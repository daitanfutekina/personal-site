---
title: "Engineering Statistics"
crumb: "Self-study Textbook"
source: "markdown"
---

IE 4613/6613, Engineering Statistics I, Mississippi State University, Fall 2026. Built from the instructor's Unit notes, homework, practice problems and equation sheets, with Montgomery and Runger as the course textbook.

The final is comprehensive over all nine units: 23 questions, made up of 1 true/false in 3 parts, 1 matching in 4 parts and 21 multiple choice, with no open response. About half of the questions need a calculation.

## Chapters

1. Statistical Thinking (Unit 1)
2. Describing Data (Unit 2)
3. Probability (Unit 3)
4. Discrete Random Variables (Unit 4)
5. Continuous Random Variables (Unit 5)
6. Correlation (Unit 6)
7. The Central Limit Theorem (Unit 7)
8. Confidence Intervals (Unit 8)
9. Hypothesis Testing (Unit 9)
