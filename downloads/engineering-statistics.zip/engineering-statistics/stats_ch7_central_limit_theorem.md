---
title: "The Central Limit Theorem"
crumb: "Engineering Statistics · Chapter 7"
meta:
  - "Est. study time: ~180 min"
  - "IE 4613 · Unit 7"
source: "markdown"
---

## Overview

A manufacturing measurement changes from part to part. If the factory makes a million parts, inspecting every one may destroy the parts, cost too much, or take longer than production itself. Engineers therefore choose a random sample and use it to learn about the population. But a sample is not a perfect copy of the population. Two equally careful engineers can take different random samples and obtain different averages. **This chapter is about predicting that variation.**

The central distinction is between a measurement of **one selected item**, written $X$, and the **average of a random sample**, written $\bar X$. Their centers agree, but their spreads do not. Once that distinction becomes automatic, probability questions about resistors, exam scores, bottling lines, shipments, and two manufacturing processes have the same structure. The Central Limit Theorem, or CLT, explains why a normal curve is often useful even when the individual measurements are not normal. Standard error gives the scale of that curve.

You will also meet a **point estimate**, the single-number guess for a population parameter obtained from sample data. The sample mean $\bar x$ estimates $\mu$, and the sample variance $s^2$ estimates $\sigma^2$. The accuracy of a point estimate depends on its sampling distribution, not on how many decimal places a calculator displays.

:::callout-key[Prerequisites]
You need the sample mean and sample variance from Chapter 2, the idea of independent events from Chapter 3, and the normal distribution and cumulative $z$ table from Chapter 5. We will use those skills without repeating the full earlier chapters. This chapter owns sampling distributions and standard error; confidence intervals belong to Chapter 8 and hypothesis testing to Chapter 9.
:::

## 7.1 Point Estimation and Sampling Distributions

The word *sample* sometimes means a list of measurements written on the paper. At other times it means a process: select ten items at random, calculate their average, put them back in the population, and repeat. The second meaning is essential. Imagine doing the experiment thousands of times. The population mean stays fixed. The data, the sample mean, and the sample variance change from one random sample to the next. The distribution of those changing sample means is a **sampling distribution**.

### Why sample at all?

Statistical inference draws conclusions about the population from a sample. Sampling is practical when testing every item is impossible, destructive, costly, or too slow. Random selection is intended to avoid systematic selection bias: if an engineer picks only the easiest parts to reach, the result may miss the variation in the full production run. Random selection does not promise that every particular sample will be representative; it gives a defensible basis for analyzing repeated-sample variation.

A **population parameter** is a fixed, usually unknown property of the whole population. Examples are the population mean $\mu$ and variance $\sigma^2$. A **sample statistic** is calculated entirely from the observed sample. Its capital-letter version, such as $\bar X$, is random before data are collected; its lowercase observed value, such as $\bar x$, is one realized number. A statistic can serve as an estimator, but the statistic is not the same thing as the population parameter.

:::definition[Definition 7.1 — Random sample]
$X_1,X_2,\ldots,X_n$ form a random sample of size $n$ when the random variables are **independent** and all $X_i$ have the **same probability distribution**. In the usual setup they therefore share population mean $\mu$ and population variance $\sigma^2$. Independence and identical distribution are the assumptions behind the simple formulas in this chapter.
:::

:::definition[Definition 7.2 — Statistic, estimator, and point estimate]
A **statistic** is any function of the observed random sample. A statistic $\hat\Theta$ used to estimate a population parameter $\theta$ is a **point estimator**. The number $\hat\theta$ obtained after observing the sample is its **point estimate**. For the mean, $\hat\mu=\bar x$. For the variance, $\hat\sigma^2=s^2$.
:::

The formulas for $\bar x$ and $s^2$ are printed on **Final Exam Equations, page 1**, immediately above the standardization formulas. The sample variance has denominator $n-1$. There is no mysterious new estimating equation to memorize: take the sample statistic whose job is to represent the parameter you care about.

:::definition[Definition 7.3 — Sampling distribution]
The **sampling distribution** of a statistic is its probability distribution over all possible random samples of the same size drawn by the same procedure. A sampling distribution of $\bar X$ concerns sample averages, not the distribution of individual measurements $X$.
:::

:::callout-intuition[Three different objects]
Think about an exam with many enrolled students. The **population** is everyone's exam score and has a fixed mean $\mu$. A **particular sample** may contain ten scores with observed average $\bar x=76.8$. The **sampling distribution** imagines every possible ten-student random sample and tracks all the possible values of $\bar X$. A score of 93 is an individual observation; 76.8 is a sample mean; $\mu$ is the true population mean. They are not interchangeable.
:::

A statement such as "find a point estimate for the mean" asks for a calculation from given measurements, not a probability from the normal table. A statement such as "what is the distribution of the sample mean?" asks what happens if the sampling procedure is repeated. A statement such as "is the mean greater than the target?" may eventually become a hypothesis test, but merely computing $\bar x$ does not answer it with inferential certainty.

### Sample observations versus a repeatable sampling process

A convenient mental experiment uses sealed bags on a conveyor. Each bag has a weight $X_i$. Take five bags and compute an average. Replace them conceptually and repeat with another random five. Some averages will be above the population mean; others will be below. The sampling distribution describes these averages. The next section identifies its center and spread, and the following sections explain how to turn it into probabilities.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 720 220" width="720" height="220" role="img" aria-label="Two distributions sharing a center but with different spreads">
<path class="fig-axis" d="M55,164 L665,164"/>
<path class="fig-curve" d="M55.00,159.74 L57.77,159.71 L60.55,159.67 L63.32,159.64 L66.09,159.59 L68.86,159.55 L71.64,159.50 L74.41,159.44 L77.18,159.38 L79.95,159.31 L82.73,159.24 L85.50,159.16 L88.27,159.07 L91.05,158.98 L93.82,158.87 L96.59,158.76 L99.36,158.63 L102.14,158.49 L104.91,158.35 L107.68,158.19 L110.45,158.01 L113.23,157.82 L116.00,157.62 L118.77,157.40 L121.55,157.16 L124.32,156.90 L127.09,156.63 L129.86,156.33 L132.64,156.01 L135.41,155.67 L138.18,155.30 L140.95,154.90 L143.73,154.48 L146.50,154.03 L149.27,153.55 L152.05,153.04 L154.82,152.50 L157.59,151.92 L160.36,151.30 L163.14,150.65 L165.91,149.95 L168.68,149.22 L171.45,148.45 L174.23,147.63 L177.00,146.77 L179.77,145.86 L182.55,144.91 L185.32,143.91 L188.09,142.86 L190.86,141.75 L193.64,140.60 L196.41,139.40 L199.18,138.14 L201.95,136.83 L204.73,135.47 L207.50,134.05 L210.27,132.58 L213.05,131.05 L215.82,129.47 L218.59,127.84 L221.36,126.15 L224.14,124.41 L226.91,122.62 L229.68,120.78 L232.45,118.88 L235.23,116.95 L238.00,114.96 L240.77,112.93 L243.55,110.87 L246.32,108.76 L249.09,106.61 L251.86,104.43 L254.64,102.23 L257.41,99.99 L260.18,97.73 L262.95,95.45 L265.73,93.16 L268.50,90.85 L271.27,88.54 L274.05,86.22 L276.82,83.91 L279.59,81.60 L282.36,79.31 L285.14,77.03 L287.91,74.77 L290.68,72.55 L293.45,70.35 L296.23,68.19 L299.00,66.08 L301.77,64.01 L304.55,62.00 L307.32,60.04 L310.09,58.15 L312.86,56.33 L315.64,54.58 L318.41,52.92 L321.18,51.33 L323.95,49.84 L326.73,48.44 L329.50,47.13 L332.27,45.92 L335.05,44.82 L337.82,43.83 L340.59,42.94 L343.36,42.17 L346.14,41.51 L348.91,40.97 L351.68,40.55 L354.45,40.24 L357.23,40.06 L360.00,40.00 L362.77,40.06 L365.55,40.24 L368.32,40.55 L371.09,40.97 L373.86,41.51 L376.64,42.17 L379.41,42.94 L382.18,43.83 L384.95,44.82 L387.73,45.92 L390.50,47.13 L393.27,48.44 L396.05,49.84 L398.82,51.33 L401.59,52.92 L404.36,54.58 L407.14,56.33 L409.91,58.15 L412.68,60.04 L415.45,62.00 L418.23,64.01 L421.00,66.08 L423.77,68.19 L426.55,70.35 L429.32,72.55 L432.09,74.77 L434.86,77.03 L437.64,79.31 L440.41,81.60 L443.18,83.91 L445.95,86.22 L448.73,88.54 L451.50,90.85 L454.27,93.16 L457.05,95.45 L459.82,97.73 L462.59,99.99 L465.36,102.23 L468.14,104.43 L470.91,106.61 L473.68,108.76 L476.45,110.87 L479.23,112.93 L482.00,114.96 L484.77,116.95 L487.55,118.88 L490.32,120.78 L493.09,122.62 L495.86,124.41 L498.64,126.15 L501.41,127.84 L504.18,129.47 L506.95,131.05 L509.73,132.58 L512.50,134.05 L515.27,135.47 L518.05,136.83 L520.82,138.14 L523.59,139.40 L526.36,140.60 L529.14,141.75 L531.91,142.86 L534.68,143.91 L537.45,144.91 L540.23,145.86 L543.00,146.77 L545.77,147.63 L548.55,148.45 L551.32,149.22 L554.09,149.95 L556.86,150.65 L559.64,151.30 L562.41,151.92 L565.18,152.50 L567.95,153.04 L570.73,153.55 L573.50,154.03 L576.27,154.48 L579.05,154.90 L581.82,155.30 L584.59,155.67 L587.36,156.01 L590.14,156.33 L592.91,156.63 L595.68,156.90 L598.45,157.16 L601.23,157.40 L604.00,157.62 L606.77,157.82 L609.55,158.01 L612.32,158.19 L615.09,158.35 L617.86,158.49 L620.64,158.63 L623.41,158.76 L626.18,158.87 L628.95,158.98 L631.73,159.07 L634.50,159.16 L637.27,159.24 L640.05,159.31 L642.82,159.38 L645.59,159.44 L648.36,159.50 L651.14,159.55 L653.91,159.59 L656.68,159.64 L659.45,159.67 L662.23,159.71 L665.00,159.74"/>
<path class="fig-curve-alt" d="M55.00,160.00 L57.77,160.00 L60.55,160.00 L63.32,160.00 L66.09,160.00 L68.86,160.00 L71.64,160.00 L74.41,160.00 L77.18,160.00 L79.95,160.00 L82.73,160.00 L85.50,160.00 L88.27,160.00 L91.05,160.00 L93.82,160.00 L96.59,160.00 L99.36,160.00 L102.14,160.00 L104.91,160.00 L107.68,160.00 L110.45,160.00 L113.23,160.00 L116.00,160.00 L118.77,160.00 L121.55,160.00 L124.32,160.00 L127.09,160.00 L129.86,160.00 L132.64,160.00 L135.41,160.00 L138.18,160.00 L140.95,160.00 L143.73,160.00 L146.50,160.00 L149.27,160.00 L152.05,160.00 L154.82,160.00 L157.59,160.00 L160.36,160.00 L163.14,160.00 L165.91,160.00 L168.68,160.00 L171.45,160.00 L174.23,160.00 L177.00,160.00 L179.77,160.00 L182.55,160.00 L185.32,160.00 L188.09,160.00 L190.86,160.00 L193.64,160.00 L196.41,160.00 L199.18,160.00 L201.95,160.00 L204.73,160.00 L207.50,160.00 L210.27,160.00 L213.05,160.00 L215.82,160.00 L218.59,160.00 L221.36,160.00 L224.14,160.00 L226.91,160.00 L229.68,160.00 L232.45,160.00 L235.23,160.00 L238.00,160.00 L240.77,160.00 L243.55,160.00 L246.32,160.00 L249.09,160.00 L251.86,160.00 L254.64,160.00 L257.41,160.00 L260.18,160.00 L262.95,160.00 L265.73,160.00 L268.50,160.00 L271.27,160.00 L274.05,160.00 L276.82,160.00 L279.59,160.00 L282.36,159.99 L285.14,159.99 L287.91,159.98 L290.68,159.96 L293.45,159.92 L296.23,159.85 L299.00,159.74 L301.77,159.55 L304.55,159.24 L307.32,158.76 L310.09,158.01 L312.86,156.90 L315.64,155.30 L318.41,153.04 L321.18,149.95 L323.95,145.86 L326.73,140.60 L329.50,134.05 L332.27,126.15 L335.05,116.95 L337.82,106.61 L340.59,95.45 L343.36,83.91 L346.14,72.55 L348.91,62.00 L351.68,52.92 L354.45,45.92 L357.23,41.51 L360.00,40.00 L362.77,41.51 L365.55,45.92 L368.32,52.92 L371.09,62.00 L373.86,72.55 L376.64,83.91 L379.41,95.45 L382.18,106.61 L384.95,116.95 L387.73,126.15 L390.50,134.05 L393.27,140.60 L396.05,145.86 L398.82,149.95 L401.59,153.04 L404.36,155.30 L407.14,156.90 L409.91,158.01 L412.68,158.76 L415.45,159.24 L418.23,159.55 L421.00,159.74 L423.77,159.85 L426.55,159.92 L429.32,159.96 L432.09,159.98 L434.86,159.99 L437.64,159.99 L440.41,160.00 L443.18,160.00 L445.95,160.00 L448.73,160.00 L451.50,160.00 L454.27,160.00 L457.05,160.00 L459.82,160.00 L462.59,160.00 L465.36,160.00 L468.14,160.00 L470.91,160.00 L473.68,160.00 L476.45,160.00 L479.23,160.00 L482.00,160.00 L484.77,160.00 L487.55,160.00 L490.32,160.00 L493.09,160.00 L495.86,160.00 L498.64,160.00 L501.41,160.00 L504.18,160.00 L506.95,160.00 L509.73,160.00 L512.50,160.00 L515.27,160.00 L518.05,160.00 L520.82,160.00 L523.59,160.00 L526.36,160.00 L529.14,160.00 L531.91,160.00 L534.68,160.00 L537.45,160.00 L540.23,160.00 L543.00,160.00 L545.77,160.00 L548.55,160.00 L551.32,160.00 L554.09,160.00 L556.86,160.00 L559.64,160.00 L562.41,160.00 L565.18,160.00 L567.95,160.00 L570.73,160.00 L573.50,160.00 L576.27,160.00 L579.05,160.00 L581.82,160.00 L584.59,160.00 L587.36,160.00 L590.14,160.00 L592.91,160.00 L595.68,160.00 L598.45,160.00 L601.23,160.00 L604.00,160.00 L606.77,160.00 L609.55,160.00 L612.32,160.00 L615.09,160.00 L617.86,160.00 L620.64,160.00 L623.41,160.00 L626.18,160.00 L628.95,160.00 L631.73,160.00 L634.50,160.00 L637.27,160.00 L640.05,160.00 L642.82,160.00 L645.59,160.00 L648.36,160.00 L651.14,160.00 L653.91,160.00 L656.68,160.00 L659.45,160.00 L662.23,160.00 L665.00,160.00"/>
<text class="fig-label" x="70" y="20">individual X</text>
<text class="fig-label" x="410" y="20">sample mean, n=25</text>
</svg>
<figcaption>The curve for an average of twenty-five independent measurements is narrower than the curve for one measurement, even though both are centered at the same population mean.</figcaption>
</figure>


:::example[Example 7.1 — Estimating a population mean from observations]
A quality engineer measures four parts, obtaining 10, 12, 11, and 9 millimeters. Determine the point estimate of the population mean.

::::answer[Answer]
**Answer:** 10.5000.

1. The requested parameter is the population mean $\mu$. The appropriate point estimator is the sample mean $\bar X$.
2. Write the actual arithmetic rather than hiding it in a summation: $\bar x=(10+12+11+9)/4=42/4=10.5000$ millimeters.
3. The observed value $\bar x$ is a statistic and is used as $\hat\mu$. It does not claim every part measures 10.5 millimeters, and it does not say the population mean is known exactly.

The point estimate says that the four observed parts suggest a population mean length of 10.5 millimeters.

Check: all four observations contribute once, and the result lies between 9 and 12.
::::
:::

:::example[Example 7.2 — Calculus II scores as a point estimate]
Final exam scores for 10 students in Calculus II are 82, 77, 71, 60, 89, 93, 73, 74, 83, and 66. What is a point estimate for the mean score?

::::answer[Answer]
**Answer:** 76.8000.

1. The target is the population mean score, so use the sample mean, $\hat\mu=\bar x$.
2. Enter the ten scores on the TI-30X IIS as an ordinary sum: $(82+77+71+60+89+93+73+74+83+66)/10$.
3. The ten scores total 768. Divide by 10 to obtain $\bar x=76.8000$ points. Keep the units as points rather than changing them to percentages.
4. The sample mean is a point estimate, not a claim that an unobserved student necessarily scores 76.8.

The ten scores give a point estimate of 76.8 points for the mean score of the population being studied.

Check: the sample average is between the smallest score, 60, and the largest score, 93.
::::
:::

### What statistics do and do not tell you

The mean is sensitive to every observation. The variance measures squared distances from that mean, and sample variance uses $n-1$ in the denominator because $\bar x$ was estimated from the same data. The standard deviation $s$ has the original units of the measurements; the variance $s^2$ has squared units. These are Chapter 2 ideas, but they matter here because later a standard error will be calculated from $s$.

A sample does not automatically eliminate selection bias. If a student asks only friends who attended every lecture, the sampling scheme can favor stronger scores. Taking more biased observations may give a more consistent estimate of the wrong quantity. The CLT is about random variation under the sampling assumptions; it is not a cure for an unfair selection process.

:::callout-pitfall[Estimates are not the parameters]
Do not write that $\bar x$ *is* the population mean $\mu$ or that the sample variance equals $\sigma^2$ by definition. They estimate those quantities. Do not confuse ten exam scores with ten possible sample means. A histogram of raw scores and a histogram of repeated-sample averages answer different questions. Also, a large sample size does not repair systematic bias from convenience sampling.
:::

### Practice: point estimates and sampling ideas

Attempt these before opening the solutions. The conceptual items test the same vocabulary that can appear in matching or true/false questions on the final exam.


:::problem[Problem 7.1 — Identify the point estimator]{difficulty=easy}
A random sample of inspected resistors is used to estimate the population mean resistance. Name the appropriate point estimator.

::::solution[Solution]
**Answer:** the sample mean.

1. Identify the population quantity: the manufacturer wants $\mu$, the mean across all resistors.
2. The sample mean $\bar X$ is calculated from sample measurements, so it is a statistic. Before sampling it varies from sample to sample.
3. Use $\bar X$ as the point estimator. After observing data, its numerical value $\bar x$ becomes the point estimate.

The statement asks for an estimator, not a normal probability or a confidence interval. This distinction is the main check.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.2 — Calculate a small sample mean]{difficulty=easy}
A random sample of four shaft diameters measures 4, 6, 8, and 10 millimeters. Give a point estimate for the population mean diameter.

::::solution[Solution]
**Answer:** 7.0000.

1. The parameter of interest is the population mean diameter $\mu$; the estimator is the sample average $\bar X$.
2. On the TI-30X IIS, enter $(4+6+8+10)/4$. The numerator equals 28 and the number of measurements is four.
3. Dividing gives $\bar x=7.0000$ millimeters. This is not an estimated standard deviation, because no spread calculation has been requested.

The sample suggests the underlying population has mean diameter about 7 millimeters.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.3 — Estimate a variance]{difficulty=standard}
Five randomly selected measurements are 12, 14, 16, 18, and 20. Compute the point estimate of the population variance using the sample variance.

::::solution[Solution]
**Answer:** 10.0000.

1. Estimate $\sigma^2$ using $s^2$, not the squared mean and not the standard error.
2. First find $\bar x=(12+14+16+18+20)/5=16$.
3. The squared differences are $(12-16)^2=16$, $(14-16)^2=4$, $(16-16)^2=0$, $(18-16)^2=4$, and $(20-16)^2=16$. Their sum is 40.
4. Use the $n-1$ denominator: $s^2=40/(5-1)=10.0000$ squared units.

The value 10 is the sample's estimate of the population variance, not the population variance known with certainty.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.4 — Recognize a sampling distribution]{difficulty=standard}
An engineer repeatedly draws independent random samples of 20 washers and records the mean thickness for each sample. Is the resulting collection of means a sampling distribution or the original population distribution?

::::solution[Solution]
**Answer:** sampling distribution.

1. Look at what one recorded number represents. It is not the thickness of a single washer; it is the average of twenty washers.
2. Repeating the random sampling procedure creates many possible realizations of the statistic $\bar X$.
3. The frequency pattern of those averages is the sampling distribution of $\bar X$. The original population distribution would instead describe thicknesses of individual washers.

The practical test is to ask whether each plotted dot is one item or one sample summary.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.5 — Estimate the center of a small process]{difficulty=standard}
A random sample of five manufactured parts has measured masses 99, 100, 101, 100, and 100 grams. Find the point estimate for the population mean mass.

::::solution[Solution]
**Answer:** 100.0000.

1. The mean mass of the whole production process is the parameter $\mu$, and the observed average is its point estimate.
2. Add all five masses before dividing: $(99+100+101+100+100)/5=500/5$.
3. The average is $100.0000$ grams. Repeated values are still separate observations and must all be counted.

The point estimate is exactly 100 grams for this particular sample. Another random sample could produce a different answer.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.6 — Does a bigger convenience sample remove bias?]{difficulty=challenge}
A supervisor estimates the factory's average defect severity by examining only the most damaged parts, but increases the sample from 20 to 200 parts. Does the larger sample by itself eliminate selection bias?

::::solution[Solution]
**Answer:** no.

1. The selection process deliberately favors damaged items, so it does not sample the population fairly.
2. Increasing the number of examined damaged items makes the estimate more stable for that selected group, not necessarily for the entire factory.
3. The CLT can describe randomness within a suitable sampling design; it cannot undo a systematically biased design.

The answer is no. Random sampling, rather than sheer sample size, is the necessary first protection against systematic selection error.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

## 7.2 The Central Limit Theorem and the Sample Mean

An individual measurement can follow a flat, skewed, or otherwise nonnormal distribution. Yet the **average of enough independent, identically distributed measurements** often follows a curve that is approximately normal. This is useful because the instructor provides cumulative normal probabilities on the equation sheet. Before looking up anything, though, decide whether the problem describes a single $X$ or a mean $\bar X$. The CLT does not turn every individual observation into a normal random variable.

### Center and spread of averages

If the $X_i$ are independent and all have population mean $\mu$, their average is $\bar X=(X_1+\cdots+X_n)/n$. Each term contributes to the average, so $E(\bar X)=\mu$. Their variances add for independent observations. Dividing a random variable by $n$ divides its variance by $n^2$. Thus the sample mean has variance $\sigma^2/n$ and standard deviation $\sigma/\sqrt n$. The mean does **not** change with sample size, but the standard deviation decreases.

:::theorem[Theorem 7.1 — Sampling mean and variance]
For independent observations from the same population with mean $\mu$ and finite variance $\sigma^2$,

$$
E(\bar X)=\mu,\qquad V(\bar X)=\frac{\sigma^2}{n},\qquad SD(\bar X)=\frac{\sigma}{\sqrt n}.
$$

These identities hold even if the original population is not normally distributed. The formula for the standard deviation is listed on **Final Exam Equations, page 1**, at the lower right as the standard error.
:::

:::theorem[Theorem 7.2 — Central Limit Theorem]
When $X_1,\ldots,X_n$ are independent and identically distributed with finite population mean $\mu$ and finite population variance $\sigma^2$, the distribution of $\bar X$ becomes approximately normal as $n$ becomes large. In the notation used in class,

$$
\bar X\ \dot\sim\ N\!\left(\mu,\frac{\sigma^2}{n}\right),\qquad
Z=\frac{\bar X-\mu}{\sigma/\sqrt n}\ \dot\sim\ N(0,1).
$$

The normal approximation improves with sample size, but its accuracy also depends on the original distribution. If the original population itself is normal, $\bar X$ is **exactly** normal for every positive sample size $n$.
:::

The $z$ formula for a sample mean is on **Final Exam Equations, page 1**, in the bottom row, immediately after the individual-observation $z$ formula. The cumulative normal table is **Table III, pages 3 and 4**. The normal table was introduced in Chapter 5, but remember that it reports $\Phi(z)=P(Z\le z)$, the area **to the left** of $z$. For a right-tail probability subtract from one. For a middle interval subtract the left cumulative area from the right cumulative area.

:::callout-intuition[Why averaging produces a bell]
Extreme averages are rare because several measurements must combine to pull the mean far from $\mu$. A single high value can be partly offset by an ordinary or low value. Across many independent samples, positive and negative deviations balance, leaving most averages close to the center. The resulting bell curve narrows as $n$ grows. A large $n$ is not magic: heavily skewed populations may need far more observations than a fairly symmetric population. Many classroom problems use $n\ge30$ as a rough comfort rule, not a theorem that makes every distribution normal at 30.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 720 215" width="720" height="215" role="img" aria-label="Uniform original distribution and approximately normal distribution of the mean of forty">
<path class="fig-axis" d="M55,157 L330,157 M390,157 L665,157"/>
<path class="fig-curve" d="M55.00,157.00 L55.69,157.00 L56.38,157.00 L57.06,157.00 L57.75,157.00 L58.44,157.00 L59.12,157.00 L59.81,157.00 L60.50,157.00 L61.19,157.00 L61.88,157.00 L62.56,157.00 L63.25,157.00 L63.94,157.00 L64.63,157.00 L65.31,157.00 L66.00,157.00 L66.69,157.00 L67.38,157.00 L68.06,157.00 L68.75,157.00 L69.44,157.00 L70.13,157.00 L70.81,157.00 L71.50,157.00 L72.19,157.00 L72.87,157.00 L73.56,157.00 L74.25,157.00 L74.94,157.00 L75.62,157.00 L76.31,157.00 L77.00,157.00 L77.69,157.00 L78.37,157.00 L79.06,157.00 L79.75,157.00 L80.44,157.00 L81.12,157.00 L81.81,157.00 L82.50,157.00 L83.19,157.00 L83.88,157.00 L84.56,157.00 L85.25,157.00 L85.94,157.00 L86.62,157.00 L87.31,157.00 L88.00,157.00 L88.69,157.00 L89.38,157.00 L90.06,157.00 L90.75,157.00 L91.44,157.00 L92.12,157.00 L92.81,157.00 L93.50,157.00 L94.19,157.00 L94.88,157.00 L95.56,157.00 L96.25,157.00 L96.94,157.00 L97.62,157.00 L98.31,157.00 L99.00,157.00 L99.69,157.00 L100.38,157.00 L101.06,157.00 L101.75,157.00 L102.44,157.00 L103.13,157.00 L103.81,157.00 L104.50,157.00 L105.19,157.00 L105.88,157.00 L106.56,157.00 L107.25,157.00 L107.94,157.00 L108.63,157.00 L109.31,157.00 L110.00,157.00 L110.69,157.00 L111.37,157.00 L112.06,157.00 L112.75,157.00 L113.44,157.00 L114.12,157.00 L114.81,157.00 L115.50,157.00 L116.19,157.00 L116.88,157.00 L117.56,157.00 L118.25,157.00 L118.94,157.00 L119.62,157.00 L120.31,157.00 L121.00,157.00 L121.69,157.00 L122.38,157.00 L123.06,157.00 L123.74,157.00 L123.75,62.00 L123.76,62.00 L124.44,62.00 L125.12,62.00 L125.81,62.00 L126.50,62.00 L127.19,62.00 L127.88,62.00 L128.56,62.00 L129.25,62.00 L129.94,62.00 L130.62,62.00 L131.31,62.00 L132.00,62.00 L132.69,62.00 L133.37,62.00 L134.06,62.00 L134.75,62.00 L135.44,62.00 L136.12,62.00 L136.81,62.00 L137.50,62.00 L138.19,62.00 L138.88,62.00 L139.56,62.00 L140.25,62.00 L140.94,62.00 L141.62,62.00 L142.31,62.00 L143.00,62.00 L143.69,62.00 L144.38,62.00 L145.06,62.00 L145.75,62.00 L146.44,62.00 L147.12,62.00 L147.81,62.00 L148.50,62.00 L149.19,62.00 L149.88,62.00 L150.56,62.00 L151.25,62.00 L151.94,62.00 L152.62,62.00 L153.31,62.00 L154.00,62.00 L154.69,62.00 L155.38,62.00 L156.06,62.00 L156.75,62.00 L157.44,62.00 L158.12,62.00 L158.81,62.00 L159.50,62.00 L160.19,62.00 L160.88,62.00 L161.56,62.00 L162.25,62.00 L162.94,62.00 L163.62,62.00 L164.31,62.00 L165.00,62.00 L165.69,62.00 L166.38,62.00 L167.06,62.00 L167.75,62.00 L168.44,62.00 L169.12,62.00 L169.81,62.00 L170.50,62.00 L171.19,62.00 L171.88,62.00 L172.56,62.00 L173.25,62.00 L173.94,62.00 L174.62,62.00 L175.31,62.00 L176.00,62.00 L176.69,62.00 L177.38,62.00 L178.06,62.00 L178.75,62.00 L179.44,62.00 L180.12,62.00 L180.81,62.00 L181.50,62.00 L182.19,62.00 L182.88,62.00 L183.56,62.00 L184.25,62.00 L184.94,62.00 L185.63,62.00 L186.31,62.00 L187.00,62.00 L187.69,62.00 L188.37,62.00 L189.06,62.00 L189.75,62.00 L190.44,62.00 L191.13,62.00 L191.81,62.00 L192.50,62.00 L193.19,62.00 L193.87,62.00 L194.56,62.00 L195.25,62.00 L195.94,62.00 L196.63,62.00 L197.31,62.00 L198.00,62.00 L198.69,62.00 L199.37,62.00 L200.06,62.00 L200.75,62.00 L201.44,62.00 L202.13,62.00 L202.81,62.00 L203.50,62.00 L204.19,62.00 L204.87,62.00 L205.56,62.00 L206.25,62.00 L206.94,62.00 L207.63,62.00 L208.31,62.00 L209.00,62.00 L209.69,62.00 L210.37,62.00 L211.06,62.00 L211.75,62.00 L212.44,62.00 L213.12,62.00 L213.81,62.00 L214.50,62.00 L215.19,62.00 L215.88,62.00 L216.56,62.00 L217.25,62.00 L217.94,62.00 L218.62,62.00 L219.31,62.00 L220.00,62.00 L220.69,62.00 L221.38,62.00 L222.06,62.00 L222.75,62.00 L223.44,62.00 L224.12,62.00 L224.81,62.00 L225.50,62.00 L226.19,62.00 L226.88,62.00 L227.56,62.00 L228.25,62.00 L228.94,62.00 L229.62,62.00 L230.31,62.00 L231.00,62.00 L231.69,62.00 L232.38,62.00 L233.06,62.00 L233.75,62.00 L234.44,62.00 L235.12,62.00 L235.81,62.00 L236.50,62.00 L237.19,62.00 L237.88,62.00 L238.56,62.00 L239.25,62.00 L239.94,62.00 L240.62,62.00 L241.31,62.00 L242.00,62.00 L242.69,62.00 L243.38,62.00 L244.06,62.00 L244.75,62.00 L245.44,62.00 L246.12,62.00 L246.81,62.00 L247.50,62.00 L248.19,62.00 L248.88,62.00 L249.56,62.00 L250.25,62.00 L250.94,62.00 L251.62,62.00 L252.31,62.00 L253.00,62.00 L253.69,62.00 L254.38,62.00 L255.06,62.00 L255.75,62.00 L256.44,62.00 L257.12,62.00 L257.81,62.00 L258.50,62.00 L259.19,62.00 L259.88,62.00 L260.56,62.00 L261.24,62.00 L261.25,62.00 L261.26,157.00 L261.94,157.00 L262.62,157.00 L263.31,157.00 L264.00,157.00 L264.69,157.00 L265.38,157.00 L266.06,157.00 L266.75,157.00 L267.44,157.00 L268.12,157.00 L268.81,157.00 L269.50,157.00 L270.19,157.00 L270.88,157.00 L271.56,157.00 L272.25,157.00 L272.94,157.00 L273.62,157.00 L274.31,157.00 L275.00,157.00 L275.69,157.00 L276.38,157.00 L277.06,157.00 L277.75,157.00 L278.44,157.00 L279.12,157.00 L279.81,157.00 L280.50,157.00 L281.19,157.00 L281.88,157.00 L282.56,157.00 L283.25,157.00 L283.94,157.00 L284.62,157.00 L285.31,157.00 L286.00,157.00 L286.69,157.00 L287.38,157.00 L288.06,157.00 L288.75,157.00 L289.44,157.00 L290.12,157.00 L290.81,157.00 L291.50,157.00 L292.19,157.00 L292.88,157.00 L293.56,157.00 L294.25,157.00 L294.94,157.00 L295.62,157.00 L296.31,157.00 L297.00,157.00 L297.69,157.00 L298.38,157.00 L299.06,157.00 L299.75,157.00 L300.44,157.00 L301.12,157.00 L301.81,157.00 L302.50,157.00 L303.19,157.00 L303.88,157.00 L304.56,157.00 L305.25,157.00 L305.94,157.00 L306.62,157.00 L307.31,157.00 L308.00,157.00 L308.69,157.00 L309.38,157.00 L310.06,157.00 L310.75,157.00 L311.44,157.00 L312.12,157.00 L312.81,157.00 L313.50,157.00 L314.19,157.00 L314.87,157.00 L315.56,157.00 L316.25,157.00 L316.94,157.00 L317.62,157.00 L318.31,157.00 L319.00,157.00 L319.69,157.00 L320.37,157.00 L321.06,157.00 L321.75,157.00 L322.44,157.00 L323.12,157.00 L323.81,157.00 L324.50,157.00 L325.19,157.00 L325.87,157.00 L326.56,157.00 L327.25,157.00 L327.94,157.00 L328.63,157.00 L329.31,157.00 L330.00,157.00"/>
<text class="fig-label" x="96" y="34">one X: uniform</text>
<path class="fig-curve-alt" d="M390.00,156.99 L391.25,156.99 L392.50,156.99 L393.75,156.99 L395.00,156.99 L396.25,156.99 L397.50,156.98 L398.75,156.98 L400.00,156.98 L401.25,156.97 L402.50,156.97 L403.75,156.96 L405.00,156.95 L406.25,156.95 L407.50,156.94 L408.75,156.93 L410.00,156.92 L411.25,156.90 L412.50,156.89 L413.75,156.87 L415.00,156.85 L416.25,156.82 L417.50,156.80 L418.75,156.77 L420.00,156.73 L421.25,156.70 L422.50,156.65 L423.75,156.60 L425.00,156.55 L426.25,156.48 L427.50,156.41 L428.75,156.34 L430.00,156.25 L431.25,156.15 L432.50,156.04 L433.75,155.92 L435.00,155.78 L436.25,155.63 L437.50,155.46 L438.75,155.28 L440.00,155.07 L441.25,154.85 L442.50,154.60 L443.75,154.33 L445.00,154.03 L446.25,153.71 L447.50,153.35 L448.75,152.97 L450.00,152.55 L451.25,152.09 L452.50,151.60 L453.75,151.06 L455.00,150.48 L456.25,149.86 L457.50,149.19 L458.75,148.47 L460.00,147.70 L461.25,146.88 L462.50,146.00 L463.75,145.06 L465.00,144.07 L466.25,143.01 L467.50,141.89 L468.75,140.71 L470.00,139.46 L471.25,138.15 L472.50,136.77 L473.75,135.32 L475.00,133.81 L476.25,132.23 L477.50,130.59 L478.75,128.88 L480.00,127.11 L481.25,125.27 L482.50,123.38 L483.75,121.43 L485.00,119.43 L486.25,117.38 L487.50,115.28 L488.75,113.15 L490.00,110.97 L491.25,108.77 L492.50,106.54 L493.75,104.28 L495.00,102.02 L496.25,99.75 L497.50,97.48 L498.75,95.22 L500.00,92.97 L501.25,90.75 L502.50,88.56 L503.75,86.41 L505.00,84.31 L506.25,82.26 L507.50,80.28 L508.75,78.37 L510.00,76.54 L511.25,74.80 L512.50,73.15 L513.75,71.60 L515.00,70.17 L516.25,68.85 L517.50,67.65 L518.75,66.58 L520.00,65.65 L521.25,64.85 L522.50,64.19 L523.75,63.67 L525.00,63.30 L526.25,63.07 L527.50,63.00 L528.75,63.07 L530.00,63.30 L531.25,63.67 L532.50,64.19 L533.75,64.85 L535.00,65.65 L536.25,66.58 L537.50,67.65 L538.75,68.85 L540.00,70.17 L541.25,71.60 L542.50,73.15 L543.75,74.80 L545.00,76.54 L546.25,78.37 L547.50,80.28 L548.75,82.26 L550.00,84.31 L551.25,86.41 L552.50,88.56 L553.75,90.75 L555.00,92.97 L556.25,95.22 L557.50,97.48 L558.75,99.75 L560.00,102.02 L561.25,104.28 L562.50,106.54 L563.75,108.77 L565.00,110.97 L566.25,113.15 L567.50,115.28 L568.75,117.38 L570.00,119.43 L571.25,121.43 L572.50,123.38 L573.75,125.27 L575.00,127.11 L576.25,128.88 L577.50,130.59 L578.75,132.23 L580.00,133.81 L581.25,135.32 L582.50,136.77 L583.75,138.15 L585.00,139.46 L586.25,140.71 L587.50,141.89 L588.75,143.01 L590.00,144.07 L591.25,145.06 L592.50,146.00 L593.75,146.88 L595.00,147.70 L596.25,148.47 L597.50,149.19 L598.75,149.86 L600.00,150.48 L601.25,151.06 L602.50,151.60 L603.75,152.09 L605.00,152.55 L606.25,152.97 L607.50,153.35 L608.75,153.71 L610.00,154.03 L611.25,154.33 L612.50,154.60 L613.75,154.85 L615.00,155.07 L616.25,155.28 L617.50,155.46 L618.75,155.63 L620.00,155.78 L621.25,155.92 L622.50,156.04 L623.75,156.15 L625.00,156.25 L626.25,156.34 L627.50,156.41 L628.75,156.48 L630.00,156.55 L631.25,156.60 L632.50,156.65 L633.75,156.70 L635.00,156.73 L636.25,156.77 L637.50,156.80 L638.75,156.82 L640.00,156.85 L641.25,156.87 L642.50,156.89 L643.75,156.90 L645.00,156.92 L646.25,156.93 L647.50,156.94 L648.75,156.95 L650.00,156.95 L651.25,156.96 L652.50,156.97 L653.75,156.97 L655.00,156.98 L656.25,156.98 L657.50,156.98 L658.75,156.99 L660.00,156.99 L661.25,156.99 L662.50,156.99 L663.75,156.99 L665.00,156.99"/>
<text class="fig-label" x="427" y="34">mean of 40: bell-shaped</text>
<text class="fig-label" x="155" y="186">4 to 6</text>
<text class="fig-label" x="501" y="186">near 5</text>
</svg>
<figcaption>A single observation remains uniform from 4 to 6, while the average of forty independent observations is much more concentrated near 5 and is approximately normal.</figcaption>
</figure>

### The examination's normal-table procedure

For almost every probability question in this unit, you can use five decisions. First, underline what is random: one measurement or a sample average. Second, identify $\mu$, $\sigma$, and $n$. Third, choose the correct denominator: $\sigma$ for $X$, or $\sigma/\sqrt n$ for $\bar X$. Fourth, round the resulting $z$ to two decimal places before looking at the instructor's six-decimal table. Fifth, translate the words "less than," "at least," or "between" into a left tail, right tail, or subtraction of areas. Tell yourself what the answer counts before writing it.

For example, $\Phi(-1.50)=0.066807$ comes from **negative-$z$ Table III, page 3, row $-1.5$, column $-0.00$**. Meanwhile $\Phi(1.50)=0.933193$ comes from **positive-$z$ Table III, page 4, row $1.5$, column $0.00$**. On the negative page the column headers run $-0.09,-0.08,\ldots,-0.00$, which is why the digits may look backward. Both tables always give left-tail area.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 720 220" width="720" height="220" role="img" aria-label="Normal curves for one measurement and averages">
<path class="fig-axis" d="M55,164 L665,164"/>
<path class="fig-curve" d="M55.00,159.96 L57.77,159.95 L60.55,159.95 L63.32,159.94 L66.09,159.93 L68.86,159.92 L71.64,159.91 L74.41,159.89 L77.18,159.88 L79.95,159.86 L82.73,159.84 L85.50,159.82 L88.27,159.79 L91.05,159.76 L93.82,159.73 L96.59,159.69 L99.36,159.65 L102.14,159.61 L104.91,159.55 L107.68,159.50 L110.45,159.43 L113.23,159.36 L116.00,159.28 L118.77,159.19 L121.55,159.10 L124.32,158.99 L127.09,158.87 L129.86,158.74 L132.64,158.59 L135.41,158.43 L138.18,158.26 L140.95,158.06 L143.73,157.85 L146.50,157.62 L149.27,157.37 L152.05,157.09 L154.82,156.79 L157.59,156.46 L160.36,156.10 L163.14,155.72 L165.91,155.30 L168.68,154.85 L171.45,154.36 L174.23,153.83 L177.00,153.26 L179.77,152.65 L182.55,152.00 L185.32,151.30 L188.09,150.55 L190.86,149.75 L193.64,148.90 L196.41,147.99 L199.18,147.02 L201.95,146.00 L204.73,144.91 L207.50,143.76 L210.27,142.55 L213.05,141.27 L215.82,139.92 L218.59,138.50 L221.36,137.02 L224.14,135.47 L226.91,133.84 L229.68,132.15 L232.45,130.38 L235.23,128.54 L238.00,126.64 L240.77,124.66 L243.55,122.62 L246.32,120.51 L249.09,118.34 L251.86,116.10 L254.64,113.81 L257.41,111.46 L260.18,109.06 L262.95,106.61 L265.73,104.12 L268.50,101.59 L271.27,99.02 L274.05,96.43 L276.82,93.82 L279.59,91.18 L282.36,88.54 L285.14,85.89 L287.91,83.25 L290.68,80.62 L293.45,78.00 L296.23,75.42 L299.00,72.86 L301.77,70.35 L304.55,67.89 L307.32,65.48 L310.09,63.14 L312.86,60.87 L315.64,58.68 L318.41,56.59 L321.18,54.58 L323.95,52.69 L326.73,50.90 L329.50,49.23 L332.27,47.68 L335.05,46.26 L337.82,44.97 L340.59,43.83 L343.36,42.82 L346.14,41.97 L348.91,41.26 L351.68,40.71 L354.45,40.32 L357.23,40.08 L360.00,40.00 L362.77,40.08 L365.55,40.32 L368.32,40.71 L371.09,41.26 L373.86,41.97 L376.64,42.82 L379.41,43.83 L382.18,44.97 L384.95,46.26 L387.73,47.68 L390.50,49.23 L393.27,50.90 L396.05,52.69 L398.82,54.58 L401.59,56.59 L404.36,58.68 L407.14,60.87 L409.91,63.14 L412.68,65.48 L415.45,67.89 L418.23,70.35 L421.00,72.86 L423.77,75.42 L426.55,78.00 L429.32,80.62 L432.09,83.25 L434.86,85.89 L437.64,88.54 L440.41,91.18 L443.18,93.82 L445.95,96.43 L448.73,99.02 L451.50,101.59 L454.27,104.12 L457.05,106.61 L459.82,109.06 L462.59,111.46 L465.36,113.81 L468.14,116.10 L470.91,118.34 L473.68,120.51 L476.45,122.62 L479.23,124.66 L482.00,126.64 L484.77,128.54 L487.55,130.38 L490.32,132.15 L493.09,133.84 L495.86,135.47 L498.64,137.02 L501.41,138.50 L504.18,139.92 L506.95,141.27 L509.73,142.55 L512.50,143.76 L515.27,144.91 L518.05,146.00 L520.82,147.02 L523.59,147.99 L526.36,148.90 L529.14,149.75 L531.91,150.55 L534.68,151.30 L537.45,152.00 L540.23,152.65 L543.00,153.26 L545.77,153.83 L548.55,154.36 L551.32,154.85 L554.09,155.30 L556.86,155.72 L559.64,156.10 L562.41,156.46 L565.18,156.79 L567.95,157.09 L570.73,157.37 L573.50,157.62 L576.27,157.85 L579.05,158.06 L581.82,158.26 L584.59,158.43 L587.36,158.59 L590.14,158.74 L592.91,158.87 L595.68,158.99 L598.45,159.10 L601.23,159.19 L604.00,159.28 L606.77,159.36 L609.55,159.43 L612.32,159.50 L615.09,159.55 L617.86,159.61 L620.64,159.65 L623.41,159.69 L626.18,159.73 L628.95,159.76 L631.73,159.79 L634.50,159.82 L637.27,159.84 L640.05,159.86 L642.82,159.88 L645.59,159.89 L648.36,159.91 L651.14,159.92 L653.91,159.93 L656.68,159.94 L659.45,159.95 L662.23,159.95 L665.00,159.96"/>
<path class="fig-curve-alt" d="M55.00,160.00 L57.77,160.00 L60.55,160.00 L63.32,160.00 L66.09,160.00 L68.86,160.00 L71.64,160.00 L74.41,160.00 L77.18,160.00 L79.95,160.00 L82.73,160.00 L85.50,160.00 L88.27,160.00 L91.05,160.00 L93.82,160.00 L96.59,160.00 L99.36,160.00 L102.14,160.00 L104.91,160.00 L107.68,160.00 L110.45,160.00 L113.23,160.00 L116.00,160.00 L118.77,160.00 L121.55,160.00 L124.32,160.00 L127.09,160.00 L129.86,160.00 L132.64,160.00 L135.41,160.00 L138.18,160.00 L140.95,160.00 L143.73,160.00 L146.50,160.00 L149.27,160.00 L152.05,160.00 L154.82,160.00 L157.59,160.00 L160.36,160.00 L163.14,160.00 L165.91,160.00 L168.68,160.00 L171.45,160.00 L174.23,160.00 L177.00,160.00 L179.77,160.00 L182.55,160.00 L185.32,160.00 L188.09,160.00 L190.86,160.00 L193.64,160.00 L196.41,160.00 L199.18,160.00 L201.95,160.00 L204.73,160.00 L207.50,160.00 L210.27,160.00 L213.05,160.00 L215.82,160.00 L218.59,160.00 L221.36,160.00 L224.14,160.00 L226.91,160.00 L229.68,160.00 L232.45,160.00 L235.23,160.00 L238.00,160.00 L240.77,160.00 L243.55,160.00 L246.32,160.00 L249.09,160.00 L251.86,160.00 L254.64,160.00 L257.41,160.00 L260.18,160.00 L262.95,160.00 L265.73,160.00 L268.50,160.00 L271.27,160.00 L274.05,160.00 L276.82,160.00 L279.59,160.00 L282.36,160.00 L285.14,160.00 L287.91,160.00 L290.68,160.00 L293.45,159.99 L296.23,159.98 L299.00,159.96 L301.77,159.92 L304.55,159.84 L307.32,159.69 L310.09,159.43 L312.86,158.99 L315.64,158.26 L318.41,157.09 L321.18,155.30 L323.95,152.65 L326.73,148.90 L329.50,143.76 L332.27,137.02 L335.05,128.54 L337.82,118.34 L340.59,106.61 L343.36,93.82 L346.14,80.62 L348.91,67.89 L351.68,56.59 L354.45,47.68 L357.23,41.97 L360.00,40.00 L362.77,41.97 L365.55,47.68 L368.32,56.59 L371.09,67.89 L373.86,80.62 L376.64,93.82 L379.41,106.61 L382.18,118.34 L384.95,128.54 L387.73,137.02 L390.50,143.76 L393.27,148.90 L396.05,152.65 L398.82,155.30 L401.59,157.09 L404.36,158.26 L407.14,158.99 L409.91,159.43 L412.68,159.69 L415.45,159.84 L418.23,159.92 L421.00,159.96 L423.77,159.98 L426.55,159.99 L429.32,160.00 L432.09,160.00 L434.86,160.00 L437.64,160.00 L440.41,160.00 L443.18,160.00 L445.95,160.00 L448.73,160.00 L451.50,160.00 L454.27,160.00 L457.05,160.00 L459.82,160.00 L462.59,160.00 L465.36,160.00 L468.14,160.00 L470.91,160.00 L473.68,160.00 L476.45,160.00 L479.23,160.00 L482.00,160.00 L484.77,160.00 L487.55,160.00 L490.32,160.00 L493.09,160.00 L495.86,160.00 L498.64,160.00 L501.41,160.00 L504.18,160.00 L506.95,160.00 L509.73,160.00 L512.50,160.00 L515.27,160.00 L518.05,160.00 L520.82,160.00 L523.59,160.00 L526.36,160.00 L529.14,160.00 L531.91,160.00 L534.68,160.00 L537.45,160.00 L540.23,160.00 L543.00,160.00 L545.77,160.00 L548.55,160.00 L551.32,160.00 L554.09,160.00 L556.86,160.00 L559.64,160.00 L562.41,160.00 L565.18,160.00 L567.95,160.00 L570.73,160.00 L573.50,160.00 L576.27,160.00 L579.05,160.00 L581.82,160.00 L584.59,160.00 L587.36,160.00 L590.14,160.00 L592.91,160.00 L595.68,160.00 L598.45,160.00 L601.23,160.00 L604.00,160.00 L606.77,160.00 L609.55,160.00 L612.32,160.00 L615.09,160.00 L617.86,160.00 L620.64,160.00 L623.41,160.00 L626.18,160.00 L628.95,160.00 L631.73,160.00 L634.50,160.00 L637.27,160.00 L640.05,160.00 L642.82,160.00 L645.59,160.00 L648.36,160.00 L651.14,160.00 L653.91,160.00 L656.68,160.00 L659.45,160.00 L662.23,160.00 L665.00,160.00"/>
<text class="fig-label" x="70" y="20">X, standard deviation 1</text>
<text class="fig-label" x="410" y="20">mean, n=25, SE 0.2</text>
</svg>
<figcaption>At the same population mean, the normal sampling distribution for $n=25$ is five times narrower in standard deviation than the individual population distribution.</figcaption>
</figure>


:::example[Example 7.3 — Uniform population, sample of forty]
Suppose that a random variable $X$ has a continuous uniform distribution with density $f(x)=1/2$ for $4\le x\le6$ and $f(x)=0$ otherwise. Find the distribution of the sample mean of a random sample of size $n=40$.

::::answer[Answer]
**Answer:** mean 5.0000, variance 0.008333, standard error 0.091287.

1. The original $X$ is uniform, not normal. The request concerns the mean of forty independent observations, so an approximate normal sampling distribution is appropriate.
2. For a uniform interval from 4 to 6, its midpoint is $\mu=(4+6)/2=5$. Its population variance is $\sigma^2=(6-4)^2/12=4/12=1/3$. The uniform-variance formula is not on the Final sheet; Chapter 5 explains that uniformly spread deviations give one-twelfth of the squared interval width as variance. Doubling the width therefore quadruples variance.
3. The variance of the sample mean is $(1/3)/40=1/120=0.008333\ldots$.
4. Its standard error is $\sqrt{1/120}=0.091287\ldots$. Therefore $\bar X\dot\sim N(5,1/120)$, where the second parameter is the **variance**.

The approximate distribution says repeated averages of forty uniform measurements cluster very tightly around 5, even though individual values can range from 4 to 6.

Check: the sampling mean remains 5, and its variance is smaller than the population variance 1/3.
::::
:::

:::example[Example 7.4 — Normally distributed resistor sample mean]
An electronics company manufactures resistors that have a mean resistance of 100 ohms and a standard deviation of 10 ohms. The resistance distribution is normal. Find the probability that a random sample of $n=25$ resistors has average resistance less than 95 ohms.

::::answer[Answer]
**Answer:** 0.006210.

1. "A random sample has an average" identifies $\bar X$, not one resistor's resistance. Because the population is normal, the sampling distribution is exactly normal even without a large-sample argument.
2. Its standard error is $10/\sqrt{25}=10/5=2$ ohms. Standardize: $z=(95-100)/2=-5/2=-2.50$.
3. In Final Table III, **page 3, row $-2.5$, column $-0.00$**, read $\Phi(-2.50)=0.006210$.
4. "Less than" is a left-tail event. We therefore use the table area directly rather than subtracting it from one.

Only about 0.6210% of random samples of twenty-five such resistors would have an average resistance below 95 ohms.

Check: 95 is 2.5 standard errors below 100, so the probability should be small.
::::
:::

:::example[Example 7.5 — Composite welds with a small sample]
The strength of a composite weld is normally distributed with mean 72 and variance 9. Find the probability that a random sample of $n=8$ welds has a sample mean strength of at least 73.

::::answer[Answer]
**Answer:** 0.173609.

1. The problem gives **variance 9**, so its standard deviation is $\sigma=\sqrt9=3$. Do not put 9 directly into the denominator.
2. Normal individual strengths imply an exactly normal sample mean even though eight observations would be small for a generic nonnormal population.
3. Calculate $SE=3/\sqrt8\approx1.06066$. The $z$ statistic is $(73-72)/1.06066\approx0.94281$, rounded to $0.94$ for Table III.
4. On **page 4, row $0.9$, column $0.04$**, $\Phi(0.94)=0.826391$. "At least" means a right tail, so $1-0.826391=0.173609$.

Approximately 17.3609% of random eight-weld samples have an average strength of at least 73.

Check: the result is less than one-half because 73 is above the center 72.
::::
:::

:::example[Example 7.6 — Professor scores, two class sizes]
A professor believes individual scores on a test have mean 75 and standard deviation 15. There are 50 students. Find (a) the probability the class mean is below 70, (b) the probability it is above 90, and (c) if there are 400 students, the probability the class mean is 76 or more.

::::answer[Answer]
**Answer:** (a) 0.009137, (b) less than 0.000048, (c) 0.091759.

1. Each part asks about a **class mean**, so calculate a standard error instead of using $15$ as the $z$ denominator. For 50 students, $SE=15/\sqrt{50}\approx2.12132$.
2. (a) $z=(70-75)/2.12132=-2.3570\approx-2.36$. **Table III, page 3, row $-2.3$, column $-0.06$** gives $\Phi(-2.36)=0.009137$.
3. (b) $z=(90-75)/2.12132\approx7.07$. The Final table only extends to $3.99$, so a more precise six-place probability is not tabulated. Its right tail is smaller than the table's $P(Z>3.90)=0.000048$, read on **page 4, row $3.9$, column $0.00$**. Report the bound, not a fabricated table value at 7.07.
4. (c) For 400 students, $SE=15/\sqrt{400}=0.75$. Then $z=(76-75)/0.75\approx1.33$ after rounding. **Page 4, row $1.3$, column $0.03$** gives $\Phi(1.33)=0.908241$, so the right tail is $1-0.908241=0.091759$.

A class mean below 70 is rare in a fifty-student class; above 90 is extraordinarily rare; and a 400-student class mean of at least 76 occurs in roughly 9.18% of such classes.

Check: the 400-student average varies less than the 50-student average because its standard error is smaller.
::::
:::

### Exact normal versus approximate normal

There are two separate reasons for writing a normal curve for $\bar X$. If the individual population is **normal**, its mean is **exactly normal for any sample size**. If the individual population is **unknown or not normal**, the CLT supports an **approximation for sufficiently large samples** under the random-sample and finite-variance assumptions. The instructor's resistor and weld problems use the first reason. The uniform problem with forty measurements uses the second reason.

If someone tells you only that $n=4$ and the source distribution is unknown, there is no basis for confidently using a normal approximation. If someone tells you that $n=400$ but all observations move together due to a common process disturbance, the independence assumption is questionable. An average of four hundred copies of essentially the same measurement is not four hundred independent pieces of information.

:::callout-pitfall[The denominator and the normality claim]
Do not substitute $\sigma^2$ for $\sigma$ when the problem states a variance. Do not use $\sigma$ instead of $\sigma/\sqrt n$ for an average. Do not declare $X$ normal merely because $\bar X$ is approximately normal. A small sample from a normal population is fine; a small sample from an unknown population is not automatically normal. Always round **the calculated $z$ to two decimals before** reading her table rather than using unrounded calculator probabilities.
:::

### Practice: conditions and probabilities for sample means


:::problem[Problem 7.7 — Normal mean above a threshold]{difficulty=easy}
Individual part lengths are normally distributed with $\mu=80$ mm and $\sigma=6$ mm. If $n=9$ parts are randomly sampled, find $P(\bar X>82)$.

::::solution[Solution]
**Answer:** 0.158655.

1. The event concerns the sample mean $\bar X$, not one part. The normal-population assumption makes the sampling distribution exactly normal at $n=9$.
2. Find $SE=6/\sqrt9=2$ millimeters and standardize: $z=(82-80)/2=1.00$.
3. **Final Table III, page 4, row $1.0$, column $0.00$** gives $\Phi(1.00)=0.841345$. The event is above 82, so take $1-0.841345=0.158655$.

About 15.8655% of nine-part random samples have an average length exceeding 82 millimeters.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.8 — CLT with an unknown original shape]{difficulty=standard}
A process has population mean 200 units and standard deviation 16 units. Its measurement distribution is unknown. For a random sample of $n=64$ independent measurements, approximate $P(\bar X<197)$.

::::solution[Solution]
**Answer:** 0.066807.

1. Because the original shape is unknown, the CLT supplies an approximation, not an exact normal result. The sample size 64 is reasonably large for this classroom calculation.
2. The standard error is $16/\sqrt{64}=2$. Thus $z=(197-200)/2=-1.50$.
3. In **Final Table III, page 3, row $-1.5$, column $-0.00$**, read $\Phi(-1.50)=0.066807$.
4. The phrase "below 197" is a left tail, so the cumulative table value is already the requested probability.

Roughly 6.6807% of such sample averages fall below 197 units.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.9 — Distribution of an average of uniform observations]{difficulty=standard}
Individual measurements are uniformly distributed from 2 through 8, and $n=36$ independent measurements are averaged. Give the approximate sampling distribution's mean, variance, and standard error.

::::solution[Solution]
**Answer:** mean 5.0000, variance 0.083333, standard error 0.288675.

1. A continuous uniform population from 2 to 8 has center $\mu=(2+8)/2=5$.
2. Its variance is $(8-2)^2/12=36/12=3$. The variance of the mean is $3/36=0.083333\ldots$.
3. Take the square root to obtain its standard error, $\sqrt{1/12}=0.288675\ldots$.
4. The CLT tells us $\bar X$ is approximately normal with mean 5 and variance $1/12$ for this sample size.

The average is centered at 5 and has a much smaller spread than one original measurement.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.10 — Can the CLT justify a four-item average?]{difficulty=easy}
A very skewed population has an unknown distribution. An independent random sample contains just $n=4$ observations. Does the CLT guarantee that the sample mean is approximately normal?

::::solution[Solution]
**Answer:** no.

1. The original population has not been stated to be normal, so exact normality of the sample mean is unavailable.
2. Four observations do not provide the large-sample support normally required for a skewed population.
3. The CLT is a limiting result as sample size increases. It gives no universal finite cutoff that guarantees accuracy for every population.

The correct response is no. More information about the original distribution or a substantially larger sample would be needed to justify the approximation.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.11 — Small sample from a normal population]{difficulty=standard}
A population is normal with $\mu=40$ and $\sigma=8$. For a random sample of $n=4$, calculate $P(\bar X\ge44)$.

::::solution[Solution]
**Answer:** 0.158655.

1. Four would be small for a generic CLT approximation, but here the original population is exactly normal, so the sample mean is exactly normal too.
2. Its standard error is $8/\sqrt4=4$. Standardize the boundary: $z=(44-40)/4=1.00$.
3. From **Final Table III, page 4, row $1.0$, column $0.00$**, $\Phi(1.00)=0.841345$. An at-least probability uses the right tail, so $1-0.841345=0.158655$.

About 15.8655% of independent four-item samples have average values of at least 44.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.12 — Probability between two sample-mean cutoffs]{difficulty=challenge}
A normally distributed process has $\mu=100$, $\sigma=10$, and sample size $n=25$. Find $P(95\le\bar X\le105)$.

::::solution[Solution]
**Answer:** 0.987580.

1. The mean's standard error is $10/\sqrt{25}=2$. Both cutoffs are five units from the center, which is 2.5 standard errors.
2. The lower cutoff gives $z=(95-100)/2=-2.50$, while the upper gives $z=(105-100)/2=2.50$.
3. **Final Table III, page 3, row $-2.5$, column $-0.00$**, gives $0.006210$. **Page 4, row $2.5$, column $0.00$**, gives $0.993790$.
4. The probability between the cutoffs is $0.993790-0.006210=0.987580$.

Approximately 98.7580% of 25-item sample averages lie between 95 and 105.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

## 7.3 Individual Observations, Standard Error, and Precision

The bottling homework is an especially useful exam trap: all three parts use the same process mean and standard deviation, but they ask about **three different things**. A randomly selected container is an individual $X$. The standard deviation of the distribution of sample means is a **standard error**. The average fill of thirty-six containers is $\bar X$. Only the second and third parts divide by $\sqrt{36}$. That is why understanding the words is more important than memorizing a formula.

### Standard deviation versus standard error

Standard deviation describes how much *individual measurements* typically vary around the population mean. Standard error describes how much a *statistic* typically varies between random samples. For the sample mean, the two are related by $SE(\bar X)=\sigma/\sqrt n$. If $n=1$, a sample mean is just one measurement and its standard error equals $\sigma$. If $n=25$, the mean's standard error is one-fifth as large. The original individual part-to-part variation does not change merely because the engineer samples more parts.

:::definition[Definition 7.4 — Standard error]
The **standard error of an estimator** $\hat\Theta$ is the standard deviation of its sampling distribution:

$$
\sigma_{\hat\Theta}=\sqrt{V(\hat\Theta)}.
$$

For a sample mean from independent, identically distributed observations, $SE(\bar X)=\sigma/\sqrt n$. If the population standard deviation is unknown, the **estimated standard error** is

$$
\hat\sigma_{\hat\Theta}=\frac{s}{\sqrt n}.
$$

Both forms are printed on **Final Exam Equations, page 1**, at the bottom right. The general square-root-of-variance definition is not printed separately: it simply says a standard deviation is the square root of a variance.
:::

A standard error is expressed in the same units as the quantity it measures. If container fill is in milliliters, then $\sigma=12$ mL and $SE=2$ mL. A sample variance, in contrast, has squared units. The standard error measures **precision** of the sample mean: a smaller standard error means averages from repeated samples tend to land closer together. It does not measure accuracy of an incorrectly calibrated instrument. A systematically shifted process can have a tiny standard error and still target the wrong population mean.

### A wording classifier that works under exam pressure

| Wording in a question | Random quantity | Denominator for a normal $z$ calculation |
|---|---|---|
| "one randomly selected container" | $X$ | $\sigma$ |
| "an individual resistor" | $X$ | $\sigma$ |
| "sample mean of 36 containers" | $\bar X$ | $\sigma/\sqrt{36}$ |
| "average of a random sample" | $\bar X$ | $\sigma/\sqrt n$ |
| "standard deviation of the sampling distribution" | spread of $\bar X$ | no $z$ needed; report $\sigma/\sqrt n$ |
| "estimate the standard error from these ten observations" | estimated spread of $\bar X$ | no probability requested; report $s/\sqrt{10}$ |

When listening to the table aloud, the central idea is simple: the word **individual** keeps the denominator $\sigma$, the word **average** changes it to $\sigma/\sqrt n$, and the phrase **standard error** asks for that denominator itself. The individual $z$ formula $z=(x-\mu)/\sigma$ is on **Final Exam Equations, page 1**, immediately next to the sample-mean $z$ formula. Neither formula should be selected before you decide which random variable is being studied.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 720 220" width="720" height="220" role="img" aria-label="Bottles one-container versus thirty-six-container mean">
<path class="fig-axis" d="M55,164 L665,164"/>
<path class="fig-guide" d="M337.12,31 L337.12,169"/>
<text class="fig-label" x="341.1" y="189">cutoff</text>
<path class="fig-curve" d="M55.00,159.54 L57.77,159.49 L60.55,159.43 L63.32,159.37 L66.09,159.31 L68.86,159.24 L71.64,159.16 L74.41,159.08 L77.18,158.99 L79.95,158.89 L82.73,158.78 L85.50,158.67 L88.27,158.54 L91.05,158.40 L93.82,158.26 L96.59,158.10 L99.36,157.92 L102.14,157.74 L104.91,157.54 L107.68,157.32 L110.45,157.09 L113.23,156.84 L116.00,156.57 L118.77,156.29 L121.55,155.98 L124.32,155.65 L127.09,155.30 L129.86,154.92 L132.64,154.52 L135.41,154.10 L138.18,153.65 L140.95,153.17 L143.73,152.65 L146.50,152.11 L149.27,151.54 L152.05,150.93 L154.82,150.29 L157.59,149.61 L160.36,148.90 L163.14,148.14 L165.91,147.35 L168.68,146.52 L171.45,145.64 L174.23,144.72 L177.00,143.76 L179.77,142.75 L182.55,141.70 L185.32,140.60 L188.09,139.46 L190.86,138.26 L193.64,137.02 L196.41,135.73 L199.18,134.39 L201.95,133.00 L204.73,131.56 L207.50,130.08 L210.27,128.54 L213.05,126.96 L215.82,125.33 L218.59,123.65 L221.36,121.92 L224.14,120.15 L226.91,118.34 L229.68,116.48 L232.45,114.58 L235.23,112.64 L238.00,110.67 L240.77,108.66 L243.55,106.61 L246.32,104.54 L249.09,102.44 L251.86,100.31 L254.64,98.16 L257.41,96.00 L260.18,93.82 L262.95,91.62 L265.73,89.42 L268.50,87.22 L271.27,85.01 L274.05,82.81 L276.82,80.62 L279.59,78.44 L282.36,76.28 L285.14,74.13 L287.91,72.02 L290.68,69.94 L293.45,67.89 L296.23,65.88 L299.00,63.91 L301.77,62.00 L304.55,60.13 L307.32,58.33 L310.09,56.59 L312.86,54.91 L315.64,53.31 L318.41,51.78 L321.18,50.33 L323.95,48.96 L326.73,47.68 L329.50,46.48 L332.27,45.39 L335.05,44.38 L337.82,43.47 L340.59,42.67 L343.36,41.97 L346.14,41.37 L348.91,40.88 L351.68,40.49 L354.45,40.22 L357.23,40.06 L360.00,40.00 L362.77,40.06 L365.55,40.22 L368.32,40.49 L371.09,40.88 L373.86,41.37 L376.64,41.97 L379.41,42.67 L382.18,43.47 L384.95,44.38 L387.73,45.39 L390.50,46.48 L393.27,47.68 L396.05,48.96 L398.82,50.33 L401.59,51.78 L404.36,53.31 L407.14,54.91 L409.91,56.59 L412.68,58.33 L415.45,60.13 L418.23,62.00 L421.00,63.91 L423.77,65.88 L426.55,67.89 L429.32,69.94 L432.09,72.02 L434.86,74.13 L437.64,76.28 L440.41,78.44 L443.18,80.62 L445.95,82.81 L448.73,85.01 L451.50,87.22 L454.27,89.42 L457.05,91.62 L459.82,93.82 L462.59,96.00 L465.36,98.16 L468.14,100.31 L470.91,102.44 L473.68,104.54 L476.45,106.61 L479.23,108.66 L482.00,110.67 L484.77,112.64 L487.55,114.58 L490.32,116.48 L493.09,118.34 L495.86,120.15 L498.64,121.92 L501.41,123.65 L504.18,125.33 L506.95,126.96 L509.73,128.54 L512.50,130.08 L515.27,131.56 L518.05,133.00 L520.82,134.39 L523.59,135.73 L526.36,137.02 L529.14,138.26 L531.91,139.46 L534.68,140.60 L537.45,141.70 L540.23,142.75 L543.00,143.76 L545.77,144.72 L548.55,145.64 L551.32,146.52 L554.09,147.35 L556.86,148.14 L559.64,148.90 L562.41,149.61 L565.18,150.29 L567.95,150.93 L570.73,151.54 L573.50,152.11 L576.27,152.65 L579.05,153.17 L581.82,153.65 L584.59,154.10 L587.36,154.52 L590.14,154.92 L592.91,155.30 L595.68,155.65 L598.45,155.98 L601.23,156.29 L604.00,156.57 L606.77,156.84 L609.55,157.09 L612.32,157.32 L615.09,157.54 L617.86,157.74 L620.64,157.92 L623.41,158.10 L626.18,158.26 L628.95,158.40 L631.73,158.54 L634.50,158.67 L637.27,158.78 L640.05,158.89 L642.82,158.99 L645.59,159.08 L648.36,159.16 L651.14,159.24 L653.91,159.31 L656.68,159.37 L659.45,159.43 L662.23,159.49 L665.00,159.54"/>
<path class="fig-curve-alt" d="M55.00,160.00 L57.77,160.00 L60.55,160.00 L63.32,160.00 L66.09,160.00 L68.86,160.00 L71.64,160.00 L74.41,160.00 L77.18,160.00 L79.95,160.00 L82.73,160.00 L85.50,160.00 L88.27,160.00 L91.05,160.00 L93.82,160.00 L96.59,160.00 L99.36,160.00 L102.14,160.00 L104.91,160.00 L107.68,160.00 L110.45,160.00 L113.23,160.00 L116.00,160.00 L118.77,160.00 L121.55,160.00 L124.32,160.00 L127.09,160.00 L129.86,160.00 L132.64,160.00 L135.41,160.00 L138.18,160.00 L140.95,160.00 L143.73,160.00 L146.50,160.00 L149.27,160.00 L152.05,160.00 L154.82,160.00 L157.59,160.00 L160.36,160.00 L163.14,160.00 L165.91,160.00 L168.68,160.00 L171.45,160.00 L174.23,160.00 L177.00,160.00 L179.77,160.00 L182.55,160.00 L185.32,160.00 L188.09,160.00 L190.86,160.00 L193.64,160.00 L196.41,160.00 L199.18,160.00 L201.95,160.00 L204.73,160.00 L207.50,160.00 L210.27,160.00 L213.05,160.00 L215.82,160.00 L218.59,160.00 L221.36,160.00 L224.14,160.00 L226.91,160.00 L229.68,160.00 L232.45,160.00 L235.23,160.00 L238.00,160.00 L240.77,160.00 L243.55,160.00 L246.32,160.00 L249.09,160.00 L251.86,160.00 L254.64,160.00 L257.41,160.00 L260.18,160.00 L262.95,160.00 L265.73,160.00 L268.50,160.00 L271.27,160.00 L274.05,160.00 L276.82,160.00 L279.59,160.00 L282.36,160.00 L285.14,160.00 L287.91,160.00 L290.68,160.00 L293.45,159.99 L296.23,159.98 L299.00,159.96 L301.77,159.92 L304.55,159.84 L307.32,159.69 L310.09,159.43 L312.86,158.99 L315.64,158.26 L318.41,157.09 L321.18,155.30 L323.95,152.65 L326.73,148.90 L329.50,143.76 L332.27,137.02 L335.05,128.54 L337.82,118.34 L340.59,106.61 L343.36,93.82 L346.14,80.62 L348.91,67.89 L351.68,56.59 L354.45,47.68 L357.23,41.97 L360.00,40.00 L362.77,41.97 L365.55,47.68 L368.32,56.59 L371.09,67.89 L373.86,80.62 L376.64,93.82 L379.41,106.61 L382.18,118.34 L384.95,128.54 L387.73,137.02 L390.50,143.76 L393.27,148.90 L396.05,152.65 L398.82,155.30 L401.59,157.09 L404.36,158.26 L407.14,158.99 L409.91,159.43 L412.68,159.69 L415.45,159.84 L418.23,159.92 L421.00,159.96 L423.77,159.98 L426.55,159.99 L429.32,160.00 L432.09,160.00 L434.86,160.00 L437.64,160.00 L440.41,160.00 L443.18,160.00 L445.95,160.00 L448.73,160.00 L451.50,160.00 L454.27,160.00 L457.05,160.00 L459.82,160.00 L462.59,160.00 L465.36,160.00 L468.14,160.00 L470.91,160.00 L473.68,160.00 L476.45,160.00 L479.23,160.00 L482.00,160.00 L484.77,160.00 L487.55,160.00 L490.32,160.00 L493.09,160.00 L495.86,160.00 L498.64,160.00 L501.41,160.00 L504.18,160.00 L506.95,160.00 L509.73,160.00 L512.50,160.00 L515.27,160.00 L518.05,160.00 L520.82,160.00 L523.59,160.00 L526.36,160.00 L529.14,160.00 L531.91,160.00 L534.68,160.00 L537.45,160.00 L540.23,160.00 L543.00,160.00 L545.77,160.00 L548.55,160.00 L551.32,160.00 L554.09,160.00 L556.86,160.00 L559.64,160.00 L562.41,160.00 L565.18,160.00 L567.95,160.00 L570.73,160.00 L573.50,160.00 L576.27,160.00 L579.05,160.00 L581.82,160.00 L584.59,160.00 L587.36,160.00 L590.14,160.00 L592.91,160.00 L595.68,160.00 L598.45,160.00 L601.23,160.00 L604.00,160.00 L606.77,160.00 L609.55,160.00 L612.32,160.00 L615.09,160.00 L617.86,160.00 L620.64,160.00 L623.41,160.00 L626.18,160.00 L628.95,160.00 L631.73,160.00 L634.50,160.00 L637.27,160.00 L640.05,160.00 L642.82,160.00 L645.59,160.00 L648.36,160.00 L651.14,160.00 L653.91,160.00 L656.68,160.00 L659.45,160.00 L662.23,160.00 L665.00,160.00"/>
<text class="fig-label" x="70" y="20">individual fill, SD 12</text>
<text class="fig-label" x="410" y="20">mean of 36, SE 2</text>
</svg>
<figcaption>A cutoff of 497 mL leaves more probability to its left for one fill than for an average of 36 fills, because the averaging distribution has standard error 2 mL instead of individual standard deviation 12 mL.</figcaption>
</figure>


:::example[Example 7.7 — Homework bottling line: individual, SE, and mean]
A bottling process fills containers with mean volume 500 mL and standard deviation 12 mL. Fill volumes are independent and normally distributed. A quality engineer randomly selects $n=36$ containers. (a) What is the probability that a randomly selected container has less than 497 mL? (b) What is the standard deviation of the sampling distribution? (c) Using the CLT, find the probability that the sample mean fill volume is less than 497 mL.

::::answer[Answer]
**Answer:** (a) 0.401294, (b) SE 2.0000, (c) 0.066807.

1. **Part (a) is about one container.** Use $z=(497-500)/12=-3/12=-0.25$. In **Final Table III, page 3, row $-0.2$, column $-0.05$**, read $\Phi(-0.25)=0.401294$. This is a fairly substantial individual-fill probability.
2. **Part (b) asks for the spread of sample averages.** $SE=\sigma/\sqrt n=12/\sqrt{36}=12/6=2.0000$ mL. This is not a probability and is not the spread of individual containers.
3. **Part (c) is about an average.** Standardize with the new denominator: $z=(497-500)/2=-1.50$. In **Table III, page 3, row $-1.5$, column $-0.00$**, $\Phi(-1.50)=0.066807$.
4. Because the underlying fill volumes are normal, the sample mean is actually normal exactly. The CLT terminology in the homework is still a valid way to motivate the sampling distribution.

The process produces individual underfills below 497 mL about 40.13% of the time, but only about 6.68% of samples of thirty-six containers have an **average** below that level.

Check: averaging reduces spread, so a mean three milliliters below target is rarer than a single fill three milliliters below target.
::::
:::

:::example[Example 7.8 — Thermal conductivity: estimated standard error]
To examine a new method for measuring thermal conductivity, ten measurements are obtained: 41.60, 41.48, 42.34, 41.95, 41.86, 42.18, 41.72, 42.26, 41.81, and 42.04. (a) Determine the sample mean. (b) Calculate the standard error of the sample mean.

::::answer[Answer]
**Answer:** (a) mean 41.9240, (b) estimated SE 0.089842.

1. The ten measurements total $41.60+41.48+42.34+41.95+41.86+42.18+41.72+42.26+41.81+42.04=419.24$. Divide by ten: $\bar x=419.24/10=41.9240$.
2. The population standard deviation $\sigma$ is not supplied, so calculate the sample standard deviation $s$. The total squared deviation about $41.924$ is $(41.60-41.924)^2+(41.48-41.924)^2+(42.34-41.924)^2+(41.95-41.924)^2+(41.86-41.924)^2+(42.18-41.924)^2+(41.72-41.924)^2+(42.26-41.924)^2+(41.81-41.924)^2+(42.04-41.924)^2=0.72644$.
3. Divide by $n-1=9$: $s^2=0.72644/9\approx0.08071556$, then take $s=\sqrt{0.08071556}\approx0.2841048$.
4. The **estimated** standard error is $s/\sqrt{10}\approx0.2841048/3.1622777=0.089842$.

The measurement method's estimated mean is 41.9240 units, and repeated samples of ten measurements would have an estimated sample-mean spread near 0.089842 units.

Check: estimated SE is smaller than s because it describes averages rather than single measurements.
::::
:::

:::example[Example 7.9 — Calculus II sample standard error]
For ten Calculus II final exam scores 82, 77, 71, 60, 89, 93, 73, 74, 83, and 66, find the standard error of the sample mean using the sample data.

::::answer[Answer]
**Answer:** 3.2173.

1. The sample mean is $\bar x=76.8$ from the earlier worked example, but a mean is not enough to calculate the sample standard deviation.
2. Square each deviation and add: $(82-76.8)^2+(77-76.8)^2+(71-76.8)^2+(60-76.8)^2+(89-76.8)^2+(93-76.8)^2+(73-76.8)^2+(74-76.8)^2+(83-76.8)^2+(66-76.8)^2=931.6$.
3. Divide by $10-1=9$ to obtain $s^2=103.5111\ldots$, then $s=\sqrt{103.5111\ldots}=10.1740\ldots$.
4. Since $\sigma$ is unknown, estimate the standard error using $s/\sqrt{10}=10.1740\ldots/3.1623\ldots=3.2173$ points.

The ten-student sample mean is estimated to vary by about 3.2173 points between comparable samples.

Check: a value near 3.2 is smaller than the estimated individual-score standard deviation near 10.17.
::::
:::

### What changing sample size really does

With a fixed population standard deviation, doubling the sample size does **not** cut standard error in half. The denominator grows by $\sqrt2$, so the new standard error is $1/\sqrt2$, or about 0.707, of the old one. To halve standard error, multiply the sample size by **four**: $\sqrt{4n}=2\sqrt n$. To reduce it to one-third, multiply sample size by nine. This inverse-square-root rule is already visible in the sheet's formula; there is no extra equation to memorize.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 720 225" width="720" height="225" role="img" aria-label="Standard error declines by square root of sample size">
<path class="fig-axis" d="M65,45 L65,175 L665,175"/>
<path class="fig-curve" d="M65.00,50.00 L71.06,86.61 L77.12,102.83 L83.18,112.50 L89.24,119.10 L95.30,123.97 L101.36,127.75 L107.42,130.81 L113.48,133.33 L119.55,135.47 L125.61,137.31 L131.67,138.92 L137.73,140.33 L143.79,141.59 L149.85,142.73 L155.91,143.75 L161.97,144.68 L168.03,145.54 L174.09,146.32 L180.15,147.05 L186.21,147.72 L192.27,148.35 L198.33,148.94 L204.39,149.48 L210.45,150.00 L216.52,150.49 L222.58,150.94 L228.64,151.38 L234.70,151.79 L240.76,152.18 L246.82,152.55 L252.88,152.90 L258.94,153.24 L265.00,153.56 L271.06,153.87 L277.12,154.17 L283.18,154.45 L289.24,154.72 L295.30,154.98 L301.36,155.24 L307.42,155.48 L313.48,155.71 L319.55,155.94 L325.61,156.16 L331.67,156.37 L337.73,156.57 L343.79,156.77 L349.85,156.96 L355.91,157.14 L361.97,157.32 L368.03,157.50 L374.09,157.67 L380.15,157.83 L386.21,157.99 L392.27,158.15 L398.33,158.30 L404.39,158.44 L410.45,158.59 L416.52,158.73 L422.58,158.86 L428.64,159.00 L434.70,159.12 L440.76,159.25 L446.82,159.38 L452.88,159.50 L458.94,159.61 L465.00,159.73 L471.06,159.84 L477.12,159.95 L483.18,160.06 L489.24,160.17 L495.30,160.27 L501.36,160.37 L507.42,160.47 L513.48,160.57 L519.55,160.66 L525.61,160.75 L531.67,160.85 L537.73,160.94 L543.79,161.02 L549.85,161.11 L555.91,161.20 L561.97,161.28 L568.03,161.36 L574.09,161.44 L580.15,161.52 L586.21,161.60 L592.27,161.67 L598.33,161.75 L604.39,161.82 L610.45,161.90 L616.52,161.97 L622.58,162.04 L628.64,162.11 L634.70,162.18 L640.76,162.24 L646.82,162.31 L652.88,162.37 L658.94,162.44 L665.00,162.50"/>
<text class="fig-label" x="55" y="31">SE</text>
<text class="fig-label" x="675" y="193">n</text>
<text class="fig-label" x="198" y="202">25</text>
<text class="fig-label" x="645" y="202">100</text>
</svg>
<figcaption>Standard error follows $\sigma/\sqrt n$: quadrupling the sample size halves the spread of sample means, not the population spread.</figcaption>
</figure>

A larger sample means a more stable average when the observations are independent and the population variability is unchanged. It does not mean every individual part becomes more consistent. The standard error is the population standard deviation of the estimator; $s/\sqrt n$ is an estimate of that unknown quantity. The instructor later introduces $t$ when studying confidence intervals with unknown $\sigma$ in Chapter 8. Do not treat an estimated standard error as if the population standard deviation had suddenly become known with certainty.

:::callout-connect[Where estimation goes next]
A point estimate $\bar x$ provides one suggested value for $\mu$. Chapter 8 adds an interval around that estimate to express precision at a specified confidence level; Chapter 9 tests claims such as $\mu=85$. The class's Exam 3 Calculus II practice includes all three, but this chapter covers only its point estimate and standard error.
:::

:::callout-pitfall[Two easy ways to lose points]
First, the word "standard deviation" might refer to **individual measurements** or to the **sampling distribution**; read the whole phrase before deciding. Second, when raw data are given and $\sigma$ is unknown, use $s/\sqrt n$, where $s^2$ divides by $n-1$. Dividing by $n$ while calculating sample variance or putting $s^2$ under the square-root-of-$n$ denominator makes the estimated SE wrong. A standard error is in the original units, never squared units.
:::

### Practice: recognizing the correct spread


:::problem[Problem 7.13 — One item versus a mean of sixteen]{difficulty=standard}
A normally distributed strength variable has $\mu=120$ and $\sigma=12$. Find (a) $P(X<117)$ for one part and (b) $P(\bar X<117)$ for an independent sample of $n=16$ parts.

::::solution[Solution]
**Answer:** (a) 0.401294, (b) 0.158655.

1. An individual $X$ uses the original standard deviation 12, giving $z=(117-120)/12=-0.25$. **Table III, page 3, row $-0.2$, column $-0.05$**, gives $0.401294$.
2. For a sample mean of sixteen, the standard error is $12/\sqrt{16}=3$.
3. The average's standardized cutoff is $z=(117-120)/3=-1.00$. **Page 3, row $-1.0$, column $-0.00$**, gives $0.158655$.
4. Both events use the same numerical cutoff, but they describe different random quantities.

About 40.13% of individual parts are below 117, compared with about 15.87% of sixteen-part averages.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.14 — Find standard error with known sigma]{difficulty=easy}
The individual population standard deviation of a dimension is $\sigma=14$ mm. A random sample contains $n=49$ parts. Find the standard error of its mean.

::::solution[Solution]
**Answer:** 2.0000.

1. The problem asks for the standard deviation of a **sample mean**. It is not asking for the original population standard deviation, which is already 14 millimeters.
2. Use the standard error formula printed at the lower right of page 1 of the Final sheet: $SE=\sigma/\sqrt n$.
3. Substitute $14/\sqrt{49}=14/7=2.0000$ millimeters.

The averages of independent 49-part samples have a standard deviation of 2 millimeters. This makes them more stable than individual part measurements.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.15 — Estimate SE when sigma is unknown]{difficulty=easy}
A random sample of $n=25$ measurements has sample standard deviation $s=7.5$ units. Estimate the standard error of the sample mean.

::::solution[Solution]
**Answer:** 1.5000.

1. The population standard deviation is not given. The stated 7.5 units is already a **sample standard deviation** $s$, so there is no need to calculate a sample variance.
2. The estimated standard error formula on Final sheet page 1 is $s/\sqrt n$.
3. Enter $7.5/\sqrt{25}=7.5/5=1.5000$ units on the TI-30X IIS.

This is the estimated spread of averages from samples of twenty-five observations. It is not a confidence interval, and it does not turn $s$ into a known population parameter.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.16 — How many observations to halve SE?]{difficulty=standard}
A process uses independent random samples of $n=25$ items. How large must the sample size become to make the standard error of its mean half as large, assuming the same population standard deviation?

::::solution[Solution]
**Answer:** 100.

1. Write $SE_{\text{old}}=\sigma/\sqrt{25}=\sigma/5$.
2. For half the old SE, the new denominator must be twice as large: $\sqrt{n_{\text{new}}}=10$.
3. Square both sides to obtain $n_{\text{new}}=100$ observations. Equivalently, multiply the original sample size by $2^2=4$.

A sample of 100 observations halves the sampling spread of the mean compared with 25 observations. Simply doubling to 50 would not achieve that reduction.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.17 — Sample mean and estimated SE from three numbers]{difficulty=standard}
Three independent measurements are 1, 4, and 7 units. Find the sample mean and the estimated standard error.

::::solution[Solution]
**Answer:** mean 4.0000, estimated SE 1.7321.

1. Compute the average: $\bar x=(1+4+7)/3=12/3=4$ units.
2. Calculate the sample variance with $n-1=2$: $s^2=((1-4)^2+(4-4)^2+(7-4)^2)/(3-1)=(9+0+9)/2=9$.
3. Take the sample standard deviation $s=\sqrt9=3$ and divide by $\sqrt3$ to get the estimated standard error $3/\sqrt3=1.7321$ units.
4. This is only an estimate of SE; three data values do not by themselves establish a CLT normal approximation.

The sample estimates a mean of 4 units, with estimated mean-to-mean spread near 1.7321 units.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.18 — Compare sample sizes at one cutoff]{difficulty=challenge}
A normal process has $\mu=70$ and $\sigma=8$. Compare $P(\bar X<69)$ when (a) $n=16$ and (b) $n=64$, using independent samples.

::::solution[Solution]
**Answer:** (a) 0.308538, (b) 0.158655.

1. With $n=16$, $SE=8/\sqrt{16}=2$. The cutoff gives $z=(69-70)/2=-0.50$, whose left tail is $0.308538$ from **page 3, row $-0.5$, column $-0.00$**.
2. With $n=64$, $SE=8/\sqrt{64}=1$. Now $z=(69-70)/1=-1.00$, whose left tail is $0.158655$ from **page 3, row $-1.0$, column $-0.00$**.
3. Both sampling distributions remain centered at 70. The larger sample is simply less spread out.

An average below 69 is less likely with 64 parts than with 16, even though individual part variability remains unchanged.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

## 7.4 Totals and Differences Between Sample Means

Shipping limits are written in **total pounds**, but the CLT formula on the Final sheet is written for a **sample mean**. The important connection is that the total of $n$ bags is exactly $n$ times their average: $T=X_1+\cdots+X_n=n\bar X$. To solve a total-weight question, either work with the total directly or divide the capacity by the number of bags and work with the average. The instructor explicitly hints at the second method in Homework 7. The two methods give the same standardized $z$ if you do not mix up the units.

### Moving between a total and an average

For $n$ independent identically distributed measurements with mean $\mu$ and standard deviation $\sigma$, the total has mean $n\mu$ and variance $n\sigma^2$. Its standard deviation is therefore $\sqrt n\,\sigma$. These facts follow from adding independent values; they are **not printed as separate formulas on the Final sheet**, but they make sense because $T=n\bar X$, and multiplying a random quantity by $n$ multiplies its standard deviation by $n$. The CLT gives an approximate normal distribution for a total when the sample size is large, just as it does for the average.

:::theorem[Theorem 7.3 — Total of independent measurements]
Let $T=X_1+\cdots+X_n=n\bar X$ for an independent random sample with population mean $\mu$ and variance $\sigma^2$. Then

$$
E(T)=n\mu,\qquad V(T)=n\sigma^2,\qquad SD(T)=\sqrt n\,\sigma.
$$

For sufficiently large $n$, $T$ is approximately normal under the CLT assumptions. If each $X_i$ is normal, the total is exactly normal. An event $T>c$ is **equivalent** to $\bar X>c/n$.
:::

The equivalence matters more than remembering another equation. If a truck carries one hundred bags and has a 5,100-pound weight limit, the equivalent limit on the **average** bag weight is $5100/100=51$ pounds. It is not 5,100 pounds per bag. In the other direction, if the mean bag weight is 50 pounds, the expected total is $100(50)=5000$ pounds.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 720 220" width="720" height="220" role="img" aria-label="Total shipment weight versus weight limit">
<path class="fig-axis" d="M55,164 L665,164"/>
<path class="fig-guide" d="M529.44,31 L529.44,169"/>
<text class="fig-label" x="533.4" y="189">cutoff</text>
<path class="fig-fill" d="M529.44,160.00 L529.44,154.73 L530.12,154.86 L530.80,154.99 L531.48,155.11 L532.16,155.23 L532.83,155.35 L533.51,155.47 L534.19,155.58 L534.87,155.70 L535.54,155.81 L536.22,155.91 L536.90,156.02 L537.58,156.12 L538.26,156.22 L538.93,156.32 L539.61,156.42 L540.29,156.51 L540.97,156.60 L541.64,156.69 L542.32,156.78 L543.00,156.87 L543.68,156.95 L544.36,157.03 L545.03,157.11 L545.71,157.19 L546.39,157.26 L547.07,157.34 L547.74,157.41 L548.42,157.48 L549.10,157.55 L549.78,157.62 L550.46,157.68 L551.13,157.75 L551.81,157.81 L552.49,157.87 L553.17,157.93 L553.84,157.99 L554.52,158.05 L555.20,158.10 L555.88,158.16 L556.56,158.21 L557.23,158.26 L557.91,158.31 L558.59,158.36 L559.27,158.41 L559.94,158.45 L560.62,158.50 L561.30,158.54 L561.98,158.58 L562.66,158.63 L563.33,158.67 L564.01,158.71 L564.69,158.74 L565.37,158.78 L566.04,158.82 L566.72,158.85 L567.40,158.89 L568.08,158.92 L568.76,158.95 L569.43,158.99 L570.11,159.02 L570.79,159.05 L571.47,159.08 L572.14,159.11 L572.82,159.13 L573.50,159.16 L574.18,159.19 L574.86,159.21 L575.53,159.24 L576.21,159.26 L576.89,159.28 L577.57,159.31 L578.24,159.33 L578.92,159.35 L579.60,159.37 L580.28,159.39 L580.96,159.41 L581.63,159.43 L582.31,159.45 L582.99,159.46 L583.67,159.48 L584.34,159.50 L585.02,159.52 L585.70,159.53 L586.38,159.55 L587.06,159.56 L587.73,159.58 L588.41,159.59 L589.09,159.60 L589.77,159.62 L590.44,159.63 L591.12,159.64 L591.80,159.65 L592.48,159.67 L593.16,159.68 L593.83,159.69 L594.51,159.70 L595.19,159.71 L595.87,159.72 L596.54,159.73 L597.22,159.74 L597.90,159.75 L598.58,159.76 L599.26,159.76 L599.93,159.77 L600.61,159.78 L601.29,159.79 L601.97,159.80 L602.64,159.80 L603.32,159.81 L604.00,159.82 L604.68,159.82 L605.36,159.83 L606.03,159.83 L606.71,159.84 L607.39,159.85 L608.07,159.85 L608.74,159.86 L609.42,159.86 L610.10,159.87 L610.78,159.87 L611.46,159.88 L612.13,159.88 L612.81,159.89 L613.49,159.89 L614.17,159.89 L614.84,159.90 L615.52,159.90 L616.20,159.91 L616.88,159.91 L617.56,159.91 L618.23,159.92 L618.91,159.92 L619.59,159.92 L620.27,159.92 L620.94,159.93 L621.62,159.93 L622.30,159.93 L622.98,159.94 L623.66,159.94 L624.33,159.94 L625.01,159.94 L625.69,159.94 L626.37,159.95 L627.04,159.95 L627.72,159.95 L628.40,159.95 L629.08,159.95 L629.76,159.96 L630.43,159.96 L631.11,159.96 L631.79,159.96 L632.47,159.96 L633.14,159.96 L633.82,159.97 L634.50,159.97 L635.18,159.97 L635.86,159.97 L636.53,159.97 L637.21,159.97 L637.89,159.97 L638.57,159.97 L639.24,159.98 L639.92,159.98 L640.60,159.98 L641.28,159.98 L641.96,159.98 L642.63,159.98 L643.31,159.98 L643.99,159.98 L644.67,159.98 L645.34,159.98 L646.02,159.98 L646.70,159.98 L647.38,159.99 L648.06,159.99 L648.73,159.99 L649.41,159.99 L650.09,159.99 L650.77,159.99 L651.44,159.99 L652.12,159.99 L652.80,159.99 L653.48,159.99 L654.16,159.99 L654.83,159.99 L655.51,159.99 L656.19,159.99 L656.87,159.99 L657.54,159.99 L658.22,159.99 L658.90,159.99 L659.58,159.99 L660.26,159.99 L660.93,159.99 L661.61,159.99 L662.29,159.99 L662.97,159.99 L663.64,159.99 L664.32,159.99 L665.00,160.00 L665.00,160.00 Z"/>
<path class="fig-curve" d="M55.00,160.00 L57.77,159.99 L60.55,159.99 L63.32,159.99 L66.09,159.99 L68.86,159.99 L71.64,159.99 L74.41,159.98 L77.18,159.98 L79.95,159.98 L82.73,159.97 L85.50,159.97 L88.27,159.96 L91.05,159.95 L93.82,159.95 L96.59,159.94 L99.36,159.93 L102.14,159.91 L104.91,159.90 L107.68,159.88 L110.45,159.86 L113.23,159.84 L116.00,159.82 L118.77,159.79 L121.55,159.75 L124.32,159.72 L127.09,159.67 L129.86,159.62 L132.64,159.57 L135.41,159.50 L138.18,159.43 L140.95,159.35 L143.73,159.26 L146.50,159.16 L149.27,159.04 L152.05,158.92 L154.82,158.77 L157.59,158.61 L160.36,158.43 L163.14,158.23 L165.91,158.01 L168.68,157.77 L171.45,157.50 L174.23,157.20 L177.00,156.87 L179.77,156.50 L182.55,156.10 L185.32,155.67 L188.09,155.19 L190.86,154.67 L193.64,154.10 L196.41,153.48 L199.18,152.81 L201.95,152.08 L204.73,151.30 L207.50,150.45 L210.27,149.54 L213.05,148.56 L215.82,147.51 L218.59,146.39 L221.36,145.19 L224.14,143.91 L226.91,142.55 L229.68,141.10 L232.45,139.57 L235.23,137.96 L238.00,136.25 L240.77,134.46 L243.55,132.58 L246.32,130.60 L249.09,128.54 L251.86,126.39 L254.64,124.16 L257.41,121.83 L260.18,119.43 L262.95,116.95 L265.73,114.39 L268.50,111.76 L271.27,109.06 L274.05,106.30 L276.82,103.49 L279.59,100.63 L282.36,97.73 L285.14,94.80 L287.91,91.84 L290.68,88.87 L293.45,85.89 L296.23,82.92 L299.00,79.96 L301.77,77.03 L304.55,74.13 L307.32,71.29 L310.09,68.50 L312.86,65.78 L315.64,63.14 L318.41,60.59 L321.18,58.15 L323.95,55.82 L326.73,53.62 L329.50,51.56 L332.27,49.63 L335.05,47.86 L337.82,46.26 L340.59,44.82 L343.36,43.56 L346.14,42.48 L348.91,41.60 L351.68,40.90 L354.45,40.40 L357.23,40.10 L360.00,40.00 L362.77,40.10 L365.55,40.40 L368.32,40.90 L371.09,41.60 L373.86,42.48 L376.64,43.56 L379.41,44.82 L382.18,46.26 L384.95,47.86 L387.73,49.63 L390.50,51.56 L393.27,53.62 L396.05,55.82 L398.82,58.15 L401.59,60.59 L404.36,63.14 L407.14,65.78 L409.91,68.50 L412.68,71.29 L415.45,74.13 L418.23,77.03 L421.00,79.96 L423.77,82.92 L426.55,85.89 L429.32,88.87 L432.09,91.84 L434.86,94.80 L437.64,97.73 L440.41,100.63 L443.18,103.49 L445.95,106.30 L448.73,109.06 L451.50,111.76 L454.27,114.39 L457.05,116.95 L459.82,119.43 L462.59,121.83 L465.36,124.16 L468.14,126.39 L470.91,128.54 L473.68,130.60 L476.45,132.58 L479.23,134.46 L482.00,136.25 L484.77,137.96 L487.55,139.57 L490.32,141.10 L493.09,142.55 L495.86,143.91 L498.64,145.19 L501.41,146.39 L504.18,147.51 L506.95,148.56 L509.73,149.54 L512.50,150.45 L515.27,151.30 L518.05,152.08 L520.82,152.81 L523.59,153.48 L526.36,154.10 L529.14,154.67 L531.91,155.19 L534.68,155.67 L537.45,156.10 L540.23,156.50 L543.00,156.87 L545.77,157.20 L548.55,157.50 L551.32,157.77 L554.09,158.01 L556.86,158.23 L559.64,158.43 L562.41,158.61 L565.18,158.77 L567.95,158.92 L570.73,159.04 L573.50,159.16 L576.27,159.26 L579.05,159.35 L581.82,159.43 L584.59,159.50 L587.36,159.57 L590.14,159.62 L592.91,159.67 L595.68,159.72 L598.45,159.75 L601.23,159.79 L604.00,159.82 L606.77,159.84 L609.55,159.86 L612.32,159.88 L615.09,159.90 L617.86,159.91 L620.64,159.93 L623.41,159.94 L626.18,159.95 L628.95,159.95 L631.73,159.96 L634.50,159.97 L637.27,159.97 L640.05,159.98 L642.82,159.98 L645.59,159.98 L648.36,159.99 L651.14,159.99 L653.91,159.99 L656.68,159.99 L659.45,159.99 L662.23,159.99 L665.00,160.00"/>
<text class="fig-label" x="70" y="20">total of 100 bags</text>
</svg>
<figcaption>For 100 independent bags with mean 50 pounds and standard deviation 4 pounds each, total weight is centered at 5,000 pounds with standard deviation 40 pounds; the region above 5,100 pounds is a small right tail.</figcaption>
</figure>


:::example[Example 7.10 — Homework truck loaded with plastic pellets]
A manufacturing company packages bulk bags of plastic pellets. Historical data indicate that the weight of an individual bag has mean 50 pounds and standard deviation 4 pounds. A truck is loaded with 100 bags and has a maximum cargo capacity of 5,100 pounds. (a) The individual bag-weight distribution is unknown; use the CLT to approximate the probability that the total exceeds 5,100 pounds. (b) Should the company be concerned about exceeding the limit?

::::answer[Answer]
**Answer:** 0.006210.

1. Call total load $T$ and average bag weight $\bar X$. Because $T=100\bar X$, the event $T>5100$ is equivalent to $\bar X>5100/100=51$ pounds per bag.
2. The mean bag weight is 50 pounds. Assuming independent bag weights from the stated process, the sample mean has standard error $4/\sqrt{100}=0.4$ pounds. The CLT is appropriate here because 100 bags are being averaged.
3. Standardize: $z=(51-50)/0.4=2.50$. **Final Table III, page 4, row $2.5$, column $0.00$** gives $\Phi(2.50)=0.993790$.
4. "Exceeds" means a right tail: $1-0.993790=0.006210$. This is $0.6210\%$ per such load under the model.
5. The risk is low but not literally zero. Whether it is acceptable depends on how often trucks are loaded and the consequences of violating the limit; a company with many shipments might still monitor it.

For a randomly loaded hundred-bag truck, the modeled chance of exceeding the 5,100-pound capacity is about six-tenths of one percent.

Check: the total has mean 5,000 lb and standard deviation 40 lb, so 5,100 lb is also 2.5 total-weight standard deviations above its mean.
::::
:::

### Comparing two processes

The instructor's aircraft-engine exercise asks whether an improved process produces a meaningfully higher **sample average lifetime** than the old process. There are now two independent sample means, so the random quantity is $D=\bar X_1-\bar X_2$. Its center is the difference of population means, $\mu_1-\mu_2$. For independent samples, variances add even though the means are subtracted. Therefore its standard deviation is the square root of $\sigma_1^2/n_1+\sigma_2^2/n_2$. The relevant normal standardized difference is

$$
Z=\frac{(\bar X_1-\bar X_2)-(\mu_1-\mu_2)}{\sqrt{\sigma_1^2/n_1+\sigma_2^2/n_2}}.
$$

:::note[Exam 3 sheet only, not on the Final sheet]
The two-sample $Z$ formula is printed on the **Exam 3 Equations sheet, page 1**, but not on the Final Exam Equations sheet or the instructor's Final Topics list. Know the concept and recognize the Exam 3 problem; do not turn this brief extension into a separate unit on two-sample inference.
:::

:::theorem[Theorem 7.4 — Difference of independent sample means]
For independent samples from populations 1 and 2,

$$
E(\bar X_1-\bar X_2)=\mu_1-\mu_2,\quad
V(\bar X_1-\bar X_2)=\frac{\sigma_1^2}{n_1}+\frac{\sigma_2^2}{n_2}.
$$

The standardized difference above is approximately standard normal when the sample-mean normal approximations are appropriate. It is exactly standard normal when the two independent populations are normal and the stated population standard deviations are used.
:::

Choose the subtraction order and stick with it. If process 1 means **new** and process 2 means **old**, then $D=\bar X_{\rm new}-\bar X_{\rm old}$ has positive mean when the process improves. A phrase such as "the difference is at least 25" is ambiguous unless the problem defines which mean comes first. State the difference you analyze before standardizing. Never subtract the variances, even when subtracting the means.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 720 220" width="720" height="220" role="img" aria-label="Aircraft process difference under two independent samples">
<path class="fig-axis" d="M55,164 L665,164"/>
<path class="fig-guide" d="M207.50,31 L207.50,169"/>
<text class="fig-label" x="211.5" y="189">cutoff</text>
<path class="fig-fill" d="M207.50,160.00 L207.50,147.94 L209.79,147.09 L212.08,146.19 L214.36,145.24 L216.65,144.24 L218.94,143.20 L221.23,142.10 L223.51,140.95 L225.80,139.75 L228.09,138.50 L230.38,137.19 L232.66,135.82 L234.95,134.40 L237.24,132.93 L239.53,131.40 L241.81,129.81 L244.10,128.17 L246.39,126.48 L248.68,124.73 L250.96,122.93 L253.25,121.08 L255.54,119.17 L257.83,117.22 L260.11,115.22 L262.40,113.18 L264.69,111.09 L266.98,108.97 L269.26,106.80 L271.55,104.60 L273.84,102.37 L276.12,100.12 L278.41,97.83 L280.70,95.53 L282.99,93.21 L285.27,90.88 L287.56,88.55 L289.85,86.21 L292.14,83.87 L294.43,81.54 L296.71,79.22 L299.00,76.92 L301.29,74.64 L303.57,72.39 L305.86,70.17 L308.15,67.99 L310.44,65.86 L312.72,63.78 L315.01,61.75 L317.30,59.78 L319.59,57.88 L321.88,56.05 L324.16,54.30 L326.45,52.63 L328.74,51.05 L331.03,49.55 L333.31,48.15 L335.60,46.86 L337.89,45.66 L340.18,44.57 L342.46,43.59 L344.75,42.73 L347.04,41.98 L349.32,41.34 L351.61,40.83 L353.90,40.44 L356.19,40.17 L358.48,40.03 L360.76,40.01 L363.05,40.11 L365.34,40.34 L367.62,40.69 L369.91,41.16 L372.20,41.75 L374.49,42.46 L376.77,43.29 L379.06,44.23 L381.35,45.28 L383.64,46.45 L385.93,47.71 L388.21,49.08 L390.50,50.54 L392.79,52.09 L395.07,53.73 L397.36,55.46 L399.65,57.26 L401.94,59.14 L404.23,61.09 L406.51,63.09 L408.80,65.16 L411.09,67.28 L413.38,69.44 L415.66,71.64 L417.95,73.88 L420.24,76.15 L422.53,78.45 L424.81,80.76 L427.10,83.09 L429.39,85.43 L431.68,87.77 L433.96,90.11 L436.25,92.44 L438.54,94.76 L440.82,97.07 L443.11,99.36 L445.40,101.62 L447.69,103.86 L449.97,106.07 L452.26,108.25 L454.55,110.39 L456.84,112.49 L459.12,114.55 L461.41,116.56 L463.70,118.53 L465.99,120.45 L468.27,122.32 L470.56,124.14 L472.85,125.90 L475.14,127.62 L477.43,129.27 L479.71,130.88 L482.00,132.43 L484.29,133.92 L486.57,135.36 L488.86,136.74 L491.15,138.07 L493.44,139.34 L495.73,140.56 L498.01,141.72 L500.30,142.84 L502.59,143.90 L504.88,144.91 L507.16,145.88 L509.45,146.79 L511.74,147.66 L514.02,148.49 L516.31,149.27 L518.60,150.00 L520.89,150.70 L523.17,151.36 L525.46,151.98 L527.75,152.56 L530.04,153.10 L532.33,153.62 L534.61,154.10 L536.90,154.55 L539.19,154.97 L541.47,155.37 L543.76,155.73 L546.05,156.07 L548.34,156.39 L550.62,156.69 L552.91,156.96 L555.20,157.22 L557.49,157.46 L559.78,157.67 L562.06,157.88 L564.35,158.06 L566.64,158.23 L568.93,158.39 L571.21,158.54 L573.50,158.67 L575.79,158.79 L578.08,158.91 L580.36,159.01 L582.65,159.10 L584.94,159.19 L587.23,159.27 L589.51,159.34 L591.80,159.41 L594.09,159.47 L596.38,159.52 L598.66,159.57 L600.95,159.61 L603.24,159.65 L605.52,159.69 L607.81,159.72 L610.10,159.75 L612.39,159.78 L614.67,159.80 L616.96,159.82 L619.25,159.84 L621.54,159.86 L623.83,159.88 L626.11,159.89 L628.40,159.90 L630.69,159.91 L632.98,159.92 L635.26,159.93 L637.55,159.94 L639.84,159.95 L642.12,159.95 L644.41,159.96 L646.70,159.96 L648.99,159.97 L651.27,159.97 L653.56,159.98 L655.85,159.98 L658.14,159.98 L660.43,159.98 L662.71,159.99 L665.00,159.99 L665.00,160.00 Z"/>
<path class="fig-curve" d="M55.00,159.99 L57.77,159.99 L60.55,159.98 L63.32,159.98 L66.09,159.98 L68.86,159.97 L71.64,159.97 L74.41,159.96 L77.18,159.96 L79.95,159.95 L82.73,159.94 L85.50,159.93 L88.27,159.92 L91.05,159.91 L93.82,159.89 L96.59,159.87 L99.36,159.85 L102.14,159.83 L104.91,159.81 L107.68,159.78 L110.45,159.74 L113.23,159.71 L116.00,159.67 L118.77,159.62 L121.55,159.56 L124.32,159.50 L127.09,159.44 L129.86,159.36 L132.64,159.27 L135.41,159.18 L138.18,159.07 L140.95,158.95 L143.73,158.82 L146.50,158.67 L149.27,158.51 L152.05,158.33 L154.82,158.13 L157.59,157.90 L160.36,157.66 L163.14,157.39 L165.91,157.10 L168.68,156.77 L171.45,156.42 L174.23,156.03 L177.00,155.61 L179.77,155.15 L182.55,154.65 L185.32,154.11 L188.09,153.53 L190.86,152.89 L193.64,152.21 L196.41,151.47 L199.18,150.68 L201.95,149.83 L204.73,148.92 L207.50,147.94 L210.27,146.90 L213.05,145.79 L215.82,144.61 L218.59,143.36 L221.36,142.03 L224.14,140.63 L226.91,139.15 L229.68,137.59 L232.45,135.95 L235.23,134.23 L238.00,132.43 L240.77,130.54 L243.55,128.58 L246.32,126.53 L249.09,124.41 L251.86,122.21 L254.64,119.93 L257.41,117.58 L260.18,115.16 L262.95,112.68 L265.73,110.13 L268.50,107.53 L271.27,104.87 L274.05,102.17 L276.82,99.43 L279.59,96.65 L282.36,93.85 L285.14,91.03 L287.91,88.19 L290.68,85.36 L293.45,82.52 L296.23,79.71 L299.00,76.92 L301.77,74.16 L304.55,71.44 L307.32,68.78 L310.09,66.18 L312.86,63.65 L315.64,61.21 L318.41,58.85 L321.18,56.60 L323.95,54.46 L326.73,52.43 L329.50,50.54 L332.27,48.78 L335.05,47.16 L337.82,45.69 L340.59,44.38 L343.36,43.24 L346.14,42.26 L348.91,41.45 L351.68,40.82 L354.45,40.36 L357.23,40.09 L360.00,40.00 L362.77,40.09 L365.55,40.36 L368.32,40.82 L371.09,41.45 L373.86,42.26 L376.64,43.24 L379.41,44.38 L382.18,45.69 L384.95,47.16 L387.73,48.78 L390.50,50.54 L393.27,52.43 L396.05,54.46 L398.82,56.60 L401.59,58.85 L404.36,61.21 L407.14,63.65 L409.91,66.18 L412.68,68.78 L415.45,71.44 L418.23,74.16 L421.00,76.92 L423.77,79.71 L426.55,82.52 L429.32,85.36 L432.09,88.19 L434.86,91.03 L437.64,93.85 L440.41,96.65 L443.18,99.43 L445.95,102.17 L448.73,104.87 L451.50,107.53 L454.27,110.13 L457.05,112.68 L459.82,115.16 L462.59,117.58 L465.36,119.93 L468.14,122.21 L470.91,124.41 L473.68,126.53 L476.45,128.58 L479.23,130.54 L482.00,132.43 L484.77,134.23 L487.55,135.95 L490.32,137.59 L493.09,139.15 L495.86,140.63 L498.64,142.03 L501.41,143.36 L504.18,144.61 L506.95,145.79 L509.73,146.90 L512.50,147.94 L515.27,148.92 L518.05,149.83 L520.82,150.68 L523.59,151.47 L526.36,152.21 L529.14,152.89 L531.91,153.53 L534.68,154.11 L537.45,154.65 L540.23,155.15 L543.00,155.61 L545.77,156.03 L548.55,156.42 L551.32,156.77 L554.09,157.10 L556.86,157.39 L559.64,157.66 L562.41,157.90 L565.18,158.13 L567.95,158.33 L570.73,158.51 L573.50,158.67 L576.27,158.82 L579.05,158.95 L581.82,159.07 L584.59,159.18 L587.36,159.27 L590.14,159.36 L592.91,159.44 L595.68,159.50 L598.45,159.56 L601.23,159.62 L604.00,159.67 L606.77,159.71 L609.55,159.74 L612.32,159.78 L615.09,159.81 L617.86,159.83 L620.64,159.85 L623.41,159.87 L626.18,159.89 L628.95,159.91 L631.73,159.92 L634.50,159.93 L637.27,159.94 L640.05,159.95 L642.82,159.96 L645.59,159.96 L648.36,159.97 L651.14,159.97 L653.91,159.98 L656.68,159.98 L659.45,159.98 L662.23,159.99 L665.00,159.99"/>
<text class="fig-label" x="70" y="20">new mean minus old mean</text>
</svg>
<figcaption>For independent normal samples, the new-minus-old mean lifetime difference is centered at 50 hours; a difference of at least 25 hours occupies almost all of this sampling distribution.</figcaption>
</figure>


:::example[Example 7.11 — Aircraft engine component improvement]
The effective life of an aircraft-engine component has mean 5000 hours and standard deviation 40 hours. An improved process raises the mean to 5050 hours and lowers the standard deviation to 30 hours. A sample of 16 components comes from the old process and 25 from the new process. What is the probability that the difference in sample means is at least 25 hours? Assume independent normally distributed processes. Interpret the difference as **new mean minus old mean**.

::::answer[Answer]
**Answer:** 0.983823.

1. Define $D=\bar X_{\rm new}-\bar X_{\rm old}$. The center is $E(D)=5050-5000=50$ hours.
2. Because samples are independent, the variance of the difference is $30^2/25+40^2/16=900/25+1600/16=36+100=136$ square hours. Its standard deviation is $\sqrt{136}\approx11.6619$ hours.
3. Standardize the 25-hour cutoff: $z=(25-50)/\sqrt{136}\approx-2.14373$, which rounds to $-2.14$ for the table.
4. From **Final Table III, page 3, row $-2.1$, column $-0.04$**, $\Phi(-2.14)=0.016177$. We want $D\ge25$, so $1-0.016177=0.983823$.
5. Both populations are normal, so the distribution of the difference is exactly normal, not merely a large-sample approximation.

There is about a 98.3823% chance that the average lifetime of a random 25-component new-process sample exceeds that of a random 16-component old-process sample by at least 25 hours.

Check: the 25-hour threshold is below the mean difference of 50 hours, so a probability well above 50% is sensible.
::::
:::

:::example[Example 7.12 — Two independently sampled normal production lines]
Line A produces normal measurements with $\mu_A=55$, $\sigma_A=8$ and sample size $n_A=16$. Line B has $\mu_B=50$, $\sigma_B=6$ and $n_B=9$. For independent samples, calculate $P(\bar X_A-\bar X_B\ge9)$.

::::answer[Answer]
**Answer:** 0.079270.

1. Define $D=\bar X_A-\bar X_B$. Its mean is $55-50=5$ measurement units.
2. Add the independent sample-mean variances: $8^2/16+6^2/9=64/16+36/9=4+4=8$. Therefore $SD(D)=\sqrt8\approx2.82843$.
3. Standardize the threshold: $z=(9-5)/2.82843\approx1.41421$, rounded to $1.41$.
4. **Final Table III, page 4, row $1.4$, column $0.01$** gives $\Phi(1.41)=0.920730$. The right tail is $1-0.920730=0.079270$.

About 7.9270% of the paired independent samples have a line-A average at least 9 units larger than the line-B average.

Check: a difference of 9 lies above the expected difference of 5, so the probability is less than one-half.
::::
:::

### Interpreting a small probability without overclaiming

A probability of 0.006210 for one truck does not prove the truck will never exceed its limit. It means that, under the specified independent-weight model, about 0.621% of comparable loads exceed it in repeated operation. A rare failure can still matter if the consequences are expensive or dangerous. Conversely, the CLT is not a guarantee that one particular truck meets the limit. Before acting on a probability, an engineer should ask whether the assumptions match actual loading conditions, whether bag weights are independent, and whether the capacity includes anything besides the modeled cargo.

:::callout-pitfall[Total weight and two-sample traps]
For a total, the threshold must be scaled to the same unit as the random variable. Comparing a 5,100-pound truck limit against a 50-pound average is nonsense until you divide by the number of bags. The total's standard deviation is $\sqrt n\sigma$, not $n\sigma$. For a difference of sample means, add the two sampling **variances**, then take a square root. Do not use a single-sample denominator or change the order of subtraction halfway through the work.
:::

### Practice: totals, thresholds, and a brief two-sample extension


:::problem[Problem 7.19 — A total load above its limit]{difficulty=standard}
A shipment contains $n=64$ independent items with mean weight $\mu=20$ lb and standard deviation $\sigma=3$ lb. Approximate the probability that the total weight exceeds 1,328 lb, assuming a suitable CLT approximation.

::::solution[Solution]
**Answer:** 0.022750.

1. The expected total is $64(20)=1280$ lb, while the total standard deviation is $\sqrt{64}(3)=24$ lb.
2. Standardize the load cutoff directly: $z=(1328-1280)/24=48/24=2.00$.
3. **Final Table III, page 4, row $2.0$, column $0.00$** gives $\Phi(2.00)=0.977250$. The requested event is above the limit, so use $1-0.977250=0.022750$.
4. Equivalently, divide the load threshold by 64 to get the average-weight cutoff 20.75 lb; that produces the same $z$.

About 2.2750% of sixty-four-item shipments exceed 1,328 lb under this model.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.20 — Total below a minimum]{difficulty=easy}
Twenty-five independent packages have mean mass $\mu=6$ lb and standard deviation $\sigma=2$ lb each. Assuming their weights are normal, find the probability that their total mass is less than 140 lb.

::::solution[Solution]
**Answer:** 0.158655.

1. The total weight has mean $25(6)=150$ lb. Its standard deviation is $\sqrt{25}(2)=10$ lb.
2. Convert the 140-pound cutoff to $z=(140-150)/10=-1.00$. Normal individual weights make the total exactly normal.
3. **Table III, page 3, row $-1.0$, column $-0.00$** gives $\Phi(-1.00)=0.158655$.
4. The phrase "less than" describes a left tail, so no subtraction from one is needed.

Approximately 15.8655% of independent 25-package shipments weigh less than 140 pounds.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.21 — A stricter truck capacity]{difficulty=standard}
Keep the Homework 7 bag model: 100 independent bags, each with $\mu=50$ lb and $\sigma=4$ lb. Suppose the cargo limit is instead 5,040 lb. Approximate the chance the total exceeds the new limit.

::::solution[Solution]
**Answer:** 0.158655.

1. The expected total is $100(50)=5000$ pounds. The standard deviation of the total is $\sqrt{100}(4)=40$ pounds.
2. The new limit is $5040-5000=40$ pounds above the mean, or $z=40/40=1.00$.
3. **Final Table III, page 4, row $1.0$, column $0.00$** gives a left area of $0.841345$. The right-tail chance is $1-0.841345=0.158655$.

About 15.8655% of these loads exceed the tighter 5,040-pound cap. A limit only 40 pounds above expected load gives a substantially larger risk than the original 5,100-pound limit.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.22 — Normal process A minus process B]{difficulty=standard}
Line A is normal with $\mu_A=55$, $\sigma_A=8$, and $n_A=16$. Independent line B is normal with $\mu_B=50$, $\sigma_B=6$, and $n_B=9$. Find $P(\bar X_A-\bar X_B\ge9)$.

::::solution[Solution]
**Answer:** 0.079270.

1. The expected line-A-minus-line-B difference is $55-50=5$. State this order before any calculations.
2. The variance of the difference is $8^2/16+6^2/9=4+4=8$. Its standard deviation is $\sqrt8=2.8284\ldots$.
3. The boundary gives $z=(9-5)/\sqrt8\approx1.41$ to two decimals.
4. **Table III, page 4, row $1.4$, column $0.01$** reads $0.920730$. Use $1-0.920730=0.079270$ for "at least".

About 7.9270% of these independent paired sample means differ by at least nine units in the stated direction.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.23 — Two different samples with different spreads]{difficulty=challenge}
Independent normal populations A and B have $\mu_A=100$, $\sigma_A=12$, $n_A=36$ and $\mu_B=98$, $\sigma_B=8$, $n_B=16$. Find $P(\bar X_A-\bar X_B>4)$.

::::solution[Solution]
**Answer:** 0.238852.

1. The mean difference is $100-98=2$. The individual standard deviations are not the denominator of the difference statistic.
2. Add sample-mean variances: $12^2/36+8^2/16=144/36+64/16=4+4=8$.
3. Standardize: $z=(4-2)/\sqrt8\approx0.7071$, which rounds to $0.71$.
4. **Table III, page 4, row $0.7$, column $0.01$** gives $\Phi(0.71)=0.761148$. The right tail is $1-0.761148=0.238852$.

About 23.8852% of independent samples have an A-minus-B mean difference greater than four units.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem 7.24 — When the truck CLT assumptions fail]{difficulty=challenge}
A loading system puts exactly the same extra 2 lb into every bag on a given truck whenever a single faulty calibration event occurs. Would it be valid to treat the resulting one-hundred bag weights as independent when applying the usual CLT standard error?

::::solution[Solution]
**Answer:** no.

1. The calibration event affects all bags in a truck together, so their weight errors have a shared component.
2. A shared disturbance means observing one unusually heavy bag gives information about the others. Their errors are not independent in the way the standard random-sample model requires.
3. The formula $\sigma/\sqrt n$ assumes independent contributions; shared errors may not average away.

The ordinary independent-bag CLT calculation cannot be trusted without a model for this common calibration effect.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

## Chapter Summary

:::summary[Chapter 7 — The quantities to keep separate]
**Point estimation:** a population parameter is fixed; a statistic is calculated from a random sample. Use $\bar x$ to estimate $\mu$ and $s^2$ to estimate $\sigma^2$. These sample-statistic formulas are on **Final sheet, page 1**.

**Sampling distribution:** the probability distribution of a statistic across repeated random samples. For independent identically distributed observations, $E(\bar X)=\mu$, $V(\bar X)=\sigma^2/n$, and the standard error is $\sigma/\sqrt n$. The standard error and mean-$z$ equation are on **Final sheet, page 1**.

**Normality:** if individual $X$ is normal, $\bar X$ is exactly normal for any $n$. Otherwise, the CLT may make $\bar X$ approximately normal when $n$ is sufficiently large and the random-sample conditions are suitable. The CLT does not say individual $X$ becomes normal.

**One observation versus an average:** for an individual, $z=(x-\mu)/\sigma$. For an average, $z=(\bar x-\mu)/(\sigma/\sqrt n)$. Use **Table III, Final sheet pages 3–4** after rounding $z$ to two decimals. The table gives left-tail area. "At least" requires $1-\Phi(z)$; "between" requires the difference of two cumulative areas.

**Unknown population spread:** when $\sigma$ is unavailable, estimate the standard error with $s/\sqrt n$ rather than pretending $s$ is the known population spread. This is an estimate of the mean's sampling variability, not a confidence interval.

**Totals:** with $T=n\bar X$, $E(T)=n\mu$ and $SD(T)=\sqrt n\sigma$. For a truck, divide the total-capacity threshold by $n$ to work with the average, or standardize the total directly. The formulas follow from independent sums and are not separately printed on the Final sheet.

**Two independent means:** $\bar X_1-\bar X_2$ has mean $\mu_1-\mu_2$ and variance $\sigma_1^2/n_1+\sigma_2^2/n_2$. The standardized formula is **Exam 3 sheet only, not on the Final sheet**. Set the subtraction order first and add variances, even when subtracting means.
:::

## Mixed Practice

The comprehensive final has true/false, matching, and multiple-choice questions, not free-response calculations. Work these as choices first. Then open each solution to see the arithmetic, the correct table row and column, and why the distractors fail. The numerical items use the instructor's table precision.


:::problem[Problem M.1 — True or false: sampling and the CLT]{difficulty=easy}
For each statement, mark true or false. (a) The sampling distribution of $\bar X$ describes possible sample means across repeated random samples. (b) The CLT says every individual observation $X$ becomes normal when $n$ is large. (c) In independent sampling, the standard error of $\bar X$ decreases when $n$ increases while $\sigma$ stays fixed.

::::solution[Solution]
**Answer:** true, false, true.

1. (a) is true: a sampling distribution is a probability distribution of a statistic calculated repeatedly, not a distribution of one randomly selected measurement.
2. (b) is false: averaging can produce an approximately normal **sample mean**; it does not change the original variable's distribution.
3. (c) is true: the denominator $\sqrt n$ in $\sigma/\sqrt n$ increases with sample size, reducing standard error.

These statements distinguish what becomes normal from what merely becomes less variable. The same confusion can appear in one multiple-choice question.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.2 — Match the four statistical descriptions]{difficulty=easy}
Match each term to a description. Terms: population parameter, point estimator, point estimate, standard error. Descriptions: (A) a realized single numerical value calculated from a sample; (B) the standard deviation of a statistic's sampling distribution; (C) a fixed characteristic of the population; (D) a sample statistic used to estimate a parameter.

::::solution[Solution]
**Answer:** parameter to C; estimator to D; estimate to A; standard error to B.

1. A population parameter is a fixed, typically unknown feature, so match it to C.
2. A point estimator is the random statistic chosen to estimate that feature, so match it to D.
3. Once the random sample is observed, the estimator's realized numerical value is the point estimate, so match it to A.
4. The standard error measures the spread of that estimator's sampling distribution, which is description B.

Do not mix up the role of a statistic with one observed value of the statistic.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.3 — Which formula fits one selected part?]{difficulty=standard}
A normally distributed production line has mean $\mu$ and standard deviation $\sigma$. A question asks about **one randomly selected part** being below $x$. Which standardization is appropriate?

(A) $(x-\mu)/(\sigma/\sqrt n)$  (B) $(x-\mu)/\sigma$  (C) $n(x-\mu)/\sigma$  (D) $(x-\mu)/\sigma^2$

::::solution[Solution]
**Answer:** (B) individual-observation standardization.

1. The wording says one selected part, so the random variable is $X$ and its standard deviation is $\sigma$.
2. Choice B uses exactly that spread. A would fit an average of $n$ independent parts, not one part. C adds a sample-size factor with no justification.
3. D divides by a variance, which has squared units; a standardized number must be unitless.

Select the denominator from the random quantity first. You do not need the normal table to make this choice.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.4 — Probability for one container]{difficulty=standard}
A normal filling process has $\mu=60$ mL and $\sigma=8$ mL. What is $P(X<58)$ for one randomly selected container?

(A) 0.158655  (B) 0.598706  (C) 0.401294  (D) 0.841345

::::solution[Solution]
**Answer:** (C) 0.401294.

1. A single container uses $\sigma=8$, so $z=(58-60)/8=-0.25$.
2. **Final Table III, page 3, row $-0.2$, column $-0.05$** gives $\Phi(-0.25)=0.401294$; that is choice C.
3. A is the $z=-1$ left tail, an incorrect sampling-mean scale for an invented sample size. B is $\Phi(0.25)$ and reverses the sign. D is the left area at positive $z=1$.

About 40.1294% of individual fills fall below 58 mL in this model.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.5 — Probability for the average of sixteen]{difficulty=standard}
For the same normal filling process, $\mu=60$ mL and $\sigma=8$ mL, what is $P(\bar X<58)$ when $n=16$ independent containers are averaged?

(A) 0.401294  (B) 0.158655  (C) 0.841345  (D) 0.598706

::::solution[Solution]
**Answer:** (B) 0.158655.

1. The random quantity is the average of sixteen, so its standard error is $8/\sqrt{16}=2$ mL.
2. Standardize: $z=(58-60)/2=-1.00$. **Final Table III, page 3, row $-1.0$, column $-0.00$** gives $0.158655$, choice B.
3. A is the single-container probability and incorrectly retains $\sigma=8$. C is the right-tail complement. D uses the wrong sign with the single-container scale.

About 15.8655% of sixteen-container samples have mean fill below 58 mL.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.6 — Standard error from known sigma]{difficulty=easy}
A process has standard deviation $\sigma=10$ mm and a random sample of $n=25$ is selected. Which is the standard error of $\bar X$?

(A) 50.0000 mm  (B) 0.4000 mm  (C) 10.0000 mm  (D) 2.0000 mm

::::solution[Solution]
**Answer:** (D) 2.0000.

1. Standard error is the spread of averages of twenty-five measurements, not the spread of one measurement.
2. Use the Final sheet's formula: $\sigma/\sqrt n=10/\sqrt{25}=10/5=2.0000$ mm. This is D.
3. A multiplies instead of dividing by $\sqrt n$. B divides by $n$ rather than $\sqrt n$. C simply repeats the original population standard deviation.

Two millimeters is the standard deviation of the sampling distribution of the mean, in the original length units.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.7 — When normality cannot be assumed]{difficulty=challenge}
A population distribution is unknown and severely skewed. A random sample of $n=4$ is collected. Which statement is justified?

(A) $\bar X$ must be exactly normal.  (B) $X$ is normal by the CLT.  (C) The CLT does not guarantee a good normal approximation here.  (D) The standard error must equal zero.

::::solution[Solution]
**Answer:** (C) CLT approximation not guaranteed.

1. The population is unknown and strongly skewed; normality has not been assumed.
2. Four observations do not ensure a useful large-sample approximation. Therefore C is justified.
3. A mistakenly asserts exact normality, which requires an appropriate normal population assumption. B confuses the distribution of individual $X$ with the sampling distribution of $\bar X$.
4. D is false because averaging reduces variation without generally eliminating it.

The CLT is a limiting result, not a blanket statement that any average follows a bell curve.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.8 — Effect of quadrupling sample size]{difficulty=standard}
A process keeps the same population standard deviation but quadruples its independent sample size. The new standard error is what fraction of the old standard error?

(A) 0.2500  (B) 2.0000  (C) 0.5000  (D) 4.0000

::::solution[Solution]
**Answer:** (C) 0.5000.

1. Let the original sample contain 25 observations and the new one contain 100. Any other quadrupling pair gives the same ratio.
2. Old standard error is $\sigma/5$ and new standard error is $\sigma/10$.
3. Their ratio is $(\sigma/10)/(\sigma/5)=1/2=0.5000$, choice C.
4. A incorrectly divides SE by four instead of by $\sqrt4$. B and D predict greater error from more independent data.

Quadrupling sample size halves sampling variability in the average; it does not change the individual standard deviation.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.9 — Shipment capacity in total pounds]{difficulty=standard}
Twenty-five independent normal bags each have mean 200 lb and standard deviation 5 lb. A trailer can hold 5,050 lb. What is the probability that the **total** bag weight exceeds its capacity?

(A) 0.977250  (B) 0.022750  (C) 0.158655  (D) 0.500000

::::solution[Solution]
**Answer:** (B) 0.022750.

1. The total has mean $25(200)=5000$ lb and standard deviation $\sqrt{25}(5)=25$ lb.
2. The cutoff gives $z=(5050-5000)/25=2.00$.
3. **Final Table III, page 4, row $2.0$, column $0.00$** gives $0.977250$ left of the cutoff; use $1-0.977250=0.022750$ for the exceedance probability, choice B.
4. A is the wrong tail. C corresponds to $z=1$, which uses a wrong denominator or threshold. D pretends the limit equals the average.

About 2.2750% of such shipments exceed 5,050 pounds.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.10 — Point estimate from exam scores]{difficulty=easy}
Ten Calculus II exam scores are 82, 77, 71, 60, 89, 93, 73, 74, 83, and 66. What is the point estimate of the population mean score?

(A) 76.8000  (B) 10.1740  (C) 3.2173  (D) 85.0000

::::solution[Solution]
**Answer:** (A) 76.8000.

1. A point estimate of $\mu$ is the sample mean. Add the ten given scores: $82+77+71+60+89+93+73+74+83+66=768$.
2. Divide by ten to obtain $768/10=76.8000$, choice A.
3. B is approximately the sample standard deviation; C is approximately its estimated standard error. Neither is the mean. D is a proposed value in the separate hypothesis-testing questions, not the observed average.

The observed sample provides 76.8 points as the estimate of the population mean score.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.11 — Variance of a sample mean]{difficulty=standard}
A process has $\sigma=12$ and $n=36$ independent observations. Which is the **variance** $V(\bar X)$?

(A) 12.0000  (B) 2.0000  (C) 4.0000  (D) 0.3333

::::solution[Solution]
**Answer:** (C) 4.0000.

1. The individual population variance is $\sigma^2=12^2=144$.
2. For the mean, divide the variance by the sample size: $V(\bar X)=144/36=4.0000$. That is choice C.
3. B is the **standard error** $12/\sqrt{36}=2$; it is the square root of the requested variance. A repeats the individual standard deviation. D results from dividing $\sigma$ by 36 rather than calculating $\sigma^2/n$.

The sampling distribution's variance is 4 squared units, corresponding to standard error 2 original units.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.12 — Probability of a two-sample difference]{difficulty=challenge}
Independent normal lines A and B have $\mu_A=55$, $\sigma_A=8$, $n_A=16$ and $\mu_B=50$, $\sigma_B=6$, $n_B=9$. What is $P(\bar X_A-\bar X_B\ge9)$?

(A) 0.920730  (B) 0.079270  (C) 0.158655  (D) 0.500000

::::solution[Solution]
**Answer:** (B) 0.079270.

1. The center of A-minus-B is $55-50=5$. The difference has variance $8^2/16+6^2/9=4+4=8$.
2. Its standard deviation is $\sqrt8$, giving $z=(9-5)/\sqrt8\approx1.41$ after rounding.
3. **Final Table III, page 4, row $1.4$, column $0.01$** gives $0.920730$ to the left. The question wants at least 9, so use its complement $0.079270$, choice B.
4. A is the wrong tail, C corresponds to $z=1$ from an incorrect spread, and D ignores that 9 exceeds the mean difference 5.

Such an unusually large A-minus-B sample difference occurs in about 7.927% of paired samples.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.13 — Point estimate using six observations]{difficulty=standard}
A random sample of six readings is 11, 12, 13, 14, 15, and 16. What point estimate should be used for the population mean?

(A) 16.0000  (B) 2.0000  (C) 12.0000  (D) 13.5000

::::solution[Solution]
**Answer:** (D) 13.5000.

1. The population mean is estimated by the observed sample mean, not the maximum or the sample standard deviation.
2. Add all six measurements: $11+12+13+14+15+16=81$.
3. Divide by six to obtain $81/6=13.5000$, choice D.
4. A incorrectly selects the maximum. B is not the average; C is simply one observed value and ignores the others.

The six measurements provide a point estimate of 13.5 units for the population mean.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::

:::problem[Problem M.14 — Choose exact or approximate sampling normality]{difficulty=challenge}
Which statement is correct?

(A) Any sample mean is exactly normal for $n=2$.  (B) When individual observations are normal, their independent sample mean is exactly normal even for small $n$.  (C) Every population becomes normal when its sample size reaches 30.  (D) CLT normality never applies when the individual population is uniform.

::::solution[Solution]
**Answer:** (B) exact normal mean from a normal population.

1. If the original individual observations are normal and independent, the sample mean is a linear combination of normal variables and is exactly normal. Thus B is correct.
2. A incorrectly gives exact normality without specifying the population. C confuses sample averages with a transformation of the population and treats 30 as a guarantee.
3. D is wrong because a uniform population with finite variance is a classic case where sufficiently large sample averages become approximately normal.

The key distinction is **exact because the source is normal** versus **approximate because the sample is sufficiently large**.

Check: The calculation uses the stated sample size and the event direction in the question.
::::
:::
