---
title: "Correlation"
crumb: "Engineering Statistics · Chapter 6"
meta:
  - "Est. study time: ~110 min"
  - "IE 4613 · Unit 6"
source: "markdown"
---

## Overview

Two measurements can vary together without one measurement determining the other. As drivers become older, the maximum distance at which they can read a road sign tends to fall. As customer revenue increases, a customer-satisfaction index might tend to rise. A scatterplot makes either relationship visible; a correlation coefficient gives its **linear direction and strength** as a number. The two approaches answer related, but not identical, questions.

For this unit, learn to read a cloud of points before calculating anything. Describe a scatterplot with **direction, form, and strength**. Translate a positive or negative correlation into an actual statement about the two variables. Distinguish a strong linear association from a weak one. Most importantly, do not turn an association into a claim of causation. Those are the skills tested in the instructor's homework and Exam 3 practice problems.

The Unit 6 notes also give a formula for sample covariance and two equivalent formulas for sample correlation $r$. We will calculate them by hand with short data sets so the ideas are clear. **Neither covariance nor correlation appears on the Final Exam Equations sheet, pages 1–6, or on the Exam 3 Equations sheet.** The provided correlation assessment questions ask for descriptions and examples, not long computations. There are no $z$, $t$, or chi-square table lookups in this chapter.

:::callout-key[What to recognize on the final]
If you see a **scatterplot**, identify the x-variable and y-variable, then say whether the points generally rise or fall, whether they follow a line or curve, and how tightly they cluster. If you see an **$r$-value**, read the sign as direction and $|r|$ as linear strength. If you see **“reasonable description of Y”**, invent a sensible variable with the required direction. If you see **“causes”**, demand more evidence than a correlation.
:::

:::callout-connect[Where this fits]
Chapter 2, *Describing Data*, studies individual variables, their plots, and sample standard deviations. This chapter studies two variables together. Chapter 1, *Statistical Thinking*, explains why a sample and the population it represents are different; a measured sample association alone does not prove a universal relationship.
:::

## 6.1 Scatterplots: Direction, Form, and Strength

Suppose an engineer measures a person's age and the maximum distance from which that person can read a road sign. There are two observations **on each person**, not two unrelated lists. Each person's age and distance form one ordered pair, $(x,y)$. Put age on the horizontal axis, distance on the vertical axis, and mark one point for that pair. Repeat for every person. A picture of all the points lets you see whether the variables tend to move together.

The instructor describes the first variable as the **independent variable**, placed on the x-axis, and the second as the **dependent variable**, placed on the y-axis. In observational examples, it is also useful to say **explanatory variable** (x) and **response variable** (y). An axis label identifies a variable and its units; a point identifies a paired observation. A point does not represent the mean of all observations at that age.

:::callout-intuition[Read the cloud, not just two dots]
Look from left to right. If higher x-values tend to come with higher y-values, the overall direction is positive. If higher x-values tend to come with lower y-values, it is negative. Next decide whether a straight line is a fair summary of the pattern. Last decide whether the points are narrowly or widely scattered around that pattern. You can describe all three without knowing any formula.
:::

:::definition[Definition 6.1 — Scatterplot]
A **scatterplot** displays paired quantitative measurements $(x_i,y_i)$ on horizontal and vertical numerical axes. Each plotted point corresponds to one pair of measurements. Following the instructor's convention, the independent or explanatory variable is on the x-axis and the dependent or response variable is on the y-axis.
:::

:::definition[Definition 6.2 — The three descriptions]
**Direction** is positive (generally upward as x increases), negative (generally downward), or no apparent direction. **Form** is approximately linear if a straight line describes the pattern, or nonlinear if a curve or other shape describes it better. **Strength** is how closely the points follow the form: strong, moderate, or weak. For a linear relationship, the correlation coefficient helps assess strength; it does not assess every nonlinear form.
:::

### Direction comes first

An upward trend means the measurements tend to increase together. For example, hours spent using a machine and its accumulated operating hours are positively related. A downward trend means one tends to decrease as the other increases, such as remaining fuel in a tank versus miles traveled, while other conditions are approximately constant. A positive trend can be steep or gentle; **slope is not the same as strength**. A steep cloud with enormous scatter may have a weaker linear association than a shallow cloud with little scatter.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 680 315" width="680" height="315" role="img" aria-label="Two scatterplots: one generally rises and the other generally falls.">
<path class="fig-axis" d="M42.0,37.0 V231.0 H292.0"/>
<path class="fig-axis" d="M42.0,231.0 v5"/>
<text class="fig-label" x="42.0" y="249.0" text-anchor="middle">0</text>
<path class="fig-axis" d="M167.0,231.0 v5"/>
<text class="fig-label" x="167.0" y="249.0" text-anchor="middle">5</text>
<path class="fig-axis" d="M292.0,231.0 v5"/>
<text class="fig-label" x="292.0" y="249.0" text-anchor="middle">10</text>
<path class="fig-axis" d="M37.0,231.0 h5"/>
<text class="fig-label" x="33.0" y="234.0" text-anchor="end">0</text>
<path class="fig-axis" d="M37.0,134.0 h5"/>
<text class="fig-label" x="33.0" y="137.0" text-anchor="end">5</text>
<path class="fig-axis" d="M37.0,37.0 h5"/>
<text class="fig-label" x="33.0" y="40.0" text-anchor="end">10</text>
<text class="fig-label" x="167.0" y="268.0" text-anchor="middle">x</text>
<text class="fig-label" x="42.0" y="28.0">y</text>
<path class="fig-curve" d="M42.00,196.08 L43.56,195.23 L45.12,194.38 L46.69,193.53 L48.25,192.69 L49.81,191.84 L51.38,190.99 L52.94,190.14 L54.50,189.29 L56.06,188.44 L57.62,187.59 L59.19,186.74 L60.75,185.90 L62.31,185.05 L63.88,184.20 L65.44,183.35 L67.00,182.50 L68.56,181.65 L70.12,180.80 L71.69,179.95 L73.25,179.10 L74.81,178.26 L76.38,177.41 L77.94,176.56 L79.50,175.71 L81.06,174.86 L82.62,174.01 L84.19,173.16 L85.75,172.31 L87.31,171.47 L88.88,170.62 L90.44,169.77 L92.00,168.92 L93.56,168.07 L95.12,167.22 L96.69,166.37 L98.25,165.53 L99.81,164.68 L101.38,163.83 L102.94,162.98 L104.50,162.13 L106.06,161.28 L107.62,160.43 L109.19,159.58 L110.75,158.74 L112.31,157.89 L113.88,157.04 L115.44,156.19 L117.00,155.34 L118.56,154.49 L120.12,153.64 L121.69,152.79 L123.25,151.94 L124.81,151.10 L126.38,150.25 L127.94,149.40 L129.50,148.55 L131.06,147.70 L132.62,146.85 L134.19,146.00 L135.75,145.16 L137.31,144.31 L138.88,143.46 L140.44,142.61 L142.00,141.76 L143.56,140.91 L145.12,140.06 L146.69,139.21 L148.25,138.37 L149.81,137.52 L151.38,136.67 L152.94,135.82 L154.50,134.97 L156.06,134.12 L157.62,133.27 L159.19,132.42 L160.75,131.57 L162.31,130.73 L163.88,129.88 L165.44,129.03 L167.00,128.18 L168.56,127.33 L170.12,126.48 L171.69,125.63 L173.25,124.78 L174.81,123.94 L176.38,123.09 L177.94,122.24 L179.50,121.39 L181.06,120.54 L182.62,119.69 L184.19,118.84 L185.75,118.00 L187.31,117.15 L188.88,116.30 L190.44,115.45 L192.00,114.60 L193.56,113.75 L195.12,112.90 L196.69,112.05 L198.25,111.21 L199.81,110.36 L201.38,109.51 L202.94,108.66 L204.50,107.81 L206.06,106.96 L207.62,106.11 L209.19,105.26 L210.75,104.42 L212.31,103.57 L213.88,102.72 L215.44,101.87 L217.00,101.02 L218.56,100.17 L220.12,99.32 L221.69,98.47 L223.25,97.63 L224.81,96.78 L226.38,95.93 L227.94,95.08 L229.50,94.23 L231.06,93.38 L232.62,92.53 L234.19,91.68 L235.75,90.84 L237.31,89.99 L238.88,89.14 L240.44,88.29 L242.00,87.44 L243.56,86.59 L245.12,85.74 L246.69,84.89 L248.25,84.05 L249.81,83.20 L251.38,82.35 L252.94,81.50 L254.50,80.65 L256.06,79.80 L257.62,78.95 L259.19,78.10 L260.75,77.25 L262.31,76.41 L263.88,75.56 L265.44,74.71 L267.00,73.86 L268.56,73.01 L270.12,72.16 L271.69,71.31 L273.25,70.46 L274.81,69.62 L276.38,68.77 L277.94,67.92 L279.50,67.07 L281.06,66.22 L282.62,65.37 L284.19,64.52 L285.75,63.67 L287.31,62.83 L288.88,61.98 L290.44,61.13 L292.00,60.28"/>
<circle class="fig-point" cx="42.00" cy="211.60" r="3"/>
<circle class="fig-point" cx="67.00" cy="174.74" r="3"/>
<circle class="fig-point" cx="92.00" cy="158.25" r="3"/>
<circle class="fig-point" cx="117.00" cy="172.80" r="3"/>
<circle class="fig-point" cx="142.00" cy="138.85" r="3"/>
<circle class="fig-point" cx="167.00" cy="120.42" r="3"/>
<circle class="fig-point" cx="192.00" cy="126.24" r="3"/>
<circle class="fig-point" cx="217.00" cy="85.50" r="3"/>
<circle class="fig-point" cx="242.00" cy="85.50" r="3"/>
<circle class="fig-point" cx="267.00" cy="78.71" r="3"/>
<circle class="fig-point" cx="292.00" cy="52.52" r="3"/>
<text class="fig-label-em" x="167.00" y="20" text-anchor="middle">Positive linear association</text>
<path class="fig-axis" d="M380.0,37.0 V231.0 H630.0"/>
<path class="fig-axis" d="M380.0,231.0 v5"/>
<text class="fig-label" x="380.0" y="249.0" text-anchor="middle">0</text>
<path class="fig-axis" d="M505.0,231.0 v5"/>
<text class="fig-label" x="505.0" y="249.0" text-anchor="middle">5</text>
<path class="fig-axis" d="M630.0,231.0 v5"/>
<text class="fig-label" x="630.0" y="249.0" text-anchor="middle">10</text>
<path class="fig-axis" d="M375.0,231.0 h5"/>
<text class="fig-label" x="371.0" y="234.0" text-anchor="end">0</text>
<path class="fig-axis" d="M375.0,134.0 h5"/>
<text class="fig-label" x="371.0" y="137.0" text-anchor="end">5</text>
<path class="fig-axis" d="M375.0,37.0 h5"/>
<text class="fig-label" x="371.0" y="40.0" text-anchor="end">10</text>
<text class="fig-label" x="505.0" y="268.0" text-anchor="middle">x</text>
<text class="fig-label" x="380.0" y="28.0">y</text>
<path class="fig-curve" d="M380.00,60.28 L381.56,61.13 L383.12,61.98 L384.69,62.83 L386.25,63.67 L387.81,64.52 L389.38,65.37 L390.94,66.22 L392.50,67.07 L394.06,67.92 L395.62,68.77 L397.19,69.62 L398.75,70.46 L400.31,71.31 L401.88,72.16 L403.44,73.01 L405.00,73.86 L406.56,74.71 L408.12,75.56 L409.69,76.41 L411.25,77.25 L412.81,78.10 L414.38,78.95 L415.94,79.80 L417.50,80.65 L419.06,81.50 L420.62,82.35 L422.19,83.20 L423.75,84.04 L425.31,84.89 L426.88,85.74 L428.44,86.59 L430.00,87.44 L431.56,88.29 L433.12,89.14 L434.69,89.99 L436.25,90.83 L437.81,91.68 L439.38,92.53 L440.94,93.38 L442.50,94.23 L444.06,95.08 L445.62,95.93 L447.19,96.78 L448.75,97.62 L450.31,98.47 L451.88,99.32 L453.44,100.17 L455.00,101.02 L456.56,101.87 L458.12,102.72 L459.69,103.57 L461.25,104.41 L462.81,105.26 L464.38,106.11 L465.94,106.96 L467.50,107.81 L469.06,108.66 L470.62,109.51 L472.19,110.36 L473.75,111.20 L475.31,112.05 L476.88,112.90 L478.44,113.75 L480.00,114.60 L481.56,115.45 L483.12,116.30 L484.69,117.15 L486.25,117.99 L487.81,118.84 L489.38,119.69 L490.94,120.54 L492.50,121.39 L494.06,122.24 L495.62,123.09 L497.19,123.94 L498.75,124.78 L500.31,125.63 L501.88,126.48 L503.44,127.33 L505.00,128.18 L506.56,129.03 L508.12,129.88 L509.69,130.73 L511.25,131.57 L512.81,132.42 L514.38,133.27 L515.94,134.12 L517.50,134.97 L519.06,135.82 L520.62,136.67 L522.19,137.52 L523.75,138.36 L525.31,139.21 L526.88,140.06 L528.44,140.91 L530.00,141.76 L531.56,142.61 L533.12,143.46 L534.69,144.31 L536.25,145.16 L537.81,146.00 L539.38,146.85 L540.94,147.70 L542.50,148.55 L544.06,149.40 L545.62,150.25 L547.19,151.10 L548.75,151.94 L550.31,152.79 L551.88,153.64 L553.44,154.49 L555.00,155.34 L556.56,156.19 L558.12,157.04 L559.69,157.89 L561.25,158.73 L562.81,159.58 L564.38,160.43 L565.94,161.28 L567.50,162.13 L569.06,162.98 L570.62,163.83 L572.19,164.68 L573.75,165.52 L575.31,166.37 L576.88,167.22 L578.44,168.07 L580.00,168.92 L581.56,169.77 L583.12,170.62 L584.69,171.47 L586.25,172.31 L587.81,173.16 L589.38,174.01 L590.94,174.86 L592.50,175.71 L594.06,176.56 L595.62,177.41 L597.19,178.26 L598.75,179.10 L600.31,179.95 L601.88,180.80 L603.44,181.65 L605.00,182.50 L606.56,183.35 L608.12,184.20 L609.69,185.05 L611.25,185.89 L612.81,186.74 L614.38,187.59 L615.94,188.44 L617.50,189.29 L619.06,190.14 L620.62,190.99 L622.19,191.84 L623.75,192.68 L625.31,193.53 L626.88,194.38 L628.44,195.23 L630.00,196.08"/>
<circle class="fig-point" cx="380.00" cy="75.80" r="3"/>
<circle class="fig-point" cx="405.00" cy="66.10" r="3"/>
<circle class="fig-point" cx="430.00" cy="76.77" r="3"/>
<circle class="fig-point" cx="455.00" cy="118.48" r="3"/>
<circle class="fig-point" cx="480.00" cy="111.69" r="3"/>
<circle class="fig-point" cx="505.00" cy="120.42" r="3"/>
<circle class="fig-point" cx="530.00" cy="153.40" r="3"/>
<circle class="fig-point" cx="555.00" cy="139.82" r="3"/>
<circle class="fig-point" cx="580.00" cy="166.98" r="3"/>
<circle class="fig-point" cx="605.00" cy="187.35" r="3"/>
<circle class="fig-point" cx="630.00" cy="188.32" r="3"/>
<text class="fig-label-em" x="505.00" y="20" text-anchor="middle">Negative linear association</text>
</svg>
<figcaption>The same closeness to a straight line can give strong positive association on the left or strong negative association on the right.</figcaption>
</figure>

When a scatterplot appears on a multiple-choice exam, eliminate any description with the wrong direction first. Then ask whether the cloud is straight or curved; finally decide whether the scatter is close enough to call the relationship strong. Do not rely on a handful of unusual points or on whether the axes start at zero. Read the pattern across the full observed range.

### The instructor's road-sign scatterplot

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 680 315" width="680" height="315" role="img" aria-label="Driver age versus maximum sign-reading distance, downward cloud of points, with the instructor-reported correlation negative 0.793.">
<path class="fig-axis" d="M90.0,36.0 V246.0 H625.0"/>
<path class="fig-axis" d="M90.0,246.0 v5"/>
<text class="fig-label" x="90.0" y="264.0" text-anchor="middle">15</text>
<path class="fig-axis" d="M166.4,246.0 v5"/>
<text class="fig-label" x="166.4" y="264.0" text-anchor="middle">25</text>
<path class="fig-axis" d="M242.9,246.0 v5"/>
<text class="fig-label" x="242.9" y="264.0" text-anchor="middle">35</text>
<path class="fig-axis" d="M319.3,246.0 v5"/>
<text class="fig-label" x="319.3" y="264.0" text-anchor="middle">45</text>
<path class="fig-axis" d="M395.7,246.0 v5"/>
<text class="fig-label" x="395.7" y="264.0" text-anchor="middle">55</text>
<path class="fig-axis" d="M472.1,246.0 v5"/>
<text class="fig-label" x="472.1" y="264.0" text-anchor="middle">65</text>
<path class="fig-axis" d="M548.6,246.0 v5"/>
<text class="fig-label" x="548.6" y="264.0" text-anchor="middle">75</text>
<path class="fig-axis" d="M625.0,246.0 v5"/>
<text class="fig-label" x="625.0" y="264.0" text-anchor="middle">85</text>
<path class="fig-axis" d="M85.0,222.0 h5"/>
<text class="fig-label" x="81.0" y="225.0" text-anchor="end">300</text>
<path class="fig-axis" d="M85.0,162.0 h5"/>
<text class="fig-label" x="81.0" y="165.0" text-anchor="end">400</text>
<path class="fig-axis" d="M85.0,102.0 h5"/>
<text class="fig-label" x="81.0" y="105.0" text-anchor="end">500</text>
<path class="fig-axis" d="M85.0,42.0 h5"/>
<text class="fig-label" x="81.0" y="45.0" text-anchor="end">600</text>
<text class="fig-label" x="357.5" y="283.0" text-anchor="middle">Driver Age (years)</text>
<text class="fig-label" x="90.0" y="27.0">Max distance to read sign</text>
<circle class="fig-point" cx="105.29" cy="94.80" r="3"/>
<circle class="fig-point" cx="120.57" cy="51.00" r="3"/>
<circle class="fig-point" cx="135.86" cy="68.40" r="3"/>
<circle class="fig-point" cx="151.14" cy="108.00" r="3"/>
<circle class="fig-point" cx="151.14" cy="94.80" r="3"/>
<circle class="fig-point" cx="158.79" cy="67.20" r="3"/>
<circle class="fig-point" cx="174.07" cy="98.40" r="3"/>
<circle class="fig-point" cx="181.71" cy="91.20" r="3"/>
<circle class="fig-point" cx="189.36" cy="124.80" r="3"/>
<circle class="fig-point" cx="197.00" cy="96.00" r="3"/>
<circle class="fig-point" cx="204.64" cy="125.40" r="3"/>
<circle class="fig-point" cx="212.29" cy="151.20" r="3"/>
<circle class="fig-point" cx="242.86" cy="146.40" r="3"/>
<circle class="fig-point" cx="265.79" cy="157.20" r="3"/>
<circle class="fig-point" cx="296.36" cy="124.20" r="3"/>
<circle class="fig-point" cx="319.29" cy="128.40" r="3"/>
<circle class="fig-point" cx="342.21" cy="174.00" r="3"/>
<circle class="fig-point" cx="365.14" cy="120.00" r="3"/>
<circle class="fig-point" cx="395.71" cy="151.20" r="3"/>
<circle class="fig-point" cx="426.29" cy="127.80" r="3"/>
<circle class="fig-point" cx="449.21" cy="166.80" r="3"/>
<circle class="fig-point" cx="472.14" cy="192.00" r="3"/>
<circle class="fig-point" cx="479.79" cy="219.00" r="3"/>
<circle class="fig-point" cx="487.43" cy="150.00" r="3"/>
<circle class="fig-point" cx="502.71" cy="183.00" r="3"/>
<circle class="fig-point" cx="510.36" cy="209.40" r="3"/>
<circle class="fig-point" cx="525.64" cy="232.80" r="3"/>
<circle class="fig-point" cx="540.93" cy="233.40" r="3"/>
<circle class="fig-point" cx="548.57" cy="147.60" r="3"/>
<circle class="fig-point" cx="563.86" cy="182.40" r="3"/>
<circle class="fig-point" cx="586.79" cy="216.60" r="3"/>
<circle class="fig-point" cx="602.07" cy="185.40" r="3"/>
<text class="fig-label-em" x="400" y="26">Reported r = -0.793</text>
</svg>
<figcaption>In the instructor’s driver-age example, higher ages generally accompany shorter readable distances; the notes report $r=-0.793$.</figcaption>
</figure>

The plot in the Unit 6 notes places **Driver Age (years)** horizontally and **Max distance to read sign** vertically. It shows an unmistakably downward overall tendency. Points at some nearby ages have different distances, so it is not a perfect line. The instructor's page 3 prints $r=-0.793$ for these data. That numerical summary agrees with a fairly strong negative **linear** association, not a perfect one.

:::example[Example 6.1 — Driver age and readable distance]
The Unit 6 notes show a scatterplot of driver age on the x-axis and maximum distance to read a road sign on the y-axis. Describe the relationship using direction, form, and strength. Interpret the reported $r=-0.793$.

::::answer[Answer]
**Answer:** Strong negative, approximately linear association.

1. Move left to right. Larger ages generally line up with shorter maximum reading distances, so the direction is **negative**.
2. The points follow a rough descending band rather than a clear U-shape or circle. Thus **approximately linear** describes the form.
3. The band contains noticeable scatter, but the descending trend is consistent. Calling it **moderately strong to strong** is reasonable; the magnitude of the reported correlation is about eight-tenths.
4. This describes an **association** in the observed drivers. It does not prove that age, by itself, caused the difference in reading distance.

Check: the negative sign matches the downward orientation of the source plot.
::::
:::

### The instructor's revenue and satisfaction scatterplot

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 680 315" width="680" height="315" role="img" aria-label="Approximate reconstruction of the Exam 3 scatterplot showing increasing customer satisfaction index with increasing revenue.">
<path class="fig-axis" d="M81.0,38.0 V253.0 H621.0"/>
<path class="fig-axis" d="M81.0,253.0 v5"/>
<text class="fig-label" x="81.0" y="271.0" text-anchor="middle">0</text>
<path class="fig-axis" d="M158.1,253.0 v5"/>
<text class="fig-label" x="158.1" y="271.0" text-anchor="middle">1k</text>
<path class="fig-axis" d="M235.3,253.0 v5"/>
<text class="fig-label" x="235.3" y="271.0" text-anchor="middle">2k</text>
<path class="fig-axis" d="M312.4,253.0 v5"/>
<text class="fig-label" x="312.4" y="271.0" text-anchor="middle">3k</text>
<path class="fig-axis" d="M389.6,253.0 v5"/>
<text class="fig-label" x="389.6" y="271.0" text-anchor="middle">4k</text>
<path class="fig-axis" d="M466.7,253.0 v5"/>
<text class="fig-label" x="466.7" y="271.0" text-anchor="middle">5k</text>
<path class="fig-axis" d="M543.9,253.0 v5"/>
<text class="fig-label" x="543.9" y="271.0" text-anchor="middle">6k</text>
<path class="fig-axis" d="M621.0,253.0 v5"/>
<text class="fig-label" x="621.0" y="271.0" text-anchor="middle">7k</text>
<path class="fig-axis" d="M76.0,253.0 h5"/>
<text class="fig-label" x="72.0" y="256.0" text-anchor="end">0</text>
<path class="fig-axis" d="M76.0,210.0 h5"/>
<text class="fig-label" x="72.0" y="213.0" text-anchor="end">1</text>
<path class="fig-axis" d="M76.0,167.0 h5"/>
<text class="fig-label" x="72.0" y="170.0" text-anchor="end">2</text>
<path class="fig-axis" d="M76.0,124.0 h5"/>
<text class="fig-label" x="72.0" y="127.0" text-anchor="end">3</text>
<path class="fig-axis" d="M76.0,81.0 h5"/>
<text class="fig-label" x="72.0" y="84.0" text-anchor="end">4</text>
<path class="fig-axis" d="M76.0,38.0 h5"/>
<text class="fig-label" x="72.0" y="41.0" text-anchor="end">5</text>
<text class="fig-label" x="351.0" y="290.0" text-anchor="middle">Customer Revenue ($)</text>
<text class="fig-label" x="81.0" y="29.0">Customer Satisfaction Index</text>
<circle class="fig-point" cx="87.17" cy="253.00" r="2.8"/>
<circle class="fig-point" cx="93.34" cy="248.72" r="2.8"/>
<circle class="fig-point" cx="98.74" cy="248.88" r="2.8"/>
<circle class="fig-point" cx="104.91" cy="245.15" r="2.8"/>
<circle class="fig-point" cx="110.31" cy="243.54" r="2.8"/>
<circle class="fig-point" cx="114.94" cy="247.39" r="2.8"/>
<circle class="fig-point" cx="120.34" cy="246.44" r="2.8"/>
<circle class="fig-point" cx="125.74" cy="237.59" r="2.8"/>
<circle class="fig-point" cx="132.69" cy="240.99" r="2.8"/>
<circle class="fig-point" cx="138.86" cy="239.60" r="2.8"/>
<circle class="fig-point" cx="145.03" cy="231.11" r="2.8"/>
<circle class="fig-point" cx="150.43" cy="234.43" r="2.8"/>
<circle class="fig-point" cx="155.06" cy="229.92" r="2.8"/>
<circle class="fig-point" cx="161.23" cy="231.55" r="2.8"/>
<circle class="fig-point" cx="166.63" cy="228.67" r="2.8"/>
<circle class="fig-point" cx="173.57" cy="232.77" r="2.8"/>
<circle class="fig-point" cx="181.29" cy="212.89" r="2.8"/>
<circle class="fig-point" cx="185.14" cy="203.25" r="2.8"/>
<circle class="fig-point" cx="188.23" cy="213.83" r="2.8"/>
<circle class="fig-point" cx="192.86" cy="204.39" r="2.8"/>
<circle class="fig-point" cx="197.49" cy="204.86" r="2.8"/>
<circle class="fig-point" cx="203.66" cy="223.17" r="2.8"/>
<circle class="fig-point" cx="207.51" cy="197.68" r="2.8"/>
<circle class="fig-point" cx="212.91" cy="201.17" r="2.8"/>
<circle class="fig-point" cx="218.31" cy="208.88" r="2.8"/>
<circle class="fig-point" cx="222.94" cy="216.24" r="2.8"/>
<circle class="fig-point" cx="227.57" cy="185.60" r="2.8"/>
<circle class="fig-point" cx="232.97" cy="196.85" r="2.8"/>
<circle class="fig-point" cx="239.14" cy="185.81" r="2.8"/>
<circle class="fig-point" cx="246.09" cy="177.40" r="2.8"/>
<circle class="fig-point" cx="250.71" cy="181.13" r="2.8"/>
<circle class="fig-point" cx="262.29" cy="103.80" r="2.8"/>
<circle class="fig-point" cx="267.69" cy="141.13" r="2.8"/>
<circle class="fig-point" cx="273.09" cy="112.33" r="2.8"/>
<circle class="fig-point" cx="277.71" cy="137.60" r="2.8"/>
<circle class="fig-point" cx="282.34" cy="102.77" r="2.8"/>
<circle class="fig-point" cx="285.43" cy="106.79" r="2.8"/>
<circle class="fig-point" cx="290.06" cy="162.24" r="2.8"/>
<circle class="fig-point" cx="293.91" cy="159.50" r="2.8"/>
<circle class="fig-point" cx="297.00" cy="153.75" r="2.8"/>
<circle class="fig-point" cx="300.86" cy="100.65" r="2.8"/>
<circle class="fig-point" cx="307.03" cy="138.20" r="2.8"/>
<circle class="fig-point" cx="310.89" cy="124.69" r="2.8"/>
<circle class="fig-point" cx="320.14" cy="123.40" r="2.8"/>
<circle class="fig-point" cx="333.26" cy="111.99" r="2.8"/>
<circle class="fig-point" cx="344.83" cy="114.83" r="2.8"/>
<circle class="fig-point" cx="354.86" cy="114.31" r="2.8"/>
<circle class="fig-point" cx="363.34" cy="102.64" r="2.8"/>
<circle class="fig-point" cx="373.37" cy="100.66" r="2.8"/>
<circle class="fig-point" cx="383.40" cy="85.03" r="2.8"/>
<circle class="fig-point" cx="393.43" cy="92.47" r="2.8"/>
<circle class="fig-point" cx="405.77" cy="79.48" r="2.8"/>
<circle class="fig-point" cx="432.77" cy="77.15" r="2.8"/>
<circle class="fig-point" cx="449.74" cy="68.02" r="2.8"/>
<circle class="fig-point" cx="475.97" cy="76.37" r="2.8"/>
<circle class="fig-point" cx="501.43" cy="92.89" r="2.8"/>
<circle class="fig-point" cx="516.86" cy="60.10" r="2.8"/>
<circle class="fig-point" cx="530.74" cy="52.89" r="2.8"/>
<circle class="fig-point" cx="544.63" cy="52.65" r="2.8"/>
<circle class="fig-point" cx="482.14" cy="50.90" r="2.8"/>
<circle class="fig-point" cx="505.29" cy="42.30" r="2.8"/>
<circle class="fig-point" cx="551.57" cy="57.35" r="2.8"/>
<circle class="fig-point" cx="443.57" cy="53.05" r="2.8"/>
<circle class="fig-point" cx="381.86" cy="76.70" r="2.8"/>
</svg>
<figcaption>The instructor’s Exam 3 scatterplot shows customer satisfaction generally rising with revenue, with visible scatter and some flattening at the upper end.</figcaption>
</figure>

The Exam 3 practice plot labels the horizontal axis **Customer Revenue** and the vertical axis **Customer Satisfaction Index**. The points rise as revenue grows, and most follow a fairly tight increasing band, though scatter exists, particularly in the middle. A sentence like “Customer revenue and customer satisfaction have a strong, positive, approximately linear association over the displayed range” covers direction, form, and strength. It is a statement about the chart, not a claim that spending money automatically makes a customer satisfied.

:::example[Example 6.2 — Exam 3 practice, Question 13]
Write one or two sentences to describe the correlation between the two variables on the scatterplot from the instructor's Exam 3 practice sheet: **Customer Revenue** on the horizontal axis and **Customer Satisfaction Index** on the vertical axis. Use the plotted points above.

::::answer[Answer]
**Answer:** Strong positive, approximately linear correlation.

1. Read the axes before interpreting dots: revenue is x and satisfaction index is y. The vertical values generally increase as the horizontal values increase.
2. Describe direction as **positive**, because higher-revenue customers tend also to have higher satisfaction indices.
3. Describe form as **roughly linear over most of the display**, with some scatter and possible flattening near the top of the bounded satisfaction scale.
4. Describe strength as **strong**, because the overall upward tendency is clear rather than overwhelmed by random scatter.

Check: a negative description would contradict the prominent upward trend. The graph alone does not demonstrate causation.
::::
:::

### Linear is not the same as related

A curved relationship can be extremely regular yet have little **linear** correlation. For example, the mathematical points on $y=x^2$ with both negative and positive x-values trace a U-shape. Knowing x helps predict y, but the increase on the right partly cancels the decrease on the left when a straight-line correlation is calculated. Therefore, “$r$ is near zero” means **little linear association**, not necessarily “no relationship of any kind.”

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 680 315" width="680" height="315" role="img" aria-label="Curved U-shaped scatter pattern following quadratic y equals zero point one nine times x squared plus zero point four five.">
<path class="fig-axis" d="M78.0,33.0 V252.0 H633.0"/>
<path class="fig-axis" d="M103.2,252.0 v5"/>
<text class="fig-label" x="103.2" y="270.0" text-anchor="middle">-5</text>
<path class="fig-axis" d="M204.1,252.0 v5"/>
<text class="fig-label" x="204.1" y="270.0" text-anchor="middle">-3</text>
<path class="fig-axis" d="M355.5,252.0 v5"/>
<text class="fig-label" x="355.5" y="270.0" text-anchor="middle">0</text>
<path class="fig-axis" d="M506.9,252.0 v5"/>
<text class="fig-label" x="506.9" y="270.0" text-anchor="middle">3</text>
<path class="fig-axis" d="M607.8,252.0 v5"/>
<text class="fig-label" x="607.8" y="270.0" text-anchor="middle">5</text>
<path class="fig-axis" d="M73.0,252.0 h5"/>
<text class="fig-label" x="69.0" y="255.0" text-anchor="end">0</text>
<path class="fig-axis" d="M73.0,189.4 h5"/>
<text class="fig-label" x="69.0" y="192.4" text-anchor="end">2</text>
<path class="fig-axis" d="M73.0,126.9 h5"/>
<text class="fig-label" x="69.0" y="129.9" text-anchor="end">4</text>
<path class="fig-axis" d="M73.0,64.3 h5"/>
<text class="fig-label" x="69.0" y="67.3" text-anchor="end">6</text>
<text class="fig-label" x="355.5" y="289.0" text-anchor="middle">x</text>
<text class="fig-label" x="78.0" y="24.0">y</text>
<path class="fig-curve" d="M103.23,89.31 L105.33,91.78 L107.43,94.23 L109.53,96.65 L111.64,99.06 L113.74,101.44 L115.84,103.80 L117.94,106.15 L120.05,108.47 L122.15,110.77 L124.25,113.05 L126.35,115.31 L128.45,117.55 L130.56,119.77 L132.66,121.97 L134.76,124.14 L136.86,126.30 L138.97,128.44 L141.07,130.55 L143.17,132.65 L145.27,134.72 L147.38,136.78 L149.48,138.81 L151.58,140.82 L153.68,142.81 L155.78,144.78 L157.89,146.73 L159.99,148.66 L162.09,150.57 L164.19,152.46 L166.30,154.33 L168.40,156.18 L170.50,158.00 L172.60,159.81 L174.70,161.60 L176.81,163.36 L178.91,165.10 L181.01,166.83 L183.11,168.53 L185.22,170.21 L187.32,171.87 L189.42,173.51 L191.52,175.13 L193.62,176.73 L195.73,178.31 L197.83,179.87 L199.93,181.41 L202.03,182.93 L204.14,184.42 L206.24,185.90 L208.34,187.35 L210.44,188.79 L212.55,190.20 L214.65,191.60 L216.75,192.97 L218.85,194.32 L220.95,195.65 L223.06,196.96 L225.16,198.25 L227.26,199.52 L229.36,200.77 L231.47,202.00 L233.57,203.21 L235.67,204.39 L237.77,205.56 L239.88,206.70 L241.98,207.83 L244.08,208.93 L246.18,210.02 L248.28,211.08 L250.39,212.12 L252.49,213.14 L254.59,214.14 L256.69,215.12 L258.80,216.08 L260.90,217.02 L263.00,217.94 L265.10,218.84 L267.20,219.72 L269.31,220.57 L271.41,221.41 L273.51,222.22 L275.61,223.02 L277.72,223.79 L279.82,224.55 L281.92,225.28 L284.02,225.99 L286.12,226.68 L288.23,227.35 L290.33,228.00 L292.43,228.63 L294.53,229.24 L296.64,229.83 L298.74,230.40 L300.84,230.95 L302.94,231.47 L305.05,231.98 L307.15,232.46 L309.25,232.93 L311.35,233.37 L313.45,233.79 L315.56,234.20 L317.66,234.58 L319.76,234.94 L321.86,235.28 L323.97,235.60 L326.07,235.90 L328.17,236.18 L330.27,236.44 L332.38,236.67 L334.48,236.89 L336.58,237.09 L338.68,237.26 L340.78,237.42 L342.89,237.55 L344.99,237.66 L347.09,237.76 L349.19,237.83 L351.30,237.88 L353.40,237.91 L355.50,237.92 L357.60,237.91 L359.70,237.88 L361.81,237.83 L363.91,237.76 L366.01,237.66 L368.11,237.55 L370.22,237.42 L372.32,237.26 L374.42,237.09 L376.52,236.89 L378.62,236.67 L380.73,236.44 L382.83,236.18 L384.93,235.90 L387.03,235.60 L389.14,235.28 L391.24,234.94 L393.34,234.58 L395.44,234.20 L397.55,233.79 L399.65,233.37 L401.75,232.93 L403.85,232.46 L405.95,231.98 L408.06,231.47 L410.16,230.95 L412.26,230.40 L414.36,229.83 L416.47,229.24 L418.57,228.63 L420.67,228.00 L422.77,227.35 L424.88,226.68 L426.98,225.99 L429.08,225.28 L431.18,224.55 L433.28,223.79 L435.39,223.02 L437.49,222.22 L439.59,221.41 L441.69,220.57 L443.80,219.72 L445.90,218.84 L448.00,217.94 L450.10,217.02 L452.20,216.08 L454.31,215.12 L456.41,214.14 L458.51,213.14 L460.61,212.12 L462.72,211.08 L464.82,210.02 L466.92,208.93 L469.02,207.83 L471.12,206.70 L473.23,205.56 L475.33,204.39 L477.43,203.21 L479.53,202.00 L481.64,200.77 L483.74,199.52 L485.84,198.25 L487.94,196.96 L490.05,195.65 L492.15,194.32 L494.25,192.97 L496.35,191.60 L498.45,190.20 L500.56,188.79 L502.66,187.35 L504.76,185.90 L506.86,184.42 L508.97,182.93 L511.07,181.41 L513.17,179.87 L515.27,178.31 L517.38,176.73 L519.48,175.13 L521.58,173.51 L523.68,171.87 L525.78,170.21 L527.89,168.53 L529.99,166.83 L532.09,165.10 L534.19,163.36 L536.30,161.60 L538.40,159.81 L540.50,158.00 L542.60,156.18 L544.70,154.33 L546.81,152.46 L548.91,150.57 L551.01,148.66 L553.11,146.73 L555.22,144.78 L557.32,142.81 L559.42,140.82 L561.52,138.81 L563.62,136.78 L565.73,134.72 L567.83,132.65 L569.93,130.55 L572.03,128.44 L574.14,126.30 L576.24,124.14 L578.34,121.97 L580.44,119.77 L582.55,117.55 L584.65,115.31 L586.75,113.05 L588.85,110.77 L590.95,108.47 L593.06,106.15 L595.16,103.80 L597.26,101.44 L599.36,99.06 L601.47,96.65 L603.57,94.23 L605.67,91.78 L607.77,89.31"/>
<circle class="fig-point" cx="103.23" cy="84.00" r="3"/>
<circle class="fig-point" cx="153.68" cy="146.57" r="3"/>
<circle class="fig-point" cx="204.14" cy="177.85" r="3"/>
<circle class="fig-point" cx="254.59" cy="217.59" r="3"/>
<circle class="fig-point" cx="305.05" cy="229.47" r="3"/>
<circle class="fig-point" cx="355.50" cy="234.48" r="3"/>
<circle class="fig-point" cx="405.95" cy="235.42" r="3"/>
<circle class="fig-point" cx="456.41" cy="208.83" r="3"/>
<circle class="fig-point" cx="506.86" cy="186.61" r="3"/>
<circle class="fig-point" cx="557.32" cy="135.93" r="3"/>
<circle class="fig-point" cx="607.77" cy="93.38" r="3"/>
</svg>
<figcaption>A U-shaped relationship can be strong and predictable even though its overall straight-line correlation is close to zero.</figcaption>
</figure>

:::example[Example 6.3 — A curve with no overall line]
A scatterplot consists of points near $y=x^2$ for x-values equally spread on both sides of zero. Describe its form, and explain why saying “unrelated” would be a mistake.

::::answer[Answer]
**Answer:** Strong nonlinear U-shaped relationship; little overall linear direction.

1. Read from left to right. y first decreases toward the bottom of the U and then increases, so there is no single rising or falling direction across the entire range.
2. The points consistently follow a **curve**, which makes the nonlinear relationship strong, even though no single straight line captures both halves.
3. A linear correlation can be close to zero because the left and right halves contribute opposing trends.
4. The variables remain related through the curved pattern. Calling them independent or unrelated would discard information visible in the plot.

Check: try a line through the center. It misses the systematic U-shape.
::::
:::

:::callout-pitfall[Three errors in scatterplot descriptions]
Do not call an upward graph “strong” merely because the line would be steep; judge how closely points cluster. Do not say “negative correlation” just because some values of y are below zero; direction concerns whether y tends to fall as x grows. Do not conclude “no relationship” from a curved graph with small linear correlation. The exam asks for the pattern you **see**, not a causal story you imagine.
:::

### Practice: reading points and axes

:::problem[Problem 6.1 — Axis roles]{difficulty=easy}
A factory plots **Machine Age (years)** horizontally and **Repair Cost (dollars)** vertically. What does a single dot represent? Identify the explanatory and response variables.

::::solution[Solution]
**Answer:** One machine's age-and-cost pair; age explains, cost responds.

1. The horizontal axis is x, so machine age is the **explanatory** variable in the graph's design.
2. The vertical axis is y, so repair cost is the **response** variable.
3. A dot records both measurements from the same machine. It is not a separate age observation and cost observation, and it is not automatically an average.
4. Reading the axes this way lets us discuss how costs change across machine ages without claiming that the display establishes causation.

Check: one dot must have both an x-coordinate and a y-coordinate.
::::
:::

:::problem[Problem 6.2 — Moving up to the right]{difficulty=easy}
A scatterplot of hours of machine operation versus accumulated wear has points in a narrow band running upward from left to right. Describe direction, form, and strength.

::::solution[Solution]
**Answer:** Strong positive, approximately linear association.

1. As hours of operation increase, accumulated wear tends to increase. That gives a **positive** direction.
2. The description “narrow band” running upward indicates that a straight line is a useful summary, so the form is **approximately linear**.
3. Because the points remain close to that band, call the relationship **strong**, rather than weak or moderate.
4. This statement concerns the displayed machines. Whether operating hours are the sole cause of wear is a separate question.

Check: exchanging the words positive and negative would reverse the graph's direction.
::::
:::

:::problem[Problem 6.3 — Scatter without a trend]{difficulty=standard}
An engineer plots batch identification time against the measured width of each finished part. The points fill a roughly rectangular cloud, with neither a rising nor a falling band. How should the relationship be described?

::::solution[Solution]
**Answer:** No apparent direction and weak linear association.

1. Read the whole rectangle, rather than selecting two distant dots. There is no consistent change in measured width when the batch identification time grows.
2. Because the points do not cluster around a rising or descending line, a **strong linear** relationship is not evident.
3. Calling the pattern **little or no apparent linear association** is justified by this plot.
4. Avoid saying that all possible relationships have been disproved. The graph only covers these variables and observations, and it can hide structures that need a different view.

Check: drawing either an upward or downward line would leave broadly scattered points on both sides.
::::
:::

:::problem[Problem 6.4 — Negative trend with scatter]{difficulty=standard}
A plot of vehicle speed on the x-axis and remaining stopping distance available before a barrier on the y-axis shows a broadly downward, roughly straight band, with considerable scatter. What are its direction, form, and strength?

::::solution[Solution]
**Answer:** Negative, approximately linear, and moderate.

1. Moving right means higher vehicle speeds, while the plotted distance generally gets smaller. The direction is therefore **negative**.
2. The points appear along a descending straight band rather than a curve, so its form is **approximately linear**.
3. The phrase “considerable scatter” means the trend is not tight enough to call very strong. **Moderate** is an appropriate description.
4. The plot's definition of stopping distance matters: the remaining available distance is not necessarily the distance required to stop a vehicle.

Check: direction comes from the trend, not from whether a particular y-value is positive.
::::
:::

:::problem[Problem 6.5 — Strong shape, weak line]{difficulty=challenge}
A sensor follows $y=x^2$ for input values equally spaced on both sides of zero, with only slight measurement noise. A friend says the variables have no useful relationship because the overall trend does not slope upward or downward. Explain the mistake using direction, form, and strength.

::::solution[Solution]
**Answer:** Strong nonlinear relationship with no single linear direction.

1. Read the points from negative to positive x. Their y-values decrease toward the middle and increase again, which produces a U-shape rather than a single direction.
2. The form is **nonlinear** and the slight noise means the points follow it **strongly**.
3. A straight-line summary is poor because one half slopes down and the other slopes up.
4. The friend confused the absence of a consistent **linear trend** with the absence of a meaningful **relationship**.

Check: the equation supplies y from x exactly before measurement noise is added.
::::
:::

:::problem[Problem 6.6 — Reading the instructor's chart]{difficulty=standard}
Return to the Exam 3 revenue-versus-customer-satisfaction scatterplot above. A classmate writes, “Revenue and satisfaction are negatively related because some points lie below other points.” Identify the problem and give a better description.

::::solution[Solution]
**Answer:** Strong positive, roughly linear association.

1. Direction compares y **as x increases**, not the vertical placement of any two randomly selected points.
2. The plotted satisfaction scores tend to rise as customer revenue rises, so the direction is **positive**.
3. The overall form is a roughly increasing line, with some spread around it and a possible ceiling near the largest satisfaction values.
4. Its pattern is fairly tight, so “strong” is reasonable. The classmate mistook individual scatter for the direction of the overall relationship.

Check: the largest-revenue group mostly lies above the smallest-revenue group.
::::
:::

## 6.2 Covariance and the Correlation Coefficient

A scatterplot tells the story visually. Covariance starts turning the story into arithmetic. Instead of comparing two separate averages, compare each **pair's departures from its averages**. Imagine a pair whose x-value is above the average x and whose y-value is also above the average y. Both deviations are positive, so their product is positive. When both are below their averages, both deviations are negative, and the product is positive again. Those two kinds of pairs support an upward association.

If x is above its average while y is below its average, the product of deviations is negative; the same happens when x is below average and y is above average. Such pairs support a downward association. Sum these products, then divide by $n-1$ as with sample variance. That gives **sample covariance**. The instructor's covariance diagram also shows a pattern with zero covariance, including a circular pattern in which different directions cancel.

:::callout-intuition[Why multiplying deviations reveals direction]
The signs do the work. Positive times positive and negative times negative both produce a positive product: x and y move together relative to their averages. Positive times negative produces a negative product: they move in opposite directions. Covariance averages this evidence. Correlation then divides out the variables' spreads so miles and kilometers, or dollars and cents, can be compared using the same scale.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 680 318" width="680" height="318" role="img" aria-label="Four mini-plots of positive covariance, zero covariance, negative covariance, and a symmetric circular zero-covariance pattern.">
<text class="fig-label-em" x="181.5" y="23.0" text-anchor="middle">Positive covariance</text>
<path class="fig-axis" d="M54.0,79.0 h255.0 M181.5,38.0 v82.0"/>
<circle class="fig-point" cx="85.88" cy="109.65" r="2.5"/>
<circle class="fig-point" cx="85.88" cy="96.32" r="2.5"/>
<circle class="fig-point" cx="117.75" cy="101.65" r="2.5"/>
<circle class="fig-point" cx="117.75" cy="88.33" r="2.5"/>
<circle class="fig-point" cx="149.62" cy="93.66" r="2.5"/>
<circle class="fig-point" cx="149.62" cy="80.33" r="2.5"/>
<circle class="fig-point" cx="181.50" cy="85.66" r="2.5"/>
<circle class="fig-point" cx="181.50" cy="72.34" r="2.5"/>
<circle class="fig-point" cx="213.38" cy="77.67" r="2.5"/>
<circle class="fig-point" cx="213.38" cy="64.34" r="2.5"/>
<circle class="fig-point" cx="245.25" cy="69.67" r="2.5"/>
<circle class="fig-point" cx="245.25" cy="56.35" r="2.5"/>
<circle class="fig-point" cx="277.12" cy="61.68" r="2.5"/>
<circle class="fig-point" cx="277.12" cy="48.35" r="2.5"/>
<text class="fig-label-em" x="516.5" y="23.0" text-anchor="middle">Zero covariance</text>
<path class="fig-axis" d="M389.0,79.0 h255.0 M516.5,38.0 v82.0"/>
<circle class="fig-point" cx="436.81" cy="104.62" r="2.5"/>
<circle class="fig-point" cx="436.81" cy="79.00" r="2.5"/>
<circle class="fig-point" cx="436.81" cy="53.38" r="2.5"/>
<circle class="fig-point" cx="516.50" cy="104.62" r="2.5"/>
<circle class="fig-point" cx="516.50" cy="79.00" r="2.5"/>
<circle class="fig-point" cx="516.50" cy="53.38" r="2.5"/>
<circle class="fig-point" cx="596.19" cy="104.62" r="2.5"/>
<circle class="fig-point" cx="596.19" cy="79.00" r="2.5"/>
<circle class="fig-point" cx="596.19" cy="53.38" r="2.5"/>
<text class="fig-label-em" x="181.5" y="162.0" text-anchor="middle">Negative covariance</text>
<path class="fig-axis" d="M54.0,218.0 h255.0 M181.5,177.0 v82.0"/>
<circle class="fig-point" cx="85.88" cy="200.68" r="2.5"/>
<circle class="fig-point" cx="85.88" cy="187.35" r="2.5"/>
<circle class="fig-point" cx="117.75" cy="208.67" r="2.5"/>
<circle class="fig-point" cx="117.75" cy="195.35" r="2.5"/>
<circle class="fig-point" cx="149.62" cy="216.67" r="2.5"/>
<circle class="fig-point" cx="149.62" cy="203.34" r="2.5"/>
<circle class="fig-point" cx="181.50" cy="224.66" r="2.5"/>
<circle class="fig-point" cx="181.50" cy="211.34" r="2.5"/>
<circle class="fig-point" cx="213.38" cy="232.66" r="2.5"/>
<circle class="fig-point" cx="213.38" cy="219.33" r="2.5"/>
<circle class="fig-point" cx="245.25" cy="240.65" r="2.5"/>
<circle class="fig-point" cx="245.25" cy="227.33" r="2.5"/>
<circle class="fig-point" cx="277.12" cy="248.65" r="2.5"/>
<circle class="fig-point" cx="277.12" cy="235.32" r="2.5"/>
<text class="fig-label-em" x="516.5" y="162.0" text-anchor="middle">Zero covariance, circular</text>
<path class="fig-axis" d="M389.0,218.0 h255.0 M516.5,177.0 v82.0"/>
<path class="fig-guide" d="M543.66,218.00 L543.65,217.29 L543.62,216.58 L543.58,215.87 L543.51,215.16 L543.43,214.45 L543.33,213.75 L543.21,213.05 L543.07,212.35 L542.91,211.66 L542.73,210.97 L542.54,210.29 L542.33,209.61 L542.10,208.93 L541.86,208.27 L541.59,207.61 L541.31,206.95 L541.01,206.31 L540.70,205.67 L540.37,205.04 L540.02,204.42 L539.66,203.81 L539.28,203.21 L538.88,202.61 L538.47,202.03 L538.05,201.46 L537.61,200.91 L537.15,200.36 L536.68,199.82 L536.20,199.30 L535.71,198.79 L535.20,198.30 L534.67,197.81 L534.14,197.35 L533.59,196.89 L533.03,196.45 L532.46,196.03 L531.88,195.61 L531.29,195.22 L530.69,194.84 L530.08,194.48 L529.46,194.13 L528.83,193.80 L528.19,193.48 L527.55,193.19 L526.89,192.91 L526.23,192.64 L525.57,192.40 L524.89,192.17 L524.21,191.96 L523.53,191.76 L522.84,191.59 L522.15,191.43 L521.45,191.29 L520.75,191.17 L520.05,191.07 L519.34,190.99 L518.63,190.92 L517.92,190.87 L517.21,190.85 L516.50,190.84 L515.79,190.85 L515.08,190.87 L514.37,190.92 L513.66,190.99 L512.95,191.07 L512.25,191.17 L511.55,191.29 L510.85,191.43 L510.16,191.59 L509.47,191.76 L508.79,191.96 L508.11,192.17 L507.43,192.40 L506.77,192.64 L506.11,192.91 L505.45,193.19 L504.81,193.48 L504.17,193.80 L503.54,194.13 L502.92,194.48 L502.31,194.84 L501.71,195.22 L501.12,195.61 L500.54,196.03 L499.97,196.45 L499.41,196.89 L498.86,197.35 L498.33,197.81 L497.80,198.30 L497.29,198.79 L496.80,199.30 L496.32,199.82 L495.85,200.36 L495.39,200.91 L494.95,201.46 L494.53,202.03 L494.12,202.61 L493.72,203.21 L493.34,203.81 L492.98,204.42 L492.63,205.04 L492.30,205.67 L491.99,206.31 L491.69,206.95 L491.41,207.61 L491.14,208.27 L490.90,208.93 L490.67,209.61 L490.46,210.29 L490.27,210.97 L490.09,211.66 L489.93,212.35 L489.79,213.05 L489.67,213.75 L489.57,214.45 L489.49,215.16 L489.42,215.87 L489.38,216.58 L489.35,217.29 L489.34,218.00 L489.35,218.71 L489.38,219.42 L489.42,220.13 L489.49,220.84 L489.57,221.55 L489.67,222.25 L489.79,222.95 L489.93,223.65 L490.09,224.34 L490.27,225.03 L490.46,225.71 L490.67,226.39 L490.90,227.07 L491.14,227.73 L491.41,228.39 L491.69,229.05 L491.99,229.69 L492.30,230.33 L492.63,230.96 L492.98,231.58 L493.34,232.19 L493.72,232.79 L494.12,233.39 L494.53,233.97 L494.95,234.54 L495.39,235.09 L495.85,235.64 L496.32,236.18 L496.80,236.70 L497.29,237.21 L497.80,237.70 L498.33,238.19 L498.86,238.65 L499.41,239.11 L499.97,239.55 L500.54,239.97 L501.12,240.39 L501.71,240.78 L502.31,241.16 L502.92,241.52 L503.54,241.87 L504.17,242.20 L504.81,242.52 L505.45,242.81 L506.11,243.09 L506.77,243.36 L507.43,243.60 L508.11,243.83 L508.79,244.04 L509.47,244.24 L510.16,244.41 L510.85,244.57 L511.55,244.71 L512.25,244.83 L512.95,244.93 L513.66,245.01 L514.37,245.08 L515.08,245.13 L515.79,245.15 L516.50,245.16 L517.21,245.15 L517.92,245.13 L518.63,245.08 L519.34,245.01 L520.05,244.93 L520.75,244.83 L521.45,244.71 L522.15,244.57 L522.84,244.41 L523.53,244.24 L524.21,244.04 L524.89,243.83 L525.57,243.60 L526.23,243.36 L526.89,243.09 L527.55,242.81 L528.19,242.52 L528.83,242.20 L529.46,241.87 L530.08,241.52 L530.69,241.16 L531.29,240.78 L531.88,240.39 L532.46,239.97 L533.03,239.55 L533.59,239.11 L534.14,238.65 L534.67,238.19 L535.20,237.70 L535.71,237.21 L536.20,236.70 L536.68,236.18 L537.15,235.64 L537.61,235.09 L538.05,234.54 L538.47,233.97 L538.88,233.39 L539.28,232.79 L539.66,232.19 L540.02,231.58 L540.37,230.96 L540.70,230.33 L541.01,229.69 L541.31,229.05 L541.59,228.39 L541.86,227.73 L542.10,227.07 L542.33,226.39 L542.54,225.71 L542.73,225.03 L542.91,224.34 L543.07,223.65 L543.21,222.95 L543.33,222.25 L543.43,221.55 L543.51,220.84 L543.58,220.13 L543.62,219.42 L543.65,218.71 L543.66,218.00"/>
<circle class="fig-point" cx="543.66" cy="218.00" r="2.5"/>
<circle class="fig-point" cx="540.02" cy="204.42" r="2.5"/>
<circle class="fig-point" cx="530.08" cy="194.48" r="2.5"/>
<circle class="fig-point" cx="516.50" cy="190.84" r="2.5"/>
<circle class="fig-point" cx="502.92" cy="194.48" r="2.5"/>
<circle class="fig-point" cx="492.98" cy="204.42" r="2.5"/>
<circle class="fig-point" cx="489.34" cy="218.00" r="2.5"/>
<circle class="fig-point" cx="492.98" cy="231.58" r="2.5"/>
<circle class="fig-point" cx="502.92" cy="241.52" r="2.5"/>
<circle class="fig-point" cx="516.50" cy="245.16" r="2.5"/>
<circle class="fig-point" cx="530.08" cy="241.52" r="2.5"/>
<circle class="fig-point" cx="540.02" cy="231.58" r="2.5"/>
</svg>
<figcaption>The sign of covariance follows an upward or downward linear tendency; a grid or symmetric circle can have zero covariance despite visible structure.</figcaption>
</figure>

:::definition[Definition 6.3 — Sample covariance]
For $n$ paired observations $(x_i,y_i)$, the sample covariance in the instructor's notation is

$$
\operatorname{Cov}(x,y)=\frac{\sum_{i=1}^{n}(x_i-\bar{x})(y_i-\bar{y})}{n-1}.
$$

Positive covariance means an overall upward **linear** tendency; negative covariance means a downward one; zero covariance means the positive and negative contributions cancel. Its units are the product of the units of x and y. **This formula is not on the Final sheet or the Exam 3 sheet.** It is constructed by multiplying each pair's deviations and dividing their sum by $n-1$.
:::

### Covariance is not yet a universal strength scale

The problem with covariance is its units. If x is measured in meters and y in kilograms, the covariance is measured in meter-kilograms. Change meters to centimeters and the covariance becomes one hundred times as large even though the actual physical relationship has not changed. A large covariance therefore does not by itself mean a stronger association than a small covariance from a different pair of variables.

To fix this, use the standard deviation of each variable to express departures in **standard-deviation units**. A standardized x-deviation is $(x-\bar{x})/s_x$; a standardized y-deviation is $(y-\bar{y})/s_y$. Each has no units. Multiply them for each pair and average over $n-1$. The result, the sample correlation coefficient $r$, is dimensionless and always lies from $-1$ to $1$, inclusive, provided both sample standard deviations are nonzero.

:::definition[Definition 6.4 — Sample correlation coefficient]
The instructor gives the standardized-deviation formula

$$
r=\frac{\displaystyle\sum_{i=1}^{n}\left(\frac{x_i-\bar{x}}{s_x}\right)\left(\frac{y_i-\bar{y}}{s_y}\right)}{n-1},
$$

and the equivalent covariance formula

$$
r=\frac{\operatorname{Cov}(x,y)}{\sqrt{s_x^2s_y^2}}=\frac{\operatorname{Cov}(x,y)}{s_xs_y},
$$

where

$$
s_x^2=\frac{\sum_{i=1}^{n}(x_i-\bar{x})^2}{n-1},\qquad
s_y^2=\frac{\sum_{i=1}^{n}(y_i-\bar{y})^2}{n-1}.
$$

The **sample-variance pattern** is on the Final sheet, page 1, under $s^2$; apply it once to x and once to y. **Neither formula for $r$, nor covariance, is on either equation sheet.** The intuitive reason for division by $s_xs_y$ is to remove units and put every relationship on the common scale $[-1,1]$.
:::

:::theorem[Theorem 6.1 — Reading $r$ correctly]
For paired quantitative data with nonzero sample standard deviations, $-1\le r\le 1$. The **sign** of $r$ gives the direction of the linear association; the **magnitude** $|r|$ measures linear strength. Values near $1$ indicate a strong positive linear association, values near $-1$ a strong negative linear association, and values near zero a weak linear association. A value of exactly $1$ or $-1$ means the observed points fall on a straight line with the indicated direction.
:::

If an instructor asks whether $r=-0.89$ is “weaker” than $r=+0.50$, the answer is **no**. Negative is not a weakness score. The first relationship is stronger in magnitude because $0.89$ is larger than $0.50$; it just points downward. Avoid inventing an official cutoff, such as declaring every value above a fixed decimal “strong.” The notes do not supply numerical cutoff categories. Use sensible language consistent with the plot and the context.

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 680 315" width="680" height="315" role="img" aria-label="Side-by-side scatterplots with the same upward guideline but different amounts of vertical scatter.">
<path class="fig-axis" d="M48.0,36.0 V246.0 H308.0"/>
<text class="fig-label" x="178.0" y="283.0" text-anchor="middle">x</text>
<text class="fig-label" x="48.0" y="27.0">y</text>
<text class="fig-label-em" x="178.0" y="20" text-anchor="middle">Stronger linear trend</text>
<path class="fig-guide" d="M48.00,204.00 L50.17,202.95 L52.33,201.90 L54.50,200.85 L56.67,199.80 L58.83,198.75 L61.00,197.70 L63.17,196.65 L65.33,195.60 L67.50,194.55 L69.67,193.50 L71.83,192.45 L74.00,191.40 L76.17,190.35 L78.33,189.30 L80.50,188.25 L82.67,187.20 L84.83,186.15 L87.00,185.10 L89.17,184.05 L91.33,183.00 L93.50,181.95 L95.67,180.90 L97.83,179.85 L100.00,178.80 L102.17,177.75 L104.33,176.70 L106.50,175.65 L108.67,174.60 L110.83,173.55 L113.00,172.50 L115.17,171.45 L117.33,170.40 L119.50,169.35 L121.67,168.30 L123.83,167.25 L126.00,166.20 L128.17,165.15 L130.33,164.10 L132.50,163.05 L134.67,162.00 L136.83,160.95 L139.00,159.90 L141.17,158.85 L143.33,157.80 L145.50,156.75 L147.67,155.70 L149.83,154.65 L152.00,153.60 L154.17,152.55 L156.33,151.50 L158.50,150.45 L160.67,149.40 L162.83,148.35 L165.00,147.30 L167.17,146.25 L169.33,145.20 L171.50,144.15 L173.67,143.10 L175.83,142.05 L178.00,141.00 L180.17,139.95 L182.33,138.90 L184.50,137.85 L186.67,136.80 L188.83,135.75 L191.00,134.70 L193.17,133.65 L195.33,132.60 L197.50,131.55 L199.67,130.50 L201.83,129.45 L204.00,128.40 L206.17,127.35 L208.33,126.30 L210.50,125.25 L212.67,124.20 L214.83,123.15 L217.00,122.10 L219.17,121.05 L221.33,120.00 L223.50,118.95 L225.67,117.90 L227.83,116.85 L230.00,115.80 L232.17,114.75 L234.33,113.70 L236.50,112.65 L238.67,111.60 L240.83,110.55 L243.00,109.50 L245.17,108.45 L247.33,107.40 L249.50,106.35 L251.67,105.30 L253.83,104.25 L256.00,103.20 L258.17,102.15 L260.33,101.10 L262.50,100.05 L264.67,99.00 L266.83,97.95 L269.00,96.90 L271.17,95.85 L273.33,94.80 L275.50,93.75 L277.67,92.70 L279.83,91.65 L282.00,90.60 L284.17,89.55 L286.33,88.50 L288.50,87.45 L290.67,86.40 L292.83,85.35 L295.00,84.30 L297.17,83.25 L299.33,82.20 L301.50,81.15 L303.67,80.10 L305.83,79.05 L308.00,78.00"/>
<circle class="fig-point" cx="53.20" cy="207.72" r="3"/>
<circle class="fig-point" cx="67.73" cy="192.01" r="3"/>
<circle class="fig-point" cx="82.26" cy="188.44" r="3"/>
<circle class="fig-point" cx="96.79" cy="175.51" r="3"/>
<circle class="fig-point" cx="111.32" cy="178.17" r="3"/>
<circle class="fig-point" cx="125.85" cy="160.38" r="3"/>
<circle class="fig-point" cx="140.38" cy="156.46" r="3"/>
<circle class="fig-point" cx="154.91" cy="154.96" r="3"/>
<circle class="fig-point" cx="169.44" cy="140.30" r="3"/>
<circle class="fig-point" cx="183.96" cy="139.15" r="3"/>
<circle class="fig-point" cx="198.49" cy="128.43" r="3"/>
<circle class="fig-point" cx="213.02" cy="129.57" r="3"/>
<circle class="fig-point" cx="227.55" cy="112.83" r="3"/>
<circle class="fig-point" cx="242.08" cy="108.21" r="3"/>
<circle class="fig-point" cx="256.61" cy="106.23" r="3"/>
<circle class="fig-point" cx="271.14" cy="92.12" r="3"/>
<circle class="fig-point" cx="285.67" cy="87.57" r="3"/>
<circle class="fig-point" cx="300.20" cy="83.51" r="3"/>
<path class="fig-axis" d="M388.0,36.0 V246.0 H648.0"/>
<text class="fig-label" x="518.0" y="283.0" text-anchor="middle">x</text>
<text class="fig-label" x="388.0" y="27.0">y</text>
<text class="fig-label-em" x="518.0" y="20" text-anchor="middle">Weaker linear trend</text>
<path class="fig-guide" d="M388.00,204.00 L390.17,202.95 L392.33,201.90 L394.50,200.85 L396.67,199.80 L398.83,198.75 L401.00,197.70 L403.17,196.65 L405.33,195.60 L407.50,194.55 L409.67,193.50 L411.83,192.45 L414.00,191.40 L416.17,190.35 L418.33,189.30 L420.50,188.25 L422.67,187.20 L424.83,186.15 L427.00,185.10 L429.17,184.05 L431.33,183.00 L433.50,181.95 L435.67,180.90 L437.83,179.85 L440.00,178.80 L442.17,177.75 L444.33,176.70 L446.50,175.65 L448.67,174.60 L450.83,173.55 L453.00,172.50 L455.17,171.45 L457.33,170.40 L459.50,169.35 L461.67,168.30 L463.83,167.25 L466.00,166.20 L468.17,165.15 L470.33,164.10 L472.50,163.05 L474.67,162.00 L476.83,160.95 L479.00,159.90 L481.17,158.85 L483.33,157.80 L485.50,156.75 L487.67,155.70 L489.83,154.65 L492.00,153.60 L494.17,152.55 L496.33,151.50 L498.50,150.45 L500.67,149.40 L502.83,148.35 L505.00,147.30 L507.17,146.25 L509.33,145.20 L511.50,144.15 L513.67,143.10 L515.83,142.05 L518.00,141.00 L520.17,139.95 L522.33,138.90 L524.50,137.85 L526.67,136.80 L528.83,135.75 L531.00,134.70 L533.17,133.65 L535.33,132.60 L537.50,131.55 L539.67,130.50 L541.83,129.45 L544.00,128.40 L546.17,127.35 L548.33,126.30 L550.50,125.25 L552.67,124.20 L554.83,123.15 L557.00,122.10 L559.17,121.05 L561.33,120.00 L563.50,118.95 L565.67,117.90 L567.83,116.85 L570.00,115.80 L572.17,114.75 L574.33,113.70 L576.50,112.65 L578.67,111.60 L580.83,110.55 L583.00,109.50 L585.17,108.45 L587.33,107.40 L589.50,106.35 L591.67,105.30 L593.83,104.25 L596.00,103.20 L598.17,102.15 L600.33,101.10 L602.50,100.05 L604.67,99.00 L606.83,97.95 L609.00,96.90 L611.17,95.85 L613.33,94.80 L615.50,93.75 L617.67,92.70 L619.83,91.65 L622.00,90.60 L624.17,89.55 L626.33,88.50 L628.50,87.45 L630.67,86.40 L632.83,85.35 L635.00,84.30 L637.17,83.25 L639.33,82.20 L641.50,81.15 L643.67,80.10 L645.83,79.05 L648.00,78.00"/>
<circle class="fig-point" cx="393.20" cy="253.46" r="3"/>
<circle class="fig-point" cx="407.73" cy="174.23" r="3"/>
<circle class="fig-point" cx="422.26" cy="196.06" r="3"/>
<circle class="fig-point" cx="436.79" cy="139.93" r="3"/>
<circle class="fig-point" cx="451.32" cy="213.74" r="3"/>
<circle class="fig-point" cx="465.85" cy="117.19" r="3"/>
<circle class="fig-point" cx="480.38" cy="136.13" r="3"/>
<circle class="fig-point" cx="494.91" cy="175.29" r="3"/>
<circle class="fig-point" cx="509.44" cy="104.73" r="3"/>
<circle class="fig-point" cx="523.96" cy="146.77" r="3"/>
<circle class="fig-point" cx="538.49" cy="109.12" r="3"/>
<circle class="fig-point" cx="553.02" cy="170.23" r="3"/>
<circle class="fig-point" cx="567.55" cy="82.34" r="3"/>
<circle class="fig-point" cx="582.08" cy="95.51" r="3"/>
<circle class="fig-point" cx="596.61" cy="130.62" r="3"/>
<circle class="fig-point" cx="611.14" cy="64.68" r="3"/>
<circle class="fig-point" cx="625.67" cy="78.43" r="3"/>
<circle class="fig-point" cx="640.20" cy="96.22" r="3"/>
</svg>
<figcaption>Strength measures closeness to the straight-line pattern: the left cloud follows it more tightly than the right cloud.</figcaption>
</figure>

### One complete calculation from paired data

The arithmetic is the same manageable sequence every time. Find two means. Subtract them to get paired deviations. Multiply deviations for covariance. Square deviations separately for x and y to get sample variances. Divide covariance by the product of the standard deviations for $r$. Keep the products visible so you can check a misplaced minus sign on a TI-30X IIS.

:::example[Example 6.4 — Compute sample covariance]
Compute the **sample covariance** for these paired measurements. Data: $x=(1,2,3,4);\ y=(2,3,5,4)$. Each coordinate in x is paired with the coordinate in the same position in y.

::::answer[Answer]
**Answer:** 1.333.

1. Calculate the means: $\bar{x}=(1+2+3+4)/4=2.5$ and $\bar{y}=(2+3+5+4)/4=3.5$.
2. List deviations in pair order: x has $-1.5,-0.5,0.5,1.5$; y has $-1.5,-0.5,1.5,0.5$.
3. Multiply the matching deviations and **write the full sum**:

   $$(-1.5)(-1.5)+(-0.5)(-0.5)+(0.5)(1.5)+(1.5)(0.5)=2.25+0.25+0.75+0.75=4.$$

4. Divide by $n-1=3$: $\operatorname{Cov}(x,y)=4/3=1.333\ldots$. On the TI-30X IIS, enter `4 ÷ 3`; the display is approximately `1.333333333`.
5. The positive covariance says larger x-values tend to appear with larger y-values in these four observed pairs.

Check: both variables have nonzero spread, and more paired deviation products are positive than negative.
::::
:::

:::example[Example 6.5 — Compute $r$ from covariance]
Calculate the **sample correlation coefficient $r$** for the same measurements using the covariance method. Data: $x=(1,2,3,4);\ y=(2,3,5,4)$.

::::answer[Answer]
**Answer:** 0.800.

1. Compute the means again: $\bar{x}=2.5$, $\bar{y}=3.5$. From the paired deviations, the covariance numerator is $2.25+0.25+0.75+0.75=4$, so covariance is $4/3$.
2. Find sample variance in x, using the Final sheet's page 1 pattern: $s_x^2=[(-1.5)^2+(-0.5)^2+(0.5)^2+(1.5)^2]/3=(2.25+0.25+0.25+2.25)/3=5/3$.
3. Likewise $s_y^2=[(-1.5)^2+(-0.5)^2+(1.5)^2+(0.5)^2]/3=(2.25+0.25+2.25+0.25)/3=5/3$.
4. Standardize the covariance: $r=(4/3)/\sqrt{(5/3)(5/3)}=(4/3)/(5/3)=4/5=0.800$. Enter `4 ÷ 5` to confirm the displayed value `0.8`.
5. In these observations, x and y have a relatively strong **positive linear** association, without implying that x causes y.

Check: $r$ lies between $-1$ and $1$ and has the same sign as covariance.
::::
:::

:::example[Example 6.6 — Perfect negative linear correlation]
Calculate the **sample correlation coefficient $r$** from the standardized-deviation idea, for data that fall on a downward straight line. Data: $x=(1,2,3,4);\ y=(8,6,4,2)$.

::::answer[Answer]
**Answer:** -1.000.

1. The means are $\bar{x}=(1+2+3+4)/4=2.5$ and $\bar{y}=(8+6+4+2)/4=5$.
2. The paired deviations are x: $-1.5,-0.5,0.5,1.5$ and y: $3,1,-1,-3$.
3. Their products add to $(-1.5)(3)+(-0.5)(1)+(0.5)(-1)+(1.5)(-3)=-4.5-0.5-0.5-4.5=-10$. Covariance is $-10/3$.
4. The variances are $s_x^2=(2.25+0.25+0.25+2.25)/3=5/3$ and $s_y^2=(9+1+1+9)/3=20/3$.
5. Using the notes' standardized-deviation formula directly, $r=\big[(-1.5)(3)+(-0.5)(1)+(0.5)(-1)+(1.5)(-3)\big]/\big[3\sqrt{5/3}\sqrt{20/3}\big]=-10/[3(10/3)]=-1.000$. The covariance formula agrees: $(-10/3)/(10/3)=-1$. Each step of one unit in x corresponds to a drop of two units in y.

Check: every pair is on the straight line $y=10-2x$, so perfect negative correlation makes sense.
::::
:::

### How to interpret magnitude without being tricked

Suppose one pair has $r=0.25$ and another $r=-0.90$. The second has a much **stronger linear association** because $|-0.90|=0.90$ while $|0.25|=0.25$. One does not “lose” strength by being negative. A value of $r=0$ means no **sample linear correlation**; it does not rule out a curved pattern. A constant variable creates another edge case: its sample standard deviation is zero, so the formula divides by zero and $r$ is **undefined**, not zero.

Unit conversion gives a useful check. If we report every x-measurement in centimeters instead of meters, all deviations and the standard deviation in x scale by the same positive factor, so their standardized ratios stay unchanged. Thus $r$ is unchanged when either variable is rescaled by a **positive** unit conversion. This is why the coefficient can compare relationships measured in unlike units.

:::callout-pitfall[Four numerical traps]
A negative $r$ can be **very strong**. A large covariance can reflect large units rather than a strong relationship. $r$ measures **linear** form, so a beautiful U-shape can still have $r$ near zero. And when either variable never changes, $s_xs_y=0$: correlation is **undefined**. Do not replace that undefined value with zero to make a multiple-choice option fit.
:::

### Practice: signs and short calculations

:::problem[Problem 6.7 — Positive sample covariance]{difficulty=easy}
Compute the **sample covariance** of the paired data. Data: $x=(1,2,3);\ y=(2,4,6)$. Give your result to three decimals.

::::solution[Solution]
**Answer:** 2.000.

1. The means are $\bar{x}=(1+2+3)/3=2$ and $\bar{y}=(2+4+6)/3=4$.
2. The deviations are $(-1,0,1)$ for x and $(-2,0,2)$ for y.
3. The sum of matching deviation products is $(-1)(-2)+(0)(0)+(1)(2)=2+0+2=4$.
4. Divide by $n-1=2$: $\operatorname{Cov}(x,y)=4/2=2.000$.
5. A positive covariance agrees with the observation that y rises as x rises for these paired measurements.

Check: the three points lie on an increasing straight line.
::::
:::

:::problem[Problem 6.8 — A decreasing straight line]{difficulty=easy}
Calculate the **sample correlation coefficient $r$** for the paired data. Data: $x=(1,2,3);\ y=(3,2,1)$. Give your result to three decimals.

::::solution[Solution]
**Answer:** -1.000.

1. Both means are $2$. The deviations in x are $(-1,0,1)$, and those in y are $(1,0,-1)$.
2. The product sum is $(-1)(1)+(0)(0)+(1)(-1)=-2$, so covariance is $-2/2=-1$.
3. Each variance is $[1+0+1]/2=1$, giving both standard deviations as $1$.
4. The correlation is $r=-1/(1\cdot1)=-1.000$.
5. This indicates a **perfect negative linear** relationship in the observed pairs, not just a somewhat negative tendency.

Check: every point satisfies $y=4-x$.
::::
:::

:::problem[Problem 6.9 — Not every positive correlation is perfect]{difficulty=standard}
Calculate the **sample correlation coefficient $r$** for the paired measurements. Data: $x=(2,4,6);\ y=(1,3,2)$. Round to three decimals.

::::solution[Solution]
**Answer:** 0.500.

1. The averages are $\bar{x}=(2+4+6)/3=4$ and $\bar{y}=(1+3+2)/3=2$.
2. The deviations are $(-2,0,2)$ and $(-1,1,0)$. Their products sum to $(-2)(-1)+(0)(1)+(2)(0)=2$.
3. Sample covariance is $2/(3-1)=1$. Sample variances are $s_x^2=(4+0+4)/2=4$ and $s_y^2=(1+1+0)/2=1$.
4. Thus $r=1/\sqrt{4\cdot1}=1/2=0.500$.
5. This is a **positive but not perfect** linear association: the middle y-value is the largest rather than all y-values rising together.

Check: the sign is positive and the magnitude remains within the allowed interval.
::::
:::

:::problem[Problem 6.10 — Strength versus sign]{difficulty=standard}
Two engineering data sets give correlations $r_A=-0.82$ and $r_B=0.41$. Which has the stronger **linear** association? State the direction of each and explain why choosing the larger signed number would be wrong.

::::solution[Solution]
**Answer:** Data set A is stronger; A is negative and B is positive.

1. Read direction directly from the signs: A has a negative linear tendency, while B has a positive tendency.
2. Compare **absolute magnitudes**, not signed numbers. A's magnitude is eighty-two hundredths and B's is forty-one hundredths.
3. A therefore represents the stronger linear association, even though its signed coefficient is smaller.
4. Neither coefficient tells us whether one variable caused changes in the other. The comparison concerns only the strength of straight-line association.

Check: a more negative number can have a greater distance from zero.
::::
:::

:::problem[Problem 6.11 — Four-pair covariance]{difficulty=challenge}
Compute the **sample covariance** for the paired process measurements. Data: $x=(1,3,5,7);\ y=(4,7,8,11)$. Round to three decimals, showing the deviation products.

::::solution[Solution]
**Answer:** 7.333.

1. Compute averages: $\bar{x}=(1+3+5+7)/4=4$ and $\bar{y}=(4+7+8+11)/4=7.5$.
2. Write deviations: x gives $(-3,-1,1,3)$; y gives $(-3.5,-0.5,0.5,3.5)$.
3. Multiply in pair order: $(-3)(-3.5)+(-1)(-0.5)+(1)(0.5)+(3)(3.5)=10.5+0.5+0.5+10.5=22$.
4. Divide the total by $n-1=3$: $\operatorname{Cov}(x,y)=22/3=7.333\ldots$.
5. The positive covariance agrees with the increasing y-measurements as x grows, but its magnitude depends on their units.

Check: enter `22 ÷ 3` on the TI-30X IIS and round the repeating decimal.
::::
:::

:::problem[Problem 6.12 — Constant response values]{difficulty=standard}
A technician records different temperatures for several trials, but the same display reading every time. A student argues that the correlation must equal zero because the display never changes. Is that correct? Explain from the formula in the instructor's notes.

::::solution[Solution]
**Answer:** Correlation is undefined, not zero.

1. The temperatures may vary, but every display reading is identical. Therefore each y-deviation from the average y is zero.
2. The y sample variance equals zero, which makes its standard deviation $s_y=0$.
3. The correlation formula divides covariance by $s_xs_y$. That denominator is zero, so the coefficient cannot be computed.
4. A computed correlation of zero would describe data with **nonzero** variation and canceling linear contributions; that is not the situation here.

Check: there is no variation in y to standardize.
::::
:::

## 6.3 Interpretation, Real Examples, and Causation

The instructor's Homework 7 does not hand you a table of paired measurements and ask for a long calculation. It hands you a variable and a required kind of association, then asks you to **invent another variable** that could plausibly have that association. That is a deeper check than merely reciting “positive means upward.” You must translate the sign of correlation into a real-world measurement that has the correct direction.

A strong positive pair tends to put high observations together and low observations together. A strong negative pair tends to put high x with low y and low x with high y. A pair with no correlation has no systematic **linear** tendency. There are many valid answers; the instructor asks for an **example**, not a unique magic word. A good answer identifies a quantitative variable, gives its units or meaning, and explains what happens to it as x rises.

:::callout-intuition[Translate a number into a sentence]
For $r<0$, say “As X tends to increase, Y tends to decrease.” For $r>0$, reverse the second verb to “increase.” Add “strong” only when the magnitude is sufficiently large. These are descriptions of the **observed association**. The next question, “Does X cause Y to change?”, requires an entirely different argument about how the data were obtained.
:::

:::definition[Definition 6.5 — Association versus causation]
An **association** means that the observed values of two variables vary together in a discernible pattern. **Causation** means that changing one variable produces a change in another, rather than merely accompanying it. A correlation coefficient, even one extremely close to $1$ or $-1$, establishes a degree of **linear association**, not proof of cause and effect.
:::

### The instructor's three-variable homework

:::example[Example 6.7 — Homework 7, Question 1]
Let variable **X be student Exam 2 scores in IE 4613**. Give a reasonable example for each variable below to satisfy the stated correlation: (a) X and G are strongly positively correlated; (b) X and K are strongly negatively correlated; (c) X and N are not correlated.

::::answer[Answer]
**Answer:** G: parallel-exam score; K: questions missed; N: randomly assigned desk number.

1. For **G**, use the score on a very similar assessment of the same material. Students who score highly on Exam 2 would generally also score highly on the similar assessment, giving a **strong positive** trend.
2. For **K**, use the number of equally weighted questions answered incorrectly on Exam 2. A larger score means fewer missed questions, so the relationship is **strongly negative**. If the scoring rules are fixed, the relationship can even be perfectly linear.
3. For **N**, use a desk number assigned randomly and independently of exam performance. No underlying linear trend is expected between score and arbitrary assigned number.
4. These are plausible **variable definitions**, not observed correlations computed from a real class data set.

Check: high X corresponds to high G, low K, and no predictable N.
::::
:::

Why is “student intelligence” a poor answer for the negative variable? It is vague, difficult to measure, and would ordinarily be expected to trend in the wrong direction. Why is “shoe size” a better candidate for an uncorrelated variable than “number of incorrect answers”? Shoe size has no obvious direct connection to this course exam, whereas incorrect-answer count is built into the score. These are plausible expectations, not guarantees about every finite sample. A random sample can have a nonzero observed correlation just by chance.

### Exam 3's ACT question

The practice problem gives a **numerical** correlation, but it is not asking you to compute a new one. It wants a description of Y that makes sense given X and the sign. A correlation of $-0.89$ is very strongly negative in magnitude. So pick a variable likely to be **smaller when ACT scores are larger**. There is no need to assume exactly which students or admissions policies were involved.

:::example[Example 6.8 — Exam 3 practice, Question 12]
The correlation between X and Y was calculated as $-0.89$. If **X is the ACT score of incoming freshmen**, what is a reasonable description for Y?

::::answer[Answer]
**Answer:** Number of remedial-course sessions needed, or another plausibly decreasing quantitative measure.

1. The sign is negative, so students with higher ACT scores should generally have **lower** values of Y, while students with lower scores should tend to have higher values of Y.
2. The magnitude is large, so the intended pairing should exhibit a **strong** downward linear tendency.
3. A plausible Y is the **number of remedial math support sessions a student needs** during the first semester. Students with stronger initial preparation might tend to need fewer sessions.
4. This is an illustrative answer, **not** an empirical finding that this particular Y actually has the stated correlation. The problem gives $r$ and asks for a reasonable kind of variable.

Check: defining Y as a second standardized admissions score would likely suggest the opposite direction.
::::
:::

### A high correlation is not a cause-and-effect argument

This is the instructor's explicit warning on Unit 6 page 3: **correlation does NOT imply causation**. Two variables can move together because a third variable influences both, because the direction of influence is reversed, because selection effects shape the data, or because the pattern is coincidental. The numerical coefficient only measures how much they line up linearly in the data available.

Imagine summer days with high ice-cream sales and many visits to an outdoor pool. Those two measurements may be positively associated, but buying ice cream is not necessarily what sends people swimming. **Hot weather** plausibly increases both. In the diagram, the weather variable can explain why the other two measurements rise together. Seeing a tight cloud of ice-cream sales against pool attendance cannot separate these mechanisms.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 680 285" width="680" height="285" role="img" aria-label="Causal alternative: hot weather may influence both cold drink sales and pool visits.">
<text class="fig-label-em" x="340" y="40" text-anchor="middle">Hot weather</text>
<path class="fig-arrow" d="M315,57 L176,171"/>
<path class="fig-arrow" d="M365,57 L501,171"/>
<path class="fig-arrow" d="M176,171 l10,-2 l-4,-9"/>
<path class="fig-arrow" d="M501,171 l-10,-2 l4,-9"/>
<text class="fig-label-em" x="165" y="196" text-anchor="middle">Cold drink sales</text>
<text class="fig-label-em" x="512" y="196" text-anchor="middle">Pool visits</text>
<path class="fig-guide" d="M225,219 H465"/>
<text class="fig-label" x="345" y="243" text-anchor="middle">Observed association does not establish either causal arrow</text>
</svg>
<figcaption>A third variable such as hot weather can raise both drink sales and pool attendance, creating correlation without either measured activity causing the other.</figcaption>
</figure>

The same warning matters for the road-sign chart. It is entirely reasonable to observe that higher driver ages tend to come with shorter maximum reading distances. But an isolated scatterplot does not rule out other factors, such as differences in vision correction, test conditions, or the groups recruited for measurement. It also does not justify predicting a particular person's ability from age alone; the chart has scatter.

:::example[Example 6.9 — Cause or association?]
A business finds a strong positive correlation between customer revenue and customer satisfaction, resembling the Exam 3 plot. A manager says, “Charging each customer more will make the customer more satisfied.” Evaluate the statement.

::::answer[Answer]
**Answer:** The graph supports an association, not the proposed causal conclusion.

1. The plotted pattern says higher-revenue customers tend to have higher satisfaction indices within this observed sample. That is a statement about **association**.
2. Revenue might be higher because customers who are already satisfied buy more, reversing the proposed direction of influence.
3. A third factor, such as the amount of service received, could affect both revenue and satisfaction. Other selection effects are possible as well.
4. Simply increasing a charge does not follow logically from the observed scatterplot as a way to increase satisfaction.

Check: there is no experiment or comparable causal evidence in the problem statement.
::::
:::

### What you are allowed to claim

A careful exam answer says **“tend to,” “associated with,” “in the observed data,”** or “as one increases, the other generally decreases.” Strong correlation means a fairly predictable pattern for these two observed measurements along a straight-line trend. It does not mean every individual follows the trend, that predictions are error-free, or that changing x will move y in that direction. Even a perfect numerical coefficient does not by itself establish the mechanism.

When asked to choose among possible variables, test candidate answers one at a time. Start from a **high x-value**. What does the candidate Y usually do? If Y rises, the proposed association is positive. If Y falls, negative. If no systematic connection is expected, it is a sensible candidate for a lack of correlation. Then inspect the strength requirement. For a **strong** relationship, choose a close mathematical or substantive connection when possible, rather than a weakly related personal trait.

:::callout-pitfall[The causation leap]
Do not turn “customers who spend more tend to report higher satisfaction” into “raising a price causes satisfaction.” Do not turn “older drivers tend to have shorter reading distances” into an exact forecast for any one driver. Do not confuse a **plausible example** of Y with proof that real-world data would attain the correlation given in a hypothetical question.
:::

### Practice: examples and causal reasoning

:::problem[Problem 6.13 — Positive relationship example]{difficulty=easy}
Let X be the number of correctly answered questions on a fixed multiple-choice quiz. Give a quantitative variable Y that would be strongly positively correlated with X, and explain the direction.

::::solution[Solution]
**Answer:** Total quiz points under fixed equal-point scoring.

1. Let Y be the total number of points earned when each correct answer is worth the same positive number of points and there are no deductions or bonuses.
2. As X rises, Y rises in fixed proportion, so higher X-values go with higher Y-values.
3. The relation is positive and exactly linear if the scoring rules really are fixed as stated.
4. Defining a variable this way makes the strong relationship clear rather than relying on a vague assumption about motivation or ability.

Check: every additional correct answer adds the same positive number of points.
::::
:::

:::problem[Problem 6.14 — Negative relationship example]{difficulty=easy}
Let X be the number of successful inspections out of a fixed number of inspections, with every inspection classified as either a success or a failure. Give a Y that is strongly negatively correlated with X.

::::solution[Solution]
**Answer:** Number of failed inspections.

1. Define Y as the number of failures for the same fixed set of inspections.
2. Every additional success necessarily replaces a failure, because the total number of inspections is fixed.
3. The relationship is a straight downward line: high X goes with low Y and vice versa.
4. That provides a perfectly negative linear association when X actually varies; the **fixed-total** condition makes the example reliable.

Check: if the number of inspections changed between observations, the fixed-total reasoning would no longer apply.
::::
:::

:::problem[Problem 6.15 — No expected correlation]{difficulty=standard}
Let X be the measured thickness of finished steel sheets. Name a quantitative variable Y for which no linear correlation with X is expected, and explain why your choice is more defensible than choosing the sheet's mass.

::::solution[Solution]
**Answer:** Randomly assigned sample-identification number.

1. Define Y as a number assigned to each sheet by a random mechanism independent of the sheet's physical characteristics.
2. Because the label is assigned independently of thickness, no underlying linear tendency is expected between X and Y.
3. Sheet **mass**, on the other hand, can change with thickness when area and material density are similar, so it is a poor candidate for no association.
4. Random assignment describes an expectation, not an absolute promise that the measured sample correlation will be exactly zero.

Check: relabeling a sheet should not physically change its thickness.
::::
:::

:::problem[Problem 6.16 — Correlation versus action]{difficulty=standard}
A university observes a strong negative correlation between students' hours of sleep and reported daytime fatigue. An administrator concludes that forcing every student to remain in bed longer will necessarily eliminate fatigue. Which part of the conclusion does the correlation not justify?

::::solution[Solution]
**Answer:** The claim that changing bed time necessarily eliminates fatigue.

1. A negative association means students with more sleep hours tend to report less fatigue in the observed data.
2. That finding is not the same as a controlled demonstration that forcing longer time in bed **causes** less fatigue.
3. Sleep quality, health, work schedules, and measurement differences may affect both variables. Also, more time in bed need not equal more sleep.
4. The word “necessarily” is especially unjustified because an association does not promise the same response for every student.

Check: the measured variable was hours of sleep, not hours required to remain in bed.
::::
:::

:::problem[Problem 6.17 — Strongly negative ACT example]{difficulty=standard}
In the instructor's Exam 3 problem, X is incoming freshmen's ACT score and $r=-0.89$. A student suggests Y should be first-semester mathematics grade, while another suggests Y should be the number of preparatory tutoring sessions needed. Which suggestion better fits the sign, and why?

::::solution[Solution]
**Answer:** Number of preparatory tutoring sessions needed.

1. A strong negative correlation calls for a Y that generally **falls** when ACT score rises.
2. Students with stronger incoming preparation might plausibly require fewer tutoring sessions, so that example has the required downward direction.
3. First-semester math grade might instead rise with ACT score, making it a more plausible candidate for **positive** association.
4. Neither suggestion is guaranteed by ACT scores; both are hypotheses about real behavior. The question asks for an example consistent with the stated sign and strength.

Check: imagine a particularly high X-value and ask which suggested Y would tend to be lower.
::::
:::

:::problem[Problem 6.18 — Confounded customer relationship]{difficulty=challenge}
A retailer notices that sales of cold drinks and customers' visits to a swimming-pool facility have strong positive correlation. The retailer proposes giving away drinks to cause a surge in pool attendance. Give a different explanation for the association and state what the correlation cannot establish.

::::solution[Solution]
**Answer:** Hot weather could raise both; the correlation does not establish causation.

1. On hotter days, people may buy more cold drinks and independently choose to visit the swimming pool more often.
2. Temperature acts as a plausible **third variable** influencing both measurements, producing a positive correlation even without drinks causing pool trips.
3. Pool visits might also change drink purchases, which is the reverse causal direction from the retailer's proposal.
4. The observed positive linear association alone cannot determine which mechanism is responsible or guarantee that a giveaway increases attendance.

Check: the proposed cause was never experimentally varied in the stated evidence.
::::
:::

## Chapter Summary

:::summary[Correlation: the exam-ready rules]
- A **scatterplot** displays pairs of quantitative measurements. Following the instructor's convention, the independent/explanatory variable is horizontal; the dependent/response variable is vertical.
- Describe each scatterplot by **direction** (positive, negative, or no clear trend), **form** (linear versus curved), and **strength** (how tightly the points follow the form).
- Sample **covariance** averages products of paired deviations about the means. Its sign indicates linear direction, but its magnitude depends on measurement units.
- The sample **correlation coefficient $r$** standardizes covariance using $s_xs_y$. Its values range from $-1$ to $1$. The sign gives linear direction; the absolute value gives **linear** strength.
- A **negative coefficient can be stronger** than a positive coefficient. A zero or near-zero correlation does not rule out a nonlinear relationship. If either variable has no variation, $r$ is undefined.
- **Neither covariance nor correlation is printed on the Final or Exam 3 equation sheets.** The sample-variance formula used within the calculation appears on the Final sheet, page 1.
- The instructor's road-sign example reports $r=-0.793$, consistent with a fairly strong negative linear association. The Exam 3 revenue-and-satisfaction plot shows a strong positive trend.
- **Correlation does not imply causation.** Write “associated with” or “tend to vary together,” and never assume changing one variable must change the other.
:::

## Mixed Practice

This set follows the final's answer formats. There is one three-part true/false item, one four-part matching item, and multiple-choice items. The small numerical questions use only short paired data lists and the Unit 6 formulas, not statistical software. Interpret every result in its own context.

:::problem[Problem M.1 — True or false in three parts]{difficulty=easy}
Decide whether each claim is true or false: **(a)** A scatterplot uses one point for each pair of quantitative measurements. **(b)** An observed correlation close to negative one proves the explanatory variable causes the response. **(c)** A relationship can be strongly curved while its linear correlation is near zero.

::::solution[Solution]
**Answer:** True, false, true.

1. **(a) True.** A plotted pair gives the x- and y-measurement from the same observational unit; two separate unpaired values would not make a valid scatterplot point.
2. **(b) False.** Negative one describes perfect negative **linear association** when both variables vary. It does not identify an underlying causal mechanism.
3. **(c) True.** A U-shaped pattern can be systematic even if its positive and negative linear contributions cancel.
4. Do not confuse “no linear pattern” with “no pattern at all.”

Check: these statements test the meanings of a point, the limits of causation, and nonlinear form.
::::
:::

:::problem[Problem M.2 — Match the description]{difficulty=standard}
Match each description to the best scatterplot pattern. **Descriptions:** A. As x increases, y generally decreases in a narrow straight band. B. The points trace a clear U-shape. C. The points form an almost featureless cloud. D. As x increases, y generally increases in a narrow straight band. **Patterns:** P. Strong positive linear. Q. Weak linear association. R. Strong negative linear. S. Strong nonlinear.

::::solution[Solution]
**Answer:** A–R, B–S, C–Q, D–P.

1. **A matches R** because a tight descending line has negative direction, linear form, and strong strength.
2. **B matches S** because an evident U-shape is a strong relationship, but its form is not linear.
3. **C matches Q** because a nearly patternless cloud gives little evidence of a consistent straight-line trend.
4. **D matches P** because a tight ascending line is positive, linear, and strong.

Check: the only curved description must match the only nonlinear option.
::::
:::

:::problem[Problem M.3 — Multiple choice: covariance]{difficulty=standard}
Compute the **sample covariance**. Data: $x=(1,2,3);\ y=(2,4,6)$. Which answer is correct?

(A) $4.000$  
(B) $2.000$  
(C) $1.333$  
(D) $-2.000$

::::solution[Solution]
**Answer:** (B) 2.000.

1. Means are $\bar{x}=2$ and $\bar{y}=4$. Paired deviation products are $(-1)(-2)+(0)(0)+(1)(2)=4$.
2. Because these are sample data, divide by $n-1=2$, giving covariance $4/2=2.000$.
3. **A** forgets to divide. **C** divides by the wrong amount. **D** has the wrong sign for pairs that rise together.
4. Positive covariance means higher x-values tend to accompany higher y-values in these measurements.

Check: the three points lie on an increasing line, making a negative result impossible.
::::
:::

:::problem[Problem M.4 — Multiple choice: negative line]{difficulty=easy}
Calculate the **sample correlation coefficient $r$**. Data: $x=(1,2,3);\ y=(3,2,1)$. Which value matches the points?

(A) $1.000$  
(B) $-1.000$  
(C) $0.000$  
(D) $-0.333$

::::solution[Solution]
**Answer:** (B) -1.000.

1. The x-deviations are $(-1,0,1)$ and the y-deviations are $(1,0,-1)$. The covariance is $[-1+0-1]/2=-1$.
2. Both sample variances are $(1+0+1)/2=1$, so $r=-1/\sqrt{1\cdot1}=-1.000$.
3. **A** reverses the direction. **C** ignores the unmistakable line. **D** incorrectly weakens a perfect straight-line pattern.
4. The observed y-value decreases by the same amount whenever x increases by one unit.

Check: the data lie exactly on $y=4-x$.
::::
:::

:::problem[Problem M.5 — Multiple choice: moderate correlation]{difficulty=challenge}
Calculate the **sample correlation coefficient $r$**. Data: $x=(1,2,3);\ y=(1,4,2)$. Round to three decimals.

(A) $0.327$  
(B) $-0.327$  
(C) $0.500$  
(D) $1.000$

::::solution[Solution]
**Answer:** (A) 0.327.

1. Compute $\bar{x}=2$ and $\bar{y}=7/3$. The deviations are $(-1,0,1)$ and $(-4/3,5/3,-1/3)$.
2. The paired products sum to $(-1)(-4/3)+(0)(5/3)+(1)(-1/3)=1$, so sample covariance is $1/2=0.5$.
3. The variances are $s_x^2=(1+0+1)/2=1$ and $s_y^2=[16/9+25/9+1/9]/2=7/3$.
4. Thus $r=0.5/\sqrt{1\cdot(7/3)}\approx0.327$. **B** gets the sign wrong; **C** mistakes covariance for correlation; **D** incorrectly treats scattered points as a perfect line.

Check: the positive sign fits the positive covariance, while the imperfect ordering explains a value below one.
::::
:::

:::problem[Problem M.6 — Multiple choice: four-pair correlation]{difficulty=standard}
Calculate the **sample correlation coefficient $r$**. Data: $x=(1,2,3,4);\ y=(5,7,6,8)$. Round to three decimals.

(A) $-0.800$  
(B) $0.000$  
(C) $0.667$  
(D) $0.800$

::::solution[Solution]
**Answer:** (D) 0.800.

1. The averages are $\bar{x}=2.5$ and $\bar{y}=6.5$. Matching deviations are $(-1.5,-0.5,0.5,1.5)$ and $(-1.5,0.5,-0.5,1.5)$.
2. The product sum is $2.25-0.25-0.25+2.25=4$; covariance is $4/3$.
3. Each deviation-square sum is $2.25+0.25+0.25+2.25=5$, so both sample variances equal $5/3$.
4. Therefore $r=(4/3)/\sqrt{(5/3)(5/3)}=4/5=0.800$. **A** reverses the sign, **B** ignores the trend, and **C** is a denominator mistake.

Check: y generally rises with x, but its middle values are not perfectly ordered.
::::
:::

:::problem[Problem M.7 — Multiple choice: compute covariance]{difficulty=standard}
Compute the **sample covariance**. Data: $x=(2,4,6);\ y=(1,3,2)$. Which is correct?

(A) $0.000$  
(B) $2.000$  
(C) $1.000$  
(D) $-1.000$

::::solution[Solution]
**Answer:** (C) 1.000.

1. The means are $\bar{x}=4$ and $\bar{y}=2$. Deviations are $(-2,0,2)$ and $(-1,1,0)$.
2. Multiply matching deviations: $(-2)(-1)+(0)(1)+(2)(0)=2$.
3. Divide by $n-1=2$ to obtain $2/2=1.000$.
4. **A** treats some nonmatching deviations as canceling; **B** uses the undivided numerator; **D** reverses the sign. The covariance is positive, but y does not increase steadily with x.

Check: this covariance and the two sample standard deviations give a correlation less than one.
::::
:::

:::problem[Problem M.8 — Multiple choice: scale of $r$]{difficulty=standard}
Calculate the **sample correlation coefficient $r$**. Data: $x=(1,3,5);\ y=(9,5,1)$. Which value is correct?

(A) $-1.000$  
(B) $-4.000$  
(C) $0.000$  
(D) $1.000$

::::solution[Solution]
**Answer:** (A) -1.000.

1. The means are $\bar{x}=3$ and $\bar{y}=5$. Their deviations are $(-2,0,2)$ and $(4,0,-4)$.
2. The product sum is $(-2)(4)+(0)(0)+(2)(-4)=-16$, so covariance is $-16/2=-8$.
3. The sample variances are $s_x^2=(4+0+4)/2=4$ and $s_y^2=(16+0+16)/2=16$.
4. Divide by the standard-deviation product: $r=-8/\sqrt{4\cdot16}=-8/8=-1.000$. **B** is outside the allowed range; **C** misses the linear relation; **D** has the wrong sign.

Check: each increase in x corresponds to an exact fall in y.
::::
:::

:::problem[Problem M.9 — Multiple choice: interpret the sign]{difficulty=easy}
For incoming freshmen, the instructor's Exam 3 problem reports a correlation of $-0.89$ between ACT score X and some Y. Which is the most reasonable candidate for Y?

(A) A second test score measuring almost the same ability  
(B) Number of correctly answered ACT questions  
(C) Number of remedial study sessions needed  
(D) ACT percentile rank

::::solution[Solution]
**Answer:** (C).

1. A highly negative correlation asks for a variable that tends to **decrease** as ACT score increases.
2. More prepared students might plausibly need fewer remedial sessions, which fits **C**.
3. **A**, **B**, and **D** would ordinarily rise alongside ACT score, giving positive rather than strongly negative association.
4. This is a reasonable hypothetical description, not proof that remedial sessions in a particular freshman cohort truly exhibit that correlation.

Check: test the answer against a student with a very high ACT score; their Y should tend to be low.
::::
:::

:::problem[Problem M.10 — Multiple choice: U-shaped relationship]{difficulty=standard}
A scatterplot shows a tight U-shape, and its sample correlation coefficient is close to zero. Which conclusion is best?

(A) The variables must be independent  
(B) There is a strong nonlinear pattern but little overall linear correlation  
(C) The graph has perfect negative linear correlation  
(D) The data must have been measured incorrectly

::::solution[Solution]
**Answer:** (B).

1. The points follow a predictable U-shape, so a real relationship is visible. The term **nonlinear** describes its form.
2. A line through the whole shape captures neither side well; opposite local directions can cancel, leaving correlation close to zero.
3. **A** falsely treats zero linear correlation as independence. **C** demands a descending straight line, which is absent. **D** invents a measurement failure not supplied by the graph.

Check: the strong pattern is curved, which is exactly what linear correlation can miss.
::::
:::

:::problem[Problem M.11 — Multiple choice: causal claim]{difficulty=standard}
A survey finds a strong positive correlation between hours of outdoor recreation and sales of cold beverages. Which statement is justified by the observed association alone?

(A) Beverage purchases cause outdoor recreation  
(B) Outdoor recreation must cause beverage purchases  
(C) The two measurements tend to be higher together in the observed data  
(D) Temperature cannot influence either measurement

::::solution[Solution]
**Answer:** (C).

1. A positive correlation supports the statement that high observations of one variable tend to accompany high observations of the other.
2. **A** and **B** turn a statistical pattern into a particular causal direction without evidence for that mechanism.
3. **D** dismisses a plausible third variable, such as temperature, without reason. Both activities could rise on hotter days.
4. Only **C** stays within what a correlation coefficient and a survey can establish.

Check: the answer uses “tend to” rather than “cause” or “must.”
::::
:::

:::problem[Problem M.12 — Multiple choice: the Exam 3 plot]{difficulty=standard}
Refer to the instructor's **Customer Revenue versus Customer Satisfaction Index** scatterplot shown in Section 6.1. Which description is best?

(A) Strong negative and linear  
(B) Weak positive and unrelated  
(C) Strong positive and approximately linear  
(D) Perfect positive with no scatter

::::solution[Solution]
**Answer:** (C).

1. The satisfaction-index values generally become higher as customer revenue increases, making the direction **positive**.
2. The cloud follows a clear upward trend with some scatter, so **strong, approximately linear** is the useful summary.
3. **A** reverses the direction. **B** ignores the prominent pattern and is internally inconsistent. **D** incorrectly claims perfect alignment when numerous points lie above or below the main trend.
4. The plot supports an association, not a claim that higher charges cause higher satisfaction.

Check: the lowest-revenue observations cluster near the lowest satisfaction-index values.
::::
:::

:::problem[Problem M.13 — Multiple choice: the homework variables]{difficulty=challenge}
Let X be the IE 4613 Exam 2 score, as in Homework 7. Which assignment to G, K, and N best meets strong positive correlation for G, strong negative for K, and no expected correlation for N?

(A) G = randomly assigned desk number; K = points earned; N = missed questions  
(B) G = missed questions; K = similar-exam points; N = points earned  
(C) G = similar-exam points; K = missed questions; N = randomly assigned desk number  
(D) G = missed questions; K = desk number; N = similar-exam points

::::solution[Solution]
**Answer:** (C).

1. Scores on a similar exam are plausibly high when X is high, giving **positive** correlation for G.
2. More points on an exam generally mean fewer questions missed under a fixed scoring rule, giving **negative** correlation for K.
3. An independently and randomly assigned desk number has no built-in relation to performance, making N a plausible uncorrelated variable.
4. **A**, **B**, and **D** assign at least one variable to the opposite relationship. Match each requirement separately instead of judging only one pair.

Check: G increases with X, K decreases with X, and N is assigned without reference to X.
::::
:::
