---
title: "Statistical Thinking"
crumb: "Engineering Statistics · Chapter 1"
meta:
  - "Est. study time: ~100 min"
  - "IE 4613 · Unit 1"
source: "markdown"
---

## Overview

An engineer rarely gets the same result twice. Two brackets made from the same drawing may fit differently; two connectors of the same design may withstand different forces. Engineering statistics begins with that uncomfortable fact. Its job is not to pretend the variation disappears. Its job is to use data to understand what changes, why it changes, and what decisions the evidence supports.

This unit is mainly conceptual. The final exam emphasizes **statistical inference, variability, population, and sample**, with true/false, matching, and multiple-choice questions. The instructor's slides also explain how engineers collect data, how observational studies differ from experiments, and why an apparent relationship need not be a causal one. The critical skill is distinguishing similar-sounding terms from the *wording* of a scenario.

There are no Unit 1 calculation formulas on the Final Exam Equations sheet. Percentages used below are ordinary part-divided-by-whole counts, not a new statistics formula. The probability tables and inferential test formulas on later pages of the Final sheet belong to later units.

:::callout-key[What a Unit 1 question usually asks]
Look for a **target group** (population), an **observed subset** (sample), **results that differ between repetitions** (variability), and a **claim extending beyond the observed data** (inference). If a study changes a treatment deliberately, ask about experiment and causation; if it only watches, ask about observation and confounding.
:::

## 1.1 Statistics and Variability

When a factory runs the same nominal procedure twice, a result can change even without a deliberate change in the drawing or instructions. Statistics describes that variation, investigates its sources, and guides action. The instructor defines statistics through the **collection, presentation, analysis, and use of data** to make decisions, solve problems, and design products or processes.

:::callout-intuition[Why engineers need statistics]
Imagine testing only the first successful connector and declaring the design reliable. That result describes one connector, not the process that produces thousands of connectors. The more useful question is whether the process *consistently* produces enough pull-off force. You need several observations to see whether low readings are rare, common, or associated with a controllable factor.
:::

:::definition[Definition 1.1 — Statistics]
**Statistics** is the field concerned with collecting, presenting, analyzing, and using data so that decisions, problem solving, and product or process design rest on evidence rather than an isolated observation.
:::

:::definition[Definition 1.2 — Variability]
**Variability** occurs when successive repetitions of an activity, measurement, or process do not produce exactly the same result. Its **sources** are the factors that make outcomes change, including raw material differences, equipment condition, environmental conditions, operators, and measurement error.
:::

### The nylon connector and its dot diagram

The instructor's engineering example concerns a nylon connector in an automotive engine. An engineer considers a wall thickness of $3/32$ inch but is unsure how that design affects pull-off force. A connector may fail during installation if the pull-off force is too low. Eight prototypes of this design yield force measurements, in pounds, of $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$.

A dot diagram puts **one dot for every measurement** above a number line. A repeated reading produces stacked dots. The diagram lets you see the **location** (where values cluster) and **scatter** (how spread out they are) without hiding individual measurements inside one summary. A second design at $1/8$ inch can be placed on the same scale to compare its outcomes; the slide gives a plotted comparison, not a printed list of the second design's raw readings. Consequently, do not claim an exact numerical comparison from the second plot alone.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 640 165" width="640" height="165" role="img" aria-label="Dot diagram of eight nylon connector pull-off force readings, with a stack of two dots at 12.6 pounds">
<line class="fig-axis" x1="70" y1="112" x2="585" y2="112"/>
<line class="fig-axis" x1="70.0" y1="109" x2="70.0" y2="119"/>
<text class="fig-label" x="70.0" y="140" text-anchor="middle">12</text>
<line class="fig-axis" x1="183.6" y1="109" x2="183.6" y2="119"/>
<text class="fig-label" x="183.6" y="140" text-anchor="middle">12.5</text>
<line class="fig-axis" x1="297.3" y1="109" x2="297.3" y2="119"/>
<text class="fig-label" x="297.3" y="140" text-anchor="middle">13</text>
<line class="fig-axis" x1="410.9" y1="109" x2="410.9" y2="119"/>
<text class="fig-label" x="410.9" y="140" text-anchor="middle">13.5</text>
<line class="fig-axis" x1="524.5" y1="109" x2="524.5" y2="119"/>
<text class="fig-label" x="524.5" y="140" text-anchor="middle">14</text>
<circle class="fig-point" cx="138.2" cy="98" r="5"/>
<circle class="fig-point" cx="206.4" cy="98" r="5"/>
<circle class="fig-point" cx="206.4" cy="75" r="5"/>
<circle class="fig-point" cx="274.5" cy="98" r="5"/>
<circle class="fig-point" cx="320.0" cy="98" r="5"/>
<circle class="fig-point" cx="388.2" cy="98" r="5"/>
<circle class="fig-point" cx="410.9" cy="98" r="5"/>
<circle class="fig-point" cx="433.6" cy="98" r="5"/>
<text class="fig-label" x="312" y="159" text-anchor="middle">Pull-off force (pounds)</text>
</svg>
<figcaption>Every prototype contributes one dot, so the repeated $12.6$-pound reading forms a two-dot stack rather than disappearing.</figcaption>
</figure>

:::example[Example 1.1 — How many prototypes?]
A nylon connector with a proposed wall thickness of $3/32$ inch is tested. The recorded pull-off forces, in pounds, are $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$. How many prototype units were measured, and what is the observational unit?

::::answer[Answer]
**Answer:** 8.

1. A measurement corresponds to one prototype connector, not to one distinct number on the dot diagram. The same force can occur more than once.
2. Count the recorded entries separately: $12.6$ (first), $12.9$, $13.4$, $12.3$, $13.6$, $13.5$, $12.6$ (second), and $13.1$.
3. There are eight entries, so the **observational unit** is one prototype connector and the **measured variable** is its pull-off force in pounds.

Check: the dot diagram must also contain eight filled dots, including both dots at $12.6$.
::::
:::

:::example[Example 1.2 — Reading repetitions from a dot diagram]
The eight recorded pull-off forces are $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$ pounds. How many units have a recorded pull-off force of exactly $12.6$ pounds?

::::answer[Answer]
**Answer:** 2.

1. The word **exactly** asks for equality, not for all forces near $12.6$. Read each recorded force or count the dots at the $12.6$ position.
2. The value $12.6$ appears once at the beginning and again near the end of the list. None of the other six entries equals $12.6$.
3. Stack the two dots rather than placing them on top of one another where one disappears.

Check: two of the eight units share this measured result; the repeated value does not mean there were only seven tests.
::::
:::

:::example[Example 1.3 — Recognizing scatter without a formula]
For the eight connector forces $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$ pounds, how many measurements are at least $13.0$ pounds? Explain what that says about the observed results.

::::answer[Answer]
**Answer:** 4.

1. **At least $13.0$** means greater than or equal to $13.0$. Scan the measurements one by one; do not count anything below that threshold.
2. The qualifying values are $13.4$, $13.6$, $13.5$, and $13.1$, for four measurements.
3. The other four prototype readings fall below $13.0$. This demonstrates that nominally identical prototypes have different forces.

Check: four qualifying plus four nonqualifying measurements account for all eight prototypes; this count alone does not establish a safe production specification.
::::
:::

### A change in output needs a possible cause

The nylon example separates three things. The **design input** is the selected wall thickness. The **response** is measured pull-off force. The **disturbances** are whatever else affects the result: material differences, molding conditions, testing alignment, and instrument noise. The slide writes the conceptual model as

$$
X=\mu+\varepsilon.
$$

Here $X$ is the varying observed result, $\mu$ is a fixed central component, and $\varepsilon$ is the random disturbance for an individual observation. This model is **not on the Final sheet**; it makes intuitive sense as “observed result = typical level + departure from that level.” It illustrates the distinction between a stable target and variable measurements. Not every process must be accurately modeled by a simple additive disturbance, and changing the design could change the typical level as well.

:::definition[Definition 1.3 — Random variable]
A **random variable** is a numerical quantity whose value can vary from one observation or trial to another. In the connector example, measured pull-off force is a random variable because it can take different values across nominally similar units.
:::

:::callout-connect[The calculations come later]
Chapter 2, *Describing Data*, teaches sample mean, sample variance, sample standard deviation, numerical spread, histograms, and box plots. Unit 1 uses the observed differences to understand **why** those summaries would be useful, not to practice their formulas.
:::

### Deming's funnel: correcting noise can make things worse

In the instructor's Deming funnel demonstration, a ball is dropped through a funnel toward a target. Strategy 1 keeps the funnel in the same position. Strategy 2 moves the funnel after each drop to compensate for the last miss. The critical point is that an individual miss can be random. Adjusting the equipment for *every* random deviation may make the process less stable, rather than more accurate.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 650 190" width="650" height="190" role="img" aria-label="Schematic simulated impact patterns for keeping a funnel fixed and for correcting after each miss">
<path class="fig-guide" d="M 217.00 84.00 L 216.87 87.63 L 216.49 91.24 L 215.86 94.81 L 214.99 98.33 L 213.86 101.79 L 212.50 105.15 L 210.91 108.41 L 209.10 111.56 L 207.07 114.56 L 204.83 117.42 L 202.41 120.12 L 199.79 122.64 L 197.01 124.98 L 194.08 127.11 L 191.00 129.03 L 187.80 130.74 L 184.48 132.21 L 181.07 133.45 L 177.58 134.46 L 174.03 135.21 L 170.44 135.72 L 166.81 135.97 L 163.19 135.97 L 159.56 135.72 L 155.97 135.21 L 152.42 134.46 L 148.93 133.45 L 145.52 132.21 L 142.20 130.74 L 139.00 129.03 L 135.92 127.11 L 132.99 124.98 L 130.21 122.64 L 127.59 120.12 L 125.17 117.42 L 122.93 114.56 L 120.90 111.56 L 119.09 108.41 L 117.50 105.15 L 116.14 101.79 L 115.01 98.33 L 114.14 94.81 L 113.51 91.24 L 113.13 87.63 L 113.00 84.00 L 113.13 80.37 L 113.51 76.76 L 114.14 73.19 L 115.01 69.67 L 116.14 66.21 L 117.50 62.85 L 119.09 59.59 L 120.90 56.44 L 122.93 53.44 L 125.17 50.58 L 127.59 47.88 L 130.21 45.36 L 132.99 43.02 L 135.92 40.89 L 139.00 38.97 L 142.20 37.26 L 145.52 35.79 L 148.93 34.55 L 152.42 33.54 L 155.97 32.79 L 159.56 32.28 L 163.19 32.03 L 166.81 32.03 L 170.44 32.28 L 174.03 32.79 L 177.58 33.54 L 181.07 34.55 L 184.48 35.79 L 187.80 37.26 L 191.00 38.97 L 194.08 40.89 L 197.01 43.02 L 199.79 45.36 L 202.41 47.88 L 204.83 50.58 L 207.07 53.44 L 209.10 56.44 L 210.91 59.59 L 212.50 62.85 L 213.86 66.21 L 214.99 69.67 L 215.86 73.19 L 216.49 76.76 L 216.87 80.37 L 217.00 84.00 Z"/>
<path class="fig-guide" d="M 187.00 84.00 L 186.95 85.53 L 186.79 87.06 L 186.52 88.57 L 186.15 90.06 L 185.67 91.52 L 185.10 92.95 L 184.42 94.33 L 183.66 95.66 L 182.80 96.93 L 181.85 98.14 L 180.83 99.28 L 179.72 100.35 L 178.54 101.34 L 177.30 102.24 L 176.00 103.05 L 174.64 103.77 L 173.24 104.40 L 171.80 104.92 L 170.32 105.35 L 168.82 105.67 L 167.30 105.88 L 165.77 105.99 L 164.23 105.99 L 162.70 105.88 L 161.18 105.67 L 159.68 105.35 L 158.20 104.92 L 156.76 104.40 L 155.36 103.77 L 154.00 103.05 L 152.70 102.24 L 151.46 101.34 L 150.28 100.35 L 149.17 99.28 L 148.15 98.14 L 147.20 96.93 L 146.34 95.66 L 145.58 94.33 L 144.90 92.95 L 144.33 91.52 L 143.85 90.06 L 143.48 88.57 L 143.21 87.06 L 143.05 85.53 L 143.00 84.00 L 143.05 82.47 L 143.21 80.94 L 143.48 79.43 L 143.85 77.94 L 144.33 76.48 L 144.90 75.05 L 145.58 73.67 L 146.34 72.34 L 147.20 71.07 L 148.15 69.86 L 149.17 68.72 L 150.28 67.65 L 151.46 66.66 L 152.70 65.76 L 154.00 64.95 L 155.36 64.23 L 156.76 63.60 L 158.20 63.08 L 159.68 62.65 L 161.18 62.33 L 162.70 62.12 L 164.23 62.01 L 165.77 62.01 L 167.30 62.12 L 168.82 62.33 L 170.32 62.65 L 171.80 63.08 L 173.24 63.60 L 174.64 64.23 L 176.00 64.95 L 177.30 65.76 L 178.54 66.66 L 179.72 67.65 L 180.83 68.72 L 181.85 69.86 L 182.80 71.07 L 183.66 72.34 L 184.42 73.67 L 185.10 75.05 L 185.67 76.48 L 186.15 77.94 L 186.52 79.43 L 186.79 80.94 L 186.95 82.47 L 187.00 84.00 Z"/>
<line class="fig-axis" x1="99" y1="84" x2="231" y2="84"/>
<line class="fig-axis" x1="165" y1="18" x2="165" y2="150"/>
<circle class="fig-point" cx="192" cy="66" r="3.5"/>
<circle class="fig-point" cx="129" cy="93" r="3.5"/>
<circle class="fig-point" cx="174" cy="120" r="3.5"/>
<circle class="fig-point" cx="201" cy="102" r="3.5"/>
<circle class="fig-point" cx="147" cy="48" r="3.5"/>
<circle class="fig-point" cx="183" cy="84" r="3.5"/>
<circle class="fig-point" cx="165" cy="57" r="3.5"/>
<text class="fig-label" x="165" y="173" text-anchor="middle">Fixed funnel</text>
<path class="fig-guide" d="M 527.00 84.00 L 526.87 87.63 L 526.49 91.24 L 525.86 94.81 L 524.99 98.33 L 523.86 101.79 L 522.50 105.15 L 520.91 108.41 L 519.10 111.56 L 517.07 114.56 L 514.83 117.42 L 512.41 120.12 L 509.79 122.64 L 507.01 124.98 L 504.08 127.11 L 501.00 129.03 L 497.80 130.74 L 494.48 132.21 L 491.07 133.45 L 487.58 134.46 L 484.03 135.21 L 480.44 135.72 L 476.81 135.97 L 473.19 135.97 L 469.56 135.72 L 465.97 135.21 L 462.42 134.46 L 458.93 133.45 L 455.52 132.21 L 452.20 130.74 L 449.00 129.03 L 445.92 127.11 L 442.99 124.98 L 440.21 122.64 L 437.59 120.12 L 435.17 117.42 L 432.93 114.56 L 430.90 111.56 L 429.09 108.41 L 427.50 105.15 L 426.14 101.79 L 425.01 98.33 L 424.14 94.81 L 423.51 91.24 L 423.13 87.63 L 423.00 84.00 L 423.13 80.37 L 423.51 76.76 L 424.14 73.19 L 425.01 69.67 L 426.14 66.21 L 427.50 62.85 L 429.09 59.59 L 430.90 56.44 L 432.93 53.44 L 435.17 50.58 L 437.59 47.88 L 440.21 45.36 L 442.99 43.02 L 445.92 40.89 L 449.00 38.97 L 452.20 37.26 L 455.52 35.79 L 458.93 34.55 L 462.42 33.54 L 465.97 32.79 L 469.56 32.28 L 473.19 32.03 L 476.81 32.03 L 480.44 32.28 L 484.03 32.79 L 487.58 33.54 L 491.07 34.55 L 494.48 35.79 L 497.80 37.26 L 501.00 38.97 L 504.08 40.89 L 507.01 43.02 L 509.79 45.36 L 512.41 47.88 L 514.83 50.58 L 517.07 53.44 L 519.10 56.44 L 520.91 59.59 L 522.50 62.85 L 523.86 66.21 L 524.99 69.67 L 525.86 73.19 L 526.49 76.76 L 526.87 80.37 L 527.00 84.00 Z"/>
<path class="fig-guide" d="M 497.00 84.00 L 496.95 85.53 L 496.79 87.06 L 496.52 88.57 L 496.15 90.06 L 495.67 91.52 L 495.10 92.95 L 494.42 94.33 L 493.66 95.66 L 492.80 96.93 L 491.85 98.14 L 490.83 99.28 L 489.72 100.35 L 488.54 101.34 L 487.30 102.24 L 486.00 103.05 L 484.64 103.77 L 483.24 104.40 L 481.80 104.92 L 480.32 105.35 L 478.82 105.67 L 477.30 105.88 L 475.77 105.99 L 474.23 105.99 L 472.70 105.88 L 471.18 105.67 L 469.68 105.35 L 468.20 104.92 L 466.76 104.40 L 465.36 103.77 L 464.00 103.05 L 462.70 102.24 L 461.46 101.34 L 460.28 100.35 L 459.17 99.28 L 458.15 98.14 L 457.20 96.93 L 456.34 95.66 L 455.58 94.33 L 454.90 92.95 L 454.33 91.52 L 453.85 90.06 L 453.48 88.57 L 453.21 87.06 L 453.05 85.53 L 453.00 84.00 L 453.05 82.47 L 453.21 80.94 L 453.48 79.43 L 453.85 77.94 L 454.33 76.48 L 454.90 75.05 L 455.58 73.67 L 456.34 72.34 L 457.20 71.07 L 458.15 69.86 L 459.17 68.72 L 460.28 67.65 L 461.46 66.66 L 462.70 65.76 L 464.00 64.95 L 465.36 64.23 L 466.76 63.60 L 468.20 63.08 L 469.68 62.65 L 471.18 62.33 L 472.70 62.12 L 474.23 62.01 L 475.77 62.01 L 477.30 62.12 L 478.82 62.33 L 480.32 62.65 L 481.80 63.08 L 483.24 63.60 L 484.64 64.23 L 486.00 64.95 L 487.30 65.76 L 488.54 66.66 L 489.72 67.65 L 490.83 68.72 L 491.85 69.86 L 492.80 71.07 L 493.66 72.34 L 494.42 73.67 L 495.10 75.05 L 495.67 76.48 L 496.15 77.94 L 496.52 79.43 L 496.79 80.94 L 496.95 82.47 L 497.00 84.00 Z"/>
<line class="fig-axis" x1="409" y1="84" x2="541" y2="84"/>
<line class="fig-axis" x1="475" y1="18" x2="475" y2="150"/>
<circle class="fig-point" cx="502" cy="66" r="3.5"/>
<circle class="fig-point" cx="412" cy="111" r="3.5"/>
<circle class="fig-point" cx="520" cy="111" r="3.5"/>
<circle class="fig-point" cx="502" cy="66" r="3.5"/>
<circle class="fig-point" cx="421" cy="30" r="3.5"/>
<circle class="fig-point" cx="511" cy="120" r="3.5"/>
<circle class="fig-point" cx="457" cy="57" r="3.5"/>
<text class="fig-label" x="475" y="173" text-anchor="middle">Adjust after last miss</text>
</svg>
<figcaption>In a schematic sequence with the same random disturbances, correcting the funnel after each miss can spread impacts farther than leaving the setting fixed; these dots illustrate the rule, not measured class results.</figcaption>
</figure>

:::callout-pitfall[Variation is not automatically a defective design]
Do not call every different reading a **mistake**, and do not assume a fixed drawing makes outcomes identical. A difference may come from natural process variation, a controllable factor, or an imperfect measurement. Likewise, a dot diagram shows what happened in the tested units; it does not independently establish what will happen to all future units.
:::

### Practice: statistics and variability

:::problem[Problem 1.1 — Everyday variation]{difficulty=easy}
The instructor asks: What are some everyday tasks that include variability, and what are the sources of variability for that task? Give one everyday activity and at least three plausible sources.

::::solution[Solution]
**Answer:** Making a cup of coffee is one example; water temperature, brewing time, and the amount of coffee are three sources.

1. Choose an activity that can be repeated under nominally similar instructions. Preparing coffee fits because one cup can taste different from the next.
2. Identify measurable or controllable sources: water temperature changes extraction, brewing time changes contact with the grounds, and the amount of coffee changes concentration.
3. Connect each source to an outcome rather than simply listing unrelated kitchen conditions.

Check: the answer explains **why repetitions differ**, which is what the definition of variability requires.
::::
:::

:::problem[Problem 1.2 — Aluminum mounting brackets]{difficulty=standard}
A company manufactures aluminum mounting brackets for agricultural equipment. Two drilled holes must be precisely located, and overall width must stay within specification. Aluminum sheets arrive from a supplier; the factory cuts, forms, drills, and inspects the brackets. Some brackets need rework because of improper hole placement or width, although the drawings, machines, and operating procedures have not intentionally changed. (a) Identify three potential sources of variability in dimensions or fit. (b) Which source would be easiest to remove or control, and why?

::::solution[Solution]
**Answer:** Possible sources are incoming-sheet differences, fixture or machine calibration, and tool wear. A calibration or setup error is a reasonable first source to correct.

1. **Incoming material:** thickness, temper, and flatness can vary among aluminum sheets and influence forming and subsequent dimensions.
2. **Machine setup:** a misaligned drilling fixture or incorrect calibration can shift hole positions even when the drawing is unchanged.
3. **Equipment wear:** worn tooling or a changing press condition can shift hole size or bracket width across a production run.
4. A reproducible calibration problem is often the most immediately controllable: inspect against a reference, correct the setting, and verify the next brackets. Wear usually requires maintenance or replacement, while supplier variability may require acceptance controls.

Check: there is no universally easiest source without plant-specific evidence; the answer gives a defensible intervention and explains its limits.
::::
:::

:::problem[Problem 1.3 — A repeated connector force]{difficulty=easy}
The measured pull-off forces of eight $3/32$-inch-wall nylon connectors, in pounds, are $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$. How many observations must be plotted at $12.6$ pounds on a dot diagram?

::::solution[Solution]
**Answer:** 2.

1. A dot diagram requires one dot for each observation, even when two observations have identical values.
2. Read the force list from left to right. The first entry is $12.6$, and the seventh entry is also $12.6$; no other entry matches.
3. Put two dots at the same horizontal coordinate and stack them vertically so both remain visible.

Check: counting those two dots plus the six other readings gives the original eight observations.
::::
:::

:::problem[Problem 1.4 — Force below a threshold]{difficulty=standard}
The measured connector forces, in pounds, are $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$. How many of these observations are below $13.0$ pounds?

::::solution[Solution]
**Answer:** 4.

1. The word **below** calls for strictly less than $13.0$, so a value equal to $13.0$ would not count.
2. The readings meeting that condition are $12.6$, $12.9$, $12.3$, and the second $12.6$.
3. Count all four observations, including the repeated value. The other four readings are above the threshold.

Check: four below and four not below account for the eight prototypes; a count from a small prototype set is not itself a population failure rate.
::::
:::

:::problem[Problem 1.5 — What the plot can establish]{difficulty=standard}
A technician makes a dot diagram of the eight connector forces. Another technician says, "The diagram proves that every connector manufactured with this design will have a pull-off force between the smallest and largest plotted values." Is that conclusion justified?

::::solution[Solution]
**Answer:** No. The diagram describes the measured prototypes, not every future connector.

1. Identify the evidence: eight prototypes were measured, so the plotted values are observations from a limited sample.
2. Identify the claim: the technician is asserting something about every connector the process will ever manufacture.
3. The future process can produce new values that did not appear among the eight tested units, especially if material or process conditions change.

Check: the statement crosses from a description of observed data to an unjustified guarantee about unobserved production.
::::
:::

:::problem[Problem 1.6 — Reaction to one unusual reading]{difficulty=challenge}
In the Deming funnel exercise, a ball lands far to the right of the target on one attempt. A student immediately moves the funnel to the left by the same distance. Explain why this correction may be a poor idea, even if the next ball then lands nearer the target.

::::solution[Solution]
**Answer:** One miss is not sufficient evidence of a persistent offset; adjusting after it can amplify random variation.

1. The ball's landing point can change from drop to drop when the funnel has not moved. That is exactly the variability the demonstration highlights.
2. A single error to the right does not establish that the equipment is consistently aimed too far right.
3. Moving left changes the process setting in response to possible noise. One improved landing can happen by chance and does not validate the correction rule.

Check: compare stability across many attempts using each strategy, not the success of one selected drop.
::::
:::

## 1.2 Populations, Samples, and Inference

One factory can manufacture thousands of brackets, but inspecting every bracket destructively may be impossible. A city may have millions of drivers, but only some can be surveyed. Statistics makes these problems manageable by separating **the group we want to know about** from **the group we actually observe**. The first is the population. The second is the sample. Then we decide what conclusions the observations justify.

:::callout-intuition[The direction of inference]
Think of a sample as a window, not the whole building. If you inspect a few windows of a building, you learn something about the building, but only if those windows were chosen in a way that gives you a fair view. A hundred windows selected because they are easy to reach may be less informative than a smaller, carefully chosen sample from every side.
:::

:::definition[Definition 1.4 — Population]
The **population** is the complete collection of individuals, objects, or outcomes about which the research question asks. The population must be defined by the question: all brackets from a given shift, all future connectors of a design, or all students enrolled in a course are different populations.
:::

:::definition[Definition 1.5 — Sample]
A **sample** is the subset of a population from which data are actually collected. The number observed is its sample size $n$. A **census** attempts to include every member of the population instead of only a subset.
:::

:::definition[Definition 1.6 — Parameter and statistic]
A **parameter** is a numerical characteristic of a population. A **statistic** is a numerical characteristic calculated from a sample. Common notation later in the course is $\mu$ and $\sigma$ for population quantities and $\bar{x}$ and $s$ for sample quantities. The Final sheet, page 1, displays formulas for $\bar{x}$ and $s^2$; the actual calculations belong to Chapter 2.
:::

:::definition[Definition 1.7 — Statistical inference]
**Statistical inference** uses evidence from a sample to make a judgment about the population from which that sample was obtained. Inference necessarily acknowledges uncertainty because different reasonable samples may yield different information.
:::

A **description** summarizes the observed sample: "the measured connectors had different pull-off forces." An **inference** goes beyond those connectors: "the process generally produces variable pull-off force." One sentence changes the target of the claim. That small wording difference is a frequent matching or true/false trap.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 650 205" width="650" height="205" role="img" aria-label="Many population members at left, a selected smaller sample at right, and an inference arrow back toward the population">
<rect class="fig-guide" x="18" y="19" width="285" height="151" rx="15"/>
<rect class="fig-guide" x="466" y="40" width="165" height="112" rx="15"/>
<circle class="fig-gridline" cx="45" cy="48" r="4"/>
<circle class="fig-gridline" cx="45" cy="78" r="4"/>
<circle class="fig-gridline" cx="45" cy="108" r="4"/>
<circle class="fig-gridline" cx="45" cy="138" r="4"/>
<circle class="fig-gridline" cx="86" cy="48" r="4"/>
<circle class="fig-point" cx="86" cy="78" r="4"/>
<circle class="fig-gridline" cx="86" cy="108" r="4"/>
<circle class="fig-gridline" cx="86" cy="138" r="4"/>
<circle class="fig-gridline" cx="127" cy="48" r="4"/>
<circle class="fig-gridline" cx="127" cy="78" r="4"/>
<circle class="fig-gridline" cx="127" cy="108" r="4"/>
<circle class="fig-point" cx="127" cy="138" r="4"/>
<circle class="fig-point" cx="168" cy="48" r="4"/>
<circle class="fig-gridline" cx="168" cy="78" r="4"/>
<circle class="fig-gridline" cx="168" cy="108" r="4"/>
<circle class="fig-gridline" cx="168" cy="138" r="4"/>
<circle class="fig-gridline" cx="209" cy="48" r="4"/>
<circle class="fig-gridline" cx="209" cy="78" r="4"/>
<circle class="fig-point" cx="209" cy="108" r="4"/>
<circle class="fig-gridline" cx="209" cy="138" r="4"/>
<circle class="fig-gridline" cx="250" cy="48" r="4"/>
<circle class="fig-point" cx="250" cy="78" r="4"/>
<circle class="fig-gridline" cx="250" cy="108" r="4"/>
<circle class="fig-gridline" cx="250" cy="138" r="4"/>
<circle class="fig-point" cx="490" cy="71" r="5"/>
<circle class="fig-point" cx="531" cy="70" r="5"/>
<circle class="fig-point" cx="574" cy="72" r="5"/>
<circle class="fig-point" cx="510" cy="119" r="5"/>
<circle class="fig-point" cx="563" cy="119" r="5"/>
<path class="fig-arrow" d="M315 81 L454 81 M444 74 L454 81 L444 88"/>
<path class="fig-arrow" d="M454 113 L315 113 M325 106 L315 113 L325 120"/>
<text class="fig-label" x="165" y="186" text-anchor="middle">Population: all relevant units</text>
<text class="fig-label" x="550" y="174" text-anchor="middle">Sample: observed units</text>
<text class="fig-label" x="383" y="70" text-anchor="middle">selection</text>
<text class="fig-label" x="383" y="133" text-anchor="middle">inference</text>
</svg>
<figcaption>Sampling moves from the population to measured units; inference reasons in the reverse direction and needs a defensible sampling method.</figcaption>
</figure>

### The four steps of a statistical investigation

The instructor gives the following sequence. First, **ask a question that can be answered by collecting data**. Second, **decide what to measure and collect the data**. Third, **summarize and analyze**. Fourth, **draw a conclusion and communicate the results**. These steps are not merely clerical. A badly specified question can make an excellent set of measurements useless, and a conclusion that does not state the target population can mislead its reader.

For the connector, the question might be whether the proposed design yields adequate installation strength. A useful measurement is pull-off force in pounds. The eight observations are the data. Displaying their spread summarizes what happened. A final conclusion must be qualified by the evidence: eight prototypes motivate further testing but do not certify every production unit. A question that cannot be answered with relevant measurements has not yet been made into a statistical question.

:::example[Example 1.4 — Population, sample, and inference]
An engineer wants to know whether all brackets produced during a month satisfy a dimension specification. She measures $25$ brackets selected from $500$ produced that month. Identify the population and sample, and what percentage of the month's brackets was inspected.

::::answer[Answer]
**Answer:** 5%.

1. The research question concerns **all $500$ brackets from the month**. Those brackets are the population, whether or not they were measured.
2. The engineer actually inspected **$25$ brackets**. That is the sample, with $n=25$.
3. The inspected share follows the ordinary part-of-whole rule: $25\div500\times100=5\%$. The percentage measures coverage, not whether selection was representative.
4. Any claim about the uninspected brackets is an inference and needs a defensible selection method.

Check: $5\%$ of $500$ is $25$ brackets, which matches the number inspected.
::::
:::

:::example[Example 1.5 — What is a census?]
A small laboratory defines its population as all $400$ connectors made in a particular batch and measures the pull-off force of all $400$ connectors. How many members of the defined population remain unmeasured, and is the data collection a sample survey or a census?

::::answer[Answer]
**Answer:** 0.

1. Define the target population before classifying the study. Here the target is only the $400$ connectors in the stated batch, not future connectors or the whole factory's history.
2. Subtract the number measured from the population count: $400-400=0$ connectors remain unmeasured.
3. Because every connector in the target batch was measured, this is a **census** of that batch.

Check: it would still be wrong to call this a census of all connectors the factory will ever make; the population boundary matters.
::::
:::

### How the sample is chosen matters

The slides contrast a **voluntary response sample** (people choose whether to respond), a **convenience sample** (the easiest people or objects are measured), and **random selection**. Voluntary response can overrepresent people with strong opinions. Convenience selection can overrepresent easy-to-access production shifts. A simple random sample is designed so every possible group of a specified size has the same chance to be selected. That also gives each individual an equal chance to be included.

Random selection helps prevent systematic selection bias, but it does **not** magically eliminate all bias. Nonresponse, faulty instruments, changing production conditions, and other measurement problems may remain. A larger randomly selected sample usually offers more stable information than a smaller one, but increasing the size of a severely biased convenience sample does not repair the way it was selected. The instructor emphasizes that for a large population the accuracy of a random sample depends much more on the sample size and method than on the sheer population count; that is a useful approximation, not a law for every situation.

:::definition[Definition 1.8 — Sampling bias]
A sample is **biased** when the selection or data-collection procedure systematically favors certain results or groups. A larger sample can reduce random fluctuation but cannot reliably cancel a systematic flaw in how observations are gathered.
:::

:::definition[Definition 1.9 — Simple random sample]
In a **simple random sample** of a fixed size, every possible subset of that size has an equal probability of selection. Random selection is different from assigning a treatment randomly *after* subjects have already been recruited; the latter is an experimental design decision.
:::

:::callout-pitfall[Population is not the same thing as sample]
The population is the **target**, not necessarily the largest number written in the problem. A census of one production batch is not a census of all future production. **Random selection** asks *who enters the study*; **random assignment** asks *who gets which treatment*. Do not swap them. Finally, "a large sample removes bias" is false: it can repeatedly measure the wrong group with great precision.
:::

### Practice: who and what are we studying?

:::problem[Problem 1.7 — Identify the target group]{difficulty=easy}
A company wants to estimate the typical pull-off force of every nylon connector produced next week. It tests a set of connectors made on Monday. Name the population and the sample, and say whether a statement about the entire week is descriptive or inferential.

::::solution[Solution]
**Answer:** The population is all connectors produced next week; the sample is the Monday connectors tested; a weekwide conclusion is inferential.

1. Read the words **every** and **next week** to locate the target of the question. That complete intended collection is the population.
2. Read **tests** to find the actually observed units. Those Monday connectors form the sample.
3. A sentence only about the tested units describes data. A statement applying their behavior to the rest of next week's production moves beyond the observations and makes an inference.

Check: neither the date of observation nor the number of tested units automatically changes the intended population.
::::
:::

:::problem[Problem 1.8 — Fraction of a batch inspected]{difficulty=standard}
A manufacturer produces $900$ identical-part-design brackets in one run and inspects $36$ of them. What percentage of the run has been inspected? Does this percentage alone prove that the sample is representative?

::::solution[Solution]
**Answer:** 4%.

1. The run of $900$ brackets defines the population for this question, while $36$ actually inspected brackets make up its sample.
2. Compute the part as a percentage of the whole: $36\div900\times100=4\%$.
3. The inspected fraction tells us the coverage but not **how** the brackets were selected. All $36$ could have come from an unusually stable part of the run.

Check: $900\times0.04=36$; representativeness still depends on the sampling method and measurement quality.
::::
:::

:::problem[Problem 1.9 — Parameter or statistic?]{difficulty=standard}
An inspector reports the mean hole spacing of $40$ sampled brackets. The production manager asks about the true mean hole spacing of every bracket produced during the shift. Which quantity is a statistic, which is a parameter, and why are they not interchangeable?

::::solution[Solution]
**Answer:** The sample mean is a statistic; the shiftwide true mean is a parameter.

1. The number calculated using only the $40$ inspected brackets describes the **sample**, so it is a statistic, normally written $\bar{x}$.
2. The desired mean over all brackets from the shift describes the **population**, so it is a parameter, normally written $\mu$.
3. The statistic can be used to estimate the parameter but need not equal it. Different selections of brackets could give different sample means.

Check: the symbols distinguish the source of each quantity, not whether either was calculated accurately.
::::
:::

:::problem[Problem 1.10 — Entire defined population]{difficulty=easy}
A quality engineer defines the population as the $600$ components in today's shipment and checks all $600$. How many components of **that defined population** remain unchecked, and what kind of coverage did the engineer achieve?

::::solution[Solution]
**Answer:** 0.

1. Use the population stated in the question: it consists of $600$ components, not every component ever produced by the supplier.
2. The number checked is also $600$, so the number unchecked is $600-600=0$.
3. Observing all members of a defined population is a **census**, even when that population is one shipment rather than a nationwide market.

Check: the classification would change if the claim instead concerned future shipments not included in this day's inspection.
::::
:::

:::problem[Problem 1.11 — Voluntary online poll]{difficulty=standard}
A university posts an optional online poll asking whether engineering students approve of a new lab schedule. Students with strong opinions are much more likely to participate. A student says a very large response count will eliminate the bias. Evaluate the claim.

::::solution[Solution]
**Answer:** False. Voluntary response can remain systematically biased even with many participants.

1. The desired group is all relevant engineering students, but the observed group consists only of people who choose to click and respond.
2. Students who feel strongly may respond at different rates from students who are indifferent. This creates a systematic distortion in the selected group.
3. More voluntary responses do not guarantee that quieter students become proportionally represented.

Check: a defined random sampling plan and measures against nonresponse would address the mechanism more directly than simply seeking more clicks.
::::
:::

:::problem[Problem 1.12 — A conclusion that goes too far]{difficulty=challenge}
A company selects connectors only from the most experienced operator's shift. All inspected connectors perform satisfactorily, so management announces, "Every connector from every operator meets specification." Identify the statistical reasoning problem and propose a better investigation.

::::solution[Solution]
**Answer:** The conclusion overgeneralizes from a potentially biased convenience sample.

1. The sample contains products made under one operator's conditions. The claim, however, covers all operators and their different working conditions.
2. Operator skill or shift-specific setup could affect quality. A successful result from the selected shift does not establish the same outcome elsewhere.
3. Define the full target population, choose units across operators using a defensible sampling design, and measure the same response under comparable conditions.

Check: a satisfactory observation is useful evidence about the measured units, not a universal guarantee about excluded units.
::::
:::

## 1.3 Observational Studies, Experiments, and Confounding

Suppose engineers discover that connectors with thicker walls have higher pull-off forces. Does that mean increasing thickness *caused* the higher force? The answer depends on how the data were collected. Perhaps the thicker connectors came from a different machine, operator, or batch of polymer. Those alternative explanations are **confounding**. A central Unit 1 skill is recognizing when data merely show an association and when a well-designed investigation can provide evidence about cause and effect.

:::callout-intuition[Watching is different from changing]
An **observational study** watches what happens without assigning a treatment. A **designed experiment** deliberately changes something to see what happens to the response. The two investigations may record exactly the same measurements, but they support different conclusions. If you are asked which method is best for a causal question, look for deliberate manipulation and controls on competing explanations.
:::

:::definition[Definition 1.10 — Observational study]
An **observational study** measures individuals, objects, or an operating system without deliberately assigning or changing the explanatory condition. It is useful for learning about populations and associations, but by itself it does not provide convincing evidence that one variable caused a change in another.
:::

:::definition[Definition 1.11 — Designed experiment]
A **designed experiment** deliberately changes an explanatory variable or assigns treatments, then measures the resulting response. Its aim is to obtain evidence about a potential **cause-and-effect** relationship. Strong experiments include controls for other influences and a way to account for chance differences.
:::

:::definition[Definition 1.12 — Retrospective study]
A **retrospective study** uses data from the past, such as previously recorded production or inspection records. "Uses historical data" identifies how information was obtained, not proof that the study was a randomized experiment.
:::

### Which variable is which?

A **variable** is a characteristic recorded about an individual or object. An **explanatory variable** is what may account for a change; it is also called the independent variable. A **response variable** is the measured outcome, also called the dependent variable. A **confounding variable** is an additional factor related to the proposed explanation that can also influence the response. It makes it difficult to separate the proposed cause from another possible cause.

For the connector, wall thickness could be explanatory and pull-off force the response. Molding temperature might be a confounding factor if a different wall thickness is consistently produced at a different temperature. If the engineer measures both designs but the thicker connectors were all made on another machine, the machine could also account for some observed difference. Simply naming a variable does not remove its effect; the study must be designed to address it.

:::definition[Definition 1.13 — Explanatory, response, and confounding variables]
The **explanatory variable** is a factor whose relation to an outcome we investigate. The **response variable** is the observed outcome. A **confounding variable** is an outside factor that changes with the explanatory condition and may influence the response, making the explanatory variable's independent effect difficult to determine.
:::

:::example[Example 1.6 — Observed association versus causation]
A manufacturing engineer notices that thicker nylon connectors have higher measured pull-off forces. The thicker units were made on the newest machine, while thinner units were made on an older machine. Identify the explanatory and response variables, a possible confounder, and the strongest justified conclusion.

::::answer[Answer]
**Answer:** Thickness is explanatory; pull-off force is the response; machine is a confounder. The observation alone does not establish causation.

1. The suspected factor is **wall thickness**, and the outcome measured to see whether it changes is **pull-off force**.
2. Machine type differs along with wall thickness. Differences in molding or machine settings could affect force independently of the thickness.
3. Because the explanatory factor is entangled with the machine, the higher observed forces may be caused by thickness, machine differences, or both.
4. A better-designed experiment would vary wall thickness under controlled, comparable manufacturing conditions.

Check: "associated with" is defensible; "proven to cause" overstates an observational comparison.
::::
:::

### Keeping alternative explanations under control

The instructor lists **direct control**, **random assignment**, **control or placebo groups**, and **blind conditions** as ways to reduce confounding. Direct control means keeping a relevant condition stable, such as using the same calibrated test instrument for every connector. Random assignment decides by chance which experimental units receive each treatment, so hidden differences are less likely to line up systematically with one treatment. A control group supplies a comparison without the active intervention. A placebo is a look-alike inactive treatment in settings where participants' expectations can matter. Blinding keeps participants, evaluators, or both from knowing the assigned condition when that knowledge might change behavior or measurement.

None of these methods guarantees that every result is caused by treatment. Chance variation remains, and badly implemented controls can still mislead. The strength of an experiment comes from making plausible alternative explanations harder to sustain, then analyzing whether the observed difference is beyond what chance might reasonably produce. The probability machinery for that last part comes in later chapters.

:::definition[Definition 1.14 — Random selection versus random assignment]
**Random selection** chooses *which members of a population enter a study* and supports representativeness. **Random assignment** chooses *which treatments the selected experimental units receive* and helps make the treatment groups comparable. A study can use either, both, or neither; the two are not synonyms.
:::

:::example[Example 1.7 — Designing a connector experiment]
An engineer wants to compare nylon connector wall thicknesses of $3/32$ inch and $1/8$ inch for their effect on pull-off force. Propose a design that gives stronger causal evidence than merely comparing two production records.

::::answer[Answer]
**Answer:** Deliberately produce both thicknesses under controlled conditions, randomly assign comparable units or production order to the thickness settings, and measure force consistently.

1. Name the explanatory variable as wall thickness and the response as pull-off force in pounds. Set up the comparison so the thickness is the deliberately changed condition.
2. Keep polymer grade, molding procedure, test equipment, and measurement protocol comparable; vary the order or assignment so an operator or time trend is not tied to one thickness.
3. Measure every test specimen by the same force procedure and compare the resulting responses while accounting for chance variability.
4. State the scope of the result: the experiment supports a causal interpretation for conditions represented by its design, not every untested environment.

Check: it is deliberate control and assignment, not merely plotting two groups on one dot diagram, that strengthens the causal argument.
::::
:::

### The two questions behind every research design

Ask **who was selected?** to evaluate whether results can reasonably represent the population. Ask **how were treatments assigned?** to evaluate causal evidence. A randomized experiment conducted only on one special production line may support a causal finding on that line but not necessarily generalize to every factory. A carefully randomized observational sample of a city may represent city residents but still not show whether a habit causes a disease. These are separate strengths, and a question can test one while hiding the other.

:::callout-pitfall[The three common causal traps]
First, **association is not automatically causation**. Second, **random selection is not random assignment**: selection addresses who is represented; assignment addresses comparability between treatments. Third, **retrospective** means historical, not necessarily experimental. A study can use old records and still be observational, while a present-day study can also be observational.
:::

### Practice: recognizing the research design

:::problem[Problem 1.13 — Look, do not intervene]{difficulty=easy}
A researcher observes the daily temperature and defect count of an operating assembly line for several weeks but does not change the temperature or any setting. Is the study observational or experimental, and what conclusion could it directly support?

::::solution[Solution]
**Answer:** Observational; it can identify an association, not prove that temperature causes defects.

1. Identify the researcher's action: recording existing conditions and outcomes without changing them is observation.
2. The possible explanatory variable is temperature, and the response variable is the observed defect count.
3. The two could vary together even if another influence, such as production speed, also changed with temperature.

Check: to support a stronger causal claim, a designed experiment would deliberately vary temperature while keeping competing influences controlled.
::::
:::

:::problem[Problem 1.14 — What is the response?]{difficulty=standard}
A company tests whether changing drill speed affects the distance between a bracket's two holes. It sets several drill speeds and measures hole spacing on each finished bracket. Identify the explanatory variable, response variable, and study type.

::::solution[Solution]
**Answer:** Drill speed is explanatory, measured hole spacing is the response, and the investigation is an experiment.

1. The variable deliberately set by the engineers is drill speed, so it is the explanatory or independent variable.
2. The measured outcome that might change in response is the distance between the holes, so it is the response or dependent variable.
3. Because the company actually selects the drill speeds instead of merely recording whatever speeds happened, the study has experimental manipulation.

Check: deliberately changing the cause candidate is the wording clue that distinguishes this from observation.
::::
:::

:::problem[Problem 1.15 — Recruitment versus treatment]{difficulty=standard}
An engineering school asks volunteers to try two study-room lighting conditions. A random number generator assigns each volunteer to one condition. Has the school used random selection, random assignment, both, or neither? Explain what the procedure does and does not establish.

::::solution[Solution]
**Answer:** Random assignment, but not random selection.

1. Volunteers decide whether they participate, so study membership is determined by self-selection rather than a random draw from all engineering students.
2. After recruitment, a random number generator decides which lighting condition each volunteer receives. That is random **assignment**.
3. Assignment helps compare lighting conditions within the recruited group, but volunteers may differ systematically from all engineering students.

Check: a sound treatment comparison among volunteers does not automatically yield a representative estimate for every student on campus.
::::
:::

:::problem[Problem 1.16 — Historical maintenance records]{difficulty=easy}
An engineer examines existing inspection records from the previous five years to investigate whether older drilling machines had more problems. No operating setting is deliberately changed. Identify the data collection method and whether it supports a direct causal conclusion.

::::solution[Solution]
**Answer:** Retrospective observational study; causal proof is not justified by the records alone.

1. The data already exist in files from previous years. This is the definition of a retrospective investigation.
2. The engineer is not assigning machine age, maintenance schedules, or other conditions. The work is observational.
3. Age might be associated with different maintenance histories, workloads, or operators, which may confound the observed pattern.

Check: using historical data can help find a promising hypothesis, but the date of the data does not substitute for controlled assignment.
::::
:::

:::problem[Problem 1.17 — Hidden confounder]{difficulty=standard}
A factory increases production speed at the same time it changes to a new supplier. Defects increase. Management says the supplier caused the increase. Identify the response, the competing explanation, and why the conclusion is not established.

::::solution[Solution]
**Answer:** Defect occurrence or count is the response; production speed is a possible confounder.

1. Management wants to explain the increase in defects, so defects are the outcome being measured.
2. Supplier choice and production speed changed together. Either could affect defect occurrence, and their separate effects cannot be identified from this one before-and-after change.
3. A defensible study would compare supplier materials under comparable production speeds or vary the factors systematically if feasible.

Check: observing a change after a supplier switch is not enough to isolate the supplier from the simultaneously changed speed.
::::
:::

:::problem[Problem 1.18 — Stronger causal evidence, weak generalization]{difficulty=challenge}
An engineer randomly assigns prototype connectors from one laboratory production batch to two controlled test conditions. One condition produces higher average pull-off force. The engineer claims this proves the same effect for every connector made by every factory. Evaluate separately the causal conclusion and the population-wide conclusion.

::::solution[Solution]
**Answer:** The controlled random assignment strengthens causal evidence for the tested setting, but the universal population claim is unsupported.

1. Randomly assigning the prototypes to test conditions makes hidden pre-existing differences less likely to systematically favor one condition, which improves causal interpretation.
2. Controlled measurement further helps isolate the condition being studied. The observed difference may still contain chance variation.
3. The units came from one laboratory batch, not a representative selection of all factories and operating conditions. Generalizing the effect everywhere requires evidence about those broader conditions.

Check: strong internal causal design and broad population representativeness answer different questions.
::::
:::

## Chapter Summary

:::summary[Unit 1 distinctions to know cold]
**Statistics** collects, presents, analyzes, and uses data to make decisions. **Variability** means repeated results differ. A **random variable** is a numerical result that can vary; the slide's $X=\mu+\varepsilon$ describes a fixed component plus random disturbance, not a calculation to memorize.

The **population** is the complete group of interest; the **sample** is the observed subset; a **census** attempts to observe everyone in the defined population. A **parameter** describes the population, while a **statistic** describes a sample. **Inference** uses sample data to draw a conclusion about the population and therefore carries uncertainty.

An **observational study** records conditions as found. A **retrospective study** uses historical records. A **designed experiment** deliberately changes an explanatory variable to study its effect on a response. A **confounder** offers an alternative explanation for the response. **Random selection** improves population representation; **random assignment** improves treatment-group comparability. Neither is a license to ignore other weaknesses in the study.

For a multiple-choice question, first mark the target population, the observed group, the variable deliberately changed if any, and the actual response. Then ask whether the conclusion stays within what those observations and that design can support.
:::

## Mixed Practice

These questions use the final exam's **true/false (three parts), matching (four parts), and multiple-choice** formats. The Unit 1 material is primarily conceptual, so its calculation items concern only direct counting and sample coverage; formulas and probability calculations from other units are deliberately excluded.

:::problem[Problem M.1 — True or false: language of inference]{difficulty=standard}
Mark each claim **True** or **False**.

(a) A sample statistic necessarily equals its corresponding population parameter.

(b) Repeated measurements can differ even if the process settings are not deliberately changed.

(c) A census of today's shipment also measures every component the factory will ever produce.

::::solution[Solution]
**Answer:** (a) False; (b) True; (c) False.

1. Claim (a) is false because a statistic is computed from observed sample members, whereas the parameter describes the entire target population. Random selection does not guarantee equality.
2. Claim (b) is true: natural disturbances, equipment conditions, and measurement noise cause variability among repeated observations.
3. Claim (c) is false because the defined population for a census matters. Inspecting all of today's shipment does not include future production.

Check: neither a large sample nor complete coverage of a narrow batch automatically proves a statement about a broader population.
::::
:::

:::problem[Problem M.2 — Matching: four key terms]{difficulty=easy}
Match each term to one description. Terms: **A. Population; B. Sample; C. Statistical inference; D. Variability.**

(i) Differences among nominally repeated measurements.

(ii) The entire set of parts about which a question asks.

(iii) Drawing a conclusion about unobserved parts using observed ones.

(iv) The particular parts from which measurements were collected.

::::solution[Solution]
**Answer:** (i) D; (ii) A; (iii) C; (iv) B.

1. Differences from one measurement to another define **variability**, so (i) matches D.
2. The **entire target set** is the population, which makes (ii) A.
3. Moving from observed parts to a statement about unobserved parts is **inference**, which makes (iii) C.
4. The observed subset is the **sample**, so (iv) B.

Check: the terms distinguish four roles: change in outcomes, target, reasoning, and observed evidence. Do not interchange target and evidence.
::::
:::

:::problem[Problem M.3 — Multiple choice: target population]{difficulty=easy}
An engineer tests several parts made on Tuesday to learn about **all** parts manufactured during the entire week. Which group is the population?

(A) Only the tested Tuesday parts

(B) Every part manufactured during the week

(C) Only the parts that failed testing

(D) Only parts that were easy to reach

::::solution[Solution]
**Answer:** (B).

1. The target wording is **all parts during the week**, so (B) gives the complete population of interest.
2. (A) is the sample if those were the tested units. (C) would be an outcome-selected subset, not the stated target.
3. (D) describes a possible convenience sample; ease of access does not redefine the population.

Check: locate the group management wants to draw conclusions about before locating the observed units.
::::
:::

:::problem[Problem M.4 — Multiple choice: duplicate observations]{difficulty=standard}
Eight connector pull-off forces in pounds are $12.6, 12.9, 13.4, 12.3, 13.6, 13.5, 12.6, 13.1$. How many dots should appear on the plot at exactly $12.6$ pounds?

(A) 1

(B) 2

(C) 3

(D) 8

::::solution[Solution]
**Answer:** (B) 2.

1. Read the eight forces in order and locate values equal to $12.6$. The value appears first and seventh, so two observations occupy that horizontal location.
2. (A) mistakenly counts distinct numerical values rather than individual readings. (C) adds a reading that does not equal $12.6$.
3. (D) is the total number of measured connectors, not the number with this particular result.

Check: two dots at $12.6$ plus six other dots total eight.
::::
:::

:::problem[Problem M.5 — Multiple choice: sample fraction]{difficulty=standard}
A production run contains $900$ brackets. Engineers select $36$ for inspection. What percent of that run was inspected?

(A) 0.4%

(B) 4%

(C) 25%

(D) 40%

::::solution[Solution]
**Answer:** (B) 4%.

1. Identify the whole run as $900$ brackets and the inspected sample as $36$ brackets.
2. Divide the selected number by the total, then convert to a percentage: $36\div900\times100=4\%$.
3. (A) places the decimal one position too far left; (C) reverses or misuses the ratio; (D) moves the decimal one position too far right.

Check: $4\%$ of $900$ gives $36$, so the fraction is consistent with the statement.
::::
:::

:::problem[Problem M.6 — Multiple choice: cause-and-effect]{difficulty=standard}
A company sees more defects on nights with high production speed. No speed setting was assigned or changed by the investigator. What is the strongest defensible conclusion?

(A) High speed definitely causes defects.

(B) The study is a controlled experiment.

(C) Speed and defects may be associated, but other factors could explain the pattern.

(D) There is no variability because all observations came from one factory.

::::solution[Solution]
**Answer:** (C).

1. The researcher only observes existing conditions, so this is an observational study that can suggest an association.
2. (A) asserts causation without controlling for factors such as staffing and machine temperature. (B) incorrectly labels watching as experimental manipulation.
3. (D) ignores that repeated outcomes in one factory can vary substantially.

Check: (C) preserves the useful evidence without ruling out confounding or chance differences.
::::
:::

:::problem[Problem M.7 — Multiple choice: what is a census?]{difficulty=easy}
The target population is the $400$ connectors in a particular batch. An engineer measures all $400$. How many target-population connectors were omitted?

(A) 0

(B) 1

(C) 40

(D) 400

::::solution[Solution]
**Answer:** (A) 0.

1. The target population is defined as the $400$ connectors in the batch. The problem says every one was measured.
2. Subtract the observed count from the total: $400-400=0$ omissions, making this a census of that batch.
3. (B) invents an omission. (C) silently assumes a smaller inspected count, while (D) mistakes the entire population for an unobserved remainder.

Check: complete coverage of this batch says nothing about unmade future batches.
::::
:::

:::problem[Problem M.8 — Multiple choice: random assignment]{difficulty=challenge}
Volunteers are recruited from one shift. A computer randomly assigns them to two safety-training methods. Which claim is best supported by the design?

(A) Both treatment groups were formed by random assignment, but volunteers may not represent all shifts.

(B) All factory workers were randomly selected.

(C) Random assignment eliminates every possible measurement error.

(D) Because volunteers were used, the treatment comparison can never be informative.

::::solution[Solution]
**Answer:** (A).

1. Volunteers were not drawn randomly from every shift, so the participant pool may not represent all workers.
2. The computer does randomly allocate the recruited people between treatments, supporting group comparability and a stronger causal comparison.
3. (B) confuses recruitment and assignment; (C) falsely promises perfect measurements; (D) wrongly rejects the possible value of a controlled comparison among volunteers.

Check: distinguish validity for the treated study group from generalization to an unrepresented population.
::::
:::

:::problem[Problem M.9 — Multiple choice: past data]{difficulty=standard}
An engineer uses last year's maintenance and inspection records to look for an association between drill age and misplaced holes. The machines are not altered. What kind of investigation is described?

(A) Designed experiment with random assignment

(B) Retrospective observational study

(C) Census of all future production

(D) Placebo-controlled trial

::::solution[Solution]
**Answer:** (B).

1. **Last year's records** identifies a retrospective source, and **machines are not altered** identifies observation rather than experimental intervention.
2. (A) and (D) invent treatments and assignment that never occurred. (C) invents coverage of future parts, which historical records cannot supply.
3. The records may reveal a pattern and help plan a more targeted investigation, but several factors may have changed with machine age.

Check: (B) describes both the historical source and the non-interventional design accurately.
::::
:::

:::problem[Problem M.10 — Multiple choice: strongest inference]{difficulty=challenge}
A supervisor measures only the easiest-to-reach brackets. The measurements look consistent, and the supervisor concludes the entire month's production must be consistent. What is the most important defect in this reasoning?

(A) The sample size must always equal the population size.

(B) The supervisor should have used a $t$ table.

(C) Convenience selection may bias the sample, undermining population-wide inference.

(D) Repeated measurements are impossible when the procedure is fixed.

::::solution[Solution]
**Answer:** (C).

1. The claim extends from selected brackets to the entire month's output, so the issue is whether the sample fairly represents the population.
2. Selecting only easy-to-reach units may exclude time periods or production conditions associated with less consistent results.
3. (A) incorrectly requires a census for inference. (B) introduces a later-unit technique without solving selection bias. (D) denies the variability seen in ordinary engineering work.

Check: the sampling mechanism must support generalization before numerical analysis can make that conclusion credible.
::::
:::
