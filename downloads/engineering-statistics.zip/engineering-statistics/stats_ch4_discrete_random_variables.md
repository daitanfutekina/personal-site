---
title: "Discrete Random Variables"
crumb: "Engineering Statistics · Chapter 4"
meta:
  - "Est. study time: ~300 min"
  - "IE 4613 · Unit 4"
source: "markdown"
---

## Overview

A random experiment can produce a number without anyone measuring a length or a time. A circuit may contain two failed joints; a shift may contain three retrieval errors; a day may bring four calls. The *random variable* is the rule that converts the outcome into a number. Its probability distribution tells us which numbers are plausible, and the distribution's mean and standard deviation describe its long-run behavior.

You need two levels of skill. First, given a small table, calculate individual and cumulative probabilities, the mean, variance, and standard deviation without confusing their meanings. Second, given ordinary wording, recognize when the count is binomial, when it is Poisson, when values are equally likely, and when the assumptions are missing. An especially important distinction is **what is being counted**: successes among a fixed number of independent trials suggest binomial; events in a fixed interval at a known rate suggest Poisson.

The Final sheet puts the general discrete formulas on **page 1** and the binomial and Poisson formulas in the four-distribution table on **page 2**. The Exam 2 sheet has a longer Table I on page 2. Neither sheet replaces the work of identifying a model, scaling a rate, or translating words like “at least” into an event. You will use a TI-30X IIS, not statistics software, so the steps below show finite sums and calculator-ready expressions rather than unexplained software commands.

:::callout-key[Prerequisites]
Be comfortable with multiplication of independent probabilities and complements such as $P(A')=1-P(A)$ from **Chapter 3, Probability**. Combinations $\binom{n}{r}$ appear on the Final sheet, page 1. This chapter uses those facts rather than re-teaching the entire probability chapter.
:::

## 4.1 Discrete Random Variables and Probability Mass Functions

:::callout-intuition[What does a number really count?]
Picture a robot that checks five sensors. Before the checks, the number of failed sensors is unknown. Afterward, that number is one of $0,1,2,3,4,5$. Those six possible **values** form a range; they are not probabilities. A probability mass function, or PMF, adds a second piece of information: how likely each value is. The symbol $X$ is the random variable before observing the result; a lowercase $x$ is one particular possible result. Thus $P(X=2)$ asks for the probability of the event “the robot detects exactly two failures,” not for a measurement with units.
:::

### Range, values, and what qualifies as discrete

:::definition[Definition 4.1 — Discrete random variable]
A **random variable** assigns a numerical value to the outcome of a random experiment. It is **discrete** when its possible values form a finite or countably infinite set, such as $\{0,1,2,\ldots\}$. A discrete variable need not have consecutive integer values; a variable taking only $\frac14,\frac38,\frac12,\frac34$ is also discrete.
:::

A count is discrete, even if the possible count is enormous. “Number of manufacturing defects,” “number of arrivals,” and “number of questions correct” are the common clues. Temperature, travel time, thickness, and weight are measured quantities normally modeled as continuous. A proportion can be discrete when it means a count divided by a fixed sample size: with four components, the possible defective proportions are $0,0.25,0.50,0.75,1$ rather than every real number between zero and one.

To determine a range, ask **what is the smallest possible result and what is the largest?** Then ask whether everything between them is attainable. For two paneling orders with thicknesses in multiples of one eighth inch, the possible total thicknesses come from the nine ordered choices, but several choices produce the same total; you must remove duplicates.

:::definition[Definition 4.2 — Probability mass function]
For a discrete random variable $X$, the probability mass function is

$$
f(x_i)=P(X=x_i).
$$

A valid PMF has $f(x_i)\ge0$ for every possible $x_i$, and $\sum_i f(x_i)=1$. Consequently, $0\le f(x_i)\le1$. The PMF identifies probability at **individual values**, not cumulative probability. The definition $f(x_i)=P(X=x_i)$ appears on the **Final sheet, page 1**; the two validity rules follow because individual event probabilities cannot be negative and the mutually exclusive values exhaust all possible outcomes.
:::

When you receive a PMF table, check its probabilities add to one *before* doing anything else. If a table's entries add to $0.93$, there is either a missing outcome or a faulty model. Do not normalize a faulty distribution without being instructed to; identifying that it is invalid may be the entire question.

### Two wafers: outcomes first, numbers second

If two wafers pass independently with probability $0.8$, an individual pass is not the same event as “exactly one pass in two tests.” There are **two ordered ways** to get exactly one pass: pass then fail, or fail then pass. They cannot occur simultaneously, so their probabilities add. This is the reason a probability distribution for a count may differ greatly from a single-trial probability.

:::example[Example 4.1 — Two semiconductor wafers]
Two wafers from a semiconductor lot are independently classified as pass or fail, and each passes with probability $0.8$. Let $X$ be the number passing. Complete the outcome probabilities and the PMF.

| Ordered outcomes | Pass, pass | Fail, pass | Pass, fail | Fail, fail |
|:--|:--:|:--:|:--:|:--:|
| $X$ | 2 | 1 | 1 | 0 |

::::answer[Answer]
**Answer:** (a) $f(0)=0.0400$, (b) $f(1)=0.3200$, (c) $f(2)=0.6400$

1. **Find each ordered outcome.** Passing has probability $0.8$ and failing $0.2$. Independence gives $P(PP)=0.8(0.8)=0.64$, $P(FP)=0.2(0.8)=0.16$, $P(PF)=0.8(0.2)=0.16$, and $P(FF)=0.2(0.2)=0.04$.
2. **Group by the value of $X$.** The zero-pass row consists only of $FF$, giving $f(0)=0.04$. The one-pass row combines $FP$ and $PF$, giving $f(1)=0.16+0.16=0.32$. The two-pass row is $PP$, giving $f(2)=0.64$.
3. **Check the mass.** $0.04+0.32+0.64=1.00$. In context, there is a $32\%$ chance exactly one of the two wafers passes.

Check: All four outcome probabilities add to one, and the grouped PMF adds to one.
::::
:::

:::example[Example 4.2 — Digital-channel PMF]
Let $X$ be the number of bits in error in the next four bits sent through a digital transmission channel. The given probabilities are $P(X=0)=0.6561$, $P(X=1)=0.2916$, $P(X=2)=0.0486$, $P(X=3)=0.0036$, and $P(X=4)=0.0001$. State $f(x)$ and verify the probabilities.

| $x$ | 0 | 1 | 2 | 3 | 4 |
|:--|:--:|:--:|:--:|:--:|:--:|
| $f(x)$ | 0.6561 | 0.2916 | 0.0486 | 0.0036 | 0.0001 |

::::answer[Answer]
**Answer:** $f(0)=0.6561$, $f(1)=0.2916$, $f(2)=0.0486$, $f(3)=0.0036$, $f(4)=0.0001$

1. The probability mass function is simply the table's second row: $f(0)=P(X=0)$, and similarly for each remaining integer. No new probability calculation is required because all five point probabilities are already supplied.
2. Test validity without skipping entries: $0.6561+0.2916+0.0486+0.0036+0.0001=1.0000$. Every entry lies between zero and one.
3. These numbers mean that zero bit errors are much more likely than several errors in a four-bit message. The height of each PMF stem equals exactly its probability.

Check: The five displayed probabilities total $1.0000$.
::::
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Discrete bit-error probability mass function for four bits and error probability one tenth">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.56 H 626"/>
<text class="fig-label" x="2" y="110.56">0.377</text>
<path class="fig-gridline" d="M 48 19.89 H 626"/>
<text class="fig-label" x="2" y="23.89">0.755</text>
<path class="fig-curve" d="M 105.80 193 V 42.57"/>
<circle class="fig-point" cx="105.80" cy="42.57" r="3"/>
<text class="fig-label" x="105.80" y="211">0</text>
<path class="fig-curve" d="M 221.40 193 V 126.14"/>
<circle class="fig-point" cx="221.40" cy="126.14" r="3"/>
<text class="fig-label" x="221.40" y="211">1</text>
<path class="fig-curve" d="M 337.00 193 V 181.86"/>
<circle class="fig-point" cx="337.00" cy="181.86" r="3"/>
<text class="fig-label" x="337.00" y="211">2</text>
<path class="fig-curve" d="M 452.60 193 V 192.17"/>
<circle class="fig-point" cx="452.60" cy="192.17" r="3"/>
<text class="fig-label" x="452.60" y="211">3</text>
<path class="fig-curve" d="M 568.20 193 V 192.98"/>
<circle class="fig-point" cx="568.20" cy="192.98" r="3"/>
<text class="fig-label" x="568.20" y="211">4</text>
</svg>
<figcaption>The probability mass function has one vertical stem at each possible bit-error count; here $f(0)=0.6561$ is far taller than $f(4)=0.0001$.</figcaption>
</figure>

### When two trials do not have the same success probability

A random variable may be discrete without having a binomial distribution. In particular, the two knees in the meniscus-surgery exercise have **different** success probabilities, and independent trials need not be identically distributed. If the left knee succeeds with probability $p$ and the right with probability $q$, the probabilities of zero, one, and two successes are $(1-p)(1-q)$, $p(1-q)+(1-p)q$, and $pq$. These arise directly by multiplying the probabilities of independent outcomes. None of this requires introducing a new named distribution.

:::example[Example 4.3 — Meniscus surgeries with unequal probabilities]
A surgical article reports a success rate **more than $90\%$** for meniscal tears with rim width under $3$ mm and a $67\%$ success rate for widths between $3$ and $6$ mm. A patient has one operation of each type, on different knees; assume independence. Let $X$ be the number of successful surgeries. Determine its PMF without silently replacing “more than” by “equals.”

::::answer[Answer]
**Answer:** The distribution depends on the unknown left-knee success probability.

1. Set $p=P(\text{left succeeds})$, where the information gives only $0.90<p\le1$, and set $q=P(\text{right succeeds})=0.67$. The two success rates are not equal.
2. Neither succeeds when both operations fail, so $f(0)=(1-p)(0.33)$. Exactly one succeeds in either of two disjoint ways: $f(1)=p(0.33)+(1-p)(0.67)$. Both succeed with probability $f(2)=0.67p$.
3. Adding the expressions gives $1$. Because $p$ is not supplied exactly, no exact decimal PMF exists. In context, two successful surgeries have probability strictly greater than $0.603$ and at most $0.67$.

Check: The three symbolic masses add to one for every admissible $p$.
::::
:::

### Sampling without replacement is still discrete

A manufactured batch may contain a known number of defective components, with a small sample drawn **without replacement**. The number of defective parts is a discrete random variable, but the success probabilities change after each draw. For a two-item sample, use combinations from Chapter 3 instead of pretending the draws are independent. Counting good-good, good-bad, and bad-bad outcomes gives all possible counts. The Final sheet has $\binom nr$ on page 1, but does not have a named without-replacement distribution formula; what follows is simply favorable unordered pairs divided by all unordered pairs.

:::example[Example 4.4 — Two parts from a finite production batch]
A day's production of $850$ parts contains $50$ nonconforming parts. Two parts are selected **without replacement**. Let $X$ be the number of nonconforming parts. Find $f(0),f(1),f(2)$ as the starting point for a cumulative distribution.

Treat the $800$ remaining parts as conforming.

::::answer[Answer]
**Answer:** (a) 0.885748, (b) 0.110857, (c) 0.003395

1. Count the total unordered samples of two: $\binom{850}{2}=360825$. A sample with no nonconforming parts selects both from $800$ conforming parts, so $f(0)=\binom{800}{2}/360825=319600/360825=0.885748$.
2. Exactly one nonconforming part means selecting one of $50$ defective and one of $800$ conforming parts: $f(1)=(50)(800)/360825=0.110857$.
3. Exactly two means selecting both from the $50$ nonconforming parts: $f(2)=\binom{50}{2}/360825=1225/360825=0.003395$.
4. These values total one to rounding. In a random sample of two from this batch, about $88.6\%$ of samples will contain no nonconforming part.

Check: The counts $319600+40000+1225=360825$ partition all two-part samples.
::::
:::

:::callout-pitfall[Three common PMF mistakes]
A possible value like $X=4$ is not itself a probability. Adding outcome probabilities for two different values is appropriate only when the question asks for either value; multiplying them is wrong because $X$ cannot equal two different values simultaneously. Finally, independent draws and draws without replacement are different experiments. In the production example, the second draw is affected by the first. Reject a binomial model unless its assumptions hold.
:::

### Practice: ranges, outcomes, and a valid mass function

:::problem[Problem 4.1 — Voice-line range]{difficulty=easy}
A business voice-communication system has $48$ external lines. At one particular time, $X$ is the number of lines in use. Is $X$ discrete or continuous? What values can $X$ take, and if ten lines are in use, what is $x$?

::::solution[Solution]
**Answer:** range 0 to 48; observed value 10

1. The variable counts lines, so it is discrete. A count cannot be negative, and more than $48$ lines cannot be in use when the business has only $48$ external lines.
2. Its range is $0,1,2,\ldots,48$. If ten lines are being used, the realized value is lowercase $x=10$; the random variable itself is written uppercase $X$.
3. No probability distribution was supplied, so we cannot infer the chance that exactly ten lines are used. The range and the PMF are distinct information.

Check: The claimed range has $49$ integers, with both the no-lines-used and all-lines-used cases included.
::::
:::

:::problem[Problem 4.2 — Solder connections]{difficulty=easy}
A printed circuit board has $1000$ solder connections. Let $X$ be the number of nonconforming connections. Determine the complete possible range, assuming any number of connections may fail.

::::solution[Solution]
**Answer:** range 0 to 1000

1. This is a count of defects, so the smallest possible count is zero when all solder connections conform to requirements.
2. The largest possible count is $1000$ when none of the solder connections conforms. Every integer between these two extremes is an attainable count.
3. Therefore $X$ takes $0,1,2,\ldots,1000$. This does not mean all values have equal probability. An additional manufacturing failure model would be necessary to assign probabilities.

Check: The extremes correspond to none and all of the connections failing.
::::
:::

:::problem[Problem 4.3 — Wood-paneling total thickness]{difficulty=standard}
Wood paneling may be ordered in thicknesses $1/8$, $1/4$, or $3/8$ inch. The random variable $X$ is the combined thickness of paneling in two orders. Determine its possible values.

::::solution[Solution]
**Answer:** thicknesses 0.2500, 0.3750, 0.5000, 0.6250, 0.7500 inches

1. Express the three thicknesses in eighths of an inch: $1/8,2/8,3/8$. With two orders, the smallest total is $1/8+1/8=2/8$, and the largest is $3/8+3/8=6/8$.
2. The intervening totals $3/8$, $4/8$, and $5/8$ are attainable by pairing allowed thicknesses. Thus $X$ has values $1/4,3/8,1/2,5/8,3/4$ inch.
3. Several pairings yield the same total, which matters when probabilities are later assigned. The output is discrete even though its numerical values are fractions.

Check: Every total is an eighth-inch multiple between two and six eighths.
::::
:::

:::problem[Problem 4.4 — Nonconforming parts in a small sample]{difficulty=standard}
A batch of $500$ machined parts includes $10$ nonconforming parts. A sample of $5$ parts is drawn without replacement, and $X$ counts nonconforming parts in the sample. Determine the possible range of $X$.

::::solution[Solution]
**Answer:** range 0 to 5

1. Because the sample contains only five parts, the sample cannot include more than five nonconforming parts. The batch does contain ten nonconforming parts, so selecting five of them is possible.
2. The batch has $490$ conforming parts, so a sample of all conforming parts is also possible. Counts of one, two, three, or four nonconforming parts lie between these extremes.
3. The range is $0,1,2,3,4,5$. Without-replacement sampling affects the probabilities of these counts, not the endpoints in this example.

Check: Both the all-conforming and all-nonconforming sample compositions are possible.
::::
:::

:::problem[Problem 4.5 — Parking-study variable types]{difficulty=standard}
You are studying the efficiency of student parking on MSU's campus. Give one discrete random variable and one continuous random variable that you could include in your study, and explain how you distinguished them.

::::solution[Solution]
**Answer:** One count and one measurement.

1. An appropriate discrete variable is the number of empty parking spaces in a designated lot at noon. It is an integer count with a finite range determined by that lot's capacity.
2. An appropriate continuous variable is the amount of time, measured in minutes, that a driver spends looking for a space. That is measured on a numerical scale rather than counted as whole objects.
3. Both choices vary randomly from observation to observation. Their distinguishing feature is the set of possible values, not whether the observations come from a study.

Check: The first example has integer values; the second can be represented by noninteger minutes.
::::
:::

:::problem[Problem 4.6 — Rejecting a faulty PMF]{difficulty=challenge}
A quality-inspection report gives the proposed PMF below. Is it a valid PMF? If not, identify what fails.

| $x$ | 0 | 1 | 2 | 3 |
|:--|:--:|:--:|:--:|:--:|
| $f(x)$ | 0.2000 | 0.3000 | 0.3200 | 0.1200 |

::::solution[Solution]
**Answer:** not a valid PMF

1. Every probability must be nonnegative. The row passes this first requirement because all entries are between zero and one.
2. Add the complete probability row: $0.20+0.30+0.32+0.12=0.94$, which is not one.
3. The distribution therefore leaves $0.06$ of probability unaccounted for. It could be missing an outcome or have a misreported entry. You cannot calculate a valid mean until the intended distribution is corrected, and you must not silently scale these entries.

Check: The total probability is $0.94$, which fails the required total of one.
::::
:::

## 4.2 Cumulative Probabilities and the Distribution Function

:::callout-intuition[Why a running total is different from a single bar]
When the digital-channel question says “three or fewer bits in error,” it is not asking about the probability at $x=3$. It asks you to collect the mutually exclusive possibilities $0,1,2,3$ and add their probabilities. As you move rightward through a PMF, you can keep a running total. That running total is the cumulative distribution function, abbreviated CDF. It answers *how much probability has accumulated up through this value?*
:::

### Translating event wording into cumulative probabilities

:::definition[Definition 4.3 — Cumulative distribution function]
For a discrete random variable $X$, the cumulative distribution function is

$$
F(x)=P(X\le x)=\sum_{x_i\le x} f(x_i).
$$

This definition is printed on the **Final sheet, page 1**. The sum means “add the probabilities of every allowable value no larger than $x$.” The argument $x$ may be noninteger even if $X$ only takes integers.
:::

The best habit is to write the included integer outcomes **before** calculating. “At most three,” “no more than three,” and “three or fewer” all mean $X\le3$. “More than three” means $X\ge4$ when counts are integers. “At least three” means $X\ge3$, so its complement is $X\le2$, **not** $X\le3$. Those two endpoints are one of the most common lost points on exam questions.

From the complement rule on the Final sheet, page 1, the upper-tail shortcut follows immediately: $P(X>k)=1-F(k)$. For an inclusive lower limit, $P(X\ge k)=1-F(k-1)$ because only $0,1,\ldots,k-1$ are excluded. For an inclusive interval, $P(a\le X\le b)=F(b)-F(a-1)$ when $X$ is integer-valued. These are not additional memorization formulas. They merely describe which bars get counted or removed.

A real-number cutoff can land between support values. For integer-valued $X$, $F(1.5)$ includes zero and one, but not two, even though $1.5$ itself is not a possible outcome. There is no smoothing between consecutive integer values: $F(x)$ is flat between jumps.

:::example[Example 4.5 — Digital-channel three or fewer errors]
For the digital-channel PMF $f(0)=0.6561$, $f(1)=0.2916$, $f(2)=0.0486$, $f(3)=0.0036$, and $f(4)=0.0001$, find $P(X\le3)$.

::::answer[Answer]
**Answer:** 0.9999

1. The phrase “three or fewer” includes four separate values, $X=0,1,2,3$. Using the cumulative definition, write the terms rather than hiding them inside summation notation.
2. Add $P(X\le3)=f(0)+f(1)+f(2)+f(3)=0.6561+0.2916+0.0486+0.0036=0.9999$.
3. A second check removes only four errors: $1-f(4)=1-0.0001=0.9999$. In context, almost every four-bit transmission has at most three errors, since the only excluded case is that all four bits are wrong.

Check: The complement and the direct sum agree.
::::
:::

:::example[Example 4.6 — A cutoff between the bars]
Use the digital-channel PMF $f(0)=0.6561$, $f(1)=0.2916$, $f(2)=0.0486$, $f(3)=0.0036$, and $f(4)=0.0001$ to calculate $F(1.5)=P(X\le1.5)$. Remember that $X$ can only equal $0,1,2,3,$ or $4$.

::::answer[Answer]
**Answer:** 0.9477

1. Write down the available outcomes no larger than $1.5$: zero errors and one error. The value $1.5$ is not itself a possible count and contributes no separate probability.
2. Therefore $F(1.5)=f(0)+f(1)=0.6561+0.2916=0.9477$.
3. The next jump occurs at $x=2$, where another $0.0486$ enters the running total. In context, about $94.77\%$ of four-bit transmissions have fewer than two errors.

Check: The value lies between zero and one and is smaller than $F(2)$.
::::
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Cumulative bit-error distribution as a step function for four transmitted bits">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.50 H 626"/>
<text class="fig-label" x="2" y="110.50">0.5</text>
<path class="fig-gridline" d="M 48 20.00 H 626"/>
<text class="fig-label" x="2" y="24.00">1</text>
<path class="fig-guide" d="M 48 193.00 H 105.80"/>
<path class="fig-curve" d="M 105.80 79.49 H 221.40"/>
<circle class="fig-point" cx="105.80" cy="79.49" r="3"/>
<circle class="fig-guide" cx="221.40" cy="79.49" r="3"/>
<text class="fig-label" x="105.80" y="211">0</text>
<path class="fig-curve" d="M 221.40 29.05 H 337.00"/>
<circle class="fig-point" cx="221.40" cy="29.05" r="3"/>
<circle class="fig-guide" cx="337.00" cy="29.05" r="3"/>
<text class="fig-label" x="221.40" y="211">1</text>
<path class="fig-curve" d="M 337.00 20.64 H 452.60"/>
<circle class="fig-point" cx="337.00" cy="20.64" r="3"/>
<circle class="fig-guide" cx="452.60" cy="20.64" r="3"/>
<text class="fig-label" x="337.00" y="211">2</text>
<path class="fig-curve" d="M 452.60 20.02 H 568.20"/>
<circle class="fig-point" cx="452.60" cy="20.02" r="3"/>
<circle class="fig-guide" cx="568.20" cy="20.02" r="3"/>
<text class="fig-label" x="452.60" y="211">3</text>
<path class="fig-curve" d="M 568.20 20.00 H 626.00"/>
<circle class="fig-point" cx="568.20" cy="20.00" r="3"/>
<text class="fig-label" x="568.20" y="211">4</text>
</svg>
<figcaption>The CDF stays level between integer error counts and jumps by exactly $f(x)$ at each allowed value.</figcaption>
</figure>

### Reading a CDF backward

A step-shaped graph can provide the PMF even when no probability table is shown. The size of a jump is the probability at that exact point. If a cumulative function rises from $0.2$ to $0.7$ at zero, the mass at zero is $0.7-0.2=0.5$. If it rises from $0.7$ to $1$ at two, the mass at two is $1-0.7=0.3$. The graph has a filled dot at the **start** of a new level and an open dot at the **end** of the previous level: a discrete CDF is right-continuous.

This graphical interpretation saves time even if you forget a formal rule. A CDF must never decrease, must stay between zero and one, and approaches one when all values have been included. If a purported CDF falls as $x$ increases, it cannot describe any probability distribution.

:::example[Example 4.7 — Recovering a PMF from a step CDF]
The CDF is $F(x)=0$ for $x<-2$; $F(x)=0.2$ for $-2\le x<0$; $F(x)=0.7$ for $0\le x<2$; and $F(x)=1$ for $x\ge2$. Find the PMF and the possible values of $X$.

::::answer[Answer]
**Answer:** $f(-2)=0.2000$, $f(0)=0.5000$, $f(2)=0.3000$

1. The first jump occurs at $x=-2$, from cumulative probability zero to $0.2$. Its jump size is $0.2-0=0.2$, so $f(-2)=0.2$.
2. At $x=0$, the CDF rises from $0.2$ to $0.7$. Hence $f(0)=0.7-0.2=0.5$.
3. At $x=2$, it rises from $0.7$ to $1$. Hence $f(2)=1-0.7=0.3$.
4. The only possible values are $-2,0,2$ and the three masses total one. The middle value occurs half the time in this model.

Check: Jump sizes $0.2+0.5+0.3=1$.
::::
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Three-jump cumulative distribution for possible values negative two zero and two">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.50 H 626"/>
<text class="fig-label" x="2" y="110.50">0.5</text>
<path class="fig-gridline" d="M 48 20.00 H 626"/>
<text class="fig-label" x="2" y="24.00">1</text>
<path class="fig-guide" d="M 48 193.00 H 144.33"/>
<path class="fig-curve" d="M 144.33 158.40 H 337.00"/>
<circle class="fig-point" cx="144.33" cy="158.40" r="3"/>
<circle class="fig-guide" cx="337.00" cy="158.40" r="3"/>
<text class="fig-label" x="144.33" y="211">-2</text>
<path class="fig-curve" d="M 337.00 71.90 H 529.67"/>
<circle class="fig-point" cx="337.00" cy="71.90" r="3"/>
<circle class="fig-guide" cx="529.67" cy="71.90" r="3"/>
<text class="fig-label" x="337.00" y="211">0</text>
<path class="fig-curve" d="M 529.67 20.00 H 626.00"/>
<circle class="fig-point" cx="529.67" cy="20.00" r="3"/>
<text class="fig-label" x="529.67" y="211">2</text>
</svg>
<figcaption>At $x=-2$, $0$, and $2$, the cumulative height jumps by $0.2$, $0.5$, and $0.3$, respectively; those jumps are the PMF.</figcaption>
</figure>

:::callout-pitfall[The one-unit endpoint error]
For an integer count, $P(X\ge3)=1-F(2)$, not $1-F(3)$; the latter computes strictly more than three. Likewise, $P(3\le X<7)$ stops at six, not at seven. Write the last included integer before you substitute any numbers. Remember also that $f(3)$ gives **exactly** three, while $F(3)$ gives **three or fewer**.
:::

### Practice: reading and reversing cumulative information

:::problem[Problem 4.7 — Upper tail from the digital channel]{difficulty=easy}
For the four-bit channel with $f(0)=0.6561$, $f(1)=0.2916$, $f(2)=0.0486$, $f(3)=0.0036$, and $f(4)=0.0001$, find $P(X>2)$ and explain why it is not $F(2)$.

::::solution[Solution]
**Answer:** 0.0037

1. “More than two errors” includes the counts three and four; it does not include zero, one, or two.
2. Directly add the two matching PMF entries: $P(X>2)=f(3)+f(4)=0.0036+0.0001=0.0037$.
3. Alternatively, subtract the cumulative probability through two from one: $1-(0.6561+0.2916+0.0486)=1-0.9963=0.0037$. This describes about a $0.37\%$ chance of at least three errors in the next four transmitted bits.

Check: The direct addition and complement agree.
::::
:::

:::problem[Problem 4.8 — Read a cumulative step]{difficulty=easy}
For $F(x)=0$ when $x<-2$, $F(x)=0.2$ when $-2\le x<0$, $F(x)=0.7$ when $0\le x<2$, and $F(x)=1$ when $x\ge2$, calculate $P(X=0)$ and $P(X\le0)$.

::::solution[Solution]
**Answer:** (a) 0.5000, (b) 0.7000

1. A point probability is the *jump* at that point. Immediately before $x=0$, the CDF is $0.2$, and at $x=0$ it becomes $0.7$. Therefore $P(X=0)=0.7-0.2=0.5$.
2. A cumulative probability is the entire height at the endpoint, so $P(X\le0)=F(0)=0.7$, not $0.5$.
3. The difference of $0.2$ is the probability mass already accumulated at $x=-2$. This is exactly why $f$ and $F$ cannot be used interchangeably.

Check: The cumulative probability includes both $-2$ and zero.
::::
:::

:::problem[Problem 4.9 — Simple uniform mass, CDF, and average]{difficulty=standard}
A probability mass function satisfies $f(x)=0.10$ for integer values $x=1,2,\ldots,10$. Compute (a) $P(X=3)$, (b) $F(5.9)$, and (c) the average value of $X$.

::::solution[Solution]
**Answer:** (a) 0.1000, (b) 0.5000, (c) 5.5000

1. Because every integer in the support has probability $0.10$, $P(X=3)=0.10$ directly from the PMF.
2. The cutoff $5.9$ includes the integers one through five only, so $F(5.9)=0.10+0.10+0.10+0.10+0.10=0.50$.
3. The mean is the midpoint of equally likely consecutive integers: $\mu=(1+10)/2=5.5$. Or multiply all ten outcomes by $0.1$ and add. The result represents the average of many independent observations, not an individual integer that necessarily occurs.

Check: Ten probability masses of $0.1$ total one.
::::
:::

:::problem[Problem 4.10 — Warehouse error tails]{difficulty=standard}
A robotic warehouse retrieval system has the PMF below for the number of retrieval errors $X$ in one shift. Find (a) $P(X\le2)$ and (b) $P(X>1)$.

| $x$ | 0 | 1 | 2 | 3 | 4 |
|:--|:--:|:--:|:--:|:--:|:--:|
| $f(x)$ | 0.1500 | 0.2500 | 0.3000 | 0.2000 | 0.1000 |

::::solution[Solution]
**Answer:** (a) 0.7000, (b) 0.6000

1. For at most two errors, select columns headed zero, one, and two from the row labeled $f(x)$: $P(X\le2)=0.15+0.25+0.30=0.70$.
2. For more than one error, select the columns headed two, three, and four: $P(X>1)=0.30+0.20+0.10=0.60$. The complement is $1-(0.15+0.25)=0.60$.
3. These are probabilities of different events: a shift with exactly two errors belongs to both. In context, $70\%$ of shifts have at most two retrieval errors under this model.

Check: The full row totals one, and both answers lie in the allowable probability range.
::::
:::

:::problem[Problem 4.11 — Without-replacement cumulative function]{difficulty=challenge}
A batch contains $850$ manufactured parts, of which $50$ do not conform. Two are selected without replacement, and $X$ counts the nonconforming parts. Give $F(x)$ for all real $x$. Use the exact favorable-sample counts $319600$, $40000$, and $1225$ out of $360825$ possible pairs.

::::solution[Solution]
**Answer:** step heights 0, 0.885748, 0.996605, 1

1. Exactly zero defective parts has probability $319600/360825=0.885748$. Exactly one has probability $40000/360825=0.110857$, and exactly two has probability $1225/360825=0.003395$.
2. Before zero, no possible outcome has occurred: $F(x)=0$ for $x<0$. For $0\le x<1$, only zero counts: $F(x)=0.885748$.
3. For $1\le x<2$, add zero and one: $F(x)=(319600+40000)/360825=0.996605$. For $x\ge2$, all outcomes are included, so $F(x)=1$.
4. These plateaus represent the chance that the two-part sample contains at most the indicated number of nonconforming parts.

Check: The last plateau reaches one, and each jump equals a nonnegative point probability.
::::
:::

:::problem[Problem 4.12 — A PMF with missing intermediate values]{difficulty=standard}
A discrete random variable takes values $0$, $2$, and $5$ with probabilities $0.20$, $0.50$, and $0.30$, respectively. Compute $F(3)$ and $P(X\ge2)$.

::::solution[Solution]
**Answer:** (a) 0.7000, (b) 0.8000

1. To calculate $F(3)=P(X\le3)$, list allowed values up through three. They are zero and two, not one or three, because those numbers never occur.
2. Add the corresponding probabilities: $F(3)=0.20+0.50=0.70$.
3. The event $X\ge2$ includes two and five, so $P(X\ge2)=0.50+0.30=0.80$. This can also be found as $1-P(X=0)=1-0.20$.
4. Nonconsecutive supports make a useful test of whether you are reading the **possible values**, not assuming all integers occur.

Check: The displayed three probabilities sum to $1.00$.
::::
:::

## 4.3 Mean, Variance, Standard Deviation, and Expected Functions

:::callout-intuition[One number for the center; another for the spread]
A PMF tells you all the probabilities, but it is cumbersome to compare two machines by staring at two long rows of numbers. The mean condenses the long-run average outcome into one number. Variance tells you how far outcomes tend to deviate from that center, weighted by how likely they are. Standard deviation takes the square root of variance to express spread in the original unit, such as errors per shift rather than squared errors per shift.
:::

### Expected value is a weighted average, not the most likely count

:::definition[Definition 4.4 — Expected value and mean]
The mean or expected value of a discrete random variable with mass function $f(x)$ is

$$
\mu=E(X)=\sum_x xf(x).
$$

This formula appears on the **Final sheet, page 1**. In actual calculator work, multiply each distinct value by its corresponding probability and add the terms. An expected value can fall between possible integers, because it describes a long-run average of many outcomes rather than a possible single outcome.
:::

Think about a two-outcome design: $70\%$ of the time the revenue is two million dollars, and $30\%$ of the time it is seven million. The average across many repetitions is not simply $(2+7)/2$ because those outcomes are not equally common. Instead, each outcome is weighted by its probability: $(2)(0.7)+(7)(0.3)$. If a question asks for the average return, expected value is the relevant tool. If it asks which result happens most often, compare the individual probabilities instead.

Expected value can also apply to a **function** of the random variable. If a rule charges $h(X)=10X+5$ dollars for $X$ errors, compute an average charge by multiplying each charge $h(x)$ by its probability $f(x)$ and adding. This extension is intuitive: transform each possible outcome into its associated cost, then weight those costs. It is described in the instructor's notes but is not written separately on the Final sheet.

:::theorem[Theorem 4.1 — Expected value of a function]
For a function $h$ of a discrete random variable, the instructor's rule is

$$
E[h(X)]=\sum_x h(x)f(x).
$$

This exact expression is **not separately listed on the Final sheet**. It follows directly from the weighted-average rule on page 1: replace each possible outcome $x$ by the transformed value $h(x)$, keeping the probability attached to the original outcome. Expand the sum term by term in calculator work.
:::

:::definition[Definition 4.5 — Variance and standard deviation]
The variance of a discrete random variable is

$$
\sigma^2=V(X)=\sum_x (x-\mu)^2 f(x)=\sum_x x^2f(x)-\mu^2.
$$

The **Final sheet, page 1** gives both equal expressions. The standard deviation is $\sigma=\sqrt{\sigma^2}$, which makes intuitive sense because taking the square root reverses the squaring of deviations. Use the second variance expression for most calculator work: compute the weighted average of the squared values and subtract the square of the mean.
:::

### Why the variance uses squares

If you added the signed deviations $x-\mu$, positive deviations above the mean and negative deviations below it would cancel. Squaring first makes every contribution nonnegative, and values far away from the mean contribute more strongly than nearby values. Consequently, variance cannot be negative, and it equals zero only when the variable is constant. The unit of variance is the **square** of the original unit. If $X$ is measured in errors per shift, $V(X)$ is in squared errors per shift; $\sigma$ returns to errors per shift.

A frequent confusion is between the random-variable population variance $\sigma^2$ and the **sample variance** $s^2$ from Chapter 2. Here the entire PMF is given, so there is no $n-1$ divisor. The $n-1$ formula on the same Final-sheet page is specifically for a sample of observed data. Never divide a PMF variance by $n-1$ just because you see “variance” in the question.

### A calculator routine you can trust

Write the table with three rows: $x$, $f(x)$, and $x f(x)$ for the mean. Add a fourth row $x^2f(x)$ for the second moment. On the TI-30X IIS, type each multiplication and each addition, storing the computed mean mentally or with the calculator's memory if convenient. Then compute $\sigma^2=E(X^2)-\mu^2$ and finally $\sigma=\sqrt{\sigma^2}$. Keep enough intermediate digits that the final answer is not changed by premature rounding. For a multi-part homework question, do not recalculate the mean from scratch when it is already known accurately.

The identity $V(X)=E(X^2)-[E(X)]^2$ is often faster, but it is not an invitation to treat $E(X)^2$ and $E(X^2)$ as the same thing. First average the squares; then subtract the **square of the average**. For a variable that is usually close to its center, the two large quantities can be close, so rounding too early may even produce a tiny negative number that a true variance cannot have.

:::example[Example 4.8 — Digital channel: mean, variance, and standard deviation]
Let $X$ count errors in four transmitted bits with the PMF in the earlier table: $f(0)=0.6561$, $f(1)=0.2916$, $f(2)=0.0486$, $f(3)=0.0036$, $f(4)=0.0001$. Compute $\mu$, $\sigma^2$, and $\sigma$.

::::answer[Answer]
**Answer:** mean 0.4000, variance 0.3600, standard deviation 0.6000

1. Compute the mean without hiding the terms: $\mu=0(0.6561)+1(0.2916)+2(0.0486)+3(0.0036)+4(0.0001)=0.4000$ bit errors.
2. Compute the average squared count: $E(X^2)=0^2(0.6561)+1^2(0.2916)+2^2(0.0486)+3^2(0.0036)+4^2(0.0001)=0.5200$.
3. Subtract the square of the mean: $\sigma^2=0.5200-(0.4000)^2=0.3600$. Take the square root: $\sigma=\sqrt{0.3600}=0.6000$.
4. In context, the channel averages $0.4$ errors per four bits; the standard deviation measures about $0.6$ errors of spread across many four-bit transmissions.

Check: Later, the binomial formulas give $np=4(0.1)=0.4$ and $np(1-p)=0.36$.
::::
:::

:::example[Example 4.9 — Warehouse retrieval errors: full table analysis]
A warehouse robot has the following PMF for errors per shift. Find $P(X\le2)$, $P(X>1)$, $\mu$, $\sigma^2$, and $\sigma$.

| $x$ | 0 | 1 | 2 | 3 | 4 |
|:--|:--:|:--:|:--:|:--:|:--:|
| $f(x)$ | 0.1500 | 0.2500 | 0.3000 | 0.2000 | 0.1000 |

::::answer[Answer]
**Answer:** at most two 0.7000, more than one 0.6000, mean 1.8500, variance 1.4275, standard deviation 1.1948

1. Read the $f(x)$ row under columns $x=0,1,2$: $P(X\le2)=0.15+0.25+0.30=0.70$. For more than one, use columns $2,3,4$: $P(X>1)=0.30+0.20+0.10=0.60$.
2. For the mean, multiply and add every term: $\mu=0(0.15)+1(0.25)+2(0.30)+3(0.20)+4(0.10)=1.85$.
3. For the squared mean calculation, $E(X^2)=0^2(0.15)+1^2(0.25)+2^2(0.30)+3^2(0.20)+4^2(0.10)=4.85$.
4. The variance is $4.85-(1.85)^2=1.4275$. On the TI-30X IIS, enter $\sqrt{1.4275}$ to obtain $1.1948$. A shift averages $1.85$ errors, with a standard deviation of about $1.19$ errors.

Check: Variance is nonnegative, and the PMF sums to $1.00$.
::::
:::

:::example[Example 4.10 — Messages per hour]
The number of messages sent per hour has the distribution below. Determine the mean and standard deviation of the number of messages per hour.

| $x$ | 10 | 11 | 12 | 13 | 14 | 15 |
|:--|:--:|:--:|:--:|:--:|:--:|:--:|
| $f(x)$ | 0.0800 | 0.1500 | 0.3000 | 0.2000 | 0.2000 | 0.0700 |

::::answer[Answer]
**Answer:** mean 12.5000, standard deviation 1.3601

1. Take the probability-weighted average: $\mu=10(0.08)+11(0.15)+12(0.30)+13(0.20)+14(0.20)+15(0.07)=12.50$ messages.
2. Compute the second moment with the same column alignment: $E(X^2)=10^2(0.08)+11^2(0.15)+12^2(0.30)+13^2(0.20)+14^2(0.20)+15^2(0.07)=158.10$.
3. Subtract the square of the mean: $V(X)=158.10-(12.50)^2=1.85$. Then $\sigma=\sqrt{1.85}=1.3601$ messages.
4. In context, $12.5$ is an average across hours; an individual hour still contains an integer count of messages.

Check: All six PMF values sum to one.
::::
:::

:::example[Example 4.11 — Product designs and expected revenue]
Marketing expects design A to bring exactly $3$ million in revenue. Design B brings $7$ million with probability $0.3$ and $2$ million with probability $0.7$. Which has the higher expected revenue, and what does that comparison omit?

::::answer[Answer]
**Answer:** design B mean 3.5000 million; design A mean 3.0000 million

1. Design A's revenue is constant, so its expected revenue is $3$ million and its variance is zero.
2. Design B has two possible revenues. Multiply each by its probability: $E(B)=7(0.3)+2(0.7)=2.1+1.4=3.5$ million dollars.
3. If the choice is based **only** on expected revenue, design B is higher by $0.5$ million. But design B has uncertainty: its revenue is $2$ million in $70\%$ of cases. Choosing a design also depends on the decision maker's risk tolerance and costs, not just its expectation.

Check: The weighted average $3.5$ lies between the two possible revenues $2$ and $7$.
::::
:::

### When the distribution has not been provided

Knowing the smallest and largest possible values does **not** determine the mean or standard deviation. One voice-line system could almost always have no lines busy, while another could almost always have all forty-eight busy. Both have the same range, yet wildly different expected loads and variability. This is not a technicality: a range describes what can happen, whereas a PMF describes how often each possible value happens.

:::example[Example 4.12 — Voice-line mean with insufficient information]
A random variable $X$ counts the number of $48$ external voice lines in use at one moment. The only supplied information is that its range is $0$ through $48$. Determine its mean, variance, and standard deviation.

::::answer[Answer]
**Answer:** Cannot be determined from the range alone.

1. The mean formula needs a probability $f(x)$ for every possible number of busy lines. Neither the problem statement nor the given range tells us those probabilities.
2. To prove the insufficiency, imagine one model that always has zero busy lines, and a second that always has forty-eight busy lines. Both obey the stated range but have different expected values.
3. Other mixtures can even produce different variances with the same mean. Thus no unique numerical mean, variance, or standard deviation exists. In this setting, inventing a uniform distribution is unjustified.

Check: A proposed numerical answer would require adding assumptions absent from the question.
::::
:::

:::callout-pitfall[Keep the mean, variance, and sample variance separate]
Do not divide by the number of support values when the table's probabilities are unequal. Do not use the sample variance formula with $n-1$ when you have an entire PMF. Do not report variance in the original measurement units: variance is squared, while standard deviation is not. And if only the range is given, a numerical mean is **not** identifiable without probabilities.
:::

### Practice: calculator-ready averages and spreads

:::problem[Problem 4.13 — Two-point distribution: mean and spread]{difficulty=easy}
The number of service calls $X$ is $0$ with probability $0.75$ and $4$ with probability $0.25$. Find $\mu$, $\sigma^2$, and $\sigma$.

::::solution[Solution]
**Answer:** mean 1.0000, variance 3.0000, standard deviation 1.7321

1. Calculate the weighted mean: $E(X)=0(0.75)+4(0.25)=1.00$ call.
2. Square each count *before* multiplying by its probability: $E(X^2)=0^2(0.75)+4^2(0.25)=4.00$.
3. The variance is $4.00-(1.00)^2=3.00$ calls squared, and the standard deviation is $\sqrt{3}=1.7321$ calls.
4. The mean of one does not have to be a possible observed value. In this model, a shift always has either zero or four calls; the mean summarizes the long-run average.

Check: A squared deviation method gives $0.75(0-1)^2+0.25(4-1)^2=3$.
::::
:::

:::problem[Problem 4.14 — Uniform outcomes but no uniform probability]{difficulty=easy}
A discrete random variable has possible values $1,2,3$, with $f(1)=0.2$, $f(2)=0.3$, and $f(3)=0.5$. Determine the mean.

::::solution[Solution]
**Answer:** 2.3000

1. Read the given PMF values before calculating; the outcomes are $1$, $2$, and $3$, but they are **not** equally likely.
2. Apply the weighted-average formula: $\mu=1(0.2)+2(0.3)+3(0.5)=0.2+0.6+1.5=2.3$.
3. A simple average of the support would give two, which is wrong because the largest outcome has the greatest probability. In context, the long-run average of this experiment is $2.3$ even though no individual trial can equal $2.3$.

Check: The PMF values add to $0.2+0.3+0.5=1$.
::::
:::

:::problem[Problem 4.15 — Revenue with a fixed inspection charge]{difficulty=standard}
A machine generates revenue of $2$ million with probability $0.7$ or $7$ million with probability $0.3$. Inspection costs $0.25$ million regardless of the outcome. Compute the expected **net** revenue in millions. Explain your transformation of each outcome.

::::solution[Solution]
**Answer:** 3.2500 million

1. The net return is the outcome revenue minus the fixed inspection charge. Thus the two possible net values are $2-0.25=1.75$ and $7-0.25=6.75$ million.
2. Weight those outcomes: $E(\text{net})=1.75(0.7)+6.75(0.3)=1.225+2.025=3.25$ million.
3. As a check, the original expected gross revenue is $2(0.7)+7(0.3)=3.5$ million; subtracting the fixed $0.25$ million gives the same result. Net revenue remains random, but its expected value is $3.25$ million.

Check: Transforming each outcome and subtracting from the gross mean agree.
::::
:::

:::problem[Problem 4.16 — Compare equal means and unequal variability]{difficulty=standard}
Design A produces exactly $3$ serviceable components every hour. Design B produces $1$ component half the hours and $5$ components the other half. Find both means and both standard deviations.

::::solution[Solution]
**Answer:** A mean 3.0000, B mean 3.0000, A standard deviation 0.0000, B standard deviation 2.0000

1. Because design A is constant, $E(A)=3$ and every deviation from its mean is zero. Thus $V(A)=0$ and $\sigma_A=0$.
2. For design B, $E(B)=1(0.5)+5(0.5)=3$. Then $E(B^2)=1^2(0.5)+5^2(0.5)=13$.
3. Therefore $V(B)=13-3^2=4$ and $\sigma_B=\sqrt4=2$. The machines share the same average output but B is less predictable from hour to hour.
4. This illustrates why the mean alone cannot reveal the complete distribution.

Check: Both expectations equal three, but only the variable-output design has nonzero spread.
::::
:::

:::problem[Problem 4.17 — Function of a discrete error count]{difficulty=standard}
A monitoring tool records $X$ errors with $P(X=0)=0.5$, $P(X=1)=0.3$, and $P(X=2)=0.2$. Each shift costs $h(X)=10X+5$ dollars to inspect. Find the expected cost.

::::solution[Solution]
**Answer:** 12.0000 dollars

1. Translate each possible count into a cost: $h(0)=5$, $h(1)=15$, and $h(2)=25$ dollars. These costs occur with the same probabilities as their corresponding error counts.
2. Weight and add: $E[h(X)]=5(0.5)+15(0.3)+25(0.2)=2.5+4.5+5=12.0$ dollars.
3. Alternatively compute $E(X)=0(0.5)+1(0.3)+2(0.2)=0.7$, then $10E(X)+5=12.0$. This is the average inspection cost over many shifts, not a prediction that any individual shift costs exactly twelve dollars.

Check: Both methods return the same expected cost.
::::
:::

:::problem[Problem 4.18 — Determine the unknown probability before variance]{difficulty=challenge}
An error count takes values $0,1,2,3$ with probabilities $0.20,0.35,c,0.15$ respectively. Find the missing probability $c$, then calculate $\mu$ and $\sigma$.

::::solution[Solution]
**Answer:** missing probability 0.3000, mean 1.4000, standard deviation 0.9695

1. A valid PMF sums to one, so $c=1-(0.20+0.35+0.15)=0.30$.
2. Compute the mean using the now-complete distribution: $\mu=0(0.20)+1(0.35)+2(0.30)+3(0.15)=1.40$.
3. The second moment is $E(X^2)=0^2(0.20)+1^2(0.35)+2^2(0.30)+3^2(0.15)=2.90$.
4. Therefore $V(X)=2.90-(1.40)^2=0.94$ and $\sigma=\sqrt{0.94}=0.9695$ errors. In context, this quantifies variation around the $1.4$-error average.

Check: The completed PMF adds to one and variance is positive.
::::
:::

## 4.4 Discrete Uniform Models and Distribution Recognition

:::callout-intuition[Equal chances are a special assumption]
Sometimes a random device is built so that each allowed result is equally likely, like a fair numbered die or a uniformly assigned last digit in a barcode. The distribution then has a particularly easy PMF: one divided by the number of values. But the word “discrete” by itself does not mean “uniform.” A random count of machine failures rarely has equal probabilities for all counts. The question must explicitly say that the values are equally likely or provide a mechanism that guarantees that result.
:::

:::note[Scope]
**Exam 2 topic, not on the Final list.** Discrete uniform word problems were examinable on Exam 2, and the expanded **Exam 2 Equations, page 2, Table I** provides its mean and variance. The comprehensive Final-sheet distribution table does not include discrete uniform, so the midpoint and count arguments below are the important ideas to retain rather than another blind formula to memorize.
:::

:::definition[Definition 4.6 — Discrete uniform model]
If the discrete variable $X$ takes exactly $n$ different values and all are equally likely, then $f(x_i)=1/n$ at each value. If the values are consecutive integers $a,a+1,\ldots,b$, there are $n=b-a+1$ values and

$$
\mu=\frac{a+b}{2},\qquad \sigma^2=\frac{(b-a+1)^2-1}{12}.
$$

These two expressions are in **Table I on the Exam 2 sheet, page 2**, not on the Final sheet. The mean is the midpoint because values pair symmetrically around it; the variance comes from averaging the squared distances of the evenly spaced values from that midpoint.
:::

If a serial number's first digit is chosen uniformly from zero through nine, there are ten possibilities, not nine. For an interval of integers, the number of values is $b-a+1$. This “plus one” is the difference between an inclusive list of integers and an ordinary numerical length. Also, the chance of a particular integer in a discrete uniform model is not the continuous uniform density $1/(b-a)$. Here each value carries positive point probability.

:::example[Example 4.13 — Serial-number first digit]
The first digit of a part's serial number is equally likely to be any digit $0,1,\ldots,9$. Let $X$ be this digit. Find the PMF and the mean.

::::answer[Answer]
**Answer:** each digit 0.1000, mean 4.5000

1. Count the possible distinct digits, including zero: there are ten. Therefore $f(x)=1/10=0.1$ for each integer from zero through nine and $f(x)=0$ otherwise.
2. The values are consecutive and equally likely, so $\mu=(0+9)/2=4.5$. You can also check by explicitly adding $0(0.1)+1(0.1)+\cdots+9(0.1)=4.5$.
3. In context, every individual digit occurs with chance $10\%$, and the average first digit across many serial numbers is $4.5$. It need not be an allowed single digit.

Check: Ten entries of $0.1$ total one.
::::
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Equal-probability PMF for serial number first digit zero through nine">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 107.25 H 626"/>
<text class="fig-label" x="2" y="111.25">0.057</text>
<path class="fig-gridline" d="M 48 20.00 H 626"/>
<text class="fig-label" x="2" y="24.00">0.115</text>
<path class="fig-curve" d="M 76.90 193 V 42.57"/>
<circle class="fig-point" cx="76.90" cy="42.57" r="3"/>
<text class="fig-label" x="76.90" y="211">0</text>
<path class="fig-curve" d="M 134.70 193 V 42.57"/>
<circle class="fig-point" cx="134.70" cy="42.57" r="3"/>
<text class="fig-label" x="134.70" y="211">1</text>
<path class="fig-curve" d="M 192.50 193 V 42.57"/>
<circle class="fig-point" cx="192.50" cy="42.57" r="3"/>
<text class="fig-label" x="192.50" y="211">2</text>
<path class="fig-curve" d="M 250.30 193 V 42.57"/>
<circle class="fig-point" cx="250.30" cy="42.57" r="3"/>
<text class="fig-label" x="250.30" y="211">3</text>
<path class="fig-curve" d="M 308.10 193 V 42.57"/>
<circle class="fig-point" cx="308.10" cy="42.57" r="3"/>
<text class="fig-label" x="308.10" y="211">4</text>
<path class="fig-curve" d="M 365.90 193 V 42.57"/>
<circle class="fig-point" cx="365.90" cy="42.57" r="3"/>
<text class="fig-label" x="365.90" y="211">5</text>
<path class="fig-curve" d="M 423.70 193 V 42.57"/>
<circle class="fig-point" cx="423.70" cy="42.57" r="3"/>
<text class="fig-label" x="423.70" y="211">6</text>
<path class="fig-curve" d="M 481.50 193 V 42.57"/>
<circle class="fig-point" cx="481.50" cy="42.57" r="3"/>
<text class="fig-label" x="481.50" y="211">7</text>
<path class="fig-curve" d="M 539.30 193 V 42.57"/>
<circle class="fig-point" cx="539.30" cy="42.57" r="3"/>
<text class="fig-label" x="539.30" y="211">8</text>
<path class="fig-curve" d="M 597.10 193 V 42.57"/>
<circle class="fig-point" cx="597.10" cy="42.57" r="3"/>
<text class="fig-label" x="597.10" y="211">9</text>
</svg>
<figcaption>A discrete uniform distribution assigns the same probability to all ten digits, including both zero and nine.</figcaption>
</figure>

:::example[Example 4.14 — A fair twelve-sided die]
A fair twelve-sided die is numbered $1$ through $12$. What is $V(X)$, the variance of the number showing?

::::answer[Answer]
**Answer:** 11.9167

1. Every integer from one through twelve is equally likely, so the distribution is discrete uniform with $a=1$, $b=12$, and $n=12$ values.
2. Use the Exam 2 Table I variance: $V(X)=((12-1+1)^2-1)/12=(12^2-1)/12=143/12=11.9167$.
3. The mean is $\mu=(1+12)/2=6.5$, so the standard deviation is about $3.45$ die faces. The variance is **not** $12.00$; rounding to two decimal places gives $11.92$.

Check: Directly averaging squared distances about $6.5$ gives $143/12$.
::::
:::

### A field guide for choosing a distribution

The six discrete model names the class mentions should be connected to six different experiment stories. **Discrete uniform** means equal chances among a fixed set of outcomes. **Binomial** means counting successes in a fixed number of independent, identical-probability trials. **Poisson** means counting randomly occurring events in a fixed interval at a constant average rate. **Geometric** means how many trials are needed until the first success. **Negative binomial** means how many trials are needed until the $r$-th success. **Hypergeometric** means how many successes appear in a sample from a finite group drawn without replacement.

Look first for the experiment's stopping rule. If you commit to performing six polls and then count the number won, that is binomial. If you keep observing until the *first* successful sighting, the stopping rule is geometric. If you continue until the *fifth* successful sighting, it is negative binomial. “Without replacement” is the giveaway that ordinary independent binomial trials are not justified. “Per hour” is a clue toward a Poisson **count**, but the word “waiting time” points toward an exponential variable, which Chapter 5 teaches.

:::note[Scope]
**Exam 2 topic, not on the Final list.** For geometric and negative binomial random variables, the required level is *recognition, parameter meaning, and the mean and variance from Table I*, not numeric probability calculations. In the Exam 2 sheet's convention, $X$ is the trial count **including** the successful trial, so the geometric mean is $1/p$ and variance is $(1-p)/p^2$. For the trial count until the $r$-th success, the negative-binomial mean is $r/p$ and the variance is $r(1-p)/p^2$. These values appear in **Exam 2 Table I, page 2**; neither formula is on the Final sheet. The instructor's exercise $f(x)=(3/4)(1/4)^x$ instead counts **failures before the first success**, starting at $x=0$. Recognizing this offset is the point; the requested geometric tail calculations are not included in Final scope.
:::

The hypergeometric label appears in the extra-credit identification problem and in Exam 2 Table I, but the Final focuses on binomial and Poisson. You do not need to memorize a hypergeometric formula: “finite collection, without replacement” is the operational description. The exact two-part batch probabilities were computed by elementary counting earlier.

:::callout-connect[Counts versus waiting times]
Poisson is a count in a specified time or length; exponential is a **continuous waiting time** until an event. Chapter 5, **Continuous Random Variables**, develops the exponential probability model. The same arrival process can produce both types of questions, but the quantity being asked for determines which chapter's computation applies.
:::

:::example[Example 4.15 — Fat Bear Week: six distributions]
Identify the appropriate distribution for each scenario, using the six discrete distributions covered in class. (a) A wildlife researcher selects photographs of male and female bears **without replacement** and counts male bears. (b) A fan watches the Fat Bear Week livestream until the first observation of Bear 747 catching a salmon. (c) Count salmon caught by Bear 32 during one hour. (d) Select one bear from a bracket, each bear equally likely. (e) Count livestream observations until the fifth successful observation of a salmon catch. (f) Across six independent polls with win/lose outcomes, count polls won by one bear.

::::answer[Answer]
**Answer:** (a) hypergeometric; (b) geometric; (c) Poisson; (d) discrete uniform; (e) negative binomial; (f) binomial

1. **Without replacement** makes the number of male bears a finite-population count: hypergeometric. Waiting for the **first** success indicates geometric.
2. Counting catches in a fixed **hour** at a random rate suggests Poisson; equal chances for one choice among a fixed bracket means discrete uniform.
3. Counting trials until the **fifth** success changes the stopping rule to negative binomial. Fixing six independent polls and counting wins is binomial.
4. The distinction is not the animal or sport in the story; it is the trial structure, stopping rule, and whether event counts are attached to an interval. These answers are distribution identification, not probabilities.

Check: Each model is identified by a different defining experiment.
::::
:::

:::callout-pitfall[Six model names do not mean six calculation formulas]
Do not use a binomial formula when trials continue **until** success; binomial fixes the number of trials before the experiment starts. Do not call an observation “Poisson” merely because it mentions time: a count in an interval is discrete, while time between arrivals is continuous exponential. Do not treat sampling without replacement as independent. And never import a geometric formula onto the Final just because the larger Exam 2 table lists it.
:::

### Practice: uniform calculations and distribution matching

:::problem[Problem 4.19 — The last barcode digit]{difficulty=easy}
When a barcode is assigned, its last digit is equally likely to be any integer from $0$ through $9$. Find (a) $P(X<4)$ and (b) the mean value of the last digit.

::::solution[Solution]
**Answer:** (a) 0.4000, (b) 4.5000

1. A barcode's final digit has ten possibilities: $0,1,2,3,4,5,6,7,8,9$. Each receives probability $1/10=0.1$ because assignment is uniform.
2. “Less than four” includes precisely zero, one, two, and three. Thus $P(X<4)=0.1+0.1+0.1+0.1=0.4$.
3. The mean of consecutive equally likely digits is their midpoint, $(0+9)/2=4.5$. An assigned barcode still has an integer last digit; $4.5$ describes the long-run average across assignments.

Check: Four favorable digits out of ten give $4/10$.
::::
:::

:::problem[Problem 4.20 — Recognize a wafer waiting experiment]{difficulty=easy}
Wafers are independently tested until the first wafer containing a large contamination particle is found. Each wafer has probability $0.01$ of containing a large particle. Let $X$ be the **number of wafers tested until detection**. Determine the probability distribution of $X$, including its family, parameter, possible values, and general mass function.

::::solution[Solution]
**Answer:** Geometric; first-success trial count.

1. The procedure does not specify a fixed number of wafers in advance. Testing stops **when the first success occurs**, where success means detecting a large particle.
2. That is a geometric waiting experiment with success probability $p=0.01$. The variable counts tested wafers, so its possible values are $x=1,2,3,\ldots$, not zero.
3. The first $x-1$ wafers must be free of large particles, each with probability $0.99$, followed by a contaminated wafer with probability $0.01$. Independence therefore gives the distribution $f(x)=(0.99)^{x-1}(0.01)$ for $x=1,2,3,\ldots$.
4. The lack of a fixed sample size prevents treating $X$ as binomial. This is the first-success convention in the Exam 2 table, presented as a distribution definition rather than a geometric probability-computation exercise.

Check: The stopping rule, rather than the numerical rate, identifies the family.
::::
:::

:::problem[Problem 4.21 — Recognize a shifted geometric PMF]{difficulty=standard}
An instructor gives the mass function $f(x)=(3/4)(1/4)^x$ for $x=0,1,2,\ldots$. Her exercise asks for $P(X=2)$, $P(X\le2)$, $P(X>2)$, and $P(X\ge1)$. Identify what kind of experiment this models and what $X$ counts, noting the difference from Table I's convention.

::::solution[Solution]
**Answer:** Geometric, counting failures before the first success.

1. In a geometric story, the factor $3/4$ is the success probability and each factor $1/4$ represents another failure before the first success.
2. Because the allowed values begin at zero, $X$ counts the number of **failures** before the successful trial, whereas the geometric variable in the Exam 2 table counts the **number of trials**, starting at one.
3. The two variables differ by one. The four probability questions in the original exercise would be geometric numerical calculations, which are outside the stated calculation scope for this chapter. Recognition and the meaning of the parameter are what matter here.

Check: The zero value represents an immediate success on the first attempt.
::::
:::

:::problem[Problem 4.22 — Fair die versus an unfair die]{difficulty=standard}
Two twelve-sided dice show integers from $1$ to $12$. Die A is fair. Die B is weighted so larger numbers are more likely, but you know nothing else about its probabilities. Can you use the discrete uniform variance formula for both?

::::solution[Solution]
**Answer:** Only die A has a determined uniform variance.

1. The stated fairness of die A means every face has probability $1/12$, so its distribution is discrete uniform. The uniform variance and midpoint formulas apply to that die.
2. Die B has exactly the same numerical support but unequal probabilities, so the equal-mass assumption is false. No specific PMF for die B was provided.
3. Consequently you cannot calculate die B's unique mean or variance from the range and the phrase “weighted toward higher numbers.” This is the same reasoning that prevents inventing a uniform model for the forty-eight voice lines.

Check: A range by itself does not specify a probability function.
::::
:::

:::problem[Problem 4.23 — Four equal shipping codes]{difficulty=standard}
A shipping system chooses an integer code uniformly from $3,4,5,6$. Determine $f(5)$, $F(4.5)$, and $\mu$.

::::solution[Solution]
**Answer:** point mass 0.2500, cumulative probability 0.5000, mean 4.5000

1. The range contains four consecutive integers, so each has probability $1/4=0.25$; in particular, $f(5)=0.25$.
2. At cutoff $4.5$, only three and four are included. Add the two corresponding masses: $F(4.5)=0.25+0.25=0.50$.
3. The mean is the midpoint, $(3+6)/2=4.5$. This is a valid expected value even though it is not one of the four possible codes; it represents an average of many assigned codes.

Check: The four point probabilities sum to one, and the CDF increases by a quarter at each code.
::::
:::

:::problem[Problem 4.24 — Which experiment is binomial?]{difficulty=challenge}
Four experiments are proposed: (A) count service calls arriving in a two-hour interval; (B) test parts until the first defect; (C) inspect eight independently produced parts with identical failure probabilities and count failures; (D) draw eight parts without replacement from a finite batch and count defects. Choose the only binomial experiment and explain the other three.

::::solution[Solution]
**Answer:** (C) fixed independent trials.

1. A binomial count requires a fixed number of independent trials with two outcomes and a constant success probability. Experiment C states all of those conditions directly.
2. Experiment A is a count in an interval and is more naturally modeled by a Poisson process when its rate assumptions are supplied. Experiment B uses a stopping rule and is geometric.
3. In experiment D, sampling without replacement changes the trial probabilities after each draw, so the ordinary binomial independence condition does not hold. The language of the experiment determines the distribution, not just the fact that all four involve counting.

Check: Only C supplies all the binomial conditions.
::::
:::

## 4.5 The Binomial Distribution

:::callout-intuition[Count successes, but keep the number of tries fixed]
Imagine checking twelve eggs for cracks. Each loading event has a small failure probability, and the customer cares about the *number* of cracks in the whole carton, not their locations. You could write down every success/failure sequence, but there are $2^{12}$ such sequences. The binomial formula compresses them by counting how many sequences contain the required number of successes. It is a smart counting shortcut, not an unrelated formula that must be memorized by faith.
:::

### The three Bernoulli conditions

:::definition[Definition 4.7 — Binomial random variable]
A **Bernoulli trial** has two possible outcomes, success and failure, with a fixed probability of success $p$. A random variable $X$ is **binomial** when it counts successes in a predetermined number $n$ of independent Bernoulli trials, each with the same success probability $p$.

Its support is $x=0,1,\ldots,n$, and its probability mass function is

$$
f(x)=\binom nx p^x(1-p)^{n-x}.
$$

The mean and variance are

$$
\mu=np,\qquad \sigma^2=np(1-p),\qquad \sigma=\sqrt{np(1-p)}.
$$

The PMF, mean, and variance appear in the **Binomial row on the Final sheet, page 2**. The combination $\binom nx=\frac{n!}{x!(n-x)!}$ also appears on **page 1**. Standard deviation is the square root of variance and is not printed as a separate binomial formula.
:::

Look for three questions in a word problem: **Are there exactly two outcomes for each trial?** Is the number of trials **fixed in advance**? Are the trials **independent with the same probability**? If every answer is yes, decide which outcome the problem calls “success.” A “success” need not be desirable: for a defective-part count, the defective part is conventionally the success event because that is what $X$ counts. Then set $p$ equal to the defect probability rather than the pass probability.

### Why the binomial formula is true

For exactly $x$ successes among $n$ trials, any one particular ordered sequence has probability $p^x(1-p)^{n-x}$ by independence. But there are many arrangements of those successes. The combination $\binom nx$ counts which $x$ of the $n$ positions contain successes. Multiplying the number of arrangements by the probability of each arrangement gives the formula. At the extremes it makes immediate sense: $P(X=0)=(1-p)^n$ because all $n$ trials fail to meet the counted success criterion, and $P(X=n)=p^n$ because all succeed.

The mean is $np$ because each of the $n$ trials contributes an expected count of $p$. The variance is $np(1-p)$ because a single independent zero-or-one trial has variance $p(1-p)$, and independent variances add. You do not need to reproduce a formal proof during the exam, but this explains why the mean and variance formulas belong to this model.

### Exact, cumulative, and complement events

For “exactly $k$,” use one term: $P(X=k)=\binom nk p^k(1-p)^{n-k}$. For “$k$ or fewer,” add the terms from zero through $k$. For “at least one,” compute $1-P(X=0)$ rather than adding a long string of terms. For “at least four,” use $1-[P(X=0)+P(X=1)+P(X=2)+P(X=3)]$. For “more than two,” the excluded cases are zero through two, exactly as in that last example but with a different cutoff. For $3\le X<7$, include counts three, four, five, and six, never seven.

The instructor mentions a cumulative binomial probability table for some exercises. The **Final sheet does not contain a binomial CDF table**, and the TI-30X IIS is not statistical software. A problem should therefore be workable by evaluating a small number of binomial terms, using a calculator's combination operation if available, or using the ratio of successive terms to avoid enormous factorials.

To calculate $\binom{80}{2}$, use the combination function if available or simplify $80(79)/2=3160$ instead of typing $80!$ and risking overflow. A concrete TI-30X IIS arithmetic sequence for the sensor example is to type $(0.97)^{80}$ for $P(X=0)$; type $80\times0.03\times(0.97)^{79}$ for $P(X=1)$; and type $(80\times79\div2)\times(0.03)^2\times(0.97)^{78}$ for $P(X=2)$. The displays are approximately $0.0874458$, $0.2163606$, and $0.2643169$; their sum is $0.5681233$. No factorial of eighty is ever evaluated. To add several probabilities, one useful recurrence is

$$
P(X=k+1)=P(X=k)\frac{n-k}{k+1}\frac{p}{1-p}.
$$

This recurrence follows by dividing two adjacent binomial PMF terms, so it is an **intuitive derived shortcut**, not a formula listed on the Final sheet. Start at $P(X=0)=(1-p)^n$ and advance one count at a time. Retain unrounded intermediate values and round only the final result.

:::example[Example 4.16 — Digital-channel binomial identification]
Each transmitted bit has independent error probability $0.1$. In the next four transmitted bits, let $X$ be the number received in error. Identify the model and find $P(X=2)$, the mean, and the variance.

::::answer[Answer]
**Answer:** exactly two 0.0486, mean 0.4000, variance 0.3600

1. Fix the number of trials at four bits. Each bit either is in error or is correct, independently, with the same error probability. Thus $X$ is binomial with $n=4$ and $p=0.1$, where “success” means error.
2. Use the Binomial row on Final sheet page 2: $P(X=2)=\binom42(0.1)^2(0.9)^2=6(0.01)(0.81)=0.0486$.
3. Compute $\mu=np=4(0.1)=0.4$ and $\sigma^2=np(1-p)=4(0.1)(0.9)=0.36$.
4. In context, there is a $4.86\%$ chance that exactly two of the next four bits are wrong, and the average error count is $0.4$ per four-bit batch.

Check: The direct PMF value agrees with the given digital-channel table.
::::
:::

:::example[Example 4.17 — Water samples: exact, at least, and a bounded interval]
Each independent water sample has a $10\%$ chance of containing an organic pollutant. Among the next $18$ samples, find (a) exactly two contaminated; (b) at least four contaminated; (c) $3\le X<7$ contaminated. Let $X$ count contaminated samples.

::::answer[Answer]
**Answer:** (a) 0.2835, (b) 0.0982, (c) 0.2650

1. The fixed number of independent yes/no tests gives $X\sim\mathrm{Binomial}(18,0.10)$. For part (a), $P(X=2)=\binom{18}{2}(0.1)^2(0.9)^{16}=153(0.01)(0.185302)=0.2835$.
2. “At least four” removes zero through three. The four individual binomial probabilities are $P(X=0)=0.1500946$, $P(X=1)=0.3001893$, $P(X=2)=0.2835121$, and $P(X=3)=0.1680072$. Thus $P(X\ge4)=1-(0.1500946+0.3001893+0.2835121+0.1680072)\approx0.0982$.
3. The interval $3\le X<7$ includes counts $3,4,5,6$, with corresponding masses $0.1680072$, $0.0700030$, $0.0217787$, and $0.0052430$. Add the four explicitly: $P(3\le X<7)=0.1680072+0.0700030+0.0217787+0.0052430\approx0.2650$.
4. The answers describe probabilities for eighteen sampled water specimens; the threshold comparison matters more than the word “pollutant.”

Check: Direct finite sums and the CDF-difference method agree to rounding.
::::
:::

:::example[Example 4.18 — Sensor shipment and five independent shipments]
Historical data indicate that $3\%$ of electronic sensors fail final quality inspection independently. A shipment contains $80$ sensors, and $X$ counts failures. Find (a) the model and parameters, (b) $P(X=0)$, (c) $P(X\le2)$, (d) $P(X\ge1)$, (e) $\mu$ and $\sigma$, and (f) the probability that **at least one of five independent shipments** contains three or more failed sensors. Round answers to the nearest thousandth.

::::answer[Answer]
**Answer:** (b) 0.087, (c) 0.568, (d) 0.913, (e) mean 2.400, standard deviation 1.526, (f) 0.941

1. One sensor either fails or passes, the eighty tests are independent, and the failure probability is constant. Thus $X\sim\mathrm{Binomial}(80,0.03)$.
2. No failures means all eighty pass: $P(X=0)=(0.97)^{80}=0.0874458$, giving $0.087$. For two or fewer, calculate the other two masses: $P(X=1)=80(0.03)(0.97)^{79}=0.2163606$ and $P(X=2)=\binom{80}{2}(0.03)^2(0.97)^{78}=3160(0.03)^2(0.97)^{78}=0.2643169$. Add $0.0874458+0.2163606+0.2643169=0.5681233$, giving $0.568$.
3. At least one failure is the complement of none: $P(X\ge1)=1-(0.97)^{80}=0.912554$, or $0.913$. The mean is $80(0.03)=2.4$ failures, and the standard deviation is $\sqrt{80(0.03)(0.97)}=1.525778$, or $1.526$.
4. For one shipment, $P(X\ge3)=1-P(X\le2)=1-0.568123=0.431877$. For five **independent** shipments, the probability that none has three or more failures is $(0.568123)^5$. Take its complement: $1-(0.568123)^5=0.940815$, or $0.941$.
5. In context, a single shipment averages $2.4$ failed sensors, but across five shipments there is about a $94.1\%$ chance of observing at least one shipment with three or more failures.

Check: All probabilities are in $[0,1]$, and part (f) uses the unrounded single-shipment CDF.
::::
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Binomial PMF for eighty independent sensors with three percent probability of failure">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.49 H 626"/>
<text class="fig-label" x="2" y="110.49">0.152</text>
<path class="fig-gridline" d="M 48 19.98 H 626"/>
<text class="fig-label" x="2" y="23.98">0.304</text>
<path class="fig-curve" d="M 72.08 193 V 143.23"/>
<circle class="fig-point" cx="72.08" cy="143.23" r="3"/>
<text class="fig-label" x="72.08" y="211">0</text>
<path class="fig-curve" d="M 120.25 193 V 69.86"/>
<circle class="fig-point" cx="120.25" cy="69.86" r="3"/>
<text class="fig-label" x="120.25" y="211">1</text>
<path class="fig-curve" d="M 168.42 193 V 42.57"/>
<circle class="fig-point" cx="168.42" cy="42.57" r="3"/>
<text class="fig-label" x="168.42" y="211">2</text>
<path class="fig-curve" d="M 216.58 193 V 72.03"/>
<circle class="fig-point" cx="216.58" cy="72.03" r="3"/>
<text class="fig-label" x="216.58" y="211">3</text>
<path class="fig-curve" d="M 264.75 193 V 120.98"/>
<circle class="fig-point" cx="264.75" cy="120.98" r="3"/>
<text class="fig-label" x="264.75" y="211">4</text>
<path class="fig-curve" d="M 312.92 193 V 159.14"/>
<circle class="fig-point" cx="312.92" cy="159.14" r="3"/>
<text class="fig-label" x="312.92" y="211">5</text>
<path class="fig-curve" d="M 361.08 193 V 179.91"/>
<circle class="fig-point" cx="361.08" cy="179.91" r="3"/>
<text class="fig-label" x="361.08" y="211">6</text>
<path class="fig-curve" d="M 409.25 193 V 188.72"/>
<circle class="fig-point" cx="409.25" cy="188.72" r="3"/>
<text class="fig-label" x="409.25" y="211">7</text>
<path class="fig-curve" d="M 457.42 193 V 191.79"/>
<circle class="fig-point" cx="457.42" cy="191.79" r="3"/>
<text class="fig-label" x="457.42" y="211">8</text>
<path class="fig-curve" d="M 505.58 193 V 192.70"/>
<circle class="fig-point" cx="505.58" cy="192.70" r="3"/>
<text class="fig-label" x="505.58" y="211">9</text>
<path class="fig-curve" d="M 553.75 193 V 192.93"/>
<circle class="fig-point" cx="553.75" cy="192.93" r="3"/>
<text class="fig-label" x="553.75" y="211">10</text>
<path class="fig-curve" d="M 601.92 193 V 192.99"/>
<circle class="fig-point" cx="601.92" cy="192.99" r="3"/>
<text class="fig-label" x="601.92" y="211">11</text>
</svg>
<figcaption>For eighty sensors with a three-percent failure rate, the binomial bars peak near two failures; a small chance of zero failures does not mean failures are certain.</figcaption>
</figure>

### Multiple cartons, shifts, or shipments: the second binomial experiment

A repeated-trial follow-up frequently changes what the trial means. In the sensor example, the original trials are **individual sensors**, so $X$ counts failed sensors. In the last part, the new trials are **whole shipments**. Each shipment either meets the condition “three or more failed sensors” or it does not. That event has probability $q=P(X\ge3)$. For five independent shipments, the number of shipments meeting the condition is another binomial count, now with $n=5$ and $p=q$. To ask whether at least one shipment meets the condition, calculate $1-(1-q)^5$.

The two layers must not be mixed. You cannot apply $1-(1-0.03)^5$ because $0.03$ is a **sensor failure rate**, not the probability of a shipment having at least three failures. First solve the one-shipment problem; then convert whole shipments into new yes/no trials. This is a general pattern for repeated inspections and repeated batches, but the independence of shipments must actually be stated or justified.

If you use rounded $q=0.432$ in the second calculation, your final answer can drift. The safer TI-30X IIS routine is to retain $0.568123\ldots$ in the expression $1-(0.568123\ldots)^5$ and round the final result once, to the nearest thousandth as requested.

:::problem[Problem 4.25 — Six fair coin flips]{difficulty=easy}
A fair coin is flipped six times. What is the probability of getting exactly two tails? Choose the correct value: (A) $0.1563$; (B) $0.2344$; (C) $0.3125$; (D) $0.5000$.

::::solution[Solution]
**Answer:** (B) 0.2344

1. The number of flips is fixed at six, each flip is independently heads or tails, and tails has constant probability $0.5$. Thus $X\sim\mathrm{Binomial}(6,0.5)$.
2. Calculate $P(X=2)=\binom62(0.5)^2(0.5)^4=15(0.5)^6=15/64=0.234375\approx0.2344$.
3. Choice B is correct. Choice A resembles a mistaken combination or power count; C is a different probability produced by miscounting favorable sequences; D is the chance of one side on a *single* flip, not exactly two tails in six. The probability describes two tails anywhere among six flips.

Check: There are $15$ favorable tail-position choices out of $64$ equally likely flip sequences.
::::
:::

:::problem[Problem 4.26 — Inspector: more than two failures]{difficulty=standard}
A quality-control engineer inspects $100$ independently manufactured parts. Each part has probability $0.05$ of failing inspection. Find (a) the probability that **more than two** parts are defective and (b) the expected number defective.

::::solution[Solution]
**Answer:** (a) 0.8817, (b) 5.0000

1. Here the counted “success” is a defective part, with $n=100$ and $p=0.05$. The fixed independent inspections make this a binomial model.
2. “More than two” means the counts three through one hundred. It is far simpler to subtract zero, one, and two from one: $P(X>2)=1-[\binom{100}{0}(0.05)^0(0.95)^{100}+\binom{100}{1}(0.05)(0.95)^{99}+\binom{100}{2}(0.05)^2(0.95)^{98}]\approx0.8817$.
3. The expected count is $\mu=np=100(0.05)=5$. This means five defective parts on average, not that every group of one hundred includes exactly five.

Check: The complement terms total approximately $0.1183$.
::::
:::

:::problem[Problem 4.27 — Twelve eggs and a complaint threshold]{difficulty=standard}
An automated egg-carton loader cracks an egg with probability $0.01$, independently from egg to egg. A carton contains $12$ eggs; a customer complains if **more than one** egg is cracked. Determine (a) the distribution of cracked eggs, (b) the probability of a complaint, and (c) the mean and standard deviation.

::::solution[Solution]
**Answer:** (b) 0.0062, (c) mean 0.1200, standard deviation 0.3447

1. Let $X$ count cracked eggs. It is binomial with $n=12$, $p=0.01$ because there are twelve independent crack/no-crack trials.
2. A complaint requires $X\ge2$. Exclude zero and one crack: $P(X\ge2)=1-[P(X=0)+P(X=1)]=1-[(0.99)^{12}+12(0.01)(0.99)^{11}]\approx0.0061745$, or $0.0062$.
3. The mean is $np=12(0.01)=0.12$ cracked eggs per carton. Variance is $np(1-p)=12(0.01)(0.99)=0.1188$; standard deviation is $\sqrt{0.1188}=0.3447$ cracked eggs.
4. In context, only about $0.62\%$ of cartons trigger complaints under this independent loading model.

Check: The complaint is the complement of zero or one cracked egg.
::::
:::

:::problem[Problem 4.28 — Read four binomial CDF events]{difficulty=standard}
Let $X$ be binomial with $n=20$ and $p=0.2$. Find (a) $P(X\le3)$, (b) $P(X>10)$, (c) $P(X=6)$, and (d) $P(6\le X\le11)$. In Exam 2, a cumulative binomial table could be used; for the Final, calculate by finite sums.

::::solution[Solution]
**Answer:** (a) 0.4114, (b) 0.0006, (c) 0.1091, (d) 0.1957

1. For part (a), add probabilities at zero, one, two, and three: $P(X\le3)=\binom{20}{0}(0.8)^{20}+\binom{20}{1}(0.2)(0.8)^{19}+\binom{20}{2}(0.2)^2(0.8)^{18}+\binom{20}{3}(0.2)^3(0.8)^{17}=0.4114$.
2. To evaluate the complement through ten, the binomial PMF values for $x=0$ through $x=10$, rounded to nine decimals, are $0.011529215,0.057646075,0.136909429,0.205364143,0.218199402,0.174559522,0.109099701,0.054549850,0.022160877,0.007386959,0.002031414$. Add those eleven values before rounding: $P(X\le10)\approx0.9994366$. Hence $P(X>10)=1-0.9994366=0.0005634\approx0.0006$.
3. For part (c), the one requested mass is $P(X=6)=\binom{20}{6}(0.2)^6(0.8)^{14}=0.1091$. For part (d), use the values at $6,7,8,9,10,11$: $0.109099701+0.054549850+0.022160877+0.007386959+0.002031414+0.000461685\approx0.1957$. Both endpoints six and eleven are included.
4. The four probabilities answer different questions about the same twenty-trial experiment; the CDF arithmetic cannot replace choosing the correct event.

Check: The inclusive interval is the sum of terms for six through eleven.
::::
:::

:::problem[Problem 4.29 — Five electronic components]{difficulty=standard}
Suppose $20\%$ of manufactured electronic components are defective. Five components are selected independently, and $X$ counts defective components. Find (a) $P(X=2)$, (b) $P(X\ge1)$, and (c) $P(X\le2)$. Also identify the model if the question instead asks when the **first** defective component appears.

::::solution[Solution]
**Answer:** (a) 0.2048, (b) 0.6723, (c) 0.9421

1. Fixed independent yes/no selections mean $X\sim\mathrm{Binomial}(5,0.2)$. Exactly two defects has probability $\binom52(0.2)^2(0.8)^3=10(0.04)(0.512)=0.2048$.
2. At least one defect is easier by complement: $P(X\ge1)=1-(0.8)^5=1-0.32768=0.67232$.
3. No more than two defects is $P(X\le2)=(0.8)^5+5(0.2)(0.8)^4+10(0.2)^2(0.8)^3=0.94208$.
4. By contrast, “first defective component on the fourth selection” is a **geometric first-success** question, not a fixed-five-trial binomial count. The numeric waiting-time calculation is outside this unit's stated geometric scope.

Check: The three binomial results agree with direct enumeration of zero through two defects.
::::
:::

:::problem[Problem 4.30 — Repeated groups of laboratory samples]{difficulty=challenge}
Each independently tested laboratory sample has a $10\%$ chance of contamination. One batch has $18$ samples, and a batch is flagged when at least four are contaminated. Six **independent batches** are tested. What is the probability that **at least one** batch is flagged?

::::solution[Solution]
**Answer:** 0.4621

1. First work at the sample level. For one batch, $X\sim\mathrm{Binomial}(18,0.1)$ and the flag event has probability $q=P(X\ge4)=1-[P(X=0)+P(X=1)+P(X=2)+P(X=3)]\approx0.0981968$.
2. Now define a new yes/no trial: an entire batch is either flagged or not flagged. Because there are six independent batches, the probability none is flagged equals $(1-q)^6$.
3. Take the complement: $P(\text{at least one flagged})=1-(1-0.0981968)^6\approx0.4621$.
4. The model changes its unit of trial from a sample to a batch. Using the individual sample contamination probability in the final six-trial step would be incorrect.

Check: The event probability across six batches must exceed the one-batch flag probability.
::::
:::

:::callout-pitfall[Binomial traps that cost calculator points]
A binomial distribution counts the event you defined, even when that event is a **failure** in ordinary language. Its $p$ is then the failure probability. Do not forget $\binom nx$ for “exactly $x$” when the successful positions are unspecified. Do not include $x=k$ when a question asks **more than** $k$. Do not compute all terms up to $n=100$ for a simple complement. Most importantly, in a repeated-shipment follow-up, the second trial is a **whole shipment**, not another sensor; recalculate the probability of that shipment-level event before raising it to the number of shipments.
:::

## 4.6 The Poisson Distribution

:::callout-intuition[Events per length, area, or time]
A warehouse can decide to check exactly eighty sensors, so its trial count is fixed. A hospital cannot decide that exactly eighty phone calls will have opportunities to occur during the next hour. Calls, flaws in copper wire, and contamination particles on disk surfaces are events that appear throughout an interval. If a stable rate describes those events and independent disjoint portions behave alike, the **number of events** in a specified amount of time, length, or area is naturally modeled by Poisson.
:::

### Poisson counts and the interval parameter

:::definition[Definition 4.8 — Poisson random variable]
A Poisson process has an approximately constant event rate, independent event occurrences across disjoint small intervals, and negligible probability of two or more events in a sufficiently tiny interval. The count $X$ of events in a specified interval follows a Poisson distribution with parameter $\lambda>0$:

$$
f(x)=P(X=x)=\frac{e^{-\lambda}\lambda^x}{x!},\qquad x=0,1,2,\ldots.
$$

Its mean and variance are $\mu=\lambda$ and $\sigma^2=\lambda$, so $\sigma=\sqrt\lambda$. All three expressions appear on the **Poisson row of the Final sheet, page 2**. The exponential function on the TI-30X IIS is the inverse of natural logarithm; use the calculator's $e^x$ operation to evaluate the exponent.
:::

The parameter $\lambda$ means the **expected number of events in the interval the question actually asks about**, not necessarily the rate quoted in the story. If the rate is four arrivals per hour, then a half-hour interval has $\lambda=4(0.5)=2$, and a three-hour interval has $\lambda=4(3)=12$. Write the units in the first step: $(4\ \mathrm{customers/hour})(0.5\ \mathrm{hour})=2\ \mathrm{customers}$. Units cancel; that is the most reliable way to avoid a factor-of-two or factor-of-sixty mistake.

The same scaling works for spatial counts. If a wire averages $2.3$ flaws per millimeter, then five millimeters has $\lambda=11.5$ flaws. If a disk surface averages $0.1$ particles per square centimeter and the disk has $100$ square centimeters, then $\lambda=10$ particles over the entire disk. **Area** and **length** are intervals in this context, just as time is. You must convert to the unit named by the rate before plugging anything into the Poisson formula.

### The meaning of zero events and the complement

The simplest Poisson probability is $P(X=0)=e^{-\lambda}\lambda^0/0!=e^{-\lambda}$. The factors $\lambda^0$ and $0!$ are both one, so the expression reduces to $e^{-\lambda}$. This is the chance that **none** of the events occurs during the whole interval. Its complement, $1-e^{-\lambda}$, is the chance **at least one** event occurs. If the rate is large or the interval is long, zero arrivals becomes less likely because $e^{-\lambda}$ gets smaller.

For “five or fewer,” you need the six probabilities for zero through five; for “at least one,” only zero is excluded, so the complement is ideal. For “more than three,” exclude zero through three. These event-translations match the general CDF rules from Section 4.2. A Poisson count has no fixed maximum, so complementing a small lower tail can avoid an **infinite** upper-tail sum.

Never replace the Poisson exponent $e^{-\lambda}$ by $e^{-r}$, where $r$ is the original hourly rate. The exponent and power both use the interval-specific $\lambda$. For an arriving customer rate of four per hour over thirty minutes, the correct zero-arrival chance is $e^{-2}$, not $e^{-4}$; the latter answers the one-hour question instead.

### Reading the rate without confusing it with probability

A rate of five flaws per centimeter is neither a probability of $5$ nor a binomial success probability $p=5$. Probabilities are between zero and one, but an expected Poisson event count may be any positive number. You are free to observe more than five flaws in one centimeter even when the mean is five. The mean is not an upper bound. This distinguishes a Poisson count on $0,1,2,\ldots$ from a binomial count, which cannot exceed the specified number of trials $n$.

The mean and variance of a Poisson random variable are numerically equal, but their **units** are not: the mean is events and the variance is events squared. The standard deviation is the square root of the interval mean. If one hour has mean four arrivals, the variance is four and the standard deviation is two arrivals. If you triple the interval, mean and variance triple; standard deviation grows by the square root of three rather than tripling.

:::example[Example 4.19 — Flaws along thin copper wire]
Flaws occur independently at random along a thin copper wire at a mean rate of $2.3$ flaws per millimeter. Let $X$ count flaws in the specified length. Find (a) exactly two flaws in one millimeter, (b) exactly ten flaws in five millimeters, and (c) at least one flaw in two millimeters.

::::answer[Answer]
**Answer:** (a) 0.2652, (b) 0.1129, (c) 0.9899

1. For one millimeter, the interval parameter is $\lambda=2.3(1)=2.3$. Use the Poisson PMF: $P(X=2)=e^{-2.3}(2.3)^2/2!=0.265185\approx0.2652$.
2. For five millimeters, the interval parameter changes to $\lambda=2.3(5)=11.5$. Now $P(X=10)=e^{-11.5}(11.5)^{10}/10!=0.112935\approx0.1129$.
3. For two millimeters, $\lambda=2.3(2)=4.6$. “At least one” excludes the zero-flaw case: $P(X\ge1)=1-e^{-4.6}=0.989948\approx0.9899$.
4. These probabilities describe different lengths of wire. Reusing $\lambda=2.3$ in all three parts would answer three one-millimeter questions rather than the requested intervals.

Check: All three interval means use the same rate times the corresponding length.
::::
:::

:::example[Example 4.20 — Contamination particles on optical disks]
The particle count on a CD follows Poisson with mean rate $0.1$ contamination particles per square centimeter. A disk has area $100$ square centimeters. Find the probabilities of (a) exactly twelve particles, (b) exactly zero particles, and (c) twelve or fewer particles on this disk.

::::answer[Answer]
**Answer:** (a) 0.0948, (b) 0.0000454, (c) 0.7916

1. The quoted rate is per **square centimeter**, not per disk. Multiply by area: $\lambda=(0.1)(100)=10$ expected contamination particles on the disk.
2. Exactly twelve uses one Poisson PMF term: $P(X=12)=e^{-10}10^{12}/12!=0.0947803\approx0.0948$.
3. No particles gives $P(X=0)=e^{-10}10^0/0!=e^{-10}=0.0000453999$, which is best retained as $0.0000454$ rather than rounded to zero.
4. Twelve or fewer includes thirteen terms. Type $P(X\le12)=e^{-10}[10^0/0!+10^1/1!+10^2/2!+10^3/3!+10^4/4!+10^5/5!+10^6/6!+10^7/7!+10^8/8!+10^9/9!+10^{10}/10!+10^{11}/11!+10^{12}/12!]\approx0.7915565$, or $0.7916$. Retain the calculator's intermediate precision rather than rounding each small probability separately.
5. In context, there is roughly a $79.16\%$ chance a disk has at most twelve particles, despite the mean count of ten.

Check: The CDF exceeds the single value $P(X=12)$, as it must.
::::
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Poisson PMF for count of contamination particles on one hundred square centimeters">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.43 H 626"/>
<text class="fig-label" x="2" y="110.43">0.072</text>
<path class="fig-gridline" d="M 48 19.85 H 626"/>
<text class="fig-label" x="2" y="23.85">0.144</text>
<path class="fig-curve" d="M 60.57 193 V 192.95"/>
<circle class="fig-point" cx="60.57" cy="192.95" r="3"/>
<text class="fig-label" x="60.57" y="211">0</text>
<path class="fig-curve" d="M 85.70 193 V 192.45"/>
<circle class="fig-point" cx="85.70" cy="192.45" r="3"/>
<text class="fig-label" x="85.70" y="211">1</text>
<path class="fig-curve" d="M 110.83 193 V 190.27"/>
<circle class="fig-point" cx="110.83" cy="190.27" r="3"/>
<text class="fig-label" x="110.83" y="211">2</text>
<path class="fig-curve" d="M 135.96 193 V 183.90"/>
<circle class="fig-point" cx="135.96" cy="183.90" r="3"/>
<text class="fig-label" x="135.96" y="211">3</text>
<path class="fig-curve" d="M 161.09 193 V 170.25"/>
<circle class="fig-point" cx="161.09" cy="170.25" r="3"/>
<text class="fig-label" x="161.09" y="211">4</text>
<path class="fig-curve" d="M 186.22 193 V 147.51"/>
<circle class="fig-point" cx="186.22" cy="147.51" r="3"/>
<text class="fig-label" x="186.22" y="211">5</text>
<path class="fig-curve" d="M 211.35 193 V 117.18"/>
<circle class="fig-point" cx="211.35" cy="117.18" r="3"/>
<text class="fig-label" x="211.35" y="211">6</text>
<path class="fig-curve" d="M 236.48 193 V 84.69"/>
<circle class="fig-point" cx="236.48" cy="84.69" r="3"/>
<text class="fig-label" x="236.48" y="211">7</text>
<path class="fig-curve" d="M 261.61 193 V 57.61"/>
<circle class="fig-point" cx="261.61" cy="57.61" r="3"/>
<text class="fig-label" x="261.61" y="211">8</text>
<path class="fig-curve" d="M 286.74 193 V 42.57"/>
<circle class="fig-point" cx="286.74" cy="42.57" r="3"/>
<text class="fig-label" x="286.74" y="211">9</text>
<path class="fig-curve" d="M 311.87 193 V 42.57"/>
<circle class="fig-point" cx="311.87" cy="42.57" r="3"/>
<text class="fig-label" x="311.87" y="211">10</text>
<path class="fig-curve" d="M 337.00 193 V 56.24"/>
<circle class="fig-point" cx="337.00" cy="56.24" r="3"/>
<text class="fig-label" x="337.00" y="211">11</text>
<path class="fig-curve" d="M 362.13 193 V 79.03"/>
<circle class="fig-point" cx="362.13" cy="79.03" r="3"/>
<text class="fig-label" x="362.13" y="211">12</text>
<path class="fig-curve" d="M 387.26 193 V 105.33"/>
<circle class="fig-point" cx="387.26" cy="105.33" r="3"/>
<text class="fig-label" x="387.26" y="211">13</text>
<path class="fig-curve" d="M 412.39 193 V 130.38"/>
<circle class="fig-point" cx="412.39" cy="130.38" r="3"/>
<text class="fig-label" x="412.39" y="211">14</text>
<path class="fig-curve" d="M 437.52 193 V 151.25"/>
<circle class="fig-point" cx="437.52" cy="151.25" r="3"/>
<text class="fig-label" x="437.52" y="211">15</text>
<path class="fig-curve" d="M 462.65 193 V 166.91"/>
<circle class="fig-point" cx="462.65" cy="166.91" r="3"/>
<text class="fig-label" x="462.65" y="211">16</text>
<path class="fig-curve" d="M 487.78 193 V 177.65"/>
<circle class="fig-point" cx="487.78" cy="177.65" r="3"/>
<text class="fig-label" x="487.78" y="211">17</text>
<path class="fig-curve" d="M 512.91 193 V 184.47"/>
<circle class="fig-point" cx="512.91" cy="184.47" r="3"/>
<text class="fig-label" x="512.91" y="211">18</text>
<path class="fig-curve" d="M 538.04 193 V 188.51"/>
<circle class="fig-point" cx="538.04" cy="188.51" r="3"/>
<text class="fig-label" x="538.04" y="211">19</text>
<path class="fig-curve" d="M 563.17 193 V 190.76"/>
<circle class="fig-point" cx="563.17" cy="190.76" r="3"/>
<text class="fig-label" x="563.17" y="211">20</text>
<path class="fig-curve" d="M 588.30 193 V 191.93"/>
<circle class="fig-point" cx="588.30" cy="191.93" r="3"/>
<text class="fig-label" x="588.30" y="211">21</text>
<path class="fig-curve" d="M 613.43 193 V 192.51"/>
<circle class="fig-point" cx="613.43" cy="192.51" r="3"/>
<text class="fig-label" x="613.43" y="211">22</text>
</svg>
<figcaption>For a disk with mean contamination count ten, Poisson probabilities center near ten but remain possible for larger counts without a fixed upper bound.</figcaption>
</figure>

:::example[Example 4.21 — Package kiosk: five rate and probability questions]
Customers arrive at a self-service package drop-off kiosk according to a Poisson process averaging $4$ customers per hour. Find (a) zero arrivals in thirty minutes, (b) exactly three in one hour, (c) five or fewer in two hours, (d) the length in hours for the probability of zero arrivals to be $0.05$, and (e) the mean and standard deviation for a three-hour count.

::::answer[Answer]
**Answer:** (a) 0.1353, (b) 0.1954, (c) 0.1912, (d) 0.7489 hours, (e) mean 12.0000, standard deviation 3.4641

1. Convert thirty minutes to $0.5$ hours. The corresponding interval mean is $\lambda=4(0.5)=2$, so $P(X=0)=e^{-2}=0.135335\approx0.1353$.
2. One hour has $\lambda=4$, hence $P(X=3)=e^{-4}4^3/3!=0.195367\approx0.1954$.
3. Two hours has $\lambda=8$. Add zero through five arrivals: $P(X\le5)=e^{-8}[8^0/0!+8^1/1!+8^2/2!+8^3/3!+8^4/4!+8^5/5!]\approx0.191236\approx0.1912$.
4. Let the unknown interval length be $t$ hours; its mean is $\lambda=4t$. No-arrival probability is $e^{-4t}=0.05$. Take natural logs: $-4t=\ln(0.05)$ and $t=-\ln(0.05)/4=0.748933$ hours, about forty-five minutes.
5. Three hours has mean $\lambda=4(3)=12$ and standard deviation $\sqrt{12}=3.4641$ arrivals. All five answers refer to the same rate but different intervals or questions.

Check: Substituting $t=0.748933$ gives $e^{-4t}pprox0.05$.
::::
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 650 240" width="650" height="240" role="img" aria-label="Poisson PMF for a half hour with mean two arrivals">
<path class="fig-axis" d="M 48 20 V 193 H 626"/>
<path class="fig-gridline" d="M 48 193.00 H 626"/>
<text class="fig-label" x="2" y="197.00">0</text>
<path class="fig-gridline" d="M 48 106.30 H 626"/>
<text class="fig-label" x="2" y="110.30">0.156</text>
<path class="fig-gridline" d="M 48 20.15 H 626"/>
<text class="fig-label" x="2" y="24.15">0.311</text>
<path class="fig-curve" d="M 76.90 193 V 117.78"/>
<circle class="fig-point" cx="76.90" cy="117.78" r="3"/>
<text class="fig-label" x="76.90" y="211">0</text>
<path class="fig-curve" d="M 134.70 193 V 42.57"/>
<circle class="fig-point" cx="134.70" cy="42.57" r="3"/>
<text class="fig-label" x="134.70" y="211">1</text>
<path class="fig-curve" d="M 192.50 193 V 42.57"/>
<circle class="fig-point" cx="192.50" cy="42.57" r="3"/>
<text class="fig-label" x="192.50" y="211">2</text>
<path class="fig-curve" d="M 250.30 193 V 92.71"/>
<circle class="fig-point" cx="250.30" cy="92.71" r="3"/>
<text class="fig-label" x="250.30" y="211">3</text>
<path class="fig-curve" d="M 308.10 193 V 142.86"/>
<circle class="fig-point" cx="308.10" cy="142.86" r="3"/>
<text class="fig-label" x="308.10" y="211">4</text>
<path class="fig-curve" d="M 365.90 193 V 172.94"/>
<circle class="fig-point" cx="365.90" cy="172.94" r="3"/>
<text class="fig-label" x="365.90" y="211">5</text>
<path class="fig-curve" d="M 423.70 193 V 186.31"/>
<circle class="fig-point" cx="423.70" cy="186.31" r="3"/>
<text class="fig-label" x="423.70" y="211">6</text>
<path class="fig-curve" d="M 481.50 193 V 191.09"/>
<circle class="fig-point" cx="481.50" cy="191.09" r="3"/>
<text class="fig-label" x="481.50" y="211">7</text>
<path class="fig-curve" d="M 539.30 193 V 192.52"/>
<circle class="fig-point" cx="539.30" cy="192.52" r="3"/>
<text class="fig-label" x="539.30" y="211">8</text>
<path class="fig-curve" d="M 597.10 193 V 192.89"/>
<circle class="fig-point" cx="597.10" cy="192.89" r="3"/>
<text class="fig-label" x="597.10" y="211">9</text>
</svg>
<figcaption>A thirty-minute interval at four customers per hour has $\lambda=2$, and its probability of no arrivals is the first bar, $e^{-2}$.</figcaption>
</figure>

### Solving backward for an interval length

If the probability of **zero arrivals** is given and the time interval is unknown, start with the event you know: $P(X=0)=e^{-rt}$ when the average rate is $r$ events per unit time and the duration is $t$ matching units. Setting the probability equal to a target $q$ gives $e^{-rt}=q$. Because the natural logarithm undoes the exponential, take $\ln$ of both sides, giving $-rt=\ln q$. Finally divide by $-r$:

$$
t=-\frac{\ln q}{r}.
$$

This is a rearrangement of the Poisson zero-count formula on Final sheet page 2. It is not an extra item you need to memorize. To solve such a problem, write the zero-count expression first and rearrange it logically. The answer must be positive because $0<q<1$ gives $\ln q<0$. If the rate was per hour, the answer is in hours; multiply by sixty only if the question asks for minutes.

A related wording trap is “the bouncer waits more than three minutes for the **next** arrival.” That random variable is a *waiting time*, not a count. You can still interpret the event as **zero arrivals during the next three minutes**, and under a Poisson process the probability is $e^{-\lambda}$ with $\lambda=(30\ \mathrm{hour}^{-1})(3/60\ \mathrm{hour})=1.5$. Chapter 5 develops the exponential waiting-time model directly; keep this bridge conceptual here rather than replacing that chapter.

:::example[Example 4.22 — Calls per household over an entire week]
Phone calls to a typical household follow a Poisson distribution with mean $1.8$ calls per day. Find (a) the probability of three or fewer calls during an entire seven-day week and (b) the expected number in one week.

::::answer[Answer]
**Answer:** (a) 0.001438, (b) 12.6000

1. The count is for a **week**, but the given rate is per day. Scale the parameter: $\lambda=(1.8\ \mathrm{calls/day})(7\ \mathrm{days})=12.6$ calls.
2. “Three or fewer” includes counts zero, one, two, and three. Calculate $P(X\le3)=e^{-12.6}[12.6^0/0!+12.6^1/1!+12.6^2/2!+12.6^3/3!]\approx0.00143775$, or $0.001438$.
3. The expected number of calls in the week is simply $\mu=\lambda=12.6$. In context, a household receiving no more than three calls over a whole week would be unusual if the daily Poisson rate really remains $1.8$.

Check: The week mean is seven times the day mean, while the probability is far below one.
::::
:::

:::callout-pitfall[Scale the Poisson rate before exponentiating]
If a rate is “per hour” and the interval is thirty minutes, the Poisson parameter is half the hourly rate. If the interval is three hours, it is three times the hourly rate. The PMF always uses the **same interval parameter** in both $e^{-\lambda}$ and $\lambda^x$. Other common mistakes are using $1-e^{-\lambda}$ for **zero** arrivals (it means at least one), or treating a Poisson mean of three as a maximum possible count of three. Neither error is a rounding problem; both change the event.
:::

### Practice: Poisson rates and counting events

:::problem[Problem 4.31 — Hospital emergency calls]{difficulty=easy}
A hospital receives an average of $3$ emergency calls per hour. What is the probability of receiving **no emergency calls** during a randomly selected hour? Choose (A) $0.0498$; (B) $0.1494$; (C) $0.9502$; (D) $0.1990$.

::::solution[Solution]
**Answer:** (A) 0.0498

1. The number of emergency calls is a Poisson count in one hour, and the supplied hourly mean already matches the requested interval, so $\lambda=3$.
2. For no calls, substitute $x=0$: $P(X=0)=e^{-3}3^0/0!=e^{-3}=0.0497871\approx0.0498$.
3. Choice A is correct. Choice C is the complement $1-e^{-3}$ and answers at least one call. Choice B is about three times the correct value, while D is about four times it; neither is a Poisson zero-count formula. In context, a quiet hour has probability just under five percent.

Check: The zero-event probability $e^{-3}$ is positive and below one.
::::
:::

:::problem[Problem 4.32 — Fewer than four lions]{difficulty=easy}
Suppose the average number of lions seen on a one-day safari is $5$. Assume a Poisson count. What is the probability tourists see **fewer than four** lions on the next one-day safari?

::::solution[Solution]
**Answer:** 0.2650

1. The count is measured over the same one-day period as the quoted mean, so $\lambda=5$ lions per day and no scaling is needed.
2. “Fewer than four” includes precisely zero, one, two, and three lions, not four. Compute $P(X<4)=e^{-5}[5^0/0!+5^1/1!+5^2/2!+5^3/3!]$.
3. The four terms total approximately $0.2650259$, so the answer is $0.2650$. In context, a safari with zero through three lion sightings has about a $26.5\%$ chance under this assumed count model.

Check: The event is the same as $F(3)$, not $F(4)$.
::::
:::

:::problem[Problem 4.33 — Earthquakes in a region]{difficulty=standard}
A region experiences an average of $4$ earthquakes of a specified magnitude each year. Assume an annual Poisson count. Find (a) no earthquakes, (b) exactly three earthquakes, and (c) **two or more** earthquakes during a selected year.

::::solution[Solution]
**Answer:** (a) 0.0183, (b) 0.1954, (c) 0.9084

1. The question and quoted mean both concern one year, so use $\lambda=4$ in every part.
2. No earthquakes gives $P(X=0)=e^{-4}=0.0183156$. Exactly three gives $P(X=3)=e^{-4}4^3/3!=0.195367$.
3. At least two means exclude zero and one. Compute $P(X\ge2)=1-[e^{-4}+e^{-4}4]=1-5e^{-4}=0.908422$.
4. In context, the model assigns roughly a $90.84\%$ probability to observing at least two earthquakes in a year, even though zero earthquakes remains possible.

Check: The three values match their respective point or tail events.
::::
:::

:::problem[Problem 4.34 — Disk particles, different areas]{difficulty=standard}
A disk surface has independent contamination particles at a rate of $0.1$ particle per square centimeter. Compare the probability of zero particles on an area of $30$ square centimeters with the probability of zero on an area of $100$ square centimeters.

::::solution[Solution]
**Answer:** smaller area 0.0498, larger area 0.0000454

1. Multiply the area by the rate to obtain the mean. Thirty square centimeters has $\lambda=0.1(30)=3$, while one hundred square centimeters has $\lambda=0.1(100)=10$.
2. For zero particles on the smaller area, compute $P(X=0)=e^{-3}=0.0497871\approx0.0498$.
3. For zero particles on the larger area, compute $P(X=0)=e^{-10}=0.0000453999\approx0.0000454$.
4. The larger region is much less likely to be completely free of contamination because it has more opportunities for particles to occur. Both probabilities refer to the same density but different areas.

Check: Since $10>3$, $e^{-10}<e^{-3}$, matching the physical interpretation.
::::
:::

:::problem[Problem 4.35 — Waiting more than three minutes for an arrival]{difficulty=standard}
Students arrive at a local bar and restaurant according to a Poisson process averaging $30$ arrivals per hour. What is the probability that a bouncer waits **more than three minutes** for the next student? Treat this as a zero-arrivals count over the first three minutes.

::::solution[Solution]
**Answer:** 0.2231

1. Time until the next arrival is continuous, but the requested event has an equivalent count description: no students arrive in the first three minutes.
2. Convert three minutes into $3/60=0.05$ hours. The interval mean is $\lambda=(30\ \mathrm{arrivals/hour})(0.05\ \mathrm{hour})=1.5$ expected arrivals.
3. Under a Poisson process, the probability of zero arrivals is $P(X=0)=e^{-1.5}=0.223130\approx0.2231$.
4. In context, the bouncer has about a $22.31\%$ chance of waiting longer than three minutes. The direct exponential waiting-time derivation belongs to Chapter 5.

Check: The zero-count event and the survival event describe the same three-minute interval.
::::
:::

:::problem[Problem 4.36 — Rate from a zero-count probability]{difficulty=challenge}
A Poisson process has average rate $6$ events per hour. How many minutes should you observe so that the probability of **zero** events during the observation equals $0.20$?

::::solution[Solution]
**Answer:** 16.0944 minutes

1. Let $t$ be the observation duration in hours. A rate of six per hour gives interval mean $\lambda=6t$.
2. The zero-event equation is $e^{-6t}=0.20$. Take natural logarithms: $-6t=\ln(0.20)$ and $t=-\ln(0.20)/6\approx0.2682397$ hours.
3. Convert to minutes, multiplying by sixty: $0.2682397(60)=16.0944$ minutes.
4. The answer is positive because the logarithm of a probability between zero and one is negative. In context, an observation of about sixteen minutes has a $20\%$ chance of recording no events.

Check: Using the unrounded duration gives $e^{-6(16.0944/60)}pprox0.20$.
::::
:::

## Chapter Summary

:::summary[Discrete probability exam checklist]
The starting point is always the **random variable**: define what it counts and what its possible values are. A discrete PMF gives $f(x)=P(X=x)$ with nonnegative masses totaling one. A cumulative function gives $F(x)=P(X\le x)$; it adds all point masses through the cutoff and is flat between supported values.

From a general PMF table, calculate $\mu$ by multiplying each value by its probability and adding. Calculate $E(X^2)$ by squaring **each value first**, multiplying by its probability and adding. Then $\sigma^2=E(X^2)-\mu^2$, and $\sigma=\sqrt{\sigma^2}$. These are all on **Final sheet page 1**. Do not confuse this variance with sample variance, and do not invent probabilities from a stated range.

For **binomial**, require a fixed number $n$ of independent two-outcome trials with constant counted-event probability $p$. Use $P(X=x)=\binom nx p^x(1-p)^{n-x}$, $\mu=np$, and $\sigma^2=np(1-p)$. For **Poisson**, count independent events over a specified time, length, or area, scale $\lambda$ to that interval, and use $P(X=x)=e^{-\lambda}\lambda^x/x!$, $\mu=\lambda$, and $\sigma^2=\lambda$. Both families appear on **Final sheet page 2**.

**Word-to-event translation:** “exactly three” is $X=3$; “at most three” is $X\le3$; “fewer than three” is $X\le2$; “more than three” is $X\ge4$; “at least three” is $X\ge3$. For unbounded upper tails, complement the short lower tail. For independent batches or shipments, solve the probability that *one entire group* meets the condition, then use that as the new probability in the repeated-group count.

Discrete uniform, geometric, and negative binomial are Exam 2 recognition topics beyond the Final list. The difference between a fixed trial count and a stopping-at-success experiment identifies most of them immediately. A Poisson **count** is not the same as an exponential **waiting time**, which is covered in Chapter 5.
:::

## Mixed Practice

The comprehensive final uses multiple choice, a true/false item with three statements, and a matching item with four descriptions. About half its questions need arithmetic. These mixed items deliberately alternate identification and calculation, rather than telling you the distribution in the heading. Choose an option before opening the answer. Every incorrect option is included for a reason; the solution explains the relevant trap.

:::problem[Problem M.1 — Choose the discrete variable]{difficulty=easy}
Which one is a discrete random variable? (A) outside temperature at noon; (B) the mass of a randomly selected package; (C) the number of defective items in a shipment; (D) the time needed to finish a test.

::::solution[Solution]
**Answer:** (C) number of defective items

1. A discrete variable has a finite or countably infinite set of possible values, and a count of defective items is an integer.
2. Choice A is a temperature measurement, B is a mass measurement, and D is a duration measurement; all three are typically modeled continuously.
3. Choice C is therefore the only discrete count. The point is not that continuous measurements must have infinitely many recorded decimals, but that the mathematical model permits real-valued measurements over intervals. A shipment count does not take fractional values.

Check: A defect count cannot equal half of a defective item.
::::
:::

:::problem[Problem M.2 — CDF at a noninteger threshold]{difficulty=easy}
A discrete distribution has $P(X=0)=0.30$, $P(X=1)=0.40$, $P(X=2)=0.20$, and $P(X=3)=0.10$. What is $F(1.8)$? (A) $0.40$; (B) $0.70$; (C) $0.90$; (D) $1.00$.

::::solution[Solution]
**Answer:** (B) 0.7000

1. The cumulative event $X\le1.8$ includes zero and one only because $X$ takes integer values. Add $0.30+0.40=0.70$.
2. Choice A uses only $f(1)$ and confuses mass with cumulative probability. Choice C additionally includes the value at two, which exceeds the cutoff. Choice D includes all outcomes, even three.
3. The correct answer is B. In context, $70\%$ of realizations are at or below $1.8$, which means at most one for this discrete variable.

Check: The result lies between $F(1)=0.70$ and $F(2)=0.90$, matching the step function.
::::
:::

:::problem[Problem M.3 — Which count is binomial?]{difficulty=standard}
Which model is appropriate for the number of defective parts among $40$ independently manufactured parts when each has a constant defect probability of $0.04$? (A) Poisson with $\lambda=40$; (B) Binomial with $n=40,p=0.04$; (C) Geometric with $p=0.04$; (D) Continuous normal with $\mu=40$.

::::solution[Solution]
**Answer:** (B) binomial

1. The trials are the forty separate manufactured parts. Each is defective or not, inspections are independent, and the defect probability does not change.
2. These are exactly the binomial conditions, so choose B. Choice A ignores the fixed number of trials and assigns the wrong Poisson parameter. Choice C asks a waiting-until-first-defect question, not the total over forty parts. Choice D is continuous and does not directly describe this finite integer count.
3. The correct parameters are the number inspected and the probability of a defect in one part.

Check: The stated count is always between zero and forty.
::::
:::

:::problem[Problem M.4 — Poisson scaling before substitution]{difficulty=standard}
A call center averages $2$ calls every hour, following Poisson. What is the probability of no calls in a three-hour window? (A) $e^{-2}\approx0.1353$; (B) $e^{-6}\approx0.0025$; (C) $1-e^{-6}\approx0.9975$; (D) $6e^{-6}\approx0.0149$.

::::solution[Solution]
**Answer:** (B) 0.0025

1. The original rate is two calls **per hour**. Three hours means $\lambda=2(3)=6$ expected calls in that window.
2. For no calls, use $P(X=0)=e^{-6}=0.00247875$, which rounds to $0.0025$, so choose B.
3. A forgets to scale the rate. C takes the complement and therefore answers **at least one call**. D resembles an exactly-one Poisson term $\lambda e^{-\lambda}$, not zero calls. The small answer fits a six-call average over the longer interval.

Check: The chance of a quiet three-hour interval is smaller than that of a quiet one-hour interval.
::::
:::

:::problem[Problem M.5 — PMF mean rather than sample mean]{difficulty=standard}
An inspection-error count has masses $f(0)=0.20$, $f(1)=0.50$, and $f(2)=0.30$. Find $\mu$. (A) $1.0000$; (B) $1.1000$; (C) $1.5000$; (D) $0.3000$.

::::solution[Solution]
**Answer:** (B) 1.1000

1. The three outcomes carry unequal probabilities, so multiply each possible value by its own mass: $0(0.20)+1(0.50)+2(0.30)=1.10$.
2. Choice B is correct. Choice A is the simple midpoint of zero and two, ignoring the weighting. Choice C is an unweighted average of one and two. Choice D merely repeats the probability attached to the largest count.
3. The result means an average of $1.1$ errors across many observations, even though one observation must be an integer count.

Check: The weighted mean falls between the smallest and largest possible counts.
::::
:::

:::problem[Problem M.6 — Two-level shipment event]{difficulty=standard}
A shipment has a $0.20$ probability of containing three or more defective parts, independently of other shipments. Four shipments are inspected. What is the chance that **at least one shipment** meets that condition? (A) $0.2000$; (B) $0.4096$; (C) $0.5904$; (D) $0.8000$.

::::solution[Solution]
**Answer:** (C) 0.5904

1. The new trial is an entire shipment. Its counted success is “three or more defective parts,” with event probability $q=0.20$.
2. With four independent shipments, the chance that all four **fail to meet** the condition is $(1-0.20)^4=(0.8)^4=0.4096$.
3. Take the complement: $1-0.4096=0.5904$, choice C. Choice A uses just one shipment; B forgets the complement and means zero qualifying shipments; D is not the result of four independent shipment trials.
4. The correct event has about a $59.04\%$ chance.

Check: The repeated-group probability exceeds the single-group probability $0.2$.
::::
:::

:::problem[Problem M.7 — Two claims about Poisson spread]{difficulty=standard}
For a Poisson count in a two-hour interval, the expected number of events is $\lambda=9$. Which is the standard deviation? (A) $81$; (B) $9$; (C) $4.5$; (D) $3$.

::::solution[Solution]
**Answer:** (D) 3.0000

1. The Poisson row gives variance $\sigma^2=\lambda$. Here both the mean and variance have numerical value nine, but they represent different things.
2. The standard deviation is the square root of the variance: $\sigma=\sqrt9=3$, so choose D.
3. Choice B reports the variance or mean rather than the standard deviation. Choice A squares instead of taking the square root. Choice C divides the mean by the two-hour interval length, which changes the rate but does not give a standard deviation. The unit of the answer is events.

Check: Squaring the reported standard deviation yields the given variance nine.
::::
:::

:::problem[Problem M.8 — At least four rather than more than four]{difficulty=challenge}
Let $X\sim\mathrm{Binomial}(n=10,p=0.2)$. Which expression correctly computes $P(X\ge4)$? (A) $1-[f(0)+f(1)+f(2)]$; (B) $1-[f(0)+f(1)+f(2)+f(3)]$; (C) $F(4)$; (D) $f(4)$.

::::solution[Solution]
**Answer:** (B) complement through three

1. “At least four” means four, five, and every higher possible count through ten. The excluded cases are zero through three.
2. Therefore $P(X\ge4)=1-P(X\le3)=1-[f(0)+f(1)+f(2)+f(3)]$, making B correct.
3. A excludes only up through two, so it includes the unwanted count three. C instead counts zero through four; D counts exactly four and ignores five or more. The chosen expression is correct before any calculator arithmetic, which is the skill this multiple-choice item tests.

Check: The complement of $X\ge4$ is $X\le3$, not $X\le4$.
::::
:::

:::problem[Problem M.9 — The uniform counting trap]{difficulty=standard}
A fair random-number generator returns an integer from $2$ through $8$ inclusive. What is $P(X=5)$? (A) $1/6$; (B) $1/7$; (C) $1/8$; (D) $5/7$.

::::solution[Solution]
**Answer:** (B) 0.1429

1. Count all allowed integers explicitly: two, three, four, five, six, seven, and eight. That is seven values, not six.
2. Every value is equally likely, so the probability assigned to five is $1/7\approx0.142857$, which rounds to $0.1429$. Thus B is correct.
3. Choice A forgets the inclusive endpoint, C incorrectly treats the upper endpoint as the count of possibilities, and D treats the value five as five favorable outcomes. The probability belongs to one exact code, not to the magnitude of that code.

Check: Seven identical masses of $1/7$ sum to one.
::::
:::

:::problem[Problem M.10 — Waiting time versus arrival count]{difficulty=standard}
Which statement best matches the random variable “minutes until the **next** customer arrives” when arrivals follow a Poisson process? (A) It is a Poisson event **count**; (B) it is a binomial count; (C) it is an exponential **waiting time**; (D) it is a discrete uniform selection.

::::solution[Solution]
**Answer:** (C) exponential waiting time

1. The wording asks how long it takes until an event happens, rather than how many events happen in a specified interval.
2. Choice C identifies the correct continuous waiting-time family. Choice A would match the *number of customers* arriving within a fixed period. B would require a fixed number of independent yes/no trials; D would require equally likely discrete values.
3. Exponential waiting-time calculations belong to Chapter 5. For this recognition question, the distinction between a measured duration and a count is sufficient.

Check: The requested random variable can take noninteger durations.
::::
:::

:::problem[Problem M.11 — Three true or false statements]{difficulty=standard}
Mark each claim **true** or **false**. (a) For a discrete variable, $F(2)$ is always equal to $f(2)$. (b) If $X$ is Poisson with mean $\lambda=4$, its variance is also $4$. (c) The sum of every possible value's PMF probability must equal one.

::::solution[Solution]
**Answer:** (a) false; (b) true; (c) true

1. Statement (a) is false because the CDF sums **all** probabilities at or below two, whereas the PMF gives only the mass at exactly two. Equality would be an exceptional case, not a general identity.
2. Statement (b) is true: the Poisson distribution's mean and variance both equal its parameter. Statement (c) is true because all mutually exclusive possible values cover the complete sample space.
3. The traps are confusing point mass with cumulative probability and overlooking the normalization rule. No numerical table lookup is needed for these conceptual final-exam statements.

Check: The first claim contradicts the CDF definition; the other two match printed formulas.
::::
:::

:::problem[Problem M.12 — Match four count models]{difficulty=standard}
Match each numbered scenario to one model: (A) discrete uniform, (B) binomial, (C) Poisson, (D) geometric. **1.** One of six digits is chosen with equal probability. **2.** Independent inspection of a fixed set of twenty parts, counting defectives. **3.** Number of calls received in a thirty-minute interval at a constant average rate. **4.** Number of trials until the first successful wafer test.

::::solution[Solution]
**Answer:** A, B, C, D

1. Equal probability across a predetermined finite set makes scenario one discrete uniform, A. A fixed number of independent two-outcome trials makes scenario two binomial, B.
2. A count of random occurrences during a fixed time interval at a stable rate is Poisson, C, so scenario three matches it. A trial count that stops at the first success is geometric, D, so scenario four matches that model.
3. In context, the difference between the last two is whether you fix the observation interval before counting events or keep repeating trials until success. The matching sequence is A, B, C, D.

Check: Every model uses its defining experiment structure, not an unrelated numerical formula.
::::
:::

