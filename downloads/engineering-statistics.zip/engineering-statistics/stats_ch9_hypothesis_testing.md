---
title: "Hypothesis Testing"
crumb: "Engineering Statistics I · Chapter 9"
meta:
  - "IE 4613/6613 · Unit 9"
  - "Z, t and chi-square tests; errors, power and p-values"
  - "Exam 3 and comprehensive final preparation"
---

## Overview

A part can be a little long in a sample without the production line being systematically too long. A golf club can rebound slightly better in a small batch without its true average coefficient having changed. A detergent filling machine can show an unusually large sample variance even while the process remains within specification. A **hypothesis test** makes that tension precise: how unusual would the measured sample be if the proposed population value were actually correct?

This chapter teaches the procedure printed on the Final Exam Equations sheet, not a separate memorized workflow. The choices to make are the population parameter, the alternative direction, whether the population standard deviation is known, and whether we are testing a mean or a variance. The computations follow once those choices are right. We will also calculate the chance of a false alarm, the chance of overlooking a real problem, and the power to detect a specified shift. You should be able to make every decision using a TI-30X IIS, the Final sheet and its three tables.

:::callout-key[Prerequisites]
Chapter 5 introduces cumulative normal probabilities and the relation $\Phi(-z)=1-\Phi(z)$. Chapter 7 explains standard error and the sampling distribution of $\bar X$. Chapter 8 explains confidence intervals and how to read the $t$ and chi-square tables. Here we use those tools for decisions rather than re-teach the distributions.
:::

:::callout-connect[What carries over]
The normal-table mechanics belong to Chapter 5; standard errors belong to Chapter 7; and confidence-interval construction belongs to Chapter 8. A hypothesis test combines all three without introducing a new kind of probability distribution.
:::

## 9.1 Claims, hypotheses, and the eight-step procedure


If a manufacturer says a machine **should** fill bottles with a mean of 16 ounces, that is a proposed population value. Taking a sample does not establish that the mean is exactly 16; it supplies evidence for or against that proposal. The test begins by making the proposal explicit and identifying what evidence would contradict it. This avoids a surprisingly common failure: calculating a perfect statistic for the wrong question.

:::callout-intuition[Innocent until the sample provides evidence]
Treat $H_0$ as the benchmark to challenge and $H_1$ as the engineer's competing claim. The null is a working assumption for calculating what unusual sampling outcomes look like. Reject it when an outcome falls in a sufficiently improbable region under that assumption. A failure to reject is not proof that the benchmark is exactly correct; it means the sample did not clear the chosen evidence threshold.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Standard normal curve with two symmetric rejection tails">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M55.00,220.00 L55.00,219.95 L55.53,219.95 L56.05,219.95 L56.58,219.94 L57.10,219.94 L57.63,219.94 L58.16,219.94 L58.68,219.94 L59.21,219.93 L59.73,219.93 L60.26,219.93 L60.79,219.93 L61.31,219.92 L61.84,219.92 L62.36,219.92 L62.89,219.92 L63.42,219.91 L63.94,219.91 L64.47,219.91 L64.99,219.90 L65.52,219.90 L66.04,219.90 L66.57,219.89 L67.10,219.89 L67.62,219.89 L68.15,219.88 L68.67,219.88 L69.20,219.87 L69.73,219.87 L70.25,219.87 L70.78,219.86 L71.30,219.86 L71.83,219.85 L72.36,219.85 L72.88,219.84 L73.41,219.84 L73.93,219.83 L74.46,219.83 L74.99,219.82 L75.51,219.82 L76.04,219.81 L76.56,219.81 L77.09,219.80 L77.62,219.79 L78.14,219.79 L78.67,219.78 L79.19,219.77 L79.72,219.77 L80.24,219.76 L80.77,219.75 L81.30,219.74 L81.82,219.74 L82.35,219.73 L82.87,219.72 L83.40,219.71 L83.93,219.70 L84.45,219.69 L84.98,219.68 L85.50,219.67 L86.03,219.66 L86.56,219.65 L87.08,219.64 L87.61,219.63 L88.13,219.62 L88.66,219.61 L89.19,219.60 L89.71,219.59 L90.24,219.57 L90.76,219.56 L91.29,219.55 L91.82,219.54 L92.34,219.52 L92.87,219.51 L93.39,219.49 L93.92,219.48 L94.45,219.46 L94.97,219.45 L95.50,219.43 L96.02,219.42 L96.55,219.40 L97.07,219.38 L97.60,219.36 L98.13,219.35 L98.65,219.33 L99.18,219.31 L99.70,219.29 L100.23,219.27 L100.76,219.25 L101.28,219.23 L101.81,219.21 L102.33,219.18 L102.86,219.16 L103.39,219.14 L103.91,219.11 L104.44,219.09 L104.96,219.06 L105.49,219.04 L106.02,219.01 L106.54,218.99 L107.07,218.96 L107.59,218.93 L108.12,218.90 L108.65,218.87 L109.17,218.84 L109.70,218.81 L110.22,218.78 L110.75,218.75 L111.28,218.71 L111.80,218.68 L112.33,218.64 L112.85,218.61 L113.38,218.57 L113.91,218.53 L114.43,218.49 L114.96,218.45 L115.48,218.41 L116.01,218.37 L116.53,218.33 L117.06,218.29 L117.59,218.24 L118.11,218.20 L118.64,218.15 L119.16,218.10 L119.69,218.06 L120.22,218.01 L120.74,217.96 L121.27,217.91 L121.79,217.85 L122.32,217.80 L122.85,217.74 L123.37,217.69 L123.90,217.63 L124.42,217.57 L124.95,217.51 L125.48,217.45 L126.00,217.39 L126.53,217.32 L127.05,217.26 L127.58,217.19 L128.11,217.12 L128.63,217.05 L129.16,216.98 L129.68,216.91 L130.21,216.83 L130.74,216.76 L131.26,216.68 L131.79,216.60 L132.31,216.52 L132.84,216.44 L133.36,216.36 L133.89,216.27 L134.42,216.18 L134.94,216.09 L135.47,216.00 L135.99,215.91 L136.52,215.82 L137.05,215.72 L137.57,215.62 L138.10,215.52 L138.62,215.42 L139.15,215.32 L139.68,215.21 L140.20,215.10 L140.73,214.99 L141.25,214.88 L141.78,214.76 L142.31,214.65 L142.83,214.53 L143.36,214.41 L143.88,214.28 L144.41,214.16 L144.94,214.03 L145.46,213.90 L145.99,213.77 L146.51,213.63 L147.04,213.49 L147.56,213.35 L148.09,213.21 L148.62,213.07 L149.14,212.92 L149.67,212.77 L150.19,212.61 L150.72,212.46 L151.25,212.30 L151.77,212.14 L152.30,211.97 L152.82,211.81 L153.35,211.64 L153.88,211.46 L154.40,211.29 L154.93,211.11 L155.45,210.93 L155.98,210.74 L156.51,210.56 L157.03,210.37 L157.56,210.17 L158.08,209.97 L158.61,209.77 L159.14,209.57 L159.66,209.36 L160.19,209.15 L160.71,208.94 L161.24,208.72 L161.77,208.50 L162.29,208.28 L162.82,208.05 L163.34,207.82 L163.87,207.58 L164.39,207.34 L164.92,207.10 L165.45,206.86 L165.97,206.61 L166.50,206.35 L167.02,206.10 L167.55,205.84 L168.08,205.57 L168.60,205.30 L169.13,205.03 L169.65,204.76 L170.18,204.48 L170.71,204.19 L171.23,203.90 L171.76,203.61 L172.28,203.31 L172.81,203.01 L173.34,202.71 L173.86,202.40 L174.39,202.09 L174.91,201.77 L175.44,201.45 L175.97,201.12 L176.49,200.79 L177.02,200.46 L177.54,200.12 L178.07,199.77 L178.60,199.43 L179.12,199.07 L179.65,198.72 L180.17,198.36 L180.70,197.99 L181.23,197.62 L181.23,220.00 Z"/>
<path class="fig-fill-alt" d="M423.77,220.00 L423.77,197.62 L424.30,197.99 L424.83,198.36 L425.35,198.72 L425.88,199.07 L426.40,199.43 L426.93,199.77 L427.46,200.12 L427.98,200.46 L428.51,200.79 L429.03,201.12 L429.56,201.45 L430.09,201.77 L430.61,202.09 L431.14,202.40 L431.66,202.71 L432.19,203.01 L432.72,203.31 L433.24,203.61 L433.77,203.90 L434.29,204.19 L434.82,204.48 L435.35,204.76 L435.87,205.03 L436.40,205.30 L436.92,205.57 L437.45,205.84 L437.98,206.10 L438.50,206.35 L439.03,206.61 L439.55,206.86 L440.08,207.10 L440.61,207.34 L441.13,207.58 L441.66,207.82 L442.18,208.05 L442.71,208.28 L443.23,208.50 L443.76,208.72 L444.29,208.94 L444.81,209.15 L445.34,209.36 L445.86,209.57 L446.39,209.77 L446.92,209.97 L447.44,210.17 L447.97,210.37 L448.49,210.56 L449.02,210.74 L449.55,210.93 L450.07,211.11 L450.60,211.29 L451.12,211.46 L451.65,211.64 L452.18,211.81 L452.70,211.97 L453.23,212.14 L453.75,212.30 L454.28,212.46 L454.81,212.61 L455.33,212.77 L455.86,212.92 L456.38,213.07 L456.91,213.21 L457.43,213.35 L457.96,213.49 L458.49,213.63 L459.01,213.77 L459.54,213.90 L460.06,214.03 L460.59,214.16 L461.12,214.28 L461.64,214.41 L462.17,214.53 L462.69,214.65 L463.22,214.76 L463.75,214.88 L464.27,214.99 L464.80,215.10 L465.32,215.21 L465.85,215.32 L466.38,215.42 L466.90,215.52 L467.43,215.62 L467.95,215.72 L468.48,215.82 L469.01,215.91 L469.53,216.00 L470.06,216.09 L470.58,216.18 L471.11,216.27 L471.64,216.36 L472.16,216.44 L472.69,216.52 L473.21,216.60 L473.74,216.68 L474.26,216.76 L474.79,216.83 L475.32,216.91 L475.84,216.98 L476.37,217.05 L476.89,217.12 L477.42,217.19 L477.95,217.26 L478.47,217.32 L479.00,217.39 L479.52,217.45 L480.05,217.51 L480.58,217.57 L481.10,217.63 L481.63,217.69 L482.15,217.74 L482.68,217.80 L483.21,217.85 L483.73,217.91 L484.26,217.96 L484.78,218.01 L485.31,218.06 L485.84,218.10 L486.36,218.15 L486.89,218.20 L487.41,218.24 L487.94,218.29 L488.47,218.33 L488.99,218.37 L489.52,218.41 L490.04,218.45 L490.57,218.49 L491.10,218.53 L491.62,218.57 L492.15,218.61 L492.67,218.64 L493.20,218.68 L493.72,218.71 L494.25,218.75 L494.78,218.78 L495.30,218.81 L495.83,218.84 L496.35,218.87 L496.88,218.90 L497.41,218.93 L497.93,218.96 L498.46,218.99 L498.98,219.01 L499.51,219.04 L500.04,219.06 L500.56,219.09 L501.09,219.11 L501.61,219.14 L502.14,219.16 L502.67,219.18 L503.19,219.21 L503.72,219.23 L504.24,219.25 L504.77,219.27 L505.30,219.29 L505.82,219.31 L506.35,219.33 L506.87,219.35 L507.40,219.36 L507.93,219.38 L508.45,219.40 L508.98,219.42 L509.50,219.43 L510.03,219.45 L510.55,219.46 L511.08,219.48 L511.61,219.49 L512.13,219.51 L512.66,219.52 L513.18,219.54 L513.71,219.55 L514.24,219.56 L514.76,219.57 L515.29,219.59 L515.81,219.60 L516.34,219.61 L516.87,219.62 L517.39,219.63 L517.92,219.64 L518.44,219.65 L518.97,219.66 L519.50,219.67 L520.02,219.68 L520.55,219.69 L521.07,219.70 L521.60,219.71 L522.13,219.72 L522.65,219.73 L523.18,219.74 L523.70,219.74 L524.23,219.75 L524.76,219.76 L525.28,219.77 L525.81,219.77 L526.33,219.78 L526.86,219.79 L527.38,219.79 L527.91,219.80 L528.44,219.81 L528.96,219.81 L529.49,219.82 L530.01,219.82 L530.54,219.83 L531.07,219.83 L531.59,219.84 L532.12,219.84 L532.64,219.85 L533.17,219.85 L533.70,219.86 L534.22,219.86 L534.75,219.87 L535.27,219.87 L535.80,219.87 L536.33,219.88 L536.85,219.88 L537.38,219.89 L537.90,219.89 L538.43,219.89 L538.96,219.90 L539.48,219.90 L540.01,219.90 L540.53,219.91 L541.06,219.91 L541.59,219.91 L542.11,219.92 L542.64,219.92 L543.16,219.92 L543.69,219.92 L544.21,219.93 L544.74,219.93 L545.27,219.93 L545.79,219.93 L546.32,219.94 L546.84,219.94 L547.37,219.94 L547.90,219.94 L548.42,219.94 L548.95,219.95 L549.47,219.95 L550.00,219.95 L550.00,220.00 Z"/>
<path class="fig-curve" d="M55.00,219.95 L57.06,219.94 L59.13,219.93 L61.19,219.92 L63.25,219.91 L65.31,219.90 L67.38,219.89 L69.44,219.87 L71.50,219.86 L73.56,219.84 L75.63,219.82 L77.69,219.79 L79.75,219.77 L81.81,219.74 L83.88,219.70 L85.94,219.67 L88.00,219.62 L90.06,219.58 L92.12,219.53 L94.19,219.47 L96.25,219.41 L98.31,219.34 L100.38,219.26 L102.44,219.18 L104.50,219.09 L106.56,218.98 L108.62,218.87 L110.69,218.75 L112.75,218.61 L114.81,218.47 L116.88,218.30 L118.94,218.13 L121.00,217.93 L123.06,217.72 L125.12,217.49 L127.19,217.24 L129.25,216.97 L131.31,216.67 L133.38,216.35 L135.44,216.01 L137.50,215.64 L139.56,215.23 L141.62,214.80 L143.69,214.33 L145.75,213.83 L147.81,213.29 L149.88,212.71 L151.94,212.09 L154.00,211.42 L156.06,210.71 L158.12,209.96 L160.19,209.15 L162.25,208.29 L164.31,207.38 L166.38,206.41 L168.44,205.39 L170.50,204.30 L172.56,203.16 L174.62,201.94 L176.69,200.67 L178.75,199.32 L180.81,197.91 L182.88,196.43 L184.94,194.87 L187.00,193.24 L189.06,191.54 L191.12,189.77 L193.19,187.91 L195.25,185.99 L197.31,183.98 L199.38,181.90 L201.44,179.75 L203.50,177.52 L205.56,175.22 L207.62,172.85 L209.69,170.40 L211.75,167.89 L213.81,165.31 L215.88,162.66 L217.94,159.95 L220.00,157.19 L222.06,154.37 L224.12,151.50 L226.19,148.59 L228.25,145.64 L230.31,142.64 L232.38,139.62 L234.44,136.57 L236.50,133.50 L238.56,130.42 L240.62,127.34 L242.69,124.25 L244.75,121.17 L246.81,118.10 L248.88,115.06 L250.94,112.04 L253.00,109.06 L255.06,106.13 L257.12,103.24 L259.19,100.42 L261.25,97.67 L263.31,94.99 L265.38,92.39 L267.44,89.88 L269.50,87.48 L271.56,85.17 L273.62,82.98 L275.69,80.91 L277.75,78.97 L279.81,77.15 L281.88,75.48 L283.94,73.94 L286.00,72.56 L288.06,71.33 L290.12,70.25 L292.19,69.33 L294.25,68.57 L296.31,67.98 L298.38,67.56 L300.44,67.31 L302.50,67.22 L304.56,67.31 L306.62,67.56 L308.69,67.98 L310.75,68.57 L312.81,69.33 L314.88,70.25 L316.94,71.33 L319.00,72.56 L321.06,73.94 L323.12,75.48 L325.19,77.15 L327.25,78.97 L329.31,80.91 L331.38,82.98 L333.44,85.17 L335.50,87.48 L337.56,89.88 L339.62,92.39 L341.69,94.99 L343.75,97.67 L345.81,100.42 L347.88,103.24 L349.94,106.13 L352.00,109.06 L354.06,112.04 L356.12,115.06 L358.19,118.10 L360.25,121.17 L362.31,124.25 L364.38,127.34 L366.44,130.42 L368.50,133.50 L370.56,136.57 L372.62,139.62 L374.69,142.64 L376.75,145.64 L378.81,148.59 L380.88,151.50 L382.94,154.37 L385.00,157.19 L387.06,159.95 L389.12,162.66 L391.19,165.31 L393.25,167.89 L395.31,170.40 L397.38,172.85 L399.44,175.22 L401.50,177.52 L403.56,179.75 L405.62,181.90 L407.69,183.98 L409.75,185.99 L411.81,187.91 L413.88,189.77 L415.94,191.54 L418.00,193.24 L420.06,194.87 L422.12,196.43 L424.19,197.91 L426.25,199.32 L428.31,200.67 L430.38,201.94 L432.44,203.16 L434.50,204.30 L436.56,205.39 L438.62,206.41 L440.69,207.38 L442.75,208.29 L444.81,209.15 L446.88,209.96 L448.94,210.71 L451.00,211.42 L453.06,212.09 L455.12,212.71 L457.19,213.29 L459.25,213.83 L461.31,214.33 L463.38,214.80 L465.44,215.23 L467.50,215.64 L469.56,216.01 L471.62,216.35 L473.69,216.67 L475.75,216.97 L477.81,217.24 L479.88,217.49 L481.94,217.72 L484.00,217.93 L486.06,218.13 L488.12,218.30 L490.19,218.47 L492.25,218.61 L494.31,218.75 L496.38,218.87 L498.44,218.98 L500.50,219.09 L502.56,219.18 L504.62,219.26 L506.69,219.34 L508.75,219.41 L510.81,219.47 L512.88,219.53 L514.94,219.58 L517.00,219.62 L519.06,219.67 L521.12,219.70 L523.19,219.74 L525.25,219.77 L527.31,219.79 L529.38,219.82 L531.44,219.84 L533.50,219.86 L535.56,219.87 L537.62,219.89 L539.69,219.90 L541.75,219.91 L543.81,219.92 L545.88,219.93 L547.94,219.94 L550.00,219.95"/>
<path class="fig-guide" d="M181.2,220 L181.2,45"/><text class="fig-label" x="181.2" y="239">−1.96</text>
<path class="fig-guide" d="M423.8,220 L423.8,45"/><text class="fig-label" x="423.8" y="239">1.96</text>
</svg>
<figcaption>For a two-sided 5% z-test, only the two outer 2.5% tails cause rejection; the central 95% is the nonrejection region.</figcaption>
</figure>

:::definition[Definition 9.1 — Statistical hypothesis and testing]
A **statistical hypothesis** is a statement about a population parameter. A **hypothesis test** is a decision-making procedure that compares evidence from a sample with a null hypothesis $H_0$. The competing statement is the alternative hypothesis $H_1$. Its direction determines whether the test is one-sided or two-sided.
:::

### Translate the words before touching the calculator

If the question asks whether the mean is **different from**, **has changed from**, or **is equal to or not** a target, it is a two-sided question: $H_0:\mu=\mu_0$ against $H_1:\mu\ne\mu_0$. Values too high **and** too low can contradict the target. If the question asks whether the mean **exceeds**, **has increased**, or **is greater than** the target, use $H_1:\mu>\mu_0$. Only a sample mean substantially above the proposed value supports it. If the question asks whether the mean **is below**, **has decreased**, or **is less than** the target, use $H_1:\mu<\mu_0$. Only unusually low results support it.

These are statements about the unknown population mean $\mu$, not the observed sample mean $\bar{x}$. The observed $\bar{x}$ changes from one random sample to the next; the hypothesis is about the fixed parameter that produced the samples. The null uses equality because the named value provides a definite distribution for calculating a probability. In engineering language it is often helpful to think of a boundary null such as $\mu\le\mu_0$ for an exceedance claim, but the calculation is performed at the boundary $\mu=\mu_0$, as printed on the instructor's sheet.

For variance, replace $\mu$ with $\sigma^2$. A statement about **spread**, **variability**, or **fill consistency** normally concerns variance rather than average fill. The distinction matters because a sample mean and a sample variance lead to different test statistics and different tables.

:::theorem[Decision-direction rule]
For $H_1:\mu\ne\mu_0$, extreme results in **either** direction lead toward rejection. For $H_1:\mu>\mu_0$, only the **right** tail is relevant. For $H_1:\mu<\mu_0$, only the **left** tail is relevant. Do not decide which alternative to use after looking at the sample's sign.
:::

### The instructor's eight steps

The **Hypothesis Test Procedure** is printed on **Final sheet page 2**, immediately to the left of the rejection-criteria boxes. Follow it in this order, including on exam items that only ask for the decision.

1. **Identify the parameter of interest.** Is the question about $\mu$ or $\sigma^2$? Give the actual units or meaning, such as true mean burning rate or true variance in fill volume.
2. **State the null hypothesis, $H_0$.** Put the hypothesized value in an equality statement, such as $H_0:\mu=50$.
3. **State the alternative hypothesis, $H_1$.** Translate *greater*, *less*, or *different* literally and choose one or two tails.
4. **Choose a significance level $\alpha$.** This is the probability of rejecting a true null under the test design. Use the specified value, commonly $0.05$, rather than picking your own afterward.
5. **Determine an appropriate test statistic.** Known $\sigma$ for a population mean calls for $z$; unknown $\sigma$ with a normal population calls for $t$; a normal-population variance calls for chi-square.
6. **State the rejection region.** Use the table and the alternative direction to say which computed values trigger rejection, or use the p-value approach as allowed in the notes. The Final sheet itself phrases this step as stating the rejection region.
7. **Compute the test statistic.** Substitute the sample measurements and the null value. Keep the sign for $z$ and $t$; chi-square is nonnegative.
8. **Decide whether to reject $H_0$.** Make a comparison to the critical boundary or compare the p-value with $\alpha$. State the conclusion about the original engineering claim.

A test is not fully explained by saying only "significant." You must say **what population parameter** appears to have changed, in **which direction** if the alternative is one-sided, and at **what significance level**. The two permissible decisions are "reject $H_0$" and "fail to reject $H_0$." The instructor's vocabulary deliberately does not include "accept $H_0$" as a proof of correctness.

:::callout-pitfall[What goes wrong before calculation]
Students put $\bar{x}$ in a hypothesis, switch to a one-sided alternative because the sample happened to be above the target, split $\alpha$ into two tails for a one-sided claim, or write "accept $H_0$" after a nonsignificant result. Each mistake changes the meaning of the test, even if the arithmetic afterward is perfect.
:::

### Recognize tests in a sentence

"Does the process still maintain the advertised mean?" suggests a two-sided test unless a directional failure is specified. "Can the manufacturer show the mean exceeds the minimum?" suggests a right-tailed test. "Do the objects weigh less than promised?" suggests a left-tailed test. "Is the process variance unacceptably large?" suggests a right-tailed chi-square test. The test statistic is *not* chosen from the direction alone; direction tells you which tail, while the parameter and knowledge of $\sigma$ determine which distribution to use.

A decision made with $\alpha=0.05$ means the rejection rule has at most a 5% false-rejection rate under the null boundary and model assumptions. It does not mean the observed data have a 5% chance of being wrong, nor that the engineer is 95% certain the alternative is true. Those are different, unsupported probability statements.

:::example[Example 9.1 — A part longer than 42 cm]
A quality engineer is interested in knowing if the **average length of a part is greater than 42 cm**. Is the test one-sided or two-sided? State the hypotheses and explain the possible decisions. This is the conceptual question from the Unit 9 notes.

::::answer[Answer]
**Answer:** Right-tailed; reject only for a sufficiently high sample mean.

1. The parameter is the population mean length $\mu$, not the length of one part. The claim is "greater than," so set $H_0:\mu=42$ cm and $H_1:\mu>42$ cm.
2. This is **one-sided to the right**, because unusually long sample averages support the alternative; unusually short ones do not.
3. Reject when a standardized sample mean lies in the prescribed upper rejection region.
4. Otherwise fail to reject; neither outcome proves the exact true mean.

In context: In the part-length question, $42$ cm is the proposed population mean. A convincingly high sample mean supports the engineer’s claim; an ordinary or low value does not.
::::
:::

:::example[Example 9.2 — Detecting any change in fill weight]
A bottling process is specified to have a mean fill of 16 ounces. The production manager asks whether its mean fill has changed in either direction. State $H_0$ and $H_1$ and describe where evidence against the null must occur.

::::answer[Answer]
**Answer:** Two-sided; compare both high and low averages.

1. We care about the true population average fill, so the parameter is $\mu$.
2. The specified benchmark is $H_0:\mu=16$ ounces. The question says "has changed in either direction," giving $H_1:\mu\ne16$ ounces.
3. Evidence against the null can appear in either tail of the sampling distribution.
4. Split the chosen significance level between tails. A failure to reject means the sample does not show a statistically convincing change, not that the machine is exactly calibrated.

In context: For the bottling machine, either consistently overfilled or underfilled bottles could produce evidence against a population mean of 16 ounces.
::::
:::

:::problem[Problem 9.1 — A tensile-strength minimum]{difficulty=easy}
A weld designer wants evidence that mean strength exceeds a required minimum of 70 units. State the hypotheses and rejection direction.

::::solution[Solution]
**Answer:** Right-tailed mean test.

1. Define $\mu$ as the true average strength of the welds.
2. The boundary null is $H_0:\mu=70$, and the desired evidence is $H_1:\mu>70$.
3. Choose an upper-tail rejection region before looking at the data, because the designer needs proof of a strength increase.
4. A very low sample average would not support an increase, so it must not trigger rejection in this specific directional test.
::::
:::

:::problem[Problem 9.2 — A faulty short part]{difficulty=easy}
A machinist is concerned that mean part length is less than the 12-cm target. State the parameter, hypotheses and tail.

::::solution[Solution]
**Answer:** Left-tailed mean test.

1. Use the population mean part length $\mu$ as the target, not a single measured diameter or the sample mean.
2. The null is $H_0:\mu=12$ cm and the concern is $H_1:\mu<12$ cm.
3. Put the entire chosen $\alpha$ in the lower rejection tail.
4. A sample average substantially **above** the target would not be evidence that the process makes parts too short; reversing the tail after viewing data is invalid.
::::
:::

:::problem[Problem 9.3 — Two-sided calibration]{difficulty=standard}
A sensor is supposed to read 5 volts on average. Its engineer asks if calibration has shifted above or below that value. State the hypotheses and tail.

::::solution[Solution]
**Answer:** Two-sided mean test.

1. The parameter is the true average voltage $\mu$.
2. A calibration shift can be positive or negative, so use $H_0:\mu=5$ V and $H_1:\mu\ne5$ V.
3. There are two rejection tails, one for readings much lower and one for readings much higher than 5 V.
4. At significance $\alpha$, each tail receives $\alpha/2$. The choice does not depend on which way the sample happens to deviate.
::::
:::

:::problem[Problem 9.4 — Claim about variability]{difficulty=standard}
A filling process must maintain population variance of at most 0.01 squared ounces. A quality inspector wants evidence that variability is higher. State the null-boundary test and direction.

::::solution[Solution]
**Answer:** Right-tailed variance test.

1. The concern is *scatter in fill*, so the parameter is $\sigma^2$, not $\mu$.
2. Use the boundary null $H_0:\sigma^2=0.01$ squared ounces and alternative $H_1:\sigma^2>0.01$.
3. Assuming the population of fill measurements is normal, the statistic will be chi-square with a right-tailed rejection region.
4. A large sample variance makes the statistic larger, which is the direction associated with an unacceptable amount of spread.
::::
:::

:::problem[Problem 9.5 — A nonsignificant result]{difficulty=standard}
A two-sided test at the 5% level does not reject the null claim of a 40-cm average. Explain what can and cannot be concluded.

::::solution[Solution]
**Answer:** Fail to reject; exact equality is not established.

1. The stated hypothesis test compared the population mean to 40 cm and did **not** produce enough evidence for rejection at the 5% significance level.
2. State "fail to reject $H_0$" rather than "accept $H_0$."
3. This means the sample has not shown a statistically significant departure from 40 cm using the chosen test.
4. It does not prove the mean equals 40, and it does not guarantee the production process is free from practical problems.
::::
:::

:::problem[Problem 9.6 — The tempting wrong direction]{difficulty=challenge}
A company planned to test whether its mean output is below 120 units. The observed sample mean happens to be 127. Should the engineer change the test to right-tailed? Give the proper inference workflow.

::::solution[Solution]
**Answer:** Keep the left-tailed alternative.

1. The question was chosen in advance: test $H_0:\mu=120$ against $H_1:\mu<120$.
2. The observed sample mean 127 points **away** from the left-tailed alternative.
3. A high observed mean is not permission to change the tail to pursue significance.
4. Calculate the originally chosen lower-tail p-value or compare to the original left-tail rejection region.
5. Unless there is other information changing the planned study, this sample will not support the claim that the mean is below 120.
::::
:::

## 9.2 Known-variance z-tests and exact normal-table p-values


If the sample mean is being compared with a target and the problem explicitly gives the **population** standard deviation $\sigma$, the natural statistic is $z_0$. It answers: how many standard errors above or below the target is the observed sample mean? One standard error is a typical amount of sampling fluctuation; three standard errors are much harder to explain as mere sampling noise when the null is true. You do not need a new distribution: the mean's standard error comes from Chapter 7, and the final sheet standardizes it for you.

:::callout-intuition[Distance measured in standard errors]
A 1-cm disagreement can be enormous if the average over 100 parts barely fluctuates, and unremarkable if the individual parts vary wildly and you measured only two. Dividing by $\sigma/\sqrt n$ puts both situations on the same scale. Under the null model, values near zero are ordinary. Values deep in a tail are evidence against the null.
:::

:::definition[Definition 9.2 — One-sample z statistic]
For a normal population with known $\sigma$, or a setting in which the normal approximation for $\bar X$ is justified, test $H_0:\mu=\mu_0$ using

$$
Z_0=\frac{\bar X-\mu_0}{\sigma/\sqrt n}.
$$

The formula is on **Final sheet pages 1 and 2**. A two-sided test rejects when $z_0>z_{\alpha/2}$ or $z_0<-z_{\alpha/2}$; an upper-tailed test rejects when $z_0>z_\alpha$; a lower-tailed test rejects when $z_0<-z_\alpha$. The entire rejection-criteria table is on **page 2**.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Normal curve with upper rejection area">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M404.59,220.00 L404.59,180.84 L405.20,181.47 L405.81,182.09 L406.41,182.71 L407.02,183.32 L407.62,183.92 L408.23,184.52 L408.83,185.11 L409.44,185.69 L410.05,186.27 L410.65,186.84 L411.26,187.40 L411.86,187.96 L412.47,188.51 L413.08,189.06 L413.68,189.60 L414.29,190.13 L414.89,190.65 L415.50,191.17 L416.11,191.68 L416.71,192.19 L417.32,192.69 L417.92,193.18 L418.53,193.67 L419.13,194.15 L419.74,194.62 L420.35,195.09 L420.95,195.55 L421.56,196.01 L422.16,196.46 L422.77,196.90 L423.38,197.33 L423.98,197.77 L424.59,198.19 L425.19,198.61 L425.80,199.02 L426.40,199.43 L427.01,199.83 L427.62,200.22 L428.22,200.61 L428.83,200.99 L429.43,201.37 L430.04,201.74 L430.65,202.11 L431.25,202.47 L431.86,202.82 L432.46,203.17 L433.07,203.51 L433.68,203.85 L434.28,204.18 L434.89,204.51 L435.49,204.83 L436.10,205.15 L436.70,205.46 L437.31,205.77 L437.92,206.07 L438.52,206.36 L439.13,206.66 L439.73,206.94 L440.34,207.22 L440.95,207.50 L441.55,207.77 L442.16,208.04 L442.76,208.30 L443.37,208.56 L443.97,208.81 L444.58,209.06 L445.19,209.30 L445.79,209.54 L446.40,209.78 L447.00,210.01 L447.61,210.23 L448.22,210.46 L448.82,210.67 L449.43,210.89 L450.03,211.10 L450.64,211.30 L451.24,211.51 L451.85,211.70 L452.46,211.90 L453.06,212.09 L453.67,212.27 L454.27,212.46 L454.88,212.64 L455.49,212.81 L456.09,212.98 L456.70,213.15 L457.30,213.32 L457.91,213.48 L458.52,213.64 L459.12,213.79 L459.73,213.95 L460.33,214.10 L460.94,214.24 L461.54,214.38 L462.15,214.52 L462.76,214.66 L463.36,214.80 L463.97,214.93 L464.57,215.05 L465.18,215.18 L465.79,215.30 L466.39,215.42 L467.00,215.54 L467.60,215.66 L468.21,215.77 L468.81,215.88 L469.42,215.98 L470.03,216.09 L470.63,216.19 L471.24,216.29 L471.84,216.39 L472.45,216.49 L473.06,216.58 L473.66,216.67 L474.27,216.76 L474.87,216.85 L475.48,216.93 L476.09,217.01 L476.69,217.10 L477.30,217.17 L477.90,217.25 L478.51,217.33 L479.11,217.40 L479.72,217.47 L480.33,217.54 L480.93,217.61 L481.54,217.68 L482.14,217.74 L482.75,217.81 L483.36,217.87 L483.96,217.93 L484.57,217.99 L485.17,218.04 L485.78,218.10 L486.38,218.15 L486.99,218.21 L487.60,218.26 L488.20,218.31 L488.81,218.36 L489.41,218.41 L490.02,218.45 L490.63,218.50 L491.23,218.54 L491.84,218.58 L492.44,218.63 L493.05,218.67 L493.66,218.71 L494.26,218.75 L494.87,218.78 L495.47,218.82 L496.08,218.86 L496.68,218.89 L497.29,218.92 L497.90,218.96 L498.50,218.99 L499.11,219.02 L499.71,219.05 L500.32,219.08 L500.93,219.11 L501.53,219.13 L502.14,219.16 L502.74,219.19 L503.35,219.21 L503.95,219.24 L504.56,219.26 L505.17,219.28 L505.77,219.31 L506.38,219.33 L506.98,219.35 L507.59,219.37 L508.20,219.39 L508.80,219.41 L509.41,219.43 L510.01,219.45 L510.62,219.47 L511.22,219.48 L511.83,219.50 L512.44,219.52 L513.04,219.53 L513.65,219.55 L514.25,219.56 L514.86,219.58 L515.47,219.59 L516.07,219.60 L516.68,219.62 L517.28,219.63 L517.89,219.64 L518.50,219.65 L519.10,219.67 L519.71,219.68 L520.31,219.69 L520.92,219.70 L521.52,219.71 L522.13,219.72 L522.74,219.73 L523.34,219.74 L523.95,219.75 L524.55,219.76 L525.16,219.76 L525.77,219.77 L526.37,219.78 L526.98,219.79 L527.58,219.80 L528.19,219.80 L528.79,219.81 L529.40,219.82 L530.01,219.82 L530.61,219.83 L531.22,219.84 L531.82,219.84 L532.43,219.85 L533.04,219.85 L533.64,219.86 L534.25,219.86 L534.85,219.87 L535.46,219.87 L536.07,219.88 L536.67,219.88 L537.28,219.89 L537.88,219.89 L538.49,219.89 L539.09,219.90 L539.70,219.90 L540.31,219.91 L540.91,219.91 L541.52,219.91 L542.12,219.92 L542.73,219.92 L543.34,219.92 L543.94,219.92 L544.55,219.93 L545.15,219.93 L545.76,219.93 L546.36,219.94 L546.97,219.94 L547.58,219.94 L548.18,219.94 L548.79,219.94 L549.39,219.95 L550.00,219.95 L550.00,220.00 Z"/>
<path class="fig-curve" d="M55.00,219.95 L57.06,219.94 L59.13,219.93 L61.19,219.92 L63.25,219.91 L65.31,219.90 L67.38,219.89 L69.44,219.87 L71.50,219.86 L73.56,219.84 L75.63,219.82 L77.69,219.79 L79.75,219.77 L81.81,219.74 L83.88,219.70 L85.94,219.67 L88.00,219.62 L90.06,219.58 L92.12,219.53 L94.19,219.47 L96.25,219.41 L98.31,219.34 L100.38,219.26 L102.44,219.18 L104.50,219.09 L106.56,218.98 L108.62,218.87 L110.69,218.75 L112.75,218.61 L114.81,218.47 L116.88,218.30 L118.94,218.13 L121.00,217.93 L123.06,217.72 L125.12,217.49 L127.19,217.24 L129.25,216.97 L131.31,216.67 L133.38,216.35 L135.44,216.01 L137.50,215.64 L139.56,215.23 L141.62,214.80 L143.69,214.33 L145.75,213.83 L147.81,213.29 L149.88,212.71 L151.94,212.09 L154.00,211.42 L156.06,210.71 L158.12,209.96 L160.19,209.15 L162.25,208.29 L164.31,207.38 L166.38,206.41 L168.44,205.39 L170.50,204.30 L172.56,203.16 L174.62,201.94 L176.69,200.67 L178.75,199.32 L180.81,197.91 L182.88,196.43 L184.94,194.87 L187.00,193.24 L189.06,191.54 L191.12,189.77 L193.19,187.91 L195.25,185.99 L197.31,183.98 L199.38,181.90 L201.44,179.75 L203.50,177.52 L205.56,175.22 L207.62,172.85 L209.69,170.40 L211.75,167.89 L213.81,165.31 L215.88,162.66 L217.94,159.95 L220.00,157.19 L222.06,154.37 L224.12,151.50 L226.19,148.59 L228.25,145.64 L230.31,142.64 L232.38,139.62 L234.44,136.57 L236.50,133.50 L238.56,130.42 L240.62,127.34 L242.69,124.25 L244.75,121.17 L246.81,118.10 L248.88,115.06 L250.94,112.04 L253.00,109.06 L255.06,106.13 L257.12,103.24 L259.19,100.42 L261.25,97.67 L263.31,94.99 L265.38,92.39 L267.44,89.88 L269.50,87.48 L271.56,85.17 L273.62,82.98 L275.69,80.91 L277.75,78.97 L279.81,77.15 L281.88,75.48 L283.94,73.94 L286.00,72.56 L288.06,71.33 L290.12,70.25 L292.19,69.33 L294.25,68.57 L296.31,67.98 L298.38,67.56 L300.44,67.31 L302.50,67.22 L304.56,67.31 L306.62,67.56 L308.69,67.98 L310.75,68.57 L312.81,69.33 L314.88,70.25 L316.94,71.33 L319.00,72.56 L321.06,73.94 L323.12,75.48 L325.19,77.15 L327.25,78.97 L329.31,80.91 L331.38,82.98 L333.44,85.17 L335.50,87.48 L337.56,89.88 L339.62,92.39 L341.69,94.99 L343.75,97.67 L345.81,100.42 L347.88,103.24 L349.94,106.13 L352.00,109.06 L354.06,112.04 L356.12,115.06 L358.19,118.10 L360.25,121.17 L362.31,124.25 L364.38,127.34 L366.44,130.42 L368.50,133.50 L370.56,136.57 L372.62,139.62 L374.69,142.64 L376.75,145.64 L378.81,148.59 L380.88,151.50 L382.94,154.37 L385.00,157.19 L387.06,159.95 L389.12,162.66 L391.19,165.31 L393.25,167.89 L395.31,170.40 L397.38,172.85 L399.44,175.22 L401.50,177.52 L403.56,179.75 L405.62,181.90 L407.69,183.98 L409.75,185.99 L411.81,187.91 L413.88,189.77 L415.94,191.54 L418.00,193.24 L420.06,194.87 L422.12,196.43 L424.19,197.91 L426.25,199.32 L428.31,200.67 L430.38,201.94 L432.44,203.16 L434.50,204.30 L436.56,205.39 L438.62,206.41 L440.69,207.38 L442.75,208.29 L444.81,209.15 L446.88,209.96 L448.94,210.71 L451.00,211.42 L453.06,212.09 L455.12,212.71 L457.19,213.29 L459.25,213.83 L461.31,214.33 L463.38,214.80 L465.44,215.23 L467.50,215.64 L469.56,216.01 L471.62,216.35 L473.69,216.67 L475.75,216.97 L477.81,217.24 L479.88,217.49 L481.94,217.72 L484.00,217.93 L486.06,218.13 L488.12,218.30 L490.19,218.47 L492.25,218.61 L494.31,218.75 L496.38,218.87 L498.44,218.98 L500.50,219.09 L502.56,219.18 L504.62,219.26 L506.69,219.34 L508.75,219.41 L510.81,219.47 L512.88,219.53 L514.94,219.58 L517.00,219.62 L519.06,219.67 L521.12,219.70 L523.19,219.74 L525.25,219.77 L527.31,219.79 L529.38,219.82 L531.44,219.84 L533.50,219.86 L535.56,219.87 L537.62,219.89 L539.69,219.90 L541.75,219.91 L543.81,219.92 L545.88,219.93 L547.94,219.94 L550.00,219.95"/>
<path class="fig-guide" d="M404.6,220 L404.6,45"/><text class="fig-label" x="404.6" y="239">1.65</text>
</svg>
<figcaption>For an upper-tailed 5% z-test, put the entire rejection probability in the right tail beyond $z_{0.05}\approx1.65$.</figcaption>
</figure>

### Use the alternative to find the boundary

In a two-sided 5% test, 2.5% goes in each tail. Thus $z_{0.025}=1.96$, found by finding $\Phi(z)=0.975$ in the positive half of Table III on **Final sheet page 4**: row $1.9$, column $0.06$ gives $0.975002$. Reject if $z_0>1.96$ or $z_0<-1.96$. In an upper-tailed 5% test, use the 95th percentile instead: the normal table locates $1.64$ or $1.65$ around cumulative probability $0.95$; the Exam 3 sheet provides the convention $z_{0.05}=1.65$. For a lower-tailed test, negate the positive cutoff.

When the table is read to two decimal places, follow the instructor's rule: **round the computed $z_0$ to two decimals before looking up its cumulative probability.** A number in Table III is $\Phi(z)=P(Z\le z)$, the area to the **left**. For negative $z$, the negative-z page of the sheet has headings $-0.09,-0.08,\ldots,-0.00$ from left to right. Thus to read $\Phi(-1.23)$ you use row $-1.2$ and column $-0.03$, not row $-1.2$ and column $0.03$. By symmetry, $\Phi(-1.23)=1-\Phi(1.23)$. This fact is the fastest way to check that you picked the right page.

:::theorem[Normal z-test p-value formulas]
On **Final sheet page 2**, the printed rules are

$$
\begin{aligned}
H_1:\mu\ne\mu_0&\quad p=2[1-\Phi(|z_0|)],\\
H_1:\mu>\mu_0&\quad p=1-\Phi(z_0),\\
H_1:\mu<\mu_0&\quad p=\Phi(z_0).
\end{aligned}
$$

Reject $H_0$ if $p<\alpha$ (at exact equality, use the convention $p\le\alpha$ for rejection). The p-value is the smallest significance level at which this observed result would cause rejection by the given test.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Normal curve showing area left of minus two">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M55.00,220.00 L55.00,219.95 L55.52,219.95 L56.03,219.95 L56.55,219.94 L57.06,219.94 L57.58,219.94 L58.09,219.94 L58.61,219.94 L59.13,219.93 L59.64,219.93 L60.16,219.93 L60.67,219.93 L61.19,219.92 L61.70,219.92 L62.22,219.92 L62.73,219.92 L63.25,219.91 L63.77,219.91 L64.28,219.91 L64.80,219.90 L65.31,219.90 L65.83,219.90 L66.34,219.90 L66.86,219.89 L67.38,219.89 L67.89,219.88 L68.41,219.88 L68.92,219.88 L69.44,219.87 L69.95,219.87 L70.47,219.86 L70.98,219.86 L71.50,219.86 L72.02,219.85 L72.53,219.85 L73.05,219.84 L73.56,219.84 L74.08,219.83 L74.59,219.83 L75.11,219.82 L75.63,219.82 L76.14,219.81 L76.66,219.80 L77.17,219.80 L77.69,219.79 L78.20,219.79 L78.72,219.78 L79.23,219.77 L79.75,219.77 L80.27,219.76 L80.78,219.75 L81.30,219.74 L81.81,219.74 L82.33,219.73 L82.84,219.72 L83.36,219.71 L83.88,219.70 L84.39,219.69 L84.91,219.68 L85.42,219.68 L85.94,219.67 L86.45,219.66 L86.97,219.65 L87.48,219.64 L88.00,219.62 L88.52,219.61 L89.03,219.60 L89.55,219.59 L90.06,219.58 L90.58,219.57 L91.09,219.55 L91.61,219.54 L92.12,219.53 L92.64,219.51 L93.16,219.50 L93.67,219.49 L94.19,219.47 L94.70,219.46 L95.22,219.44 L95.73,219.43 L96.25,219.41 L96.77,219.39 L97.28,219.38 L97.80,219.36 L98.31,219.34 L98.83,219.32 L99.34,219.30 L99.86,219.28 L100.38,219.26 L100.89,219.24 L101.41,219.22 L101.92,219.20 L102.44,219.18 L102.95,219.16 L103.47,219.13 L103.98,219.11 L104.50,219.09 L105.02,219.06 L105.53,219.04 L106.05,219.01 L106.56,218.98 L107.08,218.96 L107.59,218.93 L108.11,218.90 L108.62,218.87 L109.14,218.84 L109.66,218.81 L110.17,218.78 L110.69,218.75 L111.20,218.72 L111.72,218.68 L112.23,218.65 L112.75,218.61 L113.27,218.58 L113.78,218.54 L114.30,218.50 L114.81,218.47 L115.33,218.43 L115.84,218.39 L116.36,218.34 L116.88,218.30 L117.39,218.26 L117.91,218.22 L118.42,218.17 L118.94,218.13 L119.45,218.08 L119.97,218.03 L120.48,217.98 L121.00,217.93 L121.52,217.88 L122.03,217.83 L122.55,217.77 L123.06,217.72 L123.58,217.66 L124.09,217.61 L124.61,217.55 L125.12,217.49 L125.64,217.43 L126.16,217.37 L126.67,217.30 L127.19,217.24 L127.70,217.17 L128.22,217.11 L128.73,217.04 L129.25,216.97 L129.77,216.90 L130.28,216.82 L130.80,216.75 L131.31,216.67 L131.83,216.60 L132.34,216.52 L132.86,216.44 L133.38,216.35 L133.89,216.27 L134.41,216.19 L134.92,216.10 L135.44,216.01 L135.95,215.92 L136.47,215.83 L136.98,215.73 L137.50,215.64 L138.02,215.54 L138.53,215.44 L139.05,215.34 L139.56,215.23 L140.08,215.13 L140.59,215.02 L141.11,214.91 L141.62,214.80 L142.14,214.68 L142.66,214.57 L143.17,214.45 L143.69,214.33 L144.20,214.21 L144.72,214.08 L145.23,213.96 L145.75,213.83 L146.27,213.70 L146.78,213.56 L147.30,213.43 L147.81,213.29 L148.33,213.15 L148.84,213.00 L149.36,212.86 L149.88,212.71 L150.39,212.56 L150.91,212.40 L151.42,212.25 L151.94,212.09 L152.45,211.93 L152.97,211.76 L153.48,211.59 L154.00,211.42 L154.52,211.25 L155.03,211.08 L155.55,210.90 L156.06,210.71 L156.58,210.53 L157.09,210.34 L157.61,210.15 L158.12,209.96 L158.64,209.76 L159.16,209.56 L159.67,209.36 L160.19,209.15 L160.70,208.94 L161.22,208.73 L161.73,208.51 L162.25,208.29 L162.77,208.07 L163.28,207.85 L163.80,207.62 L164.31,207.38 L164.83,207.15 L165.34,206.91 L165.86,206.66 L166.38,206.41 L166.89,206.16 L167.41,205.91 L167.92,205.65 L168.44,205.39 L168.95,205.12 L169.47,204.85 L169.98,204.58 L170.50,204.30 L171.02,204.02 L171.53,203.74 L172.05,203.45 L172.56,203.16 L173.08,202.86 L173.59,202.56 L174.11,202.25 L174.62,201.94 L175.14,201.63 L175.66,201.31 L176.17,200.99 L176.69,200.67 L177.20,200.34 L177.72,200.00 L178.23,199.67 L178.75,199.32 L178.75,220.00 Z"/>
<path class="fig-curve" d="M55.00,219.95 L57.06,219.94 L59.13,219.93 L61.19,219.92 L63.25,219.91 L65.31,219.90 L67.38,219.89 L69.44,219.87 L71.50,219.86 L73.56,219.84 L75.63,219.82 L77.69,219.79 L79.75,219.77 L81.81,219.74 L83.88,219.70 L85.94,219.67 L88.00,219.62 L90.06,219.58 L92.12,219.53 L94.19,219.47 L96.25,219.41 L98.31,219.34 L100.38,219.26 L102.44,219.18 L104.50,219.09 L106.56,218.98 L108.62,218.87 L110.69,218.75 L112.75,218.61 L114.81,218.47 L116.88,218.30 L118.94,218.13 L121.00,217.93 L123.06,217.72 L125.12,217.49 L127.19,217.24 L129.25,216.97 L131.31,216.67 L133.38,216.35 L135.44,216.01 L137.50,215.64 L139.56,215.23 L141.62,214.80 L143.69,214.33 L145.75,213.83 L147.81,213.29 L149.88,212.71 L151.94,212.09 L154.00,211.42 L156.06,210.71 L158.12,209.96 L160.19,209.15 L162.25,208.29 L164.31,207.38 L166.38,206.41 L168.44,205.39 L170.50,204.30 L172.56,203.16 L174.62,201.94 L176.69,200.67 L178.75,199.32 L180.81,197.91 L182.88,196.43 L184.94,194.87 L187.00,193.24 L189.06,191.54 L191.12,189.77 L193.19,187.91 L195.25,185.99 L197.31,183.98 L199.38,181.90 L201.44,179.75 L203.50,177.52 L205.56,175.22 L207.62,172.85 L209.69,170.40 L211.75,167.89 L213.81,165.31 L215.88,162.66 L217.94,159.95 L220.00,157.19 L222.06,154.37 L224.12,151.50 L226.19,148.59 L228.25,145.64 L230.31,142.64 L232.38,139.62 L234.44,136.57 L236.50,133.50 L238.56,130.42 L240.62,127.34 L242.69,124.25 L244.75,121.17 L246.81,118.10 L248.88,115.06 L250.94,112.04 L253.00,109.06 L255.06,106.13 L257.12,103.24 L259.19,100.42 L261.25,97.67 L263.31,94.99 L265.38,92.39 L267.44,89.88 L269.50,87.48 L271.56,85.17 L273.62,82.98 L275.69,80.91 L277.75,78.97 L279.81,77.15 L281.88,75.48 L283.94,73.94 L286.00,72.56 L288.06,71.33 L290.12,70.25 L292.19,69.33 L294.25,68.57 L296.31,67.98 L298.38,67.56 L300.44,67.31 L302.50,67.22 L304.56,67.31 L306.62,67.56 L308.69,67.98 L310.75,68.57 L312.81,69.33 L314.88,70.25 L316.94,71.33 L319.00,72.56 L321.06,73.94 L323.12,75.48 L325.19,77.15 L327.25,78.97 L329.31,80.91 L331.38,82.98 L333.44,85.17 L335.50,87.48 L337.56,89.88 L339.62,92.39 L341.69,94.99 L343.75,97.67 L345.81,100.42 L347.88,103.24 L349.94,106.13 L352.00,109.06 L354.06,112.04 L356.12,115.06 L358.19,118.10 L360.25,121.17 L362.31,124.25 L364.38,127.34 L366.44,130.42 L368.50,133.50 L370.56,136.57 L372.62,139.62 L374.69,142.64 L376.75,145.64 L378.81,148.59 L380.88,151.50 L382.94,154.37 L385.00,157.19 L387.06,159.95 L389.12,162.66 L391.19,165.31 L393.25,167.89 L395.31,170.40 L397.38,172.85 L399.44,175.22 L401.50,177.52 L403.56,179.75 L405.62,181.90 L407.69,183.98 L409.75,185.99 L411.81,187.91 L413.88,189.77 L415.94,191.54 L418.00,193.24 L420.06,194.87 L422.12,196.43 L424.19,197.91 L426.25,199.32 L428.31,200.67 L430.38,201.94 L432.44,203.16 L434.50,204.30 L436.56,205.39 L438.62,206.41 L440.69,207.38 L442.75,208.29 L444.81,209.15 L446.88,209.96 L448.94,210.71 L451.00,211.42 L453.06,212.09 L455.12,212.71 L457.19,213.29 L459.25,213.83 L461.31,214.33 L463.38,214.80 L465.44,215.23 L467.50,215.64 L469.56,216.01 L471.62,216.35 L473.69,216.67 L475.75,216.97 L477.81,217.24 L479.88,217.49 L481.94,217.72 L484.00,217.93 L486.06,218.13 L488.12,218.30 L490.19,218.47 L492.25,218.61 L494.31,218.75 L496.38,218.87 L498.44,218.98 L500.50,219.09 L502.56,219.18 L504.62,219.26 L506.69,219.34 L508.75,219.41 L510.81,219.47 L512.88,219.53 L514.94,219.58 L517.00,219.62 L519.06,219.67 L521.12,219.70 L523.19,219.74 L525.25,219.77 L527.31,219.79 L529.38,219.82 L531.44,219.84 L533.50,219.86 L535.56,219.87 L537.62,219.89 L539.69,219.90 L541.75,219.91 L543.81,219.92 L545.88,219.93 L547.94,219.94 L550.00,219.95"/>
<path class="fig-guide" d="M178.8,220 L178.8,45"/><text class="fig-label" x="178.8" y="239">−2.00</text>
</svg>
<figcaption>For a lower-tailed z-test with $z_0=-2$, the p-value is the left cumulative area $\Phi(-2)$, not its complement.</figcaption>
</figure>

### What the p-value says, and what it cannot say

Suppose $p=0.03$. If the null were true, results at least as incompatible with it as the observed sample would occur about 3% of the time under the test model. Thus the result is significant at 5%, but not at 1%. It does **not** say there is a 3% probability the null is true. The null was fixed as the assumption used to define the sampling probabilities; we did not assign it a probability.

A one-sided p-value is a one-tail area. A two-sided p-value is the combined area from the two tails, regardless of which side produced the observed result. For $z_0=-2.10$, a lower-tailed alternative has p-value $\Phi(-2.10)$; the upper-tailed alternative has p-value $1-\Phi(-2.10)$ and therefore offers very little evidence for "greater than." Looking only at $|z_0|$ and forgetting the direction can invert a correct inference.

In a worked eight-step z-test, explicitly list the parameter, both hypotheses, $\alpha$, the statistic, the rejection region, the numerical statistic and the verbal decision. You may add the p-value, which the Unit 9 notes ask you to report even when you also use the rejection-region method.

:::callout-pitfall[Wrong standard deviation, wrong tail, wrong probability]
Do not substitute $s$ for a given population $\sigma$. Do not divide by $\sigma/n$; the standard error is $\sigma/\sqrt n$. Do not double a p-value for a one-sided alternative. And do not read a normal-table entry such as $0.9988$ as an upper-tail p-value when the table actually reports cumulative **left** area.
:::

:::example[Example 9.3 — Rocket propellant burning rate]
Unit 9 Exercise 1. Aircrew escape systems use solid propellant. Specifications require a **mean** burning rate of 50 centimeters per second, with population standard deviation 2. The experimenter selects 25 propellant specimens, observes a sample average burning rate of 51.3 centimeters per second, and chooses significance 0.05. Is there evidence of a different mean rate?

Numerical data: $\mu_0=50$, $\sigma=2$, $n=25$, $\bar{x}=51.3$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $3.25$; reject $H_0$

1. **Parameter:** the true mean propellant burning rate $\mu$, measured in centimeters per second.
2. **Null hypothesis:** $H_0:\mu=50$ cm/s, the specified design mean.
3. **Alternative hypothesis:** $H_1:\mu\ne50$ cm/s, because either a faster or a slower true burn would violate the stated mean.
4. **Significance:** $\alpha=0.05$, as given in the exercise.
5. **Test statistic:** $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ from Final sheet page 2; the population $\sigma=2$ is known.
6. **Rejection region:** $z_0<-1.96$ or $z_0>1.96$. Table III, Final sheet page 4, row $1.9$, column $0.06$, gives $\Phi(1.96)=0.975002$, leaving 0.025 in each tail.
7. **Calculation:** the standard error is $2/\sqrt{25}=0.4$ cm/s. Thus $z_0=(51.3-50)/0.4=3.25$.
8. **Decision:** because $3.25>1.96$, reject $H_0$. The sample is unusually high under a true 50-cm/s mean.

In context: The observed mean is 1.3 cm/s above specification and 3.25 standard errors above the null mean, so the propellant mean appears different from 50 cm/s at the 5% level.
::::
:::

:::example[Example 9.4 — Propellant two-sided p-value]
For the same rocket-propellant data, compute the p-value for the question whether the mean burning rate differs from the required rate.

Numerical data: $\mu_0=50$, $\sigma=2$, $n=25$, $\bar{x}=51.3$.

::::answer[Answer]
**Answer:** $0.0012$

1. The standardized test statistic is $z_0=(51.3-50)/(2/\sqrt{25})=3.250$. Round to $3.25$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $3.2$ and column $0.05$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(3.25)=0.999423$.
3. Final sheet page 2 says $p=2[1-\Phi(|z_0|)]$. Substitute the cumulative area to obtain $p\approx 0.0012$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.

In context: A p-value near 0.0012 means a sample this inconsistent with 50 cm/s would be very rare under the specification, supporting rejection.
::::
:::

:::example[Example 9.5 — Production weights out of tolerance]
Exam 3 practice Problem 11. In a quality-control situation, mean weight is supposed to be 16 ounces, with **population** standard deviation 0.4 ounces. A random sample of 70 objects yields an average weight of 15.8 ounces. Conduct a test of whether production standards are maintained and state the statistic.

Numerical data: $\mu_0=16$, $\sigma=0.4$, $n=70$, $\bar{x}=15.8$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $-4.18$; reject $H_0$

1. The population mean is the parameter. Write $H_0:\mu=16$ and $H_1:\mu\ne16$. The significance level is $\alpha=0.05$.
2. Because the population standard deviation is known, choose $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ from Final sheet page 2. The two-tailed critical cutoff is $1.96$ from Table III (row $1.9$, column $0.06$ for $1.96$; other levels use the corresponding cumulative-area row and column) nearest cumulative area $0.975$.
3. Calculate $z_0=(15.8-16)/(0.4/\sqrt{70})=-4.183$.
4. Compare $-4.183$ with the specified rejection region. We reject $H_0$. This is a conclusion about evidence for the engineering claim; failing to reject would not prove an exact mean.

In context: The sample mean of 15.8 ounces is sufficiently below 16 that the weight specification is contradicted at the 5% level, despite a raw difference of only 0.2 ounce.
::::
:::

:::example[Example 9.6 — Weight-process p-value]
For the same weight-control data from Exam 3 practice Problem 11, determine the two-sided p-value from the normal table.

Numerical data: $\mu_0=16$, $\sigma=0.4$, $n=70$, $\bar{x}=15.8$.

::::answer[Answer]
**Answer:** $p<0.0001$

1. The standardized statistic is $z_0=-4.183$, beyond the last normal-table row on Final sheet pages 3–4.
2. The edge of Table III is $\Phi(3.90)=0.999952$ (row 3.9, column 0.00), so for this two-sided test $p<2(1-0.999952)=0.000096<0.0001$.
3. Since the observed statistic is even farther into the rejection tail, the true p-value is smaller than this bound.
4. Reject $H_0$ at significance 0.05; the process mean differs from the specified value. An exact tiny p-value cannot be read from this sheet.

In context: The two-sided p-value is smaller than 0.0001 from the printed table, so the production weights show decisive statistical evidence of a changed mean.
::::
:::

:::example[Example 9.7 — Power supply test part d]
Unit 9 Exercise 3(d). Eight power supply outputs are normal with known standard deviation 0.25 volt. Test whether their population mean is 5 volts. If the sample mean is **5.1 volts**, find the two-sided p-value.

Numerical data: $\mu_0=5$, $\sigma=0.25$, $n=8$, $\bar{x}=5.1$.

::::answer[Answer]
**Answer:** $0.2585$

1. The standardized test statistic is $z_0=(5.1-5)/(0.25/\sqrt{8})=1.131$. Round to $1.13$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $1.1$ and column $0.03$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(1.13)=0.870762$.
3. Final sheet page 2 says $p=2[1-\Phi(|z_0|)]$. Substitute the cumulative area to obtain $p\approx 0.2585$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.

In context: A 5.1-volt sample mean gives p about 0.2585; by itself it does not reject the 5-volt benchmark at the conventional 5% significance level.
::::
:::

:::problem[Problem 9.7 — Check a right-tailed part dimension]{difficulty=easy}
A part should average 42 cm. The engineer wants evidence its mean exceeds 42, using known standard deviation 3, a random sample of 36, and sample mean 43.1. Calculate the z statistic.

Numerical data: $\mu_0=42$, $\sigma=3$, $n=36$, $\bar{x}=43.1$.

::::solution[Solution]
**Answer:** $2.200$

1. Treat the known population standard deviation as $\sigma=3$, not as a sample estimate.
2. On Final sheet page 1 (also the rejection box on page 2), use $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$.
3. Substitute $(43.1-42)/(3/\sqrt{36})=2.200$. The sign shows which side of the proposed mean the sample lies.
4. A statistic this many standard errors from the null mean is the standardized evidence; it is not a probability and is not itself $\alpha$.
::::
:::

:::problem[Problem 9.8 — A lower-tailed machine output]{difficulty=standard}
A machine promises a mean of 20 units, with known population standard deviation 4. For 64 measurements the mean is 19.1. Compute the left-tailed p-value.

Numerical data: $\mu_0=20$, $\sigma=4$, $n=64$, $\bar{x}=19.1$.

::::solution[Solution]
**Answer:** $0.0359$

1. The standardized test statistic is $z_0=(19.1-20)/(4/\sqrt{64})=-1.800$. Round to $-1.80$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $-1.8$ and column $-0.00$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(-1.80)=0.035930$.
3. Final sheet page 2 says $p=\Phi(z_0)$. Substitute the cumulative area to obtain $p\approx 0.0359$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.
::::
:::

:::problem[Problem 9.9 — Check a high mean voltage]{difficulty=standard}
A voltage regulator claims a mean 12.0 volts, with known sigma 0.6 volts. An engineer suspects the mean is greater than 12.0 after 25 units average 12.3. Test at significance 0.05.

Numerical data: $\mu_0=12$, $\sigma=0.6$, $n=25$, $\bar{x}=12.3$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $2.50$; reject $H_0$

1. The population mean is the parameter. Write $H_0:\mu=12$ and $H_1:\mu>12$. The significance level is $\alpha=0.05$.
2. Because the population standard deviation is known, choose $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ from Final sheet page 2. The upper-tailed critical cutoff is $1.65$ from Table III (row $1.9$, column $0.06$ for $1.96$; other levels use the corresponding cumulative-area row and column) nearest cumulative area $0.950$.
3. Calculate $z_0=(12.3-12)/(0.6/\sqrt{25})=2.500$.
4. Compare $2.500$ with the specified rejection region. We reject $H_0$. This is a conclusion about evidence for the engineering claim; failing to reject would not prove an exact mean.
::::
:::

:::problem[Problem 9.10 — Another 5% two-tail rule]{difficulty=easy}
A technician wants the positive z cutoff for a two-sided significance level of 0.05. Report the critical boundary magnitude.

Numerical data: $\alpha=0.05$.

::::solution[Solution]
**Answer:** $1.96$

1. The alternative chooses a two-tailed rejection region. At $\alpha=0.05$, allocate the error allowance equally, half to each tail.
2. Table III on Final sheet, pages 3–4, gives the standard-normal cumulative area. Find $\Phi(z)$ near $0.975$; the corresponding boundary is approximately $1.96$.
3. Reject beyond the boundary in the direction specified by $H_1$, not toward the middle of the bell curve.
4. Check: a smaller $\alpha$ calls for a boundary farther from zero, reducing false positives.
::::
:::

:::problem[Problem 9.11 — A 1% change in strength]{difficulty=standard}
The weld design target is 72 units. With population sigma 3, sample size 16 and observed mean 73.7, test for any departure at significance 0.01.

Numerical data: $\mu_0=72$, $\sigma=3$, $n=16$, $\bar{x}=73.7$, $\alpha=0.01$.

::::solution[Solution]
**Answer:** $2.27$; fail to reject $H_0$

1. The population mean is the parameter. Write $H_0:\mu=72$ and $H_1:\mu\ne72$. The significance level is $\alpha=0.01$.
2. Because the population standard deviation is known, choose $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ from Final sheet page 2. The two-tailed critical cutoff is $2.58$ from Table III (row $1.9$, column $0.06$ for $1.96$; other levels use the corresponding cumulative-area row and column) nearest cumulative area $0.995$.
3. Calculate $z_0=(73.7-72)/(3/\sqrt{16})=2.267$.
4. Compare $2.267$ with the specified rejection region. We fail to reject $H_0$. This is a conclusion about evidence for the engineering claim; failing to reject would not prove an exact mean.
::::
:::

:::problem[Problem 9.12 — Sign reversal in the wrong tail]{difficulty=challenge}
An engineer asserts the mean current is larger than 3.0 amps, known sigma 0.5, n=25, but observes average 2.7 amps. What is the p-value for that original upper-tailed claim?

Numerical data: $\mu_0=3$, $\sigma=0.5$, $n=25$, $\bar{x}=2.7$.

::::solution[Solution]
**Answer:** $0.9987$

1. The standardized test statistic is $z_0=(2.7-3)/(0.5/\sqrt{25})=-3.000$. Round to $-3.00$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $-3.0$ and column $-0.00$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(-3.00)=0.001350$.
3. Final sheet page 2 says $p=1-\Phi(z_0)$. Substitute the cumulative area to obtain $p\approx 0.9987$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.
::::
:::

## 9.3 Unknown-variance t-tests and table bounds


A sample variance is not a substitute for knowing the population variance. If the only estimate of variability is calculated from the same observations as the mean, the extra uncertainty changes the sampling distribution. The $t$ distribution makes room for that uncertainty, especially with small samples. It resembles a normal curve but has heavier tails. Its exact shape depends on the sample size through the degrees of freedom $n-1$.

:::callout-intuition[The denominator is now estimated]
In the z-test, the denominator $\sigma/\sqrt n$ is fixed by information given about the population. In a t-test, the denominator $s/\sqrt n$ comes from the data. That extra randomness makes a value such as $2.0$ less surprising than it would be under a standard normal distribution when the sample is small. With more observations, the estimate $s$ stabilizes and the t cutoffs approach the familiar z cutoffs.
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="t density with five degrees of freedom compared against standard normal">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-curve-alt" d="M55.00,220.00 L57.06,220.00 L59.12,220.00 L61.19,220.00 L63.25,220.00 L65.31,220.00 L67.38,220.00 L69.44,220.00 L71.50,220.00 L73.56,220.00 L75.63,220.00 L77.69,219.99 L79.75,219.99 L81.81,219.99 L83.87,219.99 L85.94,219.99 L88.00,219.99 L90.06,219.98 L92.12,219.98 L94.19,219.98 L96.25,219.97 L98.31,219.97 L100.38,219.96 L102.44,219.95 L104.50,219.95 L106.56,219.94 L108.62,219.93 L110.69,219.91 L112.75,219.90 L114.81,219.88 L116.88,219.86 L118.94,219.83 L121.00,219.81 L123.06,219.77 L125.13,219.74 L127.19,219.70 L129.25,219.65 L131.31,219.59 L133.38,219.53 L135.44,219.46 L137.50,219.38 L139.56,219.29 L141.62,219.18 L143.69,219.07 L145.75,218.93 L147.81,218.78 L149.88,218.62 L151.94,218.43 L154.00,218.22 L156.06,217.98 L158.12,217.72 L160.19,217.42 L162.25,217.10 L164.31,216.74 L166.38,216.34 L168.44,215.90 L170.50,215.41 L172.56,214.88 L174.62,214.29 L176.69,213.65 L178.75,212.95 L180.81,212.18 L182.88,211.34 L184.94,210.43 L187.00,209.45 L189.06,208.38 L191.12,207.23 L193.19,205.98 L195.25,204.64 L197.31,203.21 L199.37,201.67 L201.44,200.03 L203.50,198.27 L205.56,196.40 L207.62,194.42 L209.69,192.32 L211.75,190.09 L213.81,187.75 L215.88,185.28 L217.94,182.68 L220.00,179.96 L222.06,177.12 L224.12,174.16 L226.19,171.07 L228.25,167.87 L230.31,164.56 L232.38,161.14 L234.44,157.61 L236.50,153.99 L238.56,150.28 L240.62,146.49 L242.69,142.63 L244.75,138.70 L246.81,134.73 L248.88,130.71 L250.94,126.67 L253.00,122.62 L255.06,118.56 L257.12,114.52 L259.19,110.51 L261.25,106.54 L263.31,102.63 L265.38,98.80 L267.44,95.06 L269.50,91.43 L271.56,87.93 L273.62,84.56 L275.69,81.35 L277.75,78.31 L279.81,75.45 L281.88,72.79 L283.94,70.34 L286.00,68.12 L288.06,66.13 L290.12,64.38 L292.19,62.89 L294.25,61.65 L296.31,60.69 L298.38,60.00 L300.44,59.58 L302.50,59.44 L304.56,59.58 L306.62,60.00 L308.69,60.69 L310.75,61.65 L312.81,62.89 L314.88,64.38 L316.94,66.13 L319.00,68.12 L321.06,70.34 L323.13,72.79 L325.19,75.45 L327.25,78.31 L329.31,81.35 L331.38,84.56 L333.44,87.93 L335.50,91.43 L337.56,95.06 L339.62,98.80 L341.69,102.63 L343.75,106.54 L345.81,110.51 L347.88,114.52 L349.94,118.56 L352.00,122.62 L354.06,126.67 L356.12,130.71 L358.19,134.73 L360.25,138.70 L362.31,142.63 L364.38,146.49 L366.44,150.28 L368.50,153.99 L370.56,157.61 L372.62,161.14 L374.69,164.56 L376.75,167.87 L378.81,171.07 L380.88,174.16 L382.94,177.12 L385.00,179.96 L387.06,182.68 L389.12,185.28 L391.19,187.75 L393.25,190.09 L395.31,192.32 L397.38,194.42 L399.44,196.40 L401.50,198.27 L403.56,200.03 L405.62,201.67 L407.69,203.21 L409.75,204.64 L411.81,205.98 L413.88,207.23 L415.94,208.38 L418.00,209.45 L420.06,210.43 L422.12,211.34 L424.19,212.18 L426.25,212.95 L428.31,213.65 L430.38,214.29 L432.44,214.88 L434.50,215.41 L436.56,215.90 L438.62,216.34 L440.69,216.74 L442.75,217.10 L444.81,217.42 L446.88,217.72 L448.94,217.98 L451.00,218.22 L453.06,218.43 L455.12,218.62 L457.19,218.78 L459.25,218.93 L461.31,219.07 L463.38,219.18 L465.44,219.29 L467.50,219.38 L469.56,219.46 L471.62,219.53 L473.69,219.59 L475.75,219.65 L477.81,219.70 L479.88,219.74 L481.94,219.77 L484.00,219.81 L486.06,219.83 L488.12,219.86 L490.19,219.88 L492.25,219.90 L494.31,219.91 L496.37,219.93 L498.44,219.94 L500.50,219.95 L502.56,219.95 L504.63,219.96 L506.69,219.97 L508.75,219.97 L510.81,219.98 L512.88,219.98 L514.94,219.98 L517.00,219.99 L519.06,219.99 L521.12,219.99 L523.19,219.99 L525.25,219.99 L527.31,219.99 L529.38,220.00 L531.44,220.00 L533.50,220.00 L535.56,220.00 L537.62,220.00 L539.69,220.00 L541.75,220.00 L543.81,220.00 L545.88,220.00 L547.94,220.00 L550.00,220.00"/>
<path class="fig-curve" d="M55.00,219.29 L57.06,219.26 L59.12,219.23 L61.19,219.20 L63.25,219.16 L65.31,219.13 L67.38,219.09 L69.44,219.05 L71.50,219.01 L73.56,218.96 L75.63,218.91 L77.69,218.87 L79.75,218.81 L81.81,218.76 L83.87,218.70 L85.94,218.64 L88.00,218.58 L90.06,218.51 L92.12,218.44 L94.19,218.37 L96.25,218.29 L98.31,218.21 L100.38,218.12 L102.44,218.03 L104.50,217.94 L106.56,217.84 L108.62,217.73 L110.69,217.62 L112.75,217.50 L114.81,217.38 L116.88,217.24 L118.94,217.10 L121.00,216.96 L123.06,216.80 L125.13,216.64 L127.19,216.46 L129.25,216.28 L131.31,216.09 L133.38,215.88 L135.44,215.66 L137.50,215.43 L139.56,215.19 L141.62,214.93 L143.69,214.66 L145.75,214.37 L147.81,214.07 L149.88,213.74 L151.94,213.40 L154.00,213.04 L156.06,212.66 L158.12,212.25 L160.19,211.82 L162.25,211.36 L164.31,210.88 L166.38,210.37 L168.44,209.82 L170.50,209.25 L172.56,208.64 L174.62,208.00 L176.69,207.31 L178.75,206.59 L180.81,205.82 L182.88,205.01 L184.94,204.15 L187.00,203.24 L189.06,202.28 L191.12,201.26 L193.19,200.18 L195.25,199.04 L197.31,197.84 L199.37,196.56 L201.44,195.22 L203.50,193.80 L205.56,192.31 L207.62,190.73 L209.69,189.07 L211.75,187.33 L213.81,185.49 L215.88,183.56 L217.94,181.54 L220.00,179.41 L222.06,177.19 L224.12,174.86 L226.19,172.43 L228.25,169.89 L230.31,167.24 L232.38,164.49 L234.44,161.63 L236.50,158.67 L238.56,155.60 L240.62,152.43 L242.69,149.16 L244.75,145.81 L246.81,142.36 L248.88,138.84 L250.94,135.24 L253.00,131.59 L255.06,127.88 L257.12,124.13 L259.19,120.36 L261.25,116.58 L263.31,112.80 L265.38,109.04 L267.44,105.32 L269.50,101.67 L271.56,98.09 L273.62,94.61 L275.69,91.24 L277.75,88.02 L279.81,84.97 L281.88,82.09 L283.94,79.42 L286.00,76.97 L288.06,74.76 L290.12,72.81 L292.19,71.13 L294.25,69.74 L296.31,68.65 L298.38,67.86 L300.44,67.38 L302.50,67.22 L304.56,67.38 L306.62,67.86 L308.69,68.65 L310.75,69.74 L312.81,71.13 L314.88,72.81 L316.94,74.76 L319.00,76.97 L321.06,79.42 L323.13,82.09 L325.19,84.97 L327.25,88.02 L329.31,91.24 L331.38,94.61 L333.44,98.09 L335.50,101.67 L337.56,105.32 L339.62,109.04 L341.69,112.80 L343.75,116.58 L345.81,120.36 L347.88,124.13 L349.94,127.88 L352.00,131.59 L354.06,135.24 L356.12,138.84 L358.19,142.36 L360.25,145.81 L362.31,149.16 L364.38,152.43 L366.44,155.60 L368.50,158.67 L370.56,161.63 L372.62,164.49 L374.69,167.24 L376.75,169.89 L378.81,172.43 L380.88,174.86 L382.94,177.19 L385.00,179.41 L387.06,181.54 L389.12,183.56 L391.19,185.49 L393.25,187.33 L395.31,189.07 L397.38,190.73 L399.44,192.31 L401.50,193.80 L403.56,195.22 L405.62,196.56 L407.69,197.84 L409.75,199.04 L411.81,200.18 L413.88,201.26 L415.94,202.28 L418.00,203.24 L420.06,204.15 L422.12,205.01 L424.19,205.82 L426.25,206.59 L428.31,207.31 L430.38,208.00 L432.44,208.64 L434.50,209.25 L436.56,209.82 L438.62,210.37 L440.69,210.88 L442.75,211.36 L444.81,211.82 L446.88,212.25 L448.94,212.66 L451.00,213.04 L453.06,213.40 L455.12,213.74 L457.19,214.07 L459.25,214.37 L461.31,214.66 L463.38,214.93 L465.44,215.19 L467.50,215.43 L469.56,215.66 L471.62,215.88 L473.69,216.09 L475.75,216.28 L477.81,216.46 L479.88,216.64 L481.94,216.80 L484.00,216.96 L486.06,217.10 L488.12,217.24 L490.19,217.38 L492.25,217.50 L494.31,217.62 L496.37,217.73 L498.44,217.84 L500.50,217.94 L502.56,218.03 L504.63,218.12 L506.69,218.21 L508.75,218.29 L510.81,218.37 L512.88,218.44 L514.94,218.51 L517.00,218.58 L519.06,218.64 L521.12,218.70 L523.19,218.76 L525.25,218.81 L527.31,218.87 L529.38,218.91 L531.44,218.96 L533.50,219.01 L535.56,219.05 L537.62,219.09 L539.69,219.13 L541.75,219.16 L543.81,219.20 L545.88,219.23 L547.94,219.26 L550.00,219.29"/>
<path class="fig-guide" d="M302.5,220 L302.5,45"/><text class="fig-label" x="302.5" y="239">0</text>
</svg>
<figcaption>The $t$ density with 5 degrees of freedom has heavier tails than a standard normal density, so small-sample t cutoffs are farther from zero.</figcaption>
</figure>

:::definition[Definition 9.3 — One-sample t test]
When the population standard deviation is unknown and the sample comes from a normal population, use

$$
T_0=\frac{\bar X-\mu_0}{S/\sqrt n},\qquad \nu=n-1.
$$

The formula is on **Final sheet pages 1 and 2**. For a two-sided test, reject when $t_0>t_{\alpha/2,\,n-1}$ or $t_0<-t_{\alpha/2,\,n-1}$. The one-sided conditions use $t_{\alpha,\,n-1}$ with the appropriate positive or negative sign. All three are in the t rejection box on **page 2**.
:::

### Why you must know the correct degrees of freedom

For a sample of 15 golf clubs, the t distribution has 14 degrees of freedom, not 15. The reason is that the sample variance uses the deviations about the sample mean: once the mean is fixed, the last deviation is determined by the others. This is the same $n-1$ that appears in the formula for $s^2$ on Final sheet page 1. If the problem gives the **sample variance** $s^2$, take its square root before inserting it into the denominator. Dividing by $s^2/\sqrt n$ is dimensionally wrong and often changes a nonsignificant result into a false rejection.

Table V on **Final sheet page 5** has degrees of freedom in the leftmost column and **upper-tail probabilities** $\alpha$ across the top. For example, row $9$, column $0.025$ gives $t_{0.025,9}=2.262$. This is the positive cutoff for a two-sided 5% test with a sample of 10, because each tail gets 2.5%. Row $14$, column $0.05$ gives $t_{0.05,14}=1.761$, the positive boundary for a 5% **upper-tailed** test with a sample of 15. The table does not provide cumulative left-side probabilities the way Table III does; its headings already represent right-tail areas.

### Estimate a p-value without software

Unlike the normal table, the printed t table has only selected tail percentages. So the instructor asks you to **bound** the p-value rather than manufacture a false precision. Work in three deliberate moves: compute $|t_0|$, compare it with entries across the correct degrees-of-freedom row, then reverse the inequality for the probability. Bigger positive test statistics have smaller upper-tail areas.

For example, in row $9$, $t_{0.025,9}=2.262$ and $t_{0.01,9}=2.821$. A positive magnitude $2.55$ lies between these values, so its one-tail area lies between $0.01$ and $0.025$. If the alternative was two-sided, both tails count, so $0.02<p<0.05$. If it was right- or left-tailed in the direction of the observed statistic, do not double. If the observed statistic points opposite the one-sided alternative, the p-value is **larger than 0.5**, and a table built mostly for small upper-tail areas will not show it directly.

:::theorem[t-table bounding rule]
If $t_{a,\nu}<|t_0|<t_{b,\nu}$ and $a>b$, then the upper-tail probability $q$ satisfies $b<q<a$. For a two-sided test, $p=2q$, so $2b<p<2a$. For a one-sided test in the observed direction, $p=q$.
:::

### How the t-test differs from the z-test

The calculation follows exactly the same eight steps: population mean, null, alternative, significance, statistic, rejection boundary, observed statistic, decision. Only the estimated standard error and the reference distribution change. There is no independent rule saying small $n$ automatically means t while large $n$ automatically means z. The decisive question in these course problems is whether the **population** standard deviation is supplied. The assumptions also matter: for a very small sample, normal population data are needed for the exact t procedure. If the data are grossly skewed and the normality assumption is unjustified, this particular exact inference is not guaranteed.

:::callout-pitfall[Three t-table traps]
Use $n-1$, not $n$, for the row. Use the $\alpha/2$ column for two-sided tests, not the $\alpha$ column. And when the notes provide $s^2=0.02456$, use $s=\sqrt{0.02456}$ in the mean-test denominator. The t table supports bounds such as $0.02<p<0.05$; do not pretend it gives $p=0.03126$ in a no-software exam.
:::

### The instructor's two contrasts

The golf-club problem has a sample mean slightly above the benchmark, but its sample variability is large relative to that increase. It is therefore a right-tailed **t** problem whose observed statistic is small. The Calculus II scores have no known population standard deviation either, but their observed mean is appreciably below 85 when expressed in estimated standard errors. The same t machinery can therefore give opposite decisions for the two cases. The statistic measures standardized evidence, not the raw size of the engineering difference alone.

:::example[Example 9.8 — Golf-driver coefficient of restitution]
Unit 9 Exercise 2. A random sample of 15 golf drivers has average coefficient of restitution 0.83725 and sample variance 0.02456. Is there significant evidence at level 0.05 that the **mean coefficient exceeds 0.82**? State the t statistic and decision.

Numerical data: $\mu_0=0.82$, $n=15$, $\bar{x}=0.83725$, $s^2=0.02456$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $0.43$; fail to reject $H_0$

1. **Parameter:** the population mean golf-driver coefficient of restitution $\mu$.
2. **Null hypothesis:** $H_0:\mu=0.82$, the proposed benchmark.
3. **Alternative hypothesis:** $H_1:\mu>0.82$, because the question asks specifically whether the mean **exceeds** 0.82.
4. **Significance:** use the specified $\alpha=0.05$.
5. **Test statistic:** the population standard deviation is unknown, so $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$ and $\nu=15-1=14$ from Final sheet page 2. Convert the **sample variance** to $s=\sqrt{0.02456}=0.1567$.
6. **Rejection region:** $t_0>1.761$, from Table V, Final sheet page 5, row $14$, column $0.05$ (upper-tail area).
7. **Calculation:** $t_0=(0.83725-0.82)/(\sqrt{0.02456}/\sqrt{15})=0.4263$.
8. **Decision:** $0.4263$ is nowhere near the right-tail boundary $1.761$, so fail to reject $H_0$.

In context: The golf-driver mean is only about 0.43 estimated standard errors above 0.82, which is insufficient evidence that the population mean coefficient exceeds 0.82.
::::
:::

:::example[Example 9.9 — Calculus II exam scores and the test]
Exam 3 practice Problems 4 and 5. Ten students earned Calculus II final-exam scores 82, 77, 71, 60, 89, 93, 73, 74, 83, 66. Test the null of mean 85 against a difference in either direction at 0.05. The sample has mean 76.8 and sample standard deviation 10.1740. Report the t statistic and decision.

Numerical data: $\mu_0=85$, $n=10$, $\bar{x}=76.8$, $s=10.174041$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $-2.55$; reject $H_0$

1. The population mean is tested against $H_0:\mu=85$, with a two-tailed alternative and $\alpha=0.05$. An unknown population standard deviation calls for $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$.
2. The sample standard deviation is $10.1740$ and the degrees of freedom are $n-1=9$. Table V, Final sheet page 5, row $9$ and column $0.025$ gives $t=2.262$.
3. Substitute $t_0=(76.8-85)/(10.1740/\sqrt{10})=-2.549$.
4. Compare with the rejection boundary for the two-tailed test. We reject $H_0$. This result is about statistical evidence, not certainty that the machine or students are correct or defective.

In context: The ten Calculus II scores give a sample mean of 76.8, and the approximately -2.55 t statistic supports a population mean different from 85.
::::
:::

:::example[Example 9.10 — Calculus II t-table p-value bounds]
For the same ten Calculus II scores, determine a bound on the p-value of the two-sided test of the mean against 85 using **only Table V** of the Final sheet.

Numerical data: $\mu_0=85$, $n=10$, $\bar{x}=76.8$, $s=10.174041$.

::::answer[Answer]
**Answer:** $0.02 < p < 0.05$

1. Form $t_0=(76.8-85)/(10.1740/\sqrt{10})=-2.549$, with $\nu=9$. Only the magnitude is used when bounding a two-sided p-value.
2. Table V on Final sheet page 5 has degrees of freedom along the left and **upper-tail area** across the top. In row $9$, the magnitude $2.549$ lies between the tabulated thresholds $2.262$ (column $0.025$) and $2.821$ (column $0.01$).
3. The upper-tail probability lies between the corresponding column headings. Double each tail area because this is a two-sided test. Thus $0.02 < p < 0.05$.
4. A table gives an interval, not a six-decimal p-value. Compare the entire interval with $\alpha$ when deciding whether to reject.

In context: A two-sided p-value strictly between 0.02 and 0.05 is significant at 5%, so the Calculus II mean of 85 is rejected.
::::
:::

:::problem[Problem 9.13 — An unknown-sigma t statistic]{difficulty=easy}
A line produces bolts with unknown population standard deviation. For 16 bolts the mean diameter is 8.4 mm and sample standard deviation is 0.8 mm. Compare the population mean to 8.0 mm and compute t.

Numerical data: $\mu_0=8$, $n=16$, $\bar{x}=8.4$, $s=0.8$.

::::solution[Solution]
**Answer:** $2.000$

1. The population variance is not supplied. Recover the sample standard deviation as $s=\sqrt{0.64}=0.8000$ when a variance is given.
2. Use $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$ from Final sheet page 2, with $\nu=n-1=15$ degrees of freedom.
3. Direct substitution gives $(8.4-8)/(0.8000/\sqrt{16})\approx2.000$.
4. The statistic expresses the deviation in *estimated* standard errors. A $t$ table, rather than the $z$ table, supplies the critical comparison.
::::
:::

:::problem[Problem 9.14 — One-sided reduction]{difficulty=standard}
A calibration procedure is intended to decrease the average sensor reading below 10. A normal sample of 10 readings has mean 9.3 and sample standard deviation 1.0. Test at the 5% level.

Numerical data: $\mu_0=10$, $n=10$, $\bar{x}=9.3$, $s=1$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $-2.21$; reject $H_0$

1. The population mean is tested against $H_0:\mu=10$, with a lower-tailed alternative and $\alpha=0.05$. An unknown population standard deviation calls for $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$.
2. The sample standard deviation is $1.0000$ and the degrees of freedom are $n-1=9$. Table V, Final sheet page 5, row $9$ and column $0.05$ gives $t=1.833$.
3. Substitute $t_0=(9.3-10)/(1.0000/\sqrt{10})=-2.214$.
4. Compare with the rejection boundary for the lower-tailed test. We reject $H_0$. This result is about statistical evidence, not certainty that the machine or students are correct or defective.
::::
:::

:::problem[Problem 9.15 — Different from the design length]{difficulty=standard}
A normal sample of 20 parts has mean 100.8 mm and standard deviation 2.0 mm. The design value is 100 mm. Test for any difference at 5%.

Numerical data: $\mu_0=100$, $n=20$, $\bar{x}=100.8$, $s=2$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $1.79$; fail to reject $H_0$

1. The population mean is tested against $H_0:\mu=100$, with a two-tailed alternative and $\alpha=0.05$. An unknown population standard deviation calls for $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$.
2. The sample standard deviation is $2.0000$ and the degrees of freedom are $n-1=19$. Table V, Final sheet page 5, row $19$ and column $0.025$ gives $t=2.093$.
3. Substitute $t_0=(100.8-100)/(2.0000/\sqrt{20})=1.789$.
4. Compare with the rejection boundary for the two-tailed test. We fail to reject $H_0$. This result is about statistical evidence, not certainty that the machine or students are correct or defective.
::::
:::

:::problem[Problem 9.16 — One-sided t-table p interval]{difficulty=standard}
A supplier hopes to show greater mean shear strength than 75 units. For 10 normal observations, the sample mean is 76.6 and sample standard deviation is 2.4. Give table-based p bounds.

Numerical data: $\mu_0=75$, $n=10$, $\bar{x}=76.6$, $s=2.4$.

::::solution[Solution]
**Answer:** $0.025 < p < 0.05$

1. Form $t_0=(76.6-75)/(2.4000/\sqrt{10})=2.108$, with $\nu=9$. Only the magnitude is used when bounding a two-sided p-value.
2. Table V on Final sheet page 5 has degrees of freedom along the left and **upper-tail area** across the top. In row $9$, the magnitude $2.108$ lies between the tabulated thresholds $1.833$ (column $0.05$) and $2.262$ (column $0.025$).
3. The upper-tail probability lies between the corresponding column headings. Do not double a one-sided tail area. Thus $0.025 < p < 0.05$.
4. A table gives an interval, not a six-decimal p-value. Compare the entire interval with $\alpha$ when deciding whether to reject.
::::
:::

:::problem[Problem 9.17 — Golf rebound test statistic]{difficulty=easy}
Use the original golf-driver figures from Unit 9: 15 clubs, observed mean 0.83725, sample variance 0.02456 and proposed mean 0.82. Calculate the statistic alone to check whether variance or standard deviation belongs in the denominator.

Numerical data: $\mu_0=0.82$, $n=15$, $\bar{x}=0.83725$, $s^2=0.02456$.

::::solution[Solution]
**Answer:** $0.426$

1. The population variance is not supplied. Recover the sample standard deviation as $s=\sqrt{0.02456}=0.1567$ when a variance is given.
2. Use $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$ from Final sheet page 2, with $\nu=n-1=14$ degrees of freedom.
3. Direct substitution gives $(0.83725-0.82)/(0.1567/\sqrt{15})\approx0.426$.
4. The statistic expresses the deviation in *estimated* standard errors. A $t$ table, rather than the $z$ table, supplies the critical comparison.
::::
:::

:::problem[Problem 9.18 — Borderline two-sided t decision]{difficulty=challenge}
A normal population has unknown standard deviation. A sample of 10 parts has mean 20.7, sample standard deviation 1.0, and target mean 20. The engineer tests for any change at alpha 0.05.

Numerical data: $\mu_0=20$, $n=10$, $\bar{x}=20.7$, $s=1$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $2.21$; fail to reject $H_0$

1. The population mean is tested against $H_0:\mu=20$, with a two-tailed alternative and $\alpha=0.05$. An unknown population standard deviation calls for $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$.
2. The sample standard deviation is $1.0000$ and the degrees of freedom are $n-1=9$. Table V, Final sheet page 5, row $9$ and column $0.025$ gives $t=2.262$.
3. Substitute $t_0=(20.7-20)/(1.0000/\sqrt{10})=2.214$.
4. Compare with the rejection boundary for the two-tailed test. We fail to reject $H_0$. This result is about statistical evidence, not certainty that the machine or students are correct or defective.
::::
:::

## 9.4 Type I error, Type II error, acceptance regions, and power


A test can make a wrong decision in two different ways. It can call an acceptable process defective, or it can overlook a real defect. Those errors are not interchangeable. The instructor's Unit 9 notes show them in a four-cell decision table, with the true state of the null across the columns and the test's decision down the rows. The probabilities $\alpha$ and $\beta$ condition on **different truths**. That is why adding them is not a meaningful probability calculation.

:::callout-intuition[An alarm system with two failure modes]
Imagine a power-supply tester. If it fails a perfectly calibrated production line, the tester has raised a false alarm. That is a Type I error. If it passes a production line whose true average voltage is actually off target, it has missed a real problem. That is a Type II error. Power measures the second situation's success: how often the tester catches the bad state instead of missing it.
:::

:::definition[Definition 9.4 — Errors and power]
The probabilities in the Unit 9 notes are

$$
\begin{aligned}
\alpha&=P(\text{reject }H_0\mid H_0\text{ is true}),\\
\beta&=P(\text{fail to reject }H_0\mid H_0\text{ is false}),\\
\text{power}&=1-\beta.
\end{aligned}
$$

These relationships follow directly from the possible decisions; they are not separate memorization formulas on the Final sheet. The **sampling** and **test-statistic** formulas needed to evaluate them are on **Final sheet pages 1–2**.
:::

| Test decision | $H_0$ actually true | $H_0$ actually false |
|---|---|---|
| Fail to reject $H_0$ | Correct nonrejection | **Type II error**, probability $\beta$ at the specified actual parameter |
| Reject $H_0$ | **Type I error**, probability $\alpha$ | Correct detection, probability $1-\beta$ |

Read this table in sentences: when the null is true, a rejection is a Type I error. When the null is false, a failure to reject is a Type II error. The test's power is the probability of rejecting when the null is false. These conditional statements are exactly what the instructor can turn into a matching or true/false item.

### Convert a sample-mean acceptance region to an area

Sometimes the problem gives the acceptance region directly, such as $4.85\le\bar X\le5.15$, instead of giving $\alpha$ and asking you to set the cutoffs. Those endpoints identify the sample results that **do not** cause rejection. The number of individual observations and the known population standard deviation give the sampling standard error $\sigma/\sqrt n$. Under any specified true mean $\mu$, the sample mean follows the normal sampling model with center $\mu$.

:::theorem[Acceptance-region probabilities]
For a sample mean normally distributed with true mean $\mu$ and standard error $\sigma/\sqrt n$, let $L\le\bar X\le U$ be the nonrejection region. Then

$$
P_\mu(L\le\bar X\le U)=\Phi\!\left(\frac{U-\mu}{\sigma/\sqrt n}\right)-\Phi\!\left(\frac{L-\mu}{\sigma/\sqrt n}\right).
$$

The middle probability is an ordinary cumulative-normal subtraction, justified by the normal probability ideas of Chapter 5 and standard errors of Chapter 7. At the null mean $\mu_0$, $\alpha=1-P_{\mu_0}(L\le\bar X\le U)$. At a specified *different* true mean $\mu$, $\beta=P_\mu(L\le\bar X\le U)$ and power is one minus that probability.
:::

The logic is especially easy to confuse when the question says "What is the power at a true mean of 5.1?". The **physical acceptance limits do not move**. The sampling distribution's center moves to 5.1, so a larger fraction of sample means may land outside the old limits. Calculate the acceptance probability using the new true mean first. Then subtract from one to obtain power.

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Two sampling distributions centered at 5.0 and 5.1 volts sharing the same acceptance interval">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M203.50,220.00 L203.50,183.80 L204.12,182.93 L204.74,182.04 L205.36,181.14 L205.97,180.22 L206.59,179.29 L207.21,178.35 L207.83,177.39 L208.45,176.42 L209.07,175.44 L209.69,174.44 L210.31,173.43 L210.92,172.41 L211.54,171.38 L212.16,170.33 L212.78,169.27 L213.40,168.20 L214.02,167.12 L214.64,166.02 L215.26,164.91 L215.88,163.80 L216.49,162.67 L217.11,161.53 L217.73,160.37 L218.35,159.21 L218.97,158.04 L219.59,156.86 L220.21,155.67 L220.82,154.46 L221.44,153.25 L222.06,152.04 L222.68,150.81 L223.30,149.57 L223.92,148.33 L224.54,147.08 L225.16,145.82 L225.77,144.56 L226.39,143.29 L227.01,142.01 L227.63,140.73 L228.25,139.44 L228.87,138.15 L229.49,136.86 L230.11,135.56 L230.72,134.25 L231.34,132.95 L231.96,131.64 L232.58,130.33 L233.20,129.03 L233.82,127.71 L234.44,126.40 L235.06,125.09 L235.68,123.79 L236.29,122.48 L236.91,121.17 L237.53,119.87 L238.15,118.57 L238.77,117.27 L239.39,115.98 L240.01,114.69 L240.62,113.41 L241.24,112.13 L241.86,110.87 L242.48,109.60 L243.10,108.35 L243.72,107.10 L244.34,105.86 L244.96,104.64 L245.57,103.42 L246.19,102.21 L246.81,101.02 L247.43,99.83 L248.05,98.66 L248.67,97.50 L249.29,96.36 L249.91,95.23 L250.53,94.11 L251.14,93.01 L251.76,91.93 L252.38,90.86 L253.00,89.81 L253.62,88.78 L254.24,87.76 L254.86,86.77 L255.48,85.79 L256.09,84.84 L256.71,83.90 L257.33,82.99 L257.95,82.09 L258.57,81.22 L259.19,80.37 L259.81,79.55 L260.43,78.74 L261.04,77.96 L261.66,77.21 L262.28,76.48 L262.90,75.77 L263.52,75.09 L264.14,74.44 L264.76,73.81 L265.37,73.21 L265.99,72.64 L266.61,72.09 L267.23,71.57 L267.85,71.08 L268.47,70.62 L269.09,70.19 L269.71,69.78 L270.33,69.41 L270.94,69.06 L271.56,68.74 L272.18,68.45 L272.80,68.20 L273.42,67.97 L274.04,67.77 L274.66,67.60 L275.28,67.47 L275.89,67.36 L276.51,67.28 L277.13,67.24 L277.75,67.22 L278.37,67.24 L278.99,67.28 L279.61,67.36 L280.23,67.47 L280.84,67.60 L281.46,67.77 L282.08,67.97 L282.70,68.20 L283.32,68.45 L283.94,68.74 L284.56,69.06 L285.17,69.41 L285.79,69.78 L286.41,70.19 L287.03,70.62 L287.65,71.08 L288.27,71.57 L288.89,72.09 L289.51,72.64 L290.13,73.21 L290.74,73.81 L291.36,74.44 L291.98,75.09 L292.60,75.77 L293.22,76.48 L293.84,77.21 L294.46,77.96 L295.08,78.74 L295.69,79.55 L296.31,80.37 L296.93,81.22 L297.55,82.09 L298.17,82.99 L298.79,83.90 L299.41,84.84 L300.03,85.79 L300.64,86.77 L301.26,87.76 L301.88,88.78 L302.50,89.81 L303.12,90.86 L303.74,91.93 L304.36,93.01 L304.97,94.11 L305.59,95.23 L306.21,96.36 L306.83,97.50 L307.45,98.66 L308.07,99.83 L308.69,101.02 L309.31,102.21 L309.93,103.42 L310.54,104.64 L311.16,105.86 L311.78,107.10 L312.40,108.35 L313.02,109.60 L313.64,110.87 L314.26,112.13 L314.88,113.41 L315.49,114.69 L316.11,115.98 L316.73,117.27 L317.35,118.57 L317.97,119.87 L318.59,121.17 L319.21,122.48 L319.83,123.79 L320.44,125.09 L321.06,126.40 L321.68,127.71 L322.30,129.03 L322.92,130.33 L323.54,131.64 L324.16,132.95 L324.78,134.25 L325.39,135.56 L326.01,136.86 L326.63,138.15 L327.25,139.44 L327.87,140.73 L328.49,142.01 L329.11,143.29 L329.73,144.56 L330.34,145.82 L330.96,147.08 L331.58,148.33 L332.20,149.57 L332.82,150.81 L333.44,152.04 L334.06,153.25 L334.68,154.46 L335.29,155.67 L335.91,156.86 L336.53,158.04 L337.15,159.21 L337.77,160.37 L338.39,161.53 L339.01,162.67 L339.63,163.80 L340.24,164.91 L340.86,166.02 L341.48,167.12 L342.10,168.20 L342.72,169.27 L343.34,170.33 L343.96,171.38 L344.58,172.41 L345.19,173.43 L345.81,174.44 L346.43,175.44 L347.05,176.42 L347.67,177.39 L348.29,178.35 L348.91,179.29 L349.53,180.22 L350.14,181.14 L350.76,182.04 L351.38,182.93 L352.00,183.80 L352.00,220.00 Z"/>
<path class="fig-curve-alt" d="M55.00,220.00 L57.06,220.00 L59.13,220.00 L61.19,220.00 L63.25,220.00 L65.31,220.00 L67.38,220.00 L69.44,220.00 L71.50,220.00 L73.56,220.00 L75.63,220.00 L77.69,220.00 L79.75,220.00 L81.81,220.00 L83.88,220.00 L85.94,220.00 L88.00,220.00 L90.06,220.00 L92.13,220.00 L94.19,220.00 L96.25,220.00 L98.31,220.00 L100.38,220.00 L102.44,220.00 L104.50,220.00 L106.56,220.00 L108.63,220.00 L110.69,220.00 L112.75,220.00 L114.81,220.00 L116.88,220.00 L118.94,220.00 L121.00,220.00 L123.06,220.00 L125.12,220.00 L127.19,220.00 L129.25,219.99 L131.31,219.99 L133.37,219.99 L135.44,219.99 L137.50,219.99 L139.56,219.98 L141.62,219.98 L143.69,219.98 L145.75,219.97 L147.81,219.97 L149.87,219.96 L151.94,219.95 L154.00,219.94 L156.06,219.93 L158.12,219.91 L160.19,219.90 L162.25,219.88 L164.31,219.85 L166.37,219.82 L168.44,219.79 L170.50,219.75 L172.56,219.71 L174.62,219.65 L176.69,219.59 L178.75,219.52 L180.81,219.44 L182.88,219.34 L184.94,219.23 L187.00,219.10 L189.06,218.96 L191.13,218.79 L193.19,218.60 L195.25,218.39 L197.31,218.14 L199.38,217.87 L201.44,217.55 L203.50,217.20 L205.56,216.81 L207.63,216.36 L209.69,215.87 L211.75,215.31 L213.81,214.70 L215.88,214.02 L217.94,213.26 L220.00,212.43 L222.06,211.51 L224.13,210.50 L226.19,209.40 L228.25,208.19 L230.31,206.87 L232.38,205.45 L234.44,203.90 L236.50,202.22 L238.56,200.42 L240.62,198.48 L242.69,196.40 L244.75,194.18 L246.81,191.81 L248.87,189.29 L250.94,186.62 L253.00,183.80 L255.06,180.83 L257.12,177.71 L259.19,174.44 L261.25,171.03 L263.31,167.48 L265.37,163.80 L267.44,159.99 L269.50,156.06 L271.56,152.04 L273.62,147.91 L275.69,143.71 L277.75,139.44 L279.81,135.12 L281.87,130.77 L283.94,126.40 L286.00,122.04 L288.06,117.70 L290.12,113.41 L292.19,109.18 L294.25,105.05 L296.31,101.02 L298.37,97.12 L300.44,93.38 L302.50,89.81 L304.56,86.44 L306.63,83.29 L308.69,80.37 L310.75,77.71 L312.81,75.32 L314.88,73.21 L316.94,71.41 L319.00,69.91 L321.06,68.74 L323.13,67.90 L325.19,67.39 L327.25,67.22 L329.31,67.39 L331.38,67.90 L333.44,68.74 L335.50,69.91 L337.56,71.41 L339.63,73.21 L341.69,75.32 L343.75,77.71 L345.81,80.37 L347.88,83.29 L349.94,86.44 L352.00,89.81 L354.06,93.38 L356.13,97.12 L358.19,101.02 L360.25,105.05 L362.31,109.18 L364.38,113.41 L366.44,117.70 L368.50,122.04 L370.56,126.40 L372.62,130.77 L374.69,135.12 L376.75,139.44 L378.81,143.71 L380.87,147.91 L382.94,152.04 L385.00,156.06 L387.06,159.99 L389.12,163.80 L391.19,167.48 L393.25,171.03 L395.31,174.44 L397.37,177.71 L399.44,180.83 L401.50,183.80 L403.56,186.62 L405.62,189.29 L407.69,191.81 L409.75,194.18 L411.81,196.40 L413.87,198.48 L415.94,200.42 L418.00,202.22 L420.06,203.90 L422.12,205.45 L424.19,206.87 L426.25,208.19 L428.31,209.40 L430.38,210.50 L432.44,211.51 L434.50,212.43 L436.56,213.26 L438.63,214.02 L440.69,214.70 L442.75,215.31 L444.81,215.87 L446.88,216.36 L448.94,216.81 L451.00,217.20 L453.06,217.55 L455.13,217.87 L457.19,218.14 L459.25,218.39 L461.31,218.60 L463.38,218.79 L465.44,218.96 L467.50,219.10 L469.56,219.23 L471.63,219.34 L473.69,219.44 L475.75,219.52 L477.81,219.59 L479.88,219.65 L481.94,219.71 L484.00,219.75 L486.06,219.79 L488.12,219.82 L490.19,219.85 L492.25,219.88 L494.31,219.90 L496.37,219.91 L498.44,219.93 L500.50,219.94 L502.56,219.95 L504.62,219.96 L506.69,219.97 L508.75,219.97 L510.81,219.98 L512.87,219.98 L514.94,219.98 L517.00,219.99 L519.06,219.99 L521.12,219.99 L523.19,219.99 L525.25,219.99 L527.31,220.00 L529.37,220.00 L531.44,220.00 L533.50,220.00 L535.56,220.00 L537.62,220.00 L539.69,220.00 L541.75,220.00 L543.81,220.00 L545.87,220.00 L547.94,220.00 L550.00,220.00"/>
<path class="fig-curve" d="M55.00,220.00 L57.06,220.00 L59.13,220.00 L61.19,220.00 L63.25,220.00 L65.31,220.00 L67.38,220.00 L69.44,220.00 L71.50,220.00 L73.56,220.00 L75.63,220.00 L77.69,220.00 L79.75,219.99 L81.81,219.99 L83.88,219.99 L85.94,219.99 L88.00,219.99 L90.06,219.98 L92.13,219.98 L94.19,219.98 L96.25,219.97 L98.31,219.97 L100.38,219.96 L102.44,219.95 L104.50,219.94 L106.56,219.93 L108.63,219.91 L110.69,219.90 L112.75,219.88 L114.81,219.85 L116.88,219.82 L118.94,219.79 L121.00,219.75 L123.06,219.71 L125.12,219.65 L127.19,219.59 L129.25,219.52 L131.31,219.44 L133.37,219.34 L135.44,219.23 L137.50,219.10 L139.56,218.96 L141.62,218.79 L143.69,218.60 L145.75,218.39 L147.81,218.14 L149.87,217.87 L151.94,217.55 L154.00,217.20 L156.06,216.81 L158.12,216.36 L160.19,215.87 L162.25,215.31 L164.31,214.70 L166.37,214.02 L168.44,213.26 L170.50,212.43 L172.56,211.51 L174.62,210.50 L176.69,209.40 L178.75,208.19 L180.81,206.87 L182.88,205.45 L184.94,203.90 L187.00,202.22 L189.06,200.42 L191.13,198.48 L193.19,196.40 L195.25,194.18 L197.31,191.81 L199.38,189.29 L201.44,186.62 L203.50,183.80 L205.56,180.83 L207.63,177.71 L209.69,174.44 L211.75,171.03 L213.81,167.48 L215.88,163.80 L217.94,159.99 L220.00,156.06 L222.06,152.04 L224.13,147.91 L226.19,143.71 L228.25,139.44 L230.31,135.12 L232.38,130.77 L234.44,126.40 L236.50,122.04 L238.56,117.70 L240.62,113.41 L242.69,109.18 L244.75,105.05 L246.81,101.02 L248.87,97.12 L250.94,93.38 L253.00,89.81 L255.06,86.44 L257.12,83.29 L259.19,80.37 L261.25,77.71 L263.31,75.32 L265.37,73.21 L267.44,71.41 L269.50,69.91 L271.56,68.74 L273.62,67.90 L275.69,67.39 L277.75,67.22 L279.81,67.39 L281.87,67.90 L283.94,68.74 L286.00,69.91 L288.06,71.41 L290.12,73.21 L292.19,75.32 L294.25,77.71 L296.31,80.37 L298.37,83.29 L300.44,86.44 L302.50,89.81 L304.56,93.38 L306.63,97.12 L308.69,101.02 L310.75,105.05 L312.81,109.18 L314.88,113.41 L316.94,117.70 L319.00,122.04 L321.06,126.40 L323.13,130.77 L325.19,135.12 L327.25,139.44 L329.31,143.71 L331.38,147.91 L333.44,152.04 L335.50,156.06 L337.56,159.99 L339.63,163.80 L341.69,167.48 L343.75,171.03 L345.81,174.44 L347.88,177.71 L349.94,180.83 L352.00,183.80 L354.06,186.62 L356.13,189.29 L358.19,191.81 L360.25,194.18 L362.31,196.40 L364.38,198.48 L366.44,200.42 L368.50,202.22 L370.56,203.90 L372.62,205.45 L374.69,206.87 L376.75,208.19 L378.81,209.40 L380.87,210.50 L382.94,211.51 L385.00,212.43 L387.06,213.26 L389.12,214.02 L391.19,214.70 L393.25,215.31 L395.31,215.87 L397.37,216.36 L399.44,216.81 L401.50,217.20 L403.56,217.55 L405.62,217.87 L407.69,218.14 L409.75,218.39 L411.81,218.60 L413.87,218.79 L415.94,218.96 L418.00,219.10 L420.06,219.23 L422.12,219.34 L424.19,219.44 L426.25,219.52 L428.31,219.59 L430.38,219.65 L432.44,219.71 L434.50,219.75 L436.56,219.79 L438.63,219.82 L440.69,219.85 L442.75,219.88 L444.81,219.90 L446.88,219.91 L448.94,219.93 L451.00,219.94 L453.06,219.95 L455.13,219.96 L457.19,219.97 L459.25,219.97 L461.31,219.98 L463.38,219.98 L465.44,219.98 L467.50,219.99 L469.56,219.99 L471.63,219.99 L473.69,219.99 L475.75,219.99 L477.81,220.00 L479.88,220.00 L481.94,220.00 L484.00,220.00 L486.06,220.00 L488.12,220.00 L490.19,220.00 L492.25,220.00 L494.31,220.00 L496.37,220.00 L498.44,220.00 L500.50,220.00 L502.56,220.00 L504.62,220.00 L506.69,220.00 L508.75,220.00 L510.81,220.00 L512.87,220.00 L514.94,220.00 L517.00,220.00 L519.06,220.00 L521.12,220.00 L523.19,220.00 L525.25,220.00 L527.31,220.00 L529.37,220.00 L531.44,220.00 L533.50,220.00 L535.56,220.00 L537.62,220.00 L539.69,220.00 L541.75,220.00 L543.81,220.00 L545.87,220.00 L547.94,220.00 L550.00,220.00"/>
<path class="fig-guide" d="M203.5,220 L203.5,45"/><text class="fig-label" x="203.5" y="239">4.85</text>
<path class="fig-guide" d="M352.0,220 L352.0,45"/><text class="fig-label" x="352.0" y="239">5.15</text>
</svg>
<figcaption>For the power-supply example, the acceptance limits remain 4.85 and 5.15 while the alternative sampling curve shifts its center from 5.0 to 5.1 volts.</figcaption>
</figure>

### Find alpha without assuming a textbook 5% test

A specified acceptance interval determines its own false-alarm probability. It may happen to equal $0.05$, but there is no guarantee. The power-supply exercise's limits $4.85$ and $5.15$ around a mean of $5$ give two symmetric rejection tails. The resulting $\alpha$ is approximately $0.09$, not $0.05$, because the interval is narrower than a central 95% acceptance region for the given sample size and variability.

For an upper-tailed or lower-tailed acceptance region, there is one rejection tail. The same standardization rule still works, but only one physical boundary matters. Two-sided acceptance regions require a **difference** of cumulative probabilities between their lower and upper endpoints. Do not double an interior area; double only a symmetric **tail** probability when the tails actually have equal areas under the same null distribution.

:::callout-pitfall[Condition on the right true mean]
To find $\alpha$, standardize acceptance bounds around the **null** mean. To find $\beta$ or power, standardize the **same bounds** around the specified **true alternative** mean. Do not change the cutoffs when changing the center. Do not confuse $1-\alpha$ (correct nonrejection when the null is true) with $1-\beta$ (power when the null is false).
:::

### What changes the error probabilities

Making a rejection rule more conservative generally reduces $\alpha$: a truly good process is less likely to be falsely flagged. But with the same sample size and same actual shift, a harder-to-reach rejection region usually increases $\beta$, making real defects harder to detect. This is the tradeoff between false alarms and missed alarms. Increasing the sample size is different: it shrinks the standard error, helping distinguish a fixed real shift from the null value. It can improve power **without** increasing the chosen significance level.

The value of $\beta$ has no universal meaning unless the alternative mean is specified. If the true mean is 5.0001 rather than 5.0, the test may have very little power to detect that tiny difference. If it is 5.5, rejection may be nearly certain. This is why Unit 9 Exercise 3 asks for the power when the true mean is precisely 5.1, not simply "the power of this test."

:::example[Example 9.11 — Power-supply false-alarm probability]
Unit 9 Exercise 3(a,b). A manufacturer tests 8 PC power supplies for a mean output of 5 volts. Outputs are normal with known standard deviation 0.25 volt. The test does **not** reject for sample means between 4.85 and 5.15 volts, endpoints included. State the two-sided hypotheses and find the **actual Type I error probability**.

Numerical data: $\mu_0=5$, $n=8$, $\sigma=0.25$, $L=4.85$, $U=5.15$.

::::answer[Answer]
**Answer:** $0.0891$

1. The sample-mean standard error is $\sigma/\sqrt n=0.25/\sqrt{8}=0.08839$, from Final sheet page 1. The *acceptance region* is $4.85\leq\bar{X}\leq5.15$; points outside lead to rejection.
2. For Type I error, the null mean is true: 5. Convert the endpoints to $z$ values: $(4.85-5)/0.08839=-1.697$ and $(5.15-5)/0.08839=1.697$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-1.70)=0.044565$ and $\Phi(1.70)=0.955435$. Their difference, the probability *between* the limits, is $0.9109$.
4. Take one minus the acceptance probability because Type I error means rejecting a true null. Thus $\alpha=0.0891$. This is the long-run fraction of such tests with the specified outcome.

In context: The 4.85-to-5.15-volt acceptance region would falsely reject a truly 5-volt population about 8.91% of the time.
::::
:::

:::example[Example 9.12 — Power of the power-supply tester]
Unit 9 Exercise 3(c). For the same 8 PC power supplies and nonrejection interval 4.85 to 5.15 volts, find the probability of rejecting if the **true mean output is 5.1 volts**.

Numerical data: $\mu_0=5$, $\mu=5.1$, $n=8$, $\sigma=0.25$, $L=4.85$, $U=5.15$.

::::answer[Answer]
**Answer:** $0.2867$

1. The sample-mean standard error is $\sigma/\sqrt n=0.25/\sqrt{8}=0.08839$, from Final sheet page 1. The *acceptance region* is $4.85\leq\bar{X}\leq5.15$; points outside lead to rejection.
2. For Type II error or power, the actual mean is 5.1, even though the null claims 5. Convert the endpoints to $z$ values: $(4.85-5.1)/0.08839=-2.828$ and $(5.15-5.1)/0.08839=0.566$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-2.83)=0.002327$ and $\Phi(0.57)=0.715661$. Their difference, the probability *between* the limits, is $0.7133$.
4. Take one minus the acceptance probability because power is successful detection. Thus $\text{power}=0.2867$. This is the long-run fraction of such tests with the specified outcome.

In context: At a real mean of 5.1 volts, this particular test detects the shift only about 28.67% of the time and misses it about 71.33% of the time.
::::
:::

:::example[Example 9.13 — Hole-length acceptance: false alarms]
Exam 3 practice Problem 8(a,b). A quality inspector tests whether the mean product length equals 11.5 inches. The population standard deviation is 0.6 inch, 15 parts are measured, and the nonrejection region for the **sample mean** is 11.25 to 11.75 inches. State the hypotheses and compute Type I error probability.

Numerical data: $\mu_0=11.5$, $n=15$, $\sigma=0.6$, $L=11.25$, $U=11.75$.

::::answer[Answer]
**Answer:** $0.1074$

1. The sample-mean standard error is $\sigma/\sqrt n=0.6/\sqrt{15}=0.15492$, from Final sheet page 1. The *acceptance region* is $11.25\leq\bar{X}\leq11.75$; points outside lead to rejection.
2. For Type I error, the null mean is true: 11.5. Convert the endpoints to $z$ values: $(11.25-11.5)/0.15492=-1.614$ and $(11.75-11.5)/0.15492=1.614$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-1.61)=0.053699$ and $\Phi(1.61)=0.946301$. Their difference, the probability *between* the limits, is $0.8926$.
4. Take one minus the acceptance probability because Type I error means rejecting a true null. Thus $\alpha=0.1074$. This is the long-run fraction of such tests with the specified outcome.

In context: The specified inspection interval falsely flags a truly 11.5-inch mean in about 10.74% of random samples of fifteen parts.
::::
:::

:::example[Example 9.14 — Hole-length acceptance: detecting 11.7]
Exam 3 practice Problem 8(c). Keep the same 11.25 to 11.75 sample-mean acceptance region, 15 parts, population standard deviation 0.6 inch and nominal mean 11.5 inches. Find power when the true process mean is **11.7 inches**.

Numerical data: $\mu_0=11.5$, $\mu=11.7$, $n=15$, $\sigma=0.6$, $L=11.25$, $U=11.75$.

::::answer[Answer]
**Answer:** $0.3764$

1. The sample-mean standard error is $\sigma/\sqrt n=0.6/\sqrt{15}=0.15492$, from Final sheet page 1. The *acceptance region* is $11.25\leq\bar{X}\leq11.75$; points outside lead to rejection.
2. For Type II error or power, the actual mean is 11.7, even though the null claims 11.5. Convert the endpoints to $z$ values: $(11.25-11.7)/0.15492=-2.905$ and $(11.75-11.7)/0.15492=0.323$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-2.90)=0.001866$ and $\Phi(0.32)=0.625516$. Their difference, the probability *between* the limits, is $0.6236$.
4. Take one minus the acceptance probability because power is successful detection. Thus $\text{power}=0.3764$. This is the long-run fraction of such tests with the specified outcome.

In context: If the actual average length is 11.7 inches, this inspection rule detects the offset in about 37.64% of samples.
::::
:::

:::problem[Problem 9.19 — Power from beta]{difficulty=easy}
At a particular true mean a detector has Type II error probability 0.18. Calculate its power.

Numerical data: $\beta=0.18$.

::::solution[Solution]
**Answer:** $0.8200$

1. Power and Type II error are complementary outcomes when the specified alternative is the actual truth.
2. The definition in the Unit 9 notes is $\text{power}=1-\beta$. With $\beta=0.18$, evaluate $1-0.18=0.8200$.
3. This is the probability of rejecting an incorrect null hypothesis for this particular true mean.
4. A high value is desirable because it means the engineering test is more likely to detect a genuine problem rather than overlook it.
::::
:::

:::problem[Problem 9.20 — Correct decision under the null]{difficulty=easy}
A two-sided quality check is run at significance 0.01. What is the probability of not rejecting when the null model is actually true?

Numerical data: $\alpha=0.01$.

::::solution[Solution]
**Answer:** $0.9900$

1. The two outcomes under a true null are reject or fail to reject. They partition the repeated-sampling outcomes.
2. By definition $\alpha=P(\text{reject }H_0\mid H_0\text{ true})$, so the chance of not rejecting is $1-\alpha$.
3. Substitute $1-0.01=0.9900$.
4. This is not power: power is conditioned on a false null, whereas this probability is conditioned on the null being true. Keeping those conditions distinct prevents a common terminology error.
::::
:::

:::problem[Problem 9.21 — Type II at a displaced mean]{difficulty=standard}
A normal process has nominal mean 50, known standard deviation 2 and sample size 25. Nonrejection occurs when the sample mean lies between 49.216 and 50.784. Find beta when the true mean equals 51.

Numerical data: $\mu_0=50$, $\mu=51$, $n=25$, $\sigma=2$, $L=49.216$, $U=50.784$.

::::solution[Solution]
**Answer:** $0.2946$

1. The sample-mean standard error is $\sigma/\sqrt n=2/\sqrt{25}=0.40000$, from Final sheet page 1. The *acceptance region* is $49.216\leq\bar{X}\leq50.784$; points outside lead to rejection.
2. For Type II error or power, the actual mean is 51, even though the null claims 50. Convert the endpoints to $z$ values: $(49.216-51)/0.40000=-4.460$ and $(50.784-51)/0.40000=-0.540$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-4.46)=0.000000$ and $\Phi(-0.54)=0.294599$. Their difference, the probability *between* the limits, is $0.2946$.
4. Keep that probability because Type II error means failing to reject the false null. Thus $\beta=0.2946$. This is the long-run fraction of such tests with the specified outcome.
::::
:::

:::problem[Problem 9.22 — A voltage test falsely rejects]{difficulty=standard}
An acceptance test for a 12-volt supply has known sigma 0.5, n=25, and accepts sample means from 11.8 to 12.2. Compute alpha.

Numerical data: $\mu_0=12$, $n=25$, $\sigma=0.5$, $L=11.8$, $U=12.2$.

::::solution[Solution]
**Answer:** $0.0455$

1. The sample-mean standard error is $\sigma/\sqrt n=0.5/\sqrt{25}=0.10000$, from Final sheet page 1. The *acceptance region* is $11.8\leq\bar{X}\leq12.2$; points outside lead to rejection.
2. For Type I error, the null mean is true: 12. Convert the endpoints to $z$ values: $(11.8-12)/0.10000=-2.000$ and $(12.2-12)/0.10000=2.000$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-2.00)=0.022750$ and $\Phi(2.00)=0.977250$. Their difference, the probability *between* the limits, is $0.9545$.
4. Take one minus the acceptance probability because Type I error means rejecting a true null. Thus $\alpha=0.0455$. This is the long-run fraction of such tests with the specified outcome.
::::
:::

:::problem[Problem 9.23 — Power after a meaningful shift]{difficulty=standard}
For the same supply (null 12 V, sigma 0.5 V, n=25, acceptance limits 11.8–12.2), find power if the true mean is 12.3 V.

Numerical data: $\mu_0=12$, $\mu=12.3$, $n=25$, $\sigma=0.5$, $L=11.8$, $U=12.2$.

::::solution[Solution]
**Answer:** $0.8413$

1. The sample-mean standard error is $\sigma/\sqrt n=0.5/\sqrt{25}=0.10000$, from Final sheet page 1. The *acceptance region* is $11.8\leq\bar{X}\leq12.2$; points outside lead to rejection.
2. For Type II error or power, the actual mean is 12.3, even though the null claims 12. Convert the endpoints to $z$ values: $(11.8-12.3)/0.10000=-5.000$ and $(12.2-12.3)/0.10000=-1.000$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-5.00)=0.000000$ and $\Phi(-1.00)=0.158655$. Their difference, the probability *between* the limits, is $0.1587$.
4. Take one minus the acceptance probability because power is successful detection. Thus $\text{power}=0.8413$. This is the long-run fraction of such tests with the specified outcome.
::::
:::

:::problem[Problem 9.24 — Narrower interval, wrong intuition]{difficulty=challenge}
An inspector uses a null mean 30, sigma 3, sample size 36 and sample-mean nonrejection interval [29.5,30.5]. Compute alpha and explain why the narrow interval increases false alarms.

Numerical data: $\mu_0=30$, $n=36$, $\sigma=3$, $L=29.5$, $U=30.5$.

::::solution[Solution]
**Answer:** $0.3173$

1. The sample-mean standard error is $\sigma/\sqrt n=3/\sqrt{36}=0.50000$, from Final sheet page 1. The *acceptance region* is $29.5\leq\bar{X}\leq30.5$; points outside lead to rejection.
2. For Type I error, the null mean is true: 30. Convert the endpoints to $z$ values: $(29.5-30)/0.50000=-1.000$ and $(30.5-30)/0.50000=1.000$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-1.00)=0.158655$ and $\Phi(1.00)=0.841345$. Their difference, the probability *between* the limits, is $0.6827$.
4. Take one minus the acceptance probability because Type I error means rejecting a true null. Thus $\alpha=0.3173$. This is the long-run fraction of such tests with the specified outcome.
::::
:::

## 9.5 Formula-based beta and sample-size planning


The acceptance-region method explains where Type II error comes from geometrically. The formula on the Final sheet packages exactly the same idea into one line for the familiar **two-sided z-test**, with the standard symmetric rejection boundaries determined by $\alpha$. It is useful when the instructor gives a target true mean, population standard deviation, significance level and sample size, but does not spell out an acceptance interval. Its companion formula works backward: how many specimens must be tested to have a desired chance of finding a particular meaningful shift?

:::callout-intuition[Move the sampling distribution, not the machine's limits]
At the null mean, most sample averages fall near the middle of the acceptance region. If the true mean moves upward by an amount $\delta$, the entire sampling distribution of the mean shifts right, but the reference rejection boundaries stay anchored to $\mu_0$. The amount of shift measured in standard errors is $\delta\sqrt n/\sigma$. More specimens make that standardized shift larger, so the same physical change becomes easier to detect.
:::

:::definition[Definition 9.5 — Beta at a specified mean]
For a two-sided z test with known $\sigma$, null mean $\mu_0$, actual mean $\mu$ and significance $\alpha$, let $\delta=\mu-\mu_0$. Then

$$
\beta=\Phi\!\left(z_{\alpha/2}-\frac{\delta\sqrt n}{\sigma}\right)-\Phi\!\left(-z_{\alpha/2}-\frac{\delta\sqrt n}{\sigma}\right).
$$

This formula and $\delta=\mu-\mu_0$ are printed on **Final sheet page 2**. The symbol that looks like a minus after $\beta$ in the scan is intended as an **equals sign**. Power is $1-\beta$.
:::

### Derive the formula so it is not a blind memory item

The two-sided null-based acceptance interval for the sample mean is

$$
\mu_0-z_{\alpha/2}\frac{\sigma}{\sqrt n}\ \le\ \bar X\ \le\ \mu_0+z_{\alpha/2}\frac{\sigma}{\sqrt n}.
$$

This is the **same geometry** used in the previous section. To calculate the probability of staying inside when the true mean is $\mu$, subtract $\mu$ from both endpoints and divide by $\sigma/\sqrt n$. The upper standardized endpoint becomes $z_{\alpha/2}-(\mu-\mu_0)\sqrt n/\sigma$. The lower endpoint becomes $-z_{\alpha/2}-(\mu-\mu_0)\sqrt n/\sigma$. Subtract the lower normal cumulative area from the upper area and you get the formula printed on the sheet. No new probability law was invented; it is just the probability of an interval under a shifted normal distribution.

If $\delta$ is negative, the shift points left and both transformed endpoints change accordingly. The two-sided formula still works. For symmetric two-sided z tests, power depends on the **size** of the shift, not its sign: shifts of $+1$ and $-1$ have the same probability of leaving a symmetric acceptance interval. This symmetry is a valuable check on a calculation.

### Designing for a desired power

Suppose you need 90% power to detect a shift $|\delta|=1$ when individual measurements have known standard deviation $\sigma=2$ and the significance is 5%. If the proposed test is two-sided, its positive rejection boundary is $z_{0.025}=1.96$. Desired power 90% means $\beta=0.10$, so $z_\beta=z_{0.10}\approx1.28$. The sample-size approximation combines those two standard-normal distances: $n\approx(1.96+1.28)^2(2)^2/(1)^2$. That comes to 41.99. A sample size has to be a whole number and is always rounded up, so the answer is $n=42$ specimens.

:::theorem[Planning formula for a mean shift]
The Final sheet, **page 2**, prints

$$
n\approx\frac{(z_\alpha+z_\beta)^2\sigma^2}{\delta^2}.
$$

For a **one-sided** z test, its printed $z_\alpha$ is the appropriate one-tail boundary. For the **two-sided** design used in Unit 9 Exercise 5, use $z_{\alpha/2}$ instead because $\alpha$ is split between two tails:

$$
n\approx\frac{(z_{\alpha/2}+z_\beta)^2\sigma^2}{\delta^2}.
$$

Always round the result up to the next whole number, and that whole number is your answer.
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Sample size on horizontal axis and two-sided z test power for a fixed mean shift">
<path class="fig-axis" d="M55,40 L55,220 L555,220"/><path class="fig-guide" d="M55,71.50 L550,71.50"/><path class="fig-curve" d="M55.00,186.84 L57.06,184.61 L59.12,182.39 L61.19,180.16 L63.25,177.95 L65.31,175.74 L67.38,173.54 L69.44,171.35 L71.50,169.17 L73.56,167.01 L75.62,164.86 L77.69,162.73 L79.75,160.62 L81.81,158.52 L83.88,156.45 L85.94,154.39 L88.00,152.36 L90.06,150.35 L92.12,148.36 L94.19,146.39 L96.25,144.45 L98.31,142.53 L100.38,140.64 L102.44,138.77 L104.50,136.93 L106.56,135.12 L108.62,133.33 L110.69,131.57 L112.75,129.83 L114.81,128.13 L116.88,126.45 L118.94,124.79 L121.00,123.17 L123.06,121.57 L125.12,120.00 L127.19,118.45 L129.25,116.94 L131.31,115.45 L133.38,113.99 L135.44,112.55 L137.50,111.14 L139.56,109.76 L141.62,108.41 L143.69,107.08 L145.75,105.78 L147.81,104.50 L149.88,103.25 L151.94,102.03 L154.00,100.83 L156.06,99.66 L158.12,98.51 L160.19,97.38 L162.25,96.28 L164.31,95.20 L166.38,94.15 L168.44,93.12 L170.50,92.11 L172.56,91.13 L174.62,90.16 L176.69,89.22 L178.75,88.30 L180.81,87.40 L182.88,86.53 L184.94,85.67 L187.00,84.83 L189.06,84.02 L191.12,83.22 L193.19,82.44 L195.25,81.68 L197.31,80.94 L199.38,80.22 L201.44,79.51 L203.50,78.83 L205.56,78.16 L207.62,77.50 L209.69,76.86 L211.75,76.24 L213.81,75.64 L215.88,75.05 L217.94,74.47 L220.00,73.91 L222.06,73.37 L224.12,72.84 L226.19,72.32 L228.25,71.82 L230.31,71.33 L232.38,70.85 L234.44,70.38 L236.50,69.93 L238.56,69.49 L240.62,69.06 L242.69,68.65 L244.75,68.24 L246.81,67.85 L248.88,67.46 L250.94,67.09 L253.00,66.73 L255.06,66.37 L257.12,66.03 L259.19,65.70 L261.25,65.37 L263.31,65.06 L265.38,64.75 L267.44,64.46 L269.50,64.17 L271.56,63.89 L273.62,63.61 L275.69,63.35 L277.75,63.09 L279.81,62.84 L281.88,62.60 L283.94,62.36 L286.00,62.14 L288.06,61.91 L290.12,61.70 L292.19,61.49 L294.25,61.28 L296.31,61.09 L298.38,60.90 L300.44,60.71 L302.50,60.53 L304.56,60.36 L306.62,60.19 L308.69,60.02 L310.75,59.86 L312.81,59.71 L314.88,59.56 L316.94,59.41 L319.00,59.27 L321.06,59.13 L323.12,59.00 L325.19,58.87 L327.25,58.75 L329.31,58.63 L331.38,58.51 L333.44,58.40 L335.50,58.29 L337.56,58.18 L339.62,58.08 L341.69,57.97 L343.75,57.88 L345.81,57.78 L347.88,57.69 L349.94,57.60 L352.00,57.52 L354.06,57.44 L356.12,57.36 L358.19,57.28 L360.25,57.20 L362.31,57.13 L364.38,57.06 L366.44,56.99 L368.50,56.93 L370.56,56.86 L372.62,56.80 L374.69,56.74 L376.75,56.68 L378.81,56.62 L380.88,56.57 L382.94,56.52 L385.00,56.47 L387.06,56.42 L389.12,56.37 L391.19,56.32 L393.25,56.28 L395.31,56.24 L397.38,56.19 L399.44,56.15 L401.50,56.11 L403.56,56.08 L405.62,56.04 L407.69,56.00 L409.75,55.97 L411.81,55.94 L413.88,55.91 L415.94,55.87 L418.00,55.84 L420.06,55.82 L422.12,55.79 L424.19,55.76 L426.25,55.73 L428.31,55.71 L430.38,55.68 L432.44,55.66 L434.50,55.64 L436.56,55.62 L438.62,55.59 L440.69,55.57 L442.75,55.55 L444.81,55.54 L446.88,55.52 L448.94,55.50 L451.00,55.48 L453.06,55.46 L455.12,55.45 L457.19,55.43 L459.25,55.42 L461.31,55.40 L463.38,55.39 L465.44,55.38 L467.50,55.36 L469.56,55.35 L471.62,55.34 L473.69,55.33 L475.75,55.31 L477.81,55.30 L479.88,55.29 L481.94,55.28 L484.00,55.27 L486.06,55.26 L488.12,55.25 L490.19,55.24 L492.25,55.24 L494.31,55.23 L496.38,55.22 L498.44,55.21 L500.50,55.20 L502.56,55.20 L504.62,55.19 L506.69,55.18 L508.75,55.18 L510.81,55.17 L512.88,55.16 L514.94,55.16 L517.00,55.15 L519.06,55.15 L521.12,55.14 L523.19,55.14 L525.25,55.13 L527.31,55.13 L529.38,55.12 L531.44,55.12 L533.50,55.11 L535.56,55.11 L537.62,55.11 L539.69,55.10 L541.75,55.10 L543.81,55.09 L545.88,55.09 L547.94,55.09 L550.00,55.08"/><text class="fig-label" x="149.3" y="243">25</text><text class="fig-label" x="229.4" y="243">42</text><text class="fig-label" x="234.1" y="243">43</text><text class="fig-label" x="361.4" y="243">70</text><text class="fig-label" x="502.9" y="243">100</text><text class="fig-label-em" x="64" y="64.5">90% power</text>
</svg>
<figcaption>With fixed $\alpha=0.05$, $\sigma=2$ and a 1-unit true mean shift, increasing $n$ increases two-sided test power; the curve reaches 90% at about $n=42$.</figcaption>
</figure>

The formula predicts sensible trends. Doubling $\sigma$ multiplies the required $n$ by four: noisy manufacturing measurements demand many more samples. Halving the minimum shift $|\delta|$ you want to detect also multiplies $n$ by four: distinguishing tiny shifts is expensive. If you demand greater power, $\beta$ falls and $z_\beta$ rises, increasing the required sample count. If you require a smaller false-alarm significance $\alpha$, the critical z boundary moves outward, again increasing $n$ when you hold power fixed.

:::callout-pitfall[The two symbols called beta]
In the **probability** formula, $\beta$ is the chance of missing the specified shift. In the **sample-size** formula, $z_\beta$ means the normal critical value with right-tail area $\beta$, not the number $\beta$ itself. For 90% power, $\beta=0.10$, but $z_\beta\approx1.28$, not $0.10$. Also do not use $z_\alpha$ for a two-sided test without replacing it with $z_{\alpha/2}$.
:::

### Put the result back into the physical question

Power is not the probability that an observed deviation was real. It is a *design property* before data collection, at a hypothesized alternative mean. A scientist may decide a 1-cm/s burning-rate shift is the smallest difference that would matter for safety and then set the sample size to detect it with 90% power. The meaningful shift must come from the engineering specification. A calculation cannot decide what size of difference is important in the real machine.

:::example[Example 9.15 — Rocket-propellant Type II error]
Unit 9 Exercise 4. Consider the two-sided rocket-propellant test at null mean 50 cm/s, known population standard deviation 2, alpha 0.05 and sample size 25. Suppose the **true mean is 49 cm/s**. Calculate the Type II error probability beta.

Numerical data: $\mu_0=50$, $\mu=49$, $\sigma=2$, $n=25$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $0.2946$

1. The hypothesized rate is $50$ and the true rate is $49$, giving $\delta=\mu-\mu_0=-1.000$. The standard error equals $0.4000$.
2. The two-sided $z$ cutoff comes from Table III: with $\alpha=0.05$, upper-tail $\alpha/2=0.025$ corresponds to $z_{\alpha/2}=1.96$. The formula is on Final sheet page 2.
3. Substitute $\beta=\Phi(1.96--2.5000)-\Phi(-1.96--2.5000)=0.2946$. Round each argument to two decimals and read its left cumulative probability from Table III, Final sheet pages 3–4, using the signed row and column.
4. That probability is the chance of missing this real shift: a Type II error. This quantity is defined at the chosen actual mean, not for every alternative at once.

In context: If the true burning rate is 49 cm/s, the two-sided test misses that one-centimeter-per-second departure about 29.46% of the time.
::::
:::

:::example[Example 9.16 — Design the rocket-propellant sample size]
Unit 9 Exercise 5. The analyst wants the two-sided rocket-propellant test of mean 50 to detect a **1 cm/s difference** with **90% power**, using sigma 2 cm/s and alpha 0.05. What sample size is required?

Numerical data: $\sigma=2$, $\delta=1$, $\alpha=0.05$, $\text{power}=0.9$.

::::answer[Answer]
**Answer:** $42$

1. We want power $0.9$ to detect a shift of $1$ at a two-sided significance level $0.05$. Thus $\beta=0.10$.
2. Final sheet page 2 gives a sample-size planning relationship $n=(z_\alpha+z_\beta)^2\sigma^2/\delta^2$. For a **two-sided** test the tail allocation means use $z_{\alpha/2}=1.96$, while $z_\beta=1.28$, from Table III.
3. Compute $n\approx(1.96+1.28)^2(2)^2/(1)^2=41.990$, which is the value the sheet's formula gives.
4. A sample size must be a whole number, and it is always rounded up, so $41.990$ becomes $n=42$.

In context: About 42 propellant measurements give the test 90% power to detect a 1 cm/s change in the mean burning rate.
::::
:::

:::problem[Problem 9.25 — Beta at a positive shift]{difficulty=standard}
A two-sided normal mean test targets 20, with known sigma 4, n=25 and alpha .05. If the true mean is 22, calculate beta.

Numerical data: $\mu_0=20$, $\mu=22$, $\sigma=4$, $n=25$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $0.2946$

1. The hypothesized rate is $20$ and the true rate is $22$, giving $\delta=\mu-\mu_0=2.000$. The standard error equals $0.8000$.
2. The two-sided $z$ cutoff comes from Table III: with $\alpha=0.05$, upper-tail $\alpha/2=0.025$ corresponds to $z_{\alpha/2}=1.96$. The formula is on Final sheet page 2.
3. Substitute $\beta=\Phi(1.96-2.5000)-\Phi(-1.96-2.5000)=0.2946$. Round each argument to two decimals and read its left cumulative probability from Table III, Final sheet pages 3–4, using the signed row and column.
4. That probability is the chance of missing this real shift: a Type II error. This quantity is defined at the chosen actual mean, not for every alternative at once.
::::
:::

:::problem[Problem 9.26 — Power for a shifted current]{difficulty=standard}
A normal mean test targets 3 amps with sigma 0.5 amps, n=25 and alpha 0.05, two-sided. Find power if the true mean is 3.3 amps.

Numerical data: $\mu_0=3$, $\mu=3.3$, $\sigma=0.5$, $n=25$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $0.8508$

1. The hypothesized rate is $3$ and the true rate is $3.3$, giving $\delta=\mu-\mu_0=0.300$. The standard error equals $0.1000$.
2. The two-sided $z$ cutoff comes from Table III: with $\alpha=0.05$, upper-tail $\alpha/2=0.025$ corresponds to $z_{\alpha/2}=1.96$. The formula is on Final sheet page 2.
3. Substitute $\beta=\Phi(1.96-3.0000)-\Phi(-1.96-3.0000)=0.1492$. Round each argument to two decimals and read its left cumulative probability from Table III, Final sheet pages 3–4, using the signed row and column.
4. The probability of detection is $1-\beta=0.8508$, the statistical power. This quantity is defined at the chosen actual mean, not for every alternative at once.
::::
:::

:::problem[Problem 9.27 — Plan to detect a sensor bias]{difficulty=standard}
A two-sided test of a sensor mean has population sigma 1.5 units and alpha 0.05. Find the sample size required for 90% power against a 1-unit shift.

Numerical data: $\sigma=1.5$, $\delta=1$, $\alpha=0.05$, $\text{power}=0.9$.

::::solution[Solution]
**Answer:** $24$

1. We want power $0.9$ to detect a shift of $1$ at a two-sided significance level $0.05$. Thus $\beta=0.10$.
2. Final sheet page 2 gives a sample-size planning relationship $n=(z_\alpha+z_\beta)^2\sigma^2/\delta^2$. For a **two-sided** test the tail allocation means use $z_{\alpha/2}=1.96$, while $z_\beta=1.28$, from Table III.
3. Compute $n\approx(1.96+1.28)^2(1.5)^2/(1)^2=23.620$, which is the value the sheet's formula gives.
4. A sample size must be a whole number, and it is always rounded up, so $23.620$ becomes $n=24$.
::::
:::

:::problem[Problem 9.28 — Compare false negatives]{difficulty=easy}
For a two-sided test of nominal mean 10, sigma 2, n=16, alpha 0.05, find beta at actual mean 11.

Numerical data: $\mu_0=10$, $\mu=11$, $\sigma=2$, $n=16$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $0.4840$

1. The hypothesized rate is $10$ and the true rate is $11$, giving $\delta=\mu-\mu_0=1.000$. The standard error equals $0.5000$.
2. The two-sided $z$ cutoff comes from Table III: with $\alpha=0.05$, upper-tail $\alpha/2=0.025$ corresponds to $z_{\alpha/2}=1.96$. The formula is on Final sheet page 2.
3. Substitute $\beta=\Phi(1.96-2.0000)-\Phi(-1.96-2.0000)=0.4840$. Round each argument to two decimals and read its left cumulative probability from Table III, Final sheet pages 3–4, using the signed row and column.
4. That probability is the chance of missing this real shift: a Type II error. This quantity is defined at the chosen actual mean, not for every alternative at once.
::::
:::

:::problem[Problem 9.29 — A larger engineering sample]{difficulty=standard}
A two-sided test has nominal mean 100, sigma 10, sample size 100 and significance 0.05. Find its power when the actual mean is 103.

Numerical data: $\mu_0=100$, $\mu=103$, $\sigma=10$, $n=100$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $0.8508$

1. The hypothesized rate is $100$ and the true rate is $103$, giving $\delta=\mu-\mu_0=3.000$. The standard error equals $1.0000$.
2. The two-sided $z$ cutoff comes from Table III: with $\alpha=0.05$, upper-tail $\alpha/2=0.025$ corresponds to $z_{\alpha/2}=1.96$. The formula is on Final sheet page 2.
3. Substitute $\beta=\Phi(1.96-3.0000)-\Phi(-1.96-3.0000)=0.1492$. Round each argument to two decimals and read its left cumulative probability from Table III, Final sheet pages 3–4, using the signed row and column.
4. The probability of detection is $1-\beta=0.8508$, the statistical power. This quantity is defined at the chosen actual mean, not for every alternative at once.
::::
:::

:::problem[Problem 9.30 — A small shift is expensive]{difficulty=challenge}
A two-sided test uses known sigma 3 and alpha 0.05. To attain 90% power for a shift of only 0.75, determine the required sample size.

Numerical data: $\sigma=3$, $\delta=0.75$, $\alpha=0.05$, $\text{power}=0.9$.

::::solution[Solution]
**Answer:** $168$

1. We want power $0.9$ to detect a shift of $0.75$ at a two-sided significance level $0.05$. Thus $\beta=0.10$.
2. Final sheet page 2 gives a sample-size planning relationship $n=(z_\alpha+z_\beta)^2\sigma^2/\delta^2$. For a **two-sided** test the tail allocation means use $z_{\alpha/2}=1.96$, while $z_\beta=1.28$, from Table III.
3. Compute $n\approx(1.96+1.28)^2(3)^2/(0.75)^2=167.962$, which is the value the sheet's formula gives.
4. A sample size must be a whole number, and it is always rounded up, so $167.962$ becomes $n=168$.
::::
:::

## 9.6 Chi-square tests of population variance


The questions now change from "Is the average fill wrong?" to "Is the process too inconsistent?" A machine can hit the correct mean on average but still produce a large proportion of bottles that are too full or too empty. A variance test is designed for precisely that kind of failure. The population parameter becomes $\sigma^2$, the data summary is $s^2$, and the reference distribution is chi-square, not z or t.

:::callout-intuition[Spread can be a defect even at the right average]
Two detergent-filling machines may both average 500 mL. The first machine produces almost all bottles near 500 mL; the second alternates between noticeably low and high fills. Their means agree, but their variances do not. If the specification limits variance, a mean test could miss the entire problem. A chi-square test scales the observed sample variance by the variance specified under the null.
:::

:::definition[Definition 9.6 — Chi-square variance statistic]
For independent observations from a **normal population**, test $H_0:\sigma^2=\sigma_0^2$ using

$$
\chi_0^2=\frac{(n-1)S^2}{\sigma_0^2},\qquad \nu=n-1.
$$

This formula is on **Final sheet pages 1 and 2**. A greater-than alternative rejects for large values, a less-than alternative for small values, and a two-sided alternative rejects in both tails. The chi-square rejection table is on **Final sheet page 2**, and critical values are on **page 6**.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Right skewed chi square density with upper five percent tail">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M326.26,220.00 L326.26,192.16 L327.19,192.78 L328.12,193.40 L329.06,194.00 L329.99,194.59 L330.92,195.16 L331.85,195.73 L332.79,196.29 L333.72,196.83 L334.65,197.37 L335.58,197.90 L336.51,198.41 L337.45,198.92 L338.38,199.41 L339.31,199.90 L340.24,200.37 L341.18,200.84 L342.11,201.30 L343.04,201.75 L343.97,202.18 L344.90,202.61 L345.84,203.03 L346.77,203.45 L347.70,203.85 L348.63,204.25 L349.57,204.63 L350.50,205.01 L351.43,205.38 L352.36,205.74 L353.30,206.10 L354.23,206.44 L355.16,206.78 L356.09,207.12 L357.02,207.44 L357.96,207.76 L358.89,208.07 L359.82,208.37 L360.75,208.67 L361.69,208.96 L362.62,209.24 L363.55,209.52 L364.48,209.79 L365.41,210.05 L366.35,210.31 L367.28,210.56 L368.21,210.81 L369.14,211.05 L370.08,211.29 L371.01,211.51 L371.94,211.74 L372.87,211.96 L373.80,212.17 L374.74,212.38 L375.67,212.58 L376.60,212.78 L377.53,212.97 L378.47,213.16 L379.40,213.35 L380.33,213.53 L381.26,213.70 L382.19,213.87 L383.13,214.04 L384.06,214.20 L384.99,214.36 L385.92,214.52 L386.86,214.67 L387.79,214.81 L388.72,214.96 L389.65,215.10 L390.59,215.23 L391.52,215.37 L392.45,215.50 L393.38,215.62 L394.31,215.74 L395.25,215.86 L396.18,215.98 L397.11,216.09 L398.04,216.20 L398.98,216.31 L399.91,216.42 L400.84,216.52 L401.77,216.62 L402.70,216.71 L403.64,216.81 L404.57,216.90 L405.50,216.99 L406.43,217.07 L407.37,217.16 L408.30,217.24 L409.23,217.32 L410.16,217.40 L411.09,217.47 L412.03,217.55 L412.96,217.62 L413.89,217.69 L414.82,217.76 L415.76,217.82 L416.69,217.89 L417.62,217.95 L418.55,218.01 L419.49,218.07 L420.42,218.13 L421.35,218.18 L422.28,218.24 L423.21,218.29 L424.15,218.34 L425.08,218.39 L426.01,218.44 L426.94,218.48 L427.88,218.53 L428.81,218.57 L429.74,218.62 L430.67,218.66 L431.60,218.70 L432.54,218.74 L433.47,218.78 L434.40,218.81 L435.33,218.85 L436.27,218.89 L437.20,218.92 L438.13,218.95 L439.06,218.98 L439.99,219.02 L440.93,219.05 L441.86,219.08 L442.79,219.10 L443.72,219.13 L444.66,219.16 L445.59,219.18 L446.52,219.21 L447.45,219.23 L448.38,219.26 L449.32,219.28 L450.25,219.30 L451.18,219.33 L452.11,219.35 L453.05,219.37 L453.98,219.39 L454.91,219.41 L455.84,219.43 L456.77,219.44 L457.71,219.46 L458.64,219.48 L459.57,219.49 L460.50,219.51 L461.44,219.53 L462.37,219.54 L463.30,219.56 L464.23,219.57 L465.17,219.58 L466.10,219.60 L467.03,219.61 L467.96,219.62 L468.89,219.63 L469.83,219.65 L470.76,219.66 L471.69,219.67 L472.62,219.68 L473.56,219.69 L474.49,219.70 L475.42,219.71 L476.35,219.72 L477.28,219.73 L478.22,219.74 L479.15,219.75 L480.08,219.75 L481.01,219.76 L481.95,219.77 L482.88,219.78 L483.81,219.78 L484.74,219.79 L485.67,219.80 L486.61,219.80 L487.54,219.81 L488.47,219.82 L489.40,219.82 L490.34,219.83 L491.27,219.83 L492.20,219.84 L493.13,219.85 L494.06,219.85 L495.00,219.86 L495.93,219.86 L496.86,219.87 L497.79,219.87 L498.73,219.87 L499.66,219.88 L500.59,219.88 L501.52,219.89 L502.46,219.89 L503.39,219.89 L504.32,219.90 L505.25,219.90 L506.18,219.90 L507.12,219.91 L508.05,219.91 L508.98,219.91 L509.91,219.92 L510.85,219.92 L511.78,219.92 L512.71,219.92 L513.64,219.93 L514.57,219.93 L515.51,219.93 L516.44,219.93 L517.37,219.94 L518.30,219.94 L519.24,219.94 L520.17,219.94 L521.10,219.94 L522.03,219.95 L522.96,219.95 L523.90,219.95 L524.83,219.95 L525.76,219.95 L526.69,219.96 L527.63,219.96 L528.56,219.96 L529.49,219.96 L530.42,219.96 L531.36,219.96 L532.29,219.96 L533.22,219.96 L534.15,219.97 L535.08,219.97 L536.02,219.97 L536.95,219.97 L537.88,219.97 L538.81,219.97 L539.75,219.97 L540.68,219.97 L541.61,219.97 L542.54,219.98 L543.47,219.98 L544.41,219.98 L545.34,219.98 L546.27,219.98 L547.20,219.98 L548.14,219.98 L549.07,219.98 L550.00,219.98 L550.00,220.00 Z"/>
<path class="fig-curve" d="M55.00,220.00 L57.06,220.00 L59.12,220.00 L61.19,220.00 L63.25,220.00 L65.31,220.00 L67.38,220.00 L69.44,220.00 L71.50,220.00 L73.56,220.00 L75.62,219.99 L77.69,219.98 L79.75,219.96 L81.81,219.94 L83.88,219.89 L85.94,219.83 L88.00,219.74 L90.06,219.61 L92.12,219.43 L94.19,219.20 L96.25,218.90 L98.31,218.51 L100.38,218.03 L102.44,217.44 L104.50,216.72 L106.56,215.87 L108.62,214.85 L110.69,213.68 L112.75,212.32 L114.81,210.77 L116.88,209.02 L118.94,207.06 L121.00,204.89 L123.06,202.49 L125.12,199.88 L127.19,197.04 L129.25,193.99 L131.31,190.72 L133.38,187.25 L135.44,183.58 L137.50,179.72 L139.56,175.70 L141.62,171.51 L143.69,167.19 L145.75,162.74 L147.81,158.20 L149.88,153.57 L151.94,148.88 L154.00,144.15 L156.06,139.40 L158.12,134.66 L160.19,129.95 L162.25,125.29 L164.31,120.70 L166.38,116.20 L168.44,111.81 L170.50,107.56 L172.56,103.45 L174.62,99.51 L176.69,95.76 L178.75,92.19 L180.81,88.84 L182.88,85.70 L184.94,82.79 L187.00,80.12 L189.06,77.69 L191.12,75.52 L193.19,73.59 L195.25,71.92 L197.31,70.51 L199.38,69.35 L201.44,68.44 L203.50,67.79 L205.56,67.38 L207.62,67.22 L209.69,67.30 L211.75,67.60 L213.81,68.13 L215.88,68.87 L217.94,69.82 L220.00,70.97 L222.06,72.30 L224.12,73.81 L226.19,75.49 L228.25,77.33 L230.31,79.31 L232.38,81.43 L234.44,83.67 L236.50,86.03 L238.56,88.49 L240.62,91.04 L242.69,93.68 L244.75,96.39 L246.81,99.16 L248.88,101.99 L250.94,104.86 L253.00,107.77 L255.06,110.70 L257.12,113.66 L259.19,116.62 L261.25,119.60 L263.31,122.56 L265.38,125.52 L267.44,128.47 L269.50,131.39 L271.56,134.29 L273.62,137.15 L275.69,139.98 L277.75,142.78 L279.81,145.52 L281.88,148.23 L283.94,150.88 L286.00,153.48 L288.06,156.03 L290.12,158.52 L292.19,160.95 L294.25,163.32 L296.31,165.63 L298.38,167.88 L300.44,170.06 L302.50,172.19 L304.56,174.25 L306.62,176.24 L308.69,178.18 L310.75,180.05 L312.81,181.86 L314.88,183.60 L316.94,185.29 L319.00,186.91 L321.06,188.48 L323.13,189.98 L325.19,191.43 L327.25,192.82 L329.31,194.16 L331.38,195.44 L333.44,196.67 L335.50,197.85 L337.56,198.98 L339.62,200.06 L341.69,201.09 L343.75,202.08 L345.81,203.02 L347.88,203.92 L349.94,204.78 L352.00,205.60 L354.06,206.38 L356.13,207.13 L358.19,207.84 L360.25,208.51 L362.31,209.15 L364.38,209.76 L366.44,210.34 L368.50,210.89 L370.56,211.41 L372.62,211.90 L374.69,212.37 L376.75,212.81 L378.81,213.23 L380.88,213.63 L382.94,214.01 L385.00,214.36 L387.06,214.70 L389.12,215.02 L391.19,215.32 L393.25,215.60 L395.31,215.87 L397.38,216.12 L399.44,216.36 L401.50,216.59 L403.56,216.80 L405.62,217.00 L407.69,217.19 L409.75,217.36 L411.81,217.53 L413.88,217.69 L415.94,217.84 L418.00,217.97 L420.06,218.10 L422.12,218.23 L424.19,218.34 L426.25,218.45 L428.31,218.55 L430.38,218.65 L432.44,218.73 L434.50,218.82 L436.56,218.90 L438.62,218.97 L440.69,219.04 L442.75,219.10 L444.81,219.16 L446.88,219.22 L448.94,219.27 L451.00,219.32 L453.06,219.37 L455.12,219.41 L457.19,219.45 L459.25,219.49 L461.31,219.52 L463.38,219.56 L465.44,219.59 L467.50,219.62 L469.56,219.64 L471.62,219.67 L473.69,219.69 L475.75,219.71 L477.81,219.73 L479.88,219.75 L481.94,219.77 L484.00,219.79 L486.06,219.80 L488.12,219.82 L490.19,219.83 L492.25,219.84 L494.31,219.85 L496.37,219.86 L498.44,219.87 L500.50,219.88 L502.56,219.89 L504.62,219.90 L506.69,219.91 L508.75,219.91 L510.81,219.92 L512.88,219.93 L514.94,219.93 L517.00,219.94 L519.06,219.94 L521.12,219.94 L523.19,219.95 L525.25,219.95 L527.31,219.96 L529.38,219.96 L531.44,219.96 L533.50,219.97 L535.56,219.97 L537.62,219.97 L539.69,219.97 L541.75,219.97 L543.81,219.98 L545.88,219.98 L547.94,219.98 L550.00,219.98"/>
<path class="fig-guide" d="M326.3,220 L326.3,45"/><text class="fig-label" x="326.3" y="239">30.14</text>
</svg>
<figcaption>For a right-tailed 5% variance test with 19 degrees of freedom, rejection begins at $\chi^2_{0.05,19}=30.14$.</figcaption>
</figure>

### Interpreting the unequal tails

A chi-square distribution is not symmetric about its center, particularly at small degrees of freedom. Its graph begins at zero and has a long right tail. Therefore a two-sided 5% variance test does **not** have cutoffs of the form "plus or minus one number." Instead, the left boundary comes from the small chi-square percentile and the right boundary from the large chi-square percentile. Both are positive, and generally far apart.

Table IV on Final sheet page 6 labels each column by the **right-tail** probability $\alpha$ of the corresponding chi-square boundary. For example, with $\nu=19$, row 19 and column $0.050$ give $30.14$: only 5% of a chi-square distribution with 19 degrees of freedom lies to its right. For a 5% **right-tailed** test, reject above 30.14. In the same row, column $0.950$ gives $10.12$: only 5% lies **below** 10.12, so this is the 5% left-tail boundary. For a 5% **two-tailed** test, use row 19, column $0.025$ for the right boundary $32.85$, and column $0.975$ for the left boundary $8.91$.

:::theorem[Chi-square rejection criteria]
With $\chi^2_{a,\nu}$ denoting the value whose **right-tail** probability is $a$, the Final sheet page 2 rules are

$$
\begin{aligned}
H_1:\sigma^2\ne\sigma_0^2 &: \quad \chi_0^2>\chi^2_{\alpha/2,\,n-1}\ \text{or}\ \chi_0^2<\chi^2_{1-\alpha/2,\,n-1},\\
H_1:\sigma^2>\sigma_0^2 &: \quad \chi_0^2>\chi^2_{\alpha,\,n-1},\\
H_1:\sigma^2<\sigma_0^2 &: \quad \chi_0^2<\chi^2_{1-\alpha,\,n-1}.
\end{aligned}
$$

A printed subscript such as $\chi^2_{0.95,19}$ is **not** the 95th percentile; it is the boundary leaving 95% to the right and 5% to the left.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Chi square density with unequal two-sided rejection boundaries">
<path class="fig-axis" d="M50,220 L560,220 M55,45 L55,223"/>
<path class="fig-fill" d="M55.00,220.00 L55.00,220.00 L55.33,220.00 L55.67,220.00 L56.00,220.00 L56.34,220.00 L56.67,220.00 L57.00,220.00 L57.34,220.00 L57.67,220.00 L58.01,220.00 L58.34,220.00 L58.68,220.00 L59.01,220.00 L59.34,220.00 L59.68,220.00 L60.01,220.00 L60.35,220.00 L60.68,220.00 L61.01,220.00 L61.35,220.00 L61.68,220.00 L62.02,220.00 L62.35,220.00 L62.68,220.00 L63.02,220.00 L63.35,220.00 L63.69,220.00 L64.02,220.00 L64.36,220.00 L64.69,220.00 L65.02,220.00 L65.36,220.00 L65.69,220.00 L66.03,220.00 L66.36,220.00 L66.69,220.00 L67.03,220.00 L67.36,220.00 L67.70,220.00 L68.03,220.00 L68.36,220.00 L68.70,220.00 L69.03,220.00 L69.37,220.00 L69.70,220.00 L70.04,220.00 L70.37,220.00 L70.70,220.00 L71.04,220.00 L71.37,220.00 L71.71,220.00 L72.04,220.00 L72.37,220.00 L72.71,220.00 L73.04,220.00 L73.38,220.00 L73.71,220.00 L74.05,219.99 L74.38,219.99 L74.71,219.99 L75.05,219.99 L75.38,219.99 L75.72,219.99 L76.05,219.99 L76.38,219.99 L76.72,219.99 L77.05,219.98 L77.39,219.98 L77.72,219.98 L78.05,219.98 L78.39,219.98 L78.72,219.97 L79.06,219.97 L79.39,219.97 L79.73,219.96 L80.06,219.96 L80.39,219.96 L80.73,219.95 L81.06,219.95 L81.40,219.94 L81.73,219.94 L82.06,219.93 L82.40,219.93 L82.73,219.92 L83.07,219.91 L83.40,219.91 L83.73,219.90 L84.07,219.89 L84.40,219.88 L84.74,219.87 L85.07,219.86 L85.41,219.85 L85.74,219.84 L86.07,219.83 L86.41,219.81 L86.74,219.80 L87.08,219.78 L87.41,219.77 L87.74,219.75 L88.08,219.73 L88.41,219.72 L88.75,219.70 L89.08,219.68 L89.41,219.66 L89.75,219.63 L90.08,219.61 L90.42,219.58 L90.75,219.56 L91.09,219.53 L91.42,219.50 L91.75,219.47 L92.09,219.44 L92.42,219.41 L92.76,219.37 L93.09,219.33 L93.42,219.30 L93.76,219.26 L94.09,219.21 L94.43,219.17 L94.76,219.13 L95.09,219.08 L95.43,219.03 L95.76,218.98 L96.10,218.92 L96.43,218.87 L96.77,218.81 L97.10,218.75 L97.43,218.69 L97.77,218.62 L98.10,218.56 L98.44,218.49 L98.77,218.42 L99.10,218.34 L99.44,218.26 L99.77,218.18 L100.11,218.10 L100.44,218.02 L100.78,217.93 L101.11,217.84 L101.44,217.74 L101.78,217.64 L102.11,217.54 L102.45,217.44 L102.78,217.33 L103.11,217.22 L103.45,217.11 L103.78,216.99 L104.12,216.87 L104.45,216.74 L104.78,216.61 L105.12,216.48 L105.45,216.34 L105.79,216.20 L106.12,216.06 L106.46,215.91 L106.79,215.76 L107.12,215.61 L107.46,215.45 L107.79,215.28 L108.13,215.11 L108.46,214.94 L108.79,214.76 L109.13,214.58 L109.46,214.40 L109.80,214.21 L110.13,214.01 L110.46,213.81 L110.80,213.61 L111.13,213.40 L111.47,213.18 L111.80,212.96 L112.14,212.74 L112.47,212.51 L112.80,212.28 L113.14,212.04 L113.47,211.80 L113.81,211.55 L114.14,211.29 L114.47,211.04 L114.81,210.77 L115.14,210.50 L115.48,210.23 L115.81,209.95 L116.14,209.66 L116.48,209.37 L116.81,209.07 L117.15,208.77 L117.48,208.46 L117.82,208.15 L118.15,207.83 L118.48,207.51 L118.82,207.18 L119.15,206.84 L119.49,206.50 L119.82,206.16 L120.15,205.80 L120.49,205.44 L120.82,205.08 L121.16,204.71 L121.49,204.34 L121.83,203.95 L122.16,203.57 L122.49,203.17 L122.83,202.78 L123.16,202.37 L123.50,201.96 L123.83,201.55 L124.16,201.12 L124.50,200.70 L124.83,200.26 L125.17,199.82 L125.50,199.38 L125.83,198.93 L126.17,198.47 L126.50,198.01 L126.84,197.54 L127.17,197.07 L127.51,196.59 L127.84,196.10 L128.17,195.61 L128.51,195.11 L128.84,194.61 L129.18,194.10 L129.51,193.59 L129.84,193.07 L130.18,192.55 L130.51,192.01 L130.85,191.48 L131.18,190.94 L131.51,190.39 L131.85,189.84 L132.18,189.28 L132.52,188.72 L132.85,188.15 L133.19,187.58 L133.52,187.00 L133.85,186.42 L134.19,185.83 L134.52,185.23 L134.86,184.63 L135.19,184.03 L135.19,220.00 Z"/>
<path class="fig-fill-alt" d="M350.65,220.00 L350.65,205.07 L351.48,205.40 L352.31,205.72 L353.14,206.04 L353.97,206.35 L354.80,206.66 L355.63,206.95 L356.46,207.25 L357.30,207.53 L358.13,207.81 L358.96,208.09 L359.79,208.36 L360.62,208.63 L361.45,208.88 L362.28,209.14 L363.11,209.39 L363.94,209.63 L364.77,209.87 L365.60,210.11 L366.43,210.33 L367.26,210.56 L368.09,210.78 L368.92,210.99 L369.75,211.21 L370.58,211.41 L371.42,211.61 L372.25,211.81 L373.08,212.00 L373.91,212.19 L374.74,212.38 L375.57,212.56 L376.40,212.74 L377.23,212.91 L378.06,213.08 L378.89,213.25 L379.72,213.41 L380.55,213.57 L381.38,213.73 L382.21,213.88 L383.04,214.03 L383.88,214.17 L384.71,214.31 L385.54,214.45 L386.37,214.59 L387.20,214.72 L388.03,214.85 L388.86,214.98 L389.69,215.10 L390.52,215.22 L391.35,215.34 L392.18,215.46 L393.01,215.57 L393.84,215.68 L394.67,215.79 L395.50,215.90 L396.33,216.00 L397.16,216.10 L398.00,216.20 L398.83,216.29 L399.66,216.39 L400.49,216.48 L401.32,216.57 L402.15,216.66 L402.98,216.74 L403.81,216.82 L404.64,216.91 L405.47,216.99 L406.30,217.06 L407.13,217.14 L407.96,217.21 L408.79,217.28 L409.62,217.35 L410.46,217.42 L411.29,217.49 L412.12,217.56 L412.95,217.62 L413.78,217.68 L414.61,217.74 L415.44,217.80 L416.27,217.86 L417.10,217.91 L417.93,217.97 L418.76,218.02 L419.59,218.08 L420.42,218.13 L421.25,218.18 L422.08,218.22 L422.91,218.27 L423.75,218.32 L424.58,218.36 L425.41,218.41 L426.24,218.45 L427.07,218.49 L427.90,218.53 L428.73,218.57 L429.56,218.61 L430.39,218.65 L431.22,218.68 L432.05,218.72 L432.88,218.75 L433.71,218.79 L434.54,218.82 L435.37,218.85 L436.20,218.88 L437.04,218.91 L437.87,218.94 L438.70,218.97 L439.53,219.00 L440.36,219.03 L441.19,219.05 L442.02,219.08 L442.85,219.11 L443.68,219.13 L444.51,219.15 L445.34,219.18 L446.17,219.20 L447.00,219.22 L447.83,219.24 L448.66,219.27 L449.49,219.29 L450.32,219.31 L451.16,219.32 L451.99,219.34 L452.82,219.36 L453.65,219.38 L454.48,219.40 L455.31,219.41 L456.14,219.43 L456.97,219.45 L457.80,219.46 L458.63,219.48 L459.46,219.49 L460.29,219.51 L461.12,219.52 L461.95,219.53 L462.78,219.55 L463.62,219.56 L464.45,219.57 L465.28,219.59 L466.11,219.60 L466.94,219.61 L467.77,219.62 L468.60,219.63 L469.43,219.64 L470.26,219.65 L471.09,219.66 L471.92,219.67 L472.75,219.68 L473.58,219.69 L474.41,219.70 L475.24,219.71 L476.07,219.72 L476.90,219.72 L477.74,219.73 L478.57,219.74 L479.40,219.75 L480.23,219.75 L481.06,219.76 L481.89,219.77 L482.72,219.78 L483.55,219.78 L484.38,219.79 L485.21,219.79 L486.04,219.80 L486.87,219.81 L487.70,219.81 L488.53,219.82 L489.36,219.82 L490.20,219.83 L491.03,219.83 L491.86,219.84 L492.69,219.84 L493.52,219.85 L494.35,219.85 L495.18,219.86 L496.01,219.86 L496.84,219.87 L497.67,219.87 L498.50,219.87 L499.33,219.88 L500.16,219.88 L500.99,219.88 L501.82,219.89 L502.65,219.89 L503.48,219.89 L504.32,219.90 L505.15,219.90 L505.98,219.90 L506.81,219.91 L507.64,219.91 L508.47,219.91 L509.30,219.91 L510.13,219.92 L510.96,219.92 L511.79,219.92 L512.62,219.92 L513.45,219.93 L514.28,219.93 L515.11,219.93 L515.94,219.93 L516.78,219.94 L517.61,219.94 L518.44,219.94 L519.27,219.94 L520.10,219.94 L520.93,219.94 L521.76,219.95 L522.59,219.95 L523.42,219.95 L524.25,219.95 L525.08,219.95 L525.91,219.95 L526.74,219.96 L527.57,219.96 L528.40,219.96 L529.23,219.96 L530.06,219.96 L530.90,219.96 L531.73,219.96 L532.56,219.96 L533.39,219.97 L534.22,219.97 L535.05,219.97 L535.88,219.97 L536.71,219.97 L537.54,219.97 L538.37,219.97 L539.20,219.97 L540.03,219.97 L540.86,219.97 L541.69,219.97 L542.52,219.98 L543.36,219.98 L544.19,219.98 L545.02,219.98 L545.85,219.98 L546.68,219.98 L547.51,219.98 L548.34,219.98 L549.17,219.98 L550.00,219.98 L550.00,220.00 Z"/>
<path class="fig-curve" d="M55.00,220.00 L57.06,220.00 L59.12,220.00 L61.19,220.00 L63.25,220.00 L65.31,220.00 L67.38,220.00 L69.44,220.00 L71.50,220.00 L73.56,220.00 L75.62,219.99 L77.69,219.98 L79.75,219.96 L81.81,219.94 L83.88,219.89 L85.94,219.83 L88.00,219.74 L90.06,219.61 L92.12,219.43 L94.19,219.20 L96.25,218.90 L98.31,218.51 L100.38,218.03 L102.44,217.44 L104.50,216.72 L106.56,215.87 L108.62,214.85 L110.69,213.68 L112.75,212.32 L114.81,210.77 L116.88,209.02 L118.94,207.06 L121.00,204.89 L123.06,202.49 L125.12,199.88 L127.19,197.04 L129.25,193.99 L131.31,190.72 L133.38,187.25 L135.44,183.58 L137.50,179.72 L139.56,175.70 L141.62,171.51 L143.69,167.19 L145.75,162.74 L147.81,158.20 L149.88,153.57 L151.94,148.88 L154.00,144.15 L156.06,139.40 L158.12,134.66 L160.19,129.95 L162.25,125.29 L164.31,120.70 L166.38,116.20 L168.44,111.81 L170.50,107.56 L172.56,103.45 L174.62,99.51 L176.69,95.76 L178.75,92.19 L180.81,88.84 L182.88,85.70 L184.94,82.79 L187.00,80.12 L189.06,77.69 L191.12,75.52 L193.19,73.59 L195.25,71.92 L197.31,70.51 L199.38,69.35 L201.44,68.44 L203.50,67.79 L205.56,67.38 L207.62,67.22 L209.69,67.30 L211.75,67.60 L213.81,68.13 L215.88,68.87 L217.94,69.82 L220.00,70.97 L222.06,72.30 L224.12,73.81 L226.19,75.49 L228.25,77.33 L230.31,79.31 L232.38,81.43 L234.44,83.67 L236.50,86.03 L238.56,88.49 L240.62,91.04 L242.69,93.68 L244.75,96.39 L246.81,99.16 L248.88,101.99 L250.94,104.86 L253.00,107.77 L255.06,110.70 L257.12,113.66 L259.19,116.62 L261.25,119.60 L263.31,122.56 L265.38,125.52 L267.44,128.47 L269.50,131.39 L271.56,134.29 L273.62,137.15 L275.69,139.98 L277.75,142.78 L279.81,145.52 L281.88,148.23 L283.94,150.88 L286.00,153.48 L288.06,156.03 L290.12,158.52 L292.19,160.95 L294.25,163.32 L296.31,165.63 L298.38,167.88 L300.44,170.06 L302.50,172.19 L304.56,174.25 L306.62,176.24 L308.69,178.18 L310.75,180.05 L312.81,181.86 L314.88,183.60 L316.94,185.29 L319.00,186.91 L321.06,188.48 L323.13,189.98 L325.19,191.43 L327.25,192.82 L329.31,194.16 L331.38,195.44 L333.44,196.67 L335.50,197.85 L337.56,198.98 L339.62,200.06 L341.69,201.09 L343.75,202.08 L345.81,203.02 L347.88,203.92 L349.94,204.78 L352.00,205.60 L354.06,206.38 L356.13,207.13 L358.19,207.84 L360.25,208.51 L362.31,209.15 L364.38,209.76 L366.44,210.34 L368.50,210.89 L370.56,211.41 L372.62,211.90 L374.69,212.37 L376.75,212.81 L378.81,213.23 L380.88,213.63 L382.94,214.01 L385.00,214.36 L387.06,214.70 L389.12,215.02 L391.19,215.32 L393.25,215.60 L395.31,215.87 L397.38,216.12 L399.44,216.36 L401.50,216.59 L403.56,216.80 L405.62,217.00 L407.69,217.19 L409.75,217.36 L411.81,217.53 L413.88,217.69 L415.94,217.84 L418.00,217.97 L420.06,218.10 L422.12,218.23 L424.19,218.34 L426.25,218.45 L428.31,218.55 L430.38,218.65 L432.44,218.73 L434.50,218.82 L436.56,218.90 L438.62,218.97 L440.69,219.04 L442.75,219.10 L444.81,219.16 L446.88,219.22 L448.94,219.27 L451.00,219.32 L453.06,219.37 L455.12,219.41 L457.19,219.45 L459.25,219.49 L461.31,219.52 L463.38,219.56 L465.44,219.59 L467.50,219.62 L469.56,219.64 L471.62,219.67 L473.69,219.69 L475.75,219.71 L477.81,219.73 L479.88,219.75 L481.94,219.77 L484.00,219.79 L486.06,219.80 L488.12,219.82 L490.19,219.83 L492.25,219.84 L494.31,219.85 L496.37,219.86 L498.44,219.87 L500.50,219.88 L502.56,219.89 L504.62,219.90 L506.69,219.91 L508.75,219.91 L510.81,219.92 L512.88,219.93 L514.94,219.93 L517.00,219.94 L519.06,219.94 L521.12,219.94 L523.19,219.95 L525.25,219.95 L527.31,219.96 L529.38,219.96 L531.44,219.96 L533.50,219.97 L535.56,219.97 L537.62,219.97 L539.69,219.97 L541.75,219.97 L543.81,219.98 L545.88,219.98 L547.94,219.98 L550.00,219.98"/>
<path class="fig-guide" d="M135.2,220 L135.2,45"/><text class="fig-label" x="135.2" y="239">8.91</text>
<path class="fig-guide" d="M350.7,220 L350.7,45"/><text class="fig-label" x="350.7" y="239">32.85</text>
</svg>
<figcaption>A two-sided 5% chi-square test uses asymmetric positive cutoffs $8.91$ and $32.85$ for 19 degrees of freedom, each excluding 2.5% in its own tail.</figcaption>
</figure>

### P-value bounds for chi-square

The chi-square table works like the t table in one respect: it shows selected probabilities, not a continuous mapping to exact p-values. Find your statistic in the appropriate degrees-of-freedom row, identify the nearest bracketing chi-square entries, and read the **right-tail** column headings. A larger chi-square statistic corresponds to a smaller right-tail probability. For a left-tailed test, subtract the right-tail probability from one. For a two-sided test, double whichever tail probability is **smaller**. Because the chi-square distribution is asymmetric, do not try to mirror a cutoff by negating it; negative chi-square values are impossible.

The variance test also has a stronger assumption than many broad-sample mean tests. Its exact chi-square reference distribution depends on an underlying normal population. The instructor explicitly states normality in the detergent-bottle exercise. A large sample does not automatically make an arbitrary variance statistic chi-square when that normality assumption is badly violated.

### What a nonrejection means for quality control

Consider a measured sample variance above the acceptable limit. That does **not** automatically prove a process variance above the limit. The sample variance fluctuates from sample to sample. A chi-square statistic slightly below the rejection cutoff means the evidence did not meet the selected false-alarm threshold. The correct conclusion is "insufficient evidence that the population variance exceeds the specification," not "there are no defective bottles" and not "the variance definitely equals the specification."

:::callout-pitfall[The right-tail table is not a cumulative-left table]
For Table IV, column $0.05$ marks the cutoff with **5% to the right**. For a left-tailed 5% test, use column $0.95$, not $0.05$. For a two-sided 5% test use columns $0.975$ and $0.025$. Another frequent mistake is dividing by the null **standard deviation** $\sigma_0$ instead of its variance $\sigma_0^2$.
:::

### Distinguish the three distribution choices

If the question asks about the mean and gives population $\sigma$, choose z. If it asks about the mean and gives only sample $s$ or sample $s^2$, choose t. If it asks about the population **variance**, choose chi-square and use the normal-population assumption. The distribution is dictated by the parameter and information supplied, not by whether the sample appears large. The physical units of the numerator are also a check: $\bar{x}-\mu_0$ and $s$ share units in a t statistic, while $s^2$ and $\sigma_0^2$ share squared units in a chi-square statistic.

:::example[Example 9.17 — Detergent bottles: unacceptable variability]
Unit 9 Exercise 6. An automated machine fills bottles with liquid detergent. A random sample of 20 bottles gives sample **variance** of fill volume 0.0153. If population variance exceeds 0.01, an unacceptable proportion of bottles will be underfilled or overfilled. Assuming a normal population, test at alpha 0.05 whether the manufacturer has a variability problem.

Numerical data: $n=20$, $s^2=0.0153$, $\sigma_0^2=0.01$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $29.07$; fail to reject $H_0$

1. **Parameter:** the population variance in detergent fill volume, $\sigma^2$.
2. **Null hypothesis:** $H_0:\sigma^2=0.01$, the specified variance boundary.
3. **Alternative hypothesis:** $H_1:\sigma^2>0.01$, because excessive variability is the stated production concern.
4. **Significance:** $\alpha=0.05$.
5. **Test statistic:** since the fill volumes are normally distributed, use $\chi_0^2=(n-1)s^2/\sigma_0^2$ from Final sheet page 2, with $\nu=20-1=19$.
6. **Rejection region:** $\chi_0^2>30.14$; Table IV, Final sheet page 6, row $19$, column $0.050$, gives $\chi^2_{0.05,19}=30.14$.
7. **Calculation:** $\chi_0^2=19(0.0153)/0.01=29.07$.
8. **Decision:** $29.07<30.14$, so fail to reject $H_0$ at the 5% significance level.

In context: Although the observed detergent fill variance exceeds 0.01, the statistic 29.07 does not cross the 5% critical value, so there is insufficient evidence to establish excessive population variability.
::::
:::

:::example[Example 9.18 — Detergent-test p-value bounds]
For the same detergent-filling problem, use the chi-square table to bound the **right-tailed** p-value. Do not quote a software-derived exact probability.

Numerical data: $n=20$, $s^2=0.0153$, $\sigma_0^2=0.01$.

::::answer[Answer]
**Answer:** $0.05 < p < 0.1$

1. The chi-square statistic is $\chi_0^2=(19)(0.0153)/0.01=29.070$ with $19$ degrees of freedom.
2. Use Table IV, Final sheet page 6, **row $19$**. The headings give areas to the RIGHT of a chi-square cutoff, not areas to the left.
3. Locate $29.070$ between the row entries $27.2$ (column $0.1$) and $30.14$ (column $0.05$), and read their headings. The one-sided tail area is bracketed by those headings; for a lower-tail test take complements, and for a two-sided test double the smaller tail.
4. The table reports bounds rather than a unique exact decimal. Thus $0.05 < p < 0.1$. Use the bounds, not an invented exact p-value, for the decision.

In context: The detergent variance-test p-value lies between 0.05 and 0.10, which corroborates failure to reject at 5% significance.
::::
:::

:::example[Example 9.19 — A smaller-than-target variance]
A normal process is designed to have variance 4 squared units. A random sample of 15 has sample variance 1.8. Test whether the population variance is less than 4 at alpha 0.05.

Numerical data: $n=15$, $s^2=1.8$, $\sigma_0^2=4$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $6.30$; reject $H_0$

1. Test $H_0:\sigma^2=4$ against the lower-tailed alternative. The significance level is $\alpha=0.05$. Normality is essential for the exact chi-square method.
2. Final sheet page 2 gives the statistic $\chi_0^2=(n-1)s^2/\sigma_0^2$. With $n=15$, degrees of freedom are $14$.
3. Table IV, Final sheet page 6, row $14$, uses upper-tail probability columns. The rejection region is below $6.57$ (right-tail column $0.025$ and left-tail column $0.975$ for two tails; for one tail use column $0.95$).
4. Calculate $(14)(1.8)/4=6.300$. We reject $H_0$. In context this says whether the process variability has statistically significant evidence of violating the target, not whether every product meets specifications.

In context: The statistic 6.30 lies in the lower chi-square rejection region, supporting evidence that the normal process has less than its proposed variance of 4.
::::
:::

:::problem[Problem 9.31 — Compute the variance statistic]{difficulty=easy}
A normal population is hypothesized to have variance 9. In 16 observations the sample variance is 12. Compute the chi-square statistic.

Numerical data: $n=16$, $s^2=12$, $\sigma_0^2=9$.

::::solution[Solution]
**Answer:** $20.000$

1. The target is the population variance, not the standard deviation. State the null as $H_0:\sigma^2=9$.
2. For a normal population, Final sheet pages 1 and 2 give $\chi_0^2=(n-1)s^2/\sigma_0^2$, with $\nu=n-1=15$ degrees of freedom.
3. Substitute $(16-1)(12)/9=20.000$.
4. A larger sample variance produces a larger right-tail chi-square statistic, but a smaller variance produces a left-tail value. The test never has a negative statistic.
::::
:::

:::problem[Problem 9.32 — Large spread at the 5% level]{difficulty=standard}
A normal process has target variance 2.0. For 20 parts the observed sample variance is 3.5. Test whether the true variance is **greater** at alpha .05.

Numerical data: $n=20$, $s^2=3.5$, $\sigma_0^2=2$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $33.25$; reject $H_0$

1. Test $H_0:\sigma^2=2$ against the upper-tailed alternative. The significance level is $\alpha=0.05$. Normality is essential for the exact chi-square method.
2. Final sheet page 2 gives the statistic $\chi_0^2=(n-1)s^2/\sigma_0^2$. With $n=20$, degrees of freedom are $19$.
3. Table IV, Final sheet page 6, row $19$, uses upper-tail probability columns. The rejection region is above $30.14$ (right-tail column $0.025$ and left-tail column $0.975$ for two tails; for one tail use column $0.05$).
4. Calculate $(19)(3.5)/2=33.250$. We reject $H_0$. In context this says whether the process variability has statistically significant evidence of violating the target, not whether every product meets specifications.
::::
:::

:::problem[Problem 9.33 — Variance has improved]{difficulty=standard}
A normal machine has null variance 4.0, sample size 20 and observed sample variance 2.0. Test whether population variability has **decreased** at alpha .05.

Numerical data: $n=20$, $s^2=2$, $\sigma_0^2=4$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $9.50$; reject $H_0$

1. Test $H_0:\sigma^2=4$ against the lower-tailed alternative. The significance level is $\alpha=0.05$. Normality is essential for the exact chi-square method.
2. Final sheet page 2 gives the statistic $\chi_0^2=(n-1)s^2/\sigma_0^2$. With $n=20$, degrees of freedom are $19$.
3. Table IV, Final sheet page 6, row $19$, uses upper-tail probability columns. The rejection region is below $10.12$ (right-tail column $0.025$ and left-tail column $0.975$ for two tails; for one tail use column $0.95$).
4. Calculate $(19)(2)/4=9.500$. We reject $H_0$. In context this says whether the process variability has statistically significant evidence of violating the target, not whether every product meets specifications.
::::
:::

:::problem[Problem 9.34 — Variance changed in either direction]{difficulty=standard}
A normal process has target variance 1.0. With sample size 20 and sample variance 1.9, test a two-sided alternative at alpha .05.

Numerical data: $n=20$, $s^2=1.9$, $\sigma_0^2=1$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $36.10$; reject $H_0$

1. Test $H_0:\sigma^2=1$ against the two-tailed alternative. The significance level is $\alpha=0.05$. Normality is essential for the exact chi-square method.
2. Final sheet page 2 gives the statistic $\chi_0^2=(n-1)s^2/\sigma_0^2$. With $n=20$, degrees of freedom are $19$.
3. Table IV, Final sheet page 6, row $19$, uses upper-tail probability columns. The rejection region is below $8.91$ or above $32.85$ (right-tail column $0.025$ and left-tail column $0.975$ for two tails; for one tail use column $0.95$).
4. Calculate $(19)(1.9)/1=36.100$. We reject $H_0$. In context this says whether the process variability has statistically significant evidence of violating the target, not whether every product meets specifications.
::::
:::

:::problem[Problem 9.35 — Variance statistic with small sample]{difficulty=easy}
Ten normal observations have sample variance 0.75 and target variance 0.50. Calculate chi-square with the correct degrees of freedom.

Numerical data: $n=10$, $s^2=0.75$, $\sigma_0^2=0.5$.

::::solution[Solution]
**Answer:** $13.500$

1. The target is the population variance, not the standard deviation. State the null as $H_0:\sigma^2=0.5$.
2. For a normal population, Final sheet pages 1 and 2 give $\chi_0^2=(n-1)s^2/\sigma_0^2$, with $\nu=n-1=9$ degrees of freedom.
3. Substitute $(10-1)(0.75)/0.5=13.500$.
4. A larger sample variance produces a larger right-tail chi-square statistic, but a smaller variance produces a left-tail value. The test never has a negative statistic.
::::
:::

:::problem[Problem 9.36 — Two-sided evidence from lower tail]{difficulty=challenge}
For a normal process with 15 observations, a proposed variance of 4 and sample variance 1.0, test whether variance differs in either direction at alpha 0.05.

Numerical data: $n=15$, $s^2=1$, $\sigma_0^2=4$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $3.50$; reject $H_0$

1. Test $H_0:\sigma^2=4$ against the two-tailed alternative. The significance level is $\alpha=0.05$. Normality is essential for the exact chi-square method.
2. Final sheet page 2 gives the statistic $\chi_0^2=(n-1)s^2/\sigma_0^2$. With $n=15$, degrees of freedom are $14$.
3. Table IV, Final sheet page 6, row $14$, uses upper-tail probability columns. The rejection region is below $5.63$ or above $26.12$ (right-tail column $0.025$ and left-tail column $0.975$ for two tails; for one tail use column $0.95$).
4. Calculate $(14)(1)/4=3.500$. We reject $H_0$. In context this says whether the process variability has statistically significant evidence of violating the target, not whether every product meets specifications.
::::
:::

## 9.7 P-values, confidence intervals, and consistent conclusions


A hypothesis test and a confidence interval use the same sampling logic in two complementary directions. The test asks whether one **specified** value of a parameter is sufficiently inconsistent with the data. The confidence interval reports a **range of parameter values** that remain compatible with the data at a chosen confidence level. For the two-sided mean tests in this course, they agree exactly when their tail allocations, model assumptions and standard errors match.

:::callout-intuition[One claimed value versus all plausible values]
Imagine trying a series of proposed mean values for the same ten student scores. Values close to the sample average will produce small t statistics and usually will not be rejected. Values far away will yield large t statistics and will be rejected. The collection of unrejected values at the 5% level is the 95% two-sided confidence interval. Rather than run dozens of separate tests, the interval shows the whole accepted range at once.
:::

:::theorem[Test–confidence-interval equivalence]
For a **two-sided** test of $H_0:\mu=\mu_0$ at significance $\alpha$, using the same z or t model as a two-sided $(1-\alpha)100\%$ confidence interval, reject $H_0$ precisely when the proposed $\mu_0$ lies **outside** the interval. Fail to reject when it lies inside, with boundary equality handled consistently with the chosen rejection rule. This follows by rearranging the same statistic inequality.
:::

### Why the algebra agrees

A two-sided z test rejects if $|(\bar{x}-\mu_0)/(\sigma/\sqrt n)|>z_{\alpha/2}$. Multiply both sides by the positive standard error $\sigma/\sqrt n$. This becomes $|\bar{x}-\mu_0|>z_{\alpha/2}\sigma/\sqrt n$. That says the null mean is farther from the sample mean than the interval's margin of error. Equivalently, it lies outside $[\bar{x}-z_{\alpha/2}\sigma/\sqrt n,\bar{x}+z_{\alpha/2}\sigma/\sqrt n]$. The t argument is identical with $t_{\alpha/2,n-1}$ and $s/\sqrt n$. The confidence-interval formulas are printed on **Final sheet page 2**, directly above the hypothesis-testing material.

The direction is important. A 95% **two-sided** confidence interval matches a two-sided test at $\alpha=0.05$. A 95% **one-sided** upper confidence bound does not match the same two-sided rejection region; it corresponds to a particular one-sided question. Do not compare a two-sided test against a one-sided bound and expect the threshold to agree. The instructor covers the one-sided confidence-bound construction in Chapter 8; here it is enough to recognize the matching test direction.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 600 275" width="600" height="275" role="img" aria-label="Horizontal confidence interval from 69.52 to 84.08 with null 85 beyond right endpoint">
<path class="fig-axis" d="M55,200 L550,200"/><path class="fig-curve" d="M144.5,145 L432.8,145"/><path class="fig-guide" d="M144.5,123 L144.5,162"/><text class="fig-label" x="144.5" y="177">69.52</text><path class="fig-guide" d="M432.8,123 L432.8,162"/><text class="fig-label" x="432.8" y="177">84.08</text><path class="fig-point" d="M447.0,201 a4,4 0 1,0 8,0 a4,4 0 1,0 -8,0"/><text class="fig-label-em" x="451.0" y="221">null 85</text>
</svg>
<figcaption>The proposed mean $85$ is outside the Calculus II scores’ 95% confidence interval $[69.52,84.08]$, so the matching two-sided 5% t-test rejects it.</figcaption>
</figure>

### Two routes through the same Calculus II scores

The ten exam scores in Exam 3 practice Problems 4 and 5 have mean $76.8$ and sample standard deviation approximately $10.1740$. The two-sided $t$ test against $H_0:\mu=85$ has $t_0\approx-2.55$ with 9 degrees of freedom. Table V gives $t_{0.025,9}=2.262$. The 95% confidence interval is approximately $76.8\pm2.262(10.1740/\sqrt{10})$, or $(69.52,84.08)$. Since 85 lies **above** the upper endpoint, the interval rejects 85 in the corresponding two-sided 5% test. You do not have to run a separate hypothesis test if the question only asks what decision the existing interval implies.

The same test's p-value can be bounded using row 9 of the t table. The magnitude $2.55$ is greater than $2.262$ (column $0.025$) but less than $2.821$ (column $0.01$). The one-tail probability is between $0.01$ and $0.025$, and the two-sided p-value is between $0.02$ and $0.05$. Hence the result is significant at $0.05$. The direction and interval confirm that the observed evidence is for a lower mean than 85, even though the alternative allowed changes either way.

:::definition[Definition 9.7 — p-value and significance]
The **p-value**, as stated in the Unit 9 notes, is the **smallest significance level** that would lead to rejection of $H_0$ with the observed sample. A result is statistically significant at a specified $\alpha$ when $p\le\alpha$ under the test's decision convention. The p-value is calculated assuming the null model, and it does not assign a probability of truth to either hypothesis.
:::

### How to answer an exam item quickly and completely

Read the words "sample variance" and "population variance" as different objects. Read the words "greater than" and "different from" as different test directions. Then identify which table is needed. A mean with known population sigma requires a z statistic and the cumulative normal table; the Final sheet gives an explicit p-value formula for it. A mean with unknown population sigma requires t and the table yields p-value **bounds**. A variance test requires chi-square and the table again yields **bounds**. Finish with one complete sentence: "At significance 0.05, we reject the null hypothesis and have evidence that the population mean differs from the target," or "we fail to reject and do not have sufficient evidence of an increase in population variance."

:::callout-pitfall[Two matching methods, not two unrelated answers]
A two-sided 95% interval excluding the hypothesized mean and a two-sided 5% test that **fails** to reject cannot both be right if they use the same data and distribution. Check your standard error, degrees of freedom, and tail allocation. Another frequent error is interpreting a p-value as $P(H_0\text{ true}\mid\text{data})$; the definition actually conditions the sampling calculation on the null hypothesis being true.
:::

### Make the statistical meaning precise

A confidence interval's endpoints come from random samples, but the population mean is fixed. The instructor's required wording is "we are 95% confident the interval contains the true mean." Do **not** say that the fixed mean has a 95% probability of moving into this already calculated interval. Likewise, a test at 5% significance describes a repeated-sampling false-rejection frequency when the null is true. It does not mean there is a 95% probability the final conclusion is correct. Both procedures control an aspect of long-run inference, not a posterior probability that the current verbal claim is true.

:::example[Example 9.20 — Calculus II test and 95% interval]
Exam 3 practice Problem 4 asks for the hypothesis-test conclusion using the interval from its earlier confidence-interval question. With scores 82, 77, 71, 60, 89, 93, 73, 74, 83, 66, sample mean 76.8, sample standard deviation 10.1740 and target mean 85, compute the 95% t confidence interval endpoints and explain the test decision at 0.05.

Numerical data: $\mu_0=85$, $n=10$, $\bar{x}=76.8$, $s=10.174041$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $69.52$ to $84.08$

1. The population standard deviation is not known, so use the two-sided $t$ confidence interval on Final sheet page 2. The degrees of freedom equal $9$.
2. Table V on Final sheet page 5, row $9$ and column $0.025$, gives $t=2.262$.
3. Compute the margin $t s/\sqrt n=2.262(10.1740/\sqrt{10})=7.278$. Subtract it from $76.8$ for $69.52$ and add it for $84.08$.
4. The null claims $\mu=85$. Since the value is outside this two-sided interval, the corresponding test rejects at this significance level. We are 95% confident the interval contains the true mean.

In context: For the Calculus II final scores, the proposed population mean 85 is above the interval’s upper endpoint 84.08, so the corresponding 5% two-sided mean test rejects.
::::
:::

:::example[Example 9.21 — A 5% mean test recast as an interval]
A normal-process mean is tested against 100 with unknown sigma. The engineer measures 16 parts, observing sample mean 101.0 and sample standard deviation 2.0. Find the **upper** endpoint of the corresponding 95% confidence interval and say whether 100 is included.

Numerical data: $\mu_0=100$, $n=16$, $\bar{x}=101$, $s=2$, $\alpha=0.05$.

::::answer[Answer]
**Answer:** $102.07$

1. The matching two-sided $95\%$ confidence interval uses $t_{0.025,15}$ from Table V, Final sheet page 5. Row $15$, column $0.025$ gives $2.131$.
2. The upper endpoint is $\bar{x}+t_{0.025,15}s/\sqrt n=101+2.131(2.0000/\sqrt{16})=102.07$.
3. For $H_0:\mu=100$ against a two-sided alternative at $\alpha=.05$, compare the claimed mean with the whole interval, not just the endpoint.
4. If the proposed mean lies outside, reject the null. The test and the interval agree because they use the same statistic and same $5\%$ error allocation.

In context: The computed upper endpoint 102.07 is paired with a lower endpoint near 99.93, which includes the proposed mean 100 and therefore does not reject the two-sided null.
::::
:::

:::problem[Problem 9.37 — Standard-error logic]{difficulty=easy}
With 10 normal observations, sample mean 76.8 and sample standard deviation 10.1740, target mean 85, compute the two-sided test statistic that drives the confidence-interval comparison.

Numerical data: $\mu_0=85$, $n=10$, $\bar{x}=76.8$, $s=10.174041$.

::::solution[Solution]
**Answer:** $-2.549$

1. The population variance is not supplied. Recover the sample standard deviation as $s=\sqrt{103.51}=10.1740$ when a variance is given.
2. Use $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$ from Final sheet page 2, with $\nu=n-1=9$ degrees of freedom.
3. Direct substitution gives $(76.8-85)/(10.1740/\sqrt{10})\approx-2.549$.
4. The statistic expresses the deviation in *estimated* standard errors. A $t$ table, rather than the $z$ table, supplies the critical comparison.
::::
:::

:::problem[Problem 9.38 — A high p-value]{difficulty=standard}
A mean test of 5 volts uses known sigma 0.25 volts and sample size 8. An observed mean of 5.02 is used in a two-sided test. Compute its normal-table p-value and state whether it is significant at 0.05.

Numerical data: $\mu_0=5$, $n=8$, $\bar{x}=5.02$, $\sigma=0.25$.

::::solution[Solution]
**Answer:** $0.8181$

1. The standardized test statistic is $z_0=(5.02-5)/(0.25/\sqrt{8})=0.226$. Round to $0.23$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $0.2$ and column $0.03$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(0.23)=0.590954$.
3. Final sheet page 2 says $p=2[1-\Phi(|z_0|)]$. Substitute the cumulative area to obtain $p\approx 0.8181$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.
::::
:::

:::problem[Problem 9.39 — An interval excludes a design mean]{difficulty=standard}
A normal sample of 20 parts has mean 30.5, sample standard deviation 1.0 and tested null mean 30, alpha 0.05. Find the 95% t interval, and infer the matching two-sided test result.

Numerical data: $\mu_0=30$, $n=20$, $\bar{x}=30.5$, $s=1$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $30.03$ to $30.97$

1. The population standard deviation is not known, so use the two-sided $t$ confidence interval on Final sheet page 2. The degrees of freedom equal $19$.
2. Table V on Final sheet page 5, row $19$ and column $0.025$, gives $t=2.093$.
3. Compute the margin $t s/\sqrt n=2.093(1.0000/\sqrt{20})=0.468$. Subtract it from $30.5$ for $30.03$ and add it for $30.97$.
4. The null claims $\mu=30$. Since the value is outside this two-sided interval, the corresponding test rejects at this significance level. We are 95% confident the interval contains the true mean.
::::
:::

:::problem[Problem 9.40 — One-sided p versus two-sided p]{difficulty=standard}
A machine mean is compared against 10, known sigma 2, n=25, observed mean 10.8. Find the **upper-tailed** normal p-value; explain why a two-sided p-value would be double.

Numerical data: $\mu_0=10$, $n=25$, $\bar{x}=10.8$, $\sigma=2$.

::::solution[Solution]
**Answer:** $0.0227$

1. The standardized test statistic is $z_0=(10.8-10)/(2/\sqrt{25})=2.000$. Round to $2.00$ for the sheet’s normal table.
2. In Table III, Final sheet pages 3–4, use row $2.0$ and column $0.00$; on the negative page its column labels run $-0.09$ through $-0.00$. The cumulative area is $\Phi(2.00)=0.977250$.
3. Final sheet page 2 says $p=1-\Phi(z_0)$. Substitute the cumulative area to obtain $p\approx 0.0227$.
4. The p-value measures how unusual evidence at least this extreme would be if the null mean were true, not the chance the null hypothesis is true.
::::
:::

:::problem[Problem 9.41 — The matching t cutoff]{difficulty=easy}
For 10 observations from a normal population of unknown sigma, a two-sided test is conducted at alpha 0.05. Find the positive critical t value from Table V, and explain which matching confidence interval it corresponds to.

Numerical data: $n=10$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $2.262$

1. A normal population with unknown standard deviation leads to a t reference distribution, with degrees of freedom $\nu=n-1=9$.
2. This is a two-tailed test with significance 0.05, so divide the area equally between both tails.
3. Table V on Final sheet page 5, row $9$ and column $0.025$, gives the positive boundary $t=2.262$.
4. This same boundary appears in the matching two-sided confidence interval when the alternative is two-sided. It is a test cutoff, not a calculated sample statistic.
::::
:::

:::problem[Problem 9.42 — Rejection just outside an interval]{difficulty=challenge}
For a normal sample of 10 with mean 50 and standard deviation 1.8, compare the two-sided 95% interval with null mean 51.4. Calculate the endpoints and test decision.

Numerical data: $\mu_0=51.4$, $n=10$, $\bar{x}=50$, $s=1.8$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** $48.71$ to $51.29$

1. The population standard deviation is not known, so use the two-sided $t$ confidence interval on Final sheet page 2. The degrees of freedom equal $9$.
2. Table V on Final sheet page 5, row $9$ and column $0.025$, gives $t=2.262$.
3. Compute the margin $t s/\sqrt n=2.262(1.8000/\sqrt{10})=1.288$. Subtract it from $50$ for $48.71$ and add it for $51.29$.
4. The null claims $\mu=51.4$. Since the value is outside this two-sided interval, the corresponding test rejects at this significance level. We are 95% confident the interval contains the true mean.
::::
:::

## Chapter Summary

:::summary[Chapter 9 — The exam-ready framework]
A hypothesis test asks whether a sample supplies sufficiently unusual evidence against a **population** benchmark. Use $H_0$ for the equality, choose $H_1$ as greater than, less than, or different from the benchmark, specify $\alpha$, identify the statistic, state the rejection region, calculate, and make the reject/fail-to-reject decision in context. The full **eight steps** and all three rejection tables are printed on **Final sheet page 2**.

For a mean with **known population $\sigma$**, use $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ and Table III. For a mean with **unknown population $\sigma$**, use $t_0=(\bar{x}-\mu_0)/(s/\sqrt n)$ and Table V with $n-1$ degrees of freedom. For a **normal-population variance**, use $\chi_0^2=(n-1)s^2/\sigma_0^2$ and Table IV with $n-1$ degrees of freedom. These formulas appear on **Final sheet pages 1–2**; the z, t and chi-square tables appear on **pages 3–4, 5 and 6**, respectively.

A **two-sided** alternative splits $\alpha$ between two tails; a **one-sided** alternative uses all of $\alpha$ in one tail. The standard-normal table reports area to the **left**; the t and chi-square critical-value tables report **right-tail** areas. For the z p-value, use the explicit page-2 formula. For the t and chi-square p-values, bound the probability between available table headings. Report the p-value **alongside** the decision and significance level.

Type I error is rejecting a true null, with probability $\alpha$. Type II error is failing to reject a false null, with probability $\beta$ at a specified actual parameter. Power is $1-\beta$. For a sample-mean acceptance interval, calculate the area **inside** under the null to find $1-\alpha$, or inside under a specified alternative to find $\beta$. The two-sided beta and sample-size planning formulas appear on **Final sheet page 2**. For two-sided sample-size planning use $z_{\alpha/2}$ and check the resulting integer sample size's actual power.

At the same $\alpha$ and under the same model, a **two-sided** hypothesis test rejects a proposed mean precisely when that mean lies outside the corresponding $(1-\alpha)$ confidence interval. Failing to reject never proves the null is true. A p-value is not the probability that the null hypothesis is true.
:::

## Mixed Practice

These items use the structure of the comprehensive final: true/false in parts, matching, and multiple choice. The numeric choices are designed around common wrong-tail, wrong-statistic, wrong-degrees-of-freedom and wrong-error-probability mistakes. Attempt the questions using only the Final sheet before opening the answers. The mixed order matters: the first step is deciding **which kind of problem** it is, not recognizing a nearby formula.

:::problem[Problem M.1 — True or false: three statements]{difficulty=easy}
Classify all three statements: (a) A significance level of 0.05 is the probability the null is true. (b) Failing to reject a null means it has been proved. (c) A Type II error occurs when a false null is not rejected. State the truth values in order and defend each.

::::solution[Solution]
**Answer:** False, false, true.

1. Statement (a) is false. A 5% significance level is the long-run probability of rejecting when the null is true; it is **not** the conditional probability that the null itself is true.
2. Statement (b) is false. Nonrejection means the evidence was insufficient, not that the benchmark was established.
3. Statement (c) is true by the definition of Type II error: a false null remains unrejected.
4. The false-alarm definition is Type I, whereas detecting a false null is power.
::::
:::

:::problem[Problem M.2 — Match four terms]{difficulty=easy}
Match the four terms (I) $lpha$, (II) $eta$, (III) power, (IV) p-value with the definitions (A) probability of rejecting a true null, (B) probability of not rejecting a false null, (C) probability of detecting a specified false null, (D) smallest significance level at which the observed result rejects. Give the letter sequence and justify it.

::::solution[Solution]
**Answer:** I–A, II–B, III–C, IV–D.

1. Alpha is the probability of rejecting a **true** null hypothesis, so I matches A.
2. Beta is the probability of failing to reject a **false** null at the specified true parameter, so II matches B.
3. Power is $1-\beta$, the probability of catching the specified false null; III matches C.
4. The p-value is the smallest significance level at which the actual sample rejects, so IV matches D. The four choices are not synonyms, despite all being probabilities about a test.
::::
:::

:::problem[Problem M.3 — MC: pick the test distribution]{difficulty=easy}
A sample of 15 normal golf-driver measurements has an **unknown** population standard deviation. Which distribution tests its mean? (A) z; (B) t with 14 degrees of freedom; (C) chi-square with 14 degrees of freedom; (D) t with 15 degrees of freedom.

::::solution[Solution]
**Answer:** (B) Student t distribution.

1. The question targets a population **mean**, not the variance.
2. The population standard deviation is unknown; this rules out the known-sigma z test.
3. There are 15 independent normal observations, so the t statistic has $n-1=14$ degrees of freedom.
4. Choose the t distribution with 14 degrees of freedom. The phrase "normal measurements" supports the small-sample t model, and the degrees of freedom must use the sample-size adjustment.

Distractors: (A) assumes known population sigma; (C) tests a variance, not a mean; (D) uses n rather than n−1 degrees of freedom.
::::
:::

:::problem[Problem M.4 — MC: rocket-propellant z statistic]{difficulty=standard}
The propellant problem has null mean 50 cm/s, known sigma 2 cm/s, sample size 25 and sample mean 51.3 cm/s. What is the z statistic? (A) 0.65; (B) 1.30; (C) 3.25; (D) 6.50.

Numerical data: $\mu_0=50$, $\sigma=2$, $n=25$, $\bar{x}=51.3$.

::::solution[Solution]
**Answer:** (C) $3.250$

1. Treat the known population standard deviation as $\sigma=2$, not as a sample estimate.
2. On Final sheet page 1 (also the rejection box on page 2), use $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$.
3. Substitute $(51.3-50)/(2/\sqrt{25})=3.250$. The sign shows which side of the proposed mean the sample lies.
4. A statistic this many standard errors from the null mean is the standardized evidence; it is not a probability and is not itself $\alpha$.

Distractors: (A) divides by sigma rather than its standard error; (B) ignores the square-root sample-size effect; (D) incorrectly doubles a statistic merely because the test is two-sided.
::::
:::

:::problem[Problem M.5 — MC: which error is missed overheating?]{difficulty=easy}
A detector tests whether a circuit meets its prescribed average temperature. The actual population mean is too high, but the detector does not reject its null claim. Which event occurred? (A) correct decision; (B) Type I error; (C) Type II error; (D) p-value equal to alpha.

::::solution[Solution]
**Answer:** (C) Type II error.

1. The circuit's actual mean is too high, so the null hypothesis that it meets the prescribed average is **false**.
2. The detector nevertheless fails to reject that null.
3. This is the definition of a Type II error.
4. Type I error would require the benchmark to be true and the detector to reject it instead. This distinction is about the true state and the test decision, not about whether an observed sample average was high or low.

Distractors: (A) is not correct because the true null is false; (B) requires a true null to be rejected; (D) is not a classification of this event.
::::
:::

:::problem[Problem M.6 — MC: calculate actual false alarms]{difficulty=standard}
A normal process has null mean 5, known sigma 0.25, n=8 and acceptance region 4.85 to 5.15 for the sample mean. What is alpha? (A) 0.05; (B) 0.0891; (C) 0.9109; (D) 0.2867.

Numerical data: $\mu_0=5$, $n=8$, $\sigma=0.25$, $L=4.85$, $U=5.15$.

::::solution[Solution]
**Answer:** (B) $0.0891$

1. The sample-mean standard error is $\sigma/\sqrt n=0.25/\sqrt{8}=0.08839$, from Final sheet page 1. The *acceptance region* is $4.85\leq\bar{X}\leq5.15$; points outside lead to rejection.
2. For Type I error, the null mean is true: 5. Convert the endpoints to $z$ values: $(4.85-5)/0.08839=-1.697$ and $(5.15-5)/0.08839=1.697$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-1.70)=0.044565$ and $\Phi(1.70)=0.955435$. Their difference, the probability *between* the limits, is $0.9109$.
4. Take one minus the acceptance probability because Type I error means rejecting a true null. Thus $\alpha=0.0891$. This is the long-run fraction of such tests with the specified outcome.

Distractors: (A) assumes a significance not given; (C) is the probability of acceptance under the null; (D) is power at a different actual mean.
::::
:::

:::problem[Problem M.7 — MC: t-table bounds]{difficulty=standard}
The Calculus II exam scores have n=10, sample mean 76.8, sample s=10.1740, null mean 85. The alternative is two-sided. Which p-value interval is supported by Table V? (A) 0.01 to 0.025; (B) 0.02 to 0.05; (C) 0.05 to 0.10; (D) greater than 0.50.

Numerical data: $\mu_0=85$, $n=10$, $\bar{x}=76.8$, $s=10.174041$.

::::solution[Solution]
**Answer:** (B) $0.02 < p < 0.05$

1. Form $t_0=(76.8-85)/(10.1740/\sqrt{10})=-2.549$, with $\nu=9$. Only the magnitude is used when bounding a two-sided p-value.
2. Table V on Final sheet page 5 has degrees of freedom along the left and **upper-tail area** across the top. In row $9$, the magnitude $2.549$ lies between the tabulated thresholds $2.262$ (column $0.025$) and $2.821$ (column $0.01$).
3. The upper-tail probability lies between the corresponding column headings. Double each tail area because this is a two-sided test. Thus $0.02 < p < 0.05$.
4. A table gives an interval, not a six-decimal p-value. Compare the entire interval with $\alpha$ when deciding whether to reject.

Distractors: (A) forgets to double the one-sided table probability; (C) picks the wrong adjacent t columns; (D) ignores the magnitude of the observed t statistic.
::::
:::

:::problem[Problem M.8 — MC: which tail for fill variance?]{difficulty=standard}
A manufacturer considers population variance above 0.01 unacceptable. For the normal process, which alternative and tail are correct? (A) $H_1:\sigma^2>0.01$, right chi-square tail; (B) $H_1:\mu>0.01$, right z tail; (C) $H_1:\sigma^2<0.01$, left chi-square tail; (D) $H_1:\sigma^2\ne0.01$, split both tails.

::::solution[Solution]
**Answer:** (A) Right-tailed chi-square variance test.

1. The manufacturing problem concerns **population variance**, so testing the population mean would target the wrong parameter.
2. The unacceptable condition is population variance **greater** than the specified limit.
3. Write $H_0:\sigma^2=0.01$, $H_1:\sigma^2>0.01$. For normal measurements, a large sample variance generates a large positive chi-square statistic.
4. Reject only in the right tail. No two-sided split is appropriate for the specified upper-limit question.

Distractors: (B) substitutes a mean for variance; (C) reverses the concern; (D) tests any change instead of the stated unacceptable increase.
::::
:::

:::problem[Problem M.9 — MC: detergent chi-square statistic]{difficulty=standard}
For n=20 normal detergent-bottle fills, sample variance 0.0153 and null variance 0.01, what is the chi-square statistic? (A) 1.53; (B) 29.07; (C) 30.14; (D) 19.00.

Numerical data: $n=20$, $s^2=0.0153$, $\sigma_0^2=0.01$.

::::solution[Solution]
**Answer:** (B) $29.070$

1. The target is the population variance, not the standard deviation. State the null as $H_0:\sigma^2=0.01$.
2. For a normal population, Final sheet pages 1 and 2 give $\chi_0^2=(n-1)s^2/\sigma_0^2$, with $\nu=n-1=19$ degrees of freedom.
3. Substitute $(20-1)(0.0153)/0.01=29.070$.
4. A larger sample variance produces a larger right-tail chi-square statistic, but a smaller variance produces a left-tail value. The test never has a negative statistic.

Distractors: (A) omits n−1; (C) is the right-tail critical value, not the calculated statistic; (D) is degrees of freedom only.
::::
:::

:::problem[Problem M.10 — MC: calculate power from beta]{difficulty=easy}
A test has Type II error probability 0.30 at a specified actual process mean. What is power? (A) 0.30; (B) 0.05; (C) 0.70; (D) 1.30.

Numerical data: $\beta=0.3$.

::::solution[Solution]
**Answer:** (C) $0.7000$

1. Power and Type II error are complementary outcomes when the specified alternative is the actual truth.
2. The definition in the Unit 9 notes is $\text{power}=1-\beta$. With $\beta=0.3$, evaluate $1-0.3=0.7000$.
3. This is the probability of rejecting an incorrect null hypothesis for this particular true mean.
4. A high value is desirable because it means the engineering test is more likely to detect a genuine problem rather than overlook it.

Distractors: (A) is beta, not power; (B) is an unrelated significance level; (D) adds instead of subtracting and is not a probability.
::::
:::

:::problem[Problem M.11 — MC: production weight conclusion]{difficulty=standard}
For nominal mean 16 ounces, known sigma 0.4 ounce, n=70 and observed mean 15.8 ounces, a two-sided test at alpha 0.05 gives which conclusion? (A) fail to reject because 15.8 is near 16; (B) reject because z is about −4.18; (C) use t because n is large; (D) use chi-square because weights vary.

Numerical data: $\mu_0=16$, $\sigma=0.4$, $n=70$, $\bar{x}=15.8$, $\alpha=0.05$.

::::solution[Solution]
**Answer:** (B) $-4.18$; reject $H_0$

1. The population mean is the parameter. Write $H_0:\mu=16$ and $H_1:\mu\ne16$. The significance level is $\alpha=0.05$.
2. Because the population standard deviation is known, choose $z_0=(\bar{x}-\mu_0)/(\sigma/\sqrt n)$ from Final sheet page 2. The two-tailed critical cutoff is $1.96$ from Table III (row $1.9$, column $0.06$ for $1.96$; other levels use the corresponding cumulative-area row and column) nearest cumulative area $0.975$.
3. Calculate $z_0=(15.8-16)/(0.4/\sqrt{70})=-4.183$.
4. Compare $-4.183$ with the specified rejection region. We reject $H_0$. This is a conclusion about evidence for the engineering claim; failing to reject would not prove an exact mean.

Distractors: (A) ignores the small standard error; (C) ignores that population sigma is known; (D) tests variance rather than the claimed mean.
::::
:::

:::problem[Problem M.12 — MC: sample size for 90 percent power]{difficulty=challenge}
The propellant mean-test target is 50 cm/s, known sigma 2, alpha 0.05 two-sided, and the engineer wants 90% power to detect a difference of 1 cm/s. What sample size is required? (A) 25; (B) 42; (C) 43; (D) 50.

Numerical data: $\sigma=2$, $\delta=1$, $\alpha=0.05$, $\text{power}=0.9$.

::::solution[Solution]
**Answer:** (B) $42$

1. We want power $0.9$ to detect a shift of $1$ at a two-sided significance level $0.05$. Thus $\beta=0.10$.
2. Final sheet page 2 gives a sample-size planning relationship $n=(z_\alpha+z_\beta)^2\sigma^2/\delta^2$. For a **two-sided** test the tail allocation means use $z_{\alpha/2}=1.96$, while $z_\beta=1.28$, from Table III.
3. Compute $n\approx(1.96+1.28)^2(2)^2/(1)^2=41.990$, which is the value the sheet's formula gives.
4. A sample size must be a whole number, and it is always rounded up, so $41.990$ becomes $n=42$.

Distractors: (A) is the original test size, not a calculated one; (C) rounds up a second time after $41.990$ has already become $42$; (D) oversamples.
::::
:::

:::problem[Problem M.13 — MC: interval and test agreement]{difficulty=standard}
A two-sided 95% t confidence interval for a population mean is 69.52 to 84.08. The null hypothesizes mean 85. Which conclusion matches a two-sided 5% test? (A) reject the null; (B) fail to reject the null; (C) accept the null as true; (D) calculate a chi-square statistic.

::::solution[Solution]
**Answer:** (A) Reject the null.

1. A two-sided 95% confidence interval contains proposed population means that are not rejected by the matching two-sided 5% test.
2. The hypothesized mean 85 lies **above** the stated upper endpoint 84.08 and so is not included.
3. Reject the null at alpha 0.05.
4. You do not need a new test statistic to answer because the supplied interval and matching test are two equivalent versions of the same inference. Chi-square would instead test a variance.

Distractors: (B) ignores that 85 falls outside the interval; (C) falsely treats nonrejection as proof even if it applied; (D) is reserved for population variance.
::::
:::

:::problem[Problem M.14 — MC: power with a displaced mean]{difficulty=challenge}
A normal-process mean test has null 5 V, known sigma .25 V, n=8 and acceptance limits 4.85 to 5.15 V. When the true mean equals 5.1 V, what is the power? (A) 0.7133; (B) 0.2867; (C) 0.0891; (D) 0.9500.

Numerical data: $\mu_0=5$, $\mu=5.1$, $n=8$, $\sigma=0.25$, $L=4.85$, $U=5.15$.

::::solution[Solution]
**Answer:** (B) $0.2867$

1. The sample-mean standard error is $\sigma/\sqrt n=0.25/\sqrt{8}=0.08839$, from Final sheet page 1. The *acceptance region* is $4.85\leq\bar{X}\leq5.15$; points outside lead to rejection.
2. For Type II error or power, the actual mean is 5.1, even though the null claims 5. Convert the endpoints to $z$ values: $(4.85-5.1)/0.08839=-2.828$ and $(5.15-5.1)/0.08839=0.566$.
3. Round each endpoint to two decimals. In Table III, Final sheet pages 3–4, the left cumulative areas are $\Phi(-2.83)=0.002327$ and $\Phi(0.57)=0.715661$. Their difference, the probability *between* the limits, is $0.7133$.
4. Take one minus the acceptance probability because power is successful detection. Thus $\text{power}=0.2867$. This is the long-run fraction of such tests with the specified outcome.

Distractors: (A) is the probability of missing the shifted mean; (C) is the null-based false alarm rate; (D) assumes an arbitrary 5% significance rather than computing true-mean area.
::::
:::

