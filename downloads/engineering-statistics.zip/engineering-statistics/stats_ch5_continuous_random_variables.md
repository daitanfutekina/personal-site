---
title: "Continuous Random Variables"
crumb: "Engineering Statistics I · Chapter 5"
meta:
  - "Est. study time: ~6 hours"
  - "IE 4613 · Unit 5"
source: "markdown"
---

## Overview

A continuous random variable records a measurement rather than a count: current in a wire, the thickness of a flange, the time until a component fails, or the amount poured into a can. Unit 4 asked for probabilities attached to individual integers. In this unit an individual point has probability zero. Probabilities come from **areas under density curves**, and nearly every computational question is an exercise in identifying the correct area.

The chapter follows the instructor's Unit 5 progression: probability densities; accumulation and distribution functions; mean, variance and the shorter continuous-uniform model; the exponential distribution and arrival-time interpretation; the standard normal table; and engineering problems in a nonstandard normal distribution. The formula sheet gives the continuous integrals on **page 1**, distribution entries on **page 2**, and the two halves of the cumulative standard-normal table on **pages 3 and 4**. On the exam, the TI-30X IIS evaluates arithmetic, powers, square roots and logarithms; the printed tables provide normal probabilities.

The first question to ask is not which formula to memorize. It is: **What is being measured?** The next question is: **Does the wording ask for a probability below, above, between, or at an exact value?** Those two questions determine the model and the shaded region. The later examples deliberately revisit the same components with changing wording so that a new sentence on the final cannot hide a familiar calculation.

:::callout-key[The one-page decision rule]
- Given a density $f(x)$ and endpoints, integrate the density across the requested interval.
- Given a cumulative function $F(x)$, subtract cumulative probabilities at the two endpoints.
- Given uniform endpoints, divide the requested length by the full interval length.
- Given time until the next Poisson-process event, use an exponential model, not a Poisson count.
- Given a bell-shaped variable with $\mu$ and $\sigma$, calculate $z=(x-\mu)/\sigma$ and read the left-tail table.
- Given a percentage and asked to find a threshold, work **backward** from a cumulative probability to an $x$ value.
:::

## 5.1 A Continuous Density Is an Area Rule

The instructor's first slide lists electrical current, length, pressure, temperature, time, voltage and weight. Those are not arbitrary examples. Every one can vary through an interval of real numbers. A measurement may be displayed as 15.00 on an instrument, but the actual physical measurement can be 14.9998 or 15.0002. That is fundamentally unlike counting defective parts, where a count of 2 is a complete possible outcome and 2.1 defective parts is not.

Imagine a strip of copper wire with its current fluctuating across the interval from 0 to 20 milliamperes. If every current in that interval is equally likely per unit of current, its density is a horizontal line. The probability of seeing a current between 5 and 10 is not the height at 10. It is the rectangular area under that horizontal line from 5 to 10. A more complicated density simply makes the top of that region curved; **the meaning of the shaded area stays the same**.

:::callout-intuition[Why the probability at a single number is zero]
A continuous interval contains infinitely many possible measurements. One exact value has no width, and area is width times height in the simple rectangular case. Therefore $P(X=15)=0$, even when the density $f(15)$ is positive. This is why the slide suggests asking for the interval 14.99 to 15.01 rather than an exact 15. Zero probability at a point does not mean the measurement is impossible; it means an isolated point contributes zero area.
:::

:::definition[Definition 5.1 — Continuous Random Variable]
A continuous random variable $X$ has an interval of real numbers, finite or infinite, as its range. A probability density function $f(x)$ describes how probability is distributed across that range. A valid density satisfies $f(x)\geq0$ everywhere and

$$\int_{-\infty}^{\infty}f(x)\,dx=1.$$

Its probability across an interval is the area underneath the density:

$$P(a\leq X\leq b)=\int_a^bf(x)\,dx.$$

**Final-sheet location:** the probability integral is printed on **page 1**, on the right of the discrete probability formula. The two conditions on a density are the reason the total shaded probability is one; they are also visible in the Unit 5 notes.
:::

### The indispensable integral rules

You need only the integral manipulations used by the instructor. The power rule reverses differentiation: $\int x^k\,dx=x^{k+1}/(k+1)+C$ for $k\ne-1$. The exponent increases by one, and then you divide by that new exponent. When $k=-1$, the special rule is $\int(1/x)\,dx=\ln|x|+C$. For exponentials, $\int e^{au}\,du=e^{au}/a+C$ when $a\ne0$. Finally, a definite integral subtracts an antiderivative evaluated at the lower endpoint from the value at the upper endpoint, $G(b)-G(a)$.

For the instructor's integral-review example, $\int_5^{10}x\,dx=[x^2/2]_5^{10}=100/2-25/2=37.5$. With a density, the mechanics are the same, but the integral represents a probability and therefore its result must land between zero and one. The TI-30X IIS can calculate the arithmetic after you produce an antiderivative; it does not replace understanding which bounds belong in the integral.

A useful habit is to write the **support** of $X$ before integrating. If the density is declared only for $0\leq x\leq4$, then the probability to the right of 4 is zero even if an algebraic expression for the density would be positive there. Set $f(x)=0$ outside its declared support, even when the statement only prints the nonzero branch.

### A graph that makes the interval visible

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Uniform copper-wire current with the probability from five to ten shaded">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M181.00,215.00 L181.00,88.33 L182.85,88.33 L184.71,88.33 L186.56,88.33 L188.41,88.33 L190.27,88.33 L192.12,88.33 L193.97,88.33 L195.83,88.33 L197.68,88.33 L199.53,88.33 L201.39,88.33 L203.24,88.33 L205.09,88.33 L206.95,88.33 L208.80,88.33 L210.65,88.33 L212.51,88.33 L214.36,88.33 L216.21,88.33 L218.07,88.33 L219.92,88.33 L221.77,88.33 L223.63,88.33 L225.48,88.33 L227.33,88.33 L229.19,88.33 L231.04,88.33 L232.89,88.33 L234.75,88.33 L236.60,88.33 L238.45,88.33 L240.31,88.33 L242.16,88.33 L244.01,88.33 L245.87,88.33 L247.72,88.33 L249.57,88.33 L251.43,88.33 L253.28,88.33 L255.13,88.33 L256.99,88.33 L258.84,88.33 L260.69,88.33 L262.55,88.33 L264.40,88.33 L266.25,88.33 L268.11,88.33 L269.96,88.33 L271.81,88.33 L273.67,88.33 L275.52,88.33 L277.37,88.33 L279.23,88.33 L281.08,88.33 L282.93,88.33 L284.79,88.33 L286.64,88.33 L288.49,88.33 L290.35,88.33 L292.20,88.33 L294.05,88.33 L295.91,88.33 L297.76,88.33 L299.61,88.33 L301.47,88.33 L303.32,88.33 L305.17,88.33 L307.03,88.33 L308.88,88.33 L310.73,88.33 L312.59,88.33 L314.44,88.33 L316.29,88.33 L318.15,88.33 L320.00,88.33 L320.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,88.33 L43.85,88.33 L45.71,88.33 L47.56,88.33 L49.41,88.33 L51.27,88.33 L53.12,88.33 L54.97,88.33 L56.83,88.33 L58.68,88.33 L60.53,88.33 L62.39,88.33 L64.24,88.33 L66.09,88.33 L67.95,88.33 L69.80,88.33 L71.65,88.33 L73.51,88.33 L75.36,88.33 L77.21,88.33 L79.07,88.33 L80.92,88.33 L82.77,88.33 L84.63,88.33 L86.48,88.33 L88.33,88.33 L90.19,88.33 L92.04,88.33 L93.89,88.33 L95.75,88.33 L97.60,88.33 L99.45,88.33 L101.31,88.33 L103.16,88.33 L105.01,88.33 L106.87,88.33 L108.72,88.33 L110.57,88.33 L112.43,88.33 L114.28,88.33 L116.13,88.33 L117.99,88.33 L119.84,88.33 L121.69,88.33 L123.55,88.33 L125.40,88.33 L127.25,88.33 L129.11,88.33 L130.96,88.33 L132.81,88.33 L134.67,88.33 L136.52,88.33 L138.37,88.33 L140.23,88.33 L142.08,88.33 L143.93,88.33 L145.79,88.33 L147.64,88.33 L149.49,88.33 L151.35,88.33 L153.20,88.33 L155.05,88.33 L156.91,88.33 L158.76,88.33 L160.61,88.33 L162.47,88.33 L164.32,88.33 L166.17,88.33 L168.03,88.33 L169.88,88.33 L171.73,88.33 L173.59,88.33 L175.44,88.33 L177.29,88.33 L179.15,88.33 L181.00,88.33 L182.85,88.33 L184.71,88.33 L186.56,88.33 L188.41,88.33 L190.27,88.33 L192.12,88.33 L193.97,88.33 L195.83,88.33 L197.68,88.33 L199.53,88.33 L201.39,88.33 L203.24,88.33 L205.09,88.33 L206.95,88.33 L208.80,88.33 L210.65,88.33 L212.51,88.33 L214.36,88.33 L216.21,88.33 L218.07,88.33 L219.92,88.33 L221.77,88.33 L223.63,88.33 L225.48,88.33 L227.33,88.33 L229.19,88.33 L231.04,88.33 L232.89,88.33 L234.75,88.33 L236.60,88.33 L238.45,88.33 L240.31,88.33 L242.16,88.33 L244.01,88.33 L245.87,88.33 L247.72,88.33 L249.57,88.33 L251.43,88.33 L253.28,88.33 L255.13,88.33 L256.99,88.33 L258.84,88.33 L260.69,88.33 L262.55,88.33 L264.40,88.33 L266.25,88.33 L268.11,88.33 L269.96,88.33 L271.81,88.33 L273.67,88.33 L275.52,88.33 L277.37,88.33 L279.23,88.33 L281.08,88.33 L282.93,88.33 L284.79,88.33 L286.64,88.33 L288.49,88.33 L290.35,88.33 L292.20,88.33 L294.05,88.33 L295.91,88.33 L297.76,88.33 L299.61,88.33 L301.47,88.33 L303.32,88.33 L305.17,88.33 L307.03,88.33 L308.88,88.33 L310.73,88.33 L312.59,88.33 L314.44,88.33 L316.29,88.33 L318.15,88.33 L320.00,88.33 L321.85,88.33 L323.71,88.33 L325.56,88.33 L327.41,88.33 L329.27,88.33 L331.12,88.33 L332.97,88.33 L334.83,88.33 L336.68,88.33 L338.53,88.33 L340.39,88.33 L342.24,88.33 L344.09,88.33 L345.95,88.33 L347.80,88.33 L349.65,88.33 L351.51,88.33 L353.36,88.33 L355.21,88.33 L357.07,88.33 L358.92,88.33 L360.77,88.33 L362.63,88.33 L364.48,88.33 L366.33,88.33 L368.19,88.33 L370.04,88.33 L371.89,88.33 L373.75,88.33 L375.60,88.33 L377.45,88.33 L379.31,88.33 L381.16,88.33 L383.01,88.33 L384.87,88.33 L386.72,88.33 L388.57,88.33 L390.43,88.33 L392.28,88.33 L394.13,88.33 L395.99,88.33 L397.84,88.33 L399.69,88.33 L401.55,88.33 L403.40,88.33 L405.25,88.33 L407.11,88.33 L408.96,88.33 L410.81,88.33 L412.67,88.33 L414.52,88.33 L416.37,88.33 L418.23,88.33 L420.08,88.33 L421.93,88.33 L423.79,88.33 L425.64,88.33 L427.49,88.33 L429.35,88.33 L431.20,88.33 L433.05,88.33 L434.91,88.33 L436.76,88.33 L438.61,88.33 L440.47,88.33 L442.32,88.33 L444.17,88.33 L446.03,88.33 L447.88,88.33 L449.73,88.33 L451.59,88.33 L453.44,88.33 L455.29,88.33 L457.15,88.33 L459.00,88.33 L460.85,88.33 L462.71,88.33 L464.56,88.33 L466.41,88.33 L468.27,88.33 L470.12,88.33 L471.97,88.33 L473.83,88.33 L475.68,88.33 L477.53,88.33 L479.39,88.33 L481.24,88.33 L483.09,88.33 L484.95,88.33 L486.80,88.33 L488.65,88.33 L490.51,88.33 L492.36,88.33 L494.21,88.33 L496.07,88.33 L497.92,88.33 L499.77,88.33 L501.63,88.33 L503.48,88.33 L505.33,88.33 L507.19,88.33 L509.04,88.33 L510.89,88.33 L512.75,88.33 L514.60,88.33 L516.45,88.33 L518.31,88.33 L520.16,88.33 L522.01,88.33 L523.87,88.33 L525.72,88.33 L527.57,88.33 L529.43,88.33 L531.28,88.33 L533.13,88.33 L534.99,88.33 L536.84,88.33 L538.69,88.33 L540.55,88.33 L542.40,88.33 L544.25,88.33 L546.11,88.33 L547.96,88.33 L549.81,88.33 L551.67,88.33 L553.52,88.33 L555.37,88.33 L557.23,88.33 L559.08,88.33 L560.93,88.33 L562.79,88.33 L564.64,88.33 L566.49,88.33 L568.35,88.33 L570.20,88.33 L572.05,88.33 L573.91,88.33 L575.76,88.33 L577.61,88.33 L579.47,88.33 L581.32,88.33 L583.17,88.33 L585.03,88.33 L586.88,88.33 L588.73,88.33 L590.59,88.33 L592.44,88.33 L594.29,88.33 L596.15,88.33 L598.00,88.33"/>

<text class="fig-label" x="42.0" y="235">0</text><text class="fig-label" x="578" y="235">20</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="173.0" y="231">5</text><text class="fig-label-em" x="312.0" y="231">10</text>
</svg>
<figcaption>The current density is $f(x)=0.05$ from 0 to 20 mA, so the shaded five-milliampere interval has probability $5(0.05)=0.25$.</figcaption>
</figure>

:::example[Example 5.1 — Copper-wire current, two intervals]
Let $X$ be the current measured in a thin copper wire, with $f(x)=0.05$ for $0\leq x\leq20$ mA. Find (a) $P(X<10)$ and (b) $P(5<X<20)$.

::::answer[Answer]
**Answer:** (a) 0.5000; (b) 0.7500.

1. The curve is constant on its 20-mA support; every one-milliampere interval has area $0.05$. The left endpoint contributes no point probability.
2. (a) $P(X<10)=\int_0^{10}0.05\,dx=[0.05x]_0^{10}=0.50$.
3. (b) $P(5<X<20)=\int_5^{20}0.05\,dx=0.05(20-5)=0.75$.
4. These probabilities mean half of measurements are below 10 mA and three quarters are between 5 and 20 mA; adding or removing the endpoints changes neither answer.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### How to recognize left, right, and middle regions

The phrases *less than*, *below*, *under* and *at most* point to the **left** of a threshold. The phrases *more than*, *exceeds*, *greater than* and *at least* point to the **right**. *Between* requires the area in the middle. These are directional statements, not clues about whether to take a complement in every case. You can integrate the right-tail region directly when the support has a manageable upper endpoint, or calculate $1-$the left-tail area. Complementation is on the **Final sheet, page 1** as $P(E')=1-P(E)$.

If your integrand is $x/8$ on $0\leq x\leq4$, the curve grows as $x$ grows. The probability above 2 is larger than the probability below 2, even though those two regions have equal *width*. That is the distinction between a uniform density and a nonuniform density. Drawing the curve before integrating lets you predict whether the answer should exceed one-half.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Rising linear density for the lifetime of an electronic component">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M42.00,215.00 L42.00,215.00 L43.85,214.45 L45.71,213.90 L47.56,213.35 L49.41,212.80 L51.27,212.25 L53.12,211.70 L54.97,211.14 L56.83,210.59 L58.68,210.04 L60.53,209.49 L62.39,208.94 L64.24,208.39 L66.09,207.84 L67.95,207.29 L69.80,206.74 L71.65,206.19 L73.51,205.64 L75.36,205.09 L77.21,204.54 L79.07,203.99 L80.92,203.43 L82.77,202.88 L84.63,202.33 L86.48,201.78 L88.33,201.23 L90.19,200.68 L92.04,200.13 L93.89,199.58 L95.75,199.03 L97.60,198.48 L99.45,197.93 L101.31,197.38 L103.16,196.83 L105.01,196.28 L106.87,195.72 L108.72,195.17 L110.57,194.62 L112.43,194.07 L114.28,193.52 L116.13,192.97 L117.99,192.42 L119.84,191.87 L121.69,191.32 L123.55,190.77 L125.40,190.22 L127.25,189.67 L129.11,189.12 L130.96,188.57 L132.81,188.01 L134.67,187.46 L136.52,186.91 L138.37,186.36 L140.23,185.81 L142.08,185.26 L143.93,184.71 L145.79,184.16 L147.64,183.61 L149.49,183.06 L151.35,182.51 L153.20,181.96 L155.05,181.41 L156.91,180.86 L158.76,180.30 L160.61,179.75 L162.47,179.20 L164.32,178.65 L166.17,178.10 L168.03,177.55 L169.88,177.00 L171.73,176.45 L173.59,175.90 L175.44,175.35 L177.29,174.80 L179.15,174.25 L181.00,173.70 L182.85,173.14 L184.71,172.59 L186.56,172.04 L188.41,171.49 L190.27,170.94 L192.12,170.39 L193.97,169.84 L195.83,169.29 L197.68,168.74 L199.53,168.19 L201.39,167.64 L203.24,167.09 L205.09,166.54 L206.95,165.99 L208.80,165.43 L210.65,164.88 L212.51,164.33 L214.36,163.78 L216.21,163.23 L218.07,162.68 L219.92,162.13 L221.77,161.58 L223.63,161.03 L225.48,160.48 L227.33,159.93 L229.19,159.38 L231.04,158.83 L232.89,158.28 L234.75,157.72 L236.60,157.17 L238.45,156.62 L240.31,156.07 L242.16,155.52 L244.01,154.97 L245.87,154.42 L247.72,153.87 L249.57,153.32 L251.43,152.77 L253.28,152.22 L255.13,151.67 L256.99,151.12 L258.84,150.57 L260.69,150.01 L262.55,149.46 L264.40,148.91 L266.25,148.36 L268.11,147.81 L269.96,147.26 L271.81,146.71 L273.67,146.16 L275.52,145.61 L277.37,145.06 L279.23,144.51 L281.08,143.96 L282.93,143.41 L284.79,142.86 L286.64,142.30 L288.49,141.75 L290.35,141.20 L292.20,140.65 L294.05,140.10 L295.91,139.55 L297.76,139.00 L299.61,138.45 L301.47,137.90 L303.32,137.35 L305.17,136.80 L307.03,136.25 L308.88,135.70 L310.73,135.14 L312.59,134.59 L314.44,134.04 L316.29,133.49 L318.15,132.94 L320.00,132.39 L320.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,215.00 L43.85,214.45 L45.71,213.90 L47.56,213.35 L49.41,212.80 L51.27,212.25 L53.12,211.70 L54.97,211.14 L56.83,210.59 L58.68,210.04 L60.53,209.49 L62.39,208.94 L64.24,208.39 L66.09,207.84 L67.95,207.29 L69.80,206.74 L71.65,206.19 L73.51,205.64 L75.36,205.09 L77.21,204.54 L79.07,203.99 L80.92,203.43 L82.77,202.88 L84.63,202.33 L86.48,201.78 L88.33,201.23 L90.19,200.68 L92.04,200.13 L93.89,199.58 L95.75,199.03 L97.60,198.48 L99.45,197.93 L101.31,197.38 L103.16,196.83 L105.01,196.28 L106.87,195.72 L108.72,195.17 L110.57,194.62 L112.43,194.07 L114.28,193.52 L116.13,192.97 L117.99,192.42 L119.84,191.87 L121.69,191.32 L123.55,190.77 L125.40,190.22 L127.25,189.67 L129.11,189.12 L130.96,188.57 L132.81,188.01 L134.67,187.46 L136.52,186.91 L138.37,186.36 L140.23,185.81 L142.08,185.26 L143.93,184.71 L145.79,184.16 L147.64,183.61 L149.49,183.06 L151.35,182.51 L153.20,181.96 L155.05,181.41 L156.91,180.86 L158.76,180.30 L160.61,179.75 L162.47,179.20 L164.32,178.65 L166.17,178.10 L168.03,177.55 L169.88,177.00 L171.73,176.45 L173.59,175.90 L175.44,175.35 L177.29,174.80 L179.15,174.25 L181.00,173.70 L182.85,173.14 L184.71,172.59 L186.56,172.04 L188.41,171.49 L190.27,170.94 L192.12,170.39 L193.97,169.84 L195.83,169.29 L197.68,168.74 L199.53,168.19 L201.39,167.64 L203.24,167.09 L205.09,166.54 L206.95,165.99 L208.80,165.43 L210.65,164.88 L212.51,164.33 L214.36,163.78 L216.21,163.23 L218.07,162.68 L219.92,162.13 L221.77,161.58 L223.63,161.03 L225.48,160.48 L227.33,159.93 L229.19,159.38 L231.04,158.83 L232.89,158.28 L234.75,157.72 L236.60,157.17 L238.45,156.62 L240.31,156.07 L242.16,155.52 L244.01,154.97 L245.87,154.42 L247.72,153.87 L249.57,153.32 L251.43,152.77 L253.28,152.22 L255.13,151.67 L256.99,151.12 L258.84,150.57 L260.69,150.01 L262.55,149.46 L264.40,148.91 L266.25,148.36 L268.11,147.81 L269.96,147.26 L271.81,146.71 L273.67,146.16 L275.52,145.61 L277.37,145.06 L279.23,144.51 L281.08,143.96 L282.93,143.41 L284.79,142.86 L286.64,142.30 L288.49,141.75 L290.35,141.20 L292.20,140.65 L294.05,140.10 L295.91,139.55 L297.76,139.00 L299.61,138.45 L301.47,137.90 L303.32,137.35 L305.17,136.80 L307.03,136.25 L308.88,135.70 L310.73,135.14 L312.59,134.59 L314.44,134.04 L316.29,133.49 L318.15,132.94 L320.00,132.39 L321.85,131.84 L323.71,131.29 L325.56,130.74 L327.41,130.19 L329.27,129.64 L331.12,129.09 L332.97,128.54 L334.83,127.99 L336.68,127.43 L338.53,126.88 L340.39,126.33 L342.24,125.78 L344.09,125.23 L345.95,124.68 L347.80,124.13 L349.65,123.58 L351.51,123.03 L353.36,122.48 L355.21,121.93 L357.07,121.38 L358.92,120.83 L360.77,120.28 L362.63,119.72 L364.48,119.17 L366.33,118.62 L368.19,118.07 L370.04,117.52 L371.89,116.97 L373.75,116.42 L375.60,115.87 L377.45,115.32 L379.31,114.77 L381.16,114.22 L383.01,113.67 L384.87,113.12 L386.72,112.57 L388.57,112.01 L390.43,111.46 L392.28,110.91 L394.13,110.36 L395.99,109.81 L397.84,109.26 L399.69,108.71 L401.55,108.16 L403.40,107.61 L405.25,107.06 L407.11,106.51 L408.96,105.96 L410.81,105.41 L412.67,104.86 L414.52,104.30 L416.37,103.75 L418.23,103.20 L420.08,102.65 L421.93,102.10 L423.79,101.55 L425.64,101.00 L427.49,100.45 L429.35,99.90 L431.20,99.35 L433.05,98.80 L434.91,98.25 L436.76,97.70 L438.61,97.14 L440.47,96.59 L442.32,96.04 L444.17,95.49 L446.03,94.94 L447.88,94.39 L449.73,93.84 L451.59,93.29 L453.44,92.74 L455.29,92.19 L457.15,91.64 L459.00,91.09 L460.85,90.54 L462.71,89.99 L464.56,89.43 L466.41,88.88 L468.27,88.33 L470.12,87.78 L471.97,87.23 L473.83,86.68 L475.68,86.13 L477.53,85.58 L479.39,85.03 L481.24,84.48 L483.09,83.93 L484.95,83.38 L486.80,82.83 L488.65,82.28 L490.51,81.72 L492.36,81.17 L494.21,80.62 L496.07,80.07 L497.92,79.52 L499.77,78.97 L501.63,78.42 L503.48,77.87 L505.33,77.32 L507.19,76.77 L509.04,76.22 L510.89,75.67 L512.75,75.12 L514.60,74.57 L516.45,74.01 L518.31,73.46 L520.16,72.91 L522.01,72.36 L523.87,71.81 L525.72,71.26 L527.57,70.71 L529.43,70.16 L531.28,69.61 L533.13,69.06 L534.99,68.51 L536.84,67.96 L538.69,67.41 L540.55,66.86 L542.40,66.30 L544.25,65.75 L546.11,65.20 L547.96,64.65 L549.81,64.10 L551.67,63.55 L553.52,63.00 L555.37,62.45 L557.23,61.90 L559.08,61.35 L560.93,60.80 L562.79,60.25 L564.64,59.70 L566.49,59.14 L568.35,58.59 L570.20,58.04 L572.05,57.49 L573.91,56.94 L575.76,56.39 L577.61,55.84 L579.47,55.29 L581.32,54.74 L583.17,54.19 L585.03,53.64 L586.88,53.09 L588.73,52.54 L590.59,51.99 L592.44,51.43 L594.29,50.88 L596.15,50.33 L598.00,49.78"/>

<text class="fig-label" x="42.0" y="235">0</text><text class="fig-label" x="578" y="235">4</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="34.0" y="231">0</text><text class="fig-label-em" x="312.0" y="231">2</text>
</svg>
<figcaption>For $f(x)=x/8$ on $[0,4]$, the left half has less than half the total area because the density rises toward 4.</figcaption>
</figure>

:::example[Example 5.2 — Electronic-component lifetime from a rising density]
Homework 6 models the lifetime $X$ in years of a specialized electronic component by $f(x)=x/8$ for $0\leq x\leq4$. Find $P(X\leq2)$ and $P(1\leq X\leq3)$.

::::answer[Answer]
**Answer:** (a) 0.2500; (b) 0.5000.

1. First check the total area: $\int_0^4(x/8)\,dx=[x^2/16]_0^4=1$. This expression is a valid density.
2. (a) $P(X\leq2)=\int_0^2x/8\,dx=[x^2/16]_0^2=4/16=0.25$.
3. (b) $P(1\leq X\leq3)=\int_1^3x/8\,dx=[x^2/16]_1^3=(9-1)/16=0.50$.
4. Only a quarter of component lifetimes are at most two years, whereas one half fall between one and three years.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::example[Example 5.3 — Shifted lifetime and the scrap threshold]
In Unit 5 Exercise 1, the diameter $X$ of a drilled hole has $f(x)=20e^{-20(x-12.5)}$ for $x\geq12.5$ mm. If a diameter larger than 12.60 mm is scrapped, find (a) the proportion scrapped and (b) the proportion between 12.5 and 12.6 mm.

::::answer[Answer]
**Answer:** (a) 0.1353; (b) 0.8647.

1. The smallest possible diameter is 12.5 mm. Let the excess diameter be $Y=X-12.5\geq0$; its density is $20e^{-20y}$.
2. (a) A part is scrapped when $Y>0.10$. Integrate: $\int_{0.10}^{\infty}20e^{-20y}\,dy=[-e^{-20y}]_{0.10}^{\infty}=e^{-2}$.
3. (b) The complement is $P(0\leq Y\leq0.10)=1-e^{-2}$. The two proportions sum to one, as all holes are either within the first 0.10 mm above minimum or above it.
4. Approximately 13.53% of drilled parts are scrapped, while 86.47% are in the acceptable interval.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::callout-pitfall[Density height is not probability]
Three errors account for most mistakes on this part: using $f(2)$ as though it were $P(X=2)$; ignoring the support when choosing integral bounds; and forgetting the upper-minus-lower operation when evaluating an antiderivative. For the $x/8$ density, $f(2)=0.25$ happens to equal $P(X\leq2)=0.25$ by coincidence. That numerical coincidence does **not** make the two quantities the same idea.
:::

### Practice: recognizing and integrating densities

The problems below combine the instructor's copper-wire example, Homework 6, her drilled-hole exercise, and new variations using exactly the same methods. Attempt the question before opening its solution. For right tails, decide whether direct integration or a complement produces the shorter and safer calculation.

:::problem[Problem 5.1 — Homework 6, lifetime above 2.5 years]{difficulty=easy}
For the electronic-component density $f(x)=x/8$ on $0\leq x\leq4$, find $P(X>2.5)$.

::::solution[Solution]
**Answer:** 0.6094.

1. Write the support $[0,4]$ and shade the region to the right of 2.5. No density is present after 4.
2. $P(X>2.5)=\int_{2.5}^{4}x/8\,dx=[x^2/16]_{2.5}^{4}=1-6.25/16=0.609375$.
3. Alternatively, subtract $P(X\leq2.5)=6.25/16$ from one. Both calculations count the same shaded right-hand area.
4. This means about 60.94% of components last longer than 2.5 years.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.2 — SI: an exact normal measurement]{difficulty=easy}
The SI practice test asks: If $X$ is normal with $\mu=10$ and $\sigma=2$, what is $P(X=10)$? Choose A. 0.5000, B. 0.3989, C. 0.2500, or D. 0.0000.

::::solution[Solution]
**Answer:** (D) 0.0000.

1. A normal distribution is continuous. The question asks for one exact point, not a range and not a left-tail probability.
2. A point has zero width on the horizontal axis, so its area is zero and $P(X=10)=0$.
3. Choice A confuses the median split $P(X<10)=0.5$ with a point probability; B uses the density height at the mean; C has no connection to this exact event.
4. D is the only correct probability, whether or not 10 equals the mean.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.3 — Copper wire between 5 and 10 mA]{difficulty=easy}
Under the uniform copper-wire model $f(x)=0.05$ for $0\leq x\leq20$, find the probability of a current between 5 and 10 mA.

::::solution[Solution]
**Answer:** 0.2500.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.4 — Rising-density narrow band]{difficulty=standard}
A calibrated measurement has $f(x)=x/8$ for $0\leq x\leq4$. What proportion is between 2 and 3?

::::solution[Solution]
**Answer:** 0.3125.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. write the integral only over the interval where the density is nonzero. Use the power rule and apply the upper endpoint minus the lower endpoint; for variance, calculate $E(X^2)$ and subtract $\mu^2$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.5 — Recheck the drilled-hole distribution]{difficulty=standard}
For $f(x)=20e^{-20(x-12.5)}$ on $x\geq12.5$, calculate the chance that the hole exceeds 12.55 mm.

::::solution[Solution]
**Answer:** 0.3679.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. the exponential rate is $\lambda=20$ per unit. For a wait, $P(X>t)=e^{-\lambda t}$; to find a failure by $t$, take $1-e^{-\lambda t}$, and for a band subtract the two survival values. Here the requested calculation is $\mathrm{tail}$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.6 — Triangle-like density on a larger support]{difficulty=challenge}
A measured quantity has density $f(x)=x/18$ for $0\leq x\leq6$. Find the probability that $3<X<5$.

::::solution[Solution]
**Answer:** 0.4444.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. write the integral only over the interval where the density is nonzero. Use the power rule and apply the upper endpoint minus the lower endpoint; for variance, calculate $E(X^2)$ and subtract $\mu^2$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.7 — Exam 2, continuous and discrete parking variables]{difficulty=easy}
A study of parking on MSU’s campus asks for one discrete random variable and one continuous random variable that could measure parking efficiency. Give an example of each.

::::solution[Solution]
**Answer:** discrete: count of cars; continuous: time to park.

1. An integer count, such as the number of open parking spaces in a garage, is discrete because its possible values jump in whole units.
2. A measured duration, such as the number of minutes a driver spends searching before parking, is continuous because its mathematical model ranges through real-number times.
3. The two variables can describe the same parking system, but one is a count and the other is a measurement. In this chapter, the time variable is the continuous example.

Check: This classification follows directly from what the variable measures.
::::
:::

## 5.2 Cumulative Distributions and Percentiles

The probability integral answers one question at a time. The **cumulative distribution function**, or CDF, stores *every* left-tail probability in one function. Think of a running total: start below the smallest possible value with zero probability; move the threshold to the right; keep accumulating the area you pass. When you have passed the entire support, the running total reaches one and stays there.

A CDF is useful in two different directions. In the forward direction, the problem gives a measurement and asks for the fraction at or below it. In the backward direction, it gives a fraction of the population and asks for the measurement that cuts off that fraction. The latter is a **percentile** problem. Both involve the same function; the unknown changes sides of the equation.

:::definition[Definition 5.2 — Cumulative Distribution Function]
For a continuous random variable with density $f(x)$, the cumulative distribution function is

$$F(x)=P(X\leq x)=\int_{-\infty}^{x}f(u)\,du.$$

**Final-sheet location:** this exact integral appears on **page 1**. The letter $u$ is a dummy integration variable so that the upper limit can be the requested value $x$. For two thresholds, $P(a<X<b)=F(b)-F(a)$. Because continuous point probabilities are zero, $<$ and $\leq$ yield the same result at either endpoint.
:::

The shape of $F$ has three features that catch errors quickly. First, it can never decrease: moving the threshold right adds probability but cannot remove any. Second, its values must stay between zero and one. Third, $F$ approaches one for large positive $x$ and zero for large negative $x$. When a density is zero outside a finite interval, the CDF is flat outside that interval. When you have a density $f$ that is differentiable enough, the slope of $F$ at a point is $f$ at that point, since accumulation increases fastest where the density is largest.

### Build a piecewise CDF carefully

For the copper-wire density, if $x<0$ there is nothing to accumulate; if $0\leq x<20$, the accumulated rectangle has width $x$ and height 0.05; if $x\geq20$, the complete rectangle has area one. Hence $F(x)$ is **piecewise**, not just $0.05x$ for every possible input. Substituting $x=30$ into $0.05x$ gives the impossible answer 1.5. That is not an arithmetic error; it means you applied the middle branch outside its support.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Copper-wire cumulative distribution rises from zero to one">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M121.43,215.00 L121.43,215.00 L121.69,214.89 L123.55,214.14 L125.40,213.39 L127.25,212.64 L129.11,211.89 L130.96,211.14 L132.81,210.38 L134.67,209.63 L136.52,208.88 L138.37,208.13 L140.23,207.38 L142.08,206.63 L143.93,205.88 L145.79,205.12 L147.64,204.37 L149.49,203.62 L151.35,202.87 L153.20,202.12 L155.05,201.37 L156.91,200.62 L158.76,199.86 L160.61,199.11 L162.47,198.36 L164.32,197.61 L166.17,196.86 L168.03,196.11 L169.88,195.36 L171.73,194.60 L173.59,193.85 L175.44,193.10 L177.29,192.35 L179.15,191.60 L181.00,190.85 L182.85,190.10 L184.71,189.34 L186.56,188.59 L188.41,187.84 L190.27,187.09 L192.12,186.34 L193.97,185.59 L195.83,184.84 L197.68,184.08 L199.53,183.33 L201.39,182.58 L203.24,181.83 L205.09,181.08 L206.95,180.33 L208.80,179.58 L210.65,178.82 L212.51,178.07 L214.36,177.32 L216.21,176.57 L218.07,175.82 L219.92,175.07 L221.77,174.32 L223.63,173.56 L225.48,172.81 L227.33,172.06 L229.19,171.31 L231.04,170.56 L232.89,169.81 L234.75,169.06 L236.60,168.31 L238.45,167.55 L240.31,166.80 L242.16,166.05 L244.01,165.30 L245.87,164.55 L247.72,163.80 L249.57,163.05 L251.43,162.29 L253.28,161.54 L255.13,160.79 L256.99,160.04 L258.84,159.29 L260.69,158.54 L262.55,157.79 L264.40,157.03 L266.25,156.28 L268.11,155.53 L269.96,154.78 L271.81,154.03 L273.67,153.28 L275.52,152.53 L277.37,151.77 L279.23,151.02 L281.08,150.27 L282.93,149.52 L284.79,148.77 L286.64,148.02 L288.49,147.27 L290.35,146.51 L292.20,145.76 L294.05,145.01 L295.91,144.26 L297.76,143.51 L299.61,142.76 L301.47,142.01 L303.32,141.25 L305.17,140.50 L307.03,139.75 L308.88,139.00 L310.73,138.25 L312.59,137.50 L314.44,136.75 L316.29,135.99 L318.15,135.24 L320.00,134.49 L320.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,215.00 L43.85,215.00 L45.71,215.00 L47.56,215.00 L49.41,215.00 L51.27,215.00 L53.12,215.00 L54.97,215.00 L56.83,215.00 L58.68,215.00 L60.53,215.00 L62.39,215.00 L64.24,215.00 L66.09,215.00 L67.95,215.00 L69.80,215.00 L71.65,215.00 L73.51,215.00 L75.36,215.00 L77.21,215.00 L79.07,215.00 L80.92,215.00 L82.77,215.00 L84.63,215.00 L86.48,215.00 L88.33,215.00 L90.19,215.00 L92.04,215.00 L93.89,215.00 L95.75,215.00 L97.60,215.00 L99.45,215.00 L101.31,215.00 L103.16,215.00 L105.01,215.00 L106.87,215.00 L108.72,215.00 L110.57,215.00 L112.43,215.00 L114.28,215.00 L116.13,215.00 L117.99,215.00 L119.84,215.00 L121.69,214.89 L123.55,214.14 L125.40,213.39 L127.25,212.64 L129.11,211.89 L130.96,211.14 L132.81,210.38 L134.67,209.63 L136.52,208.88 L138.37,208.13 L140.23,207.38 L142.08,206.63 L143.93,205.88 L145.79,205.12 L147.64,204.37 L149.49,203.62 L151.35,202.87 L153.20,202.12 L155.05,201.37 L156.91,200.62 L158.76,199.86 L160.61,199.11 L162.47,198.36 L164.32,197.61 L166.17,196.86 L168.03,196.11 L169.88,195.36 L171.73,194.60 L173.59,193.85 L175.44,193.10 L177.29,192.35 L179.15,191.60 L181.00,190.85 L182.85,190.10 L184.71,189.34 L186.56,188.59 L188.41,187.84 L190.27,187.09 L192.12,186.34 L193.97,185.59 L195.83,184.84 L197.68,184.08 L199.53,183.33 L201.39,182.58 L203.24,181.83 L205.09,181.08 L206.95,180.33 L208.80,179.58 L210.65,178.82 L212.51,178.07 L214.36,177.32 L216.21,176.57 L218.07,175.82 L219.92,175.07 L221.77,174.32 L223.63,173.56 L225.48,172.81 L227.33,172.06 L229.19,171.31 L231.04,170.56 L232.89,169.81 L234.75,169.06 L236.60,168.31 L238.45,167.55 L240.31,166.80 L242.16,166.05 L244.01,165.30 L245.87,164.55 L247.72,163.80 L249.57,163.05 L251.43,162.29 L253.28,161.54 L255.13,160.79 L256.99,160.04 L258.84,159.29 L260.69,158.54 L262.55,157.79 L264.40,157.03 L266.25,156.28 L268.11,155.53 L269.96,154.78 L271.81,154.03 L273.67,153.28 L275.52,152.53 L277.37,151.77 L279.23,151.02 L281.08,150.27 L282.93,149.52 L284.79,148.77 L286.64,148.02 L288.49,147.27 L290.35,146.51 L292.20,145.76 L294.05,145.01 L295.91,144.26 L297.76,143.51 L299.61,142.76 L301.47,142.01 L303.32,141.25 L305.17,140.50 L307.03,139.75 L308.88,139.00 L310.73,138.25 L312.59,137.50 L314.44,136.75 L316.29,135.99 L318.15,135.24 L320.00,134.49 L321.85,133.74 L323.71,132.99 L325.56,132.24 L327.41,131.49 L329.27,130.73 L331.12,129.98 L332.97,129.23 L334.83,128.48 L336.68,127.73 L338.53,126.98 L340.39,126.23 L342.24,125.47 L344.09,124.72 L345.95,123.97 L347.80,123.22 L349.65,122.47 L351.51,121.72 L353.36,120.97 L355.21,120.21 L357.07,119.46 L358.92,118.71 L360.77,117.96 L362.63,117.21 L364.48,116.46 L366.33,115.71 L368.19,114.95 L370.04,114.20 L371.89,113.45 L373.75,112.70 L375.60,111.95 L377.45,111.20 L379.31,110.45 L381.16,109.69 L383.01,108.94 L384.87,108.19 L386.72,107.44 L388.57,106.69 L390.43,105.94 L392.28,105.19 L394.13,104.44 L395.99,103.68 L397.84,102.93 L399.69,102.18 L401.55,101.43 L403.40,100.68 L405.25,99.93 L407.11,99.18 L408.96,98.42 L410.81,97.67 L412.67,96.92 L414.52,96.17 L416.37,95.42 L418.23,94.67 L420.08,93.92 L421.93,93.16 L423.79,92.41 L425.64,91.66 L427.49,90.91 L429.35,90.16 L431.20,89.41 L433.05,88.66 L434.91,87.90 L436.76,87.15 L438.61,86.40 L440.47,85.65 L442.32,84.90 L444.17,84.15 L446.03,83.40 L447.88,82.64 L449.73,81.89 L451.59,81.14 L453.44,80.39 L455.29,79.64 L457.15,78.89 L459.00,78.14 L460.85,77.38 L462.71,76.63 L464.56,75.88 L466.41,75.13 L468.27,74.38 L470.12,73.63 L471.97,72.88 L473.83,72.12 L475.68,71.37 L477.53,70.62 L479.39,69.87 L481.24,69.12 L483.09,68.37 L484.95,67.62 L486.80,66.86 L488.65,66.11 L490.51,65.36 L492.36,64.61 L494.21,63.86 L496.07,63.11 L497.92,62.36 L499.77,61.60 L501.63,60.85 L503.48,60.10 L505.33,59.35 L507.19,58.60 L509.04,57.85 L510.89,57.10 L512.75,56.34 L514.60,55.59 L516.45,54.84 L518.31,54.09 L520.16,53.98 L522.01,53.98 L523.87,53.98 L525.72,53.98 L527.57,53.98 L529.43,53.98 L531.28,53.98 L533.13,53.98 L534.99,53.98 L536.84,53.98 L538.69,53.98 L540.55,53.98 L542.40,53.98 L544.25,53.98 L546.11,53.98 L547.96,53.98 L549.81,53.98 L551.67,53.98 L553.52,53.98 L555.37,53.98 L557.23,53.98 L559.08,53.98 L560.93,53.98 L562.79,53.98 L564.64,53.98 L566.49,53.98 L568.35,53.98 L570.20,53.98 L572.05,53.98 L573.91,53.98 L575.76,53.98 L577.61,53.98 L579.47,53.98 L581.32,53.98 L583.17,53.98 L585.03,53.98 L586.88,53.98 L588.73,53.98 L590.59,53.98 L592.44,53.98 L594.29,53.98 L596.15,53.98 L598.00,53.98"/>

<text class="fig-label" x="42.0" y="235">-4</text><text class="fig-label" x="578" y="235">24</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="113.4" y="231">0</text><text class="fig-label-em" x="312.0" y="231">10</text>
</svg>
<figcaption>The copper-wire $F(x)$ grows linearly only between 0 and 20 mA; it remains 0 below the support and 1 above it.</figcaption>
</figure>

:::example[Example 5.4 — Copper-wire CDF in all three regions]
For $f(x)=0.05$ on $0\leq x\leq20$ mA, find $F(8)$, $F(-1)$ and $F(23)$.

::::answer[Answer]
**Answer:** (a) 0.4000; (b) 0.0000; (c) 1.0000.

1. Write $F(x)=0$ for $x<0$, $F(x)=0.05x$ on $0\leq x<20$, and $F(x)=1$ for $x\geq20$.
2. $F(8)=0.05(8)=0.40$ because 8 lies within the support.
3. $F(-1)=0$ because a negative current is below the declared support, and $F(23)=1$ because 23 exceeds the entire support.
4. The values mean 40% of currents are at most 8 mA, none are at most -1 mA, and all are at most 23 mA.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### The shifted exponential in the instructor's CDF extension

The instructor extends Exercise 1 by working from the drilled-hole density $20e^{-20(x-12.5)}$ on $x\geq12.5$. Since no diameter below 12.5 is possible in this model, the CDF there is zero. Above 12.5, the accumulation starts at the lower bound of 12.5, not at zero. Substituting the lower bound matters: it is the step that keeps the CDF continuous at 12.5 and ensures a total area of one.

Use the substitution $y=u-12.5$ to see why the antiderivative has the convenient form $-e^{-20y}$. The leading 20 cancels the factor -20 produced when differentiating the exponent. Thus the lower cumulative probability is

$$F(x)=\int_{12.5}^{x}20e^{-20(u-12.5)}\,du=1-e^{-20(x-12.5)}\qquad(x\geq12.5).$$

This is the same calculation you will use in the exponential section for waiting times. A shifted starting point changes the lower limit and the argument of the exponential, not the fundamental shape of the survival curve.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Shifted exponential CDF begins at the minimum drill diameter">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M107.41,215.00 L107.41,215.00 L108.72,212.35 L110.57,208.68 L112.43,205.08 L114.28,201.57 L116.13,198.14 L117.99,194.78 L119.84,191.50 L121.69,188.29 L123.55,185.15 L125.40,182.09 L127.25,179.09 L129.11,176.16 L130.96,173.29 L132.81,170.49 L134.67,167.76 L136.52,165.08 L138.37,162.46 L140.23,159.90 L142.08,157.40 L143.93,154.96 L145.79,152.57 L147.64,150.23 L149.49,147.95 L151.35,145.72 L153.20,143.53 L155.05,141.40 L156.91,139.32 L158.76,137.28 L160.61,135.28 L162.47,133.33 L164.32,131.43 L166.17,129.57 L168.03,127.75 L169.88,125.97 L171.73,124.23 L173.59,122.53 L175.44,120.86 L177.29,119.24 L179.15,117.65 L181.00,116.09 L182.85,114.58 L184.71,113.09 L186.56,111.64 L188.41,110.22 L190.27,108.83 L192.12,107.48 L193.97,106.15 L195.83,104.86 L197.68,103.59 L199.53,102.35 L201.39,101.14 L203.24,99.96 L205.09,98.80 L206.95,97.67 L208.80,96.56 L210.65,95.48 L212.51,94.43 L214.36,93.39 L216.21,92.38 L218.07,91.40 L219.92,90.43 L221.77,89.49 L223.63,88.57 L225.48,87.66 L227.33,86.78 L229.19,85.92 L231.04,85.08 L232.89,84.25 L234.75,83.45 L236.60,82.66 L238.45,81.89 L240.31,81.14 L242.16,80.41 L244.01,79.69 L245.87,78.98 L247.72,78.30 L249.57,77.63 L251.43,76.97 L253.28,76.33 L255.13,75.70 L256.99,75.09 L258.84,74.49 L260.69,73.90 L262.55,73.33 L264.40,72.77 L266.25,72.22 L268.11,71.68 L269.96,71.16 L270.94,70.89 L270.94,215.00 Z"/>
<path class="fig-curve" d="M42.00,215.00 L43.85,215.00 L45.71,215.00 L47.56,215.00 L49.41,215.00 L51.27,215.00 L53.12,215.00 L54.97,215.00 L56.83,215.00 L58.68,215.00 L60.53,215.00 L62.39,215.00 L64.24,215.00 L66.09,215.00 L67.95,215.00 L69.80,215.00 L71.65,215.00 L73.51,215.00 L75.36,215.00 L77.21,215.00 L79.07,215.00 L80.92,215.00 L82.77,215.00 L84.63,215.00 L86.48,215.00 L88.33,215.00 L90.19,215.00 L92.04,215.00 L93.89,215.00 L95.75,215.00 L97.60,215.00 L99.45,215.00 L101.31,215.00 L103.16,215.00 L105.01,215.00 L106.87,215.00 L108.72,212.35 L110.57,208.68 L112.43,205.08 L114.28,201.57 L116.13,198.14 L117.99,194.78 L119.84,191.50 L121.69,188.29 L123.55,185.15 L125.40,182.09 L127.25,179.09 L129.11,176.16 L130.96,173.29 L132.81,170.49 L134.67,167.76 L136.52,165.08 L138.37,162.46 L140.23,159.90 L142.08,157.40 L143.93,154.96 L145.79,152.57 L147.64,150.23 L149.49,147.95 L151.35,145.72 L153.20,143.53 L155.05,141.40 L156.91,139.32 L158.76,137.28 L160.61,135.28 L162.47,133.33 L164.32,131.43 L166.17,129.57 L168.03,127.75 L169.88,125.97 L171.73,124.23 L173.59,122.53 L175.44,120.86 L177.29,119.24 L179.15,117.65 L181.00,116.09 L182.85,114.58 L184.71,113.09 L186.56,111.64 L188.41,110.22 L190.27,108.83 L192.12,107.48 L193.97,106.15 L195.83,104.86 L197.68,103.59 L199.53,102.35 L201.39,101.14 L203.24,99.96 L205.09,98.80 L206.95,97.67 L208.80,96.56 L210.65,95.48 L212.51,94.43 L214.36,93.39 L216.21,92.38 L218.07,91.40 L219.92,90.43 L221.77,89.49 L223.63,88.57 L225.48,87.66 L227.33,86.78 L229.19,85.92 L231.04,85.08 L232.89,84.25 L234.75,83.45 L236.60,82.66 L238.45,81.89 L240.31,81.14 L242.16,80.41 L244.01,79.69 L245.87,78.98 L247.72,78.30 L249.57,77.63 L251.43,76.97 L253.28,76.33 L255.13,75.70 L256.99,75.09 L258.84,74.49 L260.69,73.90 L262.55,73.33 L264.40,72.77 L266.25,72.22 L268.11,71.68 L269.96,71.16 L271.81,70.65 L273.67,70.15 L275.52,69.66 L277.37,69.18 L279.23,68.72 L281.08,68.26 L282.93,67.81 L284.79,67.38 L286.64,66.95 L288.49,66.53 L290.35,66.12 L292.20,65.73 L294.05,65.34 L295.91,64.95 L297.76,64.58 L299.61,64.22 L301.47,63.86 L303.32,63.51 L305.17,63.17 L307.03,62.84 L308.88,62.52 L310.73,62.20 L312.59,61.89 L314.44,61.58 L316.29,61.29 L318.15,61.00 L320.00,60.71 L321.85,60.43 L323.71,60.16 L325.56,59.90 L327.41,59.64 L329.27,59.39 L331.12,59.14 L332.97,58.90 L334.83,58.66 L336.68,58.43 L338.53,58.20 L340.39,57.98 L342.24,57.76 L344.09,57.55 L345.95,57.35 L347.80,57.14 L349.65,56.95 L351.51,56.75 L353.36,56.57 L355.21,56.38 L357.07,56.20 L358.92,56.02 L360.77,55.85 L362.63,55.68 L364.48,55.52 L366.33,55.36 L368.19,55.20 L370.04,55.05 L371.89,54.90 L373.75,54.75 L375.60,54.60 L377.45,54.46 L379.31,54.33 L381.16,54.19 L383.01,54.06 L384.87,53.93 L386.72,53.81 L388.57,53.68 L390.43,53.56 L392.28,53.45 L394.13,53.33 L395.99,53.22 L397.84,53.11 L399.69,53.00 L401.55,52.90 L403.40,52.80 L405.25,52.70 L407.11,52.60 L408.96,52.50 L410.81,52.41 L412.67,52.32 L414.52,52.23 L416.37,52.14 L418.23,52.06 L420.08,51.97 L421.93,51.89 L423.79,51.81 L425.64,51.73 L427.49,51.66 L429.35,51.58 L431.20,51.51 L433.05,51.44 L434.91,51.37 L436.76,51.30 L438.61,51.24 L440.47,51.17 L442.32,51.11 L444.17,51.04 L446.03,50.98 L447.88,50.92 L449.73,50.87 L451.59,50.81 L453.44,50.75 L455.29,50.70 L457.15,50.65 L459.00,50.59 L460.85,50.54 L462.71,50.49 L464.56,50.45 L466.41,50.40 L468.27,50.35 L470.12,50.31 L471.97,50.26 L473.83,50.22 L475.68,50.18 L477.53,50.14 L479.39,50.10 L481.24,50.06 L483.09,50.02 L484.95,49.98 L486.80,49.94 L488.65,49.91 L490.51,49.87 L492.36,49.84 L494.21,49.80 L496.07,49.77 L497.92,49.74 L499.77,49.71 L501.63,49.68 L503.48,49.65 L505.33,49.62 L507.19,49.59 L509.04,49.56 L510.89,49.53 L512.75,49.51 L514.60,49.48 L516.45,49.45 L518.31,49.43 L520.16,49.40 L522.01,49.38 L523.87,49.36 L525.72,49.33 L527.57,49.31 L529.43,49.29 L531.28,49.27 L533.13,49.25 L534.99,49.23 L536.84,49.21 L538.69,49.19 L540.55,49.17 L542.40,49.15 L544.25,49.13 L546.11,49.11 L547.96,49.10 L549.81,49.08 L551.67,49.06 L553.52,49.05 L555.37,49.03 L557.23,49.01 L559.08,49.00 L560.93,48.98 L562.79,48.97 L564.64,48.95 L566.49,48.94 L568.35,48.93 L570.20,48.91 L572.05,48.90 L573.91,48.89 L575.76,48.88 L577.61,48.86 L579.47,48.85 L581.32,48.84 L583.17,48.83 L585.03,48.82 L586.88,48.81 L588.73,48.80 L590.59,48.79 L592.44,48.78 L594.29,48.77 L596.15,48.76 L598.00,48.75"/>

<text class="fig-label" x="42.0" y="235">12.46</text><text class="fig-label" x="578" y="235">12.8</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="99.4" y="231">12.5</text><text class="fig-label-em" x="262.9" y="231">12.6</text>
</svg>
<figcaption>The CDF is zero below 12.5 mm and then rises as $1-e^{-20(x-12.5)}$, so $F(12.6)$ includes all accepted holes up to 12.6 mm.</figcaption>
</figure>

:::example[Example 5.5 — The CDF of the drill-hole diameter]
With $f(x)=20e^{-20(x-12.5)}$ for $x\geq12.5$, calculate $F(12.55)$ and $F(12.60)$.

::::answer[Answer]
**Answer:** (a) 0.6321; (b) 0.8647.

1. Write the complete piecewise function: $F(x)=0$ below 12.5 and $F(x)=1-e^{-20(x-12.5)}$ at or above 12.5.
2. At 12.55, the excess is $0.05$ mm, so $F(12.55)=1-e^{-20(0.05)}=1-e^{-1}$.
3. At 12.60, the excess is $0.10$ mm, so $F(12.60)=1-e^{-2}$.
4. These values give the fraction of holes no larger than each stated diameter, measured from the actual lower support of 12.5 mm.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### Turning a cumulative probability into a cutoff

A question may say *how much chemical is contained in 90% of packages*, *what diameter separates the smallest 10%*, or *what time do 90% fail by?* Those are not instructions to find $P(X<90)$ or to use 90 as a physical measurement. They give the cumulative area, 0.90, and ask for the corresponding boundary $k$. Write $F(k)=0.90$. If the question says *a value exceeded by 90%*, then only 10% are below it, so write $F(k)=0.10$. This reversal is among the most common exam traps.

For an algebraic CDF, solve the equation directly. If $F(k)=k^2/16$, then the 75th percentile satisfies $k^2/16=0.75$, hence $k^2=12$, $k=\sqrt{12}$ because the support is nonnegative. If the model is normal, the CDF cannot be inverted with the elementary rules of calculus; Section 5.5 uses the printed table backward instead.

:::callout-pitfall[The CDF's direction and its support]
$F(x)$ always means **at or below** $x$, not above it. A right-tail request uses $1-F(x)$. For a band, subtract $F(\text{right})-F(\text{left})$, not the reverse. A 90th percentile has 90% below it, whereas a threshold exceeded by 90% has only 10% below it. Finally, a formula for the CDF's middle branch must never be applied outside the range where that branch was derived.
:::

:::problem[Problem 5.8 — Instructor Exercise 3, piecewise CDF]{difficulty=standard}
The instructor gives $F(x)=0$ for $x<-2$, $F(x)=0.25x+0.5$ for $-2\leq x<2$, and $F(x)=1$ for $x\geq2$. Find (a) $P(X<1.8)$, (b) $P(X>-1.5)$, (c) $P(X<-2)$, and (d) $P(-1<X<1)$.

::::solution[Solution]
**Answer:** (a) 0.9500; (b) 0.8750; (c) 0.0000; (d) 0.5000.

1. (a) In the middle branch, $F(1.8)=0.25(1.8)+0.5=0.95$. Continuous endpoints do not matter.
2. (b) $P(X>-1.5)=1-F(-1.5)=1-[0.25(-1.5)+0.5]=1-0.125=0.875$.
3. (c) $P(X<-2)=0$ because -2 is the lower support boundary.
4. (d) $F(1)-F(-1)=[0.25+0.5]-[-0.25+0.5]=0.75-0.25=0.50$. All four results are probabilities on the stated support.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.9 — Homework 6, find the 75th lifetime percentile]{difficulty=standard}
For $f(x)=x/8$ on $0\leq x\leq4$, find $k$ such that $P(X\leq k)=0.75$ years.

::::solution[Solution]
**Answer:** 3.4641.

1. Integrate the density from 0 to $k$: $F(k)=\int_0^k x/8\,dx=k^2/16$.
2. Set the cumulative area equal to the requested fraction: $k^2/16=0.75$. Multiply both sides by 16 to get $k^2=12$.
3. Take square roots to obtain $k=\pm\sqrt{12}$, then reject the negative root because the support is $0\leq k\leq4$.
4. The positive root is the lifetime in years reached or not exceeded by 75% of components.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.10 — Flat middle CDF below its support]{difficulty=easy}
For the copper-wire model on $[0,20]$, find $F(-3)$.

::::solution[Solution]
**Answer:** 0.0000.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.11 — Flat upper CDF above its support]{difficulty=easy}
The same current is uniform on $[0,20]$. Find $F(25)$.

::::solution[Solution]
**Answer:** 1.0000.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.12 — CDF interval on the copper-wire model]{difficulty=standard}
If $F(x)=0.05x$ between 0 and 20, find $P(8<X<14)$.

::::solution[Solution]
**Answer:** 0.3000.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.13 — CDF percentile in a shifted process]{difficulty=challenge}
A hole diameter has $F(x)=1-e^{-20(x-12.5)}$ for $x\geq12.5$. Find the diameter exceeded by only 20% of parts.

::::solution[Solution]
**Answer:** 12.5805.

1. Only 20% exceed the desired diameter, so 80% are at or below it. Set $F(k)=0.80$, not 0.20.
2. $1-e^{-20(k-12.5)}=0.80$ implies $e^{-20(k-12.5)}=0.20$.
3. Apply natural logarithms: $-20(k-12.5)=\ln(0.20)$; divide by -20 and add 12.5 to get $k=12.5-\ln(0.20)/20$.
4. About 20% of modeled drilled holes exceed this diameter, which places the cutoff near the upper portion of the distribution.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

## 5.3 Mean, Variance, and the Continuous Uniform Model

A probability is an area. A **mean** is a balancing point of the entire distribution. If the values near the right side have more density, those values pull the mean to the right. You calculate this center by multiplying each possible measurement by how heavily it is represented, then accumulating over all measurements. In Unit 4 that accumulation was a sum; for a continuous variable it is an integral. You do not divide again by the width of the interval, because the density has already been scaled to total probability one.

A **variance** describes spread around the mean, not a second average of the measurements themselves. Imagine two factories producing parts with the same average thickness. One is extremely consistent, with almost every part close to the target; the other produces many thinner and thicker parts that happen to balance out. The factories have the same mean, but the second has greater variance. Squaring the distance from the mean makes positive and negative deviations contribute in the same direction, and makes larger deviations count much more strongly.

:::definition[Definition 5.3 — Mean and Variance of a Continuous Random Variable]
For a continuous random variable with density $f(x)$,

$$\mu=E(X)=\int_{-\infty}^{\infty}xf(x)\,dx,$$

$$\sigma^2=V(X)=\int_{-\infty}^{\infty}(x-\mu)^2f(x)\,dx=\int_{-\infty}^{\infty}x^2f(x)\,dx-\mu^2,$$

$$\sigma=\sqrt{\sigma^2}.$$

**Final-sheet location:** both integrals and the second-moment shortcut appear on **page 1**. Standard deviation is the square root of variance, as shown in the Unit 5 notes. The mean has the original measurement's units; variance has their **square**; standard deviation returns to the original units.
:::

### A straightforward calculation from the density

Begin with the mean; do not use a sample formula involving $\bar{x}$ and $n-1$. The problem supplies a **probability model**, not a data set. When the density is constant on $[0,20]$, the mean integral is $\int_0^{20}0.05x\,dx=0.05[x^2/2]_0^{20}=10$. For variance, the second-moment shortcut reduces the work: calculate $\int_0^{20}0.05x^2\,dx=0.05(20^3/3)=400/3$, then subtract $10^2$. This gives $100/3=33.3333$ square milliamperes. Its square root, about 5.7735 mA, is the standard deviation.

You can anticipate the mean before integrating: the distribution is flat and perfectly symmetric about the midpoint 10 mA. Expecting a mean of 10 gives you a strong arithmetic check. Similarly, variance cannot be negative; if your second moment is smaller than $\mu^2$, some algebra or endpoint substitution went wrong.

:::callout-intuition[Why the squared deviation measures spread]
If most measurements lie roughly 5 mA from the mean, variance is on the scale of $5^2=25$ mA$^2$, not 5 mA. Taking a square root converts the measure of spread back to milliamperes. That makes $\sigma$ easier to interpret beside the mean, while $\sigma^2$ remains useful algebraically in the formulas on the sheet. A variance of 33.33 does **not** mean the typical current is 33.33 mA away from its mean.
:::

:::example[Example 5.6 — Copper-wire mean, variance, and standard deviation]
The current $X$ is uniform on $0\leq x\leq20$ mA with $f(x)=0.05$. Compute its mean, variance and standard deviation.

::::answer[Answer]
**Answer:** mean 10.0000; variance 33.3333; SD 5.7735.

1. $\mu=\int_0^{20}x(0.05)\,dx=[0.05x^2/2]_0^{20}=10$.
2. $E(X^2)=\int_0^{20}x^2(0.05)\,dx=[0.05x^3/3]_0^{20}=400/3$.
3. $V(X)=400/3-10^2=100/3=33.3333$ mA$^2$. Then $\sigma=\sqrt{100/3}=5.7735$ mA.
4. The current is centered at 10 mA, with typical spread summarized by a 5.77-mA standard deviation.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::example[Example 5.7 — Exam 2 practice, parabolic density]
Exam 2 practice problem 7 gives $f(x)=1.5x^2$ for $-1<x<1$. Determine (a) $P(-0.5<X<0.5)$, (b) mean, variance and standard deviation, and (c) the CDF for $-1<x<1$.

::::answer[Answer]
**Answer:** probability 0.1250; mean 0.0000; variance 0.6000; SD 0.7746.

1. Check validity: $\int_{-1}^1 1.5x^2\,dx=[0.5x^3]_{-1}^1=1$. Because the density is symmetric about zero, its mean is zero.
2. (a) $P(-0.5<X<0.5)=[0.5x^3]_{-0.5}^{0.5}=0.5(0.125-(-0.125))=0.125$.
3. (b) $\mu=\int_{-1}^{1}1.5x^3\,dx=0$. Also $E(X^2)=\int_{-1}^{1}1.5x^4\,dx=[0.3x^5]_{-1}^{1}=0.6$, so $V(X)=0.6-0=0.6$ and $\sigma=\sqrt{0.6}=0.7746$.
4. (c) The CDF is $F(x)=0$ for $x\leq-1$, $F(x)=0.5(x^3+1)$ for $-1<x<1$, and $F(x)=1$ for $x\geq1$. The center interval contains only 12.5% because the parabolic density is smallest at zero.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Parabolic density has more probability near the endpoints">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M181.00,215.00 L181.00,173.70 L182.85,174.79 L184.71,175.87 L186.56,176.93 L188.41,177.98 L190.27,179.02 L192.12,180.04 L193.97,181.05 L195.83,182.04 L197.68,183.01 L199.53,183.98 L201.39,184.92 L203.24,185.86 L205.09,186.77 L206.95,187.68 L208.80,188.57 L210.65,189.44 L212.51,190.30 L214.36,191.14 L216.21,191.97 L218.07,192.79 L219.92,193.59 L221.77,194.37 L223.63,195.14 L225.48,195.90 L227.33,196.64 L229.19,197.37 L231.04,198.08 L232.89,198.78 L234.75,199.46 L236.60,200.13 L238.45,200.78 L240.31,201.42 L242.16,202.05 L244.01,202.66 L245.87,203.25 L247.72,203.83 L249.57,204.40 L251.43,204.95 L253.28,205.48 L255.13,206.00 L256.99,206.51 L258.84,207.00 L260.69,207.48 L262.55,207.94 L264.40,208.39 L266.25,208.82 L268.11,209.24 L269.96,209.65 L271.81,210.04 L273.67,210.41 L275.52,210.77 L277.37,211.12 L279.23,211.45 L281.08,211.76 L282.93,212.06 L284.79,212.35 L286.64,212.62 L288.49,212.88 L290.35,213.12 L292.20,213.35 L294.05,213.56 L295.91,213.76 L297.76,213.94 L299.61,214.11 L301.47,214.27 L303.32,214.41 L305.17,214.53 L307.03,214.64 L308.88,214.74 L310.73,214.82 L312.59,214.88 L314.44,214.93 L316.29,214.97 L318.15,214.99 L320.00,215.00 L321.85,214.99 L323.71,214.97 L325.56,214.93 L327.41,214.88 L329.27,214.82 L331.12,214.74 L332.97,214.64 L334.83,214.53 L336.68,214.41 L338.53,214.27 L340.39,214.11 L342.24,213.94 L344.09,213.76 L345.95,213.56 L347.80,213.35 L349.65,213.12 L351.51,212.88 L353.36,212.62 L355.21,212.35 L357.07,212.06 L358.92,211.76 L360.77,211.45 L362.63,211.12 L364.48,210.77 L366.33,210.41 L368.19,210.04 L370.04,209.65 L371.89,209.24 L373.75,208.82 L375.60,208.39 L377.45,207.94 L379.31,207.48 L381.16,207.00 L383.01,206.51 L384.87,206.00 L386.72,205.48 L388.57,204.95 L390.43,204.40 L392.28,203.83 L394.13,203.25 L395.99,202.66 L397.84,202.05 L399.69,201.42 L401.55,200.78 L403.40,200.13 L405.25,199.46 L407.11,198.78 L408.96,198.08 L410.81,197.37 L412.67,196.64 L414.52,195.90 L416.37,195.14 L418.23,194.37 L420.08,193.59 L421.93,192.79 L423.79,191.97 L425.64,191.14 L427.49,190.30 L429.35,189.44 L431.20,188.57 L433.05,187.68 L434.91,186.77 L436.76,185.86 L438.61,184.92 L440.47,183.98 L442.32,183.01 L444.17,182.04 L446.03,181.05 L447.88,180.04 L449.73,179.02 L451.59,177.98 L453.44,176.93 L455.29,175.87 L457.15,174.79 L459.00,173.70 L459.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,49.78 L43.85,51.98 L45.71,54.16 L47.56,56.33 L49.41,58.48 L51.27,60.61 L53.12,62.74 L54.97,64.84 L56.83,66.94 L58.68,69.01 L60.53,71.08 L62.39,73.13 L64.24,75.16 L66.09,77.18 L67.95,79.18 L69.80,81.17 L71.65,83.15 L73.51,85.11 L75.36,87.06 L77.21,88.99 L79.07,90.90 L80.92,92.81 L82.77,94.69 L84.63,96.56 L86.48,98.42 L88.33,100.27 L90.19,102.09 L92.04,103.91 L93.89,105.71 L95.75,107.49 L97.60,109.26 L99.45,111.02 L101.31,112.76 L103.16,114.48 L105.01,116.19 L106.87,117.89 L108.72,119.57 L110.57,121.24 L112.43,122.89 L114.28,124.53 L116.13,126.15 L117.99,127.76 L119.84,129.35 L121.69,130.93 L123.55,132.49 L125.40,134.04 L127.25,135.58 L129.11,137.10 L130.96,138.60 L132.81,140.09 L134.67,141.57 L136.52,143.03 L138.37,144.48 L140.23,145.91 L142.08,147.33 L143.93,148.73 L145.79,150.12 L147.64,151.49 L149.49,152.85 L151.35,154.19 L153.20,155.52 L155.05,156.84 L156.91,158.14 L158.76,159.42 L160.61,160.69 L162.47,161.95 L164.32,163.19 L166.17,164.41 L168.03,165.63 L169.88,166.82 L171.73,168.00 L173.59,169.17 L175.44,170.33 L177.29,171.46 L179.15,172.59 L181.00,173.70 L182.85,174.79 L184.71,175.87 L186.56,176.93 L188.41,177.98 L190.27,179.02 L192.12,180.04 L193.97,181.05 L195.83,182.04 L197.68,183.01 L199.53,183.98 L201.39,184.92 L203.24,185.86 L205.09,186.77 L206.95,187.68 L208.80,188.57 L210.65,189.44 L212.51,190.30 L214.36,191.14 L216.21,191.97 L218.07,192.79 L219.92,193.59 L221.77,194.37 L223.63,195.14 L225.48,195.90 L227.33,196.64 L229.19,197.37 L231.04,198.08 L232.89,198.78 L234.75,199.46 L236.60,200.13 L238.45,200.78 L240.31,201.42 L242.16,202.05 L244.01,202.66 L245.87,203.25 L247.72,203.83 L249.57,204.40 L251.43,204.95 L253.28,205.48 L255.13,206.00 L256.99,206.51 L258.84,207.00 L260.69,207.48 L262.55,207.94 L264.40,208.39 L266.25,208.82 L268.11,209.24 L269.96,209.65 L271.81,210.04 L273.67,210.41 L275.52,210.77 L277.37,211.12 L279.23,211.45 L281.08,211.76 L282.93,212.06 L284.79,212.35 L286.64,212.62 L288.49,212.88 L290.35,213.12 L292.20,213.35 L294.05,213.56 L295.91,213.76 L297.76,213.94 L299.61,214.11 L301.47,214.27 L303.32,214.41 L305.17,214.53 L307.03,214.64 L308.88,214.74 L310.73,214.82 L312.59,214.88 L314.44,214.93 L316.29,214.97 L318.15,214.99 L320.00,215.00 L321.85,214.99 L323.71,214.97 L325.56,214.93 L327.41,214.88 L329.27,214.82 L331.12,214.74 L332.97,214.64 L334.83,214.53 L336.68,214.41 L338.53,214.27 L340.39,214.11 L342.24,213.94 L344.09,213.76 L345.95,213.56 L347.80,213.35 L349.65,213.12 L351.51,212.88 L353.36,212.62 L355.21,212.35 L357.07,212.06 L358.92,211.76 L360.77,211.45 L362.63,211.12 L364.48,210.77 L366.33,210.41 L368.19,210.04 L370.04,209.65 L371.89,209.24 L373.75,208.82 L375.60,208.39 L377.45,207.94 L379.31,207.48 L381.16,207.00 L383.01,206.51 L384.87,206.00 L386.72,205.48 L388.57,204.95 L390.43,204.40 L392.28,203.83 L394.13,203.25 L395.99,202.66 L397.84,202.05 L399.69,201.42 L401.55,200.78 L403.40,200.13 L405.25,199.46 L407.11,198.78 L408.96,198.08 L410.81,197.37 L412.67,196.64 L414.52,195.90 L416.37,195.14 L418.23,194.37 L420.08,193.59 L421.93,192.79 L423.79,191.97 L425.64,191.14 L427.49,190.30 L429.35,189.44 L431.20,188.57 L433.05,187.68 L434.91,186.77 L436.76,185.86 L438.61,184.92 L440.47,183.98 L442.32,183.01 L444.17,182.04 L446.03,181.05 L447.88,180.04 L449.73,179.02 L451.59,177.98 L453.44,176.93 L455.29,175.87 L457.15,174.79 L459.00,173.70 L460.85,172.59 L462.71,171.46 L464.56,170.33 L466.41,169.17 L468.27,168.00 L470.12,166.82 L471.97,165.63 L473.83,164.41 L475.68,163.19 L477.53,161.95 L479.39,160.69 L481.24,159.42 L483.09,158.14 L484.95,156.84 L486.80,155.52 L488.65,154.19 L490.51,152.85 L492.36,151.49 L494.21,150.12 L496.07,148.73 L497.92,147.33 L499.77,145.91 L501.63,144.48 L503.48,143.03 L505.33,141.57 L507.19,140.09 L509.04,138.60 L510.89,137.10 L512.75,135.58 L514.60,134.04 L516.45,132.49 L518.31,130.93 L520.16,129.35 L522.01,127.76 L523.87,126.15 L525.72,124.53 L527.57,122.89 L529.43,121.24 L531.28,119.57 L533.13,117.89 L534.99,116.19 L536.84,114.48 L538.69,112.76 L540.55,111.02 L542.40,109.26 L544.25,107.49 L546.11,105.71 L547.96,103.91 L549.81,102.09 L551.67,100.27 L553.52,98.42 L555.37,96.56 L557.23,94.69 L559.08,92.81 L560.93,90.90 L562.79,88.99 L564.64,87.06 L566.49,85.11 L568.35,83.15 L570.20,81.17 L572.05,79.18 L573.91,77.18 L575.76,75.16 L577.61,73.13 L579.47,71.08 L581.32,69.01 L583.17,66.94 L585.03,64.84 L586.88,62.74 L588.73,60.61 L590.59,58.48 L592.44,56.33 L594.29,54.16 L596.15,51.98 L598.00,49.78"/>

<text class="fig-label" x="42.0" y="235">-1</text><text class="fig-label" x="578" y="235">1</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="173.0" y="231">-0.5</text><text class="fig-label-em" x="451.0" y="231">0.5</text>
</svg>
<figcaption>For $f(x)=1.5x^2$ on $(-1,1)$, the middle region from $-0.5$ to $0.5$ contains only $0.125$ probability even though it occupies half the support width.</figcaption>
</figure>

### Uniform measurements: the short route through a long integral

When a continuous distribution is **uniform**, its density has the same height throughout the interval. If the support runs from $a$ to $b$, the rectangular density must have height $1/(b-a)$ so that its entire area equals one. The probability of a subinterval is the subinterval's width divided by the full width. Uniform models are especially useful for a manufacturing tolerance deliberately stated as *equally likely anywhere between* two specifications.

:::definition[Definition 5.4 — Continuous Uniform Distribution]
For $a\leq X\leq b$ with constant density,

$$f(x)=\frac1{b-a},\qquad F(x)=\frac{x-a}{b-a}\quad(a\leq x\leq b),$$

$$\mu=\frac{a+b}{2},\qquad\sigma^2=\frac{(b-a)^2}{12}.$$

These are the continuous-uniform formulas in the instructor's Unit 5 notes and the **Exam 2 sheet, Table I on page 2**, but **the continuous-uniform row is not on the Final sheet**. They follow intuitively from the area of a rectangle, symmetry around its midpoint, and integrating the second squared deviation.
:::

:::note[Exam 2 topic, not on the Final list]
Continuous uniform was a word-problem topic on Exam 2 but is not named among the final's Unit 5 distribution topics. It remains useful because the instructor's density, CDF, mean and variance problems repeatedly use rectangular distributions, and those general techniques **are** on the final.
:::

To derive rather than blindly memorize the mean, integrate $x/(b-a)$ from $a$ to $b$. The antiderivative is $x^2/[2(b-a)]$, so the result is $(b^2-a^2)/[2(b-a)]=(a+b)/2$ after factoring the numerator. To derive the variance, integrate $(x-(a+b)/2)^2/(b-a)$ from $a$ to $b$; the result is $(b-a)^2/12$. For a symmetric interval of length $w$, moving both endpoints together shifts the mean but leaves the variance unchanged, because the width is still $w$.

:::example[Example 5.8 — Instructor Exercise 2, herbicide packages]
The net weight $X$ of a packaged chemical herbicide has $f(x)=2.0$ for $49.75<x<50.25$ pounds. (a) Find $P(X>50)$. (b) How much chemical is contained in 90% of the packages?

::::answer[Answer]
**Answer:** (a) 0.5000; (b) 49.8000.

1. The range has width $50.25-49.75=0.50$ pound, and $1/0.50=2.0$, confirming a valid uniform density.
2. (a) $P(X>50)=2.0(50.25-50)=2.0(0.25)=0.50$. Half the packages weigh more than 50 pounds.
3. (b) A cutoff *exceeded by* 90% must have 10% below it. Solve $(k-49.75)/0.50=0.10$, giving $k=49.75+0.05=49.80$.
4. Nine out of ten modeled packages contain more than 49.80 pounds. This interprets the question as a lower 10th-percentile guarantee.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::example[Example 5.9 — Instructor Exercise 4, package-weight density]
A post-office package has density $f(x)=70/(69x^2)$ for $1<x<70$ pounds. Find (a) mean and variance, (b) mean shipping cost at $\$2.50$ per pound, and (c) $P(X>50)$.

::::answer[Answer]
**Answer:** mean 4.3101; variance 51.4233; cost 10.7752; tail 0.0058.

1. Check normalization: $\int_1^{70}70/(69x^2)\,dx=[-70/(69x)]_1^{70}=1$.
2. (a) $\mu=\int_1^{70}70/(69x)\,dx=(70/69)\ln70$. The second moment is $E(X^2)=\int_1^{70}70/69\,dx=70$, so $\sigma^2=70-[(70/69)\ln70]^2$.
3. (b) A linear $\$2.50$ per pound charge has expectation $2.50E(X)$, giving the mean charge in dollars.
4. (c) $P(X>50)=\int_{50}^{70}70/(69x^2)\,dx=(70/69)(1/50-1/70)$.
5. The unusual heavy-left density gives a low mean compared with the upper support 70 pounds; its rightmost 20-pound interval is relatively unlikely.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### What a linear cost does to an expectation

Exercise 4 asks for the average shipping **cost** if a package is charged at a constant price per pound. If a physical weight is $X$ and the price is $c$ dollars per pound, then the cost is $cX$. A constant multiplier simply multiplies the expectation: $E(cX)=cE(X)$. You can see why by inserting the constant inside the mean integral, $\int cxf(x)\,dx=c\int xf(x)\,dx$. This identity is not a separate formula to memorize; it comes from the distributive rule for integration. Keep the units straight: weight mean in pounds times dollars per pound yields dollars.

For Exercise 2, the phrase “How much chemical is contained in 90% of the packages?” can be interpreted as a lower guaranteed content, namely the weight exceeded by 90% of packages. It should not be confused with a *90th percentile*, which 90% of weights are **below**. When the test instead asks *what weight contains the lowest 90%*, use the 90th percentile directly. The two numerical cutoffs are different even for a symmetric uniform model.

:::callout-pitfall[Three distinct quantities: mean, variance, and a percentile]
The mean is an average over all outcomes, the variance measures squared spread, and a percentile is the boundary of a specified left-tail area. For a uniform interval, all three have simple formulas, but only the first has the original units and is guaranteed to be at its midpoint. Never take the square root before subtracting $\mu^2$, and never confuse the physical support with a sample of measured observations.
:::

:::problem[Problem 5.14 — Instructor Exercise 5, aircraft flange thickness]{difficulty=standard}
The thickness of an aircraft-component flange is uniform from 0.95 to 1.05 mm. (a) Determine its CDF for $0.95\leq x\leq1.05$. (b) Find the fraction exceeding 1.02 mm. (c) Find the thickness exceeded by 90% of flanges. (d) Find its mean and variance.

::::solution[Solution]
**Answer:** tail 0.300000; cutoff 0.960000; mean 1.000000; variance 0.000833.

1. (a) The CDF is $0$ below 0.95, $(x-0.95)/0.10$ between 0.95 and 1.05, and $1$ above 1.05.
2. (b) The right strip has length $1.05-1.02=0.03$ out of total width 0.10, giving $P(X>1.02)=0.03/0.10=0.30$.
3. (c) Exceeded by 90% means only 10% below, so $k=0.95+0.10(0.10)=0.96$ mm.
4. (d) The midpoint is $(0.95+1.05)/2=1.00$ mm and the variance is $(0.10)^2/12=0.000833333\ldots$ mm$^2$. These quantities summarize a narrow manufacturing tolerance.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.15 — Exam 2, uniformly distributed part thickness]{difficulty=easy}
The thickness $X$ of a part is uniform between 3.0 and 4.2 mm. Find (a) $P(X<3.5)$ and (b) $V(X)$.

::::solution[Solution]
**Answer:** (a) 0.4167; (b) 0.1200.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. For (a), a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. For (b), a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.16 — Exam 2, hematology cell counter]{difficulty=standard}
The time $X$ to complete a hematology cell-counter test has density $f(x)=0.04$ for $50<x<75$ seconds. (a) What percentage of tests requires more than 70 seconds? (b) What is the mean time?

::::solution[Solution]
**Answer:** probability 0.2000; mean 62.5000.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. For probability, a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
3. For mean, a continuous uniform variable assigns equal probability per unit length, so compare interval lengths to the total support. The mean is the midpoint and variance is the square of the width divided by twelve.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.17 — SI multiple choice, a manufactured rod]{difficulty=easy}
The SI practice test gives rod diameter $X$ uniform on $20<X<30$ mm, with $f(x)=1/10$. What is $P(23<X<27)$? A. 0.20, B. 0.30, C. 0.40, D. 0.70.

::::solution[Solution]
**Answer:** (C) 0.4000.

1. The support length is $30-20=10$ mm. The desired subinterval length is $27-23=4$ mm.
2. The area is the rectangle $P(23<X<27)=(27-23)(1/10)=4/10=0.40$.
3. Choice A counts only two millimeters of width; B miscounts three; D confuses the complement of a 0.30 area with the requested central region.
4. Choice C is correct: 40% of uniformly produced rods lie in the stated four-millimeter diameter range.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.18 — SI independent uniform measurements]{difficulty=challenge}
Three independent random variables $A,B,C$ are each uniform on $[0,8]$. Find (a) $P(A<3)$, (b) $P(B=4)$, (c) the chance that all three are less than 5, and (d) $P(2<A<6)$.

::::solution[Solution]
**Answer:** (a) 0.375000; (b) 0.000000; (c) 0.244141; (d) 0.500000.

1. (a) $P(A<3)=3/8$. (b) $P(B=4)=0$ because a single continuous point has zero area.
2. (c) Each variable has $P(X<5)=5/8$. The question explicitly declares independence, so multiply $P(A<5,B<5,C<5)=(5/8)(5/8)(5/8)=125/512$.
3. (d) The interval from 2 to 6 has width 4, so $P(2<A<6)=4/8=0.5$.
4. Each probability describes a proportion of continuous measurements. Independence is a probability rule from Chapter 3 and does not convert the variables into counts.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.19 — SI: identify the three continuous distributions]{difficulty=standard}
The SI review asks for the models described by (a) constant density on $[2,10]$, (b) a symmetric bell curve about its mean, and (c) a highest-at-zero decreasing density modeling component lifetime.

::::solution[Solution]
**Answer:** (a) continuous uniform; (b) normal; (c) exponential.

1. Constant probability density across a finite interval is the defining shape of the continuous uniform distribution.
2. A symmetric bell-shaped density centered at the mean is the normal model; the standard deviation determines its horizontal spread.
3. The exponential model has density $\lambda e^{-\lambda x}$ for nonnegative time and decreases from its maximum at zero.
4. All three describe measurements, not integer event counts. A Poisson model would instead be used to count arrivals in an interval.

Check: This classification follows directly from what the variable measures.
::::
:::

## 5.4 Exponential Waiting Times and the Poisson Connection

A factory counts breakdowns and also measures the time until the next breakdown. Those are different random variables even when the same underlying process generates them. If the question asks **how many events** occur in a fixed hour, you are counting whole numbers, and the Poisson model from Chapter 4 applies. If the question asks **how long until the next event**, the result can be 1.2 minutes or 1.234 minutes, so it is a continuous waiting time. The instructor's exponential distribution connects these two questions when the arrivals form a Poisson process.

Suppose students arrive at a fixed average rate of 30 per hour. An average rate is not a promise that exactly one student arrives every two minutes. The waiting time is random: sometimes the next arrival is immediate, sometimes the bouncer waits considerably longer. The exponential density is highest at time zero and declines with time, because very long waits have increasingly small probability. That does not mean the next arrival becomes “due” once you have already waited. The exponential distribution is memoryless.

:::definition[Definition 5.5 — Exponential Distribution]
For the waiting time $X$ until the next event in a Poisson process with rate $\lambda>0$ events per unit time,

$$f(x)=\lambda e^{-\lambda x}\quad(x\geq0),\qquad\mu=\frac1\lambda,\qquad\sigma^2=\frac1{\lambda^2}.$$

The integral of this density yields

$$F(t)=P(X\leq t)=1-e^{-\lambda t},\qquad P(X>t)=e^{-\lambda t}.$$

**Final-sheet location:** the exponential density, mean and variance are on **page 2**, in the last row of the distribution table. The area rule and CDF integral are on **page 1**. The survival and CDF expressions follow by integrating the printed density, so they need not be memorized as unrelated formulas.
:::

### What the two exponentials actually mean

Here is the derivation, because the same two expressions are easy to switch accidentally. The probability of failing by time $t$ is the integral from zero to $t$:

$$\int_0^t\lambda e^{-\lambda x}\,dx=[-e^{-\lambda x}]_0^t=-e^{-\lambda t}-(-e^0)=1-e^{-\lambda t}.$$

The leading $\lambda$ cancels because differentiating $-\lambda x$ produces $-\lambda$. More explicitly, differentiating $-e^{-\lambda x}$ yields $-(-\lambda)e^{-\lambda x}=\lambda e^{-\lambda x}$. If you leave a stray factor of $\lambda$ after the integration, your answer is generally not a valid probability.

The event $X>t$ means **no failure has happened yet**, so $P(X>t)=1-P(X\leq t)=e^{-\lambda t}$. The event $X\leq t$ means **a failure has happened by $t$**, so $P(X\leq t)=1-e^{-\lambda t}$. For a band, subtract survivals: $P(a<X<b)=e^{-\lambda a}-e^{-\lambda b}$. These are not arbitrary identities. They come from the area under the exact exponential density printed on your Final sheet.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Exponential density and probability of a short wait">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M42.00,215.00 L42.00,49.78 L43.85,53.05 L45.71,56.26 L47.56,59.40 L49.41,62.49 L51.27,65.51 L53.12,68.47 L54.97,71.37 L56.83,74.21 L58.68,77.00 L60.53,79.73 L62.39,82.41 L64.24,85.04 L66.09,87.61 L67.95,90.13 L69.80,92.60 L71.65,95.03 L73.51,97.40 L75.36,99.73 L77.21,102.01 L79.07,104.25 L80.92,106.44 L82.77,108.59 L84.63,110.70 L86.48,112.77 L88.33,114.79 L90.19,116.77 L92.04,118.72 L93.89,120.63 L95.75,122.50 L97.60,124.33 L99.45,126.12 L101.31,127.88 L103.16,129.61 L105.01,131.30 L106.87,132.96 L108.72,134.58 L110.57,136.17 L112.43,137.73 L114.28,139.26 L116.13,140.76 L117.99,142.23 L119.84,143.67 L121.69,145.09 L123.55,146.47 L125.40,147.83 L127.25,149.16 L129.11,150.46 L130.96,151.74 L132.81,152.99 L134.67,154.22 L136.52,155.42 L138.37,156.60 L140.23,157.76 L142.08,158.89 L143.93,160.00 L145.79,161.09 L147.64,162.16 L149.49,163.21 L151.35,164.23 L153.20,165.24 L155.05,166.22 L156.91,167.19 L158.76,168.14 L160.61,169.06 L162.47,169.97 L164.32,170.86 L166.17,171.74 L168.03,172.60 L169.88,173.43 L171.73,174.26 L173.59,175.06 L175.44,175.86 L177.29,176.63 L179.15,177.39 L181.00,178.14 L181.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,49.78 L43.85,53.05 L45.71,56.26 L47.56,59.40 L49.41,62.49 L51.27,65.51 L53.12,68.47 L54.97,71.37 L56.83,74.21 L58.68,77.00 L60.53,79.73 L62.39,82.41 L64.24,85.04 L66.09,87.61 L67.95,90.13 L69.80,92.60 L71.65,95.03 L73.51,97.40 L75.36,99.73 L77.21,102.01 L79.07,104.25 L80.92,106.44 L82.77,108.59 L84.63,110.70 L86.48,112.77 L88.33,114.79 L90.19,116.77 L92.04,118.72 L93.89,120.63 L95.75,122.50 L97.60,124.33 L99.45,126.12 L101.31,127.88 L103.16,129.61 L105.01,131.30 L106.87,132.96 L108.72,134.58 L110.57,136.17 L112.43,137.73 L114.28,139.26 L116.13,140.76 L117.99,142.23 L119.84,143.67 L121.69,145.09 L123.55,146.47 L125.40,147.83 L127.25,149.16 L129.11,150.46 L130.96,151.74 L132.81,152.99 L134.67,154.22 L136.52,155.42 L138.37,156.60 L140.23,157.76 L142.08,158.89 L143.93,160.00 L145.79,161.09 L147.64,162.16 L149.49,163.21 L151.35,164.23 L153.20,165.24 L155.05,166.22 L156.91,167.19 L158.76,168.14 L160.61,169.06 L162.47,169.97 L164.32,170.86 L166.17,171.74 L168.03,172.60 L169.88,173.43 L171.73,174.26 L173.59,175.06 L175.44,175.86 L177.29,176.63 L179.15,177.39 L181.00,178.14 L182.85,178.86 L184.71,179.58 L186.56,180.28 L188.41,180.97 L190.27,181.64 L192.12,182.30 L193.97,182.95 L195.83,183.59 L197.68,184.21 L199.53,184.82 L201.39,185.42 L203.24,186.00 L205.09,186.58 L206.95,187.14 L208.80,187.69 L210.65,188.23 L212.51,188.76 L214.36,189.28 L216.21,189.79 L218.07,190.29 L219.92,190.78 L221.77,191.26 L223.63,191.73 L225.48,192.19 L227.33,192.64 L229.19,193.08 L231.04,193.52 L232.89,193.94 L234.75,194.36 L236.60,194.77 L238.45,195.17 L240.31,195.56 L242.16,195.95 L244.01,196.32 L245.87,196.69 L247.72,197.06 L249.57,197.41 L251.43,197.76 L253.28,198.10 L255.13,198.44 L256.99,198.76 L258.84,199.08 L260.69,199.40 L262.55,199.71 L264.40,200.01 L266.25,200.31 L268.11,200.60 L269.96,200.88 L271.81,201.16 L273.67,201.44 L275.52,201.71 L277.37,201.97 L279.23,202.23 L281.08,202.48 L282.93,202.73 L284.79,202.97 L286.64,203.21 L288.49,203.44 L290.35,203.67 L292.20,203.90 L294.05,204.12 L295.91,204.33 L297.76,204.54 L299.61,204.75 L301.47,204.95 L303.32,205.15 L305.17,205.35 L307.03,205.54 L308.88,205.73 L310.73,205.91 L312.59,206.09 L314.44,206.27 L316.29,206.44 L318.15,206.61 L320.00,206.77 L321.85,206.94 L323.71,207.10 L325.56,207.25 L327.41,207.41 L329.27,207.56 L331.12,207.70 L332.97,207.85 L334.83,207.99 L336.68,208.13 L338.53,208.27 L340.39,208.40 L342.24,208.53 L344.09,208.66 L345.95,208.78 L347.80,208.91 L349.65,209.03 L351.51,209.15 L353.36,209.26 L355.21,209.37 L357.07,209.49 L358.92,209.60 L360.77,209.70 L362.63,209.81 L364.48,209.91 L366.33,210.01 L368.19,210.11 L370.04,210.21 L371.89,210.30 L373.75,210.39 L375.60,210.49 L377.45,210.58 L379.31,210.66 L381.16,210.75 L383.01,210.83 L384.87,210.92 L386.72,211.00 L388.57,211.08 L390.43,211.15 L392.28,211.23 L394.13,211.30 L395.99,211.38 L397.84,211.45 L399.69,211.52 L401.55,211.59 L403.40,211.66 L405.25,211.72 L407.11,211.79 L408.96,211.85 L410.81,211.91 L412.67,211.97 L414.52,212.03 L416.37,212.09 L418.23,212.15 L420.08,212.21 L421.93,212.26 L423.79,212.32 L425.64,212.37 L427.49,212.42 L429.35,212.47 L431.20,212.52 L433.05,212.57 L434.91,212.62 L436.76,212.67 L438.61,212.71 L440.47,212.76 L442.32,212.80 L444.17,212.85 L446.03,212.89 L447.88,212.93 L449.73,212.97 L451.59,213.01 L453.44,213.05 L455.29,213.09 L457.15,213.13 L459.00,213.16 L460.85,213.20 L462.71,213.24 L464.56,213.27 L466.41,213.31 L468.27,213.34 L470.12,213.37 L471.97,213.40 L473.83,213.44 L475.68,213.47 L477.53,213.50 L479.39,213.53 L481.24,213.56 L483.09,213.58 L484.95,213.61 L486.80,213.64 L488.65,213.67 L490.51,213.69 L492.36,213.72 L494.21,213.74 L496.07,213.77 L497.92,213.79 L499.77,213.82 L501.63,213.84 L503.48,213.86 L505.33,213.89 L507.19,213.91 L509.04,213.93 L510.89,213.95 L512.75,213.97 L514.60,213.99 L516.45,214.01 L518.31,214.03 L520.16,214.05 L522.01,214.07 L523.87,214.09 L525.72,214.11 L527.57,214.12 L529.43,214.14 L531.28,214.16 L533.13,214.18 L534.99,214.19 L536.84,214.21 L538.69,214.22 L540.55,214.24 L542.40,214.25 L544.25,214.27 L546.11,214.28 L547.96,214.30 L549.81,214.31 L551.67,214.32 L553.52,214.34 L555.37,214.35 L557.23,214.36 L559.08,214.38 L560.93,214.39 L562.79,214.40 L564.64,214.41 L566.49,214.42 L568.35,214.44 L570.20,214.45 L572.05,214.46 L573.91,214.47 L575.76,214.48 L577.61,214.49 L579.47,214.50 L581.32,214.51 L583.17,214.52 L585.03,214.53 L586.88,214.54 L588.73,214.55 L590.59,214.56 L592.44,214.57 L594.29,214.57 L596.15,214.58 L598.00,214.59"/>

<text class="fig-label" x="42.0" y="235">0</text><text class="fig-label" x="578" y="235">12</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="34.0" y="231">0</text><text class="fig-label-em" x="173.0" y="231">3</text>
</svg>
<figcaption>For an event rate $\lambda=0.5$ per minute, the probability of waiting no more than three minutes is the shaded area under $0.5e^{-0.5t}$ from zero to three.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Exponential survival curve after three minutes">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M181.00,215.00 L181.00,179.67 L182.85,180.37 L184.71,181.06 L186.56,181.73 L188.41,182.39 L190.27,183.03 L192.12,183.67 L193.97,184.29 L195.83,184.89 L197.68,185.49 L199.53,186.08 L201.39,186.65 L203.24,187.21 L205.09,187.76 L206.95,188.30 L208.80,188.83 L210.65,189.35 L212.51,189.85 L214.36,190.35 L216.21,190.84 L218.07,191.32 L219.92,191.79 L221.77,192.25 L223.63,192.70 L225.48,193.14 L227.33,193.57 L229.19,194.00 L231.04,194.41 L232.89,194.82 L234.75,195.22 L236.60,195.61 L238.45,195.99 L240.31,196.37 L242.16,196.74 L244.01,197.10 L245.87,197.46 L247.72,197.80 L249.57,198.14 L251.43,198.48 L253.28,198.81 L255.13,199.13 L256.99,199.44 L258.84,199.75 L260.69,200.05 L262.55,200.35 L264.40,200.64 L266.25,200.92 L268.11,201.20 L269.96,201.47 L271.81,201.74 L273.67,202.00 L275.52,202.26 L277.37,202.51 L279.23,202.76 L281.08,203.00 L282.93,203.24 L284.79,203.47 L286.64,203.70 L288.49,203.92 L290.35,204.14 L292.20,204.36 L294.05,204.57 L295.91,204.78 L297.76,204.98 L299.61,205.18 L301.47,205.37 L303.32,205.56 L305.17,205.75 L307.03,205.93 L308.88,206.11 L310.73,206.29 L312.59,206.46 L314.44,206.63 L316.29,206.80 L318.15,206.96 L320.00,207.12 L321.85,207.27 L323.71,207.43 L325.56,207.58 L327.41,207.72 L329.27,207.87 L331.12,208.01 L332.97,208.15 L334.83,208.28 L336.68,208.42 L338.53,208.55 L340.39,208.67 L342.24,208.80 L344.09,208.92 L345.95,209.04 L347.80,209.16 L349.65,209.28 L351.51,209.39 L353.36,209.50 L355.21,209.61 L357.07,209.72 L358.92,209.82 L360.77,209.92 L362.63,210.02 L364.48,210.12 L366.33,210.22 L368.19,210.31 L370.04,210.41 L371.89,210.50 L373.75,210.59 L375.60,210.67 L377.45,210.76 L379.31,210.84 L381.16,210.93 L383.01,211.01 L384.87,211.09 L386.72,211.16 L388.57,211.24 L390.43,211.31 L392.28,211.39 L394.13,211.46 L395.99,211.53 L397.84,211.60 L399.69,211.66 L401.55,211.73 L403.40,211.80 L405.25,211.86 L407.11,211.92 L408.96,211.98 L410.81,212.04 L412.67,212.10 L414.52,212.16 L416.37,212.21 L418.23,212.27 L420.08,212.32 L421.93,212.38 L423.79,212.43 L425.64,212.48 L427.49,212.53 L429.35,212.58 L431.20,212.63 L433.05,212.67 L434.91,212.72 L436.76,212.76 L438.61,212.81 L440.47,212.85 L442.32,212.89 L444.17,212.94 L446.03,212.98 L447.88,213.02 L449.73,213.06 L451.59,213.09 L453.44,213.13 L455.29,213.17 L457.15,213.21 L459.00,213.24 L460.85,213.28 L462.71,213.31 L464.56,213.34 L466.41,213.38 L468.27,213.41 L470.12,213.44 L471.97,213.47 L473.83,213.50 L475.68,213.53 L477.53,213.56 L479.39,213.59 L481.24,213.62 L483.09,213.64 L484.95,213.67 L486.80,213.70 L488.65,213.72 L490.51,213.75 L492.36,213.77 L494.21,213.80 L496.07,213.82 L497.92,213.84 L499.77,213.87 L501.63,213.89 L503.48,213.91 L505.33,213.93 L507.19,213.95 L509.04,213.97 L510.89,214.00 L512.75,214.02 L514.60,214.03 L516.45,214.05 L518.31,214.07 L520.16,214.09 L522.01,214.11 L523.87,214.13 L525.72,214.14 L527.57,214.16 L529.43,214.18 L531.28,214.19 L533.13,214.21 L534.99,214.23 L536.84,214.24 L538.69,214.26 L540.55,214.27 L542.40,214.28 L544.25,214.30 L546.11,214.31 L547.96,214.33 L549.81,214.34 L551.67,214.35 L553.52,214.37 L555.37,214.38 L557.23,214.39 L559.08,214.40 L560.93,214.41 L562.79,214.43 L564.64,214.44 L566.49,214.45 L568.35,214.46 L570.20,214.47 L572.05,214.48 L573.91,214.49 L575.76,214.50 L577.61,214.51 L579.47,214.52 L581.32,214.53 L583.17,214.54 L585.03,214.55 L586.88,214.56 L588.73,214.57 L590.59,214.57 L592.44,214.58 L594.29,214.59 L596.15,214.60 L598.00,214.61 L598.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,56.67 L43.85,59.80 L45.71,62.88 L47.56,65.89 L49.41,68.84 L51.27,71.73 L53.12,74.57 L54.97,77.35 L56.83,80.08 L58.68,82.75 L60.53,85.37 L62.39,87.93 L64.24,90.45 L66.09,92.92 L67.95,95.33 L69.80,97.70 L71.65,100.03 L73.51,102.30 L75.36,104.53 L77.21,106.72 L79.07,108.87 L80.92,110.97 L82.77,113.03 L84.63,115.05 L86.48,117.03 L88.33,118.97 L90.19,120.87 L92.04,122.73 L93.89,124.56 L95.75,126.35 L97.60,128.10 L99.45,129.83 L101.31,131.51 L103.16,133.17 L105.01,134.79 L106.87,136.37 L108.72,137.93 L110.57,139.46 L112.43,140.95 L114.28,142.42 L116.13,143.86 L117.99,145.26 L119.84,146.65 L121.69,148.00 L123.55,149.33 L125.40,150.63 L127.25,151.90 L129.11,153.15 L130.96,154.38 L132.81,155.58 L134.67,156.75 L136.52,157.91 L138.37,159.04 L140.23,160.14 L142.08,161.23 L143.93,162.30 L145.79,163.34 L147.64,164.36 L149.49,165.36 L151.35,166.35 L153.20,167.31 L155.05,168.26 L156.91,169.18 L158.76,170.09 L160.61,170.98 L162.47,171.85 L164.32,172.70 L166.17,173.54 L168.03,174.36 L169.88,175.17 L171.73,175.96 L173.59,176.73 L175.44,177.49 L177.29,178.23 L179.15,178.96 L181.00,179.67 L182.85,180.37 L184.71,181.06 L186.56,181.73 L188.41,182.39 L190.27,183.03 L192.12,183.67 L193.97,184.29 L195.83,184.89 L197.68,185.49 L199.53,186.08 L201.39,186.65 L203.24,187.21 L205.09,187.76 L206.95,188.30 L208.80,188.83 L210.65,189.35 L212.51,189.85 L214.36,190.35 L216.21,190.84 L218.07,191.32 L219.92,191.79 L221.77,192.25 L223.63,192.70 L225.48,193.14 L227.33,193.57 L229.19,194.00 L231.04,194.41 L232.89,194.82 L234.75,195.22 L236.60,195.61 L238.45,195.99 L240.31,196.37 L242.16,196.74 L244.01,197.10 L245.87,197.46 L247.72,197.80 L249.57,198.14 L251.43,198.48 L253.28,198.81 L255.13,199.13 L256.99,199.44 L258.84,199.75 L260.69,200.05 L262.55,200.35 L264.40,200.64 L266.25,200.92 L268.11,201.20 L269.96,201.47 L271.81,201.74 L273.67,202.00 L275.52,202.26 L277.37,202.51 L279.23,202.76 L281.08,203.00 L282.93,203.24 L284.79,203.47 L286.64,203.70 L288.49,203.92 L290.35,204.14 L292.20,204.36 L294.05,204.57 L295.91,204.78 L297.76,204.98 L299.61,205.18 L301.47,205.37 L303.32,205.56 L305.17,205.75 L307.03,205.93 L308.88,206.11 L310.73,206.29 L312.59,206.46 L314.44,206.63 L316.29,206.80 L318.15,206.96 L320.00,207.12 L321.85,207.27 L323.71,207.43 L325.56,207.58 L327.41,207.72 L329.27,207.87 L331.12,208.01 L332.97,208.15 L334.83,208.28 L336.68,208.42 L338.53,208.55 L340.39,208.67 L342.24,208.80 L344.09,208.92 L345.95,209.04 L347.80,209.16 L349.65,209.28 L351.51,209.39 L353.36,209.50 L355.21,209.61 L357.07,209.72 L358.92,209.82 L360.77,209.92 L362.63,210.02 L364.48,210.12 L366.33,210.22 L368.19,210.31 L370.04,210.41 L371.89,210.50 L373.75,210.59 L375.60,210.67 L377.45,210.76 L379.31,210.84 L381.16,210.93 L383.01,211.01 L384.87,211.09 L386.72,211.16 L388.57,211.24 L390.43,211.31 L392.28,211.39 L394.13,211.46 L395.99,211.53 L397.84,211.60 L399.69,211.66 L401.55,211.73 L403.40,211.80 L405.25,211.86 L407.11,211.92 L408.96,211.98 L410.81,212.04 L412.67,212.10 L414.52,212.16 L416.37,212.21 L418.23,212.27 L420.08,212.32 L421.93,212.38 L423.79,212.43 L425.64,212.48 L427.49,212.53 L429.35,212.58 L431.20,212.63 L433.05,212.67 L434.91,212.72 L436.76,212.76 L438.61,212.81 L440.47,212.85 L442.32,212.89 L444.17,212.94 L446.03,212.98 L447.88,213.02 L449.73,213.06 L451.59,213.09 L453.44,213.13 L455.29,213.17 L457.15,213.21 L459.00,213.24 L460.85,213.28 L462.71,213.31 L464.56,213.34 L466.41,213.38 L468.27,213.41 L470.12,213.44 L471.97,213.47 L473.83,213.50 L475.68,213.53 L477.53,213.56 L479.39,213.59 L481.24,213.62 L483.09,213.64 L484.95,213.67 L486.80,213.70 L488.65,213.72 L490.51,213.75 L492.36,213.77 L494.21,213.80 L496.07,213.82 L497.92,213.84 L499.77,213.87 L501.63,213.89 L503.48,213.91 L505.33,213.93 L507.19,213.95 L509.04,213.97 L510.89,214.00 L512.75,214.02 L514.60,214.03 L516.45,214.05 L518.31,214.07 L520.16,214.09 L522.01,214.11 L523.87,214.13 L525.72,214.14 L527.57,214.16 L529.43,214.18 L531.28,214.19 L533.13,214.21 L534.99,214.23 L536.84,214.24 L538.69,214.26 L540.55,214.27 L542.40,214.28 L544.25,214.30 L546.11,214.31 L547.96,214.33 L549.81,214.34 L551.67,214.35 L553.52,214.37 L555.37,214.38 L557.23,214.39 L559.08,214.40 L560.93,214.41 L562.79,214.43 L564.64,214.44 L566.49,214.45 L568.35,214.46 L570.20,214.47 L572.05,214.48 L573.91,214.49 L575.76,214.50 L577.61,214.51 L579.47,214.52 L581.32,214.53 L583.17,214.54 L585.03,214.55 L586.88,214.56 L588.73,214.57 L590.59,214.57 L592.44,214.58 L594.29,214.59 L596.15,214.60 L598.00,214.61"/>

<text class="fig-label" x="42.0" y="235">0</text><text class="fig-label" x="578" y="235">12</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="173.0" y="231">3</text><text class="fig-label-em" x="590.0" y="231">12</text>
</svg>
<figcaption>The exponential survival function $P(X>t)=e^{-0.5t}$ decreases from 1; a later cutoff leaves a smaller chance that no event has occurred.</figcaption>
</figure>

### Rate units: the rule that prevents wrong answers

If the mean time between events is 8 years, the rate is $\lambda=1/8$ **per year**. If the arrival rate is 30 **per hour** but the question asks about 3 **minutes**, either convert 3 minutes to $3/60=0.05$ hour or convert the arrival rate to $30/60=0.5$ per minute. The product $\lambda t$ must be dimensionless: events/hour times hours, or events/minute times minutes. Combining 30 per hour with 3 minutes as though 3 were hours gives $e^{-90}$, a wildly incorrect tiny answer.

For intuition, the product $\lambda t$ is the **expected number of arrivals over the interval**. The Poisson count has probability $P(N(t)=0)=e^{-\lambda t}$. Thus the exponential survival probability is the chance of **zero arrivals** in the first $t$ units, which is exactly the event that the first waiting time exceeds $t$. This is the key connection, without re-teaching the Poisson calculation methods owned by Chapter 4.

:::callout-connect[Poisson counts belong to Chapter 4]
Chapter 4, *Discrete Random Variables*, teaches $P(N(t)=k)$ and count-based Poisson questions. In this chapter, the same arrival rate $\lambda$ is used only to analyze **time until the next event**, or to explain why $e^{-\lambda t}$ represents no events yet.
:::

### The lack-of-memory property

Imagine a voltage regulator that has survived six years, with an exponential lifetime model whose mean is six years. You may be tempted to say the regulator has used up its expected life and must now fail soon. An exponential model says the opposite: after you condition on having survived that long, the remaining lifetime has the same exponential distribution as a new regulator. This is a modeling property, not a claim that actual mechanical components never age.

:::theorem[Theorem 5.1 — Memoryless Exponential Waiting]
For $s,t\geq0$ and $X\sim\operatorname{Exponential}(\lambda)$,

$$P(X>s+t\mid X>s)=P(X>t)=e^{-\lambda t}.$$

To see this, divide $P(X>s+t)=e^{-\lambda(s+t)}$ by $P(X>s)=e^{-\lambda s}$; the factor $e^{-\lambda s}$ cancels. The conditional-probability principle is taught in Chapter 3. The instructor notes that among continuous distributions, the exponential distribution uniquely has this lack-of-memory property.
:::

:::example[Example 5.10 — Instructor Exercise 6, six-year voltage regulator]
Automobile voltage-regulator lifetime is exponential with mean six years. You buy a six-year-old car with a working regulator and plan to own it for six more years. (a) What is the probability it fails during your ownership? (b) If the regulator is replaced after you have owned the car for three years, what is the mean time until the replacement fails?

::::answer[Answer]
**Answer:** failure 0.6321; mean replacement life 6.0000.

1. The mean is six years, so the rate is $\lambda=1/6$ per year. The age of the working original regulator is not subtracted from its remaining lifetime under this model.
2. (a) Memorylessness says the next six years have failure probability $1-e^{-(1/6)(6)}=1-e^{-1}$.
3. (b) A newly installed replacement has the same exponential mean $1/\lambda=6$ years, regardless of when the original unit was replaced.
4. Approximately 63.21% of surviving regulators fail over the planned ownership period; the replacement is expected to last six years from installation.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::example[Example 5.11 — Two different questions about thirty arrivals per hour]
Students reach a check-in desk according to a Poisson process averaging 30 arrivals per hour. Find the probability the next arrival occurs only after 3 minutes.

::::answer[Answer]
**Answer:** 0.2231.

1. The response is a waiting time, not a count, so use the exponential distribution.
2. Convert $30$ arrivals/hour to $\lambda=30/60=0.5$ arrivals per minute. Both rate and time now use minutes.
3. The chance of *no arrival* by three minutes is $P(X>3)=e^{-0.5(3)}=e^{-1.5}$.
4. This is the probability the check-in worker has to wait more than three minutes; counting zero arrivals in three minutes would produce the same answer.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### Percentiles and inverse survival

For the 90th percentile of an exponential lifetime, set $1-e^{-\lambda t}=0.90$. Move the exponential to the other side: $e^{-\lambda t}=0.10$. Natural logarithms reverse the exponential: $-\lambda t=\ln(0.10)$, hence $t=-\ln(0.10)/\lambda$. This is a useful place to see why the negative sign matters: $\ln(0.10)$ is negative, and lifetime must be nonnegative. If the question instead says *10% survive longer than $t$*, write $e^{-\lambda t}=0.10$ and get the same cutoff.

The TI-30X IIS has an $\ln$ key. Type the positive decimal inside its parentheses, then divide the resulting negative logarithm by the negative rate. Never type a negative lifetime into $e^{-\lambda t}$ merely to fix a sign mistake. The starting statement, *percentage failed by* or *percentage surviving beyond*, determines which side of the complement you want.

:::callout-pitfall[Counts, time, rate, and memorylessness]
A Poisson random variable counts events: $0,1,2,\dots$. An exponential random variable measures **time** until an event. Converting the units of $\lambda$ is mandatory, not optional. Also, $e^{-\lambda t}$ means no event *yet*; $1-e^{-\lambda t}$ means an event *by* $t$. Finally, surviving for a long time does not subtract that elapsed duration from the exponential distribution's conditional mean.
:::

:::problem[Problem 5.20 — Exam 2, vibration-test assembly life]{difficulty=standard}
The lifetime of a mechanical assembly in a vibration test is exponential with mean 400 hours. Find (a) failure before 100 hours, (b) survival longer than 500 hours, and (c) failure in the next 100 hours given that the assembly already survived 400 hours.

::::solution[Solution]
**Answer:** (a) 0.2212; (b) 0.2865; (c) 0.2212.

1. The rate is $\lambda=1/400=0.0025$ failures per hour. All requested times are in hours, so no unit conversion is needed.
2. (a) Failure by 100 hours: $P(X<100)=1-e^{-100/400}=1-e^{-0.25}$.
3. (b) Survival past 500 hours: $P(X>500)=e^{-500/400}=e^{-1.25}$.
4. (c) Because the assembly has already survived, memorylessness gives $P(X<500\mid X>400)=P(X<100)=1-e^{-0.25}$.
5. The last value equals part (a), even though the assembly is older at the start of the conditional interval.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.21 — Exam 2, bouncer awaiting the next student]{difficulty=easy}
Students arrive at a bar and restaurant according to a Poisson process with mean rate 30 students per hour. What is the probability the bouncer waits more than 3 minutes to card the next student?

::::solution[Solution]
**Answer:** 0.2231.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. the exponential rate is $\lambda=0.5$ per unit. For a wait, $P(X>t)=e^{-\lambda t}$; to find a failure by $t$, take $1-e^{-\lambda t}$, and for a band subtract the two survival values. Here the requested calculation is $\mathrm{tail}$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.22 — SI rechargeable battery lifetime]{difficulty=challenge}
A rechargeable battery lifetime is exponential with average lifespan 8 years. (a) Write its density. (b) Find $P(5<X<10)$. (c) Find $P(X>12)$. (d) Find $t$ such that 90% fail by time $t$.

::::solution[Solution]
**Answer:** between 0.2488; survival 0.2231; 90th percentile years 18.4207.

1. (a) The average is eight years, so $\lambda=1/8=0.125$ per year and $f(x)=0.125e^{-0.125x}$ for $x\geq0$, zero otherwise.
2. (b) Subtract two survivals: $P(5<X<10)=e^{-5/8}-e^{-10/8}$.
3. (c) The chance the battery still works at year 12 is $e^{-12/8}$.
4. (d) Set $1-e^{-t/8}=0.90$. Then $e^{-t/8}=0.10$, $-t/8=\ln(0.10)$, and $t=-8\ln(0.10)$.
5. The cutoff marks the age by which nine in ten modeled batteries have failed.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.23 — SI multiple choice, between Poisson arrivals]{difficulty=easy}
Which distribution models the waiting time between consecutive arrivals in a Poisson process? A. Normal; B. Binomial; C. Exponential; D. Continuous uniform.

::::solution[Solution]
**Answer:** (C) exponential.

1. The question asks for a duration, which can vary continuously rather than only in whole-number steps.
2. An exponential waiting time is the continuous counterpart to a constant-rate Poisson count process.
3. A binomial model needs a fixed number of independent trials; a normal model is bell shaped; a uniform model gives equal density throughout a finite interval.
4. Thus only option C is consistent with both the event-generation process and the continuous waiting variable.

Check: This classification follows directly from what the variable measures.
::::
:::

:::problem[Problem 5.24 — Failure probability during a short shift]{difficulty=standard}
A process has exponentially distributed time until failure with mean 10 hours. Find the probability of failure in the first 2 hours.

::::solution[Solution]
**Answer:** 0.1813.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. the exponential rate is $\lambda=0.1$ per unit. For a wait, $P(X>t)=e^{-\lambda t}$; to find a failure by $t$, take $1-e^{-\lambda t}$, and for a band subtract the two survival values. Here the requested calculation is $\mathrm{cdf}$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.25 — Converting a rate to minutes]{difficulty=standard}
A sensor reports events at an average constant rate of 12 per hour. Assuming exponential interarrival times, what is the chance the next event takes more than 5 minutes?

::::solution[Solution]
**Answer:** 0.3679.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. the exponential rate is $\lambda=0.2$ per unit. For a wait, $P(X>t)=e^{-\lambda t}$; to find a failure by $t$, take $1-e^{-\lambda t}$, and for a band subtract the two survival values. Here the requested calculation is $\mathrm{tail}$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

## 5.5 The Standard Normal Curve and Both Halves of Table III

Some densities are given by elementary functions that you can integrate by hand, such as $x/8$ or $0.05$. The **normal density** is different. Its famous bell-shaped curve is described by a formula, but its area under an arbitrary interval does not have an elementary antiderivative. That is why your final provides **Table III** rather than expecting you to integrate a normal density on a scientific calculator. The table has already done the difficult area calculation. Your job is to translate the wording into an area and read the table accurately.

A **standard normal** variable $Z$ has mean 0 and standard deviation 1. The bell curve is centered at zero. Its left half contains probability 0.5 and its right half contains 0.5. Since the curve is symmetric, the area below $-1$ is the same as the area above $+1$. Since the table always reports the left area, you can obtain right and middle regions through subtraction, even when the question is phrased differently.

:::definition[Definition 5.6 — The Standard Normal Distribution]
A standard normal random variable is $Z\sim N(0,1)$, with $\mu=0$ and $\sigma^2=1$. Its cumulative distribution is

$$\Phi(z)=P(Z\leq z).$$

The normal density has the familiar bell shape, with $f(z)=e^{-z^2/2}/\sqrt{2\pi}$. Its density formula is the normal entry in **Final-sheet page 2**, but you do **not** integrate that expression on the test. **Table III on Final-sheet pages 3–4** gives the six-decimal values of $\Phi(z)$.
:::

### Read what the table actually prints

Turn to the negative part of Table III on page 3. Its row labels are $-3.9,-3.8,\dots,-0.1,0.0$. The columns go **$-0.09,-0.08,\dots,-0.00$ from left to right**. A common first reaction is that the columns are “backward.” They are not backward randomly: the row supplies the tenths and the column supplies the remaining negative hundredths. To locate $z=-1.25$, use row **$-1.2$** and column **$-0.05$**. Moving leftward across that row makes $z$ more negative and its left-tail probability smaller.

On the positive part on page 4, columns increase from **0.00 through 0.09**. To find $\Phi(1.53)$, use row **1.5**, column **0.03**, reading **0.936992** on the final sheet. The instructor's notes round that example to 0.93699. To find $\Phi(1.50)$, use row **1.5**, column **0.00**, giving **0.933193**; her notes show 0.93319. The table provides six decimal places. You can report four decimals if the answer choices use four, but make the subtraction from the six-decimal values before final rounding.

**Always round the computed $z$ to two decimal places before reading Table III.** A $z$-score like 1.326 is not read by using 1.33 in one boundary and 1.326 in another. Round each bound to the table's resolution, then stay consistent. This is a deliberate difference between your exam method and software's exact normal CDF; for the textbook's answers, the printed-table method governs.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Standard normal bell curve with left-tail area marked">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M42.00,215.00 L42.00,214.94 L43.85,214.94 L45.71,214.93 L47.56,214.92 L49.41,214.92 L51.27,214.91 L53.12,214.90 L54.97,214.89 L56.83,214.87 L58.68,214.86 L60.53,214.84 L62.39,214.83 L64.24,214.81 L66.09,214.79 L67.95,214.77 L69.80,214.75 L71.65,214.72 L73.51,214.69 L75.36,214.66 L77.21,214.63 L79.07,214.59 L80.92,214.55 L82.77,214.51 L84.63,214.47 L86.48,214.42 L88.33,214.36 L90.19,214.30 L92.04,214.24 L93.89,214.17 L95.75,214.09 L97.60,214.01 L99.45,213.93 L101.31,213.83 L103.16,213.73 L105.01,213.62 L106.87,213.50 L108.72,213.37 L110.57,213.24 L112.43,213.09 L114.28,212.93 L116.13,212.76 L117.99,212.58 L119.84,212.39 L121.69,212.18 L123.55,211.96 L125.40,211.72 L127.25,211.47 L129.11,211.20 L130.96,210.91 L132.81,210.61 L134.67,210.28 L136.52,209.93 L138.37,209.57 L140.23,209.18 L142.08,208.76 L143.93,208.32 L145.79,207.86 L147.64,207.37 L149.49,206.85 L151.35,206.30 L153.20,205.73 L155.05,205.12 L156.91,204.47 L158.76,203.80 L160.61,203.09 L162.47,202.34 L164.32,201.56 L166.17,200.73 L168.03,199.87 L169.88,198.97 L171.73,198.03 L173.59,197.04 L175.44,196.01 L177.29,194.93 L179.15,193.81 L181.00,192.64 L182.85,191.42 L184.71,190.16 L186.56,188.84 L188.41,187.48 L190.27,186.07 L192.12,184.60 L193.97,183.08 L195.83,181.51 L197.68,179.89 L199.53,178.22 L201.39,176.49 L203.24,174.71 L205.09,172.88 L206.95,171.00 L208.80,169.06 L210.65,167.08 L212.51,165.04 L214.36,162.96 L216.21,160.82 L218.07,158.64 L219.92,156.42 L221.77,154.14 L223.63,151.83 L225.48,149.47 L227.33,147.08 L229.19,144.64 L231.04,142.17 L232.89,139.67 L234.75,137.14 L236.60,134.58 L238.45,131.99 L240.31,129.39 L242.16,126.76 L244.01,124.12 L245.87,121.46 L247.72,118.80 L249.57,116.13 L251.43,113.45 L253.28,110.78 L255.13,108.12 L256.99,105.47 L258.84,102.82 L260.69,100.20 L262.55,97.60 L264.40,95.03 L266.25,92.48 L268.11,89.98 L269.96,87.51 L271.81,85.08 L273.67,82.70 L275.52,80.38 L277.37,78.11 L279.23,75.90 L281.08,73.76 L282.93,71.69 L284.79,69.68 L286.64,67.76 L288.49,65.92 L290.35,64.16 L292.20,62.49 L294.05,60.90 L295.91,59.42 L297.76,58.03 L299.61,56.74 L301.47,55.55 L303.32,54.47 L305.17,53.50 L307.03,52.64 L308.88,51.88 L310.73,51.24 L312.59,50.72 L314.44,50.31 L316.29,50.02 L318.15,49.84 L320.00,49.78 L321.85,49.84 L323.71,50.02 L325.56,50.31 L327.41,50.72 L329.27,51.24 L331.12,51.88 L332.97,52.64 L334.83,53.50 L336.68,54.47 L338.53,55.55 L340.39,56.74 L342.24,58.03 L344.09,59.42 L345.95,60.90 L347.80,62.49 L349.65,64.16 L351.51,65.92 L353.36,67.76 L355.21,69.68 L357.07,71.69 L358.92,73.76 L360.77,75.90 L362.63,78.11 L364.48,80.38 L366.33,82.70 L368.19,85.08 L370.04,87.51 L371.89,89.98 L373.75,92.48 L375.60,95.03 L377.45,97.60 L379.31,100.20 L381.16,102.82 L383.01,105.47 L384.87,108.12 L386.72,110.78 L388.57,113.45 L390.43,116.13 L392.28,118.80 L394.13,121.46 L395.99,124.12 L397.84,126.76 L399.69,129.39 L401.55,131.99 L403.40,134.58 L405.25,137.14 L406.88,139.36 L406.88,215.00 Z"/>
<path class="fig-curve" d="M42.00,214.94 L43.85,214.94 L45.71,214.93 L47.56,214.92 L49.41,214.92 L51.27,214.91 L53.12,214.90 L54.97,214.89 L56.83,214.87 L58.68,214.86 L60.53,214.84 L62.39,214.83 L64.24,214.81 L66.09,214.79 L67.95,214.77 L69.80,214.75 L71.65,214.72 L73.51,214.69 L75.36,214.66 L77.21,214.63 L79.07,214.59 L80.92,214.55 L82.77,214.51 L84.63,214.47 L86.48,214.42 L88.33,214.36 L90.19,214.30 L92.04,214.24 L93.89,214.17 L95.75,214.09 L97.60,214.01 L99.45,213.93 L101.31,213.83 L103.16,213.73 L105.01,213.62 L106.87,213.50 L108.72,213.37 L110.57,213.24 L112.43,213.09 L114.28,212.93 L116.13,212.76 L117.99,212.58 L119.84,212.39 L121.69,212.18 L123.55,211.96 L125.40,211.72 L127.25,211.47 L129.11,211.20 L130.96,210.91 L132.81,210.61 L134.67,210.28 L136.52,209.93 L138.37,209.57 L140.23,209.18 L142.08,208.76 L143.93,208.32 L145.79,207.86 L147.64,207.37 L149.49,206.85 L151.35,206.30 L153.20,205.73 L155.05,205.12 L156.91,204.47 L158.76,203.80 L160.61,203.09 L162.47,202.34 L164.32,201.56 L166.17,200.73 L168.03,199.87 L169.88,198.97 L171.73,198.03 L173.59,197.04 L175.44,196.01 L177.29,194.93 L179.15,193.81 L181.00,192.64 L182.85,191.42 L184.71,190.16 L186.56,188.84 L188.41,187.48 L190.27,186.07 L192.12,184.60 L193.97,183.08 L195.83,181.51 L197.68,179.89 L199.53,178.22 L201.39,176.49 L203.24,174.71 L205.09,172.88 L206.95,171.00 L208.80,169.06 L210.65,167.08 L212.51,165.04 L214.36,162.96 L216.21,160.82 L218.07,158.64 L219.92,156.42 L221.77,154.14 L223.63,151.83 L225.48,149.47 L227.33,147.08 L229.19,144.64 L231.04,142.17 L232.89,139.67 L234.75,137.14 L236.60,134.58 L238.45,131.99 L240.31,129.39 L242.16,126.76 L244.01,124.12 L245.87,121.46 L247.72,118.80 L249.57,116.13 L251.43,113.45 L253.28,110.78 L255.13,108.12 L256.99,105.47 L258.84,102.82 L260.69,100.20 L262.55,97.60 L264.40,95.03 L266.25,92.48 L268.11,89.98 L269.96,87.51 L271.81,85.08 L273.67,82.70 L275.52,80.38 L277.37,78.11 L279.23,75.90 L281.08,73.76 L282.93,71.69 L284.79,69.68 L286.64,67.76 L288.49,65.92 L290.35,64.16 L292.20,62.49 L294.05,60.90 L295.91,59.42 L297.76,58.03 L299.61,56.74 L301.47,55.55 L303.32,54.47 L305.17,53.50 L307.03,52.64 L308.88,51.88 L310.73,51.24 L312.59,50.72 L314.44,50.31 L316.29,50.02 L318.15,49.84 L320.00,49.78 L321.85,49.84 L323.71,50.02 L325.56,50.31 L327.41,50.72 L329.27,51.24 L331.12,51.88 L332.97,52.64 L334.83,53.50 L336.68,54.47 L338.53,55.55 L340.39,56.74 L342.24,58.03 L344.09,59.42 L345.95,60.90 L347.80,62.49 L349.65,64.16 L351.51,65.92 L353.36,67.76 L355.21,69.68 L357.07,71.69 L358.92,73.76 L360.77,75.90 L362.63,78.11 L364.48,80.38 L366.33,82.70 L368.19,85.08 L370.04,87.51 L371.89,89.98 L373.75,92.48 L375.60,95.03 L377.45,97.60 L379.31,100.20 L381.16,102.82 L383.01,105.47 L384.87,108.12 L386.72,110.78 L388.57,113.45 L390.43,116.13 L392.28,118.80 L394.13,121.46 L395.99,124.12 L397.84,126.76 L399.69,129.39 L401.55,131.99 L403.40,134.58 L405.25,137.14 L407.11,139.67 L408.96,142.17 L410.81,144.64 L412.67,147.08 L414.52,149.47 L416.37,151.83 L418.23,154.14 L420.08,156.42 L421.93,158.64 L423.79,160.82 L425.64,162.96 L427.49,165.04 L429.35,167.08 L431.20,169.06 L433.05,171.00 L434.91,172.88 L436.76,174.71 L438.61,176.49 L440.47,178.22 L442.32,179.89 L444.17,181.51 L446.03,183.08 L447.88,184.60 L449.73,186.07 L451.59,187.48 L453.44,188.84 L455.29,190.16 L457.15,191.42 L459.00,192.64 L460.85,193.81 L462.71,194.93 L464.56,196.01 L466.41,197.04 L468.27,198.03 L470.12,198.97 L471.97,199.87 L473.83,200.73 L475.68,201.56 L477.53,202.34 L479.39,203.09 L481.24,203.80 L483.09,204.47 L484.95,205.12 L486.80,205.73 L488.65,206.30 L490.51,206.85 L492.36,207.37 L494.21,207.86 L496.07,208.32 L497.92,208.76 L499.77,209.18 L501.63,209.57 L503.48,209.93 L505.33,210.28 L507.19,210.61 L509.04,210.91 L510.89,211.20 L512.75,211.47 L514.60,211.72 L516.45,211.96 L518.31,212.18 L520.16,212.39 L522.01,212.58 L523.87,212.76 L525.72,212.93 L527.57,213.09 L529.43,213.24 L531.28,213.37 L533.13,213.50 L534.99,213.62 L536.84,213.73 L538.69,213.83 L540.55,213.93 L542.40,214.01 L544.25,214.09 L546.11,214.17 L547.96,214.24 L549.81,214.30 L551.67,214.36 L553.52,214.42 L555.37,214.47 L557.23,214.51 L559.08,214.55 L560.93,214.59 L562.79,214.63 L564.64,214.66 L566.49,214.69 L568.35,214.72 L570.20,214.75 L572.05,214.77 L573.91,214.79 L575.76,214.81 L577.61,214.83 L579.47,214.84 L581.32,214.86 L583.17,214.87 L585.03,214.89 L586.88,214.90 L588.73,214.91 L590.59,214.92 L592.44,214.92 L594.29,214.93 L596.15,214.94 L598.00,214.94"/>

<text class="fig-label" x="42.0" y="235">-4</text><text class="fig-label" x="578" y="235">4</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="34.0" y="231">-4</text><text class="fig-label-em" x="398.9" y="231">1.25</text>
</svg>
<figcaption>Table III reports the shaded left-tail probability $\Phi(1.25)$; the remaining right tail is $1-\Phi(1.25)$.</figcaption>
</figure>

:::example[Example 5.12 — The first two z-table entries in the lecture]
Use Table III to find $P(Z\leq1.50)$ and $P(Z\leq1.53)$ for a standard normal variable.

::::answer[Answer]
**Answer:** first 0.933193; second 0.936992.

1. Look at the positive-z table on Final-sheet page 4. For $z=1.50$, use row 1.5 and column 0.00. The printed value is $\Phi(1.50)=0.933193$.
2. For $z=1.53$, keep row 1.5 but move to column 0.03. The printed value is $\Phi(1.53)=0.936992$.
3. Both are cumulative probabilities to the left of the stated cutoff. The second is larger because the cutoff moves right and adds a narrow strip of bell-curve area.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### Transform the requested event, not the table

There are four recurring formats. For *below*, read $\Phi(z)$ directly. For *above*, use $1-\Phi(z)$. For *between* $a$ and $b$, use $\Phi(b)-\Phi(a)$. For *outside* the band, use $1-[\Phi(b)-\Phi(a)]$. These are all one idea: Table III knows only the area from negative infinity to a cutoff, so rearrange the requested region into those cumulative pieces.

If a cutoff is negative, do not change its sign before looking it up unless you explicitly apply symmetry. The values $\Phi(-0.86)$ and $\Phi(+0.86)$ are completely different cumulative areas. Symmetry says $\Phi(-z)=1-\Phi(z)$. The reason is geometric: reflecting the normal curve swaps the left tail of $-z$ with the right tail of $+z$. This relationship provides a check for either half of the table. For example, $\Phi(-1.00)=0.158655$ and $1-\Phi(1.00)=1-0.841345=0.158655$.

Large-magnitude scores are another case. The Final sheet reaches roughly $\pm3.99$, not $\pm4.60$. A request for $P(Z\leq-4.60)$ is an extraordinarily small tail. At four-decimal exam precision it is **0.0000**, but it is not mathematically exactly zero. Saying “zero to four decimals” preserves the distinction between a printed approximation and an impossible event.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Standard normal probability between a negative and positive cutoff">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M233.12,215.00 L233.12,139.36 L234.75,137.14 L236.60,134.58 L238.45,131.99 L240.31,129.39 L242.16,126.76 L244.01,124.12 L245.87,121.46 L247.72,118.80 L249.57,116.13 L251.43,113.45 L253.28,110.78 L255.13,108.12 L256.99,105.47 L258.84,102.82 L260.69,100.20 L262.55,97.60 L264.40,95.03 L266.25,92.48 L268.11,89.98 L269.96,87.51 L271.81,85.08 L273.67,82.70 L275.52,80.38 L277.37,78.11 L279.23,75.90 L281.08,73.76 L282.93,71.69 L284.79,69.68 L286.64,67.76 L288.49,65.92 L290.35,64.16 L292.20,62.49 L294.05,60.90 L295.91,59.42 L297.76,58.03 L299.61,56.74 L301.47,55.55 L303.32,54.47 L305.17,53.50 L307.03,52.64 L308.88,51.88 L310.73,51.24 L312.59,50.72 L314.44,50.31 L316.29,50.02 L318.15,49.84 L320.00,49.78 L321.85,49.84 L323.71,50.02 L325.56,50.31 L327.41,50.72 L329.27,51.24 L331.12,51.88 L332.97,52.64 L334.83,53.50 L336.68,54.47 L338.53,55.55 L340.39,56.74 L342.24,58.03 L344.09,59.42 L345.72,60.71 L345.72,215.00 Z"/>
<path class="fig-curve" d="M42.00,214.94 L43.85,214.94 L45.71,214.93 L47.56,214.92 L49.41,214.92 L51.27,214.91 L53.12,214.90 L54.97,214.89 L56.83,214.87 L58.68,214.86 L60.53,214.84 L62.39,214.83 L64.24,214.81 L66.09,214.79 L67.95,214.77 L69.80,214.75 L71.65,214.72 L73.51,214.69 L75.36,214.66 L77.21,214.63 L79.07,214.59 L80.92,214.55 L82.77,214.51 L84.63,214.47 L86.48,214.42 L88.33,214.36 L90.19,214.30 L92.04,214.24 L93.89,214.17 L95.75,214.09 L97.60,214.01 L99.45,213.93 L101.31,213.83 L103.16,213.73 L105.01,213.62 L106.87,213.50 L108.72,213.37 L110.57,213.24 L112.43,213.09 L114.28,212.93 L116.13,212.76 L117.99,212.58 L119.84,212.39 L121.69,212.18 L123.55,211.96 L125.40,211.72 L127.25,211.47 L129.11,211.20 L130.96,210.91 L132.81,210.61 L134.67,210.28 L136.52,209.93 L138.37,209.57 L140.23,209.18 L142.08,208.76 L143.93,208.32 L145.79,207.86 L147.64,207.37 L149.49,206.85 L151.35,206.30 L153.20,205.73 L155.05,205.12 L156.91,204.47 L158.76,203.80 L160.61,203.09 L162.47,202.34 L164.32,201.56 L166.17,200.73 L168.03,199.87 L169.88,198.97 L171.73,198.03 L173.59,197.04 L175.44,196.01 L177.29,194.93 L179.15,193.81 L181.00,192.64 L182.85,191.42 L184.71,190.16 L186.56,188.84 L188.41,187.48 L190.27,186.07 L192.12,184.60 L193.97,183.08 L195.83,181.51 L197.68,179.89 L199.53,178.22 L201.39,176.49 L203.24,174.71 L205.09,172.88 L206.95,171.00 L208.80,169.06 L210.65,167.08 L212.51,165.04 L214.36,162.96 L216.21,160.82 L218.07,158.64 L219.92,156.42 L221.77,154.14 L223.63,151.83 L225.48,149.47 L227.33,147.08 L229.19,144.64 L231.04,142.17 L232.89,139.67 L234.75,137.14 L236.60,134.58 L238.45,131.99 L240.31,129.39 L242.16,126.76 L244.01,124.12 L245.87,121.46 L247.72,118.80 L249.57,116.13 L251.43,113.45 L253.28,110.78 L255.13,108.12 L256.99,105.47 L258.84,102.82 L260.69,100.20 L262.55,97.60 L264.40,95.03 L266.25,92.48 L268.11,89.98 L269.96,87.51 L271.81,85.08 L273.67,82.70 L275.52,80.38 L277.37,78.11 L279.23,75.90 L281.08,73.76 L282.93,71.69 L284.79,69.68 L286.64,67.76 L288.49,65.92 L290.35,64.16 L292.20,62.49 L294.05,60.90 L295.91,59.42 L297.76,58.03 L299.61,56.74 L301.47,55.55 L303.32,54.47 L305.17,53.50 L307.03,52.64 L308.88,51.88 L310.73,51.24 L312.59,50.72 L314.44,50.31 L316.29,50.02 L318.15,49.84 L320.00,49.78 L321.85,49.84 L323.71,50.02 L325.56,50.31 L327.41,50.72 L329.27,51.24 L331.12,51.88 L332.97,52.64 L334.83,53.50 L336.68,54.47 L338.53,55.55 L340.39,56.74 L342.24,58.03 L344.09,59.42 L345.95,60.90 L347.80,62.49 L349.65,64.16 L351.51,65.92 L353.36,67.76 L355.21,69.68 L357.07,71.69 L358.92,73.76 L360.77,75.90 L362.63,78.11 L364.48,80.38 L366.33,82.70 L368.19,85.08 L370.04,87.51 L371.89,89.98 L373.75,92.48 L375.60,95.03 L377.45,97.60 L379.31,100.20 L381.16,102.82 L383.01,105.47 L384.87,108.12 L386.72,110.78 L388.57,113.45 L390.43,116.13 L392.28,118.80 L394.13,121.46 L395.99,124.12 L397.84,126.76 L399.69,129.39 L401.55,131.99 L403.40,134.58 L405.25,137.14 L407.11,139.67 L408.96,142.17 L410.81,144.64 L412.67,147.08 L414.52,149.47 L416.37,151.83 L418.23,154.14 L420.08,156.42 L421.93,158.64 L423.79,160.82 L425.64,162.96 L427.49,165.04 L429.35,167.08 L431.20,169.06 L433.05,171.00 L434.91,172.88 L436.76,174.71 L438.61,176.49 L440.47,178.22 L442.32,179.89 L444.17,181.51 L446.03,183.08 L447.88,184.60 L449.73,186.07 L451.59,187.48 L453.44,188.84 L455.29,190.16 L457.15,191.42 L459.00,192.64 L460.85,193.81 L462.71,194.93 L464.56,196.01 L466.41,197.04 L468.27,198.03 L470.12,198.97 L471.97,199.87 L473.83,200.73 L475.68,201.56 L477.53,202.34 L479.39,203.09 L481.24,203.80 L483.09,204.47 L484.95,205.12 L486.80,205.73 L488.65,206.30 L490.51,206.85 L492.36,207.37 L494.21,207.86 L496.07,208.32 L497.92,208.76 L499.77,209.18 L501.63,209.57 L503.48,209.93 L505.33,210.28 L507.19,210.61 L509.04,210.91 L510.89,211.20 L512.75,211.47 L514.60,211.72 L516.45,211.96 L518.31,212.18 L520.16,212.39 L522.01,212.58 L523.87,212.76 L525.72,212.93 L527.57,213.09 L529.43,213.24 L531.28,213.37 L533.13,213.50 L534.99,213.62 L536.84,213.73 L538.69,213.83 L540.55,213.93 L542.40,214.01 L544.25,214.09 L546.11,214.17 L547.96,214.24 L549.81,214.30 L551.67,214.36 L553.52,214.42 L555.37,214.47 L557.23,214.51 L559.08,214.55 L560.93,214.59 L562.79,214.63 L564.64,214.66 L566.49,214.69 L568.35,214.72 L570.20,214.75 L572.05,214.77 L573.91,214.79 L575.76,214.81 L577.61,214.83 L579.47,214.84 L581.32,214.86 L583.17,214.87 L585.03,214.89 L586.88,214.90 L588.73,214.91 L590.59,214.92 L592.44,214.92 L594.29,214.93 L596.15,214.94 L598.00,214.94"/>

<text class="fig-label" x="42.0" y="235">-4</text><text class="fig-label" x="578" y="235">4</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="225.1" y="231">-1.25</text><text class="fig-label-em" x="337.7" y="231">0.37</text>
</svg>
<figcaption>A probability between two z-scores is the area from the negative cutoff to the positive cutoff, calculated by subtracting their cumulative table entries.</figcaption>
</figure>

:::example[Example 5.13 — Instructor Exercise 7, seven standard-normal tasks]
Using the standard normal tables, find (1) $P(Z>1.26)$, (2) $P(Z<-0.86)$, (3) $P(Z>-1.37)$, (4) $P(-1.25<Z<0.37)$, (5) $P(Z\leq-4.6)$ to four decimals, (6) $z$ with $P(Z>z)=0.05$, and (7) positive $z$ with $P(-z<Z<z)=0.99$.

::::answer[Answer]
**Answer:** (1) 0.1038; (2) 0.1949; (3) 0.9147; (4) 0.5387; (5) 0.0000; (6) 1.6400; (7) 2.5800.

1. (1) The positive table at row 1.2, column 0.06 gives $\Phi(1.26)=0.896165$; the requested upper tail is $1-0.896165$.
2. (2) On the negative page, row -0.8, column -0.06 gives $\Phi(-0.86)=0.194895$.
3. (3) Row -1.3, column -0.07 gives $\Phi(-1.37)=0.085343$; the area above is $1-0.085343$.
4. (4) Row -1.2, column -0.05 gives $\Phi(-1.25)=0.105650$; row 0.3, column 0.07 gives $\Phi(0.37)=0.644309$. Subtract: $0.644309-0.105650$.
5. (5) The printed range does not reach -4.60; this tiny lower tail rounds to 0.0000 at four decimals.
6. (6) The desired left area is 0.9500. Search the positive table: 1.64 gives 0.949497 and 1.65 gives 0.950529; the closer printed entry is 1.64.
7. (7) Central area 0.99 leaves 0.005 in each tail, so seek left area 0.995. Row 2.5, column 0.08 gives $\Phi(2.58)=0.995060$, the nearest printed entry. The computed cutoffs are in standard-deviation units.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### Reverse table lookups, including top and middle percentages

When you are asked to find $z$ rather than a probability, begin with an area. If 90% of observations are below the cutoff, find the entry closest to 0.900000 in the **body** of Table III, then read the row and column back to obtain $z$. This is the reverse of the usual procedure. If 5% are above a cutoff, the body of the table must be searched near 0.950000, not 0.050000. The complement belongs in the probability before the lookup.

For a central 99% interval, symmetry splits the probability outside the interval into two tails. Total outside area is $1-0.99=0.01$, and each tail is $0.005$. The upper cutoff therefore has cumulative area $0.995$, and its reflected negative cutoff has cumulative area $0.005$. The two ends should have the same magnitude and opposite signs. Similar reasoning works for a central 90% region: search for 0.95 to find its upper cutoff.

**Precision judgment:** with a two-hundredths-resolution table, some target areas fall between two adjacent entries. Selecting the closer *printed* value gives the best answer using the stipulated no-software method. For 0.950000, row 1.6 column 0.04 has 0.949497 and row 1.6 column 0.05 has 0.950529. The first differs by 0.000503 and the second by 0.000529, so the nearer printed entry is **1.64**. A textbook using interpolation or an inverse-normal calculator might print 1.645 or 1.64485; that is not a lookup made solely from one table cell. The SI review key likewise uses 1.64 for a top-5% score.

:::callout-pitfall[Negative columns, flipped tails, and premature rounding]
For $z=-1.25$, use **row -1.2 and column -0.05**, not row -1.2 and column -0.05 on the positive page, and not $+1.25$. The table's entries are **left-tail areas**; a question using “above” requires a complement. For a between-region, subtract the two six-decimal entries and round only once afterward. For a percentile, convert “top 5%” into “95% below” before seeking a table cell.
:::

:::problem[Problem 5.26 — Homework 6, five standard-normal lookups]{difficulty=standard}
Let $Z$ be standard normal. Find (a) $P(Z<1.25)$, (b) $P(Z>-0.85)$, (c) $P(-1.5<Z<2.0)$, (d) $P(Z>1.75)$, and (e) $z$ such that $P(Z<z)=0.90$.

::::solution[Solution]
**Answer:** (a) 0.894350; (b) 0.802337; (c) 0.910443; (d) 0.040059; (e) 1.280000.

1. (a) At row 1.2, column 0.05, $\Phi(1.25)=0.894350$.
2. (b) At row -0.8, column -0.05, $\Phi(-0.85)=0.197663$; take $1-0.197663$.
3. (c) Rows 2.0 column 0.00 and -1.5 column -0.00 give 0.977250 and 0.066807; subtract to obtain the central band.
4. (d) Row 1.7, column 0.05 gives $\Phi(1.75)=0.959941$, so the upper tail is the complement.
5. (e) Find the table body nearest 0.900000. Row 1.2, column 0.08 gives 0.899727, so the two-decimal score is 1.28.
6. All probabilities are left or right regions of the same bell curve, not separate distributions.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.27 — SI multiple choice, negative z to zero]{difficulty=easy}
For standard normal $Z$, what is $P(-1<Z<0)$? Choose A. 0.1587; B. 0.3413; C. 0.5000; D. 0.8413.

::::solution[Solution]
**Answer:** (B) 0.3413.

1. Compute $\Phi(0)-\Phi(-1.00)$, because the desired interval is bounded on both sides.
2. On Table III, row 0.0 column 0.00 is $\Phi(0)=0.500000$. On the negative page, row -1.0 column -0.00 is $\Phi(-1)=0.158655$.
3. The subtraction gives 0.341345, or 0.3413 to four decimals. A is the lower tail below -1; C is a whole half of the curve; D is the area below +1.
4. The correct middle-band answer is B.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.28 — Positive z right-tail calculation]{difficulty=easy}
Use Table III to find $P(Z>0.83)$.

::::solution[Solution]
**Answer:** 0.203269.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. standardize each boundary and use the printed cumulative table: $z=(0.83-0)/1=0.83$; Table III row 0.8, column 0.03, gives $\Phi(0.83)=0.796731$.
3. The table is a *left-tail* probability, so subtract from one to obtain the probability to the right.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.29 — A negative-z right tail]{difficulty=standard}
Use Table III to calculate $P(Z>-0.42)$.

::::solution[Solution]
**Answer:** 0.662757.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. standardize each boundary and use the printed cumulative table: $z=(-0.42-0)/1=-0.42$; Table III row -0.4, column -0.02, gives $\Phi(-0.42)=0.337243$.
3. The table is a *left-tail* probability, so subtract from one to obtain the probability to the right.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.30 — Central ninety-percent standard-normal interval]{difficulty=standard}
Find the positive two-decimal cutoff $z$ for which $P(-z<Z<z)$ is approximately 0.90 using only Table III.

::::solution[Solution]
**Answer:** 1.64.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. look up the desired left-tail area 0.9500 backward in Table III. The nearest printed entry is $\Phi(1.64)=0.949497$ at row 1.6, column 0.04.
3. Convert the standardized cutoff to the original units: $x=\mu+z\sigma=0+(1.64)(1)$.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.31 — Find the lowest two percent]{difficulty=challenge}
Find the two-decimal $z$ value with $P(Z<z)\approx0.02$ by the closest printed Table III entry.

::::solution[Solution]
**Answer:** -2.05.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. look up the desired left-tail area 0.0200 backward in Table III. The nearest printed entry is $\Phi(-2.05)=0.020182$ at row -2.0, column -0.05.
3. Convert the standardized cutoff to the original units: $x=\mu+z\sigma=0+(-2.05)(1)$.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

## 5.6 Normal Engineering Measurements: Convert X to Z and Back

An ordinary normal random variable $X$ does not have to have mean zero or standard deviation one. The wire current in the instructor's notes has mean 10 mA and variance 4 mA$^2$. The manufacturing shaft in Homework 6 has mean 50 mm and standard deviation 2 mm. The first normal variable is measured in milliamperes, the second in millimeters, and the table knows neither physical unit. **Standardization** converts both to the same universal ruler: the number of standard deviations a measurement sits above or below its mean.

If $x$ is above the mean, its $z$ is positive; if it is below the mean, its $z$ is negative. A measurement exactly equal to the mean has $z=0$. If the standard deviation is 2 and a measurement is 6 above the mean, then $z=6/2=3$. Three standard deviations above the mean is far out in the upper tail regardless of whether the original measurement is inches, grams, or electrical current. Standardization changes the horizontal scale but does not change which outcomes lie below which cutoff.

:::definition[Definition 5.7 — Standardizing a Normal Variable]
If $X\sim N(\mu,\sigma^2)$ with $\sigma>0$, then

$$Z=\frac{X-\mu}{\sigma}\sim N(0,1),\qquad z=\frac{x-\mu}{\sigma}.$$

Consequently,

$$P(X\leq x)=\Phi\!\left(\frac{x-\mu}{\sigma}\right).$$

**Final-sheet location:** the formula $z=(x-\mu)/\sigma$ is at the **bottom left of page 1**. The normal distribution notation, mean and variance are on **page 2**. Table III, **pages 3–4**, supplies the cumulative probability after standardization.
:::

### The two directions of normal problems

In a **forward** problem, the machine measurement is supplied and the probability is unknown. Write $z=(x-\mu)/\sigma$, round $z$ to two decimals, and use the table for an area. A statement such as “how many cans are scrapped?” asks for the tails outside the acceptance interval. You can calculate the interior and subtract from one, or add the two separate tails. These are the same result; using one minus the interior is usually less error-prone when both sides are specified.

In a **reverse** problem, the probability is supplied and the measurement is unknown. Determine the left cumulative area, read the corresponding $z$ from the table, and solve the standardization equation for the original value:

$$x=\mu+z\sigma.$$

This last equation is just $z=(x-\mu)/\sigma$ rearranged: multiply both sides by $\sigma$ to get $z\sigma=x-\mu$, then add $\mu$ to both sides. It is not an additional formula to memorize. The sign of $z$ automatically handles whether the cutoff is below or above the mean.

You will sometimes see $N(50,2^2)$ rather than $N(50,2)$. The **second normal parameter is the variance** $\sigma^2$, not the standard deviation. Therefore $N(50,2^2)$ means mean 50 and variance 4, so the standard deviation used in the denominator is 2. Conversely $N(10,4)$ means $\sigma=\sqrt4=2$, not 4. This notation causes avoidable mistakes whenever a problem gives a variance in squared physical units.

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 640 240" width="640" height="240" role="img" aria-label="Normally distributed wire current with scrap right tail">
<path class="fig-axis" d="M 42 215 L 598 215 M 42 215 L 42 25"/>
<path class="fig-fill" d="M424.25,215.00 L424.25,161.36 L425.64,162.96 L427.49,165.04 L429.35,167.08 L431.20,169.06 L433.05,171.00 L434.91,172.88 L436.76,174.71 L438.61,176.49 L440.47,178.22 L442.32,179.89 L444.17,181.51 L446.03,183.08 L447.88,184.60 L449.73,186.07 L451.59,187.48 L453.44,188.84 L455.29,190.16 L457.15,191.42 L459.00,192.64 L460.85,193.81 L462.71,194.93 L464.56,196.01 L466.41,197.04 L468.27,198.03 L470.12,198.97 L471.97,199.87 L473.83,200.73 L475.68,201.56 L477.53,202.34 L479.39,203.09 L481.24,203.80 L483.09,204.47 L484.95,205.12 L486.80,205.73 L488.65,206.30 L490.51,206.85 L492.36,207.37 L494.21,207.86 L496.07,208.32 L497.92,208.76 L499.77,209.18 L501.63,209.57 L503.48,209.93 L505.33,210.28 L507.19,210.61 L509.04,210.91 L510.89,211.20 L512.75,211.47 L514.60,211.72 L516.45,211.96 L518.31,212.18 L520.16,212.39 L522.01,212.58 L523.87,212.76 L525.72,212.93 L527.57,213.09 L529.43,213.24 L531.28,213.37 L533.13,213.50 L534.99,213.62 L536.84,213.73 L538.69,213.83 L540.55,213.93 L542.40,214.01 L544.25,214.09 L546.11,214.17 L547.96,214.24 L549.81,214.30 L551.67,214.36 L553.52,214.42 L555.37,214.47 L557.23,214.51 L559.08,214.55 L560.93,214.59 L562.79,214.63 L564.64,214.66 L566.49,214.69 L568.35,214.72 L570.20,214.75 L572.05,214.77 L573.91,214.79 L575.76,214.81 L577.61,214.83 L579.47,214.84 L581.32,214.86 L583.17,214.87 L585.03,214.89 L586.88,214.90 L588.73,214.91 L590.59,214.92 L592.44,214.92 L594.29,214.93 L596.15,214.94 L598.00,214.94 L598.00,215.00 Z"/>
<path class="fig-curve" d="M42.00,214.94 L43.85,214.94 L45.71,214.93 L47.56,214.92 L49.41,214.92 L51.27,214.91 L53.12,214.90 L54.97,214.89 L56.83,214.87 L58.68,214.86 L60.53,214.84 L62.39,214.83 L64.24,214.81 L66.09,214.79 L67.95,214.77 L69.80,214.75 L71.65,214.72 L73.51,214.69 L75.36,214.66 L77.21,214.63 L79.07,214.59 L80.92,214.55 L82.77,214.51 L84.63,214.47 L86.48,214.42 L88.33,214.36 L90.19,214.30 L92.04,214.24 L93.89,214.17 L95.75,214.09 L97.60,214.01 L99.45,213.93 L101.31,213.83 L103.16,213.73 L105.01,213.62 L106.87,213.50 L108.72,213.37 L110.57,213.24 L112.43,213.09 L114.28,212.93 L116.13,212.76 L117.99,212.58 L119.84,212.39 L121.69,212.18 L123.55,211.96 L125.40,211.72 L127.25,211.47 L129.11,211.20 L130.96,210.91 L132.81,210.61 L134.67,210.28 L136.52,209.93 L138.37,209.57 L140.23,209.18 L142.08,208.76 L143.93,208.32 L145.79,207.86 L147.64,207.37 L149.49,206.85 L151.35,206.30 L153.20,205.73 L155.05,205.12 L156.91,204.47 L158.76,203.80 L160.61,203.09 L162.47,202.34 L164.32,201.56 L166.17,200.73 L168.03,199.87 L169.88,198.97 L171.73,198.03 L173.59,197.04 L175.44,196.01 L177.29,194.93 L179.15,193.81 L181.00,192.64 L182.85,191.42 L184.71,190.16 L186.56,188.84 L188.41,187.48 L190.27,186.07 L192.12,184.60 L193.97,183.08 L195.83,181.51 L197.68,179.89 L199.53,178.22 L201.39,176.49 L203.24,174.71 L205.09,172.88 L206.95,171.00 L208.80,169.06 L210.65,167.08 L212.51,165.04 L214.36,162.96 L216.21,160.82 L218.07,158.64 L219.92,156.42 L221.77,154.14 L223.63,151.83 L225.48,149.47 L227.33,147.08 L229.19,144.64 L231.04,142.17 L232.89,139.67 L234.75,137.14 L236.60,134.58 L238.45,131.99 L240.31,129.39 L242.16,126.76 L244.01,124.12 L245.87,121.46 L247.72,118.80 L249.57,116.13 L251.43,113.45 L253.28,110.78 L255.13,108.12 L256.99,105.47 L258.84,102.82 L260.69,100.20 L262.55,97.60 L264.40,95.03 L266.25,92.48 L268.11,89.98 L269.96,87.51 L271.81,85.08 L273.67,82.70 L275.52,80.38 L277.37,78.11 L279.23,75.90 L281.08,73.76 L282.93,71.69 L284.79,69.68 L286.64,67.76 L288.49,65.92 L290.35,64.16 L292.20,62.49 L294.05,60.90 L295.91,59.42 L297.76,58.03 L299.61,56.74 L301.47,55.55 L303.32,54.47 L305.17,53.50 L307.03,52.64 L308.88,51.88 L310.73,51.24 L312.59,50.72 L314.44,50.31 L316.29,50.02 L318.15,49.84 L320.00,49.78 L321.85,49.84 L323.71,50.02 L325.56,50.31 L327.41,50.72 L329.27,51.24 L331.12,51.88 L332.97,52.64 L334.83,53.50 L336.68,54.47 L338.53,55.55 L340.39,56.74 L342.24,58.03 L344.09,59.42 L345.95,60.90 L347.80,62.49 L349.65,64.16 L351.51,65.92 L353.36,67.76 L355.21,69.68 L357.07,71.69 L358.92,73.76 L360.77,75.90 L362.63,78.11 L364.48,80.38 L366.33,82.70 L368.19,85.08 L370.04,87.51 L371.89,89.98 L373.75,92.48 L375.60,95.03 L377.45,97.60 L379.31,100.20 L381.16,102.82 L383.01,105.47 L384.87,108.12 L386.72,110.78 L388.57,113.45 L390.43,116.13 L392.28,118.80 L394.13,121.46 L395.99,124.12 L397.84,126.76 L399.69,129.39 L401.55,131.99 L403.40,134.58 L405.25,137.14 L407.11,139.67 L408.96,142.17 L410.81,144.64 L412.67,147.08 L414.52,149.47 L416.37,151.83 L418.23,154.14 L420.08,156.42 L421.93,158.64 L423.79,160.82 L425.64,162.96 L427.49,165.04 L429.35,167.08 L431.20,169.06 L433.05,171.00 L434.91,172.88 L436.76,174.71 L438.61,176.49 L440.47,178.22 L442.32,179.89 L444.17,181.51 L446.03,183.08 L447.88,184.60 L449.73,186.07 L451.59,187.48 L453.44,188.84 L455.29,190.16 L457.15,191.42 L459.00,192.64 L460.85,193.81 L462.71,194.93 L464.56,196.01 L466.41,197.04 L468.27,198.03 L470.12,198.97 L471.97,199.87 L473.83,200.73 L475.68,201.56 L477.53,202.34 L479.39,203.09 L481.24,203.80 L483.09,204.47 L484.95,205.12 L486.80,205.73 L488.65,206.30 L490.51,206.85 L492.36,207.37 L494.21,207.86 L496.07,208.32 L497.92,208.76 L499.77,209.18 L501.63,209.57 L503.48,209.93 L505.33,210.28 L507.19,210.61 L509.04,210.91 L510.89,211.20 L512.75,211.47 L514.60,211.72 L516.45,211.96 L518.31,212.18 L520.16,212.39 L522.01,212.58 L523.87,212.76 L525.72,212.93 L527.57,213.09 L529.43,213.24 L531.28,213.37 L533.13,213.50 L534.99,213.62 L536.84,213.73 L538.69,213.83 L540.55,213.93 L542.40,214.01 L544.25,214.09 L546.11,214.17 L547.96,214.24 L549.81,214.30 L551.67,214.36 L553.52,214.42 L555.37,214.47 L557.23,214.51 L559.08,214.55 L560.93,214.59 L562.79,214.63 L564.64,214.66 L566.49,214.69 L568.35,214.72 L570.20,214.75 L572.05,214.77 L573.91,214.79 L575.76,214.81 L577.61,214.83 L579.47,214.84 L581.32,214.86 L583.17,214.87 L585.03,214.89 L586.88,214.90 L588.73,214.91 L590.59,214.92 L592.44,214.92 L594.29,214.93 L596.15,214.94 L598.00,214.94"/>

<text class="fig-label" x="42.0" y="235">2</text><text class="fig-label" x="578" y="235">18</text><text class="fig-label" x="8" y="22">f(x)</text><text class="fig-label-em" x="416.2" y="231">13</text><text class="fig-label-em" x="590.0" y="231">18</text>
</svg>
<figcaption>For $X\sim N(10,4)$, a current above 13 mA is $1.50$ standard deviations above the mean, and its shaded upper-tail probability is $1-\Phi(1.50)$.</figcaption>
</figure>

:::example[Example 5.14 — Instructor Exercise 8, current in a strip of wire]
Wire current $X$ is normal with mean 10 mA and variance 4 mA$^2$. Find (a) the chance a measurement exceeds 13 mA and (b) the chance a measurement falls between 9 and 11 mA.

::::answer[Answer]
**Answer:** (a) 0.066807; (b) 0.382924.

1. The variance is $\sigma^2=4$, hence the standard deviation is $\sigma=2$ mA. This is the number to divide by, not 4.
2. (a) $z=(13-10)/2=1.50$. Final-sheet page 4, row 1.5 column 0.00 gives $\Phi(1.50)=0.933193$. The upper tail is $1-0.933193$.
3. (b) For 9 mA, $z=-0.50$ and row -0.5 column -0.00 gives 0.308538; for 11 mA, $z=0.50$ and row 0.5 column 0.00 gives 0.691462. The middle area is $0.691462-0.308538$.
4. These probabilities are proportions of current measurements, not current values themselves.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### Specifications and the two-tail scrap calculation

An engineering specification is not automatically centered on the current process mean. The target diameter might be 0.2500 inch while the actual process mean is 0.2508 inch. If the allowed interval is symmetric around the **target**, it is still asymmetric around the **actual mean**, so its $z$ boundaries will not be opposites. This explains why centering a manufacturing process can dramatically improve the proportion of conforming parts even without changing its standard deviation.

The notation $0.2500\pm0.0015$ defines two actual endpoints. The lower specification is $0.2500-0.0015=0.2485$; the upper is $0.2500+0.0015=0.2515$. Work out those endpoints before standardizing. Compute two distinct scores using the **actual** mean in the question, find the band between them, and only then decide whether the question requests conforming or scrapped pieces.

:::callout-intuition[Why moving the mean matters]
A normal bell curve concentrates probability near its center. If that center is offset toward one specification boundary, one tail can cross a boundary much more often than the opposite tail. Moving the center to the midpoint of the specifications allows the accepted interval to contain more of the high-density middle of the bell. Centering changes $\mu$ while leaving $\sigma$ alone in the instructor's two-process comparison.
:::

:::example[Example 5.15 — Instructor Exercise 9, shaft specifications and recentering]
Shaft diameter is normal with mean 0.2508 inch and standard deviation 0.0005 inch. Specifications are $0.2500\pm0.0015$ inch. (a) Find the proportion conforming. (b) If the mean is recentered to 0.2500 inch, find the conforming proportion.

::::answer[Answer]
**Answer:** (a) 0.9192; (b) 0.9973.

1. The specification interval is $[0.2485,0.2515]$ inch. These are physical diameters, not $z$ values.
2. (a) For the existing mean, $z_L=(0.2485-0.2508)/0.0005=-4.60$ and $z_U=(0.2515-0.2508)/0.0005=1.40$. Table III row 1.4, column 0.00 gives 0.919243. The extremely small left tail below -4.60 is outside Table III; at four decimal places, treat it as 0.0000, so the conforming fraction is about 0.9192.
3. (b) With new mean 0.2500, the limits standardize to -3.00 and +3.00. On page 3, row -3.0 column -0.00 gives 0.001350; on page 4, row 3.0 column 0.00 gives 0.998650. Subtract.
4. Recentering the process without narrowing the spread increases the conforming proportion because the acceptance interval surrounds the center of the bell.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::example[Example 5.16 — Instructor Exercise 10, fill volume and symmetric specifications]
An automated carbonated-beverage filling machine has normally distributed fill volume with $\mu=12.4$ fluid ounces and $\sigma=0.1$ fluid ounce. (a) Find $P(X<12)$. (b) If cans under 12.1 or over 12.6 are scrapped, find the scrap proportion. (c) Give symmetric limits around 12.4 that include about 99% of cans.

::::answer[Answer]
**Answer:** (a) 0.0000; (b) 0.0241; lower 12.1420; upper 12.6580.

1. (a) $z=(12-12.4)/0.1=-4.00$. This lies just outside the negative end of the sheet; its left probability is below 0.000033 and rounds to 0.0000 at four decimals.
2. (b) The lower scrap boundary has $z=(12.1-12.4)/0.1=-3.00$; the upper has $z=(12.6-12.4)/0.1=2.00$. Table III gives $\Phi(-3.00)=0.001350$ at row -3.0 column -0.00 and $\Phi(2.00)=0.977250$ at row 2.0 column 0.00.
3. Subtract to find the accepted proportion $0.977250-0.001350=0.975900$, then complement to obtain the scrap fraction.
4. (c) For the central 99%, look for left areas 0.005 and 0.995. The closest two-decimal $z$ values are -2.58 and +2.58. Convert using $x=12.4+z(0.1)$ to obtain the two physical fill limits.
5. The symmetric 99% specifications are wider than the asymmetric scrap limits in part (b).

Check: The result is consistent with the support and probability or units of the model.
::::
:::

### How to do normal problems on the TI-30X IIS

Write the physical units beside your numbers before touching the calculator. Suppose a shaft diameter is 53 mm, with mean 50 mm and standard deviation 2 mm. Compute the numerator $53-50=3$ mm, divide by 2 mm, and get $z=1.50$. The units cancel. Now Table III, row 1.5 and column 0.00, gives the fraction below 53 mm. If the question says **exceeds** 53 mm, subtract that table value from one. If the question says **between** 48 and 53 mm, standardize 48 as well: $z=-1.00$. Subtract the lower cumulative value from the upper cumulative value.

The **calculator** does not replace the **table**. A student who types a normal CDF into modern software may obtain a more precise area than the official table method. For this course, first round $z$ to two decimals, then read and retain the six-decimal table entry. The resulting answer is the one reproduced here. The same policy applies when working backward. Interpolating two cells may be mathematically sensible, but it is not the prescribed single-cell lookup.

Whenever a physical threshold is requested, do a units check on $x=\mu+z\sigma$. A product $z\sigma$ has the same units as $\sigma$, because $z$ is unitless. That means the answer returns to millimeters, ounces, miles per hour, or exam points. Reporting a bare $z=1.64$ when asked for a speed in mph is unfinished work.

### Tying ordinary normal calculations to the table's shapes

On the same curve, a lower-tail cutoff, an upper-tail cutoff, and a middle interval are not new distributions. They differ only in shading. For a process with mean 72 mph and standard deviation 4 mph, an observed 74 mph is half a standard deviation above average; the upper tail is $1-\Phi(0.50)$. The interval 71–73 mph corresponds to $z=-0.25$ and $z=+0.25$, so its area is $\Phi(0.25)-\Phi(-0.25)$. The fastest 5% begins at a high positive $z$ cutoff found by looking up left area 0.95, then transforming back to mph. These three prompts share the same mean and standard deviation, yet require three different region operations.

:::callout-pitfall[Variance is not the denominator, and top means right]
If the distribution is $N(10,4)$, divide by $\sigma=2$, not by $\sigma^2=4$. If the words say **fastest 5%**, find a cutoff with 95% **below** it. If specifications are written as a target plus or minus a tolerance, compute both endpoints before standardizing, and use the given process mean instead of silently substituting the target. Finally, a right-tail probability is not the same thing as the table's left-tail entry.
:::

:::problem[Problem 5.32 — Homework 6, normally distributed machined-shaft diameter]{difficulty=standard}
Diameter $X\sim N(50,2^2)$ millimeters. Find (a) $P(X<53)$, (b) $P(48<X<52)$, (c) $P(X>54)$, (d) the 95th percentile, and (e) the diameter separating the lowest 10% from the other 90%.

::::solution[Solution]
**Answer:** (a) 0.933193; (b) 0.682690; (c) 0.022750; (d) 53.280000; (e) 47.440000.

1. (a) $z=(53-50)/2=1.50$: page 4 row 1.5 column 0.00 gives $0.933193$.
2. (b) 48 and 52 standardize to -1.00 and 1.00. The table gives 0.158655 on page 3 row -1.0 column -0.00 and 0.841345 on page 4 row 1.0 column 0.00; subtract.
3. (c) 54 gives $z=2.00$. Row 2.0 column 0.00 gives 0.977250, so take the complement.
4. (d) A 95th-percentile cutoff has 95% to the left. The closest printed area to 0.95 corresponds to $z=1.64$, giving $50+1.64(2)$.
5. (e) A lowest-10% cutoff has left probability 0.10. The nearest negative lookup is $z=-1.28$, so compute $50-1.28(2)$.
6. Both cutoffs are in millimeters and lie on the correct sides of the 50-mm mean.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.33 — Exam 2, interstate vehicle speeds]{difficulty=standard}
Car speed $X$ is normal with mean 72 mph and standard deviation 4 mph. Find (a) $P(X>74)$, (b) $P(71<X<73)$, and (c) the threshold for the fastest 5% of cars.

::::solution[Solution]
**Answer:** (a) 0.308538; (b) 0.197412; (c) 78.560000.

1. (a) $z=(74-72)/4=0.50$. Table III row 0.5 column 0.00 gives 0.691462; the upper tail is $1-0.691462$.
2. (b) The two bounds become $-0.25$ and $+0.25$. Read 0.401294 at negative row -0.2 column -0.05 and 0.598706 at positive row 0.2 column 0.05, then subtract.
3. (c) Fastest 5% is a right tail, so find left cumulative area 0.95. The nearer table cell is $z=1.64$, giving $72+1.64(4)$ mph.
4. The third answer is a **speed**, not a probability, and can be compared with the posted speed limit.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.34 — Exam 2, thickness of a metal part]{difficulty=easy}
Part thickness is normal with mean 15.5 mm and standard deviation 3.1 mm. Find $P(X>18)$.

::::solution[Solution]
**Answer:** 0.208970.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. standardize each boundary and use the printed cumulative table: $z=(18-15.5)/3.1=0.81$; Table III row 0.8, column 0.01, gives $\Phi(0.81)=0.791030$.
3. The table is a *left-tail* probability, so subtract from one to obtain the probability to the right.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.35 — Exam 2, heights of irrigated and unirrigated plants]{difficulty=standard}
Without automatic irrigation, plant height two weeks after germination is normal with mean 2.5 cm and standard deviation 0.5 cm. Find (a) $P(X>2.25)$ and (b) $P(2.0<X<3.0)$.

::::solution[Solution]
**Answer:** (a) 0.691462; (b) 0.682690.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. For (a), standardize each boundary and use the printed cumulative table: $z=(2.25-2.5)/0.5=-0.50$; Table III row -0.5, column -0.00, gives $\Phi(-0.50)=0.308538$.
3. The table is a *left-tail* probability, so subtract from one to obtain the probability to the right.
4. For (b), standardize each boundary and use the printed cumulative table: $z=(2-2.5)/0.5=-1.00$; Table III row -1.0, column -0.00, gives $\Phi(-1.00)=0.158655$; $z=(3-2.5)/0.5=1.00$; Table III row 1.0, column 0.00, gives $\Phi(1.00)=0.841345$.
5. The desired shaded band equals the right-end cumulative area minus the left-end cumulative area.
6. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.36 — SI normal entrance-exam scores]{difficulty=standard}
A university entrance examination has normally distributed scores with mean 600 and standard deviation 80. Find (a) $P(X>680)$, (b) $P(520<X<640)$, and (c) the score required for the top 5% of test takers.

::::solution[Solution]
**Answer:** (a) 0.158655; (b) 0.532807; (c) 731.200000.

1. (a) $z=(680-600)/80=1.00$. Table III row 1.0 column 0.00 gives 0.841345; right tail $=1-0.841345$.
2. (b) 520 becomes -1.00 and 640 becomes 0.50. Use negative row -1.0 column -0.00 for 0.158655 and positive row 0.5 column 0.00 for 0.691462; subtract.
3. (c) The highest 5% begins at a cumulative 95th-percentile cutoff. The table cell nearest 0.950000 is $z=1.64$, giving $600+1.64(80)=731.2$ points.
4. The top-5% score is a threshold in examination points, not a standardized score.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.37 — Normal variable with a stated variance]{difficulty=easy}
A sensor reading has $X\sim N(24,9)$ where 9 is the variance. Find $P(X<27)$.

::::solution[Solution]
**Answer:** 0.841345.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. standardize each boundary and use the printed cumulative table: $z=(27-24)/3=1.00$; Table III row 1.0, column 0.00, gives $\Phi(1.00)=0.841345$.
3. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem 5.38 — Asymmetric two-tail scrap specifications]{difficulty=challenge}
A normal process has mean 20 and standard deviation 2. Parts are rejected below 17 or above 24. What proportion is rejected?

::::solution[Solution]
**Answer:** 0.089557.

1. Name the random variable and mark whether the question asks for an interval, a left tail, a right tail, or a cutoff. For a continuous model, an individual endpoint contributes no probability.
2. standardize each boundary and use the printed cumulative table: $z=(17-20)/2=-1.50$; Table III row -1.5, column -0.00, gives $\Phi(-1.50)=0.066807$; $z=(24-20)/2=2.00$; Table III row 2.0, column 0.00, gives $\Phi(2.00)=0.977250$.
3. Subtract the probability between the specification limits from one: the two scrap tails do not overlap.
4. State the result in the original units or as a proportion. Verify that any probability lies between zero and one, and that a percentile lies in the direction required by the wording.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

## Mixed Practice

The final combines conceptual identification with short calculations, so this is a **mixed final-style set**, not a second block of exercises arranged by formula. It contains a three-part true/false item, a four-part matching item, and thirteen multiple-choice questions. Like the instructor's comprehensive final, roughly half of the decisions require computation. Use only your equation sheet and the TI-30X IIS. Many distractors reproduce the exact error a student would make by choosing the right distribution but the wrong tail, forgetting a unit conversion, or treating a density as a point probability.

For every probability, mark the event on a sketch before touching the table or integrating. If a calculation appears to produce a negative probability or a proportion exceeding one, do not search for the closest multiple-choice option; return to the limits or the complement. Answers are hidden under each item, and every incorrect option is explained where the question supplies choices.

:::problem[Problem M.1 — True/false: fundamental continuous rules]{difficulty=easy}
Choose true or false for each statement. (a) A continuous random variable with a positive density at $x=2$ can still have $P(X=2)=0$. (b) $F(x)$ is the probability that $X$ is *greater* than $x$. (c) For a normal variable, the standard deviation is the positive square root of its variance.

::::solution[Solution]
**Answer:** (a) True; (b) False; (c) True.

1. (a) True. Density height measures probability per unit of the horizontal axis. A single point has zero width, so its probability is zero.
2. (b) False. By definition the CDF is $F(x)=P(X\leq x)$, a cumulative **left-tail** probability. The greater-than event has probability $1-F(x)$ for a continuous variable.
3. (c) True. The variance $\sigma^2$ is a squared spread, and its nonnegative square root $\sigma$ gives the standard deviation in the original measurement units.
4. Together these statements distinguish a density, cumulative probability, and descriptive spread.

Check: This classification follows directly from what the variable measures.
::::
:::

:::problem[Problem M.2 — Matching: model to what is measured]{difficulty=easy}
Match each situation with A. Normal, B. Poisson, C. Exponential, D. Continuous uniform: (a) the number of calls in a fixed hour at constant rate, (b) time to the next call, (c) a random diameter equally likely between two specifications, (d) symmetric bell-shaped measurement errors.

::::solution[Solution]
**Answer:** (a) B; (b) C; (c) D; (d) A.

1. (a) The whole-number **count** of calls in a fixed interval is Poisson, B; it is not a continuous waiting time.
2. (b) The nonnegative **time until** the next arrival is exponential, C. Its density decays from time zero.
3. (c) Equal density throughout a fixed interval makes the diameter continuous uniform, D.
4. (d) A symmetric bell-shaped density centered on a mean is normal, A. This matches the instructor separation of count, waiting time, rectangle, and bell shape.

Check: This classification follows directly from what the variable measures.
::::
:::

:::problem[Problem M.3 — Multiple choice: copper-wire subinterval]{difficulty=easy}
Wire current is uniform on $[0,20]$ mA with $f(x)=0.05$. Find $P(6<X<14)$. A. 0.7000; B. 0.4000; C. 0.0500; D. 0.8000.

::::solution[Solution]
**Answer:** (B) 0.4000.

1. The shaded interval has width $14-6=8$ mA, and the constant density has height 0.05 per mA.
2. Area equals $8(0.05)=0.40$. The result means 40% of current readings are inside this particular eight-milliampere band.
3. Option A uses an endpoint as though it were a probability. C reports the density height rather than an area. D divides 8 by 10 rather than the full support width of 20. Only B is correct.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.4 — Multiple choice: rising PDF upper tail]{difficulty=standard}
For $f(x)=x/8$ on $0\leq x\leq4$, what is $P(X>2)$? A. 0.2500; B. 0.5000; C. 0.7500; D. 1.0000.

::::solution[Solution]
**Answer:** (C) 0.7500.

1. The antiderivative of $x/8$ is $x^2/16$. The right-tail area is $[x^2/16]_2^4=(16-4)/16=0.75$.
2. A incorrectly uses the left-tail probability. B assumes all interval lengths of two out of four have equal probability, as in the uniform model. D counts all the support.
3. The density rises, so the upper half of the interval contains more than half of the area. C agrees with that graphical check.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.5 — Multiple choice: between two standard-normal values]{difficulty=standard}
What is $P(-1.25<Z<1.25)$ for standard normal $Z$? A. 0.7887; B. 0.8944; C. 0.1057; D. 0.5000.

::::solution[Solution]
**Answer:** (A) 0.7887.

1. Positive table row 1.2, column 0.05 gives $\Phi(1.25)=0.894350$. Negative row -1.2, column -0.05 gives $\Phi(-1.25)=0.105650$.
2. Subtract to obtain $0.894350-0.105650=0.788700$. That is the central band.
3. B is only the upper endpoint cumulative area, C is the lower outside tail, and D is the left or right half of the bell rather than the band. A is correct.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.6 — Multiple choice: two-hour exponential failure probability]{difficulty=standard}
A machine has exponential lifetime with mean 5 hours. What is the chance it fails within two hours? A. 0.6703; B. 0.3297; C. 0.4000; D. 0.2000.

::::solution[Solution]
**Answer:** (B) 0.3297.

1. A mean life of five hours gives rate $\lambda=1/5=0.2$ per hour. The question asks for failure **by** two hours.
2. $P(X\leq2)=1-e^{-0.2(2)}=1-e^{-0.4}$, which rounds to the value in B.
3. A gives survival beyond two hours instead of failure by that time. C confuses expected fraction of lifetime with event probability; D repeats the rate as a probability. The event occurred by the stated time.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.7 — Multiple choice: normal top-five-percent z cutoff]{difficulty=standard}
Using only Table III cells, which two-decimal positive $z$ most closely makes $P(Z>z)=0.05$? A. 0.05; B. 1.28; C. 1.64; D. 2.58.

::::solution[Solution]
**Answer:** (C) 1.64.

1. The right tail is 0.05, so the cumulative **left** area is $1-0.05=0.95$.
2. On Final-sheet page 4, row 1.6 column 0.04 gives 0.949497, while column 0.05 gives 0.950529. The first is marginally closer to 0.950000.
3. A confuses a probability with a z score; B is near the 90th percentile; D is the central-99% cutoff. C is the correct two-decimal, single-cell answer.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.8 — Multiple choice: right tail of a normal measurement]{difficulty=standard}
If $X$ is normal with mean 80 and standard deviation 10, what is $P(X>90)$? A. 0.1587; B. 0.8413; C. 0.5000; D. 0.9772.

::::solution[Solution]
**Answer:** (A) 0.1587.

1. Standardize: $z=(90-80)/10=1.00$. Table III row 1.0, column 0.00 gives $\Phi(1.00)=0.841345$.
2. Because the question asks for values above 90, take $1-0.841345=0.158655$, or 0.1587 to four decimals.
3. B is the area below 90; C is half the curve at the mean, not one standard deviation above it; D is a different standard-normal cutoff. Therefore A is correct.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.9 — Multiple choice: symmetric out-of-spec parts]{difficulty=standard}
A normal process has mean 20 and standard deviation 2. Parts are rejected if below 18 or above 22. What is the rejection fraction? A. 0.6827; B. 0.3173; C. 0.1587; D. 0.5000.

::::solution[Solution]
**Answer:** (B) 0.3173.

1. The acceptable limits standardize to $-1.00$ and $+1.00$. Table III gives $\Phi(-1.00)=0.158655$ and $\Phi(1.00)=0.841345$.
2. Accepted proportion is $0.841345-0.158655=0.682690$; rejected proportion is its complement $0.317310$.
3. A gives acceptable rather than rejected pieces. C counts only one of the equal rejection tails. D incorrectly divides the normal bell in half. B includes both tails.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.10 — Multiple choice: uniform flange upper tail]{difficulty=easy}
A flange thickness is uniform on $[0.95,1.05]$ mm. Which proportion exceeds 1.02 mm? A. 0.7000; B. 0.2000; C. 0.3000; D. 1.0200.

::::solution[Solution]
**Answer:** (C) 0.3000.

1. Calculate the full width: $1.05-0.95=0.10$ mm. Calculate the upper segment: $1.05-1.02=0.03$ mm.
2. The proportion is $0.03/0.10=0.30$, so C is correct.
3. A is the complementary fraction **below** 1.02 mm; B is an incorrect width; D is the measurement 1.02 mm masquerading as a probability, and even exceeds one.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.11 — Multiple choice: variance from a parabolic density]{difficulty=challenge}
For the valid density $f(x)=1.5x^2$ on $-1<x<1$, what is $V(X)$? A. 0.0000; B. 0.6000; C. 0.7746; D. 1.5000.

::::solution[Solution]
**Answer:** (B) 0.6000.

1. The density is symmetric so $\mu=0$. The variance shortcut is $V(X)=E(X^2)-\mu^2$.
2. $E(X^2)=\int_{-1}^1x^2(1.5x^2)\,dx=1.5[x^5/5]_{-1}^{1}=0.60$. Subtract zero.
3. A mistakes the mean for the variance; C is the square root of 0.60, so it is the standard deviation; D merely repeats the leading density coefficient. The variance itself is B.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.12 — Multiple choice: definition of the CDF]{difficulty=easy}
Which statement correctly defines $F(x)$ for a continuous random variable? A. $P(X=x)$; B. $f(x)$; C. $P(X>x)$; D. $P(X\leq x)$.

::::solution[Solution]
**Answer:** (D) cumulative left-tail probability.

1. The cumulative distribution accumulates density from the left edge of the real line up to the threshold $x$.
2. A is a point probability, which is zero for a continuous model. B is the density height, whose units and meaning differ from accumulated probability.
3. C is the upper or right-tail event, the complement of the CDF. D is exactly the printed definition on Final-sheet page 1.

Check: This classification follows directly from what the variable measures.
::::
:::

:::problem[Problem M.13 — Multiple choice: arrivals after ten minutes]{difficulty=standard}
Events arrive at a Poisson-process rate of 6 per hour. What is the probability the wait to the next event exceeds 10 minutes? A. 0.6321; B. 0.1667; C. 0.8333; D. 0.3679.

::::solution[Solution]
**Answer:** (D) 0.3679.

1. Convert the rate to 6/60=0.10 per minute so that time and rate are consistent. A ten-minute wait has product $\lambda t=0.10(10)=1$.
2. No arrival by ten minutes means survival $P(X>10)=e^{-1}=0.367879\ldots$, the value in D.
3. A is the complement, the probability some arrival has occurred; B is ten minutes expressed in hours, not a probability; C is its complement.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.14 — Multiple choice: ninety-percentile measurement]{difficulty=standard}
For a normal measurement with mean 100 and standard deviation 15, what is the approximate 90th-percentile cutoff using Table III? A. 80.8; B. 100.0; C. 119.2; D. 138.7.

::::solution[Solution]
**Answer:** (C) 119.2.

1. The desired left probability is 0.900000. Table III row 1.2 column 0.08 gives 0.899727, the nearest printed entry, so $z=1.28$.
2. Convert back: $x=100+1.28(15)=119.2$. This cutoff leaves approximately 90% of measurements below it.
3. A uses a negative z, describing the lowest 10%; B is the median rather than the 90th percentile; D uses the 2.58 cutoff for a different extreme tail. C is correct.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

:::problem[Problem M.15 — Multiple choice: elapsed time and remaining exponential life]{difficulty=standard}
An exponentially distributed lifetime has mean 4 years. The component has already survived 7 years. Under the same model, what is its expected *additional* lifetime? A. 0 years; B. 4 years; C. 7 years; D. 11 years.

::::solution[Solution]
**Answer:** (B) 4.0000.

1. An exponential distribution has the memoryless property. Conditioning on survival until year seven does not alter the distribution of the remaining waiting time.
2. The expected additional life therefore equals the original exponential mean $1/\lambda=4$ years.
3. A incorrectly treats the initial mean as a hard expiration date; C confuses elapsed age with remaining life; D adds the past seven years to the remaining four even though the question explicitly asks for additional time. B is correct.

Check: The result is consistent with the support and probability or units of the model.
::::
:::

## Chapter Summary

:::summary[The six moves behind Unit 5]
**A continuous value is measured, not counted.** Its probability comes from **area**, and the probability of a single exact value is zero. On **Final-sheet page 1**, the three central rules are $P(a\leq X\leq b)=\int_a^bf(x)\,dx$, $F(x)=\int_{-\infty}^xf(u)\,du$, and the two moment integrals for $\mu$ and $\sigma^2$. Before integrating, write the support. For a piecewise density or CDF, use the correct branch.

**Mean and variance are different questions.** Compute $\mu=\int xf(x)\,dx$ for the center, then $V(X)=\int x^2f(x)\,dx-\mu^2$ for the spread. Take a square root only at the end to obtain $\sigma$. Keep the units: mean and SD use the original measurement units; variance uses squared units. Continuous uniform is a brief Exam 2 topic: density $1/(b-a)$, mean $(a+b)/2$, and variance $(b-a)^2/12$.

**Exponential means waiting time.** The density $\lambda e^{-\lambda x}$, mean $1/\lambda$ and variance $1/\lambda^2$ appear on **Final-sheet page 2**. Derive survival $P(X>t)=e^{-\lambda t}$ and cumulative failure $P(X\leq t)=1-e^{-\lambda t}$ by integrating the density. A Poisson variable counts events; an exponential variable measures the wait until one. Convert rate and time into matching units. The exponential has the lack-of-memory property.

**The normal table is cumulative and left-tailed.** The normal density is on **page 2**, and Table III is on **pages 3–4**. Use $\Phi(z)$ for the area below $z$, $1-\Phi(z)$ for the area above, and $\Phi(b)-\Phi(a)$ for the area between. Page 3 has negative rows and negative hundredth columns from -0.09 toward -0.00; page 4 uses positive hundredths from 0.00 to 0.09. Round each $z$ to two decimal places *before* looking up the table, and then use its six-decimal entry.

**Normal measurements need standardization.** The formula $z=(x-\mu)/\sigma$ appears on **Final-sheet page 1**. The symbol $N(\mu,\sigma^2)$ uses variance as its second parameter, so take a square root when the question gives a variance. For the inverse direction, work backward from the cumulative area to a table $z$, then compute $x=\mu+z\sigma$ in the question's physical units. The **fastest** or **top** fraction is an upper tail, not a left-tail fraction.

**Use a contextual check at the end.** Every computed probability must be between zero and one. A cutoff exceeded by 90% must lie near the low end, not the high end. A manufacturer scrapping parts outside specifications needs two tails, whereas accepting parts inside specifications needs the middle band. If an exponential lifetime already survived for a while, the memoryless model does not decrease its expected remaining life. All of these checks can be done before or after the calculation without any extra formulas.
:::

