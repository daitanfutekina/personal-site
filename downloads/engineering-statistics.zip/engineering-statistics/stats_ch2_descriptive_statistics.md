---
title: "Describing Data"
crumb: "Engineering Statistics · Chapter 2"
meta:
  - "Est. study time: ~210 min"
  - "IE 4613 · Unit 2"
source: "markdown"
---

## Overview

A manufacturing process can have a sensible average and still turn out unacceptable parts. A class can have a high mean exam score while several students fail. A battery can last about the expected time on average but die much earlier on a few trials. Descriptive statistics are the tools for separating the **center** of data from its **spread**, and numerical summaries from the **shape** of the observations. The instructor's Unit 2 slides move from sample mean and variability through median, mode and quartiles, then to graphical descriptions.

On the final, a description of a sample usually asks for one of two things. It may give a short list of measurements and ask you to calculate a statistic. Or it may show a histogram or box plot and ask what that display says about center, variability, skew or outliers. You should recognize the statistic from ordinary wording, use the TI-30X IIS when it actually helps, and be able to explain your result in the units of the original measurement. **The quartile procedure is the instructor's ordered-position rule, not a calculator's built-in quartile convention.**

Unit 2's core final topics are sample mean, variance, standard deviation, range, median, mode, quartiles, histograms and box plots. The slides also demonstrate dot plots, stem-and-leaf diagrams, time-series plots and normal probability plots. Those extra displays are included briefly because they appear in the instructor's teaching and Exam 1 practice. The discussion of *standard error* in one Exam 1 question is acknowledged, but its underlying sampling-distribution theory belongs to Chapter 7.

:::callout-key[What is printed on the final sheet?]
Page 1 of the Final Exam Equations sheet gives the sample-mean formula, the sample-variance formula, and $IQR=Q_3-Q_1$. It does **not** print the quartile-position rule, the mode, the range, the $1.5\,IQR$ fences or a histogram recipe. The Exam 1 sheet additionally prints the quartile-position and whisker rules. The missing ideas are geometric and computational: sort and locate positions for quartiles; subtract endpoints for range; take the square root of variance for standard deviation; use fences to identify observations unusually far from the middle half.
:::

:::callout-connect[Connection to Chapter 1]
Chapter 1 distinguishes population, sample, variability and inference. Here we calculate summaries from an observed sample, written $x_1,x_2,\ldots,x_n$. The population mean is $\mu$ and population standard deviation is $\sigma$; their sample counterparts are $\bar{x}$ and $s$. Describing the observed data is not itself a claim about all future observations.
:::

## 2.1 Numerical Summaries and the TI-30X IIS

:::callout-intuition[The center is not the variability]
Imagine two machines both have an average cut length of 50 millimeters. Machine A makes 49, 50 and 51. Machine B makes 40, 50 and 60. If you report only the mean, those processes look identical. Variance and standard deviation tell you how far observations typically scatter about that mean, while the range only notices the two extremes. Recognition cue: *average*, *mean* and *typical balance point* call for $\bar{x}$. *Sample variance* calls for $s^2$, and *sample standard deviation* or *spread in the original units* calls for $s$.
:::

### Mean as a balancing point

:::definition[Definition 2.1 — Sample mean]
For a sample $x_1,\ldots,x_n$ of size $n$, the sample mean is

$$
\bar{x}=\frac{x_1+x_2+\cdots+x_n}{n}.
$$

This is on **Final Exam Equations, page 1**, in the bottom row of descriptive-statistic formulas. Every observed value receives equal weight when each observation is entered once. The sample mean estimates the population mean $\mu$.
:::

The mean is a **balance point**, not necessarily an observed value. If three measurements are 8, 10 and 15, their mean is 11. A value greater than the mean pulls the balance point right; a smaller one pulls it left. An unusually large observation changes the mean even when the rest of the observations do not move. That sensitivity becomes important when we compare the mean with the median.

### Variance, standard deviation, and the range

:::definition[Definition 2.2 — Sample variance and standard deviation]
The sample variance is

$$
s^2=\frac{(x_1-\bar{x})^2+(x_2-\bar{x})^2+\cdots+(x_n-\bar{x})^2}{n-1}.
$$

This is on **Final Exam Equations, page 1**. The sample standard deviation is $s=\sqrt{s^2}$, the nonnegative square root, which follows directly from the definition of variance. The divisor for a **sample** is $n-1$, not $n$. Variance estimates the population variance $\sigma^2$.
:::

Why square the deviations? A long measurement lies above the mean and a short measurement lies below it. Their signed deviations would cancel, hiding real variation. Squaring makes every contribution nonnegative and magnifies distant measurements. The squared deviations are then averaged with $n-1$ in the denominator. The resulting **variance** has squared units, for example $(\mathrm{mm})^2$ or $(\mathrm{dollars/metric\ ton})^2$. Taking the square root produces the **standard deviation** in millimeters or dollars per metric ton again. It is not the same as a guarantee that a particular fraction of measurements lies within one standard deviation.

:::definition[Definition 2.3 — Sample range]
The sample range is

$$
r=\max(x_i)-\min(x_i).
$$

The range is not printed on the Final sheet; it is simply the distance from the smallest observed value to the largest. Larger range often suggests greater spread, but it depends entirely on two observations and therefore reacts sharply to an extreme value.
:::

The sample mean, $s^2$, $s$ and range answer different questions. The mean estimates where the values are centered. Variance measures averaged squared deviations after accounting for the estimated center. Standard deviation is the more interpretable spread in original units. Range tells you the full observed width. A sample standard deviation can be zero if and only if all observations are identical; the same is true of the sample range. Both require at least two observations for the usual sample-variance calculation.

### Calculator procedure that matches the exam

:::callout-tip[TI-30X IIS: one-variable statistics, without software]
1. Press **[2nd] [DATA]**, select **1-VAR**, then press **[ENTER]**. If the machine is already in statistics mode with old measurements, choose **CLRDATA** first; otherwise a previous sample can silently contaminate the result.
2. Press **[DATA]**. Enter the first $x$ value, then **[ENTER]** or the down arrow. The screen alternates an **$x$ value** and its **FRQ**, or frequency. For ordinary ungrouped observations, leave FRQ at 1. Use the down arrow to move to the next $x$ value; enter the entire sample.
3. Press **[STATVAR]** and use the left and right arrows. Read **$n$** for sample size, **$\bar{x}$** for sample mean and **$Sx$** for *sample* standard deviation. The similarly named **$\sigma x$** is population standard deviation and is the wrong value when the question asks for $s$. To obtain $s^2$, square **$Sx$** on the regular calculation screen.
4. Read $\Sigma x$ and $\Sigma x^2$ only as checks on data entry; they are not the mean or variance. Press **[2nd] [STATVAR]**, choose **Y** and **[ENTER]** to leave statistics mode and clear the data. **One-variable mode does not calculate the instructor's quartiles or fences for you.**

These key sequences follow Texas Instruments' published TI-30X IIS instructions; keys may be labeled with small secondary functions, so look for the printed key names rather than a position on a different calculator model.
:::

Repeated observations can be entered either once each with FRQ = 1 or once with their actual frequency. For example, if 12, 12, 12, 16 and 18 are the measurements, enter 12 with FRQ = 3, 16 with FRQ = 1, and 18 with FRQ = 1. If you mistakenly enter FRQ = 3 for every value, you change the effective sample, even though a few outputs might appear superficially plausible. As soon as the statistic is displayed, compare the calculator's $n$ with your count of measurements. A mismatch means you should not trust the other results.

### Reading the calculator without surrendering the reasoning

If you were asked to show calculations on paper, start with the original data and $n$, write the mean formula from the sheet, and show the arithmetic you would type. For a short sample, writing $(6+9.5+10+16.5+13+5)/6$ is appropriate. For a sample of 40 measurements, it is more useful to state how you entered each into 1-VAR mode, confirm $n=40$, record $\bar{x}$ and $Sx$, and show how you squared $Sx$ when the question requested sample variance. A calculator value without units, or a population statistic where the word *sample* was specified, is still an incorrect answer.

:::callout-pitfall[Four mistakes that change the answer]
**Wrong divisor:** for these questions, $s^2$ divides by $n-1$. **Wrong menu variable:** $Sx$ is the sample standard deviation; $\sigma x$ is the population result. **Premature rounding:** keep full calculator precision until the final response, especially before squaring $Sx$. **Wrong units:** if the data are concentrations in milligrams per liter, $s$ has the same unit, but $s^2$ has its square. Also remember that a bigger sample does not automatically mean a smaller *sample standard deviation*; it may reveal variation that the smaller sample failed to observe.
:::

:::example[Example 2.1 — Student study hours: mean, deviation, and dot diagram]
To evaluate student study habits, six students were asked how many hours each week they spent studying. Calculate the sample mean and sample standard deviation; construct a dot diagram.

**Data:** 6, 9.5, 10, 16.5, 13, 5.

::::answer[Answer]
**Answer:** mean 10; standard deviation 4.301.

1. There are six students, so $n=6$. Write the mean exactly as on the Final sheet: $\bar{x}=(6+9.5+10+16.5+13+5)/6=60/6=10$ hours per week. This is the mean study time, not the time recorded by the middle student.

2. Deviations from 10 are $-4,-0.5,0,6.5,3,-5$. Squaring individually gives $16+0.25+0+42.25+9+25=92.5$. The *sample* variance is $92.5/(6-1)=18.5\ \mathrm{hours}^2$; its square root gives $s=4.3011626$ hours per week.

3. On the TI-30X IIS, choose 1-VAR, enter 6, 9.5, 10, 16.5, 13, 5, and inspect STATVAR. The display should show $n=6$, $\bar{x}=10$ and $Sx=4.3011626$. This cross-check catches the mistaken $n$ denominator before an exam.

4. Order the observations $5,6,9.5,10,13,16.5$ and put one dot above each of those positions. In the following figure, every dot represents one student. A dot is *not* a frequency rectangle and cannot be connected to imply a time trend.

Check: The mean student in this sample studies 10 hours a week; the observed times have sample standard deviation about 4.30 hours, and the last dot records the 16.5-hour student.
::::
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="A dot plot of six study-hour observations positioned on a horizontal number line">
<line class="fig-axis" x1="58.00" y1="174.00" x2="655.00" y2="174.00"/>
<text class="fig-label" x="58.00" y="215.00">5</text>
<text class="fig-label" x="650.00" y="215.00">17</text>
<text class="fig-label" x="295.00" y="235.00">Study hours per week</text>
<line class="fig-axis" x1="60.00" y1="169.00" x2="60.00" y2="179.00"/>
<circle class="fig-point" cx="60.00" cy="159.00" r="4"/>
<text class="fig-label" x="49.00" y="148.00">5</text>
<line class="fig-axis" x1="109.17" y1="169.00" x2="109.17" y2="179.00"/>
<circle class="fig-point" cx="109.17" cy="159.00" r="4"/>
<text class="fig-label" x="98.17" y="148.00">6</text>
<line class="fig-axis" x1="281.25" y1="169.00" x2="281.25" y2="179.00"/>
<circle class="fig-point" cx="281.25" cy="159.00" r="4"/>
<text class="fig-label" x="270.25" y="148.00">9.5</text>
<line class="fig-axis" x1="305.83" y1="169.00" x2="305.83" y2="179.00"/>
<circle class="fig-point" cx="305.83" cy="159.00" r="4"/>
<text class="fig-label" x="294.83" y="148.00">10</text>
<line class="fig-axis" x1="453.33" y1="169.00" x2="453.33" y2="179.00"/>
<circle class="fig-point" cx="453.33" cy="159.00" r="4"/>
<text class="fig-label" x="442.33" y="148.00">13</text>
<line class="fig-axis" x1="625.42" y1="169.00" x2="625.42" y2="179.00"/>
<circle class="fig-point" cx="625.42" cy="159.00" r="4"/>
<text class="fig-label" x="614.42" y="148.00">16.5</text>
</svg>
<figcaption>Each dot represents one of the six students; the six distinct study times range from 5 to 16.5 hours per week.</figcaption>
</figure>

:::example[Example 2.2 — Quarterly steel prices: mean and standard deviation]
A company reports eight quarterly average prices for steel in the United States, in US dollars per metric ton. Calculate the sample mean and sample standard deviation using a calculator, and explain whether substituting monthly reports for quarterly averages would necessarily leave both summaries unchanged.

**Data:** 684, 697, 802, 896, 839, 861, 983, 1089.

::::answer[Answer]
**Answer:** mean 856.375; standard deviation 136.336.

1. Count the quarterly figures: $n=8$. The numerator is $684+697+802+896+839+861+983+1089=6851$, so $\bar{x}=6851/8=856.375$ US dollars per metric ton.

2. To compute the sample spread by hand, subtract 856.375 from each original price and square the deviations. Their sum is $130111.875$. Divide by $8-1=7$ to obtain $s^2=18587.410714\,(\mathrm{US\ dollars/metric\ ton})^2$ and take the square root. On the TI-30X IIS the more efficient route is to enter the eight numbers, check $n=8$, then read **$Sx$**.

3. Monthly reports are a **different set of observations**. They can reveal short-lived movements concealed by quarterly averages; the sample size and each reported value change. Therefore, neither the mean nor the sample standard deviation must remain the same. Moreover, more observations do not guarantee a smaller standard deviation of the individual reports.

4. Always state units. $s$ is in dollars per metric ton, while $s^2$ is in squared dollars per metric ton. The larger figure is the variance, not a price.

Check: The sampled quarters averaged $856.375$ per metric ton with sample standard deviation about $136.336$ per metric ton; that does not determine the mean and spread of monthly prices.
::::
:::

:::example[Example 2.3 — SI multiple-choice sample mean]
In the Exam 1 SI review, the data are 5.2, 6.4, 3.8, 8.0, 12.6. What is the sample mean? Choices: (A) 7.4; (B) 9.0; (C) 6.0; (D) 7.2.

**Data:** 5.2, 6.4, 3.8, 8, 12.6.

::::answer[Answer]
**Answer:** (D) mean 7.2.

1. The request says **sample mean**, so add every value and divide by the number of observations. There are five, not four; the decimal points do not change how many measurements were taken.

2. Type $(5.2+6.4+3.8+8.0+12.6)/5$. The numerator is $36.0$, and the result is $7.2$. This is an arithmetic average, not the middle observation or the most common observation.

3. Choose option D. A is an arithmetic distractor; B and C do not equal the total divided by five. On the TI-30X IIS, STATVAR $\bar{x}$ also reads $7.2$ after entering the five numbers.

Check: Multiplying the mean by the sample size gives $7.2(5)=36$, exactly the original total. This average describes the five reported measurements.
::::
:::

:::example[Example 2.4 — Two machines with equal center and unequal spread]
Machine A produces lengths 49, 50, 51 millimeters. Find its sample size, mean, sample variance, sample standard deviation, and range. Explain why the result cannot be inferred from a mean alone.

**Data:** 49, 50, 51.

::::answer[Answer]
**Answer:** sample size 3; mean 50; variance 1; standard deviation 1; range 2.

1. Count three observations. The sample mean is $(49+50+51)/3=50$ mm. This mean can be shared by samples with dramatically different variability; knowing it alone is not enough.

2. Subtract 50 and square: $(49-50)^2+(50-50)^2+(51-50)^2=1+0+1=2$. Divide by $3-1=2$ to obtain the sample variance $s^2=1\,\mathrm{mm}^2$.

3. Take the nonnegative square root to obtain $s=1$ mm. The largest minus smallest measurement is $51-49=2$ mm, which is the range, not the standard deviation.

4. The TI-30X IIS reports $n=3$, mean 50 and $Sx=1$ when each reading is entered with frequency 1. For a comparison, the sample 40, 50, 60 has that same mean but a much larger variance.

Check: The three machine A lengths are close to 50 mm, so a one-millimeter sample standard deviation is consistent with the data.
::::
:::

:::problem[Problem 2.1 — SI review: choose the sample mean]{difficulty=easy}
The SI review lists five measurements and asks which mean is correct. (A) 7.4, (B) 9.0, (C) 6.0, (D) 7.2.

**Data:** 5.2, 6.4, 3.8, 8, 12.6.

::::solution[Solution]
**Answer:** (D) mean 7.2.

1. Count $n=5$ observations and add each measurement once. The numerator is $5.2 + 6.4 + 3.8 + 8 + 12.6$.

2. Divide by $n$ to obtain $\bar{x}=7.2$. In TI-30X IIS STATVAR, confirm the same mean and count; differing values signal an entry error.

3. The correct option is D. Since the sum is 36 and the count is 5, none of the alternative numerical choices equals the arithmetic average.

Check: Multiply the mean by $n$: $7.2(5)=36$, the original total of these SI observations.
::::
:::

:::problem[Problem 2.2 — SI review: choose the sample variance]{difficulty=standard}
The SI review asks for the **sample variance** of five measurements. (A) 11.5, (B) 9.2, (C) 3.4, (D) 3.0. Select the correct answer, then explain the two major numerical distractors.

**Data:** 5.2, 6.4, 3.8, 8, 12.6.

::::solution[Solution]
**Answer:** (A) variance 11.5.

1. Count $n=5$ measurements and calculate the mean first: $(5.2 + 6.4 + 3.8 + 8 + 12.6)/5=7.2$. This value is the reference point for the squared deviations.

2. Square and add each deviation: $(5.2-7.2)^2 + (6.4-7.2)^2 + (3.8-7.2)^2 + (8-7.2)^2 + (12.6-7.2)^2$. The total divided by $n-1=4$ is $s^2=11.5$.

3. The unit is squared because deviations were squared. Dividing by $n$ instead would calculate the population-style variance of these recorded observations, not the requested sample variance.

4. The correct option is A. Choice B is the variance obtained by dividing by n rather than n-1; choice C is approximately the standard deviation instead of its square.

Check: These SI observations are summarized with the requested sample convention and appropriate units.
::::
:::

:::problem[Problem 2.3 — SI review: the range of a sample]{difficulty=easy}
In the SI review, find the range for the data 12, 18, 21, 25, 31, 42. (A) 30, (B) 31, (C) 42, (D) 24.

**Data:** 12, 18, 21, 25, 31, 42.

::::solution[Solution]
**Answer:** (A) range 30.

1. Locate the smallest and largest actual observations, not the first and last entries in the unsorted list. Here the minimum is 12 and the maximum is 42.

2. Subtract minimum from maximum: $r=42-12=30$. Do not divide by the number of observations; this is a distance between endpoints.

3. The range has the same units as the data. It says how wide the observed values span, but not whether most of the observations are clustered near the middle or one end.

4. Choice A is correct. The largest observation alone is not the range, and no averaging is part of this computation.

Check: These measured values are summarized with the requested sample convention and appropriate units.
::::
:::

:::problem[Problem 2.4 — Sample standard deviation, not population spread]{difficulty=standard}
A machine produces the following five shaft lengths in millimeters. Calculate the **sample** standard deviation; use the TI-30X IIS to confirm which statistic applies.

**Data:** 4, 6, 8, 10, 12.

::::solution[Solution]
**Answer:** standard deviation 3.162.

1. From 1-VAR choose **$Sx$**, not population $\sigma x$. The sample standard deviation is $s=3.162278$ in the original units; squaring it returns variance.

2. The sample variance is found with a divisor of four, even though five shafts were measured. Check that your calculator displays Sx rather than population sigma x.

Check: These shaft lengths are summarized with the requested sample convention and appropriate units.
::::
:::

:::problem[Problem 2.5 — One central value does not guarantee uniformity]{difficulty=challenge}
A technician measures a machine’s output in millimeters. Compute the sample size, mean, variance, standard deviation and range.

**Data:** 2, 3, 3, 4, 8.

::::solution[Solution]
**Answer:** sample size 5; mean 4; variance 5.5; standard deviation 2.345; range 6.

1. Count $n=5$ observations and add each measurement once. The numerator is $2 + 3 + 3 + 4 + 8$.

2. Divide by $n$ to obtain $\bar{x}=4$. In TI-30X IIS STATVAR, confirm the same mean and count; differing values signal an entry error.

3. Square the deviations from $\bar{x}=4$ and divide their total by $n-1=4$. The sample variance is $s^2=5.5$ in squared units.

4. In handwritten form the squared-deviation numerator is $(2-4)^2 + (3-4)^2 + (3-4)^2 + (4-4)^2 + (8-4)^2$. Each term is nonnegative, so the result cannot be a negative variance.

5. From 1-VAR choose **$Sx$**, not population $\sigma x$. The sample standard deviation is $s=2.345208$ in the original units; squaring it returns variance.

6. The observation 8 helps pull the mean upward and makes the range much larger than it would be without that measurement.

Check: Multiply the mean by $n$: $4(5)=20$, the original total of these machine outputs.
::::
:::

:::problem[Problem 2.6 — Mean of calibration measurements]{difficulty=easy}
A calibration run records six voltages. Find their sample mean, not their median.

**Data:** 8, 10, 11, 12, 14, 16.

::::solution[Solution]
**Answer:** mean 11.833.

1. Count $n=6$ observations and add each measurement once. The numerator is $8 + 10 + 11 + 12 + 14 + 16$.

2. Divide by $n$ to obtain $\bar{x}=11.833333$. In TI-30X IIS STATVAR, confirm the same mean and count; differing values signal an entry error.

3. A fractional average is completely legitimate even when every observed voltage was recorded as an integer.

Check: Multiply the mean by $n$: $11.8333(6)=71$, the original total of these calibration voltages.
::::
:::

:::problem[Problem 2.7 — Variance and square-root units]{difficulty=challenge}
An inspector records eight component masses in grams. Calculate both the **sample variance** and **sample standard deviation** without rounding intermediate steps.

**Data:** 13, 16, 18, 19, 21, 22, 23, 27.

::::solution[Solution]
**Answer:** mean 19.875; variance 18.982; standard deviation 4.357.

1. Count $n=8$ observations and add each measurement once. The numerator is $13 + 16 + 18 + 19 + 21 + 22 + 23 + 27$.

2. Divide by $n$ to obtain $\bar{x}=19.875$. In TI-30X IIS STATVAR, confirm the same mean and count; differing values signal an entry error.

3. Square the deviations from $\bar{x}=19.875$ and divide their total by $n-1=7$. The sample variance is $s^2=18.982143$ in squared units.

4. In handwritten form the squared-deviation numerator is $(13-19.875)^2 + (16-19.875)^2 + (18-19.875)^2 + (19-19.875)^2 + (21-19.875)^2 + (22-19.875)^2 + (23-19.875)^2 + (27-19.875)^2$. Each term is nonnegative, so the result cannot be a negative variance.

5. From 1-VAR choose **$Sx$**, not population $\sigma x$. The sample standard deviation is $s=4.35685$ in the original units; squaring it returns variance.

6. Do not give variance in grams. Its unit is grams squared, whereas the standard deviation returns to grams.

Check: Multiply the mean by $n$: $19.875(8)=159$, the original total of these component masses.
::::
:::

## 2.2 Median, Mode, Quartiles, and the Middle Half

:::callout-intuition[Positions answer a different question from averages]
The mean balances all the observations. The median ignores how far the outermost values sit and asks where the **middle of an ordered list** lies. Quartiles do the same job around one quarter and three quarters of the way through the data. This is why a data set containing one extraordinarily large value can have a high mean without pushing its median nearly as far. Recognition cue: *middle value* or *fifty percent below* means median. *Most frequent* means mode. *Lower quartile*, *upper quartile*, *middle fifty percent*, and *IQR* demand the instructor's quartile positions.
:::

### Order before locating a position

:::definition[Definition 2.4 — Median and mode]
The **sample median**, $Q_2$, is the center of the ordered observations. For odd sample size it is the middle observation. For even sample size, average the two central observations. The **mode** is any most frequently repeated observation; there can be two or more modes or no mode when every observation occurs only once.
:::

The median is a **position** and the mode is a **frequency**. Closeness does not create a mode when no values repeat. For eight observations, the median lies halfway between positions four and five, not at position four. Sort first.

The median is resistant to changes in the size of an extreme observation. Replacing the largest value 35 with 350 leaves the middle position of a seven-value ordered list unchanged, even though it can pull the mean dramatically right. Resistance does not imply the median uses all information. When the engineering question concerns total cost per unit, the mean may be more relevant; when it concerns the typical middle item in a skewed distribution, the median may be easier to interpret. Neither statistic is universally superior.

### Exactly how this instructor computes quartiles

:::definition[Definition 2.5 — Ordered-position quartiles]
Write the sorted data as $x_{(1)}\le x_{(2)}\le\cdots\le x_{(n)}$. For quartile number $k=1,2,3$, compute its **position**

$$
p_k=\frac{k(n+1)}{4}.
$$

The **Exam 1 Equations** sheet prints this position formula; the **Final Exam Equations** sheet does **not**. It makes intuitive sense by dividing the ordered positions from just before the first observation to just after the last into four equal steps. If $p_k=j+d$, with $j$ an integer and $0\le d<1$, interpolate:

$$
Q_k=x_{(j)}+d\big(x_{(j+1)}-x_{(j)}\big).
$$

This interpolation line is also absent from the Final sheet, but simply means move a fraction $d$ of the way from the lower observation to the next one. $Q_2$ is the median.
:::

For example, a position of 2.25 does **not** mean use the second observed value or the third. Start at observation 2, then move one quarter of the gap toward observation 3. A position of 6.75 means move three quarters of the way from observation 6 toward observation 7. Because this rule uses $(n+1)$, it sometimes disagrees with Excel, other calculators, statistical packages or the median-of-halves shortcut. For this course, the rule above wins even if another convention seems familiar.

:::definition[Definition 2.6 — Interquartile range]
The interquartile range is

$$
IQR=Q_3-Q_1.
$$

This is printed on **Final Exam Equations, page 1**. It is the width of the middle half of the ordered distribution. It is never negative because $Q_3\ge Q_1$.
:::

Quartiles divide an ordered sample into approximately equal parts, not always exact counts of points strictly below each cutoff. Repeated values and interpolation can place several observations at a quartile.

### An eight-observation example that exposes the method

Using steel-price observations, the sorted list is $684,697,802,839,861,896,983,1089$. There are eight values. The lower-quartile position is $(8+1)/4=2.25$, so $Q_1=697+0.25(802-697)=723.25$. The median position is 4.5, so $Q_2=(839+861)/2=850$. The upper-quartile position is $3(8+1)/4=6.75$, so $Q_3=896+0.75(983-896)=961.25$. The IQR is $961.25-723.25=238$. Copying the middle-half medians instead would produce different values and is not the assigned method.

On the final, a choice like $238$ is not merely a memorized answer. It should be recognizable as a positive gap between two quartiles, measured in the original units, and one that is smaller than the entire observed range of $1089-684=405$. An IQR of 405 would mean you accidentally computed range. An IQR of 0 when the middle half is visibly spread out would signal a counting or ordering error.

:::callout-pitfall[Quartile calculations that look plausible but are wrong]
Do **not** use the calculator's quartiles, a spreadsheet's inclusive/exclusive setting, or the median of each half without checking whether it equals the instructor's positions. Do **not** interpolate using the original unsorted order. Do **not** round the position 2.25 to 2 or 3. Finally, write $IQR=Q_3-Q_1$, never $Q_1-Q_3$ and never $\max-\min$. If two values tie around a quartile, ordinary interpolation gives that same value; this does not justify choosing a different rule.
:::

:::example[Example 2.5 — SI free response: ten sculpture weights and five-number summary]
In the Exam 1 SI review, the weights in kilograms of 10 sculptures are listed. Calculate the sample mean, sample variance, sample standard deviation, and the five-number summary using the instructor's quartile rule.

**Data:** 11, 14.4, 14.8, 4.8, 9.2, 10.9, 18.3, 12.3, 17.2, 12.9.

::::answer[Answer]
**Answer:** mean 12.58; variance 15.528; standard deviation 3.941; minimum 4.8; lower quartile 10.475; median 12.6; upper quartile 15.4; maximum 18.3.

1. Put all ten weights into 1-VAR mode. A correctly entered list returns $n=10$, $\bar{x}=12.58$ kilograms, and $Sx=3.940614729$ kilograms. This is the sample standard deviation because we selected $Sx$ rather than the population value.

2. To find the variance, square the sample standard deviation without rounding it first: $s^2=(3.940614729)^2=15.52844444\ \mathrm{kg}^2$. By hand, the deviations are each measured from $12.58$, squared, added and divided by $10-1=9$.

3. Sort the ten observations: $4.8,9.2,10.9,11,12.3,12.9,14.4,14.8,17.2,18.3$. The five-number summary starts with the actual minimum $4.8$ and ends with the actual maximum $18.3$.

4. $Q_1$ lies at $11/4=2.75$, so start from $9.2$ and add $0.75(10.9-9.2)$, giving $10.475$. The median sits at position $5.5$, between $12.3$ and $12.9$, giving $12.6$. $Q_3$ sits at $3(11)/4=8.25$, between $14.8$ and $17.2$, giving $15.4$.

5. The source key rounds the mean, variance and standard deviation to approximately $12.58$, $15.53$ and $3.94$. Those agree with independent calculation. The quartile positions also agree; they are not the same as simply taking halves of the ordered list.

Check: The median sculpture weighs 12.6 kg; the sample mean is nearly the same, and the middle half runs from 10.475 to 15.4 kg.
::::
:::

:::example[Example 2.6 — Steel prices: interpolation at quarter positions]
For the eight quarterly US steel prices in the earlier homework, calculate the lower quartile, median, upper quartile and IQR. Use $(n+1)/4$ interpolation, not the median-of-halves convention.

**Data:** 684, 697, 802, 896, 839, 861, 983, 1089.

::::answer[Answer]
**Answer:** lower quartile 723.25; median 850; upper quartile 961.25; IQR 238.

1. Sort the prices in dollars per metric ton: $684,697,802,839,861,896,983,1089$. With $n=8$, the quartile positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$.

2. Lower quartile: $Q_1=x_{(2)}+0.25(x_{(3)}-x_{(2)})=697+0.25(802-697)=723.25$. Write the starting and ending observations explicitly; the 0.25 applies to the *gap* of 105, not to 802 alone.

3. Middle quartile: $Q_2=839+0.5(861-839)=850$. Upper quartile: $Q_3=896+0.75(983-896)=961.25$. The upper interpolation must use the sixth and seventh ordered values, not the last pair.

4. Subtract the two outside quartiles to find $IQR=961.25-723.25=238$ dollars per metric ton. The sample range is $1089-684=405$, which is different because the IQR excludes the outer portions in its definition.

Check: The central half of the sampled quarterly steel-price distribution spans 238 dollars per metric ton under the instructor's specified quartile method.
::::
:::

:::example[Example 2.7 — Repeated readings: identify a mode without averaging]
A sensor produces nine recorded integer readings. Report all modes and explain the difference from the median.

**Data:** 2, 4, 5, 5, 7, 8, 8, 8, 9.

::::answer[Answer]
**Answer:** mode 8.

1. Sort the recorded values and count repetitions rather than using a formula for an average. In this list the measurement 8 occurs three times, 5 occurs twice, and the other readings occur once each.

2. The mode is therefore the value with the greatest count. Its result is a measured reading, not a frequency: report the value 8, not “3.”

3. The median, by contrast, is the fifth observation after ordering because $n=9$. It may happen to equal a modal reading in a sample, but one is determined by position and the other by repetition.

Check: No other reading occurs three times, so there is a single mode. The mode says which value is most common in these nine recorded sensor measurements.
::::
:::

:::problem[Problem 2.8 — SI review: IQR from given quartiles]{difficulty=easy}
A data set has $Q_1=15$ and $Q_3=38$. Find the IQR. Choices: (A) 23, (B) 53, (C) 15, (D) 38.

**Quartiles:** 15, 38.

::::solution[Solution]
**Answer:** (A) IQR 23.

1. The quartiles are already given, so there is no reason to sort a dataset or calculate quartile positions. The lower quartile is 15 and the upper quartile is 38.

2. Apply the Final-sheet formula $IQR=Q_3-Q_1=38-15=23$. This measures the distance between the two cut points for the middle half of the observations.

3. Choose A. Choice B adds the quartiles, while C and D merely repeat one of the endpoints. The IQR cannot be negative because the upper quartile is at least as large as the lower one.

Check: $15+23=38$, recovering the stated upper quartile.
::::
:::

:::problem[Problem 2.9 — Odd sample: calculate all three quartiles]{difficulty=standard}
Seven machine cycle times are recorded in seconds. Sort the data and find all three quartiles and the IQR using the position formula.

**Data:** 21, 24, 25, 25, 28, 29, 31.

::::solution[Solution]
**Answer:** lower quartile 24; median 25; upper quartile 29; IQR 5.

1. Put the measurements in ascending order: 21, 24, 25, 25, 28, 29, 31. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2$, $p_2=4$, and $p_3=6$. Interpolate fractional positions: $Q_1=24$, median $=25$, $Q_3=29$.

3. $IQR=Q_3-Q_1=29-24=5$. This is the middle-half width, not the full range.

4. With seven observations, the quartile positions turn out to be integers. Interpolation is unnecessary in this particular sample, but the position rule has not changed.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.10 — Even sample: fractional-position quartiles]{difficulty=standard}
Eight bolt-strength measurements are recorded in kilonewtons. Compute $Q_1$, $Q_2$, $Q_3$ and IQR. Show the fractional positions.

**Data:** 42, 43, 46, 47, 48, 52, 61, 70.

::::solution[Solution]
**Answer:** lower quartile 43.75; median 47.5; upper quartile 58.75; IQR 15.

1. Put the measurements in ascending order: 42, 43, 46, 47, 48, 52, 61, 70. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$. Interpolate fractional positions: $Q_1=43.75$, median $=47.5$, $Q_3=58.75$.

3. $IQR=Q_3-Q_1=58.75-43.75=15$. This is the middle-half width, not the full range.

4. A value in the gap between observations is a legitimate interpolated quartile and does not need to appear verbatim in the dataset.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.11 — Mode after repeated part measurements]{difficulty=easy}
Nine parts are measured to the nearest whole millimeter. Identify every modal value, even if the distribution has only one mode.

**Data:** 5, 5, 6, 7, 8, 9, 9, 9.

::::solution[Solution]
**Answer:** mode 9.

1. Tally each distinct observation rather than averaging values. The counts are 5 occurs 2 times, 6 occurs 1 time, 7 occurs 1 time, 8 occurs 1 time, 9 occurs 3 times.

2. The greatest frequency is 3. The most frequent observation is 9.

3. The mode may share the same value as the median, but the definitions differ: the mode counts repetition whereas the median follows ordered positions. A multimodal sample has more than one most-frequent value.

4. The modal measurement is the observation repeated most often; its frequency is not the answer.

Check: These part measurements are summarized with the requested sample convention and appropriate units.
::::
:::

:::problem[Problem 2.12 — Quartiles after an extreme reading]{difficulty=challenge}
Eight temperature observations include one unusually large value. Find the lower quartile, median, upper quartile, and IQR without deleting anything.

**Data:** 100, 102, 103, 104, 106, 110, 117, 138.

::::solution[Solution]
**Answer:** lower quartile 102.25; median 105; upper quartile 115.25; IQR 13.

1. Put the measurements in ascending order: 100, 102, 103, 104, 106, 110, 117, 138. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$. Interpolate fractional positions: $Q_1=102.25$, median $=105$, $Q_3=115.25$.

3. $IQR=Q_3-Q_1=115.25-102.25=13$. This is the middle-half width, not the full range.

4. Do not remove an observation simply because it looks extreme. Outlier classification comes later and the quartiles must be computed from the stated sample.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.13 — An IQR with decimal measurements]{difficulty=standard}
Seven measured metal thicknesses, in millimeters, appear below. Compute the IQR using the class method.

**Data:** 1.1, 1.2, 1.3, 1.6, 1.6, 2, 2.2.

::::solution[Solution]
**Answer:** IQR 0.8.

1. Sort the data and count $n=7$. The ordered values are 1.1, 1.2, 1.3, 1.6, 1.6, 2, 2.2.

2. Locate $Q_1$ at position $(7+1)/4=2$ and $Q_3$ at position $3(7+1)/4=6$. Interpolate if a position has a fractional part.

3. Compute $IQR=Q_3-Q_1=2-1.2=0.8$. It measures the width of the middle half of these values, so it is different from their full range.

4. Retain the decimal positions. Sorting decimals is no different from sorting integers.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.14 — Six readings: upper and lower quartiles]{difficulty=standard}
A technician records six voltages. Compute the first, second, third quartiles and their interquartile range.

**Data:** 7, 8, 8, 9, 11, 13.

::::solution[Solution]
**Answer:** lower quartile 7.75; median 8.5; upper quartile 11.5; IQR 3.75.

1. Put the measurements in ascending order: 7, 8, 8, 9, 11, 13. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=1.75$, $p_2=3.5$, and $p_3=5.25$. Interpolate fractional positions: $Q_1=7.75$, median $=8.5$, $Q_3=11.5$.

3. $IQR=Q_3-Q_1=11.5-7.75=3.75$. This is the middle-half width, not the full range.

4. The 1.75 and 5.25 positions use interpolation between neighboring ordered observations, not the median of each half.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

## 2.3 Dot Plots, Stem-and-Leaf Diagrams, and Histograms

:::callout-intuition[Make the distribution visible before interpreting it]
A mean and a standard deviation compress a sample into only two numbers. Compression is helpful when reporting results, but it can hide a second cluster, a long tail, a gap or an isolated observation. A dot plot preserves each observed location, a stem-and-leaf diagram preserves the original digits while grouping similar values, and a histogram counts observations inside intervals. Recognition cue: *construct a dot diagram* means mark every reading; *stem and leaf* means retain each value as digits; *histogram* means group the measurements into labeled intervals and make each bar height equal to its count or relative frequency.
:::

### Dot plot: one mark per observation

:::definition[Definition 2.7 — Dot diagram]
A dot diagram places a mark above the observed value on a number line for **each** measurement. Repeated values stack as repeated dots, making clusters, gaps and high-frequency individual values visible without first choosing bins.
:::

The study-hours exercise from the slides has six distinct values, so there is one dot at each of six horizontal positions. If another student had also studied 10 hours, there would be two dots at 10, not one larger dot and not a connected line. The horizontal distance between 10 and 13 should reflect the numeric gap of three hours. Dot plots work best for small samples, where the individual observations can still be read.

:::callout-pitfall[The graph type determines what a mark means]
A dot plot mark is one observation. In a histogram, a whole bar reports how many observations fell within an interval. A time-series line connects observations in chronological order, not sorted order. Never connect the dots in a dot diagram simply because the graph appears sparse, and never choose frequencies by reading the height of a smooth curve or a probability density when the original data are discrete measurements.
:::

### Stem-and-leaf: preserve the original numbers

:::definition[Definition 2.8 — Stem and leaf]
Split each observed value into a **stem** of leading digit or digits and a **leaf** of remaining digits. List stems in ascending order; sort their leaves. Provide a key that explains the units, for example, $23\mid 9$ means 239 pounds when stems are tens and leaves are ones.
:::

Suppose weights include 189, 196, 196, 200, 201, 209 and 216 pounds. Their stems are 18, 19, 20 and 21; leaves appear as $18\mid9$, $19\mid66$, $20\mid019$ and $21\mid6$. You can see duplicated 196 immediately from the two leaves and reconstruct every measurement. This is a reason the instructor's slide of 80 aluminum-lithium alloy compressive-strength measurements uses a stem-and-leaf display: the tabulation retains individual digits while making the central cluster and tails visible.

If the smallest value has three digits and the largest also has three, a two-digit stem and one-digit leaf is often sensible. If readings contain decimals, the key must say how much a leaf represents. A stem of 6 and leaf of 3 could mean 63, 6.3 or 603 depending on the convention. Without a key the plot is ambiguous. Also, leaves must not be averaged, and the stem list should not skip a meaningful empty stem if the gap is relevant to the shape.

### Histogram: intervals and frequencies

:::definition[Definition 2.9 — Histogram]
A histogram divides a numerical scale into adjacent **bins** or class intervals. Above each interval, draw a rectangle whose height represents the **frequency** (number of observations in the interval) or **relative frequency** (the bin count divided by the sample size). The slide's construction procedure is: label bin boundaries on the horizontal axis, label the vertical scale, then draw each rectangle to the appropriate height.
:::

For hand counting, use a clear boundary convention: $[180,200)$ contains 180 up to but not including 200, while $[200,220)$ contains 200 through values below 220. This convention prevents 200 from being assigned to two bins. The instructor's slides present a compressive-strength histogram with frequency and relative-frequency axes. A frequency of 5 in a sample of 20 corresponds to a relative frequency of $5/20=0.25$, or 25% of the observations. Adding all frequency bars must return the sample size; adding relative frequencies must return 1.

A histogram differs from a bar chart of categories. A histogram's horizontal intervals represent an ordered numerical quantity and the bars normally touch, while separate categorical columns do not encode continuous numerical adjacency. With equal-width bins, height alone directly compares frequencies. If unequal bin widths are deliberately chosen, interpreting areas instead of heights is necessary for a frequency-density histogram, but this unit's construction exercises use ordinary equal-width bins and do not require density calculations.

### Shape: center, spread, skew, and gaps

The **center** is approximately where the observations congregate. **Spread** is the range of horizontal values populated and how tightly those values cluster. **Skew** describes a longer tail on one side: a long right tail means right-skewed, even if the tallest bar is left of center; a long left tail means left-skewed. A histogram with approximately matching left and right sides is roughly symmetric, but it need not follow a normal distribution. A clearly separated bar or single extreme dot may indicate an outlier worth checking with a box plot.

Pay attention to the axes before giving a shape diagnosis. If the bins are $60$–$70$, $70$–$80$, $80$–$90$ and $90$–$100$, the horizontal scale is score and the vertical axis should be a count or relative frequency. A tall bar at 80–90 does not mean 80%–90% of students fell in that bar; it only identifies where that bar sits on the horizontal axis. If the frequency was four out of ten, the bar represents 40%, regardless of its horizontal position.

Bin width affects appearance: broad bins conceal detail, narrow bins can be sparse. Use assigned boundaries or explicitly state yours; the reader must be able to reproduce the counts.

:::example[Example 2.8 — Exam 1 practice: Calculus II scores and two distribution displays]
Ten Calculus II final-exam scores are listed below. (a) Calculate the sample mean and sample variance. (b) Calculate the first three quartiles and IQR and construct a box plot. (c) Construct a stem-and-leaf diagram and a histogram. Use score intervals $[60,70),[70,80),[80,90),[90,100)$.

**Data:** 82, 77, 71, 60, 89, 93, 73, 74, 83, 66.

**Bin edges:** 60, 70, 80, 90, 100.

::::answer[Answer]
**Answer:** mean 76.8; variance 103.511; lower quartile 69.75; median 75.5; upper quartile 84.5; IQR 14.75; bin count 2; bin count 4; bin count 3; bin count 1.

1. There are ten scores, with total $768$. The sample mean is $768/10=76.8$. Enter all ten scores in 1-VAR mode, obtain $Sx=10.17404104$, and square it before rounding to find $s^2=103.5111111\ \mathrm{score\ points}^2$.

2. Order the scores: $60,66,71,73,74,77,82,83,89,93$. Positions $p_1=2.75$, $p_2=5.5$, and $p_3=8.25$ produce $Q_1=66+0.75(71-66)=69.75$, median $=(74+77)/2=75.5$, and $Q_3=83+0.25(89-83)=84.5$. Subtract $84.5-69.75=14.75$ for IQR.

3. For the stem-and-leaf display, use tens as stems and ones as leaves. A complete display is:

```text
6 | 0 6
7 | 1 3 4 7
8 | 2 3 9
9 | 3
Key: 7 | 4 means a score of 74.
```

4. For the histogram, count values in the stated left-closed, right-open score intervals. The four frequencies are 2, 4, 3 and 1, totaling ten scores. Each bar has width ten score points, so height compares the frequency directly.

5. For the box plot, the fences are $69.75-1.5(14.75)=47.625$ and $84.5+1.5(14.75)=106.625$. All scores lie between those boundaries; whiskers extend to observed scores 60 and 93. The box extends from 69.75 to 84.5 with a median line at 75.5.

Check: The group averaged 76.8 points; the middle half of scores lies between 69.75 and 84.5, and no score is a 1.5-IQR outlier.
::::
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Histogram Exam score interval with bin frequencies 2, 4, 3, 1">
<line class="fig-axis" x1="60.00" y1="190.00" x2="640.00" y2="190.00"/>
<line class="fig-axis" x1="60.00" y1="190.00" x2="60.00" y2="44.00"/>
<text class="fig-label" x="52.00" y="24.00">Frequency</text>
<text class="fig-label" x="275.00" y="240.00">Exam score interval</text>
<line class="fig-axis" x1="55.00" y1="190.00" x2="60.00" y2="190.00"/>
<text class="fig-label" x="20.00" y="194.00">0</text>
<line class="fig-axis" x1="55.00" y1="131.60" x2="60.00" y2="131.60"/>
<text class="fig-label" x="20.00" y="135.60">2</text>
<line class="fig-axis" x1="55.00" y1="73.20" x2="60.00" y2="73.20"/>
<text class="fig-label" x="20.00" y="77.20">4</text>
<rect class="fig-fill" x="61.00" y="131.60" width="143.00" height="58.40"/>
<text class="fig-label" x="65.00" y="211.00">60–70</text>
<text class="fig-label" x="129.50" y="124.60">2</text>
<rect class="fig-fill" x="206.00" y="73.20" width="143.00" height="116.80"/>
<text class="fig-label" x="210.00" y="211.00">70–80</text>
<text class="fig-label" x="274.50" y="66.20">4</text>
<rect class="fig-fill" x="351.00" y="102.40" width="143.00" height="87.60"/>
<text class="fig-label" x="355.00" y="211.00">80–90</text>
<text class="fig-label" x="419.50" y="95.40">3</text>
<rect class="fig-fill" x="496.00" y="160.80" width="143.00" height="29.20"/>
<text class="fig-label" x="500.00" y="211.00">90–100</text>
<text class="fig-label" x="564.50" y="153.80">1</text>
</svg>
<figcaption>The ten Calculus II scores produce frequencies 2, 4, 3, 1 in consecutive ten-point classes; the bar counts must total ten.</figcaption>
</figure>

:::example[Example 2.9 — Exam 1 practice: solution concentration and standard error]
One operator measures the concentration of a solution six times using the same instrument. Calculate the sample mean, sample standard deviation, standard error, IQR, and construct a histogram using bins $[63,64),[64,65),[65,66),[66,67),[67,68)$.

**Data:** 63.2, 67.1, 65.8, 64, 65.1, 65.3.

**Bin edges:** 63, 64, 65, 66, 67, 68.

::::answer[Answer]
**Answer:** mean 65.083; standard deviation 1.367; standard error 0.558; IQR 2.325; bin count 1; bin count 1; bin count 3; bin count 0; bin count 1.

1. The six concentrations sum to $390.5$, so the sample mean is $390.5/6=65.08333333$. In 1-VAR, $Sx=1.36735755$ and $n=6$. That is the standard deviation of the **individual** concentration readings, not the standard error of their mean.

2. The standard error was requested explicitly on this Exam 1 practice sheet. **Final sheet, page 1** lists the estimated standard error as $s/\sqrt{n}$. Evaluate $1.36735755/\sqrt6=0.55828$ in the same concentration units. Chapter 7 explains why a mean based on six readings has this smaller sampling uncertainty.

3. Order the readings: $63.2,64.0,65.1,65.3,65.8,67.1$. Quartile positions are 1.75 and 5.25. Thus $Q_1=63.2+0.75(64.0-63.2)=63.8$ and $Q_3=65.8+0.25(67.1-65.8)=66.125$. Their difference is $IQR=2.325$.

4. To draw the histogram, the intervals $[63,64),[64,65),[65,66),[66,67),[67,68)$ contain 1, 1, 3, 0, 1 observations. These frequencies sum to six. The empty 66–67 interval is a gap in this particular binned display, not evidence that such concentrations are impossible.

5. State the distinction when checking the result: standard deviation measures variation among six observed readings; standard error estimates variation of the mean across repeat samples. The latter is not a replacement for $Sx$ in the data summary.

Check: The mean concentration is approximately 65.083, with sample standard deviation 1.367, estimated standard error 0.558, and IQR 2.325 in the concentration's units.
::::
:::

:::example[Example 2.10 — Football players: a histogram and stem-and-leaf diagram]
The weights in pounds of 20 MSU football players appear in Unit 2 Exercise 2. Construct a stem-and-leaf diagram and a histogram using bins with endpoints 180, 200, 220, 240, 260, 280, 300 and 320. The exercise also asks for a box plot, completed in Section 2.4.

**Data:** 189, 209, 233, 249, 196, 216, 239, 252, 196, 221, 239, 258, 200, 227, 243, 259, 201, 232, 246, 319.

**Bin edges:** 180, 200, 220, 240, 260, 280, 300, 320.

::::answer[Answer]
**Answer:** sample size 20; bin count 3; bin count 4; bin count 6; bin count 6; bin count 0; bin count 0; bin count 1.

1. Count the twenty weights. Sorting the values makes both displays easier: $189,196,196,200,201,209,216,221,227,232,233,239,239,243,246,249,252,258,259,319$ pounds.

2. With two leading digits as stems, a stem of 23 and a leaf of 9 means a 239-pound player. Write every observation and preserve duplicates:

```text
18 | 9
19 | 6 6
20 | 0 1 9
21 | 6
22 | 1 7
23 | 2 3 9 9
24 | 3 6 9
25 | 2 8 9
26 | 
27 | 
28 | 
29 | 
30 | 
31 | 9
Key: 23 | 9 means 239 pounds.
```

3. For bins $[180,200)$, $[200,220)$, $[220,240)$, $[240,260)$, $[260,280)$, $[280,300)$, $[300,320)$, counts are 3, 4, 6, 6, 0, 0, 1. No 200-pound weight belongs in the first bin, and the 319-pound weight does belong in the last bin.

4. Plot seven adjacent bars of equal width 20 pounds using those frequencies. The last bar is isolated after two empty bins, a strong graphical warning of an unusual large observation. Whether it qualifies as a box-plot outlier requires the quartile-and-fence calculation, not visual intuition alone.

5. Unit 2 Exercise 2 also requests a box plot. Section 2.4 completes its first, second and third quartiles, lower and upper fences, whiskers, and the formal outlier check using precisely these twenty weights.

Check: The histogram frequencies total $3+4+6+6+0+0+1=20$ and every stem-and-leaf entry reconstructs an original player weight.
::::
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Histogram Player weight (lb) with bin frequencies 3, 4, 6, 6, 0, 0, 1">
<line class="fig-axis" x1="60.00" y1="190.00" x2="640.00" y2="190.00"/>
<line class="fig-axis" x1="60.00" y1="190.00" x2="60.00" y2="44.00"/>
<text class="fig-label" x="52.00" y="24.00">Frequency</text>
<text class="fig-label" x="275.00" y="240.00">Player weight (lb)</text>
<line class="fig-axis" x1="55.00" y1="190.00" x2="60.00" y2="190.00"/>
<text class="fig-label" x="20.00" y="194.00">0</text>
<line class="fig-axis" x1="55.00" y1="148.29" x2="60.00" y2="148.29"/>
<text class="fig-label" x="20.00" y="152.29">2</text>
<line class="fig-axis" x1="55.00" y1="106.57" x2="60.00" y2="106.57"/>
<text class="fig-label" x="20.00" y="110.57">4</text>
<line class="fig-axis" x1="55.00" y1="64.86" x2="60.00" y2="64.86"/>
<text class="fig-label" x="20.00" y="68.86">6</text>
<rect class="fig-fill" x="61.00" y="127.43" width="80.86" height="62.57"/>
<text class="fig-label" x="65.00" y="211.00">180–200</text>
<text class="fig-label" x="98.43" y="120.43">3</text>
<rect class="fig-fill" x="143.86" y="106.57" width="80.86" height="83.43"/>
<text class="fig-label" x="147.86" y="211.00">200–220</text>
<text class="fig-label" x="181.29" y="99.57">4</text>
<rect class="fig-fill" x="226.71" y="64.86" width="80.86" height="125.14"/>
<text class="fig-label" x="230.71" y="211.00">220–240</text>
<text class="fig-label" x="264.14" y="57.86">6</text>
<rect class="fig-fill" x="309.57" y="64.86" width="80.86" height="125.14"/>
<text class="fig-label" x="313.57" y="211.00">240–260</text>
<text class="fig-label" x="347.00" y="57.86">6</text>
<rect class="fig-fill" x="392.43" y="190.00" width="80.86" height="0.00"/>
<text class="fig-label" x="396.43" y="211.00">260–280</text>
<rect class="fig-fill" x="475.29" y="190.00" width="80.86" height="0.00"/>
<text class="fig-label" x="479.29" y="211.00">280–300</text>
<rect class="fig-fill" x="558.14" y="169.14" width="80.86" height="20.86"/>
<text class="fig-label" x="562.14" y="211.00">300–320</text>
<text class="fig-label" x="595.57" y="162.14">1</text>
</svg>
<figcaption>The football weights cluster between 180 and 260 pounds, with a gap before the isolated 319-pound observation.</figcaption>
</figure>

:::example[Example 2.11 — What a histogram can and cannot tell you]
Ten factory measurements are to be grouped into consecutive equal-width bins. Construct their frequency histogram for intervals $[20,25),[25,30),[30,35),[35,40)$ and identify the sample size from the bars.

**Data:** 20, 21, 22, 26, 27, 28, 29, 31, 36, 55.

**Bin edges:** 20, 25, 30, 35, 40, 45, 50, 55, 60.

::::answer[Answer]
**Answer:** sample size 10; bin count 3; bin count 4; bin count 1; bin count 1; bin count 0; bin count 0; bin count 0; bin count 1.

1. Sort the observations as $20,21,22,26,27,28,29,31,36,55$ and read the chosen bin boundaries carefully. The sample actually includes **ten** measurements, and one, 55, is **outside all four suggested bins**.

2. Counting values only inside the stated four bins gives 3 in 20–25, 4 in 25–30, 1 in 30–35 and 1 in 35–40. Those counts add to nine, not ten. A histogram with only those bins would therefore omit the 55 measurement and cannot represent the complete sample.

3. Extend the bins with $[40,45),[45,50),[50,55),[55,60)$ to include 55, giving four additional counts of 0, 0, 0, 1. If the provided bins are fixed, explicitly identify the observation outside their coverage rather than falsely claiming the existing bars exhaust the sample.

4. To check any histogram, first confirm the horizontal intervals cover the full range of values. Only then does the sum of the bin frequencies equal the sample size. This is the best way to catch a plot that visually looks tidy while losing an extreme reading.

Check: The four stated bins contain nine values and the additional value at 55 must be accounted for when presenting all ten readings.
::::
:::

:::problem[Problem 2.15 — Histogram frequencies from six calibration values]{difficulty=easy}
Construct a histogram of these six values using $[8,10),[10,12),[12,14),[14,16),[16,18)$. Give the frequency in every class, including empty ones.

**Data:** 8, 10, 11, 12, 14, 16.

**Bin edges:** 8, 10, 12, 14, 16, 18.

::::solution[Solution]
**Answer:** bin count 1; bin count 2; bin count 1; bin count 1; bin count 1.

1. The class $[8, 10)$ has 1 observation; its right edge is excluded.

2. The class $[10, 12)$ has 2 observations; its right edge is excluded.

3. The class $[12, 14)$ has 1 observation; its right edge is excluded.

4. The class $[14, 16)$ has 1 observation; its right edge is excluded.

5. The class $[16, 18)$ has 1 observation; its right edge is excluded.

6. Frequencies total 1 + 2 + 1 + 1 + 1 = 6 = n$. This confirms no reading was lost or double-counted.

7. The classes are half-open, so the value 10 belongs in the class beginning at 10 rather than the class ending at 10.

Check: The bar counts total 6, accounting for all 6 readings.
::::
:::

:::problem[Problem 2.16 — How many readings are shown by the bars?]{difficulty=standard}
An eight-measurement sample is grouped in bins $[40,45),[45,50),[50,55),[55,60),[60,65),[65,70),[70,75)$. Record the sample size and all bar heights.

**Data:** 42, 43, 46, 47, 48, 52, 61, 70.

**Bin edges:** 40, 45, 50, 55, 60, 65, 70, 75.

::::solution[Solution]
**Answer:** sample size 8; bin count 2; bin count 3; bin count 1; bin count 0; bin count 1; bin count 0; bin count 1.

1. The class $[40, 45)$ has 2 observations; its right edge is excluded.

2. The class $[45, 50)$ has 3 observations; its right edge is excluded.

3. The class $[50, 55)$ has 1 observation; its right edge is excluded.

4. The class $[55, 60)$ has 0 observations; its right edge is excluded.

5. The class $[60, 65)$ has 1 observation; its right edge is excluded.

6. The class $[65, 70)$ has 0 observations; its right edge is excluded.

7. The class $[70, 75)$ has 1 observation; its right edge is excluded.

8. Frequencies total 2 + 3 + 1 + 0 + 1 + 0 + 1 = 8 = n$. This confirms no reading was lost or double-counted.

9. Each observation must be covered exactly once by a class. The sum of the bins is an effective check of a hand-drawn histogram.

Check: The bar counts total 8, accounting for all 8 readings.
::::
:::

:::problem[Problem 2.17 — Read a stem-and-leaf plot]{difficulty=standard}
A data set has sorted observations shown below. Make a stem-and-leaf diagram with tens as stems and units as leaves. Then identify the range.

**Data:** 20, 24, 24, 28, 30, 35, 37, 41.

::::solution[Solution]
**Answer:** range 21.

1. Locate the smallest and largest actual observations, not the first and last entries in the unsorted list. Here the minimum is 20 and the maximum is 41.

2. Subtract minimum from maximum: $r=41-20=21$. Do not divide by the number of observations; this is a distance between endpoints.

3. The range has the same units as the data. It says how wide the observed values span, but not whether most of the observations are clustered near the middle or one end.

4. With a tens stem, 2 | 4 means 24. The two 24 readings need two leaves; a single leaf would lose an observation. A suitable display has stems 2, 3 and 4.

Check: These stem-and-leaf readings are summarized with the requested sample convention and appropriate units.
::::
:::

:::problem[Problem 2.18 — Frequency bins and repeated observations]{difficulty=standard}
An instrument gives these eight readings. Use bins $[100,102),[102,104),[104,106),[106,108),[108,110),[110,112)$ and list the bar heights.

**Data:** 100, 101, 102, 102, 103, 103, 104, 110.

**Bin edges:** 100, 102, 104, 106, 108, 110, 112.

::::solution[Solution]
**Answer:** bin count 2; bin count 4; bin count 1; bin count 0; bin count 0; bin count 1.

1. The class $[100, 102)$ has 2 observations; its right edge is excluded.

2. The class $[102, 104)$ has 4 observations; its right edge is excluded.

3. The class $[104, 106)$ has 1 observation; its right edge is excluded.

4. The class $[106, 108)$ has 0 observations; its right edge is excluded.

5. The class $[108, 110)$ has 0 observations; its right edge is excluded.

6. The class $[110, 112)$ has 1 observation; its right edge is excluded.

7. Frequencies total 2 + 4 + 1 + 0 + 0 + 1 = 8 = n$. This confirms no reading was lost or double-counted.

8. The 102 and 103 values occur twice; repetition increases a bin frequency and must not be collapsed into a single observation.

Check: The bar counts total 8, accounting for all 8 readings.
::::
:::

:::problem[Problem 2.19 — Choose an appropriate graph]{difficulty=easy}
A repair shop recorded an ordered sequence of daily defect counts. Explain why a time-series plot preserves information a sorted stem-and-leaf plot removes, and identify which axis represents time.

::::solution[Solution]
**Answer:** See the reasoning below..

1. A time-series plot keeps the observations in chronological order and puts time on the horizontal axis. Its vertical position shows the defect count recorded on that day.

2. Sorting the same counts into a stem-and-leaf diagram keeps their numerical distribution but destroys which day was first, second and so on. It can no longer reveal a systematic rise in defects over successive days.

3. A histogram tells how often count values occur, not when the counts occurred. For engineering troubleshooting, both the shape of observed counts and their sequence can matter; choose the time-series plot when the question asks for a trend over time.

Check: The graph axes must be labeled time horizontally and measured defect count vertically.
::::
:::

:::problem[Problem 2.20 — Binning an isolated high reading]{difficulty=challenge}
Eight inspection readings are shown. Construct a histogram with 10-unit bins beginning at 60 and ending at 100. Give the bar counts, including the high final measurement.

**Data:** 60, 61, 62, 65, 66, 69, 73, 95.

**Bin edges:** 60, 70, 80, 90, 100.

::::solution[Solution]
**Answer:** bin count 6; bin count 1; bin count 0; bin count 1.

1. The class $[60, 70)$ has 6 observations; its right edge is excluded.

2. The class $[70, 80)$ has 1 observation; its right edge is excluded.

3. The class $[80, 90)$ has 0 observations; its right edge is excluded.

4. The class $[90, 100)$ has 1 observation; its right edge is excluded.

5. Frequencies total 6 + 1 + 0 + 1 = 8 = n$. This confirms no reading was lost or double-counted.

6. A single high reading should appear in the rightmost interval, not be silently discarded because most of the sample sits close to 60–70.

Check: The bar counts total 8, accounting for all 8 readings.
::::
:::

:::problem[Problem 2.21 — Interpreting the highest bin]{difficulty=standard}
An eight-value sample is grouped into bins $[10,15),[15,20),[20,25),[25,30),[30,35),[35,40),[40,45),[45,50)$. Find each frequency, then explain why the highest-frequency bin is not necessarily equal to the sample mean.

**Data:** 12, 14, 16, 18, 22, 24, 30, 45.

**Bin edges:** 10, 15, 20, 25, 30, 35, 40, 45, 50.

::::solution[Solution]
**Answer:** bin count 2; bin count 2; bin count 2; bin count 0; bin count 1; bin count 0; bin count 0; bin count 1.

1. The class $[10, 15)$ has 2 observations; its right edge is excluded.

2. The class $[15, 20)$ has 2 observations; its right edge is excluded.

3. The class $[20, 25)$ has 2 observations; its right edge is excluded.

4. The class $[25, 30)$ has 0 observations; its right edge is excluded.

5. The class $[30, 35)$ has 1 observation; its right edge is excluded.

6. The class $[35, 40)$ has 0 observations; its right edge is excluded.

7. The class $[40, 45)$ has 0 observations; its right edge is excluded.

8. The class $[45, 50)$ has 1 observation; its right edge is excluded.

9. Frequencies total 2 + 2 + 2 + 0 + 1 + 0 + 0 + 1 = 8 = n$. This confirms no reading was lost or double-counted.

10. The tallest frequency bar names an interval with many observations, not an arithmetic mean. To find the exact mean, retain and average the original measurements.

Check: The bar counts total 8, accounting for all 8 readings.
::::
:::

### The other displays on the instructor's slides

The lecture moves from histograms and box plots to time-series and probability plots. A **time-series plot** uses time horizontally and an observed value vertically. Consecutive values are connected in time order so the reader can recognize cycles, sustained trends or abrupt process changes. For example, an upward progression of sample means from one month to the next can reveal drift that a single overall histogram obscures. A histogram of those same values discards the time labels. Never sort a time series by magnitude before joining its points, because doing so invents a trend.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Connected daily defect-count observations, with an overall upward trend">
<line class="fig-axis" x1="65.00" y1="189.00" x2="642.00" y2="189.00"/>
<line class="fig-axis" x1="65.00" y1="189.00" x2="65.00" y2="49.00"/>
<text class="fig-label" x="12.00" y="30.00">Defects</text>
<text class="fig-label" x="300.00" y="238.00">Production day</text>
<text class="fig-label" x="62.00" y="208.00">1</text>
<text class="fig-label" x="126.11" y="208.00">2</text>
<text class="fig-label" x="190.22" y="208.00">3</text>
<text class="fig-label" x="254.33" y="208.00">4</text>
<text class="fig-label" x="318.44" y="208.00">5</text>
<text class="fig-label" x="382.56" y="208.00">6</text>
<text class="fig-label" x="446.67" y="208.00">7</text>
<text class="fig-label" x="510.78" y="208.00">8</text>
<text class="fig-label" x="574.89" y="208.00">9</text>
<text class="fig-label" x="639.00" y="208.00">10</text>
<path class="fig-curve" d="M65.00,169.00 L129.11,159.00 L193.22,159.00 L257.33,129.00 L321.44,139.00 L385.56,119.00 L449.67,99.00 L513.78,109.00 L577.89,79.00 L642.00,69.00"/>
<circle class="fig-point" cx="65.00" cy="169.00" r="4"/>
<circle class="fig-point" cx="129.11" cy="159.00" r="4"/>
<circle class="fig-point" cx="193.22" cy="159.00" r="4"/>
<circle class="fig-point" cx="257.33" cy="129.00" r="4"/>
<circle class="fig-point" cx="321.44" cy="139.00" r="4"/>
<circle class="fig-point" cx="385.56" cy="119.00" r="4"/>
<circle class="fig-point" cx="449.67" cy="99.00" r="4"/>
<circle class="fig-point" cx="513.78" cy="109.00" r="4"/>
<circle class="fig-point" cx="577.89" cy="79.00" r="4"/>
<circle class="fig-point" cx="642.00" cy="69.00" r="4"/>
</svg>
<figcaption>Keeping production days in order reveals the upward drift and short-term reversals that a histogram of the same ten counts would hide.</figcaption>
</figure>

A **probability plot** orders observations and compares them with the positions expected under a hypothesized distribution using specially scaled axes. The final slide introduces the **normal probability plot** as a visual check of whether a sample might follow a normal distribution. When plotted points lie approximately on a straight line, the assumed shape is plausible; large systematic curvature or strong departures suggest a poor fit. This is a visual diagnostic, not a guarantee of normality and not a calculation with the $z$ table. The normal distribution and its table are covered in Chapter 5.

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Normal probability plot of ten sculpture weights against theoretical normal quantiles with a sampled reference line">
<line class="fig-axis" x1="72.00" y1="195.00" x2="635.00" y2="195.00"/>
<line class="fig-axis" x1="72.00" y1="195.00" x2="72.00" y2="35.00"/>
<text class="fig-label" x="20.00" y="21.00">Ordered weight</text>
<text class="fig-label" x="255.00" y="235.00">Expected normal quantile</text>
<path class="fig-guide" d="M84.80,166.30 L91.51,164.92 L98.23,163.54 L104.95,162.16 L111.67,160.79 L118.38,159.41 L125.10,158.03 L131.82,156.65 L138.54,155.27 L145.25,153.89 L151.97,152.51 L158.69,151.13 L165.41,149.75 L172.12,148.37 L178.84,146.99 L185.56,145.61 L192.28,144.23 L198.99,142.86 L205.71,141.48 L212.43,140.10 L219.15,138.72 L225.87,137.34 L232.58,135.96 L239.30,134.58 L246.02,133.20 L252.74,131.82 L259.45,130.44 L266.17,129.06 L272.89,127.68 L279.61,126.30 L286.32,124.93 L293.04,123.55 L299.76,122.17 L306.48,120.79 L313.19,119.41 L319.91,118.03 L326.63,116.65 L333.35,115.27 L340.06,113.89 L346.78,112.51 L353.50,111.13 L360.22,109.75 L366.94,108.37 L373.65,107.00 L380.37,105.62 L387.09,104.24 L393.81,102.86 L400.52,101.48 L407.24,100.10 L413.96,98.72 L420.68,97.34 L427.39,95.96 L434.11,94.58 L440.83,93.20 L447.55,91.82 L454.26,90.45 L460.98,89.07 L467.70,87.69 L474.42,86.31 L481.13,84.93 L487.85,83.55 L494.57,82.17 L501.29,80.79 L508.01,79.41 L514.72,78.03 L521.44,76.65 L528.16,75.27 L534.88,73.89 L541.59,72.52 L548.31,71.14 L555.03,69.76 L561.75,68.38 L568.46,67.00 L575.18,65.62 L581.90,64.24 L588.62,62.86 L595.33,61.48 L602.05,60.10 L608.77,58.72 L615.49,57.34 L622.20,55.96"/>
<circle class="fig-point" cx="155.60" cy="163.00" r="3.5"/>
<circle class="fig-point" cx="225.48" cy="133.67" r="3.5"/>
<circle class="fig-point" cx="269.64" cy="122.33" r="3.5"/>
<circle class="fig-point" cx="305.46" cy="121.67" r="3.5"/>
<circle class="fig-point" cx="337.82" cy="113.00" r="3.5"/>
<circle class="fig-point" cx="369.18" cy="109.00" r="3.5"/>
<circle class="fig-point" cx="401.54" cy="99.00" r="3.5"/>
<circle class="fig-point" cx="437.36" cy="96.33" r="3.5"/>
<circle class="fig-point" cx="481.52" cy="80.33" r="3.5"/>
<circle class="fig-point" cx="551.40" cy="73.00" r="3.5"/>
</svg>
<figcaption>On a normal probability plot, sorted measurements roughly aligning with a straight reference line support a plausible normal shape; systematic departures warn against that assumption.</figcaption>
</figure>

:::callout-connect[Connection to Chapter 5]
Chapter 5 develops normal random variables and the standard normal table. This chapter only requires recognizing the visual purpose of a normal probability plot: ordered data should approximately align with the plot's reference line when the hypothesized distribution is reasonable.
:::

## 2.4 Box Plots, Fences, and Outliers

:::callout-intuition[A box plot is a compressed map of the ordered sample]
A histogram communicates the shape through many intervals, but its appearance changes with the chosen bins. A box plot summarizes the positions of the middle half using a rectangle and extends whiskers toward non-outlying extremes. It reveals whether the median lies off center in the box, which side of the distribution is longer, and whether any observations lie beyond the agreed outlier fences. Recognition cue: *draw a box-and-whisker plot*, *identify outliers*, *calculate whisker length*, or *interpret the central fifty percent* always means sort the data, compute the instructor's quartiles, then apply the $1.5\,IQR$ rule.
:::

### The five-number summary is not yet an outlier rule

:::definition[Definition 2.10 — Five-number summary]
The five-number summary is the minimum, $Q_1$, median $Q_2$, $Q_3$, and maximum, reported in that order. The first and last values are the **actual observed minimum and maximum**, while $Q_1$, $Q_2$ and $Q_3$ may be interpolated values. A five-number summary itself does not decide which values are outliers.
:::

The center line inside the box is the median, not the mean. The left boundary of a horizontal box marks $Q_1$, its right boundary marks $Q_3$, and the length of that box is the IQR. The median can be off center. The whiskers are different from the quartile boundaries: they reach out from the box to the extreme *observed non-outlying* values. In these exercises the instructor's slides explicitly classify points beyond the whiskers as outliers. To decide where those whiskers stop, we must calculate the fences first.

:::definition[Definition 2.11 — Fences and modified box-plot whiskers]
The **lower fence** is $L=Q_1-1.5(IQR)$ and the **upper fence** is $U=Q_3+1.5(IQR)$. The $1.5\,IQR$ multiplier is printed as the *Whisker Length* rule on the **Exam 1 Equations** sheet, but the Final sheet prints only the IQR, not the fence formulas. Think of extending the middle-half box by one and a half box-widths on each end.

An **outlier** is an observed value strictly below $L$ or strictly above $U$. Whiskers stop at the smallest and largest *observed non-outliers*. Plot observations beyond those whiskers as separate points. A value exactly on a fence is not beyond it and remains a non-outlier.
:::

The fence is a **threshold**, often a number that does not appear in the dataset. The whisker end is a **data value**. For example, suppose the upper fence is 316.125 pounds and the largest observed non-outlier is 259 pounds. The upper whisker stops at 259, not 316.125; a 319-pound point appears separately. This distinction matters even when a diagram on a slide appears schematic. Computing the fences determines membership; reading observed values determines whisker endpoints.

### Constructing and interpreting the entire box plot

Follow the same sequence for every box-plot problem: sort, compute the three quartiles, find IQR, calculate both fences, scan all observations, determine non-outlier whisker endpoints, and draw the box with a median line. Label the units and include the separate outlier dots. The sample minimum and maximum in the five-number summary are still the original extremes, even if one or both are plotted as outliers. If a problem asks you to **remove outliers and recompute statistics**, explicitly say you are forming a **new retained sample** after the initial classification. Do not secretly change the sample and pretend the first set of statistics described it.

A right whisker longer than the left, or a median closer to the lower quartile, can suggest a right tail. But quartile spacing alone is a rough signal, not a proof that the underlying population is right-skewed. A box plot does not display every gap or secondary peak; the histogram can complement it. Be especially careful with the difference between the mean and the median: the mean is not drawn as part of the standard box plot unless the chart explicitly adds a separate mean marker.

:::callout-pitfall[The whisker is not 1.5 times the box width on the paper]
The number $1.5(IQR)$ is used to **set the cutoff**, not to place the whisker at an invented observation. Report an outlier only if its recorded value is outside a fence. Retain a value exactly on the fence. Do not use quartiles from the median-of-halves rule, because changing $Q_1$ and $Q_3$ can change outlier classification. Finally, when an exercise tells you to remove outliers, recompute $n$, $\bar{x}$, and $s$ from the remaining raw observations rather than adjusting the old mean with a guess.
:::

:::example[Example 2.12 — Homework 1: steel-price box plot and outliers]
Using the eight quarterly average US steel prices, draw a box plot by hand with all parts labeled; identify all outlier data values and write two or three sentences explaining the distribution.

**Data:** 684, 697, 802, 896, 839, 861, 983, 1089.

::::answer[Answer]
**Answer:** minimum 684; lower quartile 723.25; median 850; upper quartile 961.25; maximum 1089; IQR 238; lower fence 366.25; upper fence 1318.25; lower whisker 684; upper whisker 1089; outlier count 0.

1. Sort the observations: $684,697,802,839,861,896,983,1089$ dollars per metric ton. The instructor's position rule gives $Q_1=723.25$, $Q_2=850$ and $Q_3=961.25$. The five-number summary is **684, 723.25, 850, 961.25, 1089**.

2. Compute $IQR=961.25-723.25=238$. Extend the central box by $1.5(238)=357$ on either side. The lower fence is $723.25-357=366.25$ and the upper fence is $961.25+357=1318.25$ dollars per metric ton.

3. Check the actual observed prices. The minimum 684 exceeds the lower fence; the maximum 1089 is below the upper fence. Thus **none** of the eight values is a 1.5-IQR outlier. The left whisker reaches 684, and the right whisker reaches 1089; draw the box from 723.25 to 961.25 with a median marker at 850.

4. In words: observed quarterly prices ranged from 684 to 1089 dollars per metric ton. The middle half spans 238 dollars per metric ton and the median is 850. The mean, 856.375, is only slightly above the median, so these eight points do not provide strong evidence of pronounced skew.

5. Other quartile conventions may produce different values. For this course, always locate the $(n+1)/4$ positions and interpolate before deciding which values cross either fence.

Check: Both whiskers end at actual observed prices, and every observation lies within the 366.25 to 1318.25 fences.
::::
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Steel price modified box plot with quartiles 723.25, 850, and 961.25, and no outlier points">
<line class="fig-axis" x1="56.00" y1="207.00" x2="654.00" y2="207.00"/>
<text class="fig-label" x="305.00" y="242.00">Measured value</text>
<line class="fig-curve" x1="92.23" y1="91.00" x2="143.26" y2="91.00"/>
<line class="fig-curve" x1="452.68" y1="91.00" x2="618.77" y2="91.00"/>
<rect class="fig-fill" x="143.26" y="72.00" width="309.43" height="38.00"/>
<line class="fig-curve-alt" x1="308.05" y1="72.00" x2="308.05" y2="110.00"/>
<line class="fig-curve" x1="92.23" y1="79.00" x2="92.23" y2="103.00"/>
<line class="fig-curve" x1="618.77" y1="79.00" x2="618.77" y2="103.00"/>
<text class="fig-label" x="10.00" y="65.00">Steel</text>
<text class="fig-label" x="80.23" y="125.00">684</text>
<text class="fig-label" x="131.26" y="137.00">723.25</text>
<text class="fig-label" x="296.05" y="125.00">850</text>
<text class="fig-label" x="440.68" y="137.00">961.25</text>
<text class="fig-label" x="606.77" y="125.00">1089</text>
<line class="fig-axis" x1="58.00" y1="204.00" x2="58.00" y2="211.00"/>
<text class="fig-label" x="48.00" y="226.00">657.675</text>
<line class="fig-axis" x1="177.00" y1="204.00" x2="177.00" y2="211.00"/>
<text class="fig-label" x="167.00" y="226.00">749.205</text>
<line class="fig-axis" x1="296.00" y1="204.00" x2="296.00" y2="211.00"/>
<text class="fig-label" x="286.00" y="226.00">840.735</text>
<line class="fig-axis" x1="415.00" y1="204.00" x2="415.00" y2="211.00"/>
<text class="fig-label" x="405.00" y="226.00">932.265</text>
<line class="fig-axis" x1="534.00" y1="204.00" x2="534.00" y2="211.00"/>
<text class="fig-label" x="524.00" y="226.00">1023.795</text>
<line class="fig-axis" x1="653.00" y1="204.00" x2="653.00" y2="211.00"/>
<text class="fig-label" x="643.00" y="226.00">1115.325</text>
</svg>
<figcaption>With the instructor’s interpolated quartiles, all eight steel prices lie inside the fences; whiskers reach the observed minimum 684 and maximum 1089.</figcaption>
</figure>

:::example[Example 2.13 — Unit 2 Exercise 2: football-weight box plot]
The 20 MSU football-player weights from the lecture exercise are shown below. Complete the requested box plot, showing the quartiles, IQR, fences, whiskers and every outlier. The same exercise asks for a stem-and-leaf and histogram, both constructed in Section 2.3.

**Data:** 189, 209, 233, 249, 196, 216, 239, 252, 196, 221, 239, 258, 200, 227, 243, 259, 201, 232, 246, 319.

**Bin edges:** 180, 200, 220, 240, 260, 280, 300, 320.

::::answer[Answer]
**Answer:** lower quartile 203; median 232.5; upper quartile 248.25; IQR 45.25; lower fence 135.125; upper fence 316.125; outlier count 1; outlier 319; bin count 3; bin count 4; bin count 6; bin count 6; bin count 0; bin count 0; bin count 1.

1. Sort the twenty weights: $189,196,196,200,201,209,216,221,227,232,233,239,239,243,246,249,252,258,259,319$. The three positions are $21/4=5.25$, $21/2=10.5$, and $3(21)/4=15.75$.

2. Interpolate: $Q_1=201+0.25(209-201)=203$ pounds; median $=(232+233)/2=232.5$ pounds; and $Q_3=246+0.75(249-246)=248.25$ pounds. The IQR is $248.25-203=45.25$ pounds.

3. The fence extension is $1.5(45.25)=67.875$ pounds. The lower fence is $203-67.875=135.125$ pounds and the upper fence is $248.25+67.875=316.125$ pounds.

4. The observation 319 is **beyond** the upper fence and is an outlier. All other measurements lie between the fences. Therefore draw the box from 203 to 248.25 with median at 232.5; draw the left whisker to 189 and the right whisker to **259**. Plot 319 as a separate point beyond the right whisker.

5. This is a good example of why a histogram and a box plot answer different questions. The histogram has an isolated final bar at $[300,320)$; the box plot supplies a precise fence-based criterion identifying the player weight 319 as unusually high relative to the other nineteen values.

Check: The upper whisker ends at 259, not at 316.125, even though 316.125 is the fence. The 319-pound player is the only outlier by the course rule.
::::
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Modified football weight box plot with one outlier at 319 pounds and the upper whisker at 259">
<line class="fig-axis" x1="56.00" y1="207.00" x2="654.00" y2="207.00"/>
<text class="fig-label" x="305.00" y="242.00">Measured value</text>
<line class="fig-curve" x1="92.23" y1="91.00" x2="148.93" y2="91.00"/>
<line class="fig-curve" x1="332.21" y1="91.00" x2="375.75" y2="91.00"/>
<rect class="fig-fill" x="148.93" y="72.00" width="183.28" height="38.00"/>
<line class="fig-curve-alt" x1="268.42" y1="72.00" x2="268.42" y2="110.00"/>
<line class="fig-curve" x1="92.23" y1="79.00" x2="92.23" y2="103.00"/>
<line class="fig-curve" x1="375.75" y1="79.00" x2="375.75" y2="103.00"/>
<text class="fig-label" x="10.00" y="65.00">Players</text>
<text class="fig-label" x="80.23" y="125.00">189</text>
<text class="fig-label" x="136.93" y="137.00">203</text>
<text class="fig-label" x="256.42" y="125.00">232.5</text>
<text class="fig-label" x="320.21" y="137.00">248.25</text>
<text class="fig-label" x="363.75" y="125.00">259</text>
<circle class="fig-point" cx="618.77" cy="91.00" r="4.5"/>
<line class="fig-axis" x1="58.00" y1="204.00" x2="58.00" y2="211.00"/>
<text class="fig-label" x="48.00" y="226.00">180.55</text>
<line class="fig-axis" x1="177.00" y1="204.00" x2="177.00" y2="211.00"/>
<text class="fig-label" x="167.00" y="226.00">209.93</text>
<line class="fig-axis" x1="296.00" y1="204.00" x2="296.00" y2="211.00"/>
<text class="fig-label" x="286.00" y="226.00">239.31</text>
<line class="fig-axis" x1="415.00" y1="204.00" x2="415.00" y2="211.00"/>
<text class="fig-label" x="405.00" y="226.00">268.69</text>
<line class="fig-axis" x1="534.00" y1="204.00" x2="534.00" y2="211.00"/>
<text class="fig-label" x="524.00" y="226.00">298.07</text>
<line class="fig-axis" x1="653.00" y1="204.00" x2="653.00" y2="211.00"/>
<text class="fig-label" x="643.00" y="226.00">327.45</text>
</svg>
<figcaption>The 319-pound player is beyond the upper fence 316.125, so the right whisker ends at 259 rather than at the fence or the outlier.</figcaption>
</figure>

:::example[Example 2.14 — Homework 2: battery life before and after outlier removal]
For the forty battery lifetimes in minutes in Homework 2, (a) find sample size, sample mean and sample standard deviation; (b) draw a box plot; and (c) use the box plot to remove the outliers and recalculate sample size, sample mean and sample standard deviation.

**Data:** 312, 338, 346, 350, 352, 355, 359, 370, 321, 340, 347, 350, 353, 355, 360, 375, 327, 342, 348, 351, 353, 356, 362, 381, 331, 344, 349, 351, 354, 357, 364, 389, 334, 345, 349, 352, 354, 358, 366, 397.

::::answer[Answer]
**Answer:** sample size 40; mean 352.425; standard deviation 16.289; lower quartile 345.25; median 352; upper quartile 358.75; lower fence 325; upper fence 379; outlier count 5; outlier 312; outlier 321; outlier 381; outlier 389; outlier 397; remaining size 35; remaining mean 351.343; remaining standard deviation 10.209.

1. The original sample has forty measurements. Enter each reading in 1-VAR mode, using $Sx$ for the sample standard deviation and verifying the count first. The raw sample gives $n=40$, $\bar{x}=352.425$ minutes, and $s=16.28887854$ minutes.

2. Sort the values. Positions for $n=40$ are $p_1=41/4=10.25$, median position $p_2=20.5$, and $p_3=123/4=30.75$. Ordered positions 10 and 11 are 345 and 346, so $Q_1=345.25$. Positions 20 and 21 are both 352, so the median is 352. Positions 30 and 31 are 358 and 359, so $Q_3=358.75$.

3. Compute $IQR=358.75-345.25=13.5$ minutes. The fence distance is $1.5(13.5)=20.25$. Thus $L=345.25-20.25=325$ minutes and $U=358.75+20.25=379$ minutes.

4. Values below 325 are 312 and 321. Values above 379 are 381, 389 and 397. These **five observations** are outliers. Whiskers on the original plot end at the smallest retained value, 327, and largest retained value, 375. The box covers 345.25 to 358.75 with median 352.

5. Remove exactly the five outliers and retain the other thirty-five measurements. Re-enter the thirty-five values into 1-VAR mode, checking the new $n$ before reading results. The retained mean is $351.34285714$ minutes and the retained sample standard deviation is $10.20940413$ minutes.

6. Do not claim the original batteries suddenly became more consistent: this second standard deviation describes a deliberately trimmed set. The homework explicitly requests that comparison, so report both the original and retained statistics and name the rule used to delete readings.

Check: The new sample size must be $40-5=35$; the sample mean changes slightly, and the standard deviation falls from about 16.29 to 10.21 minutes only after removing the five flagged observations.
::::
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 700 250" width="700" height="250" role="img" aria-label="Two stacked battery-life box plots for original and outlier-removed samples">
<line class="fig-axis" x1="56.00" y1="207.00" x2="654.00" y2="207.00"/>
<text class="fig-label" x="305.00" y="242.00">Measured value</text>
<line class="fig-curve" x1="185.15" y1="91.00" x2="298.20" y2="91.00"/>
<line class="fig-curve" x1="381.83" y1="91.00" x2="482.49" y2="91.00"/>
<rect class="fig-fill" x="298.20" y="72.00" width="83.63" height="38.00"/>
<line class="fig-curve-alt" x1="340.01" y1="72.00" x2="340.01" y2="110.00"/>
<line class="fig-curve" x1="185.15" y1="79.00" x2="185.15" y2="103.00"/>
<line class="fig-curve" x1="482.49" y1="79.00" x2="482.49" y2="103.00"/>
<text class="fig-label" x="10.00" y="65.00">Original 40</text>
<text class="fig-label" x="173.15" y="125.00">327</text>
<text class="fig-label" x="286.20" y="137.00">345.25</text>
<text class="fig-label" x="328.01" y="125.00">352</text>
<text class="fig-label" x="369.83" y="137.00">358.75</text>
<text class="fig-label" x="470.49" y="125.00">375</text>
<circle class="fig-point" cx="92.23" cy="91.00" r="4.5"/>
<circle class="fig-point" cx="147.98" cy="91.00" r="4.5"/>
<circle class="fig-point" cx="519.66" cy="91.00" r="4.5"/>
<circle class="fig-point" cx="569.22" cy="91.00" r="4.5"/>
<circle class="fig-point" cx="618.77" cy="91.00" r="4.5"/>
<line class="fig-curve" x1="209.92" y1="151.00" x2="302.85" y2="151.00"/>
<line class="fig-curve" x1="370.99" y1="151.00" x2="451.52" y2="151.00"/>
<rect class="fig-fill" x="302.85" y="132.00" width="68.14" height="38.00"/>
<line class="fig-curve-alt" x1="340.01" y1="132.00" x2="340.01" y2="170.00"/>
<line class="fig-curve" x1="209.92" y1="139.00" x2="209.92" y2="163.00"/>
<line class="fig-curve" x1="451.52" y1="139.00" x2="451.52" y2="163.00"/>
<text class="fig-label" x="10.00" y="125.00">Retained 35</text>
<text class="fig-label" x="197.92" y="185.00">331</text>
<text class="fig-label" x="290.85" y="197.00">346</text>
<text class="fig-label" x="328.01" y="185.00">352</text>
<text class="fig-label" x="358.99" y="197.00">357</text>
<text class="fig-label" x="439.52" y="185.00">370</text>
<circle class="fig-point" cx="185.15" cy="151.00" r="4.5"/>
<circle class="fig-point" cx="482.49" cy="151.00" r="4.5"/>
<line class="fig-axis" x1="58.00" y1="204.00" x2="58.00" y2="211.00"/>
<text class="fig-label" x="48.00" y="226.00">306.475</text>
<line class="fig-axis" x1="177.00" y1="204.00" x2="177.00" y2="211.00"/>
<text class="fig-label" x="167.00" y="226.00">325.685</text>
<line class="fig-axis" x1="296.00" y1="204.00" x2="296.00" y2="211.00"/>
<text class="fig-label" x="286.00" y="226.00">344.895</text>
<line class="fig-axis" x1="415.00" y1="204.00" x2="415.00" y2="211.00"/>
<text class="fig-label" x="405.00" y="226.00">364.105</text>
<line class="fig-axis" x1="534.00" y1="204.00" x2="534.00" y2="211.00"/>
<text class="fig-label" x="524.00" y="226.00">383.315</text>
<line class="fig-axis" x1="653.00" y1="204.00" x2="653.00" y2="211.00"/>
<text class="fig-label" x="643.00" y="226.00">402.525</text>
</svg>
<figcaption>The original battery plot flags five readings outside 325–379 minutes. Replotting the thirty-five retained batteries creates two new flags, 327 and 375, but the requested one-pass statistics retain both.</figcaption>
</figure>

:::example[Example 2.15 — A box plot with no outliers and asymmetric whiskers]
An engineering sample of eight readings has the values shown below. Calculate its five-number summary, IQR, fence locations, whisker endpoints and any outliers.

**Data:** 80, 82, 85, 85, 90, 93, 94, 97.

::::answer[Answer]
**Answer:** minimum 80; lower quartile 82.75; median 87.5; upper quartile 93.75; maximum 97; IQR 11; lower fence 66.25; upper fence 110.25; lower whisker 80; upper whisker 97; outlier count 0.

1. Sort the measurements: $80,82,85,85,90,93,94,97$. The first and last observed readings supply minimum 80 and maximum 97. The median comes from positions four and five.

2. For eight values the first position is 2.25 and the upper position is 6.75. Therefore $Q_1=82+0.25(85-82)=82.75$ and $Q_3=93+0.75(94-93)=93.75$. The median is $(85+90)/2=87.5$.

3. The IQR is $93.75-82.75=11$. Extend the box by $1.5(11)=16.5$ in both directions, giving lower fence 66.25 and upper fence 110.25. Every observed measurement is inside these fences.

4. The whiskers reach the actual minimum 80 and maximum 97, and no separate outlier mark is needed. The left and right halves need not have equal length even if there are no outliers; a box plot summarizes positions, not a claim of perfect symmetry.

Check: The middle half extends from 82.75 to 93.75, and the five-number summary is ordered from minimum to maximum.
::::
:::

:::problem[Problem 2.22 — Recognize an outlier and give whiskers]{difficulty=standard}
Find the full modified box-plot summary for the seven test measurements below. Give both fences, the whisker endpoints, and any flagged observations.

**Data:** 10, 12, 12, 14, 17, 19, 35.

::::solution[Solution]
**Answer:** minimum 10; lower quartile 12; median 14; upper quartile 19; maximum 35; IQR 7; lower fence 1.5; upper fence 29.5; lower whisker 10; upper whisker 19; outlier count 1; outlier 35.

1. Put the measurements in ascending order: 10, 12, 12, 14, 17, 19, 35. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2$, $p_2=4$, and $p_3=6$. Interpolate fractional positions: $Q_1=12$, median $=14$, $Q_3=19$.

3. $IQR=Q_3-Q_1=19-12=7$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=1.5$ and $Q_3+1.5IQR=29.5$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 10 and 19. Outliers: 35. These whisker endpoints must be observed data values.

6. A very large last reading might qualify as an outlier, but only the computed upper fence makes that decision valid.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.23 — No outliers does not mean no variability]{difficulty=easy}
Construct the modified box-plot numerical summary for the eight component widths below. Identify all outliers, if any.

**Data:** 80, 82, 85, 85, 90, 93, 94, 97.

::::solution[Solution]
**Answer:** minimum 80; lower quartile 82.75; median 87.5; upper quartile 93.75; maximum 97; IQR 11; lower fence 66.25; upper fence 110.25; lower whisker 80; upper whisker 97; outlier count 0.

1. Put the measurements in ascending order: 80, 82, 85, 85, 90, 93, 94, 97. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$. Interpolate fractional positions: $Q_1=82.75$, median $=87.5$, $Q_3=93.75$.

3. $IQR=Q_3-Q_1=93.75-82.75=11$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=66.25$ and $Q_3+1.5IQR=110.25$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 80 and 97. Outliers: none. These whisker endpoints must be observed data values.

6. An empty outlier list does not mean the observations are equal; the IQR and whisker span show how much they differ.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.24 — High-end observation and outlier count]{difficulty=standard}
A process produces eight repair times. Use the instructor's $1.5\,IQR$ fences to determine how many observations are flagged as outliers.

**Data:** 20, 22, 23, 24, 25, 26, 28, 60.

::::solution[Solution]
**Answer:** outlier count 1.

1. Sort the sample of 8 observations and locate quartiles at the instructor’s $(8+1)/4$ and $3(8+1)/4$ positions. The values are $Q_1=22.25$ and $Q_3=27.5$.

2. The IQR is $5.25$. Extend $1.5$ IQR below the lower quartile and above the upper quartile to obtain the fences $14.375$ and $35.375$.

3. Test each measured value against those two strict boundaries. The number beyond a fence is 1; a point exactly on a fence stays inside. An extreme numerical value is not automatically an outlier under this rule.

4. Your answer is a count of flagged observations, not the numerical value of the largest repair time.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.25 — Box-plot summary for ten observations]{difficulty=challenge}
Draw a box plot for these ten readings, marking the five-number summary, both fences, whisker endpoints and outliers.

**Data:** 20, 21, 22, 26, 27, 28, 29, 31, 36, 55.

::::solution[Solution]
**Answer:** minimum 20; lower quartile 21.75; median 27.5; upper quartile 32.25; maximum 55; IQR 10.5; lower fence 6; upper fence 48; lower whisker 20; upper whisker 36; outlier count 1; outlier 55.

1. Put the measurements in ascending order: 20, 21, 22, 26, 27, 28, 29, 31, 36, 55. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.75$, $p_2=5.5$, and $p_3=8.25$. Interpolate fractional positions: $Q_1=21.75$, median $=27.5$, $Q_3=32.25$.

3. $IQR=Q_3-Q_1=32.25-21.75=10.5$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=6$ and $Q_3+1.5IQR=48$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 20 and 36. Outliers: 55. These whisker endpoints must be observed data values.

6. With ten values the quartile positions are 2.75 and 8.25; midpoint-of-halves quartiles can shift the fences.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.26 — Whiskers with a repeated central reading]{difficulty=challenge}
Find the box-plot numerical summary of the following eight production rates. State whether the repeated values change the number of observations.

**Data:** 30, 31, 32, 32, 32, 34, 35, 36.

::::solution[Solution]
**Answer:** minimum 30; lower quartile 31.25; median 32; upper quartile 34.75; maximum 36; IQR 3.5; lower fence 26; upper fence 40; lower whisker 30; upper whisker 36; outlier count 0.

1. Put the measurements in ascending order: 30, 31, 32, 32, 32, 34, 35, 36. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$. Interpolate fractional positions: $Q_1=31.25$, median $=32$, $Q_3=34.75$.

3. $IQR=Q_3-Q_1=34.75-31.25=3.5$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=26$ and $Q_3+1.5IQR=40$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 30 and 36. Outliers: none. These whisker endpoints must be observed data values.

6. Every repeated reading is still a separate observation. This affects n and the quartile positions even when the numerical values tie.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.27 — Look for low- and high-end outliers]{difficulty=standard}
A sensor reports these nine measurements. Determine the complete modified box-plot summary using the course fence rule.

**Data:** 1, 3, 4, 5, 5, 6, 7, 8, 9.

::::solution[Solution]
**Answer:** minimum 1; lower quartile 3.5; median 5; upper quartile 7.5; maximum 9; IQR 4; lower fence -2.5; upper fence 13.5; lower whisker 1; upper whisker 9; outlier count 0.

1. Put the measurements in ascending order: 1, 3, 4, 5, 5, 6, 7, 8, 9. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.5$, $p_2=5$, and $p_3=7.5$. Interpolate fractional positions: $Q_1=3.5$, median $=5$, $Q_3=7.5$.

3. $IQR=Q_3-Q_1=7.5-3.5=4$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=-2.5$ and $Q_3+1.5IQR=13.5$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 1 and 9. Outliers: none. These whisker endpoints must be observed data values.

6. The resulting plot is an interpretation of this sample only; it does not prove that future readings cannot exceed the fences.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

:::problem[Problem 2.28 — Percentiles and the median line]{difficulty=easy}
A materials sample produces eight recorded observations. Determine the quartiles, IQR, fences and actual whisker endpoints, and check for outliers.

**Data:** 15, 16, 17, 18, 19, 21, 22, 24.

::::solution[Solution]
**Answer:** minimum 15; lower quartile 16.25; median 18.5; upper quartile 21.75; maximum 24; IQR 5.5; lower fence 8; upper fence 30; lower whisker 15; upper whisker 24; outlier count 0.

1. Put the measurements in ascending order: 15, 16, 17, 18, 19, 21, 22, 24. Do not use the raw order for locating quartiles.

2. Instructor positions are $p_1=2.25$, $p_2=4.5$, and $p_3=6.75$. Interpolate fractional positions: $Q_1=16.25$, median $=18.5$, $Q_3=21.75$.

3. $IQR=Q_3-Q_1=21.75-16.25=5.5$. This is the middle-half width, not the full range.

4. The fences are $Q_1-1.5IQR=8$ and $Q_3+1.5IQR=30$. Observations beyond these limits are outliers; the whiskers stop at observed non-outliers.

5. Draw whiskers to 15 and 24. Outliers: none. These whisker endpoints must be observed data values.

6. The median is drawn inside the box, whereas the mean is not one of the five required summary lines.

Check: $Q_1\le Q_2\le Q_3$ and all box-plot whiskers stop at recorded values, not constructed fence positions.
::::
:::

## Chapter Summary

:::summary[Unit 2 in one pass]
- **Sample size:** $n$ counts observations, including repeated measurements. The calculator's STATVAR count must match your list.
- **Sample mean:** $\bar{x}=(x_1+\cdots+x_n)/n$, Final sheet page 1. It is an arithmetic balance point and moves when an extreme reading changes.
- **Sample variance:** $s^2$ averages squared deviations using **$n-1$** in the denominator, Final sheet page 1. The answer is in squared measurement units.
- **Sample standard deviation:** $s=\sqrt{s^2}$ is in the original units. Read **$Sx$** on the TI-30X IIS, never population $\sigma x$ for a sample.
- **Range:** maximum minus minimum. It is the full observed span, and is more sensitive to extremes than the middle-half width.
- **Median and mode:** the median follows ordered position; the mode follows repetition. They are different questions and may have different values.
- **Quartiles:** sort first; use $p_k=k(n+1)/4$ and interpolate a fractional position. This method is on Exam 1 Equations but **not** on the Final sheet. $Q_2$ is the median.
- **IQR:** $Q_3-Q_1$, Final sheet page 1, measures the middle-half spread.
- **Box plot:** box from $Q_1$ to $Q_3$, median line inside, fences $Q_1-1.5IQR$ and $Q_3+1.5IQR$, whiskers to the furthest *observed non-outliers*, and separate points beyond the fences.
- **Histogram:** count measurements in adjacent, labeled intervals. Frequencies total $n$, or relative frequencies total 1. Read center, shape, spread, skew, gaps and unusual observations from the axes.
- **Other slide displays:** dot plots retain individual observations, stem-and-leaf plots retain digits, time-series plots retain temporal order, and a normal probability plot visually compares ordered values with a normal-distribution reference line.

Numbers give exact arithmetic; histograms show shape and gaps; box plots summarize quartiles and outliers. The three displays should tell compatible stories.
:::

## Mixed Practice

This set follows the final's question types without rehearsing other chapters: true/false, matching and multiple choice. In the actual comprehensive final there is one true/false question with three statements, one matching question with four parts and 21 multiple-choice questions across all nine units. Here, every question stays within Unit 2. The numerical distractors are values you would obtain by making common mistakes, not random answers.

:::problem[Problem M.1 — True/false: center and spread]{difficulty=easy}
For each statement say true or false. (a) If the sample mean equals the sample median, all observations must be identical. (b) The sample standard deviation is in the same units as the raw measurements. (c) A point must be a 1.5-IQR outlier merely because it is the largest value in the sample.

::::solution[Solution]
**Answer:** False; True; False.

1. Statement (a) is false. A symmetric but spread-out sample, such as 1, 2, 3, has both mean and median 2, and none of its outer values needs to equal the center.

2. Statement (b) is true. Variance uses squared deviations and has squared units; the nonnegative square root returns to the original unit. This is why standard deviation is often easier to interpret.

3. Statement (c) is false. Being the maximum is not sufficient to be an outlier. You must first compute the quartiles and the upper fence and compare the observed maximum against that cutoff.

Check: The complete truth pattern is false, true, false. Each claim refers to a different definition rather than a memorized example.
::::
:::

:::problem[Problem M.2 — Matching: four descriptions]{difficulty=easy}
Match each description to its statistic. (a) The observation with greatest repetition. (b) The span from the largest observation to the smallest. (c) The cut point dividing the sorted list into lower and upper halves. (d) The average squared deviation with divisor $n-1$. Options: A = sample variance; B = range; C = mode; D = median.

::::solution[Solution]
**Answer:** C; B; D; A.

1. For (a), count how many times each value occurs. Greatest repetition defines the **mode**, so (a) matches C. It is not a calculation of the mean.

2. For (b), the difference between the two observed endpoints defines the **range**, so (b) matches B. Do not confuse the full span with IQR, which uses quartiles.

3. For (c), the positional middle of sorted observations is the **median**, so (c) matches D. For (d), squaring deviations and dividing by $n-1$ gives **sample variance**, so (d) matches A.

Check: The assignments are (a) C, (b) B, (c) D, and (d) A; each option is used exactly once.
::::
:::

:::problem[Problem M.3 — MC: mean from inspection data]{difficulty=easy}
Five hourly defect counts were recorded. What is the sample mean? (A) 5.0 (B) 5.6 (C) 6.0 (D) 7.0.

**Data:** 3, 4, 5, 7, 9.

::::solution[Solution]
**Answer:** (B) mean 5.6.

1. Read “sample mean” and choose the average formula from Final sheet page 1. There are five observations, and their total is $3+4+5+7+9=28$.

2. Divide by five: $\bar{x}=28/5=5.6$. It is fine that 5.6 was never itself recorded. The mean represents the average number of defects per hour among the five observed hours.

3. Option B is correct. Option A uses the middle observed value instead of the average; C and D are neither the total divided by five nor the median. On the TI-30X IIS, $Sx$ is irrelevant because no standard deviation was requested.

Check: $5(5.6)=28$, the original total.
::::
:::

:::problem[Problem M.4 — MC: sample or population standard deviation?]{difficulty=easy}
An inspector enters measurements into the TI-30X IIS 1-VAR menu. Which displayed variable directly gives the **sample standard deviation**? (A) $\bar{x}$; (B) $\sigma x$; (C) $Sx$; (D) $\Sigma x$.

::::solution[Solution]
**Answer:** (C).

1. The word “sample” determines which standard-deviation label is needed, not whether the original measurements are spread out. On the TI-30X IIS, **$Sx$** denotes sample standard deviation.

2. Select C. Choice A is the sample mean; B is the population standard deviation and uses a different variance divisor; D is the total sum of recorded values, not a measure of spread.

3. If the question instead asked for sample variance, you would square $Sx$ at full precision. You would still not choose the population standard deviation by mistake.

Check: The calculator variable and the sample formula both use $n-1$ for variance.
::::
:::

:::problem[Problem M.5 — MC: sample range]{difficulty=standard}
A quality-control sample records seven torque readings. What is its range? (A) 7; (B) 12; (C) 15; (D) 22.

**Data:** 10, 11, 13, 15, 17, 19, 22.

::::solution[Solution]
**Answer:** (B) range 12.

1. The request is for the range, so locate actual minimum and maximum. These are 10 and 22, independent of the order in which the technician recorded the seven readings.

2. Subtract minimum from maximum: $r=22-10=12$. No division by seven and no sample-variance denominator are involved.

3. Choose B. A is the number of observations; C could be confused with a typical central value; D is only the maximum. The range describes a full observed span of 12 torque units, not a mean level.

Check: The difference between the endpoints 10 and 22 is 12.
::::
:::

:::problem[Problem M.6 — MC: locate the right quartile with eight values]{difficulty=standard}
Eight sample measurements are listed below. Which value is the lower quartile under the instructor's rule? (A) 122.50; (B) 125.50; (C) 126.00; (D) 127.00.

**Data:** 120, 125, 127, 130, 133, 134, 138, 142.

::::solution[Solution]
**Answer:** (B) lower quartile 125.5; median 131.5; upper quartile 137; IQR 11.5.

1. Sort the eight values, then compute positions using the instructor's $k(n+1)/4$ rule. The lower-quartile position is $(8+1)/4=2.25$, so it is one quarter of the way from the second value to the third.

2. Those two ordered observations are 125 and 127. Therefore $Q_1=125+0.25(127-125)=125.5$. The median and upper quartile use positions 4.5 and 6.75 and can be obtained by the same method.

3. Select B. Choice D uses the third observation without interpolation; choice C takes the halfway point rather than the quarter point; choice A does not follow the two neighboring ordered values.

Check: The lower quartile must lie between 125 and 127, and 125.5 satisfies the specified position.
::::
:::

:::problem[Problem M.7 — MC: sample variance of six results]{difficulty=standard}
Six component measurements appear below. What is the sample variance, to one decimal? (A) 13.25; (B) 15.90; (C) 3.99; (D) 17.50.

**Data:** 12, 14, 18, 18, 20, 23.

::::solution[Solution]
**Answer:** (B) variance 15.9.

1. Calculate the mean of the six values $12,14,18,18,20,23$. Their sum is 105, so $\bar{x}=17.5$.

2. Square the deviations from 17.5, add them, and divide the sum by $6-1=5$. The result is $s^2=15.9$ in squared measurement units. The TI-30X IIS should show $Sx=\sqrt{15.9}$, which can be squared to confirm.

3. Choose B. A equals the squared-deviation total divided by six, which is the wrong divisor for sample variance. C is the square root of variance, a standard deviation. D repeats the mean rather than reporting spread.

Check: Sample variance must be nonnegative, and squaring the corresponding $Sx$ reproduces 15.9.
::::
:::

:::problem[Problem M.8 — MC: reading a right-skewed histogram]{difficulty=standard}
A histogram has most observations in low-value bins and a thin tail extending toward larger values. Which statement is best? (A) The histogram is left-skewed. (B) It is right-skewed. (C) It must be symmetric. (D) It must have exactly one formal box-plot outlier.

::::solution[Solution]
**Answer:** (B).

1. Name skew by the **direction of the longer tail**, not by the location of the tallest bar. A tail extending toward larger values lies to the right.

2. Select B, right-skewed. Choice A reverses the tail direction, while C contradicts the stated shape. Choice D goes too far: the histogram shape alone does not establish that any individual observation exceeds a $1.5\,IQR$ fence.

3. A right-skewed sample may pull its mean to the right of its median, but this is a tendency, not an identity that follows from the appearance of one histogram alone.

Check: The correct explanation identifies the right-hand tail, not the highest bar.
::::
:::

:::problem[Problem M.9 — MC: identify formal outliers]{difficulty=standard}
A sample contains a high final measurement. Under the course box-plot rule, how many of these observations fall beyond the fences? (A) 0; (B) 1; (C) 2; (D) 3.

**Data:** 9, 10, 11, 12, 13, 15, 26.

::::solution[Solution]
**Answer:** (B) outlier count 1.

1. Sort the seven values $9,10,11,12,13,15,26$. With $n=7$, the quartile positions are 2 and 6, giving $Q_1=10$ and $Q_3=15$.

2. The IQR is $15-10=5$. The lower fence is $10-1.5(5)=2.5$ and the upper fence is $15+1.5(5)=22.5$.

3. The value 26 lies above the upper fence; the other six values lie within the two boundaries. Exactly one observation is an outlier, so choose B. A ignores the high reading, while C and D invent further points that do not exceed a fence.

Check: Only 26 is beyond 22.5, so the observed outlier count is one.
::::
:::

:::problem[Problem M.10 — MC: where does a box-plot whisker stop?]{difficulty=standard}
A sample's upper fence is 26.5. The observed high values are 20, 24, 26 and 35. Where must the upper whisker stop? (A) 26.5; (B) 35; (C) 26; (D) 24.

**Data:** 20, 24, 26, 35.

::::solution[Solution]
**Answer:** (C) upper whisker 26.

1. A fence of 26.5 is an exclusion cutoff, not necessarily a recorded sample measurement. The modified box-plot whisker must stop at the largest **observed value at or below** the upper fence.

2. The value 35 exceeds 26.5 and is plotted separately. The largest remaining observed value is 26, so C is the correct choice.

3. A places the whisker at the mathematical cutoff rather than a data point; B incorrectly includes the outlier; D stops too early and ignores the valid non-outlier 26.

Check: 26 is inside the fence and 35 is outside, so the whisker ends at 26.
::::
:::

:::problem[Problem M.11 — MC: sample standard deviation after a few readings]{difficulty=standard}
A sample of seven recorded dimensions is provided. Which is the sample standard deviation, approximately? (A) 8.29; (B) 4.68; (C) 21.90; (D) 15.00.

**Data:** 3, 6, 7, 7, 8, 9, 18.

::::solution[Solution]
**Answer:** (B) standard deviation 4.68.

1. Enter $3,6,7,7,8,9,18$ in 1-VAR mode and check the displayed sample size of seven. The sample mean is $58/7=8.285714...$.

2. In STATVAR, select **$Sx$**. The sample variance is approximately $21.9047619$, so the sample standard deviation is the nonnegative square root of that number, about 4.68025.

3. Choose B. A is approximately the mean, C is the variance rather than standard deviation, and D is the observed range $18-3$. The correct result is in the original units of the seven dimensions.

Check: Squaring about 4.68 recovers the variance of roughly 21.9.
::::
:::

:::problem[Problem M.12 — MC: interpret the middle half]{difficulty=easy}
A sample's box is drawn from $Q_1=18$ to $Q_3=34$. Which statement is necessarily supported? (A) The full observed range is 16. (B) The mean equals 26. (C) The IQR is 16. (D) No outliers are possible.

**Quartiles:** 18, 34.

::::solution[Solution]
**Answer:** (C) IQR 16.

1. The horizontal distance from the left to the right edge of the box is the interquartile range. Subtract the lower quartile from the upper: $34-18=16$.

2. Select C. Choice A confuses the box width with the full minimum-to-maximum span. Choice B invents a mean, which is not represented by standard box edges. Choice D cannot be established without checking observations against the fences.

3. Remember that the median is a line **inside** the box. The numerical halfway point between quartiles need not equal the sample median, and neither one needs to equal the sample mean.

Check: The sole guaranteed number from the two given quartiles is their difference, 16.
::::
:::

:::problem[Problem M.13 — MC: interpret relative frequency]{difficulty=standard}
A sample of ten steel observations contains four measurements in the $[800,900)$ bin. What is the relative frequency of that bin? (A) 0.04; (B) 0.25; (C) 0.40; (D) 4.00.

**Data:** 4, 10.

::::solution[Solution]
**Answer:** (C) relative frequency 0.4.

1. Relative frequency means the proportion of observed values in one bin. There are four matching values out of ten, so divide the count by the sample size: $4/10=0.40$.

2. Choose C. A divides by one hundred instead of ten. B uses an unrelated fraction, and D leaves the answer as a raw count or an impossible probability greater than one.

3. The bar would have height 4 on a frequency histogram and 0.40 on a relative-frequency histogram. It represents the same four observations, despite the different vertical scales.

Check: Four out of ten observations constitute 40% of this sample.
::::
:::

:::problem[Problem M.14 — MC: a box plot after removing outliers]{difficulty=easy}
A quality engineer removes five identified outliers from a sample of forty batteries, then recalculates descriptive statistics. Which sample size should be entered as the calculator check? (A) 35; (B) 40; (C) 45; (D) 5.

**Data:** 40, 5.

::::solution[Solution]
**Answer:** (A) retained sample size 35.

1. The problem explicitly says five of the original forty observations have been removed, so the retained dataset contains forty minus five, or thirty-five observations.

2. Select A. Choice B incorrectly keeps the original count, choice C adds the removed values, and choice D reports only the number removed rather than the size of the retained sample.

3. All statistics computed after removing outliers must be recomputed from the thirty-five measurements. Using the old forty-observation $Sx$ with the new $n$ does not produce the sample standard deviation of either dataset.

Check: Thirty-five retained plus five removed accounts for all forty original batteries.
::::
:::

