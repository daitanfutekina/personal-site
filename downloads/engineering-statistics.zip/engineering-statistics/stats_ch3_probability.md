---
title: "Probability"
crumb: "Engineering Statistics · Chapter 3"
meta:
  - "Est. study time: ~360 min"
  - "IE 4613 · Unit 3"
source: "markdown"
---

## Overview

Probability turns descriptions of uncertain manufacturing, inspection, and customer events into precise numbers. The hardest work is often **not** arithmetic. It is deciding what counts as an outcome, which outcomes satisfy the wording, and whether the given information changes the group being considered. A problem saying *either* is not solved the same way as one saying *both*; a problem saying *given* changes the denominator; and a problem saying *which source, given a failure* runs a conditional probability backward.

The final assesses set operations, addition, conditional probability, multiplication, total probability, and Bayes. The Unit 3 notes also use sample-space trees, factorials, arrangements, selections, sampling without replacement, and circuit reliability. Those skills appear in the Exam 1 practice and are included here because they explain where the formulas come from. Work a problem before expanding its solution. Use the TI-30X IIS for arithmetic; each numerical answer is obtained with the formulas and operations on Final Exam Equations, page 1, or with a counting argument built from first principles.

:::callout-key[Reading the wording before choosing a formula]

**"Or"** requests a union. **"And" / "both"** requests an intersection. **"Not" / "neither"** requests a complement. **"Given" / "among" / "of those"** requests a conditional probability. **"At least one"** is often easiest as one minus the probability of none. **"Overall chance"** after several possible sources requests total probability. **"Which source, knowing the outcome"** requests Bayes. **"How many ways"** requests counting, and the question becomes whether order and replacement matter.
:::

## 3.1 Sample Spaces, Events, and Venn Diagrams

Before assigning probabilities, decide what the experiment can produce. A manufactured connector's thickness could be any physically allowed positive measurement. If instead you inspect conformity, the outcome is merely pass or fail. The experiment is the same physical operation, but its recorded sample space changes with the question. The slides begin with a telephone company: calls arrive on average every five minutes and last five minutes. Those averages alone cannot guarantee that a fixed number of lines will never block a call, because call starts can overlap. Uncertain outcomes are why we study probabilities rather than only averages.

Set notation turns words into regions. An event is a group of outcomes, and a union collects every outcome in either group. Statistical **or** includes the overlap, even though ordinary conversation sometimes treats "or" as exclusive. An intersection keeps only outcomes satisfying both descriptions. A complement excludes one event but keeps every other outcome in the original sample space. The rectangle in a Venn diagram represents **all** possible outcomes; circles mark the subsets. When two shifts of a factory are used for one individual product, those shift events cannot overlap. But a defective-product circle can intersect each shift circle.

Manufacturing tables provide more than pictures. An entry at row Attention High and column Satisfaction High is a joint count. Summing the entire high-attention row produces a marginal count. If the question asks how many customers belong to either category, count the union without counting the intersection twice. If it asks a probability, divide that count by the size of the sample space. Do not confuse a raw table count with a probability.

:::callout-intuition[Where the event comes from]

An event is a yes-or-no statement about the actual outcome. The space for two consecutively inspected parts is $S=\{yy,yn,ny,nn\}$, where $y$ means conforming and $n$ means nonconforming. The event "at least one conforms" is $\{yy,yn,ny\}$, while "neither conforms" is $\{nn\}$. Both together cover the space, but they do not overlap.
:::

:::definition[Random experiment and sample space]

A **random experiment** may produce different results even under the same procedure. Its **sample space**, denoted $S$, contains every possible outcome. An **event** is any subset of $S$, including the impossible event $\varnothing$ and certain event $S$.
:::

:::definition[Basic set operations]

Union $A\cup B$ means in **either** event, including both. Intersection $A\cap B$ means in **both**. Complement $A'$ means every outcome outside $A$ but still within $S$. Difference $A\cap B'$ means in $A$ and not in $B$.
:::

:::definition[Mutually exclusive and exhaustive]

Two events are **mutually exclusive** if their intersection is empty. A family of events is **exhaustive** if their union is the entire sample space. Mutually exclusive does not automatically mean exhaustive. First-shift and second-shift products are mutually exclusive for one sampled product, but they need not be exhaustive if there is a third shift.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 560 230" role="img" aria-label="Two partly overlapping event circles inside the rectangle S">
<rect class="fig-axis" x="15" y="10" width="532" height="209"/><path class="fig-curve" d="M321.00,111.00 L320.78,116.17 L320.12,121.31 L319.02,126.41 L317.49,131.45 L315.53,136.39 L313.16,141.23 L310.38,145.94 L307.20,150.50 L303.64,154.89 L299.72,159.09 L295.44,163.09 L290.83,166.86 L285.91,170.40 L280.70,173.67 L275.22,176.69 L269.50,179.42 L263.56,181.85 L257.42,183.99 L251.11,185.81 L244.66,187.31 L238.09,188.48 L231.44,189.32 L224.74,189.83 L218.00,190.00 L211.26,189.83 L204.56,189.32 L197.91,188.48 L191.34,187.31 L184.89,185.81 L178.58,183.99 L172.44,181.85 L166.50,179.42 L160.78,176.69 L155.30,173.67 L150.09,170.40 L145.17,166.86 L140.56,163.09 L136.28,159.09 L132.36,154.89 L128.80,150.50 L125.62,145.94 L122.84,141.23 L120.47,136.39 L118.51,131.45 L116.98,126.41 L115.88,121.31 L115.22,116.17 L115.00,111.00 L115.22,105.83 L115.88,100.69 L116.98,95.59 L118.51,90.55 L120.47,85.61 L122.84,80.77 L125.62,76.06 L128.80,71.50 L132.36,67.11 L136.28,62.91 L140.56,58.91 L145.17,55.14 L150.09,51.60 L155.30,48.33 L160.78,45.31 L166.50,42.58 L172.44,40.15 L178.58,38.01 L184.89,36.19 L191.34,34.69 L197.91,33.52 L204.56,32.68 L211.26,32.17 L218.00,32.00 L224.74,32.17 L231.44,32.68 L238.09,33.52 L244.66,34.69 L251.11,36.19 L257.42,38.01 L263.56,40.15 L269.50,42.58 L275.22,45.31 L280.70,48.33 L285.91,51.60 L290.83,55.14 L295.44,58.91 L299.72,62.91 L303.64,67.11 L307.20,71.50 L310.38,76.06 L313.16,80.77 L315.53,85.61 L317.49,90.55 L319.02,95.59 L320.12,100.69 L320.78,105.83 L321.00,111.00 Z"/><path class="fig-curve" d="M447.00,111.00 L446.78,116.17 L446.12,121.31 L445.02,126.41 L443.49,131.45 L441.53,136.39 L439.16,141.23 L436.38,145.94 L433.20,150.50 L429.64,154.89 L425.72,159.09 L421.44,163.09 L416.83,166.86 L411.91,170.40 L406.70,173.67 L401.22,176.69 L395.50,179.42 L389.56,181.85 L383.42,183.99 L377.11,185.81 L370.66,187.31 L364.09,188.48 L357.44,189.32 L350.74,189.83 L344.00,190.00 L337.26,189.83 L330.56,189.32 L323.91,188.48 L317.34,187.31 L310.89,185.81 L304.58,183.99 L298.44,181.85 L292.50,179.42 L286.78,176.69 L281.30,173.67 L276.09,170.40 L271.17,166.86 L266.56,163.09 L262.28,159.09 L258.36,154.89 L254.80,150.50 L251.62,145.94 L248.84,141.23 L246.47,136.39 L244.51,131.45 L242.98,126.41 L241.88,121.31 L241.22,116.17 L241.00,111.00 L241.22,105.83 L241.88,100.69 L242.98,95.59 L244.51,90.55 L246.47,85.61 L248.84,80.77 L251.62,76.06 L254.80,71.50 L258.36,67.11 L262.28,62.91 L266.56,58.91 L271.17,55.14 L276.09,51.60 L281.30,48.33 L286.78,45.31 L292.50,42.58 L298.44,40.15 L304.58,38.01 L310.89,36.19 L317.34,34.69 L323.91,33.52 L330.56,32.68 L337.26,32.17 L344.00,32.00 L350.74,32.17 L357.44,32.68 L364.09,33.52 L370.66,34.69 L377.11,36.19 L383.42,38.01 L389.56,40.15 L395.50,42.58 L401.22,45.31 L406.70,48.33 L411.91,51.60 L416.83,55.14 L421.44,58.91 L425.72,62.91 L429.64,67.11 L433.20,71.50 L436.38,76.06 L439.16,80.77 L441.53,85.61 L443.49,90.55 L445.02,95.59 L446.12,100.69 L446.78,105.83 L447.00,111.00 Z"/><text class="fig-label" x="168" y="115">A only</text><text class="fig-label-em" x="275" y="115">A ∩ B</text><text class="fig-label" x="393" y="115">B only</text><text class="fig-label" x="25" y="30">S</text>
</svg>
<figcaption>The two circles overlap, so a union includes the two exclusive regions and their shared middle lens, while an intersection includes only the lens.</figcaption>
</figure>

:::example[Example 3.1 — Plastic-connector sample spaces]
A molded plastic connector's thickness is measured. Describe a reasonable sample space if only positive thicknesses are possible, if all connectors are between 10 and 11 mm, if readings are classified as low/medium/high, and if only conformity matters.

::::answer[Answer]
**Answer:** $(0,\infty)$, $[10,11]$, $\{L,M,H\}$, and $\{y,n\}$.

1. For unrestricted positive thickness, the outcome is a positive real number: $S=(0,\infty)$. Physical assumptions determine whether zero is included; thickness itself must be positive.
2. For a guaranteed 10–11 mm range, record $S=[10,11]$. If measurements are sorted into three classes, $S=\{L,M,H\}$.
3. If only inspection success matters, $S=\{y,n\}$. The categories describe the same kind of part with different levels of measurement detail.

For two measured parts, the sample space is the positive quadrant of the plane; for two pass/fail outcomes it is the four ordered pairs.

Check: $(0,\infty)$, $[10,11]$, $\{L,M,H\}$, and $\{y,n\}$
::::
:::

:::example[Example 3.2 — Slide two-part event example]
Two manufactured parts are inspected in order: $S=\{yy,yn,ny,nn\}$. Write the event at least one part conforms and the complement of that event.

::::answer[Answer]
**Answer:** $E=\{yy,yn,ny\}$ and $E'=\{nn\}$.

1. Start with the four possible ordered inspection outcomes. Both letters matter because the first and second inspections are distinct.
2. The word "at least one" retains `yy`, `yn`, and `ny`. It excludes only `nn`, which has no conforming part.
3. The complement contains every outcome left behind, so $E'=\{nn\}$. Together these two disjoint events exhaust the original four outcomes.

Check: $E=\{yy,yn,ny\}$ and $E'=\{nn\}$
::::
:::

:::example[Example 3.3 — Unit 3 Exercise 1: satisfaction or attention]
A survey of 50 customers cross-classifies Attention rows High/Low against Satisfaction columns High/Low.

| Attention / Satisfaction | High | Low |
|---|---:|---:|
| High | 23 | 9 |
| Low | 6 | 12 |

Let $A$ denote high satisfaction and $B$ high attention. How many are in $A\cup B$?

::::answer[Answer]
**Answer:** 38.

1. High satisfaction is the High column: 23 from Attention High and 6 from Attention Low. High attention is the High row: 23 and 9.
2. The row and column overlap in the same cell 23. Select it only once, so the union consists of cells 23, 9, and 6.
3. Add $23+9+6=38$. As a check, subtract the only excluded cell, Low attention / Low satisfaction, from the total: $50-12=38$.

Check: Thirty-eight customers had high satisfaction, high attention, or both.
::::
:::

:::example[Example 3.4 — Unit 3 Exercise 1: high on both scales]
The customer table has row Attention High and column Satisfaction High intersecting in the count 23. Find the number in $A\cap B$.

::::answer[Answer]
**Answer:** 23.

1. The intersection symbol means both conditions are required for the same customer.
2. Look up the row Attention = High and the column Satisfaction = High. That one cell contains 23 observations.
3. The result is a count, not $23/50$, because the question asks for the number in the event rather than the probability.

Check: Twenty-three customers reported both high satisfaction and high personal attention.
::::
:::

:::example[Example 3.5 — Unit 3 Exercise 1: not high satisfaction]
The customer table's Low satisfaction column has 9 high-attention and 12 low-attention customers. Find the number in $A'$, where $A$ means high satisfaction.

::::answer[Answer]
**Answer:** 21.

1. Complement $A'$ means satisfaction is Low, regardless of the Attention category.
2. Read the Satisfaction = Low column: row Attention High contains 9; row Attention Low contains 12.
3. Add $9+12=21$. This agrees with $50-(23+6)=21$, subtracting the high-satisfaction column from all customers.

Check: Twenty-one surveyed customers are outside the high-satisfaction group.
::::
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 560 230" role="img" aria-label="Three overlapping events inside the sample space">
<rect class="fig-axis" x="13" y="10" width="535" height="209"/><path class="fig-curve" d="M323.00,83.00 L322.81,87.05 L322.26,91.09 L321.33,95.10 L320.04,99.05 L318.38,102.93 L316.38,106.73 L314.03,110.42 L311.34,114.00 L308.34,117.45 L305.02,120.74 L301.41,123.88 L297.52,126.84 L293.36,129.61 L288.96,132.19 L284.33,134.55 L279.50,136.69 L274.48,138.61 L269.29,140.28 L263.97,141.71 L258.52,142.89 L252.97,143.81 L247.36,144.47 L241.69,144.87 L236.00,145.00 L230.31,144.87 L224.64,144.47 L219.03,143.81 L213.48,142.89 L208.03,141.71 L202.71,140.28 L197.52,138.61 L192.50,136.69 L187.67,134.55 L183.04,132.19 L178.64,129.61 L174.48,126.84 L170.59,123.88 L166.98,120.74 L163.66,117.45 L160.66,114.00 L157.97,110.42 L155.62,106.73 L153.62,102.93 L151.96,99.05 L150.67,95.10 L149.74,91.09 L149.19,87.05 L149.00,83.00 L149.19,78.95 L149.74,74.91 L150.67,70.90 L151.96,66.95 L153.62,63.07 L155.62,59.27 L157.97,55.58 L160.66,52.00 L163.66,48.55 L166.98,45.26 L170.59,42.12 L174.48,39.16 L178.64,36.39 L183.04,33.81 L187.67,31.45 L192.50,29.31 L197.52,27.39 L202.71,25.72 L208.03,24.29 L213.48,23.11 L219.03,22.19 L224.64,21.53 L230.31,21.13 L236.00,21.00 L241.69,21.13 L247.36,21.53 L252.97,22.19 L258.52,23.11 L263.97,24.29 L269.29,25.72 L274.48,27.39 L279.50,29.31 L284.33,31.45 L288.96,33.81 L293.36,36.39 L297.52,39.16 L301.41,42.12 L305.02,45.26 L308.34,48.55 L311.34,52.00 L314.03,55.58 L316.38,59.27 L318.38,63.07 L320.04,66.95 L321.33,70.90 L322.26,74.91 L322.81,78.95 L323.00,83.00 Z"/><path class="fig-curve" d="M408.00,83.00 L407.81,87.05 L407.26,91.09 L406.33,95.10 L405.04,99.05 L403.38,102.93 L401.38,106.73 L399.03,110.42 L396.34,114.00 L393.34,117.45 L390.02,120.74 L386.41,123.88 L382.52,126.84 L378.36,129.61 L373.96,132.19 L369.33,134.55 L364.50,136.69 L359.48,138.61 L354.29,140.28 L348.97,141.71 L343.52,142.89 L337.97,143.81 L332.36,144.47 L326.69,144.87 L321.00,145.00 L315.31,144.87 L309.64,144.47 L304.03,143.81 L298.48,142.89 L293.03,141.71 L287.71,140.28 L282.52,138.61 L277.50,136.69 L272.67,134.55 L268.04,132.19 L263.64,129.61 L259.48,126.84 L255.59,123.88 L251.98,120.74 L248.66,117.45 L245.66,114.00 L242.97,110.42 L240.62,106.73 L238.62,102.93 L236.96,99.05 L235.67,95.10 L234.74,91.09 L234.19,87.05 L234.00,83.00 L234.19,78.95 L234.74,74.91 L235.67,70.90 L236.96,66.95 L238.62,63.07 L240.62,59.27 L242.97,55.58 L245.66,52.00 L248.66,48.55 L251.98,45.26 L255.59,42.12 L259.48,39.16 L263.64,36.39 L268.04,33.81 L272.67,31.45 L277.50,29.31 L282.52,27.39 L287.71,25.72 L293.03,24.29 L298.48,23.11 L304.03,22.19 L309.64,21.53 L315.31,21.13 L321.00,21.00 L326.69,21.13 L332.36,21.53 L337.97,22.19 L343.52,23.11 L348.97,24.29 L354.29,25.72 L359.48,27.39 L364.50,29.31 L369.33,31.45 L373.96,33.81 L378.36,36.39 L382.52,39.16 L386.41,42.12 L390.02,45.26 L393.34,48.55 L396.34,52.00 L399.03,55.58 L401.38,59.27 L403.38,63.07 L405.04,66.95 L406.33,70.90 L407.26,74.91 L407.81,78.95 L408.00,83.00 Z"/><path class="fig-curve" d="M366.00,144.00 L365.81,148.05 L365.26,152.09 L364.33,156.10 L363.04,160.05 L361.38,163.93 L359.38,167.73 L357.03,171.42 L354.34,175.00 L351.34,178.45 L348.02,181.74 L344.41,184.88 L340.52,187.84 L336.36,190.61 L331.96,193.19 L327.33,195.55 L322.50,197.69 L317.48,199.61 L312.29,201.28 L306.97,202.71 L301.52,203.89 L295.97,204.81 L290.36,205.47 L284.69,205.87 L279.00,206.00 L273.31,205.87 L267.64,205.47 L262.03,204.81 L256.48,203.89 L251.03,202.71 L245.71,201.28 L240.52,199.61 L235.50,197.69 L230.67,195.55 L226.04,193.19 L221.64,190.61 L217.48,187.84 L213.59,184.88 L209.98,181.74 L206.66,178.45 L203.66,175.00 L200.97,171.42 L198.62,167.73 L196.62,163.93 L194.96,160.05 L193.67,156.10 L192.74,152.09 L192.19,148.05 L192.00,144.00 L192.19,139.95 L192.74,135.91 L193.67,131.90 L194.96,127.95 L196.62,124.07 L198.62,120.27 L200.97,116.58 L203.66,113.00 L206.66,109.55 L209.98,106.26 L213.59,103.12 L217.48,100.16 L221.64,97.39 L226.04,94.81 L230.67,92.45 L235.50,90.31 L240.52,88.39 L245.71,86.72 L251.03,85.29 L256.48,84.11 L262.03,83.19 L267.64,82.53 L273.31,82.13 L279.00,82.00 L284.69,82.13 L290.36,82.53 L295.97,83.19 L301.52,84.11 L306.97,85.29 L312.29,86.72 L317.48,88.39 L322.50,90.31 L327.33,92.45 L331.96,94.81 L336.36,97.39 L340.52,100.16 L344.41,103.12 L348.02,106.26 L351.34,109.55 L354.34,113.00 L357.03,116.58 L359.38,120.27 L361.38,124.07 L363.04,127.95 L364.33,131.90 L365.26,135.91 L365.81,139.95 L366.00,144.00 Z"/><text class="fig-label" x="183" y="60">A</text><text class="fig-label" x="383" y="60">B</text><text class="fig-label" x="275" y="208">C</text><text class="fig-label-em" x="263" y="107">all</text>
</svg>
<figcaption>Three-event diagrams have seven potentially nonempty interior regions; a point in the center belongs to every pairwise intersection and the triple intersection.</figcaption>
</figure>

:::problem[Problem 3.1 — Unit 3 Exercise 2: pass inspection]{difficulty=easy}
Let $A$ be first-shift products and $B$ defective products. The sample space is every produced product. Which event describes products that **pass inspection**?

::::solution[Solution]
**Answer:** $B'$.

1. The defective products occupy circle B. The result must include passing products from every production shift.
2. Pass means not defective, so take the complement $B'$, all outcomes of S lying outside circle B.
3. Do not require membership in the first-shift event A because that would exclude passing products made on other shifts.

Check: $B'$
::::
:::

:::problem[Problem 3.2 — Unit 3 Exercise 2: first-shift defective products]{difficulty=easy}
Let $A$ be first-shift products and $B$ defective products. Which event means first shift **and** defective?

::::solution[Solution]
**Answer:** $A\cap B$.

1. The first-shift condition selects A, and the defect condition selects B.
2. AND means both conditions, so write intersection $A\cap B$.
3. Shade only the overlapping region. A product made on first shift but passing inspection is not in the intersection; neither is a defective product made later.

Check: $A\cap B$
::::
:::

:::problem[Problem 3.3 — Unit 3 Exercise 3: nondefective first or second shift]{difficulty=standard}
Add event $C$ for second-shift products, and assume more than two production shifts. Which event contains nondefective products from the first and second shifts?

::::solution[Solution]
**Answer:** $(A\cup C)\cap B'$.

1. First shift A and second shift C are mutually exclusive for a single product, so "from these two shifts" collects $A\cup C$.
2. Nondefective means outside defect event B, or $B'$. Combine the requirements as $(A\cup C)\cap B'$.
3. The region contains passing products from either shift but excludes defective parts and products from later shifts. All defective products, if asked separately, remain event B.

Check: $(A\cup C)\cap B'$
::::
:::

:::example[Example 3.6 — Unit 3 Exercise 4: shading a compound event]
On a three-event Venn diagram, shade $(A\cap B)\cup(C'\cap B)$. What equivalent factored event describes the shaded part of $B$?

::::answer[Answer]
**Answer:** $B\cap(A\cup C')$.

1. The first component $A\cap B$ includes all B outcomes also in A, including those inside the triple overlap.
2. The second component $C'\cap B$ includes all B outcomes outside C, regardless of A.
3. Take their union and factor B: $B\cap(A\cup C')$. The omitted piece of B is the part inside C but outside A.

Check: $B\cap(A\cup C')$
::::
:::

:::problem[Problem 3.4 — Homework 2: Smallville Manufacturing pass count]{difficulty=easy}
Pass/Fail counts by shift are: first shift 497/16, second shift 331/22, third shift 112/22. Let B denote passing inspection. How many products are in B?

::::solution[Solution]
**Answer:** 940.

1. The passing event is the entire Pass column across all three shift rows.
2. Read row Shift 1 / Pass = 497, Shift 2 / Pass = 331, and Shift 3 / Pass = 112.
3. Add $497+331+112=940$. There are 1000 products overall, and the complement count of failures is 60.

Check: Nine hundred forty of the thousand products passed inspection.
::::
:::

:::problem[Problem 3.5 — Homework 2: shift union with passing]{difficulty=standard}
Smallville's three Pass/Fail rows are 497/16, 331/22, and 112/22. Let $A$ be shift 1, $B$ Pass, and $C$ shift 3. Find the number in $A\cup B\cup C$.

::::solution[Solution]
**Answer:** 978.

1. The union includes every Pass cell, regardless of shift: $497+331+112=940$.
2. It also includes Fail cells from selected shift A (16) and shift C (22), but not failures from shift 2.
3. Therefore $940+16+22=978$. Equivalently, from 1000 total products exclude the 22 second-shift failures.

Check: Nine hundred seventy-eight products passed or came from shift one or three.
::::
:::

:::problem[Problem 3.6 — Homework 2: third-shift conforming]{difficulty=standard}
For shift 3, 112 parts Pass and 22 Fail. What is the count in $C\cap B$ if C denotes shift 3 and B denotes passing?

::::solution[Solution]
**Answer:** 112.

1. The intersection C and B means the product came from the third shift and passed.
2. Look at row Shift 3 and column Pass. The crossing count is 112.
3. Do not sum the full third-shift row or the full Pass column, because neither of those enforces both conditions.

Check: One hundred twelve products were both third-shift and passing.
::::
:::

:::problem[Problem 3.7 — Homework 2: conditional-event count]{difficulty=challenge}
Smallville's shifts 1 and 3 have Pass/Fail counts 497/16 and 112/22. The assignment asks for the **number** of products corresponding to $B\mid(A\cup C)$. How many pass in either of those two shifts?

::::solution[Solution]
**Answer:** 609.

1. The assignment requests a number, so restrict to shifts 1 and 3 and count their passing products.
2. From Shift 1 / Pass select 497, and from Shift 3 / Pass select 112. Sum $497+112=609$.
3. A formal conditional probability would instead be $P(B\mid A\cup C)=609/(513+134)=609/647$. A conditional bar by itself is not a standard event-count operation.

Check: There are 609 passing products in shifts one and three, distinct from the probability among those shifts.
::::
:::

:::example[Example 3.7 — Homework 2: hospital surgery outside transfer routes]
Let A be emergency-department admission, B transfer from another hospital, and C surgery. Express surgery after neither emergency-department admission nor transfer.

::::answer[Answer]
**Answer:** $C\cap A'\cap B'$.

1. Start with surgery event C. Any surgery patient is in C, regardless of the admission route.
2. Exclude emergency admissions with $A'$ and transfers with $B'$. Intersect all three restrictions.
3. The result is $C\cap A'\cap B'$. For surgery with no emergency admission alone, the requested event is simply $C\cap A'$.

Check: $C\cap A'\cap B'$
::::
:::

:::example[Example 3.8 — Exam 1 practice: nuclear plant categories]
Of 104 power plants, some are new, some have safety violations, and some have protestor problems. Let N mean new, V a violation, and P protestors. Express new with no violation but with protestors.

::::answer[Answer]
**Answer:** $N\cap V'\cap P$.

1. New selects N. No violation selects the complement $V'$. Protestor problems select P.
2. All requirements occur together, so intersect them: $N\cap V'\cap P$.
3. The sample-space rectangle contains 104 plants, but without counts in the regions, no numeric probability can be inferred. Shade only the appropriate three-circle lens.

Check: $N\cap V'\cap P$
::::
:::

:::callout-pitfall[Venn and table errors that cost easy marks]
Do not shade the entire rectangle when asked for a complement: the excluded event must remain unshaded. Do not conflate first shift and second shift with a product that can belong to both. In tables, use exactly the named row and column for an intersection, and avoid counting that crossing twice in a union. A count question has an integer answer; a probability question divides by the relevant total.
:::

## 3.2 Counting Outcomes: Multiplication, Permutations, and Combinations

The counting questions in the Unit 3 slides are not primarily probability formulas. They ask: how many possible outcomes could the experiment produce? In the vehicle-selection tree, a choice of transmission leads to choices of air-conditioning, then stereo, then color. Each complete path is one distinct vehicle design. You multiply available choices at successive stages. If you draw balls, the number of choices can shrink when the earlier balls are not replaced.

The key distinction is **sequence versus group**. A president and vice president cannot exchange offices and still represent the same result, so the assignment is ordered. Five identical components installed in distinct locations form a group of locations, so choosing the same five locations in a different sequence does not create a new design. The formulas look similar because they solve the same underlying question in two versions. Rather than guess which factorial formula fits, write two sample outcomes and ask whether swapping their order makes a new outcome.

The Final equation sheet, page 1, supplies the combination formula. The multiplication rule for counting and permutations are not printed separately; they follow directly from multiplying the choices left at each step. A factorial, $n!$, abbreviates $n(n-1)\cdots 1$. On a TI-30X IIS, repeated short multiplication is often more reliable than entering a huge factorial. Keep counts as integers.

:::definition[Fundamental counting principle]

If a sequence of choices has $n_1$ possibilities at the first stage, $n_2$ at the second stage for each first choice, and so on, then the number of complete outcomes is $n_1n_2\cdots n_k$. This multiplication principle is not separately printed on the Final sheet; it makes sense because every first-stage outcome has the stated number of completions.
:::

:::definition[Permutations and combinations]

For ordered choices of $r$ distinct objects from $n$ without replacement, $P_r^n=n!/(n-r)!$. For unordered selection, $\binom nr=n!/[r!(n-r)!]$; the combination formula is on Final sheet, page 1. If the objects include $n_1,n_2,\ldots$ identical copies of types, the number of distinct full arrangements is $n!/(n_1!n_2!\cdots)$ because swaps of identical objects do not create new arrangements.
:::

:::callout-key[Four fast questions]

**Does every stage have new choices?** Multiply. **Does order matter?** If yes, use ordered arrangements. **Does replacement occur?** If no, lower the available count each time. **Are items identical or is order irrelevant?** Divide out the orderings that duplicate one outcome. An ordinary three-digit prefix may begin with 0 unless the question explicitly restricts it. A real-world convention not present in the question cannot be silently imposed.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 580 210" role="img" aria-label="A decision tree with two transmission choices followed by two air conditioning choices">
<text class="fig-label-em" x="20" y="25">Start</text><path class="fig-guide" d="M 72,90 L 190,62"/><path class="fig-guide" d="M 72,90 L 190,149"/><text class="fig-label" x="199" y="55">Automatic</text><path class="fig-guide" d="M 265,62 L 380,33"/><text class="fig-label" x="385" y="33">A/C yes</text><path class="fig-guide" d="M 265,62 L 380,91"/><text class="fig-label" x="385" y="91">A/C no</text><text class="fig-label" x="199" y="142">Manual</text><path class="fig-guide" d="M 265,149 L 380,120"/><text class="fig-label" x="385" y="120">A/C yes</text><path class="fig-guide" d="M 265,149 L 380,178"/><text class="fig-label" x="385" y="178">A/C no</text>
</svg>
<figcaption>Each branch represents a choice, and every complete left-to-right path represents one outcome; additional stereo and color stages multiply the path count.</figcaption>
</figure>

:::example[Example 3.9 — Automobile designs from the slide tree]
A vehicle has 2 possible transmissions, 2 air-conditioning choices, 3 stereo choices, and 4 colors. How many distinct vehicle configurations can be ordered?

::::answer[Answer]
**Answer:** 48.

1. A complete car choice requires a transmission, air conditioning, stereo, and color. These are successive stages.
2. There are 2 choices at the first stage, 2 at the second, 3 at the third, and 4 at the fourth: $2\times2\times3\times4=48$.
3. One branch of the tree is one complete configuration. Counting branches at only the first two levels would miss the color and stereo choices.

Check: The manufacturer can offer 48 distinct designs under these choices.
::::
:::

:::example[Example 3.10 — Ten true-false questions]
A test has 10 True/False questions. How many different complete response sequences can a student mark?

::::answer[Answer]
**Answer:** 1024.

1. Each question has 2 choices, True or False, and neither answer removes choices for later questions.
2. Multiply ten factors of 2: $2\times2\times2\times2\times2\times2\times2\times2\times2\times2=1024$.
3. An answer sequence, such as T-F-T-..., is different if one answer changes. Therefore these are 1024 distinct completed tests.

Check: There are 1024 different possible answer patterns.
::::
:::

:::example[Example 3.11 — Mixed true-false and multiple choice]
A test has 5 True/False questions and 5 multiple-choice questions with four possible choices each. How many response sequences are possible?

::::answer[Answer]
**Answer:** 32768.

1. A True/False item gives 2 possibilities; each multiple-choice item gives 4.
2. The sequence count is $2^5\times4^5=32\times1024=32768$. Keep separate powers because the two item types have different branch counts.
3. The test has ten questions, but $10!$ is not appropriate: the question is not about rearranging ten fixed objects.

Check: Students can mark 32768 distinct complete answer sequences.
::::
:::

:::example[Example 3.12 — Twenty-five-member officers]
An organization with 25 members must choose a president and a vice president. How many ordered assignments are possible?

::::answer[Answer]
**Answer:** 600.

1. President and vice president are different offices, so exchanging the same two people changes the assignment.
2. There are 25 choices for president. After choosing that person, there are 24 remaining choices for vice president.
3. Calculate $25\times24=600$. This is $P_2^{25}$, and dividing by 2 would incorrectly erase the office distinction.

Check: Six hundred ordered pairs can fill the two officer positions.
::::
:::

:::example[Example 3.13 — Four distinct circuit-board components]
A printed circuit board has 8 locations in which a component can be placed. Four distinct components are installed in different locations. How many possible designs exist?

::::answer[Answer]
**Answer:** 1680.

1. The parts are distinct, and placing part A at position 1 while part B goes at position 2 differs from swapping them.
2. Place the four components in sequence: $8\times7\times6\times5=1680$.
3. The factors decline because a board location already occupied cannot be used again; the part identities make this a permutation.

Check: There are 1680 distinct assignments of four labeled components to eight locations.
::::
:::

:::example[Example 3.14 — Bar codes with repeated line thicknesses]
A bar code consists of 4 thick, 3 medium, and 2 thin lines. How many distinct orderings of those 9 lines exist?

::::answer[Answer]
**Answer:** 1260.

1. If all nine lines were distinguishable, there would be $9!$ orders.
2. Swapping the 4 thick lines, the 3 medium lines, or the 2 thin lines does not change the printed code. Divide by their internal rearrangements.
3. Compute $9!/(4!3!2!)=362880/(24\times6\times2)=1260$.

Check: The printer can make 1260 visually distinct labels.
::::
:::

:::example[Example 3.15 — Five identical components in eight locations]
A printed circuit board has 8 locations. Five **identical** components are placed, one per location. How many designs are possible?

::::answer[Answer]
**Answer:** 56.

1. Only the five chosen locations matter. The components cannot be distinguished, so installation order does not matter.
2. Use Final page 1: $\binom85=8!/(5!3!)=(8\times7\times6)/(3\times2\times1)=56$.
3. The answer is much smaller than a permutation count because each group would otherwise be repeated $5!$ times.

Check: There are 56 different sets of occupied locations.
::::
:::

:::problem[Problem 3.8 — Unit 3 Exercise 5(a): three numbered bags]{difficulty=easy}
Three bags each contain five balls numbered 1 through 5. One ball is taken from each bag. How many ordered sequences can result?

::::solution[Solution]
**Answer:** 125.

1. The bag identity gives three stages. Each bag separately has 5 possible numbered outcomes.
2. One bag's draw does not remove a ball from either other bag. Multiply $5\times5\times5=125$.
3. The sequence (bag 1, bag 2, bag 3) is ordered, so `1,2,3` and `3,2,1` count as different results.

Check: There are 125 possible ordered triples.
::::
:::

:::problem[Problem 3.9 — Unit 3 Exercise 5(b): replacement]{difficulty=easy}
From one bag containing balls numbered 1 through 5, draw a ball, record it, and replace it. Repeat for five draws. How many sequences?

::::solution[Solution]
**Answer:** 3125.

1. Because each ball returns to the bag, every draw again has 5 possibilities.
2. The number of five-draw sequences is $5\times5\times5\times5\times5=3125$.
3. Repeated numbers such as `2,2,2,2,2` are legal when you replace. Excluding them would mean solving a different experiment.

Check: There are 3125 possible ordered five-draw results.
::::
:::

:::problem[Problem 3.10 — Unit 3 Exercise 5(c): no replacement]{difficulty=standard}
From a single bag of five distinct numbered balls, draw all five **without replacement**. How many possible sequences?

::::solution[Solution]
**Answer:** 120.

1. First draw offers 5 choices; removing it leaves 4 choices for the second and then 3 for the third.
2. Multiply the decreasing counts $5\times4\times3\times2\times1=5!=120$.
3. Every outcome is a permutation of all five numbers, with none repeated. Replacement would have given 3125 instead.

Check: There are 120 permutations of the five numbered balls.
::::
:::

:::problem[Problem 3.11 — Unit 3 Exercise 5(d): three draws]{difficulty=standard}
Draw only three balls from the five distinct numbered balls, without replacement. Keep order. How many sequences are possible?

::::solution[Solution]
**Answer:** 60.

1. The first ball has five options. There are four remaining for the second, then three for the third.
2. Stop after three factors: $5\times4\times3=60$. In permutation notation, this is $P_3^5=5!/(5-3)!$.
3. Multiplying by 2 and 1 would count full five-ball permutations, not the three-draw experiment described.

Check: Sixty distinct ordered triples can be drawn.
::::
:::

:::problem[Problem 3.12 — Unit 3 Exercise 5(e): unordered triples]{difficulty=standard}
Draw three balls from five distinct numbered balls without replacement, but treat different draw orders of the same group as identical. How many groups are possible?

::::solution[Solution]
**Answer:** 10.

1. Start from the ordered three-draw count: $5\times4\times3=60$.
2. Each group of three was counted $3!=6$ times, one for each internal order.
3. Divide $60/6=10$, or use $\binom53=5!/(3!2!)=10$ from Final page 1.

Check: Ten unordered three-ball groups exist.
::::
:::

:::problem[Problem 3.13 — Unit 3 Exercise 5(f): repeated colors]{difficulty=challenge}
A bag contains two identical red balls, two identical green balls, and one yellow ball. All five balls are drawn without replacement. How many distinct color sequences are possible?

::::solution[Solution]
**Answer:** 30.

1. There are five positions, but the two reds are indistinguishable and the two greens are indistinguishable.
2. Start with $5!=120$ hypothetical labeled orders, then divide by $2!$ for red swaps and $2!$ for green swaps.
3. Calculate $120/(2\times2)=30$ different observable color sequences. The yellow ball occurs exactly once in every sequence.

Check: The five colored balls have 30 different color-order patterns.
::::
:::

:::problem[Problem 3.14 — Homework 3: unconstrained three-digit prefixes]{difficulty=easy}
How many three-digit telephone prefixes can be formed from the digits 0 through 9, with no other restrictions stated?

::::solution[Solution]
**Answer:** 1000.

1. Each of three positions has ten possible digits, including 0 and 1.
2. Repetition is permitted when the question does not exclude it, so multiply $10\times10\times10=1000$.
3. A leading zero is counted here because the problem does not prohibit it; applying a telephone-system convention would change the stated problem.

Check: There are 1000 distinct three-digit strings under the stated rules.
::::
:::

:::example[Example 3.16 — Homework 3: restricted beginning and middle]
How many three-digit prefixes do not start with 0 or 1, but have either 0 or 1 in the middle position? The final digit is unrestricted.

::::answer[Answer]
**Answer:** 160.

1. The first digit can be 2 through 9, giving 8 choices.
2. The middle digit has exactly 2 choices, and the last digit still has 10 choices because repetition is not excluded.
3. Multiply $8\times2\times10=160$ prefixes. Do not make the third digit fewer than ten choices unless a no-repeat rule is explicitly stated.

Check: The restrictions permit 160 three-digit prefixes.
::::
:::

:::example[Example 3.17 — Homework 3: no repeated digits]
How many three-digit prefixes use digits 0 through 9 if no digit may appear more than once?

::::answer[Answer]
**Answer:** 720.

1. The first position has 10 digits because a leading zero was not forbidden.
2. The second position can use any of the 9 digits left. The third has 8 digits left.
3. Therefore $10\times9\times8=720$ prefixes. The count is a permutation, not $10^3$, because repeats are prohibited.

Check: There are 720 ordered prefixes with distinct digits.
::::
:::

:::example[Example 3.18 — Exam 1 practice: iPhone model choices]
A customer chooses an iPhone model A, B, or C, a color black or white, and warranty yes or no. How many leaves would the full decision tree have?

::::answer[Answer]
**Answer:** 12.

1. Start with three model branches. From each model, make black and white color branches.
2. From each model-color branch, make warranty yes and no branches. The last stage contributes 2 outcomes per prior path.
3. The complete tree has $3\times2\times2=12$ leaves, each representing exactly one model-color-warranty combination.

Check: There are 12 complete purchasing configurations.
::::
:::

:::example[Example 3.19 — Exam 1 practice: three-letter airport codes]
Airport destinations are identified by three letters, such as LAX. Assuming each position can use any of the 26 English letters and repetitions are permitted, how many distinct codes exist?

::::answer[Answer]
**Answer:** 17576.

1. A three-letter identifier is an ordered triple, so ABC differs from ACB.
2. Under the stated assumption each of three positions has 26 available letters, and repeats are allowed.
3. Multiply $26\times26\times26=17576$. If repeated letters were forbidden, a different count $26\times25\times24$ would apply.

Check: The hypothetical code scheme contains 17576 possible strings.
::::
:::

:::callout-pitfall[Counting traps from the practice exam]
Do not treat $n!$ and $\binom nr$ as interchangeable. Eight available locations with four **distinct** parts uses $8\cdot7\cdot6\cdot5$; eight locations with five **identical** parts uses $\binom85$. For a prefix, do not silently forbid 0 in the first position. Replacing a sampled object resets the choices; not replacing it reduces later choices. A combination uses a factorial in its denominator specifically to remove duplicates, not because a smaller answer merely feels more likely.
:::

## 3.3 Probability Rules and the Addition Principle

Now that an event describes a set of outcomes, probability measures how likely that set is. If every one of six faces on a fair die is equally likely, even faces form three of the six outcomes. But the class's manufacturing tables do not usually have equally likely categories. If a table gives frequencies, divide the chosen count by the total. If it gives probabilities already, add the appropriate cells and **do not divide again**. A table in which every cell is a joint probability must total one; the marginal probability of a row or column is the sum of its entries.

The addition rule handles *or*. Think of two transparencies placed over the same table. Summing the two event probabilities counts the overlap once on each transparency. Subtract the intersection so it is counted just once. This is the reason for the minus sign, not an arbitrary algebra trick. It works whether the events are dependent, independent, or mutually exclusive. Mutually exclusive is a special case in which the overlap is zero. The three-event rule follows the same inclusion-exclusion idea, with the triple overlap added back at the end.

The distinction between a count and a probability is worth defending in every solution: a set of 38 customers is an answer to *how many*, whereas $38/50=0.76$ is the chance of randomly selecting such a customer under equal sampling. The Unit 3 assignment deliberately asks for counts in some tables. The exam practice deliberately supplies other tables as already normalized joint probabilities. Read the heading before calculating.

:::definition[Probability and basic axioms]

For any event $E$, $0\le P(E)\le1$, $P(S)=1$, and $P(\varnothing)=0$. For disjoint events, $P(A\cup B)=P(A)+P(B)$. If $N$ elementary outcomes are equally likely and $m$ satisfy $E$, then $P(E)=m/N$; this fraction follows from equal shares, rather than needing a special sheet formula.
:::

:::theorem[Complement and two-event addition]

$$P(E')=1-P(E),\qquad P(A\cup B)=P(A)+P(B)-P(A\cap B).$$

Both identities are on **Final Exam Equations, page 1**, near the top. For mutually exclusive $A,B$, the intersection is zero, so the second equation reduces to $P(A)+P(B)$.
:::

:::theorem[Three-event addition]

$$P(A\cup B\cup C)=P(A)+P(B)+P(C)-P(A\cap B)-P(A\cap C)-P(B\cap C)+P(A\cap B\cap C).$$

This appears on **Final sheet, page 1**. The last term is positive because subtracting all three pairwise overlaps removes the center too many times.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 560 230" role="img" aria-label="Two intersecting event regions both counted by separate sums">
<rect class="fig-axis" x="18" y="14" width="521" height="195"/><path class="fig-fill" d="M324.00,117.00 L323.78,122.04 L323.11,127.05 L322.00,132.02 L320.46,136.93 L318.48,141.75 L316.08,146.47 L313.27,151.06 L310.07,155.50 L306.47,159.78 L302.51,163.87 L298.19,167.77 L293.54,171.45 L288.57,174.89 L283.31,178.09 L277.78,181.02 L272.00,183.68 L266.00,186.06 L259.80,188.14 L253.43,189.91 L246.92,191.38 L240.29,192.52 L233.57,193.34 L226.80,193.84 L220.00,194.00 L213.20,193.84 L206.43,193.34 L199.71,192.52 L193.08,191.38 L186.57,189.91 L180.20,188.14 L174.00,186.06 L168.00,183.68 L162.22,181.02 L156.69,178.09 L151.43,174.89 L146.46,171.45 L141.81,167.77 L137.49,163.87 L133.53,159.78 L129.93,155.50 L126.73,151.06 L123.92,146.47 L121.52,141.75 L119.54,136.93 L118.00,132.02 L116.89,127.05 L116.22,122.04 L116.00,117.00 L116.22,111.96 L116.89,106.95 L118.00,101.98 L119.54,97.07 L121.52,92.25 L123.92,87.53 L126.73,82.94 L129.93,78.50 L133.53,74.22 L137.49,70.13 L141.81,66.23 L146.46,62.55 L151.43,59.11 L156.69,55.91 L162.22,52.98 L168.00,50.32 L174.00,47.94 L180.20,45.86 L186.57,44.09 L193.08,42.62 L199.71,41.48 L206.43,40.66 L213.20,40.16 L220.00,40.00 L226.80,40.16 L233.57,40.66 L240.29,41.48 L246.92,42.62 L253.43,44.09 L259.80,45.86 L266.00,47.94 L272.00,50.32 L277.78,52.98 L283.31,55.91 L288.57,59.11 L293.54,62.55 L298.19,66.23 L302.51,70.13 L306.47,74.22 L310.07,78.50 L313.27,82.94 L316.08,87.53 L318.48,92.25 L320.46,97.07 L322.00,101.98 L323.11,106.95 L323.78,111.96 L324.00,117.00 Z"/><path class="fig-fill-alt" d="M445.00,117.00 L444.78,122.04 L444.11,127.05 L443.00,132.02 L441.46,136.93 L439.48,141.75 L437.08,146.47 L434.27,151.06 L431.07,155.50 L427.47,159.78 L423.51,163.87 L419.19,167.77 L414.54,171.45 L409.57,174.89 L404.31,178.09 L398.78,181.02 L393.00,183.68 L387.00,186.06 L380.80,188.14 L374.43,189.91 L367.92,191.38 L361.29,192.52 L354.57,193.34 L347.80,193.84 L341.00,194.00 L334.20,193.84 L327.43,193.34 L320.71,192.52 L314.08,191.38 L307.57,189.91 L301.20,188.14 L295.00,186.06 L289.00,183.68 L283.22,181.02 L277.69,178.09 L272.43,174.89 L267.46,171.45 L262.81,167.77 L258.49,163.87 L254.53,159.78 L250.93,155.50 L247.73,151.06 L244.92,146.47 L242.52,141.75 L240.54,136.93 L239.00,132.02 L237.89,127.05 L237.22,122.04 L237.00,117.00 L237.22,111.96 L237.89,106.95 L239.00,101.98 L240.54,97.07 L242.52,92.25 L244.92,87.53 L247.73,82.94 L250.93,78.50 L254.53,74.22 L258.49,70.13 L262.81,66.23 L267.46,62.55 L272.43,59.11 L277.69,55.91 L283.22,52.98 L289.00,50.32 L295.00,47.94 L301.20,45.86 L307.57,44.09 L314.08,42.62 L320.71,41.48 L327.43,40.66 L334.20,40.16 L341.00,40.00 L347.80,40.16 L354.57,40.66 L361.29,41.48 L367.92,42.62 L374.43,44.09 L380.80,45.86 L387.00,47.94 L393.00,50.32 L398.78,52.98 L404.31,55.91 L409.57,59.11 L414.54,62.55 L419.19,66.23 L423.51,70.13 L427.47,74.22 L431.07,78.50 L434.27,82.94 L437.08,87.53 L439.48,92.25 L441.46,97.07 L443.00,101.98 L444.11,106.95 L444.78,111.96 L445.00,117.00 Z"/><path class="fig-curve" d="M324.00,117.00 L323.78,122.04 L323.11,127.05 L322.00,132.02 L320.46,136.93 L318.48,141.75 L316.08,146.47 L313.27,151.06 L310.07,155.50 L306.47,159.78 L302.51,163.87 L298.19,167.77 L293.54,171.45 L288.57,174.89 L283.31,178.09 L277.78,181.02 L272.00,183.68 L266.00,186.06 L259.80,188.14 L253.43,189.91 L246.92,191.38 L240.29,192.52 L233.57,193.34 L226.80,193.84 L220.00,194.00 L213.20,193.84 L206.43,193.34 L199.71,192.52 L193.08,191.38 L186.57,189.91 L180.20,188.14 L174.00,186.06 L168.00,183.68 L162.22,181.02 L156.69,178.09 L151.43,174.89 L146.46,171.45 L141.81,167.77 L137.49,163.87 L133.53,159.78 L129.93,155.50 L126.73,151.06 L123.92,146.47 L121.52,141.75 L119.54,136.93 L118.00,132.02 L116.89,127.05 L116.22,122.04 L116.00,117.00 L116.22,111.96 L116.89,106.95 L118.00,101.98 L119.54,97.07 L121.52,92.25 L123.92,87.53 L126.73,82.94 L129.93,78.50 L133.53,74.22 L137.49,70.13 L141.81,66.23 L146.46,62.55 L151.43,59.11 L156.69,55.91 L162.22,52.98 L168.00,50.32 L174.00,47.94 L180.20,45.86 L186.57,44.09 L193.08,42.62 L199.71,41.48 L206.43,40.66 L213.20,40.16 L220.00,40.00 L226.80,40.16 L233.57,40.66 L240.29,41.48 L246.92,42.62 L253.43,44.09 L259.80,45.86 L266.00,47.94 L272.00,50.32 L277.78,52.98 L283.31,55.91 L288.57,59.11 L293.54,62.55 L298.19,66.23 L302.51,70.13 L306.47,74.22 L310.07,78.50 L313.27,82.94 L316.08,87.53 L318.48,92.25 L320.46,97.07 L322.00,101.98 L323.11,106.95 L323.78,111.96 L324.00,117.00 Z"/><path class="fig-curve" d="M445.00,117.00 L444.78,122.04 L444.11,127.05 L443.00,132.02 L441.46,136.93 L439.48,141.75 L437.08,146.47 L434.27,151.06 L431.07,155.50 L427.47,159.78 L423.51,163.87 L419.19,167.77 L414.54,171.45 L409.57,174.89 L404.31,178.09 L398.78,181.02 L393.00,183.68 L387.00,186.06 L380.80,188.14 L374.43,189.91 L367.92,191.38 L361.29,192.52 L354.57,193.34 L347.80,193.84 L341.00,194.00 L334.20,193.84 L327.43,193.34 L320.71,192.52 L314.08,191.38 L307.57,189.91 L301.20,188.14 L295.00,186.06 L289.00,183.68 L283.22,181.02 L277.69,178.09 L272.43,174.89 L267.46,171.45 L262.81,167.77 L258.49,163.87 L254.53,159.78 L250.93,155.50 L247.73,151.06 L244.92,146.47 L242.52,141.75 L240.54,136.93 L239.00,132.02 L237.89,127.05 L237.22,122.04 L237.00,117.00 L237.22,111.96 L237.89,106.95 L239.00,101.98 L240.54,97.07 L242.52,92.25 L244.92,87.53 L247.73,82.94 L250.93,78.50 L254.53,74.22 L258.49,70.13 L262.81,66.23 L267.46,62.55 L272.43,59.11 L277.69,55.91 L283.22,52.98 L289.00,50.32 L295.00,47.94 L301.20,45.86 L307.57,44.09 L314.08,42.62 L320.71,41.48 L327.43,40.66 L334.20,40.16 L341.00,40.00 L347.80,40.16 L354.57,40.66 L361.29,41.48 L367.92,42.62 L374.43,44.09 L380.80,45.86 L387.00,47.94 L393.00,50.32 L398.78,52.98 L404.31,55.91 L409.57,59.11 L414.54,62.55 L419.19,66.23 L423.51,70.13 L427.47,74.22 L431.07,78.50 L434.27,82.94 L437.08,87.53 L439.48,92.25 L441.46,97.07 L443.00,101.98 L444.11,106.95 L444.78,111.96 L445.00,117.00 Z"/><text class="fig-label" x="170" y="115">A</text><text class="fig-label-em" x="271" y="115">overlap</text><text class="fig-label" x="393" y="115">B</text>
</svg>
<figcaption>Adding the probabilities of $A$ and $B$ counts their shared lens twice, so subtract $P(A\cap B)$ exactly once.</figcaption>
</figure>

:::example[Example 3.20 — A probability space with unequal outcomes]
An experiment has outcomes $S=\{a,b,c,d\}$ with probabilities $0.1,0.3,0.5,0.1$, respectively. Let $A=\{a,b\}$. Find $P(A)$.

::::answer[Answer]
**Answer:** 0.40.

1. First identify which elementary outcomes belong to $A$: these are $a$ and $b$.
2. Add their probabilities rather than counting two of four equally: $P(A)=P(a)+P(b)=0.1+0.3=0.40$.
3. Check the full space: $0.1+0.3+0.5+0.1=1$. The four outcomes have unequal weights, so a simple $2/4$ would be wrong.

Check: Event A occurs with probability 0.40 in this uneven sample space.
::::
:::

:::example[Example 3.21 — Set probabilities for B and C]
In the experiment $P(a)=0.1,P(b)=0.3,P(c)=0.5,P(d)=0.1$, let $B=\{b,c,d\}$ and $C=\{d\}$. Find $P(B)$.

::::answer[Answer]
**Answer:** 0.90.

1. The event $B$ includes elementary outcomes $b$, $c$, and $d$, while $a$ is excluded.
2. Add the corresponding weights $0.3+0.5+0.1=0.90$.
3. You can check with the complement: $B'=\{a\}$ has probability 0.1, so $P(B)=1-0.1=0.90$. Also, $P(C)=0.1$.

Check: B includes nine tenths of the outcome probability.
::::
:::

:::example[Example 3.22 — Slide example: intersect A and B]
With $A=\{a,b\}, B=\{b,c,d\}$ and $P(b)=0.3$ in the four-outcome experiment, find $P(A\cap B)$.

::::answer[Answer]
**Answer:** 0.30.

1. List both events and keep only the outcomes appearing in both: $A\cap B=\{b\}$.
2. The elementary outcome $b$ carries probability $0.3$, so the intersection probability equals 0.30.
3. This does not mean $0.4\times0.9$: multiplication of marginal probabilities requires independence, which is not supplied and does not hold here.

Check: Both A and B occur together only when outcome b occurs.
::::
:::

:::example[Example 3.23 — Slide example: union A and B]
In the same experiment, $P(A)=0.4$, $P(B)=0.9$, and $P(A\cap B)=0.3$. Calculate $P(A\cup B)$.

::::answer[Answer]
**Answer:** 1.00.

1. The word 'or' means the union. Write the addition rule from Final sheet page 1.
2. Substitute $P(A\cup B)=0.4+0.9-0.3=1.00$; the common outcome b was counted in both marginal totals.
3. The union includes a, b, c, and d, which is all of S. Hence its probability must be exactly one.

Check: At least one of A or B always occurs in this experiment.
::::
:::

:::example[Example 3.24 — Unit 3 Exercise 6: scores below seventy]
The grade table gives Male/Female probabilities by score band: 90–100: .04/.06; 80–89: .15/.13; 70–79: .30/.15; 60–69: .08/.04; below 60: .03/.02. Let $A$ be score below 70. Find $P(A)$.

::::answer[Answer]
**Answer:** 0.17.

1. Select the two low-score rows: 60–69 and below 60, and include both gender columns.
2. Read 60–69 / Male = 0.08; 60–69 / Female = 0.04; below-60 / Male = 0.03; below-60 / Female = 0.02.
3. Add $0.08+0.04+0.03+0.02=0.17$. A score of exactly 70 is not below 70 and belongs to the next band.

Check: Seventeen percent of outcomes correspond to scores below 70.
::::
:::

:::example[Example 3.25 — Unit 3 Exercise 6: female scores below seventy]
In the grade table, the Female column contains 0.04 for scores 60–69 and 0.02 for below 60. What is the probability that a student is female **and** scores below 70?

::::answer[Answer]
**Answer:** 0.06.

1. Female is event $B$; score below 70 is event $A$. The question is $P(A\cap B)$.
2. Restrict the table to the Female column **and** the two rows below 70: $0.04+0.02$.
3. This gives 0.06. It is a joint probability, not the conditional probability among female students, which would have a denominator of $P(B)=0.40$.

Check: Six percent of all students are female and scored below 70.
::::
:::

:::example[Example 3.26 — Unit 3 Exercise 6: female or below seventy]
In the grade table, females have total probability $0.40$, grades below 70 have probability $0.17$, and female grades below 70 have probability $0.06$. Find $P(B\cup A)$.

::::answer[Answer]
**Answer:** 0.51.

1. Female OR scored below 70 is a union. Both can occur, so do not assume disjoint events.
2. Insert the three table-derived probabilities in the addition rule: $0.40+0.17-0.06=0.51$.
3. Alternatively add every female cell (0.40) and then the male below-70 cells $0.08+0.03=0.11$. Both methods give 0.51.

Check: Fifty-one percent meet at least one of the two conditions.
::::
:::

:::example[Example 3.27 — Unit 3 Exercise 6: B union C]
From the same grade table, let $B$ be female and $C$ be a score 80 or higher. The female column totals 0.40; the 90–100 row is .04/.06 and the 80–89 row .15/.13 (Male/Female). Compute $P(B\cup C)$.

::::answer[Answer]
**Answer:** 0.59.

1. Calculate $P(C)$ from the two rows 80–89 and 90–100: $0.15+0.13+0.04+0.06=0.38$.
2. The overlap $B\cap C$ is the female cells in those two rows, $0.13+0.06=0.19$.
3. Apply the two-event formula: $P(B\cup C)=0.40+0.38-0.19=0.59$.

Check: Fifty-nine percent are female, have at least 80, or both.
::::
:::

:::example[Example 3.28 — Unit 3 Exercise 6: C union D]
Let $C$ mean grade at least 80 and $D$ mean a male grade below 70. From the table, $P(C)=0.38$ and the male cells below 70 are 0.08 and 0.03. Find $P(C\cup D)$.

::::answer[Answer]
**Answer:** 0.49.

1. A student cannot simultaneously score at least 80 and below 70, so $C$ and $D$ are mutually exclusive.
2. The male below-70 event has probability $0.08+0.03=0.11$.
3. Add the disjoint probabilities $0.38+0.11=0.49$. There is no intersection term to subtract because the grade ranges do not overlap.

Check: Forty-nine percent satisfy either high score or male low score.
::::
:::

:::problem[Problem 3.15 — Homework 3: supplier and conformance]{difficulty=standard}
Samples from suppliers 1, 2, and 3 have Conforms Yes/No counts 22/8, 25/5, and 30/10, respectively, for 100 total. Let $A$ be supplier 1 and $B$ be Conforms. What is $P(A\cup B)$?

::::solution[Solution]
**Answer:** 0.85.

1. Supplier 1 is row 1: $22+8=30$ samples. Conforming is column Yes: $22+25+30=77$ samples.
2. The intersection is row Supplier 1, column Yes: 22 samples. Subtract this overlapping cell once: $30+77-22=85$.
3. Divide by all 100 samples, giving $85/100=0.85$. This is not simply $0.30+0.77$, which double-counts supplier-1 conforming samples.

Check: Eighty-five percent of the samples are from supplier 1, conform, or both.
::::
:::

:::problem[Problem 3.16 — Homework 3: complement union with B]{difficulty=challenge}
For supplier 1 versus suppliers 2 and 3, there are 22 conforming and 8 nonconforming from supplier 1. The other suppliers together have 55 conforming and 15 nonconforming, total 100. Find $P(A'\cup B)$, where $A$ is supplier 1 and $B$ conforms.

::::solution[Solution]
**Answer:** 0.92.

1. $A'$ includes every sample from suppliers 2 and 3, totaling $55+15=70$.
2. Add supplier-1 samples that conform, the 22 in row Supplier 1 / column Yes. Do not add those 55 conforming other-supplier samples twice.
3. The union count is $70+22=92$, so $P(A'\cup B)=92/100=0.92$. Equivalently the only excluded cell is supplier-1/No, 8 samples.

Check: Ninety-two percent either came from another supplier or conformed; 0.55 is incorrect.
::::
:::

:::problem[Problem 3.17 — Homework 3: intersection probability]{difficulty=easy}
For the supplier table with 100 samples, 22 samples are from supplier 1 and conform. What is $P(A\cap B)$?

::::solution[Solution]
**Answer:** 0.22.

1. Intersection means one item satisfies both labels, not either one.
2. Read the Supplier 1 row and Conforms Yes column to obtain 22 samples in the cell.
3. Divide $22$ by the full sample size $100$, giving $0.22$. Conditional probabilities will use different denominators in the next section.

Check: Twenty-two percent were supplier-1 conforming samples.
::::
:::

:::problem[Problem 3.18 — SI review: independent of assumption of fairness]{difficulty=easy}
From a standard 52-card deck, what is the probability of drawing a heart on one uniformly random draw?

::::solution[Solution]
**Answer:** 0.25.

1. The sample space has 52 equally likely cards. There are 13 hearts in a standard four-suit deck.
2. Use favorable outcomes divided by total outcomes: $13/52=0.25$.
3. No replacement issue arises because only one card is drawn. The result equals one quarter by symmetry of the four suits.

Check: One in four uniformly drawn cards is a heart.
::::
:::

:::problem[Problem 3.19 — SI review: mutually exclusive addition]{difficulty=standard}
Events $A,B$ are mutually exclusive with $P(A)=0.25$ and $P(B)=0.35$. Find $P(A\cup B)$.

::::solution[Solution]
**Answer:** 0.60.

1. The phrase 'mutually exclusive' directly states that $P(A\cap B)=0$.
2. Use Final page 1: $P(A\cup B)=0.25+0.35-0=0.60$.
3. Do not multiply 0.25 and 0.35. Multiplication answers an 'and' question, whereas this question asks whether either event happens.

Check: The chance of A or B is sixty percent.
::::
:::

:::problem[Problem 3.20 — SI review: students in either sport]{difficulty=standard}
A class has 30 students. Eighteen play basketball, 12 play soccer, and 5 play both. How many play basketball or soccer?

::::solution[Solution]
**Answer:** 25.

1. The question asks for a count of the union, not a probability.
2. Add the basketball count 18 and soccer count 12, then subtract 5 who were counted in both groups: $18+12-5=25$.
3. Five students play neither, because the class total is 30. The union count of 25 therefore makes sense.

Check: Twenty-five students play at least one of the two sports.
::::
:::

:::problem[Problem 3.21 — SI review: complement of either device]{difficulty=challenge}
Events $A$ and $B$ satisfy $P(A)=0.40$, $P(B)=0.30$, $P(A\cap B)=0.10$. What is $P((A\cup B)')$?

::::solution[Solution]
**Answer:** 0.40.

1. Compute the union first, because a complement applies to the entire parenthesized event.
2. $P(A\cup B)=0.40+0.30-0.10=0.60$. Final sheet page 1 then gives $P((A\cup B)')=1-0.60$.
3. The answer is 0.40: neither A nor B. It is not $P(A')+P(B')$ because those complements overlap extensively.

Check: Forty percent of outcomes satisfy neither A nor B.
::::
:::

:::example[Example 3.29 — SI review: a fair die]
A fair six-sided die is rolled. What is the probability of getting an even number?

::::answer[Answer]
**Answer:** 0.50.

1. Write the equally likely sample space $S=\{1,2,3,4,5,6\}$.
2. The even-number event is $E=\{2,4,6\}$, containing three of the six outcomes.
3. Compute $3/6=0.50$. The wording does not require conditional probabilities or combinations; it is a direct count of equally likely outcomes.

Check: Half of equally likely die rolls are even.
::::
:::

:::example[Example 3.30 — SI review: probability of blue]
A bag has 5 red, 3 blue, and 2 green balls. One ball is drawn uniformly. What is $P(\text{blue})$?

::::answer[Answer]
**Answer:** 0.30.

1. Count every possible physical ball: $5+3+2=10$ total equally likely outcomes.
2. The favorable blue outcomes are exactly 3 balls.
3. Divide $3/10=0.30$. Do not divide by the number of colors; red, blue, and green are not equally likely categories here.

Check: Three of every ten equally likely balls in the bag are blue.
::::
:::

:::callout-pitfall[When to subtract the intersection]
The formula for a union always subtracts the overlap, even when a problem says the two events are independent. Independence does **not** mean the overlap disappears. Only *mutually exclusive* allows the subtraction term to become zero. In a probability table, adding a row and a column directly double-counts their crossing cell. If you are asked for **a number**, do not divide a count by the sample size just because the chapter is titled Probability.
:::

:::example[Example 3.31 — SI free response: laptop or tablet]
In a class of 50 students, 28 own a laptop, 20 own a tablet, and 12 own both. What is the probability that a randomly selected student owns a laptop or a tablet?

::::answer[Answer]
**Answer:** 0.72.

1. Laptop ownership and tablet ownership overlap in the 12 students who own both devices.
2. Use the union count $28+20-12=36$ students, so each overlapping student is counted once.
3. The random sample is one of 50 students: divide $36/50=0.72$. The result is an inclusive OR probability, not the sum of two probabilities with no overlap correction.

Check: Seventy-two percent of the class owns at least one of the devices.
::::
:::

:::example[Example 3.32 — SI free response: neither laptop nor tablet]
In a class of 50, 28 own a laptop, 20 a tablet, and 12 both. What is the probability that a random student owns neither?

::::answer[Answer]
**Answer:** 0.28.

1. The union contains $28+20-12=36$ students with at least one device.
2. The event neither is the complement of that union, so count $50-36=14$ students.
3. Divide $14/50=0.28$, equivalently $1-(36/50)=0.28$. Do not subtract only the 12 students with both devices.

Check: Twenty-eight percent of the students have neither device.
::::
:::

## 3.4 Conditional Probability and the Multiplication Rule

A conditional probability starts with a piece of information that rules out some possible outcomes. If you learn a pedestrian was in a crosswalk, the set of collisions outside crosswalks no longer belongs in your denominator. If you learn a car is red, only the red-column probabilities matter. The vertical bar in $P(B\mid A)$ is read "B given A" and means: **restrict the world to A, then ask what share of that restricted world is also B**. Conditional probabilities are not automatically smaller than the corresponding unconditional probabilities. An informative condition can make an event more likely.

The fraction has a numerator for the overlap and a denominator for the given event. That is why $P(B\mid A)$ and $P(A\mid B)$ usually differ: they share a numerator but have different denominators. In physical sampling without replacement, the first draw changes what is available for the second. The source's 100-part example is a clean way to see this: once a conforming part leaves the batch, the total goes from 100 to 99, but the number of defective parts remains ten. On the other hand, replacing the first part restores the original proportions.

The multiplication rule is not a new mystery formula. Start with the conditional fraction $P(B\mid A)=P(A\cap B)/P(A)$ and multiply both sides by $P(A)$. The result says that the chance both things happen is the chance of the first times the chance of the second **once the first has happened**. It works whether or not the events are independent. In a table, never assume that a statement containing *and* asks for multiplication: the overlap cell may already be given.

:::theorem[Conditional probability]

$$P(B\mid A)=\frac{P(A\cap B)}{P(A)},\qquad P(A)>0.$$

This exact formula is on **Final sheet, page 1**. The event to the right of the bar is the restricted sample space, hence the denominator. For a two-way count table, compute "overlap count / total count in given group" directly.
:::

:::theorem[Multiplication rule]

$$P(A\cap B)=P(B\mid A)P(A)=P(A\mid B)P(B).$$

Both forms appear on **Final sheet, page 1**. For three sequential observations, apply the same principle again: $P(A\cap B\cap C)=P(A)P(B\mid A)P(C\mid A\cap B)$. This three-stage identity follows by applying the printed two-event identity twice; it does not require a memorized new formula.
:::

:::callout-tip[Table-reading protocol]

Say the condition first: "among the red cars" means take the **Red column total**; "among electrical failures" means the **Electrical = Yes row total**. Then read the crossing cell or cells. Write numerator and denominator as counts from named rows and columns before ever entering a decimal into the calculator.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 560 230" role="img" aria-label="Conditioning restricts a full sample space to event A and examines B within A">
<rect class="fig-axis" x="20" y="12" width="522" height="196"/><path class="fig-fill" d="M435.00,112.00 L434.66,117.30 L433.64,122.57 L431.94,127.80 L429.58,132.96 L426.56,138.04 L422.90,143.00 L418.60,147.83 L413.70,152.50 L408.20,157.00 L402.14,161.31 L395.54,165.41 L388.43,169.28 L380.84,172.90 L372.79,176.26 L364.34,179.35 L355.50,182.15 L346.32,184.65 L336.85,186.83 L327.11,188.70 L317.15,190.24 L307.02,191.44 L296.75,192.31 L286.40,192.83 L276.00,193.00 L265.60,192.83 L255.25,192.31 L244.98,191.44 L234.85,190.24 L224.89,188.70 L215.15,186.83 L205.68,184.65 L196.50,182.15 L187.66,179.35 L179.21,176.26 L171.16,172.90 L163.57,169.28 L156.46,165.41 L149.86,161.31 L143.80,157.00 L138.30,152.50 L133.40,147.83 L129.10,143.00 L125.44,138.04 L122.42,132.96 L120.06,127.80 L118.36,122.57 L117.34,117.30 L117.00,112.00 L117.34,106.70 L118.36,101.43 L120.06,96.20 L122.42,91.04 L125.44,85.96 L129.10,81.00 L133.40,76.17 L138.30,71.50 L143.80,67.00 L149.86,62.69 L156.46,58.59 L163.57,54.72 L171.16,51.10 L179.21,47.74 L187.66,44.65 L196.50,41.85 L205.68,39.35 L215.15,37.17 L224.89,35.30 L234.85,33.76 L244.98,32.56 L255.25,31.69 L265.60,31.17 L276.00,31.00 L286.40,31.17 L296.75,31.69 L307.02,32.56 L317.15,33.76 L327.11,35.30 L336.85,37.17 L346.32,39.35 L355.50,41.85 L364.34,44.65 L372.79,47.74 L380.84,51.10 L388.43,54.72 L395.54,58.59 L402.14,62.69 L408.20,67.00 L413.70,71.50 L418.60,76.17 L422.90,81.00 L426.56,85.96 L429.58,91.04 L431.94,96.20 L433.64,101.43 L434.66,106.70 L435.00,112.00 Z"/><path class="fig-fill-alt" d="M398.00,112.00 L397.85,115.92 L397.39,119.83 L396.64,123.71 L395.58,127.53 L394.23,131.29 L392.60,134.96 L390.68,138.54 L388.49,142.00 L386.03,145.33 L383.33,148.53 L380.38,151.56 L377.20,154.43 L373.81,157.11 L370.22,159.60 L366.45,161.89 L362.50,163.96 L358.40,165.81 L354.17,167.43 L349.82,168.82 L345.38,169.96 L340.85,170.85 L336.27,171.49 L331.64,171.87 L327.00,172.00 L322.36,171.87 L317.73,171.49 L313.15,170.85 L308.62,169.96 L304.18,168.82 L299.83,167.43 L295.60,165.81 L291.50,163.96 L287.55,161.89 L283.78,159.60 L280.19,157.11 L276.80,154.43 L273.62,151.56 L270.67,148.53 L267.97,145.33 L265.51,142.00 L263.32,138.54 L261.40,134.96 L259.77,131.29 L258.42,127.53 L257.36,123.71 L256.61,119.83 L256.15,115.92 L256.00,112.00 L256.15,108.08 L256.61,104.17 L257.36,100.29 L258.42,96.47 L259.77,92.71 L261.40,89.04 L263.32,85.46 L265.51,82.00 L267.97,78.67 L270.67,75.47 L273.62,72.44 L276.80,69.57 L280.19,66.89 L283.78,64.40 L287.55,62.11 L291.50,60.04 L295.60,58.19 L299.83,56.57 L304.18,55.18 L308.62,54.04 L313.15,53.15 L317.73,52.51 L322.36,52.13 L327.00,52.00 L331.64,52.13 L336.27,52.51 L340.85,53.15 L345.38,54.04 L349.82,55.18 L354.17,56.57 L358.40,58.19 L362.50,60.04 L366.45,62.11 L370.22,64.40 L373.81,66.89 L377.20,69.57 L380.38,72.44 L383.33,75.47 L386.03,78.67 L388.49,82.00 L390.68,85.46 L392.60,89.04 L394.23,92.71 L395.58,96.47 L396.64,100.29 L397.39,104.17 L397.85,108.08 L398.00,112.00 Z"/><path class="fig-curve" d="M435.00,112.00 L434.66,117.30 L433.64,122.57 L431.94,127.80 L429.58,132.96 L426.56,138.04 L422.90,143.00 L418.60,147.83 L413.70,152.50 L408.20,157.00 L402.14,161.31 L395.54,165.41 L388.43,169.28 L380.84,172.90 L372.79,176.26 L364.34,179.35 L355.50,182.15 L346.32,184.65 L336.85,186.83 L327.11,188.70 L317.15,190.24 L307.02,191.44 L296.75,192.31 L286.40,192.83 L276.00,193.00 L265.60,192.83 L255.25,192.31 L244.98,191.44 L234.85,190.24 L224.89,188.70 L215.15,186.83 L205.68,184.65 L196.50,182.15 L187.66,179.35 L179.21,176.26 L171.16,172.90 L163.57,169.28 L156.46,165.41 L149.86,161.31 L143.80,157.00 L138.30,152.50 L133.40,147.83 L129.10,143.00 L125.44,138.04 L122.42,132.96 L120.06,127.80 L118.36,122.57 L117.34,117.30 L117.00,112.00 L117.34,106.70 L118.36,101.43 L120.06,96.20 L122.42,91.04 L125.44,85.96 L129.10,81.00 L133.40,76.17 L138.30,71.50 L143.80,67.00 L149.86,62.69 L156.46,58.59 L163.57,54.72 L171.16,51.10 L179.21,47.74 L187.66,44.65 L196.50,41.85 L205.68,39.35 L215.15,37.17 L224.89,35.30 L234.85,33.76 L244.98,32.56 L255.25,31.69 L265.60,31.17 L276.00,31.00 L286.40,31.17 L296.75,31.69 L307.02,32.56 L317.15,33.76 L327.11,35.30 L336.85,37.17 L346.32,39.35 L355.50,41.85 L364.34,44.65 L372.79,47.74 L380.84,51.10 L388.43,54.72 L395.54,58.59 L402.14,62.69 L408.20,67.00 L413.70,71.50 L418.60,76.17 L422.90,81.00 L426.56,85.96 L429.58,91.04 L431.94,96.20 L433.64,101.43 L434.66,106.70 L435.00,112.00 Z"/><path class="fig-curve" d="M398.00,112.00 L397.85,115.92 L397.39,119.83 L396.64,123.71 L395.58,127.53 L394.23,131.29 L392.60,134.96 L390.68,138.54 L388.49,142.00 L386.03,145.33 L383.33,148.53 L380.38,151.56 L377.20,154.43 L373.81,157.11 L370.22,159.60 L366.45,161.89 L362.50,163.96 L358.40,165.81 L354.17,167.43 L349.82,168.82 L345.38,169.96 L340.85,170.85 L336.27,171.49 L331.64,171.87 L327.00,172.00 L322.36,171.87 L317.73,171.49 L313.15,170.85 L308.62,169.96 L304.18,168.82 L299.83,167.43 L295.60,165.81 L291.50,163.96 L287.55,161.89 L283.78,159.60 L280.19,157.11 L276.80,154.43 L273.62,151.56 L270.67,148.53 L267.97,145.33 L265.51,142.00 L263.32,138.54 L261.40,134.96 L259.77,131.29 L258.42,127.53 L257.36,123.71 L256.61,119.83 L256.15,115.92 L256.00,112.00 L256.15,108.08 L256.61,104.17 L257.36,100.29 L258.42,96.47 L259.77,92.71 L261.40,89.04 L263.32,85.46 L265.51,82.00 L267.97,78.67 L270.67,75.47 L273.62,72.44 L276.80,69.57 L280.19,66.89 L283.78,64.40 L287.55,62.11 L291.50,60.04 L295.60,58.19 L299.83,56.57 L304.18,55.18 L308.62,54.04 L313.15,53.15 L317.73,52.51 L322.36,52.13 L327.00,52.00 L331.64,52.13 L336.27,52.51 L340.85,53.15 L345.38,54.04 L349.82,55.18 L354.17,56.57 L358.40,58.19 L362.50,60.04 L366.45,62.11 L370.22,64.40 L373.81,66.89 L377.20,69.57 L380.38,72.44 L383.33,75.47 L386.03,78.67 L388.49,82.00 L390.68,85.46 L392.60,89.04 L394.23,92.71 L395.58,96.47 L396.64,100.29 L397.39,104.17 L397.85,108.08 L398.00,112.00 Z"/><text class="fig-label" x="146" y="115">given A</text><text class="fig-label-em" x="316" y="115">B in A</text><text class="fig-label" x="25" y="28">S</text>
</svg>
<figcaption>For $P(B\mid A)$, the relevant denominator is the whole region $A$, and the numerator is only the portion inside both $A$ and $B$.</figcaption>
</figure>

:::example[Example 3.33 — Slide example: first conforming from a 100-part batch]
A batch has 100 parts, of which 10 are defective. One part is randomly selected. What is the probability the first part is not defective?

::::answer[Answer]
**Answer:** 0.90.

1. Count the conforming parts before any draw: $100-10=90$.
2. Each of the 100 parts is initially equally likely to be selected, so favorable count divided by total is $90/100=0.90$.
3. This is an unconditional probability about the first draw. The sample size has not changed yet because nothing was previously removed.

Check: Ninety percent of initially available parts are not defective.
::::
:::

:::example[Example 3.34 — Slide example: second part defective given first good]
In a batch of 100 parts with 10 defective, draw two without replacement. Given the first part is not defective, what is the probability the second part is defective?

::::answer[Answer]
**Answer:** 0.1010.

1. The first part is good, so none of the 10 defective parts has been removed.
2. There are now 99 parts available, with 10 defective: $P(D_2\mid G_1)=10/99$.
3. Calculate $10\div99=0.1010$ to four decimal places. The unconditional chance of second defective is still $10/100=0.10$ by symmetry, which is a different question.

Check: Given the first part was good, the second is defective with probability about 0.1010.
::::
:::

:::example[Example 3.35 — Slide example: tool one followed by tool two]
A batch has 10 parts from tool 1 and 40 from tool 2. Draw two without replacement. Given the first came from tool 1, what is the probability the second came from tool 2?

::::answer[Answer]
**Answer:** 0.8163.

1. After a tool-1 part was removed, nine tool-1 parts and all forty tool-2 parts remain.
2. The restricted sample space for the second draw has 49 parts, and 40 are favorable: $40/49$.
3. Evaluate $40\div49=0.8163$. Do not use $40/50$: the first part is known to have been removed.

Check: The second draw has probability 0.8163 of being from tool 2 under the condition.
::::
:::

:::example[Example 3.36 — Slide example: two defects from 850]
A batch has 850 parts, of which 50 are defective. Two parts are selected without replacement. Given the first is defective, what is the probability the second is defective?

::::answer[Answer]
**Answer:** 0.0577.

1. The first defective part has left the batch, so 49 defective parts remain.
2. The second draw is from 849 parts, giving conditional probability $49/849$.
3. The calculator shows approximately 0.0577. If the first part had been good instead, the numerator would still be 50, not 49.

Check: Given a first defect, the probability of a second defect is approximately 0.0577.
::::
:::

:::example[Example 3.37 — Slide example: first two defective and third good]
From 850 parts including 50 defective, select three without replacement. What is the probability that the first two are defective and the third is not?

::::answer[Answer]
**Answer:** 0.003203.

1. On the first draw, 50 of 850 parts are defective, so $P(D_1)=50/850$.
2. After that defect is removed, $P(D_2\mid D_1)=49/849$. After two defects have been removed, 800 conforming parts remain among 848: $P(G_3\mid D_1\cap D_2)=800/848$.
3. Multiply the three sequential factors: $(50/850)(49/849)(800/848)$. The answer is a probability of that **exact order**, not simply two defects anywhere in three draws.

Check: The value is the probability of the specific defect-defect-good sequence.
::::
:::

:::example[Example 3.38 — Unit 3 Exercise 7: red car]
The car-color probability table has Red probabilities .15, .08, .10, .02 for 1, 2, 3, 4 passengers, respectively. What is $P(\text{car red})$?

::::answer[Answer]
**Answer:** 0.35.

1. Select all four rows of the Red column; the event does not restrict passenger count.
2. Read row 1/Red = .15, row 2/Red = .08, row 3/Red = .10, row 4/Red = .02.
3. Add $.15+.08+.10+.02=.35$. The table entries are probabilities, so do not divide by a sample size.

Check: Thirty-five percent of cars in the study are red.
::::
:::

:::example[Example 3.39 — Unit 3 Exercise 7: two passengers given red]
In the car-color table, the row for 2 passengers and column Red is .08, and the Red column probabilities are .15, .08, .10, .02. Find $P(\text{2 passengers}\mid\text{red})$.

::::answer[Answer]
**Answer:** 0.2286.

1. The given category is Red, so the denominator is the Red column total: $.15+.08+.10+.02=.35$.
2. The joint event is the single intersection row 2 passengers / column Red, with probability .08.
3. Divide $.08/.35=0.2286$. This describes the proportion with two passengers **among red cars**, not among all cars.

Check: About 22.86 percent of red cars carry two passengers.
::::
:::

:::example[Example 3.40 — Unit 3 Exercise 7: black given three or four]
In the car table, the 3-passenger row is Red .10, Black .03, White .04, and the 4-passenger row is Red .02, Black .03, White .05. Find $P(\text{black}\mid\text{3 or 4 passengers})$.

::::answer[Answer]
**Answer:** 0.2222.

1. The condition is the set of cars with 3 or 4 passengers, so add **all three colors** in both rows: $.10+.03+.04+.02+.03+.05=.27$.
2. Within those rows the Black column contributes $.03+.03=.06$.
3. Calculate $.06/.27=0.2222$. Dividing by the Black column total would reverse the condition.

Check: About 22.22 percent of cars with three or four passengers are black.
::::
:::

:::example[Example 3.41 — Unit 3 Exercise 7: white and one passenger]
In the joint car-color probability table, the cell for 1 passenger and White is .07. Find $P(\text{white and 1 passenger})$.

::::answer[Answer]
**Answer:** 0.07.

1. The word 'and' describes the intersection of the White column and one-passenger row.
2. Because the table consists of joint probabilities, that particular cell is already the answer: .07.
3. No denominator adjustment is needed. Had the question said 'given the car was white', then the White-column total would be required.

Check: Seven percent of all cars are white and have one passenger.
::::
:::

:::example[Example 3.42 — Unit 3 Exercise 7: white or one passenger]
The White column of a car table is .07, .18, .04, .05 for 1–4 passengers. The 1-passenger row is Red .15, Black .13, White .07. Find $P(\text{white or one passenger})$.

::::answer[Answer]
**Answer:** 0.62.

1. White-column total is $.07+.18+.04+.05=.34$. The one-passenger row total is $.15+.13+.07=.35$.
2. The crossing row 1 / column White is .07. Subtract it once after adding both margins.
3. $P(\text{white or 1})=.34+.35-.07=.62$. This union includes every white car and every one-passenger car.

Check: Sixty-two percent of cars satisfy at least one of those descriptions.
::::
:::

:::example[Example 3.43 — Unit 3 Exercise 7: four passengers given black]
The Black column for cars with 1, 2, 3, and 4 passengers is .13, .12, .03, .03. Find $P(\text{4 passengers}\mid\text{black})$.

::::answer[Answer]
**Answer:** 0.0968.

1. The given group is Black, so sum its entire column: $.13+.12+.03+.03=.31$.
2. The Black/4-passenger cell is $.03$; it is the joint numerator.
3. Divide $.03/.31=0.0968$. Do not use the full sample-space denominator one: the question asks about black cars only.

Check: About 9.68 percent of black cars have four passengers.
::::
:::

:::problem[Problem 3.22 — Homework 3: probability of a gas leak]{difficulty=easy}
A maintenance firm observes air-conditioning failures in 107 units: Electrical Yes/Gas Yes 55, Electrical Yes/Gas No 17, Electrical No/Gas Yes 32, Electrical No/Gas No 3. What is $P(\text{gas leak})$?

::::solution[Solution]
**Answer:** 0.8131.

1. For a gas leak, read the Gas = Yes column across both Electrical Failure rows: 55 and 32.
2. There are $55+32=87$ gas-leak failures out of $55+17+32+3=107$ total failures.
3. Divide $87/107=0.8131$. The failures may involve both gas and electrical mechanisms, so do not remove the overlap.

Check: About 81.31 percent of observed AC failures involved a gas leak.
::::
:::

:::problem[Problem 3.23 — Homework 3: electrical given gas leak]{difficulty=standard}
The AC-failure table has Electrical Yes/Gas Yes 55 and Electrical No/Gas Yes 32. Find $P(\text{electrical evidence}\mid\text{gas leak})$.

::::solution[Solution]
**Answer:** 0.6322.

1. Condition on Gas = Yes. There are $55+32=87$ gas-leak failures in the relevant column.
2. Of these, 55 also have Electrical Failure = Yes; read the joint cell at Electrical Yes / Gas Yes.
3. Compute $55/87=0.6322$. The denominator is not all 107 failures because the problem states that a gas leak occurred.

Check: About 63.22 percent of gas-leak failures also have electrical evidence.
::::
:::

:::problem[Problem 3.24 — Homework 3: gas leak given electrical]{difficulty=standard}
The AC-failure table has Electrical Yes/Gas Yes 55 and Electrical Yes/Gas No 17. Find $P(\text{gas leak}\mid\text{electrical evidence})$.

::::solution[Solution]
**Answer:** 0.7639.

1. Condition on Electrical Failure = Yes. Its row contains $55+17=72$ failures.
2. The joint cell Electrical Yes/Gas Yes contributes 55 of those 72 outcomes.
3. Divide $55/72=0.7639$. This differs from $55/87$ in the previous problem because we changed which group was given.

Check: About 76.39 percent of electrical failures also include a gas leak.
::::
:::

:::problem[Problem 3.25 — Exam 1 practice: pedestrian outside crosswalk]{difficulty=easy}
In a collision table, Driver Speeding/Not Speeding rows and In Crosswalk/Not In Crosswalk columns have probabilities .19/.39 and .08/.34, respectively. Find the probability that a pedestrian was **not** in a crosswalk.

::::solution[Solution]
**Answer:** 0.73.

1. Read the Not in Crosswalk column for both driver-speeding categories.
2. Its two cells are Driver Speeding / Not in Crosswalk = .39 and Driver Not Speeding / Not in Crosswalk = .34.
3. Sum $.39+.34=.73$. The question did not condition on speeding, so the entire column belongs in the result.

Check: Seventy-three percent of recorded collisions happened outside a crosswalk.
::::
:::

:::problem[Problem 3.26 — Exam 1 practice: speeding given crosswalk]{difficulty=standard}
In a collision table, Speeding/In Crosswalk is .19 and Not Speeding/In Crosswalk is .08. Find $P(\text{speeding}\mid\text{in crosswalk})$.

::::solution[Solution]
**Answer:** 0.7037.

1. Among collisions with the pedestrian in a crosswalk, the column total is $.19+.08=.27$.
2. Of that conditional group, the speeding intersection cell is $.19$.
3. Calculate $.19/.27=0.7037$. Do not reverse the condition; $P(\text{crosswalk}\mid\text{speeding})$ would have a different denominator.

Check: About 70.37 percent of in-crosswalk collisions involved speeding.
::::
:::

:::problem[Problem 3.27 — Exam 1 practice: alternating odd and even tickets]{difficulty=challenge}
Tickets numbered 1 through 9 are drawn three times without replacement. What is the probability the parity sequence is either odd-even-odd or even-odd-even?

::::solution[Solution]
**Answer:** 0.2778.

1. There are 5 odd tickets and 4 even tickets. For odd-even-odd the factors are $(5/9)(4/8)(4/7)$: after one odd is removed, four odds remain.
2. For even-odd-even the factors are $(4/9)(5/8)(3/7)$: after one even, only three even tickets remain.
3. The two ordered patterns cannot occur together, so add: $80/504+60/504=140/504=0.2778$.

Check: The chance of either alternating parity pattern is about 27.78 percent.
::::
:::

:::problem[Problem 3.28 — Exam 1 practice: USB and portable drive]{difficulty=standard}
A shipment of 100 computers has USB3 Yes/No rows and Hard Drive Yes/No columns: USB3 Yes 15/80, USB3 No 4/1. Let $A$ mean hard drive and $B$ mean USB3. Find $P(A\mid B)$.

::::solution[Solution]
**Answer:** 0.1579.

1. Condition on USB3 = Yes, so the row total is $15+80=95$ computers.
2. The Hard Drive = Yes and USB3 = Yes intersection cell is 15.
3. Divide $15/95=0.1579$. Separately, the same table gives $P(A)=(15+4)/100=0.19$ and $P(A\cap B)=15/100=0.15$.

Check: About 15.79 percent of computers with USB3 also have a portable hard drive.
::::
:::

:::example[Example 3.44 — SI review: probability given male]
A class has 20 male and 30 female students. Twelve of the male students passed. Find $P(\text{pass}\mid\text{male})$.

::::answer[Answer]
**Answer:** 0.60.

1. The condition 'given male' restricts the denominator to the 20 male students.
2. Twelve students in that group satisfy Pass, so the conditional fraction is $12/20$.
3. The result is 0.60. Dividing 12 by 50 would answer the joint probability of male **and** pass, not the requested conditional probability.

Check: Sixty percent of male students passed.
::::
:::

:::example[Example 3.45 — SI review: king given face card]
A standard 52-card deck contains 12 face cards (four jacks, four queens, four kings). Given the card is a face card, what is the probability it is a king?

::::answer[Answer]
**Answer:** 0.3333.

1. Restrict the sample space to face cards, not all 52 cards.
2. There are four king face cards among 12 face cards, so the conditional probability is $4/12$.
3. That reduces to $1/3\approx0.3333$. The outcome count is exact even though the reported decimal is rounded.

Check: One third of face cards are kings.
::::
:::

:::example[Example 3.46 — SI review: intersection conditional]
Given $P(A\cap B)=0.20$ and $P(B)=0.50$, find $P(A\mid B)$.

::::answer[Answer]
**Answer:** 0.40.

1. The event to the right of the bar is $B$, so its probability 0.50 belongs in the denominator.
2. The numerator is the given intersection 0.20, so write $P(A\mid B)=0.20/0.50$.
3. Divide to obtain 0.40. The event $A$ uses 40 percent of the probability mass of the restricted event $B$.

Check: Among B outcomes, forty percent also satisfy A.
::::
:::

:::callout-pitfall[The order on either side of the bar is everything]
$P(A\mid B)$ and $P(B\mid A)$ have the same overlap numerator but different denominators. In a probability table, selecting the wrong row or column is often the entire error. Sampling **without** replacement changes later denominators and sometimes numerators; sampling **with** replacement restores the original chances. Do not use $P(A)P(B)$ for a sequential intersection unless independence has been established.
:::

## 3.5 Independence and Reliability Circuits

Independence is not another name for "different events." It means learning that one event occurred does not change the probability of the other. Imagine flipping two fair coins. The first result gives no information about the second result. Now imagine drawing two pieces from a finite bin without replacement. The first piece changes the bin's composition, and therefore the second probability. Independence is about information and the underlying experiment, not about whether two events can happen simultaneously.

The distinction becomes especially sharp in reliability engineering. For two components connected **in series**, both must work. That is an intersection of component-success events, and you multiply when their failures are independent. For two paths connected **in parallel**, the system works if either path works. Rather than adding the two success probabilities and subtracting an overlap you must compute, it is often easier to count system failure: both branches must fail. Subtract that product from one. Complex circuits can be simplified by treating a parallel group as one equivalent component, then combining those groups in series. Apply the operations one stage at a time.

One caution belongs specifically to the instructor's ABC computer-orders exercise: it supplies marginal percentages for three features but says nothing explicitly about whether the features are independent. The usual classroom calculation assumes independence. Mathematically, the joint probability is **not determined** by marginals alone, and a good answer distinguishes the additional assumption. If independence is stated in the question, use it. If not, state the assumption before multiplying.

:::definition[Independent events]

Events $A$ and $B$ with positive probabilities are independent when $P(B\mid A)=P(B)$, equivalently $P(A\mid B)=P(A)$ or $P(A\cap B)=P(A)P(B)$. The equivalences follow from the conditional and multiplication equations on **Final sheet, page 1**. Independence is a factual property to test or an assumption to be stated, not a default.
:::

:::theorem[Series and parallel reliability]

For independently functioning components with success probabilities $p_1$ and $p_2$, a **series** pair succeeds with probability $p_1p_2$. A **parallel** pair succeeds with probability $1-(1-p_1)(1-p_2)$. These are not separate printed formulas; the series result is the Final-page-1 multiplication rule under independence, and the parallel result is the complement rule applied to "both fail."
:::

:::callout-key[Mutual exclusivity is not independence]

If $A$ and $B$ are mutually exclusive and both have positive probability, knowing $A$ occurred makes $B$ impossible: $P(B\mid A)=0$ while $P(B)>0$. Thus they are **dependent**. Independent events, by contrast, typically have a positive intersection. Only when one event has probability zero can disjointness and independence both hold without contradiction.
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 560 231" role="img" aria-label="Series two components on one path versus parallel two branches">
<text class="fig-label-em" x="10" y="40">Series: both work</text><path class="fig-axis" d="M20,79 L135,79 M205,79 L304,79 M374,79 L540,79"/><rect class="fig-curve" x="135" y="62" width="70" height="34"/><rect class="fig-curve" x="304" y="62" width="70" height="34"/><text class="fig-label" x="157" y="83">p₁</text><text class="fig-label" x="324" y="83">p₂</text><text class="fig-label-em" x="10" y="132">Parallel: either path works</text><path class="fig-axis" d="M25,175 L130,175 M130,175 L130,151 L310,151 M130,175 L130,196 L310,196 M310,151 L400,151 L400,175 L530,175 M310,196 L400,196"/><rect class="fig-curve" x="225" y="137" width="70" height="27"/><rect class="fig-curve" x="225" y="182" width="70" height="27"/><text class="fig-label" x="246" y="156">p₁</text><text class="fig-label" x="246" y="201">p₂</text>
</svg>
<figcaption>A series system fails when any required element fails, while a parallel pair fails only if both alternative paths fail.</figcaption>
</figure>

:::example[Example 3.47 — Slide: replaced sample from 850]
A batch has 850 parts with 50 defective. Two are selected, but the first is replaced before the second draw. Find $P(\text{second defective}\mid\text{first defective})$.

::::answer[Answer]
**Answer:** 0.0588.

1. Replacement restores exactly the original 850-part population before the second draw.
2. The second draw still sees 50 defective out of 850 total, regardless of the first draw: $P(B\mid A)=50/850$.
3. Calculate 0.0588. This equals the unconditional defective probability $P(B)$, which demonstrates independence in this sampling procedure.

Check: The second defective chance remains about 5.88 percent even after a first defect.
::::
:::

:::example[Example 3.48 — Slide: two parts in series]
A series circuit has two independently functioning components with success probabilities 0.8 and 0.9. Find the probability the circuit operates.

::::answer[Answer]
**Answer:** 0.72.

1. A series path is complete only if the first **and** second components work.
2. Independence allows the intersection probability to be the product $0.8\times0.9$.
3. Calculate 0.72. If either device fails the sole path breaks, so system success must be smaller than either individual component's success probability.

Check: The series circuit operates on 72 percent of trials under these assumptions.
::::
:::

:::example[Example 3.49 — Slide: two parallel devices]
Two independent parallel devices each function with probability 0.95. Find the probability the overall circuit operates.

::::answer[Answer]
**Answer:** 0.9975.

1. At least one working branch creates a path, so the only system-failure case is both devices failing.
2. Each component fails with probability $1-0.95=0.05$. Independence makes the joint failure chance $0.05\times0.05=0.0025$.
3. Take the complement: $1-0.0025=0.9975$. The parallel pair is more reliable than one of its components alone.

Check: The parallel circuit functions with probability 0.9975.
::::
:::

:::example[Example 3.50 — Slide: advanced parallel blocks in series]
An advanced circuit has three independent 0.90-success components in parallel, then two independent 0.95-success components in parallel, followed by one 0.99-success device in series. Find its operating probability.

::::answer[Answer]
**Answer:** 0.986537.

1. The first block functions if at least one of its three 0.90 components works. Its probability is $1-(0.10)^3=0.999$.
2. The second block has two parallel 0.95 components, so its operating probability is $1-(0.05)^2=0.9975$.
3. All three **blocks** must work in series: $0.999\times0.9975\times0.99$. Multiply carefully after reducing each parallel block.

Check: The result is the chance a complete left-to-right path remains operational.
::::
:::

:::example[Example 3.51 — Unit 3 Exercise 10: diet and Coke independence]
The shipment has 300 Coke, 120 Diet Coke, 500 Pepsi, and 200 Diet Pepsi cans. Let $A$ mean Diet and $B$ Coke product. Find $P(A\cap B)$ as a step toward checking independence.

::::answer[Answer]
**Answer:** 0.107143.

1. The shipment total is $300+120+500+200=1120$ cans.
2. The overlap Diet AND Coke is exactly the 120 Diet Coke cans, giving $120/1120$.
3. Independence test: $P(A)=320/1120=2/7$ and $P(B)=420/1120=3/8$, whose product $(2/7)(3/8)=3/28=120/1120$. Thus the events are independent for this table.

Check: Diet and Coke product are independent in the observed shipment, despite overlapping.
::::
:::

:::example[Example 3.52 — Unit 3 Exercise 11: computer orders]
ABC computers receives 42% of orders from universities, 75% requesting monitors, and 15% requesting overnight shipping. **If these three event indicators are mutually independent**, find the chance one order has all three features.

::::answer[Answer]
**Answer:** 0.047250.

1. The desired event is a triple intersection: university AND monitor AND overnight.
2. Under the explicitly stated mutual-independence assumption, multiply all three marginal probabilities: $.42\times.75\times.15$.
3. This yields 0.04725. The original slide lists only marginal percentages, not joint behavior; without independence this exact numerical answer cannot be justified.

Check: Under mutual independence, 4.725 percent of orders have all three attributes.
::::
:::

:::example[Example 3.53 — Unit 3 Exercise 12: parallel blocks with failure probabilities]
A circuit has a first parallel block: an upper path of two independent devices in series, each with **failure** probability .01, and a lower device with failure probability .10. A second parallel block has two devices each with failure probability .10. All devices are independent. Find circuit operating probability.

::::answer[Answer]
**Answer:** 0.988030.

1. Upper path in block one works with $.99\times.99=.9801$, hence that path fails with $.0199$. The lower path fails with .10.
2. Block one fails only if both paths fail: $.0199\times.10=.00199$, so block-one reliability is $1-.00199=.99801$. Block two reliability is $1-.10\times.10=.99$.
3. The blocks themselves are in series; multiply $.99801\times.99=.9880299$ and round at the end.

Check: The full circuit operates with probability about 0.988030.
::::
:::

:::problem[Problem 3.29 — Homework 4: both detection systems succeed]{difficulty=easy}
Two inspection systems independently identify a defective part: A succeeds with probability .92, B with .88. If a defective part is tested by both, what is $P(A\cap B)$?

::::solution[Solution]
**Answer:** 0.8096.

1. The question explicitly says independence, so success in system A does not change system B's success probability.
2. Both detecting the defect is an intersection: $P(A\cap B)=0.92\times0.88$.
3. Multiply to obtain 0.8096. The value is below both individual success probabilities, as required because both must succeed.

Check: Both systems correctly identify the same defect with probability 0.8096.
::::
:::

:::problem[Problem 3.30 — Homework 4: neither inspection succeeds]{difficulty=standard}
The two independent systems have detection probabilities .92 and .88. What is the probability neither identifies the defect?

::::solution[Solution]
**Answer:** 0.0096.

1. A fails to detect with chance $1-.92=.08$; B fails with chance $1-.88=.12$.
2. Independence extends to the complements, so $P(A'\cap B')=.08\times.12$.
3. The joint-miss probability is 0.0096. This event is the complement of *at least one detects*, not of *both detect*.

Check: The chance both automated systems miss a defective part is 0.0096.
::::
:::

:::problem[Problem 3.31 — Homework 4: at least one inspection succeeds]{difficulty=standard}
Independent inspectors detect defects with probabilities .92 and .88. A quality engineer claims independence means $P(A\cup B)=P(A)+P(B)$. Calculate the correct $P(A\cup B)$.

::::solution[Solution]
**Answer:** 0.9904.

1. Independence does not make events mutually exclusive; both systems can detect the same defect.
2. Their overlap is $.92\times.88=.8096$. Use the addition formula: $.92+.88-.8096$.
3. The result is 0.9904, also obtained from $1-(.08)(.12)$. The engineer's unsupported addition would give 1.80, which is impossible for a probability.

Check: At least one detection system succeeds with probability 0.9904.
::::
:::

:::problem[Problem 3.32 — SI review: independent intersection]{difficulty=easy}
Events $A$ and $B$ are independent with $P(A)=0.50$ and $P(B)=0.40$. Find $P(A\cap B)$.

::::solution[Solution]
**Answer:** 0.20.

1. Independence is expressly given, so the conditional chance $P(B\mid A)$ equals the marginal chance 0.40.
2. Apply the multiplication rule: $P(A\cap B)=P(A)P(B)=.50\times.40$.
3. The answer is .20. This is an AND probability, not the union, and both events can occur together.

Check: Twenty percent of outcomes satisfy both independent events.
::::
:::

:::problem[Problem 3.33 — SI review: independence of coin flips]{difficulty=standard}
A fair coin is flipped twice. What is the chance both flips show heads?

::::solution[Solution]
**Answer:** 0.25.

1. Each independent fair flip has probability .5 of heads; the first flip does not change the second.
2. Both heads is an intersection, so multiply $.5\times.5=.25$.
3. The full sample space HH, HT, TH, TT also gives one favorable result out of four. For each individual flip, heads has probability .50; the two flips are independent.

Check: The chance of two heads in two independent flips is one quarter.
::::
:::

:::problem[Problem 3.34 — SI review: a conditional under independence]{difficulty=standard}
If $A$ and $B$ are independent, $P(A)=.60$, and $P(B)>0$, calculate $P(A\mid B)$.

::::solution[Solution]
**Answer:** 0.60.

1. The defining feature of independence is that being told B happened does not change A's chance.
2. Consequently $P(A\mid B)=P(A)$ whenever $P(B)>0$.
3. Insert the given marginal probability $P(A)=.60$. No product is required because the question is a conditional and independence already gives its value.

Check: Among B outcomes, the probability of A remains sixty percent.
::::
:::

:::problem[Problem 3.35 — Independence check by an impossible intersection]{difficulty=challenge}
Suppose events $A$ and $B$ are disjoint, with $P(A)=0.30$ and $P(B)=0.40$. What is $P(A\cap B)$?

::::solution[Solution]
**Answer:** 0.00.

1. Disjoint or mutually exclusive events have no common outcomes, so their intersection is the empty set.
2. Therefore $P(A\cap B)=0$, regardless of the particular positive marginal probabilities.
3. But independence would predict $.30\times.40=.12$, not zero. This contradiction proves the two positive-probability events are dependent.

Check: The events cannot occur together, so their overlap probability is zero.
::::
:::

:::callout-pitfall[Series, parallel, and missing independence]
A series circuit needs **all** its required components functioning. A parallel circuit needs **at least one** functioning branch. The first is an AND problem, the second an OR or complement-of-all-fail problem. In the circuit diagrams, some labels are failure probabilities and others are success probabilities; read the wording before multiplying. Finally, three marginal order percentages do **not** identify a triple intersection unless mutual independence, or enough conditional data, is available.
:::

## 3.6 Total Probability: Combining Alternative Sources

Many engineering failures do not come from one uniform population. A semiconductor may have high, medium, or low contamination; a beam may be subjected to one of four load levels; a manufactured product may come from one of three factories. The question asks for the **overall** failure probability before you know which source, category, or load produced the outcome. The only sensible strategy is to split the population into nonoverlapping cases, calculate how often the event occurs inside each case, and add the contributions.

Think of every supplier as a separate production stream. A stream that makes very few products but has a high defect rate can contribute fewer defects than a high-volume stream with a lower rate. This is why the formula multiplies each conditional defect rate by that source's fraction of production. The final total is a weighted average of the conditional rates, weighted by how likely each source is. If the source categories exhaust the whole population, their probabilities add to one. If they do not, you are missing a branch.

The question's verb matters. "What is the probability a random beam fails?" requests total probability. "If it failed, which load probably caused it?" will use Bayes in the next section. Both begin by computing exactly the same weighted failure total. So solve the forward question carefully and reuse that denominator rather than attempting the inverse question from intuition.

:::theorem[Law of total probability for two cases]

$$P(B)=P(B\mid A)P(A)+P(B\mid A')P(A').$$

This is printed on **Final sheet, page 1**, directly below the multiplication rule. $A$ and $A'$ are disjoint and exhaustive, so every occurrence of $B$ comes from exactly one of these two branches.
:::

:::theorem[Total probability for a partition]

For mutually exclusive, exhaustive cases $E_1,\ldots,E_k$ with positive probabilities,

$$P(B)=P(B\mid E_1)P(E_1)+P(B\mid E_2)P(E_2)+\cdots+P(B\mid E_k)P(E_k).$$

This is also on **Final sheet, page 1**. In a worked calculation write out every branch rather than compressing it into sigma notation. The result must be between the smallest and largest conditional event rates when the branch probabilities total one.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 520 205" role="img" aria-label="A two-stage probability tree first selecting a population group then an event">
<text class="fig-label-em" x="12" y="24">Random unit</text><path class="fig-axis" d="M100,100 L220,52 M100,100 L220,154"/><text class="fig-label" x="154" y="51">E₁</text><text class="fig-label" x="152" y="157">E₂</text><path class="fig-axis" d="M220,52 L402,18 M220,52 L402,86"/><path class="fig-axis" d="M220,154 L402,120 M220,154 L402,188"/><text class="fig-label-em" x="410" y="23">B</text><text class="fig-label" x="410" y="86">B’</text><text class="fig-label-em" x="410" y="125">B</text><text class="fig-label" x="410" y="191">B’</text>
</svg>
<figcaption>The two paths ending in event $B$ contribute $P(E_1)P(B\mid E_1)$ and $P(E_2)P(B\mid E_2)$ to the overall probability.</figcaption>
</figure>

:::example[Example 3.54 — Slide: semiconductor contamination, two groups]
Twenty percent of semiconductor chips receive high contamination, with failure probability .10; the other 80% have failure probability .005. Find the overall chip-related product failure probability.

::::answer[Answer]
**Answer:** 0.0240.

1. Split the chip population into High and Not High contamination. Their probabilities are .20 and .80, which total one.
2. A high-contamination chip contributes $.20\times.10=.020$ of all failures. A non-high chip contributes $.80\times.005=.004$.
3. Add the disjoint contributions: $.020+.004=.0240$. The result is not the unweighted average of .10 and .005, because the populations differ in size.

Check: Overall, 2.4 percent of chips lead to the specified product failure.
::::
:::

:::example[Example 3.55 — Slide: three contamination levels]
Chip contamination levels High, Medium, Low occur with probabilities .20, .30, .50 and have failure probabilities .10, .01, .001, respectively. Find overall product failure probability.

::::answer[Answer]
**Answer:** 0.0235.

1. High, Medium, and Low are disjoint and exhaustive because $.20+.30+.50=1$.
2. Calculate the three weighted failure contributions: $.20\times.10=.020$, $.30\times.01=.003$, and $.50\times.001=.0005$.
3. Add $.020+.003+.0005=.0235$. This is a weighted sum of failure rates, not their direct sum $.10+.01+.001$.

Check: The overall chip-related failure chance is 0.0235.
::::
:::

:::example[Example 3.56 — Unit 3 Exercise 8: extended-warranty sales]
A store's paying customers are 40% women and 60% men. Twenty-five percent of paying women and 40% of paying men buy warranties. What is the overall chance a paying customer buys an extended warranty?

::::answer[Answer]
**Answer:** 0.3400.

1. Partition paying customers into Woman (40%) and Man (60%) so every paying customer belongs to one branch.
2. Women who purchase warranties contribute $.40\times.25=.10$; men who purchase contribute $.60\times.40=.24$.
3. Add $.10+.24=.3400$. This is the overall probability of buying a warranty, irrespective of gender.

Check: Thirty-four percent of all paying customers buy an extended warranty.
::::
:::

:::example[Example 3.57 — Unit 3 Exercise 9: steel-beam failure]
Loads of 2000, 3000, 5000, 10000 lb occur with probabilities .4, .3, .2, .1, respectively. Failure probabilities given those loads are .001, .002, .005, .010. Find overall beam failure probability.

::::answer[Answer]
**Answer:** 0.0030.

1. The four load categories are disjoint and their occurrence probabilities sum to one.
2. Calculate each load's contribution to the failure event: $.4(.001)=.0004$, $.3(.002)=.0006$, $.2(.005)=.0010$, $.1(.010)=.0010$.
3. Add $.0004+.0006+.0010+.0010=.0030$. The unit 'lb' identifies loads, but the calculated probability is unitless.

Check: Three beams per thousand fail on average under the stated load mixture.
::::
:::

:::example[Example 3.58 — Exam 1 practice: three rental agencies]
Rental agencies D, E, F supply 60%, 20%, and 20% of cars. The bad-tire rates are 12%, 4%, and 10%, respectively. Find the overall chance that a randomly rented car has bad tires.

::::answer[Answer]
**Answer:** 0.1000.

1. The agency proportions form a partition: $.60+.20+.20=1$.
2. D contributes $.60\times.12=.072$ of all rentals with bad tires; E contributes $.20\times.04=.008$; F contributes $.20\times.10=.020$.
3. Sum $.072+.008+.020=.1000$. This value will become the Bayes denominator in the next section's agency-reversal question.

Check: Ten percent of all rentals have bad tires under this agency mixture.
::::
:::

:::problem[Problem 3.36 — SI review: two-factory defect rate]{difficulty=easy}
Factory A produces 60% of products and has a 2% defect rate; factory B produces 40% and has a 5% defect rate. Find the overall probability a product is defective.

::::solution[Solution]
**Answer:** 0.032.

1. The two factories cover all production, so their probabilities sum to one.
2. Calculate A's contribution $.60\times.02=.012$ and B's contribution $.40\times.05=.020$.
3. Add $.012+.020=.032$. The result lies between .02 and .05, a useful weighted-average check.

Check: The combined defect rate is 3.2 percent of total output.
::::
:::

:::problem[Problem 3.37 — SI review: online versus in-person passing]{difficulty=standard}
Seventy percent of students take a test online, and 30% in person. Pass rates are 80% online and 90% in person. Find the overall probability of passing.

::::solution[Solution]
**Answer:** 0.83.

1. The test modes partition all students because each student uses exactly one mode.
2. Online students who pass contribute $.70\times.80=.56$ of all students. In-person students who pass contribute $.30\times.90=.27$.
3. The total is $.56+.27=.83$. This is between the two conditional pass rates .80 and .90, as a weighted average should be.

Check: Eighty-three percent of all students pass under the described mixture.
::::
:::

:::problem[Problem 3.38 — SI review: three factories]{difficulty=standard}
Factories A, B, C produce 50%, 30%, 20% of units, with defect rates 2%, 3%, 5%, respectively. Find total probability of a defect.

::::solution[Solution]
**Answer:** 0.029.

1. The three production shares total one, so they exhaust output.
2. Compute contributions one at a time: $.50\times.02=.010$, $.30\times.03=.009$, $.20\times.05=.010$.
3. Their sum is $.010+.009+.010=.029$. Do not confuse a factory-specific 5% rate with a 5% contribution to all output.

Check: The combined factories produce defects at a 2.9 percent rate.
::::
:::

:::problem[Problem 3.39 — SI review: athletes and passing]{difficulty=standard}
A university has 40% athletes and 60% non-athletes. Pass rates are 80% among athletes and 65% among non-athletes. Find $P(\text{pass})$.

::::solution[Solution]
**Answer:** 0.71.

1. Separate the student body into athletes and non-athletes; the proportions .40 and .60 total one.
2. The athlete-pass share is $.40\times.80=.32$. The non-athlete-pass share is $.60\times.65=.39$.
3. Add $.32+.39=.71$. The higher athlete-specific pass rate does not imply that most passes come from athletes, since non-athletes are the larger group.

Check: Seventy-one percent of students pass the exam overall.
::::
:::

:::problem[Problem 3.40 — SI review: probability a medical test is positive]{difficulty=challenge}
A condition affects 2% of people. A test is positive for 95% of affected people and 4% of unaffected people. Find the overall probability of testing positive.

::::solution[Solution]
**Answer:** 0.0582.

1. Partition people into condition present (0.02) and condition absent (0.98).
2. True positives contribute $.02\times.95=.019$ of all people. False positives contribute $.98\times.04=.0392$.
3. Sum $.019+.0392=.0582$. Many positives come from the much larger unaffected group even though its false-positive rate is only four percent.

Check: About 5.82 percent of the population receives a positive test.
::::
:::

:::problem[Problem 3.41 — Exam 1 practice: houses and missing assumptions]{difficulty=challenge}
The Starkville market is 20% new homes, 60% with three or more bedrooms, and 75% with two or more bathrooms. **If these three attributes are mutually independent**, what is the probability a home has all three?

::::solution[Solution]
**Answer:** 0.09.

1. The question concerns a triple intersection: new AND at least three bedrooms AND at least two bathrooms.
2. Independence would permit multiplying the three marginal proportions: $.20\times.60\times.75=.09$.
3. However, the source problem does not actually assert independence. Without it, the joint probability is not uniquely determined from those three percentages, so 0.09 is conditional on the extra assumption.

Check: Under mutual independence, nine percent of homes meet all three characteristics.
::::
:::

:::callout-pitfall[A weighted average is not a posterior probability]
The total-probability rule answers "how common is this outcome overall?" Its answer is a sum of branch contributions. It does **not** answer which branch was responsible after you observe the outcome. That reversal requires Bayes. If a source gives merely three marginal percentages, multiplying them as if independent is an unjustified shortcut. State an independence assumption when the original wording is incomplete; record that limitation instead of hiding it.
:::

## 3.7 Bayes’ Theorem: Reversing Conditional Probability

Suppose a beam has failed. You know heavy loads cause failure more often, but heavy loads may be rare. It would be wrong to announce that the failed beam probably faced the highest load simply because that load has the largest failure rate. We need the probability of each load **among failed beams**, which requires two facts: how often the load occurs and how likely it is to cause failure. Bayes' theorem performs exactly that reversal.

The easiest way to think about it is through a table of joint probabilities. Imagine a warehouse of ten thousand manufactured chips. One branch contains high-contamination chips, another contains low-contamination chips. Multiply each branch's population share by its failure rate to find the share of all products that fail inside that branch. Then restrict attention to the failures and ask which branch produced what fraction of those failures. The denominator is the total failure probability found using the previous section's rule. The numerator is one chosen branch's contribution.

Recognize the wording. "Given a defective product, what is the chance it came from supplier 1?" is Bayes. The supplier distribution is the **prior** information before you know the product's condition; a defect likelihood for each supplier says how common evidence is under that source; the posterior probability is the share of the observed-evidence group attributed to the source. The formula is not magical or a separate test distribution: it is conditional probability with the joint numerator rewritten using the multiplication rule. Use a tree diagram when the source categories are more than two.

The distinction also matters with medical-test questions. A highly accurate test can have a surprisingly modest posterior chance for a rare condition because false positives are drawn from a much larger unaffected population. The same logic applies to defects, safety alarms, quality control, and warranty purchases. The conditional probability of evidence given a cause is **not** the probability of the cause given the evidence.

:::theorem[Bayes’ theorem for two events]

$$P(A\mid B)=\frac{P(B\mid A)P(A)}{P(B)},\qquad P(B)>0.$$

This is printed on **Final sheet, page 1**. If $P(B)$ is not supplied, first compute it using total probability over $A$ and $A'$. The numerator is the joint probability that the cause and the observed evidence both occur.
:::

:::theorem[Bayes for several mutually exclusive sources]

$$P(E_i\mid B)=\frac{P(B\mid E_i)P(E_i)}{P(B\mid E_1)P(E_1)+\cdots+P(B\mid E_k)P(E_k)}.$$

This appears on **Final sheet, page 1**. The same total-probability denominator applies to every source. As a check, the posterior probabilities across all disjoint exhaustive source categories must add to one.
:::

:::callout-tip[Three-line Bayes setup on an exam]

Write **prior × likelihood** for the requested source. Below it, add **prior × likelihood for every source**. Finally divide. For a two-way count table with the observed condition on one axis, you can often obtain the same answer directly by dividing the relevant cell by the observed-condition row or column total.
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 560 230" role="img" aria-label="Bayesian contamination tree with high and not high contamination and failure or success">
<rect class="fig-axis" x="16" y="14" width="535" height="198"/><path class="fig-axis" d="M85,101 L210,60 M85,101 L210,153 M210,60 L390,36 M210,153 L390,129"/><path class="fig-guide" d="M210,60 L390,80 M210,153 L390,181"/><text class="fig-label" x="118" y="52">0.20 High</text><text class="fig-label" x="116" y="173">0.80 Not high</text><text class="fig-label-em" x="394" y="42">Fail: .10</text><text class="fig-label" x="394" y="86">Pass: .90</text><text class="fig-label-em" x="394" y="135">Fail: .005</text><text class="fig-label" x="394" y="186">Pass: .995</text>
</svg>
<figcaption>A failed chip could have come from either contamination branch; Bayes divides the chosen branch’s weighted failure probability by the sum of both failure branches.</figcaption>
</figure>

:::example[Example 3.59 — Slide: contamination source given failure]
High-contamination chips are 20% of production with failure rate .10; other chips are 80% with failure rate .005. Given a failure, find the probability the chip had high contamination.

::::answer[Answer]
**Answer:** 0.8333.

1. Prior chance of High contamination is .20; chance of Failure given High is .10. The numerator is $.20\times.10=.020$.
2. Total failure probability combines both causes: $.20(.10)+.80(.005)=.020+.004=.024$.
3. Divide $.020/.024=0.8333$. The posterior is much greater than the prior .20 because High contamination produces failures at a much higher rate.

Check: About 83.33 percent of failed-chip products came from high-contamination chips.
::::
:::

:::example[Example 3.60 — Unit 3 Exercise 13: warranty buyer is a woman]
Forty percent of paying store customers are women. Of women 25% buy warranties; of men 40% buy them. Given that a customer **bought a warranty**, what is the probability the customer is a woman?

::::answer[Answer]
**Answer:** 0.2941.

1. The requested cause is Woman, whose prior probability is .40. The likelihood of Warranty given Woman is .25, so the numerator is $.40\times.25=.10$.
2. The total warranty probability from Exercise 8 is $.40(.25)+.60(.40)=.34$.
3. Divide $.10/.34=0.2941$. Do not answer .25: that is the chance of buying a warranty given the customer is a woman, with the condition reversed.

Check: About 29.41 percent of warranty buyers are women.
::::
:::

:::example[Example 3.61 — Unit 3 Exercise 14: load given beam failure]
Loads 2000, 3000, 5000, 10000 lb have probabilities .4, .3, .2, .1 and corresponding beam-failure rates .001, .002, .005, .010. Given a beam failed, what is the probability its load was 5000 lb?

::::answer[Answer]
**Answer:** 0.3333.

1. The event of a 5000-lb load has prior probability .2 and conditional failure rate .005, yielding joint contribution $.2(.005)=.001$.
2. The total failure probability from Exercise 9 is $.4(.001)+.3(.002)+.2(.005)+.1(.010)=.003$.
3. Divide $.001/.003=0.3333$. The 5000-lb load causes one third of failures despite occurring only one fifth of the time.

Check: One third of failed beams had faced a 5000-lb load.
::::
:::

:::example[Example 3.62 — Exam 1 practice: bad-tire rental from D]
Agency D supplies 60% of rentals with bad-tire rate 12%; E supplies 20% at 4%; F supplies 20% at 10%. Given that a rented car has bad tires, find the probability it came from D.

::::answer[Answer]
**Answer:** 0.72.

1. The D-and-bad-tires joint probability is $.60\times.12=.072$.
2. Every bad-tire source contributes $.072$ from D, $.008$ from E, and $.020$ from F. The total is $.100$.
3. Divide $.072/.100=.72$. The posterior exceeds D's prior .60 because its bad-tire rate is above the overall 10% rate.

Check: Seventy-two percent of rentals with bad tires came from D.
::::
:::

:::example[Example 3.63 — Exam 1 practice: bad-tire rental from E]
D/E/F supply 60%/20%/20% of rentals with bad-tire rates 12%/4%/10%, respectively. Given bad tires, find $P(E\mid\text{bad})$.

::::answer[Answer]
**Answer:** 0.08.

1. Use E's prior .20 and its conditional bad-tire probability .04. The E-and-bad joint chance is $.20\times.04=.008$.
2. The denominator is the same overall bad-tire probability .10 computed using all three agencies.
3. Divide $.008/.10=.08$. The posterior is smaller than E's original 20% market share because E's tires are relatively less likely to be bad.

Check: Eight percent of cars with bad tires came from E.
::::
:::

:::example[Example 3.64 — Exam 1 practice: bad-tire rental from F]
D/E/F supply 60%/20%/20% of rentals with bad-tire rates 12%/4%/10%. Given bad tires, find the probability the car came from F.

::::answer[Answer]
**Answer:** 0.20.

1. The F-and-bad joint chance is $.20\times.10=.020$.
2. Divide by all bad-tire rentals, whose probability is $.072+.008+.020=.10$.
3. The posterior for F is $.020/.10=.20$. Add all three posteriors to check: $.72+.08+.20=1.00$.

Check: Twenty percent of the bad-tire rentals came from F.
::::
:::

:::example[Example 3.65 — Extra credit: Fat Bear Week vote probability]
In Fat Bear Week, 60% of voters are first-time participants and 40% return. Seventy percent of first-time voters and 45% of returning voters vote for Bear A. Find the overall chance of a vote for Bear A.

::::answer[Answer]
**Answer:** 0.60.

1. Split voters into first-time and returning groups, which are mutually exclusive and exhaustive.
2. First-timers voting for Bear A contribute $.60\times.70=.42$; returning voters contribute $.40\times.45=.18$.
3. Add $.42+.18=.60$. This is total probability, needed before the reverse conditional question can be solved.

Check: Sixty percent of the ballots are for Bear A under the given figures.
::::
:::

:::problem[Problem 3.42 — Extra credit: first-time given Bear A vote]{difficulty=standard}
With 60% first-time Fat Bear Week voters and 40% returning voters, and Bear A support rates 70% among first-timers and 45% among returning voters, find $P(\text{first-time}\mid\text{voted A})$. Interpret.

::::solution[Solution]
**Answer:** 0.70.

1. The numerator is the share of all ballots that are both first-time and for Bear A: $.60\times.70=.42$.
2. The denominator is the share of all ballots for Bear A: $.42+.18=.60$.
3. Bayes gives $.42/.60=.70$. Among the voters known to have selected Bear A, 70% are first-time participants. This is not merely the prior 60% first-time share.

Check: Seventy percent of Bear A voters are first-time Fat Bear Week participants.
::::
:::

:::problem[Problem 3.43 — SI review: passing student is an athlete]{difficulty=standard}
Forty percent of students are athletes and 60% non-athletes. Their respective pass rates are .80 and .65. Given a student passed, find the probability the student is an athlete.

::::solution[Solution]
**Answer:** 0.4507.

1. The athlete-and-pass joint probability is $.40\times.80=.32$.
2. The overall probability of passing is $.32+.39=.71$ after including non-athlete passes.
3. Divide $.32/.71=0.4507$. The result is $P(\text{athlete}\mid\text{pass})$, not the 80% conditional pass rate among athletes.

Check: About 45.07 percent of the students who passed are athletes.
::::
:::

:::problem[Problem 3.44 — SI review: checking athlete-pass independence]{difficulty=standard}
A university has $P(\text{athlete})=.40$, $P(\text{pass}\mid\text{athlete})=.80$, and $P(\text{pass})=.71$. Are being an athlete and passing independent?

::::solution[Solution]
**Answer:** No, the events are dependent.

1. Independence would require the pass probability among athletes to equal the overall pass probability.
2. But $P(\text{pass}\mid\text{athlete})=0.80$ and $P(\text{pass})=0.71$ are unequal.
3. Therefore knowing athletic status changes the pass probability and the events are dependent. The reason is the inequality, not merely that an athlete could either pass or fail.

This is the logically correct independence test regardless of the review key wording.

Check: No, the events are dependent
::::
:::

:::problem[Problem 3.45 — SI review: positive test implies condition]{difficulty=challenge}
A condition affects 2% of people. A diagnostic test is positive for 95% of affected people and 4% of unaffected people. Given a positive result, find the probability the person actually has the condition.

::::solution[Solution]
**Answer:** 0.3265.

1. The joint probability of condition AND positive is $.02\times.95=.019$.
2. The overall chance of a positive is $.019+.98(.04)=.019+.0392=.0582$.
3. Divide $.019/.0582=0.3265$. The answer is not 95%; that is sensitivity, which conditions in the opposite direction.

Check: Only about 32.65 percent of positive results come from people with the condition.
::::
:::

:::problem[Problem 3.46 — SI review: freshman given passed]{difficulty=standard}
A school has 100 students: 60 freshmen and 40 sophomores. Of the freshmen 45 passed, and of the sophomores 30 passed. Given a student passed, what is the probability the student is a freshman?

::::solution[Solution]
**Answer:** 0.60.

1. Count the passed students in both years: $45+30=75$.
2. Among the 75 passes, 45 were earned by freshmen. The conditional fraction is $45/75$.
3. Divide to obtain .60. For the other parts of this review problem, $P(\text{pass})=75/100=.75$ and $P(\text{pass}\mid\text{freshman})=45/60=.75$.

Check: Sixty percent of all passing students are freshmen.
::::
:::

:::problem[Problem 3.47 — SI review: Bayes with abstract events]{difficulty=easy}
If $P(A)=.20$, $P(B\mid A)=.80$, and $P(B)=.40$, what is $P(A\mid B)$?

::::solution[Solution]
**Answer:** 0.40.

1. The question reverses the condition, so use Bayes rather than copying the given .80.
2. Compute joint probability $P(A\cap B)=P(A)P(B\mid A)=.20\times.80=.16$.
3. Divide by $P(B)=.40$ to get $.16/.40=.40$. This is the fraction of B outcomes that also came from A.

Check: Forty percent of B outcomes are also in A.
::::
:::

:::problem[Problem 3.48 — SI review: which rule reverses a test?]{difficulty=easy}
A condition affects 10% of people and a test catches 90% of affected people. Which theorem is used to determine the probability of the condition after observing a positive test?

::::solution[Solution]
**Answer:** Bayes’ theorem.

1. The question gives information about test results *given* a condition and asks about the condition *given* the result.
2. Reversing the direction of the conditioning is the defining role of Bayes' theorem.
3. The data given do not include the false-positive rate, so the final numerical posterior cannot yet be calculated. Choosing Bayes as the method is possible even though a complete computation is not.

An accurate theorem name does not compensate for a missing denominator.

Check: Bayes’ theorem
::::
:::

:::callout-pitfall[Reversing the arrow by accident]
A test that detects 95% of truly affected people does not imply 95% of positive tests come from affected people. In Bayes, the original source chance is multiplied by the evidence likelihood. The denominator must include **all routes** to the observed evidence. With several sources, calculate their posterior probabilities using the same denominator and add them; if they do not sum to one, a branch or a probability was mishandled.
:::

## Chapter Summary

:::summary[The rule-selection summary]

Probability begins with a sample space, and the words in the question choose the operation. **OR** means union: $P(A\cup B)=P(A)+P(B)-P(A\cap B)$. **NOT** means complement: $P(A')=1-P(A)$. **GIVEN** means a restricted denominator: $P(B\mid A)=P(A\cap B)/P(A)$. **AND** between sequential events means conditional multiplication: $P(A\cap B)=P(A)P(B\mid A)$. These formulas all appear together on Final page 1.

**Independent** means conditioning on one event does not change the other: $P(B\mid A)=P(B)$. It does not mean disjoint. **Mutually exclusive** means no overlap, so $P(A\cap B)=0$. For circuits, independent components **in series** must all work, and **in parallel** must not all fail.

**Overall across sources** means total probability: add the branch contributions, one term of the form $P(\text{source})P(\text{event}\mid\text{source})$ for each disjoint exhaustive source. **Source given observed outcome** means Bayes: one particular contribution divided by the sum of contributions from all possible sources. Both appear on Final page 1. Do not infer an independent intersection from separate marginal percentages unless independence is stated or justified.

For counting, multiply independent stages. An ordered selection without replacement reduces the number of options after each choice. An unordered group is a combination, calculated using $\binom nr$ on Final page 1. If objects are identical, divide out rearrangements of those identical objects. Draw a short tree or write a sample outcome if the distinction between order and group is unclear.

**Exam checklist:** name the event; decide whether you need a count or probability; record the relevant sample-space or conditional denominator; write out each table cell or probability-tree branch; use the Final sheet’s formula; calculate with parentheses on the TI-30X IIS; then interpret the result as a sentence about the original event. An answer outside $[0,1]$ is impossible for a probability, and a total-probability weighted average must lie between the component rates.
:::

## Mixed Practice

This set is formatted as an abbreviated final-exam slice: a three-part true/false item, a matching item, and twelve multiple-choice items. The real comprehensive final has 23 items across all units: one true/false with three parts, one matching with four parts, and 21 multiple-choice questions. The mixed selection below isolates Unit 3 while preserving the instructor's short decision-and-computation style. Attempt the question first, then expand its solution. The questions mix topics deliberately, because the final does not announce the rule to use.

:::problem[Problem M.1 — True/false: relationships among events]{difficulty=standard}
Mark each statement true or false. (a) Two mutually exclusive positive-probability events are independent. (b) $P(A\cup B)$ includes outcomes in both events. (c) Conditional probability changes the denominator to the event after the vertical bar.

::::solution[Solution]
**Answer:** (a) false, (b) true, (c) true.

1. Statement (a) is false. Mutually exclusive events with positive probabilities have intersection probability zero, while independence would require the positive product of their probabilities.
2. Statement (b) is true. Statistical OR is inclusive, so the overlap belongs to the union, although it must be subtracted once when adding probabilities.
3. Statement (c) is true. $P(A\mid B)=P(A\cap B)/P(B)$ restricts the denominator to B outcomes, which is the entire point of conditioning.

The three ideas can be checked with a two-circle Venn diagram and the conditional formula on Final page 1.

Check: (a) false, (b) true, (c) true
::::
:::

:::problem[Problem M.2 — Matching: name the operation]{difficulty=easy}
Match each phrase to its rule: (a) "either factory has a failure", (b) "a failure occurred, which supplier made it?", (c) "chance of a defect across all suppliers", (d) "both independent sensors detect it". Options: **I** intersection product, **II** union, **III** total probability, **IV** Bayes.

::::solution[Solution]
**Answer:** (a) II, (b) IV, (c) III, (d) I.

1. 'Either' is inclusive OR, which corresponds to a union and thus option II for (a).
2. The source **given** the observed failure reverses conditional direction, so (b) is Bayes, option IV. The overall probability across disjoint suppliers is total probability, making (c) option III.
3. The word 'both' asks for an intersection; the statement supplies independence, so multiply the two detection rates. Thus (d) matches option I.

Notice how the wording alone determines the method before a single number is used.

Check: (a) II, (b) IV, (c) III, (d) I
::::
:::

:::problem[Problem M.3 — MC: supplier complement]{difficulty=easy}
A supplier table lists 22 conformed and 8 nonconformed from supplier 1; the other suppliers account for 70 samples, for 100 total. Let $A$ mean supplier 1. Find $P(A')$.

(A) 0.22  (B) 0.30  (C) 0.70  (D) 0.78

::::solution[Solution]
**Answer:** (C) 0.70.

1. Supplier 1 contributed 22+8=30 of 100 samples, so $P(A)=.30$.
2. Use the complement rule printed on Final page 1: $P(A')=1-.30$.
3. That is .70, matching choice C. Equivalently the 70 samples from suppliers 2 and 3 form the entire complement of supplier 1.

Check: Seventy percent of samples came from a supplier other than supplier 1.
::::
:::

:::problem[Problem M.4 — MC: three-digit no-replacement arrangements]{difficulty=standard}
Digits 0–9 form three-digit codes with no repeated digit, and a leading zero is allowed. How many codes exist?

(A) 1000  (B) 720  (C) 120  (D) 90

::::solution[Solution]
**Answer:** (B) 720.

1. There are ten choices for the first digit, including zero.
2. No replacement or repetition means nine choices for the second and eight for the third; multiply $10\times9\times8$.
3. The result 720 is choice B. Answer A assumes replacement; the other options do not count all ordered triples.

Check: There are 720 valid no-repeat code sequences.
::::
:::

:::problem[Problem M.5 — MC: manufacturing union]{difficulty=standard}
In a survey $P(A)=.45$, $P(B)=.35$, and $P(A\cap B)=.18$. Find $P(A\cup B)$.

(A) .80  (B) .28  (C) .18  (D) .62

::::solution[Solution]
**Answer:** (D) 0.62.

1. The question is OR, so start with the union rule $P(A\cup B)=P(A)+P(B)-P(A\cap B)$.
2. Substitute $.45+.35-.18$ to avoid counting the overlap twice.
3. The result .62 matches choice D. Choice A fails to subtract the overlap, while choice C reports only the intersection.

Check: Sixty-two percent of cases meet at least one event.
::::
:::

:::problem[Problem M.6 — MC: conditional table orientation]{difficulty=standard}
A sample has Electrical Yes/Gas Yes = 55 and Electrical No/Gas Yes = 32. Find $P(\text{electrical}\mid\text{gas})$.

(A) .6322  (B) .7639  (C) .5140  (D) .8131

::::solution[Solution]
**Answer:** (A) 0.6322.

1. Condition on Gas Yes: use the entire gas-yes column containing 55+32=87 records.
2. The electrical-and-gas intersection is the cell 55.
3. Compute $55/87=.6322$, choice A. Choice B reverses the condition and uses the electrical-yes row denominator.

Check: About 63.22 percent of gas-leak failures also show electrical evidence.
::::
:::

:::problem[Problem M.7 — MC: disjoint versus independent]{difficulty=easy}
$A,B$ are mutually exclusive and $P(A)=.20,P(B)=.50$. What is $P(A\cap B)$?

(A) .70  (B) .10  (C) .00  (D) .30

::::solution[Solution]
**Answer:** (C) 0.00.

1. Mutually exclusive events have an empty intersection by definition.
2. The intersection probability is zero even though both marginal probabilities are positive.
3. Choice C is correct. Multiplying .20 by .50 would be permitted only if the events were independent, which cannot be the case for positive-probability disjoint events.

Check: The two events cannot happen together.
::::
:::

:::problem[Problem M.8 — MC: weighted failure across factories]{difficulty=standard}
Factories A and B make .70 and .30 of units, with defect rates .01 and .04. Find overall defect probability.

(A) .025  (B) .019  (C) .050  (D) .012

::::solution[Solution]
**Answer:** (B) 0.019.

1. Split output into the two factories, since their shares total one.
2. Multiply each share by its own defect rate: $.70(.01)=.007$ and $.30(.04)=.012$.
3. Add $.007+.012=.019$, choice B. A simple average would ignore the unequal production percentages.

Check: The combined production defect rate is 1.9 percent.
::::
:::

:::problem[Problem M.9 — MC: three-way overlap correction]{difficulty=challenge}
Suppose $P(A)=.20$, $P(B)=.30$, $P(C)=.40$, pairwise intersections $P(A\cap B)=.05$, $P(A\cap C)=.06$, $P(B\cap C)=.07$, and triple intersection $P(A\cap B\cap C)=.02$. Find the union.

(A) .74  (B) .90  (C) .76  (D) .72

::::solution[Solution]
**Answer:** (A) 0.74.

1. Add the three marginals: $.20+.30+.40=.90$.
2. Subtract the three pairwise overlaps: $.90-.05-.06-.07=.72$.
3. The triple overlap was subtracted too many times, so add it back: $.72+.02=.74$. This is choice A and matches the three-event rule on Final page 1.

Check: Seventy-four percent of outcomes belong to at least one of the three events.
::::
:::

:::problem[Problem M.10 — MC: conditional probability from a percentage table]{difficulty=standard}
In a study, $P(\text{red})=.35$ and $P(\text{red and 2 passengers})=.08$. Find $P(\text{2 passengers}\mid\text{red})$.

(A) .0800  (B) .3500  (C) .2286  (D) .4300

::::solution[Solution]
**Answer:** (C) 0.2286.

1. The conditional denominator is $P(\text{red})=.35$, not one.
2. The numerator is the joint probability that the car is red and has two passengers, .08.
3. Divide $.08/.35=.2286$, choice C. The answer is a proportion within red cars, not a percentage of every observed vehicle.

Check: About 22.86 percent of red cars carry two passengers.
::::
:::

:::problem[Problem M.11 — MC: parallel components]{difficulty=standard}
Two independent parallel components each function with probability .90. Find system operating probability.

(A) .8100  (B) .9900  (C) .9000  (D) .1000

::::solution[Solution]
**Answer:** (B) 0.9900.

1. A parallel pair fails only if both paths fail.
2. Each component fails with probability .10; both fail with probability $.10\times.10=.01$ by independence.
3. Subtract from one to get $.99$, choice B. The series product $.90\times.90=.81$ is the wrong topology.

Check: The redundant circuit works on 99 percent of trials.
::::
:::

:::problem[Problem M.12 — MC: reverse the rental-car condition]{difficulty=standard}
Agency D supplies .60 of rentals with bad-tire rate .12, while agencies E and F each supply .20 with rates .04 and .10. Given bad tires, what fraction came from D?

(A) .60  (B) .12  (C) .10  (D) .72

::::solution[Solution]
**Answer:** (D) 0.72.

1. The joint D-and-bad probability is $.60\times.12=.072$.
2. The overall bad-tire denominator is $.072+.008+.020=.100$ from all three agencies.
3. Dividing $.072/.100$ gives .72, choice D. The prior agency share .60 alone ignores the evidence that the tire is bad.

Check: Seventy-two percent of bad-tire rentals came from D.
::::
:::

:::problem[Problem M.13 — MC: faulty detector pair]{difficulty=standard}
Two independent inspection systems have defect-detection probabilities .92 and .88. What is the chance neither detects a defective part?

(A) .0096  (B) .1904  (C) .9904  (D) .8096

::::solution[Solution]
**Answer:** (A) 0.0096.

1. Take complements of both detection events: system A misses with .08, system B with .12.
2. Neither detects means both misses occur, and their independence permits multiplication $.08\times.12$.
3. The answer is .0096, choice A. The complement .9904 is the probability that at least one detector succeeds, not neither.

Check: Both systems miss the same defect with probability 0.0096.
::::
:::

:::problem[Problem M.14 — MC: Bayes with an uncommon condition]{difficulty=challenge}
A condition affects .02 of people; a test detects .95 of affected people and falsely flags .04 of unaffected people. Given a positive test, find the chance of the condition.

(A) .9500  (B) .0200  (C) .3265  (D) .0582

::::solution[Solution]
**Answer:** (C) 0.3265.

1. Calculate the true-positive branch: $.02(.95)=.019$.
2. Calculate false-positive branch: $.98(.04)=.0392$; these are disjoint, so total positives equal $.0582$.
3. Divide $.019/.0582=.3265$, choice C. The sensitivity .95 and the prior .02 alone are not the posterior probability.

Check: About 32.65 percent of positive tests belong to people with the condition.
::::
:::

