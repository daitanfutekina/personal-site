---
title: "Export Templates & Platform Targets"
source: "godot_ch64_export.html"
---

Part XI · Chapter 64

# Export Templates & Platform Targets

Estimated study time: 90 min · Godot 4.x · Editor + CLI

## Chapter Overview

When you press Play in the editor, Godot runs your project using the editor's own runtime.
 Shipping to players means packaging your game with a standalone **export template**
 — a pre-compiled Godot runtime for the target platform — and an **export preset**
 that controls what resources to include, what features to enable, and how to sign the binary.
 This chapter walks through every major platform: Windows, macOS, Linux, Web (HTML5),
 Android, and iOS.

:::callout-tip[Prerequisites]
A working Godot 4 project. Platform-specific tools (Xcode, Android SDK) only needed
  for those targets.
:::

## Export Templates

:::callout-intuition[Intuition]
The Godot editor is a development tool — it's huge and unsuitable for distribution.
  An export template is a stripped-down Godot runtime compiled only for a specific OS.
  Your exported game is: export template (the engine) + your packed project data (PCK file).
:::

### Installing Export Templates

1. In the editor: **Editor → Export → Download and Install**, or
2. **Editor → Manage Export Templates → Download**.
3. This downloads the official templates for the *exact* Godot version you're running. Templates from a different version won't work.
4. For custom builds (GDExtension, stripped features), you must compile export templates from source — see the Godot docs on *Compiling*.

### Debug vs Release Templates

| Template mode | Includes | Use for |
| --- | --- | --- |
| **Debug** | Full debug info, GDScript line numbers, remote debugger connection | Beta testing, profiling |
| **Release** | Stripped symbols, `assert()` removed, no remote debugger | Final shipping builds |

:::callout-warning[Always Test Both]
Release builds behave differently from debug:

assert()

is removed, some
  error messages disappear, and GDScript runs faster. Test your release build before
  uploading to stores — bugs can hide in debug but surface in release.
:::

## Export Presets

Open **Project → Export**. Click *Add* and choose a platform. Each
 preset has several tabs:

| Tab | What to configure |
| --- | --- |
| Options | Binary name, version string, icons, features, embed PCK |
| Resources | Which assets to include or exclude (filters) |
| Script | Script encryption key (optional, protects GDScript from extraction) |
| Platform-specific | Signing, entitlements, permissions, orientation |

### Resource Inclusion Filters

By default Godot includes all files recognized as Godot resources. Use the
 **Resources** tab to add exclusion filters:

- `*.psd` — exclude Photoshop source files
- `*.blend` — exclude Blender source files
- `design/*` — exclude entire design asset folder
- `*.md` — exclude readme/documentation files

Also use **Export Mode**: choose *Export all resources in the project*
 (safe default) or *Export selected scenes and dependencies* (smaller builds, but
 you must list every root scene explicitly).

:::callout-pitfall[Missing Resources at Runtime]
If you use

selected scenes

mode and forget to add a scene that is loaded
  dynamically via string path (

load("res://levels/world2.tscn")

), the build will
  silently exclude it and crash at runtime. Always add dynamically-loaded scenes to the
  include list manually.
:::

## Windows Export

Windows is the simplest target — no code signing is *required* (though unsigned
executables trigger SmartScreen warnings for new players).

1. Add a **Windows Desktop** preset.
2. Set *Application Name* and *Version* in Options.
3. Add a `.ico` icon (256×256 minimum; Windows uses multi-size ICO).
4. Click **Export Project** → choose a folder → Godot outputs `game.exe` + `game.pck`.

:::callout-tip[Embed PCK]
Enable

Embed PCK

in Options to merge the PCK into the EXE — you get a single

game.exe

file. Easier to distribute but slightly larger. Good for itch.io.
:::

#### Code Signing (optional but recommended)

Without signing, Windows shows "Windows protected your PC" when players run your game.
 To sign, you need a code-signing certificate from a CA (costs ~$100–400/yr) or a
 self-signed certificate (free but players still see a warning). Sign with `signtool.exe`:

```bash
signtool sign /fd SHA256 /a /n "Your Name" /t http://timestamp.digicert.com game.exe
```

## macOS Export

macOS requires code signing and notarization for distribution outside the App Store.
 Without it, Gatekeeper blocks the app and users see "can't be opened because Apple
 cannot check it for malicious software."

1. Add a **macOS** preset. Godot exports a `.dmg` or `.zip` containing a `.app` bundle.
2. In the **Application** tab: fill in Bundle Identifier (e.g. `com.yourname.gamename`), Version, and icon (`.icns` format).
3. For code signing: set *Codesign* → *Identity* to your Apple Developer certificate name.
4. For notarization: use `xcrun notarytool` after export (requires paid Apple Developer account, $99/yr).

```bash
# Notarize after exporting
xcrun notarytool submit game.dmg \
    --apple-id "you@example.com" \
    --team-id  "ABCDE12345" \
    --password "@keychain:AC_PASSWORD" \
    --wait

# Staple ticket to the DMG
xcrun stapler staple game.dmg
```

:::callout-tip[Free Distribution Workaround]
For itch.io or small audiences, instruct players to right-click the .app → Open → Open
  anyway. This bypasses Gatekeeper once. Not suitable for Steam or the App Store.
:::

## Linux Export

Linux export produces a self-contained executable. No signing required. Players may
 need to `chmod +x game.x86_64` before running.

1. Add a **Linux/X11** preset. Choose architecture (x86\_64 is standard; arm64 for Raspberry Pi, etc.).
2. Export → outputs `game.x86_64` + `game.pck`.
3. For Flatpak/Snap distribution, you need additional manifest files — beyond this chapter's scope.

```bash
# Distribute as a zip:
zip game_linux.zip game.x86_64 game.pck
# Player runs: chmod +x game.x86_64 && ./game.x86_64
```

## Web (HTML5) Export

The Web export runs in a browser using WebAssembly. It's great for game jams and demos
 but has constraints: no file system access (use `user://` via IndexedDB),
 SharedArrayBuffer required for threads, and CORS headers must be set for hosting.

1. Add a **Web** preset.
2. If your game uses threads (WorkerThreadPool), enable *Extensions Support* and ensure your server sends the required headers.
3. Export → outputs `index.html`, `index.js`, `index.wasm`, `index.pck`.
4. Upload all files to a static host (itch.io, GitHub Pages, Netlify).

#### Required CORS Headers for Threads

```apache
# .htaccess for Apache
Header set Cross-Origin-Opener-Policy "same-origin"
Header set Cross-Origin-Embedder-Policy "require-corp"
```

```javascript
// Netlify netlify.toml
[[headers]]
  for = "/*"
  [headers.values]
    Cross-Origin-Opener-Policy = "same-origin"
    Cross-Origin-Embedder-Policy = "require-corp"
```

:::callout-warning[Web Limitations]
- No native file dialogs — use `JavaScriptBridge` for file input/output
- Audio requires user interaction before playing (browser autoplay policy)
- Performance is ~30–50% lower than native due to WebAssembly overhead
- No ENet — use WebSocket for multiplayer on Web
:::

## Android Export

Android export produces an APK (sideload) or AAB (Google Play). Requires the Android SDK
 and a Java keystore for signing.

#### One-Time Setup

1. Install Android Studio and the Android SDK (API 33+ recommended).
2. In Godot Editor Settings → Export → Android: set SDK path.
3. Create a signing keystore: `keytool -genkey -v -keystore my.keystore -alias mykey -keyalg RSA -keysize 2048 -validity 10000`
4. In the Android export preset → *Keystore* tab: point to your keystore and enter the alias/passwords.

#### Per-Export Steps

1. Add an **Android** preset. Set *Package Name* (e.g. `com.yourname.gamename`).
2. Add required permissions in the *Permissions* tab (e.g. VIBRATE, INTERNET for networking).
3. Export → choose *APK* for sideloading or *AAB* for Play Store upload.

```gdscript
## Runtime Android checks
func _ready() -> void:
    if OS.get_name() == "Android":
        # Adjust UI for touch
        $VirtualJoystick.visible = true
        # Request runtime permission (Android 6+)
        if not OS.has_feature("android"):
            return
        OS.request_permission("WRITE_EXTERNAL_STORAGE")
```

## iOS Export

iOS requires macOS + Xcode for the final build step. Godot exports an Xcode project
 which you then compile and sign with your Apple Developer account.

1. Add an **iOS** preset. Set Bundle ID and Version.
2. Export → outputs an Xcode project folder (`game.xcodeproj` + source files).
3. Open in Xcode → set Signing Team → Archive → Distribute App.
4. For TestFlight/App Store: use Transporter or Xcode's organizer to upload.

:::callout-pitfall[Watch Out For]
iOS does not support GDScript JIT — all scripts are AOT compiled. This is automatic
  in Godot 4 but means you cannot use

eval()

-style runtime code generation.
:::

## Platform Detection at Runtime

Use `OS.get_name()` and `OS.has_feature()` to branch on platform:

```gdscript
func _ready() -> void:
    var platform := OS.get_name()
    match platform:
        "Windows":
            _setup_windows()
        "macOS":
            _setup_macos()
        "Linux", "FreeBSD", "NetBSD", "OpenBSD", "BSD":
            _setup_linux()
        "Android":
            _setup_android()
        "iOS":
            _setup_ios()
        "Web":
            _setup_web()

func _setup_android() -> void:
    # Show virtual gamepad, increase UI touch targets, etc.
    $TouchControls.visible = true
    theme.default_font_size = 20   # larger for phone screens

func _setup_web() -> void:
    # Reduce quality for browser performance
    RenderingServer.set_default_clear_color(Color.BLACK)
    ProjectSettings.set_setting("rendering/scaling_3d/scale", 0.75)
```

`OS.has_feature()` checks export features (you can define custom ones in the preset):

```gdscript
if OS.has_feature("demo"):
    $DemoOverlay.visible = true
    max_level = 3   # demo is locked to 3 levels

if OS.has_feature("standalone"):
    # Running as exported binary (not in editor)
    _disable_editor_shortcuts()

if OS.is_debug_build():
    $DebugOverlay.visible = true
```

## Command-Line Export & CI

Godot can export headlessly — no GUI required. This enables automated builds in CI/CD
 pipelines (GitHub Actions, GitLab CI, etc.):

```bash
# Export Windows preset named "Windows Desktop" to ./builds/
godot --headless --export-release "Windows Desktop" ./builds/game.exe

# Export Web to ./builds/web/
godot --headless --export-release "Web" ./builds/web/index.html

# Export debug build
godot --headless --export-debug "Linux/X11" ./builds/game.x86_64
```

#### GitHub Actions Example

```yaml
## .github/workflows/export.yml
name: Export Godot Game

on:
  push:
    tags: ['v*']

jobs:
  export:
    runs-on: ubuntu-latest
    container:
      image: barichello/godot-ci:4.2.2   # community Docker image with Godot + templates
    steps:
      - uses: actions/checkout@v4

      - name: Export Windows
        run: |
          mkdir -p builds/windows
          godot --headless --export-release "Windows Desktop" builds/windows/game.exe

      - name: Export Web
        run: |
          mkdir -p builds/web
          godot --headless --export-release "Web" builds/web/index.html

      - name: Upload to itch.io
        run: butler push builds/web your-name/your-game:web
        env:
          BUTLER_API_KEY: ${{ secrets.BUTLER_API_KEY }}
```

**butler** is itch.io's CLI upload tool. Install via
 `pip install itch-butler` or download from itch.io.

:::summary
### Chapter 64 — Quick Reference

| Platform | Output | Signing required? | Extra tools |
| --- | --- | --- | --- |
| Windows | .exe + .pck (or embedded) | Optional (SmartScreen) | signtool (optional) |
| macOS | .dmg / .app bundle | Yes (notarization for public) | Xcode, Apple Developer account |
| Linux | .x86\_64 + .pck | No | None |
| Web | .html + .js + .wasm + .pck | No | CORS headers on server |
| Android | .apk / .aab | Yes (keystore) | Android Studio + SDK |
| iOS | Xcode project | Yes (Apple Developer) | macOS + Xcode |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Export Template vs Preset

What is the difference between an export *template* and an export *preset*?
 Why do you need both to ship a game?

::::solution[Solution]
An **export template** is the pre-compiled Godot runtime for a target platform
 (e.g., a Windows x86\_64 binary). It is the engine itself, stripped of editor tools.
 You download templates from Godot's servers — they are the same for every project.

An **export preset** is your project-specific configuration: which resources
 to include, the app name/version, signing credentials, and platform options. It is stored
 in your project's `export_presets.cfg`.

You need both because: the template provides the runtime that executes the game, and the
 preset packages your specific project data (PCK) with the correct settings for that platform.
::::
:::

:::problem{difficulty="easy"}
#### 2. Resource Inclusion Filters

Your project has a `design/` folder with Photoshop files, a `docs/`
 folder with Markdown files, and `*.blend` files scattered through the project.
 Write the three filter strings to exclude all of these from the export.

::::solution[Solution]
In the export preset → Resources tab → Exclude Filters:

- `design/*`
- `docs/*`
- `*.blend`

You could also add `*.psd` if Photoshop files appear elsewhere, and
 `*.md` for any stray Markdown files outside `docs/`.
::::
:::

:::problem{difficulty="standard"}
#### 3. Platform-Adaptive UI

Write a `_ready()` function in a root autoload that:
 (a) shows a virtual joystick on Android and iOS,
 (b) enables a higher quality rendering scale on desktop,
 (c) shows a "beta" watermark label if the custom export feature "beta" is active.

::::solution[Solution]
```gdscript
## PlatformSetup.gd (autoload)
extends Node

func _ready() -> void:
    var platform := OS.get_name()

    # (a) Touch controls for mobile
    var is_mobile := platform in ["Android", "iOS"]
    var touch_ui := get_tree().get_first_node_in_group("touch_controls")
    if touch_ui:
        touch_ui.visible = is_mobile

    # (b) Higher render scale on desktop
    if not is_mobile and platform != "Web":
        ProjectSettings.set_setting("rendering/scaling_3d/scale", 1.0)
    else:
        ProjectSettings.set_setting("rendering/scaling_3d/scale", 0.75)

    # (c) Beta watermark
    if OS.has_feature("beta"):
        var label := get_tree().get_first_node_in_group("beta_label")
        if label:
            label.visible = true
```
::::
:::

:::problem{difficulty="standard"}
#### 4. CI Export Command

Write the two Godot command-line commands to (a) export a release Windows build
 to `./dist/windows/game.exe` and (b) export a debug Web build to
 `./dist/web/index.html`, assuming the presets are named
 "Windows Desktop" and "Web" respectively.

::::solution[Solution]
```bash
# (a) Release Windows build
godot --headless --export-release "Windows Desktop" ./dist/windows/game.exe

# (b) Debug Web build
godot --headless --export-debug "Web" ./dist/web/index.html
```

Note: `--headless` prevents a display window from opening on the CI server.
 The export preset name must match exactly (case-sensitive).
::::
:::

:::problem{difficulty="challenge"}
#### 5. Debug vs Release Differences

List four specific behavioural differences between a debug export and a release export
 in Godot 4, and for each explain one scenario where the difference could cause a bug
 that only appears in the release build.

::::solution[Solution]
1. **assert() is stripped.** An `assert(health >= 0)` guard that
 prevented negative health in debug is gone in release. A bug that sets health to -1 now
 silently corrupts game state instead of crashing loudly.
2. **No remote debugger.** You cannot attach the Godot editor to a release
 build. If a crash only occurs after 20 minutes of play in release, you must instrument
 the code with file logging (`Log.e()`) ahead of time — there's no interactive debugger.
3. **GDScript runs faster (no line-tracking).** Some race conditions or
 timing bugs that were invisible in debug (due to slightly slower execution) surface in
 release where frames complete faster. A coroutine that depended on a certain frame order
 may break.
4. **push\_error() still fires but errors tab is not visible.** In release,
 `push_error()` messages don't reach a debugger. A nil-object access that was
 caught and logged in debug silently skips the error handler in release, causing incorrect
 game logic instead of a visible error.

**Best practice:** always do a full playthrough of your release build before
 shipping, and use file logging for error capture in release.
::::
:::
