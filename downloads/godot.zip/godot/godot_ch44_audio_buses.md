---
title: "Audio Buses, Effects & Mixing"
source: "godot_ch44_audio_buses.html"
---

Part VI · Chapter 44

# Audio Buses, Effects & Mixing

Part VI — Audio · est. 65 min · covers AudioBusLayout, every AudioEffect with all properties, AudioServer runtime control, and practical mixing recipes

## Overview

Raw audio from player nodes sounds flat and identical. Audio buses let you group sounds, apply professional effects (reverb, EQ, compression), and control the overall mix — all without touching a single player script. This chapter teaches the bus model from first principles, documents every AudioEffect Godot provides, and shows how to manipulate buses at runtime for dynamic mixing: pausing music during menus, lowering SFX in cutscenes, applying an underwater filter when submerged.

:::callout-key[Prerequisite]
Ch 43 — AudioStreamPlayer nodes; the `bus` property on every player node routes its output to a bus defined here.
:::

## 1 · The Bus Model — Signal Flow

:::callout-intuition[Intuition]
Think of buses like a mixing desk. Individual players are channel strips feeding into buses. Each bus has a volume fader, a mute button, and a chain of effect inserts. Buses can feed into other buses. Everything ultimately reaches **Master**, whose output goes to the audio hardware. This routing means you can adjust all music volume with one property, mute all SFX at once, or apply reverb to everything in the "Cave" bus.
:::

```text
AudioStreamPlayer  (bus="SFX")  ─┐
AudioStreamPlayer2D(bus="SFX")  ─┤─→  SFX Bus  (vol, compressor)  ─→  Master Bus  ─→  speakers
AudioStreamPlayer  (bus="Music")─→  Music Bus (vol, EQ)            ─┘
AudioStreamPlayer  (bus="Voice")─→  Voice Bus (vol, EQ)            ─→  Master Bus
```

Audio Bus Routing — Typical Game Layout

ASP (bus="Music") ♪

ASP2D (bus="SFX") 💥

ASP2D (bus="SFX") 👣

ASP (bus="Voice") 🗣

Music Bus

EQ + volume

SFX Bus

Compressor + Limiter

volume

Voice Bus

Compressor + EQ

MASTER

Limiter + volume

cannot be removed

🔊

ASP = AudioStreamPlayer   ASP2D = AudioStreamPlayer2D

Each bus: send = its "bus" property pointing to next bus in chain

A typical game audio bus layout. Players route to named buses; buses route into Master. Adjust one bus volume to affect all sounds feeding into it.

## 2 · AudioBusLayout — Creating & Saving Your Mix

### In the editor

Open the **Audio** panel (bottom bar). You'll see the Master bus. Click *Add Bus* to create more. For each bus: name it (double-click the label), set its *Send* destination (usually Master), set volume, toggle Mute/Solo while testing, and click *Add Effect* to insert processors.

Save the layout: floppy disk icon → `res://audio_buses.tres`. Reference it in *Project Settings → Audio → Buses → Default Bus Layout* so it loads automatically.

### Typical game bus layout

| Bus | Sends to | Typical effects | What routes here |
| --- | --- | --- | --- |
| Master | Hardware | Limiter, Compressor | All other buses |
| Music | Master | EQ low-shelf cut (reduce mud) | Background music players |
| SFX | Master | Compressor (even out loud/quiet effects) | In-world sound effects |
| Voice | Master | EQ presence boost | Narrator, character dialogue |
| Ambient | Master | Reverb (large room) | Wind, rain, background hum |
| UI | Master | none | Menu clicks, notifications |

### AudioBusLayout in code

```gdscript
# Load a saved layout at runtime (e.g. for accessibility presets)
func load_mix_preset(path: String) -> void:
    AudioServer.set_bus_layout(load(path) as AudioBusLayout)

# Snapshot the current live layout and save it
func save_current_mix(path: String) -> void:
    ResourceSaver.save(AudioServer.generate_bus_layout(), path)
```

## 3 · AudioEffect Catalogue

:::callout-intuition[Intuition]
AudioEffects run in-order on a bus (left → right)

IN

Compressor

controls dynamics

EQ

shapes tone

Reverb

adds space

Limiter

prevent clipping

OUT

Order matters — swap Reverb↔Limiter and the reverb tail can clip the limiter

AudioEffects process signal left-to-right in the order they appear in the bus. Drag effects up/down in the editor to reorder them.

An AudioEffect is a processor inserted into a bus chain. Effects run in series — signal passes through effect 1, then effect 2, and so on. Order matters: a compressor before a reverb sounds different from reverb before a compressor. Each effect has an `enabled` toggle you can flip at runtime.
:::

| Class | Category | What it does |
| --- | --- | --- |
| `AudioEffectReverb` | Space | Simulates room acoustics — adds wetness and decay tail |
| `AudioEffectDelay` | Space | Echo — discrete repeating copies of the signal |
| `AudioEffectChorus` | Modulation | Detuned copies mixed in — widening, lush effect |
| `AudioEffectPhaser` | Modulation | Sweeping notch filter — swirling phase effect |
| `AudioEffectCompressor` | Dynamics | Reduces dynamic range — brings loud and quiet closer |
| `AudioEffectLimiter` | Dynamics | Hard ceiling — prevents clipping above a set dB level |
| `AudioEffectAmplify` | Dynamics | Simple volume gain stage (positive or negative dB) |
| `AudioEffectEQ6 / EQ10 / EQ21` | EQ | 6, 10, or 21-band equaliser |
| `AudioEffectFilter` | Filter | Configurable single filter: LowPass, HighPass, BandPass, Notch, Peak, LowShelf, HighShelf, BandLimit |
| `AudioEffectLowPassFilter` | Filter | Quick low-pass — muffled/underwater effect |
| `AudioEffectHighPassFilter` | Filter | Quick high-pass — thin/tinny/radio effect |
| `AudioEffectBandPassFilter` | Filter | Passes only a mid-frequency band |
| `AudioEffectNotchFilter` | Filter | Removes a narrow band — hum removal |
| `AudioEffectDistortion` | Distortion | Wave clipping / drive — harmonic saturation or crunch |
| `AudioEffectPitchShift` | Pitch | Pitch without speed change — harmoniser, octave effects |
| `AudioEffectStereoEnhance` | Stereo | Widens or narrows the stereo image |
| `AudioEffectPanner` | Stereo | Pans the bus signal left or right |
| `AudioEffectCapture` | Utility | Records bus signal to a buffer for analysis |
| `AudioEffectRecord` | Utility | Records bus output to AudioStreamWAV at runtime |
| `AudioEffectSpectrumAnalyzer` | Utility | FFT spectrum data for visualisers |

## 4 · Reverb & Delay — Adding Space

### AudioEffectReverb — all properties

| Property | Range | What it does |
| --- | --- | --- |
| room\_size | 0–1 | Simulated room size. 0 = tiny closet; 1 = cathedral. |
| damping | 0–1 | High-frequency absorption. 0 = bright (tile room); 1 = muffled (carpeted room). |
| spread | 0–1 | Stereo width of the reverb tail. 1 = wide lush stereo. |
| predelay\_msec | 0–500 | Milliseconds before reverb starts. 20–40 ms is realistic for most rooms. |
| predelay\_feedback | 0–1 | How much early reflections feed back — adds "slap". |
| hipass | 0–1 | High-pass the reverb input — reduces low-end mud buildup. |
| wet | 0–1 | Reverb send level. 0 = dry; 1 = full reverb. |
| dry | 0–1 | Original dry signal level mixed through. Keep at 1 unless you want only the tail. |

:::callout-tip[Tip — wet/dry on bus vs. a send bus]
Putting Reverb directly on your SFX bus (`wet=0.3, dry=1`) gives all SFX the same reverb. For more control, create a dedicated "SFX Reverb" send bus with `wet=1, dry=0` and route only selected players to it — the professional DAW approach.
:::

### AudioEffectDelay — all properties

| Property | What it does |
| --- | --- |
| dry | Dry (original) signal level through this effect. |
| tap1\_active / tap2\_active | Enable the first / second delay tap. |
| tap1\_delay\_ms | Delay time in ms (0–1500). Second tap creates double echo or ping-pong. |
| tap1\_level\_db | Volume of the repeat. |
| tap1\_pan | Stereo position (−1 = left, 0 = centre, 1 = right). |
| feedback\_active | Enable feedback loop — delay repeats and feeds back into itself. |
| feedback\_delay\_ms | Feedback loop delay time. |
| feedback\_level\_db | Feedback level — keep below 0 dB to avoid self-oscillation. |
| feedback\_lowpass | Low-pass on feedback — each repeat gets darker (tape delay simulation). |

## 5 · Dynamics — Compressor, Limiter & Amplify

### AudioEffectCompressor — all properties

A compressor automatically turns down loud signals and turns up quiet ones, reducing dynamic range. Essential on the Master bus and SFX bus.

| Property | What it does |
| --- | --- |
| threshold (dB, −60–0) | Level above which compression begins. Signals below pass through unchanged. |
| ratio (1–48) | Compression ratio. 4:1 = for every 4 dB above threshold, only 1 dB comes out. |
| gain (dB) | Make-up gain after compression — restores perceived loudness. |
| attack\_us (20–2000 µs) | How fast it reacts when signal exceeds threshold. Fast = catches transients. |
| release\_ms (20–2000 ms) | How fast it releases when signal falls below threshold. |
| mix (0–1) | Parallel compression blend. Less than 1 mixes dry signal back in for "punch". |
| sidechain (StringName) | Bus name used as the compression trigger. Set to "Voice" to duck music when a character speaks. |

### Sidechain ducking — music lowers when voice plays

```gdscript
# On the Music bus: AudioEffectCompressor with sidechain = "Voice"
# When the Voice bus has signal, it triggers the compressor on Music.
# Retrieve and adjust at runtime:
func set_ducking(threshold_db: float) -> void:
    var idx  := AudioServer.get_bus_index("Music")
    var comp := AudioServer.get_bus_effect(idx, 0) as AudioEffectCompressor
    if comp:
        comp.threshold = threshold_db   # e.g. -20.0 = heavy ducking
```

### AudioEffectLimiter — all properties

A limiter is a compressor with infinite ratio — nothing gets louder than the ceiling. Always add one last on the Master bus.

| Property | What it does |
| --- | --- |
| ceiling\_db | Hard ceiling. Set to −0.1 or −1.0 dB to prevent digital clipping. |
| threshold\_db | Level above which limiting begins — slightly below ceiling. |
| softclip\_db | Range above threshold for gentle saturation before hard limiting. |
| softclip\_ratio | Saturation curve steepness in the softclip zone. |

### AudioEffectAmplify

A single gain stage. One property: volume\_db. Useful at the end of a mastering chain to nudge overall output without affecting compressor/limiter settings.

## 6 · EQ & Filters

### AudioEffectFilter — all properties

| Property | What it does |
| --- | --- |
| cutoff\_hz (1–20500) | Filter centre / cutoff frequency. 500 Hz = muddy bass; 5000 Hz = presence. |
| resonance (0.1–4) | Q factor — how sharply the filter cuts/boosts around cutoff. High values ring. |
| gain | Input gain before the filter. |
| filter\_db | Gain at cutoff for shelf and peak filter types. |

### Filter type quick reference

| Type | Passes | Blocks | Game use |
| --- | --- | --- | --- |
| LowPass | Below cutoff | Above cutoff | Underwater, muffled, behind a wall |
| HighPass | Above cutoff | Below cutoff | Radio, walkie-talkie, thin/scratchy |
| BandPass | Around cutoff | Above and below | Telephone, megaphone, nasal |
| Notch | All except cutoff | Narrow band | Remove 50/60 Hz hum |
| Peak | All (boost/cut at cutoff) | — | Presence boost, mud cut |
| LowShelf | All (boost/cut below) | — | Bass boost or cut |
| HighShelf | All (boost/cut above) | — | Air boost, harshness reduction |

### AudioEffectPitchShift — all properties

Changes pitch without changing playback speed — unlike `pitch_scale` on a player node.

| Property | What it does |
| --- | --- |
| pitch\_scale (0.01–16) | 1.0 = unchanged. 2.0 = one octave up. 0.5 = one octave down. |
| oversampling (1–8) | Processing quality. Higher = better but more CPU. 4 is a good balance. |
| fft\_size | 512/1024/2048/4096 samples. Larger = better quality + more latency. |

## 7 · Controlling Buses in Code — AudioServer

:::callout-intuition[Intuition]
`AudioServer` is a global singleton giving you programmatic access to every bus: look them up by name or index, read/write volume, mute/solo, retrieve and modify effects. This is how volume sliders work in a settings menu, how music mutes during cutscenes, and how an underwater filter morphs over time.
:::

### Key AudioServer methods

| Method | What it does |
| --- | --- |
| `get_bus_index(name) → int` | Index of bus by name. Returns −1 if not found. |
| `get_bus_name(idx) → String` | Name of bus at index. |
| `get/set_bus_volume_db(idx, vol)` | Read or write a bus's volume in dB. |
| `get/set_bus_mute(idx, bool)` | Mute or unmute a bus. |
| `get/set_bus_solo(idx, bool)` | Solo or unsolo a bus. |
| `get_bus_effect(idx, effect_idx) → AudioEffect` | Retrieve an effect object to read/write its properties. |
| `set_bus_effect_enabled(idx, effect_idx, bool)` | Enable or bypass an effect at runtime. |
| `add_bus_effect(idx, effect, at_pos)` | Insert a new AudioEffect into a bus chain. |
| `remove_bus_effect(idx, effect_idx)` | Remove an effect from a bus. |
| `get_bus_peak_volume_left_db(idx, ch) → float` | Peak meter reading — for VU visualisers. |
| `set_bus_layout(layout)` | Replace the entire bus layout at runtime. |
| `generate_bus_layout() → AudioBusLayout` | Snapshot the current live layout as a saveable resource. |

### Example — settings menu volume sliders

```gdscript
extends Control

@onready var master_sl: HSlider = $MasterSlider   # range 0.0–1.0
@onready var music_sl:  HSlider = $MusicSlider
@onready var sfx_sl:    HSlider = $SFXSlider

func _ready() -> void:
    master_sl.value = db_to_linear(AudioServer.get_bus_volume_db(
                          AudioServer.get_bus_index("Master")))
    music_sl.value  = db_to_linear(AudioServer.get_bus_volume_db(
                          AudioServer.get_bus_index("Music")))
    sfx_sl.value    = db_to_linear(AudioServer.get_bus_volume_db(
                          AudioServer.get_bus_index("SFX")))

    master_sl.value_changed.connect(_set_vol.bind("Master"))
    music_sl.value_changed.connect(_set_vol.bind("Music"))
    sfx_sl.value_changed.connect(_set_vol.bind("SFX"))

func _set_vol(linear: float, bus_name: String) -> void:
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(bus_name),
        linear_to_db(linear))
```

### Example — underwater low-pass filter from an Area2D

```gdscript
extends Area2D

var _filter: AudioEffectLowPassFilter
var _effect_idx: int = -1
const MASTER: int = 0

func _ready() -> void:
    body_entered.connect(_on_enter)
    body_exited.connect(_on_exit)

func _on_enter(body: Node) -> void:
    if not body.is_in_group("player"): return
    _filter = AudioEffectLowPassFilter.new()
    _filter.cutoff_hz = 800.0
    _filter.resonance = 0.8
    AudioServer.add_bus_effect(MASTER, _filter)
    _effect_idx = AudioServer.get_bus_effect_count(MASTER) - 1
    AudioServer.set_bus_volume_db(MASTER,
        AudioServer.get_bus_volume_db(MASTER) - 6.0)

func _on_exit(body: Node) -> void:
    if not body.is_in_group("player"): return
    if _effect_idx >= 0:
        AudioServer.remove_bus_effect(MASTER, _effect_idx)
        _effect_idx = -1
    AudioServer.set_bus_volume_db(MASTER,
        AudioServer.get_bus_volume_db(MASTER) + 6.0)
```

## 8 · Mix Recipes

### Pause menu — lower game audio

```gdscript
func open_pause() -> void:
    var music_idx := AudioServer.get_bus_index("Music")
    var sfx_idx   := AudioServer.get_bus_index("SFX")
    var t := create_tween().set_parallel(true)
    t.tween_method(func(v: float): AudioServer.set_bus_volume_db(music_idx, v),
                   AudioServer.get_bus_volume_db(music_idx), -18.0, 0.3)
    t.tween_method(func(v: float): AudioServer.set_bus_volume_db(sfx_idx,  v),
                   AudioServer.get_bus_volume_db(sfx_idx),  -80.0, 0.3)

func close_pause() -> void:
    var music_idx := AudioServer.get_bus_index("Music")
    var sfx_idx   := AudioServer.get_bus_index("SFX")
    var t := create_tween().set_parallel(true)
    t.tween_method(func(v: float): AudioServer.set_bus_volume_db(music_idx, v),
                   AudioServer.get_bus_volume_db(music_idx), -6.0, 0.3)
    t.tween_method(func(v: float): AudioServer.set_bus_volume_db(sfx_idx,  v),
                   AudioServer.get_bus_volume_db(sfx_idx),   0.0, 0.3)
```

### Cave reverb preset

```gdscript
func enter_cave() -> void:
    var reverb := AudioEffectReverb.new()
    reverb.room_size    = 0.85
    reverb.damping      = 0.3
    reverb.wet          = 0.6
    reverb.dry          = 1.0
    reverb.predelay_msec = 35.0
    AudioServer.add_bus_effect(AudioServer.get_bus_index("Ambient"), reverb)
```

### Nightmare mode — morph filter + distortion over time

```gdscript
var _reverb:     AudioEffectReverb
var _distortion: AudioEffectDistortion
var _lowpass:    AudioEffectLowPassFilter

func _ready() -> void:
    _reverb              = AudioEffectReverb.new()
    _reverb.room_size    = 0.95
    _reverb.wet          = 0.0       # starts dry; tweened in
    _distortion          = AudioEffectDistortion.new()
    _distortion.drive    = 0.0
    _lowpass             = AudioEffectLowPassFilter.new()
    _lowpass.cutoff_hz   = 20000.0   # starts open
    var m := 0   # Master bus index
    AudioServer.add_bus_effect(m, _reverb)
    AudioServer.add_bus_effect(m, _distortion)
    AudioServer.add_bus_effect(m, _lowpass)

func enter_nightmare(dur: float = 2.0) -> void:
    var t := create_tween().set_parallel(true)
    t.tween_property(_reverb,     "wet",         0.8,    dur)
    t.tween_property(_distortion, "drive",        0.5,    dur)
    t.tween_property(_lowpass,    "cutoff_hz",  1200.0,   dur)

func exit_nightmare(dur: float = 2.0) -> void:
    var t := create_tween().set_parallel(true)
    t.tween_property(_reverb,     "wet",         0.0,   dur)
    t.tween_property(_distortion, "drive",        0.0,   dur)
    t.tween_property(_lowpass,    "cutoff_hz", 20000.0,  dur)
```

## Practice Problems

:::problem{difficulty="easy"}
**A.** What is the purpose of the Master bus, and why should you always put a Limiter effect on it?

::::solution[Solution]
The Master bus is the final destination for all audio before it reaches the hardware. Every other bus routes into it. A Limiter on the Master bus prevents any combination of sounds from exceeding 0 dBFS (digital full scale), which would cause harsh digital clipping. Set the ceiling to −0.1 or −1.0 dB for a small safety margin.
::::
:::

:::problem{difficulty="easy"}
**B.** Write the two lines of code that mute the "SFX" bus and later unmute it.

::::solution[Solution]
```gdscript
AudioServer.set_bus_mute(AudioServer.get_bus_index("SFX"), true)   # mute
AudioServer.set_bus_mute(AudioServer.get_bus_index("SFX"), false)  # unmute
```
::::
:::

:::problem{difficulty="standard"}
**C.** Explain the difference between a LowPassFilter and HighPassFilter. Give one in-game scenario for activating each dynamically at runtime.

::::solution[Solution]
A **LowPassFilter** passes frequencies *below* the cutoff and attenuates everything above — the result sounds muffled or heard-through-a-wall. Runtime scenario: activate on Master when the player goes underwater (cutoff ~800 Hz).

A **HighPassFilter** passes frequencies *above* the cutoff and cuts everything below — the result sounds thin and tinny like a radio. Runtime scenario: apply to a "Radio" bus for in-game walkie-talkie dialogue (cutoff ~500 Hz).
::::
:::

:::problem{difficulty="standard"}
**D.** What is sidechain compression and how do you set it up in Godot to duck music when a character speaks?

::::solution[Solution]
Sidechain compression uses signal from one bus (the "sidechain") as the trigger for a compressor on another. When the sidechain bus has signal, the compressor activates and lowers the target bus automatically.

Setup: on the Music bus add an `AudioEffectCompressor`. Set `sidechain = "Voice"`, `threshold = -20.0`, `ratio = 4.0`, `attack_us = 100`, `release_ms = 300`. When Voice plays, Music automatically ducks and recovers.
::::
:::

:::problem{difficulty="challenge"}
**E.** Write a `SettingsManager` that saves and restores bus volumes across sessions using `ConfigFile`, and exposes a `set_volume(bus_name, linear)` method that updates both AudioServer and the saved config simultaneously.

::::solution[Solution]
```gdscript
class_name SettingsManager
extends Node

const CONFIG_PATH: String = "user://settings.cfg"
const SECTION:     String = "audio"

var _config := ConfigFile.new()

func _ready() -> void:
    _config.load(CONFIG_PATH)
    # Apply saved volumes on startup
    for bus_name in ["Master", "Music", "SFX", "Voice", "UI"]:
        var linear: float = _config.get_value(SECTION, bus_name, 1.0)
        _apply(bus_name, linear)

func set_volume(bus_name: String, linear: float) -> void:
    _apply(bus_name, linear)
    _config.set_value(SECTION, bus_name, linear)
    _config.save(CONFIG_PATH)

func _apply(bus_name: String, linear: float) -> void:
    var idx: int = AudioServer.get_bus_index(bus_name)
    if idx < 0: return
    AudioServer.set_bus_volume_db(idx, linear_to_db(linear))
```
::::
:::
