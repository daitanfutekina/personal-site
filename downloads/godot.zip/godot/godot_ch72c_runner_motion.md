---
title: "Crowd Runner — Leader CharacterBody3D & Auto-Forward Motion"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72C"
meta:
  - "Est. study time: ~40 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72c_runner_motion.html"
---

## Overview

Replace the placeholder TestMover with the real **Runner**: a
 CharacterBody3D leader with a capsule mesh, two overlap sensors for later chapters
 (gates and obstacles), and a script that drives constant forward motion plus a subtle
 visual bob so the leader doesn't look like a floating stick.

:::callout-key[What you'll build in this chapter]
Runner.tscn — CharacterBody3D with a capsule collision, a visible leader mesh, and
 two Area3D sensors on the correct physics layers. Runner.gd drives the forward velocity
 and the bob. Main.tscn is updated to use Runner in place of TestMover, and TestMover is
 deleted.
:::

### Prerequisites

- Ch 72A + B complete — world scrolls, camera follows a target.
- Comfortable with CharacterBody3D (Ch 28, 29).

:::callout-connect[Reference checklist]
**Ch 28** (Jolt 3D physics, CharacterBody3D basics),
 **Ch 29** (3D character controller patterns — we use a simplified one),
 **Ch 25** (MeshInstance3D primitives — CapsuleMesh).
:::

## 1. Runner Scene

1. *Scene → New Scene*. Root = **CharacterBody3D**, rename
 **Runner**. Save as `res://scenes/runner/Runner.tscn`.
2. Select Runner. In the Inspector:

   - **Collision Layer**: check *2 (Runner)* only.
   - **Collision Mask**: check *1 (Ground)* only. Runner collides
    with ground but nothing else — gate/obstacle detection is done by the Area3D
    sensors we're about to add.
   - **Motion Mode**: `Grounded`.
   - **Up Direction**: *Vector3(0, 1, 0)* (default).
   - **Floor Snap Length**: `0.5`. Keeps the runner glued to
    the ground even at slight elevation changes (there aren't any in Ch 72, but this
    costs nothing).

3. Add child **CollisionShape3D**, name *CapsuleShape*.

   - *Shape* → *New CapsuleShape3D*.
   - *Radius* = `0.35`, *Height* = `1.6`.
    Godot's capsule height *includes* the hemispherical caps.
   - *Transform → Position → Y* = `0.8`. So the capsule bottom sits
    at Y = 0 (on the ground surface).

## 2. Leader Mesh & Material

The leader gets a visible capsule of its own, offset slightly forward and given a
 contrasting colour so it reads distinctly from the crowd we'll add in Ch 72E.

1. Add child **MeshInstance3D**, name *LeaderMesh*.

   - *Mesh* → *New CapsuleMesh*. *Radius* = `0.35`,
    *Height* = `1.6`.
   - *Transform → Position → Y* = `0.8`. Same as CollisionShape3D so
    the visible capsule matches the collision.
   - *Material Override* → *New StandardMaterial3D*.

     - *Albedo* → *Color* = `#ff9d3d` (warm orange —
      stands out against the grey ground & teal followers).
     - *Metallic* = `0.0`, *Roughness* = `0.55`.
     - *Emission → Enabled* = *on*. *Emission Color* =
      `#ff9d3d`. *Emission Energy Multiplier* = `0.6`.
      This makes the leader glow slightly so it pops through the glow bloom.
     - Save to `res://assets/materials/runner_mat.tres`.

:::callout-tip[Why the leader glows and the followers won't]
Emission is what makes the WorldEnvironment glow post-process pick up an object as a
 bloom source. The leader is the player's eye focus, so we want it visually magnetic.
 Followers we specifically *don't* want glowing (that would bloom the crowd into a
 teal blob) — they'll use a plain roughness material in Ch 72E.
:::

## 3. GateSensor & HitSensor

Two Area3D sensors as siblings of the collision. They don't participate in physics
 themselves; they scan for overlaps with Gate and Obstacle Area3Ds and emit signals.
 Adding them *now*, before we need them, means the Runner scene is complete for the
 rest of the series.

1. Add child **Area3D**, name *GateSensor*.

   - *Collision Layer*: clear all (this Area doesn't *advertise*).
   - *Collision Mask*: check *3 (Gate)*. It scans for Gate Area3Ds.
   - Add child **CollisionShape3D** to GateSensor.
    *Shape* = *New BoxShape3D*, *Size* = `(1.0, 1.6, 0.4)`.
    *Transform → Position → Y* = `0.8`. Narrow box in front of the leader.

2. Add child **Area3D**, name *HitSensor*.

   - *Collision Layer*: clear all.
   - *Collision Mask*: check *4 (Obstacle)* and *5 (EnemyWall)*.
   - Add child CollisionShape3D. *Shape* = *New CapsuleShape3D*,
    *Radius* = `0.4`, *Height* = `1.7`. Slightly
    larger than the leader's own capsule — obstacles should register a hair before
    the leader visually touches them, or the hit feels late.
   - *Transform → Position → Y* = `0.85`.

:::callout-warning[Two Areas, not one]
You might think a single Area3D with mask `3 | 4 | 5` would work — it does,
 technically, but its signal handler would have to inspect the entering body's collision
 layer to know if it's a Gate, Obstacle, or Wall. Two separate Areas let the physics
 engine route each signal to its own handler. Zero `if` checks at collision
 time, zero routing bugs.
:::

:::callout-pitfall[Signals not wired yet]
We add the sensors now but don't hook up `area_entered` / `body_entered`
 until Ch 72F (when Gate and Obstacle scenes exist to enter them). Right now the sensors are
 inert — that's fine.
:::

Final Runner tree:

```
Runner (CharacterBody3D)                   ← Runner.gd
├── CapsuleShape (CollisionShape3D)
├── LeaderMesh (MeshInstance3D)
├── GateSensor (Area3D)
│   └── CollisionShape3D
└── HitSensor (Area3D)
    └── CollisionShape3D
```

Save the scene.

## 4. Runner.gd

Attach a script to the Runner root. Path `res://scenes/runner/Runner.gd`,
 template Empty, inherits CharacterBody3D.

```gdscript
# res://scenes/runner/Runner.gd
# The leader capsule. Auto-moves forward, tweens between lanes (Ch 72D adds lanes).
# Hosts GateSensor and HitSensor for Ch 72F.
class_name Runner
extends CharacterBody3D

# ── Tuning (see Ch 72 Design Sheet §Tuning) ─────────────────────────
@export var run_speed      : float = 10.0
@export var lane_x         : Array[float] = [-2.0, 0.0, 2.0]
@export var lane_swap_time : float = 0.18
@export var bob_amp        : float = 0.08
@export var bob_freq       : float = 7.5

# ── State ────────────────────────────────────────────────────────────
var current_lane : int = 1     # index into lane_x; 1 = centre
var _time        : float = 0.0
var _lane_tween  : Tween

@onready var leader_mesh : MeshInstance3D = $LeaderMesh

func _ready() -> void:
    global_position.x = lane_x[current_lane]

func _physics_process(dt: float) -> void:
    _time += dt
    # Constant forward motion in world -Z.
    velocity = Vector3(0.0, velocity.y, -run_speed)
    # Cheap gravity in case we spawn a hair above ground.
    if not is_on_floor():
        velocity.y -= 9.8 * dt
    else:
        velocity.y = 0.0
    move_and_slide()

    # Visual sine-bob on the leader mesh only — the collision stays put.
    var bob := sin(_time * bob_freq * TAU) * bob_amp
    leader_mesh.position.y = 0.8 + bob

# Public API — Ch 72D calls change_lane(±1).
func change_lane(direction: int) -> void:
    var new_idx : int = clamp(current_lane + direction, 0, lane_x.size() - 1)
    if new_idx == current_lane:
        return
    current_lane = new_idx
    _tween_to_lane(current_lane)

func _tween_to_lane(idx: int) -> void:
    if _lane_tween != null and _lane_tween.is_valid():
        _lane_tween.kill()
    _lane_tween = create_tween()
    _lane_tween.set_ease(Tween.EASE_OUT)
    _lane_tween.set_trans(Tween.TRANS_QUAD)
    _lane_tween.tween_property(self, "position:x", lane_x[idx], lane_swap_time)
```

:::callout-intuition[Read the \_physics\_process carefully]
Every physics tick we *reset* velocity to (0, velocity.y, -run\_speed). The Y
 component we preserve from last frame so gravity accumulates properly. Then we optionally
 apply gravity if we're airborne, and clamp Y to zero when on the floor.
 `move_and_slide()` is the CharacterBody3D built-in that consumes
 `velocity` and produces the actual motion after collision resolution — you
 almost always call it exactly once at the end of \_physics\_process.
:::

:::callout-pitfall[Don't do global\_position.z -= run\_speed \* dt]
Direct position writes bypass the physics engine entirely — the runner would clip
 through the ground and never receive collision events. Always drive movement through
 `velocity` + `move_and_slide()`. This is the #1 mistake beginners
 make with CharacterBody3D.
:::

## 5. Swap TestMover for Runner in Main

1. Open `Main.tscn`.
2. Select **TestMover**, right-click → *Delete Node*. Confirm.
3. Drag `res://scenes/runner/Runner.tscn` from the FileSystem onto the
 **Main** root. Confirm it lands as a direct child of Main (not under
 GroundContainer or CameraRig).
4. Set its **Transform → Position** to `(0, 0, 0)`. It should
 appear centred, standing on the ground.
5. Update `Main.gd` — change the `_initial_target` line to point
 at Runner:

```gdscript
@onready var _initial_target : Node3D = $Runner    # was: $TestMover
```

1. Save. Run (F5). The orange leader capsule should now be the thing scrolling
 forward with the world.

## 6. Sine-Bob Animation — Making the Leader Look Alive

Runner.gd already computes the bob every physics tick. The bob is applied to
 `leader_mesh.position.y` only — the CollisionShape stays perfectly level so
 collisions don't stutter as the capsule bobs.

:::callout-intuition[Why sine-bob is enough]
Skeletal run animations cost per-bone matrix math per frame. On a phone, one skeletal
 character is fine, but you don't want it for a crowd of 200. A sine wave on the mesh Y is
 one float per frame per capsule — costs nothing and reads as “running” well
 enough at a distance. The follower crowd (Ch 72E) uses the same trick, shifted in phase
 per follower to look like a real bobbing crowd rather than a synchronised blob.
:::

:::callout-tip[Slight forward lean (optional polish)]
For extra life, you can also tilt the leader mesh forward slightly by adding
 `leader_mesh.rotation.x = -0.08` in `_ready()`. A tiny forward pitch
 reads as “leaning into the sprint” the same way real runners do. Costs nothing.
:::

## 7. Verification

1. Save all. Run (F5).

:::callout-key[Verify]
- Orange leader capsule stands on the ground at spawn, then accelerates forward at
 10 m/s.
- The camera stays behind it as it moves.
- Ground segments recycle forever.
- The capsule *bobs vertically* at ~7.5 Hz — a subtle up-and-down while
 running. If you can't see it, drop your monitor gaze or drag the game window closer
 — it's a small effect.
- Output has no red errors.
:::

:::callout-warning[Runner falls through the ground]
Cause: Runner's Collision Mask does not include layer 1. Fix: select Runner, in the
 Inspector expand *Collision → Mask*, tick layer 1 (Ground). Also verify the ground
 is on layer 1 (should be from Ch 72A step 5).
:::

:::callout-warning[Runner doesn't move]
The most common cause is missing `move_and_slide()` at the end of
 `_physics_process`. Second most common: you deleted TestMover but forgot to
 update `_initial_target` in Main.gd — the Ground/Camera still try to follow
 TestMover which no longer exists.
:::

:::callout-warning[Runner is invisible but shadow / collision is there]
LeaderMesh's Y offset is wrong. If the mesh is centred at Y = 0.8 but with height 1.6
 and radius 0.35, it should render from Y = 0 to Y = 1.6. If you accidentally set it to
 Y = 0, the bottom half of the capsule is buried in the ground.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why is the bob applied to `leader_mesh.position.y` and not to
 `self.position.y`?

::::solution[Solution]
Because `self` is the CharacterBody3D, and its position is also the
 collision shape's position. Bobbing it would cause the capsule to repeatedly leave the
 floor (triggering `is_on_floor()` flips), producing physics stutter. Bobbing
 only the child MeshInstance3D is a purely visual effect.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
You want the leader to feel “heavier” — a slower, deeper bob.
 Which two `@export`s do you touch and roughly what values?

::::solution[Solution]
Drop *bob\_freq* from 7.5 to ~4.5 Hz (slower cadence) and raise *bob\_amp*
 from 0.08 m to ~0.14 m (deeper dip). Any lower on freq and the leader looks like he's
 wading through mud; any higher on amp and the visual clipping through the collision
 shape becomes visible.
::::
:::

:::problem[Problem 3 challenge]{difficulty="challenge"}
The runner should accelerate over the first two seconds instead of instantly
 blasting off at 10 m/s. Refactor `_physics_process` to ease into full speed.

::::solution[Solution]
Add `@export var accel_time := 2.0`. Track `_time` from `_ready`.
 Compute `var t = clamp(_time / accel_time, 0.0, 1.0)`, then
 `var speed = lerp(0.0, run_speed, ease(t, 0.5))` (Godot's `ease`
 with 0.5 gives an S-curve). Use `speed` instead of `run_speed` in
 the velocity assignment. Result: gentle acceleration from 0 → 10 m/s across 2 s, then
 constant.
::::
:::

:::summary
## Summary

The Runner scene is complete: CharacterBody3D on layers/masks, visible leader capsule
 with emissive orange, two Area3D sensors sitting inert on layers 3 and 4/5 waiting for
 Ch 72F, and a Runner.gd that drives constant forward motion with sine-bob visuals. Main
 now uses Runner as the follow target; TestMover is gone.

**Next:**
 [Ch 72D](./godot_ch72d_swipe_lanes.html) hooks up swipe input and keyboard
 fallback so you can actually steer between the three lanes.
:::
