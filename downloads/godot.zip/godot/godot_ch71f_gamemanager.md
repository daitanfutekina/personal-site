---
title: "VS Clone — GameManager, Run Progression & End Screens"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71F"
meta:
  - "Est. study time: ~60 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated June 2026"
source: "godot_ch71f_gamemanager.html"
---

## Overview

GameManager is the conductor. It tracks run time, kill count, and the game's
 current state — and broadcasts changes so every system reacts automatically.
 This chapter completes the full GameManager, builds the death and victory
 screens inside HUD.tscn, and writes the final `Main.gd` that
 connects every system from Ch 71A through 71E into a complete game loop.

:::callout-connect[What was built as a skeleton in Ch 71A]
`GameManager.gd` was registered as an autoload in Ch 71A with a
 minimal skeleton. This chapter replaces that skeleton with the full implementation.
 No new autoload registration is needed if you followed Ch 71A — just
 overwrite the script content.
:::

## 1. Confirm GameManager is Registered as Autoload

1. **Open Project Settings.** Go to
 **Project → Project Settings → Autoloads**.
2. **Check GameManager is listed.** You should see
 `GameManager` pointing to
 `res://autoloads/GameManager.gd`. If it isn't there, click
 the folder icon, navigate to the script, and add it.
 The **Global Variable Name** must be exactly
 `GameManager` — this is the name used throughout all scripts.
3. **Check ObjectPool is also listed.** You need both autoloads.
 ObjectPool should point to `res://autoloads/ObjectPool.gd`.
4. **Close Project Settings** and save with Ctrl+S.

## 2. Full GameManager.gd

Open `res://autoloads/GameManager.gd` and replace the skeleton
 content entirely with the script below.

```gdscript
## res://autoloads/GameManager.gd
extends Node

enum State { WAITING, PLAYING, LEVEL_UP, GAME_OVER, VICTORY }
var state: State = State.WAITING

const RUN_DURATION: float = 1800.0   ## 30 minutes in seconds

var run_timer:  float  = 0.0
var kill_count: int    = 0
var player:     Player = null

signal state_changed(new_state: State)
signal timer_updated(seconds: float)
signal kills_updated(count: int)

## ── Public API ────────────────────────────────────────────────────────
func start_run(p: Player) -> void:
    player     = p
    run_timer  = 0.0
    kill_count = 0
    _set_state(State.PLAYING)

## Called by EnemyBase._die() for each kill.
func on_enemy_killed() -> void:
    kill_count += 1
    kills_updated.emit(kill_count)

## Called by Player._level_up().
func trigger_level_up() -> void:
    if state == State.PLAYING:
        _set_state(State.LEVEL_UP)

## Called by Player.take_damage() when HP reaches 0.
func game_over() -> void:
    ## Accept game over from either PLAYING or LEVEL_UP state.
    if state == State.PLAYING or state == State.LEVEL_UP:
        _set_state(State.GAME_OVER)

## ── Internal ──────────────────────────────────────────────────────────
func _process(delta: float) -> void:
    ## PAUSABLE default mode — this stops automatically when the tree is paused.
    if state != State.PLAYING:
        return
    run_timer += delta
    timer_updated.emit(run_timer)
    if run_timer >= RUN_DURATION:
        _set_state(State.VICTORY)

func _set_state(new_state: State) -> void:
    state = new_state
    state_changed.emit(new_state)
```

:::callout-key[The timer stops during level-up for free]
GameManager uses `PROCESS_MODE_PAUSABLE` (the default for autoloads).
 When `get_tree().paused = true` fires during level-up, the
 `_process` call stops — the run timer freezes automatically.
 No extra code, no flag, no coroutine.
:::

## 3. Run Timer & Kill Counter in HUD

Connect GameManager's signals in `HUD._ready()` so the display
 updates reactively instead of polling each frame:

```gdscript
## In HUD.gd _ready() — add these two lines:
GameManager.timer_updated.connect(update_timer)
GameManager.kills_updated.connect(update_kills)

## Updated update_timer — counts DOWN to show urgency:
func update_timer(seconds: float) -> void:
    var remaining := GameManager.RUN_DURATION - seconds
    var m := int(remaining) / 60
    var s := int(remaining) % 60
    timer_lbl.text = "%02d:%02d" % [m, s]

func update_kills(count: int) -> void:
    kill_lbl.text = "Kills: %d" % count
```

:::callout-tip[Countdown vs. count-up]
Vampire Survivors counts *down* from 30:00, which creates urgency as
 the number approaches 0:00. The formula above subtracts from
 `RUN_DURATION`. Swap to `seconds` directly for a
 count-up clock if you prefer.
:::

## 4. Build the End Screens in HUD.tscn

```
HUD (CanvasLayer)
├── MarginContainer              ← existing HP/XP bars from Ch 71E
├── GameOverPanel (Panel)        ← NEW; hidden; process_mode=ALWAYS
│   └── VBoxContainer
│       ├── TitleLabel           "You Died"
│       ├── StatsLabel           survived time + kills + level
│       └── RestartButton (Button)
└── VictoryPanel (Panel)         ← NEW; hidden; process_mode=ALWAYS
    └── VBoxContainer
        ├── TitleLabel           "You Survived!"
        ├── StatsLabel           final stats
        └── RestartButton (Button)
```

### Build GameOverPanel

1. **Open HUD.tscn.** Double-click
 `res://scenes/ui/HUD.tscn` in the FileSystem dock.
2. **Add GameOverPanel.** Select the `HUD` root,
 press Ctrl+A, add a `Panel`. Rename it
 `GameOverPanel`. In **Layout → Anchors Preset**
 choose **Center**. Set Custom Minimum Size to roughly
 400 × 300. Apply a dark StyleBoxFlat via Theme Overrides → Styles → Panel.
 Set **Process Mode: Always** so the RestartButton works while paused.
 Set **Visible: Off** in the Inspector.
3. **Add VBoxContainer** inside GameOverPanel. Alignment: Center.
 Separation: 16.
4. **Add TitleLabel.** Text: `You Died`. Large font,
 centered. Color: red/orange via Theme Overrides.
5. **Add StatsLabel.** Text: `Survived: 00:00 Kills: 0`
 (placeholder — code will update it at runtime). Alignment: Center.
6. **Add RestartButton.** Text: `Play Again`.
 Focus Mode: All. *Do not connect the pressed signal in the editor*
 — HUD.gd connects it in code.

### Build VictoryPanel

1. **Duplicate GameOverPanel.** Right-click
 `GameOverPanel` in the Scene dock → **Duplicate**.
 Rename the copy to `VictoryPanel`.
2. **Update TitleLabel text** to `You Survived!`.
 Change its color to green/gold.
3. **Save HUD.tscn.** Press Ctrl+S.

## 5. Death & Victory Screen Code

Add these methods to `HUD.gd`. They are called from
 `Main._on_game_state_changed()`.

```gdscript
## In HUD.gd — add to _ready():
$GameOverPanel/VBoxContainer/RestartButton.pressed.connect(_on_restart_pressed)
$VictoryPanel/VBoxContainer/RestartButton.pressed.connect(_on_restart_pressed)

func show_game_over() -> void:
    var m := int(GameManager.run_timer) / 60
    var s := int(GameManager.run_timer) % 60
    $GameOverPanel/VBoxContainer/StatsLabel.text = \
        "Survived: %02d:%02d   Kills: %d   Level: %d" % \
        [m, s, GameManager.kill_count, GameManager.player.stats.level]
    $GameOverPanel.show()
    $GameOverPanel/VBoxContainer/RestartButton.grab_focus()

func show_victory() -> void:
    $VictoryPanel/VBoxContainer/StatsLabel.text = \
        "30:00 Survived!   Kills: %d   Level: %d" % \
        [GameManager.kill_count, GameManager.player.stats.level]
    $VictoryPanel.show()
    $VictoryPanel/VBoxContainer/RestartButton.grab_focus()

func _on_restart_pressed() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
```

## 6. Restart Flow

Both end screens share the same restart function:

```gdscript
func _on_restart_pressed() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
```

:::callout-warning[Unpause before reload — or the new scene loads frozen]
If the tree is paused when `reload_current_scene()` is called,
 the new scene loads in a paused state. Always set
 `get_tree().paused = false` first. This is the most common
 restart bug.
:::

:::callout-tip[PlayerStats reset automatically on reload]
Because `PlayerStats.reset()` is called in
 `Player._ready()`, reloading the scene resets all runtime stats
 to their base values. No manual cleanup is needed in the restart function.
:::

## 7. Full Main.gd

Replace the current `Main.gd` content entirely. This is the
 complete integration point — it registers pools, wires signals, hands
 starting weapons to the player, and kicks off the run.

```gdscript
## res://scenes/main/Main.gd
extends Node2D

## Set in Inspector — scenes to pre-allocate in ObjectPool.
@export var xp_gem_scene:     PackedScene
@export var projectile_scene: PackedScene
@export var hit_effect_scene: PackedScene

## Set in Inspector — weapons the player starts with.
@export var starting_weapons: Array[PackedScene] = []

@onready var player:         Player       = $Player
@onready var hud:            CanvasLayer  = $HUD
@onready var upgrade_screen: CanvasLayer  = $UpgradeScreen
@onready var tilemap:        TileMapLayer = $World/NavigationRegion2D/TileMapLayer
@onready var enemy_spawner:  Node         = $EnemySpawner

func _ready() -> void:
    ## 1. Register object pools.
    if xp_gem_scene:
        ObjectPool.register("XpGem",      xp_gem_scene,     40)
    if projectile_scene:
        ObjectPool.register("Projectile", projectile_scene, 30)
    if hit_effect_scene:
        ObjectPool.register("HitEffect",  hit_effect_scene, 20)

    ## 2. Wire player signals to HUD.
    player.hp_changed.connect(hud.on_hp_changed)
    player.xp_changed.connect(hud.on_xp_changed)

    ## 3. Wire GameManager state changes to this node.
    GameManager.state_changed.connect(_on_game_state_changed)

    ## 4. Give the player their starting weapons.
    for scene in starting_weapons:
        player.add_weapon(scene)

    ## 5. Fit the Camera2D to the tilemap boundaries.
    _apply_camera_limits()

    ## 6. Start the run — everything is ready.
    GameManager.start_run(player)

func _apply_camera_limits(margin: int = 1) -> void:
    var cam := player.get_node_or_null("Camera2D") as Camera2D
    if cam == null: return
    var rect := tilemap.get_used_rect()
    var ts   := tilemap.tile_set.tile_size.x
    cam.limit_left   = (rect.position.x + margin) * ts
    cam.limit_top    = (rect.position.y + margin) * ts
    cam.limit_right  = (rect.end.x - margin) * ts
    cam.limit_bottom = (rect.end.y - margin) * ts

func _on_game_state_changed(new_state: GameManager.State) -> void:
    match new_state:
        GameManager.State.LEVEL_UP:
            get_tree().paused = true   ## pause BEFORE show_cards()
            upgrade_screen.show_cards()
        GameManager.State.GAME_OVER:
            upgrade_screen.hide()      ## hide upgrade cards if open
            get_tree().paused = false
            hud.show_game_over()
        GameManager.State.VICTORY:
            get_tree().paused = false
            hud.show_victory()
```

## 8. Wire Main.tscn in the Inspector

1. **Open Main.tscn.** Double-click
 `res://scenes/main/Main.tscn`.
2. **Select the Main root node.** In the Inspector you should
 see the exported fields from the new Main.gd: XP Gem Scene, Projectile
 Scene, Hit Effect Scene, Starting Weapons.
3. **Assign XP Gem Scene:** drag
 `res://scenes/pickups/XpGem.tscn` into this slot.
4. **Assign Projectile Scene:** drag
 `res://scenes/weapons/Projectile.tscn` into this slot.
5. **Leave Hit Effect Scene empty for now** — it is added in
 Ch 71G (polish). The `if hit_effect_scene:` guard prevents
 a crash.
6. **Assign Starting Weapons.** Click the
 **Starting Weapons** array, set size to 1, and drag
 `Garlic.tscn` into slot 0. (Magic Wand unlocked via upgrade.)
7. **Save Main.tscn.** Press Ctrl+S.

## 9. Verification Checklist

1. **Timer counts down from 30:00 on the HUD.** If stuck at 30:00:
 GameManager.timer\_updated signal isn't connected to HUD.update\_timer.
 Open HUD.gd and confirm the connection in `_ready()`.
2. **Kill counter increments on enemy death.** If stuck at 0:
 GameManager.kills\_updated isn't connected to HUD.update\_kills, or
 `GameManager.on_enemy_killed()` isn't being called from
 `EnemyBase._die()`.
3. **Game pauses and shows upgrade cards on level-up.**
 Already verified in Ch 71E. Reconfirm it still works with the new
 full Main.gd.
4. **GameOver panel appears and shows stats when player HP hits 0.**
 If not: `GameManager.game_over()` isn't called when player dies,
 or state\_changed signal isn't connected in Main.gd.
5. **Victory panel appears after 30 minutes.** For testing,
 temporarily set `RUN_DURATION = 10.0` in GameManager.gd,
 verify the Victory screen shows, then reset it to 1800.0.
6. **Restart button reloads the scene cleanly.** Player starts
 at level 1 with full HP. No leftover enemies or gems from the previous run.
 If the game loads paused: the restart function didn't unpause before reload.

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
Why does the run timer automatically freeze during the level-up upgrade pause
 without any extra code in GameManager?

::::solution[Solution]
GameManager uses the default `PROCESS_MODE_PAUSABLE`. When
 `get_tree().paused = true`, all PAUSABLE nodes stop receiving
 `_process` calls. Since the timer is incremented in
 `_process`, it simply stops advancing. No flags, no early returns
 for LEVEL\_UP state needed for the freeze — PAUSABLE handles it automatically.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Trace the full signal chain from an enemy dying to the kill counter
 updating on the HUD.

::::solution[Solution]
1. `EnemyBase._die()` → `GameManager.on_enemy_killed()`.

 2. `kill_count += 1` → `kills_updated.emit(kill_count)`.

 3. HUD.update\_kills(count) — connected in HUD.\_ready() — sets
 `kill_lbl.text = "Kills: %d" % count`.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
What happens if the player dies while the upgrade screen is open (state = LEVEL\_UP)?
 Is it handled correctly, and what extra step is needed?

::::solution[Solution]
`game_over()` checks `state == PLAYING or state == LEVEL_UP`,
 so it fires correctly. The state changes to GAME\_OVER, Main unpauses the tree, and
 HUD shows the death screen. However, the upgrade screen is still visible underneath.
 The extra step is in Main.\_on\_game\_state\_changed(GAME\_OVER):
 `upgrade_screen.hide()` before unpausing. This is already included in
 the full Main.gd above.
::::
:::

:::problem[Problem 4 challenge]{difficulty="challenge"}
Add an Escape-key pause/resume that works during PLAYING state but *not*
 during LEVEL\_UP or GAME\_OVER. Where does this code live, and what must the
 pause overlay node have set?

::::solution[Solution]
```gdscript
## In Main.gd:
func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        if GameManager.state == GameManager.State.PLAYING:
            _toggle_pause()

func _toggle_pause() -> void:
    get_tree().paused = not get_tree().paused
    $PauseOverlay.visible = get_tree().paused
```

The PauseOverlay CanvasLayer must have `PROCESS_MODE_ALWAYS` so
 it receives the Escape keypress while paused. The state guard prevents
 accidentally unpausing during LEVEL\_UP, which would leave GameManager stuck
 in LEVEL\_UP state with no upgrade card visible.
::::
:::

## Summary

:::summary
## Chapter 71F — Key Points

| What | How | Why |
| --- | --- | --- |
| GameManager | Autoload; 5-state enum; run\_timer in \_process; signals for timer/kills/state | Central broadcaster — all systems react to signals, nothing polls |
| Timer freeze | PROCESS\_MODE\_PAUSABLE; paused tree stops \_process automatically | Zero extra code to freeze timer during level-up or pause |
| Timer display | timer\_updated signal → HUD.update\_timer(); counts down from RUN\_DURATION | Signal-driven — no Main.\_process() polling needed |
| End screens | state\_changed(GAME\_OVER/VICTORY) → unpause → HUD.show\_\* | State machine broadcasts; Main routes to correct UI |
| Restart | paused=false → reload\_current\_scene() | Reload resets all scene state; PlayerStats.reset() handles stats |
| Main.gd | Registers pools, wires all signals, assigns starting weapons, starts run | Single integration point — no other scene needs to know about other scenes |
:::

Next: **Ch 71G** adds visual and audio polish — hit flash, death particles,
 screen shake, sound effects, and background music.
