---
title: "Earclacks — Ranged Weapons, Projectiles & Abilities"
crumb: "Chapter 70F · Weapon Ball Clone Series"
meta:
  - "Est. study time: ~90 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview

By Ch 70E the game runs end-to-end with melee swords. But the real Weapon Ball ecosystem
 is much wider: bows that fire arrows, staves that launch fireballs, passive rings that
 regenerate HP, special abilities that trigger on conditions. This chapter builds the
 infrastructure to support all of them — without ever touching Ball.gd, MeleeWeapon.gd,
 or HealthComponent.gd.

- **ProjectileBase** — a self-contained RigidBody2D that travels, hits a ball, deals damage, and auto-frees itself
- **RangedWeapon** — extends EquipmentBase; fires projectile scenes on a timer, direction aimed at the enemy ball
- **Arrow.tscn / Fireball.tscn** — two concrete projectiles with different stats
- **Bow.tscn / Staff.tscn** — two concrete ranged weapons
- **SpecialAbility** — triggered by a configurable condition (bounce count, HP threshold, timer)
- **PassiveEffect** — always-on stat modifiers applied in `on_equipped()`

:::callout-key[KEY CONCEPT]
RangedWeapon fires projectiles, but the direction is determined by a snapshot of the
        enemy ball's

current position

at fire time. There is no prediction, no homing,
        no steering. The projectile travels in a straight line and either hits or misses.
        The chaos of bouncing balls makes misses common and hits exciting.
:::

### Prerequisites

- Ch 70C complete — EquipmentBase, MeleeWeapon, physics layers 1–3 configured
- Understanding of Godot 4 RigidBody2D, Area2D, and `queue_free()`
- Familiarity with `get_tree().create_timer()` for cooldown timers

## Design Principles for Equipment Variety

:::callout-intuition[INTUITION]
The original architecture of many Weapon Ball clones breaks when someone tries to add a
        gun: the WeaponBase class assumes a spinning melee item, so the developer copies the whole
        class and hacks in projectile spawning. After a few weapons, every class is a copy-paste
        mess. Our EquipmentBase hierarchy solves this: each new equipment

type

(Ranged,
        Special, Passive) is one new subclass of EquipmentBase — and each new weapon within that
        type is just a scene file with different export values.
:::

```
EquipmentBase (Node2D)
├── MeleeWeapon     ← Ch 70C  — spins, parries, spin reversal
├── RangedWeapon    ← Ch 70F  — fires projectiles on a timer
├── SpecialAbility  ← Ch 70F  — triggered by a condition
└── PassiveEffect   ← Ch 70F  — always-on stat modifier
```

### How a ranged ball looks different

A ball carrying a Bow has no spinning weapon orbiting it. Instead, at regular intervals
 a small arrow node is added to the Arena scene (not parented to the ball — it must move
 independently) and travels toward the enemy ball's position. If it reaches the ball, it
 calls `take_damage()` and calls `queue_free()` on itself. If it hits
 a wall, same thing — just `queue_free()` without damage.

:::callout-warning[WARNING]
If a projectile is a child of the firing ball, it moves with the ball. The projectile
        would never travel anywhere — it would orbit with the ball's motion. Always add projectiles
        as children of the Arena (the root scene) so they move independently.
:::

## ProjectileBase.gd

Create `res://scenes/projectiles/ProjectileBase.gd`. This is the base class
 for all fired projectiles. Concrete projectiles (Arrow, Fireball) extend this or simply
 use it directly with different export values.

```gdscript
class_name ProjectileBase
extends RigidBody2D

# ──────────────────────────────────────────────
# EXPORTS
# ──────────────────────────────────────────────
@export var speed: float       = 400.0
@export var damage: float      = 15.0
@export var lifetime: float    = 3.0   # auto-free after this many seconds

# ──────────────────────────────────────────────
# STATE
# ──────────────────────────────────────────────
## The ball that fired this projectile — we must NOT damage our own ball.
var owner_ball: Ball = null

# ──────────────────────────────────────────────
# NODE REFERENCES
# ──────────────────────────────────────────────
@onready var hitbox: Area2D = $Hitbox

# ──────────────────────────────────────────────
# LIFECYCLE
# ──────────────────────────────────────────────
func _ready() -> void:
    hitbox.area_entered.connect(_on_hitbox_area_entered)
    ## Auto-free after lifetime seconds so stray projectiles don't accumulate.
    get_tree().create_timer(lifetime).timeout.connect(queue_free)

## Called by RangedWeapon immediately after instantiation, before add_child.
func fire(direction: Vector2, from_ball: Ball) -> void:
    owner_ball    = from_ball
    linear_velocity = direction.normalized() * speed
    ## Rotate sprite to face travel direction.
    rotation = direction.angle()

# ──────────────────────────────────────────────
# COLLISION
# ──────────────────────────────────────────────
func _on_hitbox_area_entered(area: Area2D) -> void:
    var hit_ball := area.get_parent() as Ball
    if hit_ball == null:
        ## Hit a wall or non-ball — just remove self.
        queue_free()
        return
    if hit_ball == owner_ball:
        ## Never damage our own ball.
        return
    hit_ball.take_damage(damage)
    queue_free()

## Also handle wall collisions via body_entered (walls are StaticBody2D, not Area2D).
func _on_body_entered(body: Node) -> void:
    if body is StaticBody2D:
        queue_free()
```

:::callout-pitfall[PITFALL]
body\_entered

only fires if the projectile has

contact\_monitor = true

and

max\_contacts\_reported >= 1

set
        in the Inspector — the same requirement as Ball. Alternatively, use an Area2D hitbox
        whose Mask includes Layer 2 (Walls) and handle everything through

area\_entered

and

body\_entered

on the Area2D only.
        The script above uses the Area2D hitbox for ball detection and

body\_entered

on the RigidBody2D itself for wall detection — both are valid.
:::

### Inspector setup for ProjectileBase

| Property | Value | Reason |
| --- | --- | --- |
| gravity\_scale | 0 | Arena has no gravity |
| linear\_damp | 0 | Projectiles don't slow down mid-flight |
| lock\_rotation | false | Rotation set by `fire()`; no physics spin needed |
| collision\_layer | Layer 4 (Projectiles) | Separate from balls and weapons |
| collision\_mask | Layers 1 + 2 | Interacts with balls and walls |
| contact\_monitor | true | Required for body\_entered wall detection |
| max\_contacts\_reported | 1 | We only need to detect one hit |

### Hitbox child (Area2D inside ProjectileBase)

| Property | Value |
| --- | --- |
| collision\_layer | Layer 4 |
| collision\_mask | Layer 1 (balls only — NOT Layer 3; we don't parry with projectiles) |
| monitoring | true |

:::example[Worked Example — Arrow flight and hit]
::::answer
Result: Arrow deals 15 damage to enemy ball and removes itself from the scene.
::::

1. Bow fires: `arrow.fire(direction, owner_ball)` → `linear_velocity = direction * 400`
2. Frames 1–N: Arrow travels in a straight line across the arena. No steering.
3. Arrow hitbox (Layer 4, Mask 1) enters enemy Ball CollisionShape2D (Layer 1).
4. `_on_hitbox_area_entered(area)` fires. `area.get_parent()` → enemy Ball. Not owner\_ball → proceed.
5. `enemy_ball.take_damage(15.0)` → HealthComponent reduces HP.
6. `queue_free()` removes the arrow node.
:::

## RangedWeapon.gd

Create `res://scenes/weapons/RangedWeapon.gd`. This extends EquipmentBase and
 fires a `projectile_scene` on a repeating timer. The fire direction is a
 snapshot of the enemy ball's current position.

```gdscript
class_name RangedWeapon
extends EquipmentBase

# ──────────────────────────────────────────────
# EXPORTS
# ──────────────────────────────────────────────
## The projectile scene to spawn on each shot.
@export var projectile_scene: PackedScene

## Seconds between shots.
@export var fire_rate: float = 1.5

## Offset from ball centre where projectile spawns.
@export var muzzle_offset: Vector2 = Vector2(40.0, 0.0)

# ──────────────────────────────────────────────
# STATE
# ──────────────────────────────────────────────
var _fire_timer: float = 0.0
var _enemy_ball: Ball  = null   # resolved at equip time

# ──────────────────────────────────────────────
# LIFECYCLE
# ──────────────────────────────────────────────
func on_equipped() -> void:
    _resolve_enemy()
    ## Stagger first shot so both balls don't fire simultaneously.
    _fire_timer = fire_rate * randf_range(0.3, 0.9)

func _physics_process(delta: float) -> void:
    _fire_timer -= delta
    if _fire_timer <= 0.0:
        _fire_timer = fire_rate
        _try_fire()

# ──────────────────────────────────────────────
# FIRING
# ──────────────────────────────────────────────
func _try_fire() -> void:
    if projectile_scene == null or _enemy_ball == null:
        return

    var arena := ball.get_parent()   # Arena is ball's parent
    var spawn_pos := ball.global_position + muzzle_offset

    ## Direction = snapshot of enemy position right now.
    ## No prediction, no homing — just aim where they ARE.
    var direction := (_enemy_ball.global_position - spawn_pos).normalized()

    var proj: ProjectileBase = projectile_scene.instantiate()
    arena.add_child(proj)
    proj.global_position = spawn_pos
    proj.fire(direction, ball)
    on_hit_landed(_enemy_ball)   # escalation hook fires on each shot attempt

func _resolve_enemy() -> void:
    ## Find the other ball in the arena.
    ## Assumes Arena has exactly two Ball children.
    for node in ball.get_parent().get_children():
        if node is Ball and node != ball:
            _enemy_ball = node
            break
```

:::callout-key[KEY CONCEPT]
A homing projectile that always curves toward the enemy is deterministic — it always hits.
        That would make the fight one-sided the moment one ball gets a ranged weapon. A snapshot-aimed
        shot can miss if the enemy ball moves or bounces between the fire moment and impact. This
        creates natural drama: "will the arrow catch them?" — which is far more interesting to watch.
:::

:::callout-warning[WARNING]
This assumption holds for the base game. If you later add 3-ball modes, replace this
        with a group lookup: add all balls to the

"balls"

group and
        use

get\_tree().get\_nodes\_in\_group("balls")

, then filter out

ball

.
:::

:::callout-pitfall[PITFALL]
ball.add\_child(proj)

would parent the projectile to the ball. As the ball
        moves, the projectile would move with it. Always use

arena.add\_child(proj)

so the projectile is in the root Arena scene and moves independently.
:::

## Arrow.tscn

### Scene tree

```
Arrow (RigidBody2D)         ← ProjectileBase.gd
├── Sprite2D                ← small arrow graphic, rotated along +X axis
└── Hitbox (Area2D)         ← Layer 4, Mask 1
    └── CollisionShape2D    ← CapsuleShape2D, ~(4, 16)
```

### Construction steps

1. New Scene → root: **RigidBody2D**, rename to **Arrow**
2. Attach script: `res://scenes/projectiles/ProjectileBase.gd`
3. Save as `res://scenes/projectiles/Arrow.tscn`
4. Inspector on Arrow:

   - gravity\_scale = 0, linear\_damp = 0, lock\_rotation = false
   - collision\_layer = Layer 4, collision\_mask = Layers 1+2
   - contact\_monitor = true, max\_contacts\_reported = 1

5. Add child: **Sprite2D** — a small horizontal arrow image
6. Add child: **Area2D** named **Hitbox**

   - collision\_layer = Layer 4, collision\_mask = Layer 1
   - monitoring = true

7. Add child to Hitbox: **CollisionShape2D** → CapsuleShape2D, height=16, radius=4
8. Arrow exports: `speed=400, damage=15, lifetime=3.0`
9. Connect Arrow's `body_entered` signal to `_on_body_entered`

:::callout-tip[TIP]
Godot treats 0° rotation as pointing along the +X axis (right). Design the arrow sprite
        pointing right.

fire()

sets

rotation = direction.angle()

, which
        will correctly rotate the sprite to match the travel direction for any angle.
:::

## Bow.tscn

Bow is the simplest ranged weapon: no spin, no orbit, no visual other than a small bow
 sprite resting on the ball. It just fires Arrows on a timer.

### Scene tree

```
Bow (Node2D)                ← RangedWeapon.gd
└── Sprite2D                ← bow sprite, centred or offset to one side
```

### Construction steps

1. New Scene → root: **Node2D**, rename to **Bow**
2. Attach script: `res://scenes/weapons/RangedWeapon.gd`
3. Save as `res://scenes/weapons/Bow.tscn`
4. Add child: **Sprite2D** — a bow image
5. Inspector exports on Bow:

   - `projectile_scene` = Arrow.tscn
   - `fire_rate = 1.5`
   - `muzzle_offset = Vector2(40, 0)`
   - `damage = 15.0` (passed through to the Arrow instance)

:::callout-warning[WARNING]
Both RangedWeapon and ProjectileBase have a

damage

export.
        The arrow's own

damage

export is what actually applies in `_on_hitbox_area_entered`. RangedWeapon's

damage

is only used
        by the

on\_hit\_landed

escalation hook. For simplicity in early builds,
        set them to the same value. For advanced builds, RangedWeapon could override the
        projectile's damage after instantiation:

proj.damage = damage

— add this line to `_try_fire()`.
:::

:::example[Worked Example — Bow firing sequence]
::::answer
Result: Arrow spawns at muzzle, travels 400 px/s toward enemy position at fire time.
::::

1. `on_equipped()` runs — resolves enemy ball, sets `_fire_timer = 1.5 * 0.6 = 0.9s` (random stagger).
2. 0.9 seconds pass in `_physics_process`.
3. `_try_fire()`: `spawn_pos = ball.global_position + (40, 0)`.
4. `direction = (enemy_ball.global_position - spawn_pos).normalized()` — a snapshot.
5. Arrow instantiated, added to Arena, `fire(direction, ball)` called.
6. Arrow's `linear_velocity = direction * 400`. Arrow sprite rotates to face direction.
7. Timer resets: `_fire_timer = 1.5`.
8. Next shot fires 1.5 s later, aimed at wherever the enemy ball is at that moment.
:::

## Fireball.tscn & Staff.tscn

Fireball is a heavier, slower projectile with more damage. Staff fires Fireballs at a
 slower rate than Bow fires Arrows. This demonstrates how the same RangedWeapon + ProjectileBase
 infrastructure supports entirely different projectile feels just by changing export values.

### Fireball exports

| Export | Arrow | Fireball |
| --- | --- | --- |
| speed | 400 | 220 |
| damage | 15 | 35 |
| lifetime | 3.0 | 4.0 |
| CollisionShape | Capsule (4×16) | Circle (radius 12) |
| Sprite | Arrow image | Glowing orb / flame sprite |

### Staff exports

| Export | Bow | Staff |
| --- | --- | --- |
| projectile\_scene | Arrow.tscn | Fireball.tscn |
| fire\_rate | 1.5 s | 2.5 s |
| muzzle\_offset | (40, 0) | (44, 0) |
| damage | 15 | 35 |

Fireball.tscn and Staff.tscn are constructed identically to Arrow.tscn and Bow.tscn —
 same node types, different export values and sprites. No new code is required.
 This is the key benefit of the equipment hierarchy: **new weapons are data, not code.**

:::callout-connect[CONNECTION]
The same pattern extends indefinitely. A Shotgun fires 5 Arrows simultaneously in a spread.
        Implement this by overriding

\_try\_fire()

in a subclass and calling

super.\_try\_fire()

five times with slightly different angle offsets.
        A Boomerang would need a custom ProjectileBase subclass that curves back — but
        RangedWeapon doesn't change at all.
:::

## Physics Layer 4 — Projectiles

In Ch 70C we set up Layers 1–3. Layer 4 (Projectiles) was reserved for this chapter.
 Here is the complete 4-layer matrix with projectiles included:

| Layer | Name | Nodes on this layer | Mask (collides with) |
| --- | --- | --- | --- |
| 1 | Balls | Ball RigidBody2D | 1, 2 |
| 2 | Walls | Arena StaticBody2D | 1, 4 |
| 3 | WeaponHitbox | Melee weapon Area2D | 1, 3 |
| 4 | Projectiles | Projectile RigidBody2D, Projectile Hitbox Area2D | 1, 2 |

:::callout-pitfall[PITFALL]
If projectile Mask includes Layer 3, a projectile will "hit" every melee weapon it
        passes through, dealing damage to the wrong target or triggering phantom parry events.
        Projectile Mask must be Layers 1+2 only. Projectiles pass through weapon hitboxes
        as if they don't exist.
:::

:::callout-pitfall[PITFALL]
If Wall Mask doesn't include Layer 4, projectiles travel straight through walls.
        Update Wall nodes (StaticBody2D) to add Layer 4 to their Mask so projectiles
        physically collide with them.
:::

## SpecialAbility — Trigger-Based Equipment

:::callout-intuition[INTUITION]
Some equipment doesn't act constantly — it waits for a condition and then fires once.
        A dash ability activates when the ball has bounced N times. A shield activates when HP
        drops below 30%. These are SpecialAbility subclasses: they override

on\_ball\_bounced()

or

on\_hp\_changed()

to watch for their
        trigger, then execute their effect.
:::

```gdscript
class_name SpecialAbility
extends EquipmentBase

## Override in subclass to define when the ability fires.
func _should_trigger() -> bool:
    return false

## Override in subclass to define what happens.
func _execute() -> void:
    pass

## Override on_ball_bounced, on_hit_landed, etc. to call _should_trigger.
## Example: activate on bounce count threshold.
func on_ball_bounced() -> void:
    if _should_trigger():
        _execute()
```

### Example: SpeedBurst ability

After every 5 bounces, the ball gets a 2-second speed boost by increasing its
 linear\_velocity magnitude.

```gdscript
class_name SpeedBurst
extends SpecialAbility

var _bounce_count: int = 0
var _is_active: bool = false

func on_ball_bounced() -> void:
    _bounce_count += 1
    if _should_trigger():
        _execute()

func _should_trigger() -> bool:
    return _bounce_count % 5 == 0   # every 5th bounce

func _execute() -> void:
    if _is_active:
        return
    _is_active = true
    ## Double current speed for 2 seconds.
    ball.linear_velocity *= 2.0
    await get_tree().create_timer(2.0).timeout
    ball.linear_velocity *= 0.5    ## restore
    _is_active = false
```

:::callout-warning[WARNING]
Using

await

inside a method that could be called from

on\_ball\_bounced()

is safe in GDScript — the coroutine runs asynchronously
        without blocking the physics thread. The

\_is\_active

guard prevents
        overlapping activations if 5 bounces occur within the 2-second boost window.
:::

## PassiveEffect — Always-On Modifiers

:::callout-intuition[INTUITION]
Some equipment items don't do anything actively — they just make the ball better.
        A Regen Ring restores 1 HP per second continuously. A Speed Boots item increases
        launch\_speed permanently. These are PassiveEffect subclasses: they apply their
        effect once in

on\_equipped()

and optionally reverse it in `on_unequipped()`.
:::

```gdscript
class_name PassiveEffect
extends EquipmentBase

## PassiveEffect base has nothing to do — subclasses put their
## setup in on_equipped() and cleanup in on_unequipped().

func on_equipped() -> void:
    pass   # override

func on_unequipped() -> void:
    pass   # override
```

### Example: RegenRing

```gdscript
class_name RegenRing
extends PassiveEffect

@export var hp_per_second: float = 1.0

var _regen_timer: float = 0.0

func on_equipped() -> void:
    ## Start ticking. We use _physics_process from EquipmentBase
    ## (which is a Node2D, so _physics_process is available).
    set_physics_process(true)

func _physics_process(delta: float) -> void:
    _regen_timer += delta
    if _regen_timer >= 1.0:
        _regen_timer -= 1.0
        ball.health_component.apply_healing(hp_per_second)

func on_unequipped() -> void:
    set_physics_process(false)
```

:::callout-tip[TIP]
HealthComponent needs an

apply\_healing(amount)

method that adds HP up to
        max\_hp and emits `hp_changed`. This is symmetric with

apply\_damage()

and is straightforward to add in Ch 70D.
:::

:::example[Worked Example — equipping a ball with Bow + RegenRing simultaneously]
::::answer
Result: ball fires Arrows every 1.5s AND regenerates 1 HP/s, with no code changes to Ball.gd.
::::

In Arena.gd, change the loadout:

```gdscript
const BOW_SCENE:       PackedScene = preload("res://scenes/weapons/Bow.tscn")
const REGEN_RING_SCENE: PackedScene = preload("res://scenes/weapons/RegenRing.tscn")

var left_loadout: Array[PackedScene] = [BOW_SCENE, REGEN_RING_SCENE]
```

Ball.\_ready() calls \_attach\_equipment(), which instantiates both. Bow enters its
 fire loop. RegenRing starts its HP tick. Both run independently — they never interact
 with each other, only with the ball they share.
:::

## Practice Problems

:::problem{difficulty="easy"}
**1.**
 Why must projectiles be added as children of Arena, not as children of the firing ball?

::::solution[Solution]
A child node's global position is relative to its parent. If the projectile is a
 child of Ball, it moves with the ball every frame, so it can never travel independently.
 Parenting to Arena makes it independent of the ball's position after spawning.
::::
:::

:::problem{difficulty="easy"}
**2.**
 What does `owner_ball` prevent in ProjectileBase?

::::solution[Solution]
It prevents the projectile from dealing damage to the ball that fired it.
 Without this guard, an arrow spawned at the ball's edge would immediately detect
 the firing ball's own CollisionShape2D and deal damage to its owner.
::::
:::

:::problem{difficulty="standard"}
**3.**
 Explain why RangedWeapon aims at a *snapshot* of the enemy's current position
 rather than predicting where the enemy will be when the projectile arrives.

::::solution[Solution]
Law 2 (no AI steering) means we do not compute trajectories or predict future
 positions. A snapshot aims where the enemy *is* right now. If the enemy
 bounces between fire and impact, the shot misses — creating natural variability.
 Prediction would make ranged weapons too reliable and reduce the chaos that makes
 the simulation interesting to watch.
::::
:::

:::problem{difficulty="standard"}
**4.**
 A Fireball has speed=220 and the arena is 1080 px wide. How many seconds does it take
 to cross the full arena width in the worst case (corner to corner,
 $\approx 1080\sqrt{2}$ px)?

::::solution[Solution]
Diagonal distance: $1080\sqrt{2} \approx 1527$ px.

Time: $\dfrac{1527}{220} \approx 6.9$ seconds.

Since `lifetime = 4.0`, a corner-to-corner Fireball would expire
 before reaching the target. In practice the arena is smaller than the full viewport
 (walls are inset), so most shots land within 2–3 seconds. Setting lifetime to 5.0
 would be safer for diagonal shots.
::::
:::

:::problem{difficulty="standard"}
**5.**
 The random stagger in `on_equipped()` sets the initial fire timer to
 `fire_rate * randf_range(0.3, 0.9)`. Why is this important when both
 balls carry bows?

::::solution[Solution]
Without stagger, both balls fire at exactly the same moment on every tick.
 This makes the fight perfectly symmetric and visually monotonous — arrows always
 cross each other mid-arena. The stagger desynchronises the two fire timers so one
 ball typically fires 0.3–0.9× fire\_rate before the other, making the exchange
 asymmetric and more dynamic.
::::
:::

:::problem{difficulty="standard"}
**6.**
 A Shotgun weapon fires 5 arrows simultaneously in a ±20° spread around the target
 direction. Write the `_try_fire()` override in a `Shotgun`
 class that extends RangedWeapon.

::::solution[Solution]
```gdscript
class_name Shotgun
extends RangedWeapon

func _try_fire() -> void:
    if projectile_scene == null or _enemy_ball == null:
        return
    var arena := ball.get_parent()
    var spawn_pos := ball.global_position + muzzle_offset
    var base_dir := (_enemy_ball.global_position - spawn_pos).normalized()
    var base_angle := base_dir.angle()
    var spread_angles := [-40.0, -20.0, 0.0, 20.0, 40.0]   # degrees
    for offset_deg in spread_angles:
        var angle := base_angle + deg_to_rad(offset_deg)
        var direction := Vector2(cos(angle), sin(angle))
        var proj: ProjectileBase = projectile_scene.instantiate()
        arena.add_child(proj)
        proj.global_position = spawn_pos
        proj.fire(direction, ball)
```

No changes to ProjectileBase, RangedWeapon, or any other class are required.
::::
:::

:::problem{difficulty="challenge"}
**7.**
 Design a `Boomerang` projectile that curves back toward the firing ball
 after 1.5 seconds. What class should it extend, what new variable does it need,
 and how does it change direction?

::::solution[Solution]
```gdscript
class_name Boomerang
extends ProjectileBase

var _elapsed: float = 0.0
const RETURN_TIME: float = 1.5

func _physics_process(delta: float) -> void:
    _elapsed += delta
    if _elapsed >= RETURN_TIME and owner_ball != null:
        ## Redirect toward owner_ball each frame (gentle homing on return).
        var return_dir := (owner_ball.global_position \
                           - global_position).normalized()
        linear_velocity = return_dir * speed

## Override hit check — on return, don't damage owner.
## (The base class already guards against owner_ball damage,
## so the return phase is already safe.)
```

The boomerang extends ProjectileBase (inheriting all hit/damage logic).
 It adds `_elapsed` to track time since launch. After RETURN\_TIME,
 it overrides `linear_velocity` each frame to home toward the owner.
 The owner-ball guard in the base class prevents self-damage on return. No changes
 to RangedWeapon are needed — assign `Boomerang.tscn` as the
 `projectile_scene`.
::::
:::

:::problem{difficulty="challenge"}
**8.**
 A ball has three items: Sword, Bow, and RegenRing. List every signal connection
 that exists at the start of the FIGHTING state, and which object is the subscriber
 for each.

::::solution[Solution]
| Signal emitter | Signal | Subscriber | Handler |
| --- | --- | --- | --- |
| Ball | bounced | Sword (MeleeWeapon) | \_on\_ball\_bounced → spin reversal |
| Ball | died | GameManager | on\_ball\_died |
| HealthComponent | hp\_changed | Ball | \_on\_hp\_changed → HPLabel update |
| HealthComponent | died | Ball | \_on\_died → re-emits ball.died |
| Sword Hitbox | area\_entered | Sword | \_on\_hitbox\_area\_entered → damage/parry |

Bow uses `_physics_process` timer — no signal. RegenRing uses
 `_physics_process` tick — no signal. These are pull-based (delta
 polling) rather than push-based (signals).
::::
:::

## Chapter Summary

:::summary
### Key Concepts

| Concept | Implementation |
| --- | --- |
| ProjectileBase | RigidBody2D, Layer 4, Mask 1+2; auto-frees on hit or lifetime |
| owner\_ball guard | Prevents projectile from damaging its own firing ball |
| Projectile lifetime | `create_timer(lifetime).timeout.connect(queue_free)` |
| RangedWeapon | Extends EquipmentBase; fires projectile\_scene on fire\_rate timer |
| Snapshot aiming | Direction = enemy position at fire moment; no prediction/homing |
| Fire stagger | Random initial timer offset prevents both balls firing simultaneously |
| Arena parenting | Projectiles added to Arena, never to ball — must move independently |
| New weapon = data | Arrow→Fireball, Bow→Staff differ only in exports and sprites |
| SpecialAbility | Extends EquipmentBase; \_should\_trigger + \_execute pattern |
| PassiveEffect | Applies effect once in on\_equipped; uses \_physics\_process for ticks |
:::

### What's next?

Ch 70G builds out the full weapon roster — a table of all planned melee weapons, ranged
 weapons, abilities, and passives with their stat sheets. Ch 70H covers polish: hit sparks,
 screen shake, motion trails, audio, and the YouTube Shorts export settings for 1080×1080
 vertical video.
