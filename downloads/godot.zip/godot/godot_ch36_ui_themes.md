---
title: "UI Themes & Styling"
source: "godot_ch36_ui_themes.html"
---

Part IV · Chapter 36

# UI Themes & Styling

Prerequisite: Ch 8 (Control nodes & UI basics) · est. 75 min

## Overview

Godot's UI theming system lets you define the visual appearance of every
 control node — button colours, border radii, font sizes, padding — in one
 place, and have it propagate automatically through the scene tree. Instead
 of setting a `Button`'s background colour directly on every
 instance, you define a theme that any button inherits.

The system is composed of three interlocking concepts:

- **Theme resource** — a dictionary of typed visual properties
 keyed by control class name and item name.
- **StyleBox** — a paintable background/border shape (flat
 colour, texture, or line) that controls how panels and buttons look.
- **Theme lookup chain** — the engine walks the scene tree
 upward looking for the nearest `Theme` that defines a
 property; this is how a single theme at the root styles the entire UI.

By the end of the chapter you will be able to build a complete game UI
 skin, switch between skins at runtime, override individual controls, and
 create scalable UI art with `NinePatchRect`.

## 1 · Theme Resource

### 1.1 · Theme lookup chain

When a `Control` node needs to draw itself, it looks for a
 theme property by walking up the scene tree:

1. **Node-local override** — properties set via
 `add_theme_*_override()` on the node itself.
2. **Node's own `theme` property** — if the node
 has a `Theme` resource assigned directly.
3. **Parent's theme**, then grandparent's, and so on up to
 the scene root.
4. **Project theme** — set in *Project Settings →
 General → GUI → Theme → Custom*.
5. **Default engine theme** — Godot's built-in fallback.

The practical consequence: assign one `Theme` resource to the
 root `CanvasLayer` or top-level `Control` of your
 UI, and every child inherits it automatically. Override specific nodes
 by either assigning a different theme to them or using per-node overrides.

:::callout-key[Key Concept]
A

Theme

is looked up, never copied.  Every

Control

node holds only a reference to a shared theme resource.  Changing one
        property in the theme file immediately updates every node that inherits it —
        no extra code needed.
:::

### 1.2 · Theme item types

A `Theme` resource stores properties keyed by
 `(type, name)`, where *type* is the control class name
 (e.g. `"Button"`, `"Label"`) and *name* is
 the property name. Each entry can hold one of six data types:

| Type | GDScript get/set | Common use |
| --- | --- | --- |
| `StyleBox` | `get_stylebox / set_stylebox` | Background, border, shadow of buttons, panels, etc. |
| `Font` | `get_font / set_font` | Custom typeface for labels, buttons |
| `int` (constant) | `get_constant / set_constant` | Spacing, separation, icon sizes |
| `float` | `get_font_size / set_font_size` | Font point size for a type |
| `Color` | `get_color / set_color` | Font colour, icon modulate |
| `Texture2D` | `get_icon / set_icon` | Default icons (e.g. checked checkbox) |

```gdscript
## Create a theme and configure a button's normal style.
var theme := Theme.new()

var sb := StyleBoxFlat.new()
sb.bg_color          = Color(0.15, 0.45, 0.85)
sb.corner_radius_top_left     = 6
sb.corner_radius_top_right    = 6
sb.corner_radius_bottom_left  = 6
sb.corner_radius_bottom_right = 6
sb.content_margin_left   = 16
sb.content_margin_right  = 16
sb.content_margin_top    = 8
sb.content_margin_bottom = 8

theme.set_stylebox("normal", "Button", sb)
theme.set_color("font_color", "Button", Color.WHITE)
theme.set_font_size("font_size", "Button", 15)

## Assign to a Control node to apply to all its children.
$UI.theme = theme
```

## 2 · StyleBox Types

A `StyleBox` is the fundamental paint unit of Godot's UI.
 Three concrete types cover almost all use cases:

### 2.1 · StyleBoxFlat — programmatic shapes

`StyleBoxFlat` draws a filled rounded rectangle with optional
 border, shadow, and anti-aliasing. Every visual property is specified
 in code or the Inspector — no art assets needed.

| Property | Type | Description |
| --- | --- | --- |
| `bg_color` | `Color` | Fill colour |
| `border_color` | `Color` | Outline colour |
| `border_width_*` | `int` | Per-side border thickness in px |
| `corner_radius_*` | `int` | Per-corner rounding in px |
| `shadow_color` | `Color` | Drop shadow colour (alpha 0 = no shadow) |
| `shadow_size` | `int` | Shadow blur radius in px |
| `shadow_offset` | `Vector2` | Shadow offset from shape |
| `content_margin_*` | `float` | Inner padding applied before content draws |
| `anti_aliasing` | `bool` | Smooth edges (default true) |

```gdscript
## Helper: build a standard flat button StyleBox.
static func make_flat_btn(bg: Color, border: Color = Color.TRANSPARENT,
                          radius: int = 6, pad_h: int = 16,
                          pad_v: int = 8) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color    = bg
    sb.border_color = border
    sb.set_border_width_all(1 if border.a > 0.0 else 0)
    sb.set_corner_radius_all(radius)
    sb.content_margin_left   = pad_h
    sb.content_margin_right  = pad_h
    sb.content_margin_top    = pad_v
    sb.content_margin_bottom = pad_v
    return sb
```

Buttons have multiple state styleboxes — all should be defined for a
 polished result:

| StyleBox name | Button state |
| --- | --- |
| `"normal"` | Default, not hovered or pressed |
| `"hover"` | Mouse is over the button |
| `"pressed"` | Button is held down |
| `"focus"` | Keyboard / gamepad focus ring |
| `"disabled"` | `disabled = true` |
| `"hover_pressed"` | Held and hovered simultaneously |

### 2.2 · StyleBoxTexture — sprite-based skins

`StyleBoxTexture` draws a `Texture2D` as the
 background, with optional nine-patch stretching to allow the texture to
 scale cleanly. Use this when you have art assets for your UI.

```gdscript
var sb := StyleBoxTexture.new()
sb.texture = preload("res://ui/btn_normal.png")
# Nine-patch margins — how many pixels from each edge are not stretched.
sb.texture_margin_left   = 8
sb.texture_margin_right  = 8
sb.texture_margin_top    = 8
sb.texture_margin_bottom = 8
sb.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
sb.axis_stretch_vertical   = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
```

### 2.3 · StyleBoxLine — separators

`StyleBoxLine` draws a thin horizontal or vertical rule.
 It is the default background for `HSeparator` /
 `VSeparator` nodes:

```gdscript
var sep := StyleBoxLine.new()
sep.color     = Color(1, 1, 1, 0.1)
sep.thickness = 1
sep.vertical  = false   # horizontal line
theme.set_stylebox("separator", "HSeparator", sep)
```

## 3 · Fonts in Themes

### 3.1 · Per-control font overrides

Every `Control` that renders text exposes font theme items.
 Set them on the theme to apply globally, or use per-node overrides for
 special elements like headings:

```gdscript
var heading_font := FontFile.new()
heading_font.load_dynamic_font("res://fonts/Roboto-Bold.ttf")

## Global default for all Labels.
theme.set_font("font",      "Label", preload("res://fonts/Roboto-Regular.ttf"))
theme.set_font_size("font_size", "Label", 16)

## Per-node override — only this Label uses the heading font.
$TitleLabel.add_theme_font_override("font",      heading_font)
$TitleLabel.add_theme_font_size_override("font_size", 28)
```

### 3.2 · FontVariation for bold/italic without extra files

`FontVariation` wraps a `FontFile` and applies
 OpenType variations or emulated bold/italic transformations. Use it to
 derive bold and italic styles from a single variable font file:

```gdscript
var base_font := preload("res://fonts/Inter-Variable.ttf") as FontFile

## Emulated bold — increases stroke weight synthetically.
var bold_font := FontVariation.new()
bold_font.base_font    = base_font
bold_font.variation_embolden = 1.2   # 0 = normal, positive = bolder

## OpenType weight axis (for variable fonts that support it).
var heavy_font := FontVariation.new()
heavy_font.base_font = base_font
heavy_font.variation_opentype = { "wght": 800 }  # 400 = regular, 700 = bold, 900 = black

theme.set_font("bold_font", "RichTextLabel", bold_font)
```

## 4 · ThemeDB Singleton

`ThemeDB` is the global manager for the default and project
 themes. It provides read and write access without needing a reference
 to a specific node:

| Method | Description |
| --- | --- |
| `ThemeDB.get_default_theme()` | Returns the engine's built-in fallback theme (always present) |
| `ThemeDB.get_project_theme()` | Returns the project theme set in Project Settings (may be null) |
| `ThemeDB.set_fallback_base_scale(scale)` | Scale factor applied to the engine fallback theme — useful for DPI scaling. (`set_default_base_scale` is on `Theme`, not `ThemeDB`, and sets one theme’s own scale) |
| `ThemeDB.set_fallback_font(font)` | Sets the absolute fallback font used when no other font is found |
| `ThemeDB.set_fallback_font_size(size)` | Sets the absolute fallback font size |

### 4.1 · Modifying the default theme

You can mutate the default theme in your autoload's `_ready()`
 to apply global tweaks without creating a full theme file. This is the
 approach used in Chapter 34 for scalable font size:

```gdscript
func _apply_ui_scale(scale: float) -> void:
    # Scale factor for the engine fallback theme's constants (padding, spacing).
    ThemeDB.set_fallback_base_scale(scale)
    # Also scale font sizes if your theme doesn't define them explicitly.
    var theme: Theme = ThemeDB.get_default_theme()
    theme.set_font_size("font_size", "Label",  int(16 * scale))
    theme.set_font_size("font_size", "Button", int(15 * scale))
```

### 4.2 · Project theme vs node theme

The **project theme** (set in Project Settings) applies to
 every scene without any per-scene setup. It is the right place for your
 game's base visual identity. **Node themes** override it for
 specific sub-trees — useful for a "dark mode" pause menu within a
 light-coloured game world.

:::callout-tip[Tip — theme inheritance and null items]
A theme item only overrides a property if it is explicitly set in that
        theme.  An item that is absent is

not

treated as "use black" —
        it is treated as "look further up the chain."  This means you can create
        a minimal override theme that only sets three colours, and all other
        properties fall through to the parent or project theme unchanged.
:::

## 5 · Theming from Code

### 5.1 · add\_theme\_\*\_override methods

Every `Control` node exposes per-instance override methods that
 sit at the very top of the lookup chain. Use them for one-off styling
 without creating a theme file:

```gdscript
## StyleBox override — give this specific Panel a dark background.
var dark_panel := StyleBoxFlat.new()
dark_panel.bg_color = Color(0.05, 0.05, 0.08, 0.95)
dark_panel.set_corner_radius_all(8)
$DialogPanel.add_theme_stylebox_override("panel", dark_panel)

## Color override — make this Label red.
$ErrorLabel.add_theme_color_override("font_color", Color.RED)

## Font size override.
$ScoreLabel.add_theme_font_size_override("font_size", 32)

## Constant override — increase button separation in this HBoxContainer.
$ButtonRow.add_theme_constant_override("separation", 12)

## Remove an override to revert to theme inheritance.
$ErrorLabel.remove_theme_color_override("font_color")
```

### 5.2 · Theme type variations

Theme type variations let you define a subtype of a control — for example
 a `"DangerButton"` variant of `Button` — without
 writing a custom class. Assign the variation name to the node's
 *Theme Type Variation* property in the Inspector, then define
 theme items under the variation name:

```gdscript
## Define "DangerButton" variant styles in the theme.
var danger_normal := make_flat_btn(Color(0.75, 0.15, 0.15), Color.TRANSPARENT, 6)
var danger_hover  := make_flat_btn(Color(0.90, 0.20, 0.20), Color.TRANSPARENT, 6)
theme.set_stylebox("normal",  "DangerButton", danger_normal)
theme.set_stylebox("hover",   "DangerButton", danger_hover)
theme.set_stylebox("pressed", "DangerButton",
    make_flat_btn(Color(0.60, 0.10, 0.10), Color.TRANSPARENT, 6))
theme.set_color("font_color", "DangerButton", Color.WHITE)

## The DangerButton inherits all unset items from Button automatically.
## In the scene, just set the ThemeTypeVariation property to "DangerButton".
$DeleteButton.theme_type_variation = &"DangerButton"
```

:::callout-intuition[Intuition — variations vs subclasses]
A theme type variation is purely visual.  It does not add new behaviour or
        signals.  Use it when buttons look different but act the same.  If they need
        different logic (e.g. a

HoldButton

that requires a long press),
        extend

Button

in GDScript instead.
:::

## 6 · Dynamic Skin Switching

### 6.1 · SkinManager autoload

Storing multiple complete theme resources and swapping the project theme
 at runtime gives you a full skin system — dark mode, different visual
 styles for DLC, accessibility high-contrast mode:

```gdscript
## res://autoloads/skin_manager.gd
## Autoload name: SkinManager
extends Node

signal skin_changed(skin_name: String)

const SKINS: Dictionary = {
    "default":       preload("res://themes/theme_default.tres"),
    "dark":          preload("res://themes/theme_dark.tres"),
    "high_contrast": preload("res://themes/theme_high_contrast.tres"),
}

var current_skin: String = "default"

func _ready() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") == OK:
        var saved: String = cfg.get_value("ui", "skin", "default")
        apply_skin(saved)
    else:
        apply_skin("default")

func apply_skin(name: String) -> void:
    if not SKINS.has(name):
        push_error("SkinManager: unknown skin '%s'" % name)
        return
    current_skin = name
    # Replace the project theme — propagates to every Control node.
    ThemeDB.get_project_theme().merge(SKINS[name], true)
    skin_changed.emit(name)
    _save_skin(name)

func _save_skin(name: String) -> void:
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value("ui", "skin", name)
    cfg.save("user://settings.cfg")

func available_skins() -> Array[String]:
    return ["default", "dark", "high_contrast"]
```

:::callout-warning[Warning — Theme.merge overwrites]
Theme.merge\_with(other, deep\_copy)

copies all items from

other

into the target theme.  If items exist in the target but
        not in

other

, they remain unchanged.  For a clean skin swap
        where you want to guarantee the new skin takes full effect, clear the
        project theme first with

theme.clear()

then merge, or simply
        replace the theme reference directly via

get\_window().theme = SKINS[name]

.
:::

### 6.2 · NinePatchRect for scalable sprite-based UI

When your UI art is sprite-based, `NinePatchRect` lets a single
 texture scale to any size without distorting its corners. The texture is
 divided into a 3×3 grid; the four corners are never scaled, the four edges
 are scaled in one direction, and the centre is tiled or stretched.

```gdscript
## Configure a NinePatchRect to use a panel texture.
var npr: NinePatchRect = $PanelNine
npr.texture = preload("res://ui/panel_bg.png")
# Pixel distances from each edge that define the non-scaled corners.
npr.patch_margin_left   = 12
npr.patch_margin_right  = 12
npr.patch_margin_top    = 12
npr.patch_margin_bottom = 12
# How the centre region fills — STRETCH or TILE.
npr.axis_stretch_horizontal = NinePatchRect.AXIS_STRETCH_MODE_STRETCH
npr.axis_stretch_vertical   = NinePatchRect.AXIS_STRETCH_MODE_STRETCH
```

For themed panels, wrap the `NinePatchRect` inside a
 `StyleBoxTexture` as covered in Section 2.2. That way you
 get the nine-patch scaling behaviour while still benefiting from the
 theme inheritance chain.

:::callout-connect[Connection — nine-patch & shaders]
StyleBoxTexture

and

NinePatchRect

do not support

ShaderMaterial

natively.  For animated or shader-driven UI
        panels (scanline effect, glow border), use a regular

TextureRect

or

ColorRect

with a shader and position it behind your content
        manually.
:::

## Summary

Godot's theme system is a cascade: local overrides win over node themes,
 which win over the project theme, which wins over the engine default.
 Every `Theme` stores typed items (StyleBox, Font, Color, int,
 float, Texture2D) keyed by control class and item name.
 `StyleBoxFlat` produces code-driven rounded rectangles with
 borders and shadows; `StyleBoxTexture` wraps art assets with
 nine-patch scaling; `StyleBoxLine` draws separators.
 Fonts are set per-control-type in the theme and can be derived from a
 single variable font file using `FontVariation`.
 `ThemeDB` provides global access to the default and project
 themes without scene-tree references.
 Per-node overrides (`add_theme_*_override`) sit above all
 theme lookups. Theme type variations define named visual subtypes
 of controls (e.g. `"DangerButton"`) without subclassing.
 A `SkinManager` autoload swaps the project theme at runtime
 for full skin support. `NinePatchRect` scales a single
 texture to any size by keeping its corners intact.

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Hover highlight.**
 Write a function `make_highlight_button_theme() -> Theme`
 that returns a `Theme` where a `Button`'s
 `"hover"` StyleBox is slightly brighter than
 `"normal"`: normal is `Color(0.2, 0.2, 0.25)`
 and hover is `Color(0.3, 0.3, 0.38)`, both with corner
 radius 5 and horizontal padding 14, vertical padding 7.

::::solution[Solution]
```gdscript
func make_highlight_button_theme() -> Theme:
    var theme := Theme.new()
    for data in [
        ["normal",  Color(0.2, 0.2, 0.25)],
        ["hover",   Color(0.3, 0.3, 0.38)],
        ["pressed", Color(0.15, 0.15, 0.20)],
    ]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = data[1]
        sb.set_corner_radius_all(5)
        sb.content_margin_left   = 14
        sb.content_margin_right  = 14
        sb.content_margin_top    = 7
        sb.content_margin_bottom = 7
        theme.set_stylebox(data[0], "Button", sb)
    theme.set_color("font_color", "Button", Color.WHITE)
    return theme
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Dynamic font colour.**
 Given an `HSlider` whose value represents a percentage
 (0–100), write a script that changes a companion `Label`'s
 font colour: green for ≥ 66, yellow for 33–65, red for < 33. Use
 `add_theme_color_override()`. Connect to
 `value_changed`.

::::solution[Solution]
```gdscript
@onready var _slider: HSlider = $HSlider
@onready var _label:  Label   = $Label

func _ready() -> void:
    _slider.value_changed.connect(_on_value_changed)
    _on_value_changed(_slider.value)

func _on_value_changed(v: float) -> void:
    var col: Color
    if v >= 66.0:
        col = Color(0.2, 0.85, 0.3)    # green
    elif v >= 33.0:
        col = Color(1.0, 0.75, 0.1)   # yellow
    else:
        col = Color(0.9, 0.2, 0.2)    # red
    _label.add_theme_color_override("font_color", col)
    _label.text = "%d%%" % int(v)
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Focus ring.**
 Design a `StyleBoxFlat` for a keyboard focus indicator on
 buttons: transparent fill, 2 px solid white border with alpha 0.8,
 corner radius 7, and an outer shadow of size 4 with a cyan glow
 colour (`Color(0.3, 0.9, 1.0, 0.5)`). Assign it to the
 `"focus"` stylebox for `"Button"` in a theme.

::::solution[Solution]
```gdscript
func make_focus_ring() -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0, 0, 0, 0)       # transparent fill
    sb.border_color = Color(1, 1, 1, 0.8)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(7)
    sb.shadow_color  = Color(0.3, 0.9, 1.0, 0.5)
    sb.shadow_size   = 4
    sb.shadow_offset = Vector2.ZERO
    return sb

## Apply:
theme.set_stylebox("focus", "Button", make_focus_ring())
```
::::
:::

:::problem{difficulty="standard"}
**P4 — "Danger" variation.**
 Using the theme type variation system, define a `"DangerButton"`
 variant with a deep-red normal state, a brighter-red hover, a darkened-red
 pressed state, and white font. All unset items should fall through to
 the base `"Button"` style. Write the GDScript to create
 and register these items in a `Theme`, then show how to
 apply the variation to a specific button node.

::::solution[Solution]
```gdscript
func register_danger_button(theme: Theme) -> void:
    var states := {
        "normal":  Color(0.65, 0.10, 0.10),
        "hover":   Color(0.80, 0.18, 0.18),
        "pressed": Color(0.50, 0.07, 0.07),
    }
    for state in states:
        var sb := StyleBoxFlat.new()
        sb.bg_color = states[state]
        sb.set_corner_radius_all(6)
        sb.content_margin_left   = 16
        sb.content_margin_right  = 16
        sb.content_margin_top    = 8
        sb.content_margin_bottom = 8
        theme.set_stylebox(state, "DangerButton", sb)
    theme.set_color("font_color", "DangerButton", Color.WHITE)
    # All other items (font, constants, focus stylebox) fall through to "Button".

## Applying to a node:
$DeleteBtn.theme_type_variation = &"DangerButton"
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Animated StyleBox border.**
 Using a `Tween`, animate the border colour of a
 `StyleBoxFlat` that is applied as a per-node override to a
 `Panel` node. The border should cycle through hues
 continuously (rainbow effect) by calling
 `Color.from_hsv(hue, 0.8, 1.0)` with an incrementing hue
 in a looping tween using `tween_method()`. The
 StyleBoxFlat should have a 3 px border and transparent fill.

::::solution[Solution]
```gdscript
## Attach to the Panel node.
extends Panel

var _sb: StyleBoxFlat

func _ready() -> void:
    _sb = StyleBoxFlat.new()
    _sb.bg_color = Color(0, 0, 0, 0)
    _sb.set_border_width_all(3)
    _sb.set_corner_radius_all(6)
    add_theme_stylebox_override("panel", _sb)

    var tw: Tween = create_tween().set_loops()
    tw.tween_method(_set_border_hue, 0.0, 1.0, 3.0).set_trans(Tween.TRANS_LINEAR)

func _set_border_hue(hue: float) -> void:
    _sb.border_color = Color.from_hsv(hue, 0.8, 1.0)
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Complete game theme builder.**
 Write a `GameThemeBuilder` class (plain GDScript, not a
 Node) with a static `build(accent: Color) -> Theme` method
 that constructs a full dark-UI game theme parameterised by an accent
 colour. Include: Button normal/hover/pressed/focus/disabled styles;
 Label font colour (white) and size (15); Panel background (dark grey
 with subtle border); ProgressBar fill colour (accent) and background
 (dark); HSeparator; and HSlider grabber (accent-coloured circle).
 All styleboxes should use consistent 6px corner radii.

::::solution[Solution]
```gdscript
class_name GameThemeBuilder

static func build(accent: Color) -> Theme:
    var t := Theme.new()
    var R := 6   # corner radius
    var dark    := Color(0.10, 0.10, 0.13, 1.0)
    var darker  := Color(0.07, 0.07, 0.09, 1.0)
    var border  := Color(1, 1, 1, 0.08)
    var white   := Color.WHITE
    var grey    := Color(0.5, 0.5, 0.5, 0.6)
    var accent_dim := accent.darkened(0.3)

    # ── Button ─────────────────────────────────────────────────────────────
    var btn_states := {
        "normal":   dark,
        "hover":    Color(dark.r + 0.06, dark.g + 0.06, dark.b + 0.07),
        "pressed":  accent_dim,
        "disabled": Color(dark.r, dark.g, dark.b, 0.4),
    }
    for state in btn_states:
        var sb := StyleBoxFlat.new()
        sb.bg_color = btn_states[state]
        sb.set_corner_radius_all(R)
        sb.border_color = border; sb.set_border_width_all(1)
        sb.content_margin_left = 16; sb.content_margin_right = 16
        sb.content_margin_top  = 8;  sb.content_margin_bottom = 8
        t.set_stylebox(state, "Button", sb)
    var focus_sb := StyleBoxFlat.new()
    focus_sb.bg_color = Color(0,0,0,0)
    focus_sb.border_color = accent; focus_sb.set_border_width_all(2)
    focus_sb.set_corner_radius_all(R)
    focus_sb.shadow_color = Color(accent.r, accent.g, accent.b, 0.4)
    focus_sb.shadow_size  = 4
    t.set_stylebox("focus", "Button", focus_sb)
    t.set_color("font_color",          "Button", white)
    t.set_color("font_disabled_color", "Button", grey)
    t.set_font_size("font_size", "Button", 15)

    # ── Label ────────────────────────────────────────────────────────────
    t.set_color("font_color",   "Label", white)
    t.set_font_size("font_size","Label", 15)

    # ── Panel ────────────────────────────────────────────────────────────
    var panel_sb := StyleBoxFlat.new()
    panel_sb.bg_color = darker
    panel_sb.set_corner_radius_all(R)
    panel_sb.border_color = border; panel_sb.set_border_width_all(1)
    t.set_stylebox("panel", "Panel", panel_sb)

    # ── ProgressBar ──────────────────────────────────────────────────────
    var pb_bg := StyleBoxFlat.new(); pb_bg.bg_color = darker
    pb_bg.set_corner_radius_all(3)
    var pb_fill := StyleBoxFlat.new(); pb_fill.bg_color = accent
    pb_fill.set_corner_radius_all(3)
    t.set_stylebox("background", "ProgressBar", pb_bg)
    t.set_stylebox("fill",       "ProgressBar", pb_fill)
    t.set_color("font_color",    "ProgressBar", white)

    # ── HSeparator ───────────────────────────────────────────────────────
    var sep := StyleBoxLine.new()
    sep.color = border; sep.thickness = 1
    t.set_stylebox("separator", "HSeparator", sep)

    # ── HSlider grabber ──────────────────────────────────────────────────
    var grab := StyleBoxFlat.new()
    grab.bg_color = accent; grab.set_corner_radius_all(8)
    grab.set_border_width_all(0)
    t.set_stylebox("grabber_area", "HSlider", grab)

    return t
```
::::
:::
