---
title: "The Free Shelf — Tutorials, Sites, Jams and How to Read an Outdated One"
crumb: "Godot 4.x Textbook · Appendix C"
meta:
  - "Every link checked September 2026"
  - "Free only — nothing here has a paywall"
  - "Godot 4.7.2 was current when this was written"
source: "markdown"
---

Appendix C

# The Free Shelf

Free Godot tutorials, sites, jams and communities worth your time · checked September 2026

## How to Use This Appendix

This book is written to be the thing you read. This appendix is for the other
thing you need, which is *watching someone else's hands*. Reading how a
`CharacterBody2D` resolves a slide is not the same experience as watching a
person drag one into a scene, get the friction wrong, and fix it on camera —
and no amount of prose substitutes for that.

So this is a shelf, not a syllabus. Nothing here is required, nothing here is
paid, and everything here was opened and confirmed to exist in September 2026.

:::callout-key[The only rule]
**Check the version stamp before you follow anything.** Godot's stable line is
4.7.2 as of August 2026, and the 4.x series has broken source compatibility at
least once in a way that silently ruins a tutorial follow-along. Section 1 is
the decoder. Read it before you start a series recorded more than a year ago.
:::

## 1 · The Version Stamp

The single most common way a beginner gets stuck is not misunderstanding the
material. It is following a tutorial recorded against an older engine, typing
exactly what is on screen, and getting an error that the tutorial never
mentions because it did not exist yet.

### Godot 3 to Godot 4

Anything recorded before 2023 is Godot 3, and Godot 3 code will not run. The
renames are mechanical, and the editor will offer to do most of them for you
when it opens an old project. The ones you will meet in the first hour:

| Godot 3 | Godot 4 |
| --- | --- |
| `Spatial` | `Node3D` |
| `KinematicBody` / `KinematicBody2D` | `CharacterBody3D` / `CharacterBody2D` |
| `PackedScene.instance()` | `PackedScene.instantiate()` |
| `translation`, `global_translation` (3D) | `position`, `global_position` |
| `yield(get_tree().create_timer(1.0), "timeout")` | `await get_tree().create_timer(1.0).timeout` |

The pattern behind the first two rows is worth internalising, because it
predicts renames this table does not list: in Godot 3, 2D nodes carried a `2D`
suffix and 3D nodes carried nothing. In Godot 4 both carry a suffix. If a
tutorial names a node with no dimension on the end and it does not resolve,
try it with `3D` appended.

The `yield` row is the one that reads *better* after the change rather than
merely differently — Godot 4 waits on `object.signal_name` directly instead of
a signal name written as a string, so a mistyped signal name is caught when the
script is parsed rather than at three in the morning.

:::callout-tip[The full list is in the engine, not the docs]
Godot's automatic project upgrade is driven by a rename table compiled into
the editor itself (`editor/project_upgrade/renames_map_3_to_4.cpp` in the
engine source). When a name from a tutorial does not resolve and you want the
authoritative answer rather than a guess, that file is the complete list of
every rename the upgrade tool performs.
:::

### Inside Godot 4: the TileMap break

Godot 4.3, released 15 August 2024, deprecated the `TileMap` node and replaced
it with `TileMapLayer`. This one catches people because both the old and the
new approach still *work* — the deprecated node was kept — so nothing errors.
You simply end up building a 2D world in a shape the whole ecosystem has moved
away from, and every tutorial and plugin you meet afterwards assumes the other
one.

| Before 4.3 | 4.3 and later |
| --- | --- |
| One `TileMap` node holding layers internally | One `TileMapLayer` node per layer |
| Layers added in the inspector, switched by tabs under the viewport | Layers are scene-tree nodes like anything else |
| The `TileSet` lives on the one node | One `TileSet` resource shared across the layer nodes |

The editor converts for you: select the `TileMap` node and use the conversion
entry in its dropdown menu. Chapter 9 covers `TileMapLayer` as the supported
way to build tile-based worlds, which is why that chapter is named after the
node rather than after the feature.

:::callout-pitfall[Pitfall: "it works, so it must be current"]
A deprecated node that still functions is more dangerous than one that errors.
`TileMap` will keep loading and will never gain another feature. If a series
you are following puts a single `TileMap` in the scene, it predates August
2024 — which tells you something about every *other* API it uses too.
:::

## 2 · Start Here

The goal of this section is not to survey the field. It is to get you to
**finish one thing**, because the gap between people who learn Godot and people
who bounce off it is almost entirely the gap between starting six tutorials and
completing one.

So pick the row that matches the time you actually have and the way you
actually learn, and ignore the rest until it is done.

| If you want | Start with | Time | Recorded against |
| --- | --- | --- | --- |
| One finished game tonight | Brackeys, *How to make a Video Game* | ~1h 17m | Godot 4, April 2024 |
| One finished game this afternoon | GDQuest, *Your First 2D Game From Zero* | ~2h | Godot 4.1, updated to 4.6 |
| A real course, taken slowly | Clear Code, *The new ultimate introduction to Godot* | very long | Godot 4, October 2025 |
| To learn programming itself first | GDQuest, *Learn GDScript From Zero* | 27 lessons | Godot 4, interactive |
| To read rather than watch | The official *Your first 2D game* | an evening | Always current |

#### Brackeys — *How to make a Video Game: Godot Beginner Tutorial*

<https://www.youtube.com/watch?v=LOhfqjmasi0> · published 28 April 2024 ·
[the rest of the series](https://www.youtube.com/playlist?list=PLPdCd0OwI4tYlJI85Oxx__BJOY9WfI7Jl)

The canonical first tutorial. Brackeys spent years as the biggest game-dev
teaching channel on YouTube, stopped in 2020, and returned in 2024 aimed at
Godot 4. About an hour and seventeen minutes, taking you from an empty project
to an exported 2D platformer with a player, tiles, collectibles, an enemy, a
score, death and respawn, sound, and an export build.

Watch this one first because it is short enough to finish in an evening, and
finishing something is the skill being taught.

#### GDQuest — *Your First 2D Game From Zero* (Vampire-Survivors style)

<https://www.youtube.com/watch?v=GwCiGixlqiU> ·
[written version and project files](https://www.gdquest.com/tutorial/godot/2d/first-2d-game-godot-4/)

Two hours, one sitting, and you end up with a roguelite that moves, aims,
shoots and spawns enemies that chase you. The strongest argument for this one
over Brackeys is maintenance: it was made for Godot 4.1 and has since been
updated to 4.6, which is rare enough among free tutorials to be worth choosing
on its own. It is also released under CC-BY 4.0.

Made by a team that teaches for a living, and it shows in the sequencing.

#### Clear Code — *The ultimate introduction to Godot*

<https://www.youtube.com/watch?v=TLG2yVpLDT8> (October 2025) ·
[the 2023 original](https://www.youtube.com/watch?v=nAh_Kx5Zh5Q)

The opposite bet from the two above: one enormous, carefully sequenced course
rather than a quick win. The 2023 original runs about eleven hours; the 2025
rebuild teaches coding through three games — a runner, a 2D platformer, and a
3D space shooter.

Prefer the 2025 version. It is newer, and building in both 2D and 3D early
prevents the very common outcome where someone is fluent in 2D and completely
lost the first time a third axis appears.

Clear Code's separate [introduction to Control
nodes](https://www.youtube.com/watch?v=Ny4JDxwlrbo) (March 2025) is the best
free UI material anywhere, and pairs directly with Chapter 13 and Chapter 36.

#### GDQuest — *Learn GDScript From Zero*

<https://gdquest.github.io/learn-gdscript/> ·
[source](https://github.com/GDQuest/learn-gdscript)

Not a video. An interactive app — twenty-seven bite-sized lessons with quizzes
and hands-on exercises, running in the browser, free and open source, with
downloadable builds for Windows, macOS and Linux on itch.io.

This is the one to use if you have never programmed at all. Watching someone
type code and typing code yourself are different activities, and only the
second one sticks. Works alongside Chapter 4 and Chapter 10.

#### The official step-by-step games

- *Your first 2D game* — "Dodge the Creeps" —
  <https://docs.godotengine.org/en/stable/getting_started/first_2d_game/>
- *Your first 3D game* — "Squash the Creeps", the same game with a jump —
  <https://docs.godotengine.org/en/stable/getting_started/first_3d_game/>

Written, free, and the only entry on this page that is *structurally incapable*
of going out of date, because it is versioned alongside the engine. Check that
the selector says the version you have installed and it cannot lie to you.

Doing the 2D one and then the 3D one back to back is an unusually efficient
afternoon: the second is deliberately the first game again with an axis added,
so everything that is genuinely different about 3D is what stands out.

KidsCanCode covers the same ground with more commentary at
<https://kidscancode.org/godot_recipes/4.x/games/first_2d/index.html>.

:::callout-tip[Two is the useful number, not five]
Do one video course and one written one. The video teaches you what the editor
feels like under someone's hands; the written one teaches you to read a
reference, which is the skill you need on the day no tutorial covers your
problem. Beyond those two, more beginner courses is procrastination with good
posture — Section 7 is what comes next.
:::

## 3 · Channels Worth Subscribing To

Grouped by what they are actually *for*, since "Godot tutorials" describes all
of them and distinguishes none of them.

### To follow a full project through

| Channel | What they build | Start with |
| --- | --- | --- |
| [**GDQuest**](https://www.youtube.com/channel/UCxboW7x0jZqFdvMdCFKTMsQ) | 2D projects taught by a team that teaches for a living | [Your First 2D Game From Zero](https://www.youtube.com/watch?v=GwCiGixlqiU) |
| [**HeartBeast**](https://www.youtube.com/@uheartbeast) | Action RPGs, long-running and unusually patient about the parts most tutorials rush | [Godot 4 Action RPG](https://www.youtube.com/playlist?list=PL9FzW-m48fn3H1URoqV6QorDpszCBIwt7) |
| [**StayAtHomeDev**](https://www.youtube.com/channel/UCDshKIMtFjYreCzApleuV8w) | An FPS toolkit built in public over a year, plus a weekly Godot news round-up | [The Godot FPS Project](https://www.youtube.com/playlist?list=PLEHvj4yeNfeF6s-UVs5Zx5TfNYmeCiYwf) |
| [**DevWorm**](https://www.youtube.com/@dev-worm) | A long RPG series — dialogue, inventory, y-sorting, save and load, procedural generation | [How to Create an RPG in Godot 4](https://www.youtube.com/watch?v=pBoXqW4RykE) |
| [**Bramwell**](https://www.youtube.com/channel/UCczi7Aq_dTKrQPF5ZV5J3gg) | 3D platformer fundamentals — movement feel and camera control | Browse the channel; the 3D movement videos are the draw |

:::callout-pitfall[Pitfall: the DevWorm RPG series predates the TileMap change]
That series began in April 2023, well before Godot 4.3 deprecated `TileMap` in
August 2024. The teaching is sound and the code runs; the tile-world portion
builds in the shape the ecosystem has since left behind. Follow it with
Section 1's table beside you, or do the tile work Chapter 9's way instead.
:::

### To understand one thing properly

| Channel | Strength | Pairs with |
| --- | --- | --- |
| [**Clear Code**](https://www.youtube.com/watch?v=Ny4JDxwlrbo) | The Control-node introduction linked here is the best free UI teaching anywhere | Chapter 13, Chapter 36 |
| [**Lukky**](https://www.youtube.com/channel/UCQ8hqAX8i9mdcwrnu8e2sIg) | Node-by-node coverage of the scene tree, the closest video equivalent to Appendix A | Appendix A, Chapter 3 |
| [**Godotneers**](https://www.youtube.com/@godotneers) | UI and interface design, explained slowly | Chapter 13 |
| [**Godot Tutorials**](https://www.youtube.com/@GodotTutorials) | GDScript language fundamentals — arrays, operators, the API itself | Chapter 4, Chapter 10 |
| [**Bitlytic**](https://www.youtube.com/@Bitlytic) | Video essays on systems rather than click-along builds | Chapter 27, Chapter 56 |

### To keep watching after you stop needing tutorials

These are channels you watch because they are good, not because you are stuck.

- **Miziziziz** — <https://www.youtube.com/channel/UCaoqVlqPTH78_xjTjTOMcmQ> —
  builds strange, fast, complete things: Doom clones, 3D platformers, whole
  games made in absurd timeframes. Dry, funny, and the strongest visual taste
  of anyone on this list. Watch for how much a small, coherent art direction
  buys you.
- **Gamefromscratch** — <https://gamefromscratch.com/> — engine news rather
  than tutorials. This is how you learn that `TileMap` was deprecated in the
  week it happens instead of eighteen months later. Covers every engine, which
  is useful for perspective.
- **GDQuest** and **StayAtHomeDev**, listed above, both run news and community
  segments alongside the teaching.

:::callout-connect[Connect]
The best use of this tier is not learning technique — it is calibrating scope.
Watching someone finish a small game in a weekend does more for your project
planning than any article about scope creep, because you see what they cut.
:::

## 4 · Sites You Will Come Back To

#### Godot 4 Recipes — KidsCanCode

<https://kidscancode.org/godot_recipes/4.x/>

The best free written reference outside the official docs, and maintained
against 4.x specifically (there is a separate 3.x site — make sure the URL you
land on says `4.x`). Organised as recipes rather than a course: grid-based
movement, platform character controllers, shooting projectiles, car steering,
FPS controllers, camera gimbals, raycasting. Every article ships code samples
and example projects, and the whole site is on GitHub.

It also keeps its own migration notes at
<https://kidscancode.org/godot_recipes/4.x/basics/migrating/index.html>, which
is a friendlier read than the engine source when a Godot 3 tutorial has left
you stranded.

#### GDNotes

<https://gdnotes.com/>

A curated directory of Godot resources and tutorials. Useful when you know the
topic but not who covered it well.

#### Class Central's Godot list

<https://www.classcentral.com/report/best-godot-courses/>

Aggregates free video courses with view counts and dates. Treat it as an index
rather than a recommendation — the dates are the valuable column.

## 5 · Shaders and Effects

Chapters 19, 32 and 50 through 55 cover the shading language. When you want to
*read* shaders rather than write them:

- **Godot Shaders** — <https://godotshaders.com/> — a community library of free
  shaders for 2D, 3D, VFX, post-processing and UI, usable in commercial
  projects. Searchable, and most entries are short enough to read in full.
- **GDQuest's open-source shader collection** —
  <https://github.com/gdquest-demos/godot-shaders> — a large library of free
  and open-source 2D and 3D shaders, each with a playable demo. The demos are
  the point: you can change a uniform and see the result immediately.
- **The official shader tutorials** —
  <https://docs.godotengine.org/en/stable/tutorials/shaders/index.html> —
  including your first shader, VisualShaders, compute shaders, screen-reading
  shaders, and converting GLSL to Godot's dialect.

:::callout-tip[Read shaders before writing them]
A shader is short enough to read in its entirety, which is rare in
programming. Reading twenty of them from the library above will teach you more
about the fragment stage than any single tutorial, because you see the same
handful of ideas — UV distortion, step functions, time as an input — recombined
twenty different ways.
:::

## 6 · Free Assets

Chapter 68 covers licensing, importing and import settings in detail. This is
just where to get the files, and one correction to the ecosystem that chapter
describes.

- **Kenney** — <https://kenney.nl/> — thousands of assets, all CC0, all usable
  commercially with no attribution required. Also publishes free, open-source
  **starter kits** at <https://kenney.nl/starter-kits> covering several genres.
  If you are prototyping, start here and never think about art again until the
  mechanic works.
- **The Godot Asset Store** — <https://store.godotengine.org/> — the official
  home for plugins, templates, demos and asset packs. Kenney publishes there
  directly.
- **Godot Asset Library** — <https://godotassetlibrary.com/> — a separate
  community-run browser over the same ecosystem, easier to search than the
  in-editor tab.

:::callout-warning[Where the Asset Library lives now]
Chapter 68 describes the Asset Library as the in-editor **AssetLib** tab, which
is still correct and still works. Since that chapter was written, the official
web home moved to `store.godotengine.org`. The move was partly a response to
third-party sites re-hosting free assets — Kenney's among them — as paid
downloads with unclear ownership information. Prefer the official store or the
creator's own site over any page that charges for something you can identify as
CC0.
:::

## 7 · Practice Without Tutorials

There is a gap between finishing a tutorial and starting a project, and it is
where most people stop. Everything in this section exists to close it.

#### The 20 Games Challenge

<https://www.20gameschallenge.org/>

Remake twenty classic games, in order of difficulty, **without watching a
tutorial specific to that game**. The rule against game-specific tutorials is
the whole method: you already know enough, and what you lack is the experience
of deciding things yourself.

The challenge asks for vertical slices rather than finished products — all the
main mechanics, none of the menus and polish — which keeps each one to a
weekend rather than a season. It is engine-agnostic and explicitly recommends
Godot for people without an engine already.

Do this after Chapter 42 or Chapter 69, when you have shipped one thing.

#### Godot Wild Jam

<https://godotwildjam.com/>

A monthly Godot-only jam, running for over ninety iterations. It starts the
second Friday of every month at 4pm New York time and runs nine days. The
community picks the theme together on Discord beforehand, and optional
"wildcards" add extra constraints you can take or leave.

Nine days is the useful number. It is long enough to finish, and short enough
that you cannot avoid cutting things — which is the skill.

:::callout-intuition[Why a jam teaches faster than a tutorial]
A tutorial hands you a decision already made. A jam forces the decision under a
deadline, and a deadline is what converts knowledge into judgment. You will
learn more about scene organisation from one jam where you got it wrong than
from any chapter that told you the right answer up front — including this
book's.
:::

## 8 · Where to Ask

- **The official forum** — <https://forum.godotengine.org/> — the highest
  signal-to-noise place to ask, and searchable, which means your question is
  probably already answered.
- **The class reference** — every page under
  <https://docs.godotengine.org/en/stable/classes/> lists the methods,
  properties and signals of one class. When a tutorial uses something you have
  never seen, this is faster than asking.
- **Godot Wild Jam's Discord**, linked from the jam site, is the most active
  place to get a fast answer during a jam.

:::callout-tip[Ask better]
Post the error text, the Godot version, and the smallest scene that reproduces
it. "It doesn't work" gets you a request for those three things and costs you a
day. This is the same discipline as Chapter 23's approach to debugging: reduce
before you report.
:::

## 9 · What Is Not Here, and Why

**Nothing paid.** Several of the best-known Godot educators — GDQuest and
HeartBeast among them — sell courses alongside their free material. The free
material is what is listed above, and it is genuinely complete rather than a
sample. No judgment on the paid courses; they are simply out of scope for a
shelf that has to stay free.

**Nothing recorded for Godot 3 only.** Many well-regarded channels built their
reputation on Godot 3 and never fully moved. Their explanations of *concepts*
are often still excellent and their *code* will not run. If you find one, read
it for the idea and write the code from Section 1's table.

**Channels named in other people's lists that could not be confirmed.**
Several roundups circulating in 2026 recommend creators — Tutemic on 3D code
architecture is the notable one — whose channels could not be located directly
while this appendix was assembled. They are omitted rather than linked to a
guess. Absence here is not a judgment about quality.

:::summary
- Check the version before you follow anything: Godot 3 code does not run in 4,
  and a pre-4.3 tutorial will build its tile world out of a deprecated node
  that still works.
- Start with one finishable thing: Brackeys for an evening, Clear Code for a
  course, GDQuest's *Learn GDScript From Zero* if you have never programmed.
- Keep the official docs and KidsCanCode's Godot 4 Recipes open while you work;
  they answer faster than a video can.
- When tutorials stop helping, the 20 Games Challenge and Godot Wild Jam are
  the two structures that reliably convert knowledge into shipped games.
:::
