---
title: "VS Clone — Object Pooling, Performance & Export"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71H"
meta:
  - "Est. study time: ~45 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated May 2026"
source: "godot_ch71h_export.html"
---

## Overview

The game runs. It looks good. Now make it run *fast*. At 200+ enemies
 the three most common bottlenecks are: projectile instantiation spikes,
 nearest-enemy linear scans in every weapon, and navigation path requests.
 This chapter addresses each with targeted fixes, then exports the project to
 Windows, Linux, and Web.

:::callout-key[Target: < 8 ms frame time at 200 enemies, 60 fps]
Profile first, fix only what shows up. Most small VS clones run fine
 without a spatial hash — only add it if the profiler shows
 `_get_nearest_enemy()` taking more than 1–2 ms per frame.
:::

## 1. Profiling the Bottleneck

1. Run the game with F5 and let it play for ~5 minutes until 100+ enemies are on screen.
2. Open **Debugger → Profiler → Start**. Let it sample for 5 seconds then stop.
3. Sort by **Self Time**. The top offenders in a VS clone are usually:

   - `EnemyBase._physics_process` — nav target update cost × enemy count
   - `WeaponBase._get_nearest_enemy` — linear group scan × weapon count
   - `ObjectPool.get / release` — if pre-alloc count is too low, spills to instantiate

4. Use **Monitors → Physics Frame** to confirm frame time stays under 8 ms.

## 2. Spatial Hash for Nearest Enemy

If the profiler shows `_get_nearest_enemy()` is expensive, replace the
 group-iteration linear scan with a spatial hash. The hash divides the world into
 cells; each enemy registers in its cell. Looking up the nearest enemy only checks
 the player's cell and its 8 neighbours — O(k) instead of O(n).

```gdscript
## res://autoloads/SpatialHash.gd — add as autoload "SpatialHash"
extends Node

const CELL_SIZE: float = 128.0
var _grid: Dictionary = {}   ## Vector2i → Array[EnemyBase]

func register(enemy: EnemyBase) -> void:
    var cell := _to_cell(enemy.global_position)
    if not _grid.has(cell):
        _grid[cell] = []
    _grid[cell].append(enemy)

func unregister(enemy: EnemyBase) -> void:
    var cell := _to_cell(enemy.global_position)
    if _grid.has(cell):
        _grid[cell].erase(enemy)

func update_position(enemy: EnemyBase, old_pos: Vector2) -> void:
    var old_cell := _to_cell(old_pos)
    var new_cell := _to_cell(enemy.global_position)
    if old_cell == new_cell: return
    if _grid.has(old_cell): _grid[old_cell].erase(enemy)
    if not _grid.has(new_cell): _grid[new_cell] = []
    _grid[new_cell].append(enemy)

func query_nearest(pos: Vector2, radius: float) -> EnemyBase:
    var center := _to_cell(pos)
    var cell_r  := int(ceil(radius / CELL_SIZE)) + 1
    var nearest: EnemyBase = null
    var best := INF
    for dx in range(-cell_r, cell_r + 1):
        for dy in range(-cell_r, cell_r + 1):
            var cell := center + Vector2i(dx, dy)
            if not _grid.has(cell): continue
            for e in _grid[cell]:
                if not is_instance_valid(e): continue
                var d := pos.distance_squared_to(e.global_position)
                if d < best:
                    best = d
                    nearest = e
    return nearest

func _to_cell(pos: Vector2) -> Vector2i:
    return Vector2i(int(floor(pos.x / CELL_SIZE)),
                    int(floor(pos.y / CELL_SIZE)))
```

Integrate into EnemyBase:

```gdscript
## In EnemyBase.gd:
var _prev_pos: Vector2

func _ready() -> void:
    # ... existing code ...
    SpatialHash.register(self)
    _prev_pos = global_position

func _physics_process(delta: float) -> void:
    # ... existing move code ...
    SpatialHash.update_position(self, _prev_pos)
    _prev_pos = global_position

func _die() -> void:
    SpatialHash.unregister(self)
    # ... rest of die ...
```

And update WeaponBase:

```gdscript
func _get_nearest_enemy() -> EnemyBase:
    return SpatialHash.query_nearest(_player.global_position, 1200.0)
```

## 3. ObjectPool Tuning

If the profiler shows `ObjectPool.acquire()` calling
 `instantiate()` (pool ran dry), increase pre-allocation counts.
 Check pool drain in the Remote debugger by printing pool sizes:

```gdscript
## Temporary debug in ObjectPool.acquire():
func acquire(key: String) -> Node:
    if _pools.has(key) and _pools[key].is_empty():
        print("POOL DRY: ", key, " — instantiating live")
    # ... rest ...
```

Tune pre-alloc counts based on observed peak simultaneous usage:

| Key | Default | Recommended at 200 enemies |
| --- | --- | --- |
| XpGem | 40 | 80 (200 enemies can die in one Garlic pulse) |
| Projectile | 30 | 40 (wand fires ~1/s; 30 in flight at once is rare) |
| HitEffect | 20 | 40 (same burst scenario) |

## 4. Reducing Draw Calls

At 200 enemies each with a Sprite2D, draw calls can spike if every sprite uses
 a different texture or material. Three easy wins:

- **Texture atlas** — put all enemy sprites on one sprite sheet (same texture, different UV rects). Godot batches all draws from the same texture into one draw call.
- **Use Sprite2D, not AnimatedSprite2D** for large enemy counts — AnimatedSprite2D adds overhead per frame for animation state checks. Drive animation via Sprite2D + modulate instead.
- **Disable HealthBar on Bats** — ProgressBar nodes on each enemy add UI draw calls. Only render HP bars on Skeleton and Golem; hide them on fast-spawning Bats.

## 5. Navigation Throttle

If NavigationServer2D is expensive, throttle path updates so enemies only
 re-path every 3rd physics frame instead of every frame:

```gdscript
## In EnemyBase.gd:
var _nav_tick: int = 0

func _physics_process(delta: float) -> void:
    _nav_tick += 1
    if _nav_tick % 3 == 0:
        nav_agent.target_position = _player.global_position
    var next := nav_agent.get_next_path_position()
    velocity = (next - global_position).normalized() * move_speed
    move_and_slide()
```

Stagger enemies so they don't all re-path on the same frame. Randomise the
 initial tick offset in `_ready()`:

```gdscript
func _ready() -> void:
    _nav_tick = randi() % 3   ## spread updates across 3 frames
    # ...
```

## 6. Windows & Linux Export

1. **Install export templates** — Editor → Export → Manage Export Templates → Download & Install (if not already done).
2. **Add preset** — Project → Export → Add → Windows Desktop. Set the .exe name to `RelicHorde.exe`.
3. **Embed PCK** — tick **Embed PCK** so the export is a single .exe file (no separate .pck needed for distribution).
4. **Export** — click **Export Project**, choose an output folder, confirm.
5. Repeat for Linux/X11 preset (output name `RelicHorde.x86_64`).

:::callout-tip[Icons and metadata]
Set a custom .ico (Windows) and .png (Linux) under Project → Project Settings
 → Application → Boot Splash / Icon. Add a company name and version string under
 Application → Config → Name and Version.
:::

## 7. Web Export

1. Add preset: **Web**. Set HTML file name to `index.html`.
2. Tick **Extensions Support** off (not needed for a pure GDScript game).
3. Under **Progressive Web App**, add an app name and icon for PWA install support.
4. Export to a folder named `web/`.
5. Test locally with Python: `cd web && python3 -m http.server 8080`, open `localhost:8080`. (A local server is required — file:// won't work for Web exports due to SharedArrayBuffer headers.)

:::callout-warning[SharedArrayBuffer headers required]
Godot 4 Web exports require the server to send
 `Cross-Origin-Opener-Policy: same-origin` and
 `Cross-Origin-Embedder-Policy: require-corp` headers.
 itch.io sets these automatically. GitHub Pages and most CDNs do not —
 use itch.io or a server you control.
:::

## 8. Uploading to itch.io

1. Create a game page at itch.io → Dashboard → Create New Project.
2. Set Kind: **HTML**. Upload the entire `web/` folder as a ZIP.
3. Tick **This file will be played in the browser** and set the frame size to 1920×1080 (or smaller for comfortable browser play).
4. Upload a Windows ZIP (the .exe + any data files) as a separate download for native play.
5. Add screenshots, a cover image, and a short description, then click **Publish**.

:::callout-tip[Frame size vs. viewport size]
The itch.io embed frame doesn't have to match your 1920×1080 viewport.
 Set the frame to 960×540 — the game will scale down cleanly with
 canvas\_items stretch mode. Players can click the fullscreen button for
 the full 1080p experience.
:::

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
What are the three most common frame-time bottlenecks in a VS-style game
 at 200 enemies, and which chapter section addresses each?

::::solution[Solution]
1. **Nearest-enemy linear scan** in weapons → section 2 (spatial hash).

 2. **Pool depletion** causing live instantiation spikes → section 3 (pool tuning).

 3. **Navigation path requests** every frame × 200 → section 5 (nav throttle).
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
With `CELL_SIZE = 128` and `cell_r = 2`,
 how many grid cells does `query_nearest()` check, and what is
 the maximum query radius this covers?

::::solution[Solution]
The loop covers `(2 × 2 + 1)² = 5² = 25` cells.

 Maximum radius covered: `(cell_r − 1) × CELL_SIZE = 1 × 128 = 128 px`
 guaranteed, with partial coverage up to `ceil(radius / CELL_SIZE) + 1`
 cells out. For a query radius of 1200 px passed to `query_nearest`,
 `cell_r = ceil(1200/128) + 1 = 11`, checking 23² = 529 cells —
 only non-empty cells have inner loops, so in a sparsely populated world this
 is still fast.
::::
:::

:::problem[Problem 3 challenge]{difficulty="challenge"}
The nav throttle staggers enemy path updates across 3 frames using
 `_nav_tick % 3`. At 200 enemies and 60 fps, how many navigation
 updates fire per second without throttling, and how many fire with it?

::::solution[Solution]
**Without throttling:** 200 enemies × 60 frames = 12,000 nav updates/second.

 **With throttle (every 3rd frame):** 12,000 / 3 = 4,000 updates/second.

 With staggered initial offsets, those 4,000 are spread evenly as approximately
 67 updates per frame instead of 200 per frame — a 3× reduction in nav server
 load per frame.
::::
:::

## Series Complete — Relic Horde

:::summary
## Chapter 71H — Key Points

| Topic | Approach |
| --- | --- |
| Profiling | Debugger → Profiler; sort by Self Time; fix only what's hot |
| Spatial hash | SpatialHash autoload; cells=128px; O(k) nearest instead of O(n) |
| Pool tuning | Watch for POOL DRY prints; increase pre-alloc to cover burst peaks |
| Draw calls | Single texture atlas for all enemies; no HealthBar on cheap enemies |
| Nav throttle | Update target every 3rd frame; stagger initial tick per enemy |
| Windows export | Embed PCK → single .exe; set icon + metadata |
| Web export | index.html + assets; test with local server; itch.io handles COOP headers |
| itch.io | HTML upload; frame 960×540; Windows ZIP as secondary download |
:::

:::callout-key[What you've built]
A fully playable, exportable Vampire Survivors clone in Godot 4. It features
 WASD movement, three auto-firing weapons (Garlic AOE, Magic Wand, Axe arc),
 three enemy types with NavigationAgent2D pathfinding, XP gems with a magnet range,
 a level-up pause with upgrade card selection, a 30-minute run timer, death and
 victory screens, hit flash and screen shake, background music, object pooling,
 and both desktop and Web exports. The architecture is cleanly separated —
 any new weapon, enemy, or upgrade is a single new file with no changes to
 existing systems.
:::

Return to the [index](./godot_index.html) to explore the rest of
 the textbook, or continue to Ch 72 when it is written.
