---
title: "Navigation — Pathfinding & Avoidance"
source: "godot_ch20_navigation.html"
---

Part III · Chapter 20

# Navigation — Pathfinding & Avoidance

Prerequisite: Chapter 8 (2D Physics) · est. 85 min

## Overview

Godot's navigation system lets characters find their way through the world without running
 into walls. It is built on three layers:

- **Navigation geometry** — `NavigationRegion2D` / `NavigationRegion3D`
 nodes that define the *walkable space* as a polygon (2D) or baked navmesh (3D).
- **NavigationAgent** — a component node that sits on a character, requests
 paths from the server, and provides the next position the character should move toward.
- **NavigationServer** — a singleton that manages all regions, agents, and
 obstacles; you can query it directly for custom pathfinding without a NavigationAgent.

Local avoidance (steering around other agents) is handled separately by the same server —
 enable it on the agent and it produces a velocity vector that steers clear of neighbours.

## 1 · Navigation 2D Setup

Navigation 2D Node Relationships

NavigationRegion2D

Contains NavigationPolygon

Defines walkable area

NavigationPolygon

resource · stores polygon vertices

NavigationServer2D

Singleton — processes queries

bakes meshes, resolves paths

NavigationAgent2D

Child of moving entity

Queries path + avoidance

set\_target\_position(pos)

get\_next\_path\_position()

Agent asks Server for path → Server searches Region's polygon → returns waypoints

Your script calls get\_next\_path\_position() each frame and moves the character toward it

Three key navigation nodes. The `NavigationRegion2D` defines walkable space, `NavigationAgent2D` requests paths, and `NavigationServer2D` (a singleton) does the pathfinding work.

⬡ — NavigationRegion2D — inherits Node2D

Defines where agents *can* walk by holding a `NavigationPolygon` resource that describes walkable areas as polygons. The engine bakes these polygons into a navigation mesh that NavigationAgent2D queries for pathfinding. Think of it as the "floor plan" — agents know they can move inside the polygon and must path around anything outside it.

| Property | Default | What it does |
| --- | --- | --- |
| navigation\_polygon | null | **Required.** A NavigationPolygon resource — draw walkable outlines and obstacle holes in its editor panel, then click Bake NavigationPolygon |
| enabled | true | Disable to temporarily remove this region from pathfinding — useful for doors, conditional terrain |
| navigation\_layers | 1 | Bitmask — agents whose navigation\_layers match use this region. Use multiple layers for flying vs ground units |
| enter\_cost | 0.0 | Extra cost added when an agent's path enters this region — higher values steer agents away (useful for mud, slow zones) |
| travel\_cost | 1.0 | Cost multiplier per unit of distance inside this region — above 1.0 makes the region less preferred than the default |

Use when:

setting up any 2D navmesh — place one in the scene, draw the walkable polygon, bake it, then give agents a NavigationAgent2D to use it.

Multiple regions:

you can have several NavigationRegion2D nodes stitched together — useful for modular levels, rooms that connect dynamically, or regions with different travel costs.

TileMapLayer alternative:

TileMapLayer can auto-generate navigation polygons from tile data — no manual drawing needed for tile-based maps.

### 1.1 · NavigationRegion2D

Add a **NavigationRegion2D** node to your scene. It holds a
 **NavigationPolygon** resource that defines which areas characters can walk through.
 Everything inside the polygon is walkable; everything outside is not.

1. Add `NavigationRegion2D` to the scene.
2. In the inspector, create a new `NavigationPolygon` resource.
3. Select the node and click **Edit Polygon** in the toolbar, then draw an outline
 around your walkable area. Add additional polygons for islands of walkable space.
4. Click **Bake NavigationPolygon** (or call `bake_navigation_polygon()`
 in code) to compute the final mesh.

### 1.2 · NavigationPolygon baking in code

```gdscript

@onready var nav_region: NavigationRegion2D = $NavigationRegion2D

func _ready() -> void:
    # Bake navigation polygon at runtime (useful when level is generated procedurally)
    nav_region.bake_navigation_polygon()
    # Baking is asynchronous — connect to the signal to know when it's done:
    nav_region.bake_finished.connect(_on_bake_finished)

func _on_bake_finished() -> void:
    print("Navigation polygon baked — agents can start pathfinding")
```

### 1.3 · Navigation on TileMapLayer

For tile-based levels, assign navigation layers to individual tiles in the TileSet editor
 (select a tile → Navigation tab → add a navigation polygon). Then add a
 `NavigationRegion2D` as a sibling of the TileMapLayer — it will automatically
 pick up navigation data from the tileset when you bake:

```gdscript

# The NavigationRegion2D automatically includes tilemap navigation polygons
# when it bakes, as long as the tiles have navigation polygons in their TileData.
# No extra code needed — just bake the region.
nav_region.bake_navigation_polygon()
```

⬡ — NavigationAgent2D — inherits Node

Handles pathfinding for a single 2D agent. Add it as a child of your enemy or NPC, call `set_target_position()`, then call `get_next_path_position()` in `_physics_process()` to get the next waypoint to walk toward — the agent automatically queries NavigationServer2D to route around obstacles baked into the NavigationPolygon. It also provides local avoidance so multiple agents don't pile up.

| Property | Default | What it does |
| --- | --- | --- |
| path\_desired\_distance | 20.0 px | How close the agent gets to a waypoint before stepping to the next one along the path |
| target\_desired\_distance | 10.0 px | How close to the final destination counts as arrival — fires the `navigation_finished` signal |
| path\_max\_distance | 100 px | Max drift from the path before a new one is requested — handles dynamic obstacles moving the agent off-path |
| navigation\_layers | 1 | Bitmask matching NavigationRegion2D layers — agent only uses regions on matching layers |
| avoidance\_enabled | false | Enable RVO2 local avoidance — agents steer around each other. Requires avoidance\_layers and avoidance\_mask to match |
| radius | 10.0 px | Agent's avoidance radius — other agents will try to keep this distance |
| max\_speed | 100 px/s | Maximum speed the avoidance algorithm uses when computing safe velocities |
| path\_postprocessing | CORRIDORFUNNEL | How path corners are smoothed — CORRIDORFUNNEL hugs walls; EDGECENTERED routes through polygon midpoints (rounder paths) |
| debug\_enabled | false | Draws path and avoidance debug visuals in the editor viewport — invaluable for diagnosing stuck agents |

Use when:

any enemy, NPC, or unit needs to pathfind through a 2D world — top-down RPGs, strategy games, tower defence creeps.

Prerequisite:

a NavigationRegion2D with a baked NavigationPolygon must exist in the scene for the agent to have a mesh to query.

The agent doesn't move the body

— it gives you a next position. You apply that to your CharacterBody2D velocity each physics frame.

## 2 · NavigationAgent2D

### 2.1 · Target and path following

NavigationAgent2D — Path Following

WALL

Agent

(current pos)

next\_path\_position()

Target

velocity = (get\_next\_path\_position() - global\_position).normalized() \* SPEED

The agent computes the full path around obstacles once. Each frame, `get_next_path_position()` returns the next waypoint. Move toward it, then call again — the agent advances through waypoints automatically.

Add a **NavigationAgent2D** node as a child of the moving character. Set its
 `target_position` to wherever you want the character to go. The agent
 communicates with the NavigationServer and provides the next waypoint via
 `get_next_path_position()`:

```gdscript

extends CharacterBody2D

const SPEED := 120.0

@onready var agent: NavigationAgent2D = $NavigationAgent2D

func _ready() -> void:
    # Connect signals to know when the path is ready and when target is reached
    agent.navigation_finished.connect(_on_navigation_finished)
    agent.velocity_computed.connect(_on_velocity_computed)   # only if avoidance enabled

func set_target(pos: Vector2) -> void:
    agent.target_position = pos

func _physics_process(delta: float) -> void:
    if agent.is_navigation_finished():
        return

    var next_pos := agent.get_next_path_position()
    var direction := (next_pos - global_position).normalized()
    velocity = direction * SPEED
    move_and_slide()

func _on_navigation_finished() -> void:
    print("Reached destination")
```

:::callout-warning
⚠️ Set target\_position after \_ready()

The NavigationServer processes in a deferred step.  Setting

target\_position

in

\_ready()

may query before the navigation map is ready.  Either defer it with

call\_deferred()

or set it one frame later using

await get\_tree().process\_frame

.
:::

### 2.2 · Local avoidance

Enable avoidance on the agent to have it automatically steer around other agents
 (RVO — Reciprocal Velocity Obstacles). Instead of applying velocity directly,
 let the agent compute a safe velocity:

```gdscript

extends CharacterBody2D

const SPEED := 120.0

@onready var agent: NavigationAgent2D = $NavigationAgent2D

func _ready() -> void:
    agent.avoidance_enabled  = true
    agent.radius             = 16.0   # character's avoidance radius (pixels)
    agent.neighbor_distance  = 200.0  # look for neighbours within this range
    agent.max_neighbors      = 8
    agent.velocity_computed.connect(_on_safe_velocity)

func _physics_process(delta: float) -> void:
    if agent.is_navigation_finished():
        return
    var next_pos  := agent.get_next_path_position()
    var desired   := (next_pos - global_position).normalized() * SPEED
    # Pass desired velocity to the avoidance system
    agent.set_velocity(desired)

# Called by the server when a safe velocity has been computed (deferred by one frame)
func _on_safe_velocity(safe_velocity: Vector2) -> void:
    velocity = safe_velocity
    move_and_slide()
```

### 2.3 · NavigationAgent2D signals and properties

| Signal / Property | Type | Purpose |
| --- | --- | --- |
| `navigation_finished` | signal | Emitted when the agent reaches its target (within `target_desired_distance`) |
| `path_changed` | signal | Emitted when a new path is computed |
| `waypoint_reached(details)` | signal | Emitted each time the agent passes a path waypoint |
| `velocity_computed(v)` | signal | Safe avoidance velocity ready (avoidance only) |
| `target_position` | Vector2 | Where to navigate to |
| `path_desired_distance` | float | How close to a waypoint before advancing (default 1 px) |
| `target_desired_distance` | float | How close to final target counts as "arrived" (default 1 px) |
| `navigation_layers` | int (bitmask) | Which navigation layers this agent can traverse |
| `get_current_navigation_path()` | PackedVector2Array | Raw path waypoints currently being followed |
| `is_navigation_finished()` | bool | True when at destination or no path exists |

## 3 · Navigation 3D

### 3.1 · NavigationMesh baking

In 3D, walkable space is defined by a **NavigationMesh** resource baked from the
 static geometry in your scene. Add a `NavigationRegion3D` node, assign a new
 `NavigationMesh` resource to it, and bake:

1. Add **NavigationRegion3D** to the scene.
2. Inspector → create new **NavigationMesh**.
3. Set `geometry_source_group` if only certain nodes should be included.
4. Adjust `agent_height`, `agent_radius`, `agent_max_slope`
 to match your character's dimensions.
5. Click **Bake NavMesh** in the toolbar, or call `bake_navigation_mesh()`
 at runtime.

```gdscript

@onready var nav_region: NavigationRegion3D = $NavigationRegion3D

func _ready() -> void:
    nav_region.bake_navigation_mesh()
    nav_region.bake_finished.connect(func(): print("3D navmesh ready"))
```

⬡ — NavigationAgent3D — inherits Node

The 3D equivalent of NavigationAgent2D. Add it as a child of any 3D character, set a target position, and query `get_next_path_position()` each physics frame to receive step-by-step waypoints toward the target, automatically avoiding obstacles baked into the NavigationMesh. Handles asynchronous pathfinding, local avoidance via RVO2, and arrival detection.

| Property | Default | What it does |
| --- | --- | --- |
| path\_desired\_distance | 1.0 m | How close the agent must get to a path point before advancing to the next |
| target\_desired\_distance | 1.0 m | How close to the final target counts as "arrived" — fires navigation\_finished signal |
| path\_max\_distance | 5.0 m | If the agent drifts this far from its path, a new path is requested automatically |
| navigation\_layers | 1 | Bitmask — agent only uses NavigationRegion3D nodes on matching layers |
| avoidance\_enabled | false | Enable RVO2 local avoidance — prevents agents from overlapping each other |
| radius | 0.5 m | Agent's physical radius for avoidance collision budgeting |
| height | 1.0 m | Agent's height — used to clip paths through low overhangs |
| max\_speed | 10 m/s | Maximum speed the avoidance system allows — used only for avoidance velocity clamping, not actual movement |
| path\_postprocessing | CORRIDORFUNNEL | CORRIDORFUNNEL smooths paths along polygon edges; EDGECENTERED routes through midpoints |

Use when:

any 3D NPC, enemy, or character needs to walk around a 3D world avoiding walls and obstacles.

Required setup:

a NavigationRegion3D with a baked NavigationMesh in the scene; the agent queries that mesh's server automatically.

Movement note:

the agent gives you waypoints — it doesn't move the body itself. Apply the direction to your CharacterBody3D's velocity each physics frame.

### 3.2 · NavigationAgent3D

The 3D API mirrors 2D exactly. Add `NavigationAgent3D` as a child of your
 `CharacterBody3D`:

```gdscript

extends CharacterBody3D

const SPEED    := 5.0
const GRAVITY  := 9.8

@onready var agent: NavigationAgent3D = $NavigationAgent3D

var _gravity_vel := 0.0

func _ready() -> void:
    agent.path_desired_distance   = 0.5
    agent.target_desired_distance = 0.5
    agent.avoidance_enabled       = true
    agent.radius                  = 0.4   # metres
    agent.velocity_computed.connect(_on_safe_velocity)

func navigate_to(pos: Vector3) -> void:
    agent.target_position = pos

func _physics_process(delta: float) -> void:
    # Apply gravity
    if not is_on_floor():
        _gravity_vel += GRAVITY * delta
    else:
        _gravity_vel = 0.0

    if agent.is_navigation_finished():
        velocity.y = -_gravity_vel
        move_and_slide()
        return

    var next_pos := agent.get_next_path_position()
    var dir      := (next_pos - global_position)
    dir.y = 0.0   # horizontal movement only — gravity handles Y
    dir   = dir.normalized()

    var desired := dir * SPEED
    desired.y   = -_gravity_vel
    agent.set_velocity(desired)

func _on_safe_velocity(safe_vel: Vector3) -> void:
    velocity = safe_vel
    move_and_slide()
```

:::callout-tip
💡 NavigationMesh cell size vs agent size

The navmesh is voxelized at

cell\_size

resolution.  Set it to roughly
        1/4 of the agent radius for best quality — too large and corners get cut; too small
        and baking takes a long time.  For a human-scale character (radius 0.4 m) use

cell\_size = 0.1

.
:::

## 4 · NavigationServer API

### 4.1 · Direct path queries (no agent node)

Query the server directly when you need a path in a one-shot way — checking whether a
 target is reachable, drawing a path preview line, or pathfinding in a non-physics context:

```gdscript

# Get the RID of the default 2D navigation map
var map_rid := get_world_2d().navigation_map

# Query a path from A to B
var params := NavigationPathQueryParameters2D.new()
params.map          = map_rid
params.start_position = $Enemy.global_position
params.target_position = $Player.global_position
params.navigation_layers = 1   # bitmask

var result := NavigationPathQueryResult2D.new()
NavigationServer2D.query_path(params, result)

var path: PackedVector2Array = result.path
if path.size() > 1:
    print("Path found with %d waypoints" % path.size())
else:
    print("No path exists")
```

### 4.2 · Dynamic obstacles

For moving obstacles that other agents should avoid (but can't be NavigationAgents themselves,
 like a swinging door or a moving platform), add a **NavigationObstacle2D**
 or **NavigationObstacle3D** node. Obstacles affect the avoidance system
 (velocity-level steering) but not the path graph:

```gdscript

# NavigationObstacle2D on a moving platform:
@onready var obstacle: NavigationObstacle2D = $Platform/NavigationObstacle2D

func _physics_process(delta: float) -> void:
    # Move the platform
    global_position.x += sin(Time.get_ticks_msec() * 0.001) * 60.0 * delta
    # The obstacle's position follows the node automatically.
    # Agents with avoidance enabled will steer around it.
```

To cut a *hole* in the navigation polygon (a wall that moves into walkable space),
 you need to re-bake the region — obstacles alone do not affect path graph topology, only
 avoidance steering. For dynamic holes, use multiple regions and enable/disable them:

```gdscript

# Door that is initially open (region enabled) and closes (disable the region)
@onready var door_region: NavigationRegion2D = $DoorNavRegion

func close_door() -> void:
    door_region.enabled = false   # removes this region from the nav graph
    # Agents will repath around the closed door on their next path request

func open_door() -> void:
    door_region.enabled = true
```

### 4.3 · Navigation layers

Navigation layers are a bitmask (up to 32 bits) that lets different agent types use different
 regions. A flying enemy might traverse regions marked "air" while a ground unit can only use
 regions marked "ground":

```gdscript

# Assign layers in the inspector on NavigationRegion2D (Navigation Layers property)
# Then set the agent's navigation_layers to match the regions it can use:

var ground_agent: NavigationAgent2D = $GroundEnemy/NavigationAgent2D
ground_agent.navigation_layers = 0b0001   # bit 0 = ground

var flying_agent: NavigationAgent2D = $FlyingEnemy/NavigationAgent2D
flying_agent.navigation_layers = 0b0011   # bits 0+1 = ground + air
```

## Summary

| Concept | Key takeaway |
| --- | --- |
| **NavigationRegion2D/3D** | Defines walkable space; bake before pathfinding begins |
| **NavigationPolygon** | 2D walkable area; draw in editor or generate procedurally |
| **NavigationMesh** | 3D walkable surface; cell\_size ≈ agent\_radius / 4 for good quality |
| **NavigationAgent2D/3D** | Child node on a character; set target\_position → call get\_next\_path\_position() each frame |
| **avoidance\_enabled** | RVO steering — use set\_velocity() and handle velocity\_computed signal |
| **NavigationObstacle** | Moving obstacle affecting avoidance only — does not change path graph |
| **NavigationServer.query\_path()** | One-shot path query without an agent node |
| **navigation\_layers bitmask** | Filter which regions each agent type can traverse |

- Always bake the navigation polygon/mesh before agents try to pathfind — connect `bake_finished` to know when it is safe.
- Set `target_position` one frame after `_ready()` to ensure the navigation map is ready.
- Use avoidance for smooth multi-agent steering; use region enable/disable for large structural changes (doors, bridges).
- NavigationObstacle only affects *avoidance velocity*, not path graphs — re-bake or disable regions for actual blocked areas.
- Navigation layers let flying, swimming, and ground units share the same scene but traverse different geometry.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Click-to-move

Write a player controller that moves toward wherever the player left-clicks on the 2D world.
 Use a `NavigationAgent2D` and `_unhandled_input`.

::::solution[Solution]
```gdscript

extends CharacterBody2D

const SPEED := 150.0

@onready var agent: NavigationAgent2D = $NavigationAgent2D

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton \
       and event.button_index == MOUSE_BUTTON_LEFT \
       and event.pressed:
        agent.target_position = get_global_mouse_position()

func _physics_process(_delta: float) -> void:
    if agent.is_navigation_finished():
        velocity = Vector2.ZERO
        return
    var next := agent.get_next_path_position()
    velocity  = (next - global_position).normalized() * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Is the target reachable?

Write a function `is_reachable(from: Vector2, to: Vector2) → bool` that uses
 `NavigationServer2D.query_path()` to check whether a path exists between two
 world positions, without requiring a NavigationAgent node.

::::solution[Solution]
```gdscript

func is_reachable(from: Vector2, to: Vector2) -> bool:
    var map := get_world_2d().navigation_map
    var params := NavigationPathQueryParameters2D.new()
    params.map             = map
    params.start_position  = from
    params.target_position = to

    var result := NavigationPathQueryResult2D.new()
    NavigationServer2D.query_path(params, result)
    return result.path.size() >= 2
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Enemy patrol with waypoints

An enemy should patrol between a list of `Vector2` waypoints in order,
 using `NavigationAgent2D`. When it reaches the last waypoint it loops back
 to the first. Speed: 100 px/s.

::::solution[Solution]
```gdscript

extends CharacterBody2D

const SPEED := 100.0

@export var waypoints: Array[Vector2] = []

@onready var agent: NavigationAgent2D = $NavigationAgent2D

var _current_wp := 0

func _ready() -> void:
    agent.navigation_finished.connect(_advance_waypoint)
    _set_target()

func _set_target() -> void:
    if waypoints.is_empty():
        return
    agent.target_position = waypoints[_current_wp]

func _advance_waypoint() -> void:
    _current_wp = (_current_wp + 1) % waypoints.size()
    _set_target()

func _physics_process(_delta: float) -> void:
    if agent.is_navigation_finished() or waypoints.is_empty():
        return
    var next := agent.get_next_path_position()
    velocity  = (next - global_position).normalized() * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Chase with flee behaviour

An enemy chases the player normally. When the player enters a "danger zone" radius of
 120 px from the enemy, the enemy switches to fleeing — it moves to a position
 300 px directly away from the player. Use `NavigationAgent2D`.

::::solution[Solution]
```gdscript

extends CharacterBody2D

const SPEED        := 110.0
const DANGER_DIST  := 120.0
const FLEE_DIST    := 300.0

@export var player_path: NodePath
@onready var player: Node2D = get_node(player_path)
@onready var agent: NavigationAgent2D = $NavigationAgent2D

var _fleeing := false

func _physics_process(delta: float) -> void:
    if not player:
        return
    var dist := global_position.distance_to(player.global_position)

    if dist < DANGER_DIST:
        _fleeing = true
    elif dist > DANGER_DIST * 1.5:
        _fleeing = false

    if _fleeing:
        var flee_dir := (global_position - player.global_position).normalized()
        agent.target_position = global_position + flee_dir * FLEE_DIST
    else:
        agent.target_position = player.global_position

    if agent.is_navigation_finished():
        return
    var next := agent.get_next_path_position()
    velocity  = (next - global_position).normalized() * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Door that blocks pathfinding

A dungeon room has a locked door represented by a `NavigationRegion2D` that
 covers the door tile. Write `lock_door()` and `unlock_door()`
 functions. After locking, verify that the path from the enemy to the player no longer
 exists using a direct query.

::::solution[Solution]
```gdscript

extends Node2D

@onready var door_region: NavigationRegion2D = $DoorNavRegion
@export var enemy_path : NodePath
@export var player_path: NodePath

func lock_door() -> void:
    door_region.enabled = false
    # One-frame defer so the server has time to process the change
    await get_tree().process_frame
    _check_path()

func unlock_door() -> void:
    door_region.enabled = true

func _check_path() -> void:
    var enemy  := get_node(enemy_path)  as Node2D
    var player := get_node(player_path) as Node2D
    var map    := get_world_2d().navigation_map
    var p      := NavigationPathQueryParameters2D.new()
    p.map             = map
    p.start_position  = enemy.global_position
    p.target_position = player.global_position
    var r := NavigationPathQueryResult2D.new()
    NavigationServer2D.query_path(p, r)
    if r.path.size() < 2:
        print("Door locked — enemy has no path to player")
    else:
        print("Path still exists (%d waypoints)" % r.path.size())
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Multi-agent crowd with avoidance

Spawn 20 enemy agents from a `PackedScene`, all trying to reach the player.
 Each agent must have avoidance enabled (radius 14 px) so they don't pile on top of
 each other. Add a shared target update: every 0.5 s, all agents refresh their
 `target_position` to the player's current position. Include a
 `NavigationObstacle2D` on a barrel node that agents steer around.

::::solution[Solution]
```gdscript

# CrowdManager.gd (Node)
extends Node

@export var enemy_scene  : PackedScene
@export var player_path  : NodePath
@export var spawn_center : Vector2 = Vector2(200, 200)

@onready var player: Node2D = get_node(player_path)

var _agents: Array[NavigationAgent2D] = []

func _ready() -> void:
    # Spawn 20 enemies
    for i in 20:
        var e   := enemy_scene.instantiate() as CharacterBody2D
        var angle := (i / 20.0) * TAU
        e.global_position = spawn_center + Vector2.from_angle(angle) * 120.0
        get_tree().current_scene.add_child(e)

        var agent: NavigationAgent2D = e.get_node("NavigationAgent2D")
        agent.avoidance_enabled  = true
        agent.radius             = 14.0
        agent.neighbor_distance  = 120.0
        agent.max_neighbors      = 10
        _agents.append(agent)

    # Refresh targets every 0.5 s
    var timer := Timer.new()
    timer.wait_time = 0.5
    timer.timeout.connect(_update_targets)
    add_child(timer)
    timer.start()

func _update_targets() -> void:
    for agent in _agents:
        agent.target_position = player.global_position
```
::::
:::
