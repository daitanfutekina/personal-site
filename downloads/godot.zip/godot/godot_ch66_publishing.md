---
title: "Itch.io, Steam & the Publishing Workflow"
source: "godot_ch66_publishing.html"
---

Part XI · Chapter 66

Capstone

# Itch.io, Steam & the Publishing Workflow

Estimated study time: 70 min · Platform-agnostic · CLI + Editor

## Chapter Overview

You've built the game. You've exported it. Now it needs players. This chapter covers
 the full publishing workflow for the two most common indie channels:
 **itch.io** (zero barrier, game jam friendly, revenue share model)
 and **Steam** (larger audience, $100 fee, Steamworks SDK integration).
 We also cover versioning strategy, playtesting, a pre-launch checklist, and how to
 hook basic analytics into your game.

## Itch.io

:::callout-intuition[Intuition]
Itch.io is the fastest path from "finished game" to "public URL." You can publish in
  under 10 minutes with no approval process and no upfront fee. Revenue share is
  configurable (default 10% to itch.io). For game jams, prototypes, and first releases,
  itch.io is the standard starting point.
:::

### Manual Upload

1. Create an account at itch.io → **Dashboard → Create new project**.
2. Set Kind = *Downloadable* (or *HTML* for web games).
3. Upload each platform build as a separate ZIP: `game_win.zip`, `game_linux.zip`, `game_web.zip`.
4. Mark each upload with the correct platform tag so itch.io's launcher detects it.
5. Set price (0 = free, or "Pay what you want" with a suggested price).
6. Write a description, add screenshots, and publish.

### butler — Automated CLI Upload

Uploading manually every update is tedious. **butler** is itch.io's official
 CLI tool that does delta uploads (only changed files), versioning, and channel management.

```bash
# Install butler
# Windows: download from https://itchio.itch.io/butler
# macOS/Linux: via Scoop, Homebrew, or direct download

# Login once
butler login

# Push a build — channel names are arbitrary but conventional
butler push ./builds/windows  yourname/your-game:windows
butler push ./builds/linux    yourname/your-game:linux
butler push ./builds/web      yourname/your-game:html5

# Push with a version tag
butler push ./builds/windows yourname/your-game:windows --userversion 1.2.0
```

Butler performs a binary diff and only uploads changed bytes — updating a 200 MB game
 where only 2 MB changed takes seconds instead of minutes.

### Store Page Tips

| Element | Recommendation |
| --- | --- |
| Cover image | 630×500 px minimum. Show gameplay, not the title logo alone. |
| Screenshots | 3–6 in-game screenshots. First screenshot is most important. |
| GIF/trailer | A 15–30 s gameplay GIF or embedded YouTube trailer dramatically increases clicks. |
| Description | First paragraph = hook. Lead with what makes the game unique, not "this is a platformer I made." |
| Tags | Fill all 10 tag slots. Use genre + mood + control style (e.g., "roguelike, pixel art, gamepad"). |
| Devlog | Post at least one devlog update to appear in "Recent activity" feeds. |

## Steam

Steam requires a one-time $100 app fee per game. You get access to Steamworks —
 Steam's SDK for achievements, cloud saves, leaderboards, DLC, and the workshop.
 Approval is not automatic but typically takes a few days for review.

### GodotSteam — Steamworks SDK for Godot 4

The official Steamworks SDK is C++. For Godot 4, use the
 **GodotSteam** GDExtension plugin (community-maintained, widely used):

```bash
# 1. Download GodotSteam for Godot 4 from GitHub:
#    https://github.com/GodotSteam/GodotSteam

# 2. Add to your project:
#    Copy the GodotSteam .gdextension file and .so/.dll/.dylib files to res://addons/godotsteam/

# 3. Add steam_appid.txt to your project root (required during development):
echo "480" > steam_appid.txt   # 480 = Spacewar (Valve test app — replace with your AppID at launch)
```

#### Initialising Steam

```gdscript
## SteamManager.gd (autoload)
extends Node

var is_steam_running := false

func _ready() -> void:
    if not Engine.has_singleton("Steam"):
        push_warning("GodotSteam not found — running without Steam")
        return

    var init := Steam.steamInitEx()
    if init.status != Steam.STEAM_API_INIT_RESULT_OK:
        push_error("Steam init failed: " + str(init))
        return

    is_steam_running = true
    print("Steam running as: ", Steam.getPersonaName())

func _process(_delta: float) -> void:
    if is_steam_running:
        Steam.run_callbacks()   # Must be called every frame
```

### Depots & Branches

A Steam **depot** is a set of files for one platform. You set up one depot per
 platform (Windows, macOS, Linux). A **branch** (Steam calls it a "build branch")
 is a version of your game — e.g., *default* (live), *beta* (opt-in),
 *dev* (password-protected internal).

```ini
## steamcmd upload script — run this to push a build
@ShutdownOnFailedCommand 1
@NoPromptForPassword 1
login YOUR_STEAM_USERNAME
run_app_build_http ./scripts/app_build_1234567.vdf
quit
```

```ini
## app_build_1234567.vdf (replace 1234567 with your AppID)
"AppBuild"
{
  "AppID" "1234567"
  "Desc"  "v1.2.0 release"
  "BuildOutput" "./output/"
  "Depots"
  {
    "1234568" { "FileMapping" { "LocalPath" "./build/windows/*" "DepotPath" "." "recursive" "1" } }
    "1234569" { "FileMapping" { "LocalPath" "./build/linux/*"   "DepotPath" "." "recursive" "1" } }
  }
}
```

### Steam Achievements

```gdscript
## AchievementManager.gd (autoload)
extends Node

func unlock(achievement_id: String) -> void:
    if not SteamManager.is_steam_running: return
    Steam.setAchievement(achievement_id)
    Steam.storeStats()   # Must store for achievement to appear
    print("Achievement unlocked: ", achievement_id)

func get_achievement(achievement_id: String) -> bool:
    if not SteamManager.is_steam_running: return false
    return Steam.getAchievement(achievement_id).achieved
```

Define achievement IDs in the Steamworks dashboard under
 *App Admin → Stats & Achievements*. String IDs like `"FIRST_KILL"`
 must match exactly between dashboard and code.

## Versioning Strategy

Use semantic versioning: **MAJOR.MINOR.PATCH** (e.g. `1.2.3`).

| Segment | Increment when |
| --- | --- |
| MAJOR | Incompatible save file changes, major reworks, DLC |
| MINOR | New content, new features (backwards compatible) |
| PATCH | Bug fixes, balance tweaks, crash fixes |

Store the version in Project Settings → Application → Config → Version, and display it
 in-game:

```gdscript
## In your main menu
$VersionLabel.text = "v" + ProjectSettings.get_setting("application/config/version")
```

Automate version bumping in your CI pipeline using a script:

```bash
#!/bin/bash
# bump_version.sh MINOR
PART=$1   # MAJOR, MINOR, or PATCH
FILE="project.godot"

# Read current version
VERSION=$(grep 'config/version=' $FILE | cut -d'"' -f2)
IFS='.' read -r -a PARTS <<< "$VERSION"
MAJOR=${PARTS[0]}; MINOR=${PARTS[1]}; PATCH=${PARTS[2]}

case $PART in
  MAJOR) MAJOR=$((MAJOR+1)); MINOR=0; PATCH=0 ;;
  MINOR) MINOR=$((MINOR+1)); PATCH=0 ;;
  PATCH) PATCH=$((PATCH+1)) ;;
esac

NEW_VERSION="$MAJOR.$MINOR.$PATCH"
sed -i "s/config\/version=\"$VERSION\"/config\/version=\"$NEW_VERSION\"/" $FILE
echo "Bumped to $NEW_VERSION"
```

## Playtesting & Analytics

### Structured Playtesting

1. **Internal** — developer testing. Find crashes and obvious bugs.
2. **Closed beta** — trusted friends or community members. Find difficulty spikes and confusion.
3. **Open beta / demo** — public. Find platform-specific issues and scale your server if needed.

During playtesting, record where players get stuck, where they quit, and what they say
 aloud — these are more valuable than written feedback.

### Simple In-Game Analytics

```gdscript
## Analytics.gd (autoload) — write events to a local file for post-session review
## For production, swap file writing for an HTTP request to your analytics server.
extends Node

const LOG_PATH := "user://analytics.log"
var _file: FileAccess

func _ready() -> void:
    if OS.is_debug_build():
        _file = FileAccess.open(LOG_PATH, FileAccess.WRITE)

func event(name: String, data: Dictionary = {}) -> void:
    if not _file: return
    var entry := {
        "time":  Time.get_unix_time_from_system(),
        "event": name,
        "data":  data
    }
    _file.store_line(JSON.stringify(entry))
    _file.flush()

func _notification(what: int) -> void:
    if what == NOTIFICATION_PREDELETE and _file:
        _file.close()
```

Usage examples:

```gdscript
Analytics.event("level_start",   { "level": 3 })
Analytics.event("player_death",  { "level": 3, "cause": "spike", "position": str(global_position) })
Analytics.event("level_complete",{ "level": 3, "time": elapsed_seconds, "deaths": death_count })
Analytics.event("item_purchased",{ "item": "shield", "currency_spent": 50 })
```

## Launch Checklist

:::callout-key[Pre-Launch Checklist]
- ☐ All platforms tested with release builds (not debug)
- ☐ Save/load tested across multiple sessions and game versions
- ☐ Settings (volume, resolution, keybindings) persist correctly
- ☐ Credits screen present and complete
- ☐ Third-party asset licenses listed (fonts, SFX libraries, etc.)
- ☐ Game icon set for all platforms (Windows ICO, macOS ICNS, Android PNG set)
- ☐ Application version set in Project Settings
- ☐ export\_presets.cfg excluded from version control OR encryption key removed
- ☐ Store page has 3+ screenshots, description, and at least one GIF/trailer
- ☐ itch.io / Steam page reviewed for typos
- ☐ Friends/beta testers confirmed they can download and run without you present
- ☐ Announcement drafted for social media / Discord / Reddit
- ☐ Feedback channel set up (Discord server, GitHub issues, itch.io community)
:::

:::callout-warning[export\_presets.cfg and Secrets]
export\_presets.cfg

may contain signing keystore paths and passwords.
  Add it to

.gitignore

or strip the sensitive fields before committing.
  Never commit Steam build credentials or Apple certificates to a public repository.
:::

:::summary
### Chapter 66 — Publishing Quick Reference

| Platform | Fee | Upload tool | Best for |
| --- | --- | --- | --- |
| Itch.io | Free (10% revenue share) | butler CLI / manual upload | Jam games, demos, indie releases |
| Steam | $100 one-time per app | steamcmd + VDF scripts | Commercial releases, large audiences |
| Google Play | $25 one-time | Play Console web upload | Android mobile games |
| App Store | $99/year (Apple Developer) | Xcode Organizer / Transporter | iOS games |
| GitHub Releases | Free | gh CLI or web | Open source, no-store distribution |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Butler Upload Script

Write a bash script called `publish.sh` that exports Windows, Linux, and
 Web builds using Godot's command line, then uploads all three to itch.io using butler.
 The itch.io game slug is `myname/mygame`.

::::solution[Solution]
```bash
#!/bin/bash
set -e   # exit on error

# Export builds
mkdir -p builds/{windows,linux,web}
godot --headless --export-release "Windows Desktop" ./builds/windows/game.exe
godot --headless --export-release "Linux/X11"       ./builds/linux/game.x86_64
godot --headless --export-release "Web"             ./builds/web/index.html

# Upload to itch.io
butler push ./builds/windows myname/mygame:windows
butler push ./builds/linux   myname/mygame:linux
butler push ./builds/web     myname/mygame:html5

echo "Published successfully!"
```
::::
:::

:::problem{difficulty="easy"}
#### 2. Version Display

Write the code to display the current game version from Project Settings in a
 Label node called `$VersionLabel`, formatted as "Version 1.2.3".
 Where in Project Settings is the version string stored?

::::solution[Solution]
```gdscript
func _ready() -> void:
    var version: String = ProjectSettings.get_setting("application/config/version", "0.0.1")
    $VersionLabel.text = "Version " + version
```

The version is stored at **Project → Project Settings → Application → Config → Version**
 (key: `application/config/version`). You can also edit it directly in
 `project.godot` under `[application]`.
::::
:::

:::problem{difficulty="standard"}
#### 3. Steam Achievement Unlock

Using the GodotSteam setup from the chapter, write the code for a
 `PlayerStats.gd` script that tracks total enemies killed and unlocks a Steam
 achievement `"HUNDRED_KILLS"` the first time the player reaches 100 kills.
 The achievement should only be unlocked once (not repeatedly).

::::solution[Solution]
```gdscript
## PlayerStats.gd (autoload)
extends Node

var kills := 0 :
    set(value):
        kills = value
        _check_achievements()

func register_kill() -> void:
    kills += 1

func _check_achievements() -> void:
    if kills == 100:
        # Check if already unlocked to avoid redundant store calls
        if not AchievementManager.get_achievement("HUNDRED_KILLS"):
            AchievementManager.unlock("HUNDRED_KILLS")
```

The `kills` property setter fires `_check_achievements()` every time
 kills changes. The `AchievementManager.get_achievement()` guard ensures we only call
 `unlock()` once — Steam handles its own deduplication, but skipping the redundant
 call avoids unnecessary Steam API traffic.
::::
:::

:::problem{difficulty="standard"}
#### 4. Pre-Launch Audit

You're 48 hours from launching your game on itch.io. List the five most critical
 things to verify in your release build (not debug) that you cannot check in the editor,
 and explain why each matters.

::::solution[Solution]
1. **Save/load persists correctly.** The `user://` path behaves
 differently in release exports (OS-specific paths). Test that saves written in one session
 load correctly in the next. A broken save on launch day is fatal for player retention.
2. **All dynamically-loaded resources exist in the build.** If you use
 `load("res://...")` with string paths, those scenes/sounds must be in the
 include list. Test every code path that loads resources — the editor always has them; the
 release build only has what the export preset included.
3. **Audio plays on launch without prior interaction (non-Web).** Desktop
 builds autoplay audio freely. Verify your main menu music actually starts. On Web, confirm
 it waits for a user click (browser policy).
4. **No debug overlays or test shortcuts are active.** `OS.is_debug_build()`
 returns false in release, so debug-guarded code is hidden. But any debug feature not guarded
 by this check (e.g., a cheat menu bound to F12) will ship to players.
5. **Crash on an unknown GPU driver / no GDExtension fallback.** If you use
 a GDExtension plugin, test on a machine that doesn't have your development environment
 installed. Some plugins need Visual C++ Redistributables on Windows — if missing, the game
 silently fails to launch.
::::
:::

:::problem{difficulty="challenge"}
#### 5. Analytics Event Design

Design a set of analytics events for a 5-level puzzle game that would let you answer
 the following questions post-launch: (a) Which level do players most commonly quit on?
 (b) How long does the average player spend on each level? (c) What percentage of players
 reach the final level? Write the specific `Analytics.event()` calls and
 explain how you'd analyse the log file to answer each question.

::::solution[Solution]
```gdscript
## Events to fire:

# When a level starts
Analytics.event("level_start", { "level": level_num, "attempt": attempt_count })

# When the player quits (main menu pressed, window closed during level)
func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        Analytics.event("quit", { "level": current_level, "time_in_level": elapsed })

# When a level is completed
Analytics.event("level_complete", { "level": level_num, "time": elapsed, "attempt": attempt_count })
```

**Analysis:**

- **(a) Most common quit level:** Count `quit` events by `level`. The level with the highest count is where players abandon the game.
- **(b) Average time per level:** For each level, collect all `level_complete.time` values and average them. Exclude outliers (AFK sessions) by capping at e.g. 30 minutes.
- **(c) Percentage reaching final level:** Count unique sessions with a `level_start` event where `level == 5`, divided by total unique sessions with `level_start level == 1`.
::::
:::

## Building a Press Kit

A press kit is a single page (or zip) journalists and content creators use to cover your game without pestering you for assets. Preparing one before launch costs two hours and earns media coverage you'd otherwise miss.

### What to include

| Asset | Format | Notes |
| --- | --- | --- |
| Game icon | PNG 512×512 | Square, no transparency. Used by storefronts and Discord embeds. |
| Logo / wordmark | PNG + SVG | Both dark and light background versions. |
| Screenshots | PNG 1920×1080 | At least 6. Capture with UI hidden if possible — press prefers clean gameplay shots. |
| GIF / short clip | GIF or MP4 | 15–30 seconds of the best gameplay moment. Used in articles. |
| Fact sheet | Plain text or HTML | Developer, release date, price, platforms, genre, controls. |
| Description | Markdown / HTML | Short (150 words) and long (500 words) versions for different contexts. |
| Trailer embed | YouTube link | Your launch trailer — journalists embed it rather than linking a download. |

### Hosting

The simplest option is a dedicated page on itch.io (their press kit builder is free). Alternatively, [dopresskit.com](https://dopresskit.com) generates a static HTML press kit from a simple config file — widely used in the indie space and recognisable to journalists.

:::callout-tip[Screenshot automation]
Write a GDScript that loads each key scene, waits one second, and calls

get\_viewport().get\_texture().get\_image().save\_png("screenshot\_%d.png" % i)

. You get consistent resolution screenshots from every game state in 10 seconds.
:::

## Storefront Page Optimisation

Your itch.io or Steam page is a landing page. Conversion rate (visitors → buyers) is directly affected by the first impression. Most players decide in under 10 seconds.

### Header image (capsule)

The capsule is the rectangular image displayed in store listings. It must communicate genre, art style, and tone at thumbnail size (~300px wide). Avoid showing title text in small fonts — they become illegible. Test by scaling the image down to 20% and asking whether someone could identify the game.

### Description structure

Lead with a one-sentence hook that names the genre and fantasy, not the mechanics: "A dark tactical RPG where every soldier has a story — and a permanent death." Follow with three bullet points of standout features. Only then go into detail. Players who reach paragraph three already want to buy.

### Tags and categories

On itch.io you control tags entirely. On Steam, Valve validates tags but you still influence them through the initial 20 you select. Research which tags your closest competitors use, then also include a couple of underserved niche tags where you'd rank in the top 10 — you'll get more visibility proportionally.

### GIFs on the itch.io page

Itch.io pages auto-play GIFs inline. A well-chosen 5-second looping GIF of satisfying gameplay (a combo, a satisfying slam, an explosion) on the page body dramatically increases page time and conversion compared to static screenshots.

:::callout-warning[Common mistake]
Launching a Steam page the same day you launch the game. Steam's algorithm rewards wishlist accumulation over weeks. Set your page live at least 4–6 weeks before launch so the algorithm has data to surface you in "New and Trending" at launch.
:::

## Community & Post-Launch

Publishing isn't the finish line. The games that build audiences are ones that communicate after launch.

### Dev log cadence

Post a dev log every two to four weeks. It doesn't need to be polished — a screenshot and three paragraphs of what changed is enough. Dev logs on itch.io are indexed by search engines and surface in the itch.io feed. They keep your page active in the algorithm and give existing fans something to share.

### Patch notes

Write patch notes even for small patches. Players who encounter a bug and then see it fixed in the next patch notes become advocates — they feel heard. Use a simple format: **Fixed:** / **Added:** / **Changed:**.

### Discord server

A small Discord is not a community management burden — it's a direct feedback loop. Even 50 active members will surface every critical bug within 24 hours of a patch. Link it from your itch.io page and Steam community hub.

### Reviews

On Steam, reviews directly affect discoverability. Email your existing players (via itch.io's email tool) after launch and ask for a review. Don't incentivise reviews — Valve prohibits it — but a polite "if you're enjoying the game, a Steam review helps us reach more players" is standard practice and legal.
