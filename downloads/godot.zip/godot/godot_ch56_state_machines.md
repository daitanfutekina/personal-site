---
title: "Finite State Machines — Code-Based & AnimationTree Hybrids"
source: "markdown"
---

Part IX · Chapter 56

# Finite State Machines — Code-Based & AnimationTree Hybrids

Estimated study time: 90 min · Prerequisites: Ch 7 Signals, Ch 12 Classes & Inheritance, Ch 37 AnimationTree

## Chapter Overview

A Finite State Machine (FSM) is the single most useful pattern in game development. Enemy AI, player controllers, UI flows, cutscene sequencing — nearly everything that can be in one of several distinct modes and transitions between them benefits from explicit state management.

This chapter presents three implementations in ascending order of complexity: a simple enum-based switch, a reusable class-based system, and a Godot-native node-based approach. It also shows how to wire an FSM to an AnimationTree so your animations and logic stay in sync.

:::callout-key[Three approaches — choose by complexity]
Enum FSM: 20 lines, great for <5 states. Class FSM: scalable, testable, recommended for characters. Node FSM: Godot-native, visual in the editor, ideal when states need their own physics/signals. AnimationTree hybrid: let the tree drive visual state while code drives logic state.
:::

## What Is a Finite State Machine?

:::callout-intuition[Intuition]
A traffic light can be Red, Yellow, or Green. It is always exactly one of those. When it changes, it follows a fixed rule: Green → Yellow, Yellow → Red, Red → Green. That's an FSM. Your game character works the same way: Idle → Run → Jump → Fall → Land → Idle.
:::

Formally, an FSM has:

- **States** — a finite set of possible modes (Idle, Run, Jump, Attack…)
- **Transitions** — rules for moving between states (if jumping and velocity.y > 0, go to Fall)
- **Entry/Exit actions** — code that runs when entering or leaving each state
- **Per-frame logic** — code that runs every frame while in a state

The key invariant: *exactly one state is active at a time*. This eliminates entire classes of bugs where overlapping conditions cause contradictory behaviour.

```
[Idle] ──(move input)──→ [Run] ──(jump)──→ [Jump]
  ↑                        |                  |
  └───(no input)───────────┘         (apex)──→ [Fall]
  ↑                                              |
  └──────────────────(landed)────────────────────┘
```

## Approach 1 — Enum FSM

The simplest approach: store state as an enum value, switch on it in `_physics_process`. Best for simple characters with 3–5 states and no shared logic between states.

### Basic Pattern

```gdscript
extends CharacterBody2D

enum State { IDLE, RUN, JUMP, FALL }

var state := State.IDLE

const SPEED    := 200.0
const JUMP_VEL := -400.0
const GRAVITY  := 980.0

func _physics_process(delta: float) -> void:
    # Apply gravity outside state so it always runs
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    match state:
        State.IDLE:
            velocity.x = 0.0
            if Input.is_action_just_pressed("jump") and is_on_floor():
                _change_state(State.JUMP)
            elif Input.get_axis("move_left", "move_right") != 0.0:
                _change_state(State.RUN)

        State.RUN:
            var dir := Input.get_axis("move_left", "move_right")
            velocity.x = dir * SPEED
            if dir == 0.0:
                _change_state(State.IDLE)
            elif Input.is_action_just_pressed("jump") and is_on_floor():
                _change_state(State.JUMP)

        State.JUMP:
            velocity.y = JUMP_VEL
            _change_state(State.FALL)

        State.FALL:
            if is_on_floor():
                _change_state(State.IDLE)

    move_and_slide()

func _change_state(new_state: State) -> void:
    state = new_state
```

:::callout-pitfall[Pitfall — JUMP logic runs for one frame only]
The JUMP branch sets velocity and immediately transitions to FALL in the same frame. This is intentional — JUMP is a momentary impulse, not a sustained state. If you need sustained jump behaviour (variable-height hold), expand JUMP to check for button release.
:::

### Adding Enter / Exit Callbacks

As soon as you need to play animations or reset variables on state change, add `_on_enter_state` and `_on_exit_state` methods:

```gdscript
@onready var anim: AnimationPlayer = $AnimationPlayer

func _change_state(new_state: State) -> void:
    _on_exit_state(state)
    state = new_state
    _on_enter_state(state)

func _on_enter_state(s: State) -> void:
    match s:
        State.IDLE:  anim.play("idle")
        State.RUN:   anim.play("run")
        State.JUMP:
            anim.play("jump")
            velocity.y = JUMP_VEL
        State.FALL:  anim.play("fall")

func _on_exit_state(s: State) -> void:
    match s:
        State.RUN:
            # Could stop footstep sound here
            pass
```

## Approach 2 — Class-Based FSM

When your character has 6+ states or states share complex logic, extract each state into its own class. This makes each state independently testable and keeps files small.

### State Base Class

```gdscript
# res://scripts/fsm/state.gd
class_name State extends Node

# Reference back to the owner (e.g., the player CharacterBody2D)
var actor: CharacterBody2D

signal transition_requested(new_state_name: StringName)

# Called when entering this state
func enter() -> void:
    pass

# Called every physics frame while this state is active
func process_physics(delta: float) -> void:
    pass

# Called every frame (for input that shouldn't be missed)
func process_input(event: InputEvent) -> void:
    pass

# Called when leaving this state
func exit() -> void:
    pass

# Helper: request a transition without knowing about the FSM manager
func transition_to(state_name: StringName) -> void:
    transition_requested.emit(state_name)
```

### FSM Manager

```gdscript
# res://scripts/fsm/state_machine.gd
class_name StateMachine extends Node

@export var initial_state: State

var current_state: State

func _ready() -> void:
    # Give all child states a reference to the actor
    for child in get_children():
        if child is State:
            child.actor = owner          # owner = the CharacterBody2D
            child.transition_requested.connect(_on_transition_requested)

    # Start in the initial state
    current_state = initial_state
    current_state.enter()

func _physics_process(delta: float) -> void:
    current_state.process_physics(delta)

func _unhandled_input(event: InputEvent) -> void:
    current_state.process_input(event)

func _on_transition_requested(new_state_name: StringName) -> void:
    var new_state := find_child(new_state_name) as State
    if new_state == null:
        push_error("StateMachine: state '%s' not found" % new_state_name)
        return
    current_state.exit()
    current_state = new_state
    current_state.enter()
```

### Concrete States

```gdscript
# res://scripts/states/idle_state.gd
class_name IdleState extends State

const SPEED    := 200.0
const JUMP_VEL := -400.0

func enter() -> void:
    actor.get_node("AnimationPlayer").play("idle")
    actor.velocity.x = 0.0

func process_physics(delta: float) -> void:
    # Gravity
    if not actor.is_on_floor():
        transition_to(&"FallState")
        return

    # Input checks
    if Input.get_axis("move_left", "move_right") != 0.0:
        transition_to(&"RunState")
    elif Input.is_action_just_pressed("jump"):
        transition_to(&"JumpState")

    actor.move_and_slide()
```

```gdscript
# res://scripts/states/jump_state.gd
class_name JumpState extends State

const JUMP_VEL  := -400.0
const GRAVITY   := 980.0
const FALL_APEX := 50.0  # velocity.y threshold where we switch to fall anim

func enter() -> void:
    actor.velocity.y = JUMP_VEL
    actor.get_node("AnimationPlayer").play("jump")

func process_physics(delta: float) -> void:
    actor.velocity.y += GRAVITY * delta

    # Variable-height jump: release early for shorter hop
    if not Input.is_action_pressed("jump") and actor.velocity.y < 0.0:
        actor.velocity.y *= 0.6

    if actor.velocity.y > FALL_APEX:
        transition_to(&"FallState")

    var dir := Input.get_axis("move_left", "move_right")
    actor.velocity.x = dir * 180.0
    actor.move_and_slide()
```

#### Scene Tree Setup

```gdscript
Player (CharacterBody2D)
  └── StateMachine (StateMachine.gd)  ← initial_state = IdleState
        ├── IdleState  (idle_state.gd)
        ├── RunState   (run_state.gd)
        ├── JumpState  (jump_state.gd)
        ├── FallState  (fall_state.gd)
        └── AttackState (attack_state.gd)
```

:::callout-tip[Why StringName transitions?]
Using

&"IdleState"

(StringName literals) as the transition target means any state can request any other state without importing it. The FSM manager does a

find\_child()

lookup. This avoids circular dependencies between state scripts.
:::

## Approach 3 — Node FSM

Each state is a full scene node with its own `_physics_process`. Enable/disable nodes to switch states. The advantage: each state can have its own child nodes (e.g., a collision shape that's only active during a specific state), and the state tree is visible in Godot's scene panel.

### Enable / Disable Pattern

```gdscript
# res://scripts/fsm/node_state_machine.gd
class_name NodeStateMachine extends Node

var _current: Node = null

func _ready() -> void:
    # Disable all child state nodes at start
    for child in get_children():
        child.set_physics_process(false)
        child.set_process_input(false)
        child.visible = false if child is CanvasItem else true

func transition_to(state_name: StringName) -> void:
    var next := find_child(state_name) as Node
    if next == null:
        push_error("NodeStateMachine: '%s' not found" % state_name)
        return
    if _current:
        if _current.has_method("exit"): _current.exit()
        _current.set_physics_process(false)
        _current.set_process_input(false)
    _current = next
    _current.set_physics_process(true)
    _current.set_process_input(true)
    if _current.has_method("enter"): _current.enter()

func get_current_state() -> Node:
    return _current
```

:::callout-warning[Node FSM overhead]
Having many Node-based states each with

\_physics\_process

that process every frame adds some overhead. Call

set\_physics\_process(false)

on inactive states — which the manager above does — to keep it efficient.
:::

## AnimationTree Hybrid

When your character already uses an AnimationTree with a StateMachine playback (see Ch 37), you can let the AnimationTree drive which animation plays while a separate code FSM drives logic. The two stay in sync by calling `travel()` on the AnimationTree whenever the code state changes.

```gdscript
extends CharacterBody2D

enum State { IDLE, RUN, JUMP, FALL, ATTACK }

@onready var anim_tree: AnimationTree = $AnimationTree
@onready var playback: AnimationNodeStateMachinePlayback = \
    anim_tree.get("parameters/playback")

var state := State.IDLE

func _change_state(new_state: State) -> void:
    state = new_state
    # Mirror state change into AnimationTree
    match new_state:
        State.IDLE:   playback.travel("Idle")
        State.RUN:    playback.travel("Run")
        State.JUMP:   playback.travel("Jump")
        State.FALL:   playback.travel("Fall")
        State.ATTACK: playback.travel("Attack")

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += 980.0 * delta

    match state:
        State.IDLE:
            velocity.x = move_toward(velocity.x, 0.0, 800.0 * delta)
            if Input.get_axis("move_left", "move_right") != 0.0:
                _change_state(State.RUN)
            elif Input.is_action_just_pressed("jump") and is_on_floor():
                _change_state(State.JUMP)
            elif Input.is_action_just_pressed("attack"):
                _change_state(State.ATTACK)

        State.ATTACK:
            velocity.x = move_toward(velocity.x, 0.0, 1200.0 * delta)
            # Wait for animation to finish before returning to idle
            if not playback.is_playing() or playback.get_current_node() != &"Attack":
                _change_state(State.IDLE)

    move_and_slide()
```

:::callout-tip[Animation-driven transitions]
For an ATTACK state, rather than timing the exit manually, you can use an AnimationTree transition configured to auto-advance back to Idle after the attack clip finishes. The code FSM then reads the current AnimationTree node to know when to exit:

playback.get\_current\_node() != &"Attack"

.
:::

## Hierarchical FSMs (HSM)

A hierarchical FSM nests FSMs inside states. Classic use case: an enemy has high-level states (Patrol, Chase, Combat), and within Combat there is a sub-FSM (Attack, Block, Dodge, Stagger). The inner FSM runs while the outer state is active; when the outer state exits, the inner FSM is suspended.

```gdscript
# Conceptual implementation using the class-based approach:
# CombatState contains its own StateMachine as a child node.

# combat_state.gd
class_name CombatState extends State

@onready var sub_fsm: StateMachine = $SubFSM

func enter() -> void:
    sub_fsm.process_mode = Node.PROCESS_MODE_INHERIT  # enable
    sub_fsm.transition_to(&"AttackState")

func exit() -> void:
    sub_fsm.process_mode = Node.PROCESS_MODE_DISABLED  # pause inner FSM

func process_physics(delta: float) -> void:
    # Check if we should leave combat entirely
    if actor.health <= 0:
        transition_to(&"DeadState")
    elif actor.target_distance() > 500.0:
        transition_to(&"PatrolState")
    # Inner FSM handles the rest automatically via its own process
```

:::callout-tip[When to add hierarchy]
Add a sub-FSM only when a top-level state becomes complex enough to warrant its own states (usually 4+ sub-behaviours). For simple cases, a flat FSM with well-named states is clearer.
:::

## Signals & FSMs

FSMs and signals work together naturally. States can react to signals from other systems (damage taken, area entered, timer timeout) without polling every frame:

```gdscript
# In StateMachine._ready(), connect signals to current state's handlers
# OR use a central dispatch that forwards signals to the active state:

class_name StateMachineWithEvents extends StateMachine

func _ready() -> void:
    super()
    # Connect external signals to the FSM dispatcher
    owner.get_node("HurtBox").area_entered.connect(_on_hurt)
    owner.get_node("AggroRange").body_entered.connect(_on_aggro)

func _on_hurt(area: Area2D) -> void:
    # Let the current state decide what to do with this event
    if current_state.has_method("on_hurt"):
        current_state.on_hurt(area)

func _on_aggro(body: Node2D) -> void:
    if current_state.has_method("on_aggro"):
        current_state.on_aggro(body)
```

```gdscript
# patrol_state.gd — implements on_aggro
func on_aggro(body: Node2D) -> void:
    actor.target = body
    transition_to(&"ChaseState")

# chase_state.gd — ignores on_aggro (already chasing)
# (method simply not defined — the FSM's has_method check handles it safely)
```

## Worked Example — Enemy AI with 4 States

A top-down enemy with Patrol → Alert → Chase → Attack states, using the class-based FSM.

### State Transition Map

```
[Patrol] ──(player spotted)──→ [Alert] ──(1s pause)──→ [Chase]
    ↑                                                       |
    └───(lost sight > 3s)──────────────────────────────────┤
                                                            │
                                               (in range)──→ [Attack]
                                                    ↑           |
                                                    └───────────┘ (out of range)
```

### PatrolState

```gdscript
class_name EnemyPatrolState extends State

const PATROL_SPEED := 80.0
var _waypoints: Array[Vector2] = []
var _wp_index   := 0

func enter() -> void:
    _waypoints = actor.get_node("Waypoints").get_waypoints()
    actor.get_node("AnimationPlayer").play("walk")

func process_physics(delta: float) -> void:
    if _waypoints.is_empty(): return

    var target_wp := _waypoints[_wp_index]
    var dir       := (target_wp - actor.global_position).normalized()
    actor.velocity = dir * PATROL_SPEED

    if actor.global_position.distance_to(target_wp) < 8.0:
        _wp_index = (_wp_index + 1) % _waypoints.size()

    actor.move_and_slide()

    # Vision check — handled via signal in real code
    if actor.can_see_player():
        transition_to(&"AlertState")
```

### AlertState

```gdscript
class_name EnemyAlertState extends State

const ALERT_DURATION := 1.0
var _timer := 0.0

func enter() -> void:
    actor.velocity = Vector2.ZERO
    actor.get_node("AnimationPlayer").play("alert")
    _timer = 0.0

func process_physics(delta: float) -> void:
    _timer += delta
    if _timer >= ALERT_DURATION:
        transition_to(&"ChaseState")
```

### ChaseState

```gdscript
class_name EnemyChaseState extends State

const CHASE_SPEED   := 140.0
const ATTACK_RANGE  := 50.0
const LOST_TIMEOUT  := 3.0

var _lost_timer := 0.0

func enter() -> void:
    actor.get_node("AnimationPlayer").play("run")
    _lost_timer = 0.0

func process_physics(delta: float) -> void:
    var player := actor.get_node("/root/World/Player") as Node2D
    var dist   := actor.global_position.distance_to(player.global_position)

    if actor.can_see_player():
        _lost_timer = 0.0
        var dir := (player.global_position - actor.global_position).normalized()
        actor.velocity = dir * CHASE_SPEED
        if dist <= ATTACK_RANGE:
            transition_to(&"AttackState")
    else:
        _lost_timer += delta
        actor.velocity = actor.velocity.move_toward(Vector2.ZERO, 200.0 * delta)
        if _lost_timer >= LOST_TIMEOUT:
            transition_to(&"PatrolState")

    actor.move_and_slide()
```

:::callout-pitfall[Pitfall 1 — Transitioning during enter()]
Calling

transition\_to()

inside

enter()

causes a recursive state change before the first state has finished setting up. Always guard against this: if you need an immediate secondary transition, defer it with

call\_deferred("transition\_to", ...)

.
:::

:::callout-pitfall[Pitfall 2 — Forgetting to call move\_and\_slide()]
In a class-based FSM each state calls

actor.move\_and\_slide()

itself. If a state forgets, the character freezes. An alternative is to always call it in the FSM manager after `current_state.process_physics(delta)` — but then states can't control whether movement happens.
:::

:::callout-pitfall[Pitfall 3 — State leaking variables]
A state that stores mutable data (e.g., a timer) must reset it in

enter()

, not in `exit()`. If the state is re-entered via the same transition path,

exit()

of the previous activation may not have run cleanly if the game was paused or the node was freed.
:::

:::summary
### Chapter 56 Summary

| Approach | Best for | Key trade-off |
| --- | --- | --- |
| Enum FSM | 1–5 states, simple characters | Fast to write; gets messy beyond 5 states |
| Class FSM | 6+ states, shared logic, testing | More files; very maintainable |
| Node FSM | States with own physics/signals | Visible in editor; slight overhead |
| AnimationTree hybrid | Animated characters | Animations and logic always in sync |
| Hierarchical FSM | Complex AI with sub-behaviours | Powerful; adds conceptual overhead |

| Task | How |
| --- | --- |
| Request a transition from within a state | `transition_to(&"StateName")` via signal |
| Run code once on entering a state | `enter()` method |
| Run code once on leaving a state | `exit()` method |
| React to signals in the current state | Dispatch from FSM manager via `has_method` |
| Mirror code FSM into AnimationTree | Call `playback.travel("StateName")` in `_change_state()` |
| Pause a sub-FSM | Set its `process_mode = PROCESS_MODE_DISABLED` |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Traffic Light FSM**

Implement an enum FSM for a traffic light node with states: RED (3s), GREEN (3s), YELLOW (1s). On each timeout the light transitions to the next state. Use a single `Timer` node restarted with the appropriate duration on each `_on_enter_state()` call. Change the node's `modulate` colour on enter.

::::solution[Solution]
```gdscript
extends Node2D

enum State { RED, GREEN, YELLOW }
var state := State.RED

@onready var timer: Timer = $Timer
@onready var light: ColorRect = $Light

func _ready() -> void:
    timer.timeout.connect(_on_timeout)
    _on_enter_state(state)

func _on_enter_state(s: State) -> void:
    match s:
        State.RED:
            light.color = Color.RED
            timer.start(3.0)
        State.GREEN:
            light.color = Color.GREEN
            timer.start(3.0)
        State.YELLOW:
            light.color = Color.YELLOW
            timer.start(1.0)

func _on_timeout() -> void:
    match state:
        State.RED:    state = State.GREEN
        State.GREEN:  state = State.YELLOW
        State.YELLOW: state = State.RED
    _on_enter_state(state)
```
::::
:::

:::problem{difficulty="easy"}
**2. Door FSM**

A door has states: CLOSED, OPENING (plays "open" animation), OPEN (stays open 2s), CLOSING (plays "close" animation). Transitions trigger when a player enters an Area2D. Implement with an enum FSM. The door should not respond to player input while OPENING or CLOSING.

::::solution[Solution]
```gdscript
extends Node2D
enum State { CLOSED, OPENING, OPEN, CLOSING }
var state := State.CLOSED

@onready var anim: AnimationPlayer = $AnimationPlayer
@onready var timer: Timer = $Timer

func _ready() -> void:
    $Area2D.body_entered.connect(_on_body_entered)
    anim.animation_finished.connect(_on_anim_finished)
    timer.timeout.connect(_on_open_timeout)

func _on_body_entered(_body: Node2D) -> void:
    if state == State.CLOSED:
        _change_state(State.OPENING)

func _change_state(s: State) -> void:
    state = s
    match s:
        State.OPENING: anim.play("open")
        State.OPEN:    timer.start(2.0)
        State.CLOSING: anim.play("close")
        State.CLOSED:  pass

func _on_anim_finished(anim_name: StringName) -> void:
    if anim_name == &"open" and state == State.OPENING:
        _change_state(State.OPEN)
    elif anim_name == &"close" and state == State.CLOSING:
        _change_state(State.CLOSED)

func _on_open_timeout() -> void:
    if state == State.OPEN:
        _change_state(State.CLOSING)
```
::::
:::

:::problem{difficulty="standard"}
**3. Class-Based Player FSM**

Extend the class-based FSM from the chapter to add a **Dash state**. While dashing: move at 3× speed in the last input direction for 0.2s, ignore gravity, and be invincible. After 0.2s return to either Run or Idle. Include a 1s cooldown after dashing (store the cooldown timer in the actor, not the state). Show the full DashState script.

::::solution[Solution]
```gdscript
# dash_state.gd
class_name DashState extends State

const DASH_SPEED    := 600.0
const DASH_DURATION := 0.2

var _timer := 0.0
var _dir   := Vector2.RIGHT

func enter() -> void:
    var raw_dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    _dir = raw_dir if raw_dir != Vector2.ZERO else Vector2(actor.facing_direction, 0.0)
    actor.is_invincible = true
    actor.dash_cooldown_timer = 1.0  # set on actor
    actor.velocity = _dir * DASH_SPEED
    actor.get_node("AnimationPlayer").play("dash")
    _timer = 0.0

func process_physics(delta: float) -> void:
    _timer += delta
    actor.velocity = _dir * DASH_SPEED  # constant speed, ignore gravity
    actor.move_and_slide()
    if _timer >= DASH_DURATION:
        transition_to(&"RunState" if Input.get_axis("move_left","move_right") != 0.0
            else &"IdleState")

func exit() -> void:
    actor.is_invincible = false
```

In the RunState and IdleState, check for dash input with a cooldown guard:

```gdscript
func process_physics(delta: float) -> void:
    actor.dash_cooldown_timer = max(actor.dash_cooldown_timer - delta, 0.0)
    if Input.is_action_just_pressed("dash") and actor.dash_cooldown_timer <= 0.0:
        transition_to(&"DashState")
    # ... rest of state logic
```
::::
:::

:::problem{difficulty="standard"}
**4. Signal-Driven Enemy FSM**

Build a simple class-based enemy FSM with Idle and Hurt states. The Hurt state plays a knockback animation for 0.5s, briefly flashes the sprite red, then returns to the previous state (not always Idle — it should resume whatever state was active before being hit). Store the pre-hurt state name and restore it after recovery.

::::solution[Solution]
```gdscript
# hurt_state.gd
class_name EnemyHurtState extends State

const HURT_DURATION := 0.5
const KNOCKBACK_SPEED := 200.0

var _timer        := 0.0
var _return_state := &"IdleState"
var _knockback_dir := Vector2.ZERO

# Called by FSM manager before entering, to store return state
func set_return_state(state_name: StringName) -> void:
    _return_state = state_name

func enter() -> void:
    _timer = 0.0
    actor.get_node("AnimationPlayer").play("hurt")
    # Flash red
    var tw := actor.create_tween()
    tw.tween_property(actor, "modulate", Color(1.5, 0.3, 0.3), 0.05)
    tw.tween_property(actor, "modulate", Color.WHITE, 0.1)

func on_hurt(damage_source: Node2D) -> void:
    _knockback_dir = (actor.global_position - damage_source.global_position).normalized()

func process_physics(delta: float) -> void:
    _timer += delta
    actor.velocity = _knockback_dir * KNOCKBACK_SPEED * (1.0 - _timer / HURT_DURATION)
    actor.move_and_slide()
    if _timer >= HURT_DURATION:
        transition_to(_return_state)
```

In the FSM manager, before transitioning to HurtState, store the current state name:

```gdscript
func _on_hurt(damage_source: Node2D) -> void:
    var hurt_state := find_child("EnemyHurtState") as EnemyHurtState
    hurt_state.set_return_state(current_state.name)
    if current_state.has_method("on_hurt"):
        current_state.on_hurt(damage_source)
    _on_transition_requested(&"EnemyHurtState")
```
::::
:::

:::problem{difficulty="challenge"}
**5. Full AnimationTree Hybrid with Blend Parameters**

Create a player with a class-based FSM for logic and an AnimationTree for visuals. The Run state should set the AnimationTree's `parameters/run_blend/blend_position` (a BlendSpace1D or 2D) based on the player's speed and direction, so animations blend between walk/run automatically. The ATTACK state should play a one-shot attack clip and transition back to Idle when it finishes. Show the key code for the RunState and AttackState.

::::solution[Solution]
```gdscript
# run_state.gd
class_name PlayerRunState extends State

const SPEED := 200.0

@onready var anim_tree: AnimationTree = actor.get_node("AnimationTree")
@onready var playback: AnimationNodeStateMachinePlayback = \
    anim_tree.get("parameters/playback")

func enter() -> void:
    playback.travel("Run")

func process_physics(delta: float) -> void:
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    actor.velocity = dir * SPEED

    # Drive blend position by input direction (x for strafe, y for forward)
    anim_tree.set("parameters/run_blend/blend_position", dir)

    if dir == Vector2.ZERO:
        transition_to(&"IdleState")
    elif Input.is_action_just_pressed("attack"):
        transition_to(&"AttackState")
    actor.move_and_slide()
```

```gdscript
# attack_state.gd
class_name PlayerAttackState extends State

@onready var anim_tree: AnimationTree = actor.get_node("AnimationTree")
@onready var playback: AnimationNodeStateMachinePlayback = \
    anim_tree.get("parameters/playback")

func enter() -> void:
    actor.velocity = Vector2.ZERO
    playback.travel("Attack")

func process_physics(_delta: float) -> void:
    actor.move_and_slide()
    # Return to Idle when attack animation finishes
    # AnimationTree auto-advances back to Idle if transition is set to "auto"
    if playback.get_current_node() == &"Idle":
        transition_to(&"IdleState")
```
::::
:::
