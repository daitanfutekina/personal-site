---
title: "Polish, Tweens, Timers & Game Feel (Juice)"
source: "godot_ch65_polish.html"
---

Part XI · Chapter 65

# Polish, Tweens, Timers & Game Feel (Juice)

Estimated study time: 80 min · Godot 4.x · GDScript

## Chapter Overview

Two games with identical mechanics can feel completely different. One feels snappy and
 satisfying; the other feels flat and lifeless. The difference is **game feel**
 — the collection of micro-feedback moments that make every action feel good.
 This chapter teaches the core techniques: Godot 4's **Tween API**,
 screen shake, hit stop, impact particles, floating damage numbers, audio juice,
 and UI animations.

## What Is Game Juice?

:::callout-intuition[Intuition]
"Juice" is the extra layer of feedback that tells the player "yes, that thing you just did

mattered

." A sword swing with no juice: the hitbox fires, health decreases.
  With juice: the sword flashes white, the screen shakes for 3 frames, a hit sound plays with
  slight pitch variation, a "—25" number floats up, and the enemy staggers back 10 pixels.
  Same mechanic — completely different feel.
:::

The main juice categories:

| Category | Examples | Why it works |
| --- | --- | --- |
| Visual feedback | Screen shake, hit flash, squash & stretch | Confirms the player's action had impact |
| Temporal feedback | Hit stop, slow motion, anticipation wind-up | Creates rhythm and weight |
| Spatial feedback | Knockback, impact particles, damage numbers | Shows direction and magnitude of events |
| Audio feedback | Pitch variation, layered sounds, UI clicks | Multi-sense confirmation makes events feel real |
| UI feedback | Button squash, health bar ease, score bounce | Makes the interface feel alive |

Player

presses attack

Game Logic

damage applied

Juice Layer

Screen Shake

3–6 frame trauma burst

Hit Flash

white modulate, 0.1s

Hit Stop

Engine.time\_scale=0

Damage Numbers

float up + fade out

Impact Particles

GPUParticles2D burst

Pitch-varied SFX

pitch\_scale ±0.15

A single player action triggers the game logic and simultaneously fires a full juice layer — all running in parallel on the same frame. None of these elements change *what* happened; they change how it *feels*.

## The Tween API

:::callout-intuition[Intuition]
A Tween smoothly moves a value from A to B over time using a mathematical easing curve.
  Instead of writing per-frame interpolation code, you describe the animation in 2–3 lines
  and the engine handles it. Godot 4's Tween API is chainable and supports any property,
  methods, and callbacks.
:::

### Creating a Tween

```gdscript
## Three ways to create a tween

## 1. Bound to this node (auto-freed when node is freed)
var tween := create_tween()

## 2. Global (not tied to any node — use for scene transitions)
var tween := get_tree().create_tween()

## 3. With flags
var tween := create_tween().set_loops().set_parallel()
```

### Core Tween Methods

```gdscript
var tween := create_tween()

## tween_property: smoothly change a node property
tween.tween_property($Sprite2D, "scale", Vector2(1.3, 0.7), 0.1)  # squash
tween.tween_property($Sprite2D, "scale", Vector2.ONE, 0.15)        # recover

## tween_method: call a method with interpolated value
tween.tween_method(_set_alpha, 1.0, 0.0, 0.5)     # fade out over 0.5s

## tween_callback: call a function at a point in the chain
tween.tween_callback(queue_free)                    # free after fade

## tween_interval: pause between steps
tween.tween_interval(0.2)
```

### Easing Functions

Easing controls the acceleration curve. Set it on any tweener with `.set_ease()`
 and `.set_trans()`:

```gdscript
tween.tween_property($Button, "scale", Vector2(1.2, 1.2), 0.15) \
    .set_ease(Tween.EASE_OUT) \
    .set_trans(Tween.TRANS_BACK)
```

| Transition | Shape | Best for |
| --- | --- | --- |
| TRANS\_LINEAR | Constant speed | Looping animations, progress bars |
| TRANS\_SINE | Smooth S-curve | General UI, breathing effects |
| TRANS\_QUAD / CUBIC | Moderate ease | Menu transitions, camera moves |
| TRANS\_QUART / QUINT | Strong ease | Fast-out UI snapping |
| TRANS\_EXPO | Aggressive ease | Pop-in effects |
| TRANS\_BACK | Overshoots & returns | Button press, item pickup |
| TRANS\_BOUNCE | Bounces at end | Landing, drop effects |
| TRANS\_ELASTIC | Wobbles like a spring | Health bar hits, damage pop |
| TRANS\_SPRING | Physics spring | Realistic spring settle |

| Ease | Meaning |
| --- | --- |
| EASE\_IN | Slow start, fast end |
| EASE\_OUT | Fast start, slow end (most natural) |
| EASE\_IN\_OUT | Slow start and end, fast middle |
| EASE\_OUT\_IN | Fast start and end, slow middle |

LINEAR

constant speed

EASE\_IN

slow start → fast end

EASE\_OUT

fast start → slow end ✓

EASE\_IN\_OUT

slow–fast–slow

The four easing modes. **EASE\_OUT** feels most natural for most juice — the action starts fast and eases to rest, mimicking real-world physics.

### Common Tween Patterns

```gdscript
## Squash and stretch on jump
func jump() -> void:
    velocity.y = -JUMP_SPEED
    var t := create_tween()
    t.tween_property(self, "scale", Vector2(0.8, 1.3), 0.1).set_ease(Tween.EASE_OUT)
    t.tween_property(self, "scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_ELASTIC)

## Fade-in on spawn
func _ready() -> void:
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 0.3).set_ease(Tween.EASE_OUT)

## Punch scale (item pickup)
func show_pickup() -> void:
    var t := create_tween()
    t.tween_property(self, "scale", Vector2(1.4, 1.4), 0.08).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
    t.tween_property(self, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

## Infinite bob (idle item)
func _ready() -> void:
    create_tween().set_loops().tween_property(
        self, "position:y", position.y - 8.0, 1.2
    ).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```

## Screen Shake

```gdscript
## ScreenShake.gd — attach to Camera2D (autoload-friendly)
extends Camera2D

var _shake_strength  := 0.0
var _shake_decay     := 5.0    ## strength lost per second
var _rng             := RandomNumberGenerator.new()

func shake(strength: float, decay: float = 5.0) -> void:
    _shake_strength = strength
    _shake_decay    = decay

func _process(delta: float) -> void:
    if _shake_strength > 0.01:
        offset = Vector2(
            _rng.randf_range(-_shake_strength, _shake_strength),
            _rng.randf_range(-_shake_strength, _shake_strength)
        )
        _shake_strength = lerpf(_shake_strength, 0.0, _shake_decay * delta)
    else:
        _shake_strength = 0.0
        offset = Vector2.ZERO
```

Usage: `$Camera2D.shake(12.0)` on hit, `shake(6.0)` for lighter impacts.

:::callout-tip[Traumatic Shake (Better Pattern)]
Instead of a flat strength value, accumulate a "trauma" amount (0–1) and
  raise it to a power (e.g. trauma²) for more natural decay:

```gdscript
var _trauma := 0.0

func add_trauma(amount: float) -> void:
    _trauma = minf(_trauma + amount, 1.0)

func _process(delta: float) -> void:
    _trauma = maxf(0.0, _trauma - delta * 1.5)
    var shake := _trauma * _trauma * 20.0   # quadratic for natural feel
    offset = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
```
:::

## Hit Stop (Time Freeze)

Hit stop freezes the game for a few frames at the moment of impact — the player's brain
 registers "something significant happened." Used in Hollow Knight, Celeste, and nearly
 every great action game.

```gdscript
## HitStop.gd (autoload)
extends Node

func freeze(duration_seconds: float) -> void:
    Engine.time_scale = 0.0
    await get_tree().create_timer(duration_seconds, true, false, true).timeout
    Engine.time_scale = 1.0
```

Usage: `HitStop.freeze(0.06)` — 60 ms freeze. The
 `create_timer` parameters `true, false, true` mean:
 process always (not affected by time\_scale), not physics, use real time.
 This ensures the timer fires even though time\_scale is 0.

:::callout-warning[time\_scale Affects Everything]
Engine.time\_scale = 0.0

pauses

all

physics and animation.
  Audio continues (controlled separately). If you want only the hit enemy to freeze,
  use

process\_mode = PROCESS\_MODE\_DISABLED

on that node instead.
:::

## Impact Particles

```gdscript
## ImpactSpawner.gd (autoload) — pool-friendly one-shot particles
extends Node

const IMPACT := preload("res://vfx/impact_particles.tscn")

func spawn(position: Vector2, normal: Vector2 = Vector2.UP) -> void:
    var p := IMPACT.instantiate() as GPUParticles2D
    get_tree().root.add_child(p)
    p.global_position = position
    # Orient particles toward normal (e.g., wall hit direction)
    p.rotation = normal.angle() - PI * 0.5
    p.emitting = true
    # Auto-free after particle lifetime
    var lifetime := p.lifetime * (1.0 + p.explosiveness)
    get_tree().create_timer(lifetime + 0.1).timeout.connect(p.queue_free)
```

Connect to your hitbox: `ImpactSpawner.spawn(hit_position, hit_normal)`.

## Floating Damage Numbers

```gdscript
## DamageNumber.gd — attach to Label node, instantiate per hit
extends Label

func _ready() -> void:
    # Drift upward and fade out
    var t := create_tween()
    t.set_parallel(true)
    t.tween_property(self, "position:y", position.y - 40.0, 0.8).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
    t.tween_property(self, "modulate:a", 0.0, 0.8).set_ease(Tween.EASE_IN)
    t.tween_callback(queue_free).set_delay(0.8)

## DamageNumbers.gd (autoload)
extends Node

const DN := preload("res://ui/damage_number.tscn")

func spawn(amount: int, world_position: Vector2, color: Color = Color.WHITE) -> void:
    var dn := DN.instantiate() as Label
    get_tree().root.add_child(dn)
    dn.text = str(amount)
    dn.modulate = color
    dn.global_position = world_position + Vector2(randf_range(-12.0, 12.0), -20.0)
    # Slight size variation
    dn.scale = Vector2.ONE * randf_range(0.9, 1.2)
```

## Audio Juice

### Pitch Variation

Identical sounds played back-to-back sound robotic. Add ±10–15% pitch variation:

```gdscript
func play_hit_sound() -> void:
    var player := $HitSFX as AudioStreamPlayer2D
    player.pitch_scale = randf_range(0.9, 1.15)
    player.play()
```

### Randomised Sound Pools

```gdscript
## SoundPool.gd — pick a random variant from an array
extends AudioStreamPlayer

@export var sounds: Array[AudioStream] = []

func play_random() -> void:
    if sounds.is_empty(): return
    stream      = sounds[randi() % sounds.size()]
    pitch_scale = randf_range(0.92, 1.08)
    play()
```

### UI Hover & Click Sounds

```gdscript
## UIAudio.gd (autoload)
extends Node

@export var hover_sound : AudioStream
@export var click_sound : AudioStream
var _player := AudioStreamPlayer.new()

func _ready() -> void:
    add_child(_player)
    _player.bus = "UI"

func play_hover() -> void:
    _player.stream      = hover_sound
    _player.pitch_scale = randf_range(0.95, 1.05)
    _player.play()

func play_click() -> void:
    _player.stream      = click_sound
    _player.pitch_scale = randf_range(0.93, 1.07)
    _player.play()
```

## UI Juice

### Health Bar Ease

```gdscript
## HealthBar.gd — smooth bar that lags behind actual health
extends ProgressBar

var _display_value: float
var _tween: Tween

func set_health(new_val: float, max_val: float) -> void:
    max_value = max_val
    if _tween: _tween.kill()
    _tween = create_tween()
    _tween.tween_property(self, "value", new_val, 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
```

### Button Hover & Press Feedback

```gdscript
## JuicyButton.gd — attach to Button node
extends Button

const HOVER_SCALE  := Vector2(1.06, 1.06)
const PRESS_SCALE  := Vector2(0.94, 0.94)
const NORMAL_SCALE := Vector2.ONE

func _ready() -> void:
    pivot_offset = size * 0.5
    mouse_entered.connect(_on_hover)
    mouse_exited.connect(_on_unhover)
    button_down.connect(_on_press)
    button_up.connect(_on_release)

func _on_hover() -> void:
    UIAudio.play_hover()
    _tween_scale(HOVER_SCALE, Tween.TRANS_BACK)

func _on_unhover() -> void:
    _tween_scale(NORMAL_SCALE, Tween.TRANS_SINE)

func _on_press() -> void:
    UIAudio.play_click()
    _tween_scale(PRESS_SCALE, Tween.TRANS_QUAD)

func _on_release() -> void:
    _tween_scale(HOVER_SCALE, Tween.TRANS_BACK)

func _tween_scale(target: Vector2, trans: int) -> void:
    var t := create_tween()
    t.tween_property(self, "scale", target, 0.1).set_ease(Tween.EASE_OUT).set_trans(trans)
```

## Worked Example — Hit Reaction System

**Goal:** When an enemy takes damage, trigger all juice simultaneously:
 hit flash, screen shake, hit stop, floating damage number, and impact particle.

```gdscript
## Enemy.gd
extends CharacterBody2D

@onready var sprite    := $Sprite2D as Sprite2D
@onready var hitbox    := $HurtboxComponent as Area2D

const FLASH_MATERIAL := preload("res://materials/hit_flash.tres")   # shader that multiplies colour

var _original_material: Material

func _ready() -> void:
    _original_material = sprite.material
    hitbox.area_entered.connect(_on_hurt)

func _on_hurt(hitbox_area: Area2D) -> void:
    var damage: int = hitbox_area.get_meta("damage", 10)
    take_damage(damage)

func take_damage(amount: int) -> void:
    # 1. Damage number
    DamageNumbers.spawn(amount, global_position, Color.ORANGE_RED)

    # 2. Hit flash
    sprite.material = FLASH_MATERIAL
    await get_tree().create_timer(0.08).timeout
    sprite.material = _original_material

    # 3. Screen shake
    %Camera.add_trauma(0.3)

    # 4. Hit stop (slight freeze)
    HitStop.freeze(0.05)

    # 5. Impact particles
    ImpactSpawner.spawn(global_position)

    # 6. Squash on hit
    var t := create_tween()
    t.tween_property(sprite, "scale", Vector2(1.3, 0.7), 0.05)
    t.tween_property(sprite, "scale", Vector2.ONE, 0.1).set_trans(Tween.TRANS_ELASTIC)
```

All six effects fire simultaneously (or within a frame) — the player's brain fuses them
 into a single satisfying "crunch." Remove any one and the hit feels cheaper.

:::summary
### Chapter 65 — Juice Checklist

| Effect | Godot API | Typical values |
| --- | --- | --- |
| Squash & stretch | `tween_property(node, "scale", ...)` | ±20–30%, 0.1–0.2 s, TRANS\_BACK or ELASTIC |
| Fade in/out | `tween_property(node, "modulate:a", ...)` | 0.2–0.5 s, EASE\_OUT |
| Screen shake | Camera2D offset + decay | Trauma 0.2–0.5, decay 1.5/s |
| Hit stop | `Engine.time_scale = 0.0` | 40–80 ms |
| Hit flash | Swap material, await timer, swap back | 60–100 ms |
| Damage numbers | Label + tween up + fade out | 0.8 s lifetime, 40 px rise |
| Impact particles | GPUParticles2D, one-shot, auto-free | 0.2–0.5 s lifetime |
| Pitch variation | `AudioStreamPlayer.pitch_scale` | randf\_range(0.9, 1.15) |
| UI button scale | scale tween on mouse\_entered | 1.06×, EASE\_OUT BACK |
| Health bar ease | tween ProgressBar.value | 0.4 s, EASE\_OUT QUAD |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Infinite Bob Animation

Write the code to make a collectible coin bob up and down infinitely between
 its start position and 8 pixels above it, using a sine ease for smoothness.
 The full cycle should take 1.4 seconds.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var start_y := position.y
    var tween := create_tween().set_loops()
    tween.tween_property(self, "position:y", start_y - 8.0, 0.7) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tween.tween_property(self, "position:y", start_y, 0.7) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```
::::
:::

:::problem{difficulty="easy"}
#### 2. Screen Shake Integration

Using the trauma-based screen shake from the chapter, write the one-line call
 that would produce a strong explosion shake (trauma 0.8) versus a light footstep
 rumble (trauma 0.05). Then explain why you shouldn't use a flat shake value for
 explosions.

::::solution[Solution]
```gdscript
## Explosion:
%Camera.add_trauma(0.8)

## Footstep:
%Camera.add_trauma(0.05)
```

A flat shake value (e.g. `shake(20.0)`) doesn't accumulate — if two explosions
 happen simultaneously you cap at the same strength. The trauma model accumulates (capped at 1.0)
 so multiple overlapping impacts stack naturally. It also decays smoothly via the quadratic curve,
 giving the shake a more organic feel.
::::
:::

:::problem{difficulty="standard"}
#### 3. Hit Stop Implementation

The chapter's `HitStop.freeze()` uses `Engine.time_scale = 0.0`.
 Write an alternative version that instead of freezing everything, only freezes the
 enemy that was hit by setting its `process_mode`, while the player and
 screen shake continue normally.

::::solution[Solution]
```gdscript
## In Enemy.gd
func freeze_self(duration: float) -> void:
    process_mode = PROCESS_MODE_DISABLED   # pauses _process and _physics_process for this node
    await get_tree().create_timer(duration).timeout
    process_mode = PROCESS_MODE_INHERIT    # restore to parent's mode
```

Unlike `Engine.time_scale`, this only pauses the specific node (and its children).
 The camera shake, player movement, and UI all continue at normal speed. This is more surgical
 and is the correct approach when you only want the hit enemy to stagger.
::::
:::

:::problem{difficulty="standard"}
#### 4. Death Animation Sequence

Write a `die()` function using a single Tween chain that:
 (a) squashes the sprite to 80% height over 0.05 s,
 (b) waits 0.1 s,
 (c) scales the sprite to zero over 0.15 s with an elastic ease,
 (d) fades modulate.a to 0 in parallel with step (c),
 (e) frees the node when done.

::::solution[Solution]
```gdscript
func die() -> void:
    # Prevent further processing while dying
    set_physics_process(false)
    set_process(false)

    var t := create_tween()

    # (a) Squash
    t.tween_property($Sprite2D, "scale", Vector2(1.2, 0.8), 0.05) \
        .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

    # (b) Wait
    t.tween_interval(0.1)

    # (c) Scale to zero + (d) Fade — parallel
    t.set_parallel(true)
    t.tween_property($Sprite2D, "scale", Vector2.ZERO, 0.15) \
        .set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_IN)
    t.tween_property(self, "modulate:a", 0.0, 0.15) \
        .set_ease(Tween.EASE_IN)

    # (e) Free when done
    t.set_parallel(false)
    t.tween_callback(queue_free)
```
::::
:::

:::problem{difficulty="challenge"}
#### 5. Full Juice System

Design a reusable `JuiceComponent` (Node child) that any object can add.
 It should expose methods: `play_hit(damage: int)` and
 `play_death()`. Internally it handles hit flash (material swap),
 squash animation, damage number, and screen shake — all configurable via
 `@export` variables.

::::solution[Solution]
```gdscript
## JuiceComponent.gd
class_name JuiceComponent extends Node

@export var target_sprite   : Sprite2D
@export var flash_material  : ShaderMaterial
@export var flash_duration  : float = 0.08
@export var shake_trauma    : float = 0.25
@export var squash_amount   : float = 0.3
@export var show_damage_num : bool  = true

var _original_material : Material

func _ready() -> void:
    if target_sprite:
        _original_material = target_sprite.material

func play_hit(damage: int) -> void:
    if target_sprite and flash_material:
        _flash()
    _squash()
    if shake_trauma > 0.0:
        var cam := get_viewport().get_camera_2d()
        if cam and cam.has_method("add_trauma"):
            cam.add_trauma(shake_trauma)
    if show_damage_num:
        DamageNumbers.spawn(damage, get_parent().global_position, Color.ORANGE_RED)

func play_death() -> void:
    var t := create_tween()
    t.tween_property(get_parent(), "scale", Vector2.ZERO, 0.2).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_IN)
    t.tween_property(get_parent(), "modulate:a", 0.0, 0.2).set_ease(Tween.EASE_IN)
    t.set_parallel(false)
    t.tween_callback(get_parent().queue_free)

func _flash() -> void:
    target_sprite.material = flash_material
    await get_tree().create_timer(flash_duration).timeout
    target_sprite.material = _original_material

func _squash() -> void:
    var t := create_tween()
    t.tween_property(get_parent(), "scale",
        Vector2(1.0 + squash_amount, 1.0 - squash_amount * 0.5), 0.05
    ).set_ease(Tween.EASE_OUT)
    t.tween_property(get_parent(), "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_ELASTIC)
```

Usage: add `JuiceComponent` as a child, set the exports, then call
 `$JuiceComponent.play_hit(damage)` from the health handler.
::::
:::
