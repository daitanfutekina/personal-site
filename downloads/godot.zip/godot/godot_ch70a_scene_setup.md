---
title: "Earclacks — Scene Setup & Physics Arena"
crumb: "Earclacks Weapon Ball — Chapter 70A"
meta:
  - "Est. study time: ~60 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview & Prerequisites

This chapter is purely about infrastructure. No weapons, no AI, no health — just the empty arena that everything else will live inside. Getting the physics foundation right here prevents a cascade of bugs later.

:::callout-key[KEY CONCEPT]
A 1080 × 1080 square Godot 4 project with: global gravity disabled, a four-wall physics arena using

StaticBody2D

nodes with

PhysicsMaterial

(bounce 0.8, friction 0), a fixed

Camera2D

, a solid-colour

WorldEnvironment

, and a

GameManager.gd

autoload with a

State

enum skeleton.
:::

### Prerequisites

- Completed the [Ch 70 Design Sheet](./godot_ch70_design_sheet.html) — you know the scene hierarchy
- Comfortable with `StaticBody2D` and `CollisionShape2D` ([Ch 8](./godot_ch8_2d_physics.html))
- Know how to create an Autoload ([Ch 12](./godot_ch12_autoloads_singletons.html))
- Godot 4.3+ installed

## 1. Project Setup — Square Resolution for Shorts

:::callout-intuition[INTUITION]
Earclacks-style videos are built for YouTube Shorts and Instagram Reels, both of which prefer a 9:16 portrait or 1:1 square crop. A 1080 × 1080 viewport fills both formats without letterboxing. Everything in this series is designed around that square.
:::

1. **Create a new Godot 4 project.** In the Project Manager click *New Project*, name it `WeaponBall`, choose a folder, leave renderer on *Forward+*, and click *Create & Edit*.
2. **Set the viewport size.** Go to *Project → Project Settings → Display → Window*.

 Width — 1080
 Height — 1080
 Stretch / Mode — canvas\_items
 Stretch / Aspect — keep

 *Stretch → canvas\_items + keep* means if the window is resized the content scales uniformly and no extra space appears on either axis.
3. **Create the folder structure.** In the FileSystem dock right-click *res://* and add these folders:

 Keeping scenes and scripts separate is a hard rule throughout this series.

   ```
   res://
   ├── scenes/
   │   ├── arena/
   │   ├── balls/
   │   └── weapons/
   ├── scripts/
   │   └── autoload/
   └── assets/
   ```

## 2. Disabling Global Gravity

:::callout-intuition[INTUITION]
In Godot's default physics world, gravity pulls everything downward at 980 px/s². Every

RigidBody2D

inherits this unless you override it. Weapon-ball fights happen in a zero-gravity vacuum — the balls have inertia and bounce but nothing drags them down. You set this once globally so you never have to remember to set

gravity\_scale = 0

on individual bodies.
:::

1. Open *Project → Project Settings* and search for **gravity**.
2. Under *Physics → 2D*, find **Default Gravity** and set it to `0`.

 Physics / 2D / Default Gravity — 0
3. Close Project Settings and save the project (Ctrl + S).

:::callout-pitfall[PITFALL]
If you forget this step and instead set

gravity\_scale = 0

on the Ball node, it works — but you have to remember it on every ball variant, every test body, every spawned instance. Setting it globally once is the correct approach for a zero-gravity game.
:::

## 3. Creating the Arena Scene

The arena scene is the root scene for every match. It owns the walls, the camera, the HUD canvas layer, and the game-over overlay. You'll populate it in stages across this chapter.

1. In the Scene dock, click *Other Node* and choose `Node2D`. Rename it `Arena`.
2. Save the scene immediately: Ctrl + S → `res://scenes/arena/Arena.tscn`.
3. Add three child `Node2D` nodes under `Arena` and name them:

 Add a `CanvasLayer` child, name it `HUD`. Add another `CanvasLayer` child, name it `GameOverScreen`.

   - `ArenaWalls` — will hold the four StaticBody2D walls
   - `Balls` — will hold spawned ball instances at runtime
   - `BallSpawner` — holds two `Marker2D` spawn points

4. Inside `BallSpawner` add two `Marker2D` nodes named `SpawnLeft` and `SpawnRight`. Position them symmetrically:

 SpawnLeft / Position — (-270, 0)
 SpawnRight / Position — (270, 0)

 The arena runs from −540 to +540 on both axes (1080 px square). Spawning at ±270 puts each ball a quarter-width from the centre.

Your scene tree should now look like this:

```
Arena [Node2D]
├── ArenaWalls [Node2D]
├── BallSpawner [Node2D]
│   ├── SpawnLeft [Marker2D]
│   └── SpawnRight [Marker2D]
├── Balls [Node2D]
├── HUD [CanvasLayer]
└── GameOverScreen [CanvasLayer]
```

## 4. Building the Four Walls

:::callout-intuition[INTUITION]
Each wall does two entirely separate things: it blocks physics objects (

StaticBody2D

+

CollisionShape2D

) and it draws a visible border (

ColorRect

). Keep those responsibilities on separate nodes — never use a

CollisionShape2D

to drive visuals or vice versa.
:::

You'll create four walls: Left, Right, Top, Bottom. Each is a `StaticBody2D` under `ArenaWalls`. The steps below give exact numbers for a 1080 × 1080 arena with 20-pixel-thick walls.

### Wall Dimensions Reference

| Wall | Size (W × H) | Position (centre) | Notes |
| --- | --- | --- | --- |
| WallLeft | 20 × 1080 | (-540, 0) | Sits flush on left edge |
| WallRight | 20 × 1080 | (540, 0) | Sits flush on right edge |
| WallTop | 1080 × 20 | (0, -540) | Sits flush on top edge |
| WallBottom | 1080 × 20 | (0, 540) | Sits flush on bottom edge |

:::callout-tip[TIP]
Godot 2D places the origin (0, 0) at the top-left of the viewport by default, but with a centred Camera2D the effective centre of your 1080 × 1080 arena becomes (0, 0) in world space. All wall positions above assume the Camera2D is positioned at (0, 0) with no zoom — which is exactly what you'll set in Section 6.
:::

1. **Create WallLeft.** Under `ArenaWalls`, add a `StaticBody2D`. Rename it `WallLeft`. Set its *Position* to `(-540, 0)`.
 Add a `CollisionShape2D` child. In the Inspector set *Shape* to *New RectangleShape2D*. Set the rectangle's *Size* to `(20, 1080)`.
 Add a `ColorRect` child. Set its *Size* to `(20, 1080)`, *Position* to `(-10, -540)`, and *Color* to a muted steel-blue like `#3a6080`.
2. **Duplicate for the other three walls.** Right-click `WallLeft` → *Duplicate*. Rename to `WallRight`, set Position to `(540, 0)` — all shapes stay the same.
 Duplicate again → `WallTop`. Set Position to `(0, -540)`. Change the `CollisionShape2D` rectangle size to `(1080, 20)` and the `ColorRect` size to `(1080, 20)`, position to `(-540, -10)`.
 Duplicate `WallTop` → `WallBottom`. Set Position to `(0, 540)`. Shapes remain (1080, 20).
3. **Physics Layer assignment.** Select each wall's `StaticBody2D`. In the Inspector under *Collision*:

 Layer — Layer 2 only
 Mask — Layer 1 (Balls)

 Walls exist on Layer 2 and scan for Layer 1. This matches the physics layer table from the design sheet.

:::callout-pitfall[PITFALL]
ColorRect

draws from its own top-left corner, not from the centre. So a 20 × 1080

ColorRect

needs its position set to

(-10, -540)

to be visually centred on the

StaticBody2D

which is positioned by its centre. If you leave the

ColorRect

at (0, 0) the visual will be offset 10 px to the right of the collision shape.
:::

## 5. Assigning a PhysicsMaterial to the Walls

:::callout-intuition[INTUITION]
By default, a

StaticBody2D

has

zero bounce

and

full friction

. If you leave it that way, balls hit the wall once and stop dead. A

PhysicsMaterial

resource is how Godot lets you override those defaults. Setting

bounce = 0.8

means 80% of the ball's incoming speed is reflected — the ball keeps bouncing almost indefinitely, which is the entire visual appeal of the format.
:::

1. Select `WallLeft` in the Scene dock. In the Inspector find the *Physics Material Override* property and click the dropdown to create a *New PhysicsMaterial*.

 Bounce — 0.8
 Friction — 0.0
2. **Save the resource so you can reuse it.** Click the floppy-disk icon next to the PhysicsMaterial and save it as `res://assets/wall_physics.tres`.
3. Select `WallRight`, `WallTop`, and `WallBottom` one at a time. For each one set *Physics Material Override* → *Load* → `res://assets/wall_physics.tres`. All four walls now share the same resource file, so changing bounce in one place updates all of them.

:::callout-key[KEY CONCEPT]
Godot

adds

the bounce of the two colliding bodies and clamps the total at 1 — two surfaces at 0.3 and 0.2 collide as 0.5, and two at 0.9 both behave as 1.0. So the ball keeps its

physics\_material.bounce = 0

and still bounces, because the wall contributes all 0.8 on its own. The one switch on the material is

Absorbent

, which subtracts that material's bounce from the other one instead of adding it — useful for a surface that is meant to deaden an impact.
:::

## 6. Camera2D and WorldEnvironment

### Camera2D

The camera is fixed for the entire match — it never moves or zooms. Weapon-ball content lives or dies on always having the full arena visible.

1. Add a `Camera2D` child directly under `Arena` (not inside ArenaWalls).
2. Set its properties:

 Position — (0, 0)
 Zoom — (1, 1)
 Anchor Mode — Fixed TopLeft → leave default

 With a 1080 × 1080 viewport and *Zoom (1, 1)*, the camera centred at (0, 0) shows the range −540 to +540 on both axes — exactly the arena.
3. Tick *Current* to make it the active camera when the scene loads.

### WorldEnvironment

Without a `WorldEnvironment` the background is the default Godot grey. A flat near-black background makes the balls and weapons pop.

1. Add a `WorldEnvironment` child under `Arena`.
2. In the Inspector click *Environment* → *New Environment*.
3. Inside the new Environment resource, set:

 Background / Mode — Color
 Background / Color — #0d1117

 This matches the dark navy theme of the textbook's own styling — subtle brand consistency.

## 7. GameManager Autoload

:::callout-intuition[INTUITION]
The

GameManager

needs to be reachable from every node in the scene — the HUD, each ball, the walls, the game-over screen. Autoloads are globally accessible singletons that live for the entire lifetime of the application. You don't have to pass a reference around or use

get\_node("../../GameManager")

fragile paths. You just call

GameManager.start\_match()

from anywhere.
:::

1. Create the script file. In the FileSystem dock navigate to `res://scripts/autoload/`, right-click → *New Script* → name it `GameManager.gd`.
2. Paste this skeleton (you'll expand it in Chapter 70E):

   ```gdscript
   extends Node

   # ─── State Machine ───────────────────────────────────────────────
   enum State { WAITING, COUNTDOWN, FIGHTING, GAME_OVER }
   var current_state: State = State.WAITING

   # ─── Match Data ──────────────────────────────────────────────────
   var balls_alive: int = 0
   var match_number: int = 0

   # ─── Signals ─────────────────────────────────────────────────────
   signal match_started
   signal match_ended(winner_name: String)
   signal state_changed(new_state: State)

   # ─────────────────────────────────────────────────────────────────
   func _ready() -> void:
       print("[GameManager] Ready. State: WAITING")

   func set_state(new_state: State) -> void:
       if current_state == new_state:
           return
       current_state = new_state
       state_changed.emit(new_state)
       print("[GameManager] → ", State.keys()[new_state])

   func start_match() -> void:
       match_number += 1
       balls_alive = 2
       set_state(State.COUNTDOWN)
       # Countdown timer added in Ch 70E
       set_state(State.FIGHTING)
       match_started.emit()

   func ball_died(ball_name: String) -> void:
       balls_alive -= 1
       if balls_alive <= 0:
           end_match(ball_name)       # last-ball-standing edge case handled in Ch 70E

   func end_match(winner_name: String) -> void:
       set_state(State.GAME_OVER)
       match_ended.emit(winner_name)
   ```

3. Register it as an Autoload. Go to *Project → Project Settings → Autoload*. Click the folder icon, navigate to `res://scripts/autoload/GameManager.gd`, and click *Add*. The node name defaults to `GameManager` — leave it as-is.

 TIP
 The autoload node name is what you reference in code: `GameManager.start_match()`. Do not rename it to `game_manager` or `GM` — the rest of the series uses `GameManager` exactly.

### Understanding the State Machine

The `State` enum is the backbone of match flow. Here's what each state means:

| State | Meaning | Transitions To |
| --- | --- | --- |
| `WAITING` | Scene loaded, no match active. Balls not yet spawned. | COUNTDOWN (on start\_match) |
| `COUNTDOWN` | Balls spawned and frozen. 3-2-1 timer running. | FIGHTING (timer ends) |
| `FIGHTING` | Physics active, weapons rotating, AI running. | GAME\_OVER (ball\_died) |
| `GAME_OVER` | Winner known. Overlay visible. Waiting for replay. | COUNTDOWN (replay) or exit |

The skeleton above skips directly from COUNTDOWN to FIGHTING (no timer) — that's intentional. You'll add the real countdown `Timer` node in Chapter 70E when the HUD exists. Starting simple keeps this chapter focused on infrastructure.

## 8. Verification — The Bounce Test

Before you add any balls, weapons, or AI, prove that the arena physics are correct. You do this by adding a temporary test ball that bounces indefinitely.

:::callout-key[KEY CONCEPT]
1. The ball doesn't fall (gravity = 0).
2. The ball bounces off all four walls (PhysicsMaterial bounce = 0.8).
3. The ball doesn't gain or lose excessive speed (no phantom forces).
4. The ball doesn't pass through walls at high speed (collision is solid).
:::

1. **Create a temporary test ball.** In the Arena scene, add a `RigidBody2D` child directly under `Arena` (NOT under Balls — this is temporary). Name it `TestBall`.

 Position — (0, 0)
 Gravity Scale — 0
 Linear Damp — 0
 Lock Rotation — ✓ (enabled)

 Setting *Linear Damp = 0* here (instead of the final 0.4) makes it easier to verify that bouncing works — the ball should keep nearly full speed. You'll add damping in Chapter 70B.
2. Add a `CollisionShape2D` child. Set Shape to *New CircleShape2D*, radius `40`.
3. Add a `ColorRect` child. Size `(80, 80)`, Position `(-40, -40)`, Color a bright orange `#f0883e`.
4. **Give it an initial velocity via script.** Add a new script to `TestBall`:

   ```gdscript
   extends RigidBody2D

   func _ready() -> void:
       # Launch at an angle so we test multiple walls
       linear_velocity = Vector2(400, 300)
   ```

5. **Set the physics layer.** On the `TestBall` `RigidBody2D` under *Collision*:

 Layer — Layer 1 (Balls)
 Mask — Layer 2 (Walls)
6. **Press F5 (Run Project).** Set Arena.tscn as the main scene when prompted.

### What You Should See

The orange ball launches toward the top-right, bounces off the right wall, then the top wall (or corner), then continues bouncing around the arena indefinitely. Its speed should slowly drift toward zero over many bounces due to the 0.8 bounce coefficient — 80% retained per bounce means after 10 bounces: `0.8^10 ≈ 0.107`, or about 10% of original speed. That's fine and expected.

:::callout-pitfall[PITFALL]
- **Ball falls off screen:** Global gravity is still 980. Recheck *Project Settings → Physics → 2D → Default Gravity = 0*.
- **Ball passes through walls:** The wall's CollisionShape2D size doesn't match the expected position. Verify all four wall sizes and positions from the table in Section 4.
- **Ball sticks to wall:** PhysicsMaterial not assigned, or Bounce is 0. Check all four walls have `wall_physics.tres` loaded with bounce 0.8.
- **Ball doesn't appear:** Layer/Mask mismatch. Ball Layer 1 must be in Wall Mask, Wall Layer 2 must be in Ball Mask.
- **Ball spins:** *Lock Rotation* is not enabled on the RigidBody2D.
:::

:::callout-tip[TIP]
Once you confirm the bounce works,

delete

the

TestBall

node from the Arena scene. Real balls will be spawned programmatically in Chapter 70B. Leaving the test ball in will break spawning logic later.
:::

## Chapter Summary

:::summary
### What You Built

| Component | Setting / File | Purpose |
| --- | --- | --- |
| Viewport | 1080 × 1080, canvas\_items stretch | Square aspect for Shorts |
| Global Gravity | Physics/2D/Default Gravity = 0 | Zero-gravity arena |
| Arena.tscn | res://scenes/arena/Arena.tscn | Root match scene |
| 4× StaticBody2D | Layer 2, 20 px thick, PhysicsMaterial bounce 0.8 | Bouncy walls |
| wall\_physics.tres | Bounce 0.8, Friction 0 | Shared physics resource |
| Camera2D | Position (0,0), Zoom (1,1), Current = on | Fixed full-arena view |
| WorldEnvironment | BG Color #0d1117 | Dark arena backdrop |
| GameManager.gd | Autoload, 4-state enum, 3 signals | Match state machine |
:::

## Practice Problems

**1.** easy — What Godot Project Setting controls the global gravity for all 2D physics objects, and what value do you set it to for this project?

:::solution[Solution]
*Project Settings → Physics → 2D → Default Gravity*, set to `0`. This overrides the default 980 px/s² downward pull for every `RigidBody2D` and `CharacterBody2D` in the project.
:::

**2.** easy — Why is `wall_physics.tres` saved as a *shared resource file* rather than creating four separate inline PhysicsMaterials?

:::solution[Solution]
A shared `.tres` file means all four walls reference the same resource object. Changing *Bounce* from 0.8 to 0.9 in one place instantly updates all walls. Four separate inline resources would require editing each wall individually — a maintenance burden and a bug risk when they fall out of sync.
:::

**3.** standard — A test ball is placed at (0, 0) with `linear_velocity = Vector2(400, 300)` and `linear_damp = 0`. The walls have `bounce = 0.8`. After the ball hits the right wall once, approximately what is its speed (magnitude of velocity)?

:::solution[Solution]
Initial speed: `|v| = √(400² + 300²) = √(160000 + 90000) = √250000 = 500` px/s.

After one bounce (bounce = 0.8, max-combine rule with ball bounce defaulting to 0): `500 × 0.8 = 400` px/s.

The x-component is reflected (400 → -320) and the y-component is unchanged (300 → 300). New velocity ≈ `(-320, 300)`, speed ≈ `√(102400 + 90000) ≈ 438` px/s. (The exact result depends on Godot's combine mode and any contact impulse rounding.)
:::

**4.** standard — The `GameManager` uses `enum State { WAITING, COUNTDOWN, FIGHTING, GAME_OVER }`. Why is it better to use an enum for game states rather than a plain `String` variable like `var state = "fighting"`?

:::solution[Solution]
Three reasons: (1) **Typo safety** — `State.FITHGING` is a compile-time error; `"fithging"` silently produces wrong behaviour. (2) **Autocomplete** — the editor shows all valid states when you type `State.`. (3) **Signal clarity** — `signal state_changed(new_state: State)` documents the allowed values in the type system itself; any subscriber knows to compare against `State.FIGHTING` not a magic string.
:::

**5.** standard — Why is *Lock Rotation* enabled on the test ball's `RigidBody2D` even though the ball is a circle and you wouldn't visually notice rotation?

:::solution[Solution]
Rotational inertia is real even for circles. Without *Lock Rotation*, collision impulses spin the ball and some translational momentum converts into angular momentum — the ball slows faster than expected. Also, the *weapon mount* (`WeaponMount` Node2D) rotates the weapon relative to the ball body. If the ball's physics body also rotates, you'd need to compensate in the weapon rotation code. Locking the physics body rotation means the ball's `transform.rotation` is always 0 and the weapon mount's rotation is purely controlled by the weapon script — much simpler math.
:::

**6.** challenge — The `BallSpawner` node contains two `Marker2D` children at (−270, 0) and (270, 0). Write the GDScript code, callable from `Arena.gd`, that retrieves both spawn positions and could be used to place balls at those locations.

:::solution[Solution]
```gdscript
# In Arena.gd
@onready var spawn_left: Marker2D  = $BallSpawner/SpawnLeft
@onready var spawn_right: Marker2D = $BallSpawner/SpawnRight

func get_spawn_positions() -> Array[Vector2]:
    return [spawn_left.global_position, spawn_right.global_position]

# Usage when spawning:
# var positions = get_spawn_positions()
# ball_instance.global_position = positions[0]  # left spawn
```

Using `global_position` rather than `position` is important — it accounts for any transform on the `BallSpawner` parent node, making the code robust if you ever move `BallSpawner` in the scene tree.
:::

**7.** challenge — Explain why the arena uses four separate thin `StaticBody2D` walls instead of a single `StaticBody2D` with four child `CollisionShape2D` nodes (which Godot does support).

:::solution[Solution]
Both approaches produce correct collision, but four separate bodies is preferred for three reasons: (1) **Individual PhysicsMaterial** — if you later want the top wall to have a different bounce (e.g., a ceiling hazard), you can assign different materials per body. Shapes on one body share one material. (2) **Signals per wall** — you can emit different signals from each wall's `body_entered`, e.g., to trigger a wall-hit sound or screen-edge FX. (3) **Easier visual editing** — moving one wall doesn't accidentally reposition the others. The cost is four nodes vs. one, which is negligible for a static scene with four shapes.
:::
