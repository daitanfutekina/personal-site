---
title: "Crowd Runner — Gates, Obstacles & the Modifier System"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72F"
meta:
  - "Est. study time: ~75 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72f_gates_obstacles.html"
---

## Overview

Build the world content the runner reacts to. Gates change the crowd count via
 arithmetic (+N, −N, ×N, ÷N). Obstacles subtract from the crowd — walls deal a flat hit
 and destroy themselves; saws drain continuously while overlapping. All four scenes
 emit through EventBus signals CrowdManager is already listening for from Ch 72E.

:::callout-key[What you'll build in this chapter]
Gate.tscn (+ Gate.gd) with a GateType enum and colour-coded translucent panel with a
 Label3D operator display. TwoGateRow.tscn — a prefab spawning two gates side-by-side so
 the player picks one. WallObstacle.tscn + SawObstacle.tscn with their scripts. And the
 wiring on Runner's GateSensor / HitSensor Area3Ds so signals flow.
:::

### Prerequisites

- Ch 72E — CrowdManager listening on EventBus.
- Area3D + collision layers understanding (Ch 17, 28).
- Godot enums & @export (Ch 4, 9).

:::callout-connect[Reference checklist]
**Ch 5** (signals), **Ch 17/18** (Area layers/masks —
 concepts transfer directly to 3D), **Ch 28** (Area3D specifics),
 **Ch 25** (MeshInstance3D for gate/obstacle visuals).
:::

## 1. GateType Enum — a Tiny Autoload

GateType values are shared across Gate.gd and CrowdManager. Rather than duplicate the
 enum in both places, put it on the EventBus autoload where both can reference it as
 `EventBus.GateType.ADD`.

1. Open `res://autoloads/EventBus.gd`.
2. Add these lines at the top (after `extends Node`):

```gdscript
# Gate operator kinds. Referenced from Gate.gd and CrowdManager.gd.
enum GateType { ADD, SUB, MUL, DIV }
```

The full EventBus.gd file now looks like:

```gdscript
# res://autoloads/EventBus.gd
extends Node

enum GateType { ADD, SUB, MUL, DIV }

# ── Crowd & combat ───────────────────────────────────────────────────
signal crowd_changed(new_count: int, delta: int)
signal gate_triggered(gate_type: int, value: int)
signal obstacle_hit(damage: int)

# ── Run lifecycle ────────────────────────────────────────────────────
signal run_started
signal run_finalizing
signal run_finished(won: bool, distance_m: int)
```

## 2. Gate Scene

1. *Scene → New Scene*. Root = **Area3D**, rename **Gate**.
 Save as `res://scenes/world/GateBase.tscn`.
2. Select Gate. In the Inspector:

   - *Collision Layer*: check *3 (Gate)*.
   - *Collision Mask*: clear all — Gate advertises, doesn't scan.
   - *Monitorable* = on. *Monitoring* = off (we don't need Gate to detect
    the runner's Area — the runner's Area is doing the detecting).

3. Add child **CollisionShape3D**, name *Trigger*.
 *Shape* → *New BoxShape3D*, *Size* = `(2.0, 3.0, 0.2)` —
 one lane wide (2 m), 3 m tall, thin (0.2 m).
 *Transform → Position → Y* = `1.5`.
4. Add child **MeshInstance3D**, name *Panel*.
 *Mesh* = *New BoxMesh*, *Size* = `(2.0, 3.0, 0.05)`.
 *Transform → Position → Y* = `1.5`.
 *Material Override* → *New StandardMaterial3D*:

   - *Transparency* = `Alpha`.
   - *Albedo → Color* = white with alpha 0.35 (RGBA 255,255,255,90).
   - *Cull Mode* = *Disabled* (so both sides visible).
   - Do *not* save this as a shared .tres — Gate.gd tints it per-instance.

5. Add child **Label3D**, name *OperatorLabel*.
 *Text* = `+0` (placeholder — Gate.gd overwrites).
 *Font Size* = `96`.
 *Pixel Size* = `0.008`.
 *Modulate* = white.
 *Outline Modulate* = black.
 *Outline Size* = `16`.
 *Billboard* = *Enabled* (always face camera).
 *Transform → Position → Y* = `2.6`.

```
Gate (Area3D)                              ← Gate.gd
├── Trigger (CollisionShape3D)             ← BoxShape 2×3×0.2 at Y=1.5
├── Panel (MeshInstance3D)                 ← translucent BoxMesh, tint via script
└── OperatorLabel (Label3D)                ← billboarded "+5" text
```

## 3. Gate.gd

Attach to Gate root. Path `res://scenes/world/Gate.gd`, template Empty,
 inherits Area3D.

```gdscript
# res://scenes/world/Gate.gd
# One-shot gate: on first Runner entry, emits EventBus.gate_triggered(type, value)
# and queue_frees itself. Colour and label update automatically from exports.
class_name Gate
extends Area3D

@export var gate_type : EventBus.GateType = EventBus.GateType.ADD :
    set(v):
        gate_type = v
        _refresh_visuals()
@export var value : int = 5 :
    set(v):
        value = v
        _refresh_visuals()

@onready var panel : MeshInstance3D = $Panel
@onready var label : Label3D = $OperatorLabel

var _triggered : bool = false

func _ready() -> void:
    _refresh_visuals()
    area_entered.connect(_on_area_entered)

func _on_area_entered(area: Area3D) -> void:
    if _triggered:
        return
    # We only care about hits from the Runner's GateSensor (layer 3 mask).
    if area.get_parent() is Runner or area.name == "GateSensor":
        _triggered = true
        EventBus.gate_triggered.emit(int(gate_type), value)
        queue_free()

func _refresh_visuals() -> void:
    if not is_inside_tree():
        return
    label.text = _operator_string()
    var tint := _tint_for_type()
    var mat : StandardMaterial3D = panel.get_active_material(0)
    if mat != null:
        # Duplicate so per-instance tint doesn't leak into other gates.
        mat = mat.duplicate()
        mat.albedo_color = Color(tint.r, tint.g, tint.b, 0.4)
        panel.material_override = mat

func _operator_string() -> String:
    match gate_type:
        EventBus.GateType.ADD: return "+%d" % value
        EventBus.GateType.SUB: return "-%d" % value
        EventBus.GateType.MUL: return "x%d" % value
        EventBus.GateType.DIV: return "/%d" % value
    return "?"

func _tint_for_type() -> Color:
    match gate_type:
        EventBus.GateType.ADD: return Color(0.35, 0.85, 0.45)   # green
        EventBus.GateType.SUB: return Color(0.90, 0.35, 0.35)   # red
        EventBus.GateType.MUL: return Color(0.30, 0.65, 0.95)   # blue
        EventBus.GateType.DIV: return Color(0.90, 0.55, 0.30)   # orange-red
    return Color.WHITE
```

:::callout-intuition[The set: pattern in @export]
Godot 4 lets any `@export` variable have a setter. When you edit
 *gate\_type* or *value* in the Inspector, `_refresh_visuals()`
 runs — you get instant feedback in the editor before you even hit play. This is why
 the Label3D and Panel change colour as you fiddle with the export values.
:::

:::callout-warning[Why area\_entered and not body\_entered]
Runner has two Area3D sensors (GateSensor, HitSensor). Gates listen for the
 *Area* — an Area entering an Area is `area_entered`. A CharacterBody3D
 entering an Area would be `body_entered`. If you connect the wrong one,
 nothing fires and there's no error. Get it right the first time.
:::

:::callout-pitfall[\_triggered guard prevents double-fire]
The runner's GateSensor and the gate's Trigger overlap for a few frames. Without the
 guard, area\_entered would fire once, but if you use `body_entered` and the
 runner physically slides through, some engines fire multiple contacts. The guard is
 cheap insurance. It also gives you a place to attach a visual death-flash before
 queue\_free, later.
:::

## 4. TwoGateRow Prefab

Gates almost always appear in pairs — that's the whole gameplay decision. A
 TwoGateRow scene is just a Node3D with two Gate children, one in the left lane and one in
 the right (or left/centre, or centre/right — three combinations).

1. *Scene → New Scene*. Root = **Node3D**, rename
 **TwoGateRow**. Save as
 `res://scenes/world/TwoGateRow.tscn`.
2. Drag `res://scenes/world/GateBase.tscn` into the scene *twice*. You
 get GateBase and GateBase2 (Godot renames the duplicate).
3. Rename to **GateLeft** and **GateRight**.
4. Set positions:

   - GateLeft: *Transform → Position* = `(-2, 0, 0)`.
   - GateRight: *Transform → Position* = `(2, 0, 0)`.

5. Give them different starting values so the prefab looks meaningful:

   - GateLeft: *gate\_type* = `ADD`, *value* = `10`.
   - GateRight: *gate\_type* = `MUL`, *value* = `2`.

6. Save.

:::callout-tip[The spawner (Ch 72G) randomises values at spawn time]
The prefab's stored values are just defaults — LevelSpawner will do
 `gate_left.gate_type = ADD; gate_left.value = randi_range(3, 8)` before adding
 it to the scene. Having sensible defaults means you can also drop TwoGateRow into
 Main.tscn manually to test gate behaviour without touching the spawner.
:::

### Signal flow — the full chain from touch to visible crowd change

Follow one gate hit from the physics contact all the way to the HUD label bouncing.
 This diagram covers every hop the signal takes:

```
   ┌────────────────────────┐
   │ Runner.GateSensor      │  (Area3D, layer 0, mask "Gate")
   │  overlaps              │
   │ Gate.Trigger           │  (CollisionShape3D inside Gate Area3D)
   └───────────┬────────────┘
               │  (Godot's physics engine fires:)
               ▼
   Gate.area_entered(area = "GateSensor")
               │
               │  Gate.gd sees the name match, calls:
               ▼
   EventBus.gate_triggered.emit(gate_type, value)
               │
               ├──▶ CrowdManager._on_gate_triggered(type, value)
               │        │
               │        ▼   applies ADD / SUB / MUL / DIV
               │    CrowdManager.set_count(new_count)
               │        │
               │        ▼   only if count actually changed
               │    EventBus.crowd_changed.emit(new_count, delta)
               │              │
               │              ├──▶ HUD._on_crowd_changed(count, delta)
               │              │       tween bounce + green/red flash
               │              │
               │              └──▶ (Ch 72H: EnemyWall records final count)
               │
               └──▶ (also, Gate.gd runs queue_free() after emitting)
```

:::callout-connect[Why the two-hop signal chain (gate\_triggered then crowd\_changed)]
Gate doesn't know arithmetic — it just says “I was crossed, here's my type and
 value.” CrowdManager doesn't know about the HUD — it just says “count went
 from X to Y.” HUD doesn't know about Gate. Each node has exactly one job. This is
 the whole reason to use an EventBus autoload: *producer* and *consumer*
 never touch each other, so you can add or remove either without breaking the other.
:::

:::callout-tip[Debugging tip: print at each hop]
If a gate doesn't visibly change the crowd, add
 `print("[gate] emit ", gate_type, value)` in Gate.gd, then
 `print("[crowd] before ", count, " after ", new_count)` in CrowdManager, then
 `print("[hud] crowd_changed ", new_count)` in HUD. Whichever print stops
 appearing is the broken link.
:::

## 5. WallObstacle

1. *Scene → New Scene*. Root = **Area3D**, rename
 **WallObstacle**. Save as
 `res://scenes/world/WallObstacle.tscn`.
2. Collision Layer = *4 (Obstacle)*. Mask = clear. Monitorable = on.
3. Add child **CollisionShape3D**: BoxShape3D `(2, 2, 0.4)`,
 Position Y = `1`.
4. Add child **MeshInstance3D**: BoxMesh `(2, 2, 0.4)`, Position
 Y = `1`. StandardMaterial3D: albedo `#c14a3f` (dull red),
 roughness 0.7.
5. Attach script `res://scenes/world/WallObstacle.gd`:

```gdscript
# res://scenes/world/WallObstacle.gd
class_name WallObstacle
extends Area3D

@export var damage : int = 10

var _triggered : bool = false

func _ready() -> void:
    area_entered.connect(_on_area_entered)

func _on_area_entered(area: Area3D) -> void:
    if _triggered:
        return
    if area.name == "HitSensor":
        _triggered = true
        EventBus.obstacle_hit.emit(damage)
        queue_free()
```

## 6. SawObstacle

1. New Scene, root **Area3D**, rename **SawObstacle**. Save as
 `res://scenes/world/SawObstacle.tscn`.
2. Collision Layer 4, Mask clear, Monitorable on.
3. Add child CollisionShape3D: *CylinderShape3D* radius 1.2, height 0.15.
 Rotation X = `90°`. Position Y = `1.2`.
4. Add child MeshInstance3D: *CylinderMesh* top 1.2, bottom 1.2, height 0.15.
 Rotation X = `90°`. Position Y = `1.2`. StandardMaterial3D:
 albedo `#b0b0b0`, metallic 0.7, roughness 0.25 (shiny disk).
5. Attach script:

```gdscript
# res://scenes/world/SawObstacle.gd
class_name SawObstacle
extends Area3D

@export var dps       : float = 15.0
@export var rot_speed : float = 6.0

@onready var mesh : MeshInstance3D = $MeshInstance3D

var _overlapping_hit_sensor : bool = false
var _drain_accum : float = 0.0

func _ready() -> void:
    area_entered.connect(_on_area_entered)
    area_exited.connect(_on_area_exited)

func _process(dt: float) -> void:
    mesh.rotate(Vector3(0.0, 0.0, 1.0), rot_speed * dt)
    if _overlapping_hit_sensor:
        _drain_accum += dps * dt
        var whole : int = int(_drain_accum)
        if whole >= 1:
            _drain_accum -= float(whole)
            EventBus.obstacle_hit.emit(whole)

func _on_area_entered(area: Area3D) -> void:
    if area.name == "HitSensor":
        _overlapping_hit_sensor = true

func _on_area_exited(area: Area3D) -> void:
    if area.name == "HitSensor":
        _overlapping_hit_sensor = false
        _drain_accum = 0.0
```

:::callout-intuition[Why accumulate the drain]
Damage must be an integer (you can't lose 0.25 of a follower). At 15 dps and 60 fps
 you'd want 0.25 damage per frame. Instead we accumulate a float and emit whenever a whole
 unit crosses. Result: 15 members lost per real second, precisely, regardless of framerate,
 but always in integer chunks.
:::

:::callout-warning[Saw does NOT queue\_free]
Unlike Wall, Saw stays alive until the LevelSpawner cleans it up (behind camera).
 Multiple runners could re-enter a saw (they can't, in this game, but the pattern is
 correct). Wall is one-shot; Saw is persistent-hazard.
:::

## 7. Runner Sensors → EventBus

Gates and obstacles emit EventBus signals directly. But you might notice — the runner's
 sensors themselves don't need scripts! Because gates listen for
 *Area entering Area* via *gate.area\_entered*, and gates are the ones with
 script + signal wiring. The GateSensor / HitSensor Areas are passive detectors from the
 runner's side; the world's Areas do all the routing.

:::callout-tip[Delete the Ch 72E debug keys now]
Open Runner.gd and remove the entire `_unhandled_input` function we added
 in Ch 72E section 7 (the KEY\_1 / KEY\_2 / KEY\_3 block). Gates and obstacles now drive
 crowd count changes.
:::

## 8. Manual Placement Test

Ch 72G will spawn these procedurally. To verify wiring *now*, drop a few by
 hand into Main.tscn.

1. Open Main.tscn.
2. Select **WorldContainer**. Drag
 `res://scenes/world/TwoGateRow.tscn` onto it. Position the row at
 `(0, 0, -25)` — 25 m in front of the runner spawn.
3. Drag `res://scenes/world/WallObstacle.tscn` onto WorldContainer.
 Position `(0, 0, -50)` — a bit further down. Set an @export in the Inspector:
 *damage* = 5.
4. Drag `res://scenes/world/SawObstacle.tscn` onto WorldContainer. Position
 `(-2, 0, -75)` — in the left lane.
5. Save. Run.

## 9. Verification

:::callout-key[Verify]
- Run through the first TwoGateRow, hitting the ADD +10 gate on the left. Watch the
 crowd expand from 1 to 11 (10 new followers in ~2 rings around you).
- Swipe right for the second TwoGateRow, hit MUL ×2 — crowd doubles to 22.
- Hit the wall — 5 followers vanish, the wall itself disappears.
- Enter the saw — you see a stream of print/console signals as the drain fires
 every ~66 ms; count drops steadily by ~1 per 15 members/sec.
- Swipe out of the saw lane — drain stops immediately.
- Output shows no red errors.
:::

:::callout-warning[Gate does nothing on pass-through]
Check three things in order:
 (a) Gate's Collision Layer includes 3 (Gate); (b) Runner's GateSensor Collision Mask
 includes 3; (c) Gate's Monitorable is on. If any is wrong, the physics engine never
 notices the overlap.
:::

:::callout-warning[Gate triggers but crowd doesn't change]
CrowdManager isn't connected. Add a print at the top of `_on_gate_triggered`
 to confirm the signal reaches it. If it doesn't, the connect line in CrowdManager's
 `_ready` is missing or misspelled.
:::

:::callout-warning[Wall damage is huge (crowd instantly zero)]
You set *damage* on the wall to the crowd's current count value or higher. Drop
 it back to 5–10 for testing.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why does Gate use `area_entered` but WallObstacle also use `area_entered`?
 They both listen for the runner. Aren't the signals different?

::::solution[Solution]
Same signal — `Area3D.area_entered(Area3D other)`. The routing difference
 is *which of runner's two sensors* triggered it. Gate filters on
 `area.name == "GateSensor"`; WallObstacle filters on
 `area.name == "HitSensor"`. That name string is our routing key. If Runner
 used only one Area, we'd have to inspect the world node's script type
 (`if area.get_parent() is Gate`) to know how to react.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Design a MUL gate whose value is negative — say, ×−1 — that would flip the crowd
 to negative. What breaks and how do you defend against it?

::::solution[Solution]
CrowdManager.set\_count clamps to [0, max\_crowd] so a negative would land at 0 and
 trigger game over. Not a bug, but unintended. Defend by: (a) restricting spawner to
 produce only positive gate values, and (b) in Gate.\_refresh\_visuals, assert
 `value > 0` so nobody sets a bad value in the Inspector.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
The SawObstacle drain is per-second. If the game framerate drops to 20 fps, is the
 drain still 15/sec? Show why or why not.

::::solution[Solution]
Yes. `_drain_accum += dps * dt` — `dt` is real elapsed time
 per frame. At 20 fps, dt = 0.05 s, so each frame adds `15 × 0.05 = 0.75`.
 Over 20 frames = 1 second, `20 × 0.75 = 15` total drain. Only the granularity
 of when integer damage is emitted changes (every ~0.067 s at 60 fps, every 0.13 s at
 20 fps).
::::
:::

:::problem[Problem 4 challenge]{difficulty="challenge"}
You want a MUL gate to only be worth doubling — but the crowd already has 200 members
 and the MultiMesh caps at 250. Doubling would “waste” 150. Fix the
 `MUL` path so any excess members trigger a bonus effect instead of being
 silently clamped.

::::solution[Solution]
In CrowdManager.\_on\_gate\_triggered's MUL case, compute the raw new\_count first, then
 `var overflow = new_count - max_crowd`. If overflow > 0, cap the count at
 max\_crowd and emit a new EventBus signal like `crowd_overflowed(overflow)`.
 The HUD or GameManager can listen and score bonus points equal to overflow, or trigger
 a “maxed out” particle burst. This is a design pattern: instead of throwing
 info away, emit it and let listeners decide what to do.
::::
:::

:::summary
## Summary

The four world content scenes are done. Gate (with GateType enum, colour-coded panel,
 billboard operator label, one-shot fire), TwoGateRow (the paired-choice prefab),
 WallObstacle (one-shot damage), SawObstacle (continuous drain). All emit through
 EventBus, which CrowdManager was already listening to from Ch 72E. The runner sensors
 needed no scripts — the world Areas do all the routing via name checks.

**Next:**
 [Ch 72G](./godot_ch72g_spawner_hud.html) replaces the hand-placed test row
 with the procedural LevelSpawner, builds the portrait HUD (juicy crowd count + distance),
 and wires up the main / pause / game-over menus.
:::
