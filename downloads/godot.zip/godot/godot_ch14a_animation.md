---
title: "Animation — AnimationPlayer, Tween & AnimationTree"
source: "markdown"
---

Part III · Chapter 14A

# Animation — AnimationPlayer, Tween & AnimationTree

Estimated reading time: 90 min · Prerequisites: Ch 4 (GDScript), Ch 11 (OOP)

## Overview

Animation is what makes a game feel alive. A character that teleports between
 states feels robotic; one that slides, stretches, and eases feels physical
 and satisfying. Godot provides three complementary animation systems, each
 suited to different problems:

- **AnimationPlayer** — timeline-based keyframe animation for anything: position, scale, material properties, method calls. The workhorse for cutscenes, UI transitions, and complex character animations authored in the editor.
- **AnimatedSprite2D** — frame-by-frame sprite sheet animation, the simplest path from a sprite sheet to a walking character.
- **Tween** — code-driven procedural animation. Interpolate any property from A to B with a chosen easing curve. No editor required.
- **AnimationTree** — a state machine and blend-tree layer that sits on top of AnimationPlayer, managing transitions between animations (idle → run → jump) with blending and conditions.

By the end of this chapter you will be able to:

- Create and play AnimationPlayer animations that drive any node property
- Use the Call Method track to fire GDScript functions at exact animation timestamps
- Set up AnimatedSprite2D with a SpriteFrames resource and switch animations in code
- Build Tween sequences for procedural UI and gameplay animation
- Wire an AnimationTree state machine to control character animation states
- Connect animation signals to synchronise gameplay with animation events

⬡ — AnimationPlayer — inherits AnimationMixer → Node

Records and plays back animations as sequences of keyframed property changes. Any property on any node in the scene — position, rotation, scale, colour, shader parameters, visibility, script variables — can be animated. One AnimationPlayer can hold dozens of named animations, play them back by name, blend between them via crossfades, and fire function calls at specific timestamps via Call Method tracks.

| Property | Default | What it does |
| --- | --- | --- |
| root\_node | ".." | The node that defines the root of animation track paths. Tracks are recorded relative to this node — keep it as the parent unless you need cross-scene animations |
| current\_animation | "" | Name of the animation currently assigned (not necessarily playing) — set to "" to clear |
| autoplay | "" | Animation to start automatically when the scene loads — common for idle loops |
| speed\_scale | 1.0 | Global playback speed multiplier — 0 = paused, negative = reverse |
| playback\_default\_blend\_time | 0.0 s | Default crossfade duration when switching animations — overridden per-pair by blend\_times |
| reset\_on\_save | true | Returns all animated properties to the RESET animation pose when saving the scene — keeps the editor clean |
| callback\_mode\_process | IDLE | Whether Call Method track callbacks fire in \_physics\_process (PHYSICS) or \_process (IDLE) |

Use when:

any node property needs to change over time without writing per-frame code — character animations, door swings, UI transitions, cutscene sequences, camera movement.

Prefer AnimatedSprite2D when:

you only need frame-swapping on a sprite sheet and don't need to animate other properties — it's lighter and simpler.

Prefer Tween when:

you need a one-off procedural transition computed at runtime (e.g., "smoothly move to wherever the enemy currently is"), not a designer-authored keyframed sequence.

## 1 · AnimationPlayer

**AnimationPlayer** stores a library of named animations. Each
 animation is a timeline of *tracks* — one track per property being
 animated. A track holds *keyframes*: (time, value) pairs that the
 player interpolates between during playback.

### Tracks and keyframes

Select the AnimationPlayer node and open the **Animation** panel
 at the bottom of the editor. Click **Animation → New** to create
 an animation and give it a name (e.g. "idle", "door\_open", "hurt"). Then:

1. Select a node in the scene tree whose property you want to animate.
2. In the Inspector, right-click the property name → **Add to Animation**, or click the key icon next to the property.
3. Godot adds a track for that property and inserts a keyframe at the current timeline position.
4. Move the timeline cursor to a later time, change the property value, then insert another keyframe.
5. AnimationPlayer interpolates between keyframes during playback.

| Track type | What it animates |
| --- | --- |
| Property track | Any exported or built-in node property: position, rotation, scale, modulate, visible, material parameters |
| Call Method track | Calls a GDScript method at a specific timestamp — perfect for sound triggers, particle bursts, gameplay events |
| Bezier track | Like property track but uses bezier curves for fine-tuned easing between keyframes |
| Audio track | Triggers an AudioStreamPlayer at a timestamp with a specific stream |
| Animation track | Plays a sub-animation from another AnimationPlayer at a timestamp (animation composition) |

Track type

Typical keyframe data

Use for

Property

position, scale, modulate…

Animating any exported property

Call Method

method name + args at time T

Spawn effects, emit signals

Bezier

property value with curve handles

Precise easing on floats / vectors

Audio

AudioStream at timestamp

Footsteps, voices, SFX cues

Animation

sub-animation name at timestamp

Composing cutscenes from clips

The five AnimationPlayer track types. Property tracks do most of the work; Call Method tracks are how you fire signals or run GDScript functions at precise animation timestamps.

### Playback API

```gdscript
@onready var anim: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    # Play an animation from the start:
    anim.play("idle")

    # Play backwards:
    anim.play_backwards("door_open")

    # Queue an animation to play after the current one finishes:
    anim.play("walk")
    anim.queue("idle")

    # Stop immediately (keep position):
    anim.stop(false)   # false = keep current position
    # Stop and rewind to start:
    anim.stop(true)

func _on_hit() -> void:
    # Interrupt current animation and play "hurt":
    anim.play("hurt")

# Check state:
if anim.is_playing():
    print("Currently playing: ", anim.current_animation)

# Control playback speed:
anim.speed_scale = 2.0   # double speed
anim.speed_scale = 0.5   # half speed (slow motion)
anim.speed_scale = -1.0  # play backwards

# Jump to a specific time in the animation:
anim.seek(0.5)   # jump to 0.5 seconds
```

:::callout-tip[RESET animation — the default pose]
Godot looks for an animation named exactly **"RESET"** when
 the AnimationPlayer is instantiated. If it exists, it is played automatically
 in the editor to set the node to its default state. Create a RESET animation
 with one keyframe at t=0 for every property your other animations modify.
 This prevents stale property values when switching animations in the editor.
:::

### Call Method track

The Call Method track fires a GDScript function at an exact timestamp in the
 animation. This is the cleanest way to synchronise gameplay events with
 animation frames — a footstep sound on frame 4, a particle burst on frame 12,
 enabling a hitbox for exactly the frames of an attack swing.

In the **Animation** panel at the bottom of the editor:

1. Open the animation you want to fire from (e.g. "attack").
2. Click **Add Track** → **Call Method Track**.
3. Pick the node whose method will be called — usually the Character node that owns the script below.
4. Move the timeline cursor to the moment you want, then right-click the track at that position and insert a key from the context menu.
5. The keyframe dialog asks for the method name and any arguments.

The methods the track names must exist on that node, or the call fails silently
at runtime with nothing in the Output panel to say why:

```gdscript
func _on_attack_swing_start() -> void:
    $HitboxArea.monitoring = true
    AudioManager.play_sfx("sword_swing")

func _on_attack_swing_end() -> void:
    $HitboxArea.monitoring = false

func _on_attack_footstep() -> void:
    AudioManager.play_sfx_pitched("footstep")
```

:::example[Door animation with callback]
A door animates open over 0.6 s. At t=0.3 s (halfway), play a creak sound.
          At t=0.6 s (fully open), enable the trigger area beyond the door.

::::answer[AnimationPlayer setup + GDScript]
```gdscript
# door.gd
extends Node2D

@onready var anim: AnimationPlayer = $AnimationPlayer
@onready var trigger: Area2D       = $TriggerArea

var _is_open := false

func open() -> void:
    if _is_open:
        return
    _is_open = true
    anim.play("open")   # timeline: position track (0→open), two call method keys

# Called by Call Method track at t=0.3:
func on_creak() -> void:
    AudioManager.play_sfx("door_creak")

# Called by Call Method track at t=0.6:
func on_fully_open() -> void:
    trigger.monitoring = true
```
::::
:::

## 2 · Sprite Animation

⬡ — AnimatedSprite2D — inherits Node2D

Displays a 2D sprite that cycles through frames stored in a `SpriteFrames` resource. Unlike AnimationPlayer (which can animate any property), AnimatedSprite2D is purpose-built for frame-by-frame sprite animation — simpler to set up for pixel art characters, each animation defined as a named sequence of frames with its own FPS and loop settings.

| Property | Default | What it does |
| --- | --- | --- |
| sprite\_frames | null | **Required.** A SpriteFrames resource containing named animation sequences and their frames. Create one in the Inspector and open its editor panel to import frames |
| animation | "default" | Name of the currently active animation — must match a name in sprite\_frames |
| autoplay | "" | Animation to start playing automatically on \_ready(). Leave blank to control from script |
| frame | 0 | Current frame index within the active animation — read or set to jump to a specific frame |
| speed\_scale | 1.0 | Multiplier on the animation's own FPS — 0.5 = half speed, 2.0 = double speed, negative = play backwards |
| centered | true | Positions the sprite so the origin is at its visual centre — turn off for pixel-perfect tile alignment |
| flip\_h / flip\_v | false | Mirror the sprite horizontally or vertically — flip\_h to face left without a separate "left" animation set |
| offset | Vector2(0,0) | Pixel offset from the node origin — useful when the sprite art isn't perfectly centred |

Use when:

you have a sprite sheet character and need clean per-frame animation control — walk, idle, attack, death cycles.

Prefer AnimationPlayer when:

you also need to animate other properties alongside the sprite (position, modulate, sounds via Call Method tracks).

Key signal:

animation\_finished

— connect it to detect when a one-shot animation (like a death sequence) completes.

### AnimatedSprite2D

**AnimatedSprite2D** plays frame-by-frame sprite animations
 from a **SpriteFrames** resource. It's the fastest path from
 a sprite sheet to an animated character — no AnimationPlayer tracks needed.

Add an AnimatedSprite2D to your scene. In the Inspector, create a new
 SpriteFrames resource. The SpriteFrames editor opens at the bottom —
 create animation entries ("idle", "run", "jump", "fall", "attack") and
 drag frames from the FileSystem dock into each animation's frame list.
 Set the FPS per animation.

```gdscript
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _physics_process(delta: float) -> void:
    var on_floor := is_on_floor()
    var vel_x    := velocity.x
    var vel_y    := velocity.y

    # Pick the right animation based on state:
    var anim_name: StringName
    if not on_floor:
        anim_name = "fall" if vel_y > 0 else "jump"
    elif absf(vel_x) > 10.0:
        anim_name = "run"
    else:
        anim_name = "idle"

    if sprite.animation != anim_name:
        sprite.play(anim_name)

    # Flip horizontally when moving left:
    if vel_x != 0.0:
        sprite.flip_h = vel_x < 0.0
```

### SpriteFrames in code

You can build a SpriteFrames resource entirely in code — useful for
 procedurally loading animations from a folder, or for testing without
 an editor session:

```gdscript
func build_spriteframes() -> SpriteFrames:
    var sf := SpriteFrames.new()

    # Create the "idle" animation:
    sf.add_animation("idle")
    sf.set_animation_speed("idle", 8.0)   # 8 FPS
    sf.set_animation_loop("idle", true)

    # Add frames from individual files:
    for i in range(1, 5):   # idle_1.png through idle_4.png
        var tex := load("res://sprites/player/idle_%d.png" % i) as Texture2D
        sf.add_frame("idle", tex)

    # Or slice frames from an atlas:
    var atlas := load("res://sprites/player_sheet.png") as Texture2D
    sf.add_animation("run")
    sf.set_animation_speed("run", 12.0)
    sf.set_animation_loop("run", true)
    for col in 6:   # 6 run frames in row 1 of the atlas
        var frame_tex := AtlasTexture.new()
        frame_tex.atlas  = atlas
        frame_tex.region = Rect2(col * 32, 32, 32, 32)   # 32×32 px tiles
        sf.add_frame("run", frame_tex)

    return sf
```

## 3 · Tween

A **Tween** is a fire-and-forget animator you create in code — no nodes in the scene tree, no editor tracks.
 Call `create_tween()` on any node and chain property interpolations, callbacks, and waits.
 Tweens are ideal for one-shot UI transitions, juice effects (squash-and-stretch, screen shake), and anything
 that would clutter an AnimationPlayer timeline.

### 3.1 · create\_tween() basics

```gdscript

# Basic property tween — move a sprite to (400, 300) over 0.5 s
func _ready() -> void:
    var tween := create_tween()
    tween.tween_property(self, "position", Vector2(400, 300), 0.5)
```

`tween_property(object, property_path, final_value, duration)` — the four arguments you always supply.
 The *property path* is a `NodePath` string; dot-notation lets you target sub-properties:

```gdscript

tween.tween_property($Sprite2D, "modulate:a", 0.0, 0.3)   # fade alpha only
tween.tween_property($Sprite2D, "scale",      Vector2(1.2, 1.2), 0.1)
```

### 3.2 · Tweener types

| Method | What it does |
| --- | --- |
| `tween_property(obj, path, to, dur)` | Interpolate an exported/readable property from its current value to `to` |
| `tween_interval(seconds)` | Insert a pause — execution waits but the Tween keeps running |
| `tween_callback(callable)` | Call a function at that point in the sequence |
| `tween_method(callable, from, to, dur)` | Call a function each frame with an interpolated value (useful for custom shader params) |

### 3.3 · Easing — Trans and Ease

Every `PropertyTweener` has a fluent `.set_trans()` / `.set_ease()` pair.
 `Tween.TRANS_*` controls the curve *shape*; `Tween.EASE_*` controls which
 *end* of the curve is accelerated.

```gdscript

tween.tween_property(self, "position", target_pos, 0.4)\
     .set_trans(Tween.TRANS_BACK)\
     .set_ease(Tween.EASE_OUT)
```

| TRANS constant | Feel | EASE constant | Acceleration side |
| --- | --- | --- | --- |
| `TRANS_LINEAR` | Constant speed | `EASE_IN` | Slow start → fast end |
| `TRANS_SINE` | Smooth, natural | `EASE_OUT` | Fast start → slow end |
| `TRANS_QUAD / CUBIC` | Gentle / moderate curve | `EASE_IN_OUT` | Slow at both ends |
| `TRANS_BACK` | Overshoot then settle | `EASE_OUT_IN` | Fast at both ends |
| `TRANS_BOUNCE` | Rubber-ball bounce | — | — |
| `TRANS_ELASTIC` | Spring wiggle | — | — |
| `TRANS_EXPO` | Dramatic ease | — | — |
| `TRANS_CIRC` | Circular arc | — | — |
| `TRANS_SPRING` | Physics spring | — | — |

### 3.4 · Sequences vs Parallel tweens

By default each tweener starts *after* the previous one finishes — that is a **sequence**.
 Call `set_parallel(true)` to run all tweeners at the same time instead:

```gdscript

# Sequential (default) — scale up, then fade out
func popup_then_fade(node: Control) -> void:
    var tw := create_tween()
    tw.tween_property(node, "scale", Vector2(1.1, 1.1), 0.1).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(node, "scale", Vector2.ONE,       0.1).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
    tw.tween_interval(0.5)
    tw.tween_property(node, "modulate:a", 0.0, 0.3)
    tw.tween_callback(node.queue_free)

# Parallel — move AND fade at the same time
func slide_out(node: Control) -> void:
    var tw := create_tween().set_parallel(true)
    tw.tween_property(node, "position:x",  -200.0, 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tw.tween_property(node, "modulate:a",    0.0,  0.4).set_trans(Tween.TRANS_LINEAR)
```

:::callout-tip
💡 Mix sequences and parallel groups

Switch back and forth with

.set\_parallel(false)

mid-chain to create a sequence where
        individual steps themselves run in parallel — e.g. slide + fade together, then a callback.
:::

### 3.5 · Tween looping & awaiting

```gdscript

# Loop a breathing glow effect forever
func start_glow_loop(node: CanvasItem) -> void:
    var tw := create_tween().set_loops()   # infinite loops
    tw.tween_property(node, "modulate:a", 0.4, 0.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_property(node, "modulate:a", 1.0, 0.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

# await a one-shot tween — coroutine-friendly
func animate_and_continue() -> void:
    var tw := create_tween()
    tw.tween_property(self, "position", Vector2(500, 300), 0.5)
    await tw.finished          # resumes after the tween completes
    print("Tween done — continuing logic here")
```

### 3.6 · Practical example — screen-shake

```gdscript

# Attach to the Camera2D node
extends Camera2D

func shake(duration: float = 0.3, strength: float = 6.0) -> void:
    var tw := create_tween()
    tw.set_loops(int(duration / 0.05))   # kick at ~20 Hz
    tw.tween_method(_apply_shake.bind(strength), 0.0, 1.0, 0.05)

func _apply_shake(strength: float, _t: float) -> void:
    offset = Vector2(
        randf_range(-strength, strength),
        randf_range(-strength, strength)
    )

# Call from anywhere via autoload:
# Camera.shake(0.4, 8.0)
```

⬡ — AnimationTree — inherits AnimationMixer → Node

A graph-based state machine that blends multiple animations from an `AnimationPlayer`. Instead of playing one animation at a time, AnimationTree lets you crossfade between states, blend walk and run by a float parameter, layer upper-body attacks over lower-body movement, and build complex character controllers — all without a single `play()` call in script.

| Property | Default | What it does |
| --- | --- | --- |
| tree\_root | null | **Required.** An AnimationNode that is the entry point — usually AnimationNodeStateMachine, AnimationNodeBlendTree, or AnimationNodeBlendSpace2D |
| anim\_player | null | Path to the AnimationPlayer that owns the source animations this tree pulls from |
| active | true | Whether the tree is processing. A new AnimationTree already has this `true`; set it `false` to pause the tree and back to `true` to resume |
| callback\_mode\_process | IDLE | PHYSICS: sync with \_physics\_process (recommended for character movement). IDLE: sync with \_process (for UI or cutscenes) |
| root\_motion\_track | "" | NodePath to the bone track that provides root motion — the tree extracts its transform so you can apply it to a CharacterBody2D |

Use when:

a character needs blended locomotion (walk/run/sprint by speed), multiple animation layers (move + shoot), or a proper state machine with transitions and conditions.

Prefer AnimationPlayer alone when:

you just need to play one animation at a time — menus, cutscenes, simple prop animations. AnimationTree adds complexity only worth it for characters with blended movement.

Setup order:

(1) build all animations in AnimationPlayer, (2) add AnimationTree sibling node, (3) set anim\_player path, (4) set tree\_root to a new AnimationNodeStateMachine, (5) set active = true.

## 4 · AnimationTree

AnimationPlayer plays one track at a time. **AnimationTree** sits on top of it and blends, mixes,
 and transitions between animations using a visual graph of *blend nodes*.
 It's indispensable for characters that need to blend walk-to-run or upper/lower body separation.

### 4.1 · Setting up AnimationTree

Add an **AnimationTree** node as a sibling (or child) of your AnimationPlayer.
 Set its `tree_root` property to one of the blend-node resources and point
 `anim_player` at your AnimationPlayer. Finally, tick **active = true**.

| Tree root type | Purpose |
| --- | --- |
| `AnimationNodeStateMachine` | Discrete states with transition conditions — best for characters |
| `AnimationNodeBlendTree` | Free-form graph of blend nodes — best for blending & layering |
| `AnimationNodeBlendSpace1D / 2D` | 1-D or 2-D blend space driven by a float parameter (speed, direction) |
| `AnimationNodeAnimation` | Leaf node — plays a single named animation |

### 4.2 · AnimationNodeStateMachine

The state machine is the go-to for player characters. Each state is an `AnimationNodeAnimation`;
 you draw transitions between them in the editor and control them with *string parameters* via the
 `AnimationTree` API.

```gdscript

extends CharacterBody2D

@onready var anim_tree: AnimationTree = $AnimationTree
@onready var state_machine: AnimationNodeStateMachinePlayback = \
    anim_tree["parameters/playback"]

func _ready() -> void:
    anim_tree.active = true

func _physics_process(delta: float) -> void:
    # --- movement logic ---
    var on_floor := is_on_floor()
    var moving   := abs(velocity.x) > 10.0

    # Drive the state machine
    if not on_floor:
        state_machine.travel("jump")
    elif moving:
        state_machine.travel("run")
    else:
        state_machine.travel("idle")
```

`state_machine.travel("state_name")` finds the shortest transition path through the graph
 to the requested state, respecting any transition conditions you configured in the editor.
 Use `state_machine.start("state_name")` to jump immediately without a transition.

### 4.3 · Blend parameters

Every blend node exposes float (or Vector2) *parameters* you can set at runtime:

```gdscript

# AnimationNodeBlend2 blends between two animations by a 0-1 weight
# e.g. blend between idle and walk based on horizontal speed
func _physics_process(delta: float) -> void:
    var speed_norm := clampf(abs(velocity.x) / MAX_SPEED, 0.0, 1.0)
    anim_tree["parameters/blend_position"] = speed_norm

# AnimationNodeBlendSpace2D — 2D locomotion (8-directional movement)
func _physics_process(delta: float) -> void:
    var dir := velocity.normalized()
    anim_tree["parameters/locomotion/blend_position"] = dir
```

:::callout-tip
💡 Parameter path convention

The path is always

"parameters/<node\_name>/<parameter>"

.
        Hover over any blend node in the AnimationTree editor to see its exact path in the inspector hint.
:::

### 4.4 · Root motion

When your animation moves the skeleton's root bone, enable **Root Motion Track** in the
 AnimationTree inspector and read `get_root_motion_position()` each frame to drive physics
 movement instead of fighting the animation:

```gdscript

func _physics_process(delta: float) -> void:
    # Let the animation drive horizontal movement
    var root_motion := anim_tree.get_root_motion_position()
    velocity.x = (root_motion.x / delta)
    move_and_slide()
```

## 5 · Animation Signals

Both AnimationPlayer and AnimatedSprite2D emit signals you can use to synchronise game logic —
 spawning a hitbox exactly when the sword swings, triggering a footstep sound on the right frame,
 or changing state when a death animation ends.

### 5.1 · AnimationPlayer signals

| Signal | Args | When emitted |
| --- | --- | --- |
| `animation_started(anim_name)` | `StringName` | Playback begins (including via queue) |
| `animation_finished(anim_name)` | `StringName` | Non-looping animation reaches its end |
| `animation_changed(old, new)` | two `StringName`s | Active animation switches |
| `current_animation_changed(name)` | `String` | Any time the current animation property changes |

```gdscript

extends CharacterBody2D

@onready var anim_player: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    anim_player.animation_finished.connect(_on_anim_finished)
    anim_player.play("idle")

func die() -> void:
    anim_player.play("death")

func _on_anim_finished(anim_name: StringName) -> void:
    match anim_name:
        "death":
            queue_free()   # remove after death animation completes
        "attack":
            anim_player.play("idle")
```

### 5.2 · AnimatedSprite2D signals

| Signal | When emitted |
| --- | --- |
| `animation_finished` | Non-looping animation reaches its last frame |
| `animation_looped` | Looping animation wraps back to frame 0 |
| `animation_changed` | Active animation name changes |
| `frame_changed` | The displayed frame index changes (every frame update) |

```gdscript

extends CharacterBody2D

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    sprite.animation_finished.connect(_on_sprite_finished)
    sprite.frame_changed.connect(_on_frame_changed)

func _on_sprite_finished() -> void:
    if sprite.animation == "death":
        queue_free()

# Footstep sound on specific frames of the walk cycle
func _on_frame_changed() -> void:
    if sprite.animation == "walk" and sprite.frame in [2, 6]:
        $FootstepPlayer.play()
```

### 5.3 · Call Method tracks

AnimationPlayer has a built-in mechanism for calling functions at exact timestamps:
 the **Call Method track**. Add one in the editor, pick the target node, and set the
 method name and optional arguments. This is ideal for per-animation events (footstep SFX, particle bursts,
 hitbox enable/disable) because the timing lives inside the animation asset, not scattered around scripts.

```gdscript

# The method just needs to exist on the target node —
# AnimationPlayer calls it automatically at the keyed time.
func enable_hitbox() -> void:
    $HitboxArea2D/CollisionShape2D.disabled = false

func disable_hitbox() -> void:
    $HitboxArea2D/CollisionShape2D.disabled = true
```

:::callout-warning
⚠️ frame\_changed performance

frame\_changed

fires every frame while the sprite animates.  Keep its handler lightweight —
        a single

if

check is fine; avoid physics queries or heavy allocations inside it.
:::

## Summary

| System | Best for | Key API |
| --- | --- | --- |
| **AnimationPlayer** | Multi-track, reusable, editor-authored animations | `play()`, `queue()`, `seek()`, `animation_finished` |
| **AnimatedSprite2D** | Sprite-sheet frame animations, simple state machine | `play()`, `stop()`, `SpriteFrames` |
| **Tween** | Fire-and-forget property interpolation, UI juice, one-shots | `create_tween()`, `tween_property()`, `set_trans()`, `set_ease()` |
| **AnimationTree** | Blended character locomotion, state machines, root motion | `state_machine.travel()`, `anim_tree["parameters/…"]` |

- Always create a **RESET animation** in AnimationPlayer to define the default pose.
- Prefer **Call Method tracks** over signal handlers for per-animation events — the timing stays in one place.
- Use **Tween** for anything you'd otherwise do with a timer + lerp in `_process()`.
- AnimationTree's `travel()` respects editor-defined transition conditions; use `start()` to jump immediately.
- Connect `animation_finished` (not `_process` polling) to react when a one-shot animation ends.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Looping idle animation

Create a scene with an `AnimatedSprite2D`. In `_ready()` play an animation
 called `"idle"`. Connect `animation_finished` so that if the animation is
 *not* set to loop, it restarts automatically anyway.

::::solution[Solution]
```gdscript

extends Node2D

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    sprite.animation_finished.connect(_on_finished)
    sprite.play("idle")

func _on_finished() -> void:
    if sprite.animation == "idle":
        sprite.play("idle")
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Fade-in UI panel

Write a function `fade_in(panel: Control)` that tweens the panel's `modulate.a`
 from 0 to 1 over 0.4 seconds using a `TRANS_SINE / EASE_OUT` curve.

::::solution[Solution]
```gdscript

func fade_in(panel: Control) -> void:
    panel.modulate.a = 0.0
    var tw := create_tween()
    tw.tween_property(panel, "modulate:a", 1.0, 0.4)\
      .set_trans(Tween.TRANS_SINE)\
      .set_ease(Tween.EASE_OUT)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Door open / close with AnimationPlayer

A `Door` node has an AnimationPlayer with `"open"` and `"close"`
 animations. Write a script that tracks whether the door is open, toggles the correct animation on
 an `interact()` call, and prevents interacting while the animation is playing.

::::solution[Solution]
```gdscript

extends Node2D

@onready var anim: AnimationPlayer = $AnimationPlayer

var _is_open   := false
var _animating := false

func _ready() -> void:
    anim.animation_finished.connect(_on_anim_finished)

func interact() -> void:
    if _animating:
        return
    _animating = true
    if _is_open:
        anim.play("close")
    else:
        anim.play("open")

func _on_anim_finished(_name: StringName) -> void:
    _is_open   = not _is_open
    _animating = false
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Bounce-and-settle collectible

When a coin is spawned, play a tween sequence: scale to `(1.3, 1.3)` over 0.1 s
 (`TRANS_BACK / EASE_OUT`), then back to `(1.0, 1.0)` over 0.15 s
 (`TRANS_BOUNCE / EASE_OUT`). After the sequence completes, start an infinite
 gentle bobbing tween that moves the coin `±6 px` on the Y axis.

::::solution[Solution]
```gdscript

extends Area2D

func _ready() -> void:
    var tw := create_tween()
    tw.tween_property(self, "scale", Vector2(1.3, 1.3), 0.1)\
      .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(self, "scale", Vector2.ONE, 0.15)\
      .set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
    await tw.finished
    _start_bob()

func _start_bob() -> void:
    var origin_y := position.y
    var bob := create_tween().set_loops()
    bob.tween_property(self, "position:y", origin_y - 6.0, 0.6)\
       .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    bob.tween_property(self, "position:y", origin_y + 6.0, 0.6)\
       .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · AnimationTree character controller

Build a top-down character that uses an `AnimationNodeStateMachine` with three states:
 `"idle"`, `"walk"`, and `"roll"`. The character walks while
 any arrow key is held, rolls when Space is pressed (playing the full animation before
 returning to idle/walk), and is locked from rolling again until the roll finishes.

::::solution[Solution]
```gdscript

extends CharacterBody2D

const SPEED  := 120.0
const ROLL_V := 220.0

@onready var anim_tree  : AnimationTree  = $AnimationTree
@onready var anim_player: AnimationPlayer = $AnimationPlayer

@onready var state_machine: AnimationNodeStateMachinePlayback = \
    anim_tree["parameters/playback"]

var _rolling := false

func _ready() -> void:
    anim_tree.active = true
    anim_player.animation_finished.connect(_on_anim_finished)

func _physics_process(delta: float) -> void:
    if _rolling:
        move_and_slide()
        return

    var dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")

    if Input.is_action_just_pressed("ui_accept") and dir != Vector2.ZERO:
        _rolling   = true
        velocity   = dir * ROLL_V
        state_machine.travel("roll")
        return

    velocity = dir * SPEED
    if dir != Vector2.ZERO:
        state_machine.travel("walk")
    else:
        state_machine.travel("idle")
    move_and_slide()

func _on_anim_finished(anim_name: StringName) -> void:
    if anim_name == "roll":
        _rolling = false
        velocity  = Vector2.ZERO
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Combo attack system

Create a melee character with a 3-hit combo (`"attack_1"`, `"attack_2"`,
 `"attack_3"`). Pressing attack during the *combo window* (last 30% of
 each animation) queues the next hit. Missing the window resets to idle. Use Call Method tracks
 to enable/disable a hitbox `CollisionShape2D` on frames where damage should register.
 Print which combo step fires for each hit.

::::solution[Solution]
```gdscript

extends CharacterBody2D

@onready var anim: AnimationPlayer     = $AnimationPlayer
@onready var hitbox: CollisionShape2D  = $HitboxArea2D/CollisionShape2D

var _combo_step   := 0         # 0 = idle, 1–3 = mid-combo
var _combo_queued := false     # player hit attack during window
var _in_window    := false     # currently inside the combo window

func _ready() -> void:
    anim.animation_finished.connect(_on_anim_finished)
    hitbox.disabled = true

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("attack"):
        if _combo_step == 0:
            _start_attack(1)
        elif _in_window:
            _combo_queued = true

# Called by AnimationPlayer Call Method track at 70% of each anim
func open_combo_window() -> void:
    _in_window = true

# AnimationPlayer will call these via Call Method track:
func enable_hitbox()  -> void: hitbox.disabled = false
func disable_hitbox() -> void: hitbox.disabled = true

func _start_attack(step: int) -> void:
    _combo_step   = step
    _combo_queued = false
    _in_window    = false
    print("Combo hit %d" % step)
    anim.play("attack_%d" % step)

func _on_anim_finished(anim_name: StringName) -> void:
    if not anim_name.begins_with("attack"):
        return
    hitbox.disabled = true
    if _combo_queued and _combo_step < 3:
        _start_attack(_combo_step + 1)
    else:
        _combo_step = 0
        anim.play("idle")
```
::::
:::
