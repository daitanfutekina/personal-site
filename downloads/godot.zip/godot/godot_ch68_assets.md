---
title: "Chapter 68 — Asset Sourcing & Import"
source: "godot_ch68_assets.html"
---

Part XII: Advanced Topics · Estimated study time: 80 min

## Chapter Overview

Every game needs art, sound, and music — but very few developers can create all of it themselves. Knowing where to find quality free assets, how to license them correctly, and how to import them into Godot without breaking their quality is a core production skill. Poor import settings are one of the most common sources of blurry sprites, crackling audio, and missing animations in student projects.

This chapter covers the complete pipeline: understanding license types so you don't accidentally violate copyright, finding reliable sources for every asset category, and mastering Godot 4's import system so your assets look and sound exactly as intended.

:::callout-tip[Prerequisites]
Sprites and AnimatedSprite2D (Ch 2, Ch 3), Audio (Ch 15), basic familiarity with the Godot FileSystem dock.
:::

## 1 · Understanding Asset Licenses

Before you use any free asset in a game, you need to understand what the license allows. Using an asset incorrectly — even a free one — can result in DMCA takedowns, rejection from storefronts like Steam or itch.io, and legal liability. This sounds scary but it becomes easy once you understand a handful of license types.

The fundamental distinction is between **public domain**, **open licenses**, and **restricted licenses**. Most game-dev-friendly assets fall under Creative Commons variants or have their own custom permissive licenses.

### License Types at a Glance

| License | Use in game? | Modify? | Commercial? | Attribute? |
| --- | --- | --- | --- | --- |
| **CC0 / Public Domain** | ✓ Yes | ✓ Yes | ✓ Yes | Not required (good practice) |
| **CC BY 4.0** | ✓ Yes | ✓ Yes | ✓ Yes | ✓ Required |
| **CC BY-SA 4.0** | ✓ Yes | ✓ Yes (keep license) | ✓ Yes | ✓ Required |
| **CC BY-NC 4.0** | Free games only | ✓ Yes | ✗ No | ✓ Required |
| **CC BY-ND 4.0** | Unmodified only | ✗ No | ✓ Yes | ✓ Required |
| **Kenney License** | ✓ Yes | ✓ Yes | ✓ Yes | Not required |
| **OFL (fonts)** | ✓ Yes | ✓ Yes | ✓ Yes | Attribution recommended |
| **Royalty-Free (paid)** | Per license terms | Per terms | Usually yes | Per terms |
| **All Rights Reserved** | ✗ No | ✗ No | ✗ No | Irrelevant |

:::callout-warning[NC = Non-Commercial Warning]
"Non-commercial" means you cannot charge money for the game, run ads in it, or use it to promote a paid product. A free game on itch.io is generally fine; a free-to-play mobile game with ads is not. "Non-commercial" does not mean "only if I don't make money" — it means the work itself cannot be part of a commercial activity. When in doubt, use CC0 or CC BY assets.
:::

### Creative Commons Explained

Creative Commons licenses are built from four conditions that can be combined. Understanding the conditions lets you decode any CC license at a glance:

Creative Commons License Conditions

BY

SA

NC

ND

Attribution

ShareAlike

NonCommercial

NoDerivatives

Credit the creator

in your credits

Your derivative work

must use same license

No commercial use

allowed

Cannot modify or

build upon the work

✓ game-safe

✓ game-safe

⚠ free games only

⚠ restricted

The four Creative Commons condition badges. A license like "CC BY-NC 4.0" combines Attribution + NonCommercial.

For jam and indie games, stick to **CC0**, **CC BY**, or licenses with explicit commercial permission. Keep a text file called `CREDITS.txt` in your project root listing every asset, its source, and its license — this becomes the in-game credits screen later.

## 2 · Sprites & Pixel Art

2D sprites are the most common asset type for indie games. They come as individual images or as **spritesheets** — a single image tiling multiple frames of animation in a grid. Godot's importer handles both, but the settings you choose have a dramatic effect on how your sprites look at runtime.

### Where to Find Free Sprites

| Source | License | Best For | URL |
| --- | --- | --- | --- |
| **Kenney.nl** | CC0 / Kenney (free commercial) | Huge variety, consistent style, jam-ready | kenney.nl/assets |
| **OpenGameArt.org** | Mixed (CC0, CC BY, GPL) | Community-contributed art, check per asset | opengameart.org |
| **itch.io (free assets)** | Per creator | Curated high-quality packs, modern styles | itch.io/game-assets/free |
| **Craftpix.net** | Craftpix Free License | Polished RPG & platformer assets | craftpix.net/freebies |
| **Game-icons.net** | CC BY 3.0 | UI icons and inventory icons (thousands) | game-icons.net |
| **Lospec Palette List** | N/A (reference) | Color palettes for pixel art consistency | lospec.com/palette-list |

### Importing Spritesheets into Godot 4

When you drop a spritesheet PNG into your Godot project, it appears in the FileSystem dock. By default, Godot imports it as a plain `Texture2D`. To use it as an animated sprite, you have two paths:

1. **Import as Texture2D** (default) — use with `AnimatedSprite2D`, slicing manually in the SpriteFrames editor.
2. **Import as SpriteSheet** — import the texture, then use it in `AnimatedSprite2D` → SpriteFrames → "Add frames from spritesheet" button.

Here is the step-by-step for setting up an `AnimatedSprite2D` from a spritesheet:

1. Drop the PNG into `res://art/` in the FileSystem dock.
2. Add an `AnimatedSprite2D` node to your scene.
3. In the Inspector, click **Sprite Frames → [new SpriteFrames]**.
4. The SpriteFrames editor opens at the bottom. Click **Add Animation** and name it (e.g., "run", "idle", "jump").
5. Click the filmstrip icon labeled **"Add frames from spritesheet"** (top-left of the SpriteFrames editor).
6. Browse to your spritesheet PNG. Set the **horizontal** and **vertical** frame count to match your sheet's grid.
7. Select which frames belong to this animation and click **Add N frames**.
8. Repeat steps 4–7 for each animation in your sheet.

### Critical Import Settings for Pixel Art

This is where most beginners go wrong. Godot's default import settings use texture filtering designed for smooth, high-resolution artwork. For pixel art, this filtering blurs the crisp edges and makes your sprites look terrible. You must change the filter setting.

:::callout-key[The Most Important Pixel Art Setting]
Godot 4 has no Filter option on the Import tab — that was Godot 3, and filtering moved out of the importer. Set it globally instead: **Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter → Nearest** (the options are Nearest, Linear, Linear Mipmap and Nearest Mipmap, and it ships on *Linear*, which is what blurs pixel art). For a single sprite that needs to differ from the project default, use the node’s own **Texture → Filter** in the Inspector — `CanvasItem.texture_filter` — which inherits from its parent unless you set it.
:::

Texture Filter Comparison

Linear (default) ✗

Blurry, smeared edges

Nearest ✓

Crisp, sharp pixel edges

Linear filter blurs pixels at scaled sizes. Nearest filter preserves the crisp pixel grid that pixel art relies on.

The full set of pixel art import settings to review:

| Setting | Pixel Art Value | Why |
| --- | --- | --- |
| Filter | `Nearest` | No interpolation between pixels |
| Mipmaps → Generate | `Off` | Mipmaps average nearby pixels, creating blur at small sizes |
| Compress → Mode | `Lossless` | No lossy compression artifacts on flat colors |
| Detect 3D | `Off` | Prevents Godot from importing 2D art as a 3D texture |

### AnimatedSprite2D vs Sprite2D + AnimationPlayer

Godot gives you two ways to animate 2D sprites. Knowing when to use each saves time:

| Node | Best For | Drawback |
| --- | --- | --- |
| `AnimatedSprite2D` | Characters with frame-by-frame sprite animations (walk, run, jump, attack) | Only controls the sprite frame — can't sync with other node properties |
| `Sprite2D` + `AnimationPlayer` | Complex animations that change multiple properties simultaneously (position, scale, color, frame) | More setup; AnimationPlayer timeline can get complex |

Rule of thumb: use `AnimatedSprite2D` for character sprites. Use `AnimationPlayer` when you need to animate anything beyond the current frame.

## 3 · 3D Models

For 3D games, you'll need meshes, materials, and often skeletal animations. Godot 4 has first-class support for the **GLTF 2.0** format, which has become the standard for real-time 3D asset exchange. Always prefer GLTF/GLB over older formats like .obj or .dae when you have a choice.

### Where to Find Free 3D Assets

| Source | License | Quality |
| --- | --- | --- |
| **Kenney.nl 3D packs** | CC0 | Low-poly, consistent, great for jams |
| **Sketchfab (Free section)** | Mixed CC | High variety, check license per model |
| **Quaternius** | CC0 | High quality stylized packs (RPG, City, etc.) |
| **OpenGameArt 3D** | Mixed CC | Community contributed |
| **Mixamo (animations)** | Adobe License (free, commercial OK) | Humanoid animation library, excellent quality |

### Importing GLB/GLTF in Godot 4

Drop a `.glb` or `.gltf` file into your project folder. Godot automatically imports it and creates a virtual scene hierarchy. The file itself becomes a **PackedScene** resource you can instance.

To use the model in your scene: drag the `.glb` from the FileSystem dock into the 3D viewport. This instances it as a child node. You'll see a hierarchy of nodes created by the importer:

- `Node3D` — root of the imported scene
- `MeshInstance3D` — the visible mesh (one per mesh object in the file)
- `Skeleton3D` — present only if the model has a rig/armature
- `AnimationPlayer` — present only if the file contains animations

### Import Actions: Extract vs. Keep

When a GLB contains materials and textures, you have a choice of how to handle them. Select the GLB in the FileSystem dock, open the **Import** tab, and look at the **Meshes** and **Materials** sections:

| Action | What It Does | When to Use |
| --- | --- | --- |
| `Keep` | Materials stay embedded in the imported scene. Changes are lost if you reimport. | Quick prototyping when you don't need to customize materials |
| `Extract` | Creates standalone `.material` files you can edit freely. | Whenever you want to customize colors, shaders, or textures |

For a production game, always extract materials. For a jam prototype, keeping is fine.

:::callout-pitfall[Watch Out For: Animation Naming]
Mixamo exports animations with names like `Armature|walk`. Godot's `AnimationPlayer.play()` expects just `"walk"`. In the import settings, check **Animation → Import Rest as RESET** and review animation names. You may need to rename animations after extracting the GLB.
:::

:::callout-tip[Merging Multiple Mixamo Animations]
Mixamo gives you one GLB per animation. To combine them into a single character file, use Godot's built-in **Blender → File → Append** workflow or the community **Godot Mixamo Importer** plugin from the Asset Library. The plugin automates re-targeting animations from multiple files onto a single skeleton.
:::

## 4 · Audio Assets

Audio has a disproportionate impact on how polished a game feels. Players will forgive imperfect art much more readily than they forgive silence or scratchy sound. Audio assets fall into two categories: **sound effects** (short, one-shot) and **music** (looping, background). They have different sources, different formats, and different import settings.

### Where to Find Free Audio

| Source | License | Best For |
| --- | --- | --- |
| **Kenney Audio** | CC0 | Complete SFX packs, 8-bit & modern styles |
| **Freesound.org** | Mixed CC (most CC0/CC BY) | Real-world recordings, every imaginable sound |
| **OpenGameArt (audio)** | Mixed CC | Game-specific music loops, chiptune |
| **Zapsplat.com** | Zapsplat Standard | Professional SFX, free with account |
| **JSFXR / sfxr.me** | Generated (yours) | 8-bit SFX — generate jump/shoot/explosion sounds instantly |
| **Kevin MacLeod (incompetech.com)** | CC BY 4.0 | Huge library of game music (attribute required) |
| **Pixabay Music** | Pixabay License (commercial OK) | Ambient, electronic, orchestral loops |

:::callout-tip[Generate SFX Instantly]
For jam games, visit [sfxr.me](https://sfxr.me) in your browser. Click preset buttons (Jump, Pickup, Laser, etc.) to generate retro sound effects instantly. Export as WAV. This takes under 5 minutes and gives you all core SFX for free.
:::

### Audio Formats: WAV vs OGG

Godot supports three primary audio formats. Choosing the right one matters for quality, file size, and looping precision:

Audio Format Decision Tree

WAV

Uncompressed PCM

✓ Sample-accurate loops

✓ No decode overhead

✓ Best for short SFX

✗ Large file size

Use for: SFX < 3 sec

OGG Vorbis

Lossy compressed

✓ Very small file size

✓ Good loop support

✗ Lossy (tiny quality loss)

✗ Decode overhead

Use for: music, long SFX

MP3

Lossy compressed

✓ Widely supported

✗ Poor loop accuracy

✗ Gap at loop point

✗ Patent history

Avoid for music loops

WAV for sound effects (precision matters), OGG for music (file size matters). Avoid MP3 for looping music.

### Audio Import Settings

Select an audio file in the FileSystem dock and open the **Import** tab to see these options:

| Setting | What It Controls | Recommendation |
| --- | --- | --- |
| **Compress → Mode** | How Godot stores the audio internally | WAV SFX: `Disabled`; OGG music: `Vorbis` |
| **Loop → Mode** | Whether and how the audio loops | Music: `Forward`; SFX: `Disabled` |
| **Loop → Begin / End** | Sample-accurate loop points (in samples) | Set for music to avoid pops at the seam |
| **BPM** | Tempo metadata for beat-synced games | Set this for music if you do rhythm-based gameplay |

### Setting Precise Loop Points for Music

The most common audio bug in student games is music that pops, clicks, or has a noticeable gap when it loops. This happens because the loop point is at a non-zero amplitude — the audio "jumps" from the end back to the start. To fix this:

1. Open the OGG file in [Audacity](https://www.audacityteam.org/) (free) or your DAW.
2. Find the exact sample where the loop should begin and end (usually a bar boundary on a zero-crossing).
3. Note the sample numbers. In Audacity: Edit → Set Loop Point.
4. In Godot's Import tab, set **Loop Begin** and **Loop End** to those sample numbers.
5. Click Reimport.

Alternatively, set a `loop_offset` on the `AudioStream` resource in GDScript if you need runtime control:

```gdscript
var stream := preload("res://audio/music/game.ogg") as AudioStreamOggVorbis
stream.loop = true
stream.loop_offset = 2.0   # start loop from 2 seconds in
$Music.stream = stream
$Music.play()
```

## 5 · Fonts

Typography shapes the personality of your game's UI. A horror game with Comic Sans and a pixel game with a serif font immediately feel wrong. Choosing and importing fonts takes less than 10 minutes but has a big impact on professionalism.

### Where to Find Free Fonts

| Source | License | Best For |
| --- | --- | --- |
| **Google Fonts** | OFL / Apache (mostly) | Clean UI fonts, enormous selection |
| **DaFont.com** | Per font (check each) | Stylized display fonts; verify commercial use license |
| **Font Squirrel** | Commercial-use filtered | Only shows fonts with commercial licenses |
| **Kenney Fonts** | CC0 | Pixel and clean UI fonts in TTF format |
| **1001fonts.com** | Per font | Broad selection; filter by "100% free" for commercial use |

### Importing and Using Fonts in Godot 4

Drop a `.ttf`, `.otf`, or `.woff2` file into your project. It imports automatically as a `FontFile` resource. To use it:

1. Select a `Label` or `Button` node.
2. In the Inspector, open **Theme Overrides → Fonts**.
3. Click the **Font** slot and drag your font file from the FileSystem dock onto it.
4. Set **Font Size** in the **Theme Overrides → Font Sizes** section.

To apply a font project-wide (to all Labels, Buttons, etc.), create a Theme resource and set it in **Project Settings → GUI → Theme → Custom**. This is the recommended approach for production games.

```gdscript
# Set font at runtime (useful for dynamic UI)
var font_file := preload("res://fonts/my_font.ttf") as FontFile
$Label.add_theme_font_override("font", font_file)
$Label.add_theme_font_size_override("font_size", 24)

# Or use a SystemFont to fall back to OS fonts (no bundling needed):
var sys_font := SystemFont.new()
sys_font.font_names = ["Arial", "Helvetica", "sans-serif"]
$Label.add_theme_font_override("font", sys_font)
```

:::callout-pitfall[Watch Out For: Bitmap Fonts vs TrueType]
Godot 4 supports **bitmap fonts** (`.fnt`) created with tools like BMFont or Shoebox. They are pre-rasterized at a fixed size and look perfect at that size but blurry when scaled. TrueType/OpenType fonts are vector-based and scale cleanly at any size. For pixel art games, bitmap fonts are the better choice. For all other games, use TTF.
:::

## 6 · The Godot Asset Library

The Godot Asset Library is an in-editor repository of free plugins, templates, demos, and asset packs maintained by the Godot community. Access it from the **AssetLib** tab at the top of the editor (next to 2D, 3D, Script).

The library is searchable and categorized. Everything in it is open-source (usually MIT or CC). Notable categories for asset sourcing:

| Category | Notable Entries |
| --- | --- |
| **Templates** | First-person controller, top-down shooter, platformer starter |
| **Plugins** | Dialogic (dialogue system), Phantom Camera, GDQuestDE, Popochiu |
| **3D** | Kenney 3D packs imported as Godot scenes |
| **Shaders** | Outline shader, water shader, CRT effect |
| **Tools** | Import remapper, texture packer integration |

To install an asset library item, click **Download** in its page, then **Install**. The files are extracted into your project folder. Plugins need to be activated in **Project Settings → Plugins**.

### Shader Effects from AssetLib

Many visual effects can be applied as **ShaderMaterial** resources without writing any shader code. Popular ones available in the Asset Library:

- **Outline/Glow** — Draw a colored outline around sprites. Apply to a `CanvasItemMaterial` or as a screen-space post-process.
- **CRT Effect** — Scanlines and chromatic aberration for retro games. Apply to a fullscreen `ColorRect` in a top-level CanvasLayer.
- **Water Shader** — Animated UV distortion for 2D water surfaces.
- **Pixelation** — Quantizes the screen to simulate lower resolution, great for pixel art games using a virtual resolution.

## 7 · Advanced Import Settings

As your project grows, you'll encounter import scenarios that require more than the defaults. These two features solve the most common problems.

### Import Remaps and .import Files

Every file you drop into a Godot project generates a hidden `.import` file (visible in the `.godot/imported/` folder). This file stores the import settings and the path to the processed version of the asset.

When you change import settings and click Reimport, Godot regenerates the `.import` file and reprocesses the asset. If you're using version control (Git), commit the `.import` files so teammates get the same import settings. Add `.godot/imported/` to `.gitignore` but keep the source assets and their `.import` metadata files.

:::callout-tip[Batch Import Settings]
To apply the same import settings to many files at once, select multiple files in the FileSystem dock (hold Ctrl/Cmd), then open the Import tab. Changes apply to all selected files at once. This is much faster than changing settings one-by-one when importing a whole art pack.
:::

### Organizing Assets in the FileSystem

Godot doesn't enforce a folder structure, but a consistent one saves enormous amounts of time as a project grows. Here is the structure used by most professional Godot projects:

```gdscript
# res:// structure
res://
├── art/
│   ├── sprites/        # 2D character and object sprites
│   ├── ui/             # UI textures, icons, buttons
│   ├── backgrounds/    # large background art
│   └── tilesets/       # tilemap tiles
├── audio/
│   ├── sfx/            # short sound effects (WAV)
│   └── music/          # music loops (OGG)
├── fonts/              # .ttf / .otf font files
├── models/             # 3D .glb files
├── scenes/
│   ├── levels/         # gameplay levels
│   ├── ui/             # UI scenes (HUD, menus)
│   ├── characters/     # player, enemy scenes
│   └── objects/        # interactable prop scenes
├── scripts/            # standalone GDScript files (not attached to scenes)
└── shaders/            # .gdshader files
```

Using `res://art/` instead of a flat structure means `preload("res://art/sprites/player_idle.png")` paths stay readable and autocomplete works well in the editor.

## Practice Problems

1. easy
 You download a sound effect from Freesound.org with a "CC BY 3.0" license. What must you do to legally use it in a commercial game? What additional restriction would "CC BY-NC 3.0" add?
 Solution

 **CC BY 3.0:** You must credit the creator in your game (credits screen or accompanying text). A line like "Explosion sound by [Author] on Freesound.org (CC BY 3.0)" is sufficient. Commercial use is permitted.
 **CC BY-NC 3.0:** The NC (NonCommercial) restriction means you cannot use the sound in a game that earns revenue through sales, ads, microtransactions, or any commercial activity. Only free-to-play, no-monetization games would be permitted.
2. easy
 Your pixel art looks blurry after importing into Godot. Name the two settings you should change in the Import tab, and where to find the project-wide setting to apply the fix globally.
 Solution

 1. **Filter → Nearest** (stops interpolation between pixels)
 2. **Mipmaps → Generate → Off** (prevents downscaled blurry versions being generated)
 To apply globally: **Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter → Nearest**. This makes all newly imported textures default to Nearest filter without manually changing each one.
3. standard
 Write GDScript that preloads a spritesheet as a `Texture2D`, creates a new `SpriteFrames` resource in code (without the editor), adds 4 frames from the sheet (2×2 grid, each frame 32×32px), and assigns it to an `AnimatedSprite2D` with an animation named "walk" playing at 8 FPS.

   ::::solution[Solution]
   ```gdscript
   func _ready() -> void:
       var texture := preload("res://art/sprites/player_walk.png") as Texture2D

       var frames := SpriteFrames.new()
       frames.add_animation("walk")
       frames.set_animation_speed("walk", 8.0)
       frames.set_animation_loop("walk", true)

       # Each frame is 32x32 in a 2x2 grid
       var frame_w := 32
       var frame_h := 32
       var cols := 2
       var rows := 2

       for row in rows:
           for col in cols:
               var region := Rect2(col * frame_w, row * frame_h, frame_w, frame_h)
               var atlas := AtlasTexture.new()
               atlas.atlas = texture
               atlas.region = region
               frames.add_frame("walk", atlas)

       $AnimatedSprite2D.sprite_frames = frames
       $AnimatedSprite2D.play("walk")
   ```
   ::::

4. standard
 Write a utility function `load_audio_library(base_path: String) -> Dictionary` that scans a folder for all `.wav` and `.ogg` files using `DirAccess`, loads each as an `AudioStream`, and returns a dictionary mapping the filename (without extension) to the stream. For example, `"jump.wav"` → key `"jump"`.

   ::::solution[Solution]
   ```gdscript
   func load_audio_library(base_path: String) -> Dictionary:
       var library: Dictionary = {}
       var dir := DirAccess.open(base_path)
       if dir == null:
           push_error("Could not open audio directory: %s" % base_path)
           return library

       dir.list_dir_begin()
       var filename := dir.get_next()

       while filename != "":
           if not dir.current_is_dir():
               var ext := filename.get_extension().to_lower()
               if ext == "wav" or ext == "ogg":
                   var key := filename.get_basename()   # removes extension
                   var full_path := base_path.path_join(filename)
                   var stream := load(full_path) as AudioStream
                   if stream != null:
                       library[key] = stream
           filename = dir.get_next()

       dir.list_dir_end()
       return library

   # Usage:
   # AudioManager.sfx_library = load_audio_library("res://audio/sfx/")
   ```
   ::::

5. challenge
 Write a `FontLoader` autoload that loads all fonts from `res://fonts/` at startup, creates a project-wide `Theme` resource at runtime, and sets the base font on the theme so all Label nodes in the game use it. Support switching fonts at runtime via a `set_font(font_name: String, size: int)` method that updates the theme.

   ::::solution[Solution]
   ```gdscript
   # FontLoader.gd — AutoLoad
   extends Node

   var theme: Theme
   var _fonts: Dictionary = {}

   func _ready() -> void:
       theme = Theme.new()
       _load_fonts()
       # Apply theme globally — any Control that doesn't override will use this
       # Set as project-default theme in Project Settings → GUI → Theme → Custom
       # Or assign to the root Control if accessible.

   func _load_fonts() -> void:
       var dir := DirAccess.open("res://fonts/")
       if dir == null:
           return
       dir.list_dir_begin()
       var f := dir.get_next()
       while f != "":
           if not dir.current_is_dir():
               var ext := f.get_extension().to_lower()
               if ext in ["ttf", "otf", "woff2"]:
                   var key := f.get_basename()
                   _fonts[key] = load("res://fonts/".path_join(f)) as FontFile
           f = dir.get_next()
       dir.list_dir_end()

   func set_font(font_name: String, size: int) -> void:
       if not _fonts.has(font_name):
           push_warning("FontLoader: unknown font '%s'" % font_name)
           return
       theme.set_font("font", "Label",  _fonts[font_name])
       theme.set_font("font", "Button", _fonts[font_name])
       theme.set_font("font", "LineEdit", _fonts[font_name])
       theme.set_font_size("font_size", "Label",  size)
       theme.set_font_size("font_size", "Button", size)
       theme.set_font_size("font_size", "LineEdit", size)

   func get_font(font_name: String) -> FontFile:
       return _fonts.get(font_name, null)
   ```
   ::::

## Chapter Summary

| Topic | Key Point |
| --- | --- |
| Licenses | CC0 and CC BY are safe for commercial games; NC means free-only; keep a CREDITS.txt |
| Pixel art filter | Import tab → Filter: `Nearest`, or set globally in Project Settings |
| Spritesheets | Use AnimatedSprite2D → SpriteFrames → "Add frames from spritesheet" |
| 3D models | Prefer GLB/GLTF; extract materials if you need to customize them |
| Audio formats | WAV for short SFX (accuracy); OGG for music (size); avoid MP3 for loops |
| Music loops | Set Loop Begin/End sample points in Import tab to avoid pops |
| Fonts | TTF for scalable UI; Bitmap for pixel art; OFL license is commercial-safe |
| Asset Library | In-editor tab → free plugins, shaders, templates from the community |
| Folder structure | Use art/, audio/, fonts/, models/, scenes/, scripts/ for maintainability |
