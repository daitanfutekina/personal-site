---
title: "Crowd Runner — Swipe Input, LaneController & Tween Steering"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72D"
meta:
  - "Est. study time: ~45 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72d_swipe_lanes.html"
---

## Overview

Add horizontal steering. The player swipes left or right on the touch screen — the
 runner tweens smoothly to the next lane. In the editor (no touch screen) we mirror the
 same behaviour on the A/D and arrow keys. Both paths call the same
 `Runner.change_lane(direction)` we wrote in Ch 72C, so the swipe logic never
 needs to know about the tween.

:::callout-key[What you'll build in this chapter]
A `LaneController` Node child of Runner that owns the input state machine.
 It watches for keyboard actions *and* touch drags, converts them into
 `change_lane(±1)` calls, and enforces a “one swipe per tween” rule
 so you can't stack inputs mid-transition.
:::

### Prerequisites

- Ch 72C complete — Runner scene exists with `change_lane(direction)` method.
- Input Map from Ch 72A: `lane_left`, `lane_right`.
- Basic understanding of InputEvent handling (Ch 46).

:::callout-connect[Reference checklist]
**Ch 46** (Input Map, InputEvent), **Ch 28** (Tween basics —
 the Ch 72C tween call is already there, we're just triggering it).
:::

## 1. LaneController Node

LaneController is a plain `Node` (no visuals, no physics) sitting under Runner.
 Keeping input handling out of Runner.gd is the clean-code choice: Runner does motion,
 LaneController does steering intent. In Ch 72G we'll add a pause check the same way —
 pause is not the runner's job.

1. Open `res://scenes/runner/Runner.tscn`.
2. Select the Runner root, add child **Node**, name it
 **LaneController**.
3. Attach a new script,
 `res://scenes/runner/LaneController.gd`, template Empty, inherits Node.
4. Save the scene.

Runner tree now:

```
Runner (CharacterBody3D)                   ← Runner.gd
├── CapsuleShape (CollisionShape3D)
├── LeaderMesh (MeshInstance3D)
├── GateSensor (Area3D)
│   └── CollisionShape3D
├── HitSensor (Area3D)
│   └── CollisionShape3D
└── LaneController (Node)                  ← LaneController.gd
```

## 2. Keyboard Fallback First

Start with the easy path — the Input Map actions from Ch 72A. This gives you a working
 editor test before touch complicates anything.

```gdscript
# res://scenes/runner/LaneController.gd — first pass, keyboard only
class_name LaneController
extends Node

@export var runner_path : NodePath

@onready var runner : Runner = get_node(runner_path)

func _unhandled_input(ev: InputEvent) -> void:
    if ev.is_action_pressed("lane_left"):
        runner.change_lane(-1)
    elif ev.is_action_pressed("lane_right"):
        runner.change_lane(+1)
```

1. Save the script. Select the LaneController node in Runner.tscn.
2. In the Inspector, set *Runner Path* — click *Assign…* → pick
 *..* (the Runner root). The path should read `..`.
3. Save. Run. Press A — the orange capsule should tween into the left lane.
 D tweens back. Repeated presses walk lanes and stop at the ends
 (`clamp` in Runner.change\_lane handles that).

:::callout-intuition[Why \_unhandled\_input and not \_input]
`_unhandled_input` fires only for events that no UI Control (e.g. pause
 button) has already consumed. In Ch 72G we add a pause button that captures the
 `Escape` action — using `_input` here would still receive
 pauses on top of lane switches, weird. `_unhandled_input` is the correct
 choice for gameplay input that must yield to UI.
:::

:::callout-pitfall[If you get Invalid get index 'change\_lane']
The `runner` variable is null — the NodePath didn't resolve. Confirm
 LaneController's *Runner Path* exports as `..` in the Inspector, not
 empty and not an absolute path.
:::

## 3. Touch Swipe Detection

Touch swipes are a two-event dance: *touch begin* saves the starting screen
 position, *touch move* (or *touch end*) compares the current position
 against the start; if the horizontal delta exceeds a threshold, fire the swipe.

:::callout-intuition[Two InputEvent types we care about]
- **InputEventScreenTouch** — a tap-down or tap-up event. Has
 `position` and `pressed` (true = down, false = up).
- **InputEventScreenDrag** — continuous position updates while a finger
 is moving on-screen. Has `position` and `relative` (delta from
 the previous drag event, in screen pixels).
:::

We use both. On *touch begin* we save the start point. On *drag* we check
 whether |current.x − start.x| exceeds `min_swipe_px`. When it does, fire the
 swipe once, then set an *armed = false* flag so the rest of the drag doesn't
 re-fire. On *touch up* we re-arm.

:::callout-warning[Don't just use InputEventScreenDrag.relative.x]
Accumulating relative deltas across many drag events works, but you have to reset the
 accumulator carefully or the runner will lane-swap every 40 px of continuous movement
 forever. Comparing against the touch *start* position (a single anchor) is
 simpler and inherently rate-limited to one swipe per finger-down.
:::

## 4. Touch from Mouse in Editor

No touch screen on your dev PC? Godot 4 has a switch that translates mouse clicks and
 drags into fake InputEventScreenTouch / InputEventScreenDrag events. Turn it on:

1. Project → Project Settings → **Input Devices → Pointing**.
2. Check **Emulate Touch From Mouse** = *on*.
3. (Optional) Also enable **Emulate Mouse From Touch** = *on* — this
 is the reverse direction (rarely useful, but harmless).

:::callout-tip[Now click-and-drag horizontally in the running game]
Click-and-hold with the mouse, drag right > 40 px, release — the runner should
 swipe into the right lane. The same code path runs on desktop editor and on the phone.
 You never write mouse-specific handling.
:::

### The swipe state machine in one diagram

Every touch input travels this four-node path. Reading the diagram makes the
 `_armed` flag obvious — it's the label on the “can still fire” edge.

```
                    ┌─────────────────────┐
     touch begin →  │  ARMED               │
                    │  _armed = true       │
                    │  _touch_start saved  │
                    └──────────┬──────────┘
                               │  drag > 40 px?
                               │
                       yes ────┼──── no (keep dragging)
                               │
                               ▼
                    ┌─────────────────────┐
                    │  FIRED               │
                    │  change_lane(±1)     │──── further drags: ignored
                    │  _armed = false      │     (still in this state)
                    └──────────┬──────────┘
                               │  touch end (finger up)
                               ▼
                    ┌─────────────────────┐
                    │  IDLE                │──── next touch begin
                    │  _armed = false      │     → back to ARMED
                    │  waiting for touch   │
                    └─────────────────────┘
```

:::callout-intuition[Every “bug” you might hit maps to a missing edge]
- Swipes fire multiple times per finger drag → you never transitioned to FIRED
 (missing `_armed = false`).
- Swipes never fire after the first → you never transitioned back to ARMED on
 touch begin (missing `_armed = true` in the pressed handler).
- Tiny drags trigger swipes → your threshold check runs before the `_armed`
 gate (check order matters).
:::

## 5. Full LaneController.gd

Replace the file entirely with this final version:

```gdscript
# res://scenes/runner/LaneController.gd
# Owns steering input for the Runner. Two paths, one call:
#   - keyboard actions lane_left / lane_right
#   - touch swipe (InputEventScreenTouch + InputEventScreenDrag)
# Both end at runner.change_lane(±1). See Ch 72 Design Sheet §Runner Architecture.
class_name LaneController
extends Node

@export var runner_path  : NodePath
@export var min_swipe_px : float = 40.0

@onready var runner : Runner = get_node(runner_path)

# ── Touch state ───────────────────────────────────────────────────────
var _touch_start : Vector2 = Vector2.ZERO
var _armed       : bool    = false   # true = swipe not yet fired since touch begin

func _unhandled_input(ev: InputEvent) -> void:
    # Keyboard path ---------------------------------------------------
    if ev.is_action_pressed("lane_left"):
        runner.change_lane(-1)
        return
    if ev.is_action_pressed("lane_right"):
        runner.change_lane(+1)
        return

    # Touch path ------------------------------------------------------
    if ev is InputEventScreenTouch:
        if ev.pressed:
            _touch_start = ev.position
            _armed = true
        # else: touch up — nothing to do; we already fired on drag (or not at all)
        return

    if ev is InputEventScreenDrag and _armed:
        var dx : float = ev.position.x - _touch_start.x
        if absf(dx) >= min_swipe_px:
            runner.change_lane(1 if dx > 0 else -1)
            _armed = false   # consume this swipe; wait for next touch-begin
        return
```

:::callout-tip[The \_armed flag]
It converts a stream of drag events into *at most one* lane change per finger
 contact. Without it, dragging your finger further past the 40-px threshold would fire
 swipe after swipe every few pixels of movement — a bug people hit constantly on their
 first swipe implementation.
:::

:::callout-warning[Vertical swipes are ignored]
We only check `dx`. A player dragging up or down does nothing — correct for
 this game (no jump, no slide). If you later add slide (finger swipe down → runner ducks),
 compare `absf(dx)` vs `absf(dy)` to decide which axis dominates.
:::

## 6. Verification

:::callout-key[Verify]
- Run the project (F5).
- Press A / Left Arrow — leader tweens to the left lane.
- Press D / Right Arrow — tweens right.
- Multi-press: quickly hit D three times — leader walks Centre → Right,
 stays in Right (the two extra presses clamp).
- Mouse click-and-drag horizontally > 40 px in the game window — same effect as
 the keyboard swipe.
- Try a very small drag (~10 px) — nothing happens. Then a large drag — swipe fires,
 release the mouse, drag again — second swipe fires normally.
:::

:::callout-warning[Every horizontal micro-jiggle triggers a swipe]
You forgot the `_armed` flag, or you're not clearing it after firing.
 Re-check that `_armed = false` lives inside the “fire the swipe”
 block, and that it's set back to `true` only in the touch-begin handler.
:::

:::callout-warning[Mouse drags do nothing]
Project Settings → Input Devices → Pointing → Emulate Touch From Mouse is off. Turn
 it on and re-run.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why does LaneController live under Runner instead of under Main?

::::solution[Solution]
Encapsulation: the runner scene is fully self-contained — instancing Runner
 anywhere brings its own input handling. If LaneController lived on Main, we'd have to
 wire a NodePath every time we spawned a runner, and the Runner scene would be
 “incomplete” on its own.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Explain why `_unhandled_input` is preferred over `_input` for
 this game.

::::solution[Solution]
`_unhandled_input` receives events only after every UI Control has had a
 chance to handle them. In Ch 72G we add a pause overlay with buttons. If lane-switching
 used `_input`, a mouse click on the resume button would *also* be
 interpreted as a swipe start. `_unhandled_input` correctly yields to UI.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Your `min_swipe_px` is 40. On a 4K desktop monitor with the game window
 stretched to 1080p, this feels fine. On a 3200×1440 phone, players complain their
 swipes don't register. Why, and what's the fix?

::::solution[Solution]
ScreenTouch/Drag positions are in *physical pixels*. 40 px on a 1440p tall
 phone is a much smaller physical distance than on a 1080p desktop. Fix: scale the
 threshold by `DisplayServer.screen_get_dpi()` or by
 `get_viewport().get_visible_rect().size.x / 1080.0` so 40 “design px”
 maps to the equivalent physical distance on any screen. A simpler production fix is
 just bumping `min_swipe_px` to ~80 for HDPI targets.
::::
:::

:::problem[Problem 4 challenge]{difficulty="challenge"}
A player double-swipes fast: swipe right, immediately swipe right again — expecting
 to jump two lanes. Currently only one swipe registers per finger contact. Redesign
 the state so a fast double-swipe traverses two lanes.

::::solution[Solution]
Track the drag distance *at the moment* you first fired, then keep listening
 for further motion — every additional `min_swipe_px` traversed in the same
 direction fires another change\_lane. Implementation: after firing, don't clear
 `_armed`; instead update `_touch_start.x` to the current
 `ev.position.x`. Now the “next 40 px” measurement resets from
 the new anchor. Drag 80 px continuously → two swipes. Drag 120 px → three. Release the
 finger to reset entirely.
::::
:::

:::summary
## Summary

LaneController is a self-contained input node under Runner. Keyboard and touch both
 collapse to a single `runner.change_lane(±1)` call. The runner tweens smoothly
 between the three lane centres, one lane per swipe per finger contact.

**Next:**
 [Ch 72E](./godot_ch72e_crowd_multimesh.html) is the star chapter — building the
 crowd with a single MultiMeshInstance3D that can render 200+ followers at 60 fps on the
 phone.
:::
