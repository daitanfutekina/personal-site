---
title: "Chapter 67 — Game Jam Survival Guide"
source: "godot_ch67_gamejam.html"
---

Part XII: Advanced Topics · Estimated study time: 90 min

## Chapter Overview

A game jam gives you 24–72 hours to design, build, and ship a complete game. It is one of the best skill accelerators in game development — you will practice scoping, rapid prototyping, debugging under pressure, and shipping something real. Many celebrated games started as jam entries: *Celeste*, *SUPERHOT*, and *Baba Is You* all grew from 72-hour prototypes.

This chapter teaches you how to use Godot 4 effectively in a jam context. The techniques here differ from "regular" game development: you will cut ruthlessly, reuse aggressively, and prioritize feel over completeness. By the end you will have a reusable project template, three production-ready autoloads, and a decision framework that can be applied to any jam theme.

:::callout-tip[Prerequisites]
Signals & Autoloads (Ch 5, Ch 12), Scenes & Nodes (Ch 3), Audio (Ch 15), SceneTree transitions (Ch 21). A working Godot 4.3+ installation.
:::

## 1 · The Game Jam Mindset

The single biggest difference between jam veterans and newcomers is not technical skill — it is how they think about time. A weekend feels long at 11 PM Friday, but devastatingly short at 10 AM Sunday. Everything in this chapter flows from that reality.

### Why Jams Fail

Postmortems from thousands of jam entries point to the same root causes. Almost no one runs out of *time to code*. Almost everyone runs out of *scope*:

| Failure Mode | What It Looks Like | Root Cause |
| --- | --- | --- |
| Feature creep | "We could also add multiplayer…" | No written MVP definition |
| Art paralysis | 6 hours polishing the player sprite | Wrong order of operations |
| Tech debt trap | Rewriting the movement system Saturday night | No jam-specific template |
| Missing the theme | Submitted game barely relates to the theme | No early design document |
| Build fails on export | Panicked Sunday morning | Never tested export during development |
| No juice | Technically complete but feels lifeless | Polish left entirely for the end |

### The Right Attitude

Your jam game does not need to be *good* — it needs to be *finished*. A janky submitted game teaches more than a polished unsubmitted one. "Shipped and imperfect" beats "perfect and never done" every single time. Adopt this mantra before you open Godot:

:::callout-key[The Three Jam Rules]
1. **Finish it.** A game with bugs that runs is infinitely better than a game that doesn't run at all.
2. **Cut early, not late.** Remove features at hour 4, not hour 44.
3. **One mechanic, ten levels of depth.** Simple rules with interesting interactions beat complex rules with shallow interactions.
:::

Confidence Arc in a Typical Jam

High

Low

0h

12h

24h

36h

48h

"This is awesome!"

Scope panic

The valley

Polish + submit

Confidence in a game jam follows a predictable arc. The valley around hour 20–30 is universal — don't quit there.

## 2 · Scoping Your Game

Scoping is the most important skill in jam development. Bad scoping is why most jams are abandoned or submitted in a broken state. Good scoping is what separates someone who ships every jam they enter from someone who has a folder of half-finished prototypes.

The moment the theme is announced, your brain will flood with ideas. Almost all of them are too big. Your first job is to aggressively filter.

### Define the MVP in the First Two Hours

MVP stands for *Minimum Viable Product* — the smallest game that is still fun and coherent. Write it as a single sentence before you write a line of code. A good MVP sentence has three parts: the **player verb** (what the player does), the **core loop** (do it → get feedback → repeat), and the **win/lose condition**.

| Theme | Bad MVP (too vague) | Good MVP (concrete) |
| --- | --- | --- |
| "Connection" | "A game about connecting things" | "Player drags cables between terminals; connect all terminals before the timer expires" |
| "Depth" | "Underwater exploration game" | "Submarine dives deeper each wave; pressure kills you if you go too deep too fast" |
| "Two Buttons" | "Platformer with only two buttons" | "Left/right only — dodge obstacles in an auto-runner; survive 60 seconds" |

### The Cut List

After writing your MVP, write a "Cut List" — features you *want* but will only add after the MVP is playable end-to-end. Put the Cut List somewhere visible. Every feature you think of during development gets written on the Cut List first; you only build it if MVP is done and time permits.

:::callout-warning[The Golden Rule]
Every feature not on your MVP sentence is on the Cut List by default. You never move features

from

the Cut List to the build unless the game is already playable and you have time to spare. Never move features

from

the build to the Cut List — if it's coded it ships.
:::

### Scope Matrix

When evaluating whether to add a feature, run it through this two-axis matrix. Build only the top-right quadrant:

Hard to implement

Easy to implement

High fun

Low fun

Cut or simplify

Spend time only if critical

✓ Build this

High ROI — prioritize

Skip entirely

Polish / nice-to-have

Add after MVP is done

e.g. procedural level gen

e.g. jump, enemy patrol, score

e.g. achievement system

e.g. screenshake, sound fx

The Scope Matrix. Evaluate every feature on these two axes before adding it to your build plan.

## 3 · The 48-Hour Schedule

Time management in a jam is not about working longer hours — it is about spending the right hours on the right things. Here is a battle-tested schedule for a 48-hour solo jam. Adjust proportions for team jams (art and sound can be parallelized).

:::callout-intuition[Why This Order Matters]
The biggest mistake is spending Friday night on systems (inventory, saves, menus) before the core mechanic is proven. You may spend 8 hours on systems for a mechanic you'll decide to scrap by Saturday afternoon. Always validate the core loop first.
:::

### Hour-by-Hour Guide

48-Hour Jam Schedule

Design & Plan (0–2h)

Core Mechanic Prototype (2–10h)

Playable Loop + Content (10–22h)

Sleep (22–26h)

Audio + Juice + Bug Fixes (26–36h)

Polish + Tutorial (36–44h)

Export & Submit (44–48h)

0h

12h

24h

36h

48h

A proven 48-hour jam schedule. The core mechanic block is the most important — don't shrink it to make time for polish.

| Phase | Hours | Goals | Hard Stop |
| --- | --- | --- | --- |
| **Design & Plan** | 0–2 | Write MVP sentence, Cut List, core mechanic sketch. Set up Godot project from template. | You must have a written MVP sentence before coding begins. |
| **Core Prototype** | 2–10 | Player moves, core mechanic works, one enemy/obstacle. No art — use placeholder shapes. | If the mechanic isn't fun with rectangles, better art won't save it. |
| **Playable Loop** | 10–22 | Win/lose works, 3+ levels or waves of content, basic HUD, sound stubs. Export once. | Stop adding features at hour 22 no matter how good you feel about scope. |
| **Sleep** | 22–26 | Mandatory. 4+ hours. Problems that seemed impossible will solve themselves. | Set an alarm. Skipping sleep costs more hours than it saves. |
| **Audio + Juice** | 26–36 | Real sound fx, music, screenshake, particles, visual feedback. Fix critical bugs only. | Juice has enormous ROI — a bad game with good sound feels better than a good game with silence. |
| **Polish** | 36–44 | Main menu, instructions screen, credits, difficulty tuning. Play-test and iterate. | No new features past hour 36. Polish existing ones. |
| **Export & Submit** | 44–48 | Web export to itch.io, fill in game page, screenshots, short description. Submit early. | Submit at hour 46, not 47:58. Export failures happen. |

## 4 · The Jam Project Template

Starting from scratch each jam wastes 1–2 hours on boilerplate. A good template has three autoloads already wired up: a **GameManager** for global state, a **SceneLoader** for instant transitions, and an **AudioManager** for one-line sound calls. You set these up once, save the project as a template, and re-use it every jam.

:::callout-tip[How to Use This Template]
After creating the three scripts below, add them as AutoLoad singletons via

Project → Project Settings → AutoLoad

. Add

GameManager.gd

as

GameManager

,

SceneLoader.gd

as

SceneLoader

, and

AudioManager.gd

as

AudioManager

. They will be available globally throughout the entire project.
:::

Autoload Architecture

GameManager

SceneLoader

AudioManager

score, lives, state

pause / unpause

restart()

add\_score(n)

goto(scene\_path)

reload\_current()

fade transition

deferred safe

play\_sfx(name)

play\_music(name)

sfx pool

music crossfade

Any scene can call these singletons from anywhere

The three jam autoloads cover 90% of the global state you'll need in any jam game.

### GameManager — Score, State, and Restart

The `GameManager` is the single source of truth for game state. It tracks score, lives, and whether the game is paused or over. Every other scene reads from and writes to `GameManager` rather than passing data through signals or scene trees — which would require scenes to know about each other.

The key design decision here is using **signals** to notify the HUD when values change, rather than having the HUD poll the GameManager every frame. This keeps coupling loose: the HUD responds to `score_changed` without the GameManager knowing the HUD exists.

```gdscript
# GameManager.gd — AutoLoad singleton
extends Node

# --- Signals ---
signal score_changed(new_score: int)
signal lives_changed(new_lives: int)
signal game_over()
signal game_paused(is_paused: bool)

# --- State ---
var score: int = 0
var lives: int = 3
var is_game_over: bool = false
var high_score: int = 0

# --- Constants (tune per game) ---
const STARTING_LIVES := 3
const POINTS_PER_ENEMY := 10

func _ready() -> void:
    # Load high score from disk if it exists
    high_score = _load_high_score()

# -------------------------------------------------------
# Public API — call these from any scene
# -------------------------------------------------------

func add_score(points: int) -> void:
    score += points
    if score > high_score:
        high_score = score
        _save_high_score()
    score_changed.emit(score)

func lose_life() -> void:
    lives -= 1
    lives_changed.emit(lives)
    if lives <= 0:
        trigger_game_over()

func trigger_game_over() -> void:
    if is_game_over:
        return   # guard against double-call
    is_game_over = true
    game_over.emit()

func restart() -> void:
    score = 0
    lives = STARTING_LIVES
    is_game_over = false
    score_changed.emit(score)
    lives_changed.emit(lives)
    SceneLoader.reload_current()

func set_paused(paused: bool) -> void:
    get_tree().paused = paused
    game_paused.emit(paused)

# -------------------------------------------------------
# Private helpers
# -------------------------------------------------------

func _load_high_score() -> int:
    var f := FileAccess.open("user://highscore.dat", FileAccess.READ)
    if f == null:
        return 0
    var val := f.get_32()
    f.close()
    return val

func _save_high_score() -> void:
    var f := FileAccess.open("user://highscore.dat", FileAccess.WRITE)
    if f == null:
        return
    f.store_32(high_score)
    f.close()
```

Inside any scene, connect to GameManager's signals in `_ready()` to keep the HUD in sync:

```gdscript
# HUD.gd
func _ready() -> void:
    GameManager.score_changed.connect(_on_score_changed)
    GameManager.lives_changed.connect(_on_lives_changed)
    GameManager.game_over.connect(_on_game_over)
    # Initialize display from current state
    _on_score_changed(GameManager.score)
    _on_lives_changed(GameManager.lives)

func _on_score_changed(new_score: int) -> void:
    $ScoreLabel.text = "SCORE: %d" % new_score

func _on_lives_changed(new_lives: int) -> void:
    $LivesLabel.text = "♥ × %d" % new_lives

func _on_game_over() -> void:
    $GameOverPanel.visible = true
    $GameOverPanel/FinalScore.text = "Final: %d" % GameManager.score
    $GameOverPanel/HighScore.text  = "Best:  %d" % GameManager.high_score
```

:::callout-pitfall[Watch Out For]
- **Forgetting to reset state on restart.** If `restart()` doesn't reset `is_game_over`, the game-over panel will immediately reappear after restart.
- **Emitting signals before nodes are ready.** If GameManager emits `score_changed` in `_ready()` before the HUD is in the tree, the connection doesn't exist yet. The pattern above re-initializes from current state *after* connecting — this avoids the race condition.
- **Using `get_tree().paused` without setting `process_mode`.** Nodes that should still update while paused (HUD, pause menu) need `process_mode = PROCESS_MODE_ALWAYS`.
:::

### SceneLoader — Instant Scene Transitions

Godot's built-in `get_tree().change_scene_to_file()` works, but it has no transition animation and can cause a one-frame blank flash. The `SceneLoader` autoload wraps scene changes in a tween-based fade, ensuring smooth transitions with a single function call from any scene.

The key technique is a **CanvasLayer** that sits above everything in the scene (via `layer` property). When transitioning, we fade this layer to black, swap the scene, then fade back to transparent. The CanvasLayer persists because it belongs to the autoload Node, not the current scene.

```gdscript
# SceneLoader.gd — AutoLoad singleton
extends Node

signal transition_started()
signal transition_finished()

var _overlay: ColorRect
var _canvas: CanvasLayer
var _is_transitioning := false

func _ready() -> void:
    # Build the full-screen fade overlay at startup
    _canvas = CanvasLayer.new()
    _canvas.layer = 100   # above everything
    add_child(_canvas)

    _overlay = ColorRect.new()
    _overlay.color = Color(0, 0, 0, 0)   # start transparent
    _overlay.anchors_preset = Control.PRESET_FULL_RECT
    _canvas.add_child(_overlay)

# -------------------------------------------------------
# Public API
# -------------------------------------------------------

func goto(scene_path: String, fade_time: float = 0.3) -> void:
    if _is_transitioning:
        return
    _is_transitioning = true
    transition_started.emit()

    # Fade to black
    var tween := create_tween()
    tween.tween_property(_overlay, "color:a", 1.0, fade_time)
    await tween.finished

    # Swap scene
    get_tree().change_scene_to_file.call_deferred(scene_path)
    await get_tree().process_frame   # let the new scene load
    await get_tree().process_frame

    # Fade back to transparent
    tween = create_tween()
    tween.tween_property(_overlay, "color:a", 0.0, fade_time)
    await tween.finished

    _is_transitioning = false
    transition_finished.emit()

func reload_current() -> void:
    goto(get_tree().current_scene.scene_file_path)

func goto_main_menu() -> void:
    GameManager.restart()           # reset state before going to menu
    goto("res://scenes/main_menu.tscn")
```

Usage from any scene is a single line:

```gdscript
# In any scene, on any button press:
func _on_play_button_pressed() -> void:
    SceneLoader.goto("res://scenes/game.tscn")

func _on_restart_button_pressed() -> void:
    GameManager.restart()   # GameManager.restart() calls SceneLoader.reload_current() internally
```

:::callout-tip[Extending for Loading Screens]
For heavier scenes, replace

change\_scene\_to\_file

with

ResourceLoader.load\_threaded\_request()

and poll

load\_threaded\_get\_status()

each frame. Show a spinner on the

\_overlay

while loading. This is rarely needed in a jam game, but it's a clean extension point.
:::

### AudioManager — One-Line SFX and Music

Jam games suffer most from two audio problems: playing a sound effect and immediately playing it again creates overlapping instances that sound terrible; and swapping music tracks produces jarring cuts. The `AudioManager` solves both with a **pool** of `AudioStreamPlayer` nodes for sound effects and a dedicated music player with crossfade support.

The pool pattern works like this: instead of creating a new AudioStreamPlayer node every time a sound plays (which is slow and can pile up), we maintain a fixed pool of, say, 8 players. When a sound needs to play, we grab an idle one from the pool. If all are busy, we steal the one that has been playing longest. This is essentially a ring buffer of audio players.

```gdscript
# AudioManager.gd — AutoLoad singleton
extends Node

# --- Pool of SFX players ---
const POOL_SIZE := 8
var _sfx_pool: Array[AudioStreamPlayer] = []
var _sfx_pool_index := 0   # round-robin cursor

# --- Music players (two for crossfade) ---
var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _active_music_player: AudioStreamPlayer

# --- Preloaded sounds ---
# Populate this dictionary at runtime or override in a child class
var sfx_library: Dictionary = {}
var music_library: Dictionary = {}

# --- Volume buses (use Godot's AudioServer) ---
var sfx_bus_index := AudioServer.get_bus_index("SFX")
var music_bus_index := AudioServer.get_bus_index("Music")

func _ready() -> void:
    # Build the SFX pool
    for i in POOL_SIZE:
        var p := AudioStreamPlayer.new()
        p.bus = "SFX"
        add_child(p)
        _sfx_pool.append(p)

    # Build the two music players
    _music_a = AudioStreamPlayer.new()
    _music_a.bus = "Music"
    add_child(_music_a)

    _music_b = AudioStreamPlayer.new()
    _music_b.bus = "Music"
    add_child(_music_b)

    _active_music_player = _music_a

# -------------------------------------------------------
# Public API
# -------------------------------------------------------

## Play a sound effect by name. Name must exist in sfx_library.
func play_sfx(sound_name: String, volume_db: float = 0.0) -> void:
    if not sfx_library.has(sound_name):
        push_warning("AudioManager: unknown SFX '%s'" % sound_name)
        return

    var player := _get_sfx_player()
    player.stream = sfx_library[sound_name]
    player.volume_db = volume_db
    player.play()

## Play music by name, crossfading from the current track.
func play_music(track_name: String, fade_time: float = 1.0) -> void:
    if not music_library.has(track_name):
        push_warning("AudioManager: unknown music '%s'" % track_name)
        return

    # Don't restart if already playing this track
    var stream := music_library[track_name]
    if _active_music_player.stream == stream and _active_music_player.playing:
        return

    var incoming := _music_b if _active_music_player == _music_a else _music_a
    incoming.stream = stream
    incoming.volume_db = -80.0
    incoming.play()

    var tween := create_tween().set_parallel()
    tween.tween_property(_active_music_player, "volume_db", -80.0, fade_time)
    tween.tween_property(incoming, "volume_db", 0.0, fade_time)

    _active_music_player = incoming

func stop_music(fade_time: float = 1.0) -> void:
    var tween := create_tween()
    tween.tween_property(_active_music_player, "volume_db", -80.0, fade_time)
    await tween.finished
    _active_music_player.stop()

func set_sfx_volume(linear: float) -> void:
    AudioServer.set_bus_volume_db(sfx_bus_index, linear_to_db(linear))

func set_music_volume(linear: float) -> void:
    AudioServer.set_bus_volume_db(music_bus_index, linear_to_db(linear))

# -------------------------------------------------------
# Private helpers
# -------------------------------------------------------

func _get_sfx_player() -> AudioStreamPlayer:
    # Round-robin: grab next in pool, steal if still playing (oldest sound)
    _sfx_pool_index = (_sfx_pool_index + 1) % POOL_SIZE
    return _sfx_pool[_sfx_pool_index]
```

In your main game scene or autoload, populate the libraries at startup:

```gdscript
# In GameManager._ready() or a dedicated preloader scene:
func _ready() -> void:
    # Preload SFX
    AudioManager.sfx_library = {
        "jump":     preload("res://audio/sfx/jump.wav"),
        "land":     preload("res://audio/sfx/land.wav"),
        "hit":      preload("res://audio/sfx/hit.wav"),
        "pickup":   preload("res://audio/sfx/pickup.wav"),
        "death":    preload("res://audio/sfx/death.wav"),
        "ui_click": preload("res://audio/sfx/ui_click.wav"),
    }
    # Preload music
    AudioManager.music_library = {
        "menu":  preload("res://audio/music/menu.ogg"),
        "game":  preload("res://audio/music/game.ogg"),
        "boss":  preload("res://audio/music/boss.ogg"),
    }

# Then anywhere in the project:
AudioManager.play_sfx("jump")
AudioManager.play_music("game", 1.5)   # 1.5-second crossfade
```

:::callout-pitfall[Watch Out For]
- **Missing audio buses.** The AudioManager assumes "SFX" and "Music" buses exist in the Audio Bus Layout. Create them in **Audio → Audio Bus Layout** before using the autoload, or replace bus names with "Master".
- **Polyphony with long sounds.** The round-robin pool will cut off a long ambience sound if all 8 slots are in use. For ambient loops, give them their own dedicated AudioStreamPlayer outside the pool.
- **Crossfade to the same track.** The guard `if _active_music_player.stream == stream` prevents restarting music that's already playing, but it won't work if you preload the same stream into a new object. Use a track name string as the key, not the stream reference.
:::

### HUD Template

Every jam game needs a HUD. Here is a minimal scene structure to start from. All of it lives in a `CanvasLayer` so it stays fixed on-screen regardless of camera movement.

```gdscript
# Scene tree:
# CanvasLayer (HUD)
#   └─ Control (full rect)
#       ├─ HBoxContainer (top-left)
#       │   ├─ Label (score_label)
#       │   └─ Label (lives_label)
#       └─ Panel (game_over_panel)  ← visible = false initially
#           ├─ Label (final_score)
#           ├─ Label (high_score_label)
#           └─ Button (restart_button)

# HUD.gd
extends CanvasLayer

@onready var score_label: Label = $Control/HBoxContainer/ScoreLabel
@onready var lives_label: Label = $Control/HBoxContainer/LivesLabel
@onready var game_over_panel: Panel = $Control/GameOverPanel
@onready var final_score: Label = $Control/GameOverPanel/FinalScore
@onready var hs_label: Label = $Control/GameOverPanel/HighScoreLabel

func _ready() -> void:
    game_over_panel.visible = false
    GameManager.score_changed.connect(func(s): score_label.text = "SCORE %d" % s)
    GameManager.lives_changed.connect(func(l): lives_label.text = "♥ × %d" % l)
    GameManager.game_over.connect(_show_game_over)
    # Initialize
    score_label.text = "SCORE 0"
    lives_label.text = "♥ × %d" % GameManager.lives

func _show_game_over() -> void:
    game_over_panel.visible = true
    final_score.text = "Score: %d" % GameManager.score
    hs_label.text    = "Best:  %d" % GameManager.high_score

func _on_restart_button_pressed() -> void:
    GameManager.restart()
```

## 5 · Adding Juice in an Hour

"Juice" is the game development term for the collection of small feedback effects that make a game feel alive and satisfying. A juicy game is one where every action has a visible and audible response. You'd be amazed how much a game's perceived quality improves from two hours of juice work.

The following are the highest-ROI juice effects ranked by impact-per-minute-of-implementation. Each can be added to your jam template in under 20 minutes.

| Effect | Implementation Time | Perceived Impact | How To |
| --- | --- | --- | --- |
| Screen shake | ~15 min | Very high | Tween camera offset on hit/explosion |
| Hit flash | ~10 min | High | Tween `modulate` to white then back |
| Death particles | ~20 min | High | CPUParticles2D, burst on death |
| Sound on every action | ~30 min total | Very high | `AudioManager.play_sfx()` calls |
| Score pop text | ~20 min | Medium-high | Label that floats up and fades |
| Squash & stretch | ~15 min | Medium | Tween `scale` on jump/land |
| Background scroll | ~10 min | Medium | Infinite parallax with two copies |
| Enemy anticipation | ~10 min | Medium | Brief delay + scale pulse before attack |

### Screen Shake

Screen shake communicates impact. Every explosion, hit, and death should shake the camera. Here is a reusable implementation you can drop into your Camera2D:

```gdscript
# Camera2D with built-in screen shake
extends Camera2D

var _shake_duration := 0.0
var _shake_intensity := 0.0

func shake(duration: float, intensity: float) -> void:
    _shake_duration = duration
    _shake_intensity = intensity

func _process(delta: float) -> void:
    if _shake_duration > 0:
        _shake_duration -= delta
        offset = Vector2(
            randf_range(-_shake_intensity, _shake_intensity),
            randf_range(-_shake_intensity, _shake_intensity)
        )
    else:
        offset = Vector2.ZERO

# Usage from any scene (assuming the camera is accessible):
# $Camera2D.shake(0.25, 8.0)   # quarter second, 8px intensity
# Or if it's in the scene tree, use a group:
# get_tree().call_group("camera", "shake", 0.25, 8.0)
```

### Score Pop Text

Floating score text that rises and fades gives players immediate feedback on what scored points and how much. This is a common pattern using a Label that animates itself and then self-destructs:

```gdscript
# ScorePopup.gd — attach to a Label node
extends Label

func _ready() -> void:
    # Animate: float up 40px over 0.8s while fading out
    var tween := create_tween().set_parallel()
    tween.tween_property(self, "position:y", position.y - 40.0, 0.8)
    tween.tween_property(self, "modulate:a", 0.0, 0.8)
    tween.chain().tween_callback(queue_free)

# To spawn one:
# var popup := preload("res://ui/score_popup.tscn").instantiate()
# popup.text = "+%d" % points
# popup.position = enemy.global_position
# get_tree().current_scene.add_child(popup)
```

## 6 · Common Jam Mistakes

These are not hypothetical — they are real mistakes that appear in jam postmortems repeatedly. Each one is preventable if you know to look for it.

### Mistake 1: Building Systems Before Mechanics

A save system for a game that hasn't proven its core mechanic yet is wasted work. Inventory systems, achievement trackers, and settings screens can all wait until the last 12 hours if they're needed at all. Build the thing the player actually interacts with first.

### Mistake 2: Perfectionist Art Block

You don't need good art to have a good jam game. Use [Kenney's free asset packs](https://kenney.nl/assets) as placeholders. Use `ColorRect` nodes with flat colors as temporary sprites. Ship first, prettify later if time allows.

Even better: embrace the jam aesthetic. A game made entirely of colored rectangles with a consistent color palette can look intentional. *Thomas Was Alone* is a famous example of this.

### Mistake 3: Not Testing the Export

This is the most painful and most common mistake. You code all weekend, go to export Sunday morning, and discover: the web export is broken, a texture wasn't included, the GLES3 renderer crashes on the player's machine. Export at the start of day 2, not the end.

:::callout-warning[Export Test Protocol]
Do this at hour 22 (before sleep): export to web, upload to itch.io as private, open in a browser, play through the core loop. Fix any export errors before proceeding to the polish phase. Don't discover export bugs at hour 47.
:::

### Mistake 4: Unconnected Sounds

Silence in a game is far more damaging than placeholder sounds. At minimum, have a sound for: the player jumping (or primary action), taking damage, scoring a point, and dying. Royalty-free sounds are available from [freesound.org](https://freesound.org) and [Zapsplat](https://www.zapsplat.com). The AudioManager template above makes this a 5-minute task once you have the files.

### Mistake 5: The 3 AM Rewrite

It is 3 AM. You're tired. The movement code feels "wrong" and you decide to rewrite it. Don't. Sleep instead. Movement that feels wrong at 3 AM often feels fine at 10 AM. Rewrites at 3 AM take 3× as long and introduce new bugs. If you must change something, write down what needs changing and do it after sleep.

### Mistake 6: Forgetting the Theme

Judges care about theme adherence. At hour 40, read your game design document and your game jam theme again. If the connection isn't clear, add a text description in your itch.io page that explains the connection explicitly. A thin thematic connection explained in text scores better than no explanation at all.

## 7 · Submission Checklist

Print this checklist and work through it in the last two hours. Submit at least one hour before the deadline so technical issues don't cost you the submission.

| Category | Item | Notes |
| --- | --- | --- |
| **Export** | Web export tested in browser | Chrome and Firefox if possible |
| All audio files included | Check Project → Export → Resources |
| No "Missing Dependency" warnings | Check Godot's output on export |
| Game opens to a main menu or immediate gameplay | No editor-only startup scene |
| **itch.io Page** | Screenshot (at least one) | Cover image shows off best moment |
| How to play (controls listed) | Assume player has never played |
| Theme connection explained | 1–2 sentences is enough |
| **Game Content** | Win condition reachable | Play-test one full run |
| Game over / restart works | Test the death path specifically |
| No crash on normal play | 5 minutes of play without errors |
| **Credits** | Asset credits listed | Kenney, freesound.org, etc. |
| Team member names | Especially for jam ratings |

## Practice Problems

1. easy
 The jam theme is "Time Loop." Write a one-sentence MVP definition for a game about this theme. Include the player verb, core loop, and win/lose condition.
 Solution

 Sample answer: "The player must find and interact with three key objects in a 30-second loop; finding all three before the loop resets wins — running out of loops (5 total) loses." The exact answer will vary, but should have: a clear player action (interact with objects), a loop constraint (30-second timer), and explicit win/lose states (found all / used up loops).
2. easy
 Add a `combo_multiplier` variable to the `GameManager` above. It should multiply score added by `add_score()`, reset to 1 when `lose_life()` is called, and increment by 0.5 each time `add_score()` is called without `lose_life()` in between (capped at 4.0).

   ::::solution[Solution]
   ```gdscript
   var combo_multiplier: float = 1.0

   func add_score(points: int) -> void:
       score += int(points * combo_multiplier)
       combo_multiplier = min(combo_multiplier + 0.5, 4.0)
       if score > high_score:
           high_score = score
           _save_high_score()
       score_changed.emit(score)

   func lose_life() -> void:
       combo_multiplier = 1.0   # reset combo
       lives -= 1
       lives_changed.emit(lives)
       if lives <= 0:
           trigger_game_over()
   ```
   ::::

3. standard
 Modify `SceneLoader.goto()` so it accepts an optional `Color` parameter for the fade color (default black). This allows a "white flash" transition by calling `SceneLoader.goto("res://game.tscn", 0.2, Color.WHITE)`.

   ::::solution[Solution]
   ```gdscript
   func goto(scene_path: String, fade_time: float = 0.3,
             fade_color: Color = Color.BLACK) -> void:
       if _is_transitioning:
           return
       _is_transitioning = true
       # Set the color (keep alpha at 0 initially)
       _overlay.color = Color(fade_color.r, fade_color.g, fade_color.b, 0.0)
       transition_started.emit()

       var tween := create_tween()
       tween.tween_property(_overlay, "color:a", 1.0, fade_time)
       await tween.finished

       get_tree().change_scene_to_file.call_deferred(scene_path)
       await get_tree().process_frame
       await get_tree().process_frame

       tween = create_tween()
       tween.tween_property(_overlay, "color:a", 0.0, fade_time)
       await tween.finished

       _is_transitioning = false
       transition_finished.emit()
   ```
   ::::

4. standard
 The `AudioManager._get_sfx_player()` uses a round-robin that steals the oldest slot. Modify it so it prefers idle players before stealing. Return the first idle player found; only fall back to round-robin if all players are busy.

   ::::solution[Solution]
   ```gdscript
   func _get_sfx_player() -> AudioStreamPlayer:
       # First pass: find an idle player
       for player in _sfx_pool:
           if not player.playing:
               return player
       # All busy — steal the next in round-robin order
       _sfx_pool_index = (_sfx_pool_index + 1) % POOL_SIZE
       return _sfx_pool[_sfx_pool_index]
   ```

   This avoids cutting off longer sound effects when the pool isn't actually full.
   ::::

5. standard
 Write a `ScorePopup` scene setup that also scales up briefly before floating away (scale 1.0 → 1.4 → 1.0, then float up and fade). This creates a "pop" feel. Use two sequential Tweens or a single Tween with chained steps.

   ::::solution[Solution]
   ```gdscript
   func _ready() -> void:
       # Step 1: scale pop (fast)
       var tween := create_tween()
       tween.tween_property(self, "scale", Vector2(1.4, 1.4), 0.08)
       tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.08)
       # Step 2: float up and fade
       tween.set_parallel(true)
       tween.tween_property(self, "position:y", position.y - 40.0, 0.7)
       tween.tween_property(self, "modulate:a", 0.0, 0.7)
       tween.chain().tween_callback(queue_free)
   ```
   ::::

6. challenge
 Extend `GameManager` with a `save_progress(slot: int)` and `load_progress(slot: int)` using Godot's `FileAccess`. The saved data should include: score, high\_score, lives, and a custom `unlocked_levels: Array[bool]`. Use JSON serialization so the file is human-readable.

   ::::solution[Solution]
   ```gdscript
   var unlocked_levels: Array[bool] = []

   func save_progress(slot: int) -> void:
       var data := {
           "score": score,
           "high_score": high_score,
           "lives": lives,
           "unlocked_levels": Array(unlocked_levels),  # convert typed array
       }
       var path := "user://save_slot_%d.json" % slot
       var f := FileAccess.open(path, FileAccess.WRITE)
       if f == null:
           push_error("Could not open save file: %s" % path)
           return
       f.store_string(JSON.stringify(data, "\t"))
       f.close()

   func load_progress(slot: int) -> bool:
       var path := "user://save_slot_%d.json" % slot
       if not FileAccess.file_exists(path):
           return false
       var f := FileAccess.open(path, FileAccess.READ)
       if f == null:
           return false
       var raw := f.get_as_text()
       f.close()

       var result := JSON.parse_string(raw)
       if result == null or not result is Dictionary:
           push_error("Corrupt save file at %s" % path)
           return false

       score   = result.get("score",      0)
       high_score = result.get("high_score", 0)
       lives   = result.get("lives",      STARTING_LIVES)
       var ul: Array = result.get("unlocked_levels", [])
       unlocked_levels.assign(ul)

       score_changed.emit(score)
       lives_changed.emit(lives)
       return true
   ```
   ::::

## Chapter Summary

| Concept | Key Rule |
| --- | --- |
| MVP definition | One sentence: player verb + core loop + win/lose condition |
| Cut List | Every feature not in the MVP sentence goes on the Cut List first |
| Schedule | Validate mechanic first (hours 2–10), then build content, then polish |
| GameManager | Singleton for score, lives, state; uses signals to notify HUD |
| SceneLoader | Wraps `change_scene_to_file` in a tween fade; single `goto()` call |
| AudioManager | Pool of 8 SFX players + two music players for crossfade |
| Juice priority | Screen shake → sounds → hit flash → particles → score popups |
| Export test | Web export at hour 22, before sleep, before polish phase |
| Submission | Submit at hour 46, not 47:58 — export failures take time to debug |
