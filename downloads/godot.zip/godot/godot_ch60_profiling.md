---
title: "Profiling, Debugging & the Remote Inspector"
source: "godot_ch60_profiling.html"
---

Part X · Chapter 60

# Profiling, Debugging & the Remote Inspector

Estimated study time: 75 min · Godot 4.x · GDScript

## Chapter Overview

Writing code that *works* and code that *runs fast* are different skills.
 This chapter teaches you to use Godot's built-in diagnostic tools: the
 **Debugger** (breakpoints, call stack, variable watches),
 the **Remote Inspector** (inspect and edit live scene nodes at runtime),
 the **Profiler** (per-frame CPU timing broken down by function),
 and the **Performance Monitors** (GPU, physics, memory counters).
 You'll also learn structured `print` strategies and how to add your own
 custom performance monitors.

:::callout-tip[Prerequisites]
Comfortable with GDScript, nodes, and the Godot editor. No prior profiling experience needed.
:::

### The Diagnostic Toolbox

| Tool | Location | Best for |
| --- | --- | --- |
| Debugger → Debugger tab | Bottom panel | Breakpoints, call stack, variable watches, error log |
| Debugger → Profiler tab | Bottom panel | Per-function CPU time, frame graph |
| Debugger → Monitors tab | Bottom panel | Live GPU/physics/memory graphs |
| Remote Inspector | Scene dock → Remote | Live node tree, property edits at runtime |
| Performance singleton | GDScript API | Read built-in counters in code; add custom ones |
| print / push\_warning / push\_error | Output panel | Quick state logging without stopping execution |

Godot Diagnostic Toolbox — where each tool lives

Bottom Panel → Debugger

Debugger tab

• Breakpoints

• Call stack

• Variable watches

• Error log

step through code

Profiler tab

• Frame time graph

• Function timing

• Self vs total ms

• Call counts

find CPU bottlenecks

Monitors tab

• FPS / frame ms

• Draw calls

• Physics bodies

• Memory (static)

live GPU/memory graphs

Other Tools

Remote Inspector

Scene dock → Remote tab

live node tree + property edits

print / push\_warning

Output panel

quick logging, no breakpoints

Start with Monitors for the big picture → Profiler to pinpoint → Debugger to inspect state

All diagnostic tools are in the **bottom Debugger panel** (three tabs) plus the Scene dock's Remote mode. Use Monitors to spot the symptom, Profiler to find the cause, Debugger to confirm the fix.

## The Debugger Panel

:::callout-intuition[Intuition]
The Debugger is a

time machine

: you set a breakpoint, and when execution hits it
  the game freezes while you inspect exactly what every variable holds and how you got there.
  Instead of sprinkling

print()

calls and re-running repeatedly, you stop once
  and look at everything.
:::

### Breakpoints & the Call Stack

Click the grey gutter to the left of any line number in a GDScript file to add a red dot
 (breakpoint). When the game runs and reaches that line, execution pauses. You then see:

- **Call Stack** — the chain of function calls from the entry point to the current line. Click any frame to jump to that source file and line.
- **Local Variables** — every variable in scope for the selected stack frame, with live values.
- **Members** — all exported and non-exported member variables of the current object (`self`).
- **Globals** — autoload singletons and constants visible globally.

#### Debugger Toolbar Buttons

| Button | Shortcut | Effect |
| --- | --- | --- |
| Continue (▶) | F5 | Resume execution until the next breakpoint or end |
| Step Over | F10 | Execute the current line, staying in the same function |
| Step Into | F11 | Step into any function call on the current line |
| Step Out | Shift+F11 | Run until the current function returns |
| Break (⏸) | F8 | Pause at whatever line is currently executing (no breakpoint needed) |

:::callout-tip[Tip — Conditional Breakpoints]
Right-click an existing breakpoint dot and choose

Edit Breakpoint

to add a
  condition like

health < 0

. The debugger only pauses when the condition is true —
  far less tedious than hitting the same breakpoint 200 times per second.
:::

### Variable Watches & Expression Evaluation

While paused, the **Watches** sub-tab lets you type any valid GDScript expression
 and see its current value — e.g., `velocity.length()`, `enemies.size()`,
 or even a function call like `get_path()`. Watches re-evaluate after every Step,
 so you can track an expression across multiple steps without switching tabs.

The **Errors** sub-tab collects every `push_error()`, null-object
 access, and type-mismatch warning printed during the session, each with a clickable link to
 the offending source line.

:::callout-pitfall[Common Pitfall — Release Exports Remove Debug Info]
Breakpoints only work in

debug

exports (the default from the editor).
  If you export with "Release" mode, GDScript is compiled without line information and
  the debugger cannot stop. Always profile and debug in debug mode first.
:::

## The Remote Inspector

:::callout-intuition[Intuition]
The Remote Inspector is the Scene dock but connected to the

running game

.
  You see every node instantiated at runtime (including dynamically spawned ones),
  click any node, and edit its properties live — no restart needed.
  It's the fastest way to answer "why does my CharacterBody end up at the wrong position?"
:::

### Accessing the Remote Scene Tree

Start the game (F5 or the Play button). In the editor, look at the top of the
 **Scene** dock — there are now two tabs: *Local* and *Remote*.
 Click **Remote** to see the live node tree.

- Click any node in the Remote tree — the **Inspector** panel on the right shows its live properties.
- Edit a property value directly in the Inspector. The change takes effect immediately in the running game.
- Nodes are colour-coded: *yellow* = script attached, *green* = editor-visible, *grey* = hidden.
- Dynamically instantiated nodes appear as soon as they enter the tree — you can catch transient objects mid-lifetime.

#### What You Can Do with the Remote Inspector

| Task | How |
| --- | --- |
| Find where a node is | Select it → Inspector shows `position` / `global_position` live |
| Adjust a value without restarting | Edit any exported or built-in property in the Inspector |
| Check if a node exists at runtime | Search the Remote tree by name with Ctrl+F |
| Count dynamic instances | Expand the parent node and count children |
| Read a script variable | Variables exported with `@export` appear; non-exported ones do not — use the Debugger for those |

:::callout-warning[Note — Non-Exported Variables]
Only

@export

variables appear in the Remote Inspector. To inspect a non-exported
  member variable at runtime, use either a debugger breakpoint + Watches, or temporarily add

@export

during debugging.
:::

### Live Scene Editing (Edit in Live Mode)

Godot 4 also supports **Live Scene Editing** (enable from *Debug → Live Scene
 Editing*). With this on, edits you make to the *Local* scene tree — adding a node,
 changing a value in the editor Inspector — are propagated to the running game in real time.
 This is separate from the Remote Inspector: the Remote Inspector reads from the game; Live
 Scene Editing writes *to* the game from the editor.

## The Profiler

:::callout-intuition[Intuition]
The Profiler tells you

where time goes

each frame. Without it, optimization
  is guesswork — you tweak random code hoping it helps. With it, you see a ranked list of
  functions and exactly how many milliseconds each consumed. Fix the top offender first;
  everything else is premature optimization.
:::

Profiler — Frame Time Graph (schematic)

33ms

16ms

0ms

60fps

← frames scroll left (time) →

stutter spike!

GDScript heavy

physics heavy

Script (GDScript)

Physics

Visual / Server

16ms / 60fps target

The Profiler frame graph stacks Script, Physics, and Visual time per frame. A bar crossing the 16ms red line means that frame dropped below 60fps. Click a tall bar to freeze it — the function table below updates to show exactly which functions consumed the most time.

### Reading the Frame Time Graph

Open the Debugger panel → **Profiler** tab → click **Start**.
 A scrolling graph appears showing three stacked layers per frame:

| Colour | Category | Meaning |
| --- | --- | --- |
| Blue | Script (GDScript) | Time in your GDScript functions this frame |
| Teal | Physics | Physics step time (collision detection, move\_and\_slide) |
| Violet | Visual / Server | RenderingServer draw call processing |
| Yellow | Idle | Editor overhead / vsync wait (ignore in game builds) |

The horizontal axis is time (frames scroll left). The vertical axis is milliseconds.
 A stable 60 fps requires each frame under **16.67 ms**; 30 fps under 33.33 ms.
 Tall spikes indicate hitches.

### Function Timing Table

Below the graph, a sortable table lists every function that ran during the profiled window:

| Column | Meaning |
| --- | --- |
| Function | Fully-qualified name: `Node::_process`, `MyClass::do_thing` |
| Calls | How many times it was called in the selected frame window |
| Total (ms) | Total time including all sub-calls made by this function |
| Self (ms) | Time spent *only* in this function's own code (excluding callees) |
| % Total | Fraction of total frame time consumed by this function |

Sort by **Self (ms)** to find functions doing the most work themselves.
 Sort by **Total (ms)** to find functions that trigger expensive subtrees.
 Click a row to see a per-frame breakdown on the right.

:::callout-tip[Workflow — Profile Before You Optimize]
1. Run the game in a representative scenario (busy scene, many enemies, etc.).
2. Click **Start** in the Profiler. Let it run for ~5 seconds.
3. Click **Stop**. Sort the table by *Self (ms)*.
4. The top entry is your bottleneck. Fix it first, then profile again to confirm improvement.
5. Repeat until you hit your target frame budget.
:::

:::callout-pitfall[Watch Out For]
- **Profiling overhead inflates times** — the profiler itself costs a few ms. Compare relative costs, not absolute numbers to production.
- **GDScript overhead hides in "builtin"** — if your function calls many built-ins they show as callee time. Check both Total and Self.
- **Don't profile in the editor with debug tools open** — close the filesystem dock, asset library, etc. to reduce noise.
:::

## Performance Monitors

The **Monitors** tab of the Debugger shows live scrolling graphs of dozens of
 engine counters. Unlike the Profiler (which records and replays), Monitors are always live
 while the game runs. Tick the checkbox next to any counter to add it to the graph.

### Key Monitors to Know

| Counter | Category | What to watch for |
| --- | --- | --- |
| FPS | Time | Should be stable at your target. Drops = hitches. |
| Process / Physics Time (ms) | Time | Separate CPU cost of \_process vs \_physics\_process per frame |
| Draw Calls | Render | Each draw call has CPU overhead. Target <1000 for mobile. |
| Objects in Frame | Render | Visible renderable objects. Use VisibleOnScreenNotifier to cull. |
| Static Memory / Dynamic Memory | Memory | Watch for growth over time (memory leaks) |
| Objects | Object | Total live Objects in the engine. Growth = leak risk. |
| Resources | Object | Loaded resources. Should stabilize, not grow unbounded. |
| Physics 2D / 3D — Active Objects | Physics | Bodies currently being simulated. Sleeping bodies are cheaper. |
| Video Memory | Render | VRAM used. Exceeding GPU VRAM causes severe stuttering. |

### Reading Performance Counters in Code

The **Performance** singleton lets you read any of these counters directly
 in GDScript — useful for in-game FPS displays or automated performance tests:

```gdscript
func _process(_delta: float) -> void:
    var fps  := Performance.get_monitor(Performance.TIME_FPS)
    var draw := Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
    var mem  := Performance.get_monitor(Performance.OBJECT_COUNT)
    fps_label.text  = "FPS: %.0f"  % fps
    draw_label.text = "Draw: %.0f" % draw
    mem_label.text  = "Obj: %.0f"  % mem
```

### Custom Performance Monitors

You can register your own counters so they appear in the Monitors tab alongside built-ins.
 This is useful for domain-specific metrics like "enemies alive", "pathfinding calls/s",
 or "bullets in flight".

```gdscript
## autoload: PerformanceTrackers.gd
extends Node

var _enemies_alive := 0

func _ready() -> void:
    # Register custom monitor — shows up in Monitors tab
    Performance.add_custom_monitor(
        "Game/enemies_alive",       # category/name shown in UI
        Callable(self, "_get_enemies_alive")
    )

func _get_enemies_alive() -> float:
    return float(_enemies_alive)

func register_enemy() -> void:
    _enemies_alive += 1

func unregister_enemy() -> void:
    _enemies_alive = max(0, _enemies_alive - 1)
```

In your enemy script call `PerformanceTrackers.register_enemy()` in
 `_ready()` and `PerformanceTrackers.unregister_enemy()` in the death
 handler. The counter appears live in the Monitors graph.

:::callout-tip[Tip — Monitor Only in Debug Builds]
Wrap registration in

if OS.is\_debug\_build():

so the overhead disappears in
  release exports:

```gdscript
func _ready() -> void:
    if OS.is_debug_build():
        Performance.add_custom_monitor("Game/enemies_alive",
            Callable(self, "_get_enemies_alive"))
```
:::

## Print Functions & Structured Logging

Breakpoints are precise but slow to set up. Sometimes you just need a quick value dump.
 Godot provides several print functions — each with different severity and formatting:

| Function | Output panel colour | Use when |
| --- | --- | --- |
| `print()` | White | General-purpose value logging |
| `print_rich()` | Coloured (BBCode) | Formatted output with `[color=red]text[/color]` etc. |
| `push_warning("msg")` | Yellow | Non-fatal conditions — also appears in Errors tab |
| `push_error("msg")` | Red | Serious errors — also appears in Errors tab with stack trace |
| `printerr()` | Red (stderr) | Errors that must appear even when Output is hidden |
| `print_verbose()` | White (suppressed) | Spammy detail — only shows when `--verbose` flag passed |
| `assert(condition, "msg")` | Red (crash in debug) | Invariants that must always hold — stripped in release |

### Structured Debug Logging Pattern

Instead of scattering raw `print()` calls, use a thin wrapper that can be
 toggled off globally:

```gdscript
## autoload: Log.gd
extends Node

## Set to false before shipping to silence all debug output.
@export var enabled := true

enum Level { VERBOSE, INFO, WARN, ERROR }
var min_level: Level = Level.INFO

func v(msg: String, ctx := "") -> void:
    _log(Level.VERBOSE, msg, ctx)

func i(msg: String, ctx := "") -> void:
    _log(Level.INFO, msg, ctx)

func w(msg: String, ctx := "") -> void:
    _log(Level.WARN, msg, ctx)

func e(msg: String, ctx := "") -> void:
    _log(Level.ERROR, msg, ctx)

func _log(level: Level, msg: String, ctx: String) -> void:
    if not enabled or level < min_level: return
    var prefix := "[%s] " % ctx if ctx else ""
    match level:
        Level.VERBOSE: print(prefix + msg)
        Level.INFO:    print_rich("[color=cyan]" + prefix + msg + "[/color]")
        Level.WARN:    push_warning(prefix + msg)
        Level.ERROR:   push_error(prefix + msg)
```

Call as `Log.i("Player spawned at %v" % position, "PlayerSpawn")`.
Set `Log.enabled = false` in your release autoload or export preset to silence
everything without touching individual files.

:::callout-pitfall[Watch Out For]
- **print() in \_process() wrecks performance** — printing 60+ times per second floods the Output panel and itself costs several ms per frame. Always guard with a condition or use the Debugger instead.
- **assert() is stripped in release** — never use it for user-facing validation. It's only for programmer invariants during development.
- **push\_error() doesn't stop execution** — unlike an exception, the script continues running after `push_error()`. To halt, pair it with `return` or `assert(false)`.
:::

## Worked Examples

### Example 1 — In-Game Debug Overlay

**Goal:** Display live FPS, draw call count, and a custom "bullets in flight"
 counter as an on-screen overlay in debug builds only.

```gdscript
## DebugOverlay.gd  (attach to a CanvasLayer > VBoxContainer > Label)
extends Label

var _bullets_in_flight := 0

func _ready() -> void:
    # Only visible in debug builds
    visible = OS.is_debug_build()
    if OS.is_debug_build():
        Performance.add_custom_monitor(
            "Game/bullets_in_flight",
            Callable(self, "_get_bullets")
        )

func _get_bullets() -> float:
    return float(_bullets_in_flight)

func register_bullet()   -> void: _bullets_in_flight += 1
func unregister_bullet() -> void: _bullets_in_flight = max(0, _bullets_in_flight - 1)

func _process(_delta: float) -> void:
    if not visible: return
    var fps  := Performance.get_monitor(Performance.TIME_FPS)
    var draw := Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
    text = "FPS: %d\nDraw: %d\nBullets: %d" % [fps, draw, _bullets_in_flight]
```

Each bullet script calls `DebugOverlay.register_bullet()` in `_ready()`
 and `DebugOverlay.unregister_bullet()` in `queue_free()`.
 The overlay automatically hides in release builds.

### Example 2 — Finding a Stutter with the Profiler

**Scenario:** The game runs at 60 fps normally but stutters to 20 fps every few
 seconds. You suspect a pathfinding call.

1. Open Debugger → Profiler → click **Start**.
2. Play until you see a stutter spike in the frame graph (tall blue bar).
3. Click the spike bar. The function table updates to show only that frame's costs.
4. Sort by *Self (ms)*. You see `EnemyAI::_rebuild_paths` consuming 28 ms.
5. Click Stop. Open `enemy_ai.gd` and find `_rebuild_paths()`.
6. It calls `NavigationServer2D.map_get_path()` for every enemy every 0.1 s. Switch to staggered per-enemy timers so no two enemies re-path on the same frame.
7. Profile again — stutter gone, spike now spread evenly across frames.

:::callout-key[Key Takeaway]
The profiler told you

exactly

which function and which frame to fix.
  Without it you might have refactored unrelated code for hours.
:::

### Example 3 — Detecting a Memory Leak

**Scenario:** You notice the game slows down over time. You suspect objects
 are not being freed.

```gdscript
## LeakDetector.gd  (autoload)
extends Node

var _baseline_objects := 0

func _ready() -> void:
    # Record object count 2 seconds after launch (let things settle)
    await get_tree().create_timer(2.0).timeout
    _baseline_objects = int(Performance.get_monitor(Performance.OBJECT_COUNT))
    Log.i("Baseline objects: %d" % _baseline_objects, "LeakDetector")

func check_leak() -> void:
    var current := int(Performance.get_monitor(Performance.OBJECT_COUNT))
    var delta   := current - _baseline_objects
    if delta > 50:
        push_warning("Possible leak: %d extra objects since baseline" % delta)
```

Call `LeakDetector.check_leak()` from a timer every 10 s.
 When a warning appears, switch to the Monitors tab and watch the *Objects*
 graph — if it grows monotonically, find the node that is `add_child()`-ing
 without ever calling `queue_free()`.

### Example 4 — Using assert() for Invariant Checking

**Goal:** Crash loudly in development if a precondition is violated, but
 cause no overhead in release builds.

```gdscript
## item_database.gd
func get_item(id: int) -> ItemResource:
    assert(id >= 0, "Item ID must be non-negative (got %d)" % id)
    assert(id < _items.size(), "Item ID %d out of range (max %d)" % [id, _items.size() - 1])
    return _items[id]

## health_component.gd
func take_damage(amount: int) -> void:
    assert(amount >= 0, "Damage must be non-negative — use heal() for positive changes")
    health = max(0, health - amount)
    health_changed.emit(health, max_health)
    if health == 0:
        died.emit()
```

In a debug build these assert calls immediately crash with a clear message when violated.
 In a release export (*Export Presets → Release*) GDScript strips them entirely —
 zero runtime cost.

:::summary
### Chapter 60 — Quick Reference

| Tool | When to use | Key shortcut / access |
| --- | --- | --- |
| Breakpoint | Pause and inspect at a specific line | Click gutter; F10/F11 to step |
| Conditional Breakpoint | Pause only when expression is true | Right-click dot → Edit Breakpoint |
| Variable Watch | Track expression value across steps | Debugger → Watches tab |
| Remote Inspector | Inspect & edit live node properties | Scene dock → Remote (while running) |
| Live Scene Editing | Push editor edits to running game | Debug menu → Live Scene Editing |
| Profiler | Find the slow function | Debugger → Profiler → Start; sort Self (ms) |
| Monitors | Watch FPS, draw calls, memory live | Debugger → Monitors |
| Performance.get\_monitor() | Read counters in code (HUD) | `Performance.TIME_FPS` etc. |
| Performance.add\_custom\_monitor() | Add game-specific counter to Monitors | Callable returning float |
| push\_warning() / push\_error() | Log with stack trace to Errors tab | Yellow / Red in Output |
| assert() | Invariant checks — stripped in release | `assert(cond, "msg")` |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Breakpoints & Watches

You have a function `spawn_enemy(type: String) -> Enemy` that sometimes
 returns `null`. Describe step-by-step how you would use a breakpoint and
 variable watch to find the cause. What would you look at in the call stack and
 local variables panel?

::::solution[Solution]
1. Click the gutter next to the first line inside `spawn_enemy()` to add a breakpoint.
2. Run the game until the buggy case occurs — execution pauses at that line.
3. In the **Local Variables** panel, inspect `type` — is it the value you expect?
4. Add a Watch for the expression being returned (e.g., `enemy_scene.instantiate()`) and Step Over to see what it evaluates to.
5. In the **Call Stack**, click the caller frame to see what argument was passed for `type` — was an invalid string passed in?
6. Add a conditional breakpoint: right-click the dot → Edit → set condition `type == ""` to catch only the null-producing call.
::::
:::

:::problem{difficulty="easy"}
#### 2. Remote Inspector

A player character is visually stuck at position (0,0) at runtime even though your code
 sets a different starting position. How would you use the Remote Inspector to investigate
 without stopping the game?

::::solution[Solution]
1. Run the game (F5). Click the Scene dock → **Remote** tab.
2. Expand the tree and find the Player node.
3. Click it — the Inspector on the right shows live values including `position` and `global_position`.
4. Check if `global_position` is actually (0,0) or if the visual is something else (e.g., a child Camera or Sprite offset).
5. If position is correct but the sprite appears at (0,0), select the Sprite2D child and check its `offset` or whether it has a rogue `position` set on the node itself.
6. Try editing `position` directly in the Remote Inspector — if the character moves, your code initialization path is the problem; if not, check parent transforms.
::::
:::

:::problem{difficulty="standard"}
#### 3. Profiler Workflow

Your game runs at 55 fps instead of 60. Use the profiler to identify the bottleneck.
 Write out the exact steps and describe what numbers in the function table you would
 look at to decide which function to optimize first.

::::solution[Solution]
1. Open Debugger → Profiler. Click **Start**.
2. Play for ~10 seconds in a typical game scenario (not main menu).
3. Click **Stop**.
4. Sort the function table by **Self (ms)** descending.
5. The top entry is the function spending the most time in its own code. If it consumes e.g. 4 ms and your frame budget is 16.67 ms, that alone accounts for the shortfall.
6. Also check **Total (ms)** to see if a wrapper function is triggering many expensive callees.
7. Click the top entry to see its per-frame call count. If it's called 500 times per frame, the fix is likely caching rather than algorithmic change.
8. Optimize that one function, then profile again to confirm improvement before touching anything else.
::::
:::

:::problem{difficulty="standard"}
#### 4. Custom Performance Monitor

Create a custom monitor called `"Game/active_particles"` that tracks how many
 `GPUParticles2D` nodes are currently emitting. Register it in an autoload and
 update it from individual particle systems.

::::solution[Solution]
```gdscript
## ParticleTracker.gd  (autoload)
extends Node

var _count := 0

func _ready() -> void:
    if OS.is_debug_build():
        Performance.add_custom_monitor(
            "Game/active_particles",
            Callable(self, "_get_count")
        )

func _get_count() -> float:
    return float(_count)

func register()   -> void: _count += 1
func unregister() -> void: _count = max(0, _count - 1)
```

```gdscript
## In each GPUParticles2D script:
func _ready() -> void:
    ParticleTracker.register()
    emitting = true

func _on_finished() -> void:        # connect to the "finished" signal
    ParticleTracker.unregister()
    queue_free()
```

Open Debugger → Monitors → tick "Game/active\_particles" to see it live.
::::
:::

:::problem{difficulty="challenge"}
#### 5. Structured Logging & assert()

Extend the `Log` autoload from the chapter so that:
 (a) it writes all output to a file `user://debug.log` in addition to the Output panel,
 (b) `Log.e()` also calls `assert(false)` to crash immediately in debug builds,
 (c) file writing is skipped entirely in release builds.

::::solution[Solution]
```gdscript
## Log.gd  (autoload)
extends Node

var _file: FileAccess = null

func _ready() -> void:
    if OS.is_debug_build():
        _file = FileAccess.open("user://debug.log", FileAccess.WRITE)
        if _file:
            _file.store_string("=== Session started: %s ===\n" % Time.get_datetime_string_from_system())

func _notification(what: int) -> void:
    if what == NOTIFICATION_PREDELETE and _file:
        _file.close()

func _write(line: String) -> void:
    if _file:
        _file.store_string(line + "\n")
        _file.flush()  # ensure written even on crash

func i(msg: String, ctx := "") -> void:
    var line := "[INFO][%s] %s" % [ctx, msg]
    print_rich("[color=cyan]" + line + "[/color]")
    _write(line)

func w(msg: String, ctx := "") -> void:
    var line := "[WARN][%s] %s" % [ctx, msg]
    push_warning(line)
    _write(line)

func e(msg: String, ctx := "") -> void:
    var line := "[ERROR][%s] %s" % [ctx, msg]
    push_error(line)
    _write(line)
    assert(false, line)  # crash in debug, stripped in release
```

In release builds `_file` stays `null` (the `OS.is_debug_build()`
 guard skips file creation), all `_write()` calls are no-ops, and `assert(false)`
 is compiled away — so there is zero overhead in shipped builds.
::::
:::
