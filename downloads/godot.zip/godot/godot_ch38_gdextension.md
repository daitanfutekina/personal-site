---
title: "GDExtension & Native Code"
source: "godot_ch38_gdextension.html"
---

Part IV · Chapter 38

# GDExtension & Native Code

Prerequisite: Ch 3 (GDScript basics), C++ fundamentals · est. 90 min

## Overview

GDScript is expressive and fast enough for the overwhelming majority of
 game logic. There are times, however, when you need raw CPU throughput —
 a custom physics solver, a realtime procedural audio synthesiser, a Lua
 scripting integration, or a thin wrapper around a third-party C library.
 **GDExtension** is Godot 4's answer: compile C++ (or any
 language with a C ABI) into a shared library, and Godot loads it as
 first-class engine classes.

This chapter covers the complete workflow from an empty folder to a
 working GDExtension node usable from GDScript:

- The difference between GDExtension and source-level engine modules
- Setting up `godot-cpp` and the `SConstruct`
 build system
- The `.gdextension` resource descriptor Godot reads
- Writing a C++ class that extends a Godot node, binding properties,
 methods, and signals
- Overriding virtual methods (`_ready`,
 `_process`, `_physics_process`)
- Using the extension seamlessly from GDScript

## 1 · What is GDExtension?

### GDExtension vs. engine modules

Godot offers two paths for native code integration:

| Feature | GDExtension | Engine Module |
| --- | --- | --- |
| Requires recompiling Godot? | No — ships as `.dll` / `.so` / `.dylib` | Yes — must rebuild the whole editor |
| Distribution | Drop shared library into project | Custom editor build required |
| Editor integration | Full — editor reloads at startup | Full — baked into editor binary |
| API surface | godot-cpp binding (mirrors GDScript API) | Direct internal C++ engine classes |
| Suitable for | Third-party libraries, performance hotspots, plugins | Deep engine changes, new renderer features |

For most developers, GDExtension is the right choice. You keep
 standard Godot export templates and the resulting library travels with
 the project like any other asset.

### When to use native code

GDScript bytecode runs through an interpreter — it is fast, but not as
 fast as native code for tight inner loops. Reach for GDExtension when:

- You need sub-millisecond per-frame SIMD or bit-manipulation loops
 (pathfinding, voxel meshing, neural networks).
- You are wrapping a C/C++ library (SQLite, OpenCV, a physics SDK)
 that has no GDNative or GDExtension binding yet.
- You want to ship a reusable plugin on the Asset Library without
 exposing source code.

:::callout-tip[Tip]
Profile first. GDScript with `@tool` and typed variables
 is surprisingly quick; the bottleneck is almost always draw calls or
 physics, not script logic. Optimise GDScript before starting a C++
 port.
:::

## 2 · Project Setup

### The godot-cpp binding library

GDExtension communicates with Godot through a C ABI defined in
 `gdextension_interface.h`. Writing against that directly is
 tedious; instead, use the official **godot-cpp** repository,
 which provides a generated C++ wrapper matching the engine API.

Recommended folder structure:

```text
my_project/           ← Godot project root (project.godot lives here)
  bin/                ← compiled .dll / .so will land here
  src/                ← your C++ source files
  godot-cpp/          ← git submodule
  SConstruct          ← build script
```

Add godot-cpp as a submodule pinned to the same Godot minor version:

```bash
cd my_project
git submodule add https://github.com/godotengine/godot-cpp
cd godot-cpp
git checkout godot-4.6     # match your Godot version exactly
git submodule update --init
```

:::callout-warning[Warning]
The godot-cpp branch must match your Godot editor version down to the
 minor number (4.6.x). A mismatch produces undefined behaviour at
 runtime because the internal struct layouts differ.
:::

### SConstruct & build

GDExtension projects conventionally use **SCons** as their
 build system because godot-cpp ships its own
 `SConstruct` helper. A minimal root-level
 `SConstruct`:

# SConstruct
import os
env = SConscript("godot-cpp/SConstruct")

# Your source files
env.Append(CPPPATH=["src/"])
sources = Glob("src/\*.cpp")

# Output: bin/libmygame.

.

.so (or .dll / .dylib)
library = env.SharedLibrary(
    target="bin/libmygame{}{}".format(
        env["suffix"], env["SHLIBSUFFIX"]
    ),
    source=sources,
)
Default(library)

Build with:

```bash
scons platform=linux target=template_debug   # Linux debug
scons platform=windows target=template_debug # Windows debug
scons platform=macos target=template_debug   # macOS debug
```

For release exports add `target=template_release` and set
 `optimize=speed`. The compiled library lands in
 `bin/`.

### The .gdextension descriptor

Godot discovers native libraries through a
 `.gdextension` file placed anywhere inside the project.
 Create `my_project/bin/mygame.gdextension`:

```ini
[configuration]
entry_symbol = "gdextension_init"
compatibility_minimum = "4.3"
reloadable = true

[libraries]
linux.debug.x86_64     = "res://bin/libmygame.linux.template_debug.x86_64.so"
linux.release.x86_64   = "res://bin/libmygame.linux.template_release.x86_64.so"
windows.debug.x86_64   = "res://bin/libmygame.windows.template_debug.x86_64.dll"
windows.release.x86_64 = "res://bin/libmygame.windows.template_release.x86_64.dll"
macos.debug            = "res://bin/libmygame.macos.template_debug.framework"
macos.release          = "res://bin/libmygame.macos.template_release.framework"
```

:::callout-key[Key concept]
`entry_symbol` names the C function Godot calls on load.
 `compatibility_minimum` is the lowest Godot version that
 can run the extension. `reloadable = true` tells the
 editor to hot-reload the library when it detects a file change.
:::

## 3 · First Extension Class

We will build a simple `FastCounter` node that extends
 `Node`, exposes a `count` integer property, and
 emits a `count_changed` signal whenever the value changes.
 It is intentionally trivial so the boilerplate is clear.

### Header file

```cpp
// src/fast_counter.h
#pragma once
#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/core/class_db.hpp>

namespace godot {

class FastCounter : public Node {
    GDCLASS(FastCounter, Node)

private:
    int64_t _count = 0;

protected:
    static void _bind_methods();

public:
    void set_count(int64_t p_count);
    int64_t get_count() const;

    void increment(int64_t by = 1);
    void reset();
};

} // namespace godot
```

The `GDCLASS` macro does the heavy lifting: it injects the
 virtual method table, the `get_class_static()` helper, and
 the reflection glue that lets GDScript call into this class.

### Source file & \_bind\_methods

```cpp
// src/fast_counter.cpp
#include "fast_counter.h"
#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void FastCounter::_bind_methods() {
    // --- Properties ---
    ClassDB::bind_method(D_METHOD("set_count", "value"), &FastCounter::set_count);
    ClassDB::bind_method(D_METHOD("get_count"),          &FastCounter::get_count);
    ADD_PROPERTY(
        PropertyInfo(Variant::INT, "count"),
        "set_count", "get_count"
    );

    // --- Methods ---
    ClassDB::bind_method(D_METHOD("increment", "by"), &FastCounter::increment);
    ClassDB::bind_method(D_METHOD("reset"),            &FastCounter::reset);

    // --- Signals ---
    ADD_SIGNAL(MethodInfo("count_changed",
        PropertyInfo(Variant::INT, "new_value")));
}

// ----- Setter / Getter -----
void FastCounter::set_count(int64_t p_count) {
    if (_count == p_count) return;
    _count = p_count;
    emit_signal("count_changed", _count);
}

int64_t FastCounter::get_count() const {
    return _count;
}

// ----- Public methods -----
void FastCounter::increment(int64_t by) {
    set_count(_count + by);
}

void FastCounter::reset() {
    set_count(0);
}
```

:::callout-intuition[Intuition]
`_bind_methods()` is called *once* per class type at
 startup, not once per instance. Think of it as building a reflection
 table. After this runs, the editor inspector, GDScript calls, and the
 debugger all know about `count`, `increment`, and
 `count_changed` — exactly as if they were defined in
 GDScript.
:::

### register\_types — the entry point

Create one more pair of files that serve as the library's entry point:

```cpp
// src/register_types.h
#pragma once
#include <godot_cpp/core/class_db.hpp>
using namespace godot;
void gdextension_init(ModuleInitializationLevel p_level);
void gdextension_terminate(ModuleInitializationLevel p_level);
```

```cpp
// src/register_types.cpp
#include "register_types.h"
#include "fast_counter.h"
#include <godot_cpp/core/defs.hpp>
#include <godot_cpp/godot.hpp>

using namespace godot;

void gdextension_init(ModuleInitializationLevel p_level) {
    if (p_level != MODULE_INITIALIZATION_LEVEL_SCENE) return;
    GDREGISTER_CLASS(FastCounter);
}

void gdextension_terminate(ModuleInitializationLevel p_level) {
    // cleanup if needed
}

extern "C" {
GDExtensionBool GDE_EXPORT gdextension_library_init(
    GDExtensionInterfaceGetProcAddress p_get_proc_address,
    GDExtensionClassLibraryPtr p_library,
    GDExtensionInitialization *r_initialization)
{
    GDExtensionBinding::InitObject init_obj(
        p_get_proc_address, p_library, r_initialization);
    init_obj.register_initializer(gdextension_init);
    init_obj.register_terminator(gdextension_terminate);
    init_obj.set_minimum_library_initialization_level(
        MODULE_INITIALIZATION_LEVEL_SCENE);
    return init_obj.init();
}
}
```

The `MODULE_INITIALIZATION_LEVEL_SCENE` level means your
 classes are registered after Godot's core is ready but before any scene
 starts loading — the correct level for custom nodes.

## 4 · Properties & Signals

### ADD\_PROPERTY in depth

The `ADD_PROPERTY` macro associates a
 `PropertyInfo` struct with a setter/getter pair so the
 inspector, `set()`, and `get()` all work
 seamlessly.

```cpp
// Float property with a range hint
ADD_PROPERTY(
    PropertyInfo(Variant::FLOAT, "speed",
                 PROPERTY_HINT_RANGE, "0,1000,1"),
    "set_speed", "get_speed"
);

// Color property
ADD_PROPERTY(
    PropertyInfo(Variant::COLOR, "tint"),
    "set_tint", "get_tint"
);

// Enum property — hint_string lists the names
ADD_PROPERTY(
    PropertyInfo(Variant::INT, "difficulty",
                 PROPERTY_HINT_ENUM, "Easy,Normal,Hard"),
    "set_difficulty", "get_difficulty"
);
```

The hint string is the same format you would type in the
 `@export_range` or `@export_enum` annotation in
 GDScript. The mapping is straightforward once you know that
 `PROPERTY_HINT_RANGE` corresponds to
 `@export_range` and `PROPERTY_HINT_ENUM`
 corresponds to `@export_enum`.

### ADD\_SIGNAL & emit\_signal

Signals are declared in `_bind_methods()` with
 `ADD_SIGNAL` and fired with `emit_signal()` just
 as in GDScript. The `MethodInfo` constructor accepts
 the signal name followed by any number of `PropertyInfo`
 argument descriptors:

```cpp
// In _bind_methods():
ADD_SIGNAL(MethodInfo("health_changed",
    PropertyInfo(Variant::INT,   "old_health"),
    PropertyInfo(Variant::INT,   "new_health")));

ADD_SIGNAL(MethodInfo("died"));    // no arguments

// In the class body:
void MyNode::take_damage(int amount) {
    int old_hp = _health;
    _health = MAX(0, _health - amount);
    emit_signal("health_changed", old_hp, _health);
    if (_health == 0) emit_signal("died");
}
```

:::callout-connect[Connect]
GDScript code connects to these signals exactly as it would to any
 built-in node signal: `$MyNode.health_changed.connect(_on_hp)`.
 The signal is fully indistinguishable from engine-native signals at the
 GDScript layer.
:::

You can also group properties into named sections using
 `ADD_GROUP` and `ADD_SUBGROUP`, which affects how
 the inspector renders them:

```cpp
// In _bind_methods():
ADD_GROUP("Combat", "combat_");      // prefix filters which properties belong
ADD_PROPERTY(PropertyInfo(Variant::INT, "combat_damage"), ...);
ADD_PROPERTY(PropertyInfo(Variant::INT, "combat_armor"),  ...);
ADD_SUBGROUP("Resistance", "combat_res_");
ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "combat_res_fire"), ...);
```

## 5 · Virtual Methods

GDExtension classes override the same virtual methods you know from
 GDScript. In C++ you declare them in the header and override them
 with the `virtual … override` syntax.

### \_ready and \_process

```cpp
// Header additions:
virtual void _ready() override;
virtual void _process(double delta) override;
```

```cpp
// Source:
void FastCounter::_ready() {
    // Called when the node enters the scene tree for the first time.
    // Equivalent of func _ready() in GDScript.
    set_process(true);   // enable _process
}

void FastCounter::_process(double delta) {
    // Called every frame when set_process(true).
    // delta is in seconds (double, not float).
    _elapsed += delta;
}
```

:::callout-warning[Warning]
Do *not* call `set_process` inside a constructor.
 Node constructors run before the node is in the tree; call
 `set_process` inside `_ready()` instead, just
 as you would in GDScript.
:::

### \_physics\_process

```cpp
// Header:
virtual void _physics_process(double delta) override;

// Source:
void FastCounter::_physics_process(double delta) {
    // Runs at the fixed physics rate (default 60 Hz).
    // Enable with set_physics_process(true) in _ready().
    _physics_ticks += 1;
}
```

Other overridable methods follow the same pattern:

| Virtual method | GDScript equivalent | Enable with |
| --- | --- | --- |
| `_ready()` | `func _ready()` | automatic |
| `_process(double)` | `func _process(delta)` | `set_process(true)` |
| `_physics_process(double)` | `func _physics_process(delta)` | `set_physics_process(true)` |
| `_input(const Ref<InputEvent>&)` | `func _input(event)` | `set_process_input(true)` |
| `_unhandled_input(const Ref<InputEvent>&)` | `func _unhandled_input(event)` | `set_process_unhandled_input(true)` |
| `_notification(int)` | `func _notification(what)` | automatic |
| `_enter_tree()` | `func _enter_tree()` | automatic |
| `_exit_tree()` | `func _exit_tree()` | automatic |

To properly clean up resources override `_exit_tree()` or
 `_notification()` and check for
 `NOTIFICATION_PREDELETE`:

```cpp
void FastCounter::_notification(int p_what) {
    switch (p_what) {
        case NOTIFICATION_READY:
            set_process(true);
            break;
        case NOTIFICATION_PREDELETE:
            // Free any heap resources here.
            break;
        default:
            break;
    }
}
```

## 6 · Calling from GDScript

### Attaching as a node script

After building the library and placing `mygame.gdextension`
 in your project, restart the Godot editor. The
 `FastCounter` class appears in the *Add Child Node*
 dialog under the Node hierarchy, just like any built-in node.

You can also use it as a script-less node and attach a GDScript to
 drive it, or extend it entirely from GDScript:

```gdscript
# Extending a GDExtension class in GDScript
extends FastCounter

func _ready() -> void:
    super._ready()          # calls the C++ _ready
    count_changed.connect(_on_count_changed)
    increment(10)

func _on_count_changed(new_value: int) -> void:
    print("Count is now: ", new_value)
```

### GDScript interop patterns

All GDScript idioms work with GDExtension classes without modification:

```gdscript
@onready var _counter: FastCounter = $FastCounter

func _ready() -> void:
    # Property access (uses the C++ setter/getter)
    _counter.count = 100
    print(_counter.count)          # 100

    # Method call
    _counter.increment(5)
    print(_counter.count)          # 105

    # Signal connection
    _counter.count_changed.connect(func(v): print("new: ", v))

    # Typed checks work as expected
    print(_counter is FastCounter) # true
    print(_counter is Node)        # true (inheritance is respected)
```

:::callout-tip[Tip]
Type hints work in GDScript for GDExtension classes. Declare
 variables as `var x: FastCounter` and the language server
 will provide autocompletion for the C++-defined methods and
 properties.
:::

You can also call GDScript methods from C++ using the
 `call()` API on any `Object*`:

```cpp
// Calling a GDScript method from C++
Variant result = get_parent()->call("some_gdscript_method", arg1, arg2);
int score = (int)result;
```

And retrieve child nodes by name or type:

```cpp
// Typed get_node shorthand via godot-cpp helper
Label *lbl = get_node<Label>("UI/ScoreLabel");
if (lbl) lbl->set_text("Score: " + String::num_int64(_count));
```

:::callout-pitfall[Pitfall]
Do not store raw pointers to Godot objects as plain member variables.
 If the object is freed, the pointer becomes a dangling pointer and
 will crash the engine. Use `ObjectID` with
 `ObjectDB::get_instance(id)` for deferred lookups, or
 store the node path and resolve it each time you need it.
:::

### Serialisation — saving extension data

Properties registered with `ADD_PROPERTY` are automatically
 serialised into `.tscn` and `.tres` files by the
 editor. You don't need to write custom serialisation for exposed
 properties — Godot calls the getter on save and the setter on load,
 just as it does for built-in node properties.

For private data that must persist but should not be editable in the
 inspector, override `_get_property_list` and return
 entries with `PROPERTY_USAGE_STORAGE` only:

```cpp
void FastCounter::_get_property_list(List<PropertyInfo> *p_list) const {
    p_list->push_back(PropertyInfo(
        Variant::INT, "_internal_state",
        PROPERTY_HINT_NONE, "",
        PROPERTY_USAGE_STORAGE  // saved, but not shown in inspector
    ));
}

bool FastCounter::_get(const StringName &p_name, Variant &r_ret) const {
    if (p_name == "_internal_state") {
        r_ret = _some_private_field;
        return true;
    }
    return false;
}

bool FastCounter::_set(const StringName &p_name, const Variant &p_value) {
    if (p_name == "_internal_state") {
        _some_private_field = (int64_t)p_value;
        return true;
    }
    return false;
}
```

## Summary

GDExtension lets you write C++ classes that are indistinguishable from
 built-in Godot nodes at the GDScript layer. The workflow in brief:

1. Add `godot-cpp` as a submodule pinned to your Godot minor
 version and write a `SConstruct`.
2. Create a `.gdextension` descriptor that maps platform
 targets to compiled library paths.
3. Derive from a Godot class using `GDCLASS(MyClass, Base)`
 and implement `_bind_methods()` to register properties,
 methods, and signals with `ClassDB`.
4. Override virtual methods (`_ready`, `_process`,
 etc.) exactly as you would in GDScript.
5. Build with `scons`, restart the editor, and use the class
 from GDScript like any built-in node.

| Task | C++ API |
| --- | --- |
| Register property | `ADD_PROPERTY(PropertyInfo(…), "setter", "getter")` |
| Register method | `ClassDB::bind_method(D_METHOD("name", "arg"), &Class::method)` |
| Register signal | `ADD_SIGNAL(MethodInfo("name", PropertyInfo(…)))` |
| Fire a signal | `emit_signal("name", arg1, arg2)` |
| Enable \_process | `set_process(true)` inside `_ready()` |
| Get typed child | `get_node<Type>("Path")` |
| Call GDScript method | `node->call("method_name", args…)` |
| Register class | `GDREGISTER_CLASS(MyClass)` in `gdextension_init` |

## Mixed Practice

:::problem{difficulty="easy"}
**1. Explain the GDExtension loading sequence.**
 Describe, in order, the files Godot reads and the C function it
 calls when loading a GDExtension at editor startup. What does
 `MODULE_INITIALIZATION_LEVEL_SCENE` control?

::::solution[Solution]
**Solution:**

1. Godot scans the project for all `.gdextension`
 files.
2. For each descriptor it reads `[libraries]` to find
 the platform-specific shared library path
 (`.dll`, `.so`, etc.).
3. The OS dynamic linker loads the library. Godot then calls
 `gdextension_library_init` (named by
 `entry_symbol`).
4. Inside `gdextension_library_init`,
 `GDExtensionBinding::InitObject` is configured
 with initialiser/terminator callbacks and the minimum
 initialisation level.
5. Godot calls the initialiser at each level in sequence
 (CORE → SERVERS → SCENE → EDITOR).
 Using `MODULE_INITIALIZATION_LEVEL_SCENE` means
 the custom classes are registered after core systems are
 ready but before scenes load — the earliest safe point to
 add node types that scenes can reference.
::::
:::

:::problem{difficulty="easy"}
**2. What does GDCLASS do?**
 The macro `GDCLASS(FastCounter, Node)` appears in the
 class body. List at least three things this macro injects and
 explain why each is necessary.

::::solution[Solution]
**Solution:**

- **Virtual method table override** — injects a
 `get_class_static()` override so
 `is_class()` and `cast_to<>()`
 resolve to the correct type.
- **\_bind\_methods declaration** — declares a
 static `_bind_methods()` that ClassDB calls
 once to populate the reflection table (methods, properties,
 signals).
- **Variant conversion helpers** — generates the
 machinery needed to pack and unpack the class through the
 `Variant` type so it can be passed across the
 GDExtension C ABI boundary.
- **Parent chain wiring** — stores the parent
 class type so the Godot type system knows
 `FastCounter` inherits from `Node`,
 enabling `is Node` checks in GDScript.
::::
:::

:::problem{difficulty="standard"}
**3. Add a `max_count` property.**
 Extend the `FastCounter` class with a
 `max_count` integer property (default 100). When
 `increment()` would push `_count` past
 `_max_count`, clamp it and emit a new
 `reached_max` signal (no arguments). Write the
 complete header additions and the updated
 `_bind_methods()` and `increment()`.

::::solution[Solution]
```cpp
// Header additions (inside FastCounter):
private:
    int64_t _max_count = 100;

public:
    void set_max_count(int64_t v);
    int64_t get_max_count() const;

// _bind_methods additions:
ClassDB::bind_method(D_METHOD("set_max_count","v"), &FastCounter::set_max_count);
ClassDB::bind_method(D_METHOD("get_max_count"),     &FastCounter::get_max_count);
ADD_PROPERTY(
    PropertyInfo(Variant::INT, "max_count",
                 PROPERTY_HINT_RANGE, "1,1000000,1"),
    "set_max_count", "get_max_count"
);
ADD_SIGNAL(MethodInfo("reached_max"));

// Source:
void FastCounter::set_max_count(int64_t v) { _max_count = MAX(1, v); }
int64_t FastCounter::get_max_count() const { return _max_count; }

void FastCounter::increment(int64_t by) {
    int64_t next = _count + by;
    if (next >= _max_count) {
        next = _max_count;
        set_count(next);
        emit_signal("reached_max");
    } else {
        set_count(next);
    }
}
```
::::
:::

:::problem{difficulty="standard"}
**4. Write a `TimedCounter` that auto-increments.**
 Extend `FastCounter` (or derive from `Node`
 directly) with a `tick_interval` float property
 (default 1.0 s). Override `_ready()` to enable
 processing and `_process(double delta)` to accumulate
 time and call `increment(1)` whenever an interval
 elapses. Write the header and source.

::::solution[Solution]
```cpp
// timed_counter.h
#pragma once
#include "fast_counter.h"
namespace godot {
class TimedCounter : public FastCounter {
    GDCLASS(TimedCounter, FastCounter)
private:
    double _tick_interval = 1.0;
    double _elapsed = 0.0;
protected:
    static void _bind_methods();
public:
    void set_tick_interval(double v);
    double get_tick_interval() const;
    virtual void _ready() override;
    virtual void _process(double delta) override;
};
} // namespace godot

// timed_counter.cpp
void TimedCounter::_bind_methods() {
    ClassDB::bind_method(D_METHOD("set_tick_interval","v"),
                         &TimedCounter::set_tick_interval);
    ClassDB::bind_method(D_METHOD("get_tick_interval"),
                         &TimedCounter::get_tick_interval);
    ADD_PROPERTY(
        PropertyInfo(Variant::FLOAT, "tick_interval",
                     PROPERTY_HINT_RANGE, "0.01,60,0.01"),
        "set_tick_interval", "get_tick_interval"
    );
}

void TimedCounter::set_tick_interval(double v) {
    _tick_interval = MAX(0.01, v);
}
double TimedCounter::get_tick_interval() const { return _tick_interval; }

void TimedCounter::_ready() {
    FastCounter::_ready();   // calls super
    set_process(true);
    _elapsed = 0.0;
}

void TimedCounter::_process(double delta) {
    _elapsed += delta;
    while (_elapsed >= _tick_interval) {
        _elapsed -= _tick_interval;
        increment(1);
    }
}
```
::::
:::

:::problem{difficulty="challenge"}
**5. Wrap a C math library function.**
 Imagine you want to expose a fast integer square-root function
 (`isqrt`, computing the integer part of √n) from a C
 library to GDScript. Write a `MathUtils` class that
 extends `Object` (not Node — it has no scene presence),
 binds a static GDScript-callable method
 `isqrt(n: int) -> int`, and registers it so GDScript
 can call `MathUtils.new().isqrt(144)`. Explain why you
 would use `Object` instead of `Node` here.

::::solution[Solution]
```cpp
// math_utils.h
#pragma once
#include <godot_cpp/classes/object.hpp>
namespace godot {
class MathUtils : public Object {
    GDCLASS(MathUtils, Object)
protected:
    static void _bind_methods();
public:
    int64_t isqrt(int64_t n) const;
};
} // namespace godot

// math_utils.cpp
#include "math_utils.h"
#include <cmath>
using namespace godot;

void MathUtils::_bind_methods() {
    ClassDB::bind_method(D_METHOD("isqrt","n"), &MathUtils::isqrt);
}

int64_t MathUtils::isqrt(int64_t n) const {
    if (n < 0) return 0;
    return static_cast<int64_t>(std::sqrt(static_cast<double>(n)));
}
```

**Why Object, not Node:**
 `Node` carries scene-tree overhead — a transform
 cache, processing callbacks, scene IDs, and a position in the
 tree. A pure utility class needs none of this. Inheriting from
 `Object` gives the minimum set of capabilities:
 reference counting, method calls, signal infrastructure — no
 scene overhead. The instance can be created with
 `MathUtils.new()` in GDScript and used immediately
 without adding it to any tree.
::::
:::

:::problem{difficulty="challenge"}
**6. Design a multi-platform .gdextension descriptor.**
 Your game ships for Linux 64-bit, Windows 64-bit, macOS
 (universal), Android arm64, and iOS arm64. Write a complete
 `.gdextension` file covering all five platforms in both
 debug and release configurations. Use the naming convention
 `libmygame.<platform>.<target>.<arch>.<ext>`
 and explain what extension/format each platform expects
 (`.so`, `.dll`, `.framework`,
 `.so` again for Android).

::::solution[Solution]
```ini
[configuration]
entry_symbol = "gdextension_init"
compatibility_minimum = "4.3"
reloadable = true

[libraries]
; ── Linux ──────────────────────────────────────────────────────────
linux.debug.x86_64   = "res://bin/libmygame.linux.template_debug.x86_64.so"
linux.release.x86_64 = "res://bin/libmygame.linux.template_release.x86_64.so"

; ── Windows ────────────────────────────────────────────────────────
windows.debug.x86_64   = "res://bin/libmygame.windows.template_debug.x86_64.dll"
windows.release.x86_64 = "res://bin/libmygame.windows.template_release.x86_64.dll"

; ── macOS (universal bundle — arm64 + x86_64 inside one .framework) ─
macos.debug   = "res://bin/libmygame.macos.template_debug.framework"
macos.release = "res://bin/libmygame.macos.template_release.framework"

; ── Android ────────────────────────────────────────────────────────
android.debug.arm64   = "res://bin/libmygame.android.template_debug.arm64.so"
android.release.arm64 = "res://bin/libmygame.android.template_release.arm64.so"

; ── iOS ────────────────────────────────────────────────────────────
ios.debug.arm64   = "res://bin/libmygame.ios.template_debug.arm64.dylib"
ios.release.arm64 = "res://bin/libmygame.ios.template_release.arm64.dylib"
```

**Extension notes:**
 Linux uses `.so` (shared object, ELF format).
 Windows uses `.dll` (dynamic-link library, PE format).
 macOS uses an `.xcframework` or `.framework`
 bundle (Mach-O); the SCons build produces a
 `.framework` directory for macOS.
 Android also uses `.so` (Linux-derived OS, ELF), but
 cross-compiled for ARM.
 iOS similarly uses `.dylib` (Mach-O, ARM); note Apple's
 restrictions mean static libraries are often preferred for App
 Store builds — check the current Godot export documentation for
 the recommended approach.
::::
:::
