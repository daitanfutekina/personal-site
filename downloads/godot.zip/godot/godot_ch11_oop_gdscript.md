---
title: "Object-Oriented GDScript — Classes, Inheritance & Design Patterns"
source: "godot_ch11_oop_gdscript.html"
---

Part II · Chapter 11

# Object-Oriented GDScript — Classes, Inheritance & Design Patterns

Estimated reading time: 85 min · Prerequisites: Ch 10 (Advanced GDScript)

## Overview

GDScript is a fully object-oriented language. Every script you write is a
 class, every node you use is an object, and the entire engine API is
 expressed as a class hierarchy. Understanding OOP in GDScript isn't just
 academic — it's the difference between a project that scales to 50 scripts
 and one that collapses under its own complexity at 10.

This chapter covers the mechanics of GDScript's class system in depth:
 how to write reusable classes with `class_name`, how inheritance
 lets you specialise behaviour without duplicating code, how setters and
 getters enforce invariants, and when *not* to use inheritance at all.
 We close with two indispensable design patterns — the State machine and the
 Command pattern — that appear in almost every non-trivial Godot project.

By the end of this chapter you will be able to:

- Write a full GDScript class with `class_name`, exported properties, methods, and a constructor
- Use `extends` to create specialised subclasses and `super` to call parent methods
- Override virtual methods to hook into the engine's lifecycle
- Define custom setters and getters with the `set =` / `get =` syntax
- Recognise when composition is a better choice than inheritance
- Implement a class-based finite state machine and a command queue

## 1 · Classes & `class_name`

### Declaring a class

Every GDScript file is implicitly a class. You give it a name, exported
 properties, private members, and methods — exactly like a class file in
 any OOP language. The difference from languages like Java or C# is that
 GDScript classes live in files rather than in explicit `class`
 blocks (except for inner classes, which are declared inline as shown in
 Chapter 10).

```gdscript
# weapon.gd — a reusable class for any weapon type
class_name Weapon
extends Resource   # Weapon is a Resource so it can be saved as .tres

@export var name:          String  = "Unnamed"
@export var base_damage:   int     = 10
@export var attack_speed:  float   = 1.0   # attacks per second
@export var range:         float   = 64.0  # pixels

var _cooldown: float = 0.0    # private — not exported

func _init(n: String = "", dmg: int = 10) -> void:
    name        = n
    base_damage = dmg

func can_attack() -> bool:
    return _cooldown <= 0.0

func attack(target: Node2D) -> int:
    if not can_attack():
        return 0
    _cooldown = 1.0 / attack_speed
    var dmg := _calculate_damage()
    target.take_damage(dmg)
    return dmg

func tick(delta: float) -> void:
    if _cooldown > 0.0:
        _cooldown -= delta

func _calculate_damage() -> int:
    return base_damage   # subclasses override this
```

### class\_name and global access

The `class_name` declaration registers the class in Godot's global
 type system. Once declared, you can:

- Use the name as a type annotation anywhere: `var w: Weapon`
- Instantiate it without a path: `Weapon.new()`
- Test with `is`: `if item is Weapon:`
- See it in the Inspector's resource picker drop-down
- Autocompletion in any script in the project

:::callout-warning[class\_name must be unique across the project]
Two files with the same `class_name` will cause a registration
 error. Godot 4.x also enforces that the `class_name` matches the
 file name by convention (though not strictly required). Name collisions with
 built-in classes (like naming your script "Node" or "Resource") cause
 confusing errors — prefix project-specific classes if needed:
 `class_name GDWeapon`.
:::

## 2 · Inheritance

Inheritance lets a class (*subclass*) automatically gain all the
 properties and methods of another class (*superclass*) while
 adding or overriding only what's different. In Godot, every node class
 already uses deep inheritance — `CharacterBody2D` extends
 `PhysicsBody2D` extends `CollisionObject2D` extends
 `Node2D` extends `CanvasItem` extends `Node`.
 You tap into this same system with your own scripts.

 Inheritance Chain — CharacterBody2D

 Object

 Node

 CanvasItem

 Node2D

 Collision
 Object2D

 Physics
 Body2D

 CharacterBody2D

 extends CharacterBody2D ← your script

 Your script inherits ALL methods & properties from this entire chain — \_ready(), position, visible, move\_and\_slide(), etc.

 When your script `extends CharacterBody2D`, it inherits the entire chain back to `Object`. You get every method and property from every ancestor automatically.

### extends

```gdscript
# sword.gd
class_name Sword
extends Weapon    # inherits everything from Weapon

@export var slash_arc_degrees: float = 90.0

# Override the damage calculation to add a random bonus:
func _calculate_damage() -> int:
    return base_damage + randi_range(0, 5)   # base_damage inherited from Weapon

# Add a new method that only Sword has:
func parry() -> bool:
    # returns true if parry timing was correct
    return _cooldown > (1.0 / attack_speed) * 0.8

# bow.gd
class_name Bow
extends Weapon

@export var projectile_scene: PackedScene
@export var projectile_speed: float = 800.0

func attack(target: Node2D) -> int:
    if not can_attack():
        return 0
    _cooldown = 1.0 / attack_speed
    # Spawn a projectile instead of instant damage
    var arrow := projectile_scene.instantiate()
    arrow.speed    = projectile_speed
    arrow.damage   = _calculate_damage()
    arrow.direction = (target.global_position - target.get_parent().global_position).normalized()
    target.get_parent().add_child(arrow)
    return 0   # damage applied on arrow impact, not here
```

### super and overriding

When a subclass overrides a method, calling `super()` inside
 the override invokes the parent's version of the same method. This lets you
 *extend* behaviour rather than *replace* it entirely:

```gdscript
class_name MagicSword
extends Sword

@export var mana_cost: int = 5
var _mana: int = 100

func attack(target: Node2D) -> int:
    if _mana < mana_cost:
        return super.attack(target)   # not enough mana: normal attack

    _mana -= mana_cost
    # Call the parent attack (which handles cooldown and damage):
    var dmg := super.attack(target)
    # Then add a magic effect on top:
    if dmg > 0:
        target.apply_status("burn", 3.0)
    return dmg

# super.method_name() calls the parent's version:
func _calculate_damage() -> int:
    return super._calculate_damage() + 10   # parent damage + 10 magic bonus
```

:::callout-key[super() vs super.method\_name()]
Inside an override, bare `super()` calls the parent's version
 of the *same* method (the one being overridden). Use this in
 `_ready()` and `_physics_process()` overrides to run
 the parent's lifecycle code first. `super.some_other_method()`
 calls a *different* parent method by name — useful but less common.
:::

### Virtual methods

GDScript doesn't have a formal `virtual` keyword, but the
 pattern is identical: define a method in the base class with a default
 (or empty) implementation and document that subclasses should override it.
 By convention, prefix the method name with an underscore to signal it's
 an "internal hook":

```gdscript
# base_enemy.gd
class_name BaseEnemy
extends CharacterBody2D

# "Virtual" — subclasses are expected to override this
func _get_move_direction() -> Vector2:
    return Vector2.ZERO   # default: stand still

# "Virtual" — subclasses provide their own attack behaviour
func _perform_attack() -> void:
    pass

func _physics_process(delta: float) -> void:
    velocity = _get_move_direction() * speed
    move_and_slide()

    if _should_attack():
        _perform_attack()

# grunt_enemy.gd
class_name GruntEnemy
extends BaseEnemy

func _get_move_direction() -> Vector2:
    var to_player := (player.global_position - global_position).normalized()
    return to_player

func _perform_attack() -> void:
    player.take_damage(10)
    $AttackAnimator.play("punch")

# archer_enemy.gd
class_name ArcherEnemy
extends BaseEnemy

@export var arrow_scene: PackedScene

func _get_move_direction() -> Vector2:
    # Stay at range — move away if too close
    var dist := global_position.distance_to(player.global_position)
    if dist < 200.0:
        return (global_position - player.global_position).normalized()
    return Vector2.ZERO

func _perform_attack() -> void:
    var arrow := arrow_scene.instantiate()
    get_parent().add_child(arrow)
    arrow.global_position = global_position
    arrow.direction = (player.global_position - global_position).normalized()
```

## 3 · Constructors & `_init()`

The `_init()` method is called when you create a new instance
 with `ClassName.new(args)`. It's optional — if you don't define
 one, Godot uses a default no-argument constructor. Any argument you pass to
 `.new()` is forwarded to `_init()`.

```gdscript
class_name StatusEffect
extends RefCounted   # lightweight — not a Node

var effect_name: String
var duration:    float
var strength:    float

func _init(name: String, dur: float, str: float = 1.0) -> void:
    effect_name = name
    duration    = dur
    strength    = str

func tick(delta: float) -> bool:
    duration -= delta
    return duration > 0.0   # return false when expired

# Create instances:
var burn  := StatusEffect.new("Burn",  5.0, 2.0)
var slow  := StatusEffect.new("Slow",  3.0, 0.5)
var stun  := StatusEffect.new("Stun",  1.5)        # uses default strength 1.0
```

### Chaining \_init() in subclasses

If the parent class has a non-default constructor, the child's
 `_init()` must call it. GDScript uses the syntax
 `super(args)` at the start of the child constructor:

```gdscript
class_name PoisonEffect
extends StatusEffect

var damage_per_second: float

func _init(dur: float, dps: float) -> void:
    super("Poison", dur, 1.0)   # call parent _init with a fixed name
    damage_per_second = dps

func apply(target: Node) -> void:
    target.take_damage(damage_per_second * (1.0 / 60.0))   # called each frame

# Usage:
var poison := PoisonEffect.new(8.0, 5.0)   # 8 seconds, 5 dmg/sec
```

:::callout-tip[RefCounted vs Node for pure data classes]
Classes that don't need `_process`, `_physics_process`,
 or scene-tree membership should extend `RefCounted` (or nothing,
 which implicitly uses RefCounted). RefCounted objects are garbage-collected
 automatically when no more references exist — no `queue_free()`
 needed. Node subclasses must be added to the tree and freed manually, which
 is overkill for a data container like StatusEffect or a graph node in A\*.
:::

## 4 · Properties — Setters & Getters

A *property* is a variable with custom logic that runs when you
 read or write it. In GDScript the syntax is `var x: T = val : set = my_setter, get = my_getter`.
 Properties let you enforce invariants, clamp values, update dependent state,
 or fire signals automatically when data changes — all without the caller
 knowing anything changed under the hood.

```gdscript
class_name Character
extends Node2D

signal health_changed(new_value: int, max_value: int)
signal died

@export var max_health: int = 100

var health: int = 100 : set = _set_health, get = _get_health

func _set_health(value: int) -> void:
    var clamped := clampi(value, 0, max_health)
    if clamped == health:
        return   # no change — don't emit noise signals
    health = clamped
    health_changed.emit(health, max_health)
    if health == 0:
        died.emit()

func _get_health() -> int:
    return health

# Callers just do: character.health -= 30
# The setter handles clamping, signals, and death automatically.
```

You can also use the **inline setter/getter** form introduced
 in Godot 4.x — useful for simple transformations:

```gdscript
# Inline property — speed always stored in pixels/sec, exposed in km/h for a tool:
var speed_px: float = 0.0
var speed_kmh: float :
    get: return speed_px * 0.0036
    set(v): speed_px = v / 0.0036

# Read-only property (getter only — no setter):
var is_alive: bool :
    get: return health > 0

# Computed property — value depends on other state, nothing stored:
var damage_output: float :
    get: return base_damage * (1.0 + strength_bonus * 0.1)
```

:::callout-warning[Don't set the property from inside its own setter]
Assigning `health = value` inside `_set_health()`
 calls the setter again — infinite recursion. You must write to the
 *underlying variable* directly. One pattern: name the backing variable
 with a leading underscore (`var _health: int`) and expose it as
 the public property `health`. The setter writes `_health`,
 the getter reads `_health`.
:::

## 5 · Composition vs Inheritance

Inheritance Explosion vs Composition

 Inheritance ✗ (8 classes for 3 traits)

 Enemy

 FlyingEnemy

 ArmoredEnemy

 FlyingArmored

 FlyingPoisoned

 ArmoredPoisoned

 FlyArmoredPoison
 Add one trait → doubles the subclasses

 Composition ✓ (1 class + 3 components)

 Enemy (Node)

 FlyBehaviour

 ArmorBehaviour

 PoisonBehaviour

 Attach any combination of components.
 FlyingArmoredPoisoned = 3 add\_child() calls.
 Adding a new trait = one new script, zero subclasses.

 Deep inheritance hierarchies explode with each new trait combination. Composition lets you attach any mix of behaviours to a single base class.

 Inheritance says "a Sword *is a* Weapon." Composition says "a character
 *has a* Weapon." Choosing the wrong one is one of the most common
 architectural mistakes in game development. The rule of thumb:

- Use **inheritance** when the relationship is truly "is-a" and the subclass only *specialises* behaviour without fundamentally changing the contract.
- Use **composition** when you want to mix behaviours from multiple sources, when the base class would need to grow constantly to accommodate subclasses, or when the relationship is better described as "has-a" or "uses-a."

:::example[Inheritance gone wrong]
You have Enemy. Then FlyingEnemy. Then ArmoredEnemy. Then FlyingArmoredEnemy.
          With pure inheritance you need four classes. Add "Poisoned" and it's eight.

::::answer[Composition solution]
```gdscript
# Each behaviour is an independent component (Node or RefCounted):

class_name FlyBehaviour
extends Node
func get_move_direction(enemy: Node2D) -> Vector2:
    return (enemy.player.global_position - enemy.global_position).normalized()

class_name GroundBehaviour
extends Node
func get_move_direction(enemy: Node2D) -> Vector2:
    # Pathfind along the ground using NavigationAgent2D
    return enemy.nav_agent.get_next_path_position() - enemy.global_position

class_name ArmorComponent
extends Node
@export var damage_reduction: float = 0.5
func modified_damage(raw: int) -> int:
    return int(raw * (1.0 - damage_reduction))

# The enemy is a thin shell that delegates to its components:
extends CharacterBody2D

@onready var movement: Node = $MovementBehaviour   # FlyBehaviour or GroundBehaviour
@onready var armor: ArmorComponent = $ArmorComponent   # present or absent

func take_damage(amount: int) -> void:
    if armor:
        amount = armor.modified_damage(amount)
    health -= amount

func _physics_process(delta: float) -> void:
    velocity = movement.get_move_direction(self) * speed
    move_and_slide()
```

Now "flying armored poisoned" = attach FlyBehaviour + ArmorComponent +
 PoisonComponent. No new class required — just new scene configurations.
::::
:::

### Component pattern in Godot's scene tree

Godot's scene tree is naturally component-friendly. Each child Node2D
 on a character can be a behaviour component — a `HealthComponent`,
 `InventoryComponent`, `StatusEffectComponent` —
 each self-contained with its own state and signals. The parent character
 just holds references to its components:

```gdscript
# health_component.gd — attach to any entity that needs health
class_name HealthComponent
extends Node

signal died
signal health_changed(new_hp: int, max_hp: int)

@export var max_health: int = 100
var _hp: int

func _ready() -> void:
    _hp = max_health

func take_damage(amount: int) -> void:
    _hp = clampi(_hp - amount, 0, max_health)
    health_changed.emit(_hp, max_health)
    if _hp == 0:
        died.emit()

func heal(amount: int) -> void:
    _hp = clampi(_hp + amount, 0, max_health)
    health_changed.emit(_hp, max_health)

func get_health() -> int:
    return _hp

# Player, Enemy, Boss all just add a HealthComponent child.
# No shared base class needed.
```

## 6 · Duck Typing & Interfaces

GDScript doesn't have interfaces or abstract classes. Instead it uses
 **duck typing**: if an object has a method, you can call it —
 no shared base class required. This is both a strength (flexible, less
 boilerplate) and a risk (no compile-time guarantee the method exists).

```gdscript
# Calling take_damage on anything that has it — no common base class needed:
func damage_all_in_radius(center: Vector2, radius: float, amount: int) -> void:
    for body in get_tree().get_nodes_in_group("damageable"):
        if body.global_position.distance_to(center) <= radius:
            if body.has_method("take_damage"):
                body.take_damage(amount)

# Safer with type checking first (and cleaner autocomplete):
func damage_all_in_radius(center: Vector2, radius: float, amount: int) -> void:
    for body in get_tree().get_nodes_in_group("damageable"):
        if not body.global_position.distance_to(center) <= radius:
            continue
        # is-check doubles as a null guard
        if body is HealthComponent:
            body.take_damage(amount)
        elif body.has_method("take_damage"):
            body.take_damage(amount)
```

:::callout-intuition[Simulate interfaces with a base script and Godot groups]
For a project-wide "contract" without a shared base class, add every
 entity that implements the contract to a Godot group (e.g. "damageable")
 in `_ready()`. Then use `get_nodes_in_group("damageable")`
 to find all implementors. Pair this with a base class (even one with just
 `pass` implementations) and document clearly that subclasses must
 override specific methods — you get the organisational benefit of interfaces
 at the cost of a tiny bit of convention discipline.
:::

## 7 · Common Design Patterns

### State pattern — finite state machines

A finite state machine (FSM) makes character AI and animation logic readable
 by splitting each behaviour into its own class. Instead of a giant
 `_physics_process` full of `if current_state == "idle"`
 checks, each state is an object with its own enter/exit/update methods.

```gdscript
# state.gd — base class for all states
class_name State
extends Node

# Called when the FSM transitions into this state
func enter() -> void: pass

# Called every physics frame while this state is active
func physics_update(delta: float) -> void: pass

# Called when the FSM transitions out of this state
func exit() -> void: pass

# idle_state.gd
class_name IdleState
extends State

@onready var player: CharacterBody2D = $"../.."  # navigate to player root

func enter() -> void:
    player.velocity = Vector2.ZERO
    player.$Animator.play("idle")

func physics_update(delta: float) -> void:
    if Input.get_axis("ui_left", "ui_right") != 0.0:
        get_parent().transition_to("Run")   # FSM manages the transition
    if Input.is_action_just_pressed("jump"):
        get_parent().transition_to("Jump")

# state_machine.gd — attach this to the player, with states as children
class_name StateMachine
extends Node

var current_state: State = null

func _ready() -> void:
    for child in get_children():
        child.enter()   # noop for non-active states, or guard below
    transition_to(get_child(0).name)   # start in first state

func transition_to(state_name: StringName) -> void:
    if current_state:
        current_state.exit()
    current_state = get_node(state_name)
    current_state.enter()

func _physics_process(delta: float) -> void:
    if current_state:
        current_state.physics_update(delta)
```

Scene structure: Player → StateMachine → IdleState, RunState, JumpState,
 FallState, AttackState. Each state is a Node child so it can have its
 own @onready vars and @export config.

### Command pattern — undo and replay

The command pattern wraps each game action as an object with an
 `execute()` and optional `undo()` method. This enables:
 undo/redo in a level editor, move replay for a turn-based game, input
 recording and playback for demos, and network-safe action serialisation.

```gdscript
# command.gd — base class
class_name Command
extends RefCounted

func execute() -> void: pass
func undo()    -> void: pass

# move_command.gd
class_name MoveCommand
extends Command

var _actor:    Node2D
var _from_pos: Vector2
var _to_pos:   Vector2

func _init(actor: Node2D, to: Vector2) -> void:
    _actor    = actor
    _from_pos = actor.position
    _to_pos   = to

func execute() -> void:
    _actor.position = _to_pos

func undo() -> void:
    _actor.position = _from_pos

# command_history.gd — stores and replays commands
class_name CommandHistory
extends RefCounted

var _history: Array[Command] = []
var _index:   int            = -1

func execute(cmd: Command) -> void:
    # Discard any "future" commands if we're mid-history (new action)
    _history.resize(_index + 1)
    cmd.execute()
    _history.append(cmd)
    _index = _history.size() - 1

func undo() -> void:
    if _index < 0:
        return
    _history[_index].undo()
    _index -= 1

func redo() -> void:
    if _index >= _history.size() - 1:
        return
    _index += 1
    _history[_index].execute()

# Usage in a turn-based game:
var history := CommandHistory.new()

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("move_right"):
        history.execute(MoveCommand.new(player, player.position + Vector2(64, 0)))
    elif event.is_action_pressed("ui_undo"):
        history.undo()
    elif event.is_action_pressed("ui_redo"):
        history.redo()
```

:::summary
## Chapter Summary

| Concept | Quick reference |
| --- | --- |
| class\_name | Registers the class globally. Enables typed vars, autocompletion, Inspector drop-downs. |
| extends | Subclass inherits all members of parent. Works with built-in types and custom class\_name scripts. |
| super() | In an override, calls the parent's version of the same method. Essential in \_init(), \_ready(), \_physics\_process(). |
| Virtual methods | Define with `pass` body; subclass overrides. Prefix with \_ by convention. |
| \_init() | Constructor. Arguments passed to .new(). Call super(args) if parent has non-default constructor. |
| Property setters | `var x: T = v : set = _setter`. Setter must write backing var, not the property itself. |
| Composition | Attach component Nodes (HealthComponent, ArmorComponent) instead of deep inheritance hierarchies. |
| Duck typing | `has_method("name")` or `is ClassName` before calling. Groups simulate interfaces. |
| State pattern | State base class + StateMachine node + child states. Each state is self-contained with enter/exit/update. |
| Command pattern | Command objects with execute()/undo(). CommandHistory enables undo/redo. |

**If you remember nothing else:** prefer composition over
 deep inheritance. A character with five component Nodes (health, inventory,
 status, movement, animation) is easier to maintain and extend than a
 six-level class hierarchy. Reserve inheritance for genuine "is-a" relationships
 — usually just specialising a base enemy or weapon type.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Write a `class_name Projectile extends Area2D` with these
 exported properties: `speed: float`, `damage: int`,
 `lifetime: float`. In `_ready()` start a timer that
 calls `queue_free()` after `lifetime` seconds.
 In `_physics_process(delta)` move the projectile forward in its
 facing direction.

::::solution[Solution]
```gdscript
class_name Projectile
extends Area2D

@export var speed:    float = 600.0
@export var damage:   int   = 15
@export var lifetime: float = 3.0

func _ready() -> void:
    body_entered.connect(_on_body_entered, CONNECT_DEFERRED)
    # Self-destruct timer:
    var timer := get_tree().create_timer(lifetime)
    timer.timeout.connect(queue_free)

func _physics_process(delta: float) -> void:
    # rotation_degrees is set by whoever spawned us
    position += Vector2.RIGHT.rotated(rotation) * speed * delta

func _on_body_entered(body: Node2D) -> void:
    if body.has_method("take_damage"):
        body.take_damage(damage)
    queue_free()
```
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Given the `Character` class with a `health` property
 setter shown in Section 4, add a `max_health` setter that clamps
 the current `health` if it exceeds the new maximum when
 `max_health` is lowered.

::::solution[Solution]
```gdscript
var _max_health: int = 100
var _health:     int = 100

var max_health: int :
    get: return _max_health
    set(value):
        _max_health = max(1, value)   # must be at least 1
        # Clamp current health if it now exceeds the new max:
        if _health > _max_health:
            health = _max_health    # goes through the health setter
        health_changed.emit(_health, _max_health)

var health: int :
    get: return _health
    set(value):
        var clamped := clampi(value, 0, _max_health)
        if clamped == _health:
            return
        _health = clamped
        health_changed.emit(_health, _max_health)
        if _health == 0:
            died.emit()
```
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Implement a `HealthComponent` as described in Section 5,
 then attach it to both a Player and an Enemy scene. Demonstrate that the
 same component script handles both without any changes to the component
 itself — only the parent scene differs.

::::solution[Solution]
```gdscript
# health_component.gd (unchanged — same file for Player and Enemy)
class_name HealthComponent
extends Node

signal died
signal health_changed(hp: int, max_hp: int)

@export var max_health: int = 100
var _hp: int

func _ready() -> void:
    _hp = max_health

func take_damage(amount: int) -> void:
    _hp = clampi(_hp - amount, 0, max_health)
    health_changed.emit(_hp, max_health)
    if _hp == 0:
        died.emit()

func heal(amount: int) -> void:
    _hp = clampi(_hp + amount, 0, max_health)
    health_changed.emit(_hp, max_health)

# player.gd — connects component signals to player-specific responses
extends CharacterBody2D
@onready var hp: HealthComponent = $HealthComponent

func _ready() -> void:
    hp.died.connect(func(): get_tree().change_scene_to_file("res://scenes/game_over.tscn"))
    hp.health_changed.connect(func(h, m): $HUD.update_health(h, m))

# enemy.gd — same component, different response
extends CharacterBody2D
@onready var hp: HealthComponent = $HealthComponent

func _ready() -> void:
    hp.died.connect(func(): drop_loot(); queue_free())
```
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Implement a three-state FSM for a simple enemy: **Patrol**
 (move back and forth between two waypoints), **Chase** (move
 toward the player when within detection range), **Attack**
 (stop and swing when within melee range). Transitions: Patrol → Chase when
 player enters detection range; Chase → Attack when within melee range;
 Attack → Chase when player moves out of melee range; Chase → Patrol when
 player exits detection range.

::::solution[Solution]
```gdscript
# patrol_state.gd
class_name PatrolState
extends State
@export var waypoints: Array[Vector2] = []
var _target_idx := 0

func physics_update(delta: float) -> void:
    var enemy: Node2D = get_parent().get_parent()
    if waypoints.is_empty(): return
    var target := waypoints[_target_idx]
    var dir := (target - enemy.global_position).normalized()
    enemy.velocity = dir * enemy.patrol_speed
    enemy.move_and_slide()
    if enemy.global_position.distance_to(target) < 8.0:
        _target_idx = (_target_idx + 1) % waypoints.size()

    var dist_to_player := enemy.global_position.distance_to(enemy.player.global_position)
    if dist_to_player < enemy.detection_range:
        get_parent().transition_to("ChaseState")

# chase_state.gd
class_name ChaseState
extends State

func physics_update(delta: float) -> void:
    var enemy: Node2D = get_parent().get_parent()
    var dist := enemy.global_position.distance_to(enemy.player.global_position)
    if dist > enemy.detection_range:
        get_parent().transition_to("PatrolState")
        return
    if dist < enemy.melee_range:
        get_parent().transition_to("AttackState")
        return
    var dir := (enemy.player.global_position - enemy.global_position).normalized()
    enemy.velocity = dir * enemy.chase_speed
    enemy.move_and_slide()

# attack_state.gd
class_name AttackState
extends State

func enter() -> void:
    get_parent().get_parent().$AttackTimer.start()

func physics_update(delta: float) -> void:
    var enemy: Node2D = get_parent().get_parent()
    if enemy.global_position.distance_to(enemy.player.global_position) > enemy.melee_range:
        get_parent().transition_to("ChaseState")
```
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Design a **turn-based RPG ability system** using the
 command pattern. Create an `Ability` base class (extends Command)
 with `cost: int` and `caster: Character` fields.
 Implement three abilities: `HealAbility`, `FireballAbility`
 (AoE), and `ShieldAbility` (timed buff). Wire them to a
 `AbilityQueue` that executes one ability per turn and supports
 undo for the last turn (cancel before end-of-turn).

::::solution[Solution]
```gdscript
# ability.gd
class_name Ability
extends Command

var cost:   int
var caster: Character

func _init(c: Character, mp_cost: int) -> void:
    caster = c
    cost   = mp_cost

func can_use() -> bool:
    return caster.mp >= cost

# heal_ability.gd
class_name HealAbility
extends Ability

@export var heal_amount: int = 40
var _old_hp: int

func _init(c: Character) -> void:
    super(c, 10)

func execute() -> void:
    caster.mp -= cost
    _old_hp     = caster.health
    caster.health += heal_amount   # goes through setter

func undo() -> void:
    caster.health = _old_hp
    caster.mp    += cost

# fireball_ability.gd
class_name FireballAbility
extends Ability

@export var damage: int   = 30
@export var radius: float = 128.0
var _targets_hit: Array[Character] = []

func _init(c: Character) -> void:
    super(c, 25)

func execute() -> void:
    caster.mp -= cost
    _targets_hit.clear()
    for node in caster.get_tree().get_nodes_in_group("enemies"):
        if node.global_position.distance_to(caster.global_position) <= radius:
            node.health -= damage
            _targets_hit.append(node)

func undo() -> void:
    for target in _targets_hit:
        if is_instance_valid(target):
            target.health += damage
    _targets_hit.clear()
    caster.mp += cost

# ability_queue.gd
class_name AbilityQueue
extends RefCounted

var _pending:  Array[Ability] = []
var _last_used: Ability       = null

func queue(ability: Ability) -> bool:
    if not ability.can_use():
        return false
    _pending.append(ability)
    return true

func execute_all() -> void:
    for ability in _pending:
        if ability.can_use():
            ability.execute()
            _last_used = ability
    _pending.clear()

func undo_last() -> void:
    if _last_used:
        _last_used.undo()
        _last_used = null
```
::::
:::

Godot 4.6 Complete Reference · Part II — Advanced GDScript · Generated for self-study. Edit freely.
