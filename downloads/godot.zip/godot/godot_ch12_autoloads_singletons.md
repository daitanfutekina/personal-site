---
title: "Autoloads & Singletons — Global Systems in Godot 4.6"
source: "godot_ch12_autoloads_singletons.html"
---

Part II · Chapter 12

# Autoloads & Singletons — Global Systems in Godot 4.6

Estimated reading time: 70 min · Prerequisites: Ch 11 (OOP in GDScript)

## Overview

Most games need systems that span the entire session: an audio manager that
 plays sounds regardless of which scene is loaded, a save system that persists
 data between levels, a score tracker visible on every screen. Building these
 as regular scene nodes is painful — you'd need to pass references everywhere
 or use `get_tree().root` lookups. Godot solves this with
 **Autoloads**: scripts (or scenes) that are instantiated once
 at startup and remain in the scene tree for the entire application lifetime.

Autoloads are Godot's singleton pattern. They are not singletons in the
 traditional software-engineering sense (no private constructor, no enforcement
 that only one exists) — they are simply nodes that live at the root of the
 scene tree and are accessible by name from any script. Used well, they
 eliminate reference-passing spaghetti. Used poorly, they become a global
 god-object that everything depends on.

By the end of this chapter you will be able to:

- Register and access autoloads from any script in the project
- Implement an event bus that decouples scenes from each other
- Write a GameManager that owns global state and handles scene transitions
- Build a pooled AudioManager that plays SFX without audio node juggling
- Create a save/load system using a custom Resource and FileAccess
- Understand autoload load order and avoid common circular dependency pitfalls

## 1 · What Are Autoloads?

An autoload is a script or scene that Godot instantiates and adds to the

 Autoloads in the Scene Tree

 /root (Window)

 GameManager ●

 AudioManager ●

 EventBus ●

 CurrentScene ▶

 Player

 Enemies

 HUD

 Autoloads (● = persist across scene changes)

 CurrentScene (▶ = replaced when SceneTree.change\_scene\_to\_file() is called)

 Autoloads sit as direct children of `/root`, *above* the current scene. When you call `change_scene_to_file()`, only the CurrentScene subtree is swapped out — the autoloads stay.

 root of the scene tree before loading any user scenes. It persists there
 until the game quits. You can think of it as a node that always exists,
 regardless of which scene is currently loaded.

### Registering autoloads

Go to **Project → Project Settings → Autoload** tab. Click
 the folder icon to pick a `.gd` script (or a `.tscn`
 scene file), then give it a name. The name becomes a global constant you
 use to access it from any script — `GameManager`,
 `AudioManager`, `EventBus`, etc.

Autoloads appear at the top of the remote scene tree (in the Running tab
 while the game is playing) above your main scene. They are Nodes added
 to `/root/`, so their full path is e.g. `/root/GameManager`.

:::callout-tip[Use a scene (.tscn) autoload when you need child nodes]
If your autoload needs AudioStreamPlayer nodes for its pool, or a
 CanvasLayer for persistent UI, make the autoload a *scene* with
 those children baked in — then register the scene file instead of a bare
 script. The root node's script is still your singleton logic; the children
 just provide infrastructure.
:::

### Accessing autoloads

Once registered, the autoload is available by name from any GDScript as if
 it were a global variable:

```gdscript
# From any script, anywhere in the project:
GameManager.add_score(100)
AudioManager.play_sfx("coin_pickup")
EventBus.player_died.emit()

# You can also access them via the scene tree if needed:
var gm: Node = get_tree().root.get_node("GameManager")

# Or with the global name (same thing, cleaner):
var gm: GameManager = GameManager
```

:::callout-warning[Autoload names are not typed by default]
GDScript treats the autoload name as a `Node` reference unless
 the script has a `class_name` matching its autoload name. For
 full autocomplete and type safety, add `class_name GameManager`
 to the top of your autoload script. Then the global `GameManager`
 variable is typed, and the editor can autocomplete its methods.
:::

## 2 · Event Bus Pattern

### Why not just connect signals directly?

Direct signal connections require the emitter to have a reference to the
 listener, or vice-versa. In a complex game, this creates dependency chains:
 a chest in Level3 needs a reference to the HUD in UILayer which needs a
 reference to GameManager… The more objects communicate, the more tangled
 the references become.

An **event bus** solves this with indirection: every object that
 wants to broadcast an event emits it on a central autoload. Every object
 that wants to receive it connects to the same autoload. Emitter and listener
 never reference each other — they only reference the bus.

 Direct Signals vs Event Bus

 Direct Connections ✗

 Enemy

 HUD

 SoundMgr

 ScoreMgr

 AchieveMgr

 Every node knows about every other node

 Event Bus ✓

 EventBus (autoload)

 Enemy

 HUD

 SoundMgr

 AchieveMgr

 Nobody references anyone — just the bus

 Direct signal connections create spaghetti dependencies. An event bus centralizes all inter-system communication: emitters emit on the bus, listeners subscribe to the bus, and neither knows the other exists.

### Implementing the event bus

```gdscript
# event_bus.gd  (autoload name: EventBus)
class_name EventBus
extends Node

# ── Player events ───────────────────────────────────────────────
signal player_died
signal player_health_changed(new_hp: int, max_hp: int)
signal player_score_changed(new_score: int)
signal player_collected_item(item_id: StringName)

# ── Level events ────────────────────────────────────────────────
signal level_started(level_index: int)
signal level_completed(level_index: int, stars: int)
signal checkpoint_reached(checkpoint_id: int)

# ── UI events ───────────────────────────────────────────────────
signal pause_requested
signal settings_opened
signal dialog_started(speaker: String, lines: Array[String])
signal dialog_ended

# No logic needed — signals are the interface.
# Any node emits; any node listens.
```

:::example[Event bus in practice]
A coin pickup in the level must update the HUD score counter.
          Neither knows about the other.

::::answer[Emitter and listener — zero direct coupling]
```gdscript
# coin.gd — the emitter
extends Area2D

@export var value: int = 10

func _on_body_entered(body: Node2D) -> void:
    if not body.is_in_group("player"):
        return
    EventBus.player_score_changed.emit(GameManager.score + value)
    GameManager.add_score(value)
    queue_free()

# hud_score_label.gd — the listener
extends Label

func _ready() -> void:
    EventBus.player_score_changed.connect(_on_score_changed)

func _on_score_changed(new_score: int) -> void:
    text = "Score: %d" % new_score
```

The coin doesn't know the HUD exists. The HUD doesn't know about coins.
 Both only know about EventBus — a stable, project-wide contract.
::::
:::

:::callout-pitfall[Disconnect bus connections when nodes are freed]
If a scene connects to EventBus signals in `_ready()` and
 is then freed (scene change, queue\_free), those connections become dangling
 references. The bus holds a reference to the freed node's method. When the
 signal fires, Godot calls into dead memory and crashes. Either disconnect
 in `_exit_tree()`, use `CONNECT_ONE_SHOT` for
 temporary listeners, or use `connect(callable, CONNECT_DEFERRED)`
 combined with `is_instance_valid()` checks in the callback.

```gdscript
func _ready() -> void:
    EventBus.player_died.connect(_on_player_died)

func _exit_tree() -> void:
    EventBus.player_died.disconnect(_on_player_died)
```
:::

## 3 · GameManager Singleton

GameManager owns the global state that must persist across scene loads:
 current score, player lives, unlocked levels, settings values. It also
 handles scene transitions so loading screens and transitions run cleanly.

### Global game state

```gdscript
# game_manager.gd  (autoload name: GameManager)
class_name GameManager
extends Node

# ── Persistent state ────────────────────────────────────────────
var score:          int  = 0
var lives:          int  = 3
var current_level:  int  = 1
var coins_collected: int = 0
var settings := GameSettings.new()   # a custom Resource (Ch 6 pattern)

# ── Score ────────────────────────────────────────────────────────
func add_score(amount: int) -> void:
    score += amount
    EventBus.player_score_changed.emit(score)

func reset_score() -> void:
    score = 0
    EventBus.player_score_changed.emit(score)

# ── Lives ────────────────────────────────────────────────────────
func lose_life() -> void:
    lives -= 1
    if lives <= 0:
        game_over()

func game_over() -> void:
    score = 0
    lives = 3
    current_level = 1
    load_scene("res://scenes/ui/game_over.tscn")

# ── Level progression ────────────────────────────────────────────
func complete_level(stars: int) -> void:
    EventBus.level_completed.emit(current_level, stars)
    current_level += 1
    # Unlock next level in save data, then load it:
    SaveSystem.save_progress(current_level)
    load_scene("res://scenes/levels/level_%02d.tscn" % current_level)
```

### Scene transitions

Abrupt scene changes jar the player. GameManager can own a full-screen
 CanvasLayer that fades in/out around every scene load:

```gdscript
# game_manager.gd (continued) — autoload is a .tscn with a CanvasLayer child
@onready var fade: ColorRect    = $FadeLayer/FadeRect
@onready var tween_node: Node  = $FadeLayer   # or use a Tween

func load_scene(path: String, fade_duration: float = 0.4) -> void:
    # Fade to black:
    var tw := create_tween()
    tw.tween_property(fade, "modulate:a", 1.0, fade_duration)
    await tw.finished

    get_tree().change_scene_to_file(path)

    # Fade back in (new scene is now active):
    tw = create_tween()
    tw.tween_property(fade, "modulate:a", 0.0, fade_duration)
    await tw.finished

func reload_current_scene() -> void:
    load_scene(get_tree().current_scene.scene_file_path)
```

## 4 · AudioManager

Playing audio in Godot usually means adding an AudioStreamPlayer node to
 a scene and calling `play()`. But this breaks down when:

- A scene is freed while a sound is still playing (the player is freed, so is the AudioStreamPlayer)
- Multiple identical sounds play simultaneously and only one node exists
- You want to play a global UI sound from a script that has no AudioStreamPlayer child

A pooled AudioManager autoload solves all three. It holds a pool of
 AudioStreamPlayer nodes, hands them out when a sound is requested, and
 reclaims them when playback finishes:

```gdscript
# audio_manager.gd  (autoload name: AudioManager, registered as a .tscn)
# The .tscn has this script on root + 8 AudioStreamPlayer children pre-added.
class_name AudioManager
extends Node

const POOL_SIZE := 8

var _sfx_pool: Array[AudioStreamPlayer] = []

# Preloaded sounds — can also load dynamically
const SOUNDS: Dictionary = {
    "coin_pickup":  preload("res://audio/sfx/coin.wav"),
    "jump":         preload("res://audio/sfx/jump.wav"),
    "hurt":         preload("res://audio/sfx/hurt.wav"),
    "explosion":    preload("res://audio/sfx/explosion.wav"),
    "ui_click":     preload("res://audio/sfx/ui_click.wav"),
}

func _ready() -> void:
    for i in POOL_SIZE:
        var player := AudioStreamPlayer.new()
        player.bus = "SFX"
        add_child(player)
        _sfx_pool.append(player)

func play_sfx(sound_name: StringName, volume_db: float = 0.0, pitch: float = 1.0) -> void:
    if not SOUNDS.has(sound_name):
        push_error("AudioManager: unknown sound '%s'" % sound_name)
        return

    var player := _get_free_player()
    if player == null:
        return   # pool exhausted — skip rather than crash

    player.stream     = SOUNDS[sound_name]
    player.volume_db  = volume_db
    player.pitch_scale = pitch
    player.play()

func play_sfx_at(sound_name: StringName, world_pos: Vector2, volume_db: float = 0.0) -> void:
    # For 2D positional audio, create a temporary AudioStreamPlayer2D instead:
    var player2d := AudioStreamPlayer2D.new()
    get_tree().current_scene.add_child(player2d)
    player2d.position   = world_pos
    player2d.stream     = SOUNDS.get(sound_name)
    player2d.volume_db  = volume_db
    player2d.play()
    # Auto-free when done:
    player2d.finished.connect(player2d.queue_free)

func _get_free_player() -> AudioStreamPlayer:
    for player in _sfx_pool:
        if not player.playing:
            return player
    return null   # all busy

# Music — single stream, cross-fade on change:
@onready var _music_a: AudioStreamPlayer = $MusicA
@onready var _music_b: AudioStreamPlayer = $MusicB
var _active_music: AudioStreamPlayer

func play_music(stream: AudioStream, fade_duration: float = 1.0) -> void:
    var next := _music_b if _active_music == _music_a else _music_a
    next.stream      = stream
    next.volume_db   = -80.0
    next.play()
    var tw := create_tween().set_parallel(true)
    if _active_music and _active_music.playing:
        tw.tween_property(_active_music, "volume_db", -80.0, fade_duration)
    tw.tween_property(next, "volume_db", 0.0, fade_duration)
    _active_music = next
```

:::callout-tip[Add slight pitch randomisation for repeated sounds]
Hearing the exact same sample for every footstep or gunshot feels mechanical.
 One line fixes it:

```gdscript
AudioManager.play_sfx("footstep", 0.0, randf_range(0.95, 1.05))
```
:::

## 5 · Save System

Godot's `ResourceSaver` and `ResourceLoader` (covered
 briefly in Chapter 6) provide an easy JSON-like save format for custom
 Resources. For a production save system, you want:

- A typed `SaveData` Resource that holds all persistent state
- An autoload `SaveSystem` that handles read/write
- Writing to `user://` (the OS-specific user data directory)
- Multiple save slots via different filenames

```gdscript
# save_data.gd
class_name SaveData
extends Resource

@export var player_name:    String = "Hero"
@export var current_level:  int    = 1
@export var total_score:    int    = 0
@export var coins_total:    int    = 0
@export var unlocked_levels: Array[int] = [1]
@export var settings_volume: float = 1.0
@export var play_time_seconds: float = 0.0

# save_system.gd  (autoload name: SaveSystem)
class_name SaveSystem
extends Node

const SAVE_DIR  := "user://saves/"
const SAVE_EXT  := ".tres"
const MAX_SLOTS := 3

func _ready() -> void:
    # Make sure the save directory exists:
    if not DirAccess.dir_exists_absolute(SAVE_DIR):
        DirAccess.make_dir_absolute(SAVE_DIR)

func save(data: SaveData, slot: int = 0) -> Error:
    var path := _slot_path(slot)
    var err  := ResourceSaver.save(data, path)
    if err != OK:
        push_error("SaveSystem: failed to save slot %d (%s)" % [slot, error_string(err)])
    return err

func load_slot(slot: int = 0) -> SaveData:
    var path := _slot_path(slot)
    if not ResourceLoader.exists(path):
        return SaveData.new()   # fresh data if no save file
    var data := ResourceLoader.load(path) as SaveData
    if data == null:
        push_error("SaveSystem: corrupt save in slot %d" % slot)
        return SaveData.new()
    return data

func delete_slot(slot: int) -> void:
    var path := _slot_path(slot)
    if ResourceLoader.exists(path):
        DirAccess.remove_absolute(path)

func get_slot_info(slot: int) -> Dictionary:
    var path := _slot_path(slot)
    if not ResourceLoader.exists(path):
        return {"exists": false}
    var data := load_slot(slot)
    return {
        "exists":       true,
        "level":        data.current_level,
        "score":        data.total_score,
        "play_time":    data.play_time_seconds,
        "player_name":  data.player_name,
    }

func save_progress(level: int) -> void:
    var data: SaveData = GameManager.current_save_data
    data.current_level = level
    if not level in data.unlocked_levels:
        data.unlocked_levels.append(level)
    save(data, GameManager.active_slot)

func _slot_path(slot: int) -> String:
    return SAVE_DIR + "slot_%02d" % slot + SAVE_EXT
```

:::callout-key[user:// vs res://]
`res://` is read-only at runtime on exported builds — it maps
 to the game's installation directory (or PCK file). `user://` maps
 to a writable directory the OS provides for the app: on Windows it's
 `%APPDATA%\Godot\app_userdata\<ProjectName>`, on Linux it's
 `~/.local/share/godot/app_userdata/<ProjectName>`. Always
 save user data to `user://`.
:::

## 6 · Autoload Load Order

Autoloads are instantiated in the order they appear in the Autoload list
 (top to bottom). This matters when one autoload's `_ready()`
 calls another:

| Rule | Why |
| --- | --- |
| Put dependencies first | If GameManager calls `EventBus.emit()` in `_ready()`, EventBus must be above GameManager in the list. |
| Avoid circular dependencies | If A calls B in \_ready() and B calls A in \_ready(), one of them runs before the other exists. Use deferred calls or signals instead. |
| Don't store autoload references at class scope | `var gm := GameManager` at script level runs when the script loads, potentially before GameManager is ready. Access inside \_ready() or later. |

```gdscript
# Safe: access inside _ready(), not at top of file
extends Node

func _ready() -> void:
    # GameManager is definitely loaded by now:
    label.text = "Score: %d" % GameManager.score

# UNSAFE: runs before autoloads are ready
var _score_ref := GameManager.score  # ERROR if GameManager isn't loaded yet
```

## 7 · Common Pitfalls

| Pitfall | Fix |
| --- | --- |
| Everything goes in the autoload (god object) | Autoloads should be systems (Audio, Save, Events), not catch-alls. If your GameManager has 1000 lines, split it. |
| Autoload holds scene-specific references | Autoloads survive scene changes; scene nodes don't. Storing a reference to a Level node in GameManager causes a dangling reference after the level unloads. Use EventBus signals instead. |
| Forgetting to disconnect EventBus listeners | Always disconnect in `_exit_tree()` or use lambdas with `CONNECT_ONE_SHOT`. |
| Testing is impossible because scripts depend on autoloads | For unit-testable code, inject dependencies as function parameters rather than calling autoloads directly. Reserve direct autoload access for integration glue code. |
| Save file corruption on crash mid-write | Write to a temporary file, then rename it over the target path atomically. FileAccess doesn't do this automatically. |

:::summary
## Chapter Summary

| Concept | Quick reference |
| --- | --- |
| Autoload | Script/scene in Project Settings → Autoload. Lives at /root/Name. Persists across scene changes. |
| Access | Use the registered name directly: `GameManager.score`. Add `class_name` for typed autocompletion. |
| Event Bus | Central autoload with only signal declarations. Emitters and listeners only reference the bus — not each other. |
| Disconnect | Always disconnect bus listeners in `_exit_tree()` to prevent dangling callbacks. |
| GameManager | Owns global state (score, lives, level). Handles faded scene transitions. Does NOT hold scene node references. |
| AudioManager | Pool of AudioStreamPlayer nodes. `play_sfx("name")` from anywhere. Cross-fade for music. |
| SaveData | Custom Resource with @export fields. Saved with ResourceSaver.save() to user://saves/slot\_00.tres. |
| SaveSystem | Autoload wrapping ResourceSaver/Loader. Provides save(slot), load\_slot(slot), get\_slot\_info(slot). |
| Load order | Autoloads load top-to-bottom. Dependencies must appear above their dependents. |

**If you remember nothing else:** EventBus + GameManager + AudioManager
 are the three autoloads every non-trivial Godot game needs. EventBus keeps
 scenes decoupled. GameManager owns state that crosses scene boundaries.
 AudioManager plays sounds from anywhere without owning AudioStreamPlayer nodes.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Write the two signals and their connection/emission code to implement
 this flow using EventBus: a chest emits an event when opened containing
 the item name; a quest tracker listens and marks the "find the artifact"
 quest step complete when the artifact chest is opened.

::::solution[Solution]
```gdscript
# event_bus.gd (add this signal):
signal chest_opened(item_name: StringName)

# chest.gd
extends Area2D
@export var item_name: StringName = "artifact"

func _on_interact() -> void:
    $OpenAnimator.play("open")
    EventBus.chest_opened.emit(item_name)
    # ... give item to player ...

# quest_tracker.gd
extends Node

func _ready() -> void:
    EventBus.chest_opened.connect(_on_chest_opened)

func _exit_tree() -> void:
    EventBus.chest_opened.disconnect(_on_chest_opened)

func _on_chest_opened(item: StringName) -> void:
    if item == "artifact":
        complete_quest_step("find_the_artifact")
```
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Add a `play_sfx_pitched` helper to AudioManager that plays a
 sound with a random pitch between `min_pitch` and `max_pitch`,
 defaulting to 0.9–1.1. Then show how you'd call it for a footstep sound
 that sounds natural.

::::solution[Solution]
```gdscript
# audio_manager.gd — add this method:
func play_sfx_pitched(sound_name: StringName,
        min_pitch: float = 0.9,
        max_pitch: float = 1.1,
        volume_db: float = 0.0) -> void:
    play_sfx(sound_name, volume_db, randf_range(min_pitch, max_pitch))

# Usage in a player footstep script:
func _on_footstep_frame() -> void:
    AudioManager.play_sfx_pitched("footstep", 0.88, 1.12, -3.0)
```
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Implement a `load_scene_with_loading_bar(path: String)` method
 in GameManager that uses Godot's **background loading**
 (`ResourceLoader.load_threaded_request` +
 `load_threaded_get_status`) to show a progress bar while the
 next scene loads.

::::solution[Solution]
```gdscript
# game_manager.gd — add this method:
func load_scene_with_loading_bar(path: String) -> void:
    # Fade to loading screen:
    await _fade_to_black(0.3)
    get_tree().change_scene_to_file("res://scenes/ui/loading_screen.tscn")

    # Request background load:
    ResourceLoader.load_threaded_request(path)

    # Poll until complete:
    var progress := []
    while true:
        var status := ResourceLoader.load_threaded_get_status(path, progress)
        match status:
            ResourceLoader.THREAD_LOAD_IN_PROGRESS:
                # progress[0] is 0.0 – 1.0
                EventBus.loading_progress.emit(progress[0] if not progress.is_empty() else 0.0)
                await get_tree().process_frame
            ResourceLoader.THREAD_LOAD_LOADED:
                break
            _:
                push_error("Failed to load: " + path)
                return

    var packed: PackedScene = ResourceLoader.load_threaded_get(path)
    get_tree().change_scene_to_packed(packed)
    await _fade_from_black(0.3)

func _fade_to_black(dur: float) -> void:
    var tw := create_tween()
    tw.tween_property($FadeLayer/FadeRect, "modulate:a", 1.0, dur)
    await tw.finished

func _fade_from_black(dur: float) -> void:
    var tw := create_tween()
    tw.tween_property($FadeLayer/FadeRect, "modulate:a", 0.0, dur)
    await tw.finished
```
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Write a `SaveSystem.autosave()` function that saves to a
 dedicated autosave slot (slot index 99) and also keeps the last three
 autosaves as rotating backups (slot\_99\_0, slot\_99\_1, slot\_99\_2), cycling
 through them so the oldest is always overwritten.

::::solution[Solution]
```gdscript
# save_system.gd
const AUTOSAVE_SLOTS := 3
var _autosave_index : int = 0

func autosave() -> void:
    var data: SaveData = GameManager.current_save_data
    var path := SAVE_DIR + "autosave_%d" % _autosave_index + SAVE_EXT
    var err := ResourceSaver.save(data, path)
    if err == OK:
        _autosave_index = (_autosave_index + 1) % AUTOSAVE_SLOTS
    else:
        push_error("Autosave failed: " + error_string(err))

func get_latest_autosave() -> SaveData:
    # The latest save is the one written just before the current index
    var latest := (_autosave_index - 1 + AUTOSAVE_SLOTS) % AUTOSAVE_SLOTS
    var path := SAVE_DIR + "autosave_%d" % latest + SAVE_EXT
    if not ResourceLoader.exists(path):
        return SaveData.new()
    return ResourceLoader.load(path) as SaveData
```
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Design a complete **settings system** using an autoload:
 a `SettingsData` Resource with fields for master/sfx/music volume,
 fullscreen toggle, and control bindings (Dictionary keyed by action name).
 A `SettingsManager` autoload loads settings on startup, applies
 them immediately (AudioServer bus volumes, DisplayServer fullscreen,
 InputMap rebinds), and saves on change. Show how the Settings UI scene
 calls SettingsManager to apply and persist a volume change.

::::solution[Solution]
```gdscript
# settings_data.gd
class_name SettingsData
extends Resource

@export_range(-80.0, 0.0, 0.5) var master_volume_db: float  = 0.0
@export_range(-80.0, 0.0, 0.5) var sfx_volume_db:    float  = 0.0
@export_range(-80.0, 0.0, 0.5) var music_volume_db:  float  = 0.0
@export var fullscreen: bool = false
# key: action name, value: InputEvent (serialised as Dictionary for .tres)
@export var bindings: Dictionary = {}

# settings_manager.gd  (autoload: SettingsManager)
class_name SettingsManager
extends Node

const SETTINGS_PATH := "user://settings.tres"
var data: SettingsData

func _ready() -> void:
    if ResourceLoader.exists(SETTINGS_PATH):
        data = ResourceLoader.load(SETTINGS_PATH) as SettingsData
    if data == null:
        data = SettingsData.new()
    _apply_all()

func _apply_all() -> void:
    _apply_audio()
    _apply_display()
    _apply_bindings()

func _apply_audio() -> void:
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), data.master_volume_db)
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"),    data.sfx_volume_db)
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"),  data.music_volume_db)

func _apply_display() -> void:
    if data.fullscreen:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
    else:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _apply_bindings() -> void:
    for action in data.bindings.keys():
        InputMap.action_erase_events(action)
        InputMap.action_add_event(action, data.bindings[action])

func set_sfx_volume(db: float) -> void:
    data.sfx_volume_db = db
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"), db)
    _save()

func set_fullscreen(enabled: bool) -> void:
    data.fullscreen = enabled
    _apply_display()
    _save()

func rebind(action: StringName, event: InputEvent) -> void:
    data.bindings[action] = event
    InputMap.action_erase_events(action)
    InputMap.action_add_event(action, event)
    _save()

func _save() -> void:
    ResourceSaver.save(data, SETTINGS_PATH)

# settings_ui.gd — example UI scene
extends Control

@onready var sfx_slider: HSlider = $SFXSlider

func _ready() -> void:
    sfx_slider.value = SettingsManager.data.sfx_volume_db
    sfx_slider.value_changed.connect(func(v): SettingsManager.set_sfx_volume(v))
```
::::
:::

Godot 4.6 Complete Reference · Part II — Architecture & Systems · Generated for self-study. Edit freely.
