---
title: "Nodes, Scenes & the Scene Tree — Godot's Core Architecture"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 3"
meta:
  - "Est. study time: ~90 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch3_nodes_scenes.html"
---

## Overview

Chapters 1 and 2 taught you the surface of Godot — the buttons, the docks, the
 shortcuts. This chapter teaches you the *idea* underneath all of it. Nodes
 and scenes are Godot's answer to a deceptively hard question: how do you build
 complex games from reusable pieces without everything becoming a tangled mess?

The node/scene system is the single most important thing to understand about Godot.
 Every part of this book — physics, signals, UI, AI, networking — is just nodes and
 scenes applied to a specific domain. Get this chapter right and everything else will
 click into place faster.

:::callout-key[Prerequisites]
- Chapters 1–2: you can open Godot, create a project, add nodes, and attach scripts.
- Basic programming knowledge: classes, inheritance, and objects.
:::

## 1. What is a Node?

:::callout-intuition[Intuition — nodes are components with a fixed interface]
Imagine you're building a robot out of LEGO. Each piece (wheel, sensor, motor)
 is a self-contained unit that does one thing well. You snap pieces together to
 form the robot. In Godot, nodes are those pieces. A `Sprite2D` draws
 a texture. A `CollisionShape2D` defines a hit area. An
 `AudioStreamPlayer` plays a sound. You compose them into a scene —
 the "robot" — and that scene becomes one reusable unit you can snap into a larger
 scene.
:::

More precisely: a **node** is an object that inherits from Godot's
 built-in `Node` class. Every node has, at minimum:

- A **name** — unique among its siblings in the tree.
- A **parent** — the node directly above it in the hierarchy (or `null` for the root).
- Zero or more **children** — nodes directly below it.
- An optional **script** — a GDScript (or C#) file attached to it.
- Zero or more **groups** — string tags for batch operations.

A selection of Godot's built-in node types. Each icon represents a different class. Source: Godot documentation (CC BY 3.0).

### The Node base class — properties every node shares

Because every node inherits from `Node`, every node automatically has
 these properties and methods. You'll use them constantly:

| Property / Method | Type | What it does |
| --- | --- | --- |
| `name` | `StringName` | The node's name as shown in the Scene dock. Must be unique among siblings. |
| `get_parent()` | `Node` | Returns the parent node, or `null` if this is the root. |
| `get_children()` | `Array[Node]` | Returns all direct children as an array. |
| `get_child(idx)` | `Node` | Returns the child at index `idx` (0-based, left to right in Scene dock). |
| `get_child_count()` | `int` | How many direct children this node has. |
| `add_child(node)` | void | Adds `node` as a child. The child immediately enters the scene tree. |
| `remove_child(node)` | void | Removes a child from the tree (does *not* free it from memory). |
| `queue_free()` | void | Schedules the node (and all its children) for deletion at the end of the current frame. |
| `is_inside_tree()` | `bool` | `true` if the node is currently part of the scene tree. |
| `get_tree()` | `SceneTree` | Returns the global SceneTree object. From it you can change scenes, pause, get all nodes in a group, etc. |
| `get_node(path)` | `Node` | Finds a node by path string relative to this node. |
| `find_child(pattern)` | `Node` | Recursive search for a child matching a name pattern. |
| `process_mode` | `ProcessMode` | Controls whether the node's `_process` runs while the game is paused. |

### The node type hierarchy

Godot ships with hundreds of built-in node types. They're organized in a class
 hierarchy — each type adds capabilities on top of its parent. Here's the part of
 the tree you'll use most:

```
Node  ← every node starts here
├── Node2D  ← adds position, rotation, scale, z-index in 2D
│   ├── CanvasItem  ← adds visibility, modulate, material
│   │   ├── Sprite2D  ← draws a texture
│   │   ├── AnimatedSprite2D  ← frame-based animation
│   │   ├── Label  ← draws text
│   │   └── Line2D, Polygon2D, …
│   ├── CollisionShape2D  ← defines a physics hit area
│   ├── PhysicsBody2D
│   │   ├── CharacterBody2D  ← player-controlled physics
│   │   ├── RigidBody2D  ← physics-simulated body
│   │   └── StaticBody2D  ← immovable (floors, walls)
│   └── Camera2D, TileMapLayer, …
├── Node3D  ← adds Transform3D (position, rotation, scale) in 3D
│   ├── MeshInstance3D, Camera3D, Light3D, …
│   └── PhysicsBody3D → CharacterBody3D, RigidBody3D, …
├── Control  ← UI nodes (anchors, layout, focus)
│   ├── Button, Label, LineEdit, TextEdit, …
│   └── Container → VBoxContainer, HBoxContainer, …
└── AudioStreamPlayer, Timer, AnimationPlayer, HTTPRequest, …

```

:::callout-tip[Find any node type in the docs instantly]
Press F1 in the editor (or **Help → Search Help**) to open the
 in-editor class reference. Type any node name to see every property, method, and
 signal it has — with descriptions. This is faster than opening a browser.
:::

:::callout-pitfall[Watch out for]
- **Confusing 2D and 3D nodes.** `Sprite2D` only works in 2D scenes; `MeshInstance3D` only in 3D. Mixing them in the same scene is possible but unusual and requires care with coordinate systems.
- **Thinking "node" means "game object."** A single game object (e.g., a player) is typically made of *several* nodes working together: a CharacterBody2D, a Sprite2D child, a CollisionShape2D child, an AnimationPlayer child. The "game object" is the whole group, not a single node.
:::

## 2. The Scene Tree

:::callout-intuition[The scene tree is the live running game]
When you press F5, Godot loads your main scene and adds its nodes to
 the **scene tree** — the global hierarchical structure that contains
 every active node in the running game. The engine then drives the tree: it calls
 `_process(delta)` on every node each frame, handles physics, processes
 input, and renders everything. The scene tree *is* the game.
:::

### Root, Viewport, and the main loop

The scene tree always has a fixed top-level structure you can't change:

```
SceneTree  ← the global object, not a node itself
└── root  ← a Window node (the game window)
    └── YourMainScene  ← whatever scene you set as main
        ├── Player
        │   ├── Sprite2D
        │   └── CollisionShape2D
        ├── Level
        └── HUD

```

`SceneTree` is accessible from any node via `get_tree()`.
 It's the control panel for the whole running game — from it you can:

| Method | What it does |
| --- | --- |
| `get_tree().change_scene_to_file("res://level2.tscn")` | Swap to a completely different scene (e.g., level transitions). |
| `get_tree().change_scene_to_packed(packed_scene)` | Swap to a PackedScene loaded in code. |
| `get_tree().reload_current_scene()` | Restart the current scene (useful for "retry" buttons). |
| `get_tree().paused = true` | Pause the whole game. Nodes with `process_mode = ALWAYS` keep running (used for pause menus). |
| `get_tree().quit()` | Exit the game cleanly. |
| `get_tree().get_nodes_in_group("enemies")` | Returns an array of all nodes currently in the group "enemies". |
| `get_tree().root` | The root Window node. Rarely needed directly. |

### Entering and exiting the tree

A node is **in the scene tree** when it has been added as a child of
 another node that is itself in the tree (all the way up to root). Nodes that haven't
 been added yet — for example, a node you just created with `Node.new()`
 but haven't called `add_child()` on — are *outside* the tree.
 They don't receive `_process` calls, don't get rendered, and can't use
 `get_tree()`.

This matters for two common patterns:

:::example[Example 2.1 — Spawning a bullet at runtime]
A Player node fires a bullet. The bullet is defined in its own scene
 (`bullet.tscn`). Spawn it at the player's position and add it to
 the scene tree so it starts moving.

::::answer[Key idea]
Load the packed scene, instantiate it, set its position, then
 `add_child()` it to put it in the tree.
::::

player.gd

```gdscript
extends CharacterBody2D

# Preload the scene once at parse time (more efficient than load() each frame)
const BulletScene: PackedScene = preload("res://scenes/bullet.tscn")

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("shoot"):
        _spawn_bullet()

func _spawn_bullet() -> void:
    var bullet: Node2D = BulletScene.instantiate()

    # Add to the parent scene (not to self) so the bullet isn't
    # destroyed when the player dies
    get_parent().add_child(bullet)

    # Position it at the player's world position
    bullet.global_position = global_position
```

**Why `get_parent().add_child()` and not `add_child()`?**
 If the bullet were a child of the Player, destroying the Player would also
 destroy all its bullets mid-flight. Adding to the parent scene keeps bullets
 alive independently. This is the standard Godot spawning pattern.
:::

## 3. Scenes as Files

:::callout-intuition[A scene is just a saved node tree]
When you save a scene in Godot (Ctrl+S), the entire node tree — the
 hierarchy, every property value, every attached script reference — gets written to
 a `.tscn` file (or `.scn` for binary). That file is
 self-contained. You can open it, edit it, version-control it, and instantiate it
 as many times as you want in other scenes.
:::

### What a .tscn file looks like

`.tscn` files are plain text. You rarely need to read them, but knowing
 their structure helps you understand what Godot is storing. Here's a minimal example:

```
[gd_scene load_steps=2 format=3]

[ext_resource type="Script" path="res://player.gd" id="1"]

[node name="Player" type="CharacterBody2D"]
script = ExtResource("1")

[node name="Sprite2D" type="Sprite2D" parent="Player"]
position = Vector2(0, 0)

[node name="CollisionShape2D" type="CollisionShape2D" parent="Player"]
shape = CapsuleShape2D
```

Each `[node]` block is one node. Properties that differ from the engine
 default are listed below the header. Properties left at their defaults are
 *not* written to the file — this keeps `.tscn` files small and
 readable in diffs.

:::callout-tip[.tscn vs .scn]
`.tscn` is human-readable text — use this for everything in version
 control. `.scn` is a compact binary format — faster to load, but not
 diff-able. You can convert between them via *Project → Export → Convert
 Scene(s) to Binary*. For development, always prefer `.tscn`.
:::

### PackedScene — scenes as resources in code

From GDScript's perspective, a saved `.tscn` file is a
 **`PackedScene`** resource. You load it, then call
 `.instantiate()` to get a live node tree you can add to the scene.

```gdscript
# Option 1: preload() — resolved at parse time, before the game runs
# Use this when you always need the scene (it's guaranteed to be available)
const EnemyScene: PackedScene = preload("res://scenes/enemy.tscn")

# Option 2: load() — resolved at runtime
# Use this for large assets or scenes chosen dynamically
var level_path: String = "res://levels/level_%d.tscn" % current_level
var LevelScene: PackedScene = load(level_path)

# Instantiate (creates the node tree in memory but doesn't add it to the scene yet)
var enemy: Node = EnemyScene.instantiate()

# Add to the tree to make it live
add_child(enemy)
```

:::callout-warning[preload() vs load()]
`preload()` requires the path to be a *string literal* known at
 write time — you cannot use a variable. It happens before `_ready()`
 runs. `load()` accepts dynamic paths (variables) and runs at the moment
 the line is executed. For a scene you always need, `preload()` is safer
 (the editor validates the path exists). For anything conditional or dynamic, use
 `load()`.
:::

## 4. Instancing Scenes

:::callout-intuition[Instancing is the core reuse mechanism]
You build a "Coin" scene once — with its Sprite2D, CollisionShape2D, and pickup
 script. Then you *instance* it fifty times in your level scene. Each
 instance is an independent copy that runs its own script and can be modified
 independently, but they all share the same underlying `.tscn` definition.
 Change the master scene and all instances update automatically. This is Godot's
 equivalent of prefabs in Unity.
:::

Multiple instances of a "Ball" scene placed in a level. Each is independent but shares the same scene definition. Source: Godot documentation (CC BY 3.0).

### Instancing in the editor

To place an instance of an existing scene into your current scene:

1. In the Scene dock, click the **chain-link icon** at the top (or press Ctrl+Shift+A).
2. A file browser appears. Navigate to your `.tscn` file and double-click it.
3. The instanced scene appears as a single node in the Scene dock, with a small film-strip icon indicating it's an instance.
4. You can move, rotate, and scale it like any node. You can also override individual properties in the Inspector — the yellow dot appears on overridden properties.

:::callout-tip[Drag-and-drop instancing]
Even faster: drag a `.tscn` file directly from the FileSystem dock
 into the viewport or Scene dock. It instantly creates an instance at the drop
 position.
:::

A main scene with instanced sub-scenes. The film-strip icons mark instances. Source: Godot documentation (CC BY 3.0).

### Instancing in code

:::example[Example 4.1 — Spawning 10 coins in a grid]
In a level's `_ready()`, spawn 10 Coin instances arranged in two rows
 of five, spaced 64 px apart horizontally and 80 px apart vertically.

::::answer[Result]
10 Coin nodes appear in the scene tree at runtime, in a 5×2 grid starting
 at (100, 100).
::::

level.gd

```gdscript
extends Node2D

const CoinScene: PackedScene = preload("res://scenes/coin.tscn")

const COLS: int = 5
const ROWS: int = 2
const SPACING: Vector2 = Vector2(64.0, 80.0)
const ORIGIN: Vector2 = Vector2(100.0, 100.0)

func _ready() -> void:
    for row in range(ROWS):
        for col in range(COLS):
            var coin: Node2D = CoinScene.instantiate()
            add_child(coin)
            coin.position = ORIGIN + Vector2(col * SPACING.x, row * SPACING.y)
```

Note: `coin.position` must be set *after*
 `add_child(coin)`, because `position` is local to the
 parent's coordinate space, and the parent relationship is only established by
 `add_child()`.
:::

### The composition pattern — why this matters

Instancing enables **composition**: building complex things by
 combining simple reusable pieces, rather than inheriting from a big base class.
 In Godot, composition is almost always the right approach.

Example: a Player scene

Instead of one God-class `Player.gd` with 800 lines of code
 for movement, animation, health, sounds, and hitboxes, you build:

- `CharacterBody2D` (root) with `player.gd` — movement only
- `Sprite2D` child — visual
- `AnimationPlayer` child — animation state
- `CollisionShape2D` child — physics shape
- `HealthComponent` (instanced sub-scene) — HP, damage, death
- `HurtBox` (instanced sub-scene) — taking damage
- `HitBox` (instanced sub-scene) — dealing damage

Each piece is simple, testable independently, and reusable in other scenes
 (e.g., enemies can use the same HealthComponent scene).

:::callout-pitfall[Watch out for]
- **Editing an instance changes only that instance.** To change the master scene (affecting all instances), double-click the instance in the Scene dock, or press Ctrl+E to open it for editing.
- **Overrides on instances aren't inherited from master changes.** If you override a property on an instance (yellow dot), and then change that property in the master scene, the instance keeps its overridden value. Only non-overridden properties pick up master changes.
- **Circular instancing causes an error.** Scene A cannot instance Scene B if Scene B also instances Scene A. Godot detects this and shows an error.
:::

## 5. Finding Nodes

:::callout-intuition[Scripts need references to other nodes]
A script attached to one node often needs to talk to another — the player's script
 needs the camera, the enemy needs the health bar, the HUD needs the score counter.
 Godot gives you several ways to get a reference. Choosing the right one keeps your
 code clean and avoids the most common beginner bugs.
:::

### $ shorthand — the everyday workhorse

`$NodeName` is shorthand for `get_node("NodeName")`. It
 returns the direct child of the current node whose name exactly matches the string.
 Combined with `@onready`, this is how you cache child references at
 startup:

```gdscript
extends CharacterBody2D

# Resolved during _ready() — safe to use from that point on
@onready var sprite: Sprite2D = $Sprite2D
@onready var anim: AnimationPlayer = $AnimationPlayer
@onready var collision: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
    print(sprite.texture)   # fine — sprite is resolved
```

`$` only searches *direct children* by default. For deeper paths,
 chain names with `/`:

```gdscript
@onready var label: Label = $HUD/HealthBar/Label
#                            ^    ^           ^
#                            |    |           grandchild named "Label"
#                            |    child named "HealthBar"
#                            direct child named "HUD"
```

### get\_node() and node paths

`get_node(path)` is what `$` desugars to. It accepts a
 `NodePath` or plain string. Paths work like file system paths:

| Path string | Meaning |
| --- | --- |
| `"Sprite2D"` | Direct child named Sprite2D. |
| `"HUD/Label"` | Child HUD, then its child Label. |
| `".."` | Parent node. |
| `"../Sibling"` | A sibling node (go up to parent, then down). |
| `"/root/Main/Player"` | Absolute path from tree root. Fragile — avoid unless necessary. |

:::callout-warning[Avoid absolute paths and "../" chains]
Paths like `"/root/Main/UI/HUD/Label"` or `"../../Player"`
 break the moment you rename or rearrange nodes. Prefer `@onready` +
 `$` for children, and **signals** (Chapter 5) for
 communication between unrelated nodes. Use absolute paths only as a last resort.
:::

### find\_child() and groups

#### find\_child()

Searches the entire subtree recursively for a node matching a name pattern
 (wildcards supported):

```gdscript
# Find the first node named exactly "HealthBar" anywhere in the subtree
var bar: Node = find_child("HealthBar")

# Wildcard — find first node whose name starts with "Enemy"
var enemy: Node = find_child("Enemy*")
```

`find_child()` is slower than `$` because it walks the whole
 subtree. Use it sparingly — it's best for one-time lookups in `_ready()`,
 not in `_process()`.

#### Groups — broadcast to many nodes at once

Groups are string tags you assign to nodes. Once tagged, you can find them all
 at once, or call a method on all of them simultaneously:

```gdscript
# --- Assigning groups (usually done in editor, but can be done in code) ---
func _ready() -> void:
    add_to_group("enemies")
    add_to_group("damageable")

# --- From any other script: ---

# Get all nodes in a group
var enemies: Array = get_tree().get_nodes_in_group("enemies")
for e in enemies:
    print(e.name)

# Call a method on every node in a group (they must all have the method)
get_tree().call_group("enemies", "stun", 2.0)
# Equivalent to: for e in enemies: e.stun(2.0)

# Check if this node is in a group
if is_in_group("damageable"):
    take_damage(10)
```

:::callout-connect[Groups vs Signals]
Groups are best for *"do this to everyone who matches"* — clearing all
 enemies, pausing all animated objects, collecting all checkpoints. Signals (Ch 5)
 are better for *"notify whoever cares that this specific event happened."*
 The two tools complement each other rather than compete.
:::

:::example[Example 5.1 — Freeze all enemies on pause]
When the player opens the pause menu, all enemies should stop moving. Each enemy
 is in the group `"enemies"` and has a `set_frozen(bool)`
 method. Call it on all enemies from the pause menu script.

::::answer[pause\_menu.gd]

::::

```gdscript
extends Control  # the pause menu is a UI node

func _on_pause_button_pressed() -> void:
    get_tree().paused = true
    # Freeze every node in the "enemies" group
    get_tree().call_group("enemies", "set_frozen", true)
    show()  # make the pause menu visible

func _on_resume_button_pressed() -> void:
    get_tree().call_group("enemies", "set_frozen", false)
    get_tree().paused = false
    hide()
```
:::

## 6. The Node Lifecycle

:::callout-intuition[Every node has a predictable life from birth to death]
From the moment a node is instantiated to the moment it's freed from memory,
 Godot calls a sequence of functions on it. You override these functions in your
 script to plug your code into the right moment. Getting the order wrong — for
 example, trying to use a child node before `_ready()` — is the most
 common source of confusing null-reference errors.
:::

### All lifecycle functions in order

Node.new() /
instantiate() — The node object is created in memory. No children are set up yet. Scripts are attached but no lifecycle function has been called. Avoid accessing children here.

\_enter\_tree() — Called when the node is added to the scene tree (`add_child()` was called on a parent already in the tree). The node is now in the tree, but children may not be ready yet. Rarely overridden — use `_ready()` instead.

\_ready() — **The main initialization point.** Called once, after the node and all its children have entered the tree and had their own `_ready()` called. All `@onready` variables are resolved here. Safe to access children, set up signals, and initialize state. Children's `_ready()` is called before the parent's.

\_process(delta) — Called every rendered frame. `delta` = seconds since last frame. Used for visual updates, non-physics movement, input polling, timers. Not called while the game is paused (unless `process_mode = ALWAYS`).

\_physics\_process(delta) — Called at a fixed rate (default 60 Hz, set in Project Settings → Physics → Common → Physics Ticks Per Second). `delta` is constant at exactly `1 / ticks_per_second`. Use for movement of physics bodies, collision checks, and anything that must be frame-rate independent.

\_input(event) — Called for every unhandled input event (key press, mouse click, gamepad button). Preferred over polling `Input` in `_process()` for one-shot actions. Call `get_viewport().set_input_as_handled()` to stop the event propagating further.

\_unhandled\_input(event) — Same as `_input()` but only fires if no other node (e.g., a UI Control) already consumed the event. Use this for gameplay input so UI elements can intercept first.

\_notification(what) — Low-level engine notifications (window focus, memory warnings, app pause on mobile). Rarely needed; `_ready()` and signals cover most use cases.

\_exit\_tree() — Called when the node is removed from the scene tree (either via `remove_child()` or as part of being freed). Use for cleanup: disconnect signals, stop audio, cancel HTTP requests. Children's `_exit_tree()` fires before the parent's.

freed from memory — After `_exit_tree()`, the node and all its children are freed. Any variable elsewhere still holding a reference to this node now holds an invalid reference — accessing it will crash. Always null-check or use `is_instance_valid(node)` before using stored references.

:::callout-tip[\_process vs \_physics\_process — the rule]
Move visuals and UI in `_process(delta)`. Move physics bodies
 (`CharacterBody2D`, `RigidBody2D`) and do collision checks
 in `_physics_process(delta)`. If you move a CharacterBody2D in
 `_process`, you'll get jitter because the physics engine runs at a
 different rate than rendering.
:::

### Freeing nodes — queue\_free() vs free()

There are two ways to destroy a node. You should almost always use the first:

queue\_free() — safe, deferred (use this)

Marks the node for deletion at the *end of the current frame*, after all
 scripts have finished executing. This means the node is still valid for the rest
 of the current frame — you can safely call `queue_free()` on yourself
 inside `_process()` without causing a crash.

```gdscript
func die() -> void:
    play_death_animation()
    queue_free()  # node lives until end of frame, then is deleted
```

free() — immediate (dangerous)

Destroys the node right now, mid-frame. Any code that runs after this call and
 still holds a reference to the now-freed node will crash with "Attempt to call
 function on a freed object." Only use `free()` on nodes you just
 created and haven't added to the tree yet (e.g., cleaning up a failed
 instantiation). In all other cases, use `queue_free()`.

:::example[Example 6.1 — A bullet that deletes itself on impact]
A bullet moves forward each physics frame. When it hits something
 (detected via `Area2D.body_entered` signal), it should deal damage
 and remove itself from the scene.

::::answer[bullet.gd]

::::

```gdscript
extends Area2D

const SPEED: float = 600.0
var direction: Vector2 = Vector2.RIGHT  # set by the spawner after instantiation

func _physics_process(delta: float) -> void:
    position += direction * SPEED * delta

func _ready() -> void:
    # Connect the signal in code (alternative to connecting in the editor)
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.has_method("take_damage"):
        body.take_damage(10)
    queue_free()  # safe: deferred deletion, won't crash mid-signal
```

Using `queue_free()` inside a signal callback is safe. Using
 `free()` there would crash because the signal system still has a
 reference to the node as it finishes dispatching the signal.
:::

### Practice problems — Section 6

:::problem[Problem 6.1 easy]{difficulty="easy"}
In what order do `_ready()` calls happen for a parent node and its
 children? Does the parent's `_ready()` run before or after the
 children's?

::::solution[Solution]
Children's `_ready()` fires **before** the parent's.
 Godot calls `_ready()` bottom-up: deepest children first, then their
 parents, then the root. This guarantees that when the parent's `_ready()`
 runs, all of its children are already initialized — so `@onready`
 variable lookups with `$ChildName` are always safe inside
 `_ready()`.
::::
:::

:::problem[Problem 6.2 easy]{difficulty="easy"}
What is the difference between `remove_child(node)` and
 `node.queue_free()`? When would you use each?

::::solution[Solution]
`remove_child(node)` takes the node out of the scene tree
 but **keeps it in memory**. The node's scripts stop running
 (no more `_process` calls), but you can add it back to the tree
 later with `add_child()`. Use this to temporarily hide/pause a node
 (e.g., pooling bullets for reuse).

`node.queue_free()` removes the node from the tree
 **and** frees its memory at end-of-frame. The node is gone
 permanently. Use this when you're done with the node and don't need it again.
::::
:::

:::problem[Problem 6.3 standard]{difficulty="standard"}
You have a HUD node that is a sibling of the Player node (both are children
 of Main). Write a line of GDScript inside `player.gd` that gets a
 reference to the HUD node using a relative path. Then rewrite it using an
 absolute path. Which should you prefer and why?

::::solution[Solution]
```gdscript
# Relative path (preferred)
@onready var hud: Node = get_node("../HUD")
# or equivalently:
@onready var hud: Node = $"../HUD"

# Absolute path (fragile — avoid)
@onready var hud: Node = get_node("/root/Main/HUD")
```

Prefer the relative path. If you rename the root scene from "Main" to
 something else, the absolute path breaks. The relative path only breaks if you
 rename the HUD node itself, which is less likely. Even better: use a signal
 or an autoload (Ch 11) so neither node needs a direct reference to the other.
::::
:::

:::summary
## Chapter Summary

### Core concepts

| Concept | One-line definition |
| --- | --- |
| **Node** | An object that inherits from `Node`. Has a name, parent, children, and optional script. The basic building block. |
| **Scene** | A saved tree of nodes (`.tscn` file). Can be instanced as many times as needed. |
| **Scene Tree** | The global hierarchy of all active nodes in the running game. Accessible via `get_tree()`. |
| **PackedScene** | A `.tscn` file as a resource in code. Call `.instantiate()` to create a live node tree from it. |
| **Instancing** | Placing a scene inside another scene. Each instance is independent but shares the master definition. |
| **preload()** | Loads a resource at parse time (compile-time path required). Safer for static assets. |
| **load()** | Loads a resource at runtime (dynamic paths allowed). Used for conditionally loaded content. |
| **$ shorthand** | `$Name` = `get_node("Name")`. Gets a direct child by name. Chain with `/` for deeper paths. |
| **Groups** | String tags on nodes. Use `get_tree().call_group()` to broadcast to all tagged nodes. |
| **queue\_free()** | Safe deferred deletion — node is freed at end of frame. Always prefer over `free()`. |

### Lifecycle order

`instantiate()` → `_enter_tree()` → children's
 `_ready()` → parent's `_ready()` → `_process()`
 / `_physics_process()` every frame → `_exit_tree()` →
 freed from memory.

### If you remember nothing else

**Build games by composing small, focused scenes — not by writing one giant
 script.** Each scene does one thing, can be tested alone, and can be reused
 anywhere. The scene tree is the running game; nodes are its atoms.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
What is the difference between `preload()` and `load()`?
 Give one scenario where you'd be forced to use `load()` instead of
 `preload()`.

::::solution[Solution]
`preload()` requires a string literal path known at write time —
 the editor validates the path exists when you save the script. It runs before
 `_ready()`, so the resource is guaranteed available. `load()`
 accepts any expression (variables, concatenated strings) and runs at the line
 it appears in code.

Forced to use `load()` example: loading a level scene
 dynamically based on a level number: `load("res://levels/level_%d.tscn" % level_num)`.
 You can't know the level number at write time, so `preload()` is
 impossible.
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
You call `queue_free()` on a node inside its own
 `_process()` function. Does the rest of the code in that
 `_process()` call still run? Is it safe?

::::solution[Solution]
Yes — the rest of `_process()` continues running normally.
 `queue_free()` only *schedules* deletion for the end of the
 frame. The node is still fully valid for the remainder of the current frame.
 This is exactly why `queue_free()` exists — so you can safely
 call it from anywhere without worrying about mid-frame crashes.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
Describe the composition approach for a simple enemy: it needs a visible sprite,
 a physics collision shape, a health system, and a hitbox that deals damage to the
 player. Name the node types you'd use for each concern and how you'd structure them
 as a scene tree.

::::solution[Solution]
One good structure:

```
CharacterBody2D  "Enemy"  [enemy.gd — movement, AI]
├── Sprite2D         [visual]
├── AnimationPlayer  [animations]
├── CollisionShape2D [physics body shape]
├── Area2D  "HitBox"  [deals damage on overlap]
│   └── CollisionShape2D
└── Area2D  "HurtBox"  [receives damage]
    └── CollisionShape2D
```

The health system can live in `enemy.gd` itself (for simplicity),
 or be a separate `HealthComponent` sub-scene instanced here — the
 latter lets you reuse the same health logic for the player, destructible crates,
 and anything else that can be damaged.
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Write the code to: (1) load `res://scenes/coin.tscn` as a
 PackedScene, (2) instantiate 5 copies, (3) add each to the current node as
 a child, (4) position them in a horizontal row starting at (50, 200), spaced
 100 px apart. Do it all inside `_ready()`.

::::solution[Solution]
```gdscript
const CoinScene: PackedScene = preload("res://scenes/coin.tscn")

func _ready() -> void:
    for i in range(5):
        var coin: Node2D = CoinScene.instantiate()
        add_child(coin)
        coin.position = Vector2(50.0 + i * 100.0, 200.0)
```
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
A node has an `@onready var timer: Timer = $Timer`. A teammate
 renames the Timer node to "CooldownTimer" in the Scene dock but forgets to
 update the script. Describe exactly what error you'll see at runtime and
 on which lifecycle call it will occur.

::::solution[Solution]
The error occurs during `_ready()` (when `@onready`
 assignments are evaluated). You'll see something like:

```
Node not found: "Timer" (relative to "/root/...YourNode").
```

The variable `timer` is assigned `null`. The first
 time any code tries to call a method on it (e.g., `timer.start()`),
 you'll get a second error:

```
Invalid call. Nonexistent function 'start' in base 'Null'.
```

Fix: update the script to `$CooldownTimer`, or rename the node
 back to "Timer".
::::
:::

:::problem[Problem M.6 challenge]{difficulty="challenge"}
You're building a wave-based game. At the start of each wave, spawn
 `N` enemies (where `N` increases each wave). When the
 last enemy dies, start the next wave. Describe the scene structure and the
 GDScript logic — which node tracks how many enemies are alive, how does it
 know when to start the next wave, and how do enemies signal their death?
 Write the key code snippets (no need for a complete working game).

::::solution[Solution]
**Scene structure:**

```
Node2D  "Main"  [main.gd — wave logic]
├── Node  "EnemyContainer"  [enemies are added here at runtime]
└── ...level nodes...
```

**main.gd — wave spawning and tracking:**

```gdscript
extends Node2D

const EnemyScene: PackedScene = preload("res://scenes/enemy.tscn")

var current_wave: int = 0
var enemies_alive: int = 0

@onready var enemy_container: Node = $EnemyContainer

func _ready() -> void:
    start_wave()

func start_wave() -> void:
    current_wave += 1
    var count: int = current_wave * 3  # 3, 6, 9… enemies per wave
    enemies_alive = count
    for i in range(count):
        var e: Node2D = EnemyScene.instantiate()
        enemy_container.add_child(e)
        e.position = Vector2(randf_range(50, 700), randf_range(50, 400))
        # Connect the enemy's "died" signal to our counter
        e.died.connect(_on_enemy_died)

func _on_enemy_died() -> void:
    enemies_alive -= 1
    if enemies_alive <= 0:
        start_wave()  # all dead — start next wave
```

**enemy.gd — emitting the signal:**

```gdscript
extends CharacterBody2D

signal died  # custom signal declared here

func take_damage(amount: int) -> void:
    health -= amount
    if health <= 0:
        died.emit()   # notify wave manager
        queue_free()
```

The key insight: enemies don't know about the wave manager. They just emit
 `died`. The wave manager connects to that signal when it spawns each
 enemy. This keeps the two scripts decoupled — the enemy could be reused in a
 non-wave game without any changes.
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
