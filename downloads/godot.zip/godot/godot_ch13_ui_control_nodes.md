---
title: "UI & Control Nodes — Building Game Interfaces in Godot 4.6"
source: "markdown"
---

Part III · Chapter 13

# UI & Control Nodes — Building Game Interfaces in Godot 4.6

Estimated reading time: 90 min · Prerequisites: Ch 4 (GDScript basics), Ch 12 (Autoloads)

## Overview

Every game needs a user interface: a health bar, a score display, inventory
 screens, pause menus, dialog boxes. Godot handles all of this with its
 **Control** node family — a complete UI toolkit built directly
 into the engine, fully resolution-aware, and scriptable with the same
 GDScript you already know.

Control nodes live in a separate coordinate space from Node2D and Node3D.
 Instead of world positions, they use **anchors** and
 **offsets** that define position relative to the parent
 container's edges. This means a health bar anchored to the top-left
 corner stays in the top-left regardless of window size — the foundation
 of responsive UI.

By the end of this chapter you will be able to:

- Understand the Control node coordinate model: rect, pivot, anchors, and offsets
- Use anchor presets to pin UI elements to screen edges and corners
- Build responsive layouts with VBoxContainer, HBoxContainer, GridContainer, and ScrollContainer
- Use and configure the most common widgets: Label, Button, ProgressBar, Slider, LineEdit
- Create and apply a project-wide Theme with custom StyleBoxes
- Layer HUD UI over a 3D or 2D game world using CanvasLayer
- Implement keyboard/controller navigation with focus neighbours

⬡ — Control — inherits CanvasItem → Node — base class for all UI widgets

The root class of Godot's entire UI system. Every widget — Button, Label, Panel, VBoxContainer, Slider — inherits from Control. It adds a rectangular layout rect (position + size), anchor and offset system for relative positioning, focus/mouse handling, theming, and tooltip support. You rarely add a bare Control node directly; instead you use its specialised children. But understanding Control's properties explains how *every* UI element is positioned and sized.

| Property | Default | What it does |
| --- | --- | --- |
| position | Vector2(0,0) | Top-left corner of the control's rect, relative to its parent. Managed by containers — don't set manually when inside a Container node |
| size | Vector2(0,0) | Width and height of the control. Containers compute this from minimum size + size\_flags |
| anchor\_left/right/top/bottom | 0 / 0 / 0 / 0 | Fraction (0–1) of the parent rect each edge is anchored to. 0 = left/top, 1 = right/bottom. Use preset buttons in the toolbar instead of setting manually |
| offset\_left/right/top/bottom | 0 each | Pixel offset from the anchor point — the actual edge position = anchor × parent\_size + offset |
| size\_flags\_horizontal | FILL | How this control requests space from its Container parent: FILL (take available space), EXPAND (claim extra share), SHRINK\_BEGIN/CENTER/END |
| size\_flags\_vertical | FILL | Same for vertical dimension |
| custom\_minimum\_size | Vector2(0,0) | Minimum size this control will never shrink below — useful to prevent labels collapsing to zero width |
| focus\_mode | NONE | NONE: can't receive keyboard/gamepad focus. CLICK: focus only on click. ALL: focusable by Tab key or gamepad — required for controller UI navigation |
| mouse\_filter | STOP | STOP: absorbs mouse events (normal). PASS: lets clicks through to nodes below. IGNORE: completely invisible to mouse |
| theme | null | Override the project theme for this control and all its children — useful for per-widget style overrides |
| tooltip\_text | "" | String shown in a floating tooltip on mouse hover — appears automatically, no code needed |
| clip\_contents | false | Clips child controls to this rect — useful for panels that should hide overflowing content |

Direct use:

Control itself is mainly used as an invisible layout spacer or hitbox overlay. For actual UI, use its descendants.

Anchors vs Containers:

anchors work best for fixed layouts (HUD elements anchored to screen corners). Containers work best for dynamic lists and responsive menus that need to reflow.

Controller support:

set

focus\_mode = FOCUS\_ALL

on every interactive widget and use the Focus Neighbour properties to define the D-pad navigation path.

## 1 · Control Node Basics

All UI elements inherit from **Control**. The fundamental
 properties that differ from Node2D:

| Property | Type | What it does |
| --- | --- | --- |
| `position` | Vector2 | Top-left corner of the rect relative to parent (in pixels) |
| `size` | Vector2 | Width and height of the control's rect |
| `custom_minimum_size` | Vector2 | Minimum size containers respect when laying out this control |
| `pivot_offset` | Vector2 | Point around which rotation and scale are applied (default top-left) |
| `rotation` | float (radians) | Rotates the control around pivot\_offset |
| `scale` | Vector2 | Scales the control around pivot\_offset |
| `modulate` | Color | Tint colour × alpha applied to this control and all children |
| `visible` | bool | Hide/show without freeing. Hidden controls still occupy layout space unless `clip_contents` differs |

### Rect and pivot

Unlike Node2D where `position` is the node's centre (or sprite's
 anchor point), a Control's `position` is always the
 **top-left corner** of its bounding rectangle. To rotate a
 button around its centre, set `pivot_offset = size / 2`:

```gdscript
@onready var btn: Button = $MyButton

func _ready() -> void:
    # Centre the pivot so rotation spins around the middle:
    btn.pivot_offset = btn.size / 2.0
    # Now animate rotation around that centre:
    var tw := create_tween().set_loops()
    tw.tween_property(btn, "rotation", TAU, 4.0)
```

### Mouse filter

The `mouse_filter` property controls how a Control node responds
 to mouse events:

| Value | Behaviour |
| --- | --- |
| `MOUSE_FILTER_STOP` (default for interactive controls) | Captures mouse events; stops them from reaching nodes below in the scene tree |
| `MOUSE_FILTER_PASS` | Receives the event but lets it continue to nodes below |
| `MOUSE_FILTER_IGNORE` (default for Label, TextureRect) | Completely ignores mouse events; they pass through as if this node weren't there |

Set `mouse_filter = MOUSE_FILTER_IGNORE` on any Control node
 you want to be purely visual — an HUD panel, a decorative frame — so it
 doesn't accidentally block clicks on the game world below.

## 2 · Anchors & Offsets

Anchors solve the responsive layout problem: how do you keep a health bar
 in the top-left corner when the window is resized? You *anchor* its
 edges to fractions of the parent's size, then define an *offset*
 (fixed pixel distance from each anchor).

Every Control has four anchor values — `anchor_left`,
 `anchor_top`, `anchor_right`, `anchor_bottom`
 — each a float from 0.0 (left/top edge of parent) to 1.0 (right/bottom edge).
 Four corresponding **offset** values define the pixel distance
 from each anchor to the control's edge.

```gdscript
# Pin a label to the top-right corner, 16px from each edge:







          Parent Container

          (0,0)
          (1,0)
          (0,1)
          (1,1)


          ScoreLabel






          anchor = 1.0
          offset_right = −16px



          Parent Container


          Background
          anchors 0→1 all sides
          offsets = 0





          Corner-anchored (top-right)
          Full-stretch (fills parent)


          Left: A label anchored to the top-right corner (anchor = 1.0) stays in the corner as the window resizes. Right: A panel with all anchors 0→1 and zero offsets always fills its parent.



var label: Label = $ScoreLabel
label.anchor_left   = 1.0
label.anchor_top    = 0.0
label.anchor_right  = 1.0
label.anchor_bottom = 0.0
label.offset_left   = -200.0   # 200px wide, growing leftward from right edge
label.offset_top    = 16.0
label.offset_right  = -16.0
label.offset_bottom = 48.0

# Stretch a panel to fill the full parent:
var panel: Panel = $Background
panel.anchor_left   = 0.0
panel.anchor_top    = 0.0
panel.anchor_right  = 1.0
panel.anchor_bottom = 1.0
panel.offset_left   = 0.0
panel.offset_top    = 0.0
panel.offset_right  = 0.0
panel.offset_bottom = 0.0
```

### Anchor presets

In the editor, select a Control and use the **Anchor Preset**
 drop-down in the toolbar (the icon with arrows) to quickly set common
 configurations. The most useful presets:

| Preset name | Effect |
| --- | --- |
| Top Left | Pinned to parent's top-left corner — size stays fixed |
| Top Right / Bottom Left / Bottom Right | Pinned to respective corner |
| Centre Top / Centre Left / etc. | Centred on one edge |
| Centre | Centred in the parent |
| Left Wide / Top Wide / etc. | Stretches along one axis, fixed on the other |
| Full Rect | Stretches to fill parent completely (most useful for background panels) |

:::callout-tip[Use anchor presets in code with set\_anchors\_and\_offsets\_preset()]
```gdscript
$HealthBar.set_anchors_and_offsets_preset(
    Control.PRESET_TOP_LEFT,
    Control.PRESET_MODE_KEEP_SIZE,
    16   # margin from the edge
)
```
:::

### Responsive layout — stretching with anchors

For a health bar that always fills a percentage of the screen width, anchor
 both left and right to 0.0 and 0.5 respectively (left half of screen),
 then set offsets for padding. As the window resizes, the bar's width tracks
 50 % of the window. Containers (next section) automate this for groups of
 controls.

:::callout-key[Container sizing: Size Flags]
Inside a container, each child Control has **size\_flags\_horizontal**
 and **size\_flags\_vertical**. The important values:

- `SIZE_FILL` — expand to fill available space
- `SIZE_EXPAND` — take extra space proportionally
- `SIZE_SHRINK_BEGIN / END / CENTER` — don't expand; align within the slot

Combine them: `SIZE_EXPAND | SIZE_FILL` is the most common —
 the control fills all available space and grabs extra space from the container.
:::

## 3 · Containers

Containers automatically lay out their children. You add Controls as children,
 set their size flags, and the container handles positions and sizes. Never
 manually set `position` or `size` on a Control inside
 a container — the container owns those values and overwrites them.

⬡ — VBoxContainer · HBoxContainer · GridContainer — all inherit BoxContainer → Container → Control

Layout containers that automatically arrange their children without any manual position-setting. **VBoxContainer** stacks children vertically. **HBoxContainer** lines them up horizontally. **GridContainer** fills a fixed number of columns in a grid. The container asks each child what size it wants, then sizes and positions everyone — resize the container and everything adapts.

| Property | Node | What it does |
| --- | --- | --- |
| separation | VBox/HBox | Pixel gap between children. Negative values overlap children (rare but valid for stacked card effects) |
| columns | GridContainer | Number of columns — children fill left-to-right, wrapping to a new row when this count is reached |
| alignment | VBox/HBox | BEGIN (default, pack to start), CENTER, END (pack to end) — affects where children cluster when they don't fill the full container |

| Child size\_flags | — | What it does |
| --- | --- | --- |
| SIZE\_FILL | expand\_v/h | The child tries to fill available space in the layout direction — without this, it only takes its minimum size |
| SIZE\_EXPAND | expand\_v/h | Combined with FILL: claims a share of remaining space. Multiple children with EXPAND share space equally (or by stretch\_ratio) |
| SIZE\_SHRINK\_CENTER | off-axis | Shrinks the child to minimum size and centres it in the off-axis direction (e.g. horizontal centering inside a VBox) |

Use VBoxContainer for:

vertical menus (main menu buttons, settings list), dialogue option lists, inventory rows.

Use HBoxContainer for:

toolbars, stat bars (icon + value side by side), horizontal tab bars, action button rows.

Use GridContainer for:

inventory grids, character stat sheets, keyboard rebinding tables, anything that flows in a fixed number of columns.

Key rule:

never set

position

on children of a Container — the container owns layout. Adjust size and size\_flags instead.

### VBoxContainer and HBoxContainer

The most used containers: VBox stacks children vertically, HBox stacks them
 horizontally. Set `separation` (gap between children) in the
 Inspector. Add a `VSeparator` or `HSeparator` node as
 a child to insert a visual divider.

```gdscript
# Build a vertical menu dynamically:
func populate_menu(items: Array[String]) -> void:
    var vbox := $MenuContainer   # VBoxContainer

    # Clear existing children:
    for child in vbox.get_children():
        child.queue_free()

    for label_text in items:
        var btn := Button.new()
        btn.text = label_text
        btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        btn.pressed.connect(func(): on_menu_item(label_text))
        vbox.add_child(btn)
```

### GridContainer

**GridContainer** arranges children in a grid with a fixed
 number of columns (set the `columns` property). Children fill
 left-to-right, top-to-bottom. All cells in the same column share the same
 width; all cells in the same row share the same height. Useful for inventory
 grids, skill trees, and option lists.

```gdscript
@onready var grid: GridContainer = $InventoryGrid

func draw_inventory(items: Array[ItemData]) -> void:
    for child in grid.get_children():
        child.queue_free()

    grid.columns = 5   # 5 columns

    for item in items:
        var slot := preload("res://ui/inventory_slot.tscn").instantiate()
        slot.set_item(item)
        grid.add_child(slot)

    # Empty slots to fill grid:
    var remaining := grid.columns - (items.size() % grid.columns)
    if remaining < grid.columns:
        for i in remaining:
            grid.add_child(Control.new())   # blank spacer
```

### MarginContainer and PanelContainer

**MarginContainer** adds uniform padding around its single child.
 Set `add_theme_constant_override("margin_left", 16)` etc. in code,
 or use the **Theme Overrides → Constants** section in the Inspector.

**PanelContainer** draws a styled background panel around its
 content (using the Panel StyleBox from the current Theme). It's the easiest
 way to give a group of controls a visual "card" background.

```gdscript
# Build a labelled stat block:
# PanelContainer → MarginContainer → VBoxContainer → [label, value]
func make_stat_block(stat_name: String, value: int) -> PanelContainer:
    var panel := PanelContainer.new()

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_top",    8)
    margin.add_theme_constant_override("margin_bottom", 8)
    margin.add_theme_constant_override("margin_left",   12)
    margin.add_theme_constant_override("margin_right",  12)

    var vbox := VBoxContainer.new()
    var name_lbl := Label.new()
    name_lbl.text = stat_name.to_upper()
    name_lbl.add_theme_font_size_override("font_size", 11)

    var val_lbl := Label.new()
    val_lbl.text = str(value)
    val_lbl.add_theme_font_size_override("font_size", 24)

    vbox.add_child(name_lbl)
    vbox.add_child(val_lbl)
    margin.add_child(vbox)
    panel.add_child(margin)
    return panel
```

⬡ — ScrollContainer — inherits Container → Control

Clips its single child to its own rect and provides scroll bars when the child is larger. The child (usually a VBoxContainer) can be as tall as needed — ScrollContainer shows only the visible portion and lets the player scroll through the rest. Use it for inventory grids, quest logs, settings lists, or any UI with more content than fits on screen.

| Property | Default | What it does |
| --- | --- | --- |
| horizontal\_scroll\_mode | AUTO | DISABLED: never shows hscrollbar. ENABLED\_ALWAYS: always visible. AUTO: only visible when content overflows horizontally |
| vertical\_scroll\_mode | AUTO | Same for vertical scroll — usually leave at AUTO |
| scroll\_deadzone | 0 | Pixels of touch drag before scroll starts — increase to prevent accidental scroll while tapping items on mobile |
| follow\_focus | false | Automatically scrolls to bring the currently focused Control into view — essential for gamepad/keyboard navigation of long lists |

Use when:

UI content can exceed the available area — inventory list, shop catalogue, settings menu, chat log, quest journal.

Typical setup:

ScrollContainer (fixed size) → VBoxContainer (size\_flags\_horizontal = EXPAND) → item nodes. The VBoxContainer grows freely; ScrollContainer clips and scrolls it.

Enable

follow\_focus

whenever keyboard/gamepad navigation is needed — without it, scrolling to a focused item off-screen requires manual code.

### ScrollContainer

**ScrollContainer** wraps content that may be taller or wider
 than the available space, adding scrollbars automatically. Set
 `horizontal_scroll_mode` and `vertical_scroll_mode`
 to `SCROLL_MODE_AUTO` (shows bar only when needed) or
 `SCROLL_MODE_SHOW_ALWAYS`. The single child is usually a VBoxContainer
 or GridContainer holding the actual content.

```gdscript
@onready var scroll: ScrollContainer = $ScrollContainer
@onready var list:   VBoxContainer   = $ScrollContainer/ListVBox

# Scroll to the bottom (e.g. chat log):
func scroll_to_bottom() -> void:
    await get_tree().process_frame   # wait one frame for layout to settle
    scroll.scroll_vertical = scroll.get_v_scroll_bar().max_value

# Scroll to a specific child:
func scroll_to_item(item: Control) -> void:
    await get_tree().process_frame
    scroll.ensure_control_visible(item)
```

## 4 · Common Widgets

⬡ — Label · RichTextLabel — both inherit Control

**Label** displays a plain string with a single font and colour — the standard choice for scores, names, counters, static UI text. **RichTextLabel** interprets BBCode tags inside the string so you can mix colours, sizes, bold, italic, images, and animated effects in a single text block — perfect for dialogue, item descriptions, and formatted log output.

| Label property | Default | What it does |
| --- | --- | --- |
| text | "" | The string to display. Change at runtime: `$Label.text = "Score: %d" % score` |
| horizontal\_alignment | LEFT | LEFT / CENTER / RIGHT / FILL — how text aligns within the label's rect |
| vertical\_alignment | TOP | TOP / CENTER / BOTTOM / FILL — vertical alignment within rect |
| autowrap\_mode | OFF | WORD (wrap at word boundaries) or ARBITRARY (wrap anywhere) — wraps text to fit the label width |
| clip\_text | false | Cuts off text that overflows the rect instead of growing the label or wrapping |
| uppercase | false | Renders all text in uppercase — useful for headings without changing the source string |

| RichTextLabel property | Default | What it does |
| --- | --- | --- |
| bbcode\_enabled | true | Parse BBCode tags in `text`. Disable for performance if displaying plain strings only |
| text | "" | String with optional BBCode — e.g. `[color=red]HP[/color]: [b]100[/b]` |
| scroll\_active | true | Shows a scroll bar when content overflows — useful for chat logs and quest journals |
| visible\_ratio | 1.0 | Fraction of characters to show (0.0–1.0) — tween this from 0 to 1 for a typewriter reveal effect |
| fit\_content | false | Auto-sizes the label height to fit its content — useful in VBoxContainers where height is dynamic |

Prefer Label when:

displaying a single-style string — name plates, score counters, button labels, debug text.

Prefer RichTextLabel when:

you need mixed formatting — dialogue with character names in different colours, item tooltips with bold stats, animated typewriter text.

Typewriter effect:

tween

visible\_ratio

from 0 → 1 over the text length ÷ chars-per-second.

### Label and RichTextLabel

**Label** displays plain text. Key properties: `text`,
 `horizontal_alignment` (LEFT/CENTER/RIGHT/FILL),
 `vertical_alignment`, `autowrap_mode` (WORD wraps at
 the label's width), `clip_text` (truncate with ellipsis).

**RichTextLabel** parses BBCode markup for inline formatting,
 images, and effects. Set `bbcode_enabled = true` (default in 4.x)
 and use the `text` property with BBCode tags:

```gdscript
@onready var rtl: RichTextLabel = $RichText

func show_damage(amount: int, is_crit: bool) -> void:
    if is_crit:
        rtl.text = "[color=orange][b]CRIT! %d[/b][/color]" % amount
    else:
        rtl.text = "[color=white]%d[/color]" % amount

# Append without clearing — good for chat logs:
func append_chat(user: String, msg: String) -> void:
    rtl.append_text("[color=aqua][b]%s:[/b][/color] %s\n" % [user, msg])

# Useful BBCode tags:
# [b]bold[/b]  [i]italic[/i]  [u]underline[/u]  [s]strike[/s]
# [color=#ff0000]red text[/color]
# [font_size=24]big[/font_size]
# [wave amp=20 freq=2]wavy[/wave]      ← animated effect
# [shake rate=20 level=5]shake[/shake] ← animated effect
# [img]res://icon.png[/img]            ← inline image
```

⬡ — Button · CheckBox · CheckButton · OptionButton · LinkButton — all inherit BaseButton → Control

Godot has a family of button widgets that share a common `BaseButton` ancestor (and its key signal `pressed`) but differ in visual style and toggle behaviour. Choose the variant that matches what the player is actually doing — clicking, toggling a setting, or selecting from a list.

| Node | Toggle? | When to use |
| --- | --- | --- |
| Button | optional | The general-purpose clickable button. Set `toggle_mode = true` to make it stay pressed. Use for actions (Start, Attack, Buy) |
| CheckBox | always | Shows a tick-box. Use for binary on/off settings: "Enable fullscreen", "Show FPS". Emits `toggled(bool)` |
| CheckButton | always | A pill-shaped iOS-style toggle switch. Functionally identical to CheckBox — choose based on visual fit |
| OptionButton | — | A dropdown selector. Add items via `add_item()` or the Inspector. Emits `item_selected(index)`. Use for quality settings, difficulty, resolution |
| LinkButton | optional | Looks like a hyperlink (underlined text). Use for "More info", "View changelog", credits links |

| BaseButton property | Default | What it does |
| --- | --- | --- |
| disabled | false | Greyed out and non-interactive — use for options that require a prerequisite (buy button when player has no gold) |
| toggle\_mode | false | Button stays pressed after click; click again to release. Useful for mode toggles (run/walk, mute) |
| button\_group | null | Assign a ButtonGroup resource to make a radio-button set — only one button in the group can be pressed at a time |
| action\_mode | BUTTON\_RELEASE | BUTTON\_PRESS fires `pressed` on mouse down; BUTTON\_RELEASE fires on mouse up (default, feels more responsive) |

Common signal:

pressed()

— fires when the button is activated (click, Enter key, gamepad A). Connect this in the Inspector or with `button.pressed.connect(my_func)`.

Gamepad/keyboard focus:

set

focus\_mode = FOCUS\_ALL

so the button can be tabbed to and activated with Enter — essential for controller support.

### Button types

| Node | Key signal | Use |
| --- | --- | --- |
| `Button` | `pressed` | Standard push button with text and/or icon |
| `TextureButton` | `pressed` | Clickable image; set Normal/Hover/Pressed/Disabled textures |
| `CheckBox` | `toggled(bool)` | Two-state checkbox with a label |
| `CheckButton` | `toggled(bool)` | Toggle switch style instead of checkbox |
| `OptionButton` | `item_selected(int)` | Drop-down picker; add items with `add_item("Text")` |
| `MenuButton` | Via `get_popup().id_pressed` | Button that opens a PopupMenu |
| `LinkButton` | `pressed` | Hyperlink-style text button |

```gdscript
@onready var quality_btn: OptionButton = $QualityDropdown

func _ready() -> void:
    quality_btn.clear()
    quality_btn.add_item("Low",    0)
    quality_btn.add_item("Medium", 1)
    quality_btn.add_item("High",   2)
    quality_btn.add_item("Ultra",  3)
    quality_btn.select(2)   # default to High
    quality_btn.item_selected.connect(_on_quality_changed)

func _on_quality_changed(index: int) -> void:
    SettingsManager.set_quality(index)
```

### LineEdit and TextEdit

**LineEdit** is a single-line text input. Key signals:
 `text_changed(new_text)` fires on every keystroke;
 `text_submitted(text)` fires when the player presses
 Enter. Set `secret = true` for password fields,
 `max_length` to cap input, and `placeholder_text`
 for hint text.

**TextEdit** is multi-line. For code/script input, prefer
 **CodeEdit** which adds syntax highlighting, code folding,
 and auto-indent.

```gdscript
@onready var name_input: LineEdit = $PlayerNameInput

func _ready() -> void:
    name_input.placeholder_text = "Enter your name…"
    name_input.max_length        = 20
    name_input.text_submitted.connect(_on_name_submitted)

func _on_name_submitted(new_name: String) -> void:
    var sanitised := new_name.strip_edges()
    if sanitised.is_empty():
        return
    GameManager.player_name = sanitised
    $ConfirmButton.grab_focus()   # move focus to next element
```

### ProgressBar and Slider

**ProgressBar** shows a fill level between `min_value`
 (default 0) and `max_value` (default 100). Set `value`
 to update it. Enable `show_percentage` to overlay a percentage
 label automatically.

**HSlider** / **VSlider** are draggable sliders
 that emit `value_changed(float)`. Use `step` to
 snap to discrete values. Sliders can serve double duty as volume controls,
 timeline scrubbers, or skill allocation bars.

```gdscript
@onready var hp_bar: ProgressBar = $HealthBar

# Update the bar whenever health changes (connect to EventBus signal):
func _ready() -> void:
    EventBus.player_health_changed.connect(_on_health_changed)

func _on_health_changed(hp: int, max_hp: int) -> void:
    hp_bar.max_value = max_hp
    hp_bar.value     = hp
    # Colour the bar red when below 25 %:
    var pct := float(hp) / max_hp
    var fill_style := hp_bar.get_theme_stylebox("fill").duplicate() as StyleBoxFlat
    fill_style.bg_color = Color.RED.lerp(Color.GREEN, pct)
    hp_bar.add_theme_stylebox_override("fill", fill_style)
```

## 4b · Extended Widget Reference

The widgets in Section 4 cover most HUDs and simple menus. The nodes below
 are equally important once you build settings screens, inventories, level
 editors, or any interface with a real information density.

### OptionButton — dropdown selector

`OptionButton` extends `Button` and opens a popup list
 when clicked. The selected item's index is accessed via
 `selected` (int) and its text via `get_item_text(selected)`.

```gdscript
@onready var quality_opt: OptionButton = $QualityOption

func _ready() -> void:
    quality_opt.add_item("Low",    0)
    quality_opt.add_item("Medium", 1)
    quality_opt.add_item("High",   2)
    quality_opt.add_item("Ultra",  3)
    quality_opt.selected = 2          # default: High

    quality_opt.item_selected.connect(_on_quality_changed)

func _on_quality_changed(index: int) -> void:
    match index:
        0: RenderingServer.viewport_set_msaa_2d(get_viewport().get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_DISABLED)
        2: RenderingServer.viewport_set_msaa_2d(get_viewport().get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_4X)
        3: RenderingServer.viewport_set_msaa_2d(get_viewport().get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_8X)
```

### SpinBox — numeric input with arrows

`SpinBox` shows a text field with increment/decrement arrows.
 Key properties: `min_value`, `max_value`,
 `step`, `value`, `suffix`
 (e.g., `"px"`). Signal: `value_changed(value: float)`.

```gdscript
@onready var volume_spin: SpinBox = $VolumeSpinBox

func _ready() -> void:
    volume_spin.min_value = 0.0
    volume_spin.max_value = 100.0
    volume_spin.step = 5.0
    volume_spin.suffix = "%"
    volume_spin.value = 80.0
    volume_spin.value_changed.connect(_on_volume_changed)

func _on_volume_changed(val: float) -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(val / 100.0))
```

### CheckBox and CheckButton

Both inherit `Button` with `toggle_mode = true`.
 `CheckBox` shows a square tick-box; `CheckButton`
 shows a toggle switch. Use `button_pressed` (bool property) to
 read or set the state, and connect the `toggled(button_pressed: bool)`
 signal for changes.

```gdscript
@onready var vsync_check: CheckBox = $VsyncCheck
@onready var fullscreen_toggle: CheckButton = $FullscreenToggle

func _ready() -> void:
    vsync_check.button_pressed = DisplayServer.window_get_vsync_mode() != DisplayServer.VSYNC_DISABLED
    vsync_check.toggled.connect(func(on): DisplayServer.window_set_vsync_mode(
        DisplayServer.VSYNC_ENABLED if on else DisplayServer.VSYNC_DISABLED))

    fullscreen_toggle.button_pressed = DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
    fullscreen_toggle.toggled.connect(func(on): DisplayServer.window_set_mode(
        DisplayServer.WINDOW_MODE_FULLSCREEN if on else DisplayServer.WINDOW_MODE_WINDOWED))
```

### TabContainer — multi-page panels

Add any Control nodes as children of `TabContainer` — each
 child becomes a tab, named by the child's `name` property.
 Only the active tab is visible. Connect `tab_changed(tab: int)`
 to react to page switches. Set `current_tab` (int) to switch
 programmatically.

```gdscript
@onready var tabs: TabContainer = $SettingsTabs

func _ready() -> void:
    # Tab names come from the child node names
    # "Graphics", "Audio", "Controls", "Gameplay"
    tabs.current_tab = 0
    tabs.tab_changed.connect(_on_tab_changed)

func _on_tab_changed(tab: int) -> void:
    print("Switched to tab: ", tabs.get_tab_title(tab))

func open_audio_tab() -> void:
    tabs.current_tab = 1  # "Audio" is the second child
```

### ItemList — scrollable list of selectable items

`ItemList` displays a scrollable list of text (and optionally
 icon) items. Use `select_mode` to allow single or multi-select.
 Key signals: `item_selected(index: int)`,
 `item_activated(index: int)` (double-click),
 `multi_selected(index: int, selected: bool)`.

```gdscript
@onready var save_list: ItemList = $SaveFileList

func populate_saves(save_names: Array[String]) -> void:
    save_list.clear()
    for name in save_names:
        save_list.add_item(name)
    save_list.item_selected.connect(_on_save_selected)

func _on_save_selected(index: int) -> void:
    var save_name := save_list.get_item_text(index)
    print("Load: ", save_name)
```

### Tree — hierarchical data display

`Tree` renders a collapsible tree of `TreeItem` nodes.
 It's the same widget Godot uses for the Scene dock. Each cell in the tree
 can hold text, icons, buttons, checkboxes, or custom colours.

```gdscript
@onready var skill_tree: Tree = $SkillTree

func _ready() -> void:
    skill_tree.columns = 2
    skill_tree.set_column_title(0, "Skill")
    skill_tree.set_column_title(1, "Level")
    skill_tree.column_titles_visible = true

    var root: TreeItem = skill_tree.create_item()
    root.set_text(0, "Combat")

    var melee: TreeItem = skill_tree.create_item(root)
    melee.set_text(0, "Melee Attack")
    melee.set_text(1, "Lv 3")

    var ranged: TreeItem = skill_tree.create_item(root)
    ranged.set_text(0, "Ranged Attack")
    ranged.set_text(1, "Lv 1")

    skill_tree.item_selected.connect(func(): print(skill_tree.get_selected().get_text(0)))
```

### TextureButton and TextureRect

`TextureRect` displays an image inside a Control rect.
 Use `expand_mode` (`EXPAND_FIT_WIDTH`,
 `EXPAND_FIT_HEIGHT`, `EXPAND_KEEP_SIZE`) to control
 how it scales. `stretch_mode` controls aspect ratio
 (`STRETCH_KEEP_ASPECT_CENTERED` is most useful).

`TextureButton` is a Button whose visuals are textures rather
 than a StyleBox. Assign textures for each state:
 `texture_normal`, `texture_pressed`,
 `texture_hover`, `texture_disabled`,
 `texture_focused`.

```gdscript
@onready var avatar: TextureRect = $AvatarImage

func set_player_avatar(texture: Texture2D) -> void:
    avatar.texture = texture
    avatar.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
    avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
```

⬡ — NinePatchRect — inherits Control

Scales a texture using the "9-slice" technique: the image is divided into a 3×3 grid by four margins, the four corners are never stretched, the four edges stretch in one direction only, and the centre stretches in both. This allows UI panels, speech bubbles, buttons, and bordered frames to resize to any dimensions without pixelating the corners.

| Property | Default | What it does |
| --- | --- | --- |
| texture | null | The source image. Should be a tileable border texture with clearly defined corners (often 3×3 equal segments or power-of-two with distinct corners) |
| patch\_margin\_left/right/top/bottom | 0 px each | How many pixels from each edge to treat as a non-scaling corner/edge. Set these to the border thickness of your texture |
| axis\_stretch\_horizontal | STRETCH | How the horizontal centre and edges scale: STRETCH (default), TILE (repeats), TILE\_FIT (repeats and adjusts scale to fit) |
| axis\_stretch\_vertical | STRETCH | Same for the vertical centre and edges |
| draw\_center | true | If false, the centre patch is invisible — use for hollow frame shapes like speech bubble outlines |
| region\_rect | Rect2(0,0,0,0) | Optional sub-rectangle within the texture atlas — use when the panel graphic is part of a sprite sheet |

Use when:

you need a bordered panel that resizes cleanly — speech bubbles, inventory windows, HUD panels, popup boxes, button backgrounds in pixel art.

Prefer Panel + StyleBoxFlat when:

you want a programmatically-coloured box with no pre-made texture — StyleBoxFlat gives you full control over colour, border, corner radius, and shadow without any art assets.

Tip:

design your panel texture at the smallest useful size (e.g., 32×32 with 8px corners) and let NinePatchRect scale it to any window size.

### NinePatchRect — scalable bordered panels

`NinePatchRect` slices a texture into a 3×3 grid with
 configurable margins. The corners never stretch; the edges tile or stretch;
 the centre fills. It's the correct way to make speech bubbles, buttons,
 health bars, and bordered panels that scale to any size without pixel
 distortion.

```gdscript
@onready var panel: NinePatchRect = $DialoguePanel

func _ready() -> void:
    # Margins define the cut lines for the 9-patch grid (in pixels)
    panel.patch_margin_left = 12
    panel.patch_margin_top = 12
    panel.patch_margin_right = 12
    panel.patch_margin_bottom = 12
    # Axis stretch mode: STRETCH_TILE, STRETCH_SCALE, or STRETCH_TILE_FIT
    panel.axis_stretch_horizontal = NinePatchRect.AXIS_STRETCH_MODE_SCALE
    panel.axis_stretch_vertical   = NinePatchRect.AXIS_STRETCH_MODE_SCALE
```

### FlowContainer, AspectRatioContainer, SplitContainer

**FlowContainer** (HFlowContainer / VFlowContainer) wraps
 children like a CSS flex-wrap — they flow to the next row/column when
 the container is full. Use it for item grids, tag lists, or
 word-wrapped button bars.

**AspectRatioContainer** forces a single child to maintain
 a fixed aspect ratio as the container resizes. Set `ratio`
 (width/height) and `stretch_mode`. Perfect for a 16:9 game
 viewport preview panel in a settings screen.

**HSplitContainer / VSplitContainer** place two children
 side by side with a draggable divider between them. The user can drag
 the splitter to resize the panels. Connect
 `dragged(offset: int)` to save the user's preference.

:::callout-tip[SubViewportContainer — 3D inside a 2D UI]
Wrap a `SubViewport` in a `SubViewportContainer`
 to render any 3D (or 2D) scene into a UI Control rect. This is how
 "character preview" panels and minimap displays work — a separate
 camera and scene tree renders into a texture that appears as a Control
 widget. Set `SubViewport.render_target_update_mode` to
 `UPDATE_WHEN_VISIBLE` so it only costs GPU time while visible.
:::

### PopupMenu and MenuButton

`PopupMenu` is a floating context menu. Call
 `add_item("Rename", 0)` then `popup()` to show it.
 Connect `id_pressed(id: int)` to handle choices. Use
 `add_separator()`, `add_check_item()`,
 `add_submenu_item()` for rich menus.

`MenuButton` is a Button that automatically opens an attached
 `PopupMenu` when clicked. Access its menu via
 `get_popup()`.

```gdscript
@onready var file_btn: MenuButton = $FileMenuButton

func _ready() -> void:
    var popup: PopupMenu = file_btn.get_popup()
    popup.add_item("New Game",  0)
    popup.add_item("Load Game", 1)
    popup.add_separator()
    popup.add_item("Quit",      2)
    popup.id_pressed.connect(_on_file_menu_pressed)

func _on_file_menu_pressed(id: int) -> void:
    match id:
        0: SceneLoader.goto_scene("res://scenes/game.tscn")
        1: SaveManager.open_load_dialog()
        2: get_tree().quit()
```

:::callout-pitfall[Watch out for]
- **TabContainer vs TabBar.** `TabContainer` manages child visibility automatically. `TabBar` is just the tab row with no panel — use it if you want to manually control which container is visible. Don't mix them up.
- **ItemList.clear() loses all items and connections.** Always rebuild items and reconnect signals after calling `clear()` if you're refreshing the list.
- **NinePatchRect margins must be set in pixels, not fractions.** They refer to pixels in the source texture. A 48px button texture with 8px corners needs margins of 8.
- **SubViewport input routing.** By default, input events don't reach a SubViewport's contents. Set `SubViewportContainer.stretch = true` and enable `handle_input_locally` on the SubViewport if you need interactivity inside it.
:::

## 5 · Themes & StyleBox

A **Theme** is a resource that defines the visual style for
 all Control nodes that use it: fonts, font sizes, colours, and
 **StyleBoxes** (the backgrounds and borders of buttons, panels,
 etc.). Apply a Theme at any level of the scene tree — it inherits down to
 all child Controls, so setting it on the root Control of your UI applies
 project-wide.

### Creating and applying a Theme

1. In the Inspector of any Control, find the **Theme** property.
2. Click the drop-down → New Theme → save as `res://ui/main_theme.tres`.
3. Double-click the theme to open the Theme editor.
4. Choose a Control type (e.g. Button) and a property category (Colors, Fonts, Font Sizes, Styles).
5. Add overrides per control type and state (Normal, Hover, Pressed, Disabled, Focus).

```gdscript
# Apply a theme programmatically:
var theme := preload("res://ui/main_theme.tres") as Theme
$UIRoot.theme = theme

# Override a single theme property on one control (without touching the theme):
$MyButton.add_theme_font_size_override("font_size", 18)
$MyButton.add_theme_color_override("font_color", Color.YELLOW)
$MyButton.add_theme_stylebox_override("normal", my_custom_stylebox)

# Remove an override and fall back to the theme:
$MyButton.remove_theme_stylebox_override("normal")
```

### StyleBoxFlat — the workhorse stylebox

**StyleBoxFlat** draws a rectangle with configurable background
 colour, border colour and width, corner rounding, and shadow. Most Godot
 UI themes use StyleBoxFlat for buttons, panels, and inputs.

```gdscript
func make_button_stylebox(
        bg: Color,
        border: Color,
        corner_radius: int = 6) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color            = bg
    sb.border_color        = border
    sb.border_width_left   = 2
    sb.border_width_top    = 2
    sb.border_width_right  = 2
    sb.border_width_bottom = 2
    sb.corner_radius_top_left     = corner_radius
    sb.corner_radius_top_right    = corner_radius
    sb.corner_radius_bottom_left  = corner_radius
    sb.corner_radius_bottom_right = corner_radius
    # Content padding (inner margin):
    sb.content_margin_left   = 12.0
    sb.content_margin_right  = 12.0
    sb.content_margin_top    = 6.0
    sb.content_margin_bottom = 6.0
    return sb

# Apply to a button's Normal and Hover states:
func _ready() -> void:
    var normal  := make_button_stylebox(Color(0.15, 0.2, 0.35), Color(0.3, 0.5, 0.8))
    var hover   := make_button_stylebox(Color(0.25, 0.35, 0.55), Color(0.5, 0.7, 1.0))
    var pressed := make_button_stylebox(Color(0.1,  0.15, 0.25), Color(0.2, 0.4, 0.7))

    $MyButton.add_theme_stylebox_override("normal",  normal)
    $MyButton.add_theme_stylebox_override("hover",   hover)
    $MyButton.add_theme_stylebox_override("pressed", pressed)
```

⬡ — CanvasLayer — inherits Node

Renders all its Control (and CanvasItem) children on a completely separate 2D canvas that ignores the main camera. This is the standard way to build HUDs, pause menus, and UI overlays — they stay fixed on screen while the game world scrolls beneath them. Each CanvasLayer has an independent transform and layer number controlling draw order.

| Property | Default | What it does |
| --- | --- | --- |
| layer | 1 | Canvas draw-order index. Higher = drawn on top. The main game world is layer 0. HUDs typically use 1–10; popups/modals 100+ |
| follow\_viewport\_enabled | false | When true, the canvas layer scrolls with the camera — useful for parallax background layers rather than fixed HUDs |
| follow\_viewport\_scale | 1.0 | Parallax speed multiplier when follow\_viewport\_enabled is true — 0.5 = scrolls at half camera speed (slow background parallax) |
| offset | Vector2(0,0) | Pixel offset of the entire canvas layer — shift the whole HUD without moving individual children |
| transform | identity | Full 2D transform applied to the layer — allows scaling, rotating, or translating the entire canvas (e.g. for cinematic letter-boxing) |
| custom\_viewport | null | Render this canvas layer into a specific Viewport instead of the main viewport — for split-screen HUD per-player |

Use when:

you need UI that doesn't move with the camera — health bars, minimaps, score displays, dialogue boxes, pause menus, loading screens.

Also use for parallax backgrounds:

set

follow\_viewport\_enabled = true

and

follow\_viewport\_scale < 1.0

to create depth layers that scroll slower than the camera.

Layer ordering:

backgrounds → game world (0) → overlay decorations (1) → HUD (2–5) → pause/menus (10+) → debug overlays (100+).

## 6 · CanvasLayer for HUD

By default, Control nodes render at the same canvas layer as 2D game nodes.
 This means a large background panel on a character will render behind it,
 but a character that is Z-sorted above the panel will render on top of HUD
 elements — a visible bug. **CanvasLayer** fixes this by drawing
 its children on an independent canvas layer, always on top of (or behind)
 the game world regardless of Z-index.

Set `layer` to a positive integer (1–128) for in-front-of-world
 rendering, or a negative integer for behind-world rendering. Layer 0 is
 the default world canvas.

```gdscript
# Scene structure for a typical 2D game with HUD:
# Node2D (Main)
# ├─ World (game entities, tilemap, enemies — all at CanvasLayer 0)
# └─ CanvasLayer (layer = 1) ← HUD lives here
#    └─ Control (full rect)
#       ├─ HealthBar (top-left)
#       ├─ ScoreLabel (top-right)
#       └─ MinimapTexture (bottom-right)

# The CanvasLayer ignores Camera2D zoom and pan —
# your HUD elements stay fixed on screen regardless of camera movement.

# To follow the camera (unusual but possible):
$HUDLayer.follow_viewport_enabled = true
$HUDLayer.follow_viewport_scale    = 1.0
```

:::callout-tip[Pause menus need a separate CanvasLayer]
A pause menu that appears over the game world should be in its own
 CanvasLayer with a higher layer number (e.g. 10). Set
 `process_mode = PROCESS_MODE_ALWAYS` on the pause menu's root
 node so it responds to input even while `get_tree().paused = true`.
:::

## 7 · Focus & Keyboard Navigation

Players using keyboards or controllers navigate menus with arrow keys or
 D-pad. For this to work, each interactive Control needs a
 **focus neighbour** — the node to focus when the player presses
 a direction.

Enable focus on a Control by setting `focus_mode` to
 `FOCUS_ALL` (responds to mouse and keyboard) or
 `FOCUS_CLICK` (mouse only). Then set the four
 `focus_neighbor_*` properties to NodePaths pointing at adjacent
 Controls.

```gdscript
func setup_focus_chain(buttons: Array[Button]) -> void:
    for i in buttons.size():
        var btn := buttons[i]
        btn.focus_mode = Control.FOCUS_ALL
        # Wrap around: last button's next = first, first's prev = last
        var prev := buttons[(i - 1 + buttons.size()) % buttons.size()]
        var next := buttons[(i + 1) % buttons.size()]
        btn.focus_neighbor_bottom = btn.get_path_to(next)
        btn.focus_neighbor_top    = btn.get_path_to(prev)

    # Focus the first button when the menu opens:
    buttons[0].grab_focus()

# Listen for focus change to play a sound:
func _ready() -> void:
    for btn in $MenuVBox.get_children():
        if btn is Button:
            btn.focus_entered.connect(func(): AudioManager.play_sfx("ui_hover"))
```

:::callout-key[grab\_focus() vs accept\_event()]
`grab_focus()` moves the keyboard focus to a specific control.
 Use it when a menu opens to auto-select the default button. If you're handling
 input in `_input()` or `_gui_input()` and don't want
 the event to propagate further, call `accept_event()` or
 `get_viewport().set_input_as_handled()`. Without this, pressing
 Escape in a text field might also trigger the pause menu.
:::

:::summary
## Chapter Summary

| Concept | Quick reference |
| --- | --- |
| Control rect | Position = top-left corner. Size = width × height. Pivot for rotation/scale. |
| mouse\_filter | IGNORE for visual-only controls so clicks pass through to the game world. |
| Anchors | 0.0 = left/top edge, 1.0 = right/bottom edge of parent. Offsets = fixed px from anchor. |
| Full Rect preset | Most common for background panels. Code: `set_anchors_and_offsets_preset(PRESET_FULL_RECT)`. |
| VBoxContainer | Stack children vertically. Set separation in Inspector. Never manually set child positions. |
| SIZE\_EXPAND\_FILL | Most common size flag. Child fills its share of container space and grabs any extra. |
| ScrollContainer | Scrollable area. Child is usually VBoxContainer. Use `ensure_control_visible()` to auto-scroll. |
| RichTextLabel | BBCode markup for inline colour, bold, images. Use `append_text()` for chat logs. |
| Theme | Shared style resource applied to a Control subtree. Overrides per-node with `add_theme_*_override()`. |
| StyleBoxFlat | bg\_color + border + corner radius + padding. The building block of every custom theme. |
| CanvasLayer | HUD at layer 1+. Ignores Camera2D. Pause menu at layer 10+ with PROCESS\_MODE\_ALWAYS. |
| Focus chain | Set focus\_neighbor\_\* NodePaths. Call `grab_focus()` on menu open for controller support. |

**If you remember nothing else:** put your HUD in a CanvasLayer
 so it ignores camera movement. Use containers (VBox/HBox/Grid) instead of
 manually positioning children. Anchor things to screen edges so the layout
 survives window resizes.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Write the anchor/offset values (in code) to place a 200×40 px button
 centred horizontally and 20 px from the bottom of the screen.

::::solution[Solution]
```gdscript
var btn: Button = $MyButton
btn.custom_minimum_size = Vector2(200, 40)
# Anchor horizontally centred, anchored to bottom:
btn.anchor_left   = 0.5
btn.anchor_right  = 0.5
btn.anchor_top    = 1.0
btn.anchor_bottom = 1.0
# Offsets: centre the 200px width, 20px gap from bottom
btn.offset_left   = -100.0   # 200/2 left of centre anchor
btn.offset_right  =  100.0   # 200/2 right of centre anchor
btn.offset_top    = -60.0    # 40px tall + 20px gap = 60px above bottom
btn.offset_bottom = -20.0    # 20px from bottom edge
```
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Build a simple HUD in code (no scene file) that shows a health bar
 in the top-left and a score label in the top-right, inside a CanvasLayer.
 Both should have 16 px padding from the screen edges.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var hud_layer := CanvasLayer.new()
    hud_layer.layer = 1
    add_child(hud_layer)

    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_layer.add_child(root)

    # Health bar — top left
    var hp_bar := ProgressBar.new()
    hp_bar.custom_minimum_size = Vector2(200, 24)
    hp_bar.anchor_left   = 0.0; hp_bar.anchor_top    = 0.0
    hp_bar.anchor_right  = 0.0; hp_bar.anchor_bottom = 0.0
    hp_bar.offset_left   = 16;  hp_bar.offset_top    = 16
    hp_bar.offset_right  = 216; hp_bar.offset_bottom = 40
    hp_bar.max_value     = 100; hp_bar.value         = 100
    root.add_child(hp_bar)

    # Score label — top right
    var score_lbl := Label.new()
    score_lbl.text = "Score: 0"
    score_lbl.anchor_left   = 1.0; score_lbl.anchor_top    = 0.0
    score_lbl.anchor_right  = 1.0; score_lbl.anchor_bottom = 0.0
    score_lbl.offset_left   = -216; score_lbl.offset_top    = 16
    score_lbl.offset_right  = -16;  score_lbl.offset_bottom = 40
    score_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(score_lbl)
```
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Create a **dynamic inventory grid**: a GridContainer with
 5 columns inside a ScrollContainer. Populate it from an
 `Array[ItemData]` where each item has a `name: String`
 and `icon: Texture2D`. Each slot is a PanelContainer with a
 TextureRect and a Label. Clicking a slot highlights it (changes its
 StyleBox border colour) and deselects the previous slot.

::::solution[Solution]
```gdscript
@onready var grid: GridContainer = $Scroll/Grid

var _selected_slot: PanelContainer = null

func populate(items: Array) -> void:
    for child in grid.get_children():
        child.queue_free()
    grid.columns = 5

    for item in items:
        var slot := _make_slot(item)
        grid.add_child(slot)

func _make_slot(item) -> PanelContainer:
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(64, 64)

    var normal_sb := StyleBoxFlat.new()
    normal_sb.bg_color     = Color(0.15, 0.15, 0.2)
    normal_sb.border_color = Color(0.3, 0.3, 0.4)
    normal_sb.set_border_width_all(2)
    normal_sb.set_corner_radius_all(4)
    panel.add_theme_stylebox_override("panel", normal_sb)

    var vbox := VBoxContainer.new()
    var icon := TextureRect.new()
    icon.texture          = item.icon
    icon.expand_mode      = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
    icon.stretch_mode     = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    icon.custom_minimum_size = Vector2(48, 48)

    var lbl := Label.new()
    lbl.text = item.name
    lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lbl.add_theme_font_size_override("font_size", 10)
    lbl.clip_text = true

    vbox.add_child(icon)
    vbox.add_child(lbl)
    panel.add_child(vbox)

    # Click to select:
    var btn_area := Button.new()
    btn_area.flat = true
    btn_area.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    btn_area.mouse_filter = Control.MOUSE_FILTER_PASS
    btn_area.pressed.connect(func(): _select_slot(panel, normal_sb))
    panel.add_child(btn_area)

    return panel

func _select_slot(slot: PanelContainer, sb: StyleBoxFlat) -> void:
    if _selected_slot:
        # Deselect — restore normal border colour
        var old_sb := _selected_slot.get_theme_stylebox("panel") as StyleBoxFlat
        old_sb.border_color = Color(0.3, 0.3, 0.4)

    _selected_slot = slot
    sb.border_color = Color(0.9, 0.7, 0.1)   # gold highlight
```
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Build a **main menu** scene with three buttons (New Game,
 Settings, Quit) in a VBoxContainer, centred on screen. Implement full
 keyboard navigation (up/down arrows, Enter to confirm) and play a hover
 sound when focus changes. On New Game, transition to the game scene using
 `GameManager.load_scene()`.

::::solution[Solution]
```gdscript
extends Control

@onready var new_game_btn: Button = $VBox/NewGameButton
@onready var settings_btn: Button = $VBox/SettingsButton
@onready var quit_btn:     Button = $VBox/QuitButton

func _ready() -> void:
    # Centre the VBox on screen:
    $VBox.set_anchors_and_offsets_preset(Control.PRESET_CENTER)

    # Focus chain — vertical wrap-around:
    var btns := [new_game_btn, settings_btn, quit_btn]
    for i in btns.size():
        btns[i].focus_mode = Control.FOCUS_ALL
        btns[i].focus_neighbor_bottom = btns[i].get_path_to(btns[(i+1) % btns.size()])
        btns[i].focus_neighbor_top    = btns[i].get_path_to(btns[(i-1+btns.size()) % btns.size()])
        btns[i].focus_entered.connect(func(): AudioManager.play_sfx("ui_hover"))

    # Wire buttons:
    new_game_btn.pressed.connect(func(): GameManager.load_scene("res://scenes/level_01.tscn"))
    settings_btn.pressed.connect(func(): $SettingsPanel.visible = true)
    quit_btn.pressed.connect(func(): get_tree().quit())

    # Auto-focus first button:
    new_game_btn.grab_focus()
```
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Implement a **typewriter RichTextLabel effect** as a reusable
 coroutine: given a RichTextLabel and a string (possibly with BBCode), reveal
 one character per `char_delay` seconds, playing a click sound on
 each non-space character. Support a "skip" action that instantly shows the
 full text. Handle BBCode tags correctly — they should be inserted all at once,
 not character by character.

::::solution[Solution]
```gdscript
func typewrite(label: RichTextLabel,
               full_text: String,
               char_delay: float = 0.04,
               skip_action: StringName = "ui_accept") -> void:
    label.text         = ""
    label.visible_characters = 0
    label.text         = full_text   # set full text, then reveal via visible_characters
    var total_chars    := label.get_total_character_count()
    var skip_requested := false

    # Listen for skip on this frame:
    var _check_skip := func():
        if Input.is_action_just_pressed(skip_action):
            skip_requested = true

    for i in total_chars:
        _check_skip.call()
        if skip_requested:
            break
        label.visible_characters = i + 1
        # Play click for non-whitespace (BBCode chars handled: visible_characters
        # counts only displayed chars, not tag text):
        if full_text.unicode_at(i) > 32:   # rough check: skip spaces/controls
            AudioManager.play_sfx_pitched("typewriter_click", 0.9, 1.1, -12.0)
        await get_tree().create_timer(char_delay).timeout
        _check_skip.call()
        if skip_requested:
            break

    label.visible_characters = -1   # -1 = show all
```

Setting `visible_characters = -1` at the end shows all
 characters instantly, including any that were behind BBCode tags.
 Godot's RichTextLabel handles the tag-parsing internally — the
 `visible_characters` count tracks only rendered glyphs,
 not markup characters.
::::
:::

Godot 4.6 Complete Reference · Part III — UI & Polish · Generated for self-study. Edit freely.
