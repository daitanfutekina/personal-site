---
title: "Scene Composition, Inheritance vs. Instancing & Code Reuse Patterns"
source: "markdown"
---

Part IX · Chapter 59

Capstone

# Scene Composition, Inheritance vs. Instancing & Code Reuse Patterns

Estimated study time: 80 min · Prerequisites: Ch 3 Nodes & Scenes, Ch 12 Classes & Inheritance, Ch 7 Signals

## Chapter Overview

This is the Part IX capstone — it doesn't introduce new API, it teaches *judgement*: how to structure your project so that code is reusable, scenes are composable, and you're not copy-pasting logic across 20 enemy types six months into development.

The central question: when should you use **inheritance** (extend a base class) versus **composition** (attach a component scene as a child)? The answer governs the entire architecture of your game.

:::callout-key[Part IX complete after this chapter]
Part IX covered FSMs, navigation, behavior trees, and architecture patterns. Part X (Ch 60–63) covers profiling, optimization, threading, and multiplayer.
:::

## The Scene as the Unit of Reuse

:::callout-intuition[Intuition]
In most engines, "prefab" means a saved object template. In Godot,

every .tscn file is a prefab

. You can instance any scene inside any other scene. This makes composition the natural default — before reaching for inheritance, ask "could this be a child scene?"
:::

Godot scenes are composable at three levels:

- **Inherited scenes** — one `.tscn` extends another, overriding specific nodes or scripts
- **Instanced scenes** — a `.tscn` placed as a child inside another scene
- **Runtime instantiation** — `preload("res://enemy.tscn").instantiate()` in GDScript

## Inheritance — Extending Scripts and Scenes

### When to Use Inheritance

Script inheritance is for **is-a** relationships where the subtype truly is a specialisation of the parent: a `Sword` is a `Weapon`, a `FireEnemy` is an `Enemy`. Use it when:

- A base class defines an interface (virtual methods) that all subtypes must implement
- Subtypes share the majority of behaviour and differ only in a few parameters or methods
- You have 2–4 levels of hierarchy at most

```gdscript
# base_enemy.gd
class_name BaseEnemy extends CharacterBody2D

@export var max_health := 100
@export var move_speed := 80.0

var health: int

signal died

func _ready() -> void:
    health = max_health

func take_damage(amount: int) -> void:
    health -= amount
    if health <= 0:
        _on_death()

# Virtual method — subclasses override this
func _on_death() -> void:
    died.emit()
    queue_free()
```

```gdscript
# fire_enemy.gd — inherits base, adds fire behaviour
class_name FireEnemy extends BaseEnemy

const BURN_DAMAGE := 3
const BURN_INTERVAL := 0.5

@onready var burn_timer: Timer = $BurnTimer

func _ready() -> void:
    super()  # call BaseEnemy._ready()
    burn_timer.wait_time = BURN_INTERVAL
    burn_timer.timeout.connect(_apply_burn)

func _on_death() -> void:
    # Explode on death, then call base behaviour
    _spawn_fire_explosion()
    super()

func _apply_burn() -> void:
    # Burns nearby players
    pass
```

### Scene Inheritance

Scene inheritance (*Scene → New Inherited Scene*) lets you extend a `.tscn` file rather than just a script. The child scene can add new nodes, override node properties, and replace scripts — without modifying the parent scene.

```gdscript
// File: enemy_fire.tscn (inherits from enemy_base.tscn)
// Only stores the DIFFERENCES from the parent:
// - Added: BurnTimer node
// - Changed: Sprite2D.texture = fire_sprite.png
// - Changed: script = fire_enemy.gd
```

### Inheritance Pitfalls

:::callout-pitfall[Pitfall — Deep inheritance chains]
A three-level hierarchy (Character → Enemy → BossEnemy → PhaseShiftingBossEnemy) is already approaching the limit. When a bug in the base class breaks all 12 subclasses, you'll wish you'd used composition instead. Prefer composition over inheritance beyond 2 levels.
:::

:::callout-pitfall[Pitfall — Fragile base class problem]
Adding a new

\_ready()

hook or property to a base class can silently break every subclass that forgot to call `super()`. Always call

super()

in overridden lifecycle methods and document which methods require it.
:::

## Composition via Instancing

Composition is for **has-a** relationships: an enemy *has* a health component, *has* an inventory, *has* a vision sensor. Instead of baking all behaviour into one monolithic script, you build independent component scenes and attach them as children.

### The Component Pattern

Each component is a small scene (usually just a Node + Script) that encapsulates one responsibility and exposes it through signals and methods.

```gdscript
# health_component.gd — res://components/health_component.tscn
class_name HealthComponent extends Node

@export var max_health := 100

var health: int

signal health_changed(new_health: int, max_health: int)
signal died

func _ready() -> void:
    health = max_health

func take_damage(amount: int) -> void:
    health = max(health - amount, 0)
    health_changed.emit(health, max_health)
    if health == 0:
        died.emit()

func heal(amount: int) -> void:
    health = min(health + amount, max_health)
    health_changed.emit(health, max_health)

func is_alive() -> bool:
    return health > 0
```

```gdscript
# enemy.gd — uses HealthComponent, not inheriting it
extends CharacterBody2D

@onready var health_comp: HealthComponent = $HealthComponent
@onready var nav_agent:   NavigationAgent2D = $NavigationAgent2D

func _ready() -> void:
    health_comp.died.connect(_on_died)
    health_comp.health_changed.connect(_on_health_changed)

func _on_hit(damage: int) -> void:
    health_comp.take_damage(damage)

func _on_died() -> void:
    queue_free()

func _on_health_changed(hp: int, max_hp: int) -> void:
    $HealthBar.value = float(hp) / float(max_hp)
```

Any entity — player, enemy, boss, destructible crate — can now share the same `HealthComponent` with zero code duplication.

### Common Reusable Components

| Component | Responsibility | Signals it exposes |
| --- | --- | --- |
| HealthComponent | HP tracking, damage, death | health\_changed, died |
| HurtboxComponent | Area2D for receiving damage | hit(damage, knockback\_dir) |
| HitboxComponent | Area2D for dealing damage | hit\_landed(target) |
| InventoryComponent | Item storage and stacking | item\_added, item\_removed, full |
| StateMachineComponent | FSM manager (Ch 56) | state\_changed(new, old) |
| InteractableComponent | Marks object as interactable | interacted(by: Node) |
| LootComponent | Drop table + spawn on death | loot\_spawned(items) |
| VisionComponent | Sight cone + hearing (Ch 58) | target\_spotted, target\_lost |

### Scene Ownership vs. Runtime Instantiation

#### Owned (in .tscn)

Drag the component scene into the scene tree. Best for components that are always present on every instance of that entity.

```gdscript
@onready var health: HealthComponent = $HealthComponent
```

#### Runtime instantiation

Create and add the component in code. Best for optional components, or when components are added conditionally.

```gdscript
var HEALTH_COMP := preload("res://components/health_component.tscn")

func add_health(max_hp: int) -> HealthComponent:
    var comp := HEALTH_COMP.instantiate()
    comp.max_health = max_hp
    add_child(comp)
    return comp
```

## Signals for Decoupling

Components should not hold direct references to each other. Instead they talk through signals, keeping each component independently testable and reusable. The owner (the entity script) wires the signals together in `_ready()`.

```gdscript
# player.gd — the owner wires everything together
extends CharacterBody2D

@onready var health   : HealthComponent    = $HealthComponent
@onready var hurtbox  : HurtboxComponent   = $HurtboxComponent
@onready var inventory: InventoryComponent = $InventoryComponent
@onready var health_ui: ProgressBar        = $UI/HealthBar

func _ready() -> void:
    # Wire hurtbox → health
    hurtbox.hit.connect(health.take_damage)

    # Wire health → UI
    health.health_changed.connect(func(hp, max_hp):
        health_ui.value = float(hp) / max_hp
    )

    # Wire health → death cleanup
    health.died.connect(func():
        inventory.drop_all()
        queue_free()
    )
```

:::callout-tip[No cross-component references]
Notice that

HurtboxComponent

does not import

HealthComponent

— it just emits a signal. The player script wires them together. This means you can use HurtboxComponent on a wall that doesn't have health, and it still works fine.
:::

## Autoload Services

Autoloads are singletons available everywhere via a globally known name. Use them for truly global services, not as a lazy way to share data between scenes.

| Good autoload uses | Bad autoload uses |
| --- | --- |
| GameEvents (event bus) | Player stats (belong on the player node) |
| AudioManager (music/sfx) | Level data (load from resource files) |
| SaveManager (slot system) | Enemy lists (use groups instead) |
| SceneTransition | UI state (belong in the UI scene) |
| Settings (keybinds, volume) | Anything that should reset on scene change |

```gdscript
# res://autoloads/game_events.gd — minimal event bus autoload
extends Node

signal player_died
signal level_completed(score: int)
signal item_collected(item_data: ItemResource)
signal enemy_killed(enemy_type: StringName, position: Vector2)

# No data stored here — only signals
# Any scene can connect to or emit these events
```

## Resources as Data Objects

Custom `Resource` subclasses are the idiomatic way to define data in Godot — enemy stats, item definitions, dialogue trees, weapon configs. Resources are saved as `.tres` or `.res` files, editable in the Inspector, shareable between scenes, and version-control friendly.

```gdscript
# res://data/item_resource.gd
class_name ItemResource extends Resource

@export var item_name   : String
@export var description : String
@export var icon        : Texture2D
@export var max_stack   : int = 1
@export var value       : int = 0
@export var item_type   : StringName  # &"weapon", &"consumable", &"key"

# Optional: methods that operate on the data
func is_stackable() -> bool:
    return max_stack > 1
```

```gdscript
# Usage: load from file or @export in the Inspector
@export var sword_data: ItemResource

func _ready() -> void:
    print(sword_data.item_name)  # "Iron Sword"
    $NameLabel.text = sword_data.item_name
    $Icon.texture   = sword_data.icon
```

:::callout-tip[Resource as config vs. Resource as instance]
A

Resource

loaded with

load()

is cached — every node that loads the same file gets the same object. If you modify it at runtime, all users see the change. To get a per-entity copy, call

.duplicate()

on load. This matters for enemy stat resources shared across multiple enemies.
:::

## Groups & Node Metadata

Groups let you tag nodes by role and find all of them with `get_tree().get_nodes_in_group("enemies")`. Use groups for loose membership queries; use signals for event-driven communication; use direct `$node` references only within the same scene.

```gdscript
# Add to group in Inspector (Node → Groups tab) or in code:
func _ready() -> void:
    add_to_group("enemies")
    add_to_group("damageable")

# Find all enemies (any scene, any depth):
func damage_all_enemies(amount: int) -> void:
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if enemy.has_method("take_damage"):
            enemy.take_damage(amount)

# Node metadata for per-node data without a custom script:
func mark_visited(door: Node) -> void:
    door.set_meta("visited", true)

func is_visited(door: Node) -> bool:
    return door.get_meta("visited", false)
```

## Architectural Patterns

### Entity-Component (Godot-native)

The most idiomatic Godot architecture: entities are scene roots (CharacterBody2D, etc.), components are child nodes. The entity script wires components together via signals in `_ready()`. No global manager needed.

### Event Bus

A global autoload that exposes signals used for cross-scene communication. Good for events that many systems care about (player died, level completed, achievement unlocked) without those systems knowing about each other.

```gdscript
# Any scene can emit:
GameEvents.enemy_killed.emit(&"Goblin", global_position)

# Any scene can listen:
func _ready() -> void:
    GameEvents.enemy_killed.connect(_on_enemy_killed)

func _on_enemy_killed(type: StringName, pos: Vector2) -> void:
    spawn_xp_orb(pos)
```

### Service Locator

A middle ground between direct references and a full event bus: a central registry where systems register themselves and others look them up by name.

```gdscript
# res://autoloads/services.gd
extends Node
var _registry: Dictionary = {}

func register(name: StringName, service: Object) -> void:
    _registry[name] = service

func get_service(name: StringName) -> Object:
    return _registry.get(name)

# Usage: any scene registers itself
func _ready() -> void:
    Services.register(&"AudioManager", self)

# Any other scene retrieves it without a direct reference:
var audio := Services.get_service(&"AudioManager") as AudioManager
```

:::callout-warning[Service Locator overuse]
The Service Locator hides dependencies — you can't tell from a script's interface what services it needs. Use sparingly. For most needs, autoloads or direct node references are clearer.
:::

:::summary
### Chapter 59 Summary — Architecture Decision Guide

| Need | Use |
| --- | --- |
| Share behaviour across a type hierarchy | Script inheritance (2 levels max) |
| Mix behaviours across unrelated entities | Component scenes as children |
| Cross-scene event without direct reference | Autoload event bus signal |
| Global service (audio, saves, settings) | Autoload singleton |
| Data definition (items, enemies, weapons) | Custom Resource subclass + .tres files |
| Loose membership queries | Groups + get\_nodes\_in\_group() |
| Per-node temporary data | set\_meta() / get\_meta() |
| Decouple components from each other | Signals wired in the owner's \_ready() |
| Spawn configured entities at runtime | preload().instantiate() + set properties |
| Variant of a scene with minor changes | Inherited scene (.tscn inheriting .tscn) |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. HealthComponent Usage**

Create a `DestructibleCrate` scene that uses the `HealthComponent` from this chapter. When health reaches 0, play a "break" animation and then queue\_free after 0.5s. The crate should take damage from an Area2D overlap (a hitbox from a melee weapon). Show the crate's script only — assume HealthComponent and HurtboxComponent already exist as scenes.

::::solution[Solution]
```gdscript
extends StaticBody2D

@onready var health  : HealthComponent  = $HealthComponent
@onready var hurtbox : HurtboxComponent = $HurtboxComponent
@onready var anim    : AnimationPlayer  = $AnimationPlayer

func _ready() -> void:
    health.max_health = 30
    hurtbox.hit.connect(health.take_damage)
    health.died.connect(_on_destroyed)

func _on_destroyed() -> void:
    # Disable collision so nothing gets stuck
    $CollisionShape2D.set_deferred("disabled", true)
    anim.play("break")
    await anim.animation_finished
    queue_free()
```
::::
:::

:::problem{difficulty="easy"}
**2. ItemResource Definition**

Define a `WeaponResource` that extends `ItemResource` and adds: `damage` (int), `attack_speed` (float), `range` (float), and `weapon_type` (StringName: &"melee" or &"ranged"). Then create two instances as .tres files: `iron_sword.tres` and `short_bow.tres` with appropriate values (set via @export fields). Show the resource script only.

::::solution[Solution]
```gdscript
# weapon_resource.gd
class_name WeaponResource extends ItemResource

@export var damage       : int   = 10
@export var attack_speed : float = 1.0   # attacks per second
@export var range        : float = 60.0  # pixels (2D) or metres (3D)
@export var weapon_type  : StringName = &"melee"

func get_dps() -> float:
    return damage * attack_speed

# iron_sword.tres: damage=15, attack_speed=1.2, range=55, weapon_type="melee"
# short_bow.tres:  damage=10, attack_speed=0.8, range=300, weapon_type="ranged"
```
::::
:::

:::problem{difficulty="standard"}
**3. Event Bus Integration**

Add three signals to the `GameEvents` autoload: `coin_collected(amount: int)`, `player_health_changed(hp: int, max_hp: int)`, and `wave_started(wave_number: int)`. Show: (1) a Coin scene that emits `coin_collected` on pickup, (2) a HUD scene that listens to all three and updates labels, and (3) a WaveManager that emits `wave_started` on a timer.

::::solution[Solution]
```gdscript
# game_events.gd (autoload)
extends Node
signal coin_collected(amount: int)
signal player_health_changed(hp: int, max_hp: int)
signal wave_started(wave_number: int)

# coin.gd
extends Area2D
@export var value := 1
func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        GameEvents.coin_collected.emit(value)
        queue_free()

# hud.gd
extends CanvasLayer
func _ready() -> void:
    GameEvents.coin_collected.connect(func(v): $CoinsLabel.text = "Coins: %d" % (_coins + v))
    GameEvents.player_health_changed.connect(func(hp, max_hp): $HPBar.value = float(hp)/max_hp)
    GameEvents.wave_started.connect(func(n): $WaveLabel.text = "Wave %d" % n)
var _coins := 0

# wave_manager.gd (autoload or level child)
extends Node
var _wave := 0
@onready var timer: Timer = $WaveTimer
func _ready() -> void:
    timer.timeout.connect(_start_next_wave)
    timer.start(5.0)
func _start_next_wave() -> void:
    _wave += 1
    GameEvents.wave_started.emit(_wave)
    timer.start(30.0)
```
::::
:::

:::problem{difficulty="standard"}
**4. Inherited Scene Enemy Variant**

You have a base `enemy_base.tscn` (CharacterBody2D, Sprite2D, CollisionShape2D, HealthComponent). Create an inherited scene `enemy_armored.tscn` that: doubles max\_health to 200, swaps the sprite to an armored texture, and adds a new child `ArmorComponent` node (a script that reduces all incoming damage by 50%). Show the ArmorComponent script and describe the scene inheritance setup.

::::solution[Solution]
```gdscript
# armor_component.gd
class_name ArmorComponent extends Node

@export var damage_reduction := 0.5  # 50% damage reduction

# Called by the entity before passing damage to HealthComponent
func apply(raw_damage: int) -> int:
    return max(1, int(raw_damage * (1.0 - damage_reduction)))
```

Setup steps:

1. Scene → New Inherited Scene → select enemy\_base.tscn → save as enemy\_armored.tscn.
2. In the Inspector, find HealthComponent → change `max_health` to 200.
3. Select Sprite2D → change Texture to the armored sprite.
4. Add ArmorComponent as a new child node.
5. Attach a new script to the root that overrides `_on_hit`:

```gdscript
# enemy_armored.gd (extends enemy_base.gd)
extends BaseEnemy

@onready var armor: ArmorComponent = $ArmorComponent

func _on_hit(damage: int) -> void:
    var reduced := armor.apply(damage)
    health_comp.take_damage(reduced)
```
::::
:::

:::problem{difficulty="challenge"}
**5. Component Swap at Runtime**

Design a system where a player can pick up a "Rage" powerup that temporarily *swaps out* their `HealthComponent` for a `RageHealthComponent` (which converts damage to temporary speed boost instead of reducing HP). After 10 seconds the original component is restored. Show the RageHealthComponent and the swap code.

::::solution[Solution]
```gdscript
# rage_health_component.gd
class_name RageHealthComponent extends HealthComponent

signal rage_triggered(boost_amount: float)

func take_damage(amount: int) -> void:
    # Instead of losing HP, gain speed
    rage_triggered.emit(amount * 2.0)
    # Health stays the same — emit unchanged values to keep UI correct
    health_changed.emit(health, max_health)

# In player.gd:
@onready var health_comp: HealthComponent = $HealthComponent
@onready var hurtbox: HurtboxComponent    = $HurtboxComponent

var _original_component: HealthComponent = null

func activate_rage(duration := 10.0) -> void:
    # Disconnect old component
    hurtbox.hit.disconnect(health_comp.take_damage)

    # Create and attach rage component
    var rage := RageHealthComponent.new()
    rage.max_health = health_comp.max_health
    rage.health     = health_comp.health
    add_child(rage)

    rage.rage_triggered.connect(func(boost): move_speed += boost)
    hurtbox.hit.connect(rage.take_damage)
    _original_component = health_comp
    health_comp = rage

    # Restore after duration
    await get_tree().create_timer(duration).timeout
    _restore_health_component()

func _restore_health_component() -> void:
    hurtbox.hit.disconnect(health_comp.take_damage)
    health_comp.queue_free()
    health_comp = _original_component
    hurtbox.hit.connect(health_comp.take_damage)
    _original_component = null
```
::::
:::
