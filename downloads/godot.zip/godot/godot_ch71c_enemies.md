---
title: "VS Clone — Enemy Types, Spawning & Navigation"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71C"
meta:
  - "Est. study time: ~90 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated June 2026"
source: "godot_ch71c_enemies.html"
---

## Overview

What makes Vampire Survivors tense isn't any single difficult enemy — it's
 *hundreds* of them. A lone Bat is harmless. The same Bat when you're
 surrounded by thirty, with three Skeletons boxing you into a corner while a
 Golem slowly closes in from the north — that's the game.

This chapter builds the entire enemy system from the ground up. By the end you
 will have: a shared **EnemyBase** class, a
 **NavigationAgent2D** that pathfinds around walls,
 a contact-damage **HitBox**, a pooled **XpGem**
 pickup, three concrete enemy types via **inherited scenes**,
 and an **EnemySpawner** with data-driven wave escalation.

:::callout-connect[What Ch 71A and 71B already gave us]
**From Ch 71A:** the NavigationRegion2D is already baked into
 Main.tscn, ObjectPool and GameManager autoloads exist as skeletons,
 and EnemyContainer (a plain Node) is already a child of Main.tscn.

 **From Ch 71B:** Player.tscn is wired into Main.tscn.
 Player has a HurtBox (Area2D, Layer 2) that detects overlapping enemy HitBoxes.
 `Player.take_damage()` and `Player.gain_xp()` are
 already implemented. We just need to call them correctly.
:::

:::callout-key[Two Godot patterns this chapter teaches]
**1. Inherited scenes** — create one base scene, then derive
 multiple variants that override only what changes (stats, sprite).
 No duplicate node structures, no duplicate scripts.

 **2. Data-driven design with Resources** — wave escalation is
 configured entirely in `.tres` files. Adding a new difficulty
 tier requires zero lines of GDScript.
:::

## 1. NavigationAgent2D — How Pathfinding Works

:::callout-intuition[The problem pathfinding solves]
A simple enemy that moves directly toward the player is one line:
 `velocity = (player.position - position).normalized() * speed`.
 But this enemy gets stuck the instant a wall is between it and the player —
 it presses into the wall forever. NavigationAgent2D solves this by computing
 a path *around* obstacles and handing the enemy a series of waypoints
 to follow instead.
:::

Godot 4's navigation system has three layers:

| Component | What it is | Who creates it |
| --- | --- | --- |
| **NavigationRegion2D** | Defines the walkable area as a baked polygon mesh | Already placed and baked in Main.tscn (Ch 71A) |
| **NavigationServer2D** | Engine singleton that holds the navmesh and answers path queries on a background thread | Automatic — you never touch this directly |
| **NavigationAgent2D** | A node on each enemy that queries the server for a path and tracks progress along it | You — added as a child of EnemyBase.tscn |

The flow each physics frame: enemy sets `nav_agent.target_position`
 to the player's position → NavigationServer2D computes or updates the path
 asynchronously → enemy calls `nav_agent.get_next_path_position()`
 to get the next waypoint → enemy moves toward that waypoint.

NavigationAgent2D — extends Node

Interfaces with NavigationServer2D to provide pathfinding for a parent body.
 Set `target_position` to the destination each frame, then call
 `get_next_path_position()` to get the next waypoint.

| Property | Type | What it does |
| --- | --- | --- |
| target\_position | Vector2 | World-space destination. Set this every frame to the player's global\_position. The server updates the path when this changes significantly. |
| path\_desired\_distance | float | How close the agent needs to be to a waypoint before advancing to the next. 16 px is a reliable default. |
| target\_desired\_distance | float | How close to the final target counts as "arrived." Set to roughly the enemy's contact range (24 px). |
| avoidance\_enabled | bool | RVO peer avoidance. O(n²) cost — keep **false** for large crowds. |
| navigation\_layers | int | Bitmask — must match NavigationRegion2D's navigation\_layers or no path is found. |

:::callout-pitfall[No path on the very first frame]
NavigationAgent2D requests a path asynchronously. On the first
 `_physics_process` call the path hasn't been computed yet.
 `get_next_path_position()` returns the agent's own position,
 making the direction vector `(0,0)` and velocity zero.
 The enemy stands still for one frame, then moves normally.
 This is expected — not a bug.
:::

### Why avoidance is disabled

RVO avoidance has each agent calculate how to avoid all other agents.
 That's O(n²) — doubling the enemy count quadruples the cost. At 200 enemies:
 200² = 40,000 pairwise checks per physics frame. In Vampire Survivors, enemies
 *should* pile onto the player — the crushing horde is the aesthetic.
 Avoidance would spread them out and defuse the tension. Keep it off.

## 2. EnemyBase — Key Design Decisions

### Why a base class instead of one script per enemy?

Bat, Skeleton, and Golem all share the same behaviour: pathfind to player,
 deal contact damage, take damage, drop XP on death. The *only* things
 that differ are their stats (HP, speed, damage, XP value) and their sprite.
 With a base class there is one script for all shared logic. Each enemy type
 is an *inherited scene* that overrides exported stat values in the
 Inspector — no new scripts needed.

### Why queue\_free() instead of ObjectPool for enemies?

Projectiles and XP gems are pooled because they spawn and die hundreds of
 times per minute. Enemies peak at ~20 spawned every 2.5 seconds, and most
 live 3–10 seconds. The instantiation cost is spread out enough that pooling
 provides no meaningful gain, while resetting enemy state (HP, nav target,
 position) would add complexity for nothing. Use `queue_free()`.

### Who detects the damage overlap — enemy or player?

When the enemy's HitBox overlaps the player's HurtBox, the
 *player* detects the overlap and applies damage to itself — not the enemy.
 One signal handler in Player.gd manages all incoming damage regardless of
 how many enemies are touching simultaneously. The enemy's only job is to be
 on the correct collision layer. This is the same architecture used in Ch 71B.

## 3. Build EnemyBase.tscn — Step by Step

EnemyBase.tscn is the parent scene all three enemy types inherit from.
 Build it once here; Bat, Skeleton, and Golem will each be an inherited
 variant with only their sprite and stats changed.

```
Enemy (CharacterBody2D)          ← root — EnemyBase.gd attached here
├── CollisionShape2D             ← defines the physics body for wall sliding
├── Sprite2D                     ← placeholder sprite, overridden per inherited scene
├── HitBox (Area2D)              ← Layer 4, Mask 2 — player HurtBox detects this
│   └── CollisionShape2D         ← slightly smaller than or same size as body shape
└── NavigationAgent2D            ← handles pathfinding each frame
```

### Create the scene

1. **Create a new scene.** In the top menu go to
 **Scene → New Scene**. When prompted to choose a root node,
 click **Other Node**, type `CharacterBody2D`,
 and press Enter. The root node appears in the Scene dock.
2. **Rename the root node.** Single-click the
 `CharacterBody2D` node in the Scene dock to select it.
 Press F2 and rename it to `Enemy`. Press Enter.
3. **Save the scene immediately.** Press Ctrl+S.
 In the Save dialog, navigate to `res://scenes/enemies/`
 (create the folder if it doesn't exist — right-click in the FileSystem dock
 and choose **New Folder**). Save as `EnemyBase.tscn`.
4. **Add CollisionShape2D.** With the `Enemy` root
 selected, click the **+** button at the top of the Scene dock
 (or press Ctrl+A). Search for `CollisionShape2D`
 and double-click it. In the Inspector, set **Shape** to
 **New CapsuleShape2D**. Set Radius to `12` and
 Height to `28`. This is the physics collider for wall sliding.
5. **Add Sprite2D.** Select the `Enemy` root again,
 press Ctrl+A, and add a `Sprite2D`. Leave its texture
 empty for now — each inherited scene will assign its own sprite. Keep it
 selected and confirm it is a direct child of `Enemy` in the
 Scene dock.
6. **Add the HitBox.** Select `Enemy`, press
 Ctrl+A, and add an `Area2D`. Rename it
 `HitBox` (F2). Now add a `CollisionShape2D`
 as a child of `HitBox` (select HitBox first, then
 Ctrl+A). Set its shape to **New CapsuleShape2D**
 with the same Radius 12 and Height 28 — matching the body collider.
7. **Set HitBox collision layers.** Select the `HitBox`
 Area2D node. In the Inspector under **Collision**:

   - Turn **Layer** off entirely, then enable only **Layer 4** (Enemies).
   - Turn **Mask** off entirely, then enable only **Layer 2** (Player).
   - Confirm **Monitoring** is **On** and
    **Monitorable** is **On**.

8. **Add NavigationAgent2D.** Select `Enemy`, press
 Ctrl+A, add `NavigationAgent2D`. In the Inspector set:

   - **Path Desired Distance:** `16`
   - **Target Desired Distance:** `24`
   - **Avoidance Enabled:** **Off**

9. **Attach EnemyBase.gd.** Select the `Enemy` root node.
 Click the scroll icon in the Inspector (or press Ctrl+Shift+A)
 to attach a script. Set the path to
 `res://scenes/enemies/EnemyBase.gd` and click
 **Create**. Replace the default contents with the full script
 from section 4 below.
10. **Save.** Press Ctrl+S. The Scene dock should now
 match the tree diagram above exactly.

:::callout-pitfall[Enemy root must be CharacterBody2D, not Node2D]
`move_and_slide()` is only available on CharacterBody2D.
 If you accidentally chose Node2D or RigidBody2D as the root, the script
 will error on that line. Delete the scene and start over — renaming the
 root type is not possible after creation.
:::

## 4. EnemyBase.gd — Fully Annotated

Every comment below explains *why* the code is written that way,
 not just what it does. Read the comments before copying — they answer the
 questions you would otherwise ask in Ch 71D and Ch 71E.

```gdscript
## res://scenes/enemies/EnemyBase.gd
##
## Base class for all enemy types. Provides: navigation toward the player,
## HitBox group membership so Player.gd can detect damage,
## take_damage() / _die() pipeline, and XP gem drop via ObjectPool.
##
## Concrete types (Bat, Skeleton, Golem) are INHERITED SCENES of EnemyBase.tscn
## with different @export values set in the Inspector — no new scripts needed.

class_name EnemyBase
extends CharacterBody2D

## ── Exported stats ────────────────────────────────────────────────────
## These are the only values that differ between Bat, Skeleton, and Golem.
## Override them in the Inspector on each inherited scene's root node.

@export var max_hp: float     = 30.0   ## starting HP
@export var move_speed: float = 60.0   ## pixels per second
@export var damage: float     = 10.0   ## damage dealt to player per HurtBox overlap
@export var xp_value: int     = 5      ## XP gem value dropped on death

## ── Runtime state ─────────────────────────────────────────────────────
var _hp: float                         ## current HP; set to max_hp in _ready()
var _player: Player = null             ## cached reference; found once in _ready()

## ── Node references ───────────────────────────────────────────────────
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var sprite: Sprite2D             = $Sprite2D

## ── Signals ───────────────────────────────────────────────────────────
## Emitted just before queue_free(). GameManager listens to count kills.
signal died(enemy: EnemyBase)

## ── Lifecycle ─────────────────────────────────────────────────────────
func _ready() -> void:
    _hp = max_hp

    ## Add to "enemies" group so weapons (Ch 71D) can query all live enemies
    ## with get_tree().get_nodes_in_group("enemies") — one hash-map lookup,
    ## much faster than iterating the full scene tree.
    add_to_group("enemies")

    ## Cache the player. get_first_node_in_group() is a single dict lookup.
    ## Works because Player._ready() calls add_to_group("player") first.
    _player = get_tree().get_first_node_in_group("player") as Player

    ## CRITICAL: add HitBox to the group Player.gd filters on.
    ## Player's area_entered handler does:
    ##   if not area.is_in_group("enemy_hitbox"): return
    ## Without this line the player never takes damage — no error, just silence.
    $HitBox.add_to_group("enemy_hitbox")

## ── Movement ──────────────────────────────────────────────────────────
func _physics_process(delta: float) -> void:
    ## If the player was freed (run ended), stop navigating to avoid a null crash.
    if not is_instance_valid(_player):
        return

    ## Update the navigation target every frame. The NavigationServer2D ignores
    ## updates that are too small to recalculate for — this is not expensive.
    nav_agent.target_position = _player.global_position

    ## Get the next waypoint along the computed path.
    ## Frame 1: path not ready yet → returns our own position → direction (0,0)
    ## → velocity (0,0) → enemy stands still for one frame. Expected behaviour.
    var next_pos: Vector2  = nav_agent.get_next_path_position()
    var direction: Vector2 = (next_pos - global_position).normalized()

    velocity = direction * move_speed
    move_and_slide()

    ## Flip the sprite to face the direction of travel so enemies feel responsive.
    if velocity.x != 0.0:
        sprite.flip_h = velocity.x < 0.0

## ── Damage pipeline ───────────────────────────────────────────────────
## Called by weapon nodes (Ch 71D) when a projectile or AOE hits this enemy.
func take_damage(amount: float) -> void:
    _hp -= amount
    if _hp <= 0.0:
        _die()

func _die() -> void:
    ## Emit signal BEFORE queue_free so listeners can still read our properties.
    died.emit(self)

    ## Tell GameManager to increment the kill counter and update the HUD.
    GameManager.on_enemy_killed()

    ## Drop XP gem at our position before we disappear.
    _drop_xp_gem()

    ## Remove from the scene tree. All children freed automatically.
    queue_free()

func _drop_xp_gem() -> void:
    ## Pull a pre-allocated XpGem from the pool — no instantiation spike.
    var gem: XpGem = ObjectPool.acquire("XpGem") as XpGem
    if gem == null:
        return   ## pool was dry — skip silently rather than crash

    gem.value           = xp_value
    gem.global_position = global_position

    ## Parent to EnemyContainer (already exists from Ch 71A) not to Main directly.
    var container := get_tree().get_first_node_in_group("enemy_container")
    if container:
        container.add_child(gem)
```

:::callout-warning[Order matters in \_die()]
The sequence — emit signal → notify GameManager → drop gem →
 `queue_free()` — is intentional. Any code that reads the
 dead enemy's properties (position, xp\_value) must run
 *before* `queue_free()`. Swap the order and you get
 a "invalid get index" crash on the next frame when something tries to
 read a freed object.
:::

## 5. HitBox — Collision Layer Settings Explained

The enemy's HitBox is an Area2D that sits passively in the world.
 The *player's* HurtBox is what detects the overlap and triggers damage.
 This design (covered in Ch 71B section 4) means one signal handler in
 Player.gd manages all damage regardless of how many enemies are touching.

| Property | Value | Reason |
| --- | --- | --- |
| collision\_layer | Layer 4 (Enemies) | Player's HurtBox has Mask = Layer 4. Without this layer the HurtBox never sees the HitBox. |
| collision\_mask | Layer 2 (Player) | Keeps the HitBox from accidentally reacting to other area nodes in the scene. |
| monitoring | On | Required for the area\_entered signal to fire at all. |
| monitorable | On | Required for the *player's* HurtBox to detect this Area2D entering it. |

:::callout-pitfall[Most common enemy damage bug]
In `EnemyBase._ready()`, the HitBox is added to the group
 `"enemy_hitbox"`. Player.gd's handler does
 `if not area.is_in_group("enemy_hitbox"): return` before
 applying damage. If you forget this `add_to_group` call —
 or misspell the group name — the player is permanently invincible with
 no error messages whatsoever. This is the number-one silent bug in
 this project.
:::

## 6. Build XpGem.tscn — Step by Step

The XP gem is an Area2D pickup that spawns at an enemy's death position,
 waits until it enters the player's MagnetArea, then glides toward the player
 and grants XP on contact. It is managed by the ObjectPool set up in Ch 71A.

```
XpGem (Area2D)                   ← root — XpGem.gd attached here
└── CollisionShape2D             ← Layer 3 (XpGems), Mask 2 (Player)
└── Sprite2D                     ← small gem or coloured circle sprite
```

### Create the scene

1. **Create a new scene.** Go to **Scene → New Scene**.
 Choose **Other Node**, search for `Area2D`, and
 press Enter. Rename the root to `XpGem`
 (F2).
2. **Add CollisionShape2D.** Select `XpGem`, press
 Ctrl+A, add `CollisionShape2D`. In the Inspector
 set its Shape to **New CircleShape2D**, Radius `8`.
 This is a small pick-up radius — tight enough that gems don't auto-collect
 from a distance.
3. **Add Sprite2D.** Select `XpGem`, Ctrl+A,
 add `Sprite2D`. Assign a small gem sprite or use a placeholder
 coloured icon. You can use any asset — what matters is its collision, not
 its look.
4. **Set collision layers.** Select the `XpGem` root
 (the Area2D). In the Inspector under **Collision**:

   - **Layer:** off entirely, then enable only **Layer 3** (XpGems).
   - **Mask:** off entirely, then enable only **Layer 2** (Player).
   - Confirm **Monitoring On**, **Monitorable On**.

5. **Attach XpGem.gd.** Select the `XpGem` root, attach
 a script at `res://scenes/pickups/XpGem.gd` (create the
 `pickups` folder if needed). Replace the default contents with
 the script from section 7 below.
6. **Save** as `res://scenes/pickups/XpGem.tscn`.
 Press Ctrl+S.
7. **Register with ObjectPool.** Open
 `res://autoloads/ObjectPool.gd` (created in Ch 71A). In the
 `_ready()` function, add a pool entry for XpGem:

 This pre-allocates 40 gems at run start. 40 covers a full wave of kills
 with headroom to spare.

   ```gdscript
   func _ready() -> void:
       register("XpGem", preload("res://scenes/pickups/XpGem.tscn"), 40)
   ```

:::callout-tip[Why Layer 3 specifically for XpGems?]
The MagnetArea on the player (Ch 71B) has its Mask set to Layer 3 so it
 detects XpGems and nothing else. If you put gems on a different layer
 the MagnetArea never fires `area_entered` and gems are
 never attracted to the player.
:::

## 7. XpGem.gd — The Object Pool Loop

:::callout-intuition[One gem's full lifecycle]
1. Pool pre-allocates 40 gems at run start (invisible, physics off).

 2. Enemy dies → `ObjectPool.acquire("XpGem")` pulls one, enables it.

 3. Gem sits at the death position, waiting.

 4. Player's MagnetArea detects it → `gem.start_attract(player)`.

 5. Each frame: gem moves toward player until within 8 px.

 6. `player.gain_xp(value)` → `ObjectPool.release("XpGem", self)`.

 Back to step 2.
:::

```gdscript
## res://scenes/pickups/XpGem.gd

class_name XpGem
extends Area2D

## Set by EnemyBase._drop_xp_gem() before this node is added to the scene.
var value: int = 5

## Guards against duplicate start_attract() calls — MagnetArea can fire
## area_entered multiple times if the gem wiggles on the boundary.
var _attracting: bool = false
var _player: Player   = null

## Must be higher than player move_speed so gems always catch the player.
const ATTRACT_SPEED: float = 250.0

func _ready() -> void:
    add_to_group("xp_gems")

## Called by Player._on_magnet_area_entered() when this gem enters magnet range.
func start_attract(player: Player) -> void:
    if _attracting:
        return          ## already moving — ignore duplicate call
    _attracting = true
    _player     = player
    add_to_group("xp_gems")   ## re-add in case it was removed on last release

func _physics_process(delta: float) -> void:
    if not _attracting or not is_instance_valid(_player):
        return

    var to_player: Vector2 = _player.global_position - global_position
    var distance: float    = to_player.length()

    if distance < 8.0:
        _player.gain_xp(float(value))
        _reset()
        ObjectPool.release("XpGem", self)
        return

    global_position += to_player.normalized() * ATTRACT_SPEED * delta

func _reset() -> void:
    _attracting = false
    _player     = null
    remove_from_group("xp_gems")
```

:::example[Worked example — does the gem catch a running player?]
Player move\_speed = 120 px/s. Gem ATTRACT\_SPEED = 250 px/s.
 The gem spawns 400 px away and the player sprints directly away. Does the gem catch up?

::::answer[Answer]
Yes — it catches up in about 3.1 seconds.
::::

Relative closing speed = 250 − 120 = 130 px/s. Time to close 400 px:
 400 ÷ 130 ≈ 3.1 s. Because ATTRACT\_SPEED > move\_speed, the gem always
 catches the player. This is intentional — if gems couldn't keep up with
 a running player, movement would become a punishment rather than a choice.
:::

:::callout-tip[Re-adding to group on pool reuse]
`_reset()` calls `remove_from_group("xp_gems")`.
 When the pool reissues the gem, `_ready()` does *not*
 run again — it only runs once at first instantiation. That is why
 `start_attract()` calls `add_to_group("xp_gems")`
 each time it activates the gem.
:::

## 8. Three Enemy Types — Stat Design

Good enemy design in swarm games uses distinct roles rather than just
 scaling health and damage linearly. Each enemy creates a different tactical
 problem for the player:

| Enemy | Role | max\_hp | move\_speed | damage | xp\_value |
| --- | --- | --- | --- | --- | --- |
| **Bat** | Fast flanker. Creates pressure from all directions. Easy to kill, very common early on. | 15 | 90 | 8 | 2 |
| **Skeleton** | Balanced backbone. The main threat throughout most of the run. Medium everything. | 60 | 50 | 12 | 8 |
| **Golem** | Slow wall. Forces concentrated weapon investment before dying. Large XP reward. | 300 | 25 | 25 | 40 |

Notice that XP rewards are not simply proportional to HP. 20 Bats total
 300 HP worth of damage and yield 40 XP — the same as one Golem. Neither
 strategy is strictly better; Bats scatter and some will be missed, while
 the Golem demands sustained damage output but dies in one place. The design
 gives players real trade-offs rather than a dominant strategy.

:::callout-connect[Golems are controlled by WaveConfig, not code]
Golems only appear after 15 minutes. This isn't written into EnemyBase.gd
 or Golem.tscn — it's controlled by which enemy scenes appear in each
 WaveConfig resource (section 11). Removing Golems from early waves
 requires editing a `.tres` file, not touching any GDScript.
:::

## 9. Creating the Three Inherited Scenes

:::callout-intuition[What an inherited scene is]
An inherited scene starts as an exact copy of a parent scene and lets
 you override specific properties without duplicating the node structure.
 If you later add a node to EnemyBase.tscn — say, a HealthBar — all
 three inherited scenes get it automatically. Only what you explicitly
 override in each inherited scene differs.
:::

### Create Bat.tscn

1. **Open EnemyBase.tscn.** In the FileSystem dock, double-click
 `res://scenes/enemies/EnemyBase.tscn` to open it.
2. **Create an inherited scene.** In the top menu go to
 **Scene → New Inherited Scene**. Godot opens a dialog asking
 which scene to inherit from — it should already show EnemyBase.tscn.
 Click **Open**.
3. **Save the new scene.** Press Ctrl+S immediately.
 Save as `res://scenes/enemies/Bat.tscn`.
4. **Override the stats.** In the Scene dock, select the root
 node (`Bat` / CharacterBody2D). In the Inspector you will see
 the EnemyBase exported properties. Set:

 Overridden properties show a small revert icon — this confirms you've
 changed them from the base scene's defaults.

   - **Max Hp:** `15`
   - **Move Speed:** `90`
   - **Damage:** `8`
   - **Xp Value:** `2`

5. **Assign the Bat sprite.** In the Scene dock, select the
 `Sprite2D` child. In the Inspector, assign a bat sprite texture
 to the **Texture** field. The CollisionShape2D, HitBox, and
 NavigationAgent2D are inherited and require no changes.
6. **Save.** Press Ctrl+S. Bat.tscn is complete.

### Create Skeleton.tscn and Golem.tscn

1. **Repeat the same six steps** for Skeleton and Golem —
 starting from **Scene → New Inherited Scene** from
 EnemyBase.tscn each time.
2. **Set Skeleton stats:** max\_hp `60`, move\_speed
 `50`, damage `12`, xp\_value `8`.
 Save as `Skeleton.tscn`.
3. **Set Golem stats:** max\_hp `300`, move\_speed
 `25`, damage `25`, xp\_value `40`.
 Save as `Golem.tscn`. Because the Golem is larger, also
 update the CollisionShape2D Radius to `20` and Height to
 `40` to give it a more imposing hitbox.

:::callout-pitfall[Nodes added to an inherited scene don't propagate back]
If you add a HealthBar node directly to Bat.tscn, only Bat gets it —
 Skeleton and Golem don't. Always add shared nodes to EnemyBase.tscn so
 all inherited scenes receive them automatically. Type-specific additions
 (e.g. a wing flap animation only Bat needs) go in the inherited scene.
:::

## 10. EnemySpawner — Build and Wire into Main.tscn

### How the spawn ring works

Enemies spawned on top of the player are instant and unfair. Enemies
 spawned far away never arrive in time to matter. The sweet spot is a ring
 *just outside the camera's view* — enemies appear at the screen
 edge and walk inward, giving the player a moment to react.

With zoom 1.5× on a 1920×1080 viewport, the camera shows 1280×720 px of
 world. The half-diagonal is √(640²+360²) ≈ 730 px. A spawn radius of
 680–700 px places enemies just beyond every viewport edge at once.

### EnemySpawner.gd

```gdscript
## res://scenes/main/EnemySpawner.gd

class_name EnemySpawner
extends Node

## Ordered array of WaveConfig resources (earliest min_time first).
@export var wave_configs: Array[WaveConfig] = []

## Spawn ring radius — should be just beyond the camera's furthest visible point.
@export var spawn_radius: float = 680.0

var _wave_timer: float  = 0.0
var _player: Player     = null
var _enemy_container: Node = null

func _ready() -> void:
    _player          = get_tree().get_first_node_in_group("player") as Player
    _enemy_container = get_tree().get_first_node_in_group("enemy_container")
    ## 3-second grace period so enemies don't spawn before the player sees the world.
    _wave_timer = 3.0

func _physics_process(delta: float) -> void:
    if GameManager.state != GameManager.State.PLAYING:
        return
    _wave_timer -= delta
    if _wave_timer <= 0.0:
        _spawn_wave()

func _spawn_wave() -> void:
    if wave_configs.is_empty() or not is_instance_valid(_player):
        return

    var cfg: WaveConfig = wave_configs[_get_wave_index()]
    _wave_timer = cfg.interval

    var player_pos: Vector2 = _player.global_position

    for i in cfg.count:
        var angle: float = randf() * TAU
        ## Multiply radius by 0.8–1.2 so enemies form a natural band, not a ring.
        var r: float     = spawn_radius * randf_range(0.8, 1.2)
        var pos: Vector2 = player_pos + Vector2(cos(angle), sin(angle)) * r

        var scene: PackedScene = cfg.enemy_scenes[randi() % cfg.enemy_scenes.size()]
        var enemy: EnemyBase   = scene.instantiate()
        enemy.global_position  = pos
        _enemy_container.add_child(enemy)

## Returns the index of the most advanced WaveConfig active at the current run time.
## Assumes wave_configs is sorted ascending by min_time.
func _get_wave_index() -> int:
    var idx: int = 0
    for i in wave_configs.size():
        if wave_configs[i].min_time <= GameManager.run_timer:
            idx = i
    return idx
```

### Add EnemySpawner to Main.tscn

1. **Open Main.tscn.** In the FileSystem dock, double-click
 `res://scenes/main/Main.tscn`.
2. **Add EnemySpawner as a child of Main.** Select the
 `Main` root node, press Ctrl+A, and add a plain
 `Node`. Rename it `EnemySpawner` (F2).
 Then attach the script `res://scenes/main/EnemySpawner.gd`
 to it (scroll icon in the Inspector, or drag-drop the .gd file onto
 the node).
3. **Position in the scene tree.** In the Scene dock, confirm
 `EnemySpawner` is a direct child of `Main` and
 appears *after* `EnemyContainer` — the container must
 exist before the spawner tries to find it via group in `_ready()`.
4. **Leave wave\_configs empty for now** — you will drag the
 `.tres` files into it in section 11.
5. **Save Main.tscn.** Press Ctrl+S.

:::example[Worked example — which wave fires at 4 min 30 s?]
Run time is 270 s. Configs: Wave 0 (0 s), Wave 1 (60 s),
 Wave 2 (300 s), Wave 3 (600 s). Which config is active?

::::answer[Answer]
Wave 1 — 60 ≤ 270, but Wave 2 starts at 300 which hasn't been reached.
::::

`_get_wave_index()` iterates all configs: Wave 0 (0 ≤ 270 ✓ → idx=0),
 Wave 1 (60 ≤ 270 ✓ → idx=1), Wave 2 (300 ≤ 270 ✗ → stops updating).
 Returns 1. Spawner uses Wave 1's count, interval, and enemy pool.
:::

## 11. WaveConfig Resource — Data-Driven Escalation

Instead of hard-coding escalation inside EnemySpawner.gd, each difficulty
 phase is a `WaveConfig` Resource. A designer can add a new wave
 tier, change enemy counts, or adjust timing entirely in the Inspector —
 zero GDScript required.

### WaveConfig.gd

```gdscript
## res://resources/WaveConfig.gd

class_name WaveConfig
extends Resource

## Run time (seconds) at which this config becomes active. Use 0.0 for the first.
@export var min_time: float = 0.0

## Enemies spawned per wave while this config is active.
@export var count: int = 5

## Seconds between each wave.
@export var interval: float = 5.0

## Pool of enemy scenes to randomly draw from each spawn event.
@export var enemy_scenes: Array[PackedScene] = []
```

### Create the five wave config .tres files

1. **Create the WaveConfig.gd script.** In the FileSystem dock,
 navigate to `res://resources/` (create the folder if needed).
 Right-click → **New Script**, name it `WaveConfig.gd`,
 and paste the script above. Save with Ctrl+S.
2. **Create wave\_0.tres.** In the FileSystem dock, right-click
 `res://resources/waves/` (create this subfolder first if needed)
 → **New Resource**. In the dialog, type `WaveConfig`
 and double-click it. Save as `wave_0.tres`. In the Inspector set:

   - **Min Time:** `0`
   - **Count:** `5`
   - **Interval:** `5.0`
   - **Enemy Scenes:** click the array, add 1 element,
    drag `Bat.tscn` into slot 0.

3. **Create wave\_1.tres.** Same process. Values: min\_time
 `60`, count `8`, interval `4.0`,
 enemy\_scenes = [Bat.tscn, Skeleton.tscn].
4. **Create wave\_2.tres.** min\_time `300`, count
 `12`, interval `3.5`,
 enemy\_scenes = [Bat.tscn, Skeleton.tscn].
5. **Create wave\_3.tres.** min\_time `600`, count
 `15`, interval `3.0`,
 enemy\_scenes = [Bat.tscn, Skeleton.tscn, Golem.tscn].
6. **Create wave\_4.tres.** min\_time `900`, count
 `20`, interval `2.5`,
 enemy\_scenes = [Skeleton.tscn, Golem.tscn]. (Bats drop off at 15 min —
 the Skeleton/Golem pressure becomes the new normal.)
7. **Assign configs to EnemySpawner.** Open Main.tscn, select
 the `EnemySpawner` node. In the Inspector, find the
 **Wave Configs** array. Click it, set size to 5. Drag
 `wave_0.tres` through `wave_4.tres` into slots
 0–4 *in order*. The array must be sorted ascending by min\_time
 for `_get_wave_index()` to work correctly.
8. **Save Main.tscn.** Press Ctrl+S.

| File | min\_time | count | interval | enemy\_scenes |
| --- | --- | --- | --- | --- |
| wave\_0.tres | 0 s | 5 | 5.0 s | Bat |
| wave\_1.tres | 60 s | 8 | 4.0 s | Bat, Skeleton |
| wave\_2.tres | 300 s | 12 | 3.5 s | Bat, Skeleton |
| wave\_3.tres | 600 s | 15 | 3.0 s | Bat, Skeleton, Golem |
| wave\_4.tres | 900 s | 20 | 2.5 s | Skeleton, Golem |

## 12. Verification Checklist

Press F5 to run the project. Work through each check in order —
 earlier failures will cause later ones, so fix them top-to-bottom.

1. **No errors in the Output panel.** If you see
 *"Class EnemyBase not found"*, the script hasn't been saved or the
 `class_name` line is missing. If you see
 *"Invalid get index 'state' on base 'null'"*, GameManager wasn't
 registered as an autoload in Project → Project Settings → Autoloads.
2. **Enemies appear after 3 seconds, not on top of the player.**
 If they spawn at (0,0): EnemySpawner couldn't find the player via group —
 check Player.\_ready() calls `add_to_group("player")`.
 If they spawn directly on the player: spawn\_radius is set to 0.
3. **Enemies path around walls.** Walk the player behind a wall
 and confirm enemies route around it. If they walk through walls: the
 NavigationRegion2D navmesh isn't baked (Ch 71A, section 4) or the
 NavigationAgent2D's navigation\_layers bitmask doesn't match the region's.
4. **Player HP decreases on enemy contact.** Watch the HUD HP bar.
 If it doesn't drop: open the Remote debugger (Debug → Remote Scene Tree),
 find an enemy's HitBox, and confirm it is in group `"enemy_hitbox"`.
 If the group is missing, EnemyBase.\_ready() didn't run or the line was deleted.
5. **A gem sprite appears at each enemy death location.**
 If no gem appears: ObjectPool.register("XpGem", ...) was not called in
 ObjectPool.\_ready(). If the gem appears at (0,0): `gem.global_position`
 was set after `add_child()` in a way that lost the assignment —
 verify the order in `_drop_xp_gem()`.
6. **Gems move toward the player when within magnet range.**
 If gems sit still: check MagnetArea's Mask includes Layer 3 (XpGems),
 and the XpGem CollisionShape2D is on Layer 3. Also confirm
 Player.\_on\_magnet\_area\_entered() calls `gem.start_attract(self)`.
7. **Player XP increases when gems are collected.**
 Use the Remote debugger → find the Player node → watch
 `current_xp` rise as gems are absorbed. If it doesn't:
 `player.gain_xp()` is not being called — check the distance
 threshold in XpGem.\_physics\_process().

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
In one sentence, explain the difference between NavigationRegion2D and NavigationAgent2D, and which one is added to each enemy.

::::solution[Solution]
NavigationRegion2D defines the *walkable area* in the world (placed once in Main.tscn); NavigationAgent2D is a per-enemy node that queries that area for a path to follow. **NavigationAgent2D goes on each enemy.**
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
What happens on the very first `_physics_process` call on an enemy, before the path has been computed? Why doesn't this cause a bug?

::::solution[Solution]
`get_next_path_position()` returns the agent's own position.
 Direction = (own\_pos − own\_pos).normalized() = (0,0). Velocity = (0,0). The enemy
 stands still for exactly one frame, then the path arrives and movement begins normally.
 No crash because `(0,0).normalized()` returns `(0,0)` in Godot
 rather than dividing by zero.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Walk through the signal chain that breaks if you forget `$HitBox.add_to_group("enemy_hitbox")` in EnemyBase.\_ready(). Identify exactly where it fails and why no error is printed.

::::solution[Solution]
A Bat walks into the player. Player's HurtBox fires
 `area_entered(bat_hitbox)`. Player's handler checks:
 `if not area.is_in_group("enemy_hitbox"): return`.
 The HitBox is NOT in the group → the handler returns immediately.
 `take_damage()` is never called. The player takes no damage.
 No error is printed because the code path is valid GDScript — it simply
 returns early. A silent logic failure with no warnings of any kind.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
The run timer is at 8 minutes (480 seconds). Using the wave table from section 11, what are the active spawn count, interval, and possible enemy types?

::::solution[Solution]
Check which configs have min\_time ≤ 480:
 Wave 0 (0 ✓), Wave 1 (60 ✓), Wave 2 (300 ✓), Wave 3 (600 ✗).
 **Wave 2 is active:** count = 12, interval = 3.5 s,
 pool = [Bat, Skeleton]. Golems haven't appeared yet — Wave 3 starts at 600 s.
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
Why does `_die()` emit the `died` signal before calling `queue_free()`? What would break if the order were reversed?

::::solution[Solution]
Any listener on the `died` signal might read the enemy's properties
 (its `global_position`, `xp_value`). If `queue_free()`
 ran first, those properties would be on a freed object. Accessing them on the same
 frame would silently return defaults; on a later frame it would crash with
 "Invalid access to property 'global\_position' on a freed object." Emit first,
 free last — always.
::::
:::

:::problem[Problem 6 challenge]{difficulty="challenge"}
Add a **split-on-death** variant: when a LargeBat dies it spawns two
 regular Bats at slightly offset positions. Write the `_die()` override
 without modifying EnemyBase.gd. Where should the new Bats be parented?

::::solution[Solution]
```gdscript
## LargeBat.gd — attach to an inherited scene of EnemyBase.tscn
class_name LargeBat
extends EnemyBase

@export var split_scene: PackedScene  ## assign Bat.tscn in the Inspector

func _die() -> void:
    var container := get_tree().get_first_node_in_group("enemy_container")
    if container and split_scene:
        for offset: Vector2 in [Vector2(-20, 0), Vector2(20, 0)]:
            var bat: EnemyBase = split_scene.instantiate()
            bat.global_position = global_position + offset
            container.add_child(bat)
    ## Run the normal death sequence last — this calls queue_free(),
    ## so our position must be read BEFORE super._die() is called.
    super._die()
```

New Bats are parented to EnemyContainer — the same parent all spawned enemies use.
 `super._die()` runs last because it calls `queue_free()`;
 reading `global_position` after that would crash.
::::
:::

## Summary

:::summary
## Chapter 71C — Key Concepts

| Concept | Implementation | Why this way |
| --- | --- | --- |
| NavigationAgent2D | Child of enemy; target\_position set each frame; avoidance off | Background-thread pathfinding; O(n²) avoidance too expensive for large crowds |
| Base class pattern | EnemyBase.gd; Bat/Skeleton/Golem are inherited scenes, no new scripts | One script for shared logic; stats overridden per type in Inspector |
| Damage detection | Player HurtBox detects enemy HitBox group; enemy has no signal handler | One handler regardless of enemy count; i-frame management stays in Player |
| XP gem pool loop | ObjectPool.get → configure → add\_child → start\_attract → gain\_xp → release | No instantiation spikes; gem reused across many deaths per minute |
| Inherited scenes | Scene → New Inherited Scene from EnemyBase.tscn | Override stats and sprite only; base node structure inherited automatically |
| Spawn ring | Random angle × radius from player; outside camera view | Enemies appear threatening but not teleporting directly onto the player |
| WaveConfig | Resource with min\_time, count, interval, enemy\_scenes | Data-driven; add/remove wave tiers by editing .tres files, no code changes |
:::

The arena is alive — enemies swarm from all directions, the player dodges,
 XP gems scatter across the ground. But the player still can't fight back.
 **Ch 71D** builds the three weapon archetypes that make this a game:
 the Garlic AOE pulse, the Magic Wand projectile, and the Axe arc throw —
 all self-firing, all scaling with player stats, none requiring a single line
 of new player code.
