---
title: "Export & Deployment"
source: "godot_ch41_export_deploy.html"
---

Part IV · Chapter 41

# Export & Deployment

Prerequisite: Ch 3 (project structure) · est. 75 min

## Overview

Building a playable game file and getting it in front of players
 involves more than clicking *Export*. You need the right
 export templates, correct platform signing and bundling, knowledge
 of what Godot packs into the binary, and — for a professional
 workflow — an automated pipeline that builds every platform on
 every commit.

This chapter covers the full export workflow:

- Downloading and managing export templates
- Creating export presets and the per-platform settings that
 matter most
- Platform-specific requirements: code signing, icon formats,
 store compliance
- PCK files as standalone resource packs and runtime DLC loading
- Feature flags for platform-conditional code
- Headless command-line export and a GitHub Actions CI example

## 1 · Export Templates

### Downloading templates

An **export template** is a stripped Godot runtime
 binary — the engine without the editor — compiled for a specific
 platform and optimisation level. The editor you downloaded does
 not include templates; you must install them separately.

In the editor: *Editor → Manage Export Templates → Download*.
 The manager fetches the template pack that matches your exact Godot
 version from `downloads.tuxfamily.org` and extracts it
 to the user data directory.

Templates are stored at:

- Windows: `%APPDATA%\Godot\export_templates\4.6.stable\`
- macOS: `~/Library/Application Support/Godot/export_templates/4.6.stable/`
- Linux: `~/.local/share/godot/export_templates/4.6.stable/`

:::callout-warning[Warning]
Export templates are version-locked. A template for Godot 4.5
 will not work with a 4.6 editor. Always download the template
 matching the exact version shown in *Help → About Godot*.
 In CI, pin both the editor and template to the same version
 string.
:::

### Export presets

An **export preset** is a named configuration that
 describes one target platform and its settings. You can have
 multiple presets for the same platform (e.g. a debug build and a
 release build for Steam).

Create a preset: *Project → Export → Add… → choose platform*.
 The most important settings in every preset:

| Setting | Effect |
| --- | --- |
| Export Mode | "Export all resources in the project" vs "Export selected scenes and dependencies" — use selected for smaller builds |
| Custom features | Comma-separated tags readable via `OS.has_feature()` |
| Encryption key | AES-256 key to encrypt the PCK (protects assets from extraction) |
| Debug / Release template | Debug builds include editor symbols and verbose output; release builds strip them for smaller size |
| Runnable | Enables the "Run on device" button for mobile targets |

Godot Project

+ Export Template

export

PCK

Windows

.exe + .pck / embed

macOS

.app bundle (notarise)

Linux

ELF binary + .pck

Web (HTML5)

.html + .wasm + .pck

Android

.apk / .aab (keystore)

iOS

Xcode project (sign)

Each target needs an

Export Template installed

Editor → Manage Export Templates

One Godot project, six export targets. Every target bundles your project into a PCK archive alongside a platform-specific runtime binary. Each target requires matching export templates to be installed first.

## 2 · Platform Specifics

### Windows

The Windows export produces an `.exe` plus a
 `.pck` file (or an embedded single-file
 `.exe` when *Embed PCK* is enabled). Key
 settings:

- **Application icon** — must be a
 `.ico` file. Convert your PNG at
 `convertio.co` or with ImageMagick.
- **Code signing** — optional for standalone, required
 for Microsoft Store. Use `signtool.exe` with a
 code-signing certificate. Without a certificate, Windows
 SmartScreen will show an "Unknown publisher" warning on first
 run.
- **Embed PCK** — produces a single distributable
 `.exe` with no separate
 `.pck` file. Convenient for itch.io uploads.

### macOS

The macOS export produces an `.app` bundle (a directory
 with a specific layout) or a `.dmg` disk image. macOS
 has strict security requirements:

- **Codesigning** — required to avoid "damaged app"
 errors on Apple Silicon. Sign with
 `codesign --deep --force --sign "Developer ID Application: ..."`.
- **Notarisation** — required for distribution outside
 the App Store. Use `xcrun notarytool` to submit the
 signed `.app` to Apple's servers and staple the
 ticket.
- **Info.plist** — set `NSMicrophoneUsageDescription`,
 `NSCameraUsageDescription`, etc. if your game requests
 those permissions.

### Linux

The Linux export produces a single ELF binary plus a
 `.pck`. Linux has no mandatory signing. Best
 practices:

- Export as `x86_64` for broad desktop compatibility.
 If you target Steam Deck, also export `x86_64` (the
 Deck runs x86\_64 Linux).
- Set the executable bit in your archive:
 `chmod +x MyGame.x86_64`. Zip files do not preserve
 this bit — use `.tar.gz` for Linux distributions.
- For itch.io, the **butler** CLI preserves
 permissions automatically.

### Web (HTML5)

The Web export produces an `.html` page, a
 `.wasm` binary, a `.js` loader, and one or
 more `.pck` files. Important constraints:

- **SharedArrayBuffer** — required for threading.
 The server must send the headers
 `Cross-Origin-Opener-Policy: same-origin` and
 `Cross-Origin-Embedder-Policy: require-corp`. GitHub
 Pages does not send these by default; use itch.io or a custom
 server.
- **Audio autoplay** — browsers block audio until the
 user interacts with the page. Godot handles this automatically
 by resuming the audio context on the first input event.
- **File system** — only the user:// path is writable,
 backed by IndexedDB. Do not use absolute system paths.

### Android

Android export requires the Android SDK and a signing keystore.
 Steps:

1. Install Android Studio and note the SDK path.
2. In the editor: *Editor → Editor Settings → Export → Android*
 → set the SDK path and `adb` path.
3. Generate a debug keystore with keytool for development:
 `keytool -genkey -v -keystore debug.keystore -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android`
4. In the export preset → Keystore section, set the
 `debug.keystore` path and matching password for
 sideloading. Use a release keystore signed by your production
 key for Play Store uploads.

The export produces an `.apk` (sideload) or
 `.aab` (Play Store bundle, which Google repackages
 for device-specific APKs).

### iOS

iOS export requires a Mac with Xcode. Godot exports an Xcode project
 directory that you then build and sign with Xcode or
 `xcodebuild`. You need an Apple Developer account
 ($99/year) to sign and distribute on real devices or the App Store.

:::callout-tip[Tip]
For testing on iOS without a paid account, you can sideload an
 `.ipa` via AltStore or Sideloadly — but the app expires
 after 7 days without a paid certificate.
:::

## 3 · PCK Files & Resource Packs

### PCK structure

A **PCK** (pack) file is a Godot-specific archive that
 maps virtual `res://` paths to compressed binary data.
 When you export a game, all project resources are packed into one
 or more PCK files and shipped alongside (or embedded in) the
 executable.

PCK files are used for:

- The main game data shipped at release
- DLC or expansion content loaded at runtime
- Game mods contributed by the community
- Patches that override specific resources without replacing the
 entire build

### Loading a PCK at runtime

Load an additional PCK file at runtime with
 `ProjectSettings.load_resource_pack()`. The virtual
 filesystem is updated immediately — any
 `res://` path in the PCK becomes accessible:

```gdscript
func load_dlc(path: String) -> bool:
    # path can be an absolute filesystem path or a user:// path
    var ok := ProjectSettings.load_resource_pack(path)
    if not ok:
        push_error("Failed to load DLC pack: " + path)
        return false

    # Resources from the pack are now accessible via res://
    if ResourceLoader.exists("res://dlc/dungeon_1.tscn"):
        var scene := load("res://dlc/dungeon_1.tscn") as PackedScene
        get_tree().change_scene_to_packed(scene)
    return true
```

:::callout-key[Key concept]
When two PCK files both define the same `res://` path,
 the last one loaded wins. This is intentional — it is the
 mechanism that allows patches to override base-game assets
 without modifying the original PCK.
:::

To export a standalone PCK without an executable (useful for DLC
 or patches), use *Project → Export → Export PCK/ZIP*
 instead of *Export Project*. The resulting
 `.pck` contains only the resources, with no runtime
 binary.

## 4 · Feature Flags & Build Profiles

### Custom features

Export presets accept a comma-separated list of
 **custom features** — arbitrary string tags baked into
 the build. Combined with the built-in platform tags, these let you
 write a single codebase that behaves differently on each target.

Built-in feature tags (always present):

| Tag | Present when |
| --- | --- |
| `windows` | Running on Windows |
| `macos` | Running on macOS |
| `linux` | Running on Linux |
| `android` | Running on Android |
| `ios` | Running on iOS |
| `web` | Running in the browser |
| `debug` | Debug build or running in editor |
| `release` | Release/template build |
| `mobile` | Android or iOS |
| `editor` | Running inside the editor |

### OS.has\_feature()

Query any feature tag at runtime with
 `OS.has_feature("tag")`:

```gdscript
func _ready() -> void:
    if OS.has_feature("mobile"):
        # Show on-screen buttons, hide keyboard hints
        $TouchControls.visible = true
        $KeyboardHints.visible  = false
    else:
        $TouchControls.visible = false
        $KeyboardHints.visible  = true

    if OS.has_feature("steam"):
        # "steam" was added as a custom feature in the Steam preset
        SteamAPI.init()

    if OS.has_feature("demo"):
        # Lock content beyond level 3 in the demo build
        _max_level = 3
```

You can also branch resource loading based on features, which
 is useful for platform-specific assets (lower-res textures on
 mobile, platform-specific control glyphs):

```gdscript
func _get_controls_texture() -> Texture2D:
    if OS.has_feature("android") or OS.has_feature("ios"):
        return preload("res://ui/controls_touch.png")
    elif OS.has_feature("windows"):
        return preload("res://ui/controls_xbox.png")
    else:
        return preload("res://ui/controls_keyboard.png")
```

git push

triggers CI

Setup

Install Godot

+ templates

Export

godot --headless

--export-release

Upload

butler push

→ itch.io

Done ✓

live for

players

① trigger

② install

③ export

④ deploy

⑤ shipped

GitHub Actions — Automated Export Pipeline

Every push triggers the pipeline: install Godot headless + export templates → run `godot --headless --export-release` → upload with `butler`. No manual steps after setup.

## 5 · Automated Export (CI)

### Headless export command

Godot can export without a display using the
 `--headless` flag. The full CLI syntax for exporting
 a preset is:

```bash
# Export the "Linux/X11" preset to a specific path
godot --headless --export-release "Linux/X11" build/MyGame.x86_64

# Export a debug build
godot --headless --export-debug "Windows Desktop" build/MyGame.exe

# Export only a PCK (no executable)
godot --headless --export-pack "Linux/X11" build/MyGame.pck
```

The preset name (e.g. `"Linux/X11"`) must match the name
 in `export_presets.cfg` exactly, including
 capitalisation.

:::callout-tip[Tip]
Commit `export_presets.cfg` to version control but
 *do not* commit `export_presets.cfg.bak`. Add
 `*.bak` to your `.gitignore`. The
 `.cfg` stores preset names and settings but not the
 encryption key or signing credentials — store those as CI secrets
 instead.
:::

### GitHub Actions example

A minimal workflow that exports to Linux and Windows on every push
 to `main`:

```yaml
# .github/workflows/export.yml
name: Export Godot Game

on:
  push:
    branches: [main]

env:
  GODOT_VERSION: "4.6.stable"
  EXPORT_NAME: "MyGame"

jobs:
  export:
    runs-on: ubuntu-latest
    container:
      image: barichello/godot-ci:4.6   # community image with Godot + templates

    steps:
      - uses: actions/checkout@v4

      - name: Set up export templates
        run: |
          mkdir -p ~/.local/share/godot/export_templates
          mv /root/.local/share/godot/export_templates/${GODOT_VERSION} \
             ~/.local/share/godot/export_templates/${GODOT_VERSION}

      - name: Export Linux
        run: |
          mkdir -p build/linux
          godot --headless --export-release "Linux/X11" \
                build/linux/${EXPORT_NAME}.x86_64

      - name: Export Windows
        run: |
          mkdir -p build/windows
          godot --headless --export-release "Windows Desktop" \
                build/windows/${EXPORT_NAME}.exe

      - name: Upload Linux artifact
        uses: actions/upload-artifact@v4
        with:
          name: linux-build
          path: build/linux/

      - name: Upload Windows artifact
        uses: actions/upload-artifact@v4
        with:
          name: windows-build
          path: build/windows/
```

The `barichello/godot-ci` Docker image bundles Godot
 headless and export templates for every supported platform. Pin the
 image tag to a specific Godot version (e.g. `:4.6`) so
 your workflow is reproducible.

:::callout-connect[Connect]
For signing, pass Android keystore passwords and macOS notarisation
 credentials as GitHub Actions secrets:
 `${{ secrets.KEYSTORE_PASSWORD }}`. Write them to
 temporary files inside the CI job and delete them at the end.
 Never hard-code signing credentials in `export_presets.cfg`
 or your workflow file.
:::

### Deploying to itch.io via butler

After exporting, push to itch.io automatically using the
 **butler** CLI:

```yaml
      - name: Push to itch.io
        env:
          BUTLER_API_KEY: ${{ secrets.BUTLER_API_KEY }}
        run: |
          curl -L -o butler.zip \
            https://broth.itch.ovh/butler/linux-amd64/LATEST/archive/default
          unzip butler.zip
          chmod +x butler
          ./butler push build/linux/ \
            your-username/your-game:linux-stable \
            --userversion "$(git describe --tags --abbrev=0)"
          ./butler push build/windows/ \
            your-username/your-game:windows-stable \
            --userversion "$(git describe --tags --abbrev=0)"
```

The `--userversion` flag tags the itch.io upload with
 the Git tag (e.g. `v1.2.0`). Itch shows this version
 number to players on the download page.

## Summary

| Task | How |
| --- | --- |
| Install templates | Editor → Manage Export Templates → Download |
| Create a preset | Project → Export → Add → choose platform |
| Single-file Windows build | Enable "Embed PCK" in Windows preset |
| macOS distribution | Sign with `codesign`, notarise with `notarytool` |
| Linux permissions | Use `.tar.gz` to preserve executable bit |
| Web SharedArrayBuffer | Set COOP / COEP headers on the server |
| Android build | SDK + keystore + `.apk` or `.aab` |
| Runtime DLC / mods | `ProjectSettings.load_resource_pack(path)` |
| Platform branching | Custom features + `OS.has_feature("tag")` |
| Headless CLI export | `godot --headless --export-release "Preset Name" out/path` |
| CI / CD | GitHub Actions + `barichello/godot-ci` Docker image |
| Itch.io deploy | `butler push` with BUTLER\_API\_KEY secret |

## Mixed Practice

:::problem{difficulty="easy"}
**1. Template version mismatch.**
 A developer exports a game and gets the error
 *"No export template found at the expected path"* even
 though export templates are installed. What are the two most
 likely causes, and how does each get fixed?

::::solution[Solution]
**Cause 1 — Version mismatch:** The installed
 template version does not match the editor version exactly
 (e.g. templates for 4.5 but editor is 4.6). Fix: open
 *Editor → Manage Export Templates* and download
 templates for the current version. The version string is
 shown in *Help → About Godot*.

**Cause 2 — Wrong preset selected:** The
 export preset was set to use a "custom template" path that
 no longer exists on disk. Fix: in the preset settings,
 clear the custom template fields to use the default installed
 templates.
::::
:::

:::problem{difficulty="easy"}
**2. Feature flag touch controls.**
 Write a `_ready()` function for a
 `GameHUD` node that shows a
 `$TouchPad` control only on mobile platforms
 (Android or iOS), and shows a `$KeyboardReminder`
 label only on desktop platforms (Windows, macOS, Linux).
 Use `OS.has_feature()`.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var is_mobile := OS.has_feature("mobile")
    $TouchPad.visible        = is_mobile
    $KeyboardReminder.visible = not is_mobile
```

`OS.has_feature("mobile")` returns
 `true` on both Android and iOS, so a single
 check covers both platforms.
::::
:::

:::problem{difficulty="standard"}
**3. Runtime DLC loader.**
 Write a complete `DLCManager` autoload with a
 method `install_pack(path: String) -> Error` that:
 loads the PCK at `path`,
 emits a signal `pack_installed(pack_path: String)`
 on success, pushes an error and returns
 `ERR_FILE_NOT_FOUND` if the file doesn't exist,
 and returns `FAILED` if the pack fails to load.

::::solution[Solution]
```gdscript
# dlc_manager.gd — registered as autoload "DLCManager"
extends Node

signal pack_installed(pack_path: String)

func install_pack(path: String) -> Error:
    if not FileAccess.file_exists(path):
        push_error("DLC pack not found: " + path)
        return ERR_FILE_NOT_FOUND

    var ok := ProjectSettings.load_resource_pack(path)
    if not ok:
        push_error("Failed to load DLC pack: " + path)
        return FAILED

    pack_installed.emit(path)
    return OK
```
::::
:::

:::problem{difficulty="standard"}
**4. Headless export script.**
 Write a bash script `export_all.sh` that exports
 four presets ("Linux/X11", "Windows Desktop", "Web",
 "Android") to a `build/` directory, creates the
 output subdirectory for each, and exits with a non-zero code
 if any export fails.

::::solution[Solution]
```bash
#!/usr/bin/env bash
set -euo pipefail

GODOT="${GODOT_BIN:-godot}"    # override with GODOT_BIN env var if needed
NAME="MyGame"

declare -A PRESETS=(
    ["Linux/X11"]="build/linux/${NAME}.x86_64"
    ["Windows Desktop"]="build/windows/${NAME}.exe"
    ["Web"]="build/web/index.html"
    ["Android"]="build/android/${NAME}.apk"
)

for preset in "${!PRESETS[@]}"; do
    outfile="${PRESETS[$preset]}"
    outdir="$(dirname "$outfile")"
    mkdir -p "$outdir"
    echo "==> Exporting '$preset' to $outfile"
    "$GODOT" --headless --export-release "$preset" "$outfile"
done

echo "All exports completed successfully."
```
::::
:::

:::problem{difficulty="challenge"}
**5. Patch PCK system.**
 Design a patch system where the base game loads a
 `base.pck` on startup and then checks a
 `user://patches/` folder for numbered patch files
 (`patch_001.pck`, `patch_002.pck`, …).
 Patches should be loaded in order so later patches override
 earlier ones. Write the complete autoload that implements
 this, including listing files in user:// and sorting them
 numerically.

::::solution[Solution]
```gdscript
# patch_loader.gd — autoload "PatchLoader"
extends Node

const PATCH_DIR := "user://patches/"

func _ready() -> void:
    _apply_patches()

func _apply_patches() -> void:
    var dir := DirAccess.open(PATCH_DIR)
    if dir == null:
        return   # no patches directory yet

    var patches: Array[String] = []
    dir.list_dir_begin()
    var fname := dir.get_next()
    while fname != "":
        if not dir.current_is_dir() and fname.ends_with(".pck"):
            patches.append(fname)
        fname = dir.get_next()
    dir.list_dir_end()

    # Sort numerically by the number embedded in the filename
    patches.sort_custom(func(a, b):
        var na := a.get_basename().split("_")[-1].to_int()
        var nb := b.get_basename().split("_")[-1].to_int()
        return na < nb
    )

    for patch_name in patches:
        var full_path := PATCH_DIR + patch_name
        var ok := ProjectSettings.load_resource_pack(full_path)
        if ok:
            print("Loaded patch: ", patch_name)
        else:
            push_error("Failed to load patch: ", patch_name)
```
::::
:::

:::problem{difficulty="challenge"}
**6. GitHub Actions multi-platform matrix.**
 Rewrite the GitHub Actions workflow from Section 5 using a
 job *matrix* so each platform (Linux, Windows, Web)
 runs in parallel as a separate job, and a final
 `release` job that depends on all three uses
 `actions/upload-artifact` and the GitHub
 Releases API to attach all build artifacts to a tag release
 when the push is a version tag (matching
 `v*.*.*`).

::::solution[Solution]
```yaml
# .github/workflows/export.yml
name: Export & Release

on:
  push:
    tags: ["v*.*.*"]   # only run on version tags

env:
  GODOT_VERSION: "4.6.stable"
  EXPORT_NAME: "MyGame"

jobs:
  export:
    runs-on: ubuntu-latest
    container:
      image: barichello/godot-ci:4.6

    strategy:
      matrix:
        include:
          - preset: "Linux/X11"
            dir: linux
            file: MyGame.x86_64
          - preset: "Windows Desktop"
            dir: windows
            file: MyGame.exe
          - preset: "Web"
            dir: web
            file: index.html

    steps:
      - uses: actions/checkout@v4

      - name: Set up templates
        run: |
          mkdir -p ~/.local/share/godot/export_templates
          mv /root/.local/share/godot/export_templates/${GODOT_VERSION} \
             ~/.local/share/godot/export_templates/${GODOT_VERSION}

      - name: Export ${{ matrix.preset }}
        run: |
          mkdir -p build/${{ matrix.dir }}
          godot --headless --export-release "${{ matrix.preset }}" \
                build/${{ matrix.dir }}/${{ matrix.file }}

      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: build-${{ matrix.dir }}
          path: build/${{ matrix.dir }}/

  release:
    needs: export
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Download all artifacts
        uses: actions/download-artifact@v4
        with:
          path: artifacts/

      - name: Create Release
        uses: softprops/action-gh-release@v2
        with:
          files: artifacts/**/*
          generate_release_notes: true
```
::::
:::
