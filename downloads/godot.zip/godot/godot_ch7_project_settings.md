---
title: "Project Settings, Render Backends & Configuration"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 7"
meta:
  - "Est. study time: ~50 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "markdown"
---

## Overview

Before you write a single line of gameplay code, every project needs four things
 configured correctly: an Input Map so actions aren't hard-coded to key names, a
 render backend chosen for your target platforms, a viewport size and stretch mode
 matched to your art style, and a handful of Autoloads for cross-scene systems.
 This chapter covers all of that, plus the Feature Tag system that lets you write
 platform-conditional behaviour without `#ifdef` preprocessor directives.

:::callout-key[Prerequisites]
- Chapters 1–6: nodes, GDScript, signals, resources.
- Have opened at least one project in Godot — you'll be navigating menus.
:::

## 1. The Project Settings Dialog

All global project configuration lives in `project.godot` at the
 project root. Open it through **Project → Project Settings**
 (Ctrl+Alt+S on Windows/Linux, Cmd+, on macOS). Every
 change you make in the dialog is written back to `project.godot`
 automatically.

### Navigating the Dialog

- Use the **search bar** at the top to filter by setting name — far faster than browsing categories.
- Click **Advanced Settings** (top-right toggle) to reveal rarely-needed low-level options that are hidden by default.
- Hover any setting label for a tooltip describing its purpose and valid range.
- Settings that differ from their default show in **bold**. Click the reset arrow (↺) to restore the default.
- The **Input Map** and **Autoload** tabs are separate tabs at the top of the dialog, not categories in the left panel.

### Key Setting Categories

| Category path | What lives there |
| --- | --- |
| Application → General | Project name, icon, **main scene** (the scene that runs at launch) |
| Display → Window → Size | Viewport width/height, initial window mode (windowed/fullscreen) |
| Display → Window → Stretch | Stretch mode and aspect (critical for scaling) |
| Rendering → Renderer | Forward+, Mobile, or Compatibility (see Section 3) |
| Rendering → Anti Aliasing | MSAA, FXAA, TAA, SSAA per viewport |
| Rendering → Textures | Default texture filter, VRAM compression |
| Physics → 2D / 3D | Gravity, physics ticks per second, sleep thresholds |
| Input → UI | Built-in UI action bindings (ui\_accept, ui\_cancel…) |
| Debug | Print errors to file, visible collision shapes, profiler settings |
| Audio → General | Default bus layout, output latency |
| Internationalization → Locales | Supported locales, default locale |

### project.godot Under the Hood

The file uses an INI-like format. Knowing this is useful when resolving merge
 conflicts in version control — the diff is human-readable and surgical:

```ini
; project.godot
[application]
config/name="My Platformer"
run/main_scene="res://scenes/main.tscn"
config/icon="res://icon.svg"

[display]
window/size/viewport_width=1280
window/size/viewport_height=720
window/stretch/mode="canvas_items"
window/stretch/aspect="keep"

[physics]
common/physics_ticks_per_second=60
2d/gravity=980.0

[rendering]
renderer/rendering_method="forward_plus"
textures/canvas_textures/default_texture_filter=0   ; 0 = Nearest (pixel art)

[autoload]
EventBus="*res://autoloads/event_bus.gd"
GameManager="*res://autoloads/game_manager.gd"
```

:::callout-tip[Always commit project.godot]
`project.godot` contains your render backend, Input Map bindings,
 Autoload list, main scene path, and viewport settings. Without it, a fresh
 clone has no idea how to run your game. Commit it to version control on day one,
 and commit it every time you change settings.
:::

## 2. The Input Map

Hard-coding key names into scripts — `if Input.is_key_pressed(KEY_SPACE)`
 — creates two problems: adding gamepad support requires touching every script that
 checks keyboard keys, and players can't rebind controls without editing source
 code. The Input Map solves both by introducing named *actions* as a layer
 between hardware inputs and game code.

### Creating an Action in the Editor

1. Open **Project → Project Settings → Input Map** tab.
2. Type a name in the "Add New Action" field — use lowercase with underscores: `jump`, `move_left`, `fire_primary`.
3. Press Enter or click **Add**.
4. Click the **+** button next to the action to open the event picker.
5. Press the desired key / gamepad button / mouse button. The event appears in the picker.
6. Optionally adjust the deadzone (for analog axes) then click **OK**.
7. Repeat steps 4–6 to add alternative bindings (e.g., both Space and gamepad South for `jump`).

:::callout-tip[Don't repurpose ui\_\* actions]
Godot pre-defines `ui_accept`, `ui_cancel`,
 `ui_left`, etc. for focus navigation in Control nodes. Leave them
 alone and define separate game actions. If you rebind `ui_accept`,
 buttons in your menus and dialog boxes may stop working correctly.
:::

### Input API Reference

| Method | Returns | Use when |
| --- | --- | --- |
| `Input.is_action_pressed("name")` | `bool` | Action is held down — movement, charging |
| `Input.is_action_just_pressed("name")` | `bool` | Action started this frame only — jump, fire, interact |
| `Input.is_action_just_released("name")` | `bool` | Action ended this frame — release attack, charge shot |
| `Input.get_action_strength("name")` | `float 0–1` | Analog intensity — gamepad trigger, partial axis |
| `Input.get_axis("neg", "pos")` | `float -1–1` | 1D axis from two opposing actions — left/right, up/down |
| `Input.get_vector("l","r","u","d")` | `Vector2` | 2D movement vector from four actions (automatically normalised) |

```gdscript
extends CharacterBody2D

const SPEED: float = 200.0
const JUMP_VELOCITY: float = -420.0

func _physics_process(delta: float) -> void:
    # Gravity — read from project settings so designers can tune it globally
    if not is_on_floor():
        velocity.y += ProjectSettings.get_setting("physics/2d/gravity") * delta

    # Jump — fires once on the frame the key is pressed, not every frame it's held
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_VELOCITY

    # 2D movement — get_vector normalises diagonal movement automatically
    var dir: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity.x = dir.x * SPEED

    # Dash — charges while held, releases on key-up
    if Input.is_action_just_pressed("dash"):
        _start_dash()
    if Input.is_action_just_released("fire_primary"):
        _release_charged_shot()

    move_and_slide()
```

### Runtime Rebinding

Modify the Input Map from code to implement a settings screen where players can
 remap controls. Changes made at runtime don't persist automatically — save them
 to a `Settings` resource and re-apply on startup.

```gdscript
# InputRebinder.gd
extends Node

func rebind_action(action: StringName, new_key: Key) -> void:
    # Remove all existing key bindings for this action
    InputMap.action_erase_events(action)

    # Create a new key event
    var event := InputEventKey.new()
    event.keycode = new_key
    InputMap.action_add_event(action, event)

    # Also keep existing gamepad bindings — don't wipe them
    # (you'd typically call this per-event-type, not clear-all)

func rebind_action_keep_gamepad(action: StringName, new_key: Key) -> void:
    # Remove only key events, preserve gamepad and mouse bindings
    var events := InputMap.action_get_events(action)
    for e in events:
        if e is InputEventKey:
            InputMap.action_erase_event(action, e)

    var new_event := InputEventKey.new()
    new_event.keycode = new_key
    InputMap.action_add_event(action, new_event)

func restore_defaults() -> void:
    # Reset everything to the project.godot defaults
    InputMap.load_from_project_settings()
```

## 3. Render Backends

When you create a new project, Godot asks you to choose a renderer. This is one
 of the most consequential early decisions: it affects visual capability,
 performance headroom, and which platforms you can export to. You can change it
 later in **Project Settings → Rendering → Renderer**, but switching
 after you've built materials and lighting may require re-tweaking both.

#### Forward+

High-end 3D

- Clustered forward shading
- Full global illumination (SDFGI)
- Screen-space reflections (SSR)
- SSAO + SSIL
- Volumetric fog & lighting
- Decals and projectors
- Requires Vulkan or D3D12
- Desktop only

#### Mobile

Balanced 3D

- Forward rendering
- No SDFGI or SSR
- SSAO supported
- Vulkan / GLES3
- Android, iOS, desktop
- Lower GPU overhead
- Good for mid-range 3D

#### Compatibility

2D & Web

- OpenGL ES 3.0 / WebGL 2
- No global illumination
- Basic shadows & lighting
- Widest device support
- Web export capable
- Lowest GPU overhead
- Best for 2D games

### Which Renderer Should You Choose?

| Project type | Recommended | Reason |
| --- | --- | --- |
| 2D game, any platform | **Compatibility** | Lowest overhead, web-exportable, runs on every device |
| 2D game targeting web | **Compatibility** | Only renderer that supports WebGL export |
| 3D game targeting mobile or web | **Mobile** | Balanced feature set within mobile GPU constraints |
| 3D game, desktop-only, high visuals | **Forward+** | Full GI, volumetrics, maximum visual quality |

:::callout-warning[Renderer locks export targets]
Forward+ and Mobile both require Vulkan. Browsers don't support Vulkan — they
 use WebGL 2 (equivalent to OpenGL ES 3). If you choose Forward+ and later
 want a web build, you'll need to switch to Compatibility and re-test all your
 materials. Decide early if web is even a *possible* target.
:::

### Anti-Aliasing Options

| Method | Quality | Cost | Available in |
| --- | --- | --- | --- |
| None | Aliased edges | Zero | All |
| FXAA | Fast, slightly blurry | Very low | All |
| MSAA 2×/4×/8× | Good geometric edges, no texture blur | Medium–High | Forward+, Mobile |
| TAA | Excellent, handles motion | Medium | Forward+ |
| SSAA | Brute-force, highest quality | Very high | All |

For 2D pixel art games: set anti-aliasing to **None** and use
 Nearest texture filtering instead — smoothing pixels defeats the aesthetic.
 For 3D games on a budget: FXAA + MSAA 2× is a good balance.

## 4. Display & Window Settings

Under **Display → Window** you control the virtual canvas size your
 game designs to and how it fills the player's screen. These two settings are the
 first thing to configure on any new project.

### Viewport Size (Base Resolution)

Set **Viewport Width** and **Viewport Height** to your
 game's native resolution — the size of the canvas you're designing for. The window
 may be larger or smaller at runtime; the stretch settings (below) determine what
 happens.

| Resolution | Good for |
| --- | --- |
| 1280 × 720 | Safe default for most desktop 2D/3D games |
| 1920 × 1080 | Sharper desktop default; heavier to render at full size |
| 320 × 180 | Pixel art — scales 6× to 1920×1080 |
| 384 × 216 | Pixel art — exact 5× of 1920×1080 |
| 480 × 270 | Pixel art — exact 4× of 1920×1080 |
| 640 × 360 | Low-res HD — 3× of 1920×1080 |

### Stretch Mode

Stretch mode controls how the fixed-size viewport is scaled when the OS window
 is resized.

| Mode | Behaviour | Best for |
| --- | --- | --- |
| `disabled` | Viewport never scales; 1:1 pixel mapping always | Fixed-window games |
| `canvas_items` | All 2D nodes scale with the window — positions and sizes change proportionally | **2D games** — most common choice |
| `viewport` | Viewport renders at base size then upscaled as a texture | **Pixel art** — integer scaling with Nearest filter |

### Stretch Aspect

| Aspect | Behaviour |
| --- | --- |
| `keep` | Letterbox or pillarbox — aspect ratio always preserved |
| `keep_width` | Width locked; taller windows show more vertical world |
| `keep_height` | Height locked; wider windows show more horizontal world |
| `expand` | Shows more world in any direction — players may see different amounts |
| `ignore` | Stretches to fill — distorts aspect ratio |

### Pixel Art Project Setup Recipe

:::example[Step-by-step — crisp pixel art at any window size]
Goal: a 320×180 pixel art game that scales up cleanly to fill any monitor
 without blurring.

1. **Viewport Width/Height**: 320 × 180
2. **Stretch Mode**: `viewport`
3. **Stretch Aspect**: `keep` (letterbox) or `expand` (show more world)
4. **Rendering → Textures → Canvas Textures → Default Texture Filter**: `Nearest`
5. Import every sprite PNG with **Filter: Nearest** in the Import tab

::::answer[Why viewport mode?]
In `viewport` mode, Godot renders the 320×180 world to an
 offscreen texture, then scales that texture up to fill the window using
 GPU nearest-neighbour scaling — exactly one pixel in the viewport maps to
 an integer number of screen pixels. `canvas_items` mode would
 scale each node's transform, which can cause sub-pixel positioning and blur.
::::
:::

### Fullscreen and Window Mode

```gdscript
# Change window mode at runtime — for a settings screen
func set_fullscreen(enabled: bool) -> void:
    if enabled:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
    else:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

# Borderless windowed fullscreen (preferred on multi-monitor setups)
func set_borderless_fullscreen() -> void:
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MAXIMIZED)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, true)

# Query current mode
func is_fullscreen() -> bool:
    return DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
```

## 5. Autoloads

Autoloads are scripts (or scenes) that Godot loads automatically before any
 gameplay scene and keeps alive for the entire session. They're the closest
 equivalent to global singletons in Godot. Every script in the project can access
 an Autoload by its registered name without any `get_node()` call.

### Registering an Autoload

1. Create your script, e.g. `res://autoloads/game_manager.gd`.
2. Open **Project → Project Settings → Autoload** tab.
3. Click the folder icon and select your script. Or type the path directly.
4. Set a **Node Name** — this becomes the global identifier:
 `GameManager`, `EventBus`, etc.
5. Click **Add**.

From any script, access it by name:

```gdscript
func _ready() -> void:
    GameManager.start_level(1)
    print(GameManager.current_score)
    EventBus.player_died.connect(_on_player_died)
```

### Typical Autoload Responsibilities

| Name | Type | Responsibility |
| --- | --- | --- |
| `EventBus` | Script | Global signal hub (Chapter 5) |
| `GameManager` | Script | Game state machine: playing / paused / game-over / transitioning |
| `SaveSystem` | Script | Load/save persistent data to `user://` |
| `AudioManager` | **Scene** | Music and SFX playback with cross-fading; needs AudioStreamPlayer child nodes |
| `SceneLoader` | Script | Background scene loading with progress signals |
| `SettingsManager` | Script | Load/apply player preferences (volume, resolution, controls) |
| `LocaleManager` | Script | Language switching, TranslationServer wrappers |

:::callout-warning[One concern per autoload]
Resist the temptation to create a single `Global.gd` that holds
 everything — the player's position, current score, audio volume, save path,
 and twelve booleans. Monolithic globals become impossible to test or reason
 about. One autoload per concern, named after that concern.
:::

### Load Order and Pitfalls

Autoloads are instantiated in list order. If `SaveSystem` calls
 `EventBus.some_signal.connect()` in its `_ready()`,
 `EventBus` must appear *above* `SaveSystem` in
 the list. Reorder by dragging in the Autoload tab.

```gdscript
# GameManager.gd — a simple state machine autoload
extends Node

enum State { MENU, PLAYING, PAUSED, GAME_OVER }
var state: State = State.MENU
var current_score: int = 0
var current_level: int = 0

func start_level(level_num: int) -> void:
    current_level = level_num
    current_score = 0
    state = State.PLAYING
    get_tree().paused = false
    EventBus.scene_transition_requested.emit("res://levels/level_%02d.tscn" % level_num)

func pause() -> void:
    state = State.PAUSED
    get_tree().paused = true
    EventBus.game_paused.emit(true)

func resume() -> void:
    state = State.PLAYING
    get_tree().paused = false
    EventBus.game_paused.emit(false)

func game_over() -> void:
    state = State.GAME_OVER
    EventBus.scene_transition_requested.emit("res://ui/game_over.tscn")
```

## 6. Feature Tags

Feature tags let you write platform-conditional code without preprocessor
 directives. Godot checks tags at runtime via `OS.has_feature()`.
 You can also use them to create platform-specific *override configuration
 files* that supersede `project.godot` on specific platforms.

### Built-in Feature Tags

| Tag | True on |
| --- | --- |
| `windows` / `linux` / `macos` | That specific desktop OS |
| `pc` | Any desktop OS (windows OR linux OR macos) |
| `android` / `ios` | Mobile platforms |
| `mobile` | Android OR iOS |
| `web` | Browser (HTML5 / WebGL export) |
| `debug` | Running in the editor or a debug export |
| `release` | Running as a release export |
| `editor` | Running inside the Godot editor itself |
| `standalone` | Running as an exported binary (not the editor) |
| `64` / `32` | 64-bit or 32-bit build of the engine |

```gdscript
func _ready() -> void:
    # Show touch controls only on mobile
    $TouchControls.visible = OS.has_feature("mobile")

    # Debug overlay — only in editor or debug exports
    $DebugHUD.visible = OS.has_feature("debug")

    # Web-specific warning
    if OS.has_feature("web"):
        $CloudSaveButton.disabled = true
        $CloudSaveButton.tooltip_text = "Cloud saves not available in browser"
        # Call into the browser's JavaScript runtime
        JavaScriptBridge.eval("console.log('Godot running in browser')")

    # Platform-specific save paths
    if OS.has_feature("android"):
        _use_external_storage()

    # Resolution adjustment for mobile
    if OS.has_feature("mobile"):
        RenderingServer.set_default_clear_color(Color.BLACK)
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
```

### Custom Feature Tags

Define your own tags under **Project Settings → Application → Config →
 Features** (you may need to enable Advanced Settings). Common uses:
 `demo` (content-limited demo build), `steam` (Steam SDK
 integration), `console` (platform SDK).

```gdscript
func _ready() -> void:
    if OS.has_feature("demo"):
        $Level4Button.disabled = true
        $Level4Button.tooltip_text = "Available in full version"
        $BuyButton.show()

    if OS.has_feature("steam"):
        SteamAPI.init()
        _connect_steam_achievements()
```

### Override Config Files

Create a file named `override.cfg` (or
 `platform.feature.override.cfg`) in your project root.
 Settings in this file supersede `project.godot` when the named
 feature tag is active. This is ideal for per-platform display or physics
 tuning without branching code.

```ini
; android.override.cfg — applied automatically on Android
[display]
window/stretch/mode="canvas_items"
window/stretch/aspect="expand"

[rendering]
textures/canvas_textures/default_texture_filter=0   ; Nearest

[physics]
common/physics_ticks_per_second=30   ; lower tick rate to save battery
```

## 7. Reading Project Settings in Code

The `ProjectSettings` singleton lets you read any setting at runtime —
 and even define your own custom settings that appear in the editor dialog.

```gdscript
extends Node

func _ready() -> void:
    # Read built-in settings
    var gravity: float = ProjectSettings.get_setting("physics/2d/gravity")
    var w: int = ProjectSettings.get_setting("display/window/size/viewport_width")
    var h: int = ProjectSettings.get_setting("display/window/size/viewport_height")
    print("Canvas: %d × %d, Gravity: %.1f" % [w, h, gravity])

    # Read with a fallback — safe even if the setting doesn't exist
    var debug_mode: bool = ProjectSettings.get_setting("debug/show_fps_counter", false)
```

:::callout-warning[Warning]
The fallback is the second argument to

get\_setting()

, and only to `get_setting()`.

get\_setting\_with\_override()

takes the name and
        nothing else — passing a fallback to it is a parse error, not a runtime surprise. The
        two methods answer different questions:

get\_setting()

reads the value,
        while

get\_setting\_with\_override()

reads it

after

applying
        feature-tag overrides, so a setting stored as

display/window/size/viewport\_width.mobile

wins on a mobile export. Asking
        it for a setting that does not exist prints

WARNING: Property not found

and returns

null

; it is not a
        safe-read helper.
:::

### Defining Custom Settings

Register your own settings so designers can tune them in the editor without
 touching code. Do this from an `@tool` script or an Autoload
 `_ready()`:

```gdscript
# WorldConfig.gd (Autoload)
extends Node

func _ready() -> void:
    # Register custom settings with types and hints if they don't exist yet
    _register("game/world/gravity", 980.0, TYPE_FLOAT)
    _register("game/world/max_enemies", 50, TYPE_INT)
    _register("game/economy/gold_multiplier", 1.0, TYPE_FLOAT)

func _register(path: String, default, type: int) -> void:
    if not ProjectSettings.has_setting(path):
        ProjectSettings.set_setting(path, default)
        ProjectSettings.set_initial_value(path, default)
        var info: Dictionary = {
            "name": path,
            "type": type,
        }
        ProjectSettings.add_property_info(info)

# Read from anywhere in the project:
var gravity: float:
    get: return ProjectSettings.get_setting("game/world/gravity")

var max_enemies: int:
    get: return ProjectSettings.get_setting("game/world/max_enemies")
```

:::callout-intuition[ProjectSettings vs @export — when to use each]
Use `ProjectSettings` for *global constants* that affect the
 whole project from one place: gravity, physics ticks, a difficulty multiplier.
 Use `@export` for *per-instance parameters* that should vary
 between different nodes of the same type: enemy speed, coin value, bullet
 damage. Putting per-instance data in ProjectSettings forces every instance to
 use the same value. Putting global constants in `@export` forces
 designers to set them on every single node.
:::

:::summary
## Chapter Summary

### Settings quick-reference

| Task | Where |
| --- | --- |
| Set the main (startup) scene | Project Settings → Application → run/main\_scene |
| Add an input action | Project Settings → Input Map tab → Add Action |
| Choose render backend | Project Settings → Rendering → Renderer |
| Set base resolution | Project Settings → Display → Window → Viewport Width/Height |
| Set stretch mode | Project Settings → Display → Window → Stretch → Mode |
| Fix pixel art blur globally | Rendering → Textures → Canvas Textures → Default Texture Filter → Nearest |
| Register an autoload | Project Settings → Autoload tab |
| Check platform at runtime | `OS.has_feature("android")` |
| Read any setting in code | `ProjectSettings.get_setting("category/key")` |
| Override settings per-platform | Create `platform.override.cfg` in project root |

### If you remember nothing else

**Set up Input Map and renderer on day one.** Every action in your
 game should be an Input Map action — never a hard-coded key check. Choose
 Compatibility for 2D and web targets; choose Forward+ only if you genuinely need
 GI and volumetrics and can drop mobile/web export. These two decisions affect
 every other technical choice down the line.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
Explain the difference between `Input.is_action_pressed("fire")`
 and `Input.is_action_just_pressed("fire")`. Give one example of
 each — a game mechanic where you'd specifically need that behaviour.

::::solution[Solution]
`is_action_pressed` returns `true` every frame the
 action key is held down. `is_action_just_pressed` returns
 `true` only on the *first frame* the key was pressed —
 once, then false even if still held.

 **Example for is\_action\_pressed**: a rapid-fire machine gun
 that shoots continuously while the fire button is held. You check it every
 physics frame and spawn a bullet each time (combined with a cooldown timer).

 **Example for is\_action\_just\_pressed**: a jump. The character
 should jump exactly once per key press, not every frame the key is held —
 otherwise they'd rocket upward every frame.
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
You're making a top-down dungeon crawler that you want to publish on itch.io
 as a browser playable. Which renderer should you choose? Name one setting
 that *must* be correct for a web export to work.

::::solution[Solution]
**Compatibility** renderer. It's a 2D game (Forward+ overhead
 is wasted) and the browser requires WebGL 2 — which maps to OpenGL ES 3,
 which is what the Compatibility renderer uses. Forward+ and Mobile require
 Vulkan, which is not available in browsers.

 Critical setting: the renderer itself must be set to Compatibility before
 the web export template is installed. You cannot switch renderers in the
 export dialog — it must be the project-level setting. Additionally, if
 you're using any Vulkan-only features (SDFGI, SSR, volumetric fog), remove
 them before switching.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
List every project setting you must configure (name and value) to get a pixel
 art game rendering crisply at a 320×180 base resolution on a 1920×1080 monitor.

::::solution[Solution]
- **Display → Window → Size → Viewport Width**: `320`
- **Display → Window → Size → Viewport Height**: `180`
- **Display → Window → Stretch → Mode**: `viewport`
- **Display → Window → Stretch → Aspect**: `keep` (or `expand`)
- **Rendering → Textures → Canvas Textures → Default Texture Filter**: `Nearest` (value 0)
- Import all sprite PNGs with **Filter: Nearest** in the Import tab

On a 1920×1080 monitor with `keep` aspect, the 320×180 canvas
 scales to exactly 6× (1920×1080). The scale factor is an integer, so
 every source pixel maps cleanly to a 6×6 block of screen pixels — no blur.
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Design the Autoload structure for a game that needs: persistent save data,
 a global signal hub, background music with cross-fading, and a game-state
 machine. Name each autoload, say what type (script or scene), and give the
 order they should appear in the Autoload list and why.

::::solution[Solution]
**1. EventBus.gd** (Script) — must be first because all
 other autoloads connect signals to it in their `_ready()`.
 If EventBus isn't loaded yet when SaveSystem tries to connect, you get a
 null reference error.

 **2. SaveSystem.gd** (Script) — loads the save data. May
 emit events on the bus when loaded (e.g., `EventBus.save_loaded.emit()`),
 so EventBus must precede it. GameManager may read save data in its own
 `_ready()`, so SaveSystem comes before GameManager.

 **3. GameManager.gd** (Script) — the state machine. Reads
 save data from SaveSystem and connects to EventBus. Comes after both.

 **4. AudioManager.tscn** (Scene, not script) — a scene because
 the cross-fade logic needs at least two `AudioStreamPlayer`
 children. Comes last because it's independent — nothing else depends on it
 being loaded first.
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
Write a `_ready()` function that: (a) shows a
 `$TouchJoystick` only on mobile, (b) shows a
 `$DebugPanel` only in debug builds, (c) disables a
 `$CloudSaveBtn` on web with an appropriate tooltip, and (d)
 logs to the browser console a message if running in a browser.

::::solution[Solution]
```gdscript
func _ready() -> void:
    # (a) Touch controls only on mobile
    $TouchJoystick.visible = OS.has_feature("mobile")

    # (b) Debug panel only in debug builds (editor + debug exports)
    $DebugPanel.visible = OS.has_feature("debug")

    # (c) Disable cloud save on web
    if OS.has_feature("web"):
        $CloudSaveBtn.disabled = true
        $CloudSaveBtn.tooltip_text = "Cloud saves are not available in the browser version."

    # (d) Browser console log
    if OS.has_feature("web"):
        JavaScriptBridge.eval("console.log('Game started in browser')")
```
::::
:::

:::problem[Problem M.6 challenge]{difficulty="challenge"}
Implement a complete **rebindable controls settings screen**.
 The screen shows three actions: `jump`, `move_left`,
 `move_right`. Each row has a Button showing the current key
 binding. Clicking a button enters "rebind mode" — it shows "…" and listens
 for the next key press. Pressing Escape cancels. After rebinding, save the
 new bindings to a `Settings` resource via an autoload so they
 survive a restart. Include a "Reset to defaults" button.

::::solution[Solution]
```gdscript
# ControlsScreen.gd
extends Control

const ACTIONS: Array[StringName] = ["jump", "move_left", "move_right"]

@onready var reset_btn: Button = $ResetButton
var _action_buttons: Dictionary = {}   # StringName -> Button
var _rebinding: StringName = ""

func _ready() -> void:
    for action in ACTIONS:
        var row: HBoxContainer = HBoxContainer.new()
        var label: Label = Label.new()
        label.text = action.capitalize().replace("_", " ")
        label.custom_minimum_size.x = 120
        var btn: Button = Button.new()
        _action_buttons[action] = btn
        row.add_child(label)
        row.add_child(btn)
        $ActionList.add_child(row)
        btn.pressed.connect(_start_rebind.bind(action))

    reset_btn.pressed.connect(_reset_all)
    _refresh_all_labels()

func _refresh_all_labels() -> void:
    for action in ACTIONS:
        _action_buttons[action].text = _get_key_label(action)

func _get_key_label(action: StringName) -> String:
    for event in InputMap.action_get_events(action):
        if event is InputEventKey:
            return OS.get_keycode_string(event.keycode)
    return "(none)"

func _start_rebind(action: StringName) -> void:
    if _rebinding != "":
        return   # already rebinding another action
    _rebinding = action
    _action_buttons[action].text = "…"

func _input(event: InputEvent) -> void:
    if _rebinding == "" or not (event is InputEventKey and event.pressed):
        return
    get_viewport().set_input_as_handled()
    var action := _rebinding
    _rebinding = ""

    if event.keycode == KEY_ESCAPE:
        _refresh_all_labels()   # cancelled — restore label
        return

    InputMap.action_erase_events(action)
    InputMap.action_add_event(action, event)
    _refresh_all_labels()
    _persist()

func _reset_all() -> void:
    InputMap.load_from_project_settings()
    _refresh_all_labels()
    _persist()

func _persist() -> void:
    # Save each action's first key event to the Settings resource
    for action in ACTIONS:
        for e in InputMap.action_get_events(action):
            if e is InputEventKey:
                SettingsManager.current.set("key_" + action, e.keycode)
                break
    SettingsManager.save_settings()
```
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
