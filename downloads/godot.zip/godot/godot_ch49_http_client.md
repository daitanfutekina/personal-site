---
title: "HTTPClient, HTTPRequest & Web APIs"
source: "godot_ch49_http_client.html"
---

Part VII · Chapter 49

# HTTPClient, HTTPRequest & Web APIs

Estimated study time: 65 min · Godot 4.6 · GDScript

## Overview

Most games that connect to the internet need only a handful of HTTP calls: submit a score, fetch a leaderboard, check for updates, or call a REST API for game content. Godot provides two tools for this. The **HTTPRequest node** handles the common case — make a request, get a response — with almost no boilerplate. The **HTTPClient** class is the lower-level API you reach for when you need streaming responses, unusual HTTP methods, or fine-grained control over the connection lifecycle.

This chapter covers both, plus the async patterns that keep HTTP calls from blocking gameplay, and a complete leaderboard implementation you can adapt for your own game.

### Prerequisites

- Ch 47 — JSON (for parsing API responses)
- Ch 7 — Signals (HTTPRequest is signal-driven)
- Ch 21 — Autoloads (the API wrapper pattern)

## HTTPRequest Node

`HTTPRequest` is a Node that wraps the full request/response cycle. Add it as a child of whichever scene needs network access, or add it dynamically in code. It sends one request at a time; queue multiple requests by waiting for the `request_completed` signal before starting the next.

### Simple GET Request

```gdscript
extends Node

@onready var http: HTTPRequest = $HTTPRequest

func _ready() -> void:
    http.request_completed.connect(_on_request_completed)
    # Make a GET request (method defaults to GET)
    var err := http.request("https://api.example.com/scores")
    if err != OK:
        push_error("HTTP request failed to start: " + error_string(err))

func _on_request_completed(
        result: int,
        response_code: int,
        headers: PackedStringArray,
        body: PackedByteArray) -> void:

    if result != HTTPRequest.RESULT_SUCCESS:
        push_error("Network error: " + str(result))
        return
    if response_code != 200:
        push_error("Server returned HTTP %d" % response_code)
        return

    var text := body.get_string_from_utf8()
    var data  = JSON.parse_string(text)
    if data == null:
        push_error("Response is not valid JSON")
        return
    _handle_scores(data)
```

### POST Request with JSON Body

```gdscript
func submit_score(player_name: String, score: int) -> void:
    var payload := JSON.stringify({
        "player": player_name,
        "score":  score,
        "timestamp": Time.get_unix_time_from_system()
    })

    var headers := PackedStringArray([
        "Content-Type: application/json",
        "Accept: application/json",
    ])

    var err := http.request(
        "https://api.example.com/scores",
        headers,
        HTTPClient.METHOD_POST,
        payload
    )
```

### HTTPRequest Properties and Methods

| Property / Method | Type | Description |
| --- | --- | --- |
| timeout | float | Seconds before the request times out. 0 = no timeout. Set this to something sane (e.g. 10.0). |
| max\_redirects | int | Maximum HTTP redirects to follow automatically. Default 8. |
| body\_size\_limit | int | Max response body size in bytes. −1 = unlimited. Set a limit when downloading user-provided URLs. |
| download\_file | String | If set, stream the response body to this file path instead of buffering it in memory. Essential for large downloads. |
| download\_chunk\_size | int | Bytes per chunk when streaming to `download_file`. Default 65536. |
| use\_threads | bool | Run the request on a background thread. Prevents the main thread from blocking on slow connections. Default `false`. |
| accept\_gzip | bool | Send `Accept-Encoding: gzip` and decompress automatically. Default `true`. |
| get\_http\_client\_status() | HTTPClient.Status | Current connection status (CONNECTING, BODY, etc.). |
| get\_downloaded\_bytes() | int | Bytes received so far. Use for a download progress bar. |
| get\_body\_size() | int | Total body size from Content-Length header. −1 if unknown. |
| cancel\_request() | void | Abort the in-progress request and close the connection. |

**request\_completed signal parameters:**

| Parameter | Type | Description |
| --- | --- | --- |
| `result` | int (HTTPRequest.Result) | `RESULT_SUCCESS` = 0. Non-zero = network-level failure (timeout, connection refused, TLS error, etc.). |
| `response_code` | int | HTTP status code: 200 OK, 404 Not Found, 500 Server Error, etc. |
| `headers` | PackedStringArray | Response headers as `"Name: Value"` strings. |
| `body` | PackedByteArray | Raw response body. Call `.get_string_from_utf8()` for text APIs. |

:::callout-pitfall[Pitfall — result vs response\_code]
`result != RESULT_SUCCESS` means the *network* failed (couldn't connect, TLS handshake failed, timed out). `response_code != 200` means the server replied but with an error status. Check *both*. A successful TLS handshake to a server that returns 503 gives `result = RESULT_SUCCESS` and `response_code = 503`.
:::

## HTTPClient (Manual)

`HTTPClient` is the lower-level class. You manage the connection, send the request, and poll for the response yourself. Use it when you need to reuse a persistent connection, handle chunked responses, or use a custom HTTP method not supported by `HTTPRequest`.

### Request Flow

```gdscript
## Manual GET with HTTPClient (run in a Thread or coroutine)
func fetch_manual(url: String) -> String:
    var client := HTTPClient.new()

    # 1. Connect (non-blocking — must poll until connected)
    var err := client.connect_to_host("api.example.com", 443, TLSOptions.client())
    if err != OK:
        push_error("connect_to_host failed: " + error_string(err))
        return ""

    # Poll until connection is established
    while client.get_status() in [HTTPClient.STATUS_CONNECTING,
                                   HTTPClient.STATUS_RESOLVING]:
        client.poll()
        OS.delay_msec(1)   # yield to avoid busy-wait in a thread

    if client.get_status() != HTTPClient.STATUS_CONNECTED:
        push_error("Failed to connect: status " + str(client.get_status()))
        return ""

    # 2. Send request
    var headers := PackedStringArray(["Accept: application/json"])
    err = client.request(HTTPClient.METHOD_GET, "/scores?limit=10", headers)
    if err != OK:
        return ""

    # 3. Poll until response headers arrive
    while client.get_status() == HTTPClient.STATUS_REQUESTING:
        client.poll()
        OS.delay_msec(1)

    # 4. Read body
    var body_bytes := PackedByteArray()
    while client.get_status() == HTTPClient.STATUS_BODY:
        client.poll()
        var chunk := client.read_response_body_chunk()
        if chunk.size() > 0:
            body_bytes.append_array(chunk)

    return body_bytes.get_string_from_utf8()
```

:::callout-tip[Tip — prefer HTTPRequest for most cases]
`HTTPClient` is verbose. The main reasons to use it directly are: you need to reuse one TCP connection for many rapid requests (avoid TLS handshake overhead), you need to stream a large response chunk by chunk, or you're building a custom protocol on top of HTTP. For everything else, `HTTPRequest` is cleaner.
:::

## Headers & Authentication

HTTP headers carry metadata: content type, authentication tokens, CORS controls, caching hints. In Godot, pass them as a `PackedStringArray` of `"Name: Value"` strings.

### Common Request Headers

| Header | When to use | Example value |
| --- | --- | --- |
| `Content-Type` | Any POST/PUT with a body | `application/json` |
| `Accept` | Tell server what format you can parse | `application/json` |
| `Authorization` | API key or bearer token auth | `Bearer eyJhbGci...` |
| `X-API-Key` | Custom API key header (many game backends) | `my-secret-key-123` |
| `User-Agent` | Identify your game to the server | `MyGame/1.0 Godot/4.6` |

```gdscript
const API_KEY := "sk-live-abc123def456"   # store in a config, not hardcoded

func _make_authenticated_request(endpoint: String) -> void:
    var headers := PackedStringArray([
        "Content-Type: application/json",
        "Accept: application/json",
        "Authorization: Bearer " + API_KEY,
        "User-Agent: MyGame/1.0 Godot/4.6",
    ])
    http.request("https://api.mygame.com" + endpoint, headers)
```

:::callout-warning[Warning — never hardcode API keys in source]
API keys committed to source control are frequently leaked. Store them in a `user://` config file downloaded at first launch, in an environment variable (desktop only), or better yet — run a small backend server so the key never reaches the client at all. A client-side API key can always be extracted from the binary.
:::

## TLS / HTTPS

All real-world API calls should use HTTPS. Godot 4 validates TLS certificates by default using the system's certificate store. For `HTTPRequest`, just use an `https://` URL and TLS is handled automatically.

For `HTTPClient`, pass a `TLSOptions` to `connect_to_host()`:

```gdscript
# Secure (validate server certificate — always use this in production)
client.connect_to_host("api.example.com", 443, TLSOptions.client())

# With a custom CA certificate (for self-signed certs on your own server)
var ca := load("res://certs/my_server_ca.crt") as X509Certificate
client.connect_to_host("my-server.local", 8443, TLSOptions.client(ca))

# INSECURE — only for local development, never ship this
client.connect_to_host("localhost", 8080, TLSOptions.client_unsafe())
```

:::callout-pitfall[Pitfall — TLS on Android/iOS]
Mobile platforms may not have all root CA certificates that desktop platforms do. If your HTTPS connections work on desktop but fail on Android, check that your server uses a certificate from a well-known CA (Let's Encrypt works well), and that the certificate chain includes the intermediate certificate.
:::

## Async Patterns

HTTP requests complete asynchronously. There are three patterns for handling this cleanly in Godot — choose based on how complex your call chain is.

### Pattern 1: Signal-Callback (simple)

For one-off requests, connect the signal, make the request, handle it in the callback. This works well when you need only one active request at a time.

```gdscript
func fetch_motd() -> void:
    $HTTP.request_completed.connect(_on_motd, CONNECT_ONE_SHOT)
    $HTTP.request("https://api.mygame.com/motd")

func _on_motd(result, code, _headers, body) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code != 200:
        return
    var data = JSON.parse_string(body.get_string_from_utf8())
    $MOTDLabel.text = data.get("message", "")
```

### Pattern 2: await (clean sequential code)

`await` on the `request_completed` signal turns async code into sequential code. This is the cleanest pattern for most cases.

```gdscript
## Returns parsed JSON dict or null on failure.
func get_json(url: String, headers: PackedStringArray = []) -> Variant:
    $HTTP.request(url, headers)
    var response = await $HTTP.request_completed
    # response is an Array: [result, response_code, headers, body]
    var result        : int              = response[0]
    var response_code : int              = response[1]
    var body          : PackedByteArray  = response[3]

    if result != HTTPRequest.RESULT_SUCCESS:
        push_error("Network error: %d" % result)
        return null
    if response_code < 200 or response_code >= 300:
        push_error("HTTP %d for %s" % [response_code, url])
        return null

    return JSON.parse_string(body.get_string_from_utf8())

## Usage:
func _ready() -> void:
    var scores = await get_json("https://api.mygame.com/scores")
    if scores != null:
        _populate_leaderboard(scores)
```

:::callout-tip[await pauses the coroutine, not the engine]
When you `await` a signal, execution pauses *in that function* but the rest of the game continues running normally — physics, rendering, input, and other coroutines all keep going. This is why `await` is the right pattern: it looks like blocking code but never actually blocks.
:::

### Pattern 3: API Wrapper Autoload with Retry

For a real game, centralise all HTTP logic in an autoload that handles retries, queuing, and token management. This prevents multiple systems from trampling each other's requests.

```gdscript
# api_client.gd — register as autoload "API"
extends Node

const BASE_URL    := "https://api.mygame.com"
const MAX_RETRIES := 3
const TIMEOUT_SEC := 10.0

var _http: HTTPRequest
var _busy := false

func _ready() -> void:
    _http = HTTPRequest.new()
    _http.timeout = TIMEOUT_SEC
    _http.use_threads = true
    add_child(_http)

## Perform a GET and return parsed JSON. Retries up to MAX_RETRIES on failure.
func get_json(endpoint: String, headers: PackedStringArray = []) -> Variant:
    return await _request(HTTPClient.METHOD_GET, endpoint, headers, "")

## Perform a POST with a JSON body and return parsed JSON.
func post_json(endpoint: String, payload: Dictionary, headers: PackedStringArray = []) -> Variant:
    var all_headers := PackedStringArray(["Content-Type: application/json"])
    all_headers.append_array(headers)
    return await _request(HTTPClient.METHOD_POST, endpoint, all_headers,
                          JSON.stringify(payload))

func _request(method: int, endpoint: String,
              headers: PackedStringArray, body: String) -> Variant:
    # Simple queue: wait until not busy
    while _busy:
        await get_tree().process_frame

    _busy = true
    var url := BASE_URL + endpoint

    for attempt in range(MAX_RETRIES):
        _http.request(url, headers, method, body)
        var resp = await _http.request_completed
        var result: int = resp[0]
        var code:   int = resp[1]
        var rbody: PackedByteArray = resp[3]

        if result == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300:
            _busy = false
            return JSON.parse_string(rbody.get_string_from_utf8())

        var wait_sec := 0.5 * pow(2.0, attempt)   # exponential back-off
        push_warning("Request failed (attempt %d/%d), retrying in %.1fs" \
                     % [attempt + 1, MAX_RETRIES, wait_sec])
        await get_tree().create_timer(wait_sec).timeout

    _busy = false
    push_error("All %d attempts failed for %s" % [MAX_RETRIES, url])
    return null
```

Usage from any scene:

```gdscript
var scores = await API.get_json("/scores?limit=10")
var result = await API.post_json("/scores", {"player": "Alice", "score": 9500})
```

## Complete Leaderboard Example

This ties everything together: a `LeaderboardScreen` that fetches scores on open, displays them in a table, and lets the player submit their own score.

```gdscript
# leaderboard_screen.gd
extends Control

@onready var score_list: VBoxContainer = $ScoreList
@onready var status_lbl: Label         = $StatusLabel
@onready var submit_btn: Button        = $SubmitButton
@onready var name_edit:  LineEdit      = $NameEdit

func _ready() -> void:
    submit_btn.pressed.connect(_on_submit)
    _load_scores()

func _load_scores() -> void:
    status_lbl.text = "Loading scores..."
    var data = await API.get_json("/scores?limit=20")

    if data == null or not data is Array:
        status_lbl.text = "Could not load scores."
        return

    status_lbl.text = ""
    # Clear old rows
    for child in score_list.get_children():
        child.queue_free()

    # Add a row per entry
    for i in data.size():
        var entry: Dictionary = data[i]
        var lbl := Label.new()
        lbl.text = "%2d.  %-20s  %8d" % [
            i + 1,
            entry.get("player", "?"),
            entry.get("score",  0),
        ]
        score_list.add_child(lbl)

func _on_submit() -> void:
    var name  := name_edit.text.strip_edges()
    var score := PlayerData.high_score   # from your game's data singleton

    if name.is_empty():
        status_lbl.text = "Enter your name first."
        return

    submit_btn.disabled = true
    status_lbl.text     = "Submitting..."

    var result = await API.post_json("/scores", {"player": name, "score": score})

    submit_btn.disabled = false
    if result != null:
        status_lbl.text = "Score submitted!"
        await get_tree().create_timer(1.0).timeout
        _load_scores()   # refresh the board
    else:
        status_lbl.text = "Submission failed. Try again."
```

:::callout-connect[Backend tip]
For a real game, the server should validate the score before storing it — a client sending `"score": 999999999` is trivially easy. Run anti-cheat validation server-side: check that the score is achievable given the claimed playtime, cross-reference a signed session token, or use a replay-validation approach.
:::

## Practice Problems

:::problem
#### A — Fetch and Print JSON easy

Write a Node with a child `HTTPRequest`. In `_ready()`, make a GET request to `https://jsonplaceholder.typicode.com/todos/1`. In the `request_completed` callback, check for success, parse the JSON body, and print the `"title"` field.

::::solution[Solution]
```gdscript
extends Node

@onready var http: HTTPRequest = $HTTPRequest

func _ready() -> void:
    http.request_completed.connect(_on_done)
    http.request("https://jsonplaceholder.typicode.com/todos/1")

func _on_done(result, code, _headers, body) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code != 200:
        push_error("Request failed: result=%d code=%d" % [result, code])
        return
    var data = JSON.parse_string(body.get_string_from_utf8())
    if data is Dictionary:
        print("Title: ", data.get("title", "?"))
```
::::
:::

:::problem
#### B — Reusable get\_json() Coroutine standard

Write a Node with a child `HTTPRequest` and a function `get_json(url: String) -> Variant` that uses `await` on `request_completed`. It should return parsed JSON on success, `null` on any failure. Then use it to fetch two different URLs sequentially in `_ready()`, printing the first response before starting the second request.

::::solution[Solution]
```gdscript
extends Node

@onready var http: HTTPRequest = $HTTPRequest

func get_json(url: String) -> Variant:
    http.request(url)
    var resp = await http.request_completed
    if resp[0] != HTTPRequest.RESULT_SUCCESS or resp[1] != 200:
        return null
    return JSON.parse_string(resp[3].get_string_from_utf8())

func _ready() -> void:
    var todo = await get_json("https://jsonplaceholder.typicode.com/todos/1")
    print("Todo: ", todo)

    var post = await get_json("https://jsonplaceholder.typicode.com/posts/1")
    print("Post title: ", post.get("title", "?") if post else "failed")
```
::::
:::

:::problem
#### C — POST with Auth Header standard

Write a function `submit_event(event_name: String, data: Dictionary) -> bool` that POSTs to `https://analytics.mygame.com/events` with a JSON body `{"event": event_name, "data": data}` and an `Authorization: Bearer MY_TOKEN` header. Return `true` if the server responded with a 2xx code, `false` otherwise. Use `await` and a child `HTTPRequest` node.

::::solution[Solution]
```gdscript
const TOKEN := "MY_TOKEN"

func submit_event(event_name: String, data: Dictionary) -> bool:
    var body := JSON.stringify({"event": event_name, "data": data})
    var headers := PackedStringArray([
        "Content-Type: application/json",
        "Authorization: Bearer " + TOKEN,
    ])
    $HTTP.request("https://analytics.mygame.com/events",
                  headers, HTTPClient.METHOD_POST, body)

    var resp = await $HTTP.request_completed
    var result: int = resp[0]
    var code:   int = resp[1]
    return result == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300
```
::::
:::

:::problem
#### D — Download Progress Bar standard

Write a function that downloads a large file from a URL to `user://download.dat`, showing download progress in a `ProgressBar` node updated every frame. Use `HTTPRequest.download_file`, `get_downloaded_bytes()`, and `get_body_size()`. The `ProgressBar` value should be 0–100.

::::solution[Solution]
```gdscript
extends Node

@onready var http: HTTPRequest = $HTTPRequest
@onready var bar:  ProgressBar = $ProgressBar

var _downloading := false

func download(url: String) -> void:
    http.download_file = "user://download.dat"
    http.request_completed.connect(_on_done, CONNECT_ONE_SHOT)
    http.request(url)
    _downloading = true

func _process(_delta: float) -> void:
    if not _downloading:
        return
    var total := http.get_body_size()
    var done  := http.get_downloaded_bytes()
    if total > 0:
        bar.value = float(done) / float(total) * 100.0

func _on_done(result, code, _h, _b) -> void:
    _downloading = false
    bar.value = 100.0 if result == HTTPRequest.RESULT_SUCCESS and code == 200 else 0.0
```
::::
:::

:::problem
#### E — Retry with Back-off challenge

Write a standalone function `fetch_with_retry(url: String, max_attempts: int) -> Variant` that calls the `get_json()` coroutine from problem B, retrying up to `max_attempts` times on failure. Between each retry, wait 2× as long as the previous wait (starting at 0.5 seconds: 0.5, 1.0, 2.0, …). Return the parsed data on success, `null` if all attempts fail. Log each failure with `push_warning()`.

::::solution[Solution]
```gdscript
func fetch_with_retry(url: String, max_attempts: int) -> Variant:
    var wait := 0.5
    for attempt in range(max_attempts):
        var data = await get_json(url)
        if data != null:
            return data
        push_warning("Attempt %d/%d failed for %s" % [attempt + 1, max_attempts, url])
        if attempt < max_attempts - 1:
            await get_tree().create_timer(wait).timeout
            wait *= 2.0
    push_error("All %d attempts failed for %s" % [max_attempts, url])
    return null
```
::::
:::
