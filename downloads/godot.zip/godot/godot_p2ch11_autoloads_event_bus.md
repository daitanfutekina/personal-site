---
title: "Autoloads, Singletons & the Event Bus Pattern"
source: "godot_p2ch11_autoloads_event_bus.html"
---

Part II · GDScript Deep Dive

# Autoloads, Singletons & the Event Bus Pattern

Part II Chapter 11 · Prerequisites: Ch 5 (Signals), Ch 9 (class\_name) · est. 65 min

## Overview

Every game needs systems that exist independently of any particular scene — a score tracker, a settings manager, a scene transition system. In Godot, these are implemented as **Autoloads**: nodes or objects that the engine instantiates before any scene loads and keeps alive for the entire lifetime of the game.

The **Event Bus** is an architectural pattern that uses a single Autoload to centralize all signal declarations — decoupling emitters from listeners so that unrelated systems can communicate without directly referencing each other.

## 1 · Autoloads

:::callout-intuition[Intuition]
An Autoload is like a persistent node that lives above the scene tree. When you change scenes, your Player and enemies are destroyed and re-created, but Autoloads survive unchanged. They are the natural home for anything that needs to outlive scene changes: scores, settings, audio, global state.
:::

### Registering an Autoload

Go to **Project → Project Settings → Autoload**. Click the folder icon, pick a `.gd` file, give it a short name (this becomes its global identifier), and click Add. The order in the list determines initialization order — autoloads registered earlier are ready before later ones.

Alternatively, register in `project.godot` directly (useful for version control):

```gdscript
[autoload]
GameEvents="*res://autoloads/game_events.gd"
GameState="*res://autoloads/game_state.gd"
```

The `*` prefix means "treat as a node" (the script's base class determines the node type). Without `*`, it's treated as a plain object (not added to the scene tree).

### Accessing Autoloads in Any Script

Once registered, the autoload is available as a global name — exactly as if it were a variable declared at the top of every script. No import, no `get_node()` path, nothing:

```gdscript
# In any script, anywhere in the project:
GameState.add_score(100)
GameEvents.player_died.emit()
SceneManager.change_to("res://scenes/game_over.tscn")
```

### Autoload Lifecycle

- Autoloads are instantiated in registration order, *before* the first scene loads.
- Their `_ready()` runs after all autoloads are instantiated.
- They persist across `get_tree().change_scene_to_file()` — they are NOT destroyed on scene change.
- They are destroyed when the application quits, in reverse registration order.
- Autoloads that extend `Node` appear in the remote scene tree debugger as children of the root node.

:::callout-warning[Autoloads that extend Node vs. plain scripts]
If your autoload script extends `Node` (or any node subclass), it gets `_process`, `_input`, signals, and scene tree integration. If it extends `RefCounted` (or nothing — which defaults to RefCounted), it gets none of those. Choose based on what your autoload needs. Most game-logic autoloads extend `Node`.
:::

## 2 · Common Autoload Patterns

### GameState — Global Game Data

A place to store data that must survive scene changes: score, lives, player level, currency, run stats in roguelikes.

```gdscript
# autoloads/game_state.gd
extends Node

signal score_changed(new_score: int)
signal lives_changed(new_lives: int)

var score: int = 0 :
    set(v):
        score = v
        score_changed.emit(score)

var lives: int = 3 :
    set(v):
        lives = clamp(v, 0, max_lives)
        lives_changed.emit(lives)

const max_lives: int = 5
var player_level: int = 1
var gold: int = 0

func add_score(amount: int) -> void:
    score += amount

func reset() -> void:
    score = 0
    lives = 3
    player_level = 1
    gold = 0
```

### SceneManager — Scene Transitions

```gdscript
# autoloads/scene_manager.gd
extends CanvasLayer

@onready var _anim: AnimationPlayer = $AnimationPlayer

var _target_scene: String = ""

func change_to(path: String) -> void:
    _target_scene = path
    _anim.play("fade_out")

func _on_animation_finished(anim_name: String) -> void:
    if anim_name == "fade_out":
        get_tree().change_scene_to_file(_target_scene)
        _anim.play("fade_in")

func reload() -> void:
    get_tree().reload_current_scene()
```

### SettingsManager — Persistent Config

```gdscript
# autoloads/settings_manager.gd
extends Node

const SAVE_PATH := "user://settings.cfg"

var master_volume: float = 1.0 :
    set(v):
        master_volume = v
        AudioServer.set_bus_volume_db(0, linear_to_db(v))
        _save()

var fullscreen: bool = false :
    set(v):
        fullscreen = v
        _apply_fullscreen()
        _save()

func _ready() -> void:
    _load()

func _load() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    master_volume = cfg.get_value("audio", "master_volume", 1.0)
    fullscreen    = cfg.get_value("display", "fullscreen", false)

func _save() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("audio", "master_volume", master_volume)
    cfg.set_value("display", "fullscreen", fullscreen)
    cfg.save(SAVE_PATH)

func _apply_fullscreen() -> void:
    if fullscreen:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
    else:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
```

## 3 · The Event Bus Pattern

:::callout-intuition[Intuition]
Normally, to connect a signal between two nodes, the emitter and the listener must know about each other — either the listener gets a reference to the emitter, or the emitter gets a reference to the listener. For deeply nested scenes that don't share a common parent, this creates spaghetti references.

The Event Bus solves this with an intermediary: all signals are declared on one global Autoload (`GameEvents`). The emitter calls `GameEvents.player_died.emit()` without knowing who listens. The listener calls `GameEvents.player_died.connect(my_method)` without knowing who emits. They are completely decoupled.
:::

### The GameEvents Autoload

This file contains *only signal declarations* — no logic. It is a pure signal bus.

```gdscript
# autoloads/game_events.gd
extends Node

# ── Player ─────────────────────────────────────────────────────────
signal player_died
signal player_respawned(spawn_position: Vector2)
signal player_leveled_up(new_level: int)
signal player_took_damage(amount: int, source: Node)

# ── Enemies ────────────────────────────────────────────────────────
signal enemy_died(enemy: Node, position: Vector2)
signal enemy_spawned(enemy: Node)
signal boss_phase_changed(phase: int)

# ── World / Level ──────────────────────────────────────────────────
signal room_transition_requested(target_room: String, spawn_id: int)
signal room_cleared
signal checkpoint_reached(checkpoint_id: int)

# ── Economy ───────────────────────────────────────────────────────
signal gold_collected(amount: int)
signal item_purchased(item: ItemData)
signal item_dropped(item: ItemData, position: Vector2)

# ── UI ─────────────────────────────────────────────────────────────
signal hud_update_requested
signal dialogue_started(dialogue_key: String)
signal dialogue_ended
```

### Emitting Events

```gdscript
# player.gd — emits events, doesn't know who listens
func take_damage(amount: int, source: Node) -> void:
    health -= amount
    GameEvents.player_took_damage.emit(amount, source)
    if health <= 0:
        GameEvents.player_died.emit()
        die()

func collect_gold(amount: int) -> void:
    GameState.gold += amount
    GameEvents.gold_collected.emit(amount)
```

### Connecting Listeners

```gdscript
# hud.gd — listens for events, doesn't know who emits
extends CanvasLayer

func _ready() -> void:
    GameEvents.player_took_damage.connect(_on_damage)
    GameEvents.player_died.connect(_on_player_died)
    GameEvents.gold_collected.connect(_on_gold_collected)

func _on_damage(amount: int, source: Node) -> void:
    $HealthBar.flash_damage()
    $DamageNumber.show_number(amount)

func _on_player_died() -> void:
    $DeathScreen.show()

func _on_gold_collected(amount: int) -> void:
    $GoldLabel.text = "Gold: %d" % GameState.gold
    $GoldLabel.play_collect_animation()
```

```gdscript
# camera.gd — completely unaware of HUD, player, or enemies
func _ready() -> void:
    # Camera shakes on damage or enemy death
    GameEvents.player_took_damage.connect(func(_amt, _src): add_trauma(0.4))
    GameEvents.enemy_died.connect(func(_enemy, _pos): add_trauma(0.2))

func add_trauma(amount: float) -> void:
    _trauma = minf(_trauma + amount, 1.0)
```

:::callout-key[Why this is powerful]
You can add a new listener for any event without modifying the emitter. You can remove a system (like the damage numbers HUD) without touching the player script. And unit-testing is trivial: emit events manually and assert listeners respond correctly.
:::

:::callout-tip[Disconnect on exit]
If a node connects to an Autoload signal and is later freed, the connection still exists in memory pointing to the freed object — a potential crash. Use `CONNECT_ONE_SHOT` for one-time events, or explicitly disconnect in `_exit_tree()`:

```gdscript
func _exit_tree() -> void:
    GameEvents.player_died.disconnect(_on_player_died)
```

Alternatively, use `Object.CONNECT_ONE_SHOT` or pass a lambda with a validity check.
:::

## 4 · Autoload Pitfalls

:::callout-pitfall[Global state is global state]
Autoloads are singletons — they exist once and are shared everywhere. This makes them convenient but dangerous if overused. Putting too much logic in Autoloads leads to tight coupling through the backdoor (everything depends on `GameState`). Reserve Autoloads for genuinely cross-scene, cross-system concerns.
:::

:::callout-pitfall[Circular dependency at startup]
Autoload A's `_ready()` accessing Autoload B works fine IF B was registered earlier (higher in the list). If you access an autoload before it's ready, you'll get a null reference. Sort your autoloads so dependencies come first: `GameEvents` → `GameState` → `SceneManager`.
:::

:::callout-pitfall[Don't store per-scene node references in Autoloads]
Storing a reference like `GameState.player = $Player` will be pointing to a freed node after a scene change. Use Autoloads for data and events, not for holding scene-specific node references. If you need to find the player, use a group: `get_tree().get_first_node_in_group("player")`.
:::

:::callout-tip[Testing in isolation]
Because Autoloads are global, unit-testing code that depends on them can be tricky. One pattern: make Autoloads properties you can swap out in tests. Another: use the Event Bus pattern so your tested code only *listens* for events, and tests can emit those events directly without a real game loop.
:::

:::summary
## Chapter Summary

| Concept | Key point |
| --- | --- |
| Autoload registration | Project Settings → Autoload; becomes a global name |
| Autoload lifecycle | Created before scene, survives scene changes, destroyed on quit |
| Accessing an Autoload | Just use its name: `GameState.score` — no path or import |
| Node vs RefCounted Autoload | Node: has \_process, signals, tree integration. RefCounted: plain object. |
| Event Bus pattern | One Autoload holds all signal declarations; emitters and listeners are decoupled |
| Emitting an event | `GameEvents.player_died.emit()` |
| Listening to an event | `GameEvents.player_died.connect(my_handler)` |
| Disconnect on exit | Always disconnect in `_exit_tree()` or use `CONNECT_ONE_SHOT` |
| What NOT to store | Don't store per-scene node references in Autoloads — they go stale after scene changes |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
Describe in plain language how to register a script as an Autoload named `AudioManager`. Then write the line of code that any other script uses to call `AudioManager.play_sfx("jump")`.

::::solution[Solution]
Go to Project → Project Settings → Autoload tab. Click the folder icon, select `audio_manager.gd`, type `AudioManager` as the name, click Add. Then in any script:

```gdscript
AudioManager.play_sfx("jump")
```
::::
:::

:::problem[2 easy]{difficulty="easy"}
Why should you NOT store a reference to a scene's Player node inside `GameState` like `GameState.player_ref = get_node("Player")`?

::::solution[Solution]
When the scene changes, all nodes in the old scene are freed. `GameState.player_ref` now points to a freed object. Any code that subsequently accesses it will crash with an "Invalid access to object that has been freed" error. Instead, use groups: `get_tree().get_first_node_in_group("player")` to find the player fresh in the new scene.
::::
:::

:::problem[3 standard]{difficulty="standard"}
Add a `combo_count: int` property to `GameState` with a setter that resets to 0 if the new value is negative, and emits a signal `combo_changed(count: int)` on every set.

::::solution[Solution]
```gdscript
signal combo_changed(count: int)

var combo_count: int = 0 :
    set(v):
        combo_count = max(0, v)
        combo_changed.emit(combo_count)
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
Add two signals to a `GameEvents` Event Bus: `pickup_collected(item: ItemData, amount: int)` and `wave_started(wave_number: int)`. Then write the code that a Bullet node would use to connect to `pickup_collected` and print the item name.

::::solution[Solution]
```gdscript
# game_events.gd
signal pickup_collected(item: ItemData, amount: int)
signal wave_started(wave_number: int)

# In Bullet._ready():
func _ready() -> void:
    GameEvents.pickup_collected.connect(func(item: ItemData, _amt: int):
        print("Collected: ", item.item_name))
```
::::
:::

:::problem[5 challenge]{difficulty="challenge"}
Design a minimal `AudioManager` Autoload (extends Node) that has a dictionary mapping sound names (String) to AudioStream resources, a `play_sfx(name: String) -> void` method that plays the matching stream from a pool of 8 `AudioStreamPlayer` children (cycling through them), and returns early silently if the name is not in the dictionary.

::::solution[Solution]
```gdscript
extends Node

@export var sound_map: Dictionary = {}   # String -> AudioStream, set in inspector

var _players: Array[AudioStreamPlayer] = []
var _pool_index: int = 0

func _ready() -> void:
    for i in 8:
        var p := AudioStreamPlayer.new()
        add_child(p)
        _players.append(p)

func play_sfx(name: String) -> void:
    if not sound_map.has(name):
        return
    var player := _players[_pool_index]
    player.stream = sound_map[name]
    player.play()
    _pool_index = (_pool_index + 1) % _players.size()
```
::::
:::
