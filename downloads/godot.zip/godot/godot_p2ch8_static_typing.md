---
title: "Static Typing, Lambdas & Coroutines"
source: "godot_p2ch8_static_typing.html"
---

Part II · GDScript Deep Dive

# Static Typing, Lambdas & Coroutines

Part II Chapter 8 · Prerequisites: Ch 4 (GDScript basics), Ch 5 (Signals) · est. 75 min

## Overview

GDScript 2.0 (Godot 4) shipped three features that dramatically change how professional code is written in the engine: a real static type system, first-class functions via the `Callable` type, and coroutines via the `await` keyword. These are not optional niceties — they are the foundation of every production Godot project.

In this chapter you will learn how to annotate variables and functions with types so the editor catches bugs before you run the game, how to store functions in variables and pass them around like data, and how to write asynchronous logic that reads like plain synchronous code using `await`.

:::callout-tip[What you'll build]
By the end you'll be able to write fully typed scripts, create inline filter/sort lambdas over arrays, and write cutscene-style sequences that wait for animations, timers, and player input — all without a single state machine or coroutine class.
:::

## 1 · Static Typing

:::callout-intuition[Intuition]
Think of a variable's type as a contract: "this slot will always hold an `int`." Without that contract, GDScript has to figure out what's in every variable at runtime (dynamic typing). With the contract, the editor and the VM both know exactly what to expect — the editor can autocomplete methods, and the VM can skip type-check overhead. The cost is zero: you just add a colon and a type name.
:::

### Type Annotations

A **type annotation** appears after the variable name (or parameter name) with a colon, followed by the type. The general syntax is:

```gdscript
var my_name: Type = initial_value

# Variables
var health: int = 100
var speed: float = 5.5
var player_name: String = "Hero"
var alive: bool = true
var target: Node2D = null   # typed to Node2D, starts null

# Constants benefit from types too (the type is inferred but explicit is clearer)
const MAX_ENEMIES: int = 50

# Export properties — type annotation also controls the Inspector widget
@export var damage: int = 10
@export var label_text: String = "Score"
@export var target_node: CharacterBody2D   # shows a drag-slot in Inspector
```

Typed variables that are **not** given an initial value are automatically initialized to the type's zero-value: `int` → `0`, `float` → `0.0`, `bool` → `false`, `String` → `""`, Object references → `null`.

#### Built-in types reference

| Type | Stores | Zero value | Notes |
| --- | --- | --- | --- |
| `bool` | true / false | `false` | — |
| `int` | 64-bit integer | `0` | No overflow warnings by default |
| `float` | 64-bit double | `0.0` | Assigning an `int` literal silently converts |
| `String` | UTF-32 text | `""` | Immutable; every operation makes a new string |
| `Vector2` | x, y floats | `Vector2.ZERO` | Also `Vector2i` for integer coords |
| `Vector3` | x, y, z floats | `Vector3.ZERO` | Also `Vector3i` |
| `Color` | r, g, b, a floats | `Color.BLACK` | Values 0–1 (not 0–255) |
| `NodePath` | Node path string | `^""` | Use with `get_node()` |
| `Callable` | Function reference | `Callable()` | See Section 2 |
| `Array` | Dynamic array | `[]` | Untyped by default; see typed arrays below |
| `Dictionary` | Hash map | `{}` | Keys and values any type by default |

#### Function parameter and return types

Parameters and return values use the same colon syntax. The return type goes after `->`:

```gdscript
# Parameters typed, return type declared
func calculate_damage(base: int, multiplier: float) -> int:
    return int(base * multiplier)

# void means no return value (implicitly returns null)
func reset_health() -> void:
    health = max_health

# Typed function that returns a node reference (or null)
func find_nearest_enemy() -> CharacterBody2D:
    # ...
    return null   # null is valid for object return types
```

:::callout-tip[Why type function parameters?]
When you type a parameter, the editor will warn you if you call the function with the wrong type at the call site — before you ever run the game. This catches bugs like passing a `float` where health expects an `int`.
:::

### Type Inference with `:=`

When the type is obvious from the right-hand side, you can use `:=` (walrus operator) and GDScript will infer the type automatically. The variable is still statically typed — the compiler just figures out the type for you.

```gdscript
# These two lines are identical in behaviour:
var score: int = 0
var score := 0           # int inferred from literal 0

# Inference from expressions
var dir := velocity.normalized()   # inferred as Vector2 (or Vector3)
var enemies := get_tree().get_nodes_in_group("enemies")  # Array

# Inference from constants
const PI_APPROX := 3.14159   # float

# Common gotcha: integer vs float
var ratio := 1 / 3    # int! Both operands are int → result is int → 0
var ratio := 1.0 / 3  # float: 0.333...
```

:::callout-pitfall[Common pitfall: int division]
`1 / 3` in GDScript is integer division and yields `0`, not `0.333`. Make at least one operand a float: `1.0 / 3`.
:::

### Typed Arrays and Dictionaries

The biggest type-safety gap in older GDScript was that `Array` could hold anything. Godot 4 adds *typed arrays* and *typed dictionaries* — both faster and safer.

```gdscript
# Typed array: only ints allowed
var scores: Array[int] = [10, 20, 30]

# Typed array of node references
var enemies: Array[CharacterBody2D] = []

# Adding a wrong type causes a runtime error (and editor warning)
scores.append("oops")  # ERROR: expected int

# Typed dictionary (Godot 4.4+)
var item_lookup: Dictionary[String, ItemData] = {}
item_lookup["sword"] = ItemData.new()

# Iterating a typed array — loop variable is automatically typed
for enemy: CharacterBody2D in enemies:
    enemy.take_damage(10)  # full autocomplete on enemy!

# Array methods that work with typed arrays
var living := enemies.filter(func(e): return e.health > 0)
var names  := enemies.map(func(e): return e.name)
var total  := scores.reduce(func(acc, x): return acc + x, 0)
```

### Type Casting: `as` and `is`

Sometimes you receive a reference typed as a parent class (e.g., `Node`) but you know at runtime it's actually a `CharacterBody2D`. The `as` keyword attempts a cast. If it fails, you get `null` (not a crash).

```gdscript
func _on_body_entered(body: Node) -> void:
    # body is typed as Node — might be anything
    var enemy := body as EnemyBody   # null if body is not an EnemyBody
    if enemy != null:
        enemy.take_damage(10)

# is  — check type without casting (returns bool)
if body is CharacterBody2D:
    print("it's a character")

# is also works with custom class_name
if body is Enemy:
    (body as Enemy).alert()

# "Safe cast" idiom: always check null after as
var rb := get_node("Tank") as RigidBody3D
assert(rb != null, "Tank node must be RigidBody3D")
```

:::callout-warning[as vs hard cast]
In some languages a failing cast throws an exception. In GDScript, `as` returns `null`. Always check the result before using it or you'll get a "null reference" error one line later — which is a much worse error message than the cast itself.
:::

## 2 · Lambdas & Callable

:::callout-intuition[Intuition]
In GDScript 2.0, functions are first-class citizens. That means you can store a function in a variable, pass it as an argument to another function, and call it later. The container that holds a function reference is called a **Callable**. An inline anonymous function (one without a name) is called a **lambda**.

Think of a Callable as a sticky note with a function's address on it. You can hand the sticky note to someone else and they'll call the function when they need to.
:::

### The Callable Type

`Callable` is a built-in Godot type (not just a GDScript concept). Every method reference is automatically a Callable. You can create one explicitly with `Callable(object, "method_name")` or by referencing a method directly.

```gdscript
# Method reference — the function is NOT called here, just referenced
var fn: Callable = self.heal_player

# Call it later:
fn.call(50)   # same as heal_player(50)

# Callable from another object
var enemy_cb := Callable(enemy_node, "take_damage")
enemy_cb.call(25)

# Callable.bind() — bake arguments in so you can call it with fewer args later
var heal_25: Callable = heal_player.bind(25)
heal_25.call()   # same as heal_player(25)

# Callable.bindv() — bind an array of arguments
var args := [10, true]
some_func.bindv(args).call()

# Check if a Callable is valid (object hasn't been freed)
if fn.is_valid():
    fn.call()
```

### Lambda Syntax

A lambda is an anonymous function written inline. The syntax is `func(params): body`. For single-expression bodies, the return value is the expression result. For multi-statement bodies, use normal `return`.

```gdscript
# Single-expression lambda (implicit return)
var double: Callable = func(x: int) -> int: return x * 2
print(double.call(5))   # 10

# Multi-line lambda
var greet := func(name: String) -> String:
    var msg := "Hello, " + name + "!"
    return msg

print(greet.call("Godot"))   # Hello, Godot!

# Lambdas capture the surrounding scope (closure)
var bonus := 100
var add_bonus := func(damage: int) -> int: return damage + bonus
print(add_bonus.call(50))    # 150 — bonus is captured

# Modifying a captured variable
# Note: captured variables are COPIES unless using a RefCounted wrapper
```

### Higher-Order Functions on Arrays

The real payoff of lambdas is using them with array methods that accept callables. These methods mirror what you'd find in functional languages — they let you express data transformations concisely without manual loops.

```gdscript
var enemies: Array[EnemyData] = get_active_enemies()

# filter() — keep elements where the lambda returns true
var alive := enemies.filter(func(e: EnemyData) -> bool:
    return e.health > 0)

# map() — transform every element into a new value
var names: Array[String] = enemies.map(func(e: EnemyData) -> String:
    return e.display_name)

# reduce() — fold the array into a single value
var total_health: int = enemies.reduce(func(acc: int, e: EnemyData) -> int:
    return acc + e.health, 0)

# sort_custom() — sort by a property
enemies.sort_custom(func(a: EnemyData, b: EnemyData) -> bool:
    return a.health < b.health)   # ascending by health

# any() — true if at least one element passes
if enemies.any(func(e): return e.is_enraged):
    show_danger_hud()

# all() — true if every element passes
if enemies.all(func(e): return e.health <= 0):
    trigger_level_complete()
```

:::callout-tip[Using lambdas with connect()]
You can connect signals to lambdas directly without defining a separate handler function. This is great for one-off reactions:

```gdscript
$Button.pressed.connect(func():
    $Label.text = "Clicked!"
    $AnimationPlayer.play("bounce"))
```
:::

:::callout-pitfall[Pitfalls with Callable and lambdas]
- **Calling without .call()**: Writing `fn(args)` is not valid. You must write `fn.call(args)`.
- **Closure copies**: Captured variables are copied at the time the lambda is created, not by reference (unless the value is a reference type like Array or Node).
- **Freed objects**: If the object a Callable references is freed, calling it will crash. Always check `.is_valid()` when the object might have been freed.
:::

## 3 · Coroutines & `await`

:::callout-intuition[Intuition]
Imagine you're directing a cutscene: "play the door opening animation, *then* display the dialogue, *then* wait two seconds, *then* fade out." In classical code you'd need a state machine or a chain of signal connections — ugly and scattered across many functions. With `await`, you write it as a straight sequence of lines, and GDScript suspends the function between steps without blocking the game loop.

Any GDScript function that contains an `await` is automatically a **coroutine** — a function that can pause and resume. The game engine keeps running during the pause; only this particular function is suspended.
:::

### How `await` Works

`await` pauses execution of the current function and gives control back to the engine. The function resumes only when the awaited thing completes. The awaited expression can be:

- A **Signal** — resumes when the signal is emitted
- A **Coroutine call** — resumes when the coroutine finishes
- Nothing else — awaiting arbitrary values or timers uses a signal under the hood

### Awaiting a Signal

```gdscript
func play_cutscene() -> void:
    # Play an animation and wait for it to finish
    $AnimationPlayer.play("door_open")
    await $AnimationPlayer.animation_finished
    # Code here runs only after the animation ends

    # Show dialogue and wait for player to dismiss it
    $DialogueBox.show_line("Welcome, traveller.")
    await $DialogueBox.dismissed

    # Wait for a specific signal from anywhere
    await get_tree().create_tween().finished

    print("Cutscene complete")
```

:::callout-tip[await returns signal arguments]
If the signal carries arguments, `await` returns them as an array (or the value directly for single-argument signals):

```gdscript
var damage: int = await player.damage_received
print("Player took %d damage" % damage)

# Multiple args come back as an array
var result = await some_signal_with_two_args
var a = result[0]
var b = result[1]
```
:::

### Awaiting a Timer

The most common use of `await` is waiting a fixed amount of time. You create a one-shot timer with `create_timer()` and await its `timeout` signal.

```gdscript
func spawn_wave_with_delay() -> void:
    spawn_enemy_wave(1)
    await get_tree().create_timer(2.0).timeout   # pause 2 seconds
    spawn_enemy_wave(2)
    await get_tree().create_timer(1.5).timeout
    spawn_enemy_wave(3)
    print("All waves spawned")

func flash_red() -> void:
    modulate = Color.RED
    await get_tree().create_timer(0.1).timeout
    modulate = Color.WHITE

# Useful helper — just await an existing Timer node
func _on_respawn_pressed() -> void:
    $RespawnTimer.start()
    await $RespawnTimer.timeout
    player.respawn()
```

### Chaining and Nesting Coroutines

Coroutines compose naturally. You can `await` another coroutine call — the outer function waits until the inner coroutine finishes. This lets you build reusable async building blocks.

```gdscript
# A reusable "fade out" coroutine
func fade_out(duration: float = 0.5) -> void:
    var tween := create_tween()
    tween.tween_property(self, "modulate:a", 0.0, duration)
    await tween.finished

func fade_in(duration: float = 0.5) -> void:
    modulate.a = 0.0
    var tween := create_tween()
    tween.tween_property(self, "modulate:a", 1.0, duration)
    await tween.finished

# Compose them in a scene transition
func transition_to_scene(path: String) -> void:
    await fade_out(0.3)
    get_tree().change_scene_to_file(path)
    await get_tree().process_frame   # wait one frame for new scene to load
    await fade_in(0.5)
```

### Coroutine Pitfalls

:::callout-pitfall[Critical: freed objects and orphaned coroutines]
If the node that owns a coroutine is freed while the coroutine is suspended, the coroutine is discarded and never resumes — there is no crash, but nothing after the `await` runs either, so any cleanup you left there is skipped. What does need guarding is the other case: the coroutine's own node survives, and some *other* object it captured has been freed by the time it wakes. That one resumes with a dangling reference, and `is_instance_valid()` is the check for it.

```gdscript
# Safe pattern: check validity after every await
func long_sequence() -> void:
    await get_tree().create_timer(3.0).timeout
    if not is_instance_valid(self):
        return   # node was freed during the wait
    do_something()
```
:::

:::callout-pitfall[await does NOT block the engine]
While a coroutine is paused, the rest of the game keeps running. This is the whole point — but it means a second call to the same coroutine function can start before the first one finishes. Guard against double-execution with a flag if needed:

```gdscript
var _is_playing: bool = false

func play_cutscene() -> void:
    if _is_playing:
        return
    _is_playing = true
    await do_the_cutscene_stuff()
    _is_playing = false
```
:::

:::callout-warning[Godot 3 → 4 migration: yield to await]
Godot 3 used `yield()` for coroutines. In Godot 4 `yield` is gone. Replace `yield($Timer, "timeout")` with `await $Timer.timeout`. The underlying concept is the same but the syntax and some behaviors differ.
:::

:::summary
## Chapter Summary

| Feature | Syntax | Benefit |
| --- | --- | --- |
| Variable type annotation | `var x: int = 0` | Editor warnings, autocomplete, faster VM |
| Type inference | `var x := 0` | Same as annotation but type deduced |
| Return type | `func f() -> int:` | Documents intent, checked by editor |
| Typed array | `Array[int]` | Runtime type-checks on every append |
| Safe cast | `node as EnemyBody` | Returns null instead of crashing |
| Type check | `node is EnemyBody` | Returns bool |
| Lambda | `func(x): return x*2` | Inline anonymous function |
| Method reference | `Callable(obj, "method")` | Store & pass functions as values |
| Bind args | `fn.bind(arg)` | Partial application |
| Await signal | `await signal_name` | Pause coroutine until signal fires |
| Await timer | `await create_timer(t).timeout` | Non-blocking delay |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
Add type annotations to the following untyped function so the editor can check for mistakes:

```gdscript
func deal_damage(target, amount, is_critical):
    if is_critical:
        target.health -= amount * 2
    else:
        target.health -= amount
```

::::solution[Solution]
```gdscript
func deal_damage(target: CharacterBody2D, amount: int, is_critical: bool) -> void:
    if is_critical:
        target.health -= amount * 2
    else:
        target.health -= amount
```

*(Exact node type depends on your project; the key changes are the typed parameters and `-> void` return.)*
::::
:::

:::problem[2 easy]{difficulty="easy"}
What does `var x := 1 / 2` produce — `0` or `0.5`? Why? How do you fix it to get `0.5`?

::::solution[Solution]
`x` is `0` because both `1` and `2` are integer literals, so integer division is performed. Fix: `var x := 1.0 / 2` (or `1 / 2.0` or `float(1) / 2`). All of these make at least one operand a `float`, triggering floating-point division.
::::
:::

:::problem[3 standard]{difficulty="standard"}
Given `var items: Array[String] = ["sword", "bow", "shield", "dagger"]`, use `filter()` and a lambda to produce a new array containing only items whose names are longer than 4 characters.

::::solution[Solution]
```gdscript
var long_names := items.filter(func(name: String) -> bool:
    return name.length() > 4)
# Result: ["sword", "shield", "dagger"]
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
You want to sort a list of `EnemyData` objects by their `threat_level: int` property in descending order (highest threat first). Write the `sort_custom()` call with an inline lambda.

::::solution[Solution]
```gdscript
enemies.sort_custom(func(a: EnemyData, b: EnemyData) -> bool:
    return a.threat_level > b.threat_level)   # descending: a before b when a is greater
```
::::
:::

:::problem[5 standard]{difficulty="standard"}
Write a coroutine called `three_shot_sequence()` that: fires a projectile, waits 0.3 seconds, fires again, waits 0.3 seconds, fires a third time. Assume a function `fire()` exists.

::::solution[Solution]
```gdscript
func three_shot_sequence() -> void:
    fire()
    await get_tree().create_timer(0.3).timeout
    fire()
    await get_tree().create_timer(0.3).timeout
    fire()
```
::::
:::

:::problem[6 standard]{difficulty="standard"}
Explain what happens when you call `play_cutscene()` (which contains `await`) while the scene is changing mid-coroutine, and how you guard against the resulting crash.

::::solution[Solution]
When the scene changes, all nodes in the old scene are freed. If the coroutine resumes after this, it tries to execute code on a freed object — causing a *"Invalid get index 'x' on base 'previously freed instance'"* crash. Guard with:

```gdscript
await get_tree().create_timer(2.0).timeout
if not is_instance_valid(self):
    return
do_next_step()
```
::::
:::

:::problem[7 challenge]{difficulty="challenge"}
Write a generic `delay_call(fn: Callable, seconds: float) -> void` coroutine that waits `seconds` seconds and then calls `fn` with no arguments. Then demonstrate calling it with a lambda that prints "Boom!" after 1.5 seconds.

::::solution[Solution]
```gdscript
func delay_call(fn: Callable, seconds: float) -> void:
    await get_tree().create_timer(seconds).timeout
    if fn.is_valid():
        fn.call()

# Usage:
delay_call(func(): print("Boom!"), 1.5)
```
::::
:::
