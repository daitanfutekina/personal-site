---
title: "Input Map, Actions, Gamepad, Touch & Rebinding UI"
source: "godot_ch46_input_map.html"
---

Part VII · Chapter 46

# Input Map, Actions, Gamepad, Touch & Rebinding UI

Estimated study time: 75 min · Godot 4.6 · GDScript

## Overview

Godot's input system has two layers. The **low layer** is a stream of `InputEvent` objects — raw hardware events describing exactly what the keyboard, mouse, gamepad, or touchscreen just did. The **high layer** is the **InputMap** — a table of named *actions* (like `"jump"` or `"move_left"`) that you bind to any combination of physical inputs. Your gameplay code only ever talks to actions; the player or your settings menu rebinds the physical keys at runtime.

This separation is why supporting a gamepad, keyboard, and touch in the same game is straightforward in Godot: add more bindings to the same action, and the action-checking code needs no changes at all.

### Prerequisites

- Ch 6 — Node lifecycle and `_process()`
- Ch 7 — Signals and the event system
- Ch 21 — Autoloads (for a rebinding manager)

## The InputEvent Hierarchy

Every piece of physical input arrives as an `InputEvent` subclass. Knowing the hierarchy tells you exactly which properties exist on each type.

```gdscript
InputEvent
├── InputEventWithModifiers          # has shift/ctrl/alt/meta booleans
│   ├── InputEventKey                # keyboard press/release
│   └── InputEventMouse              # base for all mouse events
│       ├── InputEventMouseButton    # click / scroll wheel
│       └── InputEventMouseMotion    # cursor movement
├── InputEventJoypadButton           # gamepad button press/release
├── InputEventJoypadMotion           # analog axis (stick, trigger)
├── InputEventScreenTouch            # finger down / up
├── InputEventScreenDrag             # finger moving on screen
├── InputEventMIDI                   # MIDI device note/CC
└── InputEventAction                 # synthetic — fire an action in code
```

### Keyboard Events — `InputEventKey`

| Property | Type | Description |
| --- | --- | --- |
| keycode | Key (enum) | Physical key constant, e.g. `KEY_SPACE`, `KEY_A`. Layout-independent. |
| physical\_keycode | Key (enum) | Based on physical position (QWERTY vs AZERTY). Use for movement keys so layout doesn't matter. |
| unicode | int | Unicode codepoint of the character typed. Use for text input. |
| pressed | bool | `true` = key down, `false` = key up. |
| echo | bool | `true` when the OS repeats the event while the key is held. |
| shift\_pressed | bool | Shift modifier held. (Inherited from InputEventWithModifiers.) |
| ctrl\_pressed | bool | Ctrl modifier held. |
| alt\_pressed | bool | Alt modifier held. |

:::callout-tip[keycode vs physical\_keycode]
Use keycode for shortcuts (Ctrl+S to save — the letter matters). Use physical\_keycode for movement (WASD — the position matters, not the letter, so French AZERTY players get the same keys).
:::

### Mouse Events

**InputEventMouseButton** fires when a button is clicked or the scroll wheel moves:

| Property | Type | Description |
| --- | --- | --- |
| button\_index | MouseButton enum | `MOUSE_BUTTON_LEFT`, `…RIGHT`, `…MIDDLE`, `…WHEEL_UP`, `…WHEEL_DOWN`, etc. |
| pressed | bool | Down or up. |
| double\_click | bool | `true` for the second click of a double-click. |
| position | Vector2 | Viewport-space position of the cursor. |
| global\_position | Vector2 | Screen-space position. |
| factor | float | Scroll wheel delta (usually 1.0 per notch). |

**InputEventMouseMotion** fires every frame the mouse moves:

| Property | Type | Description |
| --- | --- | --- |
| position | Vector2 | Current cursor position in the viewport. |
| relative | Vector2 | Delta since the last motion event. Use for camera look. |
| velocity | Vector2 | Pixels per second estimated from recent deltas. |
| pressure | float | Stylus pressure (0–1). Zero for regular mice. |

### Gamepad Events

**InputEventJoypadButton** — digital buttons (A/B/X/Y, shoulders, triggers as buttons, D-pad):

| Property | Type | Description |
| --- | --- | --- |
| button\_index | JoyButton enum | `JOY_BUTTON_A`, `JOY_BUTTON_B`, `JOY_BUTTON_LEFT_SHOULDER`, `JOY_BUTTON_DPAD_UP`, etc. |
| pressed | bool | Down or up. |
| pressure | float | 0 or 1 for standard buttons; 0–1 for analog triggers treated as buttons. |

**InputEventJoypadMotion** — analog axes (thumbsticks, analog triggers):

| Property | Type | Description |
| --- | --- | --- |
| axis | JoyAxis enum | `JOY_AXIS_LEFT_X`, `JOY_AXIS_LEFT_Y`, `JOY_AXIS_RIGHT_X`, `JOY_AXIS_RIGHT_Y`, `JOY_AXIS_TRIGGER_LEFT`, `JOY_AXIS_TRIGGER_RIGHT` |
| axis\_value | float | −1.0 to +1.0 for sticks; 0.0 to 1.0 for triggers. |

### Touch Events

**InputEventScreenTouch** — a finger making or breaking contact:

| Property | Type | Description |
| --- | --- | --- |
| index | int | Finger ID (0 = first finger, 1 = second, etc.). |
| position | Vector2 | Viewport-space touch position. |
| pressed | bool | `true` = finger down, `false` = lifted. |
| double\_tap | bool | Second tap detected quickly. |

**InputEventScreenDrag** — a finger already on screen moving:

| Property | Type | Description |
| --- | --- | --- |
| index | int | Finger ID. |
| position | Vector2 | Current position. |
| relative | Vector2 | Delta since last drag event. |
| velocity | Vector2 | Estimated velocity in pixels/second. |

## InputMap & Actions

The **InputMap** singleton maps string action names to sets of physical input events. Your gameplay code checks actions by name — the actual keys or buttons are stored only in the map. This is what makes remapping work: you change the map, not the gameplay code.

### Setting Up Actions in the Editor

Go to **Project → Project Settings → Input Map**. The top bar has a text field — type a new action name and press "Add". Then click the "+" button next to your action to add bindings: keyboard keys, mouse buttons, gamepad buttons, or axes.

Godot ships with several built-in actions (`ui_accept`, `ui_cancel`, `ui_left`, `ui_right`, `ui_up`, `ui_down`, `ui_focus_next`, `ui_focus_prev`) that drive the Control node focus system. You can add bindings to these or create your own.

:::callout-key[Recommended action names for a typical game]
- `move_left`, `move_right`, `move_up`, `move_down` — WASD + D-pad + left stick
- `jump` — Space + A button
- `attack` — Left mouse + X button
- `interact` — E + Y button
- `pause` — Escape + Start button
- `camera_look` — bound to mouse motion or right stick axis
:::

### InputMap Runtime API

The `InputMap` singleton lets you read and modify the action table at runtime — essential for a rebinding system.

| Method | Description |
| --- | --- |
| InputMap.has\_action(action) | Returns `true` if the action exists. |
| InputMap.add\_action(action, deadzone) | Create a new action programmatically. `deadzone` defaults to 0.5. |
| InputMap.erase\_action(action) | Remove an action and all its bindings. |
| InputMap.action\_add\_event(action, event) | Add an InputEvent binding to an existing action. |
| InputMap.action\_erase\_event(action, event) | Remove a specific binding from an action. |
| InputMap.action\_erase\_events(action) | Remove *all* bindings from an action (leaving the action itself). |
| InputMap.action\_get\_events(action) | Returns an `Array[InputEvent]` of all bindings. |
| InputMap.action\_has\_event(action, event) | Check if a specific event is bound to the action. |
| InputMap.get\_actions() | Returns an `Array[StringName]` of all registered action names. |
| InputMap.load\_from\_project\_settings() | Reset all actions back to what is defined in project settings — useful for a "reset to defaults" button. |

Creating an action in code:

```gdscript
InputMap.add_action("sprint")

var key_event := InputEventKey.new()
key_event.physical_keycode = KEY_SHIFT
InputMap.action_add_event("sprint", key_event)

var joy_event := InputEventJoypadButton.new()
joy_event.button_index = JOY_BUTTON_LEFT_STICK   # L3
InputMap.action_add_event("sprint", joy_event)
```

## Reading Input in Your Scripts

There are two completely different strategies for reading input: **event callbacks** (the engine calls you when something happens) and **polling** (you ask the current state every frame). Each has its place.

### Event Callbacks

Override `_input(event)` or `_unhandled_input(event)` on any Node. The engine calls these once per event, in the order nodes appear in the scene tree.

| Callback | When to use |
| --- | --- |
| `_input(event)` | This node wants *first dibs* on every event. UI input handling, debug overlays. |
| `_unhandled_input(event)` | Only called if no Control node or earlier `_input` consumed the event. Use for gameplay input so UI doesn't accidentally trigger actions. |
| `_unhandled_key_input(event)` | Same as above but only keyboard events. Slightly cheaper. |
| `_shortcut_input(event)` | Called before Controls process shortcuts — use for global keyboard shortcuts like Ctrl+S. |

Inside a callback, check event type with `is` and mark it consumed with `get_viewport().set_input_as_handled()`:

```gdscript
func _unhandled_input(event: InputEvent) -> void:
    # Check an action (handles any bound device automatically)
    if event.is_action_pressed("jump"):
        _do_jump()
        get_viewport().set_input_as_handled()

    # Check a raw key
    if event is InputEventKey and event.pressed and not event.echo:
        if event.physical_keycode == KEY_F5:
            _toggle_debug_overlay()

    # Check mouse button
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
            _fire_at(event.position)
```

:::callout-tip[is\_action\_pressed vs is\_action\_just\_pressed]
Inside an event callback: `event.is_action_pressed("jump")` fires on every press *and echo*. Use `event.is_action_pressed("jump") and not event.is_echo()` if you only want the initial press. In polling code (`_process`), use `Input.is_action_just_pressed("jump")` instead — it is true for exactly one frame.
:::

### Polling with the Input Singleton

The `Input` singleton represents the current state of all devices. Poll it inside `_process()` or `_physics_process()`.

| Method | Description |
| --- | --- |
| Input.is\_action\_pressed(action) | `true` while the action binding is held down. |
| Input.is\_action\_just\_pressed(action) | `true` for exactly one frame when the action starts being held. |
| Input.is\_action\_just\_released(action) | `true` for exactly one frame when the action is released. |
| Input.get\_action\_strength(action) | 0.0–1.0 analog value. 1.0 for binary bindings, 0–1 for analog (trigger/axis). |
| Input.get\_axis(neg\_action, pos\_action) | Returns −1.0 to +1.0 from two opposing actions. Perfect for movement. |
| Input.get\_vector(neg\_x, pos\_x, neg\_y, pos\_y) | Returns a Vector2 from four actions, normalised to a unit circle. Handles deadzone automatically. |
| Input.is\_key\_pressed(keycode) | Raw key state, bypasses the action map. |
| Input.is\_mouse\_button\_pressed(button) | Raw mouse button state. |
| Input.get\_joy\_axis(device, axis) | Raw analog axis value for a specific gamepad device index. |

The idiomatic Godot movement loop uses `get_vector()`:

```gdscript
func _physics_process(delta: float) -> void:
    # Returns a Vector2 from WASD / D-pad / left stick, normalised
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity.x = dir.x * SPEED
    velocity.y = dir.y * SPEED
    move_and_slide()

    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = -JUMP_FORCE
```

### Action Strength and Deadzones

When a gamepad axis is bound to an action, Godot maps the axis range through the action's **deadzone**. Below the deadzone, `get_action_strength()` returns 0.0. Above the deadzone, it linearly scales to 1.0.

```gdscript
# Set deadzone when adding the action (second argument):
InputMap.add_action("accelerate", 0.2)   # 20% deadzone

# Or query it later:
var strength := Input.get_action_strength("accelerate")
# 0.0 when stick is barely touched; 1.0 at full deflection
```

:::callout-pitfall[Pitfall — using \_input for movement]
Never drive continuous movement (velocity changes) from `_input()` or `_unhandled_input()`. These are called once per event, not once per frame, so at high framerate you get spurious extra moves, and at low framerate you miss frames entirely. **Poll** with `Input.is_action_pressed()` inside `_physics_process()` for all continuous movement.
:::

## Gamepad Deep Dive

Godot detects gamepads automatically via OS APIs. The `Input` singleton exposes connection signals and per-device queries.

### Connection Signals

```gdscript
func _ready() -> void:
    Input.joy_connection_changed.connect(_on_joy_connection_changed)

func _on_joy_connection_changed(device: int, connected: bool) -> void:
    if connected:
        print("Gamepad connected: ", Input.get_joy_name(device))
    else:
        print("Gamepad disconnected: device ", device)
```

### Useful Input Singleton Methods for Gamepads

| Method | Description |
| --- | --- |
| Input.get\_connected\_joypads() | Returns `Array[int]` of connected device indices. |
| Input.get\_joy\_name(device) | Human-readable name, e.g. "Xbox Series Controller". |
| Input.get\_joy\_guid(device) | SDL2-compatible GUID string for mapping. |
| Input.get\_joy\_axis(device, axis) | Raw axis value −1 to +1 (or 0 to +1 for triggers). |
| Input.is\_joy\_button\_pressed(device, button) | Raw button state. |
| Input.start\_joy\_vibration(device, weak, strong, duration) | Rumble: `weak` and `strong` are 0–1 motor strengths, `duration` in seconds (0 = infinite). |
| Input.stop\_joy\_vibration(device) | Stop rumble immediately. |

A short rumble burst on taking damage:

```gdscript
func take_damage(amount: int) -> void:
    health -= amount
    # Rumble all connected gamepads
    for device in Input.get_connected_joypads():
        Input.start_joy_vibration(device, 0.3, 0.8, 0.25)
```

:::callout-tip[Tip — actions are device-agnostic by default]
When you bind `JOY_BUTTON_A` to the `"jump"` action without specifying a device, Godot matches that button on *any* connected gamepad. This is almost always what you want in a single-player game. For local multiplayer, create separate action names per player (`"p1_jump"`, `"p2_jump"`) and set the device property on the InputEvent binding to restrict it to a specific gamepad index.
:::

## Touch & Swipe Detection

On mobile, Godot can either **emulate mouse from touch** (Project Settings → Input Devices → Pointing → Emulate Mouse From Touch) or give you raw touch events. For simple games, mouse emulation is enough. For multi-touch gestures you need raw events.

### Tracking Multiple Fingers

```gdscript
extends Node2D

var touches: Dictionary = {}   # finger index → start position

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touches[event.index] = event.position
        else:
            touches.erase(event.index)

    elif event is InputEventScreenDrag:
        if event.index in touches:
            var delta := event.position - touches[event.index]
            touches[event.index] = event.position
            # delta is the drag vector this frame for this finger
```

### Simple Swipe Detector

```gdscript
extends Node

signal swiped(direction: Vector2)

const MIN_SWIPE_DISTANCE := 80.0
const MAX_SWIPE_TIME      := 0.4

var _start_pos: Vector2
var _start_time: float
var _tracking := false

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and not _tracking:
            _start_pos  = event.position
            _start_time = Time.get_ticks_msec() / 1000.0
            _tracking   = true
        elif not event.pressed and _tracking:
            _tracking = false
            var elapsed := Time.get_ticks_msec() / 1000.0 - _start_time
            var delta   := event.position - _start_pos
            if delta.length() >= MIN_SWIPE_DISTANCE and elapsed <= MAX_SWIPE_TIME:
                swiped.emit(delta.normalized())
```

:::callout-tip[Emulate touch on desktop]
Enable **Project Settings → Input Devices → Pointing → Emulate Touch From Mouse** while developing so you can test touch logic with the mouse during desktop playtesting.
:::

## Rebinding UI at Runtime

A rebinding system lets players assign their own keys. The pattern: show a button labelled with the current binding → when clicked, listen for the next input event → replace the old binding with the new one → save to disk.

### Listening for the Next Event

The simplest approach is a "capture mode" flag. When capture mode is on, the first non-modifier key (or button, or axis) that arrives becomes the new binding.

```gdscript
class_name RebindButton
extends Button

@export var action: StringName = "jump"

var _capturing := false

func _ready() -> void:
    _update_label()
    pressed.connect(_start_capture)

func _start_capture() -> void:
    _capturing = true
    text = "Press a key..."
    set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
    if not _capturing:
        return
    # Ignore pure modifier keypresses
    if event is InputEventKey and event.keycode in [
            KEY_SHIFT, KEY_CTRL, KEY_ALT, KEY_META]:
        return
    # Ignore releases
    if not _is_pressed_event(event):
        return

    _capturing = false
    set_process_unhandled_input(false)
    get_viewport().set_input_as_handled()

    # Replace all bindings for this action
    InputMap.action_erase_events(action)
    InputMap.action_add_event(action, event)
    _update_label()

func _update_label() -> void:
    var events := InputMap.action_get_events(action)
    if events.is_empty():
        text = action + ": (unbound)"
    else:
        text = action + ": " + events[0].as_text()

func _is_pressed_event(event: InputEvent) -> bool:
    if event is InputEventKey:
        return event.pressed and not event.echo
    if event is InputEventMouseButton:
        return event.pressed
    if event is InputEventJoypadButton:
        return event.pressed
    if event is InputEventJoypadMotion:
        return abs(event.axis_value) > 0.5
    return false
```

### Saving and Loading Bindings

Persist remapped bindings to a config file so they survive game restarts (full details in Ch 47). A minimal approach using `ConfigFile`:

```gdscript
const BINDINGS_PATH := "user://bindings.cfg"

func save_bindings() -> void:
    var cfg := ConfigFile.new()
    for action in InputMap.get_actions():
        var events := InputMap.action_get_events(action)
        # Store each event's as_text() — not ideal but simple
        var texts: Array[String] = []
        for e in events:
            texts.append(e.as_text())
        cfg.set_value("bindings", action, texts)
    cfg.save(BINDINGS_PATH)

func reset_to_defaults() -> void:
    InputMap.load_from_project_settings()
    # Delete saved file so defaults are used on next launch
    if FileAccess.file_exists(BINDINGS_PATH):
        DirAccess.remove_absolute(BINDINGS_PATH)
```

:::callout-warning[Warning — as\_text() round-tripping]
Storing event bindings as text strings (via `as_text()`) is readable but fragile — parsing that text back into an `InputEvent` is not straightforward. For a production rebinding system, serialise the event properties directly (keycode as int, button\_index as int, etc.) into a Dictionary, then reconstruct the InputEvent from those integers on load. Ch 47 covers the save/load infrastructure.
:::

## Practice Problems

:::problem
#### A — Four-Directional Movement easy

Write a `CharacterBody2D` script that moves at 200 px/s in four directions using actions `move_left`, `move_right`, `move_up`, `move_down`. The movement vector must be normalised so diagonal movement isn't faster. Use `Input.get_vector()`.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const SPEED := 200.0

func _physics_process(_delta: float) -> void:
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity = dir * SPEED
    move_and_slide()
```

`Input.get_vector()` already normalises the result to a unit circle, so no extra `.normalized()` call is needed.
::::
:::

:::problem
#### B — One-Shot Jump easy

Add a jump to the character above. The jump should only trigger on the first frame the action is pressed (not while held). Apply an upward impulse of 500 px/s to `velocity.y` only when the character is on the floor.

::::solution[Solution]
```gdscript
const JUMP_FORCE := 500.0

func _physics_process(delta: float) -> void:
    # Add gravity
    if not is_on_floor():
        velocity.y += 980.0 * delta

    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = -JUMP_FORCE

    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity.x = dir.x * SPEED
    move_and_slide()
```
::::
:::

:::problem
#### C — Mouse Look Camera standard

Write a Node3D camera script that rotates the camera with mouse movement while the right mouse button is held. Horizontal mouse delta rotates the node around the Y axis; vertical delta rotates a child `Camera3D` (stored in `@onready var cam`) around its X axis, clamped to ±80 degrees. Capture the mouse cursor while looking.

::::solution[Solution]
```gdscript
extends Node3D

const SENSITIVITY := 0.003
@onready var cam: Camera3D = $Camera3D
var _looking := false

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_RIGHT:
            _looking = event.pressed
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if _looking \
                               else Input.MOUSE_MODE_VISIBLE

    if _looking and event is InputEventMouseMotion:
        rotate_y(-event.relative.x * SENSITIVITY)
        cam.rotate_x(-event.relative.y * SENSITIVITY)
        cam.rotation.x = clampf(cam.rotation.x, deg_to_rad(-80), deg_to_rad(80))
```
::::
:::

:::problem
#### D — Gamepad Rumble on Hit easy

Write a function `on_hit(intensity: float)` that makes all connected gamepads rumble. The weak motor should be set to `intensity * 0.4`, the strong motor to `intensity`, for 0.3 seconds. Clamp `intensity` to 0–1 before use.

::::solution[Solution]
```gdscript
func on_hit(intensity: float) -> void:
    intensity = clampf(intensity, 0.0, 1.0)
    for device in Input.get_connected_joypads():
        Input.start_joy_vibration(device, intensity * 0.4, intensity, 0.3)
```
::::
:::

:::problem
#### E — Swipe to Flip Card standard

Write a Node2D script that listens for single-finger swipes. A rightward swipe (x component > 0.6 in the normalised direction) emits a signal `swiped_right`; a leftward swipe emits `swiped_left`. A swipe must travel at least 100 px within 0.5 seconds to count.

::::solution[Solution]
```gdscript
extends Node2D

signal swiped_right
signal swiped_left

const MIN_DIST := 100.0
const MAX_TIME := 0.5

var _start: Vector2
var _t0: float
var _active := false

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and not _active:
            _start  = event.position
            _t0     = Time.get_ticks_msec() / 1000.0
            _active = true
        elif not event.pressed and _active:
            _active = false
            var dt  := Time.get_ticks_msec() / 1000.0 - _t0
            var d   := event.position - _start
            if d.length() >= MIN_DIST and dt <= MAX_TIME:
                var n := d.normalized()
                if n.x > 0.6:
                    swiped_right.emit()
                elif n.x < -0.6:
                    swiped_left.emit()
```
::::
:::

:::problem
#### F — Runtime Rebinding challenge

Write a `Control` node with a `Label` showing the current binding for the `"jump"` action and a `Button` that, when pressed, enters "capture mode." In capture mode the button label reads "Press a key…" and the next `InputEventKey` (that is not a modifier key and is a press, not release) replaces the jump action's first binding. The label then updates to show the new key name. Pressing Escape cancels capture mode without changing the binding.

::::solution[Solution]
```gdscript
extends Control

const ACTION := &"jump"
@onready var lbl: Label  = $Label
@onready var btn: Button = $Button
var _capturing := false

func _ready() -> void:
    btn.pressed.connect(_on_btn_pressed)
    _refresh()

func _on_btn_pressed() -> void:
    _capturing = true
    btn.text = "Press a key..."

func _input(event: InputEvent) -> void:
    if not _capturing:
        return
    if not (event is InputEventKey and event.pressed and not event.echo):
        return

    if event.keycode == KEY_ESCAPE:
        _capturing = false
        _refresh()
        get_viewport().set_input_as_handled()
        return

    if event.keycode in [KEY_SHIFT, KEY_CTRL, KEY_ALT, KEY_META]:
        return   # ignore pure modifiers

    _capturing = false
    InputMap.action_erase_events(ACTION)
    var new_event := InputEventKey.new()
    new_event.physical_keycode = event.physical_keycode
    InputMap.action_add_event(ACTION, new_event)
    _refresh()
    get_viewport().set_input_as_handled()

func _refresh() -> void:
    var events := InputMap.action_get_events(ACTION)
    lbl.text = "Jump: " + (events[0].as_text() if events else "(unbound)")
    btn.text = "Rebind"
```
::::
:::
