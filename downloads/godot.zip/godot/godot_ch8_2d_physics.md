---
title: "2D Physics & Collision"
crumb: "Godot 4.6 Complete Reference · Part II · Chapter 8"
meta:
  - "Est. study time: ~90 min"
  - "Part II — 2D Game Development"
  - "Updated May 2026"
source: "godot_ch8_2d_physics.html"
---

## Overview

Godot's 2D physics engine runs as a separate server — `PhysicsServer2D`
 — that simulates rigid bodies, resolves collisions, and handles queries at a fixed
 tick rate (60 Hz by default). Your scripts interact with it through four specialised
 node types, each suited to a different role: terrain that never moves, player
 characters that you control directly, dynamic objects that obey physics forces, and
 detection zones that sense overlapping bodies without blocking them.

This chapter covers every tool you need to build solid 2D collision: choosing the
 right node type, configuring collision shapes, using layers and masks to control
 what interacts with what, moving characters with `move_and_slide()`,
 detecting collisions with raycasts, and avoiding the common physics pitfalls that
 trip up every Godot beginner.

:::callout-key[Prerequisites]
- Chapters 1–7: nodes, GDScript, signals, project settings.
- Understanding of `_physics_process(delta)` vs `_process(delta)`.
:::

## 1. The Four Physics Nodes

Every physics-participating object in a 2D scene is one of these four node types.
 Choosing the wrong one is the root cause of most beginner physics problems.

| Node | Moves? | How it moves | Collides? | Use for |
| --- | --- | --- | --- | --- |
| `StaticBody2D` | No (or rarely) | Manual transform set | Yes — blocks others | Floors, walls, platforms, obstacles |
| `CharacterBody2D` | Yes | You set `velocity`, call `move_and_slide()` | Yes — blocked by others | Players, NPCs, enemies |
| `RigidBody2D` | Yes | Physics engine applies forces, gravity, friction | Yes — bounces, slides | Barrels, balls, debris, physics objects |
| `Area2D` | Yes | Manual transform or AnimationPlayer | No — passes through | Triggers, hurt zones, pickups, detection |

⬡ — StaticBody2D — inherits PhysicsBody2D → CollisionObject2D → Node2D

Immovable collision geometry. Other physics bodies collide with it and bounce off; it never moves itself. Use it for every piece of level geometry that stays put — walls, floors, ceilings, obstacles, and terrain.

| Property | Default | What it does |
| --- | --- | --- |
| physics\_material\_override | null | Assign a PhysicsMaterial resource to set **friction** (0=ice, 1=rough) and **bounce** (0=no bounce, 1=perfect elastic). Without one, project defaults apply |
| constant\_linear\_velocity | Vector2(0,0) | A fake velocity reported to touching RigidBody2D nodes — makes them "conveyor belt" slide even though the body itself doesn't move |
| constant\_angular\_velocity | 0.0 | Fake angular velocity — spins touching RigidBody2D nodes like a turntable |
| collision\_layer | 1 | Which physics layer this body occupies. Other bodies' masks must include this layer to collide |
| collision\_mask | 1 | Which layers this body detects (rarely matters for StaticBody2D — it doesn't move or fire signals) |

Use when:

the geometry is permanent — floors, walls, platforms, rocks, trees, any solid level geometry that never moves.

Prefer AnimatableBody2D when:

the geometry moves (doors, platforms) — StaticBody2D teleporting breaks collision; AnimatableBody2D reports velocity correctly.

Tip:

use

constant\_linear\_velocity

to simulate conveyor belts without actually moving the body.

### StaticBody2D

CollisionObject2D

Area2D

Detect, no block

PhysicsBody2D

StaticBody2D

CharacterBody2D

RigidBody2D

Area2D

The 2D physics class hierarchy. **Area2D** detects without blocking. **PhysicsBody2D** is the base for the three solid-body types: Static, Character, and Rigid.

The simplest physics node — it participates in collision but never moves under
 physics forces. Other bodies collide against it and are deflected; StaticBody2D
 itself doesn't respond. Use it for all level geometry: floors, walls, ceilings,
 platforms, and any prop that should block movement.

You can move a StaticBody2D by setting its position directly (e.g., from an
 AnimationPlayer or a moving platform script), but moving it by setting
 `global_position` directly every frame is physically incorrect — use
 `AnimatableBody2D` instead for moving platforms (it's a StaticBody2D
 subclass designed for this).

```gdscript
# Moving platform — use AnimatableBody2D, NOT StaticBody2D directly
# AnimatableBody2D correctly pushes CharacterBody2D nodes as it moves
extends AnimatableBody2D

@export var travel_distance: float = 200.0
@export var speed: float = 60.0

var _direction: float = 1.0
var _start_x: float

func _ready() -> void:
    _start_x = position.x

func _physics_process(delta: float) -> void:
    position.x += speed * _direction * delta
    var offset: float = position.x - _start_x
    if abs(offset) >= travel_distance:
        _direction *= -1.0
```

⬡ — AnimatableBody2D — inherits StaticBody2D → PhysicsBody2D → Node2D

A kinematic static body that moves under animation or code while *correctly pushing* CharacterBody2D and RigidBody2D nodes it collides with. This is the right choice for moving platforms, elevators, doors, and any geometry that travels but should physically interact with characters — unlike a plain StaticBody2D, it reports its velocity to the physics engine so riders slide with it.

| Property | Default | What it does |
| --- | --- | --- |
| sync\_to\_physics | true | When true, position changes are committed during the physics step so collisions are exact. False = smoother visuals but potential missed collisions at high speed |
| collision\_layer | 1 | Which physics layer this body occupies |
| collision\_mask | 1 | Which layers this body detects (mostly irrelevant — it doesn't actively scan) |

Use when:

you need a platform or door that

pushes

the player — driven by AnimationPlayer, Tween, or code setting

position

directly.

Prefer StaticBody2D when:

the geometry never moves at all.

Prefer RigidBody2D when:

the object should react to forces and collisions dynamically, not follow a predetermined path.

### AnimatableBody2D — moving platforms done right

:::callout-intuition[Why not just move StaticBody2D directly?]
If you set `global_position` on a plain `StaticBody2D`
 every frame the physics engine doesn't know the body moved — it teleported.
 CharacterBody2D nodes resting on it won't be pushed; they'll fall through or
 clip. `AnimatableBody2D` records its displacement each physics frame
 and uses that velocity to push anything standing on it, exactly like a real
 moving platform.
:::

Key properties:

| Property | Type | Purpose |
| --- | --- | --- |
| `sync_to_physics` | bool | When `true` (default), the body syncs its transform to the physics server each step so pushes are correctly calculated. Set `false` only if you're driving it via code in `_physics_process`. |

```gdscript
# Vertical moving platform — oscillates between two y positions
extends AnimatableBody2D

@export var amplitude: float = 120.0   # pixels up and down
@export var period: float = 3.0        # seconds for one full cycle

var _base_y: float

func _ready() -> void:
    _base_y = position.y

func _physics_process(delta: float) -> void:
    # Use move_and_collide so the engine tracks the displacement
    var target_y := _base_y + sin(Time.get_ticks_msec() * 0.001 * TAU / period) * amplitude
    var displacement := Vector2(0.0, target_y - position.y)
    move_and_collide(displacement)
```

:::callout-tip[Tween-driven platforms]
The pattern above works but is manual. For a cleaner approach, drive an
 `AnimatableBody2D` from an `AnimationPlayer` track or a
 `Tween` — both update the transform smoothly. Pair with
 `sync_to_physics = true` (the default) and the push behaviour
 just works.
:::

⬡ — CharacterBody2D — inherits PhysicsBody2D → CollisionObject2D → Node2D

The standard node for player characters and code-driven NPCs. You set its `velocity` and call `move_and_slide()` each physics frame; Godot resolves collisions, slides along walls, and reports floor/ceiling/wall contact. Nothing moves automatically — you are always in control.

| Property | Default | What it does |
| --- | --- | --- |
| motion\_mode | GROUNDED | GROUNDED: distinguishes floor/wall/ceiling using up\_direction. FLOATING: no floor concept — use for top-down or space games |
| up\_direction | Vector2(0,-1) | Defines which surface angle counts as "floor"; default is straight up (negative Y) |
| floor\_max\_angle | 0.785 rad (45°) | Steeper surfaces than this are treated as walls, not floors |
| floor\_snap\_length | 1.0 | Snaps the body to the floor on slopes — eliminates the hop at slope edges |
| floor\_stop\_on\_slope | true | Prevents gravity from sliding the body down slopes when velocity is zero |
| velocity | Vector2.ZERO | The movement vector you set each frame; move\_and\_slide() modifies it on collision |
| slide\_on\_ceiling | true | Zeroes the Y velocity when hitting a ceiling — prevents clinging |
| max\_slides | 4 | Maximum collision iterations per move\_and\_slide() call; rarely needs changing |

Use when:

building a player character, NPC, or any entity that needs tight, manually-tuned movement with reliable collision response.

Prefer RigidBody2D when:

the object should tumble freely under physics (crates, barrels, ragdolls).

Prefer AnimatableBody2D when:

the object is a moving platform that must push CharacterBody2D nodes rather than pass through them.

### CharacterBody2D

The workhorse node for player characters and NPCs. CharacterBody2D does
 *not* simulate physics automatically — you drive it entirely through code.
 You set `velocity`, call `move_and_slide()` each physics
 frame, and Godot handles collision resolution: sliding along walls, stopping at
 floors, reporting what was hit.

This manual control is a feature, not a limitation. It lets you implement
 perfectly tuned platformer feel, coyote time, jump buffering, and dash mechanics
 that would fight against a physics simulation.

Full coverage in Section 4.

⬡ — RigidBody2D — inherits PhysicsBody2D → CollisionObject2D → Node2D

Hands movement entirely to the physics engine. You apply forces and impulses; Godot integrates them with gravity, damping, and collision response. The body bounces, tumbles, and stacks automatically — ideal for objects that should feel physically real but are not directly controlled by the player.

| Property | Default | What it does |
| --- | --- | --- |
| mass | 1.0 | Heavier bodies need more force to move and push lighter ones further on collision |
| gravity\_scale | 1.0 | Multiplier on the project's gravity — 0 = weightless, negative = floats upward |
| linear\_damp | 0.0 | Air resistance on linear motion; -1 uses the project default. Higher = slower stopping |
| angular\_damp | 0.0 | Resistance to spinning; -1 uses project default |
| freeze | false | Halts all physics simulation on this body (it stays put but still collides) |
| freeze\_mode | STATIC | STATIC: immovable while frozen. KINEMATIC: you can drive it with linear\_velocity while frozen |
| contact\_monitor | false | Must be true to receive body\_entered/body\_exited signals |
| max\_contacts\_reported | 0 | Set > 0 when contact\_monitor is enabled to receive collision signals |
| continuous\_cd | DISABLED | CCD mode prevents fast-moving bodies from tunnelling through thin walls |
| physics\_material\_override | null | Assign a PhysicsMaterial to set friction and bounce (restitution) |

Use when:

an object should behave physically without manual control — barrels, crates, debris, ragdolls, pinball, billiard balls.

Prefer CharacterBody2D when:

you need precise, responsive player/NPC movement; RigidBody2D fighting against your velocity tweaks causes jitter.

Key rule:

never set

position

directly — use

apply\_impulse()

or toggle freeze\_mode to KINEMATIC first.

### RigidBody2D

RigidBody2D hands movement over to the physics engine. You apply forces or
 impulses; Godot integrates them with gravity, linear and angular damping, and
 collision response. You don't call `move_and_slide()` — instead you
 use `apply_force()`, `apply_impulse()`,
 `apply_central_impulse()`, or set `linear_velocity` and
 `angular_velocity` directly.

```gdscript
extends RigidBody2D

@export var explosion_force: float = 800.0

func _ready() -> void:
    # Connect to the body_entered signal (need contact_monitor=true, max_contacts>0)
    contact_monitor = true
    max_contacts_reported = 4
    body_entered.connect(_on_body_entered)

func explode_outward() -> void:
    # Apply an impulse away from center — launches the body
    var random_dir := Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized()
    apply_central_impulse(random_dir * explosion_force)

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player"):
        EventBus.player_health_changed.emit(
            EventBus.player_health - 10, EventBus.player_max_health)

# Override _integrate_forces for custom physics (runs in the physics thread)
func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
    # Cap maximum speed
    if state.linear_velocity.length() > 400.0:
        state.linear_velocity = state.linear_velocity.normalized() * 400.0
```

:::callout-warning[Never set position directly on RigidBody2D]
Directly setting `position` or `global_position` on a
 RigidBody2D bypasses the physics engine and causes tunnelling (fast-moving
 bodies pass through walls) and jitter. To reposition a RigidBody2D safely,
 use `move_body_to` or temporarily switch to
 `freeze_mode = FREEZE_MODE_KINEMATIC`, move it, then unfreeze.
:::

:::callout-tip[RigidBody2D modes]
The **Freeze** property stops the body from moving. With
 `freeze_mode = FREEZE_MODE_STATIC` it behaves like a StaticBody2D.
 With `freeze_mode = FREEZE_MODE_KINEMATIC` you can drive it by
 setting `linear_velocity` directly. Un-freeze by setting
 `freeze = false`.
:::

⬡ — Area2D — inherits CollisionObject2D → Node2D

A region of space that detects overlapping physics bodies and areas, but applies no physical forces. Use it for pickup zones, damage fields, wind currents, camera trigger regions, and anything where you want to *know* something is inside a boundary without pushing it around.

| Property | Default | What it does |
| --- | --- | --- |
| monitoring | true | Enables the area to detect bodies/areas entering or exiting it — emit signals |
| monitorable | true | Makes this area detectable by other Area2D nodes (e.g., a hitbox detecting a hurtbox) |
| collision\_layer | 1 | Which layer this area occupies — other bodies' masks must include this layer to be detected |
| collision\_mask | 1 | Which layers this area watches for overlaps |
| gravity | 980 | If gravity\_space\_override ≠ DISABLED, applies this gravity to RigidBody2D nodes inside |
| gravity\_space\_override | DISABLED | REPLACE/COMBINE to create local gravity wells or zero-gravity zones |
| linear\_damp\_space\_override | DISABLED | Apply custom linear damping inside the area — slow a RigidBody2D moving through water |
| priority | 0 | Higher priority area wins when multiple areas override gravity/damping in the same space |

Use when:

you need to detect presence without physical response — collectibles, trigger zones, hazard areas, screen-warp edges, elemental zones.

Not for:

blocking movement (use StaticBody2D) or applying forces to the character (use script logic responding to signals instead).

### Area2D

Area2D detects when physics bodies (or other areas) overlap it, but doesn't
 block their movement. It emits signals when bodies enter and exit. Use it for:
 damage zones, coin pickups, trigger regions, water surfaces, wind fields,
 camera zones, and any "sense without block" scenario.

```gdscript
extends Area2D

signal collected(value: int)

@export var heal_amount: int = 25

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if not body.is_in_group("player"):
        return
    # Area2D doesn't block the player — they just walk through
    collected.emit(heal_amount)
    queue_free()

# ── Wind field example ─────────────────────────────────────────────
# Area2D continuously pushes RigidBody2D nodes that overlap it
extends Area2D

@export var wind_force: Vector2 = Vector2(200, -50)

func _physics_process(delta: float) -> void:
    for body in get_overlapping_bodies():
        if body is RigidBody2D:
            body.apply_force(wind_force * delta)
```

## 2 · Collision Shapes

Every physics body needs at least one **CollisionShape2D** child
 to participate in the physics simulation. The shape defines the physical
 boundary that Godot tests for overlaps and contacts — it is separate from
 any visible sprite so you can tune gameplay feel without touching art.

### Shape types

Godot ships a small menu of 2D shapes. Picking the right one matters
 for both accuracy and performance: simpler shapes resolve faster.

| Shape resource | Description | Best used for |
| --- | --- | --- |
| `CircleShape2D` | Perfect circle defined by a radius | Balls, coins, bullets — fastest to test |
| `RectangleShape2D` | Axis-aligned box (size = half-extents × 2) | Platforms, walls, most crates |
| `CapsuleShape2D` | Rectangle with rounded ends (radius + height) | Humanoid characters — avoids corner snagging |
| `ConvexPolygonShape2D` | Convex hull around a set of points | Simple irregular objects (up to ~12 verts) |
| `ConcavePolygonShape2D` | Arbitrary non-convex polygon | Static level geometry only — no CharacterBody2D |
| `WorldBoundaryShape2D` | Infinite line (normal + distance) | Kill-zones, absolute floor at y=0 |
| `SegmentShape2D` | A finite line segment (A → B) | Thin one-sided platforms, rails |

Circle

Rectangle

Capsule

ConvexPolygon

The four common collision shapes (dashed = hitbox boundary). For most characters, a **CapsuleShape2D** is ideal — it slides along walls and floors without catching on corners.

:::callout-tip[Use the smallest shape that fits]
A `CircleShape2D` resolves in O(1). A concave polygon may
 require separating-axis tests against every edge. Even if your sprite is
 irregular, a capsule or a couple of rectangles usually gives better
 feel *and* better performance than a pixel-perfect polygon.
:::

### Setting shapes in the editor

Select the CollisionShape2D in the Scene panel, then open the
 **Shape** property in the Inspector. Choose a shape resource
 from the drop-down. Each shape type exposes its own size handles — you can
 drag them directly in the 2D viewport. Hold Shift while dragging
 a handle to resize from the centre.

You can also set shapes in code — useful when spawning enemies procedurally:

```gdscript
func _ready() -> void:
    var col := CollisionShape2D.new()
    var shape := CapsuleShape2D.new()
    shape.radius = 12.0
    shape.height = 28.0   # total height; the flat middle section is height - 2*radius
    col.shape = shape
    add_child(col)
```

### CollisionPolygon2D

When you need a hand-drawn irregular shape, use **CollisionPolygon2D**
 instead of CollisionShape2D. Add it as a child of a physics body, then
 click **Edit Polygon** in the toolbar to draw vertices in the
 viewport. Godot automatically decomposes concave polygons into convex pieces
 for CharacterBody2D and RigidBody2D (StaticBody2D can keep concave polygons
 intact).

:::callout-warning[Concave polygons on dynamic bodies]
A `CollisionPolygon2D` has two build modes, and the Inspector calls them **Solids** and **Segments** (`BUILD_SOLIDS` and `BUILD_SEGMENTS` in code — there is no CONVEX or CONCAVE setting here). Solids, the default, decomposes the outline into convex pieces and is what you want on anything that moves. Segments builds a hollow line loop with no interior, so a fast body can pass straight between two frames without ever registering a hit. Keep Segments for static geometry such as world boundaries, and leave moving bodies on Solids.
:::

### One-way collision

Enable the **One Way Collision** property on a CollisionShape2D
 (or a TileSet tile) to let CharacterBody2D pass through from below and land
 on top — the classic "jump-through platform." Set
 `one_way_collision_margin` (default 1 px) to control how far above
 the surface the body must be before the one-way check activates.

```gdscript
# Checking whether the player is standing on a one-way platform:
# move_and_slide already respects one_way_collision automatically.
# To drop through a platform on down + jump:
func _physics_process(delta: float) -> void:
    if Input.is_action_pressed("ui_down") and Input.is_action_just_pressed("jump"):
        # Disable one-way collision for this frame so the player falls through
        position.y += 1.0          # nudge below the surface
        velocity.y = 0.0
    move_and_slide()
```

:::callout-key[One-way is a shape property, not a body property]
One-way collision lives on the *CollisionShape2D* (or tile layer),
 not the body itself. You can have a body with multiple shapes, some one-way
 and some solid — useful for a character whose feet are one-way (so NPCs can
 stand on the same platforms) but whose torso is solid.
:::

## 3 · Collision Layers & Masks

Godot provides 32 collision layers. Every physics object has two bitmask
 properties:

| Property | Meaning |
| --- | --- |
| `collision_layer` | "I *exist* on these layers" — what layer(s) this object occupies |
| `collision_mask` | "I *see* these layers" — what layers this object scans for collisions |

A collision happens only when Object A's *mask* includes a layer that
 Object B's *layer* is on (or vice-versa for bidirectional detection).
 This lets you build sophisticated filtering with no conditional code:

:::example[Collision layer design — platformer]
Design layers so enemies and the player never block each other but
          both land on platforms. Bullets hurt enemies but not the player.

::::answer[Layer assignment]
```gdscript
# Layer constants (name them in Project → Layer Names → 2D Physics)
# Layer 1 = World   (platforms, walls)
# Layer 2 = Player
# Layer 3 = Enemies
# Layer 4 = Bullets

# Platform StaticBody2D
# layer:  1 (World)    mask: 2 | 3   (player + enemies land on it)

# Player CharacterBody2D
# layer:  2 (Player)   mask: 1       (only collides with world geometry)

# Enemy CharacterBody2D
# layer:  3 (Enemy)    mask: 1       (only collides with world geometry)

# Bullet Area2D
# layer:  4 (Bullet)   mask: 3       (only detects enemies)
# → player and other bullets are invisible to bullets
```
::::
:::

### Setting layers in code

The bitmask properties are plain integers in GDScript. Layer N corresponds
 to bit (N-1), so layer 1 = `1`, layer 2 = `2`,
 layer 3 = `4`, layer 4 = `8`, etc.

```gdscript
# Set the entire mask at once (bitwise OR layers you want):
collision_layer = 1 | 4        # layers 1 and 3
collision_mask  = 1            # only scan layer 1

# Helper methods — toggle individual layers without touching the rest:
set_collision_layer_value(3, true)   # add layer 3
set_collision_layer_value(2, false)  # remove layer 2
set_collision_mask_value(4, true)    # start seeing layer 4

# Read individual bits:
if get_collision_layer_value(3):
    print("I am on layer 3")
```

:::callout-pitfall[Layer names only exist in the editor]
Project → Layer Names → 2D Physics lets you name layers so the editor
 shows "Player" instead of "Layer 2." Those names are *not* accessible
 at runtime — in code you must use the integer bit index (1–32). Define a
 const or enum in an autoload to avoid magic numbers scattered through your
 project.
:::

```gdscript
# autoload: Layers.gd
const WORLD   := 1
const PLAYER  := 2
const ENEMIES := 4
const BULLETS := 8

# Usage in any script:
collision_mask = Layers.WORLD
```

:::callout-tip[Use layers to speed up physics]
Every body with a non-zero mask is tested against every body on those
 layers each physics tick. Assign narrow masks: if bullets only need to hit
 enemies, their mask should only have the enemy layer bit set. This alone can
 cut broadphase work in half on a busy scene.
:::

## 4 · `move_and_slide()`

`move_and_slide()` is CharacterBody2D's workhorse. Call it once
 per `_physics_process` frame after setting `velocity`
 and Godot will:

1. Move the body by `velocity * delta` (delta is baked in — don't multiply yourself).
2. Detect collisions and slide along surfaces rather than stopping dead.
3. Separate the body from any overlap so it never tunnels through geometry.
4. Populate helper state (is on floor, is on wall, etc.) you can query this frame.

:::callout-warning[Don't multiply velocity by delta yourself]
`move_and_slide()` reads `velocity` as pixels per
 second and internally multiplies by the physics delta (1/physics\_ticks\_per\_second).
 If you write `velocity *= delta` before calling it you'll move
 far too slowly — a common beginner mistake.
:::

### up\_direction and floor detection

The `up_direction` property (default `Vector2.UP`)
 tells move\_and\_slide what "up" means for surface classification. A surface
 whose normal is within `floor_max_angle` radians of
 `up_direction` is considered a floor. Steeper surfaces are walls
 or ceilings. For a top-down game set `up_direction = Vector2.ZERO`
 to disable floor/wall/ceiling classification entirely.

```gdscript
extends CharacterBody2D

const SPEED   := 300.0
const GRAVITY := 980.0
const JUMP_V  := -500.0

func _physics_process(delta: float) -> void:
    # Apply gravity every frame unless on the floor
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    # Horizontal input
    var dir := Input.get_axis("ui_left", "ui_right")
    velocity.x = dir * SPEED

    # Jump
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_V

    move_and_slide()
    # After move_and_slide, these helpers are valid for this frame:
    # is_on_floor()   — standing on a surface within floor_max_angle of up
    # is_on_wall()    — touching a vertical surface
    # is_on_ceiling() — pressed against overhead geometry
    # get_floor_normal() — the normal of the floor surface
    # get_wall_normal()  — the normal of the wall
```

### Reading slide collisions

After each `move_and_slide()` call you can inspect every
 collision that happened during that move. This lets you react to specific
 surfaces — bouncing off a wall, playing a landing sound, counting enemies hit.

```gdscript
func _physics_process(delta: float) -> void:
    # ... set velocity ...
    move_and_slide()

    for i in get_slide_collision_count():
        var col: KinematicCollision2D = get_slide_collision(i)
        var hit := col.get_collider()        # the Node we hit
        var normal := col.get_normal()       # surface normal at contact
        var depth  := col.get_depth()        # penetration depth

        if hit.is_in_group("enemy"):
            hit.take_damage(10)

        # Bounce off walls: negate the horizontal component of velocity
        if normal.x != 0.0:
            velocity.x = -velocity.x * 0.6  # 60 % bounce
```

:::callout-key[KinematicCollision2D is per-move, not persistent]
The collision objects returned by `get_slide_collision()` are
 only valid until the next `move_and_slide()` call. Cache any data
 you need (collider reference, normal, position) before the next frame.
:::

### Floor snapping (stairs and slopes)

Without snapping, a CharacterBody2D hops off the ground every time it
 crests a small step or slope edge because its velocity carries it
 upward for a frame. `floor_snap_length` (default `1.0` on CharacterBody2D, `0.1` on CharacterBody3D — a nominal amount of snapping is already on) tells
 move\_and\_slide to cast a short ray downward and pin the body to the
 floor if the floor is found within that distance. Set it to a value
 slightly larger than your largest step height (e.g. 8 px).

```gdscript
func _ready() -> void:
    floor_snap_length = 8.0        # snap to slopes/stairs up to 8 px below feet
    floor_max_angle   = deg_to_rad(50.0)   # surfaces up to 50° count as floor
    floor_stop_on_slope = true     # don't slide down gentle slopes when idle
```

## 5 · `move_and_collide()`

`move_and_collide(motion: Vector2)` is the lower-level alternative
 to `move_and_slide()`. Pass a displacement vector (pixels to move
 this frame) and it returns a `KinematicCollision2D` if anything
 was hit, or `null` if the path was clear.

Unlike `move_and_slide()`, **it does not slide** —
 the body stops exactly at the point of contact. You get full control over
 what happens next: bounce, stop, push, or anything else.

|  | `move_and_slide()` | `move_and_collide()` |
| --- | --- | --- |
| Input | Sets `velocity` property before calling | Passes displacement vector as argument |
| On collision | Slides along surface, continues moving | Stops at contact, returns collision info |
| Collisions returned | Via `get_slide_collision(i)` after the call | Directly as return value (single collision) |
| Best for | Player character, NPCs that walk on geometry | Projectiles, pushing objects, custom physics response |

```gdscript
# Projectile that bounces off surfaces
extends CharacterBody2D

@export var speed: float = 600.0

func _physics_process(delta: float) -> void:
    var motion := velocity * delta
    var col: KinematicCollision2D = move_and_collide(motion)

    if col:
        # Reflect velocity around the surface normal (perfect bounce)
        velocity = velocity.bounce(col.get_normal())
        # Or lose some energy: velocity = velocity.bounce(col.get_normal()) * 0.8

        var hit := col.get_collider()
        if hit.has_method("take_damage"):
            hit.take_damage(15)
```

:::callout-intuition[When to choose which]
Rule of thumb: if the object walks on ground, use
 `move_and_slide()`. If the object flies through air and needs
 to react precisely on contact — a bullet, a grenade, a bouncing ball —
 use `move_and_collide()`. You can also mix them on the same
 body: a character that walks with `move_and_slide()` could
 use `test_move()` (a dry-run version of move\_and\_collide)
 to probe whether a push is possible before committing.
:::

## 6 · Raycasting

A raycast fires an imaginary line from an origin point in a direction and
 reports the first physics body it hits (or nothing). Use it to check
 line-of-sight, detect the ground without moving, aim hitscan weapons, or
 probe whether a character can grab a ledge.

⬡ — RayCast2D — inherits Node2D

Casts an invisible ray from its origin to a target point every physics frame and reports the first body or area it hits. Indispensable for line-of-sight checks, ground-detection without move\_and\_slide, floor-surface normals, and hitscan weapons.

| Property | Default | What it does |
| --- | --- | --- |
| enabled | true | When false, the ray never updates — toggle off rays you don't need every frame |
| target\_position | Vector2(0,50) | End point of the ray, relative to the node's own origin |
| collision\_mask | 1 | Which physics layers to test — match this to the layers your targets are on |
| collide\_with\_bodies | true | Detect PhysicsBody2D nodes (CharacterBody2D, StaticBody2D, etc.) |
| collide\_with\_areas | false | Also detect Area2D nodes — useful for trigger zones |
| exclude\_parent | true | Automatically ignore the parent body so you don't detect yourself |
| hit\_from\_inside | false | When true, also reports hits that start inside a collider |

Use when:

you need a fast, single-contact point query — floor detection, enemy line-of-sight, hitscan shooting.

Prefer ShapeCast2D when:

you need to sweep a volume (e.g. "can my 32×48 character fit here?") or hit multiple targets at once.

Prefer direct space query when:

you need asynchronous or one-shot casts not tied to a persistent node.

### RayCast2D node

Add a **RayCast2D** as a child of any node. Set its
 **Target Position** (the end of the ray in local space) and
 enable **Enabled**. It updates automatically every physics frame.

```gdscript
@onready var ground_ray: RayCast2D = $GroundRay

func _physics_process(delta: float) -> void:
    if ground_ray.is_colliding():
        var point  := ground_ray.get_collision_point()   # world-space hit position
        var normal := ground_ray.get_collision_normal()  # surface normal at hit
        var body   := ground_ray.get_collider()          # the Node that was hit

        # Snap the character precisely to ground level:
        position.y = point.y

    # Force an immediate update (useful outside _physics_process):
    # ground_ray.force_raycast_update()
```

RayCast2D respects `collision_mask` — set it to only the layers
 you care about. It also has an **Exclude Parent** toggle
 (default on) that stops the ray from hitting the body it belongs to.

⬡ — ShapeCast2D — inherits Node2D

Like a RayCast2D, but instead of casting an infinitely thin ray it sweeps a *shape* (capsule, box, circle) through space. Returns all bodies the shape would touch if it moved from its origin to its target — perfect for checking whether a character can fit through a gap, or for detecting multiple objects in a cone.

| Property | Default | What it does |
| --- | --- | --- |
| shape | null | A Shape2D resource (RectangleShape2D, CapsuleShape2D, etc.) — the geometry that gets swept |
| target\_position | Vector2(0,50) | End point of the sweep, relative to the node's origin |
| collision\_mask | 1 | Which physics layers to test against |
| max\_results | 32 | Maximum number of overlapping bodies to report |
| collide\_with\_bodies | true | Detect physics bodies (CharacterBody2D, RigidBody2D, etc.) |
| collide\_with\_areas | false | Also detect Area2D nodes |
| enabled | true | If false, the shape cast never updates — useful to toggle expensive checks |

Use when:

a thin ray isn't enough — e.g. "can my character body fit here?", multi-target detection in a cone, or checking clearance before a teleport.

Prefer RayCast2D when:

you only need a single point-to-point hit check; shape casts are more expensive.

### ShapeCast2D — sweep a shape instead of a line

:::callout-intuition[RayCast2D vs ShapeCast2D]
`RayCast2D` casts an infinitely thin line — it misses physics bodies
 that don't intersect that exact line. `ShapeCast2D` sweeps a
 *shape* (circle, rectangle, capsule, polygon) along a vector. Use it
 when you need to check if your character fits through a gap, whether a bullet
 with real radius would hit something, or if there's ground beneath a ledge
 before allowing a drop.
:::

Key properties:

| Property | Type | Purpose |
| --- | --- | --- |
| `shape` | Shape2D | The shape to sweep (CircleShape2D, RectangleShape2D, CapsuleShape2D, etc.) |
| `target_position` | Vector2 | Sweep direction and distance, relative to the node |
| `collision_mask` | int | Physics layers to test against |
| `max_results` | int | Maximum collision results to store (default 32) |
| `margin` | float | Extra margin around the shape for early-out detection |
| `exclude_parent` | bool | Skip the parent body's own collision shapes |

```gdscript
extends CharacterBody2D

# Check if there's room to stand before completing a teleport
@onready var stand_check: ShapeCast2D = $StandCheck

func can_stand_at(world_pos: Vector2) -> bool:
    # Temporarily move the ShapeCast2D to the target position and force an update
    stand_check.global_position = world_pos
    stand_check.force_shapecast_update()
    return not stand_check.is_colliding()

# ── Ledge-grab check ─────────────────────────────────────────────────
# Fire a ShapeCast downward to find a ledge surface before committing

@onready var ledge_probe: ShapeCast2D = $LedgeProbe   # points downward

func check_for_ground_below() -> bool:
    ledge_probe.force_shapecast_update()
    if ledge_probe.is_colliding():
        # get_collision_point(0) returns the first hit world position
        var hit_point: Vector2 = ledge_probe.get_collision_point(0)
        var hit_normal: Vector2 = ledge_probe.get_collision_normal(0)
        # Only accept near-horizontal surfaces as valid floor
        return hit_normal.dot(Vector2.UP) > 0.7
    return false
```

:::callout-tip[ShapeCast2D in the editor]
Add a `ShapeCast2D` child node, assign a `Shape2D`
 resource, and set `target_position` in the Inspector. The editor
 draws the sweep as a translucent shape so you can see exactly what it covers.
 Call `force_shapecast_update()` before reading results in code
 (outside `_physics_process`) because the engine only refreshes it
 automatically each physics step.
:::

### Direct space query

For one-shot or procedural raycasts — e.g., a gun firing every time the
 player presses shoot — skip the node and query the physics space directly.
 This is also the only way to raycast from code that runs in
 `_process` (not `_physics_process`) because
 `RayCast2D` nodes only update in the physics step.

```gdscript
func fire_hitscan(from: Vector2, direction: Vector2, range: float) -> void:
    var space := get_world_2d().direct_space_state

    var query := PhysicsRayQueryParameters2D.create(
        from,
        from + direction * range
    )
    query.collision_mask = 0b00001100   # layers 3 (enemies) and 4 (destructibles)
    query.exclude = [self.get_rid()]    # don't hit ourselves

    var result: Dictionary = space.intersect_ray(query)

    if result.is_empty():
        return   # hit nothing

    # result keys: position, normal, collider, collider_id, rid, shape
    var hit_pos  : Vector2 = result["position"]
    var hit_body           = result["collider"]

    spawn_impact_vfx(hit_pos)

    if hit_body.has_method("take_damage"):
        hit_body.take_damage(25)
```

:::callout-tip[intersect\_ray vs intersect\_shape vs intersect\_point]
`intersect_ray` returns the *first* hit along a line.
 `intersect_shape` sweeps a shape and returns *all* hits —
 useful for AoE checks without creating Area2D nodes. `intersect_point`
 reports all bodies touching a single world-space point. All three live on
 `direct_space_state` and share the same
 `PhysicsPointQueryParameters2D` /
 `PhysicsShapeQueryParameters2D` pattern.
:::

:::example[Line-of-sight enemy AI]
An enemy should only aggro the player if no wall is in between.

::::answer[Direct-space solution]
```gdscript
func can_see_player(player: Node2D) -> bool:
    var space := get_world_2d().direct_space_state
    var query  := PhysicsRayQueryParameters2D.create(
        global_position,
        player.global_position
    )
    # Only test against world geometry (layer 1); ignore other enemies
    query.collision_mask = 1
    query.exclude = [self.get_rid()]

    var result := space.intersect_ray(query)
    # If the ray hit nothing, or hit something past the player, LOS is clear
    return result.is_empty()
```
::::
:::

## 7 · Physics Signals

Physics nodes emit signals when bodies enter, exit, or stay in contact.
 Reacting to these signals is almost always cleaner than polling
 `get_overlapping_bodies()` every frame.

### Area2D signals

| Signal | Fires when… | Argument |
| --- | --- | --- |
| `body_entered(body)` | A physics body enters the area | `Node2D` |
| `body_exited(body)` | A physics body leaves the area | `Node2D` |
| `area_entered(area)` | Another Area2D overlaps this one | `Area2D` |
| `area_exited(area)` | Overlapping Area2D stops overlapping | `Area2D` |
| `body_shape_entered(…)` | Per-shape variant of body\_entered | body\_rid, body, body\_shape\_index, local\_shape\_index |

```gdscript
extends Area2D   # damage zone

@export var damage_per_second: float = 20.0
var _bodies_inside: Array[Node2D] = []

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        _bodies_inside.append(body)

func _on_body_exited(body: Node2D) -> void:
    _bodies_inside.erase(body)

func _physics_process(delta: float) -> void:
    for body in _bodies_inside:
        if is_instance_valid(body) and body.has_method("take_damage"):
            body.take_damage(damage_per_second * delta)
```

### RigidBody2D contact signals

RigidBody2D emits `body_entered` and `body_exited`
 only when **Contact Monitor** is enabled and
 **Max Contacts Reported** is greater than zero. These
 properties must be set in the editor or in `_ready()` before
 the first physics step.

```gdscript
extends RigidBody2D

func _ready() -> void:
    contact_monitor = true
    max_contacts_reported = 4       # report up to 4 simultaneous contacts
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    # linear_velocity magnitude at moment of impact ≈ impact force proxy
    var speed := linear_velocity.length()
    if speed > 200.0:
        SoundManager.play_sfx("impact_heavy")
    elif speed > 60.0:
        SoundManager.play_sfx("impact_soft")
```

:::callout-warning[Always use CONNECT\_DEFERRED for physics signals]
Physics signals fire during the physics step while the physics engine
 still owns the simulation state. Calling `queue_free()`,
 `add_child()`, or modifying another body's position from
 inside a physics signal callback can corrupt the simulation. Connect
 with `CONNECT_DEFERRED` (or use `call_deferred`)
 to defer the callback to the end of the frame:

```gdscript
body_entered.connect(_on_body_entered, CONNECT_DEFERRED)
```
:::

## 8 · Physics Performance Tips

2D physics in Godot is fast, but poor practices can turn a smooth 60 fps
 game into a stuttering mess at 50 simultaneous objects. These tips apply
 especially to bullet-hell shooters, platformers with many enemies, and
 any scene with dozens of physics objects on screen.

| Tip | Why it helps |
| --- | --- |
| Use the simplest collision shape that fits | Circle and rectangle tests are O(1). Convex polygons are O(n). Avoid concave shapes on moving objects entirely. |
| Set narrow collision masks | Broadphase only checks body pairs whose layers and masks intersect. Halving masks can halve broadphase cost. |
| Disable monitoring on inactive Area2Ds | `monitoring = false` stops the area from generating overlap events. Toggle it when the area enters the viewport. |
| Avoid per-frame `get_overlapping_bodies()` | It allocates an Array every call. Cache body lists in `body_entered/exited` signals instead. |
| Use `physics_ticks_per_second` wisely | Default is 60. Dropping to 30 halves physics CPU cost at the price of less responsive collisions. Raising above 60 helps fast projectiles but costs more CPU. |
| Pool bullets rather than spawn/free | Creating and destroying RigidBody2D nodes every frame triggers physics engine bookkeeping. Re-use a fixed pool of bodies by repositioning them. |
| Freeze off-screen RigidBody2D | Set `freeze = true` on bodies that scroll off screen. The physics engine won't simulate them until you un-freeze. |

```gdscript
# Changing physics tick rate at runtime (e.g., slow-motion effect):
func enable_bullet_time() -> void:
    Engine.time_scale = 0.3          # everything runs at 30 % speed
    # Physics automatically uses the scaled delta — no code changes needed.

func disable_bullet_time() -> void:
    Engine.time_scale = 1.0

# Disable Area2D monitoring when far from player:
func _on_visibility_changed() -> void:
    $HitArea.monitoring = visible    # automatic: only active when on screen
```

:::callout-connect[Next chapter connection]
Chapters 9–10 cover TileMapLayer and procedural level generation. TileMapLayer
 has built-in physics — each tile layer can have collision shapes baked into
 it, and those shapes participate in the exact same layer/mask system you
 learned here. Everything in this chapter applies directly.
:::

:::summary
## Chapter Summary

| Concept | Quick reference |
| --- | --- |
| StaticBody2D | Immovable collider. Pair with AnimatableBody2D for moving platforms. |
| CharacterBody2D | Player / NPC body. Set `velocity`, call `move_and_slide()`. |
| RigidBody2D | Simulated physics. Enable `contact_monitor` for signals. Never set `position` directly. |
| Area2D | Sense without block. Use `CONNECT_DEFERRED` on its signals. |
| CollisionShape2D | Every physics body needs one. Use the simplest shape that fits. |
| collision\_layer / mask | Layer = "I exist here." Mask = "I see these." Collision requires overlapping bits. |
| move\_and\_slide() | Sets `velocity` property, delta baked in. Slides along surfaces. |
| move\_and\_collide() | Pass displacement vector. Returns `KinematicCollision2D`. Stops at contact. |
| RayCast2D | Node that auto-updates each physics frame. Query: `is_colliding()`, `get_collider()`. |
| Direct space query | `get_world_2d().direct_space_state.intersect_ray(query)` for one-shot casts. |
| Physics signals | Area2D: `body_entered/exited`. RigidBody2D: enable `contact_monitor` first. |

**If you remember nothing else:** CharacterBody2D +
 `move_and_slide()` handles 90 % of 2D gameplay. Everything else —
 RigidBody2D, raycasts, Area2D — layers on top when you need it.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Create a scene with a **CharacterBody2D** that falls under
 gravity and lands on a **StaticBody2D** platform. The character
 should stop cleanly on the platform's surface. What nodes and properties are
 required at minimum?

::::solution[Solution]
Minimum setup:

```gdscript
# CharacterBody2D scene:
# └─ CharacterBody2D
#    ├─ CollisionShape2D (e.g. CapsuleShape2D)
#    └─ Sprite2D (optional, for visibility)

# StaticBody2D scene (or inline):
# └─ StaticBody2D
#    └─ CollisionShape2D (RectangleShape2D sized to the platform)

extends CharacterBody2D
const GRAVITY := 980.0

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += GRAVITY * delta
    move_and_slide()
```

Both the CharacterBody2D and the StaticBody2D need CollisionShape2D children
 with non-zero shapes. Without shapes, physics ignores the bodies completely.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
You have four objects: a floor (StaticBody2D), a player (CharacterBody2D),
 an enemy (CharacterBody2D), and a fireball Area2D. The player and enemy should
 both land on the floor but should *not* block each other. The fireball
 should detect enemies but ignore the player and floor. Design the layer/mask
 assignments.

::::solution[Solution]
```gdscript
# Layer 1 = World   (2^0 = 1)
# Layer 2 = Player  (2^1 = 2)
# Layer 3 = Enemies (2^2 = 4)
# Layer 4 = Hazards (2^3 = 8)

# Floor StaticBody2D:
#   collision_layer = 1  (World)
#   collision_mask  = 2 | 4  (Player + Enemies land on it)

# Player CharacterBody2D:
#   collision_layer = 2  (Player)
#   collision_mask  = 1  (only collides with World → ignores enemies)

# Enemy CharacterBody2D:
#   collision_layer = 4  (Enemies)
#   collision_mask  = 1  (only collides with World → ignores player)

# Fireball Area2D:
#   collision_layer = 8  (Hazards)
#   collision_mask  = 4  (only detects Enemies)
```

Player and enemy have no overlap in each other's masks, so they phase
 through each other. The fireball's mask only includes the enemy layer, so
 it fires `body_entered` only for enemy bodies.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Implement a **jump-through platform**: the player can jump
 up through it from below and land on it from above. Pressing S
 while on the platform drops the player through it.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const GRAVITY  := 980.0
const SPEED    := 300.0
const JUMP_V   := -480.0

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    velocity.x = Input.get_axis("ui_left", "ui_right") * SPEED

    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_V

    # Drop through platform: nudge down so one_way check deactivates
    if is_on_floor() and Input.is_action_pressed("ui_down"):
        position.y += 2.0
        velocity.y  = 100.0   # small downward push

    move_and_slide()

# On the platform StaticBody2D:
# CollisionShape2D → Inspector → One Way Collision: ON
# (Players can pass upward; land when coming from above)
```
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Write a **bouncing ball** using RigidBody2D that plays a
 sound when it hits the floor, with the volume proportional to the impact speed.
 The ball should report at least 2 contacts.

::::solution[Solution]
```gdscript
extends RigidBody2D

@onready var sfx: AudioStreamPlayer2D = $SFX
const MIN_SPEED := 50.0
const MAX_SPEED := 600.0

func _ready() -> void:
    contact_monitor      = true
    max_contacts_reported = 2
    body_entered.connect(_on_contact, CONNECT_DEFERRED)

func _on_contact(body: Node) -> void:
    var speed := linear_velocity.length()
    if speed < MIN_SPEED:
        return
    # Map impact speed to volume dB: -30 dB at MIN, 0 dB at MAX
    var t := clampf((speed - MIN_SPEED) / (MAX_SPEED - MIN_SPEED), 0.0, 1.0)
    sfx.volume_db = lerpf(-30.0, 0.0, t)
    sfx.play()
```
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
Using a **direct space query**, write a function
 `get_ground_height(x: float) -> float` that casts a ray straight
 down from `(x, -1000)` and returns the y-coordinate of the
 first ground surface it hits, or `INF` if there is none. Only
 test against layer 1 (World).

::::solution[Solution]
```gdscript
func get_ground_height(x: float) -> float:
    var space := get_world_2d().direct_space_state
    var query  := PhysicsRayQueryParameters2D.create(
        Vector2(x, -1000.0),
        Vector2(x,  5000.0)
    )
    query.collision_mask = 1   # World layer only

    var result := space.intersect_ray(query)
    if result.is_empty():
        return INF
    return (result["position"] as Vector2).y
```
::::
:::

:::problem[Problem 6 challenge]{difficulty="challenge"}
Build a **platformer character controller** with all of the
 following behaviours: standard left/right movement and jump; coyote time
 (can jump for 0.1 s after walking off an edge); jump buffering (pressing jump
 up to 0.1 s before landing still triggers a jump); variable jump height
 (release jump early to cut the upward velocity in half). Use
 `move_and_slide()`.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const SPEED       := 300.0
const GRAVITY     := 980.0
const JUMP_V      := -520.0
const COYOTE_TIME := 0.10
const JUMP_BUFFER := 0.10

var coyote_timer : float = 0.0
var buffer_timer : float = 0.0
var jump_held    : bool  = false

func _physics_process(delta: float) -> void:
    # ── Gravity ──────────────────────────────────────
    var on_floor := is_on_floor()
    if not on_floor:
        velocity.y += GRAVITY * delta

    # ── Coyote time ──────────────────────────────────
    if on_floor:
        coyote_timer = COYOTE_TIME
    else:
        coyote_timer -= delta

    # ── Jump buffer ──────────────────────────────────
    if Input.is_action_just_pressed("jump"):
        buffer_timer = JUMP_BUFFER
    else:
        buffer_timer -= delta

    # ── Jump ─────────────────────────────────────────
    var can_jump := coyote_timer > 0.0
    if buffer_timer > 0.0 and can_jump:
        velocity.y   = JUMP_V
        coyote_timer = 0.0
        buffer_timer = 0.0
        jump_held    = true

    # ── Variable height: cut velocity if jump released ─
    if jump_held and Input.is_action_just_released("jump"):
        if velocity.y < 0.0:
            velocity.y *= 0.5
        jump_held = false

    if on_floor:
        jump_held = false

    # ── Horizontal ───────────────────────────────────
    velocity.x = Input.get_axis("ui_left", "ui_right") * SPEED

    move_and_slide()
```

Coyote time is maintained by a countdown timer that resets to
 `COYOTE_TIME` every frame the character is on the floor.
 Jump buffering uses the same pattern in reverse: pressing jump sets
 a countdown, and the actual jump fires whenever the character gains
 ground during that window.
::::
:::

Godot 4.6 Complete Reference · Part II — 2D Game Development · Generated for self-study. Edit freely.
