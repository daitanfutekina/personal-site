---
title: "Debugging & Profiling — Finding and Fixing Problems"
source: "godot_ch23_debugging.html"
---

Part III · Chapter 23

# Debugging & Profiling — Finding and Fixing Problems

Prerequisite: Chapters 4 & 10 (GDScript) · est. 75 min

## Overview

Every game developer spends a large fraction of their time not writing new features, but
 figuring out why existing features misbehave. Godot ships with a complete debugging
 toolkit built directly into the editor: a script debugger with breakpoints and
 step-through, a remote scene tree for inspecting a running game, a frame profiler for
 tracking CPU and GPU time, and a suite of real-time performance monitors. Learning to
 use these tools fluently will cut your debugging time in half.

This chapter covers the complete workflow from quick `print()` diagnostics
 up to the full profiler, and finishes with GDScript's warning system and structured
 error-handling patterns. All examples target Godot 4.6.

:::callout-intuition[Intuition]
Think of debugging in three tiers.

Tier 1

: add a

print()

to confirm a value exists at all.

Tier 2

: set a breakpoint and step
        through logic to understand

why

the value is wrong.

Tier 3

:
        open the profiler to understand

when

performance degrades.  Start at tier 1 and
        only escalate when you need more information.
:::

## 1 · Print Functions & Logging

### 1.1 · The print family

GDScript exposes several `print` variants, each serving a slightly different
 purpose. All output appears in both the editor's **Output** panel and the
 **Debugger → Output** tab of a running game.

| Function | What it does | When to use |
| --- | --- | --- |
| `print(…)` | Converts every argument to String and joins them with a space, ending with `\n`. | Quick diagnostic — the everyday workhorse. |
| `print_rich(…)` | Interprets BBCode tags (`[b]`, `[color=red]` etc.) for coloured output in the Output panel. | Distinguishing log categories visually. |
| `prints(…)` | Joins arguments with a *space* separator (equivalent to `print()`). | Legacy alias; prefer `print()`. |
| `printt(…)` | Joins arguments with a *tab* separator. | Aligning columnar debug output. |
| `printraw(…)` | Outputs without a newline and without any conversion — raw bytes. | Terminal spinners, partial-line updates. |
| `printerr(…)` | Prints to the **Errors** tab (stderr in exported builds). Shows in red. | Non-fatal error conditions you want to track. |
| `print_verbose(…)` | Only outputs when Godot is launched with the `--verbose` flag or  `OS.is_stdout_verbose()` is `true`. | Detailed trace logs that would flood the output in normal play. |

```gdscript
func _ready() -> void:
    var hp  : int   = 75
    var name: String = "Hero"

    # Basic — most common
    print("HP:", hp)                    # HP: 75

    # Formatted string (preferred for complex output)
    print("%s HP: %d / 100" % [name, hp])   # Hero HP: 75 / 100

    # Rich colour (editor Output panel only)
    print_rich("[color=yellow]Warning:[/color] low HP (%d)" % hp)

    # Verbose — hidden unless --verbose flag is passed
    print_verbose("_ready() called on ", name)
```

:::callout-tip[Tip]
In Godot 4 all

print

calls are

stripped from release builds

if you disable

Debug → Settings → Stdout → Print Stdout

in the export preset,
        so you do not need to remove them manually before shipping.
:::

### 1.2 · assert()

`assert(condition, message)` checks a condition at runtime and, if it is
 `false`, immediately pauses execution and shows the message in the
 Debugger. Asserts are **completely removed in release exports** —
 they have zero performance cost in shipped builds.

```gdscript
func take_damage(amount: int) -> void:
    assert(amount >= 0, "Damage cannot be negative! Got: %d" % amount)
    assert(is_inside_tree(), "take_damage called before node entered the tree")
    hp -= amount
    hp = max(0, hp)
```

Use asserts to encode *invariants*: things that should *always* be true
 at that point in the code. They are far more readable than an `if` guard
 followed by a `printerr()`, and they produce a paused debugger session
 automatically — no extra work needed.

:::callout-warning[Warning]
Because asserts are stripped in release builds,

never put side-effects inside
        an assert condition

.  Code like

assert(spawn\_enemy() != null)

will silently skip

spawn\_enemy()

in release builds, introducing a logic bug.
:::

### 1.3 · push\_error() and push\_warning()

`push_error(message)` and `push_warning(message)` add an entry
 to the editor's Errors panel (or the exported log file) *and* pause execution
 in the editor debugger if **Break on Error** is active. Unlike
 `printerr()`, they carry a full call stack.

```gdscript
func load_config(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        push_warning("Config not found at '%s', using defaults." % path)
        return {}

    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_error("Failed to open config: %s  Error: %s" % [
            path, error_string(FileAccess.get_open_error())
        ])
        return {}

    return JSON.parse_string(file.get_as_text())
```

:::callout-key[Key Concept]
push\_error vs printerr:

use

push\_error()

for conditions
        that represent a programming mistake or unrecoverable state — it creates a clickable
        stack trace in the Errors panel.  Use

printerr()

for expected runtime
        warnings that are recoverable (e.g., a missing optional file) and where you do not want
        to trigger "Break on Error".
:::

## 2 · The Script Debugger

Open the **Debugger** panel via Ctrl+Shift+D or the bottom
 panel tabs. It contains several sub-tabs: *Stack Trace*, *Locals*,
 *Members*, *Globals*, *Monitors*, and *Video RAM*.
 The debugger becomes active the moment you run the project with F5
 (or F6 for the current scene).

### 2.1 · Setting breakpoints

Click the **gutter** (the narrow column to the left of the line numbers)
 in any GDScript file to place a red dot — a breakpoint. You can also set a breakpoint
 programmatically with `breakpoint` (a keyword, not a function):

```gdscript
func _process(delta: float) -> void:
    var velocity := _compute_velocity(delta)

    breakpoint   # execution pauses here every frame — remove after debugging!

    global_position += velocity * delta
```

:::callout-pitfall[Pitfall]
The

breakpoint

keyword is

not

stripped from release builds
        the way

assert()

is.  Always remove it (or comment it out) before exporting.
        Use a temporary constant to make removal easy:

const DEBUG\_BREAK := false

, then

if DEBUG\_BREAK: breakpoint

.
:::

### 2.2 · Step controls

When execution is paused (at a breakpoint or after a crash) the debugger toolbar
 shows four controls:

| Button | Shortcut | Action |
| --- | --- | --- |
| Continue | F8 | Resume execution until the next breakpoint or end of game. |
| Step Over | F10 | Execute the current line and pause on the *next* line in the same function. Does not enter called functions. |
| Step Into | F11 | Execute the current line and, if it calls a function, pause on the *first line of that function*. |
| Step Out | Shift+F11 | Run the rest of the current function and pause at the call site in the caller. |

**Break on Error** (the red bug icon in the Debugger toolbar) causes
 Godot to automatically pause whenever `push_error()` is called or an
 unhandled engine error occurs. It is on by default in debug builds and invaluable
 for tracking down the exact line that triggers a runtime error.

### 2.3 · Inspecting variables while paused

While paused, the **Locals** tab shows every local variable in the
 current stack frame together with its current value. The **Stack Trace**
 tab shows the full call chain; clicking any frame in the stack will jump the editor
 to that line and update the Locals tab for that frame's scope.

You can *expand* Array, Dictionary, and Object values inline to drill into
 nested data — far faster than printing individual fields with `print()`.

:::callout-tip[Tip — Conditional breakpoints]
Godot 4.6 does not support conditional breakpoints in the GUI directly, but you can
        simulate them with a trivial guard:

```gdscript
if enemy_id == 5:
    breakpoint   # only pauses for the problematic enemy
```
:::

## 3 · Remote Scene Tree & Inspector

When a project is running inside the editor (debug build), a **Remote**
 tab appears at the top of the Scene panel. Clicking it switches the Scene Tree to a
 *live* view of nodes that actually exist in the running game, including nodes
 spawned at runtime (enemies, bullets, UI popups) that are not part of any static scene
 file.

### 3.1 · Remote Inspector

Click any node in the Remote tab to open it in the Inspector. Every exported property
 is shown with its *current runtime value*. You can read things like:

- A `CharacterBody2D`'s `velocity` vector every frame.
- An AnimationPlayer's `current_animation` and `current_animation_position`.
- An Area2D's `monitoring` flag to check whether it was accidentally disabled.
- A Label's `text` to confirm the string was built correctly.

The Remote Inspector updates in real-time while the game is running — no need to pause.

:::callout-tip[Tip — Spotting "invisible" nodes]
If a node you expected to see in the Remote Tree is missing, the likely causes are:
        (1) it was not added to the tree (

add\_child()

was never called),
        (2) it was freed prematurely, or (3) a

queue\_free()

was called unexpectedly.
        The Remote Tree is the fastest way to confirm node lifetime bugs.
:::

### 3.2 · Live Scene Editing

Turn on **Synchronize Scene Changes** in the editor’s **Debug** menu (it is a menu toggle, not a project setting) to apply edits made in the editor
 to the running game in real-time. This works for:

- Moving or resizing nodes in the 2D/3D viewport.
- Changing exported property values in the Inspector.
- Adding or removing nodes from the remote tree.

Live editing is excellent for tweaking values like damage numbers, animation speeds,
 or camera offsets without restarting the game for every small change.

:::callout-warning[Warning]
Live scene editing does

not

persist changes back to the scene file on disk.
        If you find a value that works, write it down (or copy it from the Remote Inspector)
        and apply it to the scene file manually before stopping the game.
:::

## 4 · The Profiler

The **Debugger → Profiler** tab records per-frame timing data while the
 game is running. It answers the question: *which functions are eating my frame
 budget?*

To use it:

1. Run the project in the editor (F5).
2. Open **Debugger → Profiler**.
3. Click **Start** (the play button in the Profiler sub-toolbar).
4. Play the game through the scenario you want to measure.
5. Click **Stop**. A frame timeline and function table appear.

### 4.1 · Reading the Profiler panels

The Profiler has three primary areas:

| Area | What it shows |
| --- | --- |
| **Frame graph** (top) | A timeline bar chart — each bar is one frame. Height corresponds to total frame  time. Tall spikes indicate hitches. Click a bar to inspect that specific frame. |
| **Function list** (bottom-left) | All functions called during the profiled period, sortable by *Self*  (time spent inside the function only) or *Total* (including called  sub-functions). Sort by *Self* first to find hotspots. |
| **Call graph** (bottom-right) | A tree view of callers and callees for the selected function. Helps trace  *why* an expensive function is called. |

### 4.2 · Identifying and fixing bottlenecks

The profiler's function list groups results by category. Common categories to watch:

| Category | Typical culprits | Common fixes |
| --- | --- | --- |
| `_process` | Complex logic in every entity's `_process` | Move to `_physics_process` or timer-driven updates; use groups to batch updates. |
| Physics | Too many physics bodies; complex collision shapes | Reduce physics FPS (*Project Settings → Physics*); use simple collision shapes; disable physics on distant objects. |
| Script | Array/Dictionary churn, expensive `find()` in large collections | Cache results; use Dictionary for O(1) lookup; avoid `new` inside loops. |
| Rendering | Too many draw calls; large uncompressed textures | Combine meshes; compress textures; use LOD; check Video RAM monitor. |
| Audio | Many simultaneous polyphonic streams | Limit polyphony with AudioStreamPolyphonic; pool AudioStreamPlayer nodes. |

:::callout-intuition[Intuition — Self vs Total time]
If a function has high

Total

but low

Self

, the time is spent inside
        functions it

calls

, not in its own code.  Expand its call tree to find the
        actual hotspot.  Only fix

Self

time by rewriting that function's body.
:::

:::callout-tip[Tip — Profile release builds too]
Debug builds run noticeably slower than release builds (typically 20–40% slower) due
        to all the debugger instrumentation.  If a performance target only barely passes in
        debug, profile and test the release export as well to confirm real-world performance.
        Use

Project → Export → Debug

preset with profiling enabled.
:::

## 5 · Performance Monitors

The **Debugger → Monitors** tab displays real-time graphs for dozens of
 engine metrics. Unlike the profiler (which records a session for later analysis),
 Monitors update live at the game's FPS — perfect for watching for leaks or spikes
 during gameplay.

### 5.1 · Reading monitors and the Performance singleton

Every graph corresponds to a constant in the `Performance` singleton.
 You can read any monitor value from GDScript at runtime:

```gdscript
func _process(_delta: float) -> void:
    var fps          := Performance.get_monitor(Performance.TIME_FPS)
    var draw_calls   := Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
    var objects      := Performance.get_monitor(Performance.OBJECT_COUNT)
    var nodes        := Performance.get_monitor(Performance.OBJECT_NODE_COUNT)
    var orphan_nodes := Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT)
    var static_mem   := Performance.get_monitor(Performance.MEMORY_STATIC) / 1_048_576.0  # MB

    $HUD/FPSLabel.text = "FPS: %.0f  Draws: %.0f  Nodes: %.0f (orphans: %.0f)  RAM: %.1f MB" % [
        fps, draw_calls, nodes, orphan_nodes, static_mem
    ]
```

The most useful monitors for game developers:

| Monitor constant | What it measures |
| --- | --- |
| `TIME_FPS` | Frames per second. |
| `TIME_PROCESS` | Time (seconds) spent in `_process()` across all nodes last frame. |
| `TIME_PHYSICS_PROCESS` | Time spent in physics step last frame. |
| `RENDER_TOTAL_DRAW_CALLS_IN_FRAME` | GPU draw calls issued last frame — keep below ~1000 for mobile, ~10000 for PC. |
| `RENDER_VIDEO_MEM_USED` | GPU VRAM consumed by textures, meshes, and render targets. |
| `OBJECT_COUNT` | Total live Object instances (includes nodes, resources, class instances). |
| `OBJECT_NODE_COUNT` | Nodes currently in the scene tree. |
| `OBJECT_ORPHAN_NODE_COUNT` | Nodes *not* in the tree. Should be near 0; a growing number indicates a leak. |
| `MEMORY_STATIC` | Static (heap) memory used by the engine and scripts. |
| `PHYSICS_2D_ACTIVE_OBJECTS` | Active (non-sleeping) 2D physics bodies. |
| `PHYSICS_3D_ACTIVE_OBJECTS` | Active 3D physics bodies. |
| `AUDIO_OUTPUT_LATENCY` | Audio output latency in seconds. |

### 5.2 · Adding custom monitors

In Godot 4.2+ you can register your own game-specific metrics so they appear in the
 Monitors graph alongside built-in ones. This is done through
 `Performance.add_custom_monitor(id, callable, arguments)`:

```gdscript
# In an Autoload (e.g. GameMetrics.gd)
extends Node

var _enemy_count: int = 0

func _ready() -> void:
    # The callable is called each time the monitor is sampled
    Performance.add_custom_monitor(
        "Game/Enemy Count",          # name shown in the Monitor graph
        _get_enemy_count             # callable — no arguments needed
    )
    Performance.add_custom_monitor(
        "Game/Bullets In Pool",
        _get_pool_size
    )

func _get_enemy_count() -> int:
    return get_tree().get_nodes_in_group("enemies").size()

func _get_pool_size() -> int:
    return BulletPool.available_count()  # hypothetical autoload
```

Custom monitors appear under the *Custom* category in the Monitors tab and can
 be graphed like any built-in monitor. Remove them before shipping with
 `Performance.remove_custom_monitor("Game/Enemy Count")`.

:::callout-tip[Tip — Detecting node leaks]
Watch

OBJECT\_ORPHAN\_NODE\_COUNT

while spawning and destroying game objects.
        If the count grows without bound, you have nodes being created with

Node.new()

or

load().instantiate()

but never added to the
        tree

and

never freed.  Common causes: forgetting

queue\_free()

in cleanup code, or keeping a strong reference to a node after removing it from the
        tree prevents garbage collection.
:::

## 6 · Error Handling Patterns

### 6.1 · Godot's Error enum and error\_string()

Many Godot API calls return an `Error` enum value rather than throwing an
 exception. Always check the return value of functions that can fail.

```gdscript
func save_game(path: String, data: Dictionary) -> bool:
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        var err := FileAccess.get_open_error()
        push_error("Cannot open '%s' for writing: %s" % [path, error_string(err)])
        return false

    file.store_string(JSON.stringify(data, "\t"))
    # FileAccess auto-closes when it goes out of scope (Godot 4)
    return true

func connect_signal_safe(source: Object, sig: StringName, target: Callable) -> void:
    var err := source.connect(sig, target)
    if err != OK:
        push_error("Failed to connect signal '%s': %s" % [sig, error_string(err)])

# Loading a scene safely
func load_scene_safe(path: String) -> PackedScene:
    if not ResourceLoader.exists(path):
        push_error("Scene not found: %s" % path)
        return null

    var scene := load(path) as PackedScene
    if scene == null:
        push_error("Resource at '%s' is not a PackedScene." % path)
        return null

    return scene
```

The `Error` enum constants you will encounter most often:

| Constant | Value | Meaning |
| --- | --- | --- |
| `OK` | 0 | Success — no error. |
| `FAILED` | 1 | Generic failure without a more specific code. |
| `ERR_FILE_NOT_FOUND` | 7 | File does not exist at the given path. |
| `ERR_FILE_NO_PERMISSION` | 8 | Insufficient OS permissions. |
| `ERR_FILE_ALREADY_IN_USE` | 11 | Another process (or the game itself) has the file locked. |
| `ERR_INVALID_DATA` | 30 | Data was found but could not be parsed (e.g. corrupt JSON). |
| `ERR_CANT_CONNECT` | 21 | Network connection could not be established. |
| `ERR_TIMEOUT` | 24 | Operation timed out. |

:::callout-key[Key Concept — Return vs throw]
GDScript does not have exceptions (no

try/catch

).  Error propagation is
        done by returning an

Error

code or a nullable type (

null

on
        failure), combined with

push\_error()

for developer notification.  Design
        your functions to either return success data

or

return

null

/

false

and call

push\_error()

internally so callers can handle
        failure gracefully.
:::

### 6.2 · GDScript static analysis & warnings

Godot's GDScript analyser runs at edit time and flags potential problems as
 **warnings** (yellow underlines in the script editor). Warnings do not
 prevent execution but indicate code that is likely wrong.

The most important warning categories:

| Warning | What triggers it | How to fix |
| --- | --- | --- |
| `UNTYPED_DECLARATION` | A variable or parameter has no type annotation. | Add a type: `var hp: int = 100`. |
| `INFERRED_DECLARATION` | Type inferred with `:=` — usually fine, but flagged for explicitness. | Replace with an explicit type annotation if strict mode is required. |
| `RETURN_VALUE_DISCARDED` | A function that returns a value is called without using the return value. | Assign the return value or prefix the call with `@warning_ignore`. |
| `UNUSED_VARIABLE` | A local variable is declared but never read. | Remove the variable or rename it to `_` to silence the warning. |
| `SHADOWED_VARIABLE` | A local variable has the same name as a member or outer-scope variable. | Rename one of them to avoid confusion. |
| `INTEGER_DIVISION` | `int / int` will truncate; result might be unintentionally 0. | Cast one operand to float: `float(a) / b`. |
| `UNSAFE_CAST` | `as` cast to a type that may fail at runtime. | Check for `null` after the cast. |

Warnings can be configured globally in **Project Settings → Debug →
 GDScript → Warnings**, or suppressed for a single line with an annotation:

```gdscript
# Suppress a specific warning for one line
@warning_ignore("return_value_discarded")
get_tree().create_timer(1.0)

# Or silence an unused variable by prefixing with underscore
for _i in range(10):
    do_something()
```

Enable **Treat Warnings as Errors** in the same settings page to enforce
 warning-free code across your project — this is highly recommended for teams and
 larger projects to prevent type-related bugs from accumulating silently.

### 6.3 · Using @tool for editor-time debugging

Scripts with the `@tool` annotation run inside the editor as well as in the
 game. This is useful for writing custom gizmos, validation checks, and property-update
 callbacks that surface problems at design time rather than run time.

```gdscript
@tool
extends Sprite2D

@export var radius: float = 50.0 :
    set(v):
        radius = v
        # Immediately validate in the editor
        if radius <= 0.0:
            push_warning("Sprite2D radius must be positive (got %.2f)" % v)
        queue_redraw()

func _draw() -> void:
    if Engine.is_editor_hint():
        # Draw a debug circle visible only in the editor viewport
        draw_circle(Vector2.ZERO, radius, Color(0, 1, 0, 0.25))
```

:::callout-connect[Connect — Autoloads & Logging]
Large projects benefit from a

Logger

autoload that wraps

print\_rich()

with log levels (DEBUG / INFO / WARN / ERROR) and writes to
        a file with timestamps.  This gives you persistent logs to review after a crash in a
        shipped build.  The pattern is straightforward: expose a static method per level, check
        a global

min\_level

constant, forward to

print\_rich()

in debug
        and

push\_error()

/

push\_warning()

for WARN+ levels.
:::

## Summary

Godot's debugging toolkit layers neatly from quick print diagnostics up to a full
 frame profiler. Use `print()` and `print_rich()` for fast
 inspection; use `assert()` for invariants that should be impossible to
 violate; use `push_error()` when you need a call stack and want the
 editor to pause on the problem. The script debugger gives you breakpoints, step
 controls, and live variable inspection without any additional setup. The Remote
 scene tree lets you inspect and even tweak a running game in real time. The Profiler
 records per-function timing to locate CPU hotspots, and the Monitors tab lets you
 track memory, draw calls, and node counts live — plus add your own game-specific
 metrics. For structural code quality, Godot's static warning system catches common
 mistakes at edit time, and enabling *Treat Warnings as Errors* keeps the bar
 high as a project grows.

| Tool | Best for | Available in release? |
| --- | --- | --- |
| `print()` / `print_rich()` | Quick value checks, trace logging | Yes (strip via export preset) |
| `assert()` | Invariant checks | No — stripped automatically |
| `push_error()` / `push_warning()` | Stack-traced error reporting | Yes (writes to log file) |
| `breakpoint` | Unconditional pause in debugger | Yes — must remove manually |
| Script Debugger | Step-through logic inspection | Editor only |
| Remote Scene Tree | Runtime node & property inspection | Editor only |
| Profiler | Frame timing & function hotspots | Editor only |
| Performance Monitors | Live FPS, memory, draw-call graphs | Readable in-game via API |
| GDScript Warnings | Static code analysis at edit time | Edit-time only |

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Rich-colour logging

Write a function `log_state(label: String, value: Variant) -> void` that
 prints the label in **cyan** and the value in **white**
 using `print_rich()`. Test it by calling it in `_ready()`
 with three different variable types (int, Vector2, String).

::::solution[Solution]
```gdscript
func log_state(label: String, value: Variant) -> void:
    print_rich("[color=cyan]%s[/color]: [color=white]%s[/color]" % [label, str(value)])

func _ready() -> void:
    log_state("HP",       100)
    log_state("Position", Vector2(32.0, 64.0))
    log_state("Name",     "Hero")
```
::::
:::

:::problem{difficulty="easy"}
### P2 · Invariant guard with assert

Write a function `set_max_hp(value: int) -> void` that sets a member
 variable `max_hp`. Add assertions to guarantee:

- `value` is greater than 0.
- `value` is no greater than 9999.

Write two tests: one that passes and one that would trigger the assert
 (comment the failing one out after testing).

::::solution[Solution]
```gdscript
var max_hp: int = 100

func set_max_hp(value: int) -> void:
    assert(value > 0,    "max_hp must be positive, got %d" % value)
    assert(value <= 9999,"max_hp exceeds cap (9999), got %d" % value)
    max_hp = value

func _ready() -> void:
    set_max_hp(250)      # passes
    # set_max_hp(-10)    # would trigger assert — uncomment to test
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Safe resource loader

Write a utility function
 `load_texture_safe(path: String) -> Texture2D` that:

1. Checks that the file exists with `ResourceLoader.exists()`.
2. Loads it and casts to `Texture2D`.
3. Calls `push_error()` with a descriptive message for each failure mode.
4. Returns `null` on failure.

Demonstrate calling the function with a valid path and an invalid path.

::::solution[Solution]
```gdscript
func load_texture_safe(path: String) -> Texture2D:
    if not ResourceLoader.exists(path, "Texture2D"):
        push_error("Texture not found: '%s'" % path)
        return null

    var res := load(path)
    var tex  := res as Texture2D
    if tex == null:
        push_error("Resource at '%s' is not a Texture2D (got %s)" % [
            path, res.get_class() if res else "null"
        ])
        return null

    return tex

func _ready() -> void:
    var ok_tex := load_texture_safe("res://icon.svg")        # valid
    var bad_tex := load_texture_safe("res://missing.png")    # push_error
    print(ok_tex, bad_tex)
```
::::
:::

:::problem{difficulty="standard"}
### P4 · In-game performance HUD

Create a CanvasLayer with a Label child. In `_process()` update the
 label every 0.25 seconds (use a timer accumulator, not a Timer node) to display:

- FPS (rounded to the nearest integer).
- Total node count.
- Orphan node count.
- Static memory in MB (1 MB = 1,048,576 bytes).

Toggle visibility with F3.

::::solution[Solution]
```gdscript
extends CanvasLayer

@onready var label: Label = $Label
var _timer: float = 0.0

func _ready() -> void:
    visible = false   # hidden by default

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed:
        if event.keycode == KEY_F3:
            visible = not visible

func _process(delta: float) -> void:
    if not visible:
        return

    _timer += delta
    if _timer < 0.25:
        return
    _timer = 0.0

    var fps      := Performance.get_monitor(Performance.TIME_FPS)
    var nodes    := Performance.get_monitor(Performance.OBJECT_NODE_COUNT)
    var orphans  := Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT)
    var mem_mb   := Performance.get_monitor(Performance.MEMORY_STATIC) / 1_048_576.0

    label.text = "FPS: %d  Nodes: %.0f  Orphans: %.0f  RAM: %.1f MB" % [
        roundi(fps), nodes, orphans, mem_mb
    ]
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Custom performance monitor

Create a `GameMetrics` autoload that registers two custom monitors:

- `"Game/Enemies"` — returns the size of the `"enemies"` group.
- `"Game/Projectiles"` — returns the size of the `"projectiles"` group.

Verify that both monitors appear in the Debugger → Monitors tab when you run the
 project. Add at least two nodes to each group in a test scene to confirm the values
 are non-zero.

::::solution[Solution]
```gdscript
# GameMetrics.gd (Autoload)
extends Node

func _ready() -> void:
    Performance.add_custom_monitor("Game/Enemies",     _count_enemies)
    Performance.add_custom_monitor("Game/Projectiles", _count_projectiles)

func _count_enemies() -> int:
    return get_tree().get_nodes_in_group("enemies").size()

func _count_projectiles() -> int:
    return get_tree().get_nodes_in_group("projectiles").size()
```

In your test scene, add any two nodes and call
 `add_to_group("enemies")` in their `_ready()`. The
 *Game/Enemies* graph in the Monitors tab will then read 2.
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full Logger Autoload with file output

Build a `Logger` autoload that supports four log levels:
 `DEBUG`, `INFO`, `WARN`, `ERROR`.
 Requirements:

1. A configurable `min_level` property — messages below this level are
 silently discarded.
2. Each level uses a distinct colour via `print_rich()`:
 grey / white / yellow / red.
3. WARN calls `push_warning()`; ERROR calls `push_error()`.
4. All messages are **also written to a log file** at
 `user://game.log` with a timestamp prefix
 (`Time.get_datetime_string_from_system()`).
5. The log file is opened on `_ready()` and closed (via
 `queue_free()` cleanup or
 `_notification(NOTIFICATION_PREDELETE)`) when the autoload exits.

Demonstrate usage: log one message at each level, then set
 `Logger.min_level = Logger.Level.WARN` and confirm DEBUG and INFO
 messages are suppressed.

::::solution[Solution]
```gdscript
# Logger.gd  (Autoload — add to Project Settings → Autoloads)
extends Node

enum Level { DEBUG = 0, INFO = 1, WARN = 2, ERROR = 3 }

const COLOURS := {
    Level.DEBUG: "gray",
    Level.INFO:  "white",
    Level.WARN:  "yellow",
    Level.ERROR: "red",
}
const LABELS := {
    Level.DEBUG: "DEBUG",
    Level.INFO:  "INFO ",
    Level.WARN:  "WARN ",
    Level.ERROR: "ERROR",
}

var min_level: Level = Level.DEBUG
var _file: FileAccess = null

func _ready() -> void:
    _file = FileAccess.open("user://game.log", FileAccess.WRITE)
    if _file == null:
        push_warning("Logger: could not open user://game.log for writing.")

func _notification(what: int) -> void:
    if what == NOTIFICATION_PREDELETE:
        _file = null   # FileAccess closes on GC

func debug(msg: String) -> void: _log(Level.DEBUG, msg)
func info (msg: String) -> void: _log(Level.INFO,  msg)
func warn (msg: String) -> void: _log(Level.WARN,  msg)
func error(msg: String) -> void: _log(Level.ERROR, msg)

func _log(level: Level, msg: String) -> void:
    if level < min_level:
        return

    var ts     := Time.get_datetime_string_from_system()
    var colour := COLOURS[level]
    var label  := LABELS[level]
    var line   := "[%s] [%s] %s" % [ts, label, msg]

    print_rich("[color=%s]%s[/color]" % [colour, line])

    if _file:
        _file.store_line(line)
        _file.flush()   # ensure writes reach disk even on crash

    if level == Level.WARN:
        push_warning(msg)
    elif level == Level.ERROR:
        push_error(msg)

# ── Demo (in any scene's _ready) ─────────────────────────────────────
# func _ready() -> void:
#     Logger.debug("System initialised")
#     Logger.info("Player spawned at origin")
#     Logger.warn("Save file missing, using defaults")
#     Logger.error("Critical asset not found: res://sprites/hero.png")
#
#     Logger.min_level = Logger.Level.WARN
#     Logger.debug("This is suppressed")   # silent
#     Logger.info("This is suppressed")    # silent
#     Logger.warn("This still shows")      # visible
```
::::
:::
