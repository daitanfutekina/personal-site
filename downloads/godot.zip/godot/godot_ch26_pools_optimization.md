---
title: "Object Pools & Optimization — Smooth Framerates at Scale"
source: "markdown"
---

Part III · Chapter 26

# Object Pools & Optimization — Smooth Framerates at Scale

Prerequisite: Ch 3 (Nodes), Ch 12 (Autoloads), Ch 23 (Profiling) · est. 80 min

## Overview

Performance problems are rarely where you expect them. The single most common source
 of frame spikes in Godot games is not complex AI or physics — it is the repeated
 creation and destruction of short-lived nodes: bullets, particles, hit effects, debris.
 Each `instantiate()` allocates memory; each `queue_free()`
 triggers deferred cleanup. When hundreds of these happen per second, the garbage
 collector stalls and the frame rate lurches.

The solution is **object pooling**: pre-create a fixed set of nodes at
 startup and recycle them rather than allocating new ones. Combined with a handful of
 GDScript micro-optimisations, visibility culling, and Godot's
 `MultiMeshInstance2D` for large crowds of identical objects, you can
 maintain smooth framerates even in dense action scenes.

:::callout-intuition[Intuition — Measure before optimising]
Always profile first (Chapter 23).  Optimising code that is not a bottleneck wastes
        time and adds complexity.  The workflow is: Profile → Identify the hotspot → Fix it →
        Profile again.  Pool bullets because the profiler shows allocation spikes during
        shooting, not because pooling sounds smart.
:::

## 1 · Why Object Pooling?

### 1.1 · The cost of instantiate() and queue\_free()

When you call `scene.instantiate()`, Godot must:

1. Allocate heap memory for the node and all its children.
2. Copy property values from the `PackedScene` data.
3. Call `_init()` on each script attached to those nodes.
4. Connect any signals wired up in the scene file.
5. Run `add_child()` which triggers `_enter_tree()` and
 `_ready()` on every node in the new scene.

For a bullet scene with a Sprite2D, a CollisionShape2D, and a script, this might
 be 5–10 µs per spawn. At 600 bullets per second (a modest bullet-hell scenario)
 that is 3–6 ms/s consumed purely by allocation — often more than the entire frame
 budget on mobile.

`queue_free()` is deferred, meaning the engine cleans up freed nodes at
 the end of the frame. If many nodes are freed simultaneously (explosion in a crowd),
 the cleanup cost can cause a single-frame spike visible as a hitch.

### 1.2 · What pooling eliminates

A pool pre-creates N instances at startup and keeps them alive forever.
 "Spawning" a bullet means: take an idle instance from the pool, reset its state
 (position, velocity), make it visible, and add it to the group.
 "Destroying" it means: make it invisible, disable its collision, and return it to
 the pool. No allocation, no deallocation — just property writes.

|  | Instantiate/free approach | Pool approach |
| --- | --- | --- |
| **Spawn cost** | 5–50 µs (allocation + \_ready) | ~1 µs (property writes) |
| **Destroy cost** | Deferred frame spike | Negligible |
| **Memory** | Fluctuates with live count | Fixed (pool size × instance size) |
| **Complexity** | None | Pool management code |

## 2 · Building a Generic Node Pool

### 2.1 · Design principles

A good pool has three operations:

- **acquire()** — return an idle instance; if none are available,
 either grow the pool or return null (hard cap).
- **release(instance)** — return the instance to the idle list and
 reset it to a clean state.
- **prewarm(count)** — fill the pool at startup to avoid first-use
 latency.

The pooled scene must cooperate: it needs a method (e.g., `reset()`) that
 the pool can call to restore the instance to its initial state before handing it out.

### 2.2 · A generic NodePool class + autoload

```gdscript
# node_pool.gd  — reusable pool class (not an autoload itself)
class_name NodePool

var _scene:    PackedScene
var _parent:   Node
var _idle:     Array[Node] = []
var _active:   Array[Node] = []
var _max_size: int = -1   # -1 = unlimited growth

## Create a pool for `scene`, with nodes parented to `parent`.
## Pass max_size > 0 to hard-cap the pool (returns null when exhausted).
func _init(scene: PackedScene, parent: Node, prewarm: int = 8,
           max_size: int = -1) -> void:
    _scene    = scene
    _parent   = parent
    _max_size = max_size
    for _i in prewarm:
        _create_idle()

## Get an instance from the pool (or null if capped and empty).
func acquire() -> Node:
    if _idle.is_empty():
        if _max_size > 0 and (_idle.size() + _active.size()) >= _max_size:
            return null   # hard cap reached
        _create_idle()

    var node := _idle.pop_back()
    _active.append(node)
    node.set_meta("_pool_ref", self)
    node.show()
    if node.has_method("on_acquired"):
        node.on_acquired()
    return node

## Return an instance to the pool.
func release(node: Node) -> void:
    var idx := _active.find(node)
    if idx == -1:
        push_warning("NodePool: releasing a node not in active list.")
        return
    _active.remove_at(idx)
    node.hide()
    if node.has_method("on_released"):
        node.on_released()
    _idle.append(node)

## Release all active instances at once (e.g., on level reset).
func release_all() -> void:
    for node in _active.duplicate():
        release(node)

func active_count()  -> int: return _active.size()
func idle_count()    -> int: return _idle.size()

func _create_idle() -> void:
    var node := _scene.instantiate()
    _parent.add_child(node)
    node.hide()
    _idle.append(node)
```

Now any pooled scene simply implements the optional hooks:

```gdscript
# bullet.gd
extends Area2D

var velocity: Vector2 = Vector2.ZERO
var damage:   int     = 10

func on_acquired() -> void:
    # Called when the pool hands us out — nothing to do here
    $CollisionShape2D.disabled = false

func on_released() -> void:
    # Called when we are returned to the pool
    $CollisionShape2D.disabled = true
    velocity = Vector2.ZERO

func launch(pos: Vector2, dir: Vector2, spd: float, dmg: int) -> void:
    global_position = pos
    velocity        = dir.normalized() * spd
    damage          = dmg

func _physics_process(delta: float) -> void:
    global_position += velocity * delta
    # Return to pool when off-screen
    if global_position.distance_to(Vector2.ZERO) > 2000.0:
        _pool_ref().release(self)

func _on_body_entered(body: Node) -> void:
    if body.has_method("take_damage"):
        body.take_damage(damage)
    _pool_ref().release(self)

func _pool_ref() -> NodePool:
    return get_meta("_pool_ref") as NodePool
```

The autoload that manages pools for the whole game:

```gdscript
# Pools.gd  (Autoload)
extends Node

const BULLET_SCENE  := preload("res://scenes/projectiles/bullet.tscn")
const EXPLOSION_SCN := preload("res://scenes/fx/explosion.tscn")

var bullets:    NodePool
var explosions: NodePool

func _ready() -> void:
    bullets    = NodePool.new(BULLET_SCENE,  self, 64, 128)
    explosions = NodePool.new(EXPLOSION_SCN, self, 16, 32)

# Usage from a weapon script:
func fire(origin: Vector2, direction: Vector2) -> void:
    var bullet := Pools.bullets.acquire()
    if bullet == null:
        return   # pool exhausted — hard cap reached, skip this shot
    (bullet as Bullet).launch(origin, direction, 400.0, 15)
```

:::callout-tip[Tip — Pool size guidance]
Profile your game at peak activity (boss fight, most bullets on screen) and check

Pools.bullets.active\_count()

.  Add 20% headroom above that peak.
        Starting too large wastes memory; starting too small causes the pool to grow
        at runtime (incurring allocation at the worst time).
:::

## 3 · GDScript Performance Tips

GDScript is significantly slower than C++ — roughly 50–200× for pure computation.
 However, most of a game's time is spent in engine calls (physics, rendering, audio)
 rather than in script logic, so the gap matters far less than it sounds. Still,
 a few patterns in GDScript can cause unnecessary overhead.

### 3.1 · Static typing speeds up property access

Typed variables let Godot bypass runtime type checks and use direct property offsets
 rather than dictionary lookups for engine types. The speedup is most visible in
 tight inner loops:

```gdscript
## Slow: every property access goes through a hash lookup
var pos = $Player.position
var vel = $Player.velocity

## Fast: typed — direct slot access, no hash
var pos: Vector2 = $Player.position
var vel: Vector2 = ($Player as CharacterBody2D).velocity
```

### 3.2 · Cache node references and property paths

```gdscript
## Bad: $NodePath resolved every frame by string parsing + tree walk
func _process(_delta: float) -> void:
    $HUD/HealthBar.value = hp
    $HUD/HealthBar.max_value = max_hp

## Good: cache in _ready(), access member variable every frame
@onready var _hp_bar: ProgressBar = $HUD/HealthBar

func _process(_delta: float) -> void:
    _hp_bar.value     = hp
    _hp_bar.max_value = max_hp
```

### 3.3 · Patterns to avoid in hot paths

| Avoid | Why | Instead |
| --- | --- | --- |
| `get_nodes_in_group()` in `_process()` | Allocates a new Array every call. | Cache the array; refresh only when the group changes (signal on add/remove). |
| `find_child("name", true)` | Full subtree search every call. | Use `@onready` or store the reference at startup. |
| String concatenation in loops | Allocates a new String each `+` operation. | Build strings with `"%s %s" % [a, b]` or an Array joined with  `", ".join(parts)`. |
| `Array.push_front() / insert(0, ...)` | O(n) — shifts every element. | Use `push_back()` and reverse once, or use a queue with an index pointer. |
| `has() / find()` on large Arrays | O(n) linear search. | Use a `Dictionary` for O(1) membership checks. |
| Redundant `is_instance_valid()` checks | Not expensive alone, but suggests unsafe ref management. | Use signals to clear references when nodes are freed instead of polling. |
| Calling `Engine.get_physics_frames()` or  `Time.get_ticks_msec()` every frame | Minor, but avoidable engine call overhead. | Cache time values at the start of the frame if used multiple times. |
| Lambdas in `_process()` | Creates a new Callable object each frame. | Use a named function or store the lambda as a member. |

:::callout-tip[Tip — Use \_physics\_process for game logic]
Move as much game logic as possible from

\_process()

to `_physics_process()`.  Physics runs at a fixed timestep (default 60 Hz)
        rather than the display FPS, so logic tied to physics runs a predictable number of
        times per second regardless of frame rate.  This also makes multiplayer simulation
        deterministic.
:::

### 3.4 · Throttling expensive operations

Not everything needs to run every frame. AI pathfinding, sensor checks, and
 distance calculations can run every 4–8 frames without the player noticing:

```gdscript
var _think_counter: int = 0
const THINK_INTERVAL: int = 6   # update AI every 6 physics frames

func _physics_process(_delta: float) -> void:
    _think_counter += 1
    if _think_counter >= THINK_INTERVAL:
        _think_counter = 0
        _update_ai()

    _move()   # movement still runs every frame
```

Stagger the counter across enemies so they do not all recalculate on the same frame:

```gdscript
func _ready() -> void:
    # Offset each enemy by its index to spread load across frames
    _think_counter = get_index() % THINK_INTERVAL
```

## 4 · MultiMeshInstance2D / 3D

`MultiMeshInstance2D` and `MultiMeshInstance3D` allow you to
 render thousands of identical meshes in a single GPU draw call by storing all their
 transforms (and optional colour/custom data) in a packed buffer on the GPU. This is
 the standard technique for grass, trees, bullet casings, coins, crowds, and particle
 trails that need to exist as real game objects rather than visual-only particles.

### 4.1 · Setup

```gdscript
## In the editor: add a MultiMeshInstance2D node.
## In code: configure its MultiMesh resource.

@onready var mmi: MultiMeshInstance2D = $MultiMeshInstance2D

func _ready() -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_2D       # use TRANSFORM_3D for 3D
    mm.use_colors       = true                          # optional per-instance colour
    mm.instance_count   = 500                           # must be set BEFORE transforms
    mm.mesh             = _make_quad_mesh()

    mmi.multimesh = mm
    _scatter_instances()

## Create a simple textured quad mesh
func _make_quad_mesh() -> QuadMesh:
    var q := QuadMesh.new()
    q.size = Vector2(16, 16)
    # Assign a material / texture as needed
    return q

## Write initial transforms
func _scatter_instances() -> void:
    var mm := mmi.multimesh
    for i in mm.instance_count:
        var xf := Transform2D()
        xf.origin = Vector2(randf_range(0, 1280), randf_range(0, 720))
        mm.set_instance_transform_2d(i, xf)
        mm.set_instance_color(i, Color(randf(), randf(), randf()))
```

### 4.2 · Updating transforms each frame

Because all transforms live in a single GPU buffer, updating them is a single
 upload call regardless of instance count — far cheaper than moving hundreds of
 individual `Node2D` objects:

```gdscript
## Animate all instances: rotate each one slightly each frame
func _process(delta: float) -> void:
    var mm := mmi.multimesh
    for i in mm.instance_count:
        var xf := mm.get_instance_transform_2d(i)
        xf = xf.rotated(delta * 1.5)   # rotate 1.5 rad/s
        mm.set_instance_transform_2d(i, xf)

## For maximum performance, write all transforms at once via a PackedFloat32Array
## rather than per-instance calls (avoids per-call overhead for large counts):
func _bulk_update(transforms: Array[Transform2D]) -> void:
    var mm  := mmi.multimesh
    var buf := PackedFloat32Array()
    buf.resize(transforms.size() * 6)   # Transform2D = 6 floats (2×3 matrix)
    for i in transforms.size():
        var xf := transforms[i]
        buf[i * 6 + 0] = xf.x.x; buf[i * 6 + 1] = xf.x.y
        buf[i * 6 + 2] = xf.y.x; buf[i * 6 + 3] = xf.y.y
        buf[i * 6 + 4] = xf.origin.x; buf[i * 6 + 5] = xf.origin.y
    mm.transform_array = buf   # single upload to GPU
```

:::callout-key[Key Concept — When to use MultiMesh]
Use

MultiMeshInstance2D

when you have

many identical visual
        objects

whose main concern is rendering efficiently, and their logic is
        simple enough to manage in a single controlling script.  If each instance needs its
        own complex behaviour (AI, physics, signals), use individual nodes — the overhead
        per node is then justified by the complexity it encapsulates.  For grass and
        decoration: MultiMesh.  For enemies with AI: individual nodes (possibly pooled).
:::

## 5 · Visibility Culling

Godot performs automatic frustum culling for rendering — nodes outside the camera
 view are not drawn. However, their `_process()` and physics still run
 unless you explicitly disable them. For large worlds with many off-screen entities,
 culling process callbacks saves significant CPU time.

### 5.1 · VisibleOnScreenNotifier2D / 3D

Add a `VisibleOnScreenNotifier2D` (or `VisibleOnScreenNotifier2D`
 for a simpler API) as a child of any node to receive callbacks when it enters or
 exits the camera's view.

```gdscript
## EnemyAI.gd — only process AI when on screen
extends CharacterBody2D

@onready var notifier: VisibleOnScreenNotifier2D = $VisibleOnScreenNotifier2D

func _ready() -> void:
    notifier.screen_entered.connect(_on_screen_entered)
    notifier.screen_exited.connect(_on_screen_exited)
    # Start disabled if not visible
    set_process(false)
    set_physics_process(false)

func _on_screen_entered() -> void:
    set_process(true)
    set_physics_process(true)
    $AnimationPlayer.play("walk")

func _on_screen_exited() -> void:
    set_process(false)
    set_physics_process(false)
    $AnimationPlayer.stop()
```

### 5.2 · Manual distance culling

For games with a known camera position (top-down, side-scroller), distance culling
 is even simpler and avoids the overhead of the notifier's AABB check:

```gdscript
## GroupCuller autoload — disable process on distant nodes
extends Node

const CULL_RADIUS   : float = 1200.0   # pixels
const CULL_INTERVAL : int   = 30        # check every 30 frames

var _frame_counter: int = 0

func _physics_process(_delta: float) -> void:
    _frame_counter += 1
    if _frame_counter < CULL_INTERVAL:
        return
    _frame_counter = 0
    _cull_group("enemies")
    _cull_group("projectiles")

func _cull_group(group: String) -> void:
    var cam_pos: Vector2 = _get_camera_pos()
    for node in get_tree().get_nodes_in_group(group):
        var dist := (node as Node2D).global_position.distance_to(cam_pos)
        var active := dist <= CULL_RADIUS
        node.set_process(active)
        node.set_physics_process(active)
        node.visible = active

func _get_camera_pos() -> Vector2:
    var cam := get_tree().get_first_node_in_group("player_camera")
    return (cam as Camera2D).global_position if cam else Vector2.ZERO
```

:::callout-tip[Tip — Physics culling caveat]
Disabling physics process stops a body from moving, but its collision shape remains
        active in the physics server.  For truly inactive bodies, also call

PhysicsServer2D.body\_set\_mode(body.get\_rid(), PhysicsServer2D.BODY\_MODE\_STATIC)

to remove it from the broadphase, or use

CollisionObject2D.set\_collision\_layer(0)

to make it invisible to all collision queries.
:::

## Summary

The root cause of most performance problems in Godot games is repeated node
 allocation. Object pooling solves this by pre-creating a fixed set of instances
 and recycling them — the `NodePool` class from this chapter handles
 acquire/release/prewarm in a generic, reusable way. Beyond pooling, GDScript
 performance hinges on a few simple habits: use static typing, cache
 `@onready` references, prefer `Dictionary` over Array for
 membership lookups, and throttle expensive AI calculations to run every N frames
 with staggered offsets. For rendering large numbers of identical objects,
 `MultiMeshInstance2D` collapses thousands of draw calls into one GPU
 upload. Finally, disable `_process()` and `_physics_process()`
 on off-screen entities via `VisibleOnScreenNotifier2D` or a manual
 distance culler — the engine will not draw them anyway, so there is no reason
 to tick their logic either.

| Technique | Targets | Typical gain |
| --- | --- | --- |
| Object pooling | Frequently spawned/destroyed nodes | Eliminates allocation spikes |
| Static typing + @onready cache | All GDScript | 2–5× property-access speed |
| Per-frame throttling | AI, sensor, distance checks | N× CPU reduction (N = interval) |
| MultiMeshInstance2D | 100+ identical visual objects | Collapses N draw calls to 1 |
| Visibility culling | Off-screen entities | Proportional to off-screen ratio |

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Throttled AI update

Write an `Enemy` script that has two parts: (1) a
 `_move()` function that runs every physics frame, and (2) an
 `_think()` function that runs only every 8 physics frames.
 Offset each enemy's starting counter by its `get_index()` value
 to stagger updates across frames. Print a message in `_think()`
 to confirm it fires at the correct rate.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const THINK_INTERVAL: int = 8
var _counter: int = 0

func _ready() -> void:
    _counter = get_index() % THINK_INTERVAL

func _physics_process(delta: float) -> void:
    _move(delta)
    _counter += 1
    if _counter >= THINK_INTERVAL:
        _counter = 0
        _think()

func _move(delta: float) -> void:
    # Move toward player — placeholder
    pass

func _think() -> void:
    print("Enemy %d thinking at frame %d" % [get_index(), Engine.get_physics_frames()])
```
::::
:::

:::problem{difficulty="easy"}
### P2 · VisibleOnScreenNotifier2D cull

Create an `Obstacle` scene (StaticBody2D with a sprite and
 animation). Add a `VisibleOnScreenNotifier2D` child. Connect its
 `screen_entered` and `screen_exited` signals to start
 and stop the AnimationPlayer. Verify in the Monitors that
 `TIME_PROCESS` decreases when obstacles scroll off screen.

::::solution[Solution]
```gdscript
extends StaticBody2D

@onready var anim:     AnimationPlayer           = $AnimationPlayer
@onready var notifier: VisibleOnScreenNotifier2D = $VisibleOnScreenNotifier2D

func _ready() -> void:
    notifier.screen_entered.connect(_on_visible)
    notifier.screen_exited.connect(_on_hidden)
    anim.stop()   # start idle

func _on_visible() -> void:
    anim.play("idle")

func _on_hidden() -> void:
    anim.stop()
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Simple bullet pool

Using the `NodePool` class from Section 2, create a
 `Pools` autoload that pre-warms 32 bullet instances.
 Write a `BulletSpawner` node that fires a bullet every 0.1 seconds
 from the spacebar using the pool. The bullet travels upward at 400 px/s and
 releases itself back to the pool after travelling 600 px or hitting a wall
 (use a screen boundary Area2D).

::::solution[Solution]
```gdscript
# Bullet.gd
extends Area2D

var velocity: Vector2 = Vector2.UP * 400.0
var _start_y: float   = 0.0

func on_acquired() -> void:
    $CollisionShape2D.disabled = false
    _start_y = global_position.y

func on_released() -> void:
    $CollisionShape2D.disabled = true

func _physics_process(delta: float) -> void:
    global_position += velocity * delta
    if abs(global_position.y - _start_y) > 600.0:
        get_meta("_pool_ref").release(self)

func _on_body_entered(_body: Node) -> void:
    get_meta("_pool_ref").release(self)

# BulletSpawner.gd
extends Node2D

var _cooldown: float = 0.0

func _physics_process(delta: float) -> void:
    _cooldown -= delta
    if Input.is_action_pressed("ui_accept") and _cooldown <= 0.0:
        _cooldown = 0.1
        var b := Pools.bullets.acquire()
        if b:
            b.global_position = global_position
```
::::
:::

:::problem{difficulty="standard"}
### P4 · MultiMeshInstance2D coin scatter

Place a `MultiMeshInstance2D` in a scene and write a script that:

1. Creates a `MultiMesh` with 200 instances using a
 `QuadMesh` of size `Vector2(8, 8)`.
2. Scatters each instance at a random position within a 800×600 area.
3. Assigns each instance a random yellow-to-gold colour
 (`Color(1.0, randf_range(0.6, 1.0), 0.0)`).
4. Each frame, bobs each instance up and down with
 `sin(time + i)`.

::::solution[Solution]
```gdscript
extends MultiMeshInstance2D

var _time: float = 0.0
var _base_y: PackedFloat32Array

func _ready() -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_2D
    mm.use_colors       = true
    mm.instance_count   = 200
    var q := QuadMesh.new(); q.size = Vector2(8, 8)
    mm.mesh = q
    multimesh = mm

    _base_y.resize(200)
    for i in 200:
        var x := randf_range(0, 800)
        var y := randf_range(0, 600)
        _base_y[i] = y
        var xf := Transform2D(0.0, Vector2(x, y))
        mm.set_instance_transform_2d(i, xf)
        mm.set_instance_color(i, Color(1.0, randf_range(0.6, 1.0), 0.0))

func _process(delta: float) -> void:
    _time += delta
    var mm := multimesh
    for i in mm.instance_count:
        var xf := mm.get_instance_transform_2d(i)
        xf.origin.y = _base_y[i] + sin(_time + i) * 4.0
        mm.set_instance_transform_2d(i, xf)
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Dictionary-based membership

You have a list of 10,000 item IDs (strings) in an Array, and you need to
 check membership 10,000 times per frame. Write two versions:

1. `check_with_array(items: Array, queries: Array) -> int` — uses
 `Array.has()`.
2. `check_with_dict(items: Array, queries: Array) -> int` — converts
 the Array to a Dictionary first, then uses `Dictionary.has()`.

Both return the count of matched queries. Use
 `Time.get_ticks_usec()` to measure each approach and print the
 difference. Confirm the Dictionary version is significantly faster.

::::solution[Solution]
```gdscript
func check_with_array(items: Array, queries: Array) -> int:
    var count := 0
    for q in queries:
        if items.has(q):
            count += 1
    return count

func check_with_dict(items: Array, queries: Array) -> int:
    var lookup := {}
    for item in items:
        lookup[item] = true
    var count := 0
    for q in queries:
        if lookup.has(q):
            count += 1
    return count

func _ready() -> void:
    var items   : Array = []
    var queries : Array = []
    for i in 10000:
        items.append("item_%d" % i)
        queries.append("item_%d" % randi_range(0, 9999))

    var t0 := Time.get_ticks_usec()
    var r1 := check_with_array(items, queries)
    var t1 := Time.get_ticks_usec()
    var r2 := check_with_dict(items, queries)
    var t2 := Time.get_ticks_usec()

    print("Array: %d µs  (matches: %d)" % [t1 - t0, r1])
    print("Dict:  %d µs  (matches: %d)" % [t2 - t1, r2])
    # Expect Dict to be ~100× faster
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Typed generic pool + performance comparison

Build a complete pooling benchmark that proves the performance benefit:

1. Create a simple `Coin.tscn` (Area2D + Sprite2D + script with
 `on_acquired` / `on_released` hooks).
2. Mode A (*no pool*): each frame, free all active coins and
 instantiate 50 new ones at random positions.
3. Mode B (*pooled*): use `NodePool` to acquire 50 coins
 and release them each frame.
4. Toggle between modes with Space and display the current FPS
 and active node count in a Label.
5. Add a custom Performance monitor `"Game/Coins Active"` that
 returns the active coin count.

::::solution[Solution]
```gdscript
# BenchmarkScene.gd
extends Node2D

const COIN_SCENE := preload("res://scenes/coin.tscn")
const BATCH_SIZE := 50

@onready var info_label: Label = $InfoLabel

var _use_pool: bool  = false
var _pool:     NodePool = null
var _no_pool_coins: Array[Node] = []

func _ready() -> void:
    _pool = NodePool.new(COIN_SCENE, self, BATCH_SIZE * 2)
    Performance.add_custom_monitor("Game/Coins Active", _count_active)

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and event.keycode == KEY_SPACE:
        _use_pool = not _use_pool
        print("Mode: ", "POOL" if _use_pool else "NO POOL")

func _process(_delta: float) -> void:
    if _use_pool:
        _pool.release_all()
        for _i in BATCH_SIZE:
            var c := _pool.acquire()
            if c:
                c.global_position = Vector2(randf_range(0,1280), randf_range(0,720))
    else:
        for c in _no_pool_coins:
            c.queue_free()
        _no_pool_coins.clear()
        for _i in BATCH_SIZE:
            var c := COIN_SCENE.instantiate()
            add_child(c)
            c.global_position = Vector2(randf_range(0,1280), randf_range(0,720))
            _no_pool_coins.append(c)

    info_label.text = "Mode: %s  FPS: %d  Nodes: %d" % [
        "POOL" if _use_pool else "ALLOC",
        int(Performance.get_monitor(Performance.TIME_FPS)),
        int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
    ]

func _count_active() -> int:
    return _pool.active_count() if _use_pool else _no_pool_coins.size()
```
::::
:::
