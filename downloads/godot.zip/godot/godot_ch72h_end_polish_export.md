---
title: "Crowd Runner — End Battle, Polish, ConfigFile Save & Android Export"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72H"
meta:
  - "Est. study time: ~90 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72h_end_polish_export.html"
---

## Overview

Final chapter. The game already loops end-to-end but has no *ending* — the run
 just cuts off at 400 m with a whimper. We add the enemy wall, the mini-brawl slowdown +
 particle spam, and every remaining polish pass. Then we sign an Android APK, install it
 on a physical phone, and verify 60 fps performance.

:::callout-key[What you'll build in this chapter]
EnemyWall.tscn with a Label3D showing enemy count. Mini-brawl resolution (crowd vs
 enemies math, slowdown, particle burst, win/lose signal). GPUParticles3D bursts on gate
 hits and obstacle contacts. CameraRig.shake wired to obstacle\_hit and battle events.
 AudioBuses (SFX + Music). WorldEnvironment final polish. Android SDK/JDK/Keystore setup.
 Export preset with icon, portrait lock. Physical device install via ADB. Final
 verification at 60 fps.
:::

### Prerequisites

- Ch 72G — full game loop with menus and HUD works.
- Familiarity with GPUParticles3D (Ch 34) and AudioStreamPlayer (Ch 43).
- A physical Android device with USB debugging enabled — or an emulator.
- Java JDK 17+ and Android SDK Command-Line Tools installed. If not, follow the setup
 section below carefully; this is the first-time-only step that eats an hour if you skip
 it.

:::callout-connect[Reference checklist]
**Ch 34** (GPUParticles3D), **Ch 43/44** (Audio buses &
 effects), **Ch 63** (Export templates and platform setup),
 **Ch 64** (polish & game feel).
:::

## 1. EnemyWall Scene

1. New Scene. Root = **Area3D**, rename **EnemyWall**. Save
 `res://scenes/world/EnemyWall.tscn`.
2. Collision Layer = *5 (EnemyWall)*. Mask = clear.
3. Add child CollisionShape3D: BoxShape3D `(8, 3, 0.4)` (spans all three lanes),
 Position Y = 1.5.
4. Add child MeshInstance3D: BoxMesh `(8, 3, 0.4)`, Position Y = 1.5.
 StandardMaterial3D: *Albedo* `#7a2222` (dark blood-red),
 *Emission* enabled, *Emission Color* `#c14a3f`, *Emission
 Energy* 0.4.
5. Add child Label3D: text `×000` (placeholder), font size 128, pixel size
 0.012, billboard on, position (0, 4, 0), outline size 20.
6. Attach script `res://scenes/world/EnemyWall.gd`:

```gdscript
# res://scenes/world/EnemyWall.gd
class_name EnemyWall
extends Area3D

@export var enemy_count : int = 30 :
    set(v):
        enemy_count = v
        if is_inside_tree():
            $Label3D.text = "×%d" % v

@onready var label : Label3D = $Label3D

func _ready() -> void:
    label.text = "×%d" % enemy_count
    area_entered.connect(_on_area_entered)

func _on_area_entered(area: Area3D) -> void:
    if area.name != "HitSensor":
        return
    var runner : Runner = area.get_parent() as Runner
    var cm : CrowdManager = runner.get_node("CrowdMulti") as CrowdManager
    var crowd_size : int = cm.count
    # Start the mini-brawl. Actual math resolved after slowdown.
    Engine.time_scale = 0.35
    var timer := get_tree().create_timer(1.5 * 0.35)  # 1.5 s real, at half speed
    await timer.timeout
    Engine.time_scale = 1.0
    var won : bool = crowd_size > enemy_count
    var dist : int = int(absf(runner.global_position.z))
    EventBus.run_finished.emit(won, dist)
    queue_free()
```

## 2. Mini-Brawl Resolution & Spawn Hookup

LevelSpawner emits `run_finalizing` at 400 m. Main should listen and instance
 an EnemyWall at the next spawn Z, with an enemy count that's roughly what the player has
 accumulated.

1. Update Main.gd to add the finalizing handler:

```gdscript
# res://scenes/main/Main.gd — Ch 72H additions
extends Node3D

const ENEMY_WALL := preload("res://scenes/world/EnemyWall.tscn")

@onready var runner : Runner = $Runner
@onready var world  : Node3D = $WorldContainer
@onready var crowd  : CrowdManager = runner.get_node("CrowdMulti")

func _ready() -> void:
    EventBus.crowd_changed.connect(_on_crowd_changed)
    EventBus.run_finalizing.connect(_on_run_finalizing)
    EventBus.run_started.emit()

func _on_crowd_changed(new_count: int, _delta: int) -> void:
    if new_count <= 0:
        var dist := int(absf(runner.global_position.z))
        EventBus.run_finished.emit(false, dist)

func _on_run_finalizing() -> void:
    var wall := ENEMY_WALL.instantiate() as EnemyWall
    world.add_child(wall)
    # Enemy count = current crowd × difficulty factor. Fair for average play.
    wall.enemy_count = maxi(10, int(crowd.count * 1.15))
    wall.global_position = Vector3(0.0, 0.0, runner.global_position.z - 25.0)
```

:::callout-intuition[Why crowd × 1.15]
Slightly harder than the current crowd — you need to have played the last 100 m
 efficiently (avoiding damage, hitting positive gates) to win. If we used exact parity
 (1.0×) the game always ties. If we used 1.5× or higher it feels punitive. 1.15× is the
 “you can just barely do it if you played well” sweet spot.
:::

## 3. GPUParticles3D on Gates & Obstacles

A gate/obstacle hit is a good place for a particle burst — it sells the impact. Add a
 one-shot GPUParticles3D to each scene, played from the script the moment the trigger
 fires. Kept simple: 20 particles, 0.4 s lifetime, gate colour tint.

1. Open `Gate.tscn` (technically GateBase.tscn). Add child
 **GPUParticles3D** named *HitBurst*. Position Y = 1.5.
2. Configure HitBurst:

   - *Emitting* = *off* (we'll fire on demand).
   - *Amount* = `20`.
   - *Lifetime* = `0.4`.
   - *One Shot* = *on*.
   - *Explosiveness* = `1.0`.
   - *Process Material* → *New ParticleProcessMaterial*.

     - *Emission Shape* = *Sphere*, radius 0.6.
     - *Direction* = `(0, 1, 0)`, *Spread* = 180°.
     - *Initial Velocity* min 2.0, max 6.0.
     - *Gravity* = `(0, -4, 0)`.
     - *Color* = white (tinted per instance from Gate.gd).

   - *Draw Passes* → set count 1, *Pass 1 → New SphereMesh*, radius 0.06,
    rings/subdivisions 4 (low-poly). Material Override on the mesh:
    StandardMaterial3D unlit, emission on, energy 1.5.

3. In Gate.gd, in `_on_area_entered` just before `queue_free`:

```gdscript
$HitBurst.emitting = true
# Detach the burst so it survives queue_free of the Gate.
var burst : GPUParticles3D = $HitBurst
remove_child(burst)
get_tree().current_scene.add_child(burst)
burst.global_position = global_position + Vector3(0, 1.5, 0)
burst.finished.connect(burst.queue_free)
```

:::callout-tip[Detach then attach elsewhere]
If we *queue\_free* the Gate while its GPUParticles3D child is still emitting,
 the burst disappears mid-play. Re-parenting the burst to *current\_scene* lets it
 finish its lifetime, then `burst.finished` fires and it frees itself. Same
 pattern for WallObstacle. Saw doesn't need this (no queue\_free on trigger).
:::

## 4. Camera Shake + SFX Buses

### Camera shake

CameraRig.gd already has a `shake(amount)` method from Ch 72B. Wire it now:

```gdscript
# In CameraRig.gd _ready():
EventBus.obstacle_hit.connect(_on_obstacle_hit)

func _on_obstacle_hit(damage: int) -> void:
    # Amount scales with damage, capped so a 20-damage wall doesn't nuke the screen.
    shake(minf(float(damage) * 0.03, 0.35))
```

### Audio buses

1. Open the **Audio** tab at the bottom of the editor.
2. Beside the default Master bus, click *+ Add Bus* twice to create **SFX**
 and **Music**.
3. Send both to *Master*.
4. Set Music volume to `-8 dB` (subtly quieter than SFX by default).

### SFX playback pattern

Add an autoload for one-shot SFX to avoid re-instantiating players:

```gdscript
# res://autoloads/SFX.gd (autoload as "SFX")
extends Node

@onready var _players : Array[AudioStreamPlayer] = []
const POOL_SIZE := 8

func _ready() -> void:
    for i in POOL_SIZE:
        var p := AudioStreamPlayer.new()
        p.bus = "SFX"
        add_child(p)
        _players.append(p)

func play(stream: AudioStream, volume_db: float = 0.0) -> void:
    for p in _players:
        if not p.playing:
            p.stream = stream
            p.volume_db = volume_db
            p.play()
            return
```

Register in Project Settings → Autoload as `SFX`. Then in Gate.gd:

```gdscript
const GATE_SFX := preload("res://assets/audio/gate_ding.ogg")
# in _on_area_entered:
SFX.play(GATE_SFX, -4.0)
```

:::callout-tip[Free SFX sources]
Use freesound.org (CC0/CC-BY) or generate with sfxr / bfxr for tiny 8-bit hits. Three
 files needed: *gate\_ding.ogg*, *obstacle\_thud.ogg*, *battle\_roar.ogg*.
 Keep them under 100 KB each — mobile has no love for huge audio files.
:::

## 5. Environment Polish

Tuning the WorldEnvironment glow and tonemap makes the whole game look 30 % more
 finished for zero code. Small dial-in adjustments in the Environment resource on Main:

| Property | Ch 72B value | Ch 72H value |
| --- | --- | --- |
| Glow → Intensity | 0.6 | **0.9** |
| Glow → Bloom | 0.05 | **0.10** |
| Glow → HDR Threshold | 1.0 | **0.85** |
| Tonemap → Exposure | 1.0 | **1.10** |
| Ambient → Sky Contribution | 0.5 | **0.4** |
| Ambient → Energy | 1.0 | **1.1** |

:::callout-warning[Watch the framerate after each glow tweak]
Glow is one of the more expensive Mobile-renderer effects. On some mid-range phones
 raising intensity above ~1.2 measurably drops fps. If your target device hits < 60 fps
 after these settings, back off glow before disabling any other feature.
:::

## 6. Android SDK & JDK Setup (First-Time Only)

Skip this section if you've already exported an Android APK from another Godot 4
 project — the setup is one-per-machine, not one-per-project.

1. **Install Java JDK 17.** Download from Adoptium (Temurin JDK 17 LTS).
 Install to a path with no spaces (e.g. `C:\jdk-17`). Set the
 `JAVA_HOME` environment variable to that path.
2. **Download Android SDK Command-Line Tools.** From
 developer.android.com/studio → “Command line tools only” → download for your
 OS. Unzip so the layout becomes
 `C:\android-sdk\cmdline-tools\latest\bin\sdkmanager(.bat)`. The
 `latest` folder name is required.
3. **Install the required SDK packages** via sdkmanager:

 Accept licenses: `sdkmanager --licenses`, type *y* repeatedly.

   ```
   sdkmanager "platform-tools" "build-tools;34.0.0" "platforms;android-34" "cmdline-tools;latest"
   ```

4. **Set Godot editor settings:** Godot → Editor → Editor Settings →
 Export → Android:

   - Android SDK Path = `C:\android-sdk`
   - Java SDK Path = `C:\jdk-17`

5. **Generate a debug keystore** (Godot installs an auto one, but if the
 Editor Settings show it missing, run):

 Set that path as the Debug Keystore in Editor Settings.

   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999
   ```

6. **Install Android export templates** in Godot: Editor → Manage Export
 Templates → Download and Install for your Godot 4.6 version.

:::callout-warning[If you skip step 3 licenses]
Export will fail with “License for package Android SDK Build-Tools not accepted.”
 Re-run `sdkmanager --licenses` and answer *y* to every prompt.
:::

## 7. Export Preset & Icon

1. Godot → Project → Export → *Add…* → Android. Name the preset *Android Debug*.
2. In the preset options:

   - **Options → Screen → Orientation** = `Portrait`. Critical.
   - **Options → Screen → Immersive Mode** = *on*.
   - **Options → Package → Unique Name** = `com.yourname.zergmarch`.
    Use your actual reverse-DNS; needs to be globally unique on Play Store.
   - **Options → Package → Name** = `Zerg March` (this is the app
    label the OS shows).
   - **Options → Launcher Icons → Main 192×192** = pick your icon PNG.
    Godot resamples down for the smaller densities.
   - **Options → Architecture** = `arm64-v8a` only for release.
    Debug builds can include armeabi-v7a for older devices; drop it for release APK
    size.
   - **Options → Rendering → Rendering Method** = `mobile`
    (should be auto-detected from project settings).

3. Save the preset. Do *not* tick “Runnable” unless you want the
 Play-with-Device button to use this preset automatically.

:::callout-tip[Icon PNG size]
Provide a 192×192 (or larger, square) transparent PNG. Something readable at 48×48 is
 what actually lands on the launcher grid. For Zerg March, an orange capsule silhouette
 with a small teal ring around it is enough and takes 5 minutes in any paint app.
:::

## 8. Deploy to a Physical Device

1. On the phone: *Settings → About Phone*, tap *Build Number* seven times
 to unlock Developer Options. Then *Developer Options → USB Debugging* = on.
2. Plug the phone into USB. Approve the fingerprint prompt.
3. Confirm the device appears: in a terminal

 should list one device with status *device*. (adb is in
 `C:\android-sdk\platform-tools\`.)

   ```
   adb devices
   ```

4. In Godot, click the little *Android* icon in the top-right of the editor →
 it should now show your device name. Click it and Godot builds + installs + launches the
 APK in one step.
5. Alternatively export a bundle:
 *Project → Export → Export Project…* → save as
 `res://export/zergmarch-debug.apk`. Then

   ```
   adb install -r export/zergmarch-debug.apk
   ```

:::callout-warning[Common ADB errors]
- *“device unauthorized”* — you didn't approve the fingerprint on
 the phone yet. Unlock the screen and approve.
- *“INSTALL\_FAILED\_UPDATE\_INCOMPATIBLE”* — you signed with a
 different keystore than the installed version. Uninstall the old one first:
 `adb uninstall com.yourname.zergmarch`.
:::

## 9. Final Verification Checklist

Run the APK on your device and confirm every one of these:

- Launches directly into MainMenu — portrait orientation locked (rotate the phone;
 screen stays portrait)
- PLAY starts a fresh run — HUD visible, first gate appears within 12 m
- Swipe left/right on the physical touchscreen changes lanes reliably
- Crowd count bounces green on gains, red on losses; number tween is snappy
- Gate hit fires particle burst; obstacle hit shakes camera + plays thud SFX
- Reach 400 m → enemy wall appears with an enemy count
- Mini-brawl slowdown fires; result screen shows win or loss with correct distance
- High score persists across app close and reopen
- Frame rate reads 60 fps in Godot's remote profiler (or your phone's dev overlay)
 with 100+ crowd members on screen
- APK size < 25 MB (mobile-tier renderer + minimal assets)
- No red errors in `adb logcat`

:::callout-key[You shipped it]
If every item ticks, you have a signed portrait Android game running on a phone with
 the full crowd-runner mechanic, custom art (colored capsules count), procedural levels,
 juicy UI, an end-of-run battle, high-score persistence, and a portable APK. Sideload it
 to friends; submit to Google Play Internal Testing; or record a 60-second gameplay clip
 and post it to itch.io. This is the “shitty mobile game” slot done properly.
:::

:::summary
## Summary — Ch 72 Complete

All eight build chapters done. Zerg March is a full crowd-runner mobile game:
 Mobile renderer portrait Android target; recycling ground with chase Camera3D; leader
 CharacterBody3D with swipe/keyboard steering; 250-follower MultiMeshInstance3D crowd in
 1 draw call; Area3D gates and obstacles with EventBus signalling; procedural LevelSpawner
 with distance-based difficulty ramp; portrait Control HUD with juicy tweens; main /
 pause / game-over menus with ConfigFile-persisted high score; end-of-run enemy-wall
 mini-brawl; GPUParticles3D + camera shake + pooled SFX; and signed APK deployment to
 a real phone at 60 fps.

**Whole series wired to**
 the reference chapters in Parts I–XII of the Godot 4.6 textbook —
 [back to the index](./godot_index.html) to pick your next walkthrough
 (Ch 73 Balatro Clone, Ch 74 Music Visualizer, or Ch 76 Roguelike Pool).
:::
