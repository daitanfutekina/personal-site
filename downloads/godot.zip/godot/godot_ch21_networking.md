---
title: "Networking — Multiplayer, RPCs & Synchronisation"
source: "godot_ch21_networking.html"
---

Part III · Chapter 21

# Networking — Multiplayer, RPCs & Synchronisation

Prerequisite: Chapters 3 (Scene tree) and 12 (Autoloads) · est. 110 min

## Overview

Godot 4's high-level multiplayer API is built on a **peer-to-peer with authority model**.
 One peer is designated the *authority* (usually the server/host) — it owns simulation.
 All other peers are clients that send inputs and receive state updates. The system composes
 naturally with the scene tree: every node has a `multiplayer_authority`, and RPCs
 can target specific peers or broadcast to all.

The stack from bottom to top:

- **MultiplayerPeer** — transport layer: ENet (UDP, LAN/internet), WebSocket (browser/web exports), or Steam.
- **MultiplayerAPI** — the RPC dispatcher; handles peer IDs and routing.
- **@rpc annotations** — mark GDScript functions as remotely callable.
- **MultiplayerSpawner / MultiplayerSynchronizer** — high-level nodes that automate spawning and property sync.

## 1 · Network Setup

### 1.1 · ENetMultiplayerPeer (UDP — recommended for games)

```gdscript

# Autoload: NetworkManager.gd
extends Node

const PORT    := 7777
const MAX_PEERS := 4

func host_game() -> void:
    var peer := ENetMultiplayerPeer.new()
    var err  := peer.create_server(PORT, MAX_PEERS)
    if err != OK:
        push_error("Failed to host: %s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    print("Hosting on port %d" % PORT)

func join_game(address: String = "127.0.0.1") -> void:
    var peer := ENetMultiplayerPeer.new()
    var err  := peer.create_client(address, PORT)
    if err != OK:
        push_error("Failed to connect: %s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    print("Connecting to %s:%d…" % [address, PORT])

func disconnect_from_game() -> void:
    multiplayer.multiplayer_peer = null
```

### 1.2 · WebSocketMultiplayerPeer (browser exports)

```gdscript

# Server (dedicated or host peer)
func host_ws() -> void:
    var peer := WebSocketMultiplayerPeer.new()
    peer.create_server(PORT)
    multiplayer.multiplayer_peer = peer

# Client
func join_ws(url: String = "ws://127.0.0.1:7777") -> void:
    var peer := WebSocketMultiplayerPeer.new()
    peer.create_client(url)
    multiplayer.multiplayer_peer = peer
```

### 1.3 · Connection signals

```gdscript

func _ready() -> void:
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)

func _on_peer_connected(id: int) -> void:
    print("[Server] Peer %d joined" % id)

func _on_peer_disconnected(id: int) -> void:
    print("[Server/Client] Peer %d left" % id)

func _on_connected_to_server() -> void:
    print("[Client] Connected! My ID: %d" % multiplayer.get_unique_id())

func _on_connection_failed() -> void:
    push_error("Connection failed")

func _on_server_disconnected() -> void:
    print("[Client] Server closed connection")
    get_tree().change_scene_to_file("res://ui/main_menu.tscn")
```

:::callout-key
🔑 Peer ID 1 = server

The server always has peer ID

1

.  Clients receive a unique integer ID assigned
        by the server upon connection.

multiplayer.get\_unique\_id()

returns your own ID.

multiplayer.is\_server()

returns

true

only on the host.
:::

## 2 · Remote Procedure Calls (RPCs)

### 2.1 · @rpc annotations

Add `@rpc` before a function to make it remotely callable. Call the function
 normally on the sender, and the network will execute it on the receivers. Use
 `.rpc()` to call on all peers, or `.rpc_id(peer_id)` to target one:

```gdscript

extends Node

# Simple broadcast — callable by any peer, runs on all
@rpc("any_peer", "call_local", "reliable")
func chat_message(text: String) -> void:
    print("[Chat] %s" % text)

# Call from any peer — runs on ALL peers including yourself
func send_chat(text: String) -> void:
    chat_message.rpc(text)

# Only authority → all (server → clients)
@rpc("authority", "call_remote", "unreliable")
func sync_health(hp: int) -> void:
    health = hp
    $HealthBar.value = hp

# Call from the server on a specific client
func send_health_to(peer_id: int, hp: int) -> void:
    sync_health.rpc_id(peer_id, hp)
```

### 2.2 · @rpc mode arguments

| Argument 1 (who can call) | Meaning |
| --- | --- |
| `"any_peer"` | Any connected peer may invoke this RPC |
| `"authority"` | Only the node's authority (default: server) may invoke it |

| Argument 2 (local execution) | Meaning |
| --- | --- |
| `"call_local"` | Also execute locally on the caller |
| `"call_remote"` | Execute only on the remote peer(s) — not on the caller |

| Argument 3 (reliability) | Meaning |
| --- | --- |
| `"reliable"` | Guaranteed delivery, in-order (like TCP) — use for events |
| `"unreliable"` | Best-effort, may be dropped or reordered — use for position updates |
| `"unreliable_ordered"` | May be dropped but never reordered — good for state snapshots |

### 2.3 · Authority model in practice

```gdscript

extends CharacterBody2D

# Called on the client that owns this player
func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority():
        return   # non-authority peers don't process input
    # Read input and move locally
    velocity = Input.get_vector("move_left","move_right","move_up","move_down") * 200.0
    move_and_slide()
    # Broadcast position to all peers (unreliable — position is sent every frame)
    _sync_position.rpc(global_position)

@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_position(pos: Vector2) -> void:
    global_position = pos   # non-authority peers update from network
```

:::callout-pitfall
🔴 Never trust clients on the server

Always validate RPC inputs on the server.  A client calling

set\_health.rpc\_id(1, 9999)

with cheated values should be caught server-side.  Use

multiplayer.get\_remote\_sender\_id()

inside an

@rpc

function to know which peer called it.
:::

## 3 · High-Level Multiplayer Nodes

### 3.1 · MultiplayerSpawner

`MultiplayerSpawner` automatically replicates scene instantiation to all peers.
 When the authority spawns a node locally, the Spawner sends a message to all clients who
 instantiate the same scene in the same tree location.

```gdscript

# Scene tree setup:
# World
#   ├─ MultiplayerSpawner   (spawn_path = "World", auto_spawn_list includes player.tscn)
#   └─ Players/             (spawned players land here)

# On the server only — the Spawner handles replication to clients automatically
func spawn_player(peer_id: int) -> void:
    if not multiplayer.is_server():
        return
    var player := preload("res://player/player.tscn").instantiate()
    player.name = str(peer_id)            # name must be unique and identical on all peers
    player.set_multiplayer_authority(peer_id)   # owner = the client with this ID
    $Players.add_child(player, true)      # true = use scene unique names (required by spawner)
```

Configure the `MultiplayerSpawner` in the inspector:

- **Spawn Path** — the node where children are added (e.g. `$Players`).
- **Auto Spawn List** — add each `PackedScene` the spawner should replicate.

### 3.2 · MultiplayerSynchronizer

`MultiplayerSynchronizer` replicates node properties to all peers automatically
 at a configurable rate. Add one as a child of any node, configure which properties to sync,
 and Godot handles the serialisation:

```gdscript

# Scene tree:
# Player
#   ├─ MultiplayerSynchronizer   (replication_config includes position, health)
#   └─ Sprite2D

# In the inspector on MultiplayerSynchronizer:
# Root Path = ..   (relative to itself → the Player node)
# Add Property: position       (synced every frame from authority)
# Add Property: health         (synced on change)
# Replication Interval = 0.05  (20 Hz position sync)

# In Player.gd — the synchronizer handles replication, no extra code needed:
extends CharacterBody2D

var health: int = 100

func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority():
        return   # non-authority reads replicated values
    velocity = Input.get_vector("move_left","move_right","move_up","move_down") * 200.0
    move_and_slide()
```

:::callout-tip
💡 Visibility filter

MultiplayerSynchronizer

has a

visibility filter

— you can
        restrict which peers receive updates.  Set a callable on

synchronizer.visibility\_filter

that returns

true

for peers that
        should receive data (e.g. only peers near the player in a large open world).
:::

## 4 · Lobby Pattern

### 4.1 · Host / join flow

A clean multiplayer lobby pattern:

1. Host calls `peer.create_server()` and loads the lobby scene.
2. Each client calls `peer.create_client()`.
3. Server's `peer_connected` fires — server sends lobby data to the new peer via RPC.
4. Client calls an RPC to register their player name / ready state with the server.
5. When all players are ready, server calls a **scene change RPC** to move everyone to the game scene.

```gdscript

# LobbyManager.gd (Autoload)
extends Node

var players: Dictionary = {}   # peer_id → {name, ready}

func _ready() -> void:
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)

func _on_peer_connected(id: int) -> void:
    if multiplayer.is_server():
        # Send existing players to the new peer
        for existing_id in players:
            _register_player.rpc_id(id, existing_id, players[existing_id]["name"])
        # Tell everyone about the new peer (placeholder name)
        _register_player.rpc(id, "Player %d" % id)

func _on_peer_disconnected(id: int) -> void:
    players.erase(id)
    player_left.emit(id)

@rpc("authority", "call_local", "reliable")
func _register_player(id: int, player_name: String) -> void:
    players[id] = {"name": player_name, "ready": false}
    player_joined.emit(id, player_name)

@rpc("any_peer", "call_local", "reliable")
func set_ready(is_ready: bool) -> void:
    var sender := multiplayer.get_remote_sender_id()
    if sender == 0:
        sender = multiplayer.get_unique_id()   # local call
    if sender in players:
        players[sender]["ready"] = is_ready
    _check_all_ready()

func _check_all_ready() -> void:
    if not multiplayer.is_server():
        return
    if players.values().all(func(p): return p["ready"]):
        start_game.rpc()

@rpc("authority", "call_local", "reliable")
func start_game() -> void:
    get_tree().change_scene_to_file("res://game/game_world.tscn")

signal player_joined(id: int, name: String)
signal player_left(id: int)
```

### 4.2 · Spawning players after scene change

```gdscript

# GameWorld.gd
extends Node

func _ready() -> void:
    if multiplayer.is_server():
        # Spawn a player for every connected peer (including the server itself)
        for peer_id in multiplayer.get_peers() + [1]:
            _spawn_player(peer_id)
        multiplayer.peer_connected.connect(_spawn_player)

func _spawn_player(peer_id: int) -> void:
    var p := preload("res://player/player.tscn").instantiate()
    p.name = str(peer_id)
    p.set_multiplayer_authority(peer_id)
    $Players.add_child(p, true)
```

## Summary

| Concept | Key takeaway |
| --- | --- |
| **ENetMultiplayerPeer** | UDP transport — best for real-time games; use `create_server()` / `create_client()` |
| **WebSocketMultiplayerPeer** | For browser (HTML5) exports; same API as ENet |
| **Peer ID 1** | Always the server; clients get unique IDs assigned on join |
| **@rpc annotation** | Marks a function remotely callable; call with `.rpc()` or `.rpc_id(peer_id)` |
| **"reliable" / "unreliable"** | Reliable for events; unreliable\_ordered for frequent state (position) |
| **is\_multiplayer\_authority()** | Gate input processing — only the authority should move its character |
| **MultiplayerSpawner** | Auto-replicates add\_child() calls from authority to all peers |
| **MultiplayerSynchronizer** | Auto-replicates listed properties at a configurable interval |
| **get\_remote\_sender\_id()** | Inside an @rpc function — identifies which peer called it (for validation) |

- Never trust client-sent data unconditionally — validate all inputs server-side.
- Use `multiplayer.is_server()` to gate authoritative logic; use `is_multiplayer_authority()` to gate per-node input.
- Name spawned nodes identically on all peers so the tree paths match — use the peer ID as the node name.
- MultiplayerSynchronizer + MultiplayerSpawner handle most state sync; write manual RPCs only for events (shooting, chat).
- Test with two local instances (`--headless` server + normal client) before testing over LAN.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Host / join buttons

Write the signal handlers for a main menu with two buttons: **Host** and
 **Join**. Host creates an ENet server on port 7777 and loads
 `res://lobby/lobby.tscn`. Join connects to `127.0.0.1:7777` and
 loads the same scene on success (`connected_to_server` signal).

::::solution[Solution]
```gdscript

extends Control

const PORT := 7777

func _on_host_pressed() -> void:
    var peer := ENetMultiplayerPeer.new()
    if peer.create_server(PORT, 4) != OK:
        push_error("Failed to host")
        return
    multiplayer.multiplayer_peer = peer
    get_tree().change_scene_to_file("res://lobby/lobby.tscn")

func _on_join_pressed() -> void:
    var peer := ENetMultiplayerPeer.new()
    if peer.create_client("127.0.0.1", PORT) != OK:
        push_error("Failed to connect")
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.connected_to_server.connect(func():
        get_tree().change_scene_to_file("res://lobby/lobby.tscn")
    )
    multiplayer.connection_failed.connect(func():
        push_error("Connection refused")
        multiplayer.multiplayer_peer = null
    )
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Synchronized health bar

A player node has an integer `health` variable. Write an RPC that the
 authority calls to update `health` on all peers. Non-authority peers should
 reflect the new value in a `$HealthBar` ProgressBar. The RPC should be
 reliable so no update is lost.

::::solution[Solution]
```gdscript

extends CharacterBody2D

var health := 100

@rpc("authority", "call_local", "reliable")
func set_health(new_hp: int) -> void:
    health = new_hp
    $HealthBar.value = health

func take_damage(amount: int) -> void:
    if not is_multiplayer_authority():
        return
    health = clampi(health - amount, 0, 100)
    set_health.rpc(health)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Chat system

Build a simple text chat: any peer can call `send_message(text)` which
 broadcasts the message to all peers (including itself). Each peer displays the message
 in a `RichTextLabel` prefixed with the sender's peer ID. Validate that
 messages are not longer than 200 characters.

::::solution[Solution]
```gdscript

extends CanvasLayer

@onready var log_label: RichTextLabel = $ChatLog
@onready var input:     LineEdit      = $ChatInput

func send_message(text: String) -> void:
    if text.length() > 200:
        text = text.left(200)
    _receive_message.rpc(multiplayer.get_unique_id(), text)

@rpc("any_peer", "call_local", "reliable")
func _receive_message(sender_id: int, text: String) -> void:
    # Validate length server-side (clients can call with any length)
    if text.length() > 200:
        return
    log_label.append_text("[%d]: %s\n" % [sender_id, text.xml_escape()])

func _on_send_button_pressed() -> void:
    var msg := input.text.strip_edges()
    if msg.is_empty():
        return
    send_message(msg)
    input.clear()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Authoritative pickup

A coin collectible lives on the server. When any client's player overlaps it, the client
 sends an RPC to the server asking to collect it. The server validates that the coin still
 exists and hasn't been collected by another player first, then awards the score and removes
 the coin from all peers via RPC.

::::solution[Solution]
```gdscript

# Coin.gd (on server — spawned via MultiplayerSpawner)
extends Area2D

var _collected := false

func _on_body_entered(body: Node2D) -> void:
    # Only the authority of the overlapping body should try to collect
    if not body.is_multiplayer_authority():
        return
    request_collect.rpc_id(1, body.name)   # ask the server

@rpc("any_peer", "reliable")
func request_collect(player_name: String) -> void:
    if not multiplayer.is_server():
        return
    if _collected:
        return   # already taken
    _collected = true
    # Award score
    var player: Node = get_tree().current_scene.get_node_or_null("Players/" + player_name)
    if player and player.has_method("add_score"):
        player.add_score(10)
    # Remove from all peers
    _destroy.rpc()

@rpc("authority", "call_local", "reliable")
func _destroy() -> void:
    queue_free()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Latency display

Show each peer's round-trip time (RTT) in a debug overlay. The server pings each
 client every 2 seconds by sending the current `Time.get_ticks_msec()`,
 the client echoes it back, and the server computes the RTT. Display it in a Label.

::::solution[Solution]
```gdscript

# PingManager.gd (Autoload)
extends Node

var _ping_sent_at: Dictionary = {}   # peer_id → ticks_msec
var latencies: Dictionary = {}       # peer_id → rtt_ms

func _ready() -> void:
    if multiplayer.is_server():
        var t := Timer.new()
        t.wait_time = 2.0
        t.timeout.connect(_ping_all)
        add_child(t)
        t.start()

func _ping_all() -> void:
    for id in multiplayer.get_peers():
        _ping_sent_at[id] = Time.get_ticks_msec()
        _ping.rpc_id(id, _ping_sent_at[id])

@rpc("authority", "call_remote", "unreliable")
func _ping(sent_at: int) -> void:
    _pong.rpc_id(1, sent_at)

@rpc("any_peer", "call_remote", "unreliable")
func _pong(sent_at: int) -> void:
    var sender := multiplayer.get_remote_sender_id()
    var rtt    := Time.get_ticks_msec() - sent_at
    latencies[sender] = rtt
    print("Peer %d RTT: %d ms" % [sender, rtt])
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Full 2-player pong prototype

Build a networked 2-player pong game using only RPCs (no MultiplayerSynchronizer).
 Rules:

- Server simulates the ball (authoritative) and broadcasts its position unreliably every frame.
- Each client controls its own paddle — sends paddle Y position to the server reliably when it changes.
- Server validates paddle Y (clamp to screen bounds) and replicates to both clients.
- Server detects goals and resets the ball via a reliable RPC.
- Score is kept on the server and broadcast on each goal.

::::solution[Solution]
```gdscript

# PongServer.gd — runs only on the host (is_server() guard everywhere)
extends Node2D

const BALL_SPEED   := 300.0
const PADDLE_SPEED := 240.0
const SCREEN_H     := 600.0
const SCREEN_W     := 800.0

var ball_pos := Vector2(400, 300)
var ball_vel := Vector2(BALL_SPEED, BALL_SPEED * 0.6)
var score    := Vector2.ZERO          # x = player 1, y = player 2
var paddles  := {1: 300.0, 2: 300.0} # peer_id → y position

func _physics_process(delta: float) -> void:
    if not multiplayer.is_server():
        return
    # Move ball
    ball_pos += ball_vel * delta
    # Bounce top/bottom
    if ball_pos.y < 0 or ball_pos.y > SCREEN_H:
        ball_vel.y = -ball_vel.y
    # Bounce off paddles (simplified)
    if ball_pos.x < 30 and abs(ball_pos.y - paddles[1]) < 40:
        ball_vel.x = abs(ball_vel.x)
    if ball_pos.x > SCREEN_W - 30 and abs(ball_pos.y - paddles[2]) < 40:
        ball_vel.x = -abs(ball_vel.x)
    # Goal detection
    if ball_pos.x < 0:
        score.y += 1
        _goal.rpc(score)
        ball_pos = Vector2(400, 300)
        ball_vel = Vector2(-BALL_SPEED, BALL_SPEED * 0.6)
    elif ball_pos.x > SCREEN_W:
        score.x += 1
        _goal.rpc(score)
        ball_pos = Vector2(400, 300)
        ball_vel = Vector2(BALL_SPEED, BALL_SPEED * 0.6)
    # Broadcast ball
    _sync_ball.rpc(ball_pos)

@rpc("authority", "call_local", "unreliable")
func _sync_ball(pos: Vector2) -> void:
    $Ball.position = pos

@rpc("authority", "call_local", "reliable")
func _goal(new_score: Vector2) -> void:
    $ScoreLabel.text = "%d — %d" % [int(new_score.x), int(new_score.y)]

@rpc("any_peer", "call_remote", "reliable")
func send_paddle_y(y: float) -> void:
    var sender := multiplayer.get_remote_sender_id()
    if sender not in paddles:
        return
    paddles[sender] = clampf(y, 40, SCREEN_H - 40)
    _sync_paddle.rpc(sender, paddles[sender])

@rpc("authority", "call_local", "unreliable")
func _sync_paddle(peer_id: int, y: float) -> void:
    var paddle_node := $Paddles.get_node_or_null(str(peer_id))
    if paddle_node:
        paddle_node.position.y = y
```
::::
:::
