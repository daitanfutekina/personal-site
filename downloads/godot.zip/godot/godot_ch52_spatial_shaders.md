---
title: "Spatial (3D) Shaders — PBR Inputs, Custom Lighting & Screen UV"
source: "godot_ch52_spatial_shaders.html"
---

Part VIII · Chapter 52

# Spatial (3D) Shaders — PBR Inputs, Custom Lighting & Screen UV

Estimated study time: 100 min · Godot 4.6 · GDShader

## Overview

Spatial shaders run on 3D meshes and feed into Godot's physically-based rendering (PBR) pipeline. Instead of writing directly to `COLOR`, you write to a set of **material outputs** — albedo, roughness, metallic, emission, normal — and the engine's lighting model (Filament-based) computes the final pixel colour by combining them with scene lights, reflections, and the environment.

You can intercept and fully override the lighting model too, or blend between the default PBR and a completely custom light calculation.

### Prerequisites

- Ch 50 — GDShader Fundamentals
- Ch 51 — canvas\_item shaders (concepts carry over)
- Basic understanding of 3D transforms (Ch 13)

## Spatial Render Modes

| Mode | Description |
| --- | --- |
| `blend_mix` | Standard alpha blending. Requires `ALPHA` output. |
| `blend_add` | Additive blending (glow, particles). |
| `blend_mul` | Multiplicative blending (darkening overlays). |
| `depth_draw_always` | Always write depth even on transparent materials. |
| `depth_draw_never` | Never write depth (glass, holograms, particles). |
| `depth_prepass_alpha` | Alpha-tested cutout — uses a depth pre-pass for correct shadow casting. |
| `unshaded` | Skip PBR. Fragment outputs go directly to screen. Use for emissive effects. |
| `wireframe` | Render mesh edges only. |
| `cull_back` | **Default.** Back faces are invisible. |
| `cull_front` | Front faces invisible (inverted normals — used for some tricks). |
| `cull_disabled` | Both sides render (two-sided leaves, cloth, cards). |
| `diffuse_lambert` | Use simple Lambertian diffuse model. |
| `diffuse_toon` | Cel-shaded diffuse (hard lighting bands). |
| `specular_toon` | Cel-shaded specular highlight. |
| `specular_disabled` | No specular highlight at all. |
| `skip_vertex_transform` | Disable automatic MVP transform. Compute POSITION yourself. |

## PBR Outputs

These are the writable outputs of the spatial `fragment()` function. Set them to describe the surface properties; the engine's PBR lighting model does the rest.

PBR Material Outputs — Surface Properties

ROUGHNESS = 0

mirror-smooth

ROUGHNESS = 1

fully diffuse

METALLIC = 0

dielectric / plastic

METALLIC = 1

metallic (gold/steel)

PBR material channels. Roughness controls specular blur (0 = mirror, 1 = diffuse). Metallic controls whether reflections are colored by ALBEDO (metallic=1) or white (metallic=0). Real-world materials are either fully metallic or fully dielectric — avoid values between 0.2 and 0.8.

### Albedo, Roughness, Metallic

| Output | Type | Range | Description |
| --- | --- | --- | --- |
| `ALBEDO` | vec3 | 0–1 | Base surface colour in linear space (no lighting applied). |
| `ROUGHNESS` | float | 0–1 | 0 = mirror-smooth, 1 = fully diffuse/rough. |
| `METALLIC` | float | 0–1 | 0 = dielectric (plastic, stone), 1 = metallic (gold, steel). |
| `SPECULAR` | float | 0–1 | Specular intensity for dielectric surfaces. Default 0.5. |
| `ALPHA` | float | 0–1 | Transparency. Requires `render_mode blend_mix`. |
| `ALPHA_SCISSOR_THRESHOLD` | float | 0–1 | Hard alpha cutoff (pixels below are discarded). For foliage/cards. |

```glsl
shader_type spatial;

uniform sampler2D albedo_tex   : filter_linear_mipmap;
uniform sampler2D roughness_tex: filter_linear_mipmap;
uniform float     metallic = 0.0;

void fragment() {
    vec4 col     = texture(albedo_tex,    UV);
    float rough  = texture(roughness_tex, UV).r;

    ALBEDO    = col.rgb;
    ROUGHNESS = rough;
    METALLIC  = metallic;
}
```

### Normal Maps and Ambient Occlusion

| Output | Type | Description |
| --- | --- | --- |
| `NORMAL_MAP` | vec3 | Normal map sample (RGB encodes XYZ). Must also set NORMAL\_MAP\_DEPTH. |
| `NORMAL_MAP_DEPTH` | float | Normal map strength (1.0 = full). Higher values exaggerate the bumps. |
| `NORMAL` | vec3 | Override the surface normal directly (in view space). Advanced — usually prefer NORMAL\_MAP. |
| `AO` | float | Ambient occlusion (0 = occluded/dark, 1 = fully lit). Darkens crevices. |
| `AO_LIGHT_AFFECT` | float | How much AO affects direct lights (0 = only indirect, 1 = both). |

```glsl
uniform sampler2D normal_tex : hint_normal, filter_linear_mipmap;
uniform sampler2D orm_tex    : filter_linear_mipmap; // R=AO, G=Roughness, B=Metallic

void fragment() {
    ALBEDO   = texture(albedo_tex, UV).rgb;
    NORMAL_MAP       = texture(normal_tex, UV).rgb;
    NORMAL_MAP_DEPTH = 1.5;

    vec3 orm = texture(orm_tex, UV).rgb;
    AO        = orm.r;
    ROUGHNESS = orm.g;
    METALLIC  = orm.b;
```

### Emission

Emissive surfaces appear to glow — they add light to themselves regardless of scene lighting. Emission does not actually illuminate other objects (that requires light nodes), but combined with a Bloom post-process it looks convincing.

```glsl
uniform vec3  emission_color : source_color = vec3(0.0, 1.0, 0.8);
uniform float emission_energy = 2.0;

void fragment() {
    ALBEDO   = texture(TEXTURE, UV).rgb;
    EMISSION = emission_color * emission_energy;   // can exceed 1.0
}
```

## Vertex Stage in 3D

The 3D vertex stage has richer built-ins than 2D — you have access to world-space position, normals, tangents, and all transform matrices.

| Built-in | Type | R/W | Description |
| --- | --- | --- | --- |
| `VERTEX` | vec3 | R/W | Vertex position in model space. Write to displace geometry. |
| `NORMAL` | vec3 | R/W | Vertex normal in model space. |
| `TANGENT` | vec3 | R | Tangent vector (for normal mapping). |
| `UV` | vec2 | R/W | Primary UV coordinate. |
| `UV2` | vec2 | R/W | Secondary UV (lightmap, detail map). |
| `COLOR` | vec4 | R | Per-vertex colour from the mesh data. |
| `MODEL_MATRIX` | mat4 | R | Object → world transform. |
| `VIEW_MATRIX` | mat4 | R | World → view (camera) transform. |
| `PROJECTION_MATRIX` | mat4 | R | View → clip space. |
| `MODELVIEW_MATRIX` | mat4 | R | Combined model × view. |
| `POSITION` | vec4 | W | Final clip-space position. Overrides the automatic MVP calculation. |
| `POINT_SIZE` | float | W | Point sprite size in pixels (for point cloud meshes). |

### World-Space Position in the Fragment Stage

To compute world-space effects in `fragment()` (like triplanar mapping), pass the world position from `vertex()` via a varying:

```glsl
shader_type spatial;

varying vec3 world_pos;
varying vec3 world_normal;

void vertex() {
    world_pos    = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
    world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
    // world_pos and world_normal are now available here
    ALBEDO = world_normal * 0.5 + 0.5;   // debug: visualise normals as colour
}
```

## Screen & Depth Textures in 3D

Spatial shaders can sample two screen-space textures. Neither is a built-in: Godot 3 supplied `SCREEN_TEXTURE` and `DEPTH_TEXTURE` as variables and Godot 4 removed both. You declare a `uniform sampler2D` and carry the hint, and the engine binds it — which means the name is yours. The listing below keeps the old names so they are recognisable, but `screen_tex` would work identically:

| Sampler | Hint | Description |
| --- | --- | --- |
| `SCREEN_TEXTURE` | `hint_screen_texture` | The scene rendered before this object. Used for glass, distortion, refraction. |
| `DEPTH_TEXTURE` | `hint_depth_texture` | The scene's depth buffer. Used for soft particles, water edge foaming, intersection effects. |

```glsl
shader_type spatial;
render_mode blend_mix, depth_draw_never, unshaded;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear, repeat_disable;
uniform sampler2D DEPTH_TEXTURE  : hint_depth_texture,  filter_nearest, repeat_disable;

void fragment() {
    // Read depth at this pixel
    float raw_depth = texture(DEPTH_TEXTURE, SCREEN_UV).r;
    // Reconstruct linear depth from raw (0–1) depth
    // (Godot uses a reversed-Z depth buffer in 4.x)
    vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, raw_depth);
    vec4 view = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
    view.xyz /= view.w;
    float linear_depth = -view.z;

    // Example: soft edge foam where water meets the terrain
    float depth_diff = linear_depth - (-VERTEX.z);
    float foam = 1.0 - smoothstep(0.0, 0.5, depth_diff);

    ALBEDO = mix(vec3(0.0, 0.3, 0.8), vec3(1.0), foam);
    ALPHA  = 0.85;
}
```

## Transparency and Alpha Cutout

There are two ways to handle transparency in spatial shaders:

**Alpha blending** — smooth transparency but expensive and has sorting artifacts with other transparent objects:

```glsl
shader_type spatial;
render_mode blend_mix, depth_draw_never, cull_disabled;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

void fragment() {
    vec4 tex = texture(albedo_tex, UV);
    ALBEDO   = tex.rgb;
    ALPHA    = tex.a * 0.7;   // 70% transparent
}
```

**Alpha scissor** — binary cutout (fully opaque or fully transparent, no blending). Writes depth correctly, works well for foliage/fences:

```glsl
shader_type spatial;
render_mode depth_prepass_alpha, cull_disabled;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

void fragment() {
    vec4 tex = texture(albedo_tex, UV);
    ALBEDO = tex.rgb;
    ALPHA_SCISSOR_THRESHOLD = 0.5;   // discard if alpha < 0.5
    ALPHA = tex.a;
}
```

:::callout-pitfall[Pitfall — transparent object sorting]
Alpha-blended objects must be sorted back-to-front for correct rendering. Godot does this automatically per-object but not within a single mesh. For complex transparent geometry (water, glass with internal faces), use `cull_disabled` and sort manually by splitting into front/back sub-meshes, or use the `depth_draw_always` mode and accept the overdraw cost.
:::

## Effect Cookbook — 3D

### Triplanar Mapping

Triplanar mapping samples a texture from three world-axis directions (X, Y, Z) and blends them based on the surface normal — eliminating UV seams on procedural terrain or rocks where traditional UV unwrapping is impractical.

```glsl
shader_type spatial;

uniform sampler2D rock_tex : filter_linear_mipmap, repeat_enable;
uniform float     tile_scale = 0.5;
uniform float     blend_sharpness = 8.0;

varying vec3 world_pos;
varying vec3 world_normal;

void vertex() {
    world_pos    = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
    world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
    // Sample texture from all three axes
    vec4 x_sample = texture(rock_tex, world_pos.zy * tile_scale);
    vec4 y_sample = texture(rock_tex, world_pos.xz * tile_scale);
    vec4 z_sample = texture(rock_tex, world_pos.xy * tile_scale);

    // Blend weights: sharpen the normal to make transitions crisp
    vec3 weights = abs(world_normal);
    weights = pow(weights, vec3(blend_sharpness));
    weights /= (weights.x + weights.y + weights.z);   // normalise

    ALBEDO = (x_sample * weights.x
            + y_sample * weights.y
            + z_sample * weights.z).rgb;
}
```

### Fresnel / Edge Glow

The Fresnel effect makes surfaces more reflective at grazing angles. In game shaders it is commonly used to create a rim/edge glow on characters or force-field effects.

```glsl
shader_type spatial;
render_mode unshaded, blend_add;

uniform vec3  rim_color  : source_color = vec3(0.3, 0.8, 1.0);
uniform float rim_power  : hint_range(0.5, 8.0) = 3.0;
uniform float rim_energy = 2.0;

varying vec3 view_normal;

void vertex() {
    // Normal in view space — points toward camera when surface faces camera
    view_normal = normalize((MODELVIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
    // Fresnel: 1 when facing camera, 0 at edges → invert for rim
    float fresnel = pow(1.0 - max(dot(-view_normal, vec3(0.0, 0.0, 1.0)), 0.0), rim_power);
    EMISSION = rim_color * fresnel * rim_energy;
    ALPHA    = fresnel;
}
```

### 3D Dissolve with Edge Colour

Identical concept to the 2D version, but using a world-space noise for more stable results as the object moves.

```glsl
shader_type spatial;
render_mode cull_disabled;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

uniform sampler2D noise_tex  : filter_linear, repeat_enable;
uniform float     threshold  : hint_range(0.0, 1.0, 0.005) = 0.0;
uniform vec3      edge_color : source_color = vec3(1.0, 0.4, 0.0);
uniform float     edge_width : hint_range(0.0, 0.1)        = 0.03;

varying vec3 world_pos;

void vertex() {
    world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
    // Sample noise in world space so it doesn't swim as object rotates
    float noise = texture(noise_tex, world_pos.xz * 0.5).r;

    if (noise < threshold) discard;

    float edge = smoothstep(threshold, threshold + edge_width, noise);
    ALBEDO     = mix(edge_color, texture(albedo_tex, UV).rgb, edge);
    ROUGHNESS  = 0.8;
}
```

### Stylised Water Surface

A complete stylised water shader: vertex displacement via Gerstner waves, normal-mapped surface for lighting, depth-based colour blending, and edge foam.

```glsl
shader_type spatial;
render_mode blend_mix, depth_draw_never, cull_disabled;

uniform sampler2D DEPTH_TEXTURE  : hint_depth_texture, filter_nearest, repeat_disable;
uniform sampler2D normal_tex     : hint_normal, filter_linear, repeat_enable;

uniform vec3  water_shallow : source_color = vec3(0.15, 0.7, 0.8);
uniform vec3  water_deep    : source_color = vec3(0.05, 0.2, 0.5);
uniform vec3  foam_color    : source_color = vec3(0.9, 0.95, 1.0);
uniform float wave_height   = 0.3;
uniform float wave_speed    = 1.0;
uniform float foam_depth    = 0.5;

varying vec3 v_world_pos;

void vertex() {
    v_world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;

    // Simple Gerstner-ish wave: two sine waves at different angles
    float wave1 = sin(v_world_pos.x * 2.0 + TIME * wave_speed)
                * cos(v_world_pos.z * 1.5 + TIME * wave_speed * 0.7);
    float wave2 = sin(v_world_pos.x * 1.2 - v_world_pos.z + TIME * wave_speed * 1.3)
                * 0.5;
    VERTEX.y += (wave1 + wave2) * wave_height;
}

void fragment() {
    // Scrolling normal map for surface ripple
    vec2 uv1 = UV + vec2(TIME * 0.04, TIME * 0.03);
    vec2 uv2 = UV - vec2(TIME * 0.03, TIME * 0.05) * 0.7;
    vec3 n1 = texture(normal_tex, uv1 * 3.0).rgb;
    vec3 n2 = texture(normal_tex, uv2 * 2.0).rgb;
    NORMAL_MAP       = (n1 + n2) * 0.5;
    NORMAL_MAP_DEPTH = 1.5;

    // Depth-based colour
    float raw_d = texture(DEPTH_TEXTURE, SCREEN_UV).r;
    vec4 ndc    = vec4(SCREEN_UV * 2.0 - 1.0, raw_d, 1.0);
    vec4 view   = INV_PROJECTION_MATRIX * ndc;
    view.xyz   /= view.w;
    float scene_depth = -view.z;
    float frag_depth  = -VERTEX.z;
    float depth_diff  = scene_depth - frag_depth;

    float depth_fade = clamp(depth_diff / 3.0, 0.0, 1.0);
    vec3 water_col   = mix(water_shallow, water_deep, depth_fade);

    // Edge foam
    float foam_mask = 1.0 - smoothstep(0.0, foam_depth, depth_diff);

    ALBEDO    = mix(water_col, foam_color, foam_mask);
    ROUGHNESS = 0.05;
    METALLIC  = 0.0;
    SPECULAR  = 0.9;
    ALPHA     = mix(0.9, 1.0, foam_mask);
}
```

## Practice Problems

:::problem
#### A — Emissive Pulse easy

Write a spatial shader for a mesh that samples its texture into `ALBEDO` and also emits light from itself. The emission colour and base energy should be uniforms. Make the emission pulse between 0 and the full energy value using a sine wave driven by TIME and an adjustable `pulse_speed` uniform.

::::solution[Solution]
```glsl
shader_type spatial;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

uniform vec3  emit_color  : source_color = vec3(0.2, 0.8, 1.0);
uniform float emit_energy = 3.0;
uniform float pulse_speed = 2.0;

void fragment() {
    ALBEDO   = texture(albedo_tex, UV).rgb;
    float p  = sin(TIME * pulse_speed) * 0.5 + 0.5;   // 0→1
    EMISSION = emit_color * emit_energy * p;
}
```
::::
:::

:::problem
#### B — Alpha Cutout Foliage easy

Write a spatial shader for a flat leaf card mesh. Use the texture's alpha to cut out the leaf shape (any pixel with alpha below 0.5 should be discarded). The mesh should render from both sides. Apply a slight wind sway using the vertex stage — oscillate the vertex position on the X and Z axes using TIME and UV.y as a gradient (base of the leaf doesn't move, tip moves the most).

::::solution[Solution]
```glsl
shader_type spatial;
render_mode cull_disabled, depth_prepass_alpha;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

uniform float wind_strength = 0.08;
uniform float wind_speed    = 2.0;

void vertex() {
    float sway = sin(TIME * wind_speed + VERTEX.x * 3.0) * wind_strength * UV.y;
    VERTEX.x  += sway;
    VERTEX.z  += sway * 0.5;
}

void fragment() {
    vec4 tex = texture(albedo_tex, UV);
    ALBEDO = tex.rgb;
    ALPHA  = tex.a;
    ALPHA_SCISSOR_THRESHOLD = 0.5;
    ROUGHNESS = 0.9;
}
```
::::
:::

:::problem
#### C — Holographic Force Field standard

Write a spatial shader for a translucent sphere/shield mesh. Requirements: additive blending (no depth write), Fresnel rim that makes edges brighter, animated scan lines (horizontal stripes that move over time using `VERTEX` or UV.y), and a `source_color` uniform for the shield colour. The shield should be invisible straight-on and glow at the edges.

::::solution[Solution]
```glsl
shader_type spatial;
render_mode blend_add, depth_draw_never, unshaded, cull_disabled;

uniform vec3  shield_color : source_color = vec3(0.0, 0.8, 1.0);
uniform float fresnel_power = 4.0;
uniform float scan_speed    = 0.8;

varying vec3 v_view_normal;
varying vec3 v_world_pos;

void vertex() {
    v_view_normal = normalize((MODELVIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
    v_world_pos   = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
    // Fresnel rim
    float facing  = max(dot(-v_view_normal, vec3(0.0, 0.0, 1.0)), 0.0);
    float fresnel = pow(1.0 - facing, fresnel_power);

    // Animated horizontal scan lines
    float scan = step(0.5, fract(v_world_pos.y * 6.0 + TIME * scan_speed));

    float intensity = fresnel + scan * 0.15;
    EMISSION = shield_color * intensity;
    ALPHA    = intensity * 0.6;
}
```
::::
:::

:::problem
#### D — ORM Texture (Packed Maps) standard

Write a full PBR spatial shader that reads from four textures: `albedo_tex`, `orm_tex` (R=AO, G=Roughness, B=Metallic packed), `normal_tex` (hint\_normal), and optionally an `emission_tex` multiplied by an `emission_energy` uniform. Support a `tiling` uniform that tiles all textures uniformly.

::::solution[Solution]
```glsl
shader_type spatial;

uniform sampler2D albedo_tex    : filter_linear_mipmap;
uniform sampler2D orm_tex       : filter_linear_mipmap;
uniform sampler2D normal_tex    : hint_normal, filter_linear_mipmap;
uniform sampler2D emission_tex  : filter_linear_mipmap;
uniform float     emission_energy = 0.0;
uniform float     tiling          = 1.0;

void fragment() {
    vec2 uv = UV * tiling;

    vec3 alb  = texture(albedo_tex, uv).rgb;
    vec3 orm  = texture(orm_tex,    uv).rgb;

    ALBEDO           = alb;
    AO               = orm.r;
    ROUGHNESS        = orm.g;
    METALLIC         = orm.b;
    NORMAL_MAP       = texture(normal_tex, uv).rgb;
    NORMAL_MAP_DEPTH = 1.0;
    EMISSION         = texture(emission_tex, uv).rgb * emission_energy;
}
```
::::
:::

:::problem
#### E — Soft Particle challenge

Write a spatial shader for particle quads (flat cards). It should: read `DEPTH_TEXTURE`, compute linear depth, and fade out (reduce `ALPHA`) where the particle intersects scene geometry within a configurable `soft_distance`. Also apply additive blending and colour the particle using `COLOR` (the per-particle colour set by the particle system).

::::solution[Solution]
```glsl
shader_type spatial;
render_mode blend_add, depth_draw_never, unshaded, cull_disabled;

// A spatial shader has no TEXTURE built-in; supply the sampler yourself.
uniform sampler2D albedo_tex : source_color, filter_linear;

uniform sampler2D DEPTH_TEXTURE : hint_depth_texture, filter_nearest, repeat_disable;
uniform float soft_distance = 1.0;

void fragment() {
    // Read scene depth and reconstruct linear depth
    float raw    = texture(DEPTH_TEXTURE, SCREEN_UV).r;
    vec4  ndc    = vec4(SCREEN_UV * 2.0 - 1.0, raw, 1.0);
    vec4  view   = INV_PROJECTION_MATRIX * ndc;
    view.xyz    /= view.w;
    float sdepth = -view.z;
    float fdepth = -VERTEX.z;

    float soft = clamp((sdepth - fdepth) / soft_distance, 0.0, 1.0);

    vec4 tex = texture(albedo_tex, UV);
    EMISSION = tex.rgb * COLOR.rgb;
    ALPHA    = tex.a * COLOR.a * soft;
}
```
::::
:::
