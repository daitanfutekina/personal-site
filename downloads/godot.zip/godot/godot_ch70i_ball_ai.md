---
title: "Earclacks — Ball AI & Steering Behaviour"
source: "markdown"
---

## Overview

:::callout-warning[This chapter breaks Law 2 on purpose]
The Earclacks design sheet sets three laws, and the second is *no AI steering — physics determines movement*. Everything through Ch 70H obeys it: the balls are pushed around by collisions and by their equipment, never by a decision. This chapter adds a steering brain, so a build that uses it is no longer the game the design sheet describes. That is why it is optional and why it sits after the finished build rather than inside it. Take it if you want a fight the balls are trying to win; skip it and Ch 70A–H stand on their own.
:::

:::callout-key[KEY CONCEPT]
BallAI.gd

— a Node2D component attached to Ball.tscn. Uses

apply\_central\_force()

to steer toward the enemy, retreat when HP is low, and wander when no target is found. The AI only runs when GameManager state is FIGHTING.
:::

## 1. AI Design — Keep It Simple

:::callout-intuition[INTUITION]
An open 1080×1080 arena with zero obstacles needs no pathfinding. The ball can always move in a straight line toward its target. Full behaviour trees are overkill for three states. A lightweight state enum +

apply\_central\_force()

is all you need, and it's fully debuggable in 60 lines.
:::

| AI State | Condition | Action |
| --- | --- | --- |
| SEEK | HP > 40% and target exists | Apply force toward target |
| EVADE | HP ≤ 40% | Apply force away from target (buy time to slow spin weapons) |
| WANDER | No target found | Apply force toward arena centre to avoid corner camping |

## 2. BallAI.gd — Complete Script

Create `res://scripts/BallAI.gd`:

```gdscript
extends Node
class_name BallAI

# ─── Exports ─────────────────────────────────────────────────────
@export var seek_force: float    = 280.0   # steering force toward target
@export var evade_force: float   = 350.0   # stronger than seek so escape is viable
@export var max_speed: float     = 500.0   # soft speed cap
@export var evade_hp_threshold: float = 0.4  # fraction below which AI evades

# ─── State ───────────────────────────────────────────────────────
enum AIState { SEEK, EVADE, WANDER }
var ai_state: AIState = AIState.WANDER

# ─── Node refs (resolved after _ready) ───────────────────────────
var _ball: RigidBody2D           # the ball this AI drives
var _health: HealthComponent     # our own health
var _target: Node                # enemy ball

# ─────────────────────────────────────────────────────────────────
func _ready() -> void:
    _ball   = get_parent() as RigidBody2D
    _health = _ball.get_node("HealthComponent")

func set_target(target_ball: Node) -> void:
    _target = target_ball

func _physics_process(delta: float) -> void:
    if GameManager.current_state != GameManager.State.FIGHTING:
        return
    _update_state()
    _apply_steering(delta)

func _update_state() -> void:
    if _target == null or not is_instance_valid(_target):
        ai_state = AIState.WANDER
        return
    var hp_frac = _health.get_hp_fraction()
    ai_state = AIState.EVADE if hp_frac <= evade_hp_threshold else AIState.SEEK

func _apply_steering(delta: float) -> void:
    var desired_dir: Vector2
    match ai_state:
        AIState.SEEK:
            desired_dir = (_target.global_position - _ball.global_position).normalized()
            _steer(desired_dir, seek_force, delta)
        AIState.EVADE:
            desired_dir = (_ball.global_position - _target.global_position).normalized()
            _steer(desired_dir, evade_force, delta)
        AIState.WANDER:
            # Drift toward arena centre (0,0) to avoid camping corners
            desired_dir = (Vector2.ZERO - _ball.global_position).normalized()
            _steer(desired_dir, seek_force * 0.5, delta)

func _steer(direction: Vector2, force: float, _delta: float) -> void:
    _ball.apply_central_force(direction * force)
    # Soft speed cap: subtract excess velocity
    if _ball.linear_velocity.length() > max_speed:
        _ball.linear_velocity = _ball.linear_velocity.normalized() * max_speed
```

### Why apply\_central\_force, Not linear\_velocity?

Setting `linear_velocity` every frame overrides physics — no damping, no bounce impulses get preserved. `apply_central_force()` adds to the velocity via the physics integrator every frame, so linear\_damp still reduces speed naturally and wall bounces still work. The ball feels like it's being pushed, not teleported.

## 3. AI State Transitions

The AI checks state every physics frame but only transitions when conditions change:

- **SEEK → EVADE:** when `get_hp_fraction() ≤ 0.4`. The ball retreats, creating a cat-and-mouse phase that's visually interesting for Short-form video.
- **EVADE → SEEK:** HP fraction never goes back up (no healing), so once the ball hits 40% HP it stays in EVADE until death. This creates a death spiral — intentional, it's visually climactic.
- **Any → WANDER:** target node is freed (dead). The wander drift toward centre prevents the winner ball from camping a corner after winning.

:::callout-tip[TIP]
Real Earclacks videos work because the balls look like they're actively trying to win, not just drifting. The SEEK force (280) is strong enough to steer decisively but not so strong that the ball ignores wall bounces. Try values between 200–400 and watch how the fight character changes.
:::

## 4. Attaching AI to the Ball

1. In `Ball.tscn`, add a `Node` child named `BallAI`. Attach `BallAI.gd` to it.
2. In `Arena.gd`, after spawning both balls, tell each AI about its target:

 Update `_spawn_ball()` to *return* the ball instance so Arena can reference it.

   ```gdscript
   func _on_match_started() -> void:
       var ball_red  = _spawn_ball(TEAM_RED,  spawn_left.global_position,  Vector2(1, 0.3))
       var ball_blue = _spawn_ball(TEAM_BLUE, spawn_right.global_position, Vector2(-1, -0.3))
       # Cross-link AI targets
       ball_red.get_node("BallAI").set_target(ball_blue)
       ball_blue.get_node("BallAI").set_target(ball_red)
   ```

:::callout-pitfall[PITFALL]
When the enemy ball is freed,

\_target

becomes an invalid reference. Always guard with

is\_instance\_valid(\_target)

before using it — already done in `_update_state()`. Never cache the target's position before checking validity.
:::

## 5. Tuning & Feel

| Variable | Low value effect | High value effect |
| --- | --- | --- |
| seek\_force | Lazy, drifty battles — balls take long to engage | Instant head-on crashes — little wall interaction |
| evade\_force | Evading ball gets cornered quickly — short escape | Injured ball escapes easily — long dragged-out endings |
| max\_speed | Slow-motion feel — good for fast weapons | Chaotic speed — hard to follow on video |
| evade\_hp\_threshold (0.0–1.0) | 0.0 = never evades — pure aggressor | 0.8 = evades from near-full HP — very defensive |

Recommended starting values for a 30-second Shorts fight: seek\_force=280, evade\_force=360, max\_speed=480, threshold=0.35.

## Chapter Summary

:::summary
### Files Created / Modified

| File | Change |
| --- | --- |
| res://scripts/BallAI.gd | New — 3-state steering AI with apply\_central\_force() |
| Ball.tscn | BallAI node added |
| Arena.gd | \_spawn\_ball() returns ball, AI targets cross-linked |
:::

## Practice Problems

**1.** easy — Why is `apply_central_force()` used instead of setting `linear_velocity` directly in the AI?

:::solution[Solution]
Setting `linear_velocity` every frame replaces all existing velocity including bounce impulses and the effect of linear\_damp. `apply_central_force()` adds to velocity through the physics integrator, so all damping and collision impulses are preserved. The ball feels physically steered, not teleported.
:::

**2.** standard — The EVADE state uses `evade_force > seek_force`. What happens to a fight if you set `evade_force = seek_force`? What if `evade_force < seek_force`?

:::solution[Solution]
Equal forces: the evading ball can't escape — the pursuer's force matches its retreat force exactly, so the distance between them stays roughly constant. The evader slowly dies from continued weapon contact with no escape possibility. Lower evade: the pursuer is faster than the retreat — fights end quickly with no drama. Higher evade (current setup): the injured ball can create distance, extending the fight with a climactic chase sequence.
:::

**3.** challenge — Add a fourth AI state: **ORBIT**. In ORBIT mode the ball tries to maintain a constant distance from the target equal to the weapon arm length (so the weapon tip just grazes the enemy). Write the steering logic for ORBIT mode.

:::solution[Solution]
```gdscript
AIState.ORBIT:
    var to_target = _target.global_position - _ball.global_position
    var dist = to_target.length()
    var ideal_dist = 90.0   # weapon arm_length
    # Perpendicular direction (90 deg rotation of the toward vector)
    var perp = Vector2(-to_target.y, to_target.x).normalized()
    # Radial correction: move in/out to reach ideal_dist
    var radial = to_target.normalized() * (dist - ideal_dist)
    var steer = perp * seek_force + radial * (seek_force * 0.5)
    _steer(steer.normalized(), seek_force, _delta)
```

The perpendicular component keeps the ball circling; the radial correction moves it in or out to stay at `ideal_dist`. This creates a persistent orbiting contact that's visually distinctive but requires careful force tuning.
:::
