---
title: "Multiplayer & Networking"
source: "markdown"
---

Part IV · Chapter 33

# Multiplayer & Networking

Prerequisite: Ch 4 (GDScript), Ch 7 (Signals), Ch 5 (Scene Tree) · est. 95 min

## Overview

Multiplayer is one of the most architecturally demanding features in game
 development. It requires you to think simultaneously about what runs on the
 server, what runs on each client, how data flows between them, and how to
 handle disagreements when the network is unreliable. Godot's high-level
 networking API is designed to make the common case straightforward while
 still exposing the low-level machinery when you need it.

The chapter covers:

- Client-server topology, peer IDs, and Godot's `MultiplayerAPI`
- Creating server and client connections with `ENetMultiplayerPeer`
- Remote Procedure Calls (`@rpc`) — calling functions across the network
- `MultiplayerSpawner` — automatic node replication on all peers
- `MultiplayerSynchronizer` — continuous property synchronisation
- A lobby/ready-up pattern for pre-game flow
- Latency concepts: client-side interpolation and an introduction to rollback

:::callout-warning[Warning — scope]
This chapter focuses on local network (LAN) and direct connection multiplayer.
        For internet play you additionally need NAT traversal, a relay server
        (e.g. Godot's built-in

WebRTCMultiplayerPeer

), and ideally a
        dedicated matchmaking service.  Those topics are beyond the scope of this
        chapter but build directly on the foundation taught here.
:::

## 1 · Networking Concepts

### 1.1 · Client-server topology

Godot uses an **authoritative server** model. One peer acts
 as the server — it holds the ground truth and makes all authoritative
 decisions (collision resolution, score tracking, anti-cheat). All other
 peers are clients — they send inputs to the server and receive state updates
 back. In a small game the server can be one of the players' machines
 (listen-server or "host"), or a dedicated headless process.

| Topology | Pros | Cons |
| --- | --- | --- |
| Listen-server (host plays) | Simple — no extra process; good for co-op | Host advantage; host crash = session ends |
| Dedicated server | Fair; reliable; scales better | Infrastructure cost; needs headless Godot export |
| Peer-to-peer (mesh) | No server needed | All peers must trust each other; hard to scale |

### 1.2 · Peer IDs

Every connected peer (including the server) has a unique integer ID:

- **1** — always the server.
- **2, 3, 4…** — clients, assigned by the server at connection.
- `multiplayer.get_unique_id()` — returns this peer's own ID.
- `multiplayer.is_server()` — returns `true` on the peer with ID 1.

Peer IDs are the key tool for targeting RPCs: you can call an RPC on a
 specific peer, all peers, or all peers except yourself.

:::callout-key[Key Concept — authority]
Every node has a

multiplayer authority

, which is the peer
        ID of the peer that "owns" that node.  By default all nodes have authority
        1 (the server).  When you spawn a player node for client 3, you call `node.set_multiplayer_authority(3)`.  Authority determines which
        peer is allowed to send RPC calls to that node, and which peer the

MultiplayerSynchronizer

accepts state updates from.
:::

## 2 · Creating a Connection

Godot ships with two peer implementations: `ENetMultiplayerPeer`
 (reliable UDP — best for games) and `WebSocketMultiplayerPeer`
 (for browser targets). The usage pattern is identical — create a peer,
 configure it as server or client, and assign it to
 `multiplayer.multiplayer_peer`.

### 2.1 · Starting a server

```gdscript
## res://network/network_manager.gd
## Autoload name: NetworkManager
extends Node

const PORT     := 7350
const MAX_PEERS := 8

signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal connection_failed()
signal server_disconnected()

func start_server() -> void:
    var peer := ENetMultiplayerPeer.new()
    var err: Error = peer.create_server(PORT, MAX_PEERS)
    if err != OK:
        push_error("NetworkManager: failed to create server (%s)" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    print("Server listening on port %d" % PORT)

func _on_peer_connected(id: int) -> void:
    print("Peer %d connected" % id)
    player_connected.emit(id)

func _on_peer_disconnected(id: int) -> void:
    print("Peer %d disconnected" % id)
    player_disconnected.emit(id)
```

### 2.2 · Joining as a client

```gdscript
func join_server(address: String = "127.0.0.1") -> void:
    var peer := ENetMultiplayerPeer.new()
    var err: Error = peer.create_client(address, PORT)
    if err != OK:
        push_error("NetworkManager: failed to connect (%s)" % error_string(err))
        connection_failed.emit()
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)

func _on_connected_to_server() -> void:
    print("Connected as peer %d" % multiplayer.get_unique_id())

func _on_connection_failed() -> void:
    push_error("NetworkManager: connection failed")
    connection_failed.emit()

func _on_server_disconnected() -> void:
    server_disconnected.emit()
```

### 2.3 · Connection signals reference

| Signal | Emitted on | When |
| --- | --- | --- |
| `multiplayer.peer_connected(id)` | Server & all clients | A new peer finishes connecting |
| `multiplayer.peer_disconnected(id)` | Server & all clients | A peer disconnects or times out |
| `multiplayer.connected_to_server()` | Client only | The client successfully connected |
| `multiplayer.connection_failed()` | Client only | Connection attempt timed out or refused |
| `multiplayer.server_disconnected()` | Client only | Server closed the connection |

## 3 · Remote Procedure Calls

An RPC lets you call a function on a remote peer as if it were local.
 The function runs on the receiving end(s), not on the caller. Annotate
 the function with `@rpc` to mark it as remotely callable.

### 3.1 · @rpc annotations

```gdscript
## Full annotation syntax:
@rpc(mode, sync, transfer_mode, transfer_channel)
func my_rpc_function() -> void:
    pass
```

| Parameter | Options | Default | Meaning |
| --- | --- | --- | --- |
| `mode` | `authority`, `any_peer` | `authority` | `authority`: only the node's authority can call; `any_peer`: any peer can call |
| `sync` | `call_local`, `call_remote` | `call_remote` | `call_local` also runs the function on the caller; `call_remote` only runs on remotes |
| `transfer_mode` | `unreliable`, `unreliable_ordered`, `reliable` | `reliable` | UDP reliability / ordering guarantee for this RPC's packets |
| `transfer_channel` | int (0–255) | 0 | ENet channel; separate channels process independently |

### 3.2 · Calling RPCs

```gdscript
## On a player node with authority matching the local client:

# 1. Call on ALL peers (broadcast).
rpc("take_damage", 10)

# 2. Call on a SPECIFIC peer (by ID).
rpc_id(target_peer_id, "take_damage", 10)

# 3. The function itself — runs on the receiving peer(s).
@rpc("any_peer", "call_local", "reliable")
func take_damage(amount: int) -> void:
    hp -= amount
    if hp <= 0:
        die()
```

:::callout-pitfall[Pitfall — trusting client RPCs]
any\_peer

mode means any client can trigger this function on
        any peer, including the server.  Never use

any\_peer

for
        functions that affect authoritative state (damage, score, inventory) without
        validating on the server first.  Use

authority

mode — only the
        node's assigned authority can call it — for player-controlled actions.
:::

### 3.3 · Authority and ownership

The typical pattern for a player node is:

1. Server spawns a `Player` scene for each connecting peer.
2. Server calls `player_node.set_multiplayer_authority(peer_id)`.
3. Each client only processes input for nodes where
 `is_multiplayer_authority()` is `true`.
4. Movement RPCs are annotated `@rpc("authority")` —
 only the owning client can send them.

```gdscript
## Player.gd
func _physics_process(delta: float) -> void:
    # Only the authority (owning client) handles input.
    if not is_multiplayer_authority():
        return
    var direction := Input.get_axis("move_left", "move_right")
    if direction != 0.0:
        # Tell the server our intent.
        rpc_id(1, "_sv_move", direction)

## Server-side authoritative move — only called by the player's authority.
@rpc("authority", "call_local", "reliable")
func _sv_move(direction: float) -> void:
    velocity.x = direction * SPEED
    move_and_slide()
```

## 4 · MultiplayerSpawner

`MultiplayerSpawner` automatically replicates
 `add_child` and `queue_free` calls from the server
 (the spawner's authority) to all clients. Clients never need to manually
 instantiate nodes that the spawner manages.

### 4.1 · Setup

Add a `MultiplayerSpawner` node to the scene. In the Inspector:

- *Spawn Path* — the node under which spawned nodes will be added
 (e.g. `$Players`).
- *Auto Spawn List* — add the `PackedScene` resources the
 spawner is allowed to replicate. Trying to spawn an unlisted scene throws
 an error.

```gdscript
## Server-side — spawn a player when a peer connects.
@onready var _spawner: MultiplayerSpawner = $MultiplayerSpawner

const PLAYER_SCENE := preload("res://player/player.tscn")

func _on_peer_connected(peer_id: int) -> void:
    if not multiplayer.is_server():
        return
    # Instantiate and add — the spawner replicates this to all clients.
    var player: Player = PLAYER_SCENE.instantiate()
    player.name = str(peer_id)         # node name = peer ID for easy lookup
    player.set_multiplayer_authority(peer_id)
    $Players.add_child(player)
    player.global_position = _get_spawn_position()
```

### 4.2 · Custom spawn data

The spawner can send extra data to clients when spawning, allowing you to
 initialise variables (player name, chosen character class, starting
 position) without a separate RPC:

```gdscript
## Connect MultiplayerSpawner.spawned signal to this on all clients.
func _on_spawner_spawned(node: Node) -> void:
    # node has just been instantiated on this client.
    # Retrieve the spawn data the server sent.
    var data: Dictionary = _spawner.get_spawn_config(node)
    if data.has("player_name"):
        node.player_name = data["player_name"]

## On the server, send spawn data by calling:
_spawner.spawn_with_data(PLAYER_SCENE, { "player_name": "Alice" })
```

:::callout-tip[Tip — node name as peer ID]
Naming the player node

str(peer\_id)

(e.g.

"3"

)
        lets any code look up a specific player with `$Players.get_node(str(peer_id))`.  It also ensures the

MultiplayerSynchronizer

child nodes (next section) are correctly
        routed to the right peer.
:::

## 5 · MultiplayerSynchronizer

`MultiplayerSynchronizer` continuously replicates selected
 node properties from the authority to all other peers. Unlike RPCs,
 which are event-driven, the synchroniser sends updates on a regular tick.

### 5.1 · Configuring synced properties

Add a `MultiplayerSynchronizer` as a child of the node whose
 properties you want to replicate. In the Inspector → *Replication*
 panel, click *Add Property* and select a property path such as
 `.:position`, `.:velocity`, or
 `Sprite2D:modulate`.

Each property entry can be configured:

| Option | Meaning |
| --- | --- |
| *On Change* | Send the value whenever it changes (delta) |
| *Always* | Send every tick regardless of changes |
| *Spawn* | Send once when the node is spawned; do not replicate continuously |

### 5.2 · Tick rate and delta smoothing

```gdscript
## Configure the synchroniser from code (optional — can also be done in editor).
@onready var _sync: MultiplayerSynchronizer = $MultiplayerSynchronizer

func _ready() -> void:
    # Send position updates 20 times per second.
    _sync.replication_interval = 1.0 / 20.0

    # On non-authority peers, received positions lag by up to one interval.
    # Smooth them out with interpolation (see Section 7.1).
```

:::callout-key[Key Concept — authority filter]
The synchroniser automatically ignores incoming updates for properties on
        nodes where the local peer is the authority.  You never receive your own
        position back from the server and apply it — that would cause jitter.
:::

## 6 · Lobby Pattern

Before the game starts, players need to see each other's names, signal
 readiness, and have the host launch the session. A simple lobby autoload
 holds the player list as a Dictionary and synchronises it via RPC.

### 6.1 · Player list autoload

```gdscript
## res://network/lobby.gd
## Autoload name: Lobby
extends Node

signal player_list_updated()
signal game_started()

# peer_id → player info Dictionary
var players: Dictionary = {}

func _ready() -> void:
    NetworkManager.player_connected.connect(_on_peer_connected)
    NetworkManager.player_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)

## Called on the newly-connected client: send our info to the server.
func _on_connected_to_server() -> void:
    var my_id: int = multiplayer.get_unique_id()
    rpc_id(1, "_sv_register_player", my_id, {
        "name":  PlayerPrefs.player_name,
        "ready": false,
    })

## Server receives registration from a client.
@rpc("any_peer", "call_remote", "reliable")
func _sv_register_player(peer_id: int, info: Dictionary) -> void:
    if not multiplayer.is_server():
        return
    players[peer_id] = info
    # Broadcast the full player list to all peers.
    rpc("_cl_update_player_list", players)

## All peers receive the authoritative player list.
@rpc("authority", "call_local", "reliable")
func _cl_update_player_list(new_list: Dictionary) -> void:
    players = new_list
    player_list_updated.emit()

func _on_peer_disconnected(peer_id: int) -> void:
    players.erase(peer_id)
    player_list_updated.emit()

func _on_peer_connected(_id: int) -> void:
    pass
```

### 6.2 · Ready-up and game start

```gdscript
## res://network/lobby.gd (continued)

## Client marks themselves ready.
func set_ready(is_ready: bool) -> void:
    var my_id: int = multiplayer.get_unique_id()
    rpc_id(1, "_sv_set_ready", my_id, is_ready)

@rpc("any_peer", "call_remote", "reliable")
func _sv_set_ready(peer_id: int, is_ready: bool) -> void:
    if not multiplayer.is_server():
        return
    if players.has(peer_id):
        players[peer_id]["ready"] = is_ready
    rpc("_cl_update_player_list", players)
    _check_all_ready()

func _check_all_ready() -> void:
    if players.is_empty():
        return
    for info in players.values():
        if not info.get("ready", false):
            return
    # All players ready — start the game.
    rpc("_cl_start_game")

@rpc("authority", "call_local", "reliable")
func _cl_start_game() -> void:
    game_started.emit()
    SceneManager.go_to("res://levels/level_01.tscn")
```

## 7 · Latency & Lag Compensation

### 7.1 · Client-side interpolation

The `MultiplayerSynchronizer` sends snapshots at a fixed tick rate
 (say 20 Hz). Between ticks, a remote player's position is a discrete step.
 Client-side interpolation smooths this into continuous motion by displaying
 the state from one tick ago, lerping toward the latest received snapshot:

```gdscript
## res://player/remote_player.gd
## Attach to non-authority player nodes.
extends CharacterBody2D

const INTERP_SPEED := 20.0    # higher = snappier, lower = smoother

var _target_position: Vector2

func _ready() -> void:
    # Subscribe to the synchroniser's property-received callback.
    $MultiplayerSynchronizer.delta_synchronized.connect(_on_received)

func _on_received() -> void:
    # Store the server-authoritative position as our target.
    _target_position = position

func _process(delta: float) -> void:
    if is_multiplayer_authority():
        return   # own player: no interpolation needed
    # Lerp current visual position toward latest received position.
    global_position = global_position.lerp(_target_position, INTERP_SPEED * delta)
```

:::callout-intuition[Intuition — extrapolation vs interpolation]
Interpolation always displays a slightly older state (by one network interval)
        but is smooth and accurate.  Extrapolation predicts the future state based
        on current velocity — lower visual lag but risks "rubber-banding" when
        predictions are wrong.  Most games use interpolation for positions and
        extrapolation as a fallback when the prediction error stays small.
:::

### 7.2 · Rollback networking — concepts

Input-delay compensation and rollback are advanced techniques used in fighting
 games and other latency-sensitive genres. The idea is:

1. **Input prediction**: assume remote input is unchanged and
 simulate ahead locally.
2. **Confirmed input receipt**: when the real remote input arrives
 for an old frame, re-simulate from that frame forward, discarding the
 prediction.
3. **Rollback**: the act of resetting to the saved state from
 that old frame and re-running physics.

Implementing rollback requires a fully deterministic physics simulation (no
 floating-point divergence between peers) and a state serialisation system
 that can snapshot and restore the entire game state in microseconds.
 Godot 4.6 does not provide a built-in rollback system; third-party addons
 such as *Nakama Godot* or *GodotRollbackNetcode* implement
 this on top of the low-level multiplayer API.

:::callout-connect[Connection — saving & loading]
Rollback state snapshots use the same serialisation concepts as the
        save/load system from Chapter 24, but must be

extremely

fast.
        Custom binary serialisation with

PackedByteArray

and

FileAccess

(or in-memory dictionaries only, no disk I/O)
        is typically required.
:::

## Summary

Godot's high-level networking system is built on the
 `MultiplayerAPI` singleton and a configurable
 `multiplayer_peer` object. `ENetMultiplayerPeer`
 provides reliable UDP suitable for real-time games.
 `@rpc`-annotated functions transmit calls across the network;
 the annotation controls which peer can call, whether the caller also runs
 the function, the reliability mode, and the channel.
 `MultiplayerSpawner` replicates `add_child` /
 `queue_free` events from the server, so clients always have
 the same scene tree without manual synchronisation.
 `MultiplayerSynchronizer` continuously streams selected
 properties from the authority to all peers at a configurable tick rate.
 A lobby autoload centralises the player list and ready-up flow via RPCs.
 Client-side interpolation smooths discrete positional snapshots into
 fluid motion; rollback is the foundation for latency-insensitive competitive
 play but requires deterministic simulation and fast serialisation.

| Tool | Purpose |
| --- | --- |
| `ENetMultiplayerPeer` | Reliable UDP connection layer |
| `multiplayer.get_unique_id()` | Local peer ID |
| `@rpc` annotation | Mark functions as remotely callable |
| `rpc()` / `rpc_id()` | Invoke RPC on all peers / specific peer |
| `set_multiplayer_authority()` | Assign node ownership to a peer |
| `MultiplayerSpawner` | Automatic scene instantiation replication |
| `MultiplayerSynchronizer` | Continuous property synchronisation |

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Is server check.**
 Write a helper function `only_server()` that returns early if
 the current peer is not the server, printing a warning. Use it as a
 guard at the top of authoritative functions. Also write
 `only_authority(node: Node)` that returns early if the local
 peer is not the node's multiplayer authority.

::::solution[Solution]
```gdscript
func only_server() -> bool:
    if not multiplayer.is_server():
        push_warning("only_server: called on client %d" % multiplayer.get_unique_id())
        return false
    return true

func only_authority(node: Node) -> bool:
    if not node.is_multiplayer_authority():
        push_warning("only_authority: not authority for %s" % node.name)
        return false
    return true

## Usage:
func _sv_award_score(peer_id: int, points: int) -> void:
    if not only_server(): return
    scores[peer_id] += points
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Chat RPC.**
 Add a chat system to the lobby. Any client can call
 `send_chat(message: String)`. The server broadcasts the
 message to all peers. Each peer emits a `chat_received(sender_name: String,
 message: String)` signal. Limit messages to 200 characters server-side.

::::solution[Solution]
```gdscript
## In Lobby autoload:
signal chat_received(sender_name: String, message: String)

func send_chat(message: String) -> void:
    rpc_id(1, "_sv_chat", multiplayer.get_unique_id(), message)

@rpc("any_peer", "call_remote", "reliable")
func _sv_chat(sender_id: int, message: String) -> void:
    if not multiplayer.is_server(): return
    var name: String = players.get(sender_id, {}).get("name", "Unknown")
    var safe_msg: String = message.substr(0, 200)
    rpc("_cl_chat", name, safe_msg)

@rpc("authority", "call_local", "reliable")
func _cl_chat(sender_name: String, message: String) -> void:
    chat_received.emit(sender_name, message)
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Reliable item pickup.**
 In a co-op game, a world item (see Chapter 30) should only be picked up
 by one player, even if two players reach it simultaneously.
 Write a server-authoritative pickup system:
 the client sends a "request pickup" RPC to the server;
 the server checks if the item is still present and removes it atomically;
 the server tells the requesting client to add the item to their inventory;
 the server tells all clients to despawn the item node.
 Use `is_instance_valid()` to guard against double-pickup.

::::solution[Solution]
```gdscript
## On WorldItem node (server-spawned via MultiplayerSpawner):

## Client requests pickup when entering the area.
func request_pickup() -> void:
    rpc_id(1, "_sv_request_pickup", multiplayer.get_unique_id())

## Server processes the request — only one client will succeed.
@rpc("any_peer", "call_remote", "reliable")
func _sv_request_pickup(requester_id: int) -> void:
    if not multiplayer.is_server(): return
    if not is_instance_valid(self): return   # already picked up
    # Award item to requester.
    rpc_id(requester_id, "_cl_receive_item", str(item.id), quantity)
    # Despawn for all peers (MultiplayerSpawner handles removal).
    queue_free()

@rpc("authority", "call_remote", "reliable")
func _cl_receive_item(item_id: String, qty: int) -> void:
    var player := get_tree().get_first_node_in_group("local_player")
    if player:
        player.inventory.add_item(ItemDB.get_item(StringName(item_id)), qty)
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Peer disconnect cleanup.**
 When a peer disconnects mid-game, the server should: remove that peer's
 player node from the `$Players` container, remove them from
 the `Lobby.players` dictionary, and broadcast the updated
 player list to all remaining clients. Write the server-side disconnect
 handler.

::::solution[Solution]
```gdscript
## In NetworkManager (server-side):
func _on_peer_disconnected(peer_id: int) -> void:
    if not multiplayer.is_server():
        return
    # Remove player node.
    var player_container: Node = get_tree().get_first_node_in_group("players")
    if player_container:
        var player_node: Node = player_container.get_node_or_null(str(peer_id))
        if player_node:
            player_node.queue_free()
    # Update lobby.
    Lobby.players.erase(peer_id)
    Lobby.rpc("_cl_update_player_list", Lobby.players)
    Lobby.player_list_updated.emit()
    player_disconnected.emit(peer_id)
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Authoritative health sync.**
 Implement a multiplayer-safe health system. The server owns all
 `hp` values. A client can *request* damage via
 `@rpc("any_peer")` to the server; the server validates
 (minimum 0 hp, sender must be in attack range via a simple distance
 check), applies the damage, and broadcasts the new hp to all clients
 via `@rpc("authority", "call_local")`. The health bar
 UI listens to the broadcast signal, not the local hp variable, so
 it stays in sync even if a client lags.

::::solution[Solution]
```gdscript
## In Player.gd:
signal hp_changed(new_hp: int)

var hp: int = 100

const ATTACK_RANGE := 150.0

## Any peer can request damage on this player.
@rpc("any_peer", "call_remote", "reliable")
func _sv_request_damage(attacker_id: int, amount: int) -> void:
    if not multiplayer.is_server(): return
    # Validate: find attacker node and check distance.
    var attacker: Node = $"../Players".get_node_or_null(str(attacker_id))
    if attacker == null: return
    if global_position.distance_to(attacker.global_position) > ATTACK_RANGE:
        return   # cheater / lag ghost — ignore
    amount = clampi(amount, 0, 100)     # sanity-cap damage
    var new_hp: int = clampi(hp - amount, 0, 100)
    rpc("_cl_set_hp", new_hp)

## Server broadcasts final hp to all clients.
@rpc("authority", "call_local", "reliable")
func _cl_set_hp(new_hp: int) -> void:
    hp = new_hp
    hp_changed.emit(hp)
    if hp == 0:
        die()
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Full NetworkManager.**
 Build a complete `NetworkManager` autoload that exposes:
 `host(max_players: int)`,
 `join(address: String)`,
 `disconnect_from_network()`,
 signals `peer_joined(id)` / `peer_left(id)` /
 `connected()` / `disconnected()` /
 `failed()`.
 On disconnect (*either* graceful or failure), clean up the
 `multiplayer_peer` and set it to `null` so that
 subsequent calls are safe. Add a `get_ping(peer_id: int) -> int`
 helper that returns the round-trip time in milliseconds for a specific
 peer (use `ENetMultiplayerPeer.get_peer()` and its
 `get_statistic()` method).

::::solution[Solution]
```gdscript
extends Node

const PORT := 7350

signal peer_joined(id: int)
signal peer_left(id: int)
signal connected()
signal disconnected()
signal failed()

var _enet: ENetMultiplayerPeer

func host(max_players: int = 8) -> void:
    _enet = ENetMultiplayerPeer.new()
    var err: Error = _enet.create_server(PORT, max_players)
    if err != OK:
        push_error("host failed: %s" % error_string(err))
        failed.emit(); return
    _setup_peer()
    connected.emit()

func join(address: String = "127.0.0.1") -> void:
    _enet = ENetMultiplayerPeer.new()
    var err: Error = _enet.create_client(address, PORT)
    if err != OK:
        push_error("join failed: %s" % error_string(err))
        failed.emit(); return
    _setup_peer()

func _setup_peer() -> void:
    multiplayer.multiplayer_peer = _enet
    multiplayer.peer_connected.connect(_on_joined)
    multiplayer.peer_disconnected.connect(_on_left)
    multiplayer.connected_to_server.connect(connected.emit)
    multiplayer.connection_failed.connect(_on_failed)
    multiplayer.server_disconnected.connect(_on_server_gone)

func disconnect_from_network() -> void:
    if _enet: _enet.close()
    multiplayer.multiplayer_peer = null
    disconnected.emit()

func _on_joined(id: int) -> void:   peer_joined.emit(id)
func _on_left(id: int)   -> void:   peer_left.emit(id)

func _on_failed() -> void:
    multiplayer.multiplayer_peer = null
    failed.emit()

func _on_server_gone() -> void:
    multiplayer.multiplayer_peer = null
    disconnected.emit()

func get_ping(peer_id: int) -> int:
    if _enet == null: return -1
    var ep: ENetPacketPeer = _enet.get_peer(peer_id)
    if ep == null: return -1
    return ep.get_statistic(ENetPacketPeer.PEER_ROUND_TRIP_TIME)
```
::::
:::
