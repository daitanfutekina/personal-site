---
title: "Inventory & Items"
source: "markdown"
---

Part III · Chapter 30

# Inventory & Items

Prerequisite: Ch 4 (GDScript basics), Ch 7 (Signals), Ch 22 (Custom Resources), Ch 24 (Saving & Loading) · est. 90 min

## Overview

An inventory system is one of the most architecturally challenging features in
 a game because it straddles three completely different domains at once: *data
 modelling* (what an item *is*), *game logic* (what picking up
 or using an item *does*), and *UI* (what the player *sees*).
 Getting those three layers tangled together is the single most common reason
 inventory code becomes unmaintainable.

This chapter teaches a clean three-layer architecture:

- **Layer 1 — Data:** `ItemData` custom Resource
 (immutable definition) + `InventorySlot` lightweight value type
 (item + quantity).
- **Layer 2 — Logic:** `Inventory` class with
 add/remove/move operations and `Signal`-driven change
 notifications.
- **Layer 3 — UI:** `ItemSlotUI` scene bound one-way
 to the data layer; drag-and-drop purely via Godot's built-in
 `_get_drag_data` / `_drop_data` API.

By the end you will have a fully functional inventory grid with stacking,
 equipment slots, stat modifiers, a tooltip, drag-and-drop reordering,
 world item pickup, and serialisation that integrates with the `SaveManager`
 from Chapter 24.

:::callout-key[Key Concept]
ItemData is shared; InventorySlot is owned.

Think of

ItemData

as a recipe card — every sword in the world
        shares the same card.  An

InventorySlot

is a drawer in the
        player's bag that says "3× Health Potion".  The recipe card never changes;
        the drawer quantity does.
:::

## 1 · ItemData Resource

### 1.1 · Defining item types and rarity

The decision underneath this whole chapter is that an item’s *definition* and an
item’s *presence in a bag* are different things. `ItemData` is the
definition: the name, the icon, the maximum stack size, the rarity. There is exactly one
`ItemData` for “health potion” in the entire game, and every potion
anyone is carrying points at it.

That is why it is a `Resource`. Resources are shared by reference, load once,
and can be authored in the inspector as `.tres` files — so a designer adds a
new item by making a file, with no code change. It is also why the slot class carries the
warning never to modify `item`: writing to it would change that potion for
everyone holding one.

A custom `Resource` is the perfect container for item definitions:
 it can be created in the editor, saved as a `.tres` file per item,
 inspected graphically, and loaded instantly with `preload()`.
 All fields are `@export` so designers can fill them without touching
 code.

```gdscript
## res://items/item_data.gd
class_name ItemData
extends Resource

enum Type { WEAPON, ARMOR, ACCESSORY, CONSUMABLE, QUEST, MATERIAL }
enum Rarity { COMMON, UNCOMMON, RARE, EPIC, LEGENDARY }

@export var id: StringName = ""        # unique key, e.g. &"iron_sword"
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D
@export var type: Type = Type.MATERIAL
@export var rarity: Rarity = Rarity.COMMON
@export var max_stack: int = 1         # 1 = not stackable
@export var weight: float = 0.0        # kg, 0 = weightless
@export var value: int = 0             # gold coins

# Combat stats (ignored for non-weapon/armor)
@export_group("Combat Stats")
@export var attack: int = 0
@export var defense: int = 0
@export var magic_power: int = 0
@export var speed_modifier: float = 0.0  # additive, e.g. -0.1 = -10% speed

# Consumable behaviour (ignored for non-consumables)
@export_group("Consumable")
@export var heal_hp: int = 0
@export var restore_mp: int = 0
@export var effect_scene: PackedScene  # optional VFX when used

## Returns the colour associated with this item's rarity.
func rarity_color() -> Color:
    match rarity:
        Rarity.COMMON:    return Color.WHITE
        Rarity.UNCOMMON:  return Color(0.12, 0.75, 0.12)   # green
        Rarity.RARE:      return Color(0.18, 0.46, 0.87)   # blue
        Rarity.EPIC:      return Color(0.58, 0.0,  0.83)   # purple
        Rarity.LEGENDARY: return Color(1.0,  0.5,  0.0)    # orange
    return Color.WHITE

## Single-line tooltip header, e.g. "[EPIC] Storm Blade"
func rarity_label() -> String:
    return "[%s] %s" % [Rarity.keys()[rarity], display_name]
```

:::callout-tip[Tip — export groups]
@export\_group("Combat Stats")

collapses related properties into
        a labelled section in the Inspector, keeping the resource editor tidy even
        when you add dozens of fields later.
:::

Create one `.tres` file per item. Right-click *res://items/*
 → *New Resource* → choose `ItemData`. Fill in the Inspector
 and save. A typical project structure looks like:

```
res://
  items/
    item_data.gd          ← class definition
    iron_sword.tres       ← Rarity.UNCOMMON, attack 12
    health_potion.tres    ← max_stack 99, heal_hp 50
    thunder_cloak.tres    ← Rarity.EPIC, defense 20, speed -0.05
    gold_coin.tres        ← max_stack 9999, value 1
```

### 1.2 · ItemDatabase autoload

Rather than scattering `preload()` calls everywhere, centralise all
 item definitions in an autoload. This also gives you an
 `id → ItemData` lookup used by the save/load system.

```gdscript
## res://autoloads/item_database.gd
## Autoload name: ItemDB
class_name ItemDatabase
extends Node

# Populated at startup — add every item .tres here.
const _PATHS: Array[String] = [
    "res://items/iron_sword.tres",
    "res://items/health_potion.tres",
    "res://items/thunder_cloak.tres",
    "res://items/gold_coin.tres",
]

var _db: Dictionary = {}   # StringName → ItemData

func _ready() -> void:
    for path in _PATHS:
        var data: ItemData = load(path)
        if data == null:
            push_error("ItemDB: failed to load %s" % path)
            continue
        if data.id == &"":
            push_error("ItemDB: item at %s has no id" % path)
            continue
        _db[data.id] = data
    print("ItemDB: loaded %d items" % _db.size())

## Returns the ItemData for 'item_id', or null if not found.
func get_item(item_id: StringName) -> ItemData:
    return _db.get(item_id, null)

## Returns all ItemData as an Array.
func all_items() -> Array[ItemData]:
    return Array(_db.values(), TYPE_OBJECT, &"ItemData", null)

## Returns every item that matches the given type filter.
func items_of_type(t: ItemData.Type) -> Array[ItemData]:
    var result: Array[ItemData] = []
    for item: ItemData in _db.values():
        if item.type == t:
            result.append(item)
    return result
```

:::callout-tip[Tip — ResourcePreloader alternative]
For small projects a

ResourcePreloader

node (added as a child of
        the autoload) can hold all item resources and avoids the hard-coded path list.
        For large projects consider a

ResourceFormatLoader

that scans an
        entire directory at startup.
:::

Inventory System — Data vs. Logic vs. UI layers

DATA LAYER

ItemData

Resource (.tres)

id, name, icon, stats, type

InventorySlot

RefCounted

item: ItemData, qty: int

Inventory

Resource (saveable)

slots: Array[InventorySlot]

ItemDatabase

Autoload singleton

get\_item("sword\_01")

LOGIC LAYER

Inventory methods

add\_item / remove\_item

has\_item / get\_slot

Equipment slots

equip / unequip

stat modifiers applied

Signals (events)

item\_added / removed

equipped\_changed

UI LAYER

ItemSlotUI (Control)

InventoryGridView

Tooltip panel

Drag & Drop

signals + method calls

listens to signals, reads slots

The inventory system has three clean layers: **Data** (plain Resources — no Nodes), **Logic** (methods + signals on the Inventory Resource), and **UI** (Control nodes that listen to signals and render). This separation means you can save/load the data layer without touching UI code.

## 2 · Inventory Data Model

### 2.1 · InventorySlot value type

If `ItemData` is the noun, the slot is the sentence: *this* item,
*this* many, here. It is deliberately a `RefCounted` rather than a
`Node`, because a bag of thirty slots would otherwise be thirty nodes in the
tree, each with a transform and a process callback it never uses, and all of it needing to
exist before the player can look at a menu.

`can_stack` compares `item == other_item`, and that is an identity
comparison on the resource rather than a comparison of names. It is exactly right given the
single-definition rule above, and it is the first thing to break if you ever load item
definitions twice — two `ItemData` objects describing the same potion will
refuse to stack with each other, and the bug will look like an inventory problem rather
than a loading one.

A slot holds a reference to an `ItemData` definition and a
 quantity. It is a lightweight, plain `RefCounted` object —
 not a `Node`, so there is no scene overhead.

```gdscript
## res://inventory/inventory_slot.gd
class_name InventorySlot
extends RefCounted

var item: ItemData        # shared definition — never modify this
var quantity: int         # 0 means empty (caller should null the slot)

func _init(p_item: ItemData, p_qty: int = 1) -> void:
    item = p_item
    quantity = p_qty

## Returns true if another item of the same kind can fit into this slot.
func can_stack(other_item: ItemData) -> bool:
    return item == other_item and quantity < item.max_stack

## Returns how many more units this slot could hold before it is full.
func space_remaining() -> int:
    return item.max_stack - quantity

func is_empty() -> bool:
    return quantity <= 0

## Serialise to a Dictionary for JSON / ConfigFile.
func to_dict() -> Dictionary:
    return { "id": str(item.id), "qty": quantity }

## Deserialise from a dictionary produced by to_dict().
static func from_dict(d: Dictionary) -> InventorySlot:
    var data: ItemData = ItemDB.get_item(StringName(d["id"]))
    if data == null:
        push_error("InventorySlot.from_dict: unknown item id '%s'" % d["id"])
        return null
    return InventorySlot.new(data, int(d["qty"]))
```

### 2.2 · The Inventory class

`add_item` runs in two passes, and the order is the entire user-visible
behaviour. The first pass tops up stacks that already exist; only then does the second open
a fresh slot. Reverse them and a player picking up two potions at a time fills their bag
with half-empty stacks while a full one sits beside them — the classic
inventory-management complaint, and it is one loop ordering.

Returning *what could not be added* rather than a boolean is the other decision
worth copying. A pickup that partly fits is the normal case, not an error case, and a
caller that gets back `3` knows to leave three on the ground. A boolean would
force every caller to work that out again.

`remove_item` mirrors it by returning what it actually removed, so asking for
more than is held is not an error either. Both functions emit `slot_changed` per
slot they touch, which is what lets the UI redraw one cell instead of the whole grid.

:::callout-tip[Tip]
These signals are the reason the inventory can be a plain object with no idea that a UI
  exists. The bag announces what changed; anything that cares subscribes. Test it by
  running the inventory with no UI attached at all — if that is awkward, the separation
  has already leaked.
:::

The `Inventory` class manages a fixed-size array of
 `InventorySlot`s (or `null` for empty slots).
 Every mutation emits a signal so that any UI subscribed to this inventory
 updates automatically — the UI never polls, and the logic never touches
 UI nodes directly.

```gdscript
## res://inventory/inventory.gd
class_name Inventory
extends RefCounted

signal slot_changed(index: int)   # emitted after any slot mutation
signal inventory_full()           # emitted when add_item cannot find space

var _slots: Array   # Array of InventorySlot or null, length == capacity
var capacity: int:
    get: return _slots.size()

func _init(p_capacity: int = 24) -> void:
    _slots.resize(p_capacity)
    _slots.fill(null)

# ─── READ ────────────────────────────────────────────────
func get_slot(index: int) -> InventorySlot:
    return _slots[index]

func is_empty_at(index: int) -> bool:
    return _slots[index] == null

## Returns the first index holding 'item', or -1 if not found.
func find_item(item: ItemData) -> int:
    for i in capacity:
        var s: InventorySlot = _slots[i]
        if s != null and s.item == item:
            return i
    return -1

## Counts total units of 'item' across all slots.
func count_item(item: ItemData) -> int:
    var total: int = 0
    for s: InventorySlot in _slots:
        if s != null and s.item == item:
            total += s.quantity
    return total

## Returns a list of all non-null slots as (index, slot) pairs.
func all_slots() -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for i in capacity:
        if _slots[i] != null:
            result.append({ "index": i, "slot": _slots[i] })
    return result

# ─── WRITE ───────────────────────────────────────────────
## Adds 'amount' units of 'item'.  Returns how many could NOT be added (0 = success).
func add_item(item: ItemData, amount: int = 1) -> int:
    var remaining: int = amount

    # Pass 1: top up existing partial stacks
    if item.max_stack > 1:
        for i in capacity:
            if remaining == 0:
                break
            var s: InventorySlot = _slots[i]
            if s != null and s.can_stack(item):
                var can_fit: int = s.space_remaining()
                var add_now: int = mini(can_fit, remaining)
                s.quantity += add_now
                remaining -= add_now
                slot_changed.emit(i)

    # Pass 2: fill empty slots
    for i in capacity:
        if remaining == 0:
            break
        if _slots[i] == null:
            var qty: int = mini(item.max_stack, remaining)
            _slots[i] = InventorySlot.new(item, qty)
            remaining -= qty
            slot_changed.emit(i)

    if remaining > 0:
        inventory_full.emit()
    return remaining

## Removes 'amount' units of 'item'.  Returns how many were actually removed.
func remove_item(item: ItemData, amount: int = 1) -> int:
    var removed: int = 0
    for i in capacity:
        if removed >= amount:
            break
        var s: InventorySlot = _slots[i]
        if s == null or s.item != item:
            continue
        var take: int = mini(s.quantity, amount - removed)
        s.quantity -= take
        removed += take
        if s.is_empty():
            _slots[i] = null
        slot_changed.emit(i)
    return removed

## Removes exactly the slot at index (e.g. on item use/drop).
func remove_at(index: int, amount: int = 1) -> void:
    var s: InventorySlot = _slots[index]
    if s == null:
        return
    s.quantity -= amount
    if s.is_empty():
        _slots[index] = null
    slot_changed.emit(index)

## Moves the slot at 'from_index' to 'to_index', swapping if occupied.
func move_slot(from_index: int, to_index: int) -> void:
    var tmp: InventorySlot = _slots[to_index]
    _slots[to_index] = _slots[from_index]
    _slots[from_index] = tmp
    slot_changed.emit(from_index)
    slot_changed.emit(to_index)

## Attempts to merge from_index into to_index if they hold the same item.
## Returns true if the merge was at least partial.
func merge_slots(from_index: int, to_index: int) -> bool:
    var src: InventorySlot = _slots[from_index]
    var dst: InventorySlot = _slots[to_index]
    if src == null or dst == null:
        return false
    if src.item != dst.item:
        return false
    var can_fit: int = dst.space_remaining()
    var transfer: int = mini(src.quantity, can_fit)
    if transfer == 0:
        return false
    dst.quantity += transfer
    src.quantity -= transfer
    if src.is_empty():
        _slots[from_index] = null
    slot_changed.emit(from_index)
    slot_changed.emit(to_index)
    return true

# ─── SERIALISE ───────────────────────────────────────────
func to_array() -> Array:
    var result: Array = []
    for s: InventorySlot in _slots:
        if s != null:
            result.append(s.to_dict())
        else:
            result.append(null)
    return result

func from_array(data: Array) -> void:
    _slots.resize(data.size())
    for i in data.size():
        if data[i] == null:
            _slots[i] = null
        else:
            _slots[i] = InventorySlot.from_dict(data[i])
```

:::callout-key[Key Concept — signal-driven UI]
Notice that

Inventory

extends

RefCounted

, not

Node

.  It has no connection to the scene tree.  Every time a slot
        changes it emits `slot_changed(index)`.  The UI scene connects to
        this signal and refreshes only the affected slot widget — no polling, no
        coupling.
:::

### 2.3 · Stacking logic in depth

Stacking can be confusing when items only partially fit. Let's trace an
 example: the player picks up 15 Health Potions when 7 already occupy slot 3,
 and `max_stack` is 10.

| Step | Action | Slot 3 qty | Remaining |
| --- | --- | --- | --- |
| Initial | — | 7 | 15 |
| Pass 1 (top-up slot 3) | add min(3, 15) = 3 | 10 | 12 |
| Pass 2 (first empty slot found) | new slot qty = min(10, 12) = 10 | 10 | 2 |
| Pass 2 (next empty slot) | new slot qty = min(10, 2) = 2 | — | 0 |

The two-pass algorithm is O(n) where n is the inventory capacity — perfectly
 fine for inventories up to a few hundred slots. If you need tens of thousands
 of slots, maintain a separate free-list index.

:::callout-pitfall[Pitfall — mutating ItemData]
Never

modify a field on an

ItemData

resource at
        runtime.  Because Godot resources are reference-counted, the same

.tres

object is shared by every slot that holds that item.  Changing

item.attack = 99

on a dropped sword would silently raise the attack
        of every other sword of that type.  Runtime stats (e.g. durability) must live in
        a separate per-slot data structure, not in

ItemData

.
:::

## 3 · Equipment System

### 3.1 · Equipment slots

An equipment system is a second, smaller inventory where each slot is
 named and restricted to a particular item type. A `Dictionary`
 keyed by a `SlotName` enum is clean and fast.

```gdscript
## res://inventory/equipment.gd
class_name Equipment
extends RefCounted

enum SlotName { HEAD, CHEST, LEGS, FEET, MAIN_HAND, OFF_HAND, RING, AMULET }

# Which ItemData.Type is permitted in each slot.
const ALLOWED_TYPES: Dictionary = {
    SlotName.HEAD:       ItemData.Type.ARMOR,
    SlotName.CHEST:      ItemData.Type.ARMOR,
    SlotName.LEGS:       ItemData.Type.ARMOR,
    SlotName.FEET:       ItemData.Type.ARMOR,
    SlotName.MAIN_HAND:  ItemData.Type.WEAPON,
    SlotName.OFF_HAND:   ItemData.Type.WEAPON,   # or ARMOR for shields
    SlotName.RING:       ItemData.Type.ACCESSORY,
    SlotName.AMULET:     ItemData.Type.ACCESSORY,
}

signal equipped(slot: SlotName, item: ItemData)
signal unequipped(slot: SlotName, item: ItemData)

var _slots: Dictionary = {}   # SlotName → ItemData or null

func _init() -> void:
    for s in SlotName.values():
        _slots[s] = null

## Returns the ItemData in the given slot, or null.
func get_equipped(slot: SlotName) -> ItemData:
    return _slots.get(slot, null)

## Returns true if 'item' can go into 'slot'.
func can_equip(slot: SlotName, item: ItemData) -> bool:
    return item.type == ALLOWED_TYPES[slot]

## Equips 'item' to 'slot'.  Returns the previously equipped item (or null).
func equip(slot: SlotName, item: ItemData) -> ItemData:
    if not can_equip(slot, item):
        push_error("Equipment.equip: %s cannot go in slot %s" % [item.id, SlotName.keys()[slot]])
        return null
    var old: ItemData = _slots[slot]
    _slots[slot] = item
    if old != null:
        unequipped.emit(slot, old)
    equipped.emit(slot, item)
    return old

## Unequips the item from 'slot'.  Returns the removed item, or null.
func unequip(slot: SlotName) -> ItemData:
    var old: ItemData = _slots[slot]
    if old == null:
        return null
    _slots[slot] = null
    unequipped.emit(slot, old)
    return old

# ─── SERIALISE ───────────────────────────────────────────
func to_dict() -> Dictionary:
    var d: Dictionary = {}
    for s in SlotName.values():
        var item: ItemData = _slots[s]
        d[str(s)] = item.id if item != null else ""
    return d

func from_dict(data: Dictionary) -> void:
    for s in SlotName.values():
        var id_str: String = data.get(str(s), "")
        _slots[s] = ItemDB.get_item(StringName(id_str)) if id_str != "" else null
```

### 3.2 · Applying stat modifiers

The `Equipment` object is queried by the `PlayerStats`
 component to compute derived values. Because `equipped` and
 `unequipped` signals are emitted on every change, stats always
 stay in sync.

```gdscript
## res://player/player_stats.gd
class_name PlayerStats
extends Node

# Base values (can be driven by level-up or save data)
var base_attack: int   = 10
var base_defense: int  = 5
var base_speed: float  = 200.0

@onready var equipment: Equipment = %Equipment  # Equipment node/component

## Computed properties — always re-evaluate from base + equipment
var total_attack: int:
    get:
        var bonus: int = 0
        for slot in Equipment.SlotName.values():
            var item: ItemData = equipment.get_equipped(slot)
            if item != null:
                bonus += item.attack
        return base_attack + bonus

var total_defense: int:
    get:
        var bonus: int = 0
        for slot in Equipment.SlotName.values():
            var item: ItemData = equipment.get_equipped(slot)
            if item != null:
                bonus += item.defense
        return base_defense + bonus

var total_speed: float:
    get:
        var mult: float = 1.0
        for slot in Equipment.SlotName.values():
            var item: ItemData = equipment.get_equipped(slot)
            if item != null:
                mult += item.speed_modifier
        return base_speed * mult
```

:::callout-intuition[Intuition — computed vs cached stats]
Computing stats on demand (

get:

) is simple and always correct.
        For large inventories with many modifiers, cache the result and invalidate it
        when

Equipment.equipped

or

Equipment.unequipped

fires.
        The simple version is right for 90 % of games — optimise only if profiling
        shows it is hot.
:::

## 4 · Inventory UI

### 4.1 · ItemSlotUI scene

Each slot in the grid is its own scene so it can be instantiated dynamically.
 The scene tree is minimal:

```
ItemSlotUI (Panel)
  ├── TextureRect   — item icon
  ├── Label         — quantity badge (e.g. "×12")
  └── ColorRect     — rarity border overlay (modulate set per rarity)
```

```gdscript
## res://ui/inventory/item_slot_ui.gd
class_name ItemSlotUI
extends Panel

signal slot_right_clicked(index: int)

@onready var _icon: TextureRect = $TextureRect
@onready var _qty_label: Label = $Label
@onready var _rarity_border: ColorRect = $ColorRect

var slot_index: int = -1
var _inventory: Inventory   # weak ref — set by InventoryGridView

func _ready() -> void:
    _clear()

## Binds this widget to 'inventory' and 'index', subscribing to slot_changed.
func bind(inventory: Inventory, index: int) -> void:
    # Disconnect from any previous inventory.
    if _inventory != null:
        _inventory.slot_changed.disconnect(_on_slot_changed)
    _inventory = inventory
    slot_index  = index
    _inventory.slot_changed.connect(_on_slot_changed)
    _refresh()

func _on_slot_changed(changed_index: int) -> void:
    if changed_index == slot_index:
        _refresh()

func _refresh() -> void:
    if _inventory == null:
        return
    var s: InventorySlot = _inventory.get_slot(slot_index)
    if s == null or s.is_empty():
        _clear()
        return
    _icon.texture        = s.item.icon
    _icon.modulate       = Color.WHITE
    _qty_label.text      = "" if s.item.max_stack == 1 else "×%d" % s.quantity
    _qty_label.visible   = s.item.max_stack > 1
    _rarity_border.color = s.item.rarity_color().darkened(0.4)
    _rarity_border.color.a = 0.6

func _clear() -> void:
    _icon.texture      = null
    _icon.modulate     = Color(1, 1, 1, 0.15)
    _qty_label.visible = false
    _rarity_border.color = Color.TRANSPARENT

## Right-click context menu (use / equip / drop).
func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
            slot_right_clicked.emit(slot_index)
```

### 4.2 · InventoryGridView

The grid view owns and manages all slot widgets. It is the only node that
 holds a reference to the live `Inventory` object.

```gdscript
## res://ui/inventory/inventory_grid_view.gd
class_name InventoryGridView
extends GridContainer

const SLOT_SCENE: PackedScene = preload("res://ui/inventory/item_slot_ui.tscn")

var _inventory: Inventory
var _tooltip: Control   # optional — assigned from parent

func bind_inventory(inv: Inventory) -> void:
    _inventory = inv
    # Remove stale slot widgets from previous bind.
    for child in get_children():
        child.queue_free()
    # Re-create slot widgets.
    for i in inv.capacity:
        var slot_ui: ItemSlotUI = SLOT_SCENE.instantiate()
        add_child(slot_ui)
        slot_ui.bind(inv, i)
        slot_ui.slot_right_clicked.connect(_on_right_click)
        slot_ui.mouse_entered.connect(_on_hover_enter.bind(i))
        slot_ui.mouse_exited.connect(_on_hover_exit)

func _on_right_click(index: int) -> void:
    var s: InventorySlot = _inventory.get_slot(index)
    if s == null:
        return
    _show_context_menu(index, s)

func _show_context_menu(index: int, s: InventorySlot) -> void:
    var menu := PopupMenu.new()
    add_child(menu)
    if s.item.type == ItemData.Type.CONSUMABLE:
        menu.add_item("Use", 0)
    if s.item.type in [ItemData.Type.WEAPON, ItemData.Type.ARMOR, ItemData.Type.ACCESSORY]:
        menu.add_item("Equip", 1)
    menu.add_item("Drop", 2)
    menu.id_pressed.connect(_on_context_action.bind(index))
    menu.popup_on_parent(Rect2(get_global_mouse_position(), Vector2.ZERO))

func _on_context_action(action_id: int, index: int) -> void:
    match action_id:
        0:  _use_item(index)
        1:  _equip_item(index)
        2:  _drop_item(index)

func _use_item(index: int) -> void:
    var s: InventorySlot = _inventory.get_slot(index)
    if s == null or s.item.type != ItemData.Type.CONSUMABLE:
        return
    # Notify the player — the player node handles HP change.
    Events.item_used.emit(s.item)
    _inventory.remove_at(index, 1)

func _equip_item(_index: int) -> void:
    pass  # See Section 3; delegate to EquipmentView

func _drop_item(index: int) -> void:
    var s: InventorySlot = _inventory.get_slot(index)
    if s == null:
        return
    Events.item_dropped.emit(s.item, s.quantity)
    _inventory.remove_at(index, s.quantity)

# ─── TOOLTIP ─────────────────────────────────────────────
func _on_hover_enter(index: int) -> void:
    if _tooltip == null:
        return
    var s: InventorySlot = _inventory.get_slot(index)
    if s == null:
        _tooltip.hide()
        return
    _tooltip.show_for(s.item)
    _tooltip.global_position = get_global_mouse_position() + Vector2(12, 12)
    _tooltip.show()

func _on_hover_exit() -> void:
    if _tooltip != null:
        _tooltip.hide()
```

### 4.3 · Tooltip panel

A simple `PanelContainer` scene floats above the cursor and renders
 item details. It is hidden by default and shown only by
 `InventoryGridView`.

```gdscript
## res://ui/inventory/item_tooltip.gd
class_name ItemTooltip
extends PanelContainer

@onready var _title:  Label = $VBox/Title
@onready var _rarity: Label = $VBox/Rarity
@onready var _desc:   Label = $VBox/Desc
@onready var _stats:  Label = $VBox/Stats
@onready var _value:  Label = $VBox/Value

func _ready() -> void:
    hide()
    # Keep the tooltip on top of everything.
    z_index = 100

func show_for(item: ItemData) -> void:
    _title.text  = item.display_name
    _title.add_theme_color_override("font_color", item.rarity_color())
    _rarity.text = Rarity.keys()[item.rarity].capitalize()
    _desc.text   = item.description

    var stat_lines: Array[String] = []
    if item.attack   > 0: stat_lines.append("⚔ Attack  +%d" % item.attack)
    if item.defense  > 0: stat_lines.append("🛡 Defense +%d" % item.defense)
    if item.heal_hp  > 0: stat_lines.append("❤ Heal    +%d HP" % item.heal_hp)
    if item.speed_modifier != 0.0:
        var pct: int = int(item.speed_modifier * 100.0)
        var sign_str: String = "+" if pct > 0 else ""
        stat_lines.append("👟 Speed   %s%d%%" % [sign_str, pct])
    _stats.text  = "\n".join(stat_lines)
    _value.text  = "Value: %d g" % item.value if item.value > 0 else ""
```

## 5 · Drag & Drop

Godot's `Control` nodes have a built-in drag-and-drop protocol based
 on three virtual methods. You never manage a "dragged node" yourself — Godot
 creates a preview ghost automatically.

| Override | Called when… | Return |
| --- | --- | --- |
| `_get_drag_data(pos)` | User starts dragging this control | Any non-null value becomes the "drag data" |
| `_can_drop_data(pos, data)` | Drag enters this control | `true` to allow drop, `false` to reject |
| `_drop_data(pos, data)` | User releases over this control after accepted | void — perform the drop action |

### 5.1 · Implementing \_get\_drag\_data and \_drop\_data

Add the following methods to `ItemSlotUI`:

```gdscript
## --- Add to item_slot_ui.gd ---

## Called by Godot when the player begins dragging this slot.
func _get_drag_data(_pos: Vector2) -> Variant:
    var s: InventorySlot = _inventory.get_slot(slot_index)
    if s == null:
        return null   # empty slot — nothing to drag

    # Build a preview ghost: a TextureRect matching the icon.
    var preview := TextureRect.new()
    preview.texture        = s.item.icon
    preview.custom_minimum_size = Vector2(48, 48)
    preview.modulate.a     = 0.75
    set_drag_preview(preview)

    # The drag payload: source inventory + source slot index.
    return { "inventory": _inventory, "from_index": slot_index }

## Called by Godot to ask whether this slot can accept the payload.
func _can_drop_data(_pos: Vector2, data: Variant) -> bool:
    if not data is Dictionary:
        return false
    if not data.has("inventory") or not data.has("from_index"):
        return false
    # Cannot drop onto itself.
    if data["inventory"] == _inventory and data["from_index"] == slot_index:
        return false
    return true

## Called by Godot when the player releases over an accepted target.
func _drop_data(_pos: Vector2, data: Variant) -> void:
    var src_inv: Inventory = data["inventory"]
    var from_i: int        = data["from_index"]

    if src_inv == _inventory:
        # Same inventory — try merge first, then swap.
        if not _inventory.merge_slots(from_i, slot_index):
            _inventory.move_slot(from_i, slot_index)
    else:
        # Cross-inventory drag (e.g. chest → player bag).
        var src_slot: InventorySlot = src_inv.get_slot(from_i)
        if src_slot == null:
            return
        var leftover: int = _inventory.add_item(src_slot.item, src_slot.quantity)
        var moved: int    = src_slot.quantity - leftover
        src_inv.remove_at(from_i, moved)
```

:::callout-tip[Tip — drag threshold]
By default Godot starts a drag after 10 pixels of movement.  Adjust it with

ProjectSettings → gui/common/drag\_threshold

if your slots are small and players accidentally start drags.
:::

### 5.2 · Swap and merge rules

The interaction between a drag source and drop target follows clear priority
 rules:

1. **Same item type + space remaining → merge.**
 If slot B holds 3 Health Potions (max 10) and you drag 5 from slot A,
 3 are transferred to fill B; the remaining 2 stay in A.
2. **Same item type + target full → swap.**
 Both stacks are at max — swap the slots exactly.
3. **Different item types → swap.**
 The two slots exchange contents regardless of type.
4. **Target is empty → move.**
 The slot moves to the empty position; the source becomes null.

The `merge_slots` method in `Inventory` handles
 cases 1–2 by returning `false` when no transfer occurs
 (stacks full or different items), falling through to `move_slot`
 for the swap.

## 6 · World Item Pickup

A world-item is a physical entity in the scene that the player can walk over
 or interact with. It is thin: it stores a reference to an
 `ItemData` and a quantity, and on pickup it adds to the player's
 `Inventory` then removes itself.

```gdscript
## res://world/world_item.gd
class_name WorldItem
extends Area2D

@export var item: ItemData
@export var quantity: int = 1

@onready var _sprite: Sprite2D  = $Sprite2D
@onready var _label:  Label     = $Label
@onready var _timer:  Timer     = $BobTimer   # optional bob animation

## Show icon and quantity label in world.
func _ready() -> void:
    if item == null:
        queue_free()
        return
    _sprite.texture = item.icon
    _label.text     = "×%d" % quantity if quantity > 1 else ""
    body_entered.connect(_on_body_entered)

## Spawns a WorldItem at 'pos' for the given item/quantity.
static func spawn(pos: Vector2, p_item: ItemData, qty: int = 1, parent: Node = null) -> void:
    const SCENE := preload("res://world/world_item.tscn")
    var wi: WorldItem = SCENE.instantiate()
    wi.item     = p_item
    wi.quantity = qty
    wi.global_position = pos
    (parent if parent != null else Engine.get_main_loop().current_scene).add_child(wi)

## Called when the player's hitbox enters this area.
func _on_body_entered(body: Node) -> void:
    if not body.is_in_group("player"):
        return
    # The player node is expected to expose an 'inventory' property.
    var inv: Inventory = body.get("inventory")
    if inv == null:
        return
    var leftover: int = inv.add_item(item, quantity)
    if leftover > 0:
        # Could not fully pick up — update quantity and show "Inventory full".
        quantity = leftover
        Events.inventory_full.emit()
    else:
        queue_free()
```

:::callout-connect[Connection — item drop]
When the player drops an item (from the right-click menu in the grid), the

Events.item\_dropped

signal fires with the item and quantity.
        A listener in the current level scene calls

WorldItem.spawn(player.global\_position + offset, item, qty)

to materialise it back in the world.
:::

## 7 · Saving the Inventory

The `Inventory` and `Equipment` classes already implement
 `to_array()`, `from_array()`, `to_dict()`, and
 `from_dict()`. Integrating them with the
 `SaveManager` from Chapter 24 is a matter of adding them to the
 save payload:

```gdscript
## Inside SaveManager (res://autoloads/save_manager.gd) — add to _build_save_data():
func _build_save_data() -> Dictionary:
    var player := get_tree().get_first_node_in_group("player")
    var data: Dictionary = {
        "version": CURRENT_VERSION,
        "timestamp": Time.get_unix_time_from_system(),
        "player": {
            "position": { "x": player.global_position.x,
                          "y": player.global_position.y },
            "hp": player.hp,
            "inventory": player.inventory.to_array(),
            "equipment": player.equipment.to_dict(),
        }
    }
    return data

## Inside SaveManager — add to _apply_save_data(data):
func _apply_save_data(data: Dictionary) -> void:
    var pd: Dictionary = data["player"]
    var player := get_tree().get_first_node_in_group("player")
    player.global_position = Vector2(pd["player"]["position"]["x"],
                                      pd["player"]["position"]["y"])
    player.hp = pd["player"]["hp"]
    player.inventory.from_array(pd["player"]["inventory"])
    player.equipment.from_dict(pd["player"]["equipment"])
```

:::callout-warning[Warning — item ID stability]
Once a save file exists in the wild, you must

never rename or
        reuse an item's

id

.  A rename silently produces null
        slots (the save file refers to an id the database no longer knows).  If you
        need to rename an item, add an

alias

list to

ItemDatabase.\_ready()

that maps old ids to new ones during
        load.  If you need to remove an item entirely, keep a tombstone entry in
        the database that silently discards any slot deserialized with that id.
:::

### 7.1 · Schema migration for inventory

Suppose in v2 you add a new `durability` field to
 `ItemData` and want each slot to track it. Follow the same
 migration pattern from Chapter 24:

```gdscript
## In SaveManager._migrate(data, from_version):
1 -> 2:
    # InventorySlot dicts previously had no "dur" field.
    # Add default full durability to all existing saves.
    for slot_dict in data["player"]["inventory"]:
        if slot_dict != null and not slot_dict.has("dur"):
            var item: ItemData = ItemDB.get_item(StringName(slot_dict["id"]))
            slot_dict["dur"] = item.max_durability if item != null else 100
```

## Summary

A clean inventory system separates three concerns that are easy to tangle.
 `ItemData` is an immutable `Resource` — the shared
 definition. `InventorySlot` is a mutable value type pairing a
 definition with a quantity. `Inventory` owns an array of slots,
 exposes add/remove/move operations, and broadcasts `slot_changed`
 so any number of UI scenes can react without polling. `Equipment`
 mirrors this pattern for a named set of body-part slots.
 The UI layer — `ItemSlotUI`, `InventoryGridView`, and
 `ItemTooltip` — only ever *reads* the data layer through
 `get_slot()` and *writes* through inventory methods;
 it never stores item definitions itself.
 Godot's built-in `_get_drag_data` / `_drop_data`
 protocol handles drag-and-drop with four lines per slot widget.
 World items spawn as lightweight `Area2D` nodes and add themselves
 to the player's inventory on collision.
 Both `Inventory` and `Equipment` serialise to plain
 Dictionaries that drop straight into the `SaveManager`.

| Class / file | Role | Extends |
| --- | --- | --- |
| `ItemData` | Immutable item definition | `Resource` |
| `ItemDatabase` | id → ItemData lookup | `Node` (autoload) |
| `InventorySlot` | item + quantity value type | `RefCounted` |
| `Inventory` | Fixed-capacity slot array + logic | `RefCounted` |
| `Equipment` | Named body-part slots | `RefCounted` |
| `ItemSlotUI` | Single slot widget + drag/drop | `Panel` |
| `InventoryGridView` | Grid of ItemSlotUI + context menu | `GridContainer` |
| `ItemTooltip` | Hover info panel | `PanelContainer` |
| `WorldItem` | Droppable world entity | `Area2D` |

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Rarity colour method.**
 Add a `rarity_label_bbcode()` method to `ItemData`
 that returns a BBCode-coloured string suitable for a
 `RichTextLabel`, e.g.
 `[color=#9b59b6][EPIC] Storm Blade[/color]`.
 Use the existing `rarity_color()` and
 `rarity_label()` methods.

::::solution[Solution]
```gdscript
func rarity_label_bbcode() -> String:
    var c: Color  = rarity_color()
    var hex: String = "#%02x%02x%02x" % [
        int(c.r * 255), int(c.g * 255), int(c.b * 255)
    ]
    return "[color=%s]%s[/color]" % [hex, rarity_label()]
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Count total gold.**
 Given a player's `Inventory`, write a helper function
 `count_gold(inv: Inventory) -> int` that returns the total
 number of gold coins (assume the item id is `&"gold_coin"`).
 Use only the public API of `Inventory`.

::::solution[Solution]
```gdscript
func count_gold(inv: Inventory) -> int:
    var coin: ItemData = ItemDB.get_item(&"gold_coin")
    if coin == null:
        return 0
    return inv.count_item(coin)
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Hotbar.**
 Create a `Hotbar` class (extends `RefCounted`) that
 wraps an `Inventory` with exactly 8 slots and exposes:
 `get_active_item() -> ItemData` (currently selected slot),
 `select(index: int)`, `select_next()`, and
 `select_prev()`. Emit a `selection_changed(index)`
 signal. Wrap around at both ends.

::::solution[Solution]
```gdscript
class_name Hotbar
extends RefCounted

signal selection_changed(index: int)

const SIZE: int = 8

var inventory: Inventory = Inventory.new(SIZE)
var active_index: int = 0:
    set(v):
        active_index = v
        selection_changed.emit(v)

func get_active_item() -> ItemData:
    var s: InventorySlot = inventory.get_slot(active_index)
    return s.item if s != null else null

func select(index: int) -> void:
    active_index = clamp(index, 0, SIZE - 1)

func select_next() -> void:
    active_index = (active_index + 1) % SIZE

func select_prev() -> void:
    active_index = (active_index - 1 + SIZE) % SIZE
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Use consumable.**
 Write a `use_item_at(index: int)` method for a
 `Player` node that checks if the slot at `index`
 holds a `CONSUMABLE`, applies its `heal_hp` and
 `restore_mp` to the player's stats, plays
 `effect_scene` at the player's position (if set), and
 removes one unit from the slot. Do nothing if the slot is empty or
 the item is not a consumable.

::::solution[Solution]
```gdscript
func use_item_at(index: int) -> void:
    var s: InventorySlot = inventory.get_slot(index)
    if s == null or s.item.type != ItemData.Type.CONSUMABLE:
        return
    hp = min(hp + s.item.heal_hp, max_hp)
    mp = min(mp + s.item.restore_mp, max_mp)
    if s.item.effect_scene != null:
        var vfx: Node = s.item.effect_scene.instantiate()
        get_tree().current_scene.add_child(vfx)
        if vfx.has_method("set_global_position"):
            vfx.global_position = global_position
    inventory.remove_at(index, 1)
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Vendor shop.**
 Create a `VendorInventory` class (extends `RefCounted`)
 that wraps an `Inventory` of shop stock. Implement
 `buy(item: ItemData, qty: int, buyer_inv: Inventory, buyer_gold: int) -> int`
 which returns the gold remaining after purchase (or the original amount
 if the purchase failed). Rules: the buyer must have enough gold,
 the buyer's inventory must have space, and the vendor's stock must have
 enough quantity. Implement `sell(item: ItemData, qty: int, seller_inv: Inventory) -> int`
 which removes from the seller's inventory and returns the gold earned
 (item value × qty × 0.5, rounded down). Signal
 `transaction(item, qty, price)`.

::::solution[Solution]
```gdscript
class_name VendorInventory
extends RefCounted

signal transaction(item: ItemData, qty: int, price: int)

var stock: Inventory

func _init(cap: int = 20) -> void:
    stock = Inventory.new(cap)

func buy(item: ItemData, qty: int, buyer_inv: Inventory, buyer_gold: int) -> int:
    var total_cost: int = item.value * qty
    if buyer_gold < total_cost:
        return buyer_gold                # not enough gold
    if stock.count_item(item) < qty:
        return buyer_gold                # vendor doesn't have enough
    var leftover: int = buyer_inv.add_item(item, qty)
    if leftover > 0:
        return buyer_gold                # buyer's inventory full
    stock.remove_item(item, qty)
    transaction.emit(item, qty, total_cost)
    return buyer_gold - total_cost

func sell(item: ItemData, qty: int, seller_inv: Inventory) -> int:
    if seller_inv.count_item(item) < qty:
        return 0
    var removed: int = seller_inv.remove_item(item, qty)
    if removed == 0:
        return 0
    var earned: int = int(item.value * removed * 0.5)
    stock.add_item(item, removed)
    transaction.emit(item, removed, -earned)   # negative price = payment out
    return earned
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Full inventory panel.**
 Build a complete `InventoryPanel` scene that combines:
 an `InventoryGridView` (5 × 8 = 40 slots), an equipment
 sidebar with one `ItemSlotUI` per `Equipment.SlotName`,
 an `ItemTooltip`, and a `Label` showing total
 carried weight. The weight label must update reactively via
 `slot_changed` — not polled. When the player right-clicks
 an equipment-type item in the grid and chooses "Equip", equip it to the
 correct slot (auto-detect the slot from `item.type`, using
 `MAIN_HAND` for weapons); if a piece was already equipped,
 swap it back into the inventory.

::::solution[Solution]
```gdscript
## res://ui/inventory/inventory_panel.gd
class_name InventoryPanel
extends Control

@onready var _grid:      InventoryGridView = $HSplit/Left/GridView
@onready var _tooltip:   ItemTooltip       = $Tooltip
@onready var _weight_lbl: Label            = $HSplit/Left/WeightLabel
@onready var _equip_slots: Dictionary      = {
    Equipment.SlotName.HEAD:       $HSplit/Right/Head,
    Equipment.SlotName.CHEST:      $HSplit/Right/Chest,
    Equipment.SlotName.LEGS:       $HSplit/Right/Legs,
    Equipment.SlotName.FEET:       $HSplit/Right/Feet,
    Equipment.SlotName.MAIN_HAND:  $HSplit/Right/MainHand,
    Equipment.SlotName.OFF_HAND:   $HSplit/Right/OffHand,
    Equipment.SlotName.RING:       $HSplit/Right/Ring,
    Equipment.SlotName.AMULET:     $HSplit/Right/Amulet,
}

var _inventory:  Inventory
var _equipment:  Equipment

func bind(inv: Inventory, eq: Equipment) -> void:
    _inventory = inv
    _equipment = eq
    _grid.bind_inventory(inv)
    _grid._tooltip = _tooltip
    _grid.slot_right_clicked.connect(_on_grid_right_click)
    inv.slot_changed.connect(_update_weight)
    _update_weight(0)
    # Bind equipment slot widgets.
    for slot_name in _equip_slots:
        var widget: ItemSlotUI = _equip_slots[slot_name]
        widget.slot_index = slot_name  # reuse slot_index as SlotName key
    eq.equipped.connect(_on_equipped)
    eq.unequipped.connect(_on_unequipped)

func _update_weight(_idx: int) -> void:
    var w: float = 0.0
    for entry in _inventory.all_slots():
        var s: InventorySlot = entry["slot"]
        w += s.item.weight * s.quantity
    _weight_lbl.text = "Weight: %.1f kg" % w

func _on_grid_right_click(index: int) -> void:
    var s: InventorySlot = _inventory.get_slot(index)
    if s == null:
        return
    if s.item.type not in [ItemData.Type.WEAPON, ItemData.Type.ARMOR, ItemData.Type.ACCESSORY]:
        return
    # Auto-detect slot.
    var target_slot: Equipment.SlotName
    match s.item.type:
        ItemData.Type.WEAPON:    target_slot = Equipment.SlotName.MAIN_HAND
        ItemData.Type.ARMOR:     target_slot = Equipment.SlotName.CHEST
        ItemData.Type.ACCESSORY: target_slot = Equipment.SlotName.RING
    # Equip and get the previously equipped item (if any).
    var old_item: ItemData = _equipment.equip(target_slot, s.item)
    _inventory.remove_at(index, 1)
    if old_item != null:
        _inventory.add_item(old_item, 1)

func _on_equipped(slot: Equipment.SlotName, item: ItemData) -> void:
    var widget: ItemSlotUI = _equip_slots.get(slot)
    if widget == null: return
    widget._icon.texture = item.icon
    widget._rarity_border.color = item.rarity_color().darkened(0.4)

func _on_unequipped(slot: Equipment.SlotName, _item: ItemData) -> void:
    var widget: ItemSlotUI = _equip_slots.get(slot)
    if widget == null: return
    widget._clear()
```
::::
:::
