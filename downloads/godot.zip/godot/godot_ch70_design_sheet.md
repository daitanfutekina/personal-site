---
title: "Earclacks Weapon Ball — Design Sheet"
crumb: "Earclacks Weapon Ball — Chapter 70"
meta:
  - "Est. study time: ~30 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Game Concept

**Weapon Ball** is a fully autonomous physics simulation where two or more circular balls, each armed with one or more pieces of equipment, are launched into a walled arena and fight until only one remains. There is no player input, no difficulty setting, and no AI steering — all movement comes from physics collisions. The simulation is designed to be recorded and shared as short-form video content (YouTube Shorts, TikTok Reels).

:::callout-key[KEY CONCEPT]
1. **No player input.** No keyboard, no mouse, no gamepad. The simulation runs to completion on its own.
2. **No AI steering.** Balls do not steer toward or away from enemies. Movement is entirely determined by the initial launch impulse and subsequent physics bounces.
3. **Equipment does the work.** Everything interesting — damage, abilities, stat escalation — comes from the equipment attached to the ball, not from the ball itself.
:::

## Core Mechanics

### Ball Movement — Pure Physics

Each ball is a `RigidBody2D` with `gravity_scale = 0`, `lock_rotation = true`, and a `linear_damp` value that gives the ball a natural slow-down over time. At match start each ball receives a single `linear_velocity` impulse. After that, the physics engine handles everything: wall bounces, ball-body collisions if ever enabled, and any forces applied by equipment.

:::callout-warning[WARNING]
The ball body itself does NOT physically rotate from collision impulses.

lock\_rotation = true

prevents this. The weapon equipment is what rotates — it does so at its own fixed angular speed, completely independently of the ball body's physics. If you allow the ball body to rotate from physics, the weapon's world-space angle becomes the sum of the ball's physics rotation plus the weapon's own rotation, which creates unpredictable compounding effects.
:::

### Weapon Rotation & Spin Reversal

Every melee weapon maintains a `current_angular_speed` variable (degrees/second). In `_physics_process`, the weapon node's `WeaponMount.rotation` increments by `current_angular_speed * delta`. This is independent of the ball body's rotation.

**On every collision** (wall or enemy ball), the spin direction reverses: `current_angular_speed *= -1.0`. This is detected using `_integrate_forces(state)` on the ball's RigidBody2D — which fires mid-physics-step when contacts are registered, giving exact bounce detection with no frame lag.

```gdscript
# Ball.gd — collision detection for spin reversal
signal bounced

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
    if state.get_contact_count() > 0:
        bounced.emit()

# MeleeWeapon.gd — receives the signal
func _ready() -> void:
    var ball: RigidBody2D = get_parent().get_parent()  # WeaponMount → Ball
    ball.bounced.connect(_on_ball_bounced)

func _on_ball_bounced() -> void:
    current_angular_speed *= -1.0
```

### Stat Evolution Per Hit / Per Bounce

Equipment stats can evolve dynamically during a match. The two most common patterns from actual Earclacks content:

| Trigger | Hook | Example |
| --- | --- | --- |
| Weapon lands a hit | `on_hit_landed(target, damage)` | Sword: +2 damage each hit. Staff: +1 explosion radius each hit. |
| Ball bounces | `_on_ball_bounced()` | Dagger: +20°/s rotation speed each bounce. |

Both hooks are `virtual` methods on `EquipmentBase` — subclasses override them to add their specific escalation logic.

### Parrying

When two weapons make contact with each other, neither deals damage — instead both parent balls are briefly dampened (near-stall). This is implemented via the weapon hitbox's `area_entered(area)` signal — when the entering area is also a weapon hitbox (checked via group membership), the parry logic fires instead of the damage logic.

### Ranged Weapons

Ranged weapons (bow, staff, gun) do not have rotating blades. They fire `ProjectileBase` instances on a timer. Projectiles are fired toward the nearest enemy ball at the moment of firing (direction is calculated once at spawn — the projectile then travels in a straight line under physics).

## Scene Hierarchy

### Arena.tscn — Root Match Scene

```
Arena [Node2D — Arena.gd]
├── WorldEnvironment [WorldEnvironment — bg color #0d1117]
├── Camera2D [Camera2D — fixed at (0,0), zoom (1,1), current=true]
├── ArenaWalls [Node2D]
│   ├── WallLeft [StaticBody2D — Layer 2, 20×1080 at x=−540]
│   ├── WallRight [StaticBody2D — Layer 2, 20×1080 at x=+540]
│   ├── WallTop [StaticBody2D — Layer 2, 1080×20 at y=−540]
│   └── WallBottom [StaticBody2D — Layer 2, 1080×20 at y=+540]
├── BallSpawner [Node2D]
│   ├── SpawnLeft [Marker2D — position (−270, 0)]
│   └── SpawnRight [Marker2D — position (+270, 0)]
├── Balls [Node2D — runtime ball instances added here]
├── Projectiles [Node2D — runtime projectile instances added here]
├── HUD [CanvasLayer — HUD.gd]
└── GameOverScreen [CanvasLayer — GameOverScreen.gd, hidden]
```

### Ball.tscn — Core Fighter

```
Ball [RigidBody2D — Ball.gd | gravity_scale=0, lock_rotation=ON, linear_damp=0.4, CCD=CastRay | Layer 1, Mask 2]
├── CollisionShape2D [CircleShape2D r=45]
├── BallVisual [ColorRect 90×90, centred — team colour set at runtime]
├── HPLabel [Label — displays current HP numerically, centred on ball]
├── WeaponMount [Node2D — pivot for melee equipment (stays at origin)]
│   └── [equipment instance] [added at runtime by Ball.gd]
└── HealthComponent [Node — HealthComponent.gd]
```

:::callout-tip[TIP]
Ball exposes

@export var equipment\_scenes: Array[PackedScene]

. Every scene in the array is instantiated and added as a child of

WeaponMount

. A ball can carry a sword AND a shield, or a gun AND a passive speed boost. Melee weapons attach to WeaponMount (rotating pivot). Ranged weapons and abilities also attach here but control their own timers independently.
:::

### Equipment Scenes

```
Sword [Node2D — MeleeWeapon.gd (extends EquipmentBase)]
├── SwordSprite [ColorRect 10×90 at (−5, −90)]
└── Hitbox [Area2D — Layer 3, Mask 1 (Balls)]
    └── CollisionShape2D [RectangleShape2D 10×90, centred at (0,−45)]
Bow [Node2D — RangedWeapon.gd (extends EquipmentBase)]
├── BowSprite [ColorRect — visual only]
└── FireTimer [Timer — fires Arrow.tscn projectile every fire_rate seconds]
Arrow [RigidBody2D — ProjectileBase.gd | Layer 4, Mask 1]
├── ArrowSprite [ColorRect 4×24]
├── CollisionShape2D [RectangleShape2D 4×24]
└── LifetimeTimer [Timer — queue_free after max_lifetime]
```

## Physics Setup

| Setting | Value | Where Set | Reason |
| --- | --- | --- | --- |
| Global Gravity | 0 | Project Settings → Physics/2D | Zero-gravity arena — balls float |
| Ball gravity\_scale | 0 | Ball RigidBody2D Inspector | Belt-and-suspenders zero gravity |
| Ball linear\_damp | 0.4 | Ball RigidBody2D Inspector | Natural deceleration over ~10s |
| Ball angular\_damp | 0 | Ball RigidBody2D Inspector | lock\_rotation=true makes this irrelevant |
| Ball lock\_rotation | true | Ball RigidBody2D Inspector | Ball body never physically spins — weapons control their own rotation independently |
| Ball CCD | Cast Ray | Ball RigidBody2D Inspector | Prevents tunnelling through 20px walls at speed |
| Wall PhysicsMaterial bounce | 0.8 | wall\_physics.tres | 80% speed retained per bounce |
| Wall PhysicsMaterial friction | 0.0 | wall\_physics.tres | No friction sliding along walls |
| Physics ticks/sec | 120 | Project Settings → Physics | Smoother weapon rotation at high angular speeds |

## Equipment Architecture

:::callout-intuition[INTUITION]
The original Earclacks format uses swords and spears. The evolved format includes bows (fire arrows on a timer), staves (fire fireballs with AoE), shields (passively deflect projectiles), and special abilities (burst speed, temporary invincibility). A single "WeaponBase" class that assumes a rotating blade with an Area2D hitbox cannot represent any of these. EquipmentBase is a thin common interface that all equipment types share — subclasses implement only what they need.
:::

### Class Hierarchy

```gdscript
EquipmentBase (Node2D, class_name)
  — on_equipped(ball: RigidBody2D) → virtual
  — on_unequipped()                → virtual
  — on_hit_landed(target, damage)  → virtual (called by subclasses)
  — on_ball_bounced()              → virtual (connected by subclasses)
  — owner_team: String             (set by Ball after instantiation)

MeleeWeapon  extends EquipmentBase
  — base_angular_speed, current_angular_speed
  — damage, hit_cooldown
  — Area2D Hitbox (Layer 3, Mask 1+3 for damage+parry)
  — _physics_process: rotates WeaponMount by current_angular_speed * delta
  — _on_ball_bounced: current_angular_speed *= -1

RangedWeapon extends EquipmentBase
  — fire_rate, projectile_scene, damage
  — Timer child fires projectile_scene toward nearest enemy
  — Projectile: RigidBody2D (Layer 4, Mask 1)

SpecialAbility extends EquipmentBase
  — cooldown, duration
  — activate() → virtual (triggered by condition or timer)
  — Condition examples: low_hp, on_bounce, on_hit_taken, timed_interval

PassiveEffect extends EquipmentBase
  — applied once in on_equipped()
  — Examples: +mass (harder to deflect), -linear_damp (faster), +max_hp
```

### Parry Detection

Melee weapon hitboxes are on Layer 3. They mask *both* Layer 1 (balls, for damage) and Layer 3 (other weapon hitboxes, for parry detection). When `area_entered(area)` fires and the entering area is in the "weapon\_hitbox" group, parry logic runs instead of damage logic:

```gdscript
# In MeleeWeapon.gd
func _on_hitbox_area_entered(area: Area2D) -> void:
    if area.is_in_group("weapon_hitbox"):
        _do_parry(area)   # stall both balls

func _do_parry(enemy_hitbox: Area2D) -> void:
    # Dampen both balls briefly — the "clang" moment
    var my_ball: RigidBody2D = get_parent().get_parent()
    var enemy_ball: RigidBody2D = enemy_hitbox.get_parent().get_parent().get_parent()
    my_ball.linear_velocity   *= 0.15
    enemy_ball.linear_velocity *= 0.15
    # Spin reversal also fires (bounced signal already handles this)
```

## Equipment Roster

### Melee Weapons

| Name | Arm (px) | Base Speed (°/s) | Damage | Cooldown | Escalation |
| --- | --- | --- | --- | --- | --- |
| Dagger | 60 | 360 | 8 | 0.4s | +20°/s per bounce |
| Sword | 90 | 240 | 15 | 0.5s | +2 damage per hit |
| Scythe | 110 | 180 | 22 | 0.55s | +3 damage per hit |
| Spear | 130 | 120 | 30 | 0.7s | +5 damage per hit |
| Shuriken | 80 | 720 | 6 | 0.3s | +40°/s per bounce |
| Scimitar | 100 | 200 | 25 | 0.5s | +3 damage per hit |

### Ranged Weapons

| Name | Fire Rate | Projectile | Damage | Escalation |
| --- | --- | --- | --- | --- |
| Bow | 1.2s | Arrow (RigidBody2D, fast, thin) | 12 | +1 arrow per hit (multi-shot) |
| Staff | 1.5s | Fireball (RigidBody2D, AoE on impact) | 18 + AoE | +1 AoE radius per hit |
| Gun | 0.5s | Bullet (fast, small, no AoE) | 10 | +0.1 fire rate per hit (up to cap) |

### Special Abilities (Future)

| Name | Trigger | Effect | Cooldown |
| --- | --- | --- | --- |
| Temporal Lock | Timed (every 8s) | Freezes enemy ball for 1.5s (linear\_velocity = 0) | 8s |
| Shield Burst | HP < 30% | Temp invincibility 2s + speed boost | Match-once |
| Gravity Well | Timed (every 6s) | Pulls enemy toward centre for 1s | 6s |

## Script Contracts

Each script's full interface — what it exports, what it listens to, what it emits. Build to this spec and the chapters will connect cleanly.

#### Ball.gd extends RigidBody2D

@exports

team\_color: Color

·

launch\_speed: float = 380.0

·

equipment\_scenes: Array[PackedScene]

Inputs (reads / listens)

- `HealthComponent.died` → calls `on_health_depleted()`
- Called by Arena: `launch(direction)`

Outputs (signals / methods)

- `signal bounced` — emitted from `_integrate_forces` on every contact
- `signal died(who: String)` — emitted when HP hits 0
- `take_damage(amount: float)` — forwards to HealthComponent
- `launch(direction: Vector2)` — sets linear\_velocity once at match start

Key behaviour

- Instantiates all `equipment_scenes` and adds them as children of WeaponMount
- Sets `owner_team` on each equipment instance after instantiation
- Updates HPLabel text every time HealthComponent emits `hp_changed`

#### EquipmentBase.gd extends Node2D · class\_name EquipmentBase

@exports

owner\_team: String

(set by Ball after instantiation)

Virtual methods (override in subclasses)

- `on_equipped(ball: RigidBody2D)` — called by Ball after add\_child
- `on_unequipped()` — called before queue\_free
- `on_hit_landed(target: Node, damage: float)` — for stat escalation
- `on_ball_bounced()` — for bounce-triggered escalation or reversal

#### MeleeWeapon.gd extends EquipmentBase

@exports

base\_angular\_speed: float

·

damage: float

·

hit\_cooldown: float

Runtime state

current\_angular\_speed: float

(starts = base\_angular\_speed, modified per hit/bounce)

Key behaviour

- Rotates WeaponMount by `current_angular_speed * delta` in `_physics_process`
- On `bounced` signal: `current_angular_speed *= -1.0`
- Hitbox `body_entered` → damage enemy ball (with cooldown)
- Hitbox `area_entered` → parry if other area is in group "weapon\_hitbox"
- Hitbox in group `"weapon_hitbox"` (for parry detection by others)

#### RangedWeapon.gd extends EquipmentBase

@exports

fire\_rate: float

·

projectile\_scene: PackedScene

·

damage: float

Key behaviour

- Timer fires every `fire_rate` seconds → spawns projectile into `Arena/Projectiles`
- At fire time: finds nearest enemy via `get_tree().get_nodes_in_group("balls")`, filters out own team, aims projectile toward that position
- Projectile travels in straight line — no homing after spawn

#### ProjectileBase.gd extends RigidBody2D · Layer 4, Mask 1

@exports

damage: float

·

speed: float

·

max\_lifetime: float

·

owner\_team: String

Key behaviour

- Launched with `linear_velocity = direction * speed` at spawn
- Gravity scale 0, linear\_damp 0 (travels at constant speed)
- `body_entered` → if body is enemy ball: call `take_damage()`, `queue_free()`
- LifetimeTimer → `queue_free()` if projectile misses

#### HealthComponent.gd extends Node

@exports

max\_hp: float = 100.0

Outputs

signal hp\_changed(new\_hp, max\_hp)

·

signal died

Methods

apply\_damage(amount)

·

heal(amount)

·

reset()

·

get\_hp\_fraction() → float

#### GameManager.gd Autoload singleton

State machine

enum State { WAITING, COUNTDOWN, FIGHTING, GAME\_OVER }

Signals

match\_started

·

match\_ended(winner\_name)

·

state\_changed(new\_state)

·

countdown\_tick(seconds\_left)

Methods

start\_match()

·

ball\_died(name)

·

end\_match(winner)

·

request\_replay()

#### Arena.gd extends Node2D

@exports

available\_equipment: Array[PackedScene]

·

ball\_configs: Array[Dictionary]

Key behaviour

- Spawns balls on `GameManager.match_started` (not before — balls don't exist during countdown)
- Picks equipment randomly from `available_equipment` per ball
- Connects each ball's `died` signal to `GameManager.ball_died`
- Provides projectile parent node reference to ranged weapons via `get_node("/root/Arena/Projectiles")`

## Signal Flow Diagrams

### Melee Damage Chain

```
MeleeWeapon Hitbox
  └─ body_entered(enemy_ball)
       └─ _try_hit() — checks: is ball? enemy team? off cooldown?
            └─ enemy_ball.take_damage(damage)
                 └─ HealthComponent.apply_damage(damage)
                      ├─ hp_changed.emit(new_hp, max_hp)
                      │    ├─ Ball.gd  → HPLabel.text = str(new_hp)
                      │    └─ HUD.gd  → health bar update
                      └─ (if hp ≤ 0) died.emit()
                           └─ Ball.on_health_depleted()
                                └─ Ball.died.emit(ball_name)
                                     └─ GameManager.ball_died(name)
                                          └─ GameManager.end_match(winner)
                                               └─ match_ended.emit(winner)
                                                    ├─ GameOverScreen → show
                                                    └─ Arena → print log
```

### Parry Chain

```
MeleeWeapon Hitbox
  └─ area_entered(other_area)
       └─ other_area.is_in_group("weapon_hitbox") == true
            └─ _do_parry(other_area)
                 ├─ my_ball.linear_velocity    *= 0.15
                 ├─ enemy_ball.linear_velocity *= 0.15
                 └─ (bounced signal fires naturally from _integrate_forces
                     → current_angular_speed *= -1.0 on both weapons)
```

### Spin Reversal Chain

```
Ball._integrate_forces(state)
  └─ state.get_contact_count() > 0
       └─ bounced.emit()
            └─ MeleeWeapon._on_ball_bounced()
                 └─ current_angular_speed *= -1.0
                      └─ (optional escalation: abs(current_angular_speed) += speed_per_bounce)
```

### Ranged Fire Chain

```
RangedWeapon.FireTimer.timeout
  └─ _find_nearest_enemy() → enemy_ball (or null)
       └─ (if found) _fire_projectile(direction_to_enemy)
            └─ instantiate projectile_scene
                 ├─ set owner_team, damage, direction
                 ├─ add to Arena/Projectiles node
                 └─ linear_velocity = direction * speed

ProjectileBase
  └─ body_entered(enemy_ball)
       └─ enemy_ball.take_damage(damage)
            └─ queue_free()    ← projectile destroys itself on hit
```

## Physics Layers

| Layer # | Name | Used by | Layer | Mask | Notes |
| --- | --- | --- | --- | --- | --- |
| 1 | Balls | Ball RigidBody2D | 1 | 2 (Walls) | Balls only collide with walls physically. Ball-on-ball body contact is optional (leave mask off for pure weapon-damage fights). |
| 2 | Walls | Wall StaticBody2D | 2 | 1 (Balls) |  |
| 3 | WeaponHitbox | MeleeWeapon Area2D Hitbox | 3 | 1 (Balls) + 3 (Weapons) | Mask includes Layer 3 for parry detection between weapons. |
| 4 | Projectiles | ProjectileBase RigidBody2D | 4 | 1 (Balls) | Projectiles don't collide with walls — they use lifetime timer to die. Add Layer 2 to mask if you want them to bounce off walls. |

:::callout-tip[TIP]
Balls do NOT mask Layer 1 (other balls) by default. If balls physically collide they push each other around, which can create chaotic deflections. This is fun but makes fights harder to read on video. Leave it off for clean Shorts content; enable it for a more chaotic free-for-all mode.
:::

## Implementation Checklist

Implement in this order — each phase produces a runnable state you can verify before moving on.

Phase 1 — Ch 70A: Arena Shell

- 1080×1080 project, canvas\_items stretch, global gravity = 0, physics ticks = 120
- Arena.tscn with four StaticBody2D walls + wall\_physics.tres (bounce 0.8, friction 0)
- Camera2D fixed at (0,0), WorldEnvironment dark background
- GameManager.gd autoload with 4-state enum skeleton
- Verification: temporary RigidBody2D ball bounces indefinitely, never falls

Phase 2 — Ch 70B: Ball Scene

- Ball.tscn: RigidBody2D + CollisionShape2D + BallVisual + HPLabel + WeaponMount + HealthComponent
- Ball.gd: launch(), take\_damage(), \_integrate\_forces() → bounced signal, equipment instantiation, HPLabel update
- Arena.gd: spawns two balls on match\_started, launch toward centre
- Verification: two coloured balls with HP "100" on them bounce around arena

Phase 3 — Ch 70C: Equipment System

- EquipmentBase.gd with virtual hooks
- MeleeWeapon.gd: rotation, spin reversal on bounced, damage hitbox, parry detection
- Sword.tscn as first concrete weapon
- Ball.gd updated: equipment\_scenes array, sets owner\_team per item
- Verification: swords spin, reverse on wall bounce, deal damage (HP label decreases)

Phase 4 — Ch 70D: Health & Death

- HealthComponent.gd complete (hp\_changed, died, is\_dead guard)
- Ball death: VFX tween + queue\_free, GameManager.ball\_died() called
- Verification: ball dies after ~7 sword hits, game-over state reached

Phase 5 — Ch 70E: Match Flow & HUD

- GameManager: async countdown, request\_replay()
- HUD: health bars, countdown label
- GameOverScreen: winner label, replay button
- Verification: full game loop — countdown → fight → winner → replay

Phase 6 — Ch 70F: Ranged Weapons

- RangedWeapon.gd + fire Timer, nearest-enemy targeting
- ProjectileBase.gd (Layer 4, lifetime timer, body\_entered damage)
- Arrow.tscn and Fireball.tscn (Fireball: AoE Area2D on impact)
- Arena.gd: Projectiles node as parent for spawned projectiles
- Verification: bow fires arrows that travel straight and deal damage on hit

Phase 7 — Ch 70G: Full Weapon Roster & Escalation

- All 6 melee weapons with unique escalation logic in on\_hit\_landed / on\_ball\_bounced
- Bow + Staff + Gun as ranged variants
- Random equipment selection in Arena.gd
- DPS balance pass

Phase 8 — Ch 70H: Polish & Export

- Hit sparks (GPUParticles2D)
- Screen shake on death (Camera2D offset noise)
- Ball trail (Line2D with point history)
- Sound effects (hit, death, parry clang)
- Auto-loop for unattended recording
- Export preset for 1080×1080 screen capture
