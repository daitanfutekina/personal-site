---
title: "Ch 73 — Balatro Clone (planned)"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 73"
meta:
  - "Not written yet"
  - "Tier 2 — Intermediate · 2D"
  - "Est. 10–14 h once written"
source: "markdown"
---

Part XIII · Chapter 73

# Balatro Clone — Card Roguelike with Joker Effects & Run Economy

Tier 2 — Intermediate · 2D · estimated 10–14 h of study once written

:::callout-warning[This chapter is not written yet]
It is listed so the gap is visible while you read rather than only on the
index page. Nothing below is instruction — it is the scope the chapter is
meant to cover, kept here so it can be written from its own stub.
:::

## What it is meant to cover

- Card data as Resources, and a deck that survives a run.
- Joker effects as composable modifiers rather than a switch statement — the reason this project is worth building is that scoring is a pipeline, not a sum.
- Run economy: shop, rerolls, and the money curve that keeps a run tense.
- Hand evaluation, and why it wants to be pure and testable.

## Before this is written

The four walkthroughs that already exist — the Weapon Ball, Vampire
Survivors and Crowd Runner builds in this part — cover the ground this one
assumes. Working through one of those is the prerequisite, and is the
better use of the time until this chapter exists.
