---
title: "MultiplayerAPI, RPCs, ENet & WebSocket Networking"
source: "godot_ch63_multiplayer.html"
---

Part X · Chapter 63

# MultiplayerAPI, RPCs, ENet & WebSocket Networking

Estimated study time: 100 min · Godot 4.x · GDScript

## Chapter Overview

Godot 4's multiplayer system is built around a single powerful abstraction:
 the **MultiplayerAPI**. You write the same game logic regardless of whether
 you use ENet (UDP-based, fast, for games), WebSocket (browser-compatible), or a custom
 transport. On top of the API sit two key tools: **@rpc** annotations that
 call functions across the network, and the **MultiplayerSynchronizer** node
 that automatically syncs properties without manual RPC calls.

:::callout-tip[Prerequisites]
GDScript signals and nodes. No prior networking experience required.
:::

## Core Multiplayer Concepts

:::callout-intuition[Intuition — The Post Office Model]
Think of multiplayer as a post office. Every player is a

peer

with a unique address
  (peer ID). The server is the post office master (peer 1). When you call an RPC, you're
  sending a letter: you address it (to whom), say what to do (which function), and include
  arguments (the message). The MultiplayerAPI handles delivery — you just write the code.
:::

### Peer IDs and Authority

| Concept | Value / meaning |
| --- | --- |
| Server peer ID | Always `1` |
| Client peer IDs | Random integers assigned on connection (e.g., 1234567) |
| `multiplayer.get_unique_id()` | This peer's own ID |
| `multiplayer.is_server()` | `true` on the hosting peer |
| `node.get_multiplayer_authority()` | Which peer ID "owns" this node (controls it) |
| `node.is_multiplayer_authority()` | `true` if this peer owns the node |

Every node has a **multiplayer authority** — the peer that is allowed to change
 its state. By default all nodes are authority of the server (peer 1). When a player joins,
 you call `player_node.set_multiplayer_authority(peer_id)` to give that client
 authority over their own character.

### Network Topology

| Topology | Description | Godot support |
| --- | --- | --- |
| Listen Server (client-hosted) | One player runs the server. Simple, no dedicated hardware. | ✓ Default for small games |
| Dedicated Server | Headless process on a VPS. Authoritative, cheat-resistant. | ✓ Headless export + `--headless` flag |
| Peer-to-Peer | All peers equal. Complex, NAT traversal needed. | Partial (no built-in relay) |

## ENet Setup — Host and Join

ENet is a reliable UDP networking library — it gives you TCP-like reliability channels
 while keeping the low latency of UDP. It's the default choice for real-time games.

### Creating a Server

```gdscript
## NetworkManager.gd (autoload)
extends Node

const PORT    := 7777
const MAX_PLAYERS := 8

signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal server_disconnected

func host_game() -> Error:
    var peer := ENetMultiplayerPeer.new()
    var err  := peer.create_server(PORT, MAX_PLAYERS)
    if err != OK:
        return err
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    return OK

func join_game(address: String) -> Error:
    var peer := ENetMultiplayerPeer.new()
    var err  := peer.create_client(address, PORT)
    if err != OK:
        return err
    multiplayer.multiplayer_peer = peer
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)
    return OK

func _on_peer_connected(id: int) -> void:
    print("Peer connected: ", id)
    player_connected.emit(id)

func _on_peer_disconnected(id: int) -> void:
    print("Peer disconnected: ", id)
    player_disconnected.emit(id)

func _on_connected_to_server() -> void:
    print("Connected! My ID: ", multiplayer.get_unique_id())

func _on_connection_failed() -> void:
    push_error("Connection failed")

func _on_server_disconnected() -> void:
    multiplayer.multiplayer_peer = null
    server_disconnected.emit()

func disconnect_from_game() -> void:
    multiplayer.multiplayer_peer = null
```

:::callout-tip[Headless Dedicated Server]
Export your project with "Headless" export preset. Run with:

./game.x86\_64 --headless -- server

. In GDScript detect server mode:

```gdscript
func _ready() -> void:
    if "--server" in OS.get_cmdline_user_args():
        NetworkManager.host_game()
    else:
        $UI.show_main_menu()
```
:::

## Remote Procedure Calls (RPCs)

:::callout-intuition[Intuition]
An RPC is a function call that travels over the network. You write

\_take\_damage(10)

as if it's local, and Godot sends the call (and arguments) to the correct peer where the
  function actually executes. The

@rpc

annotation controls who can call it and
  who receives it.
:::

### The @rpc Annotation

```gdscript
@rpc(mode, sync, transfer_mode, transfer_channel)
func my_function() -> void: pass
```

| Parameter | Options | Meaning |
| --- | --- | --- |
| **mode** | `"authority"` (default) | Only the multiplayer authority of this node can call this RPC |
| `"any_peer"` | Any connected peer can call this RPC |
| `"call_local"` | Also execute on the caller (not just remote) |
| (implied by others) | — |
| **sync** | `"call_remote"` (default) | Only run on remote peers, not the caller |
| `"call_local"` | Run on both caller and all targeted remotes |
| **transfer\_mode** | `"reliable"` (default) | Guaranteed delivery, ordered — like TCP |
| `"unreliable"` | Fire and forget — fast, may drop or reorder |
| `"unreliable_ordered"` | Drops old packets but preserves order of received ones |
| **transfer\_channel** | 0–255 | Separate reliable channels to avoid head-of-line blocking |

#### Targeting Specific Peers

```gdscript
## Send RPC to everyone (server calls → all clients receive):
take_damage.rpc(10)

## Send to a specific peer only:
take_damage.rpc_id(peer_id, 10)

## Call on local peer AND send to all remotes:
# Use @rpc("any_peer", "call_local") on the function definition
```

### Typical RPC Patterns

#### Pattern 1 — Client → Server (Input Forwarding)

```gdscript
## Player.gd
## Client sends their input to the server; server validates and updates state.

@rpc("any_peer", "call_remote", "unreliable_ordered")
func send_input(direction: Vector2) -> void:
    if not multiplayer.is_server(): return          # only server processes
    if multiplayer.get_remote_sender_id() != get_multiplayer_authority(): return  # auth check
    velocity = direction.normalized() * SPEED
    move_and_slide()

func _physics_process(_delta: float) -> void:
    if not is_multiplayer_authority(): return       # only authority sends input
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    send_input.rpc_id(1, dir)                       # send to server (peer 1)
```

#### Pattern 2 — Server → Clients (State Broadcast)

```gdscript
## GameState.gd (server-side)
var _health: Dictionary = {}   # peer_id -> int

func apply_damage(target_id: int, amount: int) -> void:
    _health[target_id] = max(0, _health.get(target_id, 100) - amount)
    _sync_health.rpc(_health)   # broadcast to all clients

@rpc("authority", "call_local", "reliable")
func _sync_health(state: Dictionary) -> void:
    for peer_id in state:
        var player := _get_player(peer_id)
        if player:
            player.set_health(state[peer_id])
```

#### Pattern 3 — Server → One Client (Private message)

```gdscript
@rpc("authority", "call_remote", "reliable")
func receive_private_message(text: String) -> void:
    $ChatBox.add_message("[Server] " + text)

# On server:
receive_private_message.rpc_id(target_peer_id, "You won the round!")
```

### MultiplayerSynchronizer — Automatic Property Sync

Writing RPCs for every property is tedious. **MultiplayerSynchronizer** lets
 you declare which properties to sync and handles the network traffic automatically.

1. Add a **MultiplayerSynchronizer** node as a child of the node you want to sync.
2. In the Inspector, click *Add Property* and select the property (e.g., `position`, `health`).
3. Set the authority to the peer that owns the data.
4. Choose *Replication Interval* (0 = every frame, 0.1 = 10 Hz).

```gdscript
## Player.gd — just set authority; synchronizer handles the rest
func _ready() -> void:
    $MultiplayerSynchronizer.set_multiplayer_authority(
        str(name).to_int()   # node name is set to peer_id by the spawner
    )

## MultiplayerSynchronizer in the scene syncs:
## - position  (unreliable, every frame)
## - health     (reliable, on_change)
## automatically. No manual RPC needed for these.
```

## MultiplayerSpawner — Network Object Instantiation

When the server spawns a new player or enemy, all clients must see it too.
 **MultiplayerSpawner** replicates instantiation automatically.

```gdscript
## In the scene: GameWorld -> MultiplayerSpawner (set Spawn Path = $Players)
## Add player.tscn to the Spawnable Scenes list in Inspector.

## GameWorld.gd — server calls this
func spawn_player(peer_id: int) -> void:
    if not multiplayer.is_server(): return
    var player := preload("res://player.tscn").instantiate()
    player.name = str(peer_id)           # name must be unique and peer_id for authority to work
    $Players.add_child(player, true)     # true = use readable names (important for network sync)
    player.set_multiplayer_authority(peer_id)

## This single add_child() causes MultiplayerSpawner to replicate the
## instantiation to all clients automatically. Clients see the node appear
## in their $Players without any additional code.
```

:::callout-warning[Node Names Must Match]
For MultiplayerSynchronizer and MultiplayerSpawner to work correctly, node paths must be
  identical on all peers. Always use

add\_child(node, true)

(readable names mode)
  and name nodes deterministically (e.g., the peer ID).
:::

## WebSocket Transport

WebSocket allows multiplayer games to run in a browser (HTML5 export).
 The API is identical to ENet — only the peer setup differs:

```gdscript
## WebSocket server (usually run on a VPS with HTTPS/wss)
func host_websocket(port: int) -> Error:
    var peer := WebSocketMultiplayerPeer.new()
    var err  := peer.create_server(port)
    if err != OK: return err
    multiplayer.multiplayer_peer = peer
    return OK

## WebSocket client (browser connects to wss://yourserver.com:PORT)
func join_websocket(url: String) -> Error:
    var peer := WebSocketMultiplayerPeer.new()
    var err  := peer.create_client(url)
    if err != OK: return err
    multiplayer.multiplayer_peer = peer
    return OK
```

All `@rpc` calls, MultiplayerSynchronizer, and MultiplayerSpawner work
 identically over WebSocket. Switch transports by swapping the peer object assigned
 to `multiplayer.multiplayer_peer`.

:::callout-tip[ENet vs WebSocket]
- **ENet** — better performance, lower latency. Use for PC/mobile native builds.
- **WebSocket** — required for browser (HTML5) targets. Slightly higher overhead.
- **WebRTC** — browser peer-to-peer (no server needed for game traffic). Available via the WebRTC GDExtension addon.
:::

## Worked Example — Complete Lobby + Gameplay Flow

The following ties all concepts together: a lobby where players connect, a server
 that spawns them, and in-game damage via RPC.

#### Step 1 — Network Manager (autoload)

```gdscript
## NetworkManager.gd
extends Node

const PORT    := 7777
const MAX     := 4

var players: Dictionary = {}   # peer_id -> { name, ready }
signal player_list_changed

func host(player_name: String) -> void:
    players[1] = { "name": player_name, "ready": false }
    var peer := ENetMultiplayerPeer.new()
    peer.create_server(PORT, MAX)
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)

func join(address: String, player_name: String) -> void:
    var peer := ENetMultiplayerPeer.new()
    peer.create_client(address, PORT)
    multiplayer.multiplayer_peer = peer
    multiplayer.connected_to_server.connect(
        func(): register_player.rpc_id(1, multiplayer.get_unique_id(), player_name)
    )

@rpc("any_peer", "call_remote", "reliable")
func register_player(id: int, pname: String) -> void:
    if not multiplayer.is_server(): return
    players[id] = { "name": pname, "ready": false }
    sync_players.rpc(players)

@rpc("authority", "call_local", "reliable")
func sync_players(state: Dictionary) -> void:
    players = state
    player_list_changed.emit()

func _on_peer_connected(id: int) -> void:
    # Send current player list to newly joined peer
    sync_players.rpc_id(id, players)

func _on_peer_disconnected(id: int) -> void:
    players.erase(id)
    sync_players.rpc(players)
```

#### Step 2 — Game World (server spawns players)

```gdscript
## GameWorld.gd
extends Node

## MultiplayerSpawner child: Spawn Path = $Players, Spawnable = player.tscn

func _ready() -> void:
    if multiplayer.is_server():
        for peer_id in NetworkManager.players:
            _spawn_player(peer_id)

func _spawn_player(peer_id: int) -> void:
    var player := preload("res://player.tscn").instantiate()
    player.name = str(peer_id)
    player.position = _spawn_point_for(peer_id)
    $Players.add_child(player, true)
    player.set_multiplayer_authority(peer_id)

func _spawn_point_for(peer_id: int) -> Vector2:
    var spawn_points := $SpawnPoints.get_children()
    var idx          := NetworkManager.players.keys().find(peer_id)
    return spawn_points[idx % spawn_points.size()].global_position
```

#### Step 3 — Player (authority-based input + RPC damage)

```gdscript
## Player.gd
extends CharacterBody2D

var health := 100

@rpc("any_peer", "call_local", "reliable")
func take_damage(amount: int) -> void:
    # Validate: only the server should process damage
    if multiplayer.is_server():
        health -= amount
        if health <= 0:
            _die.rpc()

@rpc("authority", "call_local", "reliable")
func _die() -> void:
    queue_free()

func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority(): return
    var dir := Input.get_vector("move_left","move_right","move_up","move_down")
    velocity = dir * 200.0
    move_and_slide()
    # MultiplayerSynchronizer handles broadcasting position to all clients
```

#### Step 4 — Projectile hitting a player

```gdscript
## Projectile.gd — only runs meaningful collision on server
extends Area2D

func _on_body_entered(body: Node) -> void:
    if not multiplayer.is_server(): return
    if body.has_method("take_damage"):
        body.take_damage.rpc(25)   # server calls RPC → all clients see health drop
    queue_free()
```

:::summary
### Chapter 63 — Quick Reference

| Concept | API | Key note |
| --- | --- | --- |
| Host game (ENet) | `ENetMultiplayerPeer.create_server(port, max)` | Assign to `multiplayer.multiplayer_peer` |
| Join game (ENet) | `ENetMultiplayerPeer.create_client(addr, port)` | Same assignment pattern |
| My peer ID | `multiplayer.get_unique_id()` | Server is always 1 |
| Am I server? | `multiplayer.is_server()` | Use for server-side authority checks |
| Node authority | `node.set_multiplayer_authority(id)` | Set on server after spawning |
| Call RPC (all) | `func_name.rpc(args)` | Sends to all connected peers |
| Call RPC (one peer) | `func_name.rpc_id(peer_id, args)` | Targeted delivery |
| Who sent RPC? | `multiplayer.get_remote_sender_id()` | Use inside @rpc function for auth checks |
| Auto property sync | MultiplayerSynchronizer node | Add properties in Inspector; set authority |
| Auto object spawn | MultiplayerSpawner node | add\_child() on server replicates to clients |
| Browser transport | `WebSocketMultiplayerPeer` | Same API as ENet, required for HTML5 |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Peer ID & Authority

In a 4-player game, player A has peer ID 1 (host) and player B has peer ID 234567.
 Player B controls their character node. Write the one-line call to give player B
 authority over their node, and write the one-line guard inside
 `_physics_process()` so only player B sends input from their machine.

::::solution[Solution]
```gdscript
## Give player B authority (called on server when spawning):
player_b_node.set_multiplayer_authority(234567)

## Guard in _physics_process (runs on all peers, but only B passes):
func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority(): return
    # ... process input ...
```
::::
:::

:::problem{difficulty="easy"}
#### 2. @rpc Annotation Selection

Choose the correct `@rpc` annotation for each scenario:
 (a) A function that the server calls to tell all clients to play an explosion sound.
 (b) A function that a client calls to tell the server they pressed the "fire" button.
 (c) A function that plays a sound only on the peer that called it (no network send).

::::solution[Solution]
**(a)** Server → all clients, reliable (sound must play):

```gdscript
@rpc("authority", "call_remote", "reliable")
func play_explosion(position: Vector2) -> void:
    $AudioPlayer.play_at(position)
```

**(b)** Client → server only:

```gdscript
@rpc("any_peer", "call_remote", "reliable")
func request_fire() -> void:
    if not multiplayer.is_server(): return
    var sender_id := multiplayer.get_remote_sender_id()
    # validate and process fire for sender_id
```

**(c)** Local only — don't use @rpc at all, just call the function normally. @rpc sends over the network; a local call is just a regular function call.
::::
:::

:::problem{difficulty="standard"}
#### 3. Simple Chat System

Write a chat autoload with:
 (a) `send_message(text: String)` — the local player sends a message,
 (b) an RPC that delivers it to all peers including the sender,
 (c) a signal `message_received(sender_id: int, text: String)` that
 the UI connects to for display.

::::solution[Solution]
```gdscript
## Chat.gd (autoload)
extends Node

signal message_received(sender_id: int, text: String)

func send_message(text: String) -> void:
    # Relay through server to prevent spoofing
    _deliver_to_server.rpc_id(1, text)

@rpc("any_peer", "call_remote", "reliable")
func _deliver_to_server(text: String) -> void:
    if not multiplayer.is_server(): return
    var sender_id := multiplayer.get_remote_sender_id()
    # Broadcast to everyone including server itself
    _broadcast.rpc(sender_id, text)

@rpc("authority", "call_local", "reliable")
func _broadcast(sender_id: int, text: String) -> void:
    message_received.emit(sender_id, text)
```
::::
:::

:::problem{difficulty="standard"}
#### 4. MultiplayerSynchronizer Setup

Describe the exact steps (editor + code) to set up a MultiplayerSynchronizer on
 a `Player` node so that `position` syncs 30 times per second
 (unreliable) and `health` syncs on change (reliable, immediately).

::::solution[Solution]
1. Add a **MultiplayerSynchronizer** node as a child of the `Player` node.
2. Select it in the Scene dock → Inspector → *Root Path*: set to `.` (the Player node itself).
3. Under *Replication*, click *Add Property* → select `Node2D:position`.
4. For `position`: set *Sync* = On, *Mode* = Always, *Delta* = 0.033 (≈30 Hz), transfer mode = Unreliable.
5. Click *Add Property* again → select `Player:health` (your custom property).
6. For `health`: set *Sync* = On, *Mode* = On Change, transfer mode = Reliable.
7. In `Player.gd` `_ready()`, set authority: `$MultiplayerSynchronizer.set_multiplayer_authority(int(name))` (assuming node name = peer\_id).

No RPC code needed — the Synchronizer handles all property replication automatically.
::::
:::

:::problem{difficulty="challenge"}
#### 5. Cheat-Proof Damage

A malicious client modifies their game to call `take_damage.rpc_id(1, enemy_id, 99999)`
 directly. Explain why this is dangerous, then rewrite the `take_damage` RPC
 so it (a) validates the sender has authority to deal damage (e.g. they hold the weapon),
 (b) caps damage to a reasonable max, (c) only executes game logic on the server.

::::solution[Solution]
**Why it's dangerous:** with `@rpc("any_peer")` and no validation,
 any client can call the function with arbitrary arguments — including one-shot killing any
 target or dealing negative damage (healing).

```gdscript
const MAX_DAMAGE_PER_HIT := 50

@rpc("any_peer", "call_remote", "reliable")
func request_damage(target_node_path: NodePath, amount: int) -> void:
    # 1. Only server processes this
    if not multiplayer.is_server(): return

    # 2. Validate the sender has a weapon (authority check)
    var sender_id  := multiplayer.get_remote_sender_id()
    var sender     := get_tree().get_first_node_in_group("player_%d" % sender_id)
    if sender == null or not sender.has_weapon_equipped(): return

    # 3. Validate target exists
    var target := get_node_or_null(target_node_path)
    if target == null or not target.has_method("apply_damage"): return

    # 4. Cap damage
    var safe_amount := clampi(amount, 0, MAX_DAMAGE_PER_HIT)

    # 5. Apply on server; sync via MultiplayerSynchronizer
    target.apply_damage(safe_amount)
```

The key insight: the server never trusts client-supplied values. It validates identity,
 existence, and clamps any numeric argument before acting on it.
::::
:::
