---
title: "Vampire Survivors Clone — Design Sheet"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71"
meta:
  - "Est. study time: ~30 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated May 2026"
source: "godot_ch71_design_sheet.html"
---

## Game Concept

**Vampire Survivors** (Poncle, 2021) is a reverse bullet-hell survivor game:
 instead of dodging enemy fire, the player is surrounded by hundreds of enemies and
 their weapons fire *automatically*. The player only controls movement. The game
 loop is: survive → kill enemies → collect XP gems → level up → pick a weapon upgrade
 → repeat until 30 minutes expire or you die.

This series builds a feature-complete clone in Godot 4 we call **Relic Horde**.
 It covers every system in the original: player movement, three weapon archetypes
 (AOE pulse, orbit projectile, thrown arc), three enemy types, XP gems with a magnet
 range, the level-up pause with upgrade cards, wave-based spawning, object pooling
 for performance, and a 30-minute run timer.

:::callout-key[What you will build]
A fully playable single-session survival game. By Ch 71H the game runs at 60 fps
 with 200+ enemies on screen, exports to Windows/Linux/Web, and is ready to record
 for YouTube or ship on itch.io.
:::

### Chapter map

| Chapter | Topic | Key systems |
| --- | --- | --- |
| 71 (this) | Design Sheet | GDD, architecture, all scripts defined |
| 71A | Scene Setup | Project, world, TileMapLayer, Camera2D + limits |
| 71B | Player | CharacterBody2D, 8-dir movement, stat resource |
| 71C | Enemies | EnemyBase, 3 types, NavigationAgent2D, spawner |
| 71D | Weapons | WeaponBase, Garlic AOE, Magic Wand, Axe arc |
| 71E | XP & Level-up | XpGem, magnet, UpgradeCard UI, pause tree |
| 71F | GameManager | Run timer, wave config, death/win screens |
| 71G | Polish | Hit flash, death burst, screen shake, SFX |
| 71H | Export | ObjectPool, draw-call batching, platform targets |

## Three Laws of Relic Horde

:::callout-intuition[Design constraints]
These rules govern every architecture decision in this series. When in doubt,
 check them first.
:::

:::definition
#### Law 1 — The player only moves

WASD / left-stick controls movement. The player never aims, never presses a fire
 button, and never manually activates an ability. All attacking is handled by
 **weapon nodes** running their own timers.
:::

:::definition
#### Law 2 — Weapons are composable components

The player carries an `Array[WeaponBase]`. Each weapon is a separate
 scene attached as a child of the player's `WeaponHolder` node. Adding a new
 weapon type means creating one new scene — no changes to Player.gd.
:::

:::definition
#### Law 3 — Everything that spawns frequently uses a pool

Projectiles, XP gems, and hit-effect particles are all obtained from an
 `ObjectPool` autoload and returned when done. `queue_free()`
 is reserved for enemies and one-off objects. This keeps frame time flat at
 200+ entities.
:::

## Core Loop

```
START RUN
  │
  ▼
SPAWN WAVE (EnemySpawner — timer fires every 5s, increases count)
  │
  ▼
FIGHT (player moves, weapons auto-fire, enemies navigate toward player)
  │
  ├─ Enemy dies → drop XpGem → player enters magnet range → gem moves to player
  │                                    │
  │                                    ▼
  │                           XP total crosses threshold?
  │                                    │ YES
  │                                    ▼
  │                           Pause tree → show 3 UpgradeCards
  │                                    │ player picks one
  │                                    ▼
  │                           WeaponHolder.add_weapon(scene) or upgrade stats
  │                                    │
  │                           Unpause tree → resume
  │
  ├─ Player HP ≤ 0 → GameManager.game_over()
  │
  └─ Run timer reaches 30:00 → GameManager.victory()
```

:::callout-tip[No save system needed]
A run is a single session. There is no persistent progress between runs in the
 base implementation — each new run starts fresh. Ch 48 (Save Slots) covers
 adding persistent meta-progression (unlocked characters, purchased upgrades)
 as an extension exercise.
:::

## Scene Hierarchy

### Main.tscn (root)

```
Main (Node2D)                    ← Main.gd — coordinates autoloads
├── World (Node2D)
│   ├── TileMapLayer              ← infinite-feel grass/floor tiles
│   └── EnemyContainer (Node2D)  ← all live enemy instances parented here
├── Player (CharacterBody2D)     ← Player.gd
│   ├── CollisionShape2D         ← CapsuleShape2D
│   ├── Sprite2D                 ← animated character sprite
│   ├── HurtBox (Area2D)         ← Layer 2, Mask 4 — receives enemy damage
│   │   └── CollisionShape2D
│   ├── MagnetArea (Area2D)      ← Layer 2, Mask 3 — attracts nearby XP gems
│   │   └── CollisionShape2D     ← CircleShape2D, radius = magnet_range
│   ├── WeaponHolder (Node2D)    ← child weapon scenes attach here
│   └── StatResource (Resource)  ← PlayerStats resource exported on player
├── HUD (CanvasLayer)            ← HUD.gd — HP bar, XP bar, run timer, kill count
├── UpgradeScreen (CanvasLayer)  ← UpgradeScreen.gd — hidden until level-up
└── NavigationRegion2D           ← baked navmesh covering the world bounds
```

### Enemy.tscn (base scene, inherited by each type)

```
Enemy (CharacterBody2D)          ← EnemyBase.gd
├── CollisionShape2D
├── Sprite2D
├── HitBox (Area2D)              ← Layer 4, Mask 2 — deals damage to player
│   └── CollisionShape2D
├── NavigationAgent2D            ← pathfinding toward player
└── HealthBar (ProgressBar)      ← visible HP (optional; hide on basic enemies)
```

### XpGem.tscn

```
XpGem (Area2D)                   ← XpGem.gd; obtained from ObjectPool
├── CollisionShape2D             ← Layer 3, Mask 2 (player MagnetArea detects it)
└── Sprite2D
```

### Projectile.tscn

```
Projectile (Area2D)              ← Projectile.gd; obtained from ObjectPool
├── CollisionShape2D             ← Layer 5, Mask 4 (hits enemies)
├── Sprite2D
└── VisibleOnScreenNotifier2D    ← returns to pool when off-screen
```

## Player Architecture

### PlayerStats resource

All numeric attributes live in a `PlayerStats` resource that is shared
 between Player.gd and the upgrade system. Upgrading a stat means editing one
 property on the resource — nothing else changes.

```gdscript
class_name PlayerStats
extends Resource

@export var max_hp: float        = 100.0
@export var move_speed: float    = 120.0
@export var magnet_range: float  = 80.0
@export var xp_multiplier: float = 1.0
@export var armor: float         = 0.0        # flat damage reduction

## Runtime — not exported; reset each run.
var current_hp: float
var current_xp: float
var level: int = 1
var xp_to_next: float = 50.0

func _init() -> void:
    current_hp = max_hp
```

### Player.gd outline

```gdscript
class_name Player
extends CharacterBody2D

@export var stats: PlayerStats
@onready var weapon_holder: Node2D    = $WeaponHolder
@onready var magnet_area: Area2D      = $MagnetArea
@onready var hurt_box: Area2D         = $HurtBox

signal died
signal xp_changed(new_xp: float, needed: float)
signal hp_changed(new_hp: float, max_hp: float)

func _physics_process(delta: float) -> void:
    ## Law 1: movement only
    var dir := Input.get_vector("move_left","move_right","move_up","move_down")
    velocity = dir * stats.move_speed
    move_and_slide()

func take_damage(amount: float) -> void:
    var effective := maxf(0.0, amount - stats.armor)
    stats.current_hp -= effective
    hp_changed.emit(stats.current_hp, stats.max_hp)
    if stats.current_hp <= 0.0:
        died.emit()

func gain_xp(amount: float) -> void:
    stats.current_xp += amount * stats.xp_multiplier
    xp_changed.emit(stats.current_xp, stats.xp_to_next)
    if stats.current_xp >= stats.xp_to_next:
        _level_up()

func _level_up() -> void:
    stats.current_xp -= stats.xp_to_next
    stats.level += 1
    stats.xp_to_next = floor(stats.xp_to_next * 1.25)
    GameManager.trigger_level_up()
```

## Weapon Architecture

:::callout-intuition[Design — weapons are autonomous nodes]
Each weapon runs its own `_physics_process` and fires on its own
 cooldown timer. The player never triggers weapons. Adding a weapon is as simple
 as instantiating its scene and parenting it to `WeaponHolder`.
:::

### WeaponBase.gd

```gdscript
class_name WeaponBase
extends Node2D

@export var damage: float         = 10.0
@export var cooldown: float       = 1.0
@export var area: float           = 60.0   ## radius / range depending on weapon type
@export var projectile_count: int = 1
@export var weapon_level: int     = 1

var _player: Player
var _cooldown_timer: float = 0.0

func _ready() -> void:
    _player = get_parent().get_parent() as Player   ## WeaponHolder → Player

func _physics_process(delta: float) -> void:
    _cooldown_timer -= delta
    if _cooldown_timer <= 0.0:
        _cooldown_timer = cooldown
        _fire()

## Override in subclass.
func _fire() -> void:
    pass

## Called by upgrade system when weapon_level increases.
func apply_upgrade(upgrade: WeaponUpgradeResource) -> void:
    damage   += upgrade.damage_bonus
    cooldown  = maxf(0.1, cooldown - upgrade.cooldown_reduction)
    area     += upgrade.area_bonus
```

### Three weapon archetypes

| Weapon | Class | Mechanic | Key node |
| --- | --- | --- | --- |
| Garlic | `GarlicWeapon` | AOE pulse — damages all enemies inside a radius each tick | Area2D with CircleShape2D; resize to `area` each tick |
| Magic Wand | `MagicWandWeapon` | Fires a fast projectile at the nearest enemy | Spawns `Projectile` from ObjectPool; aims at closest |
| Axe | `AxeWeapon` | Throws arc-trajectory projectile, bounces once | Spawns `AxeProjectile`; applies parabolic offset in \_process |

### Finding the nearest enemy

```gdscript
## In WeaponBase — utility shared by ranged weapons.
func _get_nearest_enemy() -> Node2D:
    var container := get_tree().get_first_node_in_group("enemy_container")
    if not container:
        return null
    var nearest: Node2D = null
    var best_dist := INF
    for child in container.get_children():
        var d := _player.global_position.distance_squared_to(child.global_position)
        if d < best_dist:
            best_dist = d
            nearest = child
    return nearest
```

:::callout-warning[Performance note]
`get_children()` on a 200-enemy container every weapon tick is fine
 at beginner scale. Ch 71H replaces this with a spatial hash for the advanced
 performance pass.
:::

## Enemy Architecture

### EnemyBase.gd

```gdscript
class_name EnemyBase
extends CharacterBody2D

@export var max_hp: float      = 30.0
@export var move_speed: float  = 60.0
@export var damage: float      = 10.0
@export var xp_value: int      = 5
@export var xp_gem_scene: PackedScene

var _hp: float
var _player: Player
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

signal died(enemy: EnemyBase)

func _ready() -> void:
    _hp = max_hp
    _player = get_tree().get_first_node_in_group("player")
    add_to_group("enemies")

func _physics_process(delta: float) -> void:
    if not is_instance_valid(_player):
        return
    nav_agent.target_position = _player.global_position
    var next := nav_agent.get_next_path_position()
    velocity = (next - global_position).normalized() * move_speed
    move_and_slide()

func take_damage(amount: float) -> void:
    _hp -= amount
    if _hp <= 0.0:
        _die()

func _die() -> void:
    died.emit(self)
    _drop_gem()
    queue_free()

func _drop_gem() -> void:
    var gem: XpGem = ObjectPool.acquire("XpGem")
    gem.global_position = global_position
    gem.value = xp_value
    get_parent().add_child(gem)
```

### Three enemy types

| Enemy | Scene | HP | Speed | XP | Trait |
| --- | --- | --- | --- | --- | --- |
| Bat | Bat.tscn | 15 | 90 | 2 | Fast, low HP — swarms early |
| Skeleton | Skeleton.tscn | 60 | 50 | 8 | Balanced; main mid-game enemy |
| Golem | Golem.tscn | 300 | 25 | 40 | Slow tank; appears after 15 min |

### EnemySpawner.gd outline

```gdscript
class_name EnemySpawner
extends Node

@export var enemy_scenes: Array[PackedScene] = []
@export var spawn_radius: float = 640.0   ## off-screen ring radius

var _wave_timer: float = 5.0
var _spawn_count: int  = 3

func _physics_process(delta: float) -> void:
    _wave_timer -= delta
    if _wave_timer <= 0.0:
        _wave_timer = 5.0
        _spawn_wave()

func _spawn_wave() -> void:
    var player_pos := _get_player_pos()
    for i in _spawn_count:
        var angle := randf() * TAU
        var pos   := player_pos + Vector2(cos(angle), sin(angle)) * spawn_radius
        var scene := enemy_scenes[randi() % enemy_scenes.size()]
        var enemy: EnemyBase = scene.instantiate()
        enemy.position = pos
        enemy_container.add_child(enemy)
    _spawn_count = int(_spawn_count * 1.05)  ## 5% more each wave
```

## XP Gems, Magnet & Levelling

### XpGem.gd

```gdscript
class_name XpGem
extends Area2D

var value: int = 5
var _attracting: bool = false
var _player: Player = null
const ATTRACT_SPEED := 200.0

## Called by player's MagnetArea.area_entered signal.
func start_attract(player: Player) -> void:
    _attracting = true
    _player = player

func _physics_process(delta: float) -> void:
    if not _attracting or not is_instance_valid(_player):
        return
    var dir := (_player.global_position - global_position).normalized()
    global_position += dir * ATTRACT_SPEED * delta
    if global_position.distance_to(_player.global_position) < 8.0:
        _player.gain_xp(value)
        ObjectPool.release("XpGem", self)   ## return to pool
```

### Level-up pause flow

```gdscript
## In GameManager.gd
func trigger_level_up() -> void:
    get_tree().paused = true          ## freeze physics and _process on all nodes
    var cards := _pick_three_upgrades()
    UpgradeScreen.show_cards(cards)   ## UpgradeScreen.gd populates and shows UI

## In UpgradeScreen.gd
func _on_card_chosen(upgrade: UpgradeResource) -> void:
    upgrade.apply(GameManager.player)  ## modifies PlayerStats or adds weapon
    hide()
    get_tree().paused = false          ## resume
```

### UpgradeResource

```gdscript
class_name UpgradeResource
extends Resource

@export var upgrade_name: String
@export var description: String
@export var icon: Texture2D

## The actual effect — subclass or use a typed enum + data-driven apply().
func apply(player: Player) -> void:
    pass   ## override per upgrade
```

:::callout-key[Process mode on UpgradeScreen]
The UpgradeScreen CanvasLayer and its buttons must have
 `process_mode = PROCESS_MODE_ALWAYS` so they receive input
 while the tree is paused. All other nodes default to
 `PROCESS_MODE_PAUSABLE`.
:::

## GameManager Autoload

```gdscript
## GameManager.gd — autoloaded as "GameManager"
extends Node

enum State { WAITING, PLAYING, LEVEL_UP, GAME_OVER, VICTORY }
var state: State = State.WAITING

var run_timer: float = 0.0
const RUN_DURATION: float = 30.0 * 60.0   ## 30 minutes in seconds
var kill_count: int = 0
var player: Player = null

signal state_changed(new_state: State)

func start_run(p: Player) -> void:
    player = p
    run_timer = 0.0
    kill_count = 0
    _set_state(State.PLAYING)

func _process(delta: float) -> void:
    if state != State.PLAYING:
        return
    run_timer += delta
    if run_timer >= RUN_DURATION:
        _set_state(State.VICTORY)

func on_enemy_killed() -> void:
    kill_count += 1

func trigger_level_up() -> void:
    _set_state(State.LEVEL_UP)

func game_over() -> void:
    _set_state(State.GAME_OVER)

func _set_state(s: State) -> void:
    state = s
    state_changed.emit(s)
```

## Physics Layers — 5-Layer Matrix

| Layer | Name | Used by | Mask (detects) |
| --- | --- | --- | --- |
| 1 | World | TileMapLayer StaticBody2D walls/obstacles | 2, 4 |
| 2 | Player | Player CharacterBody2D, Player HurtBox Area2D | 1, 4 |
| 3 | XpGems | XpGem Area2D; Player MagnetArea Area2D | 2 (MagnetArea detects 3) |
| 4 | Enemies | Enemy CharacterBody2D; Enemy HitBox Area2D | 1, 2 |
| 5 | Projectiles | Projectile Area2D (player weapons) | 4 (hits enemies only) |

:::callout-pitfall[Common mistake — projectiles hitting the player]
If Projectile Mask includes Layer 2, player projectiles will hit the player's
 own HurtBox. Projectiles must only have Layer 4 in their Mask. Enemy HitBoxes
 (Layer 4) hit the Player HurtBox (Layer 2) — that's intentional and separate.
:::

## Signal Flow Diagrams

### Damage chain (enemy → player)

```
Enemy HitBox.area_entered(player_hurt_box)
    → Player.take_damage(damage)
        → stats.current_hp decreases
        → hp_changed.emit()           → HUD updates HP bar
        → if hp ≤ 0: died.emit()      → GameManager.game_over()
```

### Weapon hit chain (projectile → enemy)

```
Projectile.area_entered(enemy_body)
    → EnemyBase.take_damage(damage)
        → _hp decreases
        → if _hp ≤ 0: died.emit()
            → GameManager.on_enemy_killed()   → kill_count++
            → XpGem spawned at enemy position
            → queue_free()
```

### XP gem → level-up chain

```
MagnetArea.area_entered(xp_gem)
    → xp_gem.start_attract(player)
        → gem moves toward player each frame
        → on contact: player.gain_xp(value)
            → stats.current_xp increases
            → xp_changed.emit()       → HUD updates XP bar
            → if xp ≥ threshold: _level_up()
                → GameManager.trigger_level_up()
                    → tree paused
                    → UpgradeScreen.show_cards()
                        → player picks card
                        → upgrade.apply(player)
                        → tree unpaused
```

### Run timer → victory

```
GameManager._process(delta)
    → run_timer += delta
    → HUD updates timer display
    → if run_timer ≥ 1800.0:
        → state = VICTORY
        → state_changed.emit(VICTORY)   → Main.gd shows victory screen
```

## Script Contracts

Every script's public API, summarised for cross-chapter reference.

| Script | Public signals | Public methods |
| --- | --- | --- |
| `Player.gd` | `died`, `hp_changed(hp,max)`, `xp_changed(xp,needed)` | `take_damage(n)`, `gain_xp(n)` |
| `EnemyBase.gd` | `died(enemy)` | `take_damage(n)` |
| `WeaponBase.gd` | — | `apply_upgrade(res)` |
| `XpGem.gd` | — | `start_attract(player)` |
| `GameManager.gd` | `state_changed(state)` | `start_run(player)`, `trigger_level_up()`, `game_over()` |
| `ObjectPool.gd` | — | `get(key)`, `release(key, obj)` |
| `UpgradeResource.gd` | — | `apply(player)` (virtual) |

## ObjectPool Autoload

:::callout-intuition[Why pool?]
At 200 enemies each dying and dropping a gem, and 3 weapons each firing
 projectiles every second, you will instantiate and free hundreds of nodes
 per second without pooling. Each `queue_free()` + instantiate pair
 causes a garbage-collection stall. Object pooling eliminates this by reusing
 pre-allocated nodes.
:::

```gdscript
## ObjectPool.gd — autoloaded as "ObjectPool"
extends Node

var _pools: Dictionary = {}          ## key: String → Array[Node]
var _scenes: Dictionary = {}         ## key: String → PackedScene

func register(key: String, scene: PackedScene, prealloc: int = 20) -> void:
    _scenes[key] = scene
    _pools[key]  = []
    for i in prealloc:
        var obj := scene.instantiate()
        obj.set_process(false)
        obj.set_physics_process(false)
        _pools[key].append(obj)

func acquire(key: String) -> Node:
    if _pools[key].is_empty():
        var obj := _scenes[key].instantiate()
        return obj
    var obj: Node = _pools[key].pop_back()
    obj.set_process(true)
    obj.set_physics_process(true)
    return obj

func release(key: String, obj: Node) -> void:
    obj.get_parent().remove_child(obj)
    obj.set_process(false)
    obj.set_physics_process(false)
    _pools[key].append(obj)
```

Register pools in `Main.gd._ready()` before spawning begins:

```gdscript
func _ready() -> void:
    ObjectPool.register("XpGem",     preload("res://scenes/XpGem.tscn"),     40)
    ObjectPool.register("Projectile",preload("res://scenes/Projectile.tscn"), 30)
    ObjectPool.register("HitEffect", preload("res://scenes/HitEffect.tscn"),  20)
```

## Build Checklist

Eight phases — one per chapter. Each phase must be verified before moving on.

#### Phase 1 — Scene Setup (Ch 71A)

- Project created, 1920×1080 viewport, gravity disabled
- TileMapLayer with 64×64 grass tile covers 4096×4096 world
- Camera2D follows player with limits set to world bounds
- NavigationRegion2D baked covering entire world
- EnemyContainer Node2D exists and is in group `"enemy_container"`

#### Phase 2 — Player (Ch 71B)

- Player moves with WASD at correct speed
- HurtBox receives damage and hp\_changed signal fires
- MagnetArea radius scales with `stats.magnet_range`
- PlayerStats resource is exported and editable in Inspector
- Player added to group `"player"`

#### Phase 3 — Enemies (Ch 71C)

- Bat, Skeleton, Golem scenes all navigate toward player
- EnemySpawner fires every 5 seconds, increasing count per wave
- Enemies deal damage on HitBox overlap
- Enemies drop XpGem on death via ObjectPool
- 200 enemies on screen maintains >45 fps

#### Phase 4 — Weapons (Ch 71D)

- Garlic AOE pulses and damages all enemies in radius
- Magic Wand fires projectile at nearest enemy
- Axe flies in arc and returns damage to enemy
- Weapons level up via apply\_upgrade()
- WeaponHolder can hold 6 weapon slots simultaneously

#### Phase 5 — XP & Level-Up (Ch 71E)

- XpGems attract to player when inside magnet range
- Gaining XP updates HUD bar and triggers level-up at threshold
- Level-up pauses tree, shows 3 upgrade cards
- Choosing a card applies upgrade and unpauses tree
- XpGems return to ObjectPool on pickup (no queue\_free)

#### Phase 6 — GameManager (Ch 71F)

- Run timer counts 30 minutes, displayed on HUD
- Timer expiry triggers VICTORY state and victory screen
- Player death triggers GAME\_OVER state and death screen
- Restart button reloads the main scene cleanly
- Kill counter displayed on HUD

#### Phase 7 — Polish (Ch 71G)

- Hit flash on enemy when damaged (modulate tween)
- Enemy death burst GPUParticles2D (pooled)
- Screen shake on player damage (Camera2D offset tween)
- SFX: footstep, weapon fire, enemy death, level-up chime
- Background music with seamless loop

#### Phase 8 — Export (Ch 71H)

- ObjectPool pre-allocates all frequent objects at run start
- Enemy spatial hash replaces linear distance scan
- Profiler confirms <8ms frame time at 200 enemies
- Windows, Linux, and Web exports configured and tested
- itch.io page ready for upload

:::summary
## Design Sheet Summary

| System | Node type | Key pattern |
| --- | --- | --- |
| Player | CharacterBody2D | move\_and\_slide only; no attack input |
| Weapons | Node2D children of WeaponHolder | Self-firing via \_physics\_process timer |
| Enemies | CharacterBody2D | NavigationAgent2D targets player each frame |
| XP gems | Area2D | ObjectPool; magnet attract then gain\_xp() |
| Level-up | CanvasLayer (process\_mode=ALWAYS) | Pause tree → show cards → apply → unpause |
| GameManager | Autoload | 4-state enum; run timer; kill counter |
| ObjectPool | Autoload | pre-alloc → get/release; no queue\_free for frequent objects |
| Physics layers | — | 1=World, 2=Player, 3=XpGems, 4=Enemies, 5=Projectiles |
:::
