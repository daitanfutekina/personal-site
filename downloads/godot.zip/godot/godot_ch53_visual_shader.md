---
title: "VisualShader — Node-Graph Shaders Without Writing GLSL"
source: "markdown"
---

Part VIII · Chapter 53

# VisualShader — Node-Graph Shaders Without Writing GLSL

Estimated study time: 65 min · Prerequisites: Ch 50 GDShader Fundamentals, Ch 51 Canvas Shaders, Ch 52 Spatial Shaders

## Chapter Overview

VisualShader is Godot's node-graph shader editor — the same concepts as code shaders (uniforms, UV, TIME, fragment/vertex stages) but wired together by dragging cables instead of writing GLSL. It's particularly valuable when you want to iterate visually, when you're working with artists who don't code, or when you need to prototype an effect quickly before deciding whether to clean it up in code.

Under the hood Godot compiles every VisualShader graph into real GDShader source code that you can inspect and copy. That means there's *zero* performance difference between a VisualShader and an equivalent hand-written shader — it's purely a workflow choice.

:::callout-key[Key ideas this chapter]
VisualShader nodes map 1-to-1 to GDShader concepts. The graph compiles to identical bytecode. The Expression node lets you drop raw GLSL anywhere in the graph. Uniforms declared inside VS are exposed in the Inspector just like code-shader uniforms.
:::

## What Is VisualShader?

:::callout-intuition[Intuition]
Think of it like Blender's Shader Editor or Unity's Shader Graph — every computation is a box, every data flow is a wire. You add a

Noise Texture

node, plug its output into a

Multiply

node, plug that into ALBEDO, and you have a texture-driven colour without touching a line of code.
:::

### VisualShader vs. Code Shader — When to Use Each

| Situation | Best pick | Reason |
| --- | --- | --- |
| Quick prototype / iterating visuals | VisualShader | Instant feedback, drag to reconnect |
| Complex math heavy on arrays/loops | Code shader | Loops in VS need Expression nodes |
| Artist-authored effects | VisualShader | No GLSL knowledge required |
| Reusable shader library | Code shader | Easier to diff, version-control, review |
| Teaching / learning GLSL | VisualShader → inspect output | Compare graph to generated code |
| Production PBR materials | Either | Identical performance |

Visual Shader (Node Graph)

UV Input

vec2 uv

NoiseTexture2D

noise: Texture

Mix

a, b, weight → out

Output

ALBEDO

✓ Visual — drag-connect nodes

Code Shader (GDShader text)

shader\_type

spatial;

uniform

sampler2D

noise;

void

fragment

() {

vec2

uv = UV;

float

n = texture(

noise, uv).r;

ALBEDO = mix(a, b, n);

}

✓ Precise — full GLSL expressiveness

The same "noise-blended material" built two ways: VisualShader node graph (left) connects nodes visually; code shader (right) writes the equivalent GLSL logic directly.

### Creating a VisualShader Resource

A VisualShader is stored in a `.tres` file just like any other resource. Create one via:

1. Select a MeshInstance3D (or Sprite2D / CanvasItem).
2. In the Inspector, click the *Material* property → *New StandardMaterial3D* (or *New ShaderMaterial*).
3. For a ShaderMaterial: click the *Shader* property → *New VisualShader*.
4. Click the VisualShader resource to open the VisualShader editor at the bottom panel.

:::callout-tip[Shortcut]
You can also right-click any material slot in the inspector and choose

New VisualShader

directly, skipping the intermediate ShaderMaterial step.
:::

## Editor Tour

### Graph Area Anatomy

When the VisualShader editor is open at the bottom of the screen you'll see:

- **Output node** — always present; pins on the left side correspond to the fragment/vertex built-ins (ALBEDO, ROUGHNESS, EMISSION, UV, VERTEX, etc.).
- **Add Node button / right-click** — opens the categorised node picker.
- **Shader type dropdown** — switch between *Fragment*, *Vertex*, and *Light* graphs (each is its own connected graph).
- **Preview checkbox** — toggle on nodes to see a live preview swatch of that node's output.
- **Show Generated Code button** — opens a popup showing the GLSL that Godot compiled from your graph. Invaluable for learning.

VisualShader

Fragment ▾

+ Add Node

Show Code

Input: UV

type: vec2

uv

Texture2D

uv

sampler

Preview ☐

rgb

Mix

a

b

weight

out

Output (Fragment)

ALBEDO

ROUGHNESS

METALLIC

EMISSION

NORMAL\_MAP

ALPHA

← Graph area: right-click to add nodes, drag ports to connect

Output node always present — its ports = built-in shader variables

Port color = data type  (teal=vec2  blue=float/vec3  green=output)

VisualShader editor anatomy: nodes live on the graph, ports are color-coded by type, and wire connections flow left→right into the always-present Output node.

### Node Category Reference

| Category | What's inside |
| --- | --- |
| Input | UV, TIME, VERTEX, NORMAL, FRAGCOORD, custom uniforms, constants |
| Output | The Output node pins — ALBEDO, ROUGHNESS, METALLIC, EMISSION, ALPHA, NORMAL\_MAP… |
| Math | Add, Subtract, Multiply, Divide, Abs, Floor, Ceil, Fract, Pow, Exp, Log, Mix, Clamp, Step, SmoothStep, Sin, Cos, Tan… |
| Vector | VectorOp (component-wise), VectorLen, VectorNormalize, VectorCompose, VectorDecompose, Dot, Cross, Reflect, Refract, FaceForward |
| Color | ColorConstant, ColorParameter (uniform), HSV adjustment, ColorRamp (gradient lookup), mix by scalar |
| Texture | Texture2D, Texture2DArray, Texture3D, Cubemap, NoiseTexture (inline), CurveTexture, LinearSceneDepth |
| Transform | TransformMult, TransformVecMult, OuterProduct, TransformCompose, TransformDecompose |
| Utility | If (branch), Switch, Is (zero/NaN/Inf), Comment, Relay (reroute) |
| Special | Expression (raw GLSL), CustomFunction (call external .gdshader snippet), GroupInput/Output (subgraph) |

## Your First VisualShader — UV Scrolling Sprite

We'll recreate the classic UV-scrolling texture from Ch 51 using only nodes, then inspect the generated code to see the 1-to-1 mapping.

### Goal

A 2D sprite that scrolls its texture horizontally over time. In code this is one line: `UV.x += TIME * speed;`

### Step-by-step in the Graph

1. Create a **Sprite2D** → ShaderMaterial → **New VisualShader**.
2. In the shader type dropdown, stay on **Fragment**.
3. Right-click the graph → **Input → UV** — adds a UV node (outputs a vec2).
4. Right-click → **Input → Time** — adds a TIME scalar node.
5. Right-click → **Input → Parameter (Float)** — rename it `speed`, default value `0.3`. This becomes an Inspector-exposed uniform.
6. Right-click → **Math → Multiply** — wire TIME into *a*, *speed* into *b*. Output is `TIME * speed`.
7. Right-click → **Vector → VectorCompose** — wire Multiply into the X slot, leave Y as 0.0. Output is a vec2 scroll offset.
8. Right-click → **Math → Add** (set to Vector mode) — wire UV into *a*, VectorCompose into *b*. Output is the scrolled UV.
9. Right-click → **Texture → Texture2D** — wire the scrolled UV into its *uv* input. Wire the *rgb* output pin into the Output node's **COLOR** pin (or ALBEDO for 3D).
10. Assign your sprite texture to the Texture2D node via its Inspector slot.

Press Play — the texture scrolls. Now click *Show Generated Code*. You'll see exactly the GDShader equivalent.

```
[UV] ──────────────────────────────────────→ [Add vec2] ──→ [Texture2D uv] ──→ OUTPUT.COLOR
[TIME] ──→ [Multiply] ──→ [VectorCompose] ──→ [Add vec2]
[speed ¶] ──→ [Multiply]
```

:::callout-connect[Generated Code]
Godot compiles that graph to something like:

void fragment() { COLOR = texture(TEXTURE, UV + vec2(TIME \* speed, 0.0)); }

Open "Show Generated Code" whenever you're curious — it's the fastest way to solidify your mental model.
:::

## Key Node Reference

### Input Nodes

| Node | Output type | Equivalent GLSL | Notes |
| --- | --- | --- | --- |
| UV | vec2 | `UV` | Canvas\_item: texture coords. Spatial: UV or UV2 |
| Time | float | `TIME` | Elapsed seconds since scene start |
| FragCoord | vec4 | `FRAGCOORD` | Screen-space pixel position (xy) + depth (z) |
| Normal | vec3 | `NORMAL` | View-space normal in fragment; object-space in vertex |
| Tangent | vec3 | `TANGENT` | Used for normal mapping |
| Vertex | vec3 | `VERTEX` | Vertex stage only — object-space position |
| Color | vec4 | `COLOR` | Per-vertex or modulate colour |
| ViewVector | vec3 | `VIEW` | Normalised direction from fragment to camera |
| Parameter (Float) | float | `uniform float …` | Exposes to Inspector |
| Parameter (Vec3/Color) | vec3/vec4 | `uniform vec3/vec4 …` | Colour picker in Inspector |
| Parameter (Texture2D) | sampler2D | `uniform sampler2D …` | Texture slot in Inspector |
| Constant (Float/Int/Vec) | various | Literal value | Inline constant — no Inspector exposure |

### Math Nodes

| Node | Operation | Works on |
| --- | --- | --- |
| Add / Subtract / Multiply / Divide | +, −, ×, ÷ | float or vector (component-wise) |
| Mix | `mix(a, b, t)` | float or vec3 — linear interpolate |
| Clamp | `clamp(x, min, max)` | float |
| Step | `step(edge, x)` | float — 0 if x<edge, else 1 |
| SmoothStep | `smoothstep(lo, hi, x)` | float — S-curve between lo and hi |
| Sin / Cos / Tan | Trig | float (radians) |
| Abs / Sign / Floor / Ceil / Fract / Round | Standard scalar ops | float |
| Pow | `pow(base, exp)` | float |
| Exp / Log | `exp(x)` / `log(x)` | float |
| Max / Min | `max(a,b)` / `min(a,b)` | float |

### Texture Nodes

| Node | Purpose | Key ports |
| --- | --- | --- |
| Texture2D | Sample a 2D texture | in: uv (vec2); out: rgb (vec3), a (float), rgba (vec4) |
| NoiseTexture | Procedural noise (no image needed) | Uses FastNoiseLite internally; uv input; out: value (float) |
| CurveTexture | Lookup a Curve resource by x∈[0,1] | in: uv.x; out: value (float) — great for custom falloffs |
| GradientTexture1D | Color ramp lookup | in: uv.x; out: color (vec3/vec4) |
| Texture2DArray | Sample array texture by index | in: uv, layer (float) |
| LinearSceneDepth | Read the depth buffer | out: depth (float) — needs `hint_depth_texture` |

### Vector Operation Nodes

| Node | Operation | Tip |
| --- | --- | --- |
| VectorCompose | x,y,z floats → vec3 | Also works as float,float → vec2 |
| VectorDecompose | vec3 → x,y,z floats | Useful to isolate one channel |
| Dot | `dot(a,b)` | Fresnel: `dot(NORMAL, VIEW)` |
| Cross | `cross(a,b)` | Compute tangent-space axes |
| Normalize | `normalize(v)` | Always normalise after transforming normals |
| VectorLen | `length(v)` | Distance from origin |
| Reflect | `reflect(I, N)` | Mirror a direction around a normal |
| VectorOp (Multiply) | Component-wise × | Multiply two textures together |

## The Expression Node — Escape Hatch to Raw GLSL

When you need a loop, a conditional branch, or multi-line logic that would require dozens of VS nodes, drop in an **Expression** node. It lets you write raw GLSL inside the graph.

### Using the Expression Node

1. Right-click the graph → **Special → Expression**.
2. Click the node header to expand the GLSL input area.
3. Define your input and output ports in the node's Inspector (name + type for each).
4. Write any valid GLSL in the body. The port names become local variables.
5. Wire inputs and outputs to other nodes normally.

```glsl
// Expression node: inputs: uv (vec2), time (float) | output: color (vec3)
// 8-sample blur loop — impossible to wire without Expression
vec3 col = vec3(0.0);
float w = 0.0;
for (int i = -1; i <= 1; i++) {
    for (int j = -1; j <= 1; j++) {
        vec2 off = vec2(float(i), float(j)) * 0.002;
        col += texture(TEXTURE, uv + off).rgb;
        w += 1.0;
    }
}
color = col / w;
```

:::callout-pitfall[Pitfall — Port names are case-sensitive]
The port name you set in the Expression node's Inspector becomes a local variable. If you name a port

UV

(capital), it shadows the built-in

UV

. Prefer lowercase for Expression ports:

uv\_in

, `time_in`, etc.
:::

## Uniforms (Parameters) in VisualShader

Every **Parameter node** you add in a VisualShader graph automatically declares a uniform and exposes it in the ShaderMaterial's Inspector. You can set the default value and (for floats) the min/max hint directly on the node.

### Setting Uniforms from GDScript

The workflow is identical to code shaders:

```gdscript
@onready var mat: ShaderMaterial = $Sprite2D.material

func _ready() -> void:
    mat.set_shader_parameter("speed", 0.5)
    mat.set_shader_parameter("tint_color", Color(1, 0.2, 0.2))

func _process(delta: float) -> void:
    # Animate a parameter at runtime
    var t := sin(Time.get_ticks_msec() * 0.001) * 0.5 + 0.5
    mat.set_shader_parameter("dissolve_threshold", t)
```

:::callout-tip[Naming matters]
The string you pass to

set\_shader\_parameter()

must exactly match the

Parameter Name

field on the Parameter node in the graph — not the node's display label.
:::

## Custom Function Node — Reusable GLSL Snippets

The **CustomFunction** node calls a function defined in a separate `.gdshader` file (or inline). This is the preferred way to share utility functions (noise, colour conversion, etc.) across multiple VisualShader graphs without copy-pasting.

### Workflow

1. Create a new file `res://shaders/utils.gdshader`.
2. Write your function(s) — no `shader_type` header needed, just the function body.
3. In the VS graph, add **Special → CustomFunction**.
4. In the Inspector: set *Function* to the file path, set the function name, and define input/output ports.

```glsl
// res://shaders/utils.gdshader
// No shader_type declaration — just bare functions

float remap(float value, float from_min, float from_max, float to_min, float to_max) {
    return to_min + (value - from_min) / (from_max - from_min) * (to_max - to_min);
}

vec3 hsv_to_rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
```

:::callout-tip[Inline vs. file]
You can also write the function inline in the node's

Code

property — handy for quick one-offs. Use the file approach for anything you'll reuse; it lets you edit in one place and have all graphs pick up changes automatically.
:::

## Worked Examples

### Example 1 — Dissolve Effect (2D or 3D)

**Answer first:** Wire a noise texture through a Step node into ALPHA. Animate the step threshold via a uniform to reveal or hide the sprite.

In code this is: `ALPHA = step(dissolve_amount, texture(noise_tex, UV).r);`

#### Node graph:

```
[UV] ──────────────────────────→ [NoiseTexture] ──→ [Step x] ──→ OUTPUT.ALPHA
[dissolve_amount ¶] (0.0–1.0) ──────────────────→ [Step edge]
```

#### Step-by-step:

1. Add a **NoiseTexture** node. In its Inspector create a new *FastNoiseLite*, set Noise Type to *Simplex Smooth*, frequency ~0.005.
2. Wire UV into the NoiseTexture's *uv* input. Take the *value* (float) output.
3. Add a **Parameter (Float)** named `dissolve_amount`, default 0.0, hint range 0.0–1.0.
4. Add a **Math → Step** node. Wire `dissolve_amount` → *edge*, noise value → *x*.
5. Wire Step output → **Output.ALPHA**.
6. On the ShaderMaterial set *Transparency* to Alpha (for 3D spatial) or ensure the CanvasItem uses a shader\_type canvas\_item.

From GDScript: `mat.set_shader_parameter("dissolve_amount", tween_value)` — animate 0 → 1 to dissolve the object out.

#### Adding a burn edge colour:

1. Add a **Math → Add** node: `dissolve_amount + 0.05` (use a Constant 0.05 as second input).
2. Add another **Step**: edge = `dissolve_amount + 0.05`, x = noise. This gives a slightly larger mask.
3. **Subtract** the two Step results: `big_mask - small_mask`. This isolates the thin edge band.
4. Add a **Parameter (Color)** named `burn_color`. Multiply it by the edge band result.
5. **Mix** base ALBEDO with burn colour using the edge band as the mix factor.

### Example 2 — Fresnel Rim Glow (Spatial 3D)

**Answer first:** `fresnel = pow(1.0 - dot(NORMAL, VIEW), rim_power)`, added to EMISSION.

#### Node graph:

```
[Normal] ──→ [Dot] ──→ [1 - x] ──→ [Pow base] ──→ [Multiply] ──→ [Add] ──→ OUTPUT.EMISSION
[View]   ──→ [Dot]
[rim_power ¶] ──────────→ [Pow exp]
[rim_color ¶] ──────────────────────→ [Multiply]
[base_emission_tex] ─────────────────────────────→ [Add]
```

#### Step-by-step:

1. Add **Input → Normal** and **Input → ViewVector** nodes.
2. Add **Vector → Dot**. Wire Normal → a, ViewVector → b.
3. Add **Math → Subtract**: a = Constant 1.0, b = Dot output → gives `1.0 - dot(N,V)`.
4. Add **Math → Pow**: base = Subtract, exp = `rim_power` Parameter (default 3.0).
5. Add **Parameter (Color)** named `rim_color`. Add a **VectorOp Multiply** to scale by it (VectorDecompose the color to rgb, multiply by Pow).
6. Wire into **Output.EMISSION**.

### Example 3 — 2D Water Ripple (Canvas Item)

**Answer first:** Distort UV with a scrolling sine wave on both axes, then sample SCREEN\_TEXTURE at the distorted UV.

```glsl
// What the generated code looks like:
void fragment() {
    vec2 distorted_uv = SCREEN_UV;
    distorted_uv.x += sin(UV.y * wave_freq + TIME * wave_speed) * wave_strength;
    distorted_uv.y += sin(UV.x * wave_freq + TIME * wave_speed * 0.7) * wave_strength;
    COLOR = texture(SCREEN_TEXTURE, distorted_uv);
}
```

#### Node graph (canvas\_item, Fragment stage):

```
[ScreenUV] ──────────────────────────────────→ [VectorCompose] ──→ [Add vec2] ──→ [Texture2D SCREEN_TEXTURE] ──→ OUTPUT.COLOR
[UV.y] ──→ [Multiply wave_freq] ──→ [Add TIME*speed] ──→ [Sin] ──→ [Multiply wave_strength] ──→ VectorCompose.x
[UV.x] ──→ [Multiply wave_freq] ──→ [Add TIME*speed*0.7] ──→ [Sin] ──→ [Multiply wave_strength] ──→ VectorCompose.y
```

1. Add three Parameters: `wave_freq` (float, 8.0), `wave_speed` (float, 1.5), `wave_strength` (float, 0.003).
2. Decompose UV: use **VectorDecompose** on the UV node to get UV.x and UV.y separately.
3. For each axis: Multiply UV component by `wave_freq`, then add `TIME * wave_speed` (use a separate Multiply + Add chain). Apply **Sin**, then Multiply by `wave_strength`.
4. Compose the two sin values back into a vec2 with **VectorCompose**.
5. Add **Input → ScreenUV**. Add them with a **Math → Add (vec2)**. Wire into a **Texture2D** node set to SCREEN\_TEXTURE.

:::callout-warning[SCREEN\_TEXTURE hint required]
In the VisualShader editor, when you add a Texture2D node and set it to

Screen

source, Godot automatically adds the

hint\_screen\_texture

uniform declaration. You do not need to add it manually — the node handles it.
:::

## Common Pitfalls

:::callout-pitfall[Pitfall 1 — Mixing scalar and vector ports]
A float output cannot connect directly to a vec3 input. Use

VectorCompose

to promote a float to a vector, or

VectorDecompose

to extract one channel. Mismatched port types show a red wire.
:::

:::callout-pitfall[Pitfall 2 — Forgetting to switch shader type tabs]
VisualShader has separate graphs for Fragment, Vertex, and Light. Adding a node while on the Fragment tab means it only exists in the Fragment stage. Always check the dropdown if nodes seem to disappear.
:::

:::callout-pitfall[Pitfall 3 — Duplicate parameter names]
If two Parameter nodes in the same shader share the same

Parameter Name

string, Godot merges them into one uniform. This is intentional (great for reusing a value in both Vertex and Fragment), but can be surprising if you named them by accident.
:::

:::callout-pitfall[Pitfall 4 — NoiseTexture resolution]
The default NoiseTexture resolution is 512×512. For a sprite that fills only 128×128 pixels on screen, that's unnecessarily large. Set Width/Height to 128 or 256 to reduce memory usage.
:::

:::callout-pitfall[Pitfall 5 — Can't inspect VisualShader in a TextFile editor]
VisualShader .tres files store the graph as encoded binary inside a text format — opening them in a text editor is unreadable. Always edit VS files through Godot's shader editor, not externally.
:::

:::summary
### Chapter 53 Summary

| Task | How to do it in VS |
| --- | --- |
| Expose a parameter to Inspector | Add a **Parameter node**; set Parameter Name |
| Set that parameter from GDScript | `mat.set_shader_parameter("name", value)` |
| Sample a texture | Add **Texture2D** node; wire UV input; take rgb/a outputs |
| Scroll UVs with time | UV + VectorCompose(TIME \* speed, 0) via Add node |
| Create procedural noise (no image) | **NoiseTexture** node with FastNoiseLite resource |
| Dissolve effect | Step(dissolve\_amount, noise\_value) → ALPHA |
| Fresnel rim glow | pow(1 - dot(NORMAL, VIEW), power) → EMISSION |
| Multi-line logic / loops | **Expression** node with raw GLSL |
| Shared utility functions | **CustomFunction** node pointing to .gdshader file |
| Inspect the generated GLSL | *Show Generated Code* button in the VS editor toolbar |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Pulsing Colour**

Create a 2D canvas\_item VisualShader that oscillates a sprite's tint between its original colour and a solid parameter `pulse_color` using `sin(TIME * pulse_speed)`. The result should plug into OUTPUT.COLOR, multiplied by the vertex COLOR to preserve modulate tinting.

::::solution[Solution]
Node chain: `Sin(TIME × pulse_speed)` → Abs → `Mix(COLOR.rgb, pulse_color.rgb, sin_value)` → VectorCompose with COLOR.a → OUTPUT.COLOR.

```glsl
// Generated equivalent:
void fragment() {
    float t = abs(sin(TIME * pulse_speed));
    COLOR = vec4(mix(COLOR.rgb, pulse_color.rgb, t), COLOR.a);
}
```

Use **Abs** on the Sin output to keep the value in [0,1] — raw sin goes negative which would invert colours.
::::
:::

:::problem{difficulty="easy"}
**2. Tile & Offset UV**

Build a VS shader that tiles a texture N×N times (using a `tile_count` float Parameter) and allows a per-axis UV offset via a vec2 `uv_offset` Parameter. Wire the result to a Texture2D and output to ALBEDO.

::::solution[Solution]
```glsl
// Equivalent:
void fragment() {
    vec2 tiled_uv = UV * tile_count + uv_offset;
    ALBEDO = texture(albedo_texture, tiled_uv).rgb;
}
```

VS nodes: UV → Multiply (by `tile_count` scalar; use VectorOp or just Multiply set to vec2 mode) → Add (vec2 `uv_offset`) → Texture2D uv → rgb → ALBEDO.
::::
:::

:::problem{difficulty="standard"}
**3. Height-Based Snow**

On a 3D terrain mesh, create a spatial VisualShader that blends between a base rock texture and a snow texture based on the world-space Y position of the fragment. Use a SmoothStep for a soft transition with `snow_min_height` and `snow_max_height` Parameters.

::::solution[Solution]
```glsl
// Equivalent fragment():
void fragment() {
    float blend = smoothstep(snow_min_height, snow_max_height, world_y);
    ALBEDO = mix(texture(rock_tex, UV).rgb, texture(snow_tex, UV).rgb, blend);
}
```

Getting world Y in VS: Add **Input → Vertex (world)** — in the Fragment stage VS provides a VERTEX built-in that is in view space by default. For world space you need to pass it through the Vertex stage: in the Vertex graph, wire **Input → Vertex** through a **TransformVecMult (MODEL\_MATRIX × Vertex)**, then write to a custom varying. In the Fragment graph, read that varying and decompose its Y component for the SmoothStep.
::::
:::

:::problem{difficulty="standard"}
**4. Rainbow HSV Cycle**

Using a CustomFunction node, call a `hsv_to_rgb` function (write it in a utils.gdshader file). Drive the hue with `TIME * hue_speed + UV.x` so different horizontal positions have different hues, creating a rainbow that cycles over time. Output to ALBEDO (3D) or COLOR.rgb (2D).

::::solution[Solution]
```glsl
// utils.gdshader
vec3 hsv_to_rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
// Fragment graph nodes:
// Add(Multiply(TIME, hue_speed), UV.x) → CustomFunction(hsv_to_rgb, hue=result, s=1.0, v=1.0) → ALBEDO
```

In the CustomFunction node: input ports `hue` (float), `saturation` (float), `value` (float); output port `rgb` (vec3). Feed a Constant 1.0 for saturation and value.
::::
:::

:::problem{difficulty="challenge"}
**5. Vertex Wave Animation**

In the **Vertex stage** of a spatial VisualShader, animate a flat plane mesh into a sine wave. Displace each vertex's Y position by `sin(VERTEX.x * wave_freq + TIME * wave_speed) * wave_height`. Also recalculate the NORMAL so lighting stays correct (approximate: NORMAL = normalize(vec3(-cos(...) \* wave\_freq \* wave\_height, 1.0, 0.0))).

::::solution[Solution]
```glsl
// Vertex stage equivalent:
void vertex() {
    float phase = VERTEX.x * wave_freq + TIME * wave_speed;
    VERTEX.y += sin(phase) * wave_height;
    // Approximate normal (assumes flat plane aligned to XZ)
    float dydx = cos(phase) * wave_freq * wave_height;
    NORMAL = normalize(vec3(-dydx, 1.0, 0.0));
}
```

In VS: switch to **Vertex** tab. Decompose VERTEX → x. Multiply x by wave\_freq, add TIME×wave\_speed. Apply Sin, multiply by wave\_height. Recompose VERTEX with modified Y. For NORMAL: compute Cos of same phase, multiply by wave\_freq×wave\_height, negate (for dydx), compose vec3(-dydx, 1.0, 0.0), Normalize, write to OUTPUT.NORMAL.
::::
:::

:::problem{difficulty="challenge"}
**6. Subgraph / Group Nodes**

VS supports *Group Input* and *Group Output* nodes that let you encapsulate a subgraph. Encapsulate your dissolve logic (noise + step + burn edge) into a group with ports: `uv` (vec2 in), `threshold` (float in), `alpha` (float out), `edge_mask` (float out). Then use the group in the main graph. Describe the steps to create and reuse this group.

::::solution[Solution]
Group nodes are called *SubGraph* in some Godot versions. The workflow:

1. Select all dissolve-related nodes (noise, step, subtract for edge).
2. Right-click → *Group Selection* (or use the Group button in the toolbar).
3. Add **Special → GroupInput** and **GroupOutput** inside the group canvas.
4. Define ports on GroupInput (uv, threshold) and GroupOutput (alpha, edge\_mask).
5. Connect the group's input/output ports to your dissolve logic nodes.
6. Save the VisualShader — the group is stored within the .tres file.
7. In future shaders, copy-paste the group node or reference the same .tres structure.

Note: In Godot 4.x VisualShader subgraph support is partial — you can group nodes visually for clarity but true reusable subgraph files are more reliably done via CustomFunction nodes pointing to a shared .gdshader utility file.
::::
:::
