---
title: "Earclacks — GameManager, Match Flow & HUD"
crumb: "Earclacks Weapon Ball — Chapter 70E"
meta:
  - "Est. study time: ~60 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview & Prerequisites

:::callout-key[KEY CONCEPT]
Full

GameManager.gd

with real 3-2-1 countdown ·

HUD.gd

with two health bars and a countdown label ·

GameOverScreen.gd

with winner display and replay button ·

Arena.gd

wired to spawn balls only on

FIGHTING

state.
:::

## 1. Full GameManager.gd

Replace the skeleton from Ch 70A with this complete version:

```gdscript
extends Node

enum State { WAITING, COUNTDOWN, FIGHTING, GAME_OVER }
var current_state: State = State.WAITING

var balls_alive: int = 0
var match_number: int = 0
var winner_name: String = ""

signal match_started
signal match_ended(winner_name: String)
signal state_changed(new_state: State)
signal countdown_tick(seconds_left: int)

# ─── Timer node (added to tree in _ready) ────────────────────────
var _countdown_timer: Timer

func _ready() -> void:
    _countdown_timer = Timer.new()
    _countdown_timer.one_shot = true
    add_child(_countdown_timer)
    _countdown_timer.timeout.connect(_on_countdown_done)

func set_state(new_state: State) -> void:
    if current_state == new_state:
        return
    current_state = new_state
    state_changed.emit(new_state)

func start_match() -> void:
    match_number += 1
    balls_alive = 2
    winner_name = ""
    set_state(State.COUNTDOWN)
    _run_countdown(3)

func _run_countdown(seconds: int) -> void:
    # Emit ticks manually using a loop + await so HUD can display 3-2-1
    _do_countdown_async(seconds)

func _do_countdown_async(seconds: int) -> void:
    for i in range(seconds, 0, -1):
        countdown_tick.emit(i)
        await get_tree().create_timer(1.0).timeout
    _on_countdown_done()

func _on_countdown_done() -> void:
    if current_state != State.COUNTDOWN:
        return
    set_state(State.FIGHTING)
    match_started.emit()

func ball_died(ball_name: String) -> void:
    if current_state != State.FIGHTING:
        return
    balls_alive -= 1
    # The surviving ball is whoever DIDN'T just die
    winner_name = "Blue" if ball_name == "Red" else "Red"
    if balls_alive <= 0:
        end_match(winner_name)

func end_match(w: String) -> void:
    winner_name = w
    set_state(State.GAME_OVER)
    match_ended.emit(winner_name)

func request_replay() -> void:
    # Called by GameOverScreen replay button
    # Clear dead balls before restarting
    set_state(State.WAITING)
    start_match()
```

:::callout-warning[WARNING]
This function uses

await

in a loop. Because it's called from a non-async context (`_run_countdown`), it runs asynchronously — the function returns immediately and the countdown runs in the background. This is correct behaviour:

start\_match()

returns right away while the countdown proceeds independently. Do NOT use

await \_do\_countdown\_async(3)

from `start_match()` — that would make

start\_match()

itself async and break all its callers.
:::

## 2. Countdown Timer — HUD Integration

The GameManager emits `countdown_tick(seconds_left)`. The HUD listens and displays "3", "2", "1", "FIGHT!" using a large centred label. You'll wire this in Section 3. Here's the flow:

| Time | Event | HUD shows |
| --- | --- | --- |
| t=0s | start\_match() called, state → COUNTDOWN | "3" |
| t=1s | countdown\_tick(2) | "2" |
| t=2s | countdown\_tick(1) | "1" |
| t=3s | state → FIGHTING, match\_started emitted | "FIGHT!" (briefly) |

:::callout-tip[TIP]
Arena.gd should spawn balls when

match\_started

fires (state = FIGHTING), not when

start\_match()

is called. This way balls don't exist during the countdown and can't start moving early. Update

Arena.\_on\_match\_started()

to be the signal handler for `match_started` — it already is from Ch 70B. The countdown is purely between COUNTDOWN state entry and `match_started`.
:::

## 3. HUD.gd

First build the HUD scene. In `Arena.tscn`, select the `HUD` CanvasLayer and add these children:

```
HUD (CanvasLayer)
├── CountdownLabel (Label)         — centred, large font
├── RedHealthBar (ProgressBar)     — top-left area
├── BlueHealthBar (ProgressBar)    — top-right area
├── RedNameLabel (Label)           — "RED" above red bar
└── BlueNameLabel (Label)          — "BLUE" above blue bar
```

Configure the labels and progress bars in the Inspector. For a 1080×1080 arena a suggested layout:

| Node | Position | Size | Notes |
| --- | --- | --- | --- |
| CountdownLabel | (440, 420) | (200, 100) | Font size 72, centred, initially hidden |
| RedHealthBar | (40, 40) | (300, 28) | Fill color red |
| BlueHealthBar | (740, 40) | (300, 28) | Fill color blue |
| RedNameLabel | (40, 14) | (100, 24) | "RED", small font |
| BlueNameLabel | (740, 14) | (100, 24) | "BLUE", small font |

Create `res://scripts/HUD.gd` and attach to the HUD CanvasLayer:

```gdscript
extends CanvasLayer

@onready var countdown_label: Label       = $CountdownLabel
@onready var red_bar: ProgressBar         = $RedHealthBar
@onready var blue_bar: ProgressBar        = $BlueHealthBar

func _ready() -> void:
    countdown_label.visible = false
    # Connect GameManager signals
    GameManager.countdown_tick.connect(_on_countdown_tick)
    GameManager.state_changed.connect(_on_state_changed)
    # Health bars start full
    red_bar.value  = 100
    blue_bar.value = 100

func _on_countdown_tick(seconds_left: int) -> void:
    countdown_label.visible = true
    countdown_label.text = str(seconds_left)

func _on_state_changed(new_state: GameManager.State) -> void:
    match new_state:
        GameManager.State.FIGHTING:
            countdown_label.text = "FIGHT!"
            # Hide "FIGHT!" after 0.6s
            await get_tree().create_timer(0.6).timeout
            countdown_label.visible = false
        GameManager.State.WAITING:
            # Reset bars for next match
            red_bar.value  = 100
            blue_bar.value = 100

# Called by Arena.gd after spawning each ball, passing its HealthComponent
func register_ball(ball: Node, team: String) -> void:
    var hc: HealthComponent = ball.get_node("HealthComponent")
    if team == "Red":
        hc.hp_changed.connect(func(hp, max): red_bar.value  = (hp / max) * 100)
    else:
        hc.hp_changed.connect(func(hp, max): blue_bar.value = (hp / max) * 100)
```

### Wiring HUD in Arena.gd

After spawning each ball, call `$HUD.register_ball(ball, team["name"])`. Update `Arena._spawn_ball()`:

```gdscript
func _spawn_ball(team: Dictionary, spawn_pos: Vector2, launch_dir: Vector2) -> void:
    var ball = BallScene.instantiate()
    ball.team_color   = team["color"]
    ball.ball_name    = team["name"]
    ball.weapon_scene = SwordScene
    balls_node.add_child(ball)
    ball.global_position = spawn_pos
    ball.launch(launch_dir)
    ball.died.connect(GameManager.ball_died)
    # Register with HUD for health bar updates
    $HUD.register_ball(ball, team["name"])
```

## 4. Game Over Screen

In `Arena.tscn`, the `GameOverScreen` CanvasLayer is already in the tree (hidden). Add children:

```
GameOverScreen (CanvasLayer)
├── Background (ColorRect)      — semi-transparent dark overlay, full-screen
├── WinnerLabel (Label)         — "RED WINS!" or "BLUE WINS!"
└── ReplayButton (Button)       — "Play Again"
```

Create `res://scripts/GameOverScreen.gd`:

```gdscript
extends CanvasLayer

@onready var winner_label: Label   = $WinnerLabel
@onready var replay_btn: Button    = $ReplayButton

func _ready() -> void:
    visible = false
    GameManager.match_ended.connect(_on_match_ended)
    replay_btn.pressed.connect(_on_replay_pressed)

func _on_match_ended(winner: String) -> void:
    winner_label.text = winner.to_upper() + " WINS!"
    winner_label.modulate = Color.RED if winner == "Red" else Color.CORNFLOWER_BLUE
    visible = true

func _on_replay_pressed() -> void:
    visible = false
    # Clean up any remaining balls before replaying
    var balls_node = get_node("/root/Arena/Balls")
    for ball in balls_node.get_children():
        ball.queue_free()
    GameManager.request_replay()
```

:::callout-pitfall[PITFALL]
If you call

request\_replay()

without freeing existing balls first, the old winning ball is still in the scene. It bounces alongside the two new balls. Always clear

$Balls

children before a replay. The

queue\_free()

loop in

\_on\_replay\_pressed()

handles this.
:::

## 5. Arena.gd — Spawn on FIGHTING State

One important update: Arena should spawn balls when `match_started` fires (which only happens when state transitions to FIGHTING), not when `start_match()` is called. This was already the design in Ch 70B — verify your `Arena._on_match_started()` is connected to `GameManager.match_started` (not called directly). If it is, no change needed.

Also add `GameManager.match_ended` connection for HUD cleanup:

```gdscript
func _ready() -> void:
    GameManager.match_started.connect(_on_match_started)
    GameManager.match_ended.connect(_on_match_ended)
    GameManager.start_match()

func _on_match_ended(winner_name: String) -> void:
    print("[Arena] Match ", GameManager.match_number, " over. Winner: ", winner_name)
```

## 6. Verification Checklist

1. **Run.** A "3" label appears in the centre. After 1 second it shows "2", then "1", then "FIGHT!" briefly, then disappears.
2. **Balls spawn on "FIGHT!" disappearing.** Before FIGHTING state, no balls are in the arena.
3. **Health bars update.** When the sword connects, the struck ball's health bar shrinks.
4. **Game over screen shows.** When one ball's HP hits 0, the screen darkens and "RED WINS!" or "BLUE WINS!" appears.
5. **Replay works.** Clicking "Play Again" clears balls, runs a new countdown, and starts a fresh match.

## Chapter Summary

:::summary
### The Game Is Now Fully Playable

With Ch 70E complete, you have a functioning game loop: countdown → fight → winner declared → replay. The remaining chapters (70F, 70G, 70H) add AI, more weapons, and polish — but the core loop is complete. A first video could be recorded right now.

| File | What Changed |
| --- | --- |
| GameManager.gd | Real countdown with async tick loop, request\_replay() |
| HUD.gd | Countdown label, two health bars, register\_ball() |
| GameOverScreen.gd | Winner display, replay button, ball cleanup |
| Arena.gd | register\_ball() call after spawn, \_on\_match\_ended() |
:::

## Practice Problems

**1.** easy — Why are balls spawned on `match_started` rather than when `start_match()` is first called?

:::solution[Solution]
Because there's a 3-second countdown between `start_match()` and `match_started`. If balls were spawned immediately, they'd be moving during the countdown display — players would see balls launching before the "FIGHT!" appears. Spawning on `match_started` (which fires when state becomes FIGHTING) ensures the arena is empty during the countdown and balls only appear the moment the fight begins.
:::

**2.** standard — The `_do_countdown_async` function uses `await get_tree().create_timer(1.0).timeout` in a loop. Why is `create_timer()` used here instead of a single Timer node with `wait_time = 1.0` firing three times?

:::solution[Solution]
A repeating Timer with one signal connection would require external state tracking (a counter variable) to know which tick it's on and when to stop. The `await` loop is self-contained: the loop variable `i` IS the countdown counter, the range controls when to stop, and each `create_timer()` creates a fresh one-shot timer that self-destructs. The async loop version is shorter, more readable, and has no persistent Timer node in the tree that needs cleanup.
:::

**3.** standard — The `register_ball()` method in HUD.gd uses a lambda: `func(hp, max): red_bar.value = (hp / max) * 100`. What is the risk if `max` is ever 0, and how would you guard against it?

:::solution[Solution]
Division by zero: `hp / max` would produce `inf` or `NaN`, and setting a ProgressBar's value to `inf` causes undefined behaviour. Guard with: `func(hp, m): red_bar.value = (hp / m) * 100 if m > 0 else 0`. In practice `max_hp` should never be 0 (it's set at export time), but defensive code prevents confusing editor warnings.
:::

**4.** challenge — Extend GameManager to support a **best-of-3** mode. Track wins per team. After 3 matches, the team with 2+ wins is declared the series winner. Show the new state / variables needed and modify `end_match()`.

:::solution[Solution]
```gdscript
# Add to GameManager:
var wins: Dictionary = { "Red": 0, "Blue": 0 }
var series_length: int = 3    # best of N
signal series_ended(series_winner: String)

func end_match(w: String) -> void:
    winner_name = w
    wins[w] += 1
    set_state(State.GAME_OVER)
    match_ended.emit(winner_name)
    # Check for series winner
    var needed = ceil(series_length / 2.0)  # 2 wins for best-of-3
    if wins[w] >= needed:
        series_ended.emit(w)
    else:
        # Auto-restart after a short delay
        await get_tree().create_timer(2.5).timeout
        request_replay()

func request_replay() -> void:
    # Don't replay if series is over
    var needed = ceil(series_length / 2.0)
    for team in wins:
        if wins[team] >= needed:
            return
    set_state(State.WAITING)
    start_match()
```
:::
