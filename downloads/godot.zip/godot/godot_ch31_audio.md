---
title: "Audio System"
source: "markdown"
---

Part III · Chapter 31

# Audio System

Prerequisite: Ch 4 (GDScript), Ch 7 (Signals), Ch 28 (Tweens) · est. 80 min

## Overview

Audio is one of the most powerful tools a game developer has — it communicates
 feedback, sets emotional tone, and guides player attention, often more
 efficiently than visuals. Yet audio is also one of the areas most frequently
 bolted on as an afterthought, resulting in code that plays sounds with magic
 numbers scattered through dozens of files.

Godot's audio system is built around three composable concepts:

- **Stream nodes** (`AudioStreamPlayer`,
 `AudioStreamPlayer2D`, `AudioStreamPlayer3D`) —
 the physical emitters in your scene tree.
- **Buses** — a mixing graph where streams are routed through
 named channels (Master → Music, SFX, Voice) each of which can carry
 effects (EQ, reverb, compressor).
- **Stream resources**
 (`AudioStreamOggVorbis`, `AudioStreamMP3`,
 `AudioStreamWAV`, `AudioStreamRandomizer`,
 `AudioStreamPlaylist`) — the actual audio data or logic that
 a player node plays back.

This chapter walks the full stack: from playing a basic sound to a
 professional-grade `MusicManager` autoload with crossfading,
 adaptive layered music, a pooled SFX emitter, and a settings screen that
 persists bus volumes.

## 1 · AudioStreamPlayer Nodes

### 1.1 · 2D vs 3D vs non-spatial

Godot provides three player node types. Choose based on whether you need
 positional audio:

| Node | Use case | Panning & attenuation |
| --- | --- | --- |
| `AudioStreamPlayer` | UI sounds, music, non-diegetic SFX (narration) | None — full stereo |
| `AudioStreamPlayer2D` | Sounds in a 2D world (footsteps, explosions) | Stereo panning by x-offset from listener; volume by distance |
| `AudioStreamPlayer3D` | Sounds in a 3D world | Full 3D spatialisation with HRTF option |

### 1.2 · Common API

All three share the same core properties and methods:

| Property / Method | Type | Notes |
| --- | --- | --- |
| `stream` | `AudioStream` | The resource to play |
| `volume_db` | `float` | Linear gain in decibels; 0 dB = unchanged, -6 dB ≈ half amplitude |
| `pitch_scale` | `float` | 1.0 = original pitch; 2.0 = one octave up |
| `bus` | `StringName` | Target audio bus name, e.g. `&"SFX"` |
| `autoplay` | `bool` | Start playing immediately when added to scene |
| `playing` | `bool` (read-only) | True while audio is active |
| `play(from_position)` | `void` | Start or restart; optional seek-to position in seconds |
| `stop()` | `void` | Stop immediately; does not reset position |
| `seek(to_position)` | `void` | Jump to a position while playing |
| `get_playback_position()` | `float` | Current position in seconds |
| `finished` (signal) | — | Emitted when playback ends naturally |

```gdscript
## Basic usage — fire-and-forget SFX on a character.
@onready var _sfx: AudioStreamPlayer2D = $SFXPlayer
@export var jump_sound: AudioStream
@export var land_sound: AudioStream

func jump() -> void:
    _sfx.stream      = jump_sound
    _sfx.pitch_scale = randf_range(0.95, 1.05)   # slight randomisation
    _sfx.play()

func land() -> void:
    _sfx.stream = land_sound
    _sfx.play()
```

:::callout-pitfall[Pitfall — sharing one player for rapid sounds]
If you call

play()

on a single

AudioStreamPlayer

while it is still playing, the previous sound is cut off.  For machine-gun
        fire, footsteps, or any sound that can overlap itself, use the pooled
        approach in Section 6 instead.
:::

### 1.3 · One-shot sound helper

A common pattern is to play a sound at a world position without keeping a
 permanent player node around. The node auto-frees when playback ends:

```gdscript
## res://autoloads/sfx.gd  (autoload name: SFX)
## Lightweight helper for fire-and-forget positional sounds.
extends Node

func play_at(stream: AudioStream, pos: Vector2,
             vol_db: float = 0.0, pitch: float = 1.0,
             bus: StringName = &"SFX") -> void:
    var player := AudioStreamPlayer2D.new()
    player.stream      = stream
    player.volume_db   = vol_db
    player.pitch_scale = pitch
    player.bus         = bus
    player.global_position = pos
    get_tree().current_scene.add_child(player)
    player.play()
    player.finished.connect(player.queue_free)

func play_ui(stream: AudioStream, vol_db: float = 0.0,
             bus: StringName = &"SFX") -> void:
    var player := AudioStreamPlayer.new()
    player.stream    = stream
    player.volume_db = vol_db
    player.bus       = bus
    add_child(player)
    player.play()
    player.finished.connect(player.queue_free)
```

:::callout-tip[Tip — adding to autoload vs current\_scene]
Adding the fire-and-forget player to

self

(the autoload) keeps
        it alive across scene changes.  Adding it to

current\_scene

means
        the sound stops when you change scenes.  Choose based on whether the sound
        should survive a scene transition (e.g. a death jingle probably should;
        a footstep should not).
:::

## 2 · Audio Buses

### 2.1 · Designing a bus layout

The **Audio Bus Layout** editor (*Project → Audio Bus Layout*,
 or the Audio tab at the bottom of the editor) is a visual mixing
 desk. Every bus sends to the bus named in its *Send* field, ultimately
 reaching the `Master` bus which drives the speakers.

A typical game layout:

```
Master
├── Music      (send: Master)
├── SFX        (send: Master)
│   ├── SFX_World   (send: SFX)
│   └── SFX_UI      (send: SFX)
└── Voice      (send: Master)
```

This hierarchy lets the player mute all sound effects with one bus slider,
 while still being able to independently lower the music or voice-over volume.
 The *Reverb* effect on `SFX_World` applies automatically
 to every sound routed there — you never need to add reverb to individual
 stream players.

:::callout-tip[Tip — save your bus layout]
The bus layout is saved to a file (default

res://default\_bus\_layout.tres

).
        Keep it in version control.  You can load a different layout at runtime with `AudioServer.set_bus_layout(layout)` — useful for switching between
        an "in-game" and a "cutscene" reverb setup.
:::

Audio Bus Routing — typical game layout

ASP (music)

bus: "Music"

ASP (world sfx)

bus: "SFX\_World"

ASP (UI sfx)

bus: "SFX\_UI"

ASP (voice)

bus: "Voice"

Music

Compressor

SFX

Limiter

SFX\_World

Reverb

SFX\_UI

(no effect)

Voice

EQ

Master

→ speakers

Mute "SFX" → silences both SFX\_World and SFX\_UI. Effects on a bus apply to everything routed through it.

Buses form a tree — all signals flow upward to **Master**. Sub-buses inherit their parent's volume slider and effects, so one fader controls a whole category. Reverb on `SFX_World` applies automatically to every world sound without touching individual players.

### 2.2 · Controlling buses from code

The `AudioServer` singleton provides full programmatic access to
 every bus:

| Method / Property | Description |
| --- | --- |
| `AudioServer.get_bus_index(name)` | Returns the integer index for a named bus |
| `AudioServer.get_bus_volume_db(idx)` | Current volume in dB |
| `AudioServer.set_bus_volume_db(idx, db)` | Set volume; use `linear_to_db()` to convert a 0–1 slider value |
| `AudioServer.get_bus_mute(idx)` | Returns true if muted |
| `AudioServer.set_bus_mute(idx, mute)` | Mute or unmute |
| `AudioServer.get_bus_effect(idx, effect_idx)` | Returns the `AudioEffect` resource at the given position |
| `AudioServer.set_bus_effect_enabled(idx, effect_idx, enabled)` | Toggle an individual effect |
| `db_to_linear(db)` / `linear_to_db(linear)` | Global helpers for unit conversion |

```gdscript
## Applying a volume slider value (0.0 – 1.0) to the Music bus.
func set_music_volume(linear: float) -> void:
    var idx: int = AudioServer.get_bus_index(&"Music")
    # linear 0 = silence, 1 = 0 dB.  Map to range -80..0 dB.
    var db: float = linear_to_db(linear) if linear > 0.0 else -80.0
    AudioServer.set_bus_volume_db(idx, db)

## Reading a bus volume back as a 0–1 slider position.
func get_music_volume() -> float:
    var idx: int = AudioServer.get_bus_index(&"Music")
    return db_to_linear(AudioServer.get_bus_volume_db(idx))
```

### 2.3 · Common bus effects

Effects are `AudioEffect` resources added to a bus in the editor.
 They process audio in real time:

| Effect | Typical use | Key properties |
| --- | --- | --- |
| `AudioEffectReverb` | Room ambiance, cave echo | `room_size`, `damping`, `wet` |
| `AudioEffectDelay` | Echo on voice, guitar slapback | `tap1_delay_ms`, `tap1_level_db`, `tap1_pan` |
| `AudioEffectEQ10` | Frequency shaping on Music bus | 10 band gains, each ±24 dB |
| `AudioEffectCompressor` | Tame loud SFX peaks, glue music | `threshold`, `ratio`, `attack_us`, `release_ms` |
| `AudioEffectLimiter` | Prevent digital clipping on Master | `ceiling_db` (typically –0.1 dB) |
| `AudioEffectLowPassFilter` | Muffled underwater / muted state | `cutoff_hz`, `resonance` |
| `AudioEffectDistortion` | Electric guitar, robot voice | `mode`, `drive` |
| `AudioEffectChorus` | Lush pad textures, haunted voices | `voice_count`, `wet`, `depth` |

Effects can be toggled at runtime. A common technique is to add a
 `AudioEffectLowPassFilter` to the Master bus, disabled by default,
 and enable it when the player is underwater or hears muffled sound through
 a wall:

```gdscript
## Toggle the low-pass filter at bus effect index 0 on the Master bus.
func set_underwater(enabled: bool) -> void:
    var master_idx: int = AudioServer.get_bus_index(&"Master")
    AudioServer.set_bus_effect_enabled(master_idx, 0, enabled)
```

## 3 · Spatial Audio

### 3.1 · Attenuation models

`AudioStreamPlayer2D` and `AudioStreamPlayer3D` fade
 volume based on the distance between the emitter and the
 `AudioListener2D` / `AudioListener3D` (by default the camera, unless a listener node is made current).
 The key properties on `AudioStreamPlayer2D` are:

| Property | Default | Effect |
| --- | --- | --- |
| `max_distance` | 2000 px | Beyond this distance, volume is 0. Set based on your world scale. |
| `attenuation` | 1.0 | Higher = steeper falloff curve (e.g. 2.0 = inverse-square law) |
| `panning_strength` | 1.0 | How strongly x-offset translates to left/right pan (0 = mono) |
| `area_mask` | 1 | Physics layer mask used to detect `Area2D` reverb zones |

For 3D audio, `AudioStreamPlayer3D` adds an
 `attenuation_model` enum:

- `ATTENUATION_INVERSE_DISTANCE` — volume ∝ 1/d (default)
- `ATTENUATION_INVERSE_SQUARE_DISTANCE` — volume ∝ 1/d²
 (physically accurate)
- `ATTENUATION_LOGARITHMIC` — matches human loudness perception
- `ATTENUATION_DISABLED` — no distance rolloff

### 3.2 · AudioListener2D / AudioListener3D

By default the active camera acts as the audio listener. For split-screen,
 or when the camera is detached from the player, add an explicit
 `AudioListener2D` child to the player and call
 `make_current()`:

```gdscript
## In Player._ready():
$AudioListener2D.make_current()
## Now panning and attenuation are relative to the player's position,
## not the camera's.
```

:::callout-key[Key Concept — Area2D reverb zones]
Place an

Area2D

with an

AudioStreamPlayer2D

in the inspector's

Audio

section set to

Override

.
        Any

AudioStreamPlayer2D

entering that area will automatically
        have the specified bus's reverb applied.  This is how you make a cave
        sound reverberant without attaching reverb to every individual emitter.
:::

## 4 · Stream Resources

An `AudioStream` resource can be more than just a file. Godot
 provides two powerful composite streams for game audio:

### 4.1 · AudioStreamRandomizer

`AudioStreamRandomizer` holds an array of streams and picks one
 randomly each time it is played. This eliminates the "machine-gun effect"
 where the same footstep sample plays identically every time.

```gdscript
## In the editor: create an AudioStreamRandomizer resource on the player node's
## stream property, then add several footstep .wav files to its streams array.
## The randomizer will pick a random entry and optionally vary pitch automatically.

## Via code:
func _make_footstep_stream(samples: Array[AudioStream]) -> AudioStreamRandomizer:
    var rnd := AudioStreamRandomizer.new()
    for s in samples:
        rnd.add_stream(-1, s)             # -1 = append
    rnd.random_pitch  = 0.1              # ± 10% pitch deviation
    rnd.random_volume_offset_db = 2.0    # ± 2 dB volume variation
    rnd.playback_mode = AudioStreamRandomizer.PLAYBACK_RANDOM_NO_REPEATS
    return rnd
```

| Property | Description |
| --- | --- |
| `streams_count` | Number of variants |
| `random_pitch` | Max pitch deviation (0 = none, 0.1 = ±10 %) |
| `random_volume_offset_db` | Max volume variation in dB |
| `playback_mode` | SEQUENTIAL, RANDOM, or RANDOM\_NO\_REPEATS |

### 4.2 · AudioStreamPlaylist

`AudioStreamPlaylist` plays its child streams sequentially (or
 shuffled), making it ideal for a seamless ambient loop constructed from
 multiple stems, or a music queue:

```gdscript
## Build a shuffled ambient loop.
func _make_ambient_playlist(tracks: Array[AudioStream]) -> AudioStreamPlaylist:
    var pl := AudioStreamPlaylist.new()
    for t in tracks:
        pl.add_stream(-1, t)
    pl.shuffle    = true
    pl.loop       = true
    pl.fade_time  = 2.0   # crossfade between tracks (seconds)
    return pl
```

## 5 · MusicManager Autoload

Ad hoc music playback scattered through scenes leads to double-playing tracks,
 abrupt cuts on scene changes, and no way to crossfade. A dedicated
 `MusicManager` autoload centralises all music logic.

### 5.1 · Basic crossfade

The pattern uses two `AudioStreamPlayer` nodes — think of them as
 Deck A and Deck B on a DJ mixer. When you request a new track, the current
 deck fades out while the new deck fades in:

```gdscript
## res://autoloads/music_manager.gd
## Autoload name: MusicManager
class_name MusicManager
extends Node

const FADE_DURATION: float = 1.5   # seconds

@onready var _deck_a: AudioStreamPlayer = $DeckA
@onready var _deck_b: AudioStreamPlayer = $DeckB

var _active_deck: AudioStreamPlayer     # currently playing
var _inactive_deck: AudioStreamPlayer   # will receive next track
var _current_stream: AudioStream        # track reference for deduplication

func _ready() -> void:
    _deck_a.bus = &"Music"
    _deck_b.bus = &"Music"
    _active_deck   = _deck_a
    _inactive_deck = _deck_b

## Play 'new_track' with a crossfade from whatever is currently playing.
## If 'new_track' is already playing, do nothing.
func play(new_track: AudioStream, loop: bool = true) -> void:
    if new_track == _current_stream and _active_deck.playing:
        return
    _current_stream = new_track

    # Prepare the incoming deck.
    _inactive_deck.stream    = new_track
    _inactive_deck.volume_db = -80.0
    _inactive_deck.play()

    # Tween both decks simultaneously.
    var tw: Tween = create_tween()
    tw.set_parallel(true)
    tw.tween_property(_active_deck,   "volume_db", -80.0, FADE_DURATION)
    tw.tween_property(_inactive_deck, "volume_db",   0.0, FADE_DURATION)
    await tw.finished

    _active_deck.stop()
    # Swap decks for next transition.
    var tmp: AudioStreamPlayer = _active_deck
    _active_deck   = _inactive_deck
    _inactive_deck = tmp

func stop(fade_out: bool = true) -> void:
    _current_stream = null
    if not fade_out:
        _active_deck.stop()
        return
    var tw: Tween = create_tween()
    tw.tween_property(_active_deck, "volume_db", -80.0, FADE_DURATION)
    await tw.finished
    _active_deck.stop()

func set_volume(linear: float) -> void:
    var db: float = linear_to_db(linear) if linear > 0.0 else -80.0
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index(&"Music"), db)
```

:::callout-warning[Warning — await and scene changes]
await tw.finished

inside an autoload is generally safe because
        the autoload is never freed.  However, if you call

stop()

while a crossfade is already in progress, two simultaneous

await

s
        will both try to swap the decks.  Add an

\_is\_fading

guard flag
        or kill the previous tween before starting a new one:

if \_fade\_tween: \_fade\_tween.kill()

.
:::

### 5.2 · Adaptive layered music

Many modern games use *vertical re-orchestration*: multiple stems
 (drums, bass, melody) start together but only some stems are audible
 depending on game state. In Godot, you achieve this with one player per stem,
 all playing in perfect sync:

```gdscript
## res://autoloads/adaptive_music.gd
## Autoload name: AdaptiveMusic
extends Node

## Stems must be the same length and BPM for sync to work.
@export var stem_base:    AudioStream   # always audible
@export var stem_drums:   AudioStream   # added during combat
@export var stem_tension: AudioStream   # added when HP low

@onready var _base:    AudioStreamPlayer = $Base
@onready var _drums:   AudioStreamPlayer = $Drums
@onready var _tension: AudioStreamPlayer = $Tension

func _ready() -> void:
    for p: AudioStreamPlayer in [_base, _drums, _tension]:
        p.bus = &"Music"
    _base.stream    = stem_base
    _drums.stream   = stem_drums
    _tension.stream = stem_tension

## Start all stems from position 0 in the same physics frame.
func start() -> void:
    _base.play(0.0)
    _drums.play(0.0)
    _tension.play(0.0)
    _set_stem_volume(_drums,   -80.0)   # silent initially
    _set_stem_volume(_tension, -80.0)

func enter_combat() -> void:
    _fade_stem(_drums, 0.0, 1.0)      # fade drums in over 1 s

func exit_combat() -> void:
    _fade_stem(_drums, -80.0, 2.0)

func set_tension(intensity: float) -> void:
    # intensity 0.0 – 1.0 maps to -80 dB – 0 dB
    var db: float = lerpf(-80.0, 0.0, intensity)
    _set_stem_volume(_tension, db)

func _fade_stem(player: AudioStreamPlayer, to_db: float, dur: float) -> void:
    var tw: Tween = create_tween()
    tw.tween_property(player, "volume_db", to_db, dur).set_trans(Tween.TRANS_SINE)

func _set_stem_volume(player: AudioStreamPlayer, db: float) -> void:
    player.volume_db = db
```

:::callout-intuition[Intuition — sync guarantee]
AudioStreamPlayer.play(0.0)

calls back-to-back in the same
        frame are processed together by the audio server in the next audio thread
        tick, which occurs at the audio buffer rate (typically 44 100 Hz).  Any
        offset between them is at most one audio frame — inaudible at normal
        frequencies.  You do

not

need to worry about sync drift for
        stems of equal length that loop.
:::

## 6 · SFX Pool

The fire-and-forget helper in Section 1.3 works for infrequent sounds, but
 `instantiate()` has overhead. For high-frequency effects — bullets,
 footsteps, particle pops — a pool of pre-instantiated players is faster and
 avoids frame spikes.

```gdscript
## res://autoloads/sfx_pool.gd
## Autoload name: SFXPool
extends Node

const POOL_SIZE: int = 32   # max simultaneous SFX

var _pool_2d: Array[AudioStreamPlayer2D] = []
var _pool_ui: Array[AudioStreamPlayer]   = []

func _ready() -> void:
    for i in POOL_SIZE:
        var p2d := AudioStreamPlayer2D.new()
        p2d.bus = &"SFX"
        add_child(p2d)
        _pool_2d.append(p2d)

        var pui := AudioStreamPlayer.new()
        pui.bus = &"SFX_UI"
        add_child(pui)
        _pool_ui.append(pui)

## Returns the first idle player from the 2D pool, or the oldest playing one.
func _acquire_2d() -> AudioStreamPlayer2D:
    for p in _pool_2d:
        if not p.playing:
            return p
    # All busy — steal the one closest to finishing (lowest volume ≈ longest running).
    # Simple heuristic: return the first one (oldest).
    return _pool_2d[0]

func _acquire_ui() -> AudioStreamPlayer:
    for p in _pool_ui:
        if not p.playing:
            return p
    return _pool_ui[0]

## Play 'stream' at world position 'pos'.
func play_at(stream: AudioStream, pos: Vector2,
             vol_db: float = 0.0, pitch: float = 1.0) -> void:
    var p: AudioStreamPlayer2D = _acquire_2d()
    p.stream               = stream
    p.global_position      = pos
    p.volume_db            = vol_db
    p.pitch_scale          = pitch
    p.play()

## Play a non-positional UI / narration sound.
func play_ui(stream: AudioStream, vol_db: float = 0.0) -> void:
    var p: AudioStreamPlayer = _acquire_ui()
    p.stream    = stream
    p.volume_db = vol_db
    p.play()
```

:::callout-tip[Tip — pitch randomisation at the call site]
Add natural variation when calling the pool:

SFXPool.play\_at(hit\_sound, pos, 0.0, randf\_range(0.9, 1.1))

.
        Combined with

AudioStreamRandomizer

(Section 4.1) on the
        stream itself, you get both timbral and pitch variation.
:::

## 7 · Volume Settings & Persistence

Players expect volume sliders in an Options menu that persist between
 sessions. Wire the sliders to bus volumes and save them to the player's
 config file from Chapter 24.

```gdscript
## res://ui/options/audio_settings.gd
extends VBoxContainer

@onready var _master_slider: HSlider = $Master/Slider
@onready var _music_slider:  HSlider = $Music/Slider
@onready var _sfx_slider:    HSlider = $SFX/Slider
@onready var _voice_slider:  HSlider = $Voice/Slider

const CFG_SECTION := "audio"

func _ready() -> void:
    _load_settings()
    _master_slider.value_changed.connect(_on_master_changed)
    _music_slider.value_changed.connect(_on_music_changed)
    _sfx_slider.value_changed.connect(_on_sfx_changed)
    _voice_slider.value_changed.connect(_on_voice_changed)

func _load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") != OK:
        return
    _master_slider.value = cfg.get_value(CFG_SECTION, "master", 1.0)
    _music_slider.value  = cfg.get_value(CFG_SECTION, "music",  0.8)
    _sfx_slider.value    = cfg.get_value(CFG_SECTION, "sfx",    1.0)
    _voice_slider.value  = cfg.get_value(CFG_SECTION, "voice",  1.0)
    _apply_all()

func _save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")    # load first to preserve other sections
    cfg.set_value(CFG_SECTION, "master", _master_slider.value)
    cfg.set_value(CFG_SECTION, "music",  _music_slider.value)
    cfg.set_value(CFG_SECTION, "sfx",    _sfx_slider.value)
    cfg.set_value(CFG_SECTION, "voice",  _voice_slider.value)
    cfg.save("user://settings.cfg")

func _apply_bus(bus_name: StringName, linear: float) -> void:
    var idx: int  = AudioServer.get_bus_index(bus_name)
    var db: float = linear_to_db(linear) if linear > 0.001 else -80.0
    AudioServer.set_bus_volume_db(idx, db)

func _apply_all() -> void:
    _apply_bus(&"Master", _master_slider.value)
    _apply_bus(&"Music",  _music_slider.value)
    _apply_bus(&"SFX",    _sfx_slider.value)
    _apply_bus(&"Voice",  _voice_slider.value)

func _on_master_changed(v: float) -> void: _apply_bus(&"Master", v); _save_settings()
func _on_music_changed(v:  float) -> void: _apply_bus(&"Music",  v); _save_settings()
func _on_sfx_changed(v:    float) -> void: _apply_bus(&"SFX",    v); _save_settings()
func _on_voice_changed(v:  float) -> void: _apply_bus(&"Voice",  v); _save_settings()
```

:::callout-connect[Connection — slider range]
Set your

HSlider

nodes to

min\_value = 0.0

,

max\_value = 1.0

,

step = 0.01

.  The conversion
        to dB is handled by `linear_to_db()`, which maps 0→-inf dB
        and 1→0 dB.  Clamping to -80 dB (rather than true negative infinity)
        prevents the audio server from trying to apply infinite gain reduction.
:::

## Summary

Godot's audio system is layered: stream nodes emit audio, buses route and
 process it, and stream resources describe what plays. The three player
 variants cover every use case — non-positional for UI and music, 2D and 3D
 for world sounds. The `AudioServer` singleton provides full
 runtime control of the bus graph, enabling mute, volume, and effect toggling
 from code. `AudioStreamRandomizer` eliminates the machine-gun
 effect; `AudioStreamPlaylist` enables seamless multi-track
 playback. A `MusicManager` autoload with a dual-deck crossfade
 pattern keeps music transitions smooth across scene changes. An object pool
 of pre-instantiated players handles high-frequency SFX without per-frame
 allocation spikes. Volume settings are saved to `user://settings.cfg`
 using `ConfigFile` and reloaded at startup.

| Tool | Purpose |
| --- | --- |
| `AudioStreamPlayer` | Non-positional playback (music, UI) |
| `AudioStreamPlayer2D/3D` | World-space positional audio |
| `AudioServer` | Bus volume, mute, effect control |
| `AudioStreamRandomizer` | Random variant selection with pitch/volume scatter |
| `AudioStreamPlaylist` | Sequential/shuffle multi-track playback |
| `MusicManager` autoload | Dual-deck crossfade; adaptive layer control |
| `SFXPool` autoload | Pre-instantiated pool for high-frequency SFX |
| `AudioListener2D/3D` | Explicit listener position for split-screen or detached cameras |

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Mute toggle.**
 Write a function `toggle_mute_sfx()` that reads the current
 mute state of the `"SFX"` bus and inverts it. No parameters.

::::solution[Solution]
```gdscript
func toggle_mute_sfx() -> void:
    var idx: int  = AudioServer.get_bus_index(&"SFX")
    var muted: bool = AudioServer.get_bus_mute(idx)
    AudioServer.set_bus_mute(idx, not muted)
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Randomised footsteps.**
 Create an `AudioStreamRandomizer` from an array of footstep
 samples, set `PLAYBACK_RANDOM_NO_REPEATS`, apply ±8% pitch
 deviation and ±1.5 dB volume variation, and assign it to an
 `AudioStreamPlayer2D`'s `stream` property.

::::solution[Solution]
```gdscript
func setup_footsteps(samples: Array[AudioStream],
                     player: AudioStreamPlayer2D) -> void:
    var rnd := AudioStreamRandomizer.new()
    for s in samples:
        rnd.add_stream(-1, s)
    rnd.playback_mode           = AudioStreamRandomizer.PLAYBACK_RANDOM_NO_REPEATS
    rnd.random_pitch            = 0.08
    rnd.random_volume_offset_db = 1.5
    player.stream = rnd
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Underwater effect.**
 Build a function `set_underwater(enabled: bool)` that
 crossfades a `AudioEffectLowPassFilter` on the Master bus
 (at effect index 0) smoothly: fade its `cutoff_hz` between
 20 000 Hz (normal) and 600 Hz (underwater) over 0.4 seconds using a
 Tween. The effect exists in the editor; retrieve it with
 `AudioServer.get_bus_effect()`.

::::solution[Solution]
```gdscript
var _uw_tween: Tween

func set_underwater(enabled: bool) -> void:
    var master_idx: int = AudioServer.get_bus_index(&"Master")
    var lpf: AudioEffectLowPassFilter = \
        AudioServer.get_bus_effect(master_idx, 0) as AudioEffectLowPassFilter
    if lpf == null:
        push_error("No AudioEffectLowPassFilter at Master bus effect 0")
        return
    if _uw_tween:
        _uw_tween.kill()
    _uw_tween = create_tween()
    var target_hz: float = 600.0 if enabled else 20000.0
    _uw_tween.tween_property(lpf, "cutoff_hz", target_hz, 0.4) \
             .set_trans(Tween.TRANS_SINE)
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Music queue.**
 Extend `MusicManager` with a `queue(track: AudioStream)`
 method. If something is already playing, store the track and play it
 automatically when the current track finishes (connect to `finished`).
 If nothing is playing, start immediately. Only one queued track should
 be pending at a time; calling `queue()` again replaces the
 pending track.

::::solution[Solution]
```gdscript
## Add to MusicManager:
var _queued: AudioStream = null

func queue(track: AudioStream) -> void:
    if not _active_deck.playing:
        play(track)
        return
    _queued = track
    # Disconnect previous connection to avoid stacking.
    if _active_deck.finished.is_connected(_on_track_finished):
        _active_deck.finished.disconnect(_on_track_finished)
    _active_deck.finished.connect(_on_track_finished, CONNECT_ONE_SHOT)

func _on_track_finished() -> void:
    if _queued != null:
        var t: AudioStream = _queued
        _queued = null
        play(t)
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Beat-synchronised stem swap.**
 Given a `bpm: float` and a set of stems (as
 `AudioStreamPlayer`s all playing in sync), implement a
 `swap_stem_on_beat(player: AudioStreamPlayer, enabled: bool)`
 function that fades the stem in or out, but *only starts the fade
 on the next beat boundary*. A beat occurs every
 `60.0 / bpm` seconds from the moment the stems started.
 Use `get_playback_position()` on the base stem to calculate
 the time until the next beat, then `await
 get_tree().create_timer(wait_time).timeout` before tweening.

::::solution[Solution]
```gdscript
## Add to AdaptiveMusic (or MusicManager):
@export var bpm: float = 120.0

func swap_stem_on_beat(player: AudioStreamPlayer, enabled: bool) -> void:
    var beat_dur: float   = 60.0 / bpm
    var position: float   = _base.get_playback_position()
    var beat_index: float = position / beat_dur
    var next_beat: float  = ceil(beat_index) * beat_dur
    var wait: float       = next_beat - position
    # Small epsilon guard: if we are within 20 ms of a beat, snap to it.
    if wait < 0.02:
        wait += beat_dur
    await get_tree().create_timer(wait).timeout
    var target_db: float = 0.0 if enabled else -80.0
    var tw: Tween = create_tween()
    tw.tween_property(player, "volume_db", target_db, beat_dur * 0.5) \
      .set_trans(Tween.TRANS_SINE)
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Full SoundManager.**
 Build a `SoundManager` autoload that combines the
 `MusicManager` (dual-deck crossfade, queue), the
 `SFXPool` (32 pooled 2D + 8 pooled UI players), and the
 volume settings (ConfigFile persistence, applying on `_ready()`).
 Expose a clean API:
 `play_music(stream, loop)`,
 `stop_music()`,
 `play_sfx(stream, pos, pitch_variation)`,
 `play_ui_sfx(stream)`,
 `set_bus_volume(bus_name, linear)`,
 `save_volumes()`,
 `load_volumes()`.
 The pitch variation parameter (default 0.0) adds a random ± offset
 drawn from `randf_range(-pitch_variation, pitch_variation)`.

::::solution[Solution]
```gdscript
## res://autoloads/sound_manager.gd
extends Node

# ── Music (dual-deck) ────────────────────────────────────
const FADE: float = 1.5
var _deck_a: AudioStreamPlayer
var _deck_b: AudioStreamPlayer
var _deck_active: AudioStreamPlayer
var _deck_idle: AudioStreamPlayer
var _current_music: AudioStream = null
var _queued_music: AudioStream  = null
var _fade_tween: Tween

# ── SFX Pool ─────────────────────────────────────────────
const POOL_2D: int = 32
const POOL_UI: int = 8
var _pool_2d: Array[AudioStreamPlayer2D] = []
var _pool_ui: Array[AudioStreamPlayer]   = []

func _ready() -> void:
    _deck_a = _make_music_player()
    _deck_b = _make_music_player()
    _deck_active = _deck_a
    _deck_idle   = _deck_b
    for i in POOL_2D:
        var p := AudioStreamPlayer2D.new()
        p.bus = &"SFX"; add_child(p); _pool_2d.append(p)
    for i in POOL_UI:
        var p := AudioStreamPlayer.new()
        p.bus = &"SFX_UI"; add_child(p); _pool_ui.append(p)
    load_volumes()

func _make_music_player() -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.bus = &"Music"; p.volume_db = -80.0; add_child(p); return p

# ── Public API ───────────────────────────────────────────
func play_music(stream: AudioStream, loop: bool = true) -> void:
    if stream == _current_music and _deck_active.playing: return
    _current_music = stream
    _deck_idle.stream = stream; _deck_idle.volume_db = -80.0; _deck_idle.play()
    if _fade_tween: _fade_tween.kill()
    _fade_tween = create_tween().set_parallel(true)
    _fade_tween.tween_property(_deck_active, "volume_db", -80.0, FADE)
    _fade_tween.tween_property(_deck_idle,   "volume_db",   0.0, FADE)
    await _fade_tween.finished
    _deck_active.stop()
    var tmp := _deck_active; _deck_active = _deck_idle; _deck_idle = tmp

func stop_music() -> void:
    _current_music = null
    if _fade_tween: _fade_tween.kill()
    _fade_tween = create_tween()
    _fade_tween.tween_property(_deck_active, "volume_db", -80.0, FADE)
    await _fade_tween.finished; _deck_active.stop()

func play_sfx(stream: AudioStream, pos: Vector2,
              pitch_variation: float = 0.0) -> void:
    var p: AudioStreamPlayer2D = _pool_2d[0]
    for px in _pool_2d:
        if not px.playing: p = px; break
    p.stream = stream
    p.global_position = pos
    p.pitch_scale = 1.0 + randf_range(-pitch_variation, pitch_variation)
    p.play()

func play_ui_sfx(stream: AudioStream) -> void:
    var p: AudioStreamPlayer = _pool_ui[0]
    for px in _pool_ui:
        if not px.playing: p = px; break
    p.stream = stream; p.play()

func set_bus_volume(bus_name: StringName, linear: float) -> void:
    var idx: int  = AudioServer.get_bus_index(bus_name)
    var db: float = linear_to_db(linear) if linear > 0.001 else -80.0
    AudioServer.set_bus_volume_db(idx, db)

func save_volumes() -> void:
    var cfg := ConfigFile.new(); cfg.load("user://settings.cfg")
    for bus in [&"Master", &"Music", &"SFX", &"Voice"]:
        var idx := AudioServer.get_bus_index(bus)
        cfg.set_value("audio", str(bus),
            db_to_linear(AudioServer.get_bus_volume_db(idx)))
    cfg.save("user://settings.cfg")

func load_volumes() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") != OK: return
    for bus in [&"Master", &"Music", &"SFX", &"Voice"]:
        var v: float = cfg.get_value("audio", str(bus), 1.0)
        set_bus_volume(bus, v)
```
::::
:::
