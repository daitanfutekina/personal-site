---
title: "Resources, .tres/.tscn & the FileSystem Dock"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 6"
meta:
  - "Est. study time: ~60 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch6_resources.html"
---

## Overview

If nodes are the *verbs* of a Godot game — the things that act, move, and
 respond — then resources are the *nouns*. Textures, audio clips, item
 definitions, save-game data, shader materials, tileset configurations: all of
 these are resources. They're serialisable, shareable, reference-counted data
 containers that sit alongside your scenes in the project folder.

Understanding resources unlocks two major capabilities: designer-friendly game
 data that lives in `.tres` files instead of hard-coded dictionaries,
 and a clean save/load system that Godot handles automatically.

:::callout-key[Prerequisites]
- Chapters 1–5: nodes, scenes, GDScript, signals.
- Familiarity with `@export` (covered in Chapter 4 §6).
:::

## 1. What is a Resource?

### Nodes vs Resources

Every object in Godot descends from `Object`. The two main branches
 below it are `Node` (scene-tree citizens that process and render) and
 `Resource` (data containers that can be serialised to disk and shared).

| Property | Node | Resource |
| --- | --- | --- |
| Base class | `Node → Object` | `Resource → RefCounted → Object` |
| Lives in | Scene tree | Memory / disk |
| Has `_ready()` / `_process()` | Yes | No |
| Memory management | Manual (`queue_free()`) | Automatic (reference-counted) |
| Serialisable | Via .tscn (as PackedScene) | Directly as .tres / .res |
| Shared by | Single scene tree location | Any number of holders |
| Typical use | Anything that acts in the game world | Data shared across many nodes / scenes |

Godot Object Hierarchy — Node vs Resource

Object

Node

RefCounted → Resource

Node2D / 3D

Control (UI)

AudioStreamPlayer

Texture2D

PackedScene

ShaderMaterial

Lives in scene tree · manual memory

Lives in memory/disk · reference-counted

Both branches descend from Object. Nodes live in the scene tree and drive game logic. Resources are data containers that can be shared, serialized, and reused across multiple nodes.

:::callout-connect[PackedScene is a resource]
A `.tscn` file is a `PackedScene` — a Resource that holds
 a serialised snapshot of a node tree. When you call `.instantiate()`,
 the resource unpacks itself into live nodes. This is why `preload()`
 and `load()` work the same for both `.tscn` and
 `.tres` files — they're all resources.
:::

### Reference Counting

Resources inherit from `RefCounted`. Godot automatically tracks how
 many variables hold a reference to each resource. When the count drops to zero,
 the resource is freed without any explicit call. This makes resources safe to
 pass around freely and assign to multiple nodes — no `queue_free()`
 required, no dangling pointer risk.

```gdscript
func _ready() -> void:
    var tex: Texture2D = load("res://textures/player.png")
    $Sprite1.texture = tex   # ref count: 2 (tex variable + Sprite1)
    $Sprite2.texture = tex   # ref count: 3 (tex + Sprite1 + Sprite2)
    # When tex goes out of scope: ref count drops to 2
    # When Sprite1 is freed: ref count drops to 1
    # When Sprite2 is freed: ref count drops to 0 → texture freed automatically
```

## 2. Built-in Resources

Godot ships with a large library of Resource subclasses. You interact with most
 of them by assigning files in the Inspector, not by writing code.

| Class | File ext | Description |
| --- | --- | --- |
| `Texture2D` | .png / .webp / .jpg | An image; assigned to Sprite2D, TextureRect, Button icon, etc. |
| `AudioStreamOggVorbis` | .ogg | Compressed audio; best for music (small, high quality) |
| `AudioStreamWAV` | .wav | Uncompressed audio; best for short SFX (zero decode latency) |
| `PackedScene` | .tscn | Saved node tree; call `.instantiate()` to create live nodes |
| `ShaderMaterial` | .tres | A material that references a .gdshader and stores its uniforms |
| `StandardMaterial3D` | .tres | PBR material with albedo, roughness, metallic, emission |
| `Font` / `FontFile` | .ttf / .otf | Typography; assign to Label, RichTextLabel, etc. |
| `TileSet` | .tres | Atlas of tiles for TileMap; defines physics, terrain, autotile |
| `Curve` | .tres | Editable bezier curve; used for easing, damage falloff, spawn rates |
| `Gradient` | .tres | Colour gradient; used by GPUParticles2D, GradientTexture2D |
| `Animation` | Inside .res | Keyframe track data; stored inside AnimationLibrary resources |
| `Environment` | .tres | Sky, fog, tonemapping, ambient light settings for 3D |
| `Script` | .gd | A GDScript file is itself a Resource, attached to nodes via Inspector |

:::callout-tip[Drag-and-drop assignment]
Any Inspector property typed as a Resource subclass shows a coloured slot.
 Drag a file from the FileSystem dock directly onto the slot to assign it.
 No code required — Godot stores the `res://` path in the
 `.tscn` file and loads it automatically at runtime.
:::

## 3. Custom Resources

You can define your own Resource subclasses in GDScript. This is one of Godot's
 most underused features. Instead of storing item data in a Dictionary, a CSV
 file, or a giant autoload array, you define an `ItemData` resource —
 typed properties, Inspector editing, save/load for free.

### Declaring and Exporting Properties

Three things make a script a usable custom resource:

1. `class_name ItemData` — registers it globally so the editor recognises it.
2. `extends Resource` — gives it save/load, reference-counting, and the Inspector integration.
3. `@export` on each property — each exported property appears as an editable field when you open a `.tres` file of this type.

```gdscript
# item_data.gd
class_name ItemData
extends Resource

@export var item_name: String = "Unnamed"
@export var icon: Texture2D
@export var value_gold: int = 0
@export var weight_kg: float = 0.1
@export_multiline var description: String = ""
@export var stackable: bool = true
@export var max_stack_size: int = 99
@export_range(0, 10) var rarity: int = 1   # 0 = common, 10 = legendary

# Methods work too — resources are full objects
func get_rarity_label() -> String:
    match rarity:
        0, 1: return "Common"
        2, 3: return "Uncommon"
        4, 5: return "Rare"
        6, 7: return "Epic"
        _:    return "Legendary"
```

### Creating .tres Files in the Editor

Once your script is saved and Godot has parsed it, you can create instances as
 `.tres` files:

1. Right-click in the FileSystem dock → **New Resource…**
2. Type `ItemData` in the search field and select it.
3. Choose a save path, e.g. `res://items/iron_sword.tres`.
4. Click **Open** — the Inspector shows all your `@export` fields.
5. Fill in the values and save (Ctrl+S).

Now any scene can export an `ItemData` slot and a designer can assign
 `iron_sword.tres` to it — no code change needed to add new items.

```gdscript
# item_pickup.gd — knows nothing about specific items; just has a slot
extends Area2D

signal collected(data: ItemData)

@export var item: ItemData   # designer assigns iron_sword.tres here

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        collected.emit(item)
        queue_free()
```

### Nesting Resources Inside Resources

Resources can reference other resources, enabling powerful composable data
 structures. A `CharacterStats` resource might embed a
 `LevelCurve` that defines how XP scales with level, or an
 `AbilitySet` that holds an array of `Ability` resources.

```gdscript
# level_curve.gd
class_name LevelCurve
extends Resource

@export var xp_thresholds: Array[int] = [0, 100, 250, 500, 1000, 2000]

func level_for_xp(xp: int) -> int:
    for i in range(xp_thresholds.size() - 1, -1, -1):
        if xp >= xp_thresholds[i]:
            return i + 1
    return 1

func xp_to_next(current_level: int) -> int:
    if current_level >= xp_thresholds.size():
        return INF  # max level
    return xp_thresholds[current_level] - xp_thresholds[current_level - 1]
```

```gdscript
# character_stats.gd
class_name CharacterStats
extends Resource

@export_group("Base Stats")
@export var display_name: String = "Character"
@export var base_hp: int = 100
@export var base_attack: int = 10
@export var base_defense: int = 5
@export var base_speed: float = 150.0

@export_group("Progression")
@export var level_curve: LevelCurve   # nested resource — assign in Inspector
@export var stat_growth: Array[float] = [1.1, 1.05, 1.08, 1.0]  # per level multipliers

@export_group("Visuals")
@export var portrait: Texture2D
@export var battle_sprite: SpriteFrames
```

:::example[Worked Example — Enemy Variant System]
Three enemy types (Goblin, Orc, Troll) all use the same AI script and scene.
 Only their stats differ. A single `EnemyStats` resource drives all
 three — designers create one `.tres` per enemy type.

```gdscript
# enemy_stats.gd
class_name EnemyStats
extends Resource

@export var display_name: String = "Enemy"
@export var max_health: int = 50
@export var attack_damage: int = 5
@export var move_speed: float = 80.0
@export var xp_reward: int = 20
@export var gold_drop_range: Vector2i = Vector2i(2, 8)
@export var portrait: Texture2D
@export var loot_table: LootTable   # another nested resource
```

```gdscript
# enemy.gd — ONE script for ALL enemy types
extends CharacterBody2D

@export var stats: EnemyStats   # goblin.tres / orc.tres / troll.tres

var _hp: int

func _ready() -> void:
    _hp = stats.max_health
    $NameLabel.text = stats.display_name
    $Portrait.texture = stats.portrait
    $HealthBar.max_value = stats.max_health
    $HealthBar.value = stats.max_health

func take_damage(amount: int) -> void:
    _hp = max(0, _hp - amount)
    $HealthBar.value = _hp
    if _hp == 0:
        _die()

func _die() -> void:
    var gold: int = randi_range(stats.gold_drop_range.x, stats.gold_drop_range.y)
    EventBus.enemy_killed.emit(stats.display_name, global_position, stats.xp_reward)
    if stats.loot_table:
        stats.loot_table.roll(global_position)
    queue_free()
```

::::answer[Files on disk]
`res://enemies/goblin_stats.tres`,
 `res://enemies/orc_stats.tres`,
 `res://enemies/troll_stats.tres` — each an
 `EnemyStats` instance with different Inspector values.
 The Goblin prefab, Orc prefab, and Troll prefab all use
 `enemy.tscn` as their root; only the `stats`
 property differs. Adding a new enemy type takes thirty seconds in the
 editor and zero lines of new code.
::::
:::

## 4. preload() vs load()

preload() vs load() — When to Use Each

 preload()
 Loads at compile time (before \_ready)
 ✓ Path must be a string literal
 ✓ Editor catches missing files early
 ✓ Best for always-needed assets
 e.g. const BULLET = preload("res://bullet.tscn")

 load()
 Loads at runtime (when line runs)
 ✓ Path can be a variable or expression
 ✓ Dynamic / conditional asset loading
 ✗ Returns null if path wrong (check it!)
 e.g. load("res://levels/level\_%d.tscn" % n)

 Use `preload()` for assets you always need — the editor validates the path. Use `load()` when the path depends on runtime data (level number, save slot, user choice).

 Both functions return a `Resource`. Their difference is *when*
 the loading happens and what kind of path they accept.

|  | `preload()` | `load()` |
| --- | --- | --- |
| When it loads | At **parse/compile time** — before any `_ready()` runs | At **runtime** — when the line executes |
| Path must be | A **string literal** — no variables, no concatenation | Any `String` expression |
| Returns | The resource (guaranteed non-null if path is valid) | The resource, or `null` if path invalid |
| Error timing | Editor flags the error at edit time | Error appears at runtime as a crash or null check |
| Blocks main thread | During script parse (effectively instant for typical files) | Yes — can cause a frame hitch for large assets |
| Best for | Assets the scene always needs (bullet scene, HUD font) | Dynamic paths, optional assets, large files loaded on demand |

```gdscript
extends Node2D

# preload — path is a literal, loaded before _ready() even runs
const BULLET_SCENE: PackedScene = preload("res://scenes/bullet.tscn")
const EXPLOSION_SFX: AudioStream = preload("res://audio/explosion.ogg")
const FONT: Font = preload("res://fonts/pixel.ttf")

# load — path can be constructed at runtime
@export var skin_name: String = "blue"

func _ready() -> void:
    # Dynamic path — ONLY possible with load(), not preload()
    var skin_path: String = "res://skins/%s.tres" % skin_name
    var skin: SkinData = load(skin_path) as SkinData

    if skin == null:
        push_error("Skin not found: " + skin_path)
        return
    apply_skin(skin)
```

:::callout-pitfall[preload() only accepts literals]
This fails to compile:

```gdscript
var path: String = "res://items/sword.tres"
const ITEM = preload(path)   # ERROR: preload argument must be a string literal
```

Use `load(path)` whenever the path is a variable.
:::

### Background Loading with ResourceLoader

Both `preload()` and synchronous `load()` block the main
 thread. For large assets (a level's TileSet, a 3D mesh, a long audio track) this
 causes a visible frame freeze. Use `ResourceLoader.load_threaded_request()`
 to load on a background thread while the game continues:

```gdscript
# SceneLoader.gd (Autoload)
extends Node

signal progress_updated(ratio: float)
signal load_complete(scene: PackedScene)

var _path: String = ""
var _loading: bool = false

func request(path: String) -> void:
    _path = path
    ResourceLoader.load_threaded_request(path)
    _loading = true

func _process(_delta: float) -> void:
    if not _loading:
        return

    var prog: Array = []
    var status := ResourceLoader.load_threaded_get_status(_path, prog)

    if prog.size() > 0:
        progress_updated.emit(prog[0])   # 0.0 to 1.0

    match status:
        ResourceLoader.THREAD_LOAD_IN_PROGRESS:
            pass   # still loading — progress bar updates via signal above
        ResourceLoader.THREAD_LOAD_LOADED:
            _loading = false
            progress_updated.emit(1.0)
            var scene: PackedScene = ResourceLoader.load_threaded_get(_path) as PackedScene
            load_complete.emit(scene)
        ResourceLoader.THREAD_LOAD_FAILED:
            _loading = false
            push_error("Failed to load: " + _path)
```

```gdscript
# LoadingScreen.gd — connects to the autoload
extends CanvasLayer

@onready var bar: ProgressBar = $ProgressBar

func _ready() -> void:
    SceneLoader.progress_updated.connect(func(r: float): bar.value = r * 100.0)
    SceneLoader.load_complete.connect(_on_load_complete)
    SceneLoader.request("res://levels/world_02.tscn")

func _on_load_complete(scene: PackedScene) -> void:
    get_tree().change_scene_to_packed(scene)
```

## 5. Saving & Loading .tres Files

Custom resources can be saved at runtime using `ResourceSaver` and
 loaded back with `load()`. This is Godot's built-in save-game system
 for structured data — no JSON serialisation, no manual parsing.

```gdscript
# save_data.gd
class_name SaveData
extends Resource

@export var player_name: String = ""
@export var level: int = 1
@export var total_xp: int = 0
@export var gold: int = 0
@export var position: Vector2 = Vector2.ZERO
@export var unlocked_levels: Array[String] = []
@export var settings_volume: float = 1.0
# Items are Resources too — they serialize automatically
@export var inventory: Array[ItemData] = []
```

```gdscript
# SaveSystem.gd (Autoload)
extends Node

const SAVE_PATH: String = "user://save_data.tres"

func save(player: CharacterBody2D) -> void:
    var data: SaveData = SaveData.new()
    data.player_name  = player.player_name
    data.level        = player.level
    data.total_xp     = player.xp
    data.gold         = player.gold
    data.position     = player.global_position
    data.inventory    = player.inventory.items.duplicate(true)

    var err: Error = ResourceSaver.save(data, SAVE_PATH)
    if err != OK:
        push_error("Save failed: " + error_string(err))
    else:
        print("Saved to ", SAVE_PATH)

func load_save() -> SaveData:
    if not FileAccess.file_exists(SAVE_PATH):
        return null   # first launch — no save file yet

    var data: SaveData = load(SAVE_PATH) as SaveData
    if data == null:
        push_error("Save file corrupt or wrong type at: " + SAVE_PATH)
    return data

func has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)

func delete_save() -> void:
    DirAccess.remove_absolute(SAVE_PATH)
```

### user:// vs res://

:::callout-warning[res:// is read-only in exported builds]
`res://` points to your project's asset folder. In the editor you
 can write there, but in an *exported* game the `res://`
 directory is packed into a PCK file — it is read-only. Always use
 `user://` for any file the game needs to write at runtime (saves,
 settings, logs, screenshots).

`user://` maps to an OS-specific writable directory:
 `%AppData%\Godot\app_userdata\YourProject\` on Windows,
 `~/.local/share/godot/app_userdata/YourProject/` on Linux,
 `~/Library/Application Support/Godot/YourProject/` on macOS.
:::

### .tres (text) vs .res (binary)

|  | .tres — text format | .res — binary format |
| --- | --- | --- |
| Human-readable | Yes — opens in any editor | No |
| Version control diffs | Clean, readable diffs | Binary blob diffs only |
| File size | Larger (text overhead) | ~30–50% smaller |
| Parse speed | Slower to parse | Faster to load |
| Best for | Editor assets, config, all development data | Exported runtime data, large pre-baked resources |

```gdscript
# Save as binary (smaller, faster to load — good for exported data)
ResourceSaver.save(data, "user://save.res", ResourceSaver.FLAG_COMPRESS)

# Save as text (default — good for development and version control)
ResourceSaver.save(data, "user://save.tres")
```

## 6. The FileSystem Dock

The FileSystem dock (bottom-left by default) is Godot's project asset browser.
 Every file in your `res://` folder appears here, and Godot's import
 system monitors it automatically using file system watchers.

```
res://
├── audio/
│   ├── bgm_level1.ogg
│   └── sfx_jump.wav
├── fonts/
│   └── pixel.ttf
├── items/
│   ├── iron_sword.tres
│   └── health_potion.tres
├── scenes/
│   ├── main.tscn
│   ├── player.tscn
│   └── enemy.tscn
├── scripts/
│   ├── item_data.gd
│   └── event_bus.gd
└── textures/
    ├── player.png
    └── tileset.png

```

### Key FileSystem Operations

| Action | How |
| --- | --- |
| Create a folder | Right-click → **New Folder…** |
| Create a script | Right-click → **New Script…** |
| Create a resource | Right-click → **New Resource…** |
| Rename a file | Right-click → **Rename** — Godot updates .tscn references |
| Move a file | Drag within the dock — Godot updates references |
| Delete a file | Right-click → **Delete** — check for usages first |
| Find who uses a file | Right-click → **Find Usages…** |
| Copy the res:// path | Right-click → **Copy Path** |
| Open in external app | Right-click → **Open in External Program** |
| Re-import all assets | **Project → Tools → Re-Import** |

:::callout-pitfall[Never rename files outside of Godot]
If you rename or move a file using Explorer / Finder, Godot doesn't know.
 Every `preload("res://old_name.tscn")` and every scene reference
 will break silently. Always rename and move files *through* the Godot
 FileSystem dock so it can rewrite all references automatically.
:::

### The Import Pipeline

When you drop a file into your project folder (PNG, WAV, glTF…), Godot
 automatically *imports* it: it converts the raw file into an optimised
 internal format stored in the hidden `.godot/imported/` folder. The
 original file is kept as the source of truth; the imported version is what the
 engine uses at runtime.

To view and change import settings: select a file in the FileSystem dock, then
 click the **Import** tab at the top of the editor (next to the Scene
 tab, above the viewport).

| Asset type | Key import settings |
| --- | --- |
| PNG / WebP (Texture2D) | Compress mode (Lossless / VRAM / Basis Universal), Mipmaps, Filter (Nearest for pixel art), sRGB |
| WAV | Loop mode, loop begin/end sample points, 8-bit conversion, normalise |
| OGG | Loop mode (OGG loops at stream level — set loop in your DAW or via import) |
| glTF / FBX (3D model) | Root scale, bone axes, import animations, generate LODs, create collision |
| TTF / OTF (Font) | Antialiasing, subpixel rendering, pre-render glyph sizes for performance |
| SVG | Scale, fixed size — rasterised to a Texture2D at import time |

Every imported file gains a `.import` sidecar (e.g.
 `player.png.import`) storing which settings were used. Commit these
 sidecar files to version control alongside the source assets — without them,
 teammates will re-import with different settings.

### Pixel Art Import Fix

New textures default to *linear filtering*, which blurs pixel art. Fix it
 per-texture or globally:

**Per-texture:**

1. Select the PNG in the FileSystem dock.
2. Open the **Import** tab.
3. Set **Filter** to `Nearest`.
4. Click **Re-Import**.

**Globally (recommended for pixel art projects):**

 **Project → Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter → Nearest**

:::callout-tip[Save import presets]
After configuring a file's import settings, click the **Preset ▾**
 dropdown in the Import tab and choose **Save as Default for
 <type>**. All future imports of that type (e.g. all PNGs) will
 use your preset automatically.
:::

## 7. Resource Sharing & Uniqueness

Resources are shared by reference. Assigning the same resource to two nodes
 means both point to the same object in memory. Modifying the resource through
 one node changes what the other sees.

```gdscript
extends Node2D

func _ready() -> void:
    var mat: StandardMaterial3D = preload("res://materials/enemy_red.tres")

    $EnemyA.material_override = mat
    $EnemyB.material_override = mat   # same object, same reference

    # This changes BOTH enemies to blue — they share the material
    mat.albedo_color = Color.BLUE
```

Sharing is intentional and efficient for read-only data: one copy of a
 `TileSet`, one copy of a `Font`, one copy of
 `goblin_stats.tres`. It becomes a trap when you expect each node to
 have its own independent values.

### .duplicate() — Making Independent Copies

Call `.duplicate()` to create a new independent instance with the same
 values. The `subresources: bool` parameter controls whether nested
 resources are also copied (deep copy) or just referenced (shallow copy):

```gdscript
func _ready() -> void:
    var base_mat: StandardMaterial3D = preload("res://materials/enemy_red.tres")

    # Each enemy gets its own copy — changing one won't affect the other
    $EnemyA.material_override = base_mat.duplicate()
    $EnemyB.material_override = base_mat.duplicate()

    # Safe — only EnemyA turns blue
    $EnemyA.material_override.albedo_color = Color.BLUE

# ── Deep vs Shallow ────────────────────────────────────────────
var shallow := base_stats.duplicate()          # nested resources still shared
var deep    := base_stats.duplicate(true)      # nested resources also cloned

# For a boss that should have modified stats without affecting regular enemies:
func promote_to_boss(enemy: Enemy) -> void:
    enemy.stats = enemy.stats.duplicate(true)   # deep copy
    enemy.stats.max_health *= 2
    enemy.stats.display_name = "BOSS " + enemy.stats.display_name
    enemy._hp = enemy.stats.max_health          # reset HP to new max
```

:::callout-intuition[Local vs external resources in scenes]
When you create a resource directly in the Inspector (rather than loading
 a .tres file), it becomes a *local resource* — stored inside the
 `.tscn` file, not as a separate file. It can't be reused across
 different scenes. To promote it to a reusable external resource: click its
 name in the Inspector → **Save As…** — Godot saves the
 `.tres` file and replaces the inline data with a reference to it.
:::

:::summary
## Chapter Summary

### Resource quick-reference

| Task | How |
| --- | --- |
| Define a custom resource | `class_name Foo extends Resource` + `@export` vars |
| Create a .tres in editor | FileSystem dock → right-click → New Resource… |
| Load at compile time | `const X = preload("res://path/file.tres")` |
| Load at runtime | `var x: MyType = load("res://path/" + name + ".tres")` |
| Load safely | `if not FileAccess.file_exists(path): return` |
| Save at runtime | `ResourceSaver.save(resource, "user://file.tres")` |
| Make independent copy | `resource.duplicate()` / `resource.duplicate(true)` |
| Background load | `ResourceLoader.load_threaded_request(path)` |
| Writable path (exports) | `user://` — never `res://` for writing |
| Fix pixel art blur | Import tab → Filter: Nearest → Re-Import |

### If you remember nothing else

**Custom resources replace dictionaries.** Wherever you're
 tempted to write `{"name": "sword", "damage": 10}`, write a
 `WeaponData extends Resource` instead. You get type safety,
 Inspector editing, save/load for free, and the ability to reference other
 resources as nested properties. The `.tres` file format is
 human-readable, version-control friendly, and costs nothing to use.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
For each of the following, say whether it should be a **Node**
 or a **Resource** and briefly explain why: (a) a player character
 that moves and jumps; (b) a set of dialogue lines for an NPC; (c) a countdown
 Timer; (d) a colour palette used by multiple shader materials across the project.

::::solution[Solution]
(a) **Node** — the player has behaviour (`_physics_process`,
 collision, input), exists in the scene tree, and interacts with physics. It
 is not data.

 (b) **Resource** — dialogue lines are pure data. A
 `DialogueData extends Resource` with an
 `Array[String] lines` can be saved as
 `npc_shopkeeper.tres`, edited by designers, and assigned to the
 NPC node.

 (c) **Node** — Timer is a Godot node. It needs to enter the
 scene tree to run its countdown and emit its `timeout` signal.

 (d) **Resource** — a colour palette is pure data.
 A `ColourPalette extends Resource` with an
 `Array[Color]` can be created once and referenced by every
 material that needs it. Changing one palette updates all materials
 simultaneously (shared reference).
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
Why does this fail to compile, and what is the fix?

```gdscript
var skin_name: String = "fire"
const SKIN: SkinData = preload("res://skins/" + skin_name + ".tres")
```

::::solution[Solution]
`preload()` runs at parse time — before any variable has a
 value. It only accepts string *literals*. The fix: use
 `load()` at runtime instead:

```gdscript
var skin_name: String = "fire"

func _ready() -> void:
    var skin: SkinData = load("res://skins/" + skin_name + ".tres") as SkinData
    if skin:
        apply_skin(skin)
```
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
Write a `WeaponData extends Resource` with: `weapon_name:
 String`, `damage: int`, `fire_rate: float` (shots
 per second), `projectile_scene: PackedScene`, and
 `shoot_sfx: AudioStream`. Add a computed property
 `cooldown_seconds: float` (getter only — returns
 `1.0 / fire_rate`) and handle the `fire_rate == 0`
 edge case.

::::solution[Solution]
```gdscript
# weapon_data.gd
class_name WeaponData
extends Resource

@export var weapon_name: String = "Pistol"
@export var damage: int = 10
@export var fire_rate: float = 3.0   # shots per second
@export var projectile_scene: PackedScene
@export var shoot_sfx: AudioStream

# Read-only computed property — not exported (derived from fire_rate)
var cooldown_seconds: float:
    get:
        return 1.0 / fire_rate if fire_rate > 0.0 else INF
```
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Write a `Settings extends Resource` with `master_volume:
 float`, `fullscreen: bool`, and `language: String`.
 Then write `SettingsManager.gd` (an Autoload) with two methods:
 `save()` and `load() -> Settings`. `load()`
 must return a default `Settings.new()` if no file exists, and
 push an error (not crash) if the file exists but is the wrong type.

::::solution[Solution]
```gdscript
# settings.gd
class_name Settings
extends Resource

@export var master_volume: float = 1.0
@export var fullscreen: bool = false
@export var language: String = "en"
```

```gdscript
# SettingsManager.gd (Autoload named "SettingsManager")
extends Node

const PATH: String = "user://settings.tres"
var current: Settings = Settings.new()

func _ready() -> void:
    current = load_settings()

func save_settings() -> void:
    var err: Error = ResourceSaver.save(current, PATH)
    if err != OK:
        push_error("Settings save failed: " + error_string(err))

func load_settings() -> Settings:
    if not FileAccess.file_exists(PATH):
        return Settings.new()   # first launch
    var s: Settings = load(PATH) as Settings
    if s == null:
        push_error("Settings file corrupt — using defaults")
        return Settings.new()
    return s
```
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
You have 10 enemies sharing the same `EnemyStats` resource (loaded
 via `preload()`). At runtime you want the final boss to have double
 HP and a different name — without affecting the regular enemies. Write the
 code that promotes one specific enemy to boss status.

::::solution[Solution]
```gdscript
func promote_to_boss(enemy: Enemy) -> void:
    # duplicate(true) = deep copy, including nested sub-resources
    enemy.stats = enemy.stats.duplicate(true)
    enemy.stats.max_health *= 2
    enemy.stats.display_name = "☠ " + enemy.stats.display_name + " KING"
    # Reset enemy's current HP to the new maximum
    enemy._hp = enemy.stats.max_health
    enemy.$HealthBar.max_value = enemy.stats.max_health
    enemy.$HealthBar.value = enemy._hp
    enemy.$NameLabel.text = enemy.stats.display_name
```

Without `.duplicate(true)`, modifying
 `enemy.stats.max_health` would change the value for all 10 enemies
 — they all reference the same `EnemyStats` object.
::::
:::

:::problem[Problem M.6 challenge]{difficulty="challenge"}
Build a weighted random loot system. Define two resource classes:
 `LootEntry extends Resource` (with `item: ItemData`
 and `weight: float`) and `LootTable extends Resource`
 (with `entries: Array[LootEntry]` and a
 `roll() -> ItemData` method). The roll should be weighted — if
 Common has weight 10 and Rare has weight 1, Common should drop roughly 10×
 more often. Return `null` if the table is empty.

::::solution[Solution]
```gdscript
# loot_entry.gd
class_name LootEntry
extends Resource

@export var item: ItemData
@export var weight: float = 1.0
```

```gdscript
# loot_table.gd
class_name LootTable
extends Resource

@export var entries: Array[LootEntry] = []

func roll() -> ItemData:
    if entries.is_empty():
        return null

    # Sum all weights
    var total: float = 0.0
    for e in entries:
        total += maxf(0.0, e.weight)   # guard against negative weights

    if total <= 0.0:
        return null   # all weights were zero or negative

    # Pick a random point in [0, total)
    var pick: float = randf() * total
    var cumulative: float = 0.0
    for e in entries:
        cumulative += maxf(0.0, e.weight)
        if pick < cumulative:
            return e.item

    # Floating-point edge case: return last entry
    return entries.back().item if entries.back().item else null
```

With a Goblin loot table containing Common Coin (weight 10), Uncommon
 Dagger (weight 3), and Rare Ruby (weight 1): total = 14. A random float
 in [0, 14) falls below 10 about 71% of the time (Common), between 10 and
 13 about 21% (Uncommon), and 13–14 about 7% (Rare).
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
