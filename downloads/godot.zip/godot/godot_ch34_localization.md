---
title: "Localisation & Accessibility"
source: "godot_ch34_localization.html"
---

Part IV · Chapter 34

# Localisation & Accessibility

Prerequisite: Ch 4 (GDScript), Ch 8 (UI basics) · est. 70 min

## Overview

Localisation (l10n) is the process of adapting your game for different
 languages and regions. Accessibility (a11y) is the broader goal of making
 your game playable by as many people as possible, including players with
 visual, auditory, motor, or cognitive differences. Both are best treated
 as design requirements from the start — retrofitting them into a finished
 game is far more expensive.

Godot 4 supports:

- `tr()` and `tr_n()` for string translation with
 plural forms and context.
- CSV and GNU gettext (`.po`) translation file formats.
- Full Unicode text rendering including bidirectional (RTL) text and CJK
 character sets via the `TextServer` subsystem.
- Font fallback chains for multilingual characters.
- UI accessibility hints surfaced to screen readers via the OS
 accessibility API.

Godot Localisation Pipeline

Translation file

.csv  or  .po

key = "GREET"

en = "Hello!"

import

Translation

Server

active locale: "fr"

holds all translations

singleton, auto-loaded

tr("GREET")

looks up key in

active locale

Localised string

"Bonjour !"  (fr)

"Hola!"  (es)

"こんにちは"  (ja)

TranslationServer.set\_locale("fr")  →  all tr() calls instantly return French strings

Import a CSV or PO file → TranslationServer holds all locales in memory → every `tr("KEY")` call returns the string for the active locale. Changing locale at runtime instantly re-translates every label that uses `tr()`.

## 1 · TranslationServer

### 1.1 · tr() and tr\_n()

The global `tr(key)` function looks up `key` in the
 active translation and returns the localised string. If no translation is
 found, the key itself is returned unchanged — so untranslated keys are
 still legible during development.

```gdscript
## Anywhere in GDScript:
var label_text: String = tr("BUTTON_START_GAME")  # → "Start Game" (en), "Spiel starten" (de)

## With string interpolation:
var coins: int = 42
var message: String = tr("HUD_COINS") % coins      # → "Coins: 42"

## In the scene editor:
## Set a Label's text to a translation key.  Godot wraps it with tr() at runtime.
## Simply type the key string (e.g. MENU_QUIT) in the Text property field.
```

**Best practice for keys:** use SCREAMING\_SNAKE\_CASE keys that
 describe the *context and purpose* of the string, not its English
 content. A key like `BUTTON_CONFIRM_PURCHASE` is better than
 `Yes` because the same word "Yes" might require different
 translations depending on context in some languages.

:::callout-tip[Tip — auto-translation in the editor]
When a

Label

,

Button

, or other control node has
        its text set to a translation key, Godot automatically applies

tr()

when the locale changes.  You do not need to write
        any code for this — just set the text to the key string and add the
        translations.
:::

### 1.2 · CSV translation files

For small-to-medium projects, CSV files are the simplest format.
 Create `res://translations/strings.en.csv` with this structure:

```
keys,en,de,ja,ar
BUTTON_START_GAME,Start Game,Spiel starten,ゲームを始める,ابدأ اللعبة
BUTTON_QUIT,Quit,Beenden,終了,خروج
HUD_COINS,Coins: %d,Münzen: %d,コイン: %d,عملات: %d
HUD_HEALTH,HP: %d / %d,LP: %d / %d,HP: %d / %d,صحة: %d / %d
MENU_SETTINGS,Settings,Einstellungen,設定,إعدادات
```

Import the CSV: in the FileSystem dock, click the `.csv` file
 → *Import* tab → set *Mode* to *CSV*. Godot
 generates a `.translation` binary for each language column.
 Add all generated `.translation` resources to
 *Project Settings → Localisation → Translations*.

:::callout-warning[Warning — CSV encoding]
Save the CSV as

UTF-8 without BOM

.  Many spreadsheet
        applications (Excel on Windows) add a BOM byte-order mark that confuses
        the importer.  Use a code editor or set the export options explicitly.
:::

### 1.3 · PO / gettext files

For larger projects — or when working with professional translators who
 use translation CAT tools — GNU gettext `.po` files are
 the better choice. Each language gets one `.po` file:

```po
# translations/de.po
msgid ""
msgstr ""
"Content-Type: text/plain; charset=UTF-8\n"
"Plural-Forms: nplurals=2; plural=(n != 1);\n"

msgid "BUTTON_START_GAME"
msgstr "Spiel starten"

msgid "ITEM_COUNT"
msgid_plural "ITEM_COUNT_PLURAL"
msgstr[0] "%d Gegenstand"
msgstr[1] "%d Gegenstände"
```

Import identically to CSV: the importer detects `.po` files
 automatically and generates `.translation` binaries.

### 1.4 · Adding translations at runtime

The `TranslationServer` singleton manages all loaded translations
 and the active locale:

```gdscript
## Load and register a translation object programmatically.
## Useful for DLC or modded content that ships separate translation files.
func load_dlc_translation(path: String) -> void:
    var translation: Translation = load(path)
    if translation == null:
        push_error("Failed to load translation: %s" % path)
        return
    TranslationServer.add_translation(translation)

## Translate a key directly (same as tr() global function).
var text: String = TranslationServer.translate("BUTTON_START_GAME")

## Get all loaded locale codes.
var locales: PackedStringArray = TranslationServer.get_loaded_locales()
```

## 2 · Locale Management

### 2.1 · Setting locale at runtime

```gdscript
## Change the game language to German.
TranslationServer.set_locale("de")

## Read the current locale.
var current: String = TranslationServer.get_locale()  # e.g. "en_US"

## Get the system locale (detected from the OS).
var system: String = OS.get_locale()    # e.g. "ja_JP"
var system_lang: String = OS.get_locale_language()  # e.g. "ja"
```

Changing the locale immediately updates all `Label`,
 `Button`, and `RichTextLabel` nodes whose text is set
 to a translation key. Custom UI that formats strings in code must manually
 refresh after a locale change by listening to the signal:

```gdscript
## Connect in _ready() to react when the locale changes.
TranslationServer.locale_changed.connect(_on_locale_changed)

func _on_locale_changed() -> void:
    _refresh_ui()
```

### 2.2 · Common locale codes

| Code | Language | Notes |
| --- | --- | --- |
| `en` | English | Use `en_US` / `en_GB` for regional variants |
| `de` | German |  |
| `fr` | French |  |
| `es` | Spanish | `es_ES` vs `es_MX` |
| `pt_BR` | Brazilian Portuguese | Common in game markets |
| `ja` | Japanese | Requires CJK font |
| `ko` | Korean | Requires CJK font |
| `zh_CN` | Simplified Chinese | Requires CJK font |
| `zh_TW` | Traditional Chinese | Requires CJK font |
| `ar` | Arabic | RTL; requires full TextServer |
| `ru` | Russian | Cyrillic — ensure font covers it |

### 2.3 · Persisting the locale

```gdscript
## Save the chosen locale to settings.
func save_locale(code: String) -> void:
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value("locale", "code", code)
    cfg.save("user://settings.cfg")
    TranslationServer.set_locale(code)

## Restore the locale at startup (call from _ready() of your main scene or autoload).
func load_locale() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") != OK:
        return
    var code: String = cfg.get_value("locale", "code", OS.get_locale_language())
    TranslationServer.set_locale(code)
```

## 3 · Fonts & Text Rendering

Godot 4 uses the `TextServer` subsystem for text layout. The
 full-featured variant (FreeType + ICU, enabled by default) supports Unicode
 bidirectional text, ligatures, Arabic shaping, and CJK ideographs.
 The lightweight variant supports Latin scripts only — choose it only for
 platforms where binary size is critical.

### 3.1 · Font fallback chains

A single font file rarely covers all the characters your game might display.
 Godot resolves missing glyphs by walking a **fallback chain**:
 if the primary font does not contain a codepoint, the next font in the
 chain is tried, and so on.

Set up a fallback chain on a `FontFile` resource:

```gdscript
## In code — build a font with a CJK fallback.
var font := FontFile.new()
font.load_dynamic_font("res://fonts/NotoSans-Regular.ttf")

var cjk_fallback := FontFile.new()
cjk_fallback.load_dynamic_font("res://fonts/NotoSansCJK-Regular.otf")

var arabic_fallback := FontFile.new()
arabic_fallback.load_dynamic_font("res://fonts/NotoSansArabic-Regular.ttf")

font.fallbacks = [cjk_fallback, arabic_fallback]

## Assign to a Label.
$Label.add_theme_font_override("font", font)
```

:::callout-tip[Tip — Noto fonts]
Google's

Noto

font family ("No Tofu" — tofu □ is the
        placeholder box for missing glyphs) covers nearly every writing system.
        Download the relevant Noto fonts for your target languages and assemble a
        fallback chain.  The Noto Sans CJK "Super OTC" is a single file containing
        Simplified Chinese, Traditional Chinese, Japanese, and Korean.
:::

### 3.2 · Right-to-left and bidirectional text

Arabic, Hebrew, and other RTL scripts require the full TextServer (enabled
 by default). Godot handles the visual reordering automatically when the
 text contains RTL characters. However, you must explicitly set text
 direction on UI nodes that mix LTR and RTL content:

```gdscript
## Force RTL layout on a Label for Arabic/Hebrew text.
$Label.text_direction = Control.TEXT_DIRECTION_RTL

## Use AUTO to let Godot detect direction from the first strong character.
$Label.text_direction = Control.TEXT_DIRECTION_AUTO

## For entire UI panels with RTL content, also mirror the layout direction.
$VBoxContainer.layout_direction = Control.LAYOUT_DIRECTION_RTL
```

:::callout-pitfall[Pitfall — hard-coded left/right UI offsets]
When you mirror a container's layout direction, all children flip.  If you
        have hard-coded pixel offsets (e.g. an icon always 8 px from the left edge),
        those become 8 px from the

right

edge in RTL mode — which may be
        correct, or may need separate RTL logic.  Design UI with anchors and
        containers rather than pixel offsets to make RTL mirroring automatic.
:::

## 4 · Plural Forms & Context

### 4.1 · Pluralisation with tr\_n()

Many languages have complex plural rules. English has two forms (1 item /
 2 items); Polish has four; Arabic has six. Use `tr_n()` to
 select the correct plural form for the current locale:

```gdscript
## tr_n(singular_key, plural_key, count) → localised string
var item_count: int = 3
var msg: String = tr_n("ITEM_COUNT_ONE", "ITEM_COUNT_MANY", item_count) % item_count
# In English → "3 items"
# In Russian → "3 предмета"  (genitive singular, used for 2–4)
# In Polish  → "3 przedmioty" (plural)
```

In the PO file, declare plural forms in the header and provide
 `msgstr[n]` variants for each form index:

```po
# ru.po
msgid ""
msgstr ""
"Plural-Forms: nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);\n"

msgid "ITEM_COUNT_ONE"
msgid_plural "ITEM_COUNT_MANY"
msgstr[0] "%d предмет"
msgstr[1] "%d предмета"
msgstr[2] "%d предметов"
```

### 4.2 · Translation context

The same key may need different translations in different UI locations.
 Godot supports a *context* string as a third argument to
 `tr()` to disambiguate:

```gdscript
## "Back" as a navigation button vs "Back" as the back of a card.
var back_nav:  String = tr("BACK", "navigation")
var back_card: String = tr("BACK", "card_face")
```

In the PO file, use `msgctxt` to separate contexts:

```po
msgctxt "navigation"
msgid "BACK"
msgstr "Zurück"

msgctxt "card_face"
msgid "BACK"
msgstr "Rückseite"
```

## 5 · Accessibility

### 5.1 · Scalable font size

Never hard-code font sizes in the editor. Instead, store a base size in
 a `ThemeDB` theme or a global settings variable, then scale
 it by a user-controlled multiplier:

```gdscript
## res://autoloads/settings.gd  (autoload name: Settings)
extends Node

signal font_scale_changed(scale: float)

var font_scale: float = 1.0:
    set(v):
        font_scale = clampf(v, 0.5, 2.5)
        _apply_font_scale()
        font_scale_changed.emit(font_scale)

const BASE_FONT_SIZE := 16

func _apply_font_scale() -> void:
    # Modifying the default theme affects all Label nodes that don't override.
    var theme: Theme = ThemeDB.get_default_theme()
    theme.set_font_size("font_size", "Label",
                        int(BASE_FONT_SIZE * font_scale))
    theme.set_font_size("font_size", "Button",
                        int(BASE_FONT_SIZE * font_scale))
```

:::callout-warning[Warning — UI layout breakage at large sizes]
Increasing font size beyond what the container was designed for causes text
        to clip or overflow.  Use

Label.autowrap\_mode = TextServer.AUTOWRAP\_WORD

on all multi-word labels, and prefer flexible containers
        (

VBoxContainer

,

ScrollContainer

) over fixed-size

Panel

nodes with pixel-locked children.
:::

### 5.2 · Colour-blind modes

Approximately 8% of males and 0.5% of females have some form of colour
 vision deficiency. Never use colour as the *sole* indicator of
 game state. Add shape, pattern, or text reinforcement for all
 colour-coded information.

For players who prefer a colour filter, apply a
 `ColorCorrectionEffect` (or a full-screen shader) to the
 environment. Three common simulation modes:

```gdscript
## res://autoloads/accessibility.gd
extends Node

enum ColorBlindMode { NONE, PROTANOPIA, DEUTERANOPIA, TRITANOPIA }

@onready var _overlay: ColorRect = $ColourBlindOverlay   # full-screen rect, top of canvas

var mode: ColorBlindMode = ColorBlindMode.NONE:
    set(v):
        mode = v
        _apply_mode()

func _apply_mode() -> void:
    var mat: ShaderMaterial = _overlay.material
    if mat == null:
        return
    match mode:
        ColorBlindMode.NONE:
            _overlay.visible = false
        ColorBlindMode.PROTANOPIA:
            _overlay.visible = true
            mat.set_shader_parameter("type", 0)   # red-blind matrix
        ColorBlindMode.DEUTERANOPIA:
            _overlay.visible = true
            mat.set_shader_parameter("type", 1)   # green-blind matrix
        ColorBlindMode.TRITANOPIA:
            _overlay.visible = true
            mat.set_shader_parameter("type", 2)   # blue-blind matrix
```

The corresponding shader applies a colour-matrix transformation that
 simulates the relevant deficiency:

```glsl
// colour_blind_sim.gdshader
shader_type canvas_item;
render_mode unshaded;

uniform int type = 0;   // 0=protanopia, 1=deuteranopia, 2=tritanopia
uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_nearest;

void fragment() {
    vec3 col = texture(SCREEN_TEXTURE, SCREEN_UV).rgb;
    mat3 m;
    if (type == 0) {    // Protanopia
        m = mat3(vec3(0.567, 0.433, 0.0),
                 vec3(0.558, 0.442, 0.0),
                 vec3(0.0,   0.242, 0.758));
    } else if (type == 1) { // Deuteranopia
        m = mat3(vec3(0.625, 0.375, 0.0),
                 vec3(0.7,   0.3,   0.0),
                 vec3(0.0,   0.3,   0.7));
    } else {            // Tritanopia
        m = mat3(vec3(0.95,  0.05,  0.0),
                 vec3(0.0,   0.433, 0.567),
                 vec3(0.0,   0.475, 0.525));
    }
    COLOR = vec4(m * col, 1.0);
}
```

### 5.3 · Subtitles and captions

Subtitles (dialogue text) and captions (sound descriptions like "[footsteps]"
 or "[explosion]") benefit players who are deaf or hard-of-hearing, and also
 players in noisy environments.

A simple subtitle system:

```gdscript
## res://autoloads/subtitle_manager.gd
## Autoload name: SubtitleManager
extends Node

signal subtitle_shown(text: String, duration: float)
signal subtitle_hidden()

var show_subtitles: bool = true
var _timer: SceneTreeTimer

## Show a subtitle for 'duration' seconds.
func show(text: String, duration: float = 3.0) -> void:
    if not show_subtitles:
        return
    subtitle_shown.emit(text, duration)
    if _timer != null:
        _timer = null   # cancel previous
    _timer = get_tree().create_timer(duration)
    _timer.timeout.connect(subtitle_hidden.emit, CONNECT_ONE_SHOT)

## A SubtitleLabel node in the HUD listens to these signals.
## In SubtitleLabel._ready():
## SubtitleManager.subtitle_shown.connect(_on_subtitle_shown)
## SubtitleManager.subtitle_hidden.connect(func(): text = "")
```

### 5.4 · Screen-reader hints

Godot exposes accessibility properties on `Control` nodes that
 are passed to the OS accessibility tree (e.g. Windows Narrator, macOS
 VoiceOver):

```gdscript
## Label or Button — set a description for screen readers.
$StartButton.focus_mode   = Control.FOCUS_ALL
$StartButton.tooltip_text = "Starts a new game session"

## For custom drawn controls, provide an accessible name.
$HealthBar.accessibility_name  = "Health bar"
$HealthBar.accessibility_value = "%d of %d HP" % [hp, max_hp]
```

:::callout-tip[Tip — focus traversal order]
Tab

focus navigation is the primary navigation method for
        keyboard and assistive technology users.  In the Inspector →

Focus

section of every

Control

, set the

Next

and

Previous

neighbours explicitly rather than relying on the
        auto-detected order, which can be unintuitive for non-linear UIs.
:::

## 6 · Pseudo-locale Testing

A pseudo-locale generates fake "translations" from your English source
 strings without requiring real translators. It is invaluable for catching
 layout bugs early. Godot supports two types:

- **Accented pseudo-locale** (`en_XA`) — replaces
 Latin characters with accented lookalikes (e.g. "Start" → "Ŝţàŕţ").
 Tests whether your fonts and text containers handle diacritics.
- **Bidi pseudo-locale** (`ar_XB`) — wraps text
 with RTL markers and reverses word order. Tests RTL layout.

```gdscript
## Enable pseudo-locale for testing:
TranslationServer.set_locale("en_XA")   # accented
TranslationServer.set_locale("ar_XB")  # bidi
```

In the editor, enable pseudo-locale permanently via
 *Project Settings → General → Internationalization → Pseudolocalization* (not the Localisation tab, which holds Translations, Remaps and POT Generation).
 Toggle options include string expansion (pads text by 40% to simulate
 German's longer words), all-caps, and bidi override.

:::callout-intuition[Intuition — the 40% rule]
German translations of English UI strings are on average 30–40% longer.
        Russian can be 50% longer.  If your UI panels are sized exactly for
        English, they will clip in most other languages.  The pseudo-locale
        string-expansion mode automatically pads strings to catch these problems
        before you have real translations.
:::

## Summary

`tr(key)` is the single entry point for all user-visible strings.
 Translation tables are stored in CSV or PO files, imported to
 `.translation` binaries, and registered in Project Settings.
 `TranslationServer.set_locale()` changes the active language at
 runtime and triggers automatic refresh of all control node text.
 Font fallback chains handle multilingual character sets; the full TextServer
 backend supports RTL and bidirectional text via
 `text_direction` and `layout_direction` properties.
 `tr_n()` handles plural forms; `tr(key, context)`
 disambiguates identical keys in different UI contexts.
 Accessibility features include scalable font size via a
 `ThemeDB`-driven multiplier, colour-blind simulation shaders,
 a subtitle manager autoload, and screen-reader hints on
 `Control` nodes.
 Pseudo-locale modes (`en_XA`, `ar_XB`) expose UI
 layout bugs before real translations exist.

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Language picker.**
 Write a function `set_language_from_option(index: int)`
 suitable for connecting to an `OptionButton.item_selected`
 signal. The OptionButton items are: 0 = English, 1 = German, 2 = French,
 3 = Spanish, 4 = Japanese. The function should set the locale, persist
 it via `ConfigFile`, and print the new locale to confirm.

::::solution[Solution]
```gdscript
const LOCALE_MAP: Array[String] = ["en", "de", "fr", "es", "ja"]

func set_language_from_option(index: int) -> void:
    if index < 0 or index >= LOCALE_MAP.size():
        return
    var code: String = LOCALE_MAP[index]
    TranslationServer.set_locale(code)
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value("locale", "code", code)
    cfg.save("user://settings.cfg")
    print("Locale set to: %s" % code)
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Plural item count label.**
 Write a helper `format_item_count(n: int) -> String` that
 returns a localised string using `tr_n()` with keys
 `"ITEM_SINGULAR"` and `"ITEM_PLURAL"` and
 substitutes the count. Assume the English translations are
 `"1 item"` and `"%d items"`.

::::solution[Solution]
```gdscript
func format_item_count(n: int) -> String:
    return tr_n("ITEM_SINGULAR", "ITEM_PLURAL", n) % n

## For this to work, add to your .en CSV / PO:
## ITEM_SINGULAR → "1 item"   (no %d — n is always 1 here)
## ITEM_PLURAL   → "%d items"
## For a unified key, use: tr_n("ITEM_COUNT", "ITEM_COUNT", n) % n
## with PO msgstr[0] = "1 item" and msgstr[1] = "%d items"
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Font scale slider.**
 Create a `FontScaleSlider` script for an `HSlider`
 (range 0.5–2.5, step 0.05). On `_ready()`, load the saved
 scale from `ConfigFile` and set the slider value. On
 `value_changed`, update `Settings.font_scale` and
 save to config. Connect to
 `Settings.font_scale_changed` to keep the slider in sync
 if the scale is changed from elsewhere.

::::solution[Solution]
```gdscript
## res://ui/options/font_scale_slider.gd
extends HSlider

func _ready() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") == OK:
        value = cfg.get_value("accessibility", "font_scale", 1.0)
    else:
        value = 1.0
    value_changed.connect(_on_value_changed)
    Settings.font_scale_changed.connect(func(s: float): value = s)

func _on_value_changed(v: float) -> void:
    Settings.font_scale = v
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value("accessibility", "font_scale", v)
    cfg.save("user://settings.cfg")
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Dynamic subtitle label.**
 Create a `SubtitleLabel` script (extends `Label`)
 that connects to `SubtitleManager.subtitle_shown` and
 `subtitle_hidden`. On show, set the text and fade in over
 0.2 seconds (modulate.a 0→1). On hide, fade out over 0.5 seconds
 then clear the text. Interrupt any running tween when a new subtitle
 arrives.

::::solution[Solution]
```gdscript
extends Label

var _tween: Tween

func _ready() -> void:
    modulate.a = 0.0
    SubtitleManager.subtitle_shown.connect(_on_show)
    SubtitleManager.subtitle_hidden.connect(_on_hide)

func _on_show(sub_text: String, _dur: float) -> void:
    text = sub_text
    if _tween: _tween.kill()
    _tween = create_tween()
    _tween.tween_property(self, "modulate:a", 1.0, 0.2)

func _on_hide() -> void:
    if _tween: _tween.kill()
    _tween = create_tween()
    _tween.tween_property(self, "modulate:a", 0.0, 0.5)
    await _tween.finished
    text = ""
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Pseudo-locale tester.**
 Write a debug tool (extends `Node`, added only to the debug
 build via `OS.is_debug_build()`) that cycles through locales
 with F9. The cycle order is: `en → de → ja → ar → en_XA → ar_XB → en`.
 Display the current locale in a corner label that auto-hides after
 2 seconds. Use a `SceneTreeTimer` for the auto-hide.

::::solution[Solution]
```gdscript
extends Node

const LOCALES: Array[String] = ["en", "de", "ja", "ar", "en_XA", "ar_XB"]
var _idx: int = 0
var _label: Label
var _hide_timer: SceneTreeTimer

func _ready() -> void:
    if not OS.is_debug_build():
        queue_free()
        return
    _label = Label.new()
    _label.modulate.a = 0.0
    _label.position   = Vector2(10, 10)
    _label.z_index    = 100
    get_tree().root.add_child(_label)

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.keycode == KEY_F9 and event.pressed:
        _idx = (_idx + 1) % LOCALES.size()
        var code: String = LOCALES[_idx]
        TranslationServer.set_locale(code)
        _label.text      = "Locale: %s" % code
        _label.modulate.a = 1.0
        if _hide_timer != null:
            _hide_timer = null
        _hide_timer = get_tree().create_timer(2.0)
        _hide_timer.timeout.connect(func(): _label.modulate.a = 0.0)
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Full LocalisationManager autoload.**
 Build a `LocalisationManager` autoload that:
 loads the saved locale from `ConfigFile` on startup
 (falling back to the OS locale, then to `"en"` if unsupported);
 exposes `set_locale(code)` and `get_available_locales() -> Array[String]`
 (derived from `TranslationServer.get_loaded_locales()`);
 emits `locale_changed(code: String)`;
 provides `t(key: String, context: String = "") -> String` as a
 convenience wrapper for `tr()` with context;
 and provides `tn(singular: String, plural: String, n: int) -> String`
 as a wrapper for `tr_n()` that also substitutes
 `%d` with `n`.

::::solution[Solution]
```gdscript
## res://autoloads/localisation_manager.gd
extends Node

signal locale_changed(code: String)

const CFG_SECTION := "locale"
const CFG_KEY     := "code"

func _ready() -> void:
    var code: String = _load_saved_locale()
    TranslationServer.set_locale(code)

func _load_saved_locale() -> String:
    var cfg := ConfigFile.new()
    if cfg.load("user://settings.cfg") == OK:
        var saved: String = cfg.get_value(CFG_SECTION, CFG_KEY, "")
        if saved != "" and _is_supported(saved):
            return saved
    # Fall back to OS language.
    var os_lang: String = OS.get_locale_language()
    if _is_supported(os_lang):
        return os_lang
    return "en"

func _is_supported(code: String) -> bool:
    return code in TranslationServer.get_loaded_locales()

func set_locale(code: String) -> void:
    TranslationServer.set_locale(code)
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value(CFG_SECTION, CFG_KEY, code)
    cfg.save("user://settings.cfg")
    locale_changed.emit(code)

func get_available_locales() -> Array[String]:
    var raw: PackedStringArray = TranslationServer.get_loaded_locales()
    var result: Array[String] = []
    result.assign(raw)
    return result

func t(key: String, context: String = "") -> String:
    if context.is_empty():
        return tr(key)
    return tr(key, context)

func tn(singular: String, plural: String, n: int) -> String:
    return tr_n(singular, plural, n) % n
```
::::
:::
