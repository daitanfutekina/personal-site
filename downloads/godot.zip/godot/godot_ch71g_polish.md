---
title: "VS Clone — VFX, Screen Shake, Audio & Polish"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71G"
meta:
  - "Est. study time: ~60 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated June 2026"
source: "godot_ch71g_polish.html"
---

## Overview

Mechanics make a game playable. Polish makes it feel good. A swarm of 200 enemies
 dying silently to invisible pulses is functional but hollow. Add a white flash on
 each hit, a particle burst on death, a camera shudder when the player takes damage,
 a satisfying level-up glow, and a driving soundtrack — and every second of play
 feels meaningful.

Every effect in this chapter is self-contained. If you skip any section the game
 still works. Each one is a targeted addition to an existing scene — no architectural
 changes, no refactoring.

## 1. Enemy Hit Flash

When an enemy takes damage, briefly tint its sprite white. A Tween handles the flash
 — no AnimationPlayer or Timer node needed.

### Code changes — EnemyBase.gd only

No editor steps required. Open `res://scenes/enemies/EnemyBase.gd`
 and add the following:

```gdscript
## Add near the top of EnemyBase.gd:
var _flash_tween: Tween

## Update take_damage() to call _flash_white():
func take_damage(amount: float) -> void:
    _hp -= amount
    _flash_white()
    if _hp <= 0.0:
        _die()

## Add the flash method:
func _flash_white() -> void:
    ## Kill any running flash tween first — rapid hits would stack otherwise.
    if _flash_tween:
        _flash_tween.kill()
    _flash_tween = create_tween()
    ## Snap to full white, then fade back to normal over 0.10 s.
    _flash_tween.tween_property(sprite, "modulate", Color.WHITE,       0.05)
    _flash_tween.tween_property(sprite, "modulate", Color(1, 1, 1, 1), 0.10)
```

:::callout-tip[Kill the old tween before creating a new one]
If an enemy is hit twice in quick succession, two Tweens would compete over
 `modulate` — the second would start mid-animation and produce a
 visible glitch. `_flash_tween.kill()` cancels the previous animation
 immediately before starting the new one.
:::

## 2. Death Burst Particles — Build HitEffect.tscn

A pooled one-shot GPUParticles2D fires at the enemy's death position and
 automatically returns to the pool when the burst finishes.

```
HitEffect (Node2D)               ← HitEffect.gd; managed by ObjectPool
└── GPUParticles2D               ← one_shot=true, emitting=false at start
```

### Build the scene

1. **Create a new scene.** **Scene → New Scene** →
 `Node2D` root, rename to `HitEffect`. Save as
 `res://scenes/vfx/HitEffect.tscn` (create the `vfx`
 folder if needed).
2. **Add GPUParticles2D.** Select HitEffect, Ctrl+A,
 add `GPUParticles2D`. In the Inspector:

   - **Amount:** `12`
   - **Lifetime:** `0.4`
   - **One Shot:** **On**
   - **Explosiveness:** `1.0` (all particles fire at once)
   - **Emitting:** **Off** — the script calls
    `restart()` to trigger it

3. **Create a ParticleProcessMaterial.** Under
 **Process Material** in the Inspector, click
 **New ParticleProcessMaterial**. Configure:

   - **Direction:** (0, −1) with **Spread: 180°**
    — emits in a full circle
   - **Initial Velocity Min/Max:** 60 / 140
   - **Scale Min/Max:** 2 / 4
   - **Color:** bright yellow or orange for an energy-feel burst

4. **Attach HitEffect.gd.** Attach a new script at
 `res://scenes/vfx/HitEffect.gd`. Paste the script below.
5. **Register with ObjectPool.** Open
 `res://autoloads/ObjectPool.gd`. In `_ready()` add:

   ```gdscript
   register("HitEffect", preload("res://scenes/vfx/HitEffect.tscn"), 20)
   ```

6. **Assign in Main.tscn.** Open Main.tscn, select the Main root.
 Drag `HitEffect.tscn` into the **Hit Effect Scene**
 Inspector slot (the export you left empty in Ch 71F).

```gdscript
## res://scenes/vfx/HitEffect.gd
extends Node2D

@onready var particles: GPUParticles2D = $GPUParticles2D

func play() -> void:
    ## restart() resets the one-shot burst and begins emitting.
    particles.restart()
    ## Return to pool after the lifetime expires (+ small buffer).
    await get_tree().create_timer(particles.lifetime + 0.1).timeout
    ObjectPool.release("HitEffect", self)
```

Add `_spawn_death_effect()` to EnemyBase.gd:

```gdscript
## In EnemyBase._die() — add before queue_free():
func _die() -> void:
    died.emit(self)
    GameManager.on_enemy_killed()
    _drop_xp_gem()
    _spawn_death_effect()   ## NEW
    queue_free()

func _spawn_death_effect() -> void:
    var fx: Node2D = ObjectPool.acquire("HitEffect")
    if fx == null: return
    get_parent().add_child(fx)
    fx.global_position = global_position
    fx.play()
```

## 3. Screen Shake on Player Damage

Tween the Camera2D's `offset` through a series of random displacements.
 A small dedicated method on the Camera2D keeps the logic encapsulated.

### Add shake to Camera2D

1. **Open Player.tscn.** Double-click
 `res://scenes/player/Player.tscn`.
2. **Select the Camera2D child node.** In the Scene dock, click
 `Camera2D` inside Player.
3. **Attach CameraShake.gd.** Click the scroll icon in the Inspector
 (Attach Script). Name it `CameraShake.gd`, path
 `res://scenes/player/CameraShake.gd`. The script
 *replaces* the Camera2D node type — use `extends Camera2D`.
 Paste the script below and save.
4. **Save Player.tscn.** Press Ctrl+S.

```gdscript
## res://scenes/player/CameraShake.gd
extends Camera2D

var _shake_tween: Tween

func shake(intensity: float = 6.0, duration: float = 0.25) -> void:
    if _shake_tween:
        _shake_tween.kill()
    ## Run N random-offset kicks, then ease back to zero.
    _shake_tween = create_tween().set_loops(int(duration / 0.05))
    _shake_tween.tween_callback(_apply_random_offset.bind(intensity))
    _shake_tween.tween_interval(0.05)
    _shake_tween.chain().tween_property(self, "offset", Vector2.ZERO, 0.08)

func _apply_random_offset(intensity: float) -> void:
    offset = Vector2(randf_range(-intensity, intensity),
                     randf_range(-intensity, intensity))
```

Call it in Player.gd inside `take_damage()`:

```gdscript
func take_damage(amount: float) -> void:
    var eff := maxf(0.0, amount - stats.armor)
    stats.current_hp = maxf(0.0, stats.current_hp - eff)
    hp_changed.emit(stats.current_hp, stats.max_hp)
    $Camera2D.shake(6.0, 0.25)   ## NEW
    _flash_hurt()
    if stats.current_hp <= 0.0:
        _die()
```

## 4. Level-Up Full-Screen Flash

A brief white flash before the upgrade screen appears communicates level-up even
 before the cards are visible.

### Add FlashRect to HUD.tscn

1. **Open HUD.tscn.** Double-click
 `res://scenes/ui/HUD.tscn`.
2. **Add a ColorRect** as a direct child of the `HUD`
 CanvasLayer root (not inside MarginContainer). Rename it `FlashRect`.
 Set its **Anchors Preset** to **Full Rect**.
 Set **Color** to pure white. Set **Modulate → A**
 to `0` so it's invisible by default. This rect will tween
 alpha up then back to zero.
3. **Save HUD.tscn.** Press Ctrl+S.

Add the method to HUD.gd:

```gdscript
@onready var flash_rect: ColorRect = $FlashRect

func play_level_up_flash() -> void:
    var tween := create_tween()
    tween.tween_property(flash_rect, "modulate:a", 0.6, 0.05)
    tween.tween_property(flash_rect, "modulate:a", 0.0, 0.3)
```

Update `Main._on_game_state_changed()` to fire the flash before pausing:

```gdscript
GameManager.State.LEVEL_UP:
    hud.play_level_up_flash()
    await get_tree().create_timer(0.05).timeout  ## let flash begin
    get_tree().paused = true
    upgrade_screen.show_cards()
```

## 5. Sound Effects

Each major event gets a short audio cue. Use
 `AudioStreamPlayer2D` for world-positioned sounds (enemy death,
 gem pickup) and `AudioStreamPlayer` (non-spatial) for UI and
 player events.

| Event | Node type | Parent scene |
| --- | --- | --- |
| Enemy death | AudioStreamPlayer2D | EnemyBase.tscn |
| Player hit | AudioStreamPlayer | Player.tscn |
| XP gem pickup | AudioStreamPlayer2D | XpGem.tscn |
| Level-up chime | AudioStreamPlayer | Player.tscn or HUD |
| Weapon fire (wand) | AudioStreamPlayer2D | MagicWand.tscn |
| Garlic pulse | AudioStreamPlayer2D | Garlic.tscn |

### Add death sound to EnemyBase.tscn

1. **Open EnemyBase.tscn.** Select the `Enemy` root,
 Ctrl+A, add `AudioStreamPlayer2D`. Rename it
 `DeathSFX`.
2. **Assign a stream.** In the Inspector, drag a short death sound
 (OGG or WAV) into the **Stream** slot.
 Set **Autoplay: Off**.
3. **Save EnemyBase.tscn.** Press Ctrl+S.

```gdscript
## In EnemyBase.gd — update _die():
@onready var death_sfx: AudioStreamPlayer2D = $DeathSFX

func _die() -> void:
    ## Reparent the SFX player BEFORE queue_free so it finishes playing.
    ## If it stays a child of Enemy it gets freed with it — sound cuts off.
    death_sfx.reparent(get_parent())
    death_sfx.play()
    death_sfx.finished.connect(death_sfx.queue_free)

    died.emit(self)
    GameManager.on_enemy_killed()
    _drop_xp_gem()
    _spawn_death_effect()
    queue_free()
```

:::callout-tip[reparent() before queue\_free() — always]
Freeing a node frees all its children simultaneously. Moving the
 AudioStreamPlayer2D to EnemyContainer first lets it outlive the enemy node
 and finish playing. The `finished.connect(queue_free)` line
 cleans it up automatically once it's done.
:::

## 6. Background Music

### Add music to Main.tscn

1. **Open Main.tscn.** Select the `Main` root,
 Ctrl+A, add `AudioStreamPlayer`. Rename it
 `Music`.
2. **Assign the background track.** Drag an OGG music file into
 the **Stream** slot. Set **Autoplay: Off**
 (Main.gd starts it after the run begins).
3. **Set loop points.** Select the OGG file in the FileSystem dock.
 In the Inspector under **Loop: Enabled**, set
 **Loop Offset** to the sample position (in seconds) where
 the loop should begin — usually the start of the first full bar after
 any intro. Godot jumps back to this point seamlessly when the track ends.
4. **Save Main.tscn.** Press Ctrl+S.

Add music start and fade-out to Main.gd:

```gdscript
## In Main._ready(), after GameManager.start_run(player):
$Music.play()

## In Main._on_game_state_changed() — add to GAME_OVER and VICTORY branches:
GameManager.State.GAME_OVER:
    var tween := create_tween()
    tween.tween_property($Music, "volume_db", -40.0, 2.0)
    tween.tween_callback($Music.stop)
    upgrade_screen.hide()
    get_tree().paused = false
    hud.show_game_over()
```

:::callout-key[OGG loop points in Godot 4]
Select the OGG file in the FileSystem → Inspector →
 **Loop: On**, **Loop Offset:** the exact second
 where the musical loop begins. Godot plays to the end of the file and
 jumps back to the offset point seamlessly — no code required.
 Use Audacity to find the exact sample number and convert to seconds.
:::

## 7. XP Gem Sparkle Trail

While a gem flies toward the player, leave a short sparkle trail behind it.
 A `CPUParticles2D` (lighter than GPU for small per-gem effects)
 handles this with two lines of script.

### Add trail to XpGem.tscn

1. **Open XpGem.tscn.** Double-click
 `res://scenes/pickups/XpGem.tscn`.
2. **Add CPUParticles2D.** Select `XpGem`,
 Ctrl+A, add `CPUParticles2D`. Rename it
 `Trail`. Configure in the Inspector:

   - **Amount:** 6
   - **Lifetime:** 0.2
   - **One Shot:** Off (trails continuously while emitting)
   - **Direction:** (0, 1) (downward trail behind the gem)
   - **Spread:** 45°
   - **Initial Velocity Min/Max:** 20 / 40
   - **Scale Min/Max:** 1 / 2
   - **Emitting:** Off (started in code)

3. **Save XpGem.tscn.** Press Ctrl+S.

Update XpGem.gd to toggle the trail:

```gdscript
@onready var trail: CPUParticles2D = $Trail

func start_attract(player: Player) -> void:
    if _attracting: return
    _attracting    = true
    _player        = player
    trail.emitting = true    ## start trail when gem starts moving
    add_to_group("xp_gems")

func _reset() -> void:
    _attracting    = false
    _player        = null
    trail.emitting = false   ## stop trail when gem returns to pool
    remove_from_group("xp_gems")
```

## 8. Verification Checklist

1. **Enemy sprite flashes white on hit.** If not: the `sprite`
 @onready ref in EnemyBase is null (node name mismatch) or `_flash_white()`
 isn't called in `take_damage()`.
2. **Particle burst appears at enemy death position.** If not:
 HitEffect isn't registered in ObjectPool, or `hit_effect_scene`
 export on Main isn't assigned.
3. **Camera shakes when player takes damage.** If not: CameraShake.gd
 isn't attached to the Camera2D, or `$Camera2D.shake()` isn't
 called in Player.take\_damage().
4. **White flash fires on level-up.** If not:
 `hud.play_level_up_flash()` isn't called from Main, or
 FlashRect isn't a child of HUD with Modulate A = 0 by default.
5. **Music plays during a run and fades on game over.**
 If no music: `$Music.play()` isn't in Main.\_ready().
 If it doesn't loop: Loop isn't enabled on the OGG import settings.
6. **Gems leave a sparkle trail while moving.** If not:
 Trail CPUParticles2D emitting isn't set to true in start\_attract().

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
Why must the death SFX be reparented before `queue_free()`?

::::solution[Solution]
Freeing a node frees all its children on the same frame. If the
 AudioStreamPlayer2D is still a child of the enemy when queue\_free fires,
 it gets freed too — the sound cuts off immediately. Calling
 `reparent(get_parent())` first moves it to EnemyContainer, which
 outlives the enemy. `finished.connect(queue_free)` then cleans it
 up automatically once the sound ends.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
The screen shake uses `set_loops(int(duration / 0.05))`.
 For `duration = 0.25`, how many loop iterations run?

::::solution[Solution]
`int(0.25 / 0.05) = int(5.0) = 5` loops. Each loop consists of
 a callback (instant) followed by a 0.05-second interval = 0.05 s per loop.
 5 × 0.05 = 0.25 s of random offsets, then a final 0.08-second ease-back
 to zero. Total duration ≈ 0.33 s.
::::
:::

:::problem[Problem 3 challenge]{difficulty="challenge"}
Implement a *combo multiplier*: a floating label that pops near each
 kill showing "x2", "x3" etc. if enemies die within 1 second of each other,
 resetting when the chain breaks.

::::solution[Solution]
```gdscript
## ComboTracker.gd — attach to a Node in Main.tscn
extends Node

var combo: int = 0
var _reset_timer: float = 0.0
const WINDOW: float = 1.0
@export var label_scene: PackedScene

func _ready() -> void:
    GameManager.kills_updated.connect(_on_kill)

func _process(delta: float) -> void:
    if combo > 0:
        _reset_timer -= delta
        if _reset_timer <= 0.0:
            combo = 0

func _on_kill(_total: int) -> void:
    combo       += 1
    _reset_timer = WINDOW
    if combo >= 2:
        _show_label("x%d" % combo)

func _show_label(text: String) -> void:
    var lbl: Label = label_scene.instantiate()
    get_tree().current_scene.add_child(lbl)
    lbl.global_position = GameManager.player.global_position + Vector2(30, -40)
    lbl.text = text
    var tween := lbl.create_tween()
    tween.tween_property(lbl, "position:y", lbl.position.y - 40, 0.6)
    tween.parallel().tween_property(lbl, "modulate:a", 0.0, 0.6)
    tween.tween_callback(lbl.queue_free)
```
::::
:::

## Summary

:::summary
## Chapter 71G — Key Points

| Effect | How | Why this approach |
| --- | --- | --- |
| Hit flash | Tween modulate to WHITE then back; kill old tween first | No extra nodes; Tween is cheaper than AnimationPlayer for one-property animations |
| Death burst | Pooled HitEffect GPUParticles2D; play() then auto-release after lifetime | Pool avoids per-death instantiation cost at 200+ enemies/minute |
| Screen shake | Camera2D offset tweened through random offsets × N loops | Encapsulated in Camera2D script; Player calls one method |
| Level-up flash | Full-screen ColorRect alpha tween in HUD; fire before pausing | Communicates event before upgrade UI appears |
| Death SFX | reparent() to container then play(); auto-free on finished | Prevents sound cutoff when enemy is queue\_freed |
| Music | AudioStreamPlayer in Main; OGG loop points; volume\_db tween on end | OGG loops natively — zero code for seamless looping |
| Gem trail | CPUParticles2D; emitting toggled in start\_attract()/reset() | CPU particles lighter than GPU for many small per-gem effects |
:::

Final chapter: **Ch 71H** — performance profiling, ObjectPool size
 tuning, and exporting the finished game to Windows and Web.
