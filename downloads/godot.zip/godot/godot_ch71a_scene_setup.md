---
title: "VS Clone — Scene Setup, World & Camera"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71A"
meta:
  - "Est. study time: ~45 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated May 2026"
source: "godot_ch71a_scene_setup.html"
---

## Overview

This chapter builds the stage that every other system will run on: a large tiled
 world, a navigation mesh enemies can path through, a camera that tracks the player
 inside world bounds, and the container nodes that keep the scene tree organised.
 No gameplay exists yet — but by the end you will be able to spawn a placeholder
 ball, drive it with WASD, and watch the camera follow it across an infinite-feeling
 arena.

:::callout-key[What you'll build in this chapter]
Main scene, TileMapLayer world, NavigationRegion2D, Camera2D with limits,
 EnemyContainer, HUD CanvasLayer skeleton, and Main.gd with ObjectPool
 registration. The project is verified by running an empty scene and confirming
 camera limits and navigation bake.
:::

### Prerequisites

- Ch 71 Design Sheet read — understand the scene hierarchy before building it
- Familiarity with TileMapLayer (Ch 9) and Camera2D (Ch 17)
- NavigationRegion2D basics (Ch 57)

## 1. Project Setup

1. **New Project** — Godot 4.6 → New Project → name it *RelicHorde*, choose a folder, renderer **Forward+** (or Compatibility for Web export).
2. **Viewport size** — Project Settings → Display → Window → Size: `1920 × 1080`. Stretch Mode: `canvas_items`, Aspect: `expand`.
3. **Disable gravity** — Project Settings → Physics → 2D → Default Gravity: `0`.
4. **Physics ticks** — Project Settings → Physics → Common → Physics Ticks Per Second: `60`. (Survivors doesn't need 120Hz physics.)
5. **Layer names** — Project Settings → Layer Names → 2D Physics:

 Layer 1 = `World` · Layer 2 = `Player` · Layer 3 = `XpGems` · Layer 4 = `Enemies` · Layer 5 = `Projectiles`
6. **Input map** — Project Settings → Input Map → add four actions:

 `move_left` (A / ←), `move_right` (D / →), `move_up` (W / ↑), `move_down` (S / ↓)
7. **Autoloads** — Project Settings → Autoloads → add two (create the GD files first, even if empty):

 `res://autoloads/GameManager.gd` as **GameManager**

 `res://autoloads/ObjectPool.gd` as **ObjectPool**

:::callout-tip[Folder layout]
Create these folders now to keep assets organised:

```
res://
├── autoloads/          GameManager.gd, ObjectPool.gd
├── scenes/
│   ├── main/           Main.tscn, Main.gd
│   ├── player/         Player.tscn, Player.gd, PlayerStats.gd
│   ├── enemies/        EnemyBase.gd, Bat.tscn, Skeleton.tscn, Golem.tscn
│   ├── weapons/        WeaponBase.gd, Garlic.tscn, MagicWand.tscn, Axe.tscn
│   ├── pickups/        XpGem.tscn, XpGem.gd
│   ├── projectiles/    Projectile.tscn, Projectile.gd
│   └── ui/             HUD.tscn, UpgradeScreen.tscn
├── assets/
│   ├── tiles/          tile sprites
│   └── sprites/        character/enemy sprites
└── resources/          PlayerStats resource, UpgradeResource scripts
```
:::

## 2. World Scene Structure

The root scene is **Main.tscn**. It owns everything: the world geometry,
 the player, all enemies, and the UI layers. Create it now:

1. Scene → New Scene → root: **Node2D**, rename to **Main**.
2. Save as `res://scenes/main/Main.tscn`.
3. Attach script: `res://scenes/main/Main.gd`.
4. Set as the main scene: Project → Project Settings → Application → Run → Main Scene.

Add the following child nodes to Main in order (we'll configure each below):

```
Main (Node2D)                    ← Main.gd
├── World (Node2D)
│   ├── NavigationRegion2D       ← navmesh for enemy pathfinding
│   │   └── TileMapLayer         ← visual world + collision
│   └── EnemyContainer (Node2D) ← all enemy instances live here
├── Player                       ← placeholder for now; add scene in Ch 71B
├── HUD (CanvasLayer)            ← layer = 1
└── UpgradeScreen (CanvasLayer)  ← layer = 2; hidden by default
```

:::callout-warning[TileMapLayer inside NavigationRegion2D]
Godot 4's TileMapLayer can bake navigation geometry directly into a parent
 NavigationRegion2D when you set the tile's navigation layer in the TileSet. Nesting
 TileMapLayer inside NavigationRegion2D makes this automatic. If you place them as
 siblings, you must manually configure the navmesh polygon instead.
:::

## 3. TileMapLayer — Infinite-Feel World

Vampire Survivors uses a small repeating tile that scrolls endlessly. We fake this
 with a large enough tile grid (4096×4096 px) that players rarely reach the edge,
 and the camera limits prevent them from seeing it.

### Creating the TileSet

1. Select TileMapLayer in the scene tree. Inspector → TileSet → New TileSet.
2. In the TileSet editor at the bottom, click **+** → Atlas. Assign a
 `64×64` grass/floor sprite sheet (or use a solid green ColorRect as a
 placeholder sprite exported to PNG).
3. In the TileSet editor, select your tile → Physics → Paint physics layer 0 with a
 full-tile collision shape. This makes walls block movement.
4. In the TileSet editor, select your tile → Navigation → Paint navigation region
 on the tile. This tells Godot the tile is walkable for NavigationAgent2D.

### TileMapLayer inspector settings

collision\_layer — Layer 1 (World) — collision\_mask — Layer 2 (Player), Layer 4 (Enemies) — tile\_set — your new TileSet resource

### Painting the world

1. Select TileMapLayer and open the TileMap editor at the bottom panel.
2. Select your grass tile and paint a filled rectangle covering roughly
 `−32` to `+32` tiles in both X and Y
 (64 tiles × 64 px = 4096 px total). Use **Rect** fill tool.
3. Add a border row of a solid-collision "wall" tile (or a different coloured tile
 that marks the arena edge) at row ±32. This gives enemies a visual boundary.

:::callout-tip[Placeholder tiles]
You don't need art yet. Create a 64×64 PNG in any image editor: fill it green
 for floor, brown for wall. Import it into Godot and use it as a single-tile atlas.
 Replace with proper art later without touching any scene or code.
:::

## 4. NavigationRegion2D — Baking the Navmesh

Enemies use `NavigationAgent2D` to path around obstacles. The
 NavigationRegion2D defines which areas of the world are walkable.

### Setup steps

1. Select the **NavigationRegion2D** node. Inspector → NavigationPolygon → New NavigationPolygon.
2. In the NavigationPolygon inspector, click **Bake NavigationPolygon**.
 Godot will read the TileMapLayer's navigation tile data and generate the walkable region automatically.
3. Confirm in the viewport that the blue walkable area covers the floor tiles and the wall tiles are excluded.

:::callout-pitfall[Navmesh not updating after tile changes]
The navmesh is baked at editor time — it does NOT update automatically when you
 paint more tiles. Every time you add or remove tiles, re-click
 **Bake NavigationPolygon**. For a static arena this is fine; for a
 procedurally-generated world you would rebake at runtime with
 `NavigationServer2D.bake_from_source_geometry_data()`.
:::

### NavigationAgent2D settings (set on enemies in Ch 71C)

path\_desired\_distance — 16.0 — target\_desired\_distance — 16.0 — avoidance\_enabled — false (for performance at 200 enemies)

:::callout-key[Avoidance off for performance]
RVO avoidance is off unless you turn it on — `avoidance_enabled` is
 `false` by default on NavigationAgent2D and 3D alike — and this game leaves
 it off. Each agent has to consider every other one, so the crowd costs O(n²): at 200
 enemies that is 200 × 200 = ~40,000 checks per frame. Leaving it off means enemies
 overlap each other, which actually looks correct for a swarm game. Ch 71H covers the
 spatial hash approach if you want light separation without full RVO.
:::

## 5. Camera2D — Follow Player with World Limits

The Camera2D lives on the **Player** node (added in Ch 71B), not on
 Main. We configure the limits here so you know what values to enter when the
 player scene is built.

### Camera2D inspector values

enabled — true — zoom — Vector2(1.5, 1.5) — closer view shows more enemies — limit\_left — −2048 (half of 4096) — limit\_right — 2048 — limit\_top — −2048 — limit\_bottom — 2048 — position\_smoothing\_enabled — true — position\_smoothing\_speed — 5.0

:::callout-tip[Camera on the Player, not Main]
Attaching the camera to the Player node means it follows automatically — no
 `camera.global_position = player.global_position` code needed.
 The limits stop the view from showing the grey void beyond the world edge.
:::

:::example[Worked example — setting limits via code at runtime]
You want the camera limits to match the TileMapLayer's used rect at runtime instead of hard-coded values.

::::answer[Answer]
Query the TileMapLayer's used rect and convert to pixels:
::::

```gdscript
## In Main.gd _ready(), after world is built:
@onready var tilemap: TileMapLayer = $World/NavigationRegion2D/TileMapLayer
@onready var camera: Camera2D      = $Player/Camera2D

func _ready() -> void:
    var rect: Rect2i = tilemap.get_used_rect()
    var ts: int      = tilemap.tile_set.tile_size.x   ## 64
    camera.limit_left   = rect.position.x * ts
    camera.limit_top    = rect.position.y * ts
    camera.limit_right  = rect.end.x * ts
    camera.limit_bottom = rect.end.y * ts
```

This adapts automatically if you resize the tile grid later.
:::

## 6. Node Containers & Groups

Organising enemies and effects into named containers keeps the scene tree readable
 and gives code a fast way to find all instances of a type.

### EnemyContainer

1. Add a **Node2D** child to World, rename to **EnemyContainer**.
2. With EnemyContainer selected: Node → Groups → add group `enemy_container`.

All enemy instances will be parented to EnemyContainer at runtime. Weapons iterate
 `get_tree().get_first_node_in_group("enemy_container").get_children()`
 to find enemies, which is much faster than a full scene-tree search.

### Groups used throughout the series

| Group name | Who joins | Who searches |
| --- | --- | --- |
| `player` | Player node in \_ready() | EnemyBase, EnemySpawner |
| `enemy_container` | EnemyContainer Node2D | WeaponBase, EnemySpawner |
| `enemies` | Every EnemyBase in \_ready() | Garlic AOE area\_overlaps check |
| `weapons` | Every WeaponBase in \_ready() | UpgradeScreen (to find upgradable weapons) |

## 7. HUD & UpgradeScreen CanvasLayers

Create skeleton scenes now — empty placeholders that Ch 71E and 71F will fill in.
 Getting the CanvasLayer structure right early prevents hard-to-debug Z-order issues.

### HUD.tscn skeleton

```
HUD (CanvasLayer)                ← layer = 1; HUD.gd
└── MarginContainer
    └── VBoxContainer
        ├── HpBar (ProgressBar)  ← show_percentage = false; max = 100
        ├── XpBar (ProgressBar)  ← show_percentage = false; max = 50
        ├── TimerLabel (Label)   ← text = "00:00"
        └── KillLabel (Label)    ← text = "Kills: 0"
```

### UpgradeScreen.tscn skeleton

```
UpgradeScreen (CanvasLayer)      ← layer = 2; process_mode = ALWAYS; visible = false
└── PanelContainer               ← semi-transparent dark panel
    └── VBoxContainer
        ├── TitleLabel           ← text = "Choose an Upgrade"
        └── CardsContainer (HBoxContainer)
            ├── Card0 (Button)   ← will be populated by UpgradeScreen.gd
            ├── Card1 (Button)
            └── Card2 (Button)
```

:::callout-key[process\_mode = ALWAYS on UpgradeScreen]
When `get_tree().paused = true`, all nodes with
 `process_mode = PAUSABLE` (the default) stop receiving input.
 The UpgradeScreen must have `process_mode = PROCESS_MODE_ALWAYS`
 so the player can click an upgrade card while the game is paused.
:::

## 8. Main.gd

Main.gd's only job right now is to register ObjectPool entries and wire up the
 GameManager. All spawning logic lives in EnemySpawner (Ch 71C) and all game-state
 transitions live in GameManager (Ch 71F).

```gdscript
extends Node2D

## Pool scenes — set these in the Inspector or preload here.
@export var xp_gem_scene:    PackedScene
@export var projectile_scene: PackedScene
@export var hit_effect_scene: PackedScene

@onready var tilemap: TileMapLayer = $World/NavigationRegion2D/TileMapLayer

func _ready() -> void:
    ## Register object pools before anything spawns.
    if xp_gem_scene:
        ObjectPool.register("XpGem",      xp_gem_scene,     40)
    if projectile_scene:
        ObjectPool.register("Projectile", projectile_scene, 30)
    if hit_effect_scene:
        ObjectPool.register("HitEffect",  hit_effect_scene, 20)

    ## Tell GameManager where the player is once the Player scene exists.
    ## (Uncomment after Ch 71B.)
    # var player := $Player as Player
    # GameManager.start_run(player)

    ## Dynamic camera limits from tilemap.
    _apply_camera_limits()

func _apply_camera_limits() -> void:
    ## Find camera on player — safe even if player isn't added yet.
    var player := get_node_or_null("Player")
    if player == null:
        return
    var cam := player.get_node_or_null("Camera2D") as Camera2D
    if cam == null:
        return
    var rect := tilemap.get_used_rect()
    var ts   := tilemap.tile_set.tile_size.x
    cam.limit_left   = rect.position.x * ts
    cam.limit_top    = rect.position.y * ts
    cam.limit_right  = rect.end.x * ts
    cam.limit_bottom = rect.end.y * ts
```

### ObjectPool.gd skeleton (autoload)

Create this now so the autoload doesn't error on startup. The full implementation
 is in the design sheet; paste it in:

```gdscript
## res://autoloads/ObjectPool.gd
extends Node

var _pools:  Dictionary = {}
var _scenes: Dictionary = {}

func register(key: String, scene: PackedScene, prealloc: int = 20) -> void:
    _scenes[key] = scene
    _pools[key]  = []
    for i in prealloc:
        var obj := scene.instantiate()
        obj.set_process(false)
        obj.set_physics_process(false)
        _pools[key].append(obj)

func acquire(key: String) -> Node:
    if not _pools.has(key) or _pools[key].is_empty():
        return _scenes[key].instantiate() if _scenes.has(key) else null
    var obj: Node = _pools[key].pop_back()
    obj.set_process(true)
    obj.set_physics_process(true)
    return obj

func release(key: String, obj: Node) -> void:
    if obj.get_parent():
        obj.get_parent().remove_child(obj)
    obj.set_process(false)
    obj.set_physics_process(false)
    if _pools.has(key):
        _pools[key].append(obj)
```

### GameManager.gd skeleton (autoload)

```gdscript
## res://autoloads/GameManager.gd
extends Node

enum State { WAITING, PLAYING, LEVEL_UP, GAME_OVER, VICTORY }
var state: State = State.WAITING
var run_timer: float = 0.0
const RUN_DURATION: float = 1800.0
var kill_count: int = 0
var player: Node = null   ## typed as Player after Ch 71B

signal state_changed(new_state: State)

func start_run(p: Node) -> void:
    player = p
    run_timer = 0.0
    kill_count = 0
    _set_state(State.PLAYING)

func _process(delta: float) -> void:
    if state != State.PLAYING:
        return
    run_timer += delta
    if run_timer >= RUN_DURATION:
        _set_state(State.VICTORY)

func on_enemy_killed() -> void:
    kill_count += 1

func trigger_level_up() -> void:
    _set_state(State.LEVEL_UP)

func game_over() -> void:
    _set_state(State.GAME_OVER)

func _set_state(s: State) -> void:
    state = s
    state_changed.emit(s)
```

## 9. Verification

Run the scene now (F5) and confirm all of the following before moving on:

- The scene runs without errors in the Output panel.
- The tiled world is visible — green floor, border wall row.
- The NavigationRegion2D shows a blue walkable region covering the floor (visible in editor with Debug → Visible Navigation on).
- ObjectPool and GameManager autoloads appear in the Remote debugger's scene tree under **/root**.
- Project Settings confirms gravity = 0, input actions exist for all four move directions.

:::callout-pitfall[Common issue — autoload errors on startup]
If Godot reports *"Identifier 'ObjectPool' is not declared"* or similar,
 the autoload path in Project Settings is wrong. Open Project Settings → Autoloads
 and verify both paths resolve (the file icon should be green, not red).
:::

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
Why is TileMapLayer nested inside NavigationRegion2D rather than being a sibling?

::::solution[Solution]
When TileMapLayer is a child of NavigationRegion2D, Godot can read the tile navigation
 layer data directly during bake. As a sibling, the auto-detection doesn't occur and you
 must manually assign the source geometry to the NavigationRegion2D.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
What process\_mode must UpgradeScreen have, and why?

::::solution[Solution]
`PROCESS_MODE_ALWAYS`. When the game tree is paused via
 `get_tree().paused = true`, all nodes with the default
 `PROCESS_MODE_PAUSABLE` stop receiving `_input` and
 `_process` calls. The upgrade cards need to receive mouse clicks
 while the game is paused, so their root CanvasLayer must be ALWAYS.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
The world is 4096×4096 pixels. The Camera2D zoom is `(1.5, 1.5)` and
 the viewport is 1920×1080. What is the maximum visible area in world pixels at this
 zoom level, and does it fit within the world bounds?

::::solution[Solution]
Visible width = 1920 / 1.5 = **1280 px**.
 Visible height = 1080 / 1.5 = **720 px**.
 The world is 4096 px wide — the camera can only show 1280 px at a time, so
 the player can move ~1408 px in each direction before hitting the limit.
 The world is comfortably larger than the viewport at this zoom. ✓
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Why is avoidance disabled on NavigationAgent2D for this game, and what is the
 performance consequence of enabling it at 200 enemies?

::::solution[Solution]
RVO (Reciprocal Velocity Obstacle) avoidance has every agent consider every
 other one, so it is O(n) per agent and O(n²) across the crowd. At 200 enemies:
 200 × 200 = 40,000 pairwise checks/frame, on top of
 the regular navigation path updates. In a swarm game the visual effect of
 overlapping enemies is intentional (creates the crushing horde feel), so the
 cost is pure waste. Avoidance is kept off; Ch 71H adds a lightweight spatial
 hash for minimal separation if desired.
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Write a version of `_apply_camera_limits()` that also adds a
 `margin` parameter (in tiles) so the camera never shows the outermost
 N rows of tiles.

::::solution[Solution]
```gdscript
func _apply_camera_limits(margin: int = 1) -> void:
    var player := get_node_or_null("Player")
    if player == null: return
    var cam := player.get_node_or_null("Camera2D") as Camera2D
    if cam == null: return
    var rect := tilemap.get_used_rect()
    var ts   := tilemap.tile_set.tile_size.x
    cam.limit_left   = (rect.position.x + margin) * ts
    cam.limit_top    = (rect.position.y + margin) * ts
    cam.limit_right  = (rect.end.x - margin) * ts
    cam.limit_bottom = (rect.end.y - margin) * ts
```

Adding `margin` tiles to the start and subtracting from the end
 ensures the camera stops before the edge row is visible, hiding the abrupt
 world boundary.
::::
:::

## Summary

:::summary
## Chapter 71A — Key Points

| What | How |
| --- | --- |
| Viewport | 1920×1080, canvas\_items stretch, expand aspect |
| Gravity | Project Settings → Physics 2D → Default Gravity = 0 |
| World size | TileMapLayer, 64-tile radius, 64 px tiles → 4096×4096 |
| Navmesh | TileMapLayer child of NavigationRegion2D; Bake button |
| Camera | On Player node; limits = world rect × tile\_size |
| EnemyContainer | Node2D in group "enemy\_container"; all enemies parented here |
| UpgradeScreen | CanvasLayer layer=2, process\_mode=ALWAYS, hidden by default |
| ObjectPool | Autoload; register() in Main.\_ready() before spawning |
| Input actions | move\_left/right/up/down mapped to WASD + arrow keys |
:::

Next up: **Ch 71B** builds the Player scene — CharacterBody2D with
 WASD movement, the PlayerStats resource, HurtBox, MagnetArea, and Camera2D attached.
