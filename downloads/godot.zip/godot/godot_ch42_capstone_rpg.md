---
title: "Capstone — Top-Down RPG"
source: "markdown"
---

Part IV · Chapter 42

★ CAPSTONE PROJECT

# Capstone — Top-Down RPG

Integrates: Ch 7 (CharacterBody2D), Ch 11 (AnimationPlayer), Ch 27 (State Machines), Ch 24 (Saving), Ch 30 (Inventory) · est. 3–4 hours

## Overview

A capstone brings together everything you have learned in a single
 coherent project. This chapter builds a playable top-down RPG
 prototype — a small dungeon the player can explore, fight enemies,
 collect items, and save their progress. It is intentionally
 achievable in an afternoon while covering the core integration
 challenges: coordinating multiple systems, keeping scenes decoupled,
 and shipping something that actually runs.

By the end you will have:

- An eight-direction animated player with a melee attack hitbox
- Two enemy types with a simple state-machine AI (Idle → Chase →
 Attack → Dead)
- An inventory system with a quick-slot HUD bar
- A two-room dungeon with a room-transition door
- Save/load through a `SaveData` Resource
- Screen-shake on hit and a dissolve hit-flash shader

:::callout-tip[Tip]
Work through each section in order and test after each one before
 moving on. The most common capstone problem is wiring five systems
 at once and being unable to identify which one is broken.
 One section at a time, one test at a time.
:::

## 1 · Project Plan

### Scene tree layout

The project is structured with one scene per major concept.
 The main game scene composes them together:

```text
res://
  scenes/
    player/
      player.tscn          ← CharacterBody2D + AnimationPlayer + HitBox
      player.gd
    enemies/
      slime.tscn            ← CharacterBody2D + AnimationPlayer + HurtBox
      skeleton.tscn
      enemy_base.gd         ← shared state-machine logic
    world/
      room_a.tscn           ← TileMap + doors + enemy spawn markers
      room_b.tscn
    ui/
      hud.tscn              ← quick-slot bar + health bar + minimap stub
      hud.gd
    game.tscn               ← root: World + HUD + GameCamera
  resources/
    items/
      health_potion.tres
      sword.tres
    save_data.gd            ← SaveData resource class
  autoloads/
    game_events.gd          ← signal bus
    game_state.gd           ← current room, player ref, save/load
  shaders/
    hit_flash.gdshader
```

### Project settings — autoloads

Register two autoloads in *Project → Project Settings →
 Autoloads*:

- `GameEvents` — a pure signal bus. Every system
 fires signals here; every system connects here. No direct
 references between scenes are needed.
- `GameState` — manages current room, the player's
 global position, and the save/load cycle.

```gdscript
# autoloads/game_events.gd
extends Node

signal player_died
signal enemy_died(enemy: Node)
signal item_picked_up(item_data: ItemData)
signal room_transition_requested(target_room: String, spawn_id: int)
signal damage_dealt(target: Node, amount: int)
```

## 2 · Player Character

### Eight-direction movement

The player uses `CharacterBody2D`. A
 `Sprite2D` with an animated sprite-sheet handles four
 directional animations (walk\_up/down/left/right). Store the last
 non-zero direction to keep the character facing the right way when
 standing still.

```gdscript
# player.gd
class_name Player
extends CharacterBody2D

const SPEED := 120.0

@onready var _anim: AnimationPlayer = $AnimationPlayer
@onready var _hit_box: Area2D       = $HitBox

var _facing := Vector2.DOWN   # last non-zero direction

func _physics_process(delta: float) -> void:
    var dir := Input.get_vector(
        "move_left", "move_right", "move_up", "move_down"
    )
    velocity = dir * SPEED
    move_and_slide()

    if dir != Vector2.ZERO:
        _facing = dir
        _update_walk_anim(dir)
    else:
        _update_idle_anim()

    if Input.is_action_just_pressed("attack"):
        _do_attack()

func _update_walk_anim(dir: Vector2) -> void:
    if   abs(dir.x) > abs(dir.y):
        _anim.play("walk_left" if dir.x < 0 else "walk_right")
    elif dir.y < 0:
        _anim.play("walk_up")
    else:
        _anim.play("walk_down")

func _update_idle_anim() -> void:
    if   _facing.y > 0:  _anim.play("idle_down")
    elif _facing.y < 0:  _anim.play("idle_up")
    elif _facing.x < 0:  _anim.play("idle_left")
    else:                 _anim.play("idle_right")
```

### Melee attack

The attack spawns an `Area2D` hitbox in front of the
 player for one frame, checks for overlapping enemy hurtboxes, and
 deals damage. A short cooldown prevents button mashing.

```gdscript
const ATTACK_DAMAGE := 10
const ATTACK_COOLDOWN := 0.4

var _attack_timer: float = 0.0

func _physics_process(delta: float) -> void:
    _attack_timer -= delta
    # ... movement code above ...

func _do_attack() -> void:
    if _attack_timer > 0.0:
        return
    _attack_timer = ATTACK_COOLDOWN

    # Position the hitbox in the facing direction
    _hit_box.position = _facing.normalized() * 24.0
    _hit_box.monitoring = true
    _anim.play("attack_" + _get_dir_suffix())

    await get_tree().create_timer(0.1).timeout
    for body in _hit_box.get_overlapping_bodies():
        if body.has_method("take_damage"):
            body.take_damage(ATTACK_DAMAGE)
            GameEvents.damage_dealt.emit(body, ATTACK_DAMAGE)
    _hit_box.monitoring = false

func _get_dir_suffix() -> String:
    if   _facing.y > 0: return "down"
    elif _facing.y < 0: return "up"
    elif _facing.x < 0: return "left"
    else:               return "right"
```

### Stats resource

```gdscript
# resources/player_stats.gd
class_name PlayerStats
extends Resource

@export var max_health: int = 100
@export var health: int     = 100
@export var attack: int     = 10
@export var speed: float    = 120.0

signal health_changed(new_hp: int)

func take_damage(amount: int) -> void:
    health = max(0, health - amount)
    health_changed.emit(health)
    if health == 0:
        GameEvents.player_died.emit()
```

Attach a `PlayerStats` resource to the player node as an
 `@export` field. This keeps all numeric balancing in
 one `.tres` file that designers can edit without touching
 code.

## 3 · Enemy AI

### State machine

Both enemy types share a `EnemyBase` script that
 implements the four-state machine using a simple enum and a
 `match` statement dispatched in
 `_physics_process`:

```gdscript
# enemy_base.gd
class_name EnemyBase
extends CharacterBody2D

enum State { IDLE, CHASE, ATTACK, DEAD }

@export var stats: EnemyStats
@export var detection_range: float = 120.0
@export var attack_range: float    = 28.0

@onready var _anim: AnimationPlayer = $AnimationPlayer

var _state: State = State.IDLE
var _player: Player = null
var _attack_timer: float = 0.0

func _ready() -> void:
    _player = get_tree().get_first_node_in_group("player")
    GameEvents.player_died.connect(func(): _state = State.IDLE)

func _physics_process(delta: float) -> void:
    _attack_timer -= delta
    match _state:
        State.IDLE:   _tick_idle()
        State.CHASE:  _tick_chase(delta)
        State.ATTACK: _tick_attack()
        State.DEAD:   pass

func _tick_idle() -> void:
    if _player and global_position.distance_to(_player.global_position) \
            <= detection_range:
        _state = State.CHASE
        _anim.play("walk")

func _tick_chase(delta: float) -> void:
    if _player == null:
        _state = State.IDLE
        return
    var dist := global_position.distance_to(_player.global_position)
    if dist > detection_range * 1.2:
        _state = State.IDLE
        _anim.play("idle")
        return
    if dist <= attack_range:
        _state = State.ATTACK
        return
    var dir := (_player.global_position - global_position).normalized()
    velocity = dir * stats.speed
    move_and_slide()

func _tick_attack() -> void:
    if _player == null or \
            global_position.distance_to(_player.global_position) > attack_range:
        _state = State.CHASE
        return
    if _attack_timer <= 0.0:
        _attack_timer = stats.attack_cooldown
        _player.stats.take_damage(stats.attack)
        _anim.play("attack")

func take_damage(amount: int) -> void:
    stats.health -= amount
    if stats.health <= 0:
        _die()

func _die() -> void:
    _state = State.DEAD
    GameEvents.enemy_died.emit(self)
    _anim.play("die")
    await _anim.animation_finished
    queue_free()
```

### Slime vs. Skeleton differences

Override only what differs. The `Slime` script simply
 sets lower stats and plays wobble animations. The
 `Skeleton` script adds a ranged attack state that fires a
 `Projectile` scene when the player is in a wider
 attack band but outside melee range:

```gdscript
# skeleton.gd
class_name Skeleton
extends EnemyBase

const ARROW_SCENE := preload("res://scenes/projectiles/arrow.tscn")
@export var ranged_range: float = 200.0

func _tick_attack() -> void:
    var dist := global_position.distance_to(_player.global_position)
    if dist > ranged_range:
        _state = State.CHASE
        return
    if _attack_timer <= 0.0:
        _attack_timer = stats.attack_cooldown
        var arrow := ARROW_SCENE.instantiate()
        get_parent().add_child(arrow)
        arrow.global_position = global_position
        arrow.direction = (_player.global_position - global_position).normalized()
        _anim.play("shoot")
```

## 4 · Inventory & HUD

### Quick-slot bar

The HUD shows eight quick slots numbered 1–8. Each slot displays
 an icon and stack count. The player presses 1–8
 to use the item in that slot. The HUD listens to the player's
 inventory via the signal bus:

```gdscript
# hud.gd
extends CanvasLayer

@onready var _slots: Array[QuickSlotUI] = [
    $Bar/Slot1, $Bar/Slot2, $Bar/Slot3, $Bar/Slot4,
    $Bar/Slot5, $Bar/Slot6, $Bar/Slot7, $Bar/Slot8
]
@onready var _health_bar: ProgressBar = $HealthBar

var _inventory: Inventory

func init(player: Player) -> void:
    _inventory = player.inventory
    player.stats.health_changed.connect(_on_health_changed)
    _inventory.changed.connect(_refresh_slots)
    _on_health_changed(player.stats.health)
    _refresh_slots()

func _refresh_slots() -> void:
    for i in _slots.size():
        var slot: InventorySlot = _inventory.get_slot(i)
        _slots[i].update(slot)

func _on_health_changed(hp: int) -> void:
    _health_bar.value = hp

func _input(event: InputEvent) -> void:
    for i in 8:
        if event.is_action_pressed("quick_slot_%d" % (i + 1)):
            _use_slot(i)

func _use_slot(index: int) -> void:
    var slot := _inventory.get_slot(index)
    if slot == null or slot.item == null:
        return
    # Call the item's use logic
    slot.item.use(get_tree().get_first_node_in_group("player"))
    _inventory.remove_one(index)
    _refresh_slots()
```

### Health bar with smooth lerp

```gdscript
# quick_slot_ui.gd (individual slot)
extends PanelContainer

@onready var _icon:  TextureRect = $Icon
@onready var _count: Label       = $Count

func update(slot) -> void:   # slot: InventorySlot or null
    if slot == null or slot.item == null:
        _icon.texture  = null
        _count.text    = ""
    else:
        _icon.texture  = slot.item.icon
        _count.text    = "" if slot.quantity <= 1 else str(slot.quantity)
```

## 5 · World & Rooms

### TileMap rooms

Each room is a `TileMap` node with three layers:

- **Layer 0 — Floor**: walkable tiles, no collision
- **Layer 1 — Walls**: solid collision tiles
- **Layer 2 — Details**: decorative overlays, no
 collision

Enemy spawn points are `Marker2D` nodes in a
 `SpawnPoints` group. When the room is loaded,
 `GameState` checks which enemies from the save data are
 still alive and instantiates only those.

### Room transitions

Doors are `Area2D` nodes that emit
 `GameEvents.room_transition_requested` when the player
 enters them. `GameState` listens and performs the
 transition:

```gdscript
# door.gd
extends Area2D

@export var target_room: String = "res://scenes/world/room_b.tscn"
@export var spawn_id: int = 0

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    if body is Player:
        GameEvents.room_transition_requested.emit(target_room, spawn_id)
```

```gdscript
# autoloads/game_state.gd
extends Node

var _current_room_node: Node = null

func _ready() -> void:
    GameEvents.room_transition_requested.connect(_transition_to)

func _transition_to(room_path: String, spawn_id: int) -> void:
    # Fade out
    var tween := create_tween()
    tween.tween_property($FadeRect, "color:a", 1.0, 0.3)
    await tween.finished

    # Swap room
    if _current_room_node:
        _current_room_node.queue_free()
    var packed := load(room_path) as PackedScene
    _current_room_node = packed.instantiate()
    get_tree().current_scene.add_child(_current_room_node)

    # Place player at spawn point
    var spawns := get_tree().get_nodes_in_group("spawn_%d" % spawn_id)
    if spawns.size() > 0:
        var player := get_tree().get_first_node_in_group("player")
        player.global_position = spawns[0].global_position

    # Fade in
    tween = create_tween()
    tween.tween_property($FadeRect, "color:a", 0.0, 0.3)
```

:::callout-connect[Connect]
The `$FadeRect` in `GameState` is a
 full-screen `ColorRect` added to a
 `CanvasLayer` with a high layer index (e.g. 100) so
 it always renders on top. Set its initial colour to
 `Color(0, 0, 0, 0)` (transparent black).
 Tweening its alpha to 1 gives a clean black fade-to-black
 between rooms.
:::

## 6 · Save & Load

### SaveData resource

```gdscript
# resources/save_data.gd
class_name SaveData
extends Resource

@export var current_room: String = "res://scenes/world/room_a.tscn"
@export var spawn_id: int = 0
@export var player_health: int = 100
@export var inventory_slots: Array[Dictionary] = []
@export var defeated_enemies: Array[String] = []  # unique IDs
```

### Persistence autoload

```gdscript
# autoloads/game_state.gd  (additions)
const SAVE_PATH := "user://save.tres"

func save_game() -> void:
    var player: Player = get_tree().get_first_node_in_group("player")
    var data := SaveData.new()
    data.current_room  = _current_room_path
    data.player_health = player.stats.health
    data.inventory_slots = player.inventory.serialise()
    data.defeated_enemies = _defeated_enemy_ids.duplicate()
    ResourceSaver.save(data, SAVE_PATH)
    print("Game saved.")

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var data := ResourceLoader.load(SAVE_PATH) as SaveData
    if data == null:
        return
    _defeated_enemy_ids = data.defeated_enemies.duplicate()
    _transition_to(data.current_room, data.spawn_id)
    await get_tree().process_frame   # wait for room to load
    var player: Player = get_tree().get_first_node_in_group("player")
    player.stats.health = data.player_health
    player.inventory.deserialise(data.inventory_slots)
```

:::callout-tip[Tip]
Save on room transition and on a dedicated *Save*
 key (e.g. F5), not every frame.
 `ResourceSaver.save()` writes to disk synchronously;
 calling it every frame would cause noticeable micro-stutters.
:::

## 7 · Polish Pass

### Screen shake

Add a `shake()` method to the
 `GameCamera` node. Connect it to
 `GameEvents.damage_dealt` so every hit shakes the
 camera slightly:

```gdscript
# game_camera.gd
extends Camera2D

const SHAKE_DECAY := 5.0

var _trauma: float = 0.0   # 0 = no shake, 1 = max shake
var _rng := RandomNumberGenerator.new()

func shake(amount: float = 0.3) -> void:
    _trauma = minf(_trauma + amount, 1.0)

func _process(delta: float) -> void:
    _trauma = maxf(0.0, _trauma - SHAKE_DECAY * delta)
    var shake_amt := _trauma * _trauma   # squared for more punch
    offset = Vector2(
        _rng.randf_range(-1.0, 1.0) * 8.0 * shake_amt,
        _rng.randf_range(-1.0, 1.0) * 8.0 * shake_amt
    )
```

```gdscript
# In game.gd (root scene) _ready():
GameEvents.damage_dealt.connect(func(_target, _amt):
    $GameCamera.shake(0.25)
)
```

### Hit-flash shader

A simple canvas-item shader replaces all non-transparent pixels
 with white for one frame to give a hit-flash effect:

```glsl
// shaders/hit_flash.gdshader
shader_type canvas_item;
uniform float flash_amount : hint_range(0.0, 1.0) = 0.0;

void fragment() {
    vec4 base = texture(TEXTURE, UV);
    COLOR = mix(base, vec4(1.0, 1.0, 1.0, base.a), flash_amount);
}
```

```gdscript
# In enemy_base.gd — play the flash on take_damage:
@onready var _sprite: Sprite2D = $Sprite2D
var _flash_mat: ShaderMaterial

func _ready() -> void:
    _flash_mat = preload("res://shaders/hit_flash.gdshader")
                 # or store as a ShaderMaterial .tres
    var mat := ShaderMaterial.new()
    mat.shader = preload("res://shaders/hit_flash.gdshader")
    _flash_mat = mat
    _sprite.material = _flash_mat

func take_damage(amount: int) -> void:
    stats.health -= amount
    _play_hit_flash()
    if stats.health <= 0:
        _die()

func _play_hit_flash() -> void:
    _flash_mat.set_shader_parameter("flash_amount", 1.0)
    var tween := create_tween()
    tween.tween_method(
        func(v: float): _flash_mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, 0.12
    )
```

## Extension Challenges

The capstone above is a working prototype. The following challenges
 extend it into a richer game without step-by-step guidance — apply
 what you have learned throughout the book:

:::problem{difficulty="easy"}
**A. Coin pickups.**
 Add a `Coin` `Area2D` scene that the
 player can walk over to collect. Track the coin count in
 `GameState` and display it in the HUD. Persist the
 count in `SaveData`.

::::solution[How to know it works]
Working when: the count survives quitting and relaunching, and the HUD
updates the moment a coin is taken rather than on the next frame.

Have `GameState` emit a signal on change and let the HUD listen; polling the
count in `_process` is the version that looks fine and drifts by a frame. In
the coin's `body_entered`, add to the count *before* `queue_free()` -- a freed
node's signal handler still runs, but anything reading the node after it does
not.
::::

:::

:::problem{difficulty="standard"}
**B. Chest interaction.**
 Add a `Chest` scene with an
 `InteractArea2D` that the player can open with a
 dedicated Interact key (E). The chest spawns a
 random item from a drop table
 (`Array[ItemData]` with weights) and tries to add it
 to the player's inventory. If the inventory is full, drop a
 `WorldItem` on the ground instead. Once opened, the
 chest stays open after save/load.

::::solution[How to know it works]
Working when: an opened chest is still open after a save and reload, and a
full inventory leaves a `WorldItem` on the floor instead of eating the drop.

Record opened chests in `SaveData` by a stable id you assign, not by node path.
Node paths look like identifiers and are not: rebuild the room, reorder a
sibling, and every chest forgets itself.
::::

:::

:::problem{difficulty="standard"}
**C. Minimap.**
 Draw a minimap in the HUD corner using
 `SubViewport` (render the room at a small scale) or
 a procedural `CanvasItem._draw()` that reads TileMap
 tile occupancy. Mark the player position with a coloured dot
 that updates every physics frame.

::::solution[How to know it works]
Working when: the dot tracks the player smoothly and the minimap survives
the player leaving and re-entering the room.

If you take the `SubViewport` route, set `render_target_update_mode` -- the
default renders once and then never again, which reads as a frozen minimap
rather than a broken one. Update the dot in `_physics_process`, so it is
sampling the same tick the body moved on.
::::

:::

:::problem{difficulty="challenge"}
**D. Dialogue system.**
 Add an NPC with a dialogue tree stored in a JSON or CSV file.
 Display a dialogue box (see Ch 36 for
 `RichTextLabel` and `StyleBoxFlat`) with
 typewriter-effect text using a timer and string indexing.
 Branch the dialogue based on whether the player has collected a
 specific item.

::::solution[How to know it works]
Working when: the same NPC gives different lines depending on whether the
player is carrying the item, and the typewriter effect never shows half a
BBCode tag.

Drive the reveal with `RichTextLabel`'s `visible_characters`, not by slicing
the string. Slicing counts markup as characters, so `[b]` arrives one bracket
at a time and renders as literal text.
::::

:::

:::problem{difficulty="challenge"}
**E. Procedural dungeon.**
 Replace the hand-crafted TileMap rooms with a procedurally
 generated dungeon using the BSP (Binary Space Partitioning)
 algorithm from Ch 29. Carve corridors between rooms and
 populate them with random enemy spawn points. Seed the
 generator from a per-save random seed stored in
 `SaveData` so the same seed always produces the same
 dungeon.

::::solution[How to know it works]
Working when: the same seed produces the same dungeon twice in a row,
including after loading a save.

Use your own `RandomNumberGenerator` with its `seed` set, not the global
`randi()`. The global stream is shared with every other system that draws from
it, so adding one random sound effect elsewhere silently changes your
layout -- which is the hardest kind of bug to attribute.
::::

:::

:::problem{difficulty="challenge"}
**F. Full export pipeline.**
 Configure export presets for Windows and Web (applying the
 techniques from Ch 41). Write a GitHub Actions workflow that
 builds both on push to `main` and attaches the
 archives to a GitHub Release when a version tag is pushed.
 Test the Web build locally by running
 `godot --serve-http` and verifying
 SharedArrayBuffer headers are set.

::::solution[How to know it works]
Working when: a fresh clone of the repository, pushed with a version tag,
produces both archives on the Release without anyone touching a machine.

The Web build is the one that fails late: it needs to be served over HTTP with
cross-origin isolation headers set, and opening `index.html` from disk will not
do it. Test the served build before you trust the workflow.
::::

:::
