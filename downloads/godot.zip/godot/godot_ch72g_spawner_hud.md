---
title: "Crowd Runner — LevelSpawner, Portrait HUD & Menus"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72G"
meta:
  - "Est. study time: ~75 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72g_spawner_hud.html"
---

## Overview

Everything up to Ch 72F was a game with content you had to place by hand. This chapter
 makes it a *game loop*: procedurally spawn rows every 12 m, ramp difficulty by
 distance, show a live portrait HUD with juicy tweened numbers, and wrap the whole thing
 in main / pause / game-over menus with real scene transitions.

:::callout-key[What you'll build in this chapter]
LevelSpawner (Node in Main) with the distance-based row selector. HUD.tscn
 (portrait Control) showing crowd count + distance with bounce tween on change.
 MainMenu.tscn, PauseMenu.tscn, GameOverMenu.tscn — three Control scenes.
 GameManager grows to own the state transitions and scene changes.
:::

### Prerequisites

- Ch 72F — Gate/TwoGateRow/WallObstacle/SawObstacle scenes exist.
- Control node basics (Ch 36, 37).
- Themes + StyleBox (Ch 39) — optional; we use plain Colors here for speed.

:::callout-connect[Reference checklist]
**Ch 11** (autoloads/singletons),
 **Ch 36–41** (Control, containers, buttons, labels — the full UI stack),
 **Ch 28** (Tween basics), **Ch 25** (scene management &
 `change_scene_to_file`).
:::

## 1. LevelSpawner Node

1. Open `Main.tscn`.
2. Delete the three manually-placed test items from WorldContainer (TwoGateRow,
 WallObstacle, SawObstacle you added in Ch 72F step 8). WorldContainer becomes empty
 again.
3. Add a new child to **Main** root: **Node** (not Node3D — it
 has no visuals), name **LevelSpawner**.
4. Attach script `res://scripts/level/LevelSpawner.gd`, template Empty,
 inherits Node.

Updated Main tree:

```
Main (Node3D)                              ← Main.gd
├── WorldEnvironment
├── SunLight (DirectionalLight3D)
├── GroundContainer (Node3D)                ← GroundRecycler.gd
│   ├── GroundSegment_A
│   └── GroundSegment_B
├── WorldContainer (Node3D)                 ← empty; spawner fills at runtime
├── Runner (CharacterBody3D)                ← Runner scene instance
├── CameraRig (Node3D)                      ← CameraRig.gd
│   └── Camera3D
└── LevelSpawner (Node)                     ← LevelSpawner.gd (NEW)
```

## 2. LevelSpawner.gd

```gdscript
# res://scripts/level/LevelSpawner.gd
# Spawns TwoGateRows / WallObstacles / SawObstacles ahead of the runner as they
# progress. Frees rows behind the camera. Triggers end-of-run at final_distance.
# See Ch 72 Design Sheet §LevelSpawner.
extends Node

enum RowType { TWO_GATE, WALL, SAW }

@export var runner_path        : NodePath
@export var world_container    : NodePath
@export var spawn_lookahead    : float = 40.0
@export var despawn_behind     : float = 20.0
@export var spawn_step         : float = 12.0
@export var final_distance     : float = 400.0

@onready var runner : Runner = get_node(runner_path)
@onready var world  : Node3D = get_node(world_container)

const TWO_GATE_ROW := preload("res://scenes/world/TwoGateRow.tscn")
const WALL_OBSTACLE := preload("res://scenes/world/WallObstacle.tscn")
const SAW_OBSTACLE  := preload("res://scenes/world/SawObstacle.tscn")

var _next_spawn_z : float
var _finished     : bool = false

func _ready() -> void:
    _next_spawn_z = -spawn_step   # first row ~12 m ahead of spawn

func _physics_process(_dt: float) -> void:
    if _finished:
        return
    var runner_z : float = runner.global_position.z
    # Spawn ahead
    while _next_spawn_z > runner_z - spawn_lookahead:
        _spawn_row(_next_spawn_z, absf(runner_z))
        _next_spawn_z -= spawn_step
    # Despawn behind
    for row in world.get_children():
        if row.global_position.z > runner_z + despawn_behind:
            row.queue_free()
    # End-of-run trigger
    if absf(runner_z) >= final_distance:
        _finished = true
        EventBus.run_finalizing.emit()

func _spawn_row(z: float, distance_m: float) -> void:
    var kind : RowType = _pick_row_type(distance_m)
    match kind:
        RowType.TWO_GATE: _spawn_two_gate(z, distance_m)
        RowType.WALL:     _spawn_wall(z)
        RowType.SAW:      _spawn_saw(z)

func _pick_row_type(distance_m: float) -> RowType:
    var r : float = randf()
    if distance_m < 80.0:
        if r < 0.80: return RowType.TWO_GATE
        if r < 0.95: return RowType.WALL
        return RowType.SAW
    elif distance_m < 200.0:
        if r < 0.55: return RowType.TWO_GATE
        if r < 0.80: return RowType.WALL
        return RowType.SAW
    else:
        if r < 0.40: return RowType.TWO_GATE
        if r < 0.65: return RowType.WALL
        return RowType.SAW

func _spawn_two_gate(z: float, distance_m: float) -> void:
    var row := TWO_GATE_ROW.instantiate() as Node3D
    world.add_child(row)
    row.global_position = Vector3(0.0, 0.0, z)
    # Randomise both gates from the difficulty-scaled palette.
    _randomise_gate(row.get_node("GateLeft") as Gate, distance_m)
    _randomise_gate(row.get_node("GateRight") as Gate, distance_m)

func _randomise_gate(g: Gate, distance_m: float) -> void:
    var t : EventBus.GateType
    var v : int
    if distance_m < 80.0:
        t = EventBus.GateType.ADD
        v = randi_range(3, 8)
    elif distance_m < 200.0:
        var pick : int = randi() % 3
        match pick:
            0: t = EventBus.GateType.ADD; v = randi_range(4, 10)
            1: t = EventBus.GateType.MUL; v = 2
            _: t = EventBus.GateType.SUB; v = randi_range(3, 8)
    else:
        var pick : int = randi() % 4
        match pick:
            0: t = EventBus.GateType.ADD; v = randi_range(6, 14)
            1: t = EventBus.GateType.MUL; v = 2
            2: t = EventBus.GateType.SUB; v = randi_range(6, 14)
            _: t = EventBus.GateType.DIV; v = 2
    g.gate_type = t
    g.value = v

func _spawn_wall(z: float) -> void:
    var lane_x : Array[float] = [-2.0, 0.0, 2.0]
    var wall := WALL_OBSTACLE.instantiate() as Node3D
    world.add_child(wall)
    wall.global_position = Vector3(lane_x[randi() % 3], 0.0, z)

func _spawn_saw(z: float) -> void:
    var lane_x : Array[float] = [-2.0, 0.0, 2.0]
    var saw := SAW_OBSTACLE.instantiate() as Node3D
    world.add_child(saw)
    saw.global_position = Vector3(lane_x[randi() % 3], 0.0, z)
```

1. In Main.tscn, select LevelSpawner. In the Inspector:

   - *Runner Path* → assign `../Runner`.
   - *World Container* → assign `../WorldContainer`.

2. Save. Run — content should now spawn as the runner advances, and old content should
 queue\_free behind the camera. There's no HUD yet so you can't see the crowd count grow,
 but the Output dock's `crowd_changed` prints (via HUD later) confirm it's
 working.

:::callout-intuition[Why \_physics\_process for the spawner]
The runner's Z is driven from \_physics\_process (move\_and\_slide). If the spawner runs
 from `_process` instead, they'd tick at different rates and you'd see subtle
 spacing drift. Keeping both on the physics tick guarantees deterministic spawn positions.
:::

:::callout-pitfall[preload vs load]
`preload` resolves at parse time — the scene is loaded once when the script
 compiles, and instantiating is cheap. `load` resolves at runtime — slower per
 call and can stall a frame the first time. For known-at-write-time scenes always
 preload.
:::

## 3. HUD Scene

1. New Scene. Root = **Control**, rename **HUD**. Save
 `res://scenes/ui/HUD.tscn`.
2. Select HUD, in the Inspector set *Layout → Anchor Preset* = *Full Rect*.
 (Fills the viewport.)
3. Add a child **PanelContainer**, name *TopBar*.

   - *Layout → Anchor Preset* = *Top Wide*.
   - *Offsets → Bottom* = `120` (120 px tall).

4. Give TopBar a StyleBoxFlat for a translucent bar: *Theme Overrides → Styles →
 Panel* → *New StyleBoxFlat*. Set *Bg Color* = `#000000`
 alpha 0.4. Corner radius all 0.
5. Add child **MarginContainer** inside TopBar. Set *Theme Overrides
 → Constants*: *Margin Left/Right* = 24, *Top/Bottom* = 12.
6. Inside MarginContainer, add **HBoxContainer**. Add three children:

   - *PauseButton* (Button) — text *❚❚*, custom\_min\_size (60, 60).
   - *Spacer* (Control) — Size Flags: Horizontal = *Expand Fill*.
   - *StatsVBox* (VBoxContainer):

     - *CrowdLabel* (Label) — text `1`, font size 64 (Theme Overrides).
     - *DistanceLabel* (Label) — text `0 m`, font size 24, modulate `#a0a0a0`.

7. Attach script `res://scenes/ui/HUD.gd`.

```
HUD (Control, Full Rect)                   ← HUD.gd
└── TopBar (PanelContainer, Top Wide, 120px)
    └── MarginContainer
        └── HBoxContainer
            ├── PauseButton (Button "❚❚", 60×60)
            ├── Spacer (Control, expand)
            └── StatsVBox (VBoxContainer, right-aligned)
                ├── CrowdLabel (Label, 64pt, text "1")
                └── DistanceLabel (Label, 24pt grey, text "0 m")
```

## 4. HUD.gd + Juicy Number Tween

```gdscript
# res://scenes/ui/HUD.gd
extends Control

@onready var crowd_label    : Label  = %CrowdLabel
@onready var distance_label : Label  = %DistanceLabel
@onready var pause_button   : Button = %PauseButton
@onready var runner_ref     : Runner = get_tree().get_first_node_in_group("runner")

var _crowd_tween : Tween

func _ready() -> void:
    EventBus.crowd_changed.connect(_on_crowd_changed)
    pause_button.pressed.connect(_on_pause_pressed)
    crowd_label.text = "1"
    distance_label.text = "0 m"

func _process(_dt: float) -> void:
    if runner_ref != null:
        distance_label.text = "%d m" % int(absf(runner_ref.global_position.z))

func _on_crowd_changed(new_count: int, delta: int) -> void:
    crowd_label.text = str(new_count)
    _bounce_and_flash(delta)

func _bounce_and_flash(delta: int) -> void:
    if _crowd_tween != null and _crowd_tween.is_valid():
        _crowd_tween.kill()
    _crowd_tween = create_tween().set_parallel(true)
    _crowd_tween.tween_property(crowd_label, "scale", Vector2.ONE, 0.25).from(Vector2(1.6, 1.6)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    var flash := Color(0.35, 0.85, 0.45) if delta >= 0 else Color(0.90, 0.35, 0.35)
    _crowd_tween.tween_property(crowd_label, "modulate", Color.WHITE, 0.35).from(flash)

func _on_pause_pressed() -> void:
    GameManager.pause_run()
```

:::callout-tip[Add Runner to the “runner” group]
The HUD grabs the runner via `get_first_node_in_group("runner")`. Open
 Runner.tscn, select the root, in the Inspector open *Node → Groups* (bottom tab),
 type *runner*, Add. Now HUD can find it without hardcoding a scene path.
:::

:::callout-tip[The % prefix in %CrowdLabel]
Unique-name shorthand. Right-click a node in the Scene dock → “Access as Unique
 Name” and Godot makes it findable anywhere in the scene as `%NodeName`
 instead of walking the tree with `$Panel/Margin/HBox/Stats/CrowdLabel`.
 Enable it for CrowdLabel, DistanceLabel, PauseButton.
:::

## 5. Main Menu Scene

1. New Scene. Root = **Control**, rename **MainMenu**. Save
 `res://scenes/ui/MainMenu.tscn`.
2. Anchor Preset = Full Rect.
3. Give it a coloured background: add child **ColorRect**, Anchor
 Full Rect, *Color* = `#1c2128`.
4. Add **VBoxContainer**, Anchor Preset = *Center*. Custom min size
 (400, 400). *Theme Overrides → Constants → separation* = 24.
5. Inside VBox add:

   - *Title* (Label) — text `ZERG MARCH`, font size 72, horizontal
    align = Center.
   - *PlayButton* (Button) — text `PLAY`, custom\_min\_size (300, 80),
    font size 32.
   - *HighScoreLabel* (Label) — text `High: 0 m`, font size 22, align
    Center, modulate `#a0a0a0`.
   - *QuitButton* (Button) — text `QUIT`, custom\_min\_size (300, 60).

6. Attach script `res://scenes/ui/MainMenu.gd`:

```gdscript
# res://scenes/ui/MainMenu.gd
extends Control

@onready var play_button   : Button = %PlayButton
@onready var quit_button   : Button = %QuitButton
@onready var high_label    : Label  = %HighScoreLabel

func _ready() -> void:
    play_button.pressed.connect(GameManager.start_run)
    quit_button.pressed.connect(get_tree().quit)
    high_label.text = "High: %d m" % GameManager.high_score
```

## 6. Pause Menu

A translucent overlay on top of the running game. Attach to Main.tscn so it lives
 inside the game scene, not as a separate scene change (which would destroy the run state).

1. Open Main.tscn. Add a child **CanvasLayer** to Main root, name
 **UICanvas**. This ensures UI renders on top of 3D regardless of camera.
2. Instance the HUD scene under UICanvas: drag
 `res://scenes/ui/HUD.tscn` onto UICanvas.
3. Add a new **Control** child under UICanvas, name *PauseMenu*.
 Anchor Full Rect. Visible = *off* at start.

   - Child ColorRect (Full Rect, colour `#000000` alpha 0.6).
   - Child VBoxContainer (Anchor Center, min size 300×260):

     - Label “PAUSED” 48pt centre.
     - Button “RESUME” unique name %ResumeButton.
     - Button “MAIN MENU” unique name %MenuButton.

4. Attach `res://scenes/ui/PauseMenu.gd`:

```gdscript
# res://scenes/ui/PauseMenu.gd
extends Control

@onready var resume_button : Button = %ResumeButton
@onready var menu_button   : Button = %MenuButton

func _ready() -> void:
    resume_button.pressed.connect(GameManager.resume_run)
    menu_button.pressed.connect(GameManager.return_to_menu)
    GameManager.state_changed.connect(_on_state_changed)
    process_mode = Node.PROCESS_MODE_ALWAYS  # keep working while tree is paused

func _on_state_changed(new_state: int) -> void:
    visible = (new_state == GameManager.State.PAUSED)

func _unhandled_input(ev: InputEvent) -> void:
    if ev.is_action_pressed("pause"):
        if GameManager.state == GameManager.State.RUNNING:
            GameManager.pause_run()
        elif GameManager.state == GameManager.State.PAUSED:
            GameManager.resume_run()
```

## 7. Game-Over Menu

Same idea as PauseMenu but shown only on `state = GAME_OVER`. Structure:

1. Under UICanvas, add another **Control**, name *GameOverMenu*.
 Anchor Full Rect. Visible = off.
2. Children: ColorRect (dim), VBoxContainer center:

   - Label “RUN OVER” 48pt.
   - Label unique name %ResultLabel — text placeholder `You marched 000 m with
    000 followers`. 22pt.
   - Label unique name %HighScoreLabel — text `New high!`, visible = off,
    modulate `#38d1c4`.
   - Button “RESTART” %RestartButton.
   - Button “MAIN MENU” %MenuButton.

3. Attach `res://scenes/ui/GameOverMenu.gd`:

```gdscript
# res://scenes/ui/GameOverMenu.gd
extends Control

@onready var result_label   : Label  = %ResultLabel
@onready var high_label     : Label  = %HighScoreLabel
@onready var restart_button : Button = %RestartButton
@onready var menu_button    : Button = %MenuButton

func _ready() -> void:
    restart_button.pressed.connect(GameManager.start_run)
    menu_button.pressed.connect(GameManager.return_to_menu)
    GameManager.state_changed.connect(_on_state_changed)
    EventBus.run_finished.connect(_on_run_finished)

func _on_state_changed(new_state: int) -> void:
    visible = (new_state == GameManager.State.GAME_OVER)

func _on_run_finished(won: bool, distance_m: int) -> void:
    var verb : String = "won" if won else "died"
    result_label.text = "You %s at %d m" % [verb, distance_m]
    var is_new_high : bool = distance_m > GameManager.high_score
    high_label.visible = is_new_high
```

## 8. Scene Flow via GameManager

Update GameManager to own scene transitions. Replace the stub from Ch 72A entirely:

```gdscript
# res://autoloads/GameManager.gd — Ch 72G full version
extends Node

enum State { MENU, RUNNING, PAUSED, GAME_OVER }

signal state_changed(new_state: State)

const SAVE_PATH   := "user://zergmarch.cfg"
const MENU_SCENE  := "res://scenes/ui/MainMenu.tscn"
const GAME_SCENE  := "res://scenes/main/Main.tscn"

var state       : State = State.MENU
var high_score  : int   = 0
var last_score  : int   = 0

func _ready() -> void:
    _load_settings()
    EventBus.run_finished.connect(_on_run_finished)

func _set_state(new_state: State) -> void:
    if new_state == state: return
    state = new_state
    state_changed.emit(new_state)

func start_run() -> void:
    get_tree().paused = false
    _set_state(State.RUNNING)
    get_tree().change_scene_to_file(GAME_SCENE)

func pause_run() -> void:
    if state != State.RUNNING: return
    get_tree().paused = true
    _set_state(State.PAUSED)

func resume_run() -> void:
    if state != State.PAUSED: return
    get_tree().paused = false
    _set_state(State.RUNNING)

func return_to_menu() -> void:
    get_tree().paused = false
    _set_state(State.MENU)
    get_tree().change_scene_to_file(MENU_SCENE)

func _on_run_finished(_won: bool, distance_m: int) -> void:
    last_score = distance_m
    if distance_m > high_score:
        high_score = distance_m
        _save_settings()
    _set_state(State.GAME_OVER)
    # Do NOT change scene — stay on Main so GameOverMenu overlays.

func _load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) == OK:
        high_score = int(cfg.get_value("score", "high", 0))

func _save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("score", "high", high_score)
    cfg.save(SAVE_PATH)
```

:::callout-tip[Set MainMenu as the actual startup scene]
Project Settings → Application → Run → Main Scene → change to
 `res://scenes/ui/MainMenu.tscn`. When the APK boots, it lands on the menu,
 not straight into a run.
:::

:::callout-pitfall[process\_mode = PROCESS\_MODE\_ALWAYS on PauseMenu]
When we call `get_tree().paused = true`, every node's `_process`
 and `_physics_process` stops — *including UI*. PauseMenu needs
 PROCESS\_MODE\_ALWAYS so its buttons still receive input while the tree is paused. Set this
 on PauseMenu (and later on GameOverMenu if you make its buttons work during a paused
 overlay). MainMenu doesn't need it because it lives in its own non-paused scene.
:::

Also, in Main.gd we need to emit `run_started` and detect crowd-zero
 game-over. Update Main.gd:

```gdscript
# res://scenes/main/Main.gd — Ch 72G update
extends Node3D

@onready var runner : Runner = $Runner

func _ready() -> void:
    EventBus.crowd_changed.connect(_on_crowd_changed)
    EventBus.run_started.emit()

func _on_crowd_changed(new_count: int, _delta: int) -> void:
    if new_count <= 0:
        var dist := int(absf(runner.global_position.z))
        EventBus.run_finished.emit(false, dist)
```

:::callout-warning[Remove the old \_set\_follow\_target code from Main.gd]
Ch 72B's *Main.gd* pointed GroundContainer and CameraRig at TestMover, then
 swapped to Runner in Ch 72C. Now that Runner is a permanent child, set both NodePaths
 directly in the Inspector once (GroundContainer.target\_path = `../Runner`,
 CameraRig.target\_path = `../Runner`) and delete the runtime rewiring code
 from Main.gd. The final Main.gd is just the four lines above.
:::

### HUD wireframe — what the phone screen looks like

Portrait 1080×1920. The HUD fills the top 120 px of the screen; the 3D world fills
 the rest. All UI is inside `UICanvas` which renders above the 3D scene.

```
┌────────────────────────────────────────┐   ← 0 px
│┌─ TopBar (120px, 40% black overlay) ─┐│
││                                       ││
││ ❚❚                              47   ││    ← crowd count (64pt)
││                                 87 m  ││    ← distance (24pt grey)
│└───────────────────────────────────────┘│   ← 120 px
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│         3D world renders here           │
│         (Camera3D chase view)           │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
└────────────────────────────────────────┘   ← 1920 px
      ← swipe area (whole screen) →
```

The pause button occupies a 60×60 tap area top-left. The stats stack (crowd + distance)
 is right-aligned so a right-handed player's thumb rarely covers it. The rest of the screen
 is one big swipe surface — *any* horizontal drag anywhere below the TopBar changes
 lanes. Buttons in the UI naturally consume input before the game sees it (via
 `_unhandled_input`), so a thumb tap on the pause button never accidentally
 counts as a swipe.

### Menu state chart — the four states of the game

GameManager owns the transitions. Every button in every menu just calls one of these
 transition methods.

```
                    ┌────────────┐
                    │   MENU     │  ← app launch lands here
                    │            │
                    └─────┬──────┘
              start_run() │
                    ┌─────▼──────┐
              ┌────▶│  RUNNING   │◀──── resume_run()
              │     │            │
              │     └──┬───┬─────┘
              │        │   │  pause_run()
              │        │   ▼
              │        │  ┌──────────┐
              │        │  │  PAUSED  │───── return_to_menu()
              │        │  └────┬─────┘        │
              │        │       │              │
              │        │  crowd 0 or          │
              │        │  distance ≥ 400      │
              │        ▼                      │
              │   run_finished emit           │
              │        │                      │
              │   ┌────▼──────┐               │
              │   │ GAME_OVER │──── restart───┘  (calls start_run)
              │   │           │
              │   └────┬──────┘
              │        │  return_to_menu()
              └────────┴───────────────────────▶ back to MENU
```

:::callout-intuition[Every button is a one-liner]
PlayButton.pressed → `GameManager.start_run()`. ResumeButton.pressed →
 `GameManager.resume_run()`. RestartButton.pressed → also
 `GameManager.start_run()` (which reloads the Main scene). MenuButton.pressed
 → `GameManager.return_to_menu()`. Because all state changes happen in
 GameManager and all buttons emit the same simple calls, adding a new menu (e.g.
 Settings) is just another button that calls one method — no state-machine surgery.
:::

## 9. Verification

:::callout-key[Verify]
- Launch app → Main Menu appears. Title, PLAY, high 0 m, QUIT.
- PLAY → scene transitions to Main. HUD appears at top: crowd “1”,
 distance “0 m”, pause button.
- Gates and obstacles spawn procedurally as you advance. Distance counter climbs.
- Passing a +5 gate bounces the crowd label with green flash. Passing a wall bounces
 it red.
- Pause button (or ESC): translucent pause overlay. Resume / Main Menu work.
- Let the crowd hit zero → GameOverMenu overlays with “died at X m.”
 Restart takes you into a fresh run; Main Menu returns to the title screen.
- Run again and beat your distance → next Game Over shows “New high!”
 High score persists across app restart (ConfigFile).
:::

:::callout-warning[HUD doesn't appear]
UICanvas missing on Main, or HUD not instanced as its child. Alternately, HUD's
 Anchor Preset isn't Full Rect (it's sized to 0×0 in the top-left).
:::

:::callout-warning[Pause overlay never appears / can't resume]
PauseMenu.process\_mode isn't *Always*. Once tree pauses, its
 \_unhandled\_input stops firing.
:::

:::callout-warning[Game-over never triggers]
Main.gd's `_on_crowd_changed` not connected, or you connected it in
 HUD.gd but not in Main.gd. Both are fine; just make sure exactly one place emits
 run\_finished when count ≤ 0.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why does the Pause Menu live under Main and the Main Menu live in its own
 scene?

::::solution[Solution]
PauseMenu overlays a paused game — the game state must persist while it's shown, so
 it must not swap the scene. MainMenu *replaces* the game scene; it's a full
 change\_scene\_to\_file, and the previous run is intentionally destroyed.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Distance shown on the HUD comes from Runner's Z each frame. What happens at
 run start when the Runner scene hasn't finished loading? Why doesn't the HUD crash?

::::solution[Solution]
HUD.gd checks `if runner_ref != null` in `_process`. On the
 first frame the group lookup might return null (Main's children not ready in that
 order); the null-check silently skips the update. By the next frame the runner exists
 and updates begin.
::::
:::

:::problem[Problem 3 challenge]{difficulty="challenge"}
The difficulty ramp is hard-coded in `_pick_row_type`. Refactor it so
 the ramp table lives in a Resource file that a game designer can edit without touching
 code.

::::solution[Solution]
Define `class_name DifficultyBand extends Resource` with @exports
 `min_distance`, `weight_two_gate`, `weight_wall`,
 `weight_saw`. Make DifficultyTable a Resource holding
 `Array[DifficultyBand]`. LevelSpawner @exports a DifficultyTable file. At
 pick time, find the band whose min\_distance is the largest ≤ current distance, then
 sample from its weights. Designers create/edit `.tres` files in the FileSystem
 dock — no code change needed to rebalance.
::::
:::

:::summary
## Summary

The game is a real loop now. LevelSpawner drops gates and obstacles procedurally with
 a distance-based difficulty ramp. HUD shows crowd and distance with juicy tween bounces
 and colour-flash feedback. MainMenu / PauseMenu / GameOverMenu handle the flow between
 states. ConfigFile persists the high score. GameManager owns state transitions and
 scene changes. Missing pieces: end-of-run enemy wall battle (72H section 1), particles
 and screen shake (72H section 3), Android export (72H section 5).

**Next:**
 [Ch 72H](./godot_ch72h_end_polish_export.html) — the final chapter. The enemy
 wall, mini-brawl VFX, all polish passes, and shipping to a signed Android APK.
:::
