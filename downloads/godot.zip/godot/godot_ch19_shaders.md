---
title: "Shaders — Godot Shading Language, 2D & 3D Effects"
source: "godot_ch19_shaders.html"
---

Part III · Chapter 19

# Shaders — Godot Shading Language, 2D & 3D Effects

Prerequisite: Chapter 6 (Resources) · est. 100 min

## Overview

Shaders are small programs that run on the GPU, controlling how every pixel (and vertex) of a
 mesh is drawn. Godot's **Godot Shading Language (GSL)** is GLSL-like but simpler —
 no `main()` entry point, no explicit buffer bindings. You write shader functions that
 Godot calls at the right time.

There are two ways to author shaders in Godot:

- **Code shaders** — write a `.gdshader` file; full power and precision.
- **VisualShader** — node-based graph editor; great for non-programmers and
 prototyping, but generates the same code under the hood.

Shaders attach to materials (`ShaderMaterial`), which attach to meshes, sprites,
 particles, and control nodes. Once you understand the material → shader pipeline, all
 the creative possibilities open up.

## 1 · Godot Shading Language

### 1.1 · Shader types

Every shader starts with a `shader_type` declaration that tells Godot which pipeline
 it belongs to and which built-in variables are available:

| Type | Use case | Functions available |
| --- | --- | --- |
| `canvas_item` | Sprites, UI nodes, 2D meshes | `vertex()`, `fragment()`, `light()` |
| `spatial` | 3D MeshInstance3D surfaces | `vertex()`, `fragment()`, `light()` |
| `particles` | GPUParticles custom process shader | `process()` |
| `sky` | Procedural sky background | `sky()` |
| `fog` | Volumetric fog density | `fog()` |

### 1.2 · Built-in variables (canvas\_item fragment)

```glsl

shader_type canvas_item;

// These are already in scope in every canvas_item fragment shader. You do not
// declare them -- declaring one is a redefinition error and the shader will
// not compile:
//
//   UV                  vec2       texture coordinate, 0 to 1
//   FRAGCOORD           vec4       screen-space position; .xy are the pixel
//   TEXTURE             sampler2D  the node's own texture
//   TEXTURE_PIXEL_SIZE  vec2       1.0 / texture size, in pixels
//   COLOR               vec4       in: the vertex tint
//                                  out: the pixel this shader produces

void fragment() {
    // Sample the sprite texture, then apply the vertex tint that arrived
    // in COLOR -- reading it and writing it in one line.
    vec4 tex = texture(TEXTURE, UV);
    COLOR = tex * COLOR;
}
```

### 1.3 · Uniforms — passing data from GDScript

Declare a `uniform` variable in the shader to expose it as a parameter you can set
 from GDScript. Godot shows uniforms as editable properties in the material inspector.

```glsl

shader_type canvas_item;

// Exposed to inspector and GDScript
uniform vec4  tint_color : source_color = vec4(1.0);
uniform float brightness : hint_range(0.0, 2.0) = 1.0;
uniform sampler2D noise_tex : hint_default_white;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    col.rgb  *= tint_color.rgb * brightness;
    COLOR     = col;
}
```

The `: hint_*` annotation after the type is optional but provides inspector UI hints
 (sliders, colour pickers, texture fields). Common hints:

| Hint | Inspector widget |
| --- | --- |
| `source_color` | Colour picker (sRGB-corrected) |
| `hint_range(min, max)` | Slider |
| `hint_range(min, max, step)` | Slider with step |
| `hint_default_black` | Texture field, default to black |
| `hint_default_white` | Texture field, default to white |
| `hint_normal` | Texture field, treated as normal map |

## 2 · canvas\_item Shaders (2D)

### 2.1 · Fragment shader anatomy

```glsl

shader_type canvas_item;
// render_mode options (comma-separate multiple):
// blend_mix (default), blend_add, blend_sub, blend_mul
// unshaded — skip lighting
// skip_vertex_transform — handle VERTEX transform yourself
render_mode blend_mix, unshaded;

// Note there is deliberately no `uniform sampler2D TEXTURE;` line here.
// Godot provides it, and declaring it again is a redefinition error.

void fragment() {
    vec4 col = texture(TEXTURE, UV);

    // Discard pixels with alpha below threshold (sharp cut-out)
    if (col.a < 0.1) discard;

    COLOR = col;
}
```

### 2.2 · Common 2D effects

**Sprite outline (inner glow)** — sample eight neighbouring texels to detect the edge:

```glsl

shader_type canvas_item;
uniform vec4  outline_color : source_color = vec4(1.0, 1.0, 0.0, 1.0);
uniform float outline_width : hint_range(0.0, 8.0) = 2.0;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    float a = col.a;

    // Sample in 8 directions
    vec2 ps = TEXTURE_PIXEL_SIZE * outline_width;
    float neighbour_alpha = 0.0;
    neighbour_alpha += texture(TEXTURE, UV + vec2(ps.x,  0.0 )).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2(-ps.x, 0.0 )).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2(0.0,   ps.y)).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2(0.0,  -ps.y)).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2( ps.x,  ps.y)).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2(-ps.x,  ps.y)).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2( ps.x, -ps.y)).a;
    neighbour_alpha += texture(TEXTURE, UV + vec2(-ps.x, -ps.y)).a;

    float outline = clamp(neighbour_alpha, 0.0, 1.0) * (1.0 - a);
    COLOR = mix(col, outline_color, outline);
    COLOR.a = max(a, outline);
}
```

**Grayscale / desaturate**:

```glsl

shader_type canvas_item;
uniform float desaturate : hint_range(0.0, 1.0) = 1.0;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
    COLOR = vec4(mix(col.rgb, vec3(luma), desaturate), col.a);
}
```

**Hit-flash (white silhouette)**:

```glsl

shader_type canvas_item;
uniform float flash : hint_range(0.0, 1.0) = 0.0;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    COLOR = mix(col, vec4(1.0, 1.0, 1.0, col.a), flash * col.a);
}
```

**UV scroll (water / conveyor belt)**:

```glsl

shader_type canvas_item;
uniform vec2  scroll_speed = vec2(0.1, 0.0);

void fragment() {
    vec2 scrolled_uv = UV + scroll_speed * TIME;
    COLOR = texture(TEXTURE, scrolled_uv);
}
```

## 3 · Spatial Shaders (3D)

### 3.1 · Vertex deformation

The `vertex()` function runs once per vertex before rasterisation. Modify
 `VERTEX` (object-space position) to deform geometry:

```glsl

shader_type spatial;
render_mode unshaded;

uniform float wave_height  : hint_range(0.0, 1.0) = 0.2;
uniform float wave_speed   : hint_range(0.1, 5.0) = 1.5;
uniform float wave_freq    : hint_range(0.1, 10.0)= 3.0;

void vertex() {
    // Sine wave along Y based on world X position and time
    float world_x = (MODEL_MATRIX * vec4(VERTEX, 1.0)).x;
    VERTEX.y += sin(world_x * wave_freq + TIME * wave_speed) * wave_height;
}

void fragment() {
    ALBEDO = vec3(0.2, 0.5, 1.0);  // flat ocean blue
}
```

### 3.2 · PBR fragment output variables

The spatial `fragment()` function exposes a set of write-only output variables
 that drive Godot's physically-based rendering pipeline:

| Output variable | Type | Purpose |
| --- | --- | --- |
| `ALBEDO` | `vec3` | Base colour (diffuse reflectance) |
| `METALLIC` | `float` | 0 = dielectric (plastic), 1 = metal |
| `ROUGHNESS` | `float` | 0 = mirror, 1 = fully rough |
| `NORMAL_MAP` | `vec3` | Tangent-space normal from a texture |
| `EMISSION` | `vec3` | Additive emissive colour (HDR) |
| `AO` | `float` | Ambient occlusion (0 = fully occluded) |
| `ALPHA` | `float` | Transparency (requires `render_mode blend_mix`) |
| `ALPHA_SCISSOR_THRESHOLD` | `float` | Hard cut-out alpha threshold |

### 3.3 · Common 3D effects

**Dissolve / burn effect** — uses a noise texture to cut pixels away:

```glsl

shader_type spatial;
render_mode blend_mix, depth_draw_always, cull_back;

uniform sampler2D dissolve_tex : hint_default_white;
uniform float     dissolve     : hint_range(0.0, 1.0) = 0.0;
uniform vec3      burn_color   : source_color          = vec3(1.0, 0.3, 0.0);

void fragment() {
    float noise = texture(dissolve_tex, UV).r;
    float threshold = dissolve;
    if (noise < threshold - 0.05) discard;

    ALBEDO = mix(ALBEDO, burn_color, step(noise, threshold));
    EMISSION = burn_color * step(noise, threshold + 0.05) * (1.0 - step(noise, threshold));
    ALPHA   = 1.0;
}
```

**Fresnel rim light**:

```glsl

shader_type spatial;

uniform vec3  rim_color : source_color = vec3(0.2, 0.7, 1.0);
uniform float rim_power : hint_range(0.5, 8.0) = 3.0;

void fragment() {
    float fresnel = pow(1.0 - dot(NORMAL, VIEW), rim_power);
    ALBEDO   = vec3(0.1);
    EMISSION = rim_color * fresnel;
    METALLIC  = 0.0;
    ROUGHNESS = 0.8;
}
```

**Intersection highlight** (depth-based edge glow):

```glsl

shader_type spatial;
render_mode blend_add, depth_draw_never, cull_disabled;

// DEPTH_TEXTURE was removed as a built-in in Godot 4; the depth buffer now
// arrives through a uniform carrying the hint_depth_texture qualifier.
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest;
uniform vec3  glow_color : source_color = vec3(0.0, 1.0, 1.0);
uniform float glow_scale : hint_range(0.1, 5.0) = 1.0;

void fragment() {
    float depth = texture(depth_tex, SCREEN_UV).r;
    float scene_z = depth * 2.0 - 1.0;   // NDC
    float frag_z  = FRAGCOORD.z * 2.0 - 1.0;
    float diff    = clamp((scene_z - frag_z) * glow_scale * 100.0, 0.0, 1.0);
    ALBEDO  = glow_color;
    ALPHA   = 1.0 - diff;
}
```

## 4 · Driving Shaders from GDScript

### 4.1 · set\_shader\_parameter

```gdscript

# Get the ShaderMaterial on a node
var mat: ShaderMaterial = $Sprite2D.material as ShaderMaterial

# Set a float uniform
mat.set_shader_parameter("dissolve", 0.5)

# Set a colour
mat.set_shader_parameter("tint_color", Color(1.0, 0.2, 0.2, 1.0))

# Set a texture
mat.set_shader_parameter("noise_tex", preload("res://textures/noise.png"))

# Read a parameter back
var current: float = mat.get_shader_parameter("dissolve")
```

Animate a dissolve effect with Tween:

```gdscript

func dissolve_out() -> void:
    var mat := $Sprite2D.material as ShaderMaterial
    var tw  := create_tween()
    # Tween the "dissolve" shader parameter directly
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("dissolve", v),
        0.0, 1.0, 1.5
    ).set_trans(Tween.TRANS_LINEAR)
    await tw.finished
    queue_free()
```

### 4.2 · ShaderMaterial vs BaseMaterial3D

|  | BaseMaterial3D / ORMMaterial3D | ShaderMaterial |
| --- | --- | --- |
| **Setup** | Inspector properties only — no code | Write a .gdshader file |
| **Flexibility** | Fixed PBR model | Arbitrary fragment logic |
| **Performance** | Highly optimised | Depends on shader complexity |
| **Conversion** | Right-click → Convert to ShaderMaterial | — |
| **Best for** | Standard surfaces, quick iteration | Custom effects, procedural visuals |

:::callout-tip
💡 Convert BaseMaterial3D to start a shader

Configure your material visually in the inspector, then right-click →

Convert to
        ShaderMaterial

.  Godot generates the equivalent code shader, giving you a working
        starting point to customise.
:::

## 5 · VisualShader

Create a `ShaderMaterial` and set its shader to a **VisualShader**
 resource instead of a `.gdshader` file. The editor shows a node graph where you
 connect data-flow nodes to build shader logic without code.

Key VisualShader node categories:

| Category | Example nodes |
| --- | --- |
| **Input** | UV, TIME, FRAGCOORD, NORMAL, VERTEX, COLOR |
| **Texture** | Texture2D, NoiseTexture2D (sample inline) |
| **Math** | Add, Multiply, Mix, Clamp, Sin, Step, SmoothStep |
| **Vector** | VectorOp (component-wise), VectorDecompose, Dot, Cross, Normalize |
| **Color** | ColorOp (blend modes), ColorFunc (grayscale, sepia) |
| **Procedural** | Noise (value/perlin/simplex), Voronoi, Curve (sample a Curve resource) |
| **Utility** | If, Compare, Switch, CustomExpression (write inline GLSL) |

:::callout-tip
💡 Mix code and VisualShader

VisualShader has a

CustomExpression

node that lets you write arbitrary GLSL
        inline.  Use the graph for structure and CustomExpression for complex math you can't express
        with pre-built nodes.
:::

## Summary

| Concept | Key takeaway |
| --- | --- |
| **shader\_type** | canvas\_item for 2D, spatial for 3D — determines available built-ins |
| **uniform** | Exposed parameter — set from GDScript with `set_shader_parameter()` |
| **hint\_range / source\_color** | Inspector UI hints for sliders and colour pickers |
| **fragment COLOR (2D)** | The writeable RGBA output of a canvas\_item fragment |
| **ALBEDO / ROUGHNESS / METALLIC** | PBR outputs in spatial fragment |
| **EMISSION** | Additive self-illumination — drive with fresnel or dissolve edge |
| **TIME** | Seconds since scene start — use for any animated effect |
| **discard** | Kill a fragment entirely — use for alpha cut-out and dissolve |

- Start from a converted `BaseMaterial3D` rather than a blank shader — less to type.
- Use `TIME` for any animated effect (scrolling, pulsing, wave deformation).
- Drive dissolve and hit-flash with `set_shader_parameter()` + Tween from GDScript.
- Add `: source_color` to colour uniforms so Godot handles gamma conversion correctly.
- For mobile, prefer fewer texture samples and avoid branching inside hot shader loops.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Grayscale on death

A character sprite uses a `ShaderMaterial` with the grayscale shader from section 2.2.
 Write a GDScript function `die()` that tweens the `desaturate` parameter
 from 0 to 1 over 0.8 seconds using `TRANS_SINE`.

::::solution[Solution]
```gdscript

extends CharacterBody2D

func die() -> void:
    var mat := $Sprite2D.material as ShaderMaterial
    var tw  := create_tween()
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("desaturate", v),
        0.0, 1.0, 0.8
    ).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Pulsing emission ring

Write a `spatial` shader for a ring mesh that pulses its emission colour between
 black and bright cyan once per second using `TIME`. No uniforms needed.

::::solution[Solution]
```glsl

shader_type spatial;
render_mode unshaded;

void fragment() {
    float pulse = (sin(TIME * TAU) + 1.0) * 0.5;   // 0–1 at 1 Hz
    EMISSION = vec3(0.0, 1.0, 1.0) * pulse * 3.0;
    ALBEDO   = vec3(0.0);
    ALPHA    = 1.0;
}
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Sprite outline toggle

Using the outline shader from section 2.2 as a base, expose an additional
 `bool` uniform `outline_active`. When false, the shader should
 render the sprite normally with no outline. Wire up a GDScript
 `set_outline(enabled: bool)` method.

::::solution[Solution]
```glsl

// Shader (outline_toggle.gdshader):
shader_type canvas_item;
uniform vec4  outline_color : source_color = vec4(1.0, 1.0, 0.0, 1.0);
uniform float outline_width : hint_range(0.0, 8.0) = 2.0;
uniform bool  outline_active = false;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    // No early `return` here: a shader processor function may not contain one,
    // so the toggle has to be an if/else rather than a guard clause.
    if (!outline_active) {
        COLOR = col;
    } else {
        vec2 ps = TEXTURE_PIXEL_SIZE * outline_width;
        float n = 0.0;
        n += texture(TEXTURE, UV + vec2( ps.x,  0.0)).a;
        n += texture(TEXTURE, UV + vec2(-ps.x,  0.0)).a;
        n += texture(TEXTURE, UV + vec2( 0.0,  ps.y)).a;
        n += texture(TEXTURE, UV + vec2( 0.0, -ps.y)).a;
        n += texture(TEXTURE, UV + vec2( ps.x,  ps.y)).a;
        n += texture(TEXTURE, UV + vec2(-ps.x,  ps.y)).a;
        n += texture(TEXTURE, UV + vec2( ps.x, -ps.y)).a;
        n += texture(TEXTURE, UV + vec2(-ps.x, -ps.y)).a;
        float o = clamp(n, 0.0, 1.0) * (1.0 - col.a);
        COLOR   = mix(col, outline_color, o);
        COLOR.a = max(col.a, o);
    }
}
```

```gdscript

# GDScript:
func set_outline(enabled: bool) -> void:
    var mat := $Sprite2D.material as ShaderMaterial
    mat.set_shader_parameter("outline_active", enabled)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Animated dissolve in/out

A `Sprite2D` uses the dissolve shader from section 3.3. Write two coroutine
 functions: `appear()` tweens `dissolve` from 1 to 0 over 0.6 s
 (materialises), and `disappear()` tweens from 0 to 1 over 0.6 s then calls
 `queue_free()`.

::::solution[Solution]
```gdscript

extends Sprite2D

func appear() -> void:
    var mat := material as ShaderMaterial
    mat.set_shader_parameter("dissolve", 1.0)
    visible = true
    var tw  := create_tween()
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("dissolve", v),
        1.0, 0.0, 0.6
    ).set_trans(Tween.TRANS_LINEAR)
    await tw.finished

func disappear() -> void:
    var mat := material as ShaderMaterial
    var tw  := create_tween()
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("dissolve", v),
        0.0, 1.0, 0.6
    ).set_trans(Tween.TRANS_LINEAR)
    await tw.finished
    queue_free()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Vertex wave on a water plane

Create a spatial shader for a flat `PlaneMesh` that simulates simple ocean waves:
 two overlapping sine waves with different frequencies and speeds travel along the X axis.
 Expose `wave_height`, `wave_speed_1`, and `wave_speed_2`
 as uniforms. Set `ALBEDO` to a deep blue and `ROUGHNESS` to 0.1.

::::solution[Solution]
```glsl

shader_type spatial;

uniform float wave_height  : hint_range(0.0, 2.0) = 0.3;
uniform float wave_speed_1 : hint_range(0.1, 5.0) = 1.2;
uniform float wave_speed_2 : hint_range(0.1, 5.0) = 0.7;

void vertex() {
    float wx = (MODEL_MATRIX * vec4(VERTEX, 1.0)).x;
    float wy = (MODEL_MATRIX * vec4(VERTEX, 1.0)).z;
    VERTEX.y += sin(wx * 1.5 + TIME * wave_speed_1) * wave_height * 0.6;
    VERTEX.y += sin(wy * 2.3 + TIME * wave_speed_2) * wave_height * 0.4;
}

void fragment() {
    ALBEDO    = vec3(0.04, 0.18, 0.35);
    METALLIC  = 0.0;
    ROUGHNESS = 0.1;
    SPECULAR  = 0.9;
}
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Full damage-flash + dissolve system

Build a reusable `DamageEffect` component (Node child) that:

- Attaches to any `Sprite2D` sibling via `@export`.
- On `flash()`: tweens the shader's `flash` param from 1.0 to 0.0 over 0.15 s.
- On `die()`: first plays the flash, then runs the dissolve animation over 0.8 s, then emits a `death_complete` signal.
- The `.gdshader` combines both the hit-flash (section 2.2) and grayscale (section 2.2) into one material — flash whites out; grayscale desaturates as dissolve proceeds.

::::solution[Solution]
```glsl

// damage_effect.gdshader
shader_type canvas_item;
uniform float flash       : hint_range(0.0, 1.0) = 0.0;
uniform float desaturate  : hint_range(0.0, 1.0) = 0.0;
uniform sampler2D noise_tex : hint_default_white;
uniform float dissolve    : hint_range(0.0, 1.0) = 0.0;

void fragment() {
    vec4 col  = texture(TEXTURE, UV);

    // Dissolve
    float n = texture(noise_tex, UV).r;
    if (n < dissolve) discard;

    // Desaturate
    float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
    col.rgb = mix(col.rgb, vec3(luma), desaturate);

    // Flash
    col.rgb = mix(col.rgb, vec3(1.0), flash * col.a);

    COLOR = col;
}
```

```gdscript

# DamageEffect.gd
extends Node

signal death_complete

@export var sprite_path: NodePath

@onready var _sprite: Sprite2D = get_node(sprite_path)
var _mat: ShaderMaterial

func _ready() -> void:
    _mat = _sprite.material as ShaderMaterial

## Not named _set: that is Object's property-interception virtual, and
## redefining it with a different signature stops the script loading.
func set_param(name: StringName, val: float) -> void:
    if _mat: _mat.set_shader_parameter(name, val)

func flash() -> void:
    _mat.set_shader_parameter("flash", 1.0)
    var tw := create_tween()
    tw.tween_method(func(v): _mat.set_shader_parameter("flash", v), 1.0, 0.0, 0.15)

func die() -> void:
    await _do_flash()
    await _do_dissolve()
    death_complete.emit()

func _do_flash() -> void:
    _mat.set_shader_parameter("flash", 1.0)
    var tw := create_tween()
    tw.tween_method(func(v): _mat.set_shader_parameter("flash", v), 1.0, 0.0, 0.15)
    await tw.finished

func _do_dissolve() -> void:
    var tw := create_tween().set_parallel(false)
    # Desaturate while dissolving
    tw.tween_method(func(v): _mat.set_shader_parameter("desaturate", v), 0.0, 1.0, 0.8)
    tw.parallel().tween_method(func(v): _mat.set_shader_parameter("dissolve", v), 0.0, 1.0, 0.8)
    await tw.finished
```
::::
:::
