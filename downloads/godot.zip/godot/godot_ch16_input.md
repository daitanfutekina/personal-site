---
title: "Input — InputMap, Events & Controllers"
source: "markdown"
---

Part III · Chapter 16

# Input — InputMap, Events & Controllers

Prerequisite: Chapter 4 (GDScript basics) · est. 80 min

## Overview

Godot's input system has three interacting pieces:

- **InputMap** — a project-wide dictionary that maps action names (strings like
 `"jump"` or `"ui_accept"`) to one or more physical inputs.
 You configure it in *Project Settings → Input Map* or at runtime in code.
- **Input singleton** — a polling API. Ask *right now* whether an action is
 pressed, how far an analogue axis is pushed, where the mouse is.
- **InputEvent objects** — event-driven. Godot routes an `InputEvent`
 down the scene tree whenever something happens (key press, mouse click, controller axis move).
 Override `_input()` or `_unhandled_input()` to react.

Most gameplay code uses *polling* in `_physics_process()` for continuous actions
 (movement, aiming) and *events* for discrete actions (menu navigation, text input).

## 1 · InputMap

### 1.1 · Defining actions

Open **Project → Project Settings → Input Map**. Type a new action name and press
 Add, then click the + next to the action to bind keys, mouse buttons, or
 controller axes to it. Each action can have multiple bindings — the player can trigger it with
 a keyboard key *or* a gamepad button.

Built-in UI actions (`ui_accept`, `ui_cancel`, `ui_left`, etc.)
 are pre-defined; you should not remove them as Control nodes rely on them for keyboard navigation.

### 1.2 · Runtime remapping

You can read and modify the InputMap at runtime — essential for a key-rebinding settings screen:

```gdscript

# Check what's bound to an action
var events := InputMap.action_get_events("jump")
for ev in events:
    print(ev.as_text())   # "Space", "Joypad Button 0 (Sony Cross, Xbox A, Nintendo B)", etc.

# Rebind "jump" to a new key
func rebind_action(action: StringName, new_event: InputEvent) -> void:
    InputMap.action_erase_events(action)   # clear old bindings
    InputMap.action_add_event(action, new_event)

# Build a new InputEventKey to bind programmatically
var ev := InputEventKey.new()
ev.keycode = KEY_Z
InputMap.action_add_event("jump", ev)

# Restore all bindings to project defaults
InputMap.load_from_project_settings()
```

:::callout-tip
💡 Save remapped bindings

Persist rebindings across sessions by saving the InputEvent resources to a

ConfigFile

or a custom

Resource

in

user://

,
        then reloading and calling

action\_add\_event()

in your settings autoload's `_ready()`.
:::

## 2 · Input Singleton

### 2.1 · Polling — continuous queries

| Method | Returns | Use case |
| --- | --- | --- |
| `Input.is_action_pressed("jump")` | `bool` | True while the action is held |
| `Input.is_action_just_pressed("jump")` | `bool` | True for one frame when the action starts |
| `Input.is_action_just_released("jump")` | `bool` | True for one frame when the action ends |
| `Input.get_action_strength("accelerate")` | `float 0–1` | Analogue value of an action (trigger pressure) |
| `Input.get_action_raw_strength("accelerate")` | `float 0–1` | Same but before deadzone processing |
| `Input.is_key_pressed(KEY_F)` | `bool` | Physical key check without an action mapping |
| `Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)` | `bool` | Mouse button held check |

### 2.2 · get\_vector and get\_axis

`Input.get_vector()` is the canonical way to read 2D directional input from four actions.
 It normalises the result to a unit circle (so diagonal is not faster than cardinal) and applies
 deadzone automatically.

```gdscript

func _physics_process(delta: float) -> void:
    # WASD / arrow keys / left stick — returns normalized Vector2
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity = dir * SPEED
    move_and_slide()

# get_axis — 1D signed float (-1 to +1)
var throttle := Input.get_axis("brake", "accelerate")   # -1 = full brake, +1 = full gas
```

:::callout-key
🔑 get\_vector normalises diagonals

If you manually combine two

is\_action\_pressed

checks and both are true,
        you get a diagonal with length √2 ≈ 1.41 — faster than cardinal.

get\_vector

normalises to length 1.0 so diagonals are not faster.
        Always prefer

get\_vector

for 2D movement.
:::

### 2.3 · Mouse position and buttons

```gdscript

# Viewport-relative position (pixels from top-left of the viewport)
var screen_pos := get_viewport().get_mouse_position()

# World position (accounts for camera transform)
var world_pos  := get_global_mouse_position()   # only on Node2D

# Mouse speed (pixels/frame, not pixels/second)
var delta_px := Input.get_last_mouse_velocity()   # Vector2

# Cursor modes
Input.set_mouse_mode(Input.MOUSE_MODE_HIDDEN)       # invisible, can move
Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)     # locked to center, FPS-style
Input.set_mouse_mode(Input.MOUSE_MODE_CONFINED)     # visible but stays inside window
Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)      # normal
```

## 3 · InputEvent System

### 3.1 · Event type hierarchy

Every physical input generates an `InputEvent` subclass and routes it through the
 scene tree. Knowing which class to cast to tells you which properties are available:

| Class | Key properties | Typical source |
| --- | --- | --- |
| `InputEventKey` | `keycode`, `physical_keycode`, `pressed`, `echo`, `shift_pressed`, `ctrl_pressed` | Keyboard |
| `InputEventMouseButton` | `button_index`, `pressed`, `double_click`, `position`, `factor` (scroll) | Mouse clicks, scroll wheel |
| `InputEventMouseMotion` | `relative`, `velocity`, `position`, `button_mask` | Mouse move / drag |
| `InputEventJoypadButton` | `button_index`, `pressed`, `device` | Gamepad button |
| `InputEventJoypadMotion` | `axis`, `axis_value`, `device` | Gamepad stick or trigger |
| `InputEventScreenTouch` | `index` (finger id), `position`, `pressed` | Touchscreen tap |
| `InputEventScreenDrag` | `index`, `position`, `relative`, `velocity` | Touchscreen drag |
| `InputEventAction` | `action`, `pressed`, `strength` | Synthetic / scripted actions |
| `InputEventMIDI` | `message`, `pitch`, `velocity`, `channel` | MIDI device |

InputEvent

InputEventKey

keycode / echo

InputEventMouse

(base class)

…Button

…Motion

…Joypad…

Button / Motion

…Screen…

Touch / Drag

…Action

action + strength

Cast with

if event is InputEventKey:

to access subclass properties

InputEvent class hierarchy. Use `is` to check the concrete type before casting — e.g. `if event is InputEventJoypadMotion: var motion := event as InputEventJoypadMotion`.

### 3.2 · \_input vs \_unhandled\_input vs \_shortcut\_input

| Method | Called when | Typical use |
| --- | --- | --- |
| `_input(event)` | Every InputEvent, before GUI | Global shortcuts, debug keys — runs even when a Control is focused |
| `_shortcut_input(event)` | After `_input`, before GUI, keyboard/joypad only | Keyboard shortcuts that should not fire when typing in a LineEdit |
| `_unhandled_input(event)` | Only if no GUI node consumed the event | Gameplay input — the right choice for most game actions |
| `_unhandled_key_input(event)` | Same as above but only keyboard events | Global key shortcuts that shouldn't fire during text input |

```gdscript

extends CharacterBody2D

func _unhandled_input(event: InputEvent) -> void:
    # Jump on just-pressed — correct choice: won't fire if clicking a UI button
    if event.is_action_pressed("jump"):
        velocity.y = -JUMP_SPEED

func _input(event: InputEvent) -> void:
    # Screenshot key — always active regardless of UI focus
    if event is InputEventKey and event.keycode == KEY_F12 and event.pressed:
        get_viewport().get_texture().get_image().save_png("user://screenshot.png")
        get_viewport().set_input_as_handled()   # stop propagation
```

### 3.3 · Consuming (stopping) events

Call `get_viewport().set_input_as_handled()` inside any of the four input methods to
 stop the event propagating further. GUI `Control` nodes do this automatically when
 they process a click or keypress — that's why `_unhandled_input` doesn't fire for
 button clicks.

```gdscript

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton \
       and event.button_index == MOUSE_BUTTON_RIGHT \
       and event.pressed:
        open_context_menu(event.position)
        get_viewport().set_input_as_handled()   # prevent other nodes responding
```

### 3.4 · Simulating input in code

You can fire synthetic input events — useful for automated tests or for triggering mapped
 actions from scripts (e.g. an on-screen button that acts like pressing a key):

```gdscript

# Fire a synthetic "jump" action press
func simulate_jump() -> void:
    var ev := InputEventAction.new()
    ev.action  = &"jump"
    ev.pressed = true
    Input.parse_input_event(ev)
```

## 4 · Touch & Mobile

### 4.1 · Touch events

Godot maps single-finger touch to mouse events by default
 (*Project Settings → Input Devices → Pointing → Emulate Mouse From Touch*).
 For multi-touch or fine control, handle `InputEventScreenTouch` and
 `InputEventScreenDrag` directly:

```gdscript

extends Node2D

var _touches: Dictionary = {}   # finger_id → last position

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _touches[event.index] = event.position
        else:
            _touches.erase(event.index)

    elif event is InputEventScreenDrag:
        _touches[event.index] = event.position

func get_touch_count() -> int:
    return _touches.size()

func get_touch_position(index: int) -> Vector2:
    return _touches.get(index, Vector2.ZERO)
```

### 4.2 · Virtual joystick pattern

A virtual joystick translates touch drag into action strengths so the rest of your code
 can use the same `Input.get_vector()` calls regardless of platform:

```gdscript

extends Control   # a full-screen transparent Control at the bottom of the CanvasLayer

const DEAD_RADIUS  := 20.0
const MAX_RADIUS   := 80.0

var _origin:    Vector2 = Vector2.ZERO
var _touch_id:  int     = -1
var _direction: Vector2 = Vector2.ZERO

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _touch_id == -1 and event.position.x < get_viewport_rect().size.x / 2.0:
            _touch_id = event.index
            _origin   = event.position
        elif not event.pressed and event.index == _touch_id:
            _touch_id  = -1
            _direction = Vector2.ZERO
            _update_actions(Vector2.ZERO)

    elif event is InputEventScreenDrag and event.index == _touch_id:
        var delta := event.position - _origin
        _direction = delta.limit_length(MAX_RADIUS) / MAX_RADIUS
        if delta.length() < DEAD_RADIUS:
            _direction = Vector2.ZERO
        _update_actions(_direction)

func _update_actions(dir: Vector2) -> void:
    # Inject synthetic InputEventActions so gameplay code stays platform-agnostic
    for action_name in ["move_left", "move_right", "move_up", "move_down"]:
        var ev  := InputEventAction.new()
        ev.action   = action_name
        ev.strength = 0.0
        ev.pressed  = false
        Input.parse_input_event(ev)

    var pairs := [["move_left", -dir.x], ["move_right", dir.x],
                  ["move_up",  -dir.y],  ["move_down",  dir.y]]
    for pair in pairs:
        if pair[1] > 0.0:
            var ev := InputEventAction.new()
            ev.action   = pair[0]
            ev.strength = pair[1]
            ev.pressed  = true
            Input.parse_input_event(ev)
```

## 5 · Controller & Gamepad

### 5.1 · Device connection detection

```gdscript

extends Node

func _ready() -> void:
    Input.joy_connection_changed.connect(_on_joy_connection_changed)
    # List already-connected devices
    for id in Input.get_connected_joypads():
        print("Gamepad %d: %s" % [id, Input.get_joy_name(id)])

func _on_joy_connection_changed(device: int, connected: bool) -> void:
    if connected:
        print("Gamepad connected: device %d — %s" % [device, Input.get_joy_name(device)])
    else:
        print("Gamepad disconnected: device %d" % device)
```

### 5.2 · Deadzones and axis reading

Godot applies action deadzones automatically for `get_action_strength()` and
 `get_vector()`. You set the deadzone per-action in the Input Map editor.
 If you need raw axis values (for visualising stick position, or implementing your own deadzone):

```gdscript

# Raw axis value — no deadzone applied, -1.0 to +1.0
var raw_x := Input.get_joy_axis(0, JOY_AXIS_LEFT_X)
var raw_y := Input.get_joy_axis(0, JOY_AXIS_LEFT_Y)

# Right trigger (0.0 to 1.0)
var trigger := Input.get_joy_axis(0, JOY_AXIS_TRIGGER_RIGHT)

# Common axis constants:
# JOY_AXIS_LEFT_X / LEFT_Y   — left stick
# JOY_AXIS_RIGHT_X / RIGHT_Y — right stick
# JOY_AXIS_TRIGGER_LEFT / TRIGGER_RIGHT — triggers

# Custom circular deadzone for smoother feel:
func apply_deadzone(raw: Vector2, dead: float = 0.15) -> Vector2:
    if raw.length() < dead:
        return Vector2.ZERO
    return (raw - raw.normalized() * dead) / (1.0 - dead)
```

### 5.3 · Rumble / haptic feedback

```gdscript

# Rumble device 0: weak motor (high freq), strong motor (low freq), duration seconds
Input.start_joy_vibration(0, 0.3, 0.8, 0.4)   # moderate buzz for 0.4 s
Input.stop_joy_vibration(0)                     # stop immediately

# Typical game events:
func on_player_hit() -> void:
    Input.start_joy_vibration(0, 0.0, 1.0, 0.3)   # strong thud

func on_ui_hover() -> void:
    Input.start_joy_vibration(0, 0.2, 0.0, 0.06)  # gentle tick
```

:::callout-warning
⚠️ Rumble on web exports

The Gamepad API rumble support varies by browser.  Call

Input.start\_joy\_vibration()

normally — Godot silently ignores it if the
        platform doesn't support it.
:::

### 5.4 · Device-agnostic button icons

A prompt that says “press button 0” is useless. The player needs to see the
 label their own controller has printed on it, and that label differs by brand: the
 bottom face button is Cross on a Sony pad, A on an Xbox pad, and B on a Nintendo one.

Every input event can describe itself. `InputEvent.as_text()` returns a
 string that already names all three conventions:

```gdscript

func jump_button_label() -> String:
    for ev in InputMap.action_get_events("jump"):
        if ev is InputEventJoypadButton:
            return ev.as_text()
    return ""   # no gamepad binding found
```

With the jump action bound to `JOY_BUTTON_A`, that returns:

```text
Joypad Button 0 (Bottom Action, Sony Cross, Xbox A, Nintendo B)
```

That is the whole answer for a debug readout, and too much for a HUD. To pick one
 name — or one icon — you need to know which controller is plugged in, and
 `Input.get_joy_name()` reports that:

```gdscript

func controller_brand(device: int = 0) -> String:
    var name := Input.get_joy_name(device).to_lower()
    if name.contains("sony") or name.contains("playstation") or name.contains("dualsense"):
        return "sony"
    if name.contains("nintendo") or name.contains("switch"):
        return "nintendo"
    return "xbox"
```

:::callout-warning[Warning]
get\_joy\_name()

returns an empty string when no controller is connected on
        that device index, so

controller\_brand()

falls through to

"xbox"

. That is the right default — it matches the layout Godot
        reports its button constants against — but if you are showing an icon rather than
        a word, check

Input.get\_connected\_joypads()

first and show the keyboard
        binding when the list is empty.
:::

## Summary

| Concept | Key takeaway |
| --- | --- |
| **InputMap** | Defines action names → physical inputs; rebind at runtime with `action_erase_events / action_add_event` |
| **Input.get\_vector()** | Normalized 2D directional input — preferred over combining four boolean checks |
| **is\_action\_just\_pressed()** | True for exactly one frame — use for one-shot actions (jump, shoot) |
| **\_unhandled\_input()** | Correct callback for gameplay — skips events consumed by UI |
| **InputEventMouseMotion.relative** | Delta pixels since last event — use for camera look, not absolute position |
| **Touch → Actions** | Inject `InputEventAction` from touch handlers so gameplay logic stays platform-agnostic |
| **Gamepad device index** | Always pass the device index (0 for first controller); detect connections via `Input.joy_connection_changed` |
| **Mouse modes** | CAPTURED locks cursor to center (FPS); restore VISIBLE on pause/menu |

- Poll in `_physics_process()` for movement; use `_unhandled_input()` for discrete events.
- Never hard-code keycodes — bind them in the InputMap and query by action name.
- Use `get_viewport().set_input_as_handled()` to stop event propagation when your node has consumed it.
- Test controller support early — joystick axis drift and deadzone issues are easier to fix before shipping.
- Use `Input.MOUSE_MODE_CAPTURED` for FPS; always restore `VISIBLE` on pause/menu.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Movement with get\_vector

Write a `_physics_process` for a top-down `CharacterBody2D` that moves
 at `200 px/s` using the four actions `move_left`, `move_right`,
 `move_up`, `move_down`. The character must *not* move faster
 diagonally than cardinally.

::::solution[Solution]
```gdscript

extends CharacterBody2D
const SPEED := 200.0

func _physics_process(_delta: float) -> void:
    velocity = Input.get_vector("move_left", "move_right", "move_up", "move_down") * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · FPS mouse look

In a 3D scene, write the mouse look code for an FPS character. The horizontal delta should
 rotate the character body's Y axis; the vertical delta should rotate a `$Camera3D`
 child's X axis, clamped to ±80°. Capture the mouse on `_ready()` and release it
 when Escape is pressed.

::::solution[Solution]
```gdscript

extends CharacterBody3D

const SENSITIVITY := 0.003

@onready var camera: Camera3D = $Camera3D

func _ready() -> void:
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * SENSITIVITY)
        camera.rotate_x(-event.relative.y * SENSITIVITY)
        camera.rotation.x = clampf(camera.rotation.x, -PI * 0.44, PI * 0.44)

    if event is InputEventKey and event.keycode == KEY_ESCAPE and event.pressed:
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Key rebinding screen

Build a single-action rebinding UI. A `Button` shows the current binding for
 the `"attack"` action. When clicked, it enters listening mode (changes text to
 "Press any key…") and the next `InputEventKey` replaces the binding. Save the
 new binding to `user://bindings.cfg` via `ConfigFile` and reload it on
 startup.

::::solution[Solution]
```gdscript

extends Control

const CFG_PATH := "user://bindings.cfg"
const ACTION   := &"attack"

@onready var btn: Button = $RebindButton
var _listening := false

func _ready() -> void:
    _load_bindings()
    _update_label()

func _update_label() -> void:
    var events := InputMap.action_get_events(ACTION)
    btn.text = events[0].as_text() if events.size() > 0 else "(none)"

func _on_rebind_button_pressed() -> void:
    _listening = true
    btn.text   = "Press any key…"

func _input(event: InputEvent) -> void:
    if not _listening:
        return
    if event is InputEventKey and event.pressed and not event.echo:
        _listening = false
        InputMap.action_erase_events(ACTION)
        InputMap.action_add_event(ACTION, event)
        _update_label()
        _save_bindings()
        get_viewport().set_input_as_handled()

func _save_bindings() -> void:
    var cfg := ConfigFile.new()
    for ev in InputMap.action_get_events(ACTION):
        cfg.set_value("bindings", ACTION, ev.as_text())
    cfg.save(CFG_PATH)

func _load_bindings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(CFG_PATH) != OK:
        return
    var text: String = cfg.get_value("bindings", ACTION, "")
    if text == "":
        return
    # Rebuild InputEventKey from keycode string — simplified approach
    var ev := InputEventKey.new()
    ev.keycode = OS.find_keycode_from_string(text)
    if ev.keycode != KEY_NONE:
        InputMap.action_erase_events(ACTION)
        InputMap.action_add_event(ACTION, ev)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Scroll-wheel zoom

A top-down camera (`Camera2D`) should zoom in and out when the player scrolls the
 mouse wheel. Clamp zoom between 0.5× and 3×. Smoothly lerp toward the target zoom
 each frame rather than jumping.

::::solution[Solution]
```gdscript

extends Camera2D

const ZOOM_STEP  := 0.15
const ZOOM_MIN   := 0.5
const ZOOM_MAX   := 3.0
const ZOOM_SPEED := 8.0

var _target_zoom := 1.0

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            _target_zoom = clampf(_target_zoom + ZOOM_STEP, ZOOM_MIN, ZOOM_MAX)
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            _target_zoom = clampf(_target_zoom - ZOOM_STEP, ZOOM_MIN, ZOOM_MAX)

func _process(delta: float) -> void:
    var z := lerpf(zoom.x, _target_zoom, ZOOM_SPEED * delta)
    zoom = Vector2(z, z)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Gamepad connect / disconnect UI

Show a "Controller connected" banner for 2 seconds when a gamepad is plugged in, and a
 "Controller disconnected — switching to keyboard" banner when one is unplugged. Use a
 `Label` that fades out with a Tween.

::::solution[Solution]
```gdscript

extends CanvasLayer

@onready var banner: Label = $Banner

func _ready() -> void:
    banner.modulate.a = 0.0
    Input.joy_connection_changed.connect(_on_joy_changed)

func _on_joy_changed(device: int, connected: bool) -> void:
    if connected:
        banner.text = "Controller connected: %s" % Input.get_joy_name(device)
    else:
        banner.text = "Controller disconnected — switching to keyboard"
    _show_banner()

func _show_banner() -> void:
    var tw := create_tween()
    tw.tween_property(banner, "modulate:a", 1.0, 0.2)
    tw.tween_interval(2.0)
    tw.tween_property(banner, "modulate:a", 0.0, 0.5)
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Full input manager with per-player controller assignment

Build an `InputManager` autoload that supports up to 4 local players.
 It should:

- Track which device index (0 = keyboard, 1–4 = gamepads) is assigned to each player slot.
- Expose `get_vector(player: int, neg_x, pos_x, neg_y, pos_y) → Vector2` that reads
 from the correct device for that player.
- Expose `is_action_just_pressed(player: int, action: StringName) → bool`.
- Auto-assign the first unassigned gamepad when it connects.
- On gamepad disconnect, free that player slot.

::::solution[Solution]
```gdscript

# InputManager.gd — Autoload
extends Node

# player_devices[player_index] = device_id  (0 = keyboard, ≥1 = joypad device)
var player_devices: Array[int] = [-1, -1, -1, -1]   # -1 = unassigned

func _ready() -> void:
    player_devices[0] = 0   # player 0 always gets keyboard
    Input.joy_connection_changed.connect(_on_joy_changed)

func _on_joy_changed(device: int, connected: bool) -> void:
    if connected:
        # Assign to first open slot (skip slot 0 — keyboard)
        for i in range(1, 4):
            if player_devices[i] == -1:
                player_devices[i] = device
                print("Player %d → gamepad device %d" % [i, device])
                break
    else:
        for i in range(4):
            if player_devices[i] == device:
                player_devices[i] = -1
                print("Player %d gamepad disconnected" % i)

func get_vector(player: int, neg_x: StringName, pos_x: StringName,
                neg_y: StringName, pos_y: StringName) -> Vector2:
    var dev := player_devices[player]
    if dev < 0:
        return Vector2.ZERO
    if dev == 0:
        return Input.get_vector(neg_x, pos_x, neg_y, pos_y)
    # For gamepad, build vector from axis directly
    var lx := Input.get_joy_axis(dev, JOY_AXIS_LEFT_X)
    var ly := Input.get_joy_axis(dev, JOY_AXIS_LEFT_Y)
    return Vector2(lx, ly)

func is_action_just_pressed(player: int, action: StringName) -> bool:
    var dev := player_devices[player]
    if dev < 0:
        return false
    # Action check includes device filtering via event device property
    for ev in InputMap.action_get_events(action):
        if ev is InputEventJoypadButton:
            if Input.is_joy_button_pressed(dev, ev.button_index):
                return true   # simplified: use full event system for just_pressed tracking
        elif dev == 0:
            return Input.is_action_just_pressed(action)
    return false
```
::::
:::
