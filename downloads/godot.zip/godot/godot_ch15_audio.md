---
title: "Audio — Players, Buses & Dynamic Music"
source: "godot_ch15_audio.html"
---

Part III · Chapter 15

# Audio — Players, Buses & Dynamic Music

Prerequisite: Chapters 12 (Autoloads) and 14 (Animation / Tween) · est. 85 min

## Overview

Godot's audio system is built around three independent layers that compose cleanly:

- **AudioStreamPlayer nodes** — source playback objects you add to scenes, analogous to speakers.
 There are three variants: a global one, a 2D positional one, and a 3D spatial one.
- **Audio Bus Layout** — a mixer that every player routes into. Buses can have effects
 (reverb, compressor, EQ), they can route into each other, and you can adjust them at runtime.
- **Dynamic music systems** — patterns you build in GDScript on top of the player and bus
 primitives: cross-fading tracks, stem mixing, adaptive music that responds to game state.

Understanding how these layers interact lets you build everything from a simple sound effect fire-and-forget
 call to a full adaptive soundtrack with per-environment reverb zones.

⬡ — AudioStreamPlayer — inherits Node (non-positional)

Plays audio with no spatial position — the sound is heard at the same volume and centre-panned regardless of where anything is in the scene. This makes it the right choice for background music, UI sound effects, narrator voice-over, and any audio that should feel "outside" the game world rather than anchored to an object in it.

| Property | Default | What it does |
| --- | --- | --- |
| stream | null | The AudioStream resource to play — drag in an .ogg, .mp3, or .wav file from FileSystem |
| volume\_db | 0 dB | Playback volume in decibels. 0 = original; −6 dB ≈ half perceived loudness; −80 dB ≈ silent |
| pitch\_scale | 1.0 | Playback pitch multiplier. 2.0 = one octave up; 0.5 = one octave down. Randomise per-play for variety |
| playing | false | Read-only in the Inspector; set `play()` / `stop()` in code. True when audio is currently playing |
| autoplay | false | Starts playing automatically when the node enters the scene tree — perfect for ambient music |
| stream\_paused | false | Pauses playback mid-stream without resetting position — resume with `stream_paused = false` |
| max\_polyphony | 1 | How many simultaneous instances can play at once. Raise to 4–8 for sounds triggered rapidly |
| bus | "Master" | Which audio bus to route this player through — use separate Music and SFX buses for independent volume control |
| mix\_target | STEREO | STEREO outputs normally; SURROUND\_51 / SURROUND\_71 sends to specific speaker channels for surround setups |

Use when:

the sound has no spatial origin — background music, menu clicks, UI notifications, voice-over, game-over stings.

Prefer AudioStreamPlayer2D when:

the sound should feel like it comes from a 2D world position (enemy footsteps, a waterfall, a door).

Prefer AudioStreamPlayer3D when:

working in a 3D scene with spatial audio.

Polyphony tip:

one AudioStreamPlayer with

max\_polyphony = 8

is more efficient than 8 separate nodes for the same sound.

## 1 · AudioStreamPlayer Nodes

### 1.1 · Three variants compared

| Node | When to use | Key extra properties |
| --- | --- | --- |
| `AudioStreamPlayer` | UI sounds, music, any non-positional SFX | `volume_db`, `pitch_scale`, `bus`, `mix_target` |
| `AudioStreamPlayer2D` | 2D world sounds — volume falls off with camera distance | + `max_distance`, `attenuation`, `area_mask` |
| `AudioStreamPlayer3D` | 3D world sounds — full panning, Doppler, environment reverb | + `unit_size`, `max_db`, `doppler_tracking`, `emission_angle_degrees` |

### 1.2 · Playback API

```gdscript

@onready var sfx: AudioStreamPlayer = $SFX

func _ready() -> void:
    sfx.play()                    # play from start
    sfx.play(0.5)                 # play from 0.5 s offset
    sfx.stop()
    sfx.seek(1.2)                 # jump to timestamp while already playing
    print(sfx.get_playback_position())  # current position in seconds

# Properties you can set at runtime:
sfx.volume_db   = -6.0   # attenuate 6 dB
sfx.pitch_scale = 1.2    # 20% higher pitch (speeds up playback)
sfx.bus         = &"SFX" # route to a different bus
sfx.stream      = load("res://audio/explosion.ogg") as AudioStream
```

`volume_db` is in *decibels* — 0 dB is full volume, -6 dB is roughly half perceived
 loudness, -∞ (i.e. very negative) is silence. Use `linear_to_db()` and
 `db_to_linear()` when you need to convert between a 0–1 slider and dB.

```gdscript

# Slider value 0.0–1.0 → dB
func _on_volume_slider_changed(value: float) -> void:
    $Music.volume_db = linear_to_db(value)
```

:::callout-tip
💡 Pitch randomisation for juicy SFX

Playing the same sound at a slightly random pitch prevents repetition fatigue.

player.pitch\_scale = randf\_range(0.9, 1.1)

before every

play()

call
        is a 1-line upgrade to any SFX.
:::

### 1.3 · AudioStream types

| Resource | Purpose | Key properties |
| --- | --- | --- |
| `AudioStreamOggVorbis` | Compressed music/long audio — streaming from disk | `loop`, `loop_offset` |
| `AudioStreamMP3` | Compressed audio (higher CPU than OGG) | `loop`, `loop_offset` |
| `AudioStreamWAV` | Uncompressed PCM — best for short SFX (lowest latency) | `loop_mode`, `mix_rate` |
| `AudioStreamRandomizer` | Randomly picks from a pool of streams each play() | `streams` array, `random_pitch`, `random_volume_offset_db` |
| `AudioStreamPolyphonic` | Lets one player play multiple overlapping streams simultaneously | Use `get_stream_playback()` → `play_stream()` |

### 1.4 · AudioStreamRandomizer in practice

```gdscript

# In the Inspector: set the stream property of AudioStreamPlayer to
# an AudioStreamRandomizer resource containing several footstep WAVs.
# Then just:
func _on_footstep_frame() -> void:
    $FootstepPlayer.play()
# The Randomizer picks a random stream (with optional pitch/volume variation)
# automatically — no extra GDScript needed.
```

### 1.5 · AudioStreamPolyphonic — multiple simultaneous sounds

```gdscript

# One AudioStreamPlayer whose stream = AudioStreamPolyphonic
@onready var poly_player: AudioStreamPlayer = $PolyPlayer
var _playback: AudioStreamPlaybackPolyphonic

func _ready() -> void:
    poly_player.play()
    _playback = poly_player.get_stream_playback() as AudioStreamPlaybackPolyphonic

func play_hit(stream: AudioStream, vol_db: float = 0.0) -> void:
    _playback.play_stream(stream, 0.0, vol_db)  # from, volume_db
```

## 2 · Audio Bus Layout

Every sound passes through the **Audio Bus Layout** before reaching the hardware.
 Open it with **Audio** at the bottom of the Godot editor. The default project has a
 single *Master* bus. You add buses — SFX, Music, Ambience, Voice — assign effects to them,
 and route player nodes into them via the `bus` property.

### 2.1 · Bus routing

Each bus has a **Send** dropdown that defines which bus it feeds into. A typical layout:

```gdscript

# Topology (editor, not code):
# Master  ← Music
#         ← SFX   ← 3D_SFX
#         ← Voice
#
# "SFX" and "Music" send to "Master".
# "3D_SFX" sends to "SFX" (so it inherits the SFX compressor).










          Master
          → sound card


          Music
          + Compressor


          SFX
          + Limiter


          Voice
          + EQ


          3D_SFX






          send → Master
          send
          send → Master
          send → SFX


          A typical audio bus topology. AudioStreamPlayers set their Bus property to Music, SFX, or Voice. 3D_SFX routes through SFX so it inherits the SFX Limiter automatically.


```

:::callout-tip
💡 Save the bus layout as a resource

Go to

Audio > Save

and save the layout as

res://audio/bus\_layout.tres

.
        Load it at runtime with

AudioServer.set\_bus\_layout(load("res://audio/bus\_layout.tres"))

to swap the entire mixer — useful for swapping between a "game" and "menu" layout.
:::

### 2.2 · AudioEffect chain

Click the **+** button on a bus to add effects. Effects process audio in order, top to bottom.

| Effect | Use case | Key parameters |
| --- | --- | --- |
| `AudioEffectReverb` | Room ambience, cave echo | `room_size`, `dry`, `wet`, `predelay_msec` |
| `AudioEffectDelay` | Echo, stereo slap-back | `tap1_delay_ms`, `tap1_level_db`, `tap1_pan` |
| `AudioEffectCompressor` | Tame loud peaks, glue mix | `threshold`, `ratio`, `attack_us`, `release_ms` |
| `AudioEffectLimiter` | Prevent clipping on Master bus | `ceiling_db`, `threshold_db` |
| `AudioEffectEQ` | EQ6 / EQ10 / EQ21 frequency shaping | Per-band gain in dB |
| `AudioEffectChorus` | Widen/thicken sounds | `voice_count`, `depth`, `rate` |
| `AudioEffectDistortion` | Gritty electric sound | `mode`, `drive`, `pre_gain` |
| `AudioEffectPitchShift` | Pitch-correct without timing change | `pitch_scale`, `fft_size` |
| `AudioEffectRecord` | Capture bus output to WAV | `format` — start/stop via `set_recording_active()` |

### 2.3 · Controlling buses in code

All bus manipulation goes through the `AudioServer` singleton:

```gdscript

# Volume
var bus_idx := AudioServer.get_bus_index("Music")
AudioServer.set_bus_volume_db(bus_idx, -6.0)

# Mute / solo
AudioServer.set_bus_mute(bus_idx, true)
AudioServer.set_bus_solo(bus_idx, true)

# Modify an effect at runtime
var reverb := AudioServer.get_bus_effect(bus_idx, 0) as AudioEffectReverb
if reverb:
    reverb.wet = 0.6   # increase wetness in a cave zone

# Add / remove effects at runtime
var comp := AudioEffectCompressor.new()
comp.threshold = -12.0
AudioServer.add_bus_effect(bus_idx, comp)
AudioServer.remove_bus_effect(bus_idx, 0)   # index of effect to remove
```

:::callout-warning
⚠️ Bus index is not stable

get\_bus\_index("Music")

is cheap — call it instead of caching the integer,
        because bus indices can change if buses are added or removed at runtime.
:::

## 3 · Positional Audio

⬡ — AudioStreamPlayer2D — inherits Node2D

Emits audio from a point in 2D space, with volume and panning automatically calculated based on distance to the listener (the nearest AudioListener2D or Camera2D viewport centre). Place it on an enemy, a waterfall, a door — the player hears sounds get louder as they approach and panned left/right based on direction.

| Property | Default | What it does |
| --- | --- | --- |
| stream | null | The AudioStream resource to play |
| max\_distance | 2000 px | Distance in pixels beyond which the sound is completely silent |
| attenuation | 1.0 | Falloff curve exponent — higher = steeper dropoff, sound carries less far |
| volume\_db | 0 dB | Base volume before distance attenuation. 0 dB = full volume |
| pitch\_scale | 1.0 | Playback pitch multiplier — 1.5 = 50% higher pitch. Randomise per-play for natural variation |
| max\_polyphony | 1 | Maximum simultaneous plays — increase for rapid-fire sounds like footsteps |
| bus | "Master" | Audio bus to route through; use a dedicated SFX bus with reverb/limiter effects |
| area\_mask | 1 | Which Area2D audio override zones (reverb, bus redirect) affect this player |

Use when:

a sound in a 2D game should feel spatially located — enemy footsteps, environmental ambience, pickups, explosions tied to world objects.

Prefer AudioStreamPlayer (no suffix) when:

the sound has no world position — background music, UI sounds, global notifications.

Tip:

set

max\_polyphony = 4

on frequently triggered sounds so rapid events (footsteps, bullet hits) overlap naturally instead of cutting off.

### 3.1 · AudioStreamPlayer2D attenuation

An `AudioStreamPlayer2D` emits from its 2D position. Godot calculates pan and volume
 based on the distance from the **AudioListener2D** (the camera, by default).

```gdscript

# Emit an explosion at a world position without a persistent node
func play_at(stream: AudioStream, pos: Vector2) -> void:
    var player := AudioStreamPlayer2D.new()
    player.stream        = stream
    player.max_distance  = 800.0          # audible within 800 px
    player.attenuation   = 1.0            # linear falloff
    player.bus           = &"SFX"
    player.finished.connect(player.queue_free)
    add_child(player)
    player.global_position = pos
    player.play()
```

### 3.2 · Area2D reverb / audio zones

Add an `Area2D` node, tick **Audio > Override Audio Bus** in the inspector,
 and set the target bus (e.g. *Cave*) and reverb amount. Any
 `AudioStreamPlayer2D` whose emitter is inside the area will have that bus and reverb
 applied automatically — no scripting required.

```gdscript

# To do the same thing from code:
var zone := $CaveArea2D
zone.audio_bus_override  = true
zone.audio_bus_name      = &"Cave"
zone.reverb_bus_enable   = true
zone.reverb_bus_name     = &"Cave"
zone.reverb_bus_amount   = 0.8   # 0–1 wet amount
zone.reverb_bus_uniformity = 0.5
```

⬡ — AudioStreamPlayer3D — inherits Node3D

Emits audio from a point in 3D space. The listener (the Camera3D's viewport) hears volume drop off with distance and panning shifts based on direction — creating the illusion of a sound source existing somewhere in the 3D world. Essential for footsteps, gunshots, ambient world sounds, and any audio that should feel spatially anchored.

| Property | Default | What it does |
| --- | --- | --- |
| stream | null | The AudioStream resource to play — MP3, OGG Vorbis, or WAV |
| unit\_size | 10.0 | Distance in world units where volume halves. Smaller = drops off faster (intimate sounds). Larger = carries further (explosions, music) |
| max\_distance | 0 (infinite) | Hard cutoff distance — sound is completely silent beyond this. 0 = no cutoff |
| attenuation\_model | INVERSE\_DISTANCE | How volume falls off: INVERSE (physically correct), INVERSE\_SQUARE (more dramatic), LINEAR (constant dropoff), DISABLED (no distance falloff) |
| max\_polyphony | 1 | How many simultaneous instances of this stream can play; raise for sounds triggered rapidly (footsteps) |
| bus | "Master" | Which audio bus to route through — allows per-category effects (reverb on SFX bus) |
| emission\_angle\_enabled | false | Restrict the sound to a cone; sounds outside the cone are attenuated |
| doppler\_tracking | DISABLED | IDLE or PHYSICS enables Doppler pitch shift as the source/listener moves — great for vehicles |
| area\_mask | 1 | Which Area3D reverb bus zones this player is affected by |

Use when:

any sound should appear to come from a physical location in 3D space — footsteps, gunshots, NPC speech, ambient world sounds, exploding objects.

Prefer AudioStreamPlayer (no suffix) when:

the sound has no world position — music, UI clicks, narrator voice-over.

Prefer AudioStreamPlayer2D when:

working in a 2D game scene.

### 3.3 · 3D spatial audio

`AudioStreamPlayer3D` uses the same API as 2D but adds panning, Doppler shift, and
 an emission angle for directional sounds. Make sure your scene has an
 `AudioListener3D` on (or under) the active camera.

```gdscript

# Helicopter flying past — enable Doppler
var heli: AudioStreamPlayer3D = $Helicopter/EngineSound
heli.doppler_tracking = AudioStreamPlayer3D.DOPPLER_TRACKING_PHYSICS_STEP
heli.unit_size        = 5.0    # reference distance for attenuation
heli.max_db           = 0.0    # maximum volume at zero distance

# Directional muzzle flash — louder in front, quieter behind
var gun: AudioStreamPlayer3D = $Gun/ShotSound
gun.emission_angle_enabled = true
gun.emission_angle_degrees = 60.0     # audible full-volume within ±60°
gun.emission_angle_filter_attenuation_db = -12.0  # off-axis attenuation
```

## 4 · Dynamic Music

Static looping tracks get repetitive quickly. Dynamic music systems adapt to game state:
 layering in intensity stems during combat, cross-fading between zone tracks, or smoothly blending
 down when a cutscene starts. Godot gives you all the primitives — you compose the system in GDScript.

### 4.1 · Cross-fading between tracks

The simplest dynamic music pattern: two `AudioStreamPlayer` nodes (A and B).
 To switch tracks, fade out A while fading in B, then stop A.

```gdscript

extends Node

@onready var player_a: AudioStreamPlayer = $MusicA
@onready var player_b: AudioStreamPlayer = $MusicB
var _active: AudioStreamPlayer    # which player is currently audible

func _ready() -> void:
    _active = player_a

func play_track(stream: AudioStream, fade_time: float = 1.5) -> void:
    var incoming := player_b if _active == player_a else player_a
    incoming.stream   = stream
    incoming.volume_db = -80.0   # start silent
    incoming.play()

    var tw := create_tween().set_parallel(true)
    tw.tween_property(_active,  "volume_db", -80.0, fade_time)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
    tw.tween_property(incoming, "volume_db",   0.0, fade_time)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

    await tw.finished
    _active.stop()
    _active = incoming
```

### 4.2 · Stem mixing (layered adaptive music)

Stem mixing keeps multiple layers of the same track playing in sync, and fades layers in or out
 to reflect game state. All stems must be the exact same length and exported as separate files
 from your DAW. Start them simultaneously so they stay in sync forever.

```gdscript

extends Node

# Add four AudioStreamPlayer children named Base, Rhythm, Melody, Tension.
# Each has the corresponding stem loaded in its stream property.
@onready var stems: Dictionary = {
    "base"    : $Base,
    "rhythm"  : $Rhythm,
    "melody"  : $Melody,
    "tension" : $Tension,
}

func _ready() -> void:
    # Start all stems simultaneously — they stay in sync from here on
    for player: AudioStreamPlayer in stems.values():
        player.volume_db = -80.0   # muted initially
        player.play()
    # Always audible base layer
    _set_stem_volume("base", 0.0, 0.0)

func set_intensity(level: int) -> void:
    # level 0 = calm, 1 = alert, 2 = combat
    _set_stem_volume("rhythm",  0.0  if level >= 1 else -80.0)
    _set_stem_volume("melody",  0.0  if level >= 1 else -80.0)
    _set_stem_volume("tension", 0.0  if level >= 2 else -80.0)

func _set_stem_volume(stem: String, target_db: float, duration: float = 1.0) -> void:
    var player: AudioStreamPlayer = stems[stem]
    var tw := create_tween()
    tw.tween_property(player, "volume_db", target_db, duration)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```

### 4.3 · Beat-synced transitions

Abrupt mid-bar transitions sound jarring. Wait for the next bar boundary before switching:

```gdscript

const BPM        := 120.0
const BEATS_PER_BAR := 4

# Returns seconds until the next bar boundary from 'now'
func time_to_next_bar() -> float:
    var beat_duration  := 60.0 / BPM
    var bar_duration   := beat_duration * BEATS_PER_BAR
    var pos            := _active.get_playback_position()
    var bar_position   := fmod(pos, bar_duration)
    return bar_duration - bar_position

# Queue a cross-fade to start on the next bar
func play_track_synced(stream: AudioStream) -> void:
    var wait := time_to_next_bar()
    await get_tree().create_timer(wait).timeout
    play_track(stream, 0.05)   # very short fade — already on the beat
```

:::callout-tip
💡 AudioStreamOggVorbis loop points

In Godot's Import dock you can set a

Loop Offset

so the track loops back to bar 1
        rather than absolute position 0.  This lets you have a non-looping intro that plays once, then the
        main loop repeats from the correct bar — no script required.
:::

## 5 · AudioManager Autoload

Centralising audio in an autoload singleton means any scene can play a sound with a single call
 and you never have to drag audio nodes into every prefab.

### 5.1 · SFX pool

```gdscript

# AudioManager.gd — register as an Autoload named "AudioManager"
extends Node

const POOL_SIZE := 12

var _sfx_pool:  Array[AudioStreamPlayer]   = []
var _pool_idx:  int = 0

func _ready() -> void:
    for i in POOL_SIZE:
        var p := AudioStreamPlayer.new()
        p.bus = &"SFX"
        add_child(p)
        _sfx_pool.append(p)

# Play a one-shot SFX — round-robin pool to allow polyphony
func play_sfx(stream: AudioStream,
              vol_db: float = 0.0,
              pitch: float  = 1.0) -> void:
    var player := _sfx_pool[_pool_idx]
    _pool_idx = (_pool_idx + 1) % POOL_SIZE

    player.stream      = stream
    player.volume_db   = vol_db
    player.pitch_scale = pitch
    player.play()

# Pitch-randomised convenience wrapper
func play_sfx_vary(stream: AudioStream, vol_db: float = 0.0) -> void:
    play_sfx(stream, vol_db, randf_range(0.92, 1.08))
```

### 5.2 · Music system inside AudioManager

```gdscript

# Extend AudioManager.gd with music support

@onready var _music_a: AudioStreamPlayer = $MusicA
@onready var _music_b: AudioStreamPlayer = $MusicB
var _music_active: AudioStreamPlayer

func _ready() -> void:
    # (sfx pool setup from above...)
    _music_a.bus = &"Music"
    _music_b.bus = &"Music"
    _music_active = _music_a

func play_music(stream: AudioStream, fade: float = 1.5) -> void:
    if _music_active.stream == stream and _music_active.playing:
        return   # already playing this track — no-op

    var next := _music_b if _music_active == _music_a else _music_a
    next.stream    = stream
    next.volume_db = -80.0
    next.play()

    var tw := create_tween().set_parallel(true)
    tw.tween_property(_music_active, "volume_db", -80.0, fade)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
    tw.tween_property(next, "volume_db", 0.0, fade)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    await tw.finished
    _music_active.stop()
    _music_active = next

func stop_music(fade: float = 1.0) -> void:
    var tw := create_tween()
    tw.tween_property(_music_active, "volume_db", -80.0, fade)
    await tw.finished
    _music_active.stop()

func set_music_volume(linear: float) -> void:
    var bus_idx := AudioServer.get_bus_index("Music")
    AudioServer.set_bus_volume_db(bus_idx, linear_to_db(linear))
```

### 5.3 · Usage from any scene

```gdscript

# Any script, anywhere in the project:
AudioManager.play_sfx(preload("res://audio/sfx/coin.wav"))
AudioManager.play_sfx_vary(preload("res://audio/sfx/footstep_grass.wav"), -4.0)
AudioManager.play_music(preload("res://audio/music/dungeon_theme.ogg"))
AudioManager.stop_music(2.0)
```

:::callout-pitfall
🔴 Pitfall — preload vs load in loops

Always

preload()

audio resources at the top of your script (as constants or as

@export

variables filled in the Inspector).  Calling

load()

inside a
        hot path like

\_physics\_process

causes disk reads every frame, which causes audio
        stutter.
:::

## Summary

| Concept | Key takeaway |
| --- | --- |
| **AudioStreamPlayer variants** | Global for UI/music, 2D for world SFX with distance falloff, 3D for spatial games |
| **volume\_db** | In decibels — 0 = full, negative = quieter; use `linear_to_db()` for sliders |
| **AudioStreamRandomizer** | Automatic random pitch/stream selection — use for footsteps, impacts |
| **Audio Bus Layout** | Mixer with effect chains; control volume/mute/effects at runtime via `AudioServer` |
| **Area2D audio zones** | Override bus and reverb per region with zero scripting |
| **Cross-fade pattern** | Two players + Tween; always start incoming at -80 dB |
| **Stem mixing** | Start all stems simultaneously; fade volumes to layer/unlayer |
| **AudioManager autoload** | Pool of players for SFX polyphony; two players for music cross-fade |

- Keep the Master bus always at 0 dB; control overall loudness on child buses.
- Add an `AudioEffectLimiter` to Master to prevent clipping.
- Use `AudioStreamWAV` (uncompressed) for short SFX — lower latency than OGG/MP3.
- Use `AudioStreamOggVorbis` for music — compressed streaming avoids loading large files into RAM.
- Never call `load()` for audio in hot paths — `preload()` at script init instead.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Pitch-randomised coin SFX

A coin pickup node has an `AudioStreamPlayer` child called `$CoinSFX`.
 When `collect()` is called, play the sound at a random pitch between 0.95 and 1.15
 and then `queue_free()` the node after the sound finishes.

::::solution[Solution]
```gdscript

extends Area2D

@onready var sfx: AudioStreamPlayer = $CoinSFX

func collect() -> void:
    sfx.pitch_scale = randf_range(0.95, 1.15)
    sfx.play()
    # Detach from parent so queue_free on body doesn't cut the sound
    get_parent().remove_child(self)
    get_tree().root.add_child(self)
    sfx.finished.connect(queue_free)
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Volume slider wired to a bus

A settings screen has an `HSlider` (range 0–1) for music volume.
 Connect its `value_changed` signal so it adjusts the *Music* bus volume
 in decibels. When the slider is at 0, mute the bus entirely.

::::solution[Solution]
```gdscript

extends Control

func _on_music_slider_value_changed(value: float) -> void:
    var idx := AudioServer.get_bus_index("Music")
    if value <= 0.0:
        AudioServer.set_bus_mute(idx, true)
    else:
        AudioServer.set_bus_mute(idx, false)
        AudioServer.set_bus_volume_db(idx, linear_to_db(value))
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Footstep system using AudioStreamRandomizer

Build a reusable `FootstepComponent` node that:

- Exposes an `@export` property for the `AudioStreamRandomizer` resource.
- Exposes an `@export` float `step_distance` (default 60 px).
- Tracks the parent node's movement and plays the randomiser whenever the parent has
 moved `step_distance` pixels since the last step.

::::solution[Solution]
```gdscript

# FootstepComponent.gd — add as child of CharacterBody2D
extends Node

@export var footstep_sounds: AudioStreamRandomizer
@export var step_distance: float = 60.0

@onready var _player: AudioStreamPlayer = AudioStreamPlayer.new()
var _last_pos: Vector2
var _dist_acc: float = 0.0

func _ready() -> void:
    _player.stream = footstep_sounds
    _player.bus    = &"SFX"
    add_child(_player)
    _last_pos = get_parent().global_position

func _physics_process(_delta: float) -> void:
    var parent := get_parent() as CharacterBody2D
    if not parent or not parent.is_on_floor():
        return
    var moved := parent.global_position.distance_to(_last_pos)
    _dist_acc += moved
    _last_pos = parent.global_position
    if _dist_acc >= step_distance:
        _dist_acc = fmod(_dist_acc, step_distance)
        _player.play()
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Cave reverb zone

Your 2D world has underground cave sections. Create a setup where any
 `AudioStreamPlayer2D` that emits inside a cave `Area2D` gets routed to a
 *Cave* bus that has a large `AudioEffectReverb` applied. Write the code
 to configure the Area2D's audio override properties and to set up the reverb on the bus from
 an autoload — assume the bus already exists in the layout.

::::solution[Solution]
```gdscript

# In an autoload (e.g. AudioManager._ready):
func _setup_cave_bus() -> void:
    var idx := AudioServer.get_bus_index("Cave")
    # Clear any existing effects first
    while AudioServer.get_bus_effect_count(idx) > 0:
        AudioServer.remove_bus_effect(idx, 0)

    var reverb := AudioEffectReverb.new()
    reverb.room_size  = 0.9
    reverb.predelay_msec = 40.0
    reverb.wet        = 0.7
    reverb.dry        = 0.7
    AudioServer.add_bus_effect(idx, reverb)

# On the CaveArea2D node:
func _ready() -> void:
    audio_bus_override   = true
    audio_bus_name       = &"Cave"
    reverb_bus_enable    = true
    reverb_bus_name      = &"Cave"
    reverb_bus_amount    = 0.75
    reverb_bus_uniformity = 0.5
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Record and replay

Add an `AudioEffectRecord` to the *SFX* bus at index 0. Write two functions:
 `start_recording()` which activates it, and `stop_and_get_clip()` which
 deactivates it and returns the captured `AudioStreamWAV` so it can be played back
 or saved.

::::solution[Solution]
```gdscript

extends Node

var _rec_effect: AudioEffectRecord

func _ready() -> void:
    var idx := AudioServer.get_bus_index("SFX")
    _rec_effect = AudioServer.get_bus_effect(idx, 0) as AudioEffectRecord
    assert(_rec_effect != null, "No AudioEffectRecord at SFX bus index 0")

func start_recording() -> void:
    _rec_effect.set_recording_active(true)

func stop_and_get_clip() -> AudioStreamWAV:
    _rec_effect.set_recording_active(false)
    return _rec_effect.get_recording()
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Adaptive combat music with stems

Build a complete `MusicDirector` autoload that:

- Has four stem players (*Base*, *Rhythm*, *Melody*, *Tension*) all started simultaneously.
- Exposes `set_intensity(level: int)` (0 = calm, 1 = alert, 2 = combat).
- Uses a 0.5 s tween fade for each stem transition so changes aren't jarring.
- Exposes `change_track(stems: Dictionary)` that accepts a dictionary
 mapping stem names to `AudioStream` resources and hot-swaps all stems with a
 short cross-fade, keeping them in sync by starting them all at the current playback position
 of the base stem.

::::solution[Solution]
```gdscript

# MusicDirector.gd — register as Autoload
extends Node

const FADE := 0.5

var _players: Dictionary = {}   # name → AudioStreamPlayer

func _ready() -> void:
    for stem_name in ["base", "rhythm", "melody", "tension"]:
        var p := AudioStreamPlayer.new()
        p.bus        = &"Music"
        p.volume_db  = -80.0
        add_child(p)
        _players[stem_name] = p

func start(streams: Dictionary) -> void:
    # Load streams and play all from position 0 simultaneously
    for name in streams:
        _players[name].stream = streams[name]
    for p: AudioStreamPlayer in _players.values():
        p.play(0.0)
    # Base layer always audible
    _fade_stem("base", 0.0)

func set_intensity(level: int) -> void:
    _fade_stem("base",    0.0)
    _fade_stem("rhythm",  0.0  if level >= 1 else -80.0)
    _fade_stem("melody",  0.0  if level >= 1 else -80.0)
    _fade_stem("tension", 0.0  if level >= 2 else -80.0)

func change_track(streams: Dictionary) -> void:
    # Fade out all, swap streams at current position, fade back in
    var pos := (_players["base"] as AudioStreamPlayer).get_playback_position()
    var tw  := create_tween().set_parallel(true)
    for p: AudioStreamPlayer in _players.values():
        tw.tween_property(p, "volume_db", -80.0, FADE)
    await tw.finished

    for name in streams:
        _players[name].stream = streams[name]
    for p: AudioStreamPlayer in _players.values():
        p.play(pos)   # sync to the same position

    set_intensity(0)   # re-apply calm state; caller adjusts as needed

func _fade_stem(name: String, target_db: float) -> void:
    var tw := create_tween()
    tw.tween_property(_players[name], "volume_db", target_db, FADE)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```
::::
:::
