---
title: "Capstone — 2D Platformer"
source: "markdown"
---

Part V · Chapter 42A

★ CAPSTONE PROJECT

# Capstone — 2D Platformer

Integrates: Ch 7 (CharacterBody2D), Ch 8 (physics), Ch 11 (AnimationPlayer), Ch 28 (Tweens), Ch 35 (input) · est. 3–4 hours

## Overview

The 2D platformer is the genre that teaches movement craft. Getting
 a jump to feel good — responsive, weighty, with just the right amount
 of coyote time — requires careful tuning and a clean code structure
 that makes that tuning easy. This capstone builds a complete
 platformer prototype: a character that runs, jumps, wall-slides,
 dashes, and stomps enemies across a multi-section TileMap level.

What you will build:

- A `CharacterBody2D` player with precise
 run/jump/wall-slide/dash movement
- Coyote time and jump buffering for polished controls (Ch 35
 techniques applied to 2D platforming)
- A TileMap level with one-way platforms and spike hazards
- Collectible coins and a power-up that enables the dash
- A patrol-and-stomp enemy
- A lives system with checkpoint respawn
- CPU particles for dust and coin sparkle
- A parallax scrolling background

## 1 · Project Plan

### Scene layout

```text
res://
  scenes/
    player/
      player.tscn         ← CharacterBody2D, Sprite2D, AnimationPlayer
      player.gd
    enemies/
      walker.tscn          ← CharacterBody2D with patrol path
      walker.gd
    objects/
      coin.tscn            ← Area2D + AnimationPlayer
      gem.tscn
      checkpoint.tscn      ← Area2D + flag Sprite
      spike.tscn           ← StaticBody2D kill zone
      dash_powerup.tscn    ← Area2D
    ui/
      hud.tscn             ← lives, coin count, dash indicator
      hud.gd
    world/
      level_1.tscn         ← TileMap + ParallaxBackground + spawn points
  autoloads/
    game_events.gd
    level_state.gd         ← current checkpoint, coin count, lives
```

### Signal bus and level state

```gdscript
# autoloads/game_events.gd
extends Node

signal player_died
signal checkpoint_reached(pos: Vector2)
signal coin_collected(total: int)
signal dash_unlocked
signal level_complete
```

```gdscript
# autoloads/level_state.gd
extends Node

var lives: int = 3
var coins: int = 0
var checkpoint: Vector2 = Vector2.ZERO
var has_dash: bool = false

func _ready() -> void:
    GameEvents.checkpoint_reached.connect(func(p): checkpoint = p)
    GameEvents.coin_collected.connect(func(n): coins = n)
    GameEvents.dash_unlocked.connect(func(): has_dash = true)
    GameEvents.player_died.connect(_on_player_died)

func _on_player_died() -> void:
    lives -= 1
    if lives <= 0:
        get_tree().reload_current_scene()
    else:
        # Respawn player at checkpoint next frame
        await get_tree().process_frame
        var player: Player = get_tree().get_first_node_in_group("player")
        if player:
            player.respawn(checkpoint if checkpoint != Vector2.ZERO
                           else player.spawn_position)
```

## 2 · Player Controller

### Run and jump fundamentals

Export all tuning constants so level designers can adjust feel
 without editing code. Separate *acceleration* and
 *deceleration* values give the character a grounded,
 weighty feel:

```gdscript
# player.gd
class_name Player
extends CharacterBody2D

# ── Tuning constants ──────────────────────────────────────
@export var run_speed: float         = 200.0
@export var acceleration: float      = 1200.0
@export var deceleration: float      = 900.0
@export var air_acceleration: float  = 600.0
@export var jump_velocity: float     = -380.0
@export var gravity: float           = 900.0
@export var max_fall_speed: float    = 600.0

# ── Coyote / buffer ───────────────────────────────────────
@export var coyote_time: float       = 0.10
@export var jump_buffer_time: float  = 0.12

# ── Wall movement ─────────────────────────────────────────
@export var wall_slide_gravity: float = 180.0
@export var wall_jump_velocity: Vector2 = Vector2(220.0, -340.0)

# ── Dash ──────────────────────────────────────────────────
@export var dash_speed: float        = 520.0
@export var dash_duration: float     = 0.18
@export var dash_cooldown: float     = 0.6

var spawn_position: Vector2

@onready var _anim:  AnimationPlayer = $AnimationPlayer
@onready var _sprite: Sprite2D       = $Sprite2D

var _coyote_timer:  float = 0.0
var _jump_buffer:   float = 0.0
var _was_on_floor:  bool  = false
var _facing:        float = 1.0    # 1 = right, -1 = left

var _dashing:       bool  = false
var _dash_timer:    float = 0.0
var _dash_cooldown: float = 0.0
var _dash_dir:      float = 1.0

func _ready() -> void:
    spawn_position = global_position
    add_to_group("player")

func _physics_process(delta: float) -> void:
    _tick_timers(delta)
    if _dashing:
        _tick_dash(delta)
    else:
        _tick_normal(delta)
    move_and_slide()
    _update_animation()

func _tick_timers(delta: float) -> void:
    _dash_cooldown = maxf(0.0, _dash_cooldown - delta)
    if Input.is_action_just_pressed("jump"):
        _jump_buffer = jump_buffer_time
    else:
        _jump_buffer = maxf(0.0, _jump_buffer - delta)

    if _was_on_floor and not is_on_floor():
        _coyote_timer = coyote_time
    else:
        _coyote_timer = maxf(0.0, _coyote_timer - delta)
    _was_on_floor = is_on_floor()
```

### Coyote time and jump buffer

Coyote time lets the player jump for a brief window after walking
 off a ledge. Jump buffering queues a jump if the player presses the
 button slightly before landing. Together they make the controls feel
 forgiving without being loose:

```gdscript
func _tick_normal(delta: float) -> void:
    var on_floor := is_on_floor()
    var can_jump := on_floor or _coyote_timer > 0.0

    # Horizontal movement
    var dir := Input.get_axis("move_left", "move_right")
    if dir != 0.0:
        _facing = sign(dir)
        var accel := acceleration if on_floor else air_acceleration
        velocity.x = move_toward(velocity.x, dir * run_speed, accel * delta)
    else:
        var decel := deceleration if on_floor else air_acceleration * 0.5
        velocity.x = move_toward(velocity.x, 0.0, decel * delta)

    # Jump (buffer + coyote)
    if _jump_buffer > 0.0 and can_jump:
        velocity.y     = jump_velocity
        _jump_buffer   = 0.0
        _coyote_timer  = 0.0
        _anim.play("jump")

    # Variable-height jump — release early to cut height
    if Input.is_action_just_released("jump") and velocity.y < 0.0:
        velocity.y *= 0.5

    # Wall slide
    if is_on_wall() and not on_floor and velocity.y > 0.0:
        velocity.y = minf(velocity.y, wall_slide_gravity)
        if Input.is_action_just_pressed("jump"):
            velocity = Vector2(-get_wall_normal().x * wall_jump_velocity.x,
                               wall_jump_velocity.y)
            _jump_buffer = 0.0
    else:
        # Normal gravity
        velocity.y = minf(velocity.y + gravity * delta, max_fall_speed)

    # Initiate dash
    if Input.is_action_just_pressed("dash") and \
            LevelState.has_dash and _dash_cooldown <= 0.0:
        _start_dash()
```

### Wall slide & wall jump

The wall-jump velocity components are separate from the regular jump
 velocity so they can be tuned independently. The horizontal
 component uses `get_wall_normal()` to automatically push
 the player away from whichever wall they are on, so the same code
 works for both left and right walls:

```gdscript
# Already shown above; excerpt for clarity:
if is_on_wall() and not is_on_floor() and velocity.y > 0.0:
    velocity.y = minf(velocity.y, wall_slide_gravity)   # slow fall
    _anim.play("wall_slide")
    if Input.is_action_just_pressed("jump"):
        # get_wall_normal() returns a unit vector pointing away from the wall
        velocity.x = -get_wall_normal().x * wall_jump_velocity.x
        velocity.y = wall_jump_velocity.y
```

:::callout-tip[Tip]
`CharacterBody2D.get_wall_normal()` returns
 `Vector2(1, 0)` when the character is touching a wall
 on its left side (normal points right) and
 `Vector2(-1, 0)` for the right side. Negating it gives
 the push-off direction, so
 `-get_wall_normal().x * speed` always pushes away from
 the wall regardless of which side it is on.
:::

### Dash ability

```gdscript
func _start_dash() -> void:
    _dashing      = true
    _dash_timer   = dash_duration
    _dash_cooldown = dash_cooldown
    _dash_dir     = _facing
    velocity.y    = 0.0          # cancel vertical momentum during dash
    _anim.play("dash")

func _tick_dash(delta: float) -> void:
    _dash_timer -= delta
    velocity = Vector2(_dash_dir * dash_speed, 0.0)
    if _dash_timer <= 0.0:
        _dashing  = false
        velocity.x = _dash_dir * run_speed  # exit at run speed

func _update_animation() -> void:
    _sprite.flip_h = _facing < 0.0
    if _dashing: return
    if is_on_floor():
        if abs(velocity.x) > 10.0: _anim.play("run")
        else:                       _anim.play("idle")
    elif is_on_wall() and velocity.y > 0.0:
        pass   # wall_slide already playing
    elif velocity.y < 0.0:
        _anim.play("jump")
    else:
        _anim.play("fall")

func respawn(pos: Vector2) -> void:
    global_position = pos
    velocity        = Vector2.ZERO
    _dashing        = false
```

## 3 · Level Design

### TileMap layer setup

Use three TileMap layers in the same node:

- **Layer 0 — Background**: decorative tiles,
 no collision. Z-index −1.
- **Layer 1 — Solid**: all solid platforms and walls.
 Physics layer "World" (bit 1).
- **Layer 2 — One-way**: platforms the player can
 jump up through. Uses a one-way collision shape.

In the TileSet, create a physics layer for layer 1 tiles with a
 full-tile collision polygon. For layer 2 (one-way) tiles, add a
 physics layer and check
 *TileData → Physics → one\_way\_collision = true*.

### One-way platforms

Godot handles one-way collision automatically when
 `one_way_collision` is set on the tile's physics layer.
 To allow the player to *drop through* a one-way platform
 (↓ + Jump):

```gdscript
func _tick_normal(delta: float) -> void:
    # Drop-through: temporarily disable one-way collisions
    if Input.is_action_pressed("move_down") and \
            Input.is_action_just_pressed("jump") and \
            is_on_floor():
        set_collision_mask_value(2, false)   # bit 2 = one-way layer
        await get_tree().create_timer(0.15).timeout
        set_collision_mask_value(2, true)
        return    # don't also jump

    # ... rest of movement ...
```

### Hazards and checkpoints

```gdscript
# spike.gd — a StaticBody2D with an Area2D child
extends Area2D

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    if body is Player:
        GameEvents.player_died.emit()
```

```gdscript
# checkpoint.gd
extends Area2D

var _activated := false
@onready var _flag: AnimationPlayer = $FlagAnim

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    if body is Player and not _activated:
        _activated = true
        _flag.play("raise")
        GameEvents.checkpoint_reached.emit(global_position)
```

## 4 · Collectibles

### Coins

Coins are `Area2D` nodes with a spinning animation.
 On collection they play a pop animation and disappear:

```gdscript
# coin.gd
extends Area2D

@onready var _anim: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    if body is Player:
        set_deferred("monitoring", false)
        LevelState.coins += 1
        GameEvents.coin_collected.emit(LevelState.coins)
        _anim.play("collect")
        await _anim.animation_finished
        queue_free()
```

### Dash power-up

```gdscript
# dash_powerup.gd
extends Area2D

@onready var _anim: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    body_entered.connect(_on_body)
    _anim.play("float")

func _on_body(body: Node) -> void:
    if body is Player and not LevelState.has_dash:
        LevelState.has_dash = true
        GameEvents.dash_unlocked.emit()
        _anim.play("collect")
        await _anim.animation_finished
        queue_free()
```

## 5 · Enemies

### Walker patrol enemy

The Walker moves horizontally between two invisible markers placed
 in the level. When it reaches a marker it flips and walks back:

```gdscript
# walker.gd
class_name Walker
extends CharacterBody2D

@export var speed: float = 80.0
@export var walk_right: NodePath
@export var walk_left:  NodePath

@onready var _right_marker: Marker2D = get_node(walk_right)
@onready var _left_marker:  Marker2D = get_node(walk_left)
@onready var _sprite: Sprite2D       = $Sprite2D

const GRAVITY := 900.0
var _direction: float = 1.0

func _physics_process(delta: float) -> void:
    velocity.x = _direction * speed
    velocity.y += GRAVITY * delta
    move_and_slide()

    # Flip at markers
    if _direction > 0.0 and \
            global_position.x >= _right_marker.global_position.x:
        _direction = -1.0
        _sprite.flip_h = true
    elif _direction < 0.0 and \
            global_position.x <= _left_marker.global_position.x:
        _direction = 1.0
        _sprite.flip_h = false

func die() -> void:
    queue_free()
```

### Stomp mechanic

An `Area2D` at the top of the Walker detects a falling
 player and triggers the stomp. A second area on the Walker's sides
 kills the player on contact (unless they are stomping):

```gdscript
# Walker scene additions:
# $StompArea  — Area2D at top of walker (small horizontal rect)
# $HurtArea   — Area2D covering sides and bottom

# In walker.gd _ready():
$StompArea.body_entered.connect(_on_stomped)
$HurtArea.body_entered.connect(_on_player_touched)

func _on_stomped(body: Node) -> void:
    if body is Player and body.velocity.y > 0.0:
        # Give the player a bounce
        body.velocity.y = -280.0
        die()

func _on_player_touched(body: Node) -> void:
    if body is Player and not body._dashing:
        GameEvents.player_died.emit()
```

:::callout-intuition[Intuition]
The stomp check uses `body.velocity.y > 0.0` to
 confirm the player is falling *downward*. Without this
 check, walking into the side of an enemy at the right frame would
 count as a stomp. Velocity direction is the reliable
 discriminator.
:::

## 6 · HUD & Lives

```gdscript
# hud.gd
extends CanvasLayer

@onready var _lives_label: Label      = $Bar/Lives
@onready var _coins_label: Label      = $Bar/Coins
@onready var _dash_icon:   TextureRect = $Bar/DashIcon

func _ready() -> void:
    GameEvents.player_died.connect(_refresh)
    GameEvents.coin_collected.connect(_on_coins)
    GameEvents.dash_unlocked.connect(func(): _dash_icon.modulate.a = 1.0)
    _dash_icon.modulate.a = 0.3   # greyed out until unlocked
    _refresh()

func _refresh() -> void:
    _lives_label.text = "♥ × %d" % LevelState.lives

func _on_coins(total: int) -> void:
    _coins_label.text = "✦ %d" % total
```

## 7 · Death & Respawn

The death sequence uses a short tween to shrink and fade the player
 sprite before `LevelState` positions the player at the
 last checkpoint:

```gdscript
# player.gd additions
var _dead: bool = false

func _ready() -> void:
    GameEvents.player_died.connect(_on_died)

func _on_died() -> void:
    if _dead: return
    _dead = true
    set_physics_process(false)

    var tween := create_tween().set_parallel(true)
    tween.tween_property(_sprite, "scale", Vector2(0.1, 0.1), 0.4) \
         .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
    tween.tween_property(_sprite, "modulate:a", 0.0, 0.3)
    await tween.finished
    # LevelState._on_player_died() will call respawn()

func respawn(pos: Vector2) -> void:
    _dead = false
    global_position  = pos
    velocity         = Vector2.ZERO
    _dashing         = false
    _sprite.scale    = Vector2.ONE
    _sprite.modulate = Color.WHITE
    set_physics_process(true)
    _anim.play("idle")
```

:::callout-pitfall[Pitfall]
Connect `GameEvents.player_died` only once (in
 `_ready`). If an enemy, a spike, and a falling pit all
 call `GameEvents.player_died.emit()` on the same frame,
 the signal fires once and `_on_died` runs once — the
 `if _dead: return` guard prevents double execution.
 Without this guard, the death tween runs twice and the lives
 counter decrements twice.
:::

## 8 · Polish

### CPU particles for dust and coin sparkle

Add a `CPUParticles2D` child to the player for landing
 dust. Emit a burst whenever the player transitions from airborne to
 grounded:

```gdscript
@onready var _dust: CPUParticles2D = $DustParticles

func _tick_normal(delta: float) -> void:
    var just_landed := not _was_on_floor and is_on_floor()
    # ... movement code ...
    if just_landed and abs(velocity.x) > 20.0:
        _dust.restart()   # emits a one-shot burst (amount set in inspector)
```

Configure the `CPUParticles2D` in the inspector:

- *One shot*: enabled
- *Amount*: 12
- *Lifetime*: 0.3
- *Direction*: (0, −1) with spread 60°
- *Initial Velocity*: 60 min / 120 max
- *Color ramp*: white at 0%, transparent at 100%

### Parallax scrolling background

A `ParallaxBackground` node with nested
 `ParallaxLayer` children automatically offsets each layer
 proportionally to the camera movement. Layers with a lower
 `motion_scale` appear further away:

```gdscript
# In level_1.tscn scene tree:
# ParallaxBackground
#   ParallaxLayer (motion_scale = (0.1, 0.05))  ← sky, clouds
#     Sprite2D or TileMap with sky texture
#   ParallaxLayer (motion_scale = (0.3, 0.15))  ← distant mountains
#     Sprite2D
#   ParallaxLayer (motion_scale = (0.6, 0.3))   ← midground trees
#     Sprite2D
```

No code is required — `ParallaxBackground` reads the
 active `Camera2D`'s position automatically. Set
 *motion\_mirroring* on each layer to the texture width so the
 background tiles seamlessly as the player scrolls right.

:::callout-connect[Connect]
Combine the parallax background with the camera's
 `drag_horizontal_enabled = true` and a small
 `drag_horizontal_offset` so the camera leads slightly
 ahead of the player. This gives the player more visible space in
 their direction of travel, a standard platformer UX convention.
:::

## Extension Challenges

Extend the platformer prototype with any of these challenges,
 applying concepts from earlier chapters:

:::problem{difficulty="easy"}
**A. Moving platforms.**
 Add a platform that travels back and forth between two
 `Marker2D` points using a looping
 `Tween` with `TRANS_SINE` easing.
 Ensure the player rides the platform correctly by using an
 `AnimatableBody2D` with
 `sync_to_physics = true`
 (or move it with `move_and_collide` each physics
 step so `CharacterBody2D` inherits the velocity).

::::solution[How to know it works]
Working when: the player stands still on the platform and travels with it,
without sliding toward the trailing edge.

`sync_to_physics` is a property of `AnimatableBody2D`, not of `StaticBody2D` --
that is what the node exists for. A `StaticBody2D` moved by a tween teleports
between physics ticks, so the character never sees a velocity to inherit and
slides.
::::

:::

:::problem{difficulty="easy"}
**B. Coin magnet power-up.**
 Add a second power-up that, when collected, attracts all
 nearby coins toward the player using a timer that
 iterates over coins in a `"coin"` group and tweens
 their position toward the player. Deactivate after 10
 seconds.

::::solution[How to know it works]
Working when: coins already on screen change direction the instant the
power-up is taken, and stop being attracted exactly ten seconds later.

Read the group fresh each time you pull, rather than caching the array when the
power-up starts: coins collected mid-effect are freed, and a cached list of
freed nodes throws on the next access.
::::

:::

:::problem{difficulty="standard"}
**C. Animated tile destruction.**
 Add a breakable brick tile type. When the player stomps it
 from below (detect via `KinematicCollision2D`
 normal pointing down), play an explosion
 `CPUParticles2D` burst and clear the cell from the
 `TileMapLayer` using `erase_cell(coord)`.
 Drop a random coin 50% of the time.

::::solution[How to know it works]
Working when: the brick clears only on an upward stomp, and the particles
appear where the brick was rather than where the player is.

Erase the cell with `erase_cell(coords)` on the `TileMapLayer`. Convert the
collision point with `local_to_map()` first -- the collision gives you world
coordinates and the tilemap wants cell coordinates, and passing one where the
other is expected clears a cell somewhere off-screen.
::::

:::

:::problem{difficulty="standard"}
**D. Level timer and leaderboard.**
 Display a stopwatch in the HUD that starts when the level
 begins and stops when `GameEvents.level_complete`
 fires. Persist the best time to
 `user://best_times.cfg` using
 `ConfigFile` and display it on the completion
 screen.

::::solution[How to know it works]
Working when: the stopwatch stops on the frame the level completes, and a
slower later run does not overwrite a faster stored one.

Compare before writing. The version that always writes is indistinguishable
from the correct one until the first time you play badly.
::::

:::

:::problem{difficulty="challenge"}
**E. Procedural level generator.**
 Write a `@tool` script that generates a
 randomised single-screen level by placing TileMap tiles
 programmatically: a flat floor, two or three floating
 platforms at random heights, a coin cluster, and an enemy
 spawn. Expose a `seed` export so the same seed
 always produces the same layout. Wire a
 *Regenerate* button in the editor toolbar
 (using the `EditorPlugin` from Ch 40) that
 calls the generator with a new random seed.

::::solution[How to know it works]
Working when: pressing *Regenerate* twice with the same seed gives an
identical level, and the generated tiles survive saving the scene.

A `@tool` script runs in the editor, where a mistake writes to your actual
scene file rather than to a running game. Keep a copy of the scene before the
first run.
::::

:::

:::problem{difficulty="challenge"}
**F. Full audio integration.**
 Add jump, land, dash, coin-collect, and enemy-stomp sound
 effects using the `SFXPool` from Ch 31. Compose a
 looping background music track that cross-fades to a tense
 variant when the player has only one life remaining, using the
 `MusicManager` dual-deck system. Expose a volume
 slider in a pause menu that persists settings to
 `user://settings.cfg`.

::::solution[How to know it works]
Working when: the music crosses to the tense variant on reaching one life
and back on gaining one, without a gap or a restart, and the volume slider
survives a relaunch.

Store the slider's value, not the bus volume: `linear_to_db()` is lossy at the
bottom of the range, so round-tripping through decibels walks the slider
downward a little on every launch.
::::

:::
