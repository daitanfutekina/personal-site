---
title: "Advanced GDScript — Static Typing, Lambdas & Coroutines"
source: "godot_ch10_gdscript_advanced.html"
---

Part II · Chapter 10

# Advanced GDScript — Static Typing, Lambdas & Coroutines

Estimated reading time: 80 min · Prerequisites: Ch 4 (GDScript basics)

## Overview

Chapter 4 gave you GDScript's foundations — variables, functions, control
 flow, and the node lifecycle. This chapter goes deeper into the features
 that separate *working code* from *maintainable code*:
 strict static typing, first-class callables and lambdas, and the
 coroutine system built on `await`.

These aren't academic extras. Static typing catches entire classes of bugs
 before you run the game. Lambdas eliminate boilerplate callback functions.
 `await` lets you write sequential-looking code for inherently
 asynchronous events — cutscenes, dialog boxes, network requests — without
 callback chains. Together they make GDScript feel like a first-class
 statically typed language while keeping the rapid-iteration flavour that
 makes Godot fun.

By the end of this chapter you will be able to:

- Use full static typing with type inference, typed arrays, and typed dictionaries
- Cast types safely with `as` and test types with `is`
- Write and pass lambdas as `Callable` values
- Use `bind()` and `bindv()` to partially apply callables
- Write coroutines with `await` to sequence events cleanly
- Define inner classes for self-contained data types
- Write `@tool` scripts that run inside the editor
- Use `match` with binding patterns for readable branching

## 1 · Static Typing

GDScript is dynamically typed by default — variables hold any value, and
 type mismatches surface at runtime. Static typing adds compile-time checks:
 the editor and LSP warn you *before* you run the game, autocompletion
 becomes more accurate, and the bytecode compiler can emit faster instructions
 for typed values.

Annotate a variable's type with a colon after its name:

```gdscript
# Untyped (valid, but loses editor assistance)
var score = 0
var player_name = "Alex"

# Statically typed
var score: int = 0
var player_name: String = "Alex"
var health: float = 100.0
var is_alive: bool = true
var spawn_pos: Vector2 = Vector2(200, 300)

# Typed node references
var label: Label
var player: CharacterBody2D

# Typed function parameters and return values
func add_score(amount: int) -> void:
    score += amount

func get_display_name() -> String:
    return player_name.to_upper()
```

:::callout-tip[Enable strict mode project-wide]
Add `debug/gdscript/warnings/untyped_declaration = 1` in
 project.godot (or Project Settings → Debug → GDScript → Untyped Declaration
 → Warn). This turns every untyped variable into a yellow warning so you
 can catch them systematically.
:::

### Type inference with :=

Writing the type explicitly every time is verbose. The **infer operator
 `:=`** asks GDScript to deduce the type from the right-hand
 side — you get static typing without repeating yourself:

```gdscript
var score    := 0            # inferred: int
var name     := "Alex"       # inferred: String
var position := Vector2.ZERO # inferred: Vector2
var nodes    := get_children()  # inferred: Array[Node] in Godot 4.x

# :=  is only valid in var declarations, not in assignments:
score = 5      # OK — reassignment
score := 5     # ERROR — := is not an assignment operator
```

:::callout-warning[Inference follows the literal, not your intent]
`var ratio := 1` infers `int`, not `float`.
 Write `var ratio := 1.0` or `var ratio: float = 1` when
 you need a float. The same applies to `null` — inferring from
 `null` gives type `Variant`, not the node type you
 intended.
:::

### Typed arrays and dictionaries

Arrays and dictionaries can be typed so that inserting the wrong element
 is a type error caught at edit time:

```gdscript
# Typed array: only int allowed
var scores: Array[int] = [10, 20, 30]
scores.append(40)     # OK
scores.append("oops") # Error at compile time

# Typed dictionary (Godot 4.4+): key String, value float
var modifiers: Dictionary[String, float] = {
    "speed_mult": 1.5,
    "damage_mult": 2.0,
}

# Typed array of custom class
var enemies: Array[Enemy] = []

# Iterating preserves the type — no cast needed:
for enemy in enemies:
    enemy.take_damage(10)   # full autocompletion on `enemy`
```

### Casting with as and testing with is

When you receive a node as a generic `Node` or `Variant`
 and need a specific type, use `as` to cast it. If the cast fails,
 `as` returns `null` — it never crashes.
 Use `is` to test the type before acting.

```gdscript
func _on_body_entered(body: Node2D) -> void:
    # Safe cast — returns null if body is not a Player
    var player := body as Player
    if player == null:
        return
    player.take_damage(25)

# is — boolean type check
func describe(node: Node) -> String:
    if node is CharacterBody2D:
        return "character"
    elif node is StaticBody2D:
        return "static body"
    elif node is Area2D:
        return "area"
    return "other"

# Combining is with a binding variable (Godot 4.3+):
if node is Enemy as e:
    e.alert()   # e is typed as Enemy here
```

:::callout-key[as vs cast — subtle difference]
In GDScript, `as` is a *safe cast*: it returns
 `null` on failure. There is no "hard cast" that throws an
 exception — GDScript's type system is more like Swift's `as?`
 than Java's `(Type)` cast. If you need to assert that a cast
 must succeed, follow it with a null check and a push\_error().
:::

## 2 · Lambdas & Callables

In Godot 4, functions are first-class values of type **Callable**.
 You can store them in variables, pass them as arguments, and call them later.
 This is the foundation of signal connections, deferred calls, and functional
 programming patterns in GDScript.

### Callable basics

```gdscript
# Reference a method as a Callable:
var fn: Callable = self.heal_player

# Call it later:
fn.call()          # equivalent to self.heal_player()
fn.call(25)        # pass arguments
fn.callv([25])     # pass as array

# Pass to signal.connect():
health_depleted.connect(self.on_health_depleted)

# Store a built-in method as callable:
var sorter: Callable = func(a, b): return a < b
my_array.sort_custom(sorter)
```

### Lambda functions

A **lambda** is an anonymous function defined inline with
 the `func` keyword (no name). It *captures* variables
 from the enclosing scope automatically:

```gdscript
# Simple lambda — no captures:
var double: Callable = func(x: int) -> int: return x * 2
print(double.call(5))   # 10

# Lambda capturing an outer variable:
var base_damage := 10
var calculate_damage: Callable = func(multiplier: float) -> float:
    return base_damage * multiplier     # `base_damage` captured by reference

print(calculate_damage.call(2.5))   # 25.0
base_damage = 20
print(calculate_damage.call(2.5))   # 50.0 — captures by reference, not value

# Multi-line lambda (indent the body):
var process_enemy: Callable = func(enemy: Enemy) -> void:
    if not enemy.is_alive():
        return
    enemy.update_ai()
    enemy.move()

enemies.filter(func(e): return e.is_alive()).map(process_enemy)
```

:::callout-tip[Lambdas shine in signal connections]
Instead of writing a dedicated `_on_button_pressed` method
 for every button, connect with a lambda inline. This keeps related logic
 together and avoids cluttering the class with one-liner callbacks:

```gdscript
$SaveButton.pressed.connect(func(): save_game())
$QuitButton.pressed.connect(func(): get_tree().quit())
$VolumeSlider.value_changed.connect(func(v): AudioServer.set_bus_volume_db(0, v))
```
:::

### bind() — partial application

`Callable.bind()` creates a new callable with some arguments
 pre-filled. This is essential when connecting signals that pass fewer
 arguments than your callback needs:

```gdscript
# A button signal only passes no arguments, but we need to know WHICH slot was pressed:
func _ready() -> void:
    for i in 5:
        var btn := $Buttons.get_child(i)
        # bind(i) pre-fills the first argument — the signal's zero args come after:
        btn.pressed.connect(on_slot_pressed.bind(i))

func on_slot_pressed(slot_index: int) -> void:
    equip_item(slot_index)

# bind() with multiple args — they are appended in order:
$AttackButton.pressed.connect(perform_action.bind("attack", 30))

func perform_action(action: String, value: int) -> void:
    print(action, " with power ", value)

# Callable.bindv(array) — bind from an array of args:
var args := ["fire", 50]
$SpecialButton.pressed.connect(perform_action.bindv(args))
```

## 3 · Coroutines & `await`

A **coroutine** is a function that can pause mid-execution,
 yield control back to the engine, and resume later. In GDScript, any function
 that uses the `await` keyword becomes a coroutine automatically.

Without coroutines, sequential gameplay events require callback chains:
 play animation → on\_animation\_finished → show dialog → on\_dialog\_closed → award XP.
 With `await` you write all of that as a single top-to-bottom function:

```gdscript
func play_victory_sequence() -> void:
    $Animator.play("victory")
    await $Animator.animation_finished   # pause until signal fires

    $DialogBox.show_text("You won!")
    await $DialogBox.closed              # pause until player dismisses

    player.award_xp(200)
    $LevelUpParticles.emitting = true
    await get_tree().create_timer(1.5).timeout  # pause 1.5 seconds

    get_tree().change_scene_to_file("res://scenes/next_level.tscn")
```

Each `await` line suspends this coroutine until the specified
 signal fires, then resumes from the next line. The rest of the game keeps
 running normally — `await` does not freeze the engine.

### await a signal

The most common use: wait for any signal from any object.

```gdscript
# Wait for any signal — syntax: await object.signal_name
await $TweenNode.finished
await player.died
await get_tree().process_frame    # wait exactly one frame
await get_tree().physics_frame    # wait one physics tick

# Capture the signal's emitted value(s):
var body: Node2D = await $PickupArea.body_entered
print("Picked up by: ", body.name)

# Wait for one of several signals (use a helper coroutine or a flag):
func wait_for_input() -> StringName:
    var action := ""
    while action.is_empty():
        await get_tree().process_frame
        if Input.is_action_just_pressed("jump"):   action = "jump"
        elif Input.is_action_just_pressed("dodge"): action = "dodge"
    return action
```

### await a timer

The pattern `await get_tree().create_timer(seconds).timeout`
 is so common it deserves its own section. It creates a one-shot SceneTreeTimer
 — lighter than a Timer node — that fires `timeout` after the
 given number of seconds and is then freed automatically.

```gdscript
# Pause for 2 seconds:
await get_tree().create_timer(2.0).timeout

# Respect Engine.time_scale (e.g. bullet time):
await get_tree().create_timer(1.0, true).timeout   # 2nd arg: process_always

# Practical use — invincibility frames after hit:
func take_hit(damage: int) -> void:
    if _invincible:
        return
    health -= damage
    _invincible = true
    $HurtAnimator.play("flash")
    await get_tree().create_timer(1.5).timeout
    _invincible = false
```

### Chaining and calling coroutines

Calling a coroutine from another function returns a **Signal**
 you can `await`. This lets you chain coroutines cleanly:

```gdscript
func play_level_intro() -> void:
    await show_title_card("Level 3")      # waits for show_title_card to finish
    await pan_camera_to_player()
    Input.set_input_enabled(true)

# show_title_card IS a coroutine (uses await internally):
func show_title_card(text: String) -> void:
    $TitleLabel.text = text
    $TitleLabel.visible = true
    $TitleAnimator.play("fade_in")
    await $TitleAnimator.animation_finished
    await get_tree().create_timer(2.0).timeout
    $TitleAnimator.play("fade_out")
    await $TitleAnimator.animation_finished
    $TitleLabel.visible = false

# Fire-and-forget (don't await — coroutine runs independently):
play_level_intro()   # starts the sequence but doesn't block here
```

:::callout-warning[Coroutines and freed nodes]
If the node that owns a coroutine is freed while the coroutine is
 suspended at an `await`, the coroutine is silently discarded
 — it won't crash but it won't resume either. If the coroutine held a
 reference to another object that was also freed, accessing it after
 resuming will crash. Guard with `is_instance_valid(obj)`
 after any `await` that could take a long time.
:::

:::example[Dialog system with coroutines]
Show a series of dialog lines one at a time, waiting for the player
          to press a key before advancing. Return the chosen option at the end.

::::answer[Coroutine-based dialog]
```gdscript
func run_dialog(lines: Array[String]) -> void:
    for line in lines:
        $DialogBox.set_text(line)
        $DialogBox.show_continue_prompt()
        # Wait for player to press the "interact" button
        await wait_for_action("interact")
        $DialogBox.hide_continue_prompt()
    $DialogBox.hide()

func wait_for_action(action: StringName) -> void:
    # Spin until the action fires — uses one process frame per check
    while not Input.is_action_just_pressed(action):
        await get_tree().process_frame

# Usage:
func _on_npc_interact() -> void:
    await run_dialog([
        "Hello, traveller.",
        "The dungeon ahead is dangerous.",
        "Take this torch.",
    ])
    player.receive_item("Torch")
```
::::
:::

## 4 · Inner Classes

GDScript lets you define a `class` inside a script file. Inner
 classes are useful for small self-contained data types that logically belong
 to a parent class but are too simple to deserve their own file.

```gdscript
# inventory.gd
class_name Inventory

class Item:
    var name:   String
    var weight: float
    var value:  int

    func _init(n: String, w: float, v: int) -> void:
        name   = n
        weight = w
        value  = v

    func describe() -> String:
        return "%s (%.1f kg, %d gold)" % [name, weight, value]

class Recipe:
    var result:      Item
    var ingredients: Array[Item]

    func can_craft(available: Array[Item]) -> bool:
        for ing in ingredients:
            if not available.any(func(i): return i.name == ing.name):
                return false
        return true

# Usage in any script:
var sword   := Inventory.Item.new("Iron Sword", 2.5, 120)
var potion  := Inventory.Item.new("Health Potion", 0.3, 40)
var bag     : Array[Inventory.Item] = [sword, potion]
print(sword.describe())   # Iron Sword (2.5 kg, 120 gold)
```

:::callout-intuition[When to use inner classes vs. custom resources]
Use an **inner class** for temporary, logic-heavy objects
 that are created and discarded at runtime (event queue entries, search nodes
 in A\*, intermediate results). Use a **custom Resource** (Chapter 6)
 for persistent data you want to save to disk, configure in the editor, or
 share between scenes. Resources carry serialisation and @export for free;
 inner classes do not.
:::

## 5 · @tool Scripts

Adding `@tool` at the top of a script makes it run
 *inside the Godot editor* as well as at runtime. The editor calls
 `_ready()` when the node is added to the scene, and
 `_process()` continuously while the node is selected. This
 lets you build editor helpers, procedural generators, and custom inspector
 visualisations without a plugin.

```gdscript
@tool
extends Node2D

@export var radius: float = 100.0 : set = _set_radius

func _set_radius(value: float) -> void:
    radius = value
    queue_redraw()   # request _draw() to be called

func _draw() -> void:
    # This draws a circle outline in the editor viewport
    draw_arc(Vector2.ZERO, radius, 0.0, TAU, 64, Color.AQUA, 2.0)
```

### Practical @tool use-cases

| Use-case | What you do in @tool |
| --- | --- |
| Preview collision shapes | Draw an arc or polygon in `_draw()` to visualise a custom hitbox radius. |
| Procedural mesh in editor | Use an @export + setter that calls your mesh-generation code, so the 3D mesh updates as you tweak sliders. |
| Level layout helper | Read a CSV or JSON @export var and place child nodes at the correct positions when the file changes. |
| Validation warnings | Override `_get_configuration_warnings() -> PackedStringArray` to show warnings in the inspector when properties are invalid. |
| Auto-assign children | In `_ready()`, find and assign @onready vars by path so you don't need manual NodePath wiring. |

```gdscript
@tool
extends Node2D

# Shows a warning in the inspector if no spawn points are defined
func _get_configuration_warnings() -> PackedStringArray:
    var warnings: PackedStringArray = []
    if get_child_count() == 0:
        warnings.append("Add at least one spawn point as a child.")
    return warnings

# Called when any @export property changes in the editor
func _notification(what: int) -> void:
    if what == NOTIFICATION_EDITOR_PRE_SAVE:
        _validate_data()   # check before every save

func _validate_data() -> void:
    for child in get_children():
        if not child is Marker2D:
            push_warning("Child '%s' is not a Marker2D." % child.name)
```

:::callout-pitfall[@tool runs in the editor — be careful with side effects]
`queue_free()`, `get_tree().change_scene_to_file()`,
 and any code that modifies the scene tree can corrupt the editor if called
 at edit time. Guard editor-only code with `if Engine.is_editor_hint()`
 and runtime-only code with `if not Engine.is_editor_hint()`.

```gdscript
func _process(delta: float) -> void:
    if Engine.is_editor_hint():
        queue_redraw()    # update preview
    else:
        _run_gameplay(delta)   # only in game
```
:::

## 6 · `match` & Patterns

GDScript's `match` statement is like a supercharged
 `switch`. It compares an expression against a series of
 *patterns*, not just constant values. Patterns can bind variables,
 destructure arrays and dictionaries, and match based on type.

```gdscript
var state := "idle"

match state:
    "idle":
        play_idle()
    "run", "walk":      # multiple values in one branch
        play_locomotion()
    "attack":
        play_attack()
    _:                  # wildcard — matches anything
        push_warning("Unknown state: " + state)
```

### Binding patterns

A pattern can *bind* the matched value to a local variable using
 `var`:

```gdscript
var result: Variant = get_query_result()

match result:
    null:
        print("no result")
    var n when n is int:    # guard condition with `when`
        print("integer: ", n)
    var s when s is String:
        print("string: ", s.to_upper())
    var other:
        print("something else: ", other)
```

### Array and dictionary destructuring

```gdscript
# Match an array by structure:
var pair := [3, 7]

match pair:
    [0, var b]:
        print("starts with zero, then ", b)
    [var a, var b] when a == b:
        print("equal pair: ", a)
    [var a, var b]:
        print("pair: ", a, ", ", b)    # matches [3, 7]

# Match a dictionary — only listed keys need to exist:
var event := {"type": "damage", "amount": 30}

match event:
    {"type": "damage", "amount": var dmg}:
        apply_damage(dmg)
    {"type": "heal", "amount": var heal}:
        apply_heal(heal)
    _:
        push_warning("Unknown event")
```

:::callout-tip[match is exhaustive at the branch level, not by type]
GDScript doesn't enforce that every case is covered (no compiler warning
 for missing branches). Always add a `_:` wildcard branch at the
 end if you want to catch unexpected values. The wildcard is analogous to
 `default:` in C-style switch.
:::

## 7 · Useful Annotations

Annotations (lines starting with `@`) modify how GDScript treats
 a variable, function, or class. You already know `@export` and
 `@onready` from Chapter 4. Here are the ones that become important
 at intermediate level:

| Annotation | Where | Effect |
| --- | --- | --- |
| `@export_range(min, max, step)` | var | Shows a slider in the Inspector bounded to a range. |
| `@export_enum("A","B","C")` | var | Shows a drop-down in the Inspector with the listed options. |
| `@export_group("Name")` | — (between vars) | Collapses the following @export vars into a named group in the Inspector. |
| `@export_subgroup("Name")` | — (between vars) | Nested group inside an @export\_group. |
| `@export_file("*.json")` | var (String) | Shows a file-picker for a String path, filtered by extension. |
| `@export_color_no_alpha` | var (Color) | Hides the alpha slider in the color picker. |
| `@static_unload` | class | Frees static variables when the script is no longer referenced (avoids memory leaks in autoloads). |
| `@warning_ignore("unused_variable")` | var or func | Suppresses a specific GDScript warning for the next line. |
| `@rpc` | func | Marks the function as callable via RPC in multiplayer (Chapter 30+). |

```gdscript
@export_group("Movement")
@export_range(50.0, 600.0, 10.0) var speed: float = 300.0
@export_range(0.0, 1.0, 0.01) var friction: float = 0.15

@export_group("Combat")
@export_range(1, 999) var max_health: int = 100
@export_enum("Sword", "Bow", "Magic") var weapon_type: int = 0

@export_group("Audio")
@export_file("*.wav", "*.ogg") var footstep_sound_path: String = ""

# Using @warning_ignore when a variable is intentionally unused in a branch:
func handle_event(event: Dictionary) -> void:
    @warning_ignore("unused_variable")
    var _ignored := event.get("debug_info", "")
    process_event(event)
```

:::summary
## Chapter Summary

| Feature | Quick reference |
| --- | --- |
| Static typing | `var x: int = 0` or infer with `var x := 0`. Typed arrays: `Array[Enemy]`. |
| Safe cast | `var p := body as Player` — returns null on failure, never crashes. |
| Type test | `if node is Enemy:` or binding form `if node is Enemy as e:`. |
| Callable | `var fn: Callable = self.my_method`. Call with `fn.call(args)`. |
| Lambda | `func(x): return x * 2` — anonymous, captures outer scope by reference. |
| bind() | Pre-fill args: `my_func.bind(slot_index)`. Use with signals that pass fewer args than callback needs. |
| await signal | `await $Anim.animation_finished` — suspends coroutine, engine keeps running. |
| await timer | `await get_tree().create_timer(2.0).timeout` — lightweight one-shot delay. |
| Inner class | `class Foo:` inside a script. Access externally as `OuterScript.Foo.new()`. |
| @tool | Runs script in editor. Guard with `Engine.is_editor_hint()`. |
| match patterns | Bind with `var n`, guard with `when`, destructure arrays/dicts. |

**If you remember nothing else:** `:=` infers types;
 `await signal` lets you write linear code for asynchronous events;
 `bind()` is how you pass extra context through signals. These three
 alone will improve 80 % of intermediate GDScript code.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Convert the following untyped function to fully statically typed GDScript.
 Add a return type annotation and type all parameters and local variables.

```gdscript
func calculate_dps(base_damage, attacks_per_second, crit_chance, crit_mult):
    var crit_factor = 1.0 + crit_chance * (crit_mult - 1.0)
    var dps = base_damage * attacks_per_second * crit_factor
    return dps
```

::::solution[Solution]
```gdscript
func calculate_dps(
        base_damage: float,
        attacks_per_second: float,
        crit_chance: float,
        crit_mult: float) -> float:
    var crit_factor: float = 1.0 + crit_chance * (crit_mult - 1.0)
    var dps: float = base_damage * attacks_per_second * crit_factor
    return dps

# Or using := inference for locals:
func calculate_dps(
        base_damage: float,
        attacks_per_second: float,
        crit_chance: float,
        crit_mult: float) -> float:
    var crit_factor := 1.0 + crit_chance * (crit_mult - 1.0)
    var dps         := base_damage * attacks_per_second * crit_factor
    return dps
```
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Connect three buttons to the same handler using `bind()` so that
 pressing each button calls `select_weapon(index: int)` with
 index 0, 1, and 2 respectively. The `pressed` signal emits no arguments.

::::solution[Solution]
```gdscript
func _ready() -> void:
    $SwordButton.pressed.connect(select_weapon.bind(0))
    $BowButton.pressed.connect(select_weapon.bind(1))
    $MagicButton.pressed.connect(select_weapon.bind(2))

func select_weapon(index: int) -> void:
    current_weapon = index
    update_hud()
```
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Write a coroutine `fade_out(duration: float) -> void` that
 smoothly fades a CanvasModulate node's alpha from 1.0 to 0.0 over
 `duration` seconds using `_process` / `await`,
 without a Tween node.

::::solution[Solution]
```gdscript
@onready var canvas: CanvasModulate = $CanvasModulate

func fade_out(duration: float) -> void:
    var elapsed := 0.0
    while elapsed < duration:
        await get_tree().process_frame
        var delta := get_process_delta_time()
        elapsed += delta
        var t := clampf(elapsed / duration, 0.0, 1.0)
        canvas.color.a = 1.0 - t
    canvas.color.a = 0.0
```

Each `await get_tree().process_frame` suspends for one
 frame. `get_process_delta_time()` returns the actual elapsed
 time since the last process frame, so the fade is framerate-independent.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Write a `match` statement that handles an
 `event: Dictionary` with a `"type"` key. It should handle
 `"attack"` (with an `"amount"` key), `"heal"`
 (with an `"amount"` key), `"status"` (with a
 `"effect"` String key), and an unknown type that logs a warning.

::::solution[Solution]
```gdscript
func handle_combat_event(event: Dictionary) -> void:
    match event:
        {"type": "attack", "amount": var dmg}:
            take_damage(int(dmg))
        {"type": "heal", "amount": var hp}:
            heal(int(hp))
        {"type": "status", "effect": var fx} when fx is String:
            apply_status(fx)
        {"type": var unknown}:
            push_warning("Unhandled event type: " + str(unknown))
        _:
            push_error("Malformed event dict: " + str(event))
```
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
Using an inner class, define a `PriorityQueue` class inside an
 `AISystem` script. The queue stores `Task` inner objects
 (with `priority: int` and `action: Callable` fields).
 Implement `push(task)` and `pop() -> Task` that always
 returns the task with the highest priority.

::::solution[Solution]
```gdscript
# ai_system.gd
class_name AISystem

class Task:
    var priority: int
    var action: Callable
    func _init(p: int, a: Callable) -> void:
        priority = p
        action   = a

class PriorityQueue:
    var _items: Array[AISystem.Task] = []

    func push(task: AISystem.Task) -> void:
        _items.append(task)

    func pop() -> AISystem.Task:
        if _items.is_empty():
            return null
        var best_idx := 0
        for i in range(1, _items.size()):
            if _items[i].priority > _items[best_idx].priority:
                best_idx = i
        var task: AISystem.Task = _items[best_idx]
        _items.remove_at(best_idx)
        return task

    func is_empty() -> bool:
        return _items.is_empty()

# Usage:
var queue := AISystem.PriorityQueue.new()
queue.push(AISystem.Task.new(5, func(): attack_player()))
queue.push(AISystem.Task.new(8, func(): flee_danger()))
var next := queue.pop()   # returns flee_danger task (priority 8)
next.action.call()
```
::::
:::

:::problem[Problem 6 challenge]{difficulty="challenge"}
Write a `@tool` script for a `Node2D` that draws a
 configurable polygon preview in the editor: an @export var `sides: int`
 (range 3–12) and `radius: float` drive a regular polygon drawn with
 `draw_polygon()`. When either property changes, the preview updates
 immediately. Also implement `_get_configuration_warnings()` to warn
 if `sides < 3`.

::::solution[Solution]
```gdscript
@tool
extends Node2D

@export_range(3, 12) var sides: int = 6 : set = _set_sides
@export_range(10.0, 500.0, 1.0) var radius: float = 60.0 : set = _set_radius

func _set_sides(value: int) -> void:
    sides = value
    update_configuration_warnings()
    queue_redraw()

func _set_radius(value: float) -> void:
    radius = value
    queue_redraw()

func _get_configuration_warnings() -> PackedStringArray:
    if sides < 3:
        return ["Polygon requires at least 3 sides."]
    return []

func _draw() -> void:
    if sides < 3:
        return
    var points := PackedVector2Array()
    for i in sides:
        var angle := TAU * i / sides - PI / 2.0
        points.append(Vector2(cos(angle), sin(angle)) * radius)
    draw_polygon(points, PackedColorArray([Color(0.2, 0.8, 0.4, 0.4)]))
    # Draw outline:
    points.append(points[0])   # close the loop
    draw_polyline(points, Color.GREEN, 2.0)
```

The setters call `queue_redraw()` which schedules
 `_draw()` to run at the next frame — this is how Godot's
 custom drawing pipeline works. `update_configuration_warnings()`
 forces the inspector to re-check `_get_configuration_warnings()`.
::::
:::

Godot 4.6 Complete Reference · Part II — Advanced GDScript · Generated for self-study. Edit freely.
