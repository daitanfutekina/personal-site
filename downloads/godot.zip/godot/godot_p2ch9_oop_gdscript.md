---
title: "OOP in GDScript — Classes, Inheritance & class_name"
source: "godot_p2ch9_oop_gdscript.html"
---

Part II · GDScript Deep Dive

# OOP in GDScript — Classes, Inheritance & `class_name`

Part II Chapter 9 · Prerequisites: Ch 3 (Nodes & Scenes), Ch 4 (GDScript), Ch 8 (Static Typing) · est. 70 min

## Overview

Every GDScript file is already a class — the script attached to a node defines a class that extends the node's built-in type. But GDScript goes further: you can define inner classes within a file, register your script as a globally-named type using `class_name`, and build full inheritance hierarchies exactly as you would in any OOP language.

This chapter covers the mechanics of GDScript's object model: how to define classes, how inheritance and method overriding work, and how to choose between inheritance and composition.

## 1 · Inner Classes

:::callout-intuition[Intuition]
Sometimes you need a small data structure that only makes sense in the context of one file. Rather than creating a whole new .gd file, you define an **inner class** right inside the outer script. It's a class nested within a class — private to that file, no global registration needed.
:::

Define an inner class with the `class` keyword followed by a name. Inner classes can have their own `extends`, methods, signals, and variables:

```gdscript
# inventory.gd
extends Node

# Inner class — only known inside this file unless exported via class_name
class Slot:
    var item_name: String = ""
    var quantity: int = 0
    var icon: Texture2D = null

    func _init(name: String, qty: int) -> void:
        item_name = name
        quantity = qty

    func is_empty() -> bool:
        return quantity == 0

    func _to_string() -> String:
        return "%s x%d" % [item_name, quantity]

# Use the inner class
var slots: Array[Slot] = []

func add_item(name: String, qty: int) -> void:
    slots.append(Slot.new(name, qty))   # Slot.new() calls _init
```

:::callout-tip[\_init() is the constructor]
Every GDScript class can define `_init()` which runs when `.new()` is called. Parameters you declare in `_init()` become the arguments to `.new()`. If you don't define `_init()`, `.new()` takes no arguments.
:::

### Inner Class Inheritance

Inner classes can extend other inner classes — or even external types:

```gdscript
class StackableSlot extends Slot:
    var max_stack: int = 99

    func can_add(qty: int) -> bool:
        return quantity + qty <= max_stack
```

## 2 · `class_name` — Global Type Registration

:::callout-intuition[Intuition]
Without `class_name`, a GDScript file is just a file — you reference it by path (`load("res://enemy.gd")`). With `class_name`, you register a global name for the class that the entire project can use without any imports. It's the difference between "here's a file" and "here's a named type."
:::

### How `class_name` Works

Place `class_name YourName` at the very top of a script (before `extends`, or on the same line). Once saved, the name becomes available everywhere in the project — no `preload` needed.

```gdscript
# enemy_data.gd
class_name EnemyData extends Resource

@export var display_name: String = "Unknown"
@export var max_health: int = 100
@export var damage: int = 10
@export var speed: float = 3.0
@export var drop_table: Array[String] = []

func is_boss() -> bool:
    return max_health > 500
```

```gdscript
# player.gd — EnemyData is available with no import
extends CharacterBody2D

func _on_enemy_spawned(data: EnemyData) -> void:   # typed directly
    if data.is_boss():
        show_boss_health_bar(data)

func create_test_enemy() -> EnemyData:
    var e := EnemyData.new()   # construct anywhere
    e.display_name = "Test Goblin"
    e.max_health = 50
    return e
```

### Conventions and Rules

- Names must be **PascalCase** (e.g., `EnemyData`, not `enemy_data`)
- The name must be **unique across the entire project** — duplicate names cause errors
- You can use the name in type annotations (`var x: EnemyData`) and in `is`/`as` checks
- `class_name` works on *any* script — nodes, Resources, plain objects extending RefCounted
- Inner classes *cannot* have `class_name` — only top-level scripts

:::callout-tip[class\_name vs preload]
Old GDScript pattern: `const EnemyData = preload("res://data/enemy_data.gd")`. With `class_name EnemyData` in the file, the `preload` is completely unnecessary. Prefer `class_name` for any class you'll reference more than once.
:::

## 3 · Inheritance

:::callout-intuition[Intuition]
Inheritance lets a child class *automatically have* everything a parent class has — all its variables, methods, and signals — and then add or change specific parts. Think of it as "Enemy" defining what all enemies have in common, while "BossEnemy" adds a few boss-specific things on top.

In Godot, every script already uses inheritance — `extends CharacterBody2D` means "my script's class inherits from CharacterBody2D." Custom inheritance is the same mechanism, extended to your own classes.
:::

### The `extends` Keyword

A child class uses `extends ParentClass`. It gains all of the parent's members. It can add new members and override existing methods.

```gdscript
# base_enemy.gd
class_name BaseEnemy extends CharacterBody2D

var health: int = 100
var speed: float = 2.0
var is_alive: bool = true

signal died(enemy: BaseEnemy)
signal damaged(amount: int)

func take_damage(amount: int) -> void:
    health -= amount
    damaged.emit(amount)
    if health <= 0:
        die()

func die() -> void:
    is_alive = false
    died.emit(self)
    queue_free()

func _physics_process(delta: float) -> void:
    move_and_slide()
```

```gdscript
# goblin.gd
class_name Goblin extends BaseEnemy

var loot_gold: int = 5   # Goblin-specific property

func _ready() -> void:
    health = 40           # Override the default
    speed = 3.5

# Override die() to drop loot before freeing
func die() -> void:
    drop_loot()
    super.die()           # Call parent's die() — emits signal, queue_free

func drop_loot() -> void:
    # Spawn gold pickup at our position
    pass

# Goblin adds a new method the base class doesn't have
func taunt() -> void:
    print("Heh heh heh!")
```

### Calling the Parent with `super`

`super` refers to the parent class. You can call any parent method via `super.method_name(args)`. You can also call the parent's version of the *current* method with just `super(args)`:

```gdscript
func take_damage(amount: int) -> void:
    # Add a visual shake before delegating to parent
    shake_camera()
    super(amount)            # calls BaseEnemy.take_damage(amount)
    # same as: super.take_damage(amount)

func _ready() -> void:
    super()                  # call parent _ready() first
    # then do child-specific setup
    $NameLabel.text = "Goblin"
```

:::callout-warning[Always call super() in \_ready, \_process, \_physics\_process]
If you override a lifecycle method and the parent has setup logic in it, forgetting `super()` will silently skip that parent logic. In the engine's built-in nodes this can break physics, rendering, or signals. When in doubt, call `super()` at the start of your override.
:::

### Virtual Methods

A **virtual method** is one that a parent defines but expects children to override. GDScript doesn't have a formal `virtual` keyword — by convention, a method intended to be overridden is either left with a default no-op body or contains a comment indicating it's meant to be overridden.

```gdscript
# base_enemy.gd
func get_attack_pattern() -> String:
    # Subclasses should override this
    return "basic_melee"

func _choose_target() -> Node:
    # Override in child to implement specific targeting logic
    return get_tree().get_first_node_in_group("players")
```

```gdscript
# archer_enemy.gd
class_name ArcherEnemy extends BaseEnemy

func get_attack_pattern() -> String:
    return "ranged_volley"   # overrides parent

func _choose_target() -> Node:
    # Archers target the furthest player, not the nearest
    return _find_furthest_player()
```

:::callout-tip[The Template Method Pattern]
Define the *skeleton* of an algorithm in the base class, calling virtual methods for the steps. Child classes fill in the steps. For example, a base `State` class with `enter()`, `tick()`, and `exit()` that children override — the state machine calls these without caring which State it has.
:::

## 4 · Composition vs. Inheritance

:::callout-intuition[Intuition]
Inheritance says "is-a": a `Goblin` IS a `BaseEnemy`. Composition says "has-a": a `Player` HAS a `HealthComponent`. Inheritance is powerful but creates tight coupling — change the parent and you potentially break all children. Composition keeps components independent. In Godot, the scene tree itself is a composition model.
:::

### Component Nodes (Godot's Preferred Pattern)

In Godot the idiomatic composition pattern is to use **child nodes as components**. Each component node has its own script handling one responsibility:

```gdscript
# Player scene tree:
# Player (CharacterBody2D) ← player.gd
#   ├── HealthComponent (Node) ← health_component.gd
#   ├── WeaponComponent (Node) ← weapon_component.gd
#   └── MovementComponent (Node) ← movement_component.gd

# health_component.gd
class_name HealthComponent extends Node

signal died
signal health_changed(new_val: int, max_val: int)

@export var max_health: int = 100
var current_health: int

func _ready() -> void:
    current_health = max_health

func take_damage(amount: int) -> void:
    current_health = max(0, current_health - amount)
    health_changed.emit(current_health, max_health)
    if current_health == 0:
        died.emit()

func heal(amount: int) -> void:
    current_health = min(max_health, current_health + amount)
    health_changed.emit(current_health, max_health)

func get_percent() -> float:
    return float(current_health) / float(max_health)
```

```gdscript
# player.gd — uses the component, doesn't inherit from it
extends CharacterBody2D

@onready var health: HealthComponent = $HealthComponent
@onready var weapon: WeaponComponent = $WeaponComponent

func _ready() -> void:
    health.died.connect(_on_player_died)
    health.health_changed.connect(HUD.update_health_bar)

func _on_player_died() -> void:
    $AnimationPlayer.play("death")
    await $AnimationPlayer.animation_finished
    get_tree().reload_current_scene()
```

### When to Use Inheritance vs. Composition

| Use Inheritance when… | Use Composition when… |
| --- | --- |
| The child IS the parent (Goblin IS an Enemy) | The feature is reusable across unrelated things (health, hitbox, loot) |
| You want to override a small number of methods | You want to mix and match abilities independently |
| The hierarchy is shallow (1–2 levels) | The hierarchy would be 3+ levels deep |
| The types share enough behaviour that duplication is worse | You want to test components in isolation |

:::callout-key[The Godot way]
Godot's scene tree is fundamentally a composition system. Prefer composition (child component nodes) for game logic, and use inheritance when your scripts genuinely specialise a parent type — particularly when extending engine nodes like `CharacterBody2D` or `Resource`.
:::

## 5 · Practical Design Patterns

### State Base Class (Template Method)

Define common state behaviour in a base class; concrete states override only what differs:

```gdscript
# state.gd
class_name State extends Node

var owner_body: CharacterBody2D  # set by the state machine

func enter() -> void:
    pass   # override in children

func exit() -> void:
    pass

func tick(delta: float) -> String:
    # Return "" to stay, return state name to transition
    return ""

func physics_tick(delta: float) -> String:
    return ""
```

```gdscript
# state_idle.gd
class_name StateIdle extends State

func enter() -> void:
    owner_body.velocity = Vector2.ZERO
    owner_body.get_node("AnimationPlayer").play("idle")

func tick(delta: float) -> String:
    if Input.is_action_pressed("move_right") or Input.is_action_pressed("move_left"):
        return "Run"
    if Input.is_action_just_pressed("jump"):
        return "Jump"
    return ""
```

### Duck Typing — GDScript's "Interfaces"

GDScript has no formal `interface` keyword, but you can achieve the same result through **duck typing**: check whether an object *has* a method before calling it. Combine this with `class_name` for a pseudo-interface pattern:

```gdscript
# interactable.gd — acts as an interface definition
class_name Interactable extends Node

# All "implementing" nodes should override this
func interact(player: CharacterBody2D) -> void:
    push_warning("Interactable.interact() not overridden in: " + name)

func get_prompt_text() -> String:
    return "Press E to interact"

# check_interact.gd — any node can be queried for Interactable
func try_interact(target: Node, player: CharacterBody2D) -> void:
    if target is Interactable:
        (target as Interactable).interact(player)
    elif target.has_method("interact"):   # duck typing fallback
        target.interact(player)
```

:::callout-connect[Connects forward]
These patterns will appear in **Ch 27 (State Machines)** and the Capstone chapters. The State base class here is the exact foundation for the full FSM built later.
:::

:::summary
## Chapter Summary

| Feature | Syntax | Key point |
| --- | --- | --- |
| Inner class | `class Name:` inside a script | Private to the file, no global name |
| Constructor | `func _init(args):` | Called by `ClassName.new(args)` |
| Global type name | `class_name MyClass` at top | Available project-wide, no preload |
| Inheritance | `class_name Child extends Parent` | Child gains all parent members |
| Parent call | `super()` / `super.method()` | Always call in lifecycle overrides |
| Type check | `obj is ClassName` | Works with class\_name types |
| Component pattern | Child node with its own script | Prefer over deep inheritance |
| Duck typing | `has_method("interact")` | Interface-like without formal interface |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
Write a `class_name` declaration for a script called `bullet_data.gd` that extends `Resource`. Give it `@export` variables: `damage: int`, `speed: float`, and `sprite: Texture2D`.

::::solution[Solution]
```gdscript
# bullet_data.gd
class_name BulletData extends Resource

@export var damage: int = 10
@export var speed: float = 300.0
@export var sprite: Texture2D
```
::::
:::

:::problem[2 easy]{difficulty="easy"}
In an enemy hierarchy, `ZombieEnemy` extends `BaseEnemy`. `BaseEnemy._ready()` sets up a collision shape. `ZombieEnemy._ready()` also needs to set the animation. Write a correct `ZombieEnemy._ready()`.

::::solution[Solution]
```gdscript
func _ready() -> void:
    super()                              # run BaseEnemy._ready() first (collision setup)
    $AnimationPlayer.play("zombie_idle") # then do zombie-specific setup
```
::::
:::

:::problem[3 standard]{difficulty="standard"}
Design a `HealthComponent` node script (as shown in the chapter). Add a `is_dead: bool` getter property, and a `revive(restore_amount: int)` method that only works if the unit is dead, restoring that much health and emitting `health_changed`.

::::solution[Solution]
```gdscript
class_name HealthComponent extends Node

signal died
signal health_changed(new_val: int, max_val: int)

@export var max_health: int = 100
var current_health: int

var is_dead: bool:
    get: return current_health <= 0

func _ready() -> void:
    current_health = max_health

func take_damage(amount: int) -> void:
    if is_dead: return
    current_health = max(0, current_health - amount)
    health_changed.emit(current_health, max_health)
    if current_health == 0:
        died.emit()

func revive(restore_amount: int) -> void:
    if not is_dead: return
    current_health = min(max_health, restore_amount)
    health_changed.emit(current_health, max_health)
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
Using the duck-typing pattern, write a function `pick_up(obj: Node)` that calls `obj.collect(player)` if the method exists, otherwise prints "This object cannot be collected."

::::solution[Solution]
```gdscript
func pick_up(obj: Node) -> void:
    if obj.has_method("collect"):
        obj.collect(self)   # self is the player
    else:
        print("This object cannot be collected.")
```
::::
:::

:::problem[5 challenge]{difficulty="challenge"}
Create a `class_name Weapon` base class (extends Node) with an abstract-style `attack() -> void` method that prints a warning. Then write two subclasses: `Sword` (melee, prints "Slash!") and `Bow` (ranged, prints "Twang! Arrow fired."). Demonstrate polymorphic dispatch by storing both in a `var weapons: Array[Weapon]` and iterating to call `attack()`.

::::solution[Solution]
```gdscript
# weapon.gd
class_name Weapon extends Node
func attack() -> void:
    push_warning("Weapon.attack() not overridden in: " + name)

# sword.gd
class_name Sword extends Weapon
func attack() -> void: print("Slash!")

# bow.gd
class_name Bow extends Weapon
func attack() -> void: print("Twang! Arrow fired.")

# usage:
var weapons: Array[Weapon] = [Sword.new(), Bow.new()]
for w: Weapon in weapons:
    w.attack()   # "Slash!" then "Twang! Arrow fired."
```
::::
:::
