---
title: "C# vs GDScript & an Intro to GDExtension (C++)"
source: "godot_p2ch12_csharp_gdext.html"
---

Part II · GDScript Deep Dive

# C# vs GDScript & an Intro to GDExtension (C++)

Part II Chapter 12 · Prerequisites: Ch 4 (GDScript basics) · est. 60 min

## Overview

Godot 4.6 supports three first-party scripting approaches: **GDScript** (Godot's own language), **C#** (via .NET 8), and **GDExtension** (native code, typically C++). Each has a distinct performance profile, developer experience, and integration depth. This chapter explains all three so you can make an informed choice — or know when to combine them.

The short answer for most indie developers: start with GDScript. Add C# if you need a typed, statically-compiled language with AOT. Use GDExtension only when you need bare-metal performance or want to integrate existing C/C++ libraries.

## 1 · GDScript — Strengths & Weaknesses

### What GDScript Does Well

- **Zero setup friction** — built into the editor, no SDK or compiler installation needed
- **Hot reload** — change a script and see it update in the running game without restarting
- **Godot-native types** — `Vector2`, `Signal`, `NodePath` are first-class citizens, not wrapper structs
- **Static typing option** — performance improves significantly with full type annotations (sometimes rivaling C# for typical game logic)
- **Concise syntax** — Python-inspired, easy to read and write quickly
- **Best documentation** — all Godot examples and tutorials default to GDScript

### GDScript Limitations

- Not suitable for CPU-heavy algorithms that need to run millions of iterations per frame
- No multi-threading on GDScript objects (though you can use GDScript from threads)
- Ecosystem is Godot-only — no general-purpose libraries or NuGet packages
- Export to iOS requires AOT-compiled bytecode (handled automatically since Godot 4.4)

## 2 · C# in Godot 4.6

:::callout-warning[C# requires the .NET build]
You must download Godot with the **.NET** suffix from godotengine.org. The standard build does not include the C# runtime. Once installed, C# is available alongside GDScript — both can coexist in the same project.
:::

### Setup

1. Download **Godot 4.6 (.NET)** from godotengine.org
2. Open your project and go to **Project → Tools → C# → Create C# Solution**
3. This creates a `.sln` and `.csproj` file — open in VS Code, Visual Studio, or Rider
4. Create C# scripts via **Script Attach → New Script** and choose C# as language

### C# Script Syntax in Godot

```csharp
using Godot;

// class_name equivalent: the class name IS the type — no declaration needed
// The [GlobalClass] attribute makes it visible in the editor like class_name
[GlobalClass]
public partial class PlayerController : CharacterBody2D
{
    // @export → [Export]
    [Export] public int MaxHealth { get; set; } = 100;
    [Export] public float Speed { get; set; } = 200.0f;

    private int _currentHealth;

    // _ready() → override _Ready()
    public override void _Ready()
    {
        _currentHealth = MaxHealth;
    }

    // _process() → override _Process()
    public override void _Process(double delta)
    {
        // Input uses the same names as GDScript
        if (Input.IsActionPressed("move_right"))
        {
            Velocity = new Vector2(Speed, Velocity.Y);
        }
        MoveAndSlide();
    }

    // Custom method with typed parameters
    public void TakeDamage(int amount)
    {
        _currentHealth = Mathf.Max(0, _currentHealth - amount);
        if (_currentHealth == 0)
            EmitSignal(SignalName.Died);
    }
}
```

### Signals in C#

```csharp
// Declare a signal
[Signal] public delegate void DiedEventHandler();
[Signal] public delegate void DamagedEventHandler(int amount, Node source);

// Emit a signal
EmitSignal(SignalName.Died);
EmitSignal(SignalName.Damaged, 25, attackerNode);

// Connect to a signal (from C#)
someNode.Connect(PlayerController.SignalName.Died, Callable.From(OnPlayerDied));

// Using lambda (C# syntax)
someNode.Connect(PlayerController.SignalName.Damaged,
    Callable.From((int amt, GodotObject src) => GD.Print($"Took {amt} damage")));
```

### C# Strengths in Godot

- Statically compiled — AOT on all platforms including iOS and web
- Access to the entire .NET ecosystem (NuGet packages)
- Better IDE support (Intellisense, refactoring tools in Rider/Visual Studio)
- LINQ for data queries — powerful functional-style collection processing
- Faster for computation-heavy code that runs thousands of iterations

### C# Limitations in Godot

- More verbose than GDScript for the same Godot-specific operations
- Godot-C# bindings have slightly higher function-call overhead than GDScript when calling engine methods
- Garbage collector pauses (though modern .NET GC is very well-tuned)
- No hot reload (must rebuild the project to see changes)
- Larger export size due to .NET runtime

## 3 · Head-to-Head Comparison

| Criterion | GDScript | C# | GDExtension (C++) |
| --- | --- | --- | --- |
| Setup time | Zero | ~5 min (.NET SDK) | Hours (toolchain, SConstruct) |
| Performance | Good (typed) | Very good | Native speed |
| Godot API feel | First-class | Thin wrapper | Thin wrapper |
| Hot reload | Yes | No | No |
| iOS / Web AOT | Yes (4.4+) | Yes | Yes |
| External libraries | None | NuGet ecosystem | Any C/C++ library |
| Concurrency | Thread-safe (with care) | .NET threading, async/await | Full C++ threading |
| Binary size overhead | Minimal | +20–40 MB (.NET runtime) | Depends on library |
| Learning curve | Easy | Medium (OOP + Godot bindings) | Very hard |
| Documentation quality | Best | Good | Sparse (read source) |

## 4 · Mixing GDScript and C# in One Project

:::callout-tip[They can coexist]
You can use both GDScript and C# in the same project. Typical pattern: write gameplay scripts in GDScript for fast iteration, write performance-critical systems (pathfinding, procedural generation, complex simulation) in C#, and expose them to GDScript via signals and exported methods.
:::

:::callout-pitfall[Cannot directly reference C# class\_names from GDScript (and vice versa)]
GDScript can use a C# node's exported properties and call its methods via the Godot API (as if it were any other Node). But you cannot write `var x: MyCSharpClass` in GDScript and get autocomplete for its custom methods — the type system doesn't cross the language boundary. Communicate via signals and Godot's `call()` method.
:::

```gdscript
# gdscript calling a C# node's exported method
func _ready() -> void:
    var pathfinder = $CSharpPathfinder   # typed as Node in GDScript
    var path = pathfinder.call("find_path", start_pos, end_pos)
    # or use the signal pattern: pathfinder.path_found.connect(my_callback)
```

## 5 · GDExtension — Native Code Intro

:::callout-intuition[Intuition]
GDExtension lets you write classes in C++ (or Rust, Swift, Python via third-party bindings) that appear in Godot exactly like built-in classes. A GDExtension class shows up in the node picker, has an Inspector, and is fully accessible from GDScript or C#. It is how most third-party native libraries reach Godot — Jolt reached it that way
 too, as the godot-jolt extension, before it was absorbed into the engine binary in 4.4.
:::

### When You Need GDExtension

- You need to run C/C++ libraries (Box2D, Bullet Physics, FMOD, custom AI inference)
- You have algorithms that genuinely run 10–100× slower in GDScript/C# than needed
- You want to ship a reusable Godot plugin that other projects can use as a compiled library
- You're working at the engine level (custom renderer features, editor tool plugins)

### Core Concepts (C++ side)

GDExtension uses the `godot-cpp` header-only library. Your class inherits from a Godot class (like `Node` or `Resource`) and uses macros to register itself with the engine:

```cpp
// fast_counter.h
#include <godot_cpp/classes/node.hpp>
using namespace godot;

class FastCounter : public Node {
    GDCLASS(FastCounter, Node)   // macro: declares GDVIRTUAL overrides
private:
    int64_t _count = 0;
protected:
    static void _bind_methods();  // must implement this to expose to GDScript
public:
    void increment(int64_t amount);
    int64_t get_count() const { return _count; }
    void set_count(int64_t val) { _count = val; }
};
```

```cpp
// fast_counter.cpp
#include "fast_counter.h"
#include <godot_cpp/core/class_db.hpp>

void FastCounter::_bind_methods() {
    // Expose method to GDScript
    ClassDB::bind_method(D_METHOD("increment", "amount"), &FastCounter::increment);
    // Expose as a property (get/set pair)
    ClassDB::bind_method(D_METHOD("get_count"), &FastCounter::get_count);
    ClassDB::bind_method(D_METHOD("set_count", "value"), &FastCounter::set_count);
    ADD_PROPERTY(PropertyInfo(Variant::INT, "count"), "set_count", "get_count");
    // Emit a signal (declare it here, emit from code with emit_signal())
    ADD_SIGNAL(MethodInfo("count_changed", PropertyInfo(Variant::INT, "new_value")));
}

void FastCounter::increment(int64_t amount) {
    _count += amount;
    emit_signal("count_changed", _count);
}
```

After building with SCons, place the compiled `.gdextension` descriptor file in your project — Godot loads the shared library and registers `FastCounter` as a node type, fully usable from GDScript:

```gdscript
# GDScript using the GDExtension class like any other node
var counter := FastCounter.new()
counter.increment(10)
print(counter.count)   # 10
counter.count_changed.connect(func(v): print("Count: ", v))
```

:::callout-warning[GDExtension development cost]
Setting up a GDExtension project requires: installing C++ build tools, cloning godot-cpp, configuring SConstruct build scripts, and dealing with ABI compatibility between your compiled library and the Godot version. Expect 2–4 hours of setup even with experience. Only reach for GDExtension when the performance need is clearly demonstrated by profiling.
:::

## 6 · Which Should You Choose?

| If you are… | Start with… |
| --- | --- |
| A solo indie dev or hobbyist | GDScript — least friction, best iteration speed |
| Coming from Unity / C# | C# — familiar syntax, same ecosystem |
| Building a simulation or pathfinding-heavy game | GDScript first, profile, then C# for hot paths |
| Integrating a C/C++ physics or audio library | GDExtension — the only option that lets you call C directly |
| Building a publishable Godot plugin | GDExtension (or GDScript for simpler plugins) |
| Targeting iOS or web with full AOT | Either GDScript 4.4+ or C# |
| In a team with C# devs | C# — use existing expertise |

:::callout-key[The expert consensus]
Most professional Godot games ship entirely in GDScript with full static typing. C# sees heavy use in teams coming from Unity. GDExtension is rare in commercial games — used almost exclusively for engine-level plugins (physics, rendering, platform integrations). Don't pre-optimize into GDExtension before you have a real bottleneck proven by the profiler.
:::

:::summary
## Chapter Summary

| Language | Best for | Main trade-off |
| --- | --- | --- |
| GDScript | Most game logic, solo/small team, rapid prototyping | Slower than C++ for heavy computation |
| C# (.NET) | Computation-heavy systems, teams with C# background, NuGet libraries | No hot reload; slightly verbose for Godot-specific APIs |
| GDExtension | Native libraries, max performance, engine-level plugins | Very high setup complexity; ABI fragility |

| C# mapping | GDScript equivalent |
| --- | --- |
| `[Export]` | `@export` |
| `[GlobalClass]` | `class_name` |
| `override _Ready()` | `func _ready():` |
| `[Signal] delegate void DiedEventHandler()` | `signal died` |
| `EmitSignal(SignalName.Died)` | `died.emit()` |
| `GDCLASS(MyClass, ParentClass)` | extends keyword (C++ macro) |
| `ClassDB::bind_method()` | Automatic in GDScript |
| `ADD_PROPERTY()` | `@export` |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
Name two reasons you might choose C# over GDScript for a Godot project, and one reason you'd stick with GDScript.

::::solution[Solution]
**C# reasons:** (1) Your team already knows C# from Unity or .NET background — no relearning. (2) You need a NuGet package (e.g., a JSON library, networking library) that has no GDScript equivalent.

 **Stay GDScript:** Hot reload — you can modify scripts and see changes in the running game instantly without rebuilding, which is invaluable for rapid iteration.
::::
:::

:::problem[2 easy]{difficulty="easy"}
Translate this GDScript export to the equivalent C# attribute syntax:

```gdscript
@export var move_speed: float = 300.0
@export var jump_height: int = 5
```

::::solution[Solution]
```csharp
[Export] public float MoveSpeed { get; set; } = 300.0f;
[Export] public int JumpHeight { get; set; } = 5;
```
::::
:::

:::problem[3 standard]{difficulty="standard"}
Translate this GDScript signal declaration and emission to C#:

```gdscript
signal item_picked_up(item_name: String, value: int)
# later...
item_picked_up.emit("Gold Coin", 25)
```

::::solution[Solution]
```csharp
// Declaration:
[Signal] public delegate void ItemPickedUpEventHandler(string itemName, int value);

// Emission:
EmitSignal(SignalName.ItemPickedUp, "Gold Coin", 25);
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
Describe the three things you need to do in a GDExtension C++ class to expose a method and a property to GDScript (without writing all the code — just explain the steps).

::::solution[Solution]
1. Use the `GDCLASS(MyClass, ParentClass)` macro in the class header — this declares the virtual override entry points.
2. Implement `static void _bind_methods()` and inside it call `ClassDB::bind_method()` for each method you want to expose.
3. For a property, also call `ADD_PROPERTY(PropertyInfo(...), "setter_name", "getter_name")` after binding the setter and getter methods.
::::
:::

:::problem[5 challenge]{difficulty="challenge"}
You have a GDScript game with a procedural terrain generator that currently takes 200ms per chunk and causes visible hitches. In order, describe: (1) what you should do first, (2) how you'd determine if C# would help, and (3) what signals/methods you'd design to let a C# generator work transparently with the rest of a GDScript codebase.

::::solution[Solution]
**1. Profile first** — use Godot's built-in profiler (Debugger → Profiler) to confirm the bottleneck is genuinely in the generation algorithm and not in I/O, rendering, or something else. Measure actual self-time on the generation function.

**2. Benchmark in C#** — port just the generation algorithm to C# and measure. C# shines for tight loops over arrays (math-heavy operations). If the speedup isn't 3–5×, the bottleneck might be the Godot API calls (which have similar overhead in both languages).

**3. Design the interface** — expose the C# generator with: a signal `[Signal] delegate void ChunkReadyEventHandler(Vector2I coord, PackedByteArray heightmap)` and a method `void RequestChunk(Vector2I coord)`. GDScript connects to the signal and calls `request_chunk(coord)` via the Godot API. The implementation language is invisible to the callers.
::::
:::
