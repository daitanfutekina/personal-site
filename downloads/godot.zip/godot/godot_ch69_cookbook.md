---
title: "Mechanic Cookbook — Jump, Dash, Dialogue, Projectiles, Pickups & More"
source: "godot_ch69_cookbook.html"
---

Part XII · Chapter 69

Capstone

# Mechanic Cookbook — Jump, Dash, Dialogue, Projectiles, Pickups & More

Estimated study time: 140 min · Godot 4.x · GDScript

## Chapter Overview

This chapter is a reference cookbook — copy-paste starting points for the most common
 game mechanics. Each recipe is self-contained, minimal, and designed to be dropped into
 any project. Most are 20–60 lines. Polish and extend to fit your game.

:::callout-tip[How to Use This Chapter]
Each recipe assumes a CharacterBody2D (or 3D) player unless stated otherwise.
  Adapt constants to your game's scale. All code is GDScript 4.x.
:::

## Recipe 1 — Coyote Time & Jump Buffer

These two are the difference between a platformer that feels tight and one that
feels like it is arguing with you. Both exist because the player's sense of when they
jumped and the engine's record of when they jumped are not the same thing.

**Coyote time** is named for the cartoon: you walk off a ledge and, for a
moment, nothing bad happens. A player who presses jump two frames after leaving the
platform believes they pressed it while standing on it, and at sixty frames a second they
are almost right. `_coyote_timer` is set to its full value on every frame the
body is on the floor and counts down once it is not, so it answers “how long ago was
I last standing on something?”

**Jump buffering** is the same forgiveness pointed the other way. A player
falling towards the ground presses jump slightly early; without a buffer the input lands
on a frame where `is_on_floor()` is still false and is discarded, and the
character thumps down and stands there. `_buffer_timer` remembers the press for
a moment so that landing can consume it.

The jump fires only when both timers are positive — recently grounded
*and* recently asked. Zeroing both on takeoff is what stops one press from being
spent twice.

:::callout-pitfall[Pitfall]
0.12 seconds is about seven frames at 60 Hz, which is generous. Tune it by feel and
  not by principle: too little and the forgiveness is imperceptible, too much and players
  notice they are jumping from mid-air. If a jump ever fires twice from one press, check
  that both timers are being zeroed, not just one.
:::

Two techniques that make platformer jumps feel fair: **coyote time**
 (you can jump briefly after walking off a ledge) and **jump buffer**
 (pressing jump just before landing still registers).

```gdscript
extends CharacterBody2D

const SPEED        := 200.0
const JUMP_SPEED   := -400.0
const GRAVITY      := 980.0
const COYOTE_TIME  := 0.12   ## seconds you can jump after leaving ground
const JUMP_BUFFER  := 0.12   ## seconds before landing that jump input is remembered

var _coyote_timer  := 0.0
var _buffer_timer  := 0.0

func _physics_process(delta: float) -> void:
    # Gravity
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    # Coyote timer counts down after leaving floor
    if is_on_floor():
        _coyote_timer = COYOTE_TIME
    else:
        _coyote_timer -= delta

    # Jump buffer counts down when jump pressed in air
    if Input.is_action_just_pressed("jump"):
        _buffer_timer = JUMP_BUFFER
    else:
        _buffer_timer -= delta

    # Jump if within coyote window AND buffer window
    if _buffer_timer > 0.0 and _coyote_timer > 0.0:
        velocity.y    = JUMP_SPEED
        _coyote_timer = 0.0
        _buffer_timer = 0.0

    # Variable jump height — release early for shorter jump
    if Input.is_action_just_released("jump") and velocity.y < 0.0:
        velocity.y *= 0.4

    velocity.x = Input.get_axis("move_left", "move_right") * SPEED
    move_and_slide()
```

## Recipe 2 — Dash with Cooldown & Invincibility

A dash is three states pretending to be one: winding up, moving, and cooling down.
Only the middle one is visible, and the other two are what keep it from being an infinite
speed boost.

While `_dashing` is true the recipe assigns `velocity` outright
rather than adding to it. That is the important line. A dash that adds to the existing
velocity inherits whatever the player was already doing, so dashing downhill goes further
than dashing uphill and the move stops being predictable. Overwriting makes every dash the
same length, which is what a player learning your game needs.

`invincible` is a plain boolean rather than anything cleverer because the
hurtbox only ever asks one question of it. Making the dash a dodge is most of what turns a
movement ability into a combat one.

:::callout-pitfall[Pitfall]
The fallback direction is

Vector2.RIGHT \* sign(scale.x)

, which assumes you
  flip the sprite by negating its horizontal scale. If you flip with

Sprite2D.flip\_h

instead,

scale.x

stays positive and a
  standing dash always goes right. Keep a

\_facing

variable if you are unsure
  which convention your project uses.
:::

```gdscript
extends CharacterBody2D

const DASH_SPEED    := 600.0
const DASH_DURATION := 0.15
const DASH_COOLDOWN := 0.6

var _dashing        := false
var _dash_dir       := Vector2.ZERO
var _dash_timer     := 0.0
var _cooldown_timer := 0.0
var invincible      := false    ## checked by HurtboxComponent

func _physics_process(delta: float) -> void:
    _cooldown_timer -= delta

    if not _dashing and _cooldown_timer <= 0.0 and Input.is_action_just_pressed("dash"):
        _start_dash()

    if _dashing:
        _dash_timer -= delta
        velocity = _dash_dir * DASH_SPEED
        if _dash_timer <= 0.0:
            _end_dash()

    move_and_slide()

func _start_dash() -> void:
    _dashing        = true
    invincible      = true
    _dash_timer     = DASH_DURATION
    _cooldown_timer = DASH_COOLDOWN
    # Dash in movement direction, or forward if standing still
    var input := Input.get_vector("move_left","move_right","move_up","move_down")
    _dash_dir = input if input != Vector2.ZERO else Vector2.RIGHT * sign(scale.x)
    # Optional: ghost trail effect
    create_tween().tween_property(self, "modulate:a", 0.4, DASH_DURATION)

func _end_dash() -> void:
    _dashing   = false
    invincible = false
    create_tween().tween_property(self, "modulate:a", 1.0, 0.1)
```

## Recipe 3 — Wall Slide & Wall Jump

Wall movement is mostly one decision made twice: is the character touching a wall
and nothing else? `is_on_wall_only()` answers exactly that, and it is the reason
this recipe is short. The plain `is_on_wall()` is also true while standing in a
corner, so a character who walked into a wall on the ground would start wall-sliding on
the spot.

The slide itself is not a separate mode. It is ordinary gravity with a smaller number,
chosen on each frame and only while the character is already moving downward — so
jumping upward alongside a wall is unaffected, and the slow fall begins the moment the
character starts to descend.

`get_wall_normal()` returns a vector pointing away from the surface, which
means the push direction never has to be worked out from which key is held. Multiply it by
the push strength and the character leaves a left-hand wall rightwards and a right-hand
wall leftwards, with the same line of code.

:::callout-pitfall[Pitfall]
Horizontal input is ignored entirely while on a wall. That is deliberate — it stops
  the player from cancelling their own wall jump by holding the direction of the wall —
  but it also means a player cannot steer away from a wall while sliding. Most games allow
  it after a short lockout rather than never; add a timer if yours should.
:::

```gdscript
extends CharacterBody2D

const SPEED          := 200.0
const JUMP_SPEED     := -420.0
const WALL_JUMP_PUSH := 250.0   ## horizontal force away from wall
const GRAVITY        := 980.0
const WALL_SLIDE_GRAVITY := 200.0   ## slower fall while sliding

func _physics_process(delta: float) -> void:
    var on_wall := is_on_wall_only()

    # Gravity (slow while wall sliding)
    var grav := WALL_SLIDE_GRAVITY if on_wall and velocity.y > 0.0 else GRAVITY
    if not is_on_floor():
        velocity.y += grav * delta

    # Wall jump
    if on_wall and Input.is_action_just_pressed("jump"):
        var wall_normal := get_wall_normal()
        velocity.x = wall_normal.x * WALL_JUMP_PUSH
        velocity.y = JUMP_SPEED
    elif is_on_floor() and Input.is_action_just_pressed("jump"):
        velocity.y = JUMP_SPEED

    if not on_wall:
        velocity.x = Input.get_axis("move_left", "move_right") * SPEED

    move_and_slide()
```

## Recipe 4 — Projectile with Object Pool

Instantiating a scene allocates; freeing it deallocates. Do either sixty times a
second and the cost shows up as stutter, which is why anything fired in quantity is
usually pooled. The pool builds every bullet once during
`_ready()`, keeps them all as children, and then never creates or destroys
another one — spawning becomes a search for a hidden bullet and a few assignments.

Visibility is doing double duty here as the free/in-use flag, which is compact but
worth being careful about, because *hiding a node does not switch it off*. An
invisible `Area2D` still overlaps, still emits `body_entered`, and a
recycled bullet left flying will go on dealing damage to everything it passes through. So
`recycle()` stops the physics process, zeroes the velocity, and turns
`monitoring` off; `spawn()` turns them back on. The
`set_deferred` is not decoration — changing `monitoring` during
a physics callback is not allowed, and the collision that recycles a bullet is a physics
callback.

:::callout-pitfall[Pitfall]
When the pool is exhausted this recipe silently drops the shot. That is the right
  default for bullets, where a missing one is invisible in the noise, and the wrong one
  for anything the player is counting. Size the pool for your worst case:
  fire rate multiplied by lifetime, rounded up.
:::

```gdscript
## BulletPool.gd (autoload) — reuse bullet nodes instead of queue_free + instantiate
extends Node

const BULLET_SCENE := preload("res://scenes/bullet.tscn")
const POOL_SIZE    := 32

var _pool: Array[Node] = []

func _ready() -> void:
    for i in POOL_SIZE:
        var b := BULLET_SCENE.instantiate()
        b.visible = false
        add_child(b)
        _pool.append(b)

func spawn(pos: Vector2, dir: Vector2, speed: float, damage: int) -> void:
    for b in _pool:
        if not b.visible:
            b.global_position = pos
            b.velocity         = dir.normalized() * speed
            b.damage           = damage
            b.visible          = true
            b.set_physics_process(true)
            b.set_deferred("monitoring", true)
            return
    # Pool exhausted — just ignore (or expand pool here)

## bullet.gd
extends Area2D

var velocity := Vector2.ZERO
var damage   := 10
const LIFETIME := 3.0
var _timer := 0.0

func _physics_process(delta: float) -> void:
    _timer += delta
    if _timer >= LIFETIME:
        recycle()
        return
    position += velocity * delta

func _on_body_entered(body: Node) -> void:
    if body.has_method("take_damage"):
        body.take_damage(damage)
    recycle()

func recycle() -> void:
    visible = false
    velocity = Vector2.ZERO
    set_physics_process(false)
    # Hiding a node does not stop its Area2D from reporting overlaps, so a
    # recycled bullet would go on damaging whatever it drifted through.
    # Deferred because monitoring cannot be changed during a physics callback.
    set_deferred("monitoring", false)
    _timer  = 0.0
```

## Recipe 5 — Pickups & Collectibles

A pickup is a trigger volume with a personality. The `Type` enum keeps
all four kinds in one scene rather than four near-identical ones, and the
`match` in the handler is where the kind finally matters — up to that
point a key and a coin are the same object.

The bobbing motion deserves a closer look, because it is the easiest tween in Godot to
get subtly wrong. `tween_property` takes an *absolute* target, evaluated
once when the tween is built. A single step to `position.y - 6.0` under
`set_loops()` therefore rises six pixels on the first pass and then, on every
pass after it, animates from that height to that same height: the pickup moves once and
sits still, with the loop dutifully running and nothing to show for it. Two steps — up,
then back to the starting height — give an actual oscillation.

The collection sequence is a tween as well, and the ordering is the point:
`tween_property` then `tween_callback` run one after the other by
default, so the pop finishes before `queue_free` is called. Freeing the node
immediately would delete the very thing being animated.

:::callout-pitfall[Pitfall]
body\_entered

fires for anything on a matching collision layer, so the group
  check is what stops enemies from hoovering up the player's coins. It is also worth
  guarding against collecting twice: two bodies overlapping on the same frame will run
  the handler twice before

queue\_free

takes effect.
:::

```gdscript
## Pickup.gd — attach to Area2D with CollisionShape + Sprite
extends Area2D

enum Type { COIN, HEALTH, AMMO, KEY }

@export var type    : Type = Type.COIN
@export var value   : int  = 1

func _ready() -> void:
    body_entered.connect(_on_collected)
    # Bob animation — two steps, up and back, or it only ever moves once
    var bob := create_tween().set_loops()
    bob.tween_property(self, "position:y", position.y - 6.0, 0.45) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    bob.tween_property(self, "position:y", position.y, 0.45) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func _on_collected(body: Node) -> void:
    if not body.is_in_group("player"): return
    match type:
        Type.COIN:   GameManager.add_score(value)
        Type.HEALTH: body.heal(value)
        Type.AMMO:   body.add_ammo(value)
        Type.KEY:    body.add_key(value)
    # Juice
    AudioManager.play_sfx(preload("res://audio/pickup.wav"))
    # Scale pop then free
    var t := create_tween()
    t.tween_property(self, "scale", Vector2(1.5, 1.5), 0.1)
    t.tween_callback(queue_free)
```

## Recipe 6 — Dialogue System

Two things make a dialogue box feel finished: text that arrives at reading speed
rather than all at once, and a world that stops moving while it is up. This recipe does
both, and the interaction between them is where it gets interesting.

The typewriter is built as a chain of callbacks separated by intervals, one per
character. It works because a GDScript lambda captures by value: each closure keeps its own
`i`, so callback seventeen still prints seventeen characters however long
afterwards it runs.

The pause is the trap. `get_tree().paused = true` stops every node whose
process mode does not say otherwise — and a `Tween` follows the process
mode of the node that created it. Pause the tree and the typewriter stops with everything
else, so the panel appears with a name, an empty body, and no way forward. The fix is one
line and it must come *before* the pause: set the box's
`process_mode` to `PROCESS_MODE_ALWAYS` so it keeps running while
the world does not.

:::callout-pitfall[Pitfall]
The same applies to the continue button. A

Button

under a paused tree stops
  processing input, so if the box is paused-out the player cannot dismiss it either.
  Setting the process mode on the dialogue root covers the whole subtree, which is why it
  is set there rather than on the label.
:::

```gdscript
## DialogueBox.gd — attach to CanvasLayer > Panel > VBoxContainer
extends Control

signal dialogue_finished

@onready var name_label   := $Panel/VBox/NameLabel   as Label
@onready var body_label   := $Panel/VBox/BodyLabel   as Label
@onready var continue_btn := $Panel/VBox/ContinueBtn as Button

var _lines: Array[Dictionary] = []
var _index := 0

func start(lines: Array[Dictionary]) -> void:
    _lines = lines
    _index = 0
    visible = true
    ## Pausing the tree pauses this node's tweens too, and the typewriter below
    ## is a tween -- without this the box appears with an empty body and stays
    ## that way. Must be set before the pause takes effect.
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = true   ## optional: pause game during dialogue
    _show_line()

func _show_line() -> void:
    var line := _lines[_index]
    name_label.text = line.get("name", "")
    body_label.text = ""
    # Typewriter effect
    var full := line.get("text", "")
    var t    := create_tween()
    for i in full.length() + 1:
        t.tween_callback(func(): body_label.text = full.left(i))
        t.tween_interval(0.03)

func _on_continue_pressed() -> void:
    _index += 1
    if _index >= _lines.size():
        visible = false
        get_tree().paused = false
        dialogue_finished.emit()
    else:
        _show_line()
```

```gdscript
## Usage:
$DialogueBox.start([
    { "name": "Guard", "text": "Halt! Who goes there?" },
    { "name": "Hero",  "text": "Just a traveller. Let me pass." },
    { "name": "Guard", "text": "...Very well. Move along." },
])
```

## Recipe 7 — Interactable Objects (E to Interact)

“Press E” is deceptively fiddly, because the interesting part is not the
key press but deciding *what* the key applies to. This recipe splits that in two:
`Interactable` is a marker that knows how to be interacted with and nothing
else, while the player owns the question of which one is currently in reach.

The split is what makes it reusable. A door, a chest and an NPC all get the same node
and differ only in what they connect `interacted` to — no shared base class
for unrelated objects, and no list of types in the player script that has to grow every
time you invent a new thing to touch.

Using `_unhandled_input` rather than `_input` matters more than it
looks: it runs only for events the UI has not already consumed, so pressing E with a menu
open does not also open the chest behind it.

:::callout-pitfall[Pitfall]
\_nearby

holds one interactable, and

\_on\_detection\_area\_exited

clears it unconditionally. Walk out of a chest's range while still inside a door's and
  the prompt vanishes even though something is still in reach. Keep an array and pick the
  closest each frame if your objects can overlap.
:::

```gdscript
## Interactable.gd — add to any object, player detects via Area2D overlap
class_name Interactable extends Node

signal interacted

@export var prompt_text := "Press [E] to interact"

func interact() -> void:
    interacted.emit()

## Player.gd — detect nearest interactable
var _nearby: Interactable = null

func _on_detection_area_entered(area: Area2D) -> void:
    var node := area.get_parent()
    if node is Interactable:
        _nearby = node
        $PromptLabel.text    = node.prompt_text
        $PromptLabel.visible = true

func _on_detection_area_exited(area: Area2D) -> void:
    _nearby = null
    $PromptLabel.visible = false

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("interact") and _nearby:
        _nearby.interact()
```

## Recipe 8 — Checkpoints & Respawn

A checkpoint is a small amount of state and a large amount of restraint.
`_activated` exists so that walking back through a checkpoint does not re-fire
its effects — the sound, the flag animation, the save — which is the single most
common complaint about hand-rolled checkpoint code.

Storing an `id` rather than a position is what makes checkpoints survive a
level being edited. A saved coordinate points at wherever that spot happens to be now,
which after a level revision may be inside a wall; a saved id points at the checkpoint
itself, and it can be moved freely.

```gdscript
## Checkpoint.gd
extends Area2D

@export var checkpoint_id: int = 0
var _activated := false

func _ready() -> void:
    body_entered.connect(_on_entered)

func _on_entered(body: Node) -> void:
    if _activated or not body.is_in_group("player"): return
    _activated = true
    SaveData.last_checkpoint = checkpoint_id
    SaveData.checkpoint_pos  = global_position
    # Visual feedback
    $AnimationPlayer.play("activate")

## Player.gd — respawn on death
func die() -> void:
    if SaveData.checkpoint_pos != Vector2.ZERO:
        global_position = SaveData.checkpoint_pos
        health = max_health
        GameManager.add_score(-50)   ## optional death penalty
    else:
        get_tree().reload_current_scene()
```

## Recipe 9 — Camera Follow & Room Transitions

Camera work is subtraction. The camera knows where the player is and where it
currently is, and each frame it removes some fraction of the difference — which
produces a follow that lags slightly under fast movement and settles when the player
stops, both of which read as weight.

Room-based clamping is the other half. Letting the camera show the void past the edge
of a level is the fastest way to make a game look unfinished, so the camera's limits are
set to the room's bounds on entry and the same follow code stops at the walls without
knowing anything about them.

```gdscript
## SmoothCamera2D.gd — attach Camera2D to player
extends Camera2D

@export var lookahead_speed := 200.0
@export var lookahead_dist  := 80.0
@export var smoothing       := 6.0

var _target_offset := Vector2.ZERO

func _process(delta: float) -> void:
    var input := Input.get_vector("move_left","move_right","move_up","move_down")
    _target_offset = _target_offset.lerp(input * lookahead_dist, lookahead_speed * delta)
    offset = offset.lerp(_target_offset, smoothing * delta)

## Room-based camera: lock to room bounds
func lock_to_room(room_rect: Rect2) -> void:
    limit_left   = int(room_rect.position.x)
    limit_top    = int(room_rect.position.y)
    limit_right  = int(room_rect.end.x)
    limit_bottom = int(room_rect.end.y)
```

## Recipe 10 — Wave / Enemy Spawner

A spawner is a schedule and a budget. The schedule decides when the next enemy
appears; the budget decides how many may exist at once. Without the second, a player who
stops killing things accumulates an unbounded crowd and the frame rate answers for it.

Counting living enemies by tracking a number rather than by querying the scene tree each
frame is deliberate: `get_tree().get_nodes_in_group()` allocates an array every
call, and a spawner calls it often enough to matter.

```gdscript
## WaveSpawner.gd
extends Node2D

const ENEMY := preload("res://scenes/enemy.tscn")

@export var wave_definitions: Array[Dictionary] = [
    { "count": 3, "interval": 2.0, "delay": 0.0 },
    { "count": 5, "interval": 1.5, "delay": 1.0 },
    { "count": 8, "interval": 1.0, "delay": 2.0 },
]

var _wave_index := 0

func _ready() -> void:
    start_wave(0)

func start_wave(index: int) -> void:
    _wave_index = index
    if index >= wave_definitions.size(): return
    var wave := wave_definitions[index]
    await get_tree().create_timer(wave.delay).timeout
    for i in wave.count:
        _spawn_enemy()
        await get_tree().create_timer(wave.interval).timeout

func _spawn_enemy() -> void:
    var spawn_points := $SpawnPoints.get_children()
    var pt           := spawn_points[randi() % spawn_points.size()] as Node2D
    var e            := ENEMY.instantiate()
    e.global_position = pt.global_position
    get_parent().add_child(e)
    e.died.connect(func(): _on_enemy_died(), CONNECT_ONE_SHOT)

var _alive := 0

func _on_enemy_died() -> void:
    _alive -= 1
    if _alive <= 0:
        start_wave(_wave_index + 1)
```

## Recipe 11 — Homing Projectile

Homing is a steering problem, not an aiming one. A missile that points straight
at its target every frame is unmissable and therefore not interesting; one that can only
turn so fast per second can be outmanoeuvred, which is the whole point of giving the player
a missile to dodge.

That turn rate is the single number that decides how the weapon feels. Low values make a
missile that arcs lazily and can be led away from; high values make one that is effectively
hitscan with a delay. Everything else in the recipe is bookkeeping around it.

```gdscript
## HomingMissile.gd — extends Area2D
extends Area2D

var speed       := 250.0
var turn_speed  := 4.0   ## radians/s
var damage      := 20
var _target: Node2D

func _ready() -> void:
    # Auto-find nearest enemy
    var enemies := get_tree().get_nodes_in_group("enemies")
    if not enemies.is_empty():
        _target = enemies[0] as Node2D
    body_entered.connect(func(b): _hit(b))
    # Auto-free after 4 seconds
    get_tree().create_timer(4.0).timeout.connect(queue_free)

func _physics_process(delta: float) -> void:
    if _target and is_instance_valid(_target):
        var to_target := (_target.global_position - global_position).angle()
        rotation = lerp_angle(rotation, to_target, turn_speed * delta)
    # Move forward regardless
    position += Vector2.RIGHT.rotated(rotation) * speed * delta

func _hit(body: Node) -> void:
    if body.has_method("take_damage"):
        body.take_damage(damage)
    ImpactSpawner.spawn(global_position)
    queue_free()
```

:::summary
### Chapter 69 — Cookbook Index

| # | Mechanic | Key technique |
| --- | --- | --- |
| 1 | Coyote Time + Jump Buffer | Two timers counting down independently |
| 2 | Dash with Invincibility | Velocity override + cooldown + tween |
| 3 | Wall Slide + Wall Jump | is\_on\_wall\_only() + get\_wall\_normal() |
| 4 | Projectile + Object Pool | Pre-instantiated pool, visible toggle |
| 5 | Pickups / Collectibles | Area2D + body\_entered + enum type |
| 6 | Dialogue System | Line array, typewriter tween, pause tree |
| 7 | Interactable (E to use) | Detection Area2D + nearest interactable |
| 8 | Checkpoints + Respawn | SaveData autoload stores position |
| 9 | Smooth Camera + Room Lock | Lookahead lerp + Camera2D limits |
| 10 | Wave Spawner | await timer between spawns, death counter |
| 11 | Homing Projectile | lerp\_angle toward target each frame |
:::

## Recipe 12 — Knockback & Stagger

Enemies (and players) that react visibly to taking damage feel far more satisfying. Knockback applies a velocity impulse away from the hit source; stagger freezes input briefly.

```gdscript
# In the entity's health/hit-reaction script
const KNOCKBACK_FORCE := 400.0
const STAGGER_TIME   := 0.3

var _staggered := false

func take_hit(attacker_position: Vector2) -> void:
    var dir := (global_position - attacker_position).normalized()
    velocity += dir * KNOCKBACK_FORCE   # CharacterBody2D owns `velocity`
    _stagger()

func _stagger() -> void:
    _staggered = true
    await get_tree().create_timer(STAGGER_TIME).timeout
    _staggered = false

func _physics_process(delta: float) -> void:
    if not _staggered:
        _handle_input(delta)       # normal movement input
    # Friction/deceleration applies even while staggered
    velocity = velocity.move_toward(Vector2.ZERO, 800 * delta)
    move_and_slide()
```

:::callout-tip[Polish touch]
Play a "hit flash" by modulating the sprite to white for a frame:

sprite.modulate = Color.WHITE; await get\_tree().process\_frame; sprite.modulate = Color(1,1,1,1)
:::

## Recipe 13 — Screen Shake

A brief camera shake on impact sells every explosion, heavy landing, and big hit. Done via a Tween on the camera offset so it automatically returns to centre.

```gdscript
# In your Camera2D script (or any Autoload)
func shake(duration: float = 0.3, strength: float = 12.0) -> void:
    var tw := create_tween().set_trans(Tween.TRANS_SINE)
    var steps := int(duration / 0.05)          # one shake per 50 ms
    for i in steps:
        var target := Vector2(
            randf_range(-strength, strength),
            randf_range(-strength, strength)
        )
        tw.tween_property(self, "offset", target, 0.05)
    tw.tween_property(self, "offset", Vector2.ZERO, 0.1)  # return to centre
```

Call from anywhere that has a reference to the camera: `camera.shake(0.4, 16)`

:::callout-tip[Autoload pattern]
Move the camera reference into an Autoload (e.g.

CameraController

) so any script can call

CameraController.shake()

without holding a direct node reference.
:::

## Recipe 14 — Day / Night Cycle

Animate the sky colour and sun angle over time using a Tween or AnimationPlayer targeting WorldEnvironment properties.

```gdscript
@export var day_length_seconds := 120.0   # real seconds per in-game day
@onready var env: WorldEnvironment = $WorldEnvironment
@onready var sun: DirectionalLight3D = $Sun

var _time := 0.0   # 0..1 normalised day progress

func _process(delta: float) -> void:
    _time = fmod(_time + delta / day_length_seconds, 1.0)
    var angle := lerp(-90.0, 270.0, _time)          # sun arc in degrees
    sun.rotation_degrees.x = angle

    # Modulate ambient light: blue-ish night → warm day
    var t := smoothstep(0.25, 0.5, _time) * (1.0 - smoothstep(0.75, 0.9, _time))
    env.environment.ambient_light_color = Color(0.4, 0.5, 0.8).lerp(Color(1.0, 0.95, 0.8), t)
    env.environment.ambient_light_energy = lerp(0.3, 1.5, t)
```

## Recipe 15 — Footstep Sounds

Footsteps should vary by surface and randomise pitch slightly so they never sound robotic. The classic approach combines a Timer with a random pitch/sample.

```gdscript
@export var footstep_sounds: Array[AudioStream] = []   # load several variants in Inspector
@onready var player := $AudioStreamPlayer2D
@onready var step_timer := $StepTimer

const STEP_INTERVAL := 0.35     # seconds between footsteps

func _physics_process(_delta: float) -> void:
    var moving := velocity.length() > 10.0 and is_on_floor()
    if moving and not step_timer.is_stopped():
        return
    if moving:
        step_timer.start(STEP_INTERVAL)
        _play_footstep()
    elif not moving:
        step_timer.stop()

func _play_footstep() -> void:
    player.stream = footstep_sounds.pick_random()
    player.pitch_scale = randf_range(0.9, 1.1)
    player.play()
```

:::callout-tip[Surface detection]
Use

get\_floor\_collision\_layer()

or a RayCast that hits a TileMapLayer to determine the surface type, then pick from a different sound pool for wood vs. grass vs. stone.
:::

## Recipe 16 — Simple Inventory Slot UI

A minimal grid inventory using a GridContainer and custom slot Controls. Items are stored as a Resource array; the UI reads from it.

```gdscript
# item_slot.gd — attached to each slot Control
@onready var icon: TextureRect = $Icon
@onready var count_label: Label = $Count

func set_item(item: ItemData) -> void:   # ItemData is a custom Resource
    if item == null:
        icon.texture = null
        count_label.text = ""
        return
    icon.texture = item.icon
    count_label.text = str(item.quantity) if item.quantity > 1 else ""

# inventory_ui.gd — the GridContainer parent
func refresh(items: Array) -> void:
    for i in slot_nodes.size():
        slot_nodes[i].set_item(items[i] if i < items.size() else null)
```

Connect your `Inventory` Autoload's `changed` signal to `refresh()` so the UI updates whenever the player picks up or drops an item.
