---
title: "Music, Looping, Crossfades & Adaptive Audio"
source: "godot_ch45_music_adaptive.html"
---

Part VI · Chapter 45

# Music, Looping, Crossfades & Adaptive Audio

Estimated study time: 70 min · Godot 4.6 · GDScript

## Overview

Background music in a game lives by different rules than sound effects. A 3-minute track needs to feel seamless when it loops, transition smoothly to a different mood when the player enters combat, and ideally respond in real-time to what is happening on screen — the tension rising as enemies approach, the melody opening up when a secret is discovered.

This chapter covers everything from the lowest level (loop points baked into audio files) to the highest level (AudioStreamInteractive state machines and real-time procedural synthesis). You will also build a reusable `MusicManager` autoload that handles crossfading correctly and is easy to drive from any system in your game.

### Prerequisites

- Ch 43 — AudioStreamPlayer and the three player nodes
- Ch 44 — Audio buses and effects
- Tween basics (Ch 28)
- Autoloads / singletons (Ch 21)

## Loop Settings in Audio Files

Before Godot can loop a track seamlessly it needs to know two things: *should* it loop, and *where* should it jump when it reaches the end. These settings live inside the **import** settings for each audio file, not at runtime — you set them once and they are baked into the imported resource.

### Ogg Vorbis (`AudioStreamOggVorbis`)

Ogg is the recommended format for music in Godot because its loop settings are part of the stream's metadata and survive re-imports reliably.

| Property | Type | Description |
| --- | --- | --- |
| loop | bool | Whether the stream loops at all. Default `false`. |
| loop\_offset | float (seconds) | Time to jump to when the stream reaches its end. Use this to skip into/outros. |

You set these either in the Import dock (select the .ogg file in the FileSystem dock, then open the Import tab) or at runtime:

```gdscript
var stream: AudioStreamOggVorbis = preload("res://music/boss_theme.ogg")
stream.loop = true
stream.loop_offset = 4.2  # after a 4.2-second intro, loop back here
$MusicPlayer.stream = stream
$MusicPlayer.play()
```

:::callout-tip[Tip — bake it in the import settings]
Setting loop and loop\_offset in the Import dock means the correct values are always there when the resource is loaded, even if you forget to set them in code. Right-click the .ogg in the FileSystem and choose "Reimport" after changing import settings.
:::

### MP3 (`AudioStreamMP3`)

MP3 has the same loop properties but a quirk: MP3's encoder introduces a small silence gap at the start and end of the file (the "encoder delay"). This makes perfectly gapless looping impossible without careful trimming. Use Ogg or WAV for anything that needs a precise loop point.

| Property | Type | Description |
| --- | --- | --- |
| loop | bool | Enable looping. |
| loop\_offset | float (seconds) | Jump target when stream ends. |
| bpm | float | Optional metadata — beats per minute. Not used by the engine directly. |
| beat\_count | int | Optional metadata — total beats in the file. |
| bar\_beats | int | Optional metadata — beats per bar. |

:::callout-pitfall[Pitfall — MP3 encoder delay]
MP3 always has ~26 ms of silence padded at the start due to encoding. For game audio, this means your loop will have a tiny click or silence each time it wraps. Use **Ogg Vorbis for music** and reserve MP3 only for voice-over or non-looping stings where the gap is imperceptible.
:::

### WAV (`AudioStreamWAV`)

WAV stores loop points as sample offsets rather than seconds. WAV is uncompressed and large, so it is only practical for short music loops or procedural audio buffers (see §5).

| Property | Type | Description |
| --- | --- | --- |
| loop\_mode | enum | `LOOP_DISABLED`, `LOOP_FORWARD`, `LOOP_PINGPONG`, `LOOP_BACKWARD` |
| loop\_begin | int (samples) | Sample index where the loop begins on wrap. |
| loop\_end | int (samples) | Sample index that triggers the wrap. |
| mix\_rate | int (Hz) | Samples per second (typically 44100 or 48000). |
| stereo | bool | Whether the data is interleaved stereo. |
| format | enum | `FORMAT_8_BITS`, `FORMAT_16_BITS`, `FORMAT_IMA_ADPCM`, `FORMAT_QOA` |
| data | PackedByteArray | Raw PCM sample data. Written when generating procedural audio. |

:::callout-connect[Loop point conversion]
To convert seconds → samples: `samples = seconds × mix_rate`. A loop start at 4.2 s in a 44100 Hz file is sample `185220`. Most DAWs can export WAV files with loop cue points embedded; Godot reads these automatically on import.
:::

## Crossfading Between Tracks

A hard cut between two music tracks is jarring. Crossfading smoothly reduces the outgoing track's volume while raising the incoming track's, typically over 1–3 seconds. Godot's Tween system makes this easy to implement correctly.

Crossfade — Volume over time

0 dB

−80 dB

0s

transition start

transition end

t

crossfade window (1–3s)

Track A (outgoing)

Track B (incoming)

−6 dB crossover

(equal-power point)

player\_a (playing)

player\_b (silent)

→ swap roles after transition →

Two AudioStreamPlayers, one always silent. On transition: start Track B at −80 dB, then tween both simultaneously — A fades out while B fades in. Swap their "active" roles once the fade completes.

### The Tween Method

The pattern: keep **two** AudioStreamPlayers. One is the currently-playing track; the other is silent. When a transition is requested, start the new track on the silent player at volume −80 dB, then tween both players simultaneously — old one fades out, new one fades in. Swap their roles when done.

```gdscript
extends Node

@onready var player_a: AudioStreamPlayer = $PlayerA
@onready var player_b: AudioStreamPlayer = $PlayerB

var _active: AudioStreamPlayer   # currently audible player
var _idle:   AudioStreamPlayer   # currently silent player
var _tween:  Tween

func _ready() -> void:
    player_a.bus = "Music"
    player_b.bus = "Music"
    player_b.volume_db = -80.0
    _active = player_a
    _idle   = player_b

func play_track(stream: AudioStream, fade_time: float = 1.5) -> void:
    # Cancel any in-progress fade
    if _tween:
        _tween.kill()

    _idle.stream = stream
    _idle.volume_db = -80.0
    _idle.play()

    _tween = create_tween().set_parallel(true)
    _tween.tween_property(_active, "volume_db", -80.0, fade_time)
    _tween.tween_property(_idle,   "volume_db",   0.0, fade_time)

    # Swap roles after the fade
    await _tween.finished
    _active.stop()
    var tmp = _active
    _active = _idle
    _idle   = tmp
```

:::callout-tip[Tip — use dB interpolation, not linear]
Tweening volume\_db directly gives a perceptually smooth fade because dB is already a logarithmic scale. If you tween a linear 0–1 amplitude value and convert, the fade sounds fine but you have to do the math yourself. Stick to volume\_db.
:::

### Full MusicManager Autoload

A production-ready MusicManager handles: crossfades, loop control, pausing (for menus), and a "nothing playing" state. Register this as an autoload under **Project → Project Settings → Autoloads** with the name `MusicManager`.

```gdscript
# music_manager.gd
extends Node

const FADE_IN  := 1.5
const FADE_OUT := 1.5

@onready var _a: AudioStreamPlayer = $A
@onready var _b: AudioStreamPlayer = $B

var _current: AudioStreamPlayer
var _next:    AudioStreamPlayer
var _tween:   Tween
var _current_stream: AudioStream = null

func _ready() -> void:
    for p in [_a, _b]:
        p.bus = "Music"
        p.volume_db = -80.0

    _current = _a
    _next    = _b

## Play a new track, crossfading from whatever is currently playing.
## Pass force_restart=true to restart even if the same stream is already playing.
func play(stream: AudioStream, force_restart: bool = false) -> void:
    if stream == _current_stream and _current.playing and not force_restart:
        return   # already playing this track

    _current_stream = stream
    _crossfade(stream, FADE_IN, FADE_OUT)

## Stop music, fading out over fade_time seconds.
func stop(fade_time: float = FADE_OUT) -> void:
    _current_stream = null
    if _tween:
        _tween.kill()
    _tween = create_tween()
    _tween.tween_property(_current, "volume_db", -80.0, fade_time)
    await _tween.finished
    _current.stop()

## Pause the music bus (e.g., while a menu is open).
func set_paused(paused: bool) -> void:
    AudioServer.set_bus_mute(AudioServer.get_bus_index("Music"), paused)

func _crossfade(stream: AudioStream, fade_in: float, fade_out: float) -> void:
    if _tween:
        _tween.kill()

    _next.stream = stream
    _next.volume_db = -80.0
    _next.play()

    _tween = create_tween().set_parallel(true)
    _tween.tween_property(_current, "volume_db", -80.0, fade_out)
    _tween.tween_property(_next,    "volume_db",   0.0, fade_in)

    await _tween.finished
    _current.stop()
    var tmp = _current
    _current = _next
    _next    = tmp
```

Usage anywhere in your game:

```gdscript
# In any script:
MusicManager.play(preload("res://music/combat.ogg"))

# On leaving combat:
MusicManager.play(preload("res://music/explore.ogg"))

# In a pause menu:
MusicManager.set_paused(true)
# ... when menu closes:
MusicManager.set_paused(false)
```

:::callout-pitfall[Pitfall — forgetting to stop the old player]
If you interrupt a crossfade mid-fade (player calls `play()` again before the previous tween finishes), the old tween keeps running and the silent player never gets stopped. Always call `_tween.kill()` before starting a new fade, as shown above.
:::

## Adaptive Audio

Adaptive audio means music that reacts to game state in real-time — not just "play combat music when enemies appear" but layering in instruments, shifting mood parameters, or branching between phrases based on the player's health, distance to enemies, or progress through a level.

Vertical Remixing — Stems fade in/out with game state

Explore

Alert

Combat

Explore

Drums

Bass

Melody

Tension

All stems play from beat 0 simultaneously (phase-locked). Volume tweened independently per state change.

Four stems all start at the same moment and loop forever. Game state changes are reflected by tweening individual stem volumes — the Drums are always present; Tension rises during combat; Melody drops away when danger appears.

### Layered Music

The simplest form of adaptive audio is **vertical remixing**: you export your music track as several stems (drums, bass, melody, tension layer) all perfectly time-aligned, then crossfade stems in and out based on game state. Each stem runs in its own AudioStreamPlayer, all playing in sync.

The critical rule: **all players must call `play(0.0)` at the exact same moment** — not from different frames — so the stems stay phase-locked forever.

```gdscript
class_name LayeredMusicPlayer
extends Node

## One AudioStreamPlayer per stem.
@export var stems: Array[AudioStreamPlayer] = []

## The current blend weights (0.0 = silent, 1.0 = full volume).
## Index matches stems array.
var weights: Array[float] = []

func _ready() -> void:
    for p in stems:
        p.bus = "Music"
        p.volume_db = -80.0    # start silent

    weights.resize(stems.size())
    weights.fill(0.0)

## Start all stems perfectly in sync.
func play_all() -> void:
    for p in stems:
        p.play(0.0)            # all start at position 0 in the same frame

## Fade a single stem to a target weight over fade_time seconds.
func set_weight(index: int, target: float, fade_time: float = 1.0) -> void:
    weights[index] = target
    var tween := create_tween()
    var target_db := linear_to_db(target) if target > 0.0 else -80.0
    tween.tween_property(stems[index], "volume_db", target_db, fade_time)

## Convenience: set all weights from a dictionary {stem_index: weight}
func apply_state(state: Dictionary, fade_time: float = 1.0) -> void:
    for idx in state:
        set_weight(idx, state[idx], fade_time)
```

Drive it from your combat system:

```gdscript
# In CombatSystem.gd:
func enter_combat() -> void:
    # Index 0=drums, 1=bass, 2=melody, 3=tension
    $LayeredMusic.apply_state({0: 1.0, 1: 1.0, 2: 0.3, 3: 0.8}, 2.0)

func exit_combat() -> void:
    $LayeredMusic.apply_state({0: 0.4, 1: 0.6, 2: 1.0, 3: 0.0}, 3.0)
```

### AudioStreamInteractive

**AudioStreamInteractive** is Godot's built-in state machine for music — it lets you define clips and transitions between them in the editor, so the engine handles the crossfading and beat-aware timing automatically. It is played through a regular `AudioStreamPlayer`.

| Concept | Description |
| --- | --- |
| **Clip** | A named audio segment (typically a loop). Each clip maps to one AudioStream. |
| **Transition** | A rule: "when switching from clip A to clip B, use this fade mode and wait for this beat boundary." |
| **Initial Clip** | Which clip plays when the player first starts. |

Setting up in the editor: Select an AudioStreamPlayer → set its stream to a new `AudioStreamInteractive` → open it with the pencil icon → add clips in the Clips tab → define transitions in the Transitions tab.

Switching clips at runtime via `AudioStreamPlaybackInteractive`:

```gdscript
@onready var player: AudioStreamPlayer = $MusicPlayer

func _ready() -> void:
    player.play()

func switch_to_combat() -> void:
    # Get the playback object — it is an AudioStreamPlaybackInteractive
    var pb := player.get_stream_playback() as AudioStreamPlaybackInteractive
    if pb:
        pb.switch_to_clip_by_name("combat")

func switch_to_explore() -> void:
    var pb := player.get_stream_playback() as AudioStreamPlaybackInteractive
    if pb:
        pb.switch_to_clip_by_name("explore")
```

:::callout-key[Key Transition Types]
In the Transitions tab each transition has a **From** clip, a **To** clip, and these settings:

- **Fade Mode** — `FADE_DISABLED` (hard cut), `FADE_IN`, `FADE_OUT`, `FADE_CROSS`, `FADE_AUTOMATIC`
- **Hold Once** — play the From clip to its end before switching
- **Filler Clip** — play a short bridge clip (a fill/sting) between the two main clips
- **Wait for Beat** — delay the switch until the next bar/beat boundary (requires BPM set on clips)
:::

### AudioStreamPlaylist

`AudioStreamPlaylist` plays a list of streams in order (or randomly), automatically advancing to the next when one finishes. Useful for ambient soundscapes or long non-looping pieces.

| Property | Type | Description |
| --- | --- | --- |
| shuffle | bool | Randomise playback order. |
| loop | bool | Restart the playlist when it exhausts all streams. |
| fade\_time | float | Crossfade time in seconds between consecutive tracks. Default 1.0. |
| stream\_count | int | Number of streams in the list (set to add slots). |

```gdscript
var playlist := AudioStreamPlaylist.new()
playlist.loop     = true
playlist.shuffle  = true
playlist.fade_time = 2.0
playlist.stream_count = 3
playlist.set_list_stream(0, preload("res://music/ambient_a.ogg"))
playlist.set_list_stream(1, preload("res://music/ambient_b.ogg"))
playlist.set_list_stream(2, preload("res://music/ambient_c.ogg"))

$AmbientPlayer.stream = playlist
$AmbientPlayer.play()
```

## Procedural Audio with AudioStreamGenerator

All the audio sources so far have played back pre-recorded files. **AudioStreamGenerator** breaks that constraint: it exposes a ring buffer you fill with raw PCM frames every `_process()` call, letting you synthesise sound entirely in code — sine tones, noise, chiptune-style waveforms, or anything else you can compute.

:::callout-tip[When to use AudioStreamGenerator]
Use it for: procedural chiptune music, dynamic sound effects (engine pitch that tracks RPM, wind that responds to player speed), audio visualisers, or educational demos. It is *not* needed for most game music — file-based streams are always more efficient.
:::

### AudioStreamGenerator Properties

| Property | Type | Default | Description |
| --- | --- | --- | --- |
| mix\_rate | float | 44100.0 | Sample rate in Hz. Must match the rate you generate frames at. |
| buffer\_length | float | 0.5 | Ring buffer size in seconds. Larger = more latency but more tolerance for frame spikes. 0.05–0.2 is typical. |

The playback object (`AudioStreamGeneratorPlayback`) is what you actually push frames into. Get it after calling `play()`:

```gdscript
@onready var player: AudioStreamPlayer = $SynthPlayer
var _playback: AudioStreamGeneratorPlayback
var _phase: float = 0.0

func _ready() -> void:
    var gen := AudioStreamGenerator.new()
    gen.mix_rate     = 44100.0
    gen.buffer_length = 0.1      # 100 ms latency
    player.stream = gen
    player.play()
    _playback = player.get_stream_playback()

func _process(_delta: float) -> void:
    _fill_buffer()

func _fill_buffer() -> void:
    var frames_available := _playback.get_frames_available()
    var increment := 440.0 / 44100.0   # 440 Hz sine wave

    for _i in frames_available:
        var sample := sin(_phase * TAU)
        # push_frame takes a Vector2 (left, right channels)
        _playback.push_frame(Vector2(sample, sample))
        _phase = fmod(_phase + increment, 1.0)
```

:::callout-warning[Warning — never under-fill the buffer]
If you call `push_frame()` fewer times than `get_frames_available()` returns, the buffer will run dry and you will hear pops and glitches. Always push *exactly* `get_frames_available()` frames each `_process()` call.
:::

### Synthesis Examples

The pattern is the same for any waveform — change only the sample calculation inside the loop.

```gdscript
## Square wave (classic chiptune)
var sample := 1.0 if sin(_phase * TAU) >= 0.0 else -1.0

## Sawtooth wave
var sample := fmod(_phase, 1.0) * 2.0 - 1.0

## Triangle wave
var t := fmod(_phase, 1.0)
var sample := (2.0 * abs(2.0 * t - 1.0) - 1.0)

## White noise
var sample := randf() * 2.0 - 1.0
```

A more interesting example: a procedural chiptune note sequencer that plays a melody by changing frequency on each beat.

```gdscript
extends Node

const MIX_RATE  := 44100.0
const BPM       := 120.0
const MELODY_HZ := [261.63, 293.66, 329.63, 349.23, 392.0, 440.0, 493.88, 523.25]
# C4  D4     E4     F4     G4    A4    B4     C5

@onready var player: AudioStreamPlayer = $Player
var _pb: AudioStreamGeneratorPlayback
var _phase   := 0.0
var _note_idx := 0
var _samples_per_beat : int
var _sample_count := 0

func _ready() -> void:
    var gen := AudioStreamGenerator.new()
    gen.mix_rate = MIX_RATE
    gen.buffer_length = 0.1
    player.stream = gen
    player.play()
    _pb = player.get_stream_playback()
    _samples_per_beat = int(MIX_RATE * 60.0 / BPM)

func _process(_delta: float) -> void:
    var n := _pb.get_frames_available()
    var freq := MELODY_HZ[_note_idx % MELODY_HZ.size()]
    var inc  := freq / MIX_RATE

    for _i in n:
        # Simple square wave with a short decay envelope
        var env := clampf(1.0 - float(_sample_count % _samples_per_beat) / float(_samples_per_beat), 0.0, 1.0)
        var s   := (1.0 if sin(_phase * TAU) >= 0.0 else -1.0) * env * 0.4
        _pb.push_frame(Vector2(s, s))
        _phase = fmod(_phase + inc, 1.0)
        _sample_count += 1
        if _sample_count % _samples_per_beat == 0:
            _note_idx += 1
```

:::callout-connect[Connect to other systems]
Because frequency and amplitude are just floats you update before the buffer fill, you can drive them from anything: an enemy's distance for a horror-style tone, the player's velocity for engine sound, or a music theory module that generates chords procedurally. The sky is the limit.
:::

## Practice Problems

:::problem
#### A — Loop Point Inspector easy

Write a tool script (or just a `_ready()` block) that loads `res://music/theme.ogg` as an `AudioStreamOggVorbis` and prints whether looping is enabled and what the loop\_offset is. Then set loop to `true` and loop\_offset to 3.5 before assigning it to an AudioStreamPlayer and calling `play()`.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var stream := preload("res://music/theme.ogg") as AudioStreamOggVorbis
    print("loop: ", stream.loop, "  loop_offset: ", stream.loop_offset)

    stream.loop        = true
    stream.loop_offset = 3.5
    $AudioStreamPlayer.stream = stream
    $AudioStreamPlayer.play()
```
::::
:::

:::problem
#### B — Simple Crossfade standard

Without using the MusicManager from the chapter, write a Node with two child AudioStreamPlayers (`$A` and `$B`) and a function `crossfade(to_stream: AudioStream, duration: float)` that fades `$A` out and `$B` in over `duration` seconds, then stops `$A` and swaps the references so the next call works correctly.

::::solution[Solution]
```gdscript
extends Node

@onready var _a: AudioStreamPlayer = $A
@onready var _b: AudioStreamPlayer = $B
var _cur: AudioStreamPlayer
var _next: AudioStreamPlayer

func _ready() -> void:
    _cur  = _a
    _next = _b
    _cur.volume_db  = 0.0
    _next.volume_db = -80.0

func crossfade(to_stream: AudioStream, duration: float) -> void:
    _next.stream = to_stream
    _next.volume_db = -80.0
    _next.play()

    var tw := create_tween().set_parallel(true)
    tw.tween_property(_cur,  "volume_db", -80.0, duration)
    tw.tween_property(_next, "volume_db",   0.0, duration)

    await tw.finished
    _cur.stop()
    var tmp = _cur
    _cur  = _next
    _next = tmp
```
::::
:::

:::problem
#### C — Layered Intensity standard

You have three stems: `drums.ogg`, `bass.ogg`, and `tension.ogg`. Write a Node that starts all three in sync and exposes a function `set_intensity(level: float)` where `level` is 0.0–1.0. At 0.0 only drums are audible; at 0.5 drums and bass are fully audible; at 1.0 all three are fully audible. Use linear interpolation to blend volumes smoothly with a 1.5-second tween.

::::solution[Solution]
```gdscript
extends Node

@onready var drums:   AudioStreamPlayer = $Drums
@onready var bass:    AudioStreamPlayer = $Bass
@onready var tension: AudioStreamPlayer = $Tension

func _ready() -> void:
    for p in [drums, bass, tension]:
        p.bus = "Music"
    # Sync-start all stems
    drums.play(0.0)
    bass.play(0.0)
    tension.play(0.0)
    set_intensity(0.0)

func set_intensity(level: float) -> void:
    level = clampf(level, 0.0, 1.0)
    # drums always at full
    var drums_vol   := 0.0
    # bass fades in from 0→0.5
    var bass_vol    := linear_to_db(clampf(level / 0.5, 0.0, 1.0)) if level > 0.0 else -80.0
    # tension fades in from 0.5→1.0
    var tension_vol := linear_to_db(clampf((level - 0.5) / 0.5, 0.0, 1.0)) if level > 0.5 else -80.0

    var tw := create_tween().set_parallel(true)
    tw.tween_property(drums,   "volume_db", drums_vol,   1.5)
    tw.tween_property(bass,    "volume_db", bass_vol,    1.5)
    tw.tween_property(tension, "volume_db", tension_vol, 1.5)
```
::::
:::

:::problem
#### D — AudioStreamPlaylist Shuffle easy

In code (no editor), create an `AudioStreamPlaylist` containing four ambient tracks from `res://ambient/`, set it to shuffle and loop with a 2-second crossfade, assign it to an AudioStreamPlayer on the "Ambient" bus, and start playback.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var pl := AudioStreamPlaylist.new()
    pl.shuffle      = true
    pl.loop         = true
    pl.fade_time    = 2.0
    pl.stream_count = 4
    pl.set_list_stream(0, preload("res://ambient/wind.ogg"))
    pl.set_list_stream(1, preload("res://ambient/rain.ogg"))
    pl.set_list_stream(2, preload("res://ambient/forest.ogg"))
    pl.set_list_stream(3, preload("res://ambient/cave.ogg"))

    $AmbientPlayer.bus    = "Ambient"
    $AmbientPlayer.stream = pl
    $AmbientPlayer.play()
```
::::
:::

:::problem
#### E — Procedural Sine Tone with Pitch Control standard

Write a Node that uses `AudioStreamGenerator` to produce a continuous sine wave. Expose a property `frequency: float` (default 440.0 Hz). When `frequency` changes, the pitch should update smoothly within the same `_process()` buffer fill — no clicks. The node should start playing automatically in `_ready()`.

::::solution[Solution]
```gdscript
extends Node

const MIX_RATE := 44100.0

var frequency: float = 440.0 :
    set(v): frequency = v  # _process reads it each frame, so updating is instant

@onready var player: AudioStreamPlayer = $Player
var _pb:    AudioStreamGeneratorPlayback
var _phase: float = 0.0

func _ready() -> void:
    var gen := AudioStreamGenerator.new()
    gen.mix_rate      = MIX_RATE
    gen.buffer_length = 0.05
    player.stream = gen
    player.play()
    _pb = player.get_stream_playback()

func _process(_delta: float) -> void:
    var n   := _pb.get_frames_available()
    var inc := frequency / MIX_RATE
    for _i in n:
        var s := sin(_phase * TAU) * 0.4
        _pb.push_frame(Vector2(s, s))
        _phase = fmod(_phase + inc, 1.0)
```

Because `frequency` is read inside the frame loop each `_process()`, the phase increment updates immediately — the sine wave changes pitch without a gap or click.
::::
:::

:::problem
#### F — MusicManager Extend: Duck on SFX challenge

Extend the `MusicManager` from the chapter to add a `duck(duck_db: float, duration: float)` function that temporarily lowers the Music bus volume by `duck_db` dB, holds it there for `duration` seconds, then fades back to 0 dB. A second call to `duck()` before the first finishes should cancel the old tween and start fresh. Use `AudioServer` to control the bus volume directly.

::::solution[Solution]
```gdscript
# Add to music_manager.gd:

var _duck_tween: Tween
var _music_bus_idx: int

func _ready() -> void:
    # (existing _ready code) ...
    _music_bus_idx = AudioServer.get_bus_index("Music")

func duck(duck_db: float, hold_sec: float) -> void:
    if _duck_tween:
        _duck_tween.kill()

    _duck_tween = create_tween()
    # Fade down
    _duck_tween.tween_method(
        func(v): AudioServer.set_bus_volume_db(_music_bus_idx, v),
        0.0, -absf(duck_db), 0.15
    )
    # Hold
    _duck_tween.tween_interval(hold_sec)
    # Fade back up
    _duck_tween.tween_method(
        func(v): AudioServer.set_bus_volume_db(_music_bus_idx, v),
        -absf(duck_db), 0.0, 0.3
    )
```

Call `MusicManager.duck(-12.0, 2.0)` to drop music by 12 dB for 2 seconds when a cutscene fires.
::::
:::
