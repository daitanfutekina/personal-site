---
title: "Optimization — Draw Calls, LOD, Occlusion Culling & Batching"
source: "markdown"
---

Part X · Chapter 61

# Optimization — Draw Calls, LOD, Occlusion Culling & Batching

Estimated study time: 90 min · Godot 4.x · GDScript + editor

## Chapter Overview

Profiling (Ch 60) told you *what* is slow. This chapter teaches you *how to fix it*.
 We cover the four highest-leverage optimization techniques in Godot:
 reducing **draw calls** through batching and material sharing,
 **culling** invisible geometry so the GPU never touches it,
 **Level of Detail (LOD)** to swap cheap meshes for distant objects,
 and **GDScript performance patterns** that eliminate common CPU bottlenecks.

:::callout-tip[Prerequisites]
Ch 60 (Profiling) — know how to find your bottleneck before applying fixes.
  Basic familiarity with nodes, meshes, and materials.
:::

:::callout-intuition[The Golden Rule of Optimization]
Measure first, optimize second.

Every technique in this chapter has a cost
  (setup time, memory, complexity). Apply them only to the bottleneck the profiler identified.
  Optimizing code that isn't slow wastes time and adds bugs.
:::

## Draw Calls

:::callout-intuition[Intuition]
Every time the GPU draws something, the CPU must first send it a "draw call" — a command
  packet that includes the mesh, material, shader, and transform. Each packet has fixed
  overhead regardless of how many triangles it contains. Sending 1000 draw calls for 1000
  tiny sprites costs the same CPU time as 1000 calls for 1000 complex meshes.
  The solution: combine objects so one call draws many things at once.
:::

### How Many Draw Calls Is Too Many?

| Platform | Comfortable budget | Danger zone |
| --- | --- | --- |
| PC / Console | < 2000 / frame | > 5000 |
| Mobile (mid-range) | < 300 / frame | > 700 |
| Mobile (low-end) | < 100 / frame | > 200 |

Check your current count: Debugger → Monitors → tick
 *Render / Total Draw Calls in Frame*.

Draw Call Reduction — Before vs. After

BEFORE — 6 draw calls

draw()

draw()

draw()

draw()

draw()

draw()

6 separate CPU→GPU command packets

= 6× overhead

AFTER — 1 draw call

Batched / MultiMesh

6 sprites → 1 draw call

(same material + texture atlas)

1 CPU→GPU packet regardless of count

= 1× overhead ✓

Each draw call has fixed CPU overhead. Batching 6 separate sprites sharing the same material into one call (via automatic 2D batching or `MultiMeshInstance2D`) reduces overhead from 6× to 1×.

### Automatic Batching in 2D

Godot's 2D renderer automatically batches consecutive draw calls that share the same
 **texture** and **material**. If sprites are ordered so that
 all sprites using texture A are drawn before sprites using texture B, the renderer merges
 them into one draw call. Mixing textures forces a batch break.

:::callout-tip[2D Batching Rules]
- Nodes with **z\_index** changes or **CanvasItem** with individual materials always break batches.
- Keep all ground tiles on one layer, all enemies on another — don't interleave.
- Use a **single atlas texture** (see next section) so all sprites share one texture, enabling the renderer to batch your entire scene into 1–3 draw calls.
:::

### Texture Atlases & Material Sharing

A **texture atlas** packs many small images into one large texture.
 All sprites that use different regions of the same atlas can be batched together.

#### Creating an Atlas in Godot

1. Put all sprite source images into a folder (e.g., `res://sprites/`).
2. In the FileSystem dock, select all images → right-click → **Create Sprite Frames** (for AnimatedSprite) or use the **SpriteFrames** editor.
3. Alternatively, use the **Import** dock: select a folder of images, set Mode to *Multiple* and enable *Atlas* to auto-pack them.
4. Reference individual regions with `AtlasTexture` resources — set `atlas` to the packed texture, and `region` to the sub-rectangle.

```gdscript
## At runtime: assign a region of a shared atlas to a Sprite2D
@onready var sprite := $Sprite2D as Sprite2D

func set_frame(atlas: Texture2D, region: Rect2) -> void:
    var at := AtlasTexture.new()
    at.atlas  = atlas
    at.region = region
    sprite.texture = at
```

#### Material Sharing in 3D

In 3D, draw call batching requires that objects share the exact same **Material**
 resource. If two MeshInstance3D nodes reference the same `.tres` material file,
 Godot can batch them. If each has its own material instance (even identical settings),
 they cannot be batched.

```gdscript
## Bad: each enemy creates its own material instance
func _ready() -> void:
    var mat := StandardMaterial3D.new()  # unique instance per enemy
    mat.albedo_color = Color.RED
    $MeshInstance3D.set_surface_override_material(0, mat)

## Good: share a preloaded material resource
const ENEMY_MAT := preload("res://materials/enemy.tres")
func _ready() -> void:
    $MeshInstance3D.set_surface_override_material(0, ENEMY_MAT)
```

### MultiMeshInstance3D — Thousands of Identical Meshes

When you need to render many *identical* meshes (trees, grass, coins, particles),
 **MultiMeshInstance3D** (or 2D) draws all of them in a single draw call.
 Each instance only stores a transform (and optionally a colour and custom data float).

```gdscript
## SpawnForest.gd — place 10 000 trees in 1 draw call
extends Node3D

@export var tree_mesh: Mesh
@export var count     := 10_000
@export var area      := Vector2(500.0, 500.0)

func _ready() -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.instance_count   = count
    mm.mesh             = tree_mesh

    for i in count:
        var pos := Vector3(
            randf_range(-area.x * 0.5, area.x * 0.5),
            0.0,
            randf_range(-area.y * 0.5, area.y * 0.5)
        )
        mm.set_instance_transform(i, Transform3D(Basis(), pos))

    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    add_child(mmi)
```

The GPU draws all 10 000 trees in one draw call. Updating a transform at runtime:
 `mm.set_instance_transform(index, new_transform)` — this is a CPU upload
 so keep per-frame updates below ~1000 instances or use a shader instead.

:::callout-warning[MultiMesh Limitation]
All instances share the

same

mesh and material. If you need per-instance colour,
  use

mm.use\_colors = true

and

mm.set\_instance\_color(i, color)

.
  For per-instance material uniforms, use a ShaderMaterial with `INSTANCE_CUSTOM`.
:::

## Culling — Don't Draw What You Can't See

:::callout-intuition[Intuition]
The fastest draw call is the one that never happens. Culling removes objects from the
  render pipeline before the GPU ever sees them. Godot does some culling automatically
  (frustum culling — objects outside the camera's view), but you must set up the rest.
:::

### Frustum Culling (Automatic)

Godot's renderer automatically skips rendering any GeometryInstance whose AABB
 (axis-aligned bounding box) is entirely outside the camera frustum. This is free —
 you get it for all nodes. However, it only works if the visibility AABB is correct.
 For custom meshes with unusual shapes, set custom\_aabb
 explicitly on the MeshInstance.

### VisibleOnScreenNotifier2D / 3D — Pause Off-Screen Logic

Rendering is culled automatically, but `_process()` and
 `_physics_process()` still run for off-screen nodes. Use
 **VisibleOnScreenNotifier2D** (or 3D) to pause or free nodes when invisible:

```gdscript
## EnemyOffscreenManager.gd
extends Node2D

@onready var notifier := $VisibleOnScreenNotifier2D
@onready var ai_brain := $AIBrain

func _ready() -> void:
    notifier.screen_entered.connect(_on_visible)
    notifier.screen_exited.connect(_on_hidden)

func _on_visible() -> void:
    ai_brain.set_process(true)
    ai_brain.set_physics_process(true)

func _on_hidden() -> void:
    ai_brain.set_process(false)
    ai_brain.set_physics_process(false)
```

For one-shot objects (projectiles, particles) that should be freed when they leave screen:
 add a VisibleOnScreenNotifier as a child, connect `screen_exited` to
 `queue_free()` on the parent.

### Occlusion Culling (3D)

Frustum culling skips objects outside the view cone. **Occlusion culling**
 additionally skips objects that are inside the view cone but hidden *behind* a wall
 or large object. In a corridor shooter, the entire far room is occluded by the wall — no
 draw calls needed for it.

#### Setting Up Occluders

1. Add an **OccluderInstance3D** node to any large opaque object (walls, floors, big rocks).
2. Assign an **Occluder3D** resource: for boxes use `BoxOccluder3D`; for arbitrary shapes use `PolygonOccluder3D` or `SphereOccluder3D`.
3. Enable occlusion culling globally: **Project Settings → Rendering → Occlusion Culling → Use Occlusion Culling**.

```gdscript
## At runtime: create a box occluder for a wall
var oi := OccluderInstance3D.new()
var box := BoxOccluder3D.new()
box.size = Vector3(10.0, 3.0, 0.3)   # wall dimensions
oi.occluder = box
wall_node.add_child(oi)
```

:::callout-warning[Occluder Cost]
Occluder culling uses a CPU rasterizer to test visibility. Too many complex occluders
  can cost more than they save. Use BoxOccluder3D for rooms, PolygonOccluder3D only where
  box approximations are not accurate enough.
:::

## Level of Detail (LOD)

:::callout-intuition[Intuition]
A character 200 metres away covers 4 pixels on screen — drawing its 50 000-triangle mesh
  wastes massive GPU time. LOD swaps the mesh for a cheaper version (fewer triangles,
  simpler material) based on distance. The player can't tell the difference at that range,
  and your GPU does a fraction of the work.
:::

Level of Detail — mesh complexity by distance

Camera

viewpoint

LOD 0

High poly

50 000 tris

full PBR material

0 – 20m

LOD 1

Medium poly

5 000 tris

20 – 80m

20 – 80m

LOD 2

Low poly / imposter

200 tris

80 – 200m

Culled (invisible)

> 200m

distance from camera →

LOD swaps to a cheaper mesh as distance grows. At 80 m the player can't distinguish LOD 1 from LOD 0 — but the GPU saves ~10× the triangle work. Set thresholds on `GeometryInstance3D.lod_bias` or in the Inspector under Geometry LOD.

### GeometryInstance3D Built-in LOD (3D)

Every `MeshInstance3D` inherits from `GeometryInstance3D`, which has
 built-in LOD support via the lod\_bias property and the
 **Mesh LOD** system. To use it:

1. Select your mesh in the editor. In *Import* settings, enable **Generate LODs** and set the number of LOD levels (typically 3–5).
2. Re-import. Godot generates simplified meshes at 50%, 25%, 12.5%… of original triangle count automatically using mesh simplification.
3. The engine switches LOD levels automatically based on the object's projected screen size.

You can also author LOD levels manually by creating a `Mesh` resource with
 multiple surfaces and associating them as LOD levels, or by using separate
 `MeshInstance3D` nodes with a custom distance-based switcher:

```gdscript
## ManualLOD.gd — swap child meshes by camera distance
extends Node3D

@export var lod_distances := [20.0, 60.0, 150.0]  # switch thresholds
@onready var lods: Array[Node] = [$LOD0, $LOD1, $LOD2, $LOD3]

var _camera: Camera3D

func _ready() -> void:
    _camera = get_viewport().get_camera_3d()

func _process(_delta: float) -> void:
    if not _camera: return
    var dist := global_position.distance_to(_camera.global_position)
    var level := lod_distances.size()  # default: lowest LOD
    for i in lod_distances.size():
        if dist < lod_distances[i]:
            level = i
            break
    for i in lods.size():
        lods[i].visible = (i == level)
```

#### GeometryInstance3D LOD Properties

| Property | Effect |
| --- | --- |
| lod\_bias | Multiplier on screen-size threshold. Higher = uses high-LOD longer (better quality); lower = switches earlier (better perf). |
| visibility\_range\_begin | Object appears when camera is at least this far away (useful for pop-in effects) |
| visibility\_range\_end | Object disappears when camera is farther than this — a simple distance cull |
| visibility\_range\_fade\_mode | DISABLED, SELF (dithers), or DEPENDENCIES (cross-fades between LODs) |

### Sprite LOD Pattern (2D)

2D doesn't have built-in LOD, but you can replicate it with zoom-based switching:

```gdscript
## SpriteLOD2D.gd
extends Sprite2D

@export var hi_tex  : Texture2D   ## full-res sprite
@export var lo_tex  : Texture2D   ## half-res or simplified sprite
@export var lo_zoom_threshold := 0.4   ## switch below this Camera2D zoom

func _process(_delta: float) -> void:
    var cam := get_viewport().get_camera_2d()
    if cam == null: return
    var zoom_x := cam.zoom.x
    texture = lo_tex if zoom_x < lo_zoom_threshold else hi_tex
```

## GDScript Performance Patterns

GDScript is an interpreted language — loops and function calls have overhead compared
 to compiled code. The following patterns give the biggest wins with the least refactoring.

### Cache Node References — Never Use $Path in \_process()

```gdscript
## Bad: $Path lookups every frame (string hash + tree walk each call)
func _process(delta: float) -> void:
    $HUD/HealthBar.value = $Stats.health   # two expensive lookups per frame

## Good: cache @onready, use typed references
@onready var _health_bar := $HUD/HealthBar as ProgressBar
@onready var _stats      := $Stats         as StatsComponent

func _process(delta: float) -> void:
    _health_bar.value = _stats.health      # direct pointer, zero overhead
```

### Avoid Heap Allocations in Hot Loops

```gdscript
## Bad: creates a new Array every frame
func _process(delta: float) -> void:
    var nearby := get_tree().get_nodes_in_group("enemies")  # allocates each call
    for e in nearby:
        _check_enemy(e)

## Good: cache the array and update it on demand (signal-driven)
var _enemies: Array[Node] = []

func _ready() -> void:
    get_tree().node_added.connect(_on_node_added)
    get_tree().node_removed.connect(_on_node_removed)

func _on_node_added(node: Node) -> void:
    if node.is_in_group("enemies"): _enemies.append(node)

func _on_node_removed(node: Node) -> void:
    _enemies.erase(node)

func _process(delta: float) -> void:
    for e in _enemies:
        _check_enemy(e)
```

### Use Static Typing — It Helps the GDScript VM

Typed variables allow GDScript's VM to skip type-check overhead on every access.
 The performance gain is modest (~10–15%) but cumulative in hot code:

```gdscript
## Untyped — VM must check types at runtime
var speed = 200.0
var pos = global_position

## Typed — direct dispatch, no runtime type check
var speed: float = 200.0
var pos: Vector2 = global_position
```

### Throttle Expensive Operations with Timers

Not everything needs to run at 60 fps. Pathfinding, vision checks, and AI decisions
 typically only need 5–10 Hz. Use a staggered timer per-agent so they don't all
 recalculate on the same frame:

```gdscript
## Enemy.gd — stagger AI updates across enemies
var _update_interval: float
var _update_timer: float

func _ready() -> void:
    # Each enemy gets a different phase offset — no thundering herd
    _update_interval = 0.2                         # 5 Hz
    _update_timer    = randf_range(0.0, _update_interval)

func _physics_process(delta: float) -> void:
    _update_timer -= delta
    if _update_timer > 0.0: return
    _update_timer = _update_interval
    _run_expensive_ai_tick()
```

### GDScript vs. Built-in Methods — Prefer Built-ins

Built-in Godot methods (e.g., `Array.sort()`, `Array.map()`,
 `String.format()`) are implemented in C++ and run orders of magnitude faster
 than equivalent GDScript loops. Prefer them whenever possible:

```gdscript
## Slow: manual GDScript sort
var sorted := []
for val in my_array:
    sorted.append(val)
# ... insertion sort ...

## Fast: C++ built-in
var sorted := my_array.duplicate()
sorted.sort()    # C++ introsort, ~100× faster for large arrays
```

:::callout-key[When GDScript Isn't Enough]
If profiling shows GDScript is the bottleneck and the patterns above don't help,
  consider moving the hot path to:

- **GDExtension (C++ / Rust)** — Ch 19 covers this in detail
- **RenderingServer / PhysicsServer direct API** — bypasses node overhead for mass operations
- **Thread + WorkerThreadPool** — offload heavy computation to a background thread (Ch 62)
:::

## Worked Examples

### Example 1 — Grass Field: 50 000 Blades in 1 Draw Call

**Goal:** Render a field of 50 000 grass blades on mobile without tanking draw calls.

```gdscript
## GrassField.gd
extends MultiMeshInstance3D

@export var blade_mesh : Mesh
@export var count      := 50_000
@export var area       := Vector2(100.0, 100.0)

func _ready() -> void:
    multimesh = MultiMesh.new()
    multimesh.transform_format = MultiMesh.TRANSFORM_3D
    multimesh.use_colors       = true          # per-instance tint variation
    multimesh.instance_count   = count
    multimesh.mesh             = blade_mesh

    var rng := RandomNumberGenerator.new()
    for i in count:
        var x := rng.randf_range(-area.x * 0.5, area.x * 0.5)
        var z := rng.randf_range(-area.y * 0.5, area.y * 0.5)
        # Random Y rotation for variation
        var basis := Basis(Vector3.UP, rng.randf_range(0.0, TAU))
        multimesh.set_instance_transform(i, Transform3D(basis, Vector3(x, 0.0, z)))
        # Slight colour variation (green tones)
        var g := rng.randf_range(0.6, 1.0)
        multimesh.set_instance_color(i, Color(0.2, g, 0.1))
```

All 50 000 blades render in **1 draw call**. Add a wind shader to the
 grass material using `INSTANCE_CUSTOM` to vary wave phase per blade.

### Example 2 — Visibility-Based AI Pause

**Goal:** 200 enemies on a large map — only enemies near the camera should
 run AI. Enemies more than 80 m away pause their `_physics_process`.

```gdscript
## Enemy.gd
extends CharacterBody3D

func _ready() -> void:
    var notifier := VisibleOnScreenNotifier3D.new()
    # Make the notifier's AABB slightly larger than the enemy hitbox
    notifier.aabb = AABB(Vector3(-0.5, 0.0, -0.5), Vector3(1.0, 2.0, 1.0))
    add_child(notifier)
    notifier.screen_entered.connect(func(): set_physics_process(true))
    notifier.screen_exited.connect(func():  set_physics_process(false))
    # Start paused — wait for visibility
    set_physics_process(false)

func _physics_process(delta: float) -> void:
    _run_ai(delta)
```

With 200 enemies and a typical viewing distance of 80 m, only ~20 enemies are
 active at once — a 10× reduction in physics process calls.

### Example 3 — Throttled Path Requests

**Problem:** 80 enemies each call `NavigationAgent3D` path recalculation
 every frame → 80 path queries × 60 fps = 4800 expensive calls/second.

```gdscript
## Enemy.gd
extends CharacterBody3D

const PATH_INTERVAL := 0.25   # recalculate path 4× per second
var _path_timer := 0.0

@onready var nav_agent := $NavigationAgent3D

func _ready() -> void:
    # Stagger start time so enemies don't all request paths on frame 1
    _path_timer = randf_range(0.0, PATH_INTERVAL)

func _physics_process(delta: float) -> void:
    _path_timer -= delta
    if _path_timer <= 0.0:
        _path_timer = PATH_INTERVAL
        nav_agent.target_position = _find_target()

    if nav_agent.is_navigation_finished(): return
    var next := nav_agent.get_next_path_position()
    velocity = (next - global_position).normalized() * SPEED
    move_and_slide()
```

Result: 4800 path queries/s → 320/s (80 enemies × 4 Hz). Frame time for navigation drops
 proportionally.

:::summary
### Chapter 61 — Quick Reference

| Technique | What it fixes | Godot feature |
| --- | --- | --- |
| Texture Atlas | Too many draw calls (2D sprites) | AtlasTexture, SpriteFrames import with Atlas |
| Shared Materials | Too many draw calls (3D) | Preload .tres material, avoid .new() per object |
| MultiMeshInstance | Thousands of identical meshes | MultiMesh + MultiMeshInstance2D/3D |
| Frustum Culling | Off-screen objects drawn (automatic) | Set custom\_aabb for custom meshes |
| VisibleOnScreenNotifier | Off-screen \_process() overhead | VisibleOnScreenNotifier2D/3D → screen\_exited signal |
| visibility\_range\_end | Far-away objects drawn | GeometryInstance3D property |
| Occlusion Culling | Behind-wall geometry drawn (3D) | OccluderInstance3D + BoxOccluder3D |
| Import LOD | High-poly mesh rendered at distance | Import → Generate LODs |
| Manual LOD | Custom distance-based mesh switch | visibility\_range\_begin/end or script |
| Cached node refs | $Path lookup overhead in \_process | @onready typed vars |
| Signal-driven enemy list | get\_nodes\_in\_group() alloc per frame | node\_added/removed signals |
| Staggered AI timers | All agents update same frame (herd) | randf\_range phase offset |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Draw Call Count

Your 2D game has 300 enemy sprites, each using a different texture file.
 How many draw calls does this generate? What single change would reduce it to
 approximately 1–3 draw calls, and how would you implement it in Godot?

::::solution[Solution]
300 unique textures = 300 draw calls (one per texture break).
 The fix: pack all enemy sprites into a single atlas texture.
 In Godot: select all enemy images in the FileSystem dock → Import → set Mode to
 *Multiple*, enable *Atlas*, re-import. Then reference each frame as an
 `AtlasTexture` region of the shared atlas. All 300 sprites now share one texture →
 the 2D batcher merges them into 1 draw call (assuming no z-index interleaving).
::::
:::

:::problem{difficulty="easy"}
#### 2. VisibleOnScreenNotifier Pause

You have a 2D side-scroller with 50 fish enemies, each running an `_physics_process`
 that does flocking calculations. Most fish are off-screen at any given moment.
 Write the code to add a `VisibleOnScreenNotifier2D` at runtime and pause/resume the
 physics process based on screen visibility.

::::solution[Solution]
```gdscript
## Fish.gd
extends CharacterBody2D

func _ready() -> void:
    var notifier := VisibleOnScreenNotifier2D.new()
    # Rect2 slightly larger than the fish sprite
    notifier.rect = Rect2(-16, -16, 32, 32)
    add_child(notifier)
    notifier.screen_entered.connect(func(): set_physics_process(true))
    notifier.screen_exited.connect(func():  set_physics_process(false))
    set_physics_process(false)  # start paused

func _physics_process(delta: float) -> void:
    _do_flocking(delta)
```
::::
:::

:::problem{difficulty="standard"}
#### 3. MultiMesh Coin Field

Create a script that places 5 000 coins (a shared quad mesh with a coin texture) randomly
 across a 200×200 unit 2D area using `MultiMeshInstance2D`. Each coin should have
 a random rotation. Then write a function `collect_coin(index: int)` that hides a
 specific coin by setting its transform scale to zero.

::::solution[Solution]
```gdscript
## CoinField.gd
extends MultiMeshInstance2D

const COUNT := 5_000
const AREA  := 200.0

func _ready() -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_2D
    mm.instance_count   = COUNT
    mm.mesh             = QuadMesh.new()   # assign coin texture to material separately
    multimesh = mm

    for i in COUNT:
        var x   := randf_range(-AREA * 0.5, AREA * 0.5)
        var y   := randf_range(-AREA * 0.5, AREA * 0.5)
        var rot := randf_range(0.0, TAU)
        var xf  := Transform2D(rot, Vector2(x, y))
        mm.set_instance_transform_2d(i, xf)

func collect_coin(index: int) -> void:
    # Scale to zero hides it without changing instance count
    var t := multimesh.get_instance_transform_2d(index)
    t = t.scaled(Vector2.ZERO)
    multimesh.set_instance_transform_2d(index, t)
```

Note: a cleaner approach uses `use_custom_data` and a shader that discards
 instances with custom data = 0, avoiding the scale-to-zero hack.
::::
:::

:::problem{difficulty="standard"}
#### 4. Throttled Line-of-Sight

You have 100 enemies each casting a raycast every frame to check line-of-sight to the player.
 Rewrite the pattern so each enemy only checks LOS at 10 Hz (not 60 Hz), with staggered
 start offsets so no two enemies check on the same frame.

::::solution[Solution]
```gdscript
## Enemy.gd
extends CharacterBody2D

const LOS_INTERVAL := 0.1   # 10 Hz
var _los_timer   := 0.0
var _can_see_player := false

func _ready() -> void:
    _los_timer = randf_range(0.0, LOS_INTERVAL)   # stagger phase

func _physics_process(delta: float) -> void:
    _los_timer -= delta
    if _los_timer <= 0.0:
        _los_timer = LOS_INTERVAL
        _can_see_player = _check_los()
    if _can_see_player:
        _chase_player(delta)
    else:
        _patrol(delta)

func _check_los() -> bool:
    var player := get_tree().get_first_node_in_group("player") as Node2D
    if player == null: return false
    var space  := get_world_2d().direct_space_state
    var params := PhysicsRayQueryParameters2D.create(
        global_position, player.global_position, 1, [self]
    )
    return get_world_2d().direct_space_state.intersect_ray(params).is_empty()
```

At 100 enemies × 10 Hz = 1000 LOS checks/s vs. 6000/s at 60 Hz — a 6× reduction.
::::
:::

:::problem{difficulty="challenge"}
#### 5. LOD Distance Switcher

Write a generic `LODSwitcher3D` component that accepts an array of
 `{ mesh: MeshInstance3D, max_distance: float }` pairs and shows only the
 appropriate mesh based on camera distance. The component should update at 5 Hz (not
 every frame) and handle the case where no camera is available.

::::solution[Solution]
```gdscript
## LODSwitcher3D.gd
class_name LODSwitcher3D extends Node

## Each entry: { mesh: MeshInstance3D, max_distance: float }
## Sort by max_distance ascending — closest first.
@export var lod_levels: Array[Dictionary] = []

const UPDATE_INTERVAL := 0.2   # 5 Hz
var _timer := 0.0

func _ready() -> void:
    # Sort entries by max_distance ascending
    lod_levels.sort_custom(func(a, b): return a.max_distance < b.max_distance)
    # Start all hidden
    for entry in lod_levels:
        (entry.mesh as MeshInstance3D).visible = false

func _process(delta: float) -> void:
    _timer -= delta
    if _timer > 0.0: return
    _timer = UPDATE_INTERVAL

    var cam := get_viewport().get_camera_3d()
    if cam == null: return

    var dist := (get_parent() as Node3D).global_position.distance_to(cam.global_position)
    var chosen: MeshInstance3D = null

    for entry in lod_levels:
        if dist <= entry.max_distance:
            chosen = entry.mesh as MeshInstance3D
            break

    for entry in lod_levels:
        (entry.mesh as MeshInstance3D).visible = (entry.mesh == chosen)
```

Usage: add `LODSwitcher3D` as a child of your object. Populate `lod_levels`
 with `{ "mesh": $HighPolyMesh, "max_distance": 30.0 }`,
 `{ "mesh": $MidPolyMesh, "max_distance": 80.0 }`, etc.
 Objects beyond the highest `max_distance` have `chosen = null`
 and all meshes are hidden — effectively distance culled.
::::
:::
