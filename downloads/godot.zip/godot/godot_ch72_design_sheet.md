---
title: "Crowd Runner Mobile — Design Sheet"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72"
meta:
  - "Est. study time: ~30 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72_design_sheet.html"
---

## Game Concept

**Crowd runners** (also called *gate runners* — Count Masters, Run Race 3D,
 Cube Surfer, Shortcut Run) are the archetypal “shitty mobile game”: a portrait 3D endless
 runner where you swipe left/right between lanes, pass through arithmetic gates
 (`+5`, `×2`, `−3`, `÷2`) that grow or shrink your crowd,
 dodge obstacles that kill members, and end the run with a giant crowd smashing into an enemy wall.

This series builds a feature-complete clone in Godot 4 we call **Zerg March**.
 It covers every system of the archetype: a 3-lane track with world-scrolling ground, a chase
 camera, a leader CharacterBody3D followed by up to 200 crowd members rendered with a single
 MultiMeshInstance3D, gates that mutate the crowd count, obstacles (walls and saws) that shrink
 it, procedural level generation with a distance-based difficulty ramp, a portrait HUD with
 juicy number tweens, an end-of-run mini-brawl against an enemy wall, main / pause / game-over
 menus, high score persistence, and a working Android APK export.

:::callout-key[What you will build]
A fully playable portrait Android game. By Ch 72H the game runs at 60 fps on a mid-range
 phone with 150+ crowd members on screen, handles touch swipes and taps, saves high scores,
 exports as a signed APK, and is ready to sideload or submit to Google Play internal testing.
:::

### Chapter map

| Chapter | Topic | Key systems |
| --- | --- | --- |
| 72 (this) | Design Sheet | GDD, architecture, all scripts defined |
| 72A | Project Setup | Mobile renderer, portrait, folders, autoloads, input map |
| 72B | Track & Camera | Recycling ground segments, chase Camera3D, Main scene |
| 72C | Runner & Motion | CharacterBody3D leader, auto-forward, sine bob |
| 72D | Swipe & Lanes | InputEventScreenDrag, 3-lane tween, keyboard fallback |
| 72E | Crowd & MultiMesh | MultiMeshInstance3D, ring formation, add/remove/reposition |
| 72F | Gates & Obstacles | Area3D triggers, GateType enum, wall/saw obstacles |
| 72G | Spawner, HUD & Menus | LevelSpawner, portrait HUD, main/pause/game-over |
| 72H | End Battle, Polish & Export | Enemy wall, VFX, SFX, ConfigFile save, Android APK |

:::callout-connect[Reference chapters this series draws on]
Part I foundations (1, 3–7); Part II autoloads & typing (8, 11); Part IV 3D basics
 (24, 25, 26, 28, 29, 34); Part V UI (36–41); Part VI audio (43, 44); Part VII input &
 save (46, 47); Part XI export & polish (63, 64). Each build chapter opens with a
 *Reference checklist* naming exactly which chapters to read first.
:::

## Three Laws of Zerg March

:::callout-intuition[Design constraints]
These rules govern every architecture decision in this series. When something feels
 unclear, come back to these first — most confused decisions are just a violation of one
 of them.
:::

:::definition
#### Law 1 — The player only steers

The runner moves forward automatically at constant speed. The player *only*
 chooses lanes with a horizontal swipe (or A/D in the editor). The player never accelerates,
 brakes, jumps, or attacks. Steering plus the level layout is the entire game.
:::

:::definition
#### Law 2 — There is exactly one CharacterBody3D on the field

The *leader* is a full CharacterBody3D. Every other crowd member is a purely
 visual transform inside a single MultiMeshInstance3D. Followers do not collide, do not
 physics-tick, and do not have scripts. This is the load-bearing decision that lets the
 game run 200 crowd members on a phone. Never add per-follower nodes.
:::

:::definition
#### Law 3 — All world content is procedural and disposable

Gates, obstacles, and ground segments are spawned by `LevelSpawner` as the
 runner advances and `queue_free`d as they pass behind the camera. Nothing is
 hand-placed in the Main scene except the runner, the camera, and the first two ground
 segments. New content = new spawner rule, never a new baked scene.
:::

## Core Loop

```
MAIN MENU
  │  (player taps PLAY)
  ▼
START RUN
  │  (runner spawns, camera in position, crowd count = 1, distance = 0)
  ▼
FORWARD MOTION (leader velocity.z = -RUN_SPEED, camera follows)
  │
  ├─ LevelSpawner ticks every SPAWN_METERS metres of distance
  │     │
  │     ▼
  │  Spawn TwoGateRow OR ObstacleRow at spawn_z (ahead of camera)
  │
  ├─ Player swipes L/R → LaneController tweens leader.position.x
  │
  ├─ Leader enters Gate.Area3D
  │     │
  │     ▼
  │  Gate emits gate_triggered(type, value)
  │     │
  │     ▼
  │  CrowdManager applies modifier → count changes → HUD tweens
  │
  ├─ Leader (or crowd hit-radius) enters Obstacle.Area3D
  │     │
  │     ▼
  │  Obstacle emits obstacle_hit(damage)
  │     │
  │     ▼
  │  CrowdManager subtracts damage; if count == 0 → GAME OVER
  │
  ▼  (distance >= FINAL_DISTANCE)
END SEQUENCE
  │  LevelSpawner stops. Spawn EnemyWall(enemy_count).
  │  Leader collides with EnemyWall → MiniBrawl starts.
  ▼
MINI BRAWL (1.5 s slowdown, particle spam)
  │  if crowd > enemies → WIN; else → LOSE.
  ▼
GAME OVER SCREEN
  │  Show distance, crowd, win/lose, high-score bounce if beaten.
  │  Buttons: RESTART, MAIN MENU.
  └── back to START RUN or MAIN MENU
```

:::callout-tip[Read this diagram before writing any code]
Every script in Zerg March reacts to one of the events in this loop. If a script does
 something that is *not* a reaction to a node in this diagram, it is doing something
 the game does not need.
:::

## Mobile Constraints

Every architecture decision that follows is downstream of the mobile target. If you were
 building this for PC only, you would not need most of the tricks in this document (single
 MultiMesh, recycling ground, no per-follower physics). Fixing these constraints in your
 head first prevents the “why is this so weird?” confusion later.

Target device

Mid-range Android phone (2022–2024, Snapdragon 7-series or equivalent Mediatek).
 1080×2400 physical, ~5–6 W thermal budget, single-thread GPU submit. Target: **60 fps
 with 150+ crowd members on screen**. Fallback: 30 fps with 250 members.

Renderer choice — `Mobile`, not Forward+

Godot 4 has three renderers: *Forward+* (desktop-first, best-looking), *Mobile*
 (deferred clustering removed, mobile-tuned pipeline), and *Compatibility* (GLES3, older
 Android). We use **Mobile**: it supports every effect we need, runs well on tile-based
 GPUs, and doesn't require the GLES3 fallback path. Set at project creation — changing later
 breaks materials.

Orientation and stretch

Portrait only. Viewport `1080×1920`, stretch mode `canvas_items`, aspect
 `keep_height`. Meaning: the world coordinate system stays 1080 wide; if the physical
 phone is taller (2400 px), the extra vertical is filled by rendering more world. The camera
 handles this by pulling back slightly on taller aspect ratios (Ch 72B).

No skeletal animation for crowd

Even one animated `Skeleton3D` per crowd member would blow our frame budget.
 Followers use a static capsule mesh + a per-instance vertical sine-bob written into the
 MultiMesh transform on the CPU each frame. Leader gets the same treatment for consistency.
 If we ever want real animation, it is one MeshInstance3D on the leader only.

No dynamic lights, no shadows on followers

WorldEnvironment provides an `ambient_light` and one DirectionalLight3D with
 *shadows disabled*. Shadow maps at 200 casters would tank the frame. Baked feel comes
 from ambient + directional intensity, not real shadows.

No SSR, no SSAO, glow only

Screen-space reflections and ambient occlusion are Forward+-only in practice on this
 hardware. We enable **glow** (cheap on tile GPUs) and tonemap
 *ACES*. Everything else in WorldEnvironment stays off.

## Scene Hierarchy

One root scene (`Main.tscn`) with the eight top-level nodes below. All spawned
 content lives under `WorldContainer`; all UI lives under `UICanvas`.
 No other structural changes across the whole series.

```
Main (Node3D)                              ← Main.gd
├── WorldEnvironment                       ← ambient + glow + ACES tonemap
├── SunLight (DirectionalLight3D)          ← shadows OFF, energy 1.2
├── GroundContainer (Node3D)               ← holds the 2 recycling GroundSegments
│   ├── GroundSegment_A (StaticBody3D)     ← BoxMesh + CollisionShape3D, 12×30 m
│   └── GroundSegment_B (StaticBody3D)     ← same, sits ahead of _A
├── WorldContainer (Node3D)                ← everything the spawner drops
│   └── (empty at start; Gates/Obstacles/EnemyWall appear here at runtime)
├── Runner (CharacterBody3D)               ← Runner.gd  (the leader)
│   ├── CapsuleShape (CollisionShape3D)    ← 0.4 r × 1.6 h capsule
│   ├── LeaderMesh (MeshInstance3D)        ← visible leader capsule
│   ├── CrowdMulti (MultiMeshInstance3D)   ← CrowdManager.gd, holds followers
│   ├── GateSensor (Area3D)                ← catches Gate.Area3D overlaps
│   └── HitSensor (Area3D)                 ← catches Obstacle.Area3D overlaps
├── CameraRig (Node3D)                     ← CameraRig.gd, follows Runner.z
│   └── Camera (Camera3D)                  ← offset back 8 m, up 5 m, pitch -22°
├── UICanvas (CanvasLayer)
│   ├── HUD (Control)                      ← HUD.gd, crowd count + distance
│   ├── PauseMenu (Control, hidden)        ← PauseMenu.gd
│   └── GameOverMenu (Control, hidden)     ← GameOverMenu.gd
└── LevelSpawner (Node)                    ← LevelSpawner.gd, no visuals
```

:::callout-warning[Why the crowd MultiMesh is a child of Runner]
Because we want the crowd's transforms to be *relative to the leader's origin*.
 That way, we compute follower offsets in local space (a static ring pattern) and the whole
 formation moves with the leader automatically. If CrowdMulti were a top-level node, we'd
 have to update every instance transform each frame with leader position — 200 extra
 transform ops we don't need.
:::

## Runner Architecture

The **Runner** is the leader CharacterBody3D. It owns three responsibilities and
 nothing else:

1. Constant forward motion (`velocity.z = -RUN_SPEED`) applied every physics tick.
2. Lane target position on X (set by `LaneController`, tweened smoothly).
3. Overlap sensors — two Area3Ds that emit signals when gates and obstacles are hit.

Everything else (crowd, camera, HUD) is a sibling or child that *reads from* the
 Runner's state; the Runner itself does not know they exist.

◆ — Runner — extends CharacterBody3D

The leader capsule. Auto-moves forward, tweens between lanes,
 hosts the crowd MultiMesh and the two overlap sensors. One instance per game.

| Property | Type | Default / Purpose |
| --- | --- | --- |
| @export run\_speed | float | `10.0` m/s forward (world Z-) |
| @export lane\_x | Array[float] | `[-2.0, 0.0, 2.0]` — three lane centres |
| @export lane\_swap\_time | float | `0.18` s tween duration |
| @export bob\_amp | float | `0.08` m — visual sine bob |
| @export bob\_freq | float | `7.5` Hz |
| current\_lane | int | `1` — index into lane\_x |
| \_lane\_tween | Tween | null when idle; active during swap |

**Do not add:** weapon logic, gate logic, obstacle logic, or crowd-count
 state. All of that belongs to Area3D-owned scripts or CrowdManager. The Runner script
 stays under ~80 lines.

## Crowd Architecture

The crowd is the load-bearing technical decision of this project. It is also the reason a
 crowd-runner is a *great* beginner walkthrough for a mobile-grade optimization — the
 naive version (200 CharacterBody3Ds) instantly cripples the phone, and the fix
 (one MultiMeshInstance3D + CPU-side transforms) teaches a technique you will use for the
 rest of your life.

:::callout-intuition[Why MultiMesh]
Rendering one static mesh 200 times with 200 separate MeshInstance3Ds costs
 **200 draw calls** — the CPU/GPU handshake dominates the frame. Rendering the
 same 200 copies through a single MultiMeshInstance3D costs **1 draw call**: the
 driver gets one command that says “here is the mesh, here are 200 transforms, draw them
 all.” This is called *instanced rendering* and every 3D engine offers some flavour
 of it.
:::

◆ — CrowdManager — extends MultiMeshInstance3D

Owns the crowd count and every follower transform. Recomputes
 the formation whenever count changes and applies a per-frame vertical sine-bob so the
 crowd doesn't look frozen.

| Property | Type | Default / Purpose |
| --- | --- | --- |
| @export max\_crowd | int | `250` — MultiMesh instance\_count |
| @export ring\_spacing | float | `0.65` m between followers |
| @export bob\_amp | float | `0.05` m follower bob amplitude |
| @export bob\_freq | float | `6.0` Hz |
| count | int | current live crowd, 1 ≤ count ≤ max\_crowd |
| \_home\_offsets | PackedVector3Array | ring positions for each slot |

**Formation formula:** ring index `r` = `floor((i + 1) / 6)`,
 angle `θ` = `((i + 1) mod 6) × (2π / 6)`, radius = `r × ring_spacing`.
 Slot 0 = leader (offset zero). Adding a member fills the next slot; removing pops the
 highest active slot.

**Follower lifecycle**: when `count` changes, CrowdManager calls
 `_apply_transforms()` which loops `i in range(max_crowd)`:

- If `i < count`: build a Transform3D at `_home_offsets[i]` + a vertical
 sine offset with a phase seeded by `i` (so the crowd bobs out-of-phase and looks
 alive), and write it into slot `i`.
- If `i >= count`: write a “zero” Transform3D — scaled to 0 — into slot
 `i`. (MultiMesh has no per-instance visibility toggle; hiding a slot is done by
 scaling it to nothing.)

:::callout-pitfall[Pitfall — resetting instance\_count at runtime]
Do *not* call `multimesh.instance_count = new_count` mid-game. Every
 change reallocates the transform buffer and can stall a frame. Set `instance_count = max_crowd`
 once at `_ready()` and manage visibility with scale-to-zero. This is the whole
 point of pre-allocating.
:::

## Gate Architecture

A **Gate** is an Area3D placed in the world by LevelSpawner. When the Runner's
 `GateSensor` enters it, the gate emits `gate_triggered(type, value)`
 and destroys itself. `CrowdManager` listens (via the EventBus) and applies the
 arithmetic.

◆ — Gate — extends Area3D

A translucent panel spanning one lane, with a Label3D showing
 the operator and value. One-shot trigger; queue\_frees on activation.

| Property | Type | Default / Purpose |
| --- | --- | --- |
| @export gate\_type | GateType enum | `ADD`, `SUB`, `MUL`, `DIV` |
| @export value | int | the operand (e.g., 5 for +5) |
| @export tint | Color | green (ADD/MUL) or red (SUB/DIV) |
| \_triggered | bool | guard so re-entry doesn't double-fire |

**Scene contents:** Area3D root + BoxShape3D CollisionShape3D (spans 2 m
 wide × 3 m tall × 0.1 m thin) + MeshInstance3D of the same size with a translucent unlit
 material + a Label3D above showing the operator text (`+5`, `×2`, etc.).

:::callout-connect[TwoGateRow prefab]
Gates are almost always spawned in *pairs* so the player picks one — that is the
 whole gameplay decision. A `TwoGateRow` scene is just a Node3D with two Gate
 children in different lanes; the spawner instances TwoGateRows, not single Gates.
:::

## Obstacle Architecture

Two obstacle types, both Area3Ds that hurt the crowd on contact:

◆ — WallObstacle — extends Area3D

A solid block occupying one lane. On first entry, subtracts a
 fixed portion of the crowd and destroys itself. Represents “chose the wrong lane.”

| @export damage | int | `10` — flat crowd subtraction |
| --- | --- | --- |
| @export scale\_damage | float | `0.0` — if > 0, damage scales with crowd size (harder walls late) |

◆ — SawObstacle — extends Area3D

A rotating hazard that damages continuously while the runner is
 inside. Encourages the player to swipe out quickly.

| @export dps | float | `15.0` crowd/second while overlapping |
| --- | --- | --- |
| @export rot\_speed | float | `6.0` rad/s visual spin |

## LevelSpawner

`LevelSpawner` is a plain Node under Main (not an autoload — its lifetime is
 tied to the run). It watches the runner's distance and drops new content ahead of the
 camera at regular intervals. It is also responsible for freeing content that has passed
 behind the camera, and for triggering the end-of-run sequence.

enum RowType { TWO\_GATE, WALL, SAW, MIXED\_GATE\_WALL }

@export var spawn\_lookahead: float = 40.0   # spawn Z distance ahead of runner
@export var despawn\_behind : float = 20.0   # queue\_free when Z is this far behind camera
@export var spawn\_step     : float = 12.0   # metres between successive rows
@export var final\_distance : float = 400.0  # end-of-run trigger
var \_next\_spawn\_z: float = -spawn\_step
var \_finished    : bool  = false

func \_physics\_process(\_dt):
    var runner\_z = runner.global\_position.z   # negative and decreasing
    # Spawn ahead
    while \_next\_spawn\_z > runner\_z - spawn\_lookahead:
        \_spawn\_row(\_next\_spawn\_z)
        \_next\_spawn\_z -= spawn\_step
    # Despawn behind
    for row in world\_container.get\_children():
        if row.global\_position.z > runner\_z + despawn\_behind:
            row.queue\_free()
    # End-of-run
    if not \_finished and abs(runner\_z) >= final\_distance:
        \_finished = true
        \_spawn\_enemy\_wall(\_next\_spawn\_z)
        EventBus.run\_finalizing.emit()

**Row selection** is a simple weighted table that gets harsher with distance:

| Distance | TWO\_GATE | WALL | SAW | MIXED |
| --- | --- | --- | --- | --- |
| 0 – 80 m | 80% | 15% | 5% | 0% |
| 80 – 200 m | 55% | 25% | 15% | 5% |
| 200 – 400 m | 40% | 25% | 20% | 15% |

Gate operands also scale: early gates are `+3` to `+8`; late gates
 include `×2`, `−12`, `÷2`.

## GameManager (Autoload)

One global autoload for state that outlives the Main scene: current run state (menu / running
 / paused / game over), the high score, and the ConfigFile-backed settings. Runs the
 scene-swap flow between menu and gameplay.

extends Node   # autoloaded as "GameManager"

enum State { MENU, RUNNING, PAUSED, GAME\_OVER }
signal state\_changed(new\_state: State)

const SAVE\_PATH := "user://zergmarch.cfg"
var state       : State = State.MENU
var high\_score  : int   = 0    # in metres, integer
var last\_score  : int   = 0

func \_ready():
    \_load\_settings()

func start\_run() -> void: ...           # change scene to Main.tscn, set state RUNNING
func end\_run(distance\_m: int) -> void:  # called by Main on death/finish; updates high\_score
func pause\_run() -> void: ...
func resume\_run() -> void: ...
func return\_to\_menu() -> void: ...

func \_load\_settings() -> void: ...      # ConfigFile: high\_score, sfx\_vol, music\_vol
func \_save\_settings() -> void: ...

Note: the run itself (spawner, crowd, camera) lives in Main.tscn. GameManager only knows
 *whether* a run is happening; it never touches the runner.

## Physics Layers

Set in Project Settings → Layer Names → 3D Physics. Every collision-capable node in the
 project uses these names.

| Layer | Name | Used by |
| --- | --- | --- |
| 1 | Ground | GroundSegment (StaticBody3D) |
| 2 | Runner | Runner (CharacterBody3D) |
| 3 | Gate | Gate.Area3D |
| 4 | Obstacle | WallObstacle, SawObstacle |
| 5 | EnemyWall | EnemyWall.Area3D (end battle) |

**Runner.collision\_layer** = 2 · **Runner.collision\_mask** = 1 (only
 ground). Runner's *GateSensor* is layer 0, mask 3 (Gate). *HitSensor* is layer 0,
 mask 4|5 (Obstacle + EnemyWall). Two Area3Ds so gate hits and obstacle hits can be routed to
 different receivers without an `if` ladder.

## Signal Flow

`EventBus` is a second autoload — a plain Node whose only purpose is to declare
 signals that anyone can emit or connect to. Zerg March uses only six of them.

extends Node   # autoloaded as "EventBus"

signal crowd\_changed(new\_count: int, delta: int)   # after any add/remove
signal gate\_triggered(gate\_type: int, value: int)  # emitted by Gate
signal obstacle\_hit(damage: int)                   # emitted by Obstacle
signal run\_started
signal run\_finalizing                              # spawner ready to place enemy wall
signal run\_finished(won: bool, distance\_m: int)

**Who emits what:**

| Signal | Emitted by | Listened to by |
| --- | --- | --- |
| crowd\_changed | CrowdManager | HUD (updates label), EnemyWall (compares on collision) |
| gate\_triggered | Gate | CrowdManager (applies arithmetic), HUD (particle burst) |
| obstacle\_hit | WallObstacle / SawObstacle | CrowdManager (subtract), CameraRig (shake) |
| run\_started | Main.\_ready() | HUD, GameManager |
| run\_finalizing | LevelSpawner | Main (spawn EnemyWall + stop spawner) |
| run\_finished | Main / EnemyWall | GameManager (record high), GameOverMenu (show) |

:::callout-tip[Why an EventBus and not direct wiring]
Because gates and obstacles are spawned dynamically and never know about the Runner or
 HUD. Wiring signals at spawn time is fragile (missed connections, order bugs). Broadcasting
 through EventBus means the receivers connect once at `_ready()` and every future
 spawn is auto-handled. This is the pattern used in Ch 70 and Ch 71 too — same idea.
:::

## Script Contracts

Every script's shape is decided *now*, before Ch 72A. When you sit down to write
 `Runner.gd` you should already know its full public surface — otherwise you will
 invent it as you go, and inconsistency creeps in.

### Runner.gd

class\_name Runner
extends CharacterBody3D

@export var run\_speed      : float = 10.0
@export var lane\_x         : Array[float] = [-2.0, 0.0, 2.0]
@export var lane\_swap\_time : float = 0.18
@export var bob\_amp        : float = 0.08
@export var bob\_freq       : float = 7.5

var current\_lane : int = 1
var \_time        : float = 0.0
var \_lane\_tween  : Tween

func \_physics\_process(dt: float) -> void          # apply velocity, bob mesh
func change\_lane(direction: int) -> void           # +1 right, -1 left
func \_tween\_to\_lane(idx: int) -> void              # internal tween helper

### CrowdManager.gd

class\_name CrowdManager
extends MultiMeshInstance3D

@export var max\_crowd    : int   = 250
@export var ring\_spacing : float = 0.65
@export var bob\_amp      : float = 0.05
@export var bob\_freq     : float = 6.0

var count : int = 1
var \_home\_offsets : PackedVector3Array
var \_time : float = 0.0

func \_ready() -> void                              # build home offsets, set instance\_count
func \_process(dt: float) -> void                   # per-frame bob update
func add\_members(n: int) -> void
func remove\_members(n: int) -> void
func set\_count(new\_count: int) -> void
func \_apply\_transforms() -> void                   # writes all instance transforms

### LaneController.gd

Composed onto Runner as a child Node — keeps input handling out of Runner.gd.

class\_name LaneController
extends Node

@export var runner\_path : NodePath
@export var min\_swipe\_px : float = 40.0

var \_touch\_start : Vector2 = Vector2.ZERO
var \_touch\_active : bool = false

func \_unhandled\_input(ev: InputEvent) -> void      # touch and keyboard both

### Gate.gd, WallObstacle.gd, SawObstacle.gd

See the node-ref boxes above; each script is under 40 lines. On `body_entered`
 they emit via `EventBus` and then `queue_free` themselves (walls and
 gates) or continue emitting per-frame (saws).

### CameraRig.gd

extends Node3D

@export var target\_path : NodePath
@export var follow\_smoothing : float = 6.0     # exponential smoothing on Z
@export var shake\_decay : float = 5.0

var \_shake\_intensity : float = 0.0

func \_process(dt: float) -> void               # follow target.z, apply shake offset
func shake(amount: float) -> void              # called by EventBus.obstacle\_hit

### HUD.gd

extends Control

@onready var crowd\_label   : Label = $Panel/CrowdLabel
@onready var distance\_label: Label = $Panel/DistanceLabel

func \_ready() -> void                          # connect EventBus signals
func \_on\_crowd\_changed(new\_count: int, delta: int) -> void   # tween + colour pulse
func \_on\_distance\_updated(m: int) -> void

## Tuning Values (the “feel” magic numbers)

All defaults exposed as `@export`. These are the starting values — the last
 thing you tune before shipping is these.

| Symbol | Value | Where | Effect if too high / too low |
| --- | --- | --- | --- |
| RUN\_SPEED | 10.0 m/s | Runner.gd | too high: no reaction time; too low: boring |
| lane\_swap\_time | 0.18 s | Runner.gd | high: sluggish; low: snappy but reads jerky |
| ring\_spacing | 0.65 m | CrowdManager.gd | high: crowd blobs; low: capsules overlap |
| min\_swipe\_px | 40 px | LaneController.gd | high: swipes ignored; low: taps trigger swaps |
| spawn\_step | 12.0 m | LevelSpawner.gd | high: sparse level; low: unfair overlap |
| spawn\_lookahead | 40.0 m | LevelSpawner.gd | < camera far plane, or content pops in |
| final\_distance | 400 m | LevelSpawner.gd | run length; 400 ≈ 40 s at 10 m/s |
| follow\_smoothing | 6.0 | CameraRig.gd | low: camera lags; high: no smoothing at all |
| bob\_freq (leader) | 7.5 Hz | Runner.gd | reads as run cadence — match to visual capsule size |

## Build Checklist

Each build chapter completes one phase. Tick these off as you finish; at the bottom, you
 have a shippable game.

#### Phase 1 — Foundation (Ch 72A + 72B)

- Mobile renderer, portrait viewport, physics layers, input map, folders, both autoloads (GameManager, EventBus) all set up
- Main scene runs; two ground segments visible and recycling
- Camera3D chases a placeholder Node3D — no runner yet, but visual scroll works

#### Phase 2 — Player (Ch 72C + 72D)

- Runner CharacterBody3D moves forward at RUN\_SPEED, does the sine-bob
- A/D keys change lanes in the editor
- Swipe on a touch device (or emulated mouse drag) changes lanes with tween
- Two Area3D sensors on Runner are present (no receivers yet)

#### Phase 3 — Crowd (Ch 72E)

- CrowdManager MultiMeshInstance3D pre-allocates max\_crowd instances
- Ring formation renders correctly at count = 1, 6, 12, 30, 100
- Per-frame bob works and doesn't spike CPU
- add\_members / remove\_members produce the expected visual change

#### Phase 4 — World Content (Ch 72F)

- Gate scene with all four GateTypes, colour-coded, Label3D shows operator
- WallObstacle scene destroys crowd on contact; SawObstacle drains over time
- TwoGateRow prefab positions two gates in two of three lanes
- EventBus.gate\_triggered / obstacle\_hit correctly modify CrowdManager.count

#### Phase 5 — Spawner & UI (Ch 72G)

- LevelSpawner spawns rows every spawn\_step and frees them behind camera
- Difficulty ramp table produces harder content over distance
- HUD Control shows crowd count + distance in portrait
- Number tweens: bounce on change, green on gain, red on loss
- Main menu, pause menu, game-over menu all working with scene transitions

#### Phase 6 — Ending, Polish & Export (Ch 72H)

- EnemyWall spawns at final\_distance with enemy\_count = f(distance)
- Mini-brawl slowdown + particle burst + win / lose resolution
- Gate/obstacle particle bursts (GPUParticles3D), camera shake, SFX buses
- WorldEnvironment: ACES tonemap + subtle glow only
- ConfigFile save/load of high\_score
- Signed debug APK installs on a physical Android device and runs at 60 fps

:::summary
## Summary — the whole game in one page

Portrait 3D endless runner. One CharacterBody3D leader, one MultiMeshInstance3D crowd
 (up to 250 followers, 1 draw call). LevelSpawner drops TwoGateRows / obstacles every 12 m
 for 400 m, then triggers the enemy-wall finale. Gates (+ − × ÷) modify crowd count;
 obstacles (wall / saw) drain it. HUD is a portrait Control with juicy tweens. Six signals
 on EventBus wire everything together. Save via ConfigFile. Ship as a signed Android APK.

**Next:** open
 [Ch 72A — Project Setup](./godot_ch72a_project_setup.html) and start clicking.
:::
