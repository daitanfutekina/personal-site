---
title: "Tweens & Timers — Time-Based Logic and Smooth Animation"
source: "markdown"
---

Part III · Chapter 28

# Tweens & Timers — Time-Based Logic and Smooth Animation

Prerequisite: Ch 4 (GDScript), Ch 3 (Nodes) · est. 70 min

## Overview

Almost every piece of visual polish in a game comes down to making things change
 *over time* in a pleasing way — a health bar sliding down smoothly, a button
 that bounces when clicked, a coin that spins and zooms into the wallet. Godot
 provides two complementary tools for this:

- **Tween** — an interpolation engine that smoothly animates any
 property from a starting value to an ending value over a set duration, with
 control over easing curves, parallel tracks, looping, and callbacks.
- **Timer / SceneTreeTimer** — event scheduling tools that fire
 a signal (or resume a coroutine) after a fixed delay.

Together they replace *most* of what developers reach for
 `AnimationPlayer` to do — Tween handles anything that is driven by code
 at runtime, while AnimationPlayer handles complex authored sequences baked in the
 editor.

## 1 · Tween Basics

### 1.1 · create\_tween()

Call `create_tween()` on any node to get a new `Tween`
 object bound to that node's lifetime. The tween starts playing immediately and
 is automatically freed when it finishes (or when its owning node is freed).

```gdscript
## Move a sprite to a target position over 0.5 seconds
func move_to(target: Vector2) -> void:
    var tw := create_tween()
    tw.tween_property(self, "position", target, 0.5)

## Fade out a CanvasItem
func fade_out() -> void:
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.3)
    # The node still exists but is invisible — free it when done:
    tw.tween_callback(queue_free)
```

### 1.2 · tween\_property() in depth

`tween_property(object, property, final_val, duration)` is the
 workhorse. It interpolates the named property from its *current* value
 (at the time the tweener runs) to `final_val` over
 `duration` seconds.

| Modifier | Effect | Example |
| --- | --- | --- |
| `.from(value)` | Explicitly set the starting value instead of using current. | `tw.tween_property(self,"scale",Vector2.ONE,0.3).from(Vector2.ZERO)` |
| `.from_current()` | Explicitly read the current value at the *moment the tweener starts*  (delayed tweeners need this when the property may change between setup and  execution). | `.from_current()` |
| `.as_relative()` | Treat `final_val` as an offset from the current value, not  an absolute target. | `tw.tween_property(self,"position:x",50.0,0.2).as_relative()`  — moves 50 px to the right. |
| `.set_trans(trans)` | Override the transition curve for this tweener. | `.set_trans(Tween.TRANS_BOUNCE)` |
| `.set_ease(ease)` | Override the ease direction for this tweener. | `.set_ease(Tween.EASE_OUT)` |
| `.set_delay(secs)` | Wait before starting this tweener. | `.set_delay(0.2)` |

### 1.3 · Easing and Transition enums

The `Trans` enum controls the *shape* of the curve (sine wave,
 bounce, spring, etc.) and the `Ease` enum controls whether the curve
 is applied at the start, end, or both ends of the interpolation.

| Trans constant | Feel |
| --- | --- |
| `TRANS_LINEAR` | Constant speed — robotic, no personality. |
| `TRANS_SINE` | Smooth S-curve — natural, versatile default. |
| `TRANS_QUAD` / `CUBIC` | Faster acceleration than sine — good for UI slides. |
| `TRANS_EXPO` | Very slow start or very fast end — dramatic. |
| `TRANS_BACK` | Overshoots the target slightly then settles — satisfying button pop. |
| `TRANS_BOUNCE` | Bounces at the end like a dropped ball. |
| `TRANS_ELASTIC` | Springs past the target and oscillates — jelly-like. |
| `TRANS_SPRING` | Similar to elastic but based on a damped spring. |

| Ease constant | Meaning |
| --- | --- |
| `EASE_IN` | Curve applies at the *start* — slow start, fast end. |
| `EASE_OUT` | Curve applies at the *end* — fast start, slow end. (Most UI uses this.) |
| `EASE_IN_OUT` | Curve at both ends — slow-fast-slow. |
| `EASE_OUT_IN` | Inverted — fast-slow-fast (rarely useful). |

Tween Easing Curve Shapes

LINEAR

SINE EASE\_OUT

BACK EASE\_OUT

BOUNCE EASE\_OUT

ELASTIC EASE\_OUT

Easing curve shapes. The Y axis is the interpolated value (0→1), X axis is time. EASE\_OUT means the curve is applied at the end — fast start, decelerating finish. This is the most natural-feeling motion for UI and game objects.

```gdscript
## A button that overshoot-pops in from scale zero
func pop_in() -> void:
    scale = Vector2.ZERO
    var tw := create_tween()
    tw.tween_property(self, "scale", Vector2.ONE, 0.35) \
      .set_trans(Tween.TRANS_BACK) \
      .set_ease(Tween.EASE_OUT)

## A health bar that eases out (fast response, settles smoothly)
func set_hp_animated(new_hp: float) -> void:
    var tw := create_tween()
    tw.tween_property($HPBar, "value", new_hp, 0.4) \
      .set_trans(Tween.TRANS_SINE) \
      .set_ease(Tween.EASE_OUT)
```

## 2 · Advanced Tween Techniques

### 2.1 · Sequential vs parallel tweeners

By default, tweeners in a Tween run **sequentially** — each one

 Sequential (default) vs Parallel (.set\_parallel())

 Sequential:

 move x (0.5s)

 fade alpha (0.7s)

 scale (0.4s)

 0s
 0.5s
 1.2s
 1.6s total

 Parallel:

 move x (0.5s)

 fade alpha (0.7s)

 scale (0.4s)

 0s
 0.7s total

 Sequential: 1.6s
 Parallel: 0.7s
 All run at once,
 finish when longest ends

 Sequential tweeners run one after the other. Parallel tweeners all start at the same moment — the tween finishes when the longest one does. Mix them with `.chain()` and `.set_parallel()`.

 starts after the previous finishes. Call `tw.parallel()` to run the
 *next* tweener at the same time as the current one.

```gdscript
## Sequential: move, THEN fade out
func move_then_fade(target: Vector2) -> void:
    var tw := create_tween()
    tw.tween_property(self, "position", target, 0.4)          # runs first
    tw.tween_property(self, "modulate:a", 0.0, 0.3)           # runs after

## Parallel: move AND fade at the same time
func move_and_fade(target: Vector2) -> void:
    var tw := create_tween()
    tw.tween_property(self, "position", target, 0.4)
    tw.parallel().tween_property(self, "modulate:a", 0.0, 0.4)

## Mixed: position and alpha together, THEN scale down
func collect_coin() -> void:
    var tw := create_tween()
    tw.tween_property(self, "position", _wallet_pos, 0.5) \
      .set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
    tw.parallel().tween_property(self, "modulate:a", 0.0, 0.5)
    # This runs after both of the above finish:
    tw.tween_property(self, "scale", Vector2.ZERO, 0.1)
    tw.tween_callback(queue_free)
```

### 2.2 · tween\_callback()

`tween_callback(callable)` inserts a zero-duration step that calls
 a function at that point in the sequence. It is the cleanest way to trigger
 logic mid-animation without connecting signals:

```gdscript
## Play a sound at the peak of a jump arc
func animate_jump_arc() -> void:
    var tw := create_tween()
    tw.tween_property(self, "position:y", position.y - 80, 0.3) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.tween_callback(func(): $AudioStreamPlayer.play())   # sound at apex
    tw.tween_property(self, "position:y", position.y, 0.3) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)

## Chain scene change after a fade
func go_to_next_level() -> void:
    var tw := create_tween()
    tw.tween_property($FadeOverlay, "modulate:a", 1.0, 0.4)
    tw.tween_callback(func():
        get_tree().change_scene_to_file("res://scenes/level_02.tscn")
    )
```

### 2.3 · tween\_method()

`tween_method(callable, from, to, duration)` calls a function every
 frame with an interpolated value. Use it to animate things that are not
 directly accessible as node properties — shader parameters, audio volume,
 custom draw calls:

```gdscript
## Animate a shader uniform (from Chapter 19)
func flash_white(duration: float) -> void:
    var mat := ($Sprite2D.material as ShaderMaterial)
    var tw  := create_tween()
    # Ramp flash_amount from 0.0 → 1.0 → 0.0
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("flash_amount", v),
        0.0, 1.0, duration * 0.5
    )
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, duration * 0.5
    )

## Animate bus volume (dB) via AudioServer
func fade_music_out(duration: float) -> void:
    var bus := AudioServer.get_bus_index("Music")
    var start_db := AudioServer.get_bus_volume_db(bus)
    var tw := create_tween()
    tw.tween_method(
        func(db: float): AudioServer.set_bus_volume_db(bus, db),
        start_db, -80.0, duration
    )
```

### 2.4 · Looping, pausing, and killing

```gdscript
## Pulse the scale of a "new item" badge indefinitely
var _badge_tween: Tween = null

func start_badge_pulse() -> void:
    if _badge_tween and _badge_tween.is_running():
        return   # already pulsing
    _badge_tween = create_tween().set_loops()   # infinite loops
    _badge_tween.tween_property(self, "scale", Vector2(1.15, 1.15), 0.4) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    _badge_tween.tween_property(self, "scale", Vector2.ONE, 0.4) \
        .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func stop_badge_pulse() -> void:
    if _badge_tween:
        _badge_tween.kill()   # stop immediately
        _badge_tween = null
        scale = Vector2.ONE

## Pause and resume (e.g. on game pause)
func _on_game_paused(paused: bool) -> void:
    if _badge_tween:
        if paused: _badge_tween.pause()
        else:      _badge_tween.play()
```

:::callout-warning[Warning — Tween and node lifetime]
If you call

create\_tween()

on a node and then free that node before
        the tween finishes, the tween is automatically killed — no crash, no orphan.
        However, if the tween animates a

different

node (e.g., a UI element),
        make sure the target node also remains alive for the tween's duration, or check

is\_instance\_valid(target)

inside a `tween_callback`.
:::

## 3 · Timer Node & SceneTreeTimer

### 3.1 · The Timer node

A `Timer` node is the right choice when a delay needs to be
 *persistent* and *reconfigurable* — a cooldown on a weapon, a
 wave spawner, a periodic event. Its key properties:

| Property / Method | Description |
| --- | --- |
| `wait_time` | Duration in seconds before the `timeout` signal fires. |
| `one_shot` | If `true`, the timer stops after firing once. If `false` (default), it restarts automatically. |
| `autostart` | Start counting down automatically when the node enters the tree. |
| `start(time_sec)` | Start (or restart) the timer. Optionally override `wait_time`. |
| `stop()` | Stop and reset the timer without emitting `timeout`. |
| `time_left` | Seconds remaining until the next timeout. |
| `is_stopped()` | Returns `true` if the timer is not running. |

```gdscript
## Weapon with a fire-rate cooldown Timer
extends Node2D

@onready var cooldown: Timer = $CooldownTimer

func _ready() -> void:
    cooldown.wait_time = 0.15   # 150 ms between shots
    cooldown.one_shot  = true
    cooldown.stop()             # starts idle

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("fire") and cooldown.is_stopped():
        _fire()
        cooldown.start()   # begin cooldown

func _fire() -> void:
    Pools.bullets.acquire()    # from Chapter 26

## Wave spawner — repeating timer
@onready var wave_timer: Timer = $WaveTimer

func _ready() -> void:
    wave_timer.wait_time = 5.0
    wave_timer.timeout.connect(_spawn_wave)
    wave_timer.start()

func _spawn_wave() -> void:
    for _i in randi_range(3, 7):
        _spawn_enemy()
```

### 3.2 · SceneTreeTimer — one-shot inline delays

`get_tree().create_timer(sec)` creates a lightweight, node-free timer
 that emits `timeout` once. It never needs a node in the scene tree
 and is the idiomatic way to insert a brief pause inside a coroutine:

```gdscript
## Show a message, wait 2 seconds, then hide it (no Timer node needed)
func show_message(text: String) -> void:
    $MessageLabel.text    = text
    $MessageLabel.visible = true
    await get_tree().create_timer(2.0).timeout
    $MessageLabel.visible = false

## Staggered enemy spawning — cleaner than managing an array of Timers
func spawn_wave(count: int) -> void:
    for i in count:
        _spawn_enemy_at(_get_spawn_point(i))
        await get_tree().create_timer(0.3).timeout   # 0.3 s between each spawn

## Respawn after death
func die() -> void:
    visible = false
    set_physics_process(false)
    await get_tree().create_timer(3.0).timeout
    _respawn()
```

### 3.3 · await patterns

Godot's `await` keyword suspends a coroutine until a signal fires,
 then resumes execution on the next line. This lets you write sequential
 time-based logic as straight-line code rather than nested callbacks:

```gdscript
## Cutscene sequence written as a single linear coroutine
func play_intro_cutscene() -> void:
    $CutsceneUI.visible = true

    # Character walks in
    var tw := create_tween()
    tw.tween_property($Character, "position:x", 400, 1.5) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    await tw.finished

    # Pause for dramatic effect
    await get_tree().create_timer(0.5).timeout

    # Dialogue appears word by word
    for word in "Hello, adventurer! Are you ready?".split(" "):
        $DialogueLabel.text += word + " "
        await get_tree().create_timer(0.12).timeout

    # Wait for player to press confirm
    await $ConfirmButton.pressed

    # Fade out and start game
    tw = create_tween()
    tw.tween_property($CutsceneUI, "modulate:a", 0.0, 0.4)
    await tw.finished
    $CutsceneUI.visible = false
    get_tree().change_scene_to_file("res://scenes/level_01.tscn")
```

:::callout-pitfall[Pitfall — await and freed nodes]
If the node that owns a coroutine is freed while the coroutine is suspended at an

await

, the coroutine is discarded and simply never resumes — nothing after the

await

runs, including any cleanup you were relying on. The case worth guarding is the other one: the coroutine's own node survives, but some

other

node it captured has been freed by the time it wakes. That coroutine does resume, and the reference is dangling:

```gdscript
await get_tree().create_timer(2.0).timeout
if not is_instance_valid(self):
    return   # node was freed while we were waiting
```
:::

## 4 · Game-Feel Micro-Polish

Tweens and timers are the primary tool for *game feel* — the invisible layer
 of animation, timing, and feedback that makes a game feel satisfying to play.
 Here are four common patterns every developer should have in their toolkit.

### 4.1 · Squash & stretch

Squashing (compressing along one axis) and stretching (extending it) are the
 foundational animation principles for making objects feel physical. A simple Tween
 implementation for a 2D sprite:

```gdscript
## Squash on landing, stretch on jump takeoff
func squash(amount: float = 0.3, duration: float = 0.15) -> void:
    var tw := create_tween()
    # Squash: wide and short
    tw.tween_property(self, "scale",
        Vector2(1.0 + amount, 1.0 - amount * 0.5), duration * 0.4) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    # Recover to normal
    tw.tween_property(self, "scale", Vector2.ONE, duration * 0.6) \
      .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func stretch(amount: float = 0.25, duration: float = 0.12) -> void:
    var tw := create_tween()
    # Stretch: narrow and tall
    tw.tween_property(self, "scale",
        Vector2(1.0 - amount * 0.5, 1.0 + amount), duration * 0.3) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    # Recover
    tw.tween_property(self, "scale", Vector2.ONE, duration * 0.7) \
      .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

## Call from the physics FSM:
## landing → squash();  jump take-off → stretch()
```

### 4.2 · Damage flash

A brief white flash when a character takes damage gives instant visual feedback.
 Done with `tween_method` to drive a shader parameter (see Chapter 19
 for the shader itself), or with a simple modulate approach for sprites without a
 custom shader:

```gdscript
## Modulate-based flash (no custom shader required)
func flash_damage(flashes: int = 3, interval: float = 0.08) -> void:
    var tw := create_tween()
    for _i in flashes:
        tw.tween_property(self, "modulate", Color.RED, interval * 0.5)
        tw.tween_property(self, "modulate", Color.WHITE, interval * 0.5)
    tw.tween_property(self, "modulate", Color.WHITE, 0.0)   # ensure clean end

## Shader-based flash (higher quality, supports opaque sprites)
func flash_white(duration: float = 0.12) -> void:
    var mat := ($Sprite2D.material as ShaderMaterial)
    var tw  := create_tween()
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("flash_amount", v),
        0.0, 1.0, duration * 0.3
    )
    tw.tween_method(
        func(v: float): mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, duration * 0.7
    )
```

### 4.3 · UI pop-ins and slide-outs

UI panels should not simply appear — they should *arrive*. A few
 reliable patterns that work well at any resolution:

```gdscript
## Panel slides in from the right
func slide_in_from_right(panel: Control) -> void:
    var offscreen_x := get_viewport_rect().size.x
    panel.position.x = offscreen_x   # start off-screen
    panel.visible    = true
    var tw := create_tween()
    tw.tween_property(panel, "position:x", 0.0, 0.35) \
      .set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

func slide_out_to_right(panel: Control) -> void:
    var offscreen_x := get_viewport_rect().size.x
    var tw := create_tween()
    tw.tween_property(panel, "position:x", offscreen_x, 0.25) \
      .set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
    tw.tween_callback(func(): panel.visible = false)

## Score pop: number flies up and fades
func spawn_score_popup(amount: int, world_pos: Vector2) -> void:
    var lbl := Label.new()
    lbl.text = "+%d" % amount
    lbl.add_theme_font_size_override("font_size", 24)
    add_child(lbl)
    lbl.global_position = world_pos

    var tw := create_tween()
    tw.tween_property(lbl, "position:y", lbl.position.y - 60, 0.6) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(lbl, "modulate:a", 0.0, 0.6) \
      .set_delay(0.2)
    tw.tween_callback(lbl.queue_free)
```

### 4.4 · Screen shake via Tween

A lightweight screen-shake that does not require modifying the camera script —
 just an offset applied to the camera's position and decayed back to zero:

```gdscript
## In a CameraShake autoload (CanvasLayer with a Camera2D child), OR
## as a method on Camera2D directly:

var _shake_tween: Tween = null

func shake(strength: float = 8.0, duration: float = 0.4) -> void:
    if _shake_tween:
        _shake_tween.kill()

    _shake_tween = create_tween().set_loops(
        int(duration / 0.04)   # number of shake steps
    )
    _shake_tween.tween_method(
        func(_v: float) -> void:
            offset = Vector2(
                randf_range(-strength, strength),
                randf_range(-strength, strength)
            ),
        0.0, 1.0, 0.04
    )
    _shake_tween.finished.connect(func(): offset = Vector2.ZERO)

## Usage: shake the camera on explosion
func _on_explosion() -> void:
    $Camera2D.shake(12.0, 0.5)
```

:::callout-connect[Connect — AnimationPlayer vs Tween]
Use

AnimationPlayer

when a sequence is authored in the editor,
        involves many properties, uses Call Method tracks, or needs to be previewed by a
        non-programmer.  Use

Tween

when the animation is driven by
        runtime data (target position, damage amount, dynamic UI layout), when you need
        to interrupt or reverse it in response to game events, or when you simply don't
        want the overhead of an .anim resource for a two-property fade.
:::

## Summary

`Tween` is Godot 4's primary tool for code-driven property animation.
 `tween_property()` handles the common case of smoothly interpolating
 from A to B; the `Trans` and `Ease` enums control the curve
 shape; tweeners chain sequentially by default and run in parallel after a
 `parallel()` call. `tween_callback()` injects logic mid-
 sequence; `tween_method()` calls any function with an interpolated value,
 enabling animation of shader uniforms, audio parameters, and custom draw data.
 Loops are trivial with `set_loops()`, and `kill()` stops a
 tween at any time.

For *scheduling*, a `Timer` node is the right tool when the
 delay is persistent and reconfigurable (weapon cooldowns, wave spawners).
 `get_tree().create_timer()` is ideal for one-shot inline delays inside
 `await` coroutines, which let you write sequential time-based logic as
 natural straight-line code. Combined with the four game-feel patterns — squash
 & stretch, damage flash, UI pop-ins, and screen shake — these tools let you
 add the micro-polish layer that separates a feeling prototype from a satisfying
 game.

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Bounce-in button

Write a `bounce_in()` function for a `Button` node
 that animates it from `scale = Vector2.ZERO` to
 `scale = Vector2.ONE` over 0.4 s using
 `TRANS_BACK / EASE_OUT`. Call it from `_ready()`
 on a Button in a test scene.

::::solution[Solution]
```gdscript
extends Button

func _ready() -> void:
    bounce_in()

func bounce_in() -> void:
    scale = Vector2.ZERO
    var tw := create_tween()
    tw.tween_property(self, "scale", Vector2.ONE, 0.4) \
      .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
```
::::
:::

:::problem{difficulty="easy"}
### P2 · Weapon cooldown Timer

Add a `Timer` child to a weapon node. Set
 `wait_time = 0.2`, `one_shot = true`. The player
 fires by pressing the "fire" action; if the timer is still running, the
 shot is rejected. After firing, start the timer. Print "FIRE" on each
 successful shot and "cooldown" when rejected.

::::solution[Solution]
```gdscript
extends Node2D

@onready var cooldown: Timer = $Timer

func _ready() -> void:
    cooldown.wait_time = 0.2
    cooldown.one_shot  = true

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("fire"):
        if cooldown.is_stopped():
            print("FIRE")
            cooldown.start()
        else:
            print("cooldown")
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Animated health bar

Create a HUD with two overlapping `ProgressBar` nodes:
 a "ghost" bar that represents the previous HP value (tinted yellow) and
 a "current" bar that shows actual HP (tinted red). When
 `set_hp(new_val)` is called:

1. Instantly set the current bar to `new_val`.
2. After a 0.3 s delay, smoothly animate the ghost bar down to
 `new_val` over 0.5 s (TRANS\_SINE, EASE\_OUT).

::::solution[Solution]
```gdscript
extends Control

@onready var current_bar: ProgressBar = $CurrentBar
@onready var ghost_bar:   ProgressBar = $GhostBar

func _ready() -> void:
    current_bar.max_value = 100
    ghost_bar.max_value   = 100
    current_bar.value = 100
    ghost_bar.value   = 100

func set_hp(new_val: float) -> void:
    current_bar.value = new_val   # instant

    var tw := create_tween()
    tw.tween_property(ghost_bar, "value", new_val, 0.5) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT) \
      .set_delay(0.3)
```
::::
:::

:::problem{difficulty="standard"}
### P4 · Staggered spawn coroutine

Write a function `spawn_wave(count: int, delay: float)` that
 instantiates `count` enemy scenes one by one, with
 `delay` seconds between each spawn. Use
 `await get_tree().create_timer(delay).timeout` inside the loop.
 After all enemies are spawned, print "Wave complete".

::::solution[Solution]
```gdscript
const ENEMY_SCENE := preload("res://scenes/enemy.tscn")

func spawn_wave(count: int, delay: float) -> void:
    for i in count:
        var e := ENEMY_SCENE.instantiate()
        add_child(e)
        e.global_position = Vector2(randf_range(100, 1180), 50)
        await get_tree().create_timer(delay).timeout
    print("Wave complete")
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Floating score popup

Write `spawn_score_popup(amount: int, world_pos: Vector2)`.
 Instantiate a Label, position it at `world_pos`, animate it
 upward 50 px over 0.6 s, fade its alpha to 0 starting after 0.2 s, and
 free it when done. Use a single Tween with both sequential and parallel
 tweeners.

::::solution[Solution]
```gdscript
func spawn_score_popup(amount: int, world_pos: Vector2) -> void:
    var lbl := Label.new()
    lbl.text = "+%d" % amount
    lbl.add_theme_font_size_override("font_size", 20)
    add_child(lbl)
    lbl.global_position = world_pos

    var tw := create_tween()
    tw.tween_property(lbl, "position:y",
        lbl.position.y - 50.0, 0.6) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(lbl, "modulate:a", 0.0, 0.4) \
      .set_delay(0.2)
    tw.tween_callback(lbl.queue_free)
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full game-feel suite

Build a reusable `GameFeel` autoload (Node) that exposes four
 static-style methods callable from anywhere in the game:

1. `screen_shake(node: Camera2D, strength: float, duration: float)`
2. `damage_flash(sprite: CanvasItem, color: Color, flashes: int)`
3. `squash(node: Node2D, amount: float)`
4. `score_popup(parent: Node, amount: int, pos: Vector2)`

Demonstrate all four triggering simultaneously when the player takes damage.

::::solution[Solution]
```gdscript
# GameFeel.gd  (Autoload)
extends Node

func screen_shake(cam: Camera2D, strength: float = 8.0,
                  duration: float = 0.35) -> void:
    var steps := int(duration / 0.04)
    var tw := cam.create_tween().set_loops(steps)
    tw.tween_method(func(_v: float):
        cam.offset = Vector2(
            randf_range(-strength, strength),
            randf_range(-strength, strength)),
        0.0, 1.0, 0.04)
    tw.finished.connect(func(): cam.offset = Vector2.ZERO)

func damage_flash(sprite: CanvasItem,
                  color: Color = Color.RED,
                  flashes: int = 3) -> void:
    var tw := sprite.create_tween()
    for _i in flashes:
        tw.tween_property(sprite, "modulate", color, 0.05)
        tw.tween_property(sprite, "modulate", Color.WHITE, 0.05)
    tw.tween_property(sprite, "modulate", Color.WHITE, 0.0)

func squash(node: Node2D, amount: float = 0.3) -> void:
    var tw := node.create_tween()
    tw.tween_property(node, "scale",
        Vector2(1.0 + amount, 1.0 - amount * 0.5), 0.07) \
      .set_trans(Tween.TRANS_SINE)
    tw.tween_property(node, "scale", Vector2.ONE, 0.12) \
      .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func score_popup(parent: Node, amount: int, pos: Vector2) -> void:
    var lbl := Label.new()
    lbl.text = "+%d" % amount
    lbl.add_theme_font_size_override("font_size", 22)
    parent.add_child(lbl)
    lbl.global_position = pos
    var tw := lbl.create_tween()
    tw.tween_property(lbl, "position:y", lbl.position.y - 55, 0.55) \
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(lbl, "modulate:a", 0.0, 0.35).set_delay(0.2)
    tw.tween_callback(lbl.queue_free)

# In player.gd:
# func take_damage(amount: int) -> void:
#     hp -= amount
#     GameFeel.screen_shake($Camera2D, 10.0, 0.4)
#     GameFeel.damage_flash($Sprite2D)
#     GameFeel.squash(self)
#     GameFeel.score_popup(get_parent(), -amount, global_position)
```
::::
:::
