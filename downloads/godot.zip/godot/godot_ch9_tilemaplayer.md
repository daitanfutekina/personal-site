---
title: "TileMapLayer — Building 2D Worlds with Tiles"
source: "godot_ch9_tilemaplayer.html"
---

Part II · Chapter 9

# TileMapLayer — Building 2D Worlds with Tiles

Estimated reading time: 90 min · Prerequisites: Ch 8 (2D Physics)

## Overview

Most 2D games — platformers, top-down RPGs, dungeon crawlers — build their
 worlds from **tiles**: small rectangular images arranged on a
 grid. Godot 4.x handles this with **TileMapLayer**, a node that
 efficiently renders thousands of tiles while integrating physics collision,
 navigation mesh, and autotile terrain rules — all configurable in the editor
 without writing a line of code.

In Godot 4.0–4.1, a single **TileMap** node managed multiple
 rendering layers internally. Starting in Godot 4.2 (and the model used in 4.6),
 each rendering layer is a separate **TileMapLayer** node. This
 gives you full scene-tree control: you can show/hide, script, or reparent
 individual layers independently. The old TileMap node still exists for
 compatibility but is deprecated — all new projects should use TileMapLayer.

By the end of this chapter you will be able to:

- Create a TileSet, import a tile atlas, and define tiles with physics collision in the editor
- Paint, erase, and flood-fill tiles using the Tile Map editor toolbar
- Set up autotile terrain rules so ground tiles connect seamlessly
- Add navigation polygons to tiles for pathfinding agents
- Read and write cells at runtime from GDScript for procedural level generation
- Store and query custom per-tile data (e.g., "slippery", "damage", "coin value")

⬡ — TileMapLayer — inherits Node2D

Renders a single layer of tiles from a shared `TileSet` resource onto a 2D grid. In Godot 4 the old monolithic TileMap was split into individual TileMapLayer nodes — one per visual or logical layer. This separation lets you stack ground, decorations, and foreground objects as separate nodes with independent z-ordering, physics layers, and navigation layers, while all sharing the same TileSet palette.

| Property | Default | What it does |
| --- | --- | --- |
| tile\_set | null | **Required.** The TileSet resource defining all available tiles, their atlases, collision polygons, terrain sets, and custom data. Multiple TileMapLayer nodes share one TileSet |
| enabled | true | If false, the layer is hidden AND its collision/navigation is disabled — useful for toggling entire map layers at runtime |
| y\_sort\_enabled | false | Enable Y-sorting so tiles and sprites at lower Y positions draw on top — essential for top-down RPG depth sorting |
| y\_sort\_origin | 0 | Pixel offset for Y-sort calculation within the tile (e.g. move to character feet for top-down games) |
| z\_index | 0 | Draw order relative to other CanvasItem nodes — use to place decoration layers in front of/behind the character |
| rendering\_quadrant\_size | 16 | Tiles per render chunk. Larger = fewer draw calls on large maps; smaller = finer culling on sparse maps |
| collision\_enabled | true | Whether tile collision polygons generate physics shapes. Disable on purely decorative layers to save CPU |
| collision\_visibility\_mode | DEFAULT | FORCE\_SHOW: always show collision outlines (debug). DEFAULT: show only in editor debug draw |
| navigation\_enabled | true | Whether tiles with navigation polygons contribute to the NavigationServer navmesh. Disable on non-walkable layers |

Use when:

building any tile-based map — platformers, top-down RPGs, dungeon crawlers, strategy grids.

Layer strategy:

Ground (collision on) → Decorations (collision off, y\_sort\_enabled) → Foreground (z\_index above player). Each is a separate TileMapLayer node sharing one TileSet.

Runtime API:

set\_cell(coords, source\_id, atlas\_coords)

to place tiles,

get\_cell\_source\_id(coords)

to query them,

get\_used\_cells()

to iterate all non-empty cells.

## 1 · The TileMapLayer Node

**TileMapLayer** is a 2D node that renders a grid of tiles
 defined by a shared **TileSet** resource. You can have as many
 TileMapLayer nodes in a scene as you need — one for the ground, one for
 decorative details, one for hazard objects — each with its own Z-index, modulate
 colour, and physics properties.

### The TileSet resource

The TileSet is the *database* that describes every tile available to
 all TileMapLayer nodes that share it. It stores:

- **Tile sources** — atlas textures sliced into tiles, or individual scene tiles
- **Collision polygons** — physics shapes per tile (on a per-physics-layer basis)
- **Navigation polygons** — walkable areas per tile
- **Terrain sets & terrain bits** — autotile matching rules
- **Custom data layers** — arbitrary typed data attached to each tile
- **Tile size** — default 16 × 16 px but configurable per TileSet

The TileSet is a saved `.tres` resource file — multiple scenes can
 reference the same TileSet so they all share the same tile library. Edit it
 by selecting any TileMapLayer that uses it and opening the
 **TileSet** bottom panel.

:::callout-tip[One TileSet, many layers]
All TileMapLayer nodes in the same scene (or across scenes) can share one
 TileSet resource. This means a physics collision you define on a tile is
 available to every layer that uses that TileSet — you define it once.
:::

### Tile atlases

The most common tile source is an **atlas**: one big image
 (a "spritesheet") containing all your tiles arranged on a uniform grid.
 To add an atlas:

1. Select a TileMapLayer, open the **TileSet** bottom panel.
2. Click **+** in the Sources section → *Atlas*.
3. Drag your texture from the FileSystem dock into the **Texture** slot.
4. Set **Texture Region Size** to match one tile's pixel dimensions.
5. Godot slices the atlas and shows a grid of available tiles.

Each tile in the atlas is identified by its `atlas_coords: Vector2i`
 — column and row in the atlas grid. You can assign different properties to
 every tile (or leave them default and they inherit the atlas source's settings).

:::callout-warning[Pixel art: disable filtering]
By default Godot uses bilinear filtering on textures, making pixel art
 blurry. Import your tile atlas with **Filter: Nearest** (select
 the file in the FileSystem dock → Import tab → Filter → Nearest → Reimport).
 Also set the project's default texture filter to Nearest in
 Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter.
:::

## 2 · Painting Tiles in the Editor

Select any TileMapLayer node in the scene and Godot opens the
 **TileMap editor** toolbar above the 2D viewport. This is where
 you paint the world.

### Editor tools

| Tool | Shortcut | What it does |
| --- | --- | --- |
| Select | S | Select placed tiles to move or delete them |
| Paint | P | Click or drag to place the selected tile |
| Line | L | Draw a straight line of tiles |
| Rectangle | R | Fill a rectangle region with a tile |
| Bucket Fill | B | Flood-fill a contiguous empty region |
| Eyedropper | I | Pick the tile under the cursor as the active tile |
| Erase | E | Delete placed tiles |
| Random | D | Place tiles randomly from a multi-select in the palette |
| Scatter % | — | Probability that a paint stroke places vs. skips a tile |

In the **Tiles** panel (bottom-left when a TileMapLayer is
 selected) you choose which tile to paint by clicking its atlas cell.
 Hold Shift and drag to select a rectangular *pattern*
 — multiple tiles at once — then paint the whole pattern in one stroke.

:::callout-tip[Mirror and rotate tiles]
While the Paint tool is active, press A to flip horizontally,
 S to flip vertically, and Z / X to rotate
 90° CW / CCW. These transforms are stored per-cell, so you can use the
 same tile art in four orientations without needing extra atlas entries.
:::

### Multiple TileMapLayer nodes

In the scene tree, stack multiple TileMapLayer nodes to create rendering
 depth. A typical setup for a platformer:

```gdscript
Node2D (Level)
├─ TileMapLayer "Background"     # z_index: -1  (decorative, no physics)
├─ TileMapLayer "Terrain"        # z_index:  0  (solid ground, has physics)
├─ TileMapLayer "Foreground"     # z_index:  1  (bushes in front of player)
└─ TileMapLayer "Hazards"        # z_index:  0  (spikes, lava — Area2D physics)
```

Each layer can have its own `modulate` colour (tint the entire
 layer blue for underwater), `y_sort_enabled` (sort objects
 by their Y position for top-down perspective), and `rendering_quadrant_size`
 (internal batching tile count).

Switch between layers for editing by clicking the layer name in the
 **Layers** drop-down in the TileMap toolbar, or by selecting
 the corresponding TileMapLayer node in the Scene panel.

## 3 · Physics on Tiles

TileMapLayer integrates with the Godot 2D physics engine — each tile
 can carry a collision polygon that becomes part of the scene's static
 physics world. You define collision once in the TileSet, and every
 placed instance of that tile automatically has the right shape.

### Adding collision polygons

In the **TileSet** editor bottom panel:

1. Select the **Paint** tab and set the paint mode to
 **Physics Layer 0** (or whichever physics layer you created).
2. Click a tile in the atlas. The right panel shows its properties.
3. Under **Physics Layer 0**, click **Add Polygon**.
4. Draw the collision polygon vertices in the tile preview. For a full-tile
 solid block, a simple rectangle is fine — click the square icon to
 auto-generate a full-tile rectangle.

You need to create at least one **Physics Layer** on the TileSet
 first (TileSet Inspector → Physics Layers → Add Element). Each physics layer
 has its own `collision_layer` and `collision_mask`
 bitmask. This is the same layer system you learned in Chapter 8 — tiles
 with *Physics Layer 0* get placed on whatever layer bits you set
 on layer 0 of the TileSet.

### Tile collision layers & masks

You can have multiple physics layers on a TileSet — for example:

```gdscript
# TileSet physics layers (configured in Inspector, not code):
# Physics Layer 0: collision_layer = 1 (World), collision_mask = 2 | 4
#   → solid ground tiles
# Physics Layer 1: collision_layer = 8 (Hazards), collision_mask = 2
#   → spike/lava tiles that only hurt the player

# A tile can have polygons on both physics layers simultaneously:
# ground tile with spikes = full square on layer 0 + full square on layer 1
```

At runtime you can read and modify the TileMapLayer's physics layers via
 `TileData`, or bypass per-tile collision entirely by relying on
 a separate Area2D on the "Hazards" TileMapLayer with a single large
 collision shape.

:::callout-key[TileMapLayer IS a physics body]
TileMapLayer behaves like a **StaticBody2D** for tiles that
 have collision polygons. You do not need to add a separate StaticBody2D
 around the tilemap — Godot builds the static physics shapes automatically
 from the tile data. The TileMapLayer's own `collision_layer`
 and `collision_mask` properties in the Inspector act as overrides
 for the physics layers defined in the TileSet.
:::

:::example[One-way platform tiles]
Make a grass tile that the player can jump through from below
          but land on from above.

::::answer[TileSet editor steps]
In the TileSet editor, select the tile → Physics Layer 0 →
 draw the collision polygon → enable **One-Way** on the polygon.
 The one-way direction defaults to "up" — bodies can approach from below
 and land from above. No code required.

If you need to drop through it (Chapter 8 technique): nudge
 `position.y += 2` and set `velocity.y = 80`
 before calling `move_and_slide()`.
::::
:::

## 4 · Autotile & Terrain

Painting terrain by hand is tedious when each tile has eight possible
 neighbours. Autotile lets you define *terrain rules* and Godot
 automatically picks the correct tile variant when you paint. You get
 seamless corners, edges, and inner corners without touching a single
 tile manually.

### Setting up terrain sets

In the TileSet Inspector → **Terrain Sets** → Add Element.
 Give the terrain set a name (e.g., "Grass"). Each terrain set has a
 **Mode**:

| Mode | Description | Use for |
| --- | --- | --- |
| Match Corners and Sides | Considers both the 4 adjacent (side) and 4 diagonal (corner) neighbours — 47-tile set | Blob terrain, full seamless ground |
| Match Corners | Only looks at 4 diagonal neighbours — 16-tile set | Simple square tiles without distinct edges |
| Match Sides | Only looks at 4 adjacent neighbours — 16-tile set (Wang tiles) | Decorative borders, rivers, roads |

Then create **Terrains** within the terrain set — one per
 material type. A terrain is just a name and a colour used as a label
 in the editor. You might have: Grass (green), Dirt (brown), Water (blue).

### Assigning terrain bits to tiles

With terrains defined, switch the TileSet paint mode to **Terrains**.
 Click tiles in the atlas and assign terrain bits (which corners/sides
 belong to which terrain colour). For a 47-tile blob set, you typically
 select all tiles, then use the *auto-assign* button — Godot reads
 the atlas layout and assigns bits automatically if your atlas follows
 the standard blob order.

Once bits are assigned, switch the TileMap toolbar paint mode to
 **Terrains**, pick a terrain, and paint. Godot picks the
 best-matching tile for each position based on its neighbours — corners
 fill in automatically as you expand the region.

:::callout-tip[Painting terrain from code]
Use `set_cells_terrain_connect()` to place terrain tiles
 from GDScript — useful for procedural generation. Pass a list of cell
 coordinates and the terrain set/terrain indices and Godot resolves all
 the variant lookups automatically.

```gdscript
var cells := [Vector2i(0,0), Vector2i(1,0), Vector2i(2,0)]
# terrain_set_id = 0, terrain_id = 0 (Grass)
set_cells_terrain_connect(cells, 0, 0)
```
:::

## 5 · Navigation on Tiles

2D navigation (pathfinding for enemies, followers, AI agents) in Godot
 uses a navigation mesh baked from **NavigationPolygon**
 regions. TileMapLayer can bake navigation polygons directly from tile data —
 no separate NavigationRegion2D nodes needed for tile-based maps.

### Setting up tile navigation

1. In the TileSet Inspector → **Navigation Layers** → Add Element.
2. In the TileSet editor, paint mode → **Navigation Layer 0**.
3. For each walkable tile, draw a navigation polygon in the tile preview
 (or click the square auto-fill icon for a full-tile polygon).
4. Non-walkable tiles (walls, water) get no navigation polygon.

At runtime, a **NavigationAgent2D** on any node can request paths.
 The navigation server reads the baked mesh from all TileMapLayer nodes
 automatically:

```gdscript
extends CharacterBody2D

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

func move_to(target: Vector2) -> void:
    nav_agent.target_position = target

func _physics_process(delta: float) -> void:
    if nav_agent.is_navigation_finished():
        return

    var next := nav_agent.get_next_path_position()
    var dir   := (next - global_position).normalized()
    velocity  = dir * 150.0
    move_and_slide()
```

:::callout-warning[Re-bake navigation after changing tiles at runtime]
If you modify the tilemap at runtime (place or remove tiles), the navigation
 mesh does not update automatically. Call
 `NavigationServer2D.bake_from_source_geometry_data()` or use a
 `NavigationRegion2D` with `bake_navigation_polygon()`
 to re-bake. For frequently changing maps, consider maintaining a separate
 navigation mesh instead of relying on tile-baked navigation.
:::

## 6 · Runtime Tile Manipulation

TileMapLayer exposes a complete GDScript API for reading and writing tile
 cells at runtime. This is the foundation of procedural level generation,
 destructible terrain, and runtime puzzle boards.

### set\_cell and get\_cell\_source\_id

| Method | Description |
| --- | --- |
| `set_cell(coords, source_id, atlas_coords, alt_tile)` | Place a tile. `source_id = -1` erases the cell. |
| `get_cell_source_id(coords)` | Returns the source ID at coords, or `-1` if empty. |
| `get_cell_atlas_coords(coords)` | Returns the `Vector2i` atlas position of the placed tile. |
| `get_cell_tile_data(coords)` | Returns the `TileData` object for reading/writing custom data. |
| `get_used_cells()` | Array of all `Vector2i` coordinates that have a tile placed. |
| `get_used_rect()` | Returns a `Rect2i` bounding box around all placed tiles. |
| `erase_cell(coords)` | Removes the tile at coords (same as `set_cell(coords, -1, ...)`). |
| `clear()` | Removes all tiles from this layer. |
| `map_to_local(map_coords)` | Converts grid coordinates to local pixel position (tile centre). |
| `local_to_map(local_pos)` | Converts a local pixel position to the grid cell it falls in. |

```gdscript
@onready var terrain_layer: TileMapLayer = $Terrain

# Find which tile the player is standing on:
func get_tile_under_player(player_pos: Vector2) -> Vector2i:
    var local := terrain_layer.to_local(player_pos)
    return terrain_layer.local_to_map(local)

# Destroy a tile (e.g. player digs):
func dig_tile(map_coords: Vector2i) -> void:
    if terrain_layer.get_cell_source_id(map_coords) == -1:
        return   # already empty
    # Spawn a particle at the tile's world position:
    var pos := terrain_layer.to_global(terrain_layer.map_to_local(map_coords))
    spawn_vfx(pos)
    terrain_layer.erase_cell(map_coords)

# Place a tile from GDScript:
func place_tile(map_coords: Vector2i, atlas_col: int, atlas_row: int) -> void:
    terrain_layer.set_cell(map_coords, 0, Vector2i(atlas_col, atlas_row))
```

### Procedural generation

Because `set_cell` is fast, you can generate entire levels
 in code. The pattern is: clear the layer, iterate over every cell in
 a grid, and decide what tile to place based on noise, rooms, or rules.

:::example[Simple noise-based cave generator]
Generate a 50 × 30 tile cave map using FastNoiseLite. Cells with
          noise value > 0.1 become solid rock; others are empty.

::::answer[GDScript — run in \_ready()]
```gdscript
extends TileMapLayer

const MAP_W   := 50
const MAP_H   := 30
const SOURCE  := 0                        # atlas source ID
const ROCK    := Vector2i(0, 0)           # atlas coords for the rock tile
const WALL_AT := 0.1                      # noise threshold

func _ready() -> void:
    var noise := FastNoiseLite.new()
    noise.seed = randi()
    noise.frequency = 0.07

    clear()

    for x in MAP_W:
        for y in MAP_H:
            # Always solid at the border
            var is_border := (x == 0 or y == 0 or x == MAP_W-1 or y == MAP_H-1)
            if is_border or noise.get_noise_2d(x, y) > WALL_AT:
                set_cell(Vector2i(x, y), SOURCE, ROCK)
```
::::
:::

:::callout-tip[Use set\_cells\_terrain\_connect() for generated terrain]
After placing raw cells procedurally, you can pass all occupied coordinates
 to `set_cells_terrain_connect(cells, terrain_set_id, terrain_id)`
 to automatically resolve the correct tile variant for every cell based on its
 neighbours. This is far faster than computing terrain bits manually.
:::

## 7 · Custom Tile Data

Every tile in a TileSet can carry arbitrary typed data through
 **Custom Data Layers**. This replaces the need for
 lookup dictionaries keyed on atlas coordinates. You define the data
 layer once in the TileSet, set values per-tile in the editor, and
 read them from GDScript at runtime.

To add a custom data layer: TileSet Inspector → **Custom Data Layers**
 → Add Element → set a **Name** (e.g., "damage\_per\_second")
 and a **Type** (float, int, bool, Color, String, etc.).

Then in the TileSet editor, paint mode → **Custom Data** →
 select the layer → click each tile and type its value.

```gdscript
@onready var hazard_layer: TileMapLayer = $Hazards

func get_tile_damage(map_coords: Vector2i) -> float:
    var tile_data := hazard_layer.get_cell_tile_data(map_coords)
    if tile_data == null:
        return 0.0   # empty cell
    # "damage_per_second" is the name you gave the custom data layer
    return tile_data.get_custom_data("damage_per_second")

func _physics_process(delta: float) -> void:
    # Check the tile the player stands on for hazard damage
    var player_cell := hazard_layer.local_to_map(
        hazard_layer.to_local(player.global_position)
    )
    var dmg := get_tile_damage(player_cell)
    if dmg > 0.0:
        player.take_damage(dmg * delta)
```

:::callout-intuition[Custom data replaces tile-type enum checks]
Without custom data you might write:
 `if atlas_coords == Vector2i(3,0): apply_ice_effect()`
 scattered throughout your code. Custom data layers centralise that
 knowledge in the TileSet. Add a "friction" float, a "is\_ladder" bool,
 a "footstep\_sound" String — your game logic reads data, not atlas
 coordinates. Changing tile art no longer breaks game rules.
:::

## 8 · Performance Tips

| Tip | Why it helps |
| --- | --- |
| Use a single atlas texture per TileSet | Each atlas texture is one draw call. Multiple textures = multiple draw calls per layer. |
| Keep atlas size power-of-two | GPUs handle power-of-two textures more efficiently (512×512, 1024×512, etc.). |
| Use separate TileMapLayer nodes for static vs. dynamic tiles | Godot caches static layers' render commands. Modifying a dynamic layer only invalidates that layer's cache, not the whole map. |
| Avoid calling `set_cell` every frame unnecessarily | Each `set_cell` call dirtys the render cache for that chunk. Batch changes in one frame rather than spreading over many. |
| Use `rendering_quadrant_size` wisely | Default 16. Larger values batch more tiles per draw call but increase rebuild cost when a tile changes. 32–64 is a good range for large static maps. |
| Disable physics on non-collidable layers | Set `collision_enabled = false` on decorative TileMapLayer nodes so they don't generate physics shapes. |

```gdscript
# Batch-place many tiles in one frame (cache rebuild happens once):
func fill_region(rect: Rect2i, source: int, atlas: Vector2i) -> void:
    for x in rect.size.x:
        for y in rect.size.y:
            set_cell(Vector2i(rect.position.x + x, rect.position.y + y), source, atlas)
    # All cells placed in one frame → one cache rebuild

# Disable physics on a purely visual layer:
func _ready() -> void:
    $Background.collision_enabled = false
```

:::callout-connect[Next chapter connection]
Chapter 10 covers advanced GDScript features — static typing, coroutines,
 and `await`. Many of these are especially useful in tile-based
 games: `await` lets you write step-by-step level generation
 (place tiles, pause one frame, place more) without callback spaghetti.
 `@static_unload` and static variables are useful for TileSet
 lookup caches shared across scenes.
:::

:::summary
## Chapter Summary

| Concept | Quick reference |
| --- | --- |
| TileMapLayer | One rendering + physics layer. Use multiple stacked nodes for depth. Replaces deprecated TileMap. |
| TileSet | Shared resource holding all tile definitions (atlas, collision, terrain, navigation, custom data). |
| Atlas source | Spritesheet sliced into a grid. Each tile = `Vector2i(col, row)` atlas coords. |
| Physics layers on TileSet | Each TileSet physics layer has its own collision\_layer + mask. Tiles draw polygons on any layer. |
| Autotile / Terrain | Define terrain sets + assign bits → paint terrain mode → Godot picks correct variant automatically. |
| `set_cells_terrain_connect()` | Runtime terrain painting. Pass cell list + terrain set/terrain index. |
| Navigation on tiles | Add nav polygon per walkable tile → NavigationAgent2D auto-reads baked mesh. |
| `set_cell(coords, src, atlas)` | Place tile. `src = -1` erases. Use `erase_cell()` or `clear()` for bulk removal. |
| `local_to_map / map_to_local` | Convert between pixel positions and grid coordinates. Always go through `to_local()` for world coords first. |
| Custom data layers | Typed per-tile data. Read with `get_cell_tile_data(coords).get_custom_data("name")`. |

**If you remember nothing else:** TileMapLayer = visual +
 physics built-in. Define collision in the TileSet editor once; every placed
 tile gets it automatically. Use `set_cell` for runtime changes and
 `set_cells_terrain_connect` for any terrain-aware generation.
:::

## Mixed Practice

:::problem[Problem 1 easy]{difficulty="easy"}
What is the difference between **TileMapLayer** and
 **TileSet**? If you have three TileMapLayer nodes sharing the
 same TileSet and you add a new tile with a collision polygon to the TileSet,
 which nodes are affected and how?

::::solution[Solution]
**TileSet** is the data resource — it stores the tile
 definitions (atlas, collision shapes, terrain rules, custom data). It is
 shared across layers.

**TileMapLayer** is the scene node — it renders a grid
 of cells using tile data from the TileSet. It represents one visual
 and physical layer of the map.

Adding a tile with a collision polygon to the TileSet makes that tile
 (and its collision shape) *available* to all three TileMapLayer nodes.
 Cells that were already placed using that tile in any layer will immediately
 gain the collision polygon — because TileMapLayer reads tile properties from
 the TileSet at runtime, not at placement time.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Write a function `get_tile_at_world_pos(world_pos: Vector2) -> Vector2i`
 on a TileMapLayer script that converts a world-space position to the grid
 cell the position falls in. Return `Vector2i(-999, -999)` if
 the cell is empty.

::::solution[Solution]
```gdscript
func get_tile_at_world_pos(world_pos: Vector2) -> Vector2i:
    var local    := to_local(world_pos)
    var map_pos  := local_to_map(local)
    if get_cell_source_id(map_pos) == -1:
        return Vector2i(-999, -999)
    return map_pos
```

`to_local()` converts world-space to this node's local space.
 `local_to_map()` then converts local pixel coords to tile grid coords.
 `get_cell_source_id() == -1` means no tile is placed there.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Create a **destructible tile** system: when the player fires a
 projectile and it hits the terrain TileMapLayer, erase the tile it hit and
 spawn a `GPUParticles2D` at that location. Use `move_and_collide()`
 on the projectile (Chapter 8) and the TileMapLayer API in this chapter.

::::solution[Solution]
```gdscript
# Projectile.gd (CharacterBody2D)
extends CharacterBody2D

@export var speed: float = 500.0
@onready var particles: GPUParticles2D = $DestroyParticles

var _terrain: TileMapLayer = null

func init(dir: Vector2, terrain: TileMapLayer) -> void:
    velocity  = dir * speed
    _terrain  = terrain

func _physics_process(delta: float) -> void:
    var col := move_and_collide(velocity * delta)
    if col == null:
        return

    # Did we hit the terrain?
    if col.get_collider() == _terrain:
        var hit_world := col.get_position()
        var local     := _terrain.to_local(hit_world)
        var map_pos   := _terrain.local_to_map(local)
        _terrain.erase_cell(map_pos)

        # Detach particles so they outlive the projectile
        var world_pos := _terrain.to_global(_terrain.map_to_local(map_pos))
        particles.global_position = world_pos
        particles.reparent(get_tree().current_scene)
        particles.emitting = true

    queue_free()
```
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Write a function `get_all_cells_with_data(layer: TileMapLayer, key: String, value) -> Array[Vector2i]`
 that returns every cell coordinate where the custom data field named
 `key` equals `value`. Use it to find all "spawn\_point"
 tiles at level load.

::::solution[Solution]
```gdscript
func get_all_cells_with_data(
        layer: TileMapLayer,
        key: String,
        value: Variant) -> Array[Vector2i]:
    var results: Array[Vector2i] = []
    for cell in layer.get_used_cells():
        var td := layer.get_cell_tile_data(cell)
        if td == null:
            continue
        if td.get_custom_data(key) == value:
            results.append(cell)
    return results

# Usage at level start:
func _ready() -> void:
    var spawns := get_all_cells_with_data($Terrain, "is_spawn", true)
    for cell in spawns:
        var world_pos := $Terrain.to_global($Terrain.map_to_local(cell))
        spawn_player(world_pos)
```
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
Design the terrain set and atlas configuration for a simple platformer
 with three materials: **Grass** (blob terrain, 47 tiles),
 **Stone** (blob terrain, 47 tiles), and **Water**
 (sides-only, 16 tiles that connect horizontally). How many terrain sets
 do you need, and how do you prevent water from connecting with grass?

::::solution[Solution]
**One terrain set** is enough — terrain sets group materials
 that can border each other. Add three terrains within it:

1. Terrain 0: Grass (colour green) — Mode: Match Corners and Sides (blob)
2. Terrain 1: Stone (colour grey) — Mode: Match Corners and Sides (blob)
3. Terrain 2: Water (colour blue) — Mode: Match Sides

Assign terrain bits to each tile atlas: Grass tiles get "all bits = Grass".
 Stone tiles get "all bits = Stone". Water tiles only assign *side* bits
 to Water and leave corner bits empty (since water uses Match Sides mode only).

Grass and Water will not connect because their terrain bits don't share a
 matching terrain index — when Godot looks for a tile to place at a Grass/Water
 border, neither material has bits assigned for the other, so the autotile
 system keeps them visually separated.
::::
:::

:::problem[Problem 6 challenge]{difficulty="challenge"}
Build a **procedural dungeon generator** on a TileMapLayer
 using a simple Binary Space Partitioning (BSP) approach: recursively split a
 50×40 tile rectangle into rooms (minimum size 5×5), then connect adjacent
 room centres with horizontal + vertical corridors. Solid tiles where there is
 no room or corridor; floor tiles everywhere else. Use
 `set_cells_terrain_connect()` to apply terrain after generation.

::::solution[Solution]
```gdscript
extends TileMapLayer

const W := 50; const H := 40
const MIN_ROOM := 5
const SRC := 0
const FLOOR_ATLAS := Vector2i(1, 0)
const WALL_ATLAS  := Vector2i(0, 0)

var _rooms: Array[Rect2i] = []
var _floor_cells: Array[Vector2i] = []

func _ready() -> void:
    _generate()

func _generate() -> void:
    clear()
    _rooms.clear()
    _floor_cells.clear()

    # Fill everything with walls first
    for x in W:
        for y in H:
            set_cell(Vector2i(x, y), SRC, WALL_ATLAS)

    # BSP split
    _split(Rect2i(1, 1, W - 2, H - 2))

    # Carve rooms
    for room in _rooms:
        for x in room.size.x:
            for y in room.size.y:
                _floor_cells.append(Vector2i(room.position.x + x, room.position.y + y))

    # Connect rooms with corridors
    for i in range(1, _rooms.size()):
        _carve_corridor(_rooms[i-1].get_center(), _rooms[i].get_center())

    # Place floors (terrain connect resolves correct tile variant)
    set_cells_terrain_connect(_floor_cells, 0, 0)   # terrain set 0, terrain 0 = floor

func _split(rect: Rect2i) -> void:
    # Base case: small enough to be a room
    if rect.size.x <= MIN_ROOM * 2 and rect.size.y <= MIN_ROOM * 2:
        var room := Rect2i(rect.position + Vector2i(1,1), rect.size - Vector2i(2,2))
        if room.size.x >= MIN_ROOM and room.size.y >= MIN_ROOM:
            _rooms.append(room)
        return
    # Split horizontally or vertically
    var split_h: bool = rect.size.x < rect.size.y
    if split_h:
        var mid := rect.position.y + MIN_ROOM + randi() % (rect.size.y - MIN_ROOM * 2)
        _split(Rect2i(rect.position, Vector2i(rect.size.x, mid - rect.position.y)))
        _split(Rect2i(Vector2i(rect.position.x, mid), Vector2i(rect.size.x, rect.end.y - mid)))
    else:
        var mid := rect.position.x + MIN_ROOM + randi() % (rect.size.x - MIN_ROOM * 2)
        _split(Rect2i(rect.position, Vector2i(mid - rect.position.x, rect.size.y)))
        _split(Rect2i(Vector2i(mid, rect.position.y), Vector2i(rect.end.x - mid, rect.size.y)))

func _carve_corridor(a: Vector2i, b: Vector2i) -> void:
    var x := a.x
    while x != b.x:
        _floor_cells.append(Vector2i(x, a.y))
        x += sign(b.x - x)
    var y := a.y
    while y != b.y:
        _floor_cells.append(Vector2i(b.x, y))
        y += sign(b.y - y)
```
::::
:::

Godot 4.6 Complete Reference · Part II — 2D Game Development · Generated for self-study. Edit freely.
