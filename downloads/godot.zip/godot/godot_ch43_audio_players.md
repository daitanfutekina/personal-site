---
title: "AudioStreamPlayer, AudioStreamPlayer2D & AudioStreamPlayer3D"
source: "godot_ch43_audio_players.html"
---

Part VI · Chapter 43

# AudioStreamPlayer, AudioStreamPlayer2D & AudioStreamPlayer3D

Part VI — Audio · est. 70 min · covers all three player node types, every property and method, sound pooling, and the AudioManager pattern

## Overview

Sound in Godot is split into two halves: an **AudioStream** resource that holds raw audio data, and an **AudioStreamPlayer** node that plays it. Understanding this split — resource vs. node — is the key to working with audio cleanly. This chapter covers all three player node types in full depth: every property, every method, every signal, and when to choose one over the others.

:::callout-key[Prerequisites]
Ch 5 — Signals (all three player nodes emit `finished`); Ch 6 — Resources (AudioStream is a Resource subclass); Ch 13 — Node2D (AudioStreamPlayer2D/3D need spatial context).
:::

Godot Audio Signal Chain

AudioStream

Resource (.wav / .ogg)

holds raw audio data

AudioStreamPlayer

/ 2D / 3D Node

plays, loops, volumes

emits "finished"

Audio Bus

effects (reverb, EQ…)

volume, mute, solo

Master Bus

final mix

→ speakers / output

node.bus = "SFX"

Every sound follows this chain: AudioStream resource → player node → audio bus → Master bus → output device. The `bus` property on the player node selects which bus it routes through.

## 1 · AudioStream — What You're Actually Playing

:::callout-intuition[Intuition]
An AudioStream is to audio what Texture2D is to images: a resource that holds the data, detached from the node that plays it. You can load an AudioStream once and reuse it across hundreds of sound effect instances. Godot supports several stream types; the one you will use 99% of the time for SFX is `AudioStreamWAV` (.wav) or `AudioStreamOggVorbis` (.ogg).
:::

### AudioStream subclasses

| Class | Source | Best for |
| --- | --- | --- |
| `AudioStreamWAV` | .wav | Short SFX — low decode overhead, loop points, 8/16-bit PCM |
| `AudioStreamOggVorbis` | .ogg | Music and long effects — compressed, streamed from disk |
| `AudioStreamMP3` | .mp3 | Music — supported but .ogg is preferred in Godot |
| `AudioStreamInteractive` | built from clips | Adaptive music with transition rules |
| `AudioStreamPlaylist` | list of streams | Sequential or random playlist playback |
| `AudioStreamRandomizer` | list of streams | Random variation — picks one clip per `play()` call |
| `AudioStreamPolyphonic` | no file | Multiple overlapping sounds from one player node |
| `AudioStreamGenerator` | code-generated | Procedural / synthesised audio |

### Import settings for audio files

| Setting | Default | When to change |
| --- | --- | --- |
| Loop Mode (.wav) | Disabled | Set to *Forward* for music or looping ambient |
| Loop Begin / Loop End | 0 / file end | Fine-tune loop points in samples for seamless music |
| Force Mono | false | Enable for any SFX that will be spatialised — stereo cannot be panned |
| Compress (.wav) | false | Enable to reduce RAM; adds slight decode cost |

:::callout-warning[Warning — stereo files cannot be spatialised]
AudioStreamPlayer2D and 3D compute panning by repositioning a *mono* signal between speakers. A stereo file has baked-in L/R channels that Godot cannot repan — the sound always appears dead-centre regardless of its world position. Always import positional SFX with **Force Mono** checked.
:::

### AudioStreamRandomizer — variation without code

Hearing the identical footstep sound every step breaks immersion. `AudioStreamRandomizer` wraps several clips and selects one randomly per play, optionally randomising pitch too:

```gdscript
var randomizer := AudioStreamRandomizer.new()
randomizer.add_stream(0, preload("res://sfx/step_a.wav"))
randomizer.add_stream(1, preload("res://sfx/step_b.wav"))
randomizer.add_stream(2, preload("res://sfx/step_c.wav"))
randomizer.playback_mode = AudioStreamRandomizer.PLAYBACK_RANDOM_NO_REPEATS
randomizer.random_pitch = 0.12   # ±12% pitch variation per play
$FootstepPlayer.stream = randomizer
```

## 2 · AudioStreamPlayer — Non-Spatial (UI & Music)

:::callout-intuition[Intuition]
AudioStreamPlayer plays at a fixed volume with no position in the world. The listener hears it equally loud regardless of camera position. Use it for background music, UI sounds (button clicks, menu whooshes), narrator voice-over, and any effect that should be heard identically everywhere. It is the simplest and cheapest of the three node types.
:::

### All properties

| Property | Type | Default | What it does |
| --- | --- | --- | --- |
| stream | AudioStream | null | The audio data to play. Assign any AudioStream subclass. |
| volume\_db | float | 0.0 | Volume in decibels. 0 dB = full. −6 dB ≈ half perceived loudness. −80 dB ≈ silent. |
| pitch\_scale | float | 1.0 | Playback speed multiplier. 2.0 = one octave up + double speed. 0.5 = one octave down. |
| playing | bool | false | Read-only. True while actively playing (not paused, not stopped). |
| autoplay | bool | false | Calls `play()` automatically when the node enters the scene tree. |
| stream\_paused | bool | false | Pause/resume without losing playback position. True = paused; false = playing. |
| max\_polyphony | int | 1 | Simultaneous overlapping voices from this node. Raise to 4–8 for rapid-fire effects. |
| bus | StringName | "Master" | Target audio bus. Must match a bus name in the AudioBusLayout. |

### All methods

| Method | Signature | What it does |
| --- | --- | --- |
| `play` | `play(from_position: float = 0.0)` | Starts playback. `from_position` is in seconds. |
| `stop` | `stop()` | Stops and resets playback position to 0. |
| `seek` | `seek(to_position: float)` | Jumps to a time in seconds while preserving play/pause state. |
| `get_playback_position` | `get_playback_position() → float` | Current position in seconds. Returns 0 when stopped. |
| `get_stream_playback` | `get_stream_playback() → AudioStreamPlayback` | Active playback object — needed for polyphonic and generator feeds. |
| `has_stream_playback` | `has_stream_playback() → bool` | True if a playback object exists (playing or paused). |

### Signal: `finished`

Fires when a **non-looping** stream reaches its end. Does *not* fire for looping streams or after `stop()`.

### Example A — music player with pause and resume

```gdscript
class_name MusicPlayer
extends Node

@onready var player: AudioStreamPlayer = $AudioStreamPlayer

func _ready() -> void:
    player.stream    = preload("res://music/main_theme.ogg")
    player.bus       = "Music"
    player.volume_db = -6.0
    player.autoplay  = true

func pause_music()  -> void: player.stream_paused = true
func resume_music() -> void: player.stream_paused = false
func stop_music()   -> void: player.stop()

func play_from(position_seconds: float) -> void:
    player.play(position_seconds)

func get_position() -> float:
    return player.get_playback_position()
```

Saving and restoring `get_playback_position()` is the correct way to resume music after a scene transition — store the value before changing scenes, then call `play(saved_pos)` in the new scene.

### Example B — polyphonic rapid-fire sound effects

```gdscript
@onready var sfx: AudioStreamPlayer = $GunSFX

func _ready() -> void:
    sfx.stream       = preload("res://sfx/gunshot.wav")
    sfx.max_polyphony = 8   # up to 8 simultaneous overlapping shots
    sfx.bus          = "SFX"

func fire() -> void:
    # max_polyphony > 1: play() spawns a new voice instead of restarting
    sfx.play()
    sfx.pitch_scale = randf_range(0.92, 1.08)   # avoid machine-gun effect
```

:::callout-pitfall[Pitfall]
**finished never fires for looping streams.** A looping stream never ends, so the signal never emits. Check Import settings (Loop Mode = Disabled) if your callback is never reached. Also: `pitch_scale` changes playback speed — it cannot change pitch without speed. Use `AudioEffectPitchShift` on a bus for pitch-only adjustment.
:::

## 3 · AudioStreamPlayer2D — Positional Sound in 2D

:::callout-intuition[Intuition]
AudioStreamPlayer2D places a sound in 2D world space. As the node moves away from the **AudioListener2D** (or Camera2D), volume drops and stereo panning shifts. Footsteps, explosions, enemy gunfire, environmental ambience — anything with a location in your 2D world uses this node. It extends Node2D, so attach it as a child of whatever object makes the sound.
:::

### All properties

| Property | Type | Default | What it does |
| --- | --- | --- | --- |
| stream | AudioStream | null | The audio data. Must be mono for correct panning. |
| volume\_db | float | 0.0 | Volume at the emission point — before distance attenuation. |
| pitch\_scale | float | 1.0 | Playback speed multiplier. |
| playing | bool | false | Read-only. True while actively playing. |
| autoplay | bool | false | Auto-play on entering the scene tree. |
| stream\_paused | bool | false | Pause without losing position. |
| max\_polyphony | int | 1 | Maximum simultaneous voices from this node. |
| bus | StringName | "Master" | Target audio bus. |
| max\_distance | float | 2000.0 | Pixels beyond which the sound is inaudible. |
| attenuation | float | 1.0 | Power-law falloff curve. Higher = louder close, quieter far. |
| panning\_strength | float | 1.0 | Stereo panning intensity. 0 = no panning; 2 = exaggerated. |
| area\_mask | int | 1 | Bitmask controlling which Area2D audio overrides affect this player. |

Methods are identical to AudioStreamPlayer: `play(from_position)`, `stop()`, `seek(to_position)`, `get_playback_position()`, `get_stream_playback()`, `has_stream_playback()`. Signal: `finished` — same behaviour.

### AudioListener2D

By default the Camera2D position is the "ear". To use a different point — e.g. the player character — add an **AudioListener2D** child and call `make_current()`:

```gdscript
func _ready() -> void:
    $AudioListener2D.make_current()   # this node is now the 2D listener
```

### Area2D audio bus override

An Area2D can reroute all AudioStreamPlayer2D nodes inside its bounds to a different bus — e.g. route everything inside a cave Area2D to a "Cave" bus that has reverb applied. On the Area2D: set `audio_bus_override = true` and `audio_bus_name = "Cave"`.

### Example C — enemy footsteps that fade with distance

```gdscript
class_name Enemy
extends CharacterBody2D

@onready var step: AudioStreamPlayer2D = $FootstepPlayer

const STEP_INTERVAL: float = 0.4
var _step_timer: float = 0.0

func _ready() -> void:
    var r := AudioStreamRandomizer.new()
    r.add_stream(0, preload("res://sfx/step_stone_a.wav"))
    r.add_stream(1, preload("res://sfx/step_stone_b.wav"))
    r.add_stream(2, preload("res://sfx/step_stone_c.wav"))
    r.playback_mode = AudioStreamRandomizer.PLAYBACK_RANDOM_NO_REPEATS
    r.random_pitch  = 0.08
    step.stream      = r
    step.max_distance = 600.0
    step.attenuation  = 1.5
    step.bus          = "SFX"

func _physics_process(delta: float) -> void:
    if velocity.length() > 20.0:
        _step_timer += delta
        if _step_timer >= STEP_INTERVAL:
            _step_timer = 0.0
            step.play()   # distance attenuation is automatic
```

## 4 · AudioStreamPlayer3D — Positional Sound in 3D

:::callout-intuition[Intuition]
AudioStreamPlayer3D works the same way as the 2D version but in 3D world space. It adds realistic features: multiple attenuation models, a directional emission cone (a speaker pointing away from you is quieter), Doppler shift (pitch changes as sources move towards/away), and high-frequency air absorption (distant sounds become muffled). For 3D games this is almost always the right choice for world sounds.
:::

### All properties

| Property | Type | Default | What it does |
| --- | --- | --- | --- |
| stream | AudioStream | null | Audio data. Must be mono for 3D spatialisation. |
| volume\_db | float | 0.0 | Base volume at the emission point. |
| pitch\_scale | float | 1.0 | Playback speed / pitch multiplier. |
| playing | bool | false | Read-only. True while playing. |
| autoplay | bool | false | Play on scene entry. |
| stream\_paused | bool | false | Pause without losing position. |
| max\_polyphony | int | 1 | Maximum simultaneous voices. |
| bus | StringName | "Master" | Target audio bus. |
| unit\_size | float | 10.0 | Reference distance (metres) at which `volume_db` is heard at full level. |
| max\_db | float | 3.0 | Maximum volume boost when very close to source — prevents clipping. |
| max\_distance | float | 0.0 | Hard cutoff. 0 = unlimited (attenuation only). |
| attenuation\_model | AttenuationModel | INVERSE\_DISTANCE | Volume falloff curve. Options: INVERSE\_DISTANCE, INVERSE\_SQUARE\_DISTANCE, LOGARITHMIC, DISABLED. |
| attenuation\_filter\_cutoff\_hz | float | 5000.0 | Low-pass applied at distance — far sounds become muffled (simulates air absorption). |
| attenuation\_filter\_db | float | −24.0 | High-frequency attenuation at max distance. |
| doppler\_tracking | DopplerTracking | DISABLED | Doppler pitch shift. IDLE\_STEP = \_process, PHYSICS\_STEP = \_physics\_process. |
| emission\_angle\_enabled | bool | false | Enable directional emission cone (like a speaker). |
| emission\_angle\_degrees | float | 45.0 | Half-angle of the cone. Sounds outside are attenuated. |
| emission\_angle\_filter\_attenuation\_db | float | −12.0 | Volume reduction outside the cone. |
| panning\_strength | float | 1.0 | Stereo panning strength. |
| area\_mask | int | 1 | Which Area3D reverb zones affect this player. |

### Attenuation models compared

| Model | Falloff | Best for |
| --- | --- | --- |
| INVERSE\_DISTANCE | volume ∝ 1/d | Physically accurate point sources (default) |
| INVERSE\_SQUARE\_DISTANCE | volume ∝ 1/d² | Tight indoor spaces — falls off fast |
| LOGARITHMIC | volume ∝ −log(d) | Large outdoor areas — sounds carry further |
| DISABLED | constant | No distance attenuation at all |

### Example D — 3D enemy voice with directional cone

Attenuation Model Comparison (volume vs. distance)

Distance from source

Volume

1.0

0.0

0

max

INVERSE (1/d)

INVERSE\_SQUARE

LOGARITHMIC

DISABLED (flat)

Attenuation model curves. Inverse Square drops off fastest — good for tight spaces. Logarithmic carries further — good for outdoors. Inverse is the default and most physically natural.

```gdscript
@onready var voice: AudioStreamPlayer3D = $VoicePlayer
@onready var step:  AudioStreamPlayer3D = $FootstepPlayer

func _ready() -> void:
    voice.stream    = preload("res://sfx/enemy_grunt.ogg")
    voice.unit_size = 5.0
    voice.max_distance = 30.0
    voice.emission_angle_enabled = true
    voice.emission_angle_degrees = 60.0          # ±60° cone in front
    voice.emission_angle_filter_attenuation_db = -20.0
    voice.bus = "Voice"

    step.stream  = preload("res://sfx/footstep_dirt.wav")
    step.unit_size = 3.0
    step.attenuation_filter_cutoff_hz = 2000.0   # muffled at distance
    step.doppler_tracking = AudioStreamPlayer3D.DOPPLER_TRACKING_PHYSICS_STEP
    step.bus = "SFX"
```

:::callout-pitfall[Pitfall — unit\_size calibration]
The default `unit_size = 10.0` assumes metres. If your game uses a different scale, sounds will appear to fade immediately or never. Also: `emission_angle_enabled` uses the node's local **−Z** axis as the forward direction — make sure your mesh and audio node share the same orientation, or rotate the AudioStreamPlayer3D separately.
:::

## 5 · Choosing the Right Node

AudioStreamPlayer Node Comparison

AudioStreamPlayer

AudioStreamPlayer2D

AudioStreamPlayer3D

No world position

Same volume everywhere

No attenuation

No panning

✓ Music & UI sounds

✓ Voice-over

✓ Cheapest CPU cost

GameScene, CanvasLayer

Position in 2D world

Volume drops with distance

Left/right panning

max\_distance in pixels

✓ Enemy sounds

✓ Ambient world audio

✓ Footsteps, explosions

Attach to Node2D in scene

Position in 3D world

Attenuation models

Doppler shift

Emission cone

✓ All 3D game sounds

✓ Directional speakers

✓ Air absorption

Attach to Node3D in scene

The three AudioStreamPlayer variants. Choose based on whether spatial position matters, and whether the game is 2D or 3D.

| Situation | Use | Why |
| --- | --- | --- |
| Background music | AudioStreamPlayer | No spatial position needed; route to Music bus |
| UI button click | AudioStreamPlayer | Should be the same volume everywhere |
| Enemy explosion (2D) | AudioStreamPlayer2D at explosion pos | Should pan and fade by distance from camera |
| Ambient fire crackle (2D) | AudioStreamPlayer2D on fire node | Looping, positional, fades as camera pans away |
| Any sound in a 3D game | AudioStreamPlayer3D | Full attenuation models, Doppler, air absorption |
| Narrator / announcer (3D game) | AudioStreamPlayer | Non-spatial — unaffected by player position |

## 6 · Sound Pooling & AudioStreamPolyphonic

:::callout-intuition[Intuition]
A bullet-hell game might fire hundreds of shots per second. Creating and freeing an AudioStreamPlayer2D for each bullet is expensive. A *sound pool* is a fixed set of nodes you recycle: grab an idle node, set its position, play it, return it to the pool when done. For the simpler case of many sounds from *one position*, Godot's built-in `AudioStreamPolyphonic` handles this without a manual pool.
:::

### Manual pool for spatialised effects

```gdscript
class_name SoundPool
extends Node

const POOL_SIZE: int = 16
var _pool: Array[AudioStreamPlayer2D] = []

func _ready() -> void:
    for i in POOL_SIZE:
        var p := AudioStreamPlayer2D.new()
        p.bus = "SFX"
        add_child(p)
        p.finished.connect(_return.bind(p))
        _pool.append(p)

func play_at(stream: AudioStream, pos: Vector2, vol: float = 0.0) -> void:
    if _pool.is_empty():
        return   # pool exhausted — skip rather than allocate
    var p: AudioStreamPlayer2D = _pool.pop_back()
    p.stream          = stream
    p.global_position = pos
    p.volume_db       = vol
    p.play()

func _return(p: AudioStreamPlayer2D) -> void:
    _pool.append(p)
```

### AudioStreamPolyphonic — built-in overlapping voices

```gdscript
@onready var player: AudioStreamPlayer = $HitPlayer
var _poly: AudioStreamPlaybackPolyphonic

func _ready() -> void:
    player.stream = AudioStreamPolyphonic.new()
    player.play()
    _poly = player.get_stream_playback() as AudioStreamPlaybackPolyphonic

func play_hit(sfx: AudioStream, vol: float = 0.0, pitch: float = 1.0) -> void:
    _poly.play_stream(sfx, pitch, vol)   # spawns a new voice instantly
```

### AudioManager Autoload — one node for all music

```gdscript
## AudioManager.gd — registered as Autoload named "AudioManager"
extends Node

@onready var music:  AudioStreamPlayer = $MusicPlayer
@onready var ui_sfx: AudioStreamPlayer = $UISFXPlayer

var _current_music: AudioStream = null

func play_music(stream: AudioStream, fade_in: float = 1.0) -> void:
    if stream == _current_music:
        return
    _current_music = stream
    music.stream    = stream
    music.volume_db = -80.0
    music.play()
    create_tween().tween_property(music, "volume_db", -6.0, fade_in)

func stop_music(fade_out: float = 1.0) -> void:
    var t := create_tween()
    t.tween_property(music, "volume_db", -80.0, fade_out)
    t.tween_callback(music.stop)
    _current_music = null

func play_ui(stream: AudioStream) -> void:
    ui_sfx.stream = stream
    ui_sfx.play()
```

## Practice Problems

:::problem{difficulty="easy"}
**A.** What is the difference between AudioStreamPlayer and AudioStreamPlayer2D? Give one use case for each.

::::solution[Solution]
**AudioStreamPlayer** plays at a fixed volume with no world position — heard equally everywhere. Use it for background music and UI sounds.

**AudioStreamPlayer2D** places sound in 2D world space — volume and panning change based on distance/direction from the listener. Use it for an enemy explosion that should fade as the player walks away.
::::
:::

:::problem{difficulty="easy"}
**B.** You connect to an AudioStreamPlayer's `finished` signal to trigger the next music track. The callback never fires. Why, and how do you fix it?

::::solution[Solution]
`finished` only fires when a **non-looping** stream ends. A looping stream never ends, so the signal never emits. Open the Import dock for the music file, set Loop Mode to *Disabled*, and reimport. Then handle looping yourself in the `finished` callback by calling `play()` again.
::::
:::

:::problem{difficulty="standard"}
**C.** Explain why positional sound effects must be imported as mono. What happens if you use a stereo file with AudioStreamPlayer2D?

::::solution[Solution]
AudioStreamPlayer2D computes stereo panning by distributing a *mono* signal between L and R speakers based on world position. A stereo file has two independent channels baked in — Godot cannot repan them. The result: the sound always appears dead-centre regardless of its position. Fix: enable **Force Mono** in the file's Import settings.
::::
:::

:::problem{difficulty="standard"}
**D.** Write a function `play_sound_at(stream, pos)` that plays a 2D sound at a world position without permanently adding a node to the scene — the node should free itself when done.

::::solution[Solution]
```gdscript
func play_sound_at(stream: AudioStream, pos: Vector2, vol_db: float = 0.0) -> void:
    var p := AudioStreamPlayer2D.new()
    p.stream          = stream
    p.volume_db       = vol_db
    p.global_position = pos
    p.bus             = "SFX"
    p.finished.connect(p.queue_free)
    get_tree().root.add_child(p)
    p.play()
```

Adding to `get_tree().root` rather than the current scene ensures the player survives scene transitions mid-play.
::::
:::

:::problem{difficulty="standard"}
**E.** What does `max_polyphony = 4` do? Write a short example showing the difference between the default and a raised value.

::::solution[Solution]
With `max_polyphony = 1` (default), calling `play()` on an already-playing node *restarts* it from frame 0. With `max_polyphony = 4`, each `play()` call spawns a new overlapping voice (up to 4), rather than restarting.

```gdscript
sfx.max_polyphony = 4   # collect up to 4 coins rapidly
func collect_coin() -> void:
    sfx.play()   # each collection overlaps naturally; no cut-off
```
::::
:::

:::problem{difficulty="challenge"}
**F.** Implement a crossfade function that fades from the currently playing music track to a new track over a given duration. Both tracks play simultaneously during the crossfade.

::::solution[Solution]
```gdscript
extends Node

@onready var track_a: AudioStreamPlayer = $TrackA
@onready var track_b: AudioStreamPlayer = $TrackB
var _active: AudioStreamPlayer

func _ready() -> void:
    track_a.bus = "Music"
    track_b.bus = "Music"
    _active = track_a

func crossfade_to(stream: AudioStream, duration: float = 2.0) -> void:
    var outgoing: AudioStreamPlayer = _active
    var incoming: AudioStreamPlayer = track_b if _active == track_a else track_a
    incoming.stream    = stream
    incoming.volume_db = -80.0
    incoming.play()
    var t := create_tween().set_parallel(true)
    t.tween_property(outgoing, "volume_db", -80.0, duration)
    t.tween_property(incoming, "volume_db", -6.0,  duration)
    await t.finished
    outgoing.stop()
    _active = incoming
```

`set_parallel(true)` makes both tweens run simultaneously. Without it, the fade-out completes before the fade-in begins.
::::
:::
