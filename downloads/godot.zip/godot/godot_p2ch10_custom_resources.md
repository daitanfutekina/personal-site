---
title: "Custom Resources & Data-Driven Design"
source: "godot_p2ch10_custom_resources.html"
---

Part II · GDScript Deep Dive

# Custom Resources & Data-Driven Design

Part II Chapter 10 · Prerequisites: Ch 6 (Resources), Ch 9 (class\_name & OOP) · est. 75 min

## Overview

A **Custom Resource** is a GDScript class that extends `Resource` — Godot's serializable data container. Where scene nodes hold behaviour and visual state, Custom Resources hold *pure data*: item stats, enemy configurations, dialogue lines, level parameters. Separating data from behaviour is the heart of **data-driven design**.

By the end of this chapter you'll be able to define rich, editor-editable data types, link them to scene nodes via `@export`, build a simple item database, and save/load Resources to disk at runtime.

:::callout-tip[The ScriptableObject analogy]
If you've used Unity, Custom Resources are Godot's equivalent of `ScriptableObject`. They live as `.tres` files in your project, are serialized automatically, and can be edited directly in the Inspector.
:::

## 1 · Resource Basics

:::callout-intuition[Intuition]
Everything you drag into a node property in the Inspector — textures, audio streams, mesh files, PackedScenes — is a **Resource**. Godot's built-in `Resource` class provides automatic serialization to `.tres` (text) or `.res` (binary), reference counting, and editor integration. When you extend it with your own script, you get all of that for free.
:::

### The Resource Class

`Resource` extends `RefCounted`, which means it is automatically garbage collected when no references to it remain — you never call `queue_free()` on a Resource. Key built-in properties and methods:

| Member | Type | Description |
| --- | --- | --- |
| `resource_path` | String | The `res://` path where it's saved (empty if not saved) |
| `resource_name` | String | Optional human-readable name shown in the Inspector |
| `resource_local_to_scene` | bool | If true, every scene instance gets its own copy (see Section 5) |
| `duplicate(deep)` | Resource | Shallow or deep copy of the resource |
| `emit_changed()` | void | Emits the built-in `changed` signal |
| `changed` | signal | Fired when any exported property changes (editor or code) |
| `setup_local_to_scene()` | void | Override in your class to run logic when a local copy is created |

### Creating Resource Instances

```gdscript
# From code: create a plain Resource
var r := Resource.new()
r.resource_name = "My Resource"

# Load from disk (returns the shared cached instance)
var texture := load("res://sprites/player.png") as Texture2D

# Force a fresh load (bypasses cache)
var fresh := ResourceLoader.load("res://data/item.tres", "", ResourceLoader.CACHE_MODE_IGNORE)

# Instantiate a custom resource (see Section 2)
var item := ItemData.new()
```

## 2 · Custom Resource Scripts

### Defining a Custom Resource

Create a new GDScript file, set its base class to `Resource` via `extends`, and give it a `class_name`. That's all it takes. Save the file and Godot registers it as an editor-creatable resource type.

```gdscript
# item_data.gd
class_name ItemData extends Resource

## The display name shown in-game.
@export var item_name: String = "Unknown Item"

## Icon displayed in inventory UI.
@export var icon: Texture2D

## Damage dealt by weapons; healing amount for consumables.
@export var power: int = 0

## Weight affects inventory capacity.
@export var weight: float = 1.0

## Whether the item is consumed on use.
@export var is_consumable: bool = false

## Item categories for filtering.
@export_enum("Weapon", "Armor", "Consumable", "Quest") var category: int = 0

## Rarity tier (0=common, 1=uncommon, 2=rare, 3=legendary).
@export_range(0, 3) var rarity: int = 0

## Stacking limit (0 means non-stackable).
@export var max_stack: int = 1
```

Once saved, right-click the FileSystem dock and choose **New Resource…** — your `ItemData` type appears in the list. Fill in values in the Inspector and save as a `.tres` file.

:::callout-tip[@export\_group and @export\_subgroup]
For Resources with many properties, group related fields visually in the Inspector:

```gdscript
@export_group("Combat Stats")
@export var damage: int = 10
@export var range: float = 5.0
@export_group("Visual")
@export var icon: Texture2D
@export var color_tint: Color = Color.WHITE
```
:::

### Commonly Used @export Annotations on Resources

| Annotation | Inspector Widget | Example |
| --- | --- | --- |
| `@export` | Auto from type | `@export var name: String` |
| `@export_range(min,max)` | Slider | `@export_range(0,100) var hp: int` |
| `@export_enum("A","B")` | Dropdown | `@export_enum("Fire","Ice","Earth") var element: int` |
| `@export_flags("A","B")` | Checkboxes (bitmask) | `@export_flags("Fly","Swim","Dig") var movement: int` |
| `@export_multiline` | Multi-line TextEdit | `@export_multiline var description: String` |
| `@export_file("*.json")` | File picker | Path to an external file |
| `@export var sub: AnotherResource` | Resource picker / inline | Nested resource (see Section 3) |

### Adding Methods to Resources

Resources can have full GDScript methods — they're just classes. This is where data-driven design becomes powerful: the data *knows how to interpret itself*.

```gdscript
# item_data.gd (continued)

func get_rarity_name() -> String:
    match rarity:
        0: return "Common"
        1: return "Uncommon"
        2: return "Rare"
        3: return "Legendary"
        _: return "Unknown"

func get_rarity_color() -> Color:
    match rarity:
        0: return Color.WHITE
        1: return Color(0.12, 0.85, 0.12)  # green
        2: return Color(0.0, 0.44, 0.87)   # blue
        3: return Color(0.63, 0.13, 0.94)  # purple
        _: return Color.GRAY

func is_weapon() -> bool:
    return category == 0

func can_stack() -> bool:
    return max_stack > 1
```

## 3 · Data-Driven Design

:::callout-intuition[Intuition]
Data-driven design means: instead of hard-coding game values in scripts (`var goblin_hp = 40`), you store those values in resource files, and scripts just read from them. A designer can then tweak goblin HP in the editor without touching a single line of code. The script becomes a "behaviour template" and the resource becomes the "configuration."
:::

### The Resource Database Pattern

Create an `ItemDatabase` Resource that holds an array of `ItemData` resources. Expose it as an Autoload or drag it into any node that needs it.

```gdscript
# item_database.gd
class_name ItemDatabase extends Resource

@export var items: Array[ItemData] = []

## Look up an item by its name. Returns null if not found.
func find_by_name(search: String) -> ItemData:
    for item: ItemData in items:
        if item.item_name == search:
            return item
    return null

## Returns all items of a given category (0=Weapon, etc.)
func get_by_category(cat: int) -> Array[ItemData]:
    return items.filter(func(i: ItemData) -> bool: return i.category == cat)

## Returns items sorted by rarity (highest first)
func get_sorted_by_rarity() -> Array[ItemData]:
    var sorted := items.duplicate()
    sorted.sort_custom(func(a: ItemData, b: ItemData) -> bool:
        return a.rarity > b.rarity)
    return sorted
```

### Complete Item System Example

Here's how the pieces connect in a real scene:

```gdscript
# inventory_ui.gd
extends Control

## Drag your item_database.tres here in the Inspector
@export var database: ItemDatabase

func _ready() -> void:
    # Display all weapons sorted by rarity
    var weapons := database.get_by_category(0)
    weapons.sort_custom(func(a, b): return a.rarity > b.rarity)
    for item: ItemData in weapons:
        _create_item_slot(item)

func _create_item_slot(item: ItemData) -> void:
    var slot := ItemSlot.instantiate()  # some PackedScene
    slot.label.text = item.item_name
    slot.icon_texture.texture = item.icon
    slot.label.modulate = item.get_rarity_color()
    add_child(slot)
```

### Nested Resources

Resources can contain other Resources. This lets you model complex hierarchies without any node trees:

```gdscript
# enemy_data.gd
class_name EnemyData extends Resource

@export var display_name: String = "Enemy"
@export var max_health: int = 100
@export var speed: float = 3.0

## Drop table — each entry is a separate Resource
@export var drops: Array[DropEntry] = []

## The visual and audio configuration (another Resource)
@export var appearance: EnemyAppearance

# drop_entry.gd
class_name DropEntry extends Resource

@export var item: ItemData
@export_range(0.0, 1.0) var drop_chance: float = 0.1
@export var min_quantity: int = 1
@export var max_quantity: int = 1

func roll() -> int:
    if randf() > drop_chance:
        return 0
    return randi_range(min_quantity, max_quantity)
```

## 4 · Saving & Loading Resources at Runtime

:::callout-intuition[Intuition]
Resources saved during development are part of the project's assets. But you can also save resources *at runtime* — for example saving a player's progress or a procedurally generated world. The `ResourceSaver` and `ResourceLoader` singletons handle this.
:::

### ResourceSaver

`ResourceSaver` is a built-in singleton (not an Autoload — it's a global engine class). Use it to write Resources to disk.

| Method | Returns | Description |
| --- | --- | --- |
| `save(resource, path, flags)` | Error | Save resource to the given path. Path must be `user://` or `res://` |
| `get_recognized_extensions(resource)` | PackedStringArray | Extensions the saver can write for this type |

```gdscript
## Save a game-state resource to the user's save directory
func save_game(state: GameState) -> void:
    var err := ResourceSaver.save(state, "user://save_slot_1.tres")
    if err != OK:
        push_error("Failed to save game: %s" % error_string(err))
    else:
        print("Game saved!")

## Save with binary format (faster, smaller, not human-readable)
ResourceSaver.save(state, "user://save.res", ResourceSaver.FLAG_COMPRESS)
```

### ResourceLoader

`ResourceLoader` loads Resources from disk. It caches resources so that two `load()` calls with the same path return the same shared instance.

| Method / Property | Returns | Description |
| --- | --- | --- |
| `load(path, type_hint, cache_mode)` | Resource | Blocking load. Returns null on failure. |
| `load_threaded_request(path)` | Error | Begin async load in background thread |
| `load_threaded_get_status(path)` | ThreadLoadStatus | Check if async load is done |
| `load_threaded_get(path)` | Resource | Retrieve the loaded resource (call after status = LOADED) |
| `exists(path, type_hint)` | bool | True if a resource exists at the path |
| `CACHE_MODE_IGNORE` | const | Always reload from disk, skip cache |

```gdscript
## Load a save file if it exists
func load_game() -> GameState:
    const SAVE_PATH := "user://save_slot_1.tres"
    if not ResourceLoader.exists(SAVE_PATH):
        return GameState.new()   # fresh state if no save
    var state := ResourceLoader.load(SAVE_PATH) as GameState
    if state == null:
        push_error("Save file corrupted, starting fresh")
        return GameState.new()
    return state

## Load a fresh (uncached) copy — important when you need separate instances
var fresh_item := ResourceLoader.load(
    "res://data/sword.tres", "", ResourceLoader.CACHE_MODE_IGNORE) as ItemData
```

## 5 · Shared vs. Unique Resource Instances

:::callout-pitfall[The shared-instance trap]
This is the most common Custom Resource bug. When you drag an `ItemData.tres` into two different enemy nodes in the Inspector, **both nodes share the same resource object in memory**. If Enemy A modifies `item_data.power` at runtime, Enemy B immediately sees the changed value. This is almost never what you want.
:::

```gdscript
# WRONG — both enemies share the same ItemData
@export var item: ItemData

func _ready() -> void:
    item.power = 999   # ALSO modifies every other node using this resource!

# RIGHT — duplicate the resource on ready to get a private copy
@export var item_template: ItemData

var item: ItemData   # our own instance

func _ready() -> void:
    item = item_template.duplicate()   # shallow copy
    # or: item = item_template.duplicate(true)  # deep copy (duplicates nested resources too)
    item.power = 999   # only affects this node's copy
```

### `resource_local_to_scene`

For Resources that should automatically have per-scene-instance copies, set `resource_local_to_scene = true` on the Resource. Godot will automatically duplicate the resource for each scene instance that contains it — no manual `duplicate()` needed.

```gdscript
# health_resource.gd
class_name HealthResource extends Resource

@export var max_health: int = 100
var current_health: int

func _setup_local_to_scene() -> void:
    # This is called automatically for each scene instance
    current_health = max_health

func take_damage(amount: int) -> void:
    current_health -= amount
```

In the Inspector, check **Resource → Local To Scene** on any resource you want to auto-duplicate.

:::callout-tip[When to share, when to duplicate]
- **Share** read-only definition data (item stats, enemy configs) — they don't change at runtime
- **Duplicate** instance-state data (current health, inventory contents) — each entity needs its own
:::

:::summary
## Chapter Summary

| Concept | Key point |
| --- | --- |
| Custom Resource | Any script with `extends Resource` + `class_name` becomes an editor-creatable data type |
| @export on Resources | Properties appear in the Inspector and are serialized to `.tres` automatically |
| Methods on Resources | Full GDScript — data can contain its own query and computation logic |
| Nested Resources | `@export var sub: AnotherResource` — models rich hierarchies without nodes |
| ResourceSaver.save() | Writes a Resource to `user://` or `res://`; returns an Error code |
| ResourceLoader.load() | Blocking load; returns cached shared instance |
| CACHE\_MODE\_IGNORE | Bypass cache to get a fresh independent copy |
| Shared instance trap | All nodes using the same .tres share one object; call `duplicate()` for per-instance state |
| resource\_local\_to\_scene | Auto-duplicates for every scene instance; override `setup_local_to_scene()` to initialize |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
Write a `class_name AbilityData extends Resource` with: `ability_name: String`, `cooldown: float`, `mana_cost: int`, and `icon: Texture2D`.

::::solution[Solution]
```gdscript
class_name AbilityData extends Resource

@export var ability_name: String = "Unnamed Ability"
@export var cooldown: float = 1.0
@export var mana_cost: int = 0
@export var icon: Texture2D
```
::::
:::

:::problem[2 easy]{difficulty="easy"}
You load an `EnemyData` resource from disk and assign it to two different enemy nodes. One enemy takes damage that reduces `data.health` directly. Will the other enemy's data also change? How do you prevent this?

::::solution[Solution]
Yes — both nodes reference the same resource instance in memory. To prevent this, call `data = data.duplicate()` in each node's `_ready()`. For deeply nested resources, use `data.duplicate(true)`.
::::
:::

:::problem[3 standard]{difficulty="standard"}
Add a method `can_afford(player_gold: int) -> bool` and `get_sale_price() -> int` (50% of base value) to an `ItemData` resource that has a `base_price: int` property.

::::solution[Solution]
```gdscript
@export var base_price: int = 0

func can_afford(player_gold: int) -> bool:
    return player_gold >= base_price

func get_sale_price() -> int:
    return base_price / 2
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
Write the code to save a `PlayerSave` resource to `user://save.tres` and a load function that returns a fresh `PlayerSave.new()` if the file doesn't exist.

::::solution[Solution]
```gdscript
func save_player(state: PlayerSave) -> void:
    ResourceSaver.save(state, "user://save.tres")

func load_player() -> PlayerSave:
    if not ResourceLoader.exists("user://save.tres"):
        return PlayerSave.new()
    return ResourceLoader.load("user://save.tres") as PlayerSave
```
::::
:::

:::problem[5 challenge]{difficulty="challenge"}
Design a `SpellBook` Resource that contains an `Array[AbilityData]`. Add methods: `get_affordable(mana: int) -> Array[AbilityData]` (returns abilities the player can cast given current mana) and `get_coolest() -> AbilityData` (returns the ability with the longest cooldown, or null if empty).

::::solution[Solution]
```gdscript
class_name SpellBook extends Resource

@export var abilities: Array[AbilityData] = []

func get_affordable(mana: int) -> Array[AbilityData]:
    return abilities.filter(func(a: AbilityData) -> bool:
        return a.mana_cost <= mana)

func get_coolest() -> AbilityData:
    if abilities.is_empty():
        return null
    var best: AbilityData = abilities[0]
    for a: AbilityData in abilities:
        if a.cooldown > best.cooldown:
            best = a
    return best
```
::::
:::
