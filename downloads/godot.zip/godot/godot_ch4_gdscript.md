---
title: "GDScript Crash Course — Syntax, Types & the Lifecycle Functions"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 4"
meta:
  - "Est. study time: ~110 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch4_gdscript.html"
---

## Overview

GDScript is Godot's built-in scripting language. It looks like Python but was
 designed from the ground up to be fast to write, deeply integrated with the engine's
 type system, and compiled to bytecode at runtime. This chapter covers everything you
 need to write real game code: variables, types, control flow, functions, classes, the
 most important built-in types, and GDScript's unique annotations.

If you already know Python, most of this will feel familiar. Pay special attention to
 Sections 1 (static typing — very different from Python), 5 (Godot's vector math
 types), and 6 (annotations like `@export` and `@onready`).

:::callout-key[Prerequisites]
- Chapters 1–3: you can create a project, add nodes, and attach scripts.
- General programming knowledge (variables, loops, functions) in any language.
:::

## 1. Variables & Static Typing

:::callout-intuition[GDScript can be dynamic or statically typed — you choose]
Like Python, GDScript lets you write `var x = 5` without declaring a
 type. Unlike Python, you can add `: int` to lock the variable to a
 specific type. Static typing is optional but strongly recommended: it catches bugs
 at edit time, enables autocomplete, and makes your code faster.
:::

### Type annotations

```gdscript
# Dynamic — type inferred, can change at runtime (avoid in production code)
var score = 0
var name = "Player"

# Static — type fixed at declaration (recommended)
var score: int = 0
var name: String = "Player"
var speed: float = 200.0
var is_alive: bool = true
var position: Vector2 = Vector2.ZERO

# Type-inferred static typing — the := operator
# Godot infers the type from the right-hand side and locks it
var speed := 200.0          # inferred as float
var player := $Player       # inferred as Node (use explicit type for clarity)
var player: CharacterBody2D = $Player  # explicit — better
```

The full list of GDScript's primitive types:

| Type | Literal examples | Notes |
| --- | --- | --- |
| `bool` | `true`, `false` | Boolean. Only these two values — not 0/1. |
| `int` | `0`, `-5`, `0xFF`, `0b1010` | 64-bit signed integer. Hex and binary literals supported. |
| `float` | `3.14`, `1.0`, `2e5` | 64-bit double. Always use `1.0` not `1` for float math. |
| `String` | `"hello"`, `'world'` | UTF-8. Supports `%` formatting and `+` concatenation. |
| `StringName` | `&"input_action"` | Interned string — fast equality checks. Used for node names, group names, signal names. |
| `NodePath` | `^"Sprite2D"` | A pre-parsed node path. More efficient than a String path passed to get\_node(). |
| `Variant` | any value | Dynamic type — holds any value. Avoid in typed code. |

GDScript's type system: everything is a `Variant` at runtime. Adding a type annotation locks the variable to one branch — the engine then optimises storage and catches mismatches at edit time.

Variant (dynamic)

bool / int / float

String / StringName

Vector2 / 3 / 4

Rect2 / Transform2D / 3D

Object

(Node, Resource, …)

Array / Dictionary

NodePath / RID

Primitive / scalar type

Math / geometry type

Reference type (heap-allocated)

Container type (reference)

### Constants and enums

```gdscript
# Constants — value fixed at compile time, all-caps by convention
const MAX_HEALTH: int = 100
const GRAVITY: float = 980.0
const PLAYER_SCENE: PackedScene = preload("res://scenes/player.tscn")

# Enums — named integer constants grouped together
enum State { IDLE, RUNNING, JUMPING, DEAD }
enum Direction { LEFT = -1, RIGHT = 1 }  # explicit values

var current_state: State = State.IDLE

func update_state(new_state: State) -> void:
    current_state = new_state
    match current_state:
        State.IDLE:    $AnimationPlayer.play("idle")
        State.RUNNING: $AnimationPlayer.play("run")
        State.JUMPING: $AnimationPlayer.play("jump")
        State.DEAD:    $AnimationPlayer.play("death")
```

:::callout-tip[Enums are the right tool for state machines]
Using `enum State { IDLE, RUNNING, JUMPING }` instead of
 string constants like `"idle"` gives you autocomplete, typo-proof
 comparisons, and a readable `match` statement. Chapter 55 covers
 full state machines; start using enums now.
:::

:::callout-pitfall[Watch out for]
- **Integer division truncates.** `5 / 2` is `2`, not `2.5`. Write `5.0 / 2.0` or `float(5) / 2` to get `2.5`.
- **Untyped vars default to `null`.** `var x: int` without an initializer is `0`. `var node: Node` without an initializer is `null` — accessing it before assignment crashes.
- **Floats are imprecise.** `0.1 + 0.2 != 0.3` is true in GDScript just like every other language using IEEE 754. Use `is_equal_approx(a, b)` for float comparisons instead of `==`.
:::

## 2. Control Flow

### if / elif / else and match

```gdscript
# Standard if / elif / else — identical to Python
var health: int = 75

if health <= 0:
    die()
elif health < 25:
    play_low_health_sound()
elif health < 50:
    show_warning_indicator()
else:
    # full health, do nothing special
    pass

# Inline ternary — condition_met if condition else other_value
var label_text: String = "Dead" if health <= 0 else "Alive"
```

```gdscript
# match — GDScript's switch statement
# Matches by value, not fall-through (no break needed)
match current_state:
    State.IDLE:
        velocity = Vector2.ZERO
    State.RUNNING:
        velocity.x = direction * speed
    State.JUMPING:
        velocity.y = -jump_force
    _:                    # _ is the default / catch-all case
        push_warning("Unhandled state: %s" % current_state)
```

`match` also works on types, strings, arrays, and ranges:

```gdscript
match typeof(value):
    TYPE_INT:   print("integer")
    TYPE_STRING: print("string")
    TYPE_ARRAY:  print("array")

# Range pattern
match score:
    0:          print("zero")
    1, 2, 3:    print("low")     # comma = OR
    4 .. 9:     print("medium")  # range (inclusive both ends in match)
    _:          print("high")
```

### for and while

```gdscript
# for — iterate over a range
for i in range(5):          # 0, 1, 2, 3, 4
    print(i)

for i in range(2, 10, 2):   # 2, 4, 6, 8  (start, stop, step)
    print(i)

# for — iterate over array
var enemies: Array[Node] = get_tree().get_nodes_in_group("enemies")
for enemy in enemies:
    enemy.take_damage(5)

# for — iterate over dictionary
var stats: Dictionary = {"hp": 100, "mp": 50, "atk": 30}
for key in stats:
    print("%s = %d" % [key, stats[key]])

# while — runs until condition is false
var count: int = 10
while count > 0:
    print(count)
    count -= 1

# break and continue work as in every other language
for i in range(100):
    if i == 7:
        continue    # skip 7
    if i == 15:
        break       # stop at 15
    print(i)
```

:::callout-warning[Never modify an array while iterating it]
Removing or adding elements to an array inside a `for` loop over
 that array causes undefined behavior (skipped elements or index errors). If you
 need to remove items, collect them in a separate list first, then remove after
 the loop:

```gdscript
var to_remove: Array = []
for enemy in enemies:
    if enemy.health <= 0:
        to_remove.append(enemy)
for e in to_remove:
    e.queue_free()
```
:::

## 3. Functions

```gdscript
# Basic function with typed parameters and return type
func add(a: int, b: int) -> int:
    return a + b

# void return (no return value)
func reset_health() -> void:
    health = MAX_HEALTH

# Function with no type annotations (dynamic — avoid in new code)
func old_style(x, y):
    return x + y
```

### Default arguments and return types

```gdscript
# Default argument values — trailing arguments only
func spawn_enemy(pos: Vector2, type: String = "grunt", level: int = 1) -> Node:
    var scene: PackedScene = enemy_scenes[type]
    var e: Node = scene.instantiate()
    add_child(e)
    e.position = pos
    e.initialize(level)
    return e

# Calling with defaults:
spawn_enemy(Vector2(200, 300))              # type="grunt", level=1
spawn_enemy(Vector2(400, 100), "boss")     # level=1
spawn_enemy(Vector2(100, 200), "archer", 3)  # all explicit
```

### Lambdas and Callables

GDScript supports anonymous functions (lambdas) via the `func` keyword
 inline. They're stored as `Callable` values and are most useful for
 signal connections and sorting.

```gdscript
# Lambda stored in a variable
var double: Callable = func(x: int) -> int: return x * 2
print(double.call(5))   # 10

# Lambda passed directly to connect() — no need for a separate method
$Button.pressed.connect(func(): print("Button was pressed!"))

# Lambda for sorting — sort enemies by distance to player
var player_pos: Vector2 = $Player.global_position
enemies.sort_custom(func(a: Node2D, b: Node2D) -> bool:
    return a.global_position.distance_to(player_pos) <
           b.global_position.distance_to(player_pos)
)
```

:::callout-tip[Callable.bind() — pre-fill arguments]
`Callable.bind()` creates a new Callable with arguments pre-filled.
 Useful when connecting a signal that passes no arguments to a function that needs
 some context:

```gdscript
# Signal "timeout" passes no args, but we need to know which enemy to activate
$Timer.timeout.connect(_activate_enemy.bind(enemy_node))

func _activate_enemy(enemy: Node) -> void:
    enemy.activate()
```
:::

## 4. Classes & Inheritance

:::callout-intuition[Every script is a class]
In GDScript, each `.gd` file is implicitly a class. The
 `extends` line at the top declares which built-in (or custom) class it
 inherits from. You rarely define standalone classes in GDScript the way you might
 in C++ — the node hierarchy handles most inheritance needs. But knowing the
 rules is essential when you do need them.
:::

### class\_name and extends

```gdscript
# extends — which class this script inherits from
# Must match the node type this script is attached to
extends CharacterBody2D

# class_name — registers this script as a global type
# Other scripts can now reference it as "Player" without preloading
class_name Player

# Once registered, you can use it as a type annotation anywhere:
# var p: Player = $Player
# func hit(target: Player) -> void: ...

# Calling the parent class's version of an overridden method:
func _ready() -> void:
    super()           # calls CharacterBody2D._ready() (usually a no-op for built-ins)
    setup_player()

func take_damage(amount: int) -> void:
    health -= amount
    if health <= 0:
        die()

# Overriding with super() to extend parent behavior:
# (useful when subclassing your own classes)
class_name Boss extends Enemy   # Boss inherits from your custom Enemy class

func take_damage(amount: int) -> void:
    var reduced: int = amount / 2    # bosses take half damage
    super(reduced)                   # call Enemy.take_damage(reduced)
```

### Inner classes

GDScript supports defining classes inside a script file. This is useful for
 small data structures you don't want to put in their own file:

```gdscript
extends Node

# Inner class — a lightweight data container
class InventoryItem:
    var id: StringName
    var count: int
    var display_name: String

    func _init(p_id: StringName, p_count: int, p_name: String) -> void:
        id = p_id
        count = p_count
        display_name = p_name

var inventory: Array[InventoryItem] = []

func add_item(id: StringName, name: String) -> void:
    var item := InventoryItem.new(id, 1, name)
    inventory.append(item)

func _ready() -> void:
    add_item(&"sword", "Iron Sword")
    print(inventory[0].display_name)  # "Iron Sword"
```

## 5. Built-in Types

Godot adds a rich set of math and game-specific types on top of GDScript's
 primitives. These are value types (copied on assignment, not referenced) and
 are deeply integrated with the engine's physics, rendering, and animation systems.

### Vector2 and Vector3

`Vector2` is the type you'll use most in 2D development —
 positions, velocities, directions, sizes. Every 2D node's
 `position`, `scale`, and `velocity` are
 `Vector2` values.

```gdscript
# Construction
var pos: Vector2 = Vector2(100.0, 200.0)
var zero: Vector2 = Vector2.ZERO    # (0, 0)
var one:  Vector2 = Vector2.ONE     # (1, 1)
var up:   Vector2 = Vector2.UP      # (0, -1)  NOTE: Y is down in 2D!
var right:Vector2 = Vector2.RIGHT   # (1, 0)

# Component access
print(pos.x, pos.y)     # 100.0  200.0

# Arithmetic — all operations work component-wise
var vel: Vector2 = Vector2(3.0, 4.0)
var double_vel: Vector2 = vel * 2.0      # (6, 8)
var sum: Vector2 = pos + vel             # (103, 204)

# Essential methods
var length: float = vel.length()         # 5.0  (Pythagoras: sqrt(3²+4²))
var unit: Vector2 = vel.normalized()     # (0.6, 0.8)  — length 1
var dist: float = pos.distance_to(Vector2(200, 300))
var lerped: Vector2 = pos.lerp(Vector2(500, 500), 0.1)  # 10% toward target
var dot: float = vel.dot(Vector2.RIGHT)  # projection onto right axis

# Rotating a vector
var rotated: Vector2 = vel.rotated(PI / 4)   # rotate 45 degrees

# Angle
var angle: float = vel.angle()   # angle in radians from positive X axis
```

**The Y-axis is inverted in 2D.** In Godot's 2D coordinate system,
 positive Y points *downward* (screen coordinates). So
 `Vector2.UP` is `(0, -1)` and moving a node upward means
 subtracting from its Y position. This trips up everyone coming from math class.

`Vector3` is the same idea for 3D — three components X, Y, Z. In 3D,
 Y is up by default. See Chapter 24 for the 3D coordinate system in depth.

#### Other essential math types

| Type | What it is | Common uses |
| --- | --- | --- |
| `Vector2i` | Integer version of Vector2 | Tile coordinates, pixel-perfect positions, grid indices. |
| `Rect2` | A 2D rectangle: `position` + `size` | Bounding boxes, viewport rect, UI layout. `Rect2.has_point(v)` for hit testing. |
| `Transform2D` | A 2D affine transform: position, rotation, scale | Accessed via `node.transform`. Use for full transform math. |
| `Color` | RGBA float (0.0–1.0 each channel) | `Color(1,0,0,1)` = red. `Color.WHITE`, `Color.TRANSPARENT`. Modulate sprites: `$Sprite.modulate = Color(1,1,1,0.5)` |
| `Basis` / `Transform3D` | 3D rotation and transform | Used in 3D (Ch 24). Analogous to Transform2D but in 3D space. |

### Array and Dictionary

```gdscript
# Array — ordered, resizable, typed or untyped
var scores: Array[int] = [10, 20, 30, 40]
var mixed: Array = ["hello", 42, true]      # untyped (avoid)

# Common Array operations
scores.append(50)                 # add to end
scores.insert(0, 5)               # insert at index 0
scores.remove_at(2)               # remove by index
scores.erase(20)                  # remove first occurrence of value 20
var top: int = scores.pop_back()  # remove and return last element
var found: int = scores.find(30)  # index of first 30, or -1
var has: bool = scores.has(10)    # true
var size: int = scores.size()     # count
scores.sort()                     # in-place ascending sort
scores.reverse()                  # in-place reverse
var slice: Array[int] = scores.slice(1, 3)  # indices 1 and 2

# Typed arrays are faster and catch errors earlier
var nodes: Array[Node2D] = []
nodes.append($Sprite2D)          # type checked at runtime
```

```gdscript
# Dictionary — key-value pairs, keys can be any type
var stats: Dictionary = {
    "health": 100,
    "mana": 50,
    "attack": 25,
}

# Access — bracket notation
var hp: int = stats["health"]

# Access — get() with a default (safe, no crash if key missing)
var defense: int = stats.get("defense", 0)  # returns 0 if missing

# Modification
stats["health"] = 80
stats["defense"] = 10   # adds new key

# Iteration
for key in stats:
    print("%s: %d" % [key, stats[key]])

# Membership check
if "health" in stats:
    print("has health key")

# Useful methods
stats.erase("mana")           # remove a key
var keys: Array = stats.keys()
var values: Array = stats.values()
var size: int = stats.size()
```

### String and StringName

```gdscript
# String — mutable, UTF-8, general purpose
var greeting: String = "Hello, %s! You have %d coins." % ["Alice", 42]
var upper: String = greeting.to_upper()
var lower: String = greeting.to_lower()
var has_word: bool = greeting.contains("Hello")
var parts: Array = "one,two,three".split(",")   # ["one", "two", "three"]
var joined: String = ",".join(["a", "b", "c"])  # "a,b,c"
var trimmed: String = "  hello  ".strip_edges() # "hello"
var length: int = greeting.length()

# Multi-line strings
var dialogue: String = """
The knight says:
    'I shall not yield!'
"""

# String formatting options
var pos_str: String = "Position: (%d, %d)" % [int(position.x), int(position.y)]
var float_str: String = "Speed: %.2f" % speed   # 2 decimal places

# StringName — interned string, faster equality checks
# Use for: signal names, group names, animation names, input actions
var anim_name: StringName = &"run"      # & prefix creates a StringName literal
$AnimationPlayer.play(anim_name)

# In practice you'll often just pass a String — Godot auto-converts where needed
$AnimationPlayer.play("run")            # also fine
```

:::callout-tip[String interpolation with str()]
For quick debugging, `str()` converts anything to a String and
 `print()` accepts multiple arguments separated by commas — no
 formatting needed:

```gdscript
print("pos:", position, " vel:", velocity, " hp:", health)
```

This is faster to write than `%` formatting and good enough for
 debug output.
:::

## 6. Key Annotations

Annotations are `@keyword` decorators that modify how a variable or
 function is treated by the engine. You've already used `@onready`;
 here are the rest of the important ones.

### @onready — the cached node reference pattern

:::callout-intuition[Why @onready exists]
When GDScript executes class-level variable assignments (the lines at the top of
 the script outside any function), the node's children haven't been added to the
 scene tree yet. That means `var sprite := $Sprite2D` at the top of
 the file will crash — `$Sprite2D` returns `null` because
 the tree isn't ready. `@onready` delays the assignment until
 `_ready()` fires, by which point the whole subtree is live.
:::

```gdscript
extends CharacterBody2D

# WITHOUT @onready — CRASHES at class load time
# var sprite: Sprite2D = $Sprite2D   # ← $Sprite2D is null here

# WITH @onready — assignment deferred until _ready()
@onready var sprite: Sprite2D = $Sprite2D
@onready var anim: AnimationPlayer = $AnimationPlayer
@onready var hitbox: CollisionShape2D = $Hitbox
@onready var health_bar: ProgressBar = $CanvasLayer/HUD/HealthBar

const MAX_HEALTH := 100
var health := MAX_HEALTH

func _ready() -> void:
    # By the time _ready() runs, all @onready vars are assigned
    health_bar.max_value = MAX_HEALTH
    health_bar.value = health
    anim.play("idle")

func take_damage(amount: int) -> void:
    health = clampi(health - amount, 0, MAX_HEALTH)
    health_bar.value = health          # safe — already set in _ready()
    if health == 0:
        anim.play("death")
```

:::callout-tip[@onready is the correct way to cache child nodes]
Always cache frequently-accessed child nodes with `@onready` at the
 top of the script rather than calling `$NodeName` every frame inside
 `_process()`. The `$` shorthand calls
 `get_node()` which traverses the tree — doing it once in
 `_ready()` and storing the result is both faster and easier to read.
:::

Class loaded

const / var

evaluated

Children added

subtree enters

scene tree

\_ready() called

@onready vars

assigned here ✓

\_process(delta)

game loop

begins

@onready triggers

Node lifecycle: `@onready` variables are assigned at the very start of `_ready()` — after the whole subtree is ready but before your own `_ready()` body runs.

:::callout-pitfall[Watch out for]
- **Using `@onready` on a node path that doesn't exist.**
 If the child was renamed or removed, the assignment produces `null`
 silently. Add a `assert(sprite != null, "@onready: $Sprite2D not found")`
 at the top of `_ready()` to catch missing nodes early.
- **Accessing an `@onready` var before `_ready()`.**
 If another script calls a function on this node before it enters the tree
 (e.g., passing parameters to a just-instantiated scene), the
 `@onready` vars will still be `null`.
 Use `set_deferred` or wait for `ready` signal instead.
:::

### @export and its variants

`@export` exposes a variable in the Inspector so it can be edited
 without touching code. It also saves the value in the `.tscn` file.

```gdscript
extends CharacterBody2D

# Basic export — shows a numeric field in the Inspector
@export var speed: float = 200.0
@export var max_health: int = 100

# Export with range slider — min, max, and optional step
@export_range(0.0, 1000.0, 10.0) var move_speed: float = 300.0

# Export categories — organizes the Inspector into sections
@export_group("Combat")
@export var attack_damage: int = 10
@export var attack_cooldown: float = 0.5

@export_group("Movement")
@export var jump_height: float = 400.0
@export var acceleration: float = 800.0

# Export a node reference (drag-and-drop in Inspector)
@export var target: NodePath
@export var spawn_point: Node2D    # direct node type

# Export a resource type
@export var weapon_data: Resource
@export var level_music: AudioStream

# Export an array of values
@export var damage_per_level: Array[int] = [10, 15, 20, 30]

# Export an enum (shows as dropdown in Inspector)
enum Difficulty { EASY, NORMAL, HARD }
@export var difficulty: Difficulty = Difficulty.NORMAL
```

Inspector

▶ Combat

Attack Damage — 10

Attack Cooldown — 0.5

▶ Movement

Jump Height — 400.0

Difficulty — Normal ▾

Every `@export` variable appears in the Inspector. `@export_group` folds them into collapsible sections — essential for scripts with many tweakable properties.

### @tool, @static\_unload, and @warning\_ignore

```gdscript
# @tool — runs the script in the EDITOR, not just at runtime
# Used for custom editor plugins, procedural level generation,
# or visualizing data in the viewport while designing
@tool
extends Node2D

func _process(delta: float) -> void:
    # This runs even when you're in the editor
    if Engine.is_editor_hint():
        queue_redraw()   # trigger _draw() in editor

func _draw() -> void:
    # Draw a debug circle in the editor viewport
    draw_circle(Vector2.ZERO, 32.0, Color.CYAN)
```

```gdscript
# @warning_ignore — suppress a specific editor warning on the next line
# Use sparingly — warnings usually indicate real problems
@warning_ignore("return_value_discarded")
some_function_that_returns_a_value()

# @static_unload — releases static variable memory when no instances exist
# Advanced: only needed for scripts with large @static data
@static_unload
extends RefCounted
static var cache: Dictionary = {}
```

:::callout-pitfall[Watch out for]
- **`@tool` scripts run in the editor.** Any code in `_ready()` or `_process()` of a `@tool` script runs while you're designing. A crash in a `@tool` script can destabilize the editor. Always guard editor-only code with `if Engine.is_editor_hint()`.
- **`@export` on a typed Array requires the type parameter.** Write `@export var items: Array[String]`, not `@export var items: Array`. The untyped version won't show the correct Inspector widget.
- **Changing `@export` variable names breaks saved scenes.** If you rename an `@export` var, any `.tscn` files that saved a value for it will lose that value (the key no longer matches). Rename carefully, or use `@export` with a manual setter that migrates old names.
:::

## 7. GDScript Gotchas

These are the issues that trip up every developer at least once. Read through
 them now so you recognize them when they happen.

:::example[Gotcha 1 — Array and Dictionary are reference types]
You expect assigning an array to a new variable to copy it. It doesn't.

```gdscript
var a: Array[int] = [1, 2, 3]
var b: Array[int] = a        # b is the SAME array, not a copy!
b.append(4)
print(a)    # [1, 2, 3, 4]  — a was also modified!

# Fix: use duplicate()
var c: Array[int] = a.duplicate()
c.append(5)
print(a)    # [1, 2, 3, 4]  — a unchanged
print(c)    # [1, 2, 3, 4, 5]

# Deep copy (nested arrays/dicts): duplicate(true)
var deep: Array = original.duplicate(true)
```
:::

:::example[Gotcha 2 — Integer division]
You need to find the midpoint between two integer positions.

```gdscript
var a: int = 5
var b: int = 10
var mid: int = (a + b) / 2   # result: 7, not 7.5 — integer division truncates

# Fix: cast to float
var mid_f: float = (a + b) / 2.0
# or
var mid_f2: float = float(a + b) / 2.0
```
:::

:::example[Gotcha 3 — Signals need time to propagate; free() during a signal is unsafe]
Calling `free()` (not `queue_free()`) on a node from
 within one of its signal callbacks.

```gdscript
# WRONG — crashes because the signal system still holds a reference
func _on_health_depleted() -> void:
    free()    # immediate free while signal is mid-dispatch

# CORRECT — deferred to end of frame
func _on_health_depleted() -> void:
    queue_free()
```
:::

:::example[Gotcha 4 — Forgetting that Vector2 is a value type]
You want to move a node by modifying a cached vector variable.

```gdscript
var pos: Vector2 = position   # pos is a COPY of position
pos.x += 100                  # only modifies the copy, not the node!
# The node hasn't moved.

# Fix: modify position directly
position.x += 100
# or assign back
pos.x += 100
position = pos
```
:::

:::example[Gotcha 5 — Connecting a signal twice]
You connect a signal in both the editor *and* in code. The callback
 fires twice.

```gdscript
# If you connected "body_entered" in the editor AND write this in _ready():
$Area2D.body_entered.connect(_on_body_entered)
# The function fires twice per collision.

# Fix option 1: only connect in one place (editor OR code, not both)
# Fix option 2: check before connecting
if not $Area2D.body_entered.is_connected(_on_body_entered):
    $Area2D.body_entered.connect(_on_body_entered)
```
:::

### Practice problems — Section 7

:::problem[Problem 7.1 easy]{difficulty="easy"}
What is the result of `7 / 2` in GDScript? What about
 `7.0 / 2` and `7 / 2.0`? Why?

::::solution[Solution]
`7 / 2` → `3`. Both operands are integers, so GDScript
 performs integer division and truncates the result.

`7.0 / 2` → `3.5`. The left operand is a float, so
 GDScript promotes the result to float.

`7 / 2.0` → `3.5`. Same — the right operand is a
 float, which promotes the result. If either operand is a float, the result is
 a float.
::::
:::

:::problem[Problem 7.2 easy]{difficulty="easy"}
You have `var names: Array[String] = ["Alice", "Bob"]`. Write one
 line to add "Charlie" to the end, then one line to remove "Bob" by value
 (not by index).

::::solution[Solution]
```gdscript
names.append("Charlie")  # ["Alice", "Bob", "Charlie"]
names.erase("Bob")       # ["Alice", "Charlie"]
```
::::
:::

:::problem[Problem 7.3 standard]{difficulty="standard"}
Write a function `clamp_velocity(vel: Vector2, max_speed: float) -> Vector2`
 that returns the velocity unchanged if its length is below `max_speed`,
 or scales it down to exactly `max_speed` if it exceeds it.

::::solution[Solution]
```gdscript
func clamp_velocity(vel: Vector2, max_speed: float) -> Vector2:
    if vel.length() > max_speed:
        return vel.normalized() * max_speed
    return vel

# Godot also provides this as a built-in:
# vel = vel.limit_length(max_speed)
```
::::
:::

:::problem[Problem 7.4 standard]{difficulty="standard"}
Define an enum `WeaponType` with values `SWORD`,
 `BOW`, and `STAFF`. Export a variable `weapon`
 of that type so it appears as a dropdown in the Inspector. Then write a
 `match` statement that prints the weapon's name as a string.

::::solution[Solution]
```gdscript
extends Node

enum WeaponType { SWORD, BOW, STAFF }

@export var weapon: WeaponType = WeaponType.SWORD

func _ready() -> void:
    match weapon:
        WeaponType.SWORD: print("Sword equipped")
        WeaponType.BOW:   print("Bow equipped")
        WeaponType.STAFF: print("Staff equipped")
```
::::
:::

:::problem[Problem 7.5 challenge]{difficulty="challenge"}
Write a function `deep_merge(base: Dictionary, override: Dictionary) -> Dictionary`
 that returns a new dictionary where every key from `override`
 overwrites the corresponding key in `base`, but keys in
 `base` not present in `override` are preserved.
 The function must not modify either input dictionary.

::::solution[Solution]
```gdscript
func deep_merge(base: Dictionary, override: Dictionary) -> Dictionary:
    var result: Dictionary = base.duplicate()   # copy base
    for key in override:
        result[key] = override[key]             # override/add keys
    return result

# Example:
var defaults: Dictionary = {"speed": 200, "health": 100, "debug": false}
var custom: Dictionary   = {"speed": 350, "name": "Speedy"}
var merged: Dictionary   = deep_merge(defaults, custom)
# merged = {"speed": 350, "health": 100, "debug": false, "name": "Speedy"}
```
::::
:::

:::summary
## Chapter Summary

### Language quick-reference

| Feature | Syntax / example |
| --- | --- |
| Typed variable | `var speed: float = 200.0` |
| Inferred-type | `var speed := 200.0` |
| Constant | `const MAX_HP: int = 100` |
| Enum | `enum State { IDLE, RUNNING }` |
| Function | `func move(dir: Vector2) -> void:` |
| Default arg | `func spawn(pos: Vector2, level: int = 1):` |
| Lambda | `var fn := func(x: int) -> int: return x * 2` |
| match | `match state: State.IDLE: ... _: ...` |
| Array copy | `var b := a.duplicate()` |
| Dict safe get | `var v := d.get("key", default_val)` |
| String format | `"hp: %d / %d" % [hp, max_hp]` |
| @export | Exposes var in Inspector, saved in .tscn |
| @onready | Assigns during \_ready(); use with $NodeName |
| @tool | Runs script in editor — guard with is\_editor\_hint() |
| class\_name | Registers script as a global type |
| super() | Calls the parent class's version of the method |

### If you remember nothing else

**Always use static typing.** Write `var x: int = 0` not
 `var x = 0`. It catches bugs before runtime, enables autocomplete, and
 makes code faster. Arrays and Dictionaries are reference types — use
 `.duplicate()` when you need a copy.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
What does `Vector2.UP` equal in Godot's 2D coordinate system?
 Why is it different from the mathematical convention?

::::solution[Solution]
`Vector2.UP` is `(0, -1)`. In Godot's 2D coordinate
 system, the Y axis points *downward* (increasing Y = moving down the
 screen), following screen/pixel coordinates. Mathematical convention has Y
 pointing upward. Moving a node "up" in Godot means *subtracting* from
 its Y position.
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
Write the GDScript to format a high-score display string:
 given `var player_name: String = "Alice"` and
 `var score: int = 14750`, produce the string
 `"Alice — 14,750 pts"`. *Hint: GDScript doesn't have a
 built-in thousands-separator formatter; you can use a helper or just format
 without commas for this exercise.*

::::solution[Solution]
```gdscript
var player_name: String = "Alice"
var score: int = 14750
# Simple version (no comma separator)
var display: String = "%s — %d pts" % [player_name, score]

# With thousands comma (manual helper)
func format_with_commas(n: int) -> String:
    var s: String = str(n)
    var result: String = ""
    var count: int = 0
    for i in range(s.length() - 1, -1, -1):
        if count > 0 and count % 3 == 0:
            result = "," + result
        result = s[i] + result
        count += 1
    return result

var display2: String = "%s — %s pts" % [player_name, format_with_commas(score)]
# "Alice — 14,750 pts"
```
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
Write a complete GDScript class called `Timer2D` (using
 `class_name`) that extends `Node`. It should:
 export a `duration: float` (default 1.0), have a private
 `_elapsed: float` counter, and emit a signal called
 `finished` when elapsed reaches duration. Include the
 `_process(delta)` implementation.

::::solution[Solution]
```gdscript
class_name Timer2D extends Node

signal finished

@export var duration: float = 1.0
var _elapsed: float = 0.0
var _running: bool = false

func start() -> void:
    _elapsed = 0.0
    _running = true

func stop() -> void:
    _running = false

func _process(delta: float) -> void:
    if not _running:
        return
    _elapsed += delta
    if _elapsed >= duration:
        _running = false
        finished.emit()
```
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
You have an array of Vector2 positions. Write a function that returns the
 position in the array that is closest to a given target Vector2, without using
 any built-in sort or min functions — just a loop.

::::solution[Solution]
```gdscript
func closest_point(points: Array[Vector2], target: Vector2) -> Vector2:
    if points.is_empty():
        return target  # fallback
    var best: Vector2 = points[0]
    var best_dist: float = points[0].distance_to(target)
    for i in range(1, points.size()):
        var d: float = points[i].distance_to(target)
        if d < best_dist:
            best_dist = d
            best = points[i]
    return best
```
::::
:::

:::problem[Problem M.5 challenge]{difficulty="challenge"}
Write a generic object pool in GDScript: a class `ObjectPool`
 that takes a `PackedScene` and a `pool_size: int`.
 In `_ready()` it pre-instantiates `pool_size` nodes,
 adds them to the scene tree but hides them. `get_object() -> Node`
 returns the first hidden node and shows it. `return_object(node: Node)`
 hides the node again. If `get_object()` is called when all nodes
 are visible, it instantiates a new one and adds it to the pool.

::::solution[Solution]
```gdscript
class_name ObjectPool extends Node

@export var scene: PackedScene
@export var pool_size: int = 10

var _pool: Array[Node] = []

func _ready() -> void:
    for i in range(pool_size):
        _create_instance()

func _create_instance() -> Node:
    var obj: Node = scene.instantiate()
    add_child(obj)
    obj.hide()
    _pool.append(obj)
    return obj

func get_object() -> Node:
    for obj in _pool:
        if not obj.visible:
            obj.show()
            return obj
    # Pool exhausted — grow it
    var obj: Node = _create_instance()
    obj.show()
    return obj

func return_object(obj: Node) -> void:
    obj.hide()
    # Reset position if it's a Node2D
    if obj is Node2D:
        obj.position = Vector2.ZERO
```

Object pooling avoids the cost of `instantiate()` and
 `queue_free()` every frame. Essential for high-frequency spawning
 like bullets, particles, or coin pickups.
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
