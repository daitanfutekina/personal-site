---
title: "Ch 76 — Roguelike Pool Game (planned)"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 76"
meta:
  - "Not written yet"
  - "Tier 3 — Advanced Capstone · 3D / Jolt"
  - "Est. 18–25 h once written"
source: "markdown"
---

Part XIII · Chapter 76

# Roguelike Pool Game — Physics, Run Structure & Deck-Building

Tier 3 — Advanced Capstone · 3D / Jolt · estimated 18–25 h of study once written

:::callout-warning[This chapter is not written yet]
It is listed so the gap is visible while you read rather than only on the
index page. Nothing below is instruction — it is the scope the chapter is
meant to cover, kept here so it can be written from its own stub.
:::

## What it is meant to cover

- Physics that stay deterministic enough to be fair, using Jolt.
- Shot prediction, and how much of it to show the player.
- Run structure: what carries between tables and what resets.
- Deck-building over a physics game — the two halves have to agree about when a turn ends.

## Before this is written

The four walkthroughs that already exist — the Weapon Ball, Vampire
Survivors and Crowd Runner builds in this part — cover the ground this one
assumes. Working through one of those is the prerequisite, and is the
better use of the time until this chapter exists.

:::callout-tip[Cross-project note]
The roguelike pool game has its **design doc in a separate project
folder**. Chapters in this part reference it as the advanced capstone
example.
:::
