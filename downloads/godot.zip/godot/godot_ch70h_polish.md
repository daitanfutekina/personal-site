---
title: "Earclacks — Polish, VFX & Export for Shorts"
crumb: "Earclacks Weapon Ball — Chapter 70H"
meta:
  - "Est. study time: ~60 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview

:::callout-key[KEY CONCEPT]
GPUParticles2D hit sparks on weapon contact · Camera2D screen shake on ball death · Line2D motion trail on each ball · AudioStreamPlayer hit and death sounds · Export preset for Windows/macOS at 1080×1080 for OBS screen capture.
:::

None of these systems affect gameplay — they are pure presentation. Each is self-contained and can be skipped if you want a minimal build, but together they're what makes the difference between "prototype" and "YouTube Short."

## 1. Hit Sparks (GPUParticles2D)

Hit sparks are emitted at the hitbox tip position each time the weapon lands a hit.

1. In `Sword.tscn`, add a `GPUParticles2D` child to the `Hitbox` Area2D. Name it `HitEffect`. Position it at `(0, 0)` — it inherits the hitbox's world position.
2. Configure the particle system:

 Property Value

 Amount 12
 Lifetime 0.25
 One Shot ✓ on
 Emitting ✗ off (triggered by code)
 Draw Order Index
 Process Material → ParticleProcessMaterial New
 Initial Velocity Min/Max 80 / 200
 Color #ffcc44 → transparent (gradient)
 Scale Min 3
3. In `WeaponBase.gd`, emit the effect on a hit. Add:

`restart()` resets a one-shot particle system and begins emitting. Using `get_node_or_null` means this works even on weapons that don't have a HitEffect node.

   ```gdscript
   @onready var hit_effect: GPUParticles2D = get_node_or_null("Hitbox/HitEffect")

   func _try_hit(target: Node) -> void:
       # ... existing checks ...
       _hit_timers[target] = hit_cooldown
       hit_landed.emit(target, damage)
       if target.has_method("take_damage"):
           target.take_damage(damage)
       # Trigger sparks
       if hit_effect:
           hit_effect.restart()
   ```

## 2. Screen Shake on Ball Death

A 0.4-second camera shake on the death of either ball gives the finishing blow weight. Add a `shake()` method to a simple camera script:

```gdscript
# CameraController.gd — attach to the Camera2D in Arena.tscn
extends Camera2D

var _shake_strength: float = 0.0
var _shake_decay: float    = 10.0   # strength lost per second

func _physics_process(delta: float) -> void:
    if _shake_strength > 0.0:
        offset = Vector2(
            randf_range(-_shake_strength, _shake_strength),
            randf_range(-_shake_strength, _shake_strength)
        )
        _shake_strength = maxf(0.0, _shake_strength - _shake_decay * delta)
    else:
        offset = Vector2.ZERO

func shake(strength: float = 12.0) -> void:
    _shake_strength = strength
```

In `Arena.gd`, connect to `GameManager.match_ended` to trigger a shake:

```gdscript
@onready var camera: Camera2D = $Camera2D

func _ready() -> void:
    # ... existing connections ...
    GameManager.match_ended.connect(func(_w): camera.shake(18.0))
```

:::callout-tip[TIP]
strength=5 is subtle (coin drop). strength=12 is impactful (explosion). strength=25 is disorienting. For a death event, 18 is the sweet spot — noticeable but not headache-inducing.
:::

## 3. Ball Motion Trail

A motion trail makes fast ball movement readable. Godot 4 has no built-in trail node, but you can fake it with a `Line2D` that stores recent positions:

```gdscript
# TrailEffect.gd — attach to a Line2D child of Ball
extends Line2D

@export var trail_length: int = 20     # number of points to keep
@export var trail_width: float = 8.0

var _ball: Node2D

func _ready() -> void:
    _ball = get_parent()
    width = trail_width
    # Gradient from opaque (tail) to transparent (front)
    var grad = Gradient.new()
    grad.add_point(0.0, Color(1,1,1,0.6))
    grad.add_point(1.0, Color(1,1,1,0.0))
    gradient = grad

func _process(_delta: float) -> void:
    # Prepend current position (in global space → convert to local)
    add_point(to_local(_ball.global_position), 0)
    # Trim excess points
    while get_point_count() > trail_length:
        remove_point(get_point_count() - 1)
```

Add a `Line2D` to `Ball.tscn` with `TrailEffect.gd` attached. Set its `top_level = true` in the Inspector so it renders in global space (otherwise the trail rotates with the ball parent).

## 4. Sound Effects

Add two `AudioStreamPlayer` nodes to `Arena.tscn`: `HitSound` and `DeathSound`. Assign .wav or .ogg clips (free metallic clang and explosion sounds are available at [freesound.org](https://freesound.org) under CC0 licence).

```gdscript
# In Arena.gd
@onready var hit_sound: AudioStreamPlayer   = $HitSound
@onready var death_sound: AudioStreamPlayer = $DeathSound

func _ready() -> void:
    # ... existing ...
    GameManager.match_ended.connect(func(_w): death_sound.play())
```

For per-hit sound, connect from `WeaponBase.hit_landed` in `Arena.gd` after each ball is spawned, or add an `AudioStreamPlayer` to each weapon scene and play it in `WeaponBase._try_hit()`. The weapon-local approach is cleaner for independent volume control per weapon type.

## 5. Recording Setup for YouTube Shorts

:::callout-connect[CONNECTION]
The typical pipeline for algorithmic content channels: (1) Run the game windowed at 1080×1080. (2) Record with OBS at 60 fps. (3) Trim to 15–59 seconds. (4) Add text overlay or voiceover in video editor. (5) Upload directly to YouTube Shorts (portrait-safe because 1080×1080 crops cleanly to 9:16).
:::

### Godot Window Settings for Recording

| Setting | Value | Why |
| --- | --- | --- |
| Display/Window/Size/Width | 1080 | Square for Shorts |
| Display/Window/Size/Height | 1080 | Square for Shorts |
| Display/Window/Vsync Mode | Mailbox or Disabled | Uncap FPS for smoother recording |
| Application/Boot Screen/Show Splash | Off | No splash on OBS capture |
| Physics/Common/Physics Ticks per Second | 120 | Smoother weapon rotation at high speed |

:::callout-tip[TIP]
Set GameManager to auto-start a new match after a 2-second delay following match\_ended. You can then let OBS record for 30 minutes capturing dozens of fights — edit the best ones into Shorts later. Add to GameManager:

```gdscript
func end_match(w: String) -> void:
    winner_name = w
    set_state(State.GAME_OVER)
    match_ended.emit(winner_name)
    # Auto-replay after delay
    await get_tree().create_timer(2.0).timeout
    request_replay()
```
:::

## 6. Exporting the Project

1. Go to *Project → Export*. Add a preset for your platform (Windows/macOS/Linux).
2. Set the export name to `WeaponBall`. Choose an output folder.
3. Under *Options*, tick *Embed PCK* so the game is a single executable — no folder to manage.
4. Click *Export Project*. Run the resulting executable for recording.

:::callout-warning[WARNING]
You need Godot's export templates installed (

Editor → Manage Export Templates → Download

) before this works. Match the template version to your Godot version exactly.
:::

## Series Wrap-Up — What You Built

:::callout-connect[CONNECTION]
| Chapter | What it taught |
| --- | --- |
| 70 Design Sheet | GDD/TDD — scene hierarchy, script contracts, signal flow |
| 70A Scene Setup | Project config, global gravity=0, StaticBody2D walls, PhysicsMaterial, Camera2D, GameManager autoload skeleton |
| 70B Ball Movement | RigidBody2D config, Ball.tscn, Ball.gd, spawning from Arena, launch impulse |
| 70C Weapon System | WeaponBase.gd inheritance, Area2D hitboxes, Layer 3, hit cooldown, friendly-fire check |
| 70D Health System | HealthComponent component pattern, hp\_changed signal, death + VFX tween |
| 70E Match Flow | Full GameManager state machine, countdown timer with await, HUD, game-over screen, replay |
| 70G Multiple Weapons | 5 more weapons via WeaponBase, random selection, DPS balance |
| 70H Polish & Export | Hit sparks, screen shake, motion trail, audio, OBS recording setup, export |
| 70I Ball AI *(optional)* | BallAI component, apply\_central\_force steering, SEEK/EVADE/WANDER states — sets aside the design sheet’s "no AI steering" law |
:::

The architectural patterns used here — component composition (HealthComponent, BallAI), signal-driven decoupling, base class inheritance (WeaponBase), autoload singletons (GameManager) — apply directly to any game you build in Godot 4. The next walkthroughs will build on all of it.

## Chapter Summary

:::summary
### Polish Layer Checklist

| Effect | Node/Method | Trigger |
| --- | --- | --- |
| Hit sparks | GPUParticles2D.restart() | WeaponBase.\_try\_hit() |
| Screen shake | Camera2D offset noise in \_physics\_process | GameManager.match\_ended |
| Motion trail | Line2D with sliding point history | \_process() on every ball |
| Hit sound | AudioStreamPlayer.play() | WeaponBase.hit\_landed signal |
| Death sound | AudioStreamPlayer.play() | GameManager.match\_ended signal |
:::
