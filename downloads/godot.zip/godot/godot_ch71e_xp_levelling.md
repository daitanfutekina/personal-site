---
title: "VS Clone — XP Gems, Levelling & Upgrade Card UI"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71E"
meta:
  - "Est. study time: ~75 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated June 2026"
source: "godot_ch71e_xp_levelling.html"
---

## Overview

The level-up moment is the core feedback loop of Vampire Survivors: kill enemies,
 collect gems, choose an upgrade, feel more powerful, repeat. This chapter wires
 together the full XP gem → player → level-up → pause → upgrade card → resume pipeline.

By the end of this chapter the game will pause the moment the player levels up,
 display three randomly chosen upgrade cards, apply the chosen upgrade to the player,
 and resume gameplay — all without a single coroutine or external state machine.

:::callout-key[The pause trick — one flag, zero complexity]
`get_tree().paused = true` freezes every node that uses the default
 `PROCESS_MODE_PAUSABLE` mode. The UpgradeScreen CanvasLayer is set to
 `PROCESS_MODE_ALWAYS`, so it alone receives input while the game is frozen.
 No coroutines. No state machine. One flag.
:::

## 1. UpgradeResource — The Upgrade Base Class

:::callout-intuition[Why a Resource, not a Node?]
Upgrades have no visual or physics presence — they are pure data plus one
 method. A Resource is lighter than a Node, can be saved as a `.tres`
 file and edited in the Inspector without code, and is easily stored in arrays.
 Every upgrade is a `.tres` file you can drag into the library.
:::

### Create the base scripts

1. **Create UpgradeResource.gd.** In the FileSystem dock navigate to
 `res://resources/`. Right-click → **New Script**, name it
 `UpgradeResource.gd`. Paste the base class script below and save.
2. **Create the four concrete upgrade scripts** in the same folder:
 `SpeedUpgrade.gd`, `MaxHpUpgrade.gd`,
 `AddGarlicUpgrade.gd`, `GarlicDamageUpgrade.gd`.
 Paste each script from the code block below. Save each with Ctrl+S.
3. **Create .tres files for each upgrade.** Right-click
 `res://resources/upgrades/` (create folder if needed) →
 **New Resource**. Type the class name (e.g. `SpeedUpgrade`)
 and double-click. Fill in the **Upgrade Name** and
 **Description** fields in the Inspector. Save as
 `speed_upgrade.tres`. Repeat for each upgrade type.

```gdscript
## res://resources/UpgradeResource.gd
class_name UpgradeResource
extends Resource

@export var upgrade_name: String = "Upgrade"
@export var description:  String = ""
@export var icon: Texture2D

## Override in subclasses. Receives the Player and applies the effect.
func apply(player: Player) -> void:
    pass

## ─────────────────────────────────────────────────────────────────────
## Concrete upgrades — each in its own .gd file in res://resources/

## SpeedUpgrade.gd
class_name SpeedUpgrade
extends UpgradeResource
func apply(player: Player) -> void:
    player.stats.move_speed *= 1.20

## MaxHpUpgrade.gd — also heals 30 % of the bonus.
class_name MaxHpUpgrade
extends UpgradeResource
@export var bonus: float = 20.0
func apply(player: Player) -> void:
    player.stats.max_hp       += bonus
    player.stats.current_hp    = minf(player.stats.current_hp + bonus * 0.3,
                                      player.stats.max_hp)
    player.hp_changed.emit(player.stats.current_hp, player.stats.max_hp)

## AddGarlicUpgrade.gd — gives Garlic if not already owned.
class_name AddGarlicUpgrade
extends UpgradeResource
@export var garlic_scene: PackedScene
func apply(player: Player) -> void:
    for w in player.weapon_holder.get_children():
        if w is GarlicWeapon: return   ## already has it
    player.add_weapon(garlic_scene)

## GarlicDamageUpgrade.gd — upgrades Garlic if already owned.
class_name GarlicDamageUpgrade
extends UpgradeResource
@export var weapon_upgrade: WeaponUpgradeResource
func apply(player: Player) -> void:
    weapon_upgrade.apply(player)
```

## 2. UpgradeLibrary — The Upgrade Pool

The library is a single Resource that holds every possible upgrade the game can offer.
 GameManager draws from it when a level-up triggers.

1. **Create UpgradeLibrary.gd** in `res://resources/`.
 Paste the script below and save.
2. **Create upgrade\_library.tres.** Right-click
 `res://resources/` → **New Resource** → type
 `UpgradeLibrary` → double-click. Save as
 `upgrade_library.tres`.
3. **Populate the upgrades array.** Select
 `upgrade_library.tres` in the FileSystem. In the Inspector,
 click **Upgrades** to expand the array, set the size to the
 number of upgrades you made, then drag each `.tres` upgrade
 file into a slot.

```gdscript
## res://resources/UpgradeLibrary.gd
class_name UpgradeLibrary
extends Resource

@export var upgrades: Array[UpgradeResource] = []

## Return N non-duplicate upgrades chosen at random.
func pick(count: int) -> Array[UpgradeResource]:
    ## IMPORTANT: duplicate() before shuffle() — shuffle() mutates in-place.
    ## Without this the master array order changes on every call.
    var pool := upgrades.duplicate()
    pool.shuffle()
    return pool.slice(0, min(count, pool.size()))
```

## 3. Build UpgradeScreen.tscn — Step by Step

```
UpgradeScreen (CanvasLayer)      layer=2; process_mode=ALWAYS
└── PanelContainer               ← anchored to full rect; semi-transparent bg
    └── VBoxContainer            ← separation=32; alignment=center
        ├── TitleLabel           ← text="Choose an Upgrade"; align=center
        └── CardsContainer (HBoxContainer)   separation=24; alignment=center
            ├── Card0 (Button)   ← min_size=(200,280)
            ├── Card1 (Button)
            └── Card2 (Button)
```

1. **Open UpgradeScreen.tscn.** This scene was created as a skeleton
 in Ch 71A. In the FileSystem dock, double-click
 `res://scenes/ui/UpgradeScreen.tscn`.
2. **Set the CanvasLayer properties.** Select the
 `UpgradeScreen` root (CanvasLayer). In the Inspector:

   - **Layer:** `2` — renders above the HUD (layer 1).
   - **Process Mode:** **Always** — receives input while paused.

3. **Add PanelContainer.** Select `UpgradeScreen`,
 Ctrl+A, add `PanelContainer`. In the Inspector under
 **Layout → Anchors Preset** choose **Full Rect** so
 it fills the whole screen. Apply a semi-transparent dark StyleBoxFlat:
 right-click the PanelContainer → **Theme Overrides → Styles → Panel**
 → New StyleBoxFlat → set BG Color to black with alpha ~0.75.
4. **Add VBoxContainer** as a child of PanelContainer. Set
 **Alignment: Center** and **Custom Minimum Size**
 tall enough to hold title + cards.
5. **Add TitleLabel** (a `Label`) as the first child of
 VBoxContainer. Set **Text:** `Choose an Upgrade`.
 Under **Horizontal Alignment** choose **Center**.
 Use a larger font size (~24 px) via Theme Overrides.
6. **Add CardsContainer** (an `HBoxContainer`) as the second
 child of VBoxContainer. Set **Alignment: Center** and
 **Separation: 24**.
7. **Add three Button children** to CardsContainer. Name them
 `Card0`, `Card1`, `Card2`. For each:

   - **Custom Minimum Size:** 200 × 280.
   - **Expand Icon:** On. **Icon Alignment:** Top.
   - **Focus Mode:** All (enables keyboard/gamepad navigation).

8. **Attach UpgradeScreen.gd.** Select the root node, attach
 `res://scenes/ui/UpgradeScreen.gd`. Paste the script from section 4.
 In the Inspector, assign `upgrade_library.tres` to the
 **Upgrade Library** export slot.
9. **Save the scene.** Press Ctrl+S.

## 4. UpgradeScreen.gd

```gdscript
## res://scenes/ui/UpgradeScreen.gd
extends CanvasLayer

@export var upgrade_library: UpgradeLibrary

@onready var card_scenes: Array[Button] = [
    $PanelContainer/VBoxContainer/CardsContainer/Card0,
    $PanelContainer/VBoxContainer/CardsContainer/Card1,
    $PanelContainer/VBoxContainer/CardsContainer/Card2,
]

var _current_upgrades: Array[UpgradeResource] = []
var _player: Player

func _ready() -> void:
    _player      = get_tree().get_first_node_in_group("player") as Player
    visible      = false
    ## Must be ALWAYS so we receive input while get_tree().paused = true.
    process_mode = PROCESS_MODE_ALWAYS

## Called from Main._on_game_state_changed(LEVEL_UP).
func show_cards() -> void:
    _current_upgrades = upgrade_library.pick(3)
    for i in card_scenes.size():
        var card := card_scenes[i]
        if i < _current_upgrades.size():
            var upg := _current_upgrades[i]
            card.text         = upg.upgrade_name
            card.tooltip_text = upg.description
            if upg.icon:
                card.icon = upg.icon
            card.visible = true
            ## Disconnect before reconnecting to prevent double-fire on repeat level-ups.
            if card.pressed.is_connected(_on_card_pressed.bind(i)):
                card.pressed.disconnect(_on_card_pressed.bind(i))
            card.pressed.connect(_on_card_pressed.bind(i))
        else:
            card.visible = false
    visible = true
    card_scenes[0].grab_focus()   ## keyboard/gamepad can navigate immediately

func _on_card_pressed(index: int) -> void:
    if index >= _current_upgrades.size():
        return
    _current_upgrades[index].apply(_player)
    _close()

func _close() -> void:
    visible = false
    get_tree().paused = false
    GameManager._set_state(GameManager.State.PLAYING)
```

:::callout-warning[Reconnecting signals on each level-up]
The disconnect-before-connect pattern is right, but not because the handler would fire twice. Measured in Godot 4.6.3: connecting a callable that is already connected is *refused* — `connect()` returns `ERR_INVALID_PARAMETER` and the engine prints `Signal 'pressed' is already connected to given callable`. Emitting still calls the handler once. So what the disconnect avoids is a stream of errors, not double firing.

 There is a sharper trap underneath it. Bound arguments do not make a connection distinct: `_h.bind("a")` and `_h.bind("b")` on the same signal are treated as the same connection, and the second is refused. That is fine here, because each card has its own `pressed` signal, but it means you cannot fan one signal out to one method with different bound values — use separate methods, or a lambda per case, or index into `_current_upgrades` by button as below.
:::

## 5. Pause & Unpause Flow

The complete call chain when a player levels up:

```
Player._level_up()
  → GameManager.trigger_level_up()
      → GameManager._set_state(LEVEL_UP)
          → state_changed signal fires
              → Main._on_game_state_changed(LEVEL_UP):
                    get_tree().paused = true
                    $UpgradeScreen.show_cards()

── player picks a card ──

UpgradeScreen._on_card_pressed(i):
    upgrade.apply(_player)
    get_tree().paused = false
    GameManager._set_state(PLAYING)
```

:::callout-pitfall[Pause BEFORE show\_cards(), not after]
Set `get_tree().paused = true` before calling
 `show_cards()`. If you call `show_cards()` first,
 any Tween or AnimationPlayer inside UpgradeScreen starts a frame before the
 tree freezes and may flicker or miss its first frame. Pause first, show second.
:::

## 6. Build HUD.tscn — Step by Step

```
HUD (CanvasLayer)                layer=1; process_mode=ALWAYS
└── MarginContainer              ← 12 px margins all sides
    └── VBoxContainer
        ├── HpBar (ProgressBar)  ← max=100; tint red
        ├── XpBar (ProgressBar)  ← max=50; tint cyan
        ├── TimerLabel (Label)   ← text="00:00"; monospace font
        └── KillLabel (Label)    ← text="Kills: 0"

GameOverPanel (Panel)            ← hidden by default; centered on screen
VictoryPanel  (Panel)            ← hidden by default; centered on screen
```

1. **Open HUD.tscn.** Double-click
 `res://scenes/ui/HUD.tscn` in the FileSystem dock. This was
 created as a skeleton in Ch 71A. If it's empty, create it now:
 **Scene → New Scene** → `CanvasLayer` root,
 rename to `HUD`, save as `res://scenes/ui/HUD.tscn`.
2. **Set CanvasLayer properties.** Layer: `1`.
 Process Mode: **Always** (so the timer label keeps updating
 even in pause — though we actually want it to freeze during level-up,
 so alternatively use **Inherit** and rely on Main pausing).
3. **Add MarginContainer.** Set **Anchors Preset**
 to **Full Rect**. Under **Theme Overrides → Constants**
 set Margin Left/Top/Right/Bottom all to `12`.
4. **Add VBoxContainer** inside MarginContainer. Set
 **Alignment: Begin**. This stacks bars at the top-left.
5. **Add HpBar (ProgressBar).** Set **Max Value:**
 `100`, **Value:** `100`.
 Under **Fill Color** choose a deep red.
 Set **Custom Minimum Size** to `200 × 16`.
6. **Add XpBar (ProgressBar).** Max Value `50`,
 Value `0`. Fill Color: teal/cyan. Same minimum size.
7. **Add TimerLabel (Label).** Text: `00:00`.
 Apply a monospace font via Theme Overrides → Fonts.
8. **Add KillLabel (Label).** Text: `Kills: 0`.
9. **Add GameOverPanel and VictoryPanel.** Add two `Panel`
 nodes as direct children of the `HUD` root (not inside VBoxContainer).
 Anchor both to **Center**. Add a `Label` child to each
 with the appropriate message. Set both panels to `visible = false`
 in the Inspector.
10. **Attach HUD.gd.** Attach `res://scenes/ui/HUD.gd`
 to the root. Paste the script from section 7. Save with Ctrl+S.

## 7. HUD.gd

```gdscript
## res://scenes/ui/HUD.gd
extends CanvasLayer

@onready var hp_bar:          ProgressBar = $MarginContainer/VBoxContainer/HpBar
@onready var xp_bar:          ProgressBar = $MarginContainer/VBoxContainer/XpBar
@onready var timer_lbl:       Label       = $MarginContainer/VBoxContainer/TimerLabel
@onready var kill_lbl:        Label       = $MarginContainer/VBoxContainer/KillLabel
@onready var game_over_panel: Panel       = $GameOverPanel
@onready var victory_panel:   Panel       = $VictoryPanel

func _ready() -> void:
    game_over_panel.hide()
    victory_panel.hide()

func on_hp_changed(new_hp: float, max_hp: float) -> void:
    hp_bar.max_value = max_hp
    hp_bar.value     = new_hp

func on_xp_changed(new_xp: float, needed: float) -> void:
    xp_bar.max_value = needed
    xp_bar.value     = new_xp

func update_timer(seconds: float) -> void:
    var mins := int(seconds) / 60
    var secs := int(seconds) % 60
    timer_lbl.text = "%02d:%02d" % [mins, secs]

func update_kills(count: int) -> void:
    kill_lbl.text = "Kills: %d" % count

func show_game_over() -> void:
    game_over_panel.show()

func show_victory() -> void:
    victory_panel.show()
```

## 8. Wire All Signals in Main.gd

Main.gd is the coordinator — it listens for state changes from GameManager
 and routes them to the correct UI node. Open
 `res://scenes/main/Main.gd` and add the following to
 `_ready()` and as new functions:

1. **Connect GameManager state signal.** In `Main._ready()`:

   ```gdscript
   GameManager.state_changed.connect(_on_game_state_changed)
   ```

2. **Connect Player HP and XP signals to HUD.** After the player
 is in the scene tree:

   ```gdscript
   var player := $Player as Player
   player.hp_changed.connect($HUD.on_hp_changed)
   player.xp_changed.connect($HUD.on_xp_changed)
   ```

3. **Add the state handler function:**

   ```gdscript
   func _on_game_state_changed(new_state: GameManager.State) -> void:
       match new_state:
           GameManager.State.LEVEL_UP:
               get_tree().paused = true        ## pause FIRST
               $UpgradeScreen.show_cards()
           GameManager.State.GAME_OVER:
               get_tree().paused = false
               $HUD.show_game_over()
           GameManager.State.VICTORY:
               get_tree().paused = false
               $HUD.show_victory()
   ```

4. **Update HUD timer and kills each frame.** In
 `Main._process(delta)`:

   ```gdscript
   func _process(_delta: float) -> void:
       $HUD.update_timer(GameManager.run_timer)
       $HUD.update_kills(GameManager.kill_count)
   ```

5. **Assign upgrade\_library.tres to UpgradeScreen.** Select
 `$UpgradeScreen` in Main.tscn. In the Inspector, drag
 `upgrade_library.tres` into the **Upgrade Library**
 slot. Save Main.tscn with Ctrl+S.

## 9. Pickup-All Mechanic

A "Pickup All" floor item — a treasure chest or magnet pickup — force-attracts
 every live XP gem on screen regardless of magnet range. Add this to Player.gd:

```gdscript
## In Player.gd
func attract_all_gems() -> void:
    for node in get_tree().get_nodes_in_group("xp_gems"):
        var gem := node as XpGem
        if gem and not gem._attracting:
            gem.start_attract(self)
```

Any floor-item scene that should trigger this calls
 `player.attract_all_gems()` when it's collected.

## 10. Verification Checklist

1. **HP bar decreases when enemies touch the player.**
 If it doesn't update: `player.hp_changed` signal is not connected
 to `$HUD.on_hp_changed` in Main.\_ready().
2. **XP bar fills as gems are collected.** If it doesn't update:
 `player.xp_changed` is not connected, or
 `Player.gain_xp()` isn't emitting the signal.
3. **Game pauses and three upgrade cards appear on level-up.**
 If the game pauses but no cards appear: UpgradeScreen.visible is not
 being set to true in `show_cards()`, or the UpgradeLibrary
 export is not assigned in the Inspector.
4. **Choosing a card applies the upgrade and resumes gameplay.**
 If gameplay doesn't resume: `get_tree().paused = false` is
 missing or not being reached in `_close()`.
5. **Run timer increments in the top-left during gameplay.**
 If it shows 00:00 and freezes: `Main._process()` isn't calling
 `$HUD.update_timer()`, or GameManager.run\_timer isn't incrementing.
6. **Game Over panel appears when player HP reaches 0.**
 If not: `GameManager._set_state(GAME_OVER)` is not being called
 when Player dies, or the state\_changed signal isn't connected to Main.

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
Why must `get_tree().paused = true` be called *before*
 `show_cards()`?

::::solution[Solution]
Any Tween or animation inside `show_cards()` would get one running
 frame before the tree pauses, causing a flicker or missed first frame. Pausing
 first means the UpgradeScreen's ALWAYS-mode nodes start from a clean state, and
 all gameplay nodes are already frozen before the UI appears.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
A player has 45 XP and needs 62 XP for level 2. They collect a gem worth 20 XP.
 Do they level up? What are their XP and new threshold after?

::::solution[Solution]
45 + 20 = 65 ≥ 62 → level-up triggers.

 Remainder: 65 − 62 = 3 XP carried over.

 New level: 3. New threshold: floor(62 × 1.25) = 77 XP.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
Explain why `UpgradeLibrary.pick()` calls
 `upgrades.duplicate()` before shuffling.

::::solution[Solution]
`Array.shuffle()` mutates the array in-place. Without
 `duplicate()`, every call permanently reorders the master
 `upgrades` array stored in the Resource. Since Resources are
 reference-typed, this mutation persists across all future level-ups in the
 same run. Duplicating creates a local throw-away copy; the original is untouched.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Design an upgrade that grants a 5-second invincibility shield. Write the
 `apply()` method and explain where the timer logic lives.

::::solution[Solution]
```gdscript
class_name ShieldUpgrade
extends UpgradeResource
func apply(player: Player) -> void:
    player.activate_shield(5.0)
```

Timer logic in Player.gd:

```gdscript
var _shield_active: bool = false
func activate_shield(duration: float) -> void:
    _shield_active = true
    await get_tree().create_timer(duration).timeout
    _shield_active = false
func take_damage(amount: float) -> void:
    if _shield_active: return
    ## ... normal damage pipeline ...
```

The upgrade only calls the public API; all timer logic stays inside Player.gd.
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Modify `show_cards()` to show fewer than 3 cards when the
 upgrade library has fewer than 3 items available, hiding unused slots cleanly
 and always focusing the first visible card.

::::solution[Solution]
```gdscript
func show_cards() -> void:
    _current_upgrades = upgrade_library.pick(3)
    var count := _current_upgrades.size()
    for i in card_scenes.size():
        var card := card_scenes[i]
        card.visible = i < count
        if i < count:
            var upg := _current_upgrades[i]
            card.text         = upg.upgrade_name
            card.tooltip_text = upg.description
            if card.pressed.is_connected(_on_card_pressed.bind(i)):
                card.pressed.disconnect(_on_card_pressed.bind(i))
            card.pressed.connect(_on_card_pressed.bind(i))
    visible = count > 0
    if count > 0:
        card_scenes[0].grab_focus()
```
::::
:::

## Summary

:::summary
## Chapter 71E — Key Points

| What | How | Why |
| --- | --- | --- |
| UpgradeResource | Resource subclass; apply(player) virtual; one .tres per upgrade | Data-driven — add new upgrades without touching existing code |
| UpgradeLibrary | Resource with Array[UpgradeResource]; pick(n) duplicates then shuffles | duplicate() prevents mutating master array across calls |
| Level-up trigger | Player.\_level\_up() → GameManager.trigger\_level\_up() | Player doesn't know about UI; GameManager broadcasts state change |
| Pause pattern | paused=true BEFORE show\_cards() | Avoids animation frame races during state transition |
| UpgradeScreen | CanvasLayer layer=2, PROCESS\_MODE\_ALWAYS; hides on card pick | Renders and receives input while all other nodes are paused |
| Signal reconnect | Disconnect pressed before reconnecting each level-up | Prevents double-fire on repeat level-ups |
| HUD bars | hp\_changed / xp\_changed signals from Player drive ProgressBar values | HUD is passive — Player owns the data, HUD only displays it |
:::

Next: **Ch 71F** builds the full GameManager — run timer, kill counter,
 death and victory conditions, and the restart flow that reloads the scene cleanly.
