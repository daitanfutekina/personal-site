---
title: "Earclacks — Multiple Weapons & Balancing"
crumb: "Earclacks Weapon Ball — Chapter 70G"
meta:
  - "Est. study time: ~45 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview

:::callout-key[KEY CONCEPT]
5 new weapon scenes (Dagger, Scythe, Spear, Shuriken, Scimitar) each as a 2–3 line GDScript extending WeaponBase · Random weapon picker in Arena.gd · DPS normalisation table confirming all weapons are balanced.
:::

## 1. Weapon Roster

| Weapon | Arm (px) | Speed (°/s) | Damage | Cooldown (s) | Visual color |
| --- | --- | --- | --- | --- | --- |
| Dagger | 60 | 360 | 8 | 0.4 | #c0d0e0 (silver) |
| Sword | 90 | 240 | 15 | 0.5 | #a0b0c0 (steel) |
| Scythe | 110 | 180 | 22 | 0.55 | #3a8060 (dark green) |
| Spear | 130 | 120 | 30 | 0.7 | #b08040 (bronze) |
| Shuriken | 80 | 720 | 6 | 0.3 | #80a0c0 (blue-grey) |
| Scimitar | 100 | 200 | 25 | 0.5 | #c09030 (gold) |

## 2. Building Each Weapon

Every weapon follows the same recipe as the Sword from Ch 70C. The only differences are the Inspector export values. Create each scene in `res://scenes/weapons/`:

1. **Duplicate Sword.tscn** → rename to e.g. `Dagger.tscn`. Update the ColorRect color. Resize the CollisionShape2D to match arm\_length (Dagger is 60 px — make the blade 8×60).
2. Create a matching script, e.g. `res://scripts/Dagger.gd`:

 Repeat for Scythe, Spear, Shuriken, Scimitar substituting the table values.

   ```gdscript
   extends WeaponBase
   func _ready() -> void:
       arm_length = 60.0; angular_speed_deg = 360.0
       damage = 8.0; hit_cooldown = 0.4
       super._ready()
   ```

:::callout-tip[TIP]
Instead of a script, you can set

arm\_length

, `angular_speed_deg`,

damage

, and

hit\_cooldown

directly in the Inspector for each scene's root node (they are

@export

variables on WeaponBase). Either approach works — the script approach makes the values version-control friendly.
:::

## 3. Random Weapon Selection in Arena.gd

Replace the hardcoded `const SwordScene` with an array export:

```gdscript
@export var available_weapons: Array[PackedScene] = []

func _spawn_ball(team: Dictionary, spawn_pos: Vector2, launch_dir: Vector2) -> RigidBody2D:
    var ball = BallScene.instantiate()
    ball.team_color   = team["color"]
    ball.ball_name    = team["name"]
    ball.weapon_scene = available_weapons.pick_random() if not available_weapons.is_empty() else null
    balls_node.add_child(ball)
    ball.global_position = spawn_pos
    ball.launch(launch_dir)
    ball.died.connect(GameManager.ball_died)
    $HUD.register_ball(ball, team["name"])
    return ball
```

In the Arena.tscn Inspector, drag all 6 weapon scenes into the `available_weapons` array. Each match now randomises independently — no code change needed to add a seventh weapon later.

## 4. DPS Balance Check

DPS = Damage / Cooldown. For a ball with 100 HP, time-to-kill (TTK) = 100 / DPS.

| Weapon | Damage | Cooldown | DPS | TTK (100 HP) |
| --- | --- | --- | --- | --- |
| Dagger | 8 | 0.4 | 20 | 5.0 s |
| Sword | 15 | 0.5 | 30 | 3.3 s |
| Scythe | 22 | 0.55 | 40 | 2.5 s |
| Spear | 30 | 0.7 | 43 | 2.3 s |
| Shuriken | 6 | 0.3 | 20 | 5.0 s |
| Scimitar | 25 | 0.5 | 50 | 2.0 s |

TTK ranges from 2.0 s (Scimitar) to 5.0 s (Dagger/Shuriken). That's a 2.5× spread — intentional. Faster weapons have more arm length exposure (larger orbit radius) which offsets their lower raw DPS. If a matchup feels too one-sided, increase the losing weapon's damage or reduce its cooldown by 15%.

## Chapter Summary

:::summary
### Six Weapons, All Balanced

With six distinct weapons and random selection, no two matches play identically. The WeaponBase pattern meant each new weapon required only a scene file and a ~5-line script — the payoff for good architecture in Ch 70C.
:::

## Practice Problems

**1.** easy — How many lines of code does it take to add a seventh weapon (a Halberd: arm=120, speed=150°/s, damage=28, cooldown=0.65) using the current architecture?

:::solution[Solution]
Three lines in the GDScript, plus duplicating Sword.tscn and renaming it. The script: `extends WeaponBase`, `func _ready():`, and the single assignment line `arm_length=120; angular_speed_deg=150; damage=28; hit_cooldown=0.65; super._ready()`. Then drag the scene into the `available_weapons` array in the Inspector — no other code changes needed.
:::

**2.** standard — The Shuriken spins at 720°/s — two full rotations per second. Explain why this high speed alone doesn't necessarily make it the strongest weapon given its 6-damage / 0.3s cooldown stats.

:::solution[Solution]
DPS is capped by the *cooldown* per target, not by hit frequency. The hitbox sweeps through the enemy at 720°/s so it contacts very frequently — but `_hit_timers` enforces a 0.3s minimum between hits on the same target. So it hits at most once per 0.3s regardless of rotational speed. DPS = 6/0.3 = 20. The high speed only helps if the ball briefly passes through the enemy and back — the cooldown means it won't double-dip on a long sweep.
:::

**3.** challenge — Design a Scimitar whose blade is a curved arc (not a straight rectangle). Describe what Godot node or shape you'd use for the hitbox, and how you'd create the curved visual without importing an art asset.

:::solution[Solution]
For the hitbox: use a `CollisionPolygon2D` with a hand-crafted polygon approximating the arc (6–8 points), or use a chain of 2–3 overlapping `CapsuleShape2D` hitboxes each rotated slightly. For the visual: draw the arc using a `Line2D` with a curved point array and a non-zero width, or use a `Polygon2D` with the same arc polygon. The Polygon2D approach is easiest — define the polygon once, reuse it for both the visual and the CollisionPolygon2D.
:::
