---
title: "Saving & Loading — Persistence Across Play Sessions"
source: "markdown"
---

Part III · Chapter 24

# Saving & Loading — Persistence Across Play Sessions

Prerequisite: Chapters 4 & 10 (GDScript) · est. 80 min

## Overview

A game that cannot save its state forces players to restart from scratch every time
 they close it. Godot provides four complementary mechanisms for data persistence,
 each suited to a different kind of data:

- **FileAccess** — raw byte-level read/write for any custom format.
- **JSON** — human-readable text serialisation ideal for structured game
 state (inventory, quests, player stats).
- **ConfigFile** — INI-style key/value store designed for settings and
 configuration files.
- **ResourceSaver / ResourceLoader** — Godot's native resource system
 for saving typed `Resource` subclasses as `.tres` (text) or
 `.res` (binary) files.

This chapter covers all four in depth, then shows how to build a production-quality
 save-slot system with schema versioning and autosave. All paths use
 `user://` for data that must persist after the player installs updates.

:::callout-intuition[Intuition — Choosing the right tool]
Use

JSON

when the data needs to be human-readable or shared with
        external tools.  Use

ConfigFile

for settings screens — it preserves
        comments and sections beautifully.  Use

Custom Resources

when your
        data maps naturally to Godot object types and you want the Inspector to edit it.
        Use

FileAccess binary

for large data blobs (world chunks, replay
        data) where file size matters.
:::

## 1 · FileAccess

Godot Save Methods — when to use each

JSON

.json files

✓ Human-readable

✓ Cross-platform

✓ Easy to debug

✗ Larger file size

✗ Manual type handling

Best for: game state,

settings, high scores

ConfigFile

.cfg / .ini files

✓ Key-value sections

✓ Handles Godot types

✓ Section-based

✗ Not for complex data

✗ No nested structure

Best for: user prefs,

keybindings, options

Resource

.tres / .res files

✓ Native Godot types

✓ Nested resources

✓ Editor-visible

✗ Godot-only format

✗ Larger .tres files

Best for: item defs,

characters, rich data

Binary

FileAccess + var\_to\_bytes

✓ Smallest file size

✓ Fast to parse

✓ Godot types native

✗ Not human-readable

✗ Harder to version

Best for: large maps,

replay data, bulk data

Four save mechanisms, each suited to different data. Most games use JSON or ConfigFile for settings, and either JSON or Custom Resources for actual game state. Binary format is only needed when file size or parse speed is critical.

### 1.1 · Path prefixes: user:// vs res://

Godot uses virtual path prefixes that map to OS-specific directories:

| Prefix | Maps to (Windows example) | Writable? | Use for |
| --- | --- | --- | --- |
| `user://` | `%APPDATA%\Godot\app_userdata\<project>\` | Yes | Save files, logs, screenshots, downloaded content. |
| `res://` | Project folder (editor) / PCK root (exported) | No (read-only in exports) | Game assets packed with the build. |

Always use `user://` for anything that changes at runtime. Writing to
 `res://` works in the editor but will silently fail or crash in an
 exported build because the PCK file is read-only.

:::callout-tip[Tip — Finding user:// on disk]
Run

OS.get\_user\_data\_dir()

at runtime to get the absolute OS path.
        You can also open it in the system file manager from the editor via

Project → Open User Data Folder

.
:::

### 1.2 · Reading and writing text files

`FileAccess.open(path, mode)` returns a `FileAccess` object
 on success or `null` on failure. In Godot 4 the file is automatically
 closed when the object is garbage-collected (goes out of scope), but calling
 `close()` explicitly is safer for immediate flushing.

```gdscript
# ── Writing ──────────────────────────────────────────────────────────
func write_text(path: String, content: String) -> bool:
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        push_error("Cannot write to '%s': %s" % [path, error_string(FileAccess.get_open_error())])
        return false
    file.store_string(content)
    return true   # auto-closes when 'file' goes out of scope

# ── Reading ───────────────────────────────────────────────────────────
func read_text(path: String) -> String:
    if not FileAccess.file_exists(path):
        return ""
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_error("Cannot read '%s': %s" % [path, error_string(FileAccess.get_open_error())])
        return ""
    return file.get_as_text()

# ── Appending ─────────────────────────────────────────────────────────
func append_line(path: String, line: String) -> void:
    var file := FileAccess.open(path, FileAccess.READ_WRITE)
    if file == null:
        # File does not exist yet — create it
        file = FileAccess.open(path, FileAccess.WRITE)
    if file:
        file.seek_end()
        file.store_line(line)
```

| Mode constant | Creates file if absent? | Truncates? | Seek position |
| --- | --- | --- | --- |
| `FileAccess.READ` | No | No | Start |
| `FileAccess.WRITE` | Yes | Yes (empty) | Start |
| `FileAccess.READ_WRITE` | No | No | Start |
| `FileAccess.WRITE_READ` | Yes | Yes | Start |

### 1.3 · Binary files

For compact data storage — level chunk data, replay recordings, custom asset formats —
 use the binary read/write helpers. Binary files are typically 30–60% smaller than
 equivalent JSON and much faster to parse.

```gdscript
## Save a fixed-size player record as raw binary
func save_binary_record(path: String, player: Dictionary) -> void:
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        return
    file.store_32(player["hp"])                   # 4 bytes, unsigned 32-bit int
    file.store_float(player["pos_x"])             # 4 bytes, IEEE 754 float
    file.store_float(player["pos_y"])
    file.store_pascal_string(player["name"])      # length-prefixed UTF-8 string

## Load it back
func load_binary_record(path: String) -> Dictionary:
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return {}
    return {
        "hp":    file.get_32(),
        "pos_x": file.get_float(),
        "pos_y": file.get_float(),
        "name":  file.get_pascal_string(),
    }
```

:::callout-warning[Warning — Endianness]
FileAccess

defaults to

little-endian

byte order.  If you
        are exchanging binary files with a non-Godot program that uses big-endian, set

file.big\_endian = true

immediately after opening.  Mismatched endianness
        produces silently wrong values rather than errors.
:::

### 1.4 · Directory operations

Use `DirAccess` to create directories, list files, and check for existence
 before writing:

```gdscript
## Ensure a directory exists before writing into it
func ensure_dir(path: String) -> void:
    if not DirAccess.dir_exists_absolute(
            ProjectSettings.globalize_path(path)):
        DirAccess.make_dir_recursive_absolute(
            ProjectSettings.globalize_path(path))

## List all .sav files in user://saves/
func list_saves() -> Array[String]:
    var dir := DirAccess.open("user://saves/")
    if dir == null:
        return []
    var result: Array[String] = []
    dir.list_dir_begin()
    var fname := dir.get_next()
    while fname != "":
        if not dir.current_is_dir() and fname.ends_with(".sav"):
            result.append(fname)
        fname = dir.get_next()
    dir.list_dir_end()
    return result
```

## 2 · JSON Serialisation

JSON is the most common format for game save data because it is human-readable,
 easy to diff in version control, and trivially editable for debugging. Godot
 provides both a static API and a `JSON` class for advanced use.

### 2.1 · JSON.stringify() and JSON.parse\_string()

The two static helpers cover the vast majority of use cases:

```gdscript
## Save structured game data as JSON
func save_json(path: String, data: Dictionary) -> bool:
    var json_str := JSON.stringify(data, "\t")   # "\t" = pretty-print with tabs
    var file     := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        push_error("Cannot open '%s' for writing." % path)
        return false
    file.store_string(json_str)
    return true

## Load and parse JSON back to a Dictionary
func load_json(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        return {}
    var text := FileAccess.get_file_as_string(path)  # convenience: open + read + close
    if text.is_empty():
        return {}
    var result := JSON.parse_string(text)
    if result == null:
        push_error("Failed to parse JSON from '%s'." % path)
        return {}
    if result is not Dictionary:
        push_error("Expected a JSON object at root, got %s." % type_string(typeof(result)))
        return {}
    return result as Dictionary
```

:::callout-pitfall[Pitfall — Type loss in JSON]
JSON has no concept of Godot types like

Vector2

,

Color

, or

NodePath

.  When you save a

Vector2(32.0, 64.0)

it becomes
        a JSON array

[32.0, 64.0]

, and when loaded back it is an Array, not a
        Vector2.  Either store components separately
        (

{"x": 32.0, "y": 64.0}

) and reconstruct on load, or use the

var\_to\_str()

/

str\_to\_var()

pair which preserves Godot
        types (at the cost of a non-standard format).
:::

### 2.2 · The JSON class for detailed error reporting

When loading untrusted JSON (player-editable files, downloaded content) use the
 `JSON` class instance for proper error location reporting:

```gdscript
func load_json_safe(path: String) -> Variant:
    if not FileAccess.file_exists(path):
        push_warning("JSON file not found: %s" % path)
        return null

    var text := FileAccess.get_file_as_string(path)
    var parser := JSON.new()
    var err    := parser.parse(text)

    if err != OK:
        push_error("JSON parse error in '%s' at line %d: %s" % [
            path, parser.get_error_line(), parser.get_error_message()
        ])
        return null

    return parser.data   # Variant — check type before using
```

### 2.3 · Serialising Godot types

A helper dictionary that converts common Godot types to/from JSON-safe representations:

```gdscript
## Convert a game-state Dictionary (with Godot types) to a JSON-safe one
static func to_json_safe(data: Dictionary) -> Dictionary:
    var out := {}
    for key in data:
        var val: Variant = data[key]
        if val is Vector2:
            out[key] = {"__type": "Vector2", "x": val.x, "y": val.y}
        elif val is Color:
            out[key] = {"__type": "Color", "r": val.r, "g": val.g,
                        "b": val.b, "a": val.a}
        elif val is Dictionary:
            out[key] = to_json_safe(val)   # recurse
        else:
            out[key] = val
    return out

## Reconstruct Godot types from a loaded JSON Dictionary
static func from_json_safe(data: Dictionary) -> Dictionary:
    var out := {}
    for key in data:
        var val: Variant = data[key]
        if val is Dictionary and val.has("__type"):
            match val["__type"]:
                "Vector2": out[key] = Vector2(val["x"], val["y"])
                "Color":   out[key] = Color(val["r"], val["g"], val["b"], val["a"])
        elif val is Dictionary:
            out[key] = from_json_safe(val)
        else:
            out[key] = val
    return out
```

## 3 · ConfigFile

`ConfigFile` stores data in INI-style sections and keys, and can preserve
 comments when round-tripping files. It is the natural choice for user-facing settings
 that a technically inclined player might want to edit manually.

### 3.1 · Reading and writing

```gdscript
const SETTINGS_PATH := "user://settings.cfg"

## Save settings
func save_settings(settings: Dictionary) -> void:
    var cfg := ConfigFile.new()

    cfg.set_value("video",   "fullscreen",   settings.get("fullscreen",   false))
    cfg.set_value("video",   "resolution",   settings.get("resolution",   "1920x1080"))
    cfg.set_value("video",   "vsync",        settings.get("vsync",        true))
    cfg.set_value("audio",   "master_vol",   settings.get("master_vol",   1.0))
    cfg.set_value("audio",   "music_vol",    settings.get("music_vol",    0.8))
    cfg.set_value("audio",   "sfx_vol",      settings.get("sfx_vol",      1.0))
    cfg.set_value("gameplay","difficulty",   settings.get("difficulty",   "normal"))
    cfg.set_value("gameplay","show_hints",   settings.get("show_hints",   true))

    var err := cfg.save(SETTINGS_PATH)
    if err != OK:
        push_error("Could not save settings: %s" % error_string(err))

## Load settings (with safe defaults)
func load_settings() -> Dictionary:
    var cfg := ConfigFile.new()
    var err := cfg.load(SETTINGS_PATH)
    if err != OK:
        return {}   # file absent or corrupt — caller uses defaults

    return {
        "fullscreen":  cfg.get_value("video",   "fullscreen",   false),
        "resolution":  cfg.get_value("video",   "resolution",   "1920x1080"),
        "vsync":       cfg.get_value("video",   "vsync",        true),
        "master_vol":  cfg.get_value("audio",   "master_vol",   1.0),
        "music_vol":   cfg.get_value("audio",   "music_vol",    0.8),
        "sfx_vol":     cfg.get_value("audio",   "sfx_vol",      1.0),
        "difficulty":  cfg.get_value("gameplay","difficulty",   "normal"),
        "show_hints":  cfg.get_value("gameplay","show_hints",   true),
    }
```

The resulting file on disk looks like:

```
[video]

fullscreen=false
resolution="1920x1080"
vsync=true

[audio]

master_vol=1.0
music_vol=0.8
sfx_vol=1.0

[gameplay]

difficulty="normal"
show_hints=true
```

### 3.2 · Useful ConfigFile methods

| Method | Description |
| --- | --- |
| `load(path)` | Load from a file path. Returns `Error`. |
| `save(path)` | Write to a file path. Returns `Error`. |
| `get_value(section, key, default)` | Read a value; returns `default` if section/key absent. |
| `set_value(section, key, value)` | Set a value, creating the section/key if needed. |
| `has_section(section)` | Returns `true` if the section exists. |
| `has_section_key(section, key)` | Returns `true` if the key exists in the section. |
| `erase_section(section)` | Delete an entire section and all its keys. |
| `get_sections()` | Array of all section names. |
| `get_section_keys(section)` | Array of all key names in a section. |
| `encode_to_text()` | Return the config as a String without writing a file. |

:::callout-tip[Tip — Input rebinding with ConfigFile]
ConfigFile is ideal for storing custom key bindings.  Save the stringified

InputEvent

(use `var_to_str(event)`) under a

[bindings]

section, and restore it with

InputMap.action\_add\_event(action, str\_to\_var(cfg.get\_value(...)))

on
        startup.
:::

## 4 · ResourceSaver & ResourceLoader

Godot's Resource system lets you define typed data objects that can be inspected in
 the editor, edited via @export properties, and saved/loaded as `.tres`
 (text) or `.res` (binary) files. This is the most powerful persistence
 mechanism when your data maps naturally to Godot's type system.

### 4.1 · Defining a Custom Resource

```gdscript
# player_save_data.gd
class_name PlayerSaveData
extends Resource

@export var player_name:   String  = "Hero"
@export var level:         int     = 1
@export var experience:    int     = 0
@export var max_hp:        int     = 100
@export var current_hp:    int     = 100
@export var gold:          int     = 0
@export var position_x:    float   = 0.0
@export var position_y:    float   = 0.0
@export var inventory:     Array[String] = []
@export var completed_quests: Array[String] = []
@export var play_time_secs: float  = 0.0

## Convenience constructor
static func create(name: String) -> PlayerSaveData:
    var data        := PlayerSaveData.new()
    data.player_name = name
    return data
```

Because every property is `@export`, you can inspect and edit a
 `.tres` file directly in the editor — extremely helpful for creating
 test save states without running the game.

### 4.2 · Saving and loading .tres files

```gdscript
const SAVE_DIR := "user://saves/"

## Save a PlayerSaveData resource to disk
func save_resource(data: PlayerSaveData, slot: int) -> bool:
    # Ensure directory exists
    if not DirAccess.dir_exists_absolute(
            ProjectSettings.globalize_path(SAVE_DIR)):
        DirAccess.make_dir_recursive_absolute(
            ProjectSettings.globalize_path(SAVE_DIR))

    var path := SAVE_DIR + "slot_%02d.tres" % slot
    var err  := ResourceSaver.save(data, path)
    if err != OK:
        push_error("ResourceSaver failed for slot %d: %s" % [slot, error_string(err)])
        return false
    return true

## Load a PlayerSaveData resource from a save slot
func load_resource(slot: int) -> PlayerSaveData:
    var path := SAVE_DIR + "slot_%02d.tres" % slot
    if not ResourceLoader.exists(path, "PlayerSaveData"):
        return null
    var res := ResourceLoader.load(path, "PlayerSaveData") as PlayerSaveData
    if res == null:
        push_error("Resource at '%s' could not be cast to PlayerSaveData." % path)
        return null
    return res
```

:::callout-warning[Warning — .tres files are human-readable]
Text resource files (

.tres

) contain plain GDScript expressions and are
        trivially editable.  Players can cheat by editing them.  If cheat-prevention matters,
        use binary

.res

format (pass

ResourceSaver.FLAG\_COMPRESS

to `ResourceSaver.save()`) or
        serialise to JSON and encrypt with `FileAccess.open_encrypted_with_pass()`.
:::

### 4.3 · ResourceSaver flags

| Flag | Effect |
| --- | --- |
| `FLAG_NONE` | Default — no special behaviour. |
| `FLAG_RELATIVE_PATHS` | Store resource sub-paths relative to the save location. |
| `FLAG_BUNDLE_RESOURCES` | Inline all sub-resources rather than storing as external references. |
| `FLAG_COMPRESS` | Compress the file (produces `.res` binary output). |
| `FLAG_REPLACE_SUBRESOURCE_PATHS` | Update paths of embedded sub-resources to the new file location. |

## 5 · Save Slots, Versioning & Autosave

### 5.1 · The save-slot pattern

Most games offer three save slots. Each slot has a **metadata file**
 (fast to read — shown in the load screen) and a **full data file**
 (loaded only when the player actually starts that slot).

```gdscript
# SaveManager.gd  (Autoload)
extends Node

const MAX_SLOTS  := 3
const SAVE_DIR   := "user://saves/"
const SAVE_VER   := 2   # bump this when the schema changes

## Lightweight metadata shown in the "Load Game" screen
func get_slot_info(slot: int) -> Dictionary:
    var path := SAVE_DIR + "slot_%02d_meta.json" % slot
    if not FileAccess.file_exists(path):
        return {}
    var data := _load_json(path)
    return data if data is Dictionary else {}

## Check if a slot has saved data
func slot_exists(slot: int) -> bool:
    return FileAccess.file_exists(SAVE_DIR + "slot_%02d.json" % slot)

## Save the current game state to a slot
func save_slot(slot: int, state: Dictionary) -> bool:
    _ensure_save_dir()
    state["__version"] = SAVE_VER
    state["__timestamp"] = Time.get_unix_time_from_system()

    # Full data file
    if not _save_json(SAVE_DIR + "slot_%02d.json" % slot, state):
        return false

    # Metadata file (subset for the load screen)
    var meta := {
        "player_name": state.get("player_name", "Hero"),
        "level":       state.get("level", 1),
        "play_time":   state.get("play_time_secs", 0.0),
        "location":    state.get("current_scene", ""),
        "timestamp":   state["__timestamp"],
    }
    return _save_json(SAVE_DIR + "slot_%02d_meta.json" % slot, meta)

## Load a save slot, migrating old schemas as needed
func load_slot(slot: int) -> Dictionary:
    var path := SAVE_DIR + "slot_%02d.json" % slot
    if not FileAccess.file_exists(path):
        push_warning("SaveManager: slot %d does not exist." % slot)
        return {}
    var data := _load_json(path)
    return _migrate(data)

## Delete a save slot
func delete_slot(slot: int) -> void:
    for suffix in ["_meta.json", ".json"]:
        var path := SAVE_DIR + "slot_%02d%s" % [slot, suffix]
        if FileAccess.file_exists(path):
            DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

# ── Internal helpers ──────────────────────────────────────────────────
func _ensure_save_dir() -> void:
    if not DirAccess.dir_exists_absolute(
            ProjectSettings.globalize_path(SAVE_DIR)):
        DirAccess.make_dir_recursive_absolute(
            ProjectSettings.globalize_path(SAVE_DIR))

func _save_json(path: String, data: Dictionary) -> bool:
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        push_error("SaveManager: cannot write '%s'." % path)
        return false
    file.store_string(JSON.stringify(data, "\t"))
    return true

func _load_json(path: String) -> Variant:
    var text := FileAccess.get_file_as_string(path)
    if text.is_empty():
        return {}
    var result := JSON.parse_string(text)
    return result if result != null else {}
```

### 5.2 · Schema versioning & migration

Save files will outlive game updates. When you add or rename fields, old save files
 will be missing those fields or have stale keys. A migration function handles this
 gracefully by reading the `__version` field and applying incremental
 upgrades:

```gdscript
func _migrate(data: Dictionary) -> Dictionary:
    var ver: int = data.get("__version", 1)

    # ── v1 → v2: renamed "health" to "current_hp", added "max_hp" ────
    if ver < 2:
        if data.has("health"):
            data["current_hp"] = data["health"]
            data.erase("health")
        if not data.has("max_hp"):
            data["max_hp"] = 100

    # ── v2 → v3: "inventory" changed from Array to Dict with counts ──
    if ver < 3:
        if data.has("inventory") and data["inventory"] is Array:
            var new_inv := {}
            for item_id in data["inventory"]:
                new_inv[item_id] = new_inv.get(item_id, 0) + 1
            data["inventory"] = new_inv

    data["__version"] = SAVE_VER   # update to current version
    return data
```

:::callout-key[Key Concept — Migration strategy]
Each

if ver < N

block handles one schema transition.  They are applied
        sequentially, so a version-1 file will pass through

both

the v1→v2 and v2→v3
        blocks and arrive at the current schema.  Never delete old migration blocks — a player
        who has not updated their game in two versions still needs them.
:::

### 5.3 · Autosave

Autosave protects players from losing progress to crashes or accidental exits. The
 typical approach is a dedicated "autosave" slot that is written on a timer and at
 checkpoints, never on the "Load" screen's visible list but always checked first on
 launch.

```gdscript
# In your main game scene or a GameSession autoload
extends Node

const AUTOSAVE_SLOT  := 0          # slot 0 reserved for autosave
const AUTOSAVE_INTERVAL := 120.0   # seconds between timer-based autosaves

var _autosave_timer: float = 0.0

func _process(delta: float) -> void:
    _autosave_timer += delta
    if _autosave_timer >= AUTOSAVE_INTERVAL:
        _autosave_timer = 0.0
        _do_autosave()

func _do_autosave() -> void:
    var state := _collect_game_state()
    state["is_autosave"] = true
    SaveManager.save_slot(AUTOSAVE_SLOT, state)
    # Optionally show a brief "Autosaved" indicator in the HUD
    $HUD.show_autosave_indicator()

## Call this at checkpoints (entering a new room, defeating a boss, etc.)
func checkpoint_save() -> void:
    _autosave_timer = 0.0   # reset timer so next auto isn't right after
    _do_autosave()

## On game start: offer to resume from autosave if one is newer than the manual save
func check_resume_from_autosave() -> bool:
    if not SaveManager.slot_exists(AUTOSAVE_SLOT):
        return false
    var auto_meta := SaveManager.get_slot_info(AUTOSAVE_SLOT)
    return auto_meta.get("is_autosave", false)
```

:::callout-tip[Tip — Atomic writes]
To prevent a crash mid-write from corrupting a save file, write to a temporary file
        first, then rename it over the real save file.  Unfortunately Godot's

DirAccess

does not have a native atomic rename, but you can approximate it:

```gdscript
func _safe_write(final_path: String, content: String) -> bool:
    var tmp_path := final_path + ".tmp"
    var file := FileAccess.open(tmp_path, FileAccess.WRITE)
    if file == null: return false
    file.store_string(content)
    file = null  # close

    # Replace the real file with the temp file
    var dir := DirAccess.open("user://")
    if dir == null: return false
    if FileAccess.file_exists(final_path):
        dir.remove(final_path.get_file())
    return dir.rename(tmp_path.get_file(), final_path.get_file()) == OK
```
:::

## Summary

Godot offers four persistence mechanisms for different needs.
 `FileAccess` is the foundation — raw byte and text I/O into the
 `user://` directory. `JSON` adds human-readable structured
 serialisation; use the static helpers for simple cases and the `JSON`
 class instance for robust error reporting with untrusted input.
 `ConfigFile` provides INI-style section/key storage with sensible
 defaults on read, making it ideal for settings screens and key rebinding.
 Custom Resources backed by `ResourceSaver` give you editor-inspectable,
 typed save data at the cost of `.tres` files being human-editable.
 In production, layer these tools: use JSON for game state, ConfigFile for settings,
 maintain a `__version` field in every save, and apply incremental
 migration functions so players on old saves are never left behind. Back all writes
 with autosave every two minutes and at every meaningful checkpoint.

| Mechanism | Format | Best for | Preserves Godot types? |
| --- | --- | --- | --- |
| `FileAccess` text | Any (plain text) | Custom formats, logs | No |
| `FileAccess` binary | Binary | Compact data, replays | Via manual packing |
| `JSON` | `.json` | Game state, cross-platform data exchange | No (needs helpers) |
| `ConfigFile` | `.cfg` (INI) | Settings, key bindings | Yes (Variant) |
| `ResourceSaver` | `.tres` / `.res` | Typed data, editor-editable assets | Yes (native) |

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Round-trip JSON

Write two functions: `save_score(path, name, score, level)` and
 `load_score(path) -> Dictionary`. The saved file should contain
 a JSON object with keys `name`, `score`,
 `level`, and `timestamp` (Unix time as integer).
 On load, return an empty dictionary if the file does not exist.

::::solution[Solution]
```gdscript
func save_score(path: String, name: String, score: int, level: int) -> void:
    var data := {
        "name":      name,
        "score":     score,
        "level":     level,
        "timestamp": int(Time.get_unix_time_from_system()),
    }
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data, "\t"))

func load_score(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        return {}
    var text := FileAccess.get_file_as_string(path)
    var result := JSON.parse_string(text)
    return result if result is Dictionary else {}
```
::::
:::

:::problem{difficulty="easy"}
### P2 · Settings with ConfigFile

Build a `SettingsManager` script (not an autoload) with:

- `save(fullscreen: bool, vol: float, lang: String)` — writes to
 `user://settings.cfg`.
- `load() -> Dictionary` — returns a dictionary with safe defaults
 if the file is absent.

Confirm it works by calling save, quitting, and calling load — the saved values
 should match.

::::solution[Solution]
```gdscript
extends Node

const PATH := "user://settings.cfg"

func save(fullscreen: bool, vol: float, lang: String) -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("video",    "fullscreen", fullscreen)
    cfg.set_value("audio",    "volume",     vol)
    cfg.set_value("gameplay", "language",   lang)
    cfg.save(PATH)

func load() -> Dictionary:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return {"fullscreen": false, "volume": 1.0, "language": "en"}
    return {
        "fullscreen": cfg.get_value("video",    "fullscreen", false),
        "volume":     cfg.get_value("audio",    "volume",     1.0),
        "language":   cfg.get_value("gameplay", "language",   "en"),
    }
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Custom Resource save & load

Define a `HighScoreEntry` Resource with exported fields:
 `player_name: String`, `score: int`,
 `date: String`. Write two functions:

- `save_entry(entry: HighScoreEntry, path: String) -> bool`
- `load_entry(path: String) -> HighScoreEntry` (returns null if absent)

Test by creating an entry, saving it, and reloading it — confirm all three fields
 match.

::::solution[Solution]
```gdscript
# HighScoreEntry.gd
class_name HighScoreEntry
extends Resource

@export var player_name: String = ""
@export var score:       int    = 0
@export var date:        String = ""

# In any script or autoload:
func save_entry(entry: HighScoreEntry, path: String) -> bool:
    var err := ResourceSaver.save(entry, path)
    if err != OK:
        push_error("Could not save HighScoreEntry: %s" % error_string(err))
        return false
    return true

func load_entry(path: String) -> HighScoreEntry:
    if not ResourceLoader.exists(path, "HighScoreEntry"):
        return null
    return ResourceLoader.load(path, "HighScoreEntry") as HighScoreEntry

# Test:
# func _ready() -> void:
#     var e := HighScoreEntry.new()
#     e.player_name = "Jack"
#     e.score = 9999
#     e.date  = "2026-05-27"
#     save_entry(e, "user://test_score.tres")
#     var loaded := load_entry("user://test_score.tres")
#     print(loaded.player_name, loaded.score, loaded.date)
```
::::
:::

:::problem{difficulty="standard"}
### P4 · Save slot listing UI

Build a simple "Load Game" scene with three VBoxContainers — one per slot.
 Each slot displays: player name, level, formatted play time (HH:MM), and the
 save timestamp formatted as a date string. An empty slot shows "Empty".
 Use the `SaveManager` from Section 5 (or a simplified version) to
 read the metadata. Include a "Delete" button per slot that calls
 `SaveManager.delete_slot(slot)` and refreshes the UI.

::::solution[Solution]
```gdscript
# LoadScreen.gd
extends Control

@onready var slots: Array[Control] = [
    $SlotContainer/Slot0,
    $SlotContainer/Slot1,
    $SlotContainer/Slot2,
]

func _ready() -> void:
    _refresh()

func _refresh() -> void:
    for i in 3:
        _update_slot(i)

func _update_slot(slot: int) -> void:
    var container := slots[slot]
    var meta      := SaveManager.get_slot_info(slot + 1)  # slots 1-3

    if meta.is_empty():
        container.get_node("NameLabel").text  = "Empty"
        container.get_node("InfoLabel").text  = ""
        container.get_node("DeleteBtn").hide()
        container.get_node("LoadBtn").disabled = true
        return

    var secs: float = meta.get("play_time", 0.0)
    var hh := int(secs) / 3600
    var mm := (int(secs) % 3600) / 60
    var ts := int(meta.get("timestamp", 0))
    var dt := Time.get_datetime_dict_from_unix_time(ts)

    container.get_node("NameLabel").text = "%s  Lv.%d" % [
        meta.get("player_name", "?"), meta.get("level", 1)
    ]
    container.get_node("InfoLabel").text = "%02d:%02d  ·  %04d-%02d-%02d" % [
        hh, mm, dt["year"], dt["month"], dt["day"]
    ]
    container.get_node("DeleteBtn").show()
    container.get_node("LoadBtn").disabled = false

func _on_delete_pressed(slot: int) -> void:
    SaveManager.delete_slot(slot + 1)
    _refresh()
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Schema migration

Given a version-1 save dictionary:

```gdscript
var old_save := {
    "__version": 1,
    "health": 80,
    "coins": 150,
    "items": ["sword", "shield", "sword"],
}
```

Write a `migrate(data: Dictionary) -> Dictionary` function that
 migrates it to version 3 by applying:

- **v1 → v2**: rename `health` to `current_hp`;
 add `max_hp = 100`.
- **v2 → v3**: convert `items` from an Array of item IDs
 to a Dictionary of `item_id → count`.

Print the result and confirm it matches the expected v3 format.

::::solution[Solution]
```gdscript
const SAVE_VER := 3

func migrate(data: Dictionary) -> Dictionary:
    var ver: int = data.get("__version", 1)

    if ver < 2:
        if data.has("health"):
            data["current_hp"] = data["health"]
            data.erase("health")
        if not data.has("max_hp"):
            data["max_hp"] = 100

    if ver < 3:
        if data.has("items") and data["items"] is Array:
            var counts := {}
            for item: String in data["items"]:
                counts[item] = counts.get(item, 0) + 1
            data["items"] = counts

    data["__version"] = SAVE_VER
    return data

func _ready() -> void:
    var old := {"__version": 1, "health": 80, "coins": 150,
                "items": ["sword", "shield", "sword"]}
    var new_data := migrate(old)
    print(new_data)
    # Expected: {__version:3, current_hp:80, max_hp:100,
    #            coins:150, items:{sword:2, shield:1}}
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full SaveManager autoload with encryption

Build a production-quality `SaveManager` autoload that:

1. Supports 3 named save slots (1–3) plus slot 0 (autosave).
2. Serialises to JSON using the type-safe helpers from Section 2.3
 (preserving Vector2 position).
3. Writes files using **atomic writes** (write to `.tmp`
 then rename).
4. Encrypts the save file using
 `FileAccess.open_encrypted_with_pass()` with a constant passphrase
 embedded in the code.
5. Reads the file back by opening with
 `FileAccess.open_encrypted_with_pass()` using the same passphrase.
6. Applies `_migrate()` on every load.
7. Exposes `save_slot(slot, state)`, `load_slot(slot) -> Dictionary`,
 `slot_exists(slot) -> bool`, and `delete_slot(slot)`.

::::solution[Solution]
```gdscript
# SaveManager.gd  (Autoload)
extends Node

const MAX_SLOTS  := 3
const SAVE_DIR   := "user://saves/"
const SAVE_VER   := 2
const _PASS      := "MyGameSaveKey_v1"   # obfuscated in a real project

func _ready() -> void:
    _ensure_dir()

# ── Public API ────────────────────────────────────────────────────────

func slot_exists(slot: int) -> bool:
    return FileAccess.file_exists(_slot_path(slot))

func save_slot(slot: int, state: Dictionary) -> bool:
    _ensure_dir()
    state["__version"]  = SAVE_VER
    state["__timestamp"] = int(Time.get_unix_time_from_system())
    var json := JSON.stringify(to_json_safe(state), "\t")
    return _encrypted_write(_slot_path(slot), json)

func load_slot(slot: int) -> Dictionary:
    if not slot_exists(slot):
        return {}
    var text := _encrypted_read(_slot_path(slot))
    if text.is_empty():
        return {}
    var raw := JSON.parse_string(text)
    if raw == null or raw is not Dictionary:
        push_error("SaveManager: corrupt data in slot %d." % slot)
        return {}
    return _migrate(from_json_safe(raw as Dictionary))

func delete_slot(slot: int) -> void:
    var path := _slot_path(slot)
    if FileAccess.file_exists(path):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

# ── Internal ──────────────────────────────────────────────────────────

func _slot_path(slot: int) -> String:
    return SAVE_DIR + "slot_%02d.sav" % slot

func _ensure_dir() -> void:
    var abs := ProjectSettings.globalize_path(SAVE_DIR)
    if not DirAccess.dir_exists_absolute(abs):
        DirAccess.make_dir_recursive_absolute(abs)

func _encrypted_write(final_path: String, content: String) -> bool:
    var tmp := final_path + ".tmp"
    var file := FileAccess.open_encrypted_with_pass(tmp, FileAccess.WRITE, _PASS)
    if file == null:
        push_error("SaveManager: cannot write '%s'." % tmp)
        return false
    file.store_string(content)
    file = null  # close

    # Atomic rename
    var dir := DirAccess.open(SAVE_DIR)
    if dir == null: return false
    var fname := final_path.get_file()
    var tname := tmp.get_file()
    if FileAccess.file_exists(final_path):
        dir.remove(fname)
    return dir.rename(tname, fname) == OK

func _encrypted_read(path: String) -> String:
    var file := FileAccess.open_encrypted_with_pass(path, FileAccess.READ, _PASS)
    if file == null:
        push_error("SaveManager: cannot read '%s'." % path)
        return ""
    return file.get_as_text()

func _migrate(data: Dictionary) -> Dictionary:
    var ver: int = data.get("__version", 1)
    if ver < 2:
        if data.has("health"):
            data["current_hp"] = data["health"]
            data.erase("health")
        if not data.has("max_hp"):
            data["max_hp"] = 100
    data["__version"] = SAVE_VER
    return data

# ── Type helpers (from Section 2.3) ───────────────────────────────────

static func to_json_safe(data: Dictionary) -> Dictionary:
    var out := {}
    for key in data:
        var val: Variant = data[key]
        if val is Vector2:
            out[key] = {"__type": "Vector2", "x": val.x, "y": val.y}
        elif val is Color:
            out[key] = {"__type": "Color", "r": val.r, "g": val.g,
                        "b": val.b, "a": val.a}
        elif val is Dictionary:
            out[key] = to_json_safe(val)
        else:
            out[key] = val
    return out

static func from_json_safe(data: Dictionary) -> Dictionary:
    var out := {}
    for key in data:
        var val: Variant = data[key]
        if val is Dictionary and val.has("__type"):
            match val["__type"]:
                "Vector2": out[key] = Vector2(val["x"], val["y"])
                "Color":   out[key] = Color(val["r"], val["g"], val["b"], val["a"])
        elif val is Dictionary:
            out[key] = from_json_safe(val)
        else:
            out[key] = val
    return out
```
::::
:::
