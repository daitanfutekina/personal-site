---
title: "Input & Action Remapping"
source: "markdown"
---

Part IV · Chapter 35

# Input & Action Remapping

Prerequisite: Ch 4 (GDScript), Ch 6 (2D basics) · est. 70 min

## Overview

Input handling in Godot is built on two complementary systems. The
 **InputMap** is a named-action layer: instead of checking
 "is the Space key pressed?" you ask "is the `jump` action
 pressed?" — decoupling game logic from physical keys and making
 remapping trivially easy. The **Input** singleton and
 **\_input()** / **\_unhandled\_input()** callbacks
 sit below this layer and give you access to raw device events when you
 need them.

This chapter covers:

- Defining actions in the InputMap and querying them from GDScript
- The full InputEvent type hierarchy (keyboard, mouse, joypad, touch)
- Runtime rebinding — adding and removing events per action, listening
 for a new key/button press, and persisting bindings to
 `ConfigFile`
- Analogue axis input, deadzones, and `get_vector()`
- Input buffering for tight-feel jump windows
- Context-sensitive input maps that switch between UI and gameplay

## 1 · InputMap & Actions

### 1.1 · Default action setup

Actions are defined in *Project Settings → Input Map*. Each
 action has a name (a `StringName`) and one or more bound
 `InputEvent`s. An action is "pressed" if *any* of its
 bound events is active.

A typical action list for a 2D platformer:

| Action name | Default bindings |
| --- | --- |
| `move_left` | A, ←, Gamepad D-pad left |
| `move_right` | D, →, Gamepad D-pad right |
| `jump` | Space, Gamepad Button A (South) |
| `attack` | Z, Gamepad Button X (West) |
| `interact` | E, Gamepad Button B (East) |
| `pause` | Escape, Gamepad Start |
| `ui_accept` | Enter, Space (built-in) |

### 1.2 · Input polling API

Call these from `_process()` or `_physics_process()`
 to query the current state of actions and devices:

| Method | Returns | Description |
| --- | --- | --- |
| `Input.is_action_pressed(action)` | `bool` | True while held down |
| `Input.is_action_just_pressed(action)` | `bool` | True only on the first frame it was pressed |
| `Input.is_action_just_released(action)` | `bool` | True only on the first frame it was released |
| `Input.get_action_strength(action)` | `float` 0–1 | Analogue value (1.0 for digital, axis value for gamepad) |
| `Input.get_axis(neg_action, pos_action)` | `float` −1–1 | pos\_strength − neg\_strength; ideal for 1D movement |
| `Input.get_vector(neg_x, pos_x, neg_y, pos_y)` | `Vector2` | Normalised 2D movement vector with deadzone applied |
| `get_viewport().get_mouse_position()` | `Vector2` | Mouse position in the window. `Input` has no mouse-position method — ask the viewport, or a CanvasItem for `get_global_mouse_position()` in world coordinates |
| `Input.is_joy_known(device)` | `bool` | True if device index is a connected gamepad |

```gdscript
## Standard 2D platformer movement in _physics_process():
func _physics_process(delta: float) -> void:
    # Horizontal: −1 left, +1 right
    var dir: float = Input.get_axis("move_left", "move_right")
    velocity.x = dir * SPEED

    # Jump — only on the exact frame pressed
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_VELOCITY

    move_and_slide()
```

### 1.3 · Event-driven API

Override `_input(event)` or `_unhandled_input(event)`
 to receive events as they arrive, rather than polling.
 `_unhandled_input` is called only if no `Control` node
 consumed the event first — the right choice for gameplay input that should
 not fire when the UI is focused.

```gdscript
func _unhandled_input(event: InputEvent) -> void:
    # Action-level check — works for any bound device.
    if event.is_action_pressed("attack"):
        _begin_attack()
        get_viewport().set_input_as_handled()

    # Raw key check — use sparingly; prefer actions.
    if event is InputEventKey and event.keycode == KEY_F5 and event.pressed:
        _quick_save()
```

:::callout-key[Key Concept — \_input vs \_unhandled\_input]
\_input()

fires for

every

event, even those already
        consumed by a

Button

or

LineEdit

.  Use it only
        for global shortcuts (screenshot, debug toggle) that must always fire.
        For player gameplay input, always use

\_unhandled\_input()

so
        that typing in a chat box does not also trigger attacks.
:::

## 2 · InputEvent Types

All input events inherit from `InputEvent`. The most important
 subclasses:

InputEvent Class Hierarchy

InputEvent

InputEventKey

keycode, unicode, echo

InputEventMouse

Button

InputEventMouse

Motion / relative, velocity

InputEventJoypad

Button / Motion (axis)

InputEventScreen

Touch / Drag

InputEventAction

virtual (from InputMap)

Use  event is InputEventKey  /  InputEventJoypadButton  etc. to identify the source device

All input arrives as an `InputEvent` subclass. The action-based API (`Input.is_action_pressed()`) abstracts over all hardware sources — one action can be triggered by a key, a button, or a touch event simultaneously.

### 2.1 · Keyboard events

```gdscript
func _input(event: InputEvent) -> void:
    if event is InputEventKey:
        var ke: InputEventKey = event
        # ke.keycode — physical key (KEY_SPACE, KEY_A, etc.)
        # ke.unicode — the character produced (locale-aware)
        # ke.pressed — true on down, false on up
        # ke.echo   — true for key-repeat events while held
        if ke.keycode == KEY_ESCAPE and ke.pressed and not ke.echo:
            get_tree().quit()
```

Key constants use the `KEY_*` prefix for physical keys
 (`KEY_A`, `KEY_SPACE`, `KEY_F1` …)
 and modifier checks:

```gdscript
if ke.keycode == KEY_S and ke.ctrl_pressed:
    _save_file()
```

### 2.2 · Mouse events

```gdscript
func _input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        var mb: InputEventMouseButton = event
        # mb.button_index — MOUSE_BUTTON_LEFT / RIGHT / MIDDLE / WHEEL_UP …
        # mb.pressed       — true on press, false on release
        # mb.double_click  — true on a double-click
        if mb.button_index == MOUSE_BUTTON_LEFT and mb.pressed:
            _fire_at(mb.global_position)

    if event is InputEventMouseMotion:
        var mm: InputEventMouseMotion = event
        # mm.relative — pixels moved since last event (ideal for FPS look)
        # mm.velocity — pixels/second
        _camera_yaw   += mm.relative.x * MOUSE_SENSITIVITY
        _camera_pitch += mm.relative.y * MOUSE_SENSITIVITY
```

### 2.3 · Joypad button and axis events

```gdscript
func _input(event: InputEvent) -> void:
    if event is InputEventJoypadButton:
        var jb: InputEventJoypadButton = event
        # jb.button_index — JOY_BUTTON_A, JOY_BUTTON_B, JOY_BUTTON_LEFT_SHOULDER …
        # jb.device        — which gamepad (0 = first)
        # jb.pressed
        pass

    if event is InputEventJoypadMotion:
        var jm: InputEventJoypadMotion = event
        # jm.axis  — JOY_AXIS_LEFT_X, JOY_AXIS_RIGHT_Y, JOY_AXIS_TRIGGER_LEFT …
        # jm.axis_value — −1.0 to 1.0
        pass
```

| Axis constant | Description |
| --- | --- |
| `JOY_AXIS_LEFT_X` | Left stick horizontal (−1 = left, +1 = right) |
| `JOY_AXIS_LEFT_Y` | Left stick vertical (−1 = up, +1 = down) |
| `JOY_AXIS_RIGHT_X` | Right stick horizontal |
| `JOY_AXIS_RIGHT_Y` | Right stick vertical |
| `JOY_AXIS_TRIGGER_LEFT` | Left trigger (0 = released, 1 = full press) |
| `JOY_AXIS_TRIGGER_RIGHT` | Right trigger |

### 2.4 · Touch events

```gdscript
func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var st: InputEventScreenTouch = event
        # st.index    — finger index (0 = first finger)
        # st.position — screen position
        # st.pressed  — true on touch-down, false on lift
        pass

    if event is InputEventScreenDrag:
        var sd: InputEventScreenDrag = event
        # sd.index    — finger index
        # sd.position — current position
        # sd.relative — movement delta since last event
        pass
```

:::callout-tip[Tip — emulate touch with mouse]
Enable

Project Settings → Input Devices → Pointing → Emulate Touch
        From Mouse

during development so you can test touch logic on desktop
        without a physical touchscreen.
:::

## 3 · Runtime Remapping

### 3.1 · Adding and removing events from actions

The `InputMap` singleton provides full runtime access to every
 action's event list:

```gdscript
## Replace the "jump" action's keyboard binding with a new key.
func remap_jump(new_keycode: Key) -> void:
    # 1. Remove all existing keyboard events from "jump".
    var events: Array[InputEvent] = InputMap.action_get_events("jump")
    for ev in events:
        if ev is InputEventKey:
            InputMap.action_erase_event("jump", ev)

    # 2. Create the new binding.
    var new_event := InputEventKey.new()
    new_event.keycode = new_keycode
    InputMap.action_add_event("jump", new_event)

## Remove ALL events from an action (full reset before re-adding).
func clear_action(action: StringName) -> void:
    InputMap.action_erase_events(action)

## Add a gamepad button binding alongside existing ones.
func add_joypad_binding(action: StringName, button: JoyButton) -> void:
    var ev := InputEventJoypadButton.new()
    ev.button_index = button
    InputMap.action_add_event(action, ev)
```

### 3.2 · Rebind UI — listening for any input

A rebind UI must capture the *next* event the player presses, then
 assign it. The safest pattern is to use a dedicated "listening" mode:

```gdscript
## res://ui/rebind_button.gd
class_name RebindButton
extends Button

signal rebound(action: StringName, event: InputEvent)

var _action:    StringName = ""
var _listening: bool       = false

func start_listening(action: StringName) -> void:
    _action    = action
    _listening = true
    text       = "Press any key…"
    set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
    if not _listening:
        return

    # Ignore mouse motion (too easy to accidentally trigger).
    if event is InputEventMouseMotion:
        return
    # Ignore modifier-only presses.
    if event is InputEventKey and event.keycode in [
            KEY_CTRL, KEY_SHIFT, KEY_ALT, KEY_META]:
        return
    # Ignore non-press events.
    if not event.is_pressed():
        return

    _apply_binding(event)
    get_viewport().set_input_as_handled()

func _apply_binding(event: InputEvent) -> void:
    _listening = false
    # Replace all same-type events for this action.
    var existing: Array[InputEvent] = InputMap.action_get_events(_action)
    for ev in existing:
        if ev.get_class() == event.get_class():
            InputMap.action_erase_event(_action, ev)
    InputMap.action_add_event(_action, event)
    text = _event_to_display_string(event)
    rebound.emit(_action, event)
    set_process_unhandled_input(false)

## Convert an InputEvent to a human-readable string.
static func _event_to_display_string(ev: InputEvent) -> String:
    if ev is InputEventKey:
        return OS.get_keycode_string(ev.keycode)
    if ev is InputEventJoypadButton:
        return "Btn %d" % ev.button_index
    if ev is InputEventJoypadMotion:
        var dir: String = "+" if ev.axis_value > 0 else "-"
        return "Axis %d%s" % [ev.axis, dir]
    if ev is InputEventMouseButton:
        return "Mouse %d" % ev.button_index
    return ev.as_text()
```

### 3.3 · Persisting bindings

Serialize the entire InputMap to `ConfigFile` so bindings
 survive restarts:

```gdscript
## res://autoloads/input_settings.gd
extends Node

const CFG_PATH := "user://settings.cfg"
const SECTION  := "bindings"

## The actions to save/load (omit built-in ui_* actions).
const GAME_ACTIONS: Array[StringName] = [
    &"move_left", &"move_right", &"jump", &"attack", &"interact", &"pause"
]

func save_bindings() -> void:
    var cfg := ConfigFile.new()
    cfg.load(CFG_PATH)
    for action in GAME_ACTIONS:
        var events: Array[InputEvent] = InputMap.action_get_events(action)
        var serialised: Array = []
        for ev in events:
            serialised.append(_serialise_event(ev))
        cfg.set_value(SECTION, str(action), serialised)
    cfg.save(CFG_PATH)

func load_bindings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(CFG_PATH) != OK:
        return
    for action in GAME_ACTIONS:
        if not cfg.has_section_key(SECTION, str(action)):
            continue
        InputMap.action_erase_events(action)
        for ev_dict in cfg.get_value(SECTION, str(action)):
            var ev: InputEvent = _deserialise_event(ev_dict)
            if ev != null:
                InputMap.action_add_event(action, ev)

func reset_to_defaults() -> void:
    InputMap.load_from_project_settings()

# ─── Serialisation helpers ────────────────────────────────────────────────────
func _serialise_event(ev: InputEvent) -> Dictionary:
    if ev is InputEventKey:
        return { "type": "key", "keycode": ev.keycode,
                 "physical": ev.physical_keycode }
    if ev is InputEventJoypadButton:
        return { "type": "joy_btn", "button": ev.button_index,
                 "device": ev.device }
    if ev is InputEventJoypadMotion:
        return { "type": "joy_axis", "axis": ev.axis,
                 "value": ev.axis_value, "device": ev.device }
    if ev is InputEventMouseButton:
        return { "type": "mouse_btn", "button": ev.button_index }
    return {}

func _deserialise_event(d: Dictionary) -> InputEvent:
    match d.get("type", ""):
        "key":
            var ev := InputEventKey.new()
            ev.keycode          = d["keycode"]
            ev.physical_keycode = d.get("physical", 0)
            return ev
        "joy_btn":
            var ev := InputEventJoypadButton.new()
            ev.button_index = d["button"]
            ev.device       = d.get("device", 0)
            return ev
        "joy_axis":
            var ev := InputEventJoypadMotion.new()
            ev.axis       = d["axis"]
            ev.axis_value = d["value"]
            ev.device     = d.get("device", 0)
            return ev
        "mouse_btn":
            var ev := InputEventMouseButton.new()
            ev.button_index = d["button"]
            return ev
    return null
```

## 4 · Analogue Input & Deadzones

### 4.1 · get\_axis and get\_vector

`Input.get_axis(neg, pos)` returns a float in [−1, 1],
 automatically combining keyboard (digital 0/1) and gamepad axis
 (analogue) bindings for the same actions. `get_vector()`
 extends this to 2D and normalises the result so diagonal movement is
 not faster than cardinal movement:

```gdscript
## Both keyboard and gamepad work with the same code:
var move: Vector2 = Input.get_vector(
    "move_left", "move_right",
    "move_up",   "move_down"
)
# move.length() is clamped to 1.0 — no faster diagonals.
velocity = move * SPEED
```

`get_vector()` accepts a fifth optional `deadzone`
 parameter (default 0.5). When the stick is within this circle radius,
 the result is zero — preventing gamepad drift from causing unwanted
 movement.

### 4.2 · Custom deadzone processing

Godot's built-in deadzone applies a circular clip. Some games prefer
 a *scaled circular* deadzone that remaps the remaining range to
 0–1 for a smoother feel:

```gdscript
## Scaled circular deadzone — eliminates the "snap" at the edge of the dead zone.
## Returns a Vector2 with magnitude 0..1 after deadzone processing.
func apply_deadzone(raw: Vector2, dead: float = 0.15) -> Vector2:
    var magnitude: float = raw.length()
    if magnitude < dead:
        return Vector2.ZERO
    # Remap [dead, 1] → [0, 1]
    var scaled: float = (magnitude - dead) / (1.0 - dead)
    return raw.normalized() * clampf(scaled, 0.0, 1.0)

## Usage in _physics_process:
var raw_stick: Vector2 = Vector2(
    Input.get_joy_axis(0, JOY_AXIS_LEFT_X),
    Input.get_joy_axis(0, JOY_AXIS_LEFT_Y)
)
var stick: Vector2 = apply_deadzone(raw_stick, 0.15)
velocity = stick * SPEED
```

:::callout-intuition[Intuition — why scaled deadzone feels better]
With a hard clip deadzone, there's a step from 0 to ~0.15 strength the
        moment the stick exits the dead zone — noticeable in precise aiming.
        With the scaled version, strength grows continuously from 0 at the edge
        of the dead zone to 1 at full deflection, matching physical expectations.
:::

## 5 · Input Buffering

Input buffering records a player's action for a short window even when
 the game cannot process it immediately. The most common example:
 a player presses "jump" 80 ms before landing — without buffering, the
 press is ignored; with buffering, the jump fires as soon as the player
 touches the ground.

```gdscript
## res://player/player.gd — jump buffer implementation
const JUMP_BUFFER_TIME := 0.12   # seconds to remember a jump press

var _jump_buffer: float = 0.0    # counts down each frame

func _physics_process(delta: float) -> void:
    # Decrease buffer timer.
    if _jump_buffer > 0.0:
        _jump_buffer -= delta

    # Record a new jump request.
    if Input.is_action_just_pressed("jump"):
        _jump_buffer = JUMP_BUFFER_TIME

    # Consume the buffer when we can actually jump.
    if _jump_buffer > 0.0 and is_on_floor():
        velocity.y   = JUMP_VELOCITY
        _jump_buffer = 0.0   # consume

    move_and_slide()
```

The same pattern applies to any action that needs a brief forgiveness
 window: combos, dashes, attacks. Keep the buffer time short (100–200 ms)
 — too long feels like the game is playing itself.

:::callout-connect[Connection — coyote time]
Input buffering pairs with

coyote time

(covered in Chapter 27):
        the player can jump a few frames after walking off a ledge, and the jump
        buffer fires even if pressed slightly before landing.  Together they make
        platformer controls feel precise and forgiving without being sloppy.
:::

## 6 · Context-Sensitive Input

Many games need different input behaviour in different contexts: the player
 moves in gameplay, but the same WASD keys scroll a menu in the
 pause screen. Two clean approaches:

**Approach A — Process mode gating.** Set the gameplay node's
 `process_mode` to `PROCESS_MODE_PAUSABLE` and pause
 the tree when the menu opens. The player node's
 `_physics_process` and `_unhandled_input` stop
 running automatically; the menu (set to `PROCESS_MODE_ALWAYS`)
 handles input alone. This is the pattern from Chapter 25.

**Approach B — InputMap context swap.** Maintain two complete
 InputMap configurations (gameplay and UI) and swap the entire map at
 context transitions:

```gdscript
## res://autoloads/input_context.gd
extends Node

## Snapshot of the current InputMap state.
func _snapshot() -> Dictionary:
    var snap: Dictionary = {}
    for action in InputMap.get_actions():
        snap[action] = InputMap.action_get_events(action).duplicate()
    return snap

## Saved snapshots per context name.
var _snapshots: Dictionary = {}

func save_context(name: StringName) -> void:
    _snapshots[name] = _snapshot()

func restore_context(name: StringName) -> void:
    if not _snapshots.has(name):
        push_error("InputContext: no snapshot named '%s'" % name)
        return
    var snap: Dictionary = _snapshots[name]
    for action in snap:
        InputMap.action_erase_events(action)
        for ev in snap[action]:
            InputMap.action_add_event(action, ev)
```

:::callout-tip[Tip — built-in ui\_ actions]
Godot's built-in

ui\_accept

, `ui_cancel`, `ui_left`, etc. are processed separately by the

Control

focus system and are not affected by your custom
        InputMap changes.  This means menus always respond to arrow keys and
        Enter even when you remap everything else.
:::

## Summary

The `InputMap` decouples game logic from physical hardware —
 check actions by name, not keycodes, and remapping is automatic.
 `Input.is_action_just_pressed()` for frame-accurate one-shot
 checks; `get_axis()` and `get_vector()` for smooth
 analogue movement that works equally on keyboard and gamepad.
 `_unhandled_input()` fires only when the UI has not consumed
 the event, preventing accidental gameplay input while typing.
 Runtime remapping uses `InputMap.action_erase_event()` and
 `action_add_event()`; a "listening" mode captures the next
 pressed event. Bindings are serialised as dictionaries and persisted to
 `ConfigFile`. Gamepad axes benefit from a scaled circular
 deadzone that eliminates drift and avoids snap artefacts.
 Input buffering records action presses for a short window so players
 can act slightly before the game state permits it. Context-sensitive
 input is cleanly handled by either pausing the gameplay tree or
 snapshotting and restoring InputMap configurations.

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Display current binding.**
 Write a function `get_action_display_string(action: StringName) -> String`
 that returns a human-readable string showing the first keyboard binding
 for that action (e.g. `"Space"` for `"jump"`),
 or `"[unbound]"` if no keyboard event is bound.

::::solution[Solution]
```gdscript
func get_action_display_string(action: StringName) -> String:
    for ev in InputMap.action_get_events(action):
        if ev is InputEventKey:
            return OS.get_keycode_string(ev.keycode)
    return "[unbound]"
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Conflict detection.**
 Write `find_conflicting_action(new_event: InputEvent) -> StringName`
 that checks all game actions and returns the name of any action that
 already uses `new_event`, or an empty `StringName`
 if no conflict exists. Use `InputMap.event_is_action()`.

::::solution[Solution]
```gdscript
const GAME_ACTIONS: Array[StringName] = [
    &"move_left", &"move_right", &"jump", &"attack", &"interact", &"pause"
]

func find_conflicting_action(new_event: InputEvent) -> StringName:
    for action in GAME_ACTIONS:
        if InputMap.event_is_action(new_event, action):
            return action
    return &""
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Dash buffer.**
 Implement a dash mechanic with a 0.15-second input buffer and a
 0.8-second cooldown. The player presses `"dash"`; if the
 cooldown has not expired but the press falls within the buffer window,
 the dash fires as soon as the cooldown ends. Write the
 `_physics_process` logic only; assume
 `_perform_dash()` already exists.

::::solution[Solution]
```gdscript
const DASH_BUFFER_TIME  := 0.15
const DASH_COOLDOWN     := 0.8

var _dash_buffer:   float = 0.0
var _dash_cooldown: float = 0.0

func _physics_process(delta: float) -> void:
    _dash_buffer   = maxf(_dash_buffer   - delta, 0.0)
    _dash_cooldown = maxf(_dash_cooldown - delta, 0.0)

    if Input.is_action_just_pressed("dash"):
        _dash_buffer = DASH_BUFFER_TIME

    if _dash_buffer > 0.0 and _dash_cooldown == 0.0:
        _perform_dash()
        _dash_buffer   = 0.0
        _dash_cooldown = DASH_COOLDOWN
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Mouse capture toggle.**
 Write a script for a first-person game that:
 captures the mouse (`Input.MOUSE_MODE_CAPTURED`) when the
 game starts; toggles to `MOUSE_MODE_VISIBLE` when
 Escape is pressed; and re-captures when the player
 left-clicks on the viewport. Also clamp the camera pitch to
 [−85°, 85°] using the `rotation_degrees` property of a
 `Camera3D` node.

::::solution[Solution]
```gdscript
@onready var _camera: Camera3D = $Camera3D

const SENS := 0.2
var _pitch: float = 0.0

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey:
        if event.keycode == KEY_ESCAPE and event.pressed:
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
            if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
                Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

    if event is InputEventMouseMotion:
        if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
            return
        rotation_degrees.y -= event.relative.x * SENS
        _pitch = clampf(_pitch - event.relative.y * SENS, -85.0, 85.0)
        _camera.rotation_degrees.x = _pitch
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Full rebind screen row.**
 Create a `RebindRow` scene with a `Label`
 (action display name), a `Button` (current key), and a
 `Button` labelled "Reset". Clicking the key button enters
 listening mode; the next key press replaces that action's keyboard
 binding and persists it. Clicking "Reset" restores the action to
 its project-settings default (use `ProjectSettings.get_setting()`
 on the action's input list) and persists. Show an orange tint on
 the binding button if it conflicts with another action.

::::solution[Solution]
```gdscript
## res://ui/rebind_row.gd
class_name RebindRow
extends HBoxContainer

@export var action: StringName = ""

@onready var _label:       Label  = $ActionLabel
@onready var _bind_btn:    Button = $BindButton
@onready var _reset_btn:   Button = $ResetButton

var _listening: bool = false

func _ready() -> void:
    _label.text = action.capitalize().replace("_", " ")
    _bind_btn.pressed.connect(_start_listening)
    _reset_btn.pressed.connect(_reset)
    _refresh_label()

func _refresh_label() -> void:
    var display: String = "[unbound]"
    for ev in InputMap.action_get_events(action):
        if ev is InputEventKey:
            display = OS.get_keycode_string(ev.keycode)
            break
    _bind_btn.text = display
    # Orange tint if conflicting with another action.
    var conflict := _find_conflict()
    _bind_btn.modulate = Color(1.0, 0.6, 0.2) if conflict != &"" and conflict != action \
                         else Color.WHITE

func _find_conflict() -> StringName:
    for ev in InputMap.action_get_events(action):
        if ev is InputEventKey:
            for other in InputMap.get_actions():
                if other == action: continue
                if InputMap.event_is_action(ev, other):
                    return other
    return &""

func _start_listening() -> void:
    _listening = true
    _bind_btn.text = "…"
    set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
    if not _listening: return
    if not event.is_pressed(): return
    if event is InputEventMouseMotion: return
    if event is InputEventKey and event.keycode in [KEY_CTRL, KEY_SHIFT, KEY_ALT]: return

    _listening = false
    set_process_unhandled_input(false)
    get_viewport().set_input_as_handled()

    InputMap.action_erase_events(action)
    InputMap.action_add_event(action, event)
    InputSettings.save_bindings()
    _refresh_label()

func _reset() -> void:
    InputMap.action_erase_events(action)
    # Reload defaults from project settings.
    var defaults = ProjectSettings.get_setting("input/%s" % action)
    if defaults is Array:
        for ev in defaults:
            InputMap.action_add_event(action, ev)
    InputSettings.save_bindings()
    _refresh_label()
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Multi-action combo detector.**
 Build a `ComboDetector` class (extends `Node`)
 that detects a sequence of actions pressed within a time window.
 Constructor takes an `Array[StringName]` of action names
 (the combo) and a `float` window in seconds. Emit a
 `combo_triggered` signal when the full sequence is completed
 within the window. Reset progress if the window expires or a wrong
 action is pressed. Example combo: `[&"attack", &"attack", &"jump"]`
 within 0.5 s.

::::solution[Solution]
```gdscript
class_name ComboDetector
extends Node

signal combo_triggered()

var _sequence: Array[StringName]
var _window:   float
var _progress: int   = 0
var _timer:    float = 0.0

func _init(sequence: Array[StringName], window: float = 0.5) -> void:
    _sequence = sequence
    _window   = window

func _process(delta: float) -> void:
    if _progress == 0:
        return
    _timer -= delta
    if _timer <= 0.0:
        _progress = 0   # window expired

func _unhandled_input(event: InputEvent) -> void:
    if not event.is_pressed() or event is InputEventMouseMotion:
        return
    if _sequence.is_empty():
        return

    var expected: StringName = _sequence[_progress]
    if event.is_action(expected):
        _progress += 1
        _timer     = _window
        if _progress >= _sequence.size():
            _progress = 0
            combo_triggered.emit()
    else:
        # Wrong action — check if it starts the combo.
        _progress = 1 if event.is_action(_sequence[0]) else 0
        _timer    = _window if _progress > 0 else 0.0
```
::::
:::
