---
title: "Godot 4 Node Reference"
source: "markdown"
---

Appendix B

# Godot 4 Node Reference

Quick-look cards for every major node type · Godot 4.x

## How to Use This Reference

This appendix is a fast-lookup companion, not a tutorial. Each node card shows the node's purpose, its most-used properties and signals, common gotchas, and a one-liner showing the typical GDScript usage pattern. For deeper coverage follow the chapter links in the card footers.

:::callout-tip[Tip]
Every node card uses the same layout:

What it does → Key properties → Key signals → Common pitfall → Quick snippet.

Use Ctrl+F to jump to any node by name.
:::

:::callout-key[Inheritance shorthand]
The *inherits* line lists only the immediate parent. Full chain is always available in the Godot docs. In GDScript you can call any ancestor's methods on any node.
:::

## Base Node Classes

#### Node

Inherits: Object

The root of everything. Every scene tree element is a Node. Provides the lifecycle callbacks, scene-tree access, signals, groups, and child management that all other nodes build on.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `name` | StringName | Node name — unique among siblings; used by `$NodeName` shorthand. |
| `owner` | Node | The node that "owns" this one; usually the scene root. Affects what gets saved. |
| `process_mode` | ProcessMode enum | Controls whether `_process` / `_physics_process` run when the tree is paused. |
| `get_tree()` | SceneTree | Access the running SceneTree — timers, groups, current scene, etc. |
| `get_parent()` | Node | Immediate parent, or null if this node is the root. |
| `add_child(node)` | — | Adds a node as a child. Set `force_readable_name=true` for editor clarity. |
| `queue_free()` | — | Deletes the node at end of current frame (safe during callbacks). |
| `find_child(pattern)` | Node | Recursive name-pattern search. Returns first match or null. |
| `is_in_group("g")` | bool | Groups let you broadcast calls without direct references. |

**Key signals:** `ready`, `tree_entered`, `tree_exited`, `child_entered_tree`, `renamed`

:::callout-pitfall[Pitfall]
Calling

get\_node()

or

$Child

inside the constructor (`_init`) always fails — the scene tree isn't wired yet. Use

\_ready()

instead.
:::

#### Node2D 2D

Inherits: CanvasItem → Node

Base for all 2D objects. Carries a 2D transform (position, rotation, scale) and sits on a canvas layer. Every visible 2D node ultimately inherits from here.

| Property | Type | Notes |
| --- | --- | --- |
| `position` | Vector2 | Local position relative to parent. |
| `global_position` | Vector2 | World-space position. Read/write; propagates transform changes up the tree. |
| `rotation` | float (radians) | Use `rotation_degrees` for degree-friendly values. |
| `scale` | Vector2 | Local scale. Affects children unless you reset their scale. |
| `z_index` | int | Draw order within the same canvas layer. Higher = in front. |
| `look_at(target)` | — | Rotates the node to face a global Vector2 position. |
| `translate(offset)` | — | Moves in local space (affected by rotation). |

**Key signals (CanvasItem):** `draw` (fires every frame if `queue_redraw()` is called), `visibility_changed`, `hidden`

:::callout-tip[Tip]
get\_global\_mouse\_position()

is a CanvasItem method — call it on any Node2D descendant to get the mouse in world space.
:::

#### Node3D 3D

Inherits: Node

Base for all 3D objects. Carries a full 3D Transform3D (basis + origin). Replaces Godot 3's Spatial node.

| Property | Type | Notes |
| --- | --- | --- |
| `position` | Vector3 | Local position (metres by default). |
| `global_position` | Vector3 | World-space position. |
| `rotation` | Vector3 (radians) | Euler angles. Use `rotation_degrees` in the Inspector. |
| `basis` | Basis | 3×3 rotation + scale matrix. Use for direction vectors: `basis.z` = forward. |
| `transform` | Transform3D | Full local transform. Assigning overwrites position, rotation, and scale at once. |
| `look_at(target, up)` | — | Orients so `-Z` faces target. `up` defaults to `Vector3.UP`. |
| `translate_object_local(offset)` | — | Moves in object-local space (useful for forward/strafe movement). |

:::callout-warning[Warning]
Godot 4's

-Z

axis is the default "forward" for Node3D, matching the glTF convention that Blender exports to. Blender's own viewport is Z-up with

-Y

forward, so the axes are converted on export rather than shared. Unity uses

+Z

. Adjust your locomotion math accordingly.
:::

## 2D Physics Nodes

#### StaticBody2D 2D

Inherits: PhysicsBody2D → CollisionObject2D → Node2D

An immovable physics object. Walls, floors, platforms — anything that does not move under physics forces. Has zero CPU cost per frame when static.

| Property | Type | Notes |
| --- | --- | --- |
| `physics_material_override` | PhysicsMaterial | Override friction and bounce per-body instead of per-shape. |
| `constant_linear_velocity` | Vector2 | Non-zero → moving platform behaviour; RigidBody2Ds riding it inherit this velocity. |
| `constant_angular_velocity` | float | Same for rotation (rotating conveyor belts). |

**Requires:** At least one `CollisionShape2D` or `CollisionPolygon2D` child.

:::callout-tip[Tip]
For a moving platform, use

AnimatableBody2D

(a StaticBody2D subclass that notifies the physics server of its movement each frame) instead of manually setting the velocity.
:::

#### RigidBody2D 2D

Inherits: PhysicsBody2D

A physics-simulated body. Gravity, forces, impulses, torque, and collision response are all handled by the physics server. Use for crates, projectiles, debris.

| Property | Type | Notes |
| --- | --- | --- |
| `mass` | float | Kilograms. Affects collision response and gravity. |
| `gravity_scale` | float | 0 = no gravity, negative = floats up. 1 = normal. |
| `linear_velocity` | Vector2 | Readable any frame; write via `apply_impulse()` or `apply_force()`. |
| `angular_velocity` | float | Radians/second spin. |
| `freeze` | bool | Makes the body static until un-frozen. Good for grab mechanics. |
| `apply_impulse(impulse, pos)` | — | Instantaneous velocity change. Use for kicks, explosions. |
| `apply_force(force, pos)` | — | Continuous force. Call every physics frame. |

**Key signals:** `body_entered(body)`, `body_exited(body)`, `sleeping_state_changed`

:::callout-pitfall[Pitfall]
Never set

position

or

rotation

directly on a RigidBody2D outside of `_integrate_forces()`. Doing so fights the physics engine and causes jitter.
:::

#### CharacterBody2D 2D

Inherits: PhysicsBody2D

The player body node. You move it yourself each frame using `velocity` + `move_and_slide()`; the physics server handles collision response. Maximum control, no physics surprises.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `velocity` | Vector2 | Set this then call `move_and_slide()`. |
| `up_direction` | Vector2 | What "up" means for floor detection. Default `Vector2.UP`. |
| `floor_stop_on_slope` | bool | Prevents sliding down slopes when standing still. |
| `move_and_slide()` | bool | Returns true if a collision happened. Updates `velocity` to post-slide value. |
| `is_on_floor()` | bool | True if last `move_and_slide()` hit a floor. |
| `is_on_wall()` | bool | True if last slide hit a wall. |
| `get_slide_collision(i)` | KinematicCollision2D | Details of the i-th collision from the last slide. |

:::callout-tip[Tip]
Always call

move\_and\_slide()

inside `_physics_process()`, not `_process()`. It uses delta internally and must be frame-rate-synced.
:::

#### Area2D 2D

Inherits: CollisionObject2D → Node2D

A detector zone. No physics forces, just detection: overlap queries, audio bus overrides, and gravity overrides. Perfect for triggers, pickups, damage zones, and water regions.

| Property | Type | Notes |
| --- | --- | --- |
| `monitoring` | bool | Whether this area detects overlaps with others. |
| `monitorable` | bool | Whether other areas can detect this one. |
| `collision_layer` | int (bitmask) | What layer this area exists on. |
| `collision_mask` | int (bitmask) | What layers this area watches for. |
| `gravity_point` | bool | If true, the area acts as a gravity well. |
| `get_overlapping_bodies()` | Array | Returns all physics bodies currently overlapping. |

**Key signals:** `body_entered(body)`, `body_exited(body)`, `area_entered(area)`, `area_exited(area)`

:::callout-warning[Warning]
Overlap signals only fire when

monitoring

is true AND collision layers/masks actually intersect. Mis-set layers are the #1 cause of silent Area2D failures.
:::

## 3D Physics Nodes

#### StaticBody3D 3D

Inherits: PhysicsBody3D → CollisionObject3D → Node3D

Immovable 3D collider. Level geometry, walls, floors, and any environment piece that never moves under physics.

| Property | Type | Notes |
| --- | --- | --- |
| `physics_material_override` | PhysicsMaterial | Per-body friction/bounce override. |
| `constant_linear_velocity` | Vector3 | Moving-platform velocity communicated to riding bodies. |

:::callout-tip[Tip]
Generate a StaticBody3D + CollisionShape3D automatically from any MeshInstance3D in the editor: select the mesh → Mesh menu → Create Trimesh Static Body.
:::

#### RigidBody3D 3D

Inherits: PhysicsBody3D

Physics-simulated 3D body. Gravity, forces, impulses, and torque are all automatic. Use for throwable props, ragdoll pieces, and anything that should tumble and bounce.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `mass` | float | Kilograms. |
| `gravity_scale` | float | Multiplies global gravity. 0 = weightless. |
| `linear_velocity` | Vector3 | Current velocity. Don't set directly — use `apply_impulse()`. |
| `angular_velocity` | Vector3 | Spin axis × angular speed. |
| `apply_impulse(impulse, pos)` | — | Instant velocity kick. `pos` offset from centre of mass for torque. |
| `apply_central_force(force)` | — | Continuous push with no torque (force at exact centre). |
| `freeze_mode` | FreezeMode | STATIC or KINEMATIC freeze modes when `freeze = true`. |

**Key signals:** `body_entered(body)`, `body_exited(body)`, `sleeping_state_changed`

:::callout-pitfall[Pitfall]
To move a RigidBody3D via script (e.g., a door controlled by animation), set

freeze = true

with

freeze\_mode = FREEZE\_MODE\_KINEMATIC

(there is no

mode

property in Godot 4), or use

AnimatableBody3D

— otherwise animation and physics fight each other.
:::

#### CharacterBody3D 3D

Inherits: PhysicsBody3D

The 3D player controller body. You supply velocity each frame; `move_and_slide()` resolves collisions. Same design philosophy as CharacterBody2D but in three dimensions.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `velocity` | Vector3 | Set this, then call `move_and_slide()`. |
| `up_direction` | Vector3 | Defines "floor" direction. Default `Vector3.UP`. |
| `floor_max_angle` | float (radians) | Max slope angle treated as a floor. Default ~46°. |
| `move_and_slide()` | bool | Moves body, slides along surfaces, returns true on collision. |
| `is_on_floor()` | bool | True after a slide that hit a floor surface. |
| `is_on_ceiling()` | bool | True after a slide that hit a ceiling. |
| `get_floor_normal()` | Vector3 | Normal of the floor surface being stood on. |

```gdscript
func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= 9.8 * delta          # gravity
    var dir := Input.get_vector("left","right","forward","back")
    velocity.x = dir.x * speed
    velocity.z = dir.y * speed
    move_and_slide()
```

#### Area3D 3D

Inherits: CollisionObject3D → Node3D

3D trigger zone. Same concept as Area2D: no physics forces, just overlap detection, audio bus changes, and gravity overrides in the volume.

| Property | Type | Notes |
| --- | --- | --- |
| `monitoring / monitorable` | bool | Same as Area2D — both must be true for mutual detection. |
| `reverb_bus` | StringName | Name of an Audio Bus to apply to sounds inside the area (cave reverb, etc.). |
| `reverb_amount` | float 0–1 | How strongly the reverb bus is blended in. |
| `wind_force_magnitude` | float | Applies wind to particles and soft bodies inside the area. |

**Key signals:** `body_entered`, `body_exited`, `area_entered`, `area_exited`

## 2D Rendering Nodes

#### Sprite2D 2D

Inherits: Node2D

Displays a single texture or a region of a spritesheet. The simplest way to put an image on screen in 2D.

| Property | Type | Notes |
| --- | --- | --- |
| `texture` | Texture2D | The image to display. Drag-drop from FileSystem. |
| `hframes / vframes` | int | Number of columns / rows if the texture is a spritesheet. |
| `frame` | int | Current spritesheet frame (0-based, left-to-right, top-to-bottom). |
| `centered` | bool | If true (default), origin is at texture centre. Set false for top-left origin. |
| `offset` | Vector2 | Pixel offset from node origin to texture centre. |
| `flip_h / flip_v` | bool | Horizontal / vertical flip without needing negative scale. |
| `modulate` | Color | Tint the sprite. White = no tint. Alpha controls transparency. |
| `region_enabled` | bool | Enable to use only a `region_rect` sub-rectangle of the texture. |

**Key signal:** `texture_changed`

#### AnimatedSprite2D 2D

Inherits: Node2D

Plays frame-by-frame sprite animations defined in a `SpriteFrames` resource. Each named animation holds a sequence of Texture2D frames with per-animation FPS.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `sprite_frames` | SpriteFrames | The resource holding all animations. Create one in the Inspector. |
| `animation` | StringName | Currently playing animation name. |
| `frame` | int | Current frame within the animation. |
| `speed_scale` | float | Playback speed multiplier. 2.0 = double speed. |
| `play(anim_name)` | — | Start playing. Plays from current frame if already playing same anim. |
| `stop()` | — | Pauses playback, keeping current frame. |
| `is_playing()` | bool | True while animation is running. |

**Key signals:** `animation_finished`, `animation_changed`, `frame_changed`

:::callout-tip[Tip]
Set an animation to loop=false, then connect

animation\_finished

to transition to an idle animation. This is the standard "attack → idle" pattern.
:::

#### TileMapLayer 2D

Inherits: Node2D

Renders a grid of tiles from a TileSet resource. Each layer manages its own cell data independently. Introduced in Godot 4.3 to replace the monolithic TileMap node.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `tile_set` | TileSet | Shared resource containing tile definitions, physics layers, and atlases. |
| `set_cell(coords, source_id, atlas_coords)` | — | Place a tile at grid coords. `atlas_coords = Vector2i(-1,-1)` erases. |
| `get_cell_source_id(coords)` | int | Returns -1 if the cell is empty. |
| `map_to_local(map_pos)` | Vector2 | Convert tile grid coordinate to local pixel position. |
| `local_to_map(local_pos)` | Vector2i | Convert a pixel position to the tile it falls in. |
| `get_used_cells()` | Array[Vector2i] | All non-empty cells — useful for procedural iteration. |

:::callout-warning[Warning]
Physics on a TileMapLayer only works if you have added a Physics Layer inside the TileSet and assigned shapes to individual tiles in the TileSet editor.
:::

#### Line2D / Polygon2D 2D

Inherits: Node2D

**Line2D** draws a polyline with configurable width, joint type, and texture. **Polygon2D** fills a polygon with a colour or UV-mapped texture.

| Property | Type | Notes (Line2D) |
| --- | --- | --- |
| `points` | PackedVector2Array | Control points. Append via `add_point()`. |
| `width` | float | Line thickness in pixels. |
| `default_color` | Color | Solid line colour when no gradient is set. |
| `gradient` | Gradient | Colour gradient along the line length. |
| `joint_mode` | JointMode | SHARP, BEVEL, or ROUND corners. |

:::callout-tip[Use case]
Laser beams, ropes, debug-draw overlays. For a rope: update

points

each frame using a simple verlet physics simulation.
:::

#### GPUParticles2D 2D

Inherits: Node2D

GPU-driven 2D particle system. Thousands of particles with minimal CPU cost. All logic runs in a shader via a `ParticleProcessMaterial`.

| Property | Type | Notes |
| --- | --- | --- |
| `amount` | int | Total particles allocated. Halving this is the fastest way to improve performance. |
| `lifetime` | float | Seconds each particle lives before recycling. |
| `emitting` | bool | Toggle to start/stop emission without destroying the node. |
| `one_shot` | bool | Emit once then stop. Set `explosiveness` to 1.0 for burst. |
| `process_material` | ParticleProcessMaterial | Controls velocity, colour, size over lifetime, etc. |
| `texture` | Texture2D | Particle sprite. Use an atlas for variety. |

**Key signal:** `finished` (emitted when a one-shot burst completes)

## 3D Rendering Nodes

#### MeshInstance3D 3D

Inherits: GeometryInstance3D → VisualInstance3D → Node3D

Renders a 3D mesh in the world. The workhorse of 3D rendering — almost every visible object in your 3D scene is a MeshInstance3D (or something that contains one).

| Property | Type | Notes |
| --- | --- | --- |
| `mesh` | Mesh | The geometry (ArrayMesh, PrimitiveMesh, ImportedMesh). Can be shared across instances. |
| `surface_material_override[i]` | Material | Override per-surface material without modifying the shared mesh resource. |
| `cast_shadow` | ShadowCastingSetting | ON / OFF / DOUBLE\_SIDED / SHADOWS\_ONLY. SHADOWS\_ONLY = invisible but casts shadow. |
| `lod_bias` | float | Higher = switches to lower LOD sooner. Useful for non-player objects. |
| `gi_mode` | GIMode | STATIC (baked), DYNAMIC (real-time GI), or DISABLED. |
| `create_convex_collision()` | — | Auto-generates a CollisionShape3D child for a convex approximation. |
| `create_trimesh_collision()` | — | Auto-generates a precise (but slower) trimesh collision shape. |

:::callout-tip[Performance tip]
Use

MultiMeshInstance3D

instead when you need hundreds of identical meshes (trees, rocks, crowds). Single draw call vs. one per MeshInstance3D.
:::

#### GPUParticles3D 3D

Inherits: GeometryInstance3D → Node3D

GPU-driven 3D particle system. Same design as GPUParticles2D but particles live and move in 3D world space.

| Property | Type | Notes |
| --- | --- | --- |
| `amount` | int | Particle budget. Each particle uses GPU memory regardless of emission rate. |
| `lifetime` | float | Seconds per particle life. |
| `process_material` | ParticleProcessMaterial | Same resource type as GPUParticles2D. |
| `draw_pass_1` | Mesh | Mesh rendered per particle. Use a QuadMesh for billboarded sprites. |
| `fixed_fps` | int | Lock simulation to a fixed rate (0 = match render framerate). |
| `transform_align` | TransformAlign | DISABLED, Z\_BILLBOARD, Y\_TO\_VELOCITY etc. for orientation relative to camera. |

#### Decal 3D

Inherits: VisualInstance3D → Node3D

Projects a texture onto surfaces inside a box volume — bullet holes, scorch marks, puddles, dirt. No mesh modification; fully deferred rendering.

| Property | Type | Notes |
| --- | --- | --- |
| `texture_albedo` | Texture2D | The colour texture to project. |
| `texture_normal` | Texture2D | Normal map overlay. |
| `size` | Vector3 | XYZ extents of the projection box. |
| `upper_fade / lower_fade` | float | Soft fade at top/bottom of the projection volume. |
| `cull_mask` | int bitmask | Which render layers the decal projects onto. |

:::callout-warning[Warning]
Decals require a Forward+ or Mobile renderer. Compatibility renderer does not support them.
:::

#### ReflectionProbe 3D

Inherits: VisualInstance3D → Node3D

Captures the surroundings into a cubemap used for local reflections. More accurate than the sky-only fallback, without the cost of ray-traced reflections.

| Property | Type | Notes |
| --- | --- | --- |
| `update_mode` | UpdateMode | ONCE (baked at load) or ALWAYS (every frame, expensive). |
| `extents` | Vector3 | Half-size of the capture volume. |
| `intensity` | float | Reflection brightness multiplier. |
| `ambient_mode` | AmbientMode | DISABLED, ENVIRONMENT, or CONSTANT colour for ambient inside the volume. |
| `box_projection` | bool | Parallax-correct reflections for boxy rooms. Reduces swimming artefacts. |

## Lighting Nodes

#### DirectionalLight3D 3D

Inherits: Light3D → VisualInstance3D → Node3D

Infinite parallel light with no falloff — models the sun or moon. Only the rotation matters; position has no effect on lighting (but affects shadow camera placement).

| Property | Type | Notes |
| --- | --- | --- |
| `light_energy` | float | Brightness. 1.0 = normal. HDR scenes often use 2–10. |
| `light_color` | Color | Tint. Warm orange for sunsets, cool blue for moonlight. |
| `shadow_enabled` | bool | Enable PSSM shadow cascades. Always uses 3–4 splits for outdoor scenes. |
| `directional_shadow_split_1` | float 0–1 | Fraction of view distance at which first cascade ends. |
| `sky_mode` | SkyMode | LIGHT\_AND\_SKY, LIGHT\_ONLY, or SKY\_ONLY. Useful for godray setups. |

:::callout-tip[Tip]
Add a second DirectionalLight3D with very low energy as a "fill light" from the opposite direction to prevent pitch-black shadows on the dark side of objects.
:::

#### OmniLight3D 3D

Inherits: Light3D → Node3D

A point light that emits in all directions with distance-based falloff. Torches, lamps, explosions, glowing objects.

| Property | Type | Notes |
| --- | --- | --- |
| `omni_range` | float | Maximum light reach in world units. Light is zero beyond this. |
| `omni_attenuation` | float | Falloff curve exponent. 1.0 = linear, 2.0 = quadratic (physical). |
| `light_energy` | float | Brightness. |
| `shadow_enabled` | bool | Cubemap shadow. Expensive — limit to 1–2 per scene. |

:::callout-pitfall[Performance]
Each shadow-casting OmniLight3D renders the scene 6 times (one per cubemap face). Keep shadow-casting omnis to a strict minimum in mobile targets.
:::

#### SpotLight3D 3D

Inherits: Light3D → Node3D

A cone-shaped light. Flashlights, stage spotlights, car headlights, desk lamps. Cheaper shadows than OmniLight3D (single frustum instead of cubemap).

| Property | Type | Notes |
| --- | --- | --- |
| `spot_range` | float | Maximum reach along the -Z axis. |
| `spot_angle` | float (degrees) | Half-angle of the cone. 45° = a 90° full cone. |
| `spot_angle_attenuation` | float | Softness of the cone edge. Higher = sharper falloff. |
| `spot_attenuation` | float | Distance falloff curve, same as OmniLight3D. |

#### WorldEnvironment 3D

Inherits: Node

Holds the scene's global `Environment` resource — sky, ambient light, tone mapping, fog, glow, SSAO, SSIL, and all post-processing. One per scene tree.

| Property | Type | Notes |
| --- | --- | --- |
| `environment` | Environment | The Environment resource. Edit in Inspector to expose all sub-settings. |
| `camera_attributes` | CameraAttributes | Physical camera settings: exposure, DOF, auto-exposure. Shared across the scene. |

**Key Environment sub-properties:**

| Setting | Notes |
| --- | --- |
| `background_mode` | SKY, COLOR, CANVAS (2D background), or CAMERA\_FEED. |
| `sky` | A Sky resource using ProceduralSkyMaterial, PanoramaSkyMaterial, etc. |
| `ambient_light_source` | BG (inherit from sky), COLOR (flat), or DISABLED. |
| `tonemap_mode` | LINEAR, REINHARDT, FILMIC, or ACES. Filmic is the typical cinematic choice. |
| `glow_enabled` | Enables the bloom post-process. Set glow\_blend\_mode to ADDITIVE for sci-fi. |
| `fog_enabled` | Distance fog. Set fog\_depth\_begin/end for a controllable fog ramp. |
| `ssao_enabled` | Screen-Space Ambient Occlusion. Adds contact shadows to crevices. |
| `sdfgi_enabled` | Signed Distance Field GI — large-scale real-time indirect lighting. Expensive. |

## Camera Nodes

#### Camera2D 2D

Inherits: Node2D

The 2D camera. Whichever Camera2D has `enabled = true` and is current defines the viewport view. Supports built-in smoothing, limits, and drag margins.

| Property | Type | Notes |
| --- | --- | --- |
| `enabled` | bool | Set false to disable this camera without removing it. |
| `zoom` | Vector2 | Camera zoom. `(2,2)` = everything appears 2× larger (zoomed in). |
| `position_smoothing_enabled` | bool | Lerp camera toward target. Set speed via `position_smoothing_speed`. |
| `rotation_smoothing_enabled` | bool | Smoothly follow rotation changes. |
| `limit_left/right/top/bottom` | int | Hard world-pixel limits the camera won't scroll past. Set to world edge. |
| `drag_horizontal/vertical_enabled` | bool | Camera only moves once player exits a dead zone. Classic platformer feel. |
| `offset` | Vector2 | Shift the camera view without moving the node (look-ahead). |
| `make_current()` | — | Programmatically activate this camera. |

:::callout-tip[Tip]
Attach Camera2D to your player node so it follows automatically, or make it a sibling and use a script to lerp its position for more control over dead zones and lag.
:::

#### Camera3D 3D

Inherits: Node3D

The 3D camera. Supports perspective and orthographic projection. The active Camera3D in the scene tree determines what the player sees.

| Property | Type | Notes |
| --- | --- | --- |
| `fov` | float | Vertical field of view in degrees. 75° is standard; lower for sniper zoom. |
| `near / far` | float | Near and far clip planes. Keep near as large as possible for better depth precision. |
| `projection` | ProjectionType | PERSPECTIVE or ORTHOGONAL (isometric / top-down). |
| `current` | bool | Set true to make this the active camera. Only one can be current. |
| `cull_mask` | int bitmask | Which visual layers this camera renders. Use to hide UI meshes from cutscene cameras. |
| `project_ray_from_screen(pos)` | Vector3 | Returns world-space ray direction from a screen pixel. Used for mouse-picking. |
| `unproject_position(world_pos)` | Vector2 | World position → screen pixel. Use for health bars above 3D enemies. |

## Audio Nodes

#### AudioStreamPlayer

Inherits: Node

Non-positional audio playback — music, UI sounds, narrator. Plays through the selected audio bus with no spatial falloff.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `stream` | AudioStream | The audio resource (AudioStreamMP3, AudioStreamOggVorbis, etc.). |
| `bus` | StringName | Target audio bus name. Default "Master". |
| `volume_db` | float | Volume in decibels. 0 = full, −6 = half power, −inf = silence. |
| `pitch_scale` | float | 1.0 = normal pitch. 2.0 = one octave up. |
| `autoplay` | bool | Start playing when the node enters the scene tree. |
| `play(from_pos)` | — | Start playback. Optionally seek to a time in seconds. |
| `stop()` | — | Stop and reset position. |
| `playing` | bool | Read-only; true while audio is playing. |

**Key signal:** `finished` — emitted when a non-looping stream ends. Use to chain music tracks or clean up one-shot nodes.

#### AudioStreamPlayer2D 2D

Inherits: Node2D

Positional 2D audio. Volume and stereo panning are calculated from the distance and angle between this node and the nearest `AudioListener2D` (usually the camera).

| Property | Type | Notes |
| --- | --- | --- |
| `max_distance` | float | Pixels from the listener beyond which the sound is silent. |
| `attenuation` | float | Volume falloff curve. Higher = faster drop-off. |
| `panning_strength` | float | How strongly horizontal position affects stereo pan. 0 = mono. |
| `area_mask` | int bitmask | Which Area2D audio overrides apply to this player. |

#### AudioStreamPlayer3D 3D

Inherits: Node3D

Full 3D spatial audio with distance attenuation, Doppler effect, reverb via Area3D, and HRTF panning. Use for any in-world sound (footsteps, explosions, ambient sources).

| Property | Type | Notes |
| --- | --- | --- |
| `unit_size` | float | Reference distance at which audio is at full volume. Default 10 m. |
| `max_db` | float | Max volume cap — prevents very-close sounds from being deafening. |
| `max_distance` | float | Hard cutoff distance. 0 = no cutoff. |
| `attenuation_model` | AttenuationModel | INVERSE\_DISTANCE, INVERSE\_SQUARE\_DISTANCE, LOGARITHMIC, or DISABLED. |
| `doppler_tracking` | DopplerTracking | DISABLED, IDLE (updates in \_process), or PHYSICS (updates in \_physics\_process). |
| `emission_angle_enabled` | bool | Makes the sound directional (louder in front than behind). For car engines, speakers. |

## UI / Control Nodes

#### Control UI

Inherits: CanvasItem → Node

The base class for all UI widgets. Manages layout (anchors, margins, size), focus, mouse input, and theming. You rarely add a raw Control — use one of its subclasses instead.

| Property | Type | Notes |
| --- | --- | --- |
| `anchor_left/right/top/bottom` | float 0–1 | Fractional position relative to parent container. 0=left/top, 1=right/bottom. |
| `offset_left/right/top/bottom` | float | Pixel offset applied after anchors. The "margin" from the anchor point. |
| `size` | Vector2 | Pixel size. Set via anchors+offsets or via `set_custom_minimum_size()`. |
| `size_flags_horizontal/vertical` | SizeFlags | EXPAND, FILL, SHRINK\_\* — controls container layout behaviour. |
| `mouse_filter` | MouseFilter | STOP (consume), PASS (forward to parent), IGNORE (not clickable). |
| `focus_mode` | FocusMode | NONE, CLICK, or ALL (keyboard focusable). Required for gamepad navigation. |
| `theme_type_variation` | StringName | Use a variant theme style (e.g., "DangerButton" inheriting from "Button"). |

**Key signals:** `mouse_entered`, `mouse_exited`, `focus_entered`, `focus_exited`, `resized`, `minimum_size_changed`, `gui_input(event)`

#### Label UI

Inherits: Control

Displays a single- or multi-line string. Supports BBCode-style rich text via `RichTextLabel`. For plain styled text, Label is simpler and cheaper.

| Property | Type | Notes |
| --- | --- | --- |
| `text` | String | The displayed string. Supports `\n` for newlines. |
| `horizontal_alignment` | HorizontalAlignment | LEFT, CENTER, RIGHT, or FILL (justify). |
| `vertical_alignment` | VerticalAlignment | TOP, CENTER, BOTTOM, or FILL. |
| `autowrap_mode` | AutowrapMode | OFF, ARBITRARY, WORD, WORD\_SMART. Enables text wrapping to control width. |
| `uppercase` | bool | Display all text in uppercase without changing the source string. |
| `visible_characters` | int | Shows only the first N characters — useful for typewriter effects. |
| `visible_ratio` | float 0–1 | Fraction of characters visible. Animate this for typewriter effects. |

#### Button UI

Inherits: BaseButton → Control

A clickable button with a text label and optional icon. The most common interactive UI element.

| Property | Type | Notes |
| --- | --- | --- |
| `text` | String | Button label text. |
| `icon` | Texture2D | Optional icon displayed alongside text. |
| `disabled` | bool | Greyed out and unclickable. Set via code to gate functionality. |
| `toggle_mode` | bool | If true, button latches (stays pressed). Turns it into a toggle. |
| `button_pressed` | bool | State when in toggle\_mode. |
| `action_mode` | ActionMode | BUTTON\_PRESS (fires on press) or BUTTON\_RELEASE (fires on release, default). |

**Key signals:** `pressed` (most common), `button_up`, `button_down`, `toggled(button_pressed)`

:::callout-tip[Other button types]
CheckBox

,

CheckButton

,

OptionButton

(dropdown),

MenuButton

,

LinkButton

— all inherit BaseButton and share the same signals.
:::

#### LineEdit UI

Inherits: Control

Single-line text input. Player name entry, search boxes, console inputs.

| Property | Type | Notes |
| --- | --- | --- |
| `text` | String | Current text content. Readable and writable. |
| `placeholder_text` | String | Greyed hint shown when the field is empty. |
| `secret` | bool | Masks input with bullets (password mode). |
| `max_length` | int | Character cap. 0 = unlimited. |
| `editable` | bool | Set false to make read-only (still selectable). |

**Key signals:** `text_changed(new_text)`, `text_submitted(new_text)` (Enter key), `text_change_rejected`

#### TextEdit / CodeEdit UI

Inherits: Control

**TextEdit** is a multi-line text input. **CodeEdit** (extends TextEdit) adds syntax highlighting, code folding, auto-indent, and delimiter tracking — use it for any in-game code or script editor.

| Property | Type | Notes |
| --- | --- | --- |
| `text` | String | Full text content. |
| `editable` | bool | Toggle read-only mode. |
| `wrap_mode` | LineWrappingMode | NONE or BOUNDARY. BOUNDARY wraps at control width. |
| `syntax_highlighter` | SyntaxHighlighter | (CodeEdit only) Plug in a CodeHighlighter resource for token colouring. |

#### ProgressBar / HSlider / VSlider UI

Inherits: Range → Control

All three inherit `Range` — a control with a `min_value`, `max_value`, and `value`. ProgressBar is display-only; sliders are interactive.

| Property | Type | Notes |
| --- | --- | --- |
| `min_value / max_value` | float | Range bounds. Defaults 0 – 100. |
| `value` | float | Current value. Clamped between min and max. |
| `step` | float | Snap increment. 1.0 for integers, 0 for continuous. |
| `show_percentage` | bool | (ProgressBar only) Show the % label over the bar. |

**Key signal:** `value_changed(value)`

#### Container Nodes UI

Inherits: Control (various subclasses)

Containers automatically arrange their children. You almost never set a child's size/position manually inside a container.

| Container | Behaviour |
| --- | --- |
| `VBoxContainer` | Children stacked vertically. Use `separation` theme item for gap. |
| `HBoxContainer` | Children laid out horizontally. |
| `GridContainer` | Grid layout; set `columns` for column count. |
| `MarginContainer` | Adds padding (margins) around a single child. |
| `PanelContainer` | Draws a panel background behind a single child — quick styled box. |
| `ScrollContainer` | Adds scroll bars around an oversized child. |
| `TabContainer` | Children become tabs; shows one at a time. |
| `CenterContainer` | Centres its child in its own bounds. |
| `AspectRatioContainer` | Preserves child aspect ratio while filling available space. |

:::callout-tip[Tip]
Set a child's

size\_flags\_horizontal = EXPAND

to make it grow and fill remaining container space. Combine with

FILL

to also stretch to the allocated size.
:::

#### Popup / AcceptDialog / ConfirmationDialog UI

Inherits: Window → Viewport → Node

Modal overlay windows. `Popup` is the base (auto-closes on click-outside). `AcceptDialog` adds an OK button. `ConfirmationDialog` adds OK + Cancel.

| Method | Notes |
| --- | --- |
| `popup_centered()` | Show centred in the viewport. |
| `popup_centered_ratio(ratio)` | Show at a fraction of the viewport size (e.g., 0.5 = half screen). |
| `hide()` | Close the popup. |

**Key signals:** `confirmed` (AcceptDialog/ConfirmationDialog), `canceled`, `popup_hide`

## Animation Nodes

#### AnimationPlayer

Inherits: AnimationMixer → Node

Plays named `Animation` resources that keyframe any property on any node in the scene. The standard tool for cut-scene sequences, character state animations, and UI transitions.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `root_node` | NodePath | The node whose subtree is animated. Defaults to the AnimationPlayer's parent. |
| `current_animation` | String | Name of the currently playing animation. |
| `speed_scale` | float | Global playback speed multiplier. Negative = reverse. |
| `play(name, blend=-1, speed=1)` | — | Play a named animation. `blend` seconds cross-fades from the previous. |
| `play_backwards(name)` | — | Play in reverse from the end. |
| `stop()` | — | Stop and reset to first frame. |
| `pause()` | — | Freeze at current position without resetting. |
| `seek(seconds)` | — | Jump to a specific time in the animation. |
| `get_animation(name)` | Animation | Returns the Animation resource for direct keyframe editing at runtime. |
| `has_animation(name)` | bool | Check before calling play() to avoid errors. |

**Key signals:** `animation_finished(anim_name)`, `animation_started(anim_name)`, `animation_changed(old, new)`

:::callout-tip[RESET track]
Always create a "RESET" animation that stores the default values of every property you animate. Godot uses it when stopping animations — without it, properties stay at their final keyframed value.
:::

#### AnimationTree

Inherits: AnimationMixer → Node

A state-machine and blend-tree controller layered on top of AnimationPlayer. Handles blending, transitions, and IK without custom code. Required for any character with multiple locomotion states.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `tree_root` | AnimationRootNode | The root of the blend tree (AnimationNodeStateMachine, BlendTree, etc.). |
| `anim_player` | NodePath | Points to the AnimationPlayer that owns the Animation resources. |
| `active` | bool | Must be true for the tree to process. Defaults false. |
| `set("parameters/Blend/blend_amount", v)` | — | Control blend tree parameters via string paths. Found in the AnimationTree inspector. |

**Key child node types:** `AnimationNodeStateMachine` (state graph), `AnimationNodeBlendTree` (node graph), `AnimationNodeBlend2/3`, `AnimationNodeOneShot`, `AnimationNodeTimeScale`

:::callout-pitfall[Pitfall]
If

active

is false or

anim\_player

path is wrong, the tree silently does nothing — animations won't play and no errors are thrown. Always check both settings first.
:::

#### Skeleton3D 3D

Inherits: Node3D

The armature (bone hierarchy) for a skinned 3D mesh. Imported automatically from FBX/GLTF. Drives MeshInstance3D vertex deformation via weights. Modified by AnimationPlayer and IK solvers.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `get_bone_count()` | int | Total number of bones in the skeleton. |
| `find_bone(name)` | int | Returns bone index by name, or -1 if not found. |
| `get_bone_pose(idx)` | Transform3D | Current local pose of bone idx. |
| `set_bone_pose(idx, xform)` | — | Override bone pose. Use for procedural IK (e.g., hand placement). |
| `reset_bone_poses()` | — | Reset all bones to rest pose. |

:::callout-tip[BoneAttachment3D]
Add a BoneAttachment3D as a child of Skeleton3D to attach scene nodes (weapons, hats) to specific bones. It tracks the bone's world transform every frame automatically.
:::

## Navigation Nodes

#### NavigationAgent2D / NavigationAgent3D

Inherits: Node

Queries the navigation server for paths and returns the next position an NPC should move toward. Handles avoidance, path recalculation, and arrival detection.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `target_position` | Vector2/3 | The destination. Setting this triggers a new path request. |
| `path_desired_distance` | float | How close to each waypoint before advancing. Default 1.0. |
| `target_desired_distance` | float | How close to the final target counts as "arrived". |
| `avoidance_enabled` | bool | Enable RVO obstacle avoidance (CPU cost per agent). |
| `get_next_path_position()` | Vector2/3 | Call each frame to get the next waypoint to move toward. |
| `is_navigation_finished()` | bool | True when the agent has reached the target. |
| `distance_to_target()` | float | Straight-line distance to target (not path length). |

**Key signal:** `navigation_finished` — fires when agent arrives at the destination.

```gdscript
func _physics_process(delta: float) -> void:
    if nav_agent.is_navigation_finished():
        return
    var next := nav_agent.get_next_path_position()
    var dir := (next - global_position).normalized()
    velocity = dir * speed
    move_and_slide()
```

#### NavigationRegion2D / NavigationRegion3D

Inherits: Node2D / Node3D

Defines a walkable area for the navigation server. Agents can only path through regions. Must be baked (or have a pre-baked NavigationMesh/NavigationPolygon) to be active.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `navigation_mesh` | NavigationMesh (3D) | The baked navmesh. Bake in editor via Scene menu or call `bake_navigation_mesh()` at runtime. |
| `navigation_polygon` | NavigationPolygon (2D) | The walkable polygon for 2D navigation. |
| `enabled` | bool | Toggle this region on/off (e.g., lock a door → disable its region). |
| `travel_cost / enter_cost` | float | Higher values make agents avoid this region (useful for danger zones). |

:::callout-warning[Warning]
Runtime navmesh baking is expensive — bake once at level load, not every frame. For dynamic obstacles use NavigationObstacle nodes instead of re-baking.
:::

## Utility Nodes

#### Timer

Inherits: Node

A countdown timer that emits a signal when it reaches zero. The simplest way to delay an action, repeat an event, or manage cooldowns without manual delta accumulation.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `wait_time` | float | Duration in seconds. |
| `one_shot` | bool | If false (default), restarts after firing. If true, stops after one cycle. |
| `autostart` | bool | Start counting immediately when the node enters the tree. |
| `paused` | bool | Pause without stopping the countdown. |
| `start(time=-1)` | — | Begin countdown. Negative time uses `wait_time`. |
| `stop()` | — | Stop and reset to `wait_time`. |
| `time_left` | float | Seconds remaining. 0 if stopped. |

**Key signal:** `timeout`

:::callout-tip[One-shot alternative]
For a one-off delay without adding a node:

await get\_tree().create\_timer(2.0).timeout

. Cleaner for single-use delays in async functions.
:::

#### Tween

Created by code, not added as a scene node

Animates any property from a start to end value with an easing curve. The modern replacement for AnimationPlayer one-off property animations — create it via `create_tween()`, no node needed in the scene.

| Method | Notes |
| --- | --- |
| `tween_property(obj, prop, end, dur)` | Animates a property on an object. Returns a PropertyTweener for chaining. |
| `tween_callback(callable)` | Calls a function at this point in the sequence. |
| `tween_interval(seconds)` | Pauses the sequence. |
| `set_loops(count)` | 0 = infinite loop. Default 1. |
| `set_parallel(parallel)` | All tweeners after this run simultaneously (not chained). |
| `set_ease(ease) / set_trans(trans)` | Easing and transition type for the next tweener. |
| `kill()` | Stop and discard the tween immediately. |

```gdscript
# Bounce a button in, wait, then fade it out
var tw := create_tween().set_trans(Tween.TRANS_BOUNCE)
tw.tween_property(button, "scale", Vector2(1.2, 1.2), 0.15)
tw.tween_property(button, "scale", Vector2.ONE, 0.1)
tw.tween_interval(1.0)
tw.tween_property(button, "modulate:a", 0.0, 0.3)
```

#### Marker2D / Marker3D

Inherits: Node2D / Node3D

An invisible positional anchor with no functionality of its own. Use as spawn points, waypoints, attach points, or any named location in a scene. Zero runtime cost.

| Property | Type | Notes |
| --- | --- | --- |
| `gizmo_extents` | float | (3D only) Editor display size of the cross gizmo. Has no gameplay effect. |

:::callout-tip[Usage pattern]
Export an

Array[Marker3D]

on your spawner script, assign markers in the inspector, then pick from them:

spawn\_points.pick\_random().global\_position

.
:::

#### RemoteTransform2D / RemoteTransform3D

Inherits: Node2D / Node3D

Copies its own transform (or individual position/rotation/scale components) to a target node each frame. Useful for making a camera or UI element follow a game object without parenting it.

| Property | Type | Notes |
| --- | --- | --- |
| `remote_path` | NodePath | The target node that receives the transform. |
| `update_position/rotation/scale` | bool | Control which components are copied independently. |
| `use_global_coordinates` | bool | If true, copies world-space transform (otherwise local). |

#### RayCast2D / RayCast3D

Inherits: Node2D / Node3D

Tests a ray from the node's origin in a given direction for physics collisions each frame. Use for line-of-sight, ground detection, or weapon hit-scan.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `target_position` | Vector2/3 | End of the ray in local space. Length = ray length. |
| `enabled` | bool | Active casts every physics frame. Disable when not needed to save CPU. |
| `collision_mask` | int | Which physics layers to test against. |
| `is_colliding()` | bool | True if something was hit last physics frame. |
| `get_collider()` | Object | The node that was hit. |
| `get_collision_point()` | Vector2/3 | World-space hit position. |
| `get_collision_normal()` | Vector2/3 | Surface normal at hit point. |
| `force_raycast_update()` | — | Cast immediately (outside physics step). Use when you need a result in \_process. |

#### ShapeCast2D / ShapeCast3D

Inherits: Node2D / Node3D

Like RayCast but sweeps a shape (sphere, box, capsule, etc.) along a path instead of a zero-width ray. More accurate for thick objects like characters or projectiles.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `shape` | Shape2D/3D | The sweep shape (SphereShape3D, BoxShape3D, etc.). |
| `target_position` | Vector2/3 | End point of the sweep in local space. |
| `collision_result` | Array | All hits from last sweep. Each entry has collider, point, normal. |
| `get_collision_count()` | int | Number of collisions from last sweep. |

#### VisibleOnScreenNotifier2D/3D / Enabler

Inherits: Node2D / VisualInstance3D

**Notifier:** emits signals when its bounding box enters or exits the viewport. **Enabler:** a subclass that automatically pauses AnimationPlayer and physics on invisible nodes — free performance win.

| Type | Signal / Behaviour |
| --- | --- |
| `VisibleOnScreenNotifier2D/3D` | Signals `screen_entered` / `screen_exited`. Use to spawn/despawn off-screen enemies. |
| `VisibleOnScreenEnabler2D/3D` | Automatically disables process and physics when off-screen. No scripting needed. |

:::callout-tip[Free optimisation]
Add a VisibleOnScreenEnabler3D to every enemy and obstacle in your scene. It costs nothing and can eliminate dozens of

\_physics\_process

calls per frame when enemies are off-screen.
:::

## Path & Vehicle Nodes

#### Path2D + PathFollow2D 2D

Path2D inherits Node2D; PathFollow2D inherits Node2D

**Path2D** defines a Bezier spline. **PathFollow2D** (child of Path2D) moves along it by setting its `progress` or `progress_ratio`. Use for patrol routes, roller-coasters, scrolling backgrounds, or tutorial pointers.

| Property | Type | Notes |
| --- | --- | --- |
| `Path2D.curve` | Curve2D | The spline data. Draw in editor; edit control points to shape the path. |
| `PathFollow2D.progress` | float (metres) | Distance along the path from the start. Animate this to move. |
| `PathFollow2D.progress_ratio` | float 0–1 | Normalised progress. 0 = start, 1 = end. |
| `PathFollow2D.rotates` | bool | If true, the follower automatically rotates to face along the path tangent. |
| `PathFollow2D.loop` | bool | Wraps progress when it exceeds the path length. |

```gdscript
# Patrol NPC along a path at 80px/sec
func _process(delta: float) -> void:
    path_follow.progress += 80.0 * delta
```

#### Path3D + PathFollow3D 3D

Path3D inherits Node3D; PathFollow3D inherits Node3D

Same concept as Path2D/PathFollow2D but in 3D. The follower's transform (position + forward orientation) tracks the Bezier spline in world space.

| Property | Type | Notes |
| --- | --- | --- |
| `Path3D.curve` | Curve3D | 3D Bezier spline. Edit control points and tilts in the editor. |
| `PathFollow3D.progress` | float | Distance in metres from start. |
| `PathFollow3D.rotation_mode` | RotationMode | NONE, Y (yaw only), XYZ (full), ORIENTED (uses curve tilt). Use ORIENTED for roller-coasters. |
| `PathFollow3D.cubic_interp` | bool | Cubic interpolation = smoother position along curve. Default true. |

## Miscellaneous Nodes

#### MultiMeshInstance3D 3D

Inherits: GeometryInstance3D → Node3D

Renders thousands of identical mesh instances in a single draw call. Essential for foliage, crowds, rocks, coins — anything repeated at scale. Custom colours and transforms per instance.

| Property / Method | Type | Notes |
| --- | --- | --- |
| `multimesh` | MultiMesh | The resource holding instance data. Set `instance_count` to allocate. |
| `multimesh.instance_count` | int | Total slots. Allocating is expensive — do it once at startup. |
| `multimesh.visible_instance_count` | int | How many instances are actually drawn. -1 = all. Shrink this to hide instances. |
| `set_instance_transform(i, xform)` | — | Position/rotate instance i. Call for each instance after allocating. |
| `set_instance_color(i, color)` | — | Per-instance tint (requires `use_colors = true` on the MultiMesh). |

:::callout-tip[GPU instancing note]
MultiMeshInstance3D uses hardware instancing — all instances share one material and one mesh. If you need different meshes, use separate MultiMeshInstance3D nodes.
:::

#### Joint Nodes (2D & 3D)

Various — all inherit from Joint2D or Joint3D

Joints constrain two physics bodies to each other, allowing controlled relative motion (hinges, sliders, springs) while the physics engine maintains the constraint.

| Joint | 2D | 3D | Use case |
| --- | --- | --- | --- |
| Pin | PinJoint2D | — | Nail two bodies together at a pivot point. |
| Hinge | HingeJoint2D | HingeJoint3D | Doors, wheels, flaps. Rotation around one axis. |
| Slider | GrooveJoint2D | SliderJoint3D | Pistons, elevators. Linear motion along one axis. |
| Spring | DampedSpringJoint2D | — | Elastic connection with configurable stiffness and damping. |
| Ball | — | Generic6DOFJoint3D | Socket joint — free rotation in all axes with optional limits. |
| Cone Twist | — | ConeTwistJoint3D | Shoulder / ragdoll joints. Rotation limited to a cone. |

Set `node_a` and `node_b` (NodePaths to physics bodies) on every joint. The joint node's own position defines the pivot.

#### SubViewport + SubViewportContainer

SubViewport inherits Viewport → Node; Container inherits Control

Renders a scene (or part of one) into an off-screen texture. The texture can then be displayed on a Control, applied to a 3D mesh as a material, or processed as a RenderingTexture. Use for split-screen, minimap, security camera feeds, or in-world screens.

| Property | Type | Notes |
| --- | --- | --- |
| `size` | Vector2i | Render resolution. Can differ from displayed size. |
| `render_target_update_mode` | UpdateMode | DISABLED, ONCE, WHEN\_VISIBLE, ALWAYS. WHEN\_VISIBLE saves GPU when off-screen. |
| `transparent_bg` | bool | Renders with alpha channel for overlay compositing. |
| `get_texture()` | ViewportTexture | The rendered image as a texture resource. Assign to a mesh material, etc. |

:::callout-warning[Warning]
Each SubViewport is an additional render pass. Two SubViewports = three total renders per frame (main + two subs). Use WHEN\_VISIBLE and keep render sizes small for minimaps.
:::

## Quick Inheritance Map

Use this chart when you need to know "what does X inherit?" without opening the Godot docs.

```
Object
└── RefCounted (Resources, Materials, Meshes…)
└── Node
    ├── Node2D (CanvasItem)
    │   ├── CollisionObject2D
    │   │   ├── PhysicsBody2D
    │   │   │   ├── StaticBody2D / AnimatableBody2D
    │   │   │   ├── RigidBody2D
    │   │   │   └── CharacterBody2D
    │   │   └── Area2D
    │   ├── Sprite2D, AnimatedSprite2D, Line2D, Polygon2D
    │   ├── TileMapLayer
    │   ├── GPUParticles2D, CPUParticles2D
    │   ├── Camera2D
    │   ├── Path2D → PathFollow2D
    │   └── RayCast2D, ShapeCast2D
    ├── Node3D
    │   ├── VisualInstance3D
    │   │   ├── GeometryInstance3D
    │   │   │   ├── MeshInstance3D
    │   │   │   ├── MultiMeshInstance3D
    │   │   │   └── GPUParticles3D, CPUParticles3D
    │   │   ├── Light3D → DirectionalLight3D, OmniLight3D, SpotLight3D
    │   │   └── Decal, ReflectionProbe, LightmapGI
    │   ├── CollisionObject3D
    │   │   ├── PhysicsBody3D
    │   │   │   ├── StaticBody3D / AnimatableBody3D
    │   │   │   ├── RigidBody3D
    │   │   │   └── CharacterBody3D
    │   │   └── Area3D
    │   ├── Camera3D
    │   ├── Skeleton3D, BoneAttachment3D
    │   ├── NavigationRegion3D
    │   └── Path3D → PathFollow3D
    ├── Control (CanvasItem)
    │   ├── Label, RichTextLabel
    │   ├── BaseButton → Button, CheckBox, OptionButton…
    │   ├── LineEdit, TextEdit, CodeEdit
    │   ├── Range → ProgressBar, HSlider, VSlider, SpinBox
    │   ├── Container → VBox, HBox, Grid, Margin, Panel, Scroll…
    │   └── Window → Popup, AcceptDialog, ConfirmationDialog
    ├── AnimationPlayer, AnimationTree (AnimationMixer)
    ├── AudioStreamPlayer
    ├── Timer
    ├── NavigationAgent2D / NavigationAgent3D
    └── WorldEnvironment
```
