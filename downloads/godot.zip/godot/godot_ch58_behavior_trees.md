---
title: "Behavior Trees, Enemy AI Patterns & Perception"
source: "godot_ch58_behavior_trees.html"
---

Part IX · Chapter 58

# Behavior Trees, Enemy AI Patterns & Perception

Estimated study time: 95 min · Prerequisites: Ch 56 FSMs, Ch 57 Navigation

## Chapter Overview

Finite State Machines (Ch 56) are great for simple AI with a handful of states. When an enemy needs dozens of overlapping behaviours — patrol unless hungry, attack if close, flee if low health, call for help if cornered — FSMs become a spaghetti of transitions. Behavior Trees organise complex AI as a tree of prioritised tasks that the engine traverses every frame, selecting the right action automatically.

This chapter builds a lightweight, production-quality Behavior Tree framework from scratch in GDScript, then uses it to implement a full guard-type enemy with perception (line-of-sight vision cone and hearing radius).

:::callout-key[Key ideas]
BT nodes return Success, Failure, or Running. Sequences run children left-to-right until one fails. Selectors try children until one succeeds. Decorators modify a single child's result. Leaf nodes do actual work. A Blackboard shares data between nodes.
:::

## Behavior Tree Concepts

:::callout-intuition[Intuition]
A BT is like a flowchart that re-evaluates from the top every frame. The tree is traversed depth-first; the first leaf that says "I can do something useful" gets to run. If your highest-priority behaviour (Attack) can't run because the enemy has no target, the tree falls through to the next priority (Chase), then Patrol, then Idle.
:::

Selector  ?

try each child in order

Sequence  →

Attack plan

Sequence  →

Chase plan

Action

Patrol()

Condition

CanSeePlayer?

Action

Attack()

Condition

PlayerNearby?

Action

MoveToPlayer()

Tick propagation — every frame the tree is traversed depth-first:

SUCCESS

= task done, parent can proceed

FAILURE

= can't do it, parent tries next child

RUNNING

= multi-frame action in progress, tick again next frame

A guard enemy BT: the root *Selector* tries Attack first (highest priority), falls through to Chase, then Patrol. Each *Sequence* only succeeds if all its children succeed left-to-right — a failed Condition short-circuits the whole plan.

### Node Types

| Type | Children | Behaviour |
| --- | --- | --- |
| **Sequence** (→) | 1+ | Run children left-to-right. Return FAILURE on first child failure. Return SUCCESS if all succeed. |
| **Selector** (?) | 1+ | Try children left-to-right. Return SUCCESS on first child success. Return FAILURE if all fail. |
| **Parallel** (‖) | 1+ | Run all children simultaneously. Configurable success/failure threshold. |
| **Decorator** | Exactly 1 | Wraps a child: Inverter, Repeater, Timeout, Cooldown, Succeeder… |
| **Leaf / Action** | 0 | Does actual work: Move, Attack, PlayAnimation, Wait… |
| **Leaf / Condition** | 0 | Checks a fact: CanSeePlayer?, HealthLow?, InRange? |

### Status Values

| Status | Meaning | When to return it |
| --- | --- | --- |
| `SUCCESS` | Task completed successfully | Condition is true; action finished |
| `FAILURE` | Task cannot be done | Condition is false; action impossible |
| `RUNNING` | Task is in progress | Action takes multiple frames (moving, waiting) |

## Implementing a Lightweight BT in GDScript

### BTNode Base Class

```gdscript
# res://scripts/bt/bt_node.gd
class_name BTNode extends RefCounted

enum Status { SUCCESS, FAILURE, RUNNING }

# Override in subclasses
func tick(actor: Node, blackboard: Dictionary) -> Status:
    return Status.FAILURE
```

### Composites

```gdscript
# res://scripts/bt/sequence.gd
class_name BTSequence extends BTNode
# Runs children in order; fails on first failure

var children: Array[BTNode] = []
var _running_index := 0

func tick(actor: Node, bb: Dictionary) -> Status:
    for i in range(_running_index, children.size()):
        var result := children[i].tick(actor, bb)
        match result:
            Status.FAILURE:
                _running_index = 0
                return Status.FAILURE
            Status.RUNNING:
                _running_index = i   # resume here next tick
                return Status.RUNNING
            Status.SUCCESS:
                pass  # continue to next child
    _running_index = 0
    return Status.SUCCESS
```

```gdscript
# res://scripts/bt/selector.gd
class_name BTSelector extends BTNode
# Tries children in order; succeeds on first success

var children: Array[BTNode] = []
var _running_index := 0

func tick(actor: Node, bb: Dictionary) -> Status:
    for i in range(_running_index, children.size()):
        var result := children[i].tick(actor, bb)
        match result:
            Status.SUCCESS:
                _running_index = 0
                return Status.SUCCESS
            Status.RUNNING:
                _running_index = i
                return Status.RUNNING
            Status.FAILURE:
                pass  # try next child
    _running_index = 0
    return Status.FAILURE
```

```gdscript
# res://scripts/bt/inverter.gd  (decorator)
class_name BTInverter extends BTNode

var child: BTNode

func tick(actor: Node, bb: Dictionary) -> Status:
    var result := child.tick(actor, bb)
    match result:
        Status.SUCCESS: return Status.FAILURE
        Status.FAILURE: return Status.SUCCESS
        _:              return result  # RUNNING unchanged
```

```gdscript
# res://scripts/bt/cooldown.gd  (decorator — prevents re-entry for N seconds)
class_name BTCooldown extends BTNode

var child: BTNode
var cooldown_time: float
var _remaining := 0.0

func tick(actor: Node, bb: Dictionary) -> Status:
    _remaining -= bb.get("delta", 0.016)
    if _remaining > 0.0:
        return Status.FAILURE
    var result := child.tick(actor, bb)
    if result == Status.SUCCESS:
        _remaining = cooldown_time
    return result
```

### Leaf Nodes — Conditions and Actions

```gdscript
# Condition: is the player visible?
class_name BTConditionCanSeePlayer extends BTNode

func tick(actor: Node, bb: Dictionary) -> Status:
    var player: Node2D = bb.get("player")
    if player == null:
        return Status.FAILURE
    # Check line-of-sight (detailed in Perception section)
    return Status.SUCCESS if actor.can_see(player) else Status.FAILURE
```

```gdscript
# Action: move toward blackboard target
class_name BTActionMoveToTarget extends BTNode

const ARRIVE_DIST := 20.0

func tick(actor: Node, bb: Dictionary) -> Status:
    var target_pos: Vector2 = bb.get("target_position", actor.global_position)
    var nav_agent: NavigationAgent2D = actor.get_node("NavigationAgent2D")

    if nav_agent.target_position != target_pos:
        nav_agent.target_position = target_pos

    if nav_agent.is_navigation_finished():
        return Status.SUCCESS

    var next := nav_agent.get_next_path_position()
    var dir  := (next - actor.global_position).normalized()
    var speed: float = bb.get("move_speed", 100.0)
    actor.velocity = dir * speed
    actor.move_and_slide()
    return Status.RUNNING
```

```gdscript
# Action: wait N seconds
class_name BTActionWait extends BTNode

var duration: float
var _elapsed := 0.0

func tick(actor: Node, bb: Dictionary) -> Status:
    _elapsed += bb.get("delta", 0.016)
    if _elapsed >= duration:
        _elapsed = 0.0
        return Status.SUCCESS
    return Status.RUNNING
```

## The Blackboard Pattern

A Blackboard is a shared Dictionary passed to every `tick()` call. Conditions write perceived data (player position, alert level) and actions read it. This decouples perception from decision-making.

```gdscript
# On the enemy CharacterBody2D:
var blackboard: Dictionary = {
    "delta":           0.0,
    "player":          null,
    "player_last_seen_pos": Vector2.ZERO,
    "alert_level":     0.0,    # 0 = unaware, 1 = fully alerted
    "move_speed":      100.0,
    "attack_damage":   10,
    "health":          100,
    "target_position": Vector2.ZERO,
}

var behavior_tree: BTNode  # root of the tree

func _ready() -> void:
    behavior_tree = _build_tree()

func _physics_process(delta: float) -> void:
    blackboard["delta"] = delta
    _update_perception()     # write player/alert data to blackboard
    behavior_tree.tick(self, blackboard)

func _build_tree() -> BTNode:
    # Built programmatically — see the Guard BT section for a full example
    return BTSelector.new()
```

Blackboard (Dictionary)

"player":        node

"alert\_level":   0.8

"last\_seen\_pos": vec2

"health":        65

"target\_pos":    vec2

passed to every tick()

Perception

vision cone, hearing

writes

Condition Leaves

CanSeePlayer?, HealthLow?

reads

Action Leaves

MoveToPlayer, Attack

reads

Composites

Selector, Sequence

writes

The Blackboard is a shared Dictionary threaded through every `tick()` call. Perception writes sensory data; Condition leaves read it to make decisions; Action leaves read targets and write results — all without any node needing a direct reference to another.

## Perception — Vision & Hearing

### Vision Cone (Line of Sight)

A vision cone checks two things: angle (is the player within the enemy's field of view?) and occlusion (is there a wall in the way?).

```gdscript
# On the enemy node:
const SIGHT_RANGE    := 250.0
const SIGHT_ANGLE    := 70.0  # degrees half-angle (full FOV = 140°)
const SIGHT_MASK     := 1      # physics layer for walls

var facing_direction := Vector2.RIGHT  # updated from velocity

func can_see(target: Node2D) -> bool:
    var to_target := target.global_position - global_position
    var distance  := to_target.length()

    # 1. Range check
    if distance > SIGHT_RANGE:
        return false

    # 2. Angle check
    var angle_to := rad_to_deg(facing_direction.angle_to(to_target.normalized()))
    if abs(angle_to) > SIGHT_ANGLE:
        return false

    # 3. Line-of-sight raycast
    var space  := get_world_2d().direct_space_state
    var params := PhysicsRayQueryParameters2D.create(
        global_position, target.global_position, SIGHT_MASK
    )
    params.exclude = [self]
    var hit := space.intersect_ray(params)
    return hit.is_empty()  # no wall between us and the target

func _physics_process(delta: float) -> void:
    if velocity.length() > 10.0:
        facing_direction = velocity.normalized()
```

### Hearing

Hearing is simpler — a radius check, potentially reduced by a "noise level" the player emits (running vs. crouching).

```gdscript
const HEAR_RANGE_BASE   := 150.0
const HEAR_RANGE_SPRINT := 280.0  # louder when sprinting

func can_hear(target: Node2D) -> bool:
    var dist         := global_position.distance_to(target.global_position)
    var noise_radius := HEAR_RANGE_SPRINT if target.is_sprinting else HEAR_RANGE_BASE
    return dist <= noise_radius

func _update_perception() -> void:
    var player: Node2D = get_node_or_null("/root/World/Player")
    if player == null: return

    blackboard["player"] = player

    if can_see(player) or can_hear(player):
        blackboard["alert_level"] = min(blackboard["alert_level"] + 2.0 * blackboard["delta"], 1.0)
        blackboard["player_last_seen_pos"] = player.global_position
    else:
        blackboard["alert_level"] = max(blackboard["alert_level"] - 0.3 * blackboard["delta"], 0.0)
```

## Common AI Patterns

### Patrol Behavior Tree

```
Selector
  ├── Sequence [alert: attack if alerted]
  │     ├── Condition: alert_level >= 1.0
  │     └── Action: AttackPlayer
  ├── Sequence [chase if partially alerted]
  │     ├── Condition: alert_level >= 0.5
  │     └── Action: MoveToLastSeenPosition
  └── Sequence [patrol if calm]
        ├── Action: MoveToNextWaypoint
        └── Action: Wait(1.0s)
```

### Full Guard BT — Code

```gdscript
func _build_tree() -> BTNode:
    # ── Leaf nodes ───────────────────────────────────────────────
    var cond_fully_alerted := _condition(
        func(actor, bb): return bb.get("alert_level", 0.0) >= 1.0
    )
    var cond_partially_alerted := _condition(
        func(actor, bb): return bb.get("alert_level", 0.0) >= 0.5
    )
    var cond_has_target := _condition(
        func(actor, bb): return bb.get("player") != null
    )

    var act_attack := _action(func(actor, bb) -> BTNode.Status:
        var player: Node2D = bb.get("player")
        if not actor.global_position.distance_to(player.global_position) < 50.0:
            return BTNode.Status.FAILURE
        actor.attack()
        return BTNode.Status.SUCCESS
    )

    var act_move_to_player := _action(func(actor, bb) -> BTNode.Status:
        var player: Node2D = bb.get("player")
        bb["target_position"] = player.global_position
        return BTActionMoveToTarget.new().tick(actor, bb)
    )

    var act_move_to_last_seen := _action(func(actor, bb) -> BTNode.Status:
        bb["target_position"] = bb.get("player_last_seen_pos", actor.global_position)
        return BTActionMoveToTarget.new().tick(actor, bb)
    )

    var act_patrol := BTActionPatrol.new()
    act_patrol.waypoints = _get_waypoints()

    var act_wait := BTActionWait.new()
    act_wait.duration = 1.5

    # ── Composites ───────────────────────────────────────────────
    # Branch 1: fully alerted → chase and attack
    var seq_attack := BTSequence.new()
    seq_attack.children = [cond_fully_alerted, cond_has_target, act_move_to_player, act_attack]

    # Branch 2: partially alerted → move to last seen position
    var seq_investigate := BTSequence.new()
    seq_investigate.children = [cond_partially_alerted, act_move_to_last_seen, act_wait]

    # Branch 3: calm → patrol
    var seq_patrol := BTSequence.new()
    seq_patrol.children = [act_patrol, act_wait]

    # Root selector
    var root := BTSelector.new()
    root.children = [seq_attack, seq_investigate, seq_patrol]
    return root

# Helper: create an inline condition node from a callable
func _condition(check: Callable) -> BTNode:
    var node := BTNode.new()
    node.tick = func(actor, bb): return BTNode.Status.SUCCESS if check.call(actor, bb) else BTNode.Status.FAILURE
    return node

# Helper: create an inline action node from a callable
func _action(action_fn: Callable) -> BTNode:
    var node := BTNode.new()
    node.tick = action_fn
    return node
```

:::callout-tip[Inline nodes via Callables]
Overriding

tick

with a Callable (the

node.tick = func(…)

pattern) lets you write simple leaf nodes inline without creating a new file per node. Use full subclasses only for nodes you reuse across multiple characters.
:::

## BT vs. FSM — When to Use Which

| Situation | Prefer | Why |
| --- | --- | --- |
| Simple enemy, <6 states | FSM | Less overhead, easier to reason about |
| Complex priority hierarchy | BT | Priority handled automatically by tree structure |
| Many overlapping conditions | BT | Avoids transition explosion |
| Reusable AI behaviour modules | BT | Subtrees can be composed without modifying the character |
| Team without AI programmers | BT + visual editor plugin | Designers can author trees without code |
| Animation-driven character | FSM + AnimationTree | Tighter coupling to animation state |
| Rapid prototyping | FSM | Faster to write, easier to debug |

:::callout-tip[Hybrid approach]
Use a FSM for top-level states (Patrol, Combat, Flee, Dead) and a BT within the Combat state to select between Attack, Block, Reposition, and CallForHelp. This gives you clean state boundaries with flexible in-state decision making.
:::

:::callout-pitfall[Pitfall 1 — Not resetting RUNNING state on interruption]
If a higher-priority branch interrupts a RUNNING leaf, the leaf's internal state (e.g.,

\_elapsed

in BTActionWait) is never reset. Add a

reset()

method to your BTNode base and call it when a branch is interrupted by a higher-priority selector.
:::

:::callout-pitfall[Pitfall 2 — Raycast excluding wrong objects]
The sight raycast must exclude the enemy itself (or it immediately hits its own collision shape) and optionally exclude other enemies. Pass

[self]

plus any irrelevant bodies in

PhysicsRayQueryParameters2D.exclude

.
:::

:::callout-pitfall[Pitfall 3 — Ticking too often]
Running a complex BT with 20+ nodes every physics frame (60×/s) is often wasteful. Tick the BT every 0.1–0.2s for AI decisions; move and physics can still run every frame using the last-known velocity from the BT.
:::

:::summary
### Chapter 58 Summary

| Concept | Implementation |
| --- | --- |
| BT node | Class extending RefCounted with `tick(actor, bb) → Status` |
| Sequence | Runs children until one fails — all must succeed |
| Selector | Tries children until one succeeds — first success wins |
| Condition leaf | Returns SUCCESS/FAILURE based on a fact check |
| Action leaf | Does work; returns RUNNING until complete |
| Blackboard | Dictionary passed to every tick(); shared read/write store |
| Vision cone | Range check + angle check + raycast for occlusion |
| Hearing | Distance to target vs. noise\_radius (varies by player action) |
| Alert level | Float 0–1, rises on perception, decays over time |
| Throttle BT tick | Run BT every 0.1–0.2s; physics runs every frame |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Health-Check Condition**

Write a `BTConditionHealthLow` leaf node that returns SUCCESS when the actor's `health` property falls below a configurable `threshold` (default 30). Show how to wire it into a selector so an enemy flees when health is low, otherwise attacks.

::::solution[Solution]
```gdscript
class_name BTConditionHealthLow extends BTNode

var threshold := 30

func tick(actor: Node, _bb: Dictionary) -> Status:
    return Status.SUCCESS if actor.health <= threshold else Status.FAILURE

# Wiring:
func _build_tree() -> BTNode:
    var cond_low_hp := BTConditionHealthLow.new()
    cond_low_hp.threshold = 30

    var seq_flee := BTSequence.new()
    seq_flee.children = [cond_low_hp, BTActionFlee.new()]

    var seq_attack := BTSequence.new()
    seq_attack.children = [BTConditionCanSeePlayer.new(), BTActionAttack.new()]

    var root := BTSelector.new()
    root.children = [seq_flee, seq_attack]  # flee has priority
    return root
```
::::
:::

:::problem{difficulty="easy"}
**2. BTRepeater Decorator**

Write a `BTRepeater` decorator that runs its child N times (configurable), ignoring SUCCESS or FAILURE after each run, and returns SUCCESS after all N repetitions. Show it being used to make an enemy play an idle animation 3 times before patrolling.

::::solution[Solution]
```gdscript
class_name BTRepeater extends BTNode

var child: BTNode
var repeat_count: int = 3
var _count := 0

func tick(actor: Node, bb: Dictionary) -> Status:
    if _count >= repeat_count:
        _count = 0
        return Status.SUCCESS
    var result := child.tick(actor, bb)
    if result != Status.RUNNING:
        _count += 1  # child finished one iteration
    return Status.RUNNING  # always running until count reached

# Usage:
var idle_anim := BTActionPlayAnimation.new()
idle_anim.animation_name = "idle"

var repeater := BTRepeater.new()
repeater.child = idle_anim
repeater.repeat_count = 3

var seq := BTSequence.new()
seq.children = [repeater, BTActionPatrol.new()]
```
::::
:::

:::problem{difficulty="standard"}
**3. Alert Level Integration**

Extend the `_update_perception` function so that hearing range is affected by the environment: if the blackboard contains a `"noise_multiplier"` key (e.g., 0.5 in a carpeted room, 2.0 outdoors), scale the base hearing range by it. Also add a visual debug indicator: when `alert_level >= 0.5`, draw a yellow exclamation mark above the enemy using a Label3D or a CanvasItem.

::::solution[Solution]
```gdscript
func _update_perception() -> void:
    var player := get_node_or_null("/root/World/Player") as Node2D
    if not player: return
    blackboard["player"] = player

    var noise_mult: float = blackboard.get("noise_multiplier", 1.0)
    var hear_range := HEAR_RANGE_BASE * noise_mult
    if player.is_sprinting:
        hear_range = HEAR_RANGE_SPRINT * noise_mult

    var dist := global_position.distance_to(player.global_position)
    var perceived := can_see(player) or dist <= hear_range

    if perceived:
        blackboard["alert_level"] = min(blackboard["alert_level"] + 2.0 * blackboard["delta"], 1.0)
        blackboard["player_last_seen_pos"] = player.global_position
    else:
        blackboard["alert_level"] = max(blackboard["alert_level"] - 0.3 * blackboard["delta"], 0.0)

    # Visual indicator
    var alert_label: Label = $AlertLabel  # a Label node above the enemy
    if blackboard["alert_level"] >= 1.0:
        alert_label.text = "!"
        alert_label.modulate = Color.RED
        alert_label.visible = true
    elif blackboard["alert_level"] >= 0.5:
        alert_label.text = "?"
        alert_label.modulate = Color.YELLOW
        alert_label.visible = true
    else:
        alert_label.visible = false
```
::::
:::

:::problem{difficulty="standard"}
**4. Group Alert — Call For Help**

When an enemy spots the player and becomes fully alerted, it should broadcast a signal to all nearby enemies (within 300 units) causing them to also set their `alert_level` to 1.0 and update `player_last_seen_pos`. Implement this as a `BTActionCallForHelp` leaf node. Include a cooldown so the call happens at most once every 5 seconds.

::::solution[Solution]
```gdscript
class_name BTActionCallForHelp extends BTNode

const CALL_RANGE := 300.0
var _cooldown := 0.0

func tick(actor: Node, bb: Dictionary) -> Status:
    _cooldown -= bb.get("delta", 0.016)
    if _cooldown > 0.0:
        return Status.SUCCESS  # already called recently

    _cooldown = 5.0
    var player_pos: Vector2 = bb.get("player_last_seen_pos", actor.global_position)

    # Find all enemies in group within range
    for enemy in actor.get_tree().get_nodes_in_group("enemies"):
        if enemy == actor: continue
        if not enemy is CharacterBody2D: continue
        var dist := actor.global_position.distance_to(enemy.global_position)
        if dist <= CALL_RANGE:
            enemy.blackboard["alert_level"]        = 1.0
            enemy.blackboard["player_last_seen_pos"] = player_pos

    return Status.SUCCESS
```

Wire it into the attack sequence as an optional step: `[cond_fully_alerted, act_call_for_help, act_attack]`. Since it returns SUCCESS immediately, the sequence continues to the attack action.
::::
:::

:::problem{difficulty="challenge"}
**5. Full Guard Enemy**

Build a complete guard enemy using everything in this chapter: a BT with patrol/investigate/attack branches, a vision cone (90° FOV, 200px range, blocked by walls on layer 1), hearing (100px base, 200px if player is running), a call-for-help action with 5s cooldown, and a flee branch when health < 25%. The patrol route has 3 waypoints. Show the `_build_tree()` method and the scene tree structure.

::::solution[Solution]
Scene tree:

```gdscript
Guard (CharacterBody2D)
  ├── Sprite2D
  ├── CollisionShape2D
  ├── NavigationAgent2D (avoidance_enabled: true)
  ├── AlertLabel (Label, visible: false)
  ├── SightArea (Area2D, range=200px circle)
  └── Waypoints
        ├── WP1 (Marker2D)
        ├── WP2 (Marker2D)
        └── WP3 (Marker2D)
```

```gdscript
func _build_tree() -> BTNode:
    # Conditions
    var c_alerted   := _cond(func(a, bb): return bb.get("alert_level", 0.0) >= 1.0)
    var c_partial   := _cond(func(a, bb): return bb.get("alert_level", 0.0) >= 0.5)
    var c_low_hp    := _cond(func(a, bb): return a.health < 25)
    var c_has_player := _cond(func(a, bb): return bb.get("player") != null)

    # Actions
    var a_flee      := BTActionFlee.new()
    var a_attack    := BTActionAttack.new()
    var a_call_help := BTActionCallForHelp.new()
    var a_chase     := BTActionMoveToPlayer.new()
    var a_investigate := BTActionMoveToLastSeen.new()
    var a_patrol    := BTActionPatrol.new()
    a_patrol.waypoints = _get_waypoints()
    var a_wait      := BTActionWait.new()
    a_wait.duration = 1.5

    # Branches (highest priority first in selector)
    var b_flee := BTSequence.new()
    b_flee.children = [c_low_hp, a_flee]

    var b_attack := BTSequence.new()
    b_attack.children = [c_alerted, c_has_player, a_call_help, a_chase, a_attack]

    var b_investigate := BTSequence.new()
    b_investigate.children = [c_partial, a_investigate, a_wait]

    var b_patrol := BTSequence.new()
    b_patrol.children = [a_patrol, a_wait]

    var root := BTSelector.new()
    root.children = [b_flee, b_attack, b_investigate, b_patrol]
    return root

func _cond(check: Callable) -> BTNode:
    var n := BTNode.new()
    n.tick = func(a, bb): return BTNode.Status.SUCCESS if check.call(a, bb) else BTNode.Status.FAILURE
    return n
```
::::
:::
