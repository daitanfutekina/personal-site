---
title: "Welcome to Godot 4.6 — Install, Project Manager & Your First Scene"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 1"
meta:
  - "Est. study time: ~60 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch1_welcome.html"
---

## Overview

By the end of this chapter you'll have Godot 4.6 installed, a project created, a
 scene on screen, and a working GDScript that prints to the console and moves an
 object. Everything that follows in this book builds on these three moves: **create
 a node, attach a script, run the scene**.

This chapter is intentionally short on theory — the goal is to get you to a running game
 loop as fast as possible. Deeper explanations of nodes, the scene tree, and GDScript
 arrive in Chapters 3 and 4. Here you just need to get the engine open and touch it.

:::callout-key[Prerequisites]
- You know how to program — variables, loops, functions, and classes in any language.
- You have never used Godot before (or you're starting fresh with 4.x after time away from 3.x).
- You have a Windows, macOS, or Linux desktop. (Mobile/web export comes in Ch 63.)
:::

:::callout-key[Godot 4.6 — May 2026]
This chapter targets the stable 4.6.x release. One thing worth knowing early, because
 the internet will tell you otherwise: 4.6 ships **two** 3D physics engines in
 the same binary, and the one you get by default is still **Godot Physics**.
 **Jolt Physics** is there and is a single dropdown away — Project
 Settings → Physics → 3D → Physics Engine — but you have to ask for it.
 Don't worry about which yet; Part IV covers what actually changes when you switch.
:::

## 1. What is Godot?

:::callout-intuition[The big picture first]
Godot is a free, open-source game engine. You use it to build 2D and 3D games,
 then export them to Windows, macOS, Linux, Web, Android, and iOS. Unlike Unity or
 Unreal, Godot has no subscription fee, no royalty, and no required account — you
 download a single executable (under 100 MB) and that's the entire engine.
:::

Under the hood, Godot organizes every game as a tree of **nodes**. A node
 is a reusable building block — a sprite, a collision shape, a camera, a sound player, a
 script runner. You compose these nodes into **scenes**, and scenes into
 larger scenes, recursively. That's the core mental model, and it's the thing Chapter 3
 will fully unpack. For now, just hold onto: *everything in Godot is a node, nodes
 live in scenes, scenes are files you can reuse*.

The scripting language you'll use in this book is **GDScript** — a
 Python-like language built specifically for Godot. It's fast to write, reads cleanly, and
 has first-class editor integration (autocomplete, in-editor docs, live debugging). You
 can also use C# or C++, but GDScript is the right default for learning the engine.

### Why Godot over Unity or Unreal?

This isn't a debate chapter, but it's worth being honest about trade-offs so you know
 what you're getting into.

| Engine | Cost | Strengths | Weaknesses vs Godot |
| --- | --- | --- | --- |
| **Godot 4.6** | Free, MIT | Lightweight, fast iteration, GDScript, great 2D, great for indie/jam | Smaller ecosystem, fewer AAA-grade assets, less 3D maturity than UE5 |
| Unity 2024 | Free tier, then seat-based | Massive asset store, huge community, strong mobile track record | Runtime fee controversy, heavier editor, C# required |
| Unreal 5 | Free, 5% royalty above $1M | Best-in-class 3D visuals (Nanite, Lumen), AAA-grade tools | Very heavy (100+ GB), C++ or visual scripting, overkill for 2D/indie |

Godot wins on simplicity, speed of iteration, and zero licensing cost. It's the best
 engine for learning game development without fighting the tool, and it's increasingly
 competitive for shipped indie games. The games in this book's Part XIII are all
 realistic Godot projects: 2D roguelites, card games, physics puzzles.

:::callout-tip[GDScript vs C#]
The standard Godot download uses GDScript. There's a separate ".NET" download for
 C#. Unless you have a specific reason to use C# (existing C# codebase, strong
 preference), use the standard version. Chapter 12 covers the differences in detail.
:::

## 2. Installing Godot 4.6

:::callout-intuition[Why installation is trivial]
Godot ships as a single self-contained executable. There is no installer, no
 registry entry, no system dependency. Download it, put it anywhere, double-click
 it. That's the entire install. Uninstalling is deleting the file.
:::

### Step-by-step: download and launch

1. Go to **godotengine.org** and click **Download**. Choose the
 **Standard version** (not .NET) for your OS.
2. On Windows: extract the `.zip` — you'll get a single
 `Godot_v4.6-stable_win64.exe` file. On macOS: open the
 `.dmg` and drag the app to Applications. On Linux: extract the
 `.tar.xz` anywhere, make it executable with `chmod +x`.
3. Double-click the executable. No UAC prompt, no splash screen asking for an account.
 The **Project Manager** opens immediately.
4. *Optional but recommended:* pin it to your taskbar/dock. You'll open it a lot.

:::callout-warning[macOS Gatekeeper]
On macOS, the first launch may be blocked with "cannot be opened because the developer
 cannot be verified." Right-click (or Control-click) the app icon and choose
 **Open**. On the dialog that appears, click **Open** again.
 This only happens once.
:::

### Standard vs .NET — which download?

The download page offers two flavors. Here's the actual difference:

Standard (use this)

Uses GDScript (and optionally GDExtension/C++) as scripting languages.
 Smaller binary (~85 MB on Windows), faster startup, no .NET SDK required.
 This is what 90% of Godot developers use.

.NET (C# only, skip for now)

Adds the Mono/.NET runtime and lets you write scripts in C#. Requires the
 .NET 8 SDK installed separately. About 2× larger binary. Use this only if you
 already know C# and want it for a specific project. GDScript and C# cannot be
 mixed in the same project easily.

## 3. The Project Manager

:::callout-intuition[Think of it as a launcher, not an IDE]
The Project Manager is the first screen you see when you launch Godot. Its job is
 simple: let you create, open, import, and organize your projects. Each project is a
 folder on disk. The manager just remembers which folders you care about.
:::

The Project Manager. Your project list will be empty on a fresh install.
 Source: Godot documentation (CC BY 3.0).

The interface has three main areas:

- **Project list** (center) — all your known projects, with their name, path, and last-edited time.
- **Top toolbar** — New, Import, Scan, Edit, Run, Rename, Remove.
- **Asset Library tab** — browse community addons and demos (requires internet).

### Creating your first project

1. Click **New Project** (top-left area). A dialog appears asking for a
 project name and path.
2. Type a name — let's use `hello_godot`. Then click
 **Browse** to pick where on disk the project folder should live.
 Godot creates a subfolder with your project name inside whatever folder you pick.
3. Choose your renderer (see below). Leave it on **Forward+** for now.
4. Click **Create & Edit**. The editor opens.

### Choosing a renderer

Godot 4 ships with three rendering backends. You pick one per project (you can
 change it later in Project Settings, but it's worth picking right the first time):

| Renderer | API | Best for | Notes |
| --- | --- | --- | --- |
| **Forward+** | Vulkan | 3D games, modern desktops | Best 3D fidelity. Requires a decent GPU. Default for 3D projects. |
| **Mobile** | Vulkan (mobile profile) | 3D games targeting mobile/low-end | Reduced shader complexity. Good for cross-platform 3D. |
| **Compatibility** | OpenGL 3.3 / WebGL 2 | 2D games, web export, old hardware | Best for 2D. Required for Web export. Fewer 3D post-processing effects. |

:::callout-tip[Rule of thumb]
Making a 2D game? Pick **Compatibility**. Making a 3D game for
 desktop? Pick **Forward+**. Making a 3D game for mobile or web? Pick
 **Mobile**. You can always change it later in
 *Project → Project Settings → Rendering → Renderer*.
:::

## 4. The Editor at a Glance

When a project opens you'll see the main editor. It looks busy at first. Here's a
 fast map so nothing surprises you. (Chapter 2 goes deep on every dock and toolbar.)

The five main areas of the Godot editor. Source: Godot documentation (CC BY 3.0).

| Area | Where | What it does |
| --- | --- | --- |
| **Menu bar** | Very top | Scene, Project, Debug, Editor, Help menus. Also the Play ▶ / Stop ■ buttons. |
| **Scene dock** | Top-left | Shows the node tree for the current scene. You add/delete/rearrange nodes here. |
| **FileSystem dock** | Bottom-left | Your project's files on disk — scripts, textures, scenes, audio, everything. |
| **Viewport** | Center | The visual canvas. Click and drag to move nodes. Switch between 2D, 3D, Script, and AssetLib tabs at the top. |
| **Inspector** | Right panel | Properties of the selected node. Position, scale, texture, custom export vars — all editable here. |
| **Output / Debugger** | Bottom panel | Where `print()` output goes. Also shows errors, warnings, and profiler data. |

:::callout-pitfall[Common new-user confusion]
- **The viewport is empty on first open.** That's normal — you haven't created a scene yet. The editor is waiting for you to add nodes.
- **No "save project" button.** Godot auto-saves project settings. You manually save *scenes* (Ctrl+S) and scripts are auto-saved when you switch away from them.
- **Can't find the Output panel?** It's the bottom dock. Click **Output** on the bottom bar if it's collapsed.
:::

## 5. Your First Scene

:::callout-intuition[What a scene actually is]
A scene in Godot is just a tree of nodes saved as a `.tscn` file.
 Every game is made of scenes — a "Player" scene, a "Level" scene, a "HUD" scene.
 You run a scene; Godot loads the tree of nodes in it and starts the game loop.
 Your first scene will have exactly two nodes: a root node and a sprite.
:::

### Adding nodes to a scene

1. In the **Scene dock** (top-left), click the **+** button
 (or press Ctrl+A). The "Create New Node" dialog opens with a search
 field at the top.
2. Type `Node2D` and double-click it (or press Enter). A node called
 "Node2D" appears at the top of the scene tree. This is your scene's **root
 node** — every other node will be a child of this one.
3. Make sure **Node2D** is selected in the tree. Press Ctrl+A
 again. This time type `Sprite2D` and create it. It appears as a child of
 Node2D, with a placeholder "No Texture" icon in the viewport.
4. With **Sprite2D** selected, look at the **Inspector** on
 the right. Find the **Texture** property. Click the empty slot next to
 it, choose **Load**, and navigate to any image file (PNG or JPG). If you
 don't have one handy: in the FileSystem dock, drag the Godot icon
 (`icon.svg` — it's in your project root by default) onto the Texture slot.
5. You should now see the sprite appear in the viewport's center. Left-click and drag it
 to reposition it.

:::example[Walkthrough A — Setting up a Node2D + Sprite2D scene from scratch]
Goal: Create a scene with a root Node2D and a child Sprite2D showing Godot's default
 icon, positioned at (200, 200). Save it and verify it appears in the FileSystem dock.

::::answer[Result]
You'll have a file called `main.tscn` in your project root. The scene
 tree shows Node2D → Sprite2D. The icon appears at (200, 200) in the viewport.
::::

Steps in detail

1. Scene dock → **+** → type `Node2D` → Create.
2. Right-click "Node2D" in the tree → **Rename** → type `Main`.
3. Select Main → Ctrl+A → `Sprite2D` → Create.
4. With Sprite2D selected: Inspector → Texture → drag `icon.svg` from FileSystem onto the Texture slot.
5. In the Inspector, expand **Transform** → set Position to `x: 200, y: 200`.
6. Press Ctrl+S to save. Name the file `main.tscn`. Click Save.
7. Check the FileSystem dock — you'll see `main.tscn` listed.
:::

### Saving and running the scene

You've built a scene. Now run it. Before hitting play, you need to tell Godot which
 scene is the **main scene** — the one it starts when you press Play.

1. Press F5 (or the ▶ Play button in the top bar). A dialog asks you to
 select a main scene. Click **Select**, then choose `main.tscn`.
 Godot remembers this for future runs.
2. The game window opens. You should see the Godot icon on a gray background.
 That's your running game. Not exciting yet — scripting comes in the next section.
3. Close the game window (or press F8 / the ■ Stop button).

:::callout-tip[F6 vs F5]
F5 runs the *project's main scene* (whatever you set as the
 starting point). F6 runs the *currently open scene* regardless
 of what the main scene is. When testing an individual scene in isolation,
 F6 is faster.
:::

:::callout-pitfall[Watch out for]
- **Forgetting to save before running.** Unsaved changes to a scene don't apply when you press Play. Always Ctrl+S first. (The scene tab shows a dot • next to its name when there are unsaved changes.)
- **The node tree is wrong after pressing Play.** In the editor, the remote debugger connects and shows the live scene tree — it can look different from the editor tree if you've added/removed nodes at runtime. This is normal and intentional.
- **"No scene has been set as the main scene."** You either dismissed the dialog without selecting one, or your `main.tscn` has a parse error. Check Output for red errors.
:::

## 6. Your First Script

:::callout-intuition[Scripts are attached to nodes]
In Godot, a script is not a standalone file that runs on its own — it's
 *attached to a node*. When that node enters the scene tree, the script
 starts running. Think of each script as the "brain" of its node. A Sprite2D node
 with no script is just a picture; a Sprite2D with a script can move, animate, react
 to input, and communicate with other nodes.
:::

### Attaching a script to a node

1. In the Scene dock, select your **Main** (Node2D) node.
2. Right-click it → **Attach Script**. Alternatively, click the small
 script icon in the top-right of the Scene dock toolbar.
3. The "Attach Node Script" dialog opens. Leave all defaults (GDScript, no template,
 path auto-filled as `res://main.gd`). Click **Create**.
4. The Script editor opens with a starter template. The script view replaces the
 viewport. You can switch back to the 2D viewport at any time using the tabs at
 the very top of the editor (**2D / 3D / Script / AssetLib**).

### The two lifecycle functions: \_ready() and \_process()

Every GDScript starts with at least these two functions. They're called by the engine
 automatically — you never call them yourself.

\_ready()

Called **once**, when the node first enters the scene tree (just before
 the first frame). Use it for initialization: loading data, connecting signals,
 finding child nodes. If you've used other engines or frameworks, this is like
 `Start()` in Unity or `componentDidMount` in React.

\_process(delta)

Called **every frame**, as fast as the engine can render. The
 `delta` parameter is the time in seconds since the last frame
 (typically ~0.016 at 60 fps). Use it for anything that needs continuous updating:
 movement, timers, animation state. **Always multiply movement by
 `delta`** to keep speed frame-rate-independent.

There's a third important one you'll meet soon: `_physics_process(delta)`,
 which runs at a fixed rate (default 60 Hz) regardless of render fps. Use it for
 physics and collision code. For now, `_process(delta)` is enough.

### Worked examples

:::example[Example 6.1 — Print a message on startup]
Make the Main node print "Hello, Godot!" to the Output panel when the scene starts.

::::answer[Result]
Run the scene (F5). The Output panel at the bottom shows:
 `Hello, Godot!`
::::

Script (res://main.gd)

```gdscript
extends Node2D

func _ready() -> void:
    print("Hello, Godot!")
```

**Line by line:**
 `extends Node2D` tells GDScript this script inherits from Node2D (matching
 the node type it's attached to). `func _ready() -> void:` declares the
 lifecycle function with an explicit return-type annotation of `void`.
 `print("Hello, Godot!")` sends text to the Output dock — the equivalent
 of `console.log` in JavaScript or `print()` in Python.
:::

:::example[Example 6.2 — Move the sprite across the screen]
Make the Sprite2D child node move to the right at 200 pixels per second, frame-rate
 independently. When it goes off the right edge of the screen, wrap it back to the left.

::::answer[Result]
The icon slides right across the screen, then reappears from the left side —
 endlessly. Works at any frame rate.
::::

Script (res://main.gd)

```gdscript
extends Node2D

const SPEED: float = 200.0  # pixels per second

@onready var sprite: Sprite2D = $Sprite2D  # get child node at scene start

func _ready() -> void:
    print("Scene ready. Sprite at: ", sprite.position)

func _process(delta: float) -> void:
    # Move the sprite to the right
    sprite.position.x += SPEED * delta

    # Wrap around when it goes off the right edge
    var viewport_width: float = get_viewport_rect().size.x
    if sprite.position.x > viewport_width + 64:
        sprite.position.x = -64.0
```

What each part does

- `const SPEED: float = 200.0` — a module-level constant. Constants
 are declared with `const`, variables with `var`.
 The `: float` is an optional type annotation.
- `@onready var sprite: Sprite2D = $Sprite2D` — the
 `@onready` annotation means this assignment runs inside
 `_ready()` automatically. The `$` shorthand fetches a
 child node by name. So `$Sprite2D` means "find the direct child
 node named 'Sprite2D'."
- `sprite.position.x += SPEED * delta` — `position` is a
 `Vector2` property built into Node2D and all its children.
 We increment just the `x` component. Multiplying by `delta`
 converts "pixels per frame" into "pixels per second."
- `get_viewport_rect().size.x` — returns the viewport width in pixels.
 The `Rect2` returned has a `size` field of type
 `Vector2`; we grab just `.x`.
- The `+ 64` / `- 64` offsets let the sprite fully exit the
 screen before wrapping, so the teleport isn't visible. 64 px is roughly half
 the icon's size.
:::

:::example[Example 6.3 — React to keyboard input]
Let the player move the sprite with the arrow keys or WASD. The sprite should
 move at 200 px/s in any of the four directions.

::::answer[Result]
Arrow keys and WASD move the Godot icon around the screen. Releasing a key
 stops movement immediately.
::::

Script (res://main.gd)

```gdscript
extends Node2D

const SPEED: float = 200.0

@onready var sprite: Sprite2D = $Sprite2D

func _process(delta: float) -> void:
    # get_input_direction() returns a Vector2 in (-1..1, -1..1)
    var direction: Vector2 = Input.get_vector(
        "ui_left", "ui_right", "ui_up", "ui_down"
    )
    sprite.position += direction * SPEED * delta
```

Key concept: Input.get\_vector()

`Input.get_vector(neg_x, pos_x, neg_y, pos_y)` reads four
 input actions and combines them into a single `Vector2`. The result is
 automatically normalized so diagonal movement isn't faster than cardinal movement.
 The four strings (`"ui_left"`, etc.) are built-in Input Map actions that
 Godot pre-maps to arrow keys, WASD, and gamepad left stick out of the box.

Notice the script is now just 3 meaningful lines in `_process`.
 This is typical Godot code — the engine provides high-level helpers so you don't
 have to query four separate keys and do the math yourself.
:::

:::callout-pitfall[Watch out for]
- **Forgetting to multiply by `delta`.** If you write
 `sprite.position.x += SPEED` (no delta), the sprite moves 200
 *pixels per frame* — at 60 fps that's 12,000 pixels/second, at 30 fps
 it's 6,000. Always use delta for time-based movement.
- **`$Sprite2D` returns null.** This happens when the
 node name in the scene tree doesn't match exactly (it's case-sensitive). If you
 renamed your node "sprite2d" (lowercase), write `$sprite2d`.
 Check the Scene dock for the exact name.
- **Using `@onready` before the node exists.**
 `@onready` assignments happen during `_ready()`. If you
 try to use the variable in the class body (outside any function), it will be null.
- **Script errors stopping the whole scene.** A GDScript parse error
 (red underline in the editor) will prevent the scene from running. Check the
 Output panel — errors are in red with file name and line number.
:::

### Practice problems — Section 6

:::problem[Problem 6.1 easy]{difficulty="easy"}
Add a second `print()` call to `_ready()` that shows the
 sprite's initial position formatted as: `Initial pos: (x, y)` using
 GDScript's string formatting. Run the scene and confirm the output.

::::solution[Solution]
```gdscript
func _ready() -> void:
    print("Hello, Godot!")
    print("Initial pos: ", sprite.position)
    # Or with string formatting:
    # print("Initial pos: (%s, %s)" % [sprite.position.x, sprite.position.y])
```

`sprite.position` auto-converts to a readable string like
 `(200, 200)` when passed to `print()`.
::::
:::

:::problem[Problem 6.2 easy]{difficulty="easy"}
Change the SPEED constant so the sprite moves at 350 px/s. Then change it
 to move diagonally (both right and down at the same speed) by modifying
 `_process()`. *Hint: add to both `.x` and
 `.y`.*

::::solution[Solution]
```gdscript
const SPEED: float = 350.0

func _process(delta: float) -> void:
    sprite.position.x += SPEED * delta
    sprite.position.y += SPEED * delta
    # Or equivalently:
    # sprite.position += Vector2(SPEED, SPEED) * delta
```
::::
:::

:::problem[Problem 6.3 standard]{difficulty="standard"}
Using the keyboard-input version (Example 6.3), add boundary clamping so the
 sprite can never move outside the viewport. The sprite should stop at the edge,
 not wrap. *Hint: use `clamp()` and
 `get_viewport_rect().size`.*

::::solution[Solution]
```gdscript
func _process(delta: float) -> void:
    var direction: Vector2 = Input.get_vector(
        "ui_left", "ui_right", "ui_up", "ui_down"
    )
    sprite.position += direction * SPEED * delta

    var vp: Vector2 = get_viewport_rect().size
    sprite.position.x = clamp(sprite.position.x, 0.0, vp.x)
    sprite.position.y = clamp(sprite.position.y, 0.0, vp.y)
```

`clamp(value, min, max)` returns `value` constrained
 to the range [min, max]. We clamp both axes independently after moving.
::::
:::

:::problem[Problem 6.4 standard]{difficulty="standard"}
Make the sprite spin: rotate it continuously at 90 degrees per second using
 `_process()`. In Godot, rotation is in *radians*. Print the
 current rotation in degrees to the Output every second using a timer approach
 with an accumulator variable.

::::solution[Solution]
```gdscript
extends Node2D

const ROT_SPEED: float = PI / 2.0  # 90 deg/s in radians
var time_acc: float = 0.0          # accumulator

@onready var sprite: Sprite2D = $Sprite2D

func _process(delta: float) -> void:
    sprite.rotation += ROT_SPEED * delta

    time_acc += delta
    if time_acc >= 1.0:
        time_acc -= 1.0
        print("Rotation: %.1f deg" % rad_to_deg(sprite.rotation))
```

`PI / 2.0` radians = 90 degrees. `rad_to_deg()` is a
 built-in GDScript function. The accumulator pattern (`time_acc +=
 delta; if time_acc >= 1.0: time_acc -= 1.0`) is the standard Godot
 idiom for "do X once per second without a Timer node."
::::
:::

:::problem[Problem 6.5 challenge]{difficulty="challenge"}
Create a **second** Sprite2D child node and give it a different
 texture (or reuse the icon). In `_process()`, make the second sprite
 orbit around the first one in a circle, with a radius of 150 px and one full
 revolution every 3 seconds. The first sprite should stay stationary at (200, 200).
 *Hint: use `sin()` and `cos()` with a time variable.*

::::solution[Solution]
```gdscript
extends Node2D

const ORBIT_RADIUS: float = 150.0
const ORBIT_PERIOD: float = 3.0    # seconds per revolution
var elapsed: float = 0.0

@onready var center_sprite: Sprite2D = $Sprite2D
@onready var orbit_sprite: Sprite2D = $Sprite2D2  # second child node

func _ready() -> void:
    center_sprite.position = Vector2(200.0, 200.0)

func _process(delta: float) -> void:
    elapsed += delta
    var angle: float = (elapsed / ORBIT_PERIOD) * TAU  # TAU = 2*PI
    orbit_sprite.position = center_sprite.position + Vector2(
        cos(angle) * ORBIT_RADIUS,
        sin(angle) * ORBIT_RADIUS
    )
```

`TAU` is a built-in Godot constant equal to 2π (one full circle in
 radians). Dividing `elapsed` by `ORBIT_PERIOD` gives a
 value that goes 0→1 over each period. Multiplying by TAU converts that to
 0→2π. `cos(angle)` and `sin(angle)` then map that angle
 to a point on the unit circle, which we scale by `ORBIT_RADIUS`.
::::
:::

:::summary
## Chapter Summary

### Key concepts

| Concept | What you need to know |
| --- | --- |
| **Godot installation** | Single executable, no installer. Download from godotengine.org. Standard version uses GDScript; .NET version adds C#. |
| **Project Manager** | The launcher screen. Creates and opens projects. Each project is a folder on disk. |
| **Renderer choice** | Compatibility for 2D/web; Forward+ for 3D desktop; Mobile for 3D cross-platform. |
| **Node** | The fundamental building block. Every visible and invisible element in a scene is a node. |
| **Scene** | A tree of nodes, saved as a `.tscn` file. Scenes can be nested inside other scenes. |
| **`extends`** | Declares which node type a script controls. Always matches the node the script is attached to. |
| **`_ready()`** | Called once when the node enters the scene tree. Use for initialization. |
| **`_process(delta)`** | Called every frame. `delta` = seconds since last frame. Always multiply movement by delta. |
| **`@onready`** | Annotation that defers a variable assignment to `_ready()`. Used with `$NodeName` to cache child nodes. |
| **`Input.get_vector()`** | Reads four directional actions into a normalized `Vector2`. The clean way to handle 4-directional keyboard/gamepad input. |

### If you remember nothing else

In Godot, **every game object is a node, nodes live in scenes, and scenes are files**.
 Attach a script to a node to give it behavior. Use `_ready()` to set up,
 and `_process(delta)` to update every frame — and always multiply movement
 by `delta`.

### Keyboard shortcuts you'll use constantly

| Shortcut | Action |
| --- | --- |
| Ctrl+A | Add a new node to the scene |
| Ctrl+S | Save the current scene |
| F5 | Run the project (main scene) |
| F6 | Run the currently open scene |
| F8 | Stop running |
| Ctrl+Z | Undo (in the 2D viewport) |
| Alt+G | Move selected node to a specific position (Go to) |
:::

## Mixed Practice

These problems mix concepts from the whole chapter. Attempt them without looking at
 the worked examples first.

:::problem[Problem M.1 easy]{difficulty="easy"}
Which Godot renderer should you pick for a 2D pixel-art platformer that you plan
 to export to the web? Why?

::::solution[Solution]
**Compatibility.** It uses OpenGL 3.3 / WebGL 2, which is the
 only renderer that works in a web browser. Forward+ and Mobile both require
 Vulkan, which is not available via WebGL. For 2D games, Compatibility has no
 meaningful downside.
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
What is the difference between pressing F5 and F6 in the Godot editor?
 When would you prefer one over the other?

::::solution[Solution]
F5 launches the project's *main scene* (the one set in Project Settings
 → Application → Run → Main Scene). F6 launches whichever scene is
 *currently open* in the editor.

Use F5 to test the full game flow. Use F6 when you're
 working on a sub-scene (like an enemy or UI panel) in isolation and don't want
 to navigate through the whole game to reach it.
::::
:::

:::problem[Problem M.3 easy]{difficulty="easy"}
A sprite is moving 600 pixels per second to the right, but the motion stutters
 noticeably when the frame rate drops. What is the most likely bug?

::::solution[Solution]
The script is probably using `sprite.position.x += SPEED` (no delta),
 so it moves 600 pixels *per frame* — but the distance per frame varies
 with frame rate, causing stutter. The fix:

```gdscript
sprite.position.x += SPEED * delta  # frame-rate independent
```
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Write a complete script for a Node2D that:

 Stores a child Sprite2D reference with `@onready`.
 In `_ready()`, sets the sprite's position to the center of the viewport.
 In `_process()`, moves the sprite toward the mouse cursor at 300 px/s.

 The sprite should slow down and stop when it reaches the cursor (it should not overshoot).

::::solution[Solution]
```gdscript
extends Node2D

const SPEED: float = 300.0

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    sprite.position = get_viewport_rect().size / 2.0

func _process(delta: float) -> void:
    var mouse_pos: Vector2 = get_global_mouse_position()
    var to_mouse: Vector2 = mouse_pos - sprite.position

    # Move at most SPEED*delta pixels, but never overshoot
    var max_step: float = SPEED * delta
    if to_mouse.length() <= max_step:
        sprite.position = mouse_pos  # snap to cursor
    else:
        sprite.position += to_mouse.normalized() * max_step
```

`get_global_mouse_position()` returns the mouse position in world
 (global) coordinates. `to_mouse.normalized()` gives a unit vector
 pointing from the sprite toward the mouse. Comparing
 `to_mouse.length()` against `max_step` prevents
 overshooting — if the sprite would overshoot, we snap exactly to the target.
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
What does `@onready` do, and what happens if you remove it and try to
 use `$Sprite2D` directly as a class-level variable initialization?

::::solution[Solution]
`@onready` tells Godot to evaluate the right-hand side of the variable
 assignment during `_ready()`, not when the class is first instantiated.

If you write `var sprite: Sprite2D = $Sprite2D` at the class level
 (without `@onready`), Godot tries to resolve `$Sprite2D`
 before the node has entered the scene tree. At that point the child nodes don't
 exist yet, so the assignment returns `null`. When you then try to call
 `sprite.position` you get a null dereference error:
 `Invalid get index 'position' on base 'Nil'`.
::::
:::

:::problem[Problem M.6 challenge]{difficulty="challenge"}
Build a scene with three Sprite2D nodes arranged in a triangle formation. A "leader"
 sprite (center) moves with WASD at 200 px/s. The two "follower" sprites always maintain
 their offset from the leader — they move with it rigidly, as if the three sprites are
 a single rigid body. All three should be children of the same root Node2D.
 *Hint: only the root needs a script. Changing the root's position moves all children.*

::::solution[Solution]
The key insight: all three Sprite2D nodes are children of the same root Node2D.
 Moving the *root's* position moves all children with it, maintaining their
 relative offsets automatically. You don't need to move each sprite individually.

```gdscript
extends Node2D

const SPEED: float = 200.0

func _ready() -> void:
    # Position the three sprites relative to the root (which starts at 0,0)
    $Leader.position    = Vector2(0, 0)
    $FollowerA.position = Vector2(-80, 70)
    $FollowerB.position = Vector2(80, 70)
    # Start the whole formation at screen center
    position = get_viewport_rect().size / 2.0

func _process(delta: float) -> void:
    var dir: Vector2 = Input.get_vector(
        "ui_left", "ui_right", "ui_up", "ui_down"
    )
    position += dir * SPEED * delta  # moves root → all children follow
```
::::
:::

:::problem[Problem M.7 challenge]{difficulty="challenge"}
Without using a Timer node, make the Godot icon sprite "flash" — alternate between
 visible and invisible — once per second. It should be visible for 0.5 s, invisible for
 0.5 s, and repeat indefinitely. Use only `_process(delta)` and
 a float accumulator.

::::solution[Solution]
```gdscript
extends Node2D

var time_acc: float = 0.0

@onready var sprite: Sprite2D = $Sprite2D

func _process(delta: float) -> void:
    time_acc += delta
    if time_acc >= 1.0:
        time_acc -= 1.0  # reset without drift

    # fmod gives us position within the current 1-second window
    sprite.visible = time_acc < 0.5
```

`time_acc` climbs from 0 to 1, then resets. For the first 0.5 s of
 each cycle (`time_acc < 0.5`), visible is `true`; for
 the second 0.5 s it's `false`. Subtracting 1.0 (rather than setting
 to 0) prevents accumulator drift — any overshoot carries over to the next cycle.
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
