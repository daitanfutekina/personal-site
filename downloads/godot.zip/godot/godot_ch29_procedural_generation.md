---
title: "Procedural Generation — Noise, Dungeons & Loot Tables"
source: "godot_ch29_procedural_generation.html"
---

Part III · Chapter 29

# Procedural Generation — Noise, Dungeons & Loot Tables

Prerequisite: Ch 4 (GDScript), Ch 9 (TileMapLayer) · est. 85 min

## Overview

Procedural generation is the art of creating game content algorithmically rather
 than by hand. It enables infinite replayability, personalized experiences, and
 massive worlds that would be impractical to author manually. From the random loot
 of a Diablo chest to the infinite terrain of Minecraft, PCG is one of the most
 commercially valuable programming skills in game development.

This chapter covers Godot's built-in tooling for four levels of procedural
 content:

- **Random numbers** — the `randi`/`randf`
 family and the `RandomNumberGenerator` class with explicit seeding.
- **Coherent noise** (`FastNoiseLite`) — smooth,
 natural-looking randomness for terrain heightmaps, cloud textures, and
 cave systems.
- **Weighted random tables** — item drops, enemy spawns, dialogue
 selection.
- **Dungeon generation** — a Binary Space Partition (BSP) algorithm
 that carves rooms and corridors into a `TileMapLayer`.

## 1 · Random Numbers in Godot

### 1.1 · Global RNG functions

There is one shared random-number generator behind all of these, and that shared-ness is
the whole story. It is why they are convenient — no setup, call them anywhere —
and why they are unsuitable for anything you need to reproduce. Any code that draws from
the same stream changes what every other caller sees next, so adding a particle effect that
jitters its own positions can silently change your dungeon layout.

Two of the helpers below are worth reading closely, because both encode a fact about
geometry rather than about randomness. `random_in_circle` takes the square root
of a uniform draw before scaling. Without it the points bunch towards the centre: a ring at
radius *r* has circumference proportional to *r*, so twice the radius must
receive twice the points, and drawing the radius uniformly gives every ring the same
number. The square root corrects exactly that. `random_on_circle`, wanting the
edge rather than the interior, has no such problem and does not use it.

GDScript exposes a set of global functions that use a single shared RNG state.
 These are convenient for quick use but cannot be seeded independently for
 reproducibility.

| Function | Returns | Notes |
| --- | --- | --- |
| `randi()` | `int` [0, 2³²) | Unrestricted positive integer. |
| `randi_range(from, to)` | `int` [from, to] | Both ends inclusive. |
| `randf()` | `float` [0.0, 1.0) | Standard unit interval. |
| `randf_range(from, to)` | `float` [from, to) | Continuous uniform distribution. |
| `randfn(mean, deviation)` | `float` | Normal (Gaussian) distribution — values cluster around `mean`. |
| `randomize()` | void | Seeds the global RNG from the current time. Called automatically at startup in Godot 4. |

```gdscript
## Pick a random item from an Array
func random_element(arr: Array) -> Variant:
    return arr[randi() % arr.size()]

## Coin flip
func coin_flip() -> bool:
    return randf() < 0.5

## Random point inside a circle (uniform distribution)
func random_in_circle(radius: float) -> Vector2:
    var angle := randf() * TAU
    var r     := sqrt(randf()) * radius   # sqrt for uniform area distribution
    return Vector2(cos(angle), sin(angle)) * r

## Random point on a circle's edge
func random_on_circle(radius: float) -> Vector2:
    var angle := randf() * TAU
    return Vector2(cos(angle), sin(angle)) * radius
```

### 1.2 · RandomNumberGenerator class

An instance owns its own stream. That is the entire advantage, and it is a large one:
the enemy rolling for loot cannot perturb the world generator, because they are not drawing
from the same sequence. Give each system that needs reproducibility its own generator and
they stop interfering with one another.

:::callout-tip[Tip]
The

rng.randomize()

here is belt and braces — a freshly constructed

RandomNumberGenerator

already comes seeded from the system entropy, and two
  made on the same line produce different sequences. Keep the call if it makes the intent
  obvious to a reader; it is not doing anything the constructor did not.
:::

When you need an *independent* RNG stream — for example, one per enemy so
 that spawning more enemies doesn't change the dungeon layout — use the
 `RandomNumberGenerator` class:

```gdscript
## Each enemy gets its own RNG for loot drops
extends CharacterBody2D

var rng: RandomNumberGenerator = RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()   # seed from time

## Now rng.randi_range(), rng.randf(), etc. are independent of global RNG
func roll_drop() -> String:
    var roll := rng.randf()
    if roll < 0.05:  return "legendary_sword"
    if roll < 0.20:  return "rare_gem"
    if roll < 0.50:  return "coin"
    return "nothing"
```

### 1.3 · Seeding for reproducible worlds

A seed turns randomness into a pure function of an integer. Everything valuable here
follows from that one property: a player can share a world by sharing a number, a bug
report can be reproduced exactly, and a save file can store six bytes instead of a
megabyte of terrain.

The discipline the pattern demands is total, though, and this is where most
implementations fail. The moment *any* generation step reaches for the global
`randf()` instead of `self.rng`, the world stops being a function of
the seed and the guarantee is gone — not degraded, gone, because one differing draw
shifts every draw after it. That is what the comment above the generator function is
insisting on.

Note also that `generate_dungeon` resets `rng.seed` on entry
rather than trusting the generator's current position. Without that, generating a second
dungeon in the same session continues the sequence and produces a different result from
the same seed.

A *seed* is an integer that initialises the RNG to a deterministic state:
 the same seed always produces the same sequence. This is essential for features
 like shareable map seeds, replay systems, and consistent level-generation in
 multiplayer.

```gdscript
## WorldGenerator.gd (Autoload)
extends Node

var seed: int = 0
var rng:  RandomNumberGenerator = RandomNumberGenerator.new()

func init_with_seed(s: int) -> void:
    seed = s
    rng.seed = s
    print("World seed: %d" % seed)

func init_random() -> void:
    init_with_seed(randi())   # random seed — store it for the save file!

## All generation calls use self.rng — never the global functions
func generate_dungeon(width: int, height: int) -> Array:
    # Deterministic: same seed → same dungeon every time
    rng.seed = seed   # reset to start of the sequence for repeatable generation
    return _bsp_generate(width, height)
```

:::callout-tip[Tip — Save the seed]
Always store the world seed in your save file (Chapter 24).  Players who want to
        revisit a particular dungeon layout or share it with friends need the seed string.
        Display it on the map screen with something like

$SeedLabel.text = "Seed: %d" % WorldGenerator.seed

.
:::

## 2 · FastNoiseLite

`FastNoiseLite` generates *coherent noise* — randomness where
 nearby points have similar values, creating smooth organic-looking patterns.
 Unlike pure random numbers, coherent noise is continuous: you can sample it at
 any coordinate and get a consistent gradient across the entire space.

FastNoiseLite — Noise Type Characteristics

Perlin

smooth gradients

terrain, clouds

Simplex

fewer artefacts

better for 2D+

Cellular (Voronoi)

organic cell shapes

rock, skin, cracked earth

Value

blocky / pixelated

stylised pixel art terrain

FastNoiseLite ships four main types. **Perlin** and **Simplex** produce smooth organic gradients (terrain, clouds). **Cellular** generates Voronoi-like cell boundaries (rocks, cracked surfaces). **Value** produces blocky patterns (pixel-art biomes).

### 2.1 · Noise types and key properties

Two of these properties do most of the work, and they are easy to confuse.

**Frequency** is the scale of the features: how far you must travel before
the value changes appreciably. Low frequency gives broad slow shapes — continents,
mountain ranges — and high frequency gives fine ones. It is the zoom level, and getting
it wrong is why a first attempt at noise terrain usually looks either like static or like
a flat plain.

**Octaves** are how many copies of the noise are summed on top of one
another, each at higher frequency and lower amplitude than the last. One octave gives a
smooth rolling landscape; four gives that same landscape with foothills on the mountains
and bumps on the foothills. `fractal_lacunarity` is how much the frequency rises
per octave and `fractal_gain` how much the amplitude falls, and the defaults of
2.0 and 0.5 — double the detail at half the strength — are conventional because
they look right.

| Property | Description |
| --- | --- |
| `noise_type` | `TYPE_PERLIN`, `TYPE_SIMPLEX`,  `TYPE_SIMPLEX_SMOOTH`, `TYPE_CELLULAR`,  `TYPE_VALUE`, `TYPE_VALUE_CUBIC`.  Simplex is faster and has fewer artefacts than Perlin. Cellular produces  Voronoi-cell patterns. |
| `seed` | Initialise to an integer for reproducible noise. Different seeds produce  entirely different landscapes with the same frequency settings. |
| `frequency` | Controls how quickly the noise changes. Lower = broader features  (mountain ranges); higher = finer detail (bumpy ground). |
| `fractal_type` | `FRACTAL_FBM` (Fractional Brownian Motion) layers multiple  octaves for natural-looking terrain. `FRACTAL_NONE` for a single  smooth layer. |
| `fractal_octaves` | Number of noise layers summed. More octaves = more detail but slower.  4–6 is typical for terrain. |
| `fractal_lacunarity` | Frequency multiplier between octaves. 2.0 doubles frequency each octave. |
| `fractal_gain` | Amplitude multiplier between octaves. 0.5 halves amplitude per octave  (standard FBM). |

### 2.2 · 2D terrain generation with TileMapLayer

The shape of this generator is worth naming, because it is the shape of most 2D terrain
code: noise is sampled in one dimension to produce a *heightmap*, and the second
dimension is then filled in by rule. The noise decides where the surface is; a plain
`if` ladder decides that the surface tile is grass, the next three are dirt, and
everything below is stone. Layering is not a noise problem.

:::callout-pitfall[Pitfall — the range is a bound, not a promise]
get\_noise\_1d

is documented as returning values in

[-1, 1]

, and that is true in the sense that it never leaves them. It is
  misleading as a basis for

remap

, because fractal noise does not get near
  the ends. Measured over 200 000 samples at the settings above: a single octave with

FRACTAL\_NONE

spans

-0.999

to

0.978

, essentially
  the full interval — but the four-octave FBM this listing configures spans only

-0.779

to

0.814

. Summing octaves at half amplitude each means
  every octave would have to peak together to reach 1.0, and they do not.

The practical consequence is a flatter world than the code appears to ask for.
  Remapping from

[-1, 1]

onto rows 5 to 20 uses only rows 11 to 17 —
  seven of the fifteen you allowed for. If you want the full range, measure your own noise
  once and remap from what it actually produces, or scale the result and clamp. Do not
  assume the bound is the range.
:::

```gdscript
## Generate a side-scrolling landscape using noise for heightmap
extends Node2D

@onready var tilemap: TileMapLayer = $TileMapLayer

const MAP_WIDTH  := 100
const TILE_GRASS := Vector2i(0, 0)   # atlas coords in your tileset
const TILE_DIRT  := Vector2i(1, 0)
const TILE_STONE := Vector2i(2, 0)

var noise := FastNoiseLite.new()

func _ready() -> void:
    noise.noise_type       = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.seed             = WorldGenerator.seed
    noise.frequency        = 0.03       # broad hills
    noise.fractal_type     = FastNoiseLite.FRACTAL_FBM
    noise.fractal_octaves  = 4
    _generate()

func _generate() -> void:
    for x in MAP_WIDTH:
        # get_noise_1d is bounded by [-1, 1], but see the note below: with
        # FBM it does not get near those bounds, so this remap is conservative
        var h := noise.get_noise_1d(float(x))
        var surface_y := int(remap(h, -1.0, 1.0, 5, 20))

        for y in 30:
            if y < surface_y:
                continue   # air
            elif y == surface_y:
                tilemap.set_cell(Vector2i(x, y), 0, TILE_GRASS)
            elif y < surface_y + 3:
                tilemap.set_cell(Vector2i(x, y), 0, TILE_DIRT)
            else:
                tilemap.set_cell(Vector2i(x, y), 0, TILE_STONE)
```

### 2.3 · Noise for cave systems and textures

```gdscript
## 2D cave: treat noise as a threshold — below threshold = cave
func generate_caves(width: int, height: int, threshold: float = 0.1) -> void:
    var cave_noise := FastNoiseLite.new()
    cave_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    cave_noise.seed       = WorldGenerator.seed + 1   # different from surface noise
    cave_noise.frequency  = 0.07

    for x in width:
        for y in height:
            var v := cave_noise.get_noise_2d(float(x), float(y))
            if v < threshold:
                tilemap.erase_cell(Vector2i(x, y))   # carve air

## Generate a noise texture for a cloud material
func make_noise_texture(width: int, height: int) -> ImageTexture:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.frequency  = 0.04

    var img := Image.create(width, height, false, Image.FORMAT_RGBA8)
    for x in width:
        for y in height:
            var v := remap(n.get_noise_2d(float(x), float(y)), -1.0, 1.0, 0.0, 1.0)
            img.set_pixel(x, y, Color(v, v, v, 1.0))
    return ImageTexture.create_from_image(img)
```

:::callout-tip[Tip — NoiseTexture2D resource]
For visual uses (material textures, displacement maps) you do not need to write a
        pixel loop.  Create a

NoiseTexture2D

resource in the editor, assign
        your

FastNoiseLite

to its

noise

property, and the engine
        generates the texture on the GPU automatically.
:::

## 3 · Weighted Random Tables

Pure random selection treats every option equally. A *weighted* table
 assigns different probabilities to different outcomes — a sword drops 5% of the
 time while a coin drops 70%.

### 3.1 · Implementation

```gdscript
## WeightedTable — reusable class for weighted random selection
class_name WeightedTable

var _entries: Array[Dictionary] = []
var _total_weight: float = 0.0

## Add an entry. weight is relative — 10 vs 5 vs 1 means 62.5%, 31.25%, 6.25%
func add(item: Variant, weight: float) -> void:
    assert(weight > 0.0, "WeightedTable: weight must be positive")
    _entries.append({"item": item, "weight": weight})
    _total_weight += weight

## Pick a random item according to weights
func pick(rng: RandomNumberGenerator = null) -> Variant:
    if _entries.is_empty():
        push_error("WeightedTable.pick() called on empty table")
        return null

    var roll := (rng.randf() if rng else randf()) * _total_weight
    var cumulative := 0.0
    for entry in _entries:
        cumulative += entry["weight"]
        if roll < cumulative:
            return entry["item"]

    return _entries.back()["item"]   # floating-point safety fallback

## Pick n distinct items (without replacement)
func pick_n(n: int, rng: RandomNumberGenerator = null) -> Array:
    assert(n <= _entries.size(), "pick_n: n > table size")
    var remaining := _entries.duplicate()
    var result    := []
    for _i in n:
        var total := remaining.reduce(func(a, e): return a + e["weight"], 0.0)
        var roll  := (rng.randf() if rng else randf()) * total
        var cum   := 0.0
        for j in remaining.size():
            cum += remaining[j]["weight"]
            if roll < cum:
                result.append(remaining[j]["item"])
                remaining.remove_at(j)
                break
    return result
```

### 3.2 · Loot table example

```gdscript
## LootManager.gd  (Autoload)
extends Node

var _chest_table:  WeightedTable
var _enemy_table:  WeightedTable

func _ready() -> void:
    _chest_table = WeightedTable.new()
    _chest_table.add("legendary_sword",  1)
    _chest_table.add("rare_staff",        4)
    _chest_table.add("uncommon_potion",  15)
    _chest_table.add("coin_pile",        50)
    _chest_table.add("nothing",          30)

    _enemy_table = WeightedTable.new()
    _enemy_table.add("health_orb",  40)
    _enemy_table.add("mana_orb",    30)
    _enemy_table.add("coin",        20)
    _enemy_table.add("key",          8)
    _enemy_table.add("rare_gem",     2)

func roll_chest() -> String:
    return _chest_table.pick() as String

func roll_enemy_drop() -> String:
    return _enemy_table.pick() as String

## Drop 1-3 items from the enemy table (no duplicates)
func roll_multi_drop(count: int) -> Array[String]:
    var result: Array[String] = []
    for _i in count:
        result.append(_enemy_table.pick() as String)
    return result
```

## 4 · Procedural Dungeon Generation

Binary Space Partitioning (BSP) is one of the most reliable dungeon generation
 algorithms. It recursively splits a rectangular area into two halves,
 then places rooms inside the leaf partitions, and finally connects all rooms
 with corridors. The result is a grid-based dungeon that always has at least
 one path between every room.

### 4.1 · BSP room splitting

```gdscript
## DungeonGenerator.gd
extends Node

class BSPNode:
    var rect:     Rect2i
    var left:     BSPNode = null
    var right:    BSPNode = null
    var room:     Rect2i        # only valid in leaf nodes

    func _init(r: Rect2i) -> void:
        rect = r

    func is_leaf() -> bool:
        return left == null and right == null

const MIN_SIZE  := 7    # minimum partition dimension (tiles)
const MIN_ROOM  := 4    # minimum room dimension (tiles)

var rng := RandomNumberGenerator.new()
var _rooms: Array[Rect2i] = []

func generate(width: int, height: int, seed: int) -> Array[Rect2i]:
    rng.seed = seed
    _rooms.clear()
    var root := BSPNode.new(Rect2i(0, 0, width, height))
    _split(root, 5)     # recurse up to 5 times
    _place_rooms(root)
    return _rooms

## Recursively split a node into two children
func _split(node: BSPNode, depth: int) -> void:
    if depth == 0:
        return
    if node.rect.size.x < MIN_SIZE * 2 and node.rect.size.y < MIN_SIZE * 2:
        return   # too small to split further

    var split_horizontal: bool
    if node.rect.size.x >= node.rect.size.y * 1.25:
        split_horizontal = false   # wide → split vertically
    elif node.rect.size.y >= node.rect.size.x * 1.25:
        split_horizontal = true    # tall → split horizontally
    else:
        split_horizontal = rng.randi() % 2 == 0   # roughly square → random

    var split_pos: int
    if split_horizontal:
        if node.rect.size.y < MIN_SIZE * 2: return
        split_pos = rng.randi_range(
            node.rect.position.y + MIN_SIZE,
            node.rect.position.y + node.rect.size.y - MIN_SIZE
        )
        node.left  = BSPNode.new(Rect2i(
            node.rect.position.x, node.rect.position.y,
            node.rect.size.x, split_pos - node.rect.position.y
        ))
        node.right = BSPNode.new(Rect2i(
            node.rect.position.x, split_pos,
            node.rect.size.x, node.rect.end.y - split_pos
        ))
    else:
        if node.rect.size.x < MIN_SIZE * 2: return
        split_pos = rng.randi_range(
            node.rect.position.x + MIN_SIZE,
            node.rect.position.x + node.rect.size.x - MIN_SIZE
        )
        node.left  = BSPNode.new(Rect2i(
            node.rect.position.x, node.rect.position.y,
            split_pos - node.rect.position.x, node.rect.size.y
        ))
        node.right = BSPNode.new(Rect2i(
            split_pos, node.rect.position.y,
            node.rect.end.x - split_pos, node.rect.size.y
        ))

    _split(node.left,  depth - 1)
    _split(node.right, depth - 1)

## Place a random room inside each leaf partition
func _place_rooms(node: BSPNode) -> void:
    if node.is_leaf():
        var rx := rng.randi_range(node.rect.position.x + 1,
            node.rect.position.x + node.rect.size.x - MIN_ROOM - 1)
        var ry := rng.randi_range(node.rect.position.y + 1,
            node.rect.position.y + node.rect.size.y - MIN_ROOM - 1)
        var rw := rng.randi_range(MIN_ROOM,
            node.rect.end.x - rx - 1)
        var rh := rng.randi_range(MIN_ROOM,
            node.rect.end.y - ry - 1)
        node.room = Rect2i(rx, ry, rw, rh)
        _rooms.append(node.room)
    else:
        if node.left:  _place_rooms(node.left)
        if node.right: _place_rooms(node.right)
```

### 4.2 · Corridor carving

```gdscript
## Connect rooms with L-shaped corridors
var _corridors: Array[Rect2i] = []

func _connect_rooms(rooms: Array[Rect2i]) -> void:
    _corridors.clear()
    for i in rooms.size() - 1:
        var a := rooms[i]
        var b := rooms[i + 1]
        # Start from center of each room
        var ax := a.position.x + a.size.x / 2
        var ay := a.position.y + a.size.y / 2
        var bx := b.position.x + b.size.x / 2
        var by := b.position.y + b.size.y / 2

        # Randomly decide whether to go horizontal-first or vertical-first
        if rng.randi() % 2 == 0:
            _corridors.append(Rect2i(min(ax, bx), ay, abs(bx - ax) + 1, 1))
            _corridors.append(Rect2i(bx, min(ay, by), 1, abs(by - ay) + 1))
        else:
            _corridors.append(Rect2i(ax, min(ay, by), 1, abs(by - ay) + 1))
            _corridors.append(Rect2i(min(ax, bx), by, abs(bx - ax) + 1, 1))
```

### 4.3 · Writing to TileMapLayer

```gdscript
## Apply the generated rooms + corridors to a TileMapLayer
@onready var walls_layer:  TileMapLayer = $WallsLayer
@onready var floors_layer: TileMapLayer = $FloorsLayer

const SOURCE_ID    := 0
const TILE_WALL    := Vector2i(0, 0)
const TILE_FLOOR   := Vector2i(1, 0)
const DUNGEON_W    := 60
const DUNGEON_H    := 40

func build_dungeon(seed: int) -> void:
    var gen := DungeonGenerator.new()
    add_child(gen)

    # Step 1: fill everything with walls
    for x in DUNGEON_W:
        for y in DUNGEON_H:
            walls_layer.set_cell(Vector2i(x, y), SOURCE_ID, TILE_WALL)

    # Step 2: carve rooms as floor tiles
    var rooms := gen.generate(DUNGEON_W, DUNGEON_H, seed)
    gen._connect_rooms(rooms)

    for room in rooms:
        _carve_rect(room)
    for corridor in gen._corridors:
        _carve_rect(corridor)

    gen.queue_free()

func _carve_rect(r: Rect2i) -> void:
    for x in range(r.position.x, r.end.x):
        for y in range(r.position.y, r.end.y):
            walls_layer.erase_cell(Vector2i(x, y))
            floors_layer.set_cell(Vector2i(x, y), SOURCE_ID, TILE_FLOOR)

## Spawn the player at the center of the first room
func get_player_spawn(rooms: Array[Rect2i]) -> Vector2:
    if rooms.is_empty(): return Vector2.ZERO
    var r := rooms[0]
    var tile_pos := Vector2i(
        r.position.x + r.size.x / 2,
        r.position.y + r.size.y / 2
    )
    return floors_layer.map_to_local(tile_pos)
```

:::callout-connect[Connect — Navigation & dungeons]
After building the dungeon tiles, call

$NavigationRegion2D.bake\_navigation\_polygon()

(Chapter 20) to
        automatically generate a walkable navmesh from the carved floor tiles.  Enemy AI
        can then pathfind through the generated dungeon with no additional setup.
:::

## Summary

Procedural generation in Godot is built on three primitives.
 **Random numbers** — global functions for quick use,
 `RandomNumberGenerator` for independent, seedable streams —
 provide the entropy source for everything else.
 **FastNoiseLite** turns that entropy into coherent gradients
 suitable for terrain heightmaps, cave thresholds, and texture generation;
 choose `TYPE_SIMPLEX_SMOOTH` for most tasks and layer it with
 FBM octaves for natural-looking results.
 **Weighted random tables** give different items or events
 different probabilities of selection — the `WeightedTable` class
 handles any discrete probability distribution with a simple add/pick API.
 Finally, the **BSP dungeon algorithm** recursively divides a
 rectangle into leaf partitions, places a room in each leaf, connects them with
 L-shaped corridors, and writes the result directly to a
 `TileMapLayer`. Saving the initial seed in the save file
 (Chapter 24) makes every generated world reproducible and shareable.

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Seeded colour palette

Create a function `palette_from_seed(seed: int, count: int)
 -> Array[Color]` that returns `count` visually distinct
 colours generated from the seed. Use a
 `RandomNumberGenerator` seeded with the given value. Verify
 that the same seed always produces the same colours.

::::solution[Solution]
```gdscript
func palette_from_seed(seed: int, count: int) -> Array[Color]:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    var colours: Array[Color] = []
    for i in count:
        # Space hues evenly with noise to avoid similar adjacent colours
        var h := fmod(float(i) / count + rng.randf() * 0.15, 1.0)
        colours.append(Color.from_hsv(h, 0.7 + rng.randf() * 0.3,
                                         0.8 + rng.randf() * 0.2))
    return colours

func _ready() -> void:
    var a := palette_from_seed(42, 5)
    var b := palette_from_seed(42, 5)
    for i in 5:
        assert(a[i] == b[i], "Same seed must produce same palette")
    print("Palette OK: ", a)
```
::::
:::

:::problem{difficulty="easy"}
### P2 · Weighted loot drop

Using the `WeightedTable` class from Section 3, create a table
 for a slain goblin with these drop rates:

- Nothing — 50%
- Coin — 30%
- Small Potion — 15%
- Key — 5%

Simulate 10,000 goblin kills and print the actual percentage of each drop
 to verify the distribution is approximately correct.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var table := WeightedTable.new()
    table.add("nothing",       50)
    table.add("coin",          30)
    table.add("small_potion",  15)
    table.add("key",            5)

    var counts := {"nothing": 0, "coin": 0, "small_potion": 0, "key": 0}
    for _i in 10000:
        counts[table.pick()] += 1

    for key in counts:
        print("%s: %.1f%%" % [key, counts[key] / 100.0])
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Side-scroller heightmap

Using `FastNoiseLite`, generate a side-scrolling terrain in a
 TileMapLayer. Requirements:

- 100 tiles wide, 20 tiles tall.
- Surface height from noise: remap `get_noise_1d(x)` to
 rows 3–15.
- One tile of grass at the surface, two tiles of dirt below, stone
 below that.
- A second, lower-frequency noise layer controls cave carving: any
 underground tile whose second noise value is below −0.2 becomes air.

::::solution[Solution]
```gdscript
extends Node2D

@onready var tm: TileMapLayer = $TileMapLayer
const W := 100; const H := 20
const SRC := 0
const GRASS  := Vector2i(0,0); const DIRT  := Vector2i(1,0)
const STONE  := Vector2i(2,0)

func _ready() -> void:
    var terrain := FastNoiseLite.new()
    terrain.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    terrain.seed       = 1234
    terrain.frequency  = 0.04

    var caves := FastNoiseLite.new()
    caves.noise_type = FastNoiseLite.TYPE_SIMPLEX
    caves.seed       = 5678
    caves.frequency  = 0.08

    for x in W:
        var h   := int(remap(terrain.get_noise_1d(float(x)), -1.0, 1.0, 3, 15))
        for y in H:
            if y < h: continue
            var cv := caves.get_noise_2d(float(x), float(y))
            if y > h and cv < -0.2: continue  # cave air
            if y == h:
                tm.set_cell(Vector2i(x,y), SRC, GRASS)
            elif y < h + 3:
                tm.set_cell(Vector2i(x,y), SRC, DIRT)
            else:
                tm.set_cell(Vector2i(x,y), SRC, STONE)
```
::::
:::

:::problem{difficulty="standard"}
### P4 · Name generator

Build a `NameGenerator` that produces fantasy names using a
 Markov chain trained on a short wordlist. Seed it with an integer so the
 same seed always produces the same list of names. Generate 10 names and
 print them.

::::solution[Solution]
```gdscript
## Simple bigram Markov chain name generator
extends Node

const TRAINING := [
    "aldric","bronwen","caelia","draven","elara","faeron",
    "galadriel","halion","isara","jorvin","kelthos","lirien",
    "maevis","naelar","orindel","pyriel","quellan","rathis",
    "serana","theron","ulrin","velyra","whalon","xarel","yndara","zoria"
]

var _chain:  Dictionary = {}
var rng:     RandomNumberGenerator = RandomNumberGenerator.new()

func _ready() -> void:
    _train()
    rng.seed = 42
    for _i in 10:
        print(_generate())

func _train() -> void:
    for word in TRAINING:
        var w := "^" + word + "$"
        for i in w.length() - 1:
            var bigram := w.substr(i, 2)
            var key := bigram[0]
            if not _chain.has(key): _chain[key] = []
            _chain[key].append(bigram[1])

func _generate() -> String:
    var result := ""
    var cur    := "^"
    for _guard in 20:
        if not _chain.has(cur): break
        var nexts: Array = _chain[cur]
        var c := nexts[rng.randi() % nexts.size()]
        if c == "$": break
        result += c
        cur = c
    return result.capitalize()
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Room connection validation

After generating a BSP dungeon, write a function
 `all_rooms_reachable(rooms: Array[Rect2i],
 corridors: Array[Rect2i], map_width: int, map_height: int) -> bool`
 that flood-fills from the first room's center and checks that every
 other room's center is reachable. Use a simple BFS over a boolean grid
 built from the rooms and corridors. Print the result.

::::solution[Solution]
```gdscript
func all_rooms_reachable(rooms: Array[Rect2i], corridors: Array[Rect2i],
                         mw: int, mh: int) -> bool:
    # Build walkable grid
    var grid := []
    for _y in mh:
        var row: Array = []
        for _x in mw: row.append(false)
        grid.append(row)

    for r in rooms:
        for x in range(r.position.x, r.end.x):
            for y in range(r.position.y, r.end.y):
                if x < mw and y < mh: grid[y][x] = true

    for c in corridors:
        for x in range(c.position.x, c.end.x):
            for y in range(c.position.y, c.end.y):
                if x < mw and y < mh: grid[y][x] = true

    # BFS from first room center
    var start := Vector2i(
        rooms[0].position.x + rooms[0].size.x / 2,
        rooms[0].position.y + rooms[0].size.y / 2)
    var visited := {}
    var queue   := [start]
    visited[start] = true

    while not queue.is_empty():
        var pos := queue.pop_front() as Vector2i
        for d in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]:
            var n := pos + d
            if n.x < 0 or n.y < 0 or n.x >= mw or n.y >= mh: continue
            if visited.has(n): continue
            if grid[n.y][n.x]:
                visited[n] = true
                queue.append(n)

    # Check every room center is visited
    for r in rooms:
        var c := Vector2i(r.position.x + r.size.x/2, r.position.y + r.size.y/2)
        if not visited.has(c): return false
    return true
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full seeded roguelike dungeon

Combine all chapter components to generate a complete roguelike dungeon floor:

1. Accept a seed integer (shown on the HUD as a shareable string).
2. Run BSP generation (60×40 tiles).
3. Write rooms and corridors to a `TileMapLayer`.
4. Spawn the player at the first room's center.
5. Place a locked exit door at the last room's center.
6. For each room except the first and last, use a weighted table to place
 1–3 items (50% chest, 30% enemy, 20% empty).
7. Bake a NavigationRegion2D after tile generation so enemies can pathfind.
8. Validate all rooms are reachable before finalising (regenerate with
 `seed + 1` if not, up to 5 attempts).

::::solution[Solution]
```gdscript
# FloorBuilder.gd
extends Node

const W := 60; const H := 40
const CHEST_SCENE := preload("res://scenes/chest.tscn")
const ENEMY_SCENE := preload("res://scenes/enemy.tscn")
const DOOR_SCENE  := preload("res://scenes/exit_door.tscn")

@onready var tilemap: TileMapLayer    = $TileMapLayer
@onready var navregion: NavigationRegion2D = $NavigationRegion2D
@onready var seed_label: Label        = $HUD/SeedLabel

func build(seed: int) -> void:
    var attempt_seed := seed
    for attempt in 5:
        var gen := DungeonGenerator.new()
        add_child(gen)
        var rooms := gen.generate(W, H, attempt_seed)
        gen._connect_rooms(rooms)

        if not _validate(rooms, gen._corridors):
            gen.queue_free()
            attempt_seed += 1
            continue

        _write_tiles(rooms, gen._corridors)
        _place_entities(rooms)
        gen.queue_free()

        navregion.bake_navigation_polygon()
        seed_label.text = "Seed: %d" % attempt_seed
        return
    push_error("FloorBuilder: could not generate valid dungeon after 5 attempts")

func _write_tiles(rooms: Array, corridors: Array) -> void:
    # fill walls
    for x in W:
        for y in H:
            tilemap.set_cell(Vector2i(x,y), 0, Vector2i(0,0))
    # carve floors
    for r in rooms:
        _carve(r)
    for c in corridors:
        _carve(c)

func _carve(r: Rect2i) -> void:
    for x in range(r.position.x, r.end.x):
        for y in range(r.position.y, r.end.y):
            tilemap.set_cell(Vector2i(x,y), 0, Vector2i(1,0))

func _place_entities(rooms: Array) -> void:
    var spawn_table := WeightedTable.new()
    spawn_table.add("chest",  50)
    spawn_table.add("enemy",  30)
    spawn_table.add("empty",  20)

    # Player at first room
    var fr: Rect2i = rooms[0]
    $Player.global_position = tilemap.map_to_local(
        Vector2i(fr.position.x + fr.size.x/2, fr.position.y + fr.size.y/2))

    # Exit at last room
    var lr: Rect2i = rooms.back()
    var door := DOOR_SCENE.instantiate()
    add_child(door)
    door.global_position = tilemap.map_to_local(
        Vector2i(lr.position.x + lr.size.x/2, lr.position.y + lr.size.y/2))

    # Populate middle rooms
    for i in range(1, rooms.size() - 1):
        var r: Rect2i = rooms[i]
        var center    := tilemap.map_to_local(
            Vector2i(r.position.x + r.size.x/2, r.position.y + r.size.y/2))
        match spawn_table.pick():
            "chest":
                var c := CHEST_SCENE.instantiate()
                add_child(c); c.global_position = center
            "enemy":
                var e := ENEMY_SCENE.instantiate()
                add_child(e); e.global_position = center

func _validate(rooms: Array[Rect2i], corridors: Array[Rect2i]) -> bool:
    return all_rooms_reachable(rooms, corridors, W, H)
```
::::
:::
