---
title: "Crowd Runner — Track, Recycling Ground & Chase Camera"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72B"
meta:
  - "Est. study time: ~45 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72b_track_camera.html"
---

## Overview

Before the runner exists, we build the world he'll run through — an *infinite*
 strip of ground that appears to scroll past a camera. Rendering an actually-infinite
 strip is impossible, so we fake it with two ground segments that leapfrog each other:
 whenever one falls behind the camera, we snap it forward to become the new far segment.
 This is the same trick every endless runner uses, from Subway Surfers to Temple Run.

:::callout-key[What you'll build in this chapter]
Main.tscn with WorldEnvironment (ACES tonemap + glow), one DirectionalLight3D
 (no shadows), a GroundSegment scene (30 m long × 12 m wide static box), two instances
 of it (A behind, B ahead), a CameraRig that follows a target's Z position, and a
 throwaway *TestMover* Node3D that scrolls forward so we can see the world scroll
 before the runner exists.
:::

### Prerequisites

- Ch 72A complete — project configured, layers set, autoloads registered.
- Comfortable with 3D scene composition (Ch 24, 25).
- Understand StandardMaterial3D at a beginner level (Ch 26).

:::callout-connect[Reference checklist]
Direct: **Ch 24** (Node3D transforms), **Ch 25** (MeshInstance3D
 & primitives), **Ch 26** (StandardMaterial3D), **Ch 30**
 (DirectionalLight3D), **Ch 31** (WorldEnvironment — but only the tonemap
 and glow sections; everything else is Forward+-only).
:::

## 1. Main Scene Skeleton

Open `res://scenes/main/Main.tscn` (created in Ch 72A). The root is a bare
 Node3D. Add children in this exact order so scripts written later find them by
 `$NodeName`.

1. Select `Main` in the Scene dock. Click *+ Add Child Node*
 (or Ctrl+A).
2. Search `WorldEnvironment`, add. Leave default name.
3. Add `DirectionalLight3D`, rename to **SunLight**.
4. Add `Node3D`, rename to **GroundContainer**.
5. Add another `Node3D`, rename to **WorldContainer**. (This one
 stays empty in Ch 72B — Ch 72G's spawner fills it.)
6. Add another `Node3D`, rename to **CameraRig**. Attach a
 *New Script*, save to `res://scenes/main/CameraRig.gd`, template Empty.
7. With CameraRig selected, add a `Camera3D` child (leaves it named
 *Camera3D*).
8. Save (Ctrl+S). Confirm the tree looks like:

```
Main (Node3D)
├── WorldEnvironment
├── SunLight (DirectionalLight3D)
├── GroundContainer (Node3D)
├── WorldContainer (Node3D)
└── CameraRig (Node3D)                    ← CameraRig.gd
    └── Camera3D
```

:::callout-tip[Why an empty WorldContainer now]
Adding it now — even empty — locks the tree order so Ch 72G's `LevelSpawner`
 can find it with `$WorldContainer` without any restructuring. Renaming a node
 in Godot updates every reference in the same scene automatically, but Cross-scene
 references (like a script that `get_node("../WorldContainer")`s) don't
 auto-update. Get the names right the first time.
:::

## 2. WorldEnvironment & Sun

A default 3D scene renders pitch black — no ambient light, no sky. We fix both with the
 WorldEnvironment node (holds an *Environment* resource) and the DirectionalLight3D
 we already added.

### WorldEnvironment

1. Select **WorldEnvironment** in the Main scene.
2. In the Inspector, find **Environment** — click *<empty>*
 → *New Environment*. A new resource is created and attached.
3. Click the Environment resource to expand it. Configure these sections exactly:

| Section | Property | Value |
| --- | --- | --- |
| Background | Mode | `Sky` |
| Background → Sky | Sky | Click *New Sky* → click new Sky → set *Sky Material* to *New ProceduralSkyMaterial* |
| ProceduralSkyMaterial | Sky Top Color | `#3a6b9a` (deep sky blue) |
| ProceduralSkyMaterial | Sky Horizon Color | `#c9d6df` (pale haze) |
| ProceduralSkyMaterial | Ground Bottom Color | `#20272e` (dark grey) |
| Ambient Light | Source | `Sky` |
| Ambient Light | Sky Contribution | `0.5` |
| Ambient Light | Energy | `1.0` |
| Tonemap | Mode | `ACES` |
| Tonemap | White | `6.0` |
| Glow | Enabled | `on` |
| Glow | Intensity | `0.6` |
| Glow | Bloom | `0.05` |

:::callout-warning[Leave the following off]
SSR (Screen Space Reflections), SSAO, SSIL, SDFGI, Fog, Volumetric Fog, Adjustments.
 They are either Forward+-only (Mobile ignores them) or too expensive for phone GPUs.
 If you turn any of them on to “see what it does,” turn them back off before
 committing.
:::

### SunLight

1. Select **SunLight**. In the Inspector:
2. **Transform → Rotation**: X = `-50°`, Y = `-40°`, Z = `0°`. This gives you a warm morning angle so shadows would fall diagonally to camera-right — except we're not using shadows.
3. **Light → Energy** = `1.2`. Slightly hot to punch through ambient.
4. **Light → Color** = `#fff2d9` (warm white).
5. **Shadow → Enabled** = *off*. Critical — shadow casters on the crowd would tank framerate.

:::callout-intuition[Why no shadows]
Every crowd member would need to be sampled by the shadow map — with 150 members, that's
 150 extra draw calls (one per shadow-map pass). MultiMesh helps with the color pass, but
 Godot's shadow renderer treats each instance as separate. Result: 60 fps → 22 fps
 instantly. Skipping shadows entirely, and leaning on ambient light + a hot directional
 key, is standard mobile-game practice.
:::

## 3. GroundSegment Scene

One segment is a 30 m long × 12 m wide static box: enough to fill the visible track ahead
 of the camera. Two of them tiling head-to-tail cover the visible + upcoming region.

1. *Scene → New Scene*. Root = **StaticBody3D**, rename to
 **GroundSegment**. Save as
 `res://scenes/world/GroundSegment.tscn`.
2. With GroundSegment selected, in the Inspector confirm:

 **Collision Layer** = 1 only (*Ground*)

 **Collision Mask** = 0 (cleared — the ground doesn't scan for anyone)
3. Add child **MeshInstance3D** named *Mesh*.

   - *Mesh* property → *New BoxMesh*. Click it.
   - *Size*: X = `12`, Y = `0.5`, Z = `30`. (12 m wide, 0.5 m thick, 30 m long.)
   - *Material Override* → *New StandardMaterial3D*. Click.

     - *Albedo* → *Color* = `#2f3a45` (dark asphalt).
     - *Metallic* = `0.0`, *Roughness* = `0.85`.
     - Toggle *Save to file* on the material dropdown → save as `res://assets/materials/ground_mat.tres` so both segments share one material (one draw call, not two).

4. On *Mesh*, set **Transform → Position → Y** = `-0.25` so the top surface sits at Y = 0.
5. Add child **CollisionShape3D** named *Collider*. *Shape* → *New BoxShape3D*. *Size*: X = `12`, Y = `0.5`, Z = `30`. Match Mesh Position → Y = `-0.25`.
6. Optional lane paint: add two thin child MeshInstance3Ds (BoxMesh 0.05 × 0.01 × 30, white unlit material) as lane dividers at X = `-1` and X = `+1` (between lanes centred at −2, 0, 2). Y = 0.005 (just above the ground surface).
7. Save the scene.

:::callout-tip[One shared material = one draw call]
Instantiating GroundSegment twice with the material saved to a `.tres`
 file means both instances reference the *same* material resource. Godot batches
 them into one draw call. If instead you had two *new* materials with identical
 values, Godot treats them as separate materials — two draw calls. The `.tres`
 save is not just for reuse, it's a perf detail.
:::

## 4. GroundRecycler Logic — Placing & Recycling Both Segments

Back in `Main.tscn`, instance two GroundSegments and write the recycler that
 leapfrogs them as the runner advances.

1. Select **GroundContainer** in the Main scene.
2. In the FileSystem dock, drag `res://scenes/world/GroundSegment.tscn` onto
 GroundContainer *twice*. The children appear as *GroundSegment* and
 *GroundSegment2*.
3. Rename them: right-click → Rename → **GroundSegment\_A** and
 **GroundSegment\_B**.
4. Position them along Z:

   - GroundSegment\_A: **Transform → Position** = `(0, 0, 0)`
   - GroundSegment\_B: **Transform → Position** = `(0, 0, -30)`
    (one segment length ahead — remember our forward is -Z)

5. Save Main.tscn.

Now the recycler script — this lives on `GroundContainer` itself. Attach a
 new script:

1. Select GroundContainer → click the script icon in the Scene dock header (or
 right-click → *Attach Script*).
2. Path: `res://scenes/main/GroundRecycler.gd`, template Empty, inherits Node3D.
3. Paste this content:

```gdscript
# res://scenes/main/GroundRecycler.gd
# Leapfrogs two GroundSegment children so the runner never runs out of ground.
# Attached to GroundContainer under Main.
extends Node3D

const SEGMENT_LEN : float = 30.0
const RECYCLE_BEHIND : float = 20.0   # metres behind target before jump-forward

@export var target_path : NodePath   # points to the thing that moves forward (Runner or TestMover)

@onready var target : Node3D = get_node_or_null(target_path)
@onready var segments : Array[Node3D] = [
    $GroundSegment_A,
    $GroundSegment_B,
]

func _process(_dt: float) -> void:
    if target == null:
        return
    var target_z : float = target.global_position.z   # negative & decreasing over time
    for seg in segments:
        # Segment centre is at seg.global_position.z. Segment ends at +/- SEGMENT_LEN/2.
        # If the *back* edge of the segment is more than RECYCLE_BEHIND behind the target,
        # jump the segment to be the new *far* segment.
        var seg_back_edge : float = seg.global_position.z + SEGMENT_LEN * 0.5
        if seg_back_edge > target_z + RECYCLE_BEHIND:
            _jump_forward(seg)

func _jump_forward(seg: Node3D) -> void:
    # Find the current *farthest* segment (most negative Z) and place this one
    # exactly one segment length past it.
    var farthest_z : float = INF
    for s in segments:
        if s != seg and s.global_position.z < farthest_z:
            farthest_z = s.global_position.z
    var new_pos := seg.global_position
    new_pos.z = farthest_z - SEGMENT_LEN
    seg.global_position = new_pos
```

:::callout-intuition[Read the algorithm slowly]
Say the runner is at Z = `-100` and both segments started at
 `(0, -30)`. GroundSegment\_A's back edge is at `0 + 15 = 15`. Is
 `15 > -100 + 20` i.e. `15 > -80`? Yes. So we jump it. The
 farthest other segment is B at Z = `-30`. So A moves to
 `-30 - 30 = -60`. Now B is at `-30`, A is at `-60`. Runner
 keeps advancing; next iteration B (whose back edge is at `-15`) will pass the
 threshold and get jumped to `-90`. Ping-pong forever.
:::

### Timeline visualization — the leapfrog in action

Snapshot the world every 0.5 s. Runner moves at 10 m/s. Watch A and B trade places:

```
Time (s)   Runner Z   Segment A Z   Segment B Z   Event
─────────  ─────────  ───────────   ───────────   ─────────────────────────────
  0.0          0          0            -30        (start; A behind, B ahead)
  1.0        -10          0            -30
  2.0        -20          0            -30
  3.0        -30          0            -30        (runner reaches B's centre)
  4.0        -40          0            -30        (A back edge = 15, thresh -20)
  4.5        -45        -60            -30        A jumped to -60! (past B)
  5.0        -50        -60            -30
  ...
  7.5        -75        -60            -90        B jumped to -90! (past A)
                                                  (loop continues forever)
```

Each row is a snapshot; the “Event” column marks the exact tick a segment
 leapfrogs. Notice A and B never move on the same tick — the recycler only touches a
 segment when *its* back edge crosses the threshold. This is why scroll stays
 smooth: at any moment one segment is under the camera and the other is 30 m ahead.

:::callout-pitfall[Common mistake — \_process vs \_physics\_process]
Both would work here since we're just teleporting a visual node. But `_process`
 runs at display refresh (60/120/144 Hz on desktop, whatever the phone reports), which is
 the same rate we *see* ground, so recycling “the frame you notice it” is
 correct. Reserve `_physics_process` for anything that touches
 CharacterBody3D, RigidBody3D, or emits/receives physics collisions.
:::

## 5. CameraRig — Chase Cam with Smoothing

The camera lives on a separate rig node so we can smoothly follow the runner's Z without
 touching the child Camera3D's local transform. That lets us later add camera shake as an
 additive offset on the child without fighting the follow logic.

1. Select **Camera3D** (child of CameraRig). Set:

   - **Transform → Position**: X = `0`, Y = `5`, Z = `8`. (5 m up, 8 m behind the rig origin. Positive Z is behind the runner because forward is -Z.)
   - **Transform → Rotation**: X = `-22°`, Y = `0°`, Z = `0°`. Slight downward tilt so you see track ahead.
   - **Projection**: *Perspective*. **FOV** = `65`. **Near** = `0.1`. **Far** = `60`. (Far clip beyond spawn\_lookahead so nothing pops in.)

2. Attach the CameraRig.gd script we already saved (Ch 72B step 1.6) and paste this
 content:

```gdscript
# res://scenes/main/CameraRig.gd
# Chase camera that follows target.z with exponential smoothing.
# Camera shake (Ch 72H) applied as additive offset on the child Camera3D.
extends Node3D

@export var target_path       : NodePath
@export var follow_smoothing  : float = 6.0    # higher = snappier
@export var shake_decay       : float = 5.0

@onready var target : Node3D = get_node_or_null(target_path)
@onready var cam    : Camera3D = $Camera3D

var _shake_intensity : float = 0.0
var _shake_seed      : float = 0.0

func _process(dt: float) -> void:
    if target != null:
        var pos := global_position
        var t_pos := target.global_position
        # Follow Z with exp smoothing; X stays 0 so lane movement doesn't drag the cam sideways.
        pos.z = lerp(pos.z, t_pos.z, 1.0 - exp(-follow_smoothing * dt))
        global_position = pos

    # Shake — additive local offset on the child camera.
    if _shake_intensity > 0.0:
        _shake_seed += dt * 60.0
        var offset := Vector3(
            sin(_shake_seed * 1.3) * _shake_intensity,
            cos(_shake_seed * 1.7) * _shake_intensity,
            0.0
        )
        cam.transform.origin = Vector3(0, 5, 8) + offset   # base pos + shake
        _shake_intensity = maxf(0.0, _shake_intensity - shake_decay * dt)
    else:
        cam.transform.origin = Vector3(0, 5, 8)

func shake(amount: float) -> void:
    _shake_intensity = maxf(_shake_intensity, amount)
```

:::callout-tip[Frame-rate-independent smoothing]
`1.0 - exp(-k * dt)` is the right way to smooth-lerp regardless of framerate.
 A raw `lerp(a, b, 0.1)` feels different at 30 fps vs 60 fps. Using an
 exponential decay constant, doubling the framerate keeps the visible smoothing
 identical. Memorize this idiom.
:::

## 6. Placeholder TestMover

There's still no runner — Ch 72C builds him. But we want to see the ground scroll and
 the camera follow *right now*. Solution: a throwaway Node3D that just advances Z
 by RUN\_SPEED every physics tick. We'll delete it in Ch 72C.

1. In Main.tscn, add child **Node3D**, name it **TestMover**.
2. Attach a new script *inline* (not saved to a file — click the script icon, choose
 “Built-in Script”, template Empty). Contents:

```gdscript
extends Node3D

const RUN_SPEED : float = 10.0

func _physics_process(dt: float) -> void:
    global_position.z -= RUN_SPEED * dt
```

:::callout-tip[Why inline script]
Because this node is temporary. Files clutter the FileSystem dock. Inline scripts live
 inside the scene file and vanish with the node — perfect for throwaway test rigs.
:::

## 7. Main.gd Wiring

Attach a script to the Main root that wires up the two `target_path`
 NodePaths (on GroundContainer and CameraRig) so both point at TestMover for now — Ch 72C
 swaps them to point at Runner.

1. Select the **Main** root node. Attach a new script,
 `res://scenes/main/Main.gd`, template Empty, inherits Node3D.
2. Paste:

```gdscript
# res://scenes/main/Main.gd
# Wires target paths for GroundContainer and CameraRig. Ch 72C will
# swap TestMover for the real Runner.
extends Node3D

@onready var ground_container : Node3D = $GroundContainer
@onready var camera_rig       : Node3D = $CameraRig
@onready var _initial_target  : Node3D = $TestMover

func _ready() -> void:
    _set_follow_target(_initial_target)
    print("[Main] wired follow target = ", _initial_target.name)

func _set_follow_target(t: Node3D) -> void:
    # Both consumers store a NodePath; convert absolute path to a NodePath relative to them.
    ground_container.set("target_path", ground_container.get_path_to(t))
    camera_rig.set("target_path", camera_rig.get_path_to(t))
```

:::callout-warning[If @onready var \_initial\_target := $TestMover is red]
It means you named the node something other than `TestMover`, or you deleted
 it. The `$TestMover` shorthand is Godot for `get_node("TestMover")` —
 it must exist as a direct child of Main.
:::

## 8. Verification

1. Save all (Ctrl+Shift+S).
2. Run the project (F5).

:::callout-key[Verify these five things]
- Sky is a soft blue-to-haze gradient (not black).
- Ground is a dark grey strip stretching into the distance. You can see the two
 lane dividers at X = ±1.
- The ground appears to *scroll toward you*. It is actually the camera + TestMover
 both moving forward together; visually you see world scroll past.
- The scroll never stops and never runs out — segments are recycling forever.
- Output dock prints `[Main] wired follow target = TestMover` and
 `[GameManager] ready…`. No red errors.
:::

:::callout-warning[If the ground stops scrolling after a few seconds]
Your recycler isn't firing. Common causes: *target\_path* on GroundContainer is
 unset (check the Inspector), or you attached GroundRecycler.gd to the wrong node
 (should be GroundContainer, not Main). Add a `print` at the top of
 GroundRecycler `_process` to see whether it's running at all.
:::

:::callout-warning[If the camera doesn't follow]
Same fix — check CameraRig's *target\_path* in the Inspector. Because
 Main.gd sets it in `_ready()`, if the print message *doesn't* appear
 then Main.gd never ran (check autoload order in Project Settings, or open Main.tscn and
 confirm Main.gd is attached to the root).
:::

:::callout-warning[If the ground “pops” when it recycles]
You can see the jump because `RECYCLE_BEHIND` is too small — the segment
 teleports while still on screen. Increase it to `25` or push
 *Segment\_A/B* further apart in their starting Z positions. On a phone you
 typically want RECYCLE\_BEHIND ≥ half the segment length.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why do we recycle two ground segments instead of building one very long segment (say 1 km)?

::::solution[Solution]
Three reasons. (1) Physics broadphase — a 1 km collision box would dominate every
 spatial query. (2) Frustum culling — Godot can cull a small segment behind the camera,
 but the whole 1 km box is always visible from the runner's perspective, so nothing is
 culled. (3) Origin drift — after tens of minutes at 10 m/s, the runner's Z becomes a
 very large negative float; floating-point precision degrades, causing jitter. Two 30 m
 segments keep the visible world always near the origin.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Explain in your own words why `lerp(pos.z, t_pos.z, 1.0 - exp(-k * dt))`
 is frame-rate independent but `lerp(pos.z, t_pos.z, 0.1)` is not.

::::solution[Solution]
The plain `lerp(a, b, 0.1)` moves 10 % of the distance *per call*.
 At 60 fps you call it 60 times per second → total closure rate depends on framerate.
 The exp form models a continuous decay: after time `t`, the remaining error
 is `e^(-k·t)`. So a target dt of 1/60 vs 1/30 both converge at the same
 real-time rate: the *k* constant is per-second, not per-frame. The formula
 `1 - e^(-k·dt)` converts the desired per-second rate into a per-frame lerp
 weight.
::::
:::

:::problem[Problem 3 challenge]{difficulty="challenge"}
The scroll speed feels too slow at 10 m/s on a phone screen. You bump RUN\_SPEED to
 16 without touching anything else. What breaks visually, and how do you fix it?

::::solution[Solution]
Two issues. (a) The *ground pop* is more visible because *RECYCLE\_BEHIND*
 (20 m) is now traversed in 20/16 = 1.25 s instead of 2 s — the segment jumps forward
 while it's still nearly visible. Fix: raise RECYCLE\_BEHIND to `32` so it's ≥
 the segment length. (b) The camera *follow\_smoothing* (6.0) starts to feel
 laggy — at higher speed the runner runs off the screen edge before the cam catches up.
 Fix: raise follow\_smoothing to `10` or drop the smoothing entirely (set to
 `50+`) for that arcade-tight feel.
::::
:::

:::summary
## Summary

You've built the stage. Main.tscn now has a lit sky, a recycling two-segment ground
 strip, a chase camera with exponential smoothing and a shake hook, and a placeholder
 TestMover that scrolls the world forward. Running the project shows an endless scrolling
 3D track from a low-angle chase view — the exact visual base every crowd runner starts
 from.

**Next:**
 [Ch 72C](./godot_ch72c_runner_motion.html) replaces TestMover with the real
 Runner CharacterBody3D, adds keyboard lane switching for editor testing, and does the
 sine-bob run animation.
:::
