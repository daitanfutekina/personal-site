---
title: "GDShader Fundamentals — Syntax, Types, Built-ins & the Pipeline"
source: "godot_ch50_gdshader_fundamentals.html"
---

Part VIII · Chapter 50

# GDShader Fundamentals — Syntax, Types, Built-ins & the Pipeline

Estimated study time: 85 min · Godot 4.6 · GDShader / GLSL

## Overview

A shader is a small program that runs on the GPU — thousands of times in parallel — to compute the final colour of every pixel on screen, or the final position of every vertex in a mesh. Shaders are how you get effects that are impossible with sprite tinting alone: dissolve effects, water ripples, heat distortion, cel-shading, neon glow, procedural textures, and anything else that needs per-pixel computation.

Godot uses its own **GDShader** language — a dialect of GLSL ES 3.0 with Godot-specific additions. If you have written GLSL before, GDShader will feel immediately familiar. If not, this chapter teaches you everything from scratch.

### Prerequisites

- Basic mathematics — vectors, dot products, UV coordinates
- Ch 15 — Materials and rendering basics

## What Is a Shader?

The GPU rendering pipeline works roughly like this:

1. **Vertex stage:** For each vertex of a mesh, compute its final clip-space position. The vertex shader can also pass per-vertex data to the fragment stage.
2. **Rasterisation:** The GPU interpolates between vertices to determine which screen pixels the triangle covers.
3. **Fragment stage:** For each covered pixel, compute the final output colour. This is where most visual effects happen.

GPU Rendering Pipeline (per draw call)

CPU

mesh vertices

sent to GPU

Vertex Stage

vertex() runs

per vertex

← YOU WRITE THIS

Rasterise

GPU fills pixels

inside triangles

(automatic)

Fragment Stage

fragment() runs

per pixel

← YOU WRITE THIS

Framebuffer

final pixel colors

→ screen

Vertex runs ~100s of times per mesh · Fragment runs millions of times per frame

You write the vertex() and fragment() functions. The rasteriser in between is automatic — the GPU interpolates vertex data across each triangle's pixels.

In Godot you write both stages in one `.gdshader` file. A minimal canvas\_item shader that outputs solid red looks like this:

```glsl
shader_type canvas_item;

void fragment() {
    COLOR = vec4(1.0, 0.0, 0.0, 1.0);   // RGBA red
}
```

Attach this to a `ShaderMaterial`, assign that material to any CanvasItem, and the entire mesh renders solid red regardless of its texture. That's the most basic possible effect — now let's build up from there.

:::callout-tip[Creating a shader in the editor]
Select any node with a material slot → create a new **ShaderMaterial** → click the shader slot → create a new **Shader**. The shader editor opens at the bottom of the screen. All edits hot-reload instantly — you see the effect live without restarting the scene.
:::

## Shader Types

Every GDShader file starts with a `shader_type` declaration that tells Godot which rendering context the shader belongs to. This determines which built-in variables and functions are available.

| shader\_type | Used on | Key stages |
| --- | --- | --- |
| `canvas_item` | Sprite2D, Control, MeshInstance2D, CanvasItem nodes | `vertex`, `fragment`, `light` |
| `spatial` | MeshInstance3D, any 3D mesh | `vertex`, `fragment`, `light` |
| `particles` | GPUParticles2D / GPUParticles3D | `start`, `process` |
| `sky` | Sky resource | `sky` |
| `fog` | FogVolume node | `fog` |

This chapter focuses on `canvas_item` and `spatial` — they share most of the same language features. The particle, sky, and fog types are covered in Ch 52.

## GLSL Types

GDShader's type system is a subset of GLSL. Every value has a concrete numeric type — there is no implicit conversion between them.

### Scalars and Vectors

| Type | Components | Example literal | Notes |
| --- | --- | --- | --- |
| `float` | 1 (32-bit) | `3.14` | Must include a decimal point: `1.0` not `1` |
| `int` | 1 (32-bit signed) | `42` | No decimals allowed |
| `uint` | 1 (32-bit unsigned) | `42u` | Use for bit manipulation |
| `bool` | 1 | `true` |  |
| `vec2` | 2 floats | `vec2(0.5, 1.0)` | Components: `.x`/`.y` or `.r`/`.g` |
| `vec3` | 3 floats | `vec3(1.0, 0.0, 0.0)` | RGB or XYZ |
| `vec4` | 4 floats | `vec4(1.0, 0.0, 0.0, 1.0)` | RGBA or XYZW |
| `ivec2/3/4` | 2/3/4 ints | `ivec2(4, 8)` | Integer vectors |
| `bvec2/3/4` | 2/3/4 bools | `bvec2(true, false)` | Used with `any()` / `all()` |

**Swizzling** — you can reorder or repeat components using letter suffixes:

```glsl
vec4 col = vec4(0.2, 0.4, 0.6, 1.0);
vec3 rgb = col.rgb;            // vec3(0.2, 0.4, 0.6)
vec2 rg  = col.rg;             // vec2(0.2, 0.4)
vec4 inv = col.bgra;           // vec4(0.6, 0.4, 0.2, 1.0) — reversed
vec3 rep = col.rrr;            // vec3(0.2, 0.2, 0.2) — repeat red
float r  = col.r;              // 0.2 — extract single component
```

### Matrices

| Type | Shape | Common use |
| --- | --- | --- |
| `mat2` | 2×2 float | 2D rotation |
| `mat3` | 3×3 float | 3D rotation (no translation) |
| `mat4` | 4×4 float | Full 3D transform (MVP matrix) |

### Samplers

Samplers represent textures. They are passed in as uniforms and sampled with `texture()`.

| Type | Description |
| --- | --- |
| `sampler2D` | Standard 2D texture |
| `sampler2DArray` | Array of 2D textures |
| `sampler3D` | 3D (volume) texture |
| `samplerCube` | Cubemap (6 faces) |

## Shader Structure

A complete GDShader file has this layout:

```glsl
shader_type canvas_item;

// ① Render modes (optional)
render_mode unshaded, blend_mix;

// ② Uniforms — values set from GDScript or the material inspector
uniform vec4  tint : source_color = vec4(1.0);
uniform float speed              = 1.0;
uniform sampler2D noise_tex      : filter_linear, repeat_enable;

// ③ Varyings — data passed from vertex() to fragment()
varying vec2 world_pos;

// ④ Helper functions (optional)
float remap(float v, float lo, float hi) {
    return (v - lo) / (hi - lo);
}

// ⑤ Vertex stage
void vertex() {
    world_pos = (MODEL_MATRIX * vec4(VERTEX, 0.0, 1.0)).xy;
}

// ⑥ Fragment stage
void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    COLOR = tex * tint;
}
```

### Uniforms

Uniforms are inputs set *from outside* the shader — from GDScript, from the material inspector, or from animation. They are the same for every pixel/vertex in a single draw call.

```glsl
// With a type hint (controls the inspector widget)
uniform vec4  albedo     : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float roughness  : hint_range(0.0, 1.0, 0.01) = 0.5;
uniform sampler2D tex    : filter_linear_mipmap, repeat_disable;

// Without a hint (shows as a plain number field)
uniform float speed = 2.0;
uniform int   tile_count = 4;
```

**Uniform hints** control how the inspector renders the field and how the texture is sampled:

| Hint | Applies to | Effect |
| --- | --- | --- |
| `source_color` | vec3/vec4 | Shows a colour picker; value is in linear colour space |
| `hint_range(min,max,step)` | float/int | Shows a slider |
| `hint_normal` | sampler2D | Expects a normal map (enables correct import settings) |
| `filter_nearest` | sampler2D | Pixelated (no bilinear filtering) |
| `filter_linear` | sampler2D | Smooth bilinear filtering |
| `filter_linear_mipmap` | sampler2D | Smooth + mipmaps for distant surfaces |
| `repeat_enable` | sampler2D | UV wraps around (tiles) |
| `repeat_disable` | sampler2D | UV clamps at edges |

Setting uniforms from GDScript:

```gdscript
var mat := $Sprite2D.material as ShaderMaterial
mat.set_shader_parameter("speed",   2.5)
mat.set_shader_parameter("albedo",  Color(1.0, 0.5, 0.2, 1.0))
mat.set_shader_parameter("tex",     preload("res://noise.png"))
```

### Varyings

Varyings pass data *from the vertex stage to the fragment stage*. The GPU interpolates the value across the triangle between the three vertices, so each pixel receives a smoothly blended value.

```glsl
varying vec2 uv_scaled;
varying vec3 world_normal;

void vertex() {
    uv_scaled    = UV * 4.0;        // tile UVs 4× before fragment
    world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
    vec4 col = texture(TEXTURE, uv_scaled);
    // world_normal is automatically interpolated between vertices
}
```

### The vertex() Function

The vertex function runs once per vertex. Its primary job is setting `VERTEX` (or `POSITION` in canvas\_item) to move the geometry, but it can also prepare varyings and compute anything that's more efficient to do once per vertex than once per pixel.

| Built-in | Type | R/W | Description |
| --- | --- | --- | --- |
| `VERTEX` | vec2 (2D) / vec3 (3D) | R/W | Vertex position in object space. Write to displace geometry. |
| `UV` | vec2 | R/W | Texture coordinate. Write to remap UVs for the whole mesh. |
| `COLOR` | vec4 | R | Per-vertex colour (from CanvasItem.modulate × vertex colour). |
| `MODEL_MATRIX` | mat4 | R | Object → world transform. |
| `VIEW_MATRIX` | mat4 | R | World → camera transform. |
| `PROJECTION_MATRIX` | mat4 | R | Camera → clip space transform. |

### The fragment() Function

The fragment function runs once per pixel. You write to `COLOR` (2D) or the PBR outputs (`ALBEDO`, `ROUGHNESS`, etc.) to determine the final pixel colour.

| Built-in | Type | R/W | Description |
| --- | --- | --- | --- |
| `UV` | vec2 | R | Interpolated UV coordinate for this pixel. |
| `COLOR` | vec4 | R/W (2D) | In canvas\_item: read = vertex colour; write = output colour. |
| `TEXTURE` | sampler2D | R (2D) | The node's current texture (Sprite2D texture, etc.). |
| `TEXTURE_PIXEL_SIZE` | vec2 | R (2D) | `1.0 / texture_size` — use to step one pixel in UV space. |
| `SCREEN_UV` | vec2 | R | Position of this pixel in 0–1 screen space. |
| `FRAGCOORD` | vec4 | R | Pixel position in window space (.xy = pixel coords, .z = depth). |
| `ALBEDO` | vec3 | W (3D) | Surface diffuse colour in spatial shaders. |
| `ROUGHNESS` | float | W (3D) | 0 = mirror, 1 = fully rough. |
| `METALLIC` | float | W (3D) | 0 = dielectric, 1 = metallic. |
| `EMISSION` | vec3 | W (3D) | Emissive colour (self-illumination). |
| `ALPHA` | float | W (3D) | Transparency (requires `render_mode blend_mix`). |
| `NORMAL` | vec3 | R/W (3D) | Surface normal in view space. Write to apply normal mapping. |

## Key Built-in Variables

These are available in most shader types without declaring them:

| Variable | Type | Description |
| --- | --- | --- |
| `TIME` | float | Seconds since the game started. Use for animation. |
| `PI` | float | 3.14159… — pre-defined constant. |
| `TAU` | float | 2π = 6.28318… — full circle in radians. |
| `E` | float | Euler's number 2.71828… |
| `VIEWPORT_SIZE` | vec2 | Width × height of the viewport in pixels. **Spatial shaders only** — canvas\_item has `SCREEN_PIXEL_SIZE` instead, and particles and sky have neither. |

## Built-in Functions

GDShader includes all standard GLSL math functions plus several extras. These run on the GPU and are extremely fast.

| Function | Description |
| --- | --- |
| `texture(sampler, uv)` | Sample a texture at UV. Returns vec4 (RGBA). |
| `mix(a, b, t)` | Linear interpolate: `a*(1-t) + b*t`. Works on scalars and vectors. |
| `clamp(v, lo, hi)` | Clamp value to [lo, hi]. |
| `smoothstep(lo, hi, v)` | Smooth 0→1 transition between lo and hi. Cubic (S-curve). |
| `step(edge, v)` | Returns 0.0 if v < edge, 1.0 otherwise. Hard threshold. |
| `fract(v)` | Fractional part: `v - floor(v)`. Use for tiling. |
| `floor(v) / ceil(v)` | Round toward −∞ / +∞. |
| `abs(v)` | Absolute value. |
| `sign(v)` | −1, 0, or +1. |
| `mod(v, m)` | Modulo (like GLSL `mod`, always positive). |
| `sin(v) / cos(v) / tan(v)` | Trigonometry (radians). |
| `pow(base, exp)` | Power function. |
| `sqrt(v) / inversesqrt(v)` | Square root and fast reciprocal. |
| `exp(v) / log(v)` | Natural exponential and logarithm. |
| `dot(a, b)` | Dot product of two vectors. |
| `cross(a, b)` | Cross product of two vec3s. |
| `length(v)` | Magnitude of a vector. |
| `normalize(v)` | Unit vector in the same direction. |
| `reflect(i, n)` | Reflect incident vector `i` around normal `n`. |
| `refract(i, n, eta)` | Refract vector (for glass/water effects). |
| `max(a, b) / min(a, b)` | Component-wise max/min for vectors. |

:::callout-key[The most important function: mix()]
`mix()` is the workhorse of shader programming. Virtually every blend, transition, fade, and interpolation uses it. Because it works on vec2, vec3, and vec4 as well as float, you can blend entire colours in one call: `mix(col_a, col_b, t)`.
:::

## UV Manipulation

The UV coordinate is a vec2 ranging from (0,0) at the top-left corner of a texture to (1,1) at the bottom-right. Almost every effect starts by transforming the UV in some way.

UV Coordinate Space

(0,0)

(1,0)

(0,1)

(1,1)

(0.5, 0.5)

U (0 → 1, left → right)

V (0 → 1, top → bottom)

Common UV transforms:

UV \* 2.0

tile 2× in each axis

UV - 0.5

center at origin

fract(UV \* 4.0)

tile 4× (wrap)

UV + vec2(TIME, 0)

scroll right

UV coordinates run (0,0) top-left to (1,1) bottom-right. All UV manipulations are transformations on this unit square before sampling the texture.

### Tiling

```glsl
void fragment() {
    // Tile the texture 4 times in each direction
    vec2 tiled_uv = fract(UV * 4.0);
    COLOR = texture(TEXTURE, tiled_uv);
}
```

### Scrolling

```glsl
uniform float scroll_speed = 0.2;

void fragment() {
    // Scroll horizontally over time
    vec2 scrolled = UV + vec2(TIME * scroll_speed, 0.0);
    COLOR = texture(TEXTURE, fract(scrolled));
}
```

### Rotation

```glsl
uniform float angle = 0.0;   // radians

void fragment() {
    // Rotate UV around the centre (0.5, 0.5)
    vec2 centred = UV - vec2(0.5);
    float s = sin(angle);
    float c = cos(angle);
    vec2 rotated = vec2(
        centred.x * c - centred.y * s,
        centred.x * s + centred.y * c
    ) + vec2(0.5);
    COLOR = texture(TEXTURE, rotated);
}
```

### Polar Coordinates

```glsl
void fragment() {
    // Convert UV to polar (r, theta) — great for radial effects
    vec2 centred = UV - vec2(0.5);
    float r     = length(centred);
    float theta = atan(centred.y, centred.x);   // −PI to +PI
    // Use r and theta however you like:
    float ring = step(0.3, r) * step(r, 0.4);   // circular ring
    COLOR = vec4(vec3(ring), 1.0);
}
```

## TIME & Animation

`TIME` is your single most useful animation tool. Combined with `sin()` or `fract()`, it drives every kind of cyclic animation.

```glsl
shader_type canvas_item;

uniform float wave_speed  = 2.0;
uniform float wave_amount = 0.05;

void vertex() {
    // Wave animation — displace vertices horizontally using a sine wave
    VERTEX.x += sin(VERTEX.y * 10.0 + TIME * wave_speed) * wave_amount;
}

void fragment() {
    // Pulsing glow — oscillate brightness with a sine wave
    float pulse = sin(TIME * 3.0) * 0.5 + 0.5;   // 0.0 to 1.0
    vec4 tex = texture(TEXTURE, UV);
    COLOR = tex + vec4(vec3(pulse * 0.3), 0.0);
}
```

:::callout-tip[sin(TIME) → 0..1 pattern]
`sin()` oscillates between −1 and +1. To get a 0–1 range for blending, use: `sin(TIME * speed) * 0.5 + 0.5`. To get a 0–1 sawtooth (for looping progress bars or scanning effects), use: `fract(TIME * speed)`.
:::

### Worked Example: Animated Hologram Effect

```glsl
shader_type canvas_item;

uniform float scan_speed  = 2.0;
uniform float scan_width  = 0.05;
uniform vec4  scan_color  : source_color = vec4(0.0, 1.0, 1.0, 0.8);
uniform float flicker_rate = 8.0;

void fragment() {
    vec4 base = texture(TEXTURE, UV);

    // Scanline — a moving bright horizontal band
    float scan_y    = fract(TIME * scan_speed);
    float scan_line = smoothstep(scan_width, 0.0, abs(UV.y - scan_y));

    // Flicker — random-looking brightness variation
    float flicker = fract(sin(TIME * flicker_rate) * 43758.5453);
    flicker = mix(0.85, 1.0, flicker);

    // Tint to cyan, add scanline, apply flicker
    vec4 tinted = base * vec4(0.6, 1.0, 1.0, 1.0);
    COLOR = (tinted + scan_color * scan_line) * flicker;
    COLOR.a = base.a * flicker;   // preserve alpha
}
```

:::callout-connect[Connect to GDScript]
All uniforms are animatable from GDScript. To make the hologram flicker faster during an alarm state: `mat.set_shader_parameter("flicker_rate", 24.0)`. Reset it with `mat.set_shader_parameter("flicker_rate", 8.0)`. No shader recompile needed — uniforms update every frame.
:::

## Practice Problems

:::problem
#### A — Solid Colour with Alpha easy

Write a canvas\_item shader that outputs the node's texture normally but applies a uniform `tint` (vec4, source\_color) multiplied over it, and a separate uniform `opacity` (float, range 0–1, default 1) that scales the output alpha independently. The tint's own alpha should be ignored — only the `opacity` uniform controls transparency.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform vec4  tint    : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float opacity : hint_range(0.0, 1.0, 0.01) = 1.0;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    COLOR.rgb = tex.rgb * tint.rgb;
    COLOR.a   = tex.a * opacity;
}
```
::::
:::

:::problem
#### B — UV Scroll Animation easy

Write a canvas\_item shader that scrolls its texture diagonally (both U and V axes) over time. Expose `scroll_speed_x` and `scroll_speed_y` as separate float uniforms (default 0.1 each). The texture must tile seamlessly (use `fract()`).

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float scroll_speed_x = 0.1;
uniform float scroll_speed_y = 0.1;

void fragment() {
    vec2 offset = vec2(TIME * scroll_speed_x, TIME * scroll_speed_y);
    vec2 uv = fract(UV + offset);
    COLOR = texture(TEXTURE, uv);
}
```
::::
:::

:::problem
#### C — Greyscale Filter easy

Write a canvas\_item shader that converts its texture to greyscale using luminance weighting (R×0.299 + G×0.587 + B×0.114). Expose a `strength` uniform (0 = original colour, 1 = full greyscale, range 0–1) so the effect can be partially applied.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float strength : hint_range(0.0, 1.0, 0.01) = 1.0;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    float lum = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
    vec3 grey = vec3(lum);
    COLOR.rgb = mix(tex.rgb, grey, strength);
    COLOR.a   = tex.a;
}
```
::::
:::

:::problem
#### D — Pulsing Outline standard

Write a canvas\_item shader that detects the edge of the sprite's alpha (pixels where the alpha is above 0 but at least one neighbour sample is transparent) and draws them as a pulsing coloured outline. The outline colour and pulse speed should be uniforms. Use `TEXTURE_PIXEL_SIZE` to step one pixel in UV space.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform vec4  outline_color : source_color = vec4(0.0, 1.0, 1.0, 1.0);
uniform float pulse_speed   = 3.0;

void fragment() {
    vec4 tex   = texture(TEXTURE, UV);
    float a    = tex.a;

    // Sample 4 neighbours
    float n = texture(TEXTURE, UV + vec2(0.0,  TEXTURE_PIXEL_SIZE.y)).a;
    float s = texture(TEXTURE, UV + vec2(0.0, -TEXTURE_PIXEL_SIZE.y)).a;
    float e = texture(TEXTURE, UV + vec2( TEXTURE_PIXEL_SIZE.x, 0.0)).a;
    float w = texture(TEXTURE, UV + vec2(-TEXTURE_PIXEL_SIZE.x, 0.0)).a;

    // Edge: this pixel is opaque but a neighbour is transparent
    float edge = step(0.1, a) * step(min(min(n, s), min(e, w)), 0.1);

    float pulse = sin(TIME * pulse_speed) * 0.5 + 0.5;
    vec4 out_col = outline_color * pulse;

    COLOR = mix(tex, out_col, edge);
}
```
::::
:::

:::problem
#### E — Polar Ripple challenge

Write a canvas\_item shader that distorts the UV before sampling by converting to polar coordinates, adding a time-based sinusoidal ripple to the radius, then converting back to Cartesian UV. Expose `ripple_speed`, `ripple_frequency`, and `ripple_amplitude` as uniforms. The centre of the ripple should be (0.5, 0.5).

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float ripple_speed     = 2.0;
uniform float ripple_frequency = 8.0;
uniform float ripple_amplitude = 0.04;

void fragment() {
    vec2 centred = UV - vec2(0.5);
    float r      = length(centred);
    float theta  = atan(centred.y, centred.x);

    // Add a sinusoidal displacement to the radius
    float displaced_r = r + sin(r * ripple_frequency - TIME * ripple_speed)
                            * ripple_amplitude;

    // Convert back to Cartesian
    vec2 distorted = vec2(
        cos(theta) * displaced_r,
        sin(theta) * displaced_r
    ) + vec2(0.5);

    COLOR = texture(TEXTURE, distorted);
}
```
::::
:::
