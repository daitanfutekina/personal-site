---
title: "Scene Management — Transitions, Loading & Scene Trees"
source: "godot_ch25_scene_management.html"
---

Part III · Chapter 25

# Scene Management — Transitions, Loading & Scene Trees

Prerequisite: Ch 3 (Nodes & Scenes), Ch 12 (Autoloads) · est. 75 min

## Overview

Every non-trivial game is composed of multiple scenes: a main menu, a loading screen,
 one or more gameplay levels, a pause menu, a HUD, an inventory overlay. Knowing how
 to transition between these scenes cleanly — without memory leaks, without jarring
 hitches, and with data intact — is a fundamental production skill.

Godot provides three levels of scene management:

- **Immediate replacement** (`change_scene_to_file`,
 `change_scene_to_packed`) — swaps the entire current scene with a new
 one on the next frame. Simple but synchronous.
- **Additive loading** (`add_child` of an instantiated
 scene) — keeps the current scene alive while adding another on top. Used for
 UI overlays, split-screen segments, and sub-worlds.
- **Threaded async loading**
 (`ResourceLoader.load_threaded_request`) — loads a scene file in a
 background thread while the game continues running, enabling loading screens
 without a freeze.

This chapter also covers the `SceneTree` singleton — the object that owns
 the scene hierarchy — and builds a reusable `SceneManager` autoload with
 fade transitions and a scene history stack.

## 1 · SceneTree & get\_tree()

The `SceneTree` is the top-level container for all nodes. Every node
 that is inside the tree can access it via `get_tree()`. It is not a
 node itself — it is the *owner* of the root node and drives the main loop.

### 1.1 · Commonly used SceneTree methods

| Method / Property | Description |
| --- | --- |
| `get_tree().current_scene` | The root node of the currently active scene (the one swapped by  `change_scene_to_*`). |
| `get_tree().root` | The engine's `Window` root — the true parent of everything.  Autoloads live here as direct children. |
| `get_tree().paused` | Set to `true` to pause the entire tree (only nodes with  `process_mode = ALWAYS` still tick). |
| `get_tree().quit(code)` | Exit the application with the given exit code (default 0). |
| `get_tree().reload_current_scene()` | Destroy and reload the current scene from disk. Useful for a "retry" button. |
| `get_tree().get_node_count()` | Total nodes currently in the tree — useful for leak checks. |
| `get_tree().get_frame()` | Current frame number since the game started. |
| `get_tree().create_timer(sec, process_always)` | Returns a `SceneTreeTimer` — connect its `timeout`  signal for a one-shot delay without a Timer node. |
| `get_tree().process_frame` signal | Emitted at the start of every process frame. |
| `get_tree().physics_frame` signal | Emitted at the start of every physics frame. |

```gdscript
## One-shot delay without a Timer node
func _ready() -> void:
    await get_tree().create_timer(2.0).timeout
    print("2 seconds have passed")

## Retry the current level
func retry_level() -> void:
    get_tree().reload_current_scene()

## Quit the game from a button
func _on_quit_pressed() -> void:
    get_tree().quit()
```

### 1.2 · Groups — broadcasting to sets of nodes

Groups let you tag nodes and then call methods or send signals to all members at
 once, without needing a direct reference to each. They are the cleanest way to
 implement "damage all enemies in the room" or "pause all animated NPCs".

```gdscript
## Adding/removing groups (can be done in the editor or in code)
func _ready() -> void:
    add_to_group("enemies")
    add_to_group("pausable")

func cleanup() -> void:
    remove_from_group("enemies")

## Calling a method on every member of a group
func deal_area_damage(amount: int) -> void:
    # call_group calls the method on every node in the group that has it
    get_tree().call_group("enemies", "take_damage", amount)

## Checking membership
func is_enemy() -> bool:
    return is_in_group("enemies")

## Getting all group members as an Array
func get_all_enemies() -> Array[Node]:
    return get_tree().get_nodes_in_group("enemies")
```

:::callout-warning[Warning — call\_group order]
call\_group()

calls the method on all group members in

tree order

(depth-first).  If a method call frees a node, subsequent members may shift in the
        list.  Use

call\_group\_flags(SceneTree.GROUP\_CALL\_DEFERRED, ...)

to defer
        all calls to the end of the frame, avoiding modification-during-iteration crashes.
:::

## 2 · Changing Scenes

The simplest way to transition between screens is to replace the current scene
 entirely. Godot frees the old scene (calling `_exit_tree` on every node),
 loads the new scene, and calls `_ready` on its nodes — all on the main
 thread, at the end of the current frame.

change\_scene\_to\_file() — what happens each frame

Request

change\_scene\_to

\_file() called

end of frame

Free Old Scene

\_exit\_tree() called

on every old node

Load New Scene

.tscn file parsed

nodes instantiated

Scene Ready

\_ready() called on

every new node

Autoloads are NOT freed

GameManager, AudioManager, EventBus — all persist across scene changes. This is how global state survives transitions.

To pass data: write to an Autoload before calling change\_scene, read from it in the new scene's \_ready()

Scene changes happen at the end of the frame. The engine frees every node in the old scene (firing `_exit_tree`), loads and instantiates the new one, then fires `_ready` on all new nodes. Autoloads live through the whole sequence unchanged.

### 2.1 · change\_scene\_to\_file()

```gdscript
## Navigate to a new scene by file path
func go_to_level(path: String) -> void:
    var err := get_tree().change_scene_to_file(path)
    if err != OK:
        push_error("Failed to load scene '%s': %s" % [path, error_string(err)])

## Example calls
func _on_play_pressed() -> void:
    go_to_level("res://scenes/levels/level_01.tscn")

func _on_main_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
```

### 2.2 · change\_scene\_to\_packed()

When you have already loaded a `PackedScene` (e.g., preloaded at startup),
 use `change_scene_to_packed()` to avoid hitting the disk a second time:

```gdscript
## Preload at the top of the script (happens at parse time)
const MAIN_MENU := preload("res://scenes/ui/main_menu.tscn")
const LEVEL_01  := preload("res://scenes/levels/level_01.tscn")

func _on_play_pressed() -> void:
    get_tree().change_scene_to_packed(LEVEL_01)

func _on_back_pressed() -> void:
    get_tree().change_scene_to_packed(MAIN_MENU)
```

:::callout-key[Key Concept — When the change takes effect]
Scene changes are

deferred

: Godot queues the swap and applies it at
        the end of the current frame, after all

\_process

and

\_physics\_process

callbacks for that frame have completed.  This means you
        can safely call

change\_scene\_to\_file()

from inside

\_process()

without the scene being torn out from under you mid-frame.
:::

### 2.3 · Passing data between scenes

Because the old scene is freed before the new one is ready, you cannot pass data
 by setting a variable on the new scene from the old one directly. The idiomatic
 Godot patterns are:

**Pattern A — Autoload global:** store data in a singleton before
 changing scenes; the new scene reads it in `_ready()`.

```gdscript
# GameData.gd (Autoload)
extends Node
var selected_level: int = 1
var player_name:    String = "Hero"

# In the menu scene:
func _on_play_pressed() -> void:
    GameData.selected_level = $LevelPicker.get_selected()
    GameData.player_name    = $NameField.text
    get_tree().change_scene_to_file("res://scenes/levels/game.tscn")

# In the game scene's _ready():
func _ready() -> void:
    _load_level(GameData.selected_level)
    $HUD/NameLabel.text = GameData.player_name
```

**Pattern B — Node metadata on the root:** attach data to the scene
 tree root before transitioning; the new scene reads it from `get_tree().root`.
 Less coupling than a named autoload but can become messy for large data sets.

**Pattern C — Persistent subscene:** keep a CanvasLayer or Node that
 does *not* get freed during scene changes by making it a direct child of the
 engine root (not the current scene). Autoloads achieve this automatically.

:::callout-tip[Tip]
Pattern A (autoload global) is the most readable and the most common.  Name the
        autoload something like

GameState

or

SessionData

and keep
        it focused — only data that needs to

survive

scene transitions belongs there.
:::

## 3 · Additive Scene Loading

Sometimes you do not want to replace the entire scene — you want to add a new scene
 on top of the existing one. Common use cases: opening a pause menu while the game
 world keeps running (or stays frozen), showing a pop-up dialog, or dynamically
 loading a new level "room" while keeping global UI alive.

### 3.1 · Instantiating and adding a scene

```gdscript
const PAUSE_MENU := preload("res://scenes/ui/pause_menu.tscn")

var _pause_instance: Node = null

func open_pause_menu() -> void:
    if _pause_instance != null:
        return   # already open

    get_tree().paused = true
    _pause_instance = PAUSE_MENU.instantiate()
    # Add to the root so it renders above everything,
    # or to a dedicated CanvasLayer node
    add_child(_pause_instance)
    # Connect a signal so we know when the menu closes
    _pause_instance.connect("resume_requested", _on_resume)

func _on_resume() -> void:
    _pause_instance.queue_free()
    _pause_instance = null
    get_tree().paused = false
```

### 3.2 · CanvasLayer for persistent UI

If you have global UI (a HUD, a mini-map, a notification banner) that should remain
 visible regardless of which scene is loaded, place it inside a `CanvasLayer`
 that lives in an autoload. Autoloads are children of the engine root, not of the
 current scene, so they are never freed by `change_scene_to_*`.

```gdscript
# HUD.gd  (Autoload — add to Project Settings → Autoloads)
extends CanvasLayer

@onready var _hp_bar:    ProgressBar = $HPBar
@onready var _score_lbl: Label       = $ScoreLabel

func set_hp(current: int, maximum: int) -> void:
    _hp_bar.max_value = maximum
    _hp_bar.value     = current

func set_score(score: int) -> void:
    _score_lbl.text = "Score: %d" % score

func show_hud() -> void: visible = true
func hide_hud() -> void: visible = false
```

Any scene can then call `HUD.set_hp(75, 100)` without worrying about
 whether the HUD node exists in its own subtree.

:::callout-pitfall[Pitfall — Ownership & freeing]
When you call

add\_child(instance)

, the parent node becomes the

owner

of the instance's memory lifecycle —

queue\_free()

on
        the parent will also free the child.  If you add a scene instance to

get\_tree().root

directly, you are responsible for freeing it manually
        with

instance.queue\_free()

at the appropriate time.
:::

## 4 · Async / Threaded Loading

`change_scene_to_file()` loads the scene synchronously on the main thread,
 which causes a visible freeze for large scenes. For seamless loading screens,
 Godot 4 provides `ResourceLoader.load_threaded_request()`: the resource
 loads in a background thread while your loading screen runs animations and progress
 bars normally.

### 4.1 · load\_threaded\_request() and load\_threaded\_get\_status()

```gdscript
## Step 1: Kick off the background load
ResourceLoader.load_threaded_request("res://scenes/levels/level_02.tscn")

## Step 2: Poll progress every frame
func _process(_delta: float) -> void:
    var progress: Array = []   # will be populated with a single float [0.0 - 1.0]
    var status := ResourceLoader.load_threaded_get_status(
        "res://scenes/levels/level_02.tscn", progress
    )
    match status:
        ResourceLoader.THREAD_LOAD_IN_PROGRESS:
            $ProgressBar.value = progress[0] * 100.0
        ResourceLoader.THREAD_LOAD_LOADED:
            _on_load_complete()
        ResourceLoader.THREAD_LOAD_FAILED:
            push_error("Threaded load failed!")
        ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
            push_error("Invalid resource path!")

## Step 3: Retrieve and activate the scene
func _on_load_complete() -> void:
    var packed := ResourceLoader.load_threaded_get(
        "res://scenes/levels/level_02.tscn"
    ) as PackedScene
    get_tree().change_scene_to_packed(packed)
```

| Status constant | Meaning |
| --- | --- |
| `THREAD_LOAD_INVALID_RESOURCE` | Path not found or not a valid resource. |
| `THREAD_LOAD_IN_PROGRESS` | Still loading — check `progress[0]`. |
| `THREAD_LOAD_FAILED` | Load failed due to a corruption or parse error. |
| `THREAD_LOAD_LOADED` | Loading complete — safe to call `load_threaded_get()`. |

### 4.2 · A complete loading screen

The typical pattern: a lightweight `LoadingScreen.tscn` that is loaded
 synchronously (fast because it is small), which then kicks off the threaded load of
 the heavy scene and displays an animated progress bar.

```gdscript
# LoadingScreen.gd
extends Control

@onready var bar:       ProgressBar = $ProgressBar
@onready var anim:      AnimationPlayer = $AnimationPlayer
@onready var tip_label: Label           = $TipLabel

var _target_path: String = ""

const TIPS := [
    "Tip: Double-tap dodge to evade projectiles.",
    "Tip: Hold attack to charge a heavy strike.",
    "Tip: Shops restock between chapters.",
]

func _ready() -> void:
    # The path was stored in a global before changing to this scene
    _target_path = GameState.loading_target_path
    assert(not _target_path.is_empty(), "LoadingScreen: no target path set!")

    tip_label.text = TIPS[randi() % TIPS.size()]
    anim.play("spin")

    ResourceLoader.load_threaded_request(_target_path)

func _process(_delta: float) -> void:
    var progress: Array = []
    var status := ResourceLoader.load_threaded_get_status(_target_path, progress)

    if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
        bar.value = progress[0] * 100.0
    elif status == ResourceLoader.THREAD_LOAD_LOADED:
        bar.value = 100.0
        # Brief pause so the bar reaches 100% visually
        await get_tree().create_timer(0.3).timeout
        var packed := ResourceLoader.load_threaded_get(_target_path) as PackedScene
        get_tree().change_scene_to_packed(packed)
    elif status == ResourceLoader.THREAD_LOAD_FAILED:
        push_error("Failed to load: %s" % _target_path)
        get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
```

## 5 · SceneManager Autoload

Rather than calling `get_tree().change_scene_to_file()` from scattered
 locations throughout your codebase, centralise all scene transitions in a single
 autoload. This gives you one place to add fade transitions, enforce loading screen
 logic, and maintain a navigation history.

### 5.1 · Fade transitions

A `ColorRect` that covers the full screen, animated from transparent
 to opaque (fade out) and back (fade in), is the simplest transition effect that
 works for any scene change:

```gdscript
# SceneManager.gd  (Autoload)
extends CanvasLayer

## Emitted after the new scene's _ready() has been called
signal scene_changed(new_path: String)

const LOADING_SCREEN := "res://scenes/ui/loading_screen.tscn"
const FADE_DURATION  := 0.35   # seconds

@onready var _overlay: ColorRect    = $FadeOverlay   # full-screen black rect, alpha=0
@onready var _tween:   Tween        = null

var _history: Array[String] = []

func _ready() -> void:
    _overlay.color = Color.BLACK
    _overlay.modulate.a = 0.0
    # Ensure the overlay always renders on top
    layer = 128

## Navigate to a new scene with a fade transition
func go_to(path: String, use_loading_screen: bool = false) -> void:
    _history.push_back(get_tree().current_scene.scene_file_path)

    await _fade_out()

    if use_loading_screen:
        GameState.loading_target_path = path
        get_tree().change_scene_to_file(LOADING_SCREEN)
    else:
        get_tree().change_scene_to_file(path)

    # Wait one frame for the new scene's _ready() to complete
    await get_tree().process_frame

    _fade_in()
    scene_changed.emit(path)

## Go back to the previous scene
func go_back() -> void:
    if _history.is_empty():
        push_warning("SceneManager: no history to go back to.")
        return
    var prev: String = _history.pop_back()
    await _fade_out()
    get_tree().change_scene_to_file(prev)
    await get_tree().process_frame
    _fade_in()

## Reload the current scene with a transition
func reload_current() -> void:
    await _fade_out()
    get_tree().reload_current_scene()
    await get_tree().process_frame
    _fade_in()

# ── Internal ──────────────────────────────────────────────────────────

func _fade_out() -> void:
    _tween = create_tween()
    _tween.tween_property(_overlay, "modulate:a", 1.0, FADE_DURATION)
    await _tween.finished

func _fade_in() -> void:
    _tween = create_tween()
    _tween.tween_property(_overlay, "modulate:a", 0.0, FADE_DURATION)
    # Don't await — let it run in the background
```

Usage from anywhere in the game is now a single call:

```gdscript
func _on_play_pressed() -> void:
    SceneManager.go_to("res://scenes/levels/level_01.tscn")

func _on_big_level_pressed() -> void:
    # Use the loading screen for heavy scenes
    SceneManager.go_to("res://scenes/levels/world_map.tscn", true)

func _on_back_pressed() -> void:
    SceneManager.go_back()

func _on_retry_pressed() -> void:
    SceneManager.reload_current()
```

### 5.2 · Scene history & navigation stack

The `_history` array in the SceneManager acts as a simple back-stack.
 This is particularly useful for menu flows where the player may navigate several
 levels deep (Main Menu → Options → Controls → Rebind) and wants to press a
 "Back" button to unwind cleanly.

:::callout-tip[Tip — Clearing history on game start]
Call

SceneManager.\_history.clear()

when transitioning from the main
        menu to the game world, so "back" in-game does not accidentally return to the menu.
        Alternatively, expose a

go\_to\_root(path)

method that clears history
        before navigating.
:::

:::callout-connect[Connect — Saving & scene transitions]
A common pattern is to trigger an autosave in the SceneManager's

go\_to()

just before the fade-out, guaranteeing that the player's position and state are saved
        at every scene boundary.  Connect the

scene\_changed

signal in your
        SaveManager autoload (Chapter 24) to perform this without coupling the two autoloads
        directly.
:::

## Summary

Scene management in Godot revolves around the `SceneTree` singleton and
 three transition strategies. For simple hops between small scenes use
 `change_scene_to_file()` or `change_scene_to_packed()` — they
 are synchronous but deferred to the end of the frame so they are safe to call from
 anywhere. For UI overlays and anything that must survive scene changes, use
 additive `add_child()` loading, with persistent nodes living in autoloads
 as `CanvasLayer` children. For heavy scenes that would freeze the screen,
 use `ResourceLoader.load_threaded_request()` combined with a dedicated
 loading screen that polls `load_threaded_get_status()` each frame.
 Centralising all transitions in a `SceneManager` autoload with a fade
 overlay and a history stack keeps the rest of the codebase clean and makes it trivial
 to add transition effects or autosave hooks later.

| Strategy | Blocks main thread? | Keeps old scene alive? | Best for |
| --- | --- | --- | --- |
| `change_scene_to_file/packed` | Yes (brief) | No | Simple level-to-level transitions |
| `add_child(scene.instantiate())` | Yes (brief) | Yes | UI overlays, pause menus, sub-rooms |
| `load_threaded_request` | No | Yes (loading screen) | Large worlds, open-world streaming |

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Delayed scene change

Write a function `go_after_delay(path: String, secs: float) -> void`
 that waits for the given number of seconds using a
 `SceneTreeTimer`, then calls
 `change_scene_to_file()`. Test it with a 2-second delay to a
 "game over" scene.

::::solution[Solution]
```gdscript
func go_after_delay(path: String, secs: float) -> void:
    await get_tree().create_timer(secs).timeout
    get_tree().change_scene_to_file(path)

# Usage:
func _on_player_died() -> void:
    go_after_delay("res://scenes/ui/game_over.tscn", 2.0)
```
::::
:::

:::problem{difficulty="easy"}
### P2 · Group broadcast

Create a scene with five `Label` nodes that all belong to the group
 `"status_labels"`. Write a function
 `update_all_labels(text: String) -> void` that uses
 `call_group()` to set the `text` property on all of them
 simultaneously. Confirm the update works by calling it from a Button's
 `pressed` signal.

::::solution[Solution]
```gdscript
## In each Label's script (or set the group in the editor):
# func _ready() -> void:
#     add_to_group("status_labels")

## In the parent scene script:
func update_all_labels(text: String) -> void:
    for lbl in get_tree().get_nodes_in_group("status_labels"):
        (lbl as Label).text = text

func _on_update_pressed() -> void:
    update_all_labels("Updated: %s" % Time.get_time_string_from_system())
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Additive pause menu

Build a minimal pause menu system:

1. A `PauseMenu.tscn` with a "Resume" button and a "Quit to Menu" button.
 The scene's root has a signal `resume_requested`.
2. In the main game scene, pressing Escape instantiates and adds
 the pause menu as a child, sets `get_tree().paused = true`, and
 gives the pause menu `process_mode = ALWAYS` so its buttons still
 respond.
3. "Resume" emits `resume_requested`, which the main scene catches
 to free the menu and unpause.
4. "Quit to Menu" frees the menu, unpauses, and calls
 `change_scene_to_file("res://scenes/ui/main_menu.tscn")`.

::::solution[Solution]
```gdscript
# PauseMenu.gd
extends Control
signal resume_requested

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS

func _on_resume_pressed() -> void:
    resume_requested.emit()

func _on_quit_pressed() -> void:
    get_tree().paused = false
    get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")

# GameScene.gd (excerpt)
const PAUSE_MENU := preload("res://scenes/ui/pause_menu.tscn")
var _pause_inst: Node = null

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel") and _pause_inst == null:
        _open_pause()

func _open_pause() -> void:
    get_tree().paused = true
    _pause_inst = PAUSE_MENU.instantiate()
    add_child(_pause_inst)
    _pause_inst.connect("resume_requested", _close_pause)

func _close_pause() -> void:
    _pause_inst.queue_free()
    _pause_inst = null
    get_tree().paused = false
```
::::
:::

:::problem{difficulty="standard"}
### P4 · Threaded loading with progress bar

Build a `LoadingScreen` scene that:

1. Reads `GameState.loading_target_path` in `_ready()`
 and immediately calls `ResourceLoader.load_threaded_request()`.
2. In `_process()`, polls the status and updates a
 `ProgressBar` (value 0–100).
3. When loading completes, waits 0.2 seconds then calls
 `change_scene_to_packed()` with the loaded scene.
4. If loading fails, shows an error label and returns to the main menu after
 2 seconds.

::::solution[Solution]
```gdscript
# LoadingScreen.gd
extends Control

@onready var bar:   ProgressBar = $ProgressBar
@onready var err:   Label       = $ErrorLabel

var _path: String = ""

func _ready() -> void:
    _path = GameState.loading_target_path
    err.visible = false
    ResourceLoader.load_threaded_request(_path)

func _process(_delta: float) -> void:
    var prog: Array = []
    var status := ResourceLoader.load_threaded_get_status(_path, prog)

    match status:
        ResourceLoader.THREAD_LOAD_IN_PROGRESS:
            bar.value = prog[0] * 100.0

        ResourceLoader.THREAD_LOAD_LOADED:
            bar.value = 100.0
            set_process(false)
            await get_tree().create_timer(0.2).timeout
            var ps := ResourceLoader.load_threaded_get(_path) as PackedScene
            get_tree().change_scene_to_packed(ps)

        ResourceLoader.THREAD_LOAD_FAILED, \
        ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
            set_process(false)
            err.text  = "Failed to load scene."
            err.visible = true
            await get_tree().create_timer(2.0).timeout
            get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Persistent HUD autoload

Create a `HUD` autoload (CanvasLayer) with:

- A `ProgressBar` for HP (0–100).
- A `Label` for score.
- Methods: `set_hp(v, max)`, `add_score(pts)`,
 `show()`, `hide()`.

Confirm it persists across a scene change: call `HUD.set_hp(50, 100)`
 in Scene A, change to Scene B, and verify the HUD still shows 50/100 HP without
 any setup code in Scene B.

::::solution[Solution]
```gdscript
# HUD.gd  (Autoload — CanvasLayer)
extends CanvasLayer

@onready var hp_bar:   ProgressBar = $HPBar
@onready var score_lbl: Label      = $ScoreLabel

var _score: int = 0

func _ready() -> void:
    hp_bar.max_value = 100
    hp_bar.value     = 100
    score_lbl.text   = "Score: 0"

func set_hp(current: int, maximum: int) -> void:
    hp_bar.max_value = maximum
    hp_bar.value     = current

func add_score(pts: int) -> void:
    _score += pts
    score_lbl.text = "Score: %d" % _score

func show_hud() -> void: visible = true
func hide_hud() -> void: visible = false
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full SceneManager with fade, history & loading screen

Build the complete `SceneManager` autoload from Section 5 with
 the following additional requirements:

1. A `go_to_root(path)` method that clears the history stack before
 navigating (for Main Menu → Game transitions).
2. A `history_size() -> int` helper that returns the number of
 entries in the back-stack.
3. The `go_to()` method accepts an optional
 `transition_data: Dictionary = {}` parameter that is stored in
 `GameState.scene_transition_data` before the scene change, so
 the incoming scene can read it from `_ready()`.
4. A `scene_changing(from, to)` signal emitted before the fade-out
 and a `scene_changed(path)` signal emitted after the fade-in.
5. The fade duration is configurable via an exported
 `@export var fade_secs: float = 0.35`.

::::solution[Solution]
```gdscript
# SceneManager.gd  (Autoload — CanvasLayer)
extends CanvasLayer

signal scene_changing(from_path: String, to_path: String)
signal scene_changed(new_path: String)

@export var fade_secs: float = 0.35

@onready var _overlay: ColorRect = $FadeOverlay

var _history: Array[String] = []
var _tween:   Tween          = null

func _ready() -> void:
    layer = 128
    _overlay.color       = Color.BLACK
    _overlay.modulate.a  = 0.0

# ── Public API ────────────────────────────────────────────────────────

func go_to(path: String,
           use_loading: bool = false,
           transition_data: Dictionary = {}) -> void:
    var from := get_tree().current_scene.scene_file_path
    _history.push_back(from)
    await _navigate(from, path, use_loading, transition_data)

func go_to_root(path: String,
                use_loading: bool = false,
                transition_data: Dictionary = {}) -> void:
    var from := get_tree().current_scene.scene_file_path
    _history.clear()
    await _navigate(from, path, use_loading, transition_data)

func go_back() -> void:
    if _history.is_empty():
        push_warning("SceneManager: history is empty.")
        return
    var prev := _history.pop_back() as String
    var from := get_tree().current_scene.scene_file_path
    await _navigate(from, prev, false, {})

func reload_current() -> void:
    var path := get_tree().current_scene.scene_file_path
    await _navigate(path, path, false, {})
    get_tree().reload_current_scene()

func history_size() -> int:
    return _history.size()

# ── Internal ──────────────────────────────────────────────────────────

func _navigate(from: String, to: String,
               use_loading: bool,
               data: Dictionary) -> void:
    scene_changing.emit(from, to)

    if not data.is_empty():
        GameState.scene_transition_data = data

    await _fade_out()

    if use_loading:
        GameState.loading_target_path = to
        get_tree().change_scene_to_file("res://scenes/ui/loading_screen.tscn")
    else:
        get_tree().change_scene_to_file(to)

    await get_tree().process_frame
    _fade_in()
    scene_changed.emit(to)

func _fade_out() -> void:
    if _tween: _tween.kill()
    _tween = create_tween()
    _tween.tween_property(_overlay, "modulate:a", 1.0, fade_secs)
    await _tween.finished

func _fade_in() -> void:
    if _tween: _tween.kill()
    _tween = create_tween()
    _tween.tween_property(_overlay, "modulate:a", 0.0, fade_secs)
```
::::
:::
