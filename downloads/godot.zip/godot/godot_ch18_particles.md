---
title: "Particles — GPUParticles, CPUParticles & Scripting VFX"
source: "godot_ch18_particles.html"
---

Part III · Chapter 18

# Particles — GPUParticles, CPUParticles & Scripting VFX

Prerequisite: Chapter 14 (Tween / Animation) · est. 75 min

## Overview

Godot has two particle families that serve distinct needs:

- **GPUParticles2D / GPUParticles3D** — simulate thousands of particles on the
 GPU using a compute shader. Very fast for large counts but require a GPU that supports
 compute shaders (not available on all mobile targets).
- **CPUParticles2D / CPUParticles3D** — simulate entirely on the CPU.
 Slower per-particle but work everywhere, support path following, and are easier to read
 back in GDScript.

Both systems share the same conceptual model: a *spawner* node emits *particles*
 according to a *process material* that controls initial velocity, gravity, colour over
 lifetime, scale curves, and more. All the tuning happens inside the material resource, not in
 the node itself.

⬡ — GPUParticles2D — inherits Node2D

Simulates and renders 2D particles entirely on the GPU using a compute shader. Each particle is a tiny quad (or custom texture region) whose position, velocity, colour, and scale are driven by a `ParticleProcessMaterial`. Thousands of particles cost almost nothing extra — the GPU excels at this kind of massively parallel work.

| Property | Default | What it does |
| --- | --- | --- |
| amount | 8 | Total particle slots — all pre-allocated on GPU. More = more VRAM. Recycle oldest when pool is full |
| lifetime | 1.0 s | How long each particle lives in seconds before being recycled from the pool |
| process\_material | null | **Required.** A ParticleProcessMaterial (or ShaderMaterial) that defines ALL particle behaviour — velocity, direction, gravity, colour gradient, size curve, turbulence, attractor interaction |
| texture | null | Sprite sheet or single image drawn at each particle position. Without this, particles render as white squares |
| emitting | true | Toggle emission on/off — particles already alive finish their lifetime naturally |
| one\_shot | false | Emit all particles once then stop — great for impact bursts and pickups |
| explosiveness | 0.0 | 0 = continuous trickle, 1 = all particles born simultaneously — combine with one\_shot for bang effects |
| preprocess | 0.0 s | Advance simulation by this many seconds on spawn — rain appears full from the start instead of ramping up |
| speed\_scale | 1.0 | Global time multiplier — 0 freezes, 2.0 runs double speed |
| fixed\_fps | 30 | Simulate at this frame rate — 0 = sync to render. Setting 30 saves GPU on dense effects |
| visibility\_rect | auto | 2D AABB for frustum culling. Expand manually if particles drift far outside the emitter |
| sub\_emitter | null | A second GPUParticles2D spawned when each particle dies — chain for complex effects like sparks from fire |

Use when:

you need high-volume visual effects — fire, smoke, sparks, rain, snow, magic auras, screen-space confetti.

Prefer CPUParticles2D when:

targeting WebGL or low-end mobile without compute shader support, or needing fewer than ~100 particles with GDScript-driven behaviour.

Always assign a process\_material

— without one, no particles appear and Godot prints a warning.

## 1 · GPUParticles2D

:::callout-intuition[How GPUParticles2D works]
The GPU runs a **compute shader** that simulates every particle
 in parallel. You configure the simulation via a
 `ParticleProcessMaterial` resource and control visuals via
 **draw passes** (what the particle looks like). The CPU only
 touches the particle system to set initial properties and call
 `restart()` — everything else runs on the GPU each frame.
:::

GPUParticles2D

amount, lifetime, speed\_scale

one\_shot, explosiveness, preprocess

has

ParticleProcessMaterial

emission\_shape

direction / spread

initial\_velocity\_min/max

gravity / radial\_accel

scale\_curve / color\_ramp

(Gradient / Curve resources)

+

Draw Passes (1–4)

Mesh2D (QuadMesh default)

or texture / atlas

+ optional material override

The three parts of a particle system: the **node** controls timing, the **process material** controls per-particle physics and colour, and the **draw passes** control appearance.

### 1.1 · ParticleProcessMaterial — the control centre

Every `GPUParticles2D` node has a `process_material` property that holds
 a `ParticleProcessMaterial` resource. This is where all the per-particle physics
 live. The most important properties:

| Property group | Properties | Controls |
| --- | --- | --- |
| **Emission** | `emission_shape`, `emission_sphere_radius`, `emission_rect_extents` | Where particles are born |
| **Direction / Spread** | `direction`, `spread`, `flatness` | Initial velocity direction cone |
| **Initial Velocity** | `initial_velocity_min/max` | Speed range at birth |
| **Gravity** | `gravity` | Constant acceleration (world-space Vector3) |
| **Linear Accel** | `linear_accel_min/max` | Acceleration along direction of travel |
| **Radial Accel** | `radial_accel_min/max` | Pull toward / push away from emitter |
| **Tangential Accel** | `tangent_accel_min/max` | Orbit effect around emitter |
| **Scale** | `scale_min/max`, `scale_curve` | Particle size over lifetime (Curve) |
| **Color** | `color`, `color_ramp` | Constant color or Gradient over lifetime |
| **Lifetime Randomness** | `lifetime_randomness` | 0–1; adds variation to particle lifetimes |

### 1.2 · Emission shapes

```gdscript

var mat := ParticleProcessMaterial.new()

# Emit from a point (default)
mat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_POINT

# Emit from a sphere
mat.emission_shape         = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
mat.emission_sphere_radius = 30.0

# Emit from a rectangle area
mat.emission_shape        = ParticleProcessMaterial.EMISSION_SHAPE_RECTANGLE
mat.emission_rect_extents = Vector3(100.0, 20.0, 0.0)   # half-extents

# Emit from the surface of a sphere (ring effect in 2D)
mat.emission_shape         = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE_SURFACE
mat.emission_sphere_radius = 60.0

$GPUParticles2D.process_material = mat
```

### 1.3 · Draw passes — what the particle looks like

The `draw_pass_1` (and up to 4 passes) property holds a `Mesh` that
 each particle renders. For 2D particles the mesh is typically a
 `QuadMesh` with a `CanvasItemMaterial` or a sprite texture:

```gdscript

var particles: GPUParticles2D = $GPUParticles2D

# Use a texture (most common 2D case — set in the inspector via Texture property):
particles.texture = preload("res://vfx/spark.png")

# Or build a QuadMesh for a custom shape programmatically:
var quad := QuadMesh.new()
quad.size = Vector2(8, 8)
var mat := StandardMaterial3D.new()
mat.albedo_texture = preload("res://vfx/spark.png")
mat.transparency   = BaseMaterial3D.TRANSPARENCY_ALPHA
quad.surface_set_material(0, mat)
particles.draw_pass_1 = quad
```

### 1.4 · One-shot bursts

Set `one_shot = true` and `explosiveness` close to 1.0 to emit all
 particles at once rather than over time — essential for hit sparks, explosions, and pickups:

```gdscript

func spawn_burst(particles: GPUParticles2D) -> void:
    particles.one_shot      = true
    particles.explosiveness = 0.95   # emit 95% of particles in the first frame
    particles.restart()              # restart the emission cycle

# To auto-free a one-shot effect after particles die:
func spawn_burst_and_free(scene: PackedScene, pos: Vector2) -> void:
    var inst := scene.instantiate() as GPUParticles2D
    inst.position = pos
    inst.one_shot = true
    inst.finished.connect(inst.queue_free)
    add_child(inst)
    inst.restart()
```

:::callout-tip
💡 Pre-simulate to avoid cold-start

Continuous particle effects (campfire, rain) look wrong for a fraction of a second after the
        scene loads because the emitter starts from zero.  Set

preprocess = 2.0

on the
        node to simulate 2 seconds ahead before the first frame renders.
:::

⬡ — CPUParticles2D — inherits Node2D

A CPU-driven particle system that simulates particles in GDScript-accessible data arrays rather than on the GPU. It shares almost all inspector properties with GPUParticles2D and can be converted from one to the other in one click. The trade-off: slower for large counts but works everywhere and doesn't need a compute shader.

| Property | Default | What it does |
| --- | --- | --- |
| amount | 8 | Particle pool size — keep lower than GPU equivalent; CPU cost scales linearly with amount |
| lifetime | 1.0 s | Seconds each particle lives before recycling |
| emitting | true | Enable/disable emission without removing the node |
| one\_shot | false | Emit one burst and stop — set explosiveness = 1.0 for an instant bang |
| explosiveness | 0.0 | 0 = particles spawn spread over the lifetime; 1 = all spawn simultaneously (burst) |
| spread | 45° | Angle cone of the initial emission direction |
| initial\_velocity\_min/max | 0 / 0 | Random launch speed range for each particle |
| gravity | Vector2(0, 980) | Applied to every particle each frame — override per-emitter independently of physics gravity |
| scale\_amount\_min/max | 1 / 1 | Random size range for particles at birth |
| color | white | Base tint — multiply with color\_ramp curve for animated colour over lifetime |

Use when:

targeting web exports or mobile (no GPU compute), needing < ~200 particles, or wanting to manipulate particles from GDScript.

Prefer GPUParticles2D when:

you need hundreds or thousands of particles simultaneously — fire, dense rain, confetti explosions.

Conversion tip:

right-click a GPUParticles2D in the scene tree → "Convert to CPUParticles2D" preserves all settings automatically.

## 2 · CPUParticles2D

### 2.1 · CPU vs GPU — choosing the right node

|  | GPUParticles2D | CPUParticles2D |
| --- | --- | --- |
| **Max count** | Tens of thousands comfortably | Hundreds to a few thousand |
| **Platform** | Requires compute shader support | Works everywhere (mobile, web) |
| **GDScript access** | No per-particle read-back | Can read particle positions/velocities |
| **Path following** | Not supported directly | Supported via `emission_shape = CURVE` |
| **Conversion** | Right-click → Convert to CPUParticles2D | Right-click → Convert to GPUParticles2D |

### 2.2 · Key CPUParticles2D properties

The API mirrors GPUParticles2D but uses *direct properties* rather than a process material:

```gdscript

var cpu: CPUParticles2D = $CPUParticles2D

cpu.amount            = 64
cpu.lifetime          = 1.2
cpu.one_shot          = false
cpu.explosiveness     = 0.0   # spread over lifetime
cpu.speed_scale       = 1.0

# Direction / spread
cpu.direction         = Vector2(0, -1)   # upward
cpu.spread            = 45.0            # ±45° cone
cpu.initial_velocity_min = 60.0
cpu.initial_velocity_max = 120.0

# Gravity
cpu.gravity           = Vector2(0, 98.0)

# Scale curve — grow then shrink
var curve := Curve.new()
curve.add_point(Vector2(0.0, 0.2))
curve.add_point(Vector2(0.5, 1.0))
curve.add_point(Vector2(1.0, 0.0))
cpu.scale_curve = curve

# Colour gradient — yellow to transparent
var grad := Gradient.new()
grad.set_color(0, Color(1.0, 0.9, 0.2, 1.0))
grad.set_color(1, Color(1.0, 0.3, 0.0, 0.0))
cpu.color_ramp = grad
```

⬡ — GPUParticles3D — inherits GeometryInstance3D → VisualInstance3D → Node3D

The 3D counterpart to GPUParticles2D. Thousands of particles are simulated and rendered entirely on the GPU using a `ParticleProcessMaterial`, with each particle rendered as a mesh (billboard quad by default, or any Mesh resource). Used for fire, smoke, sparks, rain, magic effects, and ambient environment particles in 3D scenes.

| Property | Default | What it does |
| --- | --- | --- |
| amount | 8 | Total particle count in the pool — all particles are allocated upfront on the GPU |
| lifetime | 1.0 s | How long each particle lives before being recycled |
| process\_material | null | A ParticleProcessMaterial (or ShaderMaterial) defining all particle behaviour — velocity, gravity, colour, scale, turbulence |
| draw\_pass\_1 | QuadMesh | The mesh each particle renders as — swap for SphereMesh, custom mesh, or a ribbon for trails |
| emitting | true | Start/stop emission without freeing the node |
| one\_shot | false | Emit all particles once then stop — combine with explosions\_from\_emitter = true for burst effects |
| preprocess | 0.0 s | Fast-forwards the simulation on spawn — rain looks established from frame 1 instead of trickling in |
| visibility\_aabb | auto | Bounding box for frustum culling — set manually if particles travel far from the emitter origin |
| collision\_base\_size | 0.01 | Particle size used for collision detection when the process material has collision enabled |

Use when:

you need large-volume 3D particle effects — fire, smoke columns, rain, waterfall mist, magic auras.

Prefer CPUParticles3D when:

targeting mobile/web where GPU compute isn't reliable, or when you need particles to react to GDScript logic per-particle.

Perf tip:

keep

amount

as low as visually acceptable — GPU particles are cheap but not free. Use

visibility\_aabb

so off-screen emitters are culled.

## 3 · GPUParticles3D

### 3.1 · 3D process material and draw mesh

GPUParticles3D works identically to its 2D counterpart, but the gravity vector lives in 3D
 and the draw pass uses a `Mesh` rendered in 3D space. The most common mesh for
 sprite-like particles is a `QuadMesh` with **billboard mode** so the
 quad always faces the camera:

```gdscript

# Build a billboard spark particle in code
func make_spark_particles() -> GPUParticles3D:
    var p := GPUParticles3D.new()
    p.amount     = 200
    p.lifetime   = 0.8
    p.one_shot   = true
    p.explosiveness = 0.9

    # Process material
    var mat := ParticleProcessMaterial.new()
    mat.direction             = Vector3(0, 1, 0)
    mat.spread                = 60.0
    mat.initial_velocity_min  = 2.0
    mat.initial_velocity_max  = 6.0
    mat.gravity               = Vector3(0, -9.8, 0)
    mat.scale_min             = 0.05
    mat.scale_max             = 0.15
    var grad := Gradient.new()
    grad.set_color(0, Color(1, 0.8, 0.2, 1))
    grad.set_color(1, Color(1, 0.2, 0,   0))
    mat.color_ramp = grad
    p.process_material = mat

    # Billboard quad mesh
    var quad := QuadMesh.new()
    quad.size = Vector2(0.15, 0.15)
    var draw_mat := StandardMaterial3D.new()
    draw_mat.transparency        = BaseMaterial3D.TRANSPARENCY_ALPHA
    draw_mat.billboard_mode      = BaseMaterial3D.BILLBOARD_ENABLED
    draw_mat.albedo_texture      = preload("res://vfx/spark.png")
    draw_mat.shading_mode        = BaseMaterial3D.SHADING_MODE_UNSHADED
    quad.surface_set_material(0, draw_mat)
    p.draw_pass_1 = quad

    return p
```

### 3.2 · Particle collision

Both GPU and CPU particles can collide with the world. For GPUParticles3D, enable
 `collision_friction` and `collision_bounce` in the
 `ParticleProcessMaterial`, then add a **GPUParticlesCollision** node
 to the scene (box, sphere, or SDF-based):

```gdscript

# Enable collision in the process material:
mat.collision_friction = 0.2
mat.collision_bounce   = 0.3

# GPUParticlesCollisionBox3D — add to scene, set size to cover your floor/walls.
# GPUParticlesCollisionSDF3D — for complex geometry:
#   1. Add GPUParticlesCollisionSDF3D node
#   2. Set its extents to cover the area
#   3. Click "Bake SDF" in the editor or call bake() at runtime

# For CPUParticles3D collision, set:
cpu.collision_mode = CPUParticles3D.COLLISION_RIGID
cpu.collision_use_scale = false
```

:::callout-warning
⚠️ GPU particle collision and mobile

GPUParticlesCollisionSDF3D

requires a modern GPU.  For mobile titles, use

CPUParticles3D

with collision, or skip collision and simulate it manually.
:::

## 4 · Scripting Particles

### 4.1 · Spawning one-shot effects at runtime

The cleanest pattern is a **VFX spawner singleton** (autoload) that instantiates
 pre-configured `PackedScene`s and removes them after their lifetime:

```gdscript

# VFX.gd — Autoload
extends Node

# Preloaded effect scenes — each scene contains a GPUParticles2D configured as one_shot
@export var hit_spark     : PackedScene
@export var coin_pickup   : PackedScene
@export var explosion     : PackedScene

func spawn(scene: PackedScene, pos: Vector2, parent: Node = null) -> void:
    var inst := scene.instantiate() as GPUParticles2D
    inst.global_position = pos
    inst.one_shot        = true
    inst.finished.connect(inst.queue_free)
    var target := parent if parent else get_tree().current_scene
    target.add_child(inst)
    inst.restart()   # start emission immediately

# Usage from any script:
# VFX.spawn(VFX.hit_spark, global_position)
# VFX.spawn(VFX.explosion, explosion_pos)
```

### 4.2 · Changing particle properties at runtime

```gdscript

# Access the process material and modify it at runtime
@onready var particles: GPUParticles2D = $BloodParticles

func set_impact_strength(strength: float) -> void:
    var mat := particles.process_material as ParticleProcessMaterial
    mat.initial_velocity_min = 40.0 * strength
    mat.initial_velocity_max = 120.0 * strength
    mat.spread               = lerpf(20.0, 80.0, strength)

func set_fire_color(hot: bool) -> void:
    var mat := particles.process_material as ParticleProcessMaterial
    var grad := Gradient.new()
    if hot:
        grad.set_color(0, Color(1.0, 0.5, 0.0, 1.0))
        grad.set_color(1, Color(1.0, 1.0, 0.0, 0.0))
    else:
        grad.set_color(0, Color(0.3, 0.3, 1.0, 1.0))
        grad.set_color(1, Color(0.0, 0.1, 0.8, 0.0))
    mat.color_ramp = grad
```

### 4.3 · The finished signal

`GPUParticles2D.finished` emits when a **one-shot** effect has
 completed all its particles' lifetimes — not when emission stops, but when the last particle
 actually dies. This is the correct time to `queue_free` or to signal game logic:

```gdscript

func play_death_effect(pos: Vector2) -> void:
    var eff := preload("res://vfx/death_burst.tscn").instantiate() as GPUParticles2D
    eff.global_position = pos
    eff.finished.connect(func():
        eff.queue_free()
        EventBus.emit_signal("death_vfx_complete")
    )
    get_tree().current_scene.add_child(eff)
    eff.restart()
```

:::callout-pitfall
🔴 Pitfall — emitting is not playing

Setting

emitting = true

on a GPUParticles node starts the emission cycle from the
        beginning.  But

restart()

is more reliable: it resets internal timers and works
        even if the node was previously mid-emission.  Always prefer

restart()

for
        one-shot effects triggered at runtime.
:::

## Summary

| Concept | Key takeaway |
| --- | --- |
| **GPUParticles2D/3D** | GPU-simulated — fast, high counts; configure via `ParticleProcessMaterial` |
| **CPUParticles2D/3D** | CPU-simulated — portable, GDScript-readable, supports path emission |
| **one\_shot + explosiveness** | All particles born at once — use for burst effects; connect `finished` to queue\_free |
| **preprocess** | Pre-simulate N seconds so looping effects (fire, rain) look full from frame 1 |
| **color\_ramp (Gradient)** | Fade colour over lifetime — the single biggest visual improvement to any particle effect |
| **scale\_curve (Curve)** | Grow then shrink — adds weight and impact to particles |
| **VFX autoload** | Centralised spawner — one call from anywhere, automatic cleanup |

- Design particle effects in the editor first; script only what needs to be dynamic at runtime.
- Use `color_ramp` (gradient) and `scale_curve` before any other parameter — they give the biggest visual return per minute.
- Convert GPU ↔ CPU particles with right-click → Convert when targeting broad platforms.
- Pre-configure effects as `PackedScene`s and spawn them via a VFX autoload for clean separation of concerns.
- Always call `restart()`, not just `emitting = true`, for reliable one-shot effects.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · One-shot coin burst

When a coin is collected, spawn a golden particle burst at the coin's world position
 and `queue_free` the effect after it finishes. The particle scene is
 available as `preload("res://vfx/coin_burst.tscn")`.

::::solution[Solution]
```gdscript

extends Area2D

func collect() -> void:
    var eff := preload("res://vfx/coin_burst.tscn").instantiate() as GPUParticles2D
    eff.global_position = global_position
    eff.one_shot        = true
    eff.finished.connect(eff.queue_free)
    get_tree().current_scene.add_child(eff)
    eff.restart()
    queue_free()
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Rain with preprocess

Configure a `CPUParticles2D` in code to simulate rainfall: particles spawn
 from a 500 px wide horizontal line at the top of the screen, fall downward at 300–500 px/s,
 live for 1.5 s, and look full from the very first frame (no warm-up).

::::solution[Solution]
```gdscript

func _ready() -> void:
    var rain: CPUParticles2D = $RainParticles
    rain.amount              = 300
    rain.lifetime            = 1.5
    rain.preprocess          = 1.5   # look full immediately
    rain.emission_shape      = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
    rain.emission_rect_extents = Vector2(250, 1)   # half-extents → 500 px wide
    rain.direction           = Vector2(0, 1)        # downward
    rain.spread              = 5.0
    rain.initial_velocity_min = 300.0
    rain.initial_velocity_max = 500.0
    rain.gravity             = Vector2.ZERO
    rain.emitting            = true
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Fire effect with colour gradient and scale curve

Build a fire CPUParticles2D entirely in code. Particles should:

- Emit upward with spread 30° from a point emitter.
- Fade from bright orange at birth to transparent red at death (colour gradient).
- Scale from small to large to tiny over their lifetime (scale curve: 0.3 → 1.0 → 0.0).
- Use `preprocess = 1.0` so the fire looks established immediately.

::::solution[Solution]
```gdscript

func _ready() -> void:
    var fire: CPUParticles2D = $FireParticles
    fire.amount              = 80
    fire.lifetime            = 1.0
    fire.preprocess          = 1.0
    fire.direction           = Vector2(0, -1)
    fire.spread              = 30.0
    fire.initial_velocity_min = 40.0
    fire.initial_velocity_max = 80.0
    fire.gravity             = Vector2(0, -20)   # slight upward drift

    # Colour gradient
    var grad := Gradient.new()
    grad.set_color(0, Color(1.0, 0.6, 0.0, 1.0))   # bright orange
    grad.set_color(1, Color(0.8, 0.1, 0.0, 0.0))   # transparent red
    fire.color_ramp = grad

    # Scale curve: small → large → gone
    var curve := Curve.new()
    curve.add_point(Vector2(0.0, 0.3))
    curve.add_point(Vector2(0.4, 1.0))
    curve.add_point(Vector2(1.0, 0.0))
    fire.scale_amount_curve = curve

    fire.emitting = true
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Impact direction particles

When a bullet hits a surface, spawn a `CPUParticles2D` burst where particles
 fly outward in the *reflected* direction of the bullet's travel. The function
 receives the bullet velocity vector and the surface normal.

::::solution[Solution]
```gdscript

func spawn_impact(pos: Vector2, bullet_vel: Vector2, surface_normal: Vector2) -> void:
    var reflected := bullet_vel.bounce(surface_normal).normalized()

    var eff: CPUParticles2D = $ImpactTemplate.duplicate() as CPUParticles2D
    eff.global_position      = pos
    eff.direction            = reflected
    eff.spread               = 40.0
    eff.initial_velocity_min = 80.0
    eff.initial_velocity_max = 200.0
    eff.amount               = 20
    eff.lifetime             = 0.4
    eff.one_shot             = true
    eff.explosiveness        = 0.9
    eff.finished.connect(eff.queue_free)
    get_tree().current_scene.add_child(eff)
    eff.emitting = true
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Magic trail following the player

Attach a `GPUParticles2D` to the player that emits a trailing sparkle effect.
 The particles should have a slight random spread, fade from white to purple over their
 0.5 s lifetime, and turn off when the player is idle (velocity near zero).

::::solution[Solution]
```gdscript

extends CharacterBody2D

@onready var trail: GPUParticles2D = $TrailParticles

func _physics_process(_delta: float) -> void:
    # Movement logic here...
    var moving := velocity.length() > 20.0
    trail.emitting = moving

    if moving:
        # Point emission opposite to movement direction (behind the player)
        var mat := trail.process_material as ParticleProcessMaterial
        mat.direction = Vector3(-velocity.normalized().x, -velocity.normalized().y, 0)
```

In the Inspector, configure the `GPUParticles2D`:

```gdscript

# Setup code (can also be done in the editor):
func _ready() -> void:
    var mat := ParticleProcessMaterial.new()
    mat.spread               = 20.0
    mat.initial_velocity_min = 20.0
    mat.initial_velocity_max = 60.0
    var grad := Gradient.new()
    grad.set_color(0, Color(1, 1, 1, 1))
    grad.set_color(1, Color(0.6, 0.0, 1.0, 0))
    mat.color_ramp = grad
    trail.process_material = mat
    trail.amount  = 30
    trail.lifetime = 0.5
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · VFX autoload with pooling

Build a `VFX` autoload that *pools* particle instances instead of
 instantiating and freeing them each time. It should:

- Accept a `String` key mapping to a `PackedScene`
 (register effects with `register(key, scene)`).
- Maintain a pool of up to 8 recycled instances per key.
- On `play(key, pos)`: grab a pooled instance (or instantiate if pool is empty),
 position it, call `restart()`, and return it to the pool when finished.

::::solution[Solution]
```gdscript

# VFX.gd — Autoload
extends Node

var _scenes : Dictionary = {}   # key → PackedScene
var _pools  : Dictionary = {}   # key → Array[GPUParticles2D]

func register(key: String, scene: PackedScene) -> void:
    _scenes[key] = scene
    _pools[key]  = []

func play(key: String, pos: Vector2) -> void:
    if key not in _scenes:
        push_error("VFX: unknown key '%s'" % key)
        return

    var inst: GPUParticles2D
    var pool: Array = _pools[key]
    if pool.size() > 0:
        inst = pool.pop_back()
    else:
        inst = _scenes[key].instantiate() as GPUParticles2D
        get_tree().current_scene.add_child(inst)

    inst.global_position = pos
    inst.visible         = true
    inst.restart()

    # Return to pool after last particle dies
    if not inst.finished.is_connected(_return_to_pool.bind(key, inst)):
        inst.finished.connect(_return_to_pool.bind(key, inst))

func _return_to_pool(key: String, inst: GPUParticles2D) -> void:
    inst.visible = false
    var pool: Array = _pools[key]
    if pool.size() < 8:
        pool.append(inst)
    else:
        inst.queue_free()
```
::::
:::
