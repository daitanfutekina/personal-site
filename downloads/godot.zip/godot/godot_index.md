---
title: "Godot 4.6 — The Complete Reference"
crumb: "Self-study Textbook · Godot 4.6 · GDScript"
source: "markdown"
---

From First Scene to Shipped Game
13 parts · 71 of 75 chapters written
~175 hours of study

This is the comprehensive Godot textbook — a deep, accurate, and practical reference covering
 every major system in the engine. It assumes you already know how to program (variables, loops,
 functions, classes) but treats Godot itself from scratch. Every node, every tool, every workflow
 you'll touch in a typical game jam or hobby project is in here.

Parts I–II build your foundation. Part III goes deep on the 2D nodes and then takes a first
 pass over the systems every project needs; Part IV covers the game systems that sit on top of
 them — persistence, scene flow, pooling, state machines, procedural generation. Parts V–VIII
 handle UI and tooling, audio, input, persistence, and the GDShader / VFX pipeline. Parts IX–XI
 cover AI patterns, networking, performance, and shipping. Part XII is a game-jam survival
 toolkit. Part XIII contains the eight complete game walkthroughs — one Unity-migration build,
 three beginner, three intermediate, and one advanced capstone. 3D is not a part of its own:
 it arrives through Ch 17 (Camera3D), Ch 52 (spatial shaders), the Crowd Runner walkthrough and
 the node reference.

:::callout-key[Targeting Godot 4.6 (stable, May 2026)]
Chapters reflect Godot 4.6.x. Notable in this release: **Jolt Physics ships built
 into the engine** (opt-in per project — Godot Physics is still what a new project
 gets), **Inverse Kinematics has returned**, the Screen Space
 Reflections renderer was fully rewritten, and **LibGodot** lets you embed the
 engine in other apps. Godot 4.7 has since shipped, bringing HDR output;
 this book is written and checked against 4.6.
:::

:::callout-tip[How to use this book]
You don't have to read top-to-bottom. The recommended path: Part I → II → either III (2D)
 or IV (3D), then dip into V/VI/VII as your project demands. When you're in a jam, jump
 straight to Part XII for the survival kit and mechanic cookbook.
:::

41 / 76 — Chapters done

~43h — Study time logged

### The whole book at a glance

Part I — Foundations — Ch 1–13 · editor, nodes, GDScript, signals, first 2D systems

Part II — GDScript Deep Dive — Ch 8–12 · typing, resources, autoloads

Part III — 2D Nodes & Core Systems — Ch 13–23 · transforms, sprites, audio, input, camera, particles, shaders

Part IV — Game Systems — Ch 24–35 · saving, scene flow, pooling, FSMs, tweens, procgen

Part V — UI, Tooling & Capstones — Ch 36–42A · themes, AnimationTree, GDExtension, plugins, two capstones

Part VI — Audio — Ch 43–45 · streams, buses, music

Part VII — Input & Persistence — Ch 46–49 · input map, save systems & networking

Part VIII — Shaders & VFX — Ch 50–55 · GDShader, particles, VFX

Part IX — AI & Architecture — Ch 56–59 · FSMs, navigation, patterns

Part X — Performance & Networking — Ch 60–63 · profiling, threading, RPC

Part XI — Shipping — Ch 64–66 · export, polish, publish

Part XII — Game Jam Toolkit — Ch 67–69 · scoping, assets, cookbook

Part XIII — Walkthroughs — Ch 70–76 · 3 beginner · 3 intermediate · 1 advanced

## Part I
 Foundations
Editor, nodes, GDScript, signals and resources — plus first passes at 2D physics, TileMapLayer and Control nodes.

- ✓
Ch 1
[Welcome to Godot 4.6 — Install, Project Manager & Your First Scene](./godot_ch1_welcome.html)core
est. 60 min
- ✓
Ch 2
[Tour of the Godot Editor — Docks, Viewports & Workflow](./godot_ch2_editor.html)
est. 75 min
- ✓
Ch 3
[Nodes, Scenes & the Scene Tree — Godot's Core Architecture](./godot_ch3_nodes_scenes.html)core
est. 90 min
- ✓
Ch 4
[GDScript Crash Course — Syntax, Types & the Lifecycle Functions](./godot_ch4_gdscript.html)
est. 110 min
- ✓
Ch 5
[Signals & Inter-Node Communication — Godot's Event System](./godot_ch5_signals.html)core
est. 75 min
- ✓
Ch 6
[Resources, `.tres` / `.tscn` & the FileSystem Dock](./godot_ch6_resources.html)
est. 60 min
- ✓
Ch 7
[Project Settings, Render Backends & Configuration](./godot_ch7_project_settings.html)
est. 50 min
- ✓
Ch 8
[2D Physics — CharacterBody2D, RigidBody2D, StaticBody2D & Area2D](./godot_ch8_2d_physics.html)2D
est. 110 min
- ✓
Ch 9
[TileMapLayer — Building 2D Worlds with Tiles](./godot_ch9_tilemaplayer.html)2D
est. 90 min
- ✓
Ch 10
[Advanced GDScript — Static Typing, Lambdas & Coroutines](./godot_ch10_gdscript_advanced.html)
est. 80 min
- ✓
Ch 11
[OOP in GDScript — Classes, Inheritance & Design Patterns](./godot_ch11_oop_gdscript.html)
est. 85 min
- ✓
Ch 12
[Autoloads & Singletons — Global Systems in Godot 4.6](./godot_ch12_autoloads_singletons.html)
est. 70 min
- ✓
Ch 13
[UI & Control Nodes — Building Game Interfaces](./godot_ch13_ui_control_nodes.html)2D
est. 90 min

## Part II
 GDScript Deep Dive & Architecture
Static typing, custom resources, singletons, and clean code patterns.

- ✓
Ch 8
[Static Typing, Lambdas, Coroutines & `await`](./godot_p2ch8_static_typing.html)
est. 75 min
- ✓
Ch 9
[Object-Oriented GDScript — Classes, Inheritance & `class_name`](./godot_p2ch9_oop_gdscript.html)
est. 70 min
- ✓
Ch 10
[Custom Resources & Data-Driven Design (the ScriptableObject pattern)](./godot_p2ch10_custom_resources.html)
est. 75 min
- ✓
Ch 11
[Autoloads, Singletons & the Event Bus Patterncore](./godot_p2ch11_autoloads_event_bus.html)
est. 65 min
- ✓
Ch 12
[C# vs GDScript & an Intro to GDExtension (C++)](./godot_p2ch12_csharp_gdext.html)
est. 60 min

## Part III
 2D Nodes & Core Systems
Node2D and Sprite2D in depth, then a first pass over the systems every project needs: audio, input, cameras, particles, shaders, navigation, networking, export and debugging.

- ✓
Ch 13
[Node2D, the 2D Coordinate System & Transforms2D](./godot_p3ch13_node2d_transforms.html)
est. 70 min
- ✓
Ch 14
[Sprite2D, AnimatedSprite2D, Textures & Atlases2D](./godot_p3ch14_sprite2d_textures.html)
est. 75 min
- ✓
Ch 14A
[Animation — AnimationPlayer, Tween & AnimationTree](./godot_ch14a_animation.html)
est. 80 min
- ✓
Ch 15
[Audio — Players, Buses & Dynamic Music](./godot_ch15_audio.html)
est. 85 min
- ✓
Ch 16
[Input — InputMap, Events & Controllers](./godot_ch16_input.html)
est. 80 min
- ✓
Ch 17
[Camera — Camera2D, Camera3D & Viewports](./godot_ch17_camera.html)
est. 80 min
- ✓
Ch 18
[Particles — GPUParticles, CPUParticles & VFX](./godot_ch18_particles.html)
est. 75 min
- ✓
Ch 19
[Shaders — Godot Shading Language, 2D & 3D Effects](./godot_ch19_shaders.html)
est. 100 min
- ✓
Ch 20
[Navigation — Pathfinding & Avoidance](./godot_ch20_navigation.html)
est. 85 min
- ✓
Ch 21
[Networking — Multiplayer, RPCs & Synchronisation](./godot_ch21_networking.html)
est. 110 min
- ✓
Ch 22
[Export & Release — Templates, Platforms & CI/CD](./godot_ch22_export.html)
est. 90 min
- ✓
Ch 23
[Debugging & Profiling — Finding and Fixing Problems](./godot_ch23_debugging.html)
est. 75 min

## Part IV
 Game Systems
What turns a prototype into a game: persistence, scene transitions, object pools, state machines, tweens, procedural generation, inventory, localisation and remappable input.

- ✓
Ch 24
[Saving & Loading — Persistence Across Play Sessions](./godot_ch24_saving_loading.html)
est. 80 min
- ✓
Ch 25
[Scene Management — Transitions, Loading & Scene Trees](./godot_ch25_scene_management.html)
est. 75 min
- ✓
Ch 26
[Object Pools & Optimization — Smooth Framerates at Scale](./godot_ch26_pools_optimization.html)
est. 80 min
- ✓
Ch 27
[State Machines — Organised Behaviour for Players & AI](./godot_ch27_state_machines.html)
est. 85 min
- ✓
Ch 28
[Tweens & Timers — Time-Based Logic and Smooth Animation](./godot_ch28_tweens_timers.html)
est. 70 min
- ✓
Ch 29
[Procedural Generation — Noise, Dungeons & Loot Tables](godot_ch29_procedural_generation.html)
est. 95 min
- ✓
Ch 30
[Inventory & Items](godot_ch30_inventory_items.html)
est. 90 min
- ✓
Ch 31
[Audio System](godot_ch31_audio.html)
est. 80 min
- ✓
Ch 32
[Introduction to Shaders](godot_ch32_shaders.html)
est. 85 min
- ✓
Ch 33
[Multiplayer & Networking](godot_ch33_networking.html)
est. 95 min
- ✓
Ch 34
[Localisation & Accessibility](godot_ch34_localization.html)
est. 70 min
- ✓
Ch 35
[Input & Action Remapping](godot_ch35_input_remapping.html)
est. 70 min

## Part V
 UI, Tooling & First Capstones
Theming and styling Control nodes, AnimationTree blending, native code and editor plugins, then two full builds — a top-down RPG and a 2D platformer.

- ✓
Ch 36
[UI Themes & Styling](godot_ch36_ui_themes.html)
est. 75 min
- ✓
Ch 37
[AnimationTree & Blend States](godot_ch37_animation_trees.html)
est. 75 min
- ✓
Ch 38
[GDExtension & Native Code](godot_ch38_gdextension.html)
est. 90 min
- ✓
Ch 39
[Performance & Profiling](godot_ch39_performance.html)
est. 80 min
- ✓
Ch 40
[Editor Plugins & @tool Scripts](godot_ch40_plugin_tools.html)
est. 85 min
- ✓
Ch 41
[Export & Deployment](godot_ch41_export_deploy.html)
est. 75 min
- ✓
Ch 42
[Capstone — Top-Down RPG](godot_ch42_capstone_rpg.html)
est. 3–4 hours
- ✓
Ch 42A
[Capstone — 2D Platformer](godot_ch42a_platformer.html)2D
est. 3–4 hours

## Part VI
 Audio
Streams, buses, effects, and music for both 2D and 3D games.

- ✓
Ch 43
[AudioStreamPlayer, 2D & 3D — Spatial Audio Without Confusion](./godot_ch43_audio_players.html)
est. 70 min
- ✓
Ch 44
[Audio Buses, Effects (Reverb, EQ, Compressor) & Mixing](./godot_ch44_audio_buses.html)
est. 65 min
- ✓
Ch 45
[Music, Looping, Crossfades & Adaptive / Procedural Audio](./godot_ch45_music_adaptive.html)
est. 75 min

## Part VII
 Input & Persistence
Input Map, devices, and save / load systems that survive shipping.

- ✓
Ch 46
[Input Map, Actions, Gamepad, Touch & Rebinding UI](./godot_ch46_input_map.html)
est. 80 min
- ✓
Ch 47
[FileAccess, JSON, ConfigFile & ResourceSaver Compared](./godot_ch47_file_access.html)
est. 70 min
- ✓
Ch 48
[Save Slots, Player Profiles & Versioned Save Data](./godot_ch48_save_slots.html)
est. 75 min
- ✓
Ch 49
[HTTPClient, HTTPRequest & Calling Web APIs](./godot_ch49_http_client.html)
est. 65 min

## Part VIII
 Shaders & VFX
GDShader language, 2D and 3D shaders, particles, and a VFX cookbook.

- ✓
Ch 50
[GDShader Fundamentals — Syntax, Types, Built-ins & the Pipeline](./godot_ch50_gdshader_fundamentals.html)
est. 85 min
- ✓
Ch 51
[CanvasItem (2D) Shaders — `fragment`, `vertex` & `light` Passes2D](./godot_ch51_canvas_shaders.html)
est. 90 min
- ✓
Ch 52
[Spatial (3D) Shaders — PBR Inputs, Custom Lighting & Screen UV3D](./godot_ch52_spatial_shaders.html)
est. 100 min
- ✓
Ch 53
[VisualShader — Node-Graph Shaders Without Writing GLSL](./godot_ch53_visual_shader.html)
est. 65 min
- ✓
Ch 54
[Particle Process Shaders — GPU Particle Logic on the Card](./godot_ch54_particle_shaders.html)
est. 70 min
- ✓
Ch 55
[VFX Cookbook — Dissolve, Outline, Water, Fire, Hit-Flash & Glow](./godot_ch55_vfx_cookbook.html)
est. 110 min

## Part IX
 AI & Architecture Patterns
State machines, navigation, enemy AI, and clean scene composition.

- ✓
Ch 56
[Finite State Machines — Code-Based & AnimationTree Hybridsadvanced](./godot_ch56_state_machines.html)
est. 90 min
- ✓
Ch 57
[NavigationAgent2D/3D, NavMesh Baking & Pathfinding](./godot_ch57_navigation.html)
est. 85 min
- ✓
Ch 58
[Behavior Trees, Enemy AI Patterns & Perception (Vision/Hearing)](./godot_ch58_behavior_trees.html)
est. 95 min
- ✓
Ch 59
[Scene Composition, Inheritance vs Instancing & Code Reuse Patterns](./godot_ch59_scene_composition.html)
est. 80 min

## Part X
 Performance & Networking
Profiling, optimization, threading, and multiplayer with RPCs.

- ✓
Ch 60
[Profiling, Debugging & the Remote Inspector](./godot_ch60_profiling.html)
est. 75 min
- ✓
Ch 61
[Optimization — Draw Calls, LOD, Occlusion Culling & Batching](./godot_ch61_optimization.html)
est. 90 min
- ✓
Ch 62
[Threading, WorkerThreadPool & Async Resource Loading](./godot_ch62_threading.html)
est. 80 min
- ✓
Ch 63
[MultiplayerAPI, RPCs, ENet & WebSocket Networking](./godot_ch63_multiplayer.html)
est. 100 min

## Part XI
 Shipping
Exporting, polishing, and publishing to itch.io and Steam.

- ✓
Ch 64
[Export Templates & Targets — Windows, macOS, Linux, Web, Mobile](./godot_ch64_export.html)
est. 90 min
- ✓
Ch 65
[Polish, Tweens, Timers & Game Feel (Juice)](./godot_ch65_polish.html)
est. 80 min
- ✓
Ch 66
[Itch.io, Steam & the Publishing Workflow](./godot_ch66_publishing.html)
est. 70 min

## Part XII
 Game Jam Toolkit
Scoping, asset pipelines, and a cookbook of common mechanics.

- ✓
Ch 67
[Scoping, Time Management & the 48-Hour Jam Survival Guide](./godot_ch67_gamejam.html)
est. 60 min
- ✓
Ch 68
[Free Asset Pipeline — Sprites, Models, SFX, Music & Fonts](./godot_ch68_assets.html)
est. 55 min
- ✓
Ch 69
[Mechanic Cookbook — Jump, Dash, Dialogue, Projectiles, Pickups & More](./godot_ch69_cookbook.html)
est. 140 min

## Part XIII
 Complete Game Walkthroughs
Seven full end-to-end builds, three of them written. Each is a complete project that cross-references the reference chapters in Parts I–XII.

#### ● Tier 1 — Beginner (full length, learning the engine end-to-end)

- ✓ Ch 70 [Earclacks — Weapon Ball: Design Sheet (GDD/TDD)beginner2D](./godot_ch70_design_sheet.html) reference
- ✓ Ch 70A [Earclacks — Scene Setup & Physics Arenabeginner2D](./godot_ch70a_scene_setup.html) 45–60 min
- ✓ Ch 70B [Earclacks — Ball & RigidBody2D Physicsbeginner2D](./godot_ch70b_ball_movement.html) ~75 min
- ✓ Ch 70C [Earclacks — Weapon System, Spin & Parrybeginner2D](./godot_ch70c_weapon_system.html) ~90 min
- ✓ Ch 70D [Earclacks — Health Component & Death Signalsbeginner2D](./godot_ch70d_health.html) ~45 min
- ✓ Ch 70E [Earclacks — GameManager, Match Flow & HUDbeginner2D](./godot_ch70e_gamemanager.html) ~60 min
- ✓ Ch 70F [Earclacks — Ranged Weapons, Projectiles & Abilitiesbeginner2D](./godot_ch70f_ranged_weapons.html) ~90 min
- ✓ Ch 70G [Earclacks — Weapon Roster & Balancingbeginner2D](./godot_ch70g_weapons.html) ~45 min
- ✓ Ch 70H [Earclacks — Polish, VFX & Export for Shortsbeginner2D](./godot_ch70h_polish.html) ~45 min
- ✓ Ch 70I [Earclacks — Optional: Ball AI & Steeringbeginner2D](./godot_ch70i_ball_ai.html) ~40 min
- ✓ Ch 71 [VS Clone — Design Sheet & Architecture (GDD/TDD)beginner2D](./godot_ch71_design_sheet.html) reference
- ✓ Ch 71A [VS Clone — Scene Setup, Infinite World & Camerabeginner2D](./godot_ch71a_scene_setup.html) ~45 min
- ✓ Ch 71B [VS Clone — Player Character, Movement & Statsbeginner2D](./godot_ch71b_player.html) ~60 min
- ✓ Ch 71C [VS Clone — Enemy Types, Spawning & NavigationAgent2Dbeginner2D](./godot_ch71c_enemies.html) ~75 min
- ✓ Ch 71D [VS Clone — Weapon System, Auto-Attack & Projectilesbeginner2D](./godot_ch71d_weapons.html) ~90 min
- ✓ Ch 71E [VS Clone — XP Gems, Levelling & Upgrade Card UIbeginner2D](./godot_ch71e_xp_levelling.html) ~75 min
- ✓ Ch 71F [VS Clone — GameManager, Wave Timer & Run Progressionbeginner2D](./godot_ch71f_gamemanager.html) ~60 min
- ✓ Ch 71G [VS Clone — VFX, Screen Shake, Audio & Polishbeginner2D](./godot_ch71g_polish.html) ~60 min
- ✓ Ch 71H [VS Clone — Object Pooling, Performance & Exportbeginner2D](./godot_ch71h_export.html) ~45 min
- ✓ Ch 72 [Crowd Runner Mobile — Design Sheet & Architecture (GDD/TDD)beginner3D](./godot_ch72_design_sheet.html) reference
- ✓ Ch 72A [Crowd Runner — Project Setup, Mobile Renderer & Portrait Configbeginner3D](./godot_ch72a_project_setup.html) ~40 min
- ✓ Ch 72B [Crowd Runner — Track, Recycling Ground & Chase Camerabeginner3D](./godot_ch72b_track_camera.html) ~45 min
- ✓ Ch 72C [Crowd Runner — Leader CharacterBody3D & Auto-Forward Motionbeginner3D](./godot_ch72c_runner_motion.html) ~40 min
- ✓ Ch 72D [Crowd Runner — Swipe Input, LaneController & Tween Steeringbeginner3D](./godot_ch72d_swipe_lanes.html) ~45 min
- ✓ Ch 72E [Crowd Runner — The Crowd with MultiMeshInstance3Dbeginner3D](./godot_ch72e_crowd_multimesh.html) ~75 min
- ✓ Ch 72F [Crowd Runner — Gates, Obstacles & the Modifier Systembeginner3D](./godot_ch72f_gates_obstacles.html) ~75 min
- ✓ Ch 72G [Crowd Runner — LevelSpawner, Portrait HUD & Menusbeginner3D](./godot_ch72g_spawner_hud.html) ~75 min
- ✓ Ch 72H [Crowd Runner — End Battle, Polish, ConfigFile Save & Android Exportbeginner3D](./godot_ch72h_end_polish_export.html) ~90 min

#### ● Tier 2 — Intermediate (full length, advanced systems & deeper architecture)

- ☐
Ch 73
[Balatro Clone — Card Roguelike with Joker Effects & Run Economyintermediate2D](./godot_ch73_balatro.html)
est. 10–14 h
- ☐
Ch 74
[Music Visualizer & Teto Voicebank Game — FFT, Spectrum & Rhythmintermediateaudio-DSP](./godot_ch74_music_visualizer.html)
est. 12–16 h
- ☐
Ch 75
[Algorithmic City Builder — Procedural Growth, Pathfinding & Sim Loopsintermediate3D-opt](./godot_ch75_city_builder.html)
est. 14–18 h

#### ● Tier 3 — Advanced Capstone

- ☐
Ch 76
[Roguelike Pool Game — Physics, Run Structure & Deck-Buildingcapstone3D / Jolt](./godot_ch76_pool_roguelike.html)
est. 18–25 h

:::callout-tip[Ch 76 cross-project note]
The roguelike pool game has its **design doc in a separate project folder**. All chapters in Part XIII reference it as the advanced capstone example.
:::

## Appendix
 Node Reference
91 node-ref cards covering every major Godot 4 scene-tree node — purpose, key properties, and when-to-use guidance.

- ✓
App A
[Complete Node Reference — All Godot 4 Nodes Explained (91 cards, 25 categories)](./godot_node_reference.html)
reference

## Appendix
 Reference
Quick-look cards for every major Godot 4 node type.

- ✓
App B
[Godot 4 Node Reference — 54 Node Cards](./godot_appendix_nodes.html)
est. 30 min reference

## Appendix
 The Free Shelf
Free tutorials, sites, jams and communities worth your time — and how to tell when one is written for an engine version you are not running.

- ✓
App C
[The Free Shelf — Free Godot Tutorials, Sites and Jams](./godot_appendix_tutorials.html)
reference
