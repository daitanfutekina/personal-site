---
title: "Earclacks — Health Component & Death Signals"
crumb: "Earclacks Weapon Ball — Chapter 70D"
meta:
  - "Est. study time: ~45 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview & Prerequisites

:::callout-key[KEY CONCEPT]
HealthComponent.gd

— a plain

Node

that any entity can carry. Signals:

hp\_changed(new\_hp, max\_hp)

and

died

.

Ball.gd

updated:

take\_damage()

calls `HealthComponent.apply_damage()`,

on\_health\_depleted()

fires on

died

signal. After this chapter a ball will actually be removed from the arena when its HP reaches 0.
:::

## 1. Why a HealthComponent Node?

:::callout-intuition[INTUITION]
You could put HP tracking directly in Ball.gd. But what if you later add destructible walls? A boss with multiple HP bars? Turrets? All of these need health logic. If HP is inside Ball.gd you'd copy-paste the same hp/max\_hp/take\_damage code into every entity type. A

HealthComponent

is a self-contained node you drag onto any entity that needs HP — the entity's own script only connects signals. This is the

composition over inheritance

pattern in practice.
:::

Concretely: Ball.gd calls `health_comp.apply_damage(amount)` and listens for `health_comp.died`. Ball.gd does not contain a single line of HP arithmetic — all of that lives in `HealthComponent.gd`.

## 2. HealthComponent.gd

Create `res://scripts/HealthComponent.gd` and attach it to the `HealthComponent` node inside `Ball.tscn`:

```gdscript
extends Node
class_name HealthComponent

# ─── Exports ─────────────────────────────────────────────────────
@export var max_hp: float = 100.0

# ─── State ───────────────────────────────────────────────────────
var current_hp: float = max_hp
var is_dead: bool = false

# ─── Signals ─────────────────────────────────────────────────────
signal hp_changed(new_hp: float, max_hp: float)
signal died

# ─────────────────────────────────────────────────────────────────
func _ready() -> void:
    current_hp = max_hp

func apply_damage(amount: float) -> void:
    if is_dead:
        return
    current_hp = maxf(0.0, current_hp - amount)
    hp_changed.emit(current_hp, max_hp)
    if current_hp <= 0.0:
        is_dead = true
        died.emit()

func heal(amount: float) -> void:
    if is_dead:
        return
    current_hp = minf(max_hp, current_hp + amount)
    hp_changed.emit(current_hp, max_hp)

func reset() -> void:
    is_dead = false
    current_hp = max_hp
    hp_changed.emit(current_hp, max_hp)

func get_hp_fraction() -> float:
    return current_hp / max_hp
```

### Walkthrough

#### is\_dead guard in apply\_damage

Without this guard, if two weapons hit the same ball in the same frame, `died` would emit twice — and `Ball.on_health_depleted()` would call `queue_free()` twice. The second call on a freed node causes an error. The `is_dead` flag makes death idempotent — safe to trigger multiple times.

#### hp\_changed signal carries both values

The HUD (Ch 70E) needs both `new_hp` and `max_hp` to draw a percentage health bar. Passing both in the signal means the HUD doesn't need to keep its own copy of max\_hp — it reads it directly from the signal every time damage occurs.

#### get\_hp\_fraction()

A convenience method for any system that needs a 0.0–1.0 ratio (colour interpolation for a health bar, AI threat assessment, etc.).

## 3. Wiring HealthComponent into Ball.gd

Update `Ball.gd` with these changes (shown in context of the existing functions):

```gdscript
@onready var health_comp: HealthComponent = $HealthComponent

func _ready() -> void:
    add_to_group("balls")
    ball_sprite.color = team_color
    _attach_weapon()
    # Connect HealthComponent's died signal to our death handler
    health_comp.died.connect(on_health_depleted)

func take_damage(amount: float) -> void:
    health_comp.apply_damage(amount)

func on_health_depleted() -> void:
    if not is_alive:
        return
    is_alive = false
    died.emit(ball_name)
    # Optional: play death VFX before freeing
    _play_death_effect()
    queue_free()
```

The key change: `take_damage()` now just calls `health_comp.apply_damage(amount)`. All HP arithmetic has moved out of Ball.gd entirely.

:::callout-connect[CONNECTION]
1. Sword's Hitbox Area2D → `body_entered`
2. WeaponBase → `_try_hit(target)` → `target.take_damage(15)`
3. Ball.take\_damage → `health_comp.apply_damage(15)`
4. HealthComponent → `hp_changed.emit(85, 100)` → (HUD, Ch 70E)
5. HealthComponent (if HP=0) → `died.emit()`
6. Ball.on\_health\_depleted → `died.emit("Red")`
7. Arena.gd → `GameManager.ball_died("Red")`
8. GameManager → `end_match("Blue")` → `match_ended.emit("Blue")`
:::

## 4. Simple Death Effect

A death with no visual feedback looks like a bug. Add a minimal flash before the ball disappears:

```gdscript
# In Ball.gd
func _play_death_effect() -> void:
    # Quick colour flash to white before disappearing
    var tween = create_tween()
    tween.tween_property(ball_sprite, "color", Color.WHITE, 0.08)
    tween.tween_interval(0.05)
    # queue_free is already called after this function returns,
    # but the tween runs for ~0.13s. To prevent the node being freed
    # before the tween finishes, delay the free:
    set_deferred("queue_free", true)   # won't work — use await instead:

func on_health_depleted() -> void:
    if not is_alive:
        return
    is_alive = false
    died.emit(ball_name)
    _play_death_vfx_and_free()

func _play_death_vfx_and_free() -> void:
    # Disable collision so the dead ball doesn't block others
    $CollisionShape2D.disabled = true
    linear_velocity = Vector2.ZERO
    # Flash white then free
    var tween = create_tween()
    tween.tween_property(ball_sprite, "color", Color.WHITE, 0.1)
    tween.tween_interval(0.08)
    await tween.finished
    queue_free()
```

:::callout-tip[TIP]
await

suspends the current function until the signal fires, without blocking anything else. The ball stays in the scene for 0.18 seconds for the VFX, then gets freed. The

is\_alive = false

and disabling the collision shape prevent any further damage or physics interaction during that window.
:::

## 5. Verification

1. Run the project. Both balls should spawn and their weapons should rotate.
2. When a sword connects with the enemy ball, watch the Output panel. No prints yet — but after ~7 sword hits (100 HP / 15 damage ≈ 7 hits) the struck ball should flash white and disappear.
3. After one ball dies, the Output panel should show:

`[GameManager] → GAME_OVER`
4. The remaining ball should continue bouncing (no crash from the freed ball being referenced).

:::callout-pitfall[PITFALL]
If the ball disappears on the first frame, the hit cooldown isn't working — the weapon is hitting many times per physics step. Check that

hit\_cooldown = 0.5

is set in WeaponBase.gd and that the

\_hit\_timers

dictionary is being populated.
:::

## Chapter Summary

:::summary
### Signal Chain Complete

With Ch 70D done, the full pipeline from weapon contact to match-over is operational. The remaining chapters (70E–70H) add: HUD, AI, more weapons, and polish — but the core game loop is *complete*.

| Component | Responsibility |
| --- | --- |
| HealthComponent.gd | HP tracking, hp\_changed + died signals, is\_dead guard |
| Ball.gd (updated) | forwards take\_damage → HealthComponent, plays death VFX |
:::

## Practice Problems

**1.** easy — What does the `is_dead` guard in `apply_damage()` prevent?

:::solution[Solution]
It prevents `died` from being emitted more than once. Without it, two weapons hitting the same ball in the same physics frame would both reduce HP to ≤0, and both would emit `died`. `Ball.on_health_depleted()` would call `queue_free()` twice — the second call on an already-freed node causes an error. The guard makes death idempotent.
:::

**2.** standard — The `hp_changed` signal passes `max_hp` as a second argument. Why not just have the HUD call `health_comp.max_hp` directly when it receives `hp_changed`?

:::solution[Solution]
Two reasons: (1) **Decoupling** — the HUD would need a direct reference to the HealthComponent to call its property. Passing max\_hp in the signal means the HUD only needs to listen to the signal — it doesn't need to hold a reference. (2) **Future flexibility** — if max\_hp ever changes mid-match (e.g., a power-up increases max HP), the signal will carry the correct new value. If the HUD cached max\_hp at scene-load it would be stale.
:::

**3.** standard — Rewrite `_play_death_vfx_and_free()` without using `await` — use a `Timer` node instead. Which approach is better for this use case?

:::solution[Solution]
```gdscript
func _play_death_vfx_and_free() -> void:
    $CollisionShape2D.disabled = true
    linear_velocity = Vector2.ZERO
    var tween = create_tween()
    tween.tween_property(ball_sprite, "color", Color.WHITE, 0.1)
    # Use a one-shot Timer instead of await
    var t = Timer.new()
    add_child(t)
    t.wait_time = 0.18
    t.one_shot = true
    t.timeout.connect(queue_free)
    t.start()
```

The `await` approach is better here because: (1) it requires fewer nodes (no Timer), (2) the intent is clearer — "wait for the tween to finish, then free" reads naturally, (3) there's no risk of the Timer outliving its parent node (which would cause an error if the parent is freed while the Timer is still running). Use `await` for simple sequential waits in disposable nodes; use Timer nodes when the wait needs to be cancellable or externally controlled.
:::

**4.** challenge — Design a `ShieldComponent` that absorbs up to N damage before deactivating. It should sit between the weapon hit and HealthComponent — when a ball has a shield, `take_damage()` should reduce shield first, then overflow to HP. Show the updated `Ball.take_damage()`.

:::solution[Solution]
```gdscript
# ShieldComponent.gd
extends Node
class_name ShieldComponent

@export var shield_hp: float = 50.0
var current_shield: float = 0.0   # starts inactive

signal shield_changed(current: float, max: float)
signal shield_broken

func activate() -> void:
    current_shield = shield_hp

func absorb(amount: float) -> float:
    # Returns leftover damage after shield absorbs what it can
    if current_shield <= 0.0:
        return amount
    var absorbed = minf(current_shield, amount)
    current_shield -= absorbed
    shield_changed.emit(current_shield, shield_hp)
    if current_shield <= 0.0:
        shield_broken.emit()
    return amount - absorbed   # leftover to HP

# In Ball.gd:
@onready var shield_comp: ShieldComponent = $ShieldComponent  # optional node

func take_damage(amount: float) -> void:
    var remaining = amount
    if shield_comp and is_instance_valid(shield_comp):
        remaining = shield_comp.absorb(amount)
    if remaining > 0.0:
        health_comp.apply_damage(remaining)
```
:::
