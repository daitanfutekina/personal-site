---
title: "Save Slots, Player Profiles & Versioned Save Data"
source: "godot_ch48_save_slots.html"
---

Part VII · Chapter 48

# Save Slots, Player Profiles & Versioned Save Data

Estimated study time: 70 min · Godot 4.6 · GDScript

## Overview

Ch 47 taught the four I/O primitives. This chapter assembles them into a complete, production-grade save system with named slots, metadata, forward-compatible versioning, corruption-safe atomic writes, optional encryption, and autosave. Every pattern here has been used in shipping games.

### Prerequisites

- Ch 47 — FileAccess, JSON, ConfigFile, ResourceSaver
- Ch 21 — Autoloads / singletons
- Ch 34 — Timer nodes (for autosave)

## Slot Architecture

A save slot is a named directory inside `user://saves/`. Each slot contains two files: the actual game data and a lightweight metadata file that the slot-selection UI can read without loading the full save.

### File Layout

The split into `meta.json` and `data.json` is the one structural
decision in this chapter, and it is made for a screen the player sees constantly: the
slot-select menu. That screen needs a name, a timestamp and a playtime for every slot, and
nothing else. If those live inside the full save, drawing the menu means parsing every
save file in full — which on a large game is a visible pause before the player has
chosen anything.

Keeping the summary in its own small file means the menu reads a few hundred bytes per
slot and the megabyte only gets touched when a slot is actually loaded. The cost is that
two files must agree, which is what the atomic write pattern later in the chapter is
protecting.

```gdscript
user://
└── saves/
    ├── slot_1/
    │   ├── meta.json      # lightweight: name, timestamp, playtime, level
    │   └── data.json      # full game state
    ├── slot_2/
    │   ├── meta.json
    │   └── data.json
    └── autosave/
        ├── meta.json
        └── data.json
```

Separating metadata from data is critical for performance. The slot-select screen loads all `meta.json` files immediately — each is tiny (under 1 KB). The full `data.json` (potentially hundreds of KB) is only loaded when the player actually confirms a slot.

### Slot Metadata Structure

```gdscript
## What goes in meta.json:
{
    "slot_name":    "Slot 1",
    "player_name":  "Alice",
    "level":        "dungeon_floor_3",
    "playtime_sec": 7342,
    "save_version": 3,
    "timestamp":    "2026-05-28T14:32:01"
}
```

The `save_version` field is the key to forward-compatible saves — discussed in the Versioning section. `playtime_sec` lets you display "12 h 17 m" without parsing the full save data.

## SaveManager Autoload

Register this as an autoload at **Project → Project Settings → Autoloads**, name it `SaveManager`. It provides the entire save/load API to the rest of the game.

### Listing Available Slots

A directory per slot, rather than `slot1.json`, `slot2.json`, is
what makes listing them a directory read instead of a naming convention. It also leaves
room for per-slot extras that are not JSON at all — a screenshot thumbnail is the usual
one — without changing anything here.

Note that `list_slots` returns an empty array rather than failing when the
directory does not exist. First run is not an error condition: a new player has no saves,
and the menu should show empty slots rather than a message about a missing folder.

```gdscript
# save_manager.gd
extends Node

const SAVES_DIR    := "user://saves/"
const CURRENT_VERSION := 3

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(
        ProjectSettings.globalize_path(SAVES_DIR)
    )

## Returns an Array of slot names (directory names under saves/).
func list_slots() -> Array[String]:
    var slots: Array[String] = []
    var dir := DirAccess.open(SAVES_DIR)
    if dir == null:
        return slots
    dir.list_dir_begin()
    var name := dir.get_next()
    while name != "":
        if dir.current_is_dir() and not name.begins_with("."):
            slots.append(name)
        name = dir.get_next()
    slots.sort()
    return slots

## Load just the metadata for a slot (fast — for the UI).
func load_meta(slot: String) -> Dictionary:
    var path := SAVES_DIR + slot + "/meta.json"
    if not FileAccess.file_exists(path):
        return {}
    var text := FileAccess.get_file_as_string(path)
    var data  = JSON.parse_string(text)
    return data if data is Dictionary else {}

## Load all slots' metadata at once (for the slot-select screen).
func load_all_meta() -> Dictionary:
    var result := {}
    for slot in list_slots():
        result[slot] = load_meta(slot)
    return result
```

### Saving and Loading Full Game Data

Returning an `Error` rather than a boolean, and checking the metadata write
before attempting the data write, is what keeps a failure from being half a save. If the
disk is full or the path is not writable, the caller finds out which step failed and the
slot is left as it was.

:::callout-pitfall[Pitfall — JSON has one number type, and it is float]
This catches everyone once. Save `{"hp": 42}`, load it back, and the value
 is `42.0`: a `float`, not an `int`. JSON does not
 distinguish them, so `JSON.parse_string` hands every number back as a float.

Most of the time nothing breaks, which is what makes it dangerous.
 `hp == 42` is still true, because GDScript compares numerically across the two
 types. But three things do break:

- `match` compares type as well as value, so a
 `match version: 3:` arm *silently falls through* on a value
 loaded from JSON. Measured: it matches an annotated `int` and does not
 match the float that came out of the file.
- `str()` renders it as `"42.0"`, so a saved integer displayed
 straight into a label shows a decimal point.
- Integers beyond 2^53^ lose precision. Round-tripping
 `9007199254740993` returns `9007199254740992` — a
 silently different number, which matters if you store 64-bit ids.

This is why the migration code reads
 `var version: int = data.get("save_version", 1)` with the type written out.
 That annotation is not decoration; it is the conversion, and dropping it is what turns
 a version check into one that never fires.
:::

```gdscript
## Save game data to a named slot.
## data: the full game state dictionary
## meta_extra: any extra fields to merge into the metadata (e.g. playtime, level)
func save(slot: String, data: Dictionary, meta_extra: Dictionary = {}) -> Error:
    var slot_dir := SAVES_DIR + slot + "/"
    DirAccess.make_dir_recursive_absolute(
        ProjectSettings.globalize_path(slot_dir)
    )

    # Build metadata
    var meta := {
        "slot_name":    slot,
        "save_version": CURRENT_VERSION,
        "timestamp":    Time.get_datetime_string_from_system(),
    }
    meta.merge(meta_extra, true)   # meta_extra overrides defaults

    # Write both files atomically (see §Atomic Writes for the full pattern)
    var err_meta := _write_json_atomic(slot_dir + "meta.json", meta)
    if err_meta != OK:
        return err_meta
    var err_data := _write_json_atomic(slot_dir + "data.json", data)
    return err_data

## Load full game data from a slot.
## Returns {} on failure; check the 'save_version' key before using.
func load_data(slot: String) -> Dictionary:
    var path := SAVES_DIR + slot + "/data.json"
    if not FileAccess.file_exists(path):
        return {}
    var text := FileAccess.get_file_as_string(path)
    var data  = JSON.parse_string(text)
    if not data is Dictionary:
        push_error("Corrupted save in slot: " + slot)
        return {}
    return _migrate(data)

## Convenience: save and immediately switch to this slot.
signal slot_saved(slot: String)
signal slot_loaded(slot: String, data: Dictionary)
var active_slot: String = ""

func save_and_notify(slot: String, data: Dictionary, meta: Dictionary = {}) -> void:
    var err := save(slot, data, meta)
    if err == OK:
        active_slot = slot
        slot_saved.emit(slot)
```

### Deleting a Slot

```gdscript
func delete_slot(slot: String) -> void:
    var slot_dir := ProjectSettings.globalize_path(SAVES_DIR + slot + "/")
    var dir := DirAccess.open(SAVES_DIR + slot + "/")
    if dir == null:
        return
    # Delete all files inside the slot directory first
    dir.list_dir_begin()
    var name := dir.get_next()
    while name != "":
        if not dir.current_is_dir():
            DirAccess.remove_absolute(slot_dir + name)
        name = dir.get_next()
    # Then remove the now-empty directory
    DirAccess.remove_absolute(slot_dir.trim_suffix("/"))
```

## Versioning & Migration

Save games outlive game updates. A player might install a patch six months after starting a game — their save file was written by version 1 of your code and needs to run under version 3. The solution is a **migration chain**: a function per version bump that upgrades the data one step at a time.

### The Migration Pattern

The rule that makes migration tractable is that each step only has to know how to get
from one version to the next. `_migrate_v1_to_v2` never considers version 3;
it is handed a v1 save and produces a v2 one, and the chain runs them in order. Adding
version 5 later means writing one function and one `if`, not revisiting four
existing ones.

The sequence of `if version < n` tests rather than `elif` is
deliberate and easy to get wrong: a v1 save must fall through *every* step to reach
the current format, so the conditions have to be independent. Each step also stamps the new
version number as it finishes, which is what lets the next condition read the value the
previous step just wrote.

:::callout-tip[Tip]
Keep one real save file from every version you have ever shipped, and load all of them in
  a test. Migration code is by nature the code you cannot exercise by playing the current
  build, and the first time it runs for real is on a player's only save.
:::

```gdscript
## Called by load_data() before returning data to the caller.
## Upgrades data from any old version to CURRENT_VERSION.
func _migrate(data: Dictionary) -> Dictionary:
    var version: int = data.get("save_version", 1)

    # Run each migration in sequence until we reach current
    if version < 2:
        data = _migrate_v1_to_v2(data)
    if version < 3:
        data = _migrate_v2_to_v3(data)
    # Add future migrations here:
    # if version < 4: data = _migrate_v3_to_v4(data)

    data["save_version"] = CURRENT_VERSION
    return data

## v1 → v2: we renamed 'hp' to 'health' and added 'stamina'.
func _migrate_v1_to_v2(data: Dictionary) -> Dictionary:
    if "hp" in data:
        data["health"] = data["hp"]
        data.erase("hp")
    if not "stamina" in data:
        data["stamina"] = 100
    data["save_version"] = 2
    return data

## v2 → v3: we added an 'inventory' array (was flat keys before).
func _migrate_v2_to_v3(data: Dictionary) -> Dictionary:
    if not "inventory" in data:
        # Gather old flat inventory keys into an array
        var items: Array = []
        for key in ["item_0", "item_1", "item_2"]:
            if key in data:
                items.append(data[key])
                data.erase(key)
        data["inventory"] = items
    data["save_version"] = 3
    return data
```

:::callout-key[Migration design rules]
- Each migration function should be *pure*: it reads the input dictionary and returns a new/modified one. No side effects.
- Write the migration at the same time you change the data format, before shipping the patch. Don't do it retroactively.
- Never delete a migration. Old saves may skip multiple versions; the chain must stay complete.
- Test by writing a save with the old version number in your tests and verifying the migrated output.
:::

## Atomic Writes — Preventing Corruption

What happens if the game crashes mid-write? Without protection, you get a partially-written file that neither the old nor new data — unrecoverable corruption. The fix is an **atomic write**: write to a temporary file, then rename it over the real file. A rename on the same filesystem is atomic — it either completes or doesn't, never leaving a half-written state.

```gdscript
## Write JSON to a path atomically using a temp file + rename.
func _write_json_atomic(path: String, data: Dictionary) -> Error:
    var tmp_path := path + ".tmp"
    var abs_path := ProjectSettings.globalize_path(path)
    var abs_tmp  := ProjectSettings.globalize_path(tmp_path)

    # Write to temp file first
    var file := FileAccess.open(tmp_path, FileAccess.WRITE)
    if file == null:
        return FileAccess.get_open_error()
    file.store_string(JSON.stringify(data, "\t"))
    file = null   # flush and close by dropping reference

    # Atomically replace the real file with the temp file
    var err := DirAccess.rename_absolute(abs_tmp, abs_path)
    if err != OK:
        DirAccess.remove_absolute(abs_tmp)   # cleanup on failure
    return err
```

:::callout-tip[Tip — keep a backup too]
For a belt-and-suspenders approach, before the rename: copy the existing `data.json` to `data.json.bak`. If the player reports a corrupt save, you can fall back to the backup. Implement a `load_data_with_backup()` that tries the main file first, then the backup.
:::

## Encryption

Godot supports encrypted file I/O natively. This prevents casual save editing but is not a server-side anti-cheat — a determined player can extract the key from the binary. Use it for single-player games where you want to discourage tampering, not prevent it.

```gdscript
const SAVE_KEY := "my-secret-passphrase-32-chars-ok"

func save_encrypted(slot: String, data: Dictionary) -> Error:
    var path := SAVES_DIR + slot + "/data.sav"
    var file := FileAccess.open_encrypted_with_pass(path, FileAccess.WRITE, SAVE_KEY)
    if file == null:
        return FileAccess.get_open_error()
    file.store_var(data)
    return OK

func load_encrypted(slot: String) -> Dictionary:
    var path := SAVES_DIR + slot + "/data.sav"
    if not FileAccess.file_exists(path):
        return {}
    var file := FileAccess.open_encrypted_with_pass(path, FileAccess.READ, SAVE_KEY)
    if file == null:
        return {}
    var data = file.get_var()
    return data if data is Dictionary else {}
```

:::callout-warning[Warning — key security]
The passphrase is embedded in your game binary. On desktop, it can be extracted with a hex editor or decompiler. Encryption here is obfuscation, not security. For truly sensitive data (like server auth tokens), use OS keychain APIs via a GDExtension, or never store them locally at all.
:::

## Autosave

Autosave writes to a reserved `"autosave"` slot on a timer or at key game events (entering a new area, after defeating a boss). Players should always be able to load the autosave slot from the slot-select screen.

```gdscript
# In your game world scene or a dedicated AutosaveManager node:
extends Node

const AUTOSAVE_INTERVAL := 120.0   # seconds
var _timer: float = 0.0

func _process(delta: float) -> void:
    _timer += delta
    if _timer >= AUTOSAVE_INTERVAL:
        _timer = 0.0
        _do_autosave()

func _do_autosave() -> void:
    var data := _collect_game_state()   # your game-specific function
    var meta := {
        "player_name": PlayerData.name,
        "level":       get_tree().current_scene.name,
        "playtime_sec": PlayerData.playtime_sec,
        "slot_name":   "Autosave",
    }
    SaveManager.save("autosave", data, meta)
    print("Autosaved at ", Time.get_datetime_string_from_system())

## Trigger immediately on crossing a checkpoint:
func on_checkpoint_reached() -> void:
    _timer = 0.0
    _do_autosave()
```

:::callout-pitfall[Pitfall — autosaving during cutscenes or loading]
Autosave should be disabled during scene transitions, cutscenes, and loading screens. The game state may be partially torn down during these windows, and writing it will produce a broken save. Add a flag `SaveManager.autosave_enabled` that you set `false` at the start of any transition and `true` once the new scene is ready.
:::

### Putting It All Together — Full Usage Example

```gdscript
## In a "Load Game" menu:
func _populate_slot_list() -> void:
    var all_meta := SaveManager.load_all_meta()
    for slot_name in all_meta:
        var meta := all_meta[slot_name]
        var btn  := SlotButton.instantiate()
        btn.slot_name   = slot_name
        btn.label_text  = "%s  —  %s  —  %s" % [
            meta.get("player_name", "Unknown"),
            meta.get("level", "?"),
            _format_playtime(meta.get("playtime_sec", 0))
        ]
        btn.pressed.connect(func(): _load_slot(slot_name))
        $SlotList.add_child(btn)

func _load_slot(slot: String) -> void:
    var data := SaveManager.load_data(slot)
    if data.is_empty():
        $ErrorLabel.text = "Save file is empty or corrupted."
        return
    SaveManager.active_slot = slot
    GameState.apply_save(data)
    get_tree().change_scene_to_file("res://world/world.tscn")

func _format_playtime(seconds: int) -> String:
    var h := seconds / 3600
    var m := (seconds % 3600) / 60
    return "%d h %02d m" % [h, m]
```

## Practice Problems

:::problem
#### A — Create and List Slots easy

Using the `SaveManager` from the chapter, write code that creates three save slots named `"slot_1"`, `"slot_2"`, and `"slot_3"`, each with dummy game data `{"health": 100, "gold": 0}` and metadata `{"player_name": "Hero", "playtime_sec": 0}`. Then call `list_slots()` and print each slot name and its saved player name.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var dummy := {"health": 100, "gold": 0}
    var meta  := {"player_name": "Hero", "playtime_sec": 0}

    for i in range(1, 4):
        SaveManager.save("slot_%d" % i, dummy, meta)

    for slot in SaveManager.list_slots():
        var m := SaveManager.load_meta(slot)
        print("%s: %s" % [slot, m.get("player_name", "?")])
```
::::
:::

:::problem
#### B — Migration: Add New Field standard

You are adding a `"reputation"` field (int, default 0) to your save data in version 4. Write the `_migrate_v3_to_v4(data)` function and update the `_migrate()` chain to include it. `CURRENT_VERSION` should be updated to 4.

::::solution[Solution]
```gdscript
const CURRENT_VERSION := 4   # bumped from 3

func _migrate(data: Dictionary) -> Dictionary:
    var version: int = data.get("save_version", 1)
    if version < 2: data = _migrate_v1_to_v2(data)
    if version < 3: data = _migrate_v2_to_v3(data)
    if version < 4: data = _migrate_v3_to_v4(data)
    data["save_version"] = CURRENT_VERSION
    return data

func _migrate_v3_to_v4(data: Dictionary) -> Dictionary:
    if not "reputation" in data:
        data["reputation"] = 0
    data["save_version"] = 4
    return data
```
::::
:::

:::problem
#### C — Slot Delete with Confirmation standard

Write a UI function `confirm_delete(slot: String)` that: (1) shows a `ConfirmationDialog` asking "Delete slot X? This cannot be undone."; (2) if the player confirms, calls `SaveManager.delete_slot(slot)` and refreshes the slot list; (3) if the player cancels, does nothing. Assume the `ConfirmationDialog` is a child node at `$ConfirmDialog`.

::::solution[Solution]
```gdscript
func confirm_delete(slot: String) -> void:
    $ConfirmDialog.dialog_text = "Delete %s? This cannot be undone." % slot
    $ConfirmDialog.popup_centered()

    # Wait for the player to respond
    var confirmed := await $ConfirmDialog.confirmed
    # Note: ConfirmationDialog.confirmed emits on "OK";
    # .canceled emits on "Cancel" — use the confirmed signal

    SaveManager.delete_slot(slot)
    _populate_slot_list()   # refresh the UI
```

Alternative without `await`: connect the `confirmed` signal to a lambda that captures `slot`:

```gdscript
func confirm_delete(slot: String) -> void:
    $ConfirmDialog.dialog_text = "Delete %s? This cannot be undone." % slot
    # Disconnect any previous one-shot connection first
    if $ConfirmDialog.confirmed.is_connected(_on_confirm):
        $ConfirmDialog.confirmed.disconnect(_on_confirm)
    $ConfirmDialog.confirmed.connect(
        func(): SaveManager.delete_slot(slot); _populate_slot_list(),
        CONNECT_ONE_SHOT
    )
    $ConfirmDialog.popup_centered()
```
::::
:::

:::problem
#### D — Autosave on Area Enter standard

Write an `Area2D` node script called `SaveCheckpoint`. When the player body (`player` group) enters it, it should: (1) collect game state from a `GameState` autoload with `GameState.collect() -> Dictionary`; (2) save to the active slot via `SaveManager`; (3) emit a signal `checkpoint_reached`; (4) disable itself so it only triggers once per visit.

::::solution[Solution]
```gdscript
class_name SaveCheckpoint
extends Area2D

signal checkpoint_reached

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if not body.is_in_group("player"):
        return
    set_deferred("monitoring", false)   # disable so it won't re-fire

    var data := GameState.collect()
    var meta := {
        "player_name":  GameState.player_name,
        "level":        get_tree().current_scene.name,
        "playtime_sec": GameState.playtime_sec,
    }
    var slot := SaveManager.active_slot
    if slot.is_empty():
        slot = "autosave"
    SaveManager.save(slot, data, meta)
    checkpoint_reached.emit()
```
::::
:::

:::problem
#### E — Backup and Restore on Corruption challenge

Extend the `SaveManager` with a `save_with_backup()` that copies the existing `data.json` to `data.json.bak` before writing the new data. Then write `load_data_safe(slot)` that tries loading `data.json` first; if the result is empty or corrupt, tries `data.json.bak` instead; if both fail, returns an empty dictionary and logs an error.

::::solution[Solution]
```gdscript
func save_with_backup(slot: String, data: Dictionary, meta: Dictionary = {}) -> Error:
    var slot_dir  := SAVES_DIR + slot + "/"
    var data_path := slot_dir + "data.json"
    var bak_path  := slot_dir + "data.json.bak"
    var abs_data  := ProjectSettings.globalize_path(data_path)
    var abs_bak   := ProjectSettings.globalize_path(bak_path)

    # Backup existing data file before overwriting
    if FileAccess.file_exists(data_path):
        DirAccess.copy_absolute(abs_data, abs_bak)

    return save(slot, data, meta)

func load_data_safe(slot: String) -> Dictionary:
    # Try main file
    var d := load_data(slot)
    if not d.is_empty():
        return d

    # Try backup
    var bak := SAVES_DIR + slot + "/data.json.bak"
    if FileAccess.file_exists(bak):
        push_warning("Main save corrupt — loading backup for slot: " + slot)
        var text := FileAccess.get_file_as_string(bak)
        var parsed = JSON.parse_string(text)
        if parsed is Dictionary and not parsed.is_empty():
            return _migrate(parsed)

    push_error("Both save and backup are corrupt for slot: " + slot)
    return {}
```
::::
:::

## Cloud Save Basics

For desktop releases on Steam, cloud saving is handled by Steamworks. For web or multi-platform releases, you can implement a simple cloud save using any HTTP-accessible storage backend. Here's the minimum viable pattern with Godot's `HTTPRequest`:

### General approach

The save file lives locally as the source of truth. On game launch, fetch the remote save and compare timestamps with the local save. Take the newer one. On game quit (or periodic autosave), POST the local save to the server.

```gdscript
# cloud_sync.gd — Autoload
const SAVE_ENDPOINT := "https://your-api.example.com/save"
@onready var http := $HTTPRequest

func push_save(save_data: Dictionary, auth_token: String) -> void:
    var body := JSON.stringify(save_data)
    var headers := [
        "Content-Type: application/json",
        "Authorization: Bearer " + auth_token
    ]
    http.request(SAVE_ENDPOINT, headers, HTTPClient.METHOD_POST, body)

func pull_save(auth_token: String) -> void:
    var headers := ["Authorization: Bearer " + auth_token]
    http.request(SAVE_ENDPOINT, headers, HTTPClient.METHOD_GET)

func _on_request_completed(result, _code, _headers, body: PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS:
        push_warning("Cloud save request failed")
        return
    var data: Dictionary = JSON.parse_string(body.get_string_from_utf8())
    # Compare timestamps and decide which save to use
    var local_ts: int = SaveManager.get_timestamp()
    var remote_ts: int = data.get("saved_at", 0)
    if remote_ts > local_ts:
        SaveManager.load_from_dict(data)
        emit_signal("cloud_save_loaded")
```

:::callout-warning[Security note]
Never store auth tokens in your save file or in plaintext in user data. Use the OS keychain or a short-lived OAuth token that expires. Cloud saves are a common target for manipulation.
:::

### Steam Cloud (GodotSteam)

If you're shipping on Steam, use [GodotSteam](https://godotsteam.com) — a community GDExtension that wraps Steamworks. Steam's cloud save API (`SteamRemoteStorage`) handles conflict resolution, quota, and sync UI automatically. You simply write files to `user://` and tell Steamworks which files to sync.

## Save Slot UI Pattern

The save/load screen is the player's first and last interaction with your persistence system. A good one shows: which slots are occupied, when they were last saved, what the player had achieved at that point, and a preview screenshot.

### Screenshot preview

```gdscript
# Capture a screenshot at save time and store it alongside the save file
func save_with_screenshot(slot: int) -> void:
    # Capture the current frame
    var img: Image = get_viewport().get_texture().get_image()
    img.resize(320, 180)   # thumbnail size
    var path := "user://save_slot_%d_preview.png" % slot
    img.save_png(path)

    # Now do the actual save
    SaveManager.save_to_slot(slot)
```

### Loading the preview in the UI

```gdscript
# In your save slot button script
func refresh(slot: int) -> void:
    var preview_path := "user://save_slot_%d_preview.png" % slot
    if FileAccess.file_exists(preview_path):
        var tex := ImageTexture.new()
        var img := Image.load_from_file(preview_path)
        tex.set_image(img)
        preview_rect.texture = tex
    else:
        preview_rect.texture = empty_slot_texture

    var data := SaveManager.read_slot_metadata(slot)
    if data.is_empty():
        name_label.text = "— Empty —"
        time_label.text = ""
    else:
        name_label.text = data.get("player_name", "Unknown")
        var ts: int = data.get("saved_at", 0)
        time_label.text = Time.get_datetime_string_from_unix_time(ts)
```

:::callout-tip[Metadata-only reads]
Store a lightweight metadata dictionary at the top of your save file (slot index, timestamp, player name, level name, playtime) so you can populate the UI without deserialising the full save. Read only the metadata key when building the slot list.
:::

## Delete Confirmation & Slot Management

Deleting the wrong save slot is a game-ending frustration. Always require confirmation before deletion, and consider a brief undo window.

```gdscript
# In save slot UI
func _on_delete_pressed(slot: int) -> void:
    # Show a ConfirmationDialog first
    var dialog := $ConfirmationDialog
    dialog.dialog_text = "Delete save slot %d? This cannot be undone." % (slot + 1)
    dialog.confirmed.connect(func(): _do_delete(slot), CONNECT_ONE_SHOT)
    dialog.popup_centered()

func _do_delete(slot: int) -> void:
    SaveManager.delete_slot(slot)
    refresh_all_slots()

# SaveManager
func delete_slot(slot: int) -> void:
    var save_path := SAVE_DIR + "slot_%d.sav" % slot
    var preview_path := SAVE_DIR + "slot_%d_preview.png" % slot
    if FileAccess.file_exists(save_path):
        DirAccess.remove_absolute(save_path)
    if FileAccess.file_exists(preview_path):
        DirAccess.remove_absolute(preview_path)
    slot_deleted.emit(slot)
```

### Copy / import slots

Power users appreciate being able to copy a save to another slot before attempting a hard challenge. It's three lines of `DirAccess` code and dramatically reduces frustration complaints:

```gdscript
func copy_slot(from: int, to: int) -> void:
    DirAccess.copy_absolute(
        SAVE_DIR + "slot_%d.sav" % from,
        SAVE_DIR + "slot_%d.sav" % to
    )
```
