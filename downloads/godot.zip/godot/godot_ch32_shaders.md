---
title: "Introduction to Shaders"
source: "markdown"
---

Part III · Chapter 32

# Introduction to Shaders

Prerequisite: Ch 4 (GDScript), Ch 6 (2D basics), Ch 28 (Tweens) · est. 85 min

## Overview

A shader is a small programme that runs on the GPU — thousands of instances
 in parallel — to determine the final colour of every pixel on screen.
 Understanding shaders unlocks effects that are impossible with the standard
 rendering pipeline: dissolve transitions, water ripples, heat distortion,
 outline glows, toon shading, parallax terrain, and animated damage flashes
 that do not require additional sprites.

Godot uses its own **Godot Shading Language (GLSL-like)** that
 compiles to the appropriate backend (Vulkan SPIR-V, OpenGL ES) automatically.
 You write one shader, and Godot translates it for every supported platform.

This chapter covers:

- How the GPU rendering pipeline works at the level a Godot developer needs
- Godot Shading Language syntax, types, and built-in functions
- `canvas_item` shaders for 2D effects
- `spatial` shaders for 3D PBR materials
- Connecting shaders to GDScript via `ShaderMaterial` uniforms
- The Visual Shader node-graph editor

## 1 · The GPU Rendering Pipeline

### 1.1 · Vertex stage vs fragment stage

Every frame, the GPU processes your geometry in two main programmable stages:

| Stage | Input | Output | Runs once per… |
| --- | --- | --- | --- |
| **Vertex** | 3D position, UV, normal, colour (from mesh) | Clip-space position; varyings passed to fragment stage | …vertex in the mesh |
| **Fragment** | Interpolated varyings; uniform values; sampler textures | Final RGBA colour (and optionally depth) for one pixel | …pixel covered by a triangle |

For a 1920×1080 screen, the fragment shader may execute over 2 million times
 per frame. That parallelism is exactly why GPUs are fast at graphics — but
 it also means each invocation is *stateless*: no reads from
 neighbouring pixels, no loops that depend on data from other invocations.
 This constraint shapes every technique in this chapter.

:::callout-intuition[Intuition — vertex vs fragment cost]
Moving work from the fragment to the vertex stage is a common optimisation.
        A water wave computed per-vertex on a dense mesh uses far fewer shader
        invocations than the same wave computed per-fragment.  However, the
        interpolation between vertices can introduce visible faceting if the mesh
        is too coarse.  The right balance depends on visual quality requirements.
:::

CPU

mesh data

uniforms

vertices

Vertex Stage

vertex() runs once

per mesh vertex

outputs VERTEX,

UV, COLOR…

★ programmable

triangles

Rasterise

(fixed — GPU

fills triangles)

fragments

Fragment Stage

fragment() runs once

per pixel covered

outputs ALBEDO,

ALPHA, EMISSION…

★ programmable

Frame-

buffer

→ screen

Rasterisation is fixed-function — only Vertex and Fragment stages are programmable in GDShader

The GPU pipeline: CPU uploads mesh data → Vertex stage runs your `vertex()` function per vertex → GPU rasterises triangles automatically → Fragment stage runs your `fragment()` function per pixel → result written to the framebuffer.

### 1.2 · Shader types in Godot

The first line of every Godot shader declares its type:

| Type | Usage | Key functions |
| --- | --- | --- |
| `shader_type canvas_item;` | 2D sprites, UI, TileMap | `vertex()`, `fragment()`, `light()` |
| `shader_type spatial;` | 3D meshes, terrain | `vertex()`, `fragment()`, `light()` |
| `shader_type particles;` | GPU particle processing | `process()` |
| `shader_type sky;` | `Sky` resource backgrounds | `sky()` |
| `shader_type fog;` | Volumetric `FogVolume` | `fog()` |

## 2 · Godot Shading Language

### 2.1 · Types and built-ins

The language is strongly typed and very close to GLSL 3.30. All types are
 lowercase:

| Type | Description | Example literal |
| --- | --- | --- |
| `float` | 32-bit floating point | `3.14` |
| `int` | 32-bit signed integer | `42` |
| `uint` | 32-bit unsigned integer | `42u` |
| `bool` | Boolean | `true` |
| `vec2` / `vec3` / `vec4` | Float vectors; `.xyzw` and `.rgba` swizzle | `vec3(1.0, 0.5, 0.0)` |
| `ivec2` / `ivec3` / `ivec4` | Integer vectors | `ivec2(3, 7)` |
| `mat2` / `mat3` / `mat4` | Column-major matrices; `*` does matrix multiply | `mat3(1.0)` (identity) |
| `sampler2D` | 2D texture uniform (set from GDScript) | — |
| `sampler2DArray` | Texture array uniform | — |

**Swizzling** lets you extract or reorder components inline:

```glsl
vec4 col = vec4(0.8, 0.2, 0.5, 1.0);
vec3 rgb = col.rgb;         // (0.8, 0.2, 0.5)
vec2 ga  = col.ga;          // (0.2, 1.0) — green and alpha
float r  = col.r;           // 0.8
vec4 rev = col.abgr;        // (1.0, 0.5, 0.2, 0.8) — reverse
```

### 2.2 · Essential built-in functions

| Function | Returns | Description |
| --- | --- | --- |
| `mix(a, b, t)` | same as inputs | Linear interpolation: a\*(1-t) + b\*t |
| `clamp(x, lo, hi)` | same | Clamps x to [lo, hi] |
| `smoothstep(e0, e1, x)` | float | Smooth curve 0→1 as x goes from e0→e1 |
| `step(edge, x)` | float | 0.0 if x < edge, else 1.0 |
| `fract(x)` | same | Fractional part; `fract(3.7) = 0.7` |
| `floor(x)` / `ceil(x)` | same | Round down / up |
| `abs(x)` | same | Absolute value |
| `sin(x)` / `cos(x)` | float/vec | Trigonometric functions (radians) |
| `pow(x, y)` | same | x raised to y |
| `length(v)` | float | Vector magnitude |
| `normalize(v)` | same | Unit vector |
| `dot(a, b)` | float | Dot product |
| `cross(a, b)` | vec3 | Cross product |
| `texture(sampler, uv)` | vec4 | Sample a texture at UV coordinates |
| `textureSize(sampler, lod)` | ivec2 | Texture dimensions in pixels |

### 2.3 · Varyings — passing data from vertex to fragment

Data computed in the vertex shader must be declared as a `varying`
 to be accessible in the fragment shader. The GPU interpolates varying values
 smoothly across the triangle between vertex samples.

```glsl
shader_type canvas_item;

varying vec2 world_uv;   // custom UV based on world position

void vertex() {
    // VERTEX is the vertex position in local space (vec2 for canvas_item)
    world_uv = VERTEX / 512.0;   // tile every 512 px
}

void fragment() {
    // world_uv is now interpolated for each pixel
    COLOR = texture(TEXTURE, world_uv);
}
```

## 3 · CanvasItem Shaders (2D)

### 3.1 · Your first shader

Create a shader: in the Inspector, set a `Sprite2D`'s
 *Material* property to a new `ShaderMaterial`, then set the
 material's *Shader* to a new `Shader`. Click the shader
 to open the built-in shader editor.

Every canvas\_item fragment function has access to several built-in inputs:

| Built-in | Type | Description |
| --- | --- | --- |
| `UV` | `vec2` | Texture coordinate (0,0) top-left → (1,1) bottom-right |
| `TEXTURE` | `sampler2D` | The node's main texture |
| `COLOR` | `vec4` (in/out) | Vertex colour tint (input); final pixel colour (output) |
| `FRAGCOORD` | `vec4` | Screen-space pixel position (x, y, z=depth, w=1) |
| `TIME` | `float` | Elapsed time in seconds (automatic) |
| `uniform sampler2D … : hint_screen_texture` | `sampler2D` | The screen behind this node. Not a built-in in Godot 4 — `SCREEN_TEXTURE` was removed; declare a uniform carrying the hint and name it what you like |

The simplest meaningful shader inverts the colours of a sprite:

```glsl
shader_type canvas_item;

void fragment() {
    vec4 col = texture(TEXTURE, UV);
    COLOR = vec4(1.0 - col.rgb, col.a);
}
```

### 3.2 · Uniforms — parameters from GDScript

A `uniform` is a value you set from outside the shader — from
 GDScript, via `ShaderMaterial.set_shader_parameter()`. Uniforms
 persist across all invocations of the same frame (every pixel sees the same
 value).

```glsl
shader_type canvas_item;

uniform float flash_amount : hint_range(0.0, 1.0) = 0.0;
uniform vec4  flash_color  : source_color         = vec4(1.0, 1.0, 1.0, 1.0);

void fragment() {
    vec4 base = texture(TEXTURE, UV);
    // Blend sprite colour toward flash_color by flash_amount.
    COLOR = mix(base, flash_color * vec4(1.0, 1.0, 1.0, base.a), flash_amount);
    COLOR.a = base.a;   // preserve original alpha
}
```

| Hint | Effect in editor |
| --- | --- |
| `hint_range(min, max)` | Slider widget with range |
| `hint_range(min, max, step)` | Slider with step |
| `source_color` | Colour picker (sRGB input) |
| `hint_default_black` | Texture defaults to solid black |
| `filter_linear_mipmap` | Sampler with linear mipmap filtering |
| `repeat_enable` | Sampler with texture repeat on |

UV Texture Space

(0,0)

(1,0)

(0,1)

(1,1)

(0.5, 0.5)

U →

V ↓

Common UV Transforms

Scroll

UV + vec2(TIME, 0)

→ moving texture

Tile

fract(UV \* 4.0)

→ 4×4 repeat

Zoom to center

(UV - 0.5) \* s + 0.5

→ zoom effect

Polar coords

atan(uv.y, uv.x)

→ radial fx

UV space is always (0,0) top-left to (1,1) bottom-right regardless of texture resolution. Most shader tricks are just UV transformations — scroll by adding TIME, tile with `fract()`, zoom by scaling around the center.

### 3.3 · Texture sampling patterns

Sampling a texture at a *displaced* UV is how most 2D effects work:

```glsl
// Dissolve effect — pixels with noise below threshold become transparent.
shader_type canvas_item;

uniform sampler2D noise_texture : filter_linear, repeat_enable;
uniform float     threshold     : hint_range(0.0, 1.0) = 0.0;

void fragment() {
    vec4  base  = texture(TEXTURE, UV);
    float noise = texture(noise_texture, UV).r;   // red channel as mask
    // Discard pixels below threshold.  step() is branchless.
    float mask  = step(threshold, noise);
    COLOR       = vec4(base.rgb, base.a * mask);
}
```

```glsl
// Ripple / water UV distortion.
shader_type canvas_item;

uniform float wave_speed     : hint_range(0.0, 5.0) = 1.0;
uniform float wave_amplitude : hint_range(0.0, 0.1) = 0.02;

void fragment() {
    vec2 offset_uv = UV;
    offset_uv.x   += sin(UV.y * 20.0 + TIME * wave_speed) * wave_amplitude;
    offset_uv.y   += cos(UV.x * 20.0 + TIME * wave_speed) * wave_amplitude;
    COLOR = texture(TEXTURE, offset_uv);
}
```

### 3.4 · Common 2D effect recipes

**Outline (post-processing, no extra sprite):**

```glsl
shader_type canvas_item;

uniform vec4  outline_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float outline_width : hint_range(0.0, 8.0) = 2.0;

void fragment() {
    vec2 texel = 1.0 / vec2(textureSize(TEXTURE, 0));
    float alpha = texture(TEXTURE, UV).a;

    // Sample 4 cardinal neighbours; take the max alpha.
    float n = texture(TEXTURE, UV + vec2(0.0,  texel.y) * outline_width).a;
    float s = texture(TEXTURE, UV + vec2(0.0, -texel.y) * outline_width).a;
    float e = texture(TEXTURE, UV + vec2( texel.x, 0.0) * outline_width).a;
    float w = texture(TEXTURE, UV + vec2(-texel.x, 0.0) * outline_width).a;
    float outline = max(max(n, s), max(e, w)) - alpha;

    vec4 base = texture(TEXTURE, UV);
    COLOR = mix(base, outline_color, clamp(outline, 0.0, 1.0));
    COLOR.a = max(alpha, outline * outline_color.a);
}
```

**Greyscale + saturation control:**

```glsl
shader_type canvas_item;

uniform float saturation : hint_range(0.0, 1.0) = 1.0;

void fragment() {
    vec4  col  = texture(TEXTURE, UV);
    // Perceptual luminance weights.
    float grey = dot(col.rgb, vec3(0.299, 0.587, 0.114));
    COLOR      = vec4(mix(vec3(grey), col.rgb, saturation), col.a);
}
```

## 4 · Spatial Shaders (3D)

Spatial shaders drive 3D mesh materials. They output to Godot's
 physically-based rendering (PBR) pipeline by writing to a set of
 reserved output variables rather than directly to a pixel colour.

### 4.1 · PBR output variables

| Variable | Type | Description |
| --- | --- | --- |
| `ALBEDO` | `vec3` | Base colour (0–1 range; no lighting applied yet) |
| `METALLIC` | `float` | 0 = dielectric, 1 = full metal |
| `ROUGHNESS` | `float` | 0 = mirror-smooth, 1 = diffuse rough |
| `NORMAL_MAP` | `vec3` | Tangent-space normal from a texture |
| `NORMAL_MAP_DEPTH` | `float` | Normal map intensity multiplier |
| `EMISSION` | `vec3` | Emissive light added on top of PBR result (HDR values >1 contribute to bloom) |
| `ALPHA` | `float` | Transparency; requires `render_mode blend_mix;` |
| `AO` | `float` | Ambient occlusion (0 = fully occluded) |
| `AO_LIGHT_AFFECT` | `float` | How strongly AO affects direct lighting |

A basic PBR material with all maps:

```glsl
shader_type spatial;

uniform sampler2D albedo_map  : source_color, filter_linear_mipmap;
uniform sampler2D normal_map  : hint_normal,  filter_linear_mipmap;
uniform sampler2D roughness_map : hint_default_white, filter_linear_mipmap;
uniform float     metallic    : hint_range(0.0, 1.0) = 0.0;
uniform vec4      albedo_tint : source_color = vec4(1.0);

void fragment() {
    vec4 tex = texture(albedo_map, UV) * albedo_tint;
    ALBEDO        = tex.rgb;
    METALLIC      = metallic;
    ROUGHNESS     = texture(roughness_map, UV).r;
    NORMAL_MAP    = texture(normal_map, UV).rgb;
    NORMAL_MAP_DEPTH = 1.0;
}
```

:::callout-tip[Tip — hint\_normal]
hint\_normal

on a sampler tells Godot to interpret the texture
        as a tangent-space normal map and set the default to a flat normal
        (0.5, 0.5, 1.0 in RGB).  Without it the default is black, which gives a
        completely wrong result.
:::

### 4.2 · Vertex displacement

Moving vertices in the shader lets you animate mesh deformation — grass
 swaying, flag waving, water surface — without CPU overhead or blend shapes:

```glsl
shader_type spatial;
render_mode vertex_lighting;  // optional: bake lighting per-vertex for perf

uniform float wave_height    : hint_range(0.0, 1.0) = 0.2;
uniform float wave_frequency : hint_range(0.0, 10.0) = 2.0;
uniform float wave_speed     : hint_range(0.0, 5.0)  = 1.5;

void vertex() {
    // VERTEX is the local-space vertex position (vec3).
    // Displace Y by a sine wave driven by X position and time.
    VERTEX.y += sin(VERTEX.x * wave_frequency + TIME * wave_speed) * wave_height;
}

void fragment() {
    ALBEDO    = vec3(0.2, 0.5, 0.8);   // ocean blue
    METALLIC  = 0.0;
    ROUGHNESS = 0.1;                    // shiny water
}
```

:::callout-warning[Warning — vertex displacement and normals]
Displacing vertices does not automatically update normals, so lighting
        will look wrong on displaced meshes.  For water you can approximate the
        normal in the fragment stage using the derivative functions

dFdx()

and `dFdy()`, or sample a normal map that
        tiles over the displaced surface.  Alternatively, set the mesh subdivisions
        high enough that the faceting is not visible.
:::

## 5 · ShaderMaterial in GDScript

### 5.1 · set\_shader\_parameter

Any `uniform` declared in a shader becomes a parameter you can
 set from GDScript at any time — including every frame. Use
 `ShaderMaterial.set_shader_parameter(name, value)`:

```gdscript
## Driving a flash_amount uniform from the damage flash in Chapter 28.
@onready var _mat: ShaderMaterial = $Sprite2D.material

func flash_white(duration: float = 0.15) -> void:
    var tw: Tween = create_tween()
    tw.tween_method(
        func(v: float): _mat.set_shader_parameter("flash_amount", v),
        0.0, 1.0, duration * 0.3
    ).set_trans(Tween.TRANS_SINE)
    tw.tween_method(
        func(v: float): _mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, duration * 0.7
    ).set_trans(Tween.TRANS_QUAD)
```

Reading a uniform value back:

```gdscript
var current: float = _mat.get_shader_parameter("flash_amount")
```

Uniform values accept the GDScript equivalents of GLSL types:

| GLSL uniform type | GDScript value type |
| --- | --- |
| `float` | `float` |
| `int` | `int` |
| `bool` | `bool` |
| `vec2` | `Vector2` |
| `vec3` | `Vector3` or `Color` (rgb) |
| `vec4` | `Color` or `Plane` |
| `mat3` | `Basis` |
| `mat4` | `Transform3D` |
| `sampler2D` | `Texture2D` |

### 5.2 · Animated uniforms — dissolve transition

Combining the dissolve shader from Section 3.3 with a Tween creates a clean
 disappearance effect when an enemy dies:

```gdscript
## res://enemies/enemy.gd
@onready var _sprite: Sprite2D = $Sprite2D
@onready var _mat: ShaderMaterial = $Sprite2D.material

const DISSOLVE_DURATION := 0.6

func die() -> void:
    # Disable physics so the body stops reacting immediately.
    $CollisionShape2D.set_deferred("disabled", true)
    # Animate the dissolve threshold from 0 → 1.
    var tw: Tween = create_tween()
    tw.tween_method(
        func(v: float): _mat.set_shader_parameter("threshold", v),
        0.0, 1.0, DISSOLVE_DURATION
    ).set_trans(Tween.TRANS_LINEAR)
    await tw.finished
    queue_free()
```

:::callout-key[Key Concept — unique materials]
By default, all nodes sharing the same

ShaderMaterial

resource
        will show the

same

uniform values — changing one changes all.
        To make per-instance changes (each enemy has its own dissolve progress),
        either assign a unique material per node in the Inspector, or call

material = material.duplicate()

in

\_ready()

to
        get a local copy.
:::

## 6 · Visual Shader Editor

If you prefer a node-graph approach over writing GLSL text, Godot's
 **Visual Shader** editor lets you connect blocks
 visually. Create a `VisualShader` resource instead of
 a `Shader` on a `ShaderMaterial`, then open it
 to see the graph.

Nodes in the visual editor map directly to GLSL concepts:

| Visual node | GLSL equivalent |
| --- | --- |
| Input → *UV* | `UV` built-in |
| Input → *Time* | `TIME` built-in |
| Texture → *Texture2D* | `texture(sampler, uv)` |
| Math → *Mix* | `mix(a, b, t)` |
| Math → *SmoothStep* | `smoothstep(e0, e1, x)` |
| Color → *GrayScale* | `dot(rgb, vec3(0.299, 0.587, 0.114))` |
| Parameter → *FloatParameter* | `uniform float` |
| Output → *Fragment* | Final `COLOR` / PBR outputs |

:::callout-tip[Tip — inspect the generated GLSL]
With a VisualShader open, click

Show Generated Shader Code

at the
        top-right of the graph editor.  Reading the GLSL output is an excellent way
        to learn how nodes translate to code — and to spot performance issues like
        accidental loops or redundant texture samples.
:::

:::callout-connect[Connection — VisualShader and uniforms]
FloatParameter

nodes in the Visual Shader expose the same

set\_shader\_parameter()

API from GDScript.  The parameter name
        you type in the node's

Parameter Name

field is the string key
        you pass to `set_shader_parameter()`.
:::

## Summary

Shaders run on the GPU in two stages: the vertex stage repositions geometry,
 and the fragment stage determines each pixel's colour. Godot's shading
 language is GLSL-like, with strong typing, vector/matrix primitives, and
 a rich set of mathematical built-ins. Canvas item shaders operate in 2D
 UV space with access to `TEXTURE`, `UV`,
 `TIME`, and `FRAGCOORD`. Spatial shaders write to
 PBR output variables (`ALBEDO`, `METALLIC`,
 `ROUGHNESS`, etc.) that the renderer uses to compute lighting.
 Both types support vertex displacement. Uniforms bridge the shader and
 GDScript worlds: declare a `uniform` in the shader, call
 `ShaderMaterial.set_shader_parameter()` from code, and you can
 drive animations, tints, dissolves, and any other effect in real time.
 The Visual Shader node editor is a non-code alternative that compiles down
 to the same GLSL.

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Tint shader.**
 Write a `canvas_item` shader with a `vec4 tint_color`
 uniform (with `source_color` hint, default white) and a
 `float tint_strength` uniform (range 0–1, default 0).
 In `fragment()`, sample the texture, then mix the sampled
 colour toward `tint_color` by `tint_strength`,
 preserving the original alpha.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform vec4  tint_color    : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float tint_strength : hint_range(0.0, 1.0) = 0.0;

void fragment() {
    vec4 base = texture(TEXTURE, UV);
    COLOR     = vec4(mix(base.rgb, tint_color.rgb, tint_strength), base.a);
}
```
::::
:::

:::problem{difficulty="easy"}
**P2 — Pulse glow.**
 Write a `canvas_item` shader that makes a sprite pulse between
 its normal colours and a bright emission. Use a `uniform vec3
 glow_color` and animate the pulse with `sin(TIME * speed)`,
 remapping from [−1,1] to [0,1] with `* 0.5 + 0.5`. The
 glow should be added to `EMISSION` (available as a render
 target when the CanvasItem's *Use HDR 2D* is on, or via
 `render_mode unshaded` approximation by brightening
 `COLOR.rgb`).

::::solution[Solution]
```glsl
shader_type canvas_item;
// Approximation without HDR: brighten the rgb towards glow_color.
uniform vec3  glow_color : source_color = vec3(1.0, 0.8, 0.2);
uniform float glow_speed : hint_range(0.1, 10.0) = 2.0;
uniform float glow_strength : hint_range(0.0, 1.0) = 0.5;

void fragment() {
    vec4  base  = texture(TEXTURE, UV);
    float pulse = sin(TIME * glow_speed) * 0.5 + 0.5;
    vec3  glow  = glow_color * pulse * glow_strength;
    COLOR = vec4(base.rgb + glow * base.a, base.a);
}
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Scanline overlay.**
 Create a `canvas_item` shader that draws evenly-spaced
 dark horizontal scanlines over a sprite, like a CRT monitor effect.
 Use `FRAGCOORD.y` to determine line position. Expose a
 `float line_density` (lines per pixel, e.g. 0.5 = every
 2 px) and a `float darkness` (0 = no effect, 1 = black
 lines) as uniforms.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float line_density : hint_range(0.1, 2.0) = 0.5;
uniform float darkness     : hint_range(0.0, 1.0) = 0.4;

void fragment() {
    vec4  base = texture(TEXTURE, UV);
    // floor(FRAGCOORD.y * line_density) mod 2 creates alternating bands.
    float line = mod(floor(FRAGCOORD.y * line_density), 2.0);
    // line == 1 → apply darkness; line == 0 → leave untouched.
    float factor = 1.0 - line * darkness;
    COLOR = vec4(base.rgb * factor, base.a);
}
```
::::
:::

:::problem{difficulty="standard"}
**P4 — GDScript dissolve driver.**
 Given an enemy `Sprite2D` node with a `ShaderMaterial`
 already using the dissolve shader from Section 3.3, write a GDScript
 function `start_dissolve(duration: float)` that:
 sets the `threshold` uniform to 0 at the start,
 animates it linearly to 1 over `duration` seconds,
 then calls `queue_free()`.
 Make sure the material is unique (duplicate it in `_ready()`)
 so that only this enemy dissolves.

::::solution[Solution]
```gdscript
@onready var _sprite: Sprite2D       = $Sprite2D
@onready var _mat:    ShaderMaterial = $Sprite2D.material

func _ready() -> void:
    _mat = _mat.duplicate()
    _sprite.material = _mat
    _mat.set_shader_parameter("threshold", 0.0)

func start_dissolve(duration: float) -> void:
    var tw: Tween = create_tween()
    tw.tween_method(
        func(v: float): _mat.set_shader_parameter("threshold", v),
        0.0, 1.0, duration
    )
    await tw.finished
    queue_free()
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Ice / freeze spatial shader.**
 Write a `spatial` shader for a frozen-enemy effect.
 When a `float freeze_amount` uniform is 0, the mesh uses
 its normal `albedo_map` and `roughness_map`.
 As `freeze_amount` approaches 1, the material transitions
 toward: `ALBEDO` blended with an icy blue-white tint
 (`vec3(0.6, 0.85, 1.0)`), `ROUGHNESS` decreasing
 toward 0.05, and `METALLIC` increasing toward 0.4.
 Also add a faint blue `EMISSION` that intensifies with
 freeze\_amount, and desaturate the base albedo as the freeze increases
 (use the greyscale dot trick).

::::solution[Solution]
```glsl
shader_type spatial;

uniform sampler2D albedo_map    : source_color, filter_linear_mipmap;
uniform sampler2D roughness_map : hint_default_white, filter_linear_mipmap;
uniform float     freeze_amount : hint_range(0.0, 1.0) = 0.0;

const vec3 ICE_TINT     = vec3(0.6, 0.85, 1.0);
const vec3 ICE_EMISSION = vec3(0.05, 0.15, 0.3);

void fragment() {
    vec4  tex       = texture(albedo_map, UV);
    float grey      = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
    vec3  desatured = mix(tex.rgb, vec3(grey), freeze_amount);
    vec3  iced      = mix(desatured, ICE_TINT, freeze_amount * 0.6);
    float rough_base = texture(roughness_map, UV).r;

    ALBEDO    = iced;
    METALLIC  = mix(0.0,  0.4,  freeze_amount);
    ROUGHNESS = mix(rough_base, 0.05, freeze_amount);
    EMISSION  = ICE_EMISSION * freeze_amount;
}
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Portal edge shader.**
 Build a `canvas_item` shader for a circular portal. The
 sprite is a square with a circle alpha mask. The shader should:
 (1) sample a scrolling noise texture (driven by `TIME`)
 inside the circle; (2) add a glowing animated ring at the edge
 of the circle (use `smoothstep` near the alpha boundary);
 (3) expose a `vec4 ring_color` and
 `float ring_width` (0–0.1) as uniforms.
 Assume `UV` runs (0,0)→(1,1) and the circle fills the sprite
 (centre 0.5,0.5, radius 0.5).

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform sampler2D noise_tex : filter_linear, repeat_enable;
uniform float     scroll_speed : hint_range(0.0, 2.0) = 0.3;
uniform vec4      ring_color   : source_color = vec4(0.3, 0.8, 1.0, 1.0);
uniform float     ring_width   : hint_range(0.0, 0.1) = 0.04;

void fragment() {
    vec2 centred = UV - vec2(0.5);
    float dist   = length(centred);

    // Hard circle clip.
    float circle_alpha = 1.0 - step(0.5, dist);
    if (circle_alpha < 0.01) discard;

    // Scrolling noise fill.
    vec2  noise_uv = UV + vec2(TIME * scroll_speed, TIME * scroll_speed * 0.7);
    vec4  noise    = texture(noise_tex, noise_uv);

    // Glowing ring near edge: distance from 0.5 radius.
    float edge_dist = abs(dist - (0.5 - ring_width * 0.5));
    float ring      = smoothstep(ring_width, 0.0, edge_dist);

    // Compose.
    vec4 fill  = vec4(noise.rgb * 0.4 + 0.1, 1.0);
    COLOR      = mix(fill, ring_color, ring);
    COLOR.a    = circle_alpha;
}
```
::::
:::
