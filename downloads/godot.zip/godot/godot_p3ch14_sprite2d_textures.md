---
title: "Sprite2D, AnimatedSprite2D & Textures"
source: "godot_p3ch14_sprite2d_textures.html"
---

Part III · Chapter 14

# Sprite2D, AnimatedSprite2D & Textures

Part III — 2D Game Development · est. 2–3 hours · covers every Sprite2D/AnimatedSprite2D property and method, texture atlases, SpriteFrames, CanvasItem modulate and y-sort

## Overview

You have a scene tree, transforms, and physics — but nothing to look at yet. This chapter puts images on screen. You will learn how Godot loads image files as **Texture2D** resources, displays them through **Sprite2D**, chops up sprite sheets with atlases, and plays frame-by-frame animation through **AnimatedSprite2D** and its companion resource **SpriteFrames**.

:::callout-key[Prerequisites]
Ch 13 — Node2D, position, rotation, scale, Transform2D; Ch 5 — Signals (AnimatedSprite2D emits `animation_finished` and `frame_changed`); Ch 6 — Resources (.tres, ResourceLoader) — textures and SpriteFrames are resources.
:::

## 1 · Texture2D — What Godot Does with Your Image Files

:::callout-intuition[Intuition]
When you drag a `.png` into the FileSystem dock, Godot creates a companion `.import` file that records how to convert the PNG into a GPU-ready format. What you actually get at runtime is a **Texture2D** object — a thin wrapper around image data that lives on the GPU. Think of it as a named rectangle of pixels that a node can sample when drawing itself.
:::

### Texture2D subclasses

| Class | What it is | Common use |
| --- | --- | --- |
| `CompressedTexture2D` | What imported .png/.jpg files become. Read-only at runtime. | Sprites, UI icons — the everyday case |
| `ImageTexture` | Texture built from a CPU-side `Image`. Writable at runtime. | Dynamic / procedural textures |
| `AtlasTexture` | A sub-region of another Texture2D, defined by a `Rect2`. | Sprite sheet slicing |
| `ViewportTexture` | Live snapshot of a SubViewport's output. | Mini-maps, portals, render-to-texture |
| `CanvasTexture` | Bundles diffuse + normal + specular for 2D lighting. | Normal-mapped 2D characters |
| `GradientTexture1D/2D` | Gradient as a texture. | Skyboxes, VFX |
| `NoiseTexture2D` | FastNoiseLite output as a texture. | Procedural generation |

### Import settings (right-click → Re-Import)

| Setting | Default | When to change it |
| --- | --- | --- |
| Compress Mode | Lossy | Set *Lossless* for pixel art — prevents colour bleed |
| Filter | Enabled | Disable for pixel art — prevents blurry edges when scaled |
| Mipmaps | Disabled | Enable for textures that appear at many distances |
| Repeat | Disabled | Enable for tiling backgrounds |

:::callout-tip[Pixel art recipe]
Set Compress Mode to *Lossless* and uncheck *Filter* on each sprite. For project-wide crisp pixels go to **Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter** and set it to *Nearest*.
:::

### Loading textures in code

```gdscript
# preload — resolved at parse time, zero runtime cost, preferred for fixed paths
@onready var tex: Texture2D = preload("res://sprites/hero.png")

# load — resolved at runtime, useful for dynamic paths
var tex: Texture2D = load("res://sprites/hero.png")

# @export — drag any Texture2D from the Inspector
@export var icon: Texture2D
```

## 2 · Sprite2D — Every Property & Method

:::callout-intuition[Intuition]
Sprite2D is the simplest way to put a texture on screen. It draws one rectangle of pixels, centred on the node's position by default. You can shift that centre (the *offset*), show only part of the texture (a *region*), or slice a sprite sheet into a grid (hframes/vframes). Sprite2D extends Node2D, so all transform properties from Ch 13 apply directly.
:::

Inheritance chain: `Node → CanvasItem → Node2D → Sprite2D`

### All properties

| Property | Type | Default | What it does |
| --- | --- | --- | --- |
| texture | Texture2D | null | The image to display. Must be set for anything to render. |
| offset | Vector2 | (0,0) | Shifts the drawn image relative to the node's pivot/origin. |
| centered | bool | true | When true, texture is centred on the origin. When false, top-left sits at origin. |
| flip\_h | bool | false | Mirrors texture horizontally. Cleaner than `scale.x = -1` because it doesn't affect children. |
| flip\_v | bool | false | Mirrors texture vertically. |
| hframes | int | 1 | Number of columns in a sprite sheet grid. Divides texture width equally. |
| vframes | int | 1 | Number of rows in a sprite sheet grid. Divides texture height equally. |
| frame | int | 0 | Which cell of the hframes × vframes grid to display. 0-indexed, left-to-right then top-to-bottom. |
| frame\_coords | Vector2i | (0,0) | Select frame by (column, row). Synced with `frame`: setting one updates the other. |
| region\_enabled | bool | false | When true, only the rectangle defined by `region_rect` is drawn. |
| region\_rect | Rect2 | (0,0,0,0) | Sub-rectangle of the texture in pixels. Only active when `region_enabled = true`. |
| region\_filter\_clip\_enabled | bool | false | Clips bilinear filtering at region edges — prevents colour bleed from adjacent atlas cells. |

### All methods

| Method | Returns | What it does |
| --- | --- | --- |
| `get_rect()` | Rect2 | Bounding box of the drawn area in local space. |
| `is_pixel_opaque(pos: Vector2)` | bool | True if the pixel at `pos` (local space) has alpha > 0. Useful for pixel-perfect click detection. |
| `get_frame_coords()` | Vector2i | Current frame as (column, row). Same as reading `frame_coords`. |

### Signals

| Signal | When it fires |
| --- | --- |
| `frame_changed` | Whenever `frame` or `frame_coords` changes, including manual code changes. |
| `texture_changed` | When the `texture` property is reassigned. |

### Example A — flip direction, tint on damage

```gdscript
class_name Player
extends Node2D

@onready var sprite: Sprite2D = $Sprite2D
var velocity: Vector2 = Vector2.ZERO
var _hit_timer: float = 0.0

func _ready() -> void:
    sprite.texture  = load("res://sprites/player.png")
    sprite.centered = true

func _process(delta: float) -> void:
    if velocity.x != 0.0:
        sprite.flip_h = velocity.x < 0.0   # face movement direction

    if _hit_timer > 0.0:
        _hit_timer -= delta
        var t: float = _hit_timer / 0.2
        sprite.modulate = Color(1.0, 1.0 - t * 0.7, 1.0 - t * 0.7)
    else:
        sprite.modulate = Color.WHITE

func take_hit() -> void:
    _hit_timer = 0.2
```

### Example B — offset to place pivot at handle

```gdscript
@onready var sword: Sprite2D = $SwordSprite

func _ready() -> void:
    sword.texture  = preload("res://sprites/sword.png")
    sword.centered = false          # top-left at origin
    # 16×64 px sword; place the grip (bottom-centre) at origin:
    sword.offset   = Vector2(-8.0, -64.0)
```

:::callout-pitfall[Pitfalls]
**Texture is null** — Sprite2D renders nothing and gives no error. Add `assert(sprite.texture != null)` during development. **flip\_h vs scale.x = -1** — scale negates the X axis for all children too; flip\_h is visual only.
:::

## 3 · Texture Atlases — One Image, Many Sprites

:::callout-intuition[Intuition]
Switching textures flushes the GPU draw-call batch. Artists pack many sprites into one large image — a *sprite sheet* — to keep batching intact. Godot slices it two ways: a **uniform grid** (hframes/vframes) when every cell is the same size, or a **region\_rect / AtlasTexture** when cells vary.
:::

### Method A — hframes / vframes (uniform grid)

```gdscript
sprite.texture = preload("res://sprites/player_sheet.png")
sprite.hframes = 4   # 4 columns
sprite.vframes = 2   # 2 rows  →  8 frames total

# Select by flat index  (formula: frame = row * hframes + col)
sprite.frame = 6              # column 2, row 1

# Or select by coordinate
sprite.frame_coords = Vector2i(2, 1)   # same frame
```

### Method B — region\_rect (arbitrary sub-rectangle)

```gdscript
sprite.texture        = preload("res://sprites/tileset.png")
sprite.region_enabled = true
# Rect2(x_from_left, y_from_top, width, height) in pixels
sprite.region_rect    = Rect2(64.0, 96.0, 32.0, 32.0)
sprite.region_filter_clip_enabled = true   # prevent bleed from neighbours
```

### Method C — AtlasTexture resource

An `AtlasTexture` is a standalone resource wrapping a region of a sheet. Unlike `region_rect`, it can be saved as a .tres and reused across many sprites.

```gdscript
var atlas := AtlasTexture.new()
atlas.atlas       = preload("res://sprites/player_sheet.png")
atlas.region      = Rect2(0.0, 0.0, 32.0, 48.0)
atlas.filter_clip = true

$Sprite2D.texture = atlas
```

AtlasTexture properties: atlas (base Texture2D), region (Rect2 sub-image), margin (Rect2 transparent padding), filter\_clip (clip filtering at boundary).

:::callout-pitfall[Pitfall]
**region\_rect without region\_enabled** — setting `region_rect` has no effect until `region_enabled = true`. **Off-by-one in frame counting** — frames are 0-indexed; an 8-frame sheet has frames 0–7.
:::

## 4 · AnimatedSprite2D — Frame Animation Without AnimationPlayer

:::callout-intuition[Intuition]
AnimatedSprite2D is the "batteries-included" sprite animation node. It stores a named library of animations (idle, run, jump, attack…) each with their own frames, FPS, and loop setting — all inside a **SpriteFrames** resource. You call `play("run")` and it handles advancing frames, looping, and emitting signals when done. For most 2D characters this is the right choice over driving a Sprite2D frame manually.
:::

Inheritance: `Node → CanvasItem → Node2D → AnimatedSprite2D`

### All properties

| Property | Type | Default | What it does |
| --- | --- | --- | --- |
| sprite\_frames | SpriteFrames | null | The animation library resource. Must be set. |
| animation | StringName | "default" | Name of the currently active animation. Setting this alone does NOT start playback. |
| autoplay | String | "" | If not empty, plays this animation when the node enters the scene tree. |
| playing | bool | false | Read-only. True while actively advancing frames. |
| frame | int | 0 | Current frame index within the active animation. |
| frame\_progress | float | 0.0 | Sub-frame progress (0.0–1.0). Useful for interpolation or custom timing. |
| speed\_scale | float | 1.0 | Multiplies animation FPS. 2.0 = double speed; −1.0 = reverse. |
| centered | bool | true | Centres the texture on the node's origin. |
| offset | Vector2 | (0,0) | Pixel offset from the centred position. |
| flip\_h | bool | false | Mirrors all frames horizontally. |
| flip\_v | bool | false | Mirrors all frames vertically. |

### All methods

| Method | Signature | What it does |
| --- | --- | --- |
| `play` | `play(name: StringName = "", custom_speed: float = 1.0, from_end: bool = false)` | Starts playing. Empty name resumes current animation. `from_end` plays in reverse. |
| `play_backwards` | `play_backwards(name: StringName = "")` | Shorthand for `play(name, -1.0)`. |
| `pause` | `pause()` | Freezes on the current frame. Resume with `play()`. |
| `stop` | `stop()` | Stops and resets to frame 0. |
| `is_playing` | `is_playing() → bool` | True if currently advancing frames. |
| `get_playing_speed` | `get_playing_speed() → float` | Effective speed: base FPS × speed\_scale. |
| `set_frame_and_progress` | `set_frame_and_progress(frame: int, progress: float)` | Seeks to an exact frame and sub-frame position. |
| `sprite_frames.get_frame_count` | `sprite_frames.get_frame_count(anim: StringName) → int` | Number of frames in the named animation. The method belongs to the `SpriteFrames` resource rather than to the sprite, so it has to go through `sprite_frames`. |

### All signals

| Signal | When it fires |
| --- | --- |
| `animation_finished` | When a **non-looping** animation reaches its last frame. Key for one-shot attacks and death sequences. |
| `animation_looped` | When a looping animation wraps back to frame 0. |
| `animation_changed` | When the active animation name changes. |
| `frame_changed` | Every time the frame advances. |
| `sprite_frames_changed` | When the `sprite_frames` resource is replaced. |

### Example C — complete player animation controller

```gdscript
class_name PlayerVisual
extends Node2D

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
var _is_dead: bool = false

func _ready() -> void:
    anim.animation_finished.connect(_on_finished)
    anim.play("idle")

func update_animation(velocity: Vector2, on_floor: bool) -> void:
    if _is_dead: return
    var next: StringName
    if not on_floor:
        next = "jump" if velocity.y < 0.0 else "fall"
    elif abs(velocity.x) > 10.0:
        next = "run"
        anim.flip_h = velocity.x < 0.0
    else:
        next = "idle"
    # Guard prevents restarting the same animation every frame
    if anim.animation != next:
        anim.play(next)

func die() -> void:
    _is_dead = true
    anim.play("death")

func _on_finished() -> void:
    if anim.animation == "death":
        anim.pause()   # hold last frame
```

:::callout-pitfall[Pitfall — the animation restart trap]
Always guard `play()` with `if anim.animation != next_name`. Calling `play("run")` every physics frame resets the animation to frame 0 every frame, producing a perpetual first-frame flicker with no visible motion.
:::

## 5 · SpriteFrames — The Animation Library Resource

:::callout-intuition[Intuition]
SpriteFrames is the data container AnimatedSprite2D reads from. It is a **Resource** — save it as a .tres and share it across many nodes. Think of it as a dictionary: each key is an animation name, and its value is a list of (texture, hold-duration) pairs plus FPS and loop settings.
:::

### All methods

| Method | What it does |
| --- | --- |
| `add_animation(anim)` | Creates a new empty named animation. |
| `remove_animation(anim)` | Deletes an animation and all its frames. |
| `rename_animation(anim, newname)` | Renames without touching frames. |
| `has_animation(anim) → bool` | True if the named animation exists. |
| `get_animation_names() → PackedStringArray` | All animation names in this resource. |
| `set_animation_loop(anim, loop)` | Set whether the animation loops. |
| `get_animation_loop(anim) → bool` | Read the loop setting. |
| `set_animation_speed(anim, fps)` | Set the FPS for this animation. |
| `get_animation_speed(anim) → float` | Read the FPS. |
| `add_frame(anim, texture, duration, at_position)` | Append (or insert) a frame. `duration` is a hold multiplier on the base FPS. |
| `remove_frame(anim, idx)` | Remove a frame by index. |
| `get_frame_count(anim) → int` | Number of frames in this animation. |
| `get_frame_texture(anim, idx) → Texture2D` | Texture at a given frame index. |
| `get_frame_duration(anim, idx) → float` | Hold duration multiplier at a given frame. |
| `set_frame(anim, idx, texture, duration = 1.0)` | Replace the texture and the hold duration at a specific frame. There is no separate setter for either one, so pass the current value for whichever you are not changing. |

### Example D — building SpriteFrames in code from a sprite sheet

```gdscript
func build_frames(sheet: Texture2D, cols: int, rows: int,
                  anims: Dictionary) -> SpriteFrames:
    var sf   := SpriteFrames.new()
    var cw   := sheet.get_width()  / float(cols)
    var ch   := sheet.get_height() / float(rows)

    for anim_name: String in anims:
        var info: Dictionary = anims[anim_name]
        sf.add_animation(anim_name)
        sf.set_animation_speed(anim_name, info.get("fps", 12.0))
        sf.set_animation_loop(anim_name, info.get("loop", true))

        for i: int in range(info["from"], info["to"] + 1):
            var atlas       := AtlasTexture.new()
            atlas.atlas      = sheet
            atlas.region     = Rect2((i % cols) * cw, (i / cols) * ch, cw, ch)
            atlas.filter_clip = true
            sf.add_frame(anim_name, atlas)
    return sf

# Usage:
func _ready() -> void:
    var sf := build_frames(preload("res://sprites/knight.png"), 8, 4, {
        "idle":   {"from": 0,  "to": 3,  "fps": 8,  "loop": true},
        "run":    {"from": 8,  "to": 15, "fps": 12, "loop": true},
        "attack": {"from": 16, "to": 21, "fps": 14, "loop": false},
        "death":  {"from": 24, "to": 31, "fps": 10, "loop": false},
    })
    $AnimatedSprite2D.sprite_frames = sf
    $AnimatedSprite2D.play("idle")
```

:::callout-pitfall[Pitfalls]
**Shared SpriteFrames mutations** — if two nodes share the same resource and you call `add_frame()`, both see the change. Call `sf.duplicate(true)` first for per-instance modification. **animation\_finished not firing** — it only fires for non-looping animations; `get_animation_loop("death") == true` silently prevents it.
:::

## 6 · CanvasItem Properties — Visibility, Modulate & Z-Index

:::callout-intuition[Intuition]
Both Sprite2D and AnimatedSprite2D inherit from **CanvasItem**, the base for everything that draws in 2D. CanvasItem gives you colour tinting, transparency, visibility, and draw-order. These properties affect the node *and all its children*, which makes them useful for bulk effects at the parent level.
:::

### Key CanvasItem properties for sprites

| Property | Type | Default | Effect |
| --- | --- | --- | --- |
| visible | bool | true | When false, skips drawing entirely — more efficient than alpha=0. |
| modulate | Color | WHITE | Multiplies this colour over the node AND all children. RGBA in 0–1 range. |
| self\_modulate | Color | WHITE | Same as modulate but affects *only this node*, not its children. |
| z\_index | int | 0 | Draw order. Higher = drawn on top within the same layer. |
| z\_as\_relative | bool | true | When true, z\_index adds to the parent's z\_index. When false, it is absolute. |
| y\_sort\_enabled | bool | false | On a *parent* node: auto-sorts children by Y position each frame. Essential for top-down RPG depth. |
| texture\_filter | TextureFilter | PARENT\_NODE | Override project-wide texture filter for this node. Set to NEAREST for pixel art. |
| material | Material | null | Shader material applied to this canvas item. |
| top\_level | bool | false | Ignores parent transform — useful for world-space overlays on a moving parent. |

### Modulate cookbook

```gdscript
var s: Sprite2D = $Sprite2D

s.visible         = false           # efficient — skips draw call entirely
s.modulate        = Color.WHITE     # no tint (identity)
s.modulate        = Color(1, 0.3, 0.3, 1)   # tint red
s.modulate.a      = 0.5             # 50% transparent

# Tween fade-out
create_tween().tween_property(s, "modulate:a", 0.0, 0.5)

# self_modulate: tint only this sprite, not its children
s.self_modulate = Color(2.0, 2.0, 2.0, 1.0)  # HDR white flash
```

### Y-sort for top-down depth

In top-down RPGs, characters lower on screen should draw in front of characters higher up. Enable `y_sort_enabled = true` on the parent node — all direct children are automatically sorted by their `position.y` every frame with no per-character code needed. Place each character node's origin at the character's *feet*, not the sprite centre, so the sort point is visually correct.

## 7 · Practical Workflow — From Art File to Animated Character

1. **Import sprite sheet** — drag PNG into FileSystem. Re-Import: Lossless + Filter off for pixel art.
2. **Build character scene** — CharacterBody2D root → CollisionShape2D child → AnimatedSprite2D child.
3. **Create SpriteFrames** — select AnimatedSprite2D, click *SpriteFrames* in Inspector → New SpriteFrames. The SpriteFrames editor opens at the bottom.
4. **Add animations** — click + for each animation (idle, run, jump, fall, death). Drag frames from FileSystem into the frame strip. Set FPS and loop flag per animation.
5. **Save SpriteFrames** — right-click SpriteFrames in Inspector → Save As → `res://resources/player_frames.tres`.
6. **Write the animation script** — use `@onready var anim: AnimatedSprite2D = $AnimatedSprite2D`. Drive from velocity with the `if anim.animation != next` guard.
7. **Wire one-shot animations via signal** — connect `anim.animation_finished` and check `anim.animation` in the callback to return to idle after attack/death.

### Example E — one-shot attack with animation\_finished

```gdscript
extends CharacterBody2D

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
var _attacking: bool = false

func _ready() -> void:
    anim.animation_finished.connect(_on_finished)

func _process(_delta: float) -> void:
    if Input.is_action_just_pressed("attack") and not _attacking:
        _attacking = true
        anim.play("attack")   # non-looping → animation_finished fires at end

func _on_finished() -> void:
    match anim.animation:
        "attack":
            _attacking = false
            anim.play("idle")
        "death":
            anim.pause()
            queue_free.call_deferred()
```

:::callout-connect[Connect — AnimatedSprite2D vs AnimationPlayer]
AnimatedSprite2D is purpose-built for frame-by-frame sprite animation and is self-contained. AnimationPlayer (covered later) can animate *any property* over time — position, colour, shader parameters — and can also drive Sprite2D's `frame`. For simple sprite animation use AnimatedSprite2D; for multi-property cutscenes and blend trees use AnimationPlayer.
:::

## Practice Problems

:::problem{difficulty="easy"}
**A.** Create a Sprite2D that displays `res://icon.svg`, is *not* centred (top-left at origin), and is flipped horizontally. Write the `_ready()` code.

::::solution[Solution]
```gdscript
func _ready() -> void:
    var s := $Sprite2D
    s.texture  = load("res://icon.svg")
    s.centered = false
    s.flip_h   = true
```
::::
:::

:::problem{difficulty="easy"}
**B.** A sprite sheet is 256×64 px with 8 frames in a single row. Write the code to display frame 5 (0-indexed).

::::solution[Solution]
```gdscript
var s := $Sprite2D
s.texture = preload("res://sprites/sheet.png")
s.hframes = 8
s.vframes = 1
s.frame   = 5   // or: s.frame_coords = Vector2i(5, 0)
```
::::
:::

:::problem{difficulty="standard"}
**C.** Explain the difference between `modulate` and `self_modulate`. A player node has a Sprite2D child and a HUD Label child. You want to tint only the sprite red on damage, leaving the label white. Which property, on which node?

::::solution[Solution]
`modulate` affects the node and *all children* recursively. `self_modulate` affects *only the node itself*.

Set `self_modulate = Color(1.0, 0.3, 0.3)` on the **Sprite2D** directly. Setting `modulate` on the player root would also tint the HUD label.
::::
:::

:::problem{difficulty="standard"}
**D.** You have an AnimatedSprite2D with a non-looping "jump" animation. Write code in `_ready()` that connects a signal so when jump finishes, "fall" begins immediately.

::::solution[Solution]
```gdscript
func _ready() -> void:
    anim.animation_finished.connect(func() -> void:
        if anim.animation == "jump":
            anim.play("fall")
    )
    anim.play("jump")
```

The guard `if anim.animation == "jump"` is essential — `animation_finished` fires for *any* non-looping animation, so without the guard every non-looping clip would trigger "fall".
::::
:::

:::problem{difficulty="standard"}
**E.** What does `y_sort_enabled = true` do, and on which node do you set it for a top-down RPG? Why should the character's node origin be placed at the character's feet?

::::solution[Solution]
When true on a parent node, all direct children are automatically sorted by their `position.y` each frame — the smallest Y (highest on screen) draws first (behind), the largest Y (lowest on screen) draws last (in front). This produces correct depth ordering without manual z\_index code.

Set it on the **parent** containing the characters — e.g. a YSort Node2D, TileMapLayer, or the level root.

Origin at the feet: y\_sort uses the node's origin point. A character whose origin is at the sprite centre will sort incorrectly when two characters stand at similar heights. With the origin at the feet, sorting is always relative to where each character's feet touch the ground.
::::
:::

:::problem{difficulty="challenge"}
**F.** Write a function `build_sprite_frames` that takes a Texture2D sheet (8 cols × 4 rows, 64×64 cells), an animation name, start cell index, end cell index, FPS, and loop flag. Return a SpriteFrames with that single animation using AtlasTexture frames.

::::solution[Solution]
```gdscript
func build_sprite_frames(sheet: Texture2D, anim_name: StringName,
        from_cell: int, to_cell: int,
        fps: float = 12.0, loop: bool = true) -> SpriteFrames:
    const COLS  := 8
    const CW    := 64.0
    const CH    := 64.0
    var sf      := SpriteFrames.new()
    sf.remove_animation("default")
    sf.add_animation(anim_name)
    sf.set_animation_speed(anim_name, fps)
    sf.set_animation_loop(anim_name, loop)
    for cell: int in range(from_cell, to_cell + 1):
        var atlas       := AtlasTexture.new()
        atlas.atlas      = sheet
        atlas.region     = Rect2((cell % COLS) * CW, (cell / COLS) * CH, CW, CH)
        atlas.filter_clip = true
        sf.add_frame(anim_name, atlas, 1.0)
    return sf
```
::::
:::

:::problem{difficulty="challenge"}
**G.** Implement a "ghost trail" effect: every 0.05 seconds spawn a copy of the player's current AnimatedSprite2D at the player's world position, tinted blue at 50% alpha, frozen on the current frame, and fading to invisible over 0.3 s before freeing itself.

::::solution[Solution]
```gdscript
extends CharacterBody2D

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    var timer       := Timer.new()
    timer.wait_time  = 0.05
    timer.autostart  = true
    add_child(timer)
    timer.timeout.connect(_spawn_ghost)

func _spawn_ghost() -> void:
    var ghost: AnimatedSprite2D = sprite.duplicate() as AnimatedSprite2D
    ghost.top_level        = true        # detach from player transform
    ghost.global_position  = sprite.global_position
    ghost.global_rotation  = sprite.global_rotation
    ghost.modulate         = Color(0.3, 0.6, 1.0, 0.5)
    ghost.pause()                        # freeze on current frame
    get_parent().add_child(ghost)
    var t := ghost.create_tween()
    t.tween_property(ghost, "modulate:a", 0.0, 0.3)
    t.tween_callback(ghost.queue_free)
```

`top_level = true` detaches the ghost from the player's transform so it stays in place as the player moves.
::::
:::
