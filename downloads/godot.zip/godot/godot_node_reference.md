---
title: "Complete Node Reference"
crumb: "Godot 4.x Textbook · Appendix A"
meta:
  - "~80 nodes covered"
  - "All scene-tree node types"
  - "Godot 4.x"
source: "markdown"
---

This appendix provides quick-reference cards for every major Godot 4 scene-tree node not covered in dedicated chapters. Each card covers what the node does, its key Inspector properties, and when to choose it over alternatives. Nodes already covered in full chapters are linked rather than repeated.

:::callout-connect[Already covered elsewhere]
StaticBody2D/CharacterBody2D/RigidBody2D/Area2D/RayCast2D/ShapeCast2D → [Ch 8](godot_ch8_2d_physics.html) · TileMapLayer → [Ch 9](godot_ch9_tilemaplayer.html) · All UI containers and widgets → [Ch 13](godot_ch13_ui_control_nodes.html) · AnimationPlayer/AnimatedSprite2D/AnimationTree → [Ch 14A](godot_ch14a_animation.html) · AudioStreamPlayer family → [Ch 15](godot_ch15_audio.html) · Camera2D/Camera3D/SubViewport → [Ch 17](godot_ch17_camera.html) · GPUParticles/CPUParticles → [Ch 18](godot_ch18_particles.html) · NavigationRegion/Agent → [Ch 20](godot_ch20_navigation.html) · AnimationTree nodes → [Ch 37](godot_ch37_animation_trees.html)
:::

## Base Node Classes

Every scene-tree node ultimately inherits from `Node`. Understanding the base classes tells you what every node can do — signals, groups, process callbacks — before you even look at the specialised properties.

#### Node

*root of all scene-tree nodes*

The base class for everything in the scene tree. Every node — Sprite2D, CharacterBody2D, Label, Camera3D — inherits Node's capabilities: lifecycle callbacks (`_ready`, `_process`, `_physics_process`), signal system, group membership, child/parent traversal, and scene saving. You rarely add a bare Node to the scene; instead you use it as a logical parent or script host with no visual component.

| Property / Method | — | What it does |
| --- | --- | --- |
| name | String | The node's identifier in the scene tree — used by `$NodeName` shorthand to get a child reference |
| process\_mode | INHERIT | PAUSABLE: pauses when SceneTree is paused. ALWAYS: runs even when paused (use for pause menus). DISABLED: never processes |
| process\_priority | 0 | Lower runs first within the same process callback. Use to order script execution when two nodes share a frame |
| \_ready() | callback | Called once when the node enters the scene tree and all children are ready — initialise variables here, not in constructors |
| \_process(delta) | callback | Called every rendered frame — use for visuals, UI, camera. Not physics-safe |
| \_physics\_process(delta) | callback | Called at fixed physics tick rate (default 60 Hz) — use for movement, collision queries, force application |
| add\_to\_group(name) | method | Tag this node so `get_tree().get_nodes_in_group()` or `call_group()` can address it by category |
| queue\_free() | method | Schedules the node for deletion at the end of the current frame — safe to call from inside the node's own callbacks |

Use bare Node when:

you need a logical container or script host with no visual — a GameManager, EventBus, state machine root, or scene organiser.

Key rule:

always initialise references to children in `_ready()`, never in `_init()` — children aren't in the tree yet during `_init()`.

#### Node2D

*inherits CanvasItem → Node*

The base for all 2D scene nodes. Adds a 2D transform (position, rotation, scale) to Node's capabilities. Everything you place in a 2D game world — sprites, physics bodies, particles, tilemaps — descends from Node2D and inherits its transform. Use a bare Node2D as a container that groups 2D objects and applies a shared transform to all children.

| Property | Default | What it does |
| --- | --- | --- |
| position | Vector2(0,0) | Position in the parent's local coordinate space. Inherited by all children |
| global\_position | — | World-space position accounting for all parent transforms — use for world-relative calculations |
| rotation | 0 rad | Rotation in radians. Use `rotation_degrees` for degree-based authoring |
| scale | Vector2(1,1) | Non-uniform scale. Values <1 shrink, >1 enlarge. Negative mirrors the axis |
| z\_index | 0 | Draw order within the same CanvasLayer. Higher draws on top. Siblings with equal z\_index draw in scene-tree order |
| z\_as\_relative | true | When true, z\_index is added to the parent's z\_index — useful for local layering within a group |
| y\_sort\_enabled | false | Children are sorted by their Y position so lower-Y (higher on screen) draws behind higher-Y — essential for top-down depth |

Use bare Node2D when:

grouping 2D objects that should share a transform — a "player" node whose children are Sprite2D + CollisionShape2D + AnimationPlayer.

Key method:

look\_at(target: Vector2)

— instantly rotates to face a world position. Great for turrets and homing projectiles.

#### Node3D

*inherits Node*

The base for all 3D scene nodes, equivalent to Node2D in the 3D world. Adds a 3D transform (position, rotation, scale) as a `Transform3D` resource. Every 3D object — MeshInstance3D, CharacterBody3D, Camera3D, Light3D — inherits from Node3D. Use a bare Node3D as a pivot point, rig root, or organisational container in 3D scenes.

| Property | Default | What it does |
| --- | --- | --- |
| position | Vector3(0,0,0) | Local position within the parent transform |
| rotation | Vector3(0,0,0) | Euler rotation in radians (XYZ order). Use `rotation_degrees` for inspector-friendly authoring |
| scale | Vector3(1,1,1) | Per-axis scale. Negative values mirror the axis |
| basis | identity | The orientation-and-scale part of the transform as a 3×3 matrix — manipulate for precise rotation without Euler gimbal issues |
| global\_position | — | World-space position after all parent transforms are applied |
| visibility | true | Whether this node and all VisualInstance3D children are rendered |
| top\_level | false | When true, the node's transform is not inherited from its parent — useful for camera rigs that shouldn't rotate with the character |

Use bare Node3D when:

you need a 3D pivot, a group container, or a script host — e.g. a weapon attachment point, a camera rig root, or a scene-organiser grouping meshes.

Key method:

look\_at(target: Vector3, up: Vector3)

— rotates to face a world position. Essential for turrets, AI agents, and billboard effects.

## 2D Drawing Nodes

#### Sprite2D

*inherits Node2D*

Displays a single texture (or a rectangular region of one) as a 2D image. The simplest way to put a graphic in a 2D scene — drag a PNG onto a Sprite2D and it appears. Supports sprite sheets via `hframes`/`vframes` for manual frame control, flipping, offset, and modulate colour. For automatic frame cycling use AnimatedSprite2D instead.

| Property | Default | What it does |
| --- | --- | --- |
| texture | null | The image to display. Drag any .png/.webp/.svg resource here |
| centered | true | Origin at the texture centre. Turn off for tile-aligned objects where (0,0) should be the top-left corner |
| offset | Vector2(0,0) | Pixel offset from the node origin — use to shift the image without moving the physics body |
| flip\_h / flip\_v | false | Mirror horizontally/vertically. Use flip\_h to face a character left without a separate art set |
| hframes / vframes | 1 / 1 | Divide the texture into a grid of frames. Set frame to pick which cell to display — manual sprite sheet control |
| frame | 0 | Which hframe×vframe cell to display (0 = top-left). Animate this with AnimationPlayer for manual frame control |
| region\_enabled | false | Display only a sub-rectangle of the texture — precise atlas extraction without hframes |
| region\_rect | Rect2(0,0,0,0) | The pixel rectangle within the atlas to display when region\_enabled is true |
| modulate | Color(1,1,1,1) | Tints the texture — red for damage flash, semi-transparent for ghost effects. Inherited by children |

Use when:

displaying a static or manually-controlled sprite — backgrounds, props, UI icons, single-image characters.

Prefer AnimatedSprite2D when:

you need automatic frame cycling with named animation sequences.

Prefer TextureRect when:

the image is part of a UI layout inside a Control hierarchy.

#### Line2D

*inherits Node2D*

Draws a polyline (sequence of connected line segments) through a list of 2D points. Used for ropes, laser beams, drawn paths, trajectory previews, debug overlays, and any line-based visual. The line has configurable width, colour gradient, texture, and end caps. You can add or modify points at runtime to create animated lines.

| Property | Default | What it does |
| --- | --- | --- |
| points | [] | Array of Vector2 positions defining the polyline vertices, in local space |
| width | 10.0 px | Line thickness in pixels. Use `width_curve` for variable width along the line |
| width\_curve | null | A Curve resource mapping 0–1 position along the line to a width multiplier — tapers ropes, makes laser beams glow at the tip |
| default\_color | white | Solid colour of the line when gradient is null |
| gradient | null | A Gradient resource — colours the line from start to end. Great for plasma beams and health bar outlines |
| texture | null | A texture mapped along the line length — for rope textures, dashed lines, patterned cables |
| texture\_mode | NONE | STRETCH (texture fills once), TILE (repeats), SQUARE (each segment gets a copy) |
| joint\_mode | SHARP | SHARP: pointed corners. BEVEL: cut corners. ROUND: smooth corners. Affects how line segments connect |
| begin\_cap\_mode / end\_cap\_mode | NONE | BOX: squared ends. ROUND: rounded ends. Useful for rope ends and stylised lasers |
| closed | false | Connect the last point back to the first — draws a closed polygon outline |
| antialiased | false | Smooth the line edges — makes thin lines look much cleaner at the cost of slight extra draw time |

Use when:

drawing any line-based visual — ropes, cables, lasers, projectile trails, drawn paths, trajectory arcs, debug overlays.

Runtime control:

add\_point(pos)

,

set\_point\_position(idx, pos)

, `remove_point(idx)` — modify the line live to animate ropes or follow a physics chain.

#### Polygon2D

*inherits Node2D*

Draws a filled 2D polygon defined by an array of vertices. Supports solid colour fill, texture mapping with UV coordinates, vertex colours, and antialiasing. Use it for terrain silhouettes, shadows, filled health bars, water surfaces, custom shapes, and anything requiring a filled region rather than an outline.

| Property | Default | What it does |
| --- | --- | --- |
| polygon | [] | Array of Vector2 vertices defining the polygon outline, in local space. Clockwise or counter-clockwise both work |
| color | white | Solid fill colour when no texture is assigned |
| texture | null | An image mapped onto the polygon using the uv array |
| uv | [] | UV coordinates per vertex for texture mapping — must match polygon length. Set automatically by the Polygon2D editor tool |
| vertex\_colors | [] | Per-vertex colours blended across the polygon — create colour gradients without a texture |
| offset | Vector2(0,0) | Shifts the entire polygon without changing vertex data |
| antialiased | false | Smooth polygon edges — important for non-axis-aligned shapes |
| internal\_vertex\_count | 0 | When >0, the last N vertices are internal (not on the outline) — used by the Skeleton2D deformation system |

Use when:

you need a filled shape — terrain cross-sections, shadow casters, water fills, health/mana bar backgrounds, dynamic mesh shapes.

For deformable shapes:

pair with Skeleton2D and use internal vertices — the standard technique for 2D character cutout animation.

Prefer CollisionPolygon2D:

when you only need the physics shape, not a visual.

## Canvas Utility Nodes

#### CanvasModulate

*inherits Node2D*

Applies a colour tint to the entire CanvasLayer it belongs to. Everything in the same canvas is multiplied by this colour — drop one into your game world layer and you can tint the whole scene red for a damage flash, desaturate it for a cinematic effect, or darken it for night. Only one CanvasModulate should be active per canvas.

| Property | Default | What it does |
| --- | --- | --- |
| color | Color(1,1,1,1) | The modulate tint applied to the entire canvas. White = no effect. Dark blue = night filter. Red = damage flash |

Use when:

you need a global colour effect on the game world — night cycle, damage flash, underwater tint, desaturation for death screen.

Animate with Tween:

tween.tween\_property($CanvasModulate, "color", Color(1,0,0), 0.1)

for a quick damage flash.

One per canvas:

multiple CanvasModulate nodes in the same canvas multiply together — keep just one and animate its colour property.

#### CanvasGroup

*inherits Node2D*

Flattens all its children onto a single texture before rendering, then applies modulate, blend mode, and shader to the combined result. Without CanvasGroup, modulate on a parent blends with each child individually (causing overlap artefacts on semi-transparent sprites). With CanvasGroup, the children are composited first so the tint applies cleanly to the whole group as one unit.

| Property | Default | What it does |
| --- | --- | --- |
| fit\_margin | 10 px | Extra pixels added around the bounding box of children — increase if children have glow shaders that bleed outside their rect |
| clear\_margin | 10 px | How far outside the bounding box the canvas is cleared to transparent — usually matches fit\_margin |

Use when:

you want to modulate or apply a shader to a group of overlapping semi-transparent sprites as a single unit — character with multiple semi-transparent parts, ghost effect on a composite character.

Performance note:

CanvasGroup causes an offscreen render pass — use sparingly and only when the compositing artefact is actually visible.

## 2D Lighting

#### DirectionalLight2D

*inherits Light2D → Node2D*

Simulates a distant light source (sun, moon) that shines with parallel rays across the entire 2D scene. Unlike PointLight2D it has no falloff — every lit pixel receives identical intensity regardless of position. Supports normal maps on Sprite2D and other 2D nodes for fake depth shading.

| Property | Default | What it does |
| --- | --- | --- |
| color | white | Tint of the light |
| energy | 1.0 | Brightness multiplier — values above 1 blow out colours |
| blend\_mode | ADD | ADD brightens, MIX replaces, SUBTRACT darkens — most platformers use ADD |
| range\_layer\_min/max | -100 / 100 | Which CanvasLayer indices receive this light |
| shadow\_enabled | false | Enable soft shadows cast by LightOccluder2D nodes |
| max\_distance | 10 000 px | How far shadows are traced — lower = cheaper |

Use when:

you want a single ambient light angle (e.g., sun rays from upper-left) that evenly illuminates the whole scene — top-down dungeon, side-scrolling platformer with time-of-day.

Prefer PointLight2D when:

you want a localised glow (torch, lantern, explosion) that fades with distance.

#### PointLight2D

*inherits Light2D → Node2D*

A localised 2D light that radiates outward from a point and falls off with distance, shaped by a texture mask. Draws a torch glow, muzzle flash, magic orb, or any small area illumination. Supports normal-mapped sprites for convincing depth. The light texture (a radial gradient by default) defines the shape and falloff.

| Property | Default | What it does |
| --- | --- | --- |
| texture | null | Gradient texture defining shape and falloff — Godot ships with a default radial one |
| texture\_scale | 1.0 | Scales the texture in world units |
| color | white | Tint of the emitted light |
| energy | 1.0 | Brightness multiplier |
| blend\_mode | ADD | Same ADD / MIX / SUBTRACT modes as DirectionalLight2D |
| range\_height | 0 | Simulated height above the canvas — affects normal-map shading angle |
| shadow\_enabled | false | Enable shadows through LightOccluder2D geometry |

Use when:

you need a point glow — torches, explosions, pickups, muzzle flashes, magic effects.

Performance tip:

shadows are expensive at runtime. Bake static scene lighting as a modulate texture if possible; reserve real-time PointLight2D for dynamic sources only.

#### LightOccluder2D

*inherits Node2D*

Defines geometry that blocks 2D light rays and casts shadows when a Light2D node has `shadow_enabled = true`. Contains an OccluderPolygon2D resource that outlines the silhouette of the shadow caster. Typical use: walls, furniture, columns in a top-down dungeon with dynamic torchlight.

| Property | Default | What it does |
| --- | --- | --- |
| occluder | null | OccluderPolygon2D resource — drawn as a polygon in the inspector |
| sdf\_collision | true | Use signed-distance-field for smoother shadows at angles |
| occluder\_light\_mask | 1 | Bitmask — only Light2D nodes with matching mask bits cast shadows through this occluder |

Use when:

your scene has shadow-casting Light2D and you need geometry to block rays — walls, large props.

Skip when:

purely decorative atmosphere lighting with no shadow requirement; shadows are a significant GPU cost.

## 2D Paths & Follow

#### Path2D

*inherits Node2D*

Holds a Curve2D resource — a smooth Bézier spline drawn in the editor viewport. By itself Path2D is invisible at runtime; it exists purely as data for PathFollow2D (enemy patrol routes, camera rails, conveyor belts) or for procedural geometry (Line2D sampling, particle emitters).

| Property | Default | What it does |
| --- | --- | --- |
| curve | null | Curve2D resource — editable as a spline directly in the viewport |

Use when:

you need a smooth predefined path for movement — enemy patrol, cutscene camera, platform moving along a rail, tutorial arrow swooping.

Tip:

right-click control points in the viewport to toggle between smooth, sharp, and mirrored handles.

#### PathFollow2D

*inherits Node2D*

Child of Path2D that slides along the parent's curve as you advance its `progress` property (0.0 = start, path length = end, or use `progress_ratio` for 0–1 normalised). The node's position and optionally rotation update automatically. Attach your sprite, enemy, or bullet as a child and animate progress with a Tween or in `_process`.

| Property | Default | What it does |
| --- | --- | --- |
| progress | 0.0 | Distance along the curve in pixels from the start point |
| progress\_ratio | 0.0 | Normalised 0–1 version of progress — easier for animation |
| h\_offset / v\_offset | 0 / 0 | Lateral/perpendicular offset from the curve centre line |
| rotate | true | Automatically orient the node to the curve's tangent direction |
| loop | true | Wrap progress back to 0 when it reaches the end |
| rotates | true | Rotate the node to face along the curve as it advances; turn off to keep a fixed orientation |

Use when:

enemy patrols, conveyor belts, platform lifts along a curve, projectile arcs, tutorial pointer swoops.

Pattern:

$PathFollow2D.progress += speed \* delta

in

\_process

for constant-speed movement.

## 2D Skeletal Animation

#### Skeleton2D

*inherits Node2D*

Root node for a 2D skeletal rig. Contains Bone2D children arranged in a hierarchy. Skeleton2D manages the skeleton's rest pose and applies bone transforms to deform polygon meshes (Polygon2D with skeleton weights) for character animation without a sprite sheet.

| Property | Default | What it does |
| --- | --- | --- |
| (no critical inspector props) | — | Control comes entirely from Bone2D children and AnimationPlayer tracks targeting their position/rotation |

Use when:

building a 2D character rig with deformable body parts — RPG characters, cut-out animation style, limb-based creatures.

Simpler alternative:

AnimatedSprite2D with a traditional sprite sheet is far easier to set up; use Skeleton2D only when you need smooth mesh deformation or procedural IK.

#### Bone2D

*inherits Node2D*

A single bone in a Skeleton2D rig. Bones are just Node2D with a rest pose stored and a visual length for the editor handle. You parent bones to each other to create limb chains (upper arm → forearm → hand). AnimationPlayer can then keyframe each bone's rotation to produce fluid character motion.

| Property | Default | What it does |
| --- | --- | --- |
| rest | Transform2D(0, 0, 0, 0, 0, 0) | Transform stored as the neutral/rest pose; used as reference when blending animations |
| length | 16 px | Visual display length in the editor — no runtime effect |

Use when:

you are building a Skeleton2D character rig. Each bone represents one segment of a limb or the torso/head.

Naming tip:

name bones descriptively (`UpperArm_L`, `Forearm_L`) — AnimationPlayer tracks reference them by node path.

## 2D Helpers & Utility

#### Timer

*inherits Node*

A countdown timer that emits a `timeout` signal when it reaches zero. Timer is one of the most frequently used utility nodes in any Godot project — used for ability cooldowns, enemy AI pause intervals, respawn delays, UI flash effects, and rate-limited random spawning. It can run once or loop automatically.

| Property | Default | What it does |
| --- | --- | --- |
| wait\_time | 1.0 s | Duration of each countdown cycle |
| autostart | false | Start the timer automatically when the node enters the scene tree |
| one\_shot | false | Stop after the first timeout (true) or loop indefinitely (false) |
| paused | false | Pause/resume the countdown without resetting it |
| time\_left | read-only | Seconds remaining in the current countdown |

Pattern:

```gdscript
@onready var _cooldown := $Timer
func _ready():
    _cooldown.wait_time = 2.0
    _cooldown.one_shot  = true
    _cooldown.timeout.connect(_on_cooldown_done)

func shoot():
    if _cooldown.is_stopped():
        spawn_bullet()
        _cooldown.start()

func _on_cooldown_done():
    pass  # ready to fire again
```

Prefer await when:

you only need a single delay inline inside an async function:

await get\_tree().create\_timer(2.0).timeout

— no node needed.

#### Marker2D

*inherits Node2D*

An invisible node with a position, rotation, and scale — a named point in 2D space. Used as spawn points, bullet origins, waypoints, enemy patrol anchors, and effect attachment points. Has a cross-hair gizmo visible in the editor but no runtime rendering cost.

| Property | Default | What it does |
| --- | --- | --- |
| gizmo\_extents | 10 | Size of the editor cross-hair — no effect at runtime |

Use when:

you need a named position — muzzle point for a gun, spawn point on a spawner, waypoints for an enemy patrol, camera focus target.

Access in code:

var spawn := $SpawnPoint as Marker2D; enemy.global\_position = spawn.global\_position

#### RemoteTransform2D

*inherits Node2D*

Copies its own global transform to another node each frame, without that target needing to be a child. Allows a node elsewhere in the tree (a Camera2D on a different canvas layer, a shadow sprite) to follow a character's position while remaining structurally independent. Configure which axes and components to copy.

| Property | Default | What it does |
| --- | --- | --- |
| remote\_path | empty | NodePath to the target node that will receive the copied transform |
| use\_global\_coordinates | true | Copy global transform (true) or local transform (false) |
| update\_position | true | Copy position component |
| update\_rotation | true | Copy rotation component |
| update\_scale | true | Copy scale component |

Use when:

a node needs to follow another without parent–child coupling — shadow decal that tracks a player, camera follow marker, UI element anchored to a world-space object.

Simpler alternative:

just parent the follower node directly if the structural coupling is acceptable.

#### VisibleOnScreenNotifier2D

*inherits Node2D*

Emits `screen_entered` and `screen_exited` signals based on whether its bounding rectangle is visible in the current camera viewport. Useful for triggering effects only when the player can actually see them, or for culling off-screen enemies.

| Property | Default | What it does |
| --- | --- | --- |
| rect | Rect2(-10,-10,20,20) | The local rectangle checked for visibility — expand to cover the parent sprite's actual size |

Use when:

you want to know when an object enters or leaves the camera view — start an animation only when visible, disable off-screen AI, trigger ambience sounds.

Prefer VisibleOnScreenEnabler2D when:

you want automatic node disable/enable on visibility rather than just a signal.

#### VisibleOnScreenEnabler2D

*inherits VisibleOnScreenNotifier2D → Node2D*

Like VisibleOnScreenNotifier2D but automatically enables or disables target nodes based on screen visibility — no code needed. Can freeze an AnimationPlayer, disable a physics process, or pause a particle emitter when off-screen, saving CPU/GPU for entities the player cannot see.

| Property | Default | What it does |
| --- | --- | --- |
| enable\_mode | INHERIT | ALWAYS: enable the target whenever visible; WHEN\_PAUSED: only when SceneTree is paused |
| enable\_node\_path | ".." | Node to enable/disable — defaults to parent |

Use when:

you have many off-screen enemies or effects whose processing you want to pause cheaply without any GDScript.

Pattern:

place as a child of the enemy, set rect to match its sprite, leave enable\_node\_path as

".."

.

## Parallax Scrolling

#### Parallax2D

*inherits Node2D*

Godot 4.3+ replacement for ParallaxBackground+ParallaxLayer. A single node that gives any child a parallax scroll factor relative to the camera, with optional infinite tiling. Simplifies multi-layer scrolling backgrounds dramatically — just add one Parallax2D per background layer and set its scroll factor.

| Property | Default | What it does |
| --- | --- | --- |
| scroll\_scale | Vector2(1,1) | Fraction of camera movement this layer follows. (0,0)=fixed; (1,1)=moves with camera; (0.2,0)=slow horizontal scroll |
| scroll\_offset | Vector2(0,0) | Additional constant offset — useful for initial positioning |
| repeat\_size | Vector2(0,0) | Tile the layer; (0,0) disables tiling. Set to the width of your background texture for seamless repeat |
| autoscroll | Vector2(0,0) | Automatically scrolls the layer at this px/s speed — for animated moving clouds etc. |
| limit\_begin / limit\_end | Vector2(-1e7,-1e7) / (+1e7,+1e7) | Clamp the layer position so it doesn't scroll past the level edges |

Use when:

building a multi-layer scrolling background — sky, distant mountains, mid-ground trees, near-ground bushes.

Layer order:

lower scroll\_scale = further away. Place further layers lower in the scene tree (drawn first).

Legacy note:

for Godot < 4.3 use the ParallaxBackground + ParallaxLayer pair described below.

#### ParallaxBackground

*inherits CanvasLayer → Node*

The older (pre-4.3) parallax system container. Must be a parent of ParallaxLayer children. Reads the current Camera2D scroll and passes it to children. Each ParallaxLayer applies a fraction of that scroll. Still fully functional in Godot 4 — use Parallax2D for new projects, but you'll encounter this in older tutorials and assets.

| Property | Default | What it does |
| --- | --- | --- |
| scroll\_offset | Vector2(0,0) | Manual scroll override — normally left at (0,0) and driven by camera |
| scroll\_base\_offset | Vector2(0,0) | Base offset applied before layer factors |
| scroll\_base\_scale | Vector2(1,1) | Global scale multiplier for all child layers |
| limit\_begin / limit\_end | Vector2(-1e7,-1e7) / (+1e7) | Scroll clamping |

Use when:

working in a project on Godot < 4.3, or following an older tutorial.

Prefer Parallax2D

for all new Godot 4.3+ projects.

## 3D Physics Bodies

#### StaticBody3D

*inherits PhysicsBody3D → CollisionObject3D → Node3D*

A 3D physics body that never moves under physics simulation — perfect for floors, walls, ramps, immovable platforms, and level geometry. Requires a CollisionShape3D child to define its collision volume. Can have surface properties (friction, bounce) via a PhysicsMaterial.

| Property | Default | What it does |
| --- | --- | --- |
| physics\_material\_override | null | PhysicsMaterial defining friction and bounce for this surface |
| constant\_linear\_velocity | Vector3(0,0,0) | Moves touching bodies (conveyor belt effect) without moving the static body itself |
| constant\_angular\_velocity | Vector3(0,0,0) | Spins touching bodies (spinning platform) without self-rotation |

Use when:

terrain, walls, floors, immovable obstacles — anything that never needs to move under physics forces.

Prefer AnimatableBody3D when:

you need to move the body via animation or code but still want it to push/block RigidBody3D.

#### AnimatableBody3D

*inherits StaticBody3D → PhysicsBody3D → Node3D*

A static body that can be moved by the engine (via AnimationPlayer or Tween) and will physically push RigidBody3D objects out of the way as it moves. Use for moving platforms, doors, elevators, and any obstacle that animates but should block and carry the player.

| Property | Default | What it does |
| --- | --- | --- |
| sync\_to\_physics | true | Sync movement to the physics step for correct collision response — leave on for moving platforms |

Use when:

moving platforms, sliding doors, rotating obstacles that need to push physics bodies.

Prefer StaticBody3D when:

the body never moves.

#### CharacterBody3D

*inherits PhysicsBody3D → CollisionObject3D → Node3D*

The standard node for player characters and enemies in 3D. You control movement completely through code using `move_and_slide()` — the engine handles collision detection and sliding along surfaces. Provides helpers for floor detection, stair stepping, and slope limits. Unlike RigidBody3D it never moves automatically; every frame of motion is authored in GDScript.

| Property | Default | What it does |
| --- | --- | --- |
| motion\_mode | GROUNDED | GROUNDED: distinguishes floor/wall/ceiling; FLOATING: all normals treated equally (for swimming/flying) |
| up\_direction | Vector3(0,1,0) | Which direction is "up" for floor/ceiling detection |
| floor\_max\_angle | 0.785 rad (45°) | Maximum slope considered walkable floor; steeper = wall |
| floor\_snap\_length | 0.1 | Snap to floor threshold — prevents floating on ramp edges |
| velocity | Vector3(0,0,0) | The velocity applied each physics frame by move\_and\_slide() |

Use when:

player characters, NPCs, enemies — any entity where you author movement logic.

Pattern:

```gdscript
const SPEED = 5.0
const GRAVITY = -9.8
const JUMP_VELOCITY = 4.5

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += GRAVITY * delta
    if Input.is_action_just_pressed("ui_accept") and is_on_floor():
        velocity.y = JUMP_VELOCITY
    var dir := Input.get_vector("left","right","forward","back")
    velocity.x = dir.x * SPEED
    velocity.z = dir.y * SPEED
    move_and_slide()
```

#### RigidBody3D

*inherits PhysicsBody3D → CollisionObject3D → Node3D*

A fully simulated 3D physics body — gravity, friction, torque, and impulses are all handled by the physics engine. Perfect for crates, balls, barrels, ragdolls, and any object that should tumble, stack, and collide realistically without manual velocity code. Apply forces with `apply_impulse()` or `apply_force()`.

| Property | Default | What it does |
| --- | --- | --- |
| mass | 1.0 kg | Affects momentum and impulse response |
| gravity\_scale | 1.0 | Multiplier on global gravity — 0 = weightless, negative = floats up |
| freeze | false | Halt all physics simulation without removing from tree |
| freeze\_mode | STATIC | STATIC: acts like StaticBody while frozen; KINEMATIC: can still be moved by code |
| linear\_damp / angular\_damp | -1 / -1 | Velocity damping (-1 = use project default) |
| lock\_rotation | false | Prevent angular movement — useful for top-down 2.5D crates that shouldn't spin |
| can\_sleep | true | Allow physics engine to stop simulating this body when it's at rest — saves CPU |

Use when:

props, debris, ragdolls, throwable objects — anything that should react to physics naturally.

Prefer CharacterBody3D when:

the entity needs authored movement logic (player, enemy AI).

#### Area3D

*inherits CollisionObject3D → Node3D*

A 3D detection volume — no physics mass or forces, just overlap detection. Emits `body_entered`, `body_exited`, `area_entered`, and `area_exited` signals. Also controls physics and audio override properties for bodies inside it (custom gravity, damping, reverb). Essential for pickups, triggers, damage zones, water volumes, and wind fields.

| Property | Default | What it does |
| --- | --- | --- |
| monitoring | true | Whether this area detects overlapping bodies/areas |
| monitorable | true | Whether this area can be detected by other Area3D nodes |
| gravity\_space\_override | DISABLED | Override gravity for bodies inside — REPLACE, COMBINE, COMBINE\_REPLACE modes |
| gravity | 9.8 | Gravity magnitude when override is active |
| linear\_damp\_space\_override | DISABLED | Override linear damping for bodies inside — useful for water, mud zones |
| audio\_bus\_name | "Master" | Override which audio bus plays for sounds inside this area — reverb zones |

Use when:

pickup zones, damage triggers, water volumes, wind areas, checkpoint regions, audio reverb zones.

Remember:

connect

body\_entered

in the inspector —

func \_on\_body\_entered(body: Node3D) -> void

.

#### CollisionShape3D

*inherits Node3D*

Every physics body (StaticBody3D, CharacterBody3D, RigidBody3D, Area3D) needs at least one CollisionShape3D child to have a physical presence. It holds a Shape3D resource (BoxShape3D, SphereShape3D, CapsuleShape3D, CylinderShape3D, ConvexPolygonShape3D, ConcavePolygonShape3D) that defines the collision volume. The shape does not need to match the visual mesh exactly — simpler shapes are faster.

| Property | Default | What it does |
| --- | --- | --- |
| shape | null | Shape3D resource — create inline in the inspector or reuse a shared resource |
| disabled | false | Temporarily exclude this shape from collision without removing it |
| debug\_color | auto | Colour of the shape visualisation in editor/debug builds |

Shape selection guide:

BoxShape3D — buildings, crates, platforms.

CapsuleShape3D — humanoid characters (slides on edges smoothly).

SphereShape3D — balls, simple rolling objects.

ConvexPolygonShape3D — convex props (barrels, rocks) — faster than concave.

ConcavePolygonShape3D — complex static terrain/meshes — only on StaticBody3D, too expensive for moving bodies.

#### RayCast3D

*inherits Node3D*

Casts a ray from its origin in `target_position` direction every physics frame and reports what it hits. Query results with `is_colliding()`, `get_collider()`, `get_collision_point()`, and `get_collision_normal()`. Useful for weapon hit-scan, line-of-sight checks, ground detection, and surface snapping.

| Property | Default | What it does |
| --- | --- | --- |
| enabled | true | Active casting; disable when not needed to save physics overhead |
| target\_position | Vector3(0,-1,0) | End point of the ray in local space |
| collision\_mask | 1 | Layer bitmask — only layers included here are tested |
| hit\_from\_inside | false | Report hit even if ray starts inside a shape |
| exclude\_parent | true | Ignore the parent physics body — almost always leave on |

Use when:

hitscan weapons, ground-normal detection, ledge grab detection, line-of-sight AI checks.

For one-off queries:

PhysicsRayQueryParameters3D

+

get\_world\_3d().direct\_space\_state.intersect\_ray()

— no persistent node needed.

#### VehicleBody3D

*inherits RigidBody3D → PhysicsBody3D → Node3D*

A specialised RigidBody3D with a built-in vehicle physics model — steering, acceleration, braking, and suspension simulation. Requires VehicleWheel3D children positioned at each wheel. Provides arcade-to-simulation quality physics without a physics plugin.

| Property | Default | What it does |
| --- | --- | --- |
| engine\_force | 0.0 | Forward drive force applied each physics frame — set this in \_physics\_process |
| brake | 0.0 | Brake force — 0 to 1+ range |
| steering | 0.0 | Steer angle in radians — set on front wheels via VehicleWheel3D.steering property too |

Use when:

racing games, vehicle driving mechanics — any car, truck, or wheeled vehicle needing suspension and traction simulation.

Setup:

VehicleBody3D → (children) VehicleWheel3D × 4 + MeshInstance3D (body) + CollisionShape3D.

## 3D Visual Nodes

#### MeshInstance3D

*inherits GeometryInstance3D → VisualInstance3D → Node3D*

The workhorse 3D visual node — renders a Mesh resource (imported .glb, .fbx, PrimitiveMesh, ArrayMesh) with one or more materials. Everything visible in a 3D scene is almost certainly a MeshInstance3D. Supports LOD, visibility ranges, per-instance material overrides, and lightmap UV.

| Property | Default | What it does |
| --- | --- | --- |
| mesh | null | The Mesh resource to render — drag from FileSystem or create inline |
| material\_override | null | Override all mesh surface materials with a single material |
| skeleton | NodePath("") | Path to a Skeleton3D for mesh skinning |
| lod\_min\_distance / lod\_max\_distance | 0 / 0 | Distance range for automatic LOD switching (0 = disabled) |
| visibility\_range\_begin / end | 0.0 / 0.0 | Cull the mesh outside this camera distance range (0 = no limit) |
| cast\_shadow | ON | ON / OFF / DOUBLE\_SIDED / SHADOWS\_ONLY |

Use when:

rendering any 3D object — character, prop, terrain chunk, vehicle body, architectural element.

Tip:

use

set\_surface\_override\_material(surface\_idx, mat)

in code to swap materials at runtime.

#### MultiMeshInstance3D

*inherits GeometryInstance3D → VisualInstance3D → Node3D*

Renders thousands of instances of a single mesh in one draw call using GPU instancing. Each instance can have its own transform, color, and custom data, but shares the same mesh and material. Essential for foliage (grass, trees), crowd systems, bullet trails, or any repetitive geometry at scale.

| Property | Default | What it does |
| --- | --- | --- |
| multimesh | null | MultiMesh resource containing per-instance data and the shared mesh |

Use when:

you need hundreds or thousands of the same object — grass blades, tree canopy leaves, rock scatter, bullet casings, crowd NPCs.

Performance:

one draw call regardless of instance count — dramatically cheaper than individual MeshInstance3D nodes.

Pattern:

set `multimesh.instance_count`, then call

multimesh.set\_instance\_transform(i, transform)

in a loop.

#### Sprite3D

*inherits SpriteBase3D → GeometryInstance3D → Node3D*

A 2D texture rendered as a flat quad in 3D space. Can billboard to always face the camera. Used for particle-style effects, health bars floating over enemies, icons, impostor trees, and any "flat image in 3D world" effect.

| Property | Default | What it does |
| --- | --- | --- |
| texture | null | The 2D texture to display |
| billboard | DISABLED | DISABLED / ENABLED (always face camera) / FIXED\_Y (Y-axis locked billboard) |
| pixel\_size | 0.01 | World units per pixel — controls physical size |
| axis | Z | Which axis the sprite faces by default |
| double\_sided | true | Render the back face too |
| region\_enabled | false | Use a sub-region of the texture (like Sprite2D) |

Use when:

floating UI labels, simple billboard trees/grass, icon indicators above characters, 2.5D games mixing sprites in 3D space.

#### Label3D

*inherits SpriteBase3D → GeometryInstance3D → Node3D*

Renders a text string as a flat quad in 3D world space, supporting font, size, wrapping, and billboard modes. Ideal for in-world name tags, damage numbers, interactive object labels, and subtitle-style world-space text.

| Property | Default | What it does |
| --- | --- | --- |
| text | "" | The string to render — supports newlines |
| font | null (default) | FontFile resource — leave null for the engine default |
| font\_size | 32 px | Render resolution of the text texture |
| pixel\_size | 0.005 | World units per pixel (same as Sprite3D) |
| billboard | DISABLED | Same billboard modes as Sprite3D |
| modulate | white | Tint colour |
| outline\_size | 12 | Pixel-width outline for legibility |

Use when:

floating enemy names, damage numbers, tutorial hints in world space, NPC speech in-world.

Tip:

enable billboard + fixed\_y so text always faces the player without tilting on slopes.

#### AnimatedSprite3D

*inherits SpriteBase3D → GeometryInstance3D → Node3D*

Like AnimatedSprite2D but in 3D space — cycles through frames of a SpriteFrames resource to produce billboard-style 2D animations in the 3D world. Classic "doom-style" sprite enemy, animated icon, hit-effect decal.

| Property | Default | What it does |
| --- | --- | --- |
| sprite\_frames | null | SpriteFrames resource with named animation clips |
| animation | "default" | Active animation name |
| autoplay | "" | Animation to start automatically on scene load |
| billboard | DISABLED | Typically left on so sprites always face the camera |

Use when:

sprite-based enemies or effects in a 3D world (retro FPS style), 2.5D games, animated pickups.

Code:

$AnimatedSprite3D.play("run")

— identical API to AnimatedSprite2D.

## CSG (Constructive Solid Geometry)

#### CSGBox3D / CSGSphere3D / CSGCylinder3D / CSGTorus3D

*inherit CSGPrimitive3D → CSGShape3D → GeometryInstance3D*

Solid 3D primitive shapes that can be combined with Boolean operations (Union, Intersection, Subtraction) to prototype level geometry directly in the editor without importing meshes. Boxes build rooms and walls, spheres and cylinders carve arches and tunnels, toruses create rings and handles. CSG is ideal for greyboxing — replace with proper meshes for shipping.

| Property | Default | What it does |
| --- | --- | --- |
| operation | UNION | UNION: add geometry; INTERSECTION: keep overlap only; SUBTRACTION: carve from parent |
| use\_collision | false | Generate StaticBody3D collision automatically — useful for greybox testing with physics |
| size / radius / height | varies | Dimensions specific to each primitive |
| material | null | Surface material — supports StandardMaterial3D |

Use when:

rapid level prototyping, greyboxing, jam game geometry, editor-only mockups.

Do not ship CSG in production:

CSG generates geometry at runtime and is not performance-optimised. Convert to MeshInstance3D (

Mesh → Bake Mesh

) before final builds.

#### CSGCombiner3D

*inherits CSGShape3D → GeometryInstance3D*

A grouping node for CSG shapes — its children's Boolean operations are evaluated together as one compound shape. Use when you want to build a complex multi-part CSG object (e.g., a room with windows and doors carved out) and then use that compound shape as a unit in a larger scene.

| Property | Default | What it does |
| --- | --- | --- |
| operation | UNION | How this combiner's result is applied to its parent CSG shape |

Use when:

combining multiple CSG primitives into a logical unit before applying them to a parent — building a doorway arch, a window opening, a complex tunnel cross-section.

#### GridMap

*inherits Node3D*

A 3D tile map — places MeshLibrary cells on a regular grid with collision baked in. Think TileMapLayer but in 3D: each cell snaps to a grid and can hold any mesh from the library (wall, floor, corner, pillar). The single most efficient tool for building grid-aligned 3D levels (dungeons, cityscapes, corridors) entirely inside the Godot editor.

| Property | Default | What it does |
| --- | --- | --- |
| mesh\_library | null | MeshLibrary resource containing named cell meshes with collision shapes |
| cell\_size | Vector3(2,2,2) | World-space dimensions of each grid cell |
| cell\_center\_x/y/z | true | Whether placed meshes are centred within their cell |
| collision\_layer / mask | 1 / 1 | Physics layer assignment for baked collision |

Use when:

building grid-aligned 3D environments — dungeons, corridors, city blocks, interior rooms.

Workflow:

create MeshLibrary from existing scene (Scene → Convert To MeshLibrary) → assign to GridMap → paint cells in the viewport with the GridMap panel.

## 3D Lighting

#### DirectionalLight3D

*inherits Light3D → VisualInstance3D → Node3D*

Simulates the sun or moon — parallel rays that hit every surface from the same angle, regardless of distance. Casts cascaded shadow maps across the entire scene. Typically there is exactly one DirectionalLight3D in an outdoor scene representing the primary sun. Rotation controls the angle of the light; position has no effect.

| Property | Default | What it does |
| --- | --- | --- |
| light\_color | white | Colour tint of the emitted light |
| light\_energy | 1.0 | Intensity multiplier |
| shadow\_enabled | false | Enable cascaded shadow maps |
| directional\_shadow\_mode | PARALLEL\_4\_SPLITS | ORTHOGONAL / PARALLEL\_SPLITS(2/4) — more splits = sharper far shadows, higher cost |
| sky\_mode | LIGHT\_AND\_SKY | Whether this light also illuminates the sky shader |

Use when:

outdoor scenes needing a sun/moon. Rotate (not move) to set light angle — golden hour = low rotation on the X axis.

Indoor scenes:

disable or remove; use OmniLight3D / SpotLight3D instead. Multiple DirectionalLights are expensive.

#### OmniLight3D

*inherits Light3D → VisualInstance3D → Node3D*

A point light that radiates equally in all directions from a single position — like a light bulb or torch. The light fades over distance according to an attenuation curve. Used for indoor lamps, campfires, glowing pickups, explosions, and any localised spherical light source.

| Property | Default | What it does |
| --- | --- | --- |
| light\_color | white | Colour tint |
| light\_energy | 1.0 | Brightness — outdoor equivalent sun is typically 64–100 |
| omni\_range | 5.0 | Maximum radius of light influence in world units |
| omni\_attenuation | 1.0 | Falloff curve shape — higher = sharper cutoff at range edge |
| shadow\_enabled | false | Cast cubemap shadows — expensive; limit to 1-2 dynamic omni shadow casters |

Use when:

indoor ceiling lights, torches, campfires, glowing objects, explosion flashes.

Performance:

shadows from OmniLight3D use cubemap rendering (6 passes) — bake static scene lighting with LightmapGI where possible.

#### SpotLight3D

*inherits Light3D → VisualInstance3D → Node3D*

A cone-shaped light emanating from a point in a direction — like a flashlight, stage spotlight, or car headlight. Defined by an inner and outer cone angle; illumination fades from full intensity inside the inner cone to zero at the outer edge. Supports shadow mapping within the cone frustum.

| Property | Default | What it does |
| --- | --- | --- |
| spot\_range | 5.0 | Maximum distance the cone reaches |
| spot\_angle | 45° | Half-angle of the outer cone — total cone width = 2 × spot\_angle |
| spot\_angle\_attenuation | 1.0 | How fast intensity drops from inner to outer cone edge |
| spot\_attenuation | 1.0 | Falloff curve over the spot\_range distance |
| shadow\_enabled | false | Cast a shadow map within the cone — cheaper than OmniLight3D shadows |

Use when:

flashlights, car headlights, stage spotlights, security camera beams, dungeon corridor torches mounted on walls.

Attach to camera:

parent a SpotLight3D to the player's Camera3D for a first-person flashlight.

#### LightmapGI

*inherits VisualInstance3D → Node3D*

Bakes static global illumination (GI), indirect lighting, and shadows from all static lights and emissive surfaces into lightmap textures. At runtime the baked data is sampled — zero GPU lighting cost for static geometry. The single most effective tool for making indoor 3D scenes look photorealistic at low runtime cost.

| Property | Default | What it does |
| --- | --- | --- |
| quality | MEDIUM | Bake quality — LOW for iteration, HIGH/ULTRA for shipping |
| bounces | 3 | Number of light bounce passes — more = more realistic indirect light |
| use\_denoiser | true | Apply AI denoiser to smooth baked texture noise |
| environment\_mode | SCENE | Include WorldEnvironment sky in bake (SCENE) or custom sky colour |
| texel\_scale | 1.0 | Lightmap resolution scale — 2.0 = twice as many texels, 4× memory |

Use when:

any static 3D scene that needs good-looking lighting without real-time cost — indoor environments, cutscene sets, fixed outdoor scenes.

Bake workflow:

mark all static MeshInstance3D nodes as "Bake Mode: Static" → Bake Lightmaps button in LightmapGI inspector.

## 3D Environment & Post-FX

#### WorldEnvironment

*inherits Node*

Applies a global Environment resource to the entire 3D scene — sky, ambient light, tone mapping, SSAO, SSIL, glow, fog, DOF blur, and more. Exactly one WorldEnvironment per scene tree. The Environment resource (assigned in the inspector) contains all the settings; WorldEnvironment just tells Godot "use this Environment globally."

| Property | Default | What it does |
| --- | --- | --- |
| environment | null | Environment resource — create new or load an existing .tres |
| camera\_attributes | null | CameraAttributesPractical / CameraAttributesPhysical for DOF, exposure, auto-exposure |

Use when:

setting up the sky, ambient colour, post-processing effects, and global fog for any 3D scene.

Key Environment settings to know:

Background (sky/colour/panorama), Ambient Light (colour + energy), Glow (enable + bloom threshold), SSAO (screen-space ambient occlusion), Fog (enable + density + colour), Tone Map (Filmic / ACES).

#### ReflectionProbe

*inherits VisualInstance3D → Node3D*

Captures a cubemap of the scene from its position and makes it available to nearby materials as a local reflection source. Objects with metallic or specular materials inside the probe's extents will reflect the cubemap rather than the sky. Can bake static captures or update dynamically (at significant GPU cost).

| Property | Default | What it does |
| --- | --- | --- |
| update\_mode | ONCE | ONCE: bake on scene load (static); ALWAYS: re-render every frame (expensive) |
| extents | Vector3(10,10,10) | Volume within which materials use this probe's reflection |
| intensity | 1.0 | Reflection brightness multiplier |
| ambient\_mode | ENVIRONMENT | Also use this probe as a local ambient light source |
| enable\_shadows | false | Render shadows in the cubemap capture |
| interior | false | Ignore sky in capture — for enclosed indoor spaces |

Use when:

shiny floors, glossy car paint, metallic props in a specific room — wherever you need localised reflections that don't look like the global sky.

Interior mode:

always enable for enclosed rooms to prevent sky bleed-through.

#### Decal

*inherits VisualInstance3D → Node3D*

Projects textures onto surfaces within a box volume — bullet holes, blood splats, paint marks, puddle reflections, grunge overlays. The texture wraps onto any geometry inside the Decal's extents, conforming to the surface normal. Supports albedo, normal, ORM (occlusion/roughness/metallic), and emission textures.

| Property | Default | What it does |
| --- | --- | --- |
| texture\_albedo | null | Colour/alpha texture projected onto surfaces |
| texture\_normal | null | Normal map decal — for dent/scratch details |
| texture\_emission | null | Emissive decal — for glowing graffiti, paint, neon stickers |
| extents | Vector3(1,1,1) | Size of the projection volume |
| emission\_energy | 1.0 | Emissive texture brightness |
| upper\_fade / lower\_fade | 0.3 / 0.3 | Fade distance at top and bottom of extents to avoid hard edges |

Use when:

bullet holes, decals, stickers, grunge overlays, wet floor puddle maps, tyre marks — any surface detail that should conform to geometry without modifying the mesh.

#### FogVolume

*inherits VisualInstance3D → Node3D*

Applies volumetric fog within a defined shape — a box, sphere, ellipsoid, cone, or full scene. Unlike the global fog in WorldEnvironment, FogVolume allows localised fog effects: a misty forest floor, a smoky corridor, a magical portal haze. Requires Volumetric Fog to be enabled in the Environment resource.

| Property | Default | What it does |
| --- | --- | --- |
| extents | Vector3(1,1,1) | Size of the volume (for BOX/ELLIPSOID shapes) |
| shape | BOX | BOX / ELLIPSOID / CONE / CYLINDER / WORLD (fills entire scene) |
| material | null | FogMaterial resource defining density, albedo, emission, scatter colour |

Use when:

localised volumetric atmosphere — mist patches, smoke zones, magical volumes, underwater visibility falloff.

Prerequisite:

enable Volumetric Fog in Environment → Volumetric Fog section first.

## 3D Helpers & Utility

#### Marker3D

*inherits Node3D*

The 3D equivalent of Marker2D — a named position+rotation+scale in 3D space with a visible axes gizmo in the editor but zero runtime cost. Used as spawn points, weapon muzzle attachments, camera targets, look-at anchors, path waypoints, and any "here is a named transform" use case.

| Property | Default | What it does |
| --- | --- | --- |
| gizmo\_extents | 0.25 | Size of the axes gizmo displayed in the editor |

Use when:

bullet spawn point on a gun mesh, camera target anchor for a crane shot, enemy patrol waypoints, cutscene look-at targets.

Pattern:

bullet.global\_transform = $MuzzlePoint.global\_transform

#### RemoteTransform3D

*inherits Node3D*

Copies its global transform to any other node in the scene tree each physics frame, without parenting. Identical concept to RemoteTransform2D. Useful for attaching a Camera3D or HUD element to a character bone position while keeping them structurally separate in the scene tree.

| Property | Default | What it does |
| --- | --- | --- |
| remote\_path | empty | NodePath to the target node |
| use\_global\_coordinates | true | Copy global (true) or local (false) transform |
| update\_position / rotation / scale | true / true / true | Toggle which transform components are copied |

Use when:

driving a Camera3D from a BoneAttachment3D without parenting the camera into the character skeleton; syncing a shadow caster decal to a world-space position.

#### SpringArm3D

*inherits Node3D*

A "spring arm" that pushes its end point (where a camera typically sits) toward the parent when the arm is blocked by geometry, and springs back to full length when unobstructed. The standard solution for third-person cameras that shouldn't clip through walls — no custom ray-cast code needed.

| Property | Default | What it does |
| --- | --- | --- |
| spring\_length | 1.0 | Maximum arm length — camera rests here when nothing blocks it |
| collision\_mask | 1 | Layer bitmask — which physics layers can push the arm |
| margin | 0.01 | Extra clearance kept between camera and the blocking surface |
| shape | null | Optional Shape3D for swept collision (sphere sweep) — more reliable than ray |

Standard 3rd-person camera rig:

CharacterBody3D → Node3D (pivot/yaw) → SpringArm3D → Camera3D.

Rotate the pivot for horizontal look; the spring handles wall clipping automatically.

#### Skeleton3D

*inherits Node3D*

The root of a 3D skeletal rig imported from .glb/.fbx. Manages all bones (stored internally, not as child nodes), applies AnimationPlayer bone tracks, and drives mesh skinning on sibling MeshInstance3D nodes. You rarely create Skeleton3D manually — it arrives with your imported character. Exposes bone transforms for IK and procedural animation.

| Property | Default | What it does |
| --- | --- | --- |
| show\_rest\_only | false | Display rest pose in editor (ignores animation preview) |
| modifier\_callback\_mode\_process | IDLE | When SkeletonModifier3D callbacks run — IDLE or PHYSICS |

Use when:

working with imported animated characters. Key API calls:

skeleton.get\_bone\_global\_pose(bone\_idx)

— read a bone's world transform.

skeleton.set\_bone\_pose\_rotation(idx, quat)

— procedurally rotate a bone.

skeleton.find\_bone("Head")

— get bone index by name.

#### BoneAttachment3D

*inherits Node3D*

Follows a specific bone in a Skeleton3D parent, updating its transform to match that bone's world position every frame. Use to attach props, weapons, or accessories directly to a skeleton bone — a sword in the right hand, a hat on the head, a shield on the forearm.

| Property | Default | What it does |
| --- | --- | --- |
| bone\_name | "" | Name of the bone to follow — pick from dropdown in inspector |
| bone\_idx | -1 | Index of the target bone (auto-set when bone\_name is chosen) |
| override\_pose | false | If true, this node's transform drives the bone instead of following it (for IK) |

Use when:

attaching equipment to a character skeleton — sword in hand, hat on head, shield on forearm, particle emitter on a wingtip.

Setup:

make BoneAttachment3D a child of Skeleton3D → set bone\_name → add your prop as a child of BoneAttachment3D.

## 3D Paths & Follow

#### Path3D

*inherits Node3D*

Holds a Curve3D resource — a smooth 3D Bézier spline editable directly in the viewport. The 3D analogue of Path2D. Used for roller-coaster rails, drone flight paths, animated camera dolly shots, road/track layout, and rope/tube procedural geometry.

| Property | Default | What it does |
| --- | --- | --- |
| curve | null | Curve3D resource — edit control points in the 3D viewport |

Use when:

enemy patrol route in 3D, camera dolly track, roller coaster, procedural tube/pipe mesh sampled from a spline.

API:

curve.sample\_baked(offset)

returns a Vector3 at a point along the path.

#### PathFollow3D

*inherits Node3D*

Child of Path3D — slides along the parent 3D curve as its `progress` or `progress_ratio` changes, exactly like the 2D version. Can orient to the curve's tangent, bank on turns, and loop. Attach a Camera3D as a child for a smooth dolly shot, or attach an enemy mesh for a scripted patrol route.

| Property | Default | What it does |
| --- | --- | --- |
| progress | 0.0 | Distance along the curve from start |
| progress\_ratio | 0.0 | Normalised 0–1 version |
| rotation\_mode | XYZ | How rotation is derived from the curve tangent — NONE, XYZ, Y, Euler XYZ, Oriented |
| loop | true | Wrap progress at end back to 0 |
| tilt\_enabled | true | Apply control-point tilt (banking on curves) |

Use when:

scripted camera dolly, enemy on a predefined 3D route, roller coaster car, animated cutscene object.

Cinematic pattern:

Path3D → PathFollow3D (rotation\_mode = Oriented) → Camera3D. Drive progress\_ratio with AnimationPlayer.

## UI — Additional Control Nodes

#### Panel

*inherits Control → CanvasItem → Node*

A simple rectangular UI background that renders a StyleBox (solid colour, rounded rectangle, gradient, or NinePatch texture). The go-to container for inventory slots, dialogue boxes, HUD frames, and any opaque/semi-transparent UI background region. Has no layout logic of its own — combine with VBoxContainer/HBoxContainer children for structured content.

| Property | Default | What it does |
| --- | --- | --- |
| theme\_override\_styles/panel | StyleBoxFlat | Override the panel's background StyleBox — change colour, border, corner radius |

Use when:

any UI background area — inventory window, tooltip backdrop, HUD status bar frame, modal dialogue background.

#### TextureRect

*inherits Control → CanvasItem → Node*

Displays a Texture2D inside a Control rect with configurable stretch/tile/keep-aspect modes. Used for image-heavy UIs — item icons in inventory slots, portrait art in dialogue boxes, minimap images, decorative UI art.

| Property | Default | What it does |
| --- | --- | --- |
| texture | null | Texture2D to display |
| expand\_mode | KEEP\_SIZE | KEEP\_SIZE / IGNORE\_SIZE / FIT\_WIDTH / FIT\_HEIGHT / FIT\_WIDTH\_PROPORTIONAL / FIT\_HEIGHT\_PROPORTIONAL |
| stretch\_mode | SCALE | SCALE / TILE / KEEP / KEEP\_CENTERED / KEEP\_ASPECT / KEEP\_ASPECT\_CENTERED / KEEP\_ASPECT\_COVERED |
| flip\_h / flip\_v | false / false | Mirror horizontally or vertically |

Use when:

item icons, character portraits, background art images, minimap textures in UI.

Common combo:

TextureRect inside a Panel with aspect\_ratio = KEEP\_ASPECT\_CENTERED for item slot thumbnails.

#### ColorRect

*inherits Control → CanvasItem → Node*

The simplest UI node — a solid colour filled rectangle. Lighter than Panel (no StyleBox overhead). Used for loading screen fades, health bar fill, fullscreen colour overlays, and simple geometric UI shapes.

| Property | Default | What it does |
| --- | --- | --- |
| color | Color(1,1,1,1) | Fill colour including alpha |

Use when:

screen fade-to-black overlay (modulate alpha via Tween), simple filled progress bar, solid background behind another Control.

Fade pattern:

tween.tween\_property($FadeRect, "modulate:a", 1.0, 0.5)

#### LineEdit

*inherits Control → CanvasItem → Node*

A single-line text input field with built-in cursor, selection, copy/paste, and placeholder text. Emits `text_changed(text)` every keystroke and `text_submitted(text)` when Enter is pressed. Used for name entry fields, search boxes, chat input, numeric entry with validation.

| Property | Default | What it does |
| --- | --- | --- |
| text | "" | Current string value — readable and settable |
| placeholder\_text | "" | Greyed hint text shown when field is empty |
| max\_length | 0 (unlimited) | Character limit |
| secret | false | Password mode — displays bullets instead of characters |
| editable | true | Allow user input (false = display-only) |
| virtual\_keyboard\_enabled | true | Show on-screen keyboard on mobile |

Use when:

player name entry, search box, chat input, save slot naming.

For multi-line text entry

use TextEdit instead.

#### TextEdit

*inherits Control → CanvasItem → Node*

Multi-line text input with word wrap, line numbers, syntax highlighting hooks, and full selection/edit support. Used for in-game note-taking, console windows, code editors within games, long-form text input. Less common than LineEdit but essential for multi-line scenarios.

| Property | Default | What it does |
| --- | --- | --- |
| text | "" | Full multi-line string content |
| placeholder\_text | "" | Hint shown when empty |
| editable | true | Allow editing |
| wrap\_mode | NONE | NONE / BOUNDARY (word wrap) |
| syntax\_highlighter | null | SyntaxHighlighter resource for custom code colouring |

Use when:

in-game journal, console output display, multi-line player note-taking, command-line tool interfaces in-game.

#### HSlider / VSlider

*inherit Slider → Range → Control*

Horizontal and vertical slider controls for selecting a numeric value within a range by dragging a handle. Emit `value_changed(value)`. The standard control for audio volume, brightness, sensitivity sliders in options menus. Inherit from Range so they share API with ProgressBar and SpinBox.

| Property | Default | What it does |
| --- | --- | --- |
| min\_value | 0.0 | Minimum selectable value |
| max\_value | 100.0 | Maximum selectable value |
| step | 1.0 | Increment — set to 0 for continuous float range |
| value | 0.0 | Current value — readable and settable |
| tick\_count | 0 | Number of tick marks drawn on the track (0 = none) |

Use when:

options menu sliders for audio volume, music volume, gamma, mouse sensitivity, difficulty scaling.

#### ProgressBar

*inherits Range → Control*

A read-only (non-interactive) horizontal bar that fills proportionally to its value between min and max. The standard health bar, XP bar, loading bar, cooldown visualisation. Can show a percentage label automatically. Shares the Range API with sliders.

| Property | Default | What it does |
| --- | --- | --- |
| value | 0.0 | Current fill value |
| min\_value / max\_value | 0 / 100 | Range endpoints |
| show\_percentage | true | Display "XX%" label in the centre of the bar |
| fill\_mode | BEGIN\_TO\_END | Direction: left-to-right, right-to-left, top-to-bottom, centre-outward |

Use when:

health bar, XP bar, stamina gauge, loading screen progress, skill charge meter.

Tip:

drive with

$HealthBar.value = current\_hp

directly — no signal needed for display-only bars.

#### SpinBox

*inherits Range → Control*

A numeric input field with up/down arrow buttons. Allows keyboard entry of a number or clicking arrows to increment/decrement. Used in editor-style UIs, game settings panels, character customisation screens, or any scenario where the user needs to pick an integer or decimal from a range.

| Property | Default | What it does |
| --- | --- | --- |
| value / min\_value / max\_value / step | 0/0/100/1 | Standard Range properties |
| prefix / suffix | "" / "" | Text shown before/after the number — e.g., "$" prefix or "px" suffix |
| editable | true | Allow keyboard entry into the text field |

Use when:

quantity pickers (how many potions to buy), numeric settings (spawn count, damage value), any scenario where the user types or arrows a number.

#### TabContainer

*inherits Container → Control*

Shows one child Control at a time and renders a tab bar at the top to switch between them. Each direct child is one tab; the child's name becomes the tab label. Used for settings menus with Graphics/Audio/Controls tabs, inventory windows with Equipment/Stats/Quests tabs, or any multi-panel UI.

| Property | Default | What it does |
| --- | --- | --- |
| current\_tab | -1 | Index of the visible tab — settable in code to switch tabs |
| tab\_alignment | LEFT | LEFT / CENTER / RIGHT — tab bar alignment |
| tabs\_visible | true | Hide the tab bar (still switchable via code) |
| clip\_tabs | true | Clip overflowing tabs into a scroll arrow |

Use when:

multi-section menus (Settings → Graphics/Audio/Controls), inventory panels, character sheets with multiple pages.

Signal:

tab\_changed(tab\_index)

— connect to update content when tab switches.

#### ItemList

*inherits Control → CanvasItem → Node*

A scrollable list of selectable items with optional icons, tooltips, and multi-select. Items are added/removed via code. Emits `item_selected(index)` and `item_activated(index)` (double-click). Used for file pickers, crafting ingredient lists, save slot menus, and log displays.

| Property | Default | What it does |
| --- | --- | --- |
| select\_mode | SINGLE | SINGLE or MULTI (Ctrl+click for multiple) |
| max\_columns | 1 | Items per row — 0 = as many as fit (grid layout) |
| fixed\_icon\_size | Vector2(0,0) | Force all icons to this size (0,0 = use texture size) |
| auto\_height | false | Shrink control height to fit content exactly |

Pattern:

```gdscript
$ItemList.clear()
for item in inventory:
    $ItemList.add_item(item.name, item.icon)
$ItemList.item_selected.connect(_on_item_selected)
```

Prefer Tree when:

you need hierarchical (nested) items rather than a flat list.

#### Tree

*inherits Control → CanvasItem → Node*

A hierarchical tree view with expandable/collapsible rows, multiple columns, checkboxes, icons, and inline editing. Uses TreeItem objects created via code. Powerful for file browsers, skill trees, scene hierarchy viewers, and any nested data display. More complex API than ItemList but handles deep hierarchies.

| Property | Default | What it does |
| --- | --- | --- |
| columns | 1 | Number of columns per row |
| select\_mode | SINGLE | SINGLE / ROW / MULTI |
| hide\_root | false | Hide the invisible root TreeItem (makes first-level children appear as top level) |
| allow\_rmb\_select | false | Right-click selects and emits item\_rmb\_selected |

Use when:

folder/file tree views, skill tree browsers with nested categories, nested quest logs, inspector-style editors in game tools.

Pattern:

var root = tree.create\_item(); var child = tree.create\_item(root); child.set\_text(0, "Leaf")

#### Window

*inherits Viewport → Node*

A pop-up window within the game — modal dialogue, settings window, inventory pop-up, or an additional OS window. Unlike other Controls, Window is a Viewport and can contain its own UI tree. Supports title bars, close buttons, resizing, minimizing, and modality. Use for in-game overlays that should feel like desktop windows.

| Property | Default | What it does |
| --- | --- | --- |
| title | "" | Title bar text |
| visible | true | Show/hide the window — toggle with popup() / hide() |
| exclusive | false | Modal — blocks input to other windows while open |
| unresizable | false | Prevent user from dragging to resize |
| wrap\_controls | false | Auto-resize window to fit children |
| min\_size | Vector2i(0,0) | Minimum window dimensions when resizable |

Use when:

in-game inventory window, settings dialogue, confirmation modal, crafting pop-up, map viewer.

Pattern:

call

$MyWindow.popup\_centered()

to show centred; connect

close\_requested

signal to hide it.

#### VideoStreamPlayer

*inherits Control → CanvasItem → Node*

Plays a video file (Ogg Theora .ogv format) inside a UI Control rect. Used for intro cinematic cutscenes, in-game TVs/monitors, loading screen videos. The video renders as a texture within the node's rect with full playback controls (play, pause, stop, loop, volume).

| Property | Default | What it does |
| --- | --- | --- |
| stream | null | VideoStream resource — import a .ogv file in the FileSystem |
| autoplay | false | Start playing immediately when scene loads |
| loop | false | Loop the video when it finishes |
| volume\_db | 0.0 | Audio volume of the video's soundtrack |
| expand | false | Scale video to fill the control rect |

Use when:

intro/outro cinematic, in-game TV screens, loading screen looping video.

Format note:

Godot only supports Ogg Theora (.ogv). Convert with FFmpeg:

ffmpeg -i input.mp4 -codec:v libtheora -q:v 7 -codec:a libvorbis -q:a 5 output.ogv

## Networking & Multiplayer

#### MultiplayerSpawner

*inherits Node*

Automatically replicates scene instantiation across all multiplayer peers. When the authority (server) spawns a scene via this node, every connected client automatically receives and instantiates the same scene. Eliminates the need for manual RPC spawn calls for most common scenarios — players, projectiles, pickups.

| Property | Default | What it does |
| --- | --- | --- |
| spawn\_path | NodePath("") | Parent node where spawned scenes are added |
| spawn\_limit | 0 (unlimited) | Maximum concurrent spawned instances (0 = no limit) |
| auto\_spawning | true | Auto-replicate any child added under spawn\_path; if false, call spawn() manually |

Use when:

multiplayer games where the server spawns entities that all clients must see — player characters, bullets, pickups, enemies.

Pattern:

server calls

$Spawner.spawn(data)

→ all clients automatically receive and create the scene.

#### MultiplayerSynchronizer

*inherits Node*

Replicates specified properties of its parent node to all peers at a configurable rate. Add properties to the "Replication" list in the inspector (e.g., `position`, `health`, `animation`) and the synchronizer automatically broadcasts them. Handles the most common multiplayer state sync without manual RPC code.

| Property | Default | What it does |
| --- | --- | --- |
| root\_path | NodePath("..") | Node whose properties are replicated — defaults to parent |
| replication\_config | null | SceneReplicationConfig resource listing which properties to sync and at what rate |
| replication\_interval | 0.0 s | Seconds between syncs (0 = every frame); 0.1 = 10 Hz |
| delta\_interval | 0.0 s | Interval for delta (change-only) syncs — reduces bandwidth for static objects |
| public\_visibility | true | Replicate to all peers (false = selectively filter by peer ID) |

Use when:

syncing player position/health/animation state across peers in a multiplayer game.

Typical setup:

Player scene → CharacterBody3D → MultiplayerSynchronizer (root\_path = "..", replicate: position, rotation, health).

## Utility & Audio Listening

#### AudioListener2D

*inherits Node2D*

Sets the 2D "ear" position used by AudioStreamPlayer2D for positional audio panning and attenuation. By default, the listener is at the Camera2D's position. Add AudioListener2D to a node (e.g., the player) and call `make_current()` to move the listening point there — critical for games where the camera lags behind the player.

| Property | Default | What it does |
| --- | --- | --- |
| (no critical properties) | — | Position drives panning; call make\_current() to activate |

Use when:

the camera and the "listener" (player) are at different positions — smooth camera with lag, split-screen, or any case where default camera-as-listener sounds wrong.

#### AudioListener3D

*inherits Node3D*

The 3D equivalent — sets the listening position and orientation for 3D spatial audio. Normally the active Camera3D is the listener. Attach AudioListener3D to a character or separate node and call `make_current()` when you need the audio perspective to differ from the camera — e.g., third-person games where footsteps should be heard from the player character, not the trailing camera.

| Property | Default | What it does |
| --- | --- | --- |
| (no critical properties) | — | Transform drives 3D audio perspective; call make\_current() to activate |

Use when:

third-person games or cinematic cameras where you want audio to be spatially anchored to the character rather than the camera position.

#### ResourcePreloader

*inherits Node*

Loads and caches a list of resources at scene load time so they are instantly available when needed at runtime. Avoids the stutter of loading a texture or audio file on demand during gameplay. Add resources in the inspector; retrieve them with `get_resource("key")`.

| Property | Default | What it does |
| --- | --- | --- |
| resources list | [] | Dictionary of name → resource path pairs — add in the inspector |

Use when:

preloading textures, sounds, or packed scenes that would otherwise cause stutter when first accessed — weapon swap effects, level-start asset load, cutscene assets.

Modern alternative:

preload("res://...")

at the top of a GDScript file achieves the same effect at compile time and is more idiomatic in Godot 4.

#### ShaderMaterial (on MeshInstance)

*Resource (not a Node — applied via material slot)*

Not a node itself, but the most important material type in Godot. A ShaderMaterial holds a custom Shader resource (written in Godot's GLSL-like shader language) and uniform parameter values. Applied to any surface on a MeshInstance3D, Sprite2D, Control, or particle system. Enables effects impossible with StandardMaterial3D: dissolve, outline, hologram, water, fire, UI shaders.

| Property | Default | What it does |
| --- | --- | --- |
| shader | null | Shader resource — .gdshader file created in the FileSystem |
| shader\_parameter/\* | varies | Uniform values exposed by the shader — editable in inspector and settable via `set_shader_parameter("name", value)` |

Set from code:

$Mesh.material\_override.set\_shader\_parameter("dissolve\_amount", 0.5)

Use when:

any visual effect that StandardMaterial3D cannot express — water caustics, character outline, heat distortion, UV scrolling lava, X-ray see-through walls.

## Viewports & Render Targets

#### SubViewport

*inherits Viewport → Node*

An offscreen render target — renders its child scene to a texture (ViewportTexture) that can be used anywhere a Texture2D is accepted: on a MeshInstance3D (in-game TV screen, portal, mirror), as a UI TextureRect (minimap, rear-view mirror HUD). Must be placed inside a SubViewportContainer in the UI tree to be interactive. Indispensable for security camera feeds, split-screen, and magic portal effects.

| Property | Default | What it does |
| --- | --- | --- |
| size | Vector2i(512,512) | Render resolution — smaller = cheaper |
| render\_target\_update\_mode | WHEN\_VISIBLE | DISABLED / ONCE / WHEN\_VISIBLE / WHEN\_PARENT\_VISIBLE / ALWAYS |
| transparent\_bg | false | Render with transparent background for overlay compositing |
| world\_2d / world\_3d | null | Share a World2D/3D with the main viewport — useful for split-screen using the same physics world |

Common uses:

In-game TV/monitor — SubViewport with a Camera3D → get\_texture() applied to a MeshInstance3D screen mesh.

Minimap — SubViewport with orthographic Camera2D looking down → TextureRect in HUD.

Portal — SubViewport with camera at exit portal → texture on a plane at the entrance portal.

#### SubViewportContainer

*inherits Container → Control*

A Control node that wraps a SubViewport and makes it interactive — input events (mouse clicks, keyboard) are forwarded into the sub-viewport's scene. Without this container, a SubViewport renders but doesn't receive input. Required when you want clickable UI elements inside an offscreen viewport, or a fully interactive embedded game window within the main window.

| Property | Default | What it does |
| --- | --- | --- |
| stretch | false | Scale the SubViewport's output to fill the container rect |
| stretch\_shrink | 1 | Integer downscale factor when stretch=true — for pixel-art rendering |

Use when:

you need an interactive embedded viewport — game-within-a-game, in-editor tool viewport, interactive minimap.

For display-only

(no interactivity needed), use a TextureRect with the SubViewport's ViewportTexture instead.

## 3D Physics Joints

#### PinJoint3D

*inherits Joint3D → Node3D*

Locks two RigidBody3D nodes at a single point — they can rotate freely around that pin but cannot translate away from it. Like a nail through two boards. Used for hinged pendulums, chain links (in 3D), and any constraint where two bodies pivot around a shared point.

| Property | Default | What it does |
| --- | --- | --- |
| node\_a / node\_b | NodePath | Paths to the two RigidBody3D nodes being constrained |
| params/bias | 0.3 | Correction strength — how aggressively the constraint is enforced |
| params/damping | 1.0 | Dampen angular velocity at the pin point |

Use when:

creating 3D chain links, pendulums, rope segments between physics bodies that must share a pivot point.

#### HingeJoint3D

*inherits Joint3D → Node3D*

Constrains two RigidBody3D nodes so they can only rotate around one shared axis — like a door hinge or an elbow. Can set angular limits (min/max angle) and motor drive to simulate a powered hinge. Use for doors that swing, trap doors, mechanical arms, and articulated robotics.

| Property | Default | What it does |
| --- | --- | --- |
| node\_a / node\_b | NodePath | The two physics bodies being hinged |
| params/angular\_limit/enable | false | Enable min/max rotation limits |
| params/angular\_limit/upper | 1.571 rad | Maximum rotation from rest (90° default) |
| params/angular\_limit/lower | -1.571 rad | Minimum rotation from rest |
| params/motor/enable | false | Powered motor drive on the hinge axis |
| params/motor/target\_velocity | 1.0 rad/s | Motor target angular velocity |

Use when:

physics-simulated doors, trap doors, drawbridges, mechanical arm joints, barn doors the player can push open.

#### Generic6DOFJoint3D

*inherits Joint3D → Node3D*

The most flexible 3D joint — independently configures translation and rotation limits on all 6 degrees of freedom (X/Y/Z linear + X/Y/Z angular). Can simulate any joint type: slider (1 translational DOF), ball-and-socket (3 rotational DOF), universal joint, or completely custom constraints. Complex to configure but covers any mechanical linkage.

| Property | Default | What it does |
| --- | --- | --- |
| linear\_limit\_x/y/z/enabled | true | Lock linear motion on that axis |
| angular\_limit\_x/y/z/enabled | true | Lock angular motion on that axis |
| linear/angular\_limit\_\*/lower / upper | 0 / 0 | Range of allowed motion on each axis |

Use when:

none of the simpler joints (PinJoint3D, HingeJoint3D, SliderJoint3D) fit your constraint — universal joints, multi-axis robotic arms, complex mechanical linkages.

## 2D Physics Joints

#### PinJoint2D

*inherits Joint2D → Node2D*

Connects two 2D RigidBody2D nodes at a fixed point, allowing them to rotate around that pin but preventing translation. The 2D analogue of PinJoint3D. Used for 2D pendulums, chain links, crank mechanisms, ragdoll joints, and wheel axles in 2D vehicles.

| Property | Default | What it does |
| --- | --- | --- |
| node\_a / node\_b | NodePath | The two RigidBody2D nodes to pin together |
| softness | 0.0 | Spring softness — 0 = rigid pin |
| angular\_limit\_enabled | false | Restrict rotation range |
| angular\_limit\_lower / upper | 0 / 0 rad | Min/max rotation when limit is enabled |
| motor\_enabled | false | Powered rotation motor |
| motor\_target\_velocity | 0 rad/s | Target speed of the motor |

Use when:

2D ragdoll joints, pendulum, bicycle wheel axle, crank-and-piston mechanism, chain link pairs.

#### GrooveJoint2D

*inherits Joint2D → Node2D*

Constrains a body to slide along a groove (line segment) defined in world space. One body (node\_a) is fixed and defines the groove; the other (node\_b) slides inside it. Used for pistons, sliding doors, elevator shafts, and any constraint where a body must slide linearly but stay in a track.

| Property | Default | What it does |
| --- | --- | --- |
| length | 50 px | Length of the groove |
| initial\_offset | 25 px | Starting position of the sliding body along the groove |

Use when:

pistons, sliding platforms constrained to a track, physics-based elevators, mechanical sliders in 2D.

## Miscellaneous & Editor Helpers

#### Node (base)

*Base class of all nodes*

Pure logic container — no transform, no rendering. Use when you need a script-only node to manage state or coordinate children without inheriting any spatial or visual properties. Common uses: GameManager singleton, level coordinator, event bus, state machine root.

| Property | Default | What it does |
| --- | --- | --- |
| name | "Node" | Identifier within the scene tree |
| process\_mode | INHERIT | INHERIT / PAUSABLE / WHEN\_PAUSED / ALWAYS / DISABLED — controls \_process/\_physics\_process during pause |
| process\_priority | 0 | Lower = processed earlier in frame; tweak when order within same group matters |
| editor\_description | "" | Tooltip shown in the scene tree editor for documentation |

process\_mode cheat sheet:

PAUSABLE — pause when

get\_tree().paused = true

(default for gameplay nodes).

WHEN\_PAUSED — run only while paused (pause menu, inventory UI).

ALWAYS — never pause (audio manager, save system).

DISABLED — never run \_process/\_physics\_process.

#### AnimationMixer

*inherits Node (abstract base for AnimationPlayer)*

Abstract base class for AnimationPlayer and AnimationTree — you never add this directly. Understanding it helps when using both: it defines the common API (`active`, `speed_scale`, `callback_mode_process`, `root_node`). Both AnimationPlayer and AnimationTree inherit these properties.

| Property | Default | What it does |
| --- | --- | --- |
| active | true | Enable/disable all animation processing |
| speed\_scale | 1.0 | Global playback speed multiplier — 0.5 = slow motion, 2.0 = double speed |
| root\_node | NodePath("..") | The subtree root whose node paths are resolved for animation tracks |
| callback\_mode\_process | IDLE | IDLE: update in \_process; PHYSICS: update in \_physics\_process |

Use speed\_scale for:

slow-motion effects, fast-forward idle animations, time-stop abilities — set on AnimationPlayer directly.

#### OccluderInstance3D

*inherits Node3D*

Provides occlusion culling geometry — defines a simplified mesh that the renderer uses to determine which other objects are hidden behind it and can be skipped entirely. Dramatically reduces draw calls in scenes with many rooms or complex props by not sending occluded geometry to the GPU. Uses Occluder3D resources (box, sphere, polygon, quad).

| Property | Default | What it does |
| --- | --- | --- |
| occluder | null | Occluder3D resource — ArrayOccluder3D, BoxOccluder3D, SphereOccluder3D, QuadOccluder3D, PolygonOccluder3D |
| bake\_mask | all layers | Which render layers are occluded by this shape |

Use when:

indoor scenes with many rooms — large walls, floors between stories, and massive pillars are ideal occluders. Bake with the OccluderInstance3D bake button.

Not useful for:

outdoor open-world scenes with no large occluding surfaces.

#### NavigationRegion3D

*inherits Node3D*

The 3D equivalent of NavigationRegion2D — bakes a NavigationMesh onto the geometry within its bounds. Defines the walkable surface for 3D NavigationAgent3D pathfinding. Place over your level geometry, configure the agent radius/height, then bake to generate the nav mesh. Supports runtime rebaking for dynamic obstacles.

| Property | Default | What it does |
| --- | --- | --- |
| navigation\_mesh | null | NavigationMesh resource — create new then bake |
| enabled | true | Include this region in pathfinding queries |

Use when:

3D AI navigation — enemy pathfinding through indoor levels, NPC routing in open-world environments.

Workflow:

add NavigationRegion3D → create NavigationMesh → configure agent properties (radius, height, max slope) → Bake NavigationMesh button.

## 2D Physics — Extra Nodes

#### CollisionShape2D

*inherits Node2D*

Defines the collision geometry for a parent 2D physics body (CharacterBody2D, RigidBody2D, StaticBody2D, Area2D). Holds a Shape2D resource. Multiple CollisionShape2D children combine to form the body's full collision shape. The shape does not need to match the visual sprite — simpler is faster.

| Property | Default | What it does |
| --- | --- | --- |
| shape | null | Shape2D resource: CircleShape2D, RectangleShape2D, CapsuleShape2D, ConvexPolygonShape2D, ConcavePolygonShape2D, SegmentShape2D, WorldBoundaryShape2D |
| disabled | false | Temporarily disable this shape without removing it |
| one\_way\_collision | false | Only collide from one side — essential for one-way platforms |
| one\_way\_collision\_margin | 1.0 px | Tolerance margin for one-way detection |

Shape guide:

CircleShape2D — fastest; RectangleShape2D — boxes/platforms; CapsuleShape2D — humanoid characters; ConvexPolygonShape2D — convex props; ConcavePolygonShape2D — complex static terrain only.

One-way platforms:

enable

one\_way\_collision

on the platform's CollisionShape2D and ensure the player presses down to fall through.

#### CollisionPolygon2D

*inherits Node2D*

Like CollisionShape2D but defines the shape as a hand-drawn polygon directly in the 2D viewport editor instead of a parameterised shape resource. Useful when you need an irregular collision hull that doesn't fit any standard shape. Build mode controls whether it generates a solid (convex decomposition) or one-sided (segment) shape.

| Property | Default | What it does |
| --- | --- | --- |
| polygon | [] | Array of Vector2 points defining the polygon outline — editable in viewport |
| build\_mode | SOLIDS | SOLID: filled collision body; SEGMENTS: only the outline edges (useful for world boundaries) |
| disabled | false | Temporarily disable collision |
| one\_way\_collision | false | One-sided collision (same as CollisionShape2D) |

Use when:

you need an irregular collision shape that doesn't fit a circle, rectangle, or capsule — custom terrain chunks, irregular platform ledges, polygon-shaped props.

#### CollisionPolygon3D

*inherits Node3D*

Defines a 3D convex collision shape from a set of 3D points, similar to CollisionPolygon2D but in 3D space. Used to create custom convex collision hulls on physics bodies. Less common than CollisionShape3D with a ConvexPolygonShape3D resource but useful for workflow integration with mesh editing tools.

| Property | Default | What it does |
| --- | --- | --- |
| polygon | [] | Array of Vector3 points — convex hull is computed from these |
| depth | 1.0 | Extrusion depth — creates a prism from the 2D polygon cross-section |
| disabled | false | Disable collision temporarily |

Prefer CollisionShape3D

with a ConvexPolygonShape3D resource for most cases — it gives access to simplified mesh generation from imported geometry.

## UI — Container Reference

#### AspectRatioContainer

*inherits Container → Control*

Forces its single child Control to maintain a fixed aspect ratio within the available space. Useful for keeping game viewports, portrait panels, and image displays from stretching when the window resizes. The ratio and fit mode control how the child is sized.

| Property | Default | What it does |
| --- | --- | --- |
| ratio | 1.0 | Width-to-height ratio (1.78 = 16:9, 1.33 = 4:3) |
| stretch\_mode | FIT | FIT: letterbox; COVER: crop; WIDTH\_CONTROLS\_HEIGHT / HEIGHT\_CONTROLS\_WIDTH |
| alignment\_horizontal / vertical | CENTER / CENTER | Where to place the child if it doesn't fill the container |

Use when:

containing a SubViewportContainer (game view) in a resizable window, keeping a character portrait at a fixed ratio, displaying a 16:9 thumbnail in a variable-width slot.

#### CenterContainer

*inherits Container → Control*

Centers its children in the middle of its rect. The simplest centering container — no size constraints, no layout logic, just "put everything in the middle." Common for splash screens, loading indicators, and centred dialogue prompts.

| Property | Default | What it does |
| --- | --- | --- |
| use\_top\_left | false | Align to top-left corner instead of true centre (rarely needed) |

Use when:

you want a child to appear in the exact centre — splash screen logo, fullscreen loading spinner, centred popup message.

#### PanelContainer

*inherits Container → Control*

Combines Panel (themed background) with automatic size-to-content behaviour. Unlike a plain Panel (fixed size), PanelContainer expands to fit its children and adds padding from the panel StyleBox. The go-to for tooltips, inventory item cards, status panels that resize to their text content.

| Property | Default | What it does |
| --- | --- | --- |
| theme\_override\_styles/panel | StyleBoxFlat | Background StyleBox — change colour, border, corner radius |

Use when:

you want a background panel that auto-sizes to its content — tooltips, notification toasts, item cards, auto-sizing dialogue boxes.

#### FlowContainer (HFlowContainer / VFlowContainer)

*inherits Container → Control*

Lays out children in a row (H) or column (V) and automatically wraps to the next line when the available width (or height) is exceeded — like CSS flexbox wrap. Perfect for tag clouds, skill grids, inventory grids that reflow when the window resizes, or any variable-count icon set.

| Property | Default | What it does |
| --- | --- | --- |
| alignment | BEGIN | BEGIN / CENTER / END — alignment of items in each row/column |
| last\_wrap\_alignment | INHERIT | Alignment override for the last (partial) row/column |

Use when:

displaying a set of same-size items that should wrap — skill icons, tag chips, inventory slots that reflow on window resize.

#### SplitContainer (HSplitContainer / VSplitContainer)

*inherits Container → Control*

Divides its space between exactly two children with a draggable divider between them. Used for resizable two-pane layouts — scene tree + inspector, map view + properties panel, chat log + input box. The user drags the divider; the split ratio is stored in `split_offset`.

| Property | Default | What it does |
| --- | --- | --- |
| split\_offset | 0 px | Pixel offset of the divider from centre (negative = left/top biased) |
| collapsed | false | Collapse the second child entirely (divider at the far edge) |
| dragger\_visibility | VISIBLE | VISIBLE / HIDDEN / HIDDEN\_COLLAPSED |

Use when:

building editor-style UIs with resizable panes — in-game world editor, map editor, debug overlay with resizable log.

## Quick-Pick Reference — Which Node Do I Need?

:::callout-key
::::callout-key
Node Decision Guide
::::

| Goal | Node to use |
| --- | --- |
| Display a 2D image | Sprite2D |
| Animated 2D sprite sheet | AnimatedSprite2D |
| Player / enemy movement (2D) | CharacterBody2D + CollisionShape2D |
| Player / enemy movement (3D) | CharacterBody3D + CollisionShape3D |
| Physics simulation (ball, crate) | RigidBody2D / RigidBody3D |
| Static level geometry | StaticBody2D / StaticBody3D |
| Overlap / trigger zone detection | Area2D / Area3D |
| 2D tile map level | TileMapLayer |
| 3D grid-aligned level | GridMap |
| 3D visible mesh | MeshInstance3D |
| Thousands of the same 3D mesh | MultiMeshInstance3D |
| Text in UI | Label / RichTextLabel |
| Text in 3D world space | Label3D |
| Button | Button / TextureButton / LinkButton |
| Health / XP bar | ProgressBar |
| Volume slider | HSlider / VSlider |
| Text entry (single line) | LineEdit |
| Text entry (multi-line) | TextEdit |
| Multi-panel settings menu | TabContainer |
| Scrollable list of items | ItemList |
| Nested hierarchical list | Tree |
| Pop-up window | Window (popup\_centered()) |
| Countdown / cooldown | Timer |
| Named position in scene | Marker2D / Marker3D |
| Play animation | AnimationPlayer |
| Blend / state-machine animations | AnimationTree |
| Play sound | AudioStreamPlayer (global), AudioStreamPlayer2D/3D (spatial) |
| Follow a camera in 2D | Camera2D |
| 3D camera | Camera3D |
| Third-person camera (no wall clip) | SpringArm3D → Camera3D |
| Parallax scrolling background | Parallax2D (Godot 4.3+) |
| Particle effects (2D) | GPUParticles2D (complex) / CPUParticles2D (simple / mobile) |
| Particle effects (3D) | GPUParticles3D |
| Enemy pathfinding (2D) | NavigationRegion2D + NavigationAgent2D |
| Enemy pathfinding (3D) | NavigationRegion3D + NavigationAgent3D |
| Offscreen render texture | SubViewport |
| Sky, ambient, post-processing | WorldEnvironment |
| Baked static lighting | LightmapGI |
| Sun / moon (3D directional) | DirectionalLight3D |
| Point light bulb / torch (3D) | OmniLight3D |
| Flashlight / spotlight (3D) | SpotLight3D |
| Bullet holes / decals | Decal |
| Level prototype geometry | CSGBox3D / CSGCombiner3D |
| Moving platform (physics-aware) | AnimatableBody2D / AnimatableBody3D |
| Multiplayer entity spawn | MultiplayerSpawner |
| Multiplayer state sync | MultiplayerSynchronizer |
:::
