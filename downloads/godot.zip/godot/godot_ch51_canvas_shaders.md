---
title: "CanvasItem (2D) Shaders — fragment, vertex & light Passes"
source: "godot_ch51_canvas_shaders.html"
---

Part VIII · Chapter 51

# CanvasItem (2D) Shaders — `fragment`, `vertex` & `light` Passes

Estimated study time: 90 min · Godot 4.6 · GDShader

## Overview

Now that you understand the GDShader language, this chapter applies it specifically to the `canvas_item` context — everything that renders to a CanvasLayer: Sprite2D, AnimatedSprite2D, TextureRect, ColorRect, MeshInstance2D, and Control nodes. The 2D rendering pipeline has unique capabilities: access to the live screen buffer (for distortion and blend effects), 2D normal maps for fake lighting, and a dedicated `light()` function that integrates with Godot's CanvasLight system.

This chapter is structured as a theory section followed by a practical effects cookbook. All effects are self-contained and ready to drop into your project.

### Prerequisites

- Ch 50 — GDShader Fundamentals (types, uniforms, UV manipulation)

## Render Modes

Render modes go on the second line of a canvas\_item shader (after `shader_type canvas_item;`) and change fundamental rendering behaviour. Multiple modes are combined with commas.

| Mode | Description |
| --- | --- |
| `blend_mix` | **Default.** Standard alpha blending: `out = src_alpha × src + (1 − src_alpha) × dst` |
| `blend_add` | Additive blending — adds source colour to destination. Bright glow/fire effects. |
| `blend_sub` | Subtractive blending — darkens destination. |
| `blend_mul` | Multiplicative — multiplies source and destination colours. |
| `blend_premul_alpha` | Use when the texture has pre-multiplied alpha. |
| `blend_disabled` | No blending — overwrites destination directly. Fastest; use for opaque sprites. |
| `unshaded` | Skip all lighting calculations. The fragment output is the final colour, unmodified by any CanvasLight nodes. |
| `light_only` | The sprite is invisible unless lit by a CanvasLight. Good for light-painted surfaces. |
| `skip_vertex_transform` | Disable Godot's automatic world/canvas transform in the vertex stage. You handle it manually via `CANVAS_MATRIX`. |

```glsl
shader_type canvas_item;
render_mode unshaded, blend_add;  // additive glow, no lighting

void fragment() {
    COLOR = texture(TEXTURE, UV);
}
```

canvas\_item Shader — Three Callable Stages

vertex()

Runs per vertex.

Modify VERTEX to displace mesh

positions (e.g. wave animation).

Optional — can be omitted.

fragment()

Runs per pixel. Set COLOR

to the final RGBA output.

90% of effects live here.

Required (usually).

light()

Runs per CanvasLight.

Customize how light colour

accumulates into LIGHT.

Optional — custom lighting only.

render\_mode unshaded → skips light() entirely  ·  render\_mode blend\_add → additive alpha compositing

A canvas\_item shader can define up to three functions. Most effects only need `fragment()`. The `vertex()` function is for mesh deformation; `light()` is for custom 2D lighting responses.

## canvas\_item Fragment Built-ins

These are the most important read/write variables available inside `fragment()` for canvas\_item shaders.

| Built-in | Type | R/W | Description |
| --- | --- | --- | --- |
| `COLOR` | vec4 | R/W | Read = per-vertex modulate colour. Write = final pixel colour output (RGBA). |
| `TEXTURE` | sampler2D | R | The node's primary texture (e.g. Sprite2D.texture). |
| `UV` | vec2 | R | Texture coordinate for this pixel, 0→1. |
| `TEXTURE_PIXEL_SIZE` | vec2 | R | `1.0 / textureSize(TEXTURE, 0)` — one pixel step in UV space. |
| `SCREEN_UV` | vec2 | R | This pixel's position in 0–1 screen space (0,0 = top-left). |
| `uniform sampler2D … : hint_screen_texture` | sampler2D | R | The live screen buffer *before* this sprite is drawn. **Not a built-in** — Godot 3’s `SCREEN_TEXTURE` was removed in 4.x. Declare your own uniform with the hint and the name is yours; see below. |
| `NORMAL_MAP` | vec3 | W | Write a normal-map sample here to enable 2D normal-mapped lighting. |
| `NORMAL_MAP_DEPTH` | float | W | Strength of the normal map (1.0 = full effect). |
| `FRAGCOORD` | vec4 | R | Window-space pixel position (.xy) and depth (.z). |
| `TIME` | float | R | Seconds since start (global). |
| `SCREEN_PIXEL_SIZE` | vec2 | R | Size of one screen pixel in screen UV units — its reciprocal is the viewport size. There is no `VIEWPORT_SIZE` in a canvas\_item shader; that one is spatial-only. |

### Using SCREEN\_TEXTURE

`SCREEN_TEXTURE` gives you the rendered image of everything *behind* the current sprite, letting you create glass, distortion, and refraction effects. You must declare it as a uniform with the `hint_screen_texture` hint for Godot to bind it automatically:

```glsl
shader_type canvas_item;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear, repeat_disable;

void fragment() {
    // Sample the screen directly behind this pixel
    vec4 behind = texture(SCREEN_TEXTURE, SCREEN_UV);
    // Tint whatever is behind to a blue-green
    COLOR = behind * vec4(0.4, 0.8, 1.0, 1.0);
}
```

:::callout-warning[Warning — SCREEN\_TEXTURE performance]
Each sprite using `SCREEN_TEXTURE` forces a copy of the screen buffer at that draw-call point. Multiple sprites using it in the same frame multiply that cost. Keep screen-texture effects rare (one or two per scene), or composite them onto a single CanvasLayer that reads the buffer once.
:::

### 2D Normal Maps

Normal maps in 2D let CanvasLight nodes (DirectionalLight2D, PointLight2D) shade sprites as if they had depth. Write the normal map sample to `NORMAL_MAP` — Godot handles the rest.

```glsl
shader_type canvas_item;

uniform sampler2D normal_tex : hint_normal, filter_linear;
uniform float     normal_depth = 1.0;

void fragment() {
    COLOR       = texture(TEXTURE, UV);
    NORMAL_MAP  = texture(normal_tex, UV).rgb;   // RGB normal map
    NORMAL_MAP_DEPTH = normal_depth;
}
```

Normal map textures encode surface normals as RGB: R = X direction, G = Y direction, B = Z direction (pointing outward). Most art tools (Aseprite, Krita, Photoshop) have plugins to generate normal maps from height maps. Import the normal map texture with the **Normal Map** import preset so Godot applies the correct colour-space conversion.

## Vertex Displacement in 2D

The `vertex()` function in canvas\_item shaders operates in object space. Writing to `VERTEX` shifts the mesh vertices — used for wobble, wave, and deformation effects.

| Built-in | Type | R/W | Description |
| --- | --- | --- | --- |
| `VERTEX` | vec2 | R/W | Vertex position in object (local) space. Write to deform the mesh. |
| `UV` | vec2 | R/W | Texture coordinate. Write to remap UVs per-vertex. |
| `COLOR` | vec4 | R | Per-vertex modulate colour. |
| `CANVAS_MATRIX` | mat4 | R | Canvas → screen transform. |
| `SCREEN_MATRIX` | mat4 | R | Screen space → NDC transform. |
| `MODEL_MATRIX` | mat4 | R | Object → world transform. Read global position from column 3. |

```glsl
shader_type canvas_item;

uniform float wave_amplitude = 8.0;
uniform float wave_frequency = 4.0;
uniform float wave_speed     = 2.0;

void vertex() {
    // Vertical sine wave — great for flags, water surfaces, foliage
    float wave = sin(VERTEX.x * wave_frequency + TIME * wave_speed);
    VERTEX.y += wave * wave_amplitude;
    // Attenuate at left edge (x < 0) so the flag root doesn't move
    // (the mesh UV.x works as a horizontal gradient from 0 to 1)
    VERTEX.y *= UV.x;
}
```

:::callout-tip[Tip — vertex shaders need enough geometry]
A Sprite2D is just two triangles (4 vertices). Sine-wave displacement on 4 vertices looks blocky. For smooth vertex deformation, use a MeshInstance2D with a PlaneMesh subdivided into many rows and columns, or a Polygon2D with many points.
:::

## The light() Function

When a CanvasLight node (PointLight2D or DirectionalLight2D) affects a sprite, Godot calls the shader's `light()` function once per light source per pixel. This is where you control how the sprite responds to lighting — default Lambertian diffuse, cel-shading, rim lighting, anything.

```glsl
shader_type canvas_item;

void fragment() {
    COLOR = texture(TEXTURE, UV);
}

void light() {
    // LIGHT_COLOR: the CanvasLight's colour × energy
    // LIGHT_ENERGY: the light's energy scalar
    // LIGHT_VERTEX: vector from pixel to light (in canvas space)
    // NORMAL: the pixel's normal (from NORMAL_MAP if set, else vec3(0,0,1))

    // Standard diffuse:
    float ndotl = max(dot(NORMAL, LIGHT_DIRECTION), 0.0);
    LIGHT = LIGHT_COLOR * LIGHT_ENERGY * COLOR * ndotl;
}
```

**light() built-in variables:**

| Variable | Type | R/W | Description |
| --- | --- | --- | --- |
| `LIGHT_COLOR` | vec4 | R | The CanvasLight's colour including alpha. |
| `LIGHT_ENERGY` | float | R | The CanvasLight's energy multiplier. |
| `LIGHT_VERTEX` | vec2 | R | Vector from pixel to light origin (canvas space). |
| `LIGHT_DIRECTION` | vec3 | R | Normalised direction toward the light (uses Z for PointLight2D height). |
| `NORMAL` | vec3 | R | Pixel normal (from NORMAL\_MAP if provided, else (0,0,1)). |
| `SHADOW_MODULATE` | vec4 | R | Shadow colour × opacity for this pixel. |
| `LIGHT` | vec4 | W | The amount of light to add to this pixel. Default = 0 (dark). |

Cel-shading light function — discrete steps instead of smooth gradient:

```glsl
void light() {
    float ndotl  = dot(NORMAL, LIGHT_DIRECTION);
    // Three discrete bands: shadow, mid, bright
    float shaded = step(0.0, ndotl) * step(ndotl, 0.5) * 0.4
                 + step(0.5, ndotl) * step(ndotl, 0.8) * 0.7
                 + step(0.8, ndotl) * 1.0;
    LIGHT = LIGHT_COLOR * LIGHT_ENERGY * COLOR * shaded;
}
```

## Effect Cookbook

All effects below are self-contained canvas\_item shaders. Attach a `ShaderMaterial` to any Sprite2D and paste the code in.

Canvas Shader Effects at a Glance

Thick Outline

Noise Dissolve

A

A

A

Chromatic Aberration

Pixelate

Screen Distortion

HIT!

Hit Flash

Each effect covered

with full GLSL source

in the sections below.

All applied via:

ShaderMaterial

on any Sprite2D,

ColorRect, or Control.

Six ready-to-use canvas\_item shader effects. Each is implemented as a single `fragment()` function attached via ShaderMaterial.

### Thick Outline

Samples the texture at 8 surrounding positions. If this pixel is transparent but any neighbour is opaque, draw the outline colour.

```glsl
shader_type canvas_item;

uniform vec4  outline_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float outline_width = 2.0;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    // Not named `step`: that is a GLSL builtin, and shadowing it makes the
    // step() calls further down fail to compile.
    vec2 px = TEXTURE_PIXEL_SIZE * outline_width;

    // Sample 8 neighbours
    float max_a = 0.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            if (x == 0 && y == 0) continue;
            vec2 offset = vec2(float(x), float(y)) * px;
            max_a = max(max_a, texture(TEXTURE, UV + offset).a);
        }
    }
    // Draw outline where this pixel is transparent but a neighbour is not
    float edge = (1.0 - step(0.1, tex.a)) * step(0.1, max_a);
    COLOR = mix(tex, outline_color, edge);
}
```

### Noise Dissolve

Clips away pixels below a noise threshold. Animate the `threshold` uniform from 0→1 to dissolve a sprite out.

```glsl
shader_type canvas_item;

uniform sampler2D noise_tex : filter_linear, repeat_enable;
uniform float     threshold : hint_range(0.0, 1.0, 0.005) = 0.0;
uniform vec4      edge_color : source_color = vec4(1.0, 0.4, 0.0, 1.0);
uniform float     edge_width : hint_range(0.0, 0.1, 0.001) = 0.02;

void fragment() {
    vec4 tex   = texture(TEXTURE, UV);
    float noise = texture(noise_tex, UV).r;

    // Discard below threshold
    if (noise < threshold) discard;

    // Colour edge band just above threshold
    float edge = smoothstep(threshold, threshold + edge_width, noise);
    COLOR = mix(edge_color, tex, edge);
    COLOR.a = tex.a * step(threshold, noise);
}
```

:::callout-tip[Animate dissolve from GDScript]
```gdscript
var tween := create_tween()
tween.tween_method(
    func(v): $Sprite2D.material.set_shader_parameter("threshold", v),
    0.0, 1.0, 1.5
)
```
:::

### Chromatic Aberration

Shifts the R and B channels in opposite directions — mimics lens distortion, great for a "damaged screen" or impact effect.

```glsl
shader_type canvas_item;

uniform float strength : hint_range(0.0, 0.05, 0.001) = 0.005;

void fragment() {
    vec2 offset = vec2(strength, 0.0);
    float r = texture(TEXTURE, UV + offset).r;
    float g = texture(TEXTURE, UV).g;
    float b = texture(TEXTURE, UV - offset).b;
    float a = texture(TEXTURE, UV).a;
    COLOR = vec4(r, g, b, a);
}
```

### Pixelate

Quantises UVs to a grid — retro pixel-art look, or a "loading" style blur.

```glsl
shader_type canvas_item;

uniform float pixel_size : hint_range(1.0, 64.0, 1.0) = 8.0;

void fragment() {
    vec2 tex_size = vec2(1.0) / TEXTURE_PIXEL_SIZE;
    vec2 grid     = pixel_size / tex_size;
    vec2 snapped  = floor(UV / grid) * grid + grid * 0.5;
    COLOR = texture(TEXTURE, snapped);
}
```

### Screen-Space Distortion (Glass / Heat Haze)

Reads a noise texture to offset the screen UV, distorting everything behind the sprite. Perfect for glass panels, heat shimmer, and portals.

```glsl
shader_type canvas_item;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear, repeat_disable;
uniform sampler2D noise_tex      : filter_linear, repeat_enable;
uniform float     distort_amount = 0.02;
uniform float     scroll_speed   = 0.3;

void fragment() {
    // Scrolling noise for animated distortion
    vec2 noise_uv   = UV + vec2(TIME * scroll_speed, TIME * scroll_speed * 0.7);
    vec2 noise_val  = texture(noise_tex, noise_uv).rg * 2.0 - 1.0;

    // Offset screen sample by noise
    vec2 screen_uv  = SCREEN_UV + noise_val * distort_amount;
    vec4 behind     = texture(SCREEN_TEXTURE, screen_uv);

    // Only apply where the sprite's texture is opaque
    float mask = texture(TEXTURE, UV).a;
    COLOR      = vec4(behind.rgb, mask);
}
```

### Hit Flash

A classic game-feel effect: when the player takes damage, flash the sprite white for a frame or two. Animate the `flash` uniform from GDScript.

```glsl
shader_type canvas_item;

uniform float flash : hint_range(0.0, 1.0, 0.01) = 0.0;
uniform vec4  flash_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    // Blend towards flash_color, preserving alpha
    COLOR.rgb = mix(tex.rgb, flash_color.rgb, flash);
    COLOR.a   = tex.a;
}
```

Trigger from GDScript on taking damage:

```gdscript
func flash_white() -> void:
    var mat := $Sprite2D.material as ShaderMaterial
    var tween := create_tween()
    tween.tween_method(
        func(v): mat.set_shader_parameter("flash", v),
        1.0, 0.0, 0.2
    )
```

## Practice Problems

:::problem
#### A — Inverted Silhouette easy

Write a canvas\_item shader that inverts the RGB of its texture (`1.0 - colour`) while preserving alpha. Expose a `strength` uniform (0 = original, 1 = fully inverted) so the inversion can be blended in.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float strength : hint_range(0.0, 1.0, 0.01) = 1.0;

void fragment() {
    vec4 tex     = texture(TEXTURE, UV);
    vec3 inverted = 1.0 - tex.rgb;
    COLOR.rgb    = mix(tex.rgb, inverted, strength);
    COLOR.a      = tex.a;
}
```
::::
:::

:::problem
#### B — Additive Glow Ring standard

Write a canvas\_item shader with `render_mode blend_add`. In the fragment function, compute the distance from UV to the centre (0.5, 0.5). Draw a glowing ring at a configurable `radius` and `ring_width` using `smoothstep()`. Let the ring colour be a `source_color` uniform and animate the glow pulsing with TIME.

::::solution[Solution]
```glsl
shader_type canvas_item;
render_mode blend_add, unshaded;

uniform vec4  ring_color  : source_color = vec4(0.2, 0.8, 1.0, 1.0);
uniform float radius      : hint_range(0.0, 0.5) = 0.35;
uniform float ring_width  : hint_range(0.01, 0.2) = 0.06;
uniform float pulse_speed = 2.0;

void fragment() {
    float dist  = length(UV - vec2(0.5));
    float ring  = smoothstep(ring_width, 0.0, abs(dist - radius));
    float pulse = sin(TIME * pulse_speed) * 0.3 + 0.7;
    COLOR = ring_color * ring * pulse;
}
```
::::
:::

:::problem
#### C — Tiled Normal Map Integration standard

Write a canvas\_item shader that applies a tiling normal map to a sprite. The normal map UV should be independently scalable with a `normal_scale` uniform (default 2.0). The normal map depth should be adjustable with `normal_depth` (0–3, default 1). The sprite's original texture colour must still show through unchanged.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform sampler2D normal_tex   : hint_normal, filter_linear, repeat_enable;
uniform float     normal_scale : hint_range(0.1, 10.0, 0.1) = 2.0;
uniform float     normal_depth : hint_range(0.0, 3.0, 0.1)  = 1.0;

void fragment() {
    COLOR            = texture(TEXTURE, UV);
    NORMAL_MAP       = texture(normal_tex, UV * normal_scale).rgb;
    NORMAL_MAP_DEPTH = normal_depth;
}
```
::::
:::

:::problem
#### D — Flag Wave Vertex Shader standard

Write a canvas\_item shader with a vertex stage that simulates a waving flag. The wave amplitude should increase from left to right (UV.x), so the left edge (the flag pole) stays still and the right edge waves the most. Expose `wave_amplitude`, `wave_frequency`, and `wave_speed` uniforms. The fragment stage just samples the texture normally.

::::solution[Solution]
```glsl
shader_type canvas_item;

uniform float wave_amplitude = 12.0;
uniform float wave_frequency = 3.5;
uniform float wave_speed     = 3.0;

void vertex() {
    float wave = sin(VERTEX.x * wave_frequency * 0.01 + TIME * wave_speed);
    // UV.x goes 0 (pole) → 1 (free edge) — attenuate by UV.x
    VERTEX.y += wave * wave_amplitude * UV.x;
}

void fragment() {
    COLOR = texture(TEXTURE, UV);
}
```
::::
:::

:::problem
#### E — Damage Vignette (Screen Effect) challenge

Write a **fullscreen** canvas\_item shader (attach to a ColorRect that fills the viewport). It should darken the screen edges with a red vignette whose intensity is driven by a `damage` uniform (0 = invisible, 1 = heavy vignette). The vignette should be smooth (use `smoothstep`), red-tinted, and also subtly pulse with TIME when `damage` is above 0.5. Use `SCREEN_TEXTURE` to show the underlying game through the effect.

::::solution[Solution]
```glsl
shader_type canvas_item;
render_mode unshaded;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear, repeat_disable;
uniform float damage : hint_range(0.0, 1.0, 0.01) = 0.0;

void fragment() {
    vec4 scene = texture(SCREEN_TEXTURE, SCREEN_UV);

    // Vignette: distance from screen centre
    vec2 centred = SCREEN_UV - vec2(0.5);
    float vignette = smoothstep(0.25, 0.75, length(centred));

    // Pulse when heavily damaged
    float pulse = damage > 0.5
        ? sin(TIME * 6.0) * 0.15 + 0.85
        : 1.0;

    vec4 red_vignette = vec4(0.8, 0.0, 0.0, 1.0) * vignette * damage * pulse;

    // Darken scene and overlay red
    COLOR = vec4(scene.rgb * (1.0 - vignette * damage * 0.5) + red_vignette.rgb,
                 1.0);
}
```

Animate `damage` from 0 → 1 → 0 using a Tween when the player takes a hit for a smooth flash-in, hold, fade-out effect.
::::
:::
