---
title: "VS Clone — Player Character, Movement & Stats"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71B"
meta:
  - "Est. study time: ~75 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated May 2026"
source: "godot_ch71b_player.html"
---

## Overview

The player in a Vampire Survivors clone does almost nothing. That sounds like a
 criticism — it isn't. It's a deliberate design constraint that is also an excellent
 Godot teaching exercise: when you strip out all the attacking, aiming, and abilities
 from the player, you see exactly what a physics-based character actually requires.

What the player needs is: **a node that can move through the world and collide
 with walls**, **a way to detect when enemies touch it**,
 **a way to detect when XP gems enter its orbit**, and
 **a place to attach weapon nodes**. That's the entire list.
 By the end of this chapter you will understand why each piece exists, what Godot
 node handles it, and how they all stay cleanly separated.

:::callout-key[What you will build]
Player.tscn and Player.gd: a CharacterBody2D that moves with WASD,
 has a HurtBox for receiving enemy damage with 0.5 s invincibility frames,
 a MagnetArea that attracts nearby XP gems, a WeaponHolder that carries
 weapons without knowing what they do, and a Camera2D that follows the player
 within world limits. All player stats live in a separate Resource so upgrades
 never require editing Player.gd.
:::

### What you need first

- Ch 71A complete — Main.tscn exists, physics layers are named, input actions are set up.
- Understanding of CharacterBody2D vs. RigidBody2D (Ch 8 covers this; key point: CharacterBody2D is for *scripted* movement, RigidBody2D is for *physics-simulated* movement).
- Basic familiarity with Godot 4 Area2D signals (Ch 5 and Ch 8).

## 1. Why CharacterBody2D — and Not the Others

:::callout-intuition[Intuition first]
Godot offers three 2D physics body types. Choosing the wrong one is the most
 common beginner mistake, and fixing it later requires rebuilding the scene.
 Understand the choice before you click "Add Node."
:::

The three physics body types in Godot 4 serve completely different purposes:

| Node | Who controls movement? | Best for |
| --- | --- | --- |
| `StaticBody2D` | Nobody — it never moves | Walls, floors, platforms, any immovable surface |
| `RigidBody2D` | Godot's physics engine — applies forces, momentum, gravity | Balls, crates, anything that should tumble and bounce realistically |
| `CharacterBody2D` | Your script — you set `velocity` and call `move_and_slide()` | Player characters, enemies, anything where YOU decide how to move |

For the player, you want full control: move left at exactly 120 px/s when A is
 held, stop instantly when it's released. A RigidBody2D would keep sliding due to
 momentum and respond to gravity — you'd spend most of your code fighting the physics
 engine instead of using it. CharacterBody2D gives you a blank canvas: set velocity,
 call `move_and_slide()`, the engine handles wall collisions, done.

CharacterBody2D — extends PhysicsBody2D → CollisionObject2D → Node2D

A physics body where movement is entirely script-driven. You set
 `velocity: Vector2` each frame and call `move_and_slide()`
 to apply it — Godot resolves collisions with walls and other bodies automatically.
 Unlike RigidBody2D, it has no gravity or momentum by default.

| Property | Type | What it does |
| --- | --- | --- |
| velocity | Vector2 | The movement vector to apply this frame. Set this in `_physics_process`, then call `move_and_slide()`. |
| up\_direction | Vector2 | Defines "up" for floor detection. Set to `Vector2.UP` for a platformer; leave at default `(0, -1)` for top-down (doesn't matter much). |
| motion\_mode | enum | `MOTION_MODE_GROUNDED` for platformers (snap to floor). `MOTION_MODE_FLOATING` for top-down — no floor snapping, simpler collision response. |
| collision\_layer / mask | int (bitmask) | Which layers this body *is on* (layer) and which layers it *collides with* (mask). Our player is on Layer 2 and collides with Layers 1 (walls) and 4 (enemies). |

:::callout-tip[Set motion\_mode to FLOATING for top-down games]
`MOTION_MODE_GROUNDED` is the default — it tries to snap the body
 to a "floor." In a top-down arena there is no floor, so leave it at
 `MOTION_MODE_FLOATING`. Otherwise you may see odd snapping behaviour
 when the player walks into diagonal walls.
:::

## 2. PlayerStats — Why a Resource, Not @export Variables

:::callout-intuition[The problem we're solving]
Imagine you have 15 stat-modifying upgrades. Each one says
 `player.move_speed *= 1.2`. Now you want to add armor. You add
 `@export var armor: float` to Player.gd, then update every upgrade
 that's supposed to interact with it, then update the HUD, then update save/load…
 The chain of changes never ends. A Resource breaks this chain: every stat lives
 in one object that anyone can read and write.
:::

A **Resource** is a Godot data container — it has exported properties,
 can be saved as a `.tres` file, and can be shared by reference across
 multiple nodes. When an upgrade modifies `player.stats.move_speed`,
 every system that reads `stats.move_speed` gets the new value
 automatically on the next frame. No events, no callbacks, no synchronisation.

Resource — extends RefCounted

A data container that can hold exported variables, be saved to disk as a
 `.tres` or `.res` file, and be loaded back by path.
 Resources are reference-counted — multiple nodes sharing the same Resource
 instance all see the same data. Subclassing Resource with `class_name`
 gives you a typed, Inspector-editable data object.

### PlayerStats.gd — annotated

```gdscript
## res://resources/PlayerStats.gd
##
## All numeric attributes for the player live here — not in Player.gd.
## Upgrades edit this resource; Player.gd reads it every frame.
## This separation means upgrades never need to touch Player.gd at all.

class_name PlayerStats
extends Resource

## ── Base attributes ───────────────────────────────────────────────────
## These are set in the Inspector on the .tres file.
## Think of them as the "default values" for a fresh run.

@export var max_hp: float        = 100.0   ## maximum HP this run can start with
@export var move_speed: float    = 120.0   ## pixels per second

## How far (in pixels) XP gems are automatically pulled toward the player.
## A larger magnet range means the player picks up gems without walking to them.
@export var magnet_range: float  = 80.0

## Multiplier applied to all XP gained. At 1.0 a 5-XP gem gives 5 XP.
## At 2.0 it gives 10. Upgrades set this above 1.0.
@export var xp_multiplier: float = 1.0

## Flat damage subtracted from every hit. armor=10 means a 15-damage hit
## deals only 5 effective damage. Prevents one-shotting the player early.
@export var armor: float         = 0.0

## ── Runtime state ─────────────────────────────────────────────────────
## These are NOT exported — they change every second during a run and would
## be confusing to show in the Inspector.

var current_hp: float            ## set in reset(); decreases as player takes damage
var current_xp: float   = 0.0   ## accumulated XP within the current level
var level: int          = 1      ## current player level; starts at 1
var xp_to_next: float   = 50.0  ## XP required to reach the next level

## Called at the start of every run and scene reload.
## Ensures a fresh run always starts from max HP and level 1,
## even if the Resource object was modified during a previous run.
func reset() -> void:
    current_hp  = max_hp
    current_xp  = 0.0
    level       = 1
    xp_to_next  = 50.0
```

:::callout-pitfall[Resources are shared by reference — reset() is essential]
When Godot reloads a scene, it does *not* automatically reset the
 `.tres` Resource to its default values. If the player died at 0 HP,
 `current_hp` is still 0 when the scene reloads.
 `reset()` in `Player._ready()` is what fixes this.
 If you ever notice a run starting at 0 HP, you forgot to call `reset()`.
:::

### Creating the .tres file

1. In FileSystem, right-click the `res://resources/` folder → **New Resource**.
2. In the search box type **PlayerStats** and select it. Save as `player_stats.tres`.
3. The resource opens in the Inspector. Set your base values: max\_hp=100, move\_speed=120, magnet\_range=80.
4. You'll assign this file to the Player node's `stats` export slot later. For now just save it.

## 3. Building Player.tscn Step by Step

The Player scene is a tree of six nodes. Each node serves exactly one purpose —
 understanding the purpose before adding the node will prevent you from adding nodes
 you don't need and missing nodes you do.

```
Player (CharacterBody2D)         ← the physics body; owns movement
├── CollisionShape2D             ← defines the body's solid shape for wall collisions
├── Sprite2D                     ← the visual — just a circle for now
├── HurtBox (Area2D)             ← detects when enemy HitBoxes touch the player
│   └── CollisionShape2D
├── MagnetArea (Area2D)          ← detects when XP gems are close enough to attract
│   └── CollisionShape2D
├── WeaponHolder (Node2D)        ← parent node; weapon scenes attach as children
└── Camera2D                     ← follows the player; limits set by Main.gd
```

Notice that **damage detection** (HurtBox) and
 **physics movement** (CharacterBody2D shape) use separate nodes with
 separate collision shapes. This is intentional — explained in section 4.

1. **Root node.** Scene → New Scene → root: `CharacterBody2D`,
 rename to **Player**. Save as `res://scenes/player/Player.tscn`.
 Set: `motion_mode = FLOATING`, `collision_layer = 2`,
 `collision_mask = 1` (walls) + `4` (enemies) = bitmask 5.
2. **CollisionShape2D** — Add child, select CollisionShape2D.
 In Inspector → Shape → New `CapsuleShape2D`. Radius: `14`,
 Height: `20`. This shape is what slides along walls.
 The capsule's rounded ends prevent the player from getting stuck on tile corners.
3. **Sprite2D** — Add child, assign a 32×32 placeholder sprite
 (a solid-colour circle works perfectly). This is purely visual — it has no
 collision and does not affect movement.
4. **HurtBox (Area2D)** — Add child Area2D, rename **HurtBox**.
 Inspector: `collision_layer = 2`, `collision_mask = 4`
 (detects Enemy HitBoxes on layer 4). `monitoring = true`.
 Add a `CollisionShape2D` child with CircleShape2D radius `14`.
5. **MagnetArea (Area2D)** — Add child Area2D, rename **MagnetArea**.
 Inspector: `collision_layer = 2`, `collision_mask = 3`
 (detects XP gems on layer 3). `monitoring = true`.
 Add a `CollisionShape2D` child with CircleShape2D radius `80`
 (will be resized from `stats.magnet_range` at runtime).
6. **WeaponHolder (Node2D)** — Add child Node2D, rename **WeaponHolder**.
 Add it to group `"weapon_holder"`.
 No other settings needed — weapon scenes will parent themselves here in Ch 71D.
7. **Camera2D** — Add child Camera2D.
 Set `zoom = Vector2(1.5, 1.5)` (shows a smaller portion of the world,
 making enemies feel closer and more threatening),
 `position_smoothing_enabled = true`,
 `position_smoothing_speed = 5.0`.
 Leave limits at default — Main.gd will set them at runtime using the tilemap bounds.

:::callout-tip[Why zoom 1.5 and not 1.0?]
At zoom 1.0, a 1920×1080 viewport shows 1920 px of the 4096 px world — nearly
 half the map at once. Enemies spawning off the edge of the screen would appear
 surprisingly far away and the game would feel empty. At zoom 1.5, you see only
 1280×720 px — enemies are much closer and the horde feels more dangerous.
:::

## 4. HurtBox vs. CollisionShape2D — Why Two Shapes?

:::callout-intuition[The key distinction]
A CharacterBody2D's CollisionShape2D is part of the **physics engine** —
 it prevents the body from passing through walls and other solid bodies.
 A HurtBox Area2D is part of the **area overlap system** — it detects
 when other Area2Ds enter the same space, without any physical effect.
 These are two entirely separate systems in Godot, running in parallel.
:::

When the player walks into a wall, the physics engine resolves the collision using
 the CharacterBody2D's CollisionShape2D. The enemy's HitBox Area2D, which is on
 Layer 4, never interacts with this physics resolution — it's invisible to the
 physics engine. The HurtBox Area2D, meanwhile, is watching for Area2D overlaps on
 Layer 4. When an enemy's HitBox enters the HurtBox, an `area_entered`
 signal fires — no physics involved, just a spatial query.

This separation is powerful: you can resize the HurtBox independently of the
 physics shape. Want enemies to deal damage when their *weapon* swings nearby
 but not when their body walks past? Make the HurtBox smaller than the
 CollisionShape2D. Want a "magnetic" larger hitbox for collectibles?
 Make the Area2D bigger. The two shapes are completely independent.

:::example[Worked example — following a damage signal]
A Bat enemy walks into the player. Trace exactly which signals fire and which don't.

::::answer[Answer]
The physics collision fires, but NOT the damage signal — yet.
::::

**What happens:**

1. Bat's CharacterBody2D (Layer 4) is moving toward the player's CharacterBody2D (Layer 2). Their collision masks include each other's layers → the physics engine blocks them from overlapping. The Bat stops or slides around the player. *No damage yet.*
2. The Bat also has a HitBox (Area2D, Layer 4). This HitBox *does* overlap with the player's body because Area2D nodes pass through physics bodies — they only interact with other Area2Ds.
3. The Bat's HitBox enters the player's HurtBox (Area2D, Layer 2, Mask 4). Both are Area2Ds. The overlap system fires `player.HurtBox.area_entered(bat_hitbox)`.
4. Player's `_on_hurt_box_area_entered()` runs → damage applied.
:::

## 5. Movement — A Deep Dive into move\_and\_slide()

:::callout-intuition[What move\_and\_slide() actually does]
It's not magic. `move_and_slide()` takes the current
 `velocity`, calculates how far the body would move this frame,
 checks for collisions along that path, and if it hits something, slides the
 remaining movement along the surface instead of stopping. That "sliding"
 is why you can walk diagonally along a wall without getting stuck.
:::

### The movement code — line by line

```gdscript
func _physics_process(delta: float) -> void:
    ## Input.get_vector() reads four named actions and returns a Vector2.
    ## The four arguments are: negative-X, positive-X, negative-Y, positive-Y.
    ## Result: (-1,0) when only A is held, (0.707, -0.707) when W+D are held, etc.
    ## It automatically normalises the result — diagonal is NOT faster than cardinal.
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")

    ## Multiply the normalised direction by the speed value from our stats resource.
    ## This is all we need to set velocity — no acceleration, no lerp, no friction.
    ## Vampire Survivors-style movement is instant and crisp, not floaty.
    velocity = dir * stats.move_speed

    ## move_and_slide() reads self.velocity, moves the body, and resolves wall collisions.
    ## It also MODIFIES self.velocity to reflect what actually happened
    ## (e.g. if you hit a wall at 45°, velocity gets adjusted to the slide direction).
    ## We don't need the return value here.
    move_and_slide()

    ## Flip the sprite to face the direction of movement.
    ## Only flip on horizontal movement — don't flip while moving purely vertically.
    if dir.x != 0.0:
        $Sprite2D.flip_h = dir.x < 0.0
```

:::callout-pitfall[get\_vector() vs. two get\_axis() calls]
A common mistake is:

```gdscript
## WRONG — diagonal movement is 41% faster than cardinal
var dir := Vector2(
    Input.get_axis("move_left", "move_right"),
    Input.get_axis("move_up", "move_down")
)
```

When both axes are non-zero (diagonal), this vector has length √2 ≈ 1.414.
 Multiplying by `move_speed` gives a diagonal speed of
 120 × 1.414 = 169 px/s instead of 120. `get_vector()` internally
 calls `.normalized()` before returning, so the result always has
 length ≤ 1.0. One function call solves the problem.
:::

:::example[Worked example — why instant stopping feels right]
Should the player decelerate smoothly when the key is released, or stop instantly?

::::answer[Answer]
Instant stop. Here's why.
::::

In platformers, smooth deceleration feels realistic — the character is running
 on a surface with friction. In a top-down arena game, the player is making
 split-second decisions to dodge 200 enemies. If the character keeps sliding
 after releasing the key, the player loses precise control exactly when they
 need it most. Vampire Survivors and its clones all use instant-stop movement
 for this reason. The code achieves this by setting `velocity` directly
 every frame from the input — there's no "previous velocity" being lerped.
 When input is zero, `dir = (0,0)`, `velocity = (0,0)`,
 the body stops.
:::

### Why \_physics\_process and not \_process?

`_physics_process(delta)` runs in sync with the physics engine at a
 fixed rate (60 Hz in our project settings). `move_and_slide()` must
 be called here — calling it in `_process` would cause inconsistent
 collision behaviour at different frame rates. Any code that affects the physics
 body's position or velocity goes in `_physics_process`.
 UI updates, visual effects, and non-physics logic go in `_process`.

## 6. Damage, Armor, and Invincibility Frames

### The damage pipeline

When an enemy's HitBox overlaps the player's HurtBox, a signal fires.
 The damage calculation happens in the Player, not the enemy — this keeps all
 player-side logic in one place and lets enemies simply declare how much damage
 they deal, without knowing anything about player armor or shields.

```gdscript
## Signal handler — runs when any Area2D enters the HurtBox.
func _on_hurt_box_area_entered(area: Area2D) -> void:
    ## Filter: only react to areas in the "enemy_hitbox" group.
    ## This prevents the HurtBox from reacting to other Area2Ds (XP gems, etc.)
    ## that happen to share collision layers.
    if not area.is_in_group("enemy_hitbox"):
        return

    ## Check the invincibility frame cooldown (see below).
    if _hurt_cooldown > 0.0:
        return

    ## Set the cooldown timer — the player is now invincible for 0.5 s.
    _hurt_cooldown = HURT_IFRAMES

    ## Get the enemy node (HitBox's parent is the Enemy node).
    var enemy := area.get_parent() as EnemyBase
    if enemy:
        take_damage(enemy.damage)
```

```gdscript
## The actual damage application.
## Separated from the signal handler so other systems (traps, poison) can call it.
func take_damage(amount: float) -> void:
    ## stats.armor is flat reduction. maxf(0.0, ...) ensures we never heal from a hit.
    ## Example: amount=15, armor=10 → effective=5. amount=8, armor=10 → effective=0.
    var effective := maxf(0.0, amount - stats.armor)

    ## Reduce HP, but never below 0.
    stats.current_hp = maxf(0.0, stats.current_hp - effective)

    ## Tell the HUD the HP changed.
    hp_changed.emit(stats.current_hp, stats.max_hp)

    if stats.current_hp <= 0.0:
        _die()
```

### Invincibility frames (I-frames)

Without I-frames, an enemy standing on top of the player would apply its
 `damage` value on *every physics frame* — 60 times per second.
 A 10-damage enemy with a 1 s overlap would deal 600 damage instead of 10.
 I-frames prevent this by setting a cooldown timer after each hit.

```gdscript
## How long the player is immune after taking a hit.
const HURT_IFRAMES: float = 0.5   ## half a second

## Counts down from HURT_IFRAMES to 0. While > 0, damage is ignored.
var _hurt_cooldown: float = 0.0

func _physics_process(delta: float) -> void:
    ## Tick down the cooldown every frame.
    ## Using _physics_process (not _process) keeps this in sync with physics.
    if _hurt_cooldown > 0.0:
        _hurt_cooldown -= delta
    ## ... movement code below ...
```

:::callout-tip[Visual feedback during i-frames]
Without a visual cue the player can't tell they're invincible — they'll keep
 trying to dodge hits that can't hurt them. A simple modulate flash communicates
 the i-frame window:

```gdscript
func _flash_hurt() -> void:
    ## Flash red 3 times over 0.45 seconds.
    for i in 3:
        $Sprite2D.modulate = Color(1, 0.3, 0.3)   ## red tint
        await get_tree().create_timer(0.075).timeout
        $Sprite2D.modulate = Color.WHITE
        await get_tree().create_timer(0.075).timeout
```

Call `_flash_hurt()` at the start of `take_damage()`.
 The `await` runs asynchronously — it doesn't block the rest of the
 game loop.
:::

## 7. The XP System — Gaining XP and Levelling Up

When an XP gem reaches the player (handled by the gem itself in Ch 71C),
 it calls `player.gain_xp(value)`. Player.gd handles the accumulation
 and checks whether a level-up threshold has been crossed.

```gdscript
## Called by XpGem when it reaches the player.
## amount is the raw gem value (e.g. 5 for a Bat, 40 for a Golem).
func gain_xp(amount: float) -> void:
    ## Apply the XP multiplier from stats. An upgrade that sets xp_multiplier=2.0
    ## makes every gem worth twice as much without changing any gem values.
    stats.current_xp += amount * stats.xp_multiplier

    ## Emit signal so the HUD can update the XP bar.
    xp_changed.emit(stats.current_xp, stats.xp_to_next)

    ## Check for level-up. Use >= not == because a large gem might jump
    ## over the threshold (e.g. 45 XP → +40 = 85, threshold was 50).
    if stats.current_xp >= stats.xp_to_next:
        _level_up()

func _level_up() -> void:
    ## Subtract the threshold — keep the overflow XP for the new level.
    ## Example: had 45, gained 40, threshold was 50.
    ## After: current_xp = 85 - 50 = 35. Those 35 XP count toward level 3.
    stats.current_xp -= stats.xp_to_next

    ## Advance the level counter.
    stats.level += 1

    ## Scale the next threshold by 25% — each level takes more XP to earn.
    ## floor() keeps it a clean integer.
    stats.xp_to_next = floor(stats.xp_to_next * 1.25)

    ## Hand off to GameManager which pauses the tree and shows upgrade cards.
    GameManager.trigger_level_up()
```

:::example[Worked example — three consecutive level-ups]
A player at level 1 picks up three gems: 30 XP, 40 XP, 20 XP. Threshold starts at 50. Trace the state after each pickup.

::::answer[Answer]
The player levels up twice across these three gems.
::::

| Gem | XP gained | current\_xp before | current\_xp after | Level-up? | New threshold |
| --- | --- | --- | --- | --- | --- |
| 30 XP | 30 | 0 | 30 | No (30 < 50) | 50 |
| 40 XP | 40 | 30 | 70 → 70-50=20 | Yes → level 2 | floor(50×1.25)=62 |
| 20 XP | 20 | 20 | 40 | No (40 < 62) | 62 |

After the second gem, `current_xp = 20` (the overflow), `level = 2`,
 `xp_to_next = 62`. The third gem brings XP to 40 — not yet enough for level 3.
:::

## 8. MagnetArea — How XP Gems Get Attracted

:::callout-intuition[How the magnet works]
The MagnetArea is a large invisible circle around the player. When an XP gem
 (an Area2D) drifts into this circle, the MagnetArea's
 `area_entered` signal fires. Player.gd then tells the gem to start
 moving toward the player. The gem handles its own movement — Player.gd just
 introduces them.
:::

```gdscript
@onready var magnet_shape: CollisionShape2D = $MagnetArea/CollisionShape2D

func _ready() -> void:
    ## Resize the magnet's CollisionShape to match stats.magnet_range.
    ## This way, an upgrade that increases magnet_range automatically makes
    ## the Area2D bigger — no separate "resize the shape" code needed.
    (magnet_shape.shape as CircleShape2D).radius = stats.magnet_range

    ## Connect MagnetArea's signal. When any Area2D enters the magnet circle,
    ## this function runs.
    $MagnetArea.area_entered.connect(_on_magnet_area_entered)

func _on_magnet_area_entered(area: Area2D) -> void:
    ## area is whatever Area2D entered. We only care about XP gems.
    ## get_parent() gives us the XpGem node (gem's root is the parent of the Area2D).
    var gem := area.get_parent() as XpGem
    if gem:
        gem.start_attract(self)   ## tell the gem to start chasing this player
```

### Upgrading magnet range at runtime

```gdscript
## Call this after any upgrade that increases stats.magnet_range.
## Without this, the Area2D size stays at the old value even though stats changed.
func refresh_magnet_radius() -> void:
    (magnet_shape.shape as CircleShape2D).radius = stats.magnet_range
```

:::callout-pitfall[Changing stats doesn't automatically resize shapes]
Setting `stats.magnet_range = 150.0` has no immediate effect on
 the CollisionShape2D — the shape was sized once in `_ready()` and
 sits there unchanged. You must explicitly call `refresh_magnet_radius()`
 after any upgrade that modifies magnet range. This is a common source of
 "my upgrade isn't working" bugs.
:::

## 9. WeaponHolder — The Plug-In Weapon System

WeaponHolder is a `Node2D` with no script — it is purely an
 organisational node. Weapon scenes are instantiated and added as its children
 at runtime. Player.gd never calls any weapon methods; it just provides the
 mounting point.

This design means you can add any number of weapons, remove them, or swap them
 without writing a single line in Player.gd. The player doesn't know it's holding
 a sword vs. a wand — it just has children under WeaponHolder, and those children
 fire themselves.

```gdscript
@onready var weapon_holder: Node2D = $WeaponHolder

## Called by UpgradeScreen when the player chooses "Add Garlic" or "Add Magic Wand".
## scene is a PackedScene (the .tscn file of the weapon).
func add_weapon(scene: PackedScene) -> void:
    var weapon = scene.instantiate()
    ## Adding as a child of WeaponHolder means the weapon can find the Player
    ## by walking up the tree: get_parent() = WeaponHolder, get_parent() = Player.
    weapon_holder.add_child(weapon)

## Called by UpgradeScreen when the player chooses a weapon upgrade.
## Finds the weapon of the given class and applies the upgrade resource to it.
func upgrade_weapon(weapon_class_name: String, upgrade: Resource) -> void:
    for child in weapon_holder.get_children():
        ## get_script().get_global_name() returns the class_name of the script.
        if child.get_script() and child.get_script().get_global_name() == weapon_class_name:
            child.apply_upgrade(upgrade)
            return   ## stop after finding the first match
```

:::callout-connect[Connection to Ch 71D (Weapons)]
In Ch 71D, weapon scripts use `get_parent().get_parent()` to find
 the Player node: `WeaponHolder.get_parent() = Player`. This parent-chain
 lookup is the only coupling between weapons and the player — no signals, no
 exported references. If you ever restructure the scene tree, just update the
 chain in WeaponBase.\_ready() and nothing else changes.
:::

## 10. Full Player.gd

Everything from sections 5–9 assembled in one file. Each section is clearly
 labelled with comment headers.

```gdscript
class_name Player
extends CharacterBody2D

## ── Exports ───────────────────────────────────────────────────────────
@export var stats: PlayerStats   ## assign player_stats.tres in the Inspector

## ── Signals ───────────────────────────────────────────────────────────
## Consumed by HUD to update progress bars.
signal hp_changed(new_hp: float, max_hp: float)
signal xp_changed(new_xp: float, needed: float)
## Consumed by GameManager.
signal died

## ── Node references ───────────────────────────────────────────────────
@onready var magnet_shape: CollisionShape2D = $MagnetArea/CollisionShape2D
@onready var weapon_holder: Node2D          = $WeaponHolder

## ── I-frame state ─────────────────────────────────────────────────────
const HURT_IFRAMES: float = 0.5
var _hurt_cooldown: float = 0.0

## ── Lifecycle ─────────────────────────────────────────────────────────
func _ready() -> void:
    add_to_group("player")
    ## Ensure runtime state is fresh — crucial on scene reload.
    if stats == null:
        stats = PlayerStats.new()
    stats.reset()
    ## Size magnet from stats resource.
    (magnet_shape.shape as CircleShape2D).radius = stats.magnet_range
    ## Wire Area2D signals.
    $HurtBox.area_entered.connect(_on_hurt_box_area_entered)
    $MagnetArea.area_entered.connect(_on_magnet_area_entered)

## ── Movement ──────────────────────────────────────────────────────────
func _physics_process(delta: float) -> void:
    if _hurt_cooldown > 0.0:
        _hurt_cooldown -= delta
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity = dir * stats.move_speed
    move_and_slide()
    if dir.x != 0.0:
        $Sprite2D.flip_h = dir.x < 0.0

## ── Damage ────────────────────────────────────────────────────────────
func _on_hurt_box_area_entered(area: Area2D) -> void:
    if not area.is_in_group("enemy_hitbox"): return
    if _hurt_cooldown > 0.0: return
    _hurt_cooldown = HURT_IFRAMES
    var enemy := area.get_parent() as EnemyBase
    if enemy:
        take_damage(enemy.damage)

func take_damage(amount: float) -> void:
    var effective := maxf(0.0, amount - stats.armor)
    stats.current_hp = maxf(0.0, stats.current_hp - effective)
    hp_changed.emit(stats.current_hp, stats.max_hp)
    _flash_hurt()
    if stats.current_hp <= 0.0:
        _die()

func _flash_hurt() -> void:
    for i in 3:
        $Sprite2D.modulate = Color(1, 0.3, 0.3)
        await get_tree().create_timer(0.075).timeout
        $Sprite2D.modulate = Color.WHITE
        await get_tree().create_timer(0.075).timeout

func _die() -> void:
    died.emit()
    GameManager.game_over()

## ── XP & Levelling ────────────────────────────────────────────────────
func gain_xp(amount: float) -> void:
    stats.current_xp += amount * stats.xp_multiplier
    xp_changed.emit(stats.current_xp, stats.xp_to_next)
    if stats.current_xp >= stats.xp_to_next:
        _level_up()

func _level_up() -> void:
    stats.current_xp -= stats.xp_to_next
    stats.level += 1
    stats.xp_to_next = floor(stats.xp_to_next * 1.25)
    GameManager.trigger_level_up()

## ── Magnet ────────────────────────────────────────────────────────────
func _on_magnet_area_entered(area: Area2D) -> void:
    var gem := area.get_parent() as XpGem
    if gem:
        gem.start_attract(self)

func refresh_magnet_radius() -> void:
    (magnet_shape.shape as CircleShape2D).radius = stats.magnet_range

## ── Weapons ───────────────────────────────────────────────────────────
func add_weapon(scene: PackedScene) -> void:
    weapon_holder.add_child(scene.instantiate())

func upgrade_weapon(class_name_str: String, upgrade: Resource) -> void:
    for w in weapon_holder.get_children():
        if w.get_script() and w.get_script().get_global_name() == class_name_str:
            w.apply_upgrade(upgrade)
            return
```

## 11. Wiring the Player into Main.tscn

1. In Main.tscn, with Main selected: Instance Child Scene → choose `Player.tscn`. Position at `(0, 0)`.
2. Select the Player node. Inspector → `stats` → assign `player_stats.tres`.
3. In Main.gd `_ready()`, after pool registration, connect player signals and start the run (see below).

```gdscript
## In Main.gd _ready():
var player := $Player as Player

## Wire player signals to HUD so HP and XP bars update live.
player.hp_changed.connect($HUD.on_hp_changed)
player.xp_changed.connect($HUD.on_xp_changed)

## Apply camera limits now that the player's Camera2D is in the scene tree.
_apply_camera_limits()

## Hand the player reference to GameManager and start the run.
GameManager.start_run(player)
```

### Quick test checklist

Press F5 and confirm each of these before moving on to Ch 71C:

- Player moves with WASD. Speed feels correct (not too fast or slow).
- Player sprite flips left/right based on movement direction.
- Player stops instantly when keys are released — no sliding.
- Player collides with tile walls and slides along them without sticking.
- Camera follows the player and stops at the world boundary.
- No errors in the Output panel.

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
Explain the difference between `collision_layer` and
 `collision_mask` on CharacterBody2D. If the Player is on Layer 2
 and needs to bump into walls (Layer 1), which one needs to include Layer 1?

::::solution[Solution]
**collision\_layer** is "what layer *this body* exists on" — it
 tells other objects which layer to scan to find this body.

 **collision\_mask** is "which layers *this body* scans for collisions"
 — it determines what the body can bump into.

 To collide with walls, the Player's **collision\_mask** must include
 Layer 1. The player is saying "I want to detect and collide with things on Layer 1."
 Layer is about being *found*; mask is about *finding*.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
A player has `stats.armor = 15`. An enemy deals
 `damage = 12`. How much HP does the player lose, and why?

::::solution[Solution]
`effective = maxf(0.0, 12 - 15) = maxf(0.0, -3) = 0.0`.
 The player loses **0 HP**. The hit is fully absorbed by armor.
 The `maxf(0.0, ...)` clamp is essential here — without it,
 the player would gain 3 HP from a hit that didn't penetrate their armor.
::::
:::

:::problem[Problem 3 easy]{difficulty="easy"}
After a hit, the player has `_hurt_cooldown = 0.5`.
 How many physics frames at 60 fps pass before the player can be hurt again?

::::solution[Solution]
Each physics frame, `delta ≈ 1/60 ≈ 0.01667 s` is subtracted.
 Frames needed: `0.5 / 0.01667 ≈ 30 frames`.
 The player is immune for exactly 30 physics frames — half a second.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
A player is at level 3. `xp_to_next` is 78.
 The player picks up a gem worth 100 XP (dropped by a boss).
 `xp_multiplier = 1.5`. Walk through the full
 `gain_xp` call and state the values of all stats after it completes.

::::solution[Solution]
**Step 1:** `amount * multiplier = 100 * 1.5 = 150 XP gained`.

 **Step 2:** Assuming `current_xp = 30` before pickup:
 `current_xp = 30 + 150 = 180`.

 **Step 3:** `180 ≥ 78` → `_level_up()` called.

 **Step 4:** `current_xp = 180 - 78 = 102`. `level = 4`.
 `xp_to_next = floor(78 * 1.25) = floor(97.5) = 97`.

 **Step 5:** `102 ≥ 97` → `_level_up()` called again!

 **Step 6:** `current_xp = 102 - 97 = 5`. `level = 5`.
 `xp_to_next = floor(97 * 1.25) = floor(121.25) = 121`.

 **Step 7:** `5 < 121` → no more level-ups.

 **Final state:** level=5, current\_xp=5, xp\_to\_next=121.
 *Two level-ups from one gem.*
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
Why does `_level_up()` call `GameManager.trigger_level_up()`
 rather than directly calling `get_tree().paused = true`
 and showing the upgrade screen itself?

::::solution[Solution]
Separation of concerns. Player.gd should not know that a level-up causes
 the game to pause and an upgrade UI to appear — those are *game flow*
 decisions, not player decisions. If the game later adds a "quick upgrade"
 mode where the game doesn't pause, only GameManager changes. If Player.gd
 directly paused the tree and called UpgradeScreen, you'd have to edit Player.gd
 to change that behaviour. By routing through GameManager, Player.gd stays
 stable regardless of how the rest of the game changes.
::::
:::

:::problem[Problem 6 standard]{difficulty="standard"}
The `_flash_hurt()` function uses `await` inside a loop.
 Explain why this doesn't freeze the game, and what would happen if you replaced
 the `await` with a blocking loop.

::::solution[Solution]
`await` in GDScript makes the function into a coroutine — it
 suspends *that function* and returns control to the engine until the
 timer expires. The game continues running normally (physics, other nodes, input)
 while the flash waits.

 A blocking loop like `while Time.get_ticks_msec() < end_time: pass`
 would run on the main thread without yielding control. The game would freeze
 completely for 0.45 seconds — no physics, no rendering, no input. In
 multiplayer this would cause a desync. `await` is the correct
 pattern for any time-delayed effect in a running game.
::::
:::

:::problem[Problem 7 challenge]{difficulty="challenge"}
Implement a **shield charge**: the player gains a shield that
 absorbs the next hit completely (regardless of damage), then disappears.
 The shield is visually shown as a blue ring around the player.
 Design the complete implementation: what variable stores shield state,
 where does the visual ring come from, and where in `take_damage()`
 does the check go?

::::solution[Solution]
```gdscript
## In Player.gd — add these:
var _has_shield: bool = false

## Called by the ShieldUpgrade resource's apply() method.
func activate_shield() -> void:
    _has_shield = true
    $ShieldRing.visible = true   ## ShieldRing is a Sprite2D child node

## Modified take_damage():
func take_damage(amount: float) -> void:
    if _has_shield:
        ## Absorb the hit entirely.
        _has_shield = false
        $ShieldRing.visible = false
        ## Play a breaking effect here (Ch 71G).
        return
    var effective := maxf(0.0, amount - stats.armor)
    stats.current_hp = maxf(0.0, stats.current_hp - effective)
    hp_changed.emit(stats.current_hp, stats.max_hp)
    _flash_hurt()
    if stats.current_hp <= 0.0:
        _die()
```

ShieldRing is a Sprite2D child of Player with a blue ring texture, set
 to `visible = false` by default. The shield activates on upgrade
 pick, persists until the next hit, then disappears. The check is at the
 *top* of `take_damage()` — before armor, before HP reduction,
 before flash — so a shielded player is completely immune.
::::
:::

## Summary

:::summary
## Chapter 71B — Key Concepts

| Concept | Implementation | Why this way |
| --- | --- | --- |
| Node type | CharacterBody2D + motion\_mode=FLOATING | Script-driven movement; no physics momentum fighting you |
| Stats | PlayerStats Resource (.tres file) | Single source of truth; upgrades edit one object; no Player.gd changes needed |
| Movement | Input.get\_vector() → velocity → move\_and\_slide() | get\_vector() normalises diagonals; instant-stop movement is intentional for responsiveness |
| Damage detection | HurtBox Area2D, group "enemy\_hitbox" filter | Separates physics collision from damage detection; flexible sizing |
| I-frames | \_hurt\_cooldown float, decremented in \_physics\_process | Prevents 60× per second damage from persistent overlaps |
| XP overflow | current\_xp -= xp\_to\_next (keeps overflow) | One large gem can grant two levels; no XP is lost |
| Magnet | Area2D sized from stats.magnet\_range; calls gem.start\_attract() | Gem handles its own movement; player just introduces them |
| Weapons | WeaponHolder Node2D; add\_weapon() / upgrade\_weapon() | Weapons are children; player never knows what weapons do |
:::

With the player moving, taking damage, and gaining XP, the next step is building
 something for the player to fight. **Ch 71C** builds three enemy types
 using NavigationAgent2D pathfinding, an escalating wave spawner, and the XP gem
 drop system that connects back to this chapter's `gain_xp()`.
