---
title: "Editor Plugins & @tool Scripts"
source: "godot_ch40_plugin_tools.html"
---

Part IV · Chapter 40

# Editor Plugins & @tool Scripts

Prerequisite: Ch 3 (GDScript), Ch 6 (Resources) · est. 85 min

## Overview

The Godot editor is itself a Godot game. Every inspector panel, every
 toolbar button, every viewport gizmo is a normal node tree running
 GDScript. That design means you can extend the editor with exactly
 the same skills you use to build games — no separate plugin API to
 learn from scratch.

There are two tiers of editor extension:

- **@tool scripts** — a single annotation that makes a
 script run inside the editor process. Perfect for
 procedural mesh preview, smart export validation, or custom
 in-viewport drawing.
- **EditorPlugin** — a first-class plugin registered
 with the editor. Provides new main-screen tabs, dock panels,
 toolbar buttons, custom inspector widgets, and custom import
 pipelines.

This chapter covers both tiers end-to-end, plus the undo/redo API
 every editor tool must respect.

## 1 · @tool Scripts

### Running code in the editor

Add `@tool` as the very first line of a GDScript file.
 The script then executes both in the editor *and* at runtime.
 Without `@tool`, `_ready()`,
 `_process()`, and all other callbacks are silenced in the
 editor — the node exists but does nothing.

```gdscript
@tool
extends Node2D

@export var point_count: int = 8 :
    set(v):
        point_count = v
        _rebuild()          # re-run when inspector changes the value

func _ready() -> void:
    _rebuild()

func _rebuild() -> void:
    # Example: draw a regular polygon outline using Line2D children
    var line: Line2D = $Line2D
    line.clear_points()
    for i in range(point_count + 1):
        var angle := TAU * i / point_count
        line.add_point(Vector2(cos(angle), sin(angle)) * 64.0)
```

With this script on a `Node2D`, dragging the
 `point_count` slider in the inspector immediately updates
 the polygon outline in the 2D viewport — no play button required.

:::callout-warning[Warning]
Code inside `@tool` scripts runs in the editor process.
 A crash (null dereference, infinite loop) will crash the editor,
 not just the game. Guard against null children and clamp
 user-supplied values before using them in calculations.
:::

### Editor-visible @export with setters

The real power of `@tool` comes from pairing
 `@export` properties with setters that immediately
 react to inspector changes. The setter pattern is:

```gdscript
@tool
extends MeshInstance3D

@export var subdivisions: int = 4 :
    set(v):
        subdivisions = clampi(v, 1, 32)
        _generate_mesh()

@export var radius: float = 1.0 :
    set(v):
        radius = maxf(v, 0.01)
        _generate_mesh()

func _ready() -> void:
    _generate_mesh()

func _generate_mesh() -> void:
    if not is_inside_tree():
        return     # guard: node may not be fully initialised yet
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    # ... build sphere geometry procedurally ...
    mesh = st.commit()
```

:::callout-tip[Tip]
Always call `is_inside_tree()` at the top of your
 `@tool` builder functions. The editor may call your
 setter before `_ready()` when deserialising a saved
 scene, at which point child nodes or the tree may not yet be
 available.
:::

### Custom in-viewport gizmos

For 3D nodes, override `_get_configuration_warnings()` to
 display inspector warnings, and implement
 `EditorNode3DGizmoPlugin` to draw custom overlays in the
 3D viewport. For simpler per-node drawing, override
 `_draw()` on a `@tool Node2D` and call
 `queue_redraw()` from the setter:

```gdscript
@tool
extends Node2D

@export var detection_radius: float = 150.0 :
    set(v):
        detection_radius = maxf(v, 0.0)
        queue_redraw()     # triggers _draw() in the editor viewport

func _draw() -> void:
    if Engine.is_editor_hint():
        # Draw a semi-transparent circle showing the detection range
        draw_arc(Vector2.ZERO, detection_radius,
                 0, TAU, 64, Color(0.2, 0.8, 1.0, 0.4), 2.0)
```

`Engine.is_editor_hint()` returns `true` when
 the script is running inside the editor, `false` at
 runtime. Use it to skip debug visualisations in shipped builds
 without needing a separate code path.

## 2 · EditorPlugin

An `EditorPlugin` is a scene or script that Godot loads
 as part of the editor itself. It has access to the full editor
 API: the scene tree, the selection, the filesystem, the undo/redo
 history, and every other open tool.

EditorPlugin — What a plugin can hook into

Godot Editor

EditorInterface

EditorSelection

EditorUndoRedoManager

@tool script

runs in editor context

InspectorPlugin

custom property widgets

ImportPlugin

custom asset importer

Main Screen tab

custom editor panel

Gizmo Plugin

3D viewport handles

Undo / Redo

history integration

All plugins declared via res://addons/my\_plugin/plugin.cfg → auto-loaded when enabled in Project Settings

An `EditorPlugin` is the central hook — it connects your code to the editor's API and registers sub-plugins (Inspector, Import, Gizmo) and custom UI panels. Everything flows through the single `plugin.cfg` declaration.

### plugin.cfg

Every plugin lives in its own folder under
 `res://addons/my_plugin/` and declares itself in a
 `plugin.cfg` file:

```ini
[plugin]
name="My Level Painter"
description="Paints objects onto the terrain with a brush."
author="Your Name"
version="1.0.0"
script="my_plugin.gd"
```

Activate the plugin via *Project → Project Settings →
 Plugins* → enable the toggle next to your plugin name. Godot
 instantiates the `script` class and calls
 `_enter_tree()`.

### EditorPlugin class

```gdscript
@tool
extends EditorPlugin

# Toolbar button
var _toolbar_btn: Button

func _enter_tree() -> void:
    # Add a button to the 3D viewport toolbar
    _toolbar_btn = Button.new()
    _toolbar_btn.text = "Paint Mode"
    _toolbar_btn.toggle_mode = true
    _toolbar_btn.pressed.connect(_on_paint_toggled)
    add_control_to_container(
        EditorPlugin.CONTAINER_SPATIAL_EDITOR_MENU,
        _toolbar_btn
    )

func _exit_tree() -> void:
    # Clean up everything added in _enter_tree
    if _toolbar_btn:
        remove_control_from_container(
            EditorPlugin.CONTAINER_SPATIAL_EDITOR_MENU,
            _toolbar_btn
        )
        _toolbar_btn.queue_free()

func _on_paint_toggled() -> void:
    print("Paint mode: ", _toolbar_btn.button_pressed)
```

The `CONTAINER_*` constants tell Godot *where*
 to attach your control:

| Constant | Location |
| --- | --- |
| `CONTAINER_TOOLBAR` | Top editor toolbar |
| `CONTAINER_SPATIAL_EDITOR_MENU` | 3D viewport top bar |
| `CONTAINER_CANVAS_EDITOR_MENU` | 2D viewport top bar |
| `CONTAINER_INSPECTOR_BOTTOM` | Below the inspector panel |
| `CONTAINER_PROJECT_SETTING_TAB_LEFT` | Project settings left tabs |

### Custom main-screen tab

To add a completely new screen (like the Script or AssetLib tabs)
 override three methods:

```gdscript
@tool
extends EditorPlugin

var _panel: Control

func _enter_tree() -> void:
    _panel = preload("res://addons/my_plugin/main_panel.tscn").instantiate()
    # Add to the editor's main screen area
    get_editor_interface().get_editor_main_screen().add_child(_panel)
    _panel.hide()

func _exit_tree() -> void:
    if _panel:
        _panel.queue_free()

# Called by the editor to decide whether to show the tab
func _has_main_screen() -> bool:
    return true

# The tab title
func _get_plugin_name() -> String:
    return "Level Painter"

# The tab icon (16×16 Texture2D)
func _get_plugin_icon() -> Texture2D:
    return preload("res://addons/my_plugin/icon.svg")

# Called when the user switches to/away from this tab
func _make_visible(visible: bool) -> void:
    if _panel:
        _panel.visible = visible
```

## 3 · EditorInspectorPlugin

An `EditorInspectorPlugin` replaces or augments how
 a specific property type or a specific class appears in the
 inspector. Register one inside your
 `EditorPlugin._enter_tree()`:

### Custom property widget

```gdscript
# my_plugin.gd  (EditorPlugin)
var _inspector_plugin: MyInspectorPlugin

func _enter_tree() -> void:
    _inspector_plugin = MyInspectorPlugin.new()
    add_inspector_plugin(_inspector_plugin)

func _exit_tree() -> void:
    remove_inspector_plugin(_inspector_plugin)
```

```gdscript
# my_inspector_plugin.gd
@tool
extends EditorInspectorPlugin

# Return true if you want to handle this object's properties
func _can_handle(object: Object) -> bool:
    return object is EnemyData    # custom Resource type

# Called for each property of handled objects
func _parse_property(
        object: Object,
        type: Variant.Type,
        name: String,
        hint_type: PropertyHint,
        hint_string: String,
        usage_flags: int,
        wide: bool) -> bool:

    if name == "difficulty_curve":
        # Replace the default editor for this property with a custom widget
        var widget := preload("res://addons/my_plugin/curve_widget.tscn").instantiate()
        widget.setup(object, name)
        add_property_editor(name, widget)
        return true    # true = we handled it, skip the default editor

    return false       # false = let Godot render it normally
```

:::callout-key[Key concept]
Returning `true` from `_parse_property`
 suppresses the built-in editor for that property and replaces it
 with whatever you added via `add_property_editor()`.
 Returning `false` passes through to the default
 inspector widget.
:::

## 4 · EditorImportPlugin

An `EditorImportPlugin` teaches Godot how to import
 a custom file format into a Resource. Once registered, your
 format appears in the *Import* dock alongside PNG, OGG,
 and GLTF.

### Importer class skeleton

```gdscript
@tool
extends EditorImportPlugin

# Unique string identifier — appears in Import → Importer dropdown
func _get_importer_name() -> String:
    return "com.mygame.csv_level_importer"

# Human-readable name
func _get_visible_name() -> String:
    return "CSV Level Data"

# File extensions this importer handles
func _get_recognized_extensions() -> PackedStringArray:
    return ["csv"]

# Resource type this importer produces
func _get_resource_type() -> String:
    return "Resource"

# Save path hint — the .import file will be saved alongside the source
func _get_save_extension() -> String:
    return "res"

# Priority when multiple importers match the same extension
func _get_priority() -> float:
    return 1.0

# Unique preset index for each combination of options
func _get_preset_count() -> int:
    return 1

func _get_preset_name(preset_index: int) -> String:
    return "Default"
```

### Import options and the import function

```gdscript
func _get_import_options(
        path: String, preset_index: int) -> Array[Dictionary]:
    return [
        {
            "name": "tile_size",
            "default_value": 64,
            "property_hint": PROPERTY_HINT_RANGE,
            "hint_string": "1,512,1"
        }
    ]

func _get_option_visibility(
        path: String,
        option_name: StringName,
        options: Dictionary) -> bool:
    return true   # show all options unconditionally

# The actual import — called by the editor when the file changes
func _import(
        source_file: String,
        save_path: String,
        options: Dictionary,
        platform_variants: Array[String],
        gen_files: Array[String]) -> Error:

    var tile_size: int = options.get("tile_size", 64)

    # Parse the CSV
    var file := FileAccess.open(source_file, FileAccess.READ)
    if file == null:
        return FAILED

    var level_data := Resource.new()
    # ... populate level_data from CSV rows ...

    # Save to the .import cache
    var full_path := "%s.%s" % [save_path, _get_save_extension()]
    return ResourceSaver.save(level_data, full_path)
```

Register the importer in your `EditorPlugin`:

```gdscript
var _importer: MyCsvImporter

func _enter_tree() -> void:
    _importer = MyCsvImporter.new()
    add_import_plugin(_importer)

func _exit_tree() -> void:
    remove_import_plugin(_importer)
```

:::callout-connect[Connect]
After registering, Godot's filesystem monitor detects any
 `.csv` file added to the project and automatically runs
 your importer, storing the result in the hidden
 `.godot/imported/` cache. The source
 `.csv` file still lives in `res://` but
 the engine loads the cached binary Resource at runtime.
:::

## 5 · Undo/Redo

Any editor action that modifies scene data must be wrapped in an
 `UndoRedo` action so the user can Ctrl+Z
 it. The editor's undo/redo history is accessed via
 `EditorPlugin.get_undo_redo()`.

### Committing an undoable action

```gdscript
func place_tile(pos: Vector2i, tile_id: int) -> void:
    var undo_redo := get_undo_redo()

    # 1. Name the action (shown in Edit menu history)
    undo_redo.create_action("Place Tile %s" % str(pos))

    # 2. "do" steps — what happens when the action is (re)done
    undo_redo.add_do_method(_tilemap, "set_cell",
        0, pos, tile_id, Vector2i.ZERO)

    # 3. "undo" steps — what happens when the action is undone
    var old_id: int = _tilemap.get_cell_source_id(0, pos)
    undo_redo.add_undo_method(_tilemap, "set_cell",
        0, pos, old_id, Vector2i.ZERO)

    # 4. Commit — this immediately executes the do steps
    undo_redo.commit_action()
```

Besides `add_do_method` / `add_undo_method`,
 the API also supports property assignments:

```gdscript
undo_redo.add_do_property(node, "position", new_pos)
undo_redo.add_undo_property(node, "position", old_pos)
```

And arbitrary references (useful when creating or deleting nodes):

```gdscript
# Creating a new node and registering it with undo:
undo_redo.create_action("Spawn Enemy")

undo_redo.add_do_method(self,   "_add_enemy",    new_enemy_scene, pos)
undo_redo.add_undo_method(self, "_remove_enemy", new_enemy_scene)

# Hold a reference so the node isn't garbage-collected during undo
undo_redo.add_do_reference(new_enemy_scene)
undo_redo.add_undo_reference(new_enemy_scene)

undo_redo.commit_action()
```

:::callout-pitfall[Pitfall]
Never modify scene state outside of a `create_action` /
 `commit_action` pair inside an editor tool. A direct
 assignment to a node property won't be tracked, the scene will be
 marked dirty, and Ctrl+Z will silently fail to reverse it.
:::

## Summary

Editor extensions range from a single `@tool` annotation
 to full multi-panel plugins. The key pieces:

| Need | Tool |
| --- | --- |
| Run GDScript in the editor viewport | `@tool` annotation on any script |
| Preview procedural content in-editor | `@tool` + `@export` setter + `_draw()` or mesh rebuild |
| Guard against editor-only crashes | `Engine.is_editor_hint()`, `is_inside_tree()` |
| Add toolbar buttons / dock panels | `EditorPlugin` + `add_control_to_container()` |
| Add a new main-screen tab | `_has_main_screen()`, `_get_plugin_name()`, `_make_visible()` |
| Custom inspector widget | `EditorInspectorPlugin` + `_parse_property()` |
| Import a custom file format | `EditorImportPlugin` + `_import()` |
| Undoable editor actions | `get_undo_redo()` → `create_action / add_do_* / add_undo_* / commit_action` |

## Mixed Practice

:::problem{difficulty="easy"}
**1. @tool guards.**
 A `@tool` script calls
 `$Sprite2D.modulate = Color.RED` inside a property
 setter. The editor prints a null-reference error when the scene
 first loads. Explain why, and write the corrected setter.

::::solution[Solution]
**Why:** When Godot deserialises a saved scene it
 calls the setter to restore the exported property value
 *before* the node enters the tree, so
 `$Sprite2D` does not exist yet. The
 `@onready` annotation is not active at this point
 because `_ready()` hasn't run.

```gdscript
@export var highlight: bool = false :
    set(v):
        highlight = v
        if not is_inside_tree():
            return          # node not ready yet — bail safely
        $Sprite2D.modulate = Color.RED if highlight else Color.WHITE
```
::::
:::

:::problem{difficulty="easy"}
**2. Detection-radius gizmo.**
 Write a complete `@tool Node2D` script with an
 `@export var detection_radius: float` that draws a
 dashed-style circle (use multiple short
 `draw_line` calls) in the 2D editor viewport only
 (not at runtime). The circle must update when the property
 changes in the inspector.

::::solution[Solution]
```gdscript
@tool
extends Node2D

@export var detection_radius: float = 100.0 :
    set(v):
        detection_radius = maxf(v, 0.0)
        queue_redraw()

func _draw() -> void:
    if not Engine.is_editor_hint():
        return
    var segments := 32
    var dash := true
    for i in segments:
        if dash:
            var a0 := TAU * i / segments
            var a1 := TAU * (i + 0.5) / segments
            draw_line(
                Vector2(cos(a0), sin(a0)) * detection_radius,
                Vector2(cos(a1), sin(a1)) * detection_radius,
                Color(0.3, 0.9, 1.0, 0.7), 2.0
            )
        dash = not dash
```
::::
:::

:::problem{difficulty="standard"}
**3. Minimal EditorPlugin.**
 Write a complete minimal plugin that adds a
 *single button* to the 2D viewport toolbar labelled
 **"Snap to Grid"**. When clicked it should print
 `"Snapping enabled"` or
 `"Snapping disabled"` depending on its toggle state.
 Include the `plugin.cfg` and the GDScript file.

::::solution[Solution]
```ini
# addons/snap_grid/plugin.cfg
[plugin]
name="Snap to Grid"
description="Adds a snap-to-grid toggle to the 2D toolbar."
author="Me"
version="1.0"
script="snap_grid.gd"
```

```gdscript
# addons/snap_grid/snap_grid.gd
@tool
extends EditorPlugin

var _btn: Button

func _enter_tree() -> void:
    _btn = Button.new()
    _btn.text = "Snap to Grid"
    _btn.toggle_mode = true
    _btn.toggled.connect(_on_toggled)
    add_control_to_container(
        EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU,
        _btn
    )

func _exit_tree() -> void:
    if _btn:
        remove_control_from_container(
            EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU,
            _btn
        )
        _btn.queue_free()
        _btn = null

func _on_toggled(pressed: bool) -> void:
    print("Snapping ", "enabled" if pressed else "disabled")
```
::::
:::

:::problem{difficulty="standard"}
**4. Undoable node placement.**
 A plugin's `_forward_canvas_gui_input` method
 receives a left-click in the 2D viewport and wants to add a
 `Marker2D` node at the click position. Write the
 method, correctly wrapping the operation in an undoable
 action so pressing Ctrl+Z removes the placed marker.
 Assume `_root` is a cached reference to the
 edited scene root.

::::solution[Solution]
```gdscript
func _forward_canvas_gui_input(event: InputEvent) -> bool:
    if event is InputEventMouseButton \
            and event.button_index == MOUSE_BUTTON_LEFT \
            and event.pressed:

        var pos: Vector2 = event.position    # viewport coords
        # Convert to world coords via the canvas transform
        var canvas_xform: Transform2D = \
            get_editor_interface() \
            .get_editor_viewport_2d().get_canvas_transform()
        var world_pos: Vector2 = canvas_xform.affine_inverse() * pos

        var marker := Marker2D.new()
        marker.position = world_pos
        marker.name = "PlacedMarker"

        var ur := get_undo_redo()
        ur.create_action("Place Marker")
        ur.add_do_method(_root,  "add_child",    marker)
        ur.add_undo_method(_root, "remove_child", marker)
        ur.add_do_reference(marker)     # keep alive during redo
        ur.add_undo_reference(marker)   # keep alive during undo
        ur.commit_action()

        return true   # event consumed
    return false      # let the editor handle other events
```
::::
:::

:::problem{difficulty="challenge"}
**5. Procedural ladder @tool.**
 Build a `@tool` script for a `Node2D`
 named `Ladder` with exported properties
 `rung_count: int` (default 5),
 `rung_spacing: float` (default 32.0), and
 `width: float` (default 24.0). The script should
 update a `Line2D` child called `LeftRail`,
 a `Line2D` child called `RightRail`, and
 dynamically create/destroy child `Line2D` nodes
 named `Rung0`, `Rung1`, … to draw the
 rungs. All children must be created with
 `owner = get_tree().edited_scene_root` so they
 serialise correctly.

::::solution[Solution]
```gdscript
@tool
extends Node2D

@export var rung_count: int = 5 :
    set(v): rung_count = max(1, v); _rebuild()
@export var rung_spacing: float = 32.0 :
    set(v): rung_spacing = maxf(v, 4.0); _rebuild()
@export var width: float = 24.0 :
    set(v): width = maxf(v, 4.0); _rebuild()

func _ready() -> void:
    _rebuild()

func _rebuild() -> void:
    if not is_inside_tree():
        return

    var total_h := rung_count * rung_spacing

    # Rails
    _set_line("LeftRail",
        [Vector2(-width * 0.5, 0.0), Vector2(-width * 0.5, total_h)])
    _set_line("RightRail",
        [Vector2( width * 0.5, 0.0), Vector2( width * 0.5, total_h)])

    # Remove stale rung nodes
    for child in get_children():
        if child.name.begins_with("Rung"):
            child.queue_free()

    # Create rungs
    for i in rung_count:
        var y := (i + 0.5) * rung_spacing
        var line := Line2D.new()
        line.name = "Rung%d" % i
        line.add_point(Vector2(-width * 0.5, y))
        line.add_point(Vector2( width * 0.5, y))
        add_child(line)
        if Engine.is_editor_hint():
            line.owner = get_tree().edited_scene_root

func _set_line(child_name: String, points: Array) -> void:
    var line: Line2D = get_node_or_null(child_name)
    if line == null:
        line = Line2D.new()
        line.name = child_name
        add_child(line)
        if Engine.is_editor_hint():
            line.owner = get_tree().edited_scene_root
    line.clear_points()
    for p in points:
        line.add_point(p)
```
::::
:::

:::problem{difficulty="challenge"}
**6. Configuration warning.**
 A custom `PatrolRoute` node requires at least two
 child `Marker2D` nodes to function correctly. Use
 `_get_configuration_warnings()` to display a helpful
 error in the editor scene tree when this requirement is not met.
 Also implement `_notification(NOTIFICATION_CHILD_ORDER_CHANGED)`
 to refresh the warning whenever children are added or removed.

::::solution[Solution]
```gdscript
@tool
extends Node2D

func _get_configuration_warnings() -> PackedStringArray:
    var warnings := PackedStringArray()
    var marker_count := 0
    for child in get_children():
        if child is Marker2D:
            marker_count += 1
    if marker_count < 2:
        warnings.append(
            "PatrolRoute needs at least 2 Marker2D children (waypoints). " +
            "Currently has %d." % marker_count
        )
    return warnings

func _notification(what: int) -> void:
    if what == NOTIFICATION_CHILD_ORDER_CHANGED:
        update_configuration_warnings()   # re-evaluate and refresh the icon
```

With this in place, the editor shows a yellow warning triangle
 on the node in the Scene dock if fewer than two
 `Marker2D` children are present, and the tooltip
 explains exactly what is missing.
::::
:::
