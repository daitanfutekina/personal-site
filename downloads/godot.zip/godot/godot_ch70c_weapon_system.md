---
title: "Earclacks — Weapon System"
crumb: "Chapter 70C · Weapon Ball Clone Series"
meta:
  - "Est. study time: ~90 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview

Weapons are what make Weapon Ball interesting. A bare ball bouncing between walls is just
 a screensaver. Attach a spinning sword — and suddenly every bounce triggers a direction
 reversal, a possible parry, or a flurry of damage. In this chapter you will build the
 complete weapon system:

- **EquipmentBase** — abstract base class for all equipment types
- **MeleeWeapon** — extends EquipmentBase; spins around the ball, reverses on every bounce, deals damage on hit, can parry enemy weapons
- **Sword.tscn** — the first concrete melee weapon using all of the above
- **Physics layer setup** — 4-layer collision matrix to separate balls, walls, weapon hitboxes, and projectiles
- **Escalation hooks** — virtual methods that subclasses override to evolve behavior over the course of a fight

:::callout-key[KEY CONCEPT]
Ranged weapons (bows, staves, guns) and special abilities are covered in Ch 70F.
        The goal here is to get a melee weapon spinning and dealing damage so the game
        is playable end-to-end before adding complexity.
:::

### Prerequisites

- Ch 70B complete — Ball.tscn has `bounced` signal, `equipment_scenes` array, WeaponMount node
- Understanding of Godot 4 Area2D and collision layers/masks
- GDScript class inheritance and virtual methods

## Class Hierarchy

:::callout-intuition[INTUITION]
A single WeaponBase with a

weapon\_type

enum quickly degenerates into a
        massive if/else chain. Every new weapon type adds branches. With inheritance, adding a
        RangedWeapon means writing one new class — nothing in the existing code changes.
        The ball doesn't care what kind of equipment it's carrying; it calls the same

on\_equipped()

hook on all of them.
:::

```
EquipmentBase (Node2D)          ← abstract; virtual hooks only
├── MeleeWeapon (Node2D)        ← Ch 70C; spins, parries, deals damage
│   └── Sword                   ← MeleeWeapon configured for Sword stats
├── RangedWeapon (Node2D)       ← Ch 70F; fires Projectile nodes
│   ├── Bow
│   └── Staff
├── SpecialAbility (Node2D)     ← Ch 70F; activated by a trigger condition
│   └── Dash
└── PassiveEffect (Node2D)      ← Ch 70F; always-on stat modifiers
    └── RegenRing
```

In GDScript, "abstract" is a convention — there is no `abstract` keyword.
 EquipmentBase declares virtual methods with a `push_error()` body so that
 subclasses that forget to override them get a clear runtime warning.

## EquipmentBase.gd

Create `res://scenes/weapons/EquipmentBase.gd`. This is a plain GDScript file
 with `class_name EquipmentBase` — no scene needed, since subclasses will have
 their own scenes.

```gdscript
class_name EquipmentBase
extends Node2D

# ──────────────────────────────────────────────
# EXPORTS — override in Inspector for each weapon
# ──────────────────────────────────────────────
@export var damage: float = 10.0
@export var attack_speed: float = 1.0   # multiplier; 1.0 = normal

# ──────────────────────────────────────────────
# NODE REFERENCES
# ──────────────────────────────────────────────
## Resolved in _ready() — the ball this equipment is attached to.
## Path: Equipment → WeaponMount → Ball
var ball: Ball

# ──────────────────────────────────────────────
# LIFECYCLE
# ──────────────────────────────────────────────
func _ready() -> void:
    ## WeaponMount is our parent; Ball is WeaponMount's parent.
    ball = get_parent().get_parent() as Ball
    if ball == null:
        push_error("EquipmentBase: parent chain is not WeaponMount → Ball")
        return
    on_equipped()

# ──────────────────────────────────────────────
# VIRTUAL HOOKS — override in subclasses
# ──────────────────────────────────────────────

## Called once when equipment is attached to a ball.
func on_equipped() -> void:
    pass   # override; EquipmentBase has nothing to do here

## Called once when equipment is removed from a ball.
func on_unequipped() -> void:
    pass

## Called by a weapon's hitbox when it lands a hit on an enemy ball.
## Subclasses can use this to escalate damage, apply effects, etc.
func on_hit_landed(enemy_ball: Ball) -> void:
    pass

## Called by MeleeWeapon when the host ball bounces.
## Subclasses that need bounce-triggered behavior override this.
func on_ball_bounced() -> void:
    pass
```

:::callout-key[KEY CONCEPT]
Not every equipment type uses every hook. A PassiveEffect doesn't deal damage, so

on\_hit\_landed

is meaningless for it. Using

pass

means
        subclasses opt in only to the hooks they need, rather than being forced to override
        all four. The

push\_error

approach is reserved for hooks that

must

be overridden — here none of them are strictly mandatory.
:::

## MeleeWeapon.gd

Create `res://scenes/weapons/MeleeWeapon.gd`. This is the workhorse class
 for any swinging, spinning melee item.

```gdscript
class_name MeleeWeapon
extends EquipmentBase

# ──────────────────────────────────────────────
# EXPORTS
# ──────────────────────────────────────────────
## Degrees per second the weapon orbits the ball.
## Positive = counter-clockwise in Godot 2D (Y-down).
@export var angular_speed_deg: float = 180.0

## Distance from ball centre to weapon pivot.
@export var orbit_radius: float = 48.0

# ──────────────────────────────────────────────
# STATE
# ──────────────────────────────────────────────
## Runtime angular speed — may be reversed on bounce.
## NOT physics-derived; we control this entirely in code.
var current_angular_speed: float = 0.0

## Accumulated angle in degrees (drives position each frame).
var current_angle_deg: float = 0.0

# ──────────────────────────────────────────────
# NODE REFERENCES
# ──────────────────────────────────────────────
@onready var hitbox: Area2D = $Hitbox

# ──────────────────────────────────────────────
# LIFECYCLE
# ──────────────────────────────────────────────
func on_equipped() -> void:
    ## Seed the runtime speed from the export.
    current_angular_speed = angular_speed_deg

    ## Subscribe to the ball's bounced signal.
    ball.bounced.connect(_on_ball_bounced)

    ## Connect the hitbox to our damage handler.
    hitbox.area_entered.connect(_on_hitbox_area_entered)

# ──────────────────────────────────────────────
# PHYSICS UPDATE — spin around the ball
# ──────────────────────────────────────────────
func _physics_process(delta: float) -> void:
    ## Advance the orbit angle.
    current_angle_deg += current_angular_speed * delta

    ## Convert to radians for trig.
    var rad := deg_to_rad(current_angle_deg)

    ## Position weapon relative to WeaponMount (which is at ball centre).
    position = Vector2(cos(rad), sin(rad)) * orbit_radius

    ## Rotate the weapon sprite to point outward (optional but looks good).
    rotation = rad
```

:::callout-warning[WARNING]
We are manually setting

position

and

rotation

each frame in `_physics_process`. The ball's

lock\_rotation = true

prevents
        the ball RigidBody2D from spinning. The weapon is a regular Node2D child — it has no
        physics body of its own and therefore is not affected by `lock_rotation`.
:::

## Spin Reversal on Every Bounce

:::callout-intuition[INTUITION]
This is the core feel of Weapon Ball. Every time the ball hits anything —
        wall, enemy, projectile — the weapon snaps from clockwise to counter-clockwise
        (or vice versa). It creates a chaotic, unpredictable attack angle that makes
        the fight visually interesting and tactically meaningful.
:::

:::definition
#### Definition: Spin Reversal

When the host ball emits `bounced`, MeleeWeapon multiplies
 `current_angular_speed` by −1. This flips the sign of the angular velocity,
 reversing the direction of orbit without changing its magnitude.
:::

```gdscript
## Called via ball.bounced signal every time the ball makes contact.
func _on_ball_bounced() -> void:
    current_angular_speed *= -1.0
```

That's it. Two tokens. The reversal is instant — no lerp, no delay — because
 `bounced` fires inside `_integrate_forces`, which runs before
 the frame renders. The viewer sees the snap as simultaneous with the collision.

:::example[Worked Example — three consecutive bounces]
::::answer
Result: spin alternates CW → CCW → CW → CCW with each collision.
::::

| Bounce # | Before | After (×−1) | Direction |
| --- | --- | --- | --- |
| Start | — | +180°/s | Counter-clockwise |
| 1 (left wall) | +180°/s | −180°/s | Clockwise |
| 2 (enemy ball) | −180°/s | +180°/s | Counter-clockwise |
| 3 (top wall) | +180°/s | −180°/s | Clockwise |

Magnitude stays at 180°/s throughout. Only the sign changes. This means speed is
 preserved across the entire fight — weapons don't slow down over time due to reversals.
:::

:::callout-pitfall[PITFALL]
If

current\_angular\_speed

starts at 0 (e.g.,

on\_equipped()

was never called, or

angular\_speed\_deg

was left at 0 in the Inspector),
        multiplying by −1 gives 0. The weapon never moves.
        Always verify

angular\_speed\_deg

is non-zero in the Inspector.
:::

:::callout-connect[CONNECTION]
MeleeWeapon connects directly to

ball.bounced

in

on\_equipped()

and handles reversal in `_on_ball_bounced()`. It also calls

on\_ball\_bounced()

(the virtual hook) so subclasses of MeleeWeapon
        can add further behavior on each bounce without disconnecting the signal.
        Add this line to

\_on\_ball\_bounced

if needed:

```gdscript
func _on_ball_bounced() -> void:
    current_angular_speed *= -1.0
    on_ball_bounced()   # virtual hook for subclasses
```
:::

## Parry Detection

:::callout-intuition[INTUITION]
A parry happens when two weapon hitboxes collide — not when a weapon hits a ball body.
        We detect this with an Area2D named Hitbox on the weapon. When Hitbox enters another
        Area2D that is in the

weapon\_hitbox

group, that is a parry — both balls
        momentarily slow down, as if they were staggered.
:::

### Two distinct collision events on a weapon

| Event | What collided | Signal used | Response |
| --- | --- | --- | --- |
| Damage hit | Weapon hitbox (Layer 3) enters enemy Ball body (Layer 1) | `hitbox.area_entered` | `enemy_ball.take_damage(damage)` |
| Parry | Weapon hitbox (Layer 3) enters enemy Weapon hitbox (Layer 3) | `hitbox.area_entered` | Both balls slow to 15% linear velocity |

We distinguish the two events by checking whether the entering area is in the
 `"weapon_hitbox"` group. If it is — parry. If not — damage hit against a
 ball body.

### Signal handler: `_on_hitbox_area_entered`

```gdscript
func _on_hitbox_area_entered(area: Area2D) -> void:
    if area.is_in_group("weapon_hitbox"):
        _do_parry(area)
    else:
        _do_damage(area)

func _do_damage(area: Area2D) -> void:
    ## The area is the enemy ball's collision shape — get the ball.
    ## Ball collision shape is a direct child of the RigidBody2D.
    var enemy_ball := area.get_parent() as Ball
    if enemy_ball == null or enemy_ball == ball:
        return
    enemy_ball.take_damage(damage)
    on_hit_landed(enemy_ball)   # escalation hook

func _do_parry(enemy_hitbox: Area2D) -> void:
    ## Resolve node path: Hitbox → MeleeWeapon → WeaponMount → Ball
    var enemy_ball := enemy_hitbox.get_parent().get_parent().get_parent() as Ball
    if enemy_ball == null or enemy_ball == ball:
        return
    ## Stagger both balls.
    ball.linear_velocity       *= 0.15
    enemy_ball.linear_velocity *= 0.15
```

:::callout-pitfall[PITFALL]
The path from enemy Hitbox to enemy Ball is:

enemy\_hitbox

(Area2D) → parent =

MeleeWeapon

→ parent =

WeaponMount

→ parent =

Ball

That is three

.get\_parent()

calls. If you add or remove a node layer in the
        scene tree, this path will silently break. Consider adding a helper method

get\_owner\_ball() -> Ball

to MeleeWeapon and exposing it, so parry
        detection does not rely on magic path arithmetic.
:::

:::example[Worked Example — parry event trace]
::::answer
Result: both balls slow to 15% velocity; weapon rotations are unaffected by the parry itself.
::::

1. Ball A's Sword hitbox sweeps through space.
2. Ball B's Sword hitbox occupies the same space.
3. Godot's Area2D detection fires: Ball A's hitbox emits `area_entered(ball_b_hitbox)`.
4. `ball_b_hitbox.is_in_group("weapon_hitbox")` → true → call `_do_parry`.
5. `get_parent()` → BallB's MeleeWeapon → `get_parent()` → BallB's WeaponMount → `get_parent()` → Ball B.
6. `ball.linear_velocity *= 0.15` → Ball A slows.
7. `enemy_ball.linear_velocity *= 0.15` → Ball B slows.
8. Both balls drift slowly until the next wall bounce restores speed.
:::

:::callout-warning[WARNING]
Ball B's Sword hitbox also receives

area\_entered(ball\_a\_hitbox)

at the
        same moment. This means

\_do\_parry

runs twice — once from each ball's
        perspective — and each ball's velocity gets the 0.15× reduction twice (0.15 × 0.15 = 0.0225).
        To prevent double-parry, add a cooldown flag or check who initiated by comparing node
        instance IDs. A simple approach:

```gdscript
var _parry_cooldown: float = 0.0

func _physics_process(delta: float) -> void:
    if _parry_cooldown > 0.0:
        _parry_cooldown -= delta
    # ... existing spin code ...

func _do_parry(enemy_hitbox: Area2D) -> void:
    if _parry_cooldown > 0.0:
        return
    _parry_cooldown = 0.5   # 0.5 s window prevents double-parry
    var enemy_ball := enemy_hitbox.get_parent().get_parent().get_parent() as Ball
    if enemy_ball == null or enemy_ball == ball:
        return
    ball.linear_velocity       *= 0.15
    enemy_ball.linear_velocity *= 0.15
```
:::

## Building Sword.tscn

Sword.tscn is a concrete instance of MeleeWeapon. It has no custom script — all logic
 lives in MeleeWeapon.gd. The scene only provides the visual and collision shape.

### Scene tree: Sword.tscn

```
Sword (Node2D)              ← MeleeWeapon.gd attached
├── Sprite2D                ← sword sprite, offset to orbit_radius
└── Hitbox (Area2D)         ← in group "weapon_hitbox", Layer 3, Mask 1+3
    └── CollisionShape2D    ← RectangleShape2D covering the blade
```

### Step-by-step construction

1. **New Scene** → root node: `Node2D`, rename to `Sword`
2. Attach script: `res://scenes/weapons/MeleeWeapon.gd`
3. Save as `res://scenes/weapons/Sword.tscn`
4. Add child: **Sprite2D** — assign a sword image or placeholder rectangle
5. Add child: **Area2D**, rename to **Hitbox**
6. Add child to Hitbox: **CollisionShape2D** → RectangleShape2D, size ~(8, 40)
7. Select Hitbox in Inspector:

   - Collision → Layer: **bit 3 only**
   - Collision → Mask: **bits 1 and 3** (hits balls AND other weapon hitboxes)
   - Groups: add `weapon_hitbox`
   - Monitoring: **true**
   - Monitorable: **true**

8. Set MeleeWeapon exports in Inspector:

   - `damage = 10.0`
   - `angular_speed_deg = 180.0`
   - `orbit_radius = 48.0`

:::callout-tip[TIP]
The Sword node's origin is the pivot (centre of orbit). The Sprite2D should be offset
        along the +X axis by roughly

orbit\_radius / 2

so the blade appears to
        extend outward. Set Sprite2D's

offset.x = 24

and the sword will look
        like it's sweeping in a full circle around the ball.
:::

## Physics Layers — 4-Layer Collision Matrix

:::callout-intuition[INTUITION]
Without explicit layers, everything collides with everything. Weapon hitboxes would
        block ball movement. Balls would trigger weapon damage against their own weapon.
        Layers let us say exactly who can hit who.
:::

| Layer | Name | Used by | Mask (collides with) |
| --- | --- | --- | --- |
| 1 | Balls | Ball RigidBody2D, Ball CollisionShape2D | 1 (balls), 2 (walls) |
| 2 | Walls | Arena StaticBody2D walls | 1 (balls) |
| 3 | WeaponHitbox | Weapon Area2D hitboxes | 1 (balls), 3 (weapon hitboxes for parry) |
| 4 | Projectiles | Projectile RigidBody2D (Ch 70F) | 1 (balls), 2 (walls) |

### Setting layer names in Project Settings

1. Project → Project Settings → Layer Names → 2D Physics
2. Layer 1: `Balls`
3. Layer 2: `Walls`
4. Layer 3: `WeaponHitbox`
5. Layer 4: `Projectiles`

:::callout-pitfall[PITFALL]
If you accidentally put the weapon hitbox on Layer 1 (Balls), the ball's own physics
        shape will collide with the weapon hitbox, making it bounce erratically every frame.
        Weapon hitboxes must be on Layer 3 exclusively. The Area2D does NOT participate in
        physical collisions — it only detects overlaps.
:::

:::callout-pitfall[PITFALL]
If the weapon hitbox Mask only has Layer 3 (for parry), it cannot detect enemy balls
        and will never deal damage. The Mask must include both Layer 1 (to detect balls)
        AND Layer 3 (to detect other weapon hitboxes for parry).
:::

## Escalation Hooks — Weapons That Evolve

:::callout-intuition[INTUITION]
Weapon Ball would be boring if the fight stayed at the same damage level forever.
        Real implementations have weapons that speed up, deal more damage, or gain new effects
        as the fight goes on. We implement this via two virtual hooks:

on\_hit\_landed(enemy\_ball)

and `on_ball_bounced()`.
        Subclasses override these to escalate without touching any other system.
:::

### Example: FuryBlade — escalating melee weapon

FuryBlade.gd extends MeleeWeapon. Every time it lands a hit, it deals 10% more damage.
 Every time the ball bounces, it spins 5% faster.

```gdscript
class_name FuryBlade
extends MeleeWeapon

var hit_count: int = 0
var bounce_count: int = 0

func on_hit_landed(enemy_ball: Ball) -> void:
    hit_count += 1
    damage *= 1.10   # +10% per hit

func on_ball_bounced() -> void:
    bounce_count += 1
    ## Speed up the spin by 5% per bounce, cap at 3× base speed.
    var base_speed := angular_speed_deg
    var new_speed := absf(current_angular_speed) * 1.05
    var max_speed := base_speed * 3.0
    current_angular_speed = clampf(new_speed, base_speed, max_speed) \
                            * sign(current_angular_speed)
```

:::callout-key[KEY CONCEPT]
We want to increase the

magnitude

without changing the

direction

.

absf(current\_angular\_speed) \* 1.05

computes the new magnitude.
        Multiplying by

sign(current\_angular\_speed)

restores the current
        clockwise/counter-clockwise direction. Without this, escalation would always reset
        to positive (counter-clockwise).
:::

### FuryBlade.tscn

Create a new scene that inherits from Sword.tscn (Scene → New Inherited Scene → Sword.tscn).
 Change the attached script from MeleeWeapon.gd to FuryBlade.gd. The sprite and hitbox
 are inherited — nothing else changes. This is the power of the hierarchy: new weapons
 cost almost nothing to add.

:::example[Worked Example — FuryBlade after 5 hits and 8 bounces]
::::answer
Result: damage ≈ 16.1, spin speed ≈ 266°/s (capped at 540°/s max).
::::

Starting: `damage = 10.0`, `angular_speed_deg = 180.0`

After 5 hits: `10 × 1.10^5 = 10 × 1.6105 ≈ 16.1`

After 8 bounces: `180 × 1.05^8 = 180 × 1.477 ≈ 266°/s`

Max speed cap: `180 × 3 = 540°/s` — not yet reached at 8 bounces
 (would need ≈ 24 bounces to hit the cap).
:::

## Practice Problems

:::problem{difficulty="easy"}
**1.**
 What node type is EquipmentBase? What does MeleeWeapon extend?

::::solution[Solution]
EquipmentBase extends `Node2D`. MeleeWeapon extends
 `EquipmentBase` (and therefore indirectly extends Node2D).
::::
:::

:::problem{difficulty="easy"}
**2.**
 At what point does MeleeWeapon connect to `ball.bounced`?
 Why not in `_ready()` directly?

::::solution[Solution]
In `on_equipped()`, which is called from `EquipmentBase._ready()`
 after resolving the `ball` reference. We cannot connect in a raw
 `_ready()` override before calling `super._ready()` because
 `ball` wouldn't be assigned yet. `on_equipped()` runs after
 the base class resolves the reference.
::::
:::

:::problem{difficulty="standard"}
**3.**
 Explain why the weapon hitbox's Mask must include both Layer 1 and Layer 3.

::::solution[Solution]
Layer 1 (Balls): the hitbox must be able to overlap with the enemy ball's
 CollisionShape2D to trigger damage. Layer 3 (WeaponHitbox): the hitbox must be able
 to overlap with the *enemy's hitbox* to trigger a parry. Without Layer 1,
 no damage. Without Layer 3, no parry.
::::
:::

:::problem{difficulty="standard"}
**4.**
 Trace the node path from an enemy weapon's Hitbox to the enemy Ball node,
 listing each `get_parent()` call.

::::solution[Solution]
```
enemy_hitbox              (Area2D — Layer 3)
  .get_parent()  →  MeleeWeapon  (Node2D with MeleeWeapon.gd)
  .get_parent()  →  WeaponMount  (Node2D — direct child of Ball)
  .get_parent()  →  Ball         (RigidBody2D)
```

Three `get_parent()` calls total.
::::
:::

:::problem{difficulty="standard"}
**5.**
 A FuryBlade lands 3 hits. Starting damage is 8.0. What is the damage on the 4th hit?

::::solution[Solution]
After 3 hits, damage has been multiplied by 1.10 three times:
 $8.0 \times 1.10^3 = 8.0 \times 1.331 = 10.648$.
 The 4th hit deals ≈ 10.6 damage (before this hit's escalation applies).
::::
:::

:::problem{difficulty="standard"}
**6.**
 Without the parry cooldown guard, how many times does `_do_parry`
 execute when two weapons collide simultaneously? What is the resulting
 velocity multiplier applied to each ball?

::::solution[Solution]
Twice — once from Ball A's hitbox entering Ball B's hitbox, and once from
 Ball B's hitbox entering Ball A's hitbox. Each call applies 0.15×, so the
 combined multiplier is $0.15 \times 0.15 = 0.0225$ — the balls nearly stop.
 With the cooldown guard, only the first call executes and each ball gets exactly
 one 0.15× reduction.
::::
:::

:::problem{difficulty="challenge"}
**7.**
 Design a `ShieldBash` special melee weapon that does NOT deal damage
 on weapon-vs-ball contact, but DOES deal damage on parry — reversing the normal
 behavior. Describe which methods to override and what code changes are needed.

::::solution[Solution]
Extend MeleeWeapon and override the two signal handler methods:

```gdscript
class_name ShieldBash
extends MeleeWeapon

func _do_damage(_area: Area2D) -> void:
    pass   # Shield does NOT damage on normal contact

func _do_parry(enemy_hitbox: Area2D) -> void:
    var enemy_ball := enemy_hitbox.get_parent() \
                      .get_parent().get_parent() as Ball
    if enemy_ball == null or enemy_ball == ball:
        return
    ## Apply damage on successful parry instead
    enemy_ball.take_damage(damage * 2.0)   # double damage on parry
    on_hit_landed(enemy_ball)
    ## Still apply a small slow to our own ball
    ball.linear_velocity *= 0.5
```

No changes to MeleeWeapon.gd or EquipmentBase.gd are needed. This is
 the Open/Closed Principle in action: the weapon system is open for extension,
 closed for modification.
::::
:::

:::problem{difficulty="challenge"}
**8.**
 Ball A has a FuryBlade (damage=10, +10% per hit) and Ball B has a standard
 Sword (damage=10, no escalation). Ball A lands 5 hits; Ball B lands 8 hits.
 Which ball dealt more total damage? Show the calculation.

::::solution[Solution]
**Ball A (FuryBlade):** Each hit escalates before the next.
 Hit damage sequence: 10, 11, 12.1, 13.31, 14.641.

 Total: $10 + 11 + 12.1 + 13.31 + 14.641 = 61.05$

**Ball B (Sword):** 10 × 8 = 80.

**Ball B dealt more total damage** (80 vs 61.05) — more hits
 at a flat rate outpaced fewer hits with escalation at this ratio. FuryBlade
 would only surpass the flat sword if it can sustain more hits over time than
 Ball B, or if Ball B stops landing hits as the fight progresses.
::::
:::

## Chapter Summary

:::summary
### Key Concepts

| Concept | Implementation |
| --- | --- |
| EquipmentBase | Node2D base class; resolves `ball` ref in \_ready; 4 virtual hooks |
| MeleeWeapon | Extends EquipmentBase; orbits ball in \_physics\_process; reverses on bounce |
| Spin reversal | `current_angular_speed *= -1.0` in `_on_ball_bounced()` |
| Spin is code-driven | Not physics — manually sets position/rotation each frame |
| Parry detection | Hitbox area\_entered → check `is_in_group("weapon_hitbox")` |
| Parry response | Both balls × 0.15 linear\_velocity; cooldown prevents double-fire |
| Physics layers | 1=Balls, 2=Walls, 3=WeaponHitbox, 4=Projectiles |
| Hitbox mask | Must include Layer 1 (damage) AND Layer 3 (parry) |
| Escalation hooks | on\_hit\_landed, on\_ball\_bounced — override in subclasses |
| Adding new weapons | Extend MeleeWeapon (or EquipmentBase), override hooks, make scene |
:::

### What's next?

Ch 70D builds the **HealthComponent** — the component that lives on each ball,
 tracks HP, emits `hp_changed` and `died`, and respects the
 `is_dead` guard so damage can't arrive after a ball is already dead.
 With health in place, Ch 70E wires the GameManager to detect a winner and trigger the
 game-over screen.
