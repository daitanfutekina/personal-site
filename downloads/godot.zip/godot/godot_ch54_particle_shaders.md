---
title: "Particle Process Shaders — GPU Particle Logic on the Card"
source: "markdown"
---

Part VIII · Chapter 54

# Particle Process Shaders — GPU Particle Logic on the Card

Estimated study time: 70 min · Prerequisites: Ch 50 GDShader Fundamentals, Ch 53 VisualShader (helpful but not required)

## Chapter Overview

Godot's GPU particle system runs entirely on the graphics card. Each particle is a tiny chunk of state — position, velocity, colour, age — updated every frame by a *particle process shader* running in parallel for every particle simultaneously. This lets you have tens of thousands of particles with negligible CPU cost.

This chapter covers how that shader works: the built-in variables it exposes, how the `start()` and `process()` functions divide responsibility, and how to write custom particle logic that the built-in **ParticleProcessMaterial** can't express.

:::callout-key[Key ideas this chapter]
Every particle has a fixed index and a fixed amount of state. The process shader runs once per particle per frame. You can't spawn or destroy particles from inside the shader — only change their transform, colour, and custom data. The particle system handles recycling automatically via the

ACTIVE

flag.
:::

## GPU vs. CPU Particles

:::callout-intuition[Intuition]
CPUParticles2D/3D runs the simulation in GDScript/C++ on the main thread. It's slower for large counts but the positions are accessible to GDScript. GPUParticles2D/3D runs on the GPU — positions are

not

readable from CPU — but easily handles 100,000+ particles at full speed.
:::

| Feature | GPUParticles2D/3D | CPUParticles2D/3D |
| --- | --- | --- |
| Max count (performance) | 100 000+ | ~5 000 |
| Position readable by GDScript | No (GPU memory) | Yes |
| Custom shader logic | Yes — particle process shader | No |
| Trails | Yes (built-in) | No |
| Attractors | Yes (GPUParticlesAttractor) | No |
| Compatibility renderer | Partial (no custom shader) | Full |
| Export to web (no Vulkan) | Limited | Works everywhere |

:::callout-tip[Rule of thumb]
Use GPUParticles for visual effects where count matters (fire, rain, sparks). Use CPUParticles when you need to query particle positions in GDScript (e.g., gameplay pickups, enemies that spawn from a burst).
:::

## GPUParticles2D and GPUParticles3D

### Key Node Properties

| Property | Type | Purpose |
| --- | --- | --- |
| amount | int | Total particle pool size (fixed at runtime) |
| amount\_ratio | float 0–1 | Fraction of pool actually active (useful for LOD) |
| lifetime | float | Seconds each particle lives before recycling |
| one\_shot | bool | Emit all particles once then stop; use with `restart()` |
| explosiveness | float 0–1 | 0 = steady stream; 1 = all particles emit at once |
| randomness | float 0–1 | Random offset to each particle's spawn time |
| fixed\_fps | int | Lock simulation to N FPS for determinism (0 = frame-rate) |
| draw\_passes | int 1–4 | Number of meshes drawn per particle (layered effects) |
| draw\_pass\_1 | Mesh | Mesh used by each particle (QuadMesh for sprites) |
| process\_material | Material | ParticleProcessMaterial *or* a ShaderMaterial with particle shader |
| visibility\_aabb | AABB | Bounding box for culling — set manually for custom shaders |
| trail\_enabled | bool | Enable ribbon trails (3D only in 4.x) |
| trail\_sections | int | Number of trail segments per particle |

### ParticleProcessMaterial vs. Custom Shader

The built-in **ParticleProcessMaterial** exposes most common behaviours (gravity, velocity curves, colour ramps, turbulence) through Inspector sliders. When you need something it can't do — spawning on a mesh surface, orbital motion, chained attractor forces — you switch to a **ShaderMaterial** whose shader uses `shader_type particles;`.

## The Particle Process Shader

A particle shader looks different from all others because it has no `fragment()` — its job is to update particle *state*, not draw pixels. The draw step is handled by a separate *draw* material (a normal canvas\_item or spatial shader on the mesh).

```glsl
shader_type particles;

// Uniforms available to this shader
uniform float gravity = -9.8;
uniform float speed_scale = 1.0;

// start() runs once when a particle first activates (born or recycled)
// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    uint seed = RANDOM_SEED + uint(INDEX);
    // Set initial position, velocity, colour, etc.
    VELOCITY = vec3(
        (rand(seed) - 0.5) * 4.0,
        (rand(seed) - 0.5) * 4.0,
        0.0
    );
    COLOR = vec4(1.0, 0.5, 0.0, 1.0); // orange
    CUSTOM.x = 0.0; // custom data channel: use as you like
}

// process() runs every frame for every ACTIVE particle
void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    float age_ratio = CUSTOM.y; // 0.0 (born) → 1.0 (dying)

    // Apply gravity
    VELOCITY.y += gravity * DELTA;

    // Fade alpha out over lifetime
    COLOR.a = 1.0 - age_ratio;

    // Shrink over lifetime (scale stored in TRANSFORM diagonal)
    float scale = 1.0 - age_ratio;
    TRANSFORM[0].x = scale;
    TRANSFORM[1].y = scale;
    TRANSFORM[2].z = scale;
}
```

### Built-in Variables

| Variable | Type | R/W | Description |
| --- | --- | --- | --- |
| `ACTIVE` | bool | R/W | Set to false to kill the particle early |
| `RESTART` | bool | R | True on the first frame of a particle's life |
| `TRANSFORM` | mat4 | R/W | World-space transform of this particle |
| `VELOCITY` | vec3 | R/W | Current velocity (applied to TRANSFORM.origin each frame) |
| `COLOR` | vec4 | R/W | Per-particle colour (multiplied into the draw material) |
| `CUSTOM` | vec4 | R/W | 4 free float channels — pass anything to the draw shader |
| `CUSTOM` channel, by hand | float | R/W | Godot 4 has no age built-in. Zero a channel in `start()` and advance it by `DELTA / LIFETIME` in `process()` to get 0.0 at birth and 1.0 at death. |
| `DELTA` | float | R | Frame delta in seconds |
| `TIME` | float | R | Global elapsed time |
| `INDEX` | uint | R | Particle's fixed index 0…amount-1 |
| `NUMBER` | uint | R | Emission count (increments each time this slot activates) |
| `EMISSION_TRANSFORM` | mat4 | R | World transform of the emitter node at emission time |
| `RANDOM_SEED` | uint | R | The only randomness the stage provides. There is no `randf()` and no random float built-in: hash this yourself, advancing the seed for each value you need. |

### start() vs. process() — Division of Labour

| Do in start() | Do in process() |
| --- | --- |
| Set initial VELOCITY | Apply gravity / drag to VELOCITY |
| Set initial COLOR | Fade COLOR over the tracked age in CUSTOM |
| Set initial TRANSFORM.origin (spawn position) | Update TRANSFORM for orbital / circular motion |
| Randomise CUSTOM channels | Read CUSTOM channels for per-particle variation |
| Set initial scale via TRANSFORM diagonal | Scale particles up/down over time |
| Set ACTIVE = false for rejected particles (shape masking) | Set ACTIVE = false for early death conditions |

:::callout-warning[RESTART check]
In older Godot 4.x versions,

start()

is a separate function. In some contexts both

start()

and

process()

must coexist in a single shader without errors — check your Godot version. In Godot 4.3+, both are separate entry points. If your version only supports `process()`, use

if (RESTART) { ... }

inside it for spawn-time logic.
:::

## Spawn Patterns

### Ring / Circle Spawn

Distribute spawn positions evenly around a circle of radius R:

```glsl
void start() {
    // Even angular distribution using INDEX
    float angle = float(INDEX) / float(AMOUNT) * TAU; // TAU = 2*PI
    float radius = 2.0;
    vec3 spawn_offset = vec3(cos(angle) * radius, sin(angle) * radius, 0.0);
    TRANSFORM[3].xyz = EMISSION_TRANSFORM[3].xyz + spawn_offset;
    // Velocity outward from centre
    VELOCITY = normalize(spawn_offset) * 3.0;
    COLOR = vec4(0.8, 0.2, 1.0, 1.0);
}
```

:::callout-tip[AMOUNT]
The

AMOUNT

built-in gives the total particle pool size, useful for computing even distributions by index.
:::

### Spawn on Mesh Surface

To spawn on a mesh surface, use the emitter's **Emission Shape** property set to *Surface* on the GPUParticles node — Godot handles the random surface point sampling automatically and passes it via `EMISSION_TRANSFORM`. Inside `start()` the position is already set; you only need to adjust velocity perpendicular to the surface normal:

```glsl
void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    // EMISSION_TRANSFORM.origin is already on the mesh surface
    // Extract the surface normal from the emission transform (stored in column 2)
    vec3 surface_normal = normalize(EMISSION_TRANSFORM[2].xyz);
    // Launch along the normal with some randomisation
    VELOCITY = surface_normal * (2.0 + rand(seed) * 2.0);
    COLOR = vec4(1.0, 0.8, 0.2, 1.0);
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    VELOCITY.y -= 5.0 * DELTA; // gravity
    COLOR.a = 1.0 - CUSTOM.y;
}
```

### Orbital / Swirling Motion

Rotate each particle around the emitter origin over time:

```glsl
uniform float orbit_speed = 1.5;
uniform float orbit_radius = 3.0;

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    // Store initial angle in CUSTOM.x, radius in CUSTOM.y
    CUSTOM.x = float(INDEX) / float(AMOUNT) * TAU;
    CUSTOM.z = orbit_radius + (rand(seed) - 0.5) * 0.5;
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    CUSTOM.x += orbit_speed * DELTA; // advance angle
    float angle = CUSTOM.x;
    float r = CUSTOM.y;
    vec3 emitter_pos = EMISSION_TRANSFORM[3].xyz;
    TRANSFORM[3].xyz = emitter_pos + vec3(cos(angle) * r, sin(angle) * r, 0.0);
    // Rise slowly
    TRANSFORM[3].y += 0.2 * DELTA;
    COLOR.a = 1.0 - CUSTOM.y;
}
```

## Colour and Size Over Lifetime

The standard technique is to use the age you tracked in a CUSTOM channel (0 → 1) and a custom colour gradient computed in the shader:

```glsl
// Colour ramp: white → orange → transparent red
vec4 color_ramp(float t) {
    if (t < 0.3) {
        return mix(vec4(1.0, 1.0, 0.8, 1.0), vec4(1.0, 0.5, 0.0, 1.0), t / 0.3);
    } else {
        float s = (t - 0.3) / 0.7;
        return mix(vec4(1.0, 0.2, 0.0, 1.0), vec4(0.5, 0.0, 0.0, 0.0), s);
    }
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    COLOR = color_ramp(CUSTOM.y);
    // Size: grow then shrink
    float scale = sin(CUSTOM.y * PI); // 0→1→0 bell curve
    TRANSFORM[0].x = scale;
    TRANSFORM[1].y = scale;
    TRANSFORM[2].z = scale;
}
```

:::callout-tip[Using a Gradient via CUSTOM]
Alternatively, store a gradient as a CurveTexture / GradientTexture1D uniform and sample it with the tracked age as UV. This lets artists edit the ramp in the Inspector without touching shader code.
:::

```glsl
uniform sampler2D color_gradient : hint_default_white;

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    COLOR = texture(color_gradient, vec2(CUSTOM.y, 0.0));
}
```

## Particle Attractors

Godot provides scene-level **GPUParticlesAttractor** nodes that influence all GPU particles within range without needing custom shader code:

| Node | Shape | Key property |
| --- | --- | --- |
| GPUParticlesAttractorSphere3D | Sphere | radius, strength (negative = repel) |
| GPUParticlesAttractorBox3D | Box | extents, strength |
| GPUParticlesAttractorVectorField3D | Volume | texture (Texture3D storing direction vectors) |
| GPUParticlesCollisionSphere3D | Sphere | Bounces particles off the sphere surface |
| GPUParticlesCollisionBox3D | Box | Bounces particles off box faces |
| GPUParticlesCollisionSDF3D | SDF bake | Collision against arbitrary mesh (baked to SDF) |

Attractors work automatically with any GPUParticles node that uses either a ParticleProcessMaterial or a custom particle shader — no shader code changes needed.

:::callout-tip[Moving attractors]
Attractor nodes are regular scene nodes — animate their position in GDScript or with an AnimationPlayer and particles will follow automatically.
:::

## Particle Trails

GPUParticles3D has built-in ribbon trail support. Enable `trail_enabled = true` and set `trail_sections`. The trail mesh is a ribbon of quads connecting each particle's historical positions.

```gdscript
@onready var particles := $GPUParticles3D

func _ready() -> void:
    particles.trail_enabled = true
    particles.trail_sections = 8      # how many ribbon segments
    particles.trail_section_subdivisions = 2  # smoothness of each segment
    # Trail uses draw_pass_2 for its mesh — set it to a RibbonTrailMesh
    var ribbon := RibbonTrailMesh.new()
    ribbon.size = 0.1
    ribbon.sections = 8
    particles.draw_pass_2 = ribbon
```

:::callout-warning[2D trails]
GPUParticles2D does not have built-in trail support in Godot 4.x. For 2D trails, use a Line2D updated by a CPUParticles2D-backed system or draw the trail manually.
:::

## Worked Examples

### Example 1 — Realistic Fire Effect

**Answer first:** Spawn at the base, drift upward with turbulence (randomised horizontal velocity), colour from white-yellow → orange → transparent red, shrink near lifetime end.

```glsl
shader_type particles;

uniform float base_speed = 2.5;
uniform float spread = 1.2;
uniform float turbulence_scale = 0.6;

// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    uint seed = RANDOM_SEED + uint(INDEX);
    // Spawn in a small disc at the emitter base
    float angle = rand(seed) * TAU;
    float r = sqrt(rand(seed)) * 0.4; // sqrt for uniform disc distribution
    TRANSFORM[3].xyz = EMISSION_TRANSFORM[3].xyz
        + vec3(cos(angle) * r, 0.0, sin(angle) * r);

    // Upward velocity with horizontal spread
    VELOCITY = vec3(
        (rand(seed) - 0.5) * spread,
        base_speed + rand(seed) * 1.5,
        (rand(seed) - 0.5) * spread
    );

    // Store random phase for turbulence in CUSTOM.x
    CUSTOM.x = rand(seed) * TAU;
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    float t = CUSTOM.y;

    // Turbulence: side-to-side oscillation
    float turb = sin(TIME * 3.0 + CUSTOM.x) * turbulence_scale;
    VELOCITY.x += turb * DELTA;
    VELOCITY.z += cos(TIME * 2.5 + CUSTOM.x) * turbulence_scale * DELTA;

    // Rising deceleration — fire slows as it rises
    VELOCITY.y = max(VELOCITY.y - 0.5 * DELTA, 0.3);

    // Colour: white-yellow → orange → red-transparent
    vec3 fire_col;
    if (t < 0.4) {
        fire_col = mix(vec3(1.0, 1.0, 0.7), vec3(1.0, 0.45, 0.0), t / 0.4);
    } else {
        fire_col = mix(vec3(1.0, 0.3, 0.0), vec3(0.4, 0.0, 0.0), (t - 0.4) / 0.6);
    }
    float alpha = 1.0 - smoothstep(0.6, 1.0, t);
    COLOR = vec4(fire_col, alpha);

    // Scale: grow then shrink
    float sc = sin(t * PI) * 0.8 + 0.2;
    TRANSFORM[0].x = sc;
    TRANSFORM[1].y = sc;
    TRANSFORM[2].z = sc;
}
```

### Example 2 — Magic Circle Burst (2D)

**Answer first:** Emit particles at equal angular spacing on a circle, velocity tangent to the circle, fade and shrink over lifetime. A one-shot burst triggered on demand.

```glsl
shader_type particles;

// Godot 4 has no AMOUNT built-in; mirror the emitter's Amount here.
uniform int particle_count = 32;

uniform float burst_radius = 80.0;  // pixels (2D)
uniform float speed = 200.0;

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    float angle = float(INDEX) / float(particle_count) * TAU;
    // Position on circle edge
    TRANSFORM[3].xyz = EMISSION_TRANSFORM[3].xyz
        + vec3(cos(angle) * burst_radius, sin(angle) * burst_radius, 0.0);
    // Tangent velocity (perpendicular to radial direction)
    VELOCITY = vec3(-sin(angle), cos(angle), 0.0) * speed;
    // Hue shifts by index — rainbow burst
    float hue = float(INDEX) / float(particle_count);
    // Simple hue→RGB approximation
    float r = abs(hue * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(hue * 6.0 - 2.0);
    float b = 2.0 - abs(hue * 6.0 - 4.0);
    COLOR = vec4(clamp(r, 0.0, 1.0), clamp(g, 0.0, 1.0), clamp(b, 0.0, 1.0), 1.0);
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    // Slow down and fade
    VELOCITY *= (1.0 - 0.8 * DELTA);
    COLOR.a = 1.0 - CUSTOM.y;
    float sc = 1.0 - CUSTOM.y * 0.5;
    TRANSFORM[0].x = sc;
    TRANSFORM[1].y = sc;
    TRANSFORM[2].z = sc;
}
```

Trigger from GDScript:

```gdscript
@onready var burst: GPUParticles2D = $MagicBurst

func trigger_burst() -> void:
    burst.restart()
    burst.emitting = true
```

:::callout-pitfall[Pitfall 1 — advance the seed, or every value is the same]
A hash of

RANDOM\_SEED

returns the same number every time unless you advance the seed, so a particle given

rand(seed)

for its angle and again for its speed gets one value for both and the whole emission collapses onto a line. Take

inout uint

and mutate it, as the helper above does. The opposite mistake is caching one draw in a variable and reusing it where you wanted two independent values.
:::

:::callout-pitfall[Pitfall 2 — Modifying TRANSFORM position directly overrides VELOCITY]
If you set

TRANSFORM[3].xyz

directly in `process()`, you're teleporting the particle — VELOCITY has no effect that frame. For orbiting particles that track a formula, set position directly. For physics-style particles, add to VELOCITY and let Godot integrate it.
:::

:::callout-pitfall[Pitfall 3 — visibility\_aabb must cover custom motion]
When you move particles outside their default bounding box with a custom shader, Godot may cull the effect. Set the GPUParticles node's

visibility\_aabb

in the Inspector to cover the full range of particle positions, or disable culling with

visibility\_aabb = AABB(Vector3(-100,-100,-100), Vector3(200,200,200))

.
:::

:::callout-pitfall[Pitfall 4 — Particle shader ≠ draw shader]
The

shader\_type particles

shader updates particle state. To control how each particle

looks

(texture, glow, alpha blending), you need a separate draw material on `draw_pass_1`. The particle's COLOR is multiplied into whatever the draw material outputs.
:::

:::summary
### Chapter 54 Summary

| Task | How |
| --- | --- |
| One-shot burst | Set `one_shot = true`, call `restart()` |
| Spawn in a disc | `angle = rand(seed) * TAU`, `r = sqrt(rand(seed)) * radius` in start() |
| Spawn in a ring (even spacing) | `angle = float(INDEX) / float(AMOUNT) * TAU` |
| Per-particle random variation | Store `rand(seed)` in CUSTOM.x during start() |
| Colour over lifetime | Drive COLOR from the tracked age via mix() or a gradient texture |
| Size over lifetime | Set TRANSFORM[0].x / [1].y / [2].z to the scale value |
| Orbiting motion | Store angle in CUSTOM.x; update it in process(); set TRANSFORM[3].xyz |
| Attract particles to a point | Add GPUParticlesAttractorSphere3D to scene |
| Ribbon trails | `trail_enabled = true`, set trail\_sections, assign RibbonTrailMesh |
| Gradient texture lookup | `uniform sampler2D grad : hint_default_white`; `texture(grad, vec2(CUSTOM.y, 0))` |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Rising Bubbles**

Write a particle shader for a 2D bubble effect: spawn at random X positions within a 200px wide strip, float straight upward at varying speeds, fade out in the last 20% of lifetime, and slightly wobble horizontally using a sine function of TIME and per-particle phase.

::::solution[Solution]
```glsl
shader_type particles;
uniform float rise_speed = 80.0;

// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    uint seed = RANDOM_SEED + uint(INDEX);
    vec3 base = EMISSION_TRANSFORM[3].xyz;
    TRANSFORM[3].xyz = base + vec3((rand(seed) - 0.5) * 200.0, 0.0, 0.0);
    VELOCITY = vec3(0.0, -(rise_speed + rand(seed) * 40.0), 0.0); // negative Y = up in 2D
    CUSTOM.x = rand(seed) * TAU; // wobble phase
    COLOR = vec4(0.5, 0.8, 1.0, 0.7);
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    // Horizontal wobble
    TRANSFORM[3].x += sin(TIME * 2.0 + CUSTOM.x) * 15.0 * DELTA;
    // Fade last 20%
    COLOR.a = 0.7 * (1.0 - smoothstep(0.8, 1.0, CUSTOM.y));
}
```
::::
:::

:::problem{difficulty="easy"}
**2. Coin Pickup Sparkle**

A one-shot burst of 16 particles that shoot outward in all directions from a coin, slow down, and fade. The shader should calculate outward velocity from the spawn angle based on INDEX, not RANDF\_SEED, so the burst is always visually even. Each particle should be gold-coloured (yellow → orange fade).

::::solution[Solution]
```glsl
shader_type particles;

// Godot 4 has no AMOUNT built-in; mirror the emitter's Amount here.
uniform int particle_count = 32;
uniform float burst_speed = 120.0;

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    float angle = float(INDEX) / float(particle_count) * TAU;
    TRANSFORM[3].xyz = EMISSION_TRANSFORM[3].xyz;
    VELOCITY = vec3(cos(angle), sin(angle), 0.0) * burst_speed;
    COLOR = vec4(1.0, 0.85, 0.0, 1.0);
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    VELOCITY *= pow(0.05, DELTA); // fast deceleration
    COLOR = mix(vec4(1.0, 0.85, 0.0, 1.0), vec4(1.0, 0.3, 0.0, 0.0), CUSTOM.y);
}
```
::::
:::

:::problem{difficulty="standard"}
**3. Snowfall**

Create a 3D snowfall shader: spawn particles at random positions in a 20×20 unit area above the player, fall downward with gravity, drift slightly side-to-side with a per-particle wind phase, and reset their Y to the top when they fall below -5.0 (so they loop without one-shot). Particles should be white and semi-transparent.

::::solution[Solution]
```glsl
shader_type particles;
uniform float fall_speed = 2.0;
uniform float wind_strength = 0.3;

// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    uint seed = RANDOM_SEED + uint(INDEX);
    vec3 base = EMISSION_TRANSFORM[3].xyz;
    TRANSFORM[3].xyz = base + vec3(
        (rand(seed) - 0.5) * 20.0,
        rand(seed) * 10.0 + 5.0, // stagger heights at start
        (rand(seed) - 0.5) * 20.0
    );
    VELOCITY = vec3(0.0, -fall_speed - rand(seed) * 1.0, 0.0);
    CUSTOM.x = rand(seed) * TAU;
    COLOR = vec4(1.0, 1.0, 1.0, 0.6 + rand(seed) * 0.3);
}

void process() {
    // Wind drift
    VELOCITY.x = sin(TIME * 0.5 + CUSTOM.x) * wind_strength;
    VELOCITY.z = cos(TIME * 0.4 + CUSTOM.x) * wind_strength * 0.5;

    // Loop: reset to top when below threshold
    if (TRANSFORM[3].y < -5.0) {
        vec3 base = EMISSION_TRANSFORM[3].xyz;
        TRANSFORM[3].x = base.x + (fract(sin(float(INDEX) + TIME) * 4375.5453) - 0.5) * 20.0;
        TRANSFORM[3].y = base.y + 10.0;
        TRANSFORM[3].z = base.z + (fract(cos(float(INDEX) + TIME) * 7819.1231) - 0.5) * 20.0;
    }
}
```
::::
:::

:::problem{difficulty="standard"}
**4. Gradient Texture Drive**

Modify the fire effect from the worked example to drive its colour entirely from a `GradientTexture1D` uniform instead of the inline colour ramp function. Set up the GDShader uniform declaration and show how to assign the gradient resource from GDScript at runtime.

::::solution[Solution]
```glsl
// Shader:
shader_type particles;
uniform sampler2D fire_gradient : hint_default_white;
uniform float base_speed = 2.5;

// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    CUSTOM.y = 0.0;   // age, advanced in process()
    uint seed = RANDOM_SEED + uint(INDEX);
    VELOCITY = vec3((rand(seed) - 0.5) * 1.2, base_speed + rand(seed), 0.0);
}

void process() {
    // Godot 4 has no LIFETIME_RATIO built-in; track the age here.
    CUSTOM.y += DELTA / LIFETIME;   // 0 at birth, 1 at death
    float t = CUSTOM.y;
    COLOR = texture(fire_gradient, vec2(t, 0.0));
    // Scale bell-curve
    float sc = sin(t * PI);
    TRANSFORM[0].x = sc; TRANSFORM[1].y = sc; TRANSFORM[2].z = sc;
}
```

```gdscript
# GDScript:
func _ready() -> void:
    var mat: ShaderMaterial = $GPUParticles3D.process_material
    var grad := GradientTexture1D.new()
    var g := Gradient.new()
    g.add_point(0.0, Color(1.0, 1.0, 0.7))
    g.add_point(0.3, Color(1.0, 0.5, 0.0))
    g.add_point(0.7, Color(0.8, 0.1, 0.0))
    g.add_point(1.0, Color(0.2, 0.0, 0.0, 0.0))
    grad.gradient = g
    mat.set_shader_parameter("fire_gradient", grad)
```
::::
:::

:::problem{difficulty="challenge"}
**5. Warp-Speed Stars**

Create a warp-speed star effect for a space game: particles spawn at random positions in a sphere of radius 10 around the player, move along the -Z axis at increasing speed (accelerating), and stretch visually by setting their TRANSFORM scale along Z proportional to speed. When they pass Z = -15.0 from the emitter, deactivate them (ACTIVE = false) — don't rely on lifetime. Reset ACTIVE in start() to ensure the pool recycles.

::::solution[Solution]
```glsl
shader_type particles;
uniform float warp_acceleration = 30.0;

// Godot 4 particle shaders have no randf(): RANDOM_SEED is the only source of
// randomness, so the hash has to be supplied. Advancing `seed` gives a fresh
// value per call, exactly as a random() would.
float rand(inout uint seed) {
    seed = seed * 747796405u + 2891336453u;
    uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;
    return float((w >> 22u) ^ w) / 4294967295.0;
}

void start() {
    uint seed = RANDOM_SEED + uint(INDEX);
    // Random position in sphere
    float theta = rand(seed) * TAU;
    float phi = acos(2.0 * rand(seed) - 1.0);
    float r = pow(rand(seed), 0.333) * 10.0; // cube root for uniform sphere
    TRANSFORM[3].xyz = EMISSION_TRANSFORM[3].xyz + vec3(
        r * sin(phi) * cos(theta),
        r * sin(phi) * sin(theta),
        r * cos(phi)
    );
    CUSTOM.x = 2.0 + rand(seed) * 5.0; // initial speed
    VELOCITY = vec3(0.0, 0.0, -CUSTOM.x);
    ACTIVE = true;
    COLOR = vec4(1.0, 1.0, 1.0, 0.8);
}

void process() {
    // Accelerate
    CUSTOM.x += warp_acceleration * DELTA;
    VELOCITY.z = -CUSTOM.x;

    // Stretch Z scale with speed (visual streaking)
    float z_scale = CUSTOM.x * 0.05;
    TRANSFORM[0].x = 0.02;
    TRANSFORM[1].y = 0.02;
    TRANSFORM[2].z = max(z_scale, 0.02);

    // Deactivate when out of view
    vec3 rel = TRANSFORM[3].xyz - EMISSION_TRANSFORM[3].xyz;
    if (rel.z < -15.0) {
        ACTIVE = false;
    }
}
```

Note: The particle draw material needs to be a thin elongated QuadMesh (or CapsuleMesh) so the Z-scale stretch is visible. For maximum visual impact, enable additive blend mode on the draw material and set the emission colour to a bright white.
::::
:::
