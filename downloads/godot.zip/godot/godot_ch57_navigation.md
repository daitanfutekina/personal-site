---
title: "NavigationAgent2D/3D, NavMesh Baking & Pathfinding"
source: "markdown"
---

Part IX · Chapter 57

# NavigationAgent2D/3D, NavMesh Baking & Pathfinding

Estimated study time: 85 min · Prerequisites: Ch 3 Nodes & Scenes, Ch 56 FSMs (helpful)

## Chapter Overview

Godot's navigation system finds paths through your world automatically. You define walkable areas (NavigationRegion), attach an agent to your character (NavigationAgent), set a target, and the system hands you the next position to walk toward — handling obstacle avoidance along the way.

This chapter covers the full 2D and 3D navigation pipeline: baking navmeshes, configuring agents, using NavigationLinks for jumps and ladders, adding dynamic obstacles, and querying the NavigationServer directly for advanced use cases like path-preview or async queries.

:::callout-key[Navigation system overview]
NavigationRegion defines walkable space. NavigationAgent computes and follows paths within it. NavigationObstacle carves moving holes in the navmesh. NavigationLink connects two disjoint regions (jump points, teleporters). NavigationServer3D/2D is the low-level API underlying all of them.
:::

## Navigation Concepts

:::callout-intuition[Intuition]
Imagine painting the floor of your level in green wherever enemies can walk. That painted area is the navmesh. Godot's A\* algorithm finds the shortest path across the painted area from point A to point B, staying within the green zone. NavigationAgent automates the "walk along this path" part every frame.
:::

| Term | What it is | Godot node |
| --- | --- | --- |
| NavMesh | Polygon mesh representing walkable area | NavigationPolygon (2D) / NavigationMesh (3D) |
| NavRegion | Scene node that owns a NavMesh and registers it with the server | NavigationRegion2D / NavigationRegion3D |
| NavAgent | Per-character node that requests paths and handles avoidance | NavigationAgent2D / NavigationAgent3D |
| NavLink | Connects two points across a gap (jump, ladder, teleport) | NavigationLink2D / NavigationLink3D |
| NavObstacle | Dynamic exclusion zone around moving objects | NavigationObstacle2D / NavigationObstacle3D |
| NavServer | Singleton managing all maps, paths, and avoidance | NavigationServer2D / NavigationServer3D |

## NavigationRegion2D — Defining Walkable Area

Add a **NavigationRegion2D** node to your scene. It needs a **NavigationPolygon** resource that describes the walkable polygon.

### Baking the NavMesh (2D)

1. Add `NavigationRegion2D` to your level scene.
2. In the Inspector, create a new **NavigationPolygon** resource on the navigation\_polygon property.
3. Click the polygon resource to open it. Use the editor toolbar to draw the walkable polygon by clicking to add vertices.
4. For TileMap levels, use the TileMap's built-in navigation layer instead (covered later).
5. Click *Bake NavigationPolygon* in the toolbar — Godot fills in the polygon from your geometry automatically.

:::callout-tip[Bake vs. manual polygon]
Manual drawing works for simple static levels. For levels built from CollisionPolygon2D shapes, enable

source\_geometry\_mode

=

Static Colliders

and bake — Godot traces the walkable area from your collision shapes automatically.
:::

#### Key NavigationRegion2D Properties

| Property | Purpose |
| --- | --- |
| navigation\_polygon | The NavigationPolygon resource defining walkable area |
| enabled | Toggle the region on/off at runtime (e.g., open a door to new area) |
| navigation\_layers | Bitmask — agents only use regions matching their layer mask |
| enter\_cost | Extra cost added when entering this region (avoidance weighting) |
| travel\_cost | Multiplier on path length within this region (1.0 = normal) |

## NavigationAgent2D

Add **NavigationAgent2D** as a child of your character node. It automatically registers with the nearest NavigationRegion and computes paths on demand.

### Key Properties

| Property | Type | Purpose |
| --- | --- | --- |
| target\_position | Vector2 | Set this to request a path to that world position |
| path\_desired\_distance | float | Distance from next waypoint before advancing to the next (default 1.0) |
| target\_desired\_distance | float | Distance from final target considered "arrived" (default 1.0) |
| max\_speed | float | Used by avoidance — set to match your character's actual speed |
| radius | float | Agent radius for avoidance calculations |
| avoidance\_enabled | bool | Enable RVO avoidance (separates agents from each other) |
| navigation\_layers | bitmask | Must overlap with region layers to use that region |
| path\_postprocessing | enum | Corridors (fast) or EdgeCentered (smoother diagonal paths) |

### Basic Follow Pattern

```gdscript
extends CharacterBody2D

const SPEED := 150.0

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

func _ready() -> void:
    # Connect the signal that fires when path is fully computed
    nav_agent.velocity_computed.connect(_on_velocity_computed)

func set_target(target_pos: Vector2) -> void:
    nav_agent.target_position = target_pos

func _physics_process(_delta: float) -> void:
    if nav_agent.is_navigation_finished():
        return

    var next_pos: Vector2 = nav_agent.get_next_path_position()
    var direction: Vector2 = (next_pos - global_position).normalized()

    # If avoidance is enabled, send desired velocity to the agent
    # and wait for velocity_computed signal to apply movement
    if nav_agent.avoidance_enabled:
        nav_agent.set_velocity(direction * SPEED)
    else:
        velocity = direction * SPEED
        move_and_slide()

# Called by avoidance system with the safe velocity
func _on_velocity_computed(safe_velocity: Vector2) -> void:
    velocity = safe_velocity
    move_and_slide()
```

:::callout-warning[Avoidance changes the velocity flow]
When

avoidance\_enabled

is true, you must call

nav\_agent.set\_velocity(desired)

and apply movement in the

velocity\_computed

signal callback — not directly in `_physics_process`. If you do both, the character moves twice.
:::

### Target Reached Signal

```gdscript
func _ready() -> void:
    nav_agent.target_reached.connect(_on_target_reached)
    nav_agent.navigation_finished.connect(_on_navigation_finished)
    nav_agent.path_changed.connect(_on_path_changed)   # fires when path is recalculated
    nav_agent.waypoint_reached.connect(_on_waypoint_reached)

func _on_target_reached() -> void:
    print("Arrived at destination!")
    # Start idle animation, pick next patrol point, etc.

func _on_navigation_finished() -> void:
    # Fires slightly after target_reached — safe to clear the target here
    pass

func _on_waypoint_reached(details: Dictionary) -> void:
    # details["position"] = the waypoint just passed
    # Useful for playing footstep sounds at each path corner
    pass
```

## 3D Navigation

### NavigationRegion3D

The 3D workflow mirrors 2D but uses a **NavigationMesh** resource instead of NavigationPolygon.

1. Add **NavigationRegion3D** to your 3D level scene.
2. Create a new **NavigationMesh** resource on the navigation\_mesh property.
3. Configure the mesh properties (agent radius, max slope, max step height).
4. Click *Bake NavigationMesh* — Godot ray-casts your scene geometry and builds the walkable surface polygons.

#### Critical NavigationMesh Properties

| Property | Purpose | Typical value |
| --- | --- | --- |
| agent/radius | Character radius — erodes edges by this amount | 0.5 m (humanoid) |
| agent/height | Minimum clearance required overhead | 1.8 m (humanoid) |
| agent/max\_slope | Maximum walkable slope in degrees | 45° |
| agent/max\_climb | Maximum step height the agent can climb | 0.25 m |
| cell/size | Voxel resolution — smaller = more accurate, slower bake | 0.25 m |
| geometry/source\_geometry\_mode | What geometry to bake from (MeshInstances, StaticBodies, Groups…) | Static Colliders |
| filter/low\_hanging\_obstacles | Remove polygons under low overhangs | true |

### NavigationAgent3D

Identical pattern to 2D. The key difference: in 3D you move on a surface, so the path points are 3D world positions.

```gdscript
extends CharacterBody3D

const SPEED   := 4.0
const GRAVITY := -9.8

@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D

func _ready() -> void:
    nav_agent.velocity_computed.connect(_on_velocity_computed)

func chase(target: Node3D) -> void:
    nav_agent.target_position = target.global_position

func _physics_process(delta: float) -> void:
    # Always apply gravity (navigation doesn't handle it)
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    if nav_agent.is_navigation_finished():
        velocity.x = move_toward(velocity.x, 0.0, SPEED)
        velocity.z = move_toward(velocity.z, 0.0, SPEED)
        move_and_slide()
        return

    var next_pos: Vector3 = nav_agent.get_next_path_position()
    var flat_dir := (next_pos - global_position)
    flat_dir.y = 0.0
    flat_dir = flat_dir.normalized()

    if nav_agent.avoidance_enabled:
        nav_agent.set_velocity(flat_dir * SPEED)
    else:
        velocity.x = flat_dir.x * SPEED
        velocity.z = flat_dir.z * SPEED
        move_and_slide()

func _on_velocity_computed(safe_velocity: Vector3) -> void:
    velocity.x = safe_velocity.x
    velocity.z = safe_velocity.z
    move_and_slide()
```

:::callout-tip[Keep gravity separate]
The navigation system works on the XZ plane — it has no concept of gravity. Always add

velocity.y += GRAVITY \* delta

yourself and never let the navigation override your Y velocity.
:::

## NavigationLinks — Jumps, Ladders & Teleports

NavigationLinks connect two positions that aren't connected by a contiguous navmesh polygon — for example, a jump-down ledge, a ladder, or a one-way shortcut.

```gdscript
# Create a NavigationLink2D in the editor:
# - Set start_position (top of jump-off point)
# - Set end_position (landing zone below)
# - enter_cost / travel_cost control how much A* prefers this link

# Detect when the agent uses a link:
nav_agent.link_reached.connect(_on_link_reached)

func _on_link_reached(details: Dictionary) -> void:
    var link_owner := details["owner"]          # the NavigationLink node
    var entry_pos  := details["position"]       # where agent entered the link
    var exit_pos   := details["exit_position"]  # where agent should end up

    # Play a jump animation, teleport, or trigger a specific action:
    if link_owner.is_in_group("jump_links"):
        _do_jump_to(exit_pos)
    elif link_owner.is_in_group("teleport_links"):
        global_position = exit_pos
```

:::callout-tip[Link bidirectionality]
By default NavigationLinks are bidirectional (

bidirectional

= true). Set it to false for one-way shortcuts (jump down but can't jump back up).
:::

## NavigationObstacles — Dynamic Avoidance

A **NavigationObstacle2D/3D** represents a moving entity that other agents should avoid (a moving crate, another enemy, the player). Unlike static navmesh carving, obstacles update in real time without rebaking.

```gdscript
# On the moving obstacle (e.g., a patrol enemy other agents should avoid):
@onready var obstacle: NavigationObstacle2D = $NavigationObstacle2D

func _ready() -> void:
    obstacle.radius = 30.0   # avoidance radius in pixels
    obstacle.avoidance_enabled = true
    # If the obstacle should also carve the navmesh (static carving):
    obstacle.affect_navigation_mesh = true
    obstacle.carve_navigation_mesh = true
```

| Property | Purpose |
| --- | --- |
| avoidance\_enabled | Include this obstacle in RVO avoidance calculations |
| radius | 2D avoidance radius |
| height | 3D avoidance height (cylinder) |
| affect\_navigation\_mesh | Carve a hole in the navmesh (static carve — requires rebake) |
| carve\_navigation\_mesh | Dynamic navmesh carving (updates without rebake) |
| avoidance\_layers | Bitmask — only agents on matching layers avoid this obstacle |

## NavigationServer API — Direct Path Queries

For cases where you need a path without a NavigationAgent (UI path preview, waypoint generation, rangefinding), query the NavigationServer directly.

### Synchronous Path Query

```gdscript
func get_path_to(from: Vector2, to: Vector2) -> PackedVector2Array:
    var nav_map := get_world_2d().navigation_map
    var params  := NavigationPathQueryParameters2D.new()
    params.map         = nav_map
    params.start_position = from
    params.target_position = to
    params.path_postprocessing = NavigationPathQueryParameters2D.PATH_POSTPROCESSING_CORRIDORFUNNEL

    var result := NavigationPathQueryResult2D.new()
    NavigationServer2D.query_path(params, result)
    return result.path  # PackedVector2Array of waypoints
```

### Async Path Query (Godot 4.3+)

```gdscript
# For large levels, avoid blocking the main thread with async queries
func request_path_async(from: Vector3, to: Vector3) -> void:
    var params := NavigationPathQueryParameters3D.new()
    params.map             = get_world_3d().navigation_map
    params.start_position  = from
    params.target_position = to

    # query_path is instant (synchronous) on the main thread in Godot 4.x
    # For true async, use a Thread:
    var thread := Thread.new()
    thread.start(_compute_path_threaded.bind(params))

func _compute_path_threaded(params: NavigationPathQueryParameters3D) -> void:
    var result := NavigationPathQueryResult3D.new()
    NavigationServer3D.query_path(params, result)
    # Must call_deferred to touch scene nodes from the thread result
    call_deferred("_on_path_computed", result.path)
```

### Nearest Point on NavMesh

```gdscript
# Snap a position to the nearest valid navmesh point
func snap_to_navmesh(pos: Vector3) -> Vector3:
    var map := get_world_3d().navigation_map
    return NavigationServer3D.map_get_closest_point(map, pos)
```

## TileMap Navigation

For tile-based levels, navigation is built into the TileSet — no separate NavigationRegion needed.

1. In the **TileSet** resource, open *Physics* → add a Physics Layer. Also add a *Navigation* layer.
2. For each tile type that should be walkable, paint its **Navigation** polygon in the tile editor (a full-tile polygon for open floor tiles; empty for walls).
3. Add a **NavigationRegion2D** as a child of the TileMap node. Set its source\_geometry\_mode to *Parsed Geometry* and parsed\_geometry\_type to *Mesh Instances*, or simply bake from the TileMap directly.
4. Alternatively (Godot 4.2+), the TileMap itself can register navigation layers — set TileMap.navigation\_enabled = true and the tiles' navigation polygons are registered automatically.

```gdscript
# Enable navigation on TileMap in code:
$TileMap.navigation_enabled = true

# Rebake at runtime when tiles change (e.g., door opened, wall destroyed):
func _on_tile_changed() -> void:
    $NavigationRegion2D.bake_navigation_polygon()
```

:::callout-warning[Baking cost]
bake\_navigation\_polygon()

runs synchronously and can stall the frame for large maps. For large destructible environments, bake on a thread or use NavigationObstacles for dynamic carving instead.
:::

## Worked Example — Patrol Enemy with Dynamic Target

A top-down enemy that patrols between waypoints and switches to chasing the player when in sight range. Uses NavigationAgent2D for pathfinding and a simple FSM from Ch 56 for state control.

```gdscript
extends CharacterBody2D

const PATROL_SPEED := 80.0
const CHASE_SPEED  := 140.0
const SIGHT_RANGE  := 250.0
const PATH_UPDATE_INTERVAL := 0.5  # seconds between path recalculations

enum State { PATROL, CHASE }

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var sight_area: Area2D           = $SightArea

var state       := State.PATROL
var player      : Node2D = null
var waypoints   : Array[Vector2] = []
var wp_index    := 0
var _path_timer := 0.0

func _ready() -> void:
    nav_agent.velocity_computed.connect(_on_velocity_computed)
    nav_agent.target_reached.connect(_on_target_reached)
    sight_area.body_entered.connect(_on_body_entered)
    sight_area.body_exited.connect(_on_body_exited)
    # Load patrol waypoints from child Marker2D nodes
    for child in $Waypoints.get_children():
        waypoints.append(child.global_position)
    _set_patrol_target()

func _set_patrol_target() -> void:
    if waypoints.is_empty(): return
    nav_agent.target_position = waypoints[wp_index]

func _on_target_reached() -> void:
    if state == State.PATROL:
        wp_index = (wp_index + 1) % waypoints.size()
        _set_patrol_target()

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        player = body
        state  = State.CHASE

func _on_body_exited(body: Node2D) -> void:
    if body == player:
        player = null
        state  = State.PATROL
        _set_patrol_target()

func _physics_process(delta: float) -> void:
    if state == State.CHASE and player:
        _path_timer += delta
        if _path_timer >= PATH_UPDATE_INTERVAL:
            _path_timer = 0.0
            nav_agent.target_position = player.global_position

    if nav_agent.is_navigation_finished():
        velocity = velocity.move_toward(Vector2.ZERO, 400.0 * delta)
        move_and_slide()
        return

    var speed  := CHASE_SPEED if state == State.CHASE else PATROL_SPEED
    var next   := nav_agent.get_next_path_position()
    var dir    := (next - global_position).normalized()
    nav_agent.set_velocity(dir * speed)  # avoidance enabled

func _on_velocity_computed(safe_vel: Vector2) -> void:
    velocity = safe_vel
    move_and_slide()
```

:::callout-tip[Throttle path updates]
Setting

target\_position

every frame triggers a new path calculation every frame. For a moving player, recalculate only every 0.3–0.5 seconds with a timer. The agent follows the existing path between updates — it feels smooth because waypoints are short segments.
:::

:::callout-pitfall[Pitfall 1 — Agent not on the navmesh]
If an agent starts outside the navmesh (e.g., a character spawned slightly inside a wall),

get\_next\_path\_position()

returns the agent's current position and the character never moves. Always ensure spawn positions are baked onto the navmesh — use

NavigationServer2D.map\_get\_closest\_point()

to snap positions.
:::

:::callout-pitfall[Pitfall 2 — Navmesh not ready at \_ready()]
After

bake\_navigation\_polygon()

, the navmesh is available on the next physics frame. Setting

target\_position

in the same frame as baking returns an empty path. Use

await get\_tree().physics\_frame

before querying.
:::

:::callout-pitfall[Pitfall 3 — Gravity and navmesh Y-position mismatch (3D)]
In 3D, the navmesh sits at the floor surface. If your character's origin is at their feet, the agent's global\_position matches the navmesh correctly. If the origin is at centre-body, you get a Y offset. Always keep the CharacterBody3D origin at the feet.
:::

:::summary
### Chapter 57 Summary

| Task | How |
| --- | --- |
| Define walkable area (2D) | NavigationRegion2D with baked NavigationPolygon |
| Define walkable area (3D) | NavigationRegion3D with baked NavigationMesh |
| Move agent toward target | Set `nav_agent.target_position`; call `get_next_path_position()` each frame |
| Enable agent avoidance | Set `avoidance_enabled = true`; use `set_velocity()` + `velocity_computed` signal |
| Detect arrival | Connect `target_reached` signal |
| Add jump/ladder shortcuts | NavigationLink2D/3D; handle via `link_reached` signal |
| Dynamic moving obstacle | NavigationObstacle2D/3D with `avoidance_enabled` |
| Query path without agent | NavigationPathQueryParameters + NavigationServer.query\_path() |
| TileMap navigation | Paint navigation polygons on tiles; set `TileMap.navigation_enabled = true` |
| Throttle path updates | Recalculate target\_position every 0.3–0.5s via timer |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Follow the Player**

Create a `FollowerEnemy` that moves toward the player using NavigationAgent2D. It should only update its target position every 0.4 seconds (not every frame). When it reaches the player (within `target_desired_distance` = 20px), it should stop and print "Attack!" Show the full script.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const SPEED := 120.0

@onready var nav: NavigationAgent2D = $NavigationAgent2D
@onready var player: Node2D = get_node("/root/World/Player")

var _timer := 0.0

func _ready() -> void:
    nav.target_desired_distance = 20.0
    nav.avoidance_enabled = false
    nav.target_reached.connect(func(): print("Attack!"))

func _physics_process(delta: float) -> void:
    _timer += delta
    if _timer >= 0.4:
        _timer = 0.0
        nav.target_position = player.global_position

    if nav.is_navigation_finished():
        return

    var dir := (nav.get_next_path_position() - global_position).normalized()
    velocity = dir * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="easy"}
**2. Waypoint Patrol**

Build a 2D enemy that loops through an array of 4 patrol waypoints (positions defined as child `Marker2D` nodes named `WP1`–`WP4`). When it reaches a waypoint it waits 1 second, then moves to the next. Use a `Timer` node for the pause.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const SPEED := 80.0

@onready var nav: NavigationAgent2D = $NavigationAgent2D
@onready var pause_timer: Timer = $PauseTimer

var waypoints: Array[Node2D] = []
var wp_index := 0
var paused   := false

func _ready() -> void:
    for i in range(1, 5):
        waypoints.append(get_node("WP%d" % i))
    nav.target_reached.connect(_on_waypoint_reached)
    pause_timer.timeout.connect(_on_pause_done)
    nav.target_position = waypoints[0].global_position

func _on_waypoint_reached() -> void:
    paused = true
    pause_timer.start(1.0)

func _on_pause_done() -> void:
    paused = false
    wp_index = (wp_index + 1) % waypoints.size()
    nav.target_position = waypoints[wp_index].global_position

func _physics_process(_delta: float) -> void:
    if paused or nav.is_navigation_finished(): return
    var dir := (nav.get_next_path_position() - global_position).normalized()
    velocity = dir * SPEED
    move_and_slide()
```
::::
:::

:::problem{difficulty="standard"}
**3. Click-to-Move**

Implement a click-to-move player controller (ARPG style): on left-click, move the player to the clicked world position using NavigationAgent2D. Show a small marker sprite at the click target. Stop the marker when the player arrives. The player should face their direction of travel.

::::solution[Solution]
```gdscript
extends CharacterBody2D

const SPEED := 180.0

@onready var nav: NavigationAgent2D = $NavigationAgent2D
@onready var marker: Sprite2D = $ClickMarker
@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    nav.avoidance_enabled = false
    nav.target_reached.connect(func(): marker.visible = false)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed \
            and event.button_index == MOUSE_BUTTON_LEFT:
        var target := get_global_mouse_position()
        nav.target_position = target
        marker.global_position = target
        marker.visible = true

func _physics_process(_delta: float) -> void:
    if nav.is_navigation_finished():
        velocity = velocity.move_toward(Vector2.ZERO, 600.0 * get_physics_process_delta_time())
        move_and_slide()
        return

    var next := nav.get_next_path_position()
    var dir  := (next - global_position).normalized()
    velocity = dir * SPEED
    # Face direction of travel
    if dir != Vector2.ZERO:
        sprite.flip_h = dir.x < 0.0
    move_and_slide()
```
::::
:::

:::problem{difficulty="standard"}
**4. Path Length Preview**

Before an enemy commits to chasing the player, calculate whether the navigation path is shorter than 500 units. If it's longer, the enemy stays in patrol mode. Use a direct NavigationServer2D query (no NavigationAgent) to get the path, then sum the segment lengths.

::::solution[Solution]
```gdscript
func path_length_to(target: Vector2) -> float:
    var nav_map := get_world_2d().navigation_map
    var params  := NavigationPathQueryParameters2D.new()
    params.map              = nav_map
    params.start_position   = global_position
    params.target_position  = target

    var result := NavigationPathQueryResult2D.new()
    NavigationServer2D.query_path(params, result)

    var path: PackedVector2Array = result.path
    var total := 0.0
    for i in range(1, path.size()):
        total += path[i].distance_to(path[i - 1])
    return total

func _physics_process(_delta: float) -> void:
    if state == State.PATROL and player:
        var dist := path_length_to(player.global_position)
        if dist < 500.0:
            state = State.CHASE
```
::::
:::

:::problem{difficulty="challenge"}
**5. Multi-Floor 3D Navigation with Link**

Set up a 3D level with two floors connected by a staircase. The staircase is too steep to be baked as a ramp, so use a **NavigationLink3D** to connect the two NavRegions. An enemy should navigate from floor 1 to floor 2 using the link. Describe the full setup and show the GDScript to detect when the link is traversed and play a "climbing" animation.

::::solution[Solution]
Scene setup:

1. Create two separate **NavigationRegion3D** nodes — one per floor. Bake each separately.
2. Add a **NavigationLink3D** node. Set start\_position to the base of the staircase on floor 1, end\_position to the top on floor 2. Set bidirectional = true.
3. The link's travel\_cost can be raised to make the A\* path prefer stairs over other routes.

```gdscript
@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var anim: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    nav_agent.link_reached.connect(_on_link_reached)
    nav_agent.target_position = Vector3(10, 4, 0)  # position on floor 2

var _climbing := false

func _on_link_reached(details: Dictionary) -> void:
    var exit_pos: Vector3 = details["exit_position"]
    if exit_pos.y > global_position.y + 0.5:  # going up
        _climbing = true
        anim.play("climb")
        # Tween to exit position instead of navmesh movement
        var tw := create_tween()
        tw.tween_property(self, "global_position", exit_pos, 1.2)
        tw.tween_callback(func(): _climbing = false)

func _physics_process(delta: float) -> void:
    if _climbing: return  # let the tween handle movement
    # ... normal navigation movement ...
```
::::
:::
