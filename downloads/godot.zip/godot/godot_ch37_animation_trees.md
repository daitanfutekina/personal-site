---
title: "AnimationTree & Blend States"
source: "godot_ch37_animation_trees.html"
---

Part IV · Chapter 37

# AnimationTree & Blend States

Prerequisite: Ch 11 (AnimationPlayer basics), Ch 27 (State Machines) · est. 85 min

## Overview

`AnimationPlayer` is fine for cutscenes and simple loops. The
 moment your character needs to blend a walk into a run, aim up and down
 while moving, or interrupt any pose with a hit reaction, you need
 `AnimationTree`. It is a graph-based animation processor that
 runs on top of `AnimationPlayer` and handles all blending
 mathematics automatically.

This chapter covers:

- The relationship between `AnimationPlayer` and
 `AnimationTree`
- `AnimationNodeStateMachine` — named states with smooth
 transitions driven by parameters
- `AnimationNodeBlendSpace1D` (listed as *BlendSpace1D* in the editor) — blend animations along a single axis
 (e.g. speed)
- `AnimationNodeBlendSpace2D` (listed as *BlendSpace2D* in the editor) — blend animations over a 2D plane
 (e.g. directional movement)
- `AnimationNodeBlendTree` — compose nodes for additive
 layering, one-shots, and time-scaling
- Setting and reading parameters from GDScript at runtime
- Root-motion extraction for physics-driven character movement

## 1 · Why AnimationTree?

### 1.1 · AnimationPlayer limitations

`AnimationPlayer` plays one animation at a time. Its
 `play(name, blend_time)` method can crossfade to the next
 animation, but you cannot:

- Blend a "walk" and "run" proportionally based on actual speed
- Layer an "aim up/down" pose on top of any locomotion state
- Play a "hit" one-shot that interrupts and then returns to the
 previous state automatically
- Have complex multi-condition transitions without writing fragile
 state-machine code by hand

`AnimationTree` solves all of these by treating animation
 clips as data flowing through a processing graph.

### 1.2 · AnimationTree setup

Add an `AnimationTree` node as a sibling of (or child of)
 your character node. Configure it in the Inspector:

1. *Anim Player* — point it at your `AnimationPlayer`.
2. *Active* — check this to enable the tree.
3. *Tree Root* — set this to an
 `AnimationNodeStateMachine`,
 `AnimationNodeBlendTree`, or other root node type.

:::callout-warning[Warning — do not call play() on AnimationPlayer]
Once

AnimationTree

is active, it takes full control of the

AnimationPlayer

.  Calling

AnimationPlayer.play()

directly will fight the tree and produce undefined results.  All animation
        control must go through

AnimationTree

parameters.
:::

⬡ — AnimationNodeStateMachine — inherits AnimationRootNode → AnimationNode → Resource

A visual state machine inside AnimationTree where each state plays an animation (or another AnimationNode) and arrows define valid transitions. Transitions can fire automatically on a condition expression, on a timer, or be triggered from code via the `StateMachinePlayback` object. This is the backbone of character animation controllers — idle, walk, jump, attack, death, each as a distinct state that flows to the next based on game logic.

| Transition property | Default | What it does |
| --- | --- | --- |
| switch\_mode | IMMEDIATE | IMMEDIATE: cuts to new state now. SYNC: waits until the new state reaches the same position. AT\_END: waits for current state to finish playing |
| advance\_mode | AUTO | AUTO: fires when the advance\_condition is true. ENABLED: always advances (for pass-throughs). DISABLED: only triggered from code via travel() |
| advance\_condition | "" | Name of an AnimationTree parameter (boolean) that triggers this transition automatically when true |
| xfade\_time | 0.0 s | Duration of the crossfade between states — 0 = hard cut, 0.2 = smooth blend |
| xfade\_curve | null | Custom easing curve for the crossfade — linear by default |
| reset | true | When true, the new state restarts from frame 0. False = resume where it left off (useful for additive layers) |

Use when:

a character has distinct animation states — idle, walk, run, jump, attack — that transition based on boolean conditions or code-driven triggers.

Control from code

via:

var sm = $AnimationTree["parameters/playback"]; sm.travel("Jump")

— the state machine crossfades smoothly.

Prefer BlendSpace2D

inside each state for directional locomotion — states switch cleanly, blending happens within.

## 2 · AnimationNodeStateMachine

The state machine is the most common root node for characters. It holds
 a set of named animation states and directed transitions between them,
 each governed by parameters you set from GDScript.

### 2.1 · States and transitions in the editor

In the *AnimationTree* bottom panel, with the state machine open:

- Right-click → *Add Animation* to add a clip as a state.
 Each state wraps an `AnimationNodeAnimation` pointing to
 one clip from the `AnimationPlayer`.
- Hover a state and drag the arrow that appears to create a
 transition to another state.
- Each transition has:
 *Switch Mode* (Immediate, Sync, AtEnd),
 *Advance Mode* (Auto or Enabled/Disabled),
 *Advance Condition* (a named parameter that triggers the
 transition when `true`), and
 *XFade Time* (crossfade duration in seconds).

| Switch Mode | When the transition occurs |
| --- | --- |
| `Immediate` | Instantly at the moment the condition is met |
| `Sync` | Syncs the new animation to the current time of the outgoing animation |
| `AtEnd` | Waits until the current animation finishes its current cycle |

### 2.2 · StateMachinePlayback

At runtime, control the state machine via its
 `AnimationNodeStateMachinePlayback` object, accessed through
 `AnimationTree.get("parameters/playback")`:

```gdscript
@onready var _anim_tree: AnimationTree = $AnimationTree
@onready var _playback: AnimationNodeStateMachinePlayback = \
    _anim_tree.get("parameters/playback")

func _ready() -> void:
    _anim_tree.active = true
    _playback.start("Idle")   # start in the Idle state

func jump() -> void:
    _playback.travel("Jump")  # travel transitions smoothly to Jump state

func land() -> void:
    _playback.travel("Idle")

## Check current state.
func is_jumping() -> bool:
    return _playback.get_current_node() == "Jump"
```

| Method | Description |
| --- | --- |
| `start(node_name)` | Jump immediately to named state (no crossfade) |
| `travel(node_name)` | Use A\* pathfinding through transitions to reach the target state, honouring crossfades and conditions |
| `stop()` | Stop the state machine |
| `get_current_node()` | Name of the currently playing state |
| `get_travel_path()` | Array of state names in the current travel path |
| `is_playing()` | True if the machine is active |

### 2.3 · Advance conditions from GDScript

Transitions can be set to advance automatically when a named boolean
 parameter becomes `true`. Set the advance condition name in
 the editor, then write to the parameter at runtime:

```gdscript
## In the editor, set transition Idle → Run advance condition to "is_moving".
## From code, drive the condition:
func _physics_process(delta: float) -> void:
    var speed: float = velocity.length()
    _anim_tree.set("parameters/conditions/is_moving", speed > 10.0)
    _anim_tree.set("parameters/conditions/is_falling", not is_on_floor())
    _anim_tree.set("parameters/conditions/is_grounded", is_on_floor())
```

:::callout-tip[Tip — travel vs conditions]
Use

travel()

for deliberate, code-triggered transitions
        (player presses jump, takes damage).  Use advance conditions for
        automatic transitions that should fire whenever a game variable crosses
        a threshold (speed > 0 → walking, speed > 200 → running).
        Mixing both in the same state machine is common and works well.
:::

⬡ — AnimationNodeBlendSpace1D / BlendSpace2D — both inherit AnimationRootNode → AnimationNode → Resource

Blend spaces let you place animation samples along one or two axes and automatically interpolate between them based on a parameter value. **BlendSpace1D** works along a single axis — e.g. speed 0 (idle) → 200 (walk) → 400 (run). **BlendSpace2D** uses a 2D grid — e.g. X = strafe direction, Y = forward speed — and triangulates between the nearest samples. Result: perfectly smooth, data-driven locomotion.

| Property | Default | What it does |
| --- | --- | --- |
| blend\_mode (2D) | INTERPOLATED | INTERPOLATED: triangulate between three nearest points. DISCRETE: snap to the nearest sample. DISCRETE\_CARRY: snap but carry time from the previous clip |
| min\_space / max\_space | -1 / 1 | Axis extents for the blend space editor view — does not clamp the parameter; clipping is handled by snap |
| sync | false | When true, all sample animations' playback positions are synchronised — keeps walk and run in the same gait phase during blending |
| x\_label / y\_label | "x" / "y" | Human-readable axis labels shown in the blend space editor — name them "Speed", "Direction", etc. |

BlendSpace1D use when:

blending along a single continuous dimension — speed (idle/walk/run), pitch (level/uphill/downhill), urgency (calm/alert).

BlendSpace2D use when:

blending two dimensions — 8-directional movement (X strafe, Y forward), aim (X horizontal, Y vertical elevation).

Always enable sync

for locomotion blend spaces so the character's footstep gait doesn't stutter when transitioning between walk and run speeds.

## 3 · BlendSpace1D & BlendSpace2D

### 3.1 · BlendSpace1D — single-axis blending

A `BlendSpace1D` node holds multiple animation clips placed at
 positions along a 1D axis (typically speed). At runtime you provide
 a float parameter; the tree linearly interpolates between the two nearest
 clips.

Setup: in a state machine, create a state whose node type is
 *BlendSpace1D*. Inside, add clips at positions:

- Position 0.0 → `Idle`
- Position 0.5 → `Walk`
- Position 1.0 → `Run`

```gdscript
## Drive the blend position from GDScript.
## Path: "parameters/{state_name}/blend_position"
func _physics_process(delta: float) -> void:
    var speed_norm: float = velocity.length() / MAX_SPEED   # 0..1
    _anim_tree.set("parameters/Locomotion/blend_position", speed_norm)
```

### 3.2 · BlendSpace2D — directional movement

A `BlendSpace2D` node holds clips at 2D points and
 interpolates among them using barycentric blending within triangles.
 Place clips at the eight cardinal and ordinal directions, or use a
 simpler symmetric layout:

- (0, 0) → Idle
- (0, 1) → Walk Forward
- (0, −1) → Walk Back
- (−1, 0) → Walk Left (or mirror of Walk Forward)
- (1, 0) → Walk Right

```gdscript
## Drive a 2D blend position from the movement direction.
## The blend_position is typically the normalised velocity direction.
func _physics_process(delta: float) -> void:
    var vel_2d: Vector2 = Vector2(velocity.x, velocity.z)  # XZ plane in 3D
    var dir: Vector2    = vel_2d.normalized() if vel_2d.length() > 1.0 else vel_2d
    _anim_tree.set("parameters/MovementBS2D/blend_position", dir)
```

:::callout-key[Key Concept — BlendSpace triangulation]
The editor automatically triangulates the point cloud you place clips at.
        Godot uses barycentric coordinates within the enclosing triangle to compute
        blend weights.  If you place points asymmetrically, the triangulation
        may not be what you expect.  Use

Auto Triangulate

or add the
        triangles manually in the BlendSpace editor.
:::

⬡ — AnimationNodeBlendTree — inherits AnimationRootNode → AnimationNode → Resource

A visual node graph where you connect AnimationNodes together — Output ← Blend2 ← (Walk, Run), Output ← Add2 ← (Locomotion, UpperBodyShoot). Gives you fine-grained control over blending, layering, and time-scaling individual animations in a graph instead of a simple state machine. Best for characters that need multiple animations running simultaneously with manual weight control.

| AnimationNode type | — | What it does |
| --- | --- | --- |
| Animation | leaf | References a single animation from the AnimationPlayer — every blend graph starts with these leaves |
| Blend2 | blend | Crossfades between two inputs by a 0–1 parameter — 0 = fully input A, 1 = fully input B |
| Blend3 | blend | Three-way blend: left / centre / right by a -1 to +1 parameter |
| Add2 | additive | Plays input B *on top of* input A — perfect for upper-body aim overlaid on lower-body locomotion |
| OneShot | interrupt | Plays a secondary animation to completion then returns — attacks, hit reactions, transitions |
| TimeScale | utility | Multiplies the playback speed of its input — slow-motion hit-stop effects |
| TimeSeek | utility | Jumps to a specific timestamp — synchronise cycle animations to a common beat |
| Transition | state | Like a mini state machine inside the graph — switch between named inputs by parameter |

Use when:

you need simultaneous blending — locomotion + upper-body aim, walk + breathing, layered hit reactions — rather than simple state switching.

Prefer AnimationNodeStateMachine when:

you need clean state transitions with named conditions (idle → walk → run → jump) and don't need simultaneous layers.

Combine both:

set AnimationNodeBlendTree as the root, put an AnimationNodeStateMachine as one of its inputs to get both — a state machine driving locomotion, blended additively with aim direction.

## 4 · AnimationNodeBlendTree

A `BlendTree` is a node graph where animation data flows from
 leaves to a single *Output* node. Each intermediate node
 transforms, blends, or filters the animation. BlendTrees can be nested
 inside state machine states for complex per-state logic.

### 4.1 · Blend2 — weighted mix of two animations

`AnimationNodeBlend2` takes two input animations and a
 `blend_amount` parameter (0 = only A, 1 = only B, 0.5 = equal
 mix). Useful for transitioning between upper-body aim poses:

```gdscript
## Blend between AimLevel and AimHigh based on a vertical look angle.
## Parameter path: "parameters/AimBlend/blend_amount"
func _process(delta: float) -> void:
    var aim_t: float = remap(camera_pitch, -45.0, 45.0, 0.0, 1.0)
    _anim_tree.set("parameters/AimBlend/blend_amount", aim_t)
```

### 4.2 · OneShot — interrupt and return

`AnimationNodeOneShot` fires a "shot" animation once and then
 lets the underlying animation continue. It automatically crossfades in
 and out. Perfect for hit reactions, reloads, attacks:

```gdscript
## Trigger the one-shot hit reaction.
## Parameter path: "parameters/HitShot/request"
func take_hit() -> void:
    _anim_tree.set("parameters/HitShot/request",
                   AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

## You can also abort it early:
func cancel_hit_reaction() -> void:
    _anim_tree.set("parameters/HitShot/request",
                   AnimationNodeOneShot.ONE_SHOT_REQUEST_ABORT)
```

| Request value | Effect |
| --- | --- |
| `ONE_SHOT_REQUEST_NONE` | No action (idle) |
| `ONE_SHOT_REQUEST_FIRE` | Starts the one-shot animation |
| `ONE_SHOT_REQUEST_ABORT` | Cancels and crossfades back to the base |
| `ONE_SHOT_REQUEST_FADE_OUT` | Finishes current loop then fades out |

### 4.3 · Add2 — additive layering

`AnimationNodeAdd2` additively applies an animation on top of
 a base. Unlike Blend2 (which mixes between two full poses), Add2
 takes the *delta* of the additive animation and stacks it on top.
 Use it for breathing, head-bob, or weapon sway that should not override
 the entire skeleton:

```gdscript
## Breathing layer runs at full strength while alive.
## Parameter path: "parameters/BreathingLayer/add_amount"
func _ready() -> void:
    _anim_tree.set("parameters/BreathingLayer/add_amount", 1.0)

## Reduce breathing intensity when the player is sprinting.
func set_sprint(sprinting: bool) -> void:
    _anim_tree.set("parameters/BreathingLayer/add_amount",
                   0.3 if sprinting else 1.0)
```

:::callout-pitfall[Pitfall — additive vs full-pose animations]
For Add2 to work correctly, the additive animation must be exported as
        a

delta

track from your DCC tool (the difference from the rest
        pose, not the full pose).  A full-pose animation added to another
        full-pose animation produces doubled transforms.  In Godot, ensure the
        additive clip's tracks start from a zero-rest pose or use the

Additive Animation

checkbox in the AnimationPlayer track
        inspector.
:::

## 5 · AnimationTree Parameters

### 5.1 · set and get parameter

Every controllable value in the tree is a *parameter*: a named
 slot of a specific type. You read and write them with
 `AnimationTree.set(path, value)` and
 `AnimationTree.get(path)`:

```gdscript
## Write
_anim_tree.set("parameters/Locomotion/blend_position", 0.75)
_anim_tree.set("parameters/conditions/is_grounded",    true)
_anim_tree.set("parameters/HitShot/request",
               AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

## Read
var speed_blend: float = _anim_tree.get("parameters/Locomotion/blend_position")
var is_playing:  bool  = _anim_tree.get("parameters/HitShot/active")
```

### 5.2 · Parameter path syntax

The path follows the nesting of your tree nodes:

| Path | Node type | Description |
| --- | --- | --- |
| `parameters/playback` | `StateMachine` | The playback object (cast to StateMachinePlayback) |
| `parameters/conditions/<name>` | `StateMachine` | Named boolean advance condition |
| `parameters/<node>/blend_position` | `BlendSpace1D` | Float blend axis position |
| `parameters/<node>/blend_position` | `BlendSpace2D` | Vector2 blend plane position |
| `parameters/<node>/blend_amount` | `Blend2`, `Add2` | Float 0–1 blend weight |
| `parameters/<node>/request` | `OneShot` | ONE\_SHOT\_REQUEST\_\* enum value |
| `parameters/<node>/active` | `OneShot` | Read-only bool: true while shot is playing |
| `parameters/<node>/scale` | `TimeScale` | Float playback speed multiplier |
| `parameters/<node>/seek_request` | `TimeSeek` | Seek to a position (set once, auto-resets) |

For nested nodes (a BlendSpace inside a state machine state), the path
 appends each level separated by `/`:

```gdscript
## State "Moving" contains a BlendSpace1D named "SpeedBlend".
_anim_tree.set("parameters/Moving/SpeedBlend/blend_position", 0.8)
```

## 6 · Root Motion

Root motion transfers positional animation data from the skeleton's root
 bone to the character's physics body, letting the animation drive
 movement rather than code. This produces perfectly matched footsteps,
 turns, and launch trajectories — no foot-sliding.

```gdscript
## Setup:
## 1. In AnimationTree Inspector, set "Root Motion Track" to the root bone path
##    (e.g. "GeneralSkeleton:Root" or "Skeleton3D:root").
## 2. In code, extract the motion each frame:
@onready var _anim_tree: AnimationTree     = $AnimationTree
@onready var _skeleton:  Skeleton3D        = $GeneralSkeleton

func _physics_process(delta: float) -> void:
    # get_root_motion_position() returns the root bone delta in skeleton-local space.
    # Transform it into world space using the skeleton's global transform.
    var motion: Vector3 = _skeleton.global_transform.basis * \
                          _anim_tree.get_root_motion_position()

    # Apply to CharacterBody3D velocity.
    velocity = motion / delta
    move_and_slide()

    # Reset the root bone to origin each frame so drift doesn't accumulate.
    _anim_tree.advance(0.0)
```

:::callout-intuition[Intuition — root motion and blending]
When you blend between two animations with root motion, the position deltas
        are also blended.  A 50% blend between "walk forward" and "walk left"
        will move the character diagonally.  This is usually what you want for a
        BlendSpace2D strafing system — the locomotion and the foot placement
        both match automatically without extra code.
:::

## Summary

`AnimationTree` is a graph processor that sits on top of
 `AnimationPlayer` and handles all blending automatically.
 Once it is active, never call `AnimationPlayer.play()`
 directly. The `AnimationNodeStateMachine` holds named states
 and directed transitions — use `StateMachinePlayback.travel()`
 for code-triggered transitions and advance conditions for threshold-based
 auto-transitions. `BlendSpace1D` smoothly mixes animations
 along a speed axis; `BlendSpace2D` blends over a directional
 plane. Inside a `BlendTree`, `Blend2` mixes two
 full poses, `Add2` stacks an additive layer, and
 `OneShot` fires an interrupting animation and automatically
 returns to the base. All runtime control flows through
 `AnimationTree.set(path, value)` using a path hierarchy that
 mirrors the tree node structure. Root motion extracts skeleton root-bone
 displacement per frame and applies it to the physics body for perfectly
 matched animation-driven movement.

## Mixed Practice

:::problem{difficulty="easy"}
**P1 — Speed blend.**
 Given a `CharacterBody2D` with an `AnimationTree`
 whose root is a `BlendSpace1D` named
 `"LocoBS"` mapping speed 0→1 to Idle→Walk→Run, write the
 `_physics_process()` code that drives
 `blend_position` from the character's current speed, where
 the maximum expected speed is 400 px/s.

::::solution[Solution]
```gdscript
const MAX_SPEED := 400.0

@onready var _anim_tree: AnimationTree = $AnimationTree

func _physics_process(delta: float) -> void:
    var speed_norm: float = clampf(velocity.length() / MAX_SPEED, 0.0, 1.0)
    _anim_tree.set("parameters/LocoBS/blend_position", speed_norm)
```
::::
:::

:::problem{difficulty="easy"}
**P2 — One-shot attack.**
 A player node has an `AnimationTree` with a
 `OneShot` node named `"AttackShot"` layered
 above the locomotion state machine. Write `attack()`
 which fires the shot, and `cancel_attack()` which aborts
 it. Also write a helper `is_attacking() -> bool` that
 reads the `active` parameter.

::::solution[Solution]
```gdscript
@onready var _anim_tree: AnimationTree = $AnimationTree

func attack() -> void:
    _anim_tree.set("parameters/AttackShot/request",
                   AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

func cancel_attack() -> void:
    _anim_tree.set("parameters/AttackShot/request",
                   AnimationNodeOneShot.ONE_SHOT_REQUEST_ABORT)

func is_attacking() -> bool:
    return _anim_tree.get("parameters/AttackShot/active")
```
::::
:::

:::problem{difficulty="standard"}
**P3 — Platformer state machine.**
 Design (in pseudocode or GDScript) an `AnimationTree` state
 machine for a 2D platformer with states: `Idle`,
 `Run`, `Jump`, `Fall`,
 `Land`. Write the `_physics_process()` code
 that sets advance conditions and calls `travel()` where
 appropriate. `Land` must use `AtEnd` switch
 mode so it plays fully before returning to `Idle`.

::::solution[Solution]
```gdscript
## State machine transitions (set up in editor):
## Idle  → Run   : advance condition "is_moving"     (auto)
## Run   → Idle  : advance condition "not_moving"    (auto)
## Any   → Jump  : travel() from code
## Jump  → Fall  : advance condition "is_falling"    (auto)
## Fall  → Land  : advance condition "is_grounded"   (auto, AtEnd switch)
## Land  → Idle  : advance condition "always_true"   (auto, AtEnd)

@onready var _anim_tree: AnimationTree                    = $AnimationTree
@onready var _playback:  AnimationNodeStateMachinePlayback = \
    _anim_tree.get("parameters/playback")

func _physics_process(_delta: float) -> void:
    var moving:   bool  = absf(velocity.x) > 10.0
    var falling:  bool  = velocity.y > 0.0 and not is_on_floor()
    var grounded: bool  = is_on_floor()

    _anim_tree.set("parameters/conditions/is_moving",   moving)
    _anim_tree.set("parameters/conditions/not_moving",  not moving)
    _anim_tree.set("parameters/conditions/is_falling",  falling)
    _anim_tree.set("parameters/conditions/is_grounded", grounded)
    _anim_tree.set("parameters/conditions/always_true", true)

    if Input.is_action_just_pressed("jump") and grounded:
        _playback.travel("Jump")
```
::::
:::

:::problem{difficulty="standard"}
**P4 — Aim blend layer.**
 A 3D character has a `BlendTree` where a base locomotion
 state machine feeds into a `Blend2` node (named
 `"AimBlend"`) whose second input is an aim-up pose.
 Write the code that maps the camera's vertical look angle (stored
 as `camera_pitch` in degrees, range −60 to +60) to the
 `blend_amount` so that 0 degrees = no aim blend,
 +60 degrees = fully blended to the aim-up pose.

::::solution[Solution]
```gdscript
@onready var _anim_tree: AnimationTree = $AnimationTree

var camera_pitch: float = 0.0   # degrees, updated from camera input

func _process(_delta: float) -> void:
    # Remap [0, 60] degrees → [0, 1] blend_amount.
    # Negative pitch (looking down) produces no blend.
    var blend: float = clampf(camera_pitch / 60.0, 0.0, 1.0)
    _anim_tree.set("parameters/AimBlend/blend_amount", blend)
```
::::
:::

:::problem{difficulty="challenge"}
**P5 — Directional strafe blend.**
 A 3D character uses a `BlendSpace2D` named
 `"StraveBS"` for locomotion (clips at the 8 cardinal
 and ordinal directions, plus a centre Idle). The X axis represents
 right strafe, the Y axis represents forward movement. Write the
 `_physics_process()` code that computes the blend
 position from the character's velocity relative to its facing
 direction (so strafing right always moves the X blend axis
 regardless of world orientation). Normalise the velocity to the
 blend range [−1, 1].

::::solution[Solution]
```gdscript
@onready var _anim_tree: AnimationTree = $AnimationTree
const MAX_SPEED := 5.0   # m/s in 3D

func _physics_process(delta: float) -> void:
    # Get velocity in character-local space (ignoring Y/vertical).
    var world_vel := Vector2(velocity.x, velocity.z)
    var facing    := Vector2(-sin(rotation.y), -cos(rotation.y))  # forward dir
    var right     := Vector2(facing.y, -facing.x)                  # right dir

    var local_x: float = world_vel.dot(right)    / MAX_SPEED
    var local_y: float = world_vel.dot(facing)   / MAX_SPEED

    var blend_pos := Vector2(
        clampf(local_x, -1.0, 1.0),
        clampf(local_y, -1.0, 1.0)
    )
    _anim_tree.set("parameters/StrafeBS/blend_position", blend_pos)
```
::::
:::

:::problem{difficulty="challenge"}
**P6 — Full character animation controller.**
 Write an `AnimationController` component (extends
 `Node`) intended to be a child of a
 `CharacterBody3D`. It should expose:
 `set_speed(speed: float)`,
 `set_move_direction(dir: Vector2)`,
 `trigger_attack()`,
 `trigger_hit_reaction()`,
 `set_aim_pitch(degrees: float)`,
 `set_grounded(v: bool)`,
 `set_airborne_velocity(y: float)`.
 Use a state machine with states Grounded (containing a
 BlendSpace2D for locomotion) and Airborne (containing a
 BlendSpace1D for rise vs fall), a OneShot for attack, a second
 OneShot for hit reaction, and a Blend2 for aim pitch.
 All paths should be declared as constants at the top of the
 class.

::::solution[Solution]
```gdscript
class_name AnimationController
extends Node

# ── Parameter paths ─────────────────────────────────────────────────────────
const P_PLAYBACK   := "parameters/playback"
const P_LOCO_DIR   := "parameters/Grounded/LocoBS2D/blend_position"
const P_AIR_VEL    := "parameters/Airborne/AirBS1D/blend_position"
const P_AIM        := "parameters/AimBlend/blend_amount"
const P_ATTACK     := "parameters/AttackShot/request"
const P_HIT        := "parameters/HitShot/request"
const P_GROUNDED   := "parameters/conditions/is_grounded"
const P_AIRBORNE   := "parameters/conditions/is_airborne"

const MAX_SPEED    := 5.0
const MAX_AIR_VEL  := 12.0   # m/s vertical

@onready var _tree: AnimationTree = get_parent().get_node("AnimationTree")
@onready var _pb:   AnimationNodeStateMachinePlayback = _tree.get(P_PLAYBACK)

func _ready() -> void:
    _tree.active = true
    _pb.start("Grounded")

func set_speed(_speed: float) -> void:
    pass  # handled via set_move_direction magnitude

func set_move_direction(dir: Vector2) -> void:
    _tree.set(P_LOCO_DIR, dir.limit_length(1.0))

func trigger_attack() -> void:
    _tree.set(P_ATTACK, AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

func trigger_hit_reaction() -> void:
    _tree.set(P_HIT, AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

func set_aim_pitch(degrees: float) -> void:
    var blend: float = clampf(degrees / 60.0, 0.0, 1.0)
    _tree.set(P_AIM, blend)

func set_grounded(v: bool) -> void:
    _tree.set(P_GROUNDED, v)
    _tree.set(P_AIRBORNE, not v)

func set_airborne_velocity(y: float) -> void:
    # Map negative-y (rising) → 0, positive-y (falling) → 1
    var norm: float = clampf(y / MAX_AIR_VEL, 0.0, 1.0)
    _tree.set(P_AIR_VEL, norm)
```
::::
:::
