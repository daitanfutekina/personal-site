---
title: "Export & Deployment — Building for Every Platform"
source: "godot_ch22_export.html"
---

Part III · Chapter 22

# Export & Deployment — Building for Every Platform

Prerequisite: Chapter 7 (Project Settings) · est. 70 min

## Overview

Exporting a Godot project packages your scenes, scripts, and assets into a self-contained
 executable (or web bundle) that can run without the Godot editor. The process has two parts:

- **Export templates** — precompiled Godot runtimes for each target platform,
 downloaded from the Godot website. You install them once and they are used by all projects.
- **Export presets** — per-project configurations that define which platform to
 target, which features to include, and all platform-specific settings (icons, signing, etc.).

Exports also support **PCK patches** (hot-swapping resource packs at runtime —
 useful for DLC and mods), **feature flags** (conditional code for platform
 differences), and **headless / command-line export** for CI/CD pipelines.

## 1 · Export Templates

### 1.1 · Installing export templates

In the editor: **Editor → Manage Export Templates → Download and Install**.
 Choose the version that matches your Godot editor exactly. Templates are stored in
 `%APPDATA%\Godot\export_templates\` (Windows) or
 `~/.local/share/godot/export_templates/` (Linux/macOS).

For CI pipelines, download the template ZIP manually and extract it to the correct path
 before running the headless export command.

### 1.2 · Export presets

Open **Project → Export**. Click **Add…** to create a preset for
 each target platform. Key settings common to all presets:

| Setting | Purpose |
| --- | --- |
| **Export Path** | Where the output file(s) are written; must end in the correct extension (.exe, .apk, .html, etc.) |
| **Resources → Export Mode** | "Export all resources" vs "Export selected scenes" vs "Export selected resources" |
| **Features** | Custom feature tags that can be queried with `OS.has_feature()` |
| **Encryption** | Set an encryption key to protect your PCK/scripts (requires a custom export template) |
| **Debug → Export with Debug** | Leave enabled for test builds; disable for release to strip debugger overhead |

:::callout-tip
💡 export\_presets.cfg vs .gitignore

export\_presets.cfg

contains signing keys and credentials.  Add it to

.gitignore

if your repository is public.  Store secrets in environment
        variables and inject them in CI instead.
:::

## 2 · Platform-Specific Settings

### 2.1 · Windows

- **Application → Icon** — set a 256×256 `.ico` file.
- **Application → File Version / Product Version** — shown in Windows file properties.
- **Codesigning** — sign with a PFX certificate to avoid SmartScreen warnings.
 Leave blank for local testing; required for Steam / itch.io distribution.
- **Console Window** — disable for release builds to avoid a black terminal
 opening alongside your game.

### 2.2 · macOS

- Requires an Apple Developer account for notarisation (mandatory for distributing outside TestFlight).
- Set **Application → Bundle Identifier** (e.g. `com.studio.mygame`).
- Run `codesign` and `xcrun notarytool` after export for Gatekeeper acceptance.
- Godot exports a `.app` bundle or a `.dmg` depending on the preset.

### 2.3 · Linux

- Exports a single ELF binary; no installer by default.
- Set executable permissions: `chmod +x MyGame.x86_64`.
- For Steam, use the official Steamworks GDNative plugin and include the Steam runtime libraries.

### 2.4 · Android

1. Install **Android SDK + JDK** and set their paths in *Editor Settings → Export → Android*.
2. In the export preset: set **Package → Unique Name** (e.g. `com.studio.mygame`).
3. Create a **debug keystore** for testing: `keytool -genkey -v -keystore debug.keystore -alias androiddebugkey …`
4. For Play Store: create a release keystore and keep it secure.
5. Set minimum SDK version (21 for 64-bit; 14 is absolute minimum) and target SDK (33+).
6. Enable **internet** permission if your game uses networking.

```gdscript

# Check at runtime if running on Android:
if OS.get_name() == "Android":
    $VirtualJoystick.visible = true
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
```

### 2.5 · iOS

- Requires **Xcode on macOS** — you cannot build iOS from Windows or Linux.
- Godot exports an Xcode project; open it and hit **Product → Archive** to submit to App Store Connect.
- Set Bundle ID, Version, and signing team in the export preset.
- Enable required capabilities in the Xcode project (GameCenter, iCloud, etc.).

### 2.6 · Web (HTML5)

- Exports an `.html`, `.js`, `.wasm`, and `.pck` bundle.
- Requires a web server with correct MIME types and **SharedArrayBuffer headers**:
 `Cross-Origin-Opener-Policy: same-origin` and
 `Cross-Origin-Embedder-Policy: require-corp` (needed for threading and audio).
- Enable **Extensions Support** (GDExtension) only if your game uses native plugins.
- Test with `godot --headless --serve` or Python's `http.server` locally.

```bash

# Simple local HTTPS server for testing web exports (Python 3):
python3 -c "
import http.server, ssl
server = http.server.HTTPServer(('', 8080), http.server.SimpleHTTPRequestHandler)
print('Serving on https://localhost:8080')
server.serve_forever()
"
# Then open https://localhost:8080/index.html
```

:::callout-warning
⚠️ SharedArrayBuffer requirement

Without the two COOP/COEP headers, Godot's web export will not run threading or audio
        in most modern browsers.  itch.io sets them automatically; GitHub Pages does not (use a
        custom

\_headers

file or Cloudflare Pages instead).
:::

## 3 · PCK Files & Patching

### 3.1 · What is a PCK?

A **PCK** (Pack) file is a virtual filesystem archive containing Godot resources.
 When you export a project, all assets are packed into a `.pck` file (or embedded
 into the executable). You can:

- Ship the game as `MyGame.exe + MyGame.pck` (PCK alongside binary).
- Embed the PCK inside the executable (single-file distribution).
- Load additional PCK files at runtime for DLC, mods, or hotfixes.

### 3.2 · Loading external PCKs at runtime

```gdscript

# Load a DLC pack from the user's data directory
func load_dlc(filename: String) -> bool:
    var path := "user://dlc/" + filename
    if not FileAccess.file_exists(path):
        push_error("DLC file not found: %s" % path)
        return false

    var ok := ProjectSettings.load_resource_pack(path)
    if not ok:
        push_error("Failed to load PCK: %s" % path)
        return false

    print("DLC loaded: %s" % filename)
    return true

# After loading, resources from the PCK are accessible via normal res:// paths:
# var dlc_scene := load("res://dlc/world_3/world_3.tscn")
```

:::callout-pitfall
🔴 PCK path conflicts

A PCK loaded at runtime can

override

existing

res://

paths if it
        contains files with the same paths — this is intentional for hotfixes but can cause
        hard-to-debug issues if DLC resource paths are not namespaced (e.g.

res://dlc/pack1/

).
        Always namespace DLC content under a unique directory.
:::

## 4 · Feature Flags & OS Detection

Feature tags let you write conditional code that compiles or runs differently per platform
 without `if/else` chains on `OS.get_name()`:

```gdscript

# Built-in feature tags (always available):
OS.has_feature("windows")      # true on Windows builds
OS.has_feature("macos")
OS.has_feature("linux")
OS.has_feature("android")
OS.has_feature("ios")
OS.has_feature("web")
OS.has_feature("mobile")       # true on Android and iOS
OS.has_feature("pc")           # true on Windows, macOS, Linux
OS.has_feature("debug")        # true in editor and debug exports
OS.has_feature("release")      # true in release exports only
OS.has_feature("editor")       # true only inside the Godot editor

# Custom tags — add them in the export preset under "Features":
OS.has_feature("steam")        # if you added "steam" to the preset
OS.has_feature("demo")         # for a demo build preset
```

```gdscript

# Practical usage — show touch controls on mobile only
func _ready() -> void:
    $VirtualJoystick.visible = OS.has_feature("mobile")
    $TouchButtons.visible    = OS.has_feature("mobile")

# Adjust quality settings per platform
func _apply_platform_settings() -> void:
    if OS.has_feature("web"):
        RenderingServer.set_default_clear_color(Color.BLACK)
        # Reduce particle count on web
        $ParticleSystem.amount = 50
    elif OS.has_feature("mobile"):
        $ParticleSystem.amount = 100
    else:
        $ParticleSystem.amount = 500
```

## 5 · Headless / CI Export

Export from the command line using the `--headless` flag and
 `--export-release` (or `--export-debug`). This is the basis of
 automated build pipelines:

```bash

# Export Windows release build (preset name must match exactly)
godot --headless --export-release "Windows Desktop" builds/windows/MyGame.exe

# Export web build
godot --headless --export-release "Web"  builds/web/index.html

# Export Android APK
godot --headless --export-release "Android" builds/android/MyGame.apk

# Export PCK only (no executable — useful for patches)
godot --headless --export-pack "Windows Desktop" builds/patch.pck
```

### 5.1 · GitHub Actions example

```yaml

# .github/workflows/export.yml
name: Export Godot Game

on:
  push:
    tags: [ "v*" ]

jobs:
  export:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Godot
        uses: chickensoft-games/setup-godot@v2
        with:
          version: "4.6.stable"
          include-templates: true   # downloads export templates automatically

      - name: Export Windows
        run: |
          mkdir -p builds/windows
          godot --headless --export-release "Windows Desktop" builds/windows/MyGame.exe

      - name: Export Web
        run: |
          mkdir -p builds/web
          godot --headless --export-release "Web" builds/web/index.html

      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: game-builds
          path: builds/
```

:::callout-tip
💡 Validate before shipping

Add a

godot --headless --check-only

step before the export step to catch
        GDScript errors without running the game.  It exits with a non-zero code on parse errors,
        failing the CI build cleanly.
:::

## Summary

| Concept | Key takeaway |
| --- | --- |
| **Export templates** | Precompiled runtimes — install once, match editor version exactly |
| **Export presets** | Per-platform configuration; store in export\_presets.cfg (gitignore for public repos) |
| **Web COOP/COEP headers** | Required for SharedArrayBuffer (threading + audio) — not set by default on GitHub Pages |
| **PCK loading** | `ProjectSettings.load_resource_pack(path)` — namespace DLC paths to avoid conflicts |
| **OS.has\_feature()** | Platform detection at runtime; custom tags addable per export preset |
| **Headless export** | `godot --headless --export-release "Preset Name" output/path` |
| **Android signing** | Debug keystore for testing; release keystore for Play Store — keep release keystore in secrets |
| **--check-only** | Validates GDScript in CI without launching the game |

- Always test exports on real hardware or a clean VM — the editor hides many issues that appear at runtime.
- Disable the console window on Windows release builds.
- Use feature tags instead of `OS.get_name()` strings — they're more composable and support custom tags.
- Automate exports in CI from day one; shipping manually once is fine but twice is already error-prone.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Platform-adaptive UI

In `_ready()`, show a `$VirtualJoystick` node only on mobile,
 hide the `$KeyboardHints` panel on mobile and web, and set
 `$QualityLabel.text` to `"PC"`, `"Mobile"`, or
 `"Web"` depending on the platform.

::::solution[Solution]
```gdscript

func _ready() -> void:
    $VirtualJoystick.visible  = OS.has_feature("mobile")
    $KeyboardHints.visible    = not OS.has_feature("mobile") and not OS.has_feature("web")

    if OS.has_feature("web"):
        $QualityLabel.text = "Web"
    elif OS.has_feature("mobile"):
        $QualityLabel.text = "Mobile"
    else:
        $QualityLabel.text = "PC"
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · User data path display

Print the full path of `user://` to the Output panel so you can find save files
 during development. Also print whether the current build is debug or release.

::::solution[Solution]
```gdscript

func _ready() -> void:
    print("User data dir: ", OS.get_user_data_dir())
    print("Build type: ", "debug" if OS.has_feature("debug") else "release")
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · DLC loader with error handling

Write a `DLCManager` autoload with:
 `load_pack(filename: String) → Error` that checks the file exists in
 `user://dlc/`, loads it, emits a `dlc_loaded(filename)` signal
 on success, and returns the appropriate error code on failure.

::::solution[Solution]
```gdscript

extends Node

signal dlc_loaded(filename: String)

func load_pack(filename: String) -> Error:
    var path := "user://dlc/" + filename
    if not FileAccess.file_exists(path):
        push_error("DLC not found: " + path)
        return ERR_FILE_NOT_FOUND

    if not ProjectSettings.load_resource_pack(path):
        push_error("Failed to load PCK: " + path)
        return ERR_CANT_OPEN

    dlc_loaded.emit(filename)
    return OK
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · CI shell script for multi-platform export

Write a Bash script `export.sh` that exports Windows, Linux, and Web builds
 into `builds/windows/`, `builds/linux/`, and `builds/web/`
 respectively. It should exit immediately on any error (`set -e`) and print
 each step.

::::solution[Solution]
```bash

#!/usr/bin/env bash
set -euo pipefail

GODOT="${GODOT_BIN:-godot}"

echo "=== Creating output directories ==="
mkdir -p builds/windows builds/linux builds/web

echo "=== Exporting Windows ==="
"$GODOT" --headless --export-release "Windows Desktop" builds/windows/MyGame.exe

echo "=== Exporting Linux ==="
"$GODOT" --headless --export-release "Linux/X11" builds/linux/MyGame.x86_64
chmod +x builds/linux/MyGame.x86_64

echo "=== Exporting Web ==="
"$GODOT" --headless --export-release "Web" builds/web/index.html

echo "=== All builds complete ==="
ls -lh builds/windows/ builds/linux/ builds/web/
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Version string from build

Read the version number from `ProjectSettings.get_setting("application/config/version")`
 and display it in a label. Append `" [DEBUG]"` if running a debug build.
 Show the result in a `$VersionLabel`.

::::solution[Solution]
```gdscript

func _ready() -> void:
    var ver: String = ProjectSettings.get_setting("application/config/version", "0.0.0")
    var label := ver
    if OS.has_feature("debug"):
        label += " [DEBUG]"
    $VersionLabel.text = "v" + label
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Mod loader

Build a `ModLoader` autoload that:

- Scans `user://mods/` for `*.pck` files on startup.
- Loads each PCK and reads a `res://mod_info.json` file from inside it
 to get the mod's name and version.
- Keeps a `Dictionary` of loaded mods (`filename → {name, version}`).
- Emits `mod_loaded(filename, info)` for each successful load.
- Skips PCKs that fail to load or lack `mod_info.json`, printing a warning.

::::solution[Solution]
```gdscript

extends Node

signal mod_loaded(filename: String, info: Dictionary)

var loaded_mods: Dictionary = {}

func _ready() -> void:
    _scan_mods()

func _scan_mods() -> void:
    var dir := DirAccess.open("user://mods/")
    if dir == null:
        return   # mods directory doesn't exist yet

    dir.list_dir_begin()
    var file := dir.get_next()
    while file != "":
        if file.ends_with(".pck"):
            _try_load_mod(file)
        file = dir.get_next()
    dir.list_dir_end()

func _try_load_mod(filename: String) -> void:
    var path := "user://mods/" + filename

    if not ProjectSettings.load_resource_pack(path):
        push_warning("ModLoader: failed to load PCK '%s'" % filename)
        return

    # Read mod_info.json from inside the now-mounted PCK
    if not FileAccess.file_exists("res://mod_info.json"):
        push_warning("ModLoader: '%s' has no mod_info.json — skipping" % filename)
        return

    var f := FileAccess.open("res://mod_info.json", FileAccess.READ)
    var info: Dictionary = JSON.parse_string(f.get_as_text())
    f.close()

    if typeof(info) != TYPE_DICTIONARY:
        push_warning("ModLoader: mod_info.json in '%s' is not valid JSON" % filename)
        return

    loaded_mods[filename] = info
    mod_loaded.emit(filename, info)
    print("Mod loaded: %s v%s" % [info.get("name", filename), info.get("version", "?")])
```
::::
:::
