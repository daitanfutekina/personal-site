---
title: "Camera — Camera2D, Camera3D & Viewports"
source: "markdown"
---

Part III · Chapter 17

# Camera — Camera2D, Camera3D & Viewports

Prerequisite: Chapters 2 (Editor tour) and 14 (Tween) · est. 80 min

## Overview

Godot's camera system lets you define exactly what region of the world is visible, with separate
 nodes for 2D and 3D. Both cameras are nodes you place in the scene tree — making a camera
 *current* switches the active viewpoint instantly, which makes cinematic cut-scenes and
 split-screen multiplayer straightforward to implement.

- **Camera2D** — follows a position in 2D space, with built-in smoothing, limits,
 drag margins, and zoom.
- **Camera3D** — a perspective (or orthographic) camera in 3D space, with FOV,
 an environment resource for sky/fog/ambient, and post-processing via `CameraAttributes`.
- **SubViewport + ViewportTexture** — render a second camera to a texture;
 the foundation for split-screen, minimaps, and in-game monitors.

⬡ — Camera2D — inherits Node2D

Controls what portion of the 2D world is visible on screen. You typically make it a child of the player node so it follows automatically, then tune limits, smoothing, and drag margins to polish the feel. Only one Camera2D can be active per Viewport — set `enabled = true` to make one current.

| Property | Default | What it does |
| --- | --- | --- |
| enabled | true | Makes this camera the active one in its Viewport. Only one active camera per Viewport at a time |
| zoom | Vector2(1,1) | Multiplier on world scale. Vector2(2,2) makes everything appear twice as large (zoomed in). Vector2(0.5,0.5) shows twice as much world |
| position\_smoothing\_enabled | false | Lerps toward the target position for a buttery follow feel instead of snapping |
| position\_smoothing\_speed | 5.0 | How fast smoothing catches up — lower = laggy cinematic, higher = snappy |
| rotation\_smoothing\_enabled | false | Smooths camera rotation — useful when the camera tilts with the player |
| drag\_horizontal\_enabled | false | Creates a dead-zone: camera only moves once the player exits the drag margin horizontally |
| drag\_vertical\_enabled | false | Same but vertical — common for platformers where you want the camera to stay put while jumping |
| limit\_left/right/top/bottom | ±10 000 000 | Hard bounds; camera never scrolls past these coordinates. Set to TileMap boundaries to avoid showing void |
| offset | Vector2(0,0) | Shifts the camera view without changing the node's position — useful for look-ahead effects |
| anchor\_mode | DRAG\_CENTER | DRAG\_CENTER: camera centres on position. FIXED\_TOP\_LEFT: (0,0) stays top-left — useful for HUD-style fixed views |
| ignore\_rotation | true | Camera stays axis-aligned even if the parent rotates — turn off for tilt effects |

Use when:

any 2D game needs scrolling — platformers, top-down RPGs, shoot-em-ups, metroidvanias.

Common setup:

child of the player node + position\_smoothing\_enabled + limit set to TileMapLayer bounds.

Avoid:

parenting directly to a RigidBody2D — physics jitter transfers to the camera. Smooth on a CharacterBody2D instead, or reparent to a separate lerped node.

## 1 · Camera2D

### 1.1 · Positioning and following

Place a `Camera2D` as a *child* of the player node and it follows automatically
 because its global position is inherited from its parent. If you need custom follow logic,
 place it as a standalone node and update its position in code.

```gdscript

# Option A — child of player (zero scripting needed):
# Player
#   └─ Camera2D   ← just add it here; it tracks the player's position

# Option B — standalone camera with custom follow (e.g. dead-zone, look-ahead)
extends Camera2D

@export var target: Node2D
@export var follow_speed: float = 5.0

func _process(delta: float) -> void:
    if target:
        global_position = global_position.lerp(target.global_position, follow_speed * delta)
```

Only one Camera2D can be *current* at a time. Set `make_current()` or tick
 the **Current** property in the inspector. You can switch cameras during a cutscene
 by calling `cutscene_cam.make_current()` and then `player_cam.make_current()`
 when it ends.

limit\_left / top / right / bottom (world boundary)

Camera viewport

drag margin (dead zone)

player

drag\_left\_margin

drag\_right\_margin

drag\_top

drag\_bottom

zoom = Vector2(1,1)

= 100% view

Camera2D concepts at a glance. The **limits** (dashed outer rect) stop the camera leaving the world. **Drag margins** (inner rect) define the dead zone — the camera only moves when the player leaves this zone.

### 1.2 · Limits — keep the camera inside the world

Limits clamp the camera so it never reveals space outside your level. Set them to match your
 world bounds (in pixels, world-space):

```gdscript

@onready var cam: Camera2D = $Camera2D

func setup_limits(world_rect: Rect2) -> void:
    cam.limit_left   = int(world_rect.position.x)
    cam.limit_top    = int(world_rect.position.y)
    cam.limit_right  = int(world_rect.end.x)
    cam.limit_bottom = int(world_rect.end.y)
    cam.limit_smoothed = true   # smooth into the boundary instead of snapping
```

:::callout-tip
💡 TileMapLayer world bounds

After you paint your level, use

tile\_map.get\_used\_rect()

multiplied by

tile\_set.tile\_size

to compute the pixel bounds automatically, then feed them
        into the limit setters above.
:::

### 1.3 · Position smoothing

Enable **Position Smoothing** in the Camera2D inspector (or in code) for a
 natural trailing feel. The `speed` property controls how quickly the camera
 catches up to its target position:

```gdscript

cam.position_smoothing_enabled = true
cam.position_smoothing_speed   = 5.0   # lower = more lag; higher = snappier

# Rotation smoothing (useful for tilting the camera with the ship/vehicle)
cam.rotation_smoothing_enabled = true
cam.rotation_smoothing_speed   = 3.0
```

### 1.4 · Drag margins

Drag margins define a dead-zone rectangle around the screen centre. The camera only starts
 following the target when it moves outside this rectangle, which feels more cinematic and
 less seasick than constant tracking:

```gdscript

cam.drag_horizontal_enabled = true
cam.drag_horizontal_offset  = 0.1   # bias — positive shifts the view right
cam.drag_vertical_enabled   = true
cam.drag_vertical_offset    = -0.1  # slight upward bias (see more above player)
```

### 1.5 · Zoom

`Camera2D.zoom` is a `Vector2` where `(2, 2)` makes everything
 appear twice as large (zoomed in) and `(0.5, 0.5)` shows twice as much world (zoomed out).
 Always keep X and Y equal for non-distorted zoom:

```gdscript

cam.zoom = Vector2(1.5, 1.5)   # zoom in 1.5×

# Smooth zoom with Tween:
func zoom_to(target_zoom: float, duration: float = 0.4) -> void:
    var tw := create_tween()
    tw.tween_property(cam, "zoom", Vector2(target_zoom, target_zoom), duration)\
      .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```

### 1.6 · Camera shake

```gdscript

extends Camera2D

var _shake_strength := 0.0
var _decay          := 5.0   # strength units lost per second

func shake(strength: float) -> void:
    _shake_strength = strength

func _process(delta: float) -> void:
    if _shake_strength > 0.01:
        offset = Vector2(
            randf_range(-_shake_strength, _shake_strength),
            randf_range(-_shake_strength, _shake_strength)
        )
        _shake_strength = lerpf(_shake_strength, 0.0, _decay * delta)
    else:
        _shake_strength = 0.0
        offset = Vector2.ZERO
```

## 2 · Advanced 2D Camera Techniques

### 2.1 · Look-ahead

Look-ahead shifts the camera view in the direction the player is moving, giving them more
 time to react to what's ahead. Blend between the player's position and a point projected
 in the movement direction:

```gdscript

extends Camera2D

@export var target:        Node2D
@export var lookahead_dist: float = 80.0
@export var follow_speed:   float = 5.0

var _velocity_smooth := Vector2.ZERO

func _process(delta: float) -> void:
    if not target:
        return
    var body := target as CharacterBody2D
    if body:
        _velocity_smooth = _velocity_smooth.lerp(body.velocity, 10.0 * delta)

    var look_offset := _velocity_smooth.normalized() * lookahead_dist \
                       if _velocity_smooth.length() > 10.0 else Vector2.ZERO
    var desired := target.global_position + look_offset
    global_position = global_position.lerp(desired, follow_speed * delta)
```

### 2.2 · Room transition

Many 2D games use room-based maps where the camera snaps or slides to the next room when the
 player crosses a boundary. A clean implementation uses two cameras — one per room — and
 a Tween to slide between them:

```gdscript

# RoomManager.gd
extends Node2D

@onready var cam: Camera2D = $Camera2D

var _room_centers: Array[Vector2] = []   # populate from room data
var _current_room := 0

func enter_room(room_index: int) -> void:
    if room_index == _current_room:
        return
    _current_room = room_index
    var tw := create_tween()
    tw.tween_property(cam, "global_position",
                      _room_centers[room_index], 0.5)\
      .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
```

⬡ — Camera3D — inherits Node3D

The viewpoint for 3D scenes. Only the current camera (the one where `current = true`, or the one made current via `make_current()`) is rendered to the screen. Like Camera2D, you can have many in the scene but only one is active at a time — enabling cinematic cut-scenes by simply swapping which one is current.

| Property | Default | What it does |
| --- | --- | --- |
| projection | PERSPECTIVE | PERSPECTIVE: realistic foreshortening (most games). ORTHOGONAL: flat isometric look with no depth distortion. FRUSTUM: offset perspective for custom effects |
| fov | 75° | Field of view in perspective mode — wider = more visible, more distortion. Typical FPS: 70–90°. Cinematic: 35–50° |
| near | 0.05 | Near clipping plane distance. Objects closer than this disappear. Too small = Z-fighting on far geometry |
| far | 4000 | Far clipping plane. Objects beyond this are culled. Keep as small as your scene allows for best depth precision |
| current | false | Set true to make this the active camera. Only one Camera3D can be current per Viewport |
| cull\_mask | all layers | Which 3D visibility layers this camera renders — use to hide objects from specific cameras (e.g., exclude UI geometry from a reflection camera) |
| environment | null | Override the world Environment resource for this camera — useful for per-level fog and sky settings |
| attributes | null | CameraAttributesPractical or CameraAttributesPhysical for DOF, exposure, and auto-exposure |

Use when:

rendering any 3D scene — first-person, third-person, isometric (set projection = ORTHOGONAL), cinematic sequences.

Cinematic tip:

parent multiple Camera3D nodes to a Node3D "camera rig" and call

make\_current()

on each to cut between shots without moving a single camera.

## 3 · Camera3D

### 3.1 · Projection and FOV

Camera3D can project in *perspective* (the default — closer objects look larger) or
 *orthographic* (parallel projection — no depth foreshortening, used for isometric games):

```gdscript

@onready var cam: Camera3D = $Camera3D

func setup_perspective(fov_deg: float = 75.0) -> void:
    cam.projection = Camera3D.PROJECTION_PERSPECTIVE
    cam.fov        = fov_deg          # horizontal FOV in degrees
    cam.near       = 0.05             # near clip plane (metres)
    cam.far        = 500.0            # far clip plane

func setup_ortho(size_m: float = 10.0) -> void:
    cam.projection = Camera3D.PROJECTION_ORTHOGONAL
    cam.size       = size_m           # world units visible vertically
```

| Property | Typical value | Effect |
| --- | --- | --- |
| `fov` | 70–90° | Wider = more fisheye/action feel; narrower = telephoto/sniper feel |
| `near` | 0.05–0.1 m | Too large → objects clip when close; too small → z-fighting at distance |
| `far` | 100–1000 m | Extends draw distance; also expands the depth buffer range (may worsen z-fighting) |
| `keep_aspect` | KEEP\_HEIGHT | KEEP\_WIDTH or KEEP\_HEIGHT — which dimension is fixed when resizing the window |

### 3.2 · Environment and sky

Attach a `WorldEnvironment` node (or set the `environment` property on
 the Camera3D) to control ambient light, background, fog, and tone-mapping. The
 `Environment` resource holds all the settings:

```gdscript

var env := Environment.new()

# Background
env.background_mode  = Environment.BG_SKY
env.sky              = Sky.new()
# Or a solid colour:
env.background_mode  = Environment.BG_COLOR
env.background_color = Color(0.1, 0.12, 0.18)

# Ambient light
env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
env.ambient_light_color  = Color(0.2, 0.2, 0.3)
env.ambient_light_energy = 0.4

# Fog
env.fog_enabled  = true
env.fog_density  = 0.01
env.fog_aerial_perspective = 0.5

# Tone mapping
env.tonemap_mode      = Environment.TONE_MAPPER_FILMIC
env.tonemap_exposure  = 1.0

$Camera3D.environment = env
```

### 3.3 · Post-processing — CameraAttributes

Attach a `CameraAttributesPhysical` or `CameraAttributesPractical`
 resource to the Camera3D for depth of field, auto-exposure, and
 chromatic aberration. `Physical` mimics real camera settings (aperture, shutter,
 ISO); `Practical` gives direct artistic controls:

```gdscript

var attr := CameraAttributesPractical.new()

# Depth of field blur
attr.dof_blur_far_enabled   = true
attr.dof_blur_far_distance  = 20.0   # metres — objects beyond this blur
attr.dof_blur_far_transition = 5.0
attr.dof_blur_amount         = 0.1

# Auto-exposure
attr.auto_exposure_enabled = true
attr.auto_exposure_min_sensitivity = 50.0   # EV100
attr.auto_exposure_max_sensitivity = 800.0

$Camera3D.attributes = attr
```

:::callout-tip
💡 Switch cameras for cinematics

Author a second Camera3D in your scene and call

cinematic\_cam.make\_current()

to cut to it instantly, or Tween its

global\_transform

for a dolly shot.
        Restore the player camera with `player_cam.make_current()`.
:::

## 4 · Viewports & Split-screen

⬡ — SubViewport — inherits Viewport → Node

A secondary render target inside the main scene. The scene tree it contains is rendered independently to a texture, which you display via a `SubViewportContainer` or sample in a shader. Use it for minimaps, picture-in-picture, in-game screens, mirrors, and split-screen setups.

| Property | Default | What it does |
| --- | --- | --- |
| size | Vector2i(512,512) | Render resolution in pixels — independent of the display it's shown on |
| render\_target\_update\_mode | WHEN\_VISIBLE | ALWAYS re-renders every frame; ONCE renders only on demand (save GPU time for static views); DISABLED skips rendering entirely |
| render\_target\_clear\_mode | ALWAYS | Whether to clear the texture before each frame — NEVER useful for accumulation effects |
| transparent\_bg | false | Clear colour is transparent instead of black — essential for UI overlays and PiP with alpha |
| disable\_3d | false | Skip 3D rendering pipeline — saves GPU if the sub-scene is 2D only |
| world\_2d / world\_3d | null | Share a world with the parent viewport to see the same objects from a different angle (mirrors, security cameras) |

Use when:

you need an independently rendered camera view — minimap, split-screen player view, in-game TV screen, rear-view mirror, or portal effect.

For split-screen:

create one SubViewport per player, each with its own Camera2D/3D, then tile them with SubViewportContainers.

Performance tip:

set

render\_target\_update\_mode = ONCE

for static thumbnails or inventory previews that only need to refresh occasionally.

### 4.1 · SubViewport

A `SubViewport` is an off-screen render target. It has its own scene tree, its own
 camera, and produces a `ViewportTexture` you can display anywhere — on a
 `SubViewportContainer`, a `Sprite2D`, or a `MeshInstance3D`
 material (security camera monitor, portal, minimap):

```gdscript

# Scene tree:
# SubViewportContainer  (Control, fills half the screen)
#   └─ SubViewport
#        └─ Camera2D or Camera3D
#        └─ (whatever you want rendered here)

# The SubViewportContainer automatically shows the SubViewport's rendered output.
# To get the texture manually:
var tex: ViewportTexture = $SubViewport.get_texture()
$MinimapSprite.texture   = tex
```

### 4.2 · 2-player split-screen

Godot makes split-screen straightforward: two `SubViewportContainer`s side by side
 (or top/bottom), each containing its own `SubViewport` with a dedicated camera
 following its own player character:

```gdscript

# Scene tree for horizontal split:
# HBoxContainer                         (fills screen)
#   ├─ SubViewportContainer  (50% width, 100% height)
#   │    └─ SubViewport
#   │         ├─ Player1 (or scene instance)
#   │         └─ Camera2D  current=true
#   └─ SubViewportContainer  (50% width, 100% height)
#        └─ SubViewport
#             ├─ Player2
#             └─ Camera2D  current=true

# Both SubViewports render the same scene if you share a world:
# In Project Settings → Rendering → Viewport → set both SubViewports
# to use the same World2D resource.
```

```gdscript

# Share World2D between two SubViewports so they see the same scene:
func _ready() -> void:
    var shared_world := World2D.new()
    $SVC1/SubViewport.world_2d = shared_world
    $SVC2/SubViewport.world_2d = shared_world
    # Now spawn Player1 and Player2 into this shared world,
    # with each player's camera in their respective SubViewport.
```

:::callout-warning
⚠️ SubViewport performance

Each

SubViewport

renders the scene independently.  Two SubViewports roughly
        doubles your draw calls.  Minimise overdraw by using appropriate

render\_target\_update\_mode

:
        set it to

UPDATE\_WHEN\_VISIBLE

for off-screen elements like minimaps that
        don't need to update every frame.
:::

### 4.3 · Viewport render modes

```gdscript

var vp: SubViewport = $SubViewport

# How often the SubViewport redraws:
vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS         # every frame
vp.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE   # only if container is visible
vp.render_target_update_mode = SubViewport.UPDATE_ONCE           # one shot, then stops
vp.render_target_update_mode = SubViewport.UPDATE_DISABLED       # never (manual trigger)

# Trigger a single manual redraw when UPDATE_DISABLED:
vp.render_target_update_mode = SubViewport.UPDATE_ONCE   # re-arm for one frame
```

## Summary

| Concept | Key takeaway |
| --- | --- |
| **Camera2D as child** | Zero-script follow — parent determines the followed position |
| **limit\_\*** | Clamp the camera to world bounds; set from TileMapLayer.get\_used\_rect() |
| **position\_smoothing** | Built-in lerp follow; adjust speed for game feel |
| **drag margins** | Dead-zone follow — camera only moves when target exits the margin rect |
| **zoom Vector2** | (2,2) = zoomed in 2×; (0.5,0.5) = zoomed out to show more world |
| **Camera3D FOV** | Wider = action/fish-eye; narrower = sniper/telephoto |
| **WorldEnvironment** | Sky, fog, ambient, tone-mapping — affects all Camera3Ds unless overridden |
| **CameraAttributes** | DOF, auto-exposure, chromatic aberration per-camera |
| **SubViewport** | Off-screen render target; share World2D/World3D for split-screen |

- Set camera limits to match your level bounds to prevent showing empty space.
- Use drag margins + look-ahead for a polished platformer feel; use pure lerp for top-down.
- Switch cameras (not positions) for cutscenes — keeps each camera's state independent.
- For split-screen, share a `World2D`/`World3D` resource between SubViewports
 so both players inhabit the same simulation.
- Set `UPDATE_WHEN_VISIBLE` on non-gameplay SubViewports (minimaps, monitors) to save GPU time.

## Mixed Practice

:::problem{difficulty="easy"}
### Problem 1 · Limit from TileMapLayer

Given a reference to a `TileMapLayer` node and a `Camera2D`, write a
 function `fit_camera_to_tilemap()` that sets the camera's four limits to exactly
 match the painted tile area.

::::solution[Solution]
```gdscript

func fit_camera_to_tilemap(cam: Camera2D, tmap: TileMapLayer) -> void:
    var used   := tmap.get_used_rect()           # Rect2i in tile coords
    var t_size := tmap.tile_set.tile_size         # Vector2i
    cam.limit_left   = used.position.x * t_size.x
    cam.limit_top    = used.position.y * t_size.y
    cam.limit_right  = used.end.x      * t_size.x
    cam.limit_bottom = used.end.y      * t_size.y
    cam.limit_smoothed = true
```
::::
:::

:::problem{difficulty="easy"}
### Problem 2 · Smooth zoom on scroll wheel

Extend a `Camera2D` script so that scrolling the mouse wheel smoothly tweens the
 zoom between 0.5× and 2.5× in steps of 0.2, using `TRANS_SINE / EASE_IN_OUT`.

::::solution[Solution]
```gdscript

extends Camera2D

const STEP     := 0.2
const ZOOM_MIN := 0.5
const ZOOM_MAX := 2.5
var _target_z  := 1.0

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            _target_z = clampf(_target_z + STEP, ZOOM_MIN, ZOOM_MAX)
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            _target_z = clampf(_target_z - STEP, ZOOM_MIN, ZOOM_MAX)
        else:
            return
        var tw := create_tween()
        tw.tween_property(self, "zoom", Vector2(_target_z, _target_z), 0.25)\
          .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
```
::::
:::

:::problem{difficulty="standard"}
### Problem 3 · Decay-based camera shake

Write a standalone `CameraShake` autoload that exposes `shake(strength, decay)`.
 It should support multiple simultaneous shake calls by summing their strengths. The camera it
 controls should be settable via an `@export` NodePath that the autoload resolves on
 `_ready()`.

::::solution[Solution]
```gdscript

# CameraShake.gd — Autoload
extends Node

@export var camera_path: NodePath

@onready var _camera: Camera2D = get_node(camera_path)

var _shakers: Array[Dictionary] = []   # [{strength, decay}]

func shake(strength: float, decay: float = 5.0) -> void:
    _shakers.append({"strength": strength, "decay": decay})

func _process(delta: float) -> void:
    if not _camera:
        return
    var total := 0.0
    var i := _shakers.size() - 1
    while i >= 0:
        var s: Dictionary = _shakers[i]
        total += s["strength"]
        s["strength"] = lerpf(s["strength"], 0.0, s["decay"] * delta)
        if s["strength"] < 0.01:
            _shakers.remove_at(i)
        i -= 1

    if total > 0.01:
        _camera.offset = Vector2(
            randf_range(-total, total),
            randf_range(-total, total)
        )
    else:
        _camera.offset = Vector2.ZERO
```
::::
:::

:::problem{difficulty="standard"}
### Problem 4 · Cinematic cut between cameras

A level has a `PlayerCamera` (Camera2D, current) and a `CinematicCamera`
 (Camera2D, not current). Write a coroutine `play_cutscene()` that:
 switches to the cinematic camera, waits 3 seconds (simulating a cutscene), then
 cross-fades back to the player camera using a black `ColorRect` overlay and Tween.

::::solution[Solution]
```gdscript

extends Node2D

@onready var player_cam    : Camera2D  = $PlayerCamera
@onready var cinematic_cam : Camera2D  = $CinematicCamera
@onready var fade_rect     : ColorRect = $FadeRect   # full-screen black ColorRect

func play_cutscene() -> void:
    # Fade to black
    fade_rect.visible   = true
    fade_rect.modulate.a = 0.0
    var tw := create_tween()
    tw.tween_property(fade_rect, "modulate:a", 1.0, 0.3)
    await tw.finished

    cinematic_cam.make_current()

    # Fade back in
    tw = create_tween()
    tw.tween_property(fade_rect, "modulate:a", 0.0, 0.3)
    await tw.finished
    fade_rect.visible = false

    # Cutscene runs…
    await get_tree().create_timer(3.0).timeout

    # Fade out again to switch back
    fade_rect.visible   = true
    tw = create_tween()
    tw.tween_property(fade_rect, "modulate:a", 1.0, 0.3)
    await tw.finished

    player_cam.make_current()

    tw = create_tween()
    tw.tween_property(fade_rect, "modulate:a", 0.0, 0.3)
    await tw.finished
    fade_rect.visible = false
```
::::
:::

:::problem{difficulty="standard"}
### Problem 5 · Minimap SubViewport

Set up a minimap in the corner of the screen that shows a zoomed-out view of the 2D world.
 Use a `SubViewport` with its own `Camera2D` (zoom 0.1×) that tracks
 the player, and display the result in a small `SubViewportContainer` anchored to
 the top-right of the screen.

::::solution[Solution]
```gdscript

# Scene structure:
# CanvasLayer (layer = 10, to draw on top of everything)
#   └─ SubViewportContainer  (anchor: top-right, size 200×150)
#        └─ SubViewport  (size 200×150, world_2d = same as main viewport)
#             └─ MinimapCamera (Camera2D)

# MinimapCamera.gd
extends Camera2D

@export var target: Node2D

func _ready() -> void:
    zoom = Vector2(0.1, 0.1)   # show 10× more world than normal

func _process(_delta: float) -> void:
    if target:
        global_position = target.global_position

# In the main scene _ready(), share the World2D:
func _ready() -> void:
    var main_vp: Viewport = get_viewport()
    $CanvasLayer/SubViewportContainer/SubViewport.world_2d = main_vp.world_2d
```
::::
:::

:::problem{difficulty="challenge"}
### Problem 6 · Full-featured 2D camera controller

Build a reusable `SmartCamera2D` node (extends `Camera2D`) with:

- Configurable lerp follow speed.
- Look-ahead that blends in over 0.3 s when velocity exceeds a threshold.
- Vertical dead-zone: camera only adjusts Y when the target moves more than 48 px above or below the dead-zone centre.
- Decay-based shake support via a `shake(strength)` method.
- Smooth zoom via `set_zoom_target(float)`.

::::solution[Solution]
```gdscript

extends Camera2D
class_name SmartCamera2D

@export var target         : Node2D
@export var follow_speed   : float = 5.0
@export var lookahead_dist : float = 80.0
@export var v_deadzone     : float = 48.0

var _look_blend    := Vector2.ZERO
var _shake_str     := 0.0
var _v_center      := 0.0      # current dead-zone Y reference in world space
var _zoom_target   := 1.0

func _ready() -> void:
    if target:
        _v_center = target.global_position.y

func shake(strength: float) -> void:
    _shake_str += strength

func set_zoom_target(z: float) -> void:
    _zoom_target = z

func _process(delta: float) -> void:
    if not target:
        return
    var body := target as CharacterBody2D

    # Look-ahead
    var vel := body.velocity if body else Vector2.ZERO
    var look_dir := vel.normalized() * lookahead_dist if vel.length() > 30.0 else Vector2.ZERO
    _look_blend = _look_blend.lerp(look_dir, 3.0 * delta)

    # Vertical dead-zone
    var ty := target.global_position.y
    if ty < _v_center - v_deadzone:
        _v_center = ty + v_deadzone
    elif ty > _v_center + v_deadzone:
        _v_center = ty - v_deadzone

    var desired := Vector2(target.global_position.x, _v_center) + _look_blend
    global_position = global_position.lerp(desired, follow_speed * delta)

    # Shake
    if _shake_str > 0.01:
        offset = Vector2(randf_range(-_shake_str, _shake_str),
                         randf_range(-_shake_str, _shake_str))
        _shake_str = lerpf(_shake_str, 0.0, 8.0 * delta)
    else:
        _shake_str = 0.0
        offset     = Vector2.ZERO

    # Smooth zoom
    var z := lerpf(zoom.x, _zoom_target, 6.0 * delta)
    zoom = Vector2(z, z)
```
::::
:::
