---
title: "VS Clone — Weapon System & Auto-Attack"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 71D"
meta:
  - "Est. study time: ~90 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated June 2026"
source: "godot_ch71d_weapons.html"
---

## Overview

Weapons are what separate a walking sim from Vampire Survivors. Every weapon is a
 fully autonomous node — it runs its own cooldown timer and fires without any player
 input. Adding a new weapon is a single call: `player.add_weapon(scene)`.
 Six weapons running simultaneously means six independent timers all firing in parallel,
 each dealing damage through the EnemyBase interface built in Ch 71C.

This chapter implements a shared `WeaponBase` class and three archetypes
 covering the core design space: area-of-effect pulse (Garlic), aimed projectile
 (Magic Wand), and arc throw with pierce (Axe).

:::callout-connect[What Ch 71B already gave us]
Player.tscn already has a `WeaponHolder` Node2D child. Player.gd
 already implements `add_weapon(scene)` which instantiates the scene and
 parents it to WeaponHolder. We are building the weapon scenes that slot into that
 holder — no Player.gd changes needed.
:::

:::callout-key[Weapons never touch Player.gd directly]
A weapon finds the player through its parent chain
 (`get_parent().get_parent()`) but only reads
 `_player.global_position`. It calls
 `enemy.take_damage()` on enemies it hits. That is the complete
 interface. New weapon types require zero changes to Player.gd or EnemyBase.gd.
:::

## 1. WeaponBase.gd — The Shared Foundation

:::callout-intuition[Why a base class for weapons?]
All weapons share the same core loop: wait for cooldown, fire, reset timer.
 They all need a reference to the player and a way to receive stat upgrades.
 WeaponBase handles all of that. Each concrete weapon only overrides
 `_fire()` — one method that describes what makes it unique.
:::

### Create WeaponBase.gd

1. **Create the weapons folder.** In the FileSystem dock,
 right-click `res://scenes/` → **New Folder**,
 name it `weapons`. Also create `res://resources/`
 if it doesn't exist yet.
2. **Create WeaponBase.gd.** Right-click
 `res://scenes/weapons/` → **New Script**.
 Name it `WeaponBase.gd`. Paste the full script below and
 save with Ctrl+S.

```gdscript
## res://scenes/weapons/WeaponBase.gd

class_name WeaponBase
extends Node2D

## ── Exported stats (tune per weapon in the Inspector) ────────────────
@export var damage: float         = 10.0
@export var cooldown: float       = 1.0   ## seconds between fires
@export var area: float           = 60.0  ## used by AOE weapons as radius
@export var projectile_count: int = 1
@export var weapon_level: int     = 1

## ── Runtime ───────────────────────────────────────────────────────────
var _player: Player         = null
var _cooldown_timer: float  = 0.0

func _ready() -> void:
    ## Weapon → WeaponHolder → Player. Two get_parent() calls.
    _player = get_parent().get_parent() as Player
    if _player == null:
        push_error("WeaponBase: must be a grandchild of Player via WeaponHolder")
    add_to_group("weapons")

func _physics_process(delta: float) -> void:
    _cooldown_timer -= delta
    if _cooldown_timer <= 0.0:
        _cooldown_timer = cooldown
        _fire()

## Override in subclass — called once per cooldown cycle.
func _fire() -> void:
    pass

## Called by the upgrade system (Ch 71E) when weapon_level increases.
func apply_upgrade(upgrade: WeaponUpgradeResource) -> void:
    damage    += upgrade.damage_bonus
    area      += upgrade.area_bonus
    cooldown   = maxf(0.1, cooldown - upgrade.cooldown_reduction)
    weapon_level += 1

## Utility: find the nearest live enemy to the player.
## Used by projectile weapons that need to aim.
func _get_nearest_enemy() -> EnemyBase:
    var best_dist := INF
    var nearest: EnemyBase = null
    for e in get_tree().get_nodes_in_group("enemies"):
        var d := _player.global_position.distance_squared_to(e.global_position)
        if d < best_dist:
            best_dist = d
            nearest   = e as EnemyBase
    return nearest
```

:::callout-pitfall[get\_nodes\_in\_group() is not slow]
`get_nodes_in_group("enemies")` is a hash-map lookup in Godot 4 —
 it does not traverse the scene tree. At 200 enemies iterating the array costs
 roughly 0.01 ms. Only the Magic Wand calls this every fire cycle; Garlic
 uses `get_overlapping_bodies()` on its Area2D, which is cheaper still.
:::

## 2. Garlic — AOE Pulse

Garlic creates a periodic shockwave that damages every enemy inside a radius.
 A single Area2D sized to the `area` export calls
 `get_overlapping_bodies()` when it fires — no projectile needed.

```
Garlic (Node2D)                  ← GarlicWeapon.gd
└── HitZone (Area2D)             ← Layer 5 (Weapons), Mask 3 (Enemies body layer)
    └── CollisionShape2D         ← CircleShape2D; radius set from area export
```

### Build Garlic.tscn

1. **Create a new scene.** Go to **Scene → New Scene**,
 choose **Other Node**, search for `Node2D` and press
 Enter. Rename the root to `Garlic` (F2).
 Save immediately as `res://scenes/weapons/Garlic.tscn`.
2. **Add HitZone.** Select `Garlic`, press Ctrl+A,
 add an `Area2D`. Rename it `HitZone`. Under
 **Collision** in the Inspector:

   - **Layer:** enable only **Layer 5** (Weapons).
   - **Mask:** enable only **Layer 3** (Enemies — the
    CharacterBody2D layer, not the HitBox layer).
   - Confirm **Monitoring: On**.

3. **Add CollisionShape2D to HitZone.** Select `HitZone`,
 Ctrl+A, add `CollisionShape2D`. Set Shape to
 **New CircleShape2D**, Radius `60` (default —
 `GarlicWeapon.gd` will override this from the export at runtime).
4. **Attach GarlicWeapon.gd.** Select the `Garlic` root.
 Attach a new script at `res://scenes/weapons/GarlicWeapon.gd`.
 Paste the script below. Save with Ctrl+S.
5. **Save the scene.** Press Ctrl+S. Your scene tree
 should match the diagram above.

```gdscript
## res://scenes/weapons/GarlicWeapon.gd

class_name GarlicWeapon
extends WeaponBase

@onready var hit_zone:  Area2D            = $HitZone
@onready var hit_shape: CollisionShape2D  = $HitZone/CollisionShape2D

func _ready() -> void:
    super._ready()
    ## Resize the collision circle to match our exported area stat.
    (hit_shape.shape as CircleShape2D).radius = area

func _fire() -> void:
    ## Damage every enemy body currently inside the hit zone.
    for body in hit_zone.get_overlapping_bodies():
        var enemy := body as EnemyBase
        if enemy:
            enemy.take_damage(damage)
    _pulse_visual()

func _pulse_visual() -> void:
    ## Quick scale tween — expands out then snaps back.
    ## Ch 71G will replace this with a particle burst.
    var tween := create_tween()
    tween.tween_property(hit_zone, "scale", Vector2(1.2, 1.2), 0.08)
    tween.tween_property(hit_zone, "scale", Vector2(1.0, 1.0), 0.06)

## On upgrade, resize the collision shape to the new area value.
func apply_upgrade(upgrade: WeaponUpgradeResource) -> void:
    super.apply_upgrade(upgrade)
    (hit_shape.shape as CircleShape2D).radius = area
```

:::callout-pitfall[get\_overlapping\_bodies() returns nothing — monitoring is off]
If Garlic fires but deals no damage, the most likely cause is
 `monitoring = false` on the HitZone Area2D. Without monitoring,
 Godot doesn't track what is inside the area and the method always returns
 an empty array. Check the Inspector → Collision section of HitZone.
:::

## 3. Magic Wand — Aimed Projectile

The Magic Wand fires a fast bolt at the nearest enemy. It snapshots the
 direction at fire time; the projectile then travels in a straight line
 until it hits an enemy or goes off-screen.

```
MagicWand (Node2D)               ← MagicWandWeapon.gd
(no child nodes — projectiles come from ObjectPool)
```

### Build MagicWand.tscn

1. **Create a new scene.** **Scene → New Scene** →
 `Node2D` root, rename to `MagicWand`.
 Save as `res://scenes/weapons/MagicWand.tscn`.
2. **Attach MagicWandWeapon.gd.** Create
 `res://scenes/weapons/MagicWandWeapon.gd` with the script
 below. Attach it to the `MagicWand` root.
3. **Assign projectile\_scene.** With the `MagicWand`
 root selected, find **Projectile Scene** in the Inspector
 (exported from the script). Drag `Projectile.tscn` into it.
 *Build Projectile.tscn first (section 4), then come back and do this step.*
4. **Save.** Press Ctrl+S.

```gdscript
## res://scenes/weapons/MagicWandWeapon.gd

class_name MagicWandWeapon
extends WeaponBase

@export var projectile_scene: PackedScene   ## assign Projectile.tscn in Inspector

func _fire() -> void:
    var target := _get_nearest_enemy()
    if target == null:
        return   ## no enemies alive — skip this fire cycle
    for i in projectile_count:
        _spawn_projectile(target.global_position, i)

func _spawn_projectile(target_pos: Vector2, index: int) -> void:
    var proj: Projectile = ObjectPool.acquire("Projectile") as Projectile
    if proj == null:
        return   ## pool exhausted — skip silently

    ## Slight angular spread when projectile_count > 1.
    ## index 0 fires straight; 1 is 12° left; 2 is 12° right; etc.
    var base_dir := _player.global_position.direction_to(target_pos)
    var spread   := deg_to_rad((index - (projectile_count - 1) / 2.0) * 12.0)
    var dir      := base_dir.rotated(spread)

    ## Parent to the world node (Main), not to the player.
    ## Parenting to the player would make projectile positions relative to player,
    ## causing them to teleport whenever the player moves.
    var world := get_tree().get_first_node_in_group("enemy_container").get_parent()
    world.add_child(proj)
    proj.global_position = _player.global_position
    proj.launch(dir, damage)
```

## 4. Projectile.gd — Pooled Bolt

Projectiles are pooled Area2D nodes. They travel at fixed speed, damage the
 first enemy they overlap, then return to the pool. A
 `VisibleOnScreenNotifier2D` handles the off-screen edge case
 automatically — no lifetime timer needed.

```
Projectile (Area2D)              ← Projectile.gd; from ObjectPool
├── CollisionShape2D             ← Layer 5 (Weapons), Mask 3 (Enemies)
├── Sprite2D                     ← small bolt or orb sprite
└── VisibleOnScreenNotifier2D    ← fires screen_exited → return to pool
```

### Build Projectile.tscn

1. **Create a new scene.** **Scene → New Scene** →
 `Area2D` root, rename to `Projectile`.
 Save as `res://scenes/weapons/Projectile.tscn`.
2. **Add CollisionShape2D.** Ctrl+A → add
 `CollisionShape2D`. Shape: **New CapsuleShape2D**,
 Radius `4`, Height `14` — a thin elongated bolt shape.
 Under **Collision** on the Area2D root:

   - **Layer:** Layer 5 (Weapons) only.
   - **Mask:** Layer 3 (Enemies body) only.

3. **Add Sprite2D.** Assign a small bolt or magic orb texture.
 Rotate it 90° in the Inspector if needed so it points right (along the
 positive X axis) — the launch() function sets rotation to the direction angle.
4. **Add VisibleOnScreenNotifier2D.** Ctrl+A →
 `VisibleOnScreenNotifier2D`. No configuration needed — the script
 connects its `screen_exited` signal in code.
5. **Attach Projectile.gd.** Create
 `res://scenes/weapons/Projectile.gd` and attach it to the root.
 Paste the script below. Save with Ctrl+S.
6. **Register with ObjectPool.** Open
 `res://autoloads/ObjectPool.gd`. In `_ready()` add:

 30 projectiles is enough for Magic Wand at max fire rate — increase if you
 add more projectile weapons later.

   ```gdscript
   register("Projectile", preload("res://scenes/weapons/Projectile.tscn"), 30)
   ```

7. **Go back and assign projectile\_scene on MagicWand.**
 Open `MagicWand.tscn`, select the root, and drag
 `Projectile.tscn` into the **Projectile Scene**
 slot in the Inspector.

```gdscript
## res://scenes/weapons/Projectile.gd

class_name Projectile
extends Area2D

const SPEED: float = 500.0

var _direction: Vector2 = Vector2.RIGHT
var _damage: float      = 10.0
var _lifetime: float    = 4.0   ## failsafe — pool release if still alive after 4 s
var _elapsed: float     = 0.0

func _ready() -> void:
    area_entered.connect(_on_area_entered)
    $VisibleOnScreenNotifier2D.screen_exited.connect(_return_to_pool)

## Called by MagicWandWeapon after add_child() and global_position assignment.
func launch(direction: Vector2, dmg: float) -> void:
    _direction = direction.normalized()
    _damage    = dmg
    _elapsed   = 0.0
    rotation   = _direction.angle()

func _physics_process(delta: float) -> void:
    global_position += _direction * SPEED * delta
    _elapsed += delta
    if _elapsed >= _lifetime:
        _return_to_pool()

func _on_area_entered(area: Area2D) -> void:
    ## area is the enemy's CharacterBody2D — we need the EnemyBase on its parent.
    ## Actually: Projectile Mask = Layer 3 (CharacterBody2D layer).
    ## The body itself is EnemyBase, so cast directly.
    var enemy := area.get_parent() as EnemyBase
    if enemy == null:
        ## Maybe the overlap is with the enemy's own body — try direct cast.
        enemy = area as EnemyBase
    if enemy:
        enemy.take_damage(_damage)
        _return_to_pool()

func _return_to_pool() -> void:
    ObjectPool.release("Projectile", self)
```

:::callout-warning[Add to world before calling launch()]
Always call `world.add_child(proj)` first, then set
 `proj.global_position`, then call `proj.launch()`.
 `global_position` only resolves correctly once the node has a
 parent in the scene tree. Getting the order wrong places the projectile
 at the world origin.
:::

## 5. Axe — Arc Throw with Pierce

The Axe is thrown in a direction, follows a parabolic arc (faked with a
 sine offset), and damages every enemy it passes through. Unlike the Magic
 Wand it does not return to a pool — it uses `queue_free()`
 because arcs are slower to spawn and die infrequently.

```
Axe (Node2D)                     ← AxeWeapon.gd (the launcher, on player)

AxeProjectile (Area2D)           ← AxeProjectile.gd (the thrown object)
├── CollisionShape2D             ← Layer 5, Mask 3; CircleShape2D radius 12
└── Sprite2D                     ← axe sprite; rotation set each frame by script
```

### Build AxeProjectile.tscn

1. **Create a new scene.** **Scene → New Scene** →
 `Area2D` root, rename to `AxeProjectile`. Save as
 `res://scenes/weapons/AxeProjectile.tscn`.
2. **Add CollisionShape2D.** Shape: **New CircleShape2D**,
 Radius `12`. On the Area2D: Layer 5, Mask 3.
 **Monitoring: On.**
3. **Add Sprite2D.** Assign an axe sprite. The script rotates
 it each frame during the arc so the texture orientation doesn't matter.
4. **Attach AxeProjectile.gd** to the root. Script path:
 `res://scenes/weapons/AxeProjectile.gd`. Paste the script
 below and save.

### Build Axe.tscn

1. **Create a new scene.** `Node2D` root, rename
 to `Axe`. Save as `res://scenes/weapons/Axe.tscn`.
2. **Attach AxeWeapon.gd** to the root. Paste the launcher
 script below. In the Inspector, assign `AxeProjectile.tscn`
 to the **Axe Scene** export slot. Save with Ctrl+S.

### AxeWeapon.gd — the launcher

```gdscript
## res://scenes/weapons/AxeWeapon.gd

class_name AxeWeapon
extends WeaponBase

@export var axe_scene: PackedScene   ## assign AxeProjectile.tscn in Inspector

func _fire() -> void:
    ## projectile_count > 1 throws axes evenly spread around a circle.
    for i in projectile_count:
        var angle := TAU / projectile_count * i
        _throw_axe(Vector2(cos(angle), sin(angle)).normalized())

func _throw_axe(direction: Vector2) -> void:
    var axe: AxeProjectile = axe_scene.instantiate()
    var world := get_tree().get_first_node_in_group("enemy_container").get_parent()
    world.add_child(axe)
    axe.global_position = _player.global_position
    axe.launch(direction, damage)
```

### AxeProjectile.gd — the flying axe

```gdscript
## res://scenes/weapons/AxeProjectile.gd

class_name AxeProjectile
extends Area2D

const SPEED: float      = 220.0
const ARC_HEIGHT: float = 120.0   ## peak vertical offset in pixels
const DURATION: float   = 1.2     ## seconds for the full arc

var _dir: Vector2
var _damage: float
var _elapsed: float   = 0.0
var _origin: Vector2
## Tracks enemies already hit this throw — prevents double-damage (pierce mechanic).
var _hit_enemies: Array = []

func launch(direction: Vector2, dmg: float) -> void:
    _dir     = direction.normalized()
    _damage  = dmg
    _elapsed = 0.0
    _origin  = global_position
    area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
    _elapsed += delta
    if _elapsed >= DURATION:
        queue_free()
        return

    var t := _elapsed / DURATION   ## 0.0 at start, 1.0 at end

    ## Horizontal: moves steadily along the throw direction.
    var horiz_pos := _origin + _dir * SPEED * _elapsed

    ## Vertical arc: sin(t * PI) peaks at t=0.5 (the apex).
    ## Negative because Godot Y increases downward — negative = upward.
    var vert := -ARC_HEIGHT * sin(t * PI)

    global_position = horiz_pos + Vector2(0.0, vert)

    ## Spin the sprite continuously over the arc duration.
    rotation = _dir.angle() + lerp(deg_to_rad(-30.0), deg_to_rad(200.0), t)

func _on_area_entered(area: Area2D) -> void:
    var enemy := area.get_parent() as EnemyBase
    if enemy == null:
        enemy = area as EnemyBase
    ## Pierce: allow hitting multiple enemies, but not the same one twice.
    if enemy and not _hit_enemies.has(enemy):
        _hit_enemies.append(enemy)
        enemy.take_damage(_damage)
```

:::callout-connect[Pierce vs. single-hit — a design choice in one line]
The Axe uses `_hit_enemies` to pierce (hit many, not the same one
 twice) while continuing its arc. The Magic Wand calls `_return_to_pool()`
 on first hit and stops. This distinction is entirely within each weapon's script —
 WeaponBase has no concept of pierce.
:::

## 6. WeaponUpgradeResource

This Resource describes a single weapon upgrade — stat bonuses applied when
 the player chooses it from the upgrade card UI (Ch 71E). Create
 `res://resources/WeaponUpgradeResource.gd`:

```gdscript
## res://resources/WeaponUpgradeResource.gd

class_name WeaponUpgradeResource
extends Resource

## Which weapon class this upgrade targets ("GarlicWeapon", "MagicWandWeapon", etc.).
## Leave empty to apply to all weapons simultaneously.
@export var weapon_class_name: String = ""

## Stat deltas applied by WeaponBase.apply_upgrade().
@export var damage_bonus: float       = 0.0
@export var area_bonus: float         = 0.0
@export var cooldown_reduction: float = 0.0

## Called by the upgrade system (Ch 71E).
func apply(player: Player) -> void:
    if weapon_class_name.is_empty():
        for w in player.weapon_holder.get_children():
            (w as WeaponBase).apply_upgrade(self)
    else:
        player.upgrade_weapon(weapon_class_name, self)
```

:::callout-tip[Adding a completely new weapon]
Create `NewWeapon.gd` extending WeaponBase, build
 `NewWeapon.tscn`, create a `WeaponUpgradeResource`
 with `func apply()` that calls
 `player.add_weapon(new_weapon_scene)`. Zero changes to any
 existing file — the system is open to extension.
:::

## 7. Wire Weapons into the Game

Players start with Garlic only. The upgrade system (Ch 71E) will handle
 adding new weapons at runtime. For now, give the player both weapons at
 run start so you can test everything immediately.

1. **Open Main.gd.** In the FileSystem dock, double-click
 `res://scenes/main/Main.gd`.
2. **Add temporary test weapons.** In `_ready()`,
 after `GameManager.start_run()`, add:

   ```gdscript
   ## Temporary: give starting weapons for testing. Remove in Ch 71E.
   var garlic_scene := preload("res://scenes/weapons/Garlic.tscn")
   var wand_scene   := preload("res://scenes/weapons/MagicWand.tscn")
   $Player.add_weapon(garlic_scene)
   $Player.add_weapon(wand_scene)
   ```

3. **Save Main.gd** with Ctrl+S.

## 8. Verification Checklist

Press F5. Work through each check top-to-bottom.

1. **No errors in Output.** "WeaponBase: not parented to
 WeaponHolder" means a weapon scene was added as a direct child of Player
 rather than through `Player.add_weapon()`. Check Main.gd
 is calling `$Player.add_weapon()`, not
 `$Player.add_child()`.
2. **Garlic pulses visually every 1 second.** The HitZone should
 briefly scale up. If it doesn't: GarlicWeapon.\_ready() didn't call
 `super._ready()`, so `_player` is null and
 `_fire()` is never reached.
3. **Enemies inside Garlic radius take damage and die.**
 If not: check HitZone Mask includes the layer the EnemyBase
 CharacterBody2D is on (Layer 3), and that **Monitoring is On**.
4. **Magic Wand fires a projectile toward the nearest enemy.**
 If no projectile appears: ObjectPool.register("Projectile", ...) was not
 called, or `projectile_scene` is not assigned in the Inspector.
5. **Projectile disappears on enemy contact and the enemy takes damage.**
 If the projectile passes through: check Layer/Mask on both Projectile and
 EnemyBase CharacterBody2D are compatible (Projectile Mask = Enemy body layer).
6. **WeaponHolder has two children in the Remote debugger.**
 Run → Debug → Remote Scene Tree → expand Player → WeaponHolder.
 You should see GarlicWeapon and MagicWandWeapon as children.

## Practice Problems

:::problem[Problem 1 easy]{difficulty="easy"}
What is the full node path used by `WeaponBase._ready()` to find
 the Player, and why does it use two `get_parent()` calls?

::::solution[Solution]
Weapon → WeaponHolder → Player. The weapon is a child of WeaponHolder,
 which is a child of Player. First `get_parent()` returns WeaponHolder;
 second returns Player. One call would return WeaponHolder, which can't be cast
 to Player — the push\_error would fire.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
Garlic uses `get_overlapping_bodies()`. Magic Wand uses
 `get_nodes_in_group("enemies")`. Why the difference?

::::solution[Solution]
Garlic only cares about enemies *physically inside its radius right now*
 — the Area2D tracks overlaps continuously, so the call is exact and cheap.
 Magic Wand needs the *nearest enemy anywhere on the map* to aim at —
 that requires checking all live enemies via the group. Using
 `get_overlapping_bodies()` for Magic Wand would cap its range to
 a fixed radius, breaking the "aim at nearest" behaviour.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
A Garlic starts with `area = 80` and receives two upgrades each
 with `area_bonus = 15`. What is the CircleShape2D radius after
 both upgrades?

::::solution[Solution]
Upgrade 1: area = 80 + 15 = 95 → radius set to 95.

 Upgrade 2: area = 95 + 15 = 110 → radius set to 110.

 `GarlicWeapon.apply_upgrade()` calls `super.apply_upgrade()`
 which adds the bonus to `area`, then the override sets
 `CircleShape2D.radius = area` with the updated value.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Trace the full sequence from cooldown expiry to enemy HP reduction for one
 Magic Wand bolt.

::::solution[Solution]
1. `_cooldown_timer ≤ 0` → `_fire()`.

 2. `_get_nearest_enemy()` iterates group "enemies" → nearest EnemyBase.

 3. `ObjectPool.acquire("Projectile")` → reused Projectile node.

 4. `world.add_child(proj)` → proj enters scene tree.

 5. `proj.global_position = player.global_position`.

 6. `proj.launch(dir, damage)` → direction and damage stored.

 7. Each frame: `global_position += dir * 500 * delta`.

 8. Projectile Area2D overlaps enemy body → `_on_area_entered`.

 9. `enemy.take_damage(_damage)` → HP reduced.

 10. `ObjectPool.release("Projectile", self)` → removed from world.
::::
:::

:::problem[Problem 5 challenge]{difficulty="challenge"}
Implement a **Lightning** weapon that chains damage from the
 nearest enemy to up to 3 additional nearby enemies within 100 px. Damage
 falls off 30% per chain. No projectile scene needed.

::::solution[Solution]
```gdscript
class_name LightningWeapon
extends WeaponBase

@export var chain_range: float = 100.0
@export var chain_count: int   = 3

func _fire() -> void:
    var first := _get_nearest_enemy()
    if first == null: return
    var chain: Array[EnemyBase] = [first]
    first.take_damage(damage)
    for i in chain_count:
        var next := _find_chain_target(chain.back(), chain)
        if next == null: break
        chain.append(next)
        next.take_damage(damage * pow(0.7, i + 1))

func _find_chain_target(from: EnemyBase, exclude: Array) -> EnemyBase:
    var best := chain_range * chain_range
    var nearest: EnemyBase = null
    for e in get_tree().get_nodes_in_group("enemies"):
        if e in exclude: continue
        var d := from.global_position.distance_squared_to(e.global_position)
        if d < best:
            best = d
            nearest = e as EnemyBase
    return nearest
```
::::
:::

## Summary

:::summary
## Chapter 71D — Key Points

| What | How | Why |
| --- | --- | --- |
| WeaponBase | Node2D; self-firing \_physics\_process timer; \_fire() virtual | All weapons share cooldown logic; only override what's unique |
| Garlic | Area2D radius; get\_overlapping\_bodies() on fire | Tracks overlaps continuously — no per-frame group scan needed |
| Magic Wand | Pooled Projectile aimed at nearest enemy | Nearest-enemy mechanic requires group scan; projectile reused |
| Axe | Sine arc; pierce via \_hit\_enemies array; queue\_free | Infrequent spawn — pooling not worth the reset complexity |
| WeaponUpgradeResource | damage/area/cooldown deltas; apply\_upgrade() on weapon | Data-driven upgrades; new weapon types need no existing code changes |
:::

Next: **Ch 71E** wires XP gems into the levelling system and builds
 the upgrade card UI that pauses the game and presents three random upgrades to choose from.
