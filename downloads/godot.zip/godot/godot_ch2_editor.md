---
title: "Tour of the Godot Editor — Docks, Viewports & Workflow"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 2"
meta:
  - "Est. study time: ~75 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch2_editor.html"
---

## Overview

You opened Godot in Chapter 1 and clicked around just enough to get something running.
 Now we slow down and learn the editor properly. By the end of this chapter you'll know
 every dock, every toolbar button, and every keyboard shortcut you'll use in your first
 dozen projects — and you'll understand *why* the editor is laid out the way it is.

This chapter is reference-heavy by design. Don't try to memorize everything in one pass.
 Read it through once, then come back whenever you're confused about what a button does.

:::callout-key[Prerequisites]
- Chapter 1 complete — you have a project open with a working scene.
- You can add a node (Ctrl+A), save a scene (Ctrl+S), and run it (F5).
:::

## 1. The Editor Layout

:::callout-intuition[The mental model]
The Godot editor is a single window divided into docks arranged around a central
 viewport. Every dock is dockable — you can drag it to a different position, float it
 as its own window, or collapse it entirely. The default layout is sensible for most
 work; we'll cover customizing it in Section 7.
:::

Here's the default layout at a glance:

Menu Bar & Play Toolbar — Top strip — Scene · Project · Debug · Editor · Help + ▶ ⏸ ■

Scene Dock

Node tree (top-left)

FileSystem

Project files (bottom-left)

Viewport — 2D · 3D · Script · AssetLib tabs

Inspector — Selected node properties (right)

Bottom Panel — Output · Debugger · Profiler · Animation · Audio · etc.

The Godot 4 editor with a 2D scene open. Source: Godot documentation (CC BY 3.0).

### Menu Bar & Play Toolbar

The menu bar (left) and play toolbar (center). Source: Godot documentation (CC BY 3.0).

| Menu | What lives there |
| --- | --- |
| **Scene** | New Scene, Open Scene, Save, Save As, Close, Revert, Recent Scenes, Quit. |
| **Project** | Project Settings, Export, Install Android Build Tools, Open in File Manager. |
| **Debug** | Run with remote debugging, deploy to device, break on errors, profiler options. |
| **Editor** | Editor Settings (preferences), Manage Editor Features, Layouts, Take Screenshot. |
| **Help** | Search Help (F1), online docs, Godot community, About. |

The **play toolbar** sits in the center of the top bar:

| Button | Shortcut | Action |
| --- | --- | --- |
| ▶ Play | F5 | Run the project's main scene. |
| ▶ Play Scene | F6 | Run the currently open scene. |
| ⏸ Pause | F7 | Pause the running game (useful for inspecting state mid-run). |
| ■ Stop | F8 | Stop the running game. |
| 🎬 Movie Writer | — | Record the running game to video (new in 4.x). |

To the right of the play toolbar you'll see a **renderer indicator**
 (Forward+, Mobile, or Compatibility) and a **distraction-free mode**
 toggle (the eye icon) that hides all docks so you can focus on writing code.

### Workspace tabs

Just below the menu bar, four tabs switch the central viewport between modes:

- **2D** — 2D canvas editor. Used for building and editing 2D scenes.
- **3D** — 3D viewport with orbit camera, gizmos, and environment settings.
- **Script** — the built-in code editor (GDScript, C#, shaders). Opens automatically when you attach or double-click a script.
- **AssetLib** — browse the official Godot Asset Library (addons, demos, shaders). Requires internet.

:::callout-tip[Switching modes fast]
Click the tabs, or use Ctrl+F1 (2D), Ctrl+F2 (3D),
 Ctrl+F3 (Script). If you're deep in a script and want to jump back to the
 viewport quickly, Ctrl+F1 is faster than reaching for the mouse.
:::

## 2. The Scene Dock

:::callout-intuition[The scene dock is your scene's skeleton]
Everything you see in the viewport exists because of a node in the Scene dock.
 The dock shows the node hierarchy as an indented tree — parent nodes contain
 child nodes, and moving a parent moves all its children. Think of it like the
 DOM in web development, or the Hierarchy panel in Unity.
:::

The Scene dock. The icons to the right of each node control visibility and lock state. Source: Godot documentation (CC BY 3.0).

### Node operations

| Action | How |
| --- | --- |
| Add a node | Ctrl+A, or the **+** button at the top of the dock. |
| Add a child node | Select a parent, then Ctrl+A. The new node becomes a child of the selected one. |
| Rename a node | Double-click the node name, or F2. |
| Delete a node | Select it, press Delete. All its children are deleted too. |
| Duplicate | Ctrl+D. Creates an exact copy as a sibling. |
| Reparent (move in tree) | Drag and drop in the dock. Hold Shift while dragging to keep the node's world position. |
| Reorder siblings | Drag up/down within the same level. |
| Multi-select | Ctrl+click to select multiple nodes. Most operations work on all selected nodes. |
| Open attached script | Click the script icon to the right of the node name, or Ctrl+click the name. |
| Attach a script | Right-click the node → **Attach Script**. |
| Detach a script | Right-click the node → **Detach Script**. |
| Expand / collapse tree | Click the triangle next to a parent node. |

:::callout-tip[Right-click is your friend]
Right-clicking any node in the Scene dock opens a context menu with every available
 operation — including "Move To", "Save Branch as Scene" (turns a subtree into its own
 `.tscn` file), and "Open in Editor" for instanced sub-scenes.
:::

### Visibility, lock, and groups

To the right of each node name in the Scene dock are two small icons that appear on
 hover (or always, when set):

- **Eye icon** — toggles the node's visibility in the *editor viewport*
 (not in the running game). Useful for hiding helper nodes while you work on other parts
 of the scene.
- **Lock icon** — locks the node so it can't be selected or moved in the
 viewport by clicking. Useful for background sprites you don't want to accidentally drag.

You can also assign nodes to **groups** — named tags that let you find and
 call methods on all matching nodes at once. Right-click a node → **Add to
 Group**. We'll use groups extensively in Chapter 5 (Signals) and Chapter 57 (AI).

:::callout-pitfall[Watch out for]
- **Node name collisions.** If you have two children with the same name under the same parent, Godot auto-renames the second one (e.g., `Sprite2D2`). The `$` shorthand in scripts uses the exact name shown in the dock — check it carefully.
- **Deleting a parent deletes all children.** There is no confirmation dialog for single-node deletes. Use Ctrl+Z immediately to undo if you delete the wrong node.
- **Instanced scenes look like single nodes in the parent scene.** An instanced scene (packed scene) shows up as one node with a film-strip icon. To edit its contents, double-click it or press Ctrl+E.
:::

## 3. The FileSystem Dock

:::callout-intuition[It's just your project folder]
The FileSystem dock shows exactly what's on disk in your project folder. Every
 `.tscn`, `.gd`, `.png`, `.mp3` and
 anything else you put there appears here. Godot doesn't have a separate "asset
 database" — the files on disk *are* the database.
:::

The FileSystem dock. The icons show file types — scenes (.tscn), scripts (.gd), textures, audio, etc. Source: Godot documentation (CC BY 3.0).

### Key operations in the FileSystem dock

| Action | How |
| --- | --- |
| Open a file | Double-click it. Scenes open in the viewport; scripts open in the Script editor; textures show a preview in the Inspector. |
| Move a file | Drag and drop within the dock. Godot automatically updates all references in `.tscn` files. *Always move files inside the dock* — never in your OS file manager. |
| Rename a file | Right-click → **Rename**. Again, Godot updates references. |
| Create a folder | Right-click any folder → **New Folder**. |
| Create a new script | Right-click a folder → **New Script**. Or use the "Attach Script" dialog on a node. |
| Show in file manager | Right-click a file → **Show in File Manager**. Opens the OS file browser at that location. |
| Collapse/expand | Click the triangle next to a folder, or use the breadcrumb at the top. |
| Search | The magnifying glass at the top of the dock filters files by name. |

### The import pipeline

When you drop a file into your project folder (image, audio, 3D model, font…), Godot
 automatically **imports** it. This creates a hidden `.import`
 folder and a small `.import` metadata file alongside the original. You never
 touch these — they're internal. What matters is the **Import dock**.

Click any imported asset in the FileSystem dock. You'll notice the Inspector switches to
 showing **Import** settings (there's also an "Import" tab at the top of the
 Inspector panel). This is where you control how Godot processes the raw file:

| Asset type | Common import settings |
| --- | --- |
| **Texture (PNG/JPG)** | Compress mode, filter mode (Nearest for pixel art), mipmaps, detect 3D hint. |
| **Audio (MP3/OGG/WAV)** | Loop, loop offset, compression (OGG for music, WAV for short SFX). |
| **3D model (glTF/FBX)** | Skeleton, animation, material overrides, mesh compression. Covered in Ch 27. |
| **Font (TTF/OTF)** | Anti-aliasing, subpixel positioning, MSDF rendering for large sizes. |

:::callout-warning[Pixel art: always set filter to Nearest]
By default Godot imports textures with linear filtering, which blurs pixel art.
 Click your sprite texture in the FileSystem dock → Import tab → set
 **Filter** to **Nearest** → click **Reimport**.
 You only need to do this once per texture.
:::

### Recommended project structure

Godot doesn't enforce a folder layout, but the following structure is used by most
 experienced developers and by this textbook's projects:

```
res://
├── scenes/          # .tscn files (player.tscn, main.tscn, ui/hud.tscn…)
├── scripts/         # .gd files not attached to a scene (autoloads, utilities)
├── assets/
│   ├── sprites/     # .png, .svg textures
│   ├── audio/       # .ogg, .mp3, .wav
│   ├── fonts/       # .ttf, .otf
│   └── models/      # .glb, .gltf (3D projects)
├── shaders/         # .gdshader files
└── icon.svg         # auto-generated project icon
```

:::callout-tip[res:// paths]
In GDScript, all paths within your project start with `res://` —
 short for "resource root." This always points to your project folder, regardless of
 where it lives on disk. `user://` is a separate path for writable save data
 (covered in Ch 47). Never hardcode OS-level paths like `C:\Users\...`.
:::

## 4. The 2D Viewport

:::callout-intuition[The viewport is your canvas — but also a camera]
The 2D viewport is where you visually place and arrange nodes. It's not a screenshot
 of the game — it's an editable view of the scene. The gray area outside the colored
 rectangle is outside the game camera's view at runtime. The blue rectangle is the
 viewport boundary (sized according to your Window settings in Project Settings).
:::

### Navigating the viewport

| Action | Input |
| --- | --- |
| Pan (scroll) | Middle-mouse drag, or Space + left-drag. |
| Zoom in/out | Mouse wheel, or + / - on the numpad. |
| Reset zoom to 100% | Numpad 1, or the zoom % indicator in the toolbar (click it, type 100). |
| Frame selection | F — zooms to fit the selected node(s). |
| Frame whole scene | Shift+F — zooms to fit everything in the scene. |
| Toggle grid | G, or the grid icon in the toolbar. |

### Transform tools

The toolbar just above the viewport (when in 2D mode) contains the transform tools.
 These apply to the *selected node* in the scene.

The 2D toolbar. Left to right: Select, Move, Rotate, Scale, then snapping, grid, and camera controls. Source: Godot documentation (CC BY 3.0).

| Tool | Shortcut | What it does |
| --- | --- | --- |
| **Select (arrow)** | Q | Click to select a node. Drag to move it (same as Move tool when a node is already selected). |
| **Move** | W | Shows directional arrows (gizmos). Drag along an axis to constrain movement. |
| **Rotate** | E | Shows a rotation ring. Drag to rotate. Hold Ctrl to snap to 15° increments. |
| **Scale** | R | Shows scale handles. Drag a corner to scale proportionally; drag an edge handle for non-uniform scale. |

:::callout-tip[Type exact values]
For precise positioning, don't drag in the viewport — use the **Inspector**
 instead. Select the node, then find its **Transform → Position** property
 and type in exact pixel values. You can also click any numeric field in the Inspector
 and scroll the mouse wheel to increment/decrement it.
:::

### Snapping and the grid

Snapping constrains movement to a grid, which is essential for tile-based games and
 aligned UI layouts. Configure it from the toolbar:

- Click the **magnet icon** (or press Ctrl+Shift+G) to toggle snapping on/off.
- Click the dropdown next to the magnet to set the snap step (default: 32 px, good for 32×32 tiles).
- The **grid icon** toggles the grid overlay. Grid size and offset are set in *Editor → Editor Settings → 2D → Grid Step*.
- Hold Ctrl while dragging to temporarily enable snapping without toggling the setting.

:::example[Walkthrough B — Aligning nodes on a pixel grid]
You're building a 16×16 pixel-art scene. Set up the editor so all nodes snap to a
 16 px grid, and verify a Sprite2D lands exactly at position (48, 32).

::::answer[Result]
The node snaps to multiples of 16. Inspector shows Position exactly
 `(48, 32)`.
::::

Steps

1. Go to **Editor → Editor Settings → 2D → Grid Step**. Set both X and Y to `16`. Close settings.
2. In the 2D toolbar, click the **magnet icon** to enable snapping.
3. Click the grid icon to make the grid visible.
4. Drag your Sprite2D node — it now jumps in 16 px increments.
5. To place it at exactly (48, 32): select the node, then in the **Inspector** → Transform → Position → set X to `48`, Y to `32`. This bypasses snapping entirely and gives you pixel-perfect placement.
:::

:::callout-pitfall[Watch out for]
- **Clicking in the viewport selects the wrong node.** Godot selects the topmost visible node under the cursor. If you can't click through to a node beneath, use the Scene dock to select it instead.
- **The blue rectangle isn't the full scene — it's the camera viewport.** Objects outside it won't be visible in the running game unless you have a Camera2D set up to follow the player (covered in Ch 20).
- **Dragging a node moves it in its *parent's* coordinate space.** If the parent is rotated or scaled, the visual drag direction may not match the axis arrows. Use the Inspector for precise positioning in these cases.
:::

## 5. The Inspector Dock

:::callout-intuition[The Inspector is property-based, not script-based]
Every node exposes its properties in the Inspector when selected. These are the same
 properties you can read and write in GDScript. Changing a value in the Inspector is
 equivalent to setting it in code — and changes you make in the editor are saved into
 the `.tscn` file as override values on top of the node's defaults.
:::

The Inspector showing a Sprite2D's properties. Properties are grouped by category. Source: Godot documentation (CC BY 3.0).

The Inspector organizes properties into collapsible **sections**. For
 most nodes, you'll see:

- **Script section** (top) — shows any attached script, and all `@export` variables from that script.
- **Node-type sections** — e.g., for a Sprite2D: Sprite2D (Texture, Hframes, Vframes, Frame), CanvasItem (Visibility, Modulate, Material), Node2D (Transform), Node (Name, Groups).

#### Working with properties

- **Click** a property value to edit it. Strings open a text field; numbers scroll with the wheel or accept typed input; colors open a color picker; resources show a dropdown.
- **Right-click** any property to get "Copy Property Path" (useful for GDScript), "Revert to Default", or "Pin/Unpin" (keeps a property visible as you switch between nodes).
- **Drag** a resource slot (e.g., Texture) and drop a file from the FileSystem dock onto it.
- **The yellow dot** next to a property means its value differs from the node's scene-level default — it has been overridden in *this instance*. Right-click → Revert to undo the override.

### The Node tab and Signals tab

At the very top of the Inspector panel are two tabs: **Inspector** and
 **Node**. Switch to **Node** to see:

- **Signals sub-tab** — lists every signal the selected node can emit. Double-click a signal to connect it to a function — the editor writes the boilerplate connection code for you. (Signals are Chapter 5's whole topic.)
- **Groups sub-tab** — lists groups this node belongs to. You can add/remove groups here as an alternative to right-clicking in the Scene dock.

:::callout-tip[Export vars show up in the Inspector]
Any GDScript variable marked with `@export` appears in the Inspector
 for that node, editable without touching code:

```gdscript
@export var speed: float = 200.0
@export var color: Color = Color.WHITE
@export var target: NodePath
```

This is how designers on a team can tune values without reading scripts. We use
 `@export` throughout the walkthroughs in Part XIII.
:::

## 6. The Bottom Panel

:::callout-intuition[The bottom panel is the engine's diagnostic center]
While the game is running (or just after it stops), the bottom panel gives you
 full visibility into what the engine is doing — what printed, what errored, what's
 slow, and what the physics is seeing. Learning to read it is the difference between
 debugging in 30 seconds and debugging for an hour.
:::

The bottom panel tabs. Click any tab to expand the panel; click again or press the X to collapse it. Source: Godot documentation (CC BY 3.0).

### Output and Debugger

#### Output

Every `print()`, `push_warning()`, and
 `push_error()` call lands here. Errors appear in red, warnings in yellow,
 normal output in white. Click any error line to jump to the offending file and line
 number in the Script editor.

The icons in the Output panel toolbar let you filter by type (errors only, warnings
 only), copy the log to clipboard, and clear it. Clearing the log at the start of each
 run is a good habit so stale messages don't confuse you.

#### Debugger

The Debugger tab becomes active when a GDScript error causes the game to pause. It
 shows the full **call stack** — which function called which function to
 get to the error. Click any stack frame to see local variable values at that point in
 execution.

You can also set **breakpoints** manually: in the Script editor, click
 the gutter (the left margin) next to any line number. A red dot appears. When the game
 reaches that line, it pauses and the Debugger opens with the current variable state.
 This is significantly more powerful than adding `print()` calls everywhere.

#### Other bottom panel tabs

| Tab | What it does |
| --- | --- |
| **Profiler** | Shows per-frame CPU cost broken down by function. Use it to find which script functions are eating frame time. Available during a running game. |
| **Visual Profiler** | GPU draw call breakdown. Shows render time per pass (shadow, opaque, transparent, canvas). Available during a running game. |
| **Network Profiler** | Multiplayer RPC call volumes (Ch 62). |
| **Monitors** | Live graphs of FPS, physics steps, draw calls, memory, and more. Great for a quick sanity check. |
| **Video RAM** | Lists all loaded textures and their VRAM usage. Useful for finding surprise large textures. |
| **Misc** | Object count, orphan node warnings, scene tree at the point of the last error. |
| **Animation** | The AnimationPlayer editor — appears when an AnimationPlayer node is selected. Covered in Ch 15. |
| **Audio** | The Audio bus editor. Configure buses, effects, and volume here. Covered in Ch 44. |
| **Shader Editor** | The VisualShader graph editor, appears when a VisualShader resource is open. Covered in Ch 53. |

:::callout-pitfall[Watch out for]
- **"Orphan nodes" warning in Misc.** This means your code created nodes with `Node.new()` but never added them to the scene or freed them. They accumulate over time and cause memory leaks. Always `add_child(node)` or `node.queue_free()`.
- **Profiler not showing data.** The Profiler only records when you click **Start** inside the Profiler tab during a running game. It doesn't auto-record.
- **Breakpoints not triggering.** Breakpoints only work in GDScript (not C#). Also, the game must be running from within the editor — not as an exported binary.
:::

## 7. Workflow Tips & Editor Customization

### Saving and restoring editor layouts

You can dock, undock, resize, and rearrange every panel. Once you have a layout you
 like, save it: **Editor → Editor Layout → Save Layout**. Give it a name
 (e.g., "Coding", "Design"). Switch between saved layouts from the same menu.

Some developers keep two layouts: a "Design" layout with a large viewport and docks
 visible, and a "Coding" layout with a maximized Script editor (activated with
 **Editor → Distraction Free Mode** or Ctrl+Shift+F11).

### Editor Settings vs Project Settings

This is a confusion point worth clearing up early:

Editor Settings (*Editor → Editor Settings*)

Preferences that apply to *you as a developer*, globally, across all projects.
 Theme, font size, code editor keybindings, autosave interval, git integration,
 default script template, snap settings. These are stored in Godot's application
 data folder, not in your project.

Project Settings (*Project → Project Settings*)

Settings that affect the *running game*. Window size, renderer, physics
 gravity, input actions, autoloads, audio bus layout. Stored in
 `res://project.godot`. Should be committed to version control.

### Multi-window editing

Godot supports editing multiple scenes simultaneously. Open a second scene from the
 FileSystem dock and it appears as a new tab at the top of the viewport. You can also
 drag a dock (including the entire Script editor) out of the main window to float it
 on a second monitor — useful on a two-monitor setup where you want the viewport on one
 screen and the script on the other.

### The Command Palette

Press Ctrl+Shift+P (or **Help → Command Palette**) to open a
 searchable list of every editor command. Faster than hunting through menus for
 infrequently used actions. Try typing "toggle" or "reimport" to see what's available.

### Version control integration

Godot has a built-in Git plugin (**Editor → Version Control → Set Up Version Control**).
 It shows diffs, lets you stage and commit, and highlights changed files in the
 FileSystem dock with colored indicators. For solo projects it's optional (using Git
 from the terminal works just as well), but on a team it's worth enabling.

:::callout-tip[Always-useful shortcuts]
- Ctrl+P — Quick open any file in the project by name (like VS Code's Ctrl+P).
- Ctrl+Shift+P — Command Palette.
- Ctrl+F — Find in the Script editor.
- Ctrl+Shift+F — Find in all files (project-wide search).
- Alt+Left / Alt+Right — Navigate back/forward through recently visited script positions.
- Ctrl+, — Open Editor Settings.
- Ctrl+Shift+F11 — Toggle distraction-free mode (maximizes script or viewport).
:::

### Practice problems — Section 7

:::problem[Problem 7.1 easy]{difficulty="easy"}
Where would you change the editor's font size? Where would you change the game
 window's resolution at startup? Name the exact menus.

::::solution[Solution]
**Font size:** *Editor → Editor Settings → Interface → Editor → Main Font Size*.
 This is an Editor Setting — it applies to you, not the project.

**Window resolution:** *Project → Project Settings → Display → Window → Size → Viewport Width / Viewport Height*.
 This is a Project Setting — it's stored in `project.godot` and affects
 the running game.
::::
:::

:::problem[Problem 7.2 easy]{difficulty="easy"}
You accidentally moved `player.png` in Windows Explorer instead of
 inside the FileSystem dock. Now Godot shows a broken reference. What's the correct
 way to fix this?

::::solution[Solution]
Move the file back to its original location using Windows Explorer, then
 move it again — this time from *inside* the FileSystem dock by dragging
 it to the new destination. Godot will update all scene and script references
 automatically.

If the broken reference is in a `.tscn` file, you can also fix it
 manually: right-click the scene in the FileSystem dock → **Reimport**.
 Or open the broken `.tscn` in a text editor and update the
 `ExtResource` path by hand — but the FileSystem dock approach is
 safer.
::::
:::

:::problem[Problem 7.3 standard]{difficulty="standard"}
You have a Sprite2D with a texture, and you want to lock it so it can't be
 accidentally moved in the viewport, while also making it invisible in the editor
 (not at runtime). Do both without touching any code.

::::solution[Solution]
In the **Scene dock**, hover over the Sprite2D node.
 Two icons appear to the right of its name:

1. Click the **eye icon** to toggle editor visibility off. The node becomes hidden in the viewport (but still runs normally at game time).
2. Click the **lock icon** to lock the node. It can no longer be clicked or dragged in the viewport.

Both states are saved into the `.tscn` file as metadata and have
 no effect on the running game.
::::
:::

:::summary
## Chapter Summary

### The five areas — at a glance

| Area | Location | Primary use |
| --- | --- | --- |
| **Menu Bar + Toolbar** | Top | Scene/project ops, Play/Stop, renderer info. |
| **Scene Dock** | Top-left | Build and manage the node tree. Ctrl+A to add, F2 to rename, Delete to remove. |
| **FileSystem Dock** | Bottom-left | Project files on disk. Always move/rename files here, not in the OS file manager. |
| **Viewport** | Center | Visually place nodes. Q/W/E/R for transform tools. Middle-drag or Space+drag to pan. |
| **Inspector** | Right | Edit selected node properties. @export vars appear here. Node tab for Signals and Groups. |
| **Bottom Panel** | Bottom | Output (print), Debugger (errors/breakpoints), Profiler (performance), Monitors (live graphs). |

### Critical keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| Ctrl+A | Add node |
| F2 | Rename selected node |
| Ctrl+D | Duplicate node |
| Q / W / E / R | Select / Move / Rotate / Scale tool in viewport |
| F | Frame (zoom to) selected node |
| Ctrl+P | Quick-open file |
| Ctrl+Shift+P | Command palette |
| Ctrl+F1/F2/F3 | Switch to 2D / 3D / Script workspace |
| Ctrl+Shift+F11 | Toggle distraction-free mode |

### If you remember nothing else

**Always move and rename files inside the FileSystem dock**, never in
 your OS file manager. And when something breaks: check the **Output panel
 first** — 90% of the time the error message tells you exactly what's wrong
 and which line caused it.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
What is the keyboard shortcut to open the Quick Open file dialog? What does
 it search through?

::::solution[Solution]
Ctrl+P. It searches all files in the project (scenes, scripts,
 textures, audio — everything under `res://`), filtered by the text
 you type. It matches by filename, not full path, and ranks recently opened
 files higher.
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
You want to see the live frames-per-second, draw call count, and memory usage
 while your game is running, without writing any code. Which bottom panel tab do you use?

::::solution[Solution]
The **Monitors** tab in the bottom panel. It shows live graphs
 for FPS, physics steps, draw calls, objects in scene, video RAM, and total memory
 — all updated in real-time while the game is running.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
You added an `@export var health: int = 100` to a node's script.
 You set it to 50 in the Inspector for that specific node instance. Later a
 teammate changes the script default to `80`. What value does the node
 have when the game runs — 50, 80, or 100? Why?

::::solution[Solution]
**50.** The Inspector override takes priority over the script
 default. When you change a property in the Inspector for a specific node
 instance, Godot stores that value directly in the `.tscn` file as a
 per-instance override (shown by the yellow dot next to the property). This
 override persists even if the script's default changes.

To revert to the script default: right-click the property in the Inspector →
 **Revert to Default**. The yellow dot disappears, and the value
 is no longer stored in the `.tscn` file.
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
You're building a pixel-art platformer. List the three editor settings or
 import settings you should configure immediately after creating your project,
 before placing a single node.

::::solution[Solution]
1. **Renderer → Compatibility** (set when creating the project). Required for web export and avoids Vulkan overhead for 2D.
2. **Project Settings → Display → Window → Size** — set Viewport Width/Height to your pixel canvas size (e.g., 320×180 for a 16:9 pixel-art game). Also set **Stretch Mode** to *viewport* and **Stretch Aspect** to *keep* so the canvas scales cleanly.
3. **Import → Filter = Nearest** for each pixel-art texture. Or change the global default in *Project Settings → Rendering → Textures → Canvas Textures → Default Texture Filter* to *Nearest* so all new imports use it automatically.
::::
:::

:::problem[Problem M.5 challenge]{difficulty="challenge"}
You want to set a breakpoint on line 12 of `player.gd` and inspect
 the value of a local variable called `velocity` when the game hits
 that line. Walk through the exact steps from "game not running" to "seeing the
 variable value."

::::solution[Solution]
1. Open `player.gd` in the Script editor (double-click it in the FileSystem dock, or click the script icon on the Player node).
2. Find line 12. Click in the **gutter** (the narrow left margin showing line numbers). A red dot (breakpoint indicator) appears.
3. Press F5 to run the project. Play until the code path that executes line 12 is reached.
4. The game pauses automatically. The Script editor highlights line 12 in yellow. The bottom panel switches to the **Debugger** tab.
5. In the Debugger, look at the **Locals** section on the right side. You'll see all local variables in the current function scope, including `velocity` and its current value.
6. Use the **Step** (F10) button to advance one line at a time, or **Continue** (F12) to resume until the next breakpoint. Press **Stop** to end the session.
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
