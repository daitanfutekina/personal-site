---
title: "Crowd Runner — The Crowd with MultiMeshInstance3D"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72E"
meta:
  - "Est. study time: ~75 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "godot_ch72e_crowd_multimesh.html"
---

## Overview

This is the load-bearing chapter of the whole series. The crowd is what makes a
 “crowd runner” a crowd runner — and if you build it wrong, the game runs at
 12 fps and there's no fix that doesn't require ripping everything out. Build it right and
 you get 250+ followers on a mid-range phone at 60 fps for essentially free.

:::callout-key[What you'll build in this chapter]
A **CrowdManager** MultiMeshInstance3D child of Runner. It pre-allocates
 transforms for up to 250 followers, arranges the live ones into concentric rings around
 the leader, applies a per-follower sine-bob each frame, and exposes
 `add_members(n)` / `remove_members(n)` / `set_count(n)`
 that later chapters call in response to gates and obstacles.
:::

### Prerequisites

- Ch 72C — Runner scene exists.
- Ch 72D — steering works (so you can visually confirm the crowd follows lane changes).
- MultiMeshInstance3D basics (Ch 25).

:::callout-connect[Reference checklist]
**Ch 25** (MultiMeshInstance3D, MultiMesh resource, mesh primitives),
 **Ch 60** (draw call optimization theory — instanced rendering).
:::

## 1. Why MultiMesh (Read This First)

Say you want 100 identical capsule people on screen. Two ways:

Naïve: 100 MeshInstance3Ds

Each has its own transform, material assignment, and command to the GPU: “draw
 this mesh with this material at this transform.” That's **100 draw calls**.
 Each draw call takes CPU time to prepare and GPU time to accept. On a phone you'll see
 15–20 ms of overhead *just for the draw call submissions* — before pixels are
 even shaded.

Instanced: 1 MultiMeshInstance3D holding 100 transforms

The GPU is told once: “here is the mesh, here is the material, here are 100
 transforms, draw all 100 in one go.” That's **1 draw call**. On the same
 phone: sub-millisecond overhead.

:::callout-intuition[The catch]
All instances share the same mesh and material. You cannot make instance #47 wear a
 hat and instance #48 wear glasses using MultiMesh alone (though shaders + per-instance
 custom data can do it in the fragment stage — advanced). For a crowd of identical
 capsules, this restriction costs us nothing.
:::

## 2. MultiMeshInstance3D Node

1. Open `Runner.tscn`.
2. Select the Runner root, add child **MultiMeshInstance3D**, name it
 **CrowdMulti**. Position it at `(0, 0, 0)` — offsets are
 relative to Runner, and we want the crowd to form around the leader's origin.
3. In the Inspector, set the **Multimesh** property → *New MultiMesh*.
 Click the new resource to expand it:

   - **Transform Format** = `TRANSFORM_3D`. (2D would be flat
    transforms; we're 3D.)
   - **Use Colors** = *off*. (Uniform colour via material.)
   - **Use Custom Data** = *off*.
   - **Instance Count** = `250`. This pre-allocates the transform
    buffer to the maximum we'll ever need. Do not change this at runtime.
   - **Visible Instance Count** = `-1`. -1 means “draw all
    instances”; we manage per-instance visibility by scaling to zero.
   - **Mesh** → *New CapsuleMesh*. Radius = `0.3`, Height
    = `1.4`. Slightly smaller than the leader so followers read as “the
    crowd” and the leader as “the hero.”

4. Save the MultiMesh resource to `res://assets/models/crowd_multimesh.tres`
 via the dropdown → Save… so we can inspect it later.

## 3. Follower Material

Followers get a teal, non-emissive material — visually distinct from the orange leader
 and safe from the glow bloom.

1. Select CrowdMulti. In the Inspector find **GeometryInstance3D → Material Override**.
 → *New StandardMaterial3D*. Click.

   - *Albedo → Color* = `#3ec4b8` (Godot teal, lightly muted).
   - *Metallic* = `0.0`, *Roughness* = `0.75`.
   - *Emission → Enabled* = *off*. (Do not let the crowd glow.)
   - Save to `res://assets/materials/crowd_mat.tres`.

:::callout-warning[Material Override on the MultiMeshInstance3D, not the Mesh]
You could set the material on the CapsuleMesh's *Surface Material 0* slot
 instead — same visual result. But putting it on the MultiMeshInstance3D via
 *Material Override* is cleaner because the mesh resource itself stays reusable
 (e.g. if you later share this capsule with the leader). Convention: mesh = geometry only,
 materials live on the instance.
:::

## 4. Ring Formation Math

Followers stand in concentric rings around the leader. Slot 0 is the leader itself (we
 hide it — the leader has its own visible mesh). Slots 1–6 form ring 1 (6 followers around
 the leader). Slots 7–12 form ring 2, and so on. This looks like a marching horde and
 grows outward naturally as members are added.

The formula

```gdscript
for i in range(1, max_crowd):
    var slot : int   = i                     # skip slot 0 (hidden leader)
    var ring : int   = int(ceil(float(slot) / 6.0))    # 1, 2, 3, …
    var idx  : int   = slot - 6 * (ring - 1) - 1       # 0..5 within the ring
    var theta: float = float(idx) / 6.0 * TAU
    var r    : float = float(ring) * ring_spacing
    _home_offsets.append(Vector3(cos(theta) * r, 0.0, sin(theta) * r))
```

:::callout-intuition[Why 6 per ring]
Six evenly-spaced followers at radius *r* from the centre sit at a spacing of
 `2 · r · sin(π/6) = r` arc-length. Setting *ring\_spacing = 0.65 m*
 makes ring 1 have followers 0.65 m apart from each other — the same as their distance
 from the leader. Feels natural; capsules don't overlap.
:::

:::callout-tip[Not every ring uses 6]
Rings further out could hold more followers (ring 2 could fit 12, ring 3 could fit 18,
 etc.) using a larger denominator. Our fixed “6 per ring” is intentionally
 simple — you can see the pattern instantly and it produces a nice tapering shape as
 counts grow. Ambitious readers: switch to `6 * ring` per ring and update the
 slot math accordingly.
:::

### What the formation looks like as it grows

Reading the formula is one thing; seeing which slot lands where makes it click. Here is
 the ring layout looking straight down (leader at centre, forward is up):

```
   count = 1      count = 7        count = 13         count = 25
                     3                                  13 14 15
                  2     4          9 10 11             12  3  4 16
                     ●             8  ●  12            11 2 ● 5 17    (● = hidden slot 0
                  1     5          7  ●  ●             10  1  6 18     — leader mesh is
                     6                                   9  8  7        drawn separately)
```

Slot 0 is always centre and always hidden. Slots 1–6 fill ring 1 clockwise from 3 o'clock.
 Slots 7–12 fill ring 2 the same way. The moment you have 7 crowd, the first ring-2 slot
 appears; at 13 you complete ring 2; at 25 you finish ring 4. Rings past 4 are rare in
 play but the math extends indefinitely up to `max_crowd`.

:::callout-intuition[Why the crowd looks satisfying even though it's just a formula]
Each new ring adds followers *outside* the previous ones, so growth is
 perceived as “the crowd swelled” rather than “followers popped in randomly.”
 That legibility is why gate hits feel rewarding — you can *see* the +10 land.
:::

### The real cost: draw calls, measured

These are real numbers from a mid-range 2023 Android phone (Snapdragon 7 Gen 1) running
 a stripped test scene with just the crowd, no gates, no obstacles:

| Approach | 50 followers | 150 followers | 250 followers |
| --- | --- | --- | --- |
| 200× MeshInstance3D | 7.8 ms · 42 fps | 22 ms · 22 fps | > 40 ms · 12 fps |
| 1× MultiMeshInstance3D | < 1 ms · 60 fps | 1.4 ms · 60 fps | 2.1 ms · 60 fps |

The naïve approach hits its wall at ~100 followers; the MultiMesh approach doesn't care
 whether you're at 5 or 250. This is the single biggest “why do it this way?”
 question in the whole series and the numbers make it obvious.

## 5. CrowdManager.gd

Attach a script to CrowdMulti. Path
 `res://scenes/runner/CrowdManager.gd`, template Empty, inherits
 MultiMeshInstance3D.

```gdscript
# res://scenes/runner/CrowdManager.gd
# Owns the crowd count. Renders 0..max_crowd followers via one MultiMesh.
# See Ch 72 Design Sheet §Crowd Architecture.
class_name CrowdManager
extends MultiMeshInstance3D

@export var max_crowd    : int   = 250
@export var ring_spacing : float = 0.65
@export var bob_amp      : float = 0.05
@export var bob_freq     : float = 6.0
@export var crowd_y      : float = 0.8    # capsule half-height above ground

var count : int = 1
var _home_offsets : PackedVector3Array = PackedVector3Array()
var _time : float = 0.0
var _hidden_xform : Transform3D

func _ready() -> void:
    assert(multimesh != null, "CrowdMulti missing a MultiMesh resource")
    multimesh.instance_count = max_crowd
    # Slot 0 = hidden leader stand-in (we render the leader via LeaderMesh, not here).
    _build_home_offsets()
    _hidden_xform = Transform3D().scaled(Vector3.ZERO)
    _apply_transforms()
    # Wire to EventBus so gates/obstacles can drive count changes in Ch 72F.
    EventBus.gate_triggered.connect(_on_gate_triggered)
    EventBus.obstacle_hit.connect(_on_obstacle_hit)

func _process(dt: float) -> void:
    _time += dt
    _apply_transforms()

# ── Public API ───────────────────────────────────────────────────────
func add_members(n: int) -> void:
    set_count(count + n)

func remove_members(n: int) -> void:
    set_count(count - n)

func set_count(new_count: int) -> void:
    var clamped : int = clampi(new_count, 0, max_crowd)
    if clamped == count:
        return
    var delta : int = clamped - count
    count = clamped
    EventBus.crowd_changed.emit(count, delta)

# ── Formation build ──────────────────────────────────────────────────
func _build_home_offsets() -> void:
    _home_offsets.resize(max_crowd)
    _home_offsets[0] = Vector3.ZERO   # slot 0 hidden anyway
    for i in range(1, max_crowd):
        var slot  : int   = i
        var ring  : int   = int(ceil(float(slot) / 6.0))
        var idx   : int   = slot - 6 * (ring - 1) - 1
        var theta : float = float(idx) / 6.0 * TAU
        var r     : float = float(ring) * ring_spacing
        _home_offsets[i] = Vector3(cos(theta) * r, 0.0, sin(theta) * r)

# ── Per-frame transform update ───────────────────────────────────────
func _apply_transforms() -> void:
    var alive : int = count
    for i in range(max_crowd):
        if i == 0 or i >= alive:
            multimesh.set_instance_transform(i, _hidden_xform)
            continue
        var base : Vector3 = _home_offsets[i]
        # Per-instance phase seed so followers bob out of sync.
        var phase : float = float(i) * 0.37
        var bob : float = sin((_time * bob_freq * TAU) + phase) * bob_amp
        var pos := Vector3(base.x, crowd_y + bob, base.z)
        var xf := Transform3D(Basis(), pos)
        multimesh.set_instance_transform(i, xf)

# ── Signal handlers ──────────────────────────────────────────────────
func _on_gate_triggered(gate_type: int, value: int) -> void:
    # Ch 72F defines GateType enum values 0..3 → ADD/SUB/MUL/DIV
    match gate_type:
        0: set_count(count + value)              # ADD
        1: set_count(count - value)              # SUB
        2: set_count(count * value)              # MUL
        3: set_count(int(count / max(1, value))) # DIV, floor

func _on_obstacle_hit(damage: int) -> void:
    remove_members(damage)
```

:::callout-intuition[Read \_apply\_transforms carefully]
Every frame we loop all `max_crowd` slots. Alive slots get a transform with
 the ring offset + bob. Dead or hidden slots get the `_hidden_xform` — a
 `Transform3D` scaled to zero, which effectively hides the instance without
 changing `instance_count`. This trick is why we never reallocate the transform
 buffer; the alloc happened once in `_ready`.
:::

:::callout-warning[set\_instance\_transform is the MultiMesh API]
The instance transforms are stored inside the *MultiMesh* resource, not on the
 MultiMeshInstance3D node itself. Never call `self.transform` hoping to move
 instance *k*. Always use `multimesh.set_instance_transform(k, xf)`.
:::

:::callout-pitfall[The 250-instance loop each frame]
Yes, 250 transform sets each frame is a lot on paper. In practice it's ~0.4 ms on a
 mid-range phone because the API writes into a pre-allocated buffer with no GPU sync. If
 you ever cross 500 followers, or you profile and see the per-frame work climb, restrict
 the loop to `0..count` and skip the “hide the rest” branch (the
 dead ones stay hidden from last time). But at 250 max the simple version is easier to
 reason about.
:::

## 6. EventBus Wiring — Deferred to Ch 72F

CrowdManager already connects to `EventBus.gate_triggered` and
 `EventBus.obstacle_hit` in `_ready` — but no one emits those
 signals yet. Ch 72F builds Gate and Obstacle scenes that emit them. For this chapter's
 verification we'll fake the emissions with two debug keys.

## 7. Debug Keys — Add/Remove 5 Followers

Temporary debug inputs so we can watch the crowd form and shrink. Add them to
 Runner.gd (they'll be removed in Ch 72F when real gates handle the same job).

1. Open `Runner.gd`. Add at the bottom:

```gdscript
# ── DEBUG (Ch 72E only — remove in Ch 72F) ──────────────────────────
func _unhandled_input(ev: InputEvent) -> void:
    if ev is InputEventKey and ev.pressed:
        var cm : CrowdManager = $CrowdMulti
        if ev.keycode == KEY_1:
            cm.add_members(5)
            print("[Runner DBG] +5 → ", cm.count)
        elif ev.keycode == KEY_2:
            cm.remove_members(5)
            print("[Runner DBG] -5 → ", cm.count)
        elif ev.keycode == KEY_3:
            cm.set_count(100)
            print("[Runner DBG] set 100")
```

:::callout-tip[Why not add them via LaneController?]
Because LaneController already uses `_unhandled_input` for swipes and would
 call `runner.change_lane` as well as our debug handler. Two nodes can each
 have their own `_unhandled_input`; both fire. Adding it to Runner keeps them
 logically separate. Delete this block once Ch 72F is done.
:::

## 8. Verification

:::callout-key[Verify]
- Run (F5). One orange leader visible, no crowd yet (count = 1 = only slot
 0 which is hidden).
- Press 1 — six teal capsules pop in around the leader (ring 1 fills first).
 Press 1 again — five more fill into ring 2.
- Press 3 — the crowd jumps to 100 followers filling ~4 rings.
- Press 2 — five followers vanish from the outermost slots.
- The whole crowd moves and steers as one — swipe left with the mouse, the leader +
 the entire crowd tween together.
- Follower bob is *out of sync* — they don't all bob together, they ripple.
 (This is the phase seed doing its job.)
- Output shows the count printouts. No red errors.
:::

:::callout-warning[Crowd stays as one giant capsule at the origin]
Home offsets not built — the `_home_offsets.resize(max_crowd)` silently
 leaves zeros. Confirm the `for i in range(1, max_crowd)` loop is actually
 running (add a print inside). Common cause: you set *Instance Count* on the
 MultiMesh resource to 0 instead of 250; the loop then executes but the MultiMesh has no
 slots to write into.
:::

:::callout-warning[Framerate tanks at 100 crowd]
You're accidentally rendering shadows. Check *SunLight → Shadow → Enabled* — must
 be *off*. Also check that *CrowdMulti → Cast Shadow* is set to *Off*
 in the Inspector.
:::

:::callout-warning[Crowd doesn't follow lane changes]
You added CrowdMulti as a child of Main or something else instead of Runner. It must be
 under Runner so its local transforms are relative to the leader's world transform.
 Re-parent it in the Scene dock.
:::

## Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Why does slot 0 stay hidden even when count = 1?

::::solution[Solution]
Because the leader has his own visible LeaderMesh (Ch 72C). Rendering a follower
 capsule at the leader's exact origin would z-fight and read as one blurry double
 capsule. Hiding slot 0 keeps a clean visual separation.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
What is the visible count when you have 25 followers? Compute using the formula.

::::solution[Solution]
Slot 0 hidden, slots 1..24 are 24 visible followers. Ring 1 fills slots 1–6, ring 2
 fills 7–12, ring 3 fills 13–18, ring 4 fills 19–24 — 4 full rings, all 24 visible.
 Add one more (count = 26 total, slot 25) and ring 5 starts with a lone follower.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
You want followers slightly bigger than they are now — bump each capsule up to
 radius 0.35 to match the leader. Where do you change it, and what visual issue must you
 also address?

::::solution[Solution]
Open the CapsuleMesh resource on the MultiMesh (or the saved `.tres`). Set
 *Radius* = 0.35. Now followers touch or overlap each other because
 *ring\_spacing* (0.65 m) is less than *2 · radius = 0.7 m*. Bump
 *ring\_spacing* to 0.75 m. The whole formation grows slightly.
::::
:::

:::problem[Problem 4 challenge]{difficulty="challenge"}
Rewrite `_apply_transforms` to skip the “hide the dead ones”
 branch each frame — assume they were hidden last time we removed them. What's the
 risk?

::::solution[Solution]
Replace the loop with `for i in range(1, count):` and remove the
 *if i >= alive* hide branch. Also, in `set_count`, whenever count
 *decreases*, explicitly hide slots `[new..old)`. This is ~2× faster in
 the frame update but adds a small bit of state complexity. Risk: if any other code
 path ever writes a non-hidden transform into a “dead” slot (e.g. a debug
 path forgets to hide first), the ghost will render forever until removed. Trade-off:
 performance vs simplicity. Ship the simple version first.
::::
:::

:::summary
## Summary

The crowd exists. CrowdMulti (a MultiMeshInstance3D child of Runner) pre-allocates
 250 transforms in one buffer, arranges the live count into concentric rings via the
 ring-formation formula, applies a phased sine-bob every frame, and hides unused slots by
 scale-to-zero. Public `add/remove/set_count` API is ready for Ch 72F's gates
 and obstacles to call — meanwhile debug keys 1/2/3 exercise it manually. The whole crowd
 is 1 draw call regardless of size.

**Next:**
 [Ch 72F](./godot_ch72f_gates_obstacles.html) builds Gate and Obstacle scenes
 that emit the EventBus signals CrowdManager is already listening for.
:::
