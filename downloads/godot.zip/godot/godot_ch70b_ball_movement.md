---
title: "Earclacks — Ball & Physics Setup"
crumb: "Chapter 70B · Weapon Ball Clone Series"
meta:
  - "Est. study time: ~75 min"
  - "Part XII · Weapon Ball"
  - "Updated May 2026"
source: "markdown"
---

## Overview

The *ball* is the heart of Weapon Ball. Everything else — weapons, health, the game
 manager, the HUD — exists to serve it. In this chapter you will build a ball that:

- Moves purely through RigidBody2D physics (no steering AI, no manual velocity forcing)
- Detects every collision and emits a `bounced` signal that weapons can listen to
- Carries an arbitrary number of equipment slots so you can attach swords, bows, or abilities later
- Displays its HP as a numeric label centred on the ball body
- Integrates cleanly with the HealthComponent you will build in Ch 70D

:::callout-key[KEY CONCEPT]
Law 1:

No player input. The simulation runs itself.

Law 2:

No AI steering. Physics determines movement.

Law 3:

Equipment does the fighting — not the ball directly.
:::

### Prerequisites

- Ch 70A complete — arena scene, walls, GameManager autoload skeleton exist
- Familiarity with Godot 4 RigidBody2D and `@export`
- Basic GDScript signals

## Ball Architecture

:::callout-intuition[INTUITION]
CharacterBody2D is designed for player-controlled characters that call

move\_and\_slide()

every frame. We never move the ball manually —
        we give it an initial push and let Godot's physics engine bounce it forever.
        RigidBody2D is the right tool: it handles momentum, collision response, and
        energy conservation automatically.
:::

### Scene Tree: Ball.tscn

```
Ball (RigidBody2D)          ← Ball.gd
├── CollisionShape2D        ← CircleShape2D, radius 32
├── Sprite2D                ← coloured circle sprite
├── HPLabel (Label)         ← shows "100" centred on ball
├── HealthComponent (Node)  ← hp_changed + died signals (Ch 70D)
└── WeaponMount (Node2D)    ← equipment attaches here (Ch 70C)
```

:::callout-warning[WARNING]
Previous drafts of this chapter included a

BallAI

node with SEEK / EVADE /
        WANDER states. That is wrong and has been removed. The ball never steers itself.
:::

### Key RigidBody2D Properties

| Property | Value | Why |
| --- | --- | --- |
| `gravity_scale` | 0 | Top-down arena — no gravity |
| `lock_rotation` | true | Ball body must not spin; weapon controls own rotation in code |
| `linear_damp` | 0.4 | Gentle friction so balls slow slightly; prevents infinite acceleration |
| `continuous_cd` | CastRay | Prevents tunnelling through walls at high speed |
| `contact_monitor` | true | Required for `_integrate_forces` to report contacts |
| `max_contacts_reported` | 4 | Enough for simultaneous wall + ball contact |

:::callout-pitfall[PITFALL]
lock\_rotation = true

means the

RigidBody2D node

won't spin when hit.
        The

weapon

has its own angular speed stored in a variable
        (`current_angular_speed`) and rotates its own node manually in `_physics_process`. These are completely separate: locking the ball body
        does NOT prevent the weapon from spinning.
:::

## Configuring the RigidBody2D

### Step 1 — Create Ball.tscn

1. In the Godot editor: **Scene → New Scene**
2. Add root node: search "RigidBody2D", rename it to **Ball**
3. Save as `res://scenes/ball/Ball.tscn`

### Step 2 — Inspector settings on Ball

With the Ball node selected in the Inspector, set:

```gdscript
# In the Inspector (not in code):
gravity_scale         = 0
lock_rotation         = true
linear_damp           = 0.4
continuous_cd         = CastRay
contact_monitor       = true
max_contacts_reported = 4
```

### Step 3 — CollisionShape2D

1. Add child: **CollisionShape2D**
2. In Inspector → Shape → new **CircleShape2D**, radius `32`

### Step 4 — Sprite2D

1. Add child: **Sprite2D**
2. Assign a plain circle texture, or create a simple colored disc in the Godot theme tool
3. Scale to match the collision radius

### Step 5 — PhysicsMaterial

1. In Inspector → Physics Material Override → new **PhysicsMaterial**
2. Set `bounce = 0.0`, `friction = 0.0` on the ball itself
3. The walls have `bounce = 0.8` (set in Ch 70A) — the wall material drives the rebound

:::callout-tip[TIP]
In Godot 4, the effective bounce is the product of both colliding bodies' bounce values.
        Keeping the ball at 0.0 and the wall at 0.8 gives a clean 0.8× rebound.
        Putting 0.8 on both would give 0.64× (0.8 × 0.8), which feels sluggish.
:::

## Bounce Detection — the `bounced` Signal

:::callout-intuition[INTUITION]
We need to know the

exact moment

the ball collides with anything — a wall, the
        enemy ball, a projectile. The most reliable place to detect this is inside `_integrate_forces(state)`, which Godot calls mid-physics-step after contacts
        have been computed but before the frame's velocities are committed. Checking

state.get\_contact\_count() > 0

here fires exactly once per collision,
        with no frame-lag or missed events.
:::

:::definition
#### Definition: `bounced` Signal

A signal emitted by `Ball.gd` whenever the RigidBody2D body makes physical
 contact with any other body. Weapons subscribe to this signal to reverse their spin
 direction. It carries no arguments — receivers simply react to the event.
:::

### Why not `body_entered`?

`body_entered` is an alternative, but it fires on the *next frame* after
 the physics step. That one-frame delay can cause the weapon to continue spinning in the
 wrong direction for a visible frame before reversing. `_integrate_forces` has
 no such delay because it runs *inside* the physics step.

### Implementation

```gdscript
func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
    if state.get_contact_count() > 0:
        bounced.emit()
```

:::callout-pitfall[PITFALL]
state.get\_contact\_count()

always returns 0 unless you enable

contact\_monitor = true

AND set

max\_contacts\_reported

to at least 1
        in the Inspector. This is the single most common reason bounce detection silently fails.
:::

:::callout-pitfall[PITFALL]
If the ball simultaneously touches a wall corner and the enemy,

\_integrate\_forces

may be called with

get\_contact\_count() == 2

.

bounced

still only
        emits once per call of `_integrate_forces` — that's correct. Do NOT emit
        once per contact; that would fire the signal twice and double-reverse spin back to the
        original direction.
:::

:::example[Worked Example — tracing a wall bounce]
::::answer
Result: weapon spin reverses immediately on contact; ball velocity reflects off the wall.
::::

Frame N: Ball is moving right at 380 px/s. Weapon is spinning clockwise.

Physics step N+1:

1. Godot resolves the collision with the right wall.
2. `_integrate_forces(state)` runs — `state.get_contact_count() == 1`.
3. `bounced.emit()` fires.
4. MeleeWeapon's `_on_ball_bounced()` handler runs: `current_angular_speed *= -1.0` → now counter-clockwise.
5. Ball velocity is reflected by the physics engine: now moving left at ~304 px/s (×0.8 wall bounce).

Frame N+2: Ball is moving left, weapon spinning counter-clockwise. The reversal was immediate and in-sync.
:::

## Ball.gd — Full Script

Create a new GDScript at `res://scenes/ball/Ball.gd` and attach it to the Ball
 root node. Here is the complete script with every section explained:

```gdscript
class_name Ball
extends RigidBody2D

# ──────────────────────────────────────────────
# EXPORTS
# ──────────────────────────────────────────────
@export var team_color: Color    = Color("#478cbf")
@export var launch_speed: float  = 380.0

## Each slot is a PackedScene that extends EquipmentBase.
## Fill these in the Inspector or via BallSpawner at runtime.
@export var equipment_scenes: Array[PackedScene] = []

# ──────────────────────────────────────────────
# SIGNALS
# ──────────────────────────────────────────────
## Emitted mid-physics-step whenever the ball contacts anything.
## Weapons connect to this to reverse spin direction.
signal bounced

## Emitted by HealthComponent (re-exported here for convenience).
signal died(ball: Ball)

# ──────────────────────────────────────────────
# NODE REFERENCES
# ──────────────────────────────────────────────
@onready var health_component: Node     = $HealthComponent
@onready var weapon_mount: Node2D       = $WeaponMount
@onready var hp_label: Label            = $HPLabel
@onready var sprite: Sprite2D           = $Sprite2D

# ──────────────────────────────────────────────
# READY
# ──────────────────────────────────────────────
func _ready() -> void:
    # Tint the sprite to this team's color
    sprite.modulate = team_color

    # Connect HealthComponent signals
    health_component.hp_changed.connect(_on_hp_changed)
    health_component.died.connect(_on_died)

    # Seed the HP label with starting value
    hp_label.text = str(health_component.max_hp)

    # Attach all equipment scenes
    _attach_equipment()

# ──────────────────────────────────────────────
# PHYSICS — BOUNCE DETECTION
# ──────────────────────────────────────────────
func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
    ## Emit bounced once per physics step that has any contact.
    if state.get_contact_count() > 0:
        bounced.emit()

# ──────────────────────────────────────────────
# PUBLIC API
# ──────────────────────────────────────────────
## Called by BallSpawner or Arena to send the ball flying.
func launch(direction: Vector2) -> void:
    linear_velocity = direction.normalized() * launch_speed

## Called by weapons or projectiles to deal damage.
func take_damage(amount: float) -> void:
    health_component.apply_damage(amount)

# ──────────────────────────────────────────────
# EQUIPMENT
# ──────────────────────────────────────────────
func _attach_equipment() -> void:
    for scene in equipment_scenes:
        if scene == null:
            continue
        var equipment = scene.instantiate()
        weapon_mount.add_child(equipment)

# ──────────────────────────────────────────────
# SIGNAL HANDLERS
# ──────────────────────────────────────────────
func _on_hp_changed(new_hp: float, _max_hp: float) -> void:
    hp_label.text = str(int(new_hp))

func _on_died() -> void:
    died.emit(self)
```

:::callout-key[KEY CONCEPT]
equipment\_scenes is an Array[PackedScene]

— not a single weapon scene.
        This means a ball can carry a sword AND a shield AND a passive regen ability simultaneously.
        You add future equipment types without touching Ball.gd at all.

Ball.gd does NOT know what weapons do.

It attaches them and emits

bounced

. What each weapon does with that signal
        is entirely the weapon's responsibility (Open/Closed Principle).
:::

### Why `died` re-emits from Ball?

HealthComponent emits `died` with no arguments. GameManager needs to know
 *which* ball died so it can determine the winner. Ball re-emits `died(self)`
 passing itself as the argument. This keeps HealthComponent generic and reusable on
 any node.

## Equipment Slots — Why an Array?

:::callout-intuition[INTUITION]
Early builds of this game hard-coded a single

weapon\_scene: PackedScene

.
        The moment we wanted to add a shield, or a passive HP-regen ring, or a gun alongside
        a sword, we had to rewrite Ball.gd. By using

Array[PackedScene]

instead,
        we solve this problem once and never revisit it.
:::

### Filling slots at runtime vs. in the Inspector

For quick testing, assign scenes directly in the Inspector on Ball.tscn.
 For the real game, BallSpawner (in Arena.gd) will fill the array programmatically
 so you can configure loadouts from data rather than scenes.

:::example[Worked Example — assigning two equipment items in Inspector]
::::answer
Result: ball spawns with both a sword and a shield attached to WeaponMount.
::::

1. Select Ball.tscn root node in the editor.
2. Inspector → `equipment_scenes` → resize Array to 2.
3. Slot 0: drag in `res://scenes/weapons/Sword.tscn`
4. Slot 1: drag in `res://scenes/weapons/Shield.tscn`
5. Play the scene. Both nodes appear under WeaponMount at startup.
:::

### Configuring loadouts from BallSpawner

```gdscript
# In Arena.gd or BallSpawner.gd
var sword_scene = preload("res://scenes/weapons/Sword.tscn")
var bow_scene   = preload("res://scenes/weapons/Bow.tscn")

func _spawn_ball(spawn_pos: Vector2, color: Color,
                 loadout: Array[PackedScene]) -> Ball:
    var ball: Ball = BALL_SCENE.instantiate()
    ball.position         = spawn_pos
    ball.team_color       = color
    ball.equipment_scenes = loadout   # assign before _ready()
    add_child(ball)
    return ball
```

:::callout-warning[WARNING]
\_ready()

calls `_attach_equipment()`, which reads `equipment_scenes`. If you add the ball to the scene tree first and
        then set the array,

\_ready()

has already run with an empty array and
        no equipment will be attached. Always set exported properties

before `add_child()`.
:::

## HP Label — Numeric HP on the Ball

:::callout-intuition[INTUITION]
Weapon Ball games display the ball's current HP as a number floating on the ball body.
        This lets viewers instantly read health states without squinting at a small health bar.
        It's especially important for YouTube Shorts where the viewport is narrow.
:::

### Setting up HPLabel in the scene

1. Add child to Ball: **Label**, rename to **HPLabel**
2. Inspector → Layout → Anchors Preset: **Center**
3. Pivot Offset: `(0, 0)` — so the label centres on the ball origin
4. Horizontal Alignment: **Center**, Vertical Alignment: **Center**
5. Theme Overrides → Font Size: `20`
6. Theme Overrides → Font Color: `White` (or your team's contrast color)
7. Autowrap Mode: **Off** (HP numbers never wrap)

### Why centre manually instead of using a Container?

The ball is a RigidBody2D, not a Control node. Control containers only work inside the
 CanvasLayer / UI tree. We use a Label with manual anchor centering because it lives in
 the 2D game world, not the UI layer. The label moves with the ball automatically since
 it is a child node.

:::example[Worked Example — HP display update flow]
::::answer
Result: label shows "75" immediately when ball takes 25 damage from initial 100 HP.
::::

1. Enemy weapon hits our ball's HealthComponent: `apply_damage(25.0)`
2. HealthComponent clamps HP to 75, emits `hp_changed(75.0, 100.0)`
3. Ball's `_on_hp_changed(75.0, 100.0)` handler fires
4. `hp_label.text = str(int(75.0))` → label now reads "75"
:::

:::callout-pitfall[PITFALL]
If HPLabel appears in the scene but is invisible in-game, check:

- Label's Z-index is higher than the Sprite2D (or set it to 1 via CanvasItem)
- Font color is not the same as the sprite color
- Label position is (0,0) relative to Ball — not offset to a corner
:::

## Updating Arena.gd — Spawning Two Balls

Arena.gd orchestrates everything at scene level. With the corrected Ball.tscn ready,
 update `_spawn_ball` to match the new export names and return the ball
 so GameManager can track it.

```gdscript
class_name Arena
extends Node2D

const BALL_SCENE := preload("res://scenes/ball/Ball.tscn")
const SWORD_SCENE := preload("res://scenes/weapons/Sword.tscn")

@onready var spawn_left:  Marker2D = $BallSpawner/SpawnLeft
@onready var spawn_right: Marker2D = $BallSpawner/SpawnRight

var ball_a: Ball
var ball_b: Ball

func _ready() -> void:
    _spawn_balls()

func _spawn_balls() -> void:
    var left_loadout:  Array[PackedScene] = [SWORD_SCENE]
    var right_loadout: Array[PackedScene] = [SWORD_SCENE]

    ball_a = _spawn_ball(spawn_left.position,  Color("#478cbf"), left_loadout)
    ball_b = _spawn_ball(spawn_right.position, Color("#e06c75"), right_loadout)

    # Connect died signals to GameManager
    ball_a.died.connect(GameManager.on_ball_died)
    ball_b.died.connect(GameManager.on_ball_died)

func _spawn_ball(spawn_pos: Vector2, color: Color,
                 loadout: Array[PackedScene]) -> Ball:
    var ball: Ball = BALL_SCENE.instantiate()
    ball.position         = spawn_pos
    ball.team_color       = color
    ball.equipment_scenes = loadout   # BEFORE add_child
    add_child(ball)
    return ball

## Called by GameManager when the FIGHTING state begins.
func launch_balls() -> void:
    ball_a.launch(Vector2(1.0, 0.3))   # aim slightly toward center
    ball_b.launch(Vector2(-1.0, -0.3))
```

:::callout-connect[CONNECTION]
launch\_balls()

is called by GameManager after the countdown completes.
        The balls exist and idle at their spawn positions during WAITING and COUNTDOWN states —
        they only start moving when GameManager calls this function in the FIGHTING state.
:::

## Testing the Ball

### Minimal test: ball bounces between walls

1. Temporarily comment out `_attach_equipment()` in `_ready()`
 (weapons don't exist yet)
2. In Arena.gd `_ready()`, call `launch_balls()` directly
 (skip countdown for now)
3. Run the Arena scene
4. Expected: both balls fly across the arena, bounce off all four walls indefinitely,
 and never leave the arena

### Bounce signal test

1. In Ball.gd `_ready()`, add a temporary line:

`bounced.connect(func(): print("bounce!"))`
2. Run the arena — you should see "bounce!" in the Output panel every time the ball
 hits a wall or the other ball
3. Remove the test line when confirmed

### HP label test

1. In Arena.gd, after spawning, add:

`ball_a.take_damage(30.0)`
2. Run — the label should immediately show "70" instead of "100"
3. Remove the test line

:::callout-tip[TIP]
While testing, open

Debugger → Remote

in the editor. You can inspect
        the live scene tree and see exactly what nodes Ball has, what values its exports hold,
        and whether signals are connected.
:::

## Practice Problems

:::problem{difficulty="easy"}
**1.**
 What two Inspector properties must be set on Ball for
 `state.get_contact_count()` to return a non-zero value?

::::solution[Solution]
`contact_monitor = true` and `max_contacts_reported ≥ 1`.
 Without both, the physics engine doesn't track contacts for this body.
::::
:::

:::problem{difficulty="easy"}
**2.**
 A ball is spawned with `equipment_scenes = []`. What happens when
 `_attach_equipment()` runs?

::::solution[Solution]
The `for scene in equipment_scenes` loop iterates zero times — nothing
 is added to WeaponMount. The ball functions normally but has no weapons.
::::
:::

:::problem{difficulty="standard"}
**3.**
 Explain why `equipment_scenes` must be set *before*
`add_child(ball)`. What breaks if you set it after?

::::solution[Solution]
`add_child()` enters the ball into the scene tree, which triggers
 `_ready()` immediately. `_ready()` calls
 `_attach_equipment()`, which reads `equipment_scenes`.
 If the array is set after `add_child()`, `_ready()` has
 already run with the empty default array. The weapons are never instantiated.
::::
:::

:::problem{difficulty="standard"}
**4.**
 The ball simultaneously hits a wall corner and the enemy ball in the same physics
 step. `state.get_contact_count()` returns 2.
 How many times does `bounced` emit?

::::solution[Solution]
Once. The `if state.get_contact_count() > 0` check emits one signal
 regardless of contact count. Weapons receive one `bounced` event and
 reverse spin once. If we emitted per contact, spin would double-reverse and return
 to the original direction — cancelling the effect.
::::
:::

:::problem{difficulty="standard"}
**5.**
 Why is `lock_rotation = true` set on Ball, given that weapons rotate?

::::solution[Solution]
`lock_rotation` prevents the RigidBody2D *physics body* from
 acquiring angular velocity from collisions. Without it, the ball would start
 physically spinning when hit, which looks wrong and destabilises movement.
 The weapon is a separate child node whose rotation is controlled entirely by code
 (`current_angular_speed` in MeleeWeapon.gd) — it is unaffected by the
 ball body's lock\_rotation setting.
::::
:::

:::problem{difficulty="standard"}
**6.**
 Write the two lines in Ball.gd that keep the HPLabel in sync with HealthComponent
 on startup (before any damage has been taken).

::::solution[Solution]
```gdscript
health_component.hp_changed.connect(_on_hp_changed)
hp_label.text = str(health_component.max_hp)
```

The connect wires future updates; the direct assignment seeds the initial value
 because `hp_changed` hasn't fired yet at startup.
::::
:::

:::problem{difficulty="challenge"}
**7.**
 You want to add a "rage mode" that doubles `launch_speed` after the ball
 has bounced 10 times. Implement a `bounce_count` variable and the
 logic in `_integrate_forces` without breaking the existing
 `bounced` signal or weapon subscriptions.

::::solution[Solution]
```gdscript
var bounce_count: int = 0
const RAGE_THRESHOLD: int = 10

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
    if state.get_contact_count() > 0:
        bounce_count += 1
        bounced.emit()
        if bounce_count == RAGE_THRESHOLD:
            linear_velocity = linear_velocity.normalized() \
                              * launch_speed * 2.0
```

Multiplying the normalised current velocity by the new speed applies rage mode
 without needing to store a separate "current speed" variable. The `==`
 check (not `>=`) ensures we only apply the boost once.
::::
:::

:::problem{difficulty="challenge"}
**8.**
 Describe how you would add a second spawn configuration where BallA gets a Sword
 and BallB gets a Bow, without modifying Ball.gd or Ball.tscn.

::::solution[Solution]
Change the loadout arrays in Arena.gd's `_spawn_balls()`:

```gdscript
var left_loadout:  Array[PackedScene] = [SWORD_SCENE]
var right_loadout: Array[PackedScene] = [BOW_SCENE]
```

Ball.gd iterates whatever is in `equipment_scenes` — it doesn't know
 or care whether the scene is a Sword, Bow, or Shield. Adding different equipment
 types only requires creating new equipment scene files and assigning them to
 the array at spawn time.
::::
:::

## Chapter Summary

:::summary
### Key Concepts

| Concept | Implementation |
| --- | --- |
| Ball node type | RigidBody2D with gravity\_scale=0, lock\_rotation=true, linear\_damp=0.4 |
| Collision detection | contact\_monitor=true, max\_contacts\_reported=4 |
| Bounce signal | `_integrate_forces` → `bounced.emit()` when contact\_count > 0 |
| Equipment slots | `Array[PackedScene] equipment_scenes` — any number of items |
| Equipment attach timing | Set equipment\_scenes BEFORE add\_child() so \_ready() sees them |
| HP display | HPLabel child Label, centred; updated via hp\_changed signal |
| Launch | `launch(direction)` sets linear\_velocity once; physics takes over |
| No AI, no steering | Ball.gd has zero pathfinding, zero force application after launch |
:::

### What's next?

The ball moves and bounces. It has equipment slots ready to receive weapons. In Ch 70C
 we build the **EquipmentBase class hierarchy** — starting with MeleeWeapon
 which subscribes to `bounced` to reverse its spin, and includes the parry
 detection system. By the end of Ch 70C a spinning sword will be orbiting each ball and
 reversing direction on every collision.
