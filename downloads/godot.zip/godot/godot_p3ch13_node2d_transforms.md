---
title: "Node2D, the 2D Coordinate System & Transforms"
source: "godot_p3ch13_node2d_transforms.html"
---

Part III · 2D Game Development

# Node2D, the 2D Coordinate System & Transforms

Part III Chapter 13 · Prerequisites: Ch 3 (Nodes & Scenes), Ch 4 (GDScript basics) · est. 70 min

## Overview

Before you can make anything move, you need to understand where things *are* and how Godot describes their position, rotation, and scale. This chapter covers the foundational spatial concepts of every 2D game: the coordinate system, the **Node2D** class and all its properties, and the **Transform2D** — Godot's compact mathematical description of position + rotation + scale in one object.

These concepts are not optional. Every CharacterBody2D, every Sprite2D, every Area2D is a Node2D at its core. Understanding transforms is what separates developers who fight the coordinate system from those who work with it.

## 1 · The 2D Coordinate System

:::callout-intuition[Intuition]
Godot's 2D coordinate system places the **origin (0, 0) at the top-left corner** of the screen/viewport. The X axis increases to the **right** and the Y axis increases **downward**. This is the standard screen-space convention used by almost every 2D engine and GUI framework — it matches how raster graphics are stored in memory (top row first).
:::

### Origin and Axes

```gdscript
# Screen: 1280 x 720 pixels
# (0, 0)   = top-left corner
# (640, 360) = center of screen
# (1280, 720) = bottom-right corner

# X axis: left(-) ← origin → right(+)
# Y axis: up(-)   ↑ origin ↓ down(+)   ← Y is FLIPPED vs. math class
```

:::callout-pitfall[Y is flipped — the single biggest gotcha in 2D games]
In school maths, Y increases upward. In Godot (and most game engines), Y increases **downward**. This means:

- Moving a node "up" visually requires *decreasing* its Y: `position.y -= speed`
- Rotating clockwise from the editor's perspective is a *positive* rotation in radians
- Angles work counter-intuitively: right = 0°, down = 90°, left = 180°, up = 270° (or -90°)
:::

### Pixels and World Units

By default, 1 Godot unit = 1 pixel. A node at `position = Vector2(100, 50)` is 100 pixels from the left and 50 pixels from the top. You can change this relationship with a camera zoom or by using a custom viewport size — but the math stays the same.

Angles in Godot are always in **radians** internally. Use `deg_to_rad()` and `rad_to_deg()` to convert, or use the `rotation_degrees` property which works in degrees directly.

### Useful Vector2 Constants

| Constant | Value | Use |
| --- | --- | --- |
| `Vector2.ZERO` | (0, 0) | Origin, reset position |
| `Vector2.ONE` | (1, 1) | Default scale, full size |
| `Vector2.RIGHT` | (1, 0) | Facing right direction |
| `Vector2.LEFT` | (-1, 0) | Facing left direction |
| `Vector2.UP` | (0, -1) | Facing up (visually) — note negative Y |
| `Vector2.DOWN` | (0, 1) | Facing down (visually) |
| `Vector2.INF` | (∞, ∞) | Sentinel / invalid position |

## 2 · The Node2D Class — Every Property Explained

:::callout-intuition[Intuition]
**Node2D** is the base class for every visible 2D object in Godot. It adds spatial awareness to a plain `Node`: position in the world, rotation, scale, and drawing order. You rarely use Node2D directly — instead you use its subclasses like Sprite2D, CharacterBody2D, Area2D. But all their spatial behaviour comes from Node2D.
:::

Node2D inherits from **CanvasItem** (which adds visibility, modulate, drawing), which inherits from **Node**. The spatial properties below are all from Node2D.

### `position: Vector2`

The node's **local position** — relative to its parent. A Sprite2D with `position = Vector2(50, 0)` is 50 pixels to the right of wherever its parent is. If the parent moves, the Sprite2D moves with it.

```gdscript
$Sprite.position = Vector2(200, 100)   # set absolute local position
$Sprite.position.x += 5               # move right 5px (each frame = very fast)
$Sprite.position += Vector2(5, 0)     # equivalent

# global_position is world-space (accounts for all parent transforms)
$Sprite.global_position = Vector2(500, 300)  # place at exact world coords
print($Sprite.global_position)        # always world position

# Offset without rebuilding position
position = Vector2.ZERO               # put at parent's origin
```

### `rotation: float` and `rotation_degrees: float`

`rotation` is in **radians**. `rotation_degrees` is the same property expressed in degrees — setting one automatically updates the other. Rotation is clockwise in screen space (because Y is flipped).

```gdscript
$Turret.rotation = PI / 4              # 45 degrees clockwise (radians)
$Turret.rotation_degrees = 45.0        # same thing, easier to read
$Turret.rotation_degrees += 90.0       # rotate 90° clockwise

# Rotate toward a target each frame
func _process(delta: float) -> void:
    var dir := (target.global_position - global_position).angle()
    rotation = lerp_angle(rotation, dir, 5.0 * delta)  # smooth rotate

# global_rotation is the actual world rotation (sum of all parents' rotations)
print(global_rotation_degrees)
```

### `scale: Vector2`

Scale multiplies the node's size and the local coordinates of all its children. `Vector2(1, 1)` is normal size. `Vector2(2, 1)` doubles width. `Vector2(-1, 1)` flips horizontally (a common pattern for character facing).

```gdscript
$Character.scale = Vector2(1, 1)       # normal (default)
$Character.scale = Vector2(2.0, 2.0)  # double size
$Character.scale.x = -1               # flip horizontally (face left)
$Character.scale.x = 1                # flip back (face right)

# Scale uniformly
$Character.scale = Vector2.ONE * 1.5  # 150% size

# Warning: non-uniform scale + rotation creates skew
# (discussed under skew)
```

:::callout-tip[Flipping with scale vs. FlipH on Sprite2D]
Setting `scale.x = -1` on a CharacterBody2D flips the entire node including children (hitbox, weapons, particles). Setting `flip_h = true` on a child Sprite2D only flips the sprite's visual — the physics body and children are unaffected. Choose based on what you want flipped.
:::

### `skew: float`

Skew shears the node's coordinate space. A value of `0.3` tilts all children to the right as if leaning. Rarely used in gameplay; mostly useful for 2D perspective illusions or stylized UI effects.

```gdscript
$Shadow.skew = 0.4   # slant the shadow sprite to fake a directional light
```

### `z_index: int` and `z_as_relative: bool`

Controls draw order within the same `CanvasLayer`. Higher z\_index draws on top. When `z_as_relative = true` (the default), the z\_index is added to the parent's z\_index. When `false`, the z\_index is absolute regardless of parent.

```gdscript
$Background.z_index = -10     # draws behind everything
$Player.z_index     = 0      # default
$HUD.z_index        = 10     # draws on top of world
$Bullet.z_index     = 5      # in front of world, behind HUD

# Override to absolute z — ignores parent
$VFX.z_as_relative = false
$VFX.z_index = 100   # always in front regardless of scene hierarchy
```

### `visible: bool` and `modulate: Color`

These come from **CanvasItem** (Node2D's parent class), but they're critical to know:

```gdscript
# visible — hides the node and ALL its children
$Enemy.visible = false           # hides visually; node still processes
$Enemy.show()                    # same as visible = true
$Enemy.hide()                    # same as visible = false

# modulate — tints the entire node tree (including children)
$Player.modulate = Color(1, 0, 0, 1)   # tint red
$Player.modulate = Color.WHITE          # remove tint (default)
$Player.modulate.a = 0.5               # 50% transparent

# self_modulate — only affects this node, not children
$Sprite.self_modulate = Color(1, 1, 1, 0.8)
```

### Other Useful Node2D Methods

| Method | Returns | Description |
| --- | --- | --- |
| `get_angle_to(point)` | float | Angle in radians from this node to `point` (world space) |
| `look_at(point)` | void | Rotate to face `point` (world space) |
| `translate(offset)` | void | Move by `offset` in **local space** |
| `global_translate(offset)` | void | Move by `offset` in **world space** |
| `rotate(radians)` | void | Add `radians` to current rotation |
| `apply_scale(ratio)` | void | Multiply current scale by `ratio` |
| `to_local(world_point)` | Vector2 | Convert world-space point to this node's local space |
| `to_global(local_point)` | Vector2 | Convert local-space point to world space |

## 3 · Transforms — The Full Picture

:::callout-intuition[Intuition]
A **transform** is a mathematical object that encodes position, rotation, and scale together in one structure. Rather than storing three separate values and combining them when needed, a transform pre-computes the combination into a compact form that can convert any point from local coordinates to world coordinates (and back) with a single multiplication.

Think of a transform as a "local coordinate frame" — a mini origin, X-axis, and Y-axis that the node and all its children live in.
:::

### Transform2D

`Transform2D` is Godot's 2D transform type. It is a 3×2 matrix (3 columns, 2 rows) composed of:

- `x: Vector2` — the "right" direction of the local X axis (scaled and rotated)
- `y: Vector2` — the "down" direction of the local Y axis (scaled and rotated)
- `origin: Vector2` — the position of the local origin in the parent's space

```gdscript
# Access the raw transform
var t: Transform2D = $Sprite.transform   # local transform
var g: Transform2D = $Sprite.global_transform   # world transform

# transform.origin IS position (just a different accessor)
print(t.origin)   # same as $Sprite.position

# Build a Transform2D from scratch
var my_transform := Transform2D(
    PI / 4,        # rotation in radians (45°)
    Vector2(100, 200)  # position/origin
)

# Or from x-axis, y-axis, origin:
var t2 := Transform2D(
    Vector2(cos(angle), sin(angle)),   # x column
    Vector2(-sin(angle), cos(angle)), # y column
    position
)

# Apply a transform to a point
var world_point := $Enemy.global_transform * Vector2(10, 0)
# This gives the point that is 10 units to the RIGHT of the enemy in the enemy's local space
```

### Global vs. Local Transform

| Property | Space | Use when |
| --- | --- | --- |
| `position` | Local (relative to parent) | Positioning within a parent node |
| `global_position` | World | Absolute positions, spawning, teleporting |
| `rotation` | Local | Rotating relative to parent |
| `global_rotation` | World | Absolute facing direction |
| `transform` | Local | Full local transform matrix |
| `global_transform` | World | Full world transform matrix |

### Transform2D Methods

| Method | Returns | Description |
| --- | --- | --- |
| `Transform2D.IDENTITY` | Transform2D | Identity: no rotation, no scale, origin at 0,0 |
| `t.rotated(angle)` | Transform2D | New transform rotated by `angle` radians |
| `t.scaled(scale)` | Transform2D | New transform scaled by `scale` Vector2 |
| `t.translated(offset)` | Transform2D | New transform translated by `offset` |
| `t.inverse()` | Transform2D | Inverse transform (convert world → local) |
| `t.affine_inverse()` | Transform2D | Inverse accounting for scale |
| `t.get_rotation()` | float | Extract rotation in radians |
| `t.get_scale()` | Vector2 | Extract scale factor |
| `t.get_origin()` | Vector2 | Extract position |
| `t * point` | Vector2 | Transform a point from local to world |
| `t.basis_xform(vec)` | Vector2 | Transform a direction (ignores translation) |
| `t.interpolate_with(other, weight)` | Transform2D | Lerp between two transforms |

## 4 · Local Space Operations

:::callout-intuition[Intuition]
When you move a node "forward" in its current facing direction, you don't want to move along the world's X axis — you want to move along the node's *own* X axis. This is called a **local space** operation. Godot makes this easy with methods that automatically account for the node's current rotation.
:::

### `to_local()` and `to_global()`

```gdscript
# Convert a world-space point to this node's local coordinates
var mouse_world: Vector2 = get_global_mouse_position()
var mouse_local: Vector2 = to_local(mouse_world)
# mouse_local is relative to this node's origin and rotation

# Convert a local point to world coordinates
var barrel_tip_local := Vector2(40, 0)   # 40px right of gun origin
var barrel_tip_world := to_global(barrel_tip_local)
# barrel_tip_world accounts for gun's world position AND rotation

# Practical: spawn a bullet at a gun's barrel tip
func fire() -> void:
    var bullet := BulletScene.instantiate()
    get_parent().add_child(bullet)
    bullet.global_position = $GunBarrelTip.global_position
    bullet.rotation = global_rotation   # match gun's world rotation
```

### `look_at(target: Vector2)`

Rotates the node so its positive X axis (local "right") points toward `target` in world space. This is the fastest way to make a turret face a player or a bullet face its direction of travel.

```gdscript
func _process(delta: float) -> void:
    # Turret always faces the player
    $Turret.look_at($Player.global_position)

# After look_at, the node's right (+X) points at the target.
# If your sprite "forward" direction is not +X, rotate by an offset:
$Sprite.look_at(target)
$Sprite.rotation += PI   # if sprite faces left by default, flip 180°
```

### `translate()` — Moving in Local Space

`translate(offset)` adds `offset` to the node's **local** position — meaning the offset is in the node's own rotated coordinate frame. This is how you make something "move forward" regardless of which way it's facing.

```gdscript
# Move 5 pixels in the node's local "right" direction (its +X axis)
# No matter how the node is rotated, this moves it "forward"
translate(Vector2(5, 0))

# Same as: position += transform.x * 5

# Compare: position += Vector2(5, 0)   ← always moves RIGHT in world space
#          translate(Vector2(5, 0))     ← moves in LOCAL right (respects rotation)

# Practical: spaceship always moves in the direction it's facing
func _physics_process(delta: float) -> void:
    if Input.is_action_pressed("thrust"):
        velocity = transform.x * thrust_speed  # transform.x = local right unit vector
    move_and_slide()
```

:::callout-key[The transform.x trick]
`transform.x` is the unit vector pointing in the node's local "right" direction, expressed in world space. It equals `Vector2(cos(rotation), sin(rotation))`. Multiplying it by a speed gives you a world-space velocity vector that always points in the node's forward direction. This is the fundamental movement formula for top-down games and space shooters.
:::

## 5 · Scene Hierarchy & Transform Inheritance

:::callout-intuition[Intuition]
Transforms compose through the scene tree. A child node's *local* transform is defined relative to its parent. The child's *world* transform is the parent's world transform multiplied by the child's local transform. This chain continues all the way to the scene root. Moving a parent automatically moves all its children, but the children's *local* positions don't change.
:::

```gdscript
# Example: Player scene tree
# Player (CharacterBody2D) — world pos (100, 200), rotation 45°
#   └── Gun (Node2D)       — local pos (20, 5),  rotation 0°
#       └── BarrelTip      — local pos (30, 0),  rotation 0°

# Gun's world position: Player's transform applied to (20, 5)
# = Player moves to (100, 200), then Gun is 20px right and 5px down
# In the Player's rotated space (45°), "right" is actually diagonal
# So Gun's actual world position is NOT simply (120, 205)

# To get the actual world position:
print($Gun.global_position)     # correct world position
print($BarrelTip.global_position)  # Gun's world + BarrelTip's local

# Reparenting — move a node to a new parent while keeping world position
func reparent_keeping_world_transform(node: Node2D, new_parent: Node2D) -> void:
    var world_t := node.global_transform
    node.reparent(new_parent)   # built-in reparent (Godot 4)
    node.global_transform = world_t  # restore world position
```

:::callout-warning[Avoid setting global\_position in \_process every frame]
Setting `global_position` directly bypasses the parent-relative transform chain — it's a "teleport." For moving physics bodies, use `velocity` and `move_and_slide()`. For non-physics nodes, adding to `position` (local) each frame is both correct and efficient. Use `global_position` sparingly, mainly for initial placement or teleportation.
:::

:::summary
## Chapter Summary

| Concept | Key point |
| --- | --- |
| 2D origin | Top-left of viewport. X right, Y **down** (flipped vs. math). |
| `position` | Local position relative to parent. `global_position` for world coords. |
| `rotation` | Radians, clockwise. Use `rotation_degrees` for human-readable values. |
| `scale` | Multiplier. `scale.x = -1` flips horizontally. |
| `z_index` | Draw order within CanvasLayer. Higher = on top. |
| `visible` / `modulate` | Visibility and tinting, inherited by children. |
| Transform2D | Encodes position + rotation + scale as a 3×2 matrix. |
| `transform.x` | Local "right" unit vector — use for forward movement. |
| `to_local()` | Convert world point → local. `to_global()` for reverse. |
| `look_at()` | Rotate to face a world-space point. |
| `translate()` | Move in local space (respects rotation). Different from `position +=`. |
| Transform inheritance | Child's world transform = parent world transform × child local transform. |
:::

## Practice Problems

:::problem[1 easy]{difficulty="easy"}
A node is at position (300, 200). You want to move it 50 pixels to the left and 30 pixels upward. Write the single line of GDScript that changes its position correctly.

::::solution[Solution]
```gdscript
position += Vector2(-50, -30)
# Left = negative X; Up = negative Y (remember: Y increases downward)
```
::::
:::

:::problem[2 easy]{difficulty="easy"}
What is the difference between `$Sprite.rotation = 0` and `$Sprite.global_rotation = 0` if the Sprite's parent is rotated 90°?

::::solution[Solution]
`rotation = 0` means "no rotation relative to my parent" — since the parent is rotated 90°, the sprite will visually appear at 90° in the world.

`global_rotation = 0` means "zero rotation in world space" — the sprite looks horizontal/unrotated in the world regardless of parent rotation. Setting global\_rotation adjusts the local rotation to compensate for the parent.
::::
:::

:::problem[3 standard]{difficulty="standard"}
Write a `_physics_process` function for a top-down spaceship that moves in the direction it is currently facing (its local +X axis) at `speed` pixels per second when the "thrust" action is held.

::::solution[Solution]
```gdscript
@export var speed: float = 200.0

func _physics_process(delta: float) -> void:
    if Input.is_action_pressed("thrust"):
        # transform.x = local right = world direction the ship faces
        velocity = transform.x * speed
    else:
        velocity = velocity.move_toward(Vector2.ZERO, speed * delta)  # decelerate
    move_and_slide()
```
::::
:::

:::problem[4 standard]{difficulty="standard"}
A gun node is rotated 45° and positioned at (100, 100) in world space. The barrel tip is at local position (40, 0) from the gun. Without using `to_global()`, calculate where the barrel tip is in world space. Then verify with the to\_global call.

::::solution[Solution]
The gun's local +X axis points in direction (cos(45°), sin(45°)) = (0.707, 0.707). The barrel tip is 40 units along this axis from the gun's origin:

Barrel world pos = gun world pos + 40 \* gun\_facing = (100, 100) + 40 \* (0.707, 0.707) = (128.28, 128.28)

```gdscript
var barrel_world: Vector2 = $Gun.to_global(Vector2(40, 0))
# Should equal approximately (128.28, 128.28)
```
::::
:::

:::problem[5 standard]{difficulty="standard"}
You want a sprite to smoothly rotate to face the mouse cursor each frame. Write the complete `_process` function using `lerp_angle` for smooth interpolation at rate 8.0 per second.

::::solution[Solution]
```gdscript
func _process(delta: float) -> void:
    var mouse_pos: Vector2 = get_global_mouse_position()
    var target_angle: float = global_position.direction_to(mouse_pos).angle()
    rotation = lerp_angle(rotation, target_angle, 8.0 * delta)
```
::::
:::

:::problem[6 challenge]{difficulty="challenge"}
Write a function `spawn_bullet_from_gun(gun: Node2D, bullet_scene: PackedScene, speed: float) -> void` that spawns a bullet at the gun's barrel tip (local position (50, 0) on the gun), gives it the gun's world rotation, and launches it at `speed` pixels/sec in the gun's facing direction. Add the bullet to the main scene, not as a child of the gun.

::::solution[Solution]
```gdscript
func spawn_bullet_from_gun(gun: Node2D, bullet_scene: PackedScene, speed: float) -> void:
    var bullet := bullet_scene.instantiate() as Node2D
    # Add to the scene root so it's not a child of the gun
    get_tree().current_scene.add_child(bullet)
    # Place at gun's barrel tip in world space
    bullet.global_position = gun.to_global(Vector2(50, 0))
    # Match the gun's world rotation
    bullet.rotation = gun.global_rotation
    # Move in the gun's facing direction (local +X in world space)
    bullet.velocity = gun.global_transform.x * speed   # assumes bullet has velocity
```
::::
:::
