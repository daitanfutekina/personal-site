---
title: "Threading, WorkerThreadPool & Async Resource Loading"
source: "godot_ch62_threading.html"
---

Part X · Chapter 62

# Threading, WorkerThreadPool & Async Resource Loading

Estimated study time: 80 min · Godot 4.x · GDScript

## Chapter Overview

Some work is too expensive to run on the main thread without causing frame drops:
 procedural map generation, pathfinding for hundreds of agents, loading large assets mid-game.
 Threading lets this work happen on a background core while the game continues rendering.
 This chapter covers Godot's threading primitives (**Thread**, **Mutex**,
 **Semaphore**), the high-level **WorkerThreadPool** API, and
 **ResourceLoader's threaded loading** for stutter-free asset streaming.

:::callout-pitfall[Critical Rule]
Never call Godot scene/node API from a background thread.

Only the main thread may touch the scene tree, nodes, and most Godot singletons.
  Background threads may only do pure computation and communicate results back to the
  main thread via

call\_deferred()

or a shared, mutex-protected data structure.
:::

## Why Threads — The Frame Budget Problem

:::callout-intuition[Intuition]
Your game has ~16 ms to do everything before the next frame must be rendered at 60 fps.
  If procedural chunk generation takes 40 ms, the game freezes for 2–3 frames whenever
  the player crosses a chunk boundary. Moving that work to a background thread lets the
  main thread keep rendering at 60 fps while the chunk generates in parallel.
:::

Threads are appropriate when:

- A single operation takes >2 ms and cannot be split across multiple frames easily
- You need to load/decompress large resources mid-game without a loading screen
- CPU-intensive processing can be done without touching the scene tree (pathfinding, procedural generation, physics simulations, AI planning)

Threads are *not* appropriate when:

- The work must touch nodes, signals, or the scene tree (use `call_deferred` for the final step)
- The operation is fast (<1 ms) — thread overhead dominates
- You're targeting single-core platforms (some consoles, old mobile)

Frame Timeline — Without vs. With Background Thread

Without threads:

Main

frame

frame

chunk gen — 40ms STALL

frame

frame

player sees freeze here →                   resumed

With background thread:

Main

frame

frame

frame

frame

frame

frame

frame

BG

chunk gen (40ms, parallel)

deferred

Main thread never stalls — background thread does the heavy work, posts result via call\_deferred()

Without threads, a 40ms chunk generation blocks every frame until it finishes. With a background thread, the main thread renders uninterrupted at 60fps while the chunk builds in parallel — then `call_deferred()` safely hands the result back.

## The Thread Class

`Thread` is Godot's low-level threading primitive. You start it with a
 `Callable`, it runs in a background OS thread, and you join it to retrieve
 the result.

```gdscript
## Basic Thread usage
extends Node

var _thread := Thread.new()

func _ready() -> void:
    # Start background work
    _thread.start(_do_heavy_work.bind(1_000_000))

func _do_heavy_work(iterations: int) -> int:
    var total := 0
    for i in iterations:
        total += i
    return total   # return value stored in thread

func _on_work_complete_button_pressed() -> void:
    if _thread.is_alive():
        print("Still working...")
        return
    var result: int = _thread.wait_to_finish()   # blocks until done, returns value
    print("Sum: ", result)
    _thread = Thread.new()   # reset for reuse
```

:::callout-warning[Always Call wait\_to\_finish()]
You

must

call

wait\_to\_finish()

before the Thread object is freed
  (e.g., in

\_exit\_tree()

or before restarting). Failing to do so leaks the OS thread
  and can cause crashes on exit.

```gdscript
func _exit_tree() -> void:
    if _thread.is_alive():
        _thread.wait_to_finish()
```
:::

### Mutex — Protecting Shared Data

When a background thread and the main thread both read/write the same variable, a
 **data race** occurs — the variable can be in an inconsistent state mid-write.
 A `Mutex` (mutual exclusion lock) ensures only one thread accesses the data at
 a time:

```gdscript
extends Node

var _mutex := Mutex.new()
var _shared_results: Array[int] = []
var _thread := Thread.new()

func _ready() -> void:
    _thread.start(_background_compute)

func _background_compute() -> void:
    for i in 1000:
        var val := i * i
        _mutex.lock()           # acquire lock
        _shared_results.append(val)
        _mutex.unlock()         # release lock

func _process(_delta: float) -> void:
    _mutex.lock()
    var count := _shared_results.size()
    _mutex.unlock()
    if count > 0:
        print("Results so far: ", count)
```

**Rule:** lock the mutex for the shortest time possible. Never call expensive
 functions inside a lock — you serialize the threads and gain nothing from parallelism.

#### RWLock — Multiple Readers, Single Writer

`RWLock` allows many threads to read simultaneously but only one to write.
 Use it when you have many readers and infrequent writes (e.g., a shared world state
 that all agents read but only the simulation thread updates):

```gdscript
var _rwlock := RWLock.new()
var _world_state: Dictionary = {}

## Called from many reader threads
func read_state(key: StringName) -> Variant:
    _rwlock.read_lock()
    var val := _world_state.get(key)
    _rwlock.read_unlock()
    return val

## Called only from the simulation thread
func update_state(key: StringName, value: Variant) -> void:
    _rwlock.write_lock()
    _world_state[key] = value
    _rwlock.write_unlock()
```

Mutex — protect shared data

Thread A

lock()

writes data ✓

unlock()

Thread B

lock() — BLOCKED

acquires lock

writes data ✓

Only one thread owns the lock at a time — no data races

Semaphore — signal work is ready

Producer thread

generates chunk

post() ← signals

Consumer thread

wait() — sleeping

wakes up

processes chunk ✓

Consumer sleeps for free — no busy-loop polling

**Mutex** prevents simultaneous access — Thread B blocks at `lock()` until A calls `unlock()`. **Semaphore** signals work availability — the consumer sleeps at `wait()` until the producer calls `post()`, wasting no CPU while idle.

### Semaphore — Signalling Between Threads

A `Semaphore` is a counter that threads can wait on. The classic use case is a
 *producer-consumer* pattern: the main thread posts work items; a worker thread blocks
 until one is ready.

```gdscript
## Chunk loader: main thread posts requests, background thread processes them
extends Node

var _semaphore   := Semaphore.new()
var _mutex       := Mutex.new()
var _exit_thread := false
var _queue: Array[Vector2i] = []
var _thread      := Thread.new()

func _ready() -> void:
    _thread.start(_worker_loop)

func request_chunk(coord: Vector2i) -> void:
    _mutex.lock()
    _queue.append(coord)
    _mutex.unlock()
    _semaphore.post()   # wake the worker

func _worker_loop() -> void:
    while true:
        _semaphore.wait()   # sleep until posted
        _mutex.lock()
        var should_exit := _exit_thread
        var coord: Vector2i = _queue.pop_front() if not _queue.is_empty() else Vector2i.ZERO
        _mutex.unlock()
        if should_exit: break
        _generate_chunk(coord)

func _exit_tree() -> void:
    _mutex.lock()
    _exit_thread = true
    _mutex.unlock()
    _semaphore.post()          # wake the worker so it can exit
    _thread.wait_to_finish()
```

## WorkerThreadPool

:::callout-intuition[Intuition]
Creating and destroying threads is expensive.

WorkerThreadPool

maintains a
  pool of reusable threads managed by the engine. You submit tasks and the pool distributes
  them across available cores automatically — much simpler than managing threads manually.
:::

### Submitting Single Tasks

```gdscript
## Fire-and-forget: submit a task, get a TaskID to check completion
var _task_id: int = -1

func start_pathfinding(from: Vector2, to: Vector2) -> void:
    _task_id = WorkerThreadPool.add_task(
        _compute_path.bind(from, to),
        true,                   # high_priority — skip the queue
        "PathfindingTask"       # debug label in profiler
    )

func _compute_path(from: Vector2, to: Vector2) -> void:
    # Pure computation — no scene tree access!
    var path := _astar.get_point_path(
        _astar.get_closest_point(from),
        _astar.get_closest_point(to)
    )
    # Send result to main thread
    call_deferred("_on_path_ready", path)

func _on_path_ready(path: PackedVector2Array) -> void:
    # Safe: called on main thread via call_deferred
    _agent.set_path(path)
```

Check if a task finished: `WorkerThreadPool.is_task_completed(task_id)`.
 Wait for it: `WorkerThreadPool.wait_for_task_completion(task_id)` (blocks main thread).

### Group Tasks — Parallel For

`add_group_task()` splits a large array into chunks and processes them in
 parallel across all available cores — like a parallel `for` loop:

```gdscript
## Simulate 10 000 particles in parallel
const PARTICLE_COUNT := 10_000
var _positions: PackedVector2Array
var _velocities: PackedVector2Array
var _group_task_id: int = -1

func _physics_process(delta: float) -> void:
    # Wait for previous frame's task to complete
    if _group_task_id >= 0:
        WorkerThreadPool.wait_for_group_task_completion(_group_task_id)

    # Launch parallel update for this frame
    _group_task_id = WorkerThreadPool.add_group_task(
        _update_particle.bind(delta),
        PARTICLE_COUNT,
        -1,                     # -1 = use all available threads
        true,                   # high_priority
        "ParticleGroupTask"
    )

## Called with index 0..PARTICLE_COUNT-1, each on a different thread
func _update_particle(index: int, delta: float) -> void:
    _positions[index] += _velocities[index] * delta
    # Boundary wrap, no scene API calls
```

:::callout-warning[Thread Safety in Group Tasks]
Each invocation of the group task callable receives a unique

index

. If each
  index writes to a different slot of a

PackedVector2Array

, no locking is needed —
  different threads write to different memory. If threads share state, you need a Mutex.
:::

## call\_deferred — Safe Main-Thread Callbacks

`call_deferred("method_name", args...)` queues a method call to execute on the
 main thread at the start of the next frame. It is the safe bridge from background threads
 back to scene tree operations:

```gdscript
## Background thread — safe pattern
func _background_work() -> void:
    var result := _expensive_pure_computation()

    # ✓ Safe: queues on main thread
    call_deferred("_apply_result", result)

    # ✗ Unsafe: scene API from background thread
    # $Label.text = str(result)   # DO NOT do this

## Main thread — receives the result next frame
func _apply_result(result: Dictionary) -> void:
    $Label.text = str(result.score)
    _spawn_effects(result.positions)
```

As an alternative, you can use a signal with `emit_signal` deferred, or write to
 a mutex-protected buffer and poll it in `_process()`:

```gdscript
## Polling pattern — main thread checks a shared queue each frame
var _result_mutex := Mutex.new()
var _result_queue: Array = []

func _process(_delta: float) -> void:
    _result_mutex.lock()
    var pending := _result_queue.duplicate()
    _result_queue.clear()
    _result_mutex.unlock()

    for result in pending:
        _apply_result(result)

## Background thread posts to the queue
func _background_work() -> void:
    var result := _compute()
    _result_mutex.lock()
    _result_queue.append(result)
    _result_mutex.unlock()
```

## Async Resource Loading

:::callout-intuition[Intuition]
Loading a large texture, audio file, or scene with

load()

blocks the main
  thread until done — causing a visible freeze or stutter.

ResourceLoader

's
  threaded API loads the resource in a background thread, letting your game keep running
  while you show a loading spinner or progress bar.
:::

### Threaded Load API

```gdscript
## AsyncLoader.gd — generic threaded resource loader
extends Node

signal resource_ready(path: String, resource: Resource)
signal load_progress(path: String, progress: float)

var _pending: Dictionary = {}   # path -> bool

func load_async(path: String) -> void:
    if path in _pending: return
    var err := ResourceLoader.load_threaded_request(path)
    if err != OK:
        push_error("AsyncLoader: failed to request '%s' (err %d)" % [path, err])
        return
    _pending[path] = true

func _process(_delta: float) -> void:
    for path in _pending.keys():
        var progress_arr: Array[float] = [0.0]
        var status := ResourceLoader.load_threaded_get_status(path, progress_arr)
        match status:
            ResourceLoader.THREAD_LOAD_IN_PROGRESS:
                load_progress.emit(path, progress_arr[0])
            ResourceLoader.THREAD_LOAD_LOADED:
                var res := ResourceLoader.load_threaded_get(path)
                _pending.erase(path)
                resource_ready.emit(path, res)
            ResourceLoader.THREAD_LOAD_FAILED:
                push_error("AsyncLoader: load failed for '%s'" % path)
                _pending.erase(path)
            ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
                push_error("AsyncLoader: invalid resource '%s'" % path)
                _pending.erase(path)
```

#### Usage Example — Loading a Level While Showing Progress

```gdscript
## LevelManager.gd
extends Node

@onready var loader := $AsyncLoader as AsyncLoader
@onready var progress_bar := $UI/ProgressBar as ProgressBar

func _ready() -> void:
    loader.resource_ready.connect(_on_level_ready)
    loader.load_progress.connect(_on_progress)
    loader.load_async("res://levels/world_2.tscn")

func _on_progress(path: String, pct: float) -> void:
    progress_bar.value = pct * 100.0

func _on_level_ready(path: String, resource: Resource) -> void:
    progress_bar.visible = false
    var level := (resource as PackedScene).instantiate()
    get_tree().root.add_child(level)
    get_tree().current_scene.queue_free()
    get_tree().current_scene = level
```

#### Preloading Resources for Level Transitions

Start the async load *before* the player needs the resource — e.g., begin loading
 World 2 when the player enters the final room of World 1:

```gdscript
## TriggerZone.gd — start loading next level on entry
extends Area2D

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        AsyncLoader.load_async("res://levels/world_2.tscn")
        # Player still has ~30 seconds to finish the room
        # Level will be ready long before they hit the door
```

:::callout-pitfall[Watch Out For]
- **Do not call `load_threaded_get()` until status is LOADED** — calling it while still in progress returns `null` and the load is cancelled.
- **load\_threaded\_request() is idempotent** — requesting the same path twice is safe; Godot de-duplicates internally.
- **PackedScene.instantiate() still runs on the main thread** — it's fast for most scenes, but a very large scene with complex `_ready()` callbacks may cause a small hitch. Spread instantiation across frames if needed.
:::

## Worked Examples

### Example 1 — Background Chunk Generator

**Goal:** Open-world game generates 64×64 tile chunks on demand. Each chunk
 takes ~25 ms to generate. Move generation off the main thread with a semaphore queue.

```gdscript
## ChunkManager.gd (autoload)
extends Node

const CHUNK_SIZE := 64

var _semaphore   := Semaphore.new()
var _mutex       := Mutex.new()
var _exit        := false
var _request_q: Array[Vector2i] = []
var _result_q: Array[Dictionary] = []
var _thread      := Thread.new()

func _ready() -> void:
    _thread.start(_worker)

func request_chunk(coord: Vector2i) -> void:
    _mutex.lock()
    if coord not in _request_q:
        _request_q.append(coord)
    _mutex.unlock()
    _semaphore.post()

func _worker() -> void:
    while true:
        _semaphore.wait()
        _mutex.lock()
        if _exit: _mutex.unlock(); break
        var coord: Vector2i = _request_q.pop_front() if not _request_q.is_empty() else Vector2i(-9999, -9999)
        _mutex.unlock()
        if coord == Vector2i(-9999, -9999): continue
        var data := _generate(coord)
        _mutex.lock()
        _result_q.append({ "coord": coord, "data": data })
        _mutex.unlock()

func _generate(coord: Vector2i) -> PackedByteArray:
    var result := PackedByteArray()
    result.resize(CHUNK_SIZE * CHUNK_SIZE)
    for i in result.size():
        result[i] = randi() % 4   # tile types 0-3
    return result

func _process(_delta: float) -> void:
    _mutex.lock()
    var ready := _result_q.duplicate()
    _result_q.clear()
    _mutex.unlock()
    for item in ready:
        _apply_chunk(item.coord, item.data)

func _apply_chunk(coord: Vector2i, data: PackedByteArray) -> void:
    # Main thread: safe to touch scene tree here
    var tilemap := get_tree().get_first_node_in_group("tilemap") as TileMap
    if tilemap == null: return
    for y in CHUNK_SIZE:
        for x in CHUNK_SIZE:
            var tile := data[y * CHUNK_SIZE + x]
            tilemap.set_cell(0, coord * CHUNK_SIZE + Vector2i(x, y), 0, Vector2i(tile, 0))

func _exit_tree() -> void:
    _mutex.lock(); _exit = true; _mutex.unlock()
    _semaphore.post()
    _thread.wait_to_finish()
```

### Example 2 — Parallel A\* for Multiple Agents

**Goal:** 32 agents each need a fresh A\* path every 0.5 s. Run all 32 path
 computations in parallel using WorkerThreadPool group tasks.

```gdscript
## ParallelPathfinder.gd
extends Node

var _agents: Array[Node2D] = []
var _target: Vector2
var _astar := AStarGrid2D.new()
var _paths: Array[PackedVector2Array]
var _group_task_id := -1

func _ready() -> void:
    _setup_astar()
    _paths.resize(32)
    $Timer.timeout.connect(_on_tick)

func _on_tick() -> void:
    if _group_task_id >= 0:
        WorkerThreadPool.wait_for_group_task_completion(_group_task_id)
        _apply_paths()
    _group_task_id = WorkerThreadPool.add_group_task(
        _compute_path_for_agent,
        _agents.size()
    )

func _compute_path_for_agent(index: int) -> void:
    # Each index runs on its own thread — no shared writes
    var from := _agents[index].global_position
    _paths[index] = _astar.get_point_path(
        _astar.get_closest_point(from),
        _astar.get_closest_point(_target)
    )

func _apply_paths() -> void:
    # Main thread: apply cached paths to agents
    for i in _agents.size():
        if i < _paths.size():
            _agents[i].set_path(_paths[i])
```

:::summary
### Chapter 62 — Quick Reference

| API | Use case | Key gotcha |
| --- | --- | --- |
| `Thread.start(callable)` | Single long background job | Must call `wait_to_finish()` before freeing |
| `Mutex.lock() / .unlock()` | Protect shared mutable state | Keep critical sections tiny |
| `RWLock` | Many readers, one writer | Reader starves writer if never unlocked |
| `Semaphore.post() / .wait()` | Producer-consumer signalling | Post once when exiting so worker can break |
| `WorkerThreadPool.add_task()` | Fire-and-forget background task | Check `is_task_completed()` before `wait_for_task_completion()` |
| `WorkerThreadPool.add_group_task()` | Parallel-for loop over large array | Each index must write to independent memory |
| `call_deferred()` | Return results to main thread safely | Only safe bridge from background → scene tree |
| `ResourceLoader.load_threaded_request()` | Start async asset load | Poll with `load_threaded_get_status()` before calling `load_threaded_get()` |
:::

## Practice Problems

:::problem{difficulty="easy"}
#### 1. Thread Safety Identification

Which of the following operations is safe to call from a background thread in Godot 4?
 (a) `$Label.text = "done"`,
 (b) `var x := 2 + 2`,
 (c) `get_tree().change_scene_to_file("res://menu.tscn")`,
 (d) `var path := _astar.get_point_path(a, b)`,
 (e) `call_deferred("_on_result", data)`.
 Explain why for each.

::::solution[Solution]
- **(a) Unsafe** — `$Label` is a node. Modifying node properties from a background thread causes data races and crashes.
- **(b) Safe** — pure arithmetic using local variables, no Godot API.
- **(c) Unsafe** — `get_tree()` accesses the SceneTree, which is main-thread-only.
- **(d) Safe (usually)** — `AStarGrid2D.get_point_path()` is a pure computation on an object. Safe *as long as* no other thread modifies the AStar object simultaneously. Use a Mutex if updates happen concurrently.
- **(e) Safe** — `call_deferred()` queues the call for the main thread. This is the correct pattern for posting results back.
::::
:::

:::problem{difficulty="easy"}
#### 2. Mutex-Protected Counter

Write a script that spawns 4 threads, each incrementing a shared integer
 `_counter` by 1 000 000 times. Use a Mutex to prevent data races.
 After all threads finish, print the final value (should be exactly 4 000 000).

::::solution[Solution]
```gdscript
extends Node

var _mutex   := Mutex.new()
var _counter := 0
var _threads: Array[Thread] = []

func _ready() -> void:
    for i in 4:
        var t := Thread.new()
        t.start(_worker)
        _threads.append(t)

func _worker() -> void:
    for j in 1_000_000:
        _mutex.lock()
        _counter += 1
        _mutex.unlock()

func _on_button_pressed() -> void:
    for t in _threads:
        t.wait_to_finish()
    print("Final count: ", _counter)   # should print 4000000
    _threads.clear()
```
::::
:::

:::problem{difficulty="standard"}
#### 3. WorkerThreadPool Single Task

Create an autoload `ProceduralGen` that generates a random 256×256 noise
 heightmap (a `PackedFloat32Array`) using `WorkerThreadPool.add_task()`.
 When done, emit a signal `heightmap_ready(data: PackedFloat32Array)` safely
 on the main thread.

::::solution[Solution]
```gdscript
## ProceduralGen.gd (autoload)
extends Node

signal heightmap_ready(data: PackedFloat32Array)

const SIZE := 256

func generate() -> void:
    WorkerThreadPool.add_task(_generate_heightmap, false, "HeightmapGen")

func _generate_heightmap() -> void:
    var noise := FastNoiseLite.new()
    noise.seed = randi()
    noise.frequency = 0.01
    var data := PackedFloat32Array()
    data.resize(SIZE * SIZE)
    for y in SIZE:
        for x in SIZE:
            data[y * SIZE + x] = noise.get_noise_2d(float(x), float(y))
    call_deferred("_emit_ready", data)

func _emit_ready(data: PackedFloat32Array) -> void:
    heightmap_ready.emit(data)
```
::::
:::

:::problem{difficulty="standard"}
#### 4. Async Scene Preload

Write a loading screen node that:
 (a) calls `ResourceLoader.load_threaded_request()` for a given scene path,
 (b) updates a `ProgressBar` each frame with the load percentage,
 (c) when loaded, instances the scene and swaps it as the current scene.

::::solution[Solution]
```gdscript
## LoadingScreen.gd
extends Control

@export var scene_to_load: String = "res://levels/world_1.tscn"
@onready var bar := $ProgressBar as ProgressBar
var _loading := false

func _ready() -> void:
    var err := ResourceLoader.load_threaded_request(scene_to_load)
    if err == OK:
        _loading = true
    else:
        push_error("Failed to request load: " + scene_to_load)

func _process(_delta: float) -> void:
    if not _loading: return
    var progress: Array[float] = [0.0]
    var status := ResourceLoader.load_threaded_get_status(scene_to_load, progress)
    bar.value = progress[0] * 100.0
    match status:
        ResourceLoader.THREAD_LOAD_LOADED:
            _loading = false
            var res := ResourceLoader.load_threaded_get(scene_to_load)
            var scene := (res as PackedScene).instantiate()
            get_tree().root.add_child(scene)
            get_tree().current_scene.queue_free()
            get_tree().current_scene = scene
        ResourceLoader.THREAD_LOAD_FAILED:
            push_error("Load failed: " + scene_to_load)
            _loading = false
```
::::
:::

:::problem{difficulty="challenge"}
#### 5. Semaphore Producer-Consumer

Implement a generic `BackgroundQueue` node that uses a Thread and Semaphore.
 It accepts `Callable` jobs from the main thread, processes them one at a time
 in the background, and delivers results via a `job_completed(result: Variant)`
 signal on the main thread. Include clean shutdown.

::::solution[Solution]
```gdscript
## BackgroundQueue.gd
class_name BackgroundQueue extends Node

signal job_completed(result: Variant)

var _semaphore := Semaphore.new()
var _mutex     := Mutex.new()
var _thread    := Thread.new()
var _jobs: Array[Callable] = []
var _results: Array       = []
var _exit      := false

func _ready() -> void:
    _thread.start(_worker)

func submit(job: Callable) -> void:
    _mutex.lock()
    _jobs.append(job)
    _mutex.unlock()
    _semaphore.post()

func _worker() -> void:
    while true:
        _semaphore.wait()
        _mutex.lock()
        var should_exit := _exit
        var job: Callable = _jobs.pop_front() if not _jobs.is_empty() else Callable()
        _mutex.unlock()
        if should_exit: break
        if not job.is_null():
            var result: Variant = job.call()
            _mutex.lock()
            _results.append(result)
            _mutex.unlock()

func _process(_delta: float) -> void:
    _mutex.lock()
    var ready := _results.duplicate()
    _results.clear()
    _mutex.unlock()
    for r in ready:
        job_completed.emit(r)

func _exit_tree() -> void:
    _mutex.lock(); _exit = true; _mutex.unlock()
    _semaphore.post()
    _thread.wait_to_finish()
```

Usage: `queue.submit(func(): return expensive_compute())`. Connect to `job_completed` to receive results.
::::
:::
