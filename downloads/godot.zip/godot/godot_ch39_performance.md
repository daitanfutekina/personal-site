---
title: "Performance & Profiling"
source: "godot_ch39_performance.html"
---

Part IV · Chapter 39

# Performance & Profiling

Prerequisite: Ch 26 (Object Pools), Ch 3 (GDScript basics) · est. 80 min

## Overview

A game that drops to 20 fps on target hardware will be rejected no
 matter how good it looks. Performance work follows one rule above all
 others: **measure before you optimise**. Gut-feeling
 micro-optimisations waste time; a five-minute profiling session tells
 you exactly where the milliseconds are going.

This chapter gives you a complete profiling workflow for Godot 4 and
 a catalogue of the most impactful optimisation techniques:

- Reading the built-in Profiler tab and Monitor graphs
- Querying runtime counters with the `Performance`
 singleton
- GDScript-level optimisations — typed variables, avoiding hotspot
 patterns, caching `@onready` lookups
- Rendering bottlenecks — draw calls, visibility culling, LOD
- Physics optimisation — collision layers, body sleep, convex hulls
- Memory management — resource sharing, scene streaming
- Registering custom performance monitors visible in the graph

## 1 · The Godot Profiler

### Debugger → Profiler tab

The built-in profiler is the fastest way to find script bottlenecks.
 Open it with F8 or via
 *Debug → Debugger → Profiler* while the game is running.
 Click **Start** to begin recording; the profiler then
 samples every GDScript call every frame.

The flame chart shows a bar per frame. Click any bar to see the
 function breakdown for that frame. The columns that matter most:

| Column | What it measures |
| --- | --- |
| Self time | Time spent *inside* this function, excluding callees |
| Total time | Self time + all descendant call times |
| Calls | Number of times this function was called in the selected frame |
| Internal | Time spent in native (C++) engine code called by this function |

:::callout-tip[Tip]
Sort by *Self time* to find functions that are slow on their
 own. Sort by *Calls* to find functions called far more than
 expected — a `find_child()` called 10 000 times per frame
 shows up immediately.
:::

### Monitor graphs

The *Debugger → Monitors* tab shows continuous real-time
 graphs for dozens of engine metrics. The most useful ones to watch
 simultaneously:

- **FPS** — frames per second. Look for sustained dips,
 not just spikes.
- **Process time** — total `_process` budget
 consumed in ms.
- **Physics time** — total `_physics_process`
 budget in ms.
- **Draw calls 2D / 3D** — GPU submission count.
 High counts indicate batching opportunities.
- **Video memory used** — total GPU RAM in use. Growing
 over time suggests resource leaks.
- **Object count** — total live `Object`
 instances. Useful for hunting object-pool leaks.

### Performance singleton

You can query any monitor value from GDScript at runtime using the
 `Performance` singleton. This lets you display stats in
 an in-game HUD or write them to a log file:

```gdscript
func _process(_delta: float) -> void:
    var fps        := Performance.get_monitor(Performance.TIME_FPS)
    var draw_calls := Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
    var mem_static := Performance.get_monitor(Performance.MEMORY_STATIC)
    var obj_count  := Performance.get_monitor(Performance.OBJECT_COUNT)

    $Label.text = "FPS: %d  Draws: %d  Mem: %.1f MB  Objs: %d" % [
        fps, draw_calls, mem_static / 1_048_576.0, obj_count
    ]
```

All monitor constants live in the `Performance` class.
 Common ones:

| Constant | Unit |
| --- | --- |
| `TIME_FPS` | frames / second |
| `TIME_PROCESS` | seconds |
| `TIME_PHYSICS_PROCESS` | seconds |
| `MEMORY_STATIC` | bytes |
| `MEMORY_STATIC_MAX` | bytes (peak) |
| `OBJECT_COUNT` | count |
| `OBJECT_NODE_COUNT` | count |
| `RENDER_TOTAL_DRAW_CALLS_IN_FRAME` | count |
| `RENDER_VIDEO_MEM_USED` | bytes |
| `PHYSICS_3D_ACTIVE_OBJECTS` | count |

## 2 · Script Bottlenecks

### Typed variables — free performance

GDScript performs type inference when you annotate variables. The
 interpreter can skip runtime variant-type checks when it already
 knows the type at parse time. Always use typed declarations in
 performance-sensitive code:

```gdscript
# Slow — every operation checks Variant type at runtime
var speed = 300.0
var direction = Vector2.RIGHT
var result = direction * speed   # Variant * Variant

# Fast — types known at parse time
var speed: float = 300.0
var direction: Vector2 = Vector2.RIGHT
var result: Vector2 = direction * speed
```

The improvement is modest for one operation but compounds quickly
 inside `_process` loops that run thousands of times per
 second.

GDScript Hot-Path Pitfalls — Before vs. After

SLOW ✗

FAST ✓

func \_process(delta):

get\_node("HUD/Label").text = str(score)  # tree walk every frame!

@onready var \_label = $HUD/Label  # cached once

func \_process(delta):  \_label.text = str(score)

func \_process(delta):

var v = Vector2(x, y)  # allocation inside hot loop!

var \_v := Vector2.ZERO  # reuse pre-allocated

func \_process(delta):  \_v.x = x; \_v.y = y

var speed = 200      # untyped — VM checks type every use

func move():  position.x += speed \* delta

var speed: float = 200.0   # typed — direct float ops

func move():  position.x += speed \* delta

Three of the most common GDScript hot-path mistakes: tree lookups in `_process()`, heap allocations inside tight loops, and untyped variables. Each costs essentially nothing to fix and can recover several milliseconds per frame.

### Common slow patterns

**get\_node() inside \_process()** traverses the scene tree
 on every call. Cache the reference in `@onready`:

```gdscript
# Slow — tree lookup every frame
func _process(delta: float) -> void:
    get_node("HUD/Label").text = str(score)

# Fast — resolved once at _ready()
@onready var _label: Label = $HUD/Label

func _process(delta: float) -> void:
    _label.text = str(score)
```

**String concatenation in loops** allocates a new string
 object for every `+` call. Use format strings or
 `String.join()`:

```gdscript
# Slow — O(n²) allocations
var result := ""
for line in lines:
    result += line + "\n"

# Fast — single join at the end
var result := "\n".join(lines)
```

**Array.find() / has() in hot loops** scans linearly.
 Use a `Dictionary` as a set for O(1) lookups:

```gdscript
# Slow — O(n) every call
if active_ids.has(entity_id): ...

# Fast — O(1) average
var active_set: Dictionary = {}
active_set[entity_id] = true
if entity_id in active_set: ...
```

**Unnecessary \_process callbacks.** Every node with
 `_process` defined is ticked every frame regardless of
 whether it needs it. Disable processing when idle:

```gdscript
func set_active(active: bool) -> void:
    set_process(active)
    set_physics_process(active)
```

### Caching and batching scene queries

If you must call `get_nodes_in_group` or
 `find_children`, do it once and cache the result.
 Rebuild the cache only when the scene changes (connect to
 `child_entered_tree` / `child_exiting_tree`):

```gdscript
var _enemies: Array[Enemy] = []

func _ready() -> void:
    _rebuild_enemy_cache()
    child_entered_tree.connect(_on_child_changed)
    child_exiting_tree.connect(_on_child_changed)

func _on_child_changed(_node: Node) -> void:
    _rebuild_enemy_cache.call_deferred()

func _rebuild_enemy_cache() -> void:
    _enemies = []
    for child in get_children():
        if child is Enemy:
            _enemies.append(child)
```

:::callout-intuition[Intuition]
The profiler's *Self time* column is your compass. If a
 function's self time is high, look inside that function. If its
 total time is high but self time is low, the bottleneck is in
 something it calls. Drill down layer by layer; rarely is the fix
 more than two or three levels deep.
:::

## 3 · Rendering Performance

### Draw calls and batching

Each draw call is a round-trip command to the GPU. On mobile and
 mid-range desktops, keeping draw calls below 500 per frame is a
 practical target. Godot batches 2D draw calls automatically when
 sprites share the same texture and are drawn consecutively in the
 scene tree — this is the primary reason to use sprite sheets (texture
 atlases).

Key rules for low draw calls:

- Pack sprites from the same layer into a single texture atlas.
 Use the built-in *Import → Compress → Atlas* or a tool
 like TexturePacker.
- Keep nodes that share a material adjacent in the scene tree.
 A node with a different material between them breaks the batch.
- Use `MultiMeshInstance2D` / `MultiMeshInstance3D`
 for large numbers of identical objects (trees, grass, coins).
 Thousands of instances can be drawn in a single call.
- Avoid changing `CanvasItem.modulate` per-node if you
 can encode the tint in the shader or the atlas instead.

```gdscript
# MultiMesh example — 10 000 coins, one draw call
@onready var _mm: MultiMeshInstance2D = $CoinMesh

func spawn_coins(positions: Array[Vector2]) -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_2D
    mm.instance_count = positions.size()
    mm.mesh = preload("res://coin.tres")
    for i in positions.size():
        var xform := Transform2D(0.0, positions[i])
        mm.set_instance_transform_2d(i, xform)
    _mm.multimesh = mm
```

### Visibility and culling

Godot performs automatic frustum culling — objects outside the camera
 view are not submitted for rendering. You can help the engine by:

- Setting **Visibility AABB** on
 `GeometryInstance3D` nodes so the engine knows the
 exact bounding box.
- Using `VisibleOnScreenNotifier2D` /
 `VisibleOnScreenNotifier3D` to pause expensive logic on
 off-screen entities:

  ```gdscript
  @onready var _vis: VisibleOnScreenNotifier2D = $Vis

  func _ready() -> void:
      _vis.screen_entered.connect(func(): set_process(true))
      _vis.screen_exited.connect(func(): set_process(false))
  ```

- Adding `OccluderInstance3D` nodes to large opaque
 walls so the renderer can skip objects hidden behind them
 (occlusion culling).

### LOD and GeometryInstance3D

Level of Detail (LOD) swaps high-poly meshes for simpler ones when
 the camera is far away. In Godot 4, set LOD properties directly on
 `GeometryInstance3D`:

| Property | Effect |
| --- | --- |
| `lod_bias` | Multiplier on the distance thresholds. >1 = switch to lower LOD sooner; <1 = keep high LOD longer |
| `visibility_range_begin` | Distance at which the instance starts to appear (fades in) |
| `visibility_range_end` | Distance at which the instance disappears (culled) |
| `visibility_range_fade_mode` | DISABLED, SELF (fades this instance), DEPENDENCIES (fades parent) |

For 3D meshes, enable automatic LOD generation in the import settings:
 *Import → Meshes → Generate LODs*. Godot generates 3–4 LOD
 levels automatically during import.

:::callout-connect[Connect]
LOD and visibility ranges work in conjunction with the
 `Camera3D` far-clip plane. Set a reasonable far-clip
 (1000–2000 m for most games) so the depth buffer precision is
 not wasted on geometry kilometres away.
:::

## 4 · Physics Optimisation

### Collision layers and masks

Godot's physics broadphase computes collision tests between every
 pair of bodies that share at least one layer/mask bit. Narrowing
 this down is the single most effective physics optimisation:

```gdscript
# In _ready or via the inspector:
# Layer bits: 1 = Player, 2 = Enemy, 4 = Wall, 8 = Pickup

# Player: on layer 1, detects walls (4) and pickups (8)
$Player.collision_layer = 1
$Player.collision_mask  = 4 | 8

# Enemy: on layer 2, detects walls (4) and player (1)
$Enemy.collision_layer  = 2
$Enemy.collision_mask   = 4 | 1

# Pickups only detect the player
$Pickup.collision_layer = 8
$Pickup.collision_mask  = 1
```

With this setup, enemies and pickups never test against each other.
 The broadphase pair count drops quadratically with careful layer
 assignment.

### Body sleep (deactivation)

`RigidBody3D` and `RigidBody2D` support
 automatic sleeping — when a body's velocity falls below a threshold
 for several frames it is deactivated and skipped by the solver.
 Ensure sleep is enabled (it is by default) and avoid continuously
 applying tiny forces that prevent sleep:

```gdscript
# Check if a body is sleeping
if rigid_body.sleeping:
    pass  # no solver overhead this frame

# Wake a sleeping body when needed
rigid_body.apply_impulse(Vector3.UP * 5.0)
# The engine wakes it automatically when an impulse is applied

# Prevent sleep for a specific body (use sparingly)
rigid_body.can_sleep = false
```

### Simplified collision shapes

Complex mesh-based collision is expensive. Use the simplest shape
 that approximates the visual mesh:

| Shape | Cost | Use for |
| --- | --- | --- |
| `SphereShape3D` | Lowest | Projectiles, rolling objects |
| `CapsuleShape3D` | Very low | Character controllers |
| `BoxShape3D` | Low | Crates, platforms |
| `ConvexPolygonShape3D` | Medium | Irregular props (auto-generated) |
| `ConcavePolygonShape3D` | High (static only) | Terrain, level geometry (StaticBody only) |

:::callout-pitfall[Pitfall]
`ConcavePolygonShape3D` cannot be used on
 `RigidBody3D` — only on `StaticBody3D`. The
 engine will print an error and ignore the shape at runtime if you
 attach it to a rigid body.
:::

To generate convex collision from a mesh in the editor, select the
 `MeshInstance3D` → *Mesh* menu →
 *Create Convex Collision Sibling* (for convex approximation) or
 *Create Trimesh Static Body* (for exact, static-only
 concave collision).

## 5 · Memory & Resources

### Resource sharing

In Godot, `preload()` and `load()` return the
 *same* resource object when called with the same path —
 Godot caches resources by path. This means all nodes sharing a
 material or mesh automatically share the same memory, for free.

The trap is `duplicate()`. When you call
 `material.duplicate()` to get a per-instance copy, that
 copy is not cached and not shared. Only duplicate when you truly
 need per-instance state (e.g. a shader uniform that differs per
 enemy):

```gdscript
func _ready() -> void:
    # ✓ Shared — all SlimeEnemy instances share one material
    # (unless you called duplicate() elsewhere)
    var mat: ShaderMaterial = $Sprite2D.material

    # ✓ Correct per-instance duplicate (see Ch 32)
    _mat = mat.duplicate()
    $Sprite2D.material = _mat
    _mat.set_shader_parameter("color", _my_color)
```

To audit resource memory use, open
 *Debug → Resource Monitor* (available during a running game
 in the editor) and sort by memory. Textures are almost always the
 top consumer; ensure large textures use compressed import presets
 (*Import → Compress → Basis Universal* for colour maps,
 *RGTC* for normal maps).

### Streaming large worlds

Open-world games cannot keep every scene loaded at once. The standard
 Godot pattern is a **world manager** that loads and
 unloads chunks asynchronously using
 `ResourceLoader.load_threaded_request()`:

```gdscript
class_name WorldManager extends Node

const CHUNK_RADIUS := 2   # load chunks this many steps around the player

var _loaded_chunks: Dictionary = {}   # chunk_key -> Node

func update_chunks(player_chunk: Vector2i) -> void:
    var needed: Dictionary = {}
    for dx in range(-CHUNK_RADIUS, CHUNK_RADIUS + 1):
        for dy in range(-CHUNK_RADIUS, CHUNK_RADIUS + 1):
            needed[player_chunk + Vector2i(dx, dy)] = true

    # Unload distant chunks
    for key in _loaded_chunks.keys():
        if not key in needed:
            _loaded_chunks[key].queue_free()
            _loaded_chunks.erase(key)

    # Request missing chunks
    for key in needed:
        if not key in _loaded_chunks:
            _request_chunk(key)

func _request_chunk(key: Vector2i) -> void:
    var path := "res://world/chunk_%d_%d.tscn" % [key.x, key.y]
    ResourceLoader.load_threaded_request(path)
    # Poll in _process or use a timer to check status:
    # ResourceLoader.load_threaded_get_status(path)

func _finish_chunk(key: Vector2i, scene: PackedScene) -> void:
    var chunk: Node = scene.instantiate()
    add_child(chunk)
    chunk.position = Vector3(key.x * CHUNK_SIZE, 0, key.y * CHUNK_SIZE)
    _loaded_chunks[key] = chunk
```

:::callout-warning[Warning]
`load()` blocks the main thread. For large scenes always
 use `ResourceLoader.load_threaded_request()` and poll
 status with `load_threaded_get_status()`. A blocking
 load mid-game causes a visible stutter that no framerate counter
 can hide.
:::

## 6 · Custom Performance Monitors

You can add your own counters to the Monitors graph using
 `Performance.add_custom_monitor()`. This is invaluable
 for game-specific stats (enemy count, active projectiles, AI
 decisions per second) that no built-in monitor tracks.

```gdscript
extends Node

var _projectile_count: int = 0
var _ai_decisions_this_second: int = 0
var _ai_decision_timer: float = 0.0

func _ready() -> void:
    # Register custom monitors — visible in Debugger → Monitors
    Performance.add_custom_monitor(
        "Game/ActiveProjectiles",
        _get_projectile_count          # callable — Godot polls this each frame
    )
    Performance.add_custom_monitor(
        "Game/AIDecisionsPerSec",
        _get_ai_dps
    )

func _get_projectile_count() -> int:
    return _projectile_count

func _get_ai_dps() -> float:
    return _ai_decisions_this_second / maxf(_ai_decision_timer, 0.001)

func _process(delta: float) -> void:
    _ai_decision_timer += delta
    if _ai_decision_timer >= 1.0:
        _ai_decisions_this_second = 0
        _ai_decision_timer = 0.0

func record_ai_decision() -> void:
    _ai_decisions_this_second += 1
```

Custom monitors appear under the name you supply (here
 `Game/ActiveProjectiles` and
 `Game/AIDecisionsPerSec`) in the Monitors dropdown,
 grouped by the prefix before the slash. Tick them on to add a
 coloured graph line alongside the built-in counters.

:::callout-key[Key concept]
The callable you pass to `add_custom_monitor` is called
 by the engine once per editor refresh (not every game frame). It
 must return a value castable to a `float`. Returning
 an `int` works fine — Godot converts it automatically.
:::

To remove a monitor when it is no longer needed:

```gdscript
func _exit_tree() -> void:
    if Performance.has_custom_monitor("Game/ActiveProjectiles"):
        Performance.remove_custom_monitor("Game/ActiveProjectiles")
    if Performance.has_custom_monitor("Game/AIDecisionsPerSec"):
        Performance.remove_custom_monitor("Game/AIDecisionsPerSec")
```

## Summary

The performance workflow is always the same: profile, identify the
 real bottleneck, fix one thing, profile again. Quick reference:

| Area | First thing to try |
| --- | --- |
| Script CPU | Type all variables; cache `@onready` lookups; disable idle `_process` |
| Rendering draw calls | Use texture atlases; batch consecutive same-material sprites; `MultiMeshInstance2D` for duplicates |
| Off-screen waste | `VisibleOnScreenNotifier2D` / `VisibleOnScreenNotifier3D` to pause logic; `OccluderInstance3D` for large walls |
| 3D polygon count | Enable LOD generation on import; set `visibility_range_end` |
| Physics broadphase | Assign tight collision layers/masks; verify body sleep is enabled |
| Physics narrowphase | Replace mesh shapes with spheres/capsules/boxes; convex hull for props |
| Memory / stutter | Use `load_threaded_request`; share resources instead of duplicating; compress textures on import |
| Monitoring | `Performance.add_custom_monitor` for game-specific counters |

## Mixed Practice

:::problem{difficulty="easy"}
**1. Profiler columns.**
 The profiler shows a function `_process` with
 self time 0.1 ms, total time 4.2 ms, and calls 1. What does
 this tell you, and where should you look next?

::::solution[Solution]
**Solution:**
 `_process` itself does very little work (0.1 ms).
 The remaining 4.1 ms (total − self) is spent inside the
 functions it calls. You should expand the profiler row for
 `_process` to see its callees, then sort by
 *total time* to find the most expensive one. The fix
 will be in a callee, not in `_process` itself.
::::
:::

:::problem{difficulty="easy"}
**2. Fix the hotspot.**
 A student's HUD script reads:

```gdscript
func _process(delta: float) -> void:
    get_node("VBox/HealthBar").value = get_node("../Player").health
    get_node("VBox/AmmoLabel").text  = str(get_node("../Player").ammo)
```

Identify every performance problem and rewrite it correctly.

::::solution[Solution]
```gdscript
@onready var _health_bar:  ProgressBar = $VBox/HealthBar
@onready var _ammo_label:  Label       = $VBox/AmmoLabel
@onready var _player:      Player      = get_parent()    # or $"../Player"

func _process(_delta: float) -> void:
    _health_bar.value    = _player.health
    _ammo_label.text     = str(_player.ammo)
```

**Problems fixed:**
 (1) Three `get_node()` calls per frame replaced by
 three `@onready` cache lookups resolved once.
 (2) Untyped nodes replaced with typed declarations so the
 compiler knows the types.
 (3) `delta` parameter unused — renamed to
 `_delta` to silence the warning.
::::
:::

:::problem{difficulty="standard"}
**3. MultiMesh grass.**
 A level has 50 000 identical grass blades stored as individual
 `Sprite2D` nodes. The draw-call count is
 50 000. Outline the steps to collapse this to one draw call
 using `MultiMeshInstance2D`, and write the GDScript
 that populates it from an array of
 `Vector2` positions.

::::solution[Solution]
**Steps:**

1. Remove the 50 000 `Sprite2D` nodes from the
 scene.
2. Add a single `MultiMeshInstance2D` node, assign
 the grass `Mesh` (a `QuadMesh` or
 exported sprite mesh) and the grass
 `Texture`.
3. Create and populate the `MultiMesh` resource
 at runtime.

```gdscript
@onready var _mmi: MultiMeshInstance2D = $GrassLayer

func spawn_grass(positions: Array[Vector2]) -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_2D
    mm.mesh = preload("res://grass_mesh.tres")
    mm.instance_count = positions.size()

    for i in positions.size():
        var angle := randf() * TAU
        var xform  := Transform2D(angle, positions[i])
        mm.set_instance_transform_2d(i, xform)

    _mmi.multimesh = mm
```

Result: 50 000 grass blades rendered in a single GPU draw call.
::::
:::

:::problem{difficulty="standard"}
**4. Custom monitor for active enemies.**
 Write an `EnemyManager` autoload that keeps track of
 how many `Enemy` nodes are active, and registers a
 custom performance monitor `"Game/EnemyCount"` so
 the count appears in the Monitors graph. The manager should
 expose `register()` and `unregister()`
 methods that enemies call from their `_ready` and
 `_exit_tree`.

::::solution[Solution]
```gdscript
# enemy_manager.gd — registered as autoload "EnemyManager"
extends Node

var _count: int = 0

func _ready() -> void:
    Performance.add_custom_monitor("Game/EnemyCount", _get_count)

func _exit_tree() -> void:
    if Performance.has_custom_monitor("Game/EnemyCount"):
        Performance.remove_custom_monitor("Game/EnemyCount")

func _get_count() -> int:
    return _count

func register() -> void:
    _count += 1

func unregister() -> void:
    _count = max(0, _count - 1)

# In enemy.gd:
# func _ready():      EnemyManager.register()
# func _exit_tree():  EnemyManager.unregister()
```
::::
:::

:::problem{difficulty="challenge"}
**5. Thread-safe chunk loader.**
 Extend the `WorldManager` from Section 5 to
 correctly poll `ResourceLoader.load_threaded_get_status()`
 every frame and instantiate chunks only when status is
 `THREAD_LOAD_LOADED`. Handle the
 `THREAD_LOAD_FAILED` case by printing an error and
 removing the key from a pending set. Write the complete
 `_process` implementation.

::::solution[Solution]
```gdscript
extends Node

const CHUNK_SIZE := 128.0

var _loaded_chunks: Dictionary  = {}   # Vector2i -> Node
var _pending_paths: Dictionary  = {}   # path: String -> key: Vector2i

func _request_chunk(key: Vector2i) -> void:
    var path := "res://world/chunk_%d_%d.tscn" % [key.x, key.y]
    if path in _pending_paths.values():
        return   # already requested
    ResourceLoader.load_threaded_request(path)
    _pending_paths[path] = key

func _process(_delta: float) -> void:
    var done: Array[String] = []

    for path in _pending_paths:
        var progress: Array = []
        var status := ResourceLoader.load_threaded_get_status(path, progress)

        match status:
            ResourceLoader.THREAD_LOAD_LOADED:
                var scene: PackedScene = ResourceLoader.load_threaded_get(path)
                var key: Vector2i = _pending_paths[path]
                _finish_chunk(key, scene)
                done.append(path)

            ResourceLoader.THREAD_LOAD_FAILED:
                push_error("Chunk load failed: " + path)
                done.append(path)

            _:
                pass   # IN_PROGRESS or INVALID_RESOURCE — keep waiting

    for path in done:
        _pending_paths.erase(path)

func _finish_chunk(key: Vector2i, scene: PackedScene) -> void:
    var chunk := scene.instantiate()
    add_child(chunk)
    chunk.position = Vector3(key.x * CHUNK_SIZE, 0.0, key.y * CHUNK_SIZE)
    _loaded_chunks[key] = chunk
```
::::
:::

:::problem{difficulty="challenge"}
**6. Performance audit checklist.**
 Your 3D game runs at 28 fps on the target device. The profiler
 shows: script self-time 0.3 ms total, render thread 22 ms,
 physics 4 ms, idle 6 ms. The monitor graph shows 2 400 draw
 calls per frame and 180 active physics bodies.
 Propose a prioritised three-step optimisation plan, explaining
 which area to attack first and which specific Godot tools or
 techniques address each step.

::::solution[Solution]
**Analysis:**
 The render thread is consuming 22 ms of a ~33 ms budget
 (30 fps) — this is the dominant bottleneck. Physics at 4 ms
 and idle at 6 ms are secondary. Script at 0.3 ms is
 negligible.

**Step 1 — Rendering (highest impact):**
 2 400 draw calls is very high for a mobile target (aim for
 <500). Actions:
 (a) Open Monitors and confirm draw calls are the issue, not
 overdraw or shader cost.
 (b) Pack scene meshes/sprites onto texture atlases.
 (c) Replace repeated props (trees, rocks) with
 `MultiMeshInstance3D`.
 (d) Enable mesh LOD generation on import for all environment
 meshes.
 (e) Add `OccluderInstance3D` to large walls.
 Expected improvement: 2 400 → 200–400 draw calls,
 22 ms → 8–12 ms render thread.

**Step 2 — Physics (secondary):**
 180 active rigid bodies is workable but worth reviewing.
 Actions:
 (a) Check collision layer/mask assignments — ensure distant
 bodies don't test against each other.
 (b) Verify all idle bodies have sleep enabled.
 (c) Replace any mesh collision shapes with
 convex-hull approximations.
 Expected improvement: 4 ms → 1–2 ms.

**Step 3 — Idle (tertiary):**
 6 ms idle suggests waiting for something (I/O or a deferred
 call). Profile the idle category specifically; if it is
 chunk loading, switch to `load_threaded_request`
 to move I/O off the main thread.
::::
:::
