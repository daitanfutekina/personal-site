---
title: "VFX Cookbook — Dissolve, Outline, Water, Fire, Hit-Flash & Glow"
source: "godot_ch55_vfx_cookbook.html"
---

Part VIII · Chapter 55

Capstone

# VFX Cookbook — Dissolve, Outline, Water, Fire, Hit-Flash & Glow

Estimated study time: 110 min · Prerequisites: Ch 51 2D Canvas Shaders, Ch 52 Spatial 3D Shaders, Ch 54 Particle Shaders (helpful)

## Chapter Overview

This is the shader capstone for Part VIII. Rather than teaching new fundamentals, it presents a library of production-ready visual effects — each with a complete shader, GDScript trigger code, and explanation of the key technique. Copy, paste, and adapt.

Every recipe follows the same structure: *what it looks like → how it works → full code → GDScript integration → variations*. Most effects are 20–50 lines of shader code.

:::callout-key[Part VIII complete after this chapter]
After this chapter you will have covered: GDShader fundamentals, 2D canvas shaders, 3D spatial shaders, VisualShader node graphs, GPU particle process shaders, and a full VFX recipe library. Part IX moves to AI and architecture patterns.
:::

## How to Use This Cookbook

Each recipe is a self-contained unit. Set up the recipe as follows:

1. Create (or select) a **ShaderMaterial** on the target node.
2. Click the Material's Shader slot → *New Shader* → paste the shader code.
3. Set any uniforms from the Inspector or via `mat.set_shader_parameter("name", value)` in GDScript.
4. For effects that need a trigger (hit flash, dissolve), call the provided GDScript function.

:::callout-tip[Shader types reminder]
2D sprite/UI effects use

shader\_type canvas\_item;

. 3D mesh effects use

shader\_type spatial;

. Full-screen post-process effects use

shader\_type canvas\_item;

on a

ColorRect

that fills the viewport, or use a

CompositorEffect

(Godot 4.3+).
:::

Chapter 55 — VFX Recipe Map

Recipe 1 — Dissolve

noise texture + threshold + burn edge

canvas\_item / spatial

Recipe 2 — Outline

UV offset sampling + vertex inflate

2D sprite / 3D mesh

Recipe 3 — Water

sine wave + refraction distortion

2D surface / 3D ocean

Recipe 4 — Fire/Lava

FBM noise + palette lookup

procedural, no texture needed

Recipe 5 — Hit Flash

modulate white + tween fade

GDScript + canvas\_item

Recipe 6 — Glow/CRT

emission pulse + scanlines

Environment + ColorRect

Recipe 7 — Hologram

scanline + flicker + refraction

spatial shader

Recipe 8 — Shockwave

UV radial distortion + TIME ring

fullscreen ColorRect

Recipe 9 — Pixelate

floor(UV \* N) / N quantise

canvas\_item / post-process

Nine drop-in shader recipes. Each is self-contained — paste the code into a new Shader resource, wire the uniforms, and it works. Most are under 40 lines.

## Recipe 1 — Dissolve / Burn Effect

Almost every shader effect in this chapter is built from one idea, and the dissolve
is the clearest place to meet it: **compare a texture against a moving number, and
use the comparison as a mask**. The noise texture supplies a value at every pixel;
`dissolve_amount` is a threshold sweeping from 0 to 1; and
`step()` turns that comparison into a hard 0 or 1 you can multiply things by.

The two masks are the whole effect. `dissolve_mask` is 1 wherever the noise
is above the threshold — the part of the sprite still present. The edge mask is the
difference between two thresholds, one slightly behind the other, which leaves a thin band
that follows the boundary as it moves: subtracting one step from another is how you get a
*ring* rather than a disc, and the trick is worth remembering because it recurs
everywhere.

Then it is bookkeeping. The colour is blended towards the burn colour inside that band,
and the alpha is multiplied by the mask so everything past the boundary disappears. The
noise texture chooses the character of the effect entirely: cloudy Perlin gives an organic
burn, sharp Voronoi gives a shattering one, and a radial gradient gives a clean wipe from
the centre.

#### Noise-Based Dissolve with Burn Edge

canvas\_item or spatial — 2D or 3D — Complexity: low

Compares a noise texture to a threshold. Below threshold → fully transparent. Near threshold → burn colour. Above threshold → normal sprite.

```glsl
shader_type canvas_item;

uniform sampler2D noise_tex : hint_default_white;
uniform float dissolve_amount : hint_range(0.0, 1.0) = 0.0;
uniform float edge_width : hint_range(0.0, 0.2) = 0.05;
uniform vec4 burn_color : source_color = vec4(1.0, 0.4, 0.0, 1.0);

void fragment() {
    vec4 base = texture(TEXTURE, UV);
    float noise = texture(noise_tex, UV).r;

    // Compute masks
    float dissolve_mask = step(dissolve_amount, noise);
    float edge_mask     = step(dissolve_amount - edge_width, noise) - dissolve_mask;

    // Apply: burn colour at the edge, transparent behind, sprite in front
    vec4 col = base;
    col.rgb = mix(col.rgb, burn_color.rgb, edge_mask);
    col.a   = col.a * dissolve_mask + edge_mask * burn_color.a;
    COLOR   = col;
}
```

#### GDScript Trigger (Tween)

```gdscript
func dissolve_out(duration := 1.0) -> void:
    var mat: ShaderMaterial = material
    var tw := create_tween()
    tw.tween_method(
        func(v): mat.set_shader_parameter("dissolve_amount", v),
        0.0, 1.0, duration
    ).set_trans(Tween.TRANS_SINE)

func dissolve_in(duration := 1.0) -> void:
    var mat: ShaderMaterial = material
    var tw := create_tween()
    tw.tween_method(
        func(v): mat.set_shader_parameter("dissolve_amount", v),
        1.0, 0.0, duration
    )
```

**Variations:** Use a gradient noise for smooth edges. Use a radial gradient as the noise for a "burn from centre" effect. For 3D, change `shader_type spatial;` and write to `ALBEDO` / `ALPHA` with `render_mode blend_mix;`.

## Recipe 2 — Thick Outline

An outline shader has to answer a question the sprite itself cannot: “is this
transparent pixel *next to* an opaque one?” A shader sees one pixel at a time
and has no notion of neighbours, so the only way to ask is to sample the texture again at
an offset — which is exactly what the eight lookups do.

`TEXTURE_PIXEL_SIZE` is what makes those offsets meaningful. It is one
texel expressed in UV units, so multiplying it by the desired width gives an offset that
means the same thing whatever the sprite's resolution. Offsetting by a raw number instead
would give a thick outline on a small sprite and a hairline on a large one.

Eight samples is a deliberate compromise. Four would miss the diagonals and leave
notched corners; a real distance field would be smooth at any width but needs preprocessing.
Eight is the cheapest thing that looks right at small widths, and it degrades honestly —
push the width up and you will see the eight sample points as lobes.

:::callout-pitfall[Pitfall]
Every one of those lookups happens per pixel, per frame. Nine texture reads instead of
  one is not free on a full-screen effect, though it is nothing on a handful of sprites.
  If the outline never changes, bake it into the texture instead.
:::

### 2D Outline (Canvas Item)

#### 8-Neighbour Sample Outline

canvas\_item — 2D — Complexity: low

Samples 8 neighbouring pixels; if any neighbour is transparent but the centre is opaque, we're on the edge.

```glsl
shader_type canvas_item;

uniform vec4 outline_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float outline_width : hint_range(0.5, 8.0) = 2.0;

void fragment() {
    vec2 texel = outline_width / vec2(textureSize(TEXTURE, 0));
    vec4 col   = texture(TEXTURE, UV);

    // Sample 8 neighbours
    float alpha = 0.0;
    alpha += texture(TEXTURE, UV + vec2(-texel.x, -texel.y)).a;
    alpha += texture(TEXTURE, UV + vec2( 0.0,     -texel.y)).a;
    alpha += texture(TEXTURE, UV + vec2( texel.x, -texel.y)).a;
    alpha += texture(TEXTURE, UV + vec2(-texel.x,  0.0    )).a;
    alpha += texture(TEXTURE, UV + vec2( texel.x,  0.0    )).a;
    alpha += texture(TEXTURE, UV + vec2(-texel.x,  texel.y)).a;
    alpha += texture(TEXTURE, UV + vec2( 0.0,      texel.y)).a;
    alpha += texture(TEXTURE, UV + vec2( texel.x,  texel.y)).a;

    // If any neighbour is solid and we're transparent, draw outline
    bool on_edge = (alpha > 0.0 && col.a < 0.5);
    COLOR = on_edge ? outline_color : col;
}
```

### 3D Outline (Vertex Inflate)

#### Back-Face Inflate Outline (two-pass)

spatial — 3D — Complexity: medium

Render a slightly inflated copy of the mesh with back-face culling inverted (front cull mode). The outline colour shows only where the back-face extrusion peeks around the silhouette.

```glsl
// Apply this shader to a DUPLICATE of the mesh (the "outline mesh")
shader_type spatial;
render_mode cull_front, unshaded;

uniform vec4 outline_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float outline_thickness : hint_range(0.0, 0.1) = 0.02;

void vertex() {
    // Inflate along object-space normal
    VERTEX += NORMAL * outline_thickness;
}

void fragment() {
    ALBEDO = outline_color.rgb;
}
```

In GDScript, add a duplicate MeshInstance as a child with this outline shader:

```gdscript
func add_outline(source: MeshInstance3D, thickness := 0.02, color := Color.BLACK) -> void:
    var outline := source.duplicate() as MeshInstance3D
    source.add_child(outline)
    var mat := ShaderMaterial.new()
    mat.shader = preload("res://shaders/outline_3d.gdshader")
    mat.set_shader_parameter("outline_thickness", thickness)
    mat.set_shader_parameter("outline_color", color)
    outline.material_override = mat
```

**Limitation:** The inflate technique breaks on flat meshes (planes) and sharp corners. Use normal-smoothed meshes or a geometry shader (not available in Godot's GLES3 backend) for perfect results.

## Recipe 3 — Stylised Water

Water is two independent lies told convincingly. The surface is not moving — the
*texture coordinates* are, scrolled by `TIME` so a static noise texture
reads as flow. And the water is not refracting — what is behind it is being sampled at
a slightly wrong place, with the noise deciding how wrong.

Using two scroll speeds in different directions is what keeps it from looking like a
sliding photograph. One layer alone moves rigidly and the eye catches the repeat almost at
once; two layers at different rates and angles interfere with each other, and the pattern
takes long enough to repeat that nobody notices.

### 2D Water Surface

#### Sine-Wave Distortion + Scrolling Foam

canvas\_item — 2D — Complexity: medium

```glsl
shader_type canvas_item;

uniform sampler2D foam_tex  : hint_default_white;
uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear_mipmap;
uniform float wave_freq   : hint_range(1.0, 30.0)  = 8.0;
uniform float wave_speed  : hint_range(0.0, 5.0)   = 1.5;
uniform float wave_amp    : hint_range(0.0, 0.02)  = 0.006;
uniform float foam_scale  : hint_range(0.5, 8.0)   = 3.0;
uniform vec4  water_tint  : source_color = vec4(0.1, 0.4, 0.7, 0.6);

void fragment() {
    // Distort screen UV
    vec2 suv = SCREEN_UV;
    suv.x += sin(UV.y * wave_freq + TIME * wave_speed) * wave_amp;
    suv.y += sin(UV.x * wave_freq * 0.7 + TIME * wave_speed * 1.3) * wave_amp * 0.5;

    vec4 bg    = texture(SCREEN_TEXTURE, suv);
    vec4 water = mix(bg, water_tint, water_tint.a);

    // Scrolling foam layer
    vec2 foam_uv = UV * foam_scale + vec2(TIME * 0.05, TIME * 0.02);
    float foam   = texture(foam_tex, foam_uv).r;
    // Foam only near the surface (top of the sprite)
    float foam_mask = smoothstep(0.1, 0.35, 1.0 - UV.y) * foam;

    water.rgb = mix(water.rgb, vec3(1.0), foam_mask * 0.6);
    COLOR = water;
}
```

### 3D Ocean Shader

#### Gerstner Waves + Depth Foam + Normal Map

spatial — 3D — Complexity: high

```glsl
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform sampler2D normal_map_a : hint_normal;
uniform sampler2D normal_map_b : hint_normal;
uniform sampler2D DEPTH_TEXTURE : hint_depth_texture, filter_nearest;

uniform vec4  shallow_color : source_color = vec4(0.0, 0.6, 0.8, 0.85);
uniform vec4  deep_color    : source_color = vec4(0.0, 0.1, 0.35, 1.0);
uniform vec4  foam_color    : source_color = vec4(1.0, 1.0, 1.0, 1.0);

uniform float wave_height   : hint_range(0.0, 2.0) = 0.4;
uniform float wave_speed    : hint_range(0.0, 3.0) = 0.8;
uniform float depth_fade    : hint_range(0.5, 20.0) = 6.0;
uniform float foam_depth    : hint_range(0.0, 2.0) = 0.8;
uniform float roughness     : hint_range(0.0, 1.0) = 0.05;

varying float vertex_depth;

// Gerstner wave: returns displacement vec3
vec3 gerstner(vec2 pos, vec2 dir, float steepness, float wavelength) {
    float k = TAU / wavelength;
    float c = sqrt(9.8 / k);
    vec2  d = normalize(dir);
    float f = k * (dot(d, pos) - c * TIME * wave_speed);
    float a = steepness / k;
    return vec3(d.x * a * cos(f), a * sin(f), d.y * a * cos(f));
}

void vertex() {
    vec2 xz = VERTEX.xz;
    vec3 disp = vec3(0.0);
    disp += gerstner(xz, vec2(1.0, 0.0), 0.25, 8.0) * wave_height;
    disp += gerstner(xz, vec2(0.7, 0.7), 0.20, 5.0) * wave_height * 0.7;
    disp += gerstner(xz, vec2(-0.5, 1.0), 0.15, 3.0) * wave_height * 0.4;
    VERTEX += disp;
    vertex_depth = VERTEX.y;
}

void fragment() {
    // Depth-based colour blend
    float depth_raw = texture(DEPTH_TEXTURE, SCREEN_UV).r;
    float depth_lin = (2.0 * 0.05) / (100.0 + 0.05 - depth_raw * (100.0 - 0.05));
    float frag_lin  = FRAGCOORD.z;
    float depth_diff = (depth_lin - frag_lin) * depth_fade * 100.0;
    float depth_fade_val = clamp(depth_diff, 0.0, 1.0);
    vec3 water_col = mix(shallow_color.rgb, deep_color.rgb, depth_fade_val);
    float alpha    = mix(shallow_color.a, deep_color.a, depth_fade_val);

    // Foam near edges
    float foam = clamp(1.0 - depth_diff / foam_depth, 0.0, 1.0);
    water_col = mix(water_col, foam_color.rgb, foam * 0.8);

    // Animated normal maps
    vec2 uv_a = UV * 2.0 + vec2(TIME * 0.04, TIME * 0.02);
    vec2 uv_b = UV * 1.5 - vec2(TIME * 0.03, TIME * 0.05);
    vec3 nm_a = texture(normal_map_a, uv_a).rgb;
    vec3 nm_b = texture(normal_map_b, uv_b).rgb;
    NORMAL_MAP = normalize(nm_a + nm_b) * 0.5 + 0.5;
    NORMAL_MAP_DEPTH = 1.5;

    ALBEDO     = water_col;
    ALPHA      = alpha;
    ROUGHNESS  = roughness;
    SPECULAR   = 0.9;
    METALLIC   = 0.0;
}
```

## Recipe 4 — Procedural Fire & Lava

Fire is a gradient with noise pushed through it. The vertical coordinate decides the
colour — white at the base, through yellow and orange, to a dark red that fades out at
the top — and the noise decides how much that gradient is displaced at each point, so
the flame licks instead of sitting still.

The colour ramp is doing more work than the motion. Real flame colour is a temperature
map, and the reason a naive fire looks like orange soup is a ramp with too few stops and no
white at the hottest point. Note that the alpha fades on a different curve from the colour:
the flame goes transparent before it goes black, which is what stops the tips from looking
like smoke.

### Procedural Fire (No Texture)

#### FBM Noise Fire on a Quad

canvas\_item — 2D — Complexity: medium

```glsl
shader_type canvas_item;
render_mode blend_add;

uniform float fire_speed  : hint_range(0.1, 5.0) = 1.8;
uniform float fire_scale  : hint_range(1.0, 20.0) = 6.0;
uniform float fire_height : hint_range(0.5, 2.0)  = 1.2;

// Simple hash
float hash(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
}

// Value noise
float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    float a = hash(i), b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)), d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

// Fractal Brownian Motion
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * noise(p);
        p  = p * 2.0 + vec2(1.7, 9.2);
        a *= 0.5;
    }
    return v;
}

void fragment() {
    vec2 uv = UV;
    uv.y = 1.0 - uv.y; // flip so fire rises

    // Scroll noise upward
    vec2 scroll = uv * fire_scale + vec2(0.0, -TIME * fire_speed);
    float f = fbm(scroll);
    f += 0.5 * fbm(scroll * 2.0 - vec2(0.0, TIME * fire_speed * 0.5));

    // Mask at base (hot) and top (cool)
    float mask = smoothstep(0.0, 0.4, uv.y) * smoothstep(1.0, 0.3 * fire_height, uv.y);
    float fire = f * mask;

    // Colour map: black → red → orange → yellow → white
    vec3 col = vec3(0.0);
    col = mix(col, vec3(0.8, 0.0, 0.0), smoothstep(0.0, 0.3, fire));
    col = mix(col, vec3(1.0, 0.4, 0.0), smoothstep(0.2, 0.5, fire));
    col = mix(col, vec3(1.0, 0.9, 0.2), smoothstep(0.4, 0.7, fire));
    col = mix(col, vec3(1.0, 1.0, 1.0), smoothstep(0.6, 0.9, fire));

    COLOR = vec4(col, fire * 2.0);
}
```

Place on a QuadMesh with `render_mode blend_add` for an additive glow over the background.

### Lava Flow

#### FBM Cracks + Colour Ramp

spatial — 3D — Complexity: medium

```glsl
shader_type spatial;
render_mode blend_mix, cull_back, diffuse_burley;

uniform float lava_scale  : hint_range(1.0, 20.0)  = 4.0;
uniform float lava_speed  : hint_range(0.0, 2.0)   = 0.2;
uniform vec4  lava_hot    : source_color = vec4(1.0, 0.7, 0.0, 1.0);
uniform vec4  lava_dark   : source_color = vec4(0.08, 0.02, 0.0, 1.0);
uniform float emission_strength : hint_range(0.0, 8.0) = 3.0;

float hash(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
}
float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
        u.y
    );
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * noise(p); p *= 2.1; a *= 0.5; }
    return v;
}

void fragment() {
    vec2 uv    = UV * lava_scale;
    float t    = TIME * lava_speed;
    float f    = fbm(uv + vec2(t, t * 0.5));
    f         += 0.5 * fbm(uv * 2.0 - vec2(t * 0.3, t));

    float crack = smoothstep(0.45, 0.55, f);
    vec3 col    = mix(lava_dark.rgb, lava_hot.rgb, crack);

    ALBEDO    = col;
    EMISSION  = lava_hot.rgb * crack * emission_strength;
    ROUGHNESS = mix(0.9, 0.2, crack);
    METALLIC  = 0.0;
}
```

## Recipe 5 — Hit Flash

The hit flash is the smallest useful shader in the chapter and probably the highest
value per line. One uniform, one `mix`, and a tween that drives the uniform from
1 back to 0 over a tenth of a second.

What makes it read as impact rather than as a colour change is the shape of the decay.
A linear fade over 0.3 seconds looks like a light turning off; a fast attack with a short
tail reads as a hit. That is a property of the tween, not of the shader — which is the
general lesson here. The shader decides what a value *means*; the animation decides
how it *feels*.

#### White Flash on Damage

canvas\_item — 2D — Complexity: very low

```glsl
shader_type canvas_item;

uniform float flash_amount : hint_range(0.0, 1.0) = 0.0;
uniform vec4  flash_color  : source_color = vec4(1.0, 1.0, 1.0, 1.0);

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    tex.rgb   = mix(tex.rgb, flash_color.rgb, flash_amount * tex.a);
    COLOR      = tex;
}
```

#### GDScript Trigger

```gdscript
@onready var mat: ShaderMaterial = $Sprite2D.material

func trigger_hit_flash(duration := 0.15) -> void:
    var tw := create_tween()
    tw.tween_method(
        func(v): mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, duration
    ).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)

# Call on receiving damage:
# trigger_hit_flash()
```

**Variations:** Use a red `flash_color` for a damage-tone effect. Combine with a Tween on the node's `modulate.a` for a brief "invincibility flicker" by toggling visibility.

## Recipe 6 — Glow, Bloom & Screen Effects

These are the effects that do not belong to any one object. A glow is a property of
the frame, not of a sprite, and that changes where the work happens: bloom is a
`WorldEnvironment` setting that acts on everything bright, while the scanline
and aberration shaders run on a full-screen quad after the scene is drawn.

Chromatic aberration is worth understanding because it is so cheap for what it buys.
Sampling the red, green and blue channels at slightly different offsets imitates a lens
that cannot focus all three colours on the same point. Keep the offset to a pixel or two:
the effect is meant to be felt rather than seen, and past that it just looks broken.

### Pulsing Emission Glow (3D)

#### Animate EMISSION over time for a magical glow

spatial — 3D — Complexity: low

```glsl
shader_type spatial;
render_mode blend_mix, unshaded;

uniform vec4  glow_color     : source_color = vec4(0.3, 0.8, 1.0, 1.0);
uniform float glow_min       : hint_range(0.0, 4.0) = 0.5;
uniform float glow_max       : hint_range(0.0, 8.0) = 3.0;
uniform float pulse_speed    : hint_range(0.1, 5.0) = 1.5;

void fragment() {
    float pulse    = sin(TIME * pulse_speed) * 0.5 + 0.5; // 0–1
    float strength = mix(glow_min, glow_max, pulse);
    EMISSION       = glow_color.rgb * strength;
    ALBEDO         = glow_color.rgb;
}
```

Enable **Glow** in the WorldEnvironment node (Environment → Glow) for the emission to bloom in the scene.

### CRT Scanlines + Chromatic Aberration

#### Full-screen post-process on a ColorRect

canvas\_item (ColorRect) — 2D post-process — Complexity: medium

```glsl
shader_type canvas_item;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear_mipmap;
uniform float scanline_strength : hint_range(0.0, 1.0) = 0.25;
uniform float scanline_count    : hint_range(10.0, 500.0) = 200.0;
uniform float aberration_amount : hint_range(0.0, 0.02) = 0.003;
uniform float vignette_strength : hint_range(0.0, 2.0) = 0.8;

void fragment() {
    vec2 uv = SCREEN_UV;

    // Chromatic aberration
    vec2 offset = vec2(aberration_amount, 0.0);
    float r = texture(SCREEN_TEXTURE, uv + offset).r;
    float g = texture(SCREEN_TEXTURE, uv).g;
    float b = texture(SCREEN_TEXTURE, uv - offset).b;
    vec3 col = vec3(r, g, b);

    // Scanlines
    float line = sin(uv.y * scanline_count * PI) * 0.5 + 0.5;
    col *= 1.0 - scanline_strength * (1.0 - line);

    // Vignette
    vec2 vig_uv = uv * 2.0 - 1.0;
    float vignette = 1.0 - dot(vig_uv, vig_uv) * vignette_strength * 0.5;
    col *= clamp(vignette, 0.0, 1.0);

    COLOR = vec4(col, 1.0);
}
```

## Recipe 7 — Hologram

A hologram is a stack of small tells, none of which is convincing alone. Horizontal
scanlines from a sine of the screen coordinate; a rim that brightens where the surface turns
away from the viewer; a slight transparency; and an occasional glitch offset. Remove any one
and it still reads as a hologram. Remove three and it reads as a blue object.

The rim term is the one worth studying, because it appears in every stylised shader:
taking the dot product of the surface normal and the view direction gives a number that is
near 1 face-on and near 0 at a grazing angle, and inverting it lights exactly the silhouette.
That is Fresnel, and it is most of what makes a shader look three-dimensional.

#### Scanline Projection with Flicker

spatial — 3D — Complexity: medium

```glsl
shader_type spatial;
render_mode blend_add, cull_disabled, unshaded;

uniform vec4  holo_color : source_color = vec4(0.0, 0.8, 1.0, 1.0);
uniform float scan_freq  : hint_range(1.0, 50.0) = 20.0;
uniform float scan_speed : hint_range(0.0, 5.0)  = 1.2;
uniform float flicker    : hint_range(0.0, 1.0)  = 0.15;
uniform float edge_glow  : hint_range(0.0, 3.0)  = 1.5;
uniform sampler2D noise_tex : hint_default_white;

void fragment() {
    // Scanlines in view-space Y
    float scan = sin(FRAGCOORD.y * scan_freq - TIME * scan_speed * 60.0) * 0.5 + 0.5;
    scan = pow(scan, 3.0) * 0.7 + 0.3;

    // Flicker noise
    float flick = 1.0 - flicker * texture(noise_tex, vec2(TIME * 5.0, 0.0)).r;

    // Fresnel edge glow
    float fresnel = pow(1.0 - abs(dot(NORMAL, VIEW)), edge_glow);
    fresnel = clamp(fresnel, 0.0, 1.0);

    float intensity = scan * flick * (0.3 + fresnel * 0.7);
    EMISSION = holo_color.rgb * intensity;
    ALPHA    = holo_color.a * intensity;
}
```

## Recipe 8 — Shockwave / Screen Blast

A shockwave distorts what is behind it, which means it must read the screen rather
than a texture of its own. The ring is a distance from the centre compared against a radius
that grows with time — the same two-threshold subtraction as the dissolve edge, used
here to select a band to displace rather than a band to colour.

The displacement is pushed along the direction away from the centre and scaled by the
band, so pixels inside the ring are dragged outward and everything else is left alone. Fade
the strength as the radius grows or the wave will look like it has infinite energy at the
edge of the screen.

#### Radial Screen Distortion

canvas\_item (ColorRect) — 2D post-process — Complexity: medium

```glsl
shader_type canvas_item;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear_mipmap;
uniform vec2  wave_origin  = vec2(0.5, 0.5); // normalised screen coords
uniform float wave_radius  : hint_range(0.0, 1.5) = 0.0;
uniform float wave_width   : hint_range(0.0, 0.3) = 0.08;
uniform float wave_strength: hint_range(0.0, 0.1) = 0.03;

void fragment() {
    vec2 uv   = SCREEN_UV;
    vec2 diff = uv - wave_origin;
    float dist = length(diff);

    // Ring mask — nonzero near wave_radius
    float ring = smoothstep(wave_width, 0.0, abs(dist - wave_radius));

    // Push pixels outward along the radial direction
    vec2 displaced = uv + normalize(diff) * ring * wave_strength;
    COLOR = texture(SCREEN_TEXTURE, displaced);
}
```

#### GDScript Trigger

```gdscript
func shockwave_at(screen_pos: Vector2, duration := 0.5) -> void:
    var vp_size := get_viewport().get_visible_rect().size
    var norm_pos := screen_pos / vp_size
    var mat: ShaderMaterial = $ColorRect.material
    mat.set_shader_parameter("wave_origin", norm_pos)
    var tw := create_tween()
    tw.tween_method(
        func(r): mat.set_shader_parameter("wave_radius", r),
        0.0, 1.2, duration
    ).set_trans(Tween.TRANS_SINE)
```

## Recipe 9 — Pixelate

Pixelation is a rounding operation on coordinates. Multiply the UV by the number of
blocks you want, `floor()` it, and divide back: every coordinate inside a block
collapses to the same value, so the whole block samples the same texel.

The one thing to get right is the filter. A pixelate shader on a texture with linear
filtering gives you blurry blocks, which is the worst of both — set the texture to
nearest-neighbour so the blocks have hard edges. This is also the cheapest transition effect
in the chapter: animate the block count from large to small and the scene resolves out of
nothing.

#### Retro Pixel Filter

canvas\_item (ColorRect) — 2D post-process — Complexity: very low

```glsl
shader_type canvas_item;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_nearest;
uniform float pixel_size : hint_range(1.0, 64.0) = 4.0;

void fragment() {
    vec2 vp_size = vec2(textureSize(SCREEN_TEXTURE, 0));
    vec2 snapped = floor(SCREEN_UV * vp_size / pixel_size) * pixel_size / vp_size;
    COLOR = texture(SCREEN_TEXTURE, snapped);
}
```

Animate `pixel_size` from 1.0 to 16.0 via Tween for a pixelation transition (e.g., level transition, death screen).

## WorldEnvironment, Sky & CompositorEffects

The **WorldEnvironment** node controls scene-wide rendering: ambient light, sky, tone mapping, and post-processing. Key properties to know:

| Category | Property path | What it does |
| --- | --- | --- |
| Ambient Light | Environment → Ambient Light → Color/Energy | Flat fill light — no shadow |
| Sky | Environment → Sky → Sky Material | Panorama, ProceduralSky, or custom sky shader |
| Tone Mapping | Environment → Tonemap → Mode | Linear, Reinhard, Filmic, ACES — affects HDR → LDR conversion |
| Glow | Environment → Glow → Enabled, Intensity, Bloom | Post-process bloom from EMISSION values |
| SSAO | Environment → SSAO → Enabled | Screen-space ambient occlusion (Vulkan renderer) |
| SSIL | Environment → SSIL → Enabled | Screen-space indirect lighting (Vulkan) |
| SSR | Environment → SSR → Enabled | Screen-space reflections (Vulkan) |
| Fog | Environment → Volumetric Fog → Enabled | Volumetric depth fog |
| Background | Environment → Background → Mode | Color, Sky, Canvas, Camera (AR) |

### CompositorEffect (Godot 4.3+)

The **Compositor** resource on the Camera3D allows custom render passes written in GLSL compute shaders (RenderingDevice API). This is Godot's replacement for full-screen post-processing ColorRects in 3D — far more powerful because it operates directly on the HDR framebuffer.

```gdscript
# Attach a CompositorEffect subclass to Camera3D.compositor.effects
class_name GrayscaleEffect extends CompositorEffect

func _init() -> void:
    effect_callback_type = EFFECT_CALLBACK_TYPE_POST_TRANSPARENT

func _render_callback(effect_callback_type: int, render_data: RenderData) -> void:
    var render_scene_buffers := render_data.get_render_scene_buffers()
    # Access the color buffer via RenderingDevice — see Godot docs for full example
```

:::callout-tip[When to use CompositorEffect vs. ColorRect]
For 2D games: ColorRect post-process shaders are simpler and work on all renderers. For 3D games: CompositorEffect gives HDR access and proper Z-ordering. Use ColorRect for 3D prototypes where you want something working fast.
:::

:::summary
### Part VIII Complete — Shader Quick-Reference

| Effect | Shader type | Key technique |
| --- | --- | --- |
| Dissolve | canvas\_item or spatial | step(threshold, noise) → ALPHA |
| 2D Outline | canvas\_item | 8-neighbour alpha sample |
| 3D Outline | spatial (cull\_front) | VERTEX inflate along NORMAL |
| 2D Water | canvas\_item | SCREEN\_TEXTURE + sin UV distortion |
| 3D Ocean | spatial | Gerstner waves + DEPTH\_TEXTURE foam |
| Procedural Fire | canvas\_item (blend\_add) | FBM noise + colour ramp + rising mask |
| Lava | spatial | FBM cracks + EMISSION hotspot |
| Hit Flash | canvas\_item | mix(tex, flash\_color, flash\_amount) |
| Glow | spatial | Pulsing EMISSION + WorldEnvironment Glow |
| CRT Scanlines | canvas\_item (ColorRect) | SCREEN\_TEXTURE + sin scanlines + aberration |
| Hologram | spatial (blend\_add) | Scanlines + Fresnel + noise flicker |
| Shockwave | canvas\_item (ColorRect) | Radial ring mask → displace SCREEN\_UV |
| Pixelate | canvas\_item (ColorRect) | floor(SCREEN\_UV / pixel\_size) \* pixel\_size |
:::

## Practice Problems

:::problem{difficulty="easy"}
**1. Ice Freeze Effect**

Adapt the dissolve shader to create a "freeze" effect: instead of burning edges, use a cold blue edge colour (`ice_color = vec4(0.6, 0.85, 1.0, 1.0)`). The dissolve should progress from the bottom of the sprite upward (use `UV.y` instead of noise, or use noise biased by UV.y). Animate it from 0 → 1 over 1.5 seconds.

::::solution[Solution]
```glsl
shader_type canvas_item;
uniform float freeze_amount : hint_range(0.0, 1.0) = 0.0;
uniform float edge_width : hint_range(0.0, 0.15) = 0.07;
uniform vec4 ice_color : source_color = vec4(0.6, 0.85, 1.0, 1.0);
uniform sampler2D noise_tex : hint_default_white;

void fragment() {
    vec4 base = texture(TEXTURE, UV);
    // Bias noise by UV.y so freeze rises from bottom
    float noise = texture(noise_tex, UV).r;
    float threshold = freeze_amount - (1.0 - UV.y) * 0.3;

    float solid_mask = step(threshold, noise);
    float edge_mask  = step(threshold - edge_width, noise) - solid_mask;

    vec4 col = base;
    col.rgb = mix(ice_color.rgb, col.rgb, solid_mask);
    col.a   = col.a * (solid_mask + edge_mask);
    COLOR   = col;
}
```

```gdscript
func freeze(duration := 1.5) -> void:
    var tw := create_tween()
    tw.tween_method(func(v): material.set_shader_parameter("freeze_amount", v),
        0.0, 1.0, duration).set_trans(Tween.TRANS_SINE)
```
::::
:::

:::problem{difficulty="easy"}
**2. Selection Outline Toggle**

Build a 2D outline shader that can be toggled on/off via an `outline_enabled` boolean uniform (use an `int` since GLSL bools in uniforms can be tricky — 1 = on, 0 = off). The outline should be a bright yellow (selection highlight). Show the GDScript code to enable/disable it from a mouse click.

::::solution[Solution]
```glsl
shader_type canvas_item;
uniform int outline_enabled = 0; // 1 = on
uniform vec4 outline_color : source_color = vec4(1.0, 0.9, 0.0, 1.0);
uniform float outline_width : hint_range(0.5, 6.0) = 2.0;

void fragment() {
    vec2 texel = outline_width / vec2(textureSize(TEXTURE, 0));
    vec4 col = texture(TEXTURE, UV);
    if (outline_enabled == 1) {
        float alpha = 0.0;
        alpha += texture(TEXTURE, UV + vec2(-texel.x, 0.0)).a;
        alpha += texture(TEXTURE, UV + vec2( texel.x, 0.0)).a;
        alpha += texture(TEXTURE, UV + vec2(0.0, -texel.y)).a;
        alpha += texture(TEXTURE, UV + vec2(0.0,  texel.y)).a;
        if (alpha > 0.0 && col.a < 0.5) { col = outline_color; }
    }
    COLOR = col;
}
```

```gdscript
func _input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed:
        var enabled: int = material.get_shader_parameter("outline_enabled")
        material.set_shader_parameter("outline_enabled", 1 - enabled)
```
::::
:::

:::problem{difficulty="standard"}
**3. Transition Wipe**

Create a full-screen wipe transition effect on a ColorRect using a gradient (radial or directional). The wipe should reveal a solid colour (e.g., black) sweeping across the screen. Use a `progress` parameter (0–1) to control how far the wipe has gone. Show how to trigger it as a scene transition using a Tween.

::::solution[Solution]
```glsl
// Directional wipe (left to right)
shader_type canvas_item;
uniform float progress : hint_range(0.0, 1.0) = 0.0;
uniform vec4 wipe_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float softness : hint_range(0.0, 0.5) = 0.05;

uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear_mipmap;

void fragment() {
    float edge = smoothstep(progress - softness, progress + softness, SCREEN_UV.x);
    vec4 screen = texture(SCREEN_TEXTURE, SCREEN_UV);
    COLOR = mix(wipe_color, screen, edge);
}
```

```gdscript
func wipe_out(on_complete: Callable, duration := 0.5) -> void:
    var mat: ShaderMaterial = $ColorRect.material
    var tw := create_tween()
    tw.tween_method(func(v): mat.set_shader_parameter("progress", v),
        0.0, 1.0, duration)
    tw.tween_callback(on_complete)

func wipe_in(duration := 0.5) -> void:
    var mat: ShaderMaterial = $ColorRect.material
    var tw := create_tween()
    tw.tween_method(func(v): mat.set_shader_parameter("progress", v),
        1.0, 0.0, duration)
```
::::
:::

:::problem{difficulty="standard"}
**4. Shield Hit Effect**

Create a 3D spatial shader for a force field / shield sphere. Normally it's mostly transparent with a faint Fresnel edge glow. When hit, a `hit_intensity` uniform spikes to 1.0 and the sphere briefly flashes bright, then fades. Combine Fresnel, hit flash, and hex-grid pattern (use UV-based hex math or a noise texture as a stand-in) for visual richness.

::::solution[Solution]
```glsl
shader_type spatial;
render_mode blend_add, cull_disabled, unshaded;

uniform float hit_intensity : hint_range(0.0, 1.0) = 0.0;
uniform vec4  shield_color : source_color = vec4(0.3, 0.7, 1.0, 1.0);
uniform float fresnel_power : hint_range(1.0, 8.0) = 3.0;
uniform sampler2D hex_tex : hint_default_white; // optional hex texture

void fragment() {
    float fresnel = pow(1.0 - abs(dot(NORMAL, VIEW)), fresnel_power);
    float hex     = texture(hex_tex, UV * 4.0).r;  // repeating hex pattern
    float base    = fresnel * 0.4 + hex * 0.15;
    float total   = base + hit_intensity * (1.0 - base);
    EMISSION = shield_color.rgb * total;
    ALPHA    = shield_color.a * total;
}
```

```gdscript
func take_hit() -> void:
    var mat: ShaderMaterial = material_override
    var tw := create_tween()
    tw.tween_method(func(v): mat.set_shader_parameter("hit_intensity", v),
        1.0, 0.0, 0.4).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
```
::::
:::

:::problem{difficulty="challenge"}
**5. Full Pipeline — Death Sequence**

Implement a complete death sequence for a 2D enemy that chains three effects: (1) a white hit flash for 0.1s, (2) a 0.8s dissolve-out with orange burn edges, (3) a burst of 12 GPUParticles2D sparks that persist for 1.0s after the sprite disappears. All three should trigger from a single `die()` function on the enemy. The enemy node should queue\_free after the particles finish.

::::solution[Solution]
```gdscript
extends CharacterBody2D

@onready var sprite: Sprite2D           = $Sprite2D
@onready var sparks: GPUParticles2D     = $Sparks
@onready var flash_mat: ShaderMaterial  = $Sprite2D.material  # hit flash shader
@onready var dissolve_mat: ShaderMaterial                      # separate material

func _ready() -> void:
    # Assign dissolve shader material at runtime
    dissolve_mat = ShaderMaterial.new()
    dissolve_mat.shader = preload("res://shaders/dissolve.gdshader")
    dissolve_mat.set_shader_parameter("dissolve_amount", 0.0)

func die() -> void:
    set_physics_process(false)
    collision_layer = 0
    collision_mask  = 0

    # 1. Hit flash
    var tw := create_tween()
    tw.tween_method(
        func(v): flash_mat.set_shader_parameter("flash_amount", v),
        1.0, 0.0, 0.1
    )

    # 2. Swap to dissolve material, then tween dissolve
    tw.tween_callback(func(): sprite.material = dissolve_mat)
    tw.tween_method(
        func(v): dissolve_mat.set_shader_parameter("dissolve_amount", v),
        0.0, 1.0, 0.8
    ).set_trans(Tween.TRANS_SINE)

    # 3. Trigger sparks burst, hide sprite, queue_free after sparks
    tw.tween_callback(func():
        sparks.one_shot  = true
        sparks.emitting  = true
        sprite.visible   = false
    )
    tw.tween_interval(1.0)
    tw.tween_callback(queue_free)
```

The sparks GPUParticles2D should use a custom particle shader that fans 12 particles outward (using INDEX-based angle like the magic circle burst from Ch 54). Set `one_shot = true` and `explosiveness = 1.0` in the Inspector.
::::
:::
