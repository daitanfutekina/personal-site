---
title: "FileAccess, JSON, ConfigFile & ResourceSaver Compared"
source: "godot_ch47_file_access.html"
---

Part VII · Chapter 47

# FileAccess, JSON, ConfigFile & ResourceSaver Compared

Estimated study time: 65 min · Godot 4.6 · GDScript

## Overview

Godot gives you four distinct mechanisms for writing data to disk, and choosing the right one saves you hours of debugging. This chapter explains all four in depth — when to use each, exactly how the API works, and the common pitfalls — so that Ch 48 (Save Slots) can build on solid foundations.

- **FileAccess** — raw byte and text I/O. Maximum control; you decide the format entirely.
- **JSON** — human-readable, language-agnostic serialisation built on FileAccess. Great for save data that you want to inspect or edit by hand.
- **ConfigFile** — INI-style key/value store. Ideal for settings (graphics, audio, keybindings).
- **ResourceSaver / ResourceLoader** — serialise any Godot `Resource` subclass to a `.tres` (text) or `.res` (binary) file. Best for game data that maps cleanly to a Resource class (player stats, inventory items, level configs).

### Prerequisites

- Ch 16 — Exported variables and Resources
- Ch 21 — Autoloads
- Ch 26 — Dictionaries and Arrays

## Path Conventions: `res://` vs `user://`

Godot uses two virtual path prefixes for file operations. Understanding the difference is fundamental.

| Prefix | Points to | Writable? | Exported? |
| --- | --- | --- | --- |
| `res://` | The project root (same folder as `project.godot`) | Only in the editor; read-only in exported builds | All `res://` files are packed into a `.pck` archive when you export |
| `user://` | OS-specific user data directory (see below) | Always writable | Not included in the export — persists between sessions on the player's machine |

**`user://` resolves to:**

- **Windows:** `%APPDATA%\Godot\app_userdata\<project_name>\`
- **macOS:** `~/Library/Application Support/Godot/<project_name>\`
- **Linux:** `~/.local/share/godot/<project_name>\`
- **Android/iOS:** Sandboxed app data directory.

In the editor you can inspect `user://` files via **Project → Open User Data Folder**.

:::callout-pitfall[Pitfall — writing to res:// in exports]
Code that writes to `res://` paths works perfectly in the editor but silently fails (or crashes) in an exported build because the `.pck` archive is read-only. **All runtime writes must go to `user://`.** Only use `res://` for reading bundled assets.
:::

### Useful Path Utilities

```gdscript
# Check if a file exists before opening it
FileAccess.file_exists("user://save.json")      # returns bool

# Get the OS path that user:// resolves to
OS.get_user_data_dir()

# List files in a directory
var dir := DirAccess.open("user://")
if dir:
    dir.list_dir_begin()
    var name := dir.get_next()
    while name != "":
        if not dir.current_is_dir():
            print(name)
        name = dir.get_next()

# Create a directory
DirAccess.make_dir_recursive_absolute(
    OS.get_user_data_dir() + "/saves/slot_1"
)
```

## FileAccess — Raw File I/O

`FileAccess` is the lowest-level API. It reads and writes individual values (strings, integers, floats, bytes) directly. Every other mechanism in this chapter uses `FileAccess` internally.

### Opening a File

```gdscript
var file := FileAccess.open("user://data.txt", FileAccess.WRITE)
if file == null:
    push_error("Could not open file: " + error_string(FileAccess.get_open_error()))
    return
```

**Open flags:**

| Flag | Behaviour |
| --- | --- |
| `FileAccess.READ` | Open for reading. File must exist. |
| `FileAccess.WRITE` | Open for writing. Creates the file if it doesn't exist; **truncates** if it does. |
| `FileAccess.READ_WRITE` | Open for both. File must exist. Does *not* truncate. |
| `FileAccess.WRITE_READ` | Open for both. Creates or truncates like WRITE, then allows reading. |

:::callout-tip[File is closed automatically]
In Godot 4, `FileAccess` closes the file when the object goes out of scope (the GDScript reference count drops to zero). You don't need to call `file.close()` explicitly — but calling it early is fine and flushes the write buffer immediately.
:::

### Writing Text and Values

| Method | Description |
| --- | --- |
| store\_string(s) | Write a string without a newline. |
| store\_line(s) | Write a string followed by `\n`. |
| store\_var(value, full\_objects) | Serialise any Variant (int, float, String, Array, Dictionary, Vector2…). `full_objects=true` allows Object references but is unsafe to load from untrusted files. |
| store\_8(v) / store\_16(v) / store\_32(v) / store\_64(v) | Write an integer as 1/2/4/8 raw bytes (little-endian). |
| store\_float(v) | Write a 32-bit float (4 bytes). |
| store\_double(v) | Write a 64-bit double (8 bytes). |
| store\_buffer(bytes) | Write a `PackedByteArray` verbatim. |
| store\_pascal\_string(s) | Write a length-prefixed string (4-byte length + UTF-8 bytes). |

```gdscript
var file := FileAccess.open("user://highscores.txt", FileAccess.WRITE)
file.store_line("Alice,9500")
file.store_line("Bob,8800")
file.store_line("Carol,7200")
# file closes (and flushes) when it goes out of scope
```

### Reading Text and Values

| Method | Description |
| --- | --- |
| get\_line() | Read one line (strip trailing newline). Returns empty string at EOF. |
| get\_as\_text() | Read the entire file as a single String. |
| get\_var(allow\_objects) | Deserialise one Variant written by `store_var()`. |
| get\_8() / get\_16() / get\_32() / get\_64() | Read 1/2/4/8 bytes as an unsigned integer. |
| get\_float() | Read a 32-bit float. |
| get\_double() | Read a 64-bit double. |
| get\_buffer(length) | Read `length` bytes into a `PackedByteArray`. |
| get\_pascal\_string() | Read a length-prefixed string. |
| eof\_reached() | Returns `true` when the read position is at the end of the file. |
| get\_position() | Current byte offset. |
| seek(pos) | Jump to a byte offset. `seek_end(offset)` seeks relative to the end. |
| get\_length() | Total file size in bytes. |

```gdscript
var file := FileAccess.open("user://highscores.txt", FileAccess.READ)
if file == null:
    return
var scores: Array[Dictionary] = []
while not file.eof_reached():
    var line := file.get_line().strip_edges()
    if line.is_empty():
        continue
    var parts := line.split(",")
    scores.append({"name": parts[0], "score": int(parts[1])})
```

### Binary Files and store\_var

`store_var()` / `get_var()` is Godot's built-in variant serialisation. It handles almost every GDScript type — Dictionaries, Arrays, all numeric types, Vector2/3, Color, NodePath, etc. It is the fastest way to persist structured data without writing a serialiser yourself.

```gdscript
## Save a Dictionary using store_var
func save_data(data: Dictionary) -> void:
    var file := FileAccess.open("user://data.bin", FileAccess.WRITE)
    file.store_var(data)

## Load it back
func load_data() -> Dictionary:
    if not FileAccess.file_exists("user://data.bin"):
        return {}
    var file := FileAccess.open("user://data.bin", FileAccess.READ)
    var data = file.get_var()
    if data is Dictionary:
        return data
    return {}
```

:::callout-warning[Warning — never use allow\_objects=true on untrusted files]
`get_var(true)` can instantiate arbitrary Godot objects from the file. If the save file comes from the internet or could be modified by a player, this is a code execution vulnerability. Only use `allow_objects=false` (the default) for save data.
:::

## JSON

JSON is the right choice when save data needs to be human-readable (players can edit their own saves), portable (other tools or servers might read it), or versioned in a way that's easy to inspect in a diff. The trade-off is that JSON is slightly slower to parse than binary, and Godot-specific types (Vector2, Color, NodePath) don't have standard JSON representations — you must convert them manually.

### Serialising to JSON

```gdscript
var save_data := {
    "version": 2,
    "player_name": "Alice",
    "health": 85,
    "position": {"x": 128.5, "y": 64.0},   # Vector2 as dict
    "inventory": ["sword", "shield", "potion"],
    "flags": {"boss_defeated": true, "secret_found": false}
}

var json_string := JSON.stringify(save_data, "\t")  # "\t" = pretty-print
var file := FileAccess.open("user://save.json", FileAccess.WRITE)
file.store_string(json_string)
```

`JSON.stringify(value, indent, sort_keys)`:

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | Variant | — | The data to serialise. Must be JSON-compatible (Dictionary, Array, String, float, bool, null). |
| `indent` | String | `""` | Indentation per level. `"\t"` for tabs, `" "` for 2 spaces, `""` for compact. |
| `sort_keys` | bool | `false` | Sort Dictionary keys alphabetically. Useful for deterministic diffs. |
| `full_precision` | bool | `false` | Use full double precision for floats (more digits, larger file). |

### Parsing JSON

```gdscript
func load_save() -> Dictionary:
    if not FileAccess.file_exists("user://save.json"):
        return {}

    var text := FileAccess.get_file_as_string("user://save.json")
    var json  := JSON.new()
    var err   := json.parse(text)

    if err != OK:
        push_error("JSON parse error at line %d: %s" % [json.get_error_line(), json.get_error_message()])
        return {}

    var data = json.get_data()
    if not data is Dictionary:
        push_error("Expected a JSON object, got: " + str(typeof(data)))
        return {}

    return data as Dictionary
```

Static shorthand (Godot 4.1+) — skip the `JSON` object when you don't need error details:

```gdscript
var data = JSON.parse_string(text)
# Returns null if parsing fails; returns the parsed value otherwise
```

:::callout-tip[Converting Godot types to/from JSON]
JSON has no Vector2, Color, or NodePath. Use these patterns:

```gdscript
# Vector2 → JSON
func v2_to_json(v: Vector2) -> Dictionary:
    return {"x": v.x, "y": v.y}

# JSON → Vector2
func json_to_v2(d: Dictionary) -> Vector2:
    return Vector2(d["x"], d["y"])

# Color → JSON (as hex string)
func color_to_json(c: Color) -> String:
    return c.to_html()

# JSON → Color
func json_to_color(s: String) -> Color:
    return Color.html(s)
```
:::

## ConfigFile

`ConfigFile` reads and writes INI-style files organised into **sections** containing **key = value** pairs. It is not for save game data — it is specifically designed for user settings (graphics quality, audio volumes, keybindings) that are logically grouped.

Example file it produces (`user://settings.cfg`):

```ini
[graphics]
fullscreen=false
resolution_width=1920
resolution_height=1080
vsync=true

[audio]
master_volume=0.8
sfx_volume=1.0
music_volume=0.7
```

### Writing a ConfigFile

| Method | Description |
| --- | --- |
| set\_value(section, key, value) | Set a key in a section. Creates both if they don't exist. |
| save(path) | Write the in-memory config to disk. Returns an `Error`. |
| save\_encrypted\_pass(path, password) | Encrypt with a password before writing. |

```gdscript
var cfg := ConfigFile.new()
cfg.set_value("graphics", "fullscreen",        false)
cfg.set_value("graphics", "resolution_width",  1920)
cfg.set_value("graphics", "resolution_height", 1080)
cfg.set_value("graphics", "vsync",             true)
cfg.set_value("audio",    "master_volume",     0.8)
cfg.set_value("audio",    "sfx_volume",        1.0)
cfg.set_value("audio",    "music_volume",      0.7)

var err := cfg.save("user://settings.cfg")
if err != OK:
    push_error("Could not save settings: " + error_string(err))
```

### Reading a ConfigFile

| Method | Description |
| --- | --- |
| load(path) | Load from disk into memory. Returns `Error`; check `== OK`. |
| get\_value(section, key, default) | Read a value. Returns `default` if the section/key doesn't exist. |
| has\_section(section) | Check if a section exists. |
| has\_section\_key(section, key) | Check if a specific key exists within a section. |
| get\_sections() | Returns a `PackedStringArray` of all section names. |
| get\_section\_keys(section) | Returns all keys in a section. |
| erase\_section(section) | Remove a section and all its keys. |
| erase\_section\_key(section, key) | Remove a single key. |

```gdscript
func load_settings() -> void:
    var cfg := ConfigFile.new()
    var err  := cfg.load("user://settings.cfg")
    if err != OK:
        # File may not exist yet on first run — use defaults
        return

    var fullscreen := cfg.get_value("graphics", "fullscreen", false)
    var width      := cfg.get_value("graphics", "resolution_width",  1920)
    var height     := cfg.get_value("graphics", "resolution_height", 1080)
    var master_vol := cfg.get_value("audio", "master_volume", 1.0)

    DisplayServer.window_set_mode(
        DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen
        else DisplayServer.WINDOW_MODE_WINDOWED
    )
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index("Master"),
        linear_to_db(master_vol)
    )
```

:::callout-key[ConfigFile stores any Variant]
`set_value()` accepts *any* GDScript Variant — including Vector2, Color, Array, Dictionary. Unlike JSON, these are round-tripped correctly without manual conversion. The saved text uses Godot's own serialisation syntax, which is why the file is partially human-readable but not standard JSON.
:::

## ResourceSaver & ResourceLoader

Godot's Resource system goes beyond file I/O — a `Resource` subclass is a first-class Godot object with exported properties, signals, and methods, and it can reference other Resources. `ResourceSaver` serialises these to `.tres` (text, human-readable) or `.res` (binary, faster to load). `ResourceLoader` loads them back.

### When to Use Resources for Save Data

Resources are the right choice when your data maps naturally to a class — a `PlayerStats` resource with `@export` variables, a `QuestState` resource, or an `InventoryItem` resource. They are *not* the right choice for a flat save game dictionary with dynamic keys.

### Defining a Custom Resource

```gdscript
# player_stats.gd
class_name PlayerStats
extends Resource

@export var player_name: String = "Hero"
@export var health:      int    = 100
@export var max_health:  int    = 100
@export var level:       int    = 1
@export var experience:  int    = 0
@export var gold:        int    = 0
@export var position:    Vector2 = Vector2.ZERO
```

### Saving a Resource

```gdscript
func save_player(stats: PlayerStats) -> void:
    var err := ResourceSaver.save(stats, "user://player.tres")
    if err != OK:
        push_error("Could not save player: " + error_string(err))
```

**ResourceSaver.save() flags** (third argument, bitfield):

| Flag | Description |
| --- | --- |
| `ResourceSaver.FLAG_RELATIVE_PATHS` | Store sub-resource paths relative to the save file. |
| `ResourceSaver.FLAG_BUNDLE_RESOURCES` | Inline sub-resources instead of referencing them by path. |
| `ResourceSaver.FLAG_COMPRESS` | Compress the output (binary format only). |
| `ResourceSaver.FLAG_OMIT_EDITOR_PROPERTIES` | Strip editor-only metadata from the saved file. |

### Loading a Resource

```gdscript
func load_player() -> PlayerStats:
    if not FileAccess.file_exists("user://player.tres"):
        return PlayerStats.new()    # return defaults on first run

    var stats = ResourceLoader.load("user://player.tres")
    if stats is PlayerStats:
        return stats
    push_error("Unexpected resource type in player.tres")
    return PlayerStats.new()

## Async loading (for large resources — prevents frame hitches):
func load_player_async() -> void:
    ResourceLoader.load_threaded_request("user://player.tres")
    # Later, in _process():
    var status := ResourceLoader.load_threaded_get_status("user://player.tres")
    if status == ResourceLoader.THREAD_LOAD_LOADED:
        var stats = ResourceLoader.load_threaded_get("user://player.tres")
```

:::callout-pitfall[Pitfall — class\_name must match on load]
When you load a `.tres` file, Godot reconstructs the object from the class name stored in the file header. If you rename the class or move the script without updating the `.tres` files, loading will fail with a "class not found" error. Keep your custom Resource script paths and class names stable, or write a migration function that handles the version difference.
:::

## Method Comparison

| Criterion | FileAccess (raw) | JSON | ConfigFile | ResourceSaver |
| --- | --- | --- | --- | --- |
| Human-readable? | Depends on format | ✓ Yes | ✓ Yes (INI) | ✓ (.tres), ✗ (.res) |
| Godot types? | Manual conversion | Manual conversion | ✓ Native | ✓ Native |
| Dynamic keys? | ✓ | ✓ | ✓ | ✗ (needs @export) |
| Encryption? | Manual | Manual | Built-in password | ✗ |
| Binary option? | Always | ✗ | ✗ | ✓ (.res) |
| Best for | Custom binary formats, high-frequency writes | Save game data, server exchange | User settings | Typed game data, level configs |

## Practice Problems

:::problem
#### A — Write and Read a Text Log easy

Write a function `append_log_entry(message: String)` that appends a timestamped line to `user://game.log` without truncating the existing contents. Each line should look like: `[2026-05-28 14:32:01] Player entered cave`. Then write `read_log() -> String` that returns the entire file as a single string.

::::solution[Solution]
```gdscript
func append_log_entry(message: String) -> void:
    var file := FileAccess.open("user://game.log", FileAccess.READ_WRITE \
                if FileAccess.file_exists("user://game.log") \
                else FileAccess.WRITE)
    if file == null:
        return
    file.seek_end(0)   # move to end before appending
    var timestamp := Time.get_datetime_string_from_system()
    file.store_line("[%s] %s" % [timestamp, message])

func read_log() -> String:
    if not FileAccess.file_exists("user://game.log"):
        return ""
    return FileAccess.get_file_as_string("user://game.log")
```
::::
:::

:::problem
#### B — JSON Save/Load Round-trip standard

Write `save_game(data: Dictionary) -> void` and `load_game() -> Dictionary`. The save function stores the dictionary as pretty-printed JSON to `user://save.json`. The load function parses it back, returning an empty dictionary and printing a warning if the file doesn't exist or the JSON is malformed. Include a `"version": 1` key in the saved data.

::::solution[Solution]
```gdscript
const SAVE_PATH := "user://save.json"

func save_game(data: Dictionary) -> void:
    data["version"] = 1
    var text := JSON.stringify(data, "\t", true)
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_error("Cannot open save file for writing")
        return
    file.store_string(text)

func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        push_warning("No save file found — returning defaults")
        return {}
    var text := FileAccess.get_file_as_string(SAVE_PATH)
    var json  := JSON.new()
    if json.parse(text) != OK:
        push_error("Save file corrupted at line %d" % json.get_error_line())
        return {}
    var d = json.get_data()
    return d if d is Dictionary else {}
```
::::
:::

:::problem
#### C — Settings Manager with Defaults standard

Write a class `SettingsManager` (suitable for an Autoload) that holds a `ConfigFile` and exposes three methods: `load_or_defaults()` (load from disk or populate with defaults), `set_setting(section, key, value)` (set and immediately save), and `get_setting(section, key, default)`. Defaults: `graphics/fullscreen = false`, `graphics/vsync = true`, `audio/master = 1.0`.

::::solution[Solution]
```gdscript
class_name SettingsManager
extends Node

const PATH := "user://settings.cfg"
var _cfg := ConfigFile.new()

func load_or_defaults() -> void:
    if _cfg.load(PATH) != OK:
        _cfg.set_value("graphics", "fullscreen", false)
        _cfg.set_value("graphics", "vsync",      true)
        _cfg.set_value("audio",    "master",      1.0)
        _cfg.save(PATH)

func set_setting(section: String, key: String, value: Variant) -> void:
    _cfg.set_value(section, key, value)
    _cfg.save(PATH)

func get_setting(section: String, key: String, default: Variant = null) -> Variant:
    return _cfg.get_value(section, key, default)
```
::::
:::

:::problem
#### D — Custom Resource Save/Load standard

Define a `QuestState` resource with `@export` variables: `quest_id: String`, `completed: bool`, `objectives_done: int`, and `objectives_total: int`. Write `save_quest(q: QuestState)` that saves to `user://quest_{q.quest_id}.tres`, and `load_quest(id: String) -> QuestState` that loads it back (returning a new default `QuestState` with the given id if the file doesn't exist).

::::solution[Solution]
```gdscript
# quest_state.gd
class_name QuestState
extends Resource

@export var quest_id:         String = ""
@export var completed:        bool   = false
@export var objectives_done:  int    = 0
@export var objectives_total: int    = 1

# ---

func save_quest(q: QuestState) -> void:
    var path := "user://quest_%s.tres" % q.quest_id
    var err  := ResourceSaver.save(q, path)
    if err != OK:
        push_error("Failed to save quest %s: %s" % [q.quest_id, error_string(err)])

func load_quest(id: String) -> QuestState:
    var path := "user://quest_%s.tres" % id
    if not FileAccess.file_exists(path):
        var q := QuestState.new()
        q.quest_id = id
        return q
    var res = ResourceLoader.load(path)
    if res is QuestState:
        return res
    push_error("Unexpected type in " + path)
    return QuestState.new()
```
::::
:::

:::problem
#### E — Delete Old Save Files challenge

Write a function `purge_old_saves(max_age_days: int)` that lists all files in `user://saves/`, checks each file's modification time, and deletes any file older than `max_age_days` days. Use `FileAccess.get_modified_time(path)` (returns a Unix timestamp as int) and `Time.get_unix_time_from_system()` for the current time.

::::solution[Solution]
```gdscript
func purge_old_saves(max_age_days: int) -> void:
    var dir := DirAccess.open("user://saves/")
    if dir == null:
        return

    var cutoff := int(Time.get_unix_time_from_system()) - max_age_days * 86400

    dir.list_dir_begin()
    var name := dir.get_next()
    while name != "":
        if not dir.current_is_dir():
            var full_path := "user://saves/" + name
            var mtime     := FileAccess.get_modified_time(full_path)
            if mtime < cutoff:
                DirAccess.remove_absolute(
                    ProjectSettings.globalize_path(full_path)
                )
                print("Deleted old save: ", name)
        name = dir.get_next()
```

Note: `DirAccess.remove_absolute()` requires an OS absolute path, hence the `ProjectSettings.globalize_path()` call to convert the `user://` path.
::::
:::
