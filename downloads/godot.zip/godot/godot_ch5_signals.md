---
title: "Signals & Inter-Node Communication"
crumb: "Godot 4.6 Complete Reference · Part I · Chapter 5"
meta:
  - "Est. study time: ~75 min"
  - "Part I — Foundations"
  - "Updated May 2026"
source: "godot_ch5_signals.html"
---

## Overview

Nodes need to talk to each other constantly: a button tells a menu to open, a
 bullet tells an enemy it was hit, a timer tells the world to spawn the next wave.
 You need a mechanism to pass these events between nodes *without* creating
 hard-coded dependency chains.

Godot's answer is **signals** — a first-class, built-in implementation
 of the Observer design pattern. This chapter covers everything about them: declaring,
 emitting, connecting, passing arguments, removing connections, and organising
 project-wide events with the Event Bus pattern.

:::callout-key[Prerequisites]
- Chapters 1–4: you can create scenes, attach scripts, and write GDScript.
- Basic understanding of functions and method calls.
:::

## 1. Why Signals Exist

### The Observer Pattern

The Observer pattern says: an object (*the subject*) maintains a list of
 dependents (*observers*) and notifies them automatically when something
 interesting happens. The subject never needs to know who is listening — or even
 whether anyone is. Observers subscribe when they care; they unsubscribe when they
 don't.

In Godot's terms: a node **emits** a signal when an event occurs.
 Any number of other nodes that have **connected** to that signal have
 a nominated method called automatically. The emitter knows nothing about its
 receivers.

```
Button  ─── emits ───▶  pressed  ─── triggers ───▶  MainMenu._on_play_pressed()
Timer   ─── emits ───▶  timeout  ─── triggers ───▶  Spawner._on_wave_timeout()
Area2D  ─── emits ───▶  body_entered(body)  ─ triggers ──▶  Coin._on_body_entered(body)

```

Enemy

(emitter)

signal died(points)

died

(points: int)

emit\_signal()

ScoreBoard

\_on\_enemy\_died(pts)

SoundManager

\_on\_enemy\_died(pts)

… any future listener

Enemy knows nothing

about its listeners

The emitter fires the signal once. Every connected receiver is called automatically — in the order they connected. Adding a new listener never changes Enemy's code.

### Signals vs Direct Calls — When to Use Which

You *could* have Button call `main_menu.start_game()` directly.
 The problem: Button now holds a typed reference to MainMenu. If you rename
 `start_game()`, move MainMenu, or reuse Button in a different scene,
 you must update Button's script too. The nodes are *tightly coupled*.

With signals, Button just emits `pressed` into the void. The parent
 scene wires the connection. Button's script stays unchanged no matter where it's
 used — it's *decoupled*.

:::callout-intuition[The golden rule]
Signals flow **upward or sideways** in the scene tree. A child
 should never call a method on its parent directly. Instead it emits a signal
 and lets the parent decide how to respond. Direct calls are fine for a parent
 telling a child what to do (the parent owns the child and knows its API).
:::

| Situation | Prefer | Why |
| --- | --- | --- |
| Child notifying parent of an event | Signal | Child stays reusable; parent stays decoupled |
| Parent telling child to do something | Direct call | Parent owns child — coupling is intentional |
| Two unrelated subtrees communicating | Signal / Event Bus | Neither knows about the other's existence |
| One event → many possible listeners | Signal | Emitter doesn't need to know listener count |
| Synchronous return value required | Direct call | Signals don't return values to the emitter |

## 2. Built-in Signals

Most Godot node types declare signals automatically. You don't write them — they
 already exist on the node class and appear in the documentation and the editor.

### Finding Signals in the Editor

Select any node in the Scene dock, then click the **Node** tab in
 the Inspector panel (the tab immediately to the right of "Inspector"). You'll see
 every signal that node can emit, grouped by class. Click the green **Connect…**
 button next to any signal to open the connection dialog.

:::callout-tip[Also check the documentation]
Press F1 in the editor (or Help → Search Help) and search for a
 node class like `Area2D`. The class reference lists every signal with
 its full argument signature and a description. This is the authoritative source —
 Godot's docs are generated directly from the engine source.
:::

### Common Built-in Signals

| Node | Signal | When emitted |
| --- | --- | --- |
| `BaseButton` | `pressed` | Mouse released over button or keyboard confirm |
| `BaseButton` | `toggled(button_pressed: bool)` | Toggle state changed |
| `BaseButton` | `button_down` / `button_up` | Press started / released (before `pressed`) |
| `Timer` | `timeout` | Countdown reaches zero |
| `Area2D` | `body_entered(body: Node2D)` | A PhysicsBody2D overlaps the area |
| `Area2D` | `body_exited(body: Node2D)` | Overlap ends |
| `Area2D` | `area_entered(area: Area2D)` | Another Area2D overlaps |
| `RigidBody2D` | `body_entered(body: Node)` | Collision detected (contact monitor on, max > 0) |
| `AnimationPlayer` | `animation_finished(anim_name: StringName)` | Playback reaches the end |
| `AnimationPlayer` | `animation_started(anim_name: StringName)` | Playback begins |
| `LineEdit` | `text_submitted(new_text: String)` | Enter pressed in text field |
| `LineEdit` | `text_changed(new_text: String)` | Text content changes each keystroke |
| `SceneTree` | `node_added(node: Node)` | Any node enters the tree |
| `SceneTree` | `process_frame` | Each frame (after all \_process calls) |
| `Node` | `tree_entered` / `tree_exiting` | Node enters / is about to leave the tree |
| `HTTPRequest` | `request_completed(result, code, headers, body)` | HTTP response received |

## 3. Custom Signals

### Declaring and Emitting

Use the `signal` keyword at class level — not inside a function. The
 declaration creates a `Signal` object accessible as a property of
 `self`.

```gdscript
extends CharacterBody2D

# No arguments — just a notification that something happened
signal died

# Arguments — the signal carries data to every listener
signal health_changed(new_health: int, max_health: int)
signal item_collected(item_name: String, position: Vector2)

# Typed return types are NOT supported on signals — signals don't return values
```

Emit using the signal object's `.emit()` method. Pass arguments in
 the same order as the declaration:

```gdscript
extends CharacterBody2D

signal died
signal health_changed(new_health: int, max_health: int)

@export var max_health: int = 100
var health: int = 100

func take_damage(amount: int) -> void:
    health = max(0, health - amount)
    health_changed.emit(health, max_health)   # emit BEFORE freeing the node

    if health == 0:
        died.emit()
        queue_free()   # safe — queue_free defers deletion to end of frame
```

:::callout-warning[Emit order matters]
Always emit signals *before* calling `queue_free()` or
 `free()`. Emission after freeing the node can still work in the same
 frame, but any connected receiver that calls back into the freed node will crash.
 The safe pattern: signal first, then free.
:::

### Typed Signals and the Signal Object

In Godot 4, every declared signal becomes a `Signal` typed property.
 You can store it in a variable, pass it as a function argument, or check
 `is_connected()` on it. This is a major improvement over Godot 3's
 string-based system.

```gdscript
extends Node

signal player_died
signal score_changed(new_score: int)

func _ready() -> void:
    # Signal object is accessed like any other property
    print(player_died)             # Signal(<player_died>)
    print(player_died.get_name())  # "player_died"

    # You can pass a signal to a helper function
    _connect_one_shot(player_died, _on_player_died)

func _connect_one_shot(sig: Signal, callable: Callable) -> void:
    sig.connect(callable, CONNECT_ONE_SHOT)

func _on_player_died() -> void:
    print("Player died — this fires exactly once")
```

:::example[Worked Example — Coin Pickup]
A `Coin` Area2D emits `collected(value: int)` when the
 player touches it. The coin and the HUD have zero knowledge of each other — the
 parent Main scene wires the connection.

```gdscript
# Coin.gd — knows nothing about HUD or score
extends Area2D

signal collected(value: int)

@export var coin_value: int = 10

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        collected.emit(coin_value)
        queue_free()
```

```gdscript
# HUD.gd — knows nothing about coins
extends CanvasLayer

@onready var score_label: Label = $ScoreLabel
var score: int = 0

func add_score(amount: int) -> void:
    score += amount
    score_label.text = "Score: %d" % score
```

```gdscript
# Main.gd — the scene that owns both; it does the wiring
extends Node2D

@onready var hud: HUD = $HUD

func _spawn_coin(pos: Vector2) -> void:
    var coin: Coin = preload("res://scenes/coin.tscn").instantiate()
    add_child(coin)
    coin.position = pos
    # Wire the signal AFTER add_child
    coin.collected.connect(hud.add_score)
```

::::answer[Why this works]
`hud.add_score` is a `Callable` — a reference to the
 `add_score` method on the `hud` instance. When the coin
 emits `collected(10)`, Godot calls `hud.add_score(10)`
 automatically. Coin and HUD never reference each other.
::::
:::

## 4. Connecting Signals

### Editor Connection

The editor connection workflow is perfect for signals between nodes that are always
 in the same scene together. It produces a persistent connection stored in the
 `.tscn` file — no code required.

1. Select the **emitter** node in the Scene dock.
2. Open the **Node** tab in the Inspector (next to "Inspector").
3. Double-click the signal you want (e.g., `pressed`).
4. In the dialog, choose the **receiver** node in the tree.
5. Edit the method name if needed (default: `_on_NodeName_signal_name`).
6. Click **Connect**. Godot creates a stub method in the receiver's script.

Editor connections show a green plug icon (🔌) next to the signal in the Node tab.
 They're saved in the `.tscn` as connection metadata, so they survive
 re-opening the project.

Inspector — Node — Groups

Signals

▷ — draw()

🔌 — pressed() — connected

▷ — toggled(button\_pressed)

Double-click a signal to open the Connect dialog → pick receiver node → click Connect

The **Node tab** (next to Inspector) lists every signal a node can emit. The 🔌 icon marks an already-connected signal. Double-click any signal to open the connection dialog.

:::callout-tip[Naming convention]
The convention is `_on_EmitterName_signal_name`, e.g.
 `_on_Button_pressed` or `_on_Timer_timeout`. The leading
 underscore means "private" and the name makes it immediately clear why the method
 exists. You can name it anything, but this convention is universally understood.
:::

### Code Connection

Use code connections when nodes are created at runtime (instanced PackedScenes),
 when the connection is conditional, or when you need to pass extra arguments.

```gdscript
extends Node2D

@onready var timer: Timer = $Timer
@onready var hud: CanvasLayer = $HUD

func _ready() -> void:
    # Basic code connection — shortest form when receiver is self
    timer.timeout.connect(_on_wave_timer_timeout)

    # Explicit Callable form — equivalent, useful for connecting to other nodes
    timer.timeout.connect(Callable(hud, "_on_timer_timeout"))

    # Or the cleaner Godot 4 syntax (method reference on an instance)
    timer.timeout.connect(hud._on_timer_timeout)

func _on_wave_timer_timeout() -> void:
    spawn_next_wave()
```

The most common code-connection scenario: you spawn an enemy at runtime and
 want to be notified when it dies.

```gdscript
extends Node2D

@export var enemy_scene: PackedScene
@onready var hud: CanvasLayer = $HUD

var total_kills: int = 0

func spawn_enemy(spawn_pos: Vector2) -> void:
    var enemy: CharacterBody2D = enemy_scene.instantiate()
    add_child(enemy)              # add BEFORE connecting
    enemy.position = spawn_pos
    # Connect AFTER add_child — node is now fully in the tree
    enemy.died.connect(_on_enemy_died)
    enemy.health_changed.connect(hud._on_enemy_health_changed)

func _on_enemy_died() -> void:
    total_kills += 1
    hud.update_kill_count(total_kills)
```

:::callout-warning[Connect after add\_child]
You can connect signals before `add_child()`, but receiver methods
 that access scene-tree state (like `$SomeChild` or
 `@onready` vars) will fail because the node isn't in the tree yet.
 The safe rule: `add_child()` first, then `.connect()`.
:::

### Lambda (Anonymous) Connections

For short, one-off responses that don't need a named method, a lambda keeps the
 logic right next to the connection declaration:

```gdscript
func _ready() -> void:
    # Lambda for simple inline logic
    $PlayButton.pressed.connect(func():
        $MainMenu.hide()
        $GameWorld.show()
    )

    # Lambda with a captured local variable
    var level_id: int = 3
    $StartButton.pressed.connect(func(): load_level(level_id))

    # Equivalent to writing a named method and connecting to it,
    # but keeps related code co-located when the logic is short
```

:::callout-pitfall[Lambdas and memory leaks]
A lambda that captures an outer variable (like `level_id` above)
 holds a reference to that variable's value. If the lambda is connected to a
 long-lived signal and the captured object is large or holds external resources,
 it won't be freed until the connection is removed. For long-lived connections,
 prefer named methods so the lifetime is easier to reason about.
:::

## 5. Signal Arguments & .bind()

Signal arguments flow directly from the emitter's `.emit()` call into
 the connected method's parameters. The receiver method must accept the same number
 and types of arguments (or fewer — extra arguments can be absorbed with
 `.bind()`).

```gdscript
## Emitter — Player.gd
signal health_changed(new_health: int, max_health: int)
signal weapon_fired(bullet_speed: float, direction: Vector2, damage: int)

func take_damage(amount: int) -> void:
    health = max(0, health - amount)
    health_changed.emit(health, max_health)
```

```gdscript
## Receiver — HUD.gd
func _ready() -> void:
    var player: Player = get_tree().get_first_node_in_group("player")
    player.health_changed.connect(_on_health_changed)

# Parameters match the signal's argument list exactly
func _on_health_changed(new_health: int, max_health: int) -> void:
    $HealthBar.value = float(new_health) / float(max_health) * 100.0
    $HealthLabel.text = "%d / %d" % [new_health, max_health]
    if new_health < max_health * 0.25:
        $HealthBar.modulate = Color.RED
    else:
        $HealthBar.modulate = Color.WHITE
```

### Adding Extra Arguments with .bind()

`Callable.bind(...)` returns a new Callable that, when invoked, appends
 the bound values as *extra arguments after* any arguments provided by the
 signal. This lets you reuse a single handler for multiple emitters:

```gdscript
extends Node2D

# Four direction buttons, each connected to the same handler
func _ready() -> void:
    $BtnUp.pressed.connect(_on_direction_pressed.bind(Vector2.UP))
    $BtnDown.pressed.connect(_on_direction_pressed.bind(Vector2.DOWN))
    $BtnLeft.pressed.connect(_on_direction_pressed.bind(Vector2.LEFT))
    $BtnRight.pressed.connect(_on_direction_pressed.bind(Vector2.RIGHT))

# 'pressed' has no arguments; bind injects direction as the only argument
func _on_direction_pressed(direction: Vector2) -> void:
    player.move(direction)
```

```gdscript
## Loop example — inventory slots
func _ready() -> void:
    for i in range($SlotContainer.get_child_count()):
        var slot: Button = $SlotContainer.get_child(i)
        # 'pressed' has no args; bind injects i
        slot.pressed.connect(_on_slot_pressed.bind(i))

func _on_slot_pressed(slot_index: int) -> void:
    select_inventory_slot(slot_index)
```

:::example[Worked Example — Floating Damage Numbers]
When an enemy takes damage, spawn a floating number above it. The enemy emits
 `damage_taken(amount: int)`. We use `.bind(enemy)` to inject
 the source node alongside the amount, so the handler knows where to position
 the label.

```gdscript
# Enemy.gd
signal damage_taken(amount: int)

func take_hit(amount: int) -> void:
    health -= amount
    damage_taken.emit(amount)
    if health <= 0: die()
```

```gdscript
# World.gd
@export var damage_label_scene: PackedScene

func _spawn_enemy(pos: Vector2) -> void:
    var enemy: Enemy = preload("res://enemy.tscn").instantiate()
    add_child(enemy)
    enemy.position = pos
    # signal emits (amount: int), bind appends enemy as second arg
    enemy.damage_taken.connect(_show_damage_number.bind(enemy))

func _show_damage_number(amount: int, source: Enemy) -> void:
    var lbl: Label = damage_label_scene.instantiate()
    add_child(lbl)
    lbl.text = str(amount)
    lbl.global_position = source.global_position + Vector2(0, -40)
    # tween lbl upward and fade, then queue_free — left as exercise
```

::::answer[Argument order with bind]
The signal's own arguments (`amount: int`) always come first. Bound
 values are appended after. So the handler receives `(amount, enemy)`
 in that order, even though `enemy` was bound at connection time.
::::
:::

## 6. Connection Flags: ONE\_SHOT & DEFERRED

The second argument to `connect()` is an optional flags bitmask.
 Two flags are especially important in day-to-day Godot development.

| Flag constant | Effect |
| --- | --- |
| `CONNECT_ONE_SHOT` | Automatically disconnect after the signal fires once |
| `CONNECT_DEFERRED` | Queue the method call to run at the end of the frame (safe during physics) |
| `CONNECT_PERSIST` | Save connection to the .tscn file (editor uses this automatically) |
| `CONNECT_REFERENCE_COUNTED` | Don't disconnect until disconnect() is called the same number of times as connect() |

Combine flags with bitwise OR: `CONNECT_ONE_SHOT | CONNECT_DEFERRED`.

### CONNECT\_ONE\_SHOT

Use `CONNECT_ONE_SHOT` whenever you want to respond to exactly one
 emission and then stop listening. Classic uses: "wait for the intro animation to
 finish", "do this once when the player enters the area for the first time".

```gdscript
extends Node2D

func _ready() -> void:
    $AnimPlayer.play("intro")
    # Connect — fires once when intro finishes, then auto-disconnects
    $AnimPlayer.animation_finished.connect(
        _on_intro_done,
        CONNECT_ONE_SHOT
    )

func _on_intro_done(anim_name: StringName) -> void:
    $SkipButton.hide()
    $HUD.show()
    _start_gameplay()

# ---- Lambda variant (same result) ----
func _ready_v2() -> void:
    $AnimPlayer.play("intro")
    $AnimPlayer.animation_finished.connect(
        func(_name: StringName): _start_gameplay(),
        CONNECT_ONE_SHOT
    )
```

### CONNECT\_DEFERRED

Godot's physics engine locks the scene tree during collision callbacks. If you try
 to call `queue_free()`, `add_child()`, or
 `remove_child()` directly inside `body_entered` or
 `_physics_process()`, Godot prints a warning and the change may be
 ignored. `CONNECT_DEFERRED` defers the method call to the end of the
 frame, after physics has finished.

```gdscript
extends Area2D

signal hit(damage: int, position: Vector2)

@export var damage: int = 10

func _ready() -> void:
    # Without DEFERRED: body_entered fires mid-physics, add_child is unsafe
    # With DEFERRED: handler runs after the physics step — safe for tree changes
    body_entered.connect(_on_body_entered, CONNECT_DEFERRED)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("enemy"):
        hit.emit(damage, global_position)
        queue_free()   # queue_free is always deferred by design
```

:::callout-tip[queue\_free is always safe]
`queue_free()` never crashes even inside a physics callback because
 Godot defers the actual deletion. What's *not* safe is
 `add_child()` or `remove_child()` mid-physics — those
 need `CONNECT_DEFERRED` or an explicit `call_deferred()`.
:::

### Disconnecting Manually

Call `disconnect()` with the exact same callable used to connect.
 Check `is_connected()` first if re-connection is possible:

```gdscript
## Basic disconnect
func _on_enemy_died() -> void:
    if $Enemy.died.is_connected(_on_enemy_died):
        $Enemy.died.disconnect(_on_enemy_died)
    _tally_kill()

## Disconnect on exit — important for Event Bus connections (see Section 7)
func _exit_tree() -> void:
    EventBus.player_health_changed.disconnect(_on_health_changed)
    EventBus.score_changed.disconnect(_on_score_changed)
```

## 7. The Event Bus Pattern

Direct signal connections work perfectly when you know both nodes at design time.
 But what about an achievement system reacting to enemy kills scattered across
 five different enemy types? Or a save system that must know every time the
 player's stats change, regardless of which script changed them?

Traversing the tree to find references is fragile. The **Event Bus**
 solves this with an *Autoload singleton* that holds all project-wide signals.
 Any script can emit or listen without knowing anything about the other side.

### Step 1 — Create the Bus Script

```gdscript
# EventBus.gd  (add to Project → Project Settings → Autoload as "EventBus")
extends Node

# ── Player ────────────────────────────────────────────────────
signal player_died
signal player_respawned(position: Vector2)
signal player_health_changed(new_health: int, max_health: int)
signal player_level_up(new_level: int)

# ── Enemies ───────────────────────────────────────────────────
signal enemy_killed(enemy_type: String, position: Vector2, xp_value: int)
signal boss_phase_changed(boss_name: String, new_phase: int)

# ── Items / Inventory ─────────────────────────────────────────
signal item_picked_up(item_id: StringName, count: int)
signal inventory_full

# ── Game Flow ─────────────────────────────────────────────────
signal scene_transition_requested(scene_path: String)
signal game_paused(is_paused: bool)
signal score_changed(new_score: int, delta: int)

# ── UI ────────────────────────────────────────────────────────
signal show_notification(message: String, duration: float)
signal dialogue_started(speaker_name: String)
signal dialogue_ended
```

### Step 2 — Emit from Anywhere

```gdscript
# Player.gd — deep in the game world, no reference to HUD or achievements
extends CharacterBody2D

var health: int = 100:
    set(value):
        var clamped := clampi(value, 0, max_health)
        if clamped == health: return
        health = clamped
        EventBus.player_health_changed.emit(health, max_health)

var max_health: int = 100

func die() -> void:
    EventBus.player_died.emit()
    queue_free()
```

```gdscript
# Enemy.gd — also has no knowledge of achievements or HUD
extends CharacterBody2D

@export var enemy_type: String = "Goblin"
@export var xp_value: int = 25

func die() -> void:
    EventBus.enemy_killed.emit(enemy_type, global_position, xp_value)
    queue_free()
```

### Step 3 — Listen from Anywhere

```gdscript
# AchievementSystem.gd (Autoload — loads before any scene)
extends Node

var _kill_counts: Dictionary = {}

func _ready() -> void:
    EventBus.enemy_killed.connect(_on_enemy_killed)
    EventBus.player_level_up.connect(_on_level_up)
    EventBus.boss_phase_changed.connect(_on_boss_phase)

func _on_enemy_killed(enemy_type: String, _pos: Vector2, _xp: int) -> void:
    _kill_counts[enemy_type] = _kill_counts.get(enemy_type, 0) + 1
    if _kill_counts[enemy_type] == 100:
        _unlock_achievement("SLAYER_OF_%s" % enemy_type.to_upper())

func _unlock_achievement(id: String) -> void:
    print("Achievement unlocked: ", id)
    EventBus.show_notification.emit("Achievement: " + id, 3.0)
```

```gdscript
# HUD.gd — responds to the same bus events
extends CanvasLayer

func _ready() -> void:
    EventBus.player_health_changed.connect(_on_health_changed)
    EventBus.score_changed.connect(_on_score_changed)
    EventBus.show_notification.connect(_on_notification)

func _exit_tree() -> void:
    # IMPORTANT: always disconnect from the bus when leaving the tree
    EventBus.player_health_changed.disconnect(_on_health_changed)
    EventBus.score_changed.disconnect(_on_score_changed)
    EventBus.show_notification.disconnect(_on_notification)

func _on_health_changed(hp: int, max_hp: int) -> void:
    $HealthBar.value = float(hp) / float(max_hp) * 100.0

func _on_score_changed(new_score: int, _delta: int) -> void:
    $ScoreLabel.text = "Score: %d" % new_score

func _on_notification(message: String, duration: float) -> void:
    $NotificationLabel.text = message
    $NotificationLabel.show()
    await get_tree().create_timer(duration).timeout
    $NotificationLabel.hide()
```

:::callout-warning[Always disconnect from the bus in \_exit\_tree]
The Event Bus is an Autoload — it outlives every scene. If a HUD node connects
 to bus signals in `_ready()` and the HUD is freed (scene change,
 level restart), the bus still holds a reference to the old callable. The next
 signal emission will crash with "Attempting to call a method on a freed object."
 Disconnect in `_exit_tree()` every time.
:::

:::callout-intuition[Keep the bus lean]
Don't put every signal on the bus — only events that genuinely cross scene
 boundaries. Signals between nodes in the same scene should use direct
 connections. The bus is for "player died" (achievement + HUD + camera + music
 all react), not for "button pressed inside a menu" (handled locally).
:::

## 8. Common Pitfalls

### Pitfall 1 — Double Connection

Calling `connect()` twice with the same callable creates two
 connections. The handler fires twice per emission. This is easy to trigger when
 a node re-enters the tree (e.g., a pooled bullet reused by calling
 `add_child()` again) or when `_ready()` is called multiple
 times on a node that is removed and re-added.

```gdscript
# BAD — if the node is removed and re-added, _ready runs again, double-connecting
func _ready() -> void:
    $FireButton.pressed.connect(_on_fire)

# GOOD — guard with is_connected
func _ready() -> void:
    if not $FireButton.pressed.is_connected(_on_fire):
        $FireButton.pressed.connect(_on_fire)
```

:::callout-pitfall[A repeated connect is refused, not duplicated]
Connecting a callable that is already connected does *not* create a second
 connection. `connect()` returns `ERR_INVALID_PARAMETER` and
 Godot prints `Signal 'x' is already connected to given callable`;
 emitting once still calls the handler once. So the hazard is not double firing but
 the error spam, and the fix is the same: guard with `is_connected()`
 wherever re-connection is possible, or pass `CONNECT_ONE_SHOT` so the
 connection removes itself.
:::

### Pitfall 2 — Callback on a Freed Node

When a signal emits and the receiver has been freed, Godot usually handles it
 gracefully (it uses weak references internally). But if you capture a node
 reference inside a lambda or `.bind()`, and that node is freed before
 the signal fires, the lambda will try to call into freed memory and crash.

```gdscript
# DANGEROUS — enemy is captured in the lambda; enemy might be freed before firing
enemy.died.connect(func(): enemy.drop_loot())

# SAFE — capture only data (a LootTable Resource) that outlives the enemy node
enemy.died.connect(_on_enemy_died.bind(enemy.loot_table))

func _on_enemy_died(loot_table: LootTable) -> void:
    loot_table.roll_drops(get_tree().current_scene)
    # loot_table is a Resource (RefCounted) — it persists after the enemy is freed
```

### Pitfall 3 — Signal Spam (Emitting Every Frame)

Emitting a signal inside `_process()` or
 `_physics_process()` without a gate fires it 60+ times per second.
 Any connected handler that does non-trivial work (updating UI, saving data) will
 tank performance. Use a property setter with a change guard:

```gdscript
extends CharacterBody2D

signal health_changed(new_health: int, max_health: int)

var max_health: int = 100
var health: int = 100:
    set(value):
        var clamped := clampi(value, 0, max_health)
        if clamped == health:
            return         # identical value — skip the emit
        health = clamped
        health_changed.emit(health, max_health)

# Now: any code that does `health -= 5` automatically emits only if the value changed.
# Even if called 60x/s with the same value, the signal fires zero times.
```

### Pitfall 4 — Circular Signal Chains

Node A emits a signal → Node B's handler emits a signal → Node A's handler
 emits the first signal again → infinite recursion → stack overflow. Design signal
 flow as a directed acyclic graph. Break cycles with a re-entrancy guard:

```gdscript
var _updating: bool = false

func _on_slider_value_changed(value: float) -> void:
    if _updating:
        return
    _updating = true
    $NumberSpinBox.value = value   # this might re-trigger _on_slider_value_changed
    _updating = false
```

### Pitfall 5 — Connecting Before add\_child (Tree Access)

Connecting a signal before a node enters the tree is legal, but the receiver's
 `@onready` variables and `$NodePath` lookups won't work
 until `_ready()` has run. The safest pattern remains: spawn →
 `add_child()` → connect → start.

```gdscript
func spawn_enemy() -> void:
    var e: Enemy = enemy_scene.instantiate()
    # DON'T connect here — e's @onready vars aren't set yet
    add_child(e)
    # NOW connect — _ready() has fired, all @onready vars are valid
    e.died.connect(_on_enemy_died)
    e.start_patrol()
```

:::summary
## Chapter Summary

### Signal quick-reference

| Task | Code |
| --- | --- |
| Declare a signal | `signal my_signal(arg: Type)` |
| Emit a signal | `my_signal.emit(value)` |
| Connect (self) | `node.signal_name.connect(_handler)` |
| Connect (other node) | `node.signal_name.connect(other._handler)` |
| Connect with bound arg | `node.signal_name.connect(_handler.bind(extra))` |
| One-shot connection | `sig.connect(fn, CONNECT_ONE_SHOT)` |
| Deferred connection | `sig.connect(fn, CONNECT_DEFERRED)` |
| Check connected | `sig.is_connected(callable)` |
| Disconnect | `sig.disconnect(callable)` |
| Event Bus emit | `EventBus.some_signal.emit(...)` |
| Event Bus listen | `EventBus.some_signal.connect(_handler)` |

### If you remember nothing else

**Children emit; parents connect.** A child node should never
 call a method on its parent — it should emit a signal and let the parent
 respond. Use the Event Bus for cross-scene communication. Always disconnect
 from the Event Bus in `_exit_tree()`.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
What is the difference between `is_action_just_pressed` and
 `is_action_pressed`? When would you use each?

::::solution[Solution]
`is_action_pressed` returns `true` every frame the
 action is held down. `is_action_just_pressed` returns
 `true` only on the *first* frame the action began. Use
 `is_action_pressed` for movement (held keys). Use
 `is_action_just_pressed` for discrete events like jumping, firing,
 or opening menus — actions that should trigger exactly once per key-down.

*(Note: this question is about Input, not signals — but knowing the
 distinction matters because signals like `pressed` on Button behave
 like `is_action_just_pressed`, not held-key.)*
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
Declare a `Door.gd` script with two signals:
 `opened` (no arguments) and
 `lock_failed(reason: String)`. Write a
 `try_open(has_key: bool)` method that emits the appropriate signal
 depending on whether the door is locked and the player has the key.

::::solution[Solution]
```gdscript
extends Node3D

signal opened
signal lock_failed(reason: String)

@export var is_locked: bool = true

func try_open(has_key: bool) -> void:
    if not is_locked:
        opened.emit()
        _play_open_animation()
    elif has_key:
        is_locked = false
        opened.emit()
        _play_open_animation()
    else:
        lock_failed.emit("The door is locked. You need the key.")

func _play_open_animation() -> void:
    $AnimationPlayer.play("open")
```
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
You spawn 20 enemies at runtime using a loop. Each has a
 `signal died(drop_value: int)`. Connect all of them to a single
 `_on_enemy_died(drop_value: int)` handler, and track a running
 `total_gold` total. When all enemies are dead, emit a local
 `signal wave_cleared(wave_num: int)`.

::::solution[Solution]
```gdscript
extends Node2D

signal wave_cleared(wave_num: int)

@export var enemy_scene: PackedScene
var total_gold: int = 0
var _alive_count: int = 0
var _wave_number: int = 0

func spawn_wave(wave_num: int, count: int) -> void:
    _wave_number = wave_num
    _alive_count = count
    total_gold = 0
    for i in range(count):
        var e: CharacterBody2D = enemy_scene.instantiate()
        add_child(e)
        e.position = Vector2(randf_range(-300, 300), randf_range(-200, 200))
        e.died.connect(_on_enemy_died)

func _on_enemy_died(drop_value: int) -> void:
    total_gold += drop_value
    _alive_count -= 1
    if _alive_count <= 0:
        wave_cleared.emit(_wave_number)
```
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Write a `HealthBar.gd` node that uses the Event Bus to react to
 `EventBus.player_health_changed(new_health: int, max_health: int)`.
 The bar should update a `ProgressBar` child and change its modulate
 to red if below 25% health. Include proper connect/disconnect in
 `_ready` / `_exit_tree`.

::::solution[Solution]
```gdscript
extends CanvasLayer

@onready var bar: ProgressBar = $ProgressBar

func _ready() -> void:
    EventBus.player_health_changed.connect(_on_health_changed)

func _exit_tree() -> void:
    if EventBus.player_health_changed.is_connected(_on_health_changed):
        EventBus.player_health_changed.disconnect(_on_health_changed)

func _on_health_changed(new_hp: int, max_hp: int) -> void:
    var ratio: float = float(new_hp) / float(max_hp)
    bar.value = ratio * 100.0
    bar.modulate = Color.RED if ratio < 0.25 else Color.WHITE
```
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
Explain what goes wrong with this code and fix it:

```gdscript
func _ready() -> void:
    for i in range(5):
        var enemy: Enemy = enemy_scene.instantiate()
        add_child(enemy)
        enemy.died.connect(func(): _on_enemy_died(enemy))

func _on_enemy_died(e: Enemy) -> void:
    e.drop_loot()
```

::::solution[Solution]
The lambda captures the *variable* `enemy`, not a snapshot
 of its value. By the time any enemy dies, the loop has finished and
 `enemy` holds the last instantiated enemy. Every lambda will call
 `_on_enemy_died` with the same last enemy — and that enemy may
 have been freed, causing a crash.

**Fix:** use `.bind()` to capture the current value
 of `enemy` at connection time:

```gdscript
func _ready() -> void:
    for i in range(5):
        var enemy: Enemy = enemy_scene.instantiate()
        add_child(enemy)
        # bind(enemy) snapshots the current value of enemy
        enemy.died.connect(_on_enemy_died.bind(enemy))

func _on_enemy_died(e: Enemy) -> void:
    if is_instance_valid(e):
        e.drop_loot()
```
::::
:::

:::problem[Problem M.6 standard]{difficulty="standard"}
A `Bullet` (Area2D) fires a signal
 `hit(damage: int, hit_pos: Vector2)` when it enters an enemy, then
 calls `queue_free()`. The bullet is spawned in
 `_physics_process()`. You see Godot warning about "modifying the scene
 tree during physics". Fix it using the appropriate connection flag.

::::solution[Solution]
```gdscript
extends Area2D

signal hit(damage: int, hit_pos: Vector2)

@export var damage: int = 15
@export var speed: float = 800.0

func _ready() -> void:
    # CONNECT_DEFERRED: handler runs after physics step, safe for tree changes
    body_entered.connect(_on_body_entered, CONNECT_DEFERRED)

func _physics_process(delta: float) -> void:
    position += transform.x * speed * delta

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("enemy"):
        hit.emit(damage, global_position)
        queue_free()   # always safe — deferred by Godot internally
```
::::
:::

:::problem[Problem M.7 challenge]{difficulty="challenge"}
Build a **rebindable controls screen**.
 `ControlsScreen.gd` shows a `Button` labelled with the
 current key bound to the `"jump"` action. When the user clicks it,
 the button label changes to "Press a key…" and the screen listens for the
 next `InputEventKey`. If the user presses Escape, cancel and restore
 the label. Otherwise, rebind `"jump"` to the new key and update the
 label. The new binding must survive a call to
 `InputMap.load_from_project_settings()` — so also save it to a
 `Settings` resource.

::::solution[Solution]
```gdscript
# ControlsScreen.gd
extends Control

@onready var jump_btn: Button = $JumpButton
var _awaiting_input: bool = false

func _ready() -> void:
    _update_label()
    jump_btn.pressed.connect(_on_jump_btn_pressed)

func _update_label() -> void:
    for event in InputMap.action_get_events("jump"):
        if event is InputEventKey:
            jump_btn.text = "Jump: " + OS.get_keycode_string(event.keycode)
            return
    jump_btn.text = "Jump: (none)"

func _on_jump_btn_pressed() -> void:
    _awaiting_input = true
    jump_btn.text = "Press a key…"

func _input(event: InputEvent) -> void:
    if not _awaiting_input:
        return
    if not (event is InputEventKey and event.pressed):
        return
    get_viewport().set_input_as_handled()
    _awaiting_input = false

    if event.keycode == KEY_ESCAPE:
        _update_label()   # cancelled
        return

    # Rebind
    InputMap.action_erase_events("jump")
    InputMap.action_add_event("jump", event)
    _update_label()

    # Persist — assumes SaveSystem autoload with a Settings resource
    SaveSystem.settings.jump_key = event.keycode
    SaveSystem.save_settings()
```
::::
:::

---

Godot 4.6 Complete Reference · Part I — Foundations · Generated for self-study. Edit freely.
