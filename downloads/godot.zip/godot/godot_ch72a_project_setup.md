---
title: "Crowd Runner — Project Setup, Mobile Renderer & Portrait Config"
crumb: "Godot 4.6 Complete Reference · Part XIII · Chapter 72A"
meta:
  - "Est. study time: ~40 min"
  - "Part XIII — Complete Game Walkthroughs"
  - "Updated Aug 2026"
source: "markdown"
---

## Overview

No gameplay in this chapter — only the setup that *every* mobile game needs before
 the first script is written. If you skip these steps or eyeball them, you will spend two
 hours in later chapters debugging a portrait viewport that isn't actually portrait, or an
 input map missing the pause action, or a Forward+ renderer that runs at 12 fps on your
 phone. Do them once, correctly, now.

:::callout-key[What you'll build in this chapter]
An empty Godot 4.6 project called *ZergMarch*, configured for portrait Android:
 Mobile renderer, 1080×1920 viewport with `keep_height` stretch, five named 3D
 physics layers, three input actions, seven folders, and two autoloads (`EventBus.gd`
 and `GameManager.gd`). The final verification is opening the empty project and
 confirming the editor viewport is a tall rectangle.
:::

### Prerequisites

- Ch 72 Design Sheet read — understand the target before configuring for it.
- Godot 4.6.x installed (any 4.6.x point release). 4.7 is stable now, but
  this walkthrough has not been checked against it — use 4.6.x here.
- Familiarity with the Project Manager and Project Settings (Ch 1, Ch 7).
- Basic GDScript (Ch 4) — the autoload stubs are tiny but written in GDScript.

:::callout-connect[Reference checklist for this chapter]
Direct dependencies: **Ch 1** (installing Godot & the Project Manager),
 **Ch 7** (Project Settings dock), **Ch 11** (autoloads pattern),
 **Ch 46** (Input Map). Everything else is deferred to later chapters.
:::

## 1. New Project

Open Godot 4.6. In the Project Manager, click **+ New** in the top-right.
 The *Create New Project* dialog opens.

1. **Project Name** — type `ZergMarch` exactly. This becomes the
 default window title and the initial APK label; you can rename later but it's easier to
 start with the shipped name.
2. **Project Path** — click *Browse*. Create a fresh, empty folder — e.g.
 `C:/Users/<you>/Documents/Godot/ZergMarch` or
 `~/Godot/ZergMarch`. Do *not* reuse an existing project folder — Godot
 will refuse. Click *Select Current Folder*.
3. **Version Control Metadata** — leave as *Git* if you plan to push
 to GitHub, otherwise *None*. A `.gitignore` and `.gitattributes`
 are generated automatically if you pick Git.
4. **Renderer** — click the dropdown and choose **Mobile**.
 *Do not choose Forward+ or Compatibility.* The renderer choice is baked into
 shipped materials and shaders; switching later means auditing every visual node in the
 project. Mobile is right for our target device (mid-range Android) and supports
 everything we need.
5. Click **Create & Edit**. The Godot editor opens on the empty project.

:::callout-pitfall[Pitfall — the “renderer” dropdown is only shown at project creation]
Once the project exists, changing the renderer requires *Project → Project Settings →
 Rendering → Renderer → Rendering Method* **and** restarting the editor.
 Materials created under one renderer may render differently under another (Forward+ has
 features that Mobile silently drops). Get it right at creation and you won't have to think
 about this again.
:::

## 2. Confirm the Mobile Renderer & Its Implications

The renderer decision has cascading effects on what visual features are available. Before
 Ch 72B/E/H rely on those features, verify the setting stuck and understand what it excludes.

1. Open **Project → Project Settings** (top-left menu).
2. In the left pane, scroll down to **Rendering → Renderer** and click it.
3. In the right pane, confirm **Rendering Method** reads `mobile`.
 If it doesn't, click the dropdown, choose *Mobile*, and click *Save & Restart*.

:::callout-intuition[What Mobile renderer excludes]
SSR (Screen-Space Reflections), SSIL, SDFGI, and Volumetric Fog are all Forward+-only.
 Our design intentionally uses none of them. The Mobile renderer keeps *glow*,
 *tonemap*, *ambient light*, *DirectionalLight3D with or without shadow*,
 *OmniLight3D and SpotLight3D*, *StandardMaterial3D with all common
 properties*, *MultiMeshInstance3D*, *Area3D triggers*, and every
 CharacterBody3D/RigidBody3D physics behaviour we need. Nothing in the crowd-runner
 architecture requires an excluded feature.
:::

## 3. Portrait Viewport & Stretch Mode

The *viewport* is the world-coordinate rectangle your game renders into. The
 *window* is the physical pixel rectangle it eventually maps to. On desktop these
 are almost the same size; on Android they are wildly different across devices. Godot's
 *Stretch Mode* setting controls how one is mapped to the other.

1. Still in **Project → Project Settings**, open **Display → Window**
 in the left pane.
2. Under **Size**:

   - **Viewport Width** = `1080`
   - **Viewport Height** = `1920`
   - **Window Width Override** = `540` (half-size window for editor preview so it fits your desktop screen)
   - **Window Height Override** = `960`
   - **Mode** = `windowed` (editor preview only; runtime overrides this)
   - **Resizable** = `off` (mobile portrait games do not resize)

3. Under **Handheld**:

   - **Orientation** = `portrait`

4. Under **Stretch**:

   - **Mode** = `canvas_items`
   - **Aspect** = `keep_height`
   - **Scale** = `1`

:::callout-intuition[Why canvas\_items + keep\_height]
*canvas\_items* means the world stays at 1080×1920 world-units and the framebuffer
 is scaled to fill the physical screen — UI stays crisp because Control nodes are drawn at
 native pixel size. *keep\_height* means we lock the 1920-unit vertical dimension and
 let the horizontal dimension expand if the physical screen is wider (e.g. 1080×2400
 phones get a 1080×2400 viewport — 1080 wide, but 2400 tall). This preserves the
 “how far ahead you can see down the track” feeling across all portrait phones.
:::

:::callout-warning[Why not keep or expand?]
`keep` would letterbox the extra vertical space with black bars — ugly on a
 modern 20:9 phone. `expand` would let the horizontal grow too — but our lane
 X positions are fixed to `[-2, 0, 2]` in world units, so a wider viewport
 would push the outer lanes off-centre. *keep\_height* is the only choice that keeps
 lanes aligned across all portrait aspect ratios.
:::

## 4. Physics Settings

The runner is a CharacterBody3D on the ground; there is no dynamic 3D physics in this
 game beyond gravity and Area3D triggers. But three settings need attention:

1. In Project Settings, open **Physics → 3D**.

   - Set **Physics Engine** to *Jolt Physics*. A new project starts on
    `DEFAULT`, which resolves to Godot Physics, so this is a change you have to make
    rather than a setting to confirm. You want Jolt for correct capsule-on-plane behaviour at
    our low physics tick rate.
   - **Default Gravity** = `9.8`. Vertical, m/s². Leave the direction as
    *Vector3(0, -1, 0)*.

2. Open **Physics → Common**.

   - **Physics Ticks Per Second** = `60`. Matches display refresh
    and keeps CharacterBody3D interpolation smooth.
   - **Max Physics Steps Per Frame** = `8` (default).

:::callout-tip[Why 60 Hz physics is enough]
Our leader moves at 10 m/s. At 60 Hz that's 0.167 m per tick — well below any collision
 shape size. Higher tick rates burn phone battery for imperceptible gain. If you ever add
 fast-moving projectiles (we don't, in this game), you'd bump this to 120.
:::

## 5. Physics Layers

Named layers make collision configuration self-documenting. If you use raw numbers
 (“layer 4, mask 5”) you will forget which is which and mis-wire collisions in
 Ch 72F.

1. Still in Project Settings, scroll to **Layer Names → 3D Physics**.
2. Type these names into the first five slots exactly:

| Layer # | Name | Used by |
| --- | --- | --- |
| 1 | `Ground` | GroundSegment (StaticBody3D) |
| 2 | `Runner` | Runner (CharacterBody3D) |
| 3 | `Gate` | Gate (Area3D) |
| 4 | `Obstacle` | WallObstacle, SawObstacle (Area3D) |
| 5 | `EnemyWall` | EnemyWall (Area3D — Ch 72H) |

:::callout-pitfall[Layer 1 is Ground, not Runner]
The temptation is to put the “most important” thing on layer 1. Don't. The
 convention across all Godot tutorials — and across Ch 70 and Ch 71 — is *static world
 geometry lives on layer 1*. This makes the default CharacterBody3D behaviour
 (`collision_mask = 1`) work out of the box without any per-node tweaking.
:::

## 6. Input Map

Touch input in Godot is handled outside the Input Map (via `InputEventScreenDrag`
 / `InputEventScreenTouch`) — but we still need three named actions for the
 keyboard fallback that lets us test in the editor, and one for pause.

1. In Project Settings, click **Input Map** in the left pane.
2. In *Add New Action*, type `lane_left`, click **Add**.
 In the row that appears, click the *+* button on the right → *Key* → press
 A → OK. Repeat the *+* → *Key* and press Left Arrow
 → OK. The row now shows two bindings.
3. Add `lane_right` with D and Right Arrow.
4. Add `pause` with Escape. Then click *+* → *Joypad
 Button* → *Start* so a controller Start button also pauses (helps when
 testing on an emulator).

:::callout-tip[Deadzone stays 0.5]
Godot 4 puts a deadzone slider on each action to filter noisy analog stick input.
 We're using keys and touch here, so the deadzone value doesn't matter — leave the
 default 0.5. If you later add gamepad-analog lane control, drop it to 0.2.
:::

:::callout-warning[Do NOT add a lane\_left/lane\_right touch binding]
Godot's Input Map *can* bind touch events, but only single-touch taps at fixed
 screen regions. Swipe detection requires a real state machine over
 InputEventScreenDrag — we build that in Ch 72D. Trying to shoehorn swipes into the
 Input Map produces false triggers on every tap.
:::

## 7. Folder Structure

Godot doesn't force a folder layout — but a consistent one saves your future self hours
 of scrolling. Create these seven top-level folders now, before any assets exist. Use the
 **FileSystem** dock (bottom-left of the editor).

1. Right-click `res://` in the FileSystem dock → *New Folder* → type
 `autoloads` → OK. Repeat for the six others below.

```
res://
├── autoloads/         EventBus.gd, GameManager.gd
├── scenes/
│   ├── main/          Main.tscn, Main.gd, CameraRig.gd
│   ├── runner/        Runner.tscn, Runner.gd, LaneController.gd, CrowdManager.gd
│   ├── world/         GroundSegment.tscn, GateBase.tscn, TwoGateRow.tscn,
│   │                  WallObstacle.tscn, SawObstacle.tscn, EnemyWall.tscn
│   └── ui/            HUD.tscn, HUD.gd, MainMenu.tscn, PauseMenu.tscn,
│                      GameOverMenu.tscn, SettingsMenu.tscn
├── scripts/
│   ├── level/         LevelSpawner.gd
│   └── util/          Tween helpers, math helpers
├── assets/
│   ├── models/        (empty for now — capsules are primitives)
│   ├── materials/     ground_mat.tres, runner_mat.tres, gate_add.tres, gate_sub.tres
│   └── audio/         gate_ding.ogg, obstacle_thud.ogg, battle_roar.ogg, music.ogg
└── export/            for exported APK builds (add to .gitignore)
```

:::callout-tip[Add to .gitignore]
If you picked Git at project creation, open the auto-generated `.gitignore`
 and append:

```
# Local export builds
/export/
# Godot cache
.godot/
```
:::

## 8. Autoloads — EventBus and GameManager

Two autoloads live for the whole life of the app. `EventBus` is the signal
 broker (see the design sheet for the six signals). `GameManager` is the run
 state and settings owner. Both start as tiny stubs — we grow them in later chapters.

### Step 1 — Create `EventBus.gd`

1. Right-click `res://autoloads/` in the FileSystem → *New Script*.
2. In the dialog: **Template** = *Empty*, **Inherits** =
 `Node`, **Path** = `res://autoloads/EventBus.gd`. Click
 **Create**.
3. Replace the file contents with exactly this:

```gdscript
# res://autoloads/EventBus.gd
# Global signal broker for Zerg March. Autoloaded as "EventBus".
# See Ch 72 Design Sheet §Signal Flow for who emits and listens to what.
extends Node

# ── Crowd & combat ───────────────────────────────────────────────────
signal crowd_changed(new_count: int, delta: int)
signal gate_triggered(gate_type: int, value: int)
signal obstacle_hit(damage: int)

# ── Run lifecycle ────────────────────────────────────────────────────
signal run_started
signal run_finalizing
signal run_finished(won: bool, distance_m: int)
```

### Step 2 — Create `GameManager.gd`

1. Right-click `res://autoloads/` → *New Script*.
2. Path `res://autoloads/GameManager.gd`, inherits `Node`.
3. Replace the contents:

```gdscript
# res://autoloads/GameManager.gd
# Global run-state owner. Autoloaded as "GameManager".
# We'll grow this in Ch 72G/H — for now it holds enum + high score stub.
extends Node

enum State { MENU, RUNNING, PAUSED, GAME_OVER }

const SAVE_PATH := "user://zergmarch.cfg"

var state       : State = State.MENU
var high_score  : int   = 0
var last_score  : int   = 0

signal state_changed(new_state: State)

func _ready() -> void:
    # Placeholder — Ch 72H replaces this with real ConfigFile load.
    high_score = 0
    print("[GameManager] ready, state = MENU, high_score = 0")

func set_state(new_state: State) -> void:
    if new_state == state:
        return
    state = new_state
    state_changed.emit(new_state)
```

### Step 3 — Register both as autoloads

1. Open **Project → Project Settings → Autoload**.
2. In *Path*, click the folder icon → pick `res://autoloads/EventBus.gd`.
 In *Node Name*, confirm it reads `EventBus` (Godot auto-fills from the
 filename). Click **Add**.
3. Repeat for `res://autoloads/GameManager.gd` as node name `GameManager`.
4. Confirm both rows show **Enable** checked.

:::callout-pitfall[Order matters: EventBus above GameManager]
Godot loads autoloads top-to-bottom. GameManager may connect to EventBus signals in
 later chapters, so EventBus must exist first. Drag `EventBus` above
 `GameManager` in the list. If you later see a “signal not found on
 EventBus” error at startup, this order is why.
:::

## 9. Verification

Every build chapter ends with a runnable checkpoint. This one is minimal because there's
 no gameplay yet — but running it catches misconfiguration before it propagates.

1. Save everything: *Scene → Save Scene* (or Ctrl+S) — even
 though we have no scene, this triggers a project-file rewrite.
2. Create a throwaway root scene: *Scene → New Scene → Other Node → Node3D*.
 Rename it `Main`. Save as `res://scenes/main/Main.tscn`.
3. Set it as the main scene: *Project → Project Settings → Application → Run →
 Main Scene*. Click the folder icon and pick `res://scenes/main/Main.tscn`.
 OK.
4. Run the project: press F5. A tall, empty window opens.

:::callout-key[Verify these three things]
- The runtime window is **portrait** — clearly taller than wide.
- The Output dock (bottom panel of the editor) shows:

 That message proves `GameManager` is loaded as an autoload.

  ```
  [GameManager] ready, state = MENU, high_score = 0
  ```

- There are **no red errors** in the Output dock. Yellow warnings are OK.
:::

:::callout-warning[If the window is landscape]
Reopen *Project Settings → Display → Window*, confirm Handheld → Orientation is
 `portrait`, then *close and reopen* the editor. Some orientation
 settings only take effect after an editor restart.
:::

:::callout-warning[If the print message is missing]
Open *Project Settings → Autoload*. Confirm both `EventBus` and
 `GameManager` exist, are enabled, and that GameManager is *below*
 EventBus. Then re-run.
:::

:::callout-warning[If you get a red “Cannot resolve autoload path” error]
Your script's file path in the FileSystem doesn't match the path registered in the
 Autoload dock. Check for typos — `res://autoloads/EventBus.gd` exactly,
 lowercase folder, PascalCase filename.
:::

Close the game window. The project is now configured for everything in Ch 72B–H.

## Practice

These prompts are optional but they harden the settings you just made. Solutions inside
 each *Show solution*.

:::problem[Problem 1 easy]{difficulty="easy"}
Why does the design use *five* physics layers, not fewer? Could you merge
 `Gate` and `Obstacle` into one `Trigger` layer?

::::solution[Solution]
You *could* — but then the Runner would need one Area3D whose script checks
 `if body is Gate` vs `if body is Obstacle` to route the event. The
 two-Area3D-two-layer design lets the physics engine do the sorting: only gate collisions
 reach `GateSensor`, only obstacles reach `HitSensor`. The tiny
 “waste” of two extra layers buys us type-safe routing with zero runtime
 `is` checks. Fewer bugs, faster code.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Your friend copies this chapter but picks *Forward+* instead of *Mobile*
 renderer “because it looks better.” On his phone the framerate drops to 15 fps
 with 100 crowd members. Name the two features he's probably paying for that Mobile
 would skip.

::::solution[Solution]
**SDFGI** (Signed Distance Field Global Illumination) is on by default in
 Forward+ and is the single biggest mobile killer. **SSR** (Screen-Space
 Reflections) also runs and eats fill-rate. Additionally, Forward+ uses clustered
 shading which is more expensive per pixel on tile-based mobile GPUs. Fix: switch to
 Mobile renderer *at project creation*, not after — mid-project switching keeps
 Forward+-specific material properties around that silently do nothing.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
You add a fourth input action, `debug_reload`, so you can restart the run
 by pressing R during development. How do you make sure it doesn't ship in
 the final APK?

::::solution[Solution]
Two good options. (a) *Delete it before export* — an item on your Ch 72H
 pre-export checklist. (b) *Guard it in code*: any handler for
 `debug_reload` is wrapped in `if OS.is_debug_build():` which is
 `true` only when running from the editor or a debug build. The exported
 release APK has `OS.is_debug_build() == false` and the reload is silently
 ignored. (b) is preferred because it lets you keep the binding for future dev builds.
::::
:::

:::problem[Problem 4 challenge]{difficulty="challenge"}
You want to test-run the project on a physical iPad which is *landscape*-locked
 by iOS. Without changing Godot's Handheld → Orientation, what would happen visually?
 (Trick question — think about which axis *keep\_height* preserves.)

::::solution[Solution]
Godot's orientation setting only affects mobile export presets — it doesn't change
 what the editor or a desktop build does. If a landscape-locked device forces landscape
 display, the 1080×1920 portrait viewport is rotated 90° by the OS. With `keep_height`
 Godot preserves the 1920 vertical world-unit — so on the iPad's actual 1620×2160 display
 (landscape), our world would render 1920 world-units *along the short axis of the
 landscape screen*. Result: everything appears squished narrow horizontally, lanes
 at X ∈ [−2, 2] are visible but cramped, and you can see much more of the track ahead
 than intended. This is why we lock the export preset to portrait in Ch 72H — the game
 will refuse to rotate on device.
::::
:::

:::summary
## Summary

You have configured a Godot 4.6 project for portrait Android. The Mobile renderer is
 set, the viewport is 1080×1920 with `keep_height` stretch, physics runs at
 60 Hz with Jolt, five named physics layers are defined, three input actions
 (`lane_left`, `lane_right`, `pause`) work, seven folders
 hold the file layout, and two autoloads (`EventBus`, `GameManager`)
 load at startup. Running the project opens a tall empty window and prints
 `[GameManager] ready`.

**Next:** in
 [Ch 72B](./godot_ch72b_track_camera.html) we build the recycling ground track,
 the chase Camera3D, and the `Main.gd` script that ties them together — the
 first visible motion in the game.
:::

### Configuration checklist (paste into your notes)

- Renderer: Mobile
- Viewport: 1080×1920, canvas\_items, keep\_height, portrait
- Physics: Jolt, 60 Hz, gravity 9.8 down
- Layers 1–5: Ground, Runner, Gate, Obstacle, EnemyWall
- Input actions: lane\_left (A/←), lane\_right (D/→), pause (Esc/Start)
- Folders: autoloads, scenes/{main,runner,world,ui}, scripts/{level,util}, assets/{models,materials,audio}, export
- Autoloads: EventBus (top), GameManager (below)
- Main scene: res://scenes/main/Main.tscn (empty Node3D, for now)
- F5 run opens a portrait window and prints the GameManager ready line
