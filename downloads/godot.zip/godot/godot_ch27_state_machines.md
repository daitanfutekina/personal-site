---
title: "State Machines — Organised Behaviour for Players & AI"
source: "markdown"
---

Part III · Chapter 27

# State Machines — Organised Behaviour for Players & AI

Prerequisite: Ch 4 & 10 (GDScript), Ch 8 (2D Physics) · est. 85 min

## Overview

Every interactive entity in a game — the player, enemies, doors, NPCs — has
 behaviour that depends on what it is *currently doing*. A player who is
 attacking cannot jump. An enemy that is dying cannot start chasing. Managing
 these rules with chains of `if/elif` blocks works for two or three
 behaviours, but collapses into unreadable "spaghetti" as complexity grows.

A **Finite State Machine (FSM)** solves this by dividing behaviour
 into a fixed set of *states*, with explicit rules — *transitions*
 — governing when the entity can move from one state to another. Only one state
 is active at a time, and each state is responsible solely for its own logic.

This chapter covers three levels of FSM implementation:

- **Enum-based** — a single script, minimal boilerplate, ideal for
 simple entities with 3–5 states.
- **Class-based** — separate class per state, maximum clarity, scales
 to 10+ states without conflicts.
- **Practical examples** — a full platformer player FSM and a
 four-state enemy AI.

## 1 · Why State Machines?

### 1.1 · The spaghetti problem

Consider a player that can idle, run, jump, fall, and attack. Without an FSM,
 `_physics_process` accumulates nested conditions:

```gdscript
## WITHOUT a state machine — becomes unmaintainable quickly
func _physics_process(delta: float) -> void:
    if is_on_floor():
        if Input.is_action_pressed("move_right") or Input.is_action_pressed("move_left"):
            if not is_attacking:
                # run logic
                pass
            else:
                # still attacking — slow movement
                pass
        else:
            if not is_attacking:
                # idle logic
                pass
        if Input.is_action_just_pressed("jump") and not is_attacking:
            # jump logic
            pass
        if Input.is_action_just_pressed("attack") and not is_jumping:
            is_attacking = true
            # start attack animation
            pass
    else:
        if velocity.y > 0:
            # falling logic
            pass
        # Can we attack in the air? Should attacking cancel a fall animation?
        # What happens if we land while attacking?...
```

Every new state or rule adds another layer of nesting. Bugs emerge because the
 combinations of flags (`is_attacking`, `is_jumping`,
 `is_hurt`) grow exponentially.

### 1.2 · FSM concepts

The vocabulary is worth fixing before the code, because all three words get used loosely
elsewhere. A **state** is a mode of behaviour that the entity is wholly in or
wholly out of — not a variable, a mode. A **transition** is a change
between two of them, and the important claim is that it is instantaneous and total: there
is no moment at which the player is half-running and half-jumping. A **guard**
is the condition that permits a transition, and it is where nearly all the interesting
design lives — “you may enter Jump if you are on the floor” is a game
design decision wearing a boolean.

What makes the pattern earn its keep is not that it is tidier. It is that it makes a
whole class of bug impossible to express. In the tangle above, “attacking while
already dead” is a combination of flags you have to remember to exclude. In a state
machine it is not a thing you can be, because `current_state` holds exactly one
value.

An FSM has three building blocks:

- **States** — discrete modes of behaviour: Idle, Run, Jump, Attack.
 Only one is active at a time.
- **Transitions** — the rules that move the machine from one state
 to another: "if on floor and moving → Run; if jump pressed → Jump".
- **Enter / Exit hooks** — code that runs exactly once when entering
 or leaving a state, used for starting animations, resetting variables, or
 playing sounds.

:::callout-key[Key Concept]
The power of an FSM is that each state only needs to know about

its own

transitions.  The Attack state does not need to know whether
        the player is on the ground or in the air — that is the ground states' concern.
        This isolation is what eliminates spaghetti.
:::

Player Character FSM — states and transitions

IDLE

on floor, no input

RUN

on floor, moving

JUMP

velocity.y < 0

FALL

velocity.y > 0

ATTACK

attack pressed

HURT

hit by enemy

move input

no input

jump

jump

apex

landed

attack

anim done

hit

recovery done

A typical platformer FSM: six states, each knowing only its own transition conditions. IDLE, RUN, JUMP and FALL handle movement; ATTACK and HURT are orthogonal interrupts. No state needs to know about the internal logic of any other state.

## 2 · Enum-Based FSM

The simplest FSM uses a GDScript `enum` to label states and a
 `match` block to dispatch logic. It lives entirely in one script —
 no extra files needed. Perfect for entities with a small, stable set of states.

### 2.1 · Basic enum pattern

```gdscript
extends CharacterBody2D

enum State { IDLE, RUN, JUMP, FALL }

var state: State = State.IDLE

const SPEED      := 200.0
const JUMP_FORCE := -420.0
const GRAVITY    := 980.0

func _physics_process(delta: float) -> void:
    # Apply gravity always
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    # Dispatch to per-state logic
    match state:
        State.IDLE: _state_idle(delta)
        State.RUN:  _state_run(delta)
        State.JUMP: _state_jump(delta)
        State.FALL: _state_fall(delta)

    move_and_slide()

func _state_idle(_delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0, SPEED)
    if Input.get_axis("move_left", "move_right") != 0.0:
        _transition(State.RUN)
    elif Input.is_action_just_pressed("jump"):
        _transition(State.JUMP)
    elif not is_on_floor():
        _transition(State.FALL)

func _state_run(_delta: float) -> void:
    var dir := Input.get_axis("move_left", "move_right")
    velocity.x = dir * SPEED
    if dir == 0.0:
        _transition(State.IDLE)
    elif Input.is_action_just_pressed("jump"):
        _transition(State.JUMP)
    elif not is_on_floor():
        _transition(State.FALL)

func _state_jump(_delta: float) -> void:
    # Horizontal control kept during jump
    velocity.x = Input.get_axis("move_left", "move_right") * SPEED
    if velocity.y >= 0.0:
        _transition(State.FALL)

func _state_fall(_delta: float) -> void:
    velocity.x = Input.get_axis("move_left", "move_right") * SPEED
    if is_on_floor():
        var dir := Input.get_axis("move_left", "move_right")
        _transition(State.RUN if dir != 0.0 else State.IDLE)

func _transition(new_state: State) -> void:
    state = new_state
```

### 2.2 · Adding enter / exit hooks

Add two helper methods — `_enter_state()` and
 `_exit_state()` — and call them from `_transition()`
 whenever the state actually changes:

```gdscript
@onready var anim: AnimationPlayer = $AnimationPlayer

func _transition(new_state: State) -> void:
    if new_state == state:
        return   # already in this state — no-op

    _exit_state(state)
    state = new_state
    _enter_state(state)

func _enter_state(s: State) -> void:
    match s:
        State.IDLE: anim.play("idle")
        State.RUN:  anim.play("run")
        State.JUMP:
            velocity.y = JUMP_FORCE
            anim.play("jump")
        State.FALL: anim.play("fall")

func _exit_state(s: State) -> void:
    match s:
        State.ATTACK:
            # Reset attack hitbox when leaving attack state
            $AttackHitbox.monitoring = false
```

:::callout-tip[Tip — State names as strings for debugging]
Add a helper to convert the enum to a readable string for print statements and
        the HUD:

```gdscript
func state_name() -> String:
    return State.keys()[state]   # returns "IDLE", "RUN", etc.
```
:::

## 3 · Class-Based FSM

For complex entities — a player with 8+ states, or an AI with branching
 sub-behaviours — put each state in its own class. This keeps files small,
 makes testing individual states easy, and allows states to be reused across
 different entities.

### 3.1 · The State base class

This class does almost nothing, and that is the design. It declares the five moments in
a state's life — becoming active, going inactive, and the three kinds of tick —
and gives every one of them a body that does nothing. A concrete state overrides only what
it cares about, so `IdleState` can be twenty lines and still be a complete,
valid state.

The return type is the part worth slowing down for. `physics_update` returns
a `State`, not a `void`, and that single decision is what keeps the
transition logic honest. A state does not change the machine; it *answers a question*
— “given what just happened, who should be running now?” — and
returning `null` means “still me”. Because a state can only ever
hand back a state, it cannot half-transition, cannot leave the machine pointing at nothing,
and cannot forget to call `exit()` on the way out. The machine owns all of that.

`owner_entity` exists because a state needs to act on something, and the
state node is a child of the machine rather than of the player. Naming it
`owner_entity` rather than `owner` is not fussiness:
`Node.owner` already exists and means the node that owns this one in a saved
scene, which is a different thing entirely.

```gdscript
# state.gd
class_name State
extends Node

## Reference back to the owner entity — set by StateMachine on add_child
var owner_entity: Node = null

## Called once when this state becomes active
func enter() -> void:
    pass

## Called once when this state is deactivated
func exit() -> void:
    pass

## Called every physics frame while this state is active.
## Return a State (or null) to trigger a transition.
func physics_update(delta: float) -> State:
    return null

## Called every render frame while this state is active.
func update(delta: float) -> State:
    return null

## Called for each unhandled input event while this state is active.
func handle_input(event: InputEvent) -> State:
    return null
```

### 3.2 · The StateMachine class

Everything the pattern promises is enforced in `transition_to`, and it is
worth reading in order. The old state is stopped and told to `exit()`; only then
does `current_state` move; only then is the new state started and told to
`enter()`. Do those in any other order and you get the classic state-machine
bugs — two states briefly both active, or an `enter()` that runs against
the outgoing state's leftovers.

The guard on the first line, returning early when the new state is the current one,
is what makes the machine safe to be enthusiastic with. A state can return itself, or the
same transition can fire twice in a frame, and neither re-runs
`exit()`/`enter()`.

:::callout-pitfall[Pitfall]
state\_changed

is emitted

after

enter()

has run, and

\_activate()

does not emit it at all. Both are defensible — a listener
  sees a fully entered state, and the initial state is not a change from anything — but
  they surprise people. A HUD that draws the state name will show nothing until the first
  real transition unless it also reads

current\_state

once on ready. And if an

enter()

immediately returns a further transition, the signals arrive
  innermost-first.
:::

```gdscript
# state_machine.gd
class_name StateMachine
extends Node

## Emitted when the active state changes
signal state_changed(from: State, to: State)

var current_state: State = null

func _ready() -> void:
    # Give every child State a reference to the entity that owns this machine
    for child in get_children():
        if child is State:
            child.owner_entity = get_parent()

    # Start with the first child state
    if get_child_count() > 0:
        var first := get_child(0) as State
        if first:
            _activate(first)

func _physics_process(delta: float) -> void:
    if current_state == null:
        return
    var next := current_state.physics_update(delta)
    if next != null:
        transition_to(next)

func _process(delta: float) -> void:
    if current_state == null:
        return
    var next := current_state.update(delta)
    if next != null:
        transition_to(next)

func _unhandled_input(event: InputEvent) -> void:
    if current_state == null:
        return
    var next := current_state.handle_input(event)
    if next != null:
        transition_to(next)

## Switch to a new state by instance reference
func transition_to(new_state: State) -> void:
    if new_state == current_state:
        return
    var prev := current_state
    if current_state:
        current_state.set_physics_process(false)
        current_state.set_process(false)
        current_state.set_process_unhandled_input(false)
        current_state.exit()
    current_state = new_state
    current_state.owner_entity = get_parent()
    current_state.set_physics_process(true)
    current_state.set_process(true)
    current_state.set_process_unhandled_input(true)
    current_state.enter()
    state_changed.emit(prev, new_state)

## Switch by node name (useful from outside the FSM)
func transition_to_name(state_name: StringName) -> void:
    ## NodePath() is required: GDScript will not convert a StringName to a
    ## NodePath on its own, and get_node_or_null takes a NodePath.
    var s := get_node_or_null(NodePath(state_name)) as State
    if s:
        transition_to(s)
    else:
        push_error("StateMachine: no state named '%s'." % state_name)

## Convenience — deactivate all non-active states at startup
func _activate(s: State) -> void:
    for child in get_children():
        if child is State:
            child.set_physics_process(false)
            child.set_process(false)
            child.set_process_unhandled_input(false)
    current_state = s
    s.set_physics_process(true)
    s.set_process(true)
    s.set_process_unhandled_input(true)
    s.enter()
```

:::callout-intuition[Intuition — Why disable process on inactive states?]
It is worth being precise about what is doing the work here, because the obvious
        answer is wrong. Godot only calls

\_physics\_process

on a node whose
        script actually defines it — and these states do not. They define `physics_update`, which is an ordinary method the StateMachine calls by
        hand. Inactive states are therefore already silent: nothing in the engine knows
        about them, and the machine simply never calls them.

So what are the

set\_physics\_process

calls for? They are insurance. A
        concrete state is free to implement the real

\_physics\_process

as well
        — for a particle emitter that should only run while the state is active, say
        — and without these calls that engine callback would keep firing in every
        inactive state at once. Toggling the flag costs nothing on a state that has no such
        callback, and prevents a confusing bug in the one that does.
:::

### 3.3 · Concrete state example — IdleState

```gdscript
# idle_state.gd
class_name IdleState
extends State

func enter() -> void:
    var entity := owner_entity as CharacterBody2D
    entity.get_node("AnimationPlayer").play("idle")
    entity.velocity.x = 0.0

func physics_update(_delta: float) -> State:
    var entity := owner_entity as CharacterBody2D

    if not entity.is_on_floor():
        return get_parent().get_node("FallState")  # transition to fall

    var dir := Input.get_axis("move_left", "move_right")
    if dir != 0.0:
        return get_parent().get_node("RunState")

    if Input.is_action_just_pressed("jump"):
        return get_parent().get_node("JumpState")

    if Input.is_action_just_pressed("attack"):
        return get_parent().get_node("AttackState")

    return null   # stay in Idle
```

The scene tree for the player looks like:

```
Player (CharacterBody2D)
├── StateMachine (state_machine.gd)
│   ├── IdleState
│   ├── RunState
│   ├── JumpState
│   ├── FallState
│   └── AttackState
├── AnimationPlayer
├── Sprite2D
└── CollisionShape2D
```

## 4 · Player Controller FSM

Here is a complete enum-based platformer player with Idle, Run, Jump, Fall,
 Attack, and Hurt states — the set that covers the majority of action platformers.

### 4.1 · Idle, Run, Jump, Fall

```gdscript
# player.gd
extends CharacterBody2D

enum State { IDLE, RUN, JUMP, FALL, ATTACK, HURT, DEAD }

const SPEED       := 220.0
const JUMP_FORCE  := -480.0
const GRAVITY     := 1000.0
const COYOTE_TIME := 0.12   # seconds of grace after walking off a ledge
const JUMP_BUFFER := 0.10   # seconds to buffer a jump input before landing

var state: State     = State.IDLE
var hp:    int       = 3
var _coyote_timer:   float = 0.0
var _jump_buffer:    float = 0.0
var _hurt_timer:     float = 0.0
var _attack_timer:   float = 0.0

@onready var anim:   AnimationPlayer = $AnimationPlayer
@onready var sprite: Sprite2D        = $Sprite2D
@onready var hitbox: Area2D          = $AttackHitbox

func _physics_process(delta: float) -> void:
    # Gravity
    if not is_on_floor():
        velocity.y += GRAVITY * delta
        _coyote_timer -= delta
    else:
        _coyote_timer = COYOTE_TIME

    # Jump buffer
    if Input.is_action_just_pressed("jump"):
        _jump_buffer = JUMP_BUFFER
    else:
        _jump_buffer -= delta

    match state:
        State.IDLE:   _state_idle(delta)
        State.RUN:    _state_run(delta)
        State.JUMP:   _state_jump(delta)
        State.FALL:   _state_fall(delta)
        State.ATTACK: _state_attack(delta)
        State.HURT:   _state_hurt(delta)
        State.DEAD:   _state_dead(delta)

    move_and_slide()

    # Flip sprite to face movement direction
    if velocity.x > 0.1:  sprite.flip_h = false
    elif velocity.x < -0.1: sprite.flip_h = true

func _state_idle(_delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0, SPEED * 4)
    if _jump_buffer > 0.0 and _coyote_timer > 0.0:
        _transition(State.JUMP)
    elif Input.get_axis("move_left", "move_right") != 0.0:
        _transition(State.RUN)
    elif Input.is_action_just_pressed("attack"):
        _transition(State.ATTACK)
    elif not is_on_floor() and velocity.y > 0:
        _transition(State.FALL)

func _state_run(_delta: float) -> void:
    var dir := Input.get_axis("move_left", "move_right")
    velocity.x = dir * SPEED
    if _jump_buffer > 0.0 and _coyote_timer > 0.0:
        _transition(State.JUMP)
    elif Input.is_action_just_pressed("attack"):
        _transition(State.ATTACK)
    elif not is_on_floor() and velocity.y > 0:
        _transition(State.FALL)
    elif dir == 0.0:
        _transition(State.IDLE)

func _state_jump(_delta: float) -> void:
    velocity.x = Input.get_axis("move_left", "move_right") * SPEED
    # Variable-height jump: release early to cut jump short
    if Input.is_action_just_released("jump") and velocity.y < -200.0:
        velocity.y *= 0.5
    if velocity.y >= 0.0:
        _transition(State.FALL)

func _state_fall(_delta: float) -> void:
    velocity.x = Input.get_axis("move_left", "move_right") * SPEED
    # Coyote jump
    if _jump_buffer > 0.0 and _coyote_timer > 0.0:
        _transition(State.JUMP)
    elif is_on_floor():
        _jump_buffer = 0.0
        var dir := Input.get_axis("move_left", "move_right")
        _transition(State.RUN if dir != 0.0 else State.IDLE)
```

### 4.2 · Attack and Hurt states

```gdscript
const ATTACK_DURATION := 0.35   # seconds
const HURT_DURATION   := 0.50

func _state_attack(delta: float) -> void:
    _attack_timer -= delta
    velocity.x = move_toward(velocity.x, 0, SPEED * 2)   # slow during attack
    if _attack_timer <= 0.0:
        hitbox.monitoring = false
        var dir := Input.get_axis("move_left", "move_right")
        _transition(State.RUN if dir != 0.0 else State.IDLE)

func _state_hurt(delta: float) -> void:
    _hurt_timer -= delta
    velocity.x = move_toward(velocity.x, 0, SPEED)
    if _hurt_timer <= 0.0:
        if hp <= 0:
            _transition(State.DEAD)
        else:
            _transition(State.IDLE)

func _state_dead(_delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0, SPEED)
    # Death is handled by the animation's finished signal

## Called by an enemy's hitbox when it overlaps the player
func take_damage(amount: int, knockback: Vector2) -> void:
    if state == State.DEAD or state == State.HURT:
        return   # already hurt / dead — ignore
    hp -= amount
    velocity = knockback
    _transition(State.HURT)

func _transition(new_state: State) -> void:
    if new_state == state:
        return
    _exit_state(state)
    state = new_state
    _enter_state(state)

func _enter_state(s: State) -> void:
    match s:
        State.IDLE:   anim.play("idle")
        State.RUN:    anim.play("run")
        State.JUMP:
            velocity.y = JUMP_FORCE
            _jump_buffer = 0.0
            _coyote_timer = 0.0
            anim.play("jump")
        State.FALL:   anim.play("fall")
        State.ATTACK:
            _attack_timer = ATTACK_DURATION
            hitbox.monitoring = true
            anim.play("attack")
        State.HURT:
            _hurt_timer = HURT_DURATION
            anim.play("hurt")
        State.DEAD:
            anim.play("die")
            set_physics_process(false)   # stop all movement on death

func _exit_state(s: State) -> void:
    match s:
        State.ATTACK:
            hitbox.monitoring = false
```

:::callout-tip[Tip — Coyote time & jump buffering]
These two techniques dramatically improve platformer feel.

Coyote time

lets the player jump for a brief window after walking
        off a ledge — the character was "on the floor" mentally even if they technically
        aren't anymore.

Jump buffering

accepts a jump input slightly before landing —
        the player pressed jump just a frame early and would be frustrated if it did nothing.
        Both are tracked as simple countdown timers.
:::

## 5 · Enemy AI FSM

A class-based FSM shines for enemy AI because each AI state can have its own
 navigation and perception logic without interfering with the others.

### 5.1 · Patrol, Chase, Attack, Dead

```gdscript
# enemy.gd  — the entity script (owns the StateMachine child)
extends CharacterBody2D

const PATROL_SPEED := 80.0
const CHASE_SPEED  := 160.0
const ATTACK_RANGE := 40.0
const CHASE_RANGE  := 300.0
const GRAVITY      := 980.0

var hp:     int  = 3
var target: Node = null   # set to the player node by the spawner or level

@onready var fsm:  StateMachine   = $StateMachine
@onready var anim: AnimationPlayer = $AnimationPlayer
@onready var nav:  NavigationAgent2D = $NavigationAgent2D

func _ready() -> void:
    target = get_tree().get_first_node_in_group("player")

func take_damage(amount: int) -> void:
    if fsm.current_state is DeadState:
        return
    hp -= amount
    if hp <= 0:
        fsm.transition_to_name("DeadState")
    else:
        fsm.transition_to_name("HurtState")
```

```gdscript
# patrol_state.gd
class_name PatrolState
extends State

var _dir: float = 1.0
var _patrol_timer: float = 0.0

func enter() -> void:
    (owner_entity as CharacterBody2D)\
        .get_node("AnimationPlayer").play("walk")
    _patrol_timer = randf_range(1.5, 3.0)

func physics_update(delta: float) -> State:
    var enemy := owner_entity as CharacterBody2D

    _patrol_timer -= delta
    if _patrol_timer <= 0.0:
        _dir *= -1.0
        _patrol_timer = randf_range(1.5, 3.0)

    enemy.velocity.x = _dir * enemy.PATROL_SPEED
    enemy.move_and_slide()

    # Check for wall or ledge — reverse direction
    if enemy.is_on_wall():
        _dir *= -1.0

    # Transition to chase if player is in range
    var player: Node = enemy.target
    if player and enemy.global_position.distance_to(
            player.global_position) <= enemy.CHASE_RANGE:
        return get_parent().get_node("ChaseState")

    return null
```

```gdscript
# chase_state.gd
class_name ChaseState
extends State

func enter() -> void:
    (owner_entity as CharacterBody2D)\
        .get_node("AnimationPlayer").play("run")

func physics_update(delta: float) -> State:
    var enemy  := owner_entity as CharacterBody2D
    var player := enemy.target

    if player == null or not is_instance_valid(player):
        return get_parent().get_node("PatrolState")

    var dist := enemy.global_position.distance_to(player.global_position)

    # Lost player — return to patrol
    if dist > enemy.CHASE_RANGE * 1.5:
        return get_parent().get_node("PatrolState")

    # Close enough to attack
    if dist <= enemy.ATTACK_RANGE:
        return get_parent().get_node("AttackState")

    # Navigate toward player
    enemy.nav.target_position = player.global_position
    var next_pos := enemy.nav.get_next_path_position()
    var dir      := (next_pos - enemy.global_position).normalized()
    enemy.velocity = dir * enemy.CHASE_SPEED
    enemy.move_and_slide()
    return null
```

```gdscript
# attack_state.gd
class_name AttackState
extends State

const ATTACK_DURATION := 0.6
var _timer: float = 0.0

func enter() -> void:
    _timer = ATTACK_DURATION
    var enemy := owner_entity as CharacterBody2D
    enemy.get_node("AnimationPlayer").play("attack")
    enemy.get_node("AttackHitbox").monitoring = true
    enemy.velocity = Vector2.ZERO

func exit() -> void:
    (owner_entity as CharacterBody2D)\
        .get_node("AttackHitbox").monitoring = false

func physics_update(delta: float) -> State:
    _timer -= delta
    if _timer > 0.0:
        return null

    var enemy  := owner_entity as CharacterBody2D
    var player := enemy.target
    if player == null:
        return get_parent().get_node("PatrolState")

    var dist := enemy.global_position.distance_to(player.global_position)
    if dist > enemy.ATTACK_RANGE:
        return get_parent().get_node("ChaseState")
    else:
        # Still in range — attack again
        _timer = ATTACK_DURATION
        enemy.get_node("AnimationPlayer").play("attack")
        enemy.get_node("AttackHitbox").monitoring = true
        return null
```

```gdscript
# dead_state.gd
class_name DeadState
extends State

func enter() -> void:
    var enemy := owner_entity as CharacterBody2D
    enemy.get_node("AnimationPlayer").play("die")
    enemy.get_node("CollisionShape2D").set_deferred("disabled", true)
    enemy.set_physics_process(false)
    # Wait for the death animation to finish, then free
    enemy.get_node("AnimationPlayer").animation_finished.connect(
        func(_name: StringName) -> void: enemy.queue_free()
    )
```

### 5.2 · Transition guards

A **guard** is a condition that must be true for a transition to
 be allowed. Guards prevent invalid state changes — an already-dead enemy cannot
 be hurt again, an enemy in the middle of an attack animation cannot be interrupted
 by a new attack request.

```gdscript
## In enemy.gd — centralise all transition requests here
func take_damage(amount: int) -> void:
    # Guard: already dead → ignore
    if fsm.current_state is DeadState:
        return

    hp -= amount
    if hp <= 0:
        fsm.transition_to_name("DeadState")
        return

    # Guard: already mid-hurt animation → don't interrupt, just reduce HP
    if fsm.current_state is HurtState:
        return

    # Guard: in attack state → interrupt it with hurt
    fsm.transition_to_name("HurtState")

## Another guard pattern: only allow ranged attack from PATROL or CHASE
func try_ranged_attack() -> void:
    var current := fsm.current_state
    if current is PatrolState or current is ChaseState:
        fsm.transition_to_name("RangedAttackState")
```

:::callout-connect[Connect — AnimationTree integration]
For complex characters, replace the manual

anim.play()

calls in each
        state's

enter()

with calls to the AnimationTree from Chapter 14:

anim\_tree.set("parameters/state\_machine/playback").travel("run")

.
        The AnimationTree handles blend times automatically, giving polished cross-fades
        between state animations without manual timing code.
:::

## Summary

Finite state machines tame behavioural complexity by splitting logic into
 self-contained states with explicit transition rules. The **enum-based**
 approach keeps everything in one file and is ideal for entities with up to five or
 six states — add enter/exit hooks via `_transition()` to keep animation
 and variable resets synchronised. The **class-based** approach puts
 each state in its own file and a `StateMachine` node orchestrates
 activation and deactivation; the active state returns a new state object to trigger
 transitions, and inactive states have their process callbacks disabled so they consume
 no CPU. The full platformer player FSM adds production polish with coyote time and
 jump buffering. The enemy AI FSM shows how navigation (NavigationAgent2D), perception
 (distance checks), and attack timing combine cleanly when each concern lives in its
 own state. Transition guards — conditions that block a transition from happening —
 are the final layer that prevents invalid state combinations and makes the machine
 robust under unexpected inputs.

| Approach | Best for | Overhead |
| --- | --- | --- |
| Enum-based | Simple entities, 2–6 states, single file | None |
| Class-based | Complex entities, 6+ states, team projects | One file per state |
| Godot AnimationTree FSM | Purely animation-driven transitions | Editor only, no custom logic |

## Mixed Practice

:::problem{difficulty="easy"}
### P1 · Traffic light FSM

Implement a traffic light as an enum-based FSM with three states:
 `RED` (stop 3 s), `GREEN` (go 3 s),
 `YELLOW` (caution 1 s). The light transitions automatically
 RED → GREEN → YELLOW → RED. Display the current state name in a Label
 and change a ColorRect's colour to match.

::::solution[Solution]
```gdscript
extends Node

enum Light { RED, GREEN, YELLOW }

const DURATIONS := { Light.RED: 3.0, Light.GREEN: 3.0, Light.YELLOW: 1.0 }
const COLOURS   := {
    Light.RED:    Color.RED,
    Light.GREEN:  Color.GREEN,
    Light.YELLOW: Color.YELLOW,
}

var state:  Light = Light.RED
var _timer: float = 0.0

@onready var rect:  ColorRect = $ColorRect
@onready var label: Label     = $Label

func _ready() -> void:
    _enter(state)

func _process(delta: float) -> void:
    _timer -= delta
    if _timer <= 0.0:
        match state:
            Light.RED:    _transition(Light.GREEN)
            Light.GREEN:  _transition(Light.YELLOW)
            Light.YELLOW: _transition(Light.RED)

func _transition(new: Light) -> void:
    state = new
    _enter(state)

func _enter(s: Light) -> void:
    _timer       = DURATIONS[s]
    rect.color   = COLOURS[s]
    label.text   = Light.keys()[s]
```
::::
:::

:::problem{difficulty="easy"}
### P2 · State name debug overlay

Add a floating `Label` above a CharacterBody2D that always shows
 the current state name. The label should update every time
 `_transition()` is called. Use the `State.keys()[state]`
 trick from the tip box to convert the enum value to a string.

::::solution[Solution]
```gdscript
extends CharacterBody2D

enum State { IDLE, RUN, JUMP, FALL }
var state: State = State.IDLE

@onready var debug_label: Label = $DebugLabel

func _transition(new_state: State) -> void:
    if new_state == state: return
    state = new_state
    debug_label.text = State.keys()[state]

func _ready() -> void:
    debug_label.text = State.keys()[state]
```
::::
:::

:::problem{difficulty="standard"}
### P3 · Door FSM with guard

Build a door with four states: `CLOSED`, `OPENING`,
 `OPEN`, `CLOSING`. Rules:

- CLOSED → OPENING when the player presses "interact" and
 `is_unlocked == true` (a guard).
- OPENING → OPEN when the open animation finishes.
- OPEN → CLOSING after 3 seconds automatically.
- CLOSING → CLOSED when the close animation finishes.
- Pressing "interact" while CLOSING should do nothing.

::::solution[Solution]
```gdscript
extends AnimatableBody2D

enum State { CLOSED, OPENING, OPEN, CLOSING }

var state:       State = State.CLOSED
var is_unlocked: bool  = false
var _open_timer: float = 0.0

@onready var anim: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
    anim.animation_finished.connect(_on_anim_finished)

func interact() -> void:
    # Guard: only open from CLOSED and only if unlocked
    if state == State.CLOSED and is_unlocked:
        _transition(State.OPENING)

func _process(delta: float) -> void:
    if state == State.OPEN:
        _open_timer -= delta
        if _open_timer <= 0.0:
            _transition(State.CLOSING)

func _on_anim_finished(anim_name: StringName) -> void:
    match anim_name:
        "open":  _transition(State.OPEN)
        "close": _transition(State.CLOSED)

func _transition(new_state: State) -> void:
    state = new_state
    match state:
        State.OPENING: anim.play("open")
        State.OPEN:    _open_timer = 3.0
        State.CLOSING: anim.play("close")
        State.CLOSED:  pass   # door is shut
```
::::
:::

:::problem{difficulty="standard"}
### P4 · Class-based two-state NPC

Using the `StateMachine` and `State` base classes from
 Section 3, implement an NPC that alternates between
 `WanderState` (moves in a random direction for 2–3 s) and
 `IdleState` (stands still for 1–2 s). Both states play different
 animations. Add the NPC to a group called `"npcs"` and confirm
 the state machine transitions are logged with `print()`.

::::solution[Solution]
```gdscript
# wander_state.gd
class_name NpcWanderState
extends State

var _timer: float = 0.0
var _dir:   Vector2 = Vector2.ZERO

func enter() -> void:
    _timer = randf_range(2.0, 3.0)
    _dir   = Vector2(randf_range(-1,1), 0).normalized()
    owner_entity.get_node("AnimationPlayer").play("walk")

func physics_update(delta: float) -> State:
    _timer -= delta
    var npc := owner_entity as CharacterBody2D
    npc.velocity = _dir * 60.0
    npc.move_and_slide()
    if _timer <= 0.0:
        return get_parent().get_node("NpcIdleState")
    return null

# npc_idle_state.gd
class_name NpcIdleState
extends State

var _timer: float = 0.0

func enter() -> void:
    _timer = randf_range(1.0, 2.0)
    owner_entity.velocity = Vector2.ZERO
    owner_entity.get_node("AnimationPlayer").play("idle")

func physics_update(delta: float) -> State:
    _timer -= delta
    if _timer <= 0.0:
        return get_parent().get_node("NpcWanderState")
    return null

# npc.gd
extends CharacterBody2D
func _ready() -> void:
    add_to_group("npcs")
    $StateMachine.state_changed.connect(
        func(from, to): print("NPC state: %s → %s" % [
            from.name if from else "none", to.name])
    )
```
::::
:::

:::problem{difficulty="standard"}
### P5 · Interrupt & return pattern

Extend the player FSM from Section 4 to add a `ROLL` state.
 Requirements:

- Triggered from IDLE or RUN by pressing "roll".
- Duration: 0.4 seconds. The player is **invincible**
 during the roll (set collision layer to 0).
- After the roll, transition back to RUN if moving, IDLE otherwise.
- Cannot be triggered from JUMP, FALL, HURT, DEAD, or ATTACK.

::::solution[Solution]
```gdscript
## Add to player.gd — extend the existing enum and state machine

# In enum:  IDLE, RUN, JUMP, FALL, ATTACK, HURT, DEAD, ROLL

const ROLL_SPEED    := 350.0
const ROLL_DURATION := 0.4
var _roll_timer:    float = 0.0
var _roll_dir:      float = 1.0

func _state_idle(_delta: float) -> void:
    # ... existing code ...
    if Input.is_action_just_pressed("roll"):
        _roll_dir = 1.0 if not sprite.flip_h else -1.0
        _transition(State.ROLL)

func _state_run(_delta: float) -> void:
    # ... existing code ...
    if Input.is_action_just_pressed("roll"):
        _roll_dir = sign(velocity.x) if velocity.x != 0 else 1.0
        _transition(State.ROLL)

func _state_roll(delta: float) -> void:
    _roll_timer -= delta
    velocity.x = _roll_dir * ROLL_SPEED
    if _roll_timer <= 0.0:
        set_collision_layer_value(1, true)   # restore collision
        var dir := Input.get_axis("move_left", "move_right")
        _transition(State.RUN if dir != 0.0 else State.IDLE)

# In _enter_state:
#   State.ROLL:
#       _roll_timer = ROLL_DURATION
#       set_collision_layer_value(1, false)  # invincible
#       anim.play("roll")
```
::::
:::

:::problem{difficulty="challenge"}
### P6 · Full class-based enemy AI with line-of-sight

Build a complete class-based enemy FSM with:

1. `PatrolState` — walks back and forth on a platform using a
 RayCast2D to detect ledges; reverses direction at ledge or wall.
2. `AlertState` — plays an exclamation animation for 0.5 s when
 the player first enters line-of-sight, then transitions to ChaseState.
 Uses a second RayCast2D pointing toward the player to check for walls
 blocking the sightline.
3. `ChaseState` — moves toward the player; if the player goes
 out of line-of-sight for more than 2 s, transitions back to PatrolState.
4. `AttackState` — plays an attack animation, deals damage, then
 returns to ChaseState.
5. A `take_damage()` method on the enemy with a guard that
 prevents interruption during AttackState (damage is still applied but the
 animation is not changed).

::::solution[Solution]
```gdscript
# enemy_patrol_state.gd
class_name EnemyPatrolState
extends State

var _dir: float = 1.0

func enter() -> void:
    owner_entity.get_node("AnimationPlayer").play("walk")

func physics_update(_delta: float) -> State:
    var e := owner_entity as CharacterBody2D
    e.velocity.x = _dir * e.PATROL_SPEED
    e.move_and_slide()

    if e.is_on_wall():
        _dir *= -1.0
    var ledge: RayCast2D = e.get_node("LedgeRay")
    if not ledge.is_colliding():
        _dir *= -1.0

    # Check line-of-sight to player
    var player := e.target
    if player and _can_see(e, player):
        return get_parent().get_node("EnemyAlertState")
    return null

func _can_see(e: Node, player: Node) -> bool:
    var dist := e.global_position.distance_to(player.global_position)
    if dist > e.CHASE_RANGE:
        return false
    var ray: RayCast2D = e.get_node("SightRay")
    ray.target_position = ray.to_local(player.global_position)
    ray.force_raycast_update()
    # If the ray hits the player (not a wall), we can see them
    return ray.get_collider() == player

# enemy_alert_state.gd
class_name EnemyAlertState
extends State

var _timer: float = 0.5

func enter() -> void:
    _timer = 0.5
    owner_entity.velocity = Vector2.ZERO
    owner_entity.get_node("AnimationPlayer").play("alert")

func physics_update(delta: float) -> State:
    _timer -= delta
    if _timer <= 0.0:
        return get_parent().get_node("EnemyChaseState")
    return null

# enemy_chase_state.gd
class_name EnemyChaseState
extends State

var _los_lost_timer: float = 0.0

func enter() -> void:
    owner_entity.get_node("AnimationPlayer").play("run")
    _los_lost_timer = 0.0

func physics_update(delta: float) -> State:
    var e      := owner_entity as CharacterBody2D
    var player := e.target
    if player == null: return get_parent().get_node("EnemyPatrolState")

    var dist := e.global_position.distance_to(player.global_position)
    if dist <= e.ATTACK_RANGE:
        return get_parent().get_node("EnemyAttackState")

    var ray: RayCast2D = e.get_node("SightRay")
    ray.target_position = ray.to_local(player.global_position)
    ray.force_raycast_update()
    var has_los := ray.get_collider() == player

    if has_los:
        _los_lost_timer = 0.0
        var dir := (player.global_position - e.global_position).normalized()
        e.velocity = dir * e.CHASE_SPEED
    else:
        _los_lost_timer += delta
        if _los_lost_timer >= 2.0:
            return get_parent().get_node("EnemyPatrolState")
        e.velocity = move_toward(e.velocity, Vector2.ZERO, 10.0)

    e.move_and_slide()
    return null

# In enemy.gd
func take_damage(amount: int) -> void:
    if fsm.current_state is DeadState: return
    hp -= amount
    if hp <= 0:
        fsm.transition_to_name("DeadState")
        return
    # Guard: don't interrupt attack animation — apply damage silently
    if fsm.current_state is EnemyAttackState: return
    fsm.transition_to_name("HurtState")
```
::::
:::
