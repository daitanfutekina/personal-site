---
title: "Practice Test 3"
source: "markdown"
---

Part VI · Chapter 30

# Practice Test 3

An original, full-length scored-core simulation emphasizing precise argument analysis and structural reading.

## Overview

Set a timer for **35 minutes per section**, and complete Sections I, II, and III in one sitting, with a **10-minute break after Section II**. Work without consulting any solution until all 77 questions are finished. This chapter models only the three scored sections; the administered LSAT also contains an unscored fourth section (Chapter 2).

**Flag, don't guess silently.** Record the number of any question you answer without confidence, even if you make a best guess. Your flags provide more useful study evidence than a raw score alone. After the timed sitting, return to those questions without a clock and record your reasons before looking at any answers: this is blind review (Chapter 22). Finally compare your timed and blind-review work with the explanations, and log the specific mistake for each miss (Chapter 23).

This test is **original practice written for this book**, not an official LSAC PrepTest. The official tests on LawHub remain the gold standard for timed calibration (Chapter 24). No conversion from this test's raw score to an official scaled score is valid.

## 30.1 Section I: Logical Reasoning

:::problem[Question I.1]
A council member argues that the library should remain open two evenings each week. The library director points out that visits during an earlier evening-hours trial were few. But that trial began during the town's annual summer festival, when even weekend library visits were unusually low. Furthermore, a recent survey found that many working residents could visit only after six o'clock. Although keeping the building open later would require rearranging staff shifts, no new positions would be necessary. The director's attendance figures therefore do not provide a sound reason to reject the proposal.

Which one of the following most accurately expresses the main conclusion of the council member’s argument?

- **(A)** The town should keep its library open two evenings each week.
- **(B)** The earlier trial coincided with a period of unusually low library attendance.
- **(C)** The director’s attendance figures were recorded accurately but do not represent typical demand.
- **(D)** The library can extend its hours without employing any additional staff.
- **(E)** The council should first conduct another survey before altering library hours.

::::solution[Solution]
**Answer:** (A)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The council member advocates two evenings of library service; the final sentence rebuts an objection in service of that recommendation.
2. **Support.** The festival explains low trial visits, the survey establishes unmet after-work demand, and existing shifts make the proposal feasible.
3. **Prephrase.** Identify the action the speaker ultimately wants the council to take, not merely an observation supporting it.
4. **Why (A) is right.** The statement is the positive recommendation that the criticisms and feasibility evidence are organized to defend.
5. **Why the others fail.**
    - **(B)** Background evidence: the festival timing explains why the trial is unrepresentative, but it is not the policy recommendation.
    - **(C)** Half-right evidence: the author argues that the numbers are poor grounds for rejecting the plan, not that every number was accurate.
    - **(D)** A supporting premise about staffing feasibility is mistaken for the broader conclusion.
    - **(E)** Invented procedure: the survey already exists, and the author never requests a second one.

**Check:** If you remove the final recommendation, the remaining claims are reasons without the policy position they support.
::::
:::
:::problem[Question I.2]
At one hospital, patients who received a follow-up telephone call within two days of discharge were less likely to be readmitted within a month than patients who did not receive a call. Nurses generally called patients they judged most capable of answering medication questions, because those conversations were quickest to complete. The hospital administrator concludes that the calls themselves prevented readmissions and proposes measuring nurses' performance by how many such calls they make. The administrator acknowledges that some patients could not be reached, but says the difference in readmission rates is too large to be accidental.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** infers that a reduction in readmissions establishes a reduction in every form of post-discharge complication.
- **(B)** overlooks the possibility that differences between patients selected for calls and other patients account for the difference in readmissions.
- **(C)** takes for granted that every patient who was called complied with the instructions given during the call.
- **(D)** fails to distinguish a telephone call made after discharge from a telephone call made before discharge.
- **(E)** generalizes from one hospital to the entire national hospital system.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The administrator credits calls with causing better outcomes and uses that causal claim to justify a performance measure.
2. **Support.** The called group was systematically selected for capacity to answer questions, an attribute that might independently predict outcomes.
3. **Prephrase.** Look for selection bias, a common-cause explanation, or a meaningful difference between groups.
4. **Why (B) is right.** The comparison does not hold patients comparable; those reached may have had better recovery prospects even without the calls.
5. **Why the others fail.**
    - **(A)** Outcome shift: the administrator claims an effect on readmissions, not on every complication.
    - **(C)** Invented mediator: the administrator may attribute benefit to the call without assuming universal patient compliance.
    - **(D)** Wrong comparison: the two reported groups differ by whether a follow-up call was received, not by before-versus-after timing.
    - **(E)** Scope mismatch: the administrator proposes performance measures for this hospital, not a national policy.

**Check:** Imagine equally effective calls that are assigned mostly to low-risk patients: the observed association could still appear.
::::
:::
:::problem[Question I.3]
An architect recommends preserving the brick facade of a former post office while converting the interior into apartments. A preliminary inspection found the facade visually intact, and the city values the building's historic street appearance. The architect argues that preserving the facade will be less expensive than dismantling it and building a visually similar replacement. The estimate includes the cost of repairing visible mortar cracks but excludes any work that might be required behind the bricks. The architect maintains that this omission does not affect the cost comparison.

Which one of the following is an assumption on which the architect’s cost argument depends?

- **(A)** The converted building will attract more tenants than a newly constructed building.
- **(B)** Every visible mortar crack can be repaired without replacing an entire brick.
- **(C)** Preserving the facade will not require hidden structural repairs so expensive that they reverse the projected cost advantage.
- **(D)** The city values historic preservation more highly than it values affordable housing.
- **(E)** A visually similar replacement facade would last fewer years than the original.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The architect concludes that keeping the facade will cost less than replacing it with a similar one.
2. **Support.** The estimates omit possible hidden repair costs that could erase the supposed savings.
3. **Prephrase.** Negate a modest limit on the uncounted expenses; if the neglected costs overwhelm the advantage, the comparison fails.
4. **Why (C) is right.** Negating it permits hidden repairs costly enough to make preservation more expensive, defeating the stated economic basis.
5. **Why the others fail.**
    - **(A)** Attractiveness to tenants could influence investment returns, but it is not required for comparing construction expenses.
    - **(B)** Too strong: some cracks could require new bricks while preservation still remains cheaper.
    - **(D)** Wrong comparison: the author argues about two facade treatments, not a social ranking of housing and heritage.
    - **(E)** Longevity is a different metric and is not needed for an up-front cost claim.

**Check:** Negation test: hidden repairs exceed the projected savings; the cheaper-preservation inference fails.
::::
:::
:::problem[Question I.4]
A rural clinic introduced automated appointment reminders and observed that the percentage of scheduled patients who failed to arrive fell from 18 percent to 11 percent in the next three months. The clinic manager attributes the decline to the reminders. A critic observes that, during the same period, the clinic stopped booking appointments more than six months ahead. Patients booking closer to their visit may be less likely to forget it. The manager nevertheless argues that the reminders deserve most of the credit for the decline.

Which one of the following, if true, most strengthens the manager’s argument?

- **(A)** The clinic sent reminders using both text messages and automated voice calls.
- **(B)** Other rural clinics generally have missed-appointment rates higher than 11 percent.
- **(C)** The cost of an automated reminder is lower than the cost of a missed appointment.
- **(D)** Among appointments booked within the same time-to-visit interval, patients sent reminders missed significantly fewer visits than comparable patients not sent reminders.
- **(E)** The number of appointments scheduled at the clinic increased during the pilot.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The manager claims reminders caused most of the reduction in missed appointments.
2. **Support.** The timing-policy change is a competing explanation because bookings closer to the visit can reduce missed visits.
3. **Prephrase.** Hold lead time constant and look for lower no-show rates among otherwise comparable reminded patients.
4. **Why (D) is right.** Within equal booking intervals, the treatment group does better than the control group, reducing the critic’s alternative-cause objection.
5. **Why the others fail.**
    - **(A)** Mechanism description without an outcome comparison; using two channels does not prove either changed attendance.
    - **(B)** Wrong comparison: another clinic’s higher level does not identify why this clinic’s rate fell.
    - **(C)** Cost-benefit evidence supports affordability but not the claimed cause of the decline.
    - **(E)** Raw volume can rise even while the no-show percentage falls; it does not isolate reminders.

**Check:** Compare like booking windows: the reminder effect remains after controlling for the proposed alternative.
::::
:::
:::problem[Question I.5]
A municipal archive applies the following rules. Every digitized land-use record is assigned a public catalog number. No record containing an unredacted medical address is made publicly searchable. Some nineteenth-century planning maps have been digitized, and every digitized planning map is a land-use record. The archivist notes that several land-use records remain unsearchable even though their catalog numbers have already been assigned. No rule specifies why those records are unsearchable. The archive also holds handwritten inspection notebooks, but nothing stated indicates whether any of those notebooks have been digitized.

Which one of the following must be true?

- **(A)** Every record with a public catalog number is publicly searchable.
- **(B)** No nineteenth-century planning map contains an unredacted medical address.
- **(C)** Every land-use record has been digitized.
- **(D)** At least one handwritten inspection notebook is publicly searchable.
- **(E)** At least one nineteenth-century planning map has a public catalog number.

::::solution[Solution]
**Answer:** (E)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** This is an inference set, not an argument: locate a guaranteed consequence of the classification rules.
2. **Support.** Some nineteenth-century planning maps are digitized; digitized planning maps are land-use records; all digitized land-use records get numbers.
3. **Prephrase.** Chain the three statements and preserve the existential “some.”
4. **Why (E) is right.** At least one map passes through digitized map → digitized land-use record → public catalog number.
5. **Why the others fail.**
    - **(A)** Reversal: a number does not guarantee searchability; numbered unsearchable records are explicitly mentioned.
    - **(B)** An unsupported exclusion: a map could contain such information and be unsearchable.
    - **(C)** Quantifier inflation: rules about digitized records do not imply all land-use records were digitized.
    - **(D)** Out-of-scope existence: the notebooks’ digitization or searchability status is unspecified.

**Check:** Diagram: some old maps → digitized → land-use → numbered; hence some old maps are numbered.
::::
:::
:::problem[Question I.6]
After renovating its main gallery, a museum reported that visitors spent an average of twelve additional minutes in the room. The renovation added a large skylight, replaced the wall labels, and moved several benches closer to the paintings. The curator credits the increase entirely to natural daylight, reasoning that bright rooms invite closer attention. A colleague questions that claim, since the museum measured room occupancy from entry to exit rather than time spent examining artworks. Both agree that the additional minutes were measured accurately.

Which one of the following, if true, most seriously weakens the curator’s explanation?

- **(A)** Visitors tended to enter the gallery through the same doorway before and after renovation.
- **(B)** Most of the additional time was spent sitting on the newly located benches while visitors waited for companions rather than looking at artworks.
- **(C)** Daylight levels in the gallery varied substantially with weather conditions.
- **(D)** Several paintings in the gallery are particularly vulnerable to prolonged sunlight exposure.
- **(E)** Many visitors praised the appearance of the new wall labels.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The curator claims skylight daylight entirely caused the increase in time in the room and made visitors more attentive.
2. **Support.** Time was counted broadly and multiple gallery changes occurred alongside the skylight.
3. **Prephrase.** Find evidence attributing the added minutes to another change or to an activity unrelated to viewing art.
4. **Why (B) is right.** Bench waiting explains the extra measured minutes without invoking either daylight or heightened attention, directly competing with “entirely.”
5. **Why the others fail.**
    - **(A)** Same entrance is a controlled feature, but it does not decide why duration increased.
    - **(C)** Variation in sunlight does not show that sunlight lacked an effect; no duration correlation is given.
    - **(D)** Conservation risk is relevant to museum policy, not the cause of visitor duration.
    - **(E)** Positive response to labels is compatible with, but does not quantify, why visits grew longer.

**Check:** The measured outcome includes waiting time; increased waiting defeats the inference from occupancy to attentive viewing.
::::
:::
:::problem[Question I.7]
A newspaper editor says, “We should publish correction notices on the same page where errors first appeared.” Some editors object that prominently displayed corrections could draw attention to errors readers never noticed. Yet independent reader interviews found that subscribers who remembered seeing a correction were more likely to say they trusted the paper than subscribers who were unaware of corrections. **Trust depends partly on readers believing the newspaper will acknowledge its mistakes.** Admittedly, interviews cannot establish whether corrections alone caused that trust. Still, their findings support a modest change in presentation policy.

The statement that trust depends partly on readers believing the newspaper will acknowledge mistakes plays which one of the following roles?

- **(A)** It is an objection the editor ultimately rejects as unsupported.
- **(B)** It restates the objection that corrections cause readers to notice otherwise unnoticed errors.
- **(C)** It is the sole empirical result reported by the independent interviews.
- **(D)** It supplies a general explanation linking the interview evidence to the recommended correction policy.
- **(E)** It limits the recommendation to newspapers whose subscribers never notice errors.

::::solution[Solution]
**Answer:** (D)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The editor recommends prominent, same-page corrections.
2. **Support.** Interviewed readers who recall corrections report more trust; the highlighted principle explains why acknowledgment could matter.
3. **Prephrase.** Distinguish a bridging explanatory premise from the policy conclusion and the statistical evidence.
4. **Why (D) is right.** The line asserts a plausible mechanism connecting visible acknowledgment to trust, supporting the editor’s move from interviews to policy.
5. **Why the others fail.**
    - **(A)** Role reversal: the editor endorses the belief-based explanation rather than presenting it to be rejected.
    - **(B)** Confuses two claims: the objection concerns drawing attention to errors; the highlighted line concerns acknowledgment and trust.
    - **(C)** Source confusion: interviews measured reported trust, not the general causal principle as an empirical result.
    - **(E)** Invented restriction: the editor applies the recommendation generally and never conditions it on readers being oblivious.

**Check:** Remove the highlighted premise and the survey-to-policy link loses its proposed explanation.
::::
:::
:::problem[Question I.8]
The parks department marks certain trees for special protection. Every tree on the city’s heritage list must receive a metal identification tag. Any tree that receives such a tag is inspected once per year. An oak outside the courthouse is known to have received a metal identification tag last week. The department’s spokesperson concludes that the courthouse oak is on the heritage list. A resident points out that other trees may receive tags for entirely different reasons, so the stated rules by themselves cannot establish the spokesperson’s conclusion.

The spokesperson’s conclusion follows logically if which one of the following is assumed?

- **(A)** Every tree that receives a metal identification tag is on the city’s heritage list.
- **(B)** Every heritage-list tree is inspected at least once per year.
- **(C)** The courthouse oak is inspected more frequently than any other oak in the district.
- **(D)** At least one tree on the heritage list stands near a government building.
- **(E)** No tree may be added to the heritage list unless it has first been inspected.

::::solution[Solution]
**Answer:** (A)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The spokesperson infers that a specific tagged oak belongs to the heritage list.
2. **Support.** Given heritage → tagged → inspected, the fact tagged(oak) alone does not establish heritage(oak).
3. **Prephrase.** Add the missing reverse conditional tagged → heritage.
4. **Why (A) is right.** Combining tagged(oak) with every tagged tree being heritage yields heritage(oak) by modus ponens.
5. **Why the others fail.**
    - **(B)** Already implied by the two given rules, but heritage → inspected does not identify a tagged oak as heritage.
    - **(C)** Comparative inspection frequency does not connect tagging to list membership.
    - **(D)** Existence of a different heritage tree at a government building is irrelevant to this oak.
    - **(E)** Heritage → previously inspected still leaves tagged trees outside heritage possible.

**Check:** With tagged → heritage, the observed tag directly entails membership; without it, the converse is invalid.
::::
:::
:::problem[Question I.9]
A paleontologist excavating a dry lakebed has identified six unusually complete skeletons of an extinct amphibian. Most skeletons of the same species held in other museums are fragmentary. She therefore concludes that the animals in this lakebed population were substantially healthier than members of the species elsewhere. However, the lakebed’s fine sediment rapidly buried carcasses, while remains at many other sites lay exposed to scavengers and erosion. She acknowledges that burial conditions differ but says that only complete skeletons offer enough information for her comparison.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that the lakebed population contained a greater number of animals than other populations because it yielded more complete fossils.
- **(B)** uses a difference in fossil preservation to infer that the two sets of remains belong to different species.
- **(C)** assumes that the six lakebed skeletons were all deposited during the same season.
- **(D)** takes the completeness of the lakebed specimens to establish that scavenging never occurred anywhere around the lake.
- **(E)** uses the preservation state of remains as evidence of health without adequately separating preservation conditions from the animals’ condition when alive.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The paleontologist attributes greater health to the lakebed population.
2. **Support.** Completeness varies with burial, erosion, and scavengers, factors that occur after death and do not measure health.
3. **Prephrase.** Distinguish what the fossil record preserves from the property of living animals being inferred.
4. **Why (E) is right.** The same healthy skeleton could survive whole in fine sediment but shatter elsewhere; preservation is a confounder.
5. **Why the others fail.**
    - **(A)** Wrong attribute: the conclusion concerns relative health, not relative population size.
    - **(B)** Misattributes the conclusion: the specimens are explicitly of the same species, with health compared across populations.
    - **(C)** Chronology distraction: the inferred greater health does not rest on a shared season of deposition.
    - **(D)** Overstates what is inferred: differences in preservation, not the complete absence of scavengers, are the evidence used.

**Check:** Test a world with identical health but different burial: complete versus fragmentary specimens still result.
::::
:::
:::problem[Question I.10]
A transit agency cut the price of a one-way bus ticket by 20 percent. In the next quarter, the total number of paid trips increased by only 5 percent, yet the agency’s total fare revenue increased by 12 percent. The agency made no changes to its routes, received no new fare subsidy, and continued counting paid trips using the same electronic system. Auditors verified all three reported figures. An analyst says that focusing only on the posted one-way price misses a relevant distinction among the different types of fares purchased.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The agency’s fuel and maintenance expenses were lower than in the quarter before the fare reduction.
- **(B)** More travelers used the bus rather than their cars after publicity about the discounted one-way fare.
- **(C)** During the quarter, a substantially larger share of riders bought higher-priced express tickets, whose prices were unchanged, instead of the discounted one-way local tickets.
- **(D)** The discount increased sales of the cheaper local tickets to occasional riders.
- **(E)** Fewer trips were taken during the morning rush hour, but more were taken in the evening.

::::solution[Solution]
**Answer:** (C)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The puzzle is higher total revenue despite a lower local fare and only a small increase in trips.
2. **Support.** The average revenue per paid trip must have risen; the stated fare cut affects only one category.
3. **Prephrase.** Find a shift in purchases toward fares with greater revenue per trip.
4. **Why (C) is right.** The changed ticket mix can raise average fare paid enough to offset the local discount and modest trip growth.
5. **Why the others fail.**
    - **(A)** Profit/revenue shell game: lower expenses raise net income but not the stated fare receipts.
    - **(B)** A cause of increased usage is insufficient: with trips up only 5 percent and ordinary fare down 20 percent, the average collected fare still needs explanation.
    - **(D)** Wrong direction for revenue per trip: selling more discounted tickets does not explain why receipts rose faster than trip counts.
    - **(E)** Time-of-day redistribution cannot account for a larger average fare when no time-dependent price difference is supplied.

**Check:** Revenue = paid trips × average fare collected; the mix shift raises the second factor.
::::
:::
:::problem[Question I.11]
A reporter has documents indicating that a contracting official awarded a lucrative bid to a former business partner. The documents are authentic but do not establish that the official intervened in the selection. An anonymous source claims that the official secretly directed staff to favor the partner, although the reporter cannot independently verify this claim. The editor proposes publishing the documented relationship but withholding the source’s unverified allegation. Another journalist objects that the allegation could be newsworthy even without verification. The question is which editorial rule most directly supports the editor’s approach.

Which one of the following principles, if accepted, most justifies the editor’s proposed decision?

- **(A)** News organizations should publish independently verified facts of public importance while withholding consequential allegations they have not been able to corroborate.
- **(B)** Journalists should never use information supplied by anyone unwilling to be identified publicly.
- **(C)** Any accusation concerning public contracts should be published immediately to deter corruption.
- **(D)** Whenever a story concerns public officials, it should be withheld until criminal charges are filed.
- **(E)** The more consequential an allegation would be if true, the less verification a journalist should demand.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The editor wants to report the confirmed relationship while not representing an unconfirmed accusation as fact.
2. **Support.** One aspect is verifiable; the alleged interference has only uncorroborated anonymous testimony.
3. **Prephrase.** Choose a rule that separates permissible verified reporting from improper presentation of unverified allegations.
4. **Why (A) is right.** The rule requires publishing the verified relationship but withholding the uncorroborated claim of intervention, matching both parts of the decision.
5. **Why the others fail.**
    - **(B)** Too absolute: it bans all anonymous-source information, rather than unverified accusations presented as settled.
    - **(C)** Opposite priority: automatic publication would not justify withholding the unverified interference charge.
    - **(D)** Excessively restrictive: the editor does not propose withholding the verified relationship until a prosecution.
    - **(E)** Reverses the editor’s evidence standard by relaxing verification for high-stakes charges.

**Check:** Apply the rule separately to the documented relationship and the unsupported intervention claim; it yields the editor’s split treatment.
::::
:::
:::problem[Question I.12]
A neighborhood group wants to plant edible vegetables in an abandoned lot. A laboratory reported that samples from the lot’s topsoil contained concentrations of lead below the city’s planting threshold. The coordinator concludes that vegetables grown anywhere in the lot will be safe to eat without importing clean soil. The laboratory sampled only the northern half of the lot because rubble blocked access to the southern half. The coordinator notes that the lot had been part of a single property for decades and therefore regards the test results as representative.

The coordinator’s argument requires assuming which one of the following?

- **(A)** The tested northern half of the lot is less contaminated than soil at some other vacant lots in the city.
- **(B)** The rubble on the southern half will be removed before the vegetable beds are planted.
- **(C)** Every edible crop is grown in soil with lead levels well below the city’s planting threshold.
- **(D)** The unsampled southern half of the lot does not contain contamination that would make vegetables grown there unsafe to eat.
- **(E)** The laboratory took enough northern soil samples to produce a precise northern-half average.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The coordinator claims any part of the lot can produce safe vegetables without imported soil.
2. **Support.** Only northern soil was tested, leaving potential hazards in southern soil unexamined.
3. **Prephrase.** Look for the minimal safety claim required to generalize from the tested half to the whole property.
4. **Why (D) is right.** If the south has contamination making its crops unsafe, the “anywhere” conclusion fails despite safe north samples.
5. **Why the others fail.**
    - **(A)** Wrong comparison: being cleaner than another lot does not establish safety on the untested southern half.
    - **(B)** Construction feasibility is not the missing soil-safety premise; removing rubble need not remove contaminants.
    - **(C)** Overly strong generalization about every crop everywhere is not needed for a claim about this lot.
    - **(E)** Better northern measurement does not address the untested southern half and so cannot support “anywhere.”

**Check:** Negation test: unsafe contamination in the untested south is compatible with all northern test results.
::::
:::
:::problem[Question I.13]
The county’s bridge database shows that every bridge inspected after a flood received either a routine maintenance designation or an urgent repair designation, but never both. Every bridge designated for urgent repair was closed to heavy trucks until repairs were complete. Some bridges with routine maintenance designations also remained closed to trucks, though the database does not state why. During the last flood, the East Fork bridge was inspected and remained open to heavy trucks throughout the inspection and follow-up period. Records also show that inspectors sometimes visit bridges between floods, but such visits are not covered by the designation rule.

Which one of the following is most strongly supported by the information above?

- **(A)** The East Fork bridge was in better structural condition than every bridge closed to trucks.
- **(B)** The East Fork bridge received a routine maintenance designation following its flood inspection.
- **(C)** Every bridge given a routine maintenance designation remains open to heavy trucks.
- **(D)** The county never closes a bridge to heavy trucks for reasons other than urgent repairs.
- **(E)** Inspectors gave the East Fork bridge no designation because it remained open.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** An inference is required from the post-flood designation split and one bridge’s observed status.
2. **Support.** Post-flood inspection means exactly one of routine or urgent; urgent implies closed. East Fork is not closed.
3. **Prephrase.** Use the contrapositive not closed → not urgent, then apply the exhaustive either-or.
4. **Why (B) is right.** Not closed rules out urgent; because one designation is required, routine follows.
5. **Why the others fail.**
    - **(A)** Unwarranted ranking: closure status does not order all bridges by structural condition.
    - **(C)** Contradicts the explicit note that some routine bridges remained closed.
    - **(D)** Excludes causes for closure that the passage expressly leaves open.
    - **(E)** Denies a mandatory designation following a flood inspection.

**Check:** Post-flood inspected → routine XOR urgent; urgent → closed; not closed → routine.
::::
:::
:::problem[Question I.14]
Every proposal approved by the heritage commission receives a compliance certificate. Every proposal receiving a compliance certificate is eligible for expedited review. The design for a small courtyard received heritage commission approval last month. The planning officer concludes that the courtyard design is eligible for expedited review. The officer makes no claim that every expedited proposal will ultimately receive a construction permit, since permit issuance depends on additional checks. The inference is confined to the eligibility status that follows from approval and certification.

Which one of the following arguments is most similar in its reasoning to the argument above?

- **(A)** All marathon runners train regularly; Omar trains regularly; therefore Omar runs marathons.
- **(B)** Some approved exhibits are advertised; every advertised exhibit draws visitors; therefore every approved exhibit draws visitors.
- **(C)** Only buildings with insulated windows qualify for a rebate; this building has insulated windows; therefore it qualifies.
- **(D)** If a laboratory passes inspection, it may reopen; the laboratory did not pass inspection; therefore it may not reopen.
- **(E)** Every registered apprentice receives a training badge; everyone with such a badge may enter the workshop; Leila is registered, so Leila may enter.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The design is eligible for expedited review.
2. **Support.** Approved → certificate → eligible; approved(design) establishes eligible(design).
3. **Prephrase.** Match the linked sufficient-condition chain and the individual case, not the subject matter.
4. **Why (E) is right.** Registered → badge → workshop access, plus registered(Leila), gives access by two valid forward inferences.
5. **Why the others fail.**
    - **(A)** Affirming the consequent: training is required of runners but is not enough to prove running status.
    - **(B)** Quantifier shift: “some approved” cannot yield a conclusion about every approved exhibit.
    - **(C)** Necessary/sufficient confusion: a necessary rebate condition is treated as sufficient.
    - **(D)** Denying the antecedent: lack of inspection does not rule out every other means of reopening.

**Check:** Both valid arguments instantiate A → B → C and A(a), hence C(a).
::::
:::
:::problem[Question I.15]
A medical practice changed its standard antibiotic instruction from four doses each day to two doses each day for a particular approved treatment. In the first month after the change, fewer patients reported missing a scheduled dose. The practice director concludes that simplifying the schedule improved adherence. But the clinic also replaced its paper instruction sheets with a nurse-led demonstration, including a review of each patient’s daily routine. The director claims this second change could not have caused the improvement, because the medication and total daily dose remained unchanged.

Which one of the following, if true, most weakens the director’s conclusion that the simpler schedule caused the improvement?

- **(A)** Patients generally report that twice-daily medication is easier to remember than four daily doses.
- **(B)** The medication’s active ingredient was identical before and after the scheduling change.
- **(C)** Among patients who continued on the four-dose schedule but received the nurse-led demonstration, missed-dose reports fell by as much as they did among patients switched to two doses.
- **(D)** The practice treated the same number of patients in the first month as in the preceding month.
- **(E)** Pharmacists in neighboring towns often provide written instructions rather than demonstrations.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The director credits improved adherence to fewer daily doses and dismisses the demonstration as irrelevant.
2. **Support.** Two interventions changed simultaneously, and keeping the medication constant does not isolate schedule from instruction quality.
3. **Prephrase.** Show the same improvement with the old schedule when the demonstration is introduced.
4. **Why (C) is right.** An unchanged dosing schedule plus better counseling produces equally large improvement, identifying a plausible alternative cause.
5. **Why the others fail.**
    - **(A)** General ease of remembering supports the schedule mechanism rather than undermining it.
    - **(B)** Same ingredient does not hold patient instruction constant.
    - **(D)** Stable patient volume does not control how patients learned their regimens.
    - **(E)** Other towns’ instruction practices do not test which change caused this clinic’s improvement.

**Check:** Same four doses + demonstration → same adherence gain; two doses are not necessary to explain it.
::::
:::
:::problem[Question I.16]
At a zoning hearing, 42 people spoke against converting an empty warehouse into small apartments, while only 11 spoke in favor. A council member concludes that a substantial majority of neighborhood residents oppose the proposal. The hearing took place on a weekday afternoon, and residents who wished to speak had to register in person before noon. In a survey commissioned by neither side, many residents said they could not leave work during that period. The council member responds that no one was prevented from writing to the city instead.

The argument is flawed because it...

- **(A)** assumes that everyone unable to attend the hearing would have spoken in favor of the proposal.
- **(B)** treats opposition to this warehouse conversion as proof that residents oppose all apartments.
- **(C)** fails to establish whether speakers who supported the proposal spoke for as long as opponents did.
- **(D)** assumes that those who spoke at a meeting with participation barriers reflect the preferences of the neighborhood as a whole.
- **(E)** confuses the number of written objections received with the number of people who attended the hearing.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The council member generalizes from speakers at one hearing to the neighborhood majority.
2. **Support.** The speaker sample is self-selected, with time-of-day and registration barriers excluding many potential participants.
3. **Prephrase.** Find the unrepresentative sampling mistake.
4. **Why (D) is right.** The group able and motivated to speak may differ systematically from residents whose views are being inferred.
5. **Why the others fail.**
    - **(A)** Attributes an assumption the council member never makes; the inference merely ignores nonattenders, whose views are unknown.
    - **(B)** Overstates the scope: the conclusion concerns only the proposal discussed at the hearing.
    - **(C)** Length-of-speech distraction: the count of speakers, not accumulated speaking time, is used to estimate majority opinion.
    - **(E)** Wrong evidence: the argument explicitly relies on oral speakers; the possibility of written submissions is offered only in response.

**Check:** A majority among 53 hearing speakers cannot establish a majority among all neighborhood residents.
::::
:::
:::problem[Question I.17]
A museum label describes an ancient pot as ceremonial because it was found near a burial chamber. A visiting archaeologist challenges the label: several ordinary cooking pots were found near chambers at the same site, and the pot in question has soot marks consistent with repeated heating. The archaeologist does not claim that ceremonial vessels were never heated; some rituals involved fire. Instead, she argues that location alone cannot establish ceremonial use, especially where an independent indicator points toward an everyday function. She recommends that the museum present the ceremonial attribution as tentative.

Which one of the following most accurately describes the archaeologist’s method of reasoning?

- **(A)** She accepts the label’s ceremonial explanation but argues that the museum should describe it with more technical terminology.
- **(B)** She undermines an inference by showing that its cited evidence occurs in cases lacking the inferred property and by introducing contrary evidence.
- **(C)** She rejects the interpretation on the basis that ceremonial objects could not have been heated repeatedly.
- **(D)** She infers that the pot was used for cooking exclusively because of the soot marks.
- **(E)** She discredits the label by showing the discovery location had been recorded incorrectly.

::::solution[Solution]
**Answer:** (B)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The archaeologist recommends treating ceremonial attribution as tentative rather than established.
2. **Support.** Cooking pots occur in similar locations and soot is independently consistent with a practical use.
3. **Prephrase.** Look for an argument that reduces the diagnostic value of one indicator and adds counterevidence.
4. **Why (B) is right.** Common location with cooking pots undercuts location as a sufficient indicator; soot further weakens the ceremonial diagnosis.
5. **Why the others fail.**
    - **(A)** Half-right recommendation trap: she wants tentative status because the evidence is weak, not a cosmetic wording upgrade while accepting certainty.
    - **(C)** Too absolute: she acknowledges that some ceremonial rituals did involve fire.
    - **(D)** Opposite overclaim: soot supports ordinary use, but she does not assert exclusive use or a proved alternative.
    - **(E)** Invented evidence: she challenges the inference from an accurately described location, not the accuracy of the location record.

**Check:** Structure: same alleged indicator in nonceremonial cases + an alternative indicator → attribution not proved.
::::
:::
:::problem[Question I.18]
A coastal town converted an unused parking lot into a shallow planted wetland. Following moderate storms, nearby drains overflowed less often than before the conversion. The town engineer argues that the wetland reduced local flooding by temporarily storing runoff. A critic points out that the town also enlarged a drainage pipe upstream that year. The engineer concedes that both changes could have helped but maintains that the wetland made a substantial independent contribution. The town has measurements of water level at the wetland inlet and outlet during storms.

Which one of the following, if true, most strengthens the engineer’s claim about the wetland?

- **(A)** The wetland uses native plants and requires relatively little routine maintenance.
- **(B)** The larger upstream pipe was less expensive to install than engineers originally estimated.
- **(C)** Some residents visited the wetland to watch migrating birds after the planting.
- **(D)** The upstream pipe carries more stormwater than the old pipe under identical test conditions.
- **(E)** During storms, inlet measurements regularly showed substantially more runoff entering the wetland than outlet measurements showed leaving it until after peak drain levels had passed.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The wetland independently contributed to reducing flooding by storing runoff during the critical period.
2. **Support.** Overflow fell but an enlarged pipe is an alternative cause of the observed difference.
3. **Prephrase.** Find direct measurements of temporary retention specifically in the wetland.
4. **Why (E) is right.** The inflow-outflow discrepancy across the peak demonstrates stored water unavailable to overwhelm drains at the dangerous time.
5. **Why the others fail.**
    - **(A)** Ecological appropriateness and maintenance costs do not show flood-storage performance.
    - **(B)** Pipe installation savings are unrelated to how much water the wetland retains.
    - **(C)** Recreation and wildlife do not measure hydrological contribution.
    - **(D)** Greater pipe capacity strengthens the competing explanation, not the independent wetland mechanism.

**Check:** Temporary inflow greater than outflow at the storm peak is direct evidence of storage.
::::
:::
:::problem[Question I.19]
Planner: When a city evaluates bids for street repairs, it should conceal company names from reviewers until technical scores are assigned. Knowing who submitted a bid can unconsciously favor familiar contractors, and the scores should reflect engineering quality alone. Financial reliability may be checked afterward. Auditor: Blind scoring might reduce favoritism, but reviewers often need a bidder’s past work history to judge whether its promised method is feasible. That history is usually inseparable from the bidder’s identity. Reviewers should therefore see company names during technical scoring, while having to document how past performance affected each score.

The planner and the auditor disagree about whether...

- **(A)** company names should be visible to reviewers while technical scores for street-repair bids are being assigned.
- **(B)** favoritism is ever a concern in public procurement.
- **(C)** financial reliability should be considered at some point before a contract is awarded.
- **(D)** past performance can provide relevant information about a contractor’s proposed work.
- **(E)** technical scores should reflect the quality of proposed engineering work rather than social connections.

::::solution[Solution]
**Answer:** (A)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Compare the speakers’ positions on the timing of bidder identification.
2. **Support.** The planner says hide names until after technical scoring; the auditor says display names during that scoring.
3. **Prephrase.** A point at issue requires affirmative evidence that one says yes and the other says no.
4. **Why (A) is right.** The pair express direct opposing positions on whether names are displayed during technical evaluation.
5. **Why the others fail.**
    - **(B)** Both acknowledge at least a possibility of favoritism; the auditor calls blind scoring a way to reduce it.
    - **(C)** The planner expressly permits a later financial check; the auditor does not reject considering reliability.
    - **(D)** The auditor stresses past performance, while the planner does not explicitly deny its relevance, only when identifiers should be revealed.
    - **(E)** Both want scores grounded in engineering rather than favoritism, though they prefer different safeguards.

**Check:** Planner: no identity during scoring. Auditor: identity during scoring. Two determinate opposite answers.
::::
:::
:::problem[Question I.20]
The city issues renovation permits under these rules: every application involving a change to a load-bearing wall requires structural review; any application requiring structural review must be signed by a licensed engineer; and no application submitted after the filing deadline receives expedited processing. Some applications for historic buildings were submitted late, and each of those late historic-building applications involves a load-bearing wall change. The city sometimes allows an applicant to resubmit a revised plan, but nothing indicates that these particular applications have been resubmitted.

Which one of the following must be true?

- **(A)** No renovation permit for a historic building is eligible for expedited processing.
- **(B)** Every application signed by an engineer involves a load-bearing wall change.
- **(C)** Some late applications for historic buildings require both structural review and an engineer’s signature.
- **(D)** Some late historic-building applications have already received renovation permits.
- **(E)** Every application requesting expedited processing was submitted before the deadline.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** Derive what must follow about the explicitly mentioned late historic-building applications.
2. **Support.** Some are late and involve wall changes; wall change → structural review → engineer signature.
3. **Prephrase.** Use forward chains on the “some” group, without reversing any conditions.
4. **Why (C) is right.** Each member of the specified nonempty group meets both review and signature requirements.
5. **Why the others fail.**
    - **(A)** Too broad: some historic applications are late, not all; timely ones could receive expedited processing.
    - **(B)** Reversal: engineer signature may be needed for other reasons too.
    - **(D)** Unwarranted outcome: requirements say nothing about whether any permit has been issued.
    - **(E)** A request can be filed late and denied expedited processing; filing is not restricted by requesting.

**Check:** Some late historic → wall change → structural review → engineer signature.
::::
:::
:::problem[Question I.21]
Every radio program that wins the local broadcasting award attracts a loyal audience. A morning show has attracted a loyal audience over the past year, according to repeated listener surveys. Its producer therefore concludes that the morning show will win the broadcasting award this year. The producer notes that the award committee often praises audience loyalty, but does not claim that the committee has made loyalty its only criterion. The show's sponsor asks whether the reasoning really supports such a confident prediction.

Which one of the following arguments exhibits the most similar flaw?

- **(A)** Every prizewinning novel was published; this manuscript has not been published; so it is not a prizewinning novel.
- **(B)** All licensed drivers must pass a vision test; Hana has not passed one; so Hana is not licensed.
- **(C)** Some highly rated restaurants use local produce; this restaurant uses local produce; so it might be highly rated.
- **(D)** If a lecture room is reserved, its doors will be unlocked; this room is reserved; so its doors will be unlocked.
- **(E)** Every certified organic farm uses approved soil practices. This farm uses approved soil practices. So this farm is certified organic.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The producer concludes loyal audience → award even though only award → loyal audience is known.
2. **Support.** Award winners have a feature; the show has that feature. The argument affirms the consequent.
3. **Prephrase.** Match the mistaken converse of a one-way rule.
4. **Why (E) is right.** Certified organic → approved practices; approved practices → certified organic is precisely the same invalid reversal.
5. **Why the others fail.**
    - **(A)** Valid contrapositive: unpublished → not prizewinning, provided winners were published.
    - **(B)** Valid contrapositive again: licensed → passed; not passed → not licensed.
    - **(C)** Too weak and wrong quantifier: “might” does not assert a mistaken conclusion, and the premise says some.
    - **(D)** Valid modus ponens: reserved → unlocked; reserved; therefore unlocked.

**Check:** Both flawed arguments use A → B, B(a), therefore A(a).
::::
:::
:::problem[Question I.22]
An urgent-care clinic plans to use a chatbot to direct patients either to a nurse or to an online self-care guide. During testing, the chatbot correctly identified almost every case that participating doctors had categorized as requiring urgent review. The clinic manager concludes that the chatbot can safely replace the current receptionist’s initial screening for all incoming patients. The tests excluded patients who wrote in languages other than English, because the developers had not yet adapted the system for multilingual input. The manager believes this exclusion is immaterial.

The manager’s argument depends on which one of the following assumptions?

- **(A)** The chatbot’s handling of patients excluded from testing will not create safety risks that defeat replacing screening for all incoming patients.
- **(B)** No future patient will ever describe symptoms ambiguously.
- **(C)** The chatbot will correctly diagnose every condition that a physician might encounter.
- **(D)** Receptionists currently refer every patient to a physician, regardless of symptoms.
- **(E)** The clinic will save money on payroll immediately after launching the chatbot.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The chatbot is safe for screening all patients, including groups not represented in the pilot.
2. **Support.** Test success concerns English-language input, while the proposed replacement includes patients excluded from tests.
3. **Prephrase.** Find the minimal bridge from the evaluated subset to the broader safety claim.
4. **Why (A) is right.** If excluded-language patients create a serious unaddressed triage risk, the all-patient safety conclusion fails.
5. **Why the others fail.**
    - **(B)** Perfection about ambiguous descriptions is far stronger than a screening system needs.
    - **(C)** Diagnosis is not the task: routing to nurse versus guide is the task under evaluation.
    - **(D)** The current receptionist’s practice may matter for relative performance, but need not be a universal physician referral.
    - **(E)** Payroll savings is a separate economic consideration, irrelevant to safe replacement.

**Check:** Negate: excluded patients face serious new unsafe triage; “safe for all” no longer follows.
::::
:::
:::problem[Question I.23]
A nonprofit local-news site introduced a registration requirement for reading its investigative articles. Although fewer people now access those articles, the site’s monthly donations increased. Its director argues that requiring registration makes readers more committed and hence more willing to donate. Critics suspect a different explanation: during the same months, the site began prominently displaying a donation request on its home page. The director insists that registration itself explains the increase and proposes extending registration to every article. The site can compare donors’ registration status and the pages they viewed before donating.

Which one of the following would be most useful to determine in evaluating the director’s explanation?

- **(A)** Whether the site’s investigative articles are longer on average than its other articles.
- **(B)** Whether the donations came from people who live inside or outside the site’s principal reporting district.
- **(C)** Whether the home-page donation request used a larger typeface than the old footer request.
- **(D)** Whether donation rates increased among people exposed to the new registration requirement but not to the home-page donation request, compared with similar readers not required to register.
- **(E)** Whether the site’s reporters prefer writing stories for registered readers.

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The director attributes increased donations to registration-induced commitment.
2. **Support.** Both registration and a more prominent donation appeal began around the same period.
3. **Prephrase.** Discriminate the effects of registration from the appeal by contrasting otherwise similar audiences.
4. **Why (D) is right.** An isolated increase associated with registration rather than the homepage ask would favor the director; a failure would favor the critics.
5. **Why the others fail.**
    - **(A)** Article length does not distinguish the two fundraising mechanisms.
    - **(B)** Donor geography could describe the audience but not identify whether registration or visibility caused giving.
    - **(C)** Typeface difference establishes a design feature without measuring its actual effect relative to registration.
    - **(E)** Staff preference has no causal bearing on donation behavior.

**Check:** Ask two-way: if registration-only readers donate more, the claim gains support; if not, it loses support.
::::
:::
:::problem[Question I.24]
An exhibition curator claims that a newly excavated set of stone tools must have been used exclusively for hunting because three widely cited researchers have identified them as hunting equipment. A fourth specialist notes wear patterns compatible with woodworking and cautions that identical shapes can serve multiple purposes. The curator dismisses this objection, arguing that the three researchers publish in more prestigious journals and are more frequently invited to conferences. The curator gives no independent account of why the wear patterns would be incompatible with woodworking.

The curator’s argument is most vulnerable to criticism because it...

- **(A)** treats disagreement among specialists as proof that none of the specialists possesses relevant expertise.
- **(B)** assumes that all archaeological judgments can be settled by comparing the number of publications on each side.
- **(C)** treats the prominence of experts as sufficient to settle a disputed interpretation without addressing the competing physical evidence.
- **(D)** concludes that no stone tool used for hunting by any ancient population could ever have been used for woodworking.
- **(E)** fails to show that the researchers’ interpretation represents the majority view of all archaeologists.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The curator insists exclusive hunting use despite evidence of possible woodworking.
2. **Support.** Authority and prestige replace examination of wear patterns that bear directly on multiple uses.
3. **Prephrase.** Look for appeal to authority rather than dealing with the opponent’s evidence; also note “exclusively.”
4. **Why (C) is right.** The three researchers’ stature does not rule out the fourth specialist’s proposed use, and no rebuttal of physical evidence is supplied.
5. **Why the others fail.**
    - **(A)** The curator does not conclude experts lack expertise; instead he elevates prestigious experts without answering material evidence.
    - **(B)** Over-specific distortion: the curator cites journal prestige and invitations as credentials, not a numerical publication count.
    - **(D)** Quantifier inflation: the curator claims exclusive use for one excavated set, not that all hunting tools used anywhere were incapable of woodworking.
    - **(E)** Popularity shell game: even a majority opinion would not independently rebut the proposed woodworking wear patterns.

**Check:** Prestige can be true even if the wear patterns support woodworking; it does not establish exclusivity.
::::
:::
:::problem[Question I.25]
A city awards a public-art commission using a rule announced before proposals are submitted: each submission receives a design score and an installation-risk score, and the contract goes to the highest design score among proposals whose installation risk is acceptable. Sculpture K received the highest design score overall but failed the published risk threshold. Sculpture L received the second-highest design score and passed the threshold. The commission instead selected sculpture M, whose design score was lower than L’s but whose fabrication plan the commissioners said was personally appealing. No emergency exception to the published rule applies.

Which one of the following principles most directly shows that the commission acted improperly?

- **(A)** The artist whose proposal is most technically innovative should receive the award regardless of feasibility.
- **(B)** When a public agency announces binding selection criteria in advance, it should not replace those criteria with unannounced preferences after receiving bids.
- **(C)** Commissioners should always prefer sculptures with the lowest installation risk, whatever their design score.
- **(D)** An agency may reject any proposal if some members dislike its appearance.
- **(E)** A publicly funded artwork should be chosen only after every resident has voted on the finalists.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The commission violated its own published decision rule by bypassing higher-scoring eligible L.
2. **Support.** K failed threshold; L was highest design among eligible known proposals; M was chosen on a private new criterion.
3. **Prephrase.** Find the requirement to honor announced criteria rather than post hoc personal tastes.
4. **Why (B) is right.** The stated principle condemns precisely replacing the binding score-and-risk rule with a commissioner’s undeclared aesthetic preference.
5. **Why the others fail.**
    - **(A)** Innovation is not the published criterion, and would not address disqualifying risk.
    - **(C)** Risk is a cutoff rather than an objective to minimize at all costs; the principle misreads the rule.
    - **(D)** Aesthetic displeasure as unlimited rejection discretion excuses the rule change rather than showing impropriety.
    - **(E)** Unannounced universal voting is an unrelated governance condition, not required by the facts.

**Check:** Under the announced rule, eligible L outranks eligible M; the commission awards M for a different reason.
::::
:::
## 30.2 Section II: Reading Comprehension

### Passage 1

In maritime disputes, the recovery of an abandoned object at sea can seem an uncomplicated case for rewarding initiative. A vessel that undertakes a costly and hazardous recovery has provided a service that the absent owner could not provide at the time. Yet consider a drifting oceanographic instrument whose owner is not absent through neglect. Researchers may have deliberately released it to follow currents, knowing that it would appear unmoored to passing crews. An unqualified application of salvage incentives to these objects might encourage mariners to retrieve instruments that were never in danger of loss. The apparent benefit of recovery would then come at the cost of the research the instrument was designed to conduct.

Traditional accounts of salvage emphasize voluntary assistance to property exposed to marine peril. The first requirement distinguishes a genuine rescue from the opportunistic interception of property that is merely unattended. But peril is not a property that can always be observed from the deck of a passing ship. An instrument floating far from any harbor may be functioning exactly as intended, while an identical instrument with a failed beacon may be in danger of colliding with a vessel. Some legal commentators therefore suggest that the critical question should be whether intervention was reasonably necessary in light of information available to the assisting crew, not whether the object was later shown to have been in danger. This approach would protect well-intentioned rescuers who act under genuine uncertainty.

That suggestion, however, contains a risk of its own. A crew might claim uncertainty while disregarding clear markings, publicly available instrument identifiers, or standard radio channels through which research operators can be contacted. If a reward follows whenever a crew asserts that it believed the object was endangered, the system encourages a convenient failure to investigate. An alternative is a two-stage inquiry. First, the decision maker should ask whether the crew took reasonable steps, given the circumstances, to determine the object's function and status before intervening. Second, it should assess whether intervention was defensible in view of what those steps actually revealed. There will be emergencies in which even a short inquiry is unsafe; reasonable inquiry need not mean exhaustive inquiry.

This proposal should not be mistaken for an attempt to eliminate incentives to assist. Where an instrument is sinking in a shipping lane or plainly damaged, delay could destroy the very property that salvage law seeks to preserve. Conversely, when a drifting sensor broadcasts its status and position and poses no immediate hazard, removing it may be less a rescue than an interference. The two-stage approach aims to distinguish the cases without relying solely on either the rescuer's stated belief or information learned only afterward. Its broader lesson is that law can reward initiative while requiring attention to the purpose of the property ostensibly being saved. The choice is not between aggressive recovery and no recovery, but between intervention justified by circumstances and intervention rewarded merely because it occurred.

:::problem[Question II.1]


Which one of the following most accurately states the main point of the passage?

- **(A)** Salvage law should deny rewards for recovering any instrument intentionally placed at sea.
- **(B)** Salvage incentives for drifting research instruments should depend in part on reasonable inquiry into whether intervention was justified, rather than solely on recovery itself.
- **(C)** The chief difficulty in maritime rescue is that researchers often fail to label equipment properly.
- **(D)** Decisions about salvage should be based exclusively on what was learned after an object was recovered.
- **(E)** Mariners should receive salvage rewards whenever they sincerely state that they thought an object was endangered.

::::solution[Solution]
**Answer:** (B)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author recommends a two-stage reasonable-inquiry standard for deciding justified intervention.
2. **Support.** Paragraphs one and two expose the difficulty; three presents the standard; four defends its balanced incentives.
3. **Prephrase.** Look for the proposed middle rule that spans both true emergencies and nonperilous drifting devices.
4. **Why (B) is right.** The answer captures the method and its aim without eliminating salvage or accepting unexamined subjective belief.
5. **Why the others fail.**
    - **(A)** Too absolute: intentionally released instruments can subsequently become endangered.
    - **(C)** Too narrow: markings matter in one example but the overall proposal concerns reasonable investigation and intervention.
    - **(D)** Opposite criterion: hindsight alone is rejected in favor of information reasonably available then.
    - **(E)** Reverses the caution against a bare claim of uncertainty.

**Check:** Paragraph three states the two-part test; paragraph four explains why neither blanket reward nor blanket denial is warranted.
::::
:::
:::problem[Question II.2]


According to the passage, what is a defect of awarding recovery rewards whenever a crew says it believed an instrument was in danger?

- **(A)** It would require crews to complete an exhaustive investigation even during emergencies.
- **(B)** It would make it impossible to reward recovery of a sinking instrument.
- **(C)** It would automatically eliminate the distinction between territorial waters and the open sea.
- **(D)** Such a rule could encourage crews to avoid readily available information about an instrument’s function.
- **(E)** It would require courts to decide whether a research instrument was valuable to its owner.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The passage notes that a subjective-belief test can reward deliberate ignorance.
2. **Support.** The third paragraph mentions ignored markings, identifiers, and radio contact routes.
3. **Prephrase.** Recall the practical incentive created by relying exclusively on professed belief.
4. **Why (D) is right.** A crew could conveniently claim ignorance after failing to consult easily accessible information.
5. **Why the others fail.**
    - **(A)** Reversal: exhaustive inquiry is expressly rejected as a condition in urgent situations.
    - **(B)** The passage says clear danger can justify intervention and incentives.
    - **(C)** No jurisdictional distinction is discussed; this injects external maritime-law doctrine.
    - **(E)** Value assessment is not presented as the objection to belief-only awards.

**Check:** Find the sentence about rewarding a “convenient failure to investigate” in paragraph three.
::::
:::
:::problem[Question II.3]


It can most reasonably be inferred that the author would favor a salvage reward for which one of the following actions?

- **(A)** A crew promptly retrieves a visibly damaged sensor that is sinking into a heavily traveled shipping lane, without first attempting lengthy contact with its operator.
- **(B)** A crew removes a functioning research sensor despite a clearly displayed “do not retrieve” instruction and no evident hazard.
- **(C)** A crew retrieves every unattended floating object simply to maximize its chance of an award.
- **(D)** A crew refuses to help an endangered instrument unless it can prove the owner legally abandoned it.
- **(E)** A crew waits for extensive office records while a damaged instrument is about to sink, because more information is always preferable.

::::solution[Solution]
**Answer:** (A)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author allows urgent rescue where inquiry would be dangerous or waste crucial time.
2. **Support.** Paragraph four specifically discusses sinking instruments in shipping lanes; paragraph three waives exhaustive investigation in emergencies.
3. **Prephrase.** Find an urgent, objectively defensible intervention with limited but reasonable inquiry.
4. **Why (A) is right.** The combination of visible danger, collision risk, and time pressure fits the stated emergency rationale.
5. **Why the others fail.**
    - **(B)** Disregards accessible status evidence in a nonemergency, failing both stages of the test.
    - **(C)** Blanket opportunity-driven collection is the behavior the proposed standard discourages.
    - **(D)** Abandonment is not required; rescue of perilous property is distinct from ownerless property.
    - **(E)** Exhaustive inquiry is explicitly unnecessary when delay would jeopardize rescue.

**Check:** Apply stage one: brief inquiry reasonable under emergency; stage two: urgent intervention defensible.
::::
:::
:::problem[Question II.4]


The discussion of publicly available identifiers and radio channels in the third paragraph primarily serves to...

- **(A)** demonstrate that all oceanographic devices can be traced to their operators in real time.
- **(B)** explain why no ship should ever approach an unmoored scientific instrument.
- **(C)** illustrate why a crew’s asserted uncertainty may be unreasonable if useful information was accessible.
- **(D)** show that retrieval rewards are already routinely denied under an existing uniform standard.
- **(E)** establish that most research operators deliberately conceal the location of their equipment.

::::solution[Solution]
**Answer:** (C)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The author introduces identifiers to challenge belief-only rewards.
2. **Support.** Read the example as part of the move toward a duty of proportionate investigation.
3. **Prephrase.** Identify the objection the example exposes, not an unsupported universal technological claim.
4. **Why (C) is right.** Easily checked identifiers show that professed ignorance can result from negligent investigation.
5. **Why the others fail.**
    - **(A)** Overgeneralization: identifiers are examples, not guaranteed for every object.
    - **(B)** Extreme rule inconsistent with emergency retrieval endorsed later.
    - **(D)** No current uniform legal outcome is documented; the passage proposes a possible approach.
    - **(E)** Opposite of the example: identifiers and channels provide information, not intentional concealment.

**Check:** The example immediately precedes the warning about conveniently failing to investigate.
::::
:::
:::problem[Question II.5]


Which one of the following best characterizes the author’s attitude toward rewarding maritime rescue?

- **(A)** Unreserved enthusiasm for awarding any crew that brings unattended property into port.
- **(B)** Complete rejection of monetary incentives for work done on the open sea.
- **(C)** Indifference to rescuers’ uncertainty because subsequent facts always decide the case.
- **(D)** Suspicion that maritime researchers deliberately manufacture danger to collect awards.
- **(E)** Qualified support, provided that incentives do not encourage needless interference with property serving an intended purpose.

::::solution[Solution]
**Answer:** (E)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The tone balances genuine rescue incentives with restraint.
2. **Support.** The final paragraph says the proposal is not intended to eliminate incentives.
3. **Prephrase.** Choose measured support coupled with an evidential condition.
4. **Why (E) is right.** This exactly mirrors the passage’s simultaneous defense of assistance and concern about interfering with functioning sensors.
5. **Why the others fail.**
    - **(A)** Overstates the reward preference despite examples of damaging recoveries.
    - **(B)** Contradicts explicit willingness to reward genuine assistance.
    - **(C)** Misstates the focus: reasonable information available at the time matters.
    - **(D)** No claim of researchers staging hazards appears anywhere.

**Check:** The author calls for intervention justified by circumstances rather than intervention rewarded merely for happening.
::::
:::
:::problem[Question II.6]


Suppose a drifting instrument transmits a clear “operating normally” signal and presents no visible navigational hazard. A crew receives this signal, retrieves the instrument anyway, and later learns that its owner had been studying open-ocean currents. Under the author’s proposed approach, this recovery would most likely be judged...

- **(A)** justified, because the crew expended time and fuel to accomplish the recovery.
- **(B)** justified, because any freely drifting device is exposed to maritime peril by definition.
- **(C)** unjustified, because the crew ignored information showing neither emergency nor need for intervention.
- **(D)** unjustified solely because the later study revealed that its owner intended it to drift.
- **(E)** automatically justified if the crew was sincerely worried despite receiving the signal.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The answer applies the two-stage standard to advance knowledge and a defensible need.
2. **Support.** The crew knew an operating signal and no visible hazard but interfered anyway.
3. **Prephrase.** The lack of emergency and clear status should make the retrieval fail the second stage.
4. **Why (C) is right.** Known normal operation and no hazard make a salvage reward incompatible with the passage’s justification requirement.
5. **Why the others fail.**
    - **(A)** Effort alone is the very criterion the author rejects.
    - **(B)** The passage distinguishes unattended drifting from actual peril.
    - **(D)** Exclusive hindsight misstates the standard; the crew already had relevant information.
    - **(E)** Subjective worry without reasonable response to evidence is insufficient under stage one.

**Check:** Known normal function + no hazard → no defensible intervention under the proposed inquiry.
::::
:::
:::problem[Question II.7]


Which one of the following situations is most analogous to the problem motivating the author’s proposal?

- **(A)** A contractor removes an apparently abandoned weather-monitoring station without checking a visible operating indicator, then seeks payment for having “rescued” it.
- **(B)** A lifeguard immediately pulls an unconscious swimmer from rough surf.
- **(C)** An owner hires a technician to service equipment after deliberately switching it off.
- **(D)** A warehouse worker receives a bonus for recovering packages known to have been stolen.
- **(E)** A ship’s navigator updates a route after consulting a current marine forecast.

::::solution[Solution]
**Answer:** (A)

**Type:** RC analogy (Chapter 18)

1. **Conclusion.** The analogy involves apparently unattended property mistakenly treated as imperiled despite easy status clues.
2. **Support.** The central concern is incentives for interference paired with ignored available information.
3. **Prephrase.** Look for an unnecessary claimed rescue made under avoidable ignorance.
4. **Why (A) is right.** The visible operating indicator parallels instrument markings; the attempted reward parallels salvage incentive.
5. **Why the others fail.**
    - **(B)** Genuine emergency and little time to inquire is an exception the author approves.
    - **(C)** Authorized maintenance is not opportunistic recovery from perceived peril.
    - **(D)** Known theft creates a genuine recovery need, not a functioning device improperly “saved.”
    - **(E)** Careful use of information avoids, rather than exemplifies, the inquiry failure.

**Check:** Both examples require asking whether a readily available status check should precede the supposed rescue.
::::
:::
### Passage 2

A single gene can yield several forms of a protein because the cell does not always retain the same portions of the initial RNA transcript. In a process called alternative splicing, some segments are joined together while others are omitted. This flexibility has often been described as a device for expanding the repertoire of proteins available to an organism. Yet a study of coastal grasses exposed to changes in salinity suggests a less obvious role: alternative splicing may sometimes help a plant regulate the *timing* of its response rather than simply add new functions.

Researchers grew genetically similar grass seedlings in controlled chambers and moved half into saltier water. Within two hours, the salt-exposed plants produced a larger proportion of a shortened RNA transcript associated with a membrane transporter. The proportion returned toward baseline after a day even though the water remained salty. In untreated seedlings, the shortened transcript remained rare. At first the researchers proposed that the shortened transcript encoded a transporter better adapted to salt. But when they examined the corresponding protein, they found little evidence that the shortened transcript produced a stable, working transporter at all. The shortened RNA was instead rapidly degraded.

That result prompted a different hypothesis. The cell may be routing newly made RNA into an unstable form during the first hours of stress, temporarily reducing the supply of ordinary transporter protein. If so, a change in transcript proportions could act as a brake while the plant adjusts ion transport through other mechanisms. To investigate, the team developed a modified group of plants in which the splice choice was strongly biased toward the ordinary transcript. Those plants maintained higher levels of transporter protein during the first stressful hours but showed more cellular signs of salt damage than otherwise similar plants capable of switching transcripts. The result was consistent with the braking hypothesis. It did not, by itself, identify which downstream processes produced the damage; the modification might also have altered other components of RNA processing.

A second experiment complicated the story. Under mild salt exposure, plants biased toward the ordinary transcript grew slightly faster than unmodified controls. The researchers therefore resisted describing the shortened transcript as universally beneficial. A rapid decrease in transporter production might prevent harm during an abrupt, severe change while imposing an unnecessary cost during a milder disturbance. Moreover, RNA loss does not directly reveal membrane transport. Degradation, translation rates, and protein turnover all intervene between an RNA measurement and a physiological effect.

The study chiefly changes the question researchers ask. Instead of treating every stress-associated RNA variant as a candidate improved protein, investigators may need to consider whether an apparently unproductive variant regulates when the conventional protein is made. Testing that possibility requires measurements at several levels, not merely a catalog of transcripts collected after stress. The experiment offers a plausible regulatory role for an RNA form that initially looked like failed production, while leaving open the full chain connecting that form to salt tolerance.

:::problem[Question II.8]


Which one of the following best states the central idea of the passage?

- **(A)** Alternative splicing always increases the number of stable functional proteins available to plants.
- **(B)** Salt damage in coastal grasses can be completely prevented by producing more transporter protein.
- **(C)** The modified plants prove that alternative splicing is the only factor determining salt tolerance.
- **(D)** An unstable stress-associated RNA variant may help regulate the timing of protein production rather than produce a useful new protein, though the complete mechanism remains uncertain.
- **(E)** Rapidly degraded RNA variants have no biological purpose because they do not make stable proteins.

::::solution[Solution]
**Answer:** (D)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The main point proposes a plausible RNA-timing mechanism with important limitations.
2. **Support.** The passage moves from variant appearance to nonfunctional protein, to a brake hypothesis and mixed experiments.
3. **Prephrase.** Capture hypothesis, evidence, and guarded epistemic strength.
4. **Why (D) is right.** It preserves both the proposed regulatory role and the authors’ refusal to assert a completed causal chain.
5. **Why the others fail.**
    - **(A)** Old generic description is explicitly questioned by the observed unstable variant.
    - **(B)** Opposite of high-transporter severe-stress results and wrongly guarantees protection.
    - **(C)** Too strong: the study explicitly notes other RNA-processing effects and unidentified downstream mechanisms.
    - **(E)** Reversal: apparently unproductive RNA is exactly what the regulatory hypothesis highlights.

**Check:** The final paragraph emphasizes testing timing, not merely cataloging proteins, while leaving causal details open.
::::
:::
:::problem[Question II.9]


According to the passage, which one of the following was observed in salt-exposed seedlings?

- **(A)** A shortened RNA transcript became a stable transporter protein after twenty-four hours.
- **(B)** The share of a shortened RNA transcript rose early and later approached its initial proportion even while saline conditions continued.
- **(C)** The fraction of shortened RNA remained high for as long as the water remained salty.
- **(D)** The ordinary transporter protein disappeared permanently from all salt-exposed seedlings.
- **(E)** Untreated seedlings produced a large proportion of the shortened transcript within two hours.

::::solution[Solution]
**Answer:** (B)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question asks for the time course actually reported.
2. **Support.** The second paragraph specifies an early spike that returned toward baseline after a day despite continuing salt exposure.
3. **Prephrase.** Select the changing RNA proportion, not an invented long-term protein result.
4. **Why (B) is right.** The answer faithfully preserves both the initial rise and the decline during ongoing stress.
5. **Why the others fail.**
    - **(A)** Protein stability was not shown; the shortened RNA was rapidly degraded.
    - **(C)** Contradicts return toward baseline despite salty water.
    - **(D)** Permanent elimination of the normal protein is neither measured nor reported.
    - **(E)** The control seedlings kept shortened RNA rare.

**Check:** Reread paragraph two: increased within two hours; toward baseline after a day; water still salty.
::::
:::
:::problem[Question II.10]


The experiment with plants biased toward producing the ordinary transcript is discussed primarily in order to...

- **(A)** prove that ordinary transporter proteins never contribute to plant growth.
- **(B)** show that the initial observations were caused by measurement errors.
- **(C)** demonstrate that modified splicing affects no cellular processes beyond the transporter.
- **(D)** establish that all variants of the transporter have identical physiological effects.
- **(E)** provide evidence consistent with the hypothesis that suppressing ordinary transporter production temporarily may limit severe salt damage.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The modified-plant experiment is a test of the proposed temporary brake.
2. **Support.** Biased plants maintain transporter protein but suffer more signs of damage under abrupt stress.
3. **Prephrase.** Connect the intervention to the competing predictions without overclaiming mechanism.
4. **Why (E) is right.** Greater damage when the brake is impaired makes temporary reduction plausibly protective.
5. **Why the others fail.**
    - **(A)** Contradicted by later mild-salt growth and the ordinary transporter’s functional importance.
    - **(B)** No measurement error is asserted; the experiment follows a new biological interpretation.
    - **(C)** Explicitly denied: altering splice choice may change other RNA-processing machinery.
    - **(D)** Functional equivalence is neither claimed nor compatible with the shortened form’s rapid degradation.

**Check:** More normal protein during first hours + more damage aligns with a protective temporary brake.
::::
:::
:::problem[Question II.11]


The passage most strongly supports which one of the following claims about measuring RNA transcripts?

- **(A)** RNA abundance is always inversely proportional to membrane protein activity.
- **(B)** Transcript measurements are useless for developing hypotheses about cellular regulation.
- **(C)** Every RNA molecule that disappears has necessarily been translated into a protein.
- **(D)** Changes in transcript abundance alone do not establish the corresponding change in membrane transport activity.
- **(E)** The amount of a transcript is entirely unaffected by environmental stress.

::::solution[Solution]
**Answer:** (D)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The passage separates RNA levels from downstream protein and transport effects.
2. **Support.** Translation, degradation, and protein turnover lie between transcript counts and membrane function.
3. **Prephrase.** Expect a caution about one proxy, not a rejection of transcript evidence entirely.
4. **Why (D) is right.** Even a large RNA shift cannot directly establish functional transport because multiple intermediate mechanisms intervene.
5. **Why the others fail.**
    - **(A)** Invents a universal inverse relationship unmentioned in the study.
    - **(B)** Too strong: the researchers used RNA measurements to formulate a testable braking hypothesis.
    - **(C)** Reverses the decay finding: the shortened RNA was degraded without stable protein.
    - **(E)** Directly contradicts salt-associated transcript proportions.

**Check:** RNA → possible protein → membrane transport is not an identity; intermediate rates matter.
::::
:::
:::problem[Question II.12]


Suppose another grass species shows a similar unstable RNA variant under intense salt stress but not mild stress. Which one of the following results would most strongly support the passage’s proposed explanation?

- **(A)** Preventing the variant reduces transporter abundance and prevents all forms of stress damage.
- **(B)** The variant produces a stable transporter that moves ions faster during all conditions.
- **(C)** Preventing formation of the unstable variant increases early transporter abundance and worsens damage during intense stress, without improving survival during that stress.
- **(D)** The variant is common in untreated plants but absent during abrupt intense salt stress.
- **(E)** The species has a higher total number of genes than the coastal grasses in the study.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The hypothesis is that variant production temporarily reduces standard protein and helps under severe stress.
2. **Support.** The proposed brake predicts higher ordinary protein and more damage if the variant cannot form.
3. **Prephrase.** Look for the intervention-result signature corresponding to the severe-stress experiment.
4. **Why (C) is right.** Loss of the variant removes the hypothesized restraint, and worsening damage mirrors the stated mechanism.
5. **Why the others fail.**
    - **(A)** Inverts the predicted effect on normal protein and asserts impossible certainty.
    - **(B)** Supports the original improved-protein hypothesis rather than the RNA-brake hypothesis.
    - **(D)** Opposite pattern of induced variant under severe stress.
    - **(E)** Genome size does not test transcript-mediated timing control.

**Check:** Brake removed → ordinary protein stays high → severe-stress damage increases.
::::
:::
:::problem[Question II.13]


The author’s attitude toward the braking hypothesis is best described as...

- **(A)** dismissive because the shortened RNA fails to yield a stable protein.
- **(B)** cautiously favorable because several observations fit it, while alternative mechanisms remain possible.
- **(C)** certain because modification experiments exclude all other effects.
- **(D)** indifferent because no experiment was conducted to test the hypothesis.
- **(E)** hostile because the hypothesis depends on environmental salinity being constant.

::::solution[Solution]
**Answer:** (B)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The study is presented as plausible, not conclusive.
2. **Support.** Two experiments support a severity-dependent interpretation, but the authors list alternative processing effects.
3. **Prephrase.** Find restrained approval alongside explicit limits.
4. **Why (B) is right.** The passage praises the changed research question and says the full chain remains open.
5. **Why the others fail.**
    - **(A)** Misses the claim that unstable RNA can have regulatory significance.
    - **(C)** Overstates certainty contrary to the explicit confounding concern.
    - **(D)** Factually wrong: plants with biased splice choice were tested under differing salt intensities.
    - **(E)** No claim that constant salinity undermines the hypothesis; the sustained exposure highlights timing.

**Check:** “Consistent with” is not “proved by”: the passage repeatedly distinguishes supporting evidence and full explanation.
::::
:::
:::problem[Question II.14]


Which one of the following is most analogous to the role hypothesized for the shortened transcript?

- **(A)** A factory temporarily sends some production orders to a queue that automatically discards them, reducing normal output during a dangerous equipment adjustment.
- **(B)** A factory replaces an old machine with a more powerful one that increases output continuously.
- **(C)** A shipping center sorts finished products by color without changing how many it sends.
- **(D)** A workshop retains every order indefinitely so no order is ever lost.
- **(E)** A factory installs an extra production line that runs faster in periods of high demand.

::::solution[Solution]
**Answer:** (A)

**Type:** RC analogy (Chapter 18)

1. **Conclusion.** The shortened form may provide a temporary, deliberate sink for RNA destined otherwise to make standard protein.
2. **Support.** Its degradation limits ordinary protein early, rather than creating a superior new transporter.
3. **Prephrase.** Select a temporary diversion and disposal mechanism that reduces output during stress.
4. **Why (A) is right.** Discarding orders parallels unstable RNA degradation; lower output during adjustment parallels reduced transporter.
5. **Why the others fail.**
    - **(B)** Represents a better protein rather than a regulatory loss channel.
    - **(C)** Reclassification of finished products does not change production timing or amount.
    - **(D)** Opposite of rapid degradation and temporary downregulation.
    - **(E)** Adds output, while the proposed mechanism deliberately curbs it.

**Check:** Ordinary RNA diverted into degradable shortened RNA → less functional protein during the stress peak.
::::
:::
### Passage 3 (comparative)

**Passage A**

Anthropologists studying ceremonial gift exchange have sometimes treated handwritten gift ledgers as imperfect substitutes for older systems of social memory. In communities where obligations once circulated through public storytelling and repeated visits, a ledger fixes names, quantities, and dates on a page. Supporters call this precision an advantage: participants can resolve disagreements about what was given. But the written record can displace a more flexible understanding of obligation. A family may remember a modest offering as especially generous because it arrived during hardship, while the ledger records only the amount. Over time, the numerical account may come to stand for the relationship itself.

This does not mean that oral memory was free of disagreement or that ledgers always damage communal life. The point is comparative: spoken accounts could be retold for different purposes and audiences, allowing a gift's significance to develop as relationships changed. The ledger, by appearing to settle the facts, may narrow the range of interpretations considered legitimate. Researchers should therefore investigate not just what ledgers record, but which aspects of exchange become harder to discuss once the page is treated as authoritative.

**Passage B**

It is tempting to describe a gift ledger as a device that freezes a living relationship into numbers. My fieldwork with a network of coastal craft guilds suggests a different possibility. Their ledgers list contributions to shared festivals, yet members routinely annotate older entries with accounts of illness, travel, and unexpected assistance. One entry that seemed to record a small gift acquired a second note praising the donor's work during a difficult repair. The record did not end interpretation; it became a surface on which interpretation took place.

Nor did the presence of a ledger eliminate storytelling. At meetings, members disputed the meaning of entries and used those disputes to reopen conversations about continuing obligations. Nevertheless, the existence of a written record did change whose interpretations carried weight. Members who maintained the books could more easily place their explanations beside the numbers, while people without access to the books depended on others to transmit their views. Thus neither the image of a perfectly objective record nor that of a purely oppressive document captures the situation. The important question is who can amend the record, who can challenge it, and what social authority attaches to those acts. A ledger can constrain interpretation, but its material permanence can also preserve disagreements that might otherwise be forgotten. Some members preserve photocopies of disputed entries so that even an eventual revision does not erase evidence of earlier disagreements.

The fieldwork thus shows that communities can use the same durable object to renegotiate context, not merely to preserve a numerical account. We should resist assuming that the effect of writing follows inevitably from writing's technical properties alone. How a ledger is governed may matter as much as what it can record.

:::problem[Question II.15]


Which one of the following best describes the relationship between the main claims of Passages A and B?

- **(A)** Passage A treats oral retellings as the only reliable basis for understanding gifts, whereas Passage B argues that oral retellings have little social value.
- **(B)** Passage A stresses how numerical precision can limit acceptable accounts, while Passage B holds that written figures can never influence the authority of accounts.
- **(C)** Passage A concentrates on who may annotate ledgers, while Passage B concentrates exclusively on whether entries report amounts correctly.
- **(D)** Both passages argue that once ledgers are introduced, oral narratives inevitably cease to affect gift obligations.
- **(E)** Passage A warns that written records can narrow interpretations of social obligations, while Passage B emphasizes that records can also become sites where those interpretations are revised.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative main point (Chapter 17)

1. **Conclusion.** A emphasizes loss of interpretive flexibility; B emphasizes active annotation and unequal access.
2. **Support.** Both reject a purely objective account, but stress different directions for the effects of written records.
3. **Prephrase.** Map A’s warning and B’s qualification before comparing.
4. **Why (E) is right.** The answer captures the contrast without pretending that either author holds an absolute position.
5. **Why the others fail.**
    - **(A)** False dilemma about media: A does not dismiss written records completely, and B reports continued storytelling as important.
    - **(B)** Half-right first clause; B explicitly says control of written records affects whose interpretations have authority.
    - **(C)** Reversed emphasis: annotation control is a special concern of B, while A develops the broader oral-versus-written contrast.
    - **(D)** Shared-extreme trap: A allows oral disputes and B explicitly describes ongoing storytelling.

**Check:** A: precision can crowd out context. B: permanence can support continued reinterpretation, depending on access.
::::
:::
:::problem[Question II.16]


The authors of both passages would most likely agree with which one of the following statements?

- **(A)** The adoption of a gift ledger usually ends face-to-face disputes about the meaning of a contribution.
- **(B)** Written records of gifts can affect whose interpretation of an exchange is treated as authoritative.
- **(C)** The numerical amount recorded for a gift ordinarily captures all the circumstances that made it socially significant.
- **(D)** The same gift will necessarily be understood in the same way by every member who consults the ledger.
- **(E)** Any inequality in access to the ledger can be corrected merely by preserving the original entries permanently.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative agreement (Chapter 17)

1. **Conclusion.** Each author ties written records to the social authority of interpretations.
2. **Support.** A worries a ledger appears to settle facts and narrow legitimate readings; B notes bookkeepers’ privileged ability to annotate.
3. **Prephrase.** Use the both-must-have-a-stake filter: find an effect explicitly treated in both texts.
4. **Why (B) is right.** Both describe ways ledgers can shape whose account carries weight, even while differing on whether meaning can be revised.
5. **Why the others fail.**
    - **(A)** Overstates the role of writing: B describes disputes at meetings; A also denies that ledgers always eliminate disagreement.
    - **(C)** Both criticize the loss of contextual information when meaning is reduced to an entry.
    - **(D)** Agreement is not guaranteed: each passage addresses contested meanings and unequal interpretive authority.
    - **(E)** Unsupported universal remedy: B distinguishes permanence from control of amendments; A does not claim preservation equalizes authority.

**Check:** A: ledger authority can narrow interpretations. B: access to ledger affects authority. Shared concern is power over interpretation.
::::
:::
:::problem[Question II.17]


Which one of the following best explains how Passage B qualifies the concern raised in Passage A?

- **(A)** It denies that the authority attached to numerical entries can affect the meaning of exchanges.
- **(B)** It finds that oral accounts of gifts were never used once guild members began keeping ledgers.
- **(C)** It describes cases in which people use the written ledger itself to preserve reinterpretations, while acknowledging that control over the ledger can still restrict whose interpretations count.
- **(D)** It argues that the ledger’s first entry is more authoritative than all later annotations because it records the quantity of the original gift.
- **(E)** It proposes abandoning ledgers in favor of exclusively oral records to restore interpretive flexibility.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** B responds to the worry about written fixity by presenting evidence of revision *within* the ledger.
2. **Support.** A warns that a numerical entry can crowd out context; B documents annotations while also noting unequal editing access.
3. **Prephrase.** Find a qualified counterexample, not the claim that A’s concerns are impossible.
4. **Why (C) is right.** The annotations supply a mechanism for renewed interpretation, and unequal control sustains the concern about authority.
5. **Why the others fail.**
    - **(A)** B instead agrees that ledger access can affect interpretive authority; it only questions whether records necessarily stop revision.
    - **(B)** B observes continued spoken disputes at meetings, contrary to this description.
    - **(D)** B highlights later notes and their capacity to reshape meaning, not a permanently superior initial amount.
    - **(E)** B’s guilds continue using ledgers actively, so elimination would miss the qualifying counterexample.

**Check:** B adds a possibility to A’s concern: durable record + annotations → preserved dispute, though access remains unequal.
::::
:::
:::problem[Question II.18]


Which one of the following claims would the author of Passage B most likely accept but the author of Passage A would not be committed to accepting?

- **(A)** The opportunity to annotate a ledger ensures that everyone who contributed to it receives an equal voice.
- **(B)** Oral accounts preserve all relevant context of an exchange, while written accounts preserve none.
- **(C)** Once a written entry has been annotated, its original numerical amount no longer matters to the community.
- **(D)** Making room for comments alongside ledger entries can preserve challenges to the first numerical account.
- **(E)** The capacity to amend a ledger prevents disputes about gifts from arising later.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative inference (Chapter 17)

1. **Conclusion.** B’s fieldwork stresses that annotations can preserve dissent, while A focuses on interpretive narrowing.
2. **Support.** B provides concrete modified entries; A does not discuss annotation as a countermeasure.
3. **Prephrase.** Find a B-supported possibility not contradicted or required by A.
4. **Why (D) is right.** B explicitly states material permanence can preserve disagreements; A’s warning does not establish this consequence.
5. **Why the others fail.**
    - **(A)** Overstates B’s finding: bookkeepers enjoy a greater chance to inscribe interpretations, so annotation does not guarantee equality.
    - **(B)** Too absolute: B documents written notes about illness and labor; A does not claim oral memory is perfect.
    - **(C)** Neither author dismisses numbers once contextual notes are added; B depicts coexistence of numeric records and stories.
    - **(E)** Opposite result: B says annotations can preserve and reopen disputes, not abolish them.

**Check:** Locate B’s statement that permanence can preserve disputes otherwise forgotten.
::::
:::
:::problem[Question II.19]


In a village, anyone may read a public gift ledger, but only two elders may add explanatory notes. Which author’s concerns would most directly prompt investigation of this policy?

- **(A)** Both authors, because Passage A asks which interpretations become authoritative and Passage B asks who can amend the record.
- **(B)** Only Passage A, because whether entries are authoritative depends solely on whether most residents can read the ledger.
- **(C)** Only Passage B, because Passage A discusses flexibility of oral interpretation but takes no position on how written authority affects legitimate accounts.
- **(D)** Neither passage, because universal permission to read ensures that the authority to add explanations cannot be concentrated.
- **(E)** Only Passage A, because Passage B treats bookkeepers’ exclusive control over additions as an unqualified benefit.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative application (Chapter 17)

1. **Conclusion.** Both passages make authority over a written account a central issue.
2. **Support.** A asks what becomes harder to discuss when the page is authoritative; B asks who can revise it.
3. **Prephrase.** Notice that open reading access does not entail equal control over annotations.
4. **Why (A) is right.** A would scrutinize the narrowed legitimate story; B would scrutinize exclusive power to inscribe comments.
5. **Why the others fail.**
    - **(B)** “Solely” misstates A, and B specifically addresses who may amend as distinct from who may read.
    - **(C)** A expressly worries that the ledger narrows which interpretations count as legitimate, so it has a stake too.
    - **(D)** Mistakes reading access for editing authority; B specifically separates those powers.
    - **(E)** B warns that unequal control can privilege the bookkeepers, so it would investigate the rule.

**Check:** An elders-only amendment rule plausibly confers authority on two interpreters even if everyone can read.
::::
:::
:::problem[Question II.20]


Which one of the following best describes a difference in the way the two authors develop their positions?

- **(A)** Passage A develops its claim through an extended community case study, whereas Passage B offers only a hypothetical comparison.
- **(B)** Passage A explains an observed practice in a single guild, while Passage B proposes general rules for correcting ledger entries.
- **(C)** Passage A argues mainly from the authority of earlier anthropologists, while Passage B tests the claim with a controlled experiment.
- **(D)** Passage A derives a conclusion about all societies, whereas Passage B argues that all written records preserve disagreement.
- **(E)** Passage A emphasizes a conceptual comparison between oral and written interpretation; Passage B relies on observations from a particular guild network to qualify a generalization.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** A develops a risk through contrast; B develops a qualification through fieldwork.
2. **Support.** A compares the flexibility of oral stories with apparent fixity; B describes annotated ledger entries and meeting disputes.
3. **Prephrase.** Match the rhetorical methods, not invented datasets.
4. **Why (E) is right.** The answer names the textual evidence difference without caricaturing A as absolutely anti-writing.
5. **Why the others fail.**
    - **(A)** Evidence-type reversal: B gives guild fieldwork and specific annotations; A supplies a conceptual warning and illustrative possibilities.
    - **(B)** Misattributes the fieldwork to A and exaggerates B into issuing universal amendment rules.
    - **(C)** Neither scholarly authority nor a controlled experiment drives the argument; B uses field observations.
    - **(D)** Double quantifier inflation: A says ledgers may narrow meaning; B says they can preserve disagreement, not that they always do.

**Check:** A: comparative conceptual argument. B: ethnographic counterexample and qualification.
::::
:::
### Passage 4

Music histories frequently describe the growing precision of written scores as a straightforward advance from the uncertainties of performance tradition toward a composer's exact intentions. On that view, eighteenth-century chamber ensembles played relatively loosely because notation left details unspecified, whereas later performers possessed clearer directions. But a set of surviving teaching notebooks from a busy trading port suggests a more complicated relationship between the page and the performance. The notebooks include short musical examples, corrections of student ornaments, and marginal comments about the character of particular dance movements. They offer evidence not that notation failed, but that notation and trained improvisation were expected to work together.

Consider a repeated melodic phrase in one notebook. The first appearance is written without embellishment; the second carries a small ornament supplied by a teacher. A margin note does not order the student to reproduce that ornament exactly. Instead, it warns against placing a rapid decorative figure where it would obscure the entry of a second instrument. Another notebook shows the reverse problem: students are asked to add variety to a repeated phrase, because mechanical repetition would make the music sound lifeless. What matters in both cases is the performer's judgment about texture and timing. The notated page records material for that judgment, not necessarily its final product.

A difficulty arises when modern editions silently incorporate one historical ornament into the printed melody. Such an edition can make a choice once treated as contingent appear to be a fixed part of the work. Conversely, a modern edition that removes all ornaments may give an equally misleading impression of unadorned simplicity. The notebooks suggest that historical fidelity cannot be reduced to following the largest possible number of markings. The performer must recognize which marks function as rules, which as demonstrations, and which as reminders of a broader practice. This is not a license to invent whatever sounds attractive; the notebooks repeatedly criticize decorations that disturb a phrase's balance or conflict with another part.

Some scholars object that instructional notebooks reflect what teachers wanted students to do, not necessarily what professional musicians actually did in concerts. The objection is important, for classroom ideals and public performances may diverge. Yet it does not erase the notebooks' value. Even if students routinely violated their teachers' advice, the advice shows that a musician could be judged for choosing among possible embellishments, rather than merely for copying every note on the page. Concert programs, private letters, and surviving instrumental parts would help establish how widely these expectations were shared beyond the classroom.

The stronger historical claim, then, is not that eighteenth-century performers were freer than all modern performers, nor that every composition required improvisation. It is that increasingly detailed written materials could coexist with expectations of active, disciplined choice. A history that treats notation and invention as opponents will miss this partnership and may mistake the surviving score for a complete record of what a musical work was understood to require.

:::problem[Question II.21]


Which one of the following best expresses the main point of the passage?

- **(A)** Teachers’ notes show that notation was so imprecise that it could not impose useful limits on performers.
- **(B)** Historical musical notation sometimes worked together with disciplined performer choice, so a surviving score should not automatically be treated as an exhaustive record of intended performance.
- **(C)** Modern editors should print every historically documented ornament inside the melody to make performers’ choices authentic.
- **(D)** Teaching notebooks establish how professional musicians in the port actually embellished their concert pieces.
- **(E)** The growth of detailed notation eventually removed the need for musicians to exercise judgment during performances.

::::solution[Solution]
**Answer:** (B)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author argues against treating notation and invention as adversaries.
2. **Support.** Notebook examples show guided choices; editorial dilemmas and evidentiary limitations support a nuanced conclusion.
3. **Prephrase.** Choose the partnership claim, not either extreme of copying versus unlimited freedom.
4. **Why (B) is right.** The final paragraph explicitly says detailed writing can coexist with active, disciplined choice.
5. **Why the others fail.**
    - **(A)** Overcorrection: the notes include constraints on ornament placement, so notation was not useless as guidance.
    - **(C)** Reverses the warning that a contingent example can falsely become obligatory in the printed score.
    - **(D)** The fourth paragraph explicitly says classroom prescriptions may not describe concerts.
    - **(E)** This is the simple opposition that the passage challenges, not its conclusion.

**Check:** Final paragraph: surviving score ≠ necessarily complete requirements; notation and invention can cooperate.
::::
:::
:::problem[Question II.22]


According to the passage, a notebook teacher warned against an ornament primarily because it might...

- **(A)** extend a repeated phrase so far that it no longer matched the dance movement’s expected timing.
- **(B)** draw attention away from the melody and toward the bass part playing underneath it.
- **(C)** obscure the entrance of another instrumental part.
- **(D)** contradict a general rule against varying a melody when it is repeated.
- **(E)** demand a degree of manual skill greater than the student had demonstrated.

::::solution[Solution]
**Answer:** (C)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The second paragraph states a specific musical-texture objection.
2. **Support.** The teacher warns about a rapid figure where the second instrument enters.
3. **Prephrase.** Retrieve the immediate context rather than inferring generic dislike of embellishment.
4. **Why (C) is right.** The answer restates that the decoration could hide another player’s entry.
5. **Why the others fail.**
    - **(A)** Related musical concern but not the teacher’s cited objection, which was obscuring a second instrument’s entry.
    - **(B)** Nearby-texture trap: the actual warning concerns an ornament hiding an *entry*, not shifting focus to the bass.
    - **(D)** Reversal: the same notebook tradition also urged variation in a repeated phrase.
    - **(E)** Plausible classroom difficulty but the given margin note addresses ensemble balance, not the student’s ability.

**Check:** Find the warning about obscuring the second instrument’s entry in paragraph two.
::::
:::
:::problem[Question II.23]


The discussion of modern editors incorporating a single historical ornament into a score serves primarily to...

- **(A)** show that an ornament in a teacher’s notebook is necessarily closer to a composer’s intention than one supplied by a modern editor.
- **(B)** argue that historical editions should include more ornaments than manuscripts to recreate a lively sound.
- **(C)** suggest that an ornament becomes a fixed requirement when multiple performers happened to choose it in the past.
- **(D)** illustrate how an editorial choice can turn what was once optional into something that appears mandatory.
- **(E)** show that publishers inevitably change a work whenever they put any musical material on the page.

::::solution[Solution]
**Answer:** (D)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The author shows a danger in reading printed notation as exhaustive and binding.
2. **Support.** The third paragraph contrasts fixing one ornament with omitting all ornaments.
3. **Prephrase.** Identify the risk of confusing example or choice with immutable instruction.
4. **Why (D) is right.** A contingent performance suggestion becomes printed melody, misleading readers about its status.
5. **Why the others fail.**
    - **(A)** Authority trap: the author treats notebook ornaments as contingent examples, not guaranteed composer instructions.
    - **(B)** Invented prescription: adding more decoration does not solve the confusion about what was optional.
    - **(C)** No evidence of frequency is offered; the problematic fixation occurs because of an editor’s unmarked decision.
    - **(E)** Overbroad claim: the author criticizes a particular editorial transformation, not the possibility of accurate publication.

**Check:** Fixed historical ornament → printed obligation is the precise shift the paragraph warns against.
::::
:::
:::problem[Question II.24]


Which one of the following can most reasonably be inferred from the passage?

- **(A)** The notebooks support conclusions about instructional expectations even if they do not by themselves settle what professionals did in concerts.
- **(B)** Teachers’ instructions probably describe concert practices exactly whenever they survive in written form.
- **(C)** Because students may have ignored teachers, the notebooks contain no evidence of what musical standards existed.
- **(D)** The author treats concert programs as less useful than marginal notes for knowing what performances sounded like.
- **(E)** Historical fidelity requires preserving every ornament exactly as it first appeared in a notebook.

::::solution[Solution]
**Answer:** (A)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author distinguishes the norms the books express from the performance behavior they might not document.
2. **Support.** Paragraph four grants the objection that teaching ideals may differ from concerts yet retains their value as norms.
3. **Prephrase.** Preserve the evidence boundary rather than jumping from classroom notes to universal concert behavior.
4. **Why (A) is right.** The notebooks show students were evaluated for choices, though additional sources are needed to know prevalence outside lessons.
5. **Why the others fail.**
    - **(B)** The passage explicitly cautions that pedagogical ideals and professional practice may differ.
    - **(C)** Reverses the author’s reply: the advice still shows the standards by which choices were judged.
    - **(D)** Unsupported ranking: additional concert programs and parts are proposed as complementary checks.
    - **(E)** Mistakes a teaching illustration for a binding performance instruction.

**Check:** The passage says even if students disobeyed, the advice still shows a norm of judged choice.
::::
:::
:::problem[Question II.25]


The author’s attitude toward a historically faithful performance is best described as...

- **(A)** supportive of improvisation as long as it makes a performance more appealing to a modern audience.
- **(B)** insistent on informed choices within historical constraints rather than mere maximization of printed detail.
- **(C)** convinced that a fully annotated edition can remove the need for performers to make any contextual decisions.
- **(D)** doubtful that teaching notebooks are relevant because actual concerts sometimes differed from lessons.
- **(E)** committed to recreating the sound of the port’s classrooms as accurately as possible, regardless of differences from public concerts.

::::solution[Solution]
**Answer:** (B)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The tone is supportive of historically informed judgment, not unbounded invention.
2. **Support.** Paragraph three criticizes both the fixation and the wholesale deletion of ornaments.
3. **Prephrase.** Choose qualified interpretation of rule, example, and practice.
4. **Why (B) is right.** The answer matches “active, disciplined choice” and the limits from balance and other instrumental lines.
5. **Why the others fail.**
    - **(A)** Wrong standard: the author emphasizes historical texture and balance, not modern taste as the overriding test.
    - **(C)** This is the complete-score view rejected by the notebooks’ examples of discretionary choice.
    - **(D)** Misreads a concession: uncertainty about concert behavior does not negate the evidence for a norm.
    - **(E)** Narrow-scope trap: the author does not equate classroom demonstrations with all historical performances.

**Check:** Faithfulness requires discerning which marks are rules and which are demonstrations or reminders.
::::
:::
:::problem[Question II.26]


Which one of the following editorial practices would be most consistent with the author’s recommendations?

- **(A)** Add historically attested ornaments to the main melody but omit whether the manuscript treated them as suggestions or commands.
- **(B)** Exclude ornaments from the printed text and describe them as inventions of modern performers rather than historical practices.
- **(C)** Print the most ornamented example as a required model but allow performers to change its tempo.
- **(D)** Ask the editor to select one ornament for every repeated phrase so that performances are consistently historically accurate.
- **(E)** Print the basic melodic line while separately marking documented ornament options and explaining that their use depended on musical context.

::::solution[Solution]
**Answer:** (E)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The author calls for preserving the distinction between written material and discretionary choices.
2. **Support.** Both hard-coding and suppressing historical ornament evidence can distort earlier practices.
3. **Prephrase.** Find an edition that communicates optionality alongside constraints.
4. **Why (E) is right.** Separating examples from fixed text preserves source evidence while encouraging informed contextual decisions.
5. **Why the others fail.**
    - **(A)** Conflates evidence with obligation, the editorial mistake the author expressly warns against.
    - **(B)** Falsely erases evidence that teachers explicitly demonstrated or requested embellishment.
    - **(C)** Flexibility in tempo does not fix making a contingent decoration compulsory.
    - **(D)** Single-choice rule ignores the context-sensitive judgments about texture and phrase balance.

**Check:** Basic text + marked options + context distinguishes a rule from an example.
::::
:::
:::problem[Question II.27]


The primary purpose of the passage is to...

- **(A)** trace the movement of chamber music from improvised folk traditions to fully fixed written compositions.
- **(B)** evaluate several competing modern editions and rank them by how many authentic ornaments they contain.
- **(C)** challenge a simple opposition between notation and improvisation by interpreting a type of historical evidence and acknowledging its limitations.
- **(D)** show that an eighteenth-century teacher’s advice about ornamentation can be applied without alteration to every contemporary performance.
- **(E)** argue that professional players must have ignored their teachers because concert practice differed from classroom expectations.

::::solution[Solution]
**Answer:** (C)

**Type:** RC primary purpose (Chapter 18)

1. **Conclusion.** The author reinterprets the evidence of notebooks to question a standard narrative.
2. **Support.** Notebook lessons, editorial caveats, and doubts about classroom-to-concert generalization build the case.
3. **Prephrase.** Choose the correct purpose verb, subject, scope, and degree.
4. **Why (C) is right.** “Challenge” plus “interpret evidence with limits” captures the full passage from initial conventional narrative to final qualification.
5. **Why the others fail.**
    - **(A)** The author disputes a one-way replacement story rather than documenting a complete chronological transition.
    - **(B)** A specific editorial problem is illustrative, not a comparative survey or ranking of editions.
    - **(D)** Exaggerates a classroom example into a universal performance rule, whereas the author insists on context and evidence limits.
    - **(E)** Confuses possible divergence with demonstrated disobedience; the author asks for more evidence.

**Check:** Paragraph one poses the notation/improvisation issue; paragraph five resolves it as coexistence with limits.
::::
:::
## 30.3 Section III: Logical Reasoning

:::problem[Question III.1]
A county released an app through which residents can report potholes. In the first month, three quarters of all reports came from the eastern district, though only one third of county residents live there. The public works director concludes that three quarters of the county’s potholes are located in the eastern district and proposes allocating repair crews accordingly. But the app was first advertised at a technology fair in the east, and older phone models used by many western residents cannot run it. The director notes that every report included a location verified by the app.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that app reports with verified coordinates must each describe a pothole severe enough to require immediate repair.
- **(B)** treats a high number of complaints from one district as proving that its residents drive on longer routes.
- **(C)** confuses where app users report potholes with the distribution of all potholes in a county whose residents have unequal access to the reporting method.
- **(D)** assumes that technological barriers to reporting affect all districts by exactly the same amount.
- **(E)** confuses accurately verified locations of submitted reports with evidence that residents in other districts never encounter potholes.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director infers a countywide pothole distribution from one app’s report distribution.
2. **Support.** App promotion and device compatibility make the sample uneven, even if reported locations are accurate.
3. **Prephrase.** Watch for selection and coverage bias, not errors within each submitted report.
4. **Why (C) is right.** Accurate coordinates for people who report do not make missing western reports appear; unreported potholes may be common there.
5. **Why the others fail.**
    - **(A)** Severity is not the inference being made; the unsupported move is from reports to geographic distribution.
    - **(B)** Wrong target: the director claims more potholes are located in the district, not that residents travel farther.
    - **(D)** The director does not explicitly assume equal barriers; the error is failing to account for the described unequal barriers.
    - **(E)** This exaggerates the inference into an “never” claim the director does not make; the actual conclusion is a three-quarter share.

**Check:** Imagine equal real potholes in east and west but fewer compatible phones west; most reports can still come from east.
::::
:::
:::problem[Question III.2]
A research clinic uses the following storage protocol. Every tissue sample retained for genetic analysis is given a coded label. Every coded sample is logged in the digital registry. No sample collected after noon is stored overnight without refrigeration. A set of samples was collected after noon on Tuesday and retained for genetic analysis. Some members of that set were stored overnight, but the protocol does not identify which ones were refrigerated because the temperature log is kept separately. Unlabeled samples from unrelated studies may also be present in the building.

Which one of the following must be true?

- **(A)** Every registry entry corresponds to a sample that was retained for genetic analysis.
- **(B)** Some samples collected after noon on Tuesday were stored overnight without refrigeration.
- **(C)** No sample collected before noon was refrigerated that night.
- **(D)** Every sample in the specified Tuesday set was entered in the digital registry.
- **(E)** Every sample in the research clinic has a coded label.

::::solution[Solution]
**Answer:** (D)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** The inference follows from the genetic-analysis classification of the Tuesday set.
2. **Support.** Retained for genetic analysis → coded → logged; all samples in the set satisfy the first condition.
3. **Prephrase.** Chain the mandatory rules, preserving their direction.
4. **Why (D) is right.** Each specified sample must be coded and therefore must appear in the digital registry.
5. **Why the others fail.**
    - **(A)** Converse: logged samples can include material not retained for genetic analysis.
    - **(B)** Contradicts the storage protocol: post-noon overnight storage requires refrigeration.
    - **(C)** The rule says nothing about morning samples’ storage temperature.
    - **(E)** Overgeneralization to unrelated samples, some of which are expressly unlabeled.

**Check:** Tuesday retained → coded → logged; no claim about unclassified samples follows.
::::
:::
:::problem[Question III.3]
An architecture team claims that installing removable fabric shades in a concrete school courtyard will reduce students’ heat exposure at lunch. On two sunny trial days, the team measured lower air temperatures directly under a temporary shade than at an unshaded weather station near the parking lot. The principal questions the comparison because the station is beside vehicle exhaust and its ground surface differs from the courtyard. The architects agree that heat exposure depends on more than air temperature, including radiant heat from surrounding surfaces and the time students spend outdoors.

Which one of the following, if true, most strengthens the architects’ claim?

- **(A)** In the same courtyard at the same time, instruments registering combined radiant and air heat exposure recorded substantially lower values beneath the shade than at nearby unshaded lunch tables.
- **(B)** Students said the fabric shade was more attractive than the school’s existing awnings.
- **(C)** The weather station recorded higher temperatures on both trial days than in most other parts of the district.
- **(D)** The fabric is lightweight and can be stored indoors when storms are forecast.
- **(E)** Nearby schools have courtyards of different shapes and sizes.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The architects say shades reduce actual heat exposure for students in the courtyard.
2. **Support.** The original comparison differed in location and captured only air temperature.
3. **Prephrase.** Control location and time, and measure the total heat exposure in the relevant student environment.
4. **Why (A) is right.** The matched courtyard measurement addresses the principal’s confounder and includes radiant heat.
5. **Why the others fail.**
    - **(B)** Aesthetic preference does not demonstrate reduced heat exposure.
    - **(C)** A hot parking-lot station makes the original comparison more suspect, not more probative.
    - **(D)** Storage convenience speaks to practicality, not thermal performance at lunch.
    - **(E)** Different school designs provide no matched test of shading at this courtyard.

**Check:** Same place and time; shade versus no shade; combined heat lower: the treatment’s predicted effect is isolated.
::::
:::
:::problem[Question III.4]
A reporter has received a digital audio file purporting to capture a mayor directing staff to ignore a building inspection. The reporter compared the speaker’s voice with public recordings and found them similar. A transcription service produced a clear transcript, and the editor concludes that the conversation can be reported as an authentic recording of the mayor. The reporter admits that the original file’s source is unknown and that high-quality synthetic voices can resemble real ones. The editor responds that the transcript’s clarity removes any remaining doubt.

Which one of the following is an assumption on which the editor’s conclusion depends?

- **(A)** The transcribed conversation would violate at least one criminal law if genuine.
- **(B)** The mayor has never before discussed building inspections with staff.
- **(C)** Every clear audio recording is automatically admissible as evidence in court.
- **(D)** The transcript contains no punctuation or capitalization errors.
- **(E)** The recording was not generated or materially altered in a way that falsely attributes the instructions to the mayor.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The editor concludes an audio file genuinely records the mayor speaking.
2. **Support.** Voice resemblance and an intelligible transcript do not establish provenance; sophisticated imitation is possible.
3. **Prephrase.** Find what the claim of authenticity cannot withstand being false.
4. **Why (E) is right.** If the instructions were falsely synthesized or altered, clarity cannot make the recording authentic.
5. **Why the others fail.**
    - **(A)** Legal consequences of a real conversation do not settle whether this audio is genuine.
    - **(B)** Too strong and unnecessary: earlier discussions are irrelevant to this particular file’s authenticity.
    - **(C)** Confuses journalistic authenticity with courtroom admissibility and asserts an unsupported universal.
    - **(D)** Typography could contain minor errors even if the underlying recording were entirely genuine.

**Check:** Negate genuine attribution: a deepfake may transcribe perfectly but still not be a mayoral conversation.
::::
:::
:::problem[Question III.5]
A city plans to install dozens of new bus shelters, arguing that its transit network needs visible improvement. A transportation advocate agrees that some stops lack shelter, but points out that one third of existing shelters have broken roofs or seating. Maintenance crews can repair those shelters more quickly than contractors can install new ones, and riders at damaged shelters already bear avoidable exposure to bad weather. The advocate therefore argues that the city should repair the existing shelters before beginning a large expansion. This would not rule out additional shelters later, once the worst defects have been addressed.

Which one of the following expresses the main conclusion of the advocate’s argument?

- **(A)** Some existing bus shelters have damaged roofs or seating.
- **(B)** The city should prioritize repairs to damaged existing bus shelters before undertaking a major installation program.
- **(C)** Repair crews can complete maintenance work faster than contractors install new shelters.
- **(D)** Adding any new shelters in the future would be a misuse of public funds.
- **(E)** Weather exposure affects riders at already damaged shelters.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The advocate’s conclusion is a sequencing recommendation: repair before expansion.
2. **Support.** Current disrepair, fast repairs, and avoidable exposure support prioritizing maintenance.
3. **Prephrase.** Look for the recommendation that the other sentences serve.
4. **Why (B) is right.** The answer preserves the sequence and explicitly avoids opposing eventual expansion.
5. **Why the others fail.**
    - **(A)** Reported condition is evidence for the sequence, not the sequence itself.
    - **(C)** Speed is a supporting comparison, not the proposed policy.
    - **(D)** Too extreme: the advocate explicitly allows new shelters later.
    - **(E)** Harm to current riders is motivation for the conclusion, not the recommendation.

**Check:** The word “therefore” introduces the policy conclusion; the final sentence qualifies it.
::::
:::
:::problem[Question III.6]
A paleontology team found that one extinct mammal species had more scratches on its molars than a related species from a nearby site. The team concludes that the first species primarily ate tough grasses while the second chiefly consumed soft leaves. The tooth samples were collected from deposits of different ages, and the scratchier teeth came from a layer containing more windblown grit. The researchers argue that scratches directly reflect the food chewed and so provide sufficient evidence of different diets. Both collections were cleaned using the same laboratory procedure.

Which one of the following, if true, most weakens the researchers’ diet conclusion?

- **(A)** The species lived during different geological periods.
- **(B)** Some living mammals eat a combination of grasses and leaves.
- **(C)** The species with more scratches also had larger molars on average.
- **(D)** The laboratory procedure removed loose sediment from both fossil collections.
- **(E)** Experiments with comparable tooth surfaces show that airborne grit trapped in food can produce the same scratch patterns regardless of whether the food is leaves or grasses.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The researchers infer different primary diets from different wear patterns.
2. **Support.** One deposit had more windblown grit, a possible non-diet source of scratches.
3. **Prephrase.** Show a scratch-producing pathway independent of dietary plant type.
4. **Why (E) is right.** Grit contamination can produce the relevant wear whether the animal eats either proposed food.
5. **Why the others fail.**
    - **(A)** Different ages are already known and do not alone show that scratches fail to indicate diet.
    - **(B)** Mixed diets in other mammals does not directly address these fossils’ scratch origin.
    - **(C)** Size difference might affect use but provides no documented alternative cause of specific scratches.
    - **(D)** Cleaning after excavation cannot erase scratches formed during the animal’s life.

**Check:** If grit → scratches under both diets, scratchiness does not isolate the grass-versus-leaf distinction.
::::
:::
:::problem[Question III.7]
A public clinic posts notices of free blood-pressure screenings only in the language most commonly spoken in its district. Administrators say translating them would require modest additional expense and argue that the notices satisfy the legal minimum. Community health volunteers explain that a substantial minority of local residents cannot understand that language. Screening appointments remain underused, and the clinic hopes to improve participation without changing the medical service itself. The issue is not whether notices are legally valid but whether the clinic’s communication decision is defensible as public service.

Which one of the following principles most strongly supports translating the notices?

- **(A)** A public clinic should offer a service only after every resident has promised to use it.
- **(B)** Government messages should always use the single most common local language to avoid confusing readers.
- **(C)** A public service should communicate essential access information in forms reasonably understandable to the populations it is intended to serve, when doing so is practicable.
- **(D)** If a communication decision satisfies a legal minimum, no further public-service obligation can exist.
- **(E)** Any service with unused appointments should be eliminated rather than advertised differently.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Translation would improve access for intended beneficiaries who otherwise cannot understand the announcement.
2. **Support.** The clinic serves a linguistically diverse population, translation is feasible, and publicity is a barrier.
3. **Prephrase.** Choose a rule centered on practical, equitable intelligibility, without requiring universal coverage.
4. **Why (C) is right.** The principle directly connects feasible translation to public-service access rather than legal compliance alone.
5. **Why the others fail.**
    - **(A)** Universal promises are not needed for providing information about an available service.
    - **(B)** Opposes the point that a sizable minority cannot understand that one language.
    - **(D)** Wrong criterion: the stem distinguishes ethical service quality from the legal floor.
    - **(E)** Destroys a potentially useful service instead of addressing a known communication barrier.

**Check:** Intended public includes residents unable to read the present notice + feasible translation → communicate accessibly.
::::
:::
:::problem[Question III.8]
A regional expressway offered a discounted unlimited-use commuter pass. In the first four months, the number of individual toll transactions recorded by electronic sensors fell 30 percent, yet expressway toll revenue rose 8 percent. Traffic counters showed that the actual number of vehicles using the road changed very little. The agency neither increased the price of ordinary single-use tolls nor began charging for new roads. An analyst suggests that the discrepancy results from changes in when payment is recorded and what the sensors classify as a toll transaction.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The expressway spent less money processing the transactions that appeared in its electronic records.
- **(B)** Commuter-pass purchases were recorded as revenue when sold, but passholders’ later trips did not generate individual paid-toll transactions.
- **(C)** Passholders tended to enter the expressway at less crowded entrances than other drivers.
- **(D)** Regular toll users traveled shorter distances per trip during the four-month period.
- **(E)** Some drivers who purchased passes reported making more trips than before.

::::solution[Solution]
**Answer:** (B)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** Revenue grew while counted paid transactions fell and vehicle volume was stable.
2. **Support.** Pass sales could generate substantial up-front revenue but remove many subsequent trip transactions.
3. **Prephrase.** Find an accounting and classification distinction between purchases and journey counts.
4. **Why (B) is right.** Prepaid revenue increases even when journeys by passholders vanish from the sensor’s tally of paid single-use transactions.
5. **Why the others fail.**
    - **(A)** Net-income shell game: administrative savings do not directly raise toll revenue.
    - **(C)** Traffic distribution does not by itself change recorded paid transactions or revenue.
    - **(D)** Trip distance cannot reconcile the figures without a distance-based price, which is not stated.
    - **(E)** Additional trips alone cannot explain the fall in paid transactions unless pass trips are recorded differently; the key mechanism is missing.

**Check:** Pass purchase = revenue once; subsequent trips = traffic but no paid transaction; both observations fit.
::::
:::
:::problem[Question III.9]
A school district surveyed students about a revised lunch menu by sending a web link through the school’s athletics clubs. Of students who responded, 82 percent rated the menu favorably. The food services director concludes that most students across the district prefer the new menu and cancels plans for any further trial. Several schools have no athletics clubs, and students who eat off campus rarely attend the club meetings where the link was promoted. The director notes that the survey included students from all four grade levels.

The argument is most vulnerable to criticism because it...

- **(A)** assumes that a survey distributed mainly through athletics clubs adequately represents district students who differ in club participation and meal habits.
- **(B)** confuses favorable ratings of the revised menu with proof that students actually purchased its lunches more frequently.
- **(C)** assumes that the favorable rating would remain at 82 percent if the menu were changed again next year.
- **(D)** fails to establish whether the menu was more popular with ninth graders than with twelfth graders.
- **(E)** infers from the survey response that no student opposed the revised menu.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director infers districtwide majority preference from a convenience sample.
2. **Support.** The sampling channel excludes or underreaches non-club participants and off-campus eaters.
3. **Prephrase.** Look for an unrepresentative sample despite broad coverage of grades.
4. **Why (A) is right.** Grade representation does not guarantee representation across schools, club status, or lunch habits.
5. **Why the others fail.**
    - **(B)** Outcome substitution: the director infers preferences from ratings, not purchases from ratings.
    - **(C)** Future stability is not part of the claimed current districtwide preference.
    - **(D)** Grade-to-grade ranking is not the claim; having all grade levels present does not repair coverage bias.
    - **(E)** The director claims a majority preference, not unanimous approval, and 18 percent of respondents did not give a favorable rating.

**Check:** Most respondents in a skewed sampling frame ≠ most district students.
::::
:::
:::problem[Question III.10]
A museum proposes replacing carpet with stone flooring in a lecture gallery. The designer says the stone will make the room more visually consistent with neighboring exhibits. A consultant responds that the room’s main purpose is spoken lectures, not display. **Sound measurements from a trial installation showed that reverberation remained high long after each spoken phrase ended.** Because overlapping sounds make speech less intelligible, the consultant recommends acoustic panels before any stone-floor project proceeds. The consultant does not argue that the stone should be permanently rejected; panels could allow the intended appearance without sacrificing clarity.

The statement about sound measurements plays which one of the following roles in the consultant’s argument?

- **(A)** It is the designer’s aesthetic reason for preferring stone over carpet.
- **(B)** It is a concession that high reverberation improves speech intelligibility.
- **(C)** It is the consultant’s final recommendation about the ordering of renovations.
- **(D)** It supplies empirical evidence of a problem that motivates the recommendation to install acoustic panels before the flooring change.
- **(E)** It establishes that no acoustic treatment can improve the room.

::::solution[Solution]
**Answer:** (D)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The consultant recommends placing acoustic treatment before installing new stone.
2. **Support.** The measurement reports lingering reverberation, a basis for concern about overlapping speech.
3. **Prephrase.** Identify the sentence as evidence distinct from the consultant’s conclusion.
4. **Why (D) is right.** The empirical observation backs the acoustics premise, which in turn supports sequencing panels first.
5. **Why the others fail.**
    - **(A)** Speaker and issue reversed: the designer’s reason is visual consistency, not measured sound decay.
    - **(B)** Opposite causal implication: the consultant says lingering sound impairs speech.
    - **(C)** Confuses evidential measurement with the later policy recommendation.
    - **(E)** Too absolute and contrary to the proposal that panels could help.

**Check:** Observed long reverberation + intelligibility harm → acoustic panels before stone.
::::
:::
:::problem[Question III.11]
The environmental office awards a stream restoration grant only to projects that complete a habitat review. Every project that completes a habitat review is assigned a watershed code. A project called Willow Bend has been assigned a watershed code, and the program officer concludes that it qualifies for the grant. The grant rules also require budget approval, and the officer has confirmed that Willow Bend has received it. Nevertheless, the available information does not yet show that Willow Bend completed the required habitat review.

Which one of the following, if assumed, makes the officer’s conclusion follow logically?

- **(A)** Every grant recipient has a watershed code and an approved budget.
- **(B)** Every project assigned a watershed code has completed a habitat review, and every budget-approved project that completed such a review qualifies for the grant.
- **(C)** Some projects with watershed codes qualify for grants after review.
- **(D)** Any project with a habitat review is assigned a watershed code regardless of its budget status.
- **(E)** No project lacking a watershed code can qualify for the grant.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The officer infers that coded, budget-approved Willow Bend is eligible for the grant.
2. **Support.** Grant → review → code and budget is required; existing facts do not give code → review or reviewed+budget → grant.
3. **Prephrase.** Fill both missing directions to make qualification a deductive consequence.
4. **Why (B) is right.** The first added condition yields review from the code; the second yields qualification from review and budget approval.
5. **Why the others fail.**
    - **(A)** Only states necessary grant properties, which do not make Willow Bend a recipient.
    - **(C)** Existential “some” cannot place this particular project in the qualifying subset.
    - **(D)** Repeats review → code already known and lacks a sufficient qualification condition.
    - **(E)** Rephrases the necessity of code but cannot infer qualification from having one.

**Check:** Code → review; review AND budget → qualify; Willow Bend has code AND budget → qualifies.
::::
:::
:::problem[Question III.12]
A municipal board has adopted these procedures for public hearings. Every hearing about a zoning amendment must have a notice posted online. No hearing may be held fewer than ten days after its required notice is posted. All hearings scheduled for the second week of December concern zoning amendments, but a few hearings concerning other subjects are scheduled for later that month. A proposed December 9 hearing had its notice posted online on November 27. The board has not announced whether any hearings will be postponed, and some notices also appear in print.

Which one of the following is most strongly supported by these facts?

- **(A)** If the proposed December 9 hearing is held as scheduled, its online notice satisfies the stated minimum timing requirement.
- **(B)** All December board hearings require online notice.
- **(C)** The December 9 hearing must be postponed because its notice was late.
- **(D)** The board never posts a notice earlier than required by its rules.
- **(E)** No December hearing is permitted to have a printed notice.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Infer what follows from the stated date gap and scheduling context.
2. **Support.** The proposed hearing’s notice was placed on November 27, twelve calendar days before December 9.
3. **Prephrase.** Compare the dates to the minimum ten-day rule, without inferring postponement.
4. **Why (A) is right.** Twelve days exceed the required ten; the stated timing condition is met if the hearing occurs as planned.
5. **Why the others fail.**
    - **(B)** Only second-week hearings are all zoning; other subjects later may have different notice rules.
    - **(C)** It is not late; the date gap exceeds ten days.
    - **(D)** Nothing says the board avoids early notices, and this one is early enough.
    - **(E)** The possibility of printed notices is explicitly allowed.

**Check:** Nov 27 to Dec 9 = 12 days, which is not fewer than 10 days.
::::
:::
:::problem[Question III.13]
Every patient who is referred to the specialized clinic is entered on the referral register. Anyone entered on that register receives a scheduling call within two business days. Priya has been referred to the specialized clinic, according to her physician’s signed note. The office administrator concludes that Priya will receive a scheduling call within two business days. The administrator does not claim that the call guarantees a completed appointment or a favorable medical outcome; the conclusion concerns only the procedural consequence of the referral.

Which one of the following arguments is most similar in its reasoning to the argument above?

- **(A)** Every certified mechanic has completed training; this mechanic completed training; so this mechanic is certified.
- **(B)** Some registered voters receive mailed notices; Theo is registered; therefore Theo will receive a notice.
- **(C)** A fire alarm is activated only if smoke is detected; smoke was detected; therefore the alarm was activated.
- **(D)** No rejected submission is published; this submission was not rejected; therefore it was published.
- **(E)** Every approved permit receives a serial number; every numbered permit appears on the online list; this permit was approved, so it appears on the list.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The referral leads through two universal rules to a scheduling call.
2. **Support.** Referred → registered → called; Priya referred.
3. **Prephrase.** Find a valid two-link forward conditional chain with a specified individual.
4. **Why (E) is right.** Approved → numbered → listed; specific approval yields listing in the same form.
5. **Why the others fail.**
    - **(A)** Affirms the consequent by treating a training requirement as sufficient for certification.
    - **(B)** Uses “some” as though it were “all,” so one registered voter has no guaranteed notice.
    - **(C)** “Only if” makes smoke necessary for activation, not sufficient for activation.
    - **(D)** No rejected → published is a prohibition on one class; not rejected does not force published.

**Check:** A → B → C and A(x) imply C(x) in both the original and correct parallel.
::::
:::
:::problem[Question III.14]
A neighborhood newsletter claims that an old courthouse is the finest example of civic architecture in the region. When readers request evidence for this ranking, the editor says that buildings ranked below the courthouse plainly lack its superior design. Asked how one can tell that the courthouse has superior design, the editor replies that it must, because no other courthouse in the region deserves the top architectural ranking. The editor has published photographs of several buildings but has not offered any independently defined criterion for architectural quality.

The argument is most vulnerable to criticism because it...

- **(A)** compares courthouse design with other buildings without specifying whether the buildings were built during the same historical era.
- **(B)** moves from one example of a well-designed courthouse to a claim about how every courthouse in the region was constructed.
- **(C)** assumes, in defending the courthouse’s top ranking, a claim equivalent to the ranking it is trying to establish.
- **(D)** appeals to the publication of photographs as conclusive proof that the courthouse is superior.
- **(E)** fails to establish that the editor’s readers agree with the ranking.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The editor insists the courthouse is the finest by asserting its superiority.
2. **Support.** When pressed for criteria, the response merely repeats that it outranks everything else.
3. **Prephrase.** Name circular reasoning: premises give no independent reason for the conclusion.
4. **Why (C) is right.** “Superior because it deserves top rank” is the same claim in different language.
5. **Why the others fail.**
    - **(A)** Comparability may matter in architectural review, but the defect here is that the proposed evidence simply repeats the ranking.
    - **(B)** Invented universal: the editor ranks designs; he does not infer a common construction method.
    - **(D)** Photographs are noted as context, but the editor’s actual defense is a restatement of the unproved ranking.
    - **(E)** Popularity is not the stated basis of design quality; agreement by readers would not break the logical circle.

**Check:** Replace “superior design” with “deserves top rank”; premise and conclusion become the same proposition.
::::
:::
:::problem[Question III.15]
A school plans to add compost to a rain garden next to its vegetable beds. The garden manager argues that the compost will improve drainage and should not increase the risk of contaminating vegetables, because the compost has passed standard tests for pathogens. A science teacher points out that the supplier also collects compostable packaging, some of which may contain chemical additives not covered by the pathogen tests. The manager insists that the pathogen results are enough to establish that the compost will not add any contamination risk.

Which one of the following is an assumption required by the manager’s conclusion?

- **(A)** The compost will cause the vegetables to grow faster than any plants without compost.
- **(B)** No microorganisms of any kind are present anywhere in the compost.
- **(C)** The school has never previously added organic matter to its garden.
- **(D)** The compost does not contain untested chemical substances at levels capable of increasing contamination risk to nearby vegetables.
- **(E)** The supplier separates all packaging by color before processing the compost.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The manager claims no increased contamination risk based on pathogen tests alone.
2. **Support.** The tests do not measure potential hazardous chemicals from packaging.
3. **Prephrase.** Rule out the specific untested danger that would defeat the safety claim.
4. **Why (D) is right.** Negating the answer allows hazardous additives in the applied compost and undermines “no added risk.”
5. **Why the others fail.**
    - **(A)** Growth improvement is neither the safety criterion nor needed for it.
    - **(B)** Too extreme: harmless microorganisms can exist without making vegetables unsafe.
    - **(C)** The garden’s history is unrelated to chemical presence in this batch.
    - **(E)** Color sorting cannot guarantee chemical safety; its absence need not create the asserted hazard.

**Check:** Negation: hazardous untested additives present → acceptable pathogen results do not imply safe compost.
::::
:::
:::problem[Question III.16]
A physician recommends prescribing a new pain treatment to patients over eighty because a study found the treatment effective among adults aged forty through sixty. A clinical researcher objects that older adults may process the drug differently and were excluded from the trial. The researcher does not claim that the treatment fails in older adults. Instead, she argues that results from one age group alone cannot establish effectiveness or safety for a distinct, untested group. She proposes a small, monitored study involving older patients before the physician makes a general recommendation.

Which one of the following most accurately describes the researcher’s method of reasoning?

- **(A)** She challenges an extrapolation by pointing out a relevant difference between the studied population and the population to which the conclusion is extended.
- **(B)** She proves that the pain treatment is ineffective for every patient older than eighty.
- **(C)** She rejects the study’s findings because the investigators were unlicensed.
- **(D)** She argues that a large trial is always worse than a small study.
- **(E)** She concludes that all drugs pose the same risk to people of every age.

::::solution[Solution]
**Answer:** (A)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The researcher says evidence for ages forty to sixty does not by itself justify prescribing generally to the over-eighty group.
2. **Support.** Possible differences in drug processing and explicit exclusion of older people undermine generalization.
3. **Prephrase.** Identify the scope objection without overstating the evidence as proof of failure.
4. **Why (A) is right.** The studied sample does not contain the target group, and a medically relevant difference could affect transportability.
5. **Why the others fail.**
    - **(B)** The researcher expressly declines to say the treatment fails in older patients.
    - **(C)** No investigator licensing or professional credentials are questioned.
    - **(D)** She asks for a small monitored initial study, not a general ranking of trial sizes.
    - **(E)** Her concern is age-dependent effects, the opposite of equal risk across ages.

**Check:** Evidence from group A is not automatically sufficient for group B when a relevant mechanism may differ.
::::
:::
:::problem[Question III.17]
An architect compares converting an unused office tower into residences with demolishing it and erecting a new residential tower. A spreadsheet indicates that the conversion requires less new concrete and steel. The architect concludes that conversion will necessarily result in lower total greenhouse-gas emissions over the next forty years. The new tower, however, is designed to require much less heating and cooling energy, while the existing tower would retain its original exterior envelope. The spreadsheet estimates construction materials but does not include the buildings’ operating emissions.

Which one of the following, if true, most weakens the architect’s conclusion?

- **(A)** Conversion would preserve many original architectural details.
- **(B)** The new tower would require more steel in its frame than the converted tower.
- **(C)** Over forty years, the converted building’s additional heating and cooling emissions would exceed the emissions saved by reusing the existing structure.
- **(D)** The converted building could be occupied sooner than the new building.
- **(E)** Some residents prefer living in older buildings to newly constructed ones.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The architect claims necessarily lower total long-run emissions from lower construction material demand.
2. **Support.** The comparison leaves out operating energy over forty years, even though the new design is more efficient.
3. **Prephrase.** Show the uncounted operational difference exceeds embodied-carbon savings.
4. **Why (C) is right.** The stated numerical relationship reverses the claimed total comparison by making conversion’s life-cycle emissions greater.
5. **Why the others fail.**
    - **(A)** Historic detail preservation is a noncarbon value.
    - **(B)** More steel supports the architect’s construction-emissions premise, not the total-emissions inference.
    - **(D)** Earlier occupancy speaks to delivery schedule, not forty-year emissions without additional figures.
    - **(E)** Resident preferences are separate from the emissions calculation.

**Check:** Total = construction + operations; if extra operations > saved construction, conversion has higher total.
::::
:::
:::problem[Question III.18]
Every building awarded the city’s weatherproofing seal has passed an airtightness test. A renovated school passed that test during an inspection last week, so the contractor concludes that the school qualifies for the weatherproofing seal. The contractor acknowledges that seal applications involve paperwork and independent checks but insists that passing the airtightness test settles the matter. The school board asks for a comparison with another argument to identify the logical mistake without relying on any knowledge of construction practices.

Which one of the following arguments exhibits the most similar flawed reasoning?

- **(A)** Every licensed pilot completed a flight examination; Benton did not complete one; therefore Benton is not a licensed pilot.
- **(B)** If a recipe contains peanuts, it carries an allergen warning; this recipe contains peanuts; therefore it carries the warning.
- **(C)** All published abstracts have been edited; this abstract is unedited; therefore it is unpublished.
- **(D)** Every high-risk specimen requires special handling; this specimen is high-risk; so it requires special handling.
- **(E)** All members of the archaeological society pay annual dues; Alia pays annual dues; therefore Alia belongs to the society.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The contractor reverses seal → passed test into passed test → seal.
2. **Support.** A necessary condition of seal qualification is treated as sufficient.
3. **Prephrase.** Match affirming the consequent, not a valid contrapositive or modus ponens.
4. **Why (E) is right.** Society member → dues; dues paid → member is the same invalid converse.
5. **Why the others fail.**
    - **(A)** Valid contrapositive: licensed → completed; not completed → not licensed.
    - **(B)** Valid forward conditional reasoning from peanuts to a warning.
    - **(C)** Valid contrapositive of published → edited.
    - **(D)** Valid modus ponens: high risk → special handling, and high risk is given.

**Check:** Both invalid forms: A → B; B; conclude A.
::::
:::
:::problem[Question III.19]
Editor One: When we obtain authentic public-budget documents, we should publish the originals even if they contain the home addresses of low-level employees. Readers deserve to check our reporting against unaltered source material. We can warn readers that addresses appear inside. Editor Two: Readers should have access to the budget figures and enough original formatting to verify our calculations, but employees’ home addresses are irrelevant to that verification. We should redact those addresses before posting documents. A warning does not adequately protect people from unnecessary disclosure once the files circulate.

The two editors disagree over whether...

- **(A)** readers should be able to verify the newsroom’s treatment of budget figures.
- **(B)** home addresses of low-level employees should remain visible when authentic budget documents are published.
- **(C)** the budget documents are authentic.
- **(D)** the newsroom should include any budget figures in its story.
- **(E)** employee addresses are legally protected by a particular privacy statute.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** One editor opposes redaction; the other requires it.
2. **Support.** Both support reader verification and both accept authentic records; they dispute unnecessary address disclosure.
3. **Prephrase.** Identify the single claim each explicitly answers in opposite ways.
4. **Why (B) is right.** One says publish originals with addresses visible, while Two says redact those addresses.
5. **Why the others fail.**
    - **(A)** Both affirm the importance of allowing readers to verify budget analysis.
    - **(C)** Authenticity is assumed by the setup and not disputed.
    - **(D)** Both presume the budget information matters and should be accessible.
    - **(E)** Neither editor asserts a specific legal statute or a legal claim of protection.

**Check:** Editor One: visible addresses yes. Editor Two: visible addresses no.
::::
:::
:::problem[Question III.20]
A hospital tested a policy requiring nonurgent nighttime equipment checks to be grouped into two scheduled rounds rather than scattered through the night. Patients on the trial ward reported fewer nighttime awakenings, and administrators concluded that the grouping reduced sleep interruptions. A skeptic points out that the trial ward also received new sound-absorbing door seals during the pilot. The hospital recorded check times and sampled sound levels in patient rooms before and after the schedule change. Patient acuity and average ward occupancy were stable over the period.

Which one of the following, if true, most strengthens the administrators’ explanation?

- **(A)** The new door seals were purchased at a discount from the manufacturer.
- **(B)** Some patients liked knowing the approximate times of scheduled rounds.
- **(C)** The number of hospital beds on the trial ward remained constant.
- **(D)** Awakenings declined most sharply during hours when unscheduled equipment checks were eliminated, while recorded noise from door openings was unchanged during those hours.
- **(E)** Daytime visitors reported that hallways looked cleaner after the pilot.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The administrators attribute fewer awakenings to the changed timing of equipment checks.
2. **Support.** Door seals are a concurrent alternative explanation, while occupancy and acuity are held steady.
3. **Prephrase.** Find a temporal pattern matching eliminated check interruptions while not matching reduced door noise.
4. **Why (D) is right.** Changes align with the check schedule in specific hours while the skeptic’s door-noise mechanism is held steady there.
5. **Why the others fail.**
    - **(A)** The seals’ purchase price has no bearing on sleep causation.
    - **(B)** Predictability may be a separate benefit but does not show actual awakenings changed because checks were grouped.
    - **(C)** Bed count does not isolate the equipment-check mechanism from the new door seals.
    - **(E)** Appearance of hallways during daytime is unrelated to nighttime awakenings.

**Check:** The drop occurs where checks disappear even without a noise-level change from doors, favoring schedule over seals.
::::
:::
:::problem[Question III.21]
A municipal election office began sending weekly email newsletters explaining how to register and vote. The office observed that reported email-open rates rose steadily, and its director concludes that residents became more interested in voting. A consultant notes that the office also changed its email provider and that the new provider marks an email as opened when certain security scanners fetch its tracking image automatically. The director replies that the change in provider cannot matter because the newsletter’s wording stayed almost identical. The office has access to both tracking data and voluntary reader surveys.

Which one of the following would be most useful to determine in evaluating the director’s conclusion?

- **(A)** Whether the newsletter used more blue than green in its header.
- **(B)** Whether election staff preferred the old provider’s customer-service interface.
- **(C)** Whether local newspapers covered the election more frequently than neighboring counties’ newspapers.
- **(D)** Whether the director personally opened every newsletter sent by the office.
- **(E)** Whether independently surveyed residents showed increased interest in voting while the email provider’s automatic-open behavior was accounted for.

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The director interprets rising tracked opens as increased civic interest.
2. **Support.** The metric’s meaning may change because security scanners trigger opens independently of human interest.
3. **Prephrase.** Use an outcome measure independent of scanner-generated opens, and assess the measurement artifact.
4. **Why (E) is right.** If interest rose in independent surveys after adjusting opens, the inference gains support; if not, the artifact is plausible.
5. **Why the others fail.**
    - **(A)** Header color does not distinguish machine opens from human interest.
    - **(B)** Staff usability preference is unrelated to the validity of engagement measurements.
    - **(C)** News coverage could affect interest, but without tracking real interest it does not test what the open rate measures.
    - **(D)** The director’s own behavior is one person and cannot validate residents’ aggregate engagement.

**Check:** Compare real interest with adjusted opens: agreement supports the claim, divergence undermines it.
::::
:::
:::problem[Question III.22]
A popular science columnist observes that many fossils of a coastal reptile species disappear from the local rock record immediately above an ash layer from a volcanic eruption. She concludes that the eruption caused the species’ worldwide extinction. The fossils come from one coastal basin, and geological mapping suggests that sediment stopped accumulating there for several thousand years after the eruption. Fossil collections from distant basins remain poorly dated. The columnist concedes that the local record has a gap but says the sharp disappearance in that record is enough to establish the worldwide event.

The columnist’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that the ash layer must have formed at exactly the same time in every basin where the reptile lived.
- **(B)** infers a global biological disappearance from a local absence of fossils that could result from a break in sediment deposition.
- **(C)** takes the abrupt local disappearance of fossils as evidence that the reptiles’ bodies immediately stopped fossilizing everywhere.
- **(D)** infers that volcanic eruptions cannot affect extinction because sediment is sometimes not deposited.
- **(E)** fails to distinguish between species found near shore and those living in deeper water when estimating total reptile diversity.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The columnist concludes that one eruption caused worldwide extinction.
2. **Support.** The local series has a depositional gap, and other regions lack precise dating.
3. **Prephrase.** Look for missing fossils that could reflect a missing record, plus unsupported leap from local to global.
4. **Why (B) is right.** Failure to deposit fossil-bearing rocks makes apparent local disappearance compatible with continued survival elsewhere.
5. **Why the others fail.**
    - **(A)** No such cross-basin simultaneity claim is needed for the stated local-to-global leap.
    - **(C)** This mischaracterizes the conclusion: the columnist claims extinction, not a global cessation of fossilization processes.
    - **(D)** The columnist asserts the opposite conclusion and does not dispute the general possibility of volcanic effects.
    - **(E)** Different habitat sampling concerns are not the key disputed claim about extinction of this one species.

**Check:** No sediments → no local fossil record even if animals persist; local gap cannot prove global extinction.
::::
:::
:::problem[Question III.23]
A town clerk discovers that an automated transcript of a council hearing omitted two sentences from a resident’s criticism of a rezoning proposal. The clerk can restore the sentences from the archived audio. A councilor says that since the omission appears accidental and the final vote is over, there is no need to correct the transcript. Another councilor objects that public records should allow future readers to understand testimony accurately, independently of whether a particular vote can be changed. Correcting the transcript would not alter the official minutes recording the vote.

Which one of the following principles most strongly justifies correcting the transcript?

- **(A)** Records should be amended only when the error can change the outcome of a current vote.
- **(B)** Any computer-generated transcript should be discarded in full if it includes a single omission.
- **(C)** An accidental omission is harmless whenever the speaker can attend a later meeting.
- **(D)** An official public record should be corrected when verifiable errors materially distort testimony, even if the underlying decision can no longer be changed.
- **(E)** Public agencies should preserve every detected error so researchers can study recordkeeping failures.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The objection calls for accurate public understanding regardless of whether the vote is final.
2. **Support.** The audio provides a verification source and the omitted criticism is material testimony.
3. **Prephrase.** Pick a principle linking verifiable material errors with public-record accuracy, not procedural reversibility.
4. **Why (D) is right.** The proposed rule requires restoring the sentences although the vote remains final.
5. **Why the others fail.**
    - **(A)** It echoes the councilor’s outcome-only rationale and would forbid this correction.
    - **(B)** Too absolute: one repairable transcription error need not invalidate the entire record.
    - **(C)** Future meeting opportunity cannot substitute for accurate documentation of the earlier hearing.
    - **(E)** Preserving mistakes would defeat the very accuracy rationale at issue.

**Check:** Verified material omission + duty of faithful record → correct transcript despite completed vote.
::::
:::
:::problem[Question III.24]
An architect plans to convert a former library into a music rehearsal facility. Tests in the building’s central reading room found that its heavy walls block substantial sound transmission to adjacent rooms. The architect concludes that rehearsal activities in every proposed studio will meet the noise standards for nearby apartments without any additional sound insulation. But three studios will be built in the former glass-fronted lobby, which was not included in the tests. The architect says the lobby is part of the same building and therefore need not be measured separately.

Which one of the following is an assumption required by the architect’s argument?

- **(A)** Every musician who uses the studios will play at exactly the same volume.
- **(B)** The heavy reading-room walls are the original walls built when the library opened.
- **(C)** The untested lobby studios will not transmit enough additional sound to violate the nearby apartments’ noise standards.
- **(D)** The library previously hosted some musical performances.
- **(E)** The nearby residents prefer music rehearsals to a vacant building.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The architect claims all studios will meet outside noise limits without added insulation.
2. **Support.** Tests of a heavy-walled room do not cover proposed studios in a glass-fronted lobby.
3. **Prephrase.** Find the necessary limit on sound from the untested part of the plan.
4. **Why (C) is right.** If the lobby studios violate noise standards, the conclusion about every studio fails.
5. **Why the others fail.**
    - **(A)** Uniform playing volume is much stronger than necessary for an acoustic compliance claim.
    - **(B)** Wall age has no necessary relationship to untested lobby sound transmission.
    - **(D)** Earlier performances, even if true, do not prove future studio compliance.
    - **(E)** Neighborhood preferences cannot establish measured noise-limit compliance.

**Check:** Negate: one lobby studio exceeds the permitted noise level; “every proposed studio complies” is false.
::::
:::
:::problem[Question III.25]
A city purchasing policy provides that every bid recommended for award must first receive a technical review. Every bid receiving a technical review has a corresponding digital audit entry. No bid with an incomplete conflict-of-interest disclosure may be recommended for award. Several bids submitted for a new water-treatment pump were recommended for award. One additional pump bid was rejected because of an incomplete disclosure, but the policy does not specify whether that rejected bid received a technical review. Recommendations remain subject to a later council vote.

Which one of the following must be true?

- **(A)** At least one bid for the pump that was recommended for award has a corresponding digital audit entry.
- **(B)** Every pump bid with a digital audit entry was recommended for award.
- **(C)** The council awarded a contract to each pump bidder recommended by staff.
- **(D)** The rejected pump bid necessarily underwent technical review before it was rejected.
- **(E)** No pump bid that had a complete disclosure was rejected for any reason.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** Chain the requirements on at least one bid among the several recommended for award.
2. **Support.** Recommended → technically reviewed → digital audit entry.
3. **Prephrase.** Preserve direction and distinguish recommendations from final awards.
4. **Why (A) is right.** Since several recommended bids exist, each was reviewed and entered; “at least one” follows.
5. **Why the others fail.**
    - **(B)** Converse error: audited bids may fail other requirements and not be recommended.
    - **(C)** No council vote outcome is stated; recommendation does not entail award.
    - **(D)** The rejected bid’s review status is explicitly left unspecified.
    - **(E)** A complete disclosure removes one disqualifier but does not prevent rejection for unrelated reasons.

**Check:** Some recommended bids exist; recommended → review → audit; therefore some pump bids have audits.
::::
:::
## 30.4 Scoring and review

Score **one point per correct answer**, with no penalty for a wrong answer. Your raw score is __ / **77**. This is an *unequated original test*: a raw score here cannot be reliably translated into an official 120–180 LSAT score or percentile. Track section accuracy, flagged correct guesses, and recurring error types rather than manufacturing a score conversion.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | A | Main conclusion | 4 |
| I.2 | B | Flaw | 9 |
| I.3 | C | Necessary assumption | 7 |
| I.4 | D | Strengthen | 8 |
| I.5 | E | Must be true | 10 |
| I.6 | B | Weaken | 8 |
| I.7 | D | Role of a statement | 11 |
| I.8 | A | Sufficient assumption | 7 |
| I.9 | E | Flaw | 9 |
| I.10 | C | Resolve the paradox | 13 |
| I.11 | A | Principle | 13 |
| I.12 | D | Necessary assumption | 7 |
| I.13 | B | Most strongly supported | 10 |
| I.14 | E | Parallel reasoning | 12 |
| I.15 | C | Weaken | 8 |
| I.16 | D | Flaw | 9 |
| I.17 | B | Method of reasoning | 11 |
| I.18 | E | Strengthen | 8 |
| I.19 | A | Point at issue | 11 |
| I.20 | C | Must be true | 10 |
| I.21 | E | Parallel flaw | 12 |
| I.22 | A | Necessary assumption | 7 |
| I.23 | D | Evaluate | 8 |
| I.24 | C | Flaw | 9 |
| I.25 | B | Principle | 13 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | B | RC main point | 18 |
| II.2 | D | RC detail | 18 |
| II.3 | A | RC inference | 18 |
| II.4 | C | RC function | 18 |
| II.5 | E | RC attitude | 18 |
| II.6 | C | RC application | 18 |
| II.7 | A | RC analogy | 18 |
| II.8 | D | RC main point | 18 |
| II.9 | B | RC detail | 18 |
| II.10 | E | RC function | 18 |
| II.11 | D | RC inference | 18 |
| II.12 | C | RC application | 18 |
| II.13 | B | RC attitude | 18 |
| II.14 | A | RC analogy | 18 |
| II.15 | E | Comparative main point | 17 |
| II.16 | B | Comparative agreement | 17 |
| II.17 | C | Comparative relationship | 17 |
| II.18 | D | Comparative inference | 17 |
| II.19 | A | Comparative application | 17 |
| II.20 | E | Comparative relationship | 17 |
| II.21 | B | RC main point | 18 |
| II.22 | C | RC detail | 18 |
| II.23 | D | RC function | 18 |
| II.24 | A | RC inference | 18 |
| II.25 | B | RC attitude | 18 |
| II.26 | E | RC application | 18 |
| II.27 | C | RC primary purpose | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | C | Flaw | 9 |
| III.2 | D | Must be true | 10 |
| III.3 | A | Strengthen | 8 |
| III.4 | E | Necessary assumption | 7 |
| III.5 | B | Main conclusion | 4 |
| III.6 | E | Weaken | 8 |
| III.7 | C | Principle | 13 |
| III.8 | B | Resolve the paradox | 13 |
| III.9 | A | Flaw | 9 |
| III.10 | D | Role of a statement | 11 |
| III.11 | B | Sufficient assumption | 7 |
| III.12 | A | Most strongly supported | 10 |
| III.13 | E | Parallel reasoning | 12 |
| III.14 | C | Flaw | 9 |
| III.15 | D | Necessary assumption | 7 |
| III.16 | A | Method of reasoning | 11 |
| III.17 | C | Weaken | 8 |
| III.18 | E | Parallel flaw | 12 |
| III.19 | B | Point at issue | 11 |
| III.20 | D | Strengthen | 8 |
| III.21 | E | Evaluate | 8 |
| III.22 | B | Flaw | 9 |
| III.23 | D | Principle | 13 |
| III.24 | C | Necessary assumption | 7 |
| III.25 | A | Must be true | 10 |
:::

| Missed-question family | Study in this book |
| --- | --- |
| Finding conclusions and premises | Chapter 4 |
| Conditionals, quantifiers, and inference chains | Chapters 5 and 10 |
| Flaw identification and causal reasoning | Chapters 6 and 9 |
| Necessary and sufficient assumptions | Chapter 7 |
| Strengthen, weaken, and evaluate | Chapter 8 |
| Role, method, and point at issue | Chapter 11 |
| Parallel reasoning and parallel flaws | Chapter 12 |
| Paradox and principle | Chapter 13 |
| RC passage structure and viewpoint | Chapter 15 |
| Comparative reading | Chapter 17 |
| RC detail, inference, function, and tone | Chapter 18 |
| Blind review and error logging | Chapters 22 and 23 |

For each miss, reread the stimulus or passage without answer choices, write a one-sentence prediction, then explain why **each wrong option** fails. Keep flagged correct guesses in your review log: they reveal unstable reasoning even when the raw score looks good.
