---
title: "Anatomy & Logistics"
source: "lsat_ch2_anatomy.html"
---

Part I · Chapter 2

# Anatomy & Logistics

The physical shape of the test — how many sections, how long, how it's delivered, and every logistical decision you'll have to make from registration to test day.

**Est. study time:** 40–50 min — **Sections:** 6 — **Practice:** 20+ items

## Overview

Chapter 1 told you what the LSAT measures. This chapter tells you what it physically *is*: the sections, the clock, the screen, and the paperwork. None of it is hard, but every piece has a strategic consequence — the unscored section changes how you spend effort, the 35-minute clock dictates your pacing, and the registration calendar quietly decides whether you apply early enough to matter. Treat logistics as part of your score: people lose points to a surprise on test day that a single paragraph here would have prevented.

By the end you'll know exactly how the four sections fit together, why one of them doesn't count and what to do about it, the arithmetic of pacing, how the online test and its on-screen tools work, and the calendar and money decisions around registering, retaking, and reporting your score.

:::callout-tip
Prerequisites

Chapter 1 (the test is a skill, and Logical Reasoning is now two of the three scored sections). Everything else is built from scratch here.
:::

:::callout-warning
One standing caveat for this whole chapter

Logistics — dates, fees, retake limits, exact tools, in-person vs. remote options — are the parts of the LSAT most likely to change. Every figure here reflects the format as of 2026, but **always confirm the current specifics at [lsac.org](https://www.lsac.org)** before you register or pay. Understand the *structure* from this chapter; get the *numbers* from the official source at the moment you act.
:::

## 2.1 · The four sections

:::callout-intuition
Intuition first

Picture the test as four back-to-back 35-minute sprints. Three of them are graded; one is a hidden tryout of new questions that doesn't count. You won't be told which is which, so from your seat it just feels like four sprints of equal importance. The whole multiple-choice test is those four sprints plus one short break in the middle — under three hours of actual testing.
:::

The multiple-choice LSAT consists of **four 35-minute sections.** Three of them count toward your score, and one does not:

| Section | Counts? | Questions | Time |
| --- | --- | --- | --- |
| Logical Reasoning | Scored | ~24–26 | 35 min |
| Logical Reasoning | Scored | ~24–26 | 35 min |
| Reading Comprehension | Scored | ~26–28 | 35 min |
| Unscored ("experimental") | **No** | ~24–28 | 35 min |

So the three *scored* sections are **two Logical Reasoning and one Reading Comprehension** — roughly **75–77 scored questions** in total. A mandatory **10-minute break** comes after the second section. Including that break, the multiple-choice portion runs about **2 hours and 40 minutes**. (The [Argumentative Writing](./lsat_textbook_toc.html) task is separate — Chapter 20 — and isn't part of this sitting.)

:::definition
**Definition 2.1 — The scored core.** Your 120–180 score is computed from three scored sections: *two Logical Reasoning* and *one Reading Comprehension*. Because LR appears twice, it contributes about **two-thirds of the scored sections and roughly half of all scored questions** — the single biggest lever on your score.
:::

:::callout-connect
Connects to Chapter 1

This is the concrete payoff of the 2024 redesign you learned in §1.3: the retired Logic Games section was replaced by a *second* Logical Reasoning section. That's why two of the three scored sections are LR — and why Part II of this course is its largest.
:::

## 2.2 · The unscored "experimental" section

:::callout-intuition
Intuition first

How does LSAC know a brand-new question is fair before it counts? It slips new questions into real tests and watches how thousands of people perform on them — *without* letting those questions affect anyone's score. That's the experimental section: a live tryout. The catch for you is that it's **disguised as a normal section** and never labeled, so you can't tell it apart from the real thing while you're taking the test.
:::

One of your four sections is **unscored**. LSAC uses it to pretest questions for future exams. It looks exactly like a scored section — same format, same length — and it can be **either an extra Logical Reasoning or an extra Reading Comprehension**, appearing at **any position** in the test. You are not told which section it is.

:::definition
**Definition 2.2 — The experimental (variable) section.** An unscored 35-minute section, indistinguishable from the scored ones, used to field-test new questions. Its position and type vary. Practical upshot: on test day you will face **either three LR sections and one RC, or two LR and two RC** — and only later does it matter which of those didn't count.
:::

### Why it changes how you play the test

Because you can't identify the experimental section, there is exactly one correct strategy: **treat every section as if it's scored.** Any effort you "save" by guessing which one is fake is a gamble that can cost you real points. But the experimental section has two genuine consequences worth planning around:

- **Endurance.** You must sustain full concentration across *four* hard sections, not three. That extra section is why fatigue is a real adversary — and why your practice tests should include a fifth experimental-style section to build stamina (Chapter 24).
- **Section mix.** Since the extra section is often another Logical Reasoning, you may do **three** LR sections in one sitting. That reinforces, again, that LR is where your preparation pays off most.

:::callout-pitfall
Watch out for these mistakes

- **Trying to "spot" the experimental section** to coast through it. You can't reliably identify it, and if you guess wrong you've thrown away a scored section. Never do this.
- **Letting a hard section rattle you** by assuming "that one must have been experimental." Maybe it was — but you have no way to know, and dwelling on it costs you focus on the sections that follow.
- **Training for only three sections.** If every practice test you take is three or four sections while the real thing is four, you'll under-train endurance. Simulate the full length.
:::

### Practice — 2.2

:::problem[Q1]{difficulty="easy"}
How many of the four multiple-choice sections count toward your score, and how many are experimental?

::::solution[Solution]
**Three count** (two LR + one RC); **one** is the unscored experimental section.
::::
:::

:::problem[Q2]{difficulty="standard"}
Midway through the test you hit a brutally hard Reading Comp section and think, "This must be the experimental one." What should you do?

- **(A)** Skip it and use the time on other sections.
- **(B)** Ask the proctor which section is unscored.
- **(C)** Relax and guess through it, since it probably doesn't count.
- **(D)** Give it full effort — you can't know if it's experimental, and treating a scored section as fake could cost real points.
- **(E)** Answer only the questions you find easy and leave the rest blank.

::::solution[Solution]
**(D).** The experimental section is unlabeled and could be any type at any position; assuming it's fake is a losing gamble. Full effort on every section is the only correct policy. (Proctors won't tell you.)
::::
:::

:::problem[Q3]{difficulty="standard"}
Why should full-length practice tests include an extra, fifth section?

::::solution[Solution]
To build **endurance** that matches test day. The real test has four sections (one experimental), and concentration must hold across all of them. Practicing with an added section trains the stamina the experimental section demands. *(Some also add a fifth to mimic the full four-section fatigue while still getting three scored practice sections.)*
::::
:::

:::problem[Q4]{difficulty="challenge"}
A test-taker reports doing three Logical Reasoning sections on their exam. Is that possible, and what does it tell you about their experimental section?

::::solution[Solution]
**Yes, it's possible and common.** Two LR sections are scored; if the experimental section was *also* LR, they'd see three LR sections total (plus one RC). It tells you their unscored section was a Logical Reasoning one — but they had no way to know *which* of the three LR sections it was, so all three still had to get full effort.
::::
:::

## 2.3 · Pacing math

:::callout-intuition
Intuition first

The LSAT's difficulty isn't only in the questions — it's in the *clock*. Thirty-five minutes per section sounds generous until you divide it by the number of questions and realize you get well under a minute and a half each. Knowing the arithmetic turns a vague dread ("I'm slow!") into a concrete plan ("I have ~1:25 per LR question; a 3-minute question means I owe time elsewhere"). Pacing is a skill you manage with numbers, not a feeling you hope goes well.
:::

Let's do the arithmetic that governs every section.

:::example
Worked Example 2.1 — the raw per-question budget

easy

**Question.** A Logical Reasoning section has 35 minutes and about 25 questions. How much time do you get per question on average?

Answer: ~1 minute 24 seconds per question.

**How we get there.** Convert minutes to seconds so the division is clean: 35 minutes × 60 = **2100 seconds**. Divide by 25 questions: 2100 &divide; 25 = **84 seconds** per question. And 84 seconds = 60 + 24 = **1 minute 24 seconds**. So your *average* LR question gets about a minute and a half — and that average has to *absorb* the reading time, not just the choosing.
:::

:::example
Worked Example 2.2 — Reading Comp's hidden overhead

standard

**Question.** An RC section has 35 minutes, 4 passages, and about 27 questions. If you spend ~3.5 minutes reading each passage, how much time is left *per question*?

Answer: about 46 seconds per question.

**How we get there.** Step 1 — reading overhead: 4 passages × 3.5 min = **14 minutes** just reading, before answering anything. Step 2 — time left for questions: 35 − 14 = **21 minutes** = 21 × 60 = **1260 seconds**. Step 3 — divide by questions: 1260 &divide; 27 ≈ **46.7 seconds** per question.

**The teaching point.** RC feels tighter than LR because a big chunk of the clock is eaten by reading *before* you can answer. That's why *how* you read (for structure, fast — Chapter 15) matters so much: every extra 30 seconds per passage is 2 minutes stolen from answering. Pacing in RC is really about controlling reading time.
:::

:::callout-key
The pacing mindset

Averages are a budget, not a rule. Some questions take 40 seconds; some take three minutes. The skill is **spending your time where it earns points**: bank the fast ones, and when a question blows past ~2 minutes with no end in sight, **flag it, put down your best guess, and move on** (there's no penalty for a wrong answer, and a hard question is worth exactly as much as an easy one). You come back if time allows. Falling behind almost always traces to over-investing in one or two questions instead of moving.
:::

:::callout-pitfall
Watch out for these mistakes

- **Refusing to abandon a question.** Pride on one hard question can cost you three easy ones later. The clock doesn't care how close you were.
- **Leaving blanks.** No wrong-answer penalty means every blank is a wasted lottery ticket. With ~30 seconds left, fill in every remaining bubble with a single guess letter.
- **Ignoring reading overhead in RC.** Planning "46 seconds a question" without accounting for 14 minutes of reading leads to a time crunch on the last passage.
:::

### Practice — 2.3

:::problem[Q1]{difficulty="easy"}
A section has 35 minutes and 26 questions. What's the average time per question, to the nearest second?

::::solution[Solution]
35 × 60 = 2100 s; 2100 &divide; 26 ≈ **80.8 s ≈ 1 minute 21 seconds**. (The more questions packed into 35 minutes, the tighter each one gets.)
::::
:::

:::problem[Q2]{difficulty="standard"}
You've used 20 minutes and answered 12 of 25 LR questions. Are you on pace, and what should you do?

::::solution[Solution]
**Behind pace.** Twenty-five questions in 35 minutes is about 1.4 minutes each, so twelve of them should have taken about 16.8 minutes. You have spent 20. You're ~3 minutes behind with 13 questions left in 15 minutes (~69 s each). Response: **speed up, skip-and-flag anything sticky, and don't leave blanks**. Bank the easy remaining questions first.
::::
:::

:::problem[Q3]{difficulty="standard"}
In RC, why does spending an extra minute reading each passage hurt more than it looks?

::::solution[Solution]
Because it multiplies across **four passages**: one extra minute each is **4 minutes** gone from your answering time — out of only ~21 minutes for questions. Reading overhead is the biggest controllable variable in RC pacing, which is why efficient structural reading (Ch 15) is so valuable.
::::
:::

:::problem[Q4]{difficulty="challenge"}
With 90 seconds left in a section you have 4 questions unanswered and can realistically solve only 1. What's the point-maximizing move?

::::solution[Solution]
**First, immediately bubble a guess for all 4** (no penalty for wrong answers, so blanks are pure loss). *Then* spend the remaining ~80 seconds actually working the one question you can solve, and update that bubble if your worked answer differs from your guess. This guarantees you never leave points on the table to the clock. Order matters: guess-fill first, solve second.
::::
:::

## 2.4 · The online format & on-screen tools

:::callout-intuition
Intuition first

The LSAT is a **digital** test now — you take it on a computer, and as of 2026 it's typically delivered **online from your own home** with a live person watching through your webcam. That means two things you control: the *tools* built into the testing software, and the *environment* you test in. Both reward practice. The single biggest unforced error here is meeting the interface for the first time on test day — so you fumble the highlighter or panic at the tech check instead of answering questions.
:::

As of 2026 the LSAT is administered **online**: you test on your own computer, in a private room, monitored by a **live remote proctor** over webcam and screen-share. (LSAC has at times also offered in-person testing at designated centers for those who need it; confirm current options at registration.) You interact with LSAC's official digital testing platform, which provides a set of on-screen tools:

| Tool | What it does | Use it for |
| --- | --- | --- |
| Highlighter | Marks text in the stimulus/passage | Flagging conclusions, pivot words, key limits |
| Answer eliminator | Greys out a choice you've ruled out | Getting down to two choices cleanly |
| Flag for review | Bookmarks a question | Skip-and-return without losing the spot |
| Font / spacing controls | Adjusts text size and line spacing | Comfortable reading; reducing eye strain |
| Timer | Countdown for the section (can be hidden) | Pacing checks; hide it if it rattles you |

:::callout-key
The rule that saves points

**Do all your serious practice in the same official interface** — LSAC's LawHub (Chapter 24 and Appendix H). Fluency with the highlighter, eliminator, and flag should be automatic before test day so that *zero* of your mental energy goes to operating the software and *all* of it goes to the questions. Practicing only on paper and then testing on-screen is a self-inflicted disadvantage.
:::

You'll also complete an **onboarding / system check** before test day (and again just before you start): the software verifies your camera, connection, ID, and testing environment. Knowing your setup passes ahead of time removes a huge source of test-morning panic.

:::callout-pitfall
Watch out for these mistakes

- **First contact with the interface on test day.** Learn the tools weeks earlier; don't discover the eliminator exists during Section 1.
- **Skipping the tech/environment check.** A webcam or bandwidth problem found at 8:59 a.m. is a crisis; found a week early, it's a five-minute fix.
- **Ignoring the environment rules.** Remote proctoring has requirements (a private room, a clear desk, an approved ID, no notes unless permitted). Read them in advance so nothing gets your session flagged.
- **Letting the visible timer spike anxiety.** If the countdown rattles you, hide it and check it only at planned checkpoints.
:::

### Practice — 2.4

:::problem[Q1]{difficulty="easy"}
Why should you take your practice tests in LSAC's official digital interface rather than on paper?

::::solution[Solution]
So the tools (highlighter, eliminator, flag) and the on-screen reading experience are **automatic** on test day. Practicing in the real interface means none of your focus is spent operating unfamiliar software during the actual exam.
::::
:::

:::problem[Q2]{difficulty="standard"}
Which on-screen tool most directly supports the "get down to two choices, then decide" strategy?

::::solution[Solution]
The **answer eliminator** — it greys out choices you've ruled out, so you can visually narrow to the final two without re-reading dead options. (The flag tool supports skip-and-return; the highlighter supports active reading.)
::::
:::

:::problem[Q3]{difficulty="standard"}
It's the morning of the test and your webcam driver just failed. According to this chapter, what earlier step was supposed to prevent this crisis?

::::solution[Solution]
The **onboarding / system check** done well before test day. Running LSAC's tech and environment check ahead of time surfaces camera, connection, and setup problems while there's still time to fix them.
::::
:::

## 2.5 · Registration, test dates & retakes

:::callout-intuition
Intuition first

Two calendars secretly control your outcome: the LSAT's (when the test is offered and when scores release) and the law-school admissions calendar (which is **rolling** — schools read applications as they arrive and fill seats over the cycle). If your score lands too late, even a great number competes for fewer remaining seats and less scholarship money. So logistics aren't just paperwork — *when* you test can matter almost as much as *how well*.
:::

The LSAT is offered **many times a year** (roughly monthly, across multi-day administration windows). You register through your LSAC account, choosing a date and (for remote testing) a time slot. Key planning facts:

- **Score timing.** Scores are released a few weeks after your test date. Plan backward from application deadlines so your score arrives in time to apply *early*.
- **Apply early.** Because admissions is rolling, submitting in the fall generally beats submitting in the spring. Aim to have your final LSAT done early enough that your applications go in near the *start* of the cycle you're targeting.
- **Retakes are normal.** LSAC limits how often you may take the LSAT — over a rolling multi-year period and across your lifetime. The exact caps change, so **confirm them at lsac.org before planning multiple sittings.** Most schools see all your scores but base decisions on your **highest**, which makes a well-planned retake a common, legitimate strategy.
- **Register before you feel "ready."** A fixed date 3–4 months out is the best motivator for consistent study; you can usually push your date within limits if you truly need to. An open-ended timeline is how people study for years and never sit the test.

:::definition
**Definition 2.3 — Rolling admissions.** An application process in which a school evaluates candidates and offers seats *continuously* as applications arrive, rather than all at once after a single deadline. Consequence: identical applications can fare differently based on *timing* — earlier is generally better, because more seats and more scholarship money remain unallocated.
:::

:::callout-pitfall
Watch out for these mistakes

- **Testing too late in the cycle.** A strong score that arrives in spring competes for the seats and scholarships left after fall applicants have been admitted.
- **Never committing to a date.** Perpetual "I'll register when I'm ready" almost guarantees you never are. Book a realistic date to anchor your plan.
- **Assuming unlimited retakes.** There are caps. Plan your attempts; don't treat the test as infinitely repeatable.
- **Fearing that schools "average" scores.** Most focus on your *highest* — but verify each target school's policy, since a few weigh multiple scores differently.
:::

### Practice — 2.5

:::problem[Q1]{difficulty="standard"}
Why does "rolling admissions" mean you should apply — and therefore test — early in the cycle?

::::solution[Solution]
Because schools fill seats **continuously** as applications arrive. Apply late and you compete for fewer remaining seats and less leftover scholarship money, even with a strong file. Testing early lets your score arrive in time to apply near the cycle's start.
::::
:::

:::problem[Q2]{difficulty="easy"}
Most law schools base their decision on which of your LSAT scores?

::::solution[Solution]
Your **highest** score (though they typically can see all of them). This is why a planned retake is a normal, often worthwhile strategy — verify each school's policy to be safe.
::::
:::

:::problem[Q3]{difficulty="standard"}
A student says, "I'll register once my practice scores are consistently at my target." What's the risk, and the better approach?

::::solution[Solution]
**Risk:** an open-ended timeline removes the deadline that drives consistent study, so "ready" keeps receding. **Better:** register for a realistic date a few months out to anchor the plan; you can usually reschedule within limits if genuinely needed. A fixed target date is itself a study tool.
::::
:::

## 2.6 · Fees, the CAS & fee waivers

:::callout-intuition
Intuition first

Applying to law school costs money in a few distinct buckets, and they surprise people who budgeted only for "the test." Beyond the test fee itself, there's a service almost every school requires that packages your transcripts, letters, and scores — each with its own charge. The good news: if cost is a real barrier, LSAC has a **fee waiver** program, and you should apply for it *before* paying anything.
:::

The main costs in the LSAC ecosystem are:

- **The LSAT registration fee** — charged per test you sit.
- **The Credential Assembly Service (CAS)** — a subscription most ABA law schools *require*. It collects your undergraduate transcripts and letters of recommendation, standardizes them, and bundles them with your LSAT scores into a report sent to schools.
- **Per-school report fees** — a charge each time your CAS report is sent to a school you apply to.

:::definition
**Definition 2.4 — Credential Assembly Service (CAS).** LSAC's clearinghouse that assembles your transcripts, letters of recommendation, and LSAT scores into a single standardized report distributed to the law schools you apply to. Most ABA-accredited schools require applicants to use it, so budget for the CAS subscription *plus* a report fee per school.
:::

:::callout-key
If money is tight, do this first

Apply for an **LSAC fee waiver** *before* paying for anything. If you qualify, a waiver can cover test fees and bundle in benefits like official prep access and CAS/report allowances. Check current eligibility and what's included at [lsac.org](https://www.lsac.org). Don't pay full price and then discover you qualified.
:::

:::callout-pitfall
Watch out for these mistakes

- **Budgeting only for the test.** The CAS subscription and per-school report fees are separate and add up across many applications.
- **Paying before checking waiver eligibility.** Apply for the waiver first; you generally can't retroactively get back fees you've already paid.
- **Forgetting the CAS is usually mandatory.** For most ABA schools it isn't optional — factor it in from the start.
:::

### Practice — 2.6

:::problem[Q1]{difficulty="easy"}
What does the Credential Assembly Service (CAS) do?

::::solution[Solution]
It **assembles and standardizes your transcripts, letters of recommendation, and LSAT scores into one report** sent to the law schools you apply to. Most ABA schools require it.
::::
:::

:::problem[Q2]{difficulty="standard"}
A student on a tight budget is about to pay the LSAT registration fee. What should they do first, and why?

::::solution[Solution]
**Apply for an LSAC fee waiver first.** If they qualify, it can cover test fees and bundle in prep and CAS benefits — but paying first typically forfeits that help, since waivers aren't applied retroactively.
::::
:::

:::problem[Q3]{difficulty="standard"}
Name the three distinct cost buckets in the LSAC ecosystem beyond prep materials.

::::solution[Solution]
(1) the **LSAT registration fee** per sitting; (2) the **CAS subscription**; and (3) **per-school report fees** for sending your CAS report to each school. Budgeting for only the first is the common mistake.
::::
:::

## Chapter summary

:::summary
#### The essentials of Chapter 2

- **Four 35-minute sections; three count.** Two Logical Reasoning + one Reading Comp are scored (~75–77 questions); a 10-minute break follows section 2; the whole sitting is ~2h40m.
- **One section is experimental and unlabeled.** Treat every section as scored; train endurance for four sections, expect possibly three LR sections.
- **Pacing is arithmetic.** ~1:24 per LR question; RC is tighter (~46s/question) because reading eats ~14 minutes. Flag-and-guess past time-sinks; never leave blanks.
- **It's an online, proctored, digital test.** Master the highlighter/eliminator/flag in the official interface; pass the tech check early.
- **Timing and money are strategic.** Apply early into rolling admissions; retakes are normal (schools use your highest); budget for CAS + report fees; seek a fee waiver first if needed.
:::

| Item | Number to remember |
| --- | --- |
| Sections total / scored | 4 / 3 |
| Scored section mix | 2 Logical Reasoning + 1 Reading Comp |
| Time per section | 35 minutes |
| Break | 10 minutes, after section 2 |
| Avg. time / LR question | ~1 min 24 sec |
| Score scale | 120–180 (see Chapter 3) |

## Mixed practice set

Twelve items across the whole chapter, mixed order and difficulty. Attempt before revealing.

:::problem[1]{difficulty="easy"}
How long is each LSAT section, and how many are there?

::::solution[Solution]
**35 minutes each; four sections** (three scored, one experimental), plus a 10-minute break after the second.
::::
:::

:::problem[2]{difficulty="standard"}
A section has 35 minutes and 24 questions. Average time per question?

::::solution[Solution]
2100 s &divide; 24 = **87.5 s ≈ 1 min 28 sec**.
::::
:::

:::problem[3]{difficulty="standard"}
True or false: if a section feels unusually easy, it's safe to assume it's the experimental one and coast.

::::solution[Solution]
**False.** The experimental section is unidentifiable; assuming any section is fake risks throwing away a scored section. Full effort on all four, always.
::::
:::

:::problem[4]{difficulty="easy"}
Which three tools in the digital interface most directly aid test technique?

::::solution[Solution]
The **highlighter** (active reading), the **answer eliminator** (narrowing choices), and **flag for review** (skip-and-return). Master all three in the official interface before test day.
::::
:::

:::problem[5]{difficulty="standard"}
With 45 seconds left you have 3 blank questions and can solve maybe one. Best sequence of actions?

::::solution[Solution]
**Bubble a guess on all 3 immediately** (no wrong-answer penalty), then use the remaining time to actually solve the one you can, updating its bubble. Guess-fill first, solve second — never leave a blank.
::::
:::

:::problem[6]{difficulty="standard"}
Why is Reading Comp pacing tighter than Logical Reasoning pacing despite the same 35 minutes?

::::solution[Solution]
Because RC requires **reading four passages first** (~14 minutes of overhead), leaving only ~21 minutes to answer ~27 questions (~46 s each). LR has no comparable up-front reading block. Controlling reading time is the key RC pacing lever.
::::
:::

:::problem[7]{difficulty="challenge"}
A test-taker finishes and says, "I did two Reading Comp sections." What was their experimental section, and did it change how hard they should have worked?

::::solution[Solution]
Their experimental section was a **Reading Comp** one (only one RC is scored; seeing two means the extra was RC). It did *not* change their approach — since it's unlabeled, both RC sections had to get full effort. Only afterward is it evident which type was doubled.
::::
:::

:::problem[8]{difficulty="standard"}
Explain why testing in the spring of an admissions cycle can hurt even a strong applicant.

::::solution[Solution]
Because of **rolling admissions**: schools fill seats and allocate scholarships continuously as applications arrive. A spring score competes for whatever seats and money remain after fall applicants were admitted — so timing can blunt even an excellent file.
::::
:::

:::problem[9]{difficulty="easy"}
Most schools consider which LSAT score when you've taken it more than once?

::::solution[Solution]
Your **highest**. (They usually see all scores; verify individual school policies.)
::::
:::

:::problem[10]{difficulty="standard"}
A first-generation applicant with limited funds is planning to register and apply. What single step should come before any payment, and what might it cover?

::::solution[Solution]
Apply for an **LSAC fee waiver** first. If approved, it can cover test fees and bundle in benefits like official prep access and CAS/report allowances. Paying first typically forfeits this help.
::::
:::

:::problem[11]{difficulty="challenge"}
You've built your entire prep on paper PrepTests and feel fast. Why might your first *online* practice test score dip, and what does that tell you to do?

::::solution[Solution]
Because the **digital interface is unfamiliar** — scrolling passages, using the on-screen highlighter/eliminator, and reading on a screen all cost time and focus you hadn't trained. The lesson: shift your practice into LSAC's official interface (LawHub) so the tools are automatic, converting that lost overhead back into answering time before test day.
::::
:::

:::problem[12]{difficulty="challenge"}
In one or two sentences, explain why "logistics" deserves study time at all, given that it doesn't teach you any reasoning.

::::solution[Solution]
Because logistics silently converts into points and admissions outcomes: mis-pacing wastes a whole section, an unlabeled experimental section demands trained endurance, an unfamiliar interface bleeds time, and testing/applying late in a rolling cycle competes for fewer seats and dollars. Knowing the structure lets you avoid self-inflicted losses that no amount of reasoning skill can recover on test day.
::::
:::

LSAT Mastery — Chapter 2. Independent study material, not affiliated with LSAC. Logistics (dates, fees, retake limits, tools, delivery mode) change frequently — verify all specifics at lsac.org before registering or paying. Practice questions are original.
