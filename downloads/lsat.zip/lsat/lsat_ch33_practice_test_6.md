---
title: "Practice Test 6"
source: "markdown"
---

Part VI · Chapter 33

# Practice Test 6

An original, technology-centered LSAT practice test spanning patent strategy, engineering evidence, computing history, and platform economics.

## Overview

Take all three sections in one sitting: **35 minutes per section**, with a **10-minute break after Section II**. Use a timer. This chapter contains the three *scored* section types; the real LSAT also includes a fourth, unscored section that may appear anywhere (Chapter 2). For additional endurance work, add a separate experimental-style section when practicing.

**Do not open solutions until all three sections are complete.** Flag, don't guess silently: write down every question number on which you are uncertain, even when you ultimately choose an answer. A lucky guess can hide exactly what you need to study. After the timed attempt, complete **blind review** on all flagged questions without a clock (Chapter 22); only then inspect the key and log errors by cause (Chapter 23).

This is an **original educational test**, not an official LSAC PrepTest and not an equated test. Official PrepTests on LawHub remain the gold standard for timed scoring practice (Chapter 24). All companies, datasets, policies, contracts, studies, and disputes in the questions are fictional unless a passage explicitly identifies an established historical or technical fact.

## 33.1 Section I: Logical Reasoning

:::problem[Question I.1]
A device manufacturer says that because it received more patents last year than any competitor, it must have developed the most valuable inventions. Its spokesperson notes that independent examiners evaluated each application before issuance and that the company invests heavily in research. Several recently granted patents cover alternative designs of the same connector, and most have not yet appeared in products. The spokesperson nevertheless insists that no rival could have achieved greater inventive value with fewer patents.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that the company's competitors did not file patent applications in other countries.
- **(B)** fails to establish that the examiners who reviewed the patents were sufficiently trained.
- **(C)** treats the number of patents granted as establishing the comparative value of the inventions patented.
- **(D)** presumes that every employee who conducts research should be named as an inventor.
- **(E)** assumes that a patent can be commercially valuable only when it is licensed to another company.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The spokesperson concludes that the manufacturer created more valuable inventions than any rival.
2. **Support.** The evidence establishes a higher count of granted patents, but gives no measure of comparative invention value.
3. **Prephrase.** Look for a quantity-to-quality or wrong-measure leap, not a criticism of the patent office.
4. **Why (C) is right.** (C) isolates the unsupported bridge from how many patents exist to how much their inventions are worth; one extraordinarily valuable rival patent defeats the inference.
5. **Why the others fail.**
   - **(A)** *Different flaw:* Foreign filings might change global counts, but the fundamental mistake survives even with perfectly complete counts.
   - **(B)** *Different flaw:* Examiner competence is a tempting attack on grants, not on the separate claim that grant quantity equals value.
   - **(D)** *Too strong:* Inventor naming is a legal-procedure distraction and does not compare economic or technical value.
   - **(E)** *Different flaw:* The argument never makes licensing the exclusive source of value; this imports an unrelated requirement.

**Check:** Hold patent counts fixed and assign one rival invention far more value; the premises remain true and the conclusion false.
::::
:::

:::problem[Question I.2]
A manufacturer tested a new power-management firmware on half of its demonstration laptops and left the other half running the old version. Its engineer concludes that the firmware caused longer battery life because the updated laptops lasted an hour longer on average. The laptops were distributed to technicians at several sites, and each technician was allowed to choose which machine to test. The engineer acknowledges that the devices might have differed in age or workload, but believes the comparison is informative.

Which one of the following, if true, most strengthens the engineer's argument?

- **(A)** Before assignment, the laptops were matched for battery health and workload, then randomly allocated to firmware versions.
- **(B)** Technicians generally prefer firmware with easily understood menu settings.
- **(C)** The updated firmware has a smaller installation file than the old firmware.
- **(D)** Some laptops ran for more than a day on a single charge under light use.
- **(E)** The manufacturer plans to release the update after another round of testing.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer attributes the hour-long battery-life advantage to the firmware.
2. **Support.** Updated machines outlasted controls, but selection and preexisting condition can confound the comparison.
3. **Prephrase.** Remove the alternative explanation that healthier machines or easier work happened to receive the update.
4. **Why (A) is right.** (A) balances battery condition and workload and randomizes allocation, cutting off the most obvious confounding causes.
5. **Why the others fail.**
   - **(B)** *Wrong causal or evidentiary target:* Preferences for menus do not explain runtime differences in the experiment.
   - **(C)** *Wrong causal or evidentiary target:* File size is an attractive engineering detail but not evidence of power efficiency during use.
   - **(D)** *Wrong comparison:* A maximum runtime under light use lacks a controlled comparison to the old firmware.
   - **(E)** *Timing shift:* Planned testing describes a future decision, not evidence about the observed difference.

**Check:** With battery health and workload matched and assignment randomized, the causal comparison is substantially more credible.
::::
:::

:::problem[Question I.3]
A hospital buys imaging software from a small supplier. Under its contract, a copy of the source code will be released from escrow if the supplier permanently stops operating. The purchasing director argues that this arrangement guarantees that the hospital could keep using the software without interruption if the supplier closed. The director points out that hospital programmers already maintain several internal systems. But the contract concerns possession of code, and it says nothing about documentation, build tools, or whether the hospital's programmers can work with this particular application.

The director's argument depends on assuming which one of the following?

- **(A)** The hospital would be able to sell its own versions of the software to other hospitals.
- **(B)** No competitor of the supplier offers software with similar features.
- **(C)** Source-code escrow is less expensive than buying a perpetual software license.
- **(D)** The supplier will never voluntarily release the source code while operating.
- **(E)** Access to the escrowed code would not be useless to the hospital for maintaining the application.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The director concludes escrow guarantees continued operation after supplier closure.
2. **Support.** Escrow gives access to source code and the hospital has programmers, but useful maintenance capacity is unestablished.
3. **Prephrase.** The minimal necessary assumption is that the released code would be of some practical maintenance use.
4. **Why (E) is right.** Negating (E) makes the code entirely useless for maintenance, eliminating the director's proposed route to continuity.
5. **Why the others fail.**
   - **(A)** *Not required:* Resale rights are stronger than maintenance rights and irrelevant to internal operation.
   - **(B)** *Not required:* Competitors' offerings could exist without affecting the escrow-based plan.
   - **(C)** *Not required:* Comparative purchasing cost concerns economy, not operational continuity.
   - **(D)** *Too strong:* Release while operating is beside the closure scenario; the argument needs no such prohibition.

**Check:** Negate (E): the hospital cannot use the source for maintenance; escrow no longer supports the claimed guarantee.
::::
:::

:::problem[Question I.4]
At a fictional laboratory, every engineer permitted to inspect the unredacted chip drawings has completed security training. No contractor who lacks an employee sponsor can inspect those drawings. Some contractors have employee sponsors and completed training, but the laboratory has not said whether they were granted inspection access. Last month, one engineer inspected the unredacted drawings in connection with a thermal-design review. The laboratory does not require employees who see only a redacted summary to complete security training.

Which one of the following must be true?

- **(A)** Everyone who completes security training may inspect unredacted drawings.
- **(B)** At least one person who inspected unredacted drawings completed security training.
- **(C)** Some contractors who have employee sponsors inspected unredacted drawings.
- **(D)** Every employee who saw the redacted summary completed security training.
- **(E)** The engineer who inspected the drawings was an employee rather than a contractor.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** There is no argumentative conclusion; this is a set of permission rules and a reported instance.
2. **Support.** Every inspecting engineer is trained, and a particular engineer inspected the drawings.
3. **Prephrase.** Apply the universal rule to the observed engineer, without reversing conditional arrows.
4. **Why (B) is right.** (B) necessarily follows: the observed engineer is one trained inspector.
5. **Why the others fail.**
   - **(A)** *Unsupported inference:* Reversal trap: training is required for inspecting engineers, not a guarantee of inspection.
   - **(C)** *Unsupported inference:* Sponsored trained contractors may still have been denied access; possibility is not fact.
   - **(D)** *Too strong:* The exception for redacted summaries does not establish that all viewers were trained.
   - **(E)** *Unsupported inference:* The laboratory calls the inspector an engineer, not necessarily an employee under these rules.

**Check:** Inspected engineer → trained; an inspected engineer exists; therefore a trained inspector exists.
::::
:::

:::problem[Question I.5]
A large retailer adopted a security patch that eliminated a vulnerability repeatedly used to gain access to its inventory systems. Yet the month after installation, the retailer recorded twice as many security incidents as in the month before. Its executives were puzzled because the patch was independently tested and none of the later incidents exploited the repaired vulnerability. Both months involved a similar volume of transactions, and there was no indication that attackers had substantially changed their behavior.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Several rival retailers did not install the same patch.
- **(B)** The repaired vulnerability had been present in the system for several years.
- **(C)** Some incidents classified as severe are more expensive than others.
- **(D)** At the same time as the patch, the retailer installed monitoring software that detected many previously unrecorded minor incidents.
- **(E)** The patch was written by engineers who had worked on other successful security products.

::::solution[Solution]
**Answer:** (D)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The apparent conflict is between fixing a real vulnerability and a doubled count of recorded incidents.
2. **Support.** Testing supports the patch's efficacy, but the measured count depends on detection as well as actual incidents.
3. **Prephrase.** Find a change in recording or another independent category of incident.
4. **Why (D) is right.** (D) explains a recorded increase without alleging any failure of the vulnerability fix.
5. **Why the others fail.**
   - **(A)** *Too strong:* Rivals' installations cannot explain this retailer's within-firm time comparison.
   - **(B)** *Does not apply the governing rule or explanation:* The vulnerability's age is compatible with both an effective and ineffective patch.
   - **(C)** *Does not apply the governing rule or explanation:* Incident severity and cost do not account for doubled incident *counts*.
   - **(E)** *Timing shift:* Engineers' past success does not explain why more incidents were counted after the patch.

**Check:** More detected low-level incidents can raise the numerator even if exploitation of the patched flaw falls to zero.
::::
:::

:::problem[Question I.6]
Some managers want the company to buy a faster prototype printer because its current machine produces parts too slowly. But the design team spends far more time waiting for approvals than waiting for printed parts. Moving approvals to a parallel review process would reduce delays without purchasing equipment. The company should therefore redesign its approval process before buying another printer. Faster printing might still be useful later, but treating equipment speed as the chief present bottleneck would misdirect funds.

Which one of the following most accurately expresses the argument's main conclusion?

- **(A)** Approval delays are larger than delays caused by the present printer.
- **(B)** The company should change its approval process before purchasing a faster printer.
- **(C)** Buying a new printer may eventually improve the prototype team's performance.
- **(D)** A parallel approval process never requires spending money.
- **(E)** Managers often misidentify the main cause of delay in technical projects.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The central recommendation is to change approvals before buying equipment.
2. **Support.** Evidence about where waiting time occurs and an alternative workflow supports that ordering.
3. **Prephrase.** Select the advocated policy, not a supporting observation or concession.
4. **Why (B) is right.** (B) states exactly the action that the other claims are assembled to support.
5. **Why the others fail.**
   - **(A)** *Premise/conclusion or role swap:* This true comparison is a premise supporting the recommendation, not the recommendation itself.
   - **(C)** *Argument-structure mismatch:* This is an explicit concession about the future, not the current priority.
   - **(D)** *Too strong:* The argument says no equipment purchase is needed, not that changing process is costless.
   - **(E)** *Argument-structure mismatch:* It generalizes from one firm to managers everywhere, exceeding the stated conclusion.

**Check:** Ask 'therefore, what?' The sentence following 'should therefore' is (B).
::::
:::

:::problem[Question I.7]
A streaming-app founder argues that raising subscription prices will not significantly increase cancellations. During a pilot, members offered a higher-priced premium plan were less likely to cancel than members who stayed on the basic plan. The founder concludes that even a company-wide price increase would probably retain subscribers, since people who pay more appear to value the service more. The founder plans to use the pilot results to persuade investors that price sensitivity is minimal.

Which one of the following, if true, most seriously weakens the founder's reasoning?

- **(A)** Premium members used the app's download feature more often than basic members.
- **(B)** The proposed new price would still be below the price of some competing services.
- **(C)** Some customers were unaware that the company had conducted a pilot.
- **(D)** Participants chose whether to upgrade, and those already least likely to cancel disproportionately selected the premium plan.
- **(E)** The company has added more original programs since it began operating.

::::solution[Solution]
**Answer:** (D)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The founder predicts low churn after a mandatory company-wide increase.
2. **Support.** Voluntary premium subscribers churned less, but their preexisting preferences may differ systematically.
3. **Prephrase.** Expose selection bias: people who choose a higher price are not representative of people assigned one.
4. **Why (D) is right.** (D) supplies precisely that selection mechanism, undercutting the causal generalization.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* Higher feature use may reflect enthusiasm but does not address whether mandatory increases cause cancellation.
   - **(B)** *Wrong causal or evidentiary target:* Relative competitor pricing lacks evidence on this platform's subscribers' response.
   - **(C)** *Wrong causal or evidentiary target:* Awareness of the study is unrelated to why voluntary buyers cancel less.
   - **(E)** *Wrong comparison:* More content might affect retention, but no comparison links it to the pilot's selection problem.

**Check:** The premium cohort could have been unusually loyal even if a forced price increase caused many basic users to leave.
::::
:::

:::problem[Question I.8]
Under a fictional company's written policy, every device whose thermal shutdown fails during certification must be recalled. The audit report establishes that all units in the Orion series have a defective thermal sensor, but it does not expressly say that any shutdown failed during certification. A safety officer argues that all Orion units must be recalled under the policy. The officer says the defect has prompted numerous customer questions and that the manufacturer should not postpone a decision while it prepares a more detailed breakdown of the audit results.

Which one of the following, if assumed, enables the officer's conclusion to be properly drawn?

- **(A)** Every device with a defective thermal sensor fails thermal-shutdown certification.
- **(B)** Some devices that fail thermal-shutdown certification have defective sensors.
- **(C)** Most devices with defective sensors are recalled voluntarily.
- **(D)** Every device recalled by the company has a thermal sensor.
- **(E)** Some Orion units have been repaired before their owners received notices.

::::solution[Solution]
**Answer:** (A)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The officer concludes every Orion unit must be recalled.
2. **Support.** Orion → defective sensor; failed certification → mandatory recall; the bridge is missing.
3. **Prephrase.** Need defective sensor → failed certification, completing the chain.
4. **Why (A) is right.** (A) creates Orion → defective → fails certification → recalled for every unit, a sufficient bridge.
5. **Why the others fail.**
   - **(B)** *Reversal or direction trap:* This reverses and weakens the required bridge by identifying only some failed devices.
   - **(C)** *Insufficient bridge:* 'Most' and voluntary recalls cannot guarantee recall of every Orion unit under the stated rule.
   - **(D)** *Reversal or direction trap:* Recalled → sensor is the converse of what the proof needs.
   - **(E)** *Timing shift:* Repairs and notice timing do not connect defect to the policy's trigger.

**Check:** Write arrows: Orion → defective → failure → recall; only (A) supplies the middle arrow.
::::
:::

:::problem[Question I.9]
A cloud-service contract says that any provider qualifying for the premium reliability badge must maintain a specified level of audited uptime. Provider Mariner maintained that uptime last year. Its marketing team therefore announced that Mariner qualifies for the premium badge. When challenged, the team noted that uptime is the only numerical benchmark mentioned in the clause. But the contract also requires a separate independent security audit, which the team's announcement did not discuss.

The reasoning is flawed because it...

- **(A)** rejects a service contract solely because a competitor drafted it.
- **(B)** concludes from a sample of one server that all cloud services are reliable.
- **(C)** mistakes a necessary condition for earning the badge for a condition sufficient to earn it.
- **(D)** assumes that audited uptime can never be measured accurately.
- **(E)** reasons that fulfilling the security-audit requirement would make uptime irrelevant.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Marketing concludes Mariner qualifies for the badge.
2. **Support.** Premium status requires uptime; Mariner has uptime, but other requirements may remain.
3. **Prephrase.** Diagram badge → uptime; the argument improperly asserts uptime → badge.
4. **Why (C) is right.** (C) names affirming the consequent, the necessary/sufficient confusion from Chapters 5 and 6.
5. **Why the others fail.**
   - **(A)** *Different flaw:* No appeal to authorship appears in the reasoning.
   - **(B)** *Too strong:* It concerns a provider's eligibility, not a statistical generalization over providers.
   - **(D)** *Too strong:* The team treats measured uptime as reliable, not as impossible to measure.
   - **(E)** *Different flaw:* The argument omits security requirements; it does not say a security audit negates the uptime criterion.

**Check:** Badge → uptime does not license uptime → badge; separate audit may be absent.
::::
:::

:::problem[Question I.10]
The legal team warns that a proposed software component may impose obligations the company has not budgeted for. The engineering manager responds that the component's features could save months of development, and those savings deserve consideration. Nevertheless, before the company distributes a product containing the component, the legal team should examine the actual license terms. After all, the same technical functionality may be available under different licensing conditions, and the commercial advantage of a shortcut may disappear if compliance work is neglected.

The statement that the component's features could save months of development plays which one of the following roles?

- **(A)** It is the conclusion the argument principally seeks to establish.
- **(B)** It is evidence that all licensing conditions are commercially harmless.
- **(C)** It is a general rule governing how all components must be licensed.
- **(D)** It is a claim the author rejects as factually false.
- **(E)** It is a consideration conceded to favor adoption, but subordinated to the recommendation for license review.

::::solution[Solution]
**Answer:** (E)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The recommendation is to examine license terms before product distribution.
2. **Support.** Time savings favor the component, while potential obligations make review essential.
3. **Prephrase.** Identify the favorable concession the author acknowledges before defending a cautionary recommendation.
4. **Why (E) is right.** (E) captures that concession-and-response structure without turning the concession into the thesis.
5. **Why the others fail.**
   - **(A)** *Premise/conclusion or role swap:* The central conclusion concerns legal review, not development time.
   - **(B)** *Too strong:* Faster development does not demonstrate freedom from obligations.
   - **(C)** *Too strong:* A possible benefit is not a licensing rule.
   - **(D)** *Argument-structure mismatch:* The manager accepts the feature benefit and weighs it, rather than denying it.

**Check:** Replace the disputed sentence with 'even though it saves time'; the recommendation still remains license review.
::::
:::

:::problem[Question I.11]
A municipal technology office follows this policy: when public funds have paid for a software tool, and releasing its code would not expose confidential resident data, the office should make the code available for public inspection. A new scheduling tool was financed entirely by a city grant. An audit establishes that releasing the code would expose no confidential resident data, even though the running tool processes appointment information. The office is debating whether the scheduling tool's code should be published. Some officials worry that residents will not be interested in reading it.

Which one of the following judgments most closely conforms to the stated policy?

- **(A)** The code must remain private because the application processes appointments.
- **(B)** The code should be released only if a majority of residents request it.
- **(C)** Any code developed by city employees should be released even if publishing it exposes confidential data.
- **(D)** The office should make the code available for public inspection despite uncertainty about public interest.
- **(E)** The code should be sold exclusively to recover the city's original expenditure.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** There is a policy and an application rather than a disputed causal conclusion.
2. **Support.** Public funding and no confidential-data exposure trigger publication for inspection.
3. **Prephrase.** Apply both conditions and reject extra conditions about demand or revenue.
4. **Why (D) is right.** (D) follows the policy despite the irrelevant possibility that few residents will read the code.
5. **Why the others fail.**
   - **(A)** *Does not apply the governing rule or explanation:* Processing appointment data does not mean publishing code exposes confidential records.
   - **(B)** *Too strong:* Resident demand is not a condition in the given policy.
   - **(C)** *Does not apply the governing rule or explanation:* This ignores the explicit confidentiality exception.
   - **(E)** *Does not apply the governing rule or explanation:* Exclusive sale conflicts with making qualifying code publicly inspectable.

**Check:** Public funding = yes; exposure of confidential records = no; policy → publish.
::::
:::

:::problem[Question I.12]
An appliance maker compared repair records for two models over three years. Both had similar numbers of service requests. The model with removable circuit boards required fewer complete-unit replacements, but its average repair took longer because service centers stocked fewer compatible boards. The model with sealed electronics was repaired more quickly when a simple adjustment sufficed, yet more often required replacement when a component failed. The maker plans to keep collecting data before choosing a design for its next product.

Which one of the following is most strongly supported by the information above?

- **(A)** Modular construction always lowers the total cost of appliance ownership.
- **(B)** Sealed designs have a lower probability of component failure than modular designs.
- **(C)** A design associated with fewer unit replacements can nevertheless be associated with longer average repair times.
- **(D)** Service centers intentionally delayed repairs on the modular model.
- **(E)** The manufacturer should discontinue the sealed model immediately.

::::solution[Solution]
**Answer:** (C)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** No recommendation is established; this is comparative repair evidence.
2. **Support.** Modular units had fewer whole-unit replacements but longer repairs on average.
3. **Prephrase.** Identify the two reported outcomes without inferring causes beyond what is given.
4. **Why (C) is right.** (C) directly combines the observations without claiming universality.
5. **Why the others fail.**
   - **(A)** *Too strong:* Total ownership cost was not measured; fewer replacements need not mean lower overall costs.
   - **(B)** *Unsupported inference:* Similar request counts do not reveal intrinsic component failure probabilities by design.
   - **(D)** *Unsupported inference:* Stock shortages explain time differences without suggesting deliberate delay.
   - **(E)** *Unsupported inference:* A categorical recommendation exceeds the descriptive data and ignores trade-offs.

**Check:** Both properties in (C) are explicitly reported for the same model.
::::
:::

:::problem[Question I.13]
A technology firm plans to purchase a smaller company's patents. Its counsel argues that the purchase will reduce the number of lawsuits filed against the firm because competitors will fear countersuits alleging infringement of the acquired patents. The counsel emphasizes that competitors already have substantial products in the market, dislike costly litigation, and would take the possibility of a credible countersuit seriously. The company has not examined whether the patents cover any of those products.

The counsel's reasoning requires assuming which one of the following?

- **(A)** Every acquired patent is stronger than any patent the firm currently owns.
- **(B)** At least one likely prospective plaintiff could plausibly face an infringement claim under an acquired patent.
- **(C)** The acquiring firm will file a countersuit in every case brought against it.
- **(D)** The portfolio will guarantee that no court ever finds the firm liable.
- **(E)** All competitors have identical product designs and legal budgets.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Counsel concludes the purchase will deter some future lawsuits.
2. **Support.** Fear of countersuits supplies deterrence only if those suits are at least potentially credible against a relevant competitor.
3. **Prephrase.** A necessary assumption should preserve a possible target, not demand guaranteed litigation success.
4. **Why (B) is right.** If (B) is false, no likely plaintiff could plausibly face such a claim; the stated deterrence mechanism loses its foundation.
5. **Why the others fail.**
   - **(A)** *Too strong:* Comparative patent strength is unnecessary when even a weaker patent might be relevant.
   - **(C)** *Not required:* A credible possibility of countersuit can deter without a commitment to sue every time.
   - **(D)** *Too strong:* Guaranteed immunity from liability is far stronger than the proposal claims.
   - **(E)** *Not required:* Differing competitors can still share a reason to avoid potential countersuits.

**Check:** Negate (B): no likely plaintiff faces a plausible portfolio claim; the feared countersuit cannot explain reduced filings.
::::
:::

:::problem[Question I.14]
A purchasing officer argues that the laboratory must replace its measurement instruments because several are more than ten years old. A researcher replies that the relevant question is not age but whether the instruments meet the accuracy requirements of the projects they serve. She points to recent calibration checks showing that the older instruments still satisfy those requirements. She does not claim that new instruments are never worthwhile; she instead challenges the criterion being used to demand replacement in this particular laboratory.

The researcher's response proceeds primarily by...

- **(A)** conceding the officer's criterion but contesting which devices satisfy it.
- **(B)** using an analogy to argue that all technology becomes more accurate as it ages.
- **(C)** questioning the officer's personal motives for recommending replacements.
- **(D)** supplying a counterexample showing that every new instrument is inaccurate.
- **(E)** rejecting the relevance of the proposed decision criterion and offering performance evidence under a different criterion.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The researcher disputes replacing the instruments solely due to age.
2. **Support.** Calibration results meet accuracy requirements despite the instruments' age.
3. **Prephrase.** Look for a shift from age as a proxy to verified performance as the standard.
4. **Why (E) is right.** (E) describes both the attack on age and the substitute accuracy-based evidence.
5. **Why the others fail.**
   - **(A)** *Argument-structure mismatch:* She does not accept age as the relevant criterion.
   - **(B)** *Too strong:* No analogy or general aging-improves-accuracy claim appears.
   - **(C)** *Argument-structure mismatch:* She addresses the policy's reasoning, not the officer's motives.
   - **(D)** *Too strong:* She does not assert anything about the accuracy of every new instrument.

**Check:** Officer: age decides; researcher: project performance decides, and these devices pass.
::::
:::

:::problem[Question I.15]
A startup emails a product questionnaire to every person who signed up for its device preorder list. Only one in ten recipients replies, and almost all respondents say they would pay extra for an extended warranty. The startup concludes that almost all preorder customers will buy the warranty at launch. The marketing director acknowledges the low response rate but argues that the survey was sent to everyone and therefore accurately represents the whole customer population.

The startup's argument is most vulnerable to criticism because it...

- **(A)** assumes that respondents' preferences represent those of nonrespondents merely because everyone was invited.
- **(B)** infers that customers will refuse warranties because most did not reply.
- **(C)** confuses the warranty's actual purchase price with the device's production cost.
- **(D)** treats the results of repeated random trials as if each trial were independent.
- **(E)** claims that customers who want warranties are less likely to purchase devices.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The startup predicts near-universal warranty purchases among preorder customers.
2. **Support.** A self-selected ten-percent response sample favors purchase; nonrespondent preferences are unknown.
3. **Prephrase.** Identify sampling bias despite a complete invitation list.
4. **Why (A) is right.** (A) points to the unrepresentative-survey inference: contact coverage does not erase response selection.
5. **Why the others fail.**
   - **(B)** *Different flaw:* The startup predicts purchases, not refusals; the premise is nonresponse, not stated rejection.
   - **(C)** *Wrong comparison:* No cost-price comparison supports or appears in the argument.
   - **(D)** *Different flaw:* There are no described randomized repeated trials; the data are a response survey.
   - **(E)** *Reversal or direction trap:* This reverses the startup's assertion about enthusiastic purchasers.

**Check:** Nonrespondents could unanimously reject the warranty while all the reported survey results remain true.
::::
:::

:::problem[Question I.16]
At a fictional research institute, every project classified as restricted must receive legal review. Every project that receives legal review requires a signed access log. Project Cedar is classified as restricted. Therefore Project Cedar requires a signed access log. The administrator notes that many unrestricted projects also have access logs, but those extra instances do not affect the conclusion. The chain runs only forward from restricted status through mandatory review to the log requirement.

Which one of the following arguments is most similar in its reasoning?

- **(A)** Every inspected batch is recorded; every recorded batch gets an identifier; batch T was inspected; therefore batch T gets an identifier.
- **(B)** Every licensed pilot has passed training; Mira passed training; therefore Mira is a licensed pilot.
- **(C)** Some sealed boxes are insured; all insured boxes are cataloged; therefore all sealed boxes are cataloged.
- **(D)** Every audited vendor is documented; vendor R is documented; therefore vendor R was audited.
- **(E)** Some prototypes are tested; every tested prototype has a report; therefore no untested prototype has a report.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** A particular restricted project must have a log.
2. **Support.** Restricted → legal review → signed log; Cedar is restricted.
3. **Prephrase.** Match a two-link universal conditional chain applied to a known member.
4. **Why (A) is right.** (A) follows inspected → recorded → identified, with an inspected batch, exactly the same valid form.
5. **Why the others fail.**
   - **(B)** *Too strong:* It affirms the consequent: training need not imply licensing.
   - **(C)** *Quantifier shift:* It incorrectly expands 'some' sealed boxes to all sealed boxes.
   - **(D)** *Reversal or direction trap:* It reverses audited → documented.
   - **(E)** *Too strong:* Tested → report says nothing about whether untested prototypes also have reports.

**Check:** Both original and (A) have X → Y → Z plus X, therefore Z.
::::
:::

:::problem[Question I.17]
A transportation company installed a machine-learning tool that schedules vehicle maintenance. The following quarter, repair spending dropped by fifteen percent. Its chief operating officer concluded that the tool caused the reduction and recommended selling it to other fleets. The officer noted that the tool had accurately flagged several damaged components. However, the spending figure combines repairs for many categories of vehicles, and the company made other operational changes during the quarter.

Which one of the following, if true, most seriously weakens the officer's conclusion about the cause of the savings?

- **(A)** The tool requires employees to learn a new reporting interface.
- **(B)** Several of the flagged damaged components would have been found during ordinary inspections.
- **(C)** Some other fleets operate vehicles made by the same manufacturers.
- **(D)** The tool was developed using historical maintenance records.
- **(E)** The company sold its oldest, most repair-intensive vehicles just before the quarter began.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The officer credits the tool for a company-wide spending decline.
2. **Support.** Spending fell after adoption, but different fleet composition could independently lower total repairs.
3. **Prephrase.** Seek a contemporaneous alternative cause large enough to explain the savings.
4. **Why (E) is right.** (E) supplies a concrete alternative: removing high-cost vehicles reduces spending even if the tool has no effect.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* Training costs could matter to net value, but do not explain why recorded *repair* spending declined.
   - **(B)** *Wrong causal or evidentiary target:* Redundant flags limit incremental benefit yet do not account for the full spending drop as directly as fleet turnover.
   - **(C)** *Timing shift:* Potential customer similarity does not test the origin of past savings.
   - **(D)** *Wrong causal or evidentiary target:* Historical training is a normal design feature, not evidence of an alternative spending cause.

**Check:** Compare identical fleets over time; (E) shows the fleets were not identical.
::::
:::

:::problem[Question I.18]
An engineering director wants to require two reviewers for high-risk code changes. In one division, such changes were followed by fewer security-related defects after the second-review requirement began. Critics say the improvement might reflect a simultaneous reduction in the complexity of the projects. The director responds that reviews often catch overlooked assumptions about access privileges, and she thinks the second reviewer contributed substantially to the decline. The division's reports summarize defect counts but do not establish why those counts changed.

Which one of the following, if true, most strengthens the director's explanation?

- **(A)** The developers describe the new process as slightly slower than the old one.
- **(B)** The division had historically used informal comments to discuss code.
- **(C)** The average complexity of high-risk changes remained stable, while review records show second reviewers found defects that first reviewers missed.
- **(D)** Some projects require more than one programming language.
- **(E)** A different division uses the same version-control software without requiring two reviewers.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The director credits the second review for reduced defects.
2. **Support.** The timing supports a causal claim, but a fall in project complexity is a possible rival explanation.
3. **Prephrase.** Eliminate the complexity confound and link second reviewers to real catches.
4. **Why (C) is right.** (C) does both and supplies a specific mechanism through findings missed by the first reviewer.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* A speed cost affects the policy trade-off, not its effect on defect detection.
   - **(B)** *Timing shift:* Past comment practices are background and cannot explain the observed causal difference.
   - **(D)** *Wrong causal or evidentiary target:* Language count need not correlate with defect changes or reviewer contribution.
   - **(E)** *Wrong comparison:* Another division's tooling is not a controlled comparison of second-review outcomes.

**Check:** Stable complexity plus unique second-review catches strongly favors the director's mechanism.
::::
:::

:::problem[Question I.19]
Nia: A university should offer a reduced licensing fee to small companies only when they provide researchers with useful technical feedback. The feedback can speed improvements, although the university must still recover its direct administrative costs. Omar: Feedback is valuable, but discounts that leave administrative costs uncovered should never be granted. A reduced fee is acceptable whenever it still covers those costs, even if the licensee never shares technical feedback. The two administrators are advising the same university on a proposed licensing policy.

Nia and Omar most clearly disagree over whether...

- **(A)** researchers can benefit from feedback received from small companies.
- **(B)** licenses should always be issued without any administrative fee.
- **(C)** granting a discount can be acceptable when it still covers administrative costs.
- **(D)** useful technical feedback is necessary to justify a reduced licensing fee.
- **(E)** campus inventions can ever be licensed to private companies.

::::solution[Solution]
**Answer:** (D)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Each speaker gives a licensing criterion rather than a single shared conclusion.
2. **Support.** Nia conditions discounts on useful feedback; Omar explicitly permits a discount without feedback if costs are covered.
3. **Prephrase.** Find a yes/no proposition on which both positions are determinate and opposite.
4. **Why (D) is right.** (D) is yes for Nia's proposed policy and no for Omar's; both have a stake in the exact criterion.
5. **Why the others fail.**
   - **(A)** *Argument-structure mismatch:* Both explicitly value feedback, so this is agreement rather than disagreement.
   - **(B)** *Argument-structure mismatch:* Both preserve cost coverage, so neither endorses zero administrative recovery.
   - **(C)** *Argument-structure mismatch:* Both can permit a cost-covering discount if feedback also exists; it is not their contested necessity.
   - **(E)** *Argument-structure mismatch:* Both contemplate licensing to companies, rejecting the alleged disagreement.

**Check:** Feedback required? Nia yes; Omar no. Cost coverage required? Both yes.
::::
:::

:::problem[Question I.20]
A technical committee must decide which file format to recommend for archival storage. One member argues that Format V is the best long-term choice because it is currently the most frequently downloaded option among customers. The committee has separately identified durability, compatibility, and the ease of recovering files decades later as its decision criteria. The member responds that the most popular file format benefits from a wide user community and insists that choosing the format attracting the largest present audience cannot be the wrong choice for a long-lived archive.

The member's argument is flawed because it...

- **(A)** assumes that a format's source code is legally available to everyone.
- **(B)** treats current popularity as sufficient evidence of suitability under distinct long-term criteria.
- **(C)** concludes that download counts are impossible to manipulate.
- **(D)** uses a carefully chosen historical analogy where no analogy would be appropriate.
- **(E)** makes the recommendation conditional on the format becoming less popular.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The member concludes Format V is the best long-term archive format.
2. **Support.** Present downloads are offered in place of evidence on durability, compatibility, and recoverability.
3. **Prephrase.** Identify an appeal to popularity combined with a mismatch between measurement and objective.
4. **Why (B) is right.** (B) names precisely the unsupported use of popularity as a proxy for the committee's actual criteria.
5. **Why the others fail.**
   - **(A)** *Different flaw:* No claim about legal source-code availability appears.
   - **(C)** *Different flaw:* Accuracy of download numbers is not challenged; even accurate numbers prove little about archival durability.
   - **(D)** *Different flaw:* No prior historical episode is used as an analogy.
   - **(E)** *Timing shift:* The argument relies on popularity now and predicts suitability, not on a future decline.

**Check:** The most downloaded format could have poor long-term recoverability without contradiction.
::::
:::

:::problem[Question I.21]
A social network proposes replacing human first-pass content review with an automated classifier. Its operations lead argues that the change will reduce unfair removals because the classifier disagrees with human reviewers in fewer cases than reviewers disagree with each other. The network's policy defines an unfair removal as taking down content that should remain under its written rules. The operations lead adds that a decision process that behaves consistently from one case to another will be easier for users to understand and for moderators to defend.

Which one of the following questions would be most useful to answer in evaluating the lead's argument?

- **(A)** Will the automated system process reports faster than the human team?
- **(B)** Does the classifier require less electrical energy than the existing servers?
- **(C)** Do users prefer to receive removal notices by email or in the app?
- **(D)** Can all of the network's reviewers explain why some rules are controversial?
- **(E)** When judged against the written policy by an independent audit, does the classifier make fewer wrongful removals than the humans it would replace?

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The lead predicts fewer *unfair* removals under automation.
2. **Support.** Lower disagreement is evidence of consistency, not necessarily policy correctness.
3. **Prephrase.** Ask which system has the lower false-removal rate measured against the operative standard.
4. **Why (E) is right.** (E) directly compares policy errors; a yes strengthens and a no weakens the claim.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* Speed tests efficiency, a different proposed benefit from fairness.
   - **(B)** *Wrong causal or evidentiary target:* Electricity use may influence cost but does not measure wrongful removals.
   - **(C)** *Wrong causal or evidentiary target:* Notification channel is downstream of the correctness of removal decisions.
   - **(D)** *Too strong:* Knowledge of controversies is not a direct comparative error rate under the stated policy.

**Check:** Consistently wrong is possible; independent policy-based accuracy is the missing variable.
::::
:::

:::problem[Question I.22]
A compliance manager says that every engineer authorized to sign a release certificate has completed the company's safety course. Researcher Lian completed that course yesterday. The manager therefore announces that Lian is now authorized to sign release certificates. Elsewhere in the company, authorization also requires supervisory approval, but the manager's inference rests only on the training record. The statement is not about whether Lian would be good at the job; it is about whether an established prerequisite proves formal authorization.

Which one of the following arguments exhibits the same flaw?

- **(A)** Every accepted supplier passed inspection; supplier K did not pass inspection; therefore supplier K was not accepted.
- **(B)** All approved visitors possess a badge; Sel has a badge; therefore Sel is an approved visitor.
- **(C)** Every registered vehicle has a plate; vehicle Q has no plate; therefore vehicle Q is not registered.
- **(D)** All accredited labs are audited; lab Z is accredited; therefore lab Z is audited.
- **(E)** If a proposal is urgent, it gets fast review; this proposal is urgent; therefore it gets fast review.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The manager concludes Lian is formally authorized.
2. **Support.** Authorization → training; Lian trained; manager reverses the implication.
3. **Prephrase.** Find affirming the consequent in a different context.
4. **Why (B) is right.** (B) mistakes a necessary badge for proof of visitor approval, matching authorized → trained; trained → authorized.
5. **Why the others fail.**
   - **(A)** *Reversal or direction trap:* This is valid modus tollens, not a reversal error.
   - **(C)** *Reversal or direction trap:* This also uses valid modus tollens, since registration requires a plate.
   - **(D)** *Different flaw:* This is valid modus ponens from accreditation to audit.
   - **(E)** *Different flaw:* This is valid modus ponens from urgency to fast review.

**Check:** Original and (B) have P → Q, Q, therefore P, an invalid converse inference.
::::
:::

:::problem[Question I.23]
A startup executive argues that showing a working prototype at a public trade fair before consulting patent counsel cannot create any intellectual-property risk, since the engineering team has kept the underlying source code private. The executive plans to display what the device does and how its components are arranged, though not to distribute schematics. The argument assumes that concealing code eliminates all potentially important public disclosure. Whether that is sensible depends on what a demonstration can reveal apart from code.

Which one of the following is an assumption on which the executive's reasoning depends?

- **(A)** The startup will eventually sell more devices than its competitors.
- **(B)** Every patent application must include the device's entire source-code repository.
- **(C)** The trade fair's visitors will include many potential customers.
- **(D)** The planned public display will not reveal any potentially consequential information apart from the concealed source code.
- **(E)** A public trade fair is always cheaper than a private investor meeting.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The executive concludes the display poses no IP disclosure risk because the code is private.
2. **Support.** A public demonstration may reveal structure or function even without exposing code.
3. **Prephrase.** The necessary bridge is that everything potentially risky remains concealed, not just the source.
4. **Why (D) is right.** Negating (D) permits consequential technical information to be disclosed publicly, destroying the executive's 'no risk because code hidden' inference.
5. **Why the others fail.**
   - **(A)** *Timing shift:* Future sales do not govern whether disclosure carries a patent risk.
   - **(B)** *Not required:* Patent-application contents are unrelated to what the public presentation reveals.
   - **(C)** *Not required:* Audience size may affect commercial exposure but is not required for a disclosure concern.
   - **(E)** *Not required:* Event cost is immaterial to information disclosure.

**Check:** A visible device architecture could be consequential even while all code stays secret.
::::
:::

:::problem[Question I.24]
An electronics firm doubled the bonus awarded to engineers when a patent application was filed. Applications increased sharply the next year, and management concluded that the new bonus inspired employees to devise more inventions. The company also hired a patent administrator who streamlined internal filing procedures. Management insists that because the increase followed the bonus, the bonus must be the chief reason for the rise in inventive activity, rather than merely a change in how existing ideas were documented.

Which one of the following, if true, most weakens management's conclusion?

- **(A)** Most of the additional applications concerned ideas recorded in laboratory notebooks before the bonus change, but not previously submitted for filing.
- **(B)** Many employees appreciated receiving written recognition for completed applications.
- **(C)** The bonus was paid only after the patent administrator certified a filing.
- **(D)** Several patents from earlier years generated licensing income.
- **(E)** The company made no change to the engineering division's vacation policy.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Management concludes the bonus caused more inventions, not merely more recorded filings.
2. **Support.** Application counts rose after the bonus, while administrative processing also changed.
3. **Prephrase.** Distinguish the creation date of ideas from the filing date of applications.
4. **Why (A) is right.** (A) shows most extra filings came from preexisting ideas, directly breaking the inference to new inventiveness.
5. **Why the others fail.**
   - **(B)** *Wrong causal or evidentiary target:* Appreciation may explain motivation but cannot distinguish new invention from delayed filing.
   - **(C)** *Wrong causal or evidentiary target:* Certification is procedural and consistent with both new and old ideas.
   - **(D)** *Timing shift:* Past licensing revenue does not date the ideas in the additional applications.
   - **(E)** *Wrong causal or evidentiary target:* Unchanged vacation policy rules out one weak alternative but does not address the filing backlog.

**Check:** Applications up need not mean inventions newly conceived up.
::::
:::

:::problem[Question I.25]
A product review board adopts the following rule: a foreseeable risk that can be materially reduced by an inexpensive engineering change should be reduced before launch, even if the product's expected profits would be higher without the change. A firm is preparing a wearable device. Testing indicates that a minor redesign would substantially lower a foreseeable skin-irritation risk at little cost. Executives nevertheless want to ship unchanged because the launch is tied to an advertising campaign and a delay could reduce quarterly earnings.

Which one of the following actions is most strongly justified by the board's principle?

- **(A)** Launch unchanged, because earnings always outweigh low-probability harms.
- **(B)** Cancel the product permanently, even if the redesign would address the risk.
- **(C)** Implement the inexpensive redesign before launch, even if doing so reduces expected profit.
- **(D)** Delay redesign until evidence proves that every customer would experience irritation.
- **(E)** Require that all future devices have identical materials regardless of function.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The rule sets a priority for avoidable foreseeable harm over the incremental expected profit.
2. **Support.** The wearable has a foreseeable risk and a cheap change that materially reduces it.
3. **Prephrase.** Match the rule's two triggers and required action without demanding zero risk.
4. **Why (C) is right.** (C) directly implements risk reduction before shipping despite the profit trade-off.
5. **Why the others fail.**
   - **(A)** *Reversal or direction trap:* It reverses the priority expressly stated by the principle.
   - **(B)** *Does not apply the governing rule or explanation:* The rule calls for mitigation, not automatic cancellation.
   - **(D)** *Too strong:* The standard is foreseeable risk, not proof of harm to every customer.
   - **(E)** *Too strong:* Standardizing all materials is broader than any case-specific inexpensive risk reduction.

**Check:** Risk foreseeable + cheap material reduction → make change before launch.
::::
:::


## 33.2 Section II: Reading Comprehension

### Passage 1

A memory chip stores bits by representing one of two states in many tiny physical devices. Yet no physical device is perfectly immune to disturbances. Electrical noise, manufacturing variation, and energetic particles can sometimes change a stored bit. A straightforward response is to make storage more reliable through the hardware itself. Another is to store extra information so a receiver can detect, and sometimes correct, a mistake after it occurs. The second strategy is the foundation of error-correcting codes. Its attraction is not that disturbances cease to happen, but that their consequences may be managed.

Consider a simplified code whose valid messages are represented by groups of bits called *codewords*. A code is designed so that legitimate codewords differ from one another in several positions. The minimum number of differing bit positions between any pair of valid codewords is the code's *minimum Hamming distance*. If this minimum is sufficiently large, a small number of accidental bit changes will leave the received pattern closer to its original codeword than to any other valid one. For a code with minimum distance three, for example, any single-bit error can be corrected under the usual nearest-codeword decoding rule. The extra bits allow the receiver to distinguish possibilities that would be indistinguishable if only the original data bits were stored.

This protection carries costs. Redundant bits consume storage capacity and energy; the circuits that compute or interpret them also require resources. Moreover, the correction guarantee applies only within the code's specified error limit. If a received word has undergone too many changes, a decoder may be unable to recover the intended message or may even choose the wrong one. Thus a claim that a device has “error-correcting memory” is incomplete unless one also knows which errors its scheme can handle and what kinds of failures are expected.

A fictional engineering team is choosing between two memory designs for a spacecraft instrument. Design R uses a stronger code and therefore stores fewer payload bits in a fixed amount of physical memory. Design S leaves more capacity available for measurements but corrects fewer kinds of corruption. In simulated tests with isolated one-bit errors, both designs recover nearly all intended readings. In a second simulation involving clustered errors, R performs appreciably better. The team initially treats the first simulation as proof that S is equally dependable. But equal success under a narrow test distribution does not establish equal performance under the disturbances the instrument will actually experience.

The appropriate choice therefore depends on a prediction as well as a coding theorem: how frequently will different error patterns arise, and what is the cost of losing a measurement? Stronger correction need not be preferable in every application. It is the match between the code's capabilities and the environment's likely faults, rather than the mere presence of redundant bits, that makes an error-control design responsible.

:::problem[Question II.1]


Which one of the following most accurately expresses the main point of the passage?

- **(A)** Any memory system using error-correcting codes will be superior to a system without them.
- **(B)** Choosing error correction responsibly requires matching a code's error-handling abilities to likely faults and application costs.
- **(C)** A code with minimum Hamming distance three can correct every possible corruption pattern.
- **(D)** Extra storage capacity is always more valuable than correction against clustered errors.
- **(E)** Hardware reliability matters only when error correction is unavailable.

::::solution[Solution]
**Answer:** (B)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author's thesis concerns fit between an error-control design and its operating environment.
2. **Support.** The passage explains the mechanism, its costs and limits, and a fictional comparison showing why a narrow test misleads.
3. **Prephrase.** Seek the moderate all-passage claim, not an unqualified recommendation for strong codes.
4. **Why (B) is right.** (B) covers the design trade-off and the need to predict relevant faults.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* 'Any' and 'superior' overshoot the explicit discussion of redundancy costs.
   - **(C)** *Too strong:* Distance three protects against single-bit errors, not every possible pattern.
   - **(D)** *Reversal or direction trap:* This reverses the author's caution that capacity and reliability must be balanced.
   - **(E)** *Too strong:* The passage presents coding and hardware reliability as alternative or complementary responses, not exclusive domains.

**Check:** Paragraphs one through five move from mechanism to limits to application-dependent choice.
::::
:::

:::problem[Question II.2]


According to the passage, a code with minimum Hamming distance three has which one of the following properties?

- **(A)** It needs exactly three redundant bits for each data bit.
- **(B)** It can repair any combination of three changed bits.
- **(C)** Its codewords always differ in exactly three positions.
- **(D)** It can correct any single-bit error under the described nearest-codeword rule.
- **(E)** It prevents physical disturbances from changing bits.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** This is a retrieval question about the code-distance explanation.
2. **Support.** The second paragraph states the single-bit correction property explicitly.
3. **Prephrase.** Match the precise error count and decoding qualification.
4. **Why (D) is right.** (D) faithfully paraphrases the given distance-three example.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* Minimum distance does not specify a fixed data-to-redundancy ratio.
   - **(B)** *Scope or text mismatch:* The number three is a minimum separation, not a three-error correction guarantee.
   - **(C)** *Quantifier shift:* 'Minimum' means some pair attains that distance; other pairs may differ at more positions.
   - **(E)** *Scope or text mismatch:* The code repairs consequences; it does not stop disturbances.

**Check:** Return to paragraph two: 'any single-bit error can be corrected' under nearest-codeword decoding.
::::
:::

:::problem[Question II.3]


It can most reasonably be inferred from the fictional spacecraft simulations that...

- **(A)** success on the isolated-error simulation alone would be insufficient to establish equal performance against clustered errors.
- **(B)** Design S failed every simulated test involving clustered errors.
- **(C)** Design R always produces more payload capacity than Design S.
- **(D)** both designs would perform identically under actual space conditions.
- **(E)** the researchers had independently established the exact distribution of future space disturbances.

::::solution[Solution]
**Answer:** (A)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The relevant inference concerns the limited reach of a narrow performance comparison.
2. **Support.** Both designs did well with isolated errors, whereas R performed better with clustered ones.
3. **Prephrase.** Combine the two stated tests without inventing failure rates or actual mission conditions.
4. **Why (A) is right.** (A) follows because the second simulation separates designs that the first did not.
5. **Why the others fail.**
   - **(B)** *Too strong:* 'Performed appreciably better' does not say S failed every clustered-error test.
   - **(C)** *Unsupported inference:* R expressly stores fewer payload bits in fixed memory.
   - **(D)** *Unsupported inference:* The author warns against predicting actual conditions from an incomplete test.
   - **(E)** *Timing shift:* The team is urged to predict error distributions; no exact future distribution was established.

**Check:** Equal in test 1; different in test 2; test 1 cannot prove equality across error types.
::::
:::

:::problem[Question II.4]


The author's discussion of Designs R and S primarily serves to...

- **(A)** establish that real spacecraft employ one particular patented code.
- **(B)** show that extra bits always reduce the chance of every error to zero.
- **(C)** challenge the correctness of the mathematical definition of minimum Hamming distance.
- **(D)** demonstrate that simulation results cannot inform any engineering decision.
- **(E)** illustrate how two designs can look equivalent under one test but differ under another relevant error pattern.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The fictional illustration supports the author's environment-dependent decision thesis.
2. **Support.** The two simulations produce similar and divergent outcomes under different disturbances.
3. **Prephrase.** Identify the logical lesson drawn from the comparison, not a technical universal.
4. **Why (E) is right.** (E) states the contrast and its argumentative function accurately.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The scenario is identified as fictional and gives no real patent adoption evidence.
   - **(B)** *Scope or text mismatch:* The author emphasizes limits rather than infallible protection.
   - **(C)** *Scope or text mismatch:* The mathematical definition is used as background, not disputed.
   - **(D)** *Scope or text mismatch:* The text favors targeted simulations, not rejection of simulation altogether.

**Check:** The author says equal success under a narrow distribution does not prove equal real-world dependability.
::::
:::

:::problem[Question II.5]


Which one of the following is most strongly supported by the passage?

- **(A)** Increasing redundancy always reduces a device's total energy use.
- **(B)** Correction algorithms are relevant only to space instruments.
- **(C)** A more powerful code may be a poor overall choice if its added costs exceed the value of the errors it prevents.
- **(D)** An uncorrectable error proves that the hardware contained no redundant bits.
- **(E)** The strongest available code must be selected whenever measurements matter.

::::solution[Solution]
**Answer:** (C)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author evaluates correction as a trade-off rather than a categorical good.
2. **Support.** Redundancy uses resources, and the benefit depends on expected faults and losses.
3. **Prephrase.** Infer a conditional counterexample to the claim that stronger is always better.
4. **Why (C) is right.** (C) fits the expressed cost-benefit framework without claiming an exact numeric threshold.
5. **Why the others fail.**
   - **(A)** *Too strong:* The passage states redundancy consumes energy, not that more always saves it.
   - **(B)** *Unsupported inference:* Spacecraft are an illustration; the opening discusses memory generally.
   - **(D)** *Unsupported inference:* Uncorrectable errors can occur when a redundant code's correction limit is exceeded.
   - **(E)** *Too strong:* The passage expressly rejects a universal preference for stronger correction.

**Check:** Marginal resources matter: a code may add cost without preventing likely losses.
::::
:::

:::problem[Question II.6]


Which one of the following situations is most analogous to the author's recommended approach to error correction?

- **(A)** A contractor chooses the most expensive protective material, assuming price alone measures safety.
- **(B)** An engineer selects a filtration system after identifying the kinds of contaminants expected and the cost of letting each through.
- **(C)** A manager chooses a battery based solely on its advertised maximum voltage.
- **(D)** A laboratory refuses to test any protective system because no test reproduces all future conditions.
- **(E)** A designer uses the same redundancy setting on every product regardless of failure risk.

::::solution[Solution]
**Answer:** (B)

**Type:** RC analogy (Chapter 18)

1. **Conclusion.** The principle is to match a protective mechanism to likely threats and their costs.
2. **Support.** The author contrasts isolated and clustered errors and notes redundancy trade-offs.
3. **Prephrase.** Find threat-specific protection with an explicit consequence assessment.
4. **Why (B) is right.** (B) mirrors both the prediction of failure type and cost-sensitive choice of mitigation.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* Price-as-quality repeats the simplistic strongest-is-best mistake.
   - **(C)** *Scope or text mismatch:* A single headline specification ignores the distribution of relevant operating requirements.
   - **(D)** *Too strong:* Imperfect foresight does not make targeted tests worthless in the passage.
   - **(E)** *Scope or text mismatch:* Uniform settings ignore differences among applications, precisely what the author rejects.

**Check:** Contaminants correspond to fault patterns; filtration corresponds to coding; losses correspond to measurement costs.
::::
:::

:::problem[Question II.7]


The author's attitude toward stronger error-correcting codes is best described as...

- **(A)** dismissive because their mathematical properties are unreliable.
- **(B)** enthusiastic without regard to implementation costs.
- **(C)** skeptical that any coding scheme can correct a changed bit.
- **(D)** appreciative of their benefits but attentive to limits and trade-offs.
- **(E)** indifferent to the environments in which codes are used.

::::solution[Solution]
**Answer:** (D)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author presents coding as useful but does not rank designs categorically.
2. **Support.** The passage gives a valid correction guarantee while emphasizing resources and actual fault distributions.
3. **Prephrase.** Look for qualified approval.
4. **Why (D) is right.** (D) preserves both the positive mechanism and the cautionary decision rule.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The distance-three theorem is presented as sound, not untrustworthy.
   - **(B)** *Scope or text mismatch:* The third paragraph explicitly catalogs costs and failure limits.
   - **(C)** *Scope or text mismatch:* Single-bit correction is affirmed, not doubted.
   - **(E)** *Scope or text mismatch:* Environment is the final paragraph's central consideration.

**Check:** The concluding sentence stresses 'the match' rather than redundancy alone.
::::
:::

### Passage 2

Accounts of early computing often divide people into two groups: inventors who conceived machines and operators who carried out instructions. That division can mislead when the machine itself had no familiar programming language. To make a calculation proceed, an early programmer might have needed to translate a mathematical method into a sequence of operations, decide what intermediate results to preserve, and arrange physical connections accordingly. Such work was neither merely mechanical nor identical to the abstract design of a computer. It required a form of technical authorship that later historical narratives sometimes obscured.

ENIAC, an early general-purpose electronic digital computer developed at the University of Pennsylvania during the 1940s, provides a useful example. Its original programmers included a group of women who learned to organize computations on the machine using its controls and connections. The machine initially did not operate as a conventional stored-program computer: setting up a new computation could involve physically configuring switches and cables. Describing these programmers as people who simply “entered” instructions risks importing a later image of typing commands into a ready-made interface. Their task included working out how a mathematical procedure could be enacted by a specific and unfamiliar apparatus.

A competing account emphasizes the importance of broader institutions. The machine depended on engineering design, military demand for calculation, and coordinated labor. A history that elevates programmers into solitary geniuses would therefore reproduce the very distortion it attempts to correct. Programming choices were constrained by hardware, deadlines, and institutional priorities. Recognizing this context need not diminish the programmers' ingenuity. Instead, it helps specify what their achievement was: solving problems within a system whose boundaries they did not choose.

The distinction matters for understanding what counts as an invention in computing history. A new machine can make a range of operations possible without specifying which of those operations will be useful. Programming techniques can turn that possibility into a working method. Conversely, a clever procedure may depend on hardware capacity unavailable to its creator. The achievements are related but not interchangeable. Histories organized exclusively around devices overlook the intellectual work needed to make them do anything of value; histories organized exclusively around algorithms obscure the physical limits under which procedures take shape.

Imagine a museum exhibiting wiring diagrams and programmers' notes alongside hardware artifacts. Such a display would not merely be a gesture toward greater inclusiveness, though whose contributions are credited plainly matters. It would also make a historical claim: the meaning of a computing machine cannot be exhausted by its circuitry. The instructions, experimental practices, and accumulated knowledge of those who used it form part of the technology's history. The most accurate account does not replace one hero with another. It traces the interaction of machine design, programming labor, and the institutions that made both possible.

:::problem[Question II.8]


Which one of the following most accurately states the main point of the passage?

- **(A)** Computing history should be rewritten as the achievement of programmers alone.
- **(B)** ENIAC's earliest programmers designed every component of the machine.
- **(C)** Accurate computing history must account for the interaction among hardware, programming work, and institutions rather than treating programmers as mere operators.
- **(D)** The advent of stored programs made earlier programming work intellectually irrelevant.
- **(E)** Museums should remove machines and exhibit only programming records.

::::solution[Solution]
**Answer:** (C)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The passage proposes a richer unit of historical explanation.
2. **Support.** It examines technical decisions by programmers, hardware constraints, institutional context, and museum practices.
3. **Prephrase.** Prefer integration over replacing one hero narrative with another.
4. **Why (C) is right.** (C) captures the final paragraph's explicit synthesis and the preceding analysis.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* This is the 'new solitary genius' narrative the third paragraph rejects.
   - **(B)** *Scope or text mismatch:* The passage distinguishes hardware engineering from programming contributions.
   - **(D)** *Timing shift:* Later interfaces are used to show why retrospective assumptions mislead, not to erase earlier intellectual effort.
   - **(E)** *Too strong:* The museum example pairs notes with hardware, not notes instead of hardware.

**Check:** The final paragraph calls for interaction of machine design, programming labor, and institutions.
::::
:::

:::problem[Question II.9]


The passage indicates that ENIAC's original programming process involved...

- **(A)** physically configuring switches and cables for computations.
- **(B)** entering commands primarily through a modern-style text interface.
- **(C)** having a stored program that could be changed without any physical configuration.
- **(D)** eliminating the need to translate mathematical methods into operations.
- **(E)** using a programming language developed solely for museum displays.

::::solution[Solution]
**Answer:** (A)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question requests the described procedure, not a theory of authorship.
2. **Support.** Paragraph two gives switch and cable configuration as the initial mode.
3. **Prephrase.** Retrieve the concrete physical operations.
4. **Why (A) is right.** (A) is explicitly described in the passage.
5. **Why the others fail.**
   - **(B)** *Timing shift:* The author warns that this later image is anachronistic.
   - **(C)** *Scope or text mismatch:* The passage states the machine initially was not a conventional stored-program computer.
   - **(D)** *Scope or text mismatch:* Translating mathematical procedure into machine actions was a central programming task.
   - **(E)** *Scope or text mismatch:* Nothing describes a museum-created language for original operation.

**Check:** Return to paragraph two's 'switches and cables' phrase.
::::
:::

:::problem[Question II.10]


In the third paragraph, the reference to institutions and coordinated labor primarily functions to...

- **(A)** deny that the original programmers made meaningful decisions.
- **(B)** prove that military demand is sufficient to produce any new computing technology.
- **(C)** argue that machine engineering and programming labor are fundamentally identical.
- **(D)** show that historical credit should go exclusively to funders.
- **(E)** prevent a history correcting one omission from creating another overly individualistic account.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The author qualifies the recognition of programmers by adding institutional interdependence.
2. **Support.** The paragraph explicitly cautions against elevating programmers into solitary geniuses.
3. **Prephrase.** Select an account of balance, not denial of contributions.
4. **Why (E) is right.** (E) names the danger that one hero story would simply replace another.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The paragraph says context helps specify programmers' ingenuity rather than erase it.
   - **(B)** *Scope or text mismatch:* Demand is one component, not an all-purpose sufficient cause.
   - **(C)** *Scope or text mismatch:* The achievements are shown as related but distinguishable.
   - **(D)** *Quantifier shift:* Funding institutions contextualize contributions; they do not claim all intellectual credit.

**Check:** The sentence beginning 'A history that elevates programmers' gives the paragraph's purpose.
::::
:::

:::problem[Question II.11]


Which one of the following is most strongly suggested by the fourth paragraph?

- **(A)** A working computer design completely determines which problems users will solve.
- **(B)** A machine's ability to perform operations does not by itself specify the useful procedures its programmers will devise.
- **(C)** Algorithms can always run on every machine regardless of resources.
- **(D)** Physical components are more important historically than computational procedures.
- **(E)** Mathematical methods become independent of all hardware once written down.

::::solution[Solution]
**Answer:** (B)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The paragraph distinguishes capability from application.
2. **Support.** A new machine makes operations possible without specifying what is useful; programming turns possibilities into procedures.
3. **Prephrase.** Preserve mutual dependence rather than proclaiming one side autonomous.
4. **Why (B) is right.** (B) is a close implication of the device-versus-program distinction.
5. **Why the others fail.**
   - **(A)** *Unsupported inference:* The text states the reverse: machine possibility leaves useful choices open.
   - **(C)** *Too strong:* The author explicitly notes hardware capacity can constrain procedures.
   - **(D)** *Unsupported inference:* No exclusive ranking of historical importance is made.
   - **(E)** *Unsupported inference:* Written methods may still require hardware capacity the creator lacks.

**Check:** Hardware possibility ≠ prescribed use, as the fourth paragraph states.
::::
:::

:::problem[Question II.12]


The author's primary purpose is to...

- **(A)** establish a complete technical chronology of all early digital computers.
- **(B)** condemn museum curators for refusing to display source documents.
- **(C)** compare ENIAC's processing speed with contemporary chips.
- **(D)** challenge an oversimplified division between inventors and operators by examining the intellectual and institutional dimensions of programming.
- **(E)** show that historical research should exclude testimony about military procurement.

::::solution[Solution]
**Answer:** (D)

**Type:** RC primary purpose (Chapter 18)

1. **Conclusion.** The author challenges a familiar category split and proposes a fuller account.
2. **Support.** ENIAC is a case study; institutional limits and museum displays broaden the interpretation.
3. **Prephrase.** Match the challenge-and-reframe purpose verb and the whole passage's scope.
4. **Why (D) is right.** (D) identifies both the argument against the binary and the alternative account.
5. **Why the others fail.**
   - **(A)** *Too strong:* The passage is thematic, not a comprehensive chronology.
   - **(B)** *Scope or text mismatch:* The imagined display includes relevant documents alongside hardware.
   - **(C)** *Scope or text mismatch:* No comparative processor-speed data appears.
   - **(E)** *Scope or text mismatch:* Military demand is included as relevant context, not excluded.

**Check:** The opening names the misleading division; the ending states the integrated replacement.
::::
:::

:::problem[Question II.13]


The author's attitude toward displaying programmers' notes alongside hardware artifacts is best described as...

- **(A)** approving, because the practice communicates a more complete historical interpretation.
- **(B)** disapproving, because the notes distract from the circuitry that alone defines the technology.
- **(C)** indifferent, because exhibition choices do not imply historical claims.
- **(D)** suspicious, because the documents are necessarily unreliable.
- **(E)** celebratory only insofar as exhibits rank individual contributors by fame.

::::solution[Solution]
**Answer:** (A)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The proposed museum display illustrates the integrated history thesis.
2. **Support.** The final paragraph says the display makes a historical claim about work beyond circuitry.
3. **Prephrase.** Read the author's evaluative language rather than importing museum politics.
4. **Why (A) is right.** (A) aligns with the approval of paired artifacts and practices.
5. **Why the others fail.**
   - **(B)** *Scope or text mismatch:* The author rejects the circuitry-only account.
   - **(C)** *Scope or text mismatch:* The author explicitly calls the display a historical claim.
   - **(D)** *Too strong:* No doubt about the notes' reliability is suggested.
   - **(E)** *Scope or text mismatch:* The author rejects hero replacement and celebrity ranking as the sole purpose.

**Check:** 'Not merely a gesture' introduces a positive intellectual function of the exhibits.
::::
:::

:::problem[Question II.14]


Which one of the following best describes the organization of the passage?

- **(A)** It lists unrelated computers chronologically and concludes that later machines were uniformly superior.
- **(B)** It presents two incompatible technical theorems and settles the dispute by experiment.
- **(C)** It questions a traditional distinction, develops a historical example and qualifications, then argues for an integrated account.
- **(D)** It begins with a museum proposal and derives all subsequent claims from public survey results.
- **(E)** It advocates recognizing operators exclusively and dismisses every institutional influence.

::::solution[Solution]
**Answer:** (C)

**Type:** RC organization (Chapter 18)

1. **Conclusion.** The structure progresses from a challenged binary to example, qualification, conceptual distinction, and synthesis.
2. **Support.** ENIAC illustrates overlooked intellectual work; institutions guard against a replacement hero narrative.
3. **Prephrase.** Choose a structural answer capturing all major stages.
4. **Why (C) is right.** (C) matches the sequence without misattributing conclusions.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The passage is not a machine-by-machine chronological list.
   - **(B)** *Scope or text mismatch:* There are no competing technical theorems or resolving experiment.
   - **(D)** *Scope or text mismatch:* The museum example appears near the end, without survey evidence.
   - **(E)** *Scope or text mismatch:* Institutional influence is essential to the conclusion rather than dismissed.

**Check:** Opening challenge → ENIAC → institutional caution → interdependence → museum synthesis.
::::
:::

### Passage 3 (comparative)

**Passage A**

A patent's claims describe the boundaries of what the inventor seeks to protect. In disputes over a hypothetical patent on a processor's cache-management system, judges must sometimes choose between the ordinary technical meaning of a claim term and a narrower explanation in the patent's written description. Courts should be reluctant to import a particular example from the description into otherwise general claim language. Inventors frequently illustrate a mechanism with a preferred implementation because concrete examples make difficult engineering ideas intelligible. To treat that illustration as an unstated limitation would penalize clear teaching and allow competitors to avoid a claim merely by substituting an equivalent implementation detail. Repeated examples alone, without an express special definition or exclusion, should not shrink an otherwise general term.

This does not mean the description is irrelevant. It can explain a term of art or show that the inventor deliberately used a word in a specialized way. Nor should a broad claim survive simply because its wording is broad; other patent requirements raise separate questions. The narrower point is institutional: when the claims use general language and the description gives one example without explicitly restricting it, the interpreter should not casually turn that example into a rule. The public can read the actual claim language. A predictable distinction between examples and boundaries assists both inventors and later engineers deciding where they may innovate.

**Passage B**

The warning against reading every example as a limit is sound, but it understates another danger: treating technical words as if they carried a single stable meaning apart from the document in which they appear. A claim to a “fast” synchronization circuit might sound broad until the description repeatedly distinguishes the proposed circuit from slow systems by reference to a specific timing relationship. A skilled reader should not dismiss those explanations as irrelevant ornaments. Doing so may give the claim a scope that the document never taught the reader to expect.

This is not a call to make every illustration mandatory. Instead, interpretation should ask how the full document would inform an engineer encountering the disputed language at the relevant time. Sometimes an example is simply one embodiment; sometimes sustained descriptions explain what the inventor meant by a seemingly familiar term, even without an express definition or exclusion. A rigid presumption against considering those explanations would make claims look more certain while making their actual technical meaning less so. Predictability matters, but so does fair notice to competitors about the invention the document genuinely describes. The distinction between interpreting words in context and adding an invented limitation is difficult, yet it cannot be avoided by focusing on claim text alone. An engineer reading the specification might discover that an apparently ordinary word was used to exclude a familiar alternative design. Ignoring that usage would not preserve neutrality. It would silently select one meaning over another while pretending the surrounding explanation offered no relevant evidence.

:::problem[Question II.15]


Which one of the following most accurately characterizes the relationship between the two passages?

- **(A)** A denies that descriptions ever matter, while B claims every example is automatically a limitation.
- **(B)** Both favor choosing the narrowest possible scope for every patent claim, but for different reasons.
- **(C)** A primarily discusses the validity of patents, while B discusses financial damages.
- **(D)** Both reject the relevance of claim language and prioritize only physical prototypes.
- **(E)** A emphasizes resisting unwritten restrictions from examples, whereas B emphasizes contextual interpretation to avoid unsupported breadth.

::::solution[Solution]
**Answer:** (E)

**Type:** RC comparative relationship (Chapter 17)

1. **Conclusion.** A resists turning illustrative details into boundaries; B resists ignoring relevant explanatory context.
2. **Support.** Both allow description to matter in some cases and reject automatic importation of every example.
3. **Prephrase.** Capture the difference in emphasis without making their positions absolute opposites.
4. **Why (E) is right.** (E) accurately articulates the two concerns and preserves their shared nuance.
5. **Why the others fail.**
   - **(A)** *Author-position or scope mismatch:* Both halves overstate: A allows specialized definitions, and B rejects making every illustration mandatory.
   - **(B)** *Author-position or scope mismatch:* Neither advocates the narrowest claim in every case.
   - **(C)** *Author-position or scope mismatch:* Both address interpretation; A mentions validity only as a distinct issue.
   - **(D)** *Too strong:* Claims are the focus, not something either author rejects.

**Check:** Compare A's 'should not casually turn that example into a rule' with B's warning against context-free meaning.
::::
:::

:::problem[Question II.16]


Both authors would most likely agree with which one of the following statements?

- **(A)** A patent's written description is irrelevant whenever its claims use general words.
- **(B)** The presence of an example in a description does not, by itself, make that example a mandatory claim limitation.
- **(C)** Patent claims should always be interpreted as broadly as linguistic possibility allows.
- **(D)** Technical words invariably have meanings entirely independent of the patent document.
- **(E)** Judges should disregard the informational needs of engineers designing alternatives.

::::solution[Solution]
**Answer:** (B)

**Type:** RC comparative agreement (Chapter 17)

1. **Conclusion.** Both writers resist automatic limits based solely on an example.
2. **Support.** A distinguishes examples from boundaries; B expressly says it is not calling for every illustration to become mandatory.
3. **Prephrase.** Apply the 'both must have a stake' filter to their common qualification.
4. **Why (B) is right.** (B) captures the explicit shared ground despite the difference in emphasis.
5. **Why the others fail.**
   - **(A)** *Author-position or scope mismatch:* A and B both allow description to explain terms.
   - **(C)** *Author-position or scope mismatch:* A rejects unlimited breadth independent of other requirements; B resists unearned breadth from decontextualization.
   - **(D)** *Author-position or scope mismatch:* B explicitly denies context-free meanings; A recognizes specialized usage.
   - **(E)** *Timing shift:* Both address fair notice or predictability for later engineers.

**Check:** Both passages say 'not every example is a limit'; the disagreement is when context changes meaning.
::::
:::

:::problem[Question II.17]


The authors are most likely to differ in their assessment of which one of the following proposals?

- **(A)** Courts should distinguish between interpreting claim words and applying independent validity rules.
- **(B)** Patent documents may contain illustrative embodiments that are not exhaustive.
- **(C)** Engineers should receive notice of the boundaries asserted by patent owners.
- **(D)** Repeated descriptions of one timing relationship, without an express definition or exclusion, can by themselves justify reading that relationship into otherwise general claim language.
- **(E)** It is possible for an inventor to describe a specialized meaning of a claim term.

::::solution[Solution]
**Answer:** (D)

**Type:** RC comparative disagreement (Chapter 17)

1. **Conclusion.** The dispute concerns which evidence should lead when broad text and contextual explanation tension arises.
2. **Support.** A advocates reluctance to narrow from examples; B objects to a rigid presumption overlooking repeated explanations.
3. **Prephrase.** Find a method that A is more receptive to and B expressly cautions against.
4. **Why (D) is right.** (D) follows B's insistence that repeated contextual explanation can restrict apparent generality, whereas A requires more than an unrestrictive example before adding a boundary.
5. **Why the others fail.**
   - **(A)** *Author-position or scope mismatch:* A expressly distinguishes validity, and B does not reject that separation.
   - **(B)** *Author-position or scope mismatch:* Both recognize illustrative embodiments can remain examples.
   - **(C)** *Author-position or scope mismatch:* Both value notice and predictability though their routes differ.
   - **(E)** *Author-position or scope mismatch:* A expressly permits specialized usage, as does B.

**Check:** On implicit restriction from repeated explanations, B is more receptive; A resists without an express special meaning or exclusion.
::::
:::

:::problem[Question II.18]


How would the author of Passage A most likely respond to Passage B's example of a term repeatedly explained through a particular timing relationship?

- **(A)** Such explanations might establish a specialized use, but they should not automatically transform any preferred implementation into an additional claim requirement.
- **(B)** No written description can ever help determine what an inventor means.
- **(C)** All claim terms must be limited to the narrowest circuit diagram in the document.
- **(D)** The timing relationship would necessarily render the patent invalid.
- **(E)** Technical claim terms can be interpreted only through later commercial success.

::::solution[Solution]
**Answer:** (A)

**Type:** RC comparative response (Chapter 17)

1. **Conclusion.** A recognizes explicit specialized meanings while protecting against casually imported limits.
2. **Support.** B's example may be evidence of meaning, which A already concedes descriptions can supply.
3. **Prephrase.** Combine A's exception with A's caution.
4. **Why (A) is right.** (A) preserves A's willingness to consult explanatory use without treating every implementation as mandatory.
5. **Why the others fail.**
   - **(B)** *Author-position or scope mismatch:* A explicitly says descriptions can explain specialized term usage.
   - **(C)** *Author-position or scope mismatch:* A resists importing specific illustrations into general claims without justification.
   - **(D)** *Too strong:* Interpretation evidence alone does not establish invalidity, which A keeps separate.
   - **(E)** *Too strong:* Passage A grounds interpretation in document language, not subsequent sales.

**Check:** Passage A's second paragraph supplies both the permission and the limit stated in (A).
::::
:::

:::problem[Question II.19]


Which one of the following conclusions is supported by both passages?

- **(A)** Only judges, not engineers, can understand claim boundaries.
- **(B)** The presence of preferred implementations always makes general claim language legally void.
- **(C)** Predictable interpretation is important partly because engineers designing later products use patent documents to assess what is covered.
- **(D)** The written description is usually authored by competitors rather than inventors.
- **(E)** Future technologies can never fall within the language of an earlier claim.

::::solution[Solution]
**Answer:** (C)

**Type:** RC comparative inference (Chapter 17)

1. **Conclusion.** Both authors connect interpretation to guidance for subsequent engineers.
2. **Support.** A discusses where engineers may innovate; B discusses their fair notice of what a document describes.
3. **Prephrase.** Look for a modest consequence supported by both texts.
4. **Why (C) is right.** (C) captures the practical reliance interest shared by the competing views.
5. **Why the others fail.**
   - **(A)** *Unsupported inference:* Both assume an engineer can read documents meaningfully.
   - **(B)** *Unsupported inference:* Neither declares automatic invalidity from preferred examples.
   - **(D)** *Unsupported inference:* Both frame the description as part of the inventor's patent document.
   - **(E)** *Too strong:* Neither states an absolute temporal bar on claim language.

**Check:** A's 'later engineers' and B's 'fair notice to competitors' both ground (C).
::::
:::

:::problem[Question II.20]


Which one of the following statements would the author of Passage B most likely endorse regarding Passage A's approach?

- **(A)** It makes no distinction between examples and boundaries, so it necessarily narrows all claims.
- **(B)** It wrongly assumes engineers never read a patent's description.
- **(C)** It favors treating every specialized use as an irrelevant ornament.
- **(D)** It is concerned exclusively with patent-application filing fees.
- **(E)** Its warning against importing examples is valuable, but a strong preference for general wording risks disregarding explanations that determine technical meaning.

::::solution[Solution]
**Answer:** (E)

**Type:** RC comparative response (Chapter 17)

1. **Conclusion.** B grants A's central warning but argues it needs a contextual qualification.
2. **Support.** B begins by calling the warning sound, then explains the risk of context-free apparent generality.
3. **Prephrase.** Look for qualified agreement followed by a targeted criticism.
4. **Why (E) is right.** (E) reproduces B's concession-and-objection structure.
5. **Why the others fail.**
   - **(A)** *Too strong:* B explicitly agrees examples are not automatically binding; A resists narrowing.
   - **(B)** *Author-position or scope mismatch:* A acknowledges that descriptions may inform specialized uses.
   - **(C)** *Author-position or scope mismatch:* 'Every' misstates A's explicit exception for specialized meanings.
   - **(D)** *Author-position or scope mismatch:* Filing fees do not appear in either passage.

**Check:** B's first and last paragraphs give the concession and its limit.
::::
:::

### Passage 4

A digital marketplace that connects buyers and independent sellers may become more useful to buyers when additional sellers join, because the range of available products increases. It may simultaneously become more attractive to sellers as the number of buyers grows. Economists call these relationships *indirect network effects*: participation on one side can alter the value of participation on the other. These effects help explain why a platform may subsidize one group while charging another. But the existence of a network effect, by itself, does not establish that one platform will necessarily dominate or that entrants cannot compete.

Consider a fictional marketplace called Dock. Dock initially attracts many sellers with low commissions, and its enlarged selection draws buyers. Those buyers, in turn, attract additional sellers. Management sees the cycle as proof that raising commissions cannot cause sellers to leave: wherever the buyers are, sellers must remain. However, the conclusion assumes that sellers must choose just one marketplace. If listing products on several sites is inexpensive, sellers can *multihome*, maintaining a presence on Dock while also offering products elsewhere. Higher commissions might then encourage sellers to direct buyers toward competing channels without immediately removing their Dock listings.

The economics also depend on differences among participants. A seller of a rare replacement component may value access to a small number of specialized buyers more than access to a large general audience. A seller of common accessories may care more about total traffic. Likewise, a buyer may value a search tool that distinguishes compatible products over one that simply lists more products. Counting participants therefore measures a potential source of value, not the complete quality of the matching service. A platform with many inactive sellers may offer a worse experience than a smaller platform with accurate inventory and reliable fulfillment.

A policy analyst studying Dock proposes measuring not only registered accounts but completed transactions, seller costs, and the frequency with which participants use competing services. The analyst expects those measurements to reveal whether Dock's apparent size advantage translates into genuine dependence. Yet the analyst warns against drawing the reverse conclusion too quickly. Multihoming is not costless in all settings: sellers may have to maintain separate inventories, reputations, and customer support systems. A competing marketplace that looks easy to join on paper may be difficult to use profitably in practice.

The resulting picture is more conditional than either an inevitable-monopoly narrative or an automatic-competition narrative. Network effects can protect an incumbent by making its existing participation valuable. They can also coexist with meaningful competition when participants can shift transactions, maintain multiple memberships, or find specialized alternatives. For anyone drafting platform contracts or assessing market power, the central question is not merely how large the network is. It is how participation affects real choices, and how costly those choices would be to change.

:::problem[Question II.21]


Which one of the following best states the main point of the passage?

- **(A)** Network effects influence platform power, but assessing dependence requires attention to participation, alternatives, and switching costs rather than user counts alone.
- **(B)** Large digital marketplaces necessarily become permanent monopolies.
- **(C)** Sellers with specialized products always leave general-purpose marketplaces.
- **(D)** High commissions automatically force every seller to close its account.
- **(E)** A registered-account count fully captures platform quality.

::::solution[Solution]
**Answer:** (A)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author argues against both inevitable dominance and automatic contestability.
2. **Support.** Dock's loop, multihoming, heterogeneous sellers, and shifting costs supply the qualifications.
3. **Prephrase.** Choose the conditional assessment rather than either extreme story.
4. **Why (A) is right.** (A) expresses the passage's final synthesis and the criteria argued throughout.
5. **Why the others fail.**
   - **(B)** *Scope or text mismatch:* The author explicitly rejects necessary dominance.
   - **(C)** *Too strong:* Specialized sellers are an example of heterogeneous incentives, not a universal migration rule.
   - **(D)** *Scope or text mismatch:* Multihoming may redirect transactions without immediate departures.
   - **(E)** *Scope or text mismatch:* The passage says inactive accounts can make counts misleading.

**Check:** The final paragraph says the central question is how participation affects real choices and their cost of change.
::::
:::

:::problem[Question II.22]


As used in the passage, an indirect network effect occurs when...

- **(A)** an individual seller reduces its costs by improving manufacturing techniques.
- **(B)** two marketplaces merge their accounting departments.
- **(C)** advertising automatically causes every potential buyer to register.
- **(D)** participation by one group changes the value of the platform to another group.
- **(E)** each registered user has exactly the same purchasing power.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question asks for the defined cross-side effect.
2. **Support.** The opening explains more sellers attract buyers and more buyers attract sellers.
3. **Prephrase.** Reproduce the relationship across participant groups.
4. **Why (D) is right.** (D) is a direct paraphrase of the definition.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* A supplier's internal cost change need not involve a different side of a platform.
   - **(B)** *Scope or text mismatch:* A corporate merger is not itself a cross-side participation effect.
   - **(C)** *Too strong:* Automatic universal registration is not asserted and is not a definition.
   - **(E)** *Scope or text mismatch:* Participant uniformity is neither implied nor required.

**Check:** More sellers → more buyer value exemplifies (D).
::::
:::

:::problem[Question II.23]


The discussion of multihoming most strongly supports which one of the following statements?

- **(A)** A seller that uses two platforms must divide its sales equally between them.
- **(B)** A seller's continued presence on a platform does not necessarily show that the seller remains commercially dependent on it.
- **(C)** Higher commissions always increase overall seller profits.
- **(D)** Multihoming eliminates all the costs of building seller reputation.
- **(E)** Every platform with network effects loses its customers quickly.

::::solution[Solution]
**Answer:** (B)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** Multihoming complicates the inference from a retained listing to commercial dependence.
2. **Support.** Sellers may retain a Dock account while shifting transactions toward competitors.
3. **Prephrase.** Distinguish nominal membership from economic activity.
4. **Why (B) is right.** (B) follows from the described possibility of redirected buyers without immediate delisting.
5. **Why the others fail.**
   - **(A)** *Unsupported inference:* No equal split of sales follows from using multiple sites.
   - **(C)** *Unsupported inference:* Commission increases can motivate sellers to shift away rather than improve profit.
   - **(D)** *Unsupported inference:* The fourth paragraph expressly identifies reputation maintenance as a cost.
   - **(E)** *Too strong:* Network effects may strengthen incumbents and do not imply rapid exit universally.

**Check:** Listed on Dock + selling elsewhere is consistent with reduced Dock dependence.
::::
:::

:::problem[Question II.24]


The author's comparison of replacement-component sellers and accessory sellers primarily serves to...

- **(A)** prove that rare components cannot be sold using digital platforms.
- **(B)** establish that access to a large audience is worthless for all sellers.
- **(C)** illustrate why the same network size can provide different value to different types of participants.
- **(D)** show that sellers are prohibited from listing on more than one marketplace.
- **(E)** argue that replacement components are always more profitable than accessories.

::::solution[Solution]
**Answer:** (C)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The examples qualify the claim that a raw count fully measures value.
2. **Support.** Specialized buyers and mass traffic matter differently to different sellers.
3. **Prephrase.** Look for heterogeneity that limits count-based inference.
4. **Why (C) is right.** (C) captures the variation in what participants value.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The example assumes rare parts may be marketed online to specialized buyers.
   - **(B)** *Scope or text mismatch:* Traffic can matter strongly to common-accessory sellers.
   - **(D)** *Scope or text mismatch:* Multihoming is discussed as possible, not prohibited.
   - **(E)** *Scope or text mismatch:* The passage never compares net profit margins across products.

**Check:** The two seller types are contrasted to demonstrate heterogeneous incentives.
::::
:::

:::problem[Question II.25]


Which one of the following is most strongly supported by the passage's assessment of account counts?

- **(A)** Completed transaction data always reveal a platform's future market share with certainty.
- **(B)** Platform size has no effect on user choice.
- **(C)** A marketplace with fewer sellers necessarily has better fulfillment.
- **(D)** Every inactive account represents a fraudulent user.
- **(E)** A platform can appear large in registration statistics while offering a relatively weak matching experience.

::::solution[Solution]
**Answer:** (E)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author warns against treating membership count as complete service quality.
2. **Support.** Inactive sellers and inaccurate inventory can make a larger marketplace function less well.
3. **Prephrase.** Infer measurement limits, not a universal reversal of the ranking.
4. **Why (E) is right.** (E) describes precisely the possibility highlighted in paragraph three.
5. **Why the others fail.**
   - **(A)** *Too strong:* Actual transactions improve evidence but do not make forecasting certain.
   - **(B)** *Unsupported inference:* Network effects can make participation valuable, so size sometimes matters.
   - **(C)** *Too strong:* Smaller does not guarantee better quality; the passage says 'may.'
   - **(D)** *Too strong:* Inactivity and fraud are not equated.

**Check:** Registered sellers can be inactive; count exceeds meaningful matching participation.
::::
:::

:::problem[Question II.26]


The author's attitude toward the claim that network effects inevitably prevent new competition is best described as...

- **(A)** critical of its certainty while recognizing that network effects can protect incumbents.
- **(B)** wholly accepting because any large platform permanently excludes rivals.
- **(C)** indifferent because the passage discusses only hardware engineering.
- **(D)** dismissive of the possibility that existing users provide any value to a platform.
- **(E)** convinced that multihoming is costless in every marketplace.

::::solution[Solution]
**Answer:** (A)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author rejects inevitability but not the phenomenon of incumbent advantage.
2. **Support.** The final paragraph states both possibilities; earlier paragraphs detail multihoming costs.
3. **Prephrase.** Select qualified criticism rather than blanket denial or acceptance.
4. **Why (A) is right.** (A) reflects both the limit and concession in the text.
5. **Why the others fail.**
   - **(B)** *Scope or text mismatch:* Permanent exclusion is the oversold claim under dispute.
   - **(C)** *Scope or text mismatch:* The entire passage concerns platform economics.
   - **(D)** *Scope or text mismatch:* The author explicitly recognizes participation can attract more participants.
   - **(E)** *Scope or text mismatch:* Inventory, reputation, and support are costs the author identifies.

**Check:** 'Can protect an incumbent' is balanced by 'coexist with meaningful competition.'
::::
:::

:::problem[Question II.27]


Which one of the following best describes how the passage develops its argument?

- **(A)** It rejects network effects at the outset and substitutes an account of technological obsolescence.
- **(B)** It derives a formal mathematical theorem and applies it to a real antitrust judgment.
- **(C)** It narrates a historical monopoly's founding, expansion, and collapse.
- **(D)** It starts by recommending a legal remedy and then lists statutes requiring the remedy.
- **(E)** It explains network effects, uses a fictional platform to test a dominance inference, and proposes a more nuanced assessment of dependence.

::::solution[Solution]
**Answer:** (E)

**Type:** RC organization (Chapter 18)

1. **Conclusion.** The passage moves from concept to Dock example to alternative variables and synthesized policy caution.
2. **Support.** It defines indirect effects, challenges management's conclusion, then examines multihoming and actual activity.
3. **Prephrase.** Match the full progression rather than only one example.
4. **Why (E) is right.** (E) includes the explanation, evaluation, and conditional assessment.
5. **Why the others fail.**
   - **(A)** *Scope or text mismatch:* The opening defines and accepts network effects as genuine.
   - **(B)** *Scope or text mismatch:* No formal theorem or actual judicial decision is offered.
   - **(C)** *Scope or text mismatch:* Dock is expressly fictional, and the passage is analytical rather than historical.
   - **(D)** *Scope or text mismatch:* No specific statute or legal remedy structures the discussion.

**Check:** Definition → Dock's inference → qualifications → better measures → conditional conclusion.
::::
:::


## 33.3 Section III: Logical Reasoning

:::problem[Question III.1]
A legal technology team claims that a new document-search model produces more useful results than its predecessor. Lawyers using the new model gave its results higher scores, but they also knew they were testing the replacement and had helped propose the project. The team leader argues that the higher scores reflect better retrieval rather than enthusiasm for the project. Because the firm plans to use the model for expensive litigation research, an independent committee wants evidence that the advantage persists when reviewers do not know which model produced each result.

Which one of the following, if true, most strengthens the leader's argument?

- **(A)** The new model has a more colorful results interface.
- **(B)** Several participating lawyers were promoted after the pilot.
- **(C)** The new model requires a larger computer to run efficiently.
- **(D)** In a later blind test on the same queries, independent lawyers rated the new model's results higher using the same relevance rubric.
- **(E)** The new model was developed by a vendor with a strong marketing reputation.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The leader attributes higher ratings to genuinely better retrieval.
2. **Support.** Original ratings may be biased because involved lawyers knew model identities.
3. **Prephrase.** Seek blinded independent replication with equivalent evaluation standards.
4. **Why (D) is right.** (D) directly removes expectancy and involvement bias while preserving the observed advantage.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* Visual appeal could bias ratings and says little about retrieved relevance.
   - **(B)** *Wrong causal or evidentiary target:* Promotions may create incentives but do not validate comparative result quality.
   - **(C)** *Wrong causal or evidentiary target:* Computing requirements concern operating cost, not the document relevance evaluated.
   - **(E)** *Wrong causal or evidentiary target:* Vendor reputation is an appeal to authority, not a controlled performance measure.

**Check:** Blind independent scores reproduce the advantage while blocking knowledge-of-model bias.
::::
:::

:::problem[Question III.2]
An industrial designer argues that a new medical monitor will be exceptionally reliable. Every individual component selected for the monitor passed a demanding laboratory reliability test, and the supplier provides detailed certificates for each part. The designer concludes that the complete monitor must therefore pass the hospital's demanding system-level reliability test. That system test will be performed only after the prototype is assembled. The designer nevertheless maintains that certifying the individual parts in advance makes a successful system-level result effectively certain.

The argument is most vulnerable to criticism because it...

- **(A)** relies on an irrelevant personal attack against the supplier.
- **(B)** assumes properties established for individual parts necessarily hold for the assembled system.
- **(C)** draws a conclusion from a survey restricted to dissatisfied patients.
- **(D)** assumes that a certified component can never malfunction.
- **(E)** treats a feature that guarantees system failure as necessary for system success.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The designer predicts the assembled monitor must pass system-level tests.
2. **Support.** Each part passes a component test, but interface interactions are untested.
3. **Prephrase.** Identify part-to-whole composition rather than dismissing component evidence.
4. **Why (B) is right.** (B) names the extrapolation from individually sound components to system performance despite interfaces.
5. **Why the others fail.**
   - **(A)** *Different flaw:* No personal attack or supplier motive appears.
   - **(C)** *Different flaw:* No patient sample or survey is involved.
   - **(D)** *Too strong:* The designer need not claim zero component failures to commit the composition flaw.
   - **(E)** *Too strong:* The mistake is component-to-system inference, not confusing a cause of failure with a success prerequisite.

**Check:** Two compliant components could interact badly while every component certificate remains accurate.
::::
:::

:::problem[Question III.3]
Every contractor permitted to upload production firmware has signed a confidentiality agreement. No contractor may receive production upload permission unless a security officer has approved the contractor's account. Some approved contractors have never uploaded any firmware. Contractor Vale was granted permission to upload production firmware yesterday, though the records do not say whether Vale has used it. The company does not require a security officer's approval for viewing publicly available firmware documentation, which several other contractors viewed last week.

Which one of the following must be true?

- **(A)** Vale signed a confidentiality agreement and received a security officer's approval.
- **(B)** Vale uploaded production firmware yesterday.
- **(C)** Every contractor with security approval can upload production firmware.
- **(D)** Any contractor who views public documentation has signed a confidentiality agreement.
- **(E)** No contractor other than Vale has production upload permission.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** There is no argued conclusion, only permission conditions and one identified case.
2. **Support.** Upload permission → confidentiality agreement and security approval; Vale has upload permission.
3. **Prephrase.** Apply necessary conditions to Vale without inferring actual use.
4. **Why (A) is right.** (A) follows by two direct conditionals applied to the granted permission.
5. **Why the others fail.**
   - **(B)** *Unsupported inference:* Permission does not entail using the permission.
   - **(C)** *Too strong:* Security approval is necessary, not sufficient, for upload permission.
   - **(D)** *Unsupported inference:* Public documents are explicitly treated differently, so no confidentiality requirement is established.
   - **(E)** *Quantifier shift:* The rules and Vale's case do not enumerate all other permitted contractors.

**Check:** Vale permitted → signed and approved; no converse is needed.
::::
:::

:::problem[Question III.4]
A software company claims its revised renewal notices will reduce disputed contract renewals. The notices will be sent by email thirty days before each automatic renewal, and the company says this gives subscribers enough opportunity to cancel. Its own records show that many subscribers rarely log in to their customer dashboard, which formerly contained the only notice. The support team adds that subscribers sometimes overlook communications while traveling and that changing the format of notices has often been requested by customer-service representatives.

The company's reasoning depends on assuming which one of the following?

- **(A)** Every subscriber checks email at least once every hour.
- **(B)** The company charges the lowest subscription price in its industry.
- **(C)** Subscribers will abandon the product if they receive more than one notice.
- **(D)** The old dashboard never displayed any account information besides renewal notices.
- **(E)** The email notices will be received by at least some subscribers who would otherwise lack effective notice of renewal.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The company predicts email notices will reduce disputes caused by ineffective notice.
2. **Support.** Dashboard notices were poorly encountered, but email delivery's actual reach is unstated.
3. **Prephrase.** The minimal required connection is that email reaches some people inadequately notified before.
4. **Why (E) is right.** Negating (E) eliminates any improvement in notice to those previously unreached, undermining the claimed mechanism for fewer disputes.
5. **Why the others fail.**
   - **(A)** *Too strong:* Hourly checking is vastly stronger than necessary to read a thirty-day notice.
   - **(B)** *Not required:* Price ranking does not establish notice effectiveness.
   - **(C)** *Not required:* Churn reactions to duplicate notices are not required for the claimed dispute reduction.
   - **(D)** *Too strong:* Dashboard contents unrelated to the appearance of renewal notices are immaterial.

**Check:** If not one formerly uninformed subscriber receives effective notice, improved delivery cannot explain fewer notice-based disputes.
::::
:::

:::problem[Question III.5]
An operator replaces older servers with more energy-efficient machines. Measurements show that electricity consumption per processed request falls by forty percent. Nevertheless, total electricity use at the facility rises over the next quarter, even though cooling efficiency is unchanged and the number of active machines stays constant. The operator verifies both sets of measurements and finds no significant metering error. The engineers therefore ask how a lower energy cost for each request could accompany a higher aggregate energy bill.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The replacement machines have a lower advertised peak power rating than the retired machines.
- **(B)** The operator also recorded a decline in the average time required to process each request.
- **(C)** The number of requests handled by the facility more than doubled after the upgrade.
- **(D)** The facility used the same electricity supplier throughout both quarters.
- **(E)** The retired servers were shut down rather than operated in parallel with their replacements.

::::solution[Solution]
**Answer:** (C)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The apparent conflict is lower energy per request but higher overall energy.
2. **Support.** Total use depends on energy per request times requests plus other facility loads.
3. **Prephrase.** Seek a sufficiently large increase in volume.
4. **Why (C) is right.** (C) makes a higher total compatible with a forty-percent per-request drop: more than twice the volume outweighs the efficiency gain, assuming other loads do not offset it.
5. **Why the others fail.**
   - **(A)** *Does not apply the governing rule or explanation:* A lower peak rating reinforces efficiency but does not explain higher aggregate use without workload information.
   - **(B)** *Does not apply the governing rule or explanation:* Shorter processing time per request does not show how many more requests were handled.
   - **(D)** *Does not apply the governing rule or explanation:* The identity of the electricity supplier does not explain greater energy consumption.
   - **(E)** *Does not apply the governing rule or explanation:* Retiring old machines rules out duplicate operation as an explanation; it does not account for higher use.

**Check:** At 0.6 times the energy per request and more than twice the requests, processing energy exceeds 1.2 times its old level.
::::
:::

:::problem[Question III.6]
A museum director says that digitizing the collection is worthwhile, but it cannot replace preserving the original objects. A scan records selected visual and textual properties, while a physical artifact may contain manufacturing marks or materials not captured by the scan. Because future researchers may ask questions that today's scanning process cannot anticipate, the museum should continue maintaining physical artifacts even after high-quality digital surrogates become available. The director therefore rejects a budget proposal that would eliminate physical storage immediately after digitization.

Which one of the following is the argument's main conclusion?

- **(A)** The museum should retain and preserve its original artifacts after digitizing them.
- **(B)** High-quality scans can record some useful visual information.
- **(C)** Some future research questions cannot be predicted today.
- **(D)** Digitization is never worthwhile for museums.
- **(E)** The museum's existing storage space will always be sufficient.

::::solution[Solution]
**Answer:** (A)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The recommendation is to preserve originals despite available scans.
2. **Support.** Scans omit some physical attributes and cannot anticipate every research question.
3. **Prephrase.** Find the action supported by the limitations of digitization.
4. **Why (A) is right.** (A) states the director's advocated policy rather than its premises or a rejected extreme.
5. **Why the others fail.**
   - **(B)** *Premise/conclusion or role swap:* This is a conceded benefit of scans, not the final recommendation.
   - **(C)** *Premise/conclusion or role swap:* This is a premise supporting retention.
   - **(D)** *Argument-structure mismatch:* The director explicitly calls digitization worthwhile.
   - **(E)** *Too strong:* The argument says nothing about future capacity needs.

**Check:** The 'because' premises culminate in 'should continue maintaining physical artifacts.'
::::
:::

:::problem[Question III.7]
A legal department buys software that automatically organizes deposition exhibits. The department's director says that the software saved attorney labor because cases that used it generated fewer billed hours than cases that did not. However, teams selected their own cases for the pilot, and lawyers tended to choose the tool for smaller disputes with fewer witnesses. The director insists that fewer hours are still compelling evidence of a software effect, since billing records are audited for accuracy and the difference between the two groups is substantial.

Which one of the following, if true, most weakens the director's conclusion?

- **(A)** Several attorneys found the software's user interface pleasant.
- **(B)** Audit records confirm that every billed hour was entered correctly.
- **(C)** When cases are matched on witnesses and dispute size, the tool-using cases have approximately the same billed hours as cases without the tool.
- **(D)** The software can export exhibits in several common formats.
- **(E)** The department also uses electronic calendaring software.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The director concludes the tool caused lower billed hours.
2. **Support.** Cases with the tool were systematically easier; accurate billing cannot control this difference.
3. **Prephrase.** Compare like-sized cases and see whether the advantage survives.
4. **Why (C) is right.** (C) removes the observed difference after matching the known confounders, undermining the causal story.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* User enjoyment says little about actual saved attorney hours.
   - **(B)** *Too strong:* Accurate billing confirms recorded outcomes, not comparability of case complexity.
   - **(D)** *Wrong causal or evidentiary target:* Export formats are potentially useful but not evidence of hours saved.
   - **(E)** *Wrong causal or evidentiary target:* Another tool's presence in the department is not shown to differ between pilot groups.

**Check:** After matching on the confounder, the predicted software-specific advantage disappears.
::::
:::

:::problem[Question III.8]
A delivery service's planner argues that routing software should not minimize travel time without constraints. Faster deliveries can improve customer satisfaction, she grants, but an algorithm that systematically directs cyclists through dangerous crossings may impose unacceptable risk. She proposes placing safety limits in the optimization and then finding the fastest routes among those that satisfy the limits. The planner notes that the company can still measure speed and customer satisfaction, but those measures should not alone decide whether a route is acceptable.

The claim that faster deliveries can improve customer satisfaction serves which role in the argument?

- **(A)** It is the author's final conclusion about how routes should be selected.
- **(B)** It is evidence that dangerous crossings should always be used.
- **(C)** It is a factual claim the author explicitly denies.
- **(D)** It is a necessary condition for a route to qualify as safe.
- **(E)** It is an acknowledged consideration supporting speed that the author argues must be constrained by safety.

::::solution[Solution]
**Answer:** (E)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The planner concludes safety constraints must limit time optimization.
2. **Support.** Customer satisfaction favors speed but does not resolve danger at crossings.
3. **Prephrase.** Identify a concession used to frame a qualified policy.
4. **Why (E) is right.** (E) captures the conceded benefit and its subordinate role.
5. **Why the others fail.**
   - **(A)** *Argument-structure mismatch:* The final policy is constrained optimization, not speed alone.
   - **(B)** *Too strong:* Satisfaction benefits do not justify unacceptable risk.
   - **(C)** *Argument-structure mismatch:* 'She grants' marks acceptance, not denial.
   - **(D)** *Argument-structure mismatch:* Safety can exist without high delivery speed; no such conditional is stated.

**Check:** The argument reads 'speed helps, but safety limits should come first.'
::::
:::

:::problem[Question III.9]
A fictional company's export rule states that any diagnostic log approved by the compliance office and containing no customer identifiers may be sent to an overseas testing partner. An engineer has a log that contains no customer identifiers, but the engineer has not checked whether compliance approval has been granted. The engineer concludes that the log may already be sent under the rule. The engineer notes that a colleague successfully sent a different identifier-free log to the same partner last month and expects the current log to be treated in much the same way.

Which one of the following, if assumed, allows the engineer's conclusion to be properly drawn?

- **(A)** The overseas partner has requested logs from other products.
- **(B)** The compliance office has approved the log in question.
- **(C)** Some approved diagnostic logs contain customer identifiers.
- **(D)** The engineer believes compliance approval is usually quick.
- **(E)** Every log sent overseas is stored for at least a week.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The engineer concludes this log is permitted for export.
2. **Support.** The rule supplies approval AND no identifiers → may send; only no identifiers is given.
3. **Prephrase.** Supply the missing conjunct for this particular log.
4. **Why (B) is right.** (B) completes the antecedent of the policy rule, making the permission follow.
5. **Why the others fail.**
   - **(A)** *Insufficient bridge:* Other products' logs do not determine permission for this log.
   - **(C)** *Quantifier shift:* Even if true, some approved logs' data content says nothing about the pending case.
   - **(D)** *Insufficient bridge:* Expected speed is not actual approval.
   - **(E)** *Too strong:* Retention length is a separate downstream property, not an authorization condition.

**Check:** Approval = yes and identifiers = none; together they trigger the stated permission.
::::
:::

:::problem[Question III.10]
A software vendor compares its two subscription plans. Plan A costs the average customer less per month than Plan B, so its sales team says Plan A must cost every customer less than Plan B. The average was calculated using different groups of customers, some with many users and some with few, and the plans charge differently for extra seats. The sales team has not compared what any particular customer would pay under both plans. Yet it uses the aggregate averages to promise universal savings from switching.

The argument is most vulnerable to criticism because it...

- **(A)** assumes that every firm must use cloud software.
- **(B)** treats a customer-survey opinion as a binding contract clause.
- **(C)** confuses a necessary feature of software with a feature sufficient for security.
- **(D)** infers from lower group average spending that each individual customer would pay less.
- **(E)** draws conclusions about current pricing solely from historical inflation.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Sales claims every customer would save with Plan A.
2. **Support.** The only evidence is a lower average for a possibly different customer mix.
3. **Prephrase.** Identify a group-average-to-individual guarantee error, compounded by unequal comparison groups.
4. **Why (D) is right.** (D) directly describes the invalid inference from mean values to a universal individual claim.
5. **Why the others fail.**
   - **(A)** *Quantifier shift:* Software adoption in all firms is never asserted.
   - **(B)** *Different flaw:* The data are price averages, not questionnaire opinions about legal obligations.
   - **(C)** *Different flaw:* No security conditional appears.
   - **(E)** *Wrong comparison:* Inflation is not an input to the comparison.

**Check:** One customer could pay more on A even if the average customer in the A group pays less.
::::
:::

:::problem[Question III.11]
A security research institute follows this rule: if a researcher discovers a reproducible flaw that threatens users, the researcher should first give the affected vendor a reasonable private opportunity to investigate and prepare a fix, unless immediate public warning is necessary to prevent imminent serious harm. Researcher Sol discovers such a flaw. No exploitation has been observed and the institute has identified no imminent serious harm, but Sol wants to publish the complete exploit immediately to gain recognition before a conference.

Which one of the following actions most closely conforms to the institute's rule?

- **(A)** Publish the full exploit immediately because researchers always own their discoveries.
- **(B)** Privately notify the vendor and allow a reasonable opportunity to investigate and prepare a fix before full publication.
- **(C)** Conceal the vulnerability permanently even after a workable fix is developed.
- **(D)** Sell the exploit to the highest bidder without informing users or the vendor.
- **(E)** Publish immediately whenever a conference submission deadline is near.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The policy gives the vendor a reasonable first chance, subject to an emergency exception.
2. **Support.** This reproducible user-threatening flaw lacks the defined imminent-harm exception.
3. **Prephrase.** Apply the rule without adding an exception for reputation or deadlines.
4. **Why (B) is right.** (B) exactly follows the vendor-notification requirement.
5. **Why the others fail.**
   - **(A)** *Too strong:* Research ownership is not an exception in the rule.
   - **(C)** *Does not apply the governing rule or explanation:* The policy requires initial delay, not perpetual silence.
   - **(D)** *Does not apply the governing rule or explanation:* Secret sale fails the requirement to notify the affected vendor.
   - **(E)** *Too strong:* Conference timing does not equal imminent serious harm.

**Check:** Reproducible threat = yes; emergency exception = no; notify privately first.
::::
:::

:::problem[Question III.12]
Two clinics use the same scheduling provider. Clinic North stores complete patient addresses in an optional notes field, while Clinic South stores only a coded location category because full addresses are unnecessary for appointment scheduling. During a simulated exposure of that notes field, auditors found that an attacker could learn actual addresses from North's records but not from South's. They did not examine the clinics' other systems, and they did not measure the probability of a future real attack.

Which one of the following is most strongly supported by the information above?

- **(A)** Clinic South cannot experience a data breach of any kind.
- **(B)** Clinic North has already suffered a real attack.
- **(C)** The scheduling provider has no responsibility for security controls.
- **(D)** Storing less data necessarily prevents unauthorized access to the system.
- **(E)** Omitting unnecessary addresses from that field reduced the sensitive information exposed in the simulated incident.

::::solution[Solution]
**Answer:** (E)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The evidence supports a limited consequence of minimizing one data field.
2. **Support.** The same simulated exposure disclosed addresses for North but not South.
3. **Prephrase.** Stay within the simulated field and avoid predictions about breach probability.
4. **Why (E) is right.** (E) accurately states the observed difference without expanding it to whole-system immunity.
5. **Why the others fail.**
   - **(A)** *Unsupported inference:* Other data and systems were not tested, so absolute breach immunity is unwarranted.
   - **(B)** *Unsupported inference:* The exposure is explicitly a simulation, not a real incident.
   - **(C)** *Unsupported inference:* Provider obligations cannot be inferred from different data-entry practices.
   - **(D)** *Too strong:* Less data limits what one exposure reveals, not necessarily whether access occurs.

**Check:** Simulated compromise of one field: address available in North, not South.
::::
:::

:::problem[Question III.13]
A processor company tests a new heat spreader and claims that it reduced performance throttling during sustained workloads. Reviewers notice that the new spreader was installed in a newer batch of test boards, while the comparison boards were manufactured earlier. They point out that differences in processor silicon or cooling airflow might explain the result. The company's engineer says the spreader's thermal conductivity is higher, but the measured throttling difference, not the specification alone, is what needs causal explanation.

Which one of the following, if true, most strengthens the engineer's conclusion?

- **(A)** Customers prefer the exterior color of the new heat spreader.
- **(B)** The heat spreader can be recycled with common metals.
- **(C)** The new boards were purchased from a well-regarded supplier.
- **(D)** Swapping only the spreaders between otherwise identical boards reverses which boards throttle first under the same load and airflow.
- **(E)** Some workloads never cause throttling with either design.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer credits the new spreader for less throttling.
2. **Support.** Batch differences and airflow are plausible alternative causes in the original comparison.
3. **Prephrase.** Isolate the spreader in a controlled swap experiment.
4. **Why (D) is right.** (D) makes throttling track spreader identity while controlling boards, workload, and airflow.
5. **Why the others fail.**
   - **(A)** *Wrong causal or evidentiary target:* Consumer color taste has no bearing on throttling.
   - **(B)** *Wrong causal or evidentiary target:* Recyclability is an unrelated sustainability feature.
   - **(C)** *Wrong comparison:* Supplier reputation does not eliminate the batch confound.
   - **(E)** *Too strong:* Non-throttling light workloads do not distinguish performance under the sustained tests at issue.

**Check:** If outcome follows the spreader when it is swapped, the proposed cause tracks the effect.
::::
:::

:::problem[Question III.14]
A product compliance handbook states that whenever a manufacturer sells a device in Region X, it must submit an annual electrical-safety report. A founder tells investors that the company will not sell devices in Region X next year and therefore will not have to submit any electrical-safety reports. The company also sells in Regions Y and Z, which may have their own reporting rules, but the founder has not investigated them. The founder adds that the company has already removed Region X from its distribution map and does not anticipate any sales there through resellers next year.

The founder's argument is flawed because it...

- **(A)** assumes that all electrical-safety reports are too expensive.
- **(B)** presumes that the region's law is necessarily unconstitutional.
- **(C)** infers from the absence of one sufficient trigger for a duty that no other trigger can create that duty.
- **(D)** establishes the duty through an argument that is circular.
- **(E)** wrongly concludes that a reporting duty in Region X would require sales in Region Y.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The founder concludes no electrical-safety reports will be required.
2. **Support.** Selling in X triggers a report, but not selling there does not rule out duties elsewhere.
3. **Prephrase.** Locate denial of the antecedent, X sale → report; no X sale → no report.
4. **Why (C) is right.** (C) precisely names the possibility of other sufficient triggers.
5. **Why the others fail.**
   - **(A)** *Different flaw:* Costs of reports are never used in the inference.
   - **(B)** *Too strong:* No constitutional issue is raised.
   - **(D)** *Premise/conclusion or role swap:* The premise is a rule, not the conclusion restated.
   - **(E)** *Different flaw:* The founder denies X sales and says nothing linking its reports to Y sales.

**Check:** X → report; not X does not imply not report, since Y or Z may independently require one.
::::
:::

:::problem[Question III.15]
A firm's general counsel recommends disabling former employees' repository accounts immediately upon departure. The counsel argues that this will materially reduce the risk of confidential code being taken after an employee leaves, since the repository contains the latest source and credentials often remain active for days under the present system. The security team supports rapid revocation but notes that some former employees might already possess local copies. The counsel's prediction concerns the marginal risk from continued account access, not all possible avenues of leakage.

The counsel's argument depends on which one of the following assumptions?

- **(A)** Continued access by at least some departed employees presents a nonzero risk of obtaining confidential code not already in their possession.
- **(B)** No employee has ever copied a file before resigning.
- **(C)** Immediate revocation will eliminate every possible route by which former employees could disclose information.
- **(D)** The firm's competitors have never hired a former employee.
- **(E)** All repository accounts are hosted by a single cloud provider.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Counsel predicts risk reduction from ending postdeparture repository access.
2. **Support.** Credentials remain active and the repository has current code, but access must generate some risk for revocation to help.
3. **Prephrase.** The needed assumption is modest: a real marginal risk exists from open access.
4. **Why (A) is right.** Negating (A) means no departed employee could obtain any additional confidential code through continued access, eliminating the identified risk-reduction mechanism.
5. **Why the others fail.**
   - **(B)** *Timing shift:* Earlier copying may occur while future access still adds risk.
   - **(C)** *Too strong:* The counsel claims material reduction, not total elimination of leakage routes.
   - **(D)** *Too strong:* Competitor hiring is not required for unauthorized code acquisition to matter.
   - **(E)** *Too strong:* Hosting architecture does not determine whether revocation cuts a marginal risk.

**Check:** If continued credentials create zero incremental acquisition risk, disabling them cannot reduce that particular risk.
::::
:::

:::problem[Question III.16]
An administrator says that a triage algorithm is equitable because its overall error rate is low. A clinician responds that the average conceals substantially higher missed-urgent-case rates for one patient group, according to the clinic's own audit. She argues that procurement should consider that unequal distribution rather than relying solely on the overall rate. The clinician does not deny that the reported total error rate is correct; she disputes the administrator's use of that aggregate as decisive evidence of equitable performance.

The clinician's argument proceeds primarily by...

- **(A)** rejecting all quantitative measures in favor of personal intuition.
- **(B)** assuming that one group must always receive identical clinical outcomes to every other group.
- **(C)** challenging an inference from an aggregate statistic by identifying an important subgroup pattern it obscures.
- **(D)** claiming that the algorithm necessarily caused the differences in patients' underlying conditions.
- **(E)** using an unrelated historical analogy to discredit the administrator's motives.

::::solution[Solution]
**Answer:** (C)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The clinician concludes that overall error alone does not establish equitable performance.
2. **Support.** The audited subgroup missed-urgent-case rate differs despite the low aggregate.
3. **Prephrase.** Describe aggregate-versus-distribution criticism without denying the data.
4. **Why (C) is right.** (C) captures both acceptance of the overall figure and the subgroup qualification.
5. **Why the others fail.**
   - **(A)** *Argument-structure mismatch:* The clinician relies on audited quantitative information.
   - **(B)** *Too strong:* The criticism concerns missed cases, not a requirement of identical outcomes in every respect.
   - **(D)** *Too strong:* No causal claim about underlying clinical conditions is advanced.
   - **(E)** *Argument-structure mismatch:* The argument supplies subgroup evidence, not an analogy or personal attack.

**Check:** An overall mean can be accurate while concealing a subgroup disparity.
::::
:::

:::problem[Question III.17]
A licensing agreement specifies that any disputed royalty payment will be resolved either through a joint audit or through private arbitration, but not both. The parties have formally agreed not to arbitrate their current dispute. The compliance officer concludes that they must therefore use the joint audit mechanism. The conclusion does not depend on which mechanism is cheaper or more popular: it depends on the exhaustive choice given in the agreement and the elimination of one of the two available routes.

Which one of the following arguments is most parallel in its reasoning?

- **(A)** A package must be sent by courier or collected in person; it will not be collected in person; therefore it must be sent by courier.
- **(B)** A package might arrive by courier or rail; it arrived by courier; therefore it could not also have come by rail.
- **(C)** All audited reports are archived; this report is archived; therefore it was audited.
- **(D)** At least one applicant must present a portfolio; Mara has one; therefore every applicant has a portfolio.
- **(E)** If a factory is inspected it receives a notice; it received a notice; therefore it was inspected.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The officer concludes joint audit must be used.
2. **Support.** Exactly one of audit or arbitration is required and arbitration is excluded.
3. **Prephrase.** Match exhaustive disjunction plus rejection of one disjunct.
4. **Why (A) is right.** (A) reasons by disjunctive syllogism: courier or pickup; not pickup; hence courier.
5. **Why the others fail.**
   - **(B)** *Argument-structure mismatch:* 'Might' does not establish an exclusive disjunction, and courier arrival does not exclude a rail segment.
   - **(C)** *Reversal or direction trap:* This reverses audited → archived.
   - **(D)** *Too strong:* An existential claim about at least one applicant cannot support a universal conclusion.
   - **(E)** *Argument-structure mismatch:* It affirms the consequent of inspected → notice.

**Check:** P or Q; not Q; therefore P, in both arguments.
::::
:::

:::problem[Question III.18]
An investment analyst concludes that a chip manufacturer's newly acquired patent portfolio is stronger than its older portfolio. The analyst observes that licensing revenue associated with the newly acquired group was higher last year than revenue from the older group. But the acquired group contains more patents and several were already subject to long-term licenses at acquisition. The older portfolio, in contrast, is used primarily for the manufacturer's own products. The analyst nevertheless treats licensing income as a direct and fair comparison of underlying patent strength.

Which one of the following, if true, most weakens the analyst's argument?

- **(A)** Some licensees pay royalties at the end of each calendar year.
- **(B)** When comparable patents are evaluated individually by the same technical and legal criteria, the older group scores higher on average despite its lower licensing revenue.
- **(C)** The company employs attorneys who administer all license agreements.
- **(D)** Several engineers prefer internal use of the older portfolio's inventions.
- **(E)** The purchased patents are recorded in the firm's asset ledger.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The analyst infers greater inherent strength from the new portfolio's higher licensing revenue.
2. **Support.** Licensing arrangements, portfolio size, and internal use make revenue an unequal proxy.
3. **Prephrase.** Find a matched per-patent quality assessment that contradicts the claimed ranking.
4. **Why (B) is right.** (B) directly supplies the opposite rating on the actual property at issue while controlling for size and use.
5. **Why the others fail.**
   - **(A)** *Timing shift:* Payment timing does not by itself reverse the relative strength comparison.
   - **(C)** *Too strong:* Having patent counsel administer contracts does not validate royalties as a quality measure.
   - **(D)** *Wrong causal or evidentiary target:* Engineering preferences hint at utility but do not compare legal and technical strength as directly as (B).
   - **(E)** *Wrong causal or evidentiary target:* Accounting recognition adds no evidence of relative patent merit.

**Check:** Higher income can coexist with lower average patent strength because income depends on licensing practices and portfolio size.
::::
:::

:::problem[Question III.19]
Arin: A patent pool for wireless devices should publish its royalty schedule. Transparent rates would make it easier for small manufacturers to plan, although the pool could still negotiate discounts for special cases. Bela: Small manufacturers need predictable pricing, but publishing a common schedule would make it harder to accommodate unusual technologies. The pool should communicate tailored rates privately instead, even if outsiders cannot compare offers. Both advisers agree that a pool can reduce the number of separate negotiations a manufacturer faces.

The speakers disagree about whether...

- **(A)** small device manufacturers benefit from knowing licensing costs in advance.
- **(B)** a patent pool can simplify negotiations with multiple patent owners.
- **(C)** every manufacturer should be charged an identical royalty.
- **(D)** publicly publishing the pool's royalty schedule would be desirable.
- **(E)** negotiated rates can ever differ between licensing arrangements.

::::solution[Solution]
**Answer:** (D)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Arin supports publishing rates while Bela opposes publication in favor of private tailoring.
2. **Support.** Both value predictable pricing and permit variation among arrangements.
3. **Prephrase.** Locate a yes/no policy disagreement, not shared goals or unsupported absolutes.
4. **Why (D) is right.** (D) draws opposite clear answers: Arin yes, Bela no.
5. **Why the others fail.**
   - **(A)** *Argument-structure mismatch:* Both want smaller firms to plan predictable costs.
   - **(B)** *Argument-structure mismatch:* Both agree pooling simplifies separate negotiations.
   - **(C)** *Argument-structure mismatch:* Arin allows special discounts; Bela advocates tailored rates, so neither demands identical rates.
   - **(E)** *Argument-structure mismatch:* Both accept differentiated terms, disagreeing about whether the schedule should be public.

**Check:** Publish schedule? Arin yes; Bela no.
::::
:::

:::problem[Question III.20]
A payment processor reports that the fraction of transactions flagged as fraudulent fell from two percent to one percent after it expanded its service. Its chief executive calls this definitive proof that fraud-prevention efforts reduced the absolute number of fraudulent transactions. Yet total transaction volume increased dramatically over the same period, and no absolute count was supplied. The executive insists that because the fraud rate was cut in half, the company must now be dealing with fewer fraudulent transactions in total.

The argument is vulnerable to criticism because it...

- **(A)** assumes that fraudulent transactions are always fully reimbursed.
- **(B)** denies that a percentage can ever provide useful information.
- **(C)** treats fraud rates as unrelated to transaction counts under all circumstances.
- **(D)** assumes that all new customers make transactions of identical value.
- **(E)** overlooks that a lower percentage of a larger total can correspond to a higher absolute number.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The chief executive concludes absolute fraud count fell.
2. **Support.** The fraud rate halved, but the total number of transactions rose greatly.
3. **Prephrase.** Check numerator = rate × volume, rather than assuming a lower rate means fewer incidents.
4. **Why (E) is right.** (E) pinpoints the changing denominator that can reverse the absolute-count inference.
5. **Why the others fail.**
   - **(A)** *Too strong:* Reimbursement is not part of the fraud-count arithmetic.
   - **(B)** *Different flaw:* The executive uses a percentage as informative, but overextends what it proves.
   - **(C)** *Too strong:* The problem is missing volume information, not claiming rates and counts are unrelated.
   - **(D)** *Too strong:* Transaction value does not determine how many transactions are fraudulent.

**Check:** 2% of 1,000 = 20; 1% of 3,000 = 30, a lower rate and higher count.
::::
:::

:::problem[Question III.21]
A software manager declares that the company has only two choices for its new programming interface: publish every internal engineering document or keep the interface completely private. Publishing all documents would expose confidential designs, so the manager concludes the interface must remain private. Some engineers note that competitors often publish interface references without disclosing internal design files, but the manager says such experiences do not alter the two choices the company now faces.

Which one of the following arguments contains the most similar flaw?

- **(A)** If a bridge is closed the road is diverted; the bridge is closed; therefore traffic is diverted.
- **(B)** A report is either public or confidential under a policy that expressly excludes all middle categories; it is not public; therefore it is confidential.
- **(C)** Some writers are editors; all editors are paid; therefore some writers are paid.
- **(D)** A committee has three defined options and rules out two; it selects the remaining option.
- **(E)** A store must either raise every price or shut down; customers would resent across-the-board increases; therefore the store must shut down.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The manager concludes total secrecy is necessary.
2. **Support.** The argument eliminates one dangerous extreme after falsely limiting choices to two extremes.
3. **Prephrase.** Match an unjustified binary that hides a middle alternative.
4. **Why (E) is right.** (E) assumes only total price increases or closure and excludes selective changes, just as the original excludes limited publication.
5. **Why the others fail.**
   - **(A)** *Different flaw:* This is valid modus ponens with no false alternatives.
   - **(B)** *Different flaw:* The policy explicitly makes the two categories exhaustive, so the inference is valid in its stipulated system.
   - **(C)** *Too strong:* This is a valid existential inference, not an invented dilemma.
   - **(D)** *Different flaw:* Three truly defined options with two excluded is not an unjustified binary.

**Check:** Both original and (E) omit a feasible compromise, so eliminating one extreme need not force the other.
::::
:::

:::problem[Question III.22]
A fictional firm's policy provides that every report classified as a critical incident must be examined by the board's risk committee. The chief auditor has established that all alerts generated by Detector Q are independently verified. From this, the auditor concludes that every Detector Q alert must reach the risk committee. But a verified alert is not necessarily classified as a critical incident under the stated policy, and there is no direct committee rule for all verified alerts.

Which one of the following, if assumed, enables the auditor's conclusion to be properly drawn?

- **(A)** Some critical incidents were never generated by Detector Q.
- **(B)** Every alert examined by the committee is independently verified.
- **(C)** Some independently verified alerts are never classified as critical.
- **(D)** Every independently verified alert is classified as a critical incident.
- **(E)** No Detector Q alert is ever classified incorrectly.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The auditor concludes that every Q alert reaches the committee.
2. **Support.** Q → independently verified; critical → committee; missing verified → critical.
3. **Prephrase.** Supply the forward bridge from the existing premise to the policy trigger.
4. **Why (D) is right.** (D) completes Q → verified → critical → committee, proving the universal conclusion.
5. **Why the others fail.**
   - **(A)** *Too strong:* Other sources of critical incidents do not address whether Q's alerts are critical.
   - **(B)** *Reversal or direction trap:* Committee → verified is the reverse of the required verified → committee path.
   - **(C)** *Too strong:* This could supply counterinstances to the desired generalization, not justify it.
   - **(E)** *Quantifier shift:* Classification accuracy could coexist with all Q alerts being classified noncritical.

**Check:** Q → verified → critical → committee follows once (D) is inserted.
::::
:::

:::problem[Question III.23]
A processor company proposes giving engineering firms a month-long evaluation license for a premium chip design tool. Its product manager argues that the trial will increase purchases because firms will see how quickly the tool performs demanding simulations and then choose it over their current products. Some prospective customers have never used the tool, while others have strong existing vendor relationships. The manager assumes that the speed experienced during evaluation will influence at least some firms' buying decisions rather than being irrelevant to the purchasing process.

The manager's argument depends on assuming which one of the following?

- **(A)** All engineering firms run exactly the same simulation workloads.
- **(B)** The premium tool is the least expensive option available.
- **(C)** At least some prospective customers' purchasing decisions can be influenced by performance they experience during the evaluation.
- **(D)** Every evaluator will buy a license immediately after the trial.
- **(E)** Existing vendors cannot improve their products during the next year.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The manager predicts trials will convert customers by exposing performance.
2. **Support.** The trial showcases speed, but speed must matter in some prospective purchase decisions.
3. **Prephrase.** Identify the minimal causal link between experience and buying choice.
4. **Why (C) is right.** If (C) is false, experience during the trial changes no prospective customer's buying decision, destroying the suggested conversion mechanism.
5. **Why the others fail.**
   - **(A)** *Too strong:* Identical workloads are unnecessary; speed can matter for diverse workloads.
   - **(B)** *Not required:* A premium tool may gain buyers on performance despite higher cost.
   - **(D)** *Too strong:* Universal immediate conversion is far stronger than a predicted increase.
   - **(E)** *Quantifier shift:* Rivals may improve while trials still influence some decisions.

**Check:** Negating (C) removes all purchase decisions influenced by trial performance.
::::
:::

:::problem[Question III.24]
A hardware firm considers adding an independent technical arbitrator to resolve disagreements over royalty calculations. Its lawyer predicts that the process will reduce time spent disputing license payments, arguing that many past disputes lasted because the parties could not agree on how to measure product usage. Critics say some delays were caused by the parties' inability to pay rather than measurement disagreements, so a technical expert might not help. The firm has records of dispute durations but has not yet separated measurement disputes from payment-capacity disputes.

Which one of the following, if true, most strengthens the lawyer's prediction?

- **(A)** In a randomized pilot involving otherwise similar measurement disputes, cases assigned to the independent technical arbitrator reached agreement substantially sooner than cases handled through the usual process.
- **(B)** The arbitrator's office has a modern website and a useful appointment system.
- **(C)** The license agreements use different fonts to distinguish royalty rates from definitions.
- **(D)** Some firms settle licensing disputes without ever speaking to an arbitrator.
- **(E)** A few past disputes concerned whether licensees had sufficient cash to pay.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The lawyer predicts faster resolution because neutral technical interpretation breaks measurement impasses.
2. **Support.** Existing durations combine measurement and cash-flow delays.
3. **Prephrase.** Isolate the kind of dispute arbitration is designed to solve and measure comparative duration.
4. **Why (A) is right.** (A) directly tests the intervention against a matched control for the relevant disputes.
5. **Why the others fail.**
   - **(B)** *Wrong causal or evidentiary target:* Scheduling convenience is not evidence of shorter substantive disagreements.
   - **(C)** *Wrong causal or evidentiary target:* Contract typography does not measure dispute resolution with or without an expert.
   - **(D)** *Wrong causal or evidentiary target:* Other settlement routes exist but do not undermine or establish the proposed speed benefit.
   - **(E)** *Wrong causal or evidentiary target:* Payment incapacity is an alternative type, but its presence does not test arbitration's effect on measurement cases.

**Check:** Random assignment within measurement disputes makes the observed shorter duration good causal evidence.
::::
:::

:::problem[Question III.25]
A research lab follows this rule: confidential technical information may be disclosed without the owner's ordinary approval only when such disclosure is necessary to prevent an imminent and serious threat to people, and the disclosure must be limited to what responders need. A technician discovers that a prototype battery may overheat at a public demonstration beginning in minutes. The owners cannot be reached, and the technician has reliable evidence that emergency responders need the internal shutdown procedure to prevent an imminent fire.

Which one of the following courses of action is most justified by the stated rule?

- **(A)** Publish the entire research archive online so everyone has the same information.
- **(B)** Give responders the necessary shutdown procedure while withholding unrelated confidential designs.
- **(C)** Remain silent until the ordinary approval process finishes, regardless of the danger.
- **(D)** Sell the shutdown procedure to a competitor after the demonstration.
- **(E)** Disclose unrelated prototypes' secrets as punishment for the owners' absence.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The principle authorizes a limited exception for necessary prevention of imminent serious human harm.
2. **Support.** The battery situation satisfies the threat and necessity conditions, and responders need only particular instructions.
3. **Prephrase.** Apply both the emergency permission and the minimization restriction.
4. **Why (B) is right.** (B) provides the necessary procedure without disclosing irrelevant secrets, satisfying both parts.
5. **Why the others fail.**
   - **(A)** *Does not apply the governing rule or explanation:* Entire archives exceed the information necessary for responders.
   - **(C)** *Does not apply the governing rule or explanation:* This disregards the explicit emergency exception.
   - **(D)** *Does not apply the governing rule or explanation:* Commercial sale after the event does not prevent the imminent threat.
   - **(E)** *Does not apply the governing rule or explanation:* Punishment and unrelated disclosures are outside the narrow emergency need.

**Check:** Imminent serious threat + necessary information → limited disclosure, not blanket release.
::::
:::


## 33.4 Scoring and review

**Raw score:** Count one point for each correct answer, from **0 to 77**. There is **no reliable 120–180 conversion** for this original, uncalibrated test; use the raw score, timing notes, flagged questions, and error log to measure progress.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| I.1 | C | Flaw | 9 |
| I.2 | A | Strengthen | 8 |
| I.3 | E | Necessary assumption | 7 |
| I.4 | B | Must be true | 10 |
| I.5 | D | Resolve the paradox | 13 |
| I.6 | B | Main conclusion | 11 |
| I.7 | D | Weaken | 8 |
| I.8 | A | Sufficient assumption | 7 |
| I.9 | C | Flaw | 9 |
| I.10 | E | Role of a statement | 11 |
| I.11 | D | Principle | 13 |
| I.12 | C | Most strongly supported | 10 |
| I.13 | B | Necessary assumption | 7 |
| I.14 | E | Method of reasoning | 11 |
| I.15 | A | Flaw | 9 |
| I.16 | A | Parallel reasoning | 12 |
| I.17 | E | Weaken | 8 |
| I.18 | C | Strengthen | 8 |
| I.19 | D | Point at issue | 11 |
| I.20 | B | Flaw | 9 |
| I.21 | E | Evaluate | 8 |
| I.22 | B | Parallel flaw | 12 |
| I.23 | D | Necessary assumption | 7 |
| I.24 | A | Weaken | 8 |
| I.25 | C | Principle | 13 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| II.1 | B | RC main point | 18 |
| II.2 | D | RC detail | 18 |
| II.3 | A | RC inference | 18 |
| II.4 | E | RC function | 18 |
| II.5 | C | RC inference | 18 |
| II.6 | B | RC analogy | 18 |
| II.7 | D | RC attitude | 18 |
| II.8 | C | RC main point | 18 |
| II.9 | A | RC detail | 18 |
| II.10 | E | RC function | 18 |
| II.11 | B | RC inference | 18 |
| II.12 | D | RC primary purpose | 18 |
| II.13 | A | RC attitude | 18 |
| II.14 | C | RC organization | 18 |
| II.15 | E | RC comparative relationship | 17 |
| II.16 | B | RC comparative agreement | 17 |
| II.17 | D | RC comparative disagreement | 17 |
| II.18 | A | RC comparative response | 17 |
| II.19 | C | RC comparative inference | 17 |
| II.20 | E | RC comparative response | 17 |
| II.21 | A | RC main point | 18 |
| II.22 | D | RC detail | 18 |
| II.23 | B | RC inference | 18 |
| II.24 | C | RC function | 18 |
| II.25 | E | RC inference | 18 |
| II.26 | A | RC attitude | 18 |
| II.27 | E | RC organization | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| III.1 | D | Strengthen | 8 |
| III.2 | B | Flaw | 9 |
| III.3 | A | Must be true | 10 |
| III.4 | E | Necessary assumption | 7 |
| III.5 | C | Resolve the paradox | 13 |
| III.6 | A | Main conclusion | 11 |
| III.7 | C | Weaken | 8 |
| III.8 | E | Role of a statement | 11 |
| III.9 | B | Sufficient assumption | 7 |
| III.10 | D | Flaw | 9 |
| III.11 | B | Principle | 13 |
| III.12 | E | Most strongly supported | 10 |
| III.13 | D | Strengthen | 8 |
| III.14 | C | Flaw | 9 |
| III.15 | A | Necessary assumption | 7 |
| III.16 | C | Method of reasoning | 11 |
| III.17 | A | Parallel reasoning | 12 |
| III.18 | B | Weaken | 8 |
| III.19 | D | Point at issue | 11 |
| III.20 | E | Flaw | 9 |
| III.21 | E | Parallel flaw | 12 |
| III.22 | D | Sufficient assumption | 7 |
| III.23 | C | Necessary assumption | 7 |
| III.24 | A | Strengthen | 8 |
| III.25 | B | Principle | 13 |

:::

| Question types to revisit | Where to review |
| --- | --- |
| Conditional inference and quantifiers | Chapter 5 |
| Flaw analysis and causal alternatives | Chapters 6 and 9 |
| Necessary and sufficient assumption | Chapter 7 |
| Strengthen, weaken, evaluate | Chapter 8 |
| Must be true and most strongly supported | Chapter 10 |
| Conclusion, role, method, disagreement | Chapter 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Paradox and principle | Chapter 13 |
| Reading for structure and author viewpoints | Chapter 15 |
| Comparing two passages | Chapter 17 |
| RC main point, detail, inference, function, attitude | Chapter 18 |

Review flagged correct guesses as carefully as misses: ask which word in the stem or choice you misread, what competing answer attracted you, and what textual fact would have decided the question under time pressure.
