---
title: "Appendices A–L"
source: "lsat_appendices.html"
---

Back Matter

# Appendices A–L

Quick-reference material to keep beside you while you drill — the catalogs, cheat sheets, tables, and checklists distilled from the twenty-seven chapters.

## Appendix A · Master Flaw Catalog

Every common reasoning flaw (Chapters 6, 9), with its tell and the LSAT's stock phrasing.

| Flaw | The tell | Stock answer phrasing |
| --- | --- | --- |
| **Causal** (correlation→cause) | evidence is a correlation; conclusion says "causes/produces/leads to" | "takes for granted that one thing caused another"; "fails to consider another factor"; "overlooks that causation may be reversed" |
| **Necessary/sufficient** | "required" treated as "enough" (or reverse) | "treats a necessary condition as though it were sufficient" |
| **Unrepresentative sample** | biased/self-selected group → whole population | "relies on a sample unlikely to be representative" |
| **Small sample** | too few cases → general claim | "draws a general conclusion from too few instances" |
| **Percentage/number** | a proportion treated as a count (or reverse) | "infers an amount from a proportion" |
| **Ad hominem** | attacks the person/source, not the claim | "rejects a position merely by criticizing its proponent" |
| **Appeal to authority/popularity** | "experts/most people say so → true" | "takes the fact that a view is widely held as evidence of its truth" |
| **Appeal to ignorance** | "not disproven → true" (or reverse) | "infers a claim is true merely because it has not been shown false" |
| **Equivocation** | a key word shifts meaning mid-argument | "relies on a term used in two different senses" |
| **Circular reasoning** | premise = conclusion restated | "presupposes what it sets out to establish" |
| **Composition/division** | part↔whole property transfer | "assumes what is true of the parts is true of the whole" |
| **False dilemma** | "only two options" when more exist | "treats two alternatives as though they were exhaustive" |

## Appendix B · Conditional Logic & Quantifier Cheat Sheet

From Chapter 5. Translate, then reason.

### Translations

"If A, then B"  →  A

→

B

"A only if B"  →  A

→

B

(only if = necessary side)

"Only A are B" →  B

→

A

(arrow points to "only")

"All A are B"  →  A

→

B

"No A are B"  →  A

→

not B

"A unless B"  →  not B

→

A

(unless = if not)

"A requires B" →  A

→

B

### Contrapositive (always valid)

A → B    ↔   not B → not A

✓

reverse AND negate; flip and↔or on the branched side

(A and B) → C ↔  not C → (not A or not B)

✗

converse  B → A

(reversed only)

✗

inverse   not A → not B

(negated only)

### The four forms

VALID

modus ponens:  A→B, A &there4; B

VALID

modus tollens:  A→B, not B &there4; not A

WRONG

affirming consequent:  A→B, B &there4; A

WRONG

denying antecedent:  A→B, not A &there4; not B

### Quantifiers

| Given | Valid | Invalid |
| --- | --- | --- |
| Some A are B | Some B are A | Most/All A are B; some A not B |
| Most A are B | Some A are B | Most B are A |
| All A are B | Some A are B; contrapositive | All B are A |

**Chaining:** All A→B + All B→C gives All A→C. Most A are B + All B are C gives Most A are C. **Two "some" never chain; two "most" never chain.**

## Appendix C · Question-Type Identification Flowchart

Read the LR stem, then act (Chapters 4, 7–13).

| If the stem says… | Type | Your move |
| --- | --- | --- |
| "depends on / requires / assumes" | Necessary Assumption | Find the required link; verify with the negation test |
| "if assumed, conclusion follows" | Sufficient Assumption | Diagram; supply the conditional that completes the chain |
| "most strengthens / supports the argument" | Strengthen | Affirm the assumption / rule out an alternative |
| "most weakens / undermines" | Weaken | Deny the assumption / supply an alternative cause |
| "vulnerable to criticism / flawed because" | Flaw | Pre-phrase the flaw (App. A); match the description |
| "must be true / most supported" | Inference | Combine facts; defend from the text; no outside knowledge |
| "proceeds by / method of reasoning" | Method | Describe the moves abstractly |
| "the claim that \_\_\_ plays which role" | Role | Map the argument; read off the sentence's job |
| "disagree about whether" | Point at Issue | Find the claim one affirms, the other denies |
| "most similar in its reasoning" | Parallel (/ Flaw) | Abstract to a skeleton; match form, strength, validity |
| "resolve / explain the discrepancy" | Paradox | Find the fact that lets both statements be true |
| "conforms to / justifies which principle" | Principle | Treat as conditional; apply (must-be-true) or justify (sufficient assumption) |

## Appendix D · Wrong-Answer Flavor Reference

The five recurring trap types (Chapter 4). Name the flavor to eliminate fast.

| Flavor | What it does | The tell |
| --- | --- | --- |
| **Out of scope** | introduces something the argument never dealt with | you can't tie it to the conclusion |
| **Opposite (reversal)** | does the reverse of the task (strengthens on a Weaken) | relevant but pointed the wrong way |
| **Too strong / extreme** | uses all/never/only/proves the modest argument can't support | one overstated word breaks it |
| **Half-right** | first clause perfect, second clause distorted | you nod, then hit a wrong word |
| **True but useless** | true (often real-world true) but doesn't affect the conclusion | "yes, and…?" |

**Defense test (App. C companion):** for any candidate, finish "correct *because the text says* \_\_\_." If you can't point to words, it's a trap.

## Appendix E · Score Conversion & Percentile Tables

From Chapter 3. Approximate, recent (~2025) — for planning only; confirm current data at lsac.org.

| Scaled score | ~Percentile | Reads as |
| --- | --- | --- |
| 180 | ~99.9th | perfect / near-perfect |
| 175 | ~99th | top 1% |
| 170 | ~95th | top 5% |
| 165 | ~86th | top ~14% — scholarship territory |
| 160 | ~73rd | top quarter |
| 157 | ~66th | solidly above average |
| 155 | ~58th | above average |
| 152 | ~50th | ≈ median test-taker |
| 150 | ~44th | just below median |
| 145 | ~26th | below median |
| 140 | ~13th | well below median |

**Key facts:** scale 120–180; no wrong-answer penalty (always guess); the curve is densest near the middle, so 150→160 is far easier than 165→175; raw→scaled is *equated* per form.

## Appendix F · Indicator-Word Lists

From Chapters 4 and 15.

| Conclusion indicators (LR) | Premise indicators (LR) | Pivot words (RC) |
| --- | --- | --- |
| therefore, thus, hence, so | because, since, for | but, however, yet |
| consequently, it follows that | given that, as, after all | although, nevertheless |
| clearly, this shows/means that | the reason is, on the grounds that | in contrast, whereas |
| we can conclude that | as indicated by, in that | on the other hand, still |

**Attribution cues (a view is likely *not* the author's):** "some argue," "critics contend," "traditionally," "it is widely held," "proponents claim," "according to X." **Attitude cues:** surprisingly, unfortunately, admittedly, crucially, importantly.

## Appendix G · Stamina Reading List

From Chapters 1 and 16. Optional dense-nonfiction to build comfort with hard prose — a habit, not a syllabus. You're training the *skill* of reading argument-heavy text, not the content.

- **General/argumentative:** *The Economist*, *The Atlantic*, *The New Yorker* (long features), *Harper's*.
- **Ideas/philosophy:** *Aeon*, *The New York Review of Books*, *London Review of Books*.
- **Science (for lay readers):** *Scientific American*, *Quanta Magazine*, *Nautilus*.
- **Law/policy (accessible):** reputable legal commentary and long-form policy essays.

Read a few pieces a week, actively: find the thesis, note the structure, track whose view is whose. This mirrors the structural reading of Chapter 15.

## Appendix H · Resource Directory

From the prep guide and Chapter 24. Start free with official material; the most important resource is real, official, previously-administered LSAT questions.

### Official (LSAC) — use first

- **LawHub** ([lsac.org/lsat/prep](https://www.lsac.org/lsat/prep)) — official platform; free tier includes several full official PrepTests in the exact test-day interface. **LawHub Advantage** (paid yearly) unlocks a large PrepTest library — the best single purchase for most people.
- **Khan Academy / official free prep** — free guided lessons and practice; excellent zero-cost start.
- **Official PrepTest books** — past tests in print, useful for untimed drilling off-screen.

### Paid (optional)

- **Self-paced platforms** — e.g., 7Sage, Blueprint, LSAT Demon, Manhattan, Princeton Review, Kaplan (lessons + analytics + question banks). Many offer free trials.
- **Books** — e.g., *The LSAT Trainer* for affordable self-study fundamentals.
- **Tutoring** — highest cost; reserve for stubborn plateaus.

**Budget stack:** free LawHub + Khan to learn types → one affordable book/course for structure → LawHub Advantage for a deep well of official PTs. **Fee help:** apply for an [LSAC fee waiver](https://www.lsac.org) before paying if cost is a barrier.

## Appendix I · Test-Day Checklist

From Chapter 27.

### Week before

- Confirm date, time, tech & environment requirements; run LSAC's system check early.
- Last full PT 3–7 days out; then taper to light review.
- Bank good sleep across several nights.

### Day before

- No new material, no full PT — light, confidence-building review at most.
- Prep space: clear desk, allowed scratch materials, water, valid ID.
- Relax; reasonable bedtime.

### During

- Answer every question; guess-fill blanks with ~30 sec left.
- Flag-and-guess time-sinks (~2 min, no path); don't get stuck.
- Treat every section as scored; use the break to reset; let a bad section go.

### After

- Complete the Argumentative Writing task promptly (gates score release).
- Wait for the score; decide on a retake with medians, timing, and a fix-plan in view.

## Appendix J · Error-Log Template

From Chapter 23. Copy these columns into a spreadsheet; one row per missed or lucky-guess question. Consistent labels make sorting reveal patterns.

| Column | What to record | Example |
| --- | --- | --- |
| Date | when you did it | 6/12 |
| Source | PT #, section, question | PT 73, S2, Q14 |
| Type | consistent type label | Nec. Assumption |
| Picked / Correct | your answer / right answer | B / D |
| Cause | timing vs. knowledge (from blind review) | Knowledge |
| Flavor | which trap caught you (App. D) | true-but-useless |
| Why / Takeaway | the misstep + the rule to prevent it | Didn't negate; *rule: always run the negation test* |

**Every week or two:** sort by Type, by Cause, and by Flavor; the top count is your next drilling priority. (Ask and I can generate this as a ready-to-use .xlsx.)

## Appendix K · Glossary of LSAT Terms

| Term | Meaning |
| --- | --- |
| **Stimulus** | the paragraph in an LR question (argument or set of facts) |
| **Stem** | the sentence stating your task ("which most weakens…") |
| **Conclusion** | the main claim an argument tries to establish |
| **Premise** | a statement offered as support for the conclusion |
| **Assumption** | an unstated premise the argument needs (necessary or sufficient) |
| **The gap** | the logical distance between premises and conclusion |
| **Contrapositive** | the valid "reverse-and-negate" of a conditional (not B → not A) |
| **Credited response** | the answer LSAC counts as correct — defensible strictly from the text |
| **Aposematism / etc.** | (any topic term) — defined in the passage; requires no outside knowledge |
| **Experimental section** | the unscored, unlabeled section used to pretest questions |
| **Equating** | the adjustment making a scaled score mean the same across test forms |
| **Percentile** | the % of test-takers you scored above |
| **Blind review** | re-solving uncertain questions untimed before checking the key |
| **PT** | PrepTest — an official practice LSAT |
| **CAS** | Credential Assembly Service — bundles scores/transcripts/letters to schools |
| **Splitter** | applicant with high LSAT but lower GPA (reverse-splitter = the opposite) |

## Appendix L · Answer Keys & Solutions Index

All practice in this book has **collapsible solutions inline** — click "Show all solutions" above any practice block, or expand an individual "Solution" toggle. There's no separate answer key because each solution *teaches* (why the right answer is right and why the wrong ones are wrong), which is how you should review (Chapter 22).

**Where the worked examples and drills live, by chapter:**

| Topic | Chapter(s) |
| --- | --- |
| Argument foundations, wrong-answer flavors | [Ch 4](./lsat_ch4_foundations.html) |
| Conditional logic & forms | [Ch 5](./lsat_ch5_logic.html) |
| Flaws (catalog & matching) | [Ch 6](./lsat_ch6_flaws.html), [Ch 9](./lsat_ch9_flaw.html) |
| Question types (Assumption → Principle) | [Ch 7](./lsat_ch7_assumption.html)–[Ch 13](./lsat_ch13_paradox_principle.html) |
| Reading Comprehension | [Ch 15](./lsat_ch15_reading_structure.html)–[Ch 18](./lsat_ch18_rc_questions.html) |
| Writing task (annotated sample) | [Ch 20](./lsat_ch20_writing.html) |
| Study method (blind review, error log) | [Ch 22](./lsat_ch22_blind_review.html), [Ch 23](./lsat_ch23_error_log.html) |

LSAT Mastery — Appendices A–L. Independent study material, not affiliated with LSAC. Percentiles, fees, formats, and policies change — verify current specifics at lsac.org. Practice content throughout is original; use official LSAC PrepTests for timed practice.
