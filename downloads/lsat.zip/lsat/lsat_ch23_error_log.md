---
title: "The Error Log"
source: "lsat_ch23_error_log.html"
---

Part V · Chapter 23

# The Error Log

Blind review tells you why you missed *one* question. The error log aggregates those findings across weeks so your *patterns* become visible — turning "I'm just bad at LR" into a precise, fixable list.

**Est. study time:** 35–45 min — **Sections:** 4 — **Practice:** 14+ items

## Overview

Blind review (Chapter 22) is powerful per-question, but its lessons evaporate if you don't *record* them. The error log is the memory of your prep: a simple running record of every miss — what type it was, why you got it wrong, and the takeaway. Its magic is **aggregation**. One missed Assumption question tells you little; but when your log shows you've missed *nine* Assumption questions in three weeks, always because you didn't run the negation test, you've found a precise, high-value target. The log converts a scatter of individual mistakes into a ranked to-do list — and it's the tool that keeps your practice pointed at your actual weaknesses instead of drifting.

:::callout-tip
Prerequisites

Chapter 22 (blind review produces the per-question diagnosis — timing vs. knowledge gap — and the five-step takeaway that you log here) and Chapter 21 (the gap analysis this log continuously updates). The error log is where those two chapters' outputs accumulate.
:::

## 23.1 · What to record per miss

:::callout-intuition
Intuition first

The log only helps if each entry is *searchable* and *diagnostic*. A one-line entry per missed question, with a few consistent fields, is enough — you're not writing an essay, you're tagging data so patterns can surface later. The key fields answer: *what* question, *what type*, *why* I missed it, was it *timing or knowledge*, and *what's the rule* to prevent it.
:::

:::definition
**Definition 23.1 — The error-log entry.** A single row per missed (or lucky-guess) question, recording at minimum: **date**, **source** (PT#/section/question), **question type**, **what I picked** vs. **correct answer**, **cause** (timing vs. knowledge, from blind review), **why I missed it** (the specific misstep / trap flavor), and **the takeaway rule**. A spreadsheet is ideal because you can sort and filter it.
:::

### A sample log format

| Date | Source | Type | Picked / Correct | Cause | Why / Takeaway |
| --- | --- | --- | --- | --- | --- |
| 6/12 | PT 73, S2, Q14 | Nec. Assumption | B / D | Knowledge | Didn't run negation test; picked a "helpful" but not required choice. *Rule: always negate.* |
| 6/12 | PT 73, S2, Q19 | Weaken | A / C | Knowledge | Chose true-but-useless (on-topic, no effect on conclusion). *Rule: pre-phrase the alternative cause.* |
| 6/13 | PT 73, S3, Q23 | RC detail | D / B | Timing | Rushed, answered from memory. *Rule: go back to the lines.* |

:::callout-tip
Keep it fast and consistent

Use **consistent labels** for type and cause (so you can sort), and keep the "why/takeaway" to a phrase. If logging is laborious you won't do it — aim for ~30–60 seconds per entry after your five-step review has already produced the takeaway. Consistency matters more than detail: "Nec. Assumption" every time (not sometimes "assumption," sometimes "NA") is what makes sorting reveal patterns.
:::

:::callout-pitfall
Watch out for these mistakes

- **Recording only the score or the right answer.** The *type*, *cause*, and *takeaway* are what make the log useful; the answer letter alone teaches nothing.
- **Inconsistent labels.** If you tag types differently each time, sorting can't reveal patterns. Standardize your categories.
- **Making entries so long you stop logging.** A phrase per field is enough. The habit only survives if it's quick.
:::

### Practice — 23.1

:::problem[Q1]{difficulty="easy"}
Name four fields every error-log entry should have.

::::solution[Solution]
Any four of: **date, source (PT/section/Q), question type, picked vs. correct, cause (timing/knowledge), why/takeaway**. Type, cause, and takeaway are the most important for finding patterns.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why record the *cause* (timing vs. knowledge), not just the type?

::::solution[Solution]
Because the cause determines the **fix** (Chapter 22): timing gaps need pacing work, knowledge gaps need re-study. Logging the cause lets you later see whether your misses are mostly speed or mostly understanding.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is a spreadsheet better than a notebook for the log?

::::solution[Solution]
Because you can **sort and filter** it — e.g., count misses by type, or filter to knowledge gaps — which is exactly how patterns surface. A notebook can't aggregate.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does consistency of labels matter more than richness of detail?

::::solution[Solution]
Because the log's value comes from **aggregation by sorting**, which only works if identical categories are labeled identically. Rich prose in each entry can't be counted; consistent tags ("Nec. Assumption," "timing") can be, so patterns emerge. A terse but standardized log beats a detailed but inconsistent one.
::::
:::

## 23.2 · Sorting the log to find patterns

:::callout-intuition
Intuition first

Every week or two, *sort* your log — by question type, by cause, by trap flavor — and **count**. The category at the top of the count is your single most valuable study target: the place where fixing one thing recovers the most points. This turns your study from "do more questions and hope" into "attack the specific weakness the data just named." The log doesn't just record the past; it *writes your next study session's agenda.*
:::

:::definition
**Definition 23.2 — Pattern analysis.** Periodically sorting and tallying the error log to surface your highest-frequency weaknesses. Sort by **type** (which question types you miss most), by **cause** (timing vs. knowledge balance), and by **trap flavor** (which wrong-answer flavors catch you). The top counts set your drilling priorities (Chapter 21).
:::

:::example
Worked Example 23.1 — the log names the target

standard

**Scenario.** After two weeks, you sort your log. By type: Weaken 9 misses, Assumption 7, Flaw 3, everything else ≤2. By cause: 15 knowledge, 6 timing. By flavor: "true but useless" tagged on 8 of the misses.

**Question.** What does the log tell you to do next?

Answer: Block-drill Weaken and Assumption (your two biggest clusters, mostly knowledge gaps), and specifically train yourself to reject "true but useless" answers — the trap flavor that's catching you across types.

**How we get there.** Three cuts, three insights. *By type:* Weaken (9) and Assumption (7) dwarf everything else — those are your priority drills (Chapters 7–8). *By cause:* 15 of 21 are knowledge gaps, so the fix is mostly *re-learning and drilling*, not just speed. *By flavor:* "true but useless" appears on 8 misses — a cross-cutting habit of picking on-topic-but-inert answers, so a targeted rule ("ask what the answer *does* to the conclusion," Chapter 4) will help across all types. Without the log, you'd have a vague sense of struggling; with it, you have three precise, ranked targets. **Teaching point:** the same data sorted three ways yields a complete, prioritized study plan.
:::

:::callout-pitfall
Watch out for these mistakes

- **Logging but never sorting.** A log you don't analyze is just a diary. The value is in the periodic tally that names your top weakness.
- **Drilling your favorite types.** Let the counts, not your comfort, choose your drills — you improve by attacking weaknesses, not rehearsing strengths.
- **Looking only at type.** Also sort by cause and by trap flavor; a cross-cutting habit (like "too strong" or "true but useless") can cost more than any single type.
:::

### Practice — 23.2

:::problem[Q1]{difficulty="easy"}
How often should you sort/analyze the log, and what do you do with the top category?

::::solution[Solution]
Every **week or two**. The top-count category becomes your **next drilling priority** — the highest-yield thing to fix.
::::
:::

:::problem[Q2]{difficulty="standard"}
Besides question type, name two other ways to sort the log and what each reveals.

::::solution[Solution]
By **cause** (reveals your timing-vs-knowledge balance → whether to prioritize speed or study) and by **trap flavor** (reveals a cross-cutting habit, e.g., always falling for "too strong" answers).
::::
:::

:::problem[Q3]{difficulty="standard"}
Your log shows mostly timing gaps concentrated in RC. What does that direct you to do?

::::solution[Solution]
Focus on **RC pacing and passage ordering** (Chapter 19) and timed practice — not more RC content study, since timing (not understanding) is the issue there. The log points to a speed fix in a specific section.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why can sorting by trap flavor reveal a weakness that sorting by type hides?

::::solution[Solution]
Because a **cross-cutting habit** — like consistently choosing "true but useless" or "too strong" answers — spreads its misses across *many* question types, so no single type looks alarming, yet the flavor's total may be your largest single source of lost points. Sorting by type buries it (a few misses each in Weaken, Flaw, RC…); sorting by flavor concentrates it into one visible, fixable pattern with one corrective rule.
::::
:::

## 23.3 · From "I'm bad at LR" to a fixable diagnosis

:::callout-intuition
Intuition first

"I'm just bad at Logical Reasoning" is a feeling, not a diagnosis — and you can't fix a feeling. The error log's deepest value is that it *replaces vague self-judgment with specific, actionable statements.* "Bad at LR" becomes "I miss Sufficient Assumption questions because I don't diagram the conditional logic." The first is discouraging and useless; the second is a concrete task you can complete. Precision is what makes improvement feel possible — and makes it actually happen.
:::

:::definition
**Definition 23.3 — Specific diagnosis.** A precise, actionable statement of a weakness, derived from the error log, that names the *question type*, the *mechanism* of the error, and (implicitly) the fix. Contrast with a vague global judgment ("I'm bad at X"), which names no mechanism and suggests no action. The move from vague to specific is what converts frustration into a to-do list.
:::

| Vague (useless) | Specific (fixable, from the log) |
| --- | --- |
| "I'm bad at Logical Reasoning." | "I miss Sufficient Assumption questions because I don't diagram the conditional and pick the wrong-direction link." |
| "RC is my worst section." | "I lose 3–4 points on the last RC passage because I over-read the first three and run out of time." |
| "I make careless mistakes." | "I misread Weaken vs. Strengthen stems when rushing; I need to circle the stem's direction first." |
| "I'm slow." | "I average 2:10 on Parallel questions; I need to triage them (guess-and-flag) rather than fight them." |

:::callout-key
Each specific diagnosis contains its own fix

Notice that every right-column statement *implies what to do*: "don't diagram" → practice diagramming; "over-read the first three passages" → passage triage and reading discipline; "misread the stem direction" → circle the stem first. A vague judgment offers no such handle. So the discipline is: whenever you catch yourself thinking a global "I'm bad at \_\_\_," go to the log, find the actual pattern, and rewrite the thought as a specific, mechanism-level diagnosis. Then do what it says.
:::

:::callout-pitfall
Watch out for these mistakes

- **Global self-judgment.** "I'm bad at LR" is demotivating and non-actionable. Always convert it to a specific, log-derived statement.
- **Diagnosing without the log.** Guessing at your weaknesses from memory is unreliable — memory over-weights recent or emotional misses. Use the data.
- **Naming the type but not the mechanism.** "I miss Assumption questions" is better than "bad at LR," but "I miss them because I skip the negation test" is what actually tells you what to practice.
:::

### Practice — 23.3

:::problem[Q1]{difficulty="easy"}
Why is "I'm bad at LR" useless as a diagnosis?

::::solution[Solution]
It's a **vague feeling that names no mechanism and suggests no action** — you can't fix it. A useful diagnosis names the specific type and the mechanism of the error (which implies the fix).
::::
:::

:::problem[Q2]{difficulty="standard"}
Rewrite "RC is my worst section" as a specific, fixable diagnosis (invent plausible detail).

::::solution[Solution]
E.g., "**I miss inference questions on science passages because I try to understand the mechanism instead of tracking which hypothesis each paragraph supports.**" It names the question type, passage type, and the mechanism — and implies the fix (read for structure, Chapter 16).
::::
:::

:::problem[Q3]{difficulty="standard"}
Why does a good specific diagnosis "contain its own fix"?

::::solution[Solution]
Because naming the **mechanism** of the error points directly at the corrective action — "I don't diagram" → practice diagramming; "I over-read early passages" → triage and reading discipline. The mechanism *is* the thing to change.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is diagnosing from the log more reliable than diagnosing from memory or feeling?

::::solution[Solution]
Because **memory is biased** — it over-weights recent misses, emotionally painful ones, and confirms whatever story you already believe ("I'm bad at LR"), while under-counting quiet, repeated errors. The log is an **unbiased tally**: it counts every miss equally, so the true top weakness (which may not be the one that *feels* worst) becomes visible. Data beats impression for finding where your points actually go.
::::
:::

## 23.4 · Scenario drills

Six error-log scenarios. Decide the right move, then check.

:::problem[1]{difficulty="easy"}
You do lots of practice but never log misses. What's the risk?

::::solution[Solution]
Your per-question lessons **evaporate** and patterns stay invisible, so you keep repeating the same errors and drilling blindly. Without the log, you can't see or target your top weaknesses.
::::
:::

:::problem[2]{difficulty="standard"}
Your log after two weeks: Flaw 8 misses, all "picked a real flaw the argument didn't commit." Diagnosis and fix?

::::solution[Solution]
Specific diagnosis: **you skip pre-phrasing on Flaw questions and pick a real-but-absent flaw**. Fix: block-drill Flaw with the "did the argument actually do this?" test (Chapter 9), pre-phrasing the flaw before reading choices.
::::
:::

:::problem[3]{difficulty="standard"}
Your log shows 20 misses but you only recorded the answer letters. What's missing and why does it matter?

::::solution[Solution]
Missing: **type, cause, and takeaway**. Without them you can't sort for patterns or know whether to fix speed or knowledge — the letters alone can't generate a study plan. Re-do the entries with the diagnostic fields.
::::
:::

:::problem[4]{difficulty="standard"}
You feel like "Parallel questions are impossible." What does the log-driven approach say to do?

::::solution[Solution]
Check the log: convert the feeling into a specific diagnosis (e.g., "I don't abstract to a skeleton and I over-spend time"), then apply the fix — practice abstracting + triage (Chapter 12). Replace the global "impossible" with a mechanism you can train.
::::
:::

:::problem[5]{difficulty="challenge"}
Two months in, your log shows knowledge gaps shrinking but timing gaps steady/growing. What does this trend mean?

::::solution[Solution]
Your **content mastery is improving** (fewer knowledge gaps) but **speed hasn't kept pace** — you increasingly know how to do questions but can't do them fast enough under time. The trend says to shift emphasis toward **timed practice, pacing, and section management** (Chapters 14, 19), and to take more full timed sections, since the remaining points are locked behind speed, not understanding.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, explain how the error log and blind review work together.

::::solution[Solution]
**Blind review** diagnoses each individual miss (timing vs. knowledge) and produces a specific takeaway; the **error log** stores those takeaways and, when sorted, aggregates them into visible patterns that set your study priorities. Review works at the single-question level; the log works at the trend level — together they turn practice into a targeted, self-correcting improvement loop.
::::
:::

## Chapter summary

:::summary
#### The error log, distilled

- **Log every miss** (and lucky guess) with consistent fields: date, source, type, picked/correct, cause (timing/knowledge), why + takeaway rule. Use a spreadsheet.
- **Sort and count every week or two** — by type, cause, and trap flavor. The top count is your next drilling priority.
- **Trap flavors cut across types:** sorting by flavor can reveal a bigger weakness than any single type.
- **Convert vague to specific:** "I'm bad at LR" → "I miss Sufficient Assumption because I don't diagram." Each specific diagnosis contains its own fix.
- **Pairs with blind review:** review diagnoses each miss; the log aggregates the diagnoses into a self-correcting agenda.
:::

LSAT Mastery — Chapter 23. Independent study material, not affiliated with LSAC. Appendix J provides a ready-to-use error-log template. Use official LSAC PrepTests for timed practice.
