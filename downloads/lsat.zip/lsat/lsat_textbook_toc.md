---
title: "LSAT Mastery"
source: "markdown"
---

Master Course Map

# LSAT Mastery

A complete self-study textbook — full table of contents with sub-chapters and appendices.

**Parts:** 6 — **Chapters:** 38 — **Appendices:** 12 — **Edition:** 2026

**Status legend:** — done drafted (exists) — partial partly covered — planned to be written

How this map works

Each chapter lists its sub-sections. Chapters tagged **partial** are already covered in some form by the existing *Complete LSAT Prep Guide* file; building them out as full standalone chapters is the next step. Every chapter from Part II onward ends with worked examples (answer-first) and a drill set with collapsible solutions, drawn from [official practice material (Appendix H)](#appG) plus original questions.

Front Matter

## Before You Begin

Orientation, philosophy, and your starting line.

F.0

[The Complete LSAT Prep Guide](./lsat_prep_guide.html)done

The single-file guide this book is being built out from. Every chapter tagged **partial** below is covered here in shorter form.

F.1

How to Use This Bookdone

The recommended path, why review beats volume, and how the chapters fit together.

F.2

The Ten Rules of LSAT Studyplanned

The study philosophy distilled into rules you can pin to a wall.

- **F.2.1** It's a skill test, not a knowledge test
- **F.2.2** The credited answer is the one the *text* supports
- **F.2.3** Review every miss until you can explain all four wrong answers
- **F.2.4** Consistency beats marathons

F.3

Your Cold Diagnosticpartial

Taking a full timed official test first, scoring it, and reading the result honestly.

- **F.3.1** Why you take it before studying
- **F.3.2** Where to get a free official test (LawHub)
- **F.3.3** Recording your baseline and section splits

Part I

## Understanding the Test

What the LSAT is, how it's built, and how your score is used.

Ch 1

[What the LSAT Is and Isn't](./lsat_ch1_what_the_lsat_is.html)done

The nature of the test and the mindset it rewards.

- **1.1** A reasoning test, not a knowledge test
- **1.2** No required reading and no memorized content — and why outside knowledge is a trap
- **1.3** The 2024 redesign: Logic Games removed
- **1.4** How law schools weigh LSAT + GPA

Ch 2

[Anatomy & Logistics](./lsat_ch2_anatomy.html)done

The mechanics of the four sections and how to register.

- **2.1** The four 35-minute sections
- **2.2** The unscored experimental section
- **2.3** Pacing math: minutes per question
- **2.4** The online/remote format & digital interface tools
- **2.5** Registration, test dates, retake limits
- **2.6** Fees, the CAS, and fee waivers

Ch 3

[Scoring, Percentiles & Targets](./lsat_ch3_scoring.html)done

From raw answers to the number schools see, and how to set a goal.

- **3.1** Raw → scaled (120–180) → percentile
- **3.2** The shape of the curve (why 150→160 is easier than 165→175)
- **3.3** Setting a target from school medians
- **3.4** Score release, retake policy, and CAS reporting

Part II

## Logical Reasoning

~50% of your score. The largest part — fundamentals, formal logic, the flaw catalog, then every question type.

Ch 4

[Foundations of Argument](./lsat_ch4_foundations.html)done

The core anatomy every LR question shares.

- **4.1** Conclusion vs. premise (and indicator words)
- **4.2** Finding the gap — the assumption
- **4.3** The six-step method
- **4.4** The credited-response principle: text-dependence key concept
- **4.5** The five wrong-answer flavors

Ch 5

[Conditional & Formal Logic](./lsat_ch5_logic.html)done

The if-then machinery underlying many of the hardest questions.

- **5.1** If–then statements; necessary vs. sufficient conditions
- **5.2** The contrapositive
- **5.3** Quantifiers: *some*, *most*, *all*, *none*
- **5.4** Diagramming chains and spotting valid inferences
- **5.5** Common valid & invalid argument forms

Ch 6

[The Flaw Catalog](./lsat_ch6_flaws.html)done

The recurring reasoning errors the test reuses — learned as a vocabulary.

- **6.1** Correlation vs. causation
- **6.2** Necessary/sufficient confusion
- **6.3** Sampling & unrepresentative surveys
- **6.4** Ad hominem & appeals (authority, popularity)
- **6.5** Equivocation & circular reasoning
- **6.6** Part-to-whole (composition/division)
- **6.7** False dilemma & other scope errors

Ch 7

[Assumption Questions](./lsat_ch7_assumption.html)done

The most fundamental type — necessary and sufficient.

- **7.1** Necessary assumption & the negation test
- **7.2** Sufficient assumption & bridging terms
- **7.3** Telling the two apart
- **7.4** Worked examples + drill set (answer-first, collapsible)

Ch 8

[Strengthen & Weaken](./lsat_ch8_strengthen_weaken.html)done

- **8.1** Helping vs. hurting a conclusion
- **8.2** Attacking and defending causal claims
- **8.3** "Most" strengthens/weakens — degree matters
- **8.4** Worked examples + drill set

Ch 9

[Flaw Questions](./lsat_ch9_flaw.html)done

- **9.1** Matching the error actually made
- **9.2** Abstract flaw descriptions decoded
- **9.3** Worked examples + drill set

Ch 10

[Inference / Must Be True](./lsat_ch10_inference.html)done

- **10.1** Must-be-true vs. most-strongly-supported
- **10.2** Combining facts; using contrapositives
- **10.3** Why "true in real life" answers fail
- **10.4** Worked examples + drill set

Ch 11

[Method, Role & Point at Issue](./lsat_ch11_method_role.html)done

- **11.1** Method / argument structure
- **11.2** Role / function of a claim
- **11.3** Point at issue / disagreement
- **11.4** Worked examples + drill set

Ch 12

[Parallel Reasoning & Parallel Flaw](./lsat_ch12_parallel.html)done

- **12.1** Matching logical form, ignoring topic
- **12.2** Parallel flaw: matching the specific error
- **12.3** Fast elimination tactics
- **12.4** Worked examples + drill set

Ch 13

[Paradox & Principle](./lsat_ch13_paradox_principle.html)done

- **13.1** Paradox / resolve–explain
- **13.2** Principle (justify & conform)
- **13.3** Worked examples + drill set

Ch 14

[LR Section Management](./lsat_ch14_lr_management.html)done

Turning per-question skill into a 35-minute section score.

- **14.1** Pacing & the skip-and-return strategy
- **14.2** Difficulty ordering within a section
- **14.3** Guessing strategy & never leaving blanks

Part III

## Reading Comprehension

~25% of your score. Reading dense, unfamiliar prose for structure — fast and precisely.

Ch 15

[Reading for Structure](./lsat_ch15_reading_structure.html)done

The core skill: mapping a passage instead of memorizing it.

- **15.1** Active reading & the paragraph map
- **15.2** Pivot words (*but, however, although*) and where opinions live
- **15.3** Tracking whose view a sentence expresses key concept
- **15.4** Stating the main point in one sentence

Ch 16

[The Four Passage Subjects](./lsat_ch16_subjects.html)done

What to expect from each topic family and how to stay calm on unfamiliar ones.

- **16.1** Natural sciences
- **16.2** Social sciences
- **16.3** Humanities & the arts
- **16.4** Law

Ch 17

[Comparative Reading](./lsat_ch17_comparative.html)done

The dual-passage set and its relationship questions.

- **17.1** Mapping two authors' positions
- **17.2** Points of agreement vs. disagreement
- **17.3** "How would author A react to B?" questions
- **17.4** Worked dual passage + drill set

Ch 18

[RC Question Types](./lsat_ch18_rc_questions.html)done

- **18.1** Main point / primary purpose
- **18.2** Detail / recognition
- **18.3** Inference
- **18.4** Author's attitude / tone
- **18.5** Function / purpose of a part
- **18.6** Structure / organization
- **18.7** Analogy / application
- **18.8** Worked passage + drill set

Ch 19

[RC Section Management](./lsat_ch19_rc_management.html)done

- **19.1** Per-passage time budget
- **19.2** Ordering passages easiest-first
- **19.3** When to skim vs. when to slow down

Part IV

## Argumentative Writing

Required but unscored. Do it once, do it competently.

Ch 20

[The Writing Task](./lsat_ch20_writing.html)done

- **20.1** Format, timing, and the perspectives
- **20.2** A reliable essay template
- **20.3** A full sample essay, annotated
- **20.4** Why it gates your score release; common mistakes

Part V

## The Study Plan

How to actually train — the methods, schedules, and mental game that turn the chapters above into points.

Ch 21

[Building Your Plan](./lsat_ch21_building_plan.html)done

- **21.1** Diagnostic → gap analysis
- **21.2** Learn the types before grinding volume
- **21.3** Drilling by type, then mixed

Ch 22

[The Blind-Review Method](./lsat_ch22_blind_review.html)done

The highest-leverage habit in all of LSAT prep.

- **22.1** Re-solving untimed before checking the key
- **22.2** The timing-gap vs. knowledge-gap diagnosis
- **22.3** The five-step single-question review

Ch 23

[The Error Log](./lsat_ch23_error_log.html)done

- **23.1** What to record per miss
- **23.2** Sorting by type to target weak spots
- **23.3** Turning "I'm bad at LR" into a fixable diagnosis

Ch 24

[Practice-Test Strategy & Endurance](./lsat_ch24_practice_tests.html)done

- **24.1** Full timed PTs in the official interface
- **24.2** Adding a fifth section for fatigue
- **24.3** Reviewing a PT (longer than the test itself)
- **24.4** The pre-test taper

Ch 25

[Study Schedules](./lsat_ch25_schedules.html)done

- **25.1** The 3-month plan (standard)
- **25.2** The 6-month plan
- **25.3** The 1-month compressed plan
- **25.4** The 12-month plan
- **25.5** The repeatable weekly rhythm

Ch 26

[Plateaus & the Mental Game](./lsat_ch26_mental_game.html)done

- **26.1** Diagnosing a score plateau
- **26.2** Avoiding burnout
- **26.3** Test anxiety & performance under pressure

Ch 27

[Test-Day Playbook](./lsat_ch27_test_day.html)done

- **27.1** The week & day before
- **27.2** Tech check & environment rules
- **27.3** Execution rules during the test
- **27.4** After: writing task, scores, deciding on a retake

Part VI

## Full-Length Practice Tests

Eleven original tests in the current format: two Logical Reasoning sections and one Reading Comprehension section, 77 questions each, every question with a full explanation. Take them timed, then blind-review (Chapter 22) before checking answers.

Ch 28

[Practice Test 1](./lsat_ch28_practice_test_1.html)done

Slightly easier than the real test. A good first full-length run.

Ch 29

[Practice Test 2](./lsat_ch29_practice_test_2.html)done

Typical difficulty.

Ch 30

[Practice Test 3](./lsat_ch30_practice_test_3.html)done

Typical difficulty.

Ch 31

[Practice Test 4](./lsat_ch31_practice_test_4.html)done

Typical difficulty.

Ch 32

[Practice Test 5](./lsat_ch32_practice_test_5.html)done

As hard as the real test plausibly gets.

Ch 33

[Practice Test 6](./lsat_ch33_practice_test_6.html)done

Typical difficulty, themed on technology: patent law, computer hardware, the history of computing and platform economics.

Ch 34

[Practice Test 7](./lsat_ch34_practice_test_7.html)done

Typical difficulty.

Ch 35

[Practice Test 8](./lsat_ch35_practice_test_8.html)done

Typical difficulty, themed on technology: trade secrets and non-competes, machine learning, the internet and AI, and privacy economics.

Ch 36

[Practice Test 9](./lsat_ch36_practice_test_9.html)done

Typical difficulty.

Ch 37

[Practice Test 10](./lsat_ch37_practice_test_10.html)done

Typical difficulty, themed on technology: chip manufacturing, Unix and open source, standard-essential patents and FRAND, and automation.

Ch 38

[Practice Test 11](./lsat_ch38_practice_test_11.html)done

Harder than the real test.

Back Matter

## Appendices

Quick-reference material to keep beside you while you drill.

### [AMaster Flaw Catalog](./lsat_appendices.html#appA)

Every common reasoning flaw on one page, each with a one-line tell and a mini-example.

### [BConditional Logic & Quantifier Cheat Sheet](./lsat_appendices.html#appB)

If–then, contrapositive, necessary/sufficient, and the *some/most/all* inference rules.

### [CQuestion-Type Identification Flowchart](./lsat_appendices.html#appC)

Read the stem → name the type → know your move. A decision tree for fast tagging.

### [DWrong-Answer Flavor Reference](./lsat_appendices.html#appD)

Out of scope, opposite, too strong, half-right, true-but-useless — with examples of each.

### [EScore Conversion & Percentile Tables](./lsat_appendices.html#appE)

Approximate raw-to-scaled bands and the 120–180 percentile chart.

### [FIndicator-Word Lists](./lsat_appendices.html#appF)

Conclusion, premise, and pivot-word vocabularies for LR and RC.

### [GStamina Reading List](./lsat_appendices.html#appG)

Optional dense-nonfiction sources (e.g., *The Economist*, *The Atlantic*, *Aeon*, *Scientific American*) to build comfort with hard prose — a habit, not a syllabus.

### [HResource Directory](./lsat_appendices.html#appH)

Official (LawHub, Khan Academy, LSAC fee waivers) and third-party courses/books, with a budget-conscious stack.

### [ITest-Day Checklist](./lsat_appendices.html#appI)

A printable pre-test, day-of, and post-test checklist.

### [JError-Log Template](./lsat_appendices.html#appJ)

Ready-to-use columns (date, source, type, pick, answer, timing-vs-understanding, lesson). Available as a spreadsheet.

### [KGlossary of LSAT Terms](./lsat_appendices.html#appK)

Stimulus, stem, conclusion, contrapositive, blind review, CAS, PT — defined plainly.

### [LAnswer Keys & Solutions Index](./lsat_appendices.html#appL)

Consolidated solutions for every drill, cross-referenced by chapter.

Master course map for a self-study LSAT textbook, June 2026. The LSAT is administered by the Law School Admission Council (LSAC); this project is independent and not affiliated with LSAC. Timed drills should use official LSAC practice material; original questions illustrate patterns but cannot replace real PrepTests. Verify all format, fee, and date specifics at lsac.org.
