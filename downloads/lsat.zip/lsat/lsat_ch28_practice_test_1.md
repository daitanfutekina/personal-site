---
title: "Practice Test 1"
source: "markdown"
---

Part VI · Chapter 28

# Practice Test 1

An original, three-section LSAT practice test with 77 questions and complete review explanations.

## Overview

Take all three sections in one sitting: **35 minutes for Section I, 35 minutes for Section II, then a 10-minute break, followed by 35 minutes for Section III**. Use a timer and record answers separately. This practice test contains only the three scored section types; the official LSAT also includes a fourth, unscored experimental section (Chapter 2).

**Flag, don’t guess silently.** Record the number of every question you were uncertain about, even if you chose an answer. A lucky correct guess still signals a skill to improve. Do not open a solution or the answer key until you have finished all three timed sections.

Afterward, revisit each flagged question **untimed, without checking the answer**, and write down the reason for your choice. This is blind review (Chapter 22). Only then consult the solutions and record wrong answers, fragile guesses, and recurring traps in your error log (Chapter 23).

This is an **original test written for this textbook**, not an official LSAC PrepTest or a score-equated test. Official PrepTests in LawHub remain the gold standard for realistic timed practice (Chapter 24).

## 28.1 Section I: Logical Reasoning

**25 questions. 35 minutes.** Choose the one best answer for each question.

:::problem[Question I.1]
When the Maritime Museum began closing at 10 p.m. rather than 6 p.m., passenger counts on the bus route serving it increased by 18 percent. The transportation director argues that the museum's later hours caused the increase and therefore that extending evening hours at the city's other museums would boost ridership on their nearby bus routes as well. The director notes that admission prices at the Maritime Museum did not change and that the bus operator made no changes to its route or timetable during the period examined.

Which one of the following, if true, most seriously weakens the director's argument?

- **(A)** The Maritime Museum received more daytime visitors after its hours were extended.
- **(B)** Several other museums are located farther from bus stops than the Maritime Museum is.
- **(C)** A month-long waterfront festival began when the museum extended its hours, and most additional evening bus passengers got off at the festival entrance before reaching the museum.
- **(D)** Some riders visiting the museum purchased day passes instead of single-ride tickets.
- **(E)** Other evening routes in the city also gained riders during the period, but their increases were much smaller than 18 percent.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The director claims extended museum hours caused the route's ridership growth and predicts similar increases elsewhere.
2. **Support.** Ridership rose at the same time as the hours changed, while prices and bus service were unchanged. That timing leaves open an independent demand shock.
3. **Prephrase.** Look for another event that attracts the new passengers without relying on museum hours.
4. **Why (C) is right.** The festival explains both the timing and destination of most new evening riders. If they left the bus before the museum, their trips do not support the director's causal story or its transfer to other museums.
5. **Why the others fail.**
   - **(A)** A daytime increase might reflect museum popularity but does not explain the evening bus passengers; it is a wrong-time comparison.
   - **(B)** Stop distance could limit how far the director may generalize, but it does not undermine the proposed cause of the observed increase as directly as (C).
   - **(D)** A ticket-category change alters revenue accounting, not the count of people riding; this is a metric shell game.
   - **(E)** A modest systemwide increase may show a general upward trend, but it does not account for most of this unusually large route-specific rise as directly as the festival does.

**Check:** The festival provides a common-timing alternative cause for the additional bus trips.
::::
:::

:::problem[Question I.2]
A neighborhood grocery cooperative has been criticized for buying too much produce, since it discards a larger percentage of its vegetables than national chains do. Yet the cooperative buys from nearby farms in small, unpredictable harvest lots and keeps varieties that chains routinely reject for cosmetic reasons. Those choices increase the chance of unsold produce, but they also give farmers a reliable market and customers access to unusual crops. Waste figures alone therefore provide an inadequate basis for declaring the cooperative's purchasing policy irresponsible; the policy should be evaluated against the benefits it was designed to provide.

Which one of the following most accurately expresses the argument's main conclusion?

- **(A)** The cooperative's purchasing policy cannot fairly be judged by its produce-waste figures alone.
- **(B)** Small local farms deliver their harvests less predictably than national suppliers do.
- **(C)** The cooperative should prioritize uncommon vegetable varieties over reducing any produce waste.
- **(D)** The cooperative should eliminate produce waste before expanding its selection.
- **(E)** Chains record less vegetable waste mainly because their purchasing practices exclude visually imperfect produce.

::::solution[Solution]
**Answer:** (A)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The author's bottom line is that waste percentages alone do not settle whether the cooperative buys responsibly.
2. **Support.** The preceding facts explain why its losses are linked to deliberate benefits for farms and shoppers, giving reasons to evaluate more than the waste statistic.
3. **Prephrase.** Find the qualified evaluation claim, not one detail supporting it or a proposal the author never made.
4. **Why (A) is right.** Choice (A) preserves both the objection under discussion and the author's response: the metric is incomplete, not necessarily incorrect.
5. **Why the others fail.**
   - **(B)** This is a supporting detail about suppliers, not the position for which the other sentences supply reasons; it mistakes premise for conclusion.
   - **(C)** The passage says unusual crops provide one benefit, but does not rank it above any reduction in waste; this is an overextended recommendation rather than the qualified evaluation conclusion.
   - **(D)** The author opposes treating the waste figure as decisive; making zero waste a prerequisite reverses the argument's thrust.
   - **(E)** The text mentions cosmetic rejections, but does not prove they are the main reason chains have lower waste rates; this turns context into an unproved causal conclusion.

**Check:** The final sentence restates (A); earlier sentences provide its supporting reasons.
::::
:::

:::problem[Question I.3]
The historic Rialto Theater must obtain a safety certificate before it can host public performances. Its manager reports that an electrician has replaced the outdated wiring and that the emergency exits now have illuminated signs. The manager concludes that the theater is ready to reopen because every theater that lacks adequate wiring or exit signs fails the safety inspection. The manager acknowledges that the inspector will also examine balcony railings, fire doors, and the sprinkler system, but says there is no reason to delay advertising the reopening date.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** treats the presence of illuminated exit signs as evidence that the replaced electrical wiring meets the inspection standard.
- **(B)** assumes that readiness to announce a reopening is itself evidence that a safety inspection has been passed.
- **(C)** mistakes improvements that are sufficient for safety certification for improvements that are required for it.
- **(D)** presumes that all safety inspectors apply identical standards to every historic theater.
- **(E)** treats the absence of two grounds for failing inspection as sufficient to ensure passing inspection.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The manager concludes that the theater is ready to reopen and pass the required inspection.
2. **Support.** The repaired wiring and exit signs remove two stated reasons an inspection could fail, but other listed conditions remain unchecked.
3. **Prephrase.** Watch for necessary/sufficient confusion: eliminating some ways to fail does not establish every requirement for passing.
4. **Why (E) is right.** Choice (E) describes precisely the leap from not failing on wiring or signs to passing overall, despite additional inspected systems.
5. **Why the others fail.**
   - **(A)** The manager relies on separate reports about wiring and exit signs, not on signs as evidence about wiring; this misdescribes the connection between premises.
   - **(B)** Advertising is the manager’s proposed next action, not a premise offered as proof of certification; this reverses the role of a recommendation.
   - **(C)** The manager treats removing disqualifying defects as enough, not as merely required; this reverses the direction of the flawed conditional.
   - **(D)** Variation in inspectors might complicate a prediction, but the known additional requirements already defeat the sufficiency leap; the manager never appeals to inspector uniformity.

**Check:** Other failed items, such as a defective sprinkler, could still prevent certification.
::::
:::

:::problem[Question I.4]
The neighborhood council distributed notices about its budget meeting in three additional languages this year. Attendance rose from 80 people at last year's meeting to 115 this year. No changes were made to the meeting room, admission rules, or scheduled start time. A council member concludes that distributing translated notices increased attendance and recommends expanding translation next year. The member does not know how many people attended because they saw a translated notice rather than an English one, but insists that the higher total establishes the notices' effect.

The council member's argument depends on assuming which one of the following?

- **(A)** Everyone who attended this year's meeting read a notice in a language other than English.
- **(B)** At least one person attended this year's meeting because of a translated notice who would not otherwise have attended.
- **(C)** The cost of translating the notices was less than the value of the additional attendance.
- **(D)** Most residents who could read the translated notices were previously unaware that the council held budget meetings.
- **(E)** No factor other than the translated notices contributed to this year’s attendance increase.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Translation of notices increased attendance, rather than merely accompanying an increase.
2. **Support.** The two meeting totals show growth while some logistics stayed the same; no evidence yet ties an additional attendee to translation.
3. **Prephrase.** The minimal required causal link is that at least one marginal attendee was brought in by translated information.
4. **Why (B) is right.** If (B) is false, nobody attended who would otherwise have stayed away because of translation. The proposed translation-driven attendance increase then has no instances, and the argument collapses.
5. **Why the others fail.**
   - **(A)** All attendees need not have used translations; even a single newly attracted attendee would support some increase. This is too strong.
   - **(C)** A benefit-cost judgment is not needed to establish the causal attendance claim; this changes the criterion.
   - **(D)** Even already-informed residents might need a timely notice to attend, and only some new attendees are required; this is an overly specific audience assumption.
   - **(E)** Translation can increase attendance even if publicity or interest also raises turnout; requiring it to be the sole cause is too strong.

**Check:** Negating (B) leaves zero attendees added by translations, defeating the claimed effect.
::::
:::

:::problem[Question I.5]
Managers of an office tower installed patterned film on the glass walls facing a wooded courtyard. During the following migration season, maintenance staff recorded only 14 bird strikes, compared with 47 in the prior season. The building's ecological consultant argues that the film was responsible for most of the reduction, rather than year-to-year variation in bird movements. The consultant has photographs documenting each reported collision but has not yet compared conditions at nearby buildings that still have untreated glass.

Which one of the following, if true, most strengthens the consultant's argument?

- **(A)** The patterned film is less expensive than replacing the tower's glass walls.
- **(B)** The same film could be installed at neighboring offices without altering their glass or landscaping.
- **(C)** The number of bird species observed in the courtyard increased after the installation.
- **(D)** During both seasons, a nearby untreated tower of similar size recorded almost the same number of strikes, while the treated tower's count fell sharply.
- **(E)** Seasonal weather was milder in the year after installation, potentially changing the movement patterns of birds.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The consultant attributes most of the decline in bird strikes to the new film.
2. **Support.** The treated building has a before-and-after decrease, but migration intensity or weather might have fallen everywhere.
3. **Prephrase.** A comparable untreated control showing no similar decline would isolate the film as a plausible difference-maker.
4. **Why (D) is right.** The nearby untreated tower serves as a comparison: shared seasonal conditions did not produce its decline. That makes film treatment a substantially stronger explanation for the treated tower's fall.
5. **Why the others fail.**
   - **(A)** Price may justify purchasing film but does not establish that it prevented collisions; this is a policy-versus-causation swap.
   - **(B)** Ease of reproducing the intervention bears on feasibility at other buildings, not whether the film caused the observed collision decline here.
   - **(C)** More observed species could mean more exposure, not fewer collisions per bird; the direction of its causal effect is ambiguous.
   - **(E)** Changed weather introduces an alternative to the film as a cause of lower strikes; it would weaken, not strengthen, the consultant’s causal attribution.

**Check:** Compare treated and untreated trends: only the treated tower declines sharply.
::::
:::

:::problem[Question I.6]
For a student to be considered for the Meridian Scholarship, the student must submit a faculty recommendation and complete an interview. Every applicant who completed an interview was invited to an orientation session, although some who were invited did not attend. No student missing the recommendation was considered. Leena was considered for the scholarship; Omar attended an orientation session but has not submitted a recommendation; and Mei submitted a recommendation but did not complete an interview. The committee has not yet selected any scholarship recipients, and the records do not show whether Omar was invited for some other reason.

Which one of the following must be true on the basis of the statements above?

- **(A)** Every student invited to orientation submitted a faculty recommendation.
- **(B)** Leena was invited to an orientation session.
- **(C)** Omar completed an interview because he attended orientation.
- **(D)** Mei was considered for the scholarship because she submitted a recommendation.
- **(E)** Leena submitted her faculty recommendation before she completed her interview.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** This is a fact set rather than an argument; the task is to derive a necessary consequence about a named student.
2. **Support.** Being considered requires an interview; completing an interview guarantees an orientation invitation. Leena is explicitly among those considered.
3. **Prephrase.** Chain considered → interviewed → invited, without reversing any arrow.
4. **Why (B) is right.** Leena was considered, so she completed an interview, which guarantees an invitation. The conclusion follows even if she did not attend.
5. **Why the others fail.**
   - **(A)** An invitation can follow an interview without a recommendation if the invitation process extends beyond considered applicants; this reverses or overextends the chain.
   - **(C)** Attending orientation does not prove an interview caused the invitation; it affirms the consequent.
   - **(D)** A recommendation alone does not replace the mandatory interview; this treats one necessary condition as sufficient.
   - **(E)** Consideration entails both documents and interview, but nothing fixes their order; this adds an unsupported chronology.

**Check:** Considered(Leena) → Interview(Leena) → Invited(Leena).
::::
:::

:::problem[Question I.7]
After Millford introduced a phone app for reporting potholes, the number of pothole reports received each month more than doubled. At the same time, the number of distinct potholes that street crews repaired each month fell by nearly one-third, even though the city maintained the same number of repair crews and workers logged the same total number of repair hours as before. Officials expected the easier reporting system to help crews locate damage and thereby increase, not reduce, completed repairs. They cannot account for the decline from a change in repair budgets or staffing.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Residents could still call the city to report potholes after the app launched.
- **(B)** Some potholes were repaired without ever being formally reported.
- **(C)** The app allowed residents to attach photographs to their reports.
- **(D)** The number of distinct potholes reported stayed about the same, even while the number of separate reports increased.
- **(E)** The app generated separate work orders for every report of the same pothole, and crews spent many hours visiting locations already inspected by another crew.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The discrepancy is more incoming reports but fewer distinct repairs despite unchanged labor hours.
2. **Support.** The app changed reporting volume and workflow, not staff levels; productivity per repair hour must have changed.
3. **Prephrase.** Seek a new burden or duplication that converts reporting growth into wasted work time.
4. **Why (E) is right.** Duplicate work orders consume the same crew hours on repeat inspections instead of distinct repairs. Both the rise in reports and the fall in completed repairs therefore follow from one mechanism.
5. **Why the others fail.**
   - **(A)** Preserving phone reports does not show why productivity fell after adding the app; it merely names another channel.
   - **(B)** Unreported repairs could affect totals in either period and do not account for the new drop; this is an unsupported timing comparison.
   - **(C)** Photos might improve identification, making the reduction more puzzling rather than explaining wasted hours.
   - **(D)** This helps explain the reporting surge as multiple reports per hole, but by itself does not explain why fixed crew hours yielded fewer completed repairs; (E) supplies wasted visits.

**Check:** Fixed crew hours − increased duplicate inspections = fewer hours for distinct repairs.
::::
:::

:::problem[Question I.8]
Under the city charter, anyone who has passed the ethics screening is eligible to conduct remote permit reviews. The training office confirms that Asha passed the procedural examination, and the planning director therefore concludes that Asha is eligible to conduct remote permit reviews. The director adds that employees may retake the procedural examination, that the ethics screening is administered separately, and that some staff who are eligible for remote reviews prefer to work on site. Nothing in the charter states that the procedural examination alone confers eligibility.

The planning director's conclusion follows logically if which one of the following is assumed?

- **(A)** Every employee eligible to review permits remotely has passed the procedural examination.
- **(B)** Some employees who passed the procedural examination also passed the ethics screening.
- **(C)** Every employee who passed the procedural examination passed the ethics screening.
- **(D)** Asha plans to work remotely rather than on site.
- **(E)** Nobody who fails the procedural examination passes the ethics screening.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The director infers that Asha is eligible for remote permit review.
2. **Support.** The known rule is ethics passed → eligible, while the known fact is procedural passed. These terms have not been linked.
3. **Prephrase.** Bridge Asha's procedural pass to the ethics pass needed to activate the charter's rule.
4. **Why (C) is right.** With (C), procedural pass → ethics pass → eligible. Since Asha passed the procedural exam, eligibility follows by two valid applications of modus ponens.
5. **Why the others fail.**
   - **(A)** Eligibility → procedural pass runs backward relative to the needed inference; it permits procedural-pass employees to be ineligible.
   - **(B)** Some qualified employees do not establish that Asha is one of them; this is a quantifier shell game.
   - **(D)** Wanting to work remotely cannot substitute for charter eligibility; it confuses preference and authorization.
   - **(E)** Failure → not screened is equivalent to screened → procedural pass, not the required procedural pass → screened.

**Check:** Procedural(Asha) → Ethics(Asha) → Eligible(Asha) only after adding (C).
::::
:::

:::problem[Question I.9]
At a weekend chocolate festival, a booth offered visitors samples of two dark chocolate recipes and asked which one should replace the company's current product. Of the 120 people who stopped to taste both samples, 76 preferred the recipe with citrus notes. The marketing director concludes that most current customers would prefer the citrus recipe and that replacing the existing product is therefore low risk. However, the booth was advertised as a tasting station for adventurous eaters and was located in the festival's experimental-food pavilion, rather than beside the company's regular product display.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** uses the preferences of a self-selected group drawn to unusual foods as evidence of what most existing customers prefer.
- **(B)** fails to establish that any sampled visitor could identify the chocolate's ingredients.
- **(C)** The citrus sample was offered at the same retail price as the company’s current chocolate.
- **(D)** mistakes a majority of all festival attendees for a majority of booth visitors.
- **(E)** Many existing customers say they like trying new flavors, even though they usually repurchase familiar products.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The marketing director claims most current customers prefer citrus and that substitution has little risk.
2. **Support.** Only 76 of 120 tasters in a deliberately novelty-oriented, self-selected booth preferred citrus; they were not sampled from current customers.
3. **Prephrase.** Identify sampling and unrepresentative surveys, not a supposed chemical or pricing issue.
4. **Why (A) is right.** Choice (A) names the selection bias: the people attracted to adventurous tasting may systematically differ from the regular customer base the director wants to predict.
5. **Why the others fail.**
   - **(B)** Knowledge of ingredients is not necessary for reporting a taste preference; this changes the measurement goal.
   - **(C)** Equal pricing would remove one possible purchasing difference but cannot repair the selective sample of novelty-oriented tasters.
   - **(D)** The director actually projects from booth tasters to current customers, not from the entire festival to booth tasters; it switches the populations.
   - **(E)** Stated curiosity among existing customers might make the proposed switch less certain, but the documented flaw is using novelty-seeking festival tasters as a proxy for the customer base.

**Check:** The surveyed population is experimental-food tasters; the target population is existing customers.
::::
:::

:::problem[Question I.10]
A hatchery biologist argues that warmer summer stream temperatures, rather than excessive harvesting, explain the sudden decline of a local trout population. Harvest levels were stable for five years, while temperatures rose sharply during the year of the decline. A colleague objects that increased sediment from construction could have damaged spawning beds. The biologist replies that sediment samples taken upstream and downstream of the construction site remained within their usual range throughout the spawning season. The colleague's proposed explanation, the biologist concludes, is inconsistent with the available measurements, though additional temperature monitoring would still be useful.

The statement that increased sediment from construction could have damaged spawning beds plays which one of the following roles in the argument?

- **(A)** It is the principal conclusion that the biologist ultimately accepts.
- **(B)** It supplies a necessary premise for the claim that harvesting levels were stable.
- **(C)** It identifies a fact that the biologist uses as direct evidence of warming.
- **(D)** It presents an alternative explanation that the biologist challenges by citing measurements.
- **(E)** It establishes that changes in sediment must be ruled out before the temperature hypothesis can be supported.

::::solution[Solution]
**Answer:** (D)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The biologist favors temperature rise as the cause and rejects the sediment proposal based on readings.
2. **Support.** Stable harvest and higher temperature support one cause; sediment is introduced as the colleague's rival hypothesis, then answered with measurements.
3. **Prephrase.** Tag the speaker and follow whether the statement is adopted, disputed or used as background.
4. **Why (D) is right.** Choice (D) identifies both the proposition's origin in the colleague's objection and the biologist's response to it. It is an objection, not the biologist's premise.
5. **Why the others fail.**
   - **(A)** The biologist does not accept sediment as the leading explanation; this reverses whose position is being defended.
   - **(B)** Stable harvesting is an independently reported fact and would remain so even if sediment never arose.
   - **(C)** Sediment measurements rebut the alternative cause, not directly prove stream warming; this conflates rebuttal with positive evidence.
   - **(E)** The biologist tests this particular alternative, but does not claim every possible sediment effect must be eliminated as a universal prerequisite for supporting a temperature explanation.

**Check:** Locate the sequence: colleague proposes sediment → biologist cites samples to challenge it.
::::
:::

:::problem[Question I.11]
A county health board compared two residential districts over four years. In the district where the city planted 900 street trees, emergency visits for childhood asthma fell by 16 percent; in a district where no trees were planted, the visits did not decline. The board concluded that the new trees reduced asthma episodes by improving air quality. It recommends a similar planting program in every district. The board has already checked that the two districts had comparable populations of children at the beginning of the period.

Which one of the following, if true, most seriously weakens the board's conclusion?

- **(A)** At the same time the trees were planted, the first district replaced a nearby diesel bus depot with an electric-vehicle depot; the other district had no comparable change.
- **(B)** Some of the newly planted trees have not yet reached their mature height.
- **(C)** The tree-planting district spent more money on environmental improvements than the comparison district.
- **(D)** A minority of asthma patients in both districts were adults rather than children.
- **(E)** The county’s overall rate of childhood asthma emergency visits declined slightly during the same four years.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The board attributes reduced childhood asthma visits to the street trees and proposes expanding them.
2. **Support.** The treated district improved relative to the control, but the comparison does not isolate other simultaneous environmental changes.
3. **Prephrase.** A second intervention plausibly affecting air quality in the improved district would undermine causal attribution.
4. **Why (A) is right.** Replacing diesel vehicles with electric ones could directly reduce pollution and explain the decrease, while the comparison district lacks this change. The trees are no longer the isolated difference.
5. **Why the others fail.**
   - **(B)** Immature trees could make a benefit less likely, but gives no concrete alternative cause for the observed decline.
   - **(C)** A general spending disparity is suggestive, but without identifying an intervention affecting asthma it does not challenge causal attribution as specifically as the diesel-depot replacement.
   - **(D)** The statistic concerns childhood emergency visits, so adult patients do not alter the reported measure.
   - **(E)** A slight countywide decline could be background trend, but the untreated district’s lack of decline makes it a less direct explanation of the 16 percent treated-district fall than (A).

**Check:** The depot replacement is a simultaneous alternative cause present only in the improving district.
::::
:::

:::problem[Question I.12]
An archivist claims that a catalog label should never be treated as conclusive evidence of an object's original use. She points to a set of wooden tablets labeled 'farm accounts' for a century. New examination revealed tiny holes placed precisely for weaving weights, and an intact loom found nearby contained matching tablets. The archivist does not claim that all old labels are wrong; rather, she argues that a label often records a past scholar's hypothesis and should be checked against physical evidence whenever that evidence becomes available.

Which one of the following most accurately describes the method of reasoning used by the archivist?

- **(A)** She derives a universal classification rule from a statistically representative survey of tablets.
- **(B)** She rejects the label mainly because its original compiler had no access to the later-discovered loom.
- **(C)** She uses a concrete case in which a long-accepted label proved mistaken to argue against treating such labels as conclusive.
- **(D)** She demonstrates that any object found near a loom must be a weaving tool.
- **(E)** She establishes that observations of nearby artifacts should always override any documentary evidence.

::::solution[Solution]
**Answer:** (C)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** A catalog label should not be regarded as final proof of original use.
2. **Support.** One long-standing classification was overturned by a combination of physical features and contextual evidence.
3. **Prephrase.** Recognize an illustrative counterexample to the stronger practice of treating labels as conclusive.
4. **Why (C) is right.** Choice (C) matches the limited claim and the way the example supports it: one mistaken label suffices to show that labels are not invariably decisive.
5. **Why the others fail.**
   - **(A)** The author neither samples a representative population nor claims every label is wrong; this inflates a counterexample into a universal survey.
   - **(B)** The discovery helps test an old classification, but the passage does not argue that the compiler’s lack of access by itself invalidates all historical labels; this narrows the reasoning to biography.
   - **(D)** The loom is corroborating evidence in one case, not a universal rule for nearby objects; this overstates an example.
   - **(E)** The argument advocates checking labels against physical evidence when available, not the universal rule that contextual objects outrank all written evidence.

**Check:** One clear counterexample defeats the practice 'a label is always conclusive,' not the weaker claim 'some labels are accurate.'
::::
:::

:::problem[Question I.13]
The school district paid $480,000 to install solar panels on the roof of its central warehouse. The finance officer calculates that the panels will save $65,000 in purchased electricity each year, assuming current utility rates and the system's forecast output. On that basis, the officer concludes that the installation will recover its entire cost through electricity savings within eight years. The officer acknowledges that resale value and environmental benefits might provide additional reasons for installing the panels, but neither benefit is counted in this payback calculation.

Which one of the following is an assumption on which the finance officer's argument depends?

- **(A)** Electricity rates will rise every year during the next eight years.
- **(B)** The warehouse will not need any roof repairs after the installation.
- **(C)** Solar power is the least expensive source of energy available to every school building.
- **(D)** The panels will produce at least some electricity that offsets purchased power during the projected eight-year period.
- **(E)** The projected environmental benefits will begin within the same eight-year period as the financial savings.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The district will recover the installation cost through electricity savings inside eight years.
2. **Support.** The arithmetic uses eight years of estimated savings: $65,000 times eight exceeds $480,000, but those savings must occur.
3. **Prephrase.** A minimal necessary condition is some actual offset of purchased electricity; a total absence of savings defeats recovery.
4. **Why (D) is right.** Negate (D): the panels produce no electricity that offsets purchased power during the period. Then electricity savings are zero, and repayment through that channel is impossible, irrespective of rate forecasts.
5. **Why the others fail.**
   - **(A)** Savings could be high enough with flat rates; annual rate increases are too strong and unnecessary.
   - **(B)** Roof maintenance might reduce net profitability, but the stated calculation concerns gross electricity savings; zero repairs is not required.
   - **(C)** Being the cheapest option elsewhere is irrelevant to whether these panels save the projected amount.
   - **(E)** Environmental benefits are excluded from the stated payback mechanism, so even their exact timing cannot be necessary to recovering cost through electricity purchases avoided.

**Check:** Negate (D) → zero offset electricity → zero electricity savings → no recovery by that route.
::::
:::

:::problem[Question I.14]
Every bowl glazed with the workshop's new mineral coating is fired at the kiln's highest temperature. No bowl fired at that temperature remains porous after cooling. Consequently, none of the bowls glazed with the new mineral coating will remain porous after cooling. The workshop owner makes no claim about unglazed bowls or bowls fired at lower temperatures and does not assume that high firing is the only way to eliminate porosity.

Which one of the following arguments is most similar in its pattern of reasoning to the argument above?

- **(A)** All licensed pilots have passed a navigation examination. Kim passed the examination. Therefore, Kim is a licensed pilot.
- **(B)** No copper pipe in the building is insulated. Every uninsulated pipe loses some heat. Therefore, every pipe that loses heat is made of copper.
- **(C)** Some verified manuscripts have digital scans. No scanned manuscript is stored outdoors. Therefore, no verified manuscript is stored outdoors.
- **(D)** Every laboratory freezer has an alarm. Every freezer with an alarm is expensive. Therefore, every expensive freezer is a laboratory freezer.
- **(E)** Every package shipped by courier express receives a tracking code. No package with a tracking code is anonymous. Therefore, no express-shipped package is anonymous.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The workshop infers that no newly coated bowl will remain porous.
2. **Support.** The two universal statements form new coating → high firing → not porous.
3. **Prephrase.** Match a valid categorical chain A → B and B → not C, hence A → not C, preserving direction and universality.
4. **Why (E) is right.** Express shipment → tracking code → not anonymous, so express shipment → not anonymous. It has the same valid two-link form.
5. **Why the others fail.**
   - **(A)** Passing the exam does not imply being licensed; this affirms the consequent of the first rule.
   - **(B)** It reverses the direction from 'copper → uninsulated → loses heat' to 'loses heat → copper.'
   - **(C)** The premise covers only some verified manuscripts, while the conclusion covers all; this improperly strengthens 'some' to 'all.'
   - **(D)** It concludes expensive → lab freezer from lab freezer → expensive; it reverses the chain's endpoint.

**Check:** Original and (E) both have the form all A are B; no B are C; therefore no A are C.
::::
:::

:::problem[Question I.15]
A coastal town is considering whether to order residents of a low-lying peninsula to evacuate before a storm. The forecast puts the probability of a devastating flood at only 20 percent, but if the flood occurs after the sole access road closes, rescue may be impossible. A voluntary advisory has not moved most residents, and officials can provide transportation and temporary lodging. The emergency planner argues that ordering evacuation now is justified even though the order will be burdensome and the predicted flood might never happen.

Which one of the following principles, if accepted, most strongly justifies the planner's recommendation?

- **(A)** Public officials should never impose a burden on residents when the predicted danger has a probability below one-half.
- **(B)** A temporary restriction that can avert an irreversible, grave harm may be justified despite uncertainty when less restrictive measures have proved inadequate and the restriction's burdens can be mitigated.
- **(C)** When a forecast danger could become impossible to escape, officials should order evacuation even if an effective voluntary evacuation has already succeeded.
- **(D)** A forecast probability should determine the timing of evacuation without consideration of how evacuation can be carried out.
- **(E)** Every emergency involving any risk of harm requires the same degree of government intervention.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** An evacuation order is warranted despite uncertainty and inconvenience.
2. **Support.** The threat is severe and potentially irreversible, voluntary measures failed, and the city can reduce the burden of compliance.
3. **Prephrase.** Choose a qualified principle weighing grave expected harm, feasible alternatives and proportional costs.
4. **Why (B) is right.** Choice (B) includes all of the planner's decisive considerations without treating every tiny risk as sufficient. It licenses a limited burden to avoid catastrophic harm after milder measures failed.
5. **Why the others fail.**
   - **(A)** It makes the 20 percent forecast categorically disqualifying, the opposite of the planner's conclusion.
   - **(C)** The planner specifically relies on the voluntary advisory having failed, so a rule ignoring successful alternatives is too sweeping to capture the stated justification.
   - **(D)** The planner explicitly considers road closure and assistance, so this rule excludes relevant premises.
   - **(E)** The recommendation depends on severe irreversible harm and a manageable evacuation burden; uniform treatment of all risks ignores both proportionality and alternatives.

**Check:** Map grave harm, inadequate advisory and mitigated burden to each condition in (B).
::::
:::

:::problem[Question I.16]
Residents of West Hollow installed a filter at the outlet of their shared well after several samples showed elevated lead concentrations. Three months later, five tests of tap water in occupied homes showed markedly lower lead readings. The well committee concluded that the filter, rather than changes in water sources or sampling conditions, caused the improvement. Critics note that the original and later tests were collected by different volunteers and that the samples came from different homes, so the comparison may not isolate the filter's effect.

Which one of the following, if true, most strengthens the committee's conclusion?

- **(A)** The new filter uses a material also employed in several commercial water systems.
- **(B)** Several households began drinking bottled water rather than well water after the initial high-lead readings.
- **(C)** A laboratory tested paired water samples taken on the same days immediately before and after the filter, and every pair showed a sharp lead reduction across the filter.
- **(D)** The committee intends to replace household pipes in the next five years.
- **(E)** Other minerals were present in many of the original tap-water samples.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The committee maintains that the shared filter caused the decline in lead at taps.
2. **Support.** Before-and-after residential readings are consistent with improvement, but sample collection and homes differ.
3. **Prephrase.** Direct same-day upstream/downstream comparisons should isolate the filter from homes, volunteers and changing source water.
4. **Why (C) is right.** Paired samples differ primarily in whether they have passed through the filter. A consistent reduction across that boundary directly supports a filtering mechanism.
5. **Why the others fail.**
   - **(A)** Use of the material elsewhere establishes feasibility, not performance in this water system.
   - **(B)** Changing which water people drink does not change measured lead concentration in water that still comes from the tap; this is an exposure-versus-concentration confusion.
   - **(D)** Future pipe replacement cannot cause improvements already recorded; it is a timing trap.
   - **(E)** Other minerals may be chemically relevant, but their mere presence does not isolate why lead readings declined.

**Check:** For paired samples on one day, outlet lead is lower than inlet lead: this localizes the change to the filter.
::::
:::

:::problem[Question I.17]
A regional development agency reports that startup founders who rent desks in shared coworking spaces file patent applications at twice the rate of founders who work from home. An agency analyst concludes that coworking spaces make founders more inventive by exposing them to new collaborators and that subsidizing memberships will therefore increase patenting. The analyst did not collect information about founders' industries, previous patent records, or funding sources. The agency's figures simply compare current members of the two groups, without tracing changes in individual founders' output after they join.

The analyst's reasoning is most vulnerable to criticism because it...

- **(A)** treats a difference between self-selected groups as evidence that membership caused the difference, without ruling out preexisting differences.
- **(B)** assumes that applying for a patent always guarantees the resulting invention has commercial value.
- **(C)** The agency has not established that every successful patent application originated from a coworking space.
- **(D)** concludes that every founder working from home files no patent applications.
- **(E)** The number of patents actually granted to founders may not match their number of applications.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Coworking membership causes higher invention output and a subsidy will increase applications.
2. **Support.** Members currently file more applications, but founders choose where they work and might have differed beforehand.
3. **Prephrase.** Look for correlation-versus-causation, particularly selection into the group with higher baseline patent activity.
4. **Why (A) is right.** Choice (A) pinpoints the missing causal control: funded, technology-intensive or already prolific founders may disproportionately choose coworking.
5. **Why the others fail.**
   - **(B)** The claim concerns application rates, not whether every invention becomes valuable; this substitutes an economic outcome.
   - **(C)** The analyst asserts an average difference between groups, not exclusivity of all patents; this is a too-strong characterization of the conclusion.
   - **(D)** A rate twice as high does not imply a zero rate in the comparison group; this is a quantifier distortion.
   - **(E)** Granted patents differ from applications, but the study and prediction both concern applications; the observation switches the outcome instead of diagnosing the causal comparison.

**Check:** Different group averages cannot determine whether joining changes an individual founder's filing rate.
::::
:::

:::problem[Question I.18]
Hana: Our community garden should require members borrowing shared tools to leave a refundable deposit. Tools frequently disappear, and the deposit would give borrowers an incentive to bring them back. We should exempt members who demonstrate that even a small deposit is unaffordable. Luis: Missing tools are a genuine problem, but a deposit system would discourage casual members from participating and create administrative work. We should instead label tools and maintain a sign-out sheet. Even with an exemption, I do not support requiring deposits from borrowers.

Hana and Luis disagree about whether...

- **(A)** tools have gone missing from the community garden.
- **(B)** the garden should require refundable deposits from tool borrowers, with exemptions for members unable to afford them.
- **(C)** a sign-out sheet could record who last borrowed a tool.
- **(D)** All members who cannot afford deposits should be permitted to borrow without payment.
- **(E)** The deposit policy could reduce participation by members who borrow tools only occasionally.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** This is a two-speaker disagreement task: Hana favors a qualified deposit rule and Luis explicitly opposes even that rule.
2. **Support.** Both accept the missing-tool problem, but they prescribe incompatible policies on deposits.
3. **Prephrase.** Apply the two-part point-at-issue test: one must affirm and the other deny the exact proposition.
4. **Why (B) is right.** Hana explicitly supports deposits with hardship exemptions; Luis says he opposes deposit requirements even with exemptions. Their stances directly contradict each other.
5. **Why the others fail.**
   - **(A)** Both speakers recognize missing tools, so this is a point of agreement, not disagreement.
   - **(C)** Luis proposes a sign-out sheet, but Hana never says such a sheet could not record borrowers; this is a one-speaker-only trap.
   - **(D)** Hana explicitly wants exemptions, but Luis opposes the deposit system as a whole and never rejects free borrowing for those in need; this is agreement-compatible, not a live dispute.
   - **(E)** Luis predicts discouragement, while Hana offers no clear position on whether that consequence will occur; one voiced concern is not a provable two-sided disagreement.

**Check:** For (B), Hana = yes; Luis = no, on the same rule including its exemption.
::::
:::

:::problem[Question I.19]
At the county courthouse, every hearing requiring an interpreter is scheduled in the afternoon because translators work mornings on document review. All afternoon hearings require two clerks to be present, while morning hearings can proceed with only one. A recently added Tuesday docket includes a hearing for which an interpreter is required. The scheduling office has not decided which judge will preside. Some hearings without interpreters are also in the afternoon, and the clerk supervisor is considering whether to add a third clerk on the busiest days.

Which one of the following is most strongly supported by the information above?

- **(A)** The Tuesday hearing requiring an interpreter will be the final hearing of the day.
- **(B)** No hearing without an interpreter will be scheduled on Tuesday afternoon.
- **(C)** Three clerks will be assigned to every hearing with an interpreter.
- **(D)** At least one hearing on Tuesday will require two clerks.
- **(E)** All hearings presided over by the same judge must occur at the same time of day.

::::solution[Solution]
**Answer:** (D)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The statements support an inference about staffing for the Tuesday interpreter hearing, not about judges or final schedules.
2. **Support.** Interpreter-required → afternoon; afternoon → two clerks; at least one interpreter-required Tuesday hearing exists.
3. **Prephrase.** Chain the conditions for that one hearing, retaining the 'at least one' quantity.
4. **Why (D) is right.** The interpreter hearing must be in the afternoon and thus must have two clerks; hence at least one Tuesday hearing requires two.
5. **Why the others fail.**
   - **(A)** Afternoon placement does not identify whether the hearing is last; this adds an ordering claim.
   - **(B)** The text explicitly allows afternoon hearings without interpreters; this wrongly converts an implication into an equivalence.
   - **(C)** A third clerk is merely under consideration on busy days, not mandated for any interpreter hearing.
   - **(E)** Judges' scheduling patterns are not specified; this adds a rule from an unrelated detail.

**Check:** Interpreter(Tuesday hearing) → Afternoon → Requires two clerks.
::::
:::

:::problem[Question I.20]
Employees who have passed the carpentry program's final safety assessment may apply for the advanced apprenticeship placement. The assessment is not automatically passed by everyone who finishes the workshops. Last week, Ravi was awarded a gold completion badge for his work in the program. The training manager concludes that Ravi may apply for the advanced placement. The manager knows that different instructors award badges and that employees may display their badges even after leaving the program, but offers no further information about the relationship between earning a gold badge and passing the final assessment.

Which one of the following, if assumed, allows the manager's conclusion to be properly drawn?

- **(A)** Everyone eligible for advanced placement has earned a gold completion badge.
- **(B)** Some employees with gold completion badges have applied for advanced placement.
- **(C)** Ravi attended all of the program's optional workshop sessions.
- **(D)** Everyone who passes the final assessment earns a gold completion badge.
- **(E)** Every employee awarded a gold completion badge has passed the program's final safety assessment.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Ravi is eligible to apply for advanced placement.
2. **Support.** Passing the final assessment is sufficient for eligibility, but Ravi is known only to have earned a badge.
3. **Prephrase.** Supply the missing arrow badge → passed final assessment, then follow the existing passed → eligible arrow.
4. **Why (E) is right.** Choice (E) gives exactly that bridge. Ravi's badge establishes an assessment pass, and the program's stated rule establishes eligibility.
5. **Why the others fail.**
   - **(A)** It makes the badge necessary for eligible candidates rather than sufficient to show assessment success; it reverses the bridge.
   - **(B)** A claim about some badge holders does not identify Ravi and does not establish program eligibility.
   - **(C)** Optional sessions need not entail assessment success; it introduces a new credential without a linking rule.
   - **(D)** This runs from assessment pass to badge, whereas the manager needs to infer a pass from a badge; this is the converse trap.

**Check:** Badge(Ravi) → Passed(Ravi) → May apply(Ravi).
::::
:::

:::problem[Question I.21]
A restaurant's average online rating increased from 3.8 to 4.4 stars during the month after servers completed a hospitality course. Its owner declares that the course improved customer satisfaction and urges other restaurants to purchase the same course. The owner neglects to mention that the earlier average included reviews from all four years the restaurant had been open, whereas the later average was calculated only from reviews written during a single promotional week, when customers were offered complimentary desserts for posting a review.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** The average review from customers during the promotional week was based on the same rating scale as older reviews.
- **(B)** relies on the restaurant owner's financial interest as proof that the course worked.
- **(C)** concludes that every customer who reviewed the restaurant received a dessert.
- **(D)** The owner assumes that customers who post reviews are representative of all diners served during that week.
- **(E)** attributes a difference between noncomparable rating samples to training without considering a simultaneous incentive affecting who reviewed.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The owner credits training with improved satisfaction based on a higher reported rating.
2. **Support.** The old and new averages cover radically different periods and reviewer incentives, so the scores do not isolate training.
3. **Prephrase.** Identify the sampling and causal confound: different pools, one encouraged with a reward.
4. **Why (E) is right.** Choice (E) directly explains why the two averages cannot be taken as before-and-after measures of the same customer population.
5. **Why the others fail.**
   - **(A)** Using the same star scale does not make a four-year historical sample comparable to a rewarded promotional-week sample; it addresses measurement labels, not sampling bias.
   - **(B)** The owner cites ratings, not the authority of financial self-interest; this misidentifies the support.
   - **(C)** A promotional dessert is offered for posting a review, but the owner does not infer all reviewers received one; this is an invented universal claim.
   - **(D)** Representativeness within a promotional week could be a concern, but the recorded argument compares different periods and rewards, so the more precise objection is the confounded before-and-after comparison in (E).

**Check:** A historical all-time mean and a rewarded promotional-week mean are not controlled before/after measures.
::::
:::

:::problem[Question I.22]
A city with 20,000 adult residents sent a voluntary online survey about a proposed pedestrian bridge. Exactly 1,000 residents responded, and 620 of them supported the bridge. The mayor concludes that a majority of all adult residents favors the project and that the council can treat the survey as evidence of citywide majority support. The mayor concedes that the response rate was low, but argues that receiving several hundred supportive answers is itself a substantial expression of public sentiment.

Which one of the following is an assumption required by the mayor's conclusion?

- **(A)** Every resident who supports the bridge responded to the survey.
- **(B)** All 380 respondents who opposed the bridge would change their minds after a public hearing.
- **(C)** The survey was distributed exclusively to residents who live within walking distance of the proposed bridge.
- **(D)** At least one adult resident who did not respond to the survey supports the bridge.
- **(E)** Residents who would use the bridge are more likely to support it than residents who would not use it.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** More than half of all 20,000 adult residents support the bridge.
2. **Support.** Only 620 of the 1,000 known respondents support it; there are 19,000 residents whose preferences are unknown.
3. **Prephrase.** A citywide majority requires 10,001 supporters. Therefore, some people outside the 620 supportive respondents must favor it.
4. **Why (D) is right.** If (D) is false, no nonrespondent favors the bridge, leaving at most 620 supporters out of 20,000, nowhere near a majority. (D) is necessary, though far from sufficient.
5. **Why the others fail.**
   - **(A)** If every supporter responded, there would be only 620, defeating rather than supporting the mayor; it is opposite to the needed assumption.
   - **(B)** Converting the opponents is unnecessary if enough nonrespondents already favor the bridge; this is a wrong-population trap.
   - **(C)** Geographic restriction is neither established nor required for a citywide majority; it would make representativeness harder, not guaranteed.
   - **(E)** Users may be more supportive, but the mayor claims a majority among all adults; this subgroup relationship cannot supply the missing number of supporters.

**Check:** Negate (D): at most 620 supporters remain, which is below the 10,001 majority threshold.
::::
:::

:::problem[Question I.23]
Every genuine antique jade pendant in the collector's display has a particular pale line visible under ultraviolet light. A pendant brought to the collector yesterday has that pale line, and the collector therefore concludes that it is a genuine antique jade pendant. The collector has not examined the pendant's provenance or tested whether modern replicas can produce the same line. The reasoning rests entirely on the feature that all genuine pieces in the display are known to have.

Which one of the following arguments exhibits the same flaw in reasoning?

- **(A)** All approved grant applications include a budget. This application lacks a budget, so it cannot be approved.
- **(B)** Every registered architect in the office has a security badge. Talia has a security badge, so she must be a registered architect.
- **(C)** No untreated beams resist the fire test. This beam is untreated, so it will not resist the fire test.
- **(D)** Some certified divers have visited the reef. Priya is a certified diver, so she might have visited the reef.
- **(E)** Every library volunteer attends an orientation. Malik is a library volunteer, so Malik attends an orientation.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The collector infers authenticity from possession of a feature common to all genuine pieces.
2. **Support.** Genuine → pale line; the inspected pendant has pale line, and the reasoning incorrectly infers genuine.
3. **Prephrase.** Match affirming the consequent: A → B; B; therefore A.
4. **Why (B) is right.** Registered architect → badge; Talia has badge; therefore architect. The badge could also belong to others, exactly like the pale line could appear on replicas.
5. **Why the others fail.**
   - **(A)** It uses the contrapositive of approved → has budget, which is valid, not the collector's error.
   - **(C)** It applies the given universal rule directly to an untreated beam, a valid deduction.
   - **(D)** The modest 'might' conclusion claims possibility, not certainty, and does not commit the collector's mistaken converse.
   - **(E)** This is valid modus ponens: volunteer → orientation; volunteer; hence orientation.

**Check:** Both stimulus and (B) affirm the consequent rather than using the contrapositive.
::::
:::

:::problem[Question I.24]
Northfield tested a new algorithm that assigns snowplow routes based on street width and traffic rather than simply dividing the town into equal geographic sectors. During the first winter using the algorithm, its fleet cleared all priority streets 40 minutes faster on average than in the previous winter. The public works director credits the routing algorithm, though residents note that one winter may be easier than another. The fleet size and number of drivers stayed constant, but the director has not yet analyzed snow depth or storm patterns.

Which one of the following, if true, most strengthens the director's conclusion?

- **(A)** Some plow drivers prefer familiar routes to algorithmically generated routes.
- **(B)** The town purchased less road salt during the winter using the new algorithm.
- **(C)** For storms of comparable snowfall, temperature, and start time, the same plow crews cleared the priority streets substantially faster using the new routes.
- **(D)** Priority streets carry a greater percentage of daytime traffic than residential streets do.
- **(E)** The algorithm performed well in a smaller town that has less traffic and receives lighter snowfall.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The algorithm caused the observed improvement in priority-street clearing time.
2. **Support.** The before-and-after average favors the algorithm, but storm severity and timing could create an artificial difference.
3. **Prephrase.** Compare like storms under like conditions while holding crews constant to isolate route design.
4. **Why (C) is right.** Choice (C) directly controls the principal seasonal alternative explanations and preserves the faster outcome under matched conditions.
5. **Why the others fail.**
   - **(A)** Driver preference might affect implementation but supplies no comparison of actual clearing times.
   - **(B)** Salt purchases do not establish the speed of clearing and may reflect a milder winter; it is the wrong outcome variable.
   - **(D)** Traffic importance explains why roads are prioritized, not why the algorithm cleared them faster.
   - **(E)** A success under easier conditions elsewhere offers some external plausibility but does not control Northfield’s seasonal differences as the matched-storm data in (C) do.

**Check:** Matched storms with same crews + shorter completion times point toward the route change.
::::
:::

:::problem[Question I.25]
After an independent bookstore began hosting free weekly reading clubs, the electronic door counter recorded a 35 percent increase in monthly visits. Nevertheless, the number of books sold in the store declined by 12 percent during the same months, despite stable prices and unchanged opening hours. The owner had expected more visitors to mean more purchases. Staff members say the clubs were consistently well attended, but they have not established whether club visitors were buying books or simply using the meeting space.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Most new visits were repeat trips by club members who had stopped buying monthly selections and instead borrowed those books for discussion.
- **(B)** The bookstore added two shelves devoted to books by local authors.
- **(C)** The club selected a number of recently published books, and the store stocked them near the meeting room.
- **(D)** The door counter counted people entering for the first time and repeat visitors in the same way.
- **(E)** Many customers who purchased books also browsed the store's stationery section.

::::solution[Solution]
**Answer:** (A)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The puzzle is higher foot traffic coupled with lower book sales after the clubs began.
2. **Support.** A door count records entrances, not purchase transactions; the new program might attract a low-purchase category of visits.
3. **Prephrase.** Distinguish repeat meetings from shopping trips to make both measures compatible.
4. **Why (A) is right.** Choice (A) explains the added entrances without corresponding purchases and makes the owner’s expectation fail: the new visitor mix is dominated by club attendance rather than buying.
5. **Why the others fail.**
   - **(B)** New shelves might change shopping choices, but no direction or effect on the visitor-to-buyer conversion is given.
   - **(C)** Stocking club titles might encourage purchases, but it does not explain why existing customers bought fewer books while visits increased; it points in the wrong direction.
   - **(D)** This clarifies the metric but does not itself show why more entrances produced fewer sales; (A) supplies the causal composition.
   - **(E)** Stationery browsing among purchasers is compatible with either sales trend and does not explain the lost book transactions.

**Check:** Door-count visits can rise through repeat nonbuyers even while purchase transactions fall.
::::
:::

## 28.2 Section II: Reading Comprehension

**Four passage sets, 27 questions. 35 minutes.** Base every answer on the passage, not outside knowledge.

### Passage 1

A licensing agency faced with thousands of annual renewal applications might use software to rank the files most likely to contain safety violations. Such a system appears to change only the order of inspections: staff still decide whether an application satisfies the law. Yet being placed near the top of the inspection queue can impose costs on a business, while receiving a low-risk score can delay the discovery of an actual hazard. For this reason, the familiar distinction between an automated recommendation and a human decision may conceal more than it clarifies. The recommendation itself can shape the practical consequences of government oversight.

Some commentators respond by demanding that every applicant receive the model's full source code. Their proposal treats transparency as a matter of making technical machinery visible. But even a complete description of an algorithm may do little for a license holder who needs to know why a particular inspection was triggered. A model can depend on hundreds of interacting variables, and specialists may disagree about which variable mattered most in a single case. Furthermore, revealing exact fraud-detection thresholds could make it easier to design applications that avoid scrutiny. These difficulties do not establish that the agency should be free from explanation; they show that explanation should be defined by the use to which it will be put.

A more promising approach begins by distinguishing three audiences. Internal auditors need enough information to test whether the system systematically overlooks certain hazards or subjects certain businesses to unwarranted scrutiny. A reviewing court needs to know which legally permitted factors the agency relied on and whether a human official could override the ranking. Individual license holders generally need a narrower, actionable account: what information about their application was used, what they can correct, and how to request human reconsideration. These accounts need not be identical. Indeed, delivering the same technical report to every audience might obscure the question each is entitled to ask.

This division of explanatory tasks does not permit officials to hide behind a model. If an agency says that an application was inspected because 'the computer selected it,' it has supplied an account of workflow, not a justification for governmental action. Nor does a human signature automatically make a decision genuinely human. An official who routinely approves every model recommendation without understanding its stated grounds adds little accountability. Responsibility rests with the institution that chooses the model, defines its permitted inputs, and decides how outputs affect people.

The better legal question, then, is not whether automated tools should be allowed to influence licensing decisions at all. It is whether the agency can connect each consequential use of such tools to reasons appropriate for evaluation and challenge. That standard leaves room for useful prediction while preserving a meaningful opportunity to question how public power has been exercised. It is more demanding than merely publishing code, but less sweeping than forbidding software a role in administrative judgment.

:::problem[Question II.1]
Which one of the following most accurately expresses the main point of the passage?

- **(A)** Licensing agencies should release the complete source code of every algorithm they use, even when doing so compromises enforcement.
- **(B)** When agencies use algorithms in consequential licensing processes, they should provide explanations fitted to the needs of those who must evaluate or contest the resulting action.
- **(C)** Because technical models are rarely comprehensible to laypeople, agencies should abandon predictive inspection tools entirely.
- **(D)** The main legal problem with algorithmic decisions is that officials sometimes choose poor software vendors.
- **(E)** A license holder's explanation should always contain every technical detail made available to internal auditors.

::::solution[Solution]
**Answer:** (B)

**Type:** Main point (Chapter 18)

1. **Conclusion.** The author argues for use-specific reason giving and meaningful challenge, not blanket disclosure or prohibition.
2. **Support.** The passage moves from effects of rankings through limits of source-code transparency to three audiences and institutional accountability.
3. **Prephrase.** Choose a thesis that captures both permission to use predictions and a demand for explanations appropriate to those affected.
4. **Why (B) is right.** Choice (B) reflects the final paragraph's standard and the detailed framework of the third: audiences require different reasons for evaluation and challenge.
5. **Why the others fail.**
   - **(A)** This is the commentator's rejected all-code proposal; the author notes that releasing thresholds can create enforcement risks.
   - **(C)** A total ban is broader than the author endorses; the final paragraph expressly leaves room for prediction.
   - **(D)** Vendor choice is not the dispute. The passage emphasizes institutional responsibility regardless of who supplies the model.
   - **(E)** The author explicitly says accounts need not be identical across audiences; this reverses the tailoring principle.

**Check:** Compare (B) to the final paragraph's 'reasons appropriate for evaluation and challenge.'
::::
:::

:::problem[Question II.2]
According to the passage, which one of the following would generally be most useful to an individual license holder seeking to challenge an inspection triggered by the model?

- **(A)** A technical report documenting every test that the model's developers performed while building it.
- **(B)** A guarantee that the agency will never use automated rankings for another inspection.
- **(C)** The names and academic qualifications of every programmer who worked on the model.
- **(D)** An account of the application information used and the means of correcting it and requesting human reconsideration.
- **(E)** A public ranking of every other license holder in the agency's inspection queue.

::::solution[Solution]
**Answer:** (D)

**Type:** Detail (Chapter 18)

1. **Conclusion.** This detail question targets what the author says applicants themselves need, as distinct from auditors and courts.
2. **Support.** The third paragraph assigns individualized, actionable information about inputs, correction and reconsideration to license holders.
3. **Prephrase.** Return to the three-audience distinction; select the applicant-facing account rather than internal diagnostics.
4. **Why (D) is right.** Choice (D) closely tracks the third paragraph's three concrete applicant needs, including a route for challenging errors.
5. **Why the others fail.**
   - **(A)** Testing documentation fits an internal auditor's task, not generally an applicant's narrower, actionable question; it is an audience swap.
   - **(B)** The author permits some algorithmic use, so an unconditional ban is unsupported and unnecessarily broad.
   - **(C)** Programmers' credentials do not explain why this particular application was flagged; it substitutes authority for reasons.
   - **(E)** Competitors' queue positions are neither listed as necessary nor helpful to correct one's own data; it is an irrelevant comparison.

**Check:** Third paragraph: individual applicants need used information, correction and human reconsideration.
::::
:::

:::problem[Question II.3]
The discussion of revealing exact fraud-detection thresholds in the second paragraph serves primarily to...

- **(A)** illustrate a practical drawback of one proposed approach to transparency without denying the importance of providing explanations.
- **(B)** establish that fraud is the most frequent violation found through automated inspections.
- **(C)** demonstrate that all members of the public are legally prohibited from inspecting government source code.
- **(D)** show that even trained auditors cannot determine whether algorithmic systems are biased.
- **(E)** support the claim that an applicant should never be told which information triggered an inspection.

::::solution[Solution]
**Answer:** (A)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** The threshold example qualifies a proposal to publish complete machinery; it is not a rejection of accountability.
2. **Support.** The author first discusses why full code can be unhelpful, adds possible gaming of exact thresholds, then explicitly insists explanation remains necessary.
3. **Prephrase.** Identify the example as a reason to design disclosure by purpose rather than demand indiscriminate exposure.
4. **Why (A) is right.** Choice (A) preserves the local argumentative move and the qualification that follows it in the second paragraph.
5. **Why the others fail.**
   - **(B)** The text supplies no violation frequencies; this invents a statistic based on one illustrative type of threshold.
   - **(C)** An enforcement risk is not a claim about universal legal secrecy; this overstates the example.
   - **(D)** Auditors are later said to need meaningful testing information; the passage does not portray their task as impossible.
   - **(E)** The third paragraph affirmatively calls for telling applicants the information used; this directly conflicts with the proposed reading.

**Check:** The sentence after the example says difficulties redefine explanation, not eliminate it.
::::
:::

:::problem[Question II.4]
Which one of the following can be most reasonably inferred from the author's discussion of human officials approving model recommendations?

- **(A)** A machine-generated ranking may never be used when the final licensing decision is made by a person.
- **(B)** Human officials routinely understand every factor in a model's calculation before signing their names.
- **(C)** A person who overrides a model recommendation is necessarily correct about the legal outcome.
- **(D)** Models become legally accountable institutions as soon as a human official approves an output.
- **(E)** Formal involvement by a human official does not by itself ensure that an agency exercises meaningful independent judgment.

::::solution[Solution]
**Answer:** (E)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The inference concerns the difference between a human signature and substantive accountability.
2. **Support.** The fourth paragraph says automatic approval without understanding adds little, and assigns responsibility to the institution designing the use.
3. **Prephrase.** Avoid extremes; infer that mere human sign-off is insufficient, not that all human review fails.
4. **Why (E) is right.** Choice (E) is the one-step consequence of the author's claim that an official's routine, uncomprehending signature adds little accountability.
5. **Why the others fail.**
   - **(A)** The author rejects an absolute ban on model influence; this falsely turns criticism into prohibition.
   - **(B)** The passage suggests precisely the opposite problem can occur: officials may not understand model grounds.
   - **(C)** Overriding a recommendation is not said to guarantee correctness; it confuses independence with accuracy.
   - **(D)** The institution, not the model itself, bears responsibility; this changes the actor being held accountable.

**Check:** A human signature without examining reasons is the author's example of inadequate accountability.
::::
:::

:::problem[Question II.5]
The author's attitude toward predictive tools in licensing is best characterized as...

- **(A)** unqualified enthusiasm for replacing inspectors with automated systems.
- **(B)** indifference to whether automated rankings affect businesses before final decisions.
- **(C)** qualified acceptance, conditioned on reason giving, oversight and opportunities to contest consequential uses.
- **(D)** suspicion of all technical explanations as inherently deceptive.
- **(E)** confidence that publication of source code alone resolves accountability problems.

::::solution[Solution]
**Answer:** (C)

**Type:** Author's attitude (Chapter 18)

1. **Conclusion.** This tone question asks for the balance of the author’s policy stance across the passage.
2. **Support.** The author acknowledges predictive tools' usefulness, rejects both code-only disclosure and outright prohibition, and demands fit-for-purpose accountability.
3. **Prephrase.** Expect a moderate, conditional approval rather than absolute praise or rejection.
4. **Why (C) is right.** Choice (C) incorporates both the author's openness to tools and the institutional obligations repeatedly emphasized.
5. **Why the others fail.**
   - **(A)** The author treats rankings as consequential and insists on human responsibility, not replacement; it overshoots approval.
   - **(B)** The opening paragraph focuses on burdens produced before final decision, directly contradicting indifference.
   - **(D)** Explanations are called necessary even if the form should change; this converts a critique of one explanation into distrust of all.
   - **(E)** The second paragraph calls full-code release potentially unhelpful or risky; this attributes a rejected view to the author.

**Check:** The final paragraph explicitly describes a standard between total code disclosure and prohibition.
::::
:::

:::problem[Question II.6]
Which one of the following agency practices would most clearly satisfy the standard advocated in the passage?

- **(A)** A licensing office records the factors supporting each flagged inspection, tests patterns of erroneous flags, and offers applicants a process to correct relevant data and request independent review.
- **(B)** An office publishes its inspection algorithm but refuses to explain why any individual application was flagged.
- **(C)** Inspectors agree to approve every high-risk label as long as a supervisor countersigns their paperwork.
- **(D)** An office stops using predictive rankings but refuses to give reasons for its wholly manual inspections.
- **(E)** An office sends all applicants a dense engineering report while restricting access to their own application records.

::::solution[Solution]
**Answer:** (A)

**Type:** Application (Chapter 18)

1. **Conclusion.** The application should realize different accounts for auditors and applicants while maintaining reviewable institutional responsibility.
2. **Support.** The passage lists testing for auditors, understandable reasons for decision-makers and corrections for applicants.
3. **Prephrase.** Select a policy combining oversight, reasons and an actionable challenge route; no single technical gesture is enough.
4. **Why (A) is right.** Choice (A) covers the three functions most directly relevant: audits of patterns, documented grounds and individual correction and review.
5. **Why the others fail.**
   - **(B)** Publishing code alone is explicitly criticized for leaving individual reasons unexplained; this is a transparency shell game.
   - **(C)** Rubber-stamped decisions are the author's example of superficial human involvement, not accountability.
   - **(D)** Avoiding algorithms does not excuse unexplained governmental action; it mistakes a means for the underlying duty.
   - **(E)** A uniform technical report disregards applicant needs and withholds practical correction information.

**Check:** Test each of (A)'s components against the three-audience list and the fourth paragraph's accountability demand.
::::
:::

:::problem[Question II.7]
Which one of the following best describes how the passage is organized?

- **(A)** It presents a technical history of licensing algorithms, compares vendors and ends with procurement advice.
- **(B)** It argues that automated rankings have no effects until an official signs an order, then defends judicial deference.
- **(C)** It identifies a difficulty with seemingly advisory rankings, critiques a sweeping transparency response, proposes audience-specific explanations, and articulates an accountability standard.
- **(D)** It lists several court cases, establishes a single mandatory reporting form and rejects any use of prediction.
- **(E)** It begins with a recommended statutory reform, retracts it after considering criticism, and declines to offer an alternative.

::::solution[Solution]
**Answer:** (C)

**Type:** Structure / organization (Chapter 18)

1. **Conclusion.** The passage's overall progression is from a hidden practical problem toward a qualified institutional solution.
2. **Support.** Paragraphs one through five successively develop consequences, limits of publishing code, audience needs, nondelegable responsibility and a final standard.
3. **Prephrase.** Choose a sequence that captures both the criticism and constructive proposal rather than only one paragraph.
4. **Why (C) is right.** Choice (C) accurately reflects the sequence and the distinct job each major paragraph performs.
5. **Why the others fail.**
   - **(A)** There is no history of software development or vendor comparison; this substitutes a technical survey for legal reasoning.
   - **(B)** The first paragraph expressly says rankings can have consequences before the ultimate decision; this reverses the opening claim.
   - **(D)** No court decisions or one-size-fits-all form are provided, and an outright ban is rejected; this invents content.
   - **(E)** The author continues to propose a concrete standard, so describing the ending as indecision misses the resolution.

**Check:** Outline the five paragraphs as effects → code limits → audience differentiation → responsibility → standard.
::::
:::

### Passage 2

After a grassland fire, seeds that have lain dormant in the soil for years sometimes sprout in remarkable numbers. The obvious explanation is that heat breaks down the hard outer coats of the seeds. For certain species that account is well supported. But field biologists studying a small group of perennial shrubs noticed a complication: seedlings occasionally appeared in unburned patches downwind of fires, where soil temperatures had barely changed. The observation suggested that heat might not be the only signal that dormant seeds use to begin growing.

The researchers gathered seeds from several sites and divided them among trays receiving different treatments. One group experienced a brief pulse of heat comparable to the temperature measured near the soil surface after a moderate fire. A second received cooled, filtered smoke without measurable heat exposure. A third received both treatments, and a fourth received neither. After several weeks, germination was frequent in the smoke-only trays, modest in the heat-only trays, and rare in the untreated trays. The combined treatment produced many seedlings, but not reliably more than the smoke-only treatment. Those results supported a role for a chemical cue in smoke, though they did not identify which compound was responsible.

The next problem was interpretation. A laboratory tray holds moisture and temperature nearly constant, unlike the soil of an actual grassland. In the field, burned areas also contain less vegetation competing for light, and rain often arrives at different times from one season to another. The researchers therefore placed mesh-covered seed packets in paired burned and unburned plots. Some unburned plots were briefly exposed to diluted smoke carried through a pipe; others served as controls. When rain came, the smoked unburned plots showed greater germination than untreated unburned plots, although the increase was smaller than in the laboratory. Burned plots still produced the largest number of surviving seedlings.

The contrast between germination and survival matters. Smoke may prompt a seed to sprout, but a newly emerged seedling in dense, unburned vegetation may die before its first dry season. A fire can create both the signal to germinate and the open space that improves survival. Counting sprouts shortly after rain would therefore overstate how fully smoke exposure reproduces the ecological effects of burning. The researchers' findings challenge the claim that heat is the only trigger, not the claim that fire can have effects which are difficult to imitate.

Land managers have considered using smoke-infused water to establish these shrubs in restored grassland without conducting controlled burns. The experiments give that idea a plausible biological basis, but they do not yet show that it will produce self-sustaining populations. A responsible trial would track plants for several growing seasons and compare survival, not simply initial sprouting. The discovery is significant precisely because it identifies one part of a complex process while making clearer which other parts remain unresolved.

:::problem[Question II.8]
Which one of the following most accurately states the main point of the passage?

- **(A)** Heat is irrelevant to the germination of all shrubs that grow in burned grasslands.
- **(B)** Smoke exposure is sufficient to reproduce every ecological benefit of a grassland fire.
- **(C)** Field experiments are generally less reliable than controlled laboratory experiments in plant science.
- **(D)** Smoke can provide a germination cue independent of heat for some dormant shrubs, but successful restoration requires attention to later survival conditions.
- **(E)** The chemical in smoke responsible for germination has been isolated and is ready for commercial use.

::::solution[Solution]
**Answer:** (D)

**Type:** Main point (Chapter 18)

1. **Conclusion.** The author distinguishes one identified germination signal from the larger processes needed for lasting plant establishment.
2. **Support.** The laboratory and field treatments point to smoke, while burned plots and survival analysis show that sprouting alone is not restoration.
3. **Prephrase.** Find a two-part claim recognizing the cue and the limitation; resist the lure of an absolute about fire.
4. **Why (D) is right.** Choice (D) captures the experimental finding and the author's insistence on tracking survival before recommending management.
5. **Why the others fail.**
   - **(A)** Heat remains effective for some species and treatments; the passage rejects heat as the only cue, not as a cue.
   - **(B)** The field plots show burned sites have more surviving seedlings, so smoke does not reproduce all benefits.
   - **(C)** The author uses both research settings and discusses what each can establish; no general ranking is proposed.
   - **(E)** The responsible compound is explicitly unidentified and practical success unproven; this upgrades speculation to result.

**Check:** The final paragraph endorses a smoke-based trial, not a proven self-sustaining restoration method.
::::
:::

:::problem[Question II.9]
According to the passage, how did seeds given both heat and smoke respond in the laboratory tests?

- **(A)** They failed to germinate because the two signals interfered with each other.
- **(B)** They germinated frequently, but not consistently more often than seeds given smoke alone.
- **(C)** They germinated only if competing vegetation had first been removed.
- **(D)** They produced fewer seedlings than the completely untreated trays in every trial.
- **(E)** They survived multiple dry seasons at higher rates than seeds exposed only to heat.

::::solution[Solution]
**Answer:** (B)

**Type:** Detail (Chapter 18)

1. **Conclusion.** This detail question concerns the comparative result of the combined laboratory treatment.
2. **Support.** The second paragraph reports frequent germination in smoke-only trays and says adding heat did not reliably improve that result.
3. **Prephrase.** Retrieve the precise comparison and avoid conflating initial sprouting with later field survival.
4. **Why (B) is right.** Choice (B) preserves both parts: many seedlings and no reliable increment beyond smoke alone.
5. **Why the others fail.**
   - **(A)** The combined group did produce many seedlings; interference is invented.
   - **(C)** Competition is a field issue, not part of the laboratory germination condition; this transports a later factor backward.
   - **(D)** Untreated trays had rare germination, so this reverses the direction of the observed comparison.
   - **(E)** Multiseason survival was not tracked in the tray tests; this converts germination into unreported survival data.

**Check:** Second paragraph: 'many seedlings, but not reliably more than ... smoke-only.'
::::
:::

:::problem[Question II.10]
Which one of the following is most strongly supported by the reported field experiments?

- **(A)** Seedlings in smoked unburned plots survived better than those in burned plots.
- **(B)** Smoke exposure changes the genetic makeup of dormant shrub seeds.
- **(C)** All plant species in the grassland respond identically to diluted smoke.
- **(D)** The presence of fire is required for any seeds of the studied shrubs to sprout outdoors.
- **(E)** Some dormant seeds can be prompted to germinate in an unburned setting without receiving the heat of a fire.

::::solution[Solution]
**Answer:** (E)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The inference concerns what the smoke-treated unburned plots demonstrate, within their limited ecological setting.
2. **Support.** Those plots had greater germination than unsmoked unburned controls, without fire heating the soil.
3. **Prephrase.** Take one modest step from the controlled field comparison: some germination can occur due to a nonheat cue.
4. **Why (E) is right.** Choice (E) directly follows from the increased germination in plots exposed to smoke alone and does not claim survival or universal scope.
5. **Why the others fail.**
   - **(A)** Burned plots had the most surviving seedlings, so this reverses the survival comparison.
   - **(B)** The experiments examine behavior, not genetic change; this invents a molecular mechanism.
   - **(C)** Only a small group of shrubs was studied, and no universal species response was claimed.
   - **(D)** Smoke-treated unburned plots are the counterexample to requiring a fire for every germination event.

**Check:** Unburned + smoke → more sprouts than unburned control, without exposure to fire heat.
::::
:::

:::problem[Question II.11]
Why does the author describe the researchers' mesh-covered seed packets in burned and unburned field plots?

- **(A)** To establish that smoke-infused water can already replace prescribed burning in every restoration project.
- **(B)** To show how researchers tested whether a laboratory-observed smoke response would also occur under more realistic environmental conditions.
- **(C)** To demonstrate that the original observations of seedlings downwind were fabricated.
- **(D)** To measure precisely which smoke molecule causes shrubs to germinate.
- **(E)** To prove that differences in rainfall never influence germination in grasslands.

::::solution[Solution]
**Answer:** (B)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** The field procedure addresses a limitation in transferring findings from controlled trays to actual habitats.
2. **Support.** The third paragraph introduces real-world variation and then details paired plots and controls as a follow-up test.
3. **Prephrase.** Locate the experiment's explanatory role: checking whether a controlled effect persists outside the laboratory.
4. **Why (B) is right.** Choice (B) captures why the method is introduced and why the smaller but positive field effect matters.
5. **Why the others fail.**
   - **(A)** The conclusion cautions that restoration success is not established; this exaggerates the purpose into policy proof.
   - **(C)** The downwind reports motivated the study; the author never accuses observers of fabrication.
   - **(D)** The experiments establish an effect without identifying the active chemical, explicitly an unresolved question.
   - **(E)** Rain remains a variable that matters; the plots do not eliminate it from all ecosystems or years.

**Check:** The third paragraph begins by contrasting stable lab conditions with variable field soil conditions.
::::
:::

:::problem[Question II.12]
Which one of the following findings would most seriously undermine the inference that smoke itself caused greater germination in the treated unburned field plots?

- **(A)** The field plots experienced slightly colder nights than the laboratory trays did.
- **(B)** Heat-treated seeds in the laboratory sometimes germinated without smoke.
- **(C)** Some shrubs produce seeds that remain dormant for multiple years.
- **(D)** Survival of seedlings in burned plots was higher than survival in unburned plots.
- **(E)** The apparatus that delivered diluted smoke also delivered substantially more water to treated plots than to controls, and added water alone produces a comparable germination increase.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen / weaken a passage claim (Chapter 18)

1. **Conclusion.** The target claim attributes the increased field germination to smoke exposure, not to some other treatment difference.
2. **Support.** In treated plots, a pipe delivers smoke, but if it also changes moisture levels the field contrast becomes confounded.
3. **Prephrase.** Find an uncontrolled intervention that independently triggers the same outcome.
4. **Why (E) is right.** Choice (E) introduces extra water as an alternative cause, validated by a water-only comparison, directly undermining the causal interpretation.
5. **Why the others fail.**
   - **(A)** Lab-field temperature differences may change effect size but do not explain a difference between the paired field plots.
   - **(B)** Heat-only germination for some seeds is already compatible with smoke being another effective cue.
   - **(C)** Dormancy duration is background, not an alternative explanation for treatment-specific sprouting.
   - **(D)** The author already distinguishes survival from germination; higher burned-plot survival does not undermine the unburned germination comparison.

**Check:** If smoke-treated plots also got extra causal water, their extra sprouts no longer isolate smoke.
::::
:::

:::problem[Question II.13]
The author's attitude toward using smoke-infused water in grassland restoration is best described as...

- **(A)** dismissive, because all field evidence contradicts the laboratory results.
- **(B)** certain that the technique will establish self-sustaining shrub populations without any additional testing.
- **(C)** cautiously receptive, because the experiments support testing the approach but not assuming long-term success.
- **(D)** indifferent, because the research addresses only chemical composition rather than plants.
- **(E)** opposed on the grounds that smoke can never stimulate germination without high temperatures.

::::solution[Solution]
**Answer:** (C)

**Type:** Author's attitude (Chapter 18)

1. **Conclusion.** The author accepts the new biological lead while withholding judgment about practical restoration outcomes.
2. **Support.** The last paragraph calls the idea plausible, recommends a trial, and requires tracking over growing seasons.
3. **Prephrase.** Look for calibrated optimism tied to evidence rather than automatic acceptance or rejection.
4. **Why (C) is right.** Choice (C) mirrors both the proposed management trial and the unproven nature of self-sustaining populations.
5. **Why the others fail.**
   - **(A)** The field comparison supports a smaller but real smoke response; this reverses the evidence.
   - **(B)** The author says trials have not yet established self-sustaining populations; this ignores the limitation.
   - **(D)** The central evidence concerns germination and survival, not merely smoke chemistry; it misdescribes the topic.
   - **(E)** Smoke-only lab and unburned-field responses are the key findings; this directly contradicts them.

**Check:** Final paragraph: plausible biological basis, but no demonstrated lasting population.
::::
:::

:::problem[Question II.14]
Which one of the following situations most closely illustrates the distinction the author draws between germination and long-term establishment?

- **(A)** A technique causes fish eggs to hatch in a hatchery tank, but released young fish fail to survive unless suitable shelter is also available.
- **(B)** A measurement instrument detects the same temperature in two adjacent laboratory rooms.
- **(C)** A mineral dissolves more rapidly at higher temperatures regardless of the shape of its container.
- **(D)** Two identical flower pots receive equal amounts of light and water and produce equally tall plants.
- **(E)** A tree grows slowly in its first year but more rapidly after it has matured.

::::solution[Solution]
**Answer:** (A)

**Type:** Application / analogy (Chapter 18)

1. **Conclusion.** The author distinguishes an event that begins development from later environmental requirements for persistence.
2. **Support.** Smoke triggers sprouts, while cleared space and competition affect whether seedlings endure.
3. **Prephrase.** Find a case where a successful initial biological trigger fails to ensure a later survival outcome.
4. **Why (A) is right.** In (A), hatching parallels germination, while adequate shelter parallels open space for continuing survival. The initial success is necessary to the outcome but not sufficient.
5. **Why the others fail.**
   - **(B)** Two equal measurements contain no distinction between an initiating event and later persistence.
   - **(C)** Dissolution rate concerns one process, not the survival of a system after an initial trigger.
   - **(D)** Identical treatment and outcome omit the crucial split between triggering and maintaining development.
   - **(E)** Different growth rates across age do not show that an initial cue works while long-term survival requires another condition.

**Check:** Trigger ≠ establishment: hatching ≠ survival, just as sprouting ≠ self-sustaining population.
::::
:::

### Passage 3 (comparative)

**Passage A**

When a centuries-old wall painting has lost large sections, visitors often see little more than fragments of color. Digital projectors can now cast a conjectural reconstruction over the remaining surface, briefly showing how the image might once have appeared. To some curators, this seems a humane way to make damaged art legible. I oppose on-wall projections as the main visitor experience. The original surface includes cracks, erased figures, and repairs made by later generations. Those changes are part of the work's history, not visual noise standing between the viewer and an imagined pristine original.

An illuminated reconstruction is especially persuasive because light fits the contours of surviving paint. Even a careful visitor may confuse what scholars have inferred with what has physically endured. Labels that announce the provisional status of the projection can help, but they cannot entirely neutralize the authority of a seamless image. I would allow a reconstruction as an optional, clearly separated interpretive display, preferably on a nearby screen. Visitors should encounter the surviving wall first, with its losses visible, before deciding whether to view a proposal for what is missing.

Consider a visitor who sees a projected hand holding an object that no longer survives in the plaster. A curator may have selected that object from a plausible inventory of symbols, but the choice can also crowd out alternatives that future research might support. Separating the reconstruction from the wall encourages viewers to treat it as one scholarly proposal rather than an invisible completion of the artifact.

**Passage B**

It is mistaken to assume that an unprojected wall gives viewers unmediated access to the past. Museums already arrange lighting, choose viewing distances, and provide labels that guide perception. Where extensive damage renders a mural almost unintelligible, withholding a reconstruction can make the surviving pigment appear like a purely decorative pattern. I favor brief projections on the wall itself, provided that uncertain portions are visibly distinguished from documented ones and that the display alternates with intervals showing only the surviving material.

Such a projection should never be described as the mural 'restored.' Its role is to disclose an argument about composition: the proposed location of a missing figure, for example, could explain why a surviving figure faces an otherwise empty area. Viewers can compare the proposal with the evidence when the light turns off. A nearby screen may be useful for detailed research notes, but it cannot reveal spatial relationships on the original surface as immediately as an aligned projection can. The ethical task is not to avoid interpretation, which is impossible, but to make its uncertainty and reversibility apparent.

The distinction between a conjectural and a documented segment need not rely on lengthy written warnings. Different light textures or a visible outline can keep the viewer aware of uncertainty throughout the demonstration. If a new pigment analysis overturns a hypothesis, the projection can change without touching the wall. That capacity for revision is an advantage over physical repainting, which may be difficult to undo.

:::problem[Question II.15]
The authors of passages A and B most clearly disagree about whether...

- **(A)** a damaged wall painting can possess historical value beyond its reconstructed original design.
- **(B)** interpretive choices made by museum staff can affect visitors' perceptions.
- **(C)** uncertainties in reconstructing missing portions of a mural should be acknowledged.
- **(D)** a carefully distinguished digital reconstruction should sometimes be projected directly onto the surviving wall as part of the main visitor experience.
- **(E)** physical repainting of a damaged mural can be difficult to undo.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative reading: central disagreement (Chapter 17)

1. **Conclusion.** A's position favors viewing the original wall before any optional reconstruction shown separately; B favors brief, visibly marked projections onto the wall.
2. **Support.** A fears seamless projections confer unwarranted authority; B believes aligned projections can convey relationships impossible to perceive on screens alone.
3. **Prephrase.** Pick the exact disputed policy, not a concern both writers share or a topic only one addresses.
4. **Why (D) is right.** Choice (D) pinpoints the operational disagreement: A resists wall-centered projection; B endorses it when marked and alternated with unprojected viewing.
5. **Why the others fail.**
   - **(A)** A values later damage and repairs; B does not deny their historical value. This is not a demonstrated opposition.
   - **(B)** B explicitly notes museums already mediate viewing; A likewise warns projections shape perception. Both recognize interpretive influence.
   - **(C)** Both demand disclosure of conjecture, even though they disagree about how to do it; this is shared ground.
   - **(E)** B explicitly contrasts reversible projection with physical repainting, but A gives no contrary view; this fails the 'both must have a stake' test.

**Check:** A says separate reconstruction from wall; B recommends aligned wall projection under safeguards.
::::
:::

:::problem[Question II.16]
Both authors would most likely agree with which one of the following statements?

- **(A)** The most effective reconstruction is one that conceals the difference between surviving and hypothesized portions.
- **(B)** An unprojected mural presents the past without the influence of any interpretive choices.
- **(C)** When displaying a hypothesized reconstruction, a museum should avoid presenting uncertain elements as though they had physically survived.
- **(D)** Wall projections must be prohibited even when they can be switched off without altering the paint.
- **(E)** A separate screen always conveys spatial relationships better than a wall-aligned image.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative reading: point of agreement (Chapter 17)

1. **Conclusion.** Both writers recognize scholarly reconstruction as conjectural and call for keeping it distinguishable from surviving evidence.
2. **Support.** A fears the authority of seamless projected completions; B calls for visibly differentiated uncertain portions and alternating unprojected viewing.
3. **Prephrase.** Seek a modest preservation-of-uncertainty commitment supported by both, not the display method on which they differ.
4. **Why (C) is right.** Choice (C) articulates their common epistemic safeguard without deciding the contested location of a projection.
5. **Why the others fail.**
   - **(A)** Both worry about merging conjecture with evidence, so concealment contradicts their shared concern.
   - **(B)** B explicitly rejects unmediated viewing, and A's caution does not affirm the absolute claim.
   - **(D)** A permits optional reconstruction in another place while B favors wall projection; a total ban is not shared.
   - **(E)** B says the opposite about aligned projections, making this a position-confusion trap.

**Check:** A's warning about seamless images and B's requirement to distinguish uncertain areas converge on (C).
::::
:::

:::problem[Question II.17]
Which one of the following best describes how the author of passage A would likely respond to B's claim that wall-aligned projection can reveal spatial relationships more immediately than a nearby screen?

- **(A)** By denying that missing figures can ever be tentatively reconstructed from surviving ones.
- **(B)** By conceding that alignment may help perception while maintaining that a persuasive projection risks being mistaken for surviving evidence.
- **(C)** By agreeing that the projection should replace the unprojected wall as the permanent display.
- **(D)** By insisting that projection equipment physically alters ancient pigment in every case.
- **(E)** By arguing that scientific uncertainty is irrelevant to how museums present the past.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative reading: author response (Chapter 17)

1. **Conclusion.** Passage A prioritizes making loss visible and fears an apparently seamless completion, even if it is pedagogically effective.
2. **Support.** A recognizes the appeal of making damaged art legible but warns that aligned light can look authoritative; B stresses the perceptual benefits of that alignment.
3. **Prephrase.** Expect a partial concession to usefulness followed by A's retained objection about confusing hypothesis with material survival.
4. **Why (B) is right.** Choice (B) respects both A's opening concession and A's central reservation. It does not falsely treat A as denying projection's attractiveness.
5. **Why the others fail.**
   - **(A)** A discusses conjectural reconstructions as possible options, not as logically impossible; this overstates skepticism.
   - **(C)** A specifically advocates encountering the surviving wall first, not replacing it with a permanent projection.
   - **(D)** A's concern is interpretive authority, not alleged unavoidable physical damage from light; it changes the objection.
   - **(E)** A's whole argument is about representing uncertainty faithfully, so this directly contradicts the stance.

**Check:** A: projections help legibility, but seamless alignment may conceal the line between inference and survival.
::::
:::

:::problem[Question II.18]
According to passage B, what should occur when a reconstruction is projected onto a damaged mural?

- **(A)** Speculative portions should be visibly distinguished, and periods of projection should alternate with viewing of the surviving surface alone.
- **(B)** The remaining pigment should be covered with new paint so the projected image can be seen more clearly.
- **(C)** The projected reconstruction should be described as the mural fully restored to its original state.
- **(D)** The image should remain continuously displayed to prevent visitors from seeing misleading fragments.
- **(E)** Research notes should be withheld so viewers can form wholly independent interpretations.

::::solution[Solution]
**Answer:** (A)

**Type:** Detail (Chapter 18)

1. **Conclusion.** This detail asks for B's explicit conditions on acceptable wall projection.
2. **Support.** B's first paragraph requires differentiation of uncertain and documented elements and alternation with unprojected intervals.
3. **Prephrase.** Find the combination of both safeguards, not merely a general endorsement of digital projection.
4. **Why (A) is right.** Choice (A) restates both of B's stated conditions and preserves the temporary, visibly provisional nature of the display.
5. **Why the others fail.**
   - **(B)** B prefers reversible light to repainting and never proposes covering original pigment; this substitutes physical intervention.
   - **(C)** B explicitly rejects the label 'restored' and describes the projection as a proposed argument.
   - **(D)** B says to alternate with surviving material, so a permanently projected image reverses the timing requirement.
   - **(E)** B calls for detailed notes on nearby screens; withholding them would conceal the argument's evidence.

**Check:** B's first paragraph: distinguish conjecture visibly, then alternate projection on/off.
::::
:::

:::problem[Question II.19]
The author of passage A describes a projected hand holding an object that no longer survives primarily to...

- **(A)** prove that any surviving hand in a mural was originally painted without an object.
- **(B)** show that curators can reproduce a lost painting with complete historical certainty.
- **(C)** establish that later repairs on paintings are invariably superior to the originals.
- **(D)** illustrate why digital projection is physically more damaging than repainting.
- **(E)** illustrate how one plausible reconstructed detail can make other possible interpretations less apparent to viewers.

::::solution[Solution]
**Answer:** (E)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** A warns that convincing reconstructions may be mistaken for complete or uniquely correct accounts.
2. **Support.** The hand example features a plausible but chosen missing object that could crowd out alternatives pending new research.
3. **Prephrase.** Identify the example's caution about apparent certainty and foreclosed hypotheses.
4. **Why (E) is right.** Choice (E) follows the paragraph's explanation that one curator's selection may suppress other possible readings.
5. **Why the others fail.**
   - **(A)** The example does not say the original hand was empty; it says the held object is no longer available as evidence.
   - **(B)** A describes conjecture, not certainty; this turns a warning into the very view being criticized.
   - **(C)** Later repairs are valued as history, not declared categorically better than original painting; this is an extreme extrapolation.
   - **(D)** A's stated concern is interpretive persuasion, not physical harm from the digital light; this switches the mechanism.

**Check:** A: 'the choice can also crowd out alternatives' immediately explains the illustration.
::::
:::

:::problem[Question II.20]
How would the author of passage B most likely respond to A's preference for showing reconstructions on a nearby screen rather than on the wall itself?

- **(A)** By arguing that screens cannot display images of murals under any circumstances.
- **(B)** By agreeing that spatial alignment has no value when interpreting partially lost figures.
- **(C)** By claiming that visitors need not be told which parts of a reconstruction are conjectural.
- **(D)** By acknowledging screens' usefulness for research notes but arguing that they do not convey relationships on the wall as directly as aligned projections do.
- **(E)** By concluding that no image reconstruction should ever be shown to visitors.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative reading: author response (Chapter 17)

1. **Conclusion.** B supports aligned projections as a uniquely clear way to show hypothesized spatial relationships, with off-wall screens playing a secondary role.
2. **Support.** B's second paragraph explicitly allows nearby screens for detailed notes but says they lack the immediacy of projection onto the original surface.
3. **Prephrase.** Find a qualified preference for on-wall alignment, not an absolute rejection of screens or evidence warnings.
4. **Why (D) is right.** Choice (D) paraphrases B's exact comparative argument: screen for notes, projected alignment for seeing proposed composition.
5. **Why the others fail.**
   - **(A)** B expressly considers screens useful for notes, so denying they can display murals is too absolute.
   - **(B)** B argues alignment is valuable, not irrelevant; this reverses the author's central reason.
   - **(C)** B requires visible distinctions and transparent provisional status; the answer removes a safeguard B supports.
   - **(E)** B advocates reconstructive projection, so a prohibition conflicts with the whole passage.

**Check:** B distinguishes screens' note-taking function from projections' on-surface spatial function.
::::
:::

### Passage 4

When a school district offers breakfast without charge to every pupil, administrators often expect participation to rise. Yet an evaluation of six middle schools found widely different results. In two schools, the share of pupils eating breakfast increased substantially; in four, it changed little. The formal benefit was identical everywhere, and each school served nearly the same menu. Initially, district officials suspected that the difference reflected families' breakfast habits. A research team argued that the physical and social setting of the meal deserved closer examination before the district attributed the results to family preference.

At the two schools with large increases, breakfast carts stood near classroom corridors, and pupils could collect food while walking to their first lesson. At the other schools, meals were served in the cafeteria before the morning bell, behind a separate entrance. Interviews suggested that some pupils viewed entering the cafeteria early as a public signal that they needed financial assistance, even though the meal had become free for everyone. Others simply arrived too late to visit the cafeteria. In this account, making a meal free removed a monetary cost but left intact a cost of visibility or inconvenience.

The researchers tested the account with a limited change. At one school with low participation, they moved breakfast distribution to a corridor for six weeks while leaving menus, prices, and opening time unchanged. Participation increased, but it rose most among pupils who had already been arriving on campus well before the bell. Interviews conducted afterward also revealed a surprise: several pupils had avoided the cafeteria not because of embarrassment, but because they preferred to spend those minutes with friends outside. The corridor cart brought food into an existing routine. The results supported the importance of location without demonstrating that stigma was the dominant barrier for every pupil.

A further difficulty arises when schools count breakfasts distributed rather than breakfasts eaten. Pupils may take food because it is conveniently available, then discard part of it. Conversely, a pupil who buys breakfast elsewhere may still be well nourished while appearing as a nonparticipant in the district's figures. The team therefore recommended tracking food waste and a voluntary measure of morning hunger along with distribution totals. These measures are imperfect, but they address outcomes that the simple participation count cannot capture.

The study does not show that corridor carts should replace cafeterias everywhere. Narrow corridors may create safety problems, and some schools lack space to store food outside a kitchen. Instead, it shows why the same formally universal program can have unequal practical reach. To assess accessibility, evaluators must examine how an institution's rules meet pupils' routines and perceptions, while resisting the temptation to interpret one behavioral measure as a complete description of well-being.

:::problem[Question II.21]
Which one of the following most accurately expresses the main point of the passage?

- **(A)** The practical accessibility of a universal breakfast program depends partly on where and how pupils encounter it, and its success should be evaluated with more than distribution counts.
- **(B)** Providing breakfast without charge inevitably increases participation equally in every school.
- **(C)** Stigma is the sole reason that pupils decline free school meals.
- **(D)** Breakfast carts should replace cafeteria service at all schools immediately.
- **(E)** District officials should measure breakfast success solely by how many meals are taken from serving areas.

::::solution[Solution]
**Answer:** (A)

**Type:** Main point (Chapter 18)

1. **Conclusion.** The passage argues that formal universal eligibility does not ensure equal access and simple uptake numbers omit important outcomes.
2. **Support.** Cross-school comparison, corridor intervention and measurement cautions each illustrate a different part of that view.
3. **Prephrase.** Choose a main point covering implementation, heterogeneous responses and the limits of one success metric.
4. **Why (A) is right.** Choice (A) captures the full argument, including the final paragraph's measured call for context-sensitive accessibility evaluation.
5. **Why the others fail.**
   - **(B)** The observed variation directly contradicts inevitability and uniform improvement.
   - **(C)** The study found both stigma and ordinary timing or social preferences; reducing all nonparticipation to stigma exaggerates one explanation.
   - **(D)** The author explicitly cautions about narrow corridors and storage constraints, so universal replacement is unsupported.
   - **(E)** The fourth paragraph warns distribution counts are inadequate alone; this is the opposite of the recommendation.

**Check:** Final paragraph combines practical reach with the danger of overinterpreting one behavioral metric.
::::
:::

:::problem[Question II.22]
According to the passage, which pupils accounted for the largest participation increase during the six-week corridor-distribution trial?

- **(A)** Those who usually arrived after the morning bell.
- **(B)** Those who previously paid full price for breakfast at the school cafeteria.
- **(C)** Those whose families had recently moved into the district.
- **(D)** Those who were already on campus well before the morning bell.
- **(E)** Those who could not eat breakfast because of medical restrictions.

::::solution[Solution]
**Answer:** (D)

**Type:** Detail (Chapter 18)

1. **Conclusion.** This is a detail retrieval about which subgroup showed the largest change under the corridor intervention.
2. **Support.** The third paragraph explicitly notes participation rose most among pupils already arriving early.
3. **Prephrase.** Locate the trial's subgroup comparison rather than assume the intervention primarily helped late arrivals.
4. **Why (D) is right.** Choice (D) is directly stated and supports the interpretation that physical location brought breakfast into routines already occurring at school.
5. **Why the others fail.**
   - **(A)** The observed largest increase was among pupils arriving early, not late; this reverses the subgroup result.
   - **(B)** The program was free at all schools, and previous payment status is not analyzed here; this invents a subgroup.
   - **(C)** Residential moves are not measured or tied to breakfast uptake; it introduces an unsupported cause.
   - **(E)** Medical dietary restrictions are not mentioned in the study and would not explain the reported specific subgroup increase.

**Check:** Third paragraph: participation 'rose most among pupils who had already been arriving ... well before the bell.'
::::
:::

:::problem[Question II.23]
Which one of the following is most strongly supported by the passage's explanation of why some pupils avoided the cafeteria?

- **(A)** Every pupil who entered a cafeteria before class was incorrectly assumed to receive financial assistance.
- **(B)** Removing the monetary cost of a service may leave barriers related to social perception or fitting the service into daily routines.
- **(C)** A corridor cart eliminates embarrassment for all pupils who use it.
- **(D)** The price of breakfast was higher at the schools with low participation.
- **(E)** Pupils' stated reasons for avoiding the cafeteria were proved false by the field trial.

::::solution[Solution]
**Answer:** (B)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The inference concerns why a free service may remain underused when its location and social meaning matter.
2. **Support.** The second and third paragraphs report visibility concerns, timing and a desire to meet friends outside, despite universal free meals.
3. **Prephrase.** Identify a qualified general implication: zero price is not the same as zero practical cost.
4. **Why (B) is right.** Choice (B) directly generalizes the text's distinction between monetary and nonmonetary barriers without claiming one is universal.
5. **Why the others fail.**
   - **(A)** Only some pupils feared such a signal, and the passage does not say every observer made that assumption; this overgeneralizes stigma.
   - **(C)** The intervention increased uptake but did not prove all embarrassment disappeared; this turns evidence of improvement into total success.
   - **(D)** The meal price was identical, free everywhere, so this contradicts a stated constant.
   - **(E)** Interviews after the trial added motives rather than showing earlier responses were dishonest; this misreads mixed explanations as falsification.

**Check:** Free meals at all six schools + uneven uptake + timing/stigma reports support (B).
::::
:::

:::problem[Question II.24]
Why does the author distinguish breakfasts distributed from breakfasts actually eaten?

- **(A)** To show that a free-breakfast policy must increase food waste in every participating school.
- **(B)** To demonstrate that pupils who eat breakfast elsewhere are necessarily malnourished.
- **(C)** To illustrate that a convenient administrative measure of participation may fail to measure the nutritional outcome the program seeks.
- **(D)** To argue that schools should stop tracking participation and measure only test scores.
- **(E)** To prove that every pupil who takes food from a cart subsequently discards it.

::::solution[Solution]
**Answer:** (C)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** The author argues that a tally of distributed meals is only a partial measure of program success.
2. **Support.** The fourth paragraph gives two counterexamples: taking food without eating it and eating outside school without being counted.
3. **Prephrase.** Look for the mismatch between observed administrative activity and actual hunger or nourishment.
4. **Why (C) is right.** Choice (C) expresses the measurement limitation the examples illustrate and motivates adding waste and hunger measures.
5. **Why the others fail.**
   - **(A)** The author describes possible waste, not an inevitable increase in every school; this imposes a universal result.
   - **(B)** Purchasing food elsewhere may leave pupils well nourished, expressly contradicting this claim.
   - **(D)** The author recommends additional measures rather than abolishing distribution counts or switching to test scores.
   - **(E)** The author says pupils may discard part of what they take, not that everyone discards everything.

**Check:** Distribution count ≠ food consumption ≠ hunger outcome; the examples separate these metrics.
::::
:::

:::problem[Question II.25]
Which one of the following judgments about the corridor trial is best supported by the passage?

- **(A)** It established that embarrassment had been the main cause of nonparticipation at all six schools.
- **(B)** It proved that the physical placement of food was irrelevant once meals were free.
- **(C)** It showed that pupils who previously ate with friends outside the building had stopped socializing.
- **(D)** It allowed the researchers to identify one uniform reason that every pupil skipped breakfast.
- **(E)** It supported the claim that meal location can affect uptake while leaving uncertain how much of the effect results from stigma rather than convenience.

::::solution[Solution]
**Answer:** (E)

**Type:** Most strongly supported (Chapter 18)

1. **Conclusion.** The researchers reach a limited causal interpretation: location matters, but its psychological mechanism varies.
2. **Support.** Moving the cart raised uptake, especially among early arrivals, and interviews showed both embarrassment and desire to be with friends.
3. **Prephrase.** Keep the supported location effect separate from an unproven exclusive stigma explanation.
4. **Why (E) is right.** Choice (E) captures the distinction the third paragraph makes explicitly and avoids attributing a single motive to all pupils.
5. **Why the others fail.**
   - **(A)** The trial occurs at one school and interviews give nonstigma reasons; this inflates both geographic scope and causal certainty.
   - **(B)** The participation rise after moving distribution demonstrates location can matter, the opposite of this statement.
   - **(C)** The passage reports pupils' preference for socializing but not the end of those interactions; this invents changed conduct.
   - **(D)** Researchers uncover multiple explanations rather than one uniform motive; this contradicts their caution.

**Check:** Location changed while menu and price stayed fixed, but interviews reveal more than one pathway.
::::
:::

:::problem[Question II.26]
Which one of the following policy situations most closely illustrates the passage's general lesson about universal eligibility and practical access?

- **(A)** A town raises the registration fee for a service and participation predictably declines.
- **(B)** A library offers free tutoring to all children, but usage rises when sessions move from a separate office into a room on the route pupils already take after school.
- **(C)** A sports club ends a free program after determining that too many participants attended.
- **(D)** A school charges only pupils with high grades for breakfast and records revenue increases.
- **(E)** A clinic advertises a paid service more heavily and sees no change in its price.

::::solution[Solution]
**Answer:** (B)

**Type:** Application / analogy (Chapter 18)

1. **Conclusion.** The lesson is that formally available, free services may be underused because participation involves visibility, detours and existing routines.
2. **Support.** Breakfast remained free, but the route through which pupils encountered it altered uptake in the trial.
3. **Prephrase.** Find another zero-fee service with a location or routine barrier changed independently of eligibility.
4. **Why (B) is right.** Choice (B) precisely parallels the distinction: tutoring remains universally free, while relocating it into a daily path increases practical access.
5. **Why the others fail.**
   - **(A)** A fee change addresses the monetary barrier that was held constant in the breakfast comparison.
   - **(C)** Canceling a popular free program does not illustrate hidden barriers to an available benefit.
   - **(D)** Charging a selected group creates different eligibility and price conditions, not the same formally universal provision.
   - **(E)** Advertising with unchanged price gives no specific example of physical or social access shaping participation.

**Check:** Free benefit constant; change in encounter location; usage increases: the same causal structure as the corridor trial.
::::
:::

:::problem[Question II.27]
The primary purpose of the passage is to...

- **(A)** argue that universal public programs are always less effective than means-tested programs.
- **(B)** describe a school district's menus without evaluating why pupils participate.
- **(C)** use a breakfast-program evaluation to show how design and measurement choices complicate judgments about effective access.
- **(D)** prove that schools should replace every cafeteria with corridor-based food service.
- **(E)** advocate ending all attempts to measure whether public programs are successful.

::::solution[Solution]
**Answer:** (C)

**Type:** Primary purpose (Chapter 18)

1. **Conclusion.** The writer uses an empirical case to refine how program accessibility and success should be assessed.
2. **Support.** The passage moves from uneven uptake through field observations and a limited trial to caution about outcome measures and context.
3. **Prephrase.** Select the purpose verb 'show/argue through evaluation,' with full-passage scope and a measured conclusion.
4. **Why (C) is right.** Choice (C) includes both recurring themes: delivery design and what the chosen metric actually measures.
5. **Why the others fail.**
   - **(A)** The passage never compares universal with means-tested policy; it concerns implementation within a universal scheme.
   - **(B)** Menus are mentioned as a control, not the subject of a neutral description; this misidentifies purpose.
   - **(D)** The author flags safety and storage reasons against adopting carts everywhere; this overshoots the conclusion.
   - **(E)** The author recommends additional measures, not abandoning evaluation; this reverses the methodological proposal.

**Check:** The final paragraph cautions about practical reach and treating one measure as a complete account.
::::
:::

## 28.3 Section III: Logical Reasoning

**25 questions. 35 minutes.** Choose the one best answer for each question.

:::problem[Question III.1]
A railway station replaced two staffed ticket windows with three touch-screen kiosks. The average time passengers spent waiting to purchase tickets fell from seven minutes to four minutes during the next month. The station manager argues that the kiosks caused the improvement and recommends installing them at other stations. A critic notes that the station may simply have received fewer passengers after a nearby office complex temporarily closed, and that shorter lines would have resulted even with the original windows.

Which one of the following, if true, most strengthens the station manager's argument?

- **(A)** Some passengers who used kiosks later asked attendants for help with platform directions.
- **(B)** The new kiosks can sell both monthly passes and single-trip tickets.
- **(C)** The cost of maintaining a kiosk is lower than paying a full-time ticket clerk.
- **(D)** During matched periods with nearly identical numbers of ticket buyers, purchasers spent less time waiting after the kiosks were installed.
- **(E)** The nearby office complex will reopen before the end of the year.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The station manager attributes shorter waits to kiosks rather than reduced demand.
2. **Support.** Waiting times declined, but the critic identifies a possible change in passenger volume.
3. **Prephrase.** A comparison holding buyer traffic roughly constant would test whether the service setup itself got faster.
4. **Why (D) is right.** Choice (D) rules out the critic's lower-volume explanation for the matched periods and preserves the wait reduction under similar demand.
5. **Why the others fail.**
   - **(A)** Help with directions concerns navigation, not ticket-purchase queues; it measures a different service.
   - **(B)** Ticket types show functionality but do not demonstrate faster processing under the same load.
   - **(C)** Lower operating costs could justify installation without showing the claimed wait-time benefit; it is a cost-versus-effect trap.
   - **(E)** Future reopening says nothing about the cause of last month's waiting-time change.

**Check:** Holding ticket-buyer volume constant, a lower postinstallation wait supports a kiosk effect.
::::
:::

:::problem[Question III.2]
A ceramics studio purchased a programmable kiln intended for both delicate ornaments and thick stoneware. During its first week, three thin-walled cups developed hairline cracks after a firing cycle. The studio director concludes that the kiln is unsuitable for making any ceramics and should be sold immediately. Yet the cups were all fired on the same experimental setting, and the director has not tested the kiln's separate programs for heavier pieces. The manufacturer's manual warns that the experimental setting is intended for preliminary calibration rather than regular production.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that every cup fired in a kiln must have the same artistic value.
- **(B)** generalizes from a few objects produced under one atypical setting to the kiln's suitability for all ceramic work.
- **(C)** fails to show that the kiln was purchased at a price lower than competing kilns.
- **(D)** reasons that because some settings are safe, all settings must be safe.
- **(E)** rejects a kiln merely because the manufacturer is unpopular with other studios.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director declares the kiln unsuitable for any ceramic production and recommends disposing of it.
2. **Support.** Only three thin cups failed under one nonproduction calibration setting; the full range of use remains untested.
3. **Prephrase.** Identify an unrepresentative sample followed by an overly broad universal conclusion.
4. **Why (B) is right.** Choice (B) correctly names both the narrow evidence and the unjustified expansion to all ceramic types and settings.
5. **Why the others fail.**
   - **(A)** Artistic value is not invoked in the quality assessment; it adds a different criterion.
   - **(C)** Purchase price is irrelevant to the conclusion about physical suitability; this is a financial shell game.
   - **(D)** The director infers universal failure from limited failures, not universal safety from limited successes; this reverses the mistake.
   - **(E)** No other studio's reputation or preference appears in the premises; it invents an appeal to popularity.

**Check:** Three cracked thin cups on one experimental cycle do not entail that every normal firing cycle fails.
::::
:::

:::problem[Question III.3]
The park service classifies every monitoring plot with purple loosestrife as a high-priority plot. High-priority plots must receive a visit before midsummer. Some high-priority plots contain no loosestrife because they are classified for other reasons. All plots visited by the volunteer team last week had already received their required early-season inspection. Plot 14 contains loosestrife, while Plot 22 was visited last week but its plant inventory has not been finished. No plot has been removed from the monitoring program, and the park does not require volunteers to inspect only high-priority sites.

Which one of the following must be true?

- **(A)** Plot 22 contains purple loosestrife.
- **(B)** All plots visited last week were high priority.
- **(C)** Plot 14 is required to receive a visit before midsummer.
- **(D)** Every high-priority plot contains purple loosestrife.
- **(E)** Plot 14 was visited by the volunteer team last week.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The inference follows from the rule assigning high-priority status to every loosestrife plot and requiring timely visits for those plots.
2. **Support.** Loosestrife → high priority → pre-midsummer required visit, and Plot 14 has the species.
3. **Prephrase.** Apply the rule to Plot 14 but do not infer anything about whether the visit already occurred.
4. **Why (C) is right.** Plot 14 must be high priority and therefore must receive a visit before midsummer. It is a required future action, not proof of a past visit.
5. **Why the others fail.**
   - **(A)** Plot 22's visit does not show its species inventory; this reverses an irrelevant condition.
   - **(B)** Volunteers are not restricted to high-priority sites, so visiting does not imply the classification.
   - **(D)** The passage says some high-priority plots lack loosestrife; this reverses the arrow and contradicts a stated exception.
   - **(E)** Nothing says volunteers visited Plot 14 last week; a deadline is not a record of completion.

**Check:** Loosestrife(14) → High priority(14) → Visit required before midsummer.
::::
:::

:::problem[Question III.4]
A nonprofit music school has received 60 donated violins and plans to lend them without charge to students whose families cannot afford an instrument. The director predicts that the donation will allow some students who otherwise could not participate in lessons to enroll. The instruments have not yet been inspected, and the director has not checked whether replacement strings and other essential repairs can be funded. The school already has enough teachers to take more students, and lesson fees have been waived for families that meet the program's financial criteria.

The director's argument requires assuming which one of the following?

- **(A)** At least one donated violin can be made playable and supplied to a student who otherwise lacks an instrument.
- **(B)** All 60 donated violins are in perfect condition and will never require maintenance.
- **(C)** Every student who receives a violin will become a professional musician.
- **(D)** The nonprofit's violin lessons are more effective than those at any private school.
- **(E)** Students with access to a violin will practice more hours than students who play other instruments.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Donated violins will enable at least some otherwise excluded students to take lessons.
2. **Support.** The school has instructors and waived fees, but donated objects must be usable and reach the students facing an instrument barrier.
3. **Prephrase.** Find a minimal connection between the uninspected donation and at least one newly enabled participant.
4. **Why (A) is right.** Negate (A): not one donated violin can be made playable and supplied to a student who lacks one. Then the donation cannot remove an instrument barrier for anyone, defeating the promised enrollment effect.
5. **Why the others fail.**
   - **(B)** The prediction needs only some usable violins, not universal permanent perfection; this is too strong.
   - **(C)** Professional success is not the program's stated endpoint, which is lesson participation; it substitutes a distant outcome.
   - **(D)** Comparative teaching quality does not determine whether a student can enroll with a loaned instrument.
   - **(E)** The claim is about access, not comparative practice hours across instruments; this is an irrelevant comparison.

**Check:** Negating (A) leaves zero students whose instrument barrier the donation can remove.
::::
:::

:::problem[Question III.5]
An apartment building installed adjustable exterior shading panels to reduce summer cooling costs. Electricity consumption for the building's air-conditioning system fell by 12 percent in the first hot month, exactly as engineers anticipated. Surprisingly, total building electricity consumption rose by 5 percent, even though occupancy, indoor temperature targets, and the rates charged for electricity remained unchanged. The building manager verified that no new apartments were added and that the main air-conditioning meters were functioning normally. The manager is unsure whether the panels might have changed other electricity needs.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Some residents preferred the appearance of the facade before panels were installed.
- **(B)** The shaded apartments were also cooler in the morning than in the afternoon.
- **(C)** The air-conditioning meters were replaced several years before the panel installation.
- **(D)** Residents paid the same fixed monthly building-service fee before and after installation.
- **(E)** The panels substantially reduced natural daylight, causing residents and hallways to use much more electric lighting, enough to exceed the cooling savings.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The mystery is lower air-conditioning consumption alongside higher total electricity consumption.
2. **Support.** Total use includes categories other than cooling, and shading might affect one of those categories.
3. **Prephrase.** Look for a large increase in a different component of total electricity driven by the panels.
4. **Why (E) is right.** Choice (E) gives a concrete offsetting load: added lighting exceeds the savings from lower cooling use, so both observed numbers can be true.
5. **Why the others fail.**
   - **(A)** Aesthetic dislike does not consume electricity; this is a preference-versus-energy trap.
   - **(B)** Time-of-day cooling patterns do not explain why total use rose despite cooling's recorded decline.
   - **(C)** An old meter replacement cannot account for a new discrepancy, and current meter function is verified.
   - **(D)** A fixed service fee affects residents' bills but not the physical kilowatt-hours measured; it switches units.

**Check:** Total = cooling + lighting + other use; lighting increase greater than cooling reduction yields a net rise.
::::
:::

:::problem[Question III.6]
A company announced that moving its meeting packets to tablets would reduce paper consumption by at least one-half. Six months later, paper orders were down only 10 percent. A facilities analyst argues that the tablet policy nevertheless worked for meetings because almost every meeting is now paperless. The analyst notes that the company opened a direct-mail division during the same period, greatly increasing paper used for customer letters. That division's paper use, the analyst contends, masks a substantial fall in meeting-related paper consumption. The analyst recommends measuring categories separately before judging the policy.

The statement that the company opened a direct-mail division serves primarily to...

- **(A)** state the analyst's conclusion that the tablet policy was a failure.
- **(B)** establish that paper orders actually rose during the six months.
- **(C)** identify an additional source of paper demand that could obscure the policy's effect on meetings.
- **(D)** describe a necessary condition for the tablet policy to operate.
- **(E)** prove that all paper used in the company was purchased for customer letters.

::::solution[Solution]
**Answer:** (C)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The analyst argues that small overall paper savings do not show that tablets failed to reduce meeting-paper use.
2. **Support.** The direct-mail division adds a new, independent source of consumption that may offset much larger savings in the target category.
3. **Prephrase.** Classify the statement as an alternative explanation for an aggregate number, not as the outcome claim itself.
4. **Why (C) is right.** Choice (C) fits its role: added direct-mail use can mask reduced meeting paper when only total purchasing is observed.
5. **Why the others fail.**
   - **(A)** The analyst defends the meeting policy's effect, not failure; this reverses the position.
   - **(B)** Orders were reported to decline 10 percent, so claiming a rise contradicts the stimulus.
   - **(D)** The policy could function without a mail division; the division is an interfering change, not a prerequisite.
   - **(E)** Meetings and other uses remain possible, so 'all paper' is an extreme distortion of one new source.

**Check:** Aggregate orders = meeting paper + direct-mail paper + other uses; growth in one category conceals decline in another.
::::
:::

:::problem[Question III.7]
After a public makerspace introduced electronic locks that members open with personalized cards, the number of reported missing tools dropped from 21 per quarter to 6. The makerspace director claims that the locks prevented theft by deterring unauthorized visitors. The director notes that the equipment inventory did not shrink and that the center continued to offer the same classes. Members nevertheless complained that filing an incident report through the new digital system had become cumbersome, since it required uploading photographs and identifying the last known tool location.

Which one of the following, if true, most seriously weakens the director's conclusion?

- **(A)** An independent physical inventory found that approximately the same number of tools were missing before and after the locks were installed, despite the decline in filed reports.
- **(B)** Some members occasionally forget their access cards and must ask staff to open the doors.
- **(C)** The locks record entry times for each member without showing which tools they use.
- **(D)** The makerspace offered more introductory workshops in the year before the locks were installed.
- **(E)** Replacing lost equipment is a significant expense for the makerspace.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The director infers actual theft fell because of the locks from a decline in reported incidents.
2. **Support.** Report counts fell, but the reporting process became more burdensome, potentially lowering reporting without changing losses.
3. **Prephrase.** A direct audit of missing tools contradicting the reported decline would separate true outcomes from reporting behavior.
4. **Why (A) is right.** Choice (A) shows that the underlying inventory loss did not improve, defeating the inference from fewer reports to fewer actual thefts.
5. **Why the others fail.**
   - **(B)** Forgotten cards could create inconvenience but says nothing about whether theft fell.
   - **(C)** Limited lock logs do not establish or refute the physical loss reduction; it describes measurement capability.
   - **(D)** Earlier workshop levels are temporally removed and provide no direct comparison of missing equipment.
   - **(E)** Replacement expense explains why theft matters, not whether the locks reduced it.

**Check:** If physical losses stay constant while reports fall, the reported metric is not evidence of fewer losses.
::::
:::

:::problem[Question III.8]
In Marlow County, any farm enrolled in the conservation basin registry is permitted to apply for a limited seasonal water-use license. The county's registry includes farms that have adopted specific water-retention practices, and enrollment is decided by a separate committee. Cedar Ridge Farm has installed a new irrigation sensor network and completed an approved soil survey. The farm manager therefore concludes that Cedar Ridge may apply for the seasonal license. The manager has not received confirmation of the farm's registry status, and neither the sensors nor the survey is independently described as granting eligibility.

Which one of the following, if assumed, allows the manager's conclusion to be properly drawn?

- **(A)** Every farm permitted to apply for a seasonal license has completed an approved soil survey.
- **(B)** Some farms with sensor networks are enrolled in the conservation basin registry.
- **(C)** Cedar Ridge's irrigation sensors are more efficient than those used on other county farms.
- **(D)** Every farm that has both installed a new irrigation sensor network and completed an approved soil survey is enrolled in the conservation basin registry.
- **(E)** Only farms already enrolled in the registry may install irrigation sensor networks.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The manager infers that Cedar Ridge is permitted to apply for the water-use license.
2. **Support.** The county guarantees registry enrollment → application eligibility, but the farm is known only to have sensors and a soil survey.
3. **Prephrase.** Supply a rule connecting the two confirmed achievements to registry enrollment, then apply the original rule.
4. **Why (D) is right.** Choice (D) makes sensors + survey sufficient for enrollment. Cedar Ridge meets both, so it is registered and eligible to apply.
5. **Why the others fail.**
   - **(A)** Eligibility → survey does not let us infer eligibility from survey completion; it reverses the direction.
   - **(B)** The fact that some sensor-equipped farms are registered does not establish Cedar Ridge's membership.
   - **(C)** Comparative sensor performance does not confer formal registry status; this introduces irrelevant quality.
   - **(E)** Registry status → permission to install sensors does not establish registry from having sensors; it is another reversed conditional.

**Check:** Sensors ∧ survey → registered → permitted to apply, using (D) as the first arrow.
::::
:::

:::problem[Question III.9]
A construction firm began night work near a wetland known for the calls of a rare frog. During the first two weeks, no residents submitted complaints mentioning the frogs. The firm's environmental officer therefore concluded that the construction had not disturbed the frogs and that no additional acoustic monitoring was needed. The officer knew that the wetland's nearest residences were more than a mile away and that most residents could not hear frog calls from their homes even when no construction was taking place. The officer had collected no sound recordings from within the wetland itself.

The officer's argument is most vulnerable to criticism because it...

- **(A)** presumes that construction vehicles are more expensive to operate at night than during the day.
- **(B)** concludes that no resident ever values the wetland's wildlife because no complaints were filed.
- **(C)** treats every complaint about construction as evidence that the frogs are thriving.
- **(D)** assumes that no environmental conditions other than noise can affect frog populations.
- **(E)** uses an absence of reports from people unlikely to observe the effect as evidence that the effect did not occur.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The officer concludes the frogs were undisturbed and further monitoring unnecessary.
2. **Support.** No complaints were filed, but the potential observers were too far away to hear the relevant signal.
3. **Prephrase.** Identify absence-of-evidence from a detection process incapable of reliably detecting the alleged harm.
4. **Why (E) is right.** Choice (E) states the detection flaw: silence from residents who cannot hear calls provides little evidence about wetland sound conditions.
5. **Why the others fail.**
   - **(A)** Operating expenses are not a premise, conclusion or monitoring standard; this adds an unrelated cost comparison.
   - **(B)** The officer discusses disturbance, not whether residents value frogs; this shifts the conclusion.
   - **(C)** No complaints existed, so the argument could not have used them as positive thriving evidence.
   - **(D)** Other environmental stressors may exist, but the actual inferential gap is the poor observational basis for claiming no noise disturbance.

**Check:** No complaints is informative only if residents were positioned to detect and report disturbances; here they were not.
::::
:::

:::problem[Question III.10]
An artisan bakery plans to change its flour blend because a local grain shortage makes the usual recipe too expensive. The owner wants to keep calling the product 'Heritage Rye' even though the revised loaf will contain a smaller percentage of rye flour than the previous one. A consumer advocate argues that the bakery may change its recipe, but it should display the new ingredients prominently before selling the revised loaf. The advocate does not demand that the bakery use the original recipe forever, only that customers should be able to recognize a material change before choosing what to purchase.

Which one of the following principles, if valid, most helps to justify the consumer advocate's recommendation?

- **(A)** A merchant may change a product only if every existing customer explicitly consents.
- **(B)** When a seller materially changes a characteristic that customers reasonably rely on, the seller should disclose the change before customers choose to buy.
- **(C)** Every product with a traditional name must contain ingredients identical to those used in its earliest historical version.
- **(D)** Customers should be allowed to return any food they dislike, regardless of the reasons for dissatisfaction.
- **(E)** A seller is entitled to withhold ingredient information whenever costs rise unexpectedly.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The advocate concludes that the bakery should disclose the new ingredients before customers decide whether to buy.
2. **Support.** The recipe's rye content materially changes while its old product name might lead regular purchasers to expect the old blend.
3. **Prephrase.** A rule about meaningful disclosure of relied-on product characteristics should justify the narrow remedy without banning recipe changes.
4. **Why (B) is right.** Choice (B) applies directly: the buyer-relevant rye proportion changed, so advance disclosure is warranted.
5. **Why the others fail.**
   - **(A)** Universal individual consent would prevent practical recipe changes, which the advocate explicitly allows; this is too strong.
   - **(C)** The advocate does not insist on an immutable historical recipe, only transparency about the current one.
   - **(D)** Refund rights after purchase do not address informing the choice beforehand; the timing and remedy differ.
   - **(E)** This would excuse nondisclosure because costs rose, contradicting the advocate's position.

**Check:** Material relied-on change + continued old name → disclose before purchase under (B).
::::
:::

:::problem[Question III.11]
An instructor asked students in a morning laboratory class to keep a brief sleep journal every night for two weeks. At the end of that period, the students scored higher on a concentration exercise than they had before the journal assignment. The instructor concluded that the act of recording sleep improved their concentration by encouraging more consistent habits. The class also began a unit requiring daily practice of the very concentration exercise used in the evaluation, and no comparable class was monitored without journals.

The answer to which one of the following questions would be most useful in evaluating the instructor's explanation of the higher scores?

- **(A)** Did students prefer writing journals on paper or using a phone app?
- **(B)** How many students had used journals for unrelated hobbies before this course?
- **(C)** Would students recommend the laboratory class to prospective majors?
- **(D)** Did the students' sleep journals contain complete sentences every night?
- **(E)** Did a similar class that practiced the same concentration exercise without keeping sleep journals show a comparable improvement?

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate the argument (Chapter 8)

1. **Conclusion.** The instructor claims journaling itself caused better concentration, possibly through sleep habits.
2. **Support.** Scores rose after journaling began, but practice on the identical test also began, providing an alternative cause.
3. **Prephrase.** Ask whether scores improve just as much when practice occurs without journaling; the answer should cut both ways.
4. **Why (E) is right.** If the nonjournal class improves comparably, practice explains much of the gain; if it does not, journaling becomes more credible. This is a genuine evaluate question because either outcome matters.
5. **Why the others fail.**
   - **(A)** Recording medium is a preference and does not separate journaling from practice effects.
   - **(B)** Past hobby journaling may describe familiarity but does not measure the competing cause of higher scores during the trial.
   - **(C)** Course recommendations measure satisfaction, not whether sleep records or practice raised concentration scores.
   - **(D)** Complete sentences are not the alleged mechanism; compliance could matter, but this question fails to isolate the practice confound.

**Check:** Compare practice + journal with practice alone; this directly tests the journal's incremental effect.
::::
:::

:::problem[Question III.12]
A local radio station has been criticized for devoting airtime to long interviews with public librarians rather than short entertainment segments. Its producer argues that such interviews serve the station's public purpose. She points out that an interview series about new library hours prompted residents to ask informed questions at a municipal hearing, and that the city revised a poorly advertised weekend schedule after hearing those questions. The producer does not claim that every interview produces legislative change; she argues that even occasional informed participation is a meaningful benefit of sustained local reporting.

Which one of the following most accurately describes the producer's method of reasoning?

- **(A)** She infers that audiences universally prefer long interviews because one council meeting was well attended.
- **(B)** She rejects the criticism by alleging that every critic works for a commercial rival.
- **(C)** She reasons that if a broadcast has educational value, it cannot also entertain listeners.
- **(D)** She defends a contested programming choice by describing a concrete outcome consistent with its claimed civic purpose.
- **(E)** She concludes that the city is required by law to fund all future radio interviews.

::::solution[Solution]
**Answer:** (D)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Long interviews can fulfill a community radio station's public purpose despite the airtime criticism.
2. **Support.** A specific series produced informed hearing participation and a policy reconsideration, illustrating one valuable effect.
3. **Prephrase.** Look for an example deployed as evidence for a qualified institutional-purpose claim.
4. **Why (D) is right.** Choice (D) states the argumentative structure without expanding a single success into a universal guarantee.
5. **Why the others fail.**
   - **(A)** The producer explicitly says not every interview changes policy and makes no claim about universal preferences.
   - **(B)** She answers by providing an outcome, not by attacking critics' employment or motives.
   - **(C)** The argument never treats educational and entertaining value as mutually exclusive; this invents a false dilemma.
   - **(E)** No legal duty to fund the station is claimed; the conclusion concerns public value, not appropriation.

**Check:** Example: library-hour reporting → informed questions → reconsidered schedule, used to support civic benefit.
::::
:::

:::problem[Question III.13]
Researchers often replace broken ocean buoys with newer models that can transmit measurements more frequently. But a replacement buoy may measure water temperature at a slightly different depth, and its sensor may have a different calibration bias. As a result, even accurate readings from the new device cannot automatically be compared with the old record as though no instrument change occurred. Research teams should therefore overlap old and new measurements whenever feasible and document changes in sensor placement. Longer data series are valuable only if the means of making them comparable are also recorded.

Which one of the following most accurately states the argument's main conclusion?

- **(A)** New ocean buoys should never replace older instruments under any circumstances.
- **(B)** Researchers should document sensor changes and, when feasible, overlap observations to preserve meaningful comparisons across time.
- **(C)** Every sensor replacement creates a temperature trend that is completely imaginary.
- **(D)** More frequent measurements are necessarily less accurate than infrequent ones.
- **(E)** All ocean buoys ought to be placed at the same depth in every body of water.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The normative main claim recommends documenting changes and taking overlapping readings to support comparisons.
2. **Support.** Changing a buoy can change depth or bias, undermining direct comparability even when each reading is locally accurate.
3. **Prephrase.** Find the method recommendation that follows from the measurement problem, not an absolute ban or claim about every sensor.
4. **Why (B) is right.** Choice (B) captures the explicitly proposed remedy and its reason: maintaining the interpretability of a long time series.
5. **Why the others fail.**
   - **(A)** The argument assumes replacement is often valuable and proposes safeguards, not prohibition; this is too extreme.
   - **(C)** The author describes a risk of artificial trends, not the certainty that all recorded trends are fictitious.
   - **(D)** Transmission frequency and measurement accuracy are not treated as inversely related; this invents a rule.
   - **(E)** Depth consistency across replacements matters, but a uniform worldwide depth is neither stated nor required.

**Check:** Find the 'should therefore' sentence: it states (B)'s recommended practice.
::::
:::

:::problem[Question III.14]
An apartment cooperative began sending residents weekly charts showing their electricity consumption beside the average for similar apartments. In the following quarter, metered consumption dropped 8 percent, and the cooperative chair concluded that the charts prompted residents to conserve electricity. The chair notes that average outdoor temperatures were typical for the season, but the building also replaced its hallway lighting at about the same time. The hallway lights are connected to a separate common-area meter, so the chair believes that change cannot explain lower readings from individual apartments.

Which one of the following, if true, most strengthens the chair's explanation?

- **(A)** Among otherwise comparable apartments, those randomly assigned to receive weekly charts reduced their individual consumption substantially more than those not sent charts.
- **(B)** Most residents said the new hallway lighting looked brighter than the old fixtures.
- **(C)** The cooperative could send charts more cheaply if it used a different printer.
- **(D)** Electricity is billed to residents at different dates each month.
- **(E)** A small number of residents moved into the cooperative after the quarter ended.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The chair attributes apartment-level electricity savings to the weekly comparative feedback charts.
2. **Support.** Metered usage fell after charts were introduced, but other contemporaneous changes or variation in apartments might matter.
3. **Prephrase.** Randomized chart recipients against nonrecipients with comparable apartments is an especially strong causal control.
4. **Why (A) is right.** Choice (A) isolates chart exposure under random assignment and reproduces the predicted difference in individual consumption.
5. **Why the others fail.**
   - **(B)** Lighting appearance says nothing about individual apartment metered usage; it is an aesthetic distraction.
   - **(C)** Printing cost matters to implementation economics, not to whether charts changed electricity behavior.
   - **(D)** Billing dates may change invoice timing, but the evidence concerns consumption measured by meters.
   - **(E)** Movers arriving after the measured quarter cannot produce the earlier reduction; this is a chronology mismatch.

**Check:** Random assignment + greater savings only among chart recipients supports a chart-driven effect.
::::
:::

:::problem[Question III.15]
A researcher discovers that several entries in a parliamentary archive contain mistaken dates. She concludes that the archive as a whole is an unreliable source and that no historical claim drawn from its thousands of other entries deserves confidence. She has not inspected those other entries, which were assembled by different clerks in different decades. The researcher insists that the existence of some mistakes is sufficient to dismiss the complete collection, even though the archive includes independently checked financial and attendance records.

Which one of the following arguments contains reasoning most similar in its flaw to the researcher's?

- **(A)** All instruments in this orchestra are rented. This violin is in the orchestra, so it is rented.
- **(B)** One chair from the shipment is broken. Therefore, at least one chair in the shipment is broken.
- **(C)** Several chapters in a large handbook have typographical errors. Therefore, the entire handbook is untrustworthy, including chapters checked independently for accuracy.
- **(D)** Every bicycle with a missing wheel is unusable. This bicycle has a missing wheel, so it is unusable.
- **(E)** No checked invoice contains an arithmetic error. This invoice was checked, so it contains no arithmetic error.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The researcher infers that errors in some entries discredit the whole diverse archive.
2. **Support.** A limited subset contains date mistakes, while other entries were compiled and checked independently.
3. **Prephrase.** Match the part-to-whole composition error: some flawed components → the entire collection unreliable.
4. **Why (C) is right.** Choice (C) makes the same unjustified generalization from several flawed sections to a whole body, ignoring independently verified parts.
5. **Why the others fail.**
   - **(A)** This is a valid application of a universal rule to one member, not a part-to-whole generalization.
   - **(B)** This inference merely restates that at least one broken chair exists; it draws no conclusion about all chairs.
   - **(D)** It is valid modus ponens from a stated missing-wheel condition; it does not use evidence about other bikes.
   - **(E)** It applies a universal rule to one checked invoice, which is valid if the premise holds.

**Check:** The same invalid step appears in both: some bad parts → every other part, or the whole, is unreliable.
::::
:::

:::problem[Question III.16]
Every colony in an experimental apiary that received the spring mineral supplement was examined in June. Some of the examined colonies had unusually high brood survival, and no colony with unusually high brood survival lacked a June examination. The field notebook lists Colony K as having unusually high brood survival. It also lists Colony L as receiving the supplement, although Colony L's brood survival has not been measured. The researchers have not established whether the supplement affects brood survival and cannot infer receipt of the supplement from an examination alone.

Which one of the following is most strongly supported by these facts?

- **(A)** Colony K received the spring mineral supplement.
- **(B)** Colony K received a June examination.
- **(C)** Every colony examined in June had unusually high brood survival.
- **(D)** Colony L had unusually high brood survival.
- **(E)** The mineral supplement caused the high brood survival observed in Colony K.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The best inference concerns whether the known high-survival colony met an examination requirement.
2. **Support.** No high-survival colony lacked a June examination; K had high brood survival.
3. **Prephrase.** Rewrite the quantified statement as high survival → examined, without inferring anything about supplement use.
4. **Why (B) is right.** Colony K's high brood survival puts it in the group all of whose members were examined in June.
5. **Why the others fail.**
   - **(A)** Supplement receipt implies examination, not the reverse; K's examination cannot prove supplement receipt.
   - **(C)** The rule says all high-survival colonies were examined, not all examined colonies had high survival; this reverses the arrow.
   - **(D)** L received supplement and thus examination, but no conclusion about survival follows; it adds a causal claim.
   - **(E)** The passage explicitly says the effect has not been established and does not link K to supplementation.

**Check:** High brood survival(K) → June examination(K).
::::
:::

:::problem[Question III.17]
After the town resurfaced its central sidewalk, the number of injuries recorded by a nearby urgent-care clinic fell from 30 to 18 over six months. A council member concludes that the resurfacing prevented twelve injuries and wants to apply the same technique townwide. The clinic's statistics, however, include all walk-in injuries, including sports injuries and accidents occurring indoors. During the comparison period, a large recreation center adjacent to the clinic closed for renovations, reducing the number of sports injuries treated there.

The council member's argument is most vulnerable to criticism because it...

- **(A)** concludes that the resurfacing improved the visual appearance of every sidewalk.
- **(B)** assumes that all injuries treated at the clinic occurred outside the town.
- **(C)** fails to establish whether residents prefer smooth sidewalks to uneven ones.
- **(D)** mistakes the difference between two clinics for a change at one clinic.
- **(E)** attributes a change in a broad injury total to sidewalk work despite a simultaneous change affecting injuries unrelated to sidewalks.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The council member assigns all twelve fewer recorded injuries to the sidewalk project.
2. **Support.** The clinic's aggregated counts cover many causes, and closure of a recreation center may independently reduce sports injuries.
3. **Prephrase.** Expose the mismatch between outcome measure and intervention plus an alternative contemporaneous cause.
4. **Why (E) is right.** Choice (E) identifies precisely why the drop cannot be assigned to the sidewalk: the count includes unrelated injury categories changed by another event.
5. **Why the others fail.**
   - **(A)** Aesthetic improvement is never claimed and has no role in the injury evidence.
   - **(B)** The argument does not locate every injury outside the town; this is an invented geographic premise.
   - **(C)** Residents' preferences are unrelated to observed accident causation; it swaps safety evidence for opinions.
   - **(D)** The evidence is one clinic across time, not two clinics at once; this misidentifies the comparison.

**Check:** Total clinic injuries ≠ sidewalk injuries; sports-center closure explains part of the total decline.
::::
:::

:::problem[Question III.18]
Nora: The community center should reserve its open rooftop for vegetable beds rather than solar panels. The center has very little garden space, and volunteers have offered to maintain the beds. Solar panels would save electricity, but the food and outdoor learning opportunities are more valuable here. Elias: The volunteers' offer is generous, and garden space is scarce. But rooftop beds would require costly structural reinforcement. We should install solar panels on the roof and use the center's ground-level courtyard for a smaller garden. The center must keep its long-term operating costs manageable.

Nora and Elias disagree over whether...

- **(A)** the community center should prioritize vegetable beds over solar panels for its open rooftop.
- **(B)** the center currently has more garden space than its community needs.
- **(C)** volunteers have offered to help maintain vegetable beds.
- **(D)** solar panels can reduce the center's electricity expenses.
- **(E)** the center should consider long-term operating costs when planning projects.

::::solution[Solution]
**Answer:** (A)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** The speakers advocate opposite uses of the same rooftop, although they share several premises.
2. **Support.** Nora directly favors rooftop vegetable beds over panels; Elias directly favors panels instead of rooftop beds.
3. **Prephrase.** Find a proposition on which both take explicit, opposing positions rather than one both concede.
4. **Why (A) is right.** Choice (A) receives an unequivocal yes from Nora and no from Elias on the identical allocation decision.
5. **Why the others fail.**
   - **(B)** Both regard garden space as scarce; the claim that current space exceeds need is contradicted, not disputed.
   - **(C)** Both recognize volunteers' willingness to maintain beds, so this is agreement.
   - **(D)** Nora concedes electricity savings from panels and Elias favors them partly for cost control; this is not the disputed point.
   - **(E)** Elias emphasizes costs, but Nora never argues they should be ignored. A difference in emphasis is not explicit disagreement.

**Check:** Nora = rooftop beds first; Elias = rooftop panels first. They disagree directly on (A).
::::
:::

:::problem[Question III.19]
A manufacturing plant plans to pay part of the childcare fees for employees whose children are under school age. The human resources manager predicts that the subsidy will eliminate childcare-related absences among participating employees, because each approved worker will now be able to afford a place at one of the town's licensed daycare centers. The manager has verified the subsidy amounts and the centers' published fees. Fourteen employees currently miss shifts because they cannot secure affordable care. However, the manager has not asked how many spaces are available for new children or whether any center keeps a waiting list.

The manager's argument depends on assuming which one of the following?

- **(A)** Every eligible employee will choose the same daycare center.
- **(B)** No employee has ever missed work for a reason unrelated to childcare.
- **(C)** At least some participating employees will be able to obtain an actual childcare place, not merely afford its listed price.
- **(D)** All daycare centers in the town offer identical hours and teaching methods.
- **(E)** The plant's childcare subsidy is larger than every comparable benefit offered by nearby employers.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The subsidy is supposed to eliminate childcare-related absences through access to daycare places.
2. **Support.** Affordability is checked, but a payable price cannot secure attendance if centers have zero openings.
3. **Prephrase.** A minimal necessary availability condition is that at least one participating employee can actually obtain a place.
4. **Why (C) is right.** Negate (C): no participating employee can obtain any place. Then subsidized fees provide no actual daycare access, eliminating the mechanism the manager says will prevent absences.
5. **Why the others fail.**
   - **(A)** Employees need not use one common center; the forecast can work across multiple providers.
   - **(B)** The claim is expressly limited to childcare absences, so unrelated reasons for missing work can remain.
   - **(D)** Centers may differ while still meeting participating families' needs; identical methods are unnecessary.
   - **(E)** Competitors' benefits do not determine whether affordable, available care eliminates these workers' absences.

**Check:** Negate (C): zero obtainable places; paying part of a fee cannot secure the proposed care.
::::
:::

:::problem[Question III.20]
Every rare book insured under the archive's premium policy has been professionally catalogued. No book that has been professionally catalogued lacks a dated photograph in the archive's files. Therefore, every rare book insured under the premium policy has a dated photograph on file. This conclusion does not claim that every catalogued book is insured or that a photograph alone is sufficient to obtain insurance; it follows solely from two rules applying to all insured books.

Which one of the following arguments has reasoning most similar to that in the argument above?

- **(A)** All certified divers have passed a swim test. Mira passed a swim test, so Mira is a certified diver.
- **(B)** Some registered attendees received badges. Everyone with a badge entered the hall, so all registered attendees entered the hall.
- **(C)** All city buses have route maps. Every bus with a route map has seats, so every vehicle with seats is a city bus.
- **(D)** Every sealed sample has been entered into the laboratory log. Every sample entered in the log has a tracking number. Thus, every sealed sample has a tracking number.
- **(E)** No recycled bottle contains lead. This bottle contains lead, so it might be made from recycled glass.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The argument derives insured → dated photograph through two universal links.
2. **Support.** Insured → catalogued, and catalogued → photograph; composing the rules yields insured → photograph.
3. **Prephrase.** Find an all-to-all chain in the same direction, not the converse, an existential jump or a merely possible outcome.
4. **Why (D) is right.** Sealed → laboratory log → tracking number, so sealed → tracking number. Choice (D) matches the valid transitive form.
5. **Why the others fail.**
   - **(A)** It affirms the consequent: having passed a swim test is necessary for certification but not sufficient.
   - **(B)** It generalizes from some badge recipients to all attendees; this changes an existential premise into a universal conclusion.
   - **(C)** It reverses the correct conclusion buses → seats into seats → buses; this is a converse error.
   - **(E)** If recycled → no lead, then lead → not recycled; (E) points against the required contrapositive conclusion.

**Check:** Both have A → B, B → C, therefore A → C.
::::
:::

:::problem[Question III.21]
A workforce center surveyed former students who had completed its weekend programming workshops and compared them with adults in the same town who had not enrolled. Workshop graduates were substantially more likely to have received a technology-sector job offer within six months. The center concluded that the workshops improved employment prospects by teaching marketable skills. It plans to spend most of next year's training budget on identical courses. The survey did not ask whether participants already had technical qualifications or were actively applying for technology jobs before enrolling.

Which one of the following, if true, most seriously weakens the center's explanation?

- **(A)** Some workshop instructors work full time in the technology industry.
- **(B)** The center issues certificates to students who finish every workshop exercise.
- **(C)** Most enrollees already held relevant technical credentials and had pending technology job applications before joining, unlike most surveyed nonparticipants.
- **(D)** Several enrollees reported enjoying collaboration with classmates.
- **(E)** The workshops covered more than one programming language.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The center asserts workshops caused graduates' greater job-offer rate and will replicate the courses.
2. **Support.** The surveyed groups differ in enrollment status and job offers, but prior credentials and applications were not controlled.
3. **Prephrase.** Look for self-selection into training by people already likely to receive offers.
4. **Why (C) is right.** Choice (C) gives a direct alternative account of the difference: workshop enrollees were further along the job-search path before training.
5. **Why the others fail.**
   - **(A)** Industry employment may enhance instruction but does not establish the workshops caused the observed difference.
   - **(B)** Certificates document completion, not the reason employers offered jobs; this is a credential-versus-causation trap.
   - **(D)** Enjoyment is a positive experience but does not explain or refute employment outcomes.
   - **(E)** Curriculum breadth says little about whether an unmeasured prior qualification caused the offer gap.

**Check:** Preexisting credentials + pending applications → both enrollment and offers, weakening workshop-as-cause.
::::
:::

:::problem[Question III.22]
A city must choose between two vendors for replacement valves in its drinking-water network. Vendor North offers valves that are slightly cheaper initially but uses a proprietary fitting available only from its own warehouse, which is sometimes closed during emergencies. Vendor South's valves cost more but accept a commonly stocked fitting and can be repaired by city crews. A maintenance supervisor recommends Vendor South, arguing that the city's first obligation is to restore service quickly during a major failure, even if it must spend somewhat more at purchase.

Which one of the following principles, if valid, most strongly supports the supervisor's recommendation?

- **(A)** Public purchases should always minimize initial cost, regardless of the consequences for repairs.
- **(B)** When failure of public infrastructure would seriously disrupt essential service, procurement should give substantial weight to repairability and rapid access to parts even at a moderate initial premium.
- **(C)** Any product offered by a private vendor should be rejected in favor of goods manufactured by the city.
- **(D)** Officials should choose whichever supplier has the largest number of employees.
- **(E)** Long-term repair needs matter only after a product has already failed for the first time.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The supervisor chooses the more repairable, slightly costlier valve to protect essential service continuity.
2. **Support.** Vendor South supports accessible parts and immediate in-house repairs, while North's fitting may be unavailable during emergencies.
3. **Prephrase.** A public-service principle prioritizing emergency resilience over moderate initial savings will bridge these facts to the choice.
4. **Why (B) is right.** Choice (B) directly states that priority, while limiting it to serious disruption and moderate premiums rather than all purchases.
5. **Why the others fail.**
   - **(A)** This endorses the cheaper initial option, conflicting with the supervisor's reasoning.
   - **(C)** Both candidates are outside vendors, and municipal manufacture is not proposed; it adds a new exclusion rule.
   - **(D)** Workforce size is never linked to parts availability or repair speed; this is an irrelevant supplier comparison.
   - **(E)** The risk of emergency delay is the reason to plan parts access beforehand; postponing consideration reverses the argument.

**Check:** Essential service + risk of unavailable proprietary part → prefer accessible, repairable option under (B).
::::
:::

:::problem[Question III.23]
Under the festival's screening agreement, an unedited documentary may be shown publicly only if a valid release is on file for every interview that appears in the final cut. A festival organizer plans to screen a film about local craftspeople without removing any footage. The organizer has obtained releases from the six principal interviewees and has confirmation from the filmmaker that the soundtrack is original. Because the featured subjects have signed, the organizer concludes that the film can be shown in its current form. The organizer has not reviewed the brief street interviews included near the end.

The organizer's argument depends on assuming which one of the following?

- **(A)** The festival will attract more viewers than any previous public showing of the film.
- **(B)** Every principal interviewee will attend the screening in person.
- **(C)** The original soundtrack was composed before the principal interviews were filmed.
- **(D)** No interview appearing in the final cut lacks the valid release required by the screening agreement.
- **(E)** All footage removed from earlier edits of the documentary featured a principal interviewee.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The film in its current, unedited form is authorized for the festival screening.
2. **Support.** The six principal interviewees have releases, but the contract requires releases for every interview, including brief ones.
3. **Prephrase.** The necessary missing fact is coverage of the remaining interviews, not merely the prominent interviews or the music.
4. **Why (D) is right.** Negating (D) yields at least one interview in the final cut with no valid release, which violates an express condition for showing the unedited film.
5. **Why the others fail.**
   - **(A)** Audience size has no connection to contractual permission; it is a popularity trap.
   - **(B)** Release validity is unrelated to personal attendance at the event; this confuses permission with participation.
   - **(C)** Soundtrack chronology does not determine whether interview releases cover the whole cut.
   - **(E)** Footage no longer in the final cut is not relevant to releases required for material that will be shown.

**Check:** Agreement: unedited screening → releases for every final-cut interview; one missing release defeats the plan.
::::
:::

:::problem[Question III.24]
A growers' cooperative shipped 30 percent more cartons of berries this season than last season but spent 20 percent fewer staff-hours manually inspecting fruit before packing. Customers reported nearly the same low rate of damaged or spoiled berries as in prior seasons. The cooperative did not hire more experienced inspectors or relax its written quality standards. Its directors had feared that a larger harvest would require more inspection labor or cause more defects to reach buyers, so the figures surprised them.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The cooperative sold berries to several new grocery chains this year.
- **(B)** Berry cartons were printed with a redesigned cooperative logo.
- **(C)** Some varieties harvested this year were sweeter than those harvested last year.
- **(D)** The cooperative used the same number of refrigerated trucks to deliver shipments in both seasons.
- **(E)** A newly installed optical sorter removed most damaged fruit before manual inspection and grouped the remaining berries into more uniform batches.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The puzzle combines more cartons, fewer inspection hours and unchanged low defect rates.
2. **Support.** The written standard remained, so a change in sorting or inspection workload must explain why the inspectors could do less with at least as good a result.
3. **Prephrase.** An upstream screening stage that removes defects and makes inspection easier would reconcile all three observations.
4. **Why (E) is right.** Choice (E) explains productivity: the sorter preselects clean, consistent batches, lowering manual labor without allowing more bad fruit through.
5. **Why the others fail.**
   - **(A)** New buyers could explain demand, but not improved quality-control efficiency.
   - **(B)** Logo design affects packaging appearance rather than the amount of defective produce reaching inspectors.
   - **(C)** Sweetness is not described as damaged or spoiled quality and does not directly reduce manual checks.
   - **(D)** Truck count concerns delivery capacity, not prepacking inspection time; it shifts to another stage of the process.

**Check:** Automated presort + fewer manual exceptions = lower inspection labor despite higher clean output.
::::
:::

:::problem[Question III.25]
A city ordinance requires that every newly commissioned public sculpture be 'accessible,' which the ordinance defines as viewable without paying an admission charge during posted visiting hours. A cultural affairs officer approves a proposed bronze sculpture for a privately operated rooftop courtyard because the developer has promised to install an elevator wide enough for wheelchairs and a gently sloped entrance ramp. The officer acknowledges that the courtyard charges all visitors an admission fee but argues that the improvements make the sculpture accessible and therefore satisfy the ordinance's requirement.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** uses 'accessible' in the sense of physically reachable to establish compliance with a rule defining it in terms of admission-free viewing.
- **(B)** assumes that no city resident uses a wheelchair when visiting rooftop courtyards.
- **(C)** concludes that an elevator is always less expensive to maintain than a staircase.
- **(D)** treats a private courtyard as though it necessarily receives government funding.
- **(E)** mistakes a requirement for posted hours for a requirement to keep the courtyard open all night.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The officer claims the proposed sculpture complies with the ordinance's accessibility standard.
2. **Support.** An elevator and ramp create physical reachability, but the ordinance defines the relevant standard by free admission during hours.
3. **Prephrase.** Look for equivocation: the same term carries a different meaning in the stated rule and in the offered proof.
4. **Why (A) is right.** Choice (A) captures the shift from no-fee viewing to wheelchair-accessible entry; a paid courtyard fails the defined criterion despite its good physical access.
5. **Why the others fail.**
   - **(B)** The officer is planning wheelchair access, not assuming wheelchair users do not exist; this reverses the premise.
   - **(C)** No maintenance-cost comparison appears; this invents a financial issue.
   - **(D)** Whether the project gets public funding is not used to satisfy the ordinance; the officer relies solely on physical accessibility.
   - **(E)** Posted hours are mentioned in the definition, but the officer never infers a twenty-four-hour opening duty.

**Check:** Ordinance-accessible = viewable without fee; ramp-accessible = physically reachable. The two meanings are not interchangeable.
::::
:::

## 28.4 Scoring and review

Count **one point per correct answer**. Your raw score is the number correct out of **77**. This original practice test was not psychometrically equated, so **do not convert it to an LSAC 120–180 score**; compare raw accuracy, pacing and blind-review changes instead.

Open the key only after your timed attempt and blind review.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| I.1 | (C) | Weaken | 8 |
| I.2 | (A) | Main conclusion | 4 |
| I.3 | (E) | Flaw | 9 |
| I.4 | (B) | Necessary assumption | 7 |
| I.5 | (D) | Strengthen | 8 |
| I.6 | (B) | Must be true / inference | 10 |
| I.7 | (E) | Paradox / resolve | 13 |
| I.8 | (C) | Sufficient assumption | 7 |
| I.9 | (A) | Flaw | 9 |
| I.10 | (D) | Role of a statement | 11 |
| I.11 | (A) | Weaken | 8 |
| I.12 | (C) | Method of reasoning | 11 |
| I.13 | (D) | Necessary assumption | 7 |
| I.14 | (E) | Parallel reasoning | 12 |
| I.15 | (B) | Principle | 13 |
| I.16 | (C) | Strengthen | 8 |
| I.17 | (A) | Flaw | 9 |
| I.18 | (B) | Point at issue | 11 |
| I.19 | (D) | Most strongly supported | 10 |
| I.20 | (E) | Sufficient assumption | 7 |
| I.21 | (E) | Flaw | 9 |
| I.22 | (D) | Necessary assumption | 7 |
| I.23 | (B) | Parallel flaw | 12 |
| I.24 | (C) | Strengthen | 8 |
| I.25 | (A) | Paradox / resolve | 13 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| II.1 | (B) | Main point | 18 |
| II.2 | (D) | Detail | 18 |
| II.3 | (A) | Function of a part | 18 |
| II.4 | (E) | Inference | 18 |
| II.5 | (C) | Author's attitude | 18 |
| II.6 | (A) | Application | 18 |
| II.7 | (C) | Structure / organization | 18 |
| II.8 | (D) | Main point | 18 |
| II.9 | (B) | Detail | 18 |
| II.10 | (E) | Inference | 18 |
| II.11 | (B) | Function of a part | 18 |
| II.12 | (E) | Strengthen / weaken a passage claim | 18 |
| II.13 | (C) | Author's attitude | 18 |
| II.14 | (A) | Application / analogy | 18 |
| II.15 | (D) | Comparative reading: central disagreement | 17 |
| II.16 | (C) | Comparative reading: point of agreement | 17 |
| II.17 | (B) | Comparative reading: author response | 17 |
| II.18 | (A) | Detail | 18 |
| II.19 | (E) | Function of a part | 18 |
| II.20 | (D) | Comparative reading: author response | 17 |
| II.21 | (A) | Main point | 18 |
| II.22 | (D) | Detail | 18 |
| II.23 | (B) | Inference | 18 |
| II.24 | (C) | Function of a part | 18 |
| II.25 | (E) | Most strongly supported | 18 |
| II.26 | (B) | Application / analogy | 18 |
| II.27 | (C) | Primary purpose | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| III.1 | (D) | Strengthen | 8 |
| III.2 | (B) | Flaw | 9 |
| III.3 | (C) | Must be true / inference | 10 |
| III.4 | (A) | Necessary assumption | 7 |
| III.5 | (E) | Paradox / resolve | 13 |
| III.6 | (C) | Role of a statement | 11 |
| III.7 | (A) | Weaken | 8 |
| III.8 | (D) | Sufficient assumption | 7 |
| III.9 | (E) | Flaw | 9 |
| III.10 | (B) | Principle | 13 |
| III.11 | (E) | Evaluate the argument | 8 |
| III.12 | (D) | Method of reasoning | 11 |
| III.13 | (B) | Main conclusion | 4 |
| III.14 | (A) | Strengthen | 8 |
| III.15 | (C) | Parallel flaw | 12 |
| III.16 | (B) | Most strongly supported | 10 |
| III.17 | (E) | Flaw | 9 |
| III.18 | (A) | Point at issue | 11 |
| III.19 | (C) | Necessary assumption | 7 |
| III.20 | (D) | Parallel reasoning | 12 |
| III.21 | (C) | Weaken | 8 |
| III.22 | (B) | Principle | 13 |
| III.23 | (D) | Necessary assumption | 7 |
| III.24 | (E) | Paradox / resolve | 13 |
| III.25 | (A) | Flaw | 9 |

:::

**Where to review**

| Question family | Textbook chapters |
| --- | --- |
| Conclusions, support and gaps | 4 |
| Formal logic and conditional inferences | 5, 10 |
| Flaw recognition | 6, 9 |
| Necessary and sufficient assumptions | 7 |
| Strengthen and weaken | 8 |
| Main conclusion, role, method, point at issue | 4, 11 |
| Parallel reasoning and parallel flaw | 12 |
| Paradox and principle | 13 |
| Reading for structure, main point and tone | 15, 18 |
| Comparative reading | 17 |
| RC detail, inference, function and application | 18 |
| Timed pacing and blind review | 14, 19, 22 |

For review, first explain why the credited answer is supported, then explain **why each specific wrong answer fails**. A question you answered correctly by luck belongs in the error log just as a miss does.
