---
title: "Practice Test 10"
source: "markdown"
---

Part VI · Chapter 37

# Practice Test 10

An original, technology-and-law-centered full-length LSAT scored-core practice test.

## Overview

Take the three sections in one sitting, allowing **35 minutes for each section** and a **10-minute break after Section II**. This practice test includes the three scored types of section, two Logical Reasoning and one Reading Comprehension; the official LSAT also has an additional unscored 35-minute section. Do not open any solution before finishing all three sections.

**Flag, don’t guess silently.** Record every question you are uncertain about, even when you select an answer. After the timed sitting, do an **untimed blind review of flagged questions** without checking answers (Chapter 22), then reveal the answer key, examine every miss, and log its reason (Chapter 23). An accidentally correct guess can conceal a reasoning weakness. Use Chapter 24 for realistic practice-test stamina and strategy.

This is an **original textbook practice test**, not an official LSAC PrepTest. For an official timed benchmark and score interpretation, LSAC’s LawHub PrepTests remain the gold standard. This chapter provides **77 scored-practice questions** and no experimental section; its raw score is not an official 120–180 scaled score.


## 37.1 Section I: Logical Reasoning

:::problem[Question I.1]
A board member wants the company to sign a five-year exclusive contract with its cheapest chip supplier. The procurement director objects that the quoted unit price omits the expected losses from interrupted shipments. Two smaller suppliers have independently maintained deliveries during disruptions that affected the large supplier. Although buying from both would raise ordinary purchasing costs, the director says those costs may be justified by reducing the risk of having no usable chips at all. The board should therefore compare contracts by expected total cost, not unit price alone.

Which one of the following most accurately expresses the main conclusion of the procurement director’s argument?

- **(A)** The two smaller suppliers must receive equal portions of all future orders.
- **(B)** Interrupted shipments have already made the exclusive contract more expensive than the alternatives.
- **(C)** The board should compare contracts by expected total cost, not unit price alone.
- **(D)** The large supplier is incapable of delivering chips reliably.
- **(E)** Independent suppliers are always preferable to exclusive contracts.

::::solution[Solution]
**Answer:** (C)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The director recommends a method for evaluating competing procurement contracts.
2. **Support.** Price, interruption exposure, and higher regular costs are competing considerations in that recommendation.
3. **Prephrase.** Look for the normative recommendation, not a piece of evidence about supplier performance.
4. **Why (C) is right.** The last sentence states the director’s proposed decision rule and integrates both ordinary cost and interruption risk.
5. **Why the others fail.**
   - **(A)** Unwarranted prescription: diversification does not specify equal allocations.
   - **(B)** Temporal overreach: the argument compares expected future risk, not a proven past total.
   - **(D)** Too strong: a past disruption does not establish permanent inability.
   - **(E)** Universal rule: the director makes a context-dependent comparison.

**Check:** The proposed rule is explicitly stated; none of the alternatives captures its scope.
::::
:::

:::problem[Question I.2]
At a research institute, every laboratory that moved security updates to an overnight automatic-installation window reported fewer successful phishing-related intrusions during the following quarter. The technology chief credits the installation schedule: patches applied before employees arrive leave attackers less opportunity to exploit old weaknesses. She therefore proposes extending overnight installation to all departments as the principal way to reduce phishing intrusions. The institute also changed several other security procedures during the same quarter, but the chief considers those changes secondary.

Which one of the following, if true, most seriously weakens the technology chief’s argument?

- **(A)** Hardware keys introduced concurrently prevented most password-based intrusions.
- **(B)** Some employees dislike restarting their machines in the morning.
- **(C)** Most laboratories had installed at least some security updates before adopting the overnight window.
- **(D)** Other departments operate their machines on schedules unlike the laboratories’ schedules.
- **(E)** The number of phishing emails received by the laboratories increased during the quarter.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The overnight patch schedule caused the decrease and should be the principal intervention.
2. **Support.** A before-and-after correlation leaves room for contemporaneous security changes.
3. **Prephrase.** Seek a competing change that plausibly explains the specific outcome instead of the patch schedule.
4. **Why (A) is right.** Hardware keys directly block password-based compromise, supplying a better cause for the recorded reduction.
5. **Why the others fail.**
   - **(B)** Preference diversion: inconvenience does not explain the reduced intrusions.
   - **(C)** Half-right background: prior patching does not account for the observed quarterly change.
   - **(D)** Limited transferability: this may affect expansion, but not the causal attribution within laboratories as directly.
   - **(E)** Wrong direction: more attempted attacks alongside fewer successes does not undermine the security improvement.

**Check:** With password theft as the route of attack, changed authentication rather than patch timing explains the effect.
::::
:::

:::problem[Question I.3]
A fictional regulator follows three rules for a technology-export application. Every application receives an initial technical review, while applications approved for expedited handling receive that review on a faster schedule. No application that fails the initial review may be granted a final export authorization. Some applications that pass the initial review must still undergo a national-security review, and passing the technical review alone does not assure authorization. One application, filed by Larton Devices, has been granted final authorization. The public file does not say whether Larton requested expedited handling or whether a national-security review was required.

Which one of the following must be true?

- **(A)** Larton Devices requested expedited handling.
- **(B)** Larton Devices was exempt from national-security review.
- **(C)** All applications receiving initial technical review eventually receive final authorization.
- **(D)** Larton Devices completed its initial technical review in less time than any rejected applicant.
- **(E)** Larton’s application did not fail its initial technical review.

::::solution[Solution]
**Answer:** (E)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The question seeks a necessary implication of the grant of final authorization.
2. **Support.** Failure of the initial technical review rules out final authorization.
3. **Prephrase.** Take the contrapositive: authorization means the applicant did not fail.
4. **Why (E) is right.** If failed review implies no authorization, then authorization implies no failed review.
5. **Why the others fail.**
   - **(A)** Converse trap: final authorization gives no information about whether expedited handling was requested.
   - **(B)** Missing information: some passing applications face that review, but Larton’s status is undisclosed.
   - **(C)** Reversal: the stated rule blocks failures, not guarantees successes.
   - **(D)** Unsupported comparison: no processing times are provided.

**Check:** Failure -> no authorization; authorization -> not failure.
::::
:::

:::problem[Question I.4]
A university’s technology office compared patents issued to two research groups. The patents from Group X were cited in later patent filings more frequently than those from Group Y. The office’s director therefore concluded that Group X must have produced more technically valuable inventions. The director did not distinguish citations by patent examiners from citations supplied by applicants, and some later filings referenced many earlier patents to describe crowded technical fields rather than because those patents were useful in developing a new product.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** mistakes a condition sufficient for receiving a patent for a condition necessary for receiving one.
- **(B)** treats patent-citation frequency as a reliable measure of technical value.
- **(C)** rejects Group Y’s inventions because the group has fewer researchers.
- **(D)** assumes that all patent citations are added by patent examiners.
- **(E)** concludes that none of Group Y’s patents has any technical value.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director equates citation frequency with greater technical value.
2. **Support.** Citation counts may reflect examination practice or crowded fields rather than invention quality.
3. **Prephrase.** Identify the proxy-to-target leap, not a claim the director never made.
4. **Why (B) is right.** The answer names the untested assumption linking the observed metric to the desired quality measure.
5. **Why the others fail.**
   - **(A)** Wrong flaw family: the argument states no conditional requirement for patent issuance.
   - **(C)** Invented premise: group size does not appear in the argument.
   - **(D)** Too specific: the problem is inference from counts to value, even when the source of citations is mixed.
   - **(E)** Overstated conclusion: the director compares groups rather than claiming zero value.

**Check:** Many citations could be generated without the asserted greater value.
::::
:::

:::problem[Question I.5]
A robotics company is deciding whether to buy a batch of inexpensive motor controllers. Their supplier’s bench tests show that individual controllers rarely fail under a constant load. The company’s engineer warns that its robots repeatedly start and stop, producing current spikes absent from those tests. She recommends commissioning a smaller pilot in actual robots before purchasing the entire batch. The procurement manager replies that a pilot would delay orders and that the impressive bench results should be enough to settle the question.

Which one of the following, if true, most strengthens the engineer’s recommendation?

- **(A)** The pilot would cost substantially less than purchasing the entire batch.
- **(B)** The supplier has delivered every previous shipment on time.
- **(C)** The robots use controllers whose labels identify their serial numbers.
- **(D)** Prior controllers passed constant-load tests yet failed under repeated start-stop operation.
- **(E)** Most competitors buy at least some controllers from this supplier.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer says a realistic pilot is needed before full purchase.
2. **Support.** The bench environment omits cycling and spikes present in the company’s use.
3. **Prephrase.** Find evidence that success in the bench setting fails to predict success in the actual operating setting.
4. **Why (D) is right.** The historical mismatch establishes that the omitted duty cycle has mattered in closely related cases.
5. **Why the others fail.**
   - **(A)** Cost alone does not show the proposed test addresses the suspected reliability gap.
   - **(B)** Wrong dimension: delivery reliability differs from electrical performance under load changes.
   - **(C)** Irrelevant detail: traceability does not predict whether bench tests transfer.
   - **(E)** Popularity trap: competitors’ purchasing choices do not validate performance in these robots.

**Check:** Past bench passes plus field failures support testing the missing condition.
::::
:::

:::problem[Question I.6]
A software manufacturer plans to release a firmware package only after an automated license scanner reports no third-party notices missing from its inventory. The general counsel argues that the scanner’s clean report is a reliable reason to believe the package meets the company’s disclosure obligations, because the scanner cross-checks inventoried components against the notices shipped with the release. The counsel does not claim that the scanner detects every possible legal issue; the claim concerns disclosure obligations for software actually included in the release.

The general counsel’s argument depends on assuming which one of the following?

- **(A)** Every disclosure obligation of every component is identical.
- **(B)** The component inventory includes every included component requiring a notice.
- **(C)** No person ever changes firmware after the scanner runs.
- **(D)** Automated scanners are more accurate than lawyers in every licensing task.
- **(E)** The package contains only components written by the manufacturer.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The clean scanner report supports compliance with included components’ notice requirements.
2. **Support.** A scan of an inventory can only check items listed in that inventory.
3. **Prephrase.** Negate the completeness of the relevant inventory and see whether a clean result still warrants compliance.
4. **Why (B) is right.** If an included notice-bearing component is absent from the inventory, the scanner could miss its obligation despite a clean report.
5. **Why the others fail.**
   - **(A)** Too strong: the scanner could compare different notices for different licenses.
   - **(C)** Excessive generalization: future modifications are irrelevant to this particular release report.
   - **(D)** Wrong comparison: the argument makes no claim about relative professional performance.
   - **(E)** Contradicts the point of checking third-party notices; the conclusion does not require this.

**Check:** Negating completeness permits a clean report with an undisclosed required notice.
::::
:::

:::problem[Question I.7]
A fictional camera maker switched to a lower-cost image-sensor supplier. In the first six months after the switch, the number of cameras sold rose sharply, yet the number returned because of sensor faults fell. The maker did not change its return policy or repair classification, and the cameras continued to use the same imaging architecture. An analyst finds the results puzzling because more units in circulation would ordinarily provide more opportunities for sensor failures, especially after a change to a cheaper supplier.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The new sensors cost less per unit than the previous sensors.
- **(B)** Many customers purchase cameras primarily for their color options.
- **(C)** The camera maker advertised the new models more intensively.
- **(D)** The new supplier screens every sensor for faults before shipment, unlike the previous supplier.
- **(E)** The repair department employs more technicians than it did before the switch.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The puzzle is higher sales volume coupled with fewer sensor-fault returns.
2. **Support.** A cheap new supplier seems unlikely to produce a lower absolute defect count during greater unit sales.
3. **Prephrase.** Find a quality-control difference capable of lowering the failure rate enough to outweigh volume.
4. **Why (D) is right.** More comprehensive supplier screening can sharply reduce faulty sensors entering sold products.
5. **Why the others fail.**
   - **(A)** Restates the low-price background without explaining fewer failed units.
   - **(B)** Demand explanation only: may explain sales but not reduced sensor-fault returns.
   - **(C)** Sales-side half answer: marketing does not account for reduced failures.
   - **(E)** Wrong outcome: technician staffing need not alter actual returns under unchanged classifications.

**Check:** Absolute returns can fall when faults per sold unit fall by more than sales rise.
::::
:::

:::problem[Question I.8]
A fictional hospital consortium considers a rule requiring every small medical-device supplier to deposit its encryption keys with a central administrator. Officials say centralized recovery would help during emergencies. An engineer objects that a compromise of the administrator would expose many otherwise separate devices. She proposes requiring a supplier to demonstrate emergency access procedures instead, unless the benefits of central storage clearly outweigh the added shared risk. The consortium wants a general principle for deciding between the proposals, not a prediction about any specific attack.

Which one of the following principles most strongly supports the engineer’s approach?

- **(A)** Any security measure that creates any new risk must be prohibited.
- **(B)** Every supplier should be free to ignore the consortium’s emergency-access needs.
- **(C)** A central safeguard should not be mandatory when safer alternatives provide the same needed function.
- **(D)** A method already used by most hospitals should be preferred.
- **(E)** Recoverability of keys should always take precedence over confidentiality.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The engineer prefers distributed emergency access unless centralization clearly wins the tradeoff.
2. **Support.** Central storage creates a common point of exposure; alternatives may serve recovery needs.
3. **Prephrase.** Seek a proportionality principle matching function and risk, not an unconditional prohibition.
4. **Why (C) is right.** The rule compares the same functional goal with systemic risk, justifying the alternative where centralization adds unnecessary exposure.
5. **Why the others fail.**
   - **(A)** Too absolute: the engineer tolerates tradeoffs when benefits clearly outweigh risk.
   - **(B)** Ignores the requirement to demonstrate an emergency-access procedure.
   - **(D)** Popularity cannot weigh the concentration of security risk.
   - **(E)** Opposite priority: the engineer resists recovery at any security cost.

**Check:** The alternative is allowed because it supplies emergency access without matching concentration.
::::
:::

:::problem[Question I.9]
A hardware plant surveyed the employees attending an optional evening workshop on predictive maintenance. Nearly all respondents said they would gladly take further classes after hours. The plant manager concluded that most factory workers prefer training outside their regular shifts, so the company should move all future training to evenings. Employees who could not attend the workshop, including those with caregiving duties or second jobs, were not asked about scheduling. The manager insisted the responses were reliable because every workshop attendee had the opportunity to reply.

The reasoning in the manager’s argument is flawed because it...

- **(A)** generalizes from self-selected evening attendees to all factory workers.
- **(B)** treats an expressed preference as an unchangeable legal entitlement.
- **(C)** presumes that all workshops concern predictive maintenance.
- **(D)** assumes that the sample is too large for meaningful analysis.
- **(E)** equates evening training with lower instructional quality.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The manager generalizes evening-workshop preferences to the whole workforce.
2. **Support.** Only self-selected evening attendees were surveyed.
3. **Prephrase.** Identify a sampling flaw rather than disputing the sincerity of respondents.
4. **Why (A) is right.** Availability for evenings influenced inclusion in the survey, distorting the inference about everyone.
5. **Why the others fail.**
   - **(B)** Invented issue: the manager recommends scheduling, not legal rights.
   - **(C)** Irrelevant scope: the bias lies in who was surveyed, regardless of course subject.
   - **(D)** Opposite problem: response opportunity is not evidence of representative selection.
   - **(E)** Misattributed claim: no assertion about quality appears.

**Check:** The sampling frame excludes precisely those likely to dislike evening schedules.
::::
:::

:::problem[Question I.10]
A maker of industrial gateways is considering publishing an independent security audit. Its chief operating officer predicts that the audit will increase orders from large customers, even if the audit identifies several low-severity weaknesses. She reasons that customers presently cannot verify the company’s security claims and that a credible outside assessment would make those claims more informative. The sales director replies that disclosing weaknesses will necessarily discourage buyers. Neither manager has evidence about how the firm’s target customers evaluate audit reports.

Which one of the following, if true, most strengthens the chief operating officer’s prediction?

- **(A)** Some small consumers buy gateways primarily on appearance.
- **(B)** A previous audit of an unrelated firm uncovered several severe weaknesses.
- **(C)** The firm can publish positive statements about security without an audit.
- **(D)** The audit will require engineers to stop feature development for several weeks.
- **(E)** Large customers require recent independent audits before approving suppliers.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The officer predicts that a credible audit increases orders despite minor findings.
2. **Support.** Customers lack independent verification; sales may hinge on audit availability.
3. **Prephrase.** Find a purchase rule making the audit a gateway to transactions.
4. **Why (E) is right.** Mandatory independent assessments directly link producing a report to eligibility for orders.
5. **Why the others fail.**
   - **(A)** Wrong population and dimension: the target is large-customer procurement.
   - **(B)** Negative comparison lacks evidence of how this firm’s customers respond.
   - **(C)** Restates the problem of unverifiable self-claims rather than supporting demand.
   - **(D)** Opportunity cost weakens or complicates publication, not evidence of increased orders.

**Check:** Without the report, many customers cannot approve purchases; with it, they can consider the supplier.
::::
:::

:::problem[Question I.11]
A fictional agency may authorize a drone-control radio only if its emissions test has been passed. Authorization also requires a completed interference analysis. The product under review has passed the emissions test, but its interference analysis remains unfinished. The agency’s reviewer concludes that it cannot yet authorize the product. The reviewer adds that the product might ultimately qualify; the present conclusion is simply about the decision that can be made before the missing analysis is complete.

Which one of the following most accurately describes the reviewer’s method of reasoning?

- **(A)** The reviewer infers that passing one prerequisite is sufficient for approval.
- **(B)** The reviewer predicts failure because another product failed testing.
- **(C)** The reviewer rejects an emissions result because the test was conducted improperly.
- **(D)** The reviewer applies a necessary authorization condition to explain why approval is currently unavailable.
- **(E)** The reviewer concludes that no future interference analysis could establish compliance.

::::solution[Solution]
**Answer:** (D)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Authorization cannot occur yet, though it may later.
2. **Support.** Two necessary requirements are given; one remains unfulfilled.
3. **Prephrase.** Identify modus tollens or failure of a necessary condition, without predicting permanent rejection.
4. **Why (D) is right.** The reviewer uses authorization -> completed analysis, and not completed analysis -> not authorization now.
5. **Why the others fail.**
   - **(A)** Reverse of the reasoning: the reviewer explicitly rejects approval from one prerequisite.
   - **(B)** Absent analogy: no comparison product is mentioned.
   - **(C)** Wrong target: the emissions result is accepted.
   - **(E)** Too strong: the reviewer expressly allows future qualification.

**Check:** Authorization requires complete analysis; that requirement is unsatisfied.
::::
:::

:::problem[Question I.12]
At a fictional data center, every technician who has unrestricted access to the power-control console must have completed incident-response training. Mara has completed that training. The shift supervisor claims that Mara is therefore entitled to unrestricted console access. The existing rule only states a prerequisite: it does not say whether trained technicians automatically qualify. No separate facts about Mara’s role or clearance have been supplied.

The supervisor’s conclusion follows logically if which one of the following is assumed?

- **(A)** Some technicians with console access have completed training.
- **(B)** Every technician who completes incident-response training is entitled to unrestricted console access.
- **(C)** No technician may access the console without training.
- **(D)** Mara has worked at the data center longer than several technicians with console access.
- **(E)** All technicians entitled to console access are employees of the data center.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Mara’s training implies entitlement to unrestricted console access.
2. **Support.** The existing rule says console access -> training; Mara is trained.
3. **Prephrase.** Supply the missing converse training -> entitlement.
4. **Why (B) is right.** With the added rule and Mara’s training, modus ponens yields the supervisor’s conclusion.
5. **Why the others fail.**
   - **(A)** Existential shell game: saying some qualified technicians trained does not establish Mara’s entitlement.
   - **(C)** Restates the necessary condition; it does not reverse the arrow.
   - **(D)** Seniority comparison supplies no rule from tenure to entitlement.
   - **(E)** Reverse-direction property: employee status does not confer access.

**Check:** Training(Mara); all training -> access; therefore access(Mara).
::::
:::

:::problem[Question I.13]
A refurbisher tested two processes for recovering usable laptop batteries. Process A recovered a greater percentage of batteries that passed the initial voltage screen, but its final safety test rejected a substantial portion of those batteries. Process B recovered fewer batteries at the voltage stage and lost almost none at the final safety stage. The company recorded the number passing each stage but did not publish the number entering the processes or the final yield for either process. Its report calls A 'better at voltage recovery' and B 'better at passing the final safety stage.'

Which one of the following is most strongly supported by the information above?

- **(A)** Stage-specific pass rates do not establish overall yield per incoming battery.
- **(B)** Process B must have the higher final yield because it loses fewer batteries at the last stage.
- **(C)** Process A necessarily produces more safe batteries than Process B.
- **(D)** The batteries rejected by Process A at the final stage were incorrectly rejected.
- **(E)** The company should stop measuring voltage and perform only the final safety test.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The question asks what the partial process data warrant.
2. **Support.** Different stages favor different processes and initial denominators are not reported.
3. **Prephrase.** Prefer a modest statement acknowledging the missing common baseline.
4. **Why (A) is right.** Without starting counts and combined pass rates, no comparative final yield can be computed.
5. **Why the others fail.**
   - **(B)** Denominator trap: lower final-stage attrition does not establish total yield from initial inputs.
   - **(C)** Reversal of metric: greater voltage recovery may be offset by final safety losses.
   - **(D)** Unsupported cause: a safety rejection is not stated to be an error.
   - **(E)** Policy leap: the data do not establish that the voltage stage lacks value.

**Check:** Stage-conditional percentages alone cannot rank total output per input.
::::
:::

:::problem[Question I.14]
An electronics firm suspects that confidential layout files were copied outside its secure network. Its investigator observes that only three employees appear in the access log for the week in question, and concludes that reviewing just those three recorded sessions is sufficient to uncover any unauthorized copying during that week. The investigator relies on a log listing authenticated user sessions, not a record of every process that touched the files. The files could also be retrieved by scheduled software services with delegated access.

Which one of the following is an assumption required by the investigator’s reasoning?

- **(A)** All three employees accessed the files for improper purposes.
- **(B)** The files had never been copied outside the network in earlier weeks.
- **(C)** No delegated software service accessed any file at all.
- **(D)** Every employee at the firm was aware of the suspected theft.
- **(E)** Any unauthorized copy occurred through one of the three recorded sessions.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Inspecting the three recorded sessions will uncover any unauthorized copying during the week.
2. **Support.** The logs cover employee sessions, while service-mediated copying is possible.
3. **Prephrase.** The unauthorized copy must fall inside the set of sessions being investigated.
4. **Why (E) is right.** Negating this condition permits an unauthorized service copy that the three logged sessions do not disclose, undermining the sufficiency of their review.
5. **Why the others fail.**
   - **(A)** Too strong: identifying one responsible person does not require guilt by all three.
   - **(B)** Irrelevant period: the conclusion addresses the week in question.
   - **(C)** Overbroad: harmless service access would not defeat identification of an unauthorized copier.
   - **(D)** Knowledge of an investigation does not link the log to the copier.

**Check:** If copying occurred exclusively through an unlogged service, the three recorded sessions cannot reveal it.
::::
:::

:::problem[Question I.15]
A startup’s CFO argues that it should cancel its patent-litigation insurance. In the past four years the firm paid more in premiums than it received in reimbursements, even though it faced several demand letters. The CFO reasons that future litigation expenses are unlikely to justify insurance either. The policy, however, covers defense costs for major lawsuits as well as smaller demands. The company’s next product will enter a market where larger patent holders frequently license technology through negotiated settlements.

Which one of the following, if true, most weakens the CFO’s recommendation?

- **(A)** The CFO correctly calculated all premiums paid during the past four years.
- **(B)** The insurer sometimes requires reports before reimbursing costs.
- **(C)** A single lawsuit could cause uncovered losses exceeding years of insurance premiums.
- **(D)** The firm had few demand letters before buying the policy.
- **(E)** Another startup canceled a different policy last year.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The firm should cancel insurance because past reimbursements were lower than premiums.
2. **Support.** The policy also protects against rare but costly lawsuits, which the history may not include.
3. **Prephrase.** Show that a low-frequency high-loss event makes simple premiums-versus-payouts reasoning unreliable.
4. **Why (C) is right.** A single catastrophic exposure can justify coverage even when ordinary past claims did not repay premiums.
5. **Why the others fail.**
   - **(A)** Accuracy of past spending does not address tail-risk protection.
   - **(B)** Administrative condition does not show the coverage lacks value.
   - **(D)** Historical frequency alone does not establish expected severity after product expansion.
   - **(E)** Anecdotal imitation gives no relevant claims or costs comparison.

**Check:** Insurance value depends on risk distribution, not on whether prior claims exceeded premiums.
::::
:::

:::problem[Question I.16]
A vendor may distribute a software image to the government only if the image has passed its security audit. Every image that has passed the audit receives a validation certificate. The image shipped last Tuesday was distributed to the government. Consequently, it must have a validation certificate. The vendor’s documentation contains no statement that possessing a certificate, by itself, permits government distribution, and the auditor does not rely on any such claim.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Every licensed pilot has passed a medical test. Ravi passed the test, so Ravi is a licensed pilot.
- **(B)** A press may operate only if inspected. The press is inspected, so it may operate.
- **(C)** Every fenced yard is secure. This yard is secure, so it must be fenced.
- **(D)** Some audited designs are approved. This design is audited, so it is approved.
- **(E)** Only accredited laboratories may analyze samples; all accredited labs are registered; Lab C analyzed samples, so it is registered.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Distributed image -> audited -> certificated, so distribution implies certification.
2. **Support.** Two universal conditionals and a fact establish membership at the end of a chain.
3. **Prephrase.** Match P -> Q -> R; P; therefore R.
4. **Why (E) is right.** Accredited is required for analyzing, accredited implies registry, and actual analysis establishes listed status.
5. **Why the others fail.**
   - **(A)** Affirms a necessary condition instead of deriving consequences from an observed qualifying action.
   - **(B)** Converse error: prerequisite treated as sufficient.
   - **(C)** Affirming the consequent, not a valid chain.
   - **(D)** Existential-to-individual leap not present in the original.

**Check:** Government distribution -> audit -> certificate; analogous analysis -> accreditation -> registry.
::::
:::

:::problem[Question I.17]
A manufacturer’s warranty states that products used continuously above a specified temperature are excluded from free repair. An engineer claims that a device used below that temperature must therefore qualify for free repair, even though the warranty also excludes devices damaged by unauthorized wiring. In the present case the temperature history is known, but the cause of damage has not yet been established. The engineer insists the temperature clause answers the complete coverage question because it is the first exclusion listed.

The engineer’s argument is most vulnerable to criticism because it...

- **(A)** infers that the temperature condition was never included in the warranty.
- **(B)** argues from the manufacturer’s character rather than the warranty’s terms.
- **(C)** treats avoiding one warranty exclusion as enough to qualify for coverage.
- **(D)** assumes that every instance of unauthorized wiring causes damage.
- **(E)** mistakes a product’s purchase price for the cost of a repair.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The engineer claims below-threshold use guarantees free repair.
2. **Support.** The contract lists two independent exclusions; satisfying one does not eliminate the other.
3. **Prephrase.** Find a necessary/sufficient mistake across separate grounds for denial.
4. **Why (C) is right.** The engineer treats not being excluded by temperature as equivalent to not being excluded at all.
5. **Why the others fail.**
   - **(A)** Contrary to the text: the engineer expressly invokes that clause.
   - **(B)** No ad hominem: the argument is about conditions of coverage.
   - **(D)** Does not rely on a causal claim about wiring; just ignores a separate exclusion.
   - **(E)** Unrelated comparison: neither amount appears.

**Check:** Not temperature-excluded does not imply warranty-covered if wiring exclusion may apply.
::::
:::

:::problem[Question I.18]
An engineering director says that a network-appliance prototype should undergo an additional field trial. She acknowledges that its laboratory throughput exceeds the client’s written target and that its processor has passed thermal testing. Yet the prototype lost connectivity during two power-transfer events at a remote site, and the client relies on uninterrupted availability during those events. The director concludes that impressive benchmark performance alone does not justify deployment. The trial should reproduce power transfers before the firm authorizes installation at other sites.

In the argument, the statement that the prototype lost connectivity during two power-transfer events plays which one of the following roles?

- **(A)** It is the director’s ultimate conclusion about whether to deploy the appliance.
- **(B)** It supplies field-failure evidence supporting another trial despite positive laboratory results.
- **(C)** It is an objection raised by the client that the director rejects.
- **(D)** It states a condition sufficient for passing the thermal test.
- **(E)** It summarizes an opposing argument for immediate installation.

::::solution[Solution]
**Answer:** (B)

**Type:** Role of statement (Chapter 11)

1. **Conclusion.** The director recommends an additional power-transfer field trial.
2. **Support.** Good lab results are conceded; failures under client-critical conditions support caution.
3. **Prephrase.** Identify how the cited fact counters the tempting deployment inference.
4. **Why (B) is right.** The power-transfer failures are the concrete evidence making an extra trial relevant.
5. **Why the others fail.**
   - **(A)** Role reversal: the conclusion is to require further trial before wider installation.
   - **(C)** Wrong attribution: the director accepts the failure as evidence.
   - **(D)** Different domain: connectivity disruption is not a criterion for thermal passage.
   - **(E)** Opposite role: the fact undermines immediate deployment.

**Check:** Remove this observation and the director’s reason for testing transfer events is substantially weakened.
::::
:::

:::problem[Question I.19]
A chip design team proposes replacing one interconnect material with another to reduce power loss. Simulations show a reduction in resistance at the intended dimensions, but the alternative requires an unfamiliar deposition step. The process engineer argues that the team should run a small fabrication experiment before committing to the substitution, because a theoretical electrical advantage may be offset by manufacturing defects. Management is considering skipping the experiment to meet an aggressive project calendar.

Which one of the following, if true, most strengthens the process engineer’s argument?

- **(A)** The material appears promising in simulations at several temperatures.
- **(B)** The fabrication experiment would require purchasing an additional mask.
- **(C)** The current interconnect material has been used by the team for years.
- **(D)** Related deposition experiments produced connection-breaking voids in the proposed material.
- **(E)** Some customers prefer chips with lower power consumption.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer recommends a fabrication experiment before substitution.
2. **Support.** Simulated resistance ignores potential yield loss under an unfamiliar process.
3. **Prephrase.** Find concrete evidence of physical manufacturing failure despite good design.
4. **Why (D) is right.** Related deposition history makes the hypothesized defects credible and trial data valuable.
5. **Why the others fail.**
   - **(A)** Reinforces the known electrical benefit, not the untested manufacturing concern.
   - **(B)** Cost objection complicates rather than supports the trial.
   - **(C)** Familiarity alone is weaker than direct evidence of deposition defects.
   - **(E)** Demand does not show the manufacturing advantage will survive fabrication.

**Check:** Electrical simulation does not rule out physical voids in production.
::::
:::

:::problem[Question I.20]
Engineer Vale: Our consortium should publish the interface specification before all member firms finish their private implementations. Public feedback may reveal ambiguities that members have overlooked, and any such ambiguities can be corrected before certification begins. Engineer Rios: The draft certainly contains ambiguities, and public users would probably identify some of them. Nevertheless, publication before members have working implementations would encourage outside teams to build incompatible software around an unsettled document. We should finish the implementations first.

Vale and Rios disagree over whether...

- **(A)** the consortium should publish before members finish implementing the specification.
- **(B)** the draft specification contains ambiguities.
- **(C)** outside users are capable of finding ambiguities.
- **(D)** certification should eventually be part of the standardization process.
- **(E)** member firms have already finished implementing the interface.

::::solution[Solution]
**Answer:** (A)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Vale endorses early publication; Rios rejects early publication.
2. **Support.** They agree on likely public feedback but weigh premature reliance differently.
3. **Prephrase.** Ask what proposition receives explicit yes from one speaker and no from the other.
4. **Why (A) is right.** The publication timing question is answered oppositely by the two engineers.
5. **Why the others fail.**
   - **(B)** Agreement trap: both explicitly acknowledge ambiguities.
   - **(C)** Agreement trap: Vale predicts it and Rios concedes it.
   - **(D)** No determinate opposition: only Vale mentions certification.
   - **(E)** Factual issue not disputed: both describe implementation as unfinished.

**Check:** Yes/No test: Vale yes before completion; Rios no before completion.
::::
:::

:::problem[Question I.21]
A consumer group ranks fictional laptops using two tests. Every laptop rated 'repair-friendly' has a battery removable without specialized heating. No laptop requiring a proprietary service server to activate a replacement keyboard receives the rating. Some laptops satisfying both conditions nevertheless fail the rating because replacement parts are unavailable. Alder’s newest laptop has been rated repair-friendly. The report does not specify its price, warranty period, or whether its manufacturer sells parts directly to independent shops.

Which one of the following must be true about Alder’s newest laptop?

- **(A)** It does not require a proprietary server to activate a replacement keyboard.
- **(B)** Replacement parts for it are sold directly to every independent repair shop.
- **(C)** Its battery can be removed only by a professional technician.
- **(D)** It has a longer warranty than any laptop without the rating.
- **(E)** It meets only the two explicitly listed conditions and no other criteria.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The rating implies absence of server-dependent keyboard activation.
2. **Support.** A device with that requirement cannot receive the rating.
3. **Prephrase.** Use the contrapositive of the exclusion rule.
4. **Why (A) is right.** If server required -> not rated; rated -> no server requirement.
5. **Why the others fail.**
   - **(B)** Too strong: rating does not guarantee all vendors or all parts access.
   - **(C)** Unsupported exclusivity: removability without special heating does not define who may remove it.
   - **(D)** Unstated comparison: no warranty data appear.
   - **(E)** Wrong inference: additional criteria such as parts availability may apply.

**Check:** Alder is rated, so it cannot be among excluded server-dependent devices.
::::
:::

:::problem[Question I.22]
A cloud-storage company reports that its enterprise clients transferred 15 percent more data in a quarter after it introduced a new pricing dashboard. The marketing vice president claims that an average client transferred 15 percent more data, showing that the dashboard increased each client’s usage. But one very large client doubled its transfers while several small clients reduced theirs. The reported figure measures the change in the total amount of data, not the mean percentage change across clients.

The vice president’s argument is flawed because it...

- **(A)** assumes that no client changed its service plan during the quarter.
- **(B)** confuses revenue per gigabyte with the absolute amount of data transferred.
- **(C)** rejects the reported total change as inaccurately measured.
- **(D)** shows that the dashboard was intentionally designed to favor large clients.
- **(E)** projects an aggregate usage increase onto individual clients without accounting for variation.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The vice president claims typical and individual client usage rose 15 percent.
2. **Support.** The only figure is total transfer change, dominated by large accounts.
3. **Prephrase.** Spot composition or aggregation error: total movement does not imply each member moved similarly.
4. **Why (E) is right.** The large account can lift the aggregate even while smaller accounts decline.
5. **Why the others fail.**
   - **(A)** No such exclusion is essential to the specifically identified aggregate-to-individual leap.
   - **(B)** Both premises and conclusion concern transfer quantities, not price or revenue.
   - **(C)** Opposite: the vice president accepts the aggregate number.
   - **(D)** Motive invention: nothing concerns design intent.

**Check:** Total +15 percent is consistent with many individual decreases.
::::
:::

:::problem[Question I.23]
Only suppliers that have signed the consortium’s patent-license agreement may display the interoperability logo. Ardent Devices displays the logo. A lawyer therefore concludes that Ardent has complied with every provision of the patent-license agreement. The lawyer concedes that merely signing the agreement does not establish compliance with all its ongoing reporting and royalty provisions; nevertheless, she treats the logo as decisive proof of complete compliance.

Which one of the following arguments exhibits the same flaw?

- **(A)** All audited firms receive a seal. These firms were audited, so they receive the seal.
- **(B)** Only licensed pharmacists may dispense the medicine. Rina dispensed it, so Rina is licensed.
- **(C)** A firm may bid only if registered. This firm is registered, so it may bid.
- **(D)** Only enrolled drivers may enter; Niko entered, so he complied with every program requirement.
- **(E)** If a device is certified, its battery passed inspection. This device is not certified, so its battery failed.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** Logo -> signed agreement, and lawyer improperly infers full ongoing compliance.
2. **Support.** Signing is necessary for logo but not a guarantee of subsequent performance.
3. **Prephrase.** Find a valid inference to eligibility followed by a flawed leap to comprehensive fulfillment.
4. **Why (D) is right.** Entering -> enrollment could hold, but enrollment does not establish compliance with every program rule.
5. **Why the others fail.**
   - **(A)** Valid modus ponens, not a leap from entry condition to broader compliance.
   - **(B)** Valid inference from a necessary condition; stops short of claiming full compliance.
   - **(C)** Converse error, unlike deriving registration and then inflating it to comprehensive compliance.
   - **(E)** Denying antecedent, a different conditional mistake.

**Check:** Entry supports enrolled status, not all continuing requirements.
::::
:::

:::problem[Question I.24]
A litigation funder forecasts that a proposed licensing settlement will outperform the cost of continuing a dispute. The analyst bases the forecast on cash payments promised under the settlement and subtracts projected litigation spending under the alternative. The analyst concludes that settling now produces a better financial outcome for the patent holder. The proposal includes a clause permitting the licensee to delay payment if a regulatory approval is not received. No forecast includes the probability or cost of delay.

The analyst’s reasoning requires assuming which one of the following?

- **(A)** Regulatory approval is certain to arrive immediately.
- **(B)** All future patent disputes involving the licensee will be settled.
- **(C)** Possible payment delays will not reverse the settlement’s forecast financial advantage.
- **(D)** The patent holder prefers cash to every form of noncash consideration.
- **(E)** The estimated cost of litigation will never change.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Settlement now will provide the better financial outcome.
2. **Support.** The forecast omits a contractually allowed payment delay affecting settlement value.
3. **Prephrase.** The unmodeled delay cannot be large enough to reverse the ranking.
4. **Why (C) is right.** Negate it: if delays erase settlement advantage, the analyst’s conclusion fails.
5. **Why the others fail.**
   - **(A)** Overstrong: a modest delay could occur without changing the financial ranking.
   - **(B)** Outside the specified financial comparison.
   - **(D)** No noncash alternative is part of the conclusion.
   - **(E)** Too absolute: estimates could vary modestly without reversing the comparison.

**Check:** The claimed inequality requires delay-adjusted settlement value to remain higher.
::::
:::

:::problem[Question I.25]
A technology firm is considering a costly infringement suit against a competitor. Its lawyer says the competitor’s chip probably falls within the ordinary wording of a patent claim, so litigation is economically attractive. The competitor argues that statements the firm made during examination limit the claim to a narrower architecture that the competitor does not use. The lawyer has estimated damages and litigation costs but has not reviewed those examination statements. The client asks what information would best determine whether to proceed.

The answer to which one of the following questions would be most useful in evaluating the lawyer’s recommendation?

- **(A)** Does the competitor produce more chips than the patent holder?
- **(B)** Did examination statements limit the claim enough to exclude the competitor’s architecture?
- **(C)** Was the patent holder’s first prototype made with expensive equipment?
- **(D)** Have other firms criticized the competitor’s marketing?
- **(E)** Is the patent holder’s headquarters nearer the courthouse?

::::solution[Solution]
**Answer:** (B)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The lawyer recommends suit based on ordinary wording and projected economics.
2. **Support.** A potentially decisive narrower claim interpretation remains unexamined.
3. **Prephrase.** Ask whether the missing examination record removes the factual basis for probable infringement.
4. **Why (B) is right.** A yes would undercut the proposed infringement theory; a no would remove the specific asserted obstacle.
5. **Why the others fail.**
   - **(A)** Market scale does not resolve the threshold claim-scope dispute.
   - **(C)** Historical production cost does not address the legal scope issue.
   - **(D)** Reputation is no substitute for determining whether the claim reaches the architecture.
   - **(E)** Geographic convenience does not answer the central infringement-risk question.

**Check:** Opposite answers materially change the chance of proving the claimed infringement.
::::
:::

## 37.2 Section II: Reading Comprehension

### Passage 1

A microchip emerges from a sequence of patterned layers, not from a single impression of its circuitry. During photolithography, light and a patterned mask are used to define features in a light-sensitive coating on a wafer; subsequent processing transfers or modifies those features. A layer may be precisely printed yet fail to connect properly with structures established earlier. Manufacturers therefore measure *overlay*, the alignment of one patterned layer with another. For a fictional fabrication line making a specialized sensor chip, engineers face a choice between slowing production to measure more wafers and allowing equipment to operate longer between measurements.

One group proposes using the mean overlay error measured at a few designated sites on each sampled wafer. The group reasons that if the mean remains close to zero, the process is centered and additional measurement merely consumes machine time. A second group notes that an average can conceal large errors of opposite signs. One side of a wafer might shift left and the other right, producing an excellent mean but poor alignment at both edges. This objection does not show that averages are useless. It shows that a reported statistic answers a narrower question than some engineers assume it answers. The second group proposes tracking spatial patterns and the spread of errors as well as their mean.

There is a complication. Measuring every feature on every chip is impractical. Engineers commonly use selected measurement sites and structures designed for metrology, which may not perfectly represent the behavior of active circuitry. More sites can reveal spatial variation, but only if their locations are informative. Ten measurements placed near the wafer center might miss the very edge effect that four well-chosen sites would detect. The fictional line’s engineers consequently distinguish *sampling density*, the number of measurements, from *sampling design*, the choice of where and what to measure. More data can improve knowledge, but simply multiplying nearly identical observations does not ensure it.

Feedback introduces a further tradeoff. Measurements from a completed batch can guide adjustments to equipment settings before later batches are processed. Yet an adjustment based on a transient disturbance may move an otherwise stable process away from its ideal settings. The engineers therefore propose comparing an apparent shift with the history of the process before acting. This proposal initially appears to favor caution over speed. In fact, it aims to make rapid adjustments more trustworthy: a controller that reacts to every fluctuation may create variation instead of reducing it.

The most defensible policy for the fictional line is neither maximal inspection nor blind confidence in a low average. It is a measurement plan matched to the errors that matter, coupled with feedback rules calibrated to distinguish persistent drift from noise. The line’s ultimate aim is usable chips, not favorable-looking metrology reports. Measures should be judged by how well they help engineers detect and correct consequential misalignment, rather than by how many numbers they produce.

:::problem[Question II.1]
Which one of the following most accurately expresses the main point of Passage 1?

- **(A)** Measuring every feature on every chip is the only reliable method of preventing misalignment.
- **(B)** Useful overlay control requires informative sampling and calibrated feedback, not just favorable averages.
- **(C)** The best way to increase chip yield is to eliminate all statistical averaging.
- **(D)** Measurements from designated wafer targets always perfectly reflect active circuitry.
- **(E)** A controller should change settings whenever any sampled error is detected.

::::solution[Solution]
**Answer:** (B)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The author favors evidence-sensitive sampling and calibrated feedback.
2. **Support.** Paragraphs two and three distinguish averages and sites; paragraph four distinguishes drift and noise.
3. **Prephrase.** Find a thesis spanning measurement and control, with moderate force.
4. **Why (B) is right.** The credited choice integrates the passage’s two practical decisions and its outcome-focused conclusion.
5. **Why the others fail.**
   - **(A)** Extreme opposite: the passage explains why full measurement is impractical.
   - **(C)** Distortion: averages retain value but are insufficient alone.
   - **(D)** Contradicts the explicit warning about metrology targets.
   - **(E)** Opposite of the caution against reacting to transient variation.

**Check:** It captures the entire progression from overlay errors to effective control.
::::
:::

:::problem[Question II.2]
The author describes opposite-sign overlay errors on different sides of a wafer primarily in order to...

- **(A)** demonstrate that photolithography cannot produce aligned patterns on curved surfaces.
- **(B)** prove that any statistic computed from multiple measurements is misleading.
- **(C)** show that measuring an edge is always less useful than measuring the center.
- **(D)** establish that the first engineering group has fabricated its results.
- **(E)** show that mean errors can cancel while serious local misalignment remains.

::::solution[Solution]
**Answer:** (E)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The question concerns the role of the opposite-sign example.
2. **Support.** A leftward and rightward shift cancel numerically but not physically.
3. **Prephrase.** The example attacks treating a centered mean as complete spatial evidence.
4. **Why (E) is right.** Opposing errors can sum to zero although neither location is aligned, illustrating concealed dispersion.
5. **Why the others fail.**
   - **(A)** Technical invention: surface curvature is not the problem in the example.
   - **(B)** Too broad: the author defends the limited usefulness of averages.
   - **(C)** Reversal: the example gives the edge potential importance.
   - **(D)** No accusation of dishonesty or fabricated data appears.

**Check:** The problem is loss of spatial information during aggregation.
::::
:::

:::problem[Question II.3]
The discussion of ten measurements near a wafer’s center and four well-chosen measurements most strongly suggests that...

- **(A)** a smaller, geographically informative sample can reveal patterns missed by clustered measurements.
- **(B)** the mathematical average from four measurements is always more precise than that from ten.
- **(C)** the center of a wafer has no useful measurement targets.
- **(D)** all spatial error patterns are visible from exactly four sites.
- **(E)** manufacturers ordinarily collect fewer than ten measurements per wafer.

::::solution[Solution]
**Answer:** (A)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The author differentiates count from site selection.
2. **Support.** Central measurements can miss edge effects; strategically selected sites may capture them.
3. **Prephrase.** Infer that information content need not increase with redundant data quantity.
4. **Why (A) is right.** This is the explicit lesson of sampling density versus design, stated without claiming four is universally best.
5. **Why the others fail.**
   - **(B)** Unsupported universal claim: precision depends on sampling and variation.
   - **(C)** Overreach: the author only warns about exclusive center sampling.
   - **(D)** The example is illustrative, not a guaranteed universal four-site protocol.
   - **(E)** The example is hypothetical and does not report industry-wide counts.

**Check:** Ten clustered points can miss a spatial trend that four distributed sites capture.
::::
:::

:::problem[Question II.4]
What is the primary function of the fourth paragraph in the passage?

- **(A)** To argue that process control should be abandoned whenever measurements contain noise.
- **(B)** To identify equipment speed as the sole determinant of chip yield.
- **(C)** To claim that all previous batches must be reprocessed after each new measurement.
- **(D)** To explain why equipment adjustments must distinguish persistent drift from transient noise.
- **(E)** To show that measurements from completed batches have no bearing on later ones.

::::solution[Solution]
**Answer:** (D)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The paragraph adds the control-decision question to the measurement-design discussion.
2. **Support.** Past measurements can guide later settings, but transient noise can prompt damaging corrections.
3. **Prephrase.** State the reason for caution without denying feedback’s usefulness.
4. **Why (D) is right.** The choice describes the paragraph’s tradeoff and its distinction between persistent drift and noise.
5. **Why the others fail.**
   - **(A)** Too absolute: the author wants calibrated control, not no control.
   - **(B)** Wrong emphasis: the paragraph concerns reliability of adjustment.
   - **(C)** No such intervention is proposed.
   - **(E)** Reversal: the author says later batches can benefit from feedback.

**Check:** It matches the paragraph’s opening, complication, and resolution.
::::
:::

:::problem[Question II.5]
Which one of the following best characterizes the author’s attitude toward the first group’s reliance on mean overlay error?

- **(A)** It is scientifically fraudulent because averaging conceals errors intentionally.
- **(B)** It should replace all other metrology because it is inexpensive.
- **(C)** It is useful but incomplete when spatial error patterns matter.
- **(D)** It accurately captures every consequential wafer defect.
- **(E)** It can never inform equipment control even when supplemented by other measures.

::::solution[Solution]
**Answer:** (C)

**Type:** Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author criticizes overreliance, not the use of means itself.
2. **Support.** The counterexample shows cancellation; the subsequent caveat preserves averages’ narrower purpose.
3. **Prephrase.** Look for a qualified assessment.
4. **Why (C) is right.** The answer mirrors the explicit statement that an average answers a narrower question, while retaining some value.
5. **Why the others fail.**
   - **(A)** Invented motive: the author faults an inference, not integrity.
   - **(B)** Opposite of the author’s broader sampling recommendation.
   - **(D)** Excessive strength: the whole counterexample disproves completeness.
   - **(E)** Too strong: the passage expressly says averages are not useless.

**Check:** The author’s phrase about averages not being useless rules out categorical rejection.
::::
:::

:::problem[Question II.6]
Which one of the following manufacturing policies most closely reflects the passage’s recommendation?

- **(A)** A factory measures many boards from one favored production position and recalibrates equipment after every isolated deviation.
- **(B)** A factory measures fewer boards each month so that its measurement database remains small.
- **(C)** A factory uses only the average error from each day because an average is insensitive to fluctuations.
- **(D)** A factory samples varied sites, tracks dispersion, and adjusts only for persistent shifts.
- **(E)** A factory ignores testing and relies on customer returns to identify defects.

::::solution[Solution]
**Answer:** (D)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The proposed transfer should combine representative measurement with calibrated action.
2. **Support.** The passage values meaningful locations, dispersion, historical comparison, and persistent signals.
3. **Prephrase.** Find the policy that addresses both measurement and response.
4. **Why (D) is right.** The answer preserves spatial diversity and delays control action until evidence indicates drift.
5. **Why the others fail.**
   - **(A)** Repeats both criticized habits: narrow sampling and reaction to noise.
   - **(B)** Count minimization without attention to informative design or control.
   - **(C)** Confuses average cancellation with safety from localized problems.
   - **(E)** Discards proactive metrology and process feedback entirely.

**Check:** It avoids the center-only and react-to-every-noise pitfalls.
::::
:::

:::problem[Question II.7]
According to the passage, why must engineers be cautious about relying entirely on measurements from metrology targets?

- **(A)** The targets are inspected less frequently than the finished chips are packaged.
- **(B)** The targets can report only the mean and never individual measurement values.
- **(C)** Target patterns may not fully represent misalignment in functional circuitry.
- **(D)** The targets are prohibited from being located near wafer edges.
- **(E)** The targets can measure electrical resistance but not layer alignment.

::::solution[Solution]
**Answer:** (C)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The question asks the stated representativeness limitation.
2. **Support.** Paragraph three says special targets may not perfectly represent active circuitry behavior.
3. **Prephrase.** Answer by matching the limitation directly, without inventing an instrument restriction.
4. **Why (C) is right.** The answer restates the target-to-device distinction accurately.
5. **Why the others fail.**
   - **(A)** The passage neither makes this time-frequency comparison nor bases its concern on packaging.
   - **(B)** Technical restriction not stated; the concern is representativeness.
   - **(D)** Wrong claim: site choice is under the engineers’ control.
   - **(E)** Reversal of their stated purpose as overlay measurement structures.

**Check:** The passage explicitly warns that targets may be imperfect stand-ins for actual circuitry.
::::
:::

### Passage 2

Accounts of computing history often depict the spread of a program as a contest between two opposing models: guarded ownership and unrestricted sharing. The history of Unix-inspired software complicates this binary. Unix was developed at Bell Labs, while later free-software projects sought to make Unix-like capabilities available under terms permitting users to examine, modify, and redistribute code. Their technical similarities did not require identical legal arrangements. Indeed, the ability to reproduce an interface or behavior without copying protected source code helps explain why a software tradition can outlive a particular implementation.

Some historians emphasize the cultural force of readable code. When programmers can study a working system, they can adapt it to unexpected hardware, teach from it, and expose flaws that a single maintainer may overlook. On this account, access to source is not merely a convenience but a way of distributing technical judgment. The argument, however, can slide too quickly from *permission to participate* to *effective participation*. Reading a repository and persuading its maintainers to accept a change are distinct activities. Contributors may lack the time, specialized knowledge, or authority necessary to alter the system on which they depend.

Another account therefore stresses institutions. Even a project whose license permits modification may depend on a small group that reviews patches, maintains release schedules, and decides which competing changes belong in a common version. Some such decisions concern compatibility: a technically elegant change may break tools whose users rely on an older interface. Others concern scarce attention: a bug report can be public and still remain unresolved because no one is funded to fix it. A community can distribute permission broadly while concentrating practical responsibility in a few hands. This is not necessarily hypocrisy; coordination may require a narrower set of decision-makers than the population entitled to copy the code.

The tension has sometimes led commentators to ask whether calling software *free* is misleading. But the objection conflates distinct freedoms. A person can possess the legal freedom to create a modified version without being entitled to control the original project’s official release. Conversely, a project may invite suggestions while retaining a license that restricts what others can redistribute. Neither the number of contributors nor the openness of discussion, taken alone, specifies the rights conveyed by a license. Historians who collapse these distinctions risk confusing governance practices with legal permissions.

A richer history would ask how licenses, technical interfaces, volunteer labor, commercial support, and maintainer authority interact. Such an account neither treats access to source as a guarantee of democratic governance nor dismisses it as symbolic. It recognizes that the movement’s achievement was to make certain forms of software independence possible while leaving difficult questions of coordination unresolved. The useful historical contrast is not between perfectly open and perfectly closed systems, but between the different ways communities allocate rights, expertise, and responsibility.

:::problem[Question II.8]
Which one of the following most accurately states the central argument of Passage 2?

- **(A)** Unix and Unix-like systems necessarily employ exactly the same source code.
- **(B)** Understanding Unix-inspired free software requires separating legal rights from official project governance.
- **(C)** Any project permitting source inspection must accept every proposed change.
- **(D)** Commercial support invariably prevents independent programmers from contributing.
- **(E)** The history of software is explained completely by competition between two fixed ownership models.

::::solution[Solution]
**Answer:** (B)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The author rejects an openness-versus-ownership binary and proposes a layered history.
2. **Support.** Legal permission, technical interfaces, maintainer decisions, and labor allocation are distinct variables.
3. **Prephrase.** Identify the distinction uniting all five paragraphs.
4. **Why (B) is right.** The answer covers rights and governance while leaving room for their interaction.
5. **Why the others fail.**
   - **(A)** Contradicts the difference between technical resemblance and copied implementation.
   - **(C)** Conflates license rights with official maintainer authority.
   - **(D)** Opposite to the passage’s multidimensional treatment of support and participation.
   - **(E)** Rejected binary rather than the author’s thesis.

**Check:** It explains the passage’s progression and final call for a richer historical account.
::::
:::

:::problem[Question II.9]
In the second paragraph, the contrast between access to a repository and persuading maintainers to accept a change is used to show that...

- **(A)** source access always produces less innovation than closed development.
- **(B)** maintainers can legally prevent every user from creating a private modified version.
- **(C)** all prospective contributors possess identical technical expertise.
- **(D)** the movement’s supporters mainly object to teaching with source code.
- **(E)** The right to modify code does not guarantee influence over official releases.

::::solution[Solution]
**Answer:** (E)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The paragraph tempers a cultural celebration of readable code.
2. **Support.** Practical participation depends on time, expertise, and maintainer acceptance.
3. **Prephrase.** Match possible legal freedom against constrained influence in a shared project.
4. **Why (E) is right.** An individual can alter a copy without controlling the official release.
5. **Why the others fail.**
   - **(A)** The passage makes no comparison of innovation outcomes between open and closed development.
   - **(B)** Opposes the distinction between private freedom and official authority.
   - **(C)** Contradicted by unequal knowledge and available time.
   - **(D)** No: teaching is described as a possible advantage.

**Check:** The second paragraph explicitly distinguishes reading from persuading maintainers.
::::
:::

:::problem[Question II.10]
The example of an elegant change that breaks tools relying on an older interface primarily serves to...

- **(A)** illustrate why maintainers may reject changes despite broad modification rights.
- **(B)** argue that older interfaces must never be modified for any reason.
- **(C)** show that technical elegance is meaningless in software design.
- **(D)** prove that a project’s license legally prohibits backward-incompatible updates.
- **(E)** demonstrate that commercial users cannot use open-source software.

::::solution[Solution]
**Answer:** (A)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The example defends the existence of coordination tradeoffs.
2. **Support.** Official releases must account for users who depend on old behaviors.
3. **Prephrase.** Identify a reason openness can coexist with selective acceptance.
4. **Why (A) is right.** Compatibility offers a nonhypocritical explanation for concentrated maintenance decisions.
5. **Why the others fail.**
   - **(B)** Universal prohibition not supported; it is one coordination consideration.
   - **(C)** Overstates: elegance is simply not the only relevant factor.
   - **(D)** Conflates governance decision with license rule.
   - **(E)** Contrary to the described compatibility concerns of existing users.

**Check:** Maintainer filtering can protect other users without revoking modification rights.
::::
:::

:::problem[Question II.11]
Which one of the following can most reasonably be inferred from the passage?

- **(A)** Similar public discussion practices can accompany different redistribution rights.
- **(B)** Projects with public discussions always have identical licensing terms.
- **(C)** A project with a small maintainer group cannot permit users to distribute modified versions.
- **(D)** Legal permission to redistribute code makes release schedules unnecessary.
- **(E)** Volunteer-maintained projects never receive commercial support.

::::solution[Solution]
**Answer:** (A)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Discussion openness and license permissions are separable.
2. **Support.** The fourth paragraph says invitations to contribute can coexist with restrictive redistribution terms.
3. **Prephrase.** Infer diversity of licensing even when participation practices look alike.
4. **Why (A) is right.** The answer combines the passage’s explicit contrast without claiming a particular project has any license.
5. **Why the others fail.**
   - **(B)** Exact opposite of the distinction stressed in paragraph four.
   - **(C)** Conflates official release decisions with separate redistribution rights.
   - **(D)** Institutional work remains necessary under broad permissions.
   - **(E)** The conclusion explicitly treats volunteer labor and commercial support as interacting dimensions.

**Check:** Shared discussion style does not entail shared rights of redistribution.
::::
:::

:::problem[Question II.12]
The author’s attitude toward accounts that classify software traditions as simply “open” or “closed” is best described as...

- **(A)** enthusiastic because the labels account for every relevant institutional difference.
- **(B)** indifferent because historical analysis has no practical implications.
- **(C)** skeptical because these labels obscure distinct rights and governance arrangements.
- **(D)** hostile to all software licensing as an illegitimate practice.
- **(E)** convinced that technical interfaces have no historical influence.

::::solution[Solution]
**Answer:** (C)

**Type:** Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author qualifies binary historical narratives.
2. **Support.** The passage presents multiple independent dimensions and asks historians not to collapse them.
3. **Prephrase.** Select a measured critique of oversimplification.
4. **Why (C) is right.** The stated reason matches the author’s explicit objections and the concluding agenda.
5. **Why the others fail.**
   - **(A)** Reverse stance: the author opens by challenging the binary.
   - **(B)** The author offers a specific richer research program.
   - **(D)** Overreach: legal freedoms are treated as real and important.
   - **(E)** Contradicted by the discussion of Unix-like behavior and compatibility.

**Check:** The vocabulary of complication and richer history supports skepticism, not dismissal.
::::
:::

:::problem[Question II.13]
Which one of the following situations would the passage most likely cite as evidence for its analysis?

- **(A)** A project bars source inspection and has no public discussion forum.
- **(B)** Every patch submitted to a project is automatically merged without review.
- **(C)** A proprietary vendor raises its price while retaining all source code.
- **(D)** A historian compares only a program’s first release date and the number of disks sold.
- **(E)** A license permits redistribution of modifications, but maintainers control the project’s official releases.

::::solution[Solution]
**Answer:** (E)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The passage argues that modification rights and release control can diverge.
2. **Support.** A license may allow forks even when official maintainers exercise centralized choice.
3. **Prephrase.** Find a concrete case with broad redistribution permission but concentrated governance.
4. **Why (E) is right.** The answer exhibits the exact contrast explained in paragraphs three and four.
5. **Why the others fail.**
   - **(A)** Fits a simple closed category, offering little evidence for separating permissions from governance.
   - **(B)** Does not illustrate the practical coordination distinction the passage emphasizes.
   - **(C)** Prices and secrecy do not show the separation between rights and authority.
   - **(D)** Leaves out the social and legal dimensions the author wants investigated.

**Check:** Official release authority need not follow from the legal right to redistribute a fork.
::::
:::

### Passage 3 (comparative)

**Passage A**

Technical standards allow devices from different manufacturers to work together. A patent may be *standard-essential* when implementing a particular standardized feature necessarily practices a patented invention. Some holders of such patents undertake to offer licenses on fair, reasonable, and nondiscriminatory, or FRAND, terms. Consider a hypothetical dispute over the royalty for a wireless communication feature used in a complex industrial machine. The patent holder proposes a royalty calculated as a percentage of the machine’s selling price, arguing that connectivity makes the entire machine more useful.

That approach risks attributing the machine’s unrelated value to the patented feature. The sensors, motors, software, and mechanical assembly would retain much of their worth without the particular standardized communication method. A price tied directly to a relevant communication module would make it harder to claim a share of value generated elsewhere. Although a module’s price is not a perfect measure of the invention’s contribution, it supplies a disciplined starting point. Comparisons with licenses for similar functions could then modify the estimate. An appropriate royalty should reward the patented technical contribution, not merely take advantage of the fact that the invention appears inside an expensive finished product. The module benchmark would not end the negotiation. It would place the burden on each party to explain, with evidence, why the patented feature contributes more or less value than that reference price suggests. The point of a starting point is to make disagreements about adjustments visible, not to replace those disagreements with a formula.

**Passage B**

The royalty question cannot always be settled by identifying the cheapest physical component in which a patented method operates. In the hypothetical industrial machine, the communication module may be inexpensive because it is mass-produced, yet reliable connectivity could allow the machine to perform valuable coordinated tasks. A royalty method tied mechanically to the module’s invoice price could neglect value that users obtain from the standardized function. The relevant inquiry is the value attributable to the patented contribution, and value need not sit entirely inside a replaceable component.

Still, using the complete machine’s price without adjustment invites overreach. It could credit the patent with gains produced by motors, sensors, and other inventions. Instead of treating either the module or the machine as a legally automatic base, negotiators should investigate comparable licenses, the incremental benefit of the standardized function, and the alternatives available when the standard was selected. Such evidence may be imperfect, but a transparent inquiry can reveal why a proposed amount is justified. The parties should not disguise a contest about attributed value as a technical argument over which piece of hardware receives the royalty label. I would not give the module price presumptive priority, even at the beginning. An initial number can frame every subsequent concession; selecting one primarily because it is printed on a component invoice risks making the burden of justification run in the wrong direction.

:::problem[Question II.14]
The authors of Passages A and B would most likely disagree about whether...

- **(A)** unadjusted finished-machine prices can attribute unrelated value to the patent.
- **(B)** a communication module’s price should ordinarily anchor the initial royalty calculation.
- **(C)** the standardized function may be useful to machine purchasers.
- **(D)** comparable licenses may supply relevant evidence in negotiations.
- **(E)** standardization can facilitate interoperability among manufacturers.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative reading: disagreement (Chapter 17)

1. **Conclusion.** A favors the relevant module as disciplined starting point; B resists mechanical primacy for a physical component.
2. **Support.** Both seek attributable patented value but weight component price differently.
3. **Prephrase.** Find a shared question on which their recommended methodology diverges.
4. **Why (B) is right.** A endorses a module-centered initial benchmark; B warns against letting the cheap module control without considering system-level benefit.
5. **Why the others fail.**
   - **(A)** Agreement: both explicitly warn against uncritical full-device pricing.
   - **(C)** Agreement: both assume the function provides value.
   - **(D)** Agreement: both name comparisons among relevant licenses.
   - **(E)** This is shared background, not the two authors’ methodological disagreement.

**Check:** A: start with component benchmark; B: no automatically privileged component benchmark.
::::
:::

:::problem[Question II.15]
Both authors would most likely agree that...

- **(A)** the finished industrial machine’s entire sales price must always be the royalty base.
- **(B)** a standard-essential patent can never generate value beyond the component containing it.
- **(C)** the least expensive component necessarily produces the fairest royalty.
- **(D)** royalties should exclude value attributable to unrelated product features.
- **(E)** all relevant licensing comparisons are too unreliable to consider.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative reading: agreement (Chapter 17)

1. **Conclusion.** The texts share a commitment to value attributable to the invention rather than unrelated equipment.
2. **Support.** A criticizes the machine price for capturing other functions; B identifies the same overreach.
3. **Prephrase.** Seek the common limiting principle, not a shared numerical formula.
4. **Why (D) is right.** Each passage names unrelated components as reasons to reject an unadjusted machine-price approach.
5. **Why the others fail.**
   - **(A)** Neither author accepts unadjusted whole-machine attribution.
   - **(B)** B expressly rejects the component-only limitation.
   - **(C)** A calls module price an imperfect starting point; B challenges its primacy.
   - **(E)** Both expressly propose using comparisons as evidence.

**Check:** Both authors explicitly reject attributing motors and sensors’ value to the patent.
::::
:::

:::problem[Question II.16]
How would the author of Passage A most likely respond to Passage B’s claim that an inexpensive module may support a highly valuable machine function?

- **(A)** Any benefit outside the module must be legally disregarded without examination.
- **(B)** The entire machine price should therefore replace all evidence from component prices.
- **(C)** The possibility matters, but royalty estimates must exclude unrelated machine value.
- **(D)** A standardized function’s value can be measured only by counting patent claims.
- **(E)** Machine connectivity is irrelevant to the usefulness of industrial equipment.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative reading: author reaction (Chapter 17)

1. **Conclusion.** A accepts that connectivity can add value while emphasizing disciplined attribution.
2. **Support.** A says module price is a starting point, not a perfect or unalterable conclusion.
3. **Prephrase.** Expect qualified acknowledgment with resistance to unrelated-value capture.
4. **Why (C) is right.** The answer preserves both components of A’s view and addresses B’s insight directly.
5. **Why the others fail.**
   - **(A)** Too categorical: A describes module price as an imperfect starting point open to comparison-based adjustment.
   - **(B)** It reverses A’s preference for using component price as a disciplined initial reference point.
   - **(D)** No reliance on claim counts appears in either text.
   - **(E)** A explicitly notes connectivity can make a machine more useful.

**Check:** A allows modifications to its benchmark but not automatic whole-machine credit.
::::
:::

:::problem[Question II.17]
In Passage B, the example of a module that is inexpensive because it is mass-produced is used chiefly to...

- **(A)** challenge the assumption that a component’s low price measures its standardized function’s value.
- **(B)** prove that the machine’s purchase price consists entirely of the module’s value.
- **(C)** show that mass production always makes a patent invalid.
- **(D)** demonstrate that component invoices are inaccurate records of what buyers paid.
- **(E)** establish that every buyer values connectivity equally.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative reading: function (Chapter 17)

1. **Conclusion.** B cautions against equating component cost with attributable function value.
2. **Support.** A low-priced module may enable valuable coordination of machine operations.
3. **Prephrase.** Identify an illustrative counterexample to mechanical component-based valuation.
4. **Why (A) is right.** It shows cost can be low even when benefits associated with the function are high.
5. **Why the others fail.**
   - **(B)** Overreach and expressly rejected elsewhere in B.
   - **(C)** Legal non sequitur: patent validity is not discussed.
   - **(D)** Wrong target: the critique concerns what the invoice price measures, not arithmetic accuracy.
   - **(E)** Passage B gives no reason to expect identical valuations among all buyers.

**Check:** The component’s invoice price need not equal the function’s incremental economic value.
::::
:::

:::problem[Question II.18]
What role do comparable licenses play in the authors’ approaches?

- **(A)** Only Passage A mentions comparables, while Passage B rejects them.
- **(B)** Both say prior license prices conclusively determine a new royalty regardless of functionality.
- **(C)** Both oppose comparables because past bargaining may contain strategic behavior.
- **(D)** Both consider comparable licenses relevant, though not automatically decisive.
- **(E)** Passage B treats comparable licenses as evidence that complete machines have no economic value.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative reading: agreement (Chapter 17)

1. **Conclusion.** Both texts propose comparisons as an evidentiary aid.
2. **Support.** A says relevant licenses can modify a module starting point; B lists comparables among multiple sources.
3. **Prephrase.** Identify shared limited evidentiary usefulness, not a conclusive formula.
4. **Why (D) is right.** The answer accurately locates the same evidence in two distinct valuation methods.
5. **Why the others fail.**
   - **(A)** Direct contradiction: Passage B expressly proposes investigating comparable licenses.
   - **(B)** Too strong: comparability and incremental benefit remain relevant.
   - **(C)** No such joint rejection occurs.
   - **(E)** Wrong inference: the discussion concerns attribution of invention value.

**Check:** Each mentions similar licensing transactions but also preserves additional considerations.
::::
:::

:::problem[Question II.19]
On which one of the following proposals would the two authors most likely reach the same initial judgment?

- **(A)** A proposal using a module price as an unchangeable maximum is necessarily ideal.
- **(B)** A proposal ignoring comparable licenses must always be forbidden.
- **(C)** A proposal maximizing the patent holder’s revenue is fair regardless of invention value.
- **(D)** A proposal using a single fixed rate for every industrial machine must be accepted.
- **(E)** Unadjusted whole-machine pricing lacks adequate attribution to the patented feature.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative reading: inference (Chapter 17)

1. **Conclusion.** Both reject giving a patented function credit for all unrelated machine value.
2. **Support.** A calls full product base risky; B says unadjusted complete price invites overreach.
3. **Prephrase.** Choose a narrow joint objection rather than inferring their final dollar numbers.
4. **Why (E) is right.** Both have specific reasons to criticize unadjusted total-device attribution.
5. **Why the others fail.**
   - **(A)** B rejects a mechanical module ceiling, and A calls it a starting point.
   - **(B)** Too strong: they see comparables as useful, not universally necessary.
   - **(C)** Contradicts both authors’ focus on contribution.
   - **(D)** Unsupported automatic formula without valuation evidence.

**Check:** The lack of patented-contribution inquiry violates both authors’ methodological concerns.
::::
:::

:::problem[Question II.20]
Which one of the following best describes the relationship between the passages?

- **(A)** Passage A argues that FRAND promises are unenforceable, whereas B argues they are binding.
- **(B)** A favors a component-based starting point; B opposes privileging component price.
- **(C)** A recounts historical negotiations without evaluating them, while B presents a chronological history.
- **(D)** A argues for prohibiting licenses while B supports royalty-free standardized technology.
- **(E)** A discusses only machine design, while B discusses only semiconductor fabrication.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative reading: relationship / structure (Chapter 17)

1. **Conclusion.** The passages propose different valuation priorities within a common goal of attribution.
2. **Support.** A anchors in component price; B emphasizes system-level incremental function value.
3. **Prephrase.** Capture the narrower-versus-broader methodological tension, not an imaginary legal dispute.
4. **Why (B) is right.** The answer contrasts the authors’ strongest claims while preserving shared caution about unrelated value.
5. **Why the others fail.**
   - **(A)** Invented legal contest: enforcement is not their disagreement.
   - **(C)** Wrong organization: both present normative valuation arguments.
   - **(D)** Neither adopts a no-license or zero-royalty position.
   - **(E)** Both concern valuation of the same standardized communication feature.

**Check:** A: disciplined benchmark; B: benchmark may understate and should not dictate outcome.
::::
:::

### Passage 4

The question of whether automation eliminates jobs is often framed as a prediction about occupations: will an inspector still be employed when a vision system can identify defective components? Labor economists studying a hypothetical electronics plant instead begin with tasks. A quality inspector may watch images for anomalies, investigate why a defect occurred, document patterns, and negotiate with technicians about when production should stop. Automating one activity does not necessarily automate the others. The effects on employment depend partly on how the tasks fit together, not merely on whether software performs one task faster than a person does.

Consider a plant that introduces automated image screening. Under its old arrangement, human inspectors reviewed every image and referred suspicious ones to engineers. Under the new arrangement, software flags possible defects and inspectors devote more time to investigating ambiguous cases. Initially, each inspector can handle a greater volume of products. Managers might respond by keeping the same number of inspectors and increasing production, or by shrinking the inspection staff while maintaining output. Productivity alone therefore cannot determine the effect on head count. It describes a new production possibility, not the manager’s choice among possible uses of it.

A second complication concerns experience. Routine inspection can be tedious, but it may also teach novices which visual patterns matter. If software handles all ordinary cases, newly hired inspectors might encounter only unusual failures without first learning the baseline. The plant could then suffer a shortage of experienced troubleshooters despite having an abundance of screening capacity. Alternatively, carefully designed training software could expose novices to representative cases more efficiently than the old production line did. What matters is whether the organization replaces the learning opportunity removed with the automated task; the technology does not dictate the answer by itself.

Some researchers would measure automation’s effects by comparing employment before and after installation. That approach is vulnerable to other changes occurring at the same time: demand might rise, product design might simplify, or production might move to another site. A more informative study would compare similar plants facing different adoption schedules while examining output, staffing, wages, training, and the composition of work. Even then, the study would need to consider whether plants adopt automation in response to expected changes in demand. Such selection could make adopters and nonadopters different before installation.

The task-level view does not imply that automation is harmless. Displacement can be substantial when firms use productivity gains chiefly to reduce labor costs, or when remaining tasks require skills that displaced workers cannot readily acquire. It does imply that technology’s labor effects are mediated by business decisions, training institutions, and the relationship among tasks. A credible forecast should therefore ask which work is removed, which work becomes more valuable, and how organizations respond. Counting the tasks a machine can perform is only the beginning of the analysis.

:::problem[Question II.21]
Which one of the following most accurately states the main point of Passage 4?

- **(A)** Automation always increases staffing by creating new investigative duties.
- **(B)** An occupation is eliminated whenever software performs any of its tasks.
- **(C)** Task-level studies are impossible because adoption choices differ among firms.
- **(D)** The only meaningful outcome of automation is the number of images processed per hour.
- **(E)** Automation’s employment impact depends on tasks, management choices, and training arrangements.

::::solution[Solution]
**Answer:** (E)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The passage challenges direct extrapolation from machine capability to job loss.
2. **Support.** Examples concern residual tasks, manager choices, novice learning, and causal research design.
3. **Prephrase.** Look for a moderated task-and-institutions thesis that unites the passage.
4. **Why (E) is right.** The answer includes the key mediating mechanisms in the concluding paragraph.
5. **Why the others fail.**
   - **(A)** One possible response treated as guaranteed.
   - **(B)** The simplistic occupation-level view the passage rejects.
   - **(C)** The passage proposes more informative comparisons while acknowledging selection problems.
   - **(D)** Too narrow: wages, learning, staffing, and output are discussed.

**Check:** It covers all five paragraphs, not just the early screening example.
::::
:::

:::problem[Question II.22]
The description of managers either increasing production or reducing staffing after automated screening chiefly serves to...

- **(A)** prove that managers always favor production expansion over cost reduction.
- **(B)** show that productivity growth alone does not determine staffing levels.
- **(C)** establish that image-screening software cannot work accurately.
- **(D)** argue that inspection staff must be legally protected from layoffs.
- **(E)** show that output invariably falls when software screens images.

::::solution[Solution]
**Answer:** (B)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The example separates feasible production from managerial choice.
2. **Support.** More tasks can be completed per worker, but firms choose among several uses of the gain.
3. **Prephrase.** Identify why one technical result permits opposite staffing outcomes.
4. **Why (B) is right.** The two responses make the ambiguity concrete without assuming a particular choice.
5. **Why the others fail.**
   - **(A)** One possibility mistaken for certainty.
   - **(C)** Its functioning is accepted in the scenario.
   - **(D)** No legal prescription is made.
   - **(E)** Opposite: greater potential output is one possible result.

**Check:** Same productivity gain, different decisions, different employment levels.
::::
:::

:::problem[Question II.23]
Which one of the following is most strongly supported by the third paragraph?

- **(A)** Automated systems always teach novices more efficiently than human workplaces.
- **(B)** Routine cases are inherently more difficult than ambiguous failures.
- **(C)** Inspectors must personally examine every routine image to become competent.
- **(D)** Removing routine work without substitute training may impair novice expertise.
- **(E)** The plant has already recorded a shortage of troubleshooters.

::::solution[Solution]
**Answer:** (D)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The paragraph focuses on how automation changes routes to expertise.
2. **Support.** Routine inspection can teach baselines; the substitute training may or may not exist.
3. **Prephrase.** Infer a conditional risk rather than inevitable deskilling.
4. **Why (D) is right.** Without replacement, novices may face hard cases before acquiring pattern familiarity.
5. **Why the others fail.**
   - **(A)** The possibility of training software is presented as conditional.
   - **(B)** Reversal of the contrast: unusual cases are treated as complex.
   - **(C)** Overstrong necessity: the paragraph discusses alternative training methods.
   - **(E)** Hypothetical risk is not reported as an observed event.

**Check:** The paragraph expressly contrasts lost learning with the alternative of designed training.
::::
:::

:::problem[Question II.24]
According to the fourth paragraph, why might a comparison between plants that adopt automated inspection and those that do not be misleading?

- **(A)** Adopting plants may already anticipate demand changes that affect employment.
- **(B)** All plants necessarily implement identical automation systems.
- **(C)** The passage says automation cannot be studied unless managers are randomly assigned jobs.
- **(D)** Wage records are never available from manufacturing plants.
- **(E)** Studying output is prohibited when employment is the main outcome.

::::solution[Solution]
**Answer:** (A)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The question seeks the stated selection-bias problem.
2. **Support.** Expected demand may drive adoption and also outcomes, producing differences before installation.
3. **Prephrase.** Find a reason adopter and nonadopter groups may not be comparable.
4. **Why (A) is right.** The answer restates the passage’s explicit concern about endogenous timing and demand expectations.
5. **Why the others fail.**
   - **(B)** Opposite: differing practices motivate the call for careful comparison.
   - **(C)** Unsupported requirement: the suggested method is comparing similar plants with varying adoption times.
   - **(D)** No such data-availability claim is made.
   - **(E)** The paragraph calls for measuring both output and staffing.

**Check:** Prior differences can confound a before/after or adopters/nonadopters estimate.
::::
:::

:::problem[Question II.25]
Which one of the following can be most reasonably inferred from the passage?

- **(A)** Any observed staffing decline proves that the new software is defective.
- **(B)** A staffing decline necessarily entails a decline in plant output.
- **(C)** Staffing declines after automation cannot automatically be attributed entirely to it.
- **(D)** If demand rises, no plant will ever reduce inspection staffing.
- **(E)** Managers choose automation independently of all expected market conditions.

::::solution[Solution]
**Answer:** (C)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The passage warns against treating temporal association as isolated causal impact.
2. **Support.** Demand, product design, relocation, and adoption selection can also affect staffing.
3. **Prephrase.** Draw the modest causal-inference caution without denying possible displacement.
4. **Why (C) is right.** The staffing decline could have additional causes; the passage supplies several.
5. **Why the others fail.**
   - **(A)** No link from layoffs to technical quality is provided.
   - **(B)** Productivity improvements can sustain output with fewer workers.
   - **(D)** Unwarranted universal prediction about managerial responses.
   - **(E)** Contradicts the stated concern about adoption selection.

**Check:** Before/after change is not sufficient to isolate automation’s contribution.
::::
:::

:::problem[Question II.26]
Which one of the following developments best illustrates the passage’s task-level approach?

- **(A)** A firm announces that because some code can be generated automatically, every software engineer position will disappear.
- **(B)** A company installs software and assumes any later change in profits was caused entirely by installation.
- **(C)** Code-review software flags formatting issues; reviewers handle complex bugs; staffing remains a separate decision.
- **(D)** A manager counts all generated lines of code as proof that employees learned no skills.
- **(E)** A training department refuses to observe employees’ tasks before selecting tools.

::::solution[Solution]
**Answer:** (C)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The account replaces specific tasks while retaining other work and organizational decisions.
2. **Support.** Screening can automate routine identification while leaving investigation and staffing choices separate.
3. **Prephrase.** Match task decomposition and mediation, not a total occupation prediction.
4. **Why (C) is right.** Formatting checks and complex logic review reproduce the same substitution-complement pattern.
5. **Why the others fail.**
   - **(A)** The unexamined occupation-level prediction the author opposes.
   - **(B)** Repeats the causal-inference error the research paragraph warns about.
   - **(D)** Conflates output with a separate unmeasured training outcome.
   - **(E)** Opposes the analysis of task complements and substitutions.

**Check:** One task is automated, remaining expertise and management choices determine broader effects.
::::
:::

:::problem[Question II.27]
Which one of the following best characterizes the author’s attitude toward forecasts of automation-driven job loss?

- **(A)** Unreservedly optimistic because automation cannot displace workers.
- **(B)** Entirely pessimistic because every automated task necessarily destroys a position.
- **(C)** Dismissive of evidence because staffing outcomes depend on unpredictable choices.
- **(D)** cautious and conditional, emphasizing tasks, organizational decisions, and confounding factors.
- **(E)** Convinced that employee training is irrelevant to automation outcomes.

::::solution[Solution]
**Answer:** (D)

**Type:** Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author neither dismisses displacement nor treats it as automatic.
2. **Support.** Conditional scenarios and methodological cautions qualify predictions.
3. **Prephrase.** Select a measured, research-oriented stance consistent with the final concession.
4. **Why (D) is right.** The answer preserves the warning of harm and demand for causal, task-level evidence.
5. **Why the others fail.**
   - **(A)** Explicitly contradicted by the final paragraph acknowledging substantial displacement.
   - **(B)** The author rejects any inevitable transition from automating one task to eliminating an occupation.
   - **(C)** The passage outlines a more informative empirical approach.
   - **(E)** Contradicts the third paragraph’s emphasis on training pathways.

**Check:** The final paragraph explicitly states displacement can be substantial while resisting deterministic forecasts.
::::
:::

## 37.3 Section III: Logical Reasoning

:::problem[Question III.1]
A city plans to pay its electronics recycler according to the total mass of devices collected, rather than the quantity of materials safely recovered. A policy analyst predicts that this incentive will increase collection but not necessarily increase valuable recovered material. She notes that heavy equipment with little recoverable metal may be cheaper to collect than small devices rich in valuable metals. City officials respond that a ton collected is always a ton diverted from household trash, so the proposed payment method will be successful.

Which one of the following, if true, most strengthens the analyst’s prediction?

- **(A)** The city paid for collecting devices under its previous contract.
- **(B)** Some residents want convenient collection sites.
- **(C)** Several recovered metals have high resale prices.
- **(D)** A mass-based trial increased collected weight while lowering usable recovery rates.
- **(E)** The recycler owns trucks capable of carrying very heavy devices.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Mass-based payment can boost collection without corresponding usable recovery.
2. **Support.** Mass and value or ease of recycling can diverge across devices.
3. **Prephrase.** Find a trial where high collected mass coexists with weak recovery performance.
4. **Why (D) is right.** Observed sorting toward heavy low-recovery devices supports the hypothesized incentive effect.
5. **Why the others fail.**
   - **(A)** Background alone supplies no effect of the new mass incentive.
   - **(B)** Demand preferences do not link the incentive to poorer material recovery.
   - **(C)** Value of materials by itself does not show what the collector chooses.
   - **(E)** Capacity makes collection possible, not evidence that incentives distort recovery.

**Check:** Mass collected and usable output diverge in the predicted direction.
::::
:::

:::problem[Question III.2]
A technology executive tells investors that her firm has twice as many issued patents as a competitor, so the firm must control twice as many commercially valuable inventions. She points out that each issued patent is a separate legal document and that her firm spent more on filing fees. She has not compared the patents’ claims, their relevance to marketed devices, or the possibility that several patents address variants of one technical approach. Investors are asked to accept the numerical comparison as direct proof of economic advantage.

The executive’s reasoning is flawed because it...

- **(A)** claims that patent applications cannot lead to issued patents.
- **(B)** equates the number of issued patents with the number of valuable inventions.
- **(C)** infers that higher filing costs guarantee a larger legal department.
- **(D)** denies that separate legal documents can concern related technical ideas.
- **(E)** assumes that the competitor owns no patents at all.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Twice as many patents implies twice as many valuable inventions.
2. **Support.** A legal document count is not a validated economic-value count.
3. **Prephrase.** Identify numerical proxy substitution, with duplicated or worthless coverage possible.
4. **Why (B) is right.** Patent claims can overlap in value and multiple filings may surround one innovation.
5. **Why the others fail.**
   - **(A)** No such claim appears; she discusses already issued patents.
   - **(C)** Company staffing is never asserted.
   - **(D)** The problem is that she overlooks this possibility, not that she denies the distinction openly.
   - **(E)** Contradicts the stated comparison of two positive portfolio sizes.

**Check:** No one-to-one ratio from documents to commercially valuable inventions is established.
::::
:::

:::problem[Question III.3]
At a fictional laboratory, everyone permitted to enter Bay Q has completed the chemical-safety course. Anyone who has completed the course but lacks a current respirator clearance is restricted to the observation gallery. No person restricted to the observation gallery may operate deposition equipment. Alia has permission to enter Bay Q and lacks a current respirator clearance. The laboratory has separate rooms with equipment unrelated to deposition, but no facts concern Alia’s access to those rooms.

Which one of the following must be true?

- **(A)** Alia may not operate deposition equipment.
- **(B)** Alia has never operated any equipment in her career.
- **(C)** Alia is forbidden to enter Bay Q.
- **(D)** Everyone who completed the safety course lacks respirator clearance.
- **(E)** Alia is restricted from using all equipment in the laboratory.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** Alia falls under the deposition-equipment prohibition.
2. **Support.** Bay Q permission implies training; training without clearance implies gallery restriction; gallery restriction implies no deposition.
3. **Prephrase.** Build the chain using both of Alia’s facts.
4. **Why (A) is right.** The conditional steps yield an explicit bar on operating deposition equipment.
5. **Why the others fail.**
   - **(B)** Too broad temporally and by equipment: current Bay Q restrictions do not address her past.
   - **(C)** Contradicts the premise granting her permission.
   - **(D)** Quantifier reversal: the condition applies only to people satisfying both traits.
   - **(E)** Wrong scope: the rule expressly concerns deposition equipment only.

**Check:** Bay Q -> trained; trained and no clearance -> gallery; gallery -> no deposition.
::::
:::

:::problem[Question III.4]
A firm’s compliance chief announces that requiring all external design discussions to occur through its monitored messaging portal will prevent employees from inadvertently disclosing confidential circuit schematics to outsiders. The portal warns users before they attach a file classified as confidential. The chief cites successful portal tests and concludes that accidental disclosures of such schematics will cease after the policy takes effect. The proposal does not include a way to prohibit or monitor face-to-face meetings or personal phone calls.

Which one of the following is an assumption on which the chief’s reasoning depends?

- **(A)** The portal detects every type of malware ever created.
- **(B)** Employees find the portal easier to use than email.
- **(C)** No employee ever intentionally discloses confidential information.
- **(D)** All outsiders have previously signed confidentiality agreements.
- **(E)** Employees will not inadvertently disclose schematics outside the monitored portal.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The portal policy will eliminate inadvertent schematic disclosure.
2. **Support.** Warnings operate only for files attached through the portal, not other channels.
3. **Prephrase.** Elimination requires preventing inadvertent leaks outside portal coverage.
4. **Why (E) is right.** Negate it: an employee inadvertently discloses a schematic by phone; portal warnings cannot stop that leak.
5. **Why the others fail.**
   - **(A)** Out of the causal path: malware detection is not the policy’s claimed mechanism.
   - **(B)** Convenience may affect adoption, but the conclusion does not require it if employees comply.
   - **(C)** Wrong category: the claim is about inadvertent disclosure, not intentional leaking.
   - **(D)** Unsupported and unnecessary to the particular prevention mechanism.

**Check:** A possible accidental off-portal disclosure defeats the prediction of zero such disclosures.
::::
:::

:::problem[Question III.5]
A university unit received far more password-reset phishing emails in October than in September. Its incident team nevertheless recorded fewer compromised accounts, even though the unit had more students and staff using its services in October. The email filtering threshold, account-reporting rules, and incident classification criteria remained unchanged. A staff member expects greater phishing volume to produce more compromises and asks what could explain the apparent reversal. The unit had introduced several authentication and training changes during the period.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The phishing emails in October contained more words on average.
- **(B)** October contained more days of student activity than September.
- **(C)** Phishing-resistant authentication makes stolen passwords insufficient for most account access.
- **(D)** The unit retained all email messages for a longer period in October.
- **(E)** Staff members used more cloud services during October.

::::solution[Solution]
**Answer:** (C)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** More phishing and more users coincided with fewer compromises.
2. **Support.** Filtering and reporting did not change, but authentication could affect attack success.
3. **Prephrase.** Find an intervention reducing the probability of compromise per attempt.
4. **Why (C) is right.** Stolen passwords cease to be enough, permitting compromise counts to fall despite more attempts.
5. **Why the others fail.**
   - **(A)** Message length does not explain success or failure of account takeover.
   - **(B)** Would tend to increase exposure, not explain the decrease.
   - **(D)** Retention policy does not directly explain fewer compromised accounts.
   - **(E)** Adds possible account exposure rather than limiting successful compromise.

**Check:** Attack volume times success rate can fall when success rate drops sharply.
::::
:::

:::problem[Question III.6]
A hardware firm’s strategist recommends shifting its next chip design from Foundry L to Foundry M. M quotes a lower price for each processed wafer, and the strategist estimates that this difference will lower manufacturing costs by 12 percent. The calculation assumes that an equal number of usable chips will emerge from a wafer at either foundry. The strategists' report contains only published wafer prices, not yield data, package rejection rates, or differences in the processing steps available at the two facilities.

Which one of the following, if true, most weakens the cost-saving prediction?

- **(A)** M is farther from the firm’s design office than L.
- **(B)** The two foundries use different labels for their process steps.
- **(C)** Lower yield makes M’s cost per usable chip higher despite its lower wafer quote.
- **(D)** L has historically charged more for some unrelated designs.
- **(E)** The strategist expects the product to sell well after launch.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The lower wafer quote will make manufacturing this design cheaper.
2. **Support.** The prediction assumes equivalent usable output per wafer.
3. **Prephrase.** Attack the hidden denominator: yield determines per-saleable-chip cost.
4. **Why (C) is right.** Inferior yield can more than consume the wafer-price saving, directly reversing the proposed economic ranking.
5. **Why the others fail.**
   - **(A)** Distance does not establish higher actual manufacturing cost without shipping or coordination evidence.
   - **(B)** Naming difference need not imply a cost disadvantage.
   - **(D)** Unrelated product mix does not establish cost for this specific design.
   - **(E)** Demand forecast does not repair the missing yield assumption.

**Check:** Cost per good die = wafer cost / good dies per wafer, subject to relevant costs.
::::
:::

:::problem[Question III.7]
A company negotiator argues that the firm should not demand the highest possible upfront payment in a cross-license. An aggressive cash demand could cause the other party to withhold rights to useful interface patents, forcing the firm to redesign products. The negotiator concedes that a larger payment would help this quarter’s balance sheet, but says that immediate cash is only one part of the exchange. For agreements linking multiple patent portfolios, management should value access rights and avoided engineering costs as well as money received.

Which one of the following most accurately states the argument’s main conclusion?

- **(A)** The firm should never seek any upfront cash payment.
- **(B)** The opposing party has already refused to license its interface patents.
- **(C)** Redesigning products is impossible whenever patents are unavailable.
- **(D)** Cross-licenses eliminate the need for patent lawyers.
- **(E)** Cross-license evaluations should consider access and avoided redesign costs alongside cash.

::::solution[Solution]
**Answer:** (E)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The firm needs a multidimensional valuation of a cross-license.
2. **Support.** Maximizing cash may forgo access and induce engineering redesign.
3. **Prephrase.** Select the final policy recommendation that the tradeoffs support.
4. **Why (E) is right.** The answer captures the intended comparison of three deal values, rather than a supporting scenario.
5. **Why the others fail.**
   - **(A)** Too strong: the negotiator rejects maximizing cash at the expense of the other terms.
   - **(B)** Hypothetical risk turned into an asserted completed action.
   - **(C)** Overstatement: redesign is described as costly, not impossible.
   - **(D)** Out of subject: the argument evaluates deal terms, not staffing.

**Check:** The final sentence states the central management directive.
::::
:::

:::problem[Question III.8]
A municipal transit agency wants to retain location logs from its fare-validation devices for ten years because some of the information may be useful for future fraud investigations. Its privacy officer proposes keeping identifiable logs only for the period needed to verify ordinary transactions and retaining older records only in a form that cannot be linked to riders, unless an active investigation requires specific identified records. Investigators object that destroying identifiable information might make unexpected future investigations more difficult.

Which one of the following principles, if accepted, most strongly supports the privacy officer’s proposal?

- **(A)** Information should be retained indefinitely whenever it could conceivably be useful.
- **(B)** Fraud investigations should be prohibited when they involve personal data.
- **(C)** All historical data should be destroyed as soon as collected.
- **(D)** Identifiable data should be retained only for demonstrated purposes, with specific justified exceptions.
- **(E)** An agency should choose whatever retention period minimizes storage cost.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The officer recommends limited identified retention with justified exceptions.
2. **Support.** A speculative future usefulness claim is weaker than demonstrated need.
3. **Prephrase.** Find a retention-minimization rule with room for case-specific exceptions.
4. **Why (D) is right.** The principle matches the purpose-based rule and the proposed investigation exception.
5. **Why the others fail.**
   - **(A)** Opposes the officer’s demonstrated-purpose threshold.
   - **(B)** Overstates the proposal; it permits specific investigative exceptions.
   - **(C)** Ignores ordinary transaction verification and nonidentifiable retention.
   - **(E)** Wrong value: the officer balances identifiability and need, not just storage expense.

**Check:** It supports both a shorter default period and targeted preservation.
::::
:::

:::problem[Question III.9]
A manufacturer compared a new router with its older model. Just 1 percent of new routers had been returned for faults at the end of their first month on sale, whereas 4 percent of old routers had been returned over the old model’s first full year. The product manager concluded that the new model is more reliable and ordered the older design discontinued. The report contains no information about how returns accumulate over time for either model.

Which one of the following must the manager assume for the comparison to support the conclusion?

- **(A)** The new routers will never fail after the first month.
- **(B)** Unequal observation periods do not explain the lower new-model return rate.
- **(C)** Every customer who buys a router returns it immediately upon any minor problem.
- **(D)** The older model cost more to manufacture than the newer one.
- **(E)** The warranty period for all electronic devices is exactly one year.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** New model’s lower observed return rate indicates higher reliability.
2. **Support.** Rates were observed for one month versus a year.
3. **Prephrase.** The observation-window disparity must not explain the rate difference.
4. **Why (B) is right.** Negating this permits the new model’s later returns to erase the claimed advantage.
5. **Why the others fail.**
   - **(A)** Much stronger than needed: later failures could occur without reversing a fair reliability comparison.
   - **(C)** This universal return-behavior claim is unnecessary to make observation windows comparable.
   - **(D)** Cost cannot repair an unequal observation-window comparison.
   - **(E)** External generalization and irrelevant to relative observed reliability.

**Check:** Without comparable exposure time, low early returns do not establish superior yearlong reliability.
::::
:::

:::problem[Question III.10]
A router vendor measured average latency for a pilot customer’s network before and after an optimization patch. The average latency fell, and the vendor concluded that the patch improved latency for almost every type of client workload. But during the trial the customer added large numbers of short, low-latency control messages while the volume of complex analytics requests remained almost unchanged. The vendor reported only the pooled average across all requests, not results within each workload category.

The argument is most vulnerable to criticism because it...

- **(A)** infers improvements across workload categories from a pooled average affected by changing workload mix.
- **(B)** assumes that the patch altered the size of the physical router.
- **(C)** concludes that the vendor has more clients than its competitors.
- **(D)** relies on evidence that individual requests all became faster.
- **(E)** states that low-latency messages cannot coexist with analytics requests.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The patch helped nearly every workload category.
2. **Support.** Only a mixture-level average improved while the mixture composition changed.
3. **Prephrase.** Spot composition and confounding by category frequency.
4. **Why (A) is right.** More fast requests could lower the pooled average even if neither category improves.
5. **Why the others fail.**
   - **(B)** The vendor never makes any assertion about the physical size of its router hardware.
   - **(C)** The argument concerns latency, not market share.
   - **(D)** That stronger evidence is precisely what the vendor lacks.
   - **(E)** Opposite of the premise: both categories are present.

**Check:** Compare within-category before/after numbers to avoid the mixed-denominator trap.
::::
:::

:::problem[Question III.11]
An operations officer supports replacing passwords with hardware keys for administrator access. She concedes that the keys are more expensive to issue and replace than passwords. But she argues that the cost of a single serious unauthorized login can be far greater than the distribution budget, and that recent incidents involved passwords obtained through deceptive messages. Because the alternative authentication method would address that attack route, she concludes that the additional expense is justified for privileged users.

The operations officer’s reasoning proceeds primarily by...

- **(A)** claiming the hardware keys have no procurement expense.
- **(B)** acknowledging extra cost and then arguing that reduced security risk justifies it.
- **(C)** inferring that every expensive control must be effective.
- **(D)** deducing from a formal definition that passwords are prohibited.
- **(E)** rejecting password use because its advocates are dishonest.

::::solution[Solution]
**Answer:** (B)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Hardware keys are worth the extra expense for administrators.
2. **Support.** A financial drawback is conceded; high-severity compromise risk may outweigh it.
3. **Prephrase.** Match concede-and-overcome structure rather than a categorical rule.
4. **Why (B) is right.** The officer compares costs and risk mitigation to defend her recommendation.
5. **Why the others fail.**
   - **(A)** Direct contradiction: she concedes additional expense.
   - **(C)** Wrong logical pattern: she identifies a specific attack route and corresponding control.
   - **(D)** No definitional or legal prohibition is offered.
   - **(E)** No ad hominem attack on advocates occurs.

**Check:** The opening concession remains true while the later consideration defeats its weight.
::::
:::

:::problem[Question III.12]
A security researcher proposes paying independent analysts for responsibly reported bugs in a consumer router. The manufacturer’s managers fear that a public reward will advertise weaknesses to attackers and create more risk than it eliminates. The researcher replies that outsiders already have incentives to search for flaws, whereas a reward can channel some discoveries toward a confidential report and a repair before the information spreads. The managers ask for evidence that the proposed reporting channel would actually change behavior.

Which one of the following, if true, most strengthens the researcher’s case?

- **(A)** The manufacturer already promises to acknowledge vulnerability emails within one business day.
- **(B)** Some routers have no known vulnerabilities at release.
- **(C)** The company already publishes marketing claims about security.
- **(D)** Researchers who would publish unpatched bugs instead reported them privately when offered rewards.
- **(E)** A different manufacturer received many invalid bug reports.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** A reward can redirect discovery toward private reporting and earlier repair.
2. **Support.** The disputed point is how analysts behave when disclosure incentives change.
3. **Prephrase.** Find a behavioral comparison with and without the reward.
4. **Why (D) is right.** Pilot evidence isolates the channel effect in the precise group likely to disclose publicly.
5. **Why the others fail.**
   - **(A)** An acknowledgment policy alone does not show that independent researchers will switch from public disclosure to confidential reporting.
   - **(B)** Absence of known vulnerabilities cannot show how discoverers respond.
   - **(C)** Marketing is not a substitute for evidence about disclosure incentives.
   - **(E)** Weak comparison: noise elsewhere does not explain behavior in the proposed program.

**Check:** Previously public reports becoming private verified reports directly supports the mechanism.
::::
:::

:::problem[Question III.13]
An economist reviewing a hypothetical patent-damages analysis says that revenue from an entire device cannot automatically be credited to one patented sensor function. She adds, however, that the complete device price can sometimes supply useful context when other evidence identifies how much value the sensor function contributes. A proposed report instead applies a fixed percentage to total device revenue without separating contributions from unrelated components. The economist concludes that the report’s royalty estimate needs better evidence of the function’s incremental value.

What role does the statement that the complete device price can sometimes supply useful context play in the economist’s argument?

- **(A)** It is the argument’s final conclusion that the submitted estimate is reliable.
- **(B)** It presents a fact the economist expressly denies.
- **(C)** It proves that all royalties must equal a fixed share of device revenue.
- **(D)** It identifies the report’s factual calculation error in adding revenue numbers.
- **(E)** It permits contextual use of device revenue without endorsing unsupported attribution.

::::solution[Solution]
**Answer:** (E)

**Type:** Role of statement (Chapter 11)

1. **Conclusion.** The report needs evidence linking the patented function to the royalty figure.
2. **Support.** Whole-device revenue is not automatically attributable, though it may inform a grounded analysis.
3. **Prephrase.** Identify the concession that narrows, rather than contradicts, the critique.
4. **Why (E) is right.** The statement allows price as background context while preserving the demand for apportionment.
5. **Why the others fail.**
   - **(A)** Opposite: the economist rejects the unsupported estimate.
   - **(B)** No denial: the economist affirms the qualified point.
   - **(C)** Too strong: the sentence permits context, not automatic attribution.
   - **(D)** Wrong target: the flaw is attribution, not arithmetic.

**Check:** The conclusion rejects automatic attribution, not any mention of whole-device price.
::::
:::

:::problem[Question III.14]
A fictional technology regulator classifies a supplier as a 'verified reporter' if the supplier submits complete vulnerability disclosures and agrees to a correction timetable. Every verified reporter may use the regulator’s expedited review process. Beacon Instruments has submitted complete disclosures and agreed to the timetable, but the regulator has not announced whether Beacon counts as a verified reporter. An advisor nevertheless argues that Beacon may use the expedited process, relying only on the two submitted requirements.

Which one of the following, if assumed, allows the advisor’s conclusion to be properly drawn?

- **(A)** Some verified reporters have submitted complete disclosures.
- **(B)** No supplier lacking complete disclosures is a verified reporter.
- **(C)** Every supplier satisfying those two disclosure requirements is a verified reporter.
- **(D)** Beacon would benefit financially from expedited review.
- **(E)** Every expedited review eventually leads to regulatory approval.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Beacon may use expedited review.
2. **Support.** Verified reporter -> eligible, and Beacon meets two facts but is not yet known verified.
3. **Prephrase.** Add two requirements -> verified status to finish modus ponens.
4. **Why (C) is right.** The assumed biconditional direction supplies verified status for Beacon; the existing rule grants review access.
5. **Why the others fail.**
   - **(A)** Existential rather than universal bridge; does not classify Beacon.
   - **(B)** Converse necessary condition does not establish that completing disclosures suffices.
   - **(D)** Motivation adds no legal eligibility link.
   - **(E)** Consequent after review, not a bridge to Beacon’s eligibility.

**Check:** Complete + timetable -> verified -> eligible.
::::
:::

:::problem[Question III.15]
A fictional consortium permits a member to transfer a license to a successor company only if the successor assumes all outstanding maintenance commitments. The contract separately says that transferring the license does not automatically transfer membership in the consortium. Redvale transferred its license to Northbank under a written agreement stating that Northbank assumed the maintenance commitments. The consortium accepted the license transfer but has not considered Northbank’s membership application. The documents do not specify whether Northbank will be admitted as a member.

Which one of the following is most strongly supported?

- **(A)** An accepted license transfer does not automatically establish consortium membership.
- **(B)** Northbank must already be a member because the license transfer was accepted.
- **(C)** Redvale’s transfer was invalid because Northbank was not a member when it signed.
- **(D)** Northbank’s application for membership is certain to be denied.
- **(E)** Every commitment Redvale ever made outside the license must be performed by Northbank.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The license transfer alone cannot prove Northbank’s membership.
2. **Support.** The contract separates transfer eligibility from consortium admission.
3. **Prephrase.** Use the stated distinction; do not infer membership from a valid transfer.
4. **Why (A) is right.** Acceptance of a transfer and undecided membership are fully compatible.
5. **Why the others fail.**
   - **(B)** Contradicts the explicit no-automatic-membership clause.
   - **(C)** Invented requirement: membership is not stated to be a transfer prerequisite.
   - **(D)** Future-decision leap: the consortium has not considered it.
   - **(E)** Overbroad: transfer concerns maintenance obligations, not all independent duties.

**Check:** A transfer satisfying maintenance assumptions is not an automatic admission.
::::
:::

:::problem[Question III.16]
A chip assembler observed that every unit passing its final functional test also passed a brief power-on test. The operations manager argues that the power-on test is therefore enough to guarantee that a unit will pass the final functional test. She plans to omit the longer test on future batches. The quality team notes that a device can power on while still having intermittent interface errors discovered only by prolonged testing. The manager answers that the historic correlation is too strong to ignore.

The manager’s reasoning is flawed because it...

- **(A)** assumes that the longer test is always cheaper than the shorter test.
- **(B)** infers that any unit failing to power on would still pass final testing.
- **(C)** concludes that every component in an assembled unit was manufactured domestically.
- **(D)** bases a prediction on a sample selected by geography.
- **(E)** reverses the implication from passing the final test to passing power-on screening.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Passing brief power-on guarantees passing full functional testing.
2. **Support.** The evidence is full pass -> power-on pass, not power-on pass -> full pass.
3. **Prephrase.** Identify affirming the consequent: a necessary indicator is treated as sufficient.
4. **Why (E) is right.** A power-on unit might fail longer interface testing even though every final passer powers on.
5. **Why the others fail.**
   - **(A)** No such cost premise; she wishes to omit the longer procedure.
   - **(B)** Not asserted, and the contrapositive of her observed rule goes the other way.
   - **(C)** The validity of the power-on inference has nothing to do with component manufacturing origins.
   - **(D)** No geographic sampling feature appears.

**Check:** Final -> power-on does not imply power-on -> final.
::::
:::

:::problem[Question III.17]
Every device admitted to a high-security lab is registered. No registered device without a current patch certificate can access the lab’s internal network. The analyst notices that a particular admitted device has no current patch certificate. Therefore the analyst concludes that this device cannot access the lab’s internal network. No rule says that every registered device is admitted; the argument does not need that converse.

Which one of the following is most similar in its logical structure?

- **(A)** All licensed couriers passed checks; no checked courier lacking a permit may enter; Mira is licensed without a permit, so she cannot enter.
- **(B)** All members have identification cards. Jules has a card, so Jules must be a member.
- **(C)** No candidate may compete without paying a fee. Kim paid the fee, so Kim may compete.
- **(D)** All guides know the route. Some guides have radios, so some people with radios know the route.
- **(E)** Only approved vendors may sell equipment. Some vendors were approved; hence all sellers are vendors.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** This admitted device lacks the certificate and thus cannot access the network.
2. **Support.** Admitted -> registered; registered and no certificate -> no network.
3. **Prephrase.** Match nested membership plus a negative condition excluding the action.
4. **Why (A) is right.** Licensed -> checked, and checked without permit -> no entry, matching the original two-stage restriction.
5. **Why the others fail.**
   - **(B)** Converse error rather than chain with missing permission.
   - **(C)** Necessary treated as sufficient, with no second restriction.
   - **(D)** Existential conclusion with a nonmatching premise.
   - **(E)** Quantifier and category mismatch; no individually identified actor lacks a condition.

**Check:** Substitute licensed/admitted, checked/registered, permit/certificate, and depot/network.
::::
:::

:::problem[Question III.18]
A medical-equipment maker proposes deploying a major encryption-firmware update to every installed pump on the same day. Its security director claims that this is safer than staged deployment because it minimizes the time during which different software versions coexist. Field engineers warn that the update also changes a device-driver interface, but the director assumes tests in the company laboratory establish that the update will work on all pumps. Several hospitals still operate older pump revisions whose controllers were not included in the laboratory tests.

Which one of the following, if true, most seriously weakens the director’s recommendation?

- **(A)** Some pump operators prefer receiving updates on weekends.
- **(B)** The company has issued security patches in earlier years.
- **(C)** The new driver interrupts dosage monitoring on untested older pumps during simultaneous deployment.
- **(D)** The encryption used by the new firmware is stronger against certain attacks.
- **(E)** The laboratory used a large sample of the newest pump revision.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Same-day deployment is safer because versions coexist for less time.
2. **Support.** The lab tests omit older hardware, and rollout also alters device drivers.
3. **Prephrase.** Find a catastrophic risk of simultaneous deployment uniquely concentrated by the schedule.
4. **Why (C) is right.** Older-revision malfunction makes phased detection far safer than exposing all installed devices at once.
5. **Why the others fail.**
   - **(A)** Preference concerns scheduling, not the clinical risk of simultaneous rollout.
   - **(B)** History alone does not address untested controller compatibility.
   - **(D)** Supports a benefit of updating but not its all-at-once timing.
   - **(E)** Sample size within one revision does not cover missing older revisions.

**Check:** An update can improve encryption yet make an untested device fail operationally.
::::
:::

:::problem[Question III.19]
A company deposits sensitive chip-layout source files with a neutral escrow service so that a customer can gain access if the supplier permanently stops maintaining the product. Its lawyer predicts that the deposit will protect customers without making the trade secret public, because the service promises to release files only after verified termination of support. The lawyer has read the release trigger but has not examined the service’s storage controls or the access privileges granted to employees.

Which one of the following assumptions is required by the lawyer’s prediction?

- **(A)** The service’s employees have never had access to a trade secret before.
- **(B)** The escrow service will not publicly expose stored files outside the authorized release process.
- **(C)** The customer will never need the source files.
- **(D)** The supplier is legally required to maintain the product forever.
- **(E)** All source files deposited at any escrow service are commercially worthless.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The deposit preserves secrecy while allowing specified contingency access.
2. **Support.** A release trigger controls authorized release, not leakage through insecure storage or staff.
3. **Prephrase.** The secrecy claim requires absence of alternative publication paths.
4. **Why (B) is right.** If a service employee may publish stored files, the trigger can be honored while secrecy fails.
5. **Why the others fail.**
   - **(A)** Historical staffing experience is not necessary to prevent public disclosure.
   - **(C)** Opposite of the escrow’s contingency purpose; access may be needed upon termination.
   - **(D)** Would remove the need for a termination-release arrangement.
   - **(E)** Contrary to the concern with public exposure; unrelated universal claim.

**Check:** Negate no-public-leak-outside-trigger: the lawyer’s secrecy prediction collapses.
::::
:::

:::problem[Question III.20]
Counsel Chen: A proposed settlement should require the rival to publish enough interface information for independent repair tools. That condition would make the settlement valuable even if the cash payment is modest, and we can still preserve confidential manufacturing details. Engineer Bell: Publishing repair-interface details would indeed help independent repairers, and sensitive manufacturing details could be withheld. But the settlement should not require publication: the rival may reject the entire deal, and reliable repair access can instead be supplied through a controlled compatibility service.

Chen and Bell most clearly disagree over whether...

- **(A)** publication would help independent repairers.
- **(B)** confidential manufacturing details can be withheld.
- **(C)** a modest cash payment can have some value.
- **(D)** the settlement should require publication of repair-interface information.
- **(E)** controlled compatibility services are technically feasible.

::::solution[Solution]
**Answer:** (D)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Chen favors compulsory publication; Bell opposes that provision.
2. **Support.** Both agree on benefits but differ about settlement structure and negotiation risk.
3. **Prephrase.** Use the both-have-a-position test on the exact term.
4. **Why (D) is right.** Chen says require publication; Bell says do not require it.
5. **Why the others fail.**
   - **(A)** Both speakers explicitly agree that publishing the interface details would help independent repairers.
   - **(B)** Both accept a distinction between interface information and sensitive production details.
   - **(C)** Only Chen discusses valuation of cash; Bell has no stated contrary view.
   - **(E)** Bell favors one, but Chen never states a position about feasibility.

**Check:** Explicit yes/no on including a publication duty in the settlement.
::::
:::

:::problem[Question III.21]
A fictional repair association has the following rules: any shop certified for battery welding is authorized to replace battery tabs; every shop authorized to replace battery tabs must document its welding procedure; no shop lacking calibrated measurement equipment may document a welding procedure. Foxglove Repair is certified for battery welding. The association has no rule requiring a shop to manufacture its own batteries, and its records do not state whether Foxglove performs work for other shops.

Which one of the following must be true?

- **(A)** Foxglove Repair has calibrated measurement equipment.
- **(B)** Foxglove Repair manufactures every battery it repairs.
- **(C)** Every shop with calibrated equipment is certified for battery welding.
- **(D)** Foxglove Repair performs work exclusively for other shops.
- **(E)** No uncertified shop is authorized to replace battery tabs.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** Foxglove must possess calibrated equipment.
2. **Support.** Certified -> authorized -> documented, and no equipment -> no documentation.
3. **Prephrase.** Use contraposition of the last rule and chain it to certification.
4. **Why (A) is right.** Documented procedure implies equipment; Foxglove’s certification requires documented procedure.
5. **Why the others fail.**
   - **(B)** Invented production requirement: certification is for welding, not manufacturing.
   - **(C)** Converse: equipment is required through the chain, not sufficient for certification.
   - **(D)** Certification provides no information about whether Foxglove serves individual customers or other shops.
   - **(E)** Wrong converse: authorization may have routes other than certification.

**Check:** Certified -> authorized -> documented -> calibrated.
::::
:::

:::problem[Question III.22]
A mid-size firm installed network segmentation that restricts communication between research machines and its billing systems. Six months later, a security adviser recommends expanding segmentation to contractors' laptops. An executive objects that attacks against contractors' credentials are uncommon and therefore cannot justify the expense. The adviser argues that even uncommon compromises may have consequences across systems when a compromised laptop can reach many internal resources. She wants to reduce the possible reach of a breach, not claim that segmentation stops credential theft.

Which one of the following, if true, most strengthens the adviser’s recommendation?

- **(A)** Contractor laptops already undergo antivirus checks when they first connect to the network.
- **(B)** Attackers prefer easy passwords to long ones.
- **(C)** The firm could purchase more laptops at a discount.
- **(D)** A compromised contractor laptop can reach systems that segmentation would isolate.
- **(E)** The company’s website advertises that it values security.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Expand segmentation to limit damage from occasional contractor compromise.
2. **Support.** Frequency is low but unconstrained access could magnify consequences.
3. **Prephrase.** Find proof that segmentation materially cuts lateral reach in the relevant pathway.
4. **Why (D) is right.** A test directly demonstrates the contained harm the adviser seeks to reduce.
5. **Why the others fail.**
   - **(A)** Entry-point scans do not measure how far an attacker could reach if a checked laptop is nevertheless compromised.
   - **(B)** May bear on credential theft rate, not segmentation’s containment mechanism.
   - **(C)** Procurement options are not evidence for reducing breach reach.
   - **(E)** Reputation statement does not identify a reachable system or control effect.

**Check:** Segmentation addresses consequences after compromise, not whether compromise occurs.
::::
:::

:::problem[Question III.23]
A public company announced a major patent cross-license at the same time it released a faster graphics processor. Its share price rose over the following two days. A commentator concluded that investors welcomed the cross-license and that the agreement caused the entire price increase. The commentator knew that analysts also revised their processor-sales forecasts after the performance announcement, but treated the two corporate events as a single positive signal without attempting to separate their effects.

The commentator’s argument is most vulnerable to criticism because it...

- **(A)** assumes that stock prices cannot change over two trading days.
- **(B)** argues that all cross-licenses are unprofitable.
- **(C)** attributes the price increase to the cross-license despite simultaneous processor news.
- **(D)** treats patent portfolios as identical to graphic processors.
- **(E)** concludes that there was no increase in processor sales forecasts.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The cross-license caused all of the share-price increase.
2. **Support.** A new product announcement and forecast revisions occurred at the same time.
3. **Prephrase.** Identify the overlooked competing cause, not a claim that stock markets are irrational.
4. **Why (C) is right.** The price increase is compatible with processor news contributing some or all of the gain.
5. **Why the others fail.**
   - **(A)** Opposite: the commentator relies on a price movement.
   - **(B)** No: the commentator says the particular agreement was welcomed.
   - **(D)** Topic confusion: patents and product sales are separate possible price drivers.
   - **(E)** Contradicts the admitted analyst revisions.

**Check:** A concurrent plausible price driver breaks single-cause attribution.
::::
:::

:::problem[Question III.24]
A contract manufacturer claims that its new soldering process is better because defects were fewer in this month’s output than in last month’s output. This month the factory produced only simple boards, whereas last month it assembled mostly boards with dense, difficult joints. The manager concludes that the new process caused the improvement and ignores the change in product complexity. No matched test on the same board type was conducted.

Which one of the following arguments contains a flaw most similar to the one above?

- **(A)** A machine produced equal numbers of defects in two identical trials, so the engineer concluded the new settings had not visibly improved measured defects.
- **(B)** A researcher observed a wider confidence interval from a smaller sample and warned against a precise estimate.
- **(C)** A manager assumed that completing a required safety class guaranteed a promotion.
- **(D)** A designer reported a component’s lower mass without claiming the design caused higher reliability.
- **(E)** A tutor credited a new teaching method for higher scores despite an easier exam.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** New process caused a fall in defects.
2. **Support.** The compared production batches differ in complexity as well as process.
3. **Prephrase.** Match before-and-after causation confounded by changing task difficulty.
4. **Why (E) is right.** Easier exam difficulty is an alternative reason for higher scores just as easier boards explain fewer defects.
5. **Why the others fail.**
   - **(A)** Comparable conditions and modest conclusion, unlike the original confound.
   - **(B)** Statistical caution rather than confounded causal attribution.
   - **(C)** Necessary/sufficient error, not comparison across changing cases.
   - **(D)** No causal claim, so no analogous unaddressed competing factor.

**Check:** Different case mix prevents isolating the purported treatment effect.
::::
:::

:::problem[Question III.25]
A patent owner considers an offer that would allow a rival to use a disputed manufacturing technique. Its counsel says the offer is preferable to pursuing an injunction because the royalties are predictable and the rival can begin paying immediately. The business team responds that the owner also sells products competing with the rival’s and fears that the new license would accelerate the rival’s market entry. The memo compares legal expenses and cash receipts but contains no analysis of how licensing would alter the owner’s own product sales.

Which one of the following questions would be most useful to answer in evaluating counsel’s recommendation?

- **(A)** How many attorneys work at the rival’s headquarters?
- **(B)** How much competing-product profit would licensing cost the patent owner?
- **(C)** Does the disputed technique have an interesting technical history?
- **(D)** Does the rival plan to advertise its newly licensed products heavily?
- **(E)** Are printed copies of the proposed license stored securely?

::::solution[Solution]
**Answer:** (B)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** Counsel predicts licensing is economically preferable to seeking an injunction.
2. **Support.** Predictable royalties are counted; lost competitive profit from enabling rival entry is omitted.
3. **Prephrase.** Ask for the unmeasured cost that can reverse the licensing-versus-litigation ranking.
4. **Why (B) is right.** A large lost profit would challenge counsel’s recommendation; little loss would support it.
5. **Why the others fail.**
   - **(A)** Personnel count does not measure lost sales or incremental royalties.
   - **(C)** Background interest does not affect the central omitted business cost.
   - **(D)** Advertising might affect sales but cannot quantify the decisive omitted effect on the patent owner’s own profits.
   - **(E)** Document custody matters administratively but not the omitted opportunity-cost comparison.

**Check:** Calculate net license benefit after subtracting profit cannibalization and compare alternatives.
::::
:::

## 37.4 Scoring and review

Count one point for each correct answer. Your **raw score is the number correct out of 77**. Because this original test has not been psychometrically equated with LSAC’s exams, no official 120–180 conversion is possible, and any scaled-score estimate would be misleading. Analyze raw accuracy separately for LR and RC, especially flagged questions and questions missed after blind review.

The following key is intentionally collapsed. Reveal it only after completing your untimed blind review.

:::answer[Answer]



**Section I**



| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | (C) | Main conclusion | Chapter 4 |
| I.2 | (A) | Weaken | Chapter 8 |
| I.3 | (E) | Must be true / inference | Chapter 10 |
| I.4 | (B) | Flaw | Chapter 9 |
| I.5 | (D) | Strengthen | Chapter 8 |
| I.6 | (B) | Necessary assumption | Chapter 7 |
| I.7 | (D) | Paradox / resolve | Chapter 13 |
| I.8 | (C) | Principle | Chapter 13 |
| I.9 | (A) | Flaw | Chapter 9 |
| I.10 | (E) | Strengthen | Chapter 8 |
| I.11 | (D) | Method of reasoning | Chapter 11 |
| I.12 | (B) | Sufficient assumption | Chapter 7 |
| I.13 | (A) | Most strongly supported | Chapter 10 |
| I.14 | (E) | Necessary assumption | Chapter 7 |
| I.15 | (C) | Weaken | Chapter 8 |
| I.16 | (E) | Parallel reasoning | Chapter 12 |
| I.17 | (C) | Flaw | Chapter 9 |
| I.18 | (B) | Role of statement | Chapter 11 |
| I.19 | (D) | Strengthen | Chapter 8 |
| I.20 | (A) | Point at issue | Chapter 11 |
| I.21 | (A) | Must be true / inference | Chapter 10 |
| I.22 | (E) | Flaw | Chapter 9 |
| I.23 | (D) | Parallel flaw | Chapter 12 |
| I.24 | (C) | Necessary assumption | Chapter 7 |
| I.25 | (B) | Evaluate | Chapter 8 |



**Section II**



| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | (B) | Main point / primary purpose | Chapter 18 |
| II.2 | (E) | Function / purpose of a part | Chapter 18 |
| II.3 | (A) | Inference | Chapter 18 |
| II.4 | (D) | Function / purpose of a part | Chapter 18 |
| II.5 | (C) | Author’s attitude / tone | Chapter 18 |
| II.6 | (D) | Analogy / application | Chapter 18 |
| II.7 | (C) | Detail / recognition | Chapter 18 |
| II.8 | (B) | Main point / primary purpose | Chapter 18 |
| II.9 | (E) | Detail / recognition | Chapter 18 |
| II.10 | (A) | Function / purpose of a part | Chapter 18 |
| II.11 | (A) | Inference | Chapter 18 |
| II.12 | (C) | Author’s attitude / tone | Chapter 18 |
| II.13 | (E) | Analogy / application | Chapter 18 |
| II.14 | (B) | Comparative reading: disagreement | Chapter 17 |
| II.15 | (D) | Comparative reading: agreement | Chapter 17 |
| II.16 | (C) | Comparative reading: author reaction | Chapter 17 |
| II.17 | (A) | Comparative reading: function | Chapter 17 |
| II.18 | (D) | Comparative reading: agreement | Chapter 17 |
| II.19 | (E) | Comparative reading: inference | Chapter 17 |
| II.20 | (B) | Comparative reading: relationship / structure | Chapter 17 |
| II.21 | (E) | Main point / primary purpose | Chapter 18 |
| II.22 | (B) | Function / purpose of a part | Chapter 18 |
| II.23 | (D) | Inference | Chapter 18 |
| II.24 | (A) | Detail / recognition | Chapter 18 |
| II.25 | (C) | Inference | Chapter 18 |
| II.26 | (C) | Analogy / application | Chapter 18 |
| II.27 | (D) | Author’s attitude / tone | Chapter 18 |



**Section III**



| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | (D) | Strengthen | Chapter 8 |
| III.2 | (B) | Flaw | Chapter 9 |
| III.3 | (A) | Must be true / inference | Chapter 10 |
| III.4 | (E) | Necessary assumption | Chapter 7 |
| III.5 | (C) | Paradox / resolve | Chapter 13 |
| III.6 | (C) | Weaken | Chapter 8 |
| III.7 | (E) | Main conclusion | Chapter 4 |
| III.8 | (D) | Principle | Chapter 13 |
| III.9 | (B) | Necessary assumption | Chapter 7 |
| III.10 | (A) | Flaw | Chapter 9 |
| III.11 | (B) | Method of reasoning | Chapter 11 |
| III.12 | (D) | Strengthen | Chapter 8 |
| III.13 | (E) | Role of statement | Chapter 11 |
| III.14 | (C) | Sufficient assumption | Chapter 7 |
| III.15 | (A) | Most strongly supported | Chapter 10 |
| III.16 | (E) | Flaw | Chapter 9 |
| III.17 | (A) | Parallel reasoning | Chapter 12 |
| III.18 | (C) | Weaken | Chapter 8 |
| III.19 | (B) | Necessary assumption | Chapter 7 |
| III.20 | (D) | Point at issue | Chapter 11 |
| III.21 | (A) | Must be true / inference | Chapter 10 |
| III.22 | (D) | Strengthen | Chapter 8 |
| III.23 | (C) | Flaw | Chapter 9 |
| III.24 | (E) | Parallel flaw | Chapter 12 |
| III.25 | (B) | Evaluate | Chapter 8 |

:::


**Review map**

| Question family | Review chapter | Focus |
| --- | --- | --- |
| Main conclusion / argument core | 4 | Separate conclusion from support and identify the gap |
| Necessary and sufficient assumption | 7 | Negation test versus conditional bridge |
| Strengthen, weaken, evaluate | 8 | Test competing explanations and missing evidence |
| Flaw | 9 (and 6) | Match the exact causal, conditional, sampling, or scope error |
| Must be true / most strongly supported | 10 | Contrapositives, quantifiers, and restrained inferences |
| Method / role / point at issue | 11 | Argument structure and two-speaker yes/no test |
| Parallel reasoning and parallel flaw | 12 | Match the logical form or the specific invalid move |
| Paradox and principle | 13 | Reconcile both facts or apply the correct general rule |
| Comparative RC | 17 | Map each author's thesis, agreements, and disagreements |
| Single-passage RC | 18 (and 15) | Main point, evidence, role, inference, attitude, application |

On review, state in your own words **why the credited answer is right and why each of the four other choices fails**. Revisit any answer you got right for the wrong reason. A narrow error log about *the trap that fooled you* is more useful than merely recording the question number.
