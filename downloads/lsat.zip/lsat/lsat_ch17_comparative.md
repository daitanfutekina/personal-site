---
title: "Comparative Reading"
source: "lsat_ch17_comparative.html"
---

Part III · Chapter 17

# Comparative Reading

One of your four RC passages is a pair: two shorter passages by different authors on a related topic. The questions are about the *relationship* between them — so your job shifts from "what does this say?" to "how do these two compare?"

**Est. study time:** 55–70 min — **Sections:** 4 — **Practice:** 16+ items

## Overview

In every Reading Comprehension section, one of the four passage sets is **Comparative Reading**: instead of a single long passage, you get *two shorter passages* — labeled A and B — written by different authors about a related topic. They typically agree on some points and disagree on others, and the questions focus on the **relationship** between them: where they agree, where they clash, how one author would respond to the other, and how their scopes or approaches differ. This is really the two-speaker skill from Point-at-Issue (Chapter 11.3) scaled up to two mini-essays — plus the structural reading of Chapter 15 applied twice.

:::callout-tip
Prerequisites

Chapter 15 (map each passage, track the author's view) applied to both A and B, and Chapter 11.3 (Point at Issue — finding what two parties agree/disagree about). Comparative Reading is the fusion of those two skills.
:::

:::callout-key
The one habit that makes Comparative Reading easy

After reading both passages, pause and **state each author's main point in one sentence, then articulate their relationship**: "A argues X; B argues Y; they agree on Z but disagree about W." If you can say that before looking at the questions, most of the set is answered. The mistake is diving into questions with only a vague sense of "they're both about coral" — you must know each thesis and how they relate.
:::

## 17.1 · Mapping two authors' positions

:::callout-intuition
Intuition first

Read passage A fully and pin its thesis *before* starting B — don't try to hold both in the air at once. Get A's main point and stance locked, then read B and pin *its* thesis. Only then do you compare. Trying to read them "together" produces a blur; reading them in sequence and summarizing each gives you two clean positions to relate.
:::

:::definition
**Definition 17.1 — The dual map.** For a comparative set, build a compact summary with three parts: **A's main point** (one sentence), **B's main point** (one sentence), and **the relationship** (agree on \_\_\_, disagree about \_\_\_, differ in scope/approach \_\_\_). Also note each author's *attitude* and whether one is broader/narrower or more/less committed than the other.
:::

### Common A–B relationships

| Relationship | What it looks like |
| --- | --- |
| Disagreement | A and B reach opposing conclusions on the same question. |
| Different scope | A discusses the general topic; B focuses on one narrow aspect (or a specific case). |
| Different approach | A is theoretical/abstract; B is practical/empirical — or A defends, B critiques. |
| Agreement with different emphasis | Both reach similar conclusions but stress different reasons or aspects. |
| General & example | A states a principle; B provides a concrete instance of it. |

:::example
Worked Example 17.1 — pin both, then relate

standard

**Passage A (excerpt):** "Zoos, whatever their intentions, confine wild animals for human viewing, and no amount of enrichment fully substitutes for a natural habitat. The practice is difficult to justify ethically."

**Passage B (excerpt):** "Modern accredited zoos fund vital conservation and breeding programs that have saved species from extinction. Whatever the discomfort of captivity, this contribution to preservation is a compelling justification."

**Task.** State each main point and the relationship.

A: zoos are ethically hard to justify because captivity can't replace natural habitat. B: zoos are justified by their crucial conservation contributions. Relationship: they disagree about whether zoos are justified — A says no, B says yes — while both acknowledge captivity involves some harm.

**How we get there.** Pin A first: thesis = zoos are ethically difficult to justify (anti). Pin B: thesis = zoos are justified by conservation (pro). Now relate: *opposing conclusions* on "are zoos justified?" — a disagreement. Note the shared ground: both concede captivity is not ideal ("no substitute for natural habitat"; "whatever the discomfort of captivity"). That agreement-amid-disagreement is exactly what comparative questions probe. **Teaching point:** the relationship (disagree on justification, agree captivity is imperfect) *is* the answer to most of the set.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reading both passages as one blur.** Pin A's thesis before starting B; keep the two positions distinct.
- **Assuming they must flatly disagree.** Sometimes they agree, differ only in scope, or relate as principle-and-example. Read the actual relationship.
- **Losing track of which passage said what.** Tag each claim A or B; questions will exploit any confusion between them.
:::

### Practice — 17.1

:::problem[Q1]{difficulty="easy"}
Should you read A and B simultaneously or in sequence, and why?

::::solution[Solution]
**In sequence** — pin A's thesis before reading B. Reading them at once blurs the two positions; sequential reading gives you two clean main points to compare.
::::
:::

:::problem[Q2]{difficulty="standard"}
Name three possible relationships between comparative passages besides flat disagreement.

::::solution[Solution]
E.g., **different scope** (general vs. narrow), **different approach** (theoretical vs. empirical, or defend vs. critique), **agreement with different emphasis**, or **principle-and-example**. Not every pair simply disagrees.
::::
:::

:::problem[Q3]{difficulty="standard"}
What three things belong in your "dual map"?

::::solution[Solution]
**A's main point, B's main point, and their relationship** (agree on \_\_\_, disagree about \_\_\_, differ in scope/approach). Plus each author's attitude if notable.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is it valuable to note when A is broader in scope than B (or vice versa)?

::::solution[Solution]
Because many comparative questions turn on **scope differences** — e.g., "A addresses the general phenomenon while B focuses on a single case," or "a claim in B is narrower than A's." Recognizing that one author speaks generally and the other specifically lets you correctly judge agreement/disagreement (they may not actually conflict if they're addressing different scopes) and answer relationship questions precisely.
::::
:::

## 17.2 · Points of agreement vs. disagreement

:::callout-intuition
Intuition first

The most common comparative questions ask: "both authors would agree that…" or "the authors would disagree about whether…". These are the Point-at-Issue two-part test (Chapter 11.3) applied to passages. For *agreement*, you need a claim **both** authors would endorse. For *disagreement*, you need a claim **one endorses and the other rejects** — and crucially, *both* must have a position on it. A claim only one author addresses can be neither a shared agreement nor a documented disagreement.
:::

:::definition
**Definition 17.2 — Agreement & disagreement in comparative sets.** An *agreement* answer is a claim both A and B would affirm (based on what each states). A *disagreement* answer is a claim one affirms and the other denies. Both require that **each author has a determinable position** on the claim; if the text gives no basis for one author's view, that claim can't be the answer.
:::

:::callout-key
The "both must have a stake" filter

For any candidate answer, ask two questions: "Does A's passage give me A's position on this?" and "Does B's passage give me B's position on this?" If either answer is "the passage doesn't say," eliminate it — you can't confirm agreement or disagreement without both positions. This single filter kills most trap answers, which typically rest on a point only one passage addresses.
:::

:::example
Worked Example 17.2 — agreement vs. disagreement

challenge

**Using the zoo passages from 17.1:** A says zoos are ethically hard to justify (captivity can't replace habitat); B says conservation justifies zoos (while granting captivity is uncomfortable).

**Q(i).** Both authors would most likely agree that…

Answer (i): captivity in zoos falls short of animals' natural habitat / involves some harm to the animals.

**Q(ii).** The authors would most likely disagree about whether…

Answer (ii): zoos are, on balance, ethically justified.

**How we get there.** For agreement (i): A explicitly says captivity is no substitute for natural habitat; B concedes "the discomfort of captivity." Both grant that captivity is imperfect/harmful — a genuine shared point. For disagreement (ii): A concludes zoos are hard to justify; B concludes they're justified — opposite positions on the same question, and both clearly hold one. Contrast a trap: "zoos fund conservation programs" — B asserts this, but A's passage never addresses conservation funding, so we can't call it an agreement *or* a disagreement (A has no stated position). The "both must have a stake" filter eliminates it. **Teaching point:** shared ground is often a conceded fact; the disagreement is usually the bottom-line conclusion.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking a claim only one author addresses.** Without both positions, it's neither agreement nor disagreement. Apply the "both must have a stake" filter.
- **Confusing "both mention it" with "both agree on it."** Two authors can discuss the same fact and draw opposite conclusions from it.
- **Overstating agreement.** They may agree on a narrow point (captivity is imperfect) while disagreeing on the conclusion (whether zoos are justified). Match the exact claim.
:::

### Practice — 17.2

:::problem[Q1]{difficulty="standard"}
State the "both must have a stake" filter and what it eliminates.

::::solution[Solution]
For any candidate, confirm **each passage gives that author's position** on the claim. It eliminates answers that rest on a point **only one passage addresses** — you can't establish agreement or disagreement without both positions.
::::
:::

:::problem[Q2]{difficulty="standard"}
A asserts "the policy raises costs"; B never discusses costs. Can "the policy raises costs" be a point of disagreement?

::::solution[Solution]
**No.** B has no stated position on costs, so there's nothing to disagree with. It fails the filter — a disagreement needs opposite positions from *both* authors.
::::
:::

:::problem[Q3]{difficulty="standard"}
Where in comparative passages does the point of *disagreement* usually lie, versus the point of agreement?

::::solution[Solution]
The **disagreement** is usually at the level of the authors' **bottom-line conclusions**; the **agreement** is often a **shared underlying fact or concession** they both accept but interpret differently. (As with the zoos: agree captivity is imperfect, disagree on whether zoos are justified.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why can two authors "agree" on a fact yet reach opposite conclusions, and how should you handle such a fact on an agreement question?

::::solution[Solution]
Because a single fact can support different overall judgments depending on what each author *weighs* against it (e.g., both accept captivity is imperfect, but B thinks conservation outweighs it while A doesn't). On an **agreement** question, such a shared fact is a valid answer *as the fact itself* ("captivity is imperfect") — but not as the conclusion. Match the answer to the shared *premise/fact*, not to either author's differing conclusion.
::::
:::

## 17.3 · "How would author A react to B?" questions

:::callout-intuition
Intuition first

The trickiest comparative questions ask you to *predict* one author's response to a specific claim from the other passage: "How would the author of Passage A most likely respond to the argument in Passage B that…?" You're extrapolating one author's stance onto a point from the other essay. The key is to answer **only from what A actually committed to** — apply A's stated principles and attitude to B's claim, without inventing new views for A.
:::

:::definition
**Definition 17.3 — Cross-passage response questions.** Questions asking how one author would react to a claim, argument, or example from the other passage. Method: (1) identify the specific claim from the other passage, (2) recall the responding author's *relevant stated positions and principles*, and (3) apply them to predict a reaction (agree, object, qualify) that's **grounded in the responding author's actual text** — never in speculation.
:::

:::example
Worked Example 17.3 — extrapolate from A's stated view

challenge

**Using the zoos passages:** A holds zoos are ethically hard to justify because captivity can't replace natural habitat. B argues conservation contributions justify zoos.

**Stem.** The author of Passage A would most likely respond to B's conservation argument by…

- **(A)** agreeing that zoos should be expanded.
- **(B)** claiming that natural habitats no longer exist.
- **(C)** conceding that conservation fully justifies keeping animals in captivity.
- **(D)** arguing that conservation benefits do not outweigh the ethical cost of confining animals in unnatural conditions.
- **(E)** denying that zoos contribute to conservation at all.

Answer: (D).

**How we get there.** Recall A's committed position: captivity in unnatural conditions is a serious ethical problem that "no amount of enrichment" fixes. Apply it to B's claim (conservation justifies zoos). A would most consistently respond that the conservation benefit *doesn't outweigh* the ethical cost A emphasized — (D). Check traps: (C) and (A) contradict A's stated view; (E) goes beyond A's text — A never denied zoos aid conservation, only that captivity is justifiable, so putting a factual denial in A's mouth is unsupported speculation; (B) invents a claim A never made. **Teaching point:** the answer must flow from A's *actual* commitments (the ethical-cost objection), not from a new position we imagine A might hold.
:::

:::callout-pitfall
Watch out for these mistakes

- **Inventing views for the author.** Predict only from what the author actually stated. If A never addressed a factual point, don't have A deny it.
- **Making the reaction too strong.** A measured author gives a measured objection; avoid answers that have them wildly agree or contemptuously dismiss beyond their tone.
- **Answering from the wrong author.** Track carefully *whose* reaction is being asked — A to B, or B to A. They're different questions.
:::

### Practice — 17.3

:::problem[Q1]{difficulty="standard"}
On a "how would A respond to B" question, what must the correct answer be grounded in?

::::solution[Solution]
**A's actual stated positions, principles, and attitude** — applied to B's claim. Never a new view invented for A; the response must follow from A's own text.
::::
:::

:::problem[Q2]{difficulty="standard"}
A emphasizes empirical evidence; B relies on an untested theoretical model. How would A likely respond to B's conclusion?

::::solution[Solution]
A would likely **question B's conclusion for lacking empirical support** — applying A's stated preference for evidence. The response flows from A's demonstrated methodological commitment, not from disagreement with the topic per se.
::::
:::

:::problem[Q3]{difficulty="challenge"}
Why is an answer that has author A deny a factual claim A never discussed usually wrong?

::::solution[Solution]
Because it **invents a position for A** that A's text doesn't support. Predictions must be extrapolated from A's *stated* commitments; attributing a brand-new factual denial to A is speculation beyond the passage — exactly the kind of unsupported step the credited-response principle forbids.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Author B concedes a drawback but argues benefits outweigh it. Author A stresses that same drawback as decisive. On "how would A react to B's cost-benefit claim," what's the shape of the right answer?

::::solution[Solution]
A would **agree the drawback is real but reject B's weighing** — arguing the drawback is too serious to be outweighed by the benefits B cites. The answer captures partial agreement (the drawback exists) plus the core disagreement (whether it's outweighed), matching A's stated emphasis that the drawback is decisive.
::::
:::

## 17.4 · Worked dual passage & drills

:::example
Comparative set — social science

**Passage A.** Remote work, its champions insist, is the future. Freed from commutes, employees report higher satisfaction, and companies save on office space. But these gains rest on a fragile assumption: that the informal, unplanned interactions of shared workspaces — the hallway conversations where ideas cross-pollinate — are dispensable. They are not. Innovation depends on serendipitous contact, and no scheduled video call reproduces it. Remote work may suit routine tasks, but organizations that abandon the office entirely will find their creative capacity quietly eroding.

**Passage B.** Critics of remote work warn that it kills the spontaneous collaboration on which innovation depends. This concern, though understandable, is overstated. Studies of distributed teams find that structured practices — regular virtual brainstorming, open digital channels, periodic in-person retreats — can generate collaboration equal to or greater than the accidental encounters of an office. The office's "serendipity" was always partly a myth; much of it was noise. What matters is not the office itself but whether an organization deliberately designs for collaboration.

#### The dual map

- **A's main point:** remote work threatens innovation because it loses the serendipitous, unplanned interactions that drive creativity; full remote erodes creative capacity.
- **B's main point:** the loss-of-serendipity worry is overstated — deliberately designed practices can match or beat office collaboration; what matters is intentional design, not the office.
- **Relationship:** they *disagree* about whether losing the office harms innovation. Both *agree* that collaboration/serendipitous interaction matters for innovation — but A thinks the office is necessary for it, while B thinks it can be engineered remotely. A values the office's informal contact; B calls much of it "noise."
:::

### Questions

:::problem[Q1]{difficulty="standard"}
Both authors would most likely agree that…

- **(A)** remote work has no benefits.
- **(B)** serendipitous encounters are largely noise.
- **(C)** that the office's serendipity was largely a myth.
- **(D)** the office should be abandoned entirely.
- **(E)** collaboration and interaction are important to innovation.

::::solution[Solution]
**(E).** A emphasizes serendipitous contact for innovation; B agrees collaboration drives innovation (and discusses how to produce it remotely). Both stake out that collaboration matters. (D),(A) neither holds; (B) is only B's view.
::::
:::

:::problem[Q2]{difficulty="standard"}
The authors would most likely disagree about whether…

- **(A)** abandoning the physical office would harm an organization's innovation.
- **(B)** companies save money on office space.
- **(C)** informal interaction contributes to innovation.
- **(D)** video calls exist.
- **(E)** employees dislike commuting.

::::solution[Solution]
**(A).** A says full remote erodes creative capacity; B says designed practices prevent that harm. Opposite positions on the same question. (E),(B) aren't points of conflict; (D) trivial.
::::
:::

:::problem[Q3]{difficulty="challenge"}
The author of Passage B would most likely respond to Passage A's claim about "serendipitous contact" by…

- **(A)** agreeing that no remote practice can reproduce it.
- **(B)** arguing that deliberately designed collaboration can substitute for it, and that its value was partly a myth.
- **(C)** insisting that remote work suits only routine tasks.
- **(D)** denying that innovation matters.
- **(E)** conceding that the office should never be abandoned.

::::solution[Solution]
**(B).** B explicitly holds that structured practices can match office collaboration and that office "serendipity" was "partly a myth." Applying B's stated view to A's claim yields (B). (A),(E) contradict B; (D) invents a view.
::::
:::

:::problem[Q4]{difficulty="standard"}
Which best describes the relationship between the two passages?

- **(A)** Passage B presents a specific case study that Passage A generalizes.
- **(B)** Both passages defend the same conclusion by different means.
- **(C)** Passage B rebuts a concern that Passage A advances.
- **(D)** The two passages address entirely unrelated topics.
- **(E)** Passage A agrees with and extends Passage B.

::::solution[Solution]
**(C).** A advances the loss-of-serendipity concern; B explicitly calls that concern "overstated" and rebuts it. B is a rebuttal of A's worry. (A),(D),(E) mischaracterize it.
::::
:::

:::problem[Q5]{difficulty="challenge"}
A point on which the passages differ is that, unlike Passage A, Passage B…

- **(A)** denies that companies save money remotely.
- **(B)** recommends abandoning the physical office entirely.
- **(C)** argues employees are less satisfied working from home.
- **(D)** claims that much of the office's serendipity was actually noise.
- **(E)** believes commuting is unpleasant.

::::solution[Solution]
**(D).** Only B characterizes office serendipity as "partly a myth"/"noise"; A treats it as genuinely valuable. That's a clear point of difference. The others aren't supported as B's distinctive claims.
::::
:::

:::problem[Q6]{difficulty="challenge"}
In one sentence, why is stating each passage's thesis and their relationship *before* the questions the key to this set?

::::solution[Solution]
Because nearly every comparative question (agreement, disagreement, cross-response, relationship) is answered directly from that three-part summary — A's thesis, B's thesis, and how they relate — so building it up front converts the whole question set into quick lookups rather than re-reading two passages per question.
::::
:::

## Chapter summary

:::summary
#### Comparative Reading, distilled

- **Read A, pin its thesis; then read B, pin its thesis;** only then compare. Don't blur them.
- **Build the dual map:** A's main point, B's main point, and the relationship (agree on \_\_\_, disagree about \_\_\_, differ in scope/approach).
- **Agreement/disagreement** = the Point-at-Issue two-part test: both authors must have a determinable position. Kill answers only one passage addresses.
- **Cross-response questions**: predict only from an author's *actual* stated views — never invent a position.
- **The disagreement is usually the conclusion; the agreement is often a shared fact** they interpret differently.
:::

LSAT Mastery — Chapter 17. Independent study material, not affiliated with LSAC. Practice passages and questions are original, written to illustrate the skills; use official LSAC PrepTests for timed practice.
