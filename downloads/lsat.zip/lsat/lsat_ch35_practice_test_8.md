---
title: "Practice Test 8"
source: "markdown"
---

Part VI · Chapter 35

# Practice Test 8

Original legal and engineering reasoning practice centered on technology, creative ownership, data, and evidence.

## Overview

Set a 35-minute timer for each section and complete all three scored sections in one sitting, with a 10-minute break after Section II. These 77 questions simulate the scored core; an actual LSAT also includes a fourth, unscored section. Do not open any solution until all sections are finished.

**Flag, don’t guess silently.** Record every question you were uncertain about, including guesses that felt plausible. After the timed test, blind-review those questions without a clock and without checking the key (Chapter 22). Only then score the test, explain every missed alternative, and log the underlying mistake (Chapter 23).

This is an original practice test written for this textbook, **not an official LSAC PrepTest**. Official timed practice on LawHub remains the gold standard for calibration (Chapter 24). No score conversion from this uncalibrated practice test should be treated as official.

## 35.1 Section I: Logical Reasoning

:::problem[Question I.1]

A cloud vendor began automatically issuing service credits after outages rather than requiring customers to submit claims. Six months later, fewer customers cancelled their contracts. The vendor’s director credits the new policy, arguing that customers who previously regarded the claims process as unfair now believe the vendor will address disruptions promptly. During the same six months, however, the vendor introduced several unrelated improvements to its service. The director wants to persuade the board that automatic credits, rather than those improvements, explain most of the decline in cancellations.

Which one of the following, if true, most strengthens the director’s argument?

- **(A)** The vendor advertised its new credit policy more prominently than its other improvements.
- **(B)** Among customers whose service reliability and price remained unchanged, cancellations fell substantially only for those who became eligible for automatic credits.
- **(C)** Customers generally dislike filling out claim forms, even when claims are approved.
- **(D)** The vendor issued more credits during those six months than during the preceding six months.
- **(E)** Customers who left the vendor cited price more often than reliability in exit interviews.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The director concludes that automatic credits, rather than simultaneous service improvements, caused most of the fall in cancellations.
2. **Support.** The decrease in cancellations followed a policy change, but several other service changes occurred at the same time.
3. **Prephrase.** Look for evidence that separates the effect of automatic credits from simultaneous improvements.
4. **Why (B) is right.** The controlled comparison holds the competing improvements constant while varying credit eligibility, directly supporting the proposed cause.
5. **Why the others fail.**
   - **(A)** Advertising intensity does not show whether credits rather than improvements caused retention.
   - **(C)** A general dislike supports plausibility but does not isolate the cause of the changed cancellation rate.
   - **(D)** More payouts could reflect more outages or more customers, not retention attributable to credits.
   - **(E)** The reasons departing customers gave do not establish why the number leaving declined.

**Check:** Hold reliability and price fixed: the drop tracks eligibility for automatic credits.
::::
:::

:::problem[Question I.2]

A software manager reports that developers who use an optional code-review assistant resolve more tickets per week than developers who do not use it. She concludes that requiring every developer to use the assistant will increase team productivity. Yet the tool was introduced on a volunteer basis, and the company’s fastest developers were also the first to try it. The manager dismisses this concern, saying that the observed difference is large enough to be meaningful and that the company cannot afford to delay a decision.

The manager’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** treats an increase in ticket counts as proof that customers were more satisfied.
- **(B)** presumes that the assistant must reduce the number of code defects in order to increase throughput.
- **(C)** assumes that the tool is cheaper than alternative software products.
- **(D)** draws a conclusion about every industry from data collected at a single company.
- **(E)** fails to consider that developers who would resolve more tickets anyway may be disproportionately represented among users of the assistant.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The manager concludes mandatory assistant use will increase developers’ ticket throughput; the issue is whether voluntary adoption proves causation.
2. **Support.** The observed association between voluntary use and ticket counts is treated as evidence that mandating use causes higher output.
3. **Prephrase.** Identify the selection effect rather than disputing the measurement or the product category.
4. **Why (E) is right.** Volunteer selection provides an alternative explanation: inherently faster developers may adopt the tool and produce more tickets regardless.
5. **Why the others fail.**
   - **(A)** The conclusion concerns productivity as ticket throughput, not customer satisfaction.
   - **(B)** The manager never claims reduced defects are required for higher ticket counts.
   - **(C)** No comparison of purchase prices forms part of the causal argument.
   - **(D)** The conclusion concerns this company’s developers, not every industry.

**Check:** Correlation remains if productivity drives adoption instead of adoption driving productivity.
::::
:::

:::problem[Question I.3]

A fictional compliance framework classifies a release as audit-ready only if its dependency inventory is complete. Any release with a complete dependency inventory is either reviewed by a security specialist or covered by an approved automated review, and never both. The platform team’s November release is classified as audit-ready. No automated review of the November release was approved, since the only one submitted used an outdated rule set. The team does not claim that audit-ready releases are necessarily free of vulnerabilities; the classification concerns documentation and review procedures rather than a guarantee of security.

Which one of the following must be true on the basis of the statements above?

- **(A)** The November release contains no vulnerabilities that a specialist would detect.
- **(B)** Every release reviewed by a specialist is classified as audit-ready.
- **(C)** The November release was reviewed by a security specialist.
- **(D)** The rejected automated review was the only automated review the company attempted in November.
- **(E)** A release with an incomplete inventory can nevertheless be audit-ready if a specialist reviews it.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** There is no argument to endorse: combine the compliance rules to determine the November release’s required review route.
2. **Support.** Apply both conditional rules to the identified release, then eliminate the disallowed alternative.
3. **Prephrase.** Chain audit-ready to inventory complete; use the either/or rule and the rejected automated route.
4. **Why (C) is right.** Audit-ready implies complete inventory; that implies exactly one approved review route. Automated review was rejected, so specialist review remains.
5. **Why the others fail.**
   - **(A)** Audit-ready status expressly does not guarantee absence of vulnerabilities.
   - **(B)** This reverses a necessary condition: specialist review does not guarantee audit readiness.
   - **(D)** Nothing states how many automated reviews were attempted.
   - **(E)** This directly contradicts the rule that audit readiness requires a complete dependency inventory.

**Check:** Audit-ready → complete inventory → specialist XOR approved automation; not approved automation → specialist.
::::
:::

:::problem[Question I.4]

A device manufacturer proposes enabling automatic rollback whenever a new firmware update produces a particular diagnostic warning. Its accountant predicts that the feature will lower warranty expenses because, in last year’s data, most warranty claims associated with failed updates came from devices that displayed that warning first. The proposed rollback will not affect shipping, component prices, or customer-service staffing. The accountant admits that enabling rollback will require a one-time engineering expense, but maintains that the savings in warranty claims will more than compensate for it.

Which one of the following is an assumption on which the accountant’s argument depends?

- **(A)** At least some warranty expenses associated with the warning would be avoided by the proposed rollback.
- **(B)** Every device that ever displays the warning eventually generates a warranty claim.
- **(C)** The manufacturer will stop releasing firmware updates after installing rollback.
- **(D)** Rollback will prevent every kind of hardware defect caused by firmware.
- **(E)** Customers value automatic rollback more than new firmware features.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The accountant predicts that rollback-related warranty savings will exceed its one-time engineering expense.
2. **Support.** The historical association of warnings with claims is used to predict financial savings from an intervention at the warning stage.
3. **Prephrase.** Negate a minimal necessary link between rollback and at least some avoided expenses.
4. **Why (A) is right.** If rollback avoids none of the relevant warranty costs, the claimed savings cannot offset the engineering expense.
5. **Why the others fail.**
   - **(B)** This is far stronger than necessary: many warning-bearing devices could recover without claims.
   - **(C)** Future updates need not stop for rollback to reduce claim expenses.
   - **(D)** The conclusion requires savings, not the elimination of all defects.
   - **(E)** Customer preferences are not needed for this financial comparison.

**Check:** Negate the answer: rollback avoids no warning-associated expenses; the alleged saving disappears.
::::
:::

:::problem[Question I.5]

A cloud company trained its on-call engineers to identify production incidents more quickly. The median time from a customer report to an engineer’s initial acknowledgment fell markedly after the training. Unexpectedly, the median duration of customer-visible incidents increased during the same period. Managers confirmed that monitoring equipment, the definition of an incident, and reporting procedures remained unchanged. They had anticipated that quicker acknowledgments would allow engineers to begin repairs sooner and therefore shorten incidents, so they asked analysts to explain the opposing trends.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Customers are more likely to report outages when the service is important to them.
- **(B)** The training reduced the time needed to read a monitoring alert.
- **(C)** The company received fewer customer complaints after training.
- **(D)** Following the training, engineers were required to acknowledge an incident immediately but wait for a separate specialist’s authorization before changing production systems, and authorization delays grew.
- **(E)** On-call staffing levels were unchanged throughout the period.

::::solution[Solution]
**Answer:** (D)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The apparently conflicting outcomes are quicker acknowledgments but longer customer-visible outages; the task is to reconcile them.
2. **Support.** Improved acknowledgment speed and worsened total incident duration are compatible if later repair steps become slower.
3. **Prephrase.** Separate the time to acknowledge from the time required to restore service.
4. **Why (D) is right.** The training speeds the first stage while an added or worsened authorization bottleneck delays the stage that ends incidents.
5. **Why the others fail.**
   - **(A)** This does not explain why incident duration grew after faster acknowledgments.
   - **(B)** This may explain faster acknowledgment but supplies no reason incidents last longer.
   - **(C)** Complaint volume does not explain why verified incident durations increased.
   - **(E)** Stable staffing rules out one confound but does not locate the new repair delay.

**Check:** Acknowledgment time falls while time awaiting authorization grows by more.
::::
:::

:::problem[Question I.6]

An engineering director acknowledges that permissively licensed components can save development time. She also accepts that reviewing license notices before shipment imposes some cost. Still, she argues, the company should require a documented license review for every software component incorporated into a distributed product. Without that review, the release team cannot reliably know which notice obligations apply. The expense of a predictable check is smaller than the disruption of discovering obligations only after products have been shipped. Her recommendation does not entail avoiding open-source software; it concerns a checkpoint in the release process.

Which one of the following most accurately expresses the argument’s main conclusion?

- **(A)** Permissively licensed components often save developers time.
- **(B)** The cost of checking licenses is less than the possible disruption of late discovery.
- **(C)** The company ought to conduct a documented license review before distributing products containing software components.
- **(D)** Companies should abandon all open-source components in shipped products.
- **(E)** License obligations can always be known with certainty before distribution.

::::solution[Solution]
**Answer:** (C)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The director’s main recommendation is to require a documented review of component licenses before distribution.
2. **Support.** Savings and risk comparisons are reasons offered in favor of a specific checkpoint.
3. **Prephrase.** Find the advocated policy, not a reason for it or an extreme alternative.
4. **Why (C) is right.** The normative claim that every distributed component should undergo documented review is what the other statements support.
5. **Why the others fail.**
   - **(A)** That is a concession establishing the value of components, not the director’s recommendation.
   - **(B)** This is a supporting comparison, not the action the director advocates.
   - **(D)** The argument explicitly distinguishes review from abandoning open source.
   - **(E)** The director argues for a reliable process, not guaranteed certainty.

**Check:** The conclusion is the “should require” sentence; cost and notice claims support it.
::::
:::

:::problem[Question I.7]

A product manager says a new privacy badge caused more visitors to subscribe to a note-taking app. Before the badge was displayed, 4 percent of visitors subscribed; afterward, 7 percent did. The manager argues that the badge reassures potential customers who are uncertain about the app’s practices. The subscription price and page layout were unchanged, and the team kept the same definition of 'visitor.' However, the app had also begun appearing in a newsletter aimed at professionals who routinely pay for software tools.

Which one of the following, if true, most seriously weakens the manager’s explanation?

- **(A)** Among visitors arriving through sources used both before and after the badge appeared, the subscription rate remained approximately 4 percent.
- **(B)** Many current subscribers say they appreciate privacy assurances.
- **(C)** The app’s privacy badge is printed in a small font.
- **(D)** The app offers a free trial to people who do not immediately subscribe.
- **(E)** Visitors typically spend under a minute reading the app’s page.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The manager claims the new privacy badge caused the increase in subscription conversions.
2. **Support.** Aggregate conversion rose as a new badge and a new acquisition channel arrived together.
3. **Prephrase.** Find a comparison separating the badge from the changed audience.
4. **Why (A) is right.** If conversion did not rise within comparable traffic sources, the overall increase can be explained by a shift to professional newsletter visitors.
5. **Why the others fail.**
   - **(B)** This supports a plausible badge mechanism but does not explain the time-series difference.
   - **(C)** Small type may reduce impact, but it does not directly account for the higher conversion rate.
   - **(D)** A standing trial option does not distinguish the before and after periods.
   - **(E)** Short visits do not show whether the badge was noticed or whether it affected subscription decisions.

**Check:** Within-source rates stay flat: compositional change can produce the aggregate increase.
::::
:::

:::problem[Question I.8]

A hosting provider discovers that a configuration error exposed a narrow category of customer files for several hours. Investigators cannot establish whether anyone downloaded the files. A manager proposes withholding notice until misuse is confirmed because an announcement could alarm customers unnecessarily. A colleague responds that customers need information to take precautions and that the uncertainty concerns whether harm occurred, not whether the exposure happened. The colleague seeks a principle that would justify notification without assuming that every possible exposure creates actual harm.

Which one of the following principles, if accepted, most strongly supports the colleague’s position?

- **(A)** A provider must disclose every internal configuration change, whether or not customers could be affected.
- **(B)** Customers should be notified only after investigators demonstrate that their files were actually misused.
- **(C)** Public statements should never be made while an investigation has unresolved questions.
- **(D)** Notification is appropriate whenever it improves the company’s public image.
- **(E)** When a verified event gives customers a material reason to take protective action, a provider should promptly disclose the event even if resulting misuse remains uncertain.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The colleague argues for notifying customers of verified exposure despite uncertainty about subsequent misuse.
2. **Support.** The colleague separates a known exposure from unknown downstream misuse and stresses customers’ ability to respond.
3. **Prephrase.** Choose a rule triggered by actionable risk rather than proved damage or corporate publicity.
4. **Why (E) is right.** The principle identifies established exposure plus a material opportunity for precaution, explicitly allowing uncertainty about misuse.
5. **Why the others fail.**
   - **(A)** This imposes disclosure for irrelevant changes and is stronger than the colleague’s customer-protection rationale.
   - **(B)** This endorses the manager’s threshold, rather than the colleague’s position.
   - **(C)** This would bar disclosure precisely because misuse is uncertain.
   - **(D)** Reputation is not the colleague’s reason; useful customer precautions are.

**Check:** Known exposure + actionable precautions → notice; certainty of misuse is not required.
::::
:::

:::problem[Question I.9]

A startup’s prototype was tested by forty employees of a single technology consultancy. Thirty-six said they would recommend it to their colleagues. The founder therefore predicts that at least 90 percent of employees across all industries would recommend the product after using it. The consultancy’s staff had volunteered for the test, and the product was designed around their workflow. The founder concedes that other organizations have different requirements but insists that thirty-six favorable responses are too many to dismiss as a coincidence.

The reasoning is most vulnerable to criticism because it...

- **(A)** assumes that every favorable recommendation guarantees a purchase.
- **(B)** generalizes from a small, self-selected group whose work is unusually close to the product’s intended design to workers in very different settings.
- **(C)** confuses the number of positive reviews with the total number of participants.
- **(D)** infers that the consultancy’s workers share identical preferences.
- **(E)** fails to establish that the prototype uses the latest available technology.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The founder projects the volunteer prototype testers’ high recommendation rate to employees in all industries.
2. **Support.** The founder treats one volunteer group with a matching workflow as representative of the workforce at large.
3. **Prephrase.** Name the sampling and generalization flaw, not a concern about purchase or product quality.
4. **Why (B) is right.** The sample is specially selected, so its 90-percent recommendation rate cannot simply be projected to all industries.
5. **Why the others fail.**
   - **(A)** The conclusion concerns willingness to recommend, not purchases.
   - **(C)** The fraction 36 out of 40 is understood correctly; representativeness is the issue.
   - **(D)** The premise reports differing responses, not uniform preferences.
   - **(E)** Recency of technology has no necessary connection to the survey’s population inference.

**Check:** Replace the sample with employees whose workflows differ: the 90-percent projection is unsupported.
::::
:::

:::problem[Question I.10]

A payment processor measured its API responses over two weeks. Half of requests completed in under 90 milliseconds, while a small tail took more than two seconds. Large retail clients sent far more requests than small clients, and the dashboard pooled all requests before calculating its median. The processor’s support team observed that some small clients reported severe delays even though the pooled median scarcely changed. Its engineer warned that request-weighted summaries need not reflect the typical experience of each client.

Which one of the following is most strongly supported by the information above?

- **(A)** Most of the processor’s clients experienced a response time under 90 milliseconds.
- **(B)** Every request taking over two seconds came from a small client.
- **(C)** The reported severe delays were caused by large clients’ traffic.
- **(D)** A pooled median can remain favorable even when some low-volume clients experience substantial delays.
- **(E)** A client-weighted mean is always a better summary than a request-weighted median.

::::solution[Solution]
**Answer:** (D)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The question asks what follows from request-weighted latency data that can obscure client-level experiences.
2. **Support.** Large clients contribute more requests; aggregation is at the request rather than client level.
3. **Prephrase.** Distinguish a statistic about requests from a statistic about customers.
4. **Why (D) is right.** The pooled median weights high-volume clients heavily, allowing severe experiences among low-volume clients to have little effect.
5. **Why the others fail.**
   - **(A)** Half of requests, not half of clients, fell under that threshold; this reverses the unit of analysis.
   - **(B)** The source of the slow tail is unspecified.
   - **(C)** No cause of delay or competition for capacity is identified.
   - **(E)** A universal claim about superior metrics is not supported; suitability depends on the question.

**Check:** A client with few slow requests can suffer while barely shifting the pooled median.
::::
:::

:::problem[Question I.11]

A fictional software escrow arrangement provides that every release containing a restricted component must undergo legal review. All releases that undergo legal review receive a signed release certificate. Project Atlas has a signed release certificate. The team wants to establish that Atlas may be delivered to the customer today, but the contract also requires a delivery authorization before shipping. Neither the review rule nor the certificate rule explicitly connects certificates with delivery authorization.

Which one of the following, if assumed, allows the conclusion that Project Atlas may be delivered today to be properly drawn?

- **(A)** Every authorized release has a signed release certificate.
- **(B)** Some releases that underwent legal review were authorized for delivery today.
- **(C)** Every release containing a restricted component eventually undergoes review.
- **(D)** Every release that has a signed release certificate is authorized for delivery today.
- **(E)** No release without a signed certificate may be delivered today.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The procurement team seeks to conclude that Atlas may be delivered today, though only its certificate is established.
2. **Support.** The premises yield a certificate, but delivery authorization is a separate contractual requirement.
3. **Prephrase.** Add a universal conditional running from the known certificate to the needed delivery authorization.
4. **Why (D) is right.** Atlas has a certificate; certificate → authorization provides the missing direct bridge to permission to deliver.
5. **Why the others fail.**
   - **(A)** This reverses the needed conditional: authorization → certificate cannot establish authorization from a certificate.
   - **(B)** An existential claim need not include Atlas.
   - **(C)** This restates a premise about reviews and never bridges certificates to authorization.
   - **(E)** This makes a certificate necessary for delivery but not sufficient to authorize Atlas.

**Check:** Atlas certificate + certificate → authorized today, so Atlas authorized today.
::::
:::

:::problem[Question I.12]

A procurement officer argues that a low bid should not automatically win a cloud-storage contract. Price matters, but storage vendors also differ in recovery arrangements and documentation. **An audit report describes a vendor’s controls at a particular time; it does not guarantee the vendor will never suffer a failure.** For that reason, procurement should inspect the scope and date of audit evidence rather than treating the mere presence of a report as proof that resilience is assured. The officer nevertheless thinks an appropriately scoped report can be useful evidence alongside tests and contract terms.

The statement in boldface plays which one of the following roles in the argument?

- **(A)** It is the conclusion that procurement must reject the lowest-priced vendor.
- **(B)** It is a premise limiting what can reasonably be inferred from the presence of an audit report.
- **(C)** It is an objection the officer introduces only to refute.
- **(D)** It provides an example of a vendor that suffered a failure despite passing an audit.
- **(E)** It establishes that audit reports are useless in all purchasing decisions.

::::solution[Solution]
**Answer:** (B)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The lawyer’s ultimate recommendation is to inspect the actual scope of audit evidence; the highlighted sentence supports it.
2. **Support.** The passage moves from the limits of a report to the purchasing practice those limits warrant.
3. **Prephrase.** Classify the statement as evidence and preserve its modest rather than absolute force.
4. **Why (B) is right.** The bold statement supports the recommendation to evaluate report scope, because an audit does not promise future perfection.
5. **Why the others fail.**
   - **(A)** The officer says low price is not automatically decisive, not that the lowest bid must be rejected.
   - **(C)** The officer accepts and relies on the audit report’s limitations.
   - **(D)** No particular audited vendor or failure is described.
   - **(E)** The final sentence explicitly retains their usefulness as partial evidence.

**Check:** Premise about limited report scope → recommendation not to equate report with guaranteed resilience.
::::
:::

:::problem[Question I.13]

A university electronics shop began measuring battery health in returned laptops before choosing which units to refurbish. A semester later, the proportion of refurbished units returned with battery complaints fell. The shop’s supervisor argues that the screening procedure caused the improvement by excluding batteries likely to fail. Another technician notes that the shop also started buying replacement batteries from a new supplier during the same semester, potentially offering a separate explanation for the decline in complaints.

Which one of the following, if true, most strengthens the supervisor’s argument?

- **(A)** Among refurbished laptops that retained their original batteries, the complaint rate fell sharply after screening began even though no replacement supplier was involved.
- **(B)** The new supplier’s batteries were less expensive than the old supplier’s.
- **(C)** The screening machine required less training than the previous inspection protocol.
- **(D)** Refurbished units are popular with students who need low-cost devices.
- **(E)** Technicians sometimes disagreed about how to classify battery health.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The supervisor credits battery-health screening for the decline in refurbishment complaints.
2. **Support.** Two simultaneous interventions could account for the aggregate decline in complaints.
3. **Prephrase.** Look for improvement where the competing replacement-battery explanation cannot operate.
4. **Why (A) is right.** For original-battery units the supplier change is irrelevant, yet complaints still fall with screening.
5. **Why the others fail.**
   - **(B)** Battery prices do not reveal which change reduced failures.
   - **(C)** Ease of use does not isolate an effect on battery complaints.
   - **(D)** Customer demand is separate from the reason complaints declined.
   - **(E)** Inter-rater disagreement could limit screening rather than strengthen its efficacy.

**Check:** Condition on original batteries; supplier change drops out but screening remains.
::::
:::

:::problem[Question I.14]

A purchasing analyst argues that a manufacturer should qualify a second supplier for a specialized connector. Although the current supplier has never missed a shipment, the plant would be forced to halt production if that supplier’s facility became unavailable. Qualifying another supplier costs money, but the analyst compares that fee with an insurance premium: the point is not that a failure is certain but that its consequences are severe and the alternative makes them less severe. The analyst concludes that historical reliability alone does not settle the decision.

The analyst’s argument proceeds primarily by...

- **(A)** demonstrating that an interruption at the current supplier is inevitable.
- **(B)** calculating the precise expected monetary loss of relying on one supplier.
- **(C)** challenging the accuracy of the current supplier’s delivery records.
- **(D)** arguing that no manufacturer can operate safely with a single supplier.
- **(E)** using an analogy to explain why a costly precaution can be warranted despite a favorable history.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The analyst recommends qualifying a second connector supplier to avoid severe single-source disruption.
2. **Support.** The analyst grants the supplier’s good history but emphasizes a potentially severe single-point failure.
3. **Prephrase.** Identify the analogy and the risk-management inference, not an invented quantitative proof.
4. **Why (E) is right.** The insurance-premium comparison makes the rationale for precaution understandable without proving any breakdown will occur.
5. **Why the others fail.**
   - **(A)** The analyst explicitly says failure is uncertain, not inevitable.
   - **(B)** No probabilities or numerical losses are provided.
   - **(C)** The past record is conceded and its decisiveness is questioned.
   - **(D)** The conclusion concerns this production line’s exposure, not every manufacturer.

**Check:** Analogy: second qualification is to production interruption as a premium is to uncertain loss.
::::
:::

:::problem[Question I.15]

A startup plans to publish device telemetry grouped by postal district. Its founder argues that the published tables will reveal nothing about any individual because each table will list only totals for districts containing at least fifty devices. The engineering team points out that users may be able to combine these totals with separately available information. The founder replies that a table does not display names or device identifiers and insists that the district threshold by itself makes identifying an individual’s behavior impossible.

The founder’s argument depends on assuming which one of the following?

- **(A)** Every device in each district generates an equal quantity of telemetry.
- **(B)** Postal district boundaries will never change.
- **(C)** No recipient can use the district totals together with other available information to infer the behavior of an identifiable individual.
- **(D)** The published data will be useful to at least fifty independent researchers.
- **(E)** The startup has obtained consent from every owner of a device.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The founder concludes that district-level aggregation guarantees no individual behavior can be identified.
2. **Support.** The founder moves from omission of identifiers and group size to a universal inability to infer individual behavior.
3. **Prephrase.** Rule out the specific joining or differencing route the founder has ignored.
4. **Why (C) is right.** Negating the answer allows re-identification through combination, directly defeating the founder’s claim of impossibility.
5. **Why the others fail.**
   - **(A)** Uniform contribution is not necessarily required if individuals still cannot be identified.
   - **(B)** Boundary stability is irrelevant to whether a current release permits inference.
   - **(D)** Usefulness and number of researchers do not establish anonymity.
   - **(E)** Consent does not determine whether a dataset permits identifying behavior.

**Check:** Negate it: a recipient can combine data to identify behavior, so the universal anonymity claim fails.
::::
:::

:::problem[Question I.16]

A hardware director says the latest product release was delayed because engineers spent too much time performing optional tests. During the delayed release, teams performed more optional tests than in the preceding on-time release. Accordingly, the director proposes eliminating optional tests to restore the schedule. But the latest design introduced a new component with unusual failure modes, and engineers added tests after encountering problems during early trials. The director’s evidence establishes which activities accompanied the delay, not why the schedule slipped.

The director’s argument is most vulnerable to criticism because it...

- **(A)** overlooks the possibility that emerging design problems led both to additional tests and to the delayed release.
- **(B)** treats optional tests as legally required by all engineering standards.
- **(C)** concludes that the previous product had more defects than the latest one.
- **(D)** presumes that testing can never improve product quality.
- **(E)** uses a broad national survey to predict the behavior of a small team.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director claims extra optional testing caused the schedule delay and should therefore be eliminated.
2. **Support.** The director infers causation from two correlated changes while ignoring a plausible common cause.
3. **Prephrase.** Ask whether the delay prompted testing, or whether design complexity caused both.
4. **Why (A) is right.** Testing may be a response to troublesome design rather than the underlying cause of the delay.
5. **Why the others fail.**
   - **(B)** The argument never mentions standards or legal testing duties.
   - **(C)** No such comparison of defect counts appears.
   - **(D)** The claim is about the schedule, not a categorical inability to improve quality.
   - **(E)** The data compare two releases, not a national sample.

**Check:** Common cause: unusual component failures → added tests and schedule delay.
::::
:::

:::problem[Question I.17]

A company rule states that every product incorporating a component from Registry Q must receive a technical review. Every product that receives technical review is entered in the release ledger. Prototype Lark incorporates a Registry Q component. The legal operations team therefore concludes that Prototype Lark will be entered in the release ledger. The team notes that being entered in the ledger may not be sufficient for shipment approval, but that qualification is irrelevant to the narrowly stated conclusion about ledger entry.

Which one of the following arguments exhibits the same pattern of reasoning?

- **(A)** All approved films are archived; a particular film is archived; therefore it was approved.
- **(B)** Some licensed pilots have completed night training; Rina is licensed; therefore she has completed night training.
- **(C)** Whenever the forecast predicts rain, workers close the awning; the awning is closed; therefore rain was predicted.
- **(D)** Every certified mechanic completes safety training; everyone who completes safety training receives an employee badge; Mara is a certified mechanic; therefore Mara receives a badge.
- **(E)** No technician without authorization may enter the lab; Kai has authorization; therefore Kai may enter.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The release team concludes that Lark must be in the ledger; the task is to match its valid conditional chain.
2. **Support.** Two universal implications compose transitively, then apply to the specified prototype.
3. **Prephrase.** Match A → B → C, A(x), therefore C(x), without reversing arrows.
4. **Why (D) is right.** The valid chain is Registry-Q → technical review → ledger, with a named member in the first class.
5. **Why the others fail.**
   - **(A)** This reverses the first implication and affirms the consequent.
   - **(B)** An existential some cannot be applied to every licensed pilot.
   - **(C)** A closed awning does not imply the condition that is sufficient to close it.
   - **(E)** Having a necessary condition is not sufficient for entry.

**Check:** Certified → trained → badge and Mara certified → badge.
::::
:::

:::problem[Question I.18]

An app developer claims that a patch eliminated most crashes because crash reports sent by users fell 70 percent during the month after release. The app’s interface and subscription price stayed the same, and the reporting server was operational. The developer assumes that report counts track the number of crashes. However, the patch also included a new privacy dialog asking users whether to share diagnostic data, and opting out disabled automatic crash reporting. Users could still submit reports manually through a support form.

Which one of the following, if true, most weakens the developer’s argument?

- **(A)** Some users submitted detailed crash descriptions through the support form.
- **(B)** The patch fixed several visual glitches unrelated to crashes.
- **(C)** After the patch, most users disabled automatic diagnostic sharing, while independently recorded crash events fell only slightly.
- **(D)** A competing app had more crash reports than this app in the preceding month.
- **(E)** Users who enabled automatic reports often used the app for long sessions.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The developer concludes that the patch eliminated most crashes because submitted crash reports declined.
2. **Support.** The argument uses fewer submitted reports as a proxy for fewer incidents despite changed reporting consent.
3. **Prephrase.** Find evidence that measurement or participation fell independently of crash occurrence.
4. **Why (C) is right.** Independent crash events barely decline while opt-outs suppress reports, severing the assumed link between observed reports and actual crashes.
5. **Why the others fail.**
   - **(A)** The existence of manual reporting does not measure the true crash-rate change.
   - **(B)** Unrelated visual improvements do not explain the decline in crash reports.
   - **(D)** Competitor counts do not address whether reporting practices changed after this patch.
   - **(E)** Session length among reporters does not establish overall crash frequency.

**Check:** Reports decrease because reporting is disabled, not because crashes decrease proportionally.
::::
:::

:::problem[Question I.19]

Engineer: We have a working prototype but only preliminary durability results. We should postpone the public demonstration until the patent team has reviewed what we intend to disclose. An early presentation could reveal details we later wish to protect. Product lead: I agree that counsel should inspect the planned material before we present it. But I disagree that the demonstration itself must be postponed. We can schedule a limited presentation using only material that the team and counsel have already approved, even while durability testing continues.

The engineer and the product lead disagree about whether...

- **(A)** patent counsel should review information before it is publicly demonstrated.
- **(B)** the planned demonstration must be delayed until a broader review has been completed.
- **(C)** the prototype currently has complete durability data.
- **(D)** every public demonstration automatically destroys patent protection.
- **(E)** product teams should never disclose technical specifications.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** The speakers disagree about whether the demonstration must be postponed, not about whether counsel should review planned disclosures.
2. **Support.** They share the goal of lawyer-reviewed disclosure but disagree about the timing of the particular presentation.
3. **Prephrase.** Find a proposition one affirms and the other denies, rather than shared caution.
4. **Why (B) is right.** The engineer advocates postponement; the product lead explicitly says postponement is unnecessary if the scope is limited.
5. **Why the others fail.**
   - **(A)** Both speakers explicitly agree that counsel should review what will be shown.
   - **(C)** Both acknowledge testing is incomplete; neither claims complete data.
   - **(D)** Neither speaker asserts such a universal legal rule about public disclosure and patents.
   - **(E)** Both discuss controlled disclosure, not a permanent prohibition.

**Check:** Engineer: delay yes; product lead: delay no, given limited approved material.
::::
:::

:::problem[Question I.20]

A city runs a public dashboard of pedestrian counts gathered by street sensors. A resident asks officials to release the raw logs, which include device identifiers. Officials are willing to release summary counts but worry that a small number of journeys could be traced through the raw logs. A transparency advocate argues that public information should be disclosed in the most detailed useful form consistent with protecting people from identification. The advocate rejects both a total refusal to share any counts and automatic release of all underlying records.

Which one of the following policies most closely conforms to the advocate’s principle?

- **(A)** Publish all raw logs because government-funded data must always be maximally detailed.
- **(B)** Refuse to publish even district totals until every sensor owner consents.
- **(C)** Publish only data that would increase the city’s advertising revenue.
- **(D)** Release an arbitrary 10 percent of raw rows without examining identifiability.
- **(E)** Release useful aggregated journey counts, suppressing detail that would permit individual journeys to be identified.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The advocate endorses releasing useful information only at a level that protects identifiable journeys.
2. **Support.** The advocate values transparency and identification safeguards simultaneously.
3. **Prephrase.** Apply both requirements rather than maximizing only publicity or only secrecy.
4. **Why (E) is right.** The rule requires maximal useful disclosure constrained by avoiding identifiable journeys, which aggregation and suppression implement.
5. **Why the others fail.**
   - **(A)** This discards the advocate’s express condition against identification.
   - **(B)** This ignores the commitment to useful release when protection is possible.
   - **(C)** Revenue is not the governing criterion of useful transparency consistent with privacy.
   - **(D)** Reducing volume does not guarantee protection from tracing individual journeys.

**Check:** Useful summaries are public; identifying-level detail is withheld.
::::
:::

:::problem[Question I.21]

A team lead says that any module that passes the company’s mandatory peer-review checklist is suitable for production. She notes that every production-ready module has passed that checklist. The team has just completed the checklist for the billing module, so she concludes that the billing module is production-ready. Other criteria such as integration testing and deployment permissions are assessed separately, but the lead regards the completed checklist as decisive because no production-ready module lacks it.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** infers from software documentation that all bills will be accurate.
- **(B)** assumes peer reviewers have no relevant expertise.
- **(C)** draws an analogy between different product teams and assumes they are identical.
- **(D)** rejects integration testing because it is more expensive than review.
- **(E)** confuses a condition required for production readiness with one that guarantees production readiness.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The lead claims a completed checklist is sufficient to classify the billing module as production-ready.
2. **Support.** The premise identifies checklist completion as necessary; the lead uses it as sufficient.
3. **Prephrase.** Diagram the conditional and identify the unjustified converse.
4. **Why (E) is right.** Production-ready → checklist passed is affirmed, but the conclusion requires checklist passed → production-ready.
5. **Why the others fail.**
   - **(A)** The argument does not predict any particular billing outcome.
   - **(B)** It may overvalue checklist completion without denying reviewer competence.
   - **(C)** No analogy or cross-team comparison is used.
   - **(D)** The lead does not supply a cost comparison or explicit rejection of testing.

**Check:** Ready → checklist; checklist does not entail ready.
::::
:::

:::problem[Question I.22]

A SaaS buyer must choose between two otherwise identical cloud contracts. Contract Pine costs less each month but refunds only a small fraction of fees after a prolonged outage. Contract Cedar costs more but reimburses a much larger fraction when outages occur. A finance officer recommends Pine solely on the ground that its monthly fee is lower. Another officer says this overlooks the total financial consequences of downtime and asks for information that would most help assess whether paying the premium for Cedar is worthwhile.

The answer to which one of the following questions would be most useful in evaluating the finance officer’s recommendation?

- **(A)** How many service credits did each provider issue last year?
- **(B)** How often did each provider respond to past outages within fifteen minutes?
- **(C)** How likely are outages of the kind covered by the reimbursement clauses, and what uncompensated loss would each cause?
- **(D)** Did customers who received credits report greater satisfaction with Cedar?
- **(E)** Have the providers kept their monthly fees unchanged over the preceding year?

::::solution[Solution]
**Answer:** (C)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The first finance officer recommends Pine solely from the lower base fee; the task is to evaluate that recommendation.
2. **Support.** The cheaper fixed price is contrasted with differences in contingent protection, so total expected costs matter.
3. **Prephrase.** Identify the unknown probabilities and financial magnitude that determine the tradeoff.
4. **Why (C) is right.** Outage probabilities and loss exposure reveal whether the additional coverage is worth Cedar’s higher premium.
5. **Why the others fail.**
   - **(A)** Counts alone omit outage severity, future likelihood and the buyer’s losses beyond credits.
   - **(B)** Response speed is relevant but does not evaluate the cost of the differing reimbursements.
   - **(D)** Customer satisfaction does not show whether the premium is justified by expected financial outcomes.
   - **(E)** Past price stability does not measure the value of contingent outage coverage.

**Check:** Compare Cedar’s extra fixed cost with expected benefit of its better outage reimbursement.
::::
:::

:::problem[Question I.23]

After deploying a chatbot to answer routine IT questions, a university reported that the number of human-handled help-desk tickets declined. Nevertheless, the total number of hours human staff spent on help-desk work increased. Administrators verified that ticket categories and time-reporting rules remained the same. They had expected the chatbot to relieve staff workloads, since it handled many basic inquiries without human intervention. The increase in staff hours appears inconsistent with that expectation unless something about the remaining work changed.

Which one of the following, if true, most helps to resolve the discrepancy?

- **(A)** The chatbot answered a high proportion of routine password questions correctly.
- **(B)** The chatbot resolved most short password questions, leaving humans with fewer but substantially longer, complex incidents.
- **(C)** The university kept the same number of help-desk employees on staff.
- **(D)** Human-handled requests were more frequently assigned to their correct department after the change.
- **(E)** Users could still submit support tickets even after the chatbot answered their first question.

::::solution[Solution]
**Answer:** (B)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The puzzle is a smaller human ticket count alongside a larger total number of human work hours.
2. **Support.** Fewer human tickets coexist with more human hours if the remaining tickets are harder.
3. **Prephrase.** Look for a change in composition of human-handled requests.
4. **Why (B) is right.** Hours equal ticket count times average human time per ticket; average time can increase enough to outweigh fewer tickets.
5. **Why the others fail.**
   - **(A)** That supports its reduction in simple tickets without explaining why total human work increased.
   - **(C)** Staffing stability does not tell us how long remaining tickets take.
   - **(D)** Better routing might improve efficiency but does not establish why total labor hours rose.
   - **(E)** The possibility of duplicate requests could matter, but no increase in such duplicates is shown.

**Check:** Count down × time per ticket up by more = total hours up.
::::
:::

:::problem[Question I.24]

A procurement rule states that any supplier awarded the highest reliability grade must have completed independent testing. A candidate supplier completed independent testing last year. The committee therefore asserts that the candidate has earned the highest reliability grade and should be treated as qualified for the most sensitive shipments. Several other grade criteria exist, but the committee considers testing enough because every top-graded supplier has it.

Which one of the following arguments contains reasoning most similar in its flaw?

- **(A)** Every solar-powered station needs sunlight. This station has no sunlight. Therefore it cannot be solar-powered at the moment.
- **(B)** All blue tags are numbered. This tag is blue. Therefore it is numbered.
- **(C)** Some award winners study music. Troy studies music. Therefore Troy might win an award.
- **(D)** Every championship swimmer has completed endurance training. Nila completed endurance training. Therefore Nila is a championship swimmer.
- **(E)** No licensed vehicle lacks insurance. A vehicle is licensed. Therefore it has insurance.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The committee incorrectly infers the highest reliability grade from completion of one necessary test.
2. **Support.** The committee converts a necessary test into a guarantee of a higher status.
3. **Prephrase.** Match a firm conclusion obtained by reversing an only-if requirement.
4. **Why (D) is right.** The flawed form is top grade → tested; tested, so top grade: affirming the consequent.
5. **Why the others fail.**
   - **(A)** This valid contrapositive denies a necessary condition, unlike the stimulus.
   - **(B)** This is valid modus ponens, not an inference from necessary to sufficient.
   - **(C)** A possibility claim does not replicate the definite converse error.
   - **(E)** This valid inference applies the requirement in the correct direction.

**Check:** Champion → trained; trained → champion is invalid in exactly the same way.
::::
:::

:::problem[Question I.25]

An equipment engineer installed vibration sensors on half the machines in a printing plant and used their alerts to schedule maintenance. During the next quarter, sensor-equipped machines experienced less unplanned downtime than the others. The engineer attributes the difference to predictive maintenance and proposes deploying sensors everywhere. Critics note that the sensors were initially installed on newer machines, which might have needed fewer repairs even without the system. The engineer seeks evidence separating the monitoring system from the machines' ages.

Which one of the following, if true, most strengthens the engineer’s conclusion?

- **(A)** After controlling for machine age and prior repair history, sensor-equipped machines still had substantially less unplanned downtime.
- **(B)** The cost of each sensor fell after the first order.
- **(C)** Several sensor-equipped machines generated false alarms.
- **(D)** The plant’s oldest machines require specialized spare parts.
- **(E)** Production volume increased in the quarter after sensors were installed.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer claims predictive monitoring, not the newer age of monitored machines, caused reduced downtime.
2. **Support.** The original association is confounded because monitored units are newer.
3. **Prephrase.** Hold relevant baseline condition constant and check whether the observed advantage persists.
4. **Why (A) is right.** Conditioning on age and past repairs removes the principal rival explanation while retaining a downtime difference.
5. **Why the others fail.**
   - **(B)** Lower cost helps the purchase decision but not the causal claim about downtime.
   - **(C)** False alarms are potentially adverse evidence, not evidence of fewer breakdowns.
   - **(D)** This reinforces a possible age confound without resolving it.
   - **(E)** Plantwide volume does not distinguish the effect of sensors from machine age.

**Check:** Within comparable machines, monitoring still predicts less downtime.
::::
:::

## 35.2 Section II: Reading Comprehension

### Passage 1

The engineer who leaves a cloud-security firm may carry two kinds of knowledge: a memory of how secure systems are generally designed, and details of a particular firm’s unpublished detection rules. Employers have reasons to protect the latter, while the public benefits when engineers can use the former elsewhere. In a hypothetical jurisdiction called Northport, courts considering a dispute between an employer and a departed engineer therefore ask what information the employer claims as secret, rather than treating the employee’s entire technical experience as company property. That distinction sounds simple until a design choice emerges from hundreds of small decisions, some published and others internal.

Consider a fictional firm, Heliograph, that compiles an alert score from several signals. The general idea of combining signals appears in public technical discussions. But Heliograph alleges that the exact weights, the unusual exception rules, and the results of costly internal tests were kept confidential. It has restricted access to those materials, though one version of a test spreadsheet was mistakenly shared with a contractor. A competing firm hires a former Heliograph engineer and later releases an alert system that performs similarly. Similar performance alone cannot establish which information the engineer used. Independent experimentation or reliance on public techniques could explain it. Conversely, the engineer’s ability to describe a procedure from memory would not, by itself, make the procedure public.

Employment contracts complicate the dispute. Heliograph’s confidentiality agreement instructs employees not to disclose designated internal documents; its separate non-compete clause would, if enforceable, prevent a former engineer from taking certain jobs for a period. The two provisions protect different interests by different means. A confidentiality obligation targets disclosure or use of specified information. A non-compete restricts employment even where no information is shown to have been used. In Northport’s hypothetical legal system, courts inspect the scope of each restriction independently; they do not infer that every contractual promise is valid merely because it was signed.

Some commentators would resolve these disputes by demanding that employers precisely enumerate every secret before an employee leaves. Precision could discourage later attempts to claim ownership of ordinary skills. Yet a rigid inventory might omit configurations developed the day before departure or inadvertently reveal the very combinations an employer seeks to protect. A better approach, the author suggests, is to require an employer to identify the allegedly protected information with enough specificity to permit a meaningful challenge, while accepting that the identification need not take the form of a complete advance list. The aim is not automatic victory for either firm or worker. It is a fair inquiry into information, access, and use, rather than an inference from job changes or technical resemblance alone. Such a procedure would also let an engineer distinguish an allegation about a particular internal rule from an effort to prevent ordinary work using knowledge that many trained engineers possess.

:::problem[Question II.1]

Which one of the following most accurately states the main point of Passage 1?

- **(A)** Disputes over departing engineers should turn on sufficiently specific evidence of protected information and its use, not simply employment changes or technical similarity.
- **(B)** Because engineers remember their employers’ methods, former employers should own whatever systems they subsequently build.
- **(C)** Non-compete clauses are always invalid, while confidentiality clauses are always enforceable.
- **(D)** Companies should publish exact inventories of all internal techniques before employees depart.
- **(E)** Technical similarity between competing products conclusively establishes that a secret was copied.

::::solution[Solution]
**Answer:** (A)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author favors sufficiently specific proof of allegedly protected information and its use, while preserving ordinary employee expertise.
2. **Support.** Paragraphs 1–3 distinguish general knowledge, alleged secrets, similarity, and different contract restrictions; paragraph 4 presents the preferred procedure.
3. **Prephrase.** Choose the qualified position governing how claims should be tested, not one extreme interest.
4. **Why (A) is right.** The final paragraph endorses specificity sufficient for a meaningful challenge without a mandatory exhaustive inventory.
5. **Why the others fail.**
   - **(B)** This equates general skills with protected information, the very inference the passage resists.
   - **(C)** The hypothetical Northport courts evaluate each provision separately; neither absolute rule appears.
   - **(D)** The author objects to a rigid complete advance inventory.
   - **(E)** The Heliograph example gives independent development as an alternative explanation.

**Check:** Match the recommendation in the final paragraph to the distinctions developed throughout.
::::
:::

:::problem[Question II.2]

According to Passage 1, which circumstance complicates Heliograph’s claim that it kept its technical materials confidential?

- **(A)** The company’s alert score uses no exception rules.
- **(B)** Every former engineer received a complete copy of the internal tests.
- **(C)** Heliograph’s competitors publicly disclosed the exact signal weights before its product launch.
- **(D)** One version of a test spreadsheet was mistakenly shared with a contractor.
- **(E)** Its engineers were forbidden to discuss any security subject with contractors.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The second paragraph presents restricted internal material with one exception, a test spreadsheet mistakenly shared with a contractor.
2. **Support.** The second paragraph specifies both asserted safeguards and one possible breach of secrecy.
3. **Prephrase.** Return to the factual qualification immediately after the description of restricted access.
4. **Why (D) is right.** The mistaken sharing is the explicit limitation on Heliograph’s otherwise restricted access to internal test material.
5. **Why the others fail.**
   - **(A)** The passage expressly describes unusual exception rules as among the alleged confidential details.
   - **(B)** No such universal distribution is stated; the passage identifies a single mistaken sharing.
   - **(C)** The passage says the general idea is public, not the exact weights.
   - **(E)** The passage discusses mistaken access, not a blanket prohibition on all subjects.

**Check:** Paragraph 2: “one version of a test spreadsheet was mistakenly shared with a contractor.”
::::
:::

:::problem[Question II.3]

It can most reasonably be inferred from Passage 1 that the author would regard which evidence as insufficient by itself to establish misuse of a secret?

- **(A)** A former engineer copied Heliograph’s restricted exception rules into the competitor’s design notes.
- **(B)** A competing alert system performs about as well as Heliograph’s alert system.
- **(C)** A former engineer transferred a nonpublic internal test report to the competitor.
- **(D)** A court received documents identifying precise internal weights and proof that they were used.
- **(E)** A contractor admitted revealing confidential configurations to a competitor.

::::solution[Solution]
**Answer:** (B)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author distinguishes proof of using confidential details from mere similarity of competing products.
2. **Support.** Independent experimentation or public techniques could also explain similar outputs.
3. **Prephrase.** Isolate the evidence that permits competing explanations of how the result arose.
4. **Why (B) is right.** The author explicitly says similar performance alone does not establish which information an engineer used.
5. **Why the others fail.**
   - **(A)** Such copying is direct evidence of use, not mere resemblance.
   - **(C)** The passage gives reason to treat transfer of identified internal tests as pertinent evidence.
   - **(D)** This addresses identification and use rather than relying solely on performance.
   - **(E)** An admission of disclosure is more than evidence of similar performance.

**Check:** Paragraph 2 states that similar performance alone cannot establish the source of information.
::::
:::

:::problem[Question II.4]

The discussion of a configuration developed the day before departure primarily serves to...

- **(A)** demonstrate that employees always develop configurations without employer supervision.
- **(B)** show that a later-developed configuration must be available to everyone.
- **(C)** prove that earlier disclosure of secrets would invariably be unlawful.
- **(D)** establish that every secret can be identified only after litigation begins.
- **(E)** illustrate why a complete advance inventory could leave genuinely disputed information out.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The author rejects a complete advance inventory as the only acceptable means of identifying alleged secrets.
2. **Support.** Paragraph 4 grants the benefit of precision, then supplies reasons rigid inventories can fail.
3. **Prephrase.** Identify the argumentative function within the author’s qualified alternative.
4. **Why (E) is right.** The recent-configuration example is a counterexample to the demand for an exhaustive predeparture list.
5. **Why the others fail.**
   - **(A)** No claim about universal employee autonomy is made.
   - **(B)** The passage uses timing to show possible omission, not public status.
   - **(C)** The argument concerns practical consequences of inventory rules, not a universal legal prohibition.
   - **(D)** The author rejects completeness as an absolute prerequisite, not all earlier identification.

**Check:** An item created at the last minute need not appear on a prior supposedly complete list.
::::
:::

:::problem[Question II.5]

Which one of the following hypothetical policies would best reflect the distinction drawn in the third paragraph?

- **(A)** Treat a signed non-compete as proof that an employee revealed confidential documents.
- **(B)** Assume that any signed promise in an employment contract is automatically enforceable.
- **(C)** Assess a confidentiality claim by identifying what information was used, and separately assess a non-compete restriction that bars an otherwise permissible job.
- **(D)** Require all employees to abandon general engineering skills upon leaving a firm.
- **(E)** Treat every confidentiality agreement as an unrestricted ban on working for competitors.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The third paragraph treats confidentiality promises and employment restrictions as distinct legal instruments in the hypothetical system.
2. **Support.** Paragraph 3 differentiates restrictions aimed at specified information from restrictions on jobs without proof of use.
3. **Prephrase.** Apply the two-restriction distinction, not merely a preference for one party.
4. **Why (C) is right.** The choice preserves the distinct subject and independent evaluation of each obligation.
5. **Why the others fail.**
   - **(A)** This confuses restrictions on jobs with evidence of disclosure or use.
   - **(B)** Northport specifically evaluates scope rather than validity from signature alone.
   - **(D)** Paragraph 1 separates transferable experience from particular protected information.
   - **(E)** A confidentiality obligation targets information rather than all competing employment.

**Check:** Information restriction and job restriction must be analyzed on separate grounds.
::::
:::

:::problem[Question II.6]

The author’s attitude toward requiring precise advance identification of every trade secret is best described as...

- **(A)** wholly dismissive of the value of identifying alleged secrets.
- **(B)** unreservedly enthusiastic about complete lists as the exclusive solution.
- **(C)** indifferent to the competing interests of firms and workers.
- **(D)** sympathetic to the goal of specificity but skeptical of an inflexible exhaustive-list requirement.
- **(E)** convinced that employers can never keep configurations confidential.

::::solution[Solution]
**Answer:** (D)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The final paragraph makes a qualified, not categorical, endorsement of specificity in identifying secrets.
2. **Support.** The last paragraph begins with an advantage of lists, then pivots to omissions and accidental revelation.
3. **Prephrase.** Choose the mixed evaluative attitude corresponding to that concession-and-qualification pattern.
4. **Why (D) is right.** The author accepts the rationale for precision but rejects its complete advance form in favor of a flexible specificity standard.
5. **Why the others fail.**
   - **(A)** The author specifically requires enough identification to permit a meaningful challenge.
   - **(B)** The text raises two difficulties with a rigid complete list.
   - **(C)** The opening and conclusion explicitly balance their competing interests.
   - **(E)** The passage distinguishes potentially protectable details from public design ideas.

**Check:** “Precision could discourage” is conceded; “yet a rigid inventory might omit” marks the pivot.
::::
:::

### Passage 2

A machine-learning model trained to distinguish cracked circuit-board traces from harmless surface markings may receive excellent scores on images it has seen before. That achievement reveals little about whether the model has learned a distinction that remains useful on new boards. During training, an algorithm adjusts a model’s parameters to reduce error on examples supplied to it. The immediate objective is performance on those examples; the practical objective is generalization, or successful prediction on appropriately new cases. An unusually flexible model may memorize features particular to training images, including patterns that have nothing to do with cracks. This is one form of overfitting.

Suppose a fictional factory photographs every board twice, once under each of two lighting settings. If one image of each board enters the training set and its near-duplicate enters the test set, the test score can appear impressive even though the model has not learned to handle unfamiliar boards. The problem is not that the arithmetic used to compute accuracy is incorrect. The problem is that the tested images do not represent the independence promised by the phrase 'unseen examples.' In this setting, splitting data by physical board, rather than by image, provides a more informative assessment of performance on new boards. A later evaluation on boards from a different production run might reveal another weakness: the camera background has changed.

There is no single intervention that cures every failure of generalization. Reducing model complexity can limit opportunities to fit irrelevant details, yet a model too simple to capture genuine crack patterns may perform poorly for a different reason. Gathering varied training examples can help when those examples capture the changes the deployed system will encounter. Validation data can guide design decisions, but repeated selection of a model because it performs well on the same validation set risks adapting the development process to peculiarities of that set. An untouched final test set is consequently valuable, though even one such test cannot guarantee performance after future conditions change.

A proposed factory audit illustrates the danger of asking only whether a score is high. One engineer proposes reporting accuracy from a randomly selected set of photographs. Another proposes documenting how boards were grouped into training and testing, whether threshold choices were settled before final testing, and which lighting conditions were covered. The second proposal is more informative even if it produces a lower score. That is because a useful evaluation identifies what the number measures and the circumstances under which it may cease to apply. Generalization is not a property certified once and for all by a single impressive percentage; it is a claim tied to a defined population of future examples, with assumptions that can be investigated. The test designer must therefore describe not only what happened on the selected images but also why those images are relevant to the deployment decisions being made.

:::problem[Question II.7]

Which one of the following most accurately expresses the main point of Passage 2?

- **(A)** A sufficiently flexible model will always generalize better than a simpler model.
- **(B)** Training accuracy is the best measure of how well a vision system will perform after deployment.
- **(C)** An evaluation score supports claims about generalization only to the extent that the testing design matches the new cases the model is meant to handle.
- **(D)** Every future shift in factory conditions can be anticipated by collecting enough photographs.
- **(E)** A model’s test accuracy should never be reported to engineers or customers.

::::solution[Solution]
**Answer:** (C)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author argues that model evaluation must correspond to the future cases about which a generalization claim is made.
2. **Support.** The passage focuses on inference from a numerical test result to a defined future population.
3. **Prephrase.** Choose the conclusion about evaluation design and generalization, not a ban on scores.
4. **Why (C) is right.** Each paragraph illustrates a reason accuracy alone is insufficient: dependence, leakage, model choice, and deployment coverage.
5. **Why the others fail.**
   - **(A)** The text warns that flexibility can encourage overfitting and simplicity can also underfit.
   - **(B)** The opening expressly distinguishes training performance from the practical objective.
   - **(D)** The author denies that any single intervention or test guarantees future performance.
   - **(E)** The author wants better contextualized accuracy, not abandonment of measurements.

**Check:** Every example asks what new examples the evaluation can legitimately represent.
::::
:::

:::problem[Question II.8]

In the factory photography example, why would splitting the data by physical board rather than by individual image provide a more informative test?

- **(A)** It reduces the chance that nearly identical images of one board appear in both training and test sets.
- **(B)** It guarantees that no change in camera background will affect later predictions.
- **(C)** It forces the model to use fewer parameters during training.
- **(D)** It increases the number of boards photographed under both lighting conditions.
- **(E)** It ensures all crack markings are equally common in the test images.

::::solution[Solution]
**Answer:** (A)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The factory example questions whether two images of the same board count as independent training and test cases.
2. **Support.** Paragraph 2 identifies overlap between units represented in training and testing as the leakage mechanism.
3. **Prephrase.** Explain how the split restores independence with respect to boards rather than changing model architecture.
4. **Why (A) is right.** Images of one board under two settings may be near duplicates, making image-level testing misleadingly easy.
5. **Why the others fail.**
   - **(B)** Grouping by board does not eliminate distribution shift across production runs.
   - **(C)** The split changes evaluation membership, not model capacity directly.
   - **(D)** The passage gives no new collection rule or expansion of the dataset.
   - **(E)** Grouping by board does not establish balanced classes or equal prevalence.

**Check:** A board appears in one partition, not both, even if it has two photographs.
::::
:::

:::problem[Question II.9]

The passage most strongly suggests that repeated design selection based on one validation set may...

- **(A)** make the validation images physically identical to images from future production runs.
- **(B)** cause the development process to fit chance characteristics of that validation set.
- **(C)** remove the need for a final untouched evaluation set.
- **(D)** guarantee that a model with lower training error has lower deployment error.
- **(E)** prevent a model from detecting any real cracks in training images.

::::solution[Solution]
**Answer:** (B)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author warns that selecting repeatedly on one validation set can adapt the development process to that set.
2. **Support.** The validation set participates indirectly in selection, threatening independence of assessment.
3. **Prephrase.** Infer the subtle form of overfitting at the workflow level.
4. **Why (B) is right.** Paragraph 3 warns that repeatedly choosing based on one set adapts the entire development process to that set’s peculiarities.
5. **Why the others fail.**
   - **(A)** Repeated selection does not change the physical photographs or future manufacturing conditions.
   - **(C)** The passage recommends preserving an untouched final set for exactly this concern.
   - **(D)** No guarantee follows, and training fit is not the issue.
   - **(E)** Repeated validation tuning may bias performance estimates, not necessarily eliminate detection ability.

**Check:** If decisions repeatedly optimize one validation set, it ceases to function as an untouched independent check.
::::
:::

:::problem[Question II.10]

The second engineer’s proposal in the final paragraph is presented primarily to...

- **(A)** argue that factories should discontinue automated visual inspection entirely.
- **(B)** claim that threshold selection is never a legitimate part of model design.
- **(C)** show that a lower accuracy score necessarily means a superior model.
- **(D)** establish that camera backgrounds always determine whether traces are cracked.
- **(E)** illustrate how documentation of evaluation conditions can be more informative than a single favorable performance number.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The proposed audit illustrates why evaluation conditions matter more than a decontextualized percentage.
2. **Support.** It contrasts raw random-photo accuracy with scrutiny of how the evaluation was structured.
3. **Prephrase.** Focus on the illustrative role of the two audit proposals.
4. **Why (E) is right.** Contextual information about splits, thresholds, and lighting establishes what the performance number can support.
5. **Why the others fail.**
   - **(A)** The proposal improves evaluation and does not reject model deployment.
   - **(B)** The proposal asks when threshold choices were settled, not that they are illegitimate.
   - **(C)** The point concerns meaning and validity of the score, not a preference for low accuracy.
   - **(D)** Camera shift is an example of changing conditions, not the sole determinant of cracks.

**Check:** The second proposal explains the score’s applicability even if its numeric result is lower.
::::
:::

:::problem[Question II.11]

Which one of the following evaluation plans most closely follows the author’s recommendations for a model intended to inspect boards from new suppliers?

- **(A)** Put one image of every board into the training set and another into the final test set.
- **(B)** Choose the model that achieves perfect training accuracy and omit all independent tests.
- **(C)** Tune thresholds repeatedly to maximize final test accuracy and report only that last value.
- **(D)** Train only on boards from one supplier and assume that results automatically extend to every other supplier.
- **(E)** Keep boards from selected suppliers out of development entirely, then test the final model on those suppliers and report the limits of the comparison.

::::solution[Solution]
**Answer:** (E)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The author advocates testing on genuinely new units that resemble the intended deployment population.
2. **Support.** New suppliers are the future units of interest, so independent supplier-based testing is especially relevant.
3. **Prephrase.** Choose an evaluation partition corresponding to the intended generalization claim.
4. **Why (E) is right.** Withholding entire suppliers matches the deployment population and an untouched final set preserves a meaningful check.
5. **Why the others fail.**
   - **(A)** This recreates the near-duplicate leakage the author warns against.
   - **(B)** Training perfection is not a generalization test.
   - **(C)** Repeated adaptation compromises the independence of the final test set.
   - **(D)** This ignores possible distribution shifts between suppliers.

**Check:** No images from held-out suppliers should influence model or threshold selection.
::::
:::

:::problem[Question II.12]

The author’s view of reducing model complexity is best described as...

- **(A)** a guaranteed means of preventing all deployment failures.
- **(B)** a potentially helpful intervention that can fail if it prevents learning genuine patterns.
- **(C)** an irrelevant change because model size never affects fitting to examples.
- **(D)** a practice that should always be forbidden in industrial quality control.
- **(E)** a method that makes separate test sets unnecessary.

::::solution[Solution]
**Answer:** (B)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author takes a balanced view: reducing complexity can curb overfitting but may also cause underfitting.
2. **Support.** The stance is conditional and balanced rather than categorical endorsement or rejection.
3. **Prephrase.** Find a choice preserving both benefit and limitation.
4. **Why (B) is right.** Paragraph 3 explicitly pairs reduced overfitting opportunity with the risk of an overly simple model.
5. **Why the others fail.**
   - **(A)** The passage states that no single remedy cures every problem.
   - **(C)** The passage explicitly connects complexity with fitting irrelevant detail.
   - **(D)** The author presents it as potentially useful, not forbidden.
   - **(E)** The author still advocates independent assessment despite model-selection strategies.

**Check:** Less capacity may reduce fitting to noise but may also omit real crack structure.
::::
:::

:::problem[Question II.13]

Which one of the following most accurately describes the organization of Passage 2?

- **(A)** It first proves a mathematical theorem and then derives factory safety rules from it.
- **(B)** It narrates the chronological invention of automated optical inspection and forecasts its commercial decline.
- **(C)** It compares two competing factories and recommends closing the less accurate one.
- **(D)** It introduces a goal, illustrates threats to measuring that goal, considers partial remedies, and uses a proposed audit to show the evaluative lesson.
- **(E)** It argues from the failure of one model that all machine-learning methods are unreliable.

::::solution[Solution]
**Answer:** (D)

**Type:** RC structure (Chapter 18)

1. **Conclusion.** The passage develops a sequence from learning objective through misleading tests to qualified remedies and audit evidence.
2. **Support.** The passage’s logical progression is expository and evaluative rather than historical or purely deductive.
3. **Prephrase.** Match the sequence and its reasoned qualification.
4. **Why (D) is right.** The paragraph map is objective → leakage example → remedies and limits → audit illustration.
5. **Why the others fail.**
   - **(A)** No theorem or formal derivation is offered.
   - **(B)** The structure is conceptual and illustrative, not historical.
   - **(C)** Only one hypothetical evaluation setting is used; no closure proposal appears.
   - **(E)** The conclusion concerns conditions of reliable evaluation, not categorical unreliability.

**Check:** P1 objective, P2 split threat, P3 limited safeguards, P4 audit lesson.
::::
:::

### Passage 3 (comparative)

**Passage A**

A generated image can be moving even when no human painted the individual marks on it. Yet admiration for the finished result is not the same as a reason to give someone a legal power to exclude others from reproducing it. Copyright policy, viewed as an arrangement for supporting artistic work, must ask whose creative activity the power is meant to encourage. A person who selects a prompt, rejects drafts, and arranges outputs may make consequential choices; such human selection can be examined on its own terms. But granting an exclusive right in every output merely because someone initiated a computational process would erase the distinction between composing an expressive work and requesting a result.

Some advocates for broad protection fear that unprotected generated images will be copied so rapidly that no one will fund useful creative tools. This prediction is possible, but it requires evidence about investment that is not established by the fact that copying is inexpensive. A policy can encourage human creative arrangement without granting a new exclusive right in every unattended output. The burden should rest with those proposing broader exclusivity to show that it produces cultural work that otherwise would not be made. Without such a showing, access and reuse are not defects awaiting correction; they may themselves support artistic experimentation. For that reason, an independent right in unattended outputs lacking any creative human selection should not be created. If supporting the development of generative tools is desirable, other incentives could be considered without treating every result as an exclusive artistic possession.

**Passage B**

Debates about machine-generated art often begin with the question of whether a machine can be an author. That question, while provocative, does not by itself settle what legal incentives might help artists and small creative studios. Suppose a studio invests in building a distinctive system for producing educational animations but cannot justify publishing the resulting animations because rivals could instantly duplicate them. A narrowly limited right in some outputs might make publication worthwhile, even if no machine is described as a person and no operator claims to have composed every frame.

Such a right need not resemble the expansive monopoly critics fear. Policymakers could require evidence of substantial production investment, grant a short term, and preserve broad permissions for quotation, study, and transformative reuse. Those design details matter more than a metaphysical verdict about machine creativity. Of course, a new exclusive right should not be enacted without empirical evidence that it improves production and access on balance. Still, refusing to consider output-based protection until someone proves a machine possesses intention makes a philosophical condition into a policy veto. The relevant question is comparative: would a carefully bounded incentive produce more publicly available creative material than a regime without it? That inquiry could include outputs generated with no human choices about individual expressive details. Whether any new right is worth its costs would depend on evidence, not on automatically treating tool ownership as authorship.

:::problem[Question II.14]

Passages A and B are most clearly in disagreement about whether...

- **(A)** policy should consider evidence about the effects of rights on creative production.
- **(B)** a human may make consequential selections when working with generative systems.
- **(C)** a carefully limited exclusive right in some machine-generated outputs should remain a policy option even without attributing authorship to a machine.
- **(D)** all machine-generated images are aesthetically worthless.
- **(E)** any exclusive rights granted to generated material must last forever.

::::solution[Solution]
**Answer:** (C)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** The question tests the disputed status of a limited right in outputs lacking individual human expressive choices.
2. **Support.** Both acknowledge possible incentive arguments and empirical scrutiny, but assign different openness to a new output-centered right.
3. **Prephrase.** Find a point on which both authors take positions; avoid treating one author’s silence as disagreement.
4. **Why (C) is right.** A opposes broader automatic output exclusivity without a showing; B expressly keeps a carefully bounded output right under consideration independent of machine personhood.
5. **Why the others fail.**
   - **(A)** Both authors demand evidence about incentive effects.
   - **(B)** A affirms human selection; B does not deny it or settle this as the dispute.
   - **(D)** Neither claims that; A explicitly says they can move viewers.
   - **(E)** Neither favors perpetual rights; B proposes a short term.

**Check:** A favors protecting human creative contribution without default output right; B considers a limited output right as an option.
::::
:::

:::problem[Question II.15]

Which one of the following would both authors be most likely to accept?

- **(A)** Claims that new exclusivity will improve creative production should be assessed using evidence rather than inferred merely from ease of copying.
- **(B)** Every generated image must receive the same protection as a traditionally painted work.
- **(C)** A machine must possess human-like intention before any output-based policy can even be evaluated.
- **(D)** Public reuse can never contribute to artistic innovation.
- **(E)** All human editing of model outputs should be disregarded by copyright policy.

::::solution[Solution]
**Answer:** (A)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** The passages share an insistence on evidence that an exclusive right would improve creative production and access.
2. **Support.** They differ on the possibility of a new right but agree that untested assumptions are inadequate.
3. **Prephrase.** Use the “both must have a stake” filter: verify a positive commitment in each passage.
4. **Why (A) is right.** A demands evidence of additional work; B demands empirical evidence of production and access benefits.
5. **Why the others fail.**
   - **(B)** A rejects automatic rights; B proposes narrow conditional rights instead of automatic equivalence.
   - **(C)** B explicitly objects to this philosophical prerequisite.
   - **(D)** A explicitly regards access and reuse as potentially productive.
   - **(E)** A emphasizes human selection; B does not mandate disregarding it.

**Check:** A: burden to show cultural benefit; B: right should not be enacted without evidence of net improvement.
::::
:::

:::problem[Question II.16]

How would the author of Passage A most likely respond to Passage B’s hypothetical animation studio?

- **(A)** By asserting that the studio cannot have invested any resources because software generated the animations.
- **(B)** By accepting any copying risk as sufficient proof that broad permanent exclusivity is necessary.
- **(C)** By asking for evidence that the proposed limited right would generate work that would otherwise not be published, while preserving room for reuse.
- **(D)** By requiring lawmakers to recognize the generating system as a legal person before evaluating incentives.
- **(E)** By arguing that educational animations are not cultural works capable of public benefit.

::::solution[Solution]
**Answer:** (C)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** The hypothetical studio tests whether A would accept an investment argument without proof of additional work.
2. **Support.** The studio is a proposed example of underinvestment; A would investigate rather than concede the causal prediction.
3. **Prephrase.** Apply A’s stated burden of proof to B’s illustrative case.
4. **Why (C) is right.** A expressly challenges the inference from low copying costs to new rights and demands additional-production evidence.
5. **Why the others fail.**
   - **(A)** A does not deny that tools and production can require investment.
   - **(B)** A rejects inference from cheap copying alone and fears broad rights.
   - **(D)** A focuses on human creativity and evidence, not machine personhood as a prerequisite.
   - **(E)** No distinction excluding education from cultural benefit appears.

**Check:** Low copying cost is a premise for a hypothesis, not proof of investment loss.
::::
:::

:::problem[Question II.17]

The final sentence of Passage B most nearly expresses the view that...

- **(A)** copyright policy for generated outputs should be assessed by comparing practical effects of feasible policy choices.
- **(B)** the metaphysical question of machine intention has already been scientifically settled.
- **(C)** a new right is justified regardless of whether it improves public access.
- **(D)** human artistic judgment can be measured precisely from prompt length.
- **(E)** any form of quotation or transformative reuse should require a license.

::::solution[Solution]
**Answer:** (A)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** B shifts the focus from machine personhood to a comparison of policy consequences.
2. **Support.** B replaces a question about whether machines are persons with a practical incentive comparison.
3. **Prephrase.** Identify the empirical policy frame rather than an assertion about metaphysics.
4. **Why (A) is right.** The comparative question asks how more output becomes available under a bounded right versus no right.
5. **Why the others fail.**
   - **(B)** Passage B expressly avoids resolving whether machines possess intention before considering policy choices.
   - **(C)** B demands evidence about production and access on balance.
   - **(D)** B never proposes prompt length as a measure.
   - **(E)** B explicitly proposes preserving broad permissions for reuse.

**Check:** “Would ... produce more publicly available creative material” supplies the test.
::::
:::

:::problem[Question II.18]

Which one of the following best describes a difference in the approaches of the passages?

- **(A)** A offers an economic formula; B supplies an exhaustive history of copyright disputes.
- **(B)** A argues machines are conscious; B demonstrates that consciousness is impossible.
- **(C)** A focuses exclusively on studio accounting while B addresses only individual artists’ emotions.
- **(D)** A supports all new exclusivity; B rejects even limited rights under all conditions.
- **(E)** A emphasizes the risks of creating broad exclusions without proof of additional artistic production, whereas B sketches a limited output-based incentive and a way to test it.

::::solution[Solution]
**Answer:** (E)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** A argues against new output exclusivity absent human selection; B entertains a conditional narrow output right.
2. **Support.** Both reason about creative incentives, but they emphasize different default positions toward creating new rights.
3. **Prephrase.** Match each author’s position and argumentative move without reversing them.
4. **Why (E) is right.** A foregrounds the burden against automatic expansion; B describes narrow criteria and a comparative test of benefits.
5. **Why the others fail.**
   - **(A)** Neither passage includes a formula or historical survey.
   - **(B)** Both avoid answering consciousness as a factual matter.
   - **(C)** A discusses cultural production and public reuse; B includes production incentives and access.
   - **(D)** This reverses their positions on an output-centered right.

**Check:** A worries about rights granted merely for initiating computation; B imagines short, conditional protection.
::::
:::

:::problem[Question II.19]

Passage B implies that its author regards which claim as possible, though not yet established?

- **(A)** Any investment in machine-learning tools creates a current, enforceable copyright in all outputs.
- **(B)** A machine cannot generate imagery unless a human specifies every individual frame.
- **(C)** The societal costs of restricting reuse are always zero when a term is short.
- **(D)** Under some conditions, a restricted output right could induce publication of works that otherwise would not appear.
- **(E)** Every studio would publish more material if rights were made permanent.

::::solution[Solution]
**Answer:** (D)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** B treats a studio’s reluctance to publish as a possible circumstance, not an established universal fact.
2. **Support.** The imagined studio would publish only with an incentive; this could support a limited rights policy if verified.
3. **Prephrase.** Choose a possibility framed as conditional rather than a universal current legal entitlement.
4. **Why (D) is right.** B offers the studio as a possibility that warrants empirical evaluation and explicitly declines to claim proof.
5. **Why the others fail.**
   - **(A)** B proposes a possible future policy rather than describing existing law.
   - **(B)** The studio example presupposes generated animation, not frame-by-frame human authorship.
   - **(C)** B says a comparison of production and access is required.
   - **(E)** The hypothesis is restricted to some conditions and a narrowly limited right.

**Check:** “Suppose a studio ... cannot justify publishing” is a hypothesis, not evidence of universal behavior.
::::
:::

:::problem[Question II.20]

Both passages suggest that a proposal regarding generated works would be inadequately justified if it rested solely on which one of the following?

- **(A)** Evidence that the proposal would change how many works are made available.
- **(B)** The observation that digital copies can be produced cheaply.
- **(C)** An analysis of potential impacts on artistic reuse.
- **(D)** A comparison of incentives under two specified legal regimes.
- **(E)** The recognition that people can exercise judgment in arranging generated outputs.

::::solution[Solution]
**Answer:** (B)

**Type:** RC comparative (Chapter 17)

1. **Conclusion.** Both authors reject an automatic rights inference based solely on cheap copying.
2. **Support.** Each author requires an incentive justification beyond the ease of reproducing digital files.
3. **Prephrase.** Find a shared rejected shortcut rather than their different proposed legal defaults.
4. **Why (B) is right.** A explicitly rejects cheap copying as enough to justify exclusion; B says empirical comparison remains necessary.
5. **Why the others fail.**
   - **(A)** Both demand examination of consequences for production and access.
   - **(C)** A explicitly values reuse; B preserves it as a policy consideration.
   - **(D)** That is B’s central proposal, compatible with A’s evidence demand.
   - **(E)** A values that human contribution; neither treats it as sufficient by itself to justify all output rights.

**Check:** Cheap copying alone does not establish net social gains from new rights in either passage.
::::
:::

### Passage 4

People often describe personal data as something consumers trade for a free service. That metaphor captures one aspect of an exchange: a person may permit an application to collect information in return for access. But it can conceal two complications. First, the person may not know what future uses will be derived from information supplied today. Second, a record about one person can help predict the behavior of others who never agreed to that exchange. The value generated by a collection of records is therefore not always the sum of separate, informed bargains over each record.

In a hypothetical market, two fitness applications sell advertising based on the activity patterns users provide. Application Clearstep allows people to refuse secondary uses and explains the options in plain language. Application Quickstride offers the same initial features but buries its data terms in a lengthy notice. At first, Quickstride obtains more data, and some observers conclude that users value convenience more than control. Yet this conclusion assumes that a failure to object reflects a preference rather than a failure to notice the choice. Comparing click rates without accounting for how alternatives are presented confuses behavior with informed valuation.

Economists can analyze these choices without assuming that every privacy concern is reducible to money. A user’s willingness to pay for greater privacy might reveal something about preferences under a particular set of prices, information, and available alternatives. It cannot, by itself, reveal the value of protecting other people whose characteristics can be inferred from that user’s data. This is an externality: part of the effect of an individual’s decision falls on people outside the transaction. Nor does an advertiser’s willingness to pay for aggregated records necessarily equal the benefit received by the people described in them. That payment measures what the buyer expects the records to be worth to the buyer.

Policy responses therefore face a design problem rather than a simple choice between banning collection and trusting every click. Rules requiring clearer choices may improve consent, but disclosures alone cannot give an individual control over deductions made from other people’s records. Limits on certain downstream uses could address that gap, although such limits might also restrict research or services with genuine public benefits. The author favors assessing each intervention by which failure it addresses and whose interests it changes. The market does provide information about what some parties want. It does not automatically produce a complete accounting of everyone affected by the information it trades. For example, a consent form can improve a participant’s understanding without giving absent neighbors a seat in the bargain. At the same time, restrictions designed for one harmful inference should not be assumed to improve every downstream use. The effects to be compared depend on the information, the audience, and the purpose for which predictions are made.

:::problem[Question II.21]

Which one of the following most accurately states the main point of Passage 4?

- **(A)** The best privacy policy is to ban every form of behavioral data collection.
- **(B)** Personal-data transactions do not necessarily account for all affected parties, so privacy policy should target specific failures rather than treat observed choices as complete measures of welfare.
- **(C)** Consumers knowingly value convenience above privacy whenever they accept default terms.
- **(D)** Advertisers should determine the rights of nonusers because they pay for aggregated data.
- **(E)** Clearer notices alone can eliminate every privacy externality.

::::solution[Solution]
**Answer:** (B)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author concludes that personal-data exchanges often omit third-party interests, warranting carefully targeted policy.
2. **Support.** The paragraphs move from trade metaphor limitations to a choice example, externalities, and qualified interventions.
3. **Prephrase.** Choose the qualified thesis concerning market information and incomplete accounting.
4. **Why (B) is right.** The author connects imperfectly informed consent and effects on third parties to policy evaluation tailored to distinct failures.
5. **Why the others fail.**
   - **(A)** The author rejects the simple ban-versus-click dichotomy and recognizes legitimate benefits.
   - **(C)** The passage challenges precisely that inference from non-objection.
   - **(D)** The advertiser’s willingness to pay reflects the buyer’s value, not nonusers’ welfare.
   - **(E)** The passage says disclosures cannot control inferences from other people’s records.

**Check:** The final sentence denies that transactions supply a complete account of everyone affected.
::::
:::

:::problem[Question II.22]

According to Passage 4, what complicates the inference that Quickstride’s users preferred convenience over data control?

- **(A)** Clearstep charges a higher subscription fee than Quickstride.
- **(B)** Quickstride publicly commits to never collecting information.
- **(C)** The applications provide fundamentally different initial features.
- **(D)** Quickstride allows no users to decline secondary uses.
- **(E)** The choice not to object could result from failing to notice an option buried in a lengthy notice.

::::solution[Solution]
**Answer:** (E)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The example challenges the inference from Quickstride users’ failure to object to a genuine preference for convenience.
2. **Support.** Paragraph 2 contrasts a plain-language control with a buried notice.
3. **Prephrase.** Find the unobserved awareness condition on the purported preference inference.
4. **Why (E) is right.** The author questions whether observed non-objection reflects information failure rather than genuine preference.
5. **Why the others fail.**
   - **(A)** The passage specifies matching initial features, not differing subscription prices.
   - **(B)** It obtains more data and buries terms; no such promise is described.
   - **(C)** The example explicitly says the same initial features are offered.
   - **(D)** The concern is unclear presentation of choice, not an absolute absence of choice.

**Check:** Not objecting is not necessarily informed consent when an alternative is hard to notice.
::::
:::

:::problem[Question II.23]

Which one of the following can most reasonably be inferred from the author’s discussion of externalities?

- **(A)** An externality occurs only when a data buyer refuses to pay for information.
- **(B)** Every person whose behavior is inferred from data must have previously used the collecting application.
- **(C)** Even a fully informed user’s consent may leave privacy costs imposed on other people unaddressed.
- **(D)** Users’ choices are irrelevant to every privacy policy decision.
- **(E)** The harm to outsiders can always be measured precisely in dollars.

::::solution[Solution]
**Answer:** (C)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The externality discussion says one person’s data transaction can affect people outside it.
2. **Support.** Paragraph 3 defines costs falling on people outside the transaction as externalities.
3. **Prephrase.** Infer the limit of individual consent when third-party effects are present.
4. **Why (C) is right.** An agreement by the data subject cannot bind or fully account for people whose behavior becomes predictable using that information.
5. **Why the others fail.**
   - **(A)** The external effect concerns third parties regardless of payment between buyer and user.
   - **(B)** The opening explicitly says inferences can involve people who never agreed to the exchange.
   - **(D)** The author treats choices as informative but incomplete.
   - **(E)** The text cautions against reducing every privacy concern to a monetary valuation.

**Check:** If a record informs predictions about nonparticipants, consent by its supplier does not settle their interests.
::::
:::

:::problem[Question II.24]

Why does the author distinguish an advertiser’s willingness to pay from the benefit received by the people described in aggregated records?

- **(A)** To show that a market price reveals a buyer’s expected value without measuring the welfare of all affected people.
- **(B)** To argue that advertisers receive no benefit from personal information.
- **(C)** To demonstrate that people always receive a direct share of advertisers’ profits.
- **(D)** To establish that a willingness-to-pay measure must be mathematically inaccurate.
- **(E)** To suggest that data buyers should be forbidden from purchasing any records whatsoever.

::::solution[Solution]
**Answer:** (A)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The advertiser-price example illustrates that buyer valuation and overall social benefit are different quantities.
2. **Support.** Paragraph 3 develops the externality objection to treating market exchange as a complete accounting.
3. **Prephrase.** Identify the difference between measuring an advertiser’s benefit and measuring affected persons’ benefit.
4. **Why (A) is right.** The distinction supports the claim that a transaction price cannot stand in for total welfare.
5. **Why the others fail.**
   - **(B)** The distinction assumes the buyer expects value, not zero value.
   - **(C)** The passage describes advertiser valuations and offers no rule distributing advertising profits to data subjects.
   - **(D)** The author critiques whose valuation it measures, not the arithmetic of the measure.
   - **(E)** The passage recommends targeted evaluation rather than categorical prohibition.

**Check:** Expected value to buyer is not by definition the benefit to individuals represented in the data.
::::
:::

:::problem[Question II.25]

Which one of the following situations most directly illustrates the limitation of clearer notices discussed in the final paragraph?

- **(A)** An app user declines a secondary-use request because the disclosure is easy to understand.
- **(B)** A company simplifies a consent form and more users correctly understand the available choices.
- **(C)** An advertiser pays for a campaign after reviewing an accurate purchase invoice.
- **(D)** A nonuser’s commuting pattern can be inferred from aggregate information voluntarily shared by several coworkers who received clear notices.
- **(E)** A user receives too many reminders after voluntarily subscribing to a newsletter.

::::solution[Solution]
**Answer:** (D)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The final paragraph warns that clearer notices cannot control deductions from other people’s records.
2. **Support.** The final paragraph explicitly says disclosure alone cannot give one person control over deductions from others’ data.
3. **Prephrase.** Apply the externality argument in a setting with fully clear notices.
4. **Why (D) is right.** The coworkers’ consent cannot control what the data permits others to infer about a nonuser.
5. **Why the others fail.**
   - **(A)** That is a success of clear notice, not its inability to control external effects.
   - **(B)** This again illustrates the benefits of disclosure, not its stated limit.
   - **(C)** Billing transparency is unrelated to inferences about nonparticipants.
   - **(E)** Unwanted reminders to the consenting person are not the described third-party inference gap.

**Check:** Even ideal consent forms cannot grant the nonuser control of inferences built from others’ information.
::::
:::

:::problem[Question II.26]

The author’s attitude toward limits on downstream uses of data is best characterized as...

- **(A)** open to targeted restrictions while attentive to the useful research and services they might foreclose.
- **(B)** categorically opposed to restrictions because markets always reveal everyone’s preferences.
- **(C)** unreservedly favorable to restrictions regardless of consequences.
- **(D)** convinced that notices alone solve all third-party effects.
- **(E)** indifferent to whether interventions address identifiable problems.

::::solution[Solution]
**Answer:** (A)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author sees possible benefits and costs in targeted downstream restrictions.
2. **Support.** The last paragraph both identifies the gap and cautions about restrictions’ costs.
3. **Prephrase.** Look for an attitude combining openness and evaluation, not categorical certainty.
4. **Why (A) is right.** The author sees downstream limits as one possible answer to externalities but stresses tradeoffs and targeted design.
5. **Why the others fail.**
   - **(B)** The passage denies that markets capture all interests.
   - **(C)** The author expressly cautions that restrictions can limit beneficial services and research.
   - **(D)** The final paragraph expressly states that disclosures alone cannot address all third-party inferences.
   - **(E)** The author explicitly favors judging each measure by the failure it addresses.

**Check:** “Could address that gap, although” signals conditional support with a caveat.
::::
:::

:::problem[Question II.27]

Which one of the following best describes the organization of Passage 4?

- **(A)** It begins with a court decision and concludes with a survey of historical privacy statutes.
- **(B)** It derives consumer preferences from a controlled laboratory experiment and then rejects economics entirely.
- **(C)** It qualifies a common exchange metaphor, tests an inference using a hypothetical example, develops a third-party-effect problem, and evaluates policy responses.
- **(D)** It presents a mathematical model before proving every market transaction inefficient.
- **(E)** It catalogues technical encryption methods without taking a position on regulation.

::::solution[Solution]
**Answer:** (C)

**Type:** RC structure (Chapter 18)

1. **Conclusion.** The argument moves from a trade metaphor to a problematic choice example, then externalities and policy options.
2. **Support.** Each subsequent paragraph adds a reason simple market consent is an incomplete criterion.
3. **Prephrase.** Match the four-paragraph map without turning nuance into total rejection.
4. **Why (C) is right.** The passage proceeds from metaphor critique to notice example to externality to policy design.
5. **Why the others fail.**
   - **(A)** Neither cases nor legal history structure the passage.
   - **(B)** The applications are hypothetical, and the author does not reject economic analysis.
   - **(D)** No formal model or universal inefficiency theorem appears.
   - **(E)** The passage concerns information and externalities, and it favors targeted policy analysis.

**Check:** P1 limits metaphor; P2 flawed inference; P3 externality; P4 response and tradeoff.
::::
:::

## 35.3 Section III: Logical Reasoning

:::problem[Question III.1]

A company’s records policy automatically deletes internal chat messages after a fixed interval. Its legal department recommends adding a mechanism that can suspend deletion for messages relevant to a dispute. The department concedes that automatic deletion ordinarily reduces storage burdens and simplifies routine administration. But once a dispute makes particular messages relevant, the predictable benefits of ordinary deletion must yield to the need to preserve potentially pertinent evidence. The company can keep the general deletion schedule while implementing targeted exceptions, so the two administrative aims need not be treated as mutually exclusive.

Which one of the following most accurately states the argument’s main conclusion?

- **(A)** Routine deletion can reduce storage burdens for a company.
- **(B)** Every employee chat message should be kept indefinitely.
- **(C)** The company is already facing an adjudicated lawsuit concerning deleted messages.
- **(D)** The company should equip its deletion system with a targeted preservation mechanism for relevant messages.
- **(E)** Preserving relevant messages is necessarily cheaper than deleting them.

::::solution[Solution]
**Answer:** (D)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The legal department recommends retaining routine deletion but adding a mechanism that preserves dispute-relevant messages.
2. **Support.** It grants deletion’s advantages and argues for a limited exception when relevant evidence requires preservation.
3. **Prephrase.** Distinguish the advocated exception from background concessions.
4. **Why (D) is right.** The department’s recommendation is the policy the considerations about evidence and storage are marshaled to support.
5. **Why the others fail.**
   - **(A)** This is an admitted benefit of current practice, not the recommendation.
   - **(B)** The argument endorses routine deletion outside targeted exceptions.
   - **(C)** No actual lawsuit or judicial finding is stated.
   - **(E)** The argument balances purposes rather than proving preservation has the lower cost.

**Check:** Targeted preservation is the claim supported by the competing concerns and their reconciliation.
::::
:::

:::problem[Question III.2]

A security office introduced a short course on recognizing fraudulent login pages. Employees who completed the course were less likely to enter credentials during a later simulated phishing exercise than employees who did not complete it. The director attributes the difference to the training. Critics note that employees who registered voluntarily might already have been more cautious about unfamiliar links. The office is considering making the course mandatory but wants stronger evidence that it actually changes behavior rather than merely identifying careful workers.

Which one of the following, if true, most strengthens the director’s explanation?

- **(A)** Employees selected at random to receive the course were subsequently less likely to submit credentials than comparable employees randomly assigned not to receive it.
- **(B)** The course mentions several common features of misleading login pages.
- **(C)** The employees who volunteered for training tended to work in technical departments.
- **(D)** Most employees said they enjoyed the short course.
- **(E)** The phishing exercise used a different logo from the company’s real login page.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The director attributes improved phishing performance to training, while critics identify voluntary selection as an alternative.
2. **Support.** Voluntary trainees could differ from nontrainees before the program.
3. **Prephrase.** Control the selection effect by assigning training independently of employee caution.
4. **Why (A) is right.** Random assignment breaks the association between prior caution and choosing training, providing stronger causal evidence.
5. **Why the others fail.**
   - **(B)** Course content provides a possible mechanism but does not separate selection from impact.
   - **(C)** This could strengthen the selection objection instead of supporting the causal claim.
   - **(D)** Enjoying a course does not establish any reduction in risky credential-submission behavior.
   - **(E)** The logo detail does not show whether training caused the between-group performance gap.

**Check:** Random groups differing only in course exposure allow a more credible causal inference.
::::
:::

:::problem[Question III.3]

A robotics startup wants to send its prototype diagrams to a potential manufacturing partner. Its operations officer argues that signing a mutual confidentiality agreement is sufficient to protect the diagrams, because the contract obliges each party to avoid unauthorized disclosure. The partner will need the diagrams to estimate tooling costs. The officer is not promising that secrecy will eliminate all commercial risks; rather, she insists that the signed agreement will prevent any meaningful unauthorized access to the diagrams, even once the partner’s subcontractors begin the estimating work.

Which one of the following is an assumption required by the operations officer’s argument?

- **(A)** The partner will never use subcontractors for any purpose.
- **(B)** The diagrams are protected by an issued patent in every country.
- **(C)** The confidentiality obligations or effective access controls will prevent unauthorized subcontractors from obtaining the diagrams.
- **(D)** The partner will find it inexpensive to manufacture the prototype.
- **(E)** Every employee of the startup will remain employed for at least five years.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The officer claims a bilateral confidentiality agreement will prevent meaningful unauthorized access even during subcontracted work.
2. **Support.** The agreement binds the named parties, while the claim extends to subcontractors who will participate.
3. **Prephrase.** Use the negation test on the gap between parties’ commitments and downstream access.
4. **Why (C) is right.** If unbound or uncontrolled subcontractors can access the diagrams, a bilateral signature alone does not ensure the promised prevention.
5. **Why the others fail.**
   - **(A)** The scenario anticipates subcontractors, and protection could occur through controls rather than their absence.
   - **(B)** Patent status is not required for contractual or practical secrecy.
   - **(D)** Tooling price has no bearing on the claimed prevention of access.
   - **(E)** Staff retention is unrelated to whether partner subcontractors access diagrams.

**Check:** Negate it: uncontrolled subcontractors can obtain the diagrams, defeating the no-meaningful-unauthorized-access claim.
::::
:::

:::problem[Question III.4]

A cloud provider promised that if its monthly availability dropped below a specified threshold, customers would receive a service credit. Several customers received credits in March. A salesperson therefore announced that the provider had necessarily breached its availability threshold that month. The contract, however, separately allowed discretionary goodwill credits after customer-support failures, even when the availability threshold had been met. The salesperson knows that below-threshold availability is sufficient to trigger a credit but treats the existence of credits as decisive evidence of the condition that normally triggers them.

The salesperson’s argument is most vulnerable to criticism because it...

- **(A)** assumes that an availability threshold is itself a guarantee of perfect security.
- **(B)** treats a contractual promise as legally invalid because some customers received compensation.
- **(C)** infers that every customer must have experienced an outage in March.
- **(D)** compares two companies without accounting for different contract terms.
- **(E)** infers a particular triggering condition from a benefit that can also be provided for other reasons.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The salesperson concludes that service credits prove a breach of the availability threshold.
2. **Support.** The credit is an effect with multiple possible triggering conditions.
3. **Prephrase.** Identify affirming the consequent rather than a problem with how credits are calculated.
4. **Why (E) is right.** Below-threshold → credit does not yield credit → below-threshold because a goodwill route also exists.
5. **Why the others fail.**
   - **(A)** The stated contractual trigger concerns service availability and credits, not guaranteed security.
   - **(B)** The salesperson asserts a breach, not invalidity of the contract.
   - **(C)** The conclusion concerns threshold breach, not each customer’s service experience.
   - **(D)** The argument draws an inference from one provider’s service credits, without any intercompany comparison.

**Check:** Goodwill credits provide a counterexample to credit → threshold breach.
::::
:::

:::problem[Question III.5]

A fictional team’s deployment rules say that every emergency production change is logged. Any logged change involving customer data is reviewed by a privacy engineer. Changes that are both emergency changes and involve customer data may proceed only if the on-call lead authorizes them. A patch installed at 2 a.m. was an emergency production change involving customer data. The patch was installed in compliance with the rules. The team does not say whether the patch was tested, whether it changed visible features, or which engineer originally wrote it.

Which one of the following must be true?

- **(A)** The patch received an independent external audit before installation.
- **(B)** The patch was logged, reviewed by a privacy engineer, and authorized by the on-call lead.
- **(C)** The patch was authored by the privacy engineer who reviewed it.
- **(D)** Every logged change at the company involves customer data.
- **(E)** The patch was the only emergency change deployed that night.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** The question asks which safeguards necessarily applied to a compliant emergency patch concerning customer data.
2. **Support.** The rules are universal and the specific patch meets the stated antecedents.
3. **Prephrase.** Chain the conditionals and use the fact of rule-compliant installation.
4. **Why (B) is right.** All three conditions follow: emergency → logged; logged with customer data → privacy review; emergency plus customer data and compliant installation → lead authorization.
5. **Why the others fail.**
   - **(A)** The rules say nothing about external audits.
   - **(C)** The obligation to review a change does not identify who originally authored the patch.
   - **(D)** Only one direction for a subset of logged changes is given.
   - **(E)** The number of other changes is unreported.

**Check:** Emergency ∧ customer data plus compliance entails all three required safeguards.
::::
:::

:::problem[Question III.6]

An electronics firm redesigned an online setup guide after users reported confusion. In controlled usability sessions, participants using the revised guide completed setup faster and made fewer mistakes. Yet the number of setup-related support calls rose in the month after the revised guide went live. The product line, support number, and classification of calls remained the same. Managers are puzzled because the guide seems to help users who actually follow it, and the firm expected fewer requests for assistance rather than more.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The revised guide uses more examples of completed setup screens than the original.
- **(B)** At the same time the guide changed, a retailer began selling many more units to customers unfamiliar with this category of device, increasing total first-time setups.
- **(C)** The most experienced support specialists were retained after the new guide appeared.
- **(D)** The controlled usability sessions covered common setup tasks.
- **(E)** Users who complete setup without errors almost never call support afterward.

::::solution[Solution]
**Answer:** (B)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The puzzle is greater support-call volume despite a guide that improves individual setup performance.
2. **Support.** Controlled sessions establish a per-user advantage; total support volume also depends on population size and composition.
3. **Prephrase.** Distinguish rates of difficulty from the total number of opportunities for difficulty.
4. **Why (B) is right.** Per-user success may improve while total calls rise because far more inexperienced users are now attempting setup.
5. **Why the others fail.**
   - **(A)** This may aid the observed usability improvements but does not explain more total support calls.
   - **(C)** Staff experience bears on handling calls, not why users generated more of them.
   - **(D)** This lends relevance to the test results but does not account for the population-wide call total.
   - **(E)** That confirms a per-user mechanism but not why the number of users requiring help rose.

**Check:** Calls = number of new users × probability of calling; volume can rise while probability falls.
::::
:::

:::problem[Question III.7]

A phone developer blames a third-party analytics SDK for a sharp increase in battery consumption. The battery problem appeared in the release that first included the SDK, and removal of the SDK is now proposed. During that release cycle, the team also replaced the graphics renderer, but the developer considers this an unlikely cause because rendering occurs only when the screen is active. The team has not yet conducted a comparison that separately toggles the SDK and the renderer, and the developer urges a quick decision.

Which one of the following, if true, most weakens the developer’s argument?

- **(A)** The SDK includes a privacy notice in its developer documentation.
- **(B)** The renderer sometimes draws frames at a lower resolution.
- **(C)** The app’s users include people with several different phone models.
- **(D)** On otherwise identical builds, enabling the new renderer greatly increases battery use even with the SDK absent, while adding the SDK causes little additional increase.
- **(E)** The SDK was developed by a company larger than the phone developer.

::::solution[Solution]
**Answer:** (D)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The developer concludes that adding the analytics SDK caused a battery drain also possibly attributable to a renderer change.
2. **Support.** Two changes coincided with the rise, and neither had been independently tested.
3. **Prephrase.** Find a direct comparison isolating both candidate causes.
4. **Why (D) is right.** The controlled builds assign most of the drain to the renderer rather than the SDK.
5. **Why the others fail.**
   - **(A)** Documentation does not show an effect on power consumption.
   - **(B)** Resolution by itself does not establish whether it drives the measured drain.
   - **(C)** Variation of devices does not isolate which code change caused the drain.
   - **(E)** Company size supplies no evidence on power use.

**Check:** SDK absent + renderer present still produces drain; SDK added changes little.
::::
:::

:::problem[Question III.8]

A researcher discovers a serious vulnerability in a networked door lock. She considers immediately posting technical details so users can understand their risk. A colleague worries that detailed instructions may assist attackers before any fix is available. They agree that a product’s manufacturer should not be allowed to suppress all criticism indefinitely. The researcher proposes a policy that respects eventual public disclosure while allowing a short period for coordinated repair when the specific details would enable exploitation.

Which one of the following principles would most strongly justify the proposed policy?

- **(A)** When technical details create a credible near-term exploitation risk, a limited repair window before full disclosure is warranted, provided the delay cannot become indefinite.
- **(B)** Vulnerability information should always remain confidential to prevent panic.
- **(C)** Researchers should publish immediately whenever a manufacturer requests time to fix a flaw.
- **(D)** Any defect that does not affect the researcher personally should be ignored.
- **(E)** Manufacturers should decide unilaterally whether their products can be criticized.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The researcher seeks a temporary exploitation-sensitive delay with eventual public disclosure.
2. **Support.** The stated tension is timely public information versus exploit-enabling technical details before a patch.
3. **Prephrase.** Choose a qualified risk-and-time rule rather than total secrecy or unconditional release.
4. **Why (A) is right.** The principle preserves both parts of the policy: short, justified postponement and guaranteed eventual disclosure.
5. **Why the others fail.**
   - **(B)** An indefinite ban contradicts the proposal for eventual publication.
   - **(C)** That rule eliminates the conditional repair window that the researcher endorses.
   - **(D)** The proposal concerns users’ risks, not only the researcher’s.
   - **(E)** Both speakers reject permanent suppression by the manufacturer.

**Check:** Credible exploit risk → temporary delay; not an indefinite veto.
::::
:::

:::problem[Question III.9]

A lawyer recommends that a prospective customer negotiate a written escalation path for severe service interruptions. **The vendor’s sales presentation promises attentive support, but the draft agreement sets out no timeframe for escalating a critical ticket.** Such a discrepancy may not mean the vendor intends poor service; presentations are frequently broad. Nevertheless, without agreed escalation terms the customer may have difficulty establishing whether a delayed response violates the negotiated service commitment. The lawyer’s goal is to turn an important expectation into a sufficiently definite operational obligation.

The statement in boldface plays which one of the following roles?

- **(A)** It supplies the conclusion that the vendor has already breached its agreement.
- **(B)** It is a concession that all sales presentations are fraudulent.
- **(C)** It identifies a gap between informal assurance and contractual detail that motivates the recommendation.
- **(D)** It establishes that the vendor will necessarily refuse to provide support.
- **(E)** It introduces a rival proposal to replace escalation rules with an oral promise.

::::solution[Solution]
**Answer:** (C)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The lawyer advises negotiating precise escalation terms; the bold sentence identifies the gap motivating that advice.
2. **Support.** The lawyer moves from a documentation gap to the need for a definite term, without claiming deception.
3. **Prephrase.** Classify the bold statement as a supporting description of the problem.
4. **Why (C) is right.** The observation about the sales assurance and missing contractual timing explains why the lawyer wants explicit escalation terms.
5. **Why the others fail.**
   - **(A)** The agreement is still a draft and no breach is alleged.
   - **(B)** The lawyer specifically avoids inferring bad intent.
   - **(D)** Lack of explicit timing does not establish refusal.
   - **(E)** The bold statement describes the problem, not an endorsed alternative.

**Check:** Sales promise without timing → negotiation for enforceable escalation language.
::::
:::

:::problem[Question III.10]

Two project-management apps offered different free trials. App Meridian offered a thirty-day trial and attracted more registrations than App Delta, which offered a seven-day trial. Meridian’s marketing director concludes that customers place a higher value on Meridian’s paid product. But Meridian advertised on several popular websites, while Delta advertised only through its own newsletter. The two products also had different subscription prices. The director has measured trial registrations, not how much customers would pay or how they would evaluate the products after testing them.

The director’s argument is most vulnerable to criticism because it...

- **(A)** assumes that trial registrations are impossible to count accurately.
- **(B)** argues that a seven-day trial is always unlawful.
- **(C)** concludes that Meridian and Delta charge exactly the same price.
- **(D)** deduces that all users who register will become loyal customers.
- **(E)** uses a difference in trial registrations, potentially explained by marketing exposure, as a measure of relative willingness to pay for paid products.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director concludes more trial registrations establish greater customer valuation of the paid product.
2. **Support.** More registrations could result from promotion or trial terms without greater product valuation.
3. **Prephrase.** Find the mismatched measure and the unaddressed rival explanation.
4. **Why (E) is right.** Acquisition volume is confounded by advertising exposure and is not equivalent to willingness to pay.
5. **Why the others fail.**
   - **(A)** The counts may be accurate; the flaw lies in what they are said to prove.
   - **(B)** The stimulus makes no legal claim about trial durations.
   - **(C)** The stimulus expressly says the two apps had different subscription prices, contradicting this claim.
   - **(D)** The conclusion concerns higher relative value, not certainty of conversion for all users.

**Check:** Registration count ≠ paid valuation; promotional reach differs substantially.
::::
:::

:::problem[Question III.11]

Under a hypothetical service agreement, any vendor assigned the critical tier must complete an annual recovery drill. Every vendor that completes the annual recovery drill gets a compliance certificate. Northwind is assigned the critical tier and has completed the drill. A procurement officer concludes that Northwind is eligible for the company’s accelerated renewal process. The agreement, however, does not state that completion of the drill by itself provides accelerated renewal eligibility; the renewal process is governed by a separate policy.

Which one of the following, if assumed, enables the officer’s conclusion to be properly drawn?

- **(A)** Only vendors holding a compliance certificate may be eligible for accelerated renewal.
- **(B)** Some vendors that conduct drills qualify for accelerated renewal.
- **(C)** A vendor cannot complete a recovery drill without being assigned the critical tier.
- **(D)** Every accelerated renewal candidate must first be assigned the critical tier.
- **(E)** Every vendor holding a compliance certificate is eligible for accelerated renewal.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The officer wants accelerated renewal eligibility for Northwind from its critical tier, drill, and certificate.
2. **Support.** Critical tier and completed drill imply certification; accelerated renewal requires an additional bridge.
3. **Prephrase.** Complete drill → certificate → renewal-eligible without reversing the arrow.
4. **Why (E) is right.** Northwind has a certificate, so certificate → eligible supplies the needed bridge to renewal.
5. **Why the others fail.**
   - **(A)** This makes certification necessary for renewal but cannot establish renewal from certification.
   - **(B)** The existential statement need not cover Northwind.
   - **(C)** This adds a reverse drill condition but no bridge to renewal.
   - **(D)** This makes critical tier necessary, not sufficient, for accelerated renewal.

**Check:** Northwind completed drill → certificate; added premise certificate → eligibility.
::::
:::

:::problem[Question III.12]

A department head claims that buying the most expensive security suite is always the safest choice. A systems administrator replies that price by itself cannot guarantee suitability. One high-priced suite lacks support for the department’s older devices, which would force engineers to leave some machines unmonitored. A lower-priced suite supports those devices and meets the department’s specific monitoring requirements. The administrator does not conclude that cheaper products are always superior. Instead, she rejects a universal decision rule by presenting a case in which that rule would give an inferior result.

The systems administrator responds to the department head primarily by...

- **(A)** arguing that all security suites are equally effective regardless of cost.
- **(B)** showing that the highest-priced suite is never the safest possible option.
- **(C)** presenting a counterexample to an unrestricted claim about higher-priced products.
- **(D)** appealing to how popular a lower-priced suite is among consumers.
- **(E)** deducing that purchasing any suite necessarily reduces security.

::::solution[Solution]
**Answer:** (C)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The administrator challenges the assertion that the most expensive security suite is always the safest.
2. **Support.** The administrator shows a particular environment where the high-priced choice leaves systems uncovered.
3. **Prephrase.** Look for rejection of an absolute through a single inconsistent case.
4. **Why (C) is right.** The cheaper compatible suite is one counterexample sufficient to refute the director’s universal “always” claim.
5. **Why the others fail.**
   - **(A)** The administrator explicitly compares two suites based on compatibility, rather than claiming equal effectiveness.
   - **(B)** One unsuitable case disproves always, not every expensive option.
   - **(D)** The reason concerns specific device support, not market popularity.
   - **(E)** That opposite universal conclusion is not offered.

**Check:** One expensive inferior option disproves “most expensive is always safest”.
::::
:::

:::problem[Question III.13]

A data-center operator installed a new airflow-control algorithm on one floor and observed lower electricity use per unit of computing work than on an untreated floor. Its engineering manager argues that the controller caused the improvement and should be deployed throughout the facility. The treated floor hosted newer servers, and local technicians worried that more efficient machines might be responsible for the result. The manager agrees that a test comparing floors without accounting for hardware differences is inconclusive and requests a better basis for the deployment recommendation.

Which one of the following, if true, most strengthens the manager’s causal claim?

- **(A)** The algorithm’s user interface was popular with technicians.
- **(B)** When the algorithm was alternately enabled and disabled on the same servers under comparable computing loads, energy use was consistently lower while it was enabled.
- **(C)** The treated floor contained the largest number of newer servers in the building.
- **(D)** Electricity prices fell during the test period.
- **(E)** The algorithm was written in a programming language already used at the facility.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The manager concludes that deploying airflow control across the facility will lower energy use independent of server age.
2. **Support.** The original between-floor comparison could confuse hardware efficiency with algorithmic improvement.
3. **Prephrase.** Look for within-machine control with workload held roughly constant.
4. **Why (B) is right.** Toggling the algorithm on the same hardware under comparable load isolates its effect from server age.
5. **Why the others fail.**
   - **(A)** Ease of use does not prove energy savings.
   - **(C)** This makes the hardware-age alternative more credible rather than isolating the airflow algorithm’s effect.
   - **(D)** Price changes affect spending, not electricity consumed per unit of work.
   - **(E)** Implementation language does not establish a causal impact on energy use.

**Check:** Hardware and load fixed; change controller state → change energy intensity.
::::
:::

:::problem[Question III.14]

A chip-design consultancy argues that its new policy of giving clients read-only access to project notes will not expose proprietary client designs. The policy blocks file downloads and hides explicit project identifiers. Consultants can nevertheless describe measurements in the notes, and multiple clients may work on devices with distinctive performance profiles. The firm’s partner says identification cannot occur because visitors see neither the original file nor the customer’s name. She maintains that the protections eliminate every practical route by which one client might infer another client’s confidential design.

Which one of the following is an assumption required by the partner’s reasoning?

- **(A)** Every client design has a unique combination of physical dimensions.
- **(B)** The read-only interface is harder to copy from than an ordinary document viewer.
- **(C)** All contractors are bound by the consultancy’s internal confidentiality agreement.
- **(D)** No combination of measurements visible in the notes allows a visitor to identify another client’s confidential design.
- **(E)** The consultancy can trace which users viewed which notes.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The partner asserts that no identifying inference about a client design is possible through read-only project notes.
2. **Support.** The argument relies on preventing direct downloads and labels while ignoring inference from the remaining content.
3. **Prephrase.** Negate the choice that rules out re-identification through distinctive measurements.
4. **Why (D) is right.** If available measurements suffice to identify a design, the partner’s claim that practical inference is impossible fails despite hidden names.
5. **Why the others fail.**
   - **(A)** Unique dimensions need not be exposed in the notes and thus are not necessary for confidentiality.
   - **(B)** Preventing copying of files is separate from making inferences from permitted measurements.
   - **(C)** Contractual duties may help, but the partner claims recipients cannot infer protected client designs.
   - **(E)** Audit logs can detect access without necessarily preventing recognition of a design.

**Check:** Negation allows a visitor to infer a client design from measurements; the claim of complete protection collapses.
::::
:::

:::problem[Question III.15]

A bank offers free fraud monitoring to customers who choose to enroll. Customers who enrolled subsequently reported more suspicious transactions than customers who did not. The bank cannot tell from these counts whether the service caused people to encounter fraud or made them better at noticing it. Enrollment records show that customers who had already experienced account irregularities were disproportionately likely to sign up. A bank analyst cautions that a simple comparison between volunteers and nonvolunteers is not a reliable estimate of the effect of monitoring.

Which one of the following is most strongly supported by the statements above?

- **(A)** Past account problems may help explain why monitoring customers reported more suspicious activity even without any harmful effect of monitoring.
- **(B)** Fraud monitoring necessarily increases actual fraud among enrollees.
- **(C)** Enrollees were randomly assigned to the monitoring program.
- **(D)** Every customer who had an irregularity enrolled.
- **(E)** The bank’s fraud-detection technology is entirely ineffective.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The question asks what the unequal voluntary enrollment groups support, not whether monitoring itself raises fraud.
2. **Support.** Volunteers differ in past risk and possibly attention, undermining a naive causal inference.
3. **Prephrase.** Choose a restrained explanation consistent with selection; do not settle what monitoring causes.
4. **Why (A) is right.** Selection by prior irregularities creates a plausible preexisting difference that can raise reporting rates.
5. **Why the others fail.**
   - **(B)** The causal direction is unresolved, and awareness alone can affect reports.
   - **(C)** Enrollment was voluntary and skewed toward people with prior irregularities.
   - **(D)** A higher propensity is not universal enrollment.
   - **(E)** The information does not establish whether detection is effective or ineffective.

**Check:** Prior irregularities → greater likelihood of enrollment and potentially greater reported activity.
::::
:::

:::problem[Question III.16]

A hardware firm’s legal team won a favorable settlement concerning one well-documented patent claim. A vice president concludes that every claim in the firm’s entire portfolio is equally strong, and therefore every patent deserves the same annual litigation budget. He acknowledges that the portfolio covers different devices and was prepared by different inventors, but argues that a successful settlement demonstrates the legal team’s general skill. That ability, he says, is enough to guarantee similar outcomes for unrelated claims in materially different disputes.

The vice president’s argument is most vulnerable to criticism because it...

- **(A)** accepts the firm’s legal team as incapable of negotiating settlements.
- **(B)** assumes that every patent has exactly the same filing date.
- **(C)** projects the result of one particular claim onto a heterogeneous set of claims without establishing that their relevant strengths are alike.
- **(D)** argues that litigation is always cheaper than licensing.
- **(E)** rejects all evidence obtained from previous legal disputes.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The vice president projects a settlement on one patent claim to uniform strength and budgeting across an entire portfolio.
2. **Support.** The lawyer’s skill may be transferable, but claim-specific evidence and circumstances differ.
3. **Prephrase.** Name overgeneralization from an unrepresentative case, not the existence of settlement itself.
4. **Why (C) is right.** Outcome for one claim under one set of facts does not show equal strength and cost justification across unrelated claims.
5. **Why the others fail.**
   - **(A)** He asserts the team is skilled, not incapable.
   - **(B)** No filing dates or chronology are mentioned.
   - **(D)** Neither costs nor a licensing comparison supports the prediction.
   - **(E)** He relies heavily on one previous dispute, rather than rejecting its relevance entirely.

**Check:** One success + heterogeneous portfolio does not entail universal equal strength.
::::
:::

:::problem[Question III.17]

A hypothetical retention policy states that any dataset tagged as legally restricted is stored in an isolated repository. Every dataset in an isolated repository requires approval before export. The archive named Ember is tagged as legally restricted. The administrator concludes that Ember requires approval before export. She does not claim that all datasets needing approval are legally restricted, only that Ember falls into the established chain of conditions.

Which one of the following arguments is most similar in its reasoning?

- **(A)** Every licensed shop has a permit; Store K has a permit; therefore Store K is licensed.
- **(B)** Some vaccinated plants are disease-resistant; Seedling M is vaccinated; therefore it is disease-resistant.
- **(C)** Only trained guides may enter the cave; Inez is trained; therefore she may enter.
- **(D)** No library book is overdue; Volume N is overdue; therefore Volume N is a library book.
- **(E)** Every marine vessel in the research fleet carries a radio; every vessel carrying a radio must have a battery inspection; Vessel Tern is in that fleet; therefore it must have a battery inspection.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The archive’s storage rules establish that Ember requires export approval through a valid two-step chain.
2. **Support.** Two universal inclusion rules chain transitively to a named case.
3. **Prephrase.** Find two links in the same direction followed by an instance of the first class.
4. **Why (E) is right.** The valid form is restricted → isolated → approval; Ember restricted, therefore approval.
5. **Why the others fail.**
   - **(A)** It affirms the consequent rather than chaining in the given direction.
   - **(B)** Some does not establish a universal conditional for the individual.
   - **(C)** It confuses a necessary condition for entry with a sufficient one.
   - **(D)** The conclusion contradicts rather than follows the universal exclusion.

**Check:** Fleet → radio → battery inspection, Tern in fleet → inspection.
::::
:::

:::problem[Question III.18]

A streaming service replaced a complicated surcharge schedule with a simple displayed all-in monthly price. In a customer survey, fewer respondents said they were confused about charges afterward. Nevertheless, the number of billing complaints increased that quarter, even though the billing system made no additional errors. The service’s management had expected that clearer prices would reduce complaints and asked why greater understanding seemed to coincide with more objections. The survey included both long-term subscribers and recently recruited customers.

Which one of the following, if true, most helps to resolve the discrepancy?

- **(A)** Most customers noticed the new displayed monthly amount.
- **(B)** The average billed amount remained constant across the change.
- **(C)** The service sent billing reminders at the same frequency as before.
- **(D)** Once subscribers understood the all-in charge, more of them recognized that they disliked its amount and complained despite no longer being confused.
- **(E)** The service continued to answer all billing calls using the same support team.

::::solution[Solution]
**Answer:** (D)

**Type:** Resolve the paradox (Chapter 13)

1. **Conclusion.** The puzzle is more billing complaints after a price change that reduced confusion about the charges.
2. **Support.** The measured reduction in confusion concerns comprehension, while complaints can concern perceived unfairness.
3. **Prephrase.** Find a mechanism by which improved comprehension increases objections rather than decreases them.
4. **Why (D) is right.** Understanding and satisfaction are distinct: clear recognition of a disliked price can generate more complaints.
5. **Why the others fail.**
   - **(A)** This helps explain reduced confusion but not the rise in complaints without dissatisfaction.
   - **(B)** Unchanged amount does not establish how people reacted to understanding it.
   - **(C)** Constant reminder frequency does not account for more objections.
   - **(E)** Stable support staffing cannot itself explain an increase in customer complaints.

**Check:** Less confusion + clearer recognition of an unwelcome amount → more complaints.
::::
:::

:::problem[Question III.19]

An engineering team’s manager claims that outsourcing circuit-board assembly will shorten a medical-device prototype schedule. The new assembler quotes a lower manufacturing lead time than the in-house shop has recently achieved. The manager overlooks that the external assembler has never worked with this project’s unusually strict documentation workflow. The prototype cannot move to integration until production records have been checked and approved, and the manager’s comparison counts assembly time but excludes documentation review and shipping.

Which one of the following, if true, most weakens the manager’s prediction?

- **(A)** The external assembler’s required documentation review and shipping would add more time than its quoted assembly lead-time advantage.
- **(B)** The assembler’s quoted build cost is lower than the in-house cost.
- **(C)** The outside assembly work will require fewer individual solder joints.
- **(D)** The outside assembler has completed similarly sized batches for another client.
- **(E)** In-house assembly technicians currently work overtime on the prototype.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The manager predicts outside assembly will shorten the whole prototype schedule from a shorter assembly lead time alone.
2. **Support.** The manager assumes a shorter subtask means a shorter overall critical path.
3. **Prephrase.** Find costs in the omitted stages that reverse the schedule comparison.
4. **Why (A) is right.** The decisive unit is total time to integration, and uncounted steps exceed the nominal assembly savings.
5. **Why the others fail.**
   - **(B)** A saving in money does not resolve the schedule effect of documentation and transport.
   - **(C)** A shorter assembly subtask alone leaves the omitted review and shipping steps unexamined.
   - **(D)** Batch size history does not establish familiarity with this project’s approval workflow.
   - **(E)** Existing overtime may motivate outsourcing, but it does not establish the end-to-end timeline.

**Check:** Assembly saved time < documentation plus shipping delay → integration later.
::::
:::

:::problem[Question III.20]

General counsel: Employees should disclose personal technical projects to a designated reviewer when the projects substantially overlap with their assigned company research. The reviewer can then assess potential conflicts without treating every hobby as company property. Engineering manager: I agree that overlapping projects create possible conflicts and that company ownership should not be presumed. But I oppose requiring advance disclosure merely because subjects overlap. A project should be disclosed only when an employee proposes using restricted company materials in it.

The general counsel and engineering manager disagree over whether...

- **(A)** a company automatically owns every technical hobby project created by an employee.
- **(B)** a substantial overlap with an employee’s assigned research is itself enough to trigger a disclosure requirement.
- **(C)** restricted company materials may create concerns when used on a personal project.
- **(D)** employees should be prevented from having personal technical projects.
- **(E)** a designated reviewer could be given the power to adjudicate criminal liability.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Counsel and the manager disagree about whether overlap with assigned company work, by itself, triggers project disclosure.
2. **Support.** They share the concern about conflicts and a rejection of automatic ownership but dispute the trigger for disclosure.
3. **Prephrase.** Apply the both-sides-test to a single proposed disclosure rule.
4. **Why (B) is right.** Counsel says substantial overlap triggers review; the manager says overlap alone does not.
5. **Why the others fail.**
   - **(A)** Both speakers explicitly reject the idea that a company owns every employee project merely by default.
   - **(C)** Neither disputes the relevance of restricted material.
   - **(D)** Both envisage employees working on such projects.
   - **(E)** Criminal adjudication is never proposed by either speaker.

**Check:** Counsel: overlap sufficient; manager: overlap insufficient absent proposed use of restricted material.
::::
:::

:::problem[Question III.21]

A university computing unit has funds to fix only one of two recurring problems this week. A campus calendar export sometimes fails for a small number of users, while a laboratory access-control system occasionally denies authorized researchers entry during scheduled experiments. Both repairs are expected to take the same time. The unit’s policy committee says maintenance should be prioritized by the seriousness and immediacy of the disruption to core activities, not simply by the number of people who see an error message.

Which one of the following decisions most closely conforms to the committee’s principle?

- **(A)** Repair the laboratory access-control failure first because it can directly interrupt scheduled research, despite fewer affected users.
- **(B)** Repair calendar export first solely because more people use calendars.
- **(C)** Postpone both repairs indefinitely because the defects are intermittent.
- **(D)** Choose the repair whose error message is easiest to reproduce, ignoring consequences.
- **(E)** Fund a redesign of the entire website before addressing either failure.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The committee prioritizes the immediacy and severity of disruption to core activities over sheer user count.
2. **Support.** The committee weighs seriousness and immediacy rather than simple user counts.
3. **Prephrase.** Apply the criterion to the laboratory obstruction and calendar nuisance.
4. **Why (A) is right.** The choice prioritizes imminent interference with core research over sheer volume of inconvenience.
5. **Why the others fail.**
   - **(B)** This relies on head count alone rather than severity and immediacy.
   - **(C)** Intermittence does not eliminate foreseeable disruption to core activities.
   - **(D)** Reproducibility is not the stated priority criterion.
   - **(E)** A broad redesign ignores the given immediate maintenance choice.

**Check:** Given equal repair time, the more serious interruption to scheduled experiments receives priority.
::::
:::

:::problem[Question III.22]

A semiconductor company sells more microcontrollers than a smaller rival. Its marketing officer argues that its chips must therefore be more reliable. The company’s products are bundled with an inexpensive development board and are stocked by several large distributors, while the rival sells mostly through direct orders. The officer acknowledges those differences but contends that high sales volume itself is evidence that reliability must be superior, since consumers generally prefer products that work well.

The marketing officer’s reasoning is most vulnerable to criticism because it...

- **(A)** concludes that the company sold fewer chips than the smaller rival.
- **(B)** assumes that greater sales result from superior reliability without accounting for distribution, bundling, or other causes of purchasing decisions.
- **(C)** assumes that every purchased chip is inevitably defective.
- **(D)** compares products sold in exactly identical channels.
- **(E)** argues that reliability can never influence purchases.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The officer concludes that greater microcontroller sales show superior reliability.
2. **Support.** The officer moves from popularity to quality without excluding identified alternatives.
3. **Prephrase.** Name the popularity-to-quality inference and omitted causal explanations.
4. **Why (B) is right.** Sales can be higher for reasons other than reliability, including pricing bundles and retailer availability.
5. **Why the others fail.**
   - **(A)** The premise says the opposite and the officer accepts it.
   - **(C)** His claim is of greater, not lesser, reliability.
   - **(D)** The stimulus emphasizes channels are different, not identical.
   - **(E)** The officer invokes reliability as a factor; the error is treating it as the decisive explanation.

**Check:** Even less reliable chips could outsell a rival with broader distribution and a cheaper bundle.
::::
:::

:::problem[Question III.23]

A department regulation says that any student permitted to take Advanced Circuits must have passed Signals I. Valen has passed Signals I, and an advisor concludes that Valen is therefore permitted to take Advanced Circuits. The advisor overlooks the separate rule requiring completion of a laboratory safety course. No one disputes that passing Signals I is necessary for Advanced Circuits; the mistake is treating that necessary prerequisite as if it were the complete set of eligibility requirements.

Which one of the following arguments contains an error most similar to the advisor’s?

- **(A)** All museum volunteers receive badges. Ada is a museum volunteer. Therefore Ada receives a badge.
- **(B)** No unsupervised visitors may enter the vault. Lio is unsupervised. Therefore Lio may not enter.
- **(C)** All crowned winners passed the qualifying round. Mina did not pass that round. Therefore Mina was not crowned.
- **(D)** If a sensor is overheated it shuts down. This sensor overheated. Therefore it shuts down.
- **(E)** Every approved lifeguard has CPR certification. Oren has CPR certification. Therefore Oren is an approved lifeguard.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The advisor incorrectly infers course eligibility from one required prerequisite.
2. **Support.** Passing Signals I is necessary but lab safety is another eligibility requirement.
3. **Prephrase.** Find a different domain with exactly the same necessary-as-sufficient inversion.
4. **Why (E) is right.** Eligible → prerequisite passed; prerequisite passed → eligible is the invalid converse.
5. **Why the others fail.**
   - **(A)** The volunteer’s status satisfies the sufficient condition for receiving a badge, so the inference is valid.
   - **(B)** This validly applies an exclusion, unlike the advisor’s converse inference.
   - **(C)** This uses the valid contrapositive of a necessary condition.
   - **(D)** This is valid modus ponens, not affirming the consequent.

**Check:** Approved lifeguard → CPR; CPR does not entail approved lifeguard.
::::
:::

:::problem[Question III.24]

A factory uses robotic arms to place sensitive parts on circuit boards. After installing automated calibration checks, the factory observed fewer placement defects. A process engineer argues that the checks caused the decline. Management notes that the factory also changed solder suppliers and introduced a different inspection camera during the same period. The process engineer responds that placement accuracy is measured before soldering and seeks more direct evidence that calibration, rather than coincident process changes, accounts for the result.

Which one of the following, if true, most strengthens the engineer’s argument?

- **(A)** The new solder was delivered in larger containers than the old solder.
- **(B)** The inspection camera produced higher-resolution photographs.
- **(C)** On the same robot, batches assembled with calibration checking enabled repeatedly showed fewer pre-solder placement errors than matched batches with checking disabled.
- **(D)** The factory planned to purchase two more robotic arms next year.
- **(E)** The cost of the calibration software was lower than forecast.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The engineer claims calibration checks, rather than parallel manufacturing changes, reduced pre-solder placement defects.
2. **Support.** Several processes changed, but the desired outcome can be assessed directly at the relevant stage.
3. **Prephrase.** Look for matched, direct measurement of placement errors with calibration varied.
4. **Why (C) is right.** The within-robot enabled-versus-disabled comparison isolates calibration before the separate solder change could matter.
5. **Why the others fail.**
   - **(A)** Container size does not establish fewer pre-solder placement errors.
   - **(B)** Better measurement could alter detection counts, leaving causation unresolved.
   - **(D)** Future capacity purchases do not identify what changed existing error rates.
   - **(E)** Lower purchase cost is not evidence of defect reduction.

**Check:** Same robot + matched batches + pre-solder measurement: calibration state is the key difference.
::::
:::

:::problem[Question III.25]

A company’s patent committee can accept a modest licensing payment from a device maker or pursue an infringement claim under a hypothetical contract and patent dispute. The committee chair favors litigation because a successful court judgment might yield a larger recovery than the offered license. Another member warns that litigation expenses, the risk of losing, the time before recovery, and effects on an important customer relationship could make the apparently larger potential judgment less attractive. Neither option is assumed to be lawful or profitable merely because it exists.

Which one of the following questions would be most useful to answer in evaluating the chair’s reasoning?

- **(A)** How frequently have the parties negotiated license agreements in unrelated disputes?
- **(B)** Would the potential court judgment exceed the proposed license payment before legal fees?
- **(C)** Does the licensing payment arrive sooner than an estimated litigation judgment?
- **(D)** How do the probability-adjusted net proceeds and strategic costs of litigation compare with the value of accepting the license now?
- **(E)** Is the proposed license payment larger than the company’s most recent unrelated royalty?

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The chair favors litigation because of a higher possible gross judgment; the task is to evaluate the net comparison.
2. **Support.** The chair focuses on upside while omitting risk, cost, delay, and commercial relationships.
3. **Prephrase.** Compare expected outcomes of both options including relevant contingent costs.
4. **Why (D) is right.** Net expected value and strategic consequences, not maximum possible gross judgment, determine whether litigation beats the available license.
5. **Why the others fail.**
   - **(A)** Past negotiation frequency does not quantify this claim’s litigation costs, risks and opportunity costs.
   - **(B)** Gross recovery is the chair’s existing comparison and omits the probability and full costs.
   - **(C)** Timing matters, but this narrower fact by itself cannot settle the litigation risk and costs.
   - **(E)** Another royalty is an irrelevant benchmark for this dispute’s expected net return.

**Check:** Potential larger gross award can still yield a worse net outcome after probability and costs.
::::
:::

## 35.4 Scoring and review

Open the answer key only after completing the timed sections and your untimed blind review.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | B | Strengthen | Chapter 8 |
| I.2 | E | Flaw | Chapter 9 |
| I.3 | C | Must be true | Chapter 10 |
| I.4 | A | Necessary assumption | Chapter 7 |
| I.5 | D | Resolve the paradox | Chapter 13 |
| I.6 | C | Main conclusion | Chapter 11 |
| I.7 | A | Weaken | Chapter 8 |
| I.8 | E | Principle | Chapter 13 |
| I.9 | B | Flaw | Chapter 9 |
| I.10 | D | Most strongly supported | Chapter 10 |
| I.11 | D | Sufficient assumption | Chapter 7 |
| I.12 | B | Role of a statement | Chapter 11 |
| I.13 | A | Strengthen | Chapter 8 |
| I.14 | E | Method of reasoning | Chapter 11 |
| I.15 | C | Necessary assumption | Chapter 7 |
| I.16 | A | Flaw | Chapter 9 |
| I.17 | D | Parallel reasoning | Chapter 12 |
| I.18 | C | Weaken | Chapter 8 |
| I.19 | B | Point at issue | Chapter 11 |
| I.20 | E | Principle | Chapter 13 |
| I.21 | E | Flaw | Chapter 9 |
| I.22 | C | Evaluate | Chapter 8 |
| I.23 | B | Resolve the paradox | Chapter 13 |
| I.24 | D | Parallel flaw | Chapter 12 |
| I.25 | A | Strengthen | Chapter 8 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | A | RC main point | Chapter 18 |
| II.2 | D | RC detail | Chapter 18 |
| II.3 | B | RC inference | Chapter 18 |
| II.4 | E | RC function | Chapter 18 |
| II.5 | C | RC application | Chapter 18 |
| II.6 | D | RC attitude | Chapter 18 |
| II.7 | C | RC main point | Chapter 18 |
| II.8 | A | RC detail | Chapter 18 |
| II.9 | B | RC inference | Chapter 18 |
| II.10 | E | RC function | Chapter 18 |
| II.11 | E | RC application | Chapter 18 |
| II.12 | B | RC attitude | Chapter 18 |
| II.13 | D | RC structure | Chapter 18 |
| II.14 | C | RC comparative | Chapter 17 |
| II.15 | A | RC comparative | Chapter 17 |
| II.16 | C | RC comparative | Chapter 17 |
| II.17 | A | RC comparative | Chapter 17 |
| II.18 | E | RC comparative | Chapter 17 |
| II.19 | D | RC comparative | Chapter 17 |
| II.20 | B | RC comparative | Chapter 17 |
| II.21 | B | RC main point | Chapter 18 |
| II.22 | E | RC detail | Chapter 18 |
| II.23 | C | RC inference | Chapter 18 |
| II.24 | A | RC function | Chapter 18 |
| II.25 | D | RC application | Chapter 18 |
| II.26 | A | RC attitude | Chapter 18 |
| II.27 | C | RC structure | Chapter 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | D | Main conclusion | Chapter 11 |
| III.2 | A | Strengthen | Chapter 8 |
| III.3 | C | Necessary assumption | Chapter 7 |
| III.4 | E | Flaw | Chapter 9 |
| III.5 | B | Must be true | Chapter 10 |
| III.6 | B | Resolve the paradox | Chapter 13 |
| III.7 | D | Weaken | Chapter 8 |
| III.8 | A | Principle | Chapter 13 |
| III.9 | C | Role of a statement | Chapter 11 |
| III.10 | E | Flaw | Chapter 9 |
| III.11 | E | Sufficient assumption | Chapter 7 |
| III.12 | C | Method of reasoning | Chapter 11 |
| III.13 | B | Strengthen | Chapter 8 |
| III.14 | D | Necessary assumption | Chapter 7 |
| III.15 | A | Most strongly supported | Chapter 10 |
| III.16 | C | Flaw | Chapter 9 |
| III.17 | E | Parallel reasoning | Chapter 12 |
| III.18 | D | Resolve the paradox | Chapter 13 |
| III.19 | A | Weaken | Chapter 8 |
| III.20 | B | Point at issue | Chapter 11 |
| III.21 | A | Principle | Chapter 13 |
| III.22 | B | Flaw | Chapter 9 |
| III.23 | E | Parallel flaw | Chapter 12 |
| III.24 | C | Strengthen | Chapter 8 |
| III.25 | D | Evaluate | Chapter 8 |

:::

**Raw score:** Count one point for each correct answer, out of 77: Section I /25 + Section II /27 + Section III /25. This original test has not been equated to official LSAT forms; do **not** convert your raw score to a purported 120–180 scaled score.

Use your section split and flagged answers to determine what to drill. A correct guess with no solid reason should remain on your review list.

| Type or skill | Review chapter |
| --- | --- |
| Conditional reasoning and formal inferences | Chapter 5 |
| Necessary and sufficient assumptions | Chapter 7 |
| Causal strengthen / weaken / evaluation | Chapter 8 |
| Flaws, selection bias, sampling, comparison | Chapters 6 and 9 |
| Must be true and most strongly supported | Chapter 10 |
| Main conclusion, role, method, point at issue | Chapters 4 and 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Resolve the paradox and principle | Chapter 13 |
| RC paragraph maps, primary purpose and detail | Chapters 15 and 18 |
| RC comparative agreement and disagreement | Chapter 17 |
| Blind review and error logging | Chapters 22 and 23 |
