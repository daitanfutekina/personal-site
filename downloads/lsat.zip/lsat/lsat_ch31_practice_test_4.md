---
title: "Practice Test 4"
source: "markdown"
---

Part VI · Chapter 31

# Practice Test 4

An original 77-question LSAT practice test with two Logical Reasoning sections and one Reading Comprehension section.

## Overview

Take the three scored sections in one sitting, allowing **35 minutes per section** and a **10-minute break after Section II**. This chapter practices the scored core of the post-August-2024 LSAT; the official test also contains one unscored experimental section. Use a timer and work through the sections in order.

**Flag, don't guess silently.** Record every question you are uncertain about, even when you choose an answer. Do not open any solution until all three sections are complete. Then **blind-review your flagged questions without a timer** before consulting the answer key (Chapter 22). Record misses and the traps you fell for in your error log (Chapter 23).

This is an **original instructional test**, not an official LSAC PrepTest. For calibrated timing and scoring, official PrepTests in LawHub remain the gold standard (Chapter 24). This chapter's score is a practice raw score, not an LSAC-scaled score.

## 31.1 Section I: Logical Reasoning

:::problem[Question I.1]
Transit planner: Some council members oppose reserving a lane for express buses because it would remove parking spaces that shopkeepers value. Yet the shops already receive most of their customers on foot, and deliveries use the rear service road. More important, an express lane would make bus arrival times more predictable, encouraging commuters who currently drive to use transit. We should therefore reserve the lane for buses rather than preserve curbside parking. The council can address loading concerns without abandoning a change that benefits the street as a whole.

Which one of the following most accurately expresses the main conclusion of the transit planner’s argument?

- **(A)** Most shop customers reach the shops on foot.
- **(B)** Rear service roads should replace all street parking throughout the city.
- **(C)** Predictable bus arrival times matter more to commuters than lower fares.
- **(D)** Shopkeepers are mistaken about the importance of all parking spaces.
- **(E)** The council should designate the street lane for express buses instead of retaining the curbside parking.

::::solution[Solution]
**Answer:** (E)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The planner recommends reserving the lane for buses.
2. **Support.** Pedestrian customers, rear deliveries, and more reliable transit all support the proposed change.
3. **Prephrase.** Find the normative claim that the other statements try to establish.
4. **Why (E) is right.** This sentence is explicitly introduced by “therefore” and is the action justified by the remaining facts.
5. **Why the others fail.**
   - **(A)** Premise trap: pedestrian arrivals are evidence used against the parking objection, not the recommended action.
   - **(B)** Scope shift: the planner discusses deliveries on one street, not a citywide parking ban.
   - **(C)** Wrong comparison: fares are never compared with punctuality.
   - **(D)** Overstatement: the argument challenges a particular lane reservation, not every parking claim.

**Check:** The recommendation, unlike its supporting facts, answers what the council should do.
::::
:::

:::problem[Question I.2]
A museum curator argues that the new audio guide caused visitors to spend more time examining paintings. In the month after its introduction, the average gallery visit rose from forty to fifty-six minutes. During that month the museum also changed its ticketing system, but the curator claims ticketing could not explain the increase because tickets were scanned only at entry. The curator hopes to use the observed change to justify spending more on recordings for other galleries.

Which one of the following, if true, most strengthens the curator’s argument?

- **(A)** Visitors interviewed after using the guide said the recordings were enjoyable.
- **(B)** The recordings took approximately sixteen minutes to play in full.
- **(C)** Visitors who were randomly offered the guide spent substantially more minutes looking at individual paintings than comparable visitors who were not offered it during the same weeks.
- **(D)** The museum charged no extra fee for the audio guide.
- **(E)** Visitors to other museums also spent longer in galleries that month.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The audio guide caused an increase in time spent examining paintings.
2. **Support.** Visit duration increased after the guide appeared, but a before-and-after correlation may hide other changes.
3. **Prephrase.** Look for comparable visitors in the same time period who differ in guide access.
4. **Why (C) is right.** Random assignment while holding calendar conditions constant helps isolate the guide rather than seasonal changes or ticketing.
5. **Why the others fail.**
   - **(A)** Satisfaction is a shell game: enjoyment does not establish longer viewing.
   - **(B)** Coincidental arithmetic: a recording’s length does not show visitors listened or stayed because of it.
   - **(D)** Accessibility might help uptake but provides no comparison isolating the cause of longer visits.
   - **(E)** Alternative trend trap: a general increase actually leaves a rival explanation open.

**Check:** A contemporaneous randomized contrast directly supports the proposed cause.
::::
:::

:::problem[Question I.3]
A nutrition blogger surveyed readers who had purchased her high-protein snack plan. Of those who replied, eighty percent said they felt more energetic than before. She concludes that the plan will make most people feel more energetic, and she advises a public health office to recommend it to residents generally. The blogger notes that the survey was large, with almost two thousand responses, and argues that a sample this big cannot give a misleading picture of the effects of the plan.

The blogger’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** overlooks that purchasers who chose to reply may differ systematically from the general population whose outcomes the conclusion predicts.
- **(B)** infers that energy levels cause people to buy protein snacks when the evidence supports only the reverse direction.
- **(C)** assumes that a person who feels energetic necessarily eats sufficient protein.
- **(D)** treats the opinions of a health office as if they were scientific evidence.
- **(E)** presupposes that all respondents gave exactly the same reason for feeling energetic.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The plan is likely to energize most residents.
2. **Support.** A large voluntary response survey of existing purchasers produced many favorable self-reports.
3. **Prephrase.** Identify the sampling-to-population gap, not merely the number of responses.
4. **Why (A) is right.** Self-selection and purchaser-only sampling can bias even a survey with two thousand answers; sample size does not repair representativeness.
5. **Why the others fail.**
   - **(B)** Reversal trap: the writer claims the snacks increase energy, not that energy causes purchase.
   - **(C)** Necessary/sufficient shell game: the argument does not infer nutrient adequacy from reported energy.
   - **(D)** Authority trap: the office is the intended recipient of advice, not a cited authority.
   - **(E)** Too strong: unanimity of explanations is not necessary to the population prediction.

**Check:** The observed sample is not established as representative of the target residents.
::::
:::

:::problem[Question I.4]
A wildlife office counted crane nesting sites along three estuaries. Every site in the eastern estuary was within a protected marsh. Some sites in the central estuary were not protected, but all such unprotected sites were on privately owned land. The western estuary had no sites on privately owned land, although several of its sites lay outside protected marshes. The office emphasizes that its counts concern nesting sites, not every place cranes forage during migration, so nothing about feeding locations follows merely from these records.

Which one of the following must be true on the basis of the office’s information?

- **(A)** Every crane nesting site outside protected marshes was located on private land.
- **(B)** At least one nesting site in the western estuary was outside a protected marsh and not on privately owned land.
- **(C)** Some cranes feed on privately owned land in the central estuary.
- **(D)** All nesting sites on private land were outside protected marshes.
- **(E)** The eastern estuary had more protected nesting sites than the western estuary.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The question seeks a necessary consequence of the location classifications.
2. **Support.** Western sites include several outside marshes, and none of the western sites is on private land.
3. **Prephrase.** Combine the two western-estuary statements without importing counts or behavior.
4. **Why (B) is right.** Take any specified western site outside a protected marsh. Since no western site is privately owned, that site meets both conditions.
5. **Why the others fail.**
   - **(A)** Overgeneralization: western sites outside marshes are explicitly not on private land.
   - **(C)** Outside-scope inference: records concern nest sites, not feeding.
   - **(D)** Converse trap: only unprotected central sites are specified as private, not all private sites.
   - **(E)** Wrong comparison: no estuary counts are supplied.

**Check:** Outside marsh (western) + no western site privately owned => the existential claim.
::::
:::

:::problem[Question I.5]
A city is considering giving free helmets to people who register for its cycling classes. A councilor argues that the giveaway will reduce injuries to cyclists, since helmets greatly reduce the severity of certain head injuries when worn correctly. The councilor acknowledges that the program does not require anyone to wear a helmet during later rides, but maintains that giving them out is an effective injury-prevention policy even without enforcement. Her conclusion concerns injuries in the city, not merely the number of helmets distributed.

The councilor’s reasoning depends on assuming which one of the following?

- **(A)** The giveaway will result in at least some rides being taken with suitable helmets that would otherwise have been taken without them.
- **(B)** Every recipient will wear a helmet on every subsequent ride.
- **(C)** Helmet distribution will cause more residents to enroll in cycling classes.
- **(D)** Head injuries are more common than all other cycling injuries combined.
- **(E)** The program will lower the number of bicycle collisions on city roads.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The giveaway will lower cycling injuries in the city.
2. **Support.** Helmets protect when worn, but free distribution does not ensure that people wear them.
3. **Prephrase.** The program must result in at least some new effective helmet use.
4. **Why (A) is right.** Negate this: not a single ride that otherwise would have lacked a suitable helmet gains one through the giveaway. The stated injury-reduction mechanism then provides no added protection.
5. **Why the others fail.**
   - **(B)** Too strong: the argument needs actual uptake, not universal compliance.
   - **(C)** Wrong target: class enrollment is not the stated mechanism for reducing injuries.
   - **(D)** Wrong comparison: the policy can reduce injuries even if head injuries are a minority.
   - **(E)** Mechanism substitution: the cited benefit is reduced severity, not fewer collisions.

**Check:** Negating actual new helmet use removes the policy’s injury-reduction bridge.
::::
:::

:::problem[Question I.6]
A public aquarium moved a popular fish species from a small tank to a much larger habitat. The species’ population in the exhibit doubled over the next year, yet visitors reported seeing the fish less often than they had in the smaller tank. The staff found that the exhibit remained open the same hours, its viewing glass stayed equally clear, and visitors spent approximately the same time at the exhibit. The director wants an explanation that accommodates both the growing number of fish and the decline in reported sightings.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The aquarium installed new interactive displays explaining the fish’s usual habits.
- **(B)** Visitors found the new habitat more natural-looking than the old tank.
- **(C)** The average fish in the species was slightly larger after the move.
- **(D)** The new habitat contains deep rock crevices where the fish spend much of the day beyond visitors’ view.
- **(E)** The aquarium monitored population changes more closely after the move.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** An explanation must reconcile more fish with fewer reported sightings.
2. **Support.** The staff has ruled out simple changes in opening time, glass clarity, and viewing duration.
3. **Prephrase.** Look for a lower probability of seeing any individual fish.
4. **Why (D) is right.** Hidden crevices reduce visibility even while total population grows, so both observations can be true.
5. **Why the others fail.**
   - **(A)** Information for visitors might alter what they notice, but no reason is given that it made live fish less visible.
   - **(B)** Satisfaction with a natural-looking habitat does not by itself explain fewer sightings despite more fish.
   - **(C)** Opposite pressure: larger fish would normally be easier, not harder, to spot.
   - **(E)** Better counting may corroborate the growth but does not explain why visitors saw fewer individuals.

**Check:** Number present and number visible need not move together.
::::
:::

:::problem[Question I.7]
A transportation committee claims that the recently introduced light-rail line shortened the commute of the average resident in its corridor. It cites a questionnaire in which rail riders report an average journey of twenty-six minutes, while local drivers report thirty-eight minutes. Most riders interviewed boarded near the line’s central station, where trains arrive frequently. The committee argues that the twelve-minute difference demonstrates a systemwide benefit and should be used to estimate the amount of time the city has saved.

Which one of the following, if true, most weakens the committee’s conclusion?

- **(A)** Rail passengers often read or work while traveling.
- **(B)** The fare for a rail journey is lower than the cost of driving for many surveyed commuters.
- **(C)** Rail riders surveyed generally live near downtown, while the driver sample contains many residents commuting from distant suburbs.
- **(D)** Several surveyed drivers said they enjoy driving.
- **(E)** The rail system uses trains with fewer seats than the city’s original proposal.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Introducing rail shortened commute times for the average corridor resident.
2. **Support.** A cross-sectional comparison contrasts rail riders’ and drivers’ reported durations.
3. **Prephrase.** Find a baseline difference between rider and driver groups unrelated to transit effectiveness.
4. **Why (C) is right.** If groups travel very different distances, their current trip times cannot isolate the rail line’s effect on commute duration.
5. **Why the others fail.**
   - **(A)** Benefit substitution: productive travel does not establish shorter door-to-door commute time.
   - **(B)** Travel-cost savings may recommend rail, but do not make the rider/driver trip-time groups comparable.
   - **(D)** Preference trap: liking a mode does not explain the time difference.
   - **(E)** Capacity comparison does not show whether commuting times were reduced.

**Check:** Comparable commuters, not unlike geographic populations, would be needed.
::::
:::

:::problem[Question I.8]
A museum’s director argues that when an institution discovers that an object in its collection was transferred under an agreement obtained by deliberate deception, it ought to offer to return the object to the original owner’s successor. She concedes that returning objects can disrupt exhibitions and sometimes disappoint donors. Nevertheless, an institution should not retain the advantages of a transaction whose terms would never have been accepted had the other party known the truth. The director distinguishes such cases from genuine disputes over how an old agreement should be interpreted.

Which one of the following principles most closely conforms to the director’s reasoning?

- **(A)** Museums must return all objects whenever a living relative of a former owner requests them.
- **(B)** An institution should offer to reverse a transaction when it benefited from intentional deception that induced the other party’s consent.
- **(C)** Agreements about art are never binding if circumstances later change.
- **(D)** An institution may retain a deceptively acquired object if its exhibition is especially popular.
- **(E)** Every ambiguous historical ownership document must be resolved against museums.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Deceptively induced transfers create an obligation to offer return.
2. **Support.** Consent obtained through deliberate misrepresentation lacks the moral force of informed agreement.
3. **Prephrase.** Look for a principle tied to deception, benefit, and reversal rather than any ownership disagreement.
4. **Why (B) is right.** The principle exactly captures the triggering defect and the limited restorative duty the director endorses.
5. **Why the others fail.**
   - **(A)** Too broad: requests alone are not the deliberate-deception condition.
   - **(C)** Wrong trigger: later inconvenience is not deception at the time of agreement.
   - **(D)** Contradicts the argument: exhibition benefits do not override the restitution duty.
   - **(E)** Category shift: the director explicitly distinguishes genuine interpretive disputes.

**Check:** Apply it to the described transaction: deliberate deceit -> offer reversal.
::::
:::

:::problem[Question I.9]
A psychologist asked forty volunteers to record how many hours they slept on each of seven nights, then tested their recall on the eighth morning. Volunteers who reported longer sleep performed better on the recall task. The psychologist therefore concluded that longer sleep caused the better memory scores. The volunteers were free to choose their own bedtimes, and the study did not record how demanding their jobs were or whether they had recently been ill. Yet the psychologist called the association direct evidence of a causal effect.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** infers from seven nights of sleep that every volunteer will sleep the same amount indefinitely.
- **(B)** assumes that memory scores and job demands cannot be measured independently.
- **(C)** fails to rule out factors that might affect both sleep duration and performance on the recall task.
- **(D)** bases a general claim exclusively on people who refused to participate.
- **(E)** concludes that better recall caused the volunteers to go to bed earlier.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Longer sleep caused improved recall scores.
2. **Support.** Self-reported sleep hours correlate with memory scores in an uncontrolled volunteer sample.
3. **Prephrase.** Identify a common-cause alternative to the causal interpretation.
4. **Why (C) is right.** Illness, stress, or job demands could influence both variables, making correlation inadequate evidence that added sleep produced the change.
5. **Why the others fail.**
   - **(A)** Straw claim: no long-term prediction appears in the conclusion.
   - **(B)** No such measurement claim is made; the weakness is omitted confounding variables.
   - **(D)** Reversed sample: the data come from volunteers who did participate.
   - **(E)** Reversal trap: the psychologist asserts sleep causes recall, not vice versa.

**Check:** No random assignment or control excludes a shared cause.
::::
:::

:::problem[Question I.10]
An arts council proposes restoring a neglected theater’s original exterior. Its chair predicts that this will increase attendance at performances inside, even though the auditorium and programming will remain unchanged. As support, the chair observes that several newly renovated buildings nearby receive more foot traffic than similarly sized unrenovated buildings. The council needs to decide whether the cost of facade repairs is justified by additional ticket revenue, not merely by a more attractive streetscape.

Which one of the following, if true, most strengthens the chair’s prediction?

- **(A)** Restoration would improve the theater’s structural stability.
- **(B)** Some nearby renovated buildings house popular restaurants.
- **(C)** The theater’s current subscribers already report high satisfaction with its performances.
- **(D)** The restoration would use materials matching those originally installed.
- **(E)** In comparable theaters, randomly shown photographs of restored exteriors led prospective patrons to reserve more performance tickets than photographs of unrestored exteriors.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Exterior restoration will raise theater performance attendance.
2. **Support.** Foot traffic near renovated buildings is correlated with renovation, but does not establish a ticket-purchase effect.
3. **Prephrase.** Test whether exterior appearance changes a potential patron’s purchase behavior.
4. **Why (E) is right.** Randomly varying the exterior appearance while holding comparable theater offers constant gives direct evidence for a booking effect.
5. **Why the others fail.**
   - **(A)** Benefit substitution: structural stability may matter, but the conclusion predicts ticket sales from appearance.
   - **(B)** Confounding trap: popularity may explain traffic without renovation doing so.
   - **(C)** Existing audience satisfaction does not predict whether exterior restoration attracts additional patrons.
   - **(D)** Historical authenticity is a potential value but does not show increased bookings.

**Check:** The test manipulates the proposed cause and observes the claimed commercial outcome.
::::
:::

:::problem[Question I.11]
Field biologist: Some marine researchers maintain that pale shells protect shore crabs from predators by making them less visible on sand. But crabs with pale shells are found just as frequently on dark, rocky shores, where pale shells would seem conspicuous. This observation does not prove that shell color has no protective function, since the relevant predators may perceive colors differently from humans. It does show that habitat color alone is a poor basis for asserting that camouflage explains the distribution of pale-shelled crabs.

In the argument, the assertion that pale-shelled crabs are also common on rocky shores serves which one of the following functions?

- **(A)** It provides evidence against an explanation offered by other researchers without establishing that explanation to be impossible.
- **(B)** It states the biologist’s final conclusion about the inadequacy of habitat color.
- **(C)** It concedes that pale shells always conceal crabs from predators.
- **(D)** It identifies the assumption that marine predators see colors exactly as humans do.
- **(E)** It defines what the biologist means by a protective function.

::::solution[Solution]
**Answer:** (A)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** Habitat color by itself cannot justify the camouflage explanation.
2. **Support.** An unexpected observation of pale shells on dark rock undermines a simple fit-to-background theory.
3. **Prephrase.** Identify whether the quoted sentence is evidence, concession, or conclusion.
4. **Why (A) is right.** It is the counterexample used to weaken a proposed explanation; the biologist explicitly stops short of disproof.
5. **Why the others fail.**
   - **(B)** Premise/conclusion swap: the final judgment is that habitat color alone is poor evidence.
   - **(C)** Opposite claim: rocky backgrounds make the simple concealment story doubtful.
   - **(D)** Wrong role: predator vision is an acknowledged uncertainty, not what the rocky-shore observation states.
   - **(E)** Definition trap: a distributional observation is not a definition of protection.

**Check:** The observation supports a limited criticism, not a categorical rejection.
::::
:::

:::problem[Question I.12]
A grocery chain plans to place green labels on products that meet its nutritional criteria. A manager predicts the labels will improve the nutritional quality of customers’ purchases because shoppers often make quick decisions and will be able to recognize suitable products without reading every ingredient list. The chain will not remove unlabeled products or lower the prices of labeled ones. The manager’s forecast assumes a change in what customers place in their carts, not just a change in how quickly they shop.

Which one of the following is an assumption required by the manager’s reasoning?

- **(A)** Some shoppers will choose labeled products over less nutritious alternatives because of the labels.
- **(B)** Every shopper understands the precise nutritional formula used for labels.
- **(C)** Unlabeled products will disappear from shelves within a year.
- **(D)** The labeled products are always cheaper than their unlabeled alternatives.
- **(E)** Green labels will shorten the average shopping trip by more than five minutes.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Placing labels will improve the nutritional quality of purchases.
2. **Support.** The proposed mechanism is easier recognition of nutritious items in fast decisions.
3. **Prephrase.** At least some choices must change toward nutritious products because of the labels.
4. **Why (A) is right.** Negate this: no shopper switches toward a better alternative because of a label. Then recognition alone cannot produce the predicted improvement through the proposed mechanism.
5. **Why the others fail.**
   - **(B)** Too strong: recognizing the symbol can work without understanding its formula.
   - **(C)** Contradicts the described plan and is not needed for a change in purchasing.
   - **(D)** Wrong mechanism: the store explicitly holds price changes out of its proposal.
   - **(E)** Wrong outcome: quicker shopping is not improved nutrition.

**Check:** No label-induced healthier substitution -> the stated rationale supplies no improvement.
::::
:::

:::problem[Question I.13]
An ecologist rejects the claim that a decline in morning bird counts proves that the local bird population has shrunk. She points out that the survey team recently began counting two hours later, after many birds leave their morning feeding areas. When an earlier team temporarily used that later schedule, its counts also fell, although simultaneous nest monitoring showed stable numbers of breeding pairs. The ecologist concludes that the new schedule is a plausible explanation for the lower observed counts, so a population decline has not yet been demonstrated.

Which one of the following most accurately describes the ecologist’s method of reasoning?

- **(A)** She derives a prediction from a general law concerning all bird species.
- **(B)** She offers an alternative explanation for an observation and uses a prior comparison to show that the observation need not indicate the claimed change.
- **(C)** She refutes a claim by exposing a contradiction between two definitions.
- **(D)** She attacks the qualifications of the people who conducted the new survey.
- **(E)** She uses the absence of any historical variation to prove the population has increased.

::::solution[Solution]
**Answer:** (B)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The lower counts do not yet demonstrate a decline in population.
2. **Support.** The counting time shifted; a previous late-count period yielded similar low counts despite stable nests.
3. **Prephrase.** Look for an alternative-cause response rather than proof of the opposite claim.
4. **Why (B) is right.** The method uses a counter-explanation with corroborating earlier observations to undermine a causal inference.
5. **Why the others fail.**
   - **(A)** No universal law appears; the evidence concerns survey timing in one area.
   - **(C)** No equivocation or definitional contradiction is alleged.
   - **(D)** Ad hominem trap: her objection concerns sampling conditions, not competence.
   - **(E)** Opposite and too strong: she does not establish an increase, only an alternative explanation.

**Check:** It blocks the asserted inference without requiring proof that population is constant.
::::
:::

:::problem[Question I.14]
A school district introduced an app that sends students an alert when their bus is approaching. Administrators conclude that the alerts reduced the number of students missing buses because, after the launch, the office logged thirty percent fewer reports from parents whose children had missed pickup. The app was optional, and the district did not record actual missed pickups. Administrators argue that fewer complaints are a reliable measure of greater punctuality because parents usually call when transportation goes wrong.

Which one of the following, if true, most seriously weakens the administrators’ argument?

- **(A)** Many students used the app to view their bus’s current location.
- **(B)** The district also improved the colors on bus-stop signs.
- **(C)** Parents who used the app reported finding its map easier to read than the paper schedule.
- **(D)** Students who received alerts often checked them shortly before leaving home.
- **(E)** The app replaced the phone-report form with a difficult-to-find online form, and many parents stopped reporting missed pickups.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Alerts caused fewer actual missed pickups.
2. **Support.** Only the number of parent reports is observed; reporting behavior is assumed stable.
3. **Prephrase.** Find a reason complaints could fall while incidents stay the same.
4. **Why (E) is right.** A harder reporting system directly severs the proxy between calls and actual missed buses.
5. **Why the others fail.**
   - **(A)** Uptake does not determine whether unreported missed pickups fell.
   - **(B)** Possible alternative cause, but without evidence it affects missed pickups this is less direct than lost reporting.
   - **(C)** A readability advantage may help users but cannot rule out the collapse in reporting as the cause of fewer complaints.
   - **(D)** Evidence of attention to alerts does not validate parent complaints as a proxy for actual missed pickups.

**Check:** Declining reports are consistent with unchanged pickup failures.
::::
:::

:::problem[Question I.15]
A shuttle operator will issue a discount to any passenger who has both a monthly pass and a university identification card. Every student in the graduate residence owns a monthly pass. Mira lives in that residence and has a university identification card. Therefore, the operator will issue Mira a discount. The operator’s policy does not state that only these passengers qualify, and the argument does not rely on any conclusion about passengers who lack one of the two documents.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Anyone with a library card may borrow books. Pia borrowed books, so Pia must have a library card.
- **(B)** Every volunteer has a key or an access code. Leo is a volunteer and has a key, so he lacks an access code.
- **(C)** Every certified guide with a park badge receives free entry. All members of the alpine crew are certified guides. Jo is in that crew and has a park badge. Therefore, Jo receives free entry.
- **(D)** Anyone who owns a pass and a badge gets entry. Arun has a badge, so Arun gets entry.
- **(E)** All crew members have passes, and all residents have badges. Mei has a pass and a badge, so she is both a crew member and a resident.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The discount follows for Mira.
2. **Support.** Pass and ID are jointly sufficient; group membership guarantees one, and Mira separately has the other.
3. **Prephrase.** Match the chain group -> first condition, individual -> group + second condition -> benefit.
4. **Why (C) is right.** The guide/badge argument reproduces each logical link with new terms and reaches the guaranteed benefit.
5. **Why the others fail.**
   - **(A)** Converse trap: this wrongly infers a condition from a benefit.
   - **(B)** False exclusivity: “or” does not establish “not both.”
   - **(D)** Missing conjunct: this version lacks the needed pass.
   - **(E)** Affirming consequents: this infers group membership from shared properties.

**Check:** Both arguments use modus ponens and conjunction introduction.
::::
:::

:::problem[Question I.16]
An appraiser argues that a sculpture must be authentic because a well-known collector paid a very high price for it at auction. The collector has bought many genuine works, and sales staff say he has excellent taste. The appraiser does not mention any examination of the sculpture’s materials or provenance. When asked whether even experienced collectors might make mistakes, she replies that the collector’s reputation makes such a mistake too unlikely to consider, and repeats that the high sale price settles the question.

The appraiser’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that all auction houses knowingly sell counterfeit works.
- **(B)** confuses a necessary legal condition for ownership with a sufficient one.
- **(C)** reasons that because the work is genuine it must have been expensive.
- **(D)** uses a respected purchaser’s conduct as decisive evidence of authenticity without examining whether that purchaser could have been mistaken.
- **(E)** fails to compare the sculpture’s size with the dimensions of other works by the artist.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The sculpture must be authentic.
2. **Support.** A reputed collector bought it at a high price and is presumed incapable of relevant error.
3. **Prephrase.** Look for an appeal to a purchaser’s authority as proof of the object’s status.
4. **Why (D) is right.** Collectors can be skilled and still mistaken; reputation and price are not conclusive authentication.
5. **Why the others fail.**
   - **(A)** Opposite accusation: no claim that auction houses are deliberately deceptive appears.
   - **(B)** Wrong domain: ownership conditions are not under discussion.
   - **(C)** Reversal trap: the argument infers genuineness from price, not price from genuineness.
   - **(E)** Arbitrary missing evidence: dimensions might help, but this is not the reasoning error described.

**Check:** High confidence in an expert buyer does not entail infallibility.
::::
:::

:::problem[Question I.17]
The transportation board has adopted two rules: every tram route that serves the hospital qualifies for extended nighttime operation, and any route that qualifies for extended nighttime operation must receive a safety inspection this month. The Green Line is a tram route, but the board has not said whether it serves the hospital. An advocate nonetheless concludes that the Green Line must receive a safety inspection this month, relying entirely on those two rules and one unstated additional fact.

Which one of the following, if assumed, allows the advocate’s conclusion to be properly drawn?

- **(A)** Some routes inspected this month do not run at night.
- **(B)** The Green Line serves the hospital.
- **(C)** No hospital-serving tram route will lose funding this year.
- **(D)** The Green Line serves more stops than any other tram route.
- **(E)** Routes that receive safety inspections sometimes extend their hours afterward.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Green Line must receive an inspection this month.
2. **Support.** Hospital service -> nighttime qualification -> inspection, but Green Line lacks the antecedent.
3. **Prephrase.** Add Green Line -> serves hospital to complete the chain.
4. **Why (B) is right.** If Green Line serves the hospital, the first rule yields qualification, then the second yields inspection.
5. **Why the others fail.**
   - **(A)** Wrong direction: a fact about inspected routes does not classify Green Line.
   - **(C)** Irrelevant consequence: funding is not part of the inspection chain.
   - **(D)** Wrong property: stop count is not a premise in either rule.
   - **(E)** Converse/generalization: later schedule changes do not prove inspection required here.

**Check:** Green Line -> hospital -> qualified -> inspection.
::::
:::

:::problem[Question I.18]
A psychologist measured reaction times in people who were given a mildly caffeinated drink or an identical-looking caffeine-free drink. Participants were randomly assigned, and neither participants nor test administrators knew which drink was which. In each of three sessions, the caffeinated group reacted slightly faster on average, but individual scores overlapped greatly between groups. The researcher cautioned that the experiments tested brief reactions to lights rather than judgment, long-term attention, or the effects of consuming caffeine every day.

Which one of the following is most strongly supported by the psychologist’s findings?

- **(A)** Every participant given caffeine reacted faster than every participant given the other drink.
- **(B)** Daily caffeine use reliably improves long-term judgment.
- **(C)** The experiment proves that expectation, rather than caffeine, produced the effect.
- **(D)** The caffeine-free group would have performed worse if the experimenters had told participants the drink contained caffeine.
- **(E)** Under the tested conditions, a mild dose of caffeine can improve average speed on a brief reaction task without guaranteeing faster performance for each individual.

::::solution[Solution]
**Answer:** (E)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The question asks for a modest inference from a controlled study.
2. **Support.** Randomized, blinded comparisons show a small average difference with overlap.
3. **Prephrase.** Keep the claim restricted to averages, task, dose, and conditions.
4. **Why (E) is right.** The answer correctly distinguishes improved group means from individual guarantees and avoids extrapolation.
5. **Why the others fail.**
   - **(A)** Quantifier trap: the groups’ scores overlapped.
   - **(B)** Scope shift: neither daily use nor judgment was tested.
   - **(C)** Opposite inference: blinding weakens an expectation-based explanation.
   - **(D)** Speculation about a different disclosure protocol is not supported by the blinded experiment.

**Check:** Average difference + overlap is compatible with many caffeine participants being slower.
::::
:::

:::problem[Question I.19]
A conservation team hopes to protect a wetland from invasive frogs by installing a low mesh barrier around the wetland’s edge. The team expects the barrier to reduce the number of invasive frogs breeding inside it. Opponents point out that frogs can sometimes pass through gaps in barriers, and that many frog eggs are carried by water. The team responds that the wetland is unusually isolated, but it needs stronger evidence that this particular barrier would meaningfully reduce future breeding.

Which one of the following, if true, most strengthens the team’s expectation?

- **(A)** Several native frog species benefit from wetland vegetation.
- **(B)** The mesh is dense enough to prevent most adult frogs from squeezing directly through it.
- **(C)** Surveys found that nearly all invasive frogs now breeding in the wetland arrived as adult frogs across the precise edge where the mesh barrier would be installed.
- **(D)** Some invasive frogs can survive in water that is slightly saline.
- **(E)** The team has successfully excluded invasive frogs from a much smaller enclosed pond.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The barrier should reduce invasive breeding.
2. **Support.** Frogs can bypass barriers through gaps or waterborne eggs, so entry path matters.
3. **Prephrase.** Locate the dominant actual entry route and show it intersects the barrier.
4. **Why (C) is right.** If almost all breeders arrive as adults over that edge, a barrier blocking the crossing addresses the main source directly.
5. **Why the others fail.**
   - **(A)** Species switch: native frogs do not show the proposed barrier blocks invasive breeders.
   - **(B)** Blockage capability helps, but without evidence adults normally enter over that edge, waterborne eggs could still sustain breeding.
   - **(D)** Biological detail does not establish whether barrier controls the main source.
   - **(E)** Success in a different habitat supplies some support but does not address whether this wetland’s breeders enter via its perimeter.

**Check:** Most breeding entrants cross the proposed blockade, strengthening the causal mechanism.
::::
:::

:::problem[Question I.20]
Curator Ellis: Visitors understand a painter’s experimentation best when canvases are presented in chronological order. Even if the later canvases are the most famous, displaying them first hides the sequence of trials that produced them. I favor arranging this retrospective by date. Curator Rowan: Chronology can reveal changes, and I agree that the painter’s experiments matter. But visitors with little background should encounter the best-known canvases immediately so they have a reason to explore the unfamiliar ones. For this particular retrospective, I favor a fame-first arrangement.

The curators disagree over whether...

- **(A)** the painter’s experiments are important to understanding the work.
- **(B)** chronological order can reveal changes in technique.
- **(C)** visitors already know every canvas in the retrospective.
- **(D)** the best-known paintings are also the paintings that show the artist’s greatest technical experimentation.
- **(E)** the retrospective should place the painter’s best-known canvases ahead of the earlier, less familiar canvases.

::::solution[Solution]
**Answer:** (E)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Identify a proposition on which the speakers take opposed positions.
2. **Support.** Ellis favors date order despite later fame; Rowan explicitly favors fame-first for this exhibition.
3. **Prephrase.** Both must have a stated stake, and the answers must separate their views.
4. **Why (E) is right.** Ellis rejects the ordering Rowan endorses, whereas both agree on the educational value of experimentation.
5. **Why the others fail.**
   - **(A)** Agreement trap: Rowan explicitly agrees that the experiments matter.
   - **(B)** Agreement trap: Rowan grants that chronology can reveal changes.
   - **(C)** No-stake trap: neither curator says visitors know every work.
   - **(D)** Both value experimentation, but neither says fame and experimentation track one another.

**Check:** Ellis: chronological first; Rowan: famous works first.
::::
:::

:::problem[Question I.21]
A conservation committee has determined that every painted panel of a restored triptych is individually resistant to humidity. It concludes that the assembled triptych cannot suffer moisture damage in a humid gallery. The committee grants that joining the panels introduces seams and adhesives, but says that a property possessed by every panel must also characterize the assembled artwork. No testing has been conducted on the joints. The committee is confident that checking each component separately is equivalent to testing the combined object under actual display conditions.

Which one of the following arguments is flawed in the same way?

- **(A)** Every completed greenhouse has weatherproof glass. This loose pane came from such a greenhouse, so it is weatherproof.
- **(B)** Every segment of the greenhouse roof is resistant to hail damage. Thus the assembled roof, including the seams joining the segments, must resist hail damage.
- **(C)** Each pane of clear glass transmits some sunlight; therefore the whole roof admits at least some sunlight through its panes.
- **(D)** Every weatherproof greenhouse has reinforced joints. This greenhouse has reinforced joints; therefore it is weatherproof.
- **(E)** One greenhouse panel survived last year’s hailstorm, so every panel made by its manufacturer will survive the next storm.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The entire assembled artwork must resist humidity because each panel resists it.
2. **Support.** Individual panels have tested resistance, but seams and adhesives could behave differently.
3. **Prephrase.** Match a move from each part’s protection to guaranteed protection of the joined whole.
4. **Why (B) is right.** The greenhouse argument transfers hail resistance of separate segments to the seams and roof assembly without testing the assembled system.
5. **Why the others fail.**
   - **(A)** Part-to-member inference: it moves a property of completed wholes to one component, the opposite direction.
   - **(C)** Not the flaw: the conclusion preserves the local transparent pathways rather than claiming vulnerable joints are protected.
   - **(D)** Necessary/sufficient confusion: the converse of a conditional, not composition across parts.
   - **(E)** Hasty generalization from one component to a class, not from all component properties to whole-assembly durability.

**Check:** Individual component durability does not entail durability of joints or overall assembly.
::::
:::

:::problem[Question I.22]
An environmental columnist proposes that households replace individually wrapped meal kits with bulk ingredients purchased in reusable containers. The columnist argues this will reduce those households’ total packaging waste because the bulk ingredients arrive without the dozens of small wrappers found in meal kits. The proposal would not affect how much food the families eat. Yet the columnist’s calculation compares only the packaging visible when food reaches the home, not any packaging used upstream in shipping and storage.

The columnist’s argument requires assuming which one of the following?

- **(A)** No packaging is used at any point in producing or transporting bulk ingredients.
- **(B)** All households will find bulk ingredients cheaper than meal kits.
- **(C)** The reusable containers are made exclusively of recycled glass.
- **(D)** The net change in packaging waste away from households will not offset the reduction in household-visible wrappers.
- **(E)** Food waste is a larger environmental problem than packaging waste.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Using bulk ingredients reduces total packaging waste.
2. **Support.** Fewer visible individual wrappers are counted, but upstream packaging is omitted.
3. **Prephrase.** The unseen waste must not erase the observed reduction.
4. **Why (D) is right.** Negate this: the net increase in packaging away from households equals or exceeds the wrapper reduction. Then total packaging does not decrease.
5. **Why the others fail.**
   - **(A)** Too strong: some upstream packaging may remain without erasing the net reduction.
   - **(B)** Cost is an unrelated goal and no price comparison supports packaging totals.
   - **(C)** Material specificity is unnecessary; any suitably reusable container can serve.
   - **(E)** Wrong comparison: total packaging, not relative harms, is the conclusion.

**Check:** The net, not merely visible, packaging difference determines the result.
::::
:::

:::problem[Question I.23]
A regional governor argues that subsidizing the morning ferry will increase employment among island residents. She cites a travel survey showing that employed islanders are more likely than unemployed islanders to take the ferry to the mainland. The governor takes that association as evidence that making ferry travel cheaper will help unemployed residents find work. She does not report whether mainland jobs are reachable from the terminal or how many unemployed islanders are actively seeking such jobs.

Which one of the following, if true, most weakens the governor’s reasoning?

- **(A)** The ferry has comfortable seats for passengers who travel early.
- **(B)** Some employers reimburse commuting costs for their workers.
- **(C)** Several island residents prefer the ferry to an existing bridge.
- **(D)** Most employed ferry users began riding the ferry only after securing mainland jobs, whereas few current job vacancies can be reached from the terminal.
- **(E)** Residents who are already employed report that their travel schedules are less flexible than those of job seekers.

::::solution[Solution]
**Answer:** (D)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Cheaper ferry rides will increase employment.
2. **Support.** Employed people take the ferry more; the governor treats an association as cause of employment.
3. **Prephrase.** Test reverse causation and practical access to jobs.
4. **Why (D) is right.** If people board the ferry because they already have jobs and vacancies are not reachable, subsidizing rides may not produce employment.
5. **Why the others fail.**
   - **(A)** Comfort does not explain the employment association or show new job access.
   - **(B)** Possible subsidy overlap is less decisive than evidence that jobs cause ferry use and vacancies are unreachable.
   - **(C)** Preference does not establish access to additional employment.
   - **(E)** Different schedules are relevant to ferry demand but do not show the subsidy will create accessible jobs.

**Check:** Employment -> ferry use can explain the data without ferry cost -> employment.
::::
:::

:::problem[Question I.24]
A gallery owner argues that a recently donated painting cannot contain synthetic blue pigment. Analysis of the artist’s works shows that original paint layers applied before 1910 lacked synthetic blue pigment. The gallery owner has an unsigned note suggesting the donated painting was finished in 1908, but another document records that the artist reworked several paintings long after their initial completion. The owner refuses to examine the donated work itself and treats the year suggested by the note as decisive about the materials now present on its surface.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** fails to consider that a painting initially completed before 1910 may have been altered afterward using different materials.
- **(B)** confuses the absence of pigment in all paintings with its absence from some paintings.
- **(C)** mistakes evidence of later reworking for proof that this painting was reworked.
- **(D)** relies on the fact that synthetic blue pigment is now commercially available.
- **(E)** fails to determine whether the painting’s market value has increased.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The painting now cannot contain synthetic blue pigment.
2. **Support.** Initial completion before 1910 is used to infer the present surface contains no later synthetic pigment.
3. **Prephrase.** Find the possibility that present materials differ from initial materials.
4. **Why (A) is right.** Later alterations could introduce synthetic pigment even if the old painting’s original state satisfied the historical rule.
5. **Why the others fail.**
   - **(B)** Quantifier trap: the rule is specifically about pre-1910 paintings, not all paintings.
   - **(C)** False attribution: the owner ignores later reworking; the critic need not prove it happened here.
   - **(D)** Unsupported premise: no evidence about current retail availability appears.
   - **(E)** Wrong issue: value does not decide the pigments on its surface.

**Check:** Initial date is not a guarantee about materials added later.
::::
:::

:::problem[Question I.25]
A psychology researcher predicts that a ten-minute breathing exercise offered before appointments will reduce patients’ reported anxiety. At one clinic, patients who elected to perform the exercise reported less anxiety afterward than patients who declined. The researcher argues the exercise is responsible and wants to repeat the program in other clinics. However, participation was optional, and the same survey instrument asked about anxiety immediately before and after the appointment. A colleague proposes asking one additional question that would most help evaluate the causal inference.

The answer to which one of the following questions would be most useful in evaluating the researcher’s argument?

- **(A)** How many clinics use the same brand of appointment-scheduling software?
- **(B)** Do patients generally prefer morning appointments to afternoon appointments?
- **(C)** Would a longer breathing exercise require larger waiting rooms?
- **(D)** Before exercising, did the participating patients tend to report lower anxiety than patients who declined?
- **(E)** Were the participating patients more likely to recommend the clinic to others?

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The exercise produced the lower post-appointment anxiety.
2. **Support.** Participants self-selected and had lower post-treatment anxiety than nonparticipants.
3. **Prephrase.** Ask whether they differed on the outcome before the intervention.
4. **Why (D) is right.** If participants already felt calmer, self-selection could explain the difference; if baseline levels matched, a major alternative becomes less plausible.
5. **Why the others fail.**
   - **(A)** Unrelated institutional feature does not test the selection effect in anxiety.
   - **(B)** Broad preference is not linked to group anxiety differences as stated.
   - **(C)** Implementation cost does not evaluate whether the ten-minute exercise caused anxiety changes.
   - **(E)** Recommendation behavior might reflect satisfaction but cannot isolate a preexisting anxiety difference.

**Check:** Both answers to the baseline question would materially shift the causal assessment.
::::
:::

## 31.2 Section II: Reading Comprehension

### Passage 1

A repair cooperative restoring obsolete scientific instruments has discovered a persistent obstacle. The instruments' manufacturers generally permit owners to replace worn parts, but the instructions needed to identify those parts are locked inside old service manuals. Many manuals are out of print. Some survive only as scanned copies maintained by collectors, and publishers sometimes demand licenses before a cooperative may put those scans online. The cooperative argues that because the manuals describe physical operations rather than novels or paintings, their contents should be freely reproducible. That position captures a genuine access problem but misunderstands a distinction central to intellectual property law: an instruction's underlying procedure and the particular expression used to describe it need not receive the same treatment.

A repair procedure, considered as a sequence of mechanical steps, is different from a diagrammaker's creative choice of viewpoint, shading, and arrangement. A legal system might permit anyone to explain how to adjust a valve while still protecting a distinctive illustration from verbatim copying. Even a technically accurate diagram can embody choices among many ways of showing the same machine. Conversely, the fact that a manual contains copyrightable illustrations does not establish that the maker owns the procedure itself. Confusing those categories can either let publishers claim exclusive control over practical knowledge or cause repair advocates to deny protection to genuinely original presentation. The hard cases involve diagrams in which only one clear depiction will communicate a particular operation.

Some advocates propose a categorical exemption for all technical documentation. Manufacturers respond that this would undercut the expense of preparing safe, comprehensible manuals. Neither position adequately addresses manuals whose commercial market has effectively disappeared. A narrower proposal would permit preservation libraries to provide complete digital copies when a manual is unavailable through ordinary channels, provided the library identifies the source, limits alterations that could create safety hazards, and withdraws its copy if a reasonably accessible authorized edition returns. These conditions cannot remove every economic objection: publishers may value licensing opportunities even for little-used works. But they connect the exemption to the access failure that motivates it, rather than to the sweeping claim that technical expression deserves no protection.

One objection is that a conditional exemption would encourage libraries to decide for themselves when a work is unavailable. Yet institutions already make judgments about the accessibility and condition of materials in preservation programs; the issue is how to document those judgments and permit review. A public record of unsuccessful attempts to locate an authorized edition would be more accountable than treating all manuals alike. Such a record would also permit a rights holder to correct an error without making every repair researcher begin a new licensing negotiation.

The choice is not between absolute ownership of mechanical knowledge and unlimited copying of every manual. A workable policy should preserve room for original expression while ensuring that the disappearance of a commercial edition does not permanently suppress access to instructions needed to maintain existing equipment.

:::problem[Question II.1]
Which one of the following most accurately states the main point of the passage?

- **(A)** All illustrations in technical manuals should be free of copyright because they depict machines.
- **(B)** Manufacturers should receive broader rights over the mechanical methods described in their manuals.
- **(C)** A limited, reviewable copying exception for unavailable repair manuals can address access without denying protection to original expression.
- **(D)** A copyright owner should retain exclusive control over copying even when no authorized edition remains available.
- **(E)** Out-of-print manuals are generally unsafe to use without the manufacturer’s supervision.

::::solution[Solution]
**Answer:** (C)

**Type:** RC Main point (Chapter 18)

1. **Conclusion.** The author argues for a conditional route to digital access that preserves expression rights.
2. **Support.** The passage distinguishes procedure from expression, evaluates two extreme policies, and develops a documented exemption.
3. **Prephrase.** Select the position covering both access and intellectual-property limits.
4. **Why (C) is right.** This answer matches the final synthesis and the specific third-paragraph proposal.
5. **Why the others fail.**
   - **(A)** Overstatement: original diagram presentation may be protected.
   - **(B)** Opposite position: the author distinguishes procedures from protected expression.
   - **(D)** This is the unqualified ownership extreme the author rejects in favor of conditional access.
   - **(E)** Too narrow and unsupported: the passage mentions safety safeguards, not a general risk claim.

**Check:** First and final paragraphs both reject the false choice between unrestricted copying and absolute control.
::::
:::

:::problem[Question II.2]
According to the passage, which one of the following may receive protection even when the procedure it describes is available for others to use?

- **(A)** The physical sequence of steps required to adjust a valve.
- **(B)** The particular creative arrangement and viewpoint chosen for an illustration of the procedure.
- **(C)** Any factual measurement recorded in a service manual.
- **(D)** The manufacturer’s continuing ownership of the repaired machine.
- **(E)** The general idea that all equipment needs maintenance.

::::solution[Solution]
**Answer:** (B)

**Type:** RC Detail (Chapter 18)

1. **Conclusion.** The relevant distinction is between instructions as processes and their presentation.
2. **Support.** Paragraph two says choices of viewpoint, shading, and arrangement may be protectable.
3. **Prephrase.** Find the expressive choice rather than the functional information.
4. **Why (B) is right.** The listed creative features are exactly what the author separates from the unowned procedure.
5. **Why the others fail.**
   - **(A)** Category reversal: the procedure itself is distinguished from its expression.
   - **(C)** Wrong category: facts are not equated with original illustration choices.
   - **(D)** Out of scope: ownership of the physical machine is not at issue.
   - **(E)** Too abstract: the protection discussed concerns distinctive expression, not a commonplace idea.

**Check:** Paragraph two contrasts the procedure with a diagrammaker’s choices.
::::
:::

:::problem[Question II.3]
The discussion of manuals whose commercial market has effectively disappeared serves primarily to...

- **(A)** identify a class of cases for which an access-based exemption can be justified more narrowly than a universal exemption.
- **(B)** prove that preparing technical manuals never requires substantial financial investment.
- **(C)** establish that all technical procedures are protected as original expression.
- **(D)** show that publishers routinely destroy old manuals to create licensing demand.
- **(E)** deny that licensing opportunities have any economic value.

::::solution[Solution]
**Answer:** (A)

**Type:** RC Function / purpose of a part (Chapter 18)

1. **Conclusion.** The vanished-market case motivates the tailored copying proposal.
2. **Support.** Paragraph three rejects blanket positions and then singles out inaccessible editions.
3. **Prephrase.** Ask why the author introduces the vanished-market case at this point in the argument.
4. **Why (A) is right.** It supplies the condition connecting the exemption to a particular access failure, instead of all technical writing.
5. **Why the others fail.**
   - **(B)** Contradiction: the passage acknowledges manufacturers’ production expenses.
   - **(C)** Opposite distinction: procedures and expression are separated.
   - **(D)** Invented motive: no deliberate destruction is alleged.
   - **(E)** Contradiction: even little-used works may retain licensing value.

**Check:** Its placement marks the pivot from extremes to a narrow policy.
::::
:::

:::problem[Question II.4]
Which one of the following can most reasonably be inferred about the author’s preferred preservation process?

- **(A)** It would require every rights holder to approve each use before a preservation copy could be viewed.
- **(B)** It would include a way for a rights holder to challenge a library’s determination that no authorized edition was reasonably accessible.
- **(C)** It would leave all determinations of availability permanently unreviewable.
- **(D)** It would automatically exempt any manual once its first edition sold out.
- **(E)** It would give librarians authority to alter safety-sensitive instructions at will.

::::solution[Solution]
**Answer:** (B)

**Type:** RC Inference (Chapter 18)

1. **Conclusion.** The author wants an accountable conditional access decision.
2. **Support.** Paragraph four calls for a public record and says rights holders could correct mistakes.
3. **Prephrase.** Find an inference that combines documentation with correction without preapproval for every use.
4. **Why (B) is right.** A challenge procedure follows naturally from permitting rights holders to correct an erroneous availability finding.
5. **Why the others fail.**
   - **(A)** Reversal: such case-by-case negotiations are what the policy aims to avoid.
   - **(C)** Opposite: the author insists on documentation and review.
   - **(D)** Overreach: accessible authorized editions still matter.
   - **(E)** Contradiction: proposed limits guard against hazardous alterations.

**Check:** Correctable decisions imply some form of contest or review.
::::
:::

:::problem[Question II.5]
Which one of the following best describes the author’s attitude toward the boundary between functional information and protected illustration?

- **(A)** The distinction is meaningless because every diagram is a mechanical procedure.
- **(B)** The distinction is simple enough that no policy review is necessary.
- **(C)** The distinction should always favor publishers regardless of access failures.
- **(D)** The distinction is useful only when a manual is still sold in print.
- **(E)** The distinction is important, but some cases are genuinely difficult to classify.

::::solution[Solution]
**Answer:** (E)

**Type:** RC Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author values the expression/function distinction yet recognizes its edge cases.
2. **Support.** Paragraph two calls certain only-one-depiction diagrams hard cases.
3. **Prephrase.** Look for measured endorsement plus acknowledged limits.
4. **Why (E) is right.** The answer matches both the confident category separation and stated uncertainty about constrained diagrams.
5. **Why the others fail.**
   - **(A)** Opposite: the distinction anchors the analysis.
   - **(B)** Too certain: the author highlights hard cases and accountability.
   - **(C)** Misattribution: the author supports conditional access.
   - **(D)** Artificial limitation: the author invokes the distinction for unavailable manuals too.

**Check:** A principle can guide policy without deciding every case mechanically.
::::
:::

:::problem[Question II.6]
Suppose a library posts a full scan of an unavailable repair manual under the proposed exception. A year later, the publisher releases a reasonably accessible authorized digital edition. Under the proposal, the library should most likely...

- **(A)** withdraw its online copy because the specific condition justifying access has ceased to hold.
- **(B)** keep the scan online indefinitely because it was lawful when first posted.
- **(C)** replace the scan with altered instructions that differ from the new edition.
- **(D)** demand that the publisher release all future service manuals for free.
- **(E)** delete all records of its earlier unsuccessful search for editions.

::::solution[Solution]
**Answer:** (A)

**Type:** RC Application / analogy (Chapter 18)

1. **Conclusion.** The access exemption is conditioned on continued lack of an accessible edition.
2. **Support.** Paragraph three explicitly requires withdrawal if a reasonably accessible edition returns.
3. **Prephrase.** Apply the stated conditional rule to the new facts.
4. **Why (A) is right.** The restored authorized edition eliminates the unavailable-market trigger for keeping the scan online.
5. **Why the others fail.**
   - **(B)** Temporal shell game: the proposal expressly includes withdrawal if an edition returns.
   - **(C)** Wrong remedy: alteration risks safety and is not the specified response.
   - **(D)** Scope jump: a single restored edition triggers no general duty.
   - **(E)** Opposite transparency goal: documentation supports accountable decisions.

**Check:** Authorized edition returns -> remove the special-access scan.
::::
:::

:::problem[Question II.7]
Which one of the following is most strongly supported by the passage?

- **(A)** The author recognizes that a carefully limited exemption may still impose some economic costs on publishers.
- **(B)** A narrow exception necessarily eliminates all licensing revenue from technical manuals.
- **(C)** An inaccessible manual cannot contain copyrightable material.
- **(D)** Publishers have no legitimate reasons to object once an exception requires source attribution.
- **(E)** Libraries currently copy all unavailable materials without making judgments of any kind.

::::solution[Solution]
**Answer:** (A)

**Type:** RC Inference (Chapter 18)

1. **Conclusion.** The proposal is a compromise rather than a costless solution.
2. **Support.** Paragraph three says restrictions cannot eliminate every economic objection because licensing remains valuable.
3. **Prephrase.** Choose a limited inference consistent with conceded costs.
4. **Why (A) is right.** The author expressly accepts that even a narrow exemption may reduce some licensing opportunities.
5. **Why the others fail.**
   - **(B)** Overstatement: the author specifically acknowledges residual licensing objections.
   - **(C)** Category error: accessibility and protectability are separate issues.
   - **(D)** Too strong: attribution does not remove the licensing-value objection recognized by the author.
   - **(E)** Opposite: libraries already make availability and condition judgments.

**Check:** The text distinguishes improved access from elimination of all economic objections.
::::
:::

### Passage 2

From a satellite, two blankets of low cloud above neighboring stretches of ocean can look nearly identical in thickness yet reflect different amounts of sunlight. Part of the difference may arise from the tiny airborne particles around which cloud droplets form. Where more suitable particles are present, a given quantity of liquid water can be distributed among a larger number of smaller droplets. Such a cloud generally presents more droplet surface to incoming sunlight and can become more reflective. This relationship has prompted interest in whether changing the supply of particles over the ocean could temporarily increase the cooling influence of some marine clouds.

The physical argument seems straightforward until the cloud is treated as a moving system rather than a static collection of droplets. A brighter cloud may also evaporate faster if dry air mixes downward from above it. The added particles can alter drizzle formation, which in turn affects how long the cloud retains water. Sometimes reduced drizzle allows a cloud to persist; in other settings, turbulence fragments the cloud layer and exposes darker ocean. Consequently, a change that increases the reflectivity of individual cloud patches need not increase the total sunlight reflected by the entire region over a full day. The area covered by clouds and the duration of that coverage matter alongside brightness.

To investigate these processes, researchers compare measurements from aircraft, ship instruments, satellites, and numerical models. Ship instruments can record the particle distribution near the ocean surface, while aircraft sample conditions at cloud level. Satellites provide broad views but may struggle to distinguish a cloud made of numerous small droplets from one with a different liquid-water content. Models can isolate hypothetical mechanisms by holding some variables fixed, although their treatment of small-scale mixing necessarily simplifies reality. Agreement among methods is valuable precisely because the instruments and models fail in different ways. No single snapshot settles the regional cooling question.

Historical ship exhaust tracks offer striking examples of particle-rich air producing visibly brighter streaks through low clouds. Those tracks are instructive but not a simple recipe. Their brightness is affected by the background particle population and by whether the surrounding cloud was already close to the maximum number of droplets it could support. A cloud that already contains many small droplets may respond little to an additional supply. A sparse cloud in unusually dry air might respond by thinning rather than brightening. The same intervention can therefore have different effects in different atmospheric circumstances.

The important scientific task is not merely to establish that particles can brighten droplets; multiple observations support that narrower claim. It is to determine when that local effect survives the competing changes in cloud lifetime, extent, and mixing. Until those conditions are understood, regional cooling estimates should be treated as conditional projections rather than as a predictable consequence of adding particles.

:::problem[Question II.8]
The passage is primarily concerned with...

- **(A)** arguing that marine clouds never influence the amount of sunlight reaching Earth.
- **(B)** demonstrating that satellite data are useless for atmospheric research.
- **(C)** proposing immediate large-scale addition of particles to all ocean clouds.
- **(D)** estimating regional cooling from cloud droplet counts without considering differences in water content.
- **(E)** explaining why a particle-induced increase in individual cloud brightness does not by itself establish predictable regional cooling.

::::solution[Solution]
**Answer:** (E)

**Type:** RC Main point (Chapter 18)

1. **Conclusion.** Local brightening must not be confused with reliable regionwide cooling.
2. **Support.** The passage traces particle effects, competing cloud responses, measurement limits, and context dependence.
3. **Prephrase.** Select the overarching distinction between local reflectivity and regional effect.
4. **Why (E) is right.** This choice covers the physical explanation and the qualified closing conclusion.
5. **Why the others fail.**
   - **(A)** Contradiction: reflectivity is the passage’s starting fact.
   - **(B)** Overstatement: satellites contribute broad views despite limits.
   - **(C)** Opposite recommendation: the author urges conditional estimates.
   - **(D)** This captures a specific methodological problem but is too narrow for a main point covering coverage and lifetime too.

**Check:** The final paragraph repeats the local-effect-versus-regional-outcome distinction.
::::
:::

:::problem[Question II.9]
According to the second paragraph, a reduction in drizzle can sometimes...

- **(A)** guarantee that every cloud will cover more ocean surface.
- **(B)** prevent all dry air from entering the cloud.
- **(C)** make every droplet instantly larger.
- **(D)** allow a cloud to retain water for a longer period.
- **(E)** eliminate the importance of cloud lifetime for cooling.

::::solution[Solution]
**Answer:** (D)

**Type:** RC Detail (Chapter 18)

1. **Conclusion.** Reduced drizzle can sometimes preserve cloud water.
2. **Support.** The second paragraph says reduced drizzle can let a cloud persist.
3. **Prephrase.** Locate the expressly stated possible effect, not a guaranteed regional consequence.
4. **Why (D) is right.** The answer paraphrases the sentence about water persistence without adding universality.
5. **Why the others fail.**
   - **(A)** Too strong: cloud fragmentation may still reduce coverage.
   - **(B)** Wrong mechanism: entrainment of dry air is separately described.
   - **(C)** Unsupported timing and universal claim about droplets.
   - **(E)** Opposite: lifetime is one of the variables whose effects matter.

**Check:** “Sometimes” permits the stated limited effect.
::::
:::

:::problem[Question II.10]
The author mentions that satellites can have difficulty distinguishing droplet number from liquid-water content primarily to...

- **(A)** argue that aircraft measurements are perfectly accurate.
- **(B)** show that satellite instruments cannot observe cloud patterns at all.
- **(C)** illustrate why a broad observational view must be supplemented with other forms of measurement.
- **(D)** establish that liquid-water content never affects reflectivity.
- **(E)** suggest that all numerical models should be abandoned.

::::solution[Solution]
**Answer:** (C)

**Type:** RC Function / purpose of a part (Chapter 18)

1. **Conclusion.** Complementary instruments are needed for confidence in cloud estimates.
2. **Support.** The paragraph contrasts ship, aircraft, satellite, and models with different limitations.
3. **Prephrase.** Identify the role of a specific measurement weakness in the broader methodological point.
4. **Why (C) is right.** The satellite limitation explains why triangulation across methods is informative.
5. **Why the others fail.**
   - **(A)** False comparison: the passage says methods fail differently, not that aircraft never fail.
   - **(B)** Opposite: satellites provide broad views.
   - **(D)** Contradiction: the mechanism depends on water distributed among droplets.
   - **(E)** Unrelated conclusion: models are included as useful but simplified tools.

**Check:** The sentence supports “no single snapshot settles the question.”
::::
:::

:::problem[Question II.11]
Which one of the following is most strongly supported by the passage?

- **(A)** All clouds brighten by the same percentage when the same quantity of particles is added.
- **(B)** Adding particles to a cloud already rich in small droplets may have little effect on its brightness.
- **(C)** Clouds containing many small droplets are necessarily short-lived.
- **(D)** Cloud brightness depends exclusively on particles from ship exhaust.
- **(E)** Aerosol additions cannot affect clouds in dry air under any circumstances.

::::solution[Solution]
**Answer:** (B)

**Type:** RC Inference (Chapter 18)

1. **Conclusion.** The response depends on existing cloud conditions.
2. **Support.** Paragraph four says a cloud near its droplet capacity may respond little to added particles.
3. **Prephrase.** Use the saturation example rather than projecting universal effects.
4. **Why (B) is right.** The answer states exactly the limited possibility contemplated in the passage.
5. **Why the others fail.**
   - **(A)** Contradiction: responses vary with atmospheric circumstances.
   - **(C)** Unsupported association between droplet number and longevity.
   - **(D)** Exclusive-cause trap: background conditions and liquid water also matter.
   - **(E)** Too absolute: dry air may cause thinning but outcomes are conditional.

**Check:** Already droplet-rich -> marginal effect may be small.
::::
:::

:::problem[Question II.12]
A researcher finds that an intervention raises the reflectivity of clouds directly above a test vessel, but afterward the clouds cover less area and dissipate earlier. Which assessment is most consistent with the passage?

- **(A)** The intervention must cool the entire region because patch reflectivity increased.
- **(B)** The intervention must warm the region because coverage decreased.
- **(C)** The satellite used to observe the clouds is necessarily defective.
- **(D)** The regional cooling outcome remains uncertain because brighter patches may be offset by reduced coverage and duration.
- **(E)** The result proves that changing particle supply never affects droplet size.

::::solution[Solution]
**Answer:** (D)

**Type:** RC Application / analogy (Chapter 18)

1. **Conclusion.** Competing changes can cancel or outweigh local brightening.
2. **Support.** The second and fifth paragraphs insist that extent and duration matter.
3. **Prephrase.** Avoid inferring net regional effect from patch brightness alone.
4. **Why (D) is right.** Less area and lifetime could offset increased patch reflectivity; without magnitudes the net effect is unknown.
5. **Why the others fail.**
   - **(A)** Local-to-regional trap: ignores area and lifetime.
   - **(B)** Too strong in the opposite direction: competing effects have not been quantified.
   - **(C)** Instrument attribution unsupported; physical changes can coexist.
   - **(E)** Non sequitur: reflectivity change is consistent with microphysical effects.

**Check:** Patch reflectivity is only one term in the regional energy balance.
::::
:::

:::problem[Question II.13]
How does the author regard historical ship exhaust tracks?

- **(A)** As proof that any ocean cloud can be made brighter by adding enough particles.
- **(B)** As irrelevant artifacts that reveal nothing about cloud processes.
- **(C)** As evidence that ship engines consistently cool the global climate.
- **(D)** As informative observations of particle-related cloud brightening that do not by themselves establish a reliable intervention strategy.
- **(E)** As a basis for rejecting all observational climate research.

::::solution[Solution]
**Answer:** (D)

**Type:** RC Author’s attitude / tone (Chapter 18)

1. **Conclusion.** Ship tracks illustrate a narrow mechanism but have limited predictive power.
2. **Support.** Paragraph four calls the tracks instructive but not a simple recipe.
3. **Prephrase.** Match cautious usefulness rather than wholesale acceptance or dismissal.
4. **Why (D) is right.** The answer captures the author's explicit qualified description.
5. **Why the others fail.**
   - **(A)** Overgeneralization: background particle levels constrain response.
   - **(B)** Opposite: the author calls them instructive.
   - **(C)** Scope error: a visible track is not a global climate estimate.
   - **(E)** Wrong conclusion: multiple observational methods are endorsed.

**Check:** Observed streaks ≠ guaranteed general response.
::::
:::

:::problem[Question II.14]
Which one of the following best describes the organization of the passage?

- **(A)** It begins with a policy recommendation, then presents objections only from political opponents.
- **(B)** It presents several experiments showing identical outcomes and concludes no uncertainty remains.
- **(C)** It introduces a proposed mechanism, considers competing system responses, discusses measurement limits, and ends by restricting the conclusion that may be drawn.
- **(D)** It surveys historical climate theories chronologically without evaluating any.
- **(E)** It uses historical ship observations to establish a universal law and then applies that law to all cloud types.

::::solution[Solution]
**Answer:** (C)

**Type:** RC Structure / organization (Chapter 18)

1. **Conclusion.** The passage moves from mechanism to qualifying complexity and cautious conclusion.
2. **Support.** P1 mechanism; P2 feedbacks; P3 tools; P4 context-dependent examples; P5 limited inference.
3. **Prephrase.** Use the paragraph map rather than isolated technical details.
4. **Why (C) is right.** The sequence in the answer matches every major movement in the text.
5. **Why the others fail.**
   - **(A)** Wrong structure: the focus is physical and methodological, not political debate.
   - **(B)** Contrary: variable responses and uncertainty are emphasized.
   - **(D)** Wrong organization: paragraphs follow mechanisms and evidence, not chronology.
   - **(E)** Historical tracks are treated as examples with limited transferability, not proof of a universal response.

**Check:** The final paragraph differentiates the established local mechanism from conditional regional projections.
::::
:::

### Passage 3

A person asked to imagine a red square may report that the square seems to occupy a position in a private visual field. Another person, asked the same thing, may deny having anything picture-like in mind while successfully answering questions about the square's rotation. Philosophers have sometimes used this contrast to divide thinkers into those who possess mental imagery and those who do not. The division is tempting, but it rests on a questionable assumption: that a report about the character of an experience and a demonstration of an ability describe the same underlying thing.

First-person reports are indispensable evidence about how thinking seems to the person doing it. To dismiss a person who denies a visual impression is to ignore the very feature that makes the question interesting. Yet the report is shaped by the language available to the speaker. One person might reserve the word “picture” for something as vivid as ordinary sight; another might apply it to a faint awareness of spatial relationships. Their conflicting descriptions need not reveal an equally sharp difference in what they can mentally accomplish. Nor does identical performance settle the question of experience: two people can produce the same answer by quite different routes.

Experimental tasks complicate matters further. Participants may be asked which of two imagined objects would fit through an opening, or whether a letter would still look familiar after rotation. Such tasks reveal how representations are used, but the answer could result from manipulating a spatial model without anything that feels like seeing. Conversely, a vivid inner impression may occur without yielding precise judgments. Those who infer the presence of a picture-like experience from successful rotation therefore move too quickly from function to feeling. Those who infer an absence of useful spatial representation from a denial of imagery commit a comparable error in reverse.

One response is to insist that only brain measurements can resolve the matter. Shared patterns of neural activity might help determine whether different participants recruit similar mechanisms, and that would be substantial progress. But even an extremely reliable neural marker could not, by itself, decide what a participant means by “visual.” A useful inquiry should compare careful descriptions, performance across several tasks, and neural measurements, while acknowledging that each method answers a different question. Such triangulation is not a compromise between scientific rigor and subjective report; it is a way of avoiding claims that any one kind of evidence is sufficient for every issue.

The dispute about mental imagery may thus be less about choosing between reports and experiments than about refusing to treat one as a translation of the other. The goal is a richer account in which how thinking feels, what thinking enables, and how thinking is implemented can converge without being assumed identical from the start.

:::problem[Question II.15]
Which one of the following most accurately states the passage’s main point?

- **(A)** Subjective experience is scientifically inaccessible and should be disregarded.
- **(B)** Only neural recordings can establish what words about imagery mean.
- **(C)** Reports of imagery should be given less weight whenever they conflict with behavioral tests.
- **(D)** Mental imagery can be divided with certainty into exactly two kinds of people.
- **(E)** Accounts of mental imagery should integrate reports, task performance, and neural evidence without assuming these measure exactly the same feature of thinking.

::::solution[Solution]
**Answer:** (E)

**Type:** RC Main point (Chapter 18)

1. **Conclusion.** The author endorses a pluralistic inquiry into imagery.
2. **Support.** Reports, performance, and neural measures each answer related but distinct questions.
3. **Prephrase.** Choose the synthesis respecting the three levels.
4. **Why (E) is right.** This answer captures the final paragraph and the proposed triangulation.
5. **Why the others fail.**
   - **(A)** Contradiction: first-person evidence is called indispensable.
   - **(B)** Misattribution: neural measures cannot alone settle meanings of visual reports.
   - **(C)** This overprioritizes performance, whereas the author treats reports and tasks as noninterchangeable.
   - **(D)** Opposite: that initial sharp division is challenged.

**Check:** Experience, function, and implementation should not be assumed identical.
::::
:::

:::problem[Question II.16]
According to the second paragraph, two people who describe their mental experiences differently may nevertheless...

- **(A)** necessarily possess identical subjective experiences.
- **(B)** use exactly the same definition of “picture.”
- **(C)** be unable to answer questions about imagined objects.
- **(D)** have similar capacities to manipulate spatial information.
- **(E)** have proven that all visual memories are inaccurate.

::::solution[Solution]
**Answer:** (D)

**Type:** RC Detail (Chapter 18)

1. **Conclusion.** Different descriptions need not imply an equally sharp difference in abilities.
2. **Support.** Varying thresholds for using “picture” may produce distinct reports from comparable function.
3. **Prephrase.** Identify the explicit report/performance distinction.
4. **Why (D) is right.** The choice paraphrases the paragraph without claiming identical experience.
5. **Why the others fail.**
   - **(A)** Overstatement: similar abilities do not settle experiential identity.
   - **(B)** Contradiction: different usages explain contrasting reports.
   - **(C)** Contradiction: successful performance can coexist with denial of imagery.
   - **(E)** Unsupported generalization about memory accuracy.

**Check:** Words and capacities are not a one-to-one mapping.
::::
:::

:::problem[Question II.17]
Which one of the following would the author most likely agree with?

- **(A)** Anyone with a vivid visual impression must always excel at rotation tasks.
- **(B)** People who deny mental images cannot manipulate spatial relationships.
- **(C)** Neural measurements have no useful role in studies of mental imagery.
- **(D)** Success at a mental-rotation task alone does not establish that the participant has a conscious visual impression.
- **(E)** The meaning of “visual” is fixed by performance speed on a single task.

::::solution[Solution]
**Answer:** (D)

**Type:** RC Inference (Chapter 18)

1. **Conclusion.** Function cannot alone establish feeling.
2. **Support.** Paragraph three distinguishes correct spatial judgments from picture-like experience.
3. **Prephrase.** Find the one-way inference the author explicitly rejects.
4. **Why (D) is right.** The answer restates the author’s rejection of moving from task success to conscious visual quality.
5. **Why the others fail.**
   - **(A)** Direct conflict: vividness need not yield precise judgments.
   - **(B)** Reverse error: some can perform spatial tasks successfully.
   - **(C)** Overstatement: they are valuable for investigating mechanisms.
   - **(E)** Single-measure trap: language and experience require additional evidence.

**Check:** Ability to rotate is consistent with no picture-like feeling.
::::
:::

:::problem[Question II.18]
The discussion of neural markers in the fourth paragraph primarily serves to...

- **(A)** show that brain patterns cannot be compared across participants.
- **(B)** prove that first-person reports are always more accurate than brain measurements.
- **(C)** acknowledge a useful additional source of evidence while rejecting the idea that it can answer every question about imagery.
- **(D)** replace behavioral experiments with biological tests entirely.
- **(E)** argue that neural activity reveals no aspect of a thinking process.

::::solution[Solution]
**Answer:** (C)

**Type:** RC Function / purpose of a part (Chapter 18)

1. **Conclusion.** Neural evidence matters, but does not supersede reports and tasks.
2. **Support.** Paragraph four grants mechanistic insight while denying neural measures settle verbal meanings alone.
3. **Prephrase.** Look for concession followed by limitation.
4. **Why (C) is right.** The author makes room for neural methods but rejects methodological exclusivity.
5. **Why the others fail.**
   - **(A)** Contradiction: such comparisons could advance knowledge.
   - **(B)** Wrong comparison: the methods answer different questions.
   - **(D)** Opposite: the author advocates triangulation across all three.
   - **(E)** Overstatement: shared mechanisms can be investigated.

**Check:** A marker for mechanism is not by itself a definition of “visual.”
::::
:::

:::problem[Question II.19]
Which one of the following scenarios is most analogous to the error the author identifies in inferring an inner picture from successful rotation?

- **(A)** A researcher records that two participants use different words for the same color and asks them to clarify their meanings.
- **(B)** A researcher combines interview reports with accuracy measures to describe attention.
- **(C)** A researcher refuses to infer someone’s experience solely from a brain scan.
- **(D)** A researcher discovers that a task is harder when its instructions are incomplete.
- **(E)** A researcher concludes that a chess player must mentally hear spoken move instructions because the player can plan moves without a board.

::::solution[Solution]
**Answer:** (E)

**Type:** RC Application / analogy (Chapter 18)

1. **Conclusion.** The targeted error moves from competence to a particular conscious sensation.
2. **Support.** Rotation success can arise without something picture-like.
3. **Prephrase.** Find an argument that insists a specific inner experience must accompany a skill.
4. **Why (E) is right.** Chess planning establishes an ability, not an internal auditory experience; the inference repeats the category jump.
5. **Why the others fail.**
   - **(A)** Good-method contrast: it investigates language rather than inferring a specific feeling from skill.
   - **(B)** Opposite method: triangulation is endorsed.
   - **(C)** Valid caution, not the criticized inference.
   - **(D)** Different issue: task clarity is not an inference from function to feeling.

**Check:** Performance does not entail a particular phenomenal quality.
::::
:::

:::problem[Question II.20]
Which one of the following best describes the author’s attitude toward studies of mental imagery?

- **(A)** Dismissive of all experiments involving imagined objects.
- **(B)** Certain that vivid imagery never contributes to accurate judgments.
- **(C)** Critical of single-measure certainty but optimistic about combining several kinds of evidence.
- **(D)** Hostile to reports because they cannot be expressed precisely.
- **(E)** Convinced that the debate is settled and further research is unnecessary.

::::solution[Solution]
**Answer:** (C)

**Type:** RC Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author favors careful, plural evidence over simple equivalence.
2. **Support.** P2 preserves reports; P3 preserves tasks; P4 adds brain measures.
3. **Prephrase.** Choose a measured methodological attitude rather than categorical rejection.
4. **Why (C) is right.** The answer matches the critical and constructive final two paragraphs.
5. **Why the others fail.**
   - **(A)** Contradiction: tasks reveal how representations are used.
   - **(B)** Too strong: the passage notes non-necessity, not impossibility.
   - **(D)** Wrong emphasis: reports remain indispensable.
   - **(E)** Opposite: the author proposes an improved inquiry.

**Check:** Triangulation is presented as progress, not surrender.
::::
:::

### Passage 4 (comparative)

**Passage A**

Supporters of ranked-choice ballots often promise that an election will become more civil when voters can list second and third preferences. That prediction is harder to establish than the procedural benefit at the heart of the reform. A ranked ballot records information that a single-choice ballot cannot: what some voters would select if their first choice were eliminated. Such additional information does not guarantee a fairer outcome in every contest, but it can help describe the range of support for candidates rather than just each candidate's first-choice coalition. Consider a contest in which two candidates split voters who share similar second preferences. A first-choice tally obscures that relationship; rankings can make it visible without requiring analysts to guess how those voters would have behaved in a runoff. This is a descriptive advantage, not a guarantee about the winner.

Cities that are already replacing election equipment should therefore consider adopting ranked-choice voting, accompanied by clear instructions and public audits. Waiting for proof that every voter will rank every candidate sets an unreasonable threshold. Voters are free to express only one preference, and a reform need not be perfect to provide additional useful information. The proper question is whether its informational advantages justify manageable training and administrative costs. Officials should publish rates of incomplete rankings and compare those rates across precincts, but possible differences in voter familiarity are reasons to monitor implementation, not necessarily reasons to postpone it indefinitely.

**Passage B**

The promise of ranked-choice ballots must be evaluated from the standpoint of voters who encounter the ballot, not solely from the standpoint of analysts who can extract additional information from it. Listing alternatives may allow a voter to express more preferences, but that opportunity matters only if voters understand how their rankings will be counted. A ballot that collects more marks from experienced voters while producing more invalid or incomplete responses from others may deepen an existing difference in political voice. For instance, a voter may know a second ranking is permitted but mistakenly think making it will weaken a first choice. Counting completed ballots would not reveal that misconception. A reform can therefore appear widely used while still failing to communicate how the ranking process operates.

This is not an argument that a single-choice ballot is inherently superior or that ranked systems should never be used. It is an argument for delaying large-scale adoption until controlled local trials demonstrate that straightforward instructions allow different voter groups to use the system with reasonably comparable success. Comparing precinct totals after implementation will not, by itself, show whether the ballot design produced observed differences, since precincts vary in other ways. Trials with different instruction formats and measures of voter comprehension would reveal which obstacles can be removed. The crucial threshold should be meaningful, broadly shared access to the new expressive opportunity, rather than simply a higher amount of information available to election analysts.

:::problem[Question II.21]
Which one of the following best describes a central difference between the two passages?

- **(A)** Passage A treats monitored adoption as reasonable before all uncertainties are resolved, while Passage B makes comparative evidence of voter usability a prerequisite for broad adoption.
- **(B)** Passage A favors single-choice ballots, whereas Passage B argues for immediate ranked-choice adoption.
- **(C)** Passage A focuses on the information rankings provide, while Passage B denies that voter understanding bears on reform.
- **(D)** Passage A denies that rankings add information, while Passage B argues that they always produce fair outcomes.
- **(E)** Passage A and Passage B both demand that every voter rank every candidate before adoption.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative reading: relationship (Chapter 17)

1. **Conclusion.** A supports adoption with monitoring; B requires successful trials first.
2. **Support.** Each author values potential expression but sets a different evidentiary threshold.
3. **Prephrase.** Name the adoption timing and evidentiary-standard contrast.
4. **Why (A) is right.** The answer captures the real disagreement while preserving shared recognition of ranking benefits.
5. **Why the others fail.**
   - **(B)** Reversal: A supports conditional adoption and B advises delay.
   - **(C)** The first half reflects A’s emphasis, but the second directly reverses B’s concern with comprehension.
   - **(D)** Double contradiction: A emphasizes added information; B acknowledges it without promising fairness.
   - **(E)** Overstatement: A expressly rejects this threshold; B asks for comparable usability, not complete ranking.

**Check:** A: adopt with safeguards; B: delay widespread adoption pending controlled trials.
::::
:::

:::problem[Question II.22]
Both authors would most likely agree with which one of the following?

- **(A)** A ranked-choice ballot can record preferences beyond a voter’s first choice, although that fact alone does not settle whether the reform should be adopted.
- **(B)** Every voter will use all available ranking positions.
- **(C)** Additional preference data guarantee a fairer result in every contest.
- **(D)** Ranked-choice instructions have already been proven equally clear for all voter groups.
- **(E)** The reform offers no information unavailable through single-choice ballots.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative reading: agreement (Chapter 17)

1. **Conclusion.** The two writers share an understanding of additional expression, not the adoption threshold.
2. **Support.** A praises second-choice information; B says ranking may allow more preferences.
3. **Prephrase.** Choose a narrow claim both affirm without forcing agreement on reform timing.
4. **Why (A) is right.** The answer expresses their common premise and leaves their policy disagreement intact.
5. **Why the others fail.**
   - **(B)** Both reject or fail to support universal full completion.
   - **(C)** A explicitly denies a guarantee; B is cautious about inequality.
   - **(D)** B demands proof through local trials; A calls for monitoring.
   - **(E)** Contradiction: both concede the potential for additional expression.

**Check:** Both acknowledge the additional recorded preferences; neither treats that as dispositive.
::::
:::

:::problem[Question II.23]
How would the author of Passage A most likely respond to Passage B’s demand for controlled local trials before large-scale adoption?

- **(A)** Trials are irrelevant because ballot instructions cannot affect voter behavior.
- **(B)** Trials must be completed before ranked-choice voting is considered in any city.
- **(C)** Trials prove that all voters will make identical ranking choices.
- **(D)** Trials could measure voter comprehension but could never affect which equipment a city purchases.
- **(E)** Trials could provide useful evidence, but making them a strict prerequisite risks delaying a reform whose benefits can be monitored after implementation.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative reading: author response (Chapter 17)

1. **Conclusion.** A’s implementation-first stance allows evidence gathering but not universal postponement.
2. **Support.** A recommends adoption when equipment is replaced with audits and publication of completion rates.
3. **Prephrase.** Infer A’s likely answer to B without making A deny usefulness of trials.
4. **Why (E) is right.** The answer captures A’s willingness to monitor real implementation and skepticism of rigid prerequisites.
5. **Why the others fail.**
   - **(A)** Contradiction: A calls for clear instructions and tracking incomplete rankings.
   - **(B)** Adopts B’s threshold rather than A’s more permissive stance.
   - **(C)** Unsupported and implausibly absolute; neither author seeks identical choices.
   - **(D)** A does not separate evidence about usability from implementation choices in this categorical way.

**Check:** A treats possible uneven familiarity as a reason to monitor, not necessarily to postpone.
::::
:::

:::problem[Question II.24]
According to Passage B, why would comparing precinct totals after implementation be insufficient by itself?

- **(A)** Precinct results are always deliberately falsified by election officials.
- **(B)** Precincts differ in factors other than the ballot design that may account for their observed results.
- **(C)** Ranked-choice ballots contain no information beyond first preferences.
- **(D)** Post-election data cannot include any ranking-completion rates.
- **(E)** Different instruction formats necessarily produce identical comprehension levels.

::::solution[Solution]
**Answer:** (B)

**Type:** RC Detail (Chapter 18)

1. **Conclusion.** B argues that raw precinct comparisons do not identify a ballot-design effect.
2. **Support.** B says precincts vary in other ways and advocates controlled instruction trials.
3. **Prephrase.** Return to B’s second paragraph for the methodological limitation.
4. **Why (B) is right.** Other precinct differences confound any simple comparison of outcomes.
5. **Why the others fail.**
   - **(A)** Invented accusation: no fraud claim appears.
   - **(C)** Opposite: B acknowledges additional expressive potential.
   - **(D)** Unsupported absolute: B objects to causal interpretation, not availability of data.
   - **(E)** Contradiction: trialing instruction formats is proposed precisely to compare effects.

**Check:** Observational differences across precincts ≠ effects of ballot design alone.
::::
:::

:::problem[Question II.25]
Which one of the following best captures Passage A’s likely view of ballots on which voters rank only one candidate?

- **(A)** They should automatically be discarded even when the first preference is legible.
- **(B)** Such ballots need not invalidate the reform, because voters may choose to state only their first preference.
- **(C)** They prove that ranked-choice voting yields no additional information from any voter.
- **(D)** They must be counted as votes for every candidate the voter left unranked.
- **(E)** They demonstrate that election audits are unnecessary.

::::solution[Solution]
**Answer:** (B)

**Type:** RC Inference (Chapter 18)

1. **Conclusion.** A does not require every voter to rank every candidate.
2. **Support.** A states voters are free to express only one preference.
3. **Prephrase.** Infer tolerance of partial rankings without assuming how all elections count them.
4. **Why (B) is right.** The answer follows from A’s refusal to make complete ranking a threshold for reform.
5. **Why the others fail.**
   - **(A)** Unsupported penalty: A treats single rankings as permissible.
   - **(C)** Quantifier trap: one voter’s single mark does not erase others’ rankings.
   - **(D)** Invented counting rule: neither author says that.
   - **(E)** Wrong inference: A explicitly endorses audits.

**Check:** Partial expression is explicitly permitted by A’s rationale.
::::
:::

:::problem[Question II.26]
Which one of the following findings would most directly address a concern raised by both authors?

- **(A)** A study finds that revised instructions substantially reduce differences in ballot-completion errors among voter groups without preventing voters from ranking additional candidates.
- **(B)** A survey finds that candidates prefer debates held on weekday evenings.
- **(C)** Election analysts can extract more preference data from a ranked ballot regardless of whether voters understand it.
- **(D)** A city’s new ballot boxes cost less than the ones they replaced.
- **(E)** A district reports that its ranked ballot contains more spaces for candidate choices than its prior ballot.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative reading: application (Chapter 17)

1. **Conclusion.** Both authors care about useful additional expression and implementation quality.
2. **Support.** A supports clear instructions and monitoring; B stresses comparable success across voter groups.
3. **Prephrase.** Find evidence that improves actual usability while retaining the expressive benefit.
4. **Why (A) is right.** Lower, more equal error rates with continued ranking opportunity speak directly to both authors’ criteria.
5. **Why the others fail.**
   - **(B)** Out of scope: candidates’ scheduling preferences do not address ranked ballot usability.
   - **(C)** Half-right trap: it addresses A’s information benefit but sidesteps B’s comprehension concern.
   - **(D)** Different cost category: equipment expense alone does not test equitable use and information.
   - **(E)** More available ranking slots show potential capacity, not the actual equitable use central to both authors.

**Check:** Useful extra choices plus equitable comprehension connect the two priorities.
::::
:::

:::problem[Question II.27]
Which one of the following most accurately characterizes the authors’ different approaches?

- **(A)** Passage A offers a purely historical account, while Passage B supplies an artist’s personal testimony.
- **(B)** Passage A proves the reform guarantees civil campaigns, while Passage B denies that ballots can express preferences.
- **(C)** Passage A examines only voter psychology, while Passage B examines only election hardware.
- **(D)** Passage A asks whether elections can be held at all, while Passage B asks whether elections should be abolished.
- **(E)** Passage A weighs a procedural benefit against practical implementation costs, while Passage B focuses on evidence needed to establish that the benefit is accessible across voter groups.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative reading: organization (Chapter 17)

1. **Conclusion.** A makes a qualified practical adoption argument; B sets an empirical threshold for equitable use.
2. **Support.** The passages assign different weight to implementation monitoring versus controlled pre-adoption evidence.
3. **Prephrase.** Compare argument strategy, not just whether the conclusions are pro or cautious.
4. **Why (E) is right.** The answer states each author’s distinctive emphasis without adding claims absent from the text.
5. **Why the others fail.**
   - **(A)** Incorrect genres: both make contemporary policy arguments.
   - **(B)** Double misrepresentation: neither makes those categorical claims.
   - **(C)** Reversed and too narrow: A weighs implementation; B emphasizes comprehension.
   - **(D)** Wild scope shift: both discuss ballot-system design, not election existence.

**Check:** Each passage argues a policy threshold from a different priority.
::::
:::

## 31.3 Section III: Logical Reasoning

:::problem[Question III.1]
A research crew tagged penguins on two islands, North and South. Every bird tagged on North Island was an adult. Some birds tagged on South Island were juveniles, and all juvenile birds tagged there were weighed. No bird weighed on South Island was transferred to North Island for observation. Researchers also measured bill length in several adults on North Island, but did not weigh every adult there. The crew’s records apply only to the tagged birds and say nothing about untagged penguins elsewhere in the colony.

Which one of the following must be true?

- **(A)** Every adult penguin tagged on North Island was weighed.
- **(B)** Some juveniles were tagged on North Island.
- **(C)** No adult penguin was weighed on South Island.
- **(D)** All untagged birds were juveniles.
- **(E)** At least one penguin weighed on South Island was not transferred to North Island for observation.

::::solution[Solution]
**Answer:** (E)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** A necessary consequence about some weighed South Island birds is requested.
2. **Support.** There are tagged juveniles on South, all are weighed, and no weighed South birds are transferred north.
3. **Prephrase.** Combine the existential juvenile observation with the weighing and nontransfer rules.
4. **Why (E) is right.** Pick one tagged South juvenile: it was weighed, and it was not transferred north.
5. **Why the others fail.**
   - **(A)** Unsupported universal: North adults had some bill measurements, not universal weighing.
   - **(B)** Direct contradiction: all tagged North birds were adults.
   - **(C)** Illicit exclusion: weighing every juvenile does not rule out weighing adults.
   - **(D)** Out of scope: no information about untagged birds is supplied.

**Check:** Some South juvenile -> some South weighed -> no transfer north.
::::
:::

:::problem[Question III.2]
A critic claims that a museum made a poor acquisition because a new street artist has fewer social-media followers than artists already represented in the collection. Successful museum acquisitions, the critic says, generally involve artists who eventually become influential. The critic then treats online follower counts as an exact measure of future artistic influence, even though the museum purchased work from this artist because of its unusual technique. The critic acknowledges that follower counts change rapidly but insists the lower present number settles the acquisition’s quality.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that museum works must be displayed outdoors to remain valuable.
- **(B)** argues that unusual technique alone guarantees an artist’s long-term influence.
- **(C)** presumes without adequate support that a current popularity measure reliably determines future artistic influence.
- **(D)** concludes that high follower counts are caused by museum purchases.
- **(E)** ignores that the artist’s technique may appeal to a narrower audience than the museum’s existing artists.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The museum’s acquisition was poor.
2. **Support.** The artist has fewer followers, and influence is said to matter for acquisition success.
3. **Prephrase.** Identify the unsupported leap from popularity now to artistic influence later.
4. **Why (C) is right.** Current followers could be a poor predictor of eventual influence; treating that proxy as decisive is not warranted.
5. **Why the others fail.**
   - **(A)** Material/topic switch: placement of artworks is not under debate.
   - **(B)** Opposite speaker: the museum cites technique; the critic does not make this inference.
   - **(D)** Reversed causal claim: no causal explanation of follower counts is asserted.
   - **(E)** Niche appeal does not validate the leap from present follower counts to eventual artistic influence.

**Check:** Popularity at one time is not logically identical to future influence.
::::
:::

:::problem[Question III.3]
A school nutrition director believes placing vegetables first in cafeteria lines causes students to buy more vegetables. In one school, vegetable purchases rose after the serving line was rearranged, although the school also adopted a new menu. A second school kept the original line but made different menu changes. The director proposes expanding the arrangement policy districtwide and wants evidence that the physical placement, rather than changes in available food or school population, caused the higher purchasing rate.

Which one of the following, if true, most strengthens the director’s causal claim?

- **(A)** Students rated the new menu as tastier than the old one.
- **(B)** Vegetable sales at the second school rose after it introduced a different menu without rearranging its line.
- **(C)** Vegetable purchases increased at the school that changed both its line and menu.
- **(D)** Students who bought vegetables were likely to finish eating them.
- **(E)** When otherwise identical cafeteria lines randomly alternated the first-serving position between vegetables and starches, purchases of vegetables were higher on vegetable-first days.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Vegetable-first placement raises vegetable purchases.
2. **Support.** One school changed both line and menu, leaving a confound.
3. **Prephrase.** Hold menus constant and vary placement alone.
4. **Why (E) is right.** Randomly alternating only the order controls key rival factors and observes the predicted purchasing change.
5. **Why the others fail.**
   - **(A)** Alternative explanation trap: improved taste could explain increased sales without placement.
   - **(B)** This suggests a menu effect as an alternative, rather than isolating the claimed placement effect.
   - **(C)** Repetition of the correlation cannot separate the simultaneous changes.
   - **(D)** Consumption of selected food is a different outcome from causal effects on purchase choice.

**Check:** Same offerings + randomized ordering isolates placement better than before-after data.
::::
:::

:::problem[Question III.4]
A ferry operator raised the price of a single ride by twenty percent in January. Economic consultants therefore expected ridership to decline. Instead, the operator sold substantially more rides in February than the previous February. Service frequency and the number of residents in the service area remained almost unchanged. The operator insists its tickets were not discounted after the announced increase, so the higher ridership must be explained by some other change rather than by a hidden price cut.

Which one of the following, if true, most helps resolve the apparent discrepancy?

- **(A)** The ferry company advertised the fare increase extensively before January.
- **(B)** A single ferry ride takes slightly longer than an automobile trip over the open bridge.
- **(C)** Passengers could begin purchasing ferry tickets through a mobile app in January.
- **(D)** The main highway bridge was closed for emergency repairs in February, leaving the ferry as the only direct crossing for many commuters.
- **(E)** The ferry operator increased the number of ticket agents without changing vessel departures.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** Rides increased despite a fare hike.
2. **Support.** Fare, service frequency, and local population alone predict or suggest fewer rides.
3. **Prephrase.** Look for a change that sharply increases demand independent of the fare.
4. **Why (D) is right.** Closing an alternative crossing forces some travelers onto the ferry, outweighing the deterrent effect of higher prices.
5. **Why the others fail.**
   - **(A)** Publicity about higher prices does not explain the sharp increase in journeys when tickets were not discounted.
   - **(B)** Travel-time comparison with an open bridge does not explain behavior during February.
   - **(C)** Easier payment may increase convenience somewhat, but the competing bridge closure directly accounts for why many more trips became necessary.
   - **(E)** Faster ticket service might affect convenience, but there is no evidence that it outweighed a major fare increase.

**Check:** Demand can rise after the competing route disappears even when price increases.
::::
:::

:::problem[Question III.5]
An experimenter asked volunteers to choose either a twenty-minute walk or a quiet seated activity, then rate their mood afterward. Walkers reported more positive moods. The experimenter concludes that the act of walking improved mood, not merely that people who preferred walking were already happier. Although volunteers chose their activity and were not randomly assigned, the experimenter insists the difference between the two groups is evidence of a beneficial causal effect.

Which one of the following is an assumption on which the experimenter’s conclusion depends?

- **(A)** Every walker ended the session in a better mood than every seated volunteer.
- **(B)** Volunteers knew nothing about the study’s objective.
- **(C)** The seated volunteers disliked all physical activity.
- **(D)** A walk longer than twenty minutes would have improved mood even more.
- **(E)** The entire post-activity mood difference was not already present between the groups before the activities began.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Walking caused an improvement in mood.
2. **Support.** After self-selection, walkers reported better moods; baseline group differences are not measured.
3. **Prephrase.** The observed difference cannot be entirely attributable to preexisting mood.
4. **Why (E) is right.** Negate: all of the difference predated the activities. Then the after-only contrast supplies no evidence of walking-induced change.
5. **Why the others fail.**
   - **(A)** Too strong: the conclusion concerns an overall effect, not perfectly separated individuals.
   - **(B)** Blinding might help but is not essential to claiming a difference caused by walking.
   - **(C)** Unsupported motivation: the study need not presuppose total dislike of exercise.
   - **(D)** Dose-response speculation beyond the tested activity.

**Check:** If the groups were already different by the same amount, the causal reading loses its support.
::::
:::

:::problem[Question III.6]
A museum educator disputes a claim that visitors cannot appreciate abstract painting without lengthy wall labels. She observes that galleries with only short labels sometimes attract detailed conversations among visitors. In a pilot program, one gallery replaced lengthy labels with short questions, after which visitors offered a wider variety of interpretations in recorded discussions. The educator does not infer that labels are useless in every context. Instead, she challenges the assertion that lengthy explanation is a prerequisite for serious engagement.

Which one of the following best describes the educator’s reasoning?

- **(A)** She argues that visitors prefer short labels because most museum educators do.
- **(B)** She disputes a claim of necessity by presenting cases in which the claimed result occurs without the supposedly required condition.
- **(C)** She proves that every interpretive conversation improves art knowledge.
- **(D)** She derives the pilot’s results from a theory about human visual perception.
- **(E)** She assumes that what is sufficient for one gallery is sufficient for all museums.

::::solution[Solution]
**Answer:** (B)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Lengthy labels are not required for serious engagement.
2. **Support.** Visitors sometimes engage substantially with short labels or short questions.
3. **Prephrase.** To disprove a universal necessity claim, find even one credible exception.
4. **Why (B) is right.** She supplies cases of engagement absent lengthy labels and carefully limits her conclusion to rejecting necessity.
5. **Why the others fail.**
   - **(A)** Appeal to authority is absent; the argument uses visitor behavior.
   - **(C)** Overstatement: quality of knowledge is not measured for every discussion.
   - **(D)** Invented mechanism: the example is empirical, not a theoretical deduction.
   - **(E)** Scope trap: she explicitly stops short of a universal claim.

**Check:** If serious engagement occurs without lengthy labels, “engagement -> lengthy labels” is false.
::::
:::

:::problem[Question III.7]
A city analyst estimates that adding bike-share stations to residential blocks will reduce car trips. Residents near existing stations make fewer car trips per week than residents farther away. The analyst argues the stations cause the difference, because many station users say they like having a bicycle nearby. The city has not examined whether stations were preferentially installed in neighborhoods that already had lower car ownership or better pedestrian access.

Which one of the following, if true, most weakens the analyst’s argument?

- **(A)** Even before bike-share stations were installed, the neighborhoods selected for stations had substantially fewer car trips than otherwise similar neighborhoods.
- **(B)** Residents near stations are more likely to recognize the bike-share logo.
- **(C)** Residents close to stations are more likely to use shared bicycles for occasional weekend recreation.
- **(D)** Some car trips are longer than a typical bike-share ride.
- **(E)** Many residents who own cars also have active bike-share memberships.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Stations caused reductions in car use.
2. **Support.** The evidence is a neighborhood correlation with possible placement selection.
3. **Prephrase.** Look for lower car trips before bike-share arrived.
4. **Why (A) is right.** If the difference predated the stations, neighborhood characteristics can explain the association without a station effect.
5. **Why the others fail.**
   - **(B)** Awareness does not establish change in driving caused by station installation.
   - **(C)** Occasional recreational use does not establish that the stations reduced commuting or other car trips.
   - **(D)** Partial limitation might narrow the effect but does not explain the observed entire difference as directly as preexisting patterns.
   - **(E)** Dual membership does not demonstrate that the stations caused a reduction in the number of trips by car.

**Check:** Pre-treatment differences undercut attribution of the current difference to treatment.
::::
:::

:::problem[Question III.8]
A zoologist advises against releasing a rehabilitated otter immediately. Although it is healthy, it has never hunted without help. She argues that release is justified only when an animal has demonstrated the skills needed to meet its basic needs in the environment to which it will return. She does not demand proof that the animal will never face danger; wild animals always face risks. Rather, she rejects exposing an animal to risks it is predictably unable to manage because a crucial survival skill remains untested.

Which one of the following most accurately expresses the principle underlying the zoologist’s recommendation?

- **(A)** An animal should not be released into an environment until it has demonstrated the capacity to perform essential survival tasks there.
- **(B)** No wild animal should ever be exposed to environmental risks.
- **(C)** An animal is ready for release as soon as it has no diagnosed disease.
- **(D)** Human care is always preferable to an animal’s independent life.
- **(E)** An animal that hunts successfully once should be released regardless of its ability to find shelter.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Delay this otter’s release.
2. **Support.** Essential independent hunting competence has not been demonstrated.
3. **Prephrase.** Identify a readiness rule grounded in proven necessary skills, not risk-free survival.
4. **Why (A) is right.** The criterion directly explains why a healthy but untested hunter should remain in rehabilitation.
5. **Why the others fail.**
   - **(B)** Absolute trap: the zoologist explicitly accepts ordinary wild risks.
   - **(C)** Necessary/sufficient confusion: health alone is insufficient when hunting ability is untested.
   - **(D)** Overgeneralization: the recommendation is conditional and allows later release.
   - **(E)** The rule neglects other essential survival tasks and reduces readiness to one performance.

**Check:** No demonstrated essential skill -> not yet ready for release.
::::
:::

:::problem[Question III.9]
A nutrition scientist argues that prominent calorie labels may fail to lower total daily calorie intake even when they change lunch choices. Participants in a study ordered smaller lunches when menu labels were visible. However, researchers observed that many of these participants ate larger evening snacks than they had on days without labels. This compensatory eating is a reason to distinguish a reduction in calories at one meal from a reduction in calories over the whole day. The scientist thus recommends measuring full-day intake before claiming that the labels improve diets.

The claim that many participants ate larger evening snacks plays which one of the following roles?

- **(A)** It is the scientist’s primary recommendation about future study design.
- **(B)** It presents the original claim that calorie labels necessarily reduce total calories.
- **(C)** It is evidence that limits what can be inferred from the observed reduction in lunch calories.
- **(D)** It illustrates the scientist’s claim that the labeled lunch meals were larger than the unlabeled ones.
- **(E)** It is a concession that the labels had no effect on lunch choices.

::::solution[Solution]
**Answer:** (C)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** Full-day intake should be measured before inferring an improved diet.
2. **Support.** Smaller labeled lunches may be offset by later snack consumption.
3. **Prephrase.** Look for a fact that limits the scope of an earlier finding.
4. **Why (C) is right.** The snack observation explains why the lunchtime effect does not automatically extend to daily intake.
5. **Why the others fail.**
   - **(A)** Role confusion: the recommendation is to measure full-day intake.
   - **(B)** Opposite role: the snack evidence challenges that inference.
   - **(D)** Wrong meal and time: the evidence concerns later snacks while the labeled lunches were smaller.
   - **(E)** Contradiction: the scientist accepts smaller lunches when labels were visible.

**Check:** The sentence is an offsetting premise, not the concluding recommendation.
::::
:::

:::problem[Question III.10]
An art museum’s policy states that any object with unresolved provenance may not travel on an international loan. Separately, any object prohibited from international loans must receive a provenance committee review before its next public exhibition. A vase is scheduled for exhibition, but the registrar has not said whether its provenance is unresolved. A trustee nonetheless concludes that a committee review is required before the vase’s next exhibition, relying on the two rules and one missing assumption.

Which one of the following, if assumed, enables the trustee’s conclusion to be properly drawn?

- **(A)** Any object reviewed by the committee is eventually exhibited.
- **(B)** The vase has unresolved provenance.
- **(C)** The vase was loaned internationally at least once in the past.
- **(D)** The vase is more fragile than other items in the collection.
- **(E)** At least one museum object has been subject to an international loan.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The vase requires a provenance review before exhibition.
2. **Support.** Unresolved provenance -> barred from international loan -> review, but the vase’s status is missing.
3. **Prephrase.** Bridge the vase to the first antecedent.
4. **Why (B) is right.** Assuming unresolved provenance initiates both conditional rules and entails review.
5. **Why the others fail.**
   - **(A)** Wrong arrow: review -> exhibition does not establish this vase needs review.
   - **(C)** Past loan history neither establishes current unresolved provenance nor triggers the two forward-looking rules.
   - **(D)** Fragility is unrelated to the stated policy antecedents.
   - **(E)** Existential distractor: a loan elsewhere cannot trigger review for the vase.

**Check:** Unresolved -> no loan -> review; apply to the vase.
::::
:::

:::problem[Question III.11]
A transportation consultant surveys only commuters who use the city’s premium carpooling app. Nearly all respondents say they support building a designated pickup lane at the downtown station. The consultant therefore concludes that nearly all residents of the city support the lane. She argues the survey is credible because app users are especially informed about pickup congestion, but the city includes many people who do not own cars or regularly visit the station. No attempt was made to sample those residents.

The consultant’s reasoning is flawed because it...

- **(A)** assumes that all premium carpool-app users have personally experienced congestion at the station.
- **(B)** treats a necessary condition for using the app as a sufficient condition.
- **(C)** assumes that informed commuters prefer carpooling apps to every other form of transport.
- **(D)** fails to show that the surveyed users could identify all effects of the proposed pickup lane.
- **(E)** generalizes from a group selected for special interest in a policy to a broader population that may have different preferences.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Nearly all city residents support the lane.
2. **Support.** Nearly all premium carpool app users, a special-interest subset, report support.
3. **Prephrase.** Identify the sampling and generalization defect.
4. **Why (E) is right.** People most affected by pickup congestion need not represent all residents, so selection may bias the extrapolation.
5. **Why the others fail.**
   - **(A)** The consultant needs representative public preferences, not evidence that every selected app user experienced the problem.
   - **(B)** Wrong flaw family: no conditional eligibility inference occurs.
   - **(C)** Preference across all modes is not inferred; the problematic leap concerns the broader population’s policy support.
   - **(D)** Perfect expertise about impacts is not required to express policy support; selection bias drives the population inference.

**Check:** Informed respondents can still be unrepresentative.
::::
:::

:::problem[Question III.12]
Biologists studied a beetle species that survives long dry periods. Beetles from two populations were held in identical chambers with limited water. Members of the ridge population lost water more slowly, on average, than members of the valley population, though there was considerable overlap among individuals. The biologists also found differences in the waxy layers covering the insects’ outer shells. They did not manipulate those layers, and they caution that the study cannot establish whether the shell differences account for the water-loss results.

Which one of the following is most strongly supported by the study?

- **(A)** Every ridge beetle retained more water than every valley beetle.
- **(B)** The shell’s waxy layer is the only possible cause of water retention.
- **(C)** Ridge beetles always survive longer in the wild than valley beetles.
- **(D)** The populations differed in average water-loss rates under the tested conditions, but the cause of that difference was not established.
- **(E)** Valley beetles do not possess any waxy shell layer.

::::solution[Solution]
**Answer:** (D)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Find what can be inferred without assigning a causal mechanism.
2. **Support.** Group mean water-loss rates differed, individual outcomes overlapped, and shells were not manipulated.
3. **Prephrase.** Restate the observed difference with its causal limitation.
4. **Why (D) is right.** The answer preserves the controlled finding and refuses to overclaim why it occurred.
5. **Why the others fail.**
   - **(A)** Universal trap: individual results overlapped.
   - **(B)** Unjustified causation: no manipulation tested that mechanism.
   - **(C)** External validity trap: chamber water loss does not establish wild survival time.
   - **(E)** Opposite of evidence: the biologists compared layers in both populations.

**Check:** Observed mean difference ≠ proof of a particular shell-based cause.
::::
:::

:::problem[Question III.13]
A transit authority believes replacing platform signs that list only route numbers with signs that also show destinations will reduce accidental boarding of the wrong train. At one station, wrong-train complaints fell after destination signs were installed, but the authority also increased the number of employees giving directions. To support spending on signs rather than staffing elsewhere, planners need evidence that destination information itself changes boarding decisions.

Which one of the following, if true, most strengthens the planners’ hypothesis?

- **(A)** Commuters report that destination signs look more modern than the old signs.
- **(B)** The station that installed signs hired more employees to answer questions.
- **(C)** A nearby station reduced wrong-train complaints after adding both destination signs and extra staff.
- **(D)** At stations with identical staffing, randomly assigned platforms using destination signs had fewer mistaken boardings than those using number-only signs.
- **(E)** A few riders continue to board the wrong train at stations with destination signs.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Signs with destinations reduce mistaken boarding.
2. **Support.** Complaints declined amid simultaneous staffing changes.
3. **Prephrase.** Compare boarding under different signs while keeping staffing the same.
4. **Why (D) is right.** Randomized platform signs isolate the type of information presented and measure actual mistaken boarding.
5. **Why the others fail.**
   - **(A)** Appearance preference does not show fewer boarding errors.
   - **(B)** Alternative-cause trap: staffing could account for lower complaints.
   - **(C)** A joint intervention does not isolate the sign’s contribution, unlike the controlled comparison.
   - **(E)** Nonzero residual errors do not undermine the relative-effect hypothesis, nor strengthen it.

**Check:** Controlled sign variation with constant staff supports causation.
::::
:::

:::problem[Question III.14]
A regional museum will digitize its collection of fragile sketches and place high-resolution images on a public website. The director predicts that doing so will expand meaningful public access to the sketches, since people unable to travel to the museum will be able to examine the images. The museum does not plan to publish interpretive essays with the images, and the originals will remain unavailable for handling. The director emphasizes the opportunity for close inspection rather than claiming that online viewing is identical to seeing an original.

Which one of the following is an assumption required by the director’s argument?

- **(A)** At least some people who cannot examine the original sketches in person will be able to access and meaningfully inspect the online images.
- **(B)** Every online viewer will understand the artist’s intentions better than a visitor to the museum.
- **(C)** Online images reproduce every physical quality of the original paper.
- **(D)** The website will allow users to zoom farther into each sketch than an ordinary museum visitor can.
- **(E)** Most visitors prefer digital displays to real works on paper.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Digitization will expand meaningful public access.
2. **Support.** People unable to visit may inspect high-resolution web images.
3. **Prephrase.** There must be at least some otherwise excluded users who can actually use the images.
4. **Why (A) is right.** Negate: no one excluded from physical access can meaningfully inspect the images; then the claimed enlargement of meaningful access through remote viewing fails.
5. **Why the others fail.**
   - **(B)** Too strong: relative interpretive mastery is not the promised benefit.
   - **(C)** Unnecessary perfection: useful visual access need not reproduce texture.
   - **(D)** Zoom functionality could improve inspection, but expanded access does not require superior magnification.
   - **(E)** Preference of existing visitors is not necessary to expanding access for distant people.

**Check:** Without new effective users, the argument’s access-expansion mechanism vanishes.
::::
:::

:::problem[Question III.15]
A clinic’s printed policy says that every meal approved for its low-sodium program contains less than six hundred milligrams of sodium, and any meal containing less than six hundred milligrams of sodium qualifies for a blue menu marker. The baked squash meal is approved for the low-sodium program. Therefore, it qualifies for a blue marker. The argument does not assert that unapproved meals are necessarily high in sodium or that all blue-marked meals are approved by the program.

Which one of the following most closely parallels the reasoning?

- **(A)** Every certified site is inspected annually. This site is inspected annually, so it is certified.
- **(B)** Some certified sites are listed in the directory. This site is certified, so it must be listed.
- **(C)** Every certified recycling site is inspected annually, and every annually inspected site appears on the municipal directory. This center is certified, so it appears on the directory.
- **(D)** Every inspected site is listed. This site is not inspected, so it cannot be listed.
- **(E)** Some listed sites are certified, and some certified sites are inspected, so every listed site is inspected.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Approved meal -> low sodium -> blue marker.
2. **Support.** Two universal conditionals and membership in the first category are given.
3. **Prephrase.** Match a two-link chain concluded by modus ponens.
4. **Why (C) is right.** Certified -> inspected -> directory, plus this center certified, yields directory, identical structure.
5. **Why the others fail.**
   - **(A)** Converse trap: inspecting is necessary but may not prove certification.
   - **(B)** Quantifier switch: “some” does not justify an arbitrary instance.
   - **(D)** Denying antecedent: other sites might be listed without inspection.
   - **(E)** Unsupported universal: two existential claims cannot yield “every.”

**Check:** A -> B -> C and A, therefore C.
::::
:::

:::problem[Question III.16]
Volunteers reported far fewer owl nests in a forest this spring than in previous springs. Nevertheless, biologists who fitted radio transmitters to a representative sample of adult owls estimate that the number of breeding pairs was nearly unchanged. The volunteers followed the same trails and spent similar hours searching. Officials are confident neither group made a counting arithmetic mistake. They seek a biological or behavioral explanation for why visible nests declined while the estimated number of breeding pairs remained stable.

Which one of the following, if true, most helps explain the discrepancy?

- **(A)** The volunteers enjoyed looking for owls more this spring than last spring.
- **(B)** A large storm destroyed many exposed old nests, after which the same breeding pairs built new nests higher in dense foliage away from the trails.
- **(C)** Owls usually defend their territories against neighboring adults.
- **(D)** The forest had a greater number of small mammals available as prey that spring.
- **(E)** The tagged adult owls continued occupying territories at approximately the same rate.

::::solution[Solution]
**Answer:** (B)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** Volunteer nest reports fell while breeding pairs stayed stable.
2. **Support.** Search effort and location are comparable; biologists estimate unchanged pairs.
3. **Prephrase.** Find a change in the visibility or location of nests rather than number of pairs.
4. **Why (B) is right.** New nests away from customary search paths remain present but unseen, reconciling both measurements.
5. **Why the others fail.**
   - **(A)** Search enjoyment cannot explain declining visible nest counts with stable effort.
   - **(C)** General behavior does not connect nest visibility to the observed change.
   - **(D)** Food abundance may affect owl breeding, but it does not explain why existing breeding pairs became less visible to trail observers.
   - **(E)** This reinforces the stable-pairs estimate without explaining why fewer nests were visible.

**Check:** Number of nests visible from trails can decline without fewer breeding pairs.
::::
:::

:::problem[Question III.17]
A cognitive scientist argues that offices should not require employees to receive every nonurgent digital notification instantly. Laboratory participants who received messages continuously made more errors on a proofreading task than participants who received the same messages in batches. Some managers worry that batching would delay responses, but the scientist notes that the experiment excluded urgent requests, which can still be delivered immediately. She concludes that default batching for nonurgent messages is a sensible workplace policy, rather than a prohibition on communication during work.

Which one of the following most accurately states the main conclusion?

- **(A)** Proofreading participants receiving continuous messages made more errors.
- **(B)** Offices should use batch delivery as the default for nonurgent notifications.
- **(C)** Urgent workplace requests should never be delayed.
- **(D)** All digital notifications distract workers equally.
- **(E)** Managers worry about slow responses to messages.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** Batch delivery should be the default for nonurgent messages.
2. **Support.** Continuous notifications harmed task accuracy, and urgent communications can remain instant.
3. **Prephrase.** Identify the policy recommendation supported by an empirical result.
4. **Why (B) is right.** The proposed default is the governing conclusion; the study and urgency exception explain its rationale and scope.
5. **Why the others fail.**
   - **(A)** Premise trap: this finding supports the proposed policy.
   - **(C)** Background qualification: urgency is exempted but is not the central recommendation.
   - **(D)** Overgeneralization: the experiment tests two schedules for the same messages.
   - **(E)** Opposing concern: the scientist acknowledges it and narrows the recommendation.

**Check:** The main conclusion is a policy, not a restatement of the experimental observation.
::::
:::

:::problem[Question III.18]
A curator claims new adjustable lighting improved public appreciation of a sculpture exhibition. After the lighting change, the exhibition received more favorable online reviews. The curator acknowledges that the museum also began offering free admission on Fridays, but argues that attendance grew without altering the sculptures themselves, so lighting must explain the higher review scores. The curator did not distinguish between reviews posted before and after visitors learned that admission would be free.

Which one of the following, if true, most weakens the curator’s claim?

- **(A)** The new lamps consume less electricity than the old ones.
- **(B)** Museum attendance increased following free-admission Fridays.
- **(C)** When reviewers were matched for visit day and whether admission was free, reviews before and after the lighting change were equally favorable.
- **(D)** Most sculptures were originally carved under natural light.
- **(E)** Museum visitors who attend the sculpture exhibition often also visit the painting galleries.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Adjustable lighting caused improved appreciation.
2. **Support.** Online review scores improved as lighting and admission conditions changed.
3. **Prephrase.** Look for a comparison holding the admission-related visitor mix constant.
4. **Why (C) is right.** No within-comparable-group improvement suggests the aggregate rise stems from who visited or when, not the lighting.
5. **Why the others fail.**
   - **(A)** Operating-cost benefit does not establish appreciation caused by lighting.
   - **(B)** Possible alternative explanation but not direct evidence that lighting had no review effect.
   - **(D)** Historical production lighting is not a measure of visitor appreciation.
   - **(E)** Movement between galleries does not tell us whether lighting or free admission accounts for the improved sculpture reviews.

**Check:** Controlling for free-entry visit conditions removes the claimed lighting effect.
::::
:::

:::problem[Question III.19]
A passenger claims that the Number 8 bus must run express because every express route operated by the city stops at the central transfer station, and the Number 8 bus stops there. She admits that many local routes also pass through downtown but argues that the central station is so important it must be the distinguishing characteristic of express service. The transit agency’s rule guarantees central-station service for express buses; it does not say that serving the station is sufficient to make a bus express.

The passenger’s argument is most vulnerable to criticism because it...

- **(A)** confuses a condition necessary for being an express route with one sufficient to establish that status.
- **(B)** rejects the rule that all express routes stop at the central station.
- **(C)** infers that buses never stop anywhere outside the central station.
- **(D)** reasons that the transit agency lacks authority to define bus routes.
- **(E)** treats the fact that some local routes serve downtown as evidence they cannot be local.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Number 8 must be an express route.
2. **Support.** Express -> central stop, and Number 8 -> central stop; the passenger infers express.
3. **Prephrase.** Recognize affirming the consequent.
4. **Why (A) is right.** A bus may stop at the station without being express, exactly as local routes might.
5. **Why the others fail.**
   - **(B)** Opposite: the passenger relies upon that rule.
   - **(C)** Invented exclusivity: the conclusion concerns express classification, not other stops.
   - **(D)** No attack on the agency’s authority appears.
   - **(E)** Reversed fact: that concession actually highlights the possibility of local service.

**Check:** Express -> central is not central -> express.
::::
:::

:::problem[Question III.20]
Dietitian Perez: The school should offer a plant-based main dish every day. Students should have a reliable option that does not depend on which week of the menu cycle it is. I do not object to serving meat as another choice. Principal Tan: A plant-based option is important, and I agree it should never be absent for an entire week. But a daily requirement would force us to remove popular dishes on some days given our limited kitchen capacity. I favor offering the option three days a week instead.

The speakers disagree over whether...

- **(A)** schools should provide any plant-based option at all.
- **(B)** meat dishes must be eliminated from school menus.
- **(C)** school kitchens have unlimited capacity to prepare meals.
- **(D)** a plant-based main dish should be offered on every school day.
- **(E)** a plant-based option is unimportant to students.

::::solution[Solution]
**Answer:** (D)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Find the live disagreement about frequency.
2. **Support.** Perez says every day; Tan says three days a week, not every day.
3. **Prephrase.** Each speaker must have a determinable opposed position.
4. **Why (D) is right.** They affirm opposite answers to daily availability while agreeing on the importance of some availability.
5. **Why the others fail.**
   - **(A)** Agreement trap: both affirm a recurring plant-based option.
   - **(B)** No-stake trap: Perez explicitly permits meat and Tan never favors elimination.
   - **(C)** No-stake claim: Tan says capacity is limited, while Perez offers no view on its size.
   - **(E)** Agreement-opposite: both state that a plant-based option matters.

**Check:** Perez: yes daily. Tan: no daily.
::::
:::

:::problem[Question III.21]
A coastal reserve classifies any beach with verified artificial-light interference as requiring night patrols. Every beach requiring night patrols is included in the weekly ranger roster. Beach K is monitored by researchers, but no one has reported whether the researchers verified artificial-light interference there. A volunteer claims that Beach K must appear on the weekly ranger roster because of the reserve’s two rules, plus one additional fact not yet established.

Which one of the following, if assumed, would allow the volunteer’s conclusion to be properly drawn?

- **(A)** Every beach on the ranger roster is monitored by researchers.
- **(B)** Artificial-light interference has been verified at Beach K.
- **(C)** The reserve has monitored several beaches for more than a decade.
- **(D)** Some beaches on the roster have no turtle hatchlings.
- **(E)** Beach K attracts more nighttime visitors than any other reserve beach.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Beach K must appear on the ranger roster.
2. **Support.** Verified interference -> required patrols -> roster; Beach K has no verified interference premise.
3. **Prephrase.** Supply the missing antecedent for Beach K.
4. **Why (B) is right.** Verification establishes required patrols and hence roster inclusion under the two rules.
5. **Why the others fail.**
   - **(A)** Wrong direction: roster -> monitored cannot give monitored -> roster.
   - **(C)** Unrelated history does not trigger the night-patrol classification.
   - **(D)** Other-site counterexample does not determine Beach K’s status.
   - **(E)** Night visits might motivate vigilance, but they do not by themselves establish verified light interference, the rule’s trigger.

**Check:** Verified K -> patrol K -> roster K.
::::
:::

:::problem[Question III.22]
A naturalist notes that every bird nesting in the city’s protected rooftop gardens is a swallow. He observes a swallow building a nest on the old library roof and concludes that the library roof must be one of the protected rooftop gardens. The naturalist has not examined whether the library joined the protection scheme. The fallacy concerns the direction in which a property identifying garden residents may be used to classify a new place.

Which one of the following arguments contains the same flaw?

- **(A)** All paintings in the restoration exhibit are oil paintings. This canvas is an oil painting, so it must be in the restoration exhibit.
- **(B)** All canvases in the exhibit are oils. This canvas is in the exhibit, so it is an oil.
- **(C)** No artworks in the exhibit are photographs. This work is a photograph, so it is not in the exhibit.
- **(D)** Some oils are in the exhibit, and some drawings are in the exhibit, so some oils are drawings.
- **(E)** If a painting is in the exhibit, it is an oil. This work is not an oil, so it is not in the exhibit.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The library rooftop is classified as a protected garden from the presence of a swallow.
2. **Support.** Protected -> swallow; swallow -> protected is an invalid converse.
3. **Prephrase.** Find another attempt to infer membership in a category from a property shared by its members.
4. **Why (A) is right.** The oils/restoration argument repeats exhibit -> oil, oil -> exhibit.
5. **Why the others fail.**
   - **(B)** Valid application of a universal conditional.
   - **(C)** Valid contrapositive of an exclusion rule.
   - **(D)** Different fallacy: existential groups are wrongly assumed to overlap.
   - **(E)** Valid modus tollens rather than affirming the consequent.

**Check:** Both affirm the consequent of a one-way rule.
::::
:::

:::problem[Question III.23]
A museum’s loan ledger indicates that every sculpture sent abroad in September had been inspected by a conservator. Some inspected sculptures were not sent abroad, but every inspected sculpture made of limestone had a humidity report attached. Three limestone sculptures were sent abroad in September. The ledger also notes that a bronze sculpture was withheld because of damage, but it says nothing about whether every withheld sculpture was damaged. The question is what the loan and inspection rules entail for the limestone sculptures.

Which one of the following must be true?

- **(A)** Every sculpture with a humidity report was sent abroad in September.
- **(B)** No bronze sculptures were sent abroad in September.
- **(C)** At least three sculptures sent abroad in September had humidity reports attached.
- **(D)** All inspected sculptures were sent abroad in September.
- **(E)** Only limestone sculptures underwent conservation inspections.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** At least three abroad limestone sculptures had humidity reports.
2. **Support.** Three abroad limestone -> inspected because all abroad -> inspected; inspected limestone -> report.
3. **Prephrase.** Chain the two rules for each of the three specified sculptures.
4. **Why (C) is right.** Each of the three limestone loans had inspection and therefore a report, giving the minimum count.
5. **Why the others fail.**
   - **(A)** Converse trap: the humidity-report rule does not require a loan.
   - **(B)** Overgeneralization: one bronze work was withheld, not all bronze works.
   - **(D)** Direct contradiction: some inspected sculptures were not loaned.
   - **(E)** Wrong category: the rule permits inspected objects of other materials.

**Check:** Three limestone abroad -> three inspected limestone -> three reports.
::::
:::

:::problem[Question III.24]
A food bank plans to replace some of the grain it distributes with iron-fortified grain. Its director predicts that the change will reduce iron deficiency among the people the bank serves. The fortified grain contains more usable iron per serving, and the bank will provide the same total number of grain servings each month. Recipients may trade foods with neighbors or leave part of their allotment unused. The director’s prediction concerns recipients’ nutritional status, not the chemical composition of food remaining in the warehouse.

Which one of the following is an assumption required by the director’s reasoning?

- **(A)** All recipients will consume every grain serving the bank distributes.
- **(B)** Fortified grain will completely eliminate iron deficiency in the community.
- **(C)** The food bank will also increase its distribution of fresh vegetables.
- **(D)** Every recipient has the same initial level of iron deficiency.
- **(E)** At least some recipients will actually consume additional usable iron as a result of the substitution.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Changing grain distribution will reduce recipients’ iron deficiency.
2. **Support.** Servings are fortified, but recipients may not eat or retain the grains.
3. **Prephrase.** Some new iron must reach recipients as a result of the distribution.
4. **Why (E) is right.** Negate: nobody consumes additional usable iron from the substitution. The proposed pathway to improved iron status then disappears.
5. **Why the others fail.**
   - **(A)** Too strong: some consumption of additional iron can support a reduction without perfect uptake.
   - **(B)** Exaggeration: the predicted outcome is reduction, not elimination.
   - **(C)** Additional intervention is not part of the stated iron-substitution mechanism.
   - **(D)** Uniform baseline is unnecessary for a benefit among some recipients.

**Check:** Extra iron in stored or traded food alone cannot improve recipients’ iron status.
::::
:::

:::problem[Question III.25]
An educational psychologist believes a tablet-based attention game improves students’ reading comprehension. Students who chose to play it for several weeks earned higher scores on a later comprehension test than students who declined. The psychologist notes that both groups received the same reading lessons and took the test on the same day. However, the researchers never measured how participants performed before choosing whether to use the game, and the psychologist treats the score gap as a training effect.

The answer to which one of the following questions would be most useful in evaluating the psychologist’s conclusion?

- **(A)** Did the test booklet use the same font size for all students?
- **(B)** Did students who played the game spend more total hours reading recreational books?
- **(C)** Would a game with different graphics be more popular?
- **(D)** Were students who chose the game already stronger readers before the training period?
- **(E)** Did students enjoy their reading lessons more than their mathematics lessons?

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The game caused stronger reading comprehension.
2. **Support.** Self-selected users scored better, but pre-intervention ability is unknown.
3. **Prephrase.** Ask whether the users were already stronger readers before choosing the game.
4. **Why (D) is right.** An initial advantage offers a ready alternative cause of later higher scores; comparable baselines would lend support to treatment effectiveness.
5. **Why the others fail.**
   - **(A)** Administration consistency is already compatible with both self-selection and a true effect.
   - **(B)** An alternative educational exposure would matter if established, but it does not directly test whether the observed performance gap preceded training.
   - **(C)** Hypothetical design preference does not assess whether the existing game improved reading.
   - **(E)** Relative enjoyment of other lessons does not isolate the score gap’s cause.

**Check:** Yes versus no to preexisting ability directly changes the inference.
::::
:::

## 31.4 Scoring and review

Count one point for every correct answer. Your **raw score is out of 77**: 25 Section I questions, 27 Section II questions, and 25 Section III questions. This independently written test is **not equated**, so its raw score cannot be reliably converted to an official 120–180 LSAT score. Use section-by-section mistakes and blind-review flags to guide study.

:::answer[Answer]

**Section I answer key**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | (E) | Main conclusion | 4 |
| I.2 | (C) | Strengthen | 8 |
| I.3 | (A) | Flaw | 9 |
| I.4 | (B) | Must be true / inference | 10 |
| I.5 | (A) | Necessary assumption | 7 |
| I.6 | (D) | Paradox / resolve | 13 |
| I.7 | (C) | Weaken | 8 |
| I.8 | (B) | Principle | 13 |
| I.9 | (C) | Flaw | 9 |
| I.10 | (E) | Strengthen | 8 |
| I.11 | (A) | Role of a statement | 11 |
| I.12 | (A) | Necessary assumption | 7 |
| I.13 | (B) | Method of reasoning | 11 |
| I.14 | (E) | Weaken | 8 |
| I.15 | (C) | Parallel reasoning | 12 |
| I.16 | (D) | Flaw | 9 |
| I.17 | (B) | Sufficient assumption | 7 |
| I.18 | (E) | Most strongly supported | 10 |
| I.19 | (C) | Strengthen | 8 |
| I.20 | (E) | Point at issue | 11 |
| I.21 | (B) | Parallel flaw | 12 |
| I.22 | (D) | Necessary assumption | 7 |
| I.23 | (D) | Weaken | 8 |
| I.24 | (A) | Flaw | 9 |
| I.25 | (D) | Evaluate | 8 |

**Section II answer key**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | (C) | RC Main point | 18 |
| II.2 | (B) | RC Detail | 18 |
| II.3 | (A) | RC Function / purpose of a part | 18 |
| II.4 | (B) | RC Inference | 18 |
| II.5 | (E) | RC Author’s attitude / tone | 18 |
| II.6 | (A) | RC Application / analogy | 18 |
| II.7 | (A) | RC Inference | 18 |
| II.8 | (E) | RC Main point | 18 |
| II.9 | (D) | RC Detail | 18 |
| II.10 | (C) | RC Function / purpose of a part | 18 |
| II.11 | (B) | RC Inference | 18 |
| II.12 | (D) | RC Application / analogy | 18 |
| II.13 | (D) | RC Author’s attitude / tone | 18 |
| II.14 | (C) | RC Structure / organization | 18 |
| II.15 | (E) | RC Main point | 18 |
| II.16 | (D) | RC Detail | 18 |
| II.17 | (D) | RC Inference | 18 |
| II.18 | (C) | RC Function / purpose of a part | 18 |
| II.19 | (E) | RC Application / analogy | 18 |
| II.20 | (C) | RC Author’s attitude / tone | 18 |
| II.21 | (A) | Comparative reading: relationship | 17 |
| II.22 | (A) | Comparative reading: agreement | 17 |
| II.23 | (E) | Comparative reading: author response | 17 |
| II.24 | (B) | RC Detail | 18 |
| II.25 | (B) | RC Inference | 18 |
| II.26 | (A) | Comparative reading: application | 17 |
| II.27 | (E) | Comparative reading: organization | 17 |

**Section III answer key**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | (E) | Must be true / inference | 10 |
| III.2 | (C) | Flaw | 9 |
| III.3 | (E) | Strengthen | 8 |
| III.4 | (D) | Paradox / resolve | 13 |
| III.5 | (E) | Necessary assumption | 7 |
| III.6 | (B) | Method of reasoning | 11 |
| III.7 | (A) | Weaken | 8 |
| III.8 | (A) | Principle | 13 |
| III.9 | (C) | Role of a statement | 11 |
| III.10 | (B) | Sufficient assumption | 7 |
| III.11 | (E) | Flaw | 9 |
| III.12 | (D) | Most strongly supported | 10 |
| III.13 | (D) | Strengthen | 8 |
| III.14 | (A) | Necessary assumption | 7 |
| III.15 | (C) | Parallel reasoning | 12 |
| III.16 | (B) | Paradox / resolve | 13 |
| III.17 | (B) | Main conclusion | 4 |
| III.18 | (C) | Weaken | 8 |
| III.19 | (A) | Flaw | 9 |
| III.20 | (D) | Point at issue | 11 |
| III.21 | (B) | Sufficient assumption | 7 |
| III.22 | (A) | Parallel flaw | 12 |
| III.23 | (C) | Must be true / inference | 10 |
| III.24 | (E) | Necessary assumption | 7 |
| III.25 | (D) | Evaluate | 8 |

:::

**Review by question family**

| Question family | Review chapter |
| --- | --- |
| Main conclusion and argument anatomy | 4 |
| Necessary and sufficient assumptions | 7 (and conditional logic: 5) |
| Strengthen, weaken, evaluate | 8 |
| Flaw identification | 9 (flaw catalog: 6) |
| Must be true, most strongly supported | 10 |
| Method, role, point at issue | 11 |
| Parallel reasoning and parallel flaw | 12 |
| Paradox and principle | 13 |
| RC main point, detail, inference, tone, function, structure, application | 15 and 18 |
| Comparative reading: agreement, disagreement, author response | 17 |

After checking answers, revisit every flagged question you got right by chance. Explain why the correct answer is compelled and why **each** attractive alternative fails. Log the specific trap and the chapter to review (Chapters 22–23).
