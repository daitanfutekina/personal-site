---
title: "Inference / Must Be True"
source: "lsat_ch10_inference.html"
---

Part II · Chapter 10

# Inference / Must Be True

The question type where the credited-response principle rules absolutely: the answer isn't the most reasonable conclusion — it's the one the text *guarantees*. Here you stop evaluating arguments and start extracting exactly what the facts force.

**Est. study time:** 60–75 min — **Sections:** 4 — **Practice:** 22+ items

## Overview

Inference questions flip the usual task. Most LR questions hand you an *argument* (premises aiming at a conclusion) and ask you to judge it. Inference questions hand you a set of *facts* — usually with no conclusion at all — and ask which answer **must be true** given those facts, or is **most strongly supported** by them. You're not criticizing reasoning; you're finding what the statements guarantee. This is the purest test of Chapter 1's credited-response principle: the answer is provable from the text, and everything else — however plausible — is wrong.

You'll learn the crucial difference between "must be true" and "most supported," the mechanical techniques for *combining* statements (especially the conditional chaining from Chapter 5), and how to resist the single biggest trap: answers that are true in the real world but not guaranteed by the passage.

:::callout-tip
Prerequisites

Chapter 1 (credited response, outside-knowledge trap), Chapter 4 (defense test), and Chapter 5 (conditional chaining, contrapositives, quantifiers) — which are the engine of the harder inference questions.
:::

## 10.1 · "Must be true" vs. "most strongly supported"

:::callout-intuition
Intuition first

These two stems look similar but set different bars. **Must be true** demands an ironclad guarantee: the answer has to follow with 100% certainty from the facts — no gap allowed. **Most strongly supported** relaxes to "the facts make this very likely / point clearly to this," accepting a tiny reasonable step. Knowing which bar you're clearing tells you how strict to be, and it changes which answers survive.
:::

:::definition
**Definition 10.1 — The two inference bars.** *Must be true* (a.k.a. "which one can be properly inferred," "must also be true"): the answer is **guaranteed** by the statements — if the facts are true, the answer cannot be false. *Most strongly supported* (a.k.a. "most supported," "best supported"): the answer is the one the facts make most **likely**, permitting a small, well-grounded inference. Both forbid outside information; they differ only in how airtight the link must be.
:::

:::callout-key
The governing question for both

Always ask: "**Does the passage guarantee (or, for 'supported,' strongly point to) this — using only what's on the page?**" For "must be true," if you can imagine *any* scenario where the facts hold but the answer is false, eliminate it. For "most supported," you can accept the answer that the evidence most clearly favors, but you still can't import outside facts. The credited-response principle governs both.
:::

:::example
Worked Example 10.1 — the certainty bar

standard

"Every book on the top shelf is a first edition. No first edition in this collection is for sale. The dictionary is on the top shelf."

**Stem.** Which one must be true?

- **(A)** The dictionary is not for sale.
- **(B)** Every first edition is on the top shelf.
- **(C)** Some books not on the top shelf are for sale.
- **(D)** The dictionary is rare.
- **(E)** The dictionary is the most valuable book in the collection.

Answer: (A).

**How we get there.** Chain the conditionals (Chapter 5): `top shelf → first edition`; `first edition → not for sale`. So `top shelf → not for sale`. The dictionary is on the top shelf, so by modus ponens it's **not for sale** — guaranteed. Test the traps: (E) "most valuable" and (D) "rare" import outside assumptions — first editions aren't necessarily valuable or rare per the text. (B) is the *converse* (top-shelf→first edition doesn't give first edition→top shelf). (C) isn't guaranteed — we know nothing about books off the shelf. Only (A) must be true. **Teaching point:** "must be true" answers usually come straight from chaining the given statements — no embellishment.
:::

:::callout-pitfall
Watch out for these mistakes

- **Applying the "supported" bar to a "must be true" question.** On "must be true," a merely-likely answer isn't good enough — demand a guarantee.
- **Adding plausible detail.** "Valuable," "rare," "important" sneak in outside knowledge. If the word isn't earned by the text, it's out.
- **Accepting the converse.** Chaining runs one direction; reversing an arrow is the classic inference trap (Chapter 5).
:::

### Practice — 10.1

:::problem[Q1]{difficulty="easy"}
What's the difference in the bar between "must be true" and "most strongly supported"?

::::solution[Solution]
"Must be true" requires a **guarantee** (the answer can't be false if the facts hold); "most supported" requires only that the facts make the answer **most likely**, allowing a small reasonable step. Neither permits outside information.
::::
:::

:::problem[Q2]{difficulty="standard"}
"All the pastries sold today were baked this morning. Nothing baked this morning contains preservatives." Which must be true?

::::solution[Solution]
**None of the pastries sold today contain preservatives.** Chain: `sold today → baked this morning → no preservatives`. Guaranteed by modus ponens. (Don't infer anything about pastries *not* sold today.)
::::
:::

:::problem[Q3]{difficulty="standard"}
On a "must be true" question, you like an answer that's "probably true" given the facts. Keep or cut?

::::solution[Solution]
**Cut.** "Probably" fails the certainty bar. If any scenario lets the facts hold while the answer is false, it's not a "must be true." (On a "most supported" stem, "probably" might be acceptable — but not here.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is an answer that's the "main point" or "best conclusion" of a set of facts often *wrong* on a must-be-true question?

::::solution[Solution]
Because "the best conclusion" typically requires an inferential *leap* beyond what the facts strictly guarantee — the kind of leap that's an *assumption*. Must-be-true rewards the tightly guaranteed statement, which is often modest and unexciting, not the sweeping "point" a persuasive writer would draw. Certainty beats significance.
::::
:::

## 10.2 · Combining the facts

:::callout-intuition
Intuition first

The credited inference is almost never sitting in a single sentence — it emerges when you *combine* two or more statements. The test gives you puzzle pieces; the answer is what they force when snapped together. Your job is to look for statements that *share a term* and link them: conditionals chain, quantifiers overlap, and a general rule applied to a specific case yields a new fact.
:::

:::definition
**Definition 10.2 — Combination techniques.** The main ways facts combine into a guaranteed inference: **(a) conditional chaining** — link arrows sharing a term (Chapter 5); **(b) contrapositive** — read a conditional backward from a negated term; **(c) quantifier overlap** — an "all" plus a "some/most" sharing the "all" term yields a "some" conclusion; **(d) rule + case** — apply a general statement to a specific instance (modus ponens).
:::

:::example
Worked Example 10.2 — chaining + contrapositive

challenge

"Anyone admitted to the honor society has a GPA above 3.7. Students on academic probation have a GPA below 2.5. Miguel is on academic probation."

**Stem.** Which one must be true?

- **(A)** Miguel has applied to the honor society.
- **(B)** Miguel is not a member of the honor society.
- **(C)** Everyone with a GPA above 3.7 is in the honor society.
- **(D)** Miguel will improve his GPA.
- **(E)** Some honor-society members are on probation.

Answer: (B).

**How we get there.** Diagram: `honor society → GPA > 3.7`; `probation → GPA < 2.5`. Miguel is on probation, so his GPA is below 2.5 — which means it's *not* above 3.7. By the contrapositive of the first rule (`not (GPA > 3.7) → not honor society`), Miguel is **not in the honor society**. That's (B). Traps: (C) is the converse; (A), (D) import outside facts (applying, improving); (E) contradicts the chain (probation → low GPA → not in society). **Teaching point:** the answer came from combining two rules through a shared quantity (GPA) and a contrapositive — never from one sentence alone.
:::

:::example
Worked Example 10.3 — quantifier overlap

standard

"All of the interns attended the orientation. Most of the interns were assigned to the marketing team."

**Stem.** Which one must be true?

Answer: Some people who attended the orientation were assigned to the marketing team.

**How we get there.** "Most interns → marketing" means more than half the interns are on marketing; "all interns → attended orientation" means every intern attended. So those marketing interns both attended orientation *and* are on marketing — giving "**some** orientation-attendees are on marketing." This is the valid *all + most* overlap from Chapter 5 (the "all" term, interns, bridges the two). You could *not* conclude "most attendees are on marketing" (attendees might include many non-interns) — only the "some" claim is guaranteed. **Teaching point:** when you see "all X…" and "most X…," look for the "some" conclusion linking the two predicates.
:::

:::callout-tip
A search strategy

Scan the statements for a **shared term** — the same category or condition appearing in two facts. That shared term is almost always the hinge the inference turns on. Diagram conditionals as arrows; note quantifiers; then ask what the shared term forces. The correct answer typically lives at that junction.
:::

:::callout-pitfall
Watch out for these mistakes

- **Stopping at one statement.** The answer usually requires combining two. If a choice restates a single given fact, it may be true but is rarely the intended (or hardest-to-see) inference — though on must-be-true it can still be correct if guaranteed.
- **Over-combining into an unsupported leap.** Combine only what the shared terms license; don't add a bridge the text doesn't provide.
- **Forgetting the contrapositive.** Many inferences hide in the backward reading of a conditional — negate and reverse.
:::

### Practice — 10.2

:::problem[Q1]{difficulty="standard"}
"All licensed guides know first aid. No one who knows first aid panics in emergencies." What must be true about licensed guides?

::::solution[Solution]
**No licensed guide panics in emergencies.** Chain: `licensed guide → knows first aid → does not panic`. Guaranteed.
::::
:::

:::problem[Q2]{difficulty="standard"}
"Every applicant who was hired had a referral. Dana did not have a referral." What follows?

::::solution[Solution]
**Dana was not hired.** Contrapositive of `hired → referral` is `no referral → not hired`. Dana had no referral, so not hired.
::::
:::

:::problem[Q3]{difficulty="standard"}
"All of the vans are electric. Most of the vans are wheelchair-accessible." What must be true?

::::solution[Solution]
**Some electric vehicles (here, vans) are wheelchair-accessible** — more precisely, some wheelchair-accessible vehicles are electric. The accessible vans are electric (all vans are), so the two predicates overlap. (Can't say "most electric vehicles are accessible" — there may be other electric vehicles.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
"No reptiles are warm-blooded. All mammals are warm-blooded. The Gila monster is a reptile." What can you conclude about the Gila monster and mammals?

::::solution[Solution]
**The Gila monster is not a mammal.** It's a reptile → not warm-blooded (first rule). Mammals → warm-blooded, so by contrapositive not warm-blooded → not a mammal. Chain: reptile → not warm-blooded → not a mammal. Guaranteed.
::::
:::

## 10.3 · Why "true in the real world" answers fail

:::callout-intuition
Intuition first

This is the single most important habit for inference questions, and it's the credited-response principle at full strength (Chapter 1). Inference answer sets are stuffed with statements that are *true* — factually correct about the real world — but not *guaranteed by the passage*. Your knowledge screams "yes, that's right!" and you pick it. Wrong. The only currency here is textual support. An answer must be forced by the words on the page, not by what you happen to know.
:::

:::callout-key
The two-part filter for every inference answer

An answer must pass *both*: (1) **Is it supported by the passage?** (can you point to the words that force it?) and (2) **Is it too strong for what the passage gives?** (does it add certainty, scope, or detail the text doesn't earn?). A real-world-true answer typically fails part (1): it's true, but nothing in the passage establishes it. An over-reaching answer fails part (2): part of it is supported, but a word like "always," "most," or "cannot" overshoots.
:::

:::example
Worked Example 10.4 — true, but not supported

standard

"The city's new subway line has reduced average commute times downtown. Ridership on parallel bus routes has fallen since the line opened."

**Stem.** Which one is most strongly supported by the passage?

- **(A)** Public transit reduces traffic congestion.
- **(B)** Subways are a more efficient form of transit than buses.
- **(C)** Some commuters who previously took parallel buses now use the subway.
- **(D)** The city should eliminate the parallel bus routes.
- **(E)** The subway line was expensive to build.

Answer: (C).

**How we get there.** The passage gives two facts: commute times fell, and parallel-bus ridership fell after the subway opened. (C) is a modest, well-supported explanation: the falling bus ridership alongside a new parallel subway suggests some riders switched — the passage points clearly to it. Now the traps, all of which are *plausibly true in the real world*: (B) "subways more efficient than buses" — a general claim the passage never establishes (outside knowledge). (A) "public transit reduces congestion" — true in general, unmentioned here. (E) "expensive to build" — almost certainly true in reality, but not stated. (D) is a recommendation the facts don't support. Every trap is real-world-reasonable; only (C) is grounded in the passage. **Teaching point:** feel suspicion, not comfort, when an answer is something you already "know" — that's the tell of the outside-knowledge trap.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking the answer your knowledge endorses.** Truth ≠ support. If the passage doesn't force it, it's wrong — no matter how correct it is.
- **Rewarding sophistication.** The impressive general principle is usually the trap; the modest passage-hugging answer usually wins.
- **Missing an overshoot word.** "Some commuters switched" (supported) vs. "most commuters switched" (unsupported) — one word can flip a right answer to wrong.
- **Choosing a recommendation.** Inference passages give facts; "the city should…" answers add a value judgment the facts don't establish.
:::

### Practice — 10.3

:::problem[Q1]{difficulty="standard"}
A passage reports a study finding that a region's honeybee population declined as pesticide use rose. An answer says "pesticides are harmful to the environment." Supported?

::::solution[Solution]
**Not supported** as stated — it's a broad, real-world-true generalization the passage doesn't establish (the passage reports one correlation in one region). Outside-knowledge trap. A supported answer would stay close to the specific finding.
::::
:::

:::problem[Q2]{difficulty="standard"}
Two answers: (i) "some residents oppose the plan"; (ii) "most residents oppose the plan." The passage says "a number of residents spoke against the plan at the meeting." Which is supported?

::::solution[Solution]
**(i).** "A number spoke against" supports "some oppose," but not "most" — the speakers could be a small, vocal minority. The overshoot word "most" fails part (2) of the filter.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is a "should"/recommendation answer usually wrong on an inference question about a factual passage?

::::solution[Solution]
Because a recommendation adds a **value judgment** (what ought to be done) that pure facts don't guarantee. Inference answers must be forced by the stated facts; "should" claims require extra normative premises the passage doesn't provide.
::::
:::

:::problem[Q4]{difficulty="challenge"}
State the two-part filter and apply it to reject an answer that reads "electric cars are better for the planet" following a passage about a city's EV incentive raising EV sales.

::::solution[Solution]
Filter: (1) supported by the passage? (2) too strong for what's given? The answer fails **(1)**: the passage establishes that incentives raised EV *sales*, not any claim about EVs being "better for the planet" — that's an unstated, real-world generalization. It also arguably fails (2) as a sweeping value claim. Reject as an outside-knowledge trap; a supported answer would say something like "the incentive influenced some buyers' choices."
::::
:::

## 10.4 · Drill set

Twelve inference questions. Check the stem's bar (must-be-true vs. supported), combine the facts, and defend every answer from the text. Difficulty rises through the set.

:::problem[1]{difficulty="easy"}
"All the coins in the jar are silver. Every silver coin in the jar predates 1965." Must be true?

- **(A)** Some coins in the jar are gold.
- **(B)** All coins predating 1965 are silver.
- **(C)** No silver coin outside the jar predates 1965.
- **(D)** All the coins in the jar predate 1965.
- **(E)** The jar contains valuable coins.

::::solution[Solution]
**(D).** Chain: `in jar → silver → predates 1965`. (E) imports value; (A) contradicts; (B) is the converse.
::::
:::

:::problem[2]{difficulty="standard"}
"No one who has read the report supports the merger. The CFO supports the merger." Must be true?

- **(A)** The report opposes the merger.
- **(B)** The merger will fail.
- **(C)** Anyone who has not read the report supports the merger.
- **(D)** Everyone who read the report is an executive.
- **(E)** The CFO has not read the report.

::::solution[Solution]
**(E).** `read report → not support`; contrapositive `support → not read`. CFO supports, so hasn't read. (A),(B),(D) unsupported.
::::
:::

:::problem[3]{difficulty="standard"}
"Most of the museum's paintings are modern. All of its modern paintings are insured." Must be true?

- **(A)** Most of the museum's paintings are insured.
- **(B)** All insured paintings are modern.
- **(C)** Every painting in the museum is insured.
- **(D)** Some ancient paintings are insured.
- **(E)** The museum is well funded.

::::solution[Solution]
**(A).** Most paintings are modern; all modern ones are insured → most paintings are insured (most + all bridges validly). (B) is the converse; (D),(E) unsupported.
::::
:::

:::problem[4]{difficulty="standard"}
"The recipe requires either butter or oil. This batch was made without oil." Must be true?

- **(A)** The recipe never uses both.
- **(B)** This batch was made with butter.
- **(C)** Any batch made with butter was made without oil.
- **(D)** This batch tastes better.
- **(E)** Butter is healthier than oil.

::::solution[Solution]
**(B).** "Either butter or oil" + "no oil" forces butter (disjunctive syllogism). (D),(E) outside knowledge; (A) not stated ("either/or" allows both).
::::
:::

:::problem[5]{difficulty="standard"}
"Every student who studied abroad speaks a second language. Some students who speak a second language are on the debate team." Must be true?

- **(A)** All debate-team members studied abroad.
- **(B)** No debate-team member studied abroad.
- **(C)** Some debate-team members speak a second language.
- **(D)** Some students who studied abroad are on the debate team.
- **(E)** Every student who speaks a second language studied abroad.

::::solution[Solution]
**(C).** "Some second-language speakers are on debate" is symmetric → some debate members speak a second language. (D) is a two-"some"/chain error — studied-abroad speakers and debate speakers needn't overlap. (A) is unsupported/converse.
::::
:::

:::problem[6]{difficulty="standard"}
"Sales of e-books rose last year while sales of printed books fell. Total book sales were flat." Most strongly supported?

- **(A)** Readers prefer e-books.
- **(B)** More e-books than printed books were sold last year.
- **(C)** Printed books will disappear.
- **(D)** The rise in e-book sales roughly offset the decline in printed-book sales.
- **(E)** E-books are cheaper than printed books.

::::solution[Solution]
**(D).** Flat total with one up and one down implies the changes roughly cancelled. (E),(A),(C) are outside knowledge or overshoot.
::::
:::

:::problem[7]{difficulty="challenge"}
"All members of the finance committee are shareholders. No shareholder may audit the company's books. Lena audits the company's books." Must be true?

- **(A)** Lena owns no shares in any company.
- **(B)** No member of the finance committee audits any company's books.
- **(C)** All auditors are non-shareholders' employees.
- **(D)** Some shareholders audit other companies.
- **(E)** Lena is not on the finance committee.

::::solution[Solution]
**(E).** `finance committee → shareholder → may not audit`. Lena audits (so she "may" audit / does), hence she's not a shareholder, hence not on the committee (contrapositive chain). (A) overshoots ("any company"); (C),(D) unsupported.
::::
:::

:::problem[8]{difficulty="challenge"}
"Whenever the factory runs overtime, defect rates rise. Last month defect rates did not rise." Must be true?

- **(A)** The factory did not run overtime last month.
- **(B)** Whenever the factory does not run overtime, defect rates do not rise.
- **(C)** The factory produced fewer units last month.
- **(D)** Overtime always causes defects elsewhere too.
- **(E)** Defect rates will stay low.

::::solution[Solution]
**(A).** `overtime → defects rise`; contrapositive `defects not rise → no overtime`. Defects didn't rise → no overtime. (C),(D),(E) unsupported.
::::
:::

:::problem[9]{difficulty="challenge"}
"Some of the grant recipients are first-time applicants. All first-time applicants attended the workshop. No one who attended the workshop missed the deadline." Must be true?

- **(A)** Some first-time applicants are not grant recipients.
- **(B)** Some grant recipients did not miss the deadline.
- **(C)** All grant recipients attended the workshop.
- **(D)** Everyone who met the deadline is a first-time applicant.
- **(E)** Most grant recipients are first-time applicants.

::::solution[Solution]
**(B).** Some recipients are first-time applicants → they attended the workshop → they didn't miss the deadline. So some recipients met the deadline. (C) overshoots ("all"); (D) is a converse; (E) "most" is unsupported ("some").
::::
:::

:::problem[10]{difficulty="challenge"}
"Whenever one of the store's products sells out, the store restocks it. The blue mugs have never been restocked." Most strongly supported?

- **(A)** Every product the store has restocked had sold out.
- **(B)** The blue mugs are overpriced.
- **(C)** The blue mugs have never sold out.
- **(D)** The blue mugs are unpopular.
- **(E)** The store dislikes blue mugs.

::::solution[Solution]
**(C).** `sells out → restocked`. The mugs were never restocked, so by the contrapositive they never sold out — `not restocked → not sold out`. Note how much the wording of the first sentence matters: "restocks a product *only when* it sells out" would point the arrow the other way, `restocked → sold out`, and then never having been restocked would license nothing at all. (B),(D),(E) import prices, popularity and motives the passage never mentions.
::::
:::

:::problem[11]{difficulty="challenge"}
A passage states: "Since the tariff took effect, imports of steel fell and domestic steel production rose." An answer reads "the tariff caused domestic production to rise." Is this a safe inference? Why or why not?

::::solution[Solution]
**Not safe** on a strict must-be-true/supported basis. The passage gives a *correlation in time* (after the tariff, imports fell and production rose), not a guaranteed causal link — other factors could explain the production rise. A defensible answer would stay descriptive ("domestic production rose after the tariff took effect"), not assert causation. This is the causal-flaw awareness from Ch 6 applied to inference: don't upgrade a correlation to a cause the text doesn't force.
::::
:::

:::problem[12]{difficulty="challenge"}
In one or two sentences, explain why inference questions are the purest application of the credited-response principle.

::::solution[Solution]
Because there's no argument to evaluate — only facts and the demand for what they *guarantee* (or most support). The answer must be provable strictly from the text, and the answer sets are engineered with real-world-true distractors precisely to punish reasoning from outside knowledge. Success depends entirely on defending the answer from the words on the page — exactly the credited-response principle.
::::
:::

## Chapter summary

:::summary
#### Inference questions, distilled

- **You extract, not evaluate.** Facts in, guaranteed (or best-supported) conclusion out — no argument to critique.
- **Know the bar.** "Must be true" = guaranteed; "most supported" = most likely. Both forbid outside info.
- **Combine to find the answer.** Chain conditionals, use contrapositives, overlap quantifiers (all + most/some), apply rule to case.
- **Two-part filter:** (1) is it supported by the text? (2) is it too strong for what's given? Real-world-true answers fail (1); overshoot words fail (2).
- **Suspicion, not comfort,** when an answer is something you already "know." That's the outside-knowledge trap.
:::

LSAT Mastery — Chapter 10. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
