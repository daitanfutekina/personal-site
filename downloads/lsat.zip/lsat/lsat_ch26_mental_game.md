---
title: "Plateaus & the Mental Game"
source: "lsat_ch26_mental_game.html"
---

Part V · Chapter 26

# Plateaus & the Mental Game

Long prep tests your psychology as much as your reasoning. This chapter covers the three mental challenges that derail scores: the score plateau, burnout, and test-day anxiety — and how to work through each.

**Est. study time:** 40–50 min — **Sections:** 4 — **Practice:** 14+ items

## Overview

Everything so far has been about *what* to study and *how*. But a months-long prep is also a psychological project, and three mental obstacles derail more scores than any content gap: the **plateau** (your score stalls and you don't know why), **burnout** (motivation and focus collapse from overwork), and **test anxiety** (nerves that undercut your trained ability on the day it counts). None of these is a character flaw; they're normal features of hard, high-stakes preparation — and each has practical remedies. This chapter equips you to recognize and work through all three so your psychology supports your score instead of sabotaging it.

:::callout-tip
Prerequisites

Chapter 22 (blind review — the diagnostic tool for breaking plateaus), Chapter 25 (the weekly rhythm and rest day that prevent burnout), and Chapter 24 (the taper). This chapter draws on all of them.
:::

:::callout-key
A note before we start

These challenges are common and manageable, and this chapter offers concrete, healthy strategies. That said, the LSAT is one test in a long life; if prep is seriously affecting your wellbeing, mood, or health, that matters more than any score, and it's worth talking to someone you trust or a professional. Taking care of yourself is not separate from performing well — it's the foundation of it.
:::

## 26.1 · Diagnosing a score plateau

:::callout-intuition
Intuition first

A plateau — weeks of practice tests stuck at the same score — is discouraging, but it's a *diagnostic puzzle*, not a verdict on your ability. Plateaus almost always mean one of two things: you've stopped doing the thing that was driving improvement (usually thorough review), or your practice has drifted toward your strengths and away from the specific weaknesses that are actually capping your score. The fix isn't "try harder" or "do more questions" — it's to *diagnose why the score is stuck* and change the input.
:::

:::definition
**Definition 26.1 — Plateau diagnosis.** A structured look at *why* a stalled score isn't moving, using your error log and blind-review data. Common causes: (a) **shallow review** — doing volume without the deep five-step review; (b) **practicing strengths** — drilling comfortable types instead of weak ones; (c) **an unaddressed bottleneck** — a single persistent weakness (a type or a timing/endurance issue) that caps the whole score; (d) **a pure timing wall** — solid untimed ability that isn't converting under time.
:::

### How to break a plateau

1. **Audit your review.** Are you actually doing the deep, five-step blind review (Chapter 22), or just checking answers? Shallow review is the most common plateau cause — fix it first.
2. **Re-sort your error log** (Chapter 23). Is one type or trap flavor still dominating your misses? That bottleneck is your target — attack it specifically.
3. **Check the timing/knowledge split.** If most misses are timing gaps, the plateau is a *speed* wall — shift to pacing/endurance (Chapters 14, 19, 24), not more content.
4. **Change the input.** A plateau means your current routine has stopped producing gains; do something *different* — a new drill focus, harder targeted sets, or a pacing overhaul — rather than more of what plateaued you.

:::example
Worked Example 26.1 — a stuck score

standard

**Scenario.** Four PTs in a row at 161. Your log shows misses spread thinly across types, but on review you realize you've been "reviewing" by reading explanations for 30 seconds each, and you mostly drill LR (your strength) because RC is unpleasant.

**Question.** Diagnose the plateau and prescribe.

Diagnosis: shallow review + practicing your strength (LR) while avoiding your weakness (RC). Prescription: switch to deep five-step blind review, and reallocate drilling toward RC, using the error log to target specific RC question types.

**How we get there.** Two classic plateau causes are both present. First, 30-second answer-reading isn't review (Chapter 22) — without the deep review, you're doing reps with no feedback, so the score can't move. Second, avoidance: drilling LR (comfortable) while neglecting RC (unpleasant) means the section capping your score never improves. The fix changes both inputs: real blind review to restart learning, and a deliberate shift of practice toward the avoided weakness. "Do more questions the same way" would keep you at 161. **Teaching point:** plateaus are broken by *changing what you do*, guided by honest diagnosis — not by grinding harder at the same routine.
:::

:::callout-pitfall
Watch out for these mistakes

- **"Just do more questions."** If your routine plateaued you, more of it won't help. Change the input.
- **Practicing strengths for comfort.** Improvement comes from attacking weaknesses; drilling what you're already good at feels productive but moves nothing.
- **Treating a timing plateau as a knowledge plateau.** Re-studying concepts you already know (untimed) won't break a speed wall — shift to pacing.
- **Catastrophizing.** A plateau is a puzzle to solve, not proof of your ceiling. People break through them regularly.
:::

### Practice — 26.1

:::problem[Q1]{difficulty="easy"}
What's the most common cause of a score plateau?

::::solution[Solution]
**Shallow review** — doing volume without the deep five-step blind review, so reps produce no feedback and no learning. Fix the review first.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why does "just do more questions" usually fail to break a plateau?

::::solution[Solution]
Because the plateau means your **current routine has stopped producing gains**; repeating it (more questions the same way) yields more of the same. Breaking through requires *changing the input* — deeper review, targeting weaknesses, or a pacing overhaul.
::::
:::

:::problem[Q3]{difficulty="standard"}
Your plateau's misses are mostly timing gaps. What kind of wall is it, and what changes?

::::solution[Solution]
A **speed wall** — you have the ability but can't apply it in time. Shift to **pacing, section management, and endurance** (Chapters 14, 19, 24), not more content study.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why do people unconsciously drill their strengths during a plateau, and why is it counterproductive?

::::solution[Solution]
Because practicing what you're good at is **comfortable and feels successful** (you get questions right), while attacking weaknesses is unpleasant and error-filled — so avoidance is natural. It's counterproductive because your score is capped by your **weaknesses**, not your strengths; improving an already-strong area yields almost nothing, while the untouched weak area keeps limiting the score. Breaking the plateau requires deliberately steering practice toward the uncomfortable weak spots the error log identifies.
::::
:::

## 26.2 · Avoiding burnout

:::callout-intuition
Intuition first

Burnout is what happens when you treat a months-long skill-building project like a series of all-out sprints: motivation drains, focus frays, practice scores may even *drop*, and studying starts to feel like dread. It's not weakness — it's the predictable result of overload without recovery. And it's counterproductive on its own terms: a burned-out brain learns and performs worse, so pushing through it costs you the very score you're grinding for. The remedy is sustainable pacing, real rest, and treating recovery as part of training.
:::

:::definition
**Definition 26.2 — Burnout.** A state of mental exhaustion and reduced motivation from prolonged overwork without adequate recovery, marked by declining focus, falling or stagnant scores despite effort, irritability, and aversion to studying. Because cognitive performance depends on a rested brain, burnout directly undermines both learning and test performance.
:::

### Preventing and recovering from burnout

- **Build recovery into the plan.** The protected rest day and sustainable weekly hours (Chapter 25) aren't slack — they're what keep you learning. Consistent moderate effort beats relentless grinding.
- **Watch for early signs:** dreading study, declining practice scores despite effort, trouble focusing, resentment of the test. These mean *reduce load*, not push harder.
- **Take a real break when needed.** A few days fully off can restore more performance than a few days of exhausted grinding — the brain consolidates and recovers. A short break rarely sets you back; burnout does.
- **Protect sleep, movement, and life outside the LSAT.** These aren't distractions from prep; they're the physiological base that makes prep work. Sacrificing all of them to study more is a bad trade.
- **Keep perspective.** The LSAT is important but it is one test; framing it as your entire worth raises the pressure that fuels burnout.

:::callout-warning
Grinding through burnout is a losing trade

The instinct when scores stall is to study *more* — but if the cause is burnout, more study deepens the hole: a fatigued brain retains less, reviews worse, and performs lower, so additional hours yield negative returns. The counterintuitive but correct move is often to **rest first, then resume**. Recovery isn't quitting; it's how you get back the capacity to improve.
:::

### Practice — 26.2

:::problem[Q1]{difficulty="easy"}
Name three early signs of burnout.

::::solution[Solution]
Any three: **dreading study, declining/stagnant scores despite effort, trouble focusing, irritability/resentment of the test**. These signal *reduce load*, not push harder.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why is "study more" the wrong response to burnout-caused stagnation?

::::solution[Solution]
Because burnout is **fatigue-driven**, and a tired brain learns and performs worse — so more hours yield *negative* returns, deepening the problem. The right move is recovery first (rest), then resume.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why are sleep, movement, and non-LSAT life described as part of prep rather than distractions from it?

::::solution[Solution]
Because they're the **physiological and psychological base** that makes learning and focus possible; sacrificing them to study more degrades the very cognitive capacity prep depends on. They support the score rather than competing with it.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A student is burned out three weeks before test day and considers pushing hard to "make up for it." Advise them.

::::solution[Solution]
Pushing hard while burned out will likely **lower** their performance, not raise it — fatigue impairs learning and test execution. Better: **take a short genuine break to recover**, then resume with a lighter, sustainable rhythm and a focus on consolidation over new cramming; and honestly weigh whether the current date is realistic (Chapter 2 allows rescheduling). Arriving rested at a slightly lower prep volume beats arriving depleted after a frantic final push. Their wellbeing also matters in its own right, beyond the score.
::::
:::

## 26.3 · Test anxiety & performing under pressure

:::callout-intuition
Intuition first

You can train for months and then lose points on test day to *nerves* — a racing mind, a blanked-out first passage, a spiral after one hard section. Some arousal is normal and even helpful; the problem is when anxiety tips into interference. The good news: performing under pressure is itself a *trainable* skill, and a few concrete techniques — realistic practice, a reset routine, and reframing — reliably reduce the gap between your practice ability and your test-day performance.
:::

:::definition
**Definition 26.3 — Test anxiety management.** A set of practices that reduce performance-impairing nerves: **simulation** (making test conditions familiar so they're less threatening), a **reset routine** (a quick way to recover focus mid-test), **reframing** (interpreting arousal as readiness rather than danger), and **process focus** (attending to the next question, not the outcome or the score).
:::

### Concrete techniques

- **Simulate relentlessly.** The single best anti-anxiety tool is making test day *familiar*: full timed PTs in the official interface, same time of day, real conditions (Chapter 24). Familiarity converts the unknown (scary) into the known (routine).
- **Have a reset routine.** When you feel a spiral — mind racing, re-reading the same sentence — pause for a slow breath, drop your shoulders, and return to the *process* (find the conclusion, run the method). A few seconds of deliberate reset beats minutes of flailing.
- **Reframe the arousal.** A pounding heart and heightened alertness are your body *preparing to perform*, not a sign of impending failure. Telling yourself "I'm ready/energized" rather than "I'm panicking" measurably helps — same physical state, better interpretation.
- **Focus on process, not outcome.** Thinking about your score mid-test steals attention from the question in front of you. Narrow to the next question; the score takes care of itself when you attend to process.
- **Let go of a bad section.** If one section felt awful, it's done — and it may even have been the experimental one (Chapter 2). Spiraling about it costs you the *next* section too. Reset and keep scoring.

:::callout-key
The most freeing fact for test day

By test morning, **the work is done — you cannot cram in new ability overnight.** Your only job on the day is *execution*: stay calm, keep moving, guess-and-flag when stuck (Chapter 14), and let your training carry you. Reframing test day as "execute what I've built" rather than "prove myself" removes much of the pressure. Nerves are normal; the people who do best are simply the ones who keep answering.
:::

:::callout-pitfall
Watch out for these mistakes

- **Only practicing in comfortable conditions.** Cozy, untimed practice doesn't inoculate you against test-day pressure. Simulate the real thing.
- **Dwelling on a hard section.** Rumination mid-test bleeds into later sections. Reset and move forward.
- **Interpreting normal arousal as disaster.** A racing heart is readiness; don't read it as proof you'll fail.
- **Focusing on the score mid-test.** Outcome-thinking steals attention from the question. Stay on process.
:::

### Practice — 26.3

:::problem[Q1]{difficulty="easy"}
What's the single most effective way to make test day less anxiety-provoking?

::::solution[Solution]
**Realistic simulation** — full timed PTs in the official interface under real conditions. Familiarity turns the scary unknown into a known routine.
::::
:::

:::problem[Q2]{difficulty="standard"}
You feel a panic spiral start during a section. What's the reset routine?

::::solution[Solution]
**Pause for a slow breath, relax your shoulders, and return to the process** (find the conclusion, run the method / go back to the lines). A few seconds of deliberate reset beats minutes of flailing.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is "focus on process, not outcome" useful mid-test?

::::solution[Solution]
Because **thinking about your score steals attention from the question in front of you**, hurting performance. Narrowing to the next question keeps your full cognitive resources on the task; the outcome follows from good process.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Explain the "reframe the arousal" technique and why it works despite the physical state being unchanged.

::::solution[Solution]
It means interpreting the physical signs of stress (racing heart, alertness) as **your body preparing to perform** ("I'm energized/ready") rather than as danger ("I'm panicking"). It works because the same physiological arousal can either *aid* performance (heightened focus, energy) or *impair* it (interpreted as threat, triggering avoidance and rumination) — and the *interpretation*, not the arousal itself, largely determines which. Relabeling the sensation as readiness channels the same energy toward the task instead of toward fear.
::::
:::

## 26.4 · Scenario drills

Six mental-game scenarios. Decide the right response, then check.

:::problem[1]{difficulty="easy"}
Five PTs stuck at 159 and you're doing "more questions." What's the likely issue?

::::solution[Solution]
A **plateau from an unchanged routine** — probably shallow review and/or drilling strengths. Diagnose with the error log; change the input (deep review, target weaknesses or timing).
::::
:::

:::problem[2]{difficulty="standard"}
You dread opening your prep materials and your scores have dipped despite steady effort. Diagnosis?

::::solution[Solution]
**Burnout.** Reduce load, take a genuine short break, protect sleep — pushing harder would lower performance further. Recovery restores learning capacity.
::::
:::

:::problem[3]{difficulty="standard"}
Mid-test, one RC section felt like a disaster and you're rattled. What now?

::::solution[Solution]
**Let it go and reset** — it's done (and might have been experimental). Reset routine (breath, process focus) and give full effort to the next section; spiraling would cost you more points.
::::
:::

:::problem[4]{difficulty="standard"}
The night before, you feel the urge to cram five more hours. Wise?

::::solution[Solution]
**No** — you're in the taper (Chapters 24–25). Cramming can't raise ability now and risks exhausting you; do light review at most and prioritize sleep. The work is done; protect your test-day freshness.
::::
:::

:::problem[5]{difficulty="challenge"}
Your practice average is 165 but you've bombed two real attempts around 158, seemingly from nerves. What should you build into your remaining prep?

::::solution[Solution]
**Pressure inoculation**: take more *realistic, high-stakes* simulations (full timed PTs in the official interface, unfamiliar conditions, maybe timed in front of a modest "audience" or at a testing-like location) to make the real setting routine; drill and rehearse a **reset routine and reframing** so they're automatic under stress; and practice **process-focus** mid-test. The gap is execution under pressure, not ability, so the fix is training the pressure itself — plus, if nerves are severe, considering support/techniques for test anxiety. Their true ability (165) suggests the points are recoverable by closing the performance gap.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, explain why the mental game deserves a chapter alongside the reasoning content.

::::solution[Solution]
Because a months-long, high-stakes prep is a psychological project as much as an intellectual one: plateaus, burnout, and anxiety each cost real points and derail otherwise well-prepared test-takers, and none is fixed by more content. Managing them — diagnosing plateaus, pacing to avoid burnout, and training performance under pressure — is what lets your trained reasoning ability actually show up as your score on the day it counts.
::::
:::

## Chapter summary

:::summary
#### The mental game, distilled

- **Plateaus are puzzles, not ceilings.** Usually shallow review or practicing strengths; diagnose with the error log, then *change the input* — deeper review, target weaknesses, or fix timing.
- **Burnout is overload without recovery.** Watch the early signs; rest is part of training, and grinding through it lowers performance.
- **Protect sleep, movement, and life** — they're the base that makes prep work, not distractions from it.
- **Beat anxiety with simulation, a reset routine, reframing arousal as readiness, and process focus.** Let go of a bad section.
- **By test day the work is done** — your job is execution. Keep answering.
- If prep seriously affects your wellbeing, that matters more than any score — seek support.
:::

LSAT Mastery — Chapter 26. Independent study material, not affiliated with LSAC. This chapter offers general study strategies, not medical or psychological advice; if anxiety or burnout seriously affects your wellbeing, consider speaking with a trusted person or professional.
