---
title: "Reading for Structure"
source: "lsat_ch15_reading_structure.html"
---

Part III · Chapter 15

# Reading for Structure

The core Reading Comprehension skill: absorbing a dense, unfamiliar passage by mapping its *architecture* — not memorizing its content. Get this right and the questions become lookups.

**Est. study time:** 65–80 min — **Sections:** 5 — **Practice:** 18+ items

## Overview

Reading Comprehension is worth about a quarter of your score, and it punishes the way most people naturally read. Faced with 450 words on Byzantine tax law or the biochemistry of coral, the instinct is to *study* the content — to try to understand and remember it all. That's slow, exhausting, and unnecessary. Skilled LSAT readers do something different: they read for **structure**. They track what each paragraph *does*, where the author's opinion sits versus other people's, and how the pieces connect — building a mental *map* they can navigate back to when a question asks for a detail. This chapter teaches that skill, which underlies every RC question type in the chapters that follow.

:::callout-tip
Prerequisites

Chapter 1 (the credited-response principle, the outside-knowledge trap — both dominate RC) and Chapter 4 (finding conclusions and tracking whose view a sentence expresses — the same skill, now on longer text). Everything here extends those ideas to passages.
:::

## 15.1 · Active reading & the paragraph map

:::callout-intuition
Intuition first

Imagine being dropped in an unfamiliar city. You could memorize every shop window (exhausting, useless) — or you could note the layout: "main square here, river to the north, museum district east." When a question asks "where's the museum?", the map-reader answers instantly; the window-memorizer is lost. RC works the same way. Don't absorb every fact; note what each *paragraph* does, and you'll know exactly where to look when a question needs a detail. You read the passage *once*, for structure; you re-read tiny bits *on demand*, for specifics.
:::

:::definition
**Definition 15.1 — The paragraph map.** A compressed, one-phrase-per-paragraph summary of what each paragraph *does* (its function), not everything it says. Example map: "P1: old theory. P2: problem with it. P3: author's alternative. P4: evidence for the alternative." The map captures the passage's architecture so you can answer structure/function questions from it directly and locate details fast.
:::

### What "active" reading means

As you read each paragraph, silently answer three questions:

- **What is this paragraph doing?** (introducing a theory? raising an objection? giving an example? concluding?) — this is the map entry.
- **Whose idea is this?** (the author's, or a view being reported?) — flag opinions (15.3).
- **How does it connect to the last paragraph?** (supporting it? contrasting? qualifying?) — watch the pivot words (15.2).

:::callout-key
Read for the skeleton, look up the flesh

Your one read-through captures the **skeleton**: main point, structure, and where opinions live. You deliberately do *not* try to retain every detail, date, or name — those you'll **look up** when a specific question sends you back (and RC rewards going back; memory-based answers get trapped, Chapter 1). This split — structure now, details on demand — is what makes RC fast enough to finish.
:::

:::example
Worked Example 15.1 — mapping a paragraph

standard

"Historians long attributed the city's decline to the collapse of its silver trade. Recent excavations, however, reveal thriving markets and new construction well after the trade ended — evidence that the economy had diversified. The traditional single-cause explanation now appears too simple."

**Task.** Give the one-phrase map entry for this paragraph and note the author's stance.

Map entry: "challenges the old single-cause (silver-trade) explanation with new archaeological evidence." Author's stance: skeptical of the traditional explanation; favors economic diversification.

**How we get there.** Don't record "silver trade," "excavations," "markets," "construction" as facts to memorize. Ask what the paragraph *does*: it states an old view ("historians long attributed…"), then rebuts it ("however… evidence that…"), and delivers a judgment ("too simple"). That's the function — a rebuttal of a traditional explanation. Note the pivot "however" (15.2) marking the turn to the author's view, and that "historians long attributed" flags an *opposing* view the author counters (15.3). **Teaching point:** the map entry is about role, not content — and it already tells you the author's position.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reading to memorize.** Trying to retain every detail is slow and unnecessary — and still leaves you re-reading for questions. Map the structure; look up specifics later.
- **Skimming so lightly you miss the structure.** The opposite error: you must actively note each paragraph's *function* and the author's stance, or you have no map at all.
- **Getting bogged down in a hard sentence.** If one technical sentence is dense, grasp its *role* ("some evidence for the claim") and move on; you can return if a question needs it.
:::

### Practice — 15.1

:::problem[Q1]{difficulty="easy"}
What does a paragraph-map entry capture — what the paragraph *says* or what it *does*?

::::solution[Solution]
What it **does** (its function/role) — e.g., "raises an objection," "gives an example" — not a summary of every fact it contains. The map is architecture, not content.
::::
:::

:::problem[Q2]{difficulty="standard"}
Map this paragraph in one phrase: "While solar power is often praised as pollution-free, manufacturing solar panels generates significant toxic waste, a cost frequently ignored in glowing assessments."

::::solution[Solution]
"**Complicates the pollution-free image of solar power by noting manufacturing waste.**" It states a common praise, then qualifies/undercuts it ("While… however implied") — a qualification the author endorses.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why do you deliberately *not* memorize details on the first read?

::::solution[Solution]
Because it's slow and unnecessary — you can **look up specifics on demand** when a question sends you back (and going back beats memory, which gets trapped). The first read is for the skeleton (structure, main point, opinions); details are retrieved as needed.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A technical paragraph is too dense to fully understand on one read. What should you extract before moving on?

::::solution[Solution]
Its **function** — what role it plays in the passage (e.g., "detailed evidence supporting the author's hypothesis," "a rival mechanism the author will reject") — plus its connection to neighboring paragraphs. You don't need the technical content mastered; you need to know *why it's there* so you can navigate back if a question requires the detail.
::::
:::

## 15.2 · Pivot words & where opinions live

:::callout-intuition
Intuition first

A handful of small words are the signposts of an LSAT passage: *but, however, although, yet, nevertheless, in contrast, surprisingly.* These **pivot words** mark a turn — where the author changes direction, disagrees with someone, or reveals what they really think. The most important sentences in a passage almost always sit right after a pivot. Train your eye to snap to them, because that's where the answers to the hardest questions hide.
:::

:::definition
**Definition 15.2 — Pivot words.** Transition words signaling a shift in direction or emphasis. *Contrast pivots* (but, however, yet, although, nevertheless, on the other hand, in contrast, whereas) mark disagreement or a turn — often to the author's own view. *Emphasis/attitude cues* (surprisingly, importantly, crucially, unfortunately, admittedly) reveal the author's stance. Marking these as you read locates the passage's key claims and the author's opinion.
:::

:::callout-key
The pivot-to-opinion rule

A contrast pivot frequently separates a view the author is *reporting* from the view the author *holds*. Pattern: "Many believe X. **However**, [author's real view]." The sentence after the "however" is usually the author's position — and usually the main point or close to it. When you hit a pivot, slow down and ask "what's turning, and which side is the author on?"
:::

:::example
Worked Example 15.2 — the pivot reveals the thesis

standard

"Conventional wisdom holds that great scientific breakthroughs are the work of lone geniuses. **Yet** a close look at the history of major discoveries reveals dense networks of collaborators, correspondents, and predecessors without whom the 'genius' could not have succeeded."

**Task.** Identify the author's view and how the pivot signals it.

Author's view: great breakthroughs are collaborative, not the work of lone geniuses. The pivot "Yet" separates the reported conventional wisdom from the author's contrary thesis.

**How we get there.** The first sentence is flagged as *reported* opinion ("conventional wisdom holds") — not necessarily the author's. The pivot "**Yet**" turns to what the author actually argues: discoveries depend on networks. So the author's thesis lives *after* the pivot. If a question asked for the main point or the author's attitude toward "lone genius," you'd answer from this post-pivot sentence — and you'd know the author is *skeptical* of the lone-genius view. **Teaching point:** pivots are where opinions and main points cluster; mark them.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reading past pivots at full speed.** The sentence after "but/however/yet" is often the most important in the paragraph — slow down there, don't skim.
- **Assuming the pre-pivot claim is the author's.** Frequently it's the view being *rebutted*. Check which side of the pivot the author endorses.
- **Ignoring attitude cues.** "Unfortunately," "admittedly," "surprisingly" quietly tell you how the author feels — useful for Attitude/Tone questions (Chapter 18).
:::

### Practice — 15.2

:::problem[Q1]{difficulty="easy"}
Name four contrast pivot words.

::::solution[Solution]
Any of: **but, however, yet, although, nevertheless, whereas, in contrast, on the other hand**. They mark a turn in direction, often to the author's own view.
::::
:::

:::problem[Q2]{difficulty="standard"}
"Economists have generally assumed people act in their own self-interest. However, ..." What's likely coming after "However," and whose view is it?

::::solution[Solution]
The **author's contrary view** — likely evidence or an argument that people *don't* always act in pure self-interest. The pre-pivot claim is the reported assumption; the post-pivot sentence carries the author's position.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why should you slow down right after a pivot word?

::::solution[Solution]
Because the sentence after a contrast pivot is often the **author's actual thesis** (or a key turn in the argument) — the highest-value sentence in the paragraph. Skimming past it risks missing the main point and the author's stance.
::::
:::

:::problem[Q4]{difficulty="challenge"}
How can the word "admittedly" both reveal the author's stance and signal structure?

::::solution[Solution]
"Admittedly" flags a **concession** — the author grants a point to the other side (revealing awareness of/stance toward an opposing consideration), and it structurally signals that a **rebuttal or "but…" is coming** (the author will argue the conceded point is outweighed). So it marks both attitude (fair-minded concession) and the concession→rebuttal structure, much like the Role-question concessions in Chapter 11.
::::
:::

## 15.3 · Tracking whose view a sentence expresses

:::callout-intuition
Intuition first

LSAT passages are crowded with *opinions* — the author's, plus those of critics, traditional scholars, one camp, a rival camp. A huge share of RC traps exploit one confusion: mistaking a view the author is *describing* (or *rebutting*) for the author's *own* view. If you don't track whose opinion each sentence carries, you'll answer "the author believes X" with a sentence where the author was actually reporting someone else's belief in order to disagree with it. Keeping a running tag of "who thinks this" is the single most protective RC habit.
:::

:::definition
**Definition 15.3 — Attribution.** The task of identifying *whose* position a given sentence expresses: the author's own view, or a view the author attributes to others (and may support, report neutrally, or oppose). Attribution cues: "some argue," "critics contend," "traditionally," "it is widely held," "proponents claim," "according to X." Sentences with these cues are usually *not* the author's voice.
:::

:::callout-tip
Tag opinions as you read

Mentally (or with the highlighter) label each opinion with a source: *[others], [author], [camp A], [camp B]*. When the passage presents multiple positions, know exactly who holds what — especially in comparative passages (Chapter 17) and on "the author would agree" or "author's attitude" questions (Chapter 18). The author's own view is often introduced by a pivot ("but," "however") after the reported views.
:::

:::example
Worked Example 15.3 — three voices in one paragraph

challenge

"Proponents of the new curriculum argue that it raises test scores. Critics counter that any gains come at the expense of creativity. In fact, the limited data available support neither sweeping claim; the curriculum's effects appear modest and mixed."

**Task.** Attribute each of the three claims and state the author's own view.

Claim 1 (raises scores) = proponents. Claim 2 (kills creativity) = critics. Claim 3 (effects modest and mixed) = the author. The author's view: both strong claims are unsupported; the real effect is modest.

**How we get there.** Tag by cue: "Proponents… argue" → [camp A], not the author. "Critics counter" → [camp B], not the author. "In fact, the limited data… support neither" → the author's own voice, stepping in to judge both. A trap question might ask "the author believes the curriculum raises test scores" and offer that as an answer — but that's the *proponents'* view, which the author actually doubts. Only by tagging voices do you avoid attributing camp A's claim to the author. **Teaching point:** in multi-opinion passages, the author frequently withholds their view until after presenting others' — often signaled by "in fact," "but," or "the truth is."
:::

:::callout-pitfall
Watch out for these mistakes

- **Attributing a reported view to the author.** "Some scholars claim X" is not "the author claims X" — often the author disagrees. This is the top RC trap.
- **Losing track in multi-camp passages.** When two or three positions appear, explicitly tag each; don't let them blur together.
- **Missing where the author enters.** Watch for "in fact," "but," "however," "the truth is" — these often introduce the author's own judgment after others' views.
:::

### Practice — 15.3

:::problem[Q1]{difficulty="easy"}
Does "many economists have assumed that markets are efficient" express the author's view?

::::solution[Solution]
**Not necessarily** — "many economists have assumed" attributes the view to *others*. It's a reported position the author may well go on to challenge. Don't assume it's the author's.
::::
:::

:::problem[Q2]{difficulty="standard"}
List three attribution cues that usually signal a view is *not* the author's.

::::solution[Solution]
E.g., "**some argue**," "**critics contend**," "**traditionally / it is widely held**" (also "proponents claim," "according to X"). These attribute the view to others.
::::
:::

:::problem[Q3]{difficulty="standard"}
In "Supporters say the dam will prevent floods. But it will also displace thousands of families," whose view is each sentence, and what's the author likely doing?

::::solution[Solution]
Sentence 1 = **supporters'** view (flood prevention). Sentence 2 (after "But") = the **author's** counter-consideration (displacement). The author is likely raising a drawback to complicate or oppose the supporters' case.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why are "the author would agree/disagree" questions especially dangerous without attribution tracking?

::::solution[Solution]
Because such questions offer answer choices drawn from *every* view in the passage — the author's *and* the reported/opposed ones. Without tagging which claims are the author's, you can easily select a view the author actually **rejected** or merely reported. Attribution is the only reliable way to separate the author's commitments from positions they described.
::::
:::

## 15.4 · Stating the main point in one sentence

:::callout-intuition
Intuition first

Before you touch the questions, you should be able to say the passage's **main point in a single sentence** — the one claim the whole passage exists to make. This isn't busywork: Main Point and Primary Purpose questions are answered directly from it, and it's your anchor for judging every other answer ("does this fit the passage's overall point?"). If you can't state it, you didn't read for structure — go back to your map.
:::

:::definition
**Definition 15.4 — The main point.** The single central claim the passage as a whole supports — the author's overall thesis. It must (1) reflect the *author's* view (not a reported one), (2) cover the *whole* passage (not one paragraph), and (3) match the author's *strength/attitude* (a hedged passage has a hedged main point). Build it from your paragraph map plus the author's stance.
:::

:::callout-key
How to construct it

Combine two things you already have: your **paragraph map** (the structure) and your **attribution tags** (the author's view). A reliable template: "*Although [the view the author opposes], [the author's thesis], because [the passage's main support].*" Then compress. The main point is usually near a pivot, often in the first or last paragraph — but state it in your own words rather than copying one sentence.
:::

:::example
Worked Example 15.4 — building the main point

standard

**Given this map:** P1: traditional view that language shapes thought entirely. P2: experiments showing people distinguish concepts their language lacks words for. P3: author argues language *influences* but doesn't *determine* thought. P4: implications for translation.

**Task.** State the main point in one sentence.

Main point: "Contrary to the strong traditional claim that language wholly determines thought, the author argues that language influences but does not fully determine it, as shown by experiments on non-lexicalized concepts."

**How we get there.** Use the template. The opposed view (P1): language *determines* thought. The author's thesis (P3): language *influences but doesn't determine*. The support (P2): experiments with concepts languages lack words for. Assemble: "Although the traditional view says language determines thought, the author argues it only influences thought, based on experimental evidence." Note the *strength*: the author's claim is *moderate* ("influences, doesn't determine"), so the main point must be moderate too — a Main Point answer that says "language has no effect on thought" or "language completely controls thought" would be wrong for overshooting in either direction. **Teaching point:** the main point is your map + attribution, stated at the author's actual strength.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking a paragraph's point as the whole passage's.** The main point must cover *all* paragraphs, not just one (a classic Main Point trap — an answer true of P2 only).
- **Stating an opposed view as the main point.** Make sure it's the *author's* thesis, not the position they rebut.
- **Getting the strength wrong.** A hedged passage ("suggests," "may," "influences") needs a hedged main point; don't inflate it to a sweeping claim (or vice versa).
:::

### Practice — 15.4

:::problem[Q1]{difficulty="easy"}
Three requirements a correct main-point statement must meet?

::::solution[Solution]
It must (1) be the **author's** view, (2) cover the **whole** passage, and (3) match the author's **strength/attitude** (hedged stays hedged).
::::
:::

:::problem[Q2]{difficulty="standard"}
Why is an answer that accurately summarizes only paragraph 2 usually wrong on a Main Point question?

::::solution[Solution]
Because the main point must cover the **entire** passage. A statement true of only one paragraph is too **narrow** — a common trap that's accurate but not the overall thesis.
::::
:::

:::problem[Q3]{difficulty="standard"}
A passage repeatedly uses "suggests," "may," and "appears to." What does that imply for its main point?

::::solution[Solution]
The main point should be **hedged/moderate**, matching that tentative language. An answer stating a strong, certain conclusion would overshoot the author's actual (cautious) claim.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Give the template for constructing a main point and explain why it works.

::::solution[Solution]
"**Although [opposed view], [author's thesis], because [main support].**" It works because it forces you to include all three essentials: it distinguishes the author's thesis from the view being rebutted (attribution), it ties the thesis to the passage's overall support (whole-passage coverage), and framing it as the author's argued position keeps the strength anchored to what the author actually claims.
::::
:::

## 15.5 · Full worked passage

Put it together: map the passage, tag the voices, mark pivots, and state the main point — then answer structure-focused questions from your map.

:::example
Passage — humanities / history of science

(1) For most of the twentieth century, historians of medicine told the story of nineteenth-century public health as a triumph of scientific discovery: once researchers identified the germs that caused disease, mortality fell. (2) This narrative is appealing in its simplicity, and it flatters the laboratory science that came to dominate modern medicine.

(3) Recent scholarship, however, complicates the picture. (4) Demographers have shown that death rates from several major infectious diseases began falling *decades before* the relevant germs were identified or effective treatments existed. (5) The decisive factors, these scholars argue, were unglamorous public works: clean water, sewage systems, better nutrition, and less crowded housing.

(6) Defenders of the traditional account respond that germ theory, even before it yielded cures, guided these very reforms — engineers built sewers *because* they came to understand contagion. (7) There is something to this: ideas and infrastructure surely interacted.

(8) Still, the timing is stubborn. (9) Much of the mortality decline preceded not just germ-based cures but germ theory itself. (10) The most defensible conclusion is that material improvements in living conditions, more than laboratory breakthroughs, drove the early decline — though the two were never wholly separate.

#### The structural map

- **P1:** the traditional "triumph of science" narrative — *[reported view]*, and note P2 flags its *appeal* (setting up a critique).
- **P2/P3:** pivot "**however**" (sentence 3) → recent scholarship *challenges* it: death rates fell *before* germs were identified; the real drivers were public works — *[camp: revisionists]*, which the author leans toward.
- **P3 (6–7):** the traditionalists' *rebuttal* (germ theory guided the reforms), and the author's partial *concession* ("There is something to this") — *[camp: defenders], then [author concedes]*.
- **P4:** pivot "**Still**" → the author's *own judgment*: living conditions drove the early decline more than lab science, "though the two were never wholly separate" (hedged).

**Voices:** traditional historians (P1), revisionist demographers (P2), defenders of tradition (P3), author (P4, and the concessions in 7 and 10). **Main point (one sentence, at the author's strength):** *"Although the traditional account credits scientific discovery, the mortality decline of the nineteenth century was driven more by material improvements in living conditions than by laboratory breakthroughs — though the two interacted."* Note the hedge ("more than," "though… never wholly separate") — the author is measured, not absolute.
:::

### Questions

:::problem[Q1]{difficulty="standard"}
The primary purpose of the passage is to…

- **(A)** defend the traditional narrative of public health as a scientific triumph.
- **(B)** show that demographers and historians never disagree.
- **(C)** prove that germ theory played no role in falling mortality.
- **(D)** argue that material living conditions, more than laboratory science, drove the early mortality decline, while acknowledging the two interacted.
- **(E)** describe the discovery of the germs responsible for major diseases.

::::solution[Solution]
**(D).** Matches the hedged main point covering the whole passage. (C) overshoots ("no role" — the author concedes interaction); (A) reverses the author's lean; (E) covers only background; (B) is false. Getting the *strength* right kills (C).
::::
:::

:::problem[Q2]{difficulty="standard"}
The author's attitude toward the traditional "triumph of science" narrative is best described as…

- **(A)** total dismissal as worthless.
- **(B)** indifference.
- **(C)** enthusiastic endorsement of every revisionist claim.
- **(D)** complete acceptance.
- **(E)** partial agreement but ultimate disagreement with its emphasis.

::::solution[Solution]
**(E).** The author concedes germ theory "guided the reforms" ("There is something to this") but concludes living conditions mattered *more* — partial agreement, ultimate disagreement with the emphasis. (A) is too extreme (the author allows interaction); (D) contradicts the "however/still" pivots.
::::
:::

:::problem[Q3]{difficulty="standard"}
The function of the third paragraph (sentences 6–7) is to…

- **(A)** present the traditionalists' rebuttal and grant it partial validity before the author's final judgment.
- **(B)** state the passage's main conclusion.
- **(C)** summarize the revisionist position without evaluating it.
- **(D)** provide statistical data on mortality.
- **(E)** introduce the revisionist demographers' evidence.

::::solution[Solution]
**(A).** P3 is the defenders' counter (germ theory guided reforms) plus the author's concession ("There is something to this"). The main conclusion is P4; the revisionist evidence is P2. Answer from the map.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Which claim would the author most likely agree with?

- **(A)** Scientific discovery was irrelevant to nineteenth-century mortality decline.
- **(B)** The early mortality decline had more to do with sewers and nutrition than with laboratory cures.
- **(C)** Improvements in sanitation had no measurable effect on mortality.
- **(D)** Germ theory was the sole cause of falling death rates.
- **(E)** Historians should ignore demographic evidence.

::::solution[Solution]
**(B).** Directly reflects the author's hedged thesis (material conditions > lab science, but interacting). (A) and (D) are the two *extremes* the author explicitly rejects ("never wholly separate"); (E) contradicts the author's reliance on demographers. The trap here is picking an extreme — attribution and strength-tracking prevent it.
::::
:::

:::problem[Q5]{difficulty="challenge"}
The phrase "the timing is stubborn" (sentence 8) most nearly serves to…

- **(A)** concede that the traditionalists are correct.
- **(B)** acknowledge that the revisionist dating has itself been disputed.
- **(C)** reassert the revisionist evidence (that decline preceded germ theory) as decisive against over-crediting science, transitioning to the author's conclusion.
- **(D)** introduce a new disease as an example.
- **(E)** question whether death rates can be measured.

::::solution[Solution]
**(C).** After the concession in P3, "Still, the timing is stubborn" pivots back to the revisionist point (decline came before germ theory) and sets up the author's final judgment in sentence 10. It's a structural hinge — recognizable from the map and the pivot "Still."
::::
:::

## Chapter summary

:::summary
#### Reading for structure, distilled

- **Map, don't memorize.** One phrase per paragraph capturing its *function*; look up details on demand.
- **Pivot words** (but, however, yet, still) mark turns — the author's thesis usually sits right after one.
- **Tag every opinion's owner.** Distinguish the author's view from reported/opposed views — the top RC trap exploits this.
- **State the main point in one sentence:** author's view, whole passage, correct strength. Build it from map + attribution.
- **Match the author's strength.** Hedged passages have hedged main points; beware extreme-worded answer traps.
:::

LSAT Mastery — Chapter 15. Independent study material, not affiliated with LSAC. Practice passage and questions are original, written to illustrate the skills; use official LSAC PrepTests for timed practice.
