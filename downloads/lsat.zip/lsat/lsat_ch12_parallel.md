---
title: "Parallel Reasoning & Parallel Flaw"
source: "lsat_ch12_parallel.html"
---

Part II · Chapter 12

# Parallel Reasoning & Parallel Flaw

Match the argument's logical *skeleton*, ignore its flesh. These questions look long and scary, but with the right abstraction they collapse into fast pattern-matching.

**Est. study time:** 55–70 min — **Sections:** 4 — **Practice:** 20+ items

## Overview

Parallel Reasoning questions ask you to find, among five answer choices, the argument whose *logical structure* matches the stimulus. Parallel Flaw questions are the same, but the shared structure is a specific *error*. The topics will differ wildly — the stimulus is about frogs, the right answer about tax law — because **topic is irrelevant; only the form matters.** These questions intimidate people because they're long (six arguments to read!), but with a disciplined method — abstract the skeleton, then match — they become some of the most learnable questions on the test.

:::callout-tip
Prerequisites

Chapter 5 (conditional forms and the four valid/invalid patterns), Chapter 4 (conclusion/premise), and Chapter 6 (the flaw catalog, for Parallel Flaw). Parallel questions are largely those chapters' structures used as matching targets.
:::

## 12.1 · Matching logical form, ignoring topic

:::callout-intuition
Intuition first

Think of each argument as a sentence with the nouns blanked out: "All A are B; this is an A; so this is a B." The right answer is the choice that fills a *different* set of nouns into the *same* blanks. The test deliberately changes the subject matter so you can't match on topic — you have to match on the shape. Your first move, always, is to strip the stimulus down to its skeleton.
:::

:::definition
**Definition 12.1 — Parallel reasoning.** A question asking which answer's argument has the same *logical structure* as the stimulus. Stems: "most similar in its reasoning," "most closely parallels the reasoning," "the pattern of reasoning is most similar to." A correct match preserves: the **logical form** (conditional chain, quantifier pattern, causal claim, etc.), the **certainty level** of the conclusion (must vs. probably vs. some), and the **validity** (a valid argument matches a valid one; a flawed one matches the same flaw).
:::

### The abstraction technique

1. **Abstract the stimulus** into a skeleton using letters or short labels: "All A→B; x is A; so x is B," or "Most A are B; most B are C; so (claims) most A are C."
2. **Note three features to match:** the *form* (arrows/quantifiers/causation), the *conclusion's strength* (all/most/some/probably), and whether it's *valid or flawed*.
3. **Abstract each answer** the same way and compare skeletons — not topics.

:::example
Worked Example 12.1 — match the skeleton

standard

"All of the cabins by the lake have fireplaces. The Hendersons' cabin does not have a fireplace. So the Hendersons' cabin is not by the lake."

**Stem.** Which one is most similar in its reasoning?

- **(A)** All licensed pilots have passed a medical exam. Mr. Ito has not passed a medical exam. So Mr. Ito is not a licensed pilot.
- **(B)** Every employee has an ID badge. Some employees work remotely. So some badge-holders work remotely.
- **(C)** Most marathoners train daily. Dev trains daily. So Dev is probably a marathoner.
- **(D)** If it rains, the game is canceled. The game was canceled. So it rained.
- **(E)** All the roses in the garden are red. This flower is red. So it is a rose from the garden.

Answer: (A).

**How we get there.** Abstract the stimulus: `All A → B` (lake cabin → fireplace); `x is not B` (no fireplace); `so x is not A` (not by lake). That's **modus tollens** — valid. Now (A): `All A → B` (pilot → passed exam); `Ito not B` (didn't pass); `so Ito not A` (not a pilot). Identical modus tollens. Match. Check others: (E) is affirming-the-consequent (invalid — wrong form); (B) is a quantifier-overlap argument (different form); (C) is a "most"-based probabilistic inference (different form and strength); (D) is affirming the consequent (invalid). Only (A) shares the exact valid modus tollens skeleton. **Teaching point:** reduce to letters and the topics (cabins vs. pilots) stop mattering entirely.
:::

:::callout-pitfall
Watch out for these mistakes

- **Matching on topic or tone.** An answer about the same subject as the stimulus is a deliberate trap. Match structure, not content.
- **Ignoring conclusion strength.** A stimulus that concludes "must" doesn't match an answer that concludes "probably" or "some," even if the form is otherwise similar.
- **Overlooking validity.** A valid stimulus must match a valid answer; if the stimulus is valid, eliminate any flawed answer immediately (and vice versa).
:::

### Practice — 12.1

:::problem[Q1]{difficulty="standard"}
Abstract this into a skeleton: "All chefs can cook. Sam can cook. So Sam is a chef."

::::solution[Solution]
`All A → B; x is B; so x is A` — **affirming the consequent** (invalid converse). A correct parallel would share this same invalid form with different nouns.
::::
:::

:::problem[Q2]{difficulty="standard"}
Three features you must match in a parallel-reasoning question?

::::solution[Solution]
The **logical form** (arrows/quantifiers/causation), the **conclusion's strength/certainty** (all/most/some/probably/must), and the **validity** (valid matches valid, flawed matches the same flaw). Topic is irrelevant.
::::
:::

:::problem[Q3]{difficulty="standard"}
A stimulus concludes "so it must be X." An answer concludes "so it is probably X," with otherwise identical structure. Match?

::::solution[Solution]
**No.** Conclusion strength differs — "must" (certainty) vs. "probably" (likelihood). Parallel answers must match the certainty level, so this is a mismatch even with the same form.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is abstracting to letters more reliable than reading the arguments "naturally"?

::::solution[Solution]
Because natural reading tempts you to match on **topic, tone, or plausibility** — all irrelevant. Reducing each argument to `A/B/C` arrows and quantifiers exposes the pure structure, so you compare the only thing that matters (form, strength, validity) and become immune to content-based traps.
::::
:::

## 12.2 · Parallel flaw — matching the specific error

:::callout-intuition
Intuition first

Parallel Flaw is Parallel Reasoning with a twist: the stimulus argument is *bad*, and you must find the answer that's bad **in the same specific way**. It's not enough for the answer to be flawed — it has to commit the *identical* flaw. So the method adds one step to Chapter 12.1: name the flaw (Chapter 6), then find the answer that commits *that* flaw, not just any flaw.
:::

:::definition
**Definition 12.2 — Parallel flaw.** A question asking which answer's argument contains *flawed reasoning most similar* to the stimulus's. Stems: "flawed reasoning most similar to," "commits which error also committed above," "most closely parallels the flawed reasoning." The correct answer must (1) be flawed, (2) commit the *same* flaw, and (3) match the form and conclusion strength.
:::

:::example
Worked Example 12.2 — match the flaw

challenge

"Everyone who wins the lottery is lucky. Elena is lucky. So Elena will win the lottery."

**Stem.** The flawed reasoning is most similar to which one?

- **(A)** All professional dancers are fit. Marcus is not fit. So Marcus is not a professional dancer.
- **(B)** Every bestselling author is disciplined. Nadia is disciplined. So Nadia is a bestselling author.
- **(C)** All the apples in the crate are ripe. This apple is from the crate. So it is ripe.
- **(D)** Some scientists are musicians. All musicians read notation. So some scientists read notation.
- **(E)** If a plant is a fern, it lacks flowers. This plant has flowers. So it is not a fern.

Answer: (B).

**How we get there.** Name the stimulus flaw: `All A → B; x is B; so x is A` — **affirming the consequent** (being lucky is necessary for winning, not sufficient; the argument treats it as sufficient). Now find the same flaw. (B): `All A → B` (bestselling → disciplined); `Nadia is B` (disciplined); `so Nadia is A` (bestselling) — identical affirming-the-consequent. Match. Others: (A) is valid modus tollens; (C) is valid modus ponens; (D) is a valid quantifier chain; (E) is valid modus tollens. Only (B) is flawed *and* flawed the same way. **Teaching point:** a huge shortcut — since four answers here are actually *valid*, and the stimulus is flawed, you can eliminate every valid answer instantly (see 12.3).
:::

:::callout-pitfall
Watch out for these mistakes

- **Settling for "also flawed."** The answer must commit the *same* flaw, not merely be a bad argument. A different flaw is a wrong answer.
- **Forgetting to name the flaw.** Without naming it (Chapter 6), you can't verify the match. Diagnose the specific error first.
- **Matching a valid answer to a flawed stimulus.** If the stimulus is flawed, the answer must be flawed too — eliminate valid answers on sight.
:::

### Practice — 12.2

:::problem[Q1]{difficulty="standard"}
Name the flaw and give its skeleton: "All geniuses are eccentric. Toby is eccentric. So Toby is a genius."

::::solution[Solution]
**Affirming the consequent.** Skeleton: `All A → B; x is B; so x is A`. A correct parallel-flaw answer shares this exact invalid pattern.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why isn't "the answer is also a flawed argument" sufficient to make it the correct parallel-flaw answer?

::::solution[Solution]
Because parallel-flaw requires the **same specific flaw**, not just any flaw. An argument flawed by, say, a sampling error doesn't match a stimulus flawed by affirming the consequent, even though both are "bad." Same error type is required.
::::
:::

:::problem[Q3]{difficulty="standard"}
Stimulus flaw: correlation→causation. Which answer parallels it — "Ice cream sales and drownings both rise in summer, so ice cream causes drowning" or "All cats are mammals, so this mammal is a cat"?

::::solution[Solution]
The **first** — it commits correlation→causation (both rise together → one causes the other, ignoring the common cause of summer heat). The second is affirming the consequent, a different flaw.
::::
:::

:::problem[Q4]{difficulty="challenge"}
In a parallel-flaw question, three of the five answers are valid arguments. What can you do immediately, and why is that a big time-saver?

::::solution[Solution]
**Eliminate all three valid answers at once** — since the stimulus is flawed, the answer must also be flawed. That leaves only two candidates to compare in detail, cutting the work dramatically. Validity screening is the fastest filter on these questions (see 12.3).
::::
:::

## 12.3 · Fast elimination tactics

:::callout-intuition
Intuition first

Parallel questions are long, so speed comes from *eliminating without fully diagramming every answer*. A few high-level features let you cross off two or three choices in seconds — before you do the careful skeleton comparison on what remains. Think of it as triage: cheap checks first, expensive matching last.
:::

:::definition
**The elimination checklist (apply in order).**

1. **Validity.** Is the stimulus valid or flawed? Eliminate every answer of the *opposite* kind. (Valid stimulus → drop all flawed answers; flawed stimulus → drop all valid answers.)
2. **Conclusion type.** Match the conclusion's *form and strength*: a recommendation ("should"), a prediction ("will"), a flat "is," a "must," a "probably," a "some/most." Eliminate answers whose conclusion type differs.
3. **Quantifier / logical operator.** Does the stimulus use "all," "some," "most," "none," a conditional, or a causal claim? Eliminate answers using a different operator.
4. **Number of terms & polarity.** Count the pieces and note negations. A two-step chain doesn't match a one-step inference; a conclusion with a negation ("is not") should match one with a negation.
5. **Full skeleton** only on the 1–2 survivors.
:::

:::example
Worked Example 12.3 — triage in action

challenge

"The mayor should not raise the sales tax. Doing so would burden low-income families, and no policy that burdens low-income families is justifiable."

**Stem.** Which is most similar in its reasoning?

- **(A)** If the tax rises, revenue will grow. Revenue grew, so the tax rose.
- **(B)** Most families oppose the tax, so it should not pass.
- **(C)** The company should not relocate. Relocating would hurt employee morale, and no move that hurts morale is worthwhile.
- **(D)** The mayor raised the tax last year, so she will raise it again.
- **(E)** Some tax increases are unpopular, so this one will be too.

Answer: (C).

**How we get there — using the checklist.** Stimulus features: *valid*; conclusion is a **recommendation** ("should not"); uses a **universal** premise ("no policy that…is justifiable"); structure: `doing X causes harm H; no policy causing H is acceptable; so shouldn't do X`. Triage: (D) is a prediction from a single past case (wrong conclusion type — prediction, not recommendation; also flawed). (E) concludes with a prediction/"some" (wrong type). (A) is affirming the consequent (flawed — but stimulus is valid, eliminate). (B) is a different structure (appeal to majority, "most"). That leaves (C): a *recommendation* ("should not relocate") built on a universal premise ("no move that hurts morale is worthwhile") — same valid skeleton. Confirmed. **Teaching point:** steps 1–2 (validity + conclusion type) killed three answers before any diagramming.
:::

:::callout-tip
Order of attack for the whole question type

(1) Read the stimulus and note validity + conclusion type. (2) Sweep the five conclusions *only* — eliminate mismatched conclusion types fast. (3) On survivors, check the operator and term count. (4) Diagram fully only if two remain. This "conclusions first" habit is the biggest time-saver on parallel questions, which are otherwise among the slowest on the section.
:::

:::callout-pitfall
Watch out for these mistakes

- **Diagramming all five answers from the start.** Wasteful. Triage on cheap features first; diagram only survivors.
- **Skipping the conclusion sweep.** Matching conclusion type alone often eliminates 2–3 answers in seconds.
- **Forgetting polarity.** A "not" in the conclusion or a negated term is a structural feature that must match.
:::

### Practice — 12.3

:::problem[Q1]{difficulty="standard"}
The stimulus argument is valid. An answer is clearly flawed (affirming the consequent). Keep or cut, and how quickly?

::::solution[Solution]
**Cut immediately** — step 1 of the checklist. A valid stimulus can't be paralleled by a flawed argument. No diagramming needed.
::::
:::

:::problem[Q2]{difficulty="standard"}
Stimulus conclusion is a recommendation ("we should X"). Which answers can you cut on conclusion type alone?

::::solution[Solution]
Any whose conclusion is **not a recommendation** — e.g., a prediction ("will happen"), a flat factual claim ("is a Y"), or a probability ("probably"). Matching the conclusion type is a fast early filter.
::::
:::

:::problem[Q3]{difficulty="standard"}
Put the elimination checklist steps in order.

::::solution[Solution]
(1) Validity, (2) conclusion type/strength, (3) quantifier/operator, (4) number of terms & polarity, (5) full skeleton on survivors only. Cheapest, highest-yield checks first.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does checking the conclusions of all five answers *before* analyzing their premises save the most time?

::::solution[Solution]
Because the conclusion is one short statement per answer, yet its **type and strength** (recommendation/prediction/must/some, positive/negative) must match the stimulus — so a quick conclusion sweep eliminates several answers without reading their premises at all. You then diagram premises only for the few whose conclusions survive, minimizing the expensive work.
::::
:::

## 12.4 · Drill set

Ten questions. Abstract the stimulus to a skeleton, note validity + conclusion type, then match. Difficulty rises.

:::problem[1]{difficulty="easy"}
"All squares are rectangles. This shape is a square. So it is a rectangle." *Most similar?*

- **(A)** All dogs are animals. Rex is an animal. So Rex is a dog.
- **(B)** Some dogs are brown. Rex is brown. So Rex is a dog.
- **(C)** If Rex is a dog, Rex is an animal. Rex is an animal. So Rex is a dog.
- **(D)** All dogs are animals. Rex is a dog. So Rex is an animal.
- **(E)** All dogs are animals. Rex is not an animal. So Rex is not a dog.

::::solution[Solution]
**(D).** Valid modus ponens: `All A→B; x is A; so x is B`. (A),(C) affirm the consequent; (B) is invalid.
::::
:::

:::problem[2]{difficulty="standard"}
"No amphibians have scales. This creature has scales. So it is not an amphibian." *Most similar?*

- **(A)** All stars shine. This shines. So it is a star.
- **(B)** Some planets have moons. Mars has moons. So Mars is a planet.
- **(C)** If it's a comet, it has a tail. It's a comet. So it has a tail.
- **(D)** No comets are planets. This object is not a planet. So it is a comet.
- **(E)** No planets are stars. The Sun is a star. So the Sun is not a planet.

::::solution[Solution]
**(E).** Valid modus tollens via a "no" statement: `No A are B; x is B; so x is not A`. (E) matches exactly. Others differ in form.
::::
:::

:::problem[3]{difficulty="standard"}
"Most novelists are introverts. Most introverts enjoy solitude. So most novelists enjoy solitude." *Most similar (flaw and all)?*

- **(A)** Most cyclists are fit. Most fit people sleep well. So most cyclists sleep well.
- **(B)** All cyclists are fit. All fit people sleep well. So all cyclists sleep well.
- **(C)** Some cyclists are fit. Some fit people sleep well. So some cyclists sleep well.
- **(D)** No cyclists are unfit. Every unfit person tires quickly. So no cyclist tires quickly.
- **(E)** No cyclists are unfit. This person is unfit. So not a cyclist.

::::solution[Solution]
**(A).** The stimulus is the invalid "most + most" chain (Ch 5). (A) reproduces it exactly. (B) is a valid all-chain; (C),(E) different forms.
::::
:::

:::problem[4]{difficulty="standard"}
"If the bill passes, taxes rise. Taxes rose. So the bill passed." *Most similar?*

- **(A)** It snowed, so school closed and buses stopped.
- **(B)** If it snows, school closes. School closed. So it snowed.
- **(C)** If it snows, school closes. It snowed. So school closed.
- **(D)** If it snows, school closes. It did not snow. So school did not close.
- **(E)** If it snows, school closes. School didn't close. So it didn't snow.

::::solution[Solution]
**(B).** Affirming the consequent: `A→B; B; so A`. (B) matches. (C) is valid modus ponens; (E) valid modus tollens.
::::
:::

:::problem[5]{difficulty="standard"}
"We should not adopt the plan. It raises costs, and no plan that raises costs is acceptable." *Most similar?*

- **(A)** Some applicants lack licenses, so this one might too.
- **(B)** If he's licensed, he's qualified. He's qualified. So he's licensed.
- **(C)** We should not hire him. He lacks a license, and no unlicensed applicant is acceptable.
- **(D)** He lacks a licence, so he must be unqualified for every job.
- **(E)** He was hired last year, so he'll be hired again.

::::solution[Solution]
**(C).** Valid recommendation on a universal premise: `X has feature F; no policy with F is acceptable; so shouldn't do X`. (C) mirrors it. Others differ in type/validity.
::::
:::

:::problem[6]{difficulty="challenge"}
"Sales rose after the mascot debuted, so the mascot boosted sales." *Flawed reasoning most similar?*

- **(A)** No good manager micromanages. She micromanages. So she's not a good manager.
- **(B)** Most winners practice daily. Ada practices daily. So Ada probably wins.
- **(C)** The mascot is popular, so the company that owns it is popular.
- **(D)** Crime fell after the new chief took office, so the chief reduced crime.
- **(E)** All effective ads are memorable. This ad is memorable. So it's effective.

::::solution[Solution]
**(D).** Correlation/causation (post hoc): effect followed cause, so cause produced effect. (D) is the same post hoc flaw. (E) is affirming the consequent (different flaw); (A) valid; (B) different.
::::
:::

:::problem[7]{difficulty="challenge"}
"Every member passed the exam. Some members are volunteers. So some volunteers passed the exam." *Most similar?*

- **(A)** Every intern got a laptop. Some laptop-holders are minors. So some interns are minors.
- **(B)** Most interns got laptops. Most laptop-holders are minors. So most interns are minors.
- **(C)** Every intern got a laptop. No minor got a laptop. So no intern is a minor.
- **(D)** If an intern works late, she gets overtime. She got overtime. So she worked late.
- **(E)** Every intern got a laptop. Some interns are minors. So some minors got a laptop.

::::solution[Solution]
**(E).** Valid all+some overlap on the "all" term: `All A→B; some A are C; so some C are B`. (E) matches exactly (interns all got laptops; some interns are minors; so some minors got laptops). (A) reverses the shared term; (B) most+most; (D) affirms consequent.
::::
:::

:::problem[8]{difficulty="challenge"}
"To be admitted, you must submit a portfolio. Kira submitted a portfolio. So Kira will be admitted." *Flawed reasoning most similar?*

- **(A)** All who board have tickets. Sam has no ticket. So Sam won't board.
- **(B)** Some passengers have tickets. Sam is a passenger. So Sam has a ticket.
- **(C)** To board, you need a ticket. Sam has a ticket. So Sam will board.
- **(D)** To board, you need a ticket. Sam didn't board. So Sam had no ticket.
- **(E)** Sam will board, because he is going to get on the plane.

::::solution[Solution]
**(C).** The flaw is treating a *necessary* condition as a *sufficient* one: submitting a portfolio is required for admission, not enough for it. (C) does the same with the ticket. (A) is a valid modus tollens — no ticket, so no boarding — and a valid argument can never parallel a flawed one. (B) slides from "some" to "all". (D) denies the antecedent: not boarding does not establish that Sam had no ticket, since he might have had one and stayed home. (E) is valid too.
::::
:::

:::problem[9]{difficulty="challenge"}
"Either the cause was fraud or it was negligence. It wasn't fraud. So it was negligence." *Most similar?*

- **(A)** Either the leak was in the roof or the pipes. It wasn't the roof. So it was the pipes.
- **(B)** If the leak were in the pipes, the water meter would spin. The meter is still. So the leak is not in the pipes.
- **(C)** The leak was in the roof, so it wasn't the pipes.
- **(D)** Most leaks are in pipes, so this one is too.
- **(E)** If it's the roof, we'll see water stains. We see stains. So it's the roof.

::::solution[Solution]
**(A).** Valid disjunctive syllogism: `A or B; not A; so B`. (A) matches exactly. (E) affirms the consequent; (D) is a "most" inference; (C) is unsupported.
::::
:::

:::problem[10]{difficulty="challenge"}
In one or two sentences, summarize the whole method for parallel questions.

::::solution[Solution]
**Abstract the stimulus to a letter-skeleton** (form, conclusion strength, validity), then **triage the answers** by validity and conclusion type to eliminate quickly, and finally **diagram only the survivors** to confirm an exact structural (and, for parallel flaw, same-flaw) match — ignoring topic entirely throughout.
::::
:::

## Chapter summary

:::summary
#### Parallel questions, distilled

- **Match form, not topic.** Abstract each argument to a letter-skeleton; the differing subjects are deliberate distraction.
- **Match three things:** logical form, conclusion strength/type, and validity (valid↔valid, flawed↔same flaw).
- **Parallel flaw needs the *same* flaw** — name it (Chapter 6), then find the matching error, not just any bad argument.
- **Triage to go fast:** validity → conclusion type → operator → term count → full skeleton on survivors only.
- **Conclusions first:** sweeping the five conclusions eliminates 2–3 answers before you read a single premise.
:::

LSAT Mastery — Chapter 12. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
