---
title: "Method, Role & Point at Issue"
source: "lsat_ch11_method_role.html"
---

Part II · Chapter 11

# Method, Role & Point at Issue

Three question types that reward pure structural reading. You don't judge whether the argument is good — you describe how it's built, what a given sentence does, or exactly where two speakers disagree.

**Est. study time:** 55–70 min — **Sections:** 4 — **Practice:** 20+ items

## Overview

This chapter groups three related types that all test one underlying ability: reading an argument for its *structure* rather than its truth. **Method** questions ask how the argument is built (abstractly). **Role** questions ask what job a specific sentence does within it. **Point at Issue** questions give you two speakers and ask exactly what they disagree about. None of them asks whether anyone is *right* — only how the pieces fit and relate. If you nailed conclusion-vs-premise in Chapter 4, you already have the core skill; here we sharpen it and add the two-speaker case.

:::callout-tip
Prerequisites

Chapter 4 (conclusion, premise, tracking whose view a sentence expresses) is essential — these questions are Chapter 4's structural skill turned into their own question types. The abstract-description skill from Chapter 9 also helps for Method questions.
:::

## 11.1 · Method / argument structure

:::callout-intuition
Intuition first

A Method question asks: "how does the argument *proceed*?" The answer describes the argument's moves in generic terms — "presents a hypothesis, then offers a counterexample," "draws an analogy," "concedes a point and then argues it's outweighed." You're a play-by-play announcer describing the *form* of the reasoning, not a judge of whether it's sound. The content is scaffolding; the structure is the answer.
:::

:::definition
**Definition 11.1 — Method (argument structure).** A question asking you to identify the abstract *technique* or *organization* of an argument. Stems: "the argument proceeds by," "the author develops the argument by," "which describes the method of reasoning used?" Correct answers describe real moves the argument makes, in the right order; wrong answers describe moves it didn't make (as in Flaw questions, Chapter 9).
:::

:::example
Worked Example 11.1 — describe the moves

standard

"Some claim that free public transit would ease congestion. But cities that made transit free saw only tiny ridership gains, and congestion barely changed. So free transit is not an effective way to reduce congestion."

**Stem.** The argument proceeds by…

- **(A)** appealing to an authority on urban planning.
- **(B)** defining a key term and deriving consequences from the definition.
- **(C)** attacking the character of those who hold the opposing view.
- **(D)** presenting a position and then rejecting it with empirical evidence about relevant cases.
- **(E)** drawing an analogy between transit and another public service.

Answer: (D).

**How we get there.** Trace the moves: (1) states a position others hold ("some claim free transit eases congestion"), (2) offers evidence from actual cities (tiny ridership gains, congestion unchanged), (3) concludes the position is wrong. That's "presents a position and rejects it with empirical evidence." (D) matches. The others describe techniques the argument didn't use — no character attack (C), analogy (E), authority (A), or definition (B). **Teaching point:** narrate the argument's moves in plain terms first, then match — exactly the Chapter 9 method, applied to structure instead of flaws.
:::

:::callout-pitfall
Watch out for these mistakes

- **Judging soundness instead of describing structure.** Method answers don't say whether the argument works — only how it's built. A perfectly-worded description of a bad argument is still correct.
- **Picking a technique not used.** Like Flaw wrong-answers, distractors name real methods (analogy, authority, definition) the argument didn't employ. Verify each against the text.
- **Getting the order wrong.** "Rejects a view, then presents evidence" ≠ "presents evidence, then rejects a view" if the sequence is reversed. Match the actual order.
:::

### Practice — 11.1

:::problem[Q1]{difficulty="standard"}
"Critics say the reform failed. But the reform was never fully funded, so it hasn't really been tested. We cannot yet judge it a failure." How does the argument proceed?

::::solution[Solution]
It **rebuts a criticism by challenging its presupposition** — arguing the reform wasn't truly implemented, so the critics' judgment is premature. (It doesn't defend the reform's results; it undercuts the basis for evaluating them.)
::::
:::

:::problem[Q2]{difficulty="standard"}
Why can a Method answer be correct even if the argument it describes is weak?

::::solution[Solution]
Because Method questions ask **how the argument is structured, not whether it succeeds**. A correct answer accurately describes the moves regardless of their quality; soundness is irrelevant to the description.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Consider a bridge with a cracked support: we'd never trust it. The economy has a similar structural crack — excessive debt — so we shouldn't trust it either." Name the method.

::::solution[Solution]
It **argues by analogy** — drawing a parallel between a cracked bridge and the economy to transfer a judgment (don't trust it) from one to the other.
::::
:::

:::problem[Q4]{difficulty="challenge"}
An answer reads "concedes a point to the opposition and then argues that it is outweighed by other considerations." What must appear in the stimulus for this to be correct?

::::solution[Solution]
Two things, in order: (1) an explicit **concession** — the author grants something the other side says ("Admittedly, X is true…") — and (2) a subsequent move showing that concession is **outweighed** ("…but Y matters more"). If either the concession or the outweighing isn't actually present, the description doesn't match.
::::
:::

## 11.2 · Role / function of a claim

:::callout-intuition
Intuition first

A Role question quotes one sentence from the argument and asks what *job* it does: is it the main conclusion? a premise supporting the conclusion? a sub-conclusion (a claim that's supported by something and in turn supports the main point)? a counter-position the author argues against? an example? The key is that you can't answer without first mapping the whole argument — you have to know where everything else is to say what this one piece does.
:::

:::definition
**Definition 11.2 — Role / function.** A question asking what part a specified statement plays in the argument's structure. Stems: "the claim that \_\_\_ plays which role?", "the statement about \_\_\_ functions in the argument to…". Common roles: *main conclusion, premise (support), intermediate/sub-conclusion, a view the author opposes, a concession, an example/illustration, background.*
:::

### The technique: map first, then locate

1. Find the **main conclusion** (Chapter 4). This is step one, always.
2. Identify the **premises** and any **sub-conclusions** (claims that are both supported *and* supporting).
3. Note any **opposing views** the author rebuts.
4. Now locate the quoted claim on that map and read off its role.

:::example
Worked Example 11.2 — premise vs. conclusion vs. opposing view

challenge

"Some argue that zoos are cruel and should be closed. But well-run zoos fund conservation programs that save species in the wild. Since protecting endangered species is a moral priority, zoos that support such efforts should remain open."

**Stem.** The claim that well-run zoos fund conservation programs that save species (underlined) plays which role?

- **(A)** It is a position the author ultimately rejects.
- **(B)** It is a claim the author concedes is false.
- **(C)** It restates the opposing view.
- **(D)** It is the argument's main conclusion.
- **(E)** It is a premise supporting the conclusion that certain zoos should remain open.

Answer: (E).

**How we get there.** Map it: main conclusion = "zoos that support conservation should remain open" (last sentence). Opposing view = "some argue zoos are cruel and should be closed" (first sentence, the view being rebutted). The underlined claim (zoos fund conservation that saves species) is a reason offered *for* keeping them open — a **premise**. So (E). Traps: (D) names the actual conclusion, not this claim; (A)/(C) confuse it with the opposing view it actually counters; (B) is wrong — the author asserts it, doesn't concede it false. **Teaching point:** you could only assign the role after mapping the whole thing — find the conclusion and the opposing view first, and the quoted claim's job becomes obvious.
:::

:::callout-pitfall
Watch out for these mistakes

- **Answering without mapping.** You can't know a sentence's role in isolation. Always locate the conclusion and opposing view first.
- **Confusing a sub-conclusion with the main conclusion.** A sub-conclusion is supported by something *and* supports the main point; make sure you've found the *final* claim everything drives toward.
- **Mistaking an opposing view for the author's premise.** Sentences introduced by "some argue," "critics say," "it might be thought" are usually positions the author *counters*, not support for the author's conclusion.
:::

### Practice — 11.2

:::problem[Q1]{difficulty="standard"}
In "Housing prices will keep rising. Demand far exceeds supply, and supply cannot grow quickly because of zoning limits," what role does "supply cannot grow quickly because of zoning limits" play?

::::solution[Solution]
**A premise** (support) for the conclusion that prices will keep rising — specifically explaining why supply can't catch up to demand. The first sentence is the conclusion.
::::
:::

:::problem[Q2]{difficulty="standard"}
What is a "sub-conclusion" (intermediate conclusion)?

::::solution[Solution]
A claim that is **both supported by a premise and used to support the main conclusion** — it sits in the middle of the chain. It's a conclusion relative to what's below it and a premise relative to the final point.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why must you identify the main conclusion before assigning any sentence's role?

::::solution[Solution]
Because a sentence's **role is defined by its relationship to the conclusion** — premise, sub-conclusion, opposing view, etc. Without knowing where the argument lands, you can't say what any piece does relative to it.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"Admittedly, the new drug has side effects. Still, it cures a disease that was previously fatal, so it should be approved." What role does "the new drug has side effects" play?

::::solution[Solution]
A **concession** — a point granted to the opposing side ("Admittedly…") that the author then argues is outweighed. It's not a premise for the conclusion (it actually cuts against approval); it's acknowledged and then overridden by the curing-a-fatal-disease premise.
::::
:::

## 11.3 · Point at issue / disagreement

:::callout-intuition
Intuition first

Point-at-Issue questions give you two speakers — call them Ana and Ben — and ask what they *disagree* about. The trap is that they talk past each other: they touch several topics, agree on some, and only clash on one specific claim. Your job is to find the one statement that Ana would **affirm** and Ben would **deny** (or vice versa). If either speaker has no stated opinion on a claim, it can't be the point of disagreement — even if it feels central.
:::

:::definition
**Definition 11.3 — Point at issue.** A question asking which statement two speakers disagree about. The correct answer is a claim on which the speakers hold *opposite* positions — one commits to it, the other commits against it. Stems: "Ana and Ben disagree about whether…", "the point at issue between them is…". A related, rarer stem asks what they *agree* on (same technique, reversed).
:::

:::callout-key
The two-part test for the correct answer

For a claim to be the point at issue, **both** must be true: (1) Speaker 1 has a clear position on it, and (2) Speaker 2 has the *opposite* position on it. Run both checks. The most common wrong answers fail because one speaker *never addresses* the claim (no position), or because both speakers actually *agree* on it.
:::

:::example
Worked Example 11.3 — find the clash

challenge

**Rosa:** "We should build the new highway. It will cut commute times, and shorter commutes will boost the local economy."

**Tomas:** "The highway will indeed shorten commutes, but the increased traffic and sprawl it encourages will harm the local economy in the long run."

**Stem.** Rosa and Tomas disagree about whether…

- **(A)** the highway will benefit the local economy.
- **(B)** commute times affect the economy.
- **(C)** the highway will be expensive to build.
- **(D)** sprawl is environmentally harmful.
- **(E)** the highway will shorten commute times.

Answer: (A).

**How we get there.** Map each speaker's positions. On *commute times*: Rosa says shorter, Tomas *agrees* ("will indeed shorten commutes") — so (E) is agreement, not disagreement. On *the economy*: Rosa says the highway will boost it; Tomas says it will harm it. Opposite positions — that's the clash. (A) is the point at issue. Traps: (B) neither takes a clear stance on the general principle; (C) cost is never mentioned by either (no position); (D) Tomas mentions sprawl but Rosa says nothing about its environmental harm (only one position). **Teaching point:** run the two-part test — the answer needs an explicit, opposite stance from *both* speakers.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking a claim only one speaker addressed.** If the other never takes a position, it can't be the point of disagreement — no matter how important it seems.
- **Choosing something they agree on.** Shared ground (like "commutes will shorten" above) is a classic trap on a disagreement question.
- **Inferring positions the speakers didn't state.** Stick to what each actually commits to; don't extrapolate a view to manufacture a clash.
- **Confusing tone with disagreement.** Two people can sound opposed while actually disagreeing about something narrower than it appears — pin the exact claim.
:::

### Practice — 11.3

:::problem[Q1]{difficulty="standard"}
State the two-part test for the correct answer to a Point-at-Issue question.

::::solution[Solution]
The claim must be one that **(1) one speaker affirms and (2) the other denies** — both must hold a clear, opposite position on it. If either lacks a stated position, it's not the point at issue.
::::
:::

:::problem[Q2]{difficulty="standard"}
**Mia:** "Remote work lowers company costs, so firms should adopt it." **Jae:** "Remote work does cut some costs, but it reduces collaboration so much that firms should not adopt it." What do they disagree about?

::::solution[Solution]
Whether **firms should adopt remote work**. They *agree* it lowers some costs; they take opposite positions on the recommendation to adopt it. (The cost point is common ground — a trap.)
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is a claim that only one speaker mentions never the correct answer?

::::solution[Solution]
Because disagreement requires **two opposing positions**. If only one speaker addresses the claim, the other has no stated view, so there's no clash — the two-part test fails on condition (2).
::::
:::

:::problem[Q4]{difficulty="challenge"}
**Lee:** "The painting is a genuine Rembrandt; the brushwork matches his known style." **Ada:** "The brushwork is consistent with Rembrandt, but pigment analysis dates it to after his death, so it's not genuine." Identify the point of agreement and the point at issue.

::::solution[Solution]
**Agreement:** the brushwork is consistent with Rembrandt's style (both grant this). **Point at issue:** whether the painting is a *genuine* Rembrandt — Lee affirms, Ada denies (on pigment-dating grounds). The shared brushwork observation is the trap; the authenticity claim is the real clash.
::::
:::

## 11.4 · Drill set

Ten mixed questions across the three types. Identify the type from the stem, then map the structure before answering. Difficulty rises.

:::problem[1]{difficulty="easy"}
"Skeptics say meditation is useless. But controlled studies show it lowers stress hormones. So meditation has real physiological benefits." *The argument proceeds by…*

- **(A)** appealing to popular opinion.
- **(B)** rebutting a dismissive claim with experimental evidence.
- **(C)** attacking the skeptics personally.
- **(D)** drawing an analogy between meditation and physical exercise.
- **(E)** defining meditation and drawing consequences.

::::solution[Solution]
**(B).** States a dismissal, counters it with controlled studies, concludes benefits are real. Method question.
::::
:::

:::problem[2]{difficulty="standard"}
"The company should relocate. Rent downtown has doubled, and relocating would cut fixed costs sharply." *"Rent downtown has doubled" functions as…*

- **(A)** a concession.
- **(B)** the main conclusion.
- **(C)** a premise supporting the recommendation to relocate.
- **(D)** an objection that the author goes on to rebut.
- **(E)** a view the author opposes.

::::solution[Solution]
**(C).** It's a reason offered for relocating (the conclusion). Role question.
::::
:::

:::problem[3]{difficulty="standard"}
**Pat:** "Nuclear power is safe and we should expand it." **Sam:** "Nuclear power is relatively safe, but the waste-storage problem is unsolved, so we should not expand it." *They disagree about whether…*

- **(A)** nuclear plants are expensive.
- **(B)** nuclear power is relatively safe.
- **(C)** whether nuclear power emits less carbon than coal.
- **(D)** we should expand nuclear power.
- **(E)** waste storage is a problem.

::::solution[Solution]
**(D).** They agree it's relatively safe; they clash on the expansion recommendation. Point at issue.
::::
:::

:::problem[4]{difficulty="standard"}
"Many believe talent is innate. Yet studies of experts show thousands of hours of practice precede elite performance. Thus talent is largely developed, not inborn." *The method is to…*

- **(A)** concede the common belief and extend it.
- **(B)** attack the motives of those who hold the belief.
- **(C)** defining a key term and deducing consequences from the definition.
- **(D)** rely on an analogy.
- **(E)** present a common belief and argue against it with empirical findings.

::::solution[Solution]
**(E).** Common belief stated, then rebutted with studies. Method.
::::
:::

:::problem[5]{difficulty="standard"}
"Electric cars reduce local air pollution. True, the electricity may come from coal, but even accounting for that, lifecycle emissions are lower. So cities should promote EVs." *"the electricity may come from coal" functions as…*

- **(A)** a concession the author then argues is outweighed.
- **(B)** the primary evidence for the conclusion.
- **(C)** an objection the author accepts as decisive.
- **(D)** an example of local air pollution.
- **(E)** the main conclusion.

::::solution[Solution]
**(A).** "True, …" signals a concession, immediately outweighed ("even accounting for that, lifecycle emissions are lower"). Role.
::::
:::

:::problem[6]{difficulty="challenge"}
"The senator's plan can't work. It assumes cities will cooperate, but cities have every incentive to defect. And a plan that ignores incentives is doomed." *"a plan that ignores incentives is doomed" functions as…*

- **(A)** the main conclusion of the argument.
- **(B)** a general principle used as a premise to support the conclusion that the plan can't work.
- **(C)** an assumption the author attributes to the senator.
- **(D)** a position the author rejects.
- **(E)** a specific example.

::::solution[Solution]
**(B).** Main conclusion is "the plan can't work"; the "doomed" statement is a general principle offered as support (combined with the point that the plan ignores incentives). Role.
::::
:::

:::problem[7]{difficulty="challenge"}
**Dr. Kim:** "The new therapy should be covered by insurance; trials show it works better than the standard treatment." **Dr. Ola:** "The trials do show it outperforms the standard, but it's so expensive that covering it would force cuts to other essential services, so it shouldn't be covered." *Point at issue?*

- **(A)** whether the therapy outperforms the standard treatment.
- **(B)** whether the therapy outperforms the standard treatment.
- **(C)** whether the therapy should be covered by insurance.
- **(D)** whether the therapy is expensive.
- **(E)** whether other services are essential.

::::solution[Solution]
**(C).** They agree it outperforms the standard (common ground / trap A); they disagree on whether it should be *covered*. Point at issue.
::::
:::

:::problem[8]{difficulty="challenge"}
"Opponents claim the tax will hurt small businesses. But it applies only to firms with over $50 million in revenue — hardly small businesses. So the objection misses its target." *The argument proceeds by…*

- **(A)** attacking the opponents' credibility.
- **(B)** appealing to the authority of tax experts.
- **(C)** generalizing from a single small business.
- **(D)** showing that an objection rests on a false assumption about the tax's scope.
- **(E)** conceding the objection and proposing a compromise.

::::solution[Solution]
**(D).** It rebuts the objection by showing its factual premise (that the tax hits small businesses) is false — the tax only hits large firms. Method.
::::
:::

:::problem[9]{difficulty="challenge"}
**Ravi:** "The museum's attendance rose because of the new exhibit." **Nell:** "Attendance did rise, but it was the citywide tourism boom, not the exhibit, that caused it." *They disagree about whether…*

- **(A)** tourism increased citywide.
- **(B)** whether a citywide tourism boom occurred.
- **(C)** the exhibit was popular.
- **(D)** museum attendance rose.
- **(E)** the new exhibit caused the rise in attendance.

::::solution[Solution]
**(E).** Both agree attendance rose (trap A); they disagree about the *cause* — exhibit vs. tourism boom. Point at issue. (Note the causal-alternative structure from Ch 6/8.)
::::
:::

:::problem[10]{difficulty="challenge"}
In one or two sentences, explain what all three question types in this chapter have in common and how that shapes your approach.

::::solution[Solution]
All three test **structural reading, not evaluation**: you map an argument's parts (conclusion, premises, opposing views) or two speakers' committed positions, and describe relationships rather than judge truth. So the shared approach is: **map first** — find the conclusion / each speaker's stance — *then* read off the method, the role, or the clash. Never assess whether anyone is right.
::::
:::

## Chapter summary

:::summary
#### Method, Role & Point at Issue, distilled

- **All three are structural, not evaluative.** Describe how the argument is built or where speakers clash — never whether anyone is right.
- **Method:** narrate the argument's moves in plain terms, then match; distractors name techniques not used (and watch the order).
- **Role:** map the whole argument (conclusion, premises, opposing views) *first*, then read off the quoted sentence's job.
- **Point at Issue:** the answer is a claim one speaker affirms and the other denies — run the two-part test; reject anything only one addresses or both agree on.
- **Foundation:** this is Chapter 4's conclusion/premise skill turned into its own question types.
:::

LSAT Mastery — Chapter 11. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
