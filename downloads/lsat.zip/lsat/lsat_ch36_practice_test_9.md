---
title: "Practice Test 9"
source: "markdown"
---

Part VI · Chapter 36

# Practice Test 9

A full original LSAT-style test emphasizing causal inference, conditional rules, and precisely supported reading judgments.

## Overview

Allow 35 minutes per section and take the three sections in one sitting, with a 10-minute break after Section II. Work under a timer. Do not open any solution until all three sections are complete.

**Flag, don’t guess silently.** Record every question you are unsure about, even when you select an answer. After timing, blind-review those flagged questions without the key (Chapter 22). Only then check the answers and log misses and reasoning errors (Chapter 23).

This is an original practice test written for this book, not an official LSAC PrepTest. Official LSAC PrepTests on LawHub remain the gold standard for timed practice (Chapter 24). This three-section scored-core drill does not include the unscored experimental section present on the actual LSAT.

## 36.1 Section I: Logical Reasoning

:::problem[Question I.1]
At two stops on the same bus route, passengers who waited beneath awnings boarded more quickly during rain than passengers at unsheltered stops. A transit manager proposes installing awnings everywhere, arguing that the resulting faster boarding will improve the route's punctuality. The operations director agrees that awnings may be pleasant, but notes that nearly all of the route's recorded delays occur at a bridge far from any stop. Consequently, she argues, the awnings are unlikely to make the buses arrive at their final stop appreciably earlier.

Which one of the following most accurately expresses the operations director’s main conclusion?

- **(A)** Installing awnings will make waiting more comfortable.
- **(B)** The bridge delays should be eliminated before other improvements are considered.
- **(C)** Installing awnings is unlikely to appreciably improve the route’s final arrival times.
- **(D)** Passengers at sheltered stops board more quickly during rain.
- **(E)** The bridge delays are themselves longer in rain, when the awnings would be most useful.

::::solution[Solution]
**Answer:** (C)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The director concludes that awnings probably will not materially improve the final arrival times.
2. **Support.** She concedes a possible boarding benefit but says delays largely originate at the bridge.
3. **Prephrase.** Separate an intermediate concession from the claim the director wants accepted.
4. **Why (C) is right.** (C) states the final judgment about the effect of awnings, not merely a supporting observation.
5. **Why the others fail.**
   - **(A)** Concession trap: comfort is not the point she sets out to establish.
   - **(B)** Recommendation trap: she never says bridge repair must come first.
   - **(D)** Premise trap: this is the observation prompting the proposal, not her conclusion.
   - **(E)** Relevant timing trap: a rain-related bridge delay does not make awnings reduce the bridge bottleneck.

**Check:** The word “Consequently” introduces the final conclusion, which (C) reproduces.
::::
:::

:::problem[Question I.2]
A bakery tested two dough-resting schedules. In its first week, loaves left to rest overnight received higher flavor scores than loaves rested for two hours. The owner concludes that the additional resting time, rather than some unrelated feature of the trial, improved the loaves' flavor. A critic points out that the overnight loaves were baked by the evening team, whereas the short-rest loaves were baked by the morning team, and the teams sometimes use different oven settings. The owner wants evidence addressing that criticism rather than merely another set of favorable customer comments.

Which one of the following, if true, most strengthens the owner’s conclusion?

- **(A)** A later trial randomly assigned both resting schedules to each team, held ingredients and baking settings constant, and again favored overnight rest.
- **(B)** Overnight dough can be prepared before the bakery opens for the day.
- **(C)** Both teams believe that customers prefer bread with a darker crust.
- **(D)** The share of customers reporting that they purchased bread rose during the trial.
- **(E)** Most customers who praised overnight loaves had also purchased bread from the bakery previously.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Longer rest caused improved flavor, not a team or oven difference.
2. **Support.** The original comparison confounded rest length with the baking team.
3. **Prephrase.** Find a comparison that isolates resting time while controlling other plausible causes.
4. **Why (A) is right.** (A) removes the team and oven confounds and reproduces the effect under controlled assignment.
5. **Why the others fail.**
   - **(B)** Practicality trap: scheduling benefits do not establish flavor effects.
   - **(C)** Shared belief trap: crust preferences do not control oven differences in the original study.
   - **(D)** Outcome shell game: buying bread does not identify what caused the measured flavor advantage.
   - **(E)** Popularity trap: returning customers do not isolate the cause of a score difference.

**Check:** Holding other conditions fixed preserves resting time as the decisive tested difference.
::::
:::

:::problem[Question I.3]
A small archaeological museum introduced a monthly public excavation demonstration. Attendance rose during the same three months. Its curator concludes that the demonstrations caused the increase and proposes moving several permanent displays to create space for more demonstrations. Yet the museum also began offering free admission during those months, and the curator's evidence does not distinguish demonstration visitors from people who came because admission was free. The curator replies that an exciting program plainly attracts people and thus requires no further analysis of why attendance increased.

The curator’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** confuses a condition required for museum admission with a condition sufficient for attendance.
- **(B)** Assumes that demonstrations will be more expensive to run than permanent displays.
- **(C)** assumes that visitors to the demonstrations were already interested in archaeology.
- **(D)** rejects a proposal merely because it would alter a permanent display.
- **(E)** attributes a change to one event without ruling out another simultaneous possible cause.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The demonstrations explain the attendance rise.
2. **Support.** Both demonstrations and free admission began together, so the time trend does not isolate a cause.
3. **Prephrase.** Look for a correlation-to-causation flaw involving a competing explanation.
4. **Why (E) is right.** (E) correctly identifies the unaddressed free-admission confound.
5. **Why the others fail.**
   - **(A)** Conditional-logic decoy: no necessary/sufficient admission rule is invoked.
   - **(B)** Cost distraction: no cost comparison supports or undermines the curator’s inference about attendance causation.
   - **(C)** Visitor-motivation detail: the claim concerns the source of rising attendance, not preexisting interests.
   - **(D)** Misstates structure: display relocation follows the causal claim; it is not rejected as such.

**Check:** If free admission alone attracted the additional visitors, the curator’s causal inference fails.
::::
:::

:::problem[Question I.4]
A warehouse manager surveyed employees at the end of a voluntary morning meeting. Of those who filled out the questionnaire, most preferred keeping the current night-shift schedule to adopting the proposed alternating schedule. The manager concludes that a majority of all warehouse employees would prefer the current schedule. Several workers who rarely attend morning meetings are assigned exclusively to nights. The manager says the survey is nevertheless decisive because it records respondents' preferences accurately; no one has alleged that respondents lied about their choices.

Which one of the following is an assumption on which the manager’s argument depends?

- **(A)** No employee changed a preference after answering the questionnaire.
- **(B)** The meeting attendees’ preferences are not so different from those of nonattendees that the warehouse-wide majority would be reversed.
- **(C)** Every employee received advance notice of the meeting.
- **(D)** Employees who work only nights are less satisfied than other employees.
- **(E)** All employees have previously experienced an alternating schedule.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** A majority of all employees prefer the existing schedule.
2. **Support.** The survey establishes only a majority among attendees who answered; the unobserved employees could differ.
3. **Prephrase.** The manager needs enough representativeness to carry a sample majority to the workforce.
4. **Why (B) is right.** (B) is a minimal bridge: negate it and the absent employees could overturn the claimed majority.
5. **Why the others fail.**
   - **(A)** Timing trap: later preference changes do not fix who was omitted from the survey.
   - **(C)** Coverage trap: notification does not establish how nonattendees would vote.
   - **(D)** Direction trap: assumes dissatisfaction without showing any preference for a schedule.
   - **(E)** Experience trap: prior exposure is not required for having a preference.

**Check:** Negate (B): nonrespondents reverse the majority, leaving the manager’s conclusion unsupported.
::::
:::

:::problem[Question I.5]
At a regional airport, administrators assigned two additional inspectors to the document-check station for an entire month. Records show that the average time an individual traveler spent being checked fell markedly. Nevertheless, the average time from joining the line to clearing the station increased. The airport's measurements were taken using the same definitions before and after the change. The administrators are puzzled: the inspection itself became faster, yet a traveler had to allow more total time for it. They seek an explanation that can make both measurements accurate.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The new inspectors completed their training just before the month began.
- **(B)** Travelers rated the inspectors’ courtesy more highly than before.
- **(C)** The airport offered fewer flights in the following month.
- **(D)** The number of travelers arriving at the station per hour increased enough to exceed the station’s new processing capacity.
- **(E)** Most flights depart from the airport’s smaller terminal, whose traffic grew slightly.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** There is no argumentative conclusion; the puzzle is shorter service but longer total time.
2. **Support.** Total time includes queueing, and arrival flow can outpace processing even when service per traveler improves.
3. **Prephrase.** Distinguish the service-time component from the waiting-time component.
4. **Why (D) is right.** (D) raises line length enough that waiting-time increases dominate faster individual checks.
5. **Why the others fail.**
   - **(A)** Background detail: training date alone does not explain longer queues.
   - **(B)** Satisfaction distraction: courtesy does not determine queue length.
   - **(C)** Wrong period: next month’s flights cannot explain the measured month.
   - **(E)** Wrong comparison: the smaller terminal’s traffic does not establish whether arrivals at this inspection station increased.

**Check:** Total time = queue wait + inspection time; one can rise more than the other falls.
::::
:::

:::problem[Question I.6]
At a flight school, every helicopter cleared for instructional flight has passed a rotor inspection within the past week. No helicopter with an unresolved hydraulic warning is cleared for instructional flight. The school's two trainer helicopters, Lark and Wren, both passed rotor inspections yesterday. Wren has an unresolved hydraulic warning; Lark does not. A third helicopter, Finch, is used only for maintenance training and is not eligible for instructional flight. The chief engineer cautions that a recent rotor inspection is only one of several conditions for clearance.

Which one of the following must be true?

- **(A)** Every helicopter that passes a rotor inspection is cleared for instructional flight.
- **(B)** Wren is not cleared for instructional flight.
- **(C)** Finch has an unresolved hydraulic warning.
- **(D)** Lark and Wren will receive identical clearance decisions.
- **(E)** Lark is cleared for instructional flight.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** No contested conclusion; the task is to deduce a mandatory statement from the rules.
2. **Support.** Unresolved hydraulic warning implies not cleared, while inspection is only necessary, not sufficient.
3. **Prephrase.** Apply the exclusion rule to Wren without reversing the inspection rule.
4. **Why (B) is right.** (B) follows directly because Wren has the warning that bars clearance.
5. **Why the others fail.**
   - **(A)** Converse trap: passing inspection is necessary for clearance, not sufficient.
   - **(C)** Unsupported attribution: Finch’s ineligibility does not show a particular warning.
   - **(D)** False equivalence: the two helicopters differ on a clearance-relevant warning.
   - **(E)** Wrong conditional target: Lark’s absence of a warning does not guarantee clearance.

**Check:** Warning -> not cleared; Wren has warning -> Wren not cleared.
::::
:::

:::problem[Question I.7]
A planner argues that converting a four-lane downtown road to two lanes will reduce traffic throughout the surrounding district. In a neighboring district, traffic counts on a narrowed road fell by one-third after a similar conversion. The planner assumes that the reduction represented fewer car trips, not simply drivers choosing other roads. A colleague notes that the neighboring study counted vehicles only on the altered road, even though the district has several parallel streets and drivers can reach the same destinations by multiple routes.

Which one of the following, if true, most seriously weakens the planner’s argument?

- **(A)** Traffic on the altered road fell during weekend mornings as well as weekdays.
- **(B)** Travel times on the narrowed road were shorter on the day the planner visited.
- **(C)** The narrowed road gained space for benches and street trees.
- **(D)** The neighboring district’s parallel streets gained approximately as many vehicle trips as the narrowed road lost.
- **(E)** Several drivers had already changed their preferred route during the roadwork preceding the conversion.

::::solution[Solution]
**Answer:** (D)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The road conversion will reduce district-wide vehicle traffic.
2. **Support.** The single-road comparison does not show whether traffic disappeared or moved elsewhere.
3. **Prephrase.** Find evidence that the apparent drop is displacement rather than fewer trips.
4. **Why (D) is right.** (D) offsets the decline elsewhere, directly contradicting the extrapolation to total district traffic.
5. **Why the others fail.**
   - **(A)** Same-measure trap: another decline on the treated road leaves diversion possible.
   - **(B)** Different metric: one day’s travel time cannot distinguish district-wide traffic removal from diversion.
   - **(C)** Amenity trap: improved streetscape does not establish district-wide traffic reduction.
   - **(E)** Timing alternative: earlier route changes do not establish a net reduction across the district after conversion.

**Check:** Net district change = road losses + parallel-road gains; (D) may make it near zero.
::::
:::

:::problem[Question I.8]
A cooperative sells foods made by several small vendors. Its board adopts a principle: when a seller has credible evidence that an ingredient could seriously harm an identifiable group of customers, and a clear warning would allow those customers to avoid that harm without misleading others, the seller should place the warning on the package. The principle does not require warnings about remote possibilities unsupported by evidence, nor does it endorse claims that exaggerate the danger to the general public. The board must decide between several proposed labeling policies.

Which one of the following policies most closely conforms to the board’s principle?

- **(A)** Add a clear group-specific notice when reliable testing identifies a serious risk to that group and the notice permits avoidance.
- **(B)** Warn only when a vendor’s competitors print a similar notice.
- **(C)** Warn that every product is dangerous because some foods cause allergies.
- **(D)** Warn about any imaginable adverse reaction even without credible evidence.
- **(E)** Omit all warnings until a customer has actually been injured.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (apply) (Chapter 13)

1. **Conclusion.** The task is to apply a conditional warning principle, not assess whether it is empirically sound.
2. **Support.** Credible group-specific serious risk plus useful nonmisleading warning jointly trigger the duty.
3. **Prephrase.** Choose the policy that respects both the evidence threshold and the narrow warning scope.
4. **Why (A) is right.** (A) satisfies the trigger and the warning’s intended function.
5. **Why the others fail.**
   - **(B)** Popularity substitution: a competitor’s notice is not the specified evidence.
   - **(C)** Overgeneralization trap: it would mislead customers outside the at-risk group.
   - **(D)** Evidence omission: merely imaginable reactions fail the credible-evidence condition.
   - **(E)** Too-late condition: actual injury is not required by the rule.

**Check:** Match all necessary parts of the principle to the proposed policy.
::::
:::

:::problem[Question I.9]
A university archive plans to digitize a collection of correspondence. Every collection whose index is fully searchable can be located by researchers through the archive's public portal. The project supervisor knows that the correspondence will be digitized, but digitization alone does not guarantee a fully searchable index: some digitized collections have only image files. Nevertheless, the supervisor confidently concludes that researchers will be able to locate this collection through the public portal when the project is complete.

Which one of the following, if assumed, enables the supervisor’s conclusion to be properly drawn?

- **(A)** Researchers will prefer this collection to most of the archive’s other collections.
- **(B)** Some digitized collections without searchable indexes are still accessible by direct links.
- **(C)** The correspondence collection’s index will be fully searchable when digitization is complete.
- **(D)** Some collections available through the portal have never been digitized.
- **(E)** Researchers will be allowed to download complete images of the correspondence.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Researchers can locate the correspondence via the portal.
2. **Support.** Fully searchable index -> portal locatable; digitization alone does not supply the antecedent.
3. **Prephrase.** Bridge this particular collection to the sufficient searchability condition.
4. **Why (C) is right.** (C) establishes the antecedent; the stated rule then guarantees the conclusion.
5. **Why the others fail.**
   - **(A)** Preference trap: interest does not entail findability.
   - **(B)** Possibility trap: direct access to other collections does not ensure this collection will be findable through the portal.
   - **(D)** Irrelevant existential: other collections say nothing about this one.
   - **(E)** Access distinction: downloading images is different from finding the collection.

**Check:** Searchable index -> portal location; (C) supplies searchable index, so location follows.
::::
:::

:::problem[Question I.10]
A school director says: 'The pilot cafeteria used smaller serving spoons, and food discarded per student dropped by twelve percent. The pilot also placed a second trash station next to the exit. Some teachers infer that smaller spoons must be responsible for the lower waste. But the extra station may have altered how precisely the discarded food was collected and weighed. We should therefore repeat the pilot with the disposal arrangements held fixed before attributing any reduction to serving size.' The director accepts the reported number but questions the explanation attached to it.

In the director’s argument, the claim that the extra trash station may have altered measurement plays which one of the following roles?

- **(A)** It is a premise offered to show that smaller spoons increase food waste.
- **(B)** It summarizes the teachers’ view without challenging it.
- **(C)** It identifies a safeguard that guarantees the measured decline reflects a real decrease in discarded food.
- **(D)** It states the conclusion that the director ultimately wants the school to accept.
- **(E)** It is a possible alternative explanation used to undermine a causal inference.

::::solution[Solution]
**Answer:** (E)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** A controlled repeat is warranted before assigning causation to smaller spoons.
2. **Support.** The measurement concern introduces a confounding explanation for the observed drop.
3. **Prephrase.** Identify whether the claim is conclusion, rebuttal, concession, or background.
4. **Why (E) is right.** (E) assigns the statement its actual critical role against the teachers’ inference.
5. **Why the others fail.**
   - **(A)** Opposite claim: the director does not claim spoons increase waste.
   - **(B)** Attribution reversal: the measurement worry is the director’s challenge.
   - **(C)** Direction reversal: the statement questions the integrity of measurement instead of guaranteeing it.
   - **(D)** Conclusion substitution: the director’s final request is a new controlled pilot.

**Check:** The statement supports the “repeat the pilot” conclusion by challenging the earlier causal reading.
::::
:::

:::problem[Question I.11]
An aviation club plans to replace all lamps along its training runway. One trial lamp survived fourteen months of testing under unusually mild weather. The club's treasurer claims that every replacement lamp can be budgeted to last at least fourteen months and therefore that purchasing replacements only once a year will never cause an interruption. The testing technician points out that the other lamps could be exposed to stronger winds and greater temperature changes, and that even identical lamps do not all fail at identical times. The treasurer insists that the trial proves the annual schedule is safe.

The reasoning is most vulnerable to criticism because it...

- **(A)** mistakes a disagreement about replacement timing for proof of a disagreement about lamp durability.
- **(B)** presumes that runway lights can be replaced only in summer.
- **(C)** treats a necessary condition for safe operations as sufficient.
- **(D)** takes a single observation under favorable conditions to establish a universal guarantee.
- **(E)** uses the price of a lamp to infer its expected operating lifetime.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The trial establishes a universal annual replacement guarantee for all lamps.
2. **Support.** The evidence is one lamp in mild conditions; other conditions and variation are untested.
3. **Prephrase.** Identify the overgeneralization from a small, atypical sample to “every” and “never.”
4. **Why (D) is right.** (D) describes the unjustified move from a favorable single test to a universal claim.
5. **Why the others fail.**
   - **(A)** The treasurer’s evidence fails because of sample scope, not because two people have different opinions.
   - **(B)** Fabricated restriction: summer replacement is never proposed.
   - **(C)** Condition trap: no necessary/sufficient rule is formulated; the trouble is generalization.
   - **(E)** Cost trap: the argument mentions a budget but never uses lamp price as evidence of lifetime.

**Check:** One observation cannot logically establish the asserted zero-risk universal schedule.
::::
:::

:::problem[Question I.12]
A grocery chain noticed that spoilage complaints fell after its stores began using temperature alarms in refrigerated display cases. A regional analyst argues that the alarms reduced spoilage by notifying staff quickly when cases warmed. Critics note that the chain simultaneously changed delivery schedules, reducing the time groceries sat on loading docks. The analyst proposes comparing stores whose deliveries changed equally but whose alarm implementation dates differed, because such evidence would separate the competing explanations more effectively than a chain-wide before-and-after comparison.

Which one of the following, if true, most strengthens the analyst’s explanation?

- **(A)** Several stores with alarms had already expanded their advertising about food quality.
- **(B)** Stores with the alarms also sold more frozen desserts during the study.
- **(C)** Several stores with the same delivery changes experienced a substantial complaint drop immediately after alarms were activated, while matched stores awaiting activation did not.
- **(D)** Delivery drivers generally considered the new schedules easier to follow.
- **(E)** Spoilage complaints had fallen at several stores before the alarm installation.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Case alarms, rather than delivery changes alone, reduced spoilage complaints.
2. **Support.** Both changes occurred together, but staggered activation can isolate the alarm.
3. **Prephrase.** Hold delivery improvements fixed while comparing alarm timing and outcome.
4. **Why (C) is right.** (C) supplies precisely that differential pattern, favoring an alarm effect.
5. **Why the others fail.**
   - **(A)** Competing-change trap: advertising could affect the complaints received without isolating alarms.
   - **(B)** Sales category distraction: desserts do not isolate spoiled products.
   - **(D)** Driver satisfaction trap: convenience is not spoilage reduction.
   - **(E)** Temporal counterevidence: declines before alarms could favor another explanation.

**Check:** Matched delivery changes + differing alarm activation makes alarms the remaining measured difference.
::::
:::

:::problem[Question I.13]
An archaeological site offers tours of two reconstructed courtyards. Visitors shown a reconstructed painted wall more often say that they can imagine life at the site than visitors shown an unpainted wall. The guide argues that painting the wall made visitors understand the original residents' daily routines more accurately. The survey question, however, asked about vividness of imagination, not accuracy, and the reconstructions were designed using incomplete evidence. The guide acknowledges the difference in wording but treats it as irrelevant to the conclusion about historical understanding.

Which one of the following is an assumption required by the guide’s reasoning?

- **(A)** Every part of the painted reconstruction is historically accurate.
- **(B)** The observed increase in reported vividness indicates at least some increase in accuracy of understanding, rather than imagination alone.
- **(C)** The unpainted reconstruction was disliked by every visitor.
- **(D)** Visitors who imagine a scene vividly always remember it longer.
- **(E)** The original residents painted every wall in the same manner.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The painting improved accuracy of visitors’ historical understanding.
2. **Support.** The evidence measures self-reported vividness, a distinct property from accuracy.
3. **Prephrase.** The guide must connect measured vividness to actual accuracy in this comparison.
4. **Why (B) is right.** (B) is the required bridge; if vividness increased with no gain in accuracy, the offered evidence does not support the accuracy conclusion.
5. **Why the others fail.**
   - **(A)** Too strong: accuracy need not require every reconstruction detail to be correct.
   - **(C)** Unnecessary extreme: universal dislike of the comparison wall plays no role.
   - **(D)** Memory shell game: retention is different from historical accuracy.
   - **(E)** Historic-uniformity overreach: the argument does not need all walls to match.

**Check:** Negate (E): there is no accuracy gain behind the vividness result, so the inference loses its bridge.
::::
:::

:::problem[Question I.14]
A business association claims that a proposed neighborhood market is unnecessary because most people questioned outside the existing supermarket said they had no trouble buying groceries. An advocate replies: 'That survey samples people who already reached the supermarket, not residents who cannot conveniently get there. You have inferred neighborhood-wide access from a group selected partly by its access. Unless you investigate residents unable to use the current store, you cannot infer that an additional market would serve no unmet need.' The advocate does not claim that a new market is certainly needed.

The advocate proceeds primarily by...

- **(A)** conceding the association’s conclusion while disputing the way it was worded.
- **(B)** appealing to the survey’s numerical majority rather than questioning the truthfulness of respondents.
- **(C)** arguing that all neighborhood residents face the same shopping barriers.
- **(D)** providing independent measurements that establish the proposed market will be profitable.
- **(E)** rejecting a universal prediction because an observed sample excludes a relevant portion of the population.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The existing-store survey cannot settle the neighborhood-wide need question.
2. **Support.** The sample is selected from people able to access the existing store.
3. **Prephrase.** Describe the criticism of representativeness without falsely attributing a positive demand claim.
4. **Why (E) is right.** (E) correctly identifies an omitted subgroup and the unsupported population inference.
5. **Why the others fail.**
   - **(A)** Wrong position: the advocate denies the inference, not concedes its conclusion.
   - **(B)** Misidentified criticism: the advocate does not dispute how respondents answered, but whether the sample represents all residents.
   - **(C)** Universalization trap: the advocate highlights differences in access.
   - **(D)** Proof inflation: the advocate provides no profitability analysis.

**Check:** The conclusion attacks the survey’s reach, not the market’s ultimate merits.
::::
:::

:::problem[Question I.15]
A county recreation office states that every instructor authorized to lead its river outings has completed water-safety training. Everyone who completes that training must have passed a written evaluation. Nira is authorized to lead outings. The office therefore concludes that Nira passed the evaluation. The office makes no claim that passing the evaluation by itself grants authorization; authorization could have additional requirements. Nira received the authorization in last week's scheduling email, which the recreation office uses to identify the people permitted to lead each outing.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Anyone on the roster attended orientation; anyone attending orientation signed a form; Tavi is on the roster; therefore Tavi signed a form.
- **(B)** No gardener with a permit lacks registration; Mina lacks a permit; therefore Mina is unregistered.
- **(C)** All delegates travel by rail or air; Juno traveled by air; therefore Juno is a delegate.
- **(D)** All certified bakers have completed training; Ezra completed training; therefore Ezra is certified.
- **(E)** All rented bicycles have functioning brakes; some bicycles have functioning brakes; therefore some are rented.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Authorization entails training, which entails passing; Nira is authorized, so she passed.
2. **Support.** This is a valid two-link modus ponens chain, A -> B -> C; A, therefore C.
3. **Prephrase.** Find another argument following two forward implications from a known starting membership.
4. **Why (A) is right.** (A) maps roster -> orientation -> signed form, plus roster membership, to the endpoint.
5. **Why the others fail.**
   - **(B)** Denying-antecedent trap: lack of permit does not imply unregistered.
   - **(C)** Affirming-consequent trap: rail/air travel does not imply delegate status.
   - **(D)** Affirming-consequent trap: training does not imply certification.
   - **(E)** Reverse-direction trap: working brakes need not mean rented.

**Check:** A -> B -> C and A imply C; only (C) duplicates this valid structure.
::::
:::

:::problem[Question I.16]
A councilmember argues that capping the retail price of fresh produce at a neighborhood market will increase how much produce low-income residents can buy. The councilmember notes that residents have the same food budgets and that, at the proposed cap, each unit would cost less than it does now. Suppliers, however, are free to send each day's produce to different markets, and the store already devotes most of its refrigerated space to products it has contracted to stock. The councilmember has not negotiated any agreement about deliveries under the proposed cap.

Which one of the following, if true, most weakens the councilmember’s argument?

- **(A)** Fresh produce has a shorter shelf life than dried food.
- **(B)** The market’s produce is sourced from several farms.
- **(C)** Residents buy less produce when the market reduces its prices in seasonal promotions.
- **(D)** The councilmember previously supported a different pricing policy.
- **(E)** Under the proposed cap, suppliers would reduce deliveries so sharply that the market would sell substantially fewer units to those residents.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** A lower capped unit price increases residents’ attainable produce purchases.
2. **Support.** An affordable price is useful only if sufficient produce is offered for sale.
3. **Prephrase.** Find a quantity response that offsets the purported buying-power benefit.
4. **Why (E) is right.** (E) shows the policy restricts available units, defeating the inference from cheaper price to larger purchased quantity.
5. **Why the others fail.**
   - **(A)** True-seeming background: perishability alone does not establish a delivery reduction.
   - **(B)** Supplier-number trap: multiple farms do not ensure supply under the cap.
   - **(C)** Wrong intervention comparison: past promotions may involve different quantities, suppliers, and durations from the proposed cap.
   - **(D)** Ad hominem trap: the member’s prior position is not evidence about supply.

**Check:** Lower price without available supply does not imply more units can be bought.
::::
:::

:::problem[Question I.17]
An airfield divided its grounds into three zones for wildlife inspections. All reported bird strikes during the quarter occurred near Zone C. Inspections discovered nests in Zones B and C, but none in Zone A. The report also notes that teams spent more hours inspecting Zone A than either other zone. The manager cautions that finding no nests in a zone does not show that birds never fly through it, and that strikes can depend on aircraft movement as well as birds' locations. The report provides no counts of aircraft movements by zone.

Which one of the following is most strongly supported by the report?

- **(A)** The location of reported strikes cannot by itself establish the relative number of nests in all three zones.
- **(B)** Zone C contains more nests than Zones A and B combined.
- **(C)** Increasing inspections in Zone C would necessarily reduce the number of birds in all zones.
- **(D)** Every bird strike in the quarter occurred because a nest was nearby.
- **(E)** Zone A is completely free of birds.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The task is to state the limited conclusion the record justifies.
2. **Support.** Strikes are only reported in C; nest detection is imperfect and aircraft movement varies.
3. **Prephrase.** Avoid treating reported incidents as a direct census of nests or birds.
4. **Why (A) is right.** (A) accurately preserves the distinction between strike location and nest abundance.
5. **Why the others fail.**
   - **(B)** Comparison invention: no complete nest counts by zone were provided.
   - **(C)** Intervention guarantee: no such response to greater inspections is measured in the report.
   - **(D)** Causation overclaim: proximity of nests is not shown to cause every strike.
   - **(E)** Absence-of-evidence trap: no observed nests does not imply no birds.

**Check:** Observed strike distribution alone cannot rank nests without other exposure data.
::::
:::

:::problem[Question I.18]
Principal: 'If we offer students small rewards for perfect attendance, attendance will improve in the first semester. That alone makes the program worth adopting, even if it has no lasting effect.' Counselor: 'I agree that short-term attendance will improve. But a program should not be adopted unless there is reason to expect it to improve attendance after rewards stop. A temporary change is insufficient to justify the cost and administrative effort.' Both speak about the same proposed reward program and accept the same forecast of its immediate effect.

The principal and counselor disagree about whether...

- **(A)** the program will have any administrative cost.
- **(B)** attendance can be measured accurately for a semester.
- **(C)** students generally prefer rewards to verbal praise.
- **(D)** a short-term attendance improvement alone is enough to justify adopting the program.
- **(E)** the proposed rewards will improve first-semester attendance.

::::solution[Solution]
**Answer:** (D)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Find a proposition for which the speakers take opposite positions.
2. **Support.** They agree on the short-term gain; they differ on whether that gain is sufficient to justify adoption.
3. **Prephrase.** Test each choice against explicit yes/no commitments by both speakers.
4. **Why (D) is right.** (D) gets a “yes” from the principal and a “no” from the counselor.
5. **Why the others fail.**
   - **(A)** Undetermined: only the counselor refers to cost, and neither denies it.
   - **(B)** Unaddressed: neither questions the accuracy of attendance counts.
   - **(C)** Preference distraction: neither discusses praise.
   - **(E)** Agreement trap: both say attendance will initially improve.

**Check:** Two-sided test: principal yes, counselor no, on (D) only.
::::
:::

:::problem[Question I.19]
At an excavation, researchers found fragments of decorative pottery in a trench along with materials clearly deposited centuries later. An amateur historian asserts that the decorative pottery must have been made at the same time as the later materials, since all were found in the same trench. A specialist cautions that excavation layers can contain materials disturbed and redeposited at different times. The amateur replies that sharing a location makes a common production date unavoidable, without offering evidence that the trench remained undisturbed throughout its history.

The amateur historian’s reasoning is flawed because it...

- **(A)** rejects the specialist’s caution because the later objects were recovered at a greater depth.
- **(B)** assumes that objects discovered together must have originated at the same time.
- **(C)** concludes that all the pottery in the region had a single manufacturer.
- **(D)** uses pottery style to determine which excavation layer is oldest.
- **(E)** argues from the absence of decorative pottery at other sites.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Co-location guarantees the same production date.
2. **Support.** A mixed or disturbed deposit can bring together items of different ages.
3. **Prephrase.** Identify the unsupported inference from shared discovery context to shared origin time.
4. **Why (B) is right.** (B) names exactly the co-location-to-contemporaneity leap.
5. **Why the others fail.**
   - **(A)** Invented evidence: neither the amateur nor specialist mentions a reliable depth-based dating comparison.
   - **(C)** Scope inflation: neither single manufacturer nor the whole region is discussed.
   - **(D)** Method substitution: the amateur does not date anything from style.
   - **(E)** Missing evidence trap: no comparison with other sites occurs.

**Check:** It is possible for objects made at different times to be deposited together.
::::
:::

:::problem[Question I.20]
A ferry operator lowered fares on weekdays for a trial month and saw higher ridership than the month before. The operator argues that repeating the discount next month will increase fare revenue because more people will ride. A board member observes that a revenue prediction requires balancing fares collected per rider against the number of paying riders, and that the additional passengers may include riders who would otherwise have paid full price. The operator has reported the change in total boardings but not the resulting revenue.

The answer to which one of the following questions would be most useful in evaluating the operator’s argument?

- **(A)** Did advertising the discount attract riders who would otherwise have purchased full-price fares?
- **(B)** Did passengers find the discounted tickets easier to purchase?
- **(C)** Did the increase in paying rides, accounting for the discount on each ride, produce greater total fare receipts during the trial?
- **(D)** Was the increase in boardings concentrated among commuters who would otherwise have used a competing route?
- **(E)** Were some of the additional boardings made using passes purchased before the discount began?

::::solution[Solution]
**Answer:** (C)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** A repeated discount will raise fare revenue, not just boardings.
2. **Support.** Revenue equals number of paid rides times fare actually received; the trial reports only boardings.
3. **Prephrase.** Ask for the omitted outcome that directly adjudicates the revenue claim.
4. **Why (C) is right.** (C) distinguishes a net gain from a revenue loss despite more rides.
5. **Why the others fail.**
   - **(A)** Cannibalization clue: the answer might identify one revenue pressure, but not the net outcome across all paid trips.
   - **(B)** Convenience trap: purchasing ease does not determine total receipts.
   - **(D)** Passenger-origin trap: knowing where riders came from does not reveal total fare receipts after discounting.
   - **(E)** Partial-revenue trap: prepayment matters, but the net receipts comparison in the credited choice settles the prediction directly.

**Check:** Revenue comparison is the direct test; boardings alone are insufficient.
::::
:::

:::problem[Question I.21]
A machine shop offers a paid apprenticeship. Its director says: 'When an applicant demonstrates the skills needed to do a job safely and effectively, we should not deny that applicant access merely because the skills were learned outside a formal school. On the other hand, a convincing certificate cannot excuse a failure to perform the required safety tasks.' The director proposes a practical skills demonstration alongside a review of training records. This approach would allow traditional coursework to count as evidence without making a particular educational route an absolute gatekeeper.

Which one of the following principles most closely underlies the director’s reasoning?

- **(A)** Eligibility should depend on demonstrated job-relevant competence rather than on possession of one educational credential alone.
- **(B)** Applicants without formal schooling should always be preferred over those who attended school.
- **(C)** Certificates should count only when issued by employers rather than schools.
- **(D)** Safety demonstrations are unnecessary when a candidate has years of experience.
- **(E)** Every applicant must receive the position if willing to accept its wages.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (identify) (Chapter 13)

1. **Conclusion.** Competence should govern access, regardless of where it was learned.
2. **Support.** Practical demonstration can validate both formally and informally acquired skills.
3. **Prephrase.** State the decision rule linking relevant evidence of skill to eligibility.
4. **Why (A) is right.** (A) captures competence over pedigree without assuming everyone qualifies.
5. **Why the others fail.**
   - **(B)** Reverse preference: the rule removes a barrier; it does not privilege non-school routes.
   - **(C)** Credential-source invention: no employer-only rule is stated.
   - **(D)** Safety exception error: actual performance is required regardless of years.
   - **(E)** Unbounded guarantee: willingness to accept wages is not competence.

**Check:** The principle allows different routes but holds the safety standard constant.
::::
:::

:::problem[Question I.22]
A town library proposes shifting two hours of afternoon operations into the evening. Its administrator argues that doing so will increase the total number of student visits to the library, pointing to a survey in which many students said they would visit if the library stayed open after dinner. The library is currently full of students in the late afternoon, and staffing will be shifted from the afternoon hours rather than expanded. The administrator has not compared how many students may stop coming earlier with how many additional students may come later.

Which one of the following is an assumption the administrator’s argument requires?

- **(A)** The library’s evening lighting is more economical than its afternoon lighting.
- **(B)** The proposed schedule will add more student visits than it eliminates through shorter afternoon hours.
- **(C)** No student visits the library more than once in a week.
- **(D)** The survey respondents have all checked out library books.
- **(E)** Students will always prefer evening library visits to afternoon visits.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The new hours increase total student library use.
2. **Support.** Prospective new evening users are counted, but losses from reduced afternoons are omitted.
3. **Prephrase.** Net gains must exceed displaced or lost visits for a total increase.
4. **Why (B) is right.** (B) is necessary: if losses equal or exceed gains, aggregate visits do not rise.
5. **Why the others fail.**
   - **(A)** Cost distraction: operating efficiency does not prove more student use.
   - **(C)** Unique-visitor shell game: repeat visits do not settle the net count.
   - **(D)** Survey-status trap: borrowing books is irrelevant to the visit forecast.
   - **(E)** Extreme preference: some may still favor afternoons without harming the net argument.

**Check:** Negate (B): gains do not exceed losses, so increased total student visits cannot follow.
::::
:::

:::problem[Question I.23]
An airport manager argues that whenever a departure is delayed at Gate 4, a ground-service warning appears on the operations screen. This morning a ground-service warning appeared, so the manager concludes that a departure at Gate 4 must have been delayed. The screen can also issue such warnings for activities unrelated to a delay at that gate, but the manager treats the warning as conclusive proof. The manager adds that ground-service warnings are uncommon and so sees little reason to consult the separate gate-departure record before announcing the delay.

Which one of the following arguments contains a flaw most similar to the one above?

- **(A)** No closed store admits shoppers; this store admitted shoppers; therefore it was not closed.
- **(B)** If a permit expires, its holder receives a notice; Pilar received no notice; therefore her permit did not expire.
- **(C)** Every winning ticket bears a serial number; this ticket has no serial number; therefore it cannot win.
- **(D)** Some orchids grow indoors; these are orchids; therefore they grow indoors.
- **(E)** All licensed vendors paid an application fee; Ren paid the fee; therefore Ren must be licensed.

::::solution[Solution]
**Answer:** (E)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The warning is treated as sufficient to prove a delayed departure.
2. **Support.** Delay -> warning; warning -> delay is the invalid converse, affirming the consequent.
3. **Prephrase.** Find another argument that infers the antecedent from its consequent.
4. **Why (E) is right.** (E) matches the fallacy: licensed -> paid, paid -> licensed.
5. **Why the others fail.**
   - **(A)** Valid rule use: shoppers admitted contradicts being closed.
   - **(B)** Valid contrapositive: no notice entails no expiry if expiry implies notice.
   - **(C)** Valid contrapositive: no serial number entails no win if wins require numbers.
   - **(D)** Quantifier error: from “some” orchids to this orchid, not the same converse conditional.

**Check:** Both stimulus and (D) have P -> Q, Q, therefore P (invalid).
::::
:::

:::problem[Question I.24]
A city preservation board argues that restoring a closed railway depot will lead visitors to spend more money at nearby shops. The board points out that two previously restored depots in other towns experienced increased foot traffic. A critic observes that foot traffic alone does not demonstrate retail spending, and that both earlier depots opened beside existing tourist attractions. The board seeks evidence connecting restoration to spending at the specific location proposed, rather than merely to the number of people passing through it.

Which one of the following, if true, most strengthens the board’s prediction?

- **(A)** The depot’s roof can be repaired with materials similar in appearance to the originals.
- **(B)** A survey found that visitors to restored depots were willing to visit shops near the depot.
- **(C)** The two earlier towns’ shops were already profitable before the depots reopened.
- **(D)** A comparable depot restoration increased purchases at adjacent shops relative to similar shops not near a restored depot, despite no other nearby tourist development.
- **(E)** Restoration grants are available for buildings that meet certain standards.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Depot restoration will increase nearby retail spending.
2. **Support.** Prior foot-traffic growth is confounded by tourist attractions and unconnected to spending.
3. **Prephrase.** Seek comparative purchasing data isolated from other tourist changes.
4. **Why (D) is right.** (D) supplies the missing spending outcome and a reasonable comparison.
5. **Why the others fail.**
   - **(A)** Repair material aesthetics do not address changes in shops’ sales.
   - **(B)** Intention-versus-spending trap: stated willingness to visit a shop is not evidence that purchases rose.
   - **(C)** Past profitability does not show any incremental spending from restoration.
   - **(E)** Grant eligibility concerns financing, not spending by nearby shoppers.

**Check:** Purchasing changes at treated shops versus controls bear directly on the board’s claim.
::::
:::

:::problem[Question I.25]
A volunteer rescue organization requires a current navigation certificate before any pilot may coordinate a search flight. All pilots with current navigation certificates have passed the organization's map-reading evaluation. Mara passed that evaluation last month and has logged many hours of supervised practice. The coordinator concludes that Mara qualifies to coordinate a search flight. Yet passing the evaluation is not by itself stated to confer a current certificate, and the practice hours may or may not satisfy other organizational requirements.

Which one of the following, if assumed, allows the coordinator’s conclusion to be properly drawn?

- **(A)** Most pilots who pass the evaluation eventually earn current navigation certificates.
- **(B)** Mara’s practice hours exceeded those of some already qualified pilots.
- **(C)** Every pilot who passed the map-reading evaluation last month and logged at least as many supervised hours as Mara qualifies to coordinate a search flight.
- **(D)** The organization administers the evaluation several times each year.
- **(E)** All pilots qualified to coordinate a flight have passed a map-reading evaluation.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Mara qualifies to coordinate flights.
2. **Support.** Given premises do not turn passing the evaluation and practice into actual qualification.
3. **Prephrase.** Supply a rule sufficient for Mara’s specific facts to entail qualification.
4. **Why (C) is right.** (C) applies directly to Mara and explicitly guarantees the target status.
5. **Why the others fail.**
   - **(A)** Most-versus-all trap: a statistical tendency cannot guarantee Mara qualifies.
   - **(B)** Comparison trap: more hours than some qualified pilots does not imply equal eligibility.
   - **(D)** Administrative detail: evaluation frequency is unrelated to current qualifications.
   - **(E)** Converse trap: qualified -> passed does not permit passed -> qualified.

**Check:** Mara meets both antecedents in (D), so modus ponens yields qualification.
::::
:::

## 36.2 Section II: Reading Comprehension

### Passage 1

A product can injure a consumer even when it works exactly as its manufacturer anticipated. Consider a hypothetical countertop heater whose exposed metal surface becomes dangerously hot during ordinary use. The manufacturer might provide a prominent warning, reduce the accessible temperature through redesign, or both. These responses address related but distinct questions: whether users were adequately informed of a risk and whether the product ought to have been designed to reduce that risk in the first place. Confusing those questions can make an apparently clear safety judgment less precise.

One approach to product-liability analysis treats the warning and the physical design as parts of a single practical assessment. On this view, a highly conspicuous warning can reduce the expected harm because some users will alter their behavior. A redesign, meanwhile, might be expensive, might diminish the product's function, or might introduce different hazards. The appropriate response depends on the interaction between the product's usefulness, feasible alternatives, and how users are likely to respond to information. Supporters of this approach argue that the most important issue is the overall configuration of safety measures, rather than whether an individual measure belongs in a particular conceptual category.

A second approach argues that the categories must not be collapsed. A warning can inform a consumer that a hot surface exists, but it cannot necessarily protect a person who must touch the surface in order to operate the product. If a feasible guard would prevent burns without substantially impairing use, its omission may remain problematic despite an excellent warning. Moreover, relying too heavily on warnings could shift the burden of avoiding a preventable danger onto users who have no control over design choices. The point is not that warnings are worthless. Rather, the fact that information is helpful should not automatically settle a separate question about reducing the hazard itself.

The difference becomes less abstract in a case involving two groups of users. Suppose one group operates the heater occasionally, with time to read and follow every instruction, whereas another routinely moves it in a crowded workspace. An improved warning might benefit the first group considerably while having much less effect on the second, whose tasks require quick physical contact. A redesigned insulated handle could help both groups. Yet a handle that obstructed the heater's essential function might create another safety tradeoff. None of these possibilities can be resolved by stating simply that the product either has a warning or lacks one.

A useful analysis therefore distinguishes the informational and design questions before considering how their answers interact. That distinction does not dictate a verdict in every hypothetical lawsuit; it requires decision makers to specify what an offered precaution can actually accomplish. An excellent warning can be relevant without being a substitute for a practicable physical safeguard. Conversely, a proposed redesign should not be deemed desirable merely because it is possible. The evaluative task is to identify which hazard each measure addresses and what costs or limitations accompany it.

:::problem[Question II.1]
The main point of the passage is that...

- **(A)** warnings should always be legally irrelevant when a product could be redesigned.
- **(B)** a manufacturer’s duty to warn is the only useful measure of product safety.
- **(C)** the costs of safeguards generally outweigh the benefits of redesign.
- **(D)** warning adequacy and design safety should be distinguished, then evaluated together in relation to the hazards each addresses.
- **(E)** Physical redesign will usually be more effective than information when products are used under time pressure.

::::solution[Solution]
**Answer:** (D)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author recommends distinct initial analysis of warnings and designs, followed by attention to their interaction.
2. **Support.** Paragraphs two and three contrast approaches; the final paragraph states the nuanced synthesis.
3. **Prephrase.** Choose a thesis that preserves both separation and practical interaction.
4. **Why (D) is right.** (D) covers the whole discussion without pretending either safety measure always wins.
5. **Why the others fail.**
   - **(A)** Absolute overstatement: the author expressly says warnings can remain relevant.
   - **(B)** One-category trap: design safety is an independent question.
   - **(C)** Unsupported generalization: tradeoffs matter, but costs do not generally dominate.
   - **(E)** Narrow-example extrapolation: the workplace scenario does not establish a general comparison across products.

**Check:** Opening distinction + final synthesis jointly support (D).
::::
:::

:::problem[Question II.2]
The hypothetical crowded-workspace example serves primarily to...

- **(A)** suggest that time pressure, rather than the product’s physical design, is the sole cause of burn injuries.
- **(B)** show why warning effectiveness may vary by user context even when the underlying product is unchanged.
- **(C)** establish that an insulated handle would be the preferable safety measure regardless of how it affected the heater’s function.
- **(D)** illustrate that a warning is most helpful to the group that handles the heater most frequently.
- **(E)** show that providing any warning about the heater settles the design question for occasional users.

::::solution[Solution]
**Answer:** (B)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The example illustrates different effects of a warning and a possible design modification.
2. **Support.** One group can readily attend to instructions; another has less opportunity for them.
3. **Prephrase.** Locate the example’s contribution to the warnings-versus-design distinction.
4. **Why (B) is right.** (B) precisely describes context-dependent usefulness without overclaiming.
5. **Why the others fail.**
   - **(A)** Single-cause trap: time pressure limits warning effectiveness but does not eliminate design-related risk.
   - **(C)** Tradeoff omission: the passage expressly notes that a badly positioned handle may impair function.
   - **(D)** Group reversal: the frequent users have less time to act on warnings than occasional users.
   - **(E)** Overextension: occasional users may benefit from warnings, but that does not settle whether a guard is feasible.

**Check:** Contrast the two groups: the warning’s expected effect differs.
::::
:::

:::problem[Question II.3]
According to the second approach described in the passage, a prominent warning...

- **(A)** can be helpful without resolving whether the design should reduce the physical hazard.
- **(B)** can protect a user required to touch a hot surface as completely as a feasible physical guard.
- **(C)** should generally be disregarded whenever designers can imagine any physical alternative.
- **(D)** should be assessed without regard to whether consumers can avoid touching the hazard.
- **(E)** settles the question of design safety whenever the label describes the hot surface accurately.

::::solution[Solution]
**Answer:** (A)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question asks for the second approach’s explicit claim.
2. **Support.** Paragraph three says a warning can inform while failing to protect a user who must touch a hazard.
3. **Prephrase.** Keep information and physical protection conceptually separate.
4. **Why (A) is right.** (A) paraphrases the passage’s central warning/design distinction.
5. **Why the others fail.**
   - **(B)** Equivalence overclaim: a warning may not prevent unavoidable physical contact.
   - **(C)** Possible-versus-feasible trap: the approach accepts warnings and assesses workable safeguards.
   - **(D)** Relevant-condition omission: required contact is essential to assessing a warning’s limits.
   - **(E)** Substitution trap: clear information does not eliminate the need to consider unavoidable contact.

**Check:** Paragraph three directly supports (C).
::::
:::

:::problem[Question II.4]
Which one of the following can most reasonably be inferred about the author’s view of the first approach?

- **(A)** It requires eliminating all useful functions from dangerous products.
- **(B)** It is incoherent because warnings never affect behavior.
- **(C)** It entirely ignores the costs of alternative designs.
- **(D)** It is legally mandatory in all product-injury disputes.
- **(E)** It recognizes important tradeoffs but risks obscuring a distinct question about preventable hazards if used without further separation.

::::solution[Solution]
**Answer:** (E)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The author credits practical interaction while insisting distinct questions retain value.
2. **Support.** Paragraph two articulates the integrated approach; paragraph five refines it rather than discarding it.
3. **Prephrase.** Expect qualified acceptance with a caution about collapsing categories.
4. **Why (E) is right.** (E) matches the qualified criticism and reconciliatory ending.
5. **Why the others fail.**
   - **(A)** Straw man: tradeoffs explicitly preserve useful function.
   - **(B)** Denial trap: warning-induced behavior change is explicitly acknowledged.
   - **(C)** Opposite detail: cost is a stated element of the first approach.
   - **(D)** External-law overreach: no binding jurisdiction rule is asserted.

**Check:** The final paragraph says distinguish first, then consider interaction.
::::
:::

:::problem[Question II.5]
Which one of the following new findings would most directly strengthen a design-based concern in the author’s hypothetical heater case?

- **(A)** A revised warning causes occasional users to change their grip before touching the heater.
- **(B)** The occasional users can recite the warning from memory.
- **(C)** A low-cost insulated grip prevents burns during required handling without impairing the heater’s function.
- **(D)** A proposed protective grip obstructs one of the heater’s essential controls.
- **(E)** Customers say they would pay more for a heater with a visually distinctive handle.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** A design concern depends on whether a practical physical safeguard addresses an injury risk.
2. **Support.** Paragraph three posits a feasible guard; paragraph four considers a handle and functional tradeoffs.
3. **Prephrase.** Supply evidence of both hazard reduction and practicability.
4. **Why (C) is right.** (C) establishes a concrete prevention advantage with few countervailing functional costs.
5. **Why the others fail.**
   - **(A)** Warning-side benefit: safer behavior does not establish whether a missing guard would reduce required-contact injuries.
   - **(B)** Memory trap: recall does not reduce risk from unavoidable handling.
   - **(D)** Countervailing feasibility finding: obstructing controls weakens rather than strengthens a case for redesign.
   - **(E)** Preference-versus-safety trap: willingness to pay for appearance does not establish burn prevention.

**Check:** (B) addresses feasibility, prevention, and functional limitation together.
::::
:::

:::problem[Question II.6]
The author’s attitude toward warning labels is best described as...

- **(A)** qualified approval, accompanied by concern that warnings not be treated as substitutes for every feasible safeguard.
- **(B)** unreservedly enthusiastic, since warnings eliminate design obligations.
- **(C)** indifferent, since the passage concerns only costs.
- **(D)** hostile toward the use of instructions by consumers.
- **(E)** dismissive, since warnings shift every danger to users.

::::solution[Solution]
**Answer:** (A)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author sees genuine informational value but rejects automatic substitution for design.
2. **Support.** The conclusion explicitly states that warnings can be relevant without being sufficient.
3. **Prephrase.** Match a balanced tone, not an extreme evaluation.
4. **Why (A) is right.** (A) preserves both the positive and limiting aspects.
5. **Why the others fail.**
   - **(B)** Overstatement in the other direction: design questions remain.
   - **(C)** Wrong focus: safety functions, not just costs, dominate.
   - **(D)** Invented hostility: no objection to consumers reading instructions is voiced.
   - **(E)** Overstatement: warnings are acknowledged as helpful.

**Check:** “Relevant without being a substitute” captures the stance.
::::
:::

:::problem[Question II.7]
Which one of the following best describes the passage’s organization?

- **(A)** An empirical experiment is presented, then its numerical results are recalculated.
- **(B)** A proposal to ban an appliance is supported by eyewitness reports.
- **(C)** A legal holding is quoted, then reversed by a later court.
- **(D)** An initial distinction is followed by competing analyses, an illustrative hypothetical, and a qualified synthesis.
- **(E)** A historical chronology of manufacturing techniques leads to a technical manual.

::::solution[Solution]
**Answer:** (D)

**Type:** RC structure (Chapter 18)

1. **Conclusion.** The author’s overall structure is comparative analysis followed by synthesis.
2. **Support.** Paragraph one frames two questions; two and three compare perspectives; four illustrates; five concludes.
3. **Prephrase.** Identify the sequence of rhetorical moves, not merely the topic.
4. **Why (D) is right.** (D) matches every major part in the correct order.
5. **Why the others fail.**
   - **(A)** No dataset: examples are hypothetical and unquantified.
   - **(B)** Policy invention: no appliance ban is proposed.
   - **(C)** Fabricated case law: no holding or court appears.
   - **(E)** Genre mismatch: the passage offers analysis, not history or a manual.

**Check:** The paragraph map exactly matches (C).
::::
:::

### Passage 2

Conservation planners sometimes draw a narrow corridor between two woodland patches on a map and label the result a connection. But a line that connects habitats geometrically need not connect the ecological processes that allow a population to persist. The relevant question is not merely whether an animal can cross the corridor. It is also whether the movement results in dispersal, reproduction, or other exchanges that matter over successive generations. A corridor may look continuous to a surveyor while remaining inhospitable to the organisms it is intended to serve.

For plants that depend on animals to transport seeds, this distinction is particularly important. A bird may travel from one woodland patch to another yet deposit few seeds along the way. Conversely, it may carry seeds into a patch where exposed soil, competition, or browsing prevents seedlings from surviving. Counting animal crossings or seeds found in traps is therefore a measure of one stage in a process, not a complete measure of successful plant recruitment. A project can improve movement without producing the intended increase in established plants.

Imagine a hypothetical restoration project with two potential corridor designs. One design is a short, straight band of young trees that minimizes travel distance. Another is a longer, irregular band containing shaded resting sites and a more varied understory. The straight corridor might support frequent passage by one seed-carrying species, whereas the irregular corridor might favor another species that pauses in shaded cover. Which design better aids plant recruitment cannot be determined solely by measuring corridor length or the total number of animals photographed. The animals' seed loads, behavior, and the conditions where seeds are deposited all matter.

A related problem concerns the timescale of evaluation. In the first season after construction, a planner might detect many animals using a corridor and celebrate success. Seedlings may appear in the first growing season yet die before becoming established plants. Estimating recruitment may require observations over several seasons, and changes in plant populations may emerge slowly. Monitoring only the initial movement response risks confusing an early mechanism with the final ecological objective. Yet this objection does not justify postponing all judgment until the distant future. Short-term movement data can be useful if researchers specify what such data measure and what additional evidence remains necessary.

The most informative evaluation would therefore combine several observations: which animals traverse the corridor, whether they carry and deposit seeds, and whether plants become established at destination sites. These observations need not all be collected with equal intensity at every location. A practical program might use intensive follow-up at selected sites to interpret simpler movement counts collected more widely. Such a design would not guarantee restoration success. It would, however, prevent a convenient intermediate measure from being mistaken for the outcome the corridor was constructed to achieve.

:::problem[Question II.8]
The author’s primary purpose is to...

- **(A)** trace changes in corridor vegetation during one hypothetical restoration project.
- **(B)** argue that habitat corridors should never be used in conservation.
- **(C)** identify why movement counts alone cannot establish restoration success and propose a more informative evaluation.
- **(D)** show that straight corridors are always inferior to irregular corridors.
- **(E)** document the migration of a named bird species over several centuries.

::::solution[Solution]
**Answer:** (C)

**Type:** RC primary purpose (Chapter 18)

1. **Conclusion.** The purpose is to qualify the meaning of corridor “success” and propose staged evidence.
2. **Support.** The author repeatedly distinguishes movement, deposition, and recruitment, then recommends combining measures.
3. **Prephrase.** Use a purpose verb describing critique and improved assessment.
4. **Why (C) is right.** (C) covers the diagnosis and proposed evaluation.
5. **Why the others fail.**
   - **(A)** Scope trap: examples support a general critique of evaluation, not a report on vegetation changes.
   - **(B)** Absolute rejection: the author accepts corridor projects, questioning their evaluation.
   - **(D)** Unwarranted ranking: design merits depend on species and outcomes.
   - **(E)** Historical detail invention: no named species or centuries are discussed.

**Check:** Final paragraph offers the multi-stage method promised by the earlier critique.
::::
:::

:::problem[Question II.9]
According to the passage, a count of animals crossing a corridor may fail to indicate plant recruitment because...

- **(A)** all animal species avoid crossing wooded corridors.
- **(B)** some crossings do not result in seed deposition or successful seedling establishment.
- **(C)** different seed-carrying animals may prefer corridors with different vegetation structures.
- **(D)** birds using the corridor sometimes pause to feed at resting sites before continuing to the next patch.
- **(E)** crossing counts do not distinguish repeated passages by one bird from visits by different birds.

::::solution[Solution]
**Answer:** (B)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The author says crossing is an intermediate process, not the target outcome.
2. **Support.** Paragraph two separates travel, deposit, and subsequent survival.
3. **Prephrase.** Look for the missing causal links after crossing.
4. **Why (B) is right.** (B) names both possible breaks in the sequence.
5. **Why the others fail.**
   - **(A)** Universal denial contradicts the discussion of actual crossings.
   - **(C)** Design-comparison distraction: habitat preference alone does not establish the crossing-to-recruitment gap.
   - **(D)** Behavioral detail: resting during travel does not by itself show that seed deposition or establishment failed.
   - **(E)** Measurement distinction: uniqueness might matter, but the passage’s explicit failure links are deposition and seedling survival.

**Check:** Movement -> possible transport -> possible deposition -> possible establishment; later links may fail.
::::
:::

:::problem[Question II.10]
The third paragraph most strongly suggests that corridor design should be assessed...

- **(A)** by choosing the band with the largest area on a map.
- **(B)** without regard to whether seeds can establish at destinations.
- **(C)** only after every species has been monitored for a century.
- **(D)** solely according to whichever route minimizes travel distance.
- **(E)** in relation to the particular organisms and ecological outcomes a project seeks to support.

::::solution[Solution]
**Answer:** (E)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** No design can be called superior without target-specific evidence.
2. **Support.** The two designs favor different behavior, and recruitment requires more than crossings.
3. **Prephrase.** Infer a context-dependent, outcome-focused design criterion.
4. **Why (E) is right.** (E) generalizes the example without claiming a universal best shape.
5. **Why the others fail.**
   - **(A)** Map-area substitute: no evidence equates map area with recruitment.
   - **(B)** Endpoint omission: establishment is the passage’s concern.
   - **(C)** Overextended timescale: no century-long universal requirement is given.
   - **(D)** Single-metric trap: shortest distance is explicitly insufficient.

**Check:** Different species favor different corridors, so design adequacy is goal-dependent.
::::
:::

:::problem[Question II.11]
The author’s view of early animal-movement data is best described as...

- **(A)** skeptical of the motives of all researchers collecting such data.
- **(B)** indifferent to any measurements made before several decades pass.
- **(C)** critical of using early counts as proof that a corridor has already met its long-term goals.
- **(D)** unwilling to draw any preliminary conclusions until seedling survival is confirmed over several seasons.
- **(E)** supportive of their limited use, provided they are not mistaken for long-term ecological outcomes.

::::solution[Solution]
**Answer:** (E)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** Early measures are useful proxies only with explicit limitations.
2. **Support.** Paragraph four warns against premature success claims but says short-term data can be useful.
3. **Prephrase.** Choose a balanced position acknowledging information and limits.
4. **Why (E) is right.** (E) restates the precise qualification.
5. **Why the others fail.**
   - **(A)** Motive invention: the author critiques inference, not honesty.
   - **(B)** Timescale distortion: the author expressly permits early judgment.
   - **(C)** Half-right but incomplete: the author criticizes that use while still endorsing the data for narrower purposes.
   - **(D)** Overcorrection: the author permits useful provisional judgments from early measurements.

**Check:** “Useful if researchers specify what such data measure” supports (E).
::::
:::

:::problem[Question II.12]
Which one of the following findings would most clearly demonstrate the particular limitation of seed-trap data discussed in the passage?

- **(A)** The shortest potential corridor would cross a road.
- **(B)** A corridor contains several species of young trees.
- **(C)** Many seeds enter the destination patch, but almost no seedlings survive to become established plants.
- **(D)** Birds cross a corridor frequently but deposit very few seeds in the destination patch.
- **(E)** More seeds are deposited in the corridor during its first season than in its second.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** Seed arrival is not the same outcome as recruitment.
2. **Support.** Paragraph two states seeds can be deposited where conditions prevent seedlings from surviving.
3. **Prephrase.** Look for seed deposition followed by failure at a later stage.
4. **Why (C) is right.** (C) specifically separates trapped or deposited seeds from established plants.
5. **Why the others fail.**
   - **(A)** Route concern: a road is a design constraint, not evidence of recruitment failure.
   - **(B)** Vegetation description: tree variety alone does not test deposition versus recruitment.
   - **(D)** Wrong proxy stage: this challenges crossing counts, whereas the question specifically targets the limits of seed-deposition data.
   - **(E)** Change-in-count trap: varying deposition does not by itself demonstrate that deposited seeds failed to establish.

**Check:** Many deposits with few established plants expose the proxy-outcome gap.
::::
:::

:::problem[Question II.13]
The discussion of first-season corridor use primarily serves to...

- **(A)** argue that any animal count obtained within a year must be inaccurate.
- **(B)** introduce the possibility that a process can be observed before its intended long-term consequence can be assessed.
- **(C)** prove that no seedlings can survive during the first season.
- **(D)** replace the need for monitoring with the judgment of a surveyor.
- **(E)** claim that all corridors eventually fail to support plants.

::::solution[Solution]
**Answer:** (B)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The paragraph adds a temporal mismatch to the earlier mechanistic mismatch.
2. **Support.** Movement may rise quickly, while establishment may become apparent over several seasons.
3. **Prephrase.** Identify the paragraph’s new reason intermediate measures can mislead.
4. **Why (B) is right.** (B) captures the time-lag function without asserting inevitable failure.
5. **Why the others fail.**
   - **(A)** Accuracy misreading: valid movement counts can still be incomplete.
   - **(C)** Absolute claim: some seedlings may survive; the issue is demonstrating establishment.
   - **(D)** Contradiction: the paragraph advocates clarified monitoring.
   - **(E)** Unwarranted generalization: nothing says every corridor fails.

**Check:** The passage distinguishes early response from the later target outcome.
::::
:::

:::problem[Question II.14]
Which one of the following best describes the reasoning in the final paragraph?

- **(A)** It recommends combining measures along a causal sequence, with intensive sampling at selected sites to interpret broader observations.
- **(B)** It argues that only the most expensive available monitoring can be trusted.
- **(C)** It reduces the ecological goal to increased animal movement.
- **(D)** It proposes replacing corridor projects with unrelated conservation activities.
- **(E)** It dismisses all earlier measurements as fabricated.

::::solution[Solution]
**Answer:** (A)

**Type:** RC structure (Chapter 18)

1. **Conclusion.** The conclusion recommends a practical layered monitoring design.
2. **Support.** It lists crossing, transport/deposition, and establishment and allows uneven sampling intensity.
3. **Prephrase.** Capture the combined observation plan and its practicality constraint.
4. **Why (A) is right.** (A) contains both the multi-stage measures and selective intensive follow-up.
5. **Why the others fail.**
   - **(B)** Expense extreme: the author explicitly allows selective sampling.
   - **(C)** Endpoint reversal: established plants remain the target.
   - **(D)** Policy replacement trap: the author assesses corridors rather than abandoning them.
   - **(E)** Credibility trap: the issue is inference, not fabrication.

**Check:** The final paragraph itself names all components of (D).
::::
:::

### Passage 3 (comparative)

**Passage A**

Educational researchers often describe prompt feedback as effective because students can correct a mistaken procedure before they practice it repeatedly. That observation is useful, but it risks defining effectiveness too narrowly. Imagine a hypothetical study in which two groups solve arithmetic problems. The first group receives a correction after each response; the second receives a summary after completing the set. On a test given immediately afterward, the first group performs better. It would be tempting to conclude that prompt feedback is superior in general, yet the result establishes only an immediate advantage under those study conditions.

To judge whether feedback supports durable learning, the researchers should also use a delayed assessment containing problems that differ in surface features from the training exercises. If immediate feedback produces high scores mainly because learners imitate the latest correction, the apparent benefit may shrink on that later transfer test. Conversely, the benefit may persist, in which case a stronger case for prompt feedback emerges. The point is methodological: the time and form of the assessment help determine what the experiment demonstrates. “Better learning” cannot be read directly from one narrowly timed score. For the limited question of which schedule produces more durable learning, a suitably designed delayed transfer test can settle the comparison without separate observations about students’ interpretations. Such observations might be informative but are not necessary to judge that result.

**Passage B**

Discussions of feedback timing too often treat students as if they encounter a correction in isolation. In a classroom, a message delivered immediately after an error may be interpreted as a hint, an evaluation, or an interruption. The student’s response can depend on what the teacher has said about mistakes, whether classmates are present, and whether the student is expected to revise independently. For this reason, two classrooms can implement an identical schedule of comments without giving students an equivalent learning experience.

Consider a hypothetical writing class in which students receive margin comments as soon as they finish each paragraph. One teacher asks students to explain how they used those comments; another simply asks them to continue writing. A later revision exercise may reveal substantial differences between the classes, even though both technically used immediate feedback. Researchers should therefore report not only when comments arrive but also what students do with them. Delayed tests can be valuable, yet a delayed score alone will not reveal whether students understood, resisted, or merely copied the guidance they received.

A useful account of feedback should connect the timing of information to the social practices through which students interpret and apply it. Without that context, a study can give a precise answer to a poorly specified question. Even if a delayed score favors one schedule, that result alone is insufficient to establish which schedule produces more durable learning. A student might reproduce a rehearsed response without independently applying the relevant principle.

:::problem[Question II.15]
Both authors would most likely agree that...

- **(A)** delayed assessments are always sufficient to identify the mechanism of learning.
- **(B)** feedback should be withheld from every struggling student.
- **(C)** only immediate scores can show whether feedback works.
- **(D)** a study of feedback can be misleading if its measures omit important aspects of what students learn or do.
- **(E)** the timing of feedback can be studied without considering what learners do afterward.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative agreement (Chapter 17)

1. **Conclusion.** The common ground is concern about what a narrow observation leaves out.
2. **Support.** A demands delayed transfer; B demands attention to uptake and classroom practice.
3. **Prephrase.** Find a cautious methodological overlap, not either author’s unique emphasis.
4. **Why (D) is right.** (D) allows both authors’ specific objections to narrow measures.
5. **Why the others fail.**
   - **(A)** B explicitly says delayed scores alone can be insufficient.
   - **(B)** Policy invention: neither advocates withholding all feedback.
   - **(C)** Both reject narrow immediate-performance criteria.
   - **(E)** Opposite of B: interpretation and activity are B’s core concern.

**Check:** Both criticize inference from an underspecified measure to “effective feedback.”
::::
:::

:::problem[Question II.16]
On which one of the following questions would the authors be most likely to differ?

- **(A)** Whether corrections can be expressed in words.
- **(B)** Whether adding a delayed transfer test, without observing how students interpret feedback, adequately addresses the central limitation of an immediate-score study.
- **(C)** Whether feedback can ever be delivered immediately.
- **(D)** Whether arithmetic and writing are both taught in schools.
- **(E)** Whether classroom circumstances can influence how students react to a comment.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative disagreement (Chapter 17)

1. **Conclusion.** A treats delayed transfer as the crucial additional test; B denies a delayed score alone addresses student interpretation.
2. **Support.** Both value stronger evidence, but B presses beyond A’s main recommended extension.
3. **Prephrase.** Seek a claim A would tend to endorse as the key remedy and B would find insufficient.
4. **Why (B) is right.** (B) exposes that difference in what counts as an adequate fix.
5. **Why the others fail.**
   - **(A)** Irrelevant triviality: neither questions verbal corrections.
   - **(C)** Both presuppose immediate feedback is possible.
   - **(D)** Trivial background: neither contests subject teaching.
   - **(E)** One-sided claim: B affirms it, but A does not deny it, so no established disagreement.

**Check:** A emphasizes delayed transfer; B expressly says delayed scores alone are insufficient.
::::
:::

:::problem[Question II.17]
How would the author of Passage B most likely respond to Passage A’s proposed delayed transfer assessment?

- **(A)** It should be rejected because delayed performance can never be measured.
- **(B)** It proves that social context has no effect on students.
- **(C)** It could test persistence of a score advantage, but it would make observations of students’ use of feedback unnecessary.
- **(D)** It would make it unnecessary to record when feedback was delivered.
- **(E)** It would add useful evidence about durability, but it would not by itself show how classroom practices shaped students’ use of feedback.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative response (Chapter 17)

1. **Conclusion.** B acknowledges delayed tests but wants evidence of interpretation and activity.
2. **Support.** B’s final paragraph expressly states that a delayed score alone will not identify student uptake.
3. **Prephrase.** Express qualified endorsement with a demand for context.
4. **Why (E) is right.** (E) is exactly that qualified response.
5. **Why the others fail.**
   - **(A)** Absolute dismissal: B calls delayed tests valuable.
   - **(B)** Opposite: context is B’s central argument.
   - **(C)** Partial-concession trap: B values the delayed measure but specifically rejects discarding interpretation evidence.
   - **(D)** Timing omission: B says report when comments arrive and what learners do.

**Check:** B explicitly grants value to delayed tests while identifying their remaining gap.
::::
:::

:::problem[Question II.18]
In the hypothetical arithmetic study in Passage A, the immediate assessment...

- **(A)** was administered several months after the training.
- **(B)** tested only student attitudes toward teachers.
- **(C)** was identical to the independent revision exercise in Passage B.
- **(D)** showed the prompt-feedback group performed better under the study conditions.
- **(E)** showed the delayed-feedback group performed better.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question asks for a fact stipulated by Passage A.
2. **Support.** A explicitly says the first, promptly corrected group scored higher immediately afterward.
3. **Prephrase.** Keep the time and direction of the comparison intact.
4. **Why (D) is right.** (D) correctly identifies the outcome while limiting it to that assessment.
5. **Why the others fail.**
   - **(A)** Timing reversal: the assessment was immediate.
   - **(B)** Outcome swap: the test assessed arithmetic performance.
   - **(C)** Cross-passage shell game: the writing revision exercise is in B.
   - **(E)** Direction reversal: the first group, not the second, did better.

**Check:** Passage A first paragraph directly supports (B).
::::
:::

:::problem[Question II.19]
Which one of the following best characterizes the relationship between the passages?

- **(A)** A explains why teachers should stop correcting mistakes; B explains why students should stop revising.
- **(B)** A examines the physical delivery of feedback; B discusses only its monetary cost.
- **(C)** A emphasizes the timing and transfer measures used to judge learning, whereas B emphasizes the interpretation and use of feedback in social context.
- **(D)** A argues feedback is always beneficial; B argues it is always harmful.
- **(E)** A reports a completed national experiment; B challenges its raw data.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** Both critique narrow studies of feedback, but prioritize different omitted dimensions.
2. **Support.** A focuses on delayed and varied tests; B on classroom practices and how guidance is taken up.
3. **Prephrase.** Contrast the scope and methodological concerns without inventing a direct contradiction.
4. **Why (C) is right.** (C) names their real difference in emphasis.
5. **Why the others fail.**
   - **(A)** Policy fabrication: neither urges ending correction or revision.
   - **(B)** Cost distraction: B does not focus on money.
   - **(D)** False opposition: neither gives an absolute good/bad verdict.
   - **(E)** Study-status invention: both examples are hypothetical.

**Check:** Dual map: A = assess durability; B = observe social interpretation.
::::
:::

:::problem[Question II.20]
Which one of the following research designs would best address the central concerns of both passages?

- **(A)** Compare feedback schedules using immediate and delayed transfer tests while also observing how students interpret and use the comments.
- **(B)** Ask students whether they appreciated their feedback and compare next-day scores on similar exercises.
- **(C)** Hold classroom context constant, compare immediate scores, and omit delayed testing.
- **(D)** Study how students explain feedback in class, but do not give delayed transfer assessments.
- **(E)** Compare delayed test scores under two feedback schedules without observing students’ interpretations.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative response (Chapter 17)

1. **Conclusion.** A requires durable transfer evidence; B requires observations of interpretation and use.
2. **Support.** The proposed combination must preserve a learning outcome and contextual uptake.
3. **Prephrase.** Select a design that satisfies both complementary methodological recommendations.
4. **Why (A) is right.** (A) includes varied delayed outcomes and observable student response.
5. **Why the others fail.**
   - **(B)** Satisfaction and short-term-performance proxies omit transfer and observed uptake.
   - **(C)** Immediate-outcome trap: control of context cannot replace A’s transfer measure.
   - **(D)** B-only design: it observes context but cannot evaluate the durability emphasized by A.
   - **(E)** A-only design: it uses delayed assessment but overlooks B’s social interpretation concern.

**Check:** (C) simultaneously operationalizes A’s transfer and B’s context conditions.
::::
:::

### Passage 4

A small mark in the margin of a medieval manuscript can seem almost incidental when compared with the carefully copied text beside it. Yet marginal annotations can reveal how a manuscript was used by readers and scribes after, or even during, its production. Some marks correct apparent errors; others point to a passage worth returning to; still others add comments whose relationship to the main text is uncertain. The temptation is to regard all such marks as interruptions of a finished work. That assumption makes the manuscript appear more stable, and its history of reading less visible, than it may actually have been.

Suppose an unnamed manuscript contains a poem copied in a formal hand, with several short notes along its outer edges. One note offers an alternative word, another identifies a recurring image, and a third asks a question about a character's motive. The notes need not have been written by a single person or at the same time. The alternative word could record an attempt to repair a copying error, but it might instead preserve a different reading of the poem. The question about motive could reflect disagreement, curiosity, or a classroom exercise. Simply classifying all three as errors would erase their variety.

There is also a danger in the opposite direction. A modern reader, eager to find evidence of lively debate, might treat every marginal question as a challenge to the poem's authority. But a question is not necessarily an objection. It might be an instruction to recite a passage, a prompt for remembering a familiar interpretation, or a note unrelated to the original copyist. Likewise, a smudged correction need not demonstrate censorship. Physical evidence can narrow possibilities, but marks whose authorship and timing cannot be established should not support elaborate stories about the motives of specific readers.

The placement of annotations can nevertheless be informative. Notes repeatedly positioned beside changes in speaker may suggest that a reader found shifts in voice difficult or important. A series of alternate words may invite comparison with another version of the poem, if one is available. These patterns do not settle who made the notes. They provide hypotheses that can be tested against handwriting differences, ink distribution, and the manuscript's other features. Even when such tests yield no conclusive identity, the annotations may still show that the page was an object of active interpretation rather than a passive container for text.

The strongest account of marginal writing therefore resists two simple pictures: that annotations are mere defects in an otherwise complete poem, and that they transparently record the private intentions of identifiable readers. The marks are evidence of engagement, but evidence requiring restraint. A manuscript's margins can complicate a literary history centered only on a finalized work, without allowing the researcher to claim every uncertainty has been solved. Attention to them is most productive when it expands the questions scholars can ask while preserving the difference between plausible interpretation and demonstrated fact.

:::problem[Question II.21]
Which one of the following best states the main point of the passage?

- **(A)** Annotations in medieval manuscripts are invariably copying mistakes.
- **(B)** The writer of a marginal note can always be identified from its placement.
- **(C)** Manuscript annotations can illuminate historical engagement with texts, but their significance requires cautious interpretation.
- **(D)** Uncertainty about the identity of annotators prevents their notes from contributing to literary interpretation.
- **(E)** Modern readers should ignore marginal annotations until every note has been dated.

::::solution[Solution]
**Answer:** (C)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author argues for investigating annotations without overinterpreting them.
2. **Support.** Paragraphs two through four illustrate kinds and limits of evidence; the last paragraph synthesizes.
3. **Prephrase.** Select a balanced statement of value and uncertainty.
4. **Why (C) is right.** (C) reflects both the positive and cautionary claims.
5. **Why the others fail.**
   - **(A)** Defect-only extreme: the author expressly rejects it.
   - **(B)** Identification overclaim: placement need not settle authorship.
   - **(D)** All-or-nothing error: the passage explicitly permits insight without established authorship.
   - **(E)** Overcautious rule: annotations can matter even when dating is unresolved.

**Check:** The final paragraph’s two rejected extremes leave the middle position in (C).
::::
:::

:::problem[Question II.22]
According to the second paragraph, an alternative word in a margin might...

- **(A)** provide a correction or preserve a different reading of the poem.
- **(B)** show that a reader was especially interested in the recurring image mentioned by the neighboring note.
- **(C)** indicate that the poem’s word choices were always corrected for performance rather than for copying accuracy.
- **(D)** demonstrate that the main poem lacks any deliberate imagery.
- **(E)** prove that the manuscript’s author personally approved the revision.

::::solution[Solution]
**Answer:** (A)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** The question asks what one type of note may signify.
2. **Support.** The second paragraph explicitly gives two possibilities for the alternative word.
3. **Prephrase.** Preserve ambiguity rather than treating one reading as certain.
4. **Why (A) is right.** (A) restates both possible functions.
5. **Why the others fail.**
   - **(B)** Neighboring-detail confusion: the image-identifying note is separate from the alternative-word note.
   - **(C)** Single-function overreach: the word might indicate multiple readings or repair, not only performance.
   - **(D)** Content reversal: recurring imagery is mentioned as identifiable.
   - **(E)** Authorship invention: the note is not attributed to the poem’s author.

**Check:** The words “could ... but ... instead” introduce the two interpretations in (D).
::::
:::

:::problem[Question II.23]
The third paragraph serves primarily to...

- **(A)** establish that physical examination of notes can conclusively distinguish censorship from other uses.
- **(B)** give chronological dates for the manuscript’s production.
- **(C)** prove that marginal questions were always intended as classroom exercises.
- **(D)** establish that every correction was written by a censor.
- **(E)** offer a counterweight to the earlier warning against dismissing annotations, by warning against overreading them.

::::solution[Solution]
**Answer:** (E)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The author introduces the converse danger of too enthusiastic an interpretation.
2. **Support.** Paragraph one critiques treating marks as defects; three cautions against reading every mark as dissent.
3. **Prephrase.** Identify the balancing rhetorical move.
4. **Why (E) is right.** (E) correctly captures the shift from neglect to overinterpretation.
5. **Why the others fail.**
   - **(A)** Certainty trap: the paragraph specifically says smudged marks do not prove censorship.
   - **(B)** Missing dates: none are given.
   - **(C)** Possibility-to-rule trap: classroom exercise is only one possible function.
   - **(D)** Fabrication: censorship is cited as an unjustified leap.

**Check:** “There is also a danger in the opposite direction” signals the function.
::::
:::

:::problem[Question II.24]
If an anonymous manuscript contains many notes beside changes in speaker, the passage most strongly suggests that...

- **(A)** any interpretation of the poem’s speakers would be invalid.
- **(B)** the annotator probably objected to the poet’s handling of every shift in voice.
- **(C)** the manuscript was copied exclusively for theatrical performance.
- **(D)** the notes may indicate attention to changes in voice, although they do not establish who wrote them.
- **(E)** all the notes were necessarily written at the same time.

::::solution[Solution]
**Answer:** (D)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** The pattern supports a hypothesis about attention, not an identity claim.
2. **Support.** Paragraph four describes precisely this example and its inferential limits.
3. **Prephrase.** Choose the modest functional inference and preserve uncertain authorship.
4. **Why (D) is right.** (D) tracks the example’s explicit caution.
5. **Why the others fail.**
   - **(A)** Overreaction: observations can generate hypotheses without invalidating readings.
   - **(B)** Motive leap: attention to a feature does not establish a hostile attitude or universal objection.
   - **(C)** Genre invention: no performance context is established.
   - **(E)** Timing overreach: annotations need not be contemporaneous.

**Check:** Paragraph four directly distinguishes focus of attention from authorship.
::::
:::

:::problem[Question II.25]
Which one of the following research practices would best fit the author’s recommendations?

- **(A)** Treat every marginal correction as proof that the original poem was censored.
- **(B)** Compare ink and handwriting across notes, state multiple plausible functions, and distinguish supported findings from conjecture.
- **(C)** Ignore the margins because the main text is more carefully copied.
- **(D)** Attribute all notes to a famous scholar whenever their handwriting looks neat.
- **(E)** Infer a note’s motive exclusively from its location on the page.

::::solution[Solution]
**Answer:** (B)

**Type:** RC application (Chapter 18)

1. **Conclusion.** The author favors empirical comparison and calibrated interpretation.
2. **Support.** Paragraph four suggests ink and handwriting tests; paragraphs three and five resist unwarranted motive claims.
3. **Prephrase.** Choose evidence-sensitive inquiry with explicit uncertainty.
4. **Why (B) is right.** (B) combines testing with disciplined limits.
5. **Why the others fail.**
   - **(A)** Censorship narrative trap: the author says a smudge does not prove it.
   - **(C)** Dismissal trap: ignores the evidence the passage values.
   - **(D)** Authority fantasy: neat script does not identify a renowned writer.
   - **(E)** Single-clue overconfidence: placement alone cannot fix a motive.

**Check:** Use several physical clues, then separate hypotheses from conclusions.
::::
:::

:::problem[Question II.26]
The author would most likely regard uncertainty about a note’s authorship as...

- **(A)** a reason to claim it belonged to the original poet.
- **(B)** a mistake that could be eliminated by assuming all notes have one author.
- **(C)** evidence that the manuscript was copied carelessly.
- **(D)** a limitation that restricts some conclusions but does not erase all interpretive value.
- **(E)** proof that the note is irrelevant.

::::solution[Solution]
**Answer:** (D)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** Uncertainty limits biographical narratives, not every reading of a page.
2. **Support.** Paragraph four explicitly says notes may show active interpretation without conclusive identity.
3. **Prephrase.** Seek epistemic restraint, not dismissal.
4. **Why (D) is right.** (D) matches the author’s nuanced treatment of unidentified marks.
5. **Why the others fail.**
   - **(A)** Identity invention: uncertainty is not evidence for the poet.
   - **(B)** Arbitrary simplification: single authorship is unsupported.
   - **(C)** Carelessness inference: unclear authorship does not establish poor copying.
   - **(E)** All-or-nothing trap: value can persist without an identified hand.

**Check:** No identity does not entail no evidence of engagement.
::::
:::

:::problem[Question II.27]
Which one of the following most accurately describes the organization of the passage?

- **(A)** It reports an experiment comparing medieval and modern readers’ scores.
- **(B)** It proves that marginal notes are unrelated to literary interpretation.
- **(C)** It argues a general claim, illustrates interpretive options, cautions against opposing excesses, suggests tests, and states a qualified conclusion.
- **(D)** It traces a manuscript’s journey through precisely dated owners.
- **(E)** It presents a single author’s verified biography and uses it to decode a poem.

::::solution[Solution]
**Answer:** (C)

**Type:** RC structure (Chapter 18)

1. **Conclusion.** The structure is balanced interpretive argument with examples and methodological constraints.
2. **Support.** The first paragraph frames; the next two show alternative errors; four gives tests; five synthesizes.
3. **Prephrase.** Match the full rhetorical progression.
4. **Why (C) is right.** (C) identifies the entire sequence.
5. **Why the others fail.**
   - **(A)** Empirical-study invention: no scored reader experiment occurs.
   - **(B)** Thesis reversal: margins can reveal active interpretation.
   - **(D)** Chronology invention: no named owners or dates.
   - **(E)** Biographical certainty opposite the passage’s caution.

**Check:** Each clause of (A) corresponds to a successive segment of the passage.
::::
:::

## 36.3 Section III: Logical Reasoning

:::problem[Question III.1]
An airport shuttle company replaced its fixed departure timetable with a system that dispatches vans whenever a certain number of passengers are waiting. During the first week, each dispatched van carried more passengers on average than before. The manager concludes that this system will reduce the average time passengers wait for a van. An employee observes that higher occupancy is a measure of how many people are aboard when a van leaves, not how long the first person in the queue had to wait. The manager has not reported any queue-time figures.

Which one of the following, if true, most weakens the manager’s conclusion?

- **(A)** The vans have more seats than the number of passengers required to trigger dispatch.
- **(B)** The first passengers arriving between busy periods now frequently wait longer while enough others accumulate to trigger a van.
- **(C)** Passenger demand is highest early in the morning.
- **(D)** Dispatchers required more training before they could use the new system reliably.
- **(E)** Most drivers prefer dispatching on demand to a fixed timetable.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Passenger wait times will fall under demand-triggered dispatch.
2. **Support.** Higher occupancy is not a waiting-time measurement; a threshold can impose a delay on early arrivals.
3. **Prephrase.** Seek direct evidence of increased waiting produced by the dispatch rule.
4. **Why (B) is right.** (B) shows a mechanism by which van fullness rises while some passenger waiting worsens.
5. **Why the others fail.**
   - **(A)** Capacity background: spare seats do not reveal waiting.
   - **(C)** Demand pattern: a peak alone does not establish comparative waits.
   - **(D)** Possible operational cost: training burden does not establish the direction of passengers’ waiting times.
   - **(E)** Employee preference trap: drivers’ views do not measure passenger waits.

**Check:** Dispatch-on-threshold can lengthen waits despite fuller vans.
::::
:::

:::problem[Question III.2]
A school kitchen has tested a simplified soup recipe three times, and each batch met its nutritional targets. The chef argues that the kitchen should adopt the recipe permanently because the fewer preparation steps reduce opportunities for mistakes. A supervisor responds that three successful batches are encouraging but do not demonstrate that the recipe can be made reliably when rotating volunteers are preparing hundreds of servings. The supervisor recommends a larger trial using typical staffing before a permanent change. The supervisor's argument is not that the simplified recipe is nutritionally inadequate.

Which one of the following most accurately states the supervisor’s main conclusion?

- **(A)** The simplified recipe has more preparation steps than the original.
- **(B)** Three trial batches were all unsuccessful.
- **(C)** The kitchen should increase volunteer training before deciding whether to expand service.
- **(D)** The soup recipe is nutritionally worse than the former recipe.
- **(E)** The kitchen should test the recipe under normal large-scale conditions before adopting it permanently.

::::solution[Solution]
**Answer:** (E)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The supervisor wants a larger realistic trial before permanent adoption.
2. **Support.** Three small successes do not establish dependable scaling under rotating staff.
3. **Prephrase.** Distinguish the recommendation from the conceded nutritional success.
4. **Why (E) is right.** (E) reproduces the advocated next step.
5. **Why the others fail.**
   - **(A)** Reversal: the simplified recipe has fewer steps.
   - **(B)** Premise reversal: all three batches met targets.
   - **(C)** Different proposal: additional training might help, but the supervisor specifically demands a typical-scale recipe trial.
   - **(D)** Explicit contradiction: the supervisor does not challenge nutrition.

**Check:** “Recommends a larger trial” is the author’s final position.
::::
:::

:::problem[Question III.3]
A manufacturer allowed volunteer designers to work remotely for two days a week. Those who volunteered finished more projects than the department average during the next quarter. The director concludes that remote work caused the higher output and should therefore be required for all designers. But participants volunteered after being told that only workers already comfortable with the design software would be eligible. The comparison group included beginners still learning that software. The director gives no reason to think the groups had comparable productivity before the arrangement began.

The director’s reasoning is most vulnerable to criticism because it...

- **(A)** concludes that remote work should remain voluntary even though volunteers do well.
- **(B)** claims that the designers’ prior software ability could never improve further.
- **(C)** treats being comfortable with the software as a necessary condition for any productive work.
- **(D)** compares self-selected experienced participants with a different group and attributes the difference entirely to remote work.
- **(E)** assumes that project completion is irrelevant to productivity.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Remote work caused superior output and warrants a universal requirement.
2. **Support.** The groups differ in experience and selection before the intervention.
3. **Prephrase.** Identify preexisting group differences as an alternative explanation.
4. **Why (D) is right.** (D) correctly names the selection confound.
5. **Why the others fail.**
   - **(A)** Opposite policy: the director seeks a requirement.
   - **(B)** Permanent-ability attribution: the director does not need to deny learning to make a selection-confounded comparison.
   - **(C)** Necessary-condition invention: the director states an eligibility rule for the pilot, not a general productivity law.
   - **(E)** Measure reversal: the director relies on project completion.

**Check:** High performers may have volunteered because they were already skilled.
::::
:::

:::problem[Question III.4]
A municipal emergency office tested redesigned flood-risk maps with two groups of residents. The new maps used simpler symbols and a clearer legend; volunteers using them answered more hazard-location questions correctly than people using the old maps. An official argues that the symbols improved comprehension. A critic notes that the volunteers using the new maps were drawn from a neighborhood with greater prior experience of flooding, whereas the old-map users came from elsewhere. The official wants a test of the visual design rather than local familiarity.

Which one of the following, if true, most strengthens the official’s claim?

- **(A)** When participants from each neighborhood were randomly assigned old or new maps, the new-map users in both neighborhoods answered more hazard-location questions correctly.
- **(B)** Residents said the old maps looked more official.
- **(C)** Participants using the new maps reported feeling more confident in their hazard-location answers.
- **(D)** The neighborhoods contain different numbers of houses.
- **(E)** The designer had previously produced other public maps that residents found easy to read.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** New symbols cause better map comprehension.
2. **Support.** Initial users differed by flood familiarity as well as map version.
3. **Prephrase.** Balance neighborhood familiarity and vary only map design.
4. **Why (A) is right.** (A) reproduces the effect within both neighborhoods under randomized assignment.
5. **Why the others fail.**
   - **(B)** Appearance preference: official-looking design is not measured understanding.
   - **(C)** Confidence proxy: self-reported assurance cannot isolate visual design from prior local knowledge.
   - **(D)** Population comparison: house counts do not isolate map readability.
   - **(E)** Past-success appeal: feedback on other maps does not control neighborhood differences in this trial.

**Check:** Within-neighborhood randomization removes the named confound.
::::
:::

:::problem[Question III.5]
A city office wants to move all taxi permit renewals to an online portal. The official in charge argues that doing so will reduce the total staff time needed for renewals because the portal requires fewer clerical steps per completed application. Some permit holders, however, do not have reliable internet access, and the office has proposed offering help by telephone. The official's calculation includes portal processing time but has not yet counted the staff time for the assistance calls or for fixing incomplete online submissions.

Which one of the following is an assumption required by the official’s argument?

- **(A)** Every applicant can complete the portal unaided.
- **(B)** Online renewals will eliminate the need to verify eligibility.
- **(C)** The staff time saved in routine processing will exceed any additional time spent on assistance and corrections.
- **(D)** All permit holders prefer online forms to paper.
- **(E)** Telephone help costs less per minute than in-person service.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The new process will lower total staff time.
2. **Support.** The calculation omits additional tasks that might offset simpler standard processing.
3. **Prephrase.** A net-reduction forecast requires total new burdens to remain below processing savings.
4. **Why (C) is right.** (C) states the minimal necessary net balance; its negation defeats the predicted savings.
5. **Why the others fail.**
   - **(A)** Too strong: some applicants can need help while total labor still falls.
   - **(B)** Eligibility exception: verification may continue without invalidating savings.
   - **(D)** Preference trap: convenience opinions do not determine labor.
   - **(E)** Cost versus time: cost per minute does not establish total minutes.

**Check:** Negate (B): extra work equals or exceeds saved work; total staff time cannot fall.
::::
:::

:::problem[Question III.6]
A food distributor installed more reliable refrigeration in its delivery trucks. The share of each day's delivered produce rejected for temperature-related spoilage fell. Yet the distributor recorded more total kilograms of rejected produce per day afterward. Inspectors verified that the same rejection criteria were used throughout, and the trucks carried the same broad categories of produce. The distributor wants to understand how a smaller rejected percentage could coexist with a greater absolute amount of rejected produce rather than dismiss one of the measurements.

Which one of the following, if true, most helps resolve the apparent discrepancy?

- **(A)** Drivers reported that the new cooling equipment required fewer manual adjustments.
- **(B)** Some drivers took the same routes as before.
- **(C)** The percentage of rejected produce was calculated using kilograms as the unit.
- **(D)** Total daily delivery volume increased enough that a smaller percentage represented more kilograms of rejected produce.
- **(E)** The distributor also expanded the number of delivery routes during the study.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** No argument conclusion; reconcile a smaller fraction with a larger absolute quantity.
2. **Support.** Rejected kilograms = total kilograms delivered multiplied by rejected fraction.
3. **Prephrase.** Find a changed denominator large enough to raise the product.
4. **Why (D) is right.** (D) supplies the increased total volume that mathematically permits both observations.
5. **Why the others fail.**
   - **(A)** Process improvement: maintenance impressions do not explain why absolute waste rose as its fraction fell.
   - **(B)** Route continuity: same roads do not control delivery volume.
   - **(C)** Unit trap: kilograms is compatible with both measures and gives no increase.
   - **(E)** Incomplete proxy: more routes does not by itself establish sufficient total volume to resolve the percentage and weight discrepancy.

**Check:** For example, 10% of 100 = 10, while 6% of 200 = 12.
::::
:::

:::problem[Question III.7]
A library permits special loans under two rules. Every fragile map must remain in the reading room unless a conservator has approved transport. No manuscript that is being repaired may be lent outside the building. Map N is fragile and has no conservator approval. Manuscript P is under repair. Photograph Q is not fragile, but its loan status is unrecorded. The librarian explains that some approved items may still be restricted for other reasons, so permission for one category does not guarantee an unrestricted loan.

Which one of the following must be true?

- **(A)** Map N may be taken outside if a patron promises to return it promptly.
- **(B)** Every item retained in the reading room must be fragile.
- **(C)** Manuscript P cannot be lent outside the building.
- **(D)** Photograph Q can be borrowed outside the building.
- **(E)** Every map with conservator approval is freely borrowable.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** Deduce a restriction guaranteed by the given rules.
2. **Support.** Under repair -> not outside loan, and Manuscript P is under repair.
3. **Prephrase.** Follow the one-way categorical prohibition.
4. **Why (C) is right.** (C) is an immediate application of the manuscript restriction.
5. **Why the others fail.**
   - **(A)** Invented exception: promises do not override the fragile-map rule.
   - **(B)** Reverse-category trap: other reasons can keep items inside.
   - **(D)** Unknown-case trap: Q’s loan status is expressly unrecorded.
   - **(E)** Converse/overreach: approval merely removes one restriction.

**Check:** P is under repair; all under-repair manuscripts are barred from outside loans.
::::
:::

:::problem[Question III.8]
A research workshop adopts this policy: scarce equipment should be assigned first to projects that cannot proceed without it, provided those projects meet the workshop's safety requirements. A project that could use a substitute should not displace a safe project for which no substitute exists merely because its supervisor has greater seniority. When two eligible projects have equally urgent equipment needs, the workshop may use a lottery. The directors face conflicting requests for an instrument that can serve only one project at a time.

Which one of the following decisions most closely conforms to the workshop’s policy?

- **(A)** Assign it to whichever project already owns the most instruments.
- **(B)** Give the instrument to the senior supervisor, regardless of substitutability.
- **(C)** Give it to an unsafe project simply because that project has no substitute.
- **(D)** Randomize immediately among all projects even if one can proceed with other tools.
- **(E)** Assign it first to a project that cannot proceed without it and meets safety rules, ahead of a project with a workable substitute.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (apply) (Chapter 13)

1. **Conclusion.** The priority rule is necessity conditioned on safety, with limited tie-breaking.
2. **Support.** The policy excludes unsafe projects and ranks non-substitutable safe projects ahead of substitutable ones.
3. **Prephrase.** Use both the eligibility gate and priority comparison.
4. **Why (E) is right.** (E) satisfies safety and assigns priority to the project with no workable substitute.
5. **Why the others fail.**
   - **(A)** Accumulation bias: existing ownership does not confer priority.
   - **(B)** Seniority trap: the rule expressly rejects that displacement rationale.
   - **(C)** Condition omission: lack of a substitute cannot override safety.
   - **(D)** Premature lottery: tie-breaker applies only to equally urgent eligible requests.

**Check:** Safe + cannot proceed without it -> precedence over safe with substitute.
::::
:::

:::problem[Question III.9]
An airport replaced a strip of tall grass near one taxiway with gravel. Bird sightings along that taxiway declined over the following two months. The grounds manager concludes that the change reduced the total number of birds using the airport and recommends replacing grass with gravel across the property. A biologist notes that the airport's observation team records sightings by taxiway rather than unique birds across the property. Birds avoiding one area could simply gather elsewhere, and weather conditions can alter where the observers spot them.

Which one of the following, if true, most weakens the manager’s conclusion?

- **(A)** Birds were observed spending less time on the newly graveled strip than before.
- **(B)** Sightings at adjacent taxiways rose by roughly the number lost at the altered strip, with no decline in airport-wide sightings.
- **(C)** Birds continued to be seen at the airport during the trial.
- **(D)** The observation team used binoculars with the same magnification as before.
- **(E)** Some taxiways do not have grassy strips.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Gravel reduced the number of birds using the entire airport.
2. **Support.** Observed sightings dropped only beside the altered taxiway; relocation is plausible.
3. **Prephrase.** Find a matched rise elsewhere showing displacement, not a net reduction.
4. **Why (B) is right.** (B) directly defeats the airport-wide extrapolation.
5. **Why the others fail.**
   - **(A)** Local confirmation only: fewer birds at the treated strip remains consistent with displacement.
   - **(C)** Weak existence: some sightings are compatible with a large or small decline.
   - **(D)** Measurement-equipment constancy: same binoculars do not rule out movement elsewhere.
   - **(E)** Other-site description: grass distribution does not quantify airport-wide birds.

**Check:** Area-specific decrease + adjacent increase can equal no total decrease.
::::
:::

:::problem[Question III.10]
An excavation committee is considering whether to reopen an old trench. Its chair says: 'The field notes from the original excavation are incomplete. We have, however, detailed photographs of the exposed layers. That is a reason not to treat the surviving records as worthless. Still, photographs alone cannot show which objects were removed between two pictures. Because that sequence matters to our current question, a limited new excavation may be justified.' The chair uses the photographs neither as final proof nor as a reason to abandon further work.

In the chair’s argument, the statement that the photographs are a reason not to treat the records as worthless serves to...

- **(A)** concede that existing evidence has some value before identifying a remaining evidentiary gap.
- **(B)** prove that no objects were removed between photographs.
- **(C)** reject all field notes as intentionally misleading.
- **(D)** establish that the old trench can never be studied again.
- **(E)** state the final conclusion in favor of an unrestricted excavation.

::::solution[Solution]
**Answer:** (A)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** Limited new excavation may be justified because the sequence is unrecorded.
2. **Support.** The chair acknowledges some evidential value in photographs but finds a specific gap.
3. **Prephrase.** Identify a qualifying concession within an argument for further investigation.
4. **Why (A) is right.** (A) captures the concession-and-limitation structure.
5. **Why the others fail.**
   - **(B)** Contradiction: unseen removals are precisely the gap.
   - **(C)** Intent invention: incomplete notes are not alleged dishonest.
   - **(D)** Opposite conclusion: new study remains possible.
   - **(E)** Scope inflation: a limited excavation is not unrestricted.

**Check:** The statement is a concession, followed by “Still” and a limiting argument.
::::
:::

:::problem[Question III.11]
An art museum uses a private archival index. Every exhibit whose provenance documents have been fully verified receives a green catalog marker. Any exhibit with a green marker is included in the curator's approved guide. A new ceramic vase is expected to appear in the approved guide, but the registrar has only said that most of its documents have been checked. The registrar stresses that 'most checked' is not the same as 'fully verified' and that no separate rule has yet been stated for partially checked objects.

Which one of the following, if assumed, permits the conclusion that the vase will appear in the approved guide?

- **(A)** Most items whose documents are checked receive green markers.
- **(B)** The registrar has checked documents for several unrelated exhibits.
- **(C)** The vase’s provenance documents will be fully verified before the guide is compiled.
- **(D)** Some exhibits in the guide have no green marker.
- **(E)** The vase is more valuable than most cataloged ceramics.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The vase will appear in the guide.
2. **Support.** Fully verified -> green marker -> approved guide; the vase currently lacks the antecedent.
3. **Prephrase.** Supply full verification for the vase to activate the chain.
4. **Why (C) is right.** (C) activates both rules and guarantees guide inclusion.
5. **Why the others fail.**
   - **(A)** Probability trap: “most” does not guarantee this item.
   - **(B)** Irrelevant work history: other objects do not establish this one’s status.
   - **(D)** Other-item trap: some entries without markers say nothing about this vase.
   - **(E)** Value distraction: price is not part of the rules.

**Check:** Vase fully verified -> green -> included in guide.
::::
:::

:::problem[Question III.12]
A call center requires every team leader to complete conflict-resolution training. Its director notices that Arun completed the training and concludes that Arun must now be a team leader. But several ordinary staff members also enroll in the training to qualify for possible future promotions, and at present the center has no team-leader vacancies. The director has not examined the current list of supervisors.

The director’s argument is most vulnerable to criticism on the grounds that it...

- **(A)** confuses a condition necessary for team leadership with one sufficient for becoming a team leader.
- **(B)** uses the number of team leaders to estimate turnover.
- **(C)** assumes that training changes employee personalities.
- **(D)** infers that employees in one department work fewer hours than others.
- **(E)** treats a job-title rule as evidence that the rule was violated.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Arun is a team leader because he completed the required course.
2. **Support.** Team leader -> trained; Arun trained does not yield team leader.
3. **Prephrase.** Look for affirming the consequent: mistaking necessary for sufficient.
4. **Why (A) is right.** (A) describes the exact conditional reversal.
5. **Why the others fail.**
   - **(B)** Turnover invention: the argument does not estimate retention.
   - **(C)** Causation distraction: personality change is irrelevant.
   - **(D)** Comparison invention: other departments and hours are absent.
   - **(E)** Rule violation trap: no violation is alleged.

**Check:** Leader -> trained; trained does not imply leader.
::::
:::

:::problem[Question III.13]
A rooftop garden sells vegetables to local restaurants. During three warm months it harvested more lettuce than during three cooler months. Its records also show that restaurants placed more orders during the warm period, but some of those orders were filled by outside growers. The garden’s manager cautions that harvest volume alone cannot establish the cause of restaurant demand, and that orders received are not identical to orders actually filled from the roof. Neither price changes nor weather conditions have been isolated in a controlled comparison.

Which one of the following is most strongly supported by the information above?

- **(A)** The rooftop garden supplied every additional restaurant order during the warm period.
- **(B)** The garden’s harvest volume and the restaurants’ total orders both rose during the warm period, without proof of a causal connection between those changes.
- **(C)** Restaurant demand caused the increase in lettuce harvest.
- **(D)** The garden’s share of all restaurant lettuce orders increased during the warm period.
- **(E)** Outside growers sold less lettuce during the warm period.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Only a limited descriptive inference is established.
2. **Support.** Harvest and orders were higher in warm months, but fulfillment and causality are unresolved.
3. **Prephrase.** Retain both observations without inventing the direction of causation.
4. **Why (B) is right.** (B) is a precisely bounded summary of the evidence.
5. **Why the others fail.**
   - **(A)** Fulfillment overclaim: some orders were supplied from outside.
   - **(C)** Correlation-causation leap: demand’s effect on harvest is untested.
   - **(D)** Market-share trap: relative orders do not establish that the garden filled each additional order.
   - **(E)** Outside-volume invention: some outside orders do not show a decline.

**Check:** Observed co-movement does not entail either causal direction.
::::
:::

:::problem[Question III.14]
A parks department replaced faded signs at several trail intersections with signs containing larger lettering and clearer arrows. Rangers later received fewer reports of hikers taking wrong turns. A supervisor believes the new signs reduced navigational mistakes. A critic observes that the department also rerouted a popular hiking event away from those intersections and that the overall number of hikers could have changed. The supervisor wants evidence about wrong turns per comparable visitor, not simply a smaller total number of reports.

Which one of the following, if true, most strengthens the supervisor’s explanation?

- **(A)** Rangers also started giving spoken directions to hikers at the trailhead.
- **(B)** Hikers surveyed near the new signs said they felt more confident about their route choices.
- **(C)** The park’s website was redesigned during the same month.
- **(D)** At otherwise comparable intersections with unchanged routes and similar hiker counts, wrong turns per hundred hikers fell where signs were replaced but not where they remained faded.
- **(E)** The new signs included more recognizable landmark names as well as larger arrows.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Sign redesign caused fewer navigation errors.
2. **Support.** Raw report counts are confounded by route and visitor changes.
3. **Prephrase.** Compare error rates at like intersections with and without signs changed.
4. **Why (D) is right.** (D) isolates the relevant variable and normalizes by exposure.
5. **Why the others fail.**
   - **(A)** Alternative cause: personal directions could reduce wrong turns regardless of replacement signs.
   - **(B)** Subjective-proxy trap: confidence is weaker than controlled counts of actual wrong turns.
   - **(C)** New confound: website redesign provides no isolated sign evidence.
   - **(E)** Feature mixing: additional changes might explain improvements but do not isolate the effect of arrow clarity specifically.

**Check:** Controls + per-hiker rate make (A) a causal strengthen answer.
::::
:::

:::problem[Question III.15]
A restaurant raised its lunch prices while keeping the menu unchanged. Average spending per transaction increased the following week, and the owner concludes that the restaurant earned more total lunch revenue. But the owner has not said how many transactions occurred, and a nearby construction project made access to the restaurant more difficult. The owner assumes that higher spending per transaction tells the full story. The accountant asks the owner to check the register's transaction log before making a statement to investors, but the owner says the higher average ticket is already decisive.

Which one of the following is an assumption the owner’s argument requires?

- **(A)** Construction workers ate lunch at the restaurant.
- **(B)** Every individual menu item became more profitable.
- **(C)** Every customer ordered the same meal in both weeks.
- **(D)** The owner notified customers of the price change in advance.
- **(E)** The number of lunch transactions did not fall enough to offset the higher average spending.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Total lunch revenue increased.
2. **Support.** Average spending rose, but the quantity of transactions is unknown.
3. **Prephrase.** A net-revenue increase requires the count not to shrink too much.
4. **Why (E) is right.** (E) exactly supplies that required nonoffset condition.
5. **Why the others fail.**
   - **(A)** Customer-identity trap: construction workers are immaterial to total sales.
   - **(B)** Profit-versus-revenue shell game: margin on each item is not total receipts.
   - **(C)** Uniform-purchase trap: transaction compositions can vary without preventing revenue growth.
   - **(D)** Notice distraction: announcements do not settle arithmetic.

**Check:** Negate (C): transactions drop enough to offset ticket size, so total revenue fails to rise.
::::
:::

:::problem[Question III.16]
A researcher claims that a stone tool must belong to the oldest occupation phase of a site because it looks more worn than tools found nearby. Another archaeologist replies: 'Wear need not increase uniformly with age. Tools can be used with different intensity, and soil movement can abrade a surface after burial. Without showing that these influences were comparable, you cannot infer relative age from wear alone.' The archaeologist does not attempt to establish the tool's actual date; the challenge is directed at the reliability of the proposed evidence.

The second archaeologist responds to the argument primarily by...

- **(A)** accepting the claimed date but changing its significance.
- **(B)** claiming that stone tools can never be dated using any method.
- **(C)** appealing to the professional status of the critic.
- **(D)** arguing that the tool must have been made recently.
- **(E)** identifying alternative influences on the observed feature used as a proxy for age.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Surface wear alone cannot establish comparative age under uncontrolled conditions.
2. **Support.** Usage and post-burial abrasion could produce the observed wear independent of age.
3. **Prephrase.** Describe an attack on the reliability of the proposed indicator.
4. **Why (E) is right.** (E) identifies the alternative-cause critique accurately.
5. **Why the others fail.**
   - **(A)** Concession misread: the claimed date is not accepted.
   - **(B)** Absolute rejection: only wear-alone dating is challenged.
   - **(C)** Authority trap: evidence-based alternatives, not prestige, carry the rebuttal.
   - **(D)** Reverse dating claim: the critic does not assert a recent date.

**Check:** Wear can be caused by factors other than time, so it is not a stand-alone age measure.
::::
:::

:::problem[Question III.17]
A rescue unit follows two rules: anyone assigned to night dispatch has completed radio instruction, and everyone who has completed that instruction can read the emergency frequency chart. Lena is assigned to night dispatch. The supervisor concludes that Lena can read the chart. The supervisor does not infer that everyone who reads the chart is qualified for night dispatch, since other qualifications may also be necessary. Lena received the night assignment at the beginning of the month, when the dispatch supervisor circulated the new roster to all unit members.

Which one of the following arguments is most similar in its reasoning?

- **(A)** All gallery volunteers signed a waiver; Rafi signed a waiver; therefore Rafi is a gallery volunteer.
- **(B)** Every archived map is cataloged; every cataloged map has an identifier; this map is archived; therefore it has an identifier.
- **(C)** All award winners submitted essays; some students submitted essays; therefore those students won awards.
- **(D)** If an aircraft is inspected it receives a stamp; no stamp was issued; therefore the aircraft was inspected.
- **(E)** Anyone who can lead the workshop can use a lathe; Yara uses a lathe; therefore Yara can lead it.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Dispatch -> training -> chart reading; Lena in dispatch -> reads chart.
2. **Support.** Two chained universal conditionals are applied forward to an individual.
3. **Prephrase.** Find P -> Q -> R, plus P, therefore R.
4. **Why (B) is right.** (B) uses archived -> cataloged -> identifier, plus this archived map.
5. **Why the others fail.**
   - **(A)** Affirming-consequent error: signing is not enough for volunteering.
   - **(C)** Reversal and “some” problem: essays do not entail awards.
   - **(D)** Contradictory inference: no stamp would imply not inspected, not inspected.
   - **(E)** Affirming-consequent error: lathe use does not entail leadership.

**Check:** Forward two-link application appears only in (B).
::::
:::

:::problem[Question III.18]
A pilot argues that no aircraft has experienced a mechanical problem after landing at a small coastal airstrip because the strip's maintenance log lists no mechanical problems for the past year. Yet the log is used only for incidents handled by the airstrip's own maintenance crew, and visiting pilots can obtain repairs elsewhere. The pilot has offered no evidence about those outside repairs. The absence of entries in one limited record is treated as proof that the underlying events did not occur anywhere in the relevant population.

The pilot’s reasoning is most vulnerable to criticism because it...

- **(A)** takes the absence of reports in a restricted record as proof of the absence of the events themselves.
- **(B)** treats landing at one strip as sufficient to guarantee a fault.
- **(C)** uses the rate of repairs to estimate aircraft traffic.
- **(D)** argues that traveling pilots are more careful than local pilots.
- **(E)** claims that mechanical faults always occur after landings.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** No aircraft experienced a post-landing mechanical problem at the strip.
2. **Support.** The log only covers crew-handled cases and omits outside repairs.
3. **Prephrase.** Identify an incomplete-record or absence-of-evidence flaw.
4. **Why (A) is right.** (A) correctly characterizes the unsupported move from “not logged” to “never happened.”
5. **Why the others fail.**
   - **(B)** Opposite inference: landing is not claimed to cause a fault.
   - **(C)** Traffic-rate invention: aircraft volume is not discussed.
   - **(D)** Behavior comparison invention: visiting versus local caution is unmentioned.
   - **(E)** Universal-fault invention: the pilot asserts zero faults, not inevitable faults.

**Check:** Unrecorded outside repairs are compatible with the log’s silence.
::::
:::

:::problem[Question III.19]
Instructor Vale: 'A student who has demonstrated mastery on a comprehensive retake should have the new score replace the earlier one, even if the retake was taken after substantial extra study.' Instructor Noor: 'I agree that a comprehensive retake can demonstrate mastery. But replacing an earlier score completely would hide how consistently a student performed across the term. The retake should count, but the original score should remain part of the grade.' Both instructors believe that mastery matters and that retake scores provide useful information.

The instructors disagree about whether...

- **(A)** retake scores provide information about student learning.
- **(B)** course grades can be based on more than one test.
- **(C)** a strong retake score should completely replace the earlier grade.
- **(D)** a comprehensive retake can demonstrate mastery.
- **(E)** students can study after an original examination.

::::solution[Solution]
**Answer:** (C)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Find the exact disputed grade-replacement policy.
2. **Support.** Vale explicitly favors full replacement; Noor explicitly rejects full replacement.
3. **Prephrase.** Choose a proposition one affirms and the other denies.
4. **Why (C) is right.** (C) produces the opposed positions without adding assumptions.
5. **Why the others fail.**
   - **(A)** Shared agreement: both see informational value.
   - **(B)** Compatible with both: Vale’s broader grading policy is not specified.
   - **(D)** Shared agreement: both accept demonstration of mastery.
   - **(E)** Undisputed background: neither disputes extra study.

**Check:** Vale yes, Noor no, on complete replacement.
::::
:::

:::problem[Question III.20]
An aquarium shop switched to smaller containers for a certain fish food. The price of each container fell, and customers purchased more containers per week. Yet the total weight of this food sold each week declined. The shopkeeper initially considered the records inconsistent, but both the container counts and the weight totals were independently checked. The shopkeeper wishes to understand how all three observations could coexist without assuming any reporting error or an abrupt change in the type of food sold.

Which one of the following, if true, most helps resolve the apparent discrepancy?

- **(A)** The same employee counted containers during both periods.
- **(B)** More customers visited the shop to buy fish tanks.
- **(C)** Customers reported preferring the smaller packages because they were easier to carry.
- **(D)** The reduction in the amount of food per container was proportionally greater than the increase in containers purchased.
- **(E)** The shop began closing earlier on Sundays.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** The puzzle concerns containers versus weight, not conflicting totals.
2. **Support.** Total weight = containers sold times weight per container.
3. **Prephrase.** Find a fall in package size large enough to outweigh more packages.
4. **Why (D) is right.** (D) allows container count to rise while total kilograms decline.
5. **Why the others fail.**
   - **(A)** Record reliability: counting consistency is already stipulated.
   - **(B)** Other-product traffic: tank sales do not give food weight.
   - **(C)** Preference without arithmetic: easier handling might increase counts but does not explain falling total weight.
   - **(E)** Hours background: could affect sales, but not the stated arithmetic relationship.

**Check:** For instance, 100 × 1 kg = 100 kg; 150 × 0.5 kg = 75 kg.
::::
:::

:::problem[Question III.21]
A town archive plans to discard fragile paper copies once their images have been transferred to microfilm. The director says the archive will preserve all information that future researchers might need because every printed word on each document will be legible on the film. The director has not considered whether some documents contain marginal marks, watermarks, or physical features relevant to research. The proposal treats the preservation of readable printed text as equivalent to the preservation of every potentially important feature of the originals.

Which one of the following is an assumption on which the director’s argument depends?

- **(A)** No feature of the original paper documents that would be lost in the transfer could be information future researchers need.
- **(B)** Microfilm will be cheaper to store than every other medium.
- **(C)** The town archive will never acquire any more paper records.
- **(D)** All researchers prefer reading images to handling originals.
- **(E)** Every document has been inspected by at least three archivists.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Microfilm text legibility preserves all information future researchers may need.
2. **Support.** The evidence covers printed words but not potentially meaningful physical features.
3. **Prephrase.** The director must assume no irreplaceable research-relevant information lies outside the film record.
4. **Why (A) is right.** (A) is the necessary denial of the missing-information possibility.
5. **Why the others fail.**
   - **(B)** Cost distraction: expenses are independent of preservation completeness.
   - **(C)** Future-acquisition trap: new records do not change information lost from these ones.
   - **(D)** Preference trap: liking images does not preserve lost features.
   - **(E)** Review-procedure detail: three inspections do not guarantee all relevant features survive.

**Check:** Negate (E): a research-relevant feature is lost, refuting preservation of all needed information.
::::
:::

:::problem[Question III.22]
A botanical garden director says: 'We welcome volunteer proposals, but no proposal should receive special access merely because its sponsor donated money. A proposal that clearly benefits the collection and satisfies safety requirements should be considered on its merits, even if its author is new to the garden. If several proposals are equally qualified and resources cannot accommodate them all, we can choose by a transparent lottery.' The director's aim is to allow scarce access to be allocated by relevance and safety rather than influence or personal connections.

Which one of the following principles best justifies the director’s policy?

- **(A)** The garden should approve every proposal without safety review.
- **(B)** Access should be reserved for people with the most years of affiliation.
- **(C)** Whenever possible, the director should avoid collecting evidence about a proposal.
- **(D)** Scarce opportunities should be judged first by relevant merits and eligibility, with impartial tie-breaking among equally qualified applicants.
- **(E)** A donor’s requests should have priority when the donor has been generous.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (identify) (Chapter 13)

1. **Conclusion.** Relevant benefit and safety precede influence; equal contenders may be selected fairly.
2. **Support.** The director explicitly rejects donation and seniority as overriding eligibility.
3. **Prephrase.** State an impartial merit threshold plus transparent tie-breaker.
4. **Why (D) is right.** (D) mirrors both stages of the rule.
5. **Why the others fail.**
   - **(A)** Safety omission: the policy requires compliance.
   - **(B)** Tenure trap: newcomers can qualify on merits.
   - **(C)** Evidence aversion: the policy calls for evaluating proposals.
   - **(E)** Influence preference: contradicts the anti-donor premise.

**Check:** Merits first, impartial resolution of genuine ties second.
::::
:::

:::problem[Question III.23]
A science museum argues: 'If our visiting exhibition is extremely popular, weekend tickets will sell out. Weekend tickets have sold out, so the exhibition must be extremely popular.' But the museum's small theater has only a few weekend seats, and tickets could sell out even if comparatively few people want to attend. The director has reported no figures on unfilled requests or on the demand for comparable exhibitions in larger venues.

Which one of the following arguments is flawed in the same way?

- **(A)** If a truck has no fuel, it cannot drive; the truck has fuel; therefore it can drive.
- **(B)** If an exam is canceled, no papers are graded; papers were graded; therefore the exam was not canceled.
- **(C)** If a library closes early, the doors are locked by six; the doors are locked by six; therefore the library closed early.
- **(D)** If a campsite is open, the road is passable; the campsite is open; therefore the road is passable.
- **(E)** If a coin is made of silver, it is metallic; this coin is not metallic; therefore it is not silver.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** Sold out is treated as proof of the supposed cause, popularity.
2. **Support.** Extremely popular -> sold out; sold out -> extremely popular affirms the consequent.
3. **Prephrase.** Look for the same conditional converse error.
4. **Why (C) is right.** (C) mirrors closed early -> locked; locked -> closed early.
5. **Why the others fail.**
   - **(A)** Denying-antecedent flaw: no fuel -> cannot drive; fuel does not imply can drive, but this is a different error.
   - **(B)** Valid contrapositive: graded papers -> not canceled.
   - **(D)** Valid modus ponens: open -> passable with open.
   - **(E)** Valid contrapositive: not metallic -> not silver.

**Check:** Both stimulus and (A) infer P from Q given P -> Q.
::::
:::

:::problem[Question III.24]
A fabrication company plans to train existing workers on a new programmable cutting machine. The operations chief says the training will pay for itself within a year because experienced workers will produce more units per hour after completing it. The finance officer notes that greater output per hour does not necessarily mean higher net savings if the training is expensive or if the machine will sit idle when demand is low. The chief has not provided a calculation comparing added value from output with the full cost of training and equipment downtime.

The answer to which one of the following questions would be most useful in evaluating the chief’s argument?

- **(A)** Will training sessions take place during ordinary production shifts?
- **(B)** Did trainees produce more units per hour during the company’s initial pilot session?
- **(C)** How much did the company’s rival gain from its own investment in a similar machine?
- **(D)** Will worker availability allow the company to schedule more machine hours after training?
- **(E)** Will the value of additional usable output within one year exceed the total training costs and resulting downtime costs?

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The investment recoups its costs within one year.
2. **Support.** Productivity per hour is an intermediate metric; net return requires benefits versus all relevant costs.
3. **Prephrase.** Ask directly whether the predicted benefits clear the proposed payback threshold.
4. **Why (E) is right.** (E) states the necessary payback comparison.
5. **Why the others fail.**
   - **(A)** One-cost component: the timing affects downtime but does not settle the full payback calculation.
   - **(B)** One-sided benefit: a productivity gain still does not establish recovery of training and downtime costs.
   - **(C)** Wrong comparison: a rival’s gain does not determine this firm’s specific costs or payback.
   - **(D)** Capacity intermediate: available hours alone do not establish usable demand or net benefit.

**Check:** Net payback requires added value >= training plus downtime costs.
::::
:::

:::problem[Question III.25]
A flying club says that every instructor who can supervise night navigation has completed advanced instrument training. Every instructor who has completed that training is authorized to brief students on instrument procedures. Niko is authorized to brief students on instrument procedures, and the club's administrator concludes that Niko can supervise night navigation. The administrator checked Niko's briefing authorization on a current roster but has not reviewed Niko's training history or night-flight assignments. The roster records briefing permissions, not supervisory appointments.

Which one of the following, if assumed, would enable the administrator’s conclusion to be properly drawn?

- **(A)** Every instructor who can supervise night navigation can brief students.
- **(B)** Any instructor authorized to brief students on instrument procedures can supervise night navigation.
- **(C)** Niko has briefed at least one student before.
- **(D)** Every instructor who has completed advanced instrument training may supervise night navigation.
- **(E)** Every instructor authorized to brief students has completed at least one classroom course.

::::solution[Solution]
**Answer:** (B)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Niko is eligible to supervise night navigation.
2. **Support.** Current rules give supervision -> training -> briefing; we know only Niko’s briefing authorization.
3. **Prephrase.** Supply a direct sufficient condition from briefing authorization to supervision.
4. **Why (B) is right.** (B) states exactly that conditional and completes a valid inference.
5. **Why the others fail.**
   - **(A)** Restates a necessary condition: supervision -> briefing cannot be reversed.
   - **(C)** Past-activity trap: actual briefing does not prove supervisory status.
   - **(D)** Partial-chain trap: even if training suffices for supervision, Niko is not shown to have completed that training.
   - **(E)** Weaker-credential trap: a classroom course is not stated to confer night-navigation supervisory qualification.

**Check:** Briefing authorized (Niko) + briefing -> supervision yields Niko supervises.
::::
:::

## 36.4 Scoring and review

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | C | Main conclusion | 4 |
| I.2 | A | Strengthen | 8 |
| I.3 | E | Flaw | 9 |
| I.4 | B | Necessary assumption | 7 |
| I.5 | D | Paradox / resolve | 13 |
| I.6 | B | Must be true / inference | 10 |
| I.7 | D | Weaken | 8 |
| I.8 | A | Principle (apply) | 13 |
| I.9 | C | Sufficient assumption | 7 |
| I.10 | E | Role of a statement | 11 |
| I.11 | D | Flaw | 9 |
| I.12 | C | Strengthen | 8 |
| I.13 | B | Necessary assumption | 7 |
| I.14 | E | Method of reasoning | 11 |
| I.15 | A | Parallel reasoning | 12 |
| I.16 | E | Weaken | 8 |
| I.17 | A | Most strongly supported | 10 |
| I.18 | D | Point at issue | 11 |
| I.19 | B | Flaw | 9 |
| I.20 | C | Evaluate | 8 |
| I.21 | A | Principle (identify) | 13 |
| I.22 | B | Necessary assumption | 7 |
| I.23 | E | Parallel flaw | 12 |
| I.24 | D | Strengthen | 8 |
| I.25 | C | Sufficient assumption | 7 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | D | RC main point | 18 |
| II.2 | B | RC function | 18 |
| II.3 | A | RC detail | 18 |
| II.4 | E | RC inference | 18 |
| II.5 | C | RC application | 18 |
| II.6 | A | RC attitude | 18 |
| II.7 | D | RC structure | 18 |
| II.8 | C | RC primary purpose | 18 |
| II.9 | B | RC detail | 18 |
| II.10 | E | RC inference | 18 |
| II.11 | E | RC attitude | 18 |
| II.12 | C | RC application | 18 |
| II.13 | B | RC function | 18 |
| II.14 | A | RC structure | 18 |
| II.15 | D | Comparative agreement | 17 |
| II.16 | B | Comparative disagreement | 17 |
| II.17 | E | Comparative response | 17 |
| II.18 | D | RC detail | 18 |
| II.19 | C | Comparative relationship | 17 |
| II.20 | A | Comparative response | 17 |
| II.21 | C | RC main point | 18 |
| II.22 | A | RC detail | 18 |
| II.23 | E | RC function | 18 |
| II.24 | D | RC inference | 18 |
| II.25 | B | RC application | 18 |
| II.26 | D | RC attitude | 18 |
| II.27 | C | RC structure | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | B | Weaken | 8 |
| III.2 | E | Main conclusion | 4 |
| III.3 | D | Flaw | 9 |
| III.4 | A | Strengthen | 8 |
| III.5 | C | Necessary assumption | 7 |
| III.6 | D | Paradox / resolve | 13 |
| III.7 | C | Must be true / inference | 10 |
| III.8 | E | Principle (apply) | 13 |
| III.9 | B | Weaken | 8 |
| III.10 | A | Role of a statement | 11 |
| III.11 | C | Sufficient assumption | 7 |
| III.12 | A | Flaw | 9 |
| III.13 | B | Most strongly supported | 10 |
| III.14 | D | Strengthen | 8 |
| III.15 | E | Necessary assumption | 7 |
| III.16 | E | Method of reasoning | 11 |
| III.17 | B | Parallel reasoning | 12 |
| III.18 | A | Flaw | 9 |
| III.19 | C | Point at issue | 11 |
| III.20 | D | Paradox / resolve | 13 |
| III.21 | A | Necessary assumption | 7 |
| III.22 | D | Principle (identify) | 13 |
| III.23 | C | Parallel flaw | 12 |
| III.24 | E | Evaluate | 8 |
| III.25 | B | Sufficient assumption | 7 |

:::

**Raw score:** Add your correct answers out of **77**. Section scores are out of 25, 27, and 25. This practice test has not been statistically equated by LSAC, so **no valid 120–180 conversion or percentile can be assigned** to your result. Treat the raw score and error patterns as diagnostic rather than as an official score prediction.

| Missed question type | Review chapter |
| --- | --- |
| Main conclusion and argument foundations | Chapter 4 |
| Necessary or sufficient assumption | Chapter 7 (and Chapter 5 for conditional logic) |
| Strengthen, weaken, and evaluate | Chapter 8 |
| Flaw | Chapters 6 and 9 |
| Must be true or most strongly supported | Chapter 10 |
| Role, method, and point at issue | Chapter 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Paradox and principle | Chapter 13 |
| RC global, detail, inference, function, attitude, structure, application | Chapters 15 and 18 |
| Comparative RC | Chapters 17 and 18 |

After checking the key, review flagged correct answers as carefully as misses: a lucky answer should not be treated as mastery (Chapters 22–23).
