---
title: "Conditional & Formal Logic"
source: "lsat_ch5_logic.html"
---

Part II · Chapter 5

# Conditional & Formal Logic

The if–then machinery under the hood of the LSAT's hardest questions. Learn to translate sentences into arrows, flip them correctly, and chain them — and a whole class of "trick" questions becomes mechanical.

**Est. study time:** 70–90 min — **Sections:** 5 — **Practice:** 25+ items

## Overview

Some LSAT questions are secretly little logic puzzles. They hinge on words like *if, only, unless, all, some,* and *most* — and if you read those words casually, you'll pick a wrong answer that "feels" right. This chapter gives you a precise, mechanical system: translate conditional sentences into arrows, form the contrapositive without error, handle the three quantifiers, chain statements together, and recognize the valid and invalid argument forms the test reuses constantly.

This is the one genuinely "technical" chapter in Part II, and it rewards deliberate practice more than reading. Work every example with pen in hand. Once the translations become automatic, questions that used to feel like traps will feel like arithmetic — and the necessary/sufficient confusion you met in Chapter 4 will become impossible to fall for.

:::callout-tip
Prerequisites

Chapter 4 — especially the gap/assumption idea and the necessary-vs-sufficient distinction we previewed there. Here we make that distinction rigorous and give it notation.
:::

## 5.1 · If–then statements: necessary vs. sufficient

:::callout-intuition
Intuition first

A conditional statement says "if one thing is true, another must be true." The first thing is **enough to guarantee** the second — it's *sufficient*. The second is something that **has to be present** whenever the first is — it's *necessary*. Think "having a valid ticket" (sufficient) and "getting into the concert" (necessary): the ticket guarantees entry, and entry requires a ticket. Mixing up which is which is the single most common logical error the LSAT tests — so we'll nail it down with notation you can't misread.
:::

:::definition
**Definition 5.1 — Conditional, sufficient, necessary.** A *conditional* "If A, then B" means: whenever A is true, B must be true. We write it `A → B`. Here **A is the sufficient condition** (A alone guarantees B) and **B is the necessary condition** (B must hold for A to hold). The arrow always points *from* sufficient *to* necessary.
:::

"If it is a dog, then it is a mammal."

dog

→

mammal

sufficient: dog (being a dog is enough to be a mammal)

necessary: mammal (you must be a mammal to be a dog)

### Translating the tricky trigger words

The LSAT rarely says a clean "if… then." It hides conditionals behind other words. Learn these translations cold:

| Wording | Translates to | Note |
| --- | --- | --- |
| "If A, (then) B" | `A → B` | the base case |
| "A only if B" | `A → B` | "only if" introduces the *necessary* condition |
| "Only A are B" / "Only A's get in" | `B → A` | "only" marks what's necessary — arrow points *to* it |
| "All A are B" / "Every A is B" | `A → B` | same as if–then |
| "No A are B" / "None" | `A → not B` | negate the necessary side |
| "A unless B" | `not B → A` | "unless" = "if not" |
| "A requires B" | `A → B` | B is necessary for A |

:::callout-warning
The "only" rule — memorize its direction

The words **"only," "only if," and "only when"** introduce the *necessary* condition. The arrow points **toward** whatever "only" tags. "Only members may vote" → `vote → member` (voting requires membership), *not* `member → vote`. Getting the direction of "only" backward is the most common translation error on the test.
:::

:::example
Worked Example 5.1 — necessary vs. sufficient in action

standard

"To board the flight, you must have a boarding pass. Dana has a boarding pass."

**Question.** Can we conclude Dana will board the flight?

Answer: No.

**How we get there.** Translate: "To board, you must have a boarding pass" means boarding *requires* a pass, so `board → pass` (pass is *necessary*). Dana having a pass tells us the *necessary* condition is met — but a necessary condition being satisfied does **not** guarantee the sufficient one. Dana might still miss the flight, be denied boarding, etc. Having the pass is required, not enough. To validly conclude "Dana boards," we'd need a statement where the pass is *sufficient* (`pass → board`), which we don't have. This is the necessary/sufficient trap, now formalized.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reversing "only."** "Only A are B" is `B → A`, not `A → B`. Slow down every time you see "only."
- **Treating a met necessary condition as sufficient.** Satisfying the necessary side proves nothing about the sufficient side (Worked Example 5.1).
- **Mistranslating "unless."** "A unless B" = "if not B, then A" (`not B → A`). Don't guess — apply the rule.
:::

### Practice — 5.1

:::problem[Q1]{difficulty="easy"}
Translate: "All licensed drivers have passed the road test."

::::solution[Solution]
`licensed driver → passed road test`. "All A are B" is `A → B`; passing the test is the necessary condition.
::::
:::

:::problem[Q2]{difficulty="standard"}
Translate: "Only students with a 3.5 GPA are eligible for the honors program."

::::solution[Solution]
`eligible → 3.5 GPA`. "Only" tags the necessary condition (the 3.5 GPA), so the arrow points toward it. Being eligible *requires* the GPA; the GPA alone doesn't make you eligible.
::::
:::

:::problem[Q3]{difficulty="standard"}
Translate: "You won't pass the class unless you submit the final project."

::::solution[Solution]
"A unless B" = "if not B then A," with A = "won't pass," B = "submit project": `not submit → not pass`. Equivalently, passing requires submitting: `pass → submit project`. (Both are the same relationship.)
::::
:::

:::problem[Q4]{difficulty="standard"}
"To enter the lab, an ID badge is required. Kim has an ID badge." What, if anything, follows about Kim entering the lab?

::::solution[Solution]
**Nothing follows.** `enter → badge` (badge necessary). Kim meeting the necessary condition doesn't guarantee entry — she might lack other requirements. Don't treat a satisfied necessary condition as sufficient.
::::
:::

:::problem[Q5]{difficulty="challenge"}
Translate and identify sufficient/necessary: "No reptiles are warm-blooded."

::::solution[Solution]
`reptile → not warm-blooded`. Sufficient: being a reptile; necessary: *not* being warm-blooded. "No A are B" negates the necessary side. (Equivalently `warm-blooded → not reptile` — its contrapositive, coming in 5.2.)
::::
:::

## 5.2 · The contrapositive

:::callout-intuition
Intuition first

Every conditional secretly contains a second, equally-true statement — its **contrapositive**. "If it's a dog, it's a mammal" also tells you "if it's *not* a mammal, it's *not* a dog." That's not a new fact; it's the same fact viewed from the other end. The contrapositive is the LSAT's favorite tool because the correct answer to many questions is just the contrapositive of a statement in the stimulus — sitting in plain sight, but only visible if you know how to flip an arrow correctly.
:::

:::definition
**Definition 5.2 — The contrapositive.** The contrapositive of `A → B` is `not B → not A`. You form it by two moves done together: **(1) reverse** the arrow (swap the two sides) and **(2) negate** both sides. A conditional and its contrapositive are *logically identical* — always both true or both false.
:::

Original:      dog

→

mammal

Contrapositive: not mammal

→

not dog

✓ valid, same meaning

Two WRONG flips people make:

Converse:     mammal → dog

✗ reversed only, NOT negated

Inverse:      not dog → not mammal

✗ negated only, NOT reversed

:::callout-warning
Do both moves, or neither works

The contrapositive requires **both** reversing *and* negating. Do only one and you get an invalid statement: reversing alone gives the **converse** (`B → A`), negating alone gives the **inverse** (`not A → not B`). The converse and inverse are *not* guaranteed by the original — believing them is exactly the necessary/sufficient error. Only the full reverse-and-negate contrapositive is valid.
:::

### Contrapositive with "and" / "or" — flip the connector too

When a side has multiple terms, negating it also swaps **and ↔ or** (De Morgan's rule — you'll see it again in Chapter 6 and in Digital Logic):

Original:      (A

and

B) → C

Contrapositive: not C → (not A

or

not B)

and becomes or

Original:      A → (B

or

C)

Contrapositive: (not B

and

not C) → not A

or becomes and

:::example
Worked Example 5.2 — the answer is the contrapositive

standard

"If a candidate is endorsed by the union, she will win the primary."

**Question.** Which one must also be true?

- **(A)** If a candidate wins the primary, she was endorsed by the union.
- **(B)** If a candidate is not endorsed by the union, she will not win the primary.
- **(C)** If a candidate does not win the primary, she was not endorsed by the union.
- **(D)** If a candidate is endorsed by the union, she will not win the primary.
- **(E)** Winning the primary requires a union endorsement.

Answer: (C).

**How we get there.** Translate: `endorsed → win`. The contrapositive (reverse + negate) is `not win → not endorsed` — "if she doesn't win, she wasn't endorsed." That's (C), and it must be true. Now catch the traps: (A) is the **converse** (`win → endorsed`) — reversed but not negated, invalid. (B) is the **inverse** (`not endorsed → not win`) — negated but not reversed, invalid. (E) is also the converse in disguise ("winning requires endorsement" = `win → endorsed`). (D) contradicts the original. Only (C) does both moves.
:::

:::callout-pitfall
Watch out for these mistakes

- **Converse errors.** "A → B" does not give "B → A." This is the most common wrong answer on conditional questions — and it's just the necessary/sufficient confusion again.
- **Inverse errors.** "A → B" does not give "not A → not B." Negating without reversing is equally invalid.
- **Forgetting De Morgan.** When negating an "and"/"or" side, flip the connector. "(A and B)" negates to "(not A or not B)."
:::

### Practice — 5.2

:::problem[Q1]{difficulty="easy"}
Give the contrapositive of `rain → wet ground`.

::::solution[Solution]
`not wet ground → not rain` ("if the ground isn't wet, it didn't rain"). Reverse and negate both sides.
::::
:::

:::problem[Q2]{difficulty="standard"}
"If you are a citizen, you may vote." A person may not vote. What follows?

::::solution[Solution]
`citizen → may vote`; contrapositive `not may-vote → not citizen`. Since the person may not vote, **they are not a citizen**. (Do not conclude the converse — that anyone who may vote is a citizen.)
::::
:::

:::problem[Q3]{difficulty="standard"}
Identify each as contrapositive (valid), converse (invalid), or inverse (invalid) of `A → B`: (i) `not A → not B`; (ii) `not B → not A`; (iii) `B → A`.

::::solution[Solution]
(i) **inverse** — invalid. (ii) **contrapositive** — valid. (iii) **converse** — invalid. Only (ii) reverses *and* negates.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Give the contrapositive of `(hired) → (interview and reference check)`.

::::solution[Solution]
`(not interview OR not reference check) → not hired`. Reverse the arrow, negate both sides, and by De Morgan the "and" on the necessary side becomes "or." In words: if someone *either* wasn't interviewed *or* wasn't reference-checked, they weren't hired.
::::
:::

:::problem[Q5]{difficulty="challenge"}
"Only applicants who submit both a portfolio and a résumé are considered." A person was considered. What can you conclude, and via which tool?

::::solution[Solution]
"Only… both X and Y are considered" → `considered → (portfolio AND résumé)`. The person was considered (sufficient met), so directly: **they submitted both a portfolio and a résumé.** Here you apply the conditional *forward* (not the contrapositive), since the sufficient condition "considered" is satisfied. Recognizing which direction to run is the skill.
::::
:::

## 5.3 · Quantifiers: some, most, all, none

:::callout-intuition
Intuition first

Conditionals are about *all* ("every dog is a mammal"). But the LSAT also reasons with **some** and **most**, and these behave differently — they don't chain the way "all" does, and they have their own rules for what you can and can't infer. Precise meanings matter: on the LSAT, "some" means "at least one," and "most" means "more than half." Read them loosely and you'll accept invalid inferences that feel true.
:::

:::definition
**Definition 5.3 — The three quantifiers.**

- **All A are B** — every single A is a B. This is the conditional `A → B`.
- **Most A are B** — *more than half* of A's are B (could be 51% or 100%).
- **Some A are B** — *at least one* A is a B (could be one, could be all). "Some" is symmetric: "some A are B" also means "some B are A."

**None / no A are B** — zero overlap: `A → not B`.
:::

### What you can and cannot infer

| Given | Valid inference | Invalid (do NOT infer) |
| --- | --- | --- |
| Some A are B | Some B are A | Most/All A are B; some A are *not* B |
| Most A are B | Some A are B; some B are A | Most B are A; all A are B |
| All A are B | Some A are B; not-B → not-A | All B are A (converse) |
| No A are B | No B are A; A → not B | anything about A's relation to non-B categories |

:::callout-key
The one chaining rule worth memorizing

You *can* combine two statements when they share a term and at least one is "all," or when a "most" and an "all" overlap the right way. The cleanest reliable chains: `All A→B` plus `All B→C` gives `All A→C`. And `Most A are B` plus `All B are C` gives `Most A are C`. But **two "some" statements never chain, and two "most" statements never chain** — that's the trap. "Most A are B" and "most B are C" tells you *nothing* guaranteed about A and C.
:::

:::example
Worked Example 5.3 — why "most + most" fails

challenge

"Most of the volunteers are students. Most of the students are local residents."

**Question.** Does it follow that most of the volunteers are local residents?

Answer: No — it does not follow.

**How we get there.** "Most" means "more than half." Picture 100 volunteers; "most are students" could mean exactly 51 are students. "Most of the students are local" refers to *all* students (a much bigger group, most of the school), only some of whom are among your 51 volunteer-students. It's entirely possible that the local students barely overlap with your 51 volunteer-students, so that *few* volunteers are local. Because the two "most" groups can dodge each other, **most + most does not chain.** To make it valid you'd need an "all" — e.g., "*all* students are local" would give "most volunteers are local."
:::

:::callout-pitfall
Watch out for these mistakes

- **Chaining two "some" or two "most" statements.** Neither is valid. You need an "all" to bridge reliably.
- **Reading "some" as "some but not all."** "Some" allows *all* — "some students passed" is true even if every student passed. Don't infer that some didn't.
- **Reading "most" as "almost all."** "Most" can be a bare 51%. Don't inflate it.
- **Forgetting "some" is symmetric.** "Some A are B" always gives "some B are A."
:::

### Practice — 5.3

:::problem[Q1]{difficulty="easy"}
"Some engineers are painters." Which follows: (a) some painters are engineers; (b) most engineers are painters; (c) some engineers are not painters?

::::solution[Solution]
Only **(a)**. "Some" is symmetric, so some painters are engineers. (b) overstates; (c) doesn't follow — "some are" is compatible with "all are."
::::
:::

:::problem[Q2]{difficulty="standard"}
"All members pay dues. Most members attend meetings." Can you conclude that some dues-payers attend meetings?

::::solution[Solution]
**Yes.** Members all pay dues, and most members attend — so those attending members are dues-payers, giving "some dues-payers attend meetings." (An "all" statement bridges to the "most" group validly.)
::::
:::

:::problem[Q3]{difficulty="standard"}
"Most cats in the shelter are black. Most black cats in the shelter are microchipped." Does it follow that most cats in the shelter are microchipped?

::::solution[Solution]
**No.** Two "most" statements don't chain. The microchipped black cats might be a subset that doesn't cover a majority of all shelter cats. You'd need an "all" to force the conclusion.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"All A are B. Some A are C." What, if anything, can you validly infer about B and C?

::::solution[Solution]
**Some B are C** (equivalently some C are B). The A's that are C are also B (since all A are B), so there's overlap between B and C. You cannot say most or all B are C. (This "all + some sharing the 'all' term" chain is valid because every A carries its B-membership along.)
::::
:::

:::problem[Q5]{difficulty="standard"}
Why is "some students are athletes; some athletes are seniors; therefore some students are seniors" invalid?

::::solution[Solution]
Because **two "some" statements never chain**. The student-athletes and the senior-athletes could be entirely different athletes, so there's no guaranteed student who is a senior. "Some" only asserts at-least-one overlap, not a shared member across both links.
::::
:::

## 5.4 · Diagramming and chaining

:::callout-intuition
Intuition first

When a stimulus stacks several conditionals, your working memory can't hold them all straight — so you write them as arrows and *link* them into a chain. Once chained, valid conclusions fall out mechanically: anything upstream forces everything downstream, and you can read the contrapositive by walking the chain backward. Diagramming turns a paragraph that feels like a knot into a single line you can trace with your finger.
:::

### Building a chain

Conditionals link when the necessary term of one is the sufficient term of the next:

Given: A → B,   B → C,   C → D

Chain: A

→

B

→

C

→

D

Read forward: A guarantees B, C, and D.

Read the contrapositive backward:

not D → not C → not B → not A

:::definition
**Definition 5.4 — Valid chain inference.** In a chain `A → B → C → D`: if you know any term is *true*, every term to its **right** (downstream, its necessary conditions) must be true. If you know any term is *false*, every term to its **left** (upstream) must be false — that's the contrapositive read backward. You may *not* travel the other way: knowing D is true tells you nothing about A; knowing A is false tells you nothing about D.
:::

:::example
Worked Example 5.4 — chaining several statements

challenge

"Anyone who is promoted receives a raise. Anyone who receives a raise must be reviewed by HR. No one reviewed by HR is a probationary employee."

**Question.** Which one must be true?

- **(A)** Some probationary employees receive raises.
- **(B)** Everyone reviewed by HR receives a raise.
- **(C)** Anyone reviewed by HR has been promoted.
- **(D)** No probationary employee has been promoted.
- **(E)** Anyone who receives a raise has been promoted.

Answer: (D).

**How we get there.** Diagram each: `promoted → raise`; `raise → HR review`; `HR review → not probationary`. Chain them:

promoted

→

raise

→

HR review

→

not probationary

So `promoted → not probationary`. Contrapositive: `probationary → not promoted` — "no probationary employee has been promoted." That's (D). The traps (C), (E), (B) all travel the chain *backward* illegitimately (converse errors — e.g., "reviewed by HR → promoted" reverses the arrows), and (A) contradicts the chain (probationary employees can't get raises, since raise → HR review → not probationary). Only (D) follows.
:::

:::callout-tip
A practical shorthand

Use short abbreviations (P for promoted, R for raise) and stack contrapositives beneath as needed. You don't need a formal system — just consistent arrows you can trust. The goal is to *offload* the logic from your head onto the page so your reasoning has room to work. Speed comes with reps; accuracy comes first.
:::

:::callout-pitfall
Watch out for these mistakes

- **Traveling the chain backward.** Downstream from true, upstream from false — never the reverse. Backward travel is the converse/inverse error dressed up in a chain.
- **Linking on the wrong term.** Two conditionals only chain when one's necessary term equals the other's sufficient term. `A→B` and `C→B` do *not* chain (they share the necessary term, not a link).
- **Dropping "and/or" during contrapositives** when walking a chain backward. Keep De Morgan in mind on branched terms.
:::

### Practice — 5.4

:::problem[Q1]{difficulty="standard"}
Given `X → Y` and `Y → Z`, and that X is true, what follows?

::::solution[Solution]
**Y and Z are both true.** X forces everything downstream: X → Y → Z.
::::
:::

:::problem[Q2]{difficulty="standard"}
Same chain `X → Y → Z`. You learn Z is false. What follows?

::::solution[Solution]
**Y is false and X is false** (walk the contrapositive backward: not Z → not Y → not X). Knowing the downstream term is false kills everything upstream.
::::
:::

:::problem[Q3]{difficulty="standard"}
Same chain. You learn Z is *true*. What follows about X and Y?

::::solution[Solution]
**Nothing.** Z being true doesn't force Y or X (that would be traveling backward from a true term — a converse error). Z could be true for other reasons.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Diagram and find what must be true: "All jazz musicians read music. Anyone who reads music understands rhythm. Pat does not understand rhythm."

::::solution[Solution]
Chain: `jazz musician → reads music → understands rhythm`. Pat lacks the downstream term (rhythm), so walk back: not rhythm → not reads music → **not a jazz musician**. Conclusion: **Pat is not a jazz musician.**
::::
:::

:::problem[Q5]{difficulty="challenge"}
Do `A → B` and `C → B` chain into a conclusion linking A and C? Why or why not?

::::solution[Solution]
**No.** They share the *necessary* term B, not a sufficient-necessary link, so there's no path from A to C or C to A. (Both lead *into* B, but B doesn't lead out to either.) Chaining requires one statement's necessary term to be the next's sufficient term.
::::
:::

## 5.5 · Common valid & invalid argument forms

:::callout-intuition
Intuition first

Conditional questions reuse a small set of argument *shapes*. Two are valid; two are classic fallacies with names. If you memorize these four, you can judge a huge fraction of conditional arguments instantly — and Parallel Reasoning questions (Chapter 12) often just ask you to match one of these shapes.
:::

:::definition
**The four forms of `A → B` reasoning.**

- **Modus ponens (valid):** `A → B`; A is true; therefore B. Affirm the sufficient → get the necessary.
- **Modus tollens (valid):** `A → B`; B is false; therefore not A. Deny the necessary → deny the sufficient (the contrapositive).
- **Affirming the consequent (invalid):** `A → B`; B is true; therefore A. The converse error.
- **Denying the antecedent (invalid):** `A → B`; A is false; therefore not B. The inverse error.
:::

VALID

A→B,  A  &there4; B

modus ponens

VALID

A→B,  not B  &there4; not A

modus tollens

WRONG

A→B,  B  &there4; A

affirming the consequent (converse)

WRONG

A→B,  not A  &there4; not B

denying the antecedent (inverse)

:::example
Worked Example 5.5 — name the form

standard

"If the alarm is working, it will sound when smoke is detected. The alarm did not sound when smoke was detected. So the alarm was not working."

**Question.** Is the reasoning valid, and what is the form?

Answer: Valid — modus tollens.

**How we get there.** Translate: `working → sounds`. The argument denies the necessary condition ("did not sound"), then concludes the sufficient is false ("not working"). That's `A → B`, not B, therefore not A — modus tollens, the contrapositive in argument form. Valid. Compare the invalid twin: if it had said "the alarm sounded, so it was working" (`B, therefore A`), that would be affirming the consequent — a false-alarm could sound too. Same sentence-parts, opposite validity, depending on which condition is affirmed or denied.
:::

:::callout-connect
Connects forward

These four forms power several later chapters: **Flaw** questions (Chapter 9) frequently hinge on spotting affirming-the-consequent or denying-the-antecedent; **Parallel Reasoning** (Chapter 12) asks you to match a form; and **Sufficient Assumption** questions (Chapter 7) are often solved by supplying the conditional that makes a modus ponens complete. This section is a hub, not a footnote.
:::

:::callout-pitfall
Watch out for these mistakes

- **Confusing modus tollens with denying the antecedent.** Denying the *necessary* side (not B) is valid; denying the *sufficient* side (not A) is not.
- **Accepting affirming the consequent** because it "sounds reasonable." "B is true, so A" ignores that B could arise other ways.
- **Not translating first.** You can't classify the form until you've turned the sentences into `A → B` with the arrow pointing correctly (mind the "only" rule from 5.1).
:::

### Practice — 5.5

:::problem[Q1]{difficulty="easy"}
"If it's Sunday, the store is closed. It's Sunday. So the store is closed." Valid? Name the form.

::::solution[Solution]
**Valid — modus ponens** (`A→B`, A, therefore B). Affirming the sufficient condition yields the necessary one.
::::
:::

:::problem[Q2]{difficulty="standard"}
"If it's Sunday, the store is closed. The store is closed. So it's Sunday." Valid? Name the form.

::::solution[Solution]
**Invalid — affirming the consequent** (the converse). The store could be closed for other reasons (a holiday, night hours). B doesn't give A.
::::
:::

:::problem[Q3]{difficulty="standard"}
"If a plant is a cactus, it stores water. This plant is not a cactus. So it does not store water." Valid? Name the form.

::::solution[Solution]
**Invalid — denying the antecedent** (the inverse). Non-cactus plants can store water too. Denying the sufficient side proves nothing about the necessary side.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"Only registered users can post comments. This account posted a comment. Therefore this account is registered." Valid? Name the form.

::::solution[Solution]
**Valid — modus ponens.** Translate the "only": `post → registered` (registration is necessary to post). The account posted (affirms the sufficient condition "post"), so it's registered. The tricky part is the correct translation; once `post → registered` is set, affirming "post" gives "registered."
::::
:::

:::problem[Q5]{difficulty="challenge"}
Explain why modus tollens and denying the antecedent are so easily confused, and give the one-line test to tell them apart.

::::solution[Solution]
Both start from `A→B` and involve a negation, so they look similar. The test: **which condition are you negating?** Modus tollens negates the *necessary* condition (not B) → valid (not A). Denying the antecedent negates the *sufficient* condition (not A) → invalid. Negate the arrow's *head* (necessary) = valid; negate its *tail* (sufficient) = fallacy.
::::
:::

## Chapter summary

:::summary
#### The formal-logic toolkit

- **Translate to arrows.** `A → B`: A sufficient, B necessary. "Only"/"only if" tag the necessary side; "unless" = "if not."
- **Contrapositive = reverse + negate** (and flip and↔or). It's always valid and often *is* the answer. Converse and inverse are traps.
- **Quantifiers:** some = at least one (symmetric); most = >half; all = conditional. Two "some" or two "most" never chain — you need an "all."
- **Chains:** downstream from a true term, upstream (contrapositive) from a false term — never backward.
- **Four forms:** modus ponens & modus tollens (valid); affirming the consequent & denying the antecedent (invalid).
:::

| Statement | Symbol | Valid partner |
| --- | --- | --- |
| If A then B | `A → B` | contrapositive `not B → not A` |
| A only if B | `A → B` | — |
| Only A are B | `B → A` | — |
| A unless B | `not B → A` | — |
| No A are B | `A → not B` | `B → not A` |

## Mixed practice set

Fourteen items across the chapter, mixed order and difficulty. Translate first, then reason.

:::problem[1]{difficulty="easy"}
Translate: "Every winner receives a medal."

::::solution[Solution]
`winner → medal`. (Contrapositive: `no medal → not a winner`.)
::::
:::

:::problem[2]{difficulty="standard"}
Translate: "Only ticket-holders may enter."

::::solution[Solution]
`enter → ticket-holder`. "Only" marks the necessary condition; the arrow points to it.
::::
:::

:::problem[3]{difficulty="standard"}
Contrapositive of `signed → valid`?

::::solution[Solution]
`not valid → not signed`.
::::
:::

:::problem[4]{difficulty="standard"}
"If it's fresh, it's not frozen. This item is frozen." What follows?

::::solution[Solution]
`fresh → not frozen`; contrapositive `frozen → not fresh`. It's frozen, so **it's not fresh** (modus ponens on the contrapositive).
::::
:::

:::problem[5]{difficulty="easy"}
"Some doctors are runners." Which must be true — some runners are doctors, or most doctors are runners?

::::solution[Solution]
**Some runners are doctors** ("some" is symmetric). "Most" doesn't follow from "some."
::::
:::

:::problem[6]{difficulty="challenge"}
"Most of the staff are part-time. Most part-time workers are students." Does most of the staff being students follow?

::::solution[Solution]
**No** — most + most doesn't chain. The student part-timers needn't overlap enough with the staff's part-timers to cover a majority of staff. Needs an "all" to bridge.
::::
:::

:::problem[7]{difficulty="standard"}
Name the form: "If hired, you passed the exam. You passed the exam. So you were hired."

::::solution[Solution]
**Affirming the consequent — invalid.** Passing is necessary, not sufficient; you could pass yet not be hired. (Converse error.)
::::
:::

:::problem[8]{difficulty="standard"}
Name the form: "If hired, you passed the exam. You did not pass. So you were not hired."

::::solution[Solution]
**Modus tollens — valid.** `hired → passed`; not passed, therefore not hired (the contrapositive).
::::
:::

:::problem[9]{difficulty="challenge"}
Contrapositive of `(member and paid) → access`?

::::solution[Solution]
`not access → (not member OR not paid)`. Reverse, negate, and turn "and" into "or" (De Morgan).
::::
:::

:::problem[10]{difficulty="standard"}
Chain `P → Q`, `Q → R`. You learn R is false. What follows?

::::solution[Solution]
**Q is false and P is false.** Walk the contrapositive backward: not R → not Q → not P.
::::
:::

:::problem[11]{difficulty="standard"}
"All A are B. Some C are A." What follows about B and C?

::::solution[Solution]
**Some C are B** (and some B are C). The C's that are A must be B, creating overlap between C and B. No stronger claim (most/all) is warranted.
::::
:::

:::problem[12]{difficulty="challenge"}
"Only applicants who interviewed were hired. Rosa was hired. Anyone who interviewed met the manager." What must be true about Rosa?

::::solution[Solution]
Translate: `hired → interviewed`; `interviewed → met manager`. Chain: `hired → interviewed → met manager`. Rosa was hired, so downstream: **Rosa interviewed and met the manager.**
::::
:::

:::problem[13]{difficulty="challenge"}
Why does "A unless B" translate to `not B → A` rather than `A → not B`? Give a concrete check.

::::solution[Solution]
"Unless" means "if not." "You'll be late unless you leave now" = "if you do *not* leave now, you'll be late" = `not leave → late`. Check the other reading (`late → not leave`): that would say being late implies you didn't leave, which garbles the meaning. The rule "unless = if not, negate the unless-clause and make it sufficient" gives the correct `not B → A`.
::::
:::

:::problem[14]{difficulty="challenge"}
In one or two sentences, explain how this chapter dissolves the "necessary/sufficient confusion" flaw from Chapter 4.

::::solution[Solution]
By forcing every conditional into an arrow with a fixed direction (sufficient → necessary), you can no longer accidentally run it backward: affirming the necessary side (converse) or denying the sufficient side (inverse) are visibly invalid on the diagram. The confusion that felt like a subtle judgment call becomes a mechanical check — does the inference travel the arrow the legal way (modus ponens/tollens) or the illegal way?
::::
:::

LSAT Mastery — Chapter 5. Independent study material, not affiliated with LSAC. Practice questions are original. Diagramming systems vary; use whatever notation you can apply consistently and quickly.
