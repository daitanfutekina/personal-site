---
title: "Assumption Questions"
source: "lsat_ch7_assumption.html"
---

Part II · Chapter 7

# Assumption Questions

The most fundamental question type — and the one that most rewards everything you built in Chapters 4–6. Learn to name what an argument silently takes for granted, and to prove your answer with the single most powerful tool in Logical Reasoning: the negation test.

**Est. study time:** 70–85 min — **Sections:** 4 — **Practice:** 24+ items

## Overview

An *assumption* is the unstated premise an argument needs to work — the plank the author quietly lays across the gap you learned to find in Chapter 4. Assumption questions ask you to identify that plank. There are two flavors, and they are genuinely different: **necessary** assumptions (something the argument *needs* to be true) and **sufficient** assumptions (something that, if added, would make the conclusion airtight). Confusing them is the number-one source of missed points here, so we'll build each carefully and then draw the line between them.

This chapter also gives you the **negation test** — a mechanical procedure that turns necessary-assumption questions from judgment calls into near-certainties. Master it and a whole category of "I narrowed it to two" agony disappears.

:::callout-tip
Prerequisites

Chapter 4 (gap/assumption, the six-step method), Chapter 5 (conditional logic, especially bridging terms), and Chapter 6 (flaws as flawed assumptions). Assumption questions are where those three chapters converge.
:::

## 7.1 · Necessary assumptions

:::callout-intuition
Intuition first

A **necessary assumption** is something the argument absolutely *requires* — if it turned out to be false, the argument would fall apart. Think of it as a load-bearing wall: it might not be enough to hold up the whole house by itself, but remove it and the house collapses. Necessary-assumption questions ask: "what does this argument *depend on* being true, even though it never says so?"
:::

:::definition
**Definition 7.1 — Necessary assumption.** A statement the argument *must* rely on for its conclusion to hold. It is *required* but not necessarily *enough*. Question stems: "depends on assuming," "requires which assumption," "is an assumption on which the argument relies," "the argument presupposes that…"
:::

### The character of a necessary assumption: often modest

Because a necessary assumption only has to be *required*, it's frequently a small, defensive statement — often ruling out a specific objection. Two common shapes:

- **"No alternative" assumptions:** "nothing else explains the result," "there's no other relevant difference." (You saw these as the denials of the causal flaw in Chapter 6.)
- **"Link" assumptions:** a minimal connection between a term in the premises and a term in the conclusion ("the survey respondents are representative," "profit tracks the sales mentioned").

:::callout-warning
The giveaway: necessary assumptions are usually weakly worded

Because they only need to be *required*, correct necessary assumptions tend to use cautious language — "at least some," "not entirely," "there is no reason to think otherwise." Overly strong answers ("X is *always* true," "X is the *only* cause") are usually *too strong* to be merely necessary and are common traps. When choosing, lean toward the modest option — then confirm with the negation test.
:::

### The negation test — your most powerful tool

:::definition
**The negation test.** To check whether a choice is a necessary assumption: **negate it** (make it false) and ask whether the argument still works. *If negating the choice destroys the argument, the choice is a necessary assumption.* If the argument survives the negation, the choice is not necessary. Exactly one answer, when negated, wrecks the argument — that's your answer.
:::

:::callout-tip
How to negate correctly

Negate the *logical force*, not by adding melodrama. "All Xs are Y" negates to "**not all** Xs are Y" (i.e., at least one isn't) — not to "no Xs are Y." "The plan will succeed" negates to "the plan will **not** succeed." "At least some" negates to "none." Soft negation of the exact claim is what the test needs; over-negating gives wrong results.
:::

:::example
Worked Example 7.1 — negation in action

standard

"The city's new bike lanes will reduce traffic congestion. After all, they will encourage many commuters to bike instead of drive."

**Stem.** The argument depends on assuming which one of the following?

- **(A)** The bike lanes are inexpensive to build.
- **(B)** Most commuters already own bicycles.
- **(C)** Biking is the fastest way to commute in the city.
- **(D)** Biking is healthier than driving.
- **(E)** The commuters who switch to biking would otherwise have added to traffic congestion.

Answer: (E).

**How we get there.** Conclusion: bike lanes will reduce *congestion*. Premise: they'll get many commuters to bike instead of drive. Gap: the switchers must be people who were *contributing to congestion* — if they biked from areas that were never congested, or were already taking the bus, switching them wouldn't cut congestion. Now the negation test on (E): negate it to "the commuters who switch would *not* otherwise have added to congestion." If that's true, then removing them from the roads does nothing for congestion — the argument collapses. Because negating (E) destroys the argument, (E) is necessary. Check a trap: negate (D) — "biking is not healthier than driving" — the congestion argument is untouched, so (D) isn't necessary. Same for (A), (B), (C). **Teaching point:** the negation test converted a plausible-sounding field of five into one certainty.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking an answer that "helps" but isn't required.** A necessary assumption isn't just supportive — the argument must *need* it. Test with negation.
- **Choosing too-strong answers.** Necessary assumptions are usually modest; extreme wording often over-commits beyond what's required.
- **Over-negating.** "Most" negates to "not most" (i.e., half or fewer), not to "none." Botch the negation and you'll misjudge the answer.
- **Bringing in outside plausibility.** An answer can be true and relevant-sounding yet unnecessary. Only the negation test settles it.
:::

### Practice — 7.1

:::problem[Q1]{difficulty="easy"}
State the negation test in one sentence.

::::solution[Solution]
Negate the answer choice; if doing so **destroys the argument**, the choice is a necessary assumption (if the argument survives, it isn't).
::::
:::

:::problem[Q2]{difficulty="standard"}
Negate correctly: "All of the store's suppliers are local."

::::solution[Solution]
"**Not all** of the store's suppliers are local" (equivalently, at least one supplier is not local). Not "none are local" — that over-negates.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Our ad campaign caused sales to rise, since sales grew during the campaign." A necessary assumption is that no other factor caused the sales growth. Apply the negation test to confirm.

::::solution[Solution]
Negate it: "**another factor did** cause the sales growth." If that's true, the campaign isn't established as the cause, and the causal conclusion fails — the argument collapses. Since the negation destroys it, "no other factor caused the growth" is a necessary assumption. (This is the causal flaw's assumption from Ch 6.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why are correct necessary assumptions often *weakly* worded, and how does that guide answer choice?

::::solution[Solution]
Because a necessary assumption only needs to be **required**, not sufficient — so the minimal claim that the argument can't do without is usually a modest one (e.g., "there is *at least some* connection," "*nothing else* fully accounts for it"). Strong/absolute answers typically assert more than the argument strictly needs, making them too strong to be merely necessary. Guidance: prefer the modest choice, then verify by negation.
::::
:::

## 7.2 · Sufficient assumptions

:::callout-intuition
Intuition first

A **sufficient assumption** is the opposite temperament from a necessary one. Instead of "the minimum the argument needs," it's "enough to *guarantee* the conclusion." If you drop a sufficient assumption into the argument as a new premise, the conclusion follows with certainty — the gap is fully sealed. Sufficient-assumption answers are often *strong*, even sweeping, because their job is to make the reasoning airtight, not to be minimally required.
:::

:::definition
**Definition 7.2 — Sufficient assumption.** A statement that, if added to the premises, makes the conclusion follow *necessarily* (validly). It need not be required by the argument; it just has to be *enough*. Question stems: "which one, if assumed, allows the conclusion to be properly drawn," "the conclusion follows logically if which one is assumed," "which, if true, enables the conclusion to be validly inferred."
:::

### The technique: build the bridge between premise and conclusion

Sufficient-assumption questions are usually *conditional-logic* problems (Chapter 5). The recipe:

1. Diagram the premise(s) as arrows and identify the conclusion's arrow.
2. Find the **new term** in the conclusion that the premises never connected.
3. The answer is the conditional that **links the loose end of the premises to the conclusion's term** — completing a valid chain (usually a modus ponens).

:::example
Worked Example 7.2 — bridging the gap

standard

"Anyone who exercises regularly sleeps well. So Dana sleeps well."

**Stem.** The conclusion follows logically if which one is assumed?

- **(A)** Dana exercises regularly.
- **(B)** Some people who sleep well exercise regularly.
- **(C)** Dana wants to sleep well.
- **(D)** People who sleep well exercise regularly.
- **(E)** Most people who exercise regularly are healthy.

Answer: (A).

**How we get there.** Diagram the premise: `exercises → sleeps well`. The conclusion is "Dana sleeps well." To reach it via modus ponens, we need Dana to satisfy the sufficient condition — i.e., `Dana exercises`. Add (A): "Dana exercises regularly," and the chain completes: Dana exercises → Dana sleeps well. Conclusion guaranteed. Check traps: (D) is the *converse* (`sleeps well → exercises`) — wrong direction, doesn't help. (B) "some" can't force a conclusion about Dana specifically. (C) and (E) are irrelevant. **Teaching point:** a sufficient assumption *completes a valid form*; here it supplied the missing premise of a modus ponens.
:::

:::example
Worked Example 7.3 — linking two loose terms

challenge

"Every course Dr. Reyes teaches is challenging. So this course will improve students' critical thinking."

**Stem.** The conclusion follows logically if which one is assumed?

- **(A)** This course is not easy.
- **(B)** This course is taught by Dr. Reyes, and every challenging course improves critical thinking.
- **(C)** Some challenging courses improve critical thinking.
- **(D)** Dr. Reyes wants students to think critically.
- **(E)** Courses that improve critical thinking are challenging.

Answer: (B).

**How we get there.** The premise gives `Reyes-taught → challenging`; the conclusion is about `this course → improves critical thinking`. Two loose ends: we must (1) establish this course is Reyes-taught (to use the premise) and (2) link "challenging" to "improves critical thinking." (B) supplies *both*: this course is Reyes-taught (so it's challenging), and *every* challenging course improves critical thinking (so it does). Chain: `this course → Reyes-taught → challenging → improves critical thinking`. Airtight. Note (B) is *strong* ("every challenging course") — that's fine and typical for sufficient assumptions; strength is what guarantees validity. (E) reverses the needed link; (C) "some" can't guarantee; (A) is too weak. **Teaching point:** when there are two gaps, the sufficient assumption often closes both at once, and it's allowed to be sweeping.
:::

:::callout-pitfall
Watch out for these mistakes

- **Rejecting an answer for being "too strong."** Strength is a virtue here — a sufficient assumption must be *enough*, so sweeping "all/every" statements are often correct (the opposite of necessary-assumption instincts).
- **Picking the converse.** The bridge must point *from* the premises' loose end *to* the conclusion's term. Reversed links (a common trap) don't complete the chain.
- **Settling for "some."** "Some X are Y" rarely guarantees a specific conclusion; sufficient assumptions usually need "all/every" to force validity.
- **Not diagramming.** These are conditional puzzles; arrows make the missing link obvious.
:::

### Practice — 7.2

:::problem[Q1]{difficulty="standard"}
"All of Mia's paintings are abstract. So this painting will sell quickly." Which sufficient assumption completes it?

::::solution[Solution]
Something like: "**This is one of Mia's paintings, and all abstract paintings sell quickly**." That gives `this → Mia's → abstract → sells quickly`. It supplies the membership *and* the missing link, guaranteeing the conclusion.
::::
:::

:::problem[Q2]{difficulty="standard"}
Premise `volunteer → background check`; conclusion "Rafael had a background check." What sufficient assumption is needed?

::::solution[Solution]
**"Rafael is a volunteer."** Then modus ponens: Rafael volunteer → background check. (Note: "everyone with a background check is a volunteer" would be the converse and wouldn't work.)
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is a sufficient assumption allowed to be a sweeping "all/every" statement when a necessary assumption usually isn't?

::::solution[Solution]
Because its job differs: a sufficient assumption must be **enough to guarantee** the conclusion, and only strong, universal links force validity. A necessary assumption must be **required**, and the argument rarely *needs* a sweeping claim — a modest one usually suffices, so strong wording tends to be more than necessary.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Premise `A → B`; conclusion `A → D`. What single conditional, added, makes the conclusion valid?

::::solution[Solution]
`B → D`. Then `A → B → D` chains to `A → D`. The sufficient assumption links the premise's necessary term (B) to the conclusion's new term (D), completing the chain in the correct direction. (`D → B` would be the reversed trap.)
::::
:::

## 7.3 · Telling the two apart

:::callout-intuition
Intuition first

The whole game is reading the stem correctly, because the two question types reward *opposite* instincts. Necessary asks "what does the argument *need*?" — favoring modest, defensive answers, verified by negation. Sufficient asks "what would make it *airtight*?" — favoring strong, bridge-building answers, verified by plugging in and checking validity. Grab the wrong instinct and you'll eliminate the right answer.
:::

|  | Necessary assumption | Sufficient assumption |
| --- | --- | --- |
| **Question asks** | What must be true for the argument to work? | What would *guarantee* the conclusion? |
| **Stem cues** | "depends on," "requires," "relies on," "presupposes" | "if assumed, allows/enables the conclusion," "follows logically if" |
| **Answer strength** | usually modest/weak | usually strong/sweeping |
| **How to verify** | negation test (negate → argument dies) | plug in → conclusion follows validly |
| **Must it be required?** | Yes | No (only enough) |
| **Must it be enough?** | No | Yes |

:::callout-key
The one-line discriminator

Read the stem's verb. **"Depends on / requires / relies on"** → necessary (negate to test). **"If assumed, the conclusion follows / is properly drawn"** → sufficient (add it and check validity). Tattoo this on your process; it prevents the most common assumption-question error.
:::

:::example
Worked Example 7.4 — same argument, two questions

challenge

"The new policy will cut emissions, because it taxes the largest polluters."

**Necessary version.** "The argument depends on assuming which one?" → a modest answer like *"Taxing the largest polluters will lead at least some of them to reduce emissions (rather than, say, all simply paying the tax and polluting the same)."* Negate it — "taxing them will *not* reduce any emissions" — and the argument dies. Required.

**Sufficient version.** "The conclusion follows logically if which one is assumed?" → a strong answer like *"Any policy that taxes the largest polluters cuts emissions."* Plug it in: this policy taxes the largest polluters, and *any* such policy cuts emissions, so it cuts emissions. Airtight. Enough.

Same stimulus, opposite answer profiles: the necessary one is a hedged minimum; the sufficient one is a sweeping guarantee.

**Teaching point:** notice you would *reject* the sufficient answer on the necessary question (too strong — the argument doesn't need *every* such policy to work) and *reject* the necessary answer on the sufficient question (too weak — "at least some" doesn't guarantee the conclusion). The stem decides everything.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reading the stem carelessly.** The single most costly error in this chapter. Identify necessary vs. sufficient *before* evaluating answers.
- **Applying the negation test to a sufficient question.** It's a necessary-assumption tool. For sufficient, plug in and check validity instead.
- **Letting "strength bias" leak across types.** Modest instinct is right for necessary, wrong for sufficient — and vice versa.
:::

### Practice — 7.3

:::problem[Q1]{difficulty="easy"}
Stem: "The argument relies on which assumption?" Which type, and which verification tool?

::::solution[Solution]
**Necessary** ("relies on"). Verify with the **negation test**.
::::
:::

:::problem[Q2]{difficulty="easy"}
Stem: "The conclusion is properly drawn if which one is assumed?" Which type, and tool?

::::solution[Solution]
**Sufficient**. Verify by **adding it and checking that the conclusion follows validly**.
::::
:::

:::problem[Q3]{difficulty="standard"}
On a *necessary* question, you're torn between "at least some customers were influenced by the ad" and "all customers were influenced by the ad." Which is likelier correct and why?

::::solution[Solution]
The **modest** one ("at least some"). A necessary assumption need only be required; "all" is usually stronger than the argument needs. Negation confirms: "no customers were influenced" (negation of "at least some") tends to kill the argument, while negating "all" ("not all were influenced") often leaves it standing.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Explain why an answer can be a *sufficient* assumption but not a *necessary* one for the same argument.

::::solution[Solution]
Because "enough" and "required" differ. A sweeping claim like "*every* policy of this kind works" would **guarantee** the conclusion (sufficient), but the argument doesn't **need** that much — it only needs "this policy works." So negating the sweeping claim ("not every such policy works") leaves the argument intact, showing it isn't necessary. Sufficient ⊃ more than necessary requires.
::::
:::

## 7.4 · Drill set

Twelve full assumption questions in mixed order — some necessary, some sufficient. **First identify the type from the stem**, then apply the right tool (negation vs. plug-in). Difficulty rises through the set.

:::problem[1]{difficulty="easy"}
"The restaurant will lose money this year, because its costs have risen sharply." *The argument depends on assuming which one?*

- **(A)** The owner plans to close the restaurant.
- **(B)** The restaurant's costs have risen more sharply than those of its competitors.
- **(C)** The restaurant's revenue will not rise enough to offset the higher costs.
- **(D)** The restaurant serves expensive dishes.
- **(E)** All restaurants in the area are struggling.

::::solution[Solution]
**(C)** — necessary ("depends on"). Negate: "revenue *will* rise enough to offset costs" → the restaurant might not lose money → argument dies. Required. Rising costs alone don't imply losses unless revenue doesn't keep up.
::::
:::

:::problem[2]{difficulty="standard"}
"All members of the committee are lawyers. So Ken must follow the bar's ethics rules." *The conclusion follows logically if which one is assumed?*

- **(A)** Ken wants to join the committee.
- **(B)** Ken is a member of the committee, and some lawyers must follow the bar's ethics rules.
- **(C)** Anyone who follows the ethics rules is a lawyer.
- **(D)** Ken is a member of the committee, and all lawyers must follow the bar's ethics rules.
- **(E)** Some committee members follow the ethics rules.

::::solution[Solution]
**(D)** — sufficient. Chain: Ken on committee → lawyer (given) → follows ethics rules (added). Guarantees the conclusion. (C) is the converse; (E) "some" can't force it.
::::
:::

:::problem[3]{difficulty="standard"}
"Our town should build the new library; a survey shows most residents want more public spaces." *Which is an assumption the argument requires?*

- **(A)** The library will be the largest in the county.
- **(B)** Most residents who want more public spaces would use the new library.
- **(C)** No resident opposes the library.
- **(D)** Public spaces always increase property values.
- **(E)** A library is a kind of public space that would help satisfy the desire for more public spaces.

::::solution[Solution]
**(E)** — necessary. Negate: "a library would *not* serve as/help provide the wanted public spaces" → the survey no longer supports building it → argument dies. (C) is too strong (needn't have *zero* opposition); (D) irrelevant.
::::
:::

:::problem[4]{difficulty="standard"}
"The medicine must be effective, because patients who took it recovered faster than those who didn't." *The argument assumes which one?*

- **(A)** The two groups of patients did not differ in some other way that affected recovery.
- **(B)** The mechanism by which the medicine works is well understood.
- **(C)** The medicine has no side effects.
- **(D)** All patients who took the medicine recovered completely.
- **(E)** The medicine is inexpensive.

::::solution[Solution]
**(A)** — necessary (the causal-flaw assumption from Ch 6). Negate: "the groups *did* differ in another recovery-affecting way" → the faster recovery might be due to that → argument dies. (D) too strong; (C),(E) irrelevant.
::::
:::

:::problem[5]{difficulty="standard"}
"Everyone who passed the audition can read music. Jordan passed the audition. So Jordan can read music." *Which assumption, if any, does this require?* (Trick: check whether it even needs one.)

::::solution[Solution]
**None needed — the argument is already valid.** `passed → reads music`; Jordan passed; therefore Jordan reads music (modus ponens). A well-constructed assumption question won't ask this, but the drill makes the point: always check whether the conclusion *already* follows before hunting for a gap.
::::
:::

:::problem[6]{difficulty="standard"}
"Reducing class sizes will raise test scores, since students in smaller classes get more individual attention." *The argument depends on assuming:*

- **(A)** Smaller classes are the only way to give students more individual attention.
- **(B)** More individual attention leads to higher test scores.
- **(C)** Teachers prefer smaller classes.
- **(D)** Smaller classes are more expensive.
- **(E)** Test scores are the only measure of learning.

::::solution[Solution]
**(B)** — necessary. Negate: "more individual attention does *not* raise test scores" → the whole chain from small classes to higher scores breaks → argument dies. The argument links class size → attention → scores; (B) is the load-bearing second link.
::::
:::

:::problem[7]{difficulty="challenge"}
"Any employee who exceeds quota gets a bonus. So Priya will get a bonus." *The conclusion follows logically if:*

- **(A)** Priya has exceeded quota in previous years.
- **(B)** Most employees exceed quota.
- **(C)** Priya will exceed quota.
- **(D)** Priya has received bonuses before.
- **(E)** Everyone who gets a bonus exceeds quota.

::::solution[Solution]
**(C)** — sufficient. `exceeds quota → bonus`; add "Priya exceeds quota" and modus ponens delivers the bonus. (E) is the converse; (B) "most" doesn't pin Priya.
::::
:::

:::problem[8]{difficulty="challenge"}
"The company's profits will grow next year, because it just entered the fast-growing Asian market." *Which is a necessary assumption?*

- **(A)** The company's profits grew last year.
- **(B)** The company will exit its other markets.
- **(C)** Asian consumers prefer the company's products to all competitors'.
- **(D)** Entering the Asian market will not create costs that outweigh the new revenue.
- **(E)** The Asian market will grow faster than any other market.

::::solution[Solution]
**(D)** — necessary. Negate: "entering will create costs that *outweigh* the revenue" → profits could fall, not grow → argument dies. (E),(C) are too strong (needn't be fastest or preferred to *all*); (B) irrelevant. Note the modest wording of (D) — classic necessary assumption.
::::
:::

:::problem[9]{difficulty="challenge"}
"This figure is a square. So it has four equal sides." *The conclusion follows logically if which is assumed?*

- **(A)** This figure is a rectangle.
- **(B)** Some four-sided figures are squares.
- **(C)** This figure has four sides.
- **(D)** Figures with four equal sides are squares.
- **(E)** All squares have four equal sides.

::::solution[Solution]
**(E)** — sufficient. `square → four equal sides` added to "this is a square" gives the conclusion by modus ponens. (D) is the converse; (B),(C) insufficient. (Yes, it's definitionally true, but the question tests the *logical* bridge — the universal conditional in the correct direction.)
::::
:::

:::problem[10]{difficulty="challenge"}
"Because violent video game sales rose while youth crime fell, such games must reduce youth crime." *A necessary assumption is:*

- **(A)** No other factor better explains the fall in youth crime.
- **(B)** Video games are the healthiest hobby for youth.
- **(C)** All young people play violent video games.
- **(D)** Youth crime will continue to fall.
- **(E)** Youth crime fell in every region where such sales rose.

::::solution[Solution]
**(A)** — necessary (causal). Negate: "another factor better explains the fall" → games aren't established as the cause → argument dies. The others are too strong or irrelevant. (This one even has a reverse/coincidence vulnerability — the assumption ruling out alternatives is what the argument leans on.)
::::
:::

:::problem[11]{difficulty="challenge"}
"All of Dr. Okafor's studies are peer-reviewed. Peer-reviewed studies are reliable. So this study's findings should be trusted." *The conclusion follows logically if which is assumed?*

- **(A)** Findings that should be trusted are reliable.
- **(B)** This study is one of Dr. Okafor's, and reliable findings should be trusted.
- **(C)** Some trusted findings are peer-reviewed.
- **(D)** Dr. Okafor is a respected scientist.
- **(E)** Every reliable study is one of Dr. Okafor's.

::::solution[Solution]
**(B)** — sufficient. It supplies the membership (this is Okafor's study) *and* the final link (reliable → should be trusted), completing: this study → Okafor's → peer-reviewed → reliable → trusted. (A) reverses the last link; (C),(D) insufficient.
::::
:::

:::problem[12]{difficulty="challenge"}
Same stimulus as #11 but the stem now reads "the argument *depends on* assuming which one?" How does the correct answer's character change?

::::solution[Solution]
It flips from strong to **modest**. A necessary answer would be something like "*this study is one of Dr. Okafor's*" — the argument genuinely needs that (negate it: "this isn't Okafor's study" → the peer-review premise no longer applies → argument dies). It does *not* need the sweeping combined claim of #11's answer (B) to be true; that was more than required. Same argument, opposite answer profile — the stem's verb ("depends on" vs. "follows if assumed") dictates everything.
::::
:::

## Chapter summary

:::summary
#### Assumption questions, distilled

- **Read the stem first** to classify: necessary ("depends on/requires/relies on") vs. sufficient ("if assumed, the conclusion follows").
- **Necessary = required, usually modest.** Verify with the **negation test**: negate the choice; if the argument dies, it's the answer.
- **Sufficient = enough, usually strong.** Diagram, find the loose term, and pick the conditional that **bridges** premises to conclusion (correct direction).
- **Strength instinct flips by type:** prefer weak answers for necessary, strong answers for sufficient.
- **Negate softly:** "all" → "not all," "some" → "none," "will" → "will not." Over-negation gives wrong verdicts.
:::

| Stem says… | Type | Tool | Answer tends to be… |
| --- | --- | --- | --- |
| depends on / requires / relies on / presupposes | Necessary | Negation test | modest, defensive |
| if assumed, allows / conclusion follows logically if | Sufficient | Plug in & check validity | strong, bridging |

LSAT Mastery — Chapter 7. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
