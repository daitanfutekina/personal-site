---
title: "Test-Day Playbook"
source: "lsat_ch27_test_day.html"
---

Part V · Chapter 27

# Test-Day Playbook

The final chapter of the course, and the last thing you'll read before test day. Months of training come down to execution — here's how to protect it, from the week before through the score release.

**Est. study time:** 35–45 min — **Sections:** 5 — **Practice:** 12+ items

## Overview

By test day, the hard work is behind you — your reasoning skill is built, your pacing is trained, your weaknesses are patched. What remains is **execution**, and execution is where preparation gets protected or squandered. This chapter is your operational checklist for the final stretch: how to spend the week and day before, how to make sure the technology and testing environment won't ambush you, how to execute *during* the four sections, and what to do afterward — the writing task, the score, and the retake decision. None of it is intellectually hard; all of it is easy to fumble if you haven't planned it. Consider this the playbook you run on autopilot so your mind is free for the questions.

:::callout-tip
Prerequisites

The whole course, but especially Chapter 2 (online format, tools, break), Chapter 3 (no wrong-answer penalty, retakes/highest score), Chapter 14 (skip-and-return, guessing), Chapter 20 (the writing task gates score release), Chapter 24 (taper), and Chapter 26 (the mental game). This chapter assembles their test-day-relevant pieces into one sequence.
:::

## 27.1 · The week & day before

:::callout-intuition
Intuition first

The final days are about *arriving fresh and prepared*, not learning anything new. You're in the taper (Chapter 24): the goal is to consolidate lightly, verify logistics, and rest so your trained ability shows up intact. The most common self-sabotage here is cramming yourself into exhaustion or discovering a logistical problem at the last second — both entirely preventable.
:::

### The week before

- Confirm your test date, start time, and (for online) that your computer, webcam, and room meet LSAC's tech and environment requirements.
- Run LSAC's official system check / onboarding *ahead* of test day — don't discover a webcam or bandwidth problem at the desk.
- Take your final full PT early in the week (3–7 days out), then taper to light review (Chapter 24).
- Bank good sleep across several nights — sleep is training too (Chapter 24), and one good night can't offset a week of deprivation.
- Re-read your error-log takeaways (Chapter 23) for a light, confidence-building refresher — not new material.

### The day before

- No new material and no full PT. A light, confidence-building review at most — then stop.
- Prep your space and materials: clear desk, allowed scratch materials per LSAC rules, water, ID ready.
- Lay everything out and confirm exactly when you'll log in.
- Do something relaxing and get to bed at a reasonable hour; don't chase perfect sleep anxiously (pre-test nerves make that night's sleep unreliable, and one imperfect night is fine if you banked the earlier ones).

:::callout-pitfall
Watch out for these mistakes

- **A full PT the day before.** It exhausts you for zero ability gain and can rattle you over a random bad section. Finish PTs several days out.
- **Cramming new techniques.** The last days are for consolidation; a method learned in a panic won't be reliable under pressure.
- **Skipping the tech check.** A device or environment problem found the week before is a five-minute fix; found at 8:59 a.m., it's a crisis.
- **Fixating on the last night's sleep.** Bank several good nights; don't lie awake anxious about one.
:::

### Practice — 27.1

:::problem[Q1]{difficulty="easy"}
Should you take a full PT the day before? Why or why not?

::::solution[Solution]
**No** — it exhausts you for no ability gain and risks shaking your confidence. Your last full PT should be 3–7 days out; the day before is light review and rest.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why run the official tech/system check a week ahead rather than on test morning?

::::solution[Solution]
Because a webcam, bandwidth, or environment problem found **a week early is a small fix**, while the same problem at test time is a crisis that can derail or forfeit your attempt. Surfacing it early leaves time to solve it.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why "bank sleep across several nights" rather than just sleep well the night before?

::::solution[Solution]
Because **sleep debt accumulates and one night can't repay it**, and pre-test nerves often spoil the final night's sleep anyway. Several good nights ensure you're genuinely rested and buffer against a restless night before.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is light review of your error-log takeaways good, but learning a new technique bad, in the final days?

::::solution[Solution]
Light review of **already-learned takeaways** reinforces reliable skills and builds confidence at low cognitive cost. A **new technique**, by contrast, isn't yet automatic — under test-day pressure you default to trained habits, and a half-learned method is more likely to misfire or create doubt than to help. The taper is for consolidating what works, not introducing untested tools.
::::
:::

## 27.2 · Tech check & environment (online testing)

:::callout-intuition
Intuition first

Since the test is delivered online with a live remote proctor (Chapter 2), your *setup* is part of your performance. A flagged environment, a dropped connection, or an unfamiliar interface can cost you focus or even your session. The remedy is entirely preventable: know and meet the requirements in advance, and practice in the real interface so nothing about the software is new on test day.
:::

### Environment & tech checklist

- A private, quiet room where you won't be interrupted; a clear desk (only permitted items).
- An approved, valid ID matching your registration exactly.
- A tested computer, webcam, and stable internet that passed LSAC's system check.
- Familiarity with the proctoring rules (what's allowed on the desk, bathroom-break policy, etc.) so nothing you do accidentally flags your session.
- The official interface tools — highlighter, answer eliminator, flag for review — fully automatic from practicing in LawHub (Chapter 2).

:::callout-key
The interface should be invisible to you

If you've done your PTs in the official interface (Chapters 2, 24), operating the highlighter, eliminator, and flag should take **zero conscious effort** on test day — freeing all your attention for the questions. The worst version of test day is meeting the software for the first time under pressure. Practice in it until it's boringly familiar.
:::

:::callout-warning
If something goes wrong mid-test

Technical issues (a disconnect, a proctor pause) do occasionally happen. Stay calm and follow the proctor's / LSAC's instructions; these situations have established procedures. Panicking won't help and can bleed into your performance when the test resumes. Know in advance (from LSAC's materials) roughly how interruptions are handled so a glitch feels like a known contingency, not a catastrophe.
:::

### Practice — 27.2

:::problem[Q1]{difficulty="easy"}
Name three things your testing environment needs for an online LSAT.

::::solution[Solution]
Any three: a **private quiet room, clear desk (permitted items only), valid matching ID, tested computer/webcam/internet**, and familiarity with proctoring rules.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why should the digital interface feel "invisible" on test day, and how do you get there?

::::solution[Solution]
So **all your attention goes to the questions**, not to operating unfamiliar software. You get there by doing your practice — especially PTs — in the **official LawHub interface** until the tools are automatic (Chapters 2, 24).
::::
:::

:::problem[Q3]{difficulty="standard"}
Why learn the proctoring rules in advance?

::::solution[Solution]
So you don't **accidentally flag your session** by doing something disallowed (wrong items on the desk, looking away, etc.), and so interruptions/breaks feel like known procedures rather than surprises. Knowing the rules removes a source of avoidable stress and risk.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Your connection drops mid-section. Why is knowing LSAC's interruption procedure in advance valuable beyond the fix itself?

::::solution[Solution]
Because knowing there's an **established procedure** reframes a scary glitch as a *known contingency*, which keeps you calm — and calm is exactly what protects the rest of your test. Panic over a disconnect can bleed into your focus and pacing when the session resumes, costing points beyond the interruption. Preparation converts a potential spiral (Chapter 26) into a manageable, expected hiccup you can handle by simply following instructions.
::::
:::

## 27.3 · Execution rules during the test

:::callout-intuition
Intuition first

During the four sections, your job is not to be brilliant — it's to *execute the habits you trained*. Every rule below you've already learned; test day is just about running them under pressure without deviating. The test-takers who do best aren't the calmest geniuses; they're the ones who keep methodically answering, guessing-and-flagging when stuck, and refusing to spiral.
:::

:::definition
**The test-day execution rules.**

- **Answer every question.** No wrong-answer penalty (Chapter 3), so never leave a blank; with ~30 seconds left in a section, fill any remaining bubbles with your letter of the day.
- **Don't get stuck.** If a question is eating your clock (~2 min, no path), flag it, guess, and move on (Chapter 14). One hard question is worth the same as one easy one.
- **Use the tools** you practiced with — highlighter, eliminator, flag.
- **Treat every section as scored.** You can't identify the experimental section (Chapter 2), so give all four full effort.
- **Use the 10-minute break to reset** — stand, breathe, hydrate. Endurance is a skill you trained (Chapter 24); trust it.
- **If a section goes badly, let it go.** Spiraling costs you the next section too (Chapter 26). Reset and keep scoring.
:::

:::callout-key
The mindset that ties it together

Reframe the whole day as **execution, not evaluation** (Chapter 26). You're not proving your worth; you're running a trained routine. Stay on *process* — the next question, the method, the pacing — and the score takes care of itself. Nerves are normal; the winning move is simply to keep answering, section after section, until it's done.
:::

:::callout-pitfall
Watch out for these mistakes

- **Leaving blanks** or forgetting to guess-fill in the last seconds. Every blank is a wasted lottery ticket.
- **Fighting a time-sink question** out of pride. Flag, guess, move — protect the other points.
- **Coasting on a section you assume is experimental.** You can't know; full effort on all four.
- **Ruminating over a bad section** during the next one. Reset; the past section is unchangeable.
:::

### Practice — 27.3

:::problem[Q1]{difficulty="easy"}
With 30 seconds left and blanks remaining, what do you do first?

::::solution[Solution]
**Bubble a guess on every blank** (letter of the day) — no wrong-answer penalty, so a blank can only cost you. Guarantee no empty answers before time runs out.
::::
:::

:::problem[Q2]{difficulty="standard"}
A question has eaten ~2 minutes with no path. Move?

::::solution[Solution]
**Flag it, guess, and move on** (Chapter 14). One hard question equals one easy one; protect the time for questions you can get, and return only if the section allows.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why give full effort to a section you suspect is experimental?

::::solution[Solution]
Because the experimental section is **unidentifiable** (Chapter 2) — assuming a section is fake risks coasting through a *scored* one and throwing away points. Full effort on all four is the only safe policy.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is "execution, not evaluation" the right frame for test day, and how does it change your moment-to-moment behavior?

::::solution[Solution]
Because your ability is already built and can't change on the day, so **the only variable is how well you run your trained routine** — framing it as evaluation ("am I good enough?") invites anxiety and outcome-focus that impair performance, while framing it as execution ("run the process") keeps attention on the controllable next action. Concretely, it makes you attend to *process* — find the conclusion, apply the method, manage pacing, guess-and-flag — rather than tracking your score or judging yourself, which is exactly the behavior that produces the best score.
::::
:::

## 27.4 · After the test

:::callout-intuition
Intuition first

The multiple-choice test is done, but two things still stand between you and a reported score: the **writing task** (if you haven't done it) and the **wait**. And once your score arrives, there's a decision to make — accept it or retake. Handling this last stretch calmly matters, because a great score can still be delayed by a forgotten writing sample, and a disappointing score isn't the end of the road.
:::

### The post-test sequence

- **Complete the Argumentative Writing task** as soon as you're eligible if you haven't already — your score is *not released* until an approved sample is on file (Chapter 20). Don't block your own score.
- **Wait for the score** — released a few weeks after test day, via email/your LSAC account (Chapter 3). Try not to obsess; nothing you do now changes it.
- **Reporting via CAS:** your score travels to schools bundled with transcripts and letters (Chapters 2–3). Schools generally decide on your **highest** score.
- **Decide on a retake** if the score is well below your practice average and the cycle still has runway.

:::callout-key
The retake decision

A retake is a **normal, low-risk move** when your official score lands meaningfully below your steady practice-test average and there's still time to apply early (Chapter 2's rolling-admissions timing). Most schools weigh your *highest* score, so a retake mostly offers upside — provided you have the time and a plan to address what went wrong (nerves? a specific weak section?). Weigh it against retake limits (Chapter 2) and your target (Chapter 3): if you're already at or above your target schools' medians, you may be done. If a specific, fixable factor cost you points, retaking to realize your true ability is often worth it.
:::

:::callout-pitfall
Watch out for these mistakes

- **Forgetting the writing task.** The single most common post-test error — it silently withholds your whole score. Do it promptly.
- **Panic-deciding on a retake before the score arrives.** Wait for the actual number, then decide with the medians and timing in view.
- **Retaking with no plan.** If nothing changes in your prep or execution, the score likely won't either. Retake to fix a specific, identified problem.
- **Assuming schools average scores.** Most use your highest — but verify each target school's policy.
:::

### Practice — 27.4

:::problem[Q1]{difficulty="easy"}
What must you complete for your score to be released?

::::solution[Solution]
The **LSAT Argumentative Writing sample** (unscored but mandatory). Without an approved sample on file, your score isn't released to schools (Chapter 20).
::::
:::

:::problem[Q2]{difficulty="standard"}
When is a retake a reasonable, low-risk choice?

::::solution[Solution]
When your official score is **well below your steady practice average**, there's still time to apply early, and you have a plan to fix what went wrong — since most schools use your **highest** score, the retake mostly offers upside (mind retake limits and your target).
::::
:::

:::problem[Q3]{difficulty="standard"}
Why decide on a retake *after* the score arrives, not right after the test?

::::solution[Solution]
Because your **felt performance is an unreliable predictor** of the actual score — the number may be better (or worse) than you fear. Wait for the real result, then decide with your target-school medians and the cycle timing in view.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Your official score matches your practice average and sits just above your target schools' medians. Retake?

::::solution[Solution]
**Probably not.** The score reflects your true ability (matches practice) and already clears your targets' medians (Chapter 3), so the expected upside of a retake is small while it costs time, money, and a retake slot. Unless you're now aiming higher (e.g., chasing scholarships or reach schools), you've achieved the goal you set — the disciplined move is to **apply early with a strong score** rather than risk a retake for marginal gain. Retaking makes sense when there's a real gap to close, not when you're already at target.
::::
:::

## 27.5 · Scenario drills

Six test-day scenarios. Decide the right move, then check.

:::problem[1]{difficulty="easy"}
It's the night before and you're tempted to do one more full PT. Do it?

::::solution[Solution]
**No** — light review at most, then rest. A full PT the night before exhausts you for no gain and can rattle you. You're in the taper.
::::
:::

:::problem[2]{difficulty="standard"}
Section 1 felt terrible and you're shaken heading into the break. What's the plan?

::::solution[Solution]
**Use the break to reset** (stand, breathe, hydrate), then let Section 1 go — it might even have been experimental. Give full, calm effort to the remaining sections; spiraling would compound the damage (Chapter 26).
::::
:::

:::problem[3]{difficulty="standard"}
Two minutes left in a section, three questions unanswered, you can solve maybe one. Sequence?

::::solution[Solution]
**Bubble guesses on all three first**, then spend the remaining time solving the one you can, updating its bubble. Lock in guaranteed value (no blanks) before chasing the one gettable point (Chapters 3, 14).
::::
:::

:::problem[4]{difficulty="standard"}
You finish the multiple-choice test, feel relieved, and skip the writing task "for later," then forget. Consequence?

::::solution[Solution]
Your **score is not released to schools** until the writing sample is on file — you've blocked your own score. Do the writing task **promptly** after the test.
::::
:::

:::problem[5]{difficulty="challenge"}
Your score comes back 7 points below your practice average; it's still early in the cycle. Walk through the decision.

::::solution[Solution]
This is a **strong retake candidate**: the gap suggests something (likely nerves or a bad section, not ability) cost you points you can recover, and most schools use your **highest** score, so the downside is minimal. Confirm you have **time to apply early** after retaking (rolling admissions, Chapter 2) and **retake slots** remaining (retake limits), then make a **plan to fix the specific problem** (e.g., pressure inoculation from Chapter 26, or targeted work on the section that cratered). If those check out, retake; a planned retake to realize a demonstrated ability is a normal, sensible move.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, sum up the entire test-day philosophy.

::::solution[Solution]
By test day the work is done, so the day is about **execution, not new ability**: arrive rested and logistically prepared, run your trained habits (answer everything, guess-and-flag, treat every section as scored, reset after setbacks), and stay on process rather than outcome — then complete the writing task and let your training's result be your score. Calm, methodical execution is what converts months of preparation into points.
::::
:::

## Chapter summary

:::summary
#### Test-day playbook, distilled

- **Week/day before:** last full PT 3–7 days out, then light review and banked sleep; run the tech check early; no new material.
- **Environment:** private quiet room, valid ID, tested tech, known proctoring rules, and an interface made invisible by practice.
- **Execution:** answer everything, don't get stuck (flag/guess/move), treat every section as scored, reset after a bad section. Process, not outcome.
- **After:** complete the writing task promptly (it gates score release), wait for the score, and decide on a retake with medians, timing, and a fix-plan in view.
- **The whole day is execution,** not evaluation — keep answering and let your training carry you.
:::

:::callout-connect
End of the core course

That completes the twenty-seven core chapters — the full test, every question type, and the whole study plan through test day and beyond. You now have everything you need to understand the LSAT, train for it, and execute on the day. What remains are the **appendices** (A–L): quick-reference material — the flaw catalog, conditional-logic cheat sheet, question-type flowchart, score tables, resource directory, checklists, glossary, and consolidated answer keys — to keep beside you while you drill. Good luck; the work you put in is what shows up on test day.
:::

LSAT Mastery — Chapter 27. Independent study material, not affiliated with LSAC. Test-day procedures, tech requirements, and policies change — confirm current details at lsac.org before your test.
