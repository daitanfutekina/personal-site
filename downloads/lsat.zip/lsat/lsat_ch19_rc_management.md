---
title: "RC Section Management"
source: "lsat_ch19_rc_management.html"
---

Part III · Chapter 19

# RC Section Management

Reading Comprehension is a race against a clock that's tighter than it looks. This chapter turns your reading skill into a section score: how to budget time, which passage to do first, and when to read closely versus move.

**Est. study time:** 40–50 min — **Sections:** 4 — **Practice:** 14+ items

## Overview

You've learned to read for structure (Chapter 15) and to handle every RC question type (Chapter 18). But RC's hidden difficulty is the *clock*: four passages and ~27 questions in 35 minutes, with a big chunk of time eaten by reading before you can answer anything. Many capable readers underperform simply because they run out of time on the fourth passage — leaving points on the table that had nothing to do with skill. This chapter is the RC counterpart to Chapter 14: how to spend your 35 minutes so every gettable point gets got.

:::callout-tip
Prerequisites

Chapter 2 (RC pacing math: ~14 minutes of reading overhead, leaving ~21 minutes for questions — about 46 seconds each), Chapter 14 (skip-and-return, never leave blanks — the same principles apply here), and Chapter 15 (structural reading, which controls your reading time).
:::

:::callout-key
The core RC time problem

Unlike Logical Reasoning, where each question is self-contained, RC front-loads a big **reading cost** per passage before any points are available. That makes two levers decisive: **controlling reading time** (structural reading, Chapter 15) and **choosing the order** you tackle passages so you never get stranded on the hardest one with no time left. Master those and the section stops feeling like a sprint you always lose.
:::

## 19.1 · The per-passage time budget

:::callout-intuition
Intuition first

Four passages in 35 minutes means roughly **8–9 minutes per passage set** — and that has to cover *both* reading and answering. Because reading eats a big share, the biggest controllable variable is how fast you read (structurally, not exhaustively). A rough split per passage: about **3–4 minutes reading**, **4–5 minutes answering**. Blow the reading budget and you'll be starved for answering time — which is where the points actually are.
:::

:::definition
**Definition 19.1 — The RC budget.** ~35 minutes ÷ 4 passages ≈ **8.75 minutes per passage set**. A workable internal split: ~3.5 min reading (building the map, tagging voices, pinning the main point) + ~5 min on the questions. Comparative sets (two passages) may need slightly more reading; a passage with 8 questions deserves a bit more total time than one with 5.
:::

:::example
Worked Example 19.1 — the reading-overhead trap

standard

**Scenario.** You spend 6 minutes carefully reading and re-reading a dense science passage, determined to understand it fully. You now have ~2.75 minutes for its 7 questions.

**Question.** What went wrong, and what's the fix?

Answer: You over-read. 6 minutes on reading leaves far too little for 7 questions (~24 sec each — impossible). Fix: read for structure in ~3.5 min, accept you won't fully "understand" the science, and preserve answering time.

**How we get there.** The points live in the *questions*, not in your comprehension of the passage. Reading is overhead — necessary, but to be minimized via structural reading (map the functions, don't master the content). Six minutes of reading nearly doubled the budget and stole the answering time you needed. The fix isn't to read faster carelessly; it's to read *for structure* (Chapter 15), which is both faster and sufficient, then spend the saved time where points are earned. **Teaching point:** guard the reading clock — every extra minute reading is a minute stolen from answering.
:::

:::callout-pitfall
Watch out for these mistakes

- **Over-reading for comprehension.** You don't need to understand every detail — you need the structure. Points come from questions, not from mastering the passage.
- **Ignoring question count.** An 8-question passage is worth more total time than a 5-question one; allocate accordingly.
- **No time checkpoints.** Glance at the clock after each passage; if you're past ~9 minutes, speed up on the next.
:::

### Practice — 19.1

:::problem[Q1]{difficulty="easy"}
Roughly how many minutes per passage set do you have, and how should it split?

::::solution[Solution]
About **8.5–9 minutes** per set, split roughly **~3.5 min reading + ~5 min answering**. Reading is overhead to minimize; answering is where points are.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why is over-reading a passage a costly mistake even if it improves your understanding?

::::solution[Solution]
Because points come from **answering questions**, not from comprehension. Extra reading time is stolen directly from answering time, so deep understanding you didn't need can cost you gettable points. Read for structure, then move to the questions.
::::
:::

:::problem[Q3]{difficulty="standard"}
Two passages, one with 5 questions and one with 8. How should time differ?

::::solution[Solution]
Give the **8-question passage more total time** — it offers more points. Don't split the 35 minutes into four rigidly equal quarters; weight toward passages with more questions.
::::
:::

:::problem[Q4]{difficulty="challenge"}
You finish reading a passage in 3 minutes but realize you have no idea what the author's point was. Better to re-read now or push into the questions?

::::solution[Solution]
Usually **pin the main point quickly, then push into the questions** — but if you truly lack the *structure* (not just details), a fast 20–30 second re-skim of the first and last sentence of each paragraph to grab the main point and map is worth it, since global and function questions depend on it. The goal is the skeleton, not full comprehension; get just enough structure to navigate, then let the questions send you back for specifics.
::::
:::

## 19.2 · Ordering the passages (easiest first)

:::callout-intuition
Intuition first

Here's a free points gift most people ignore: **you don't have to do the passages in order.** All four sets are worth roughly the same, but they vary in difficulty. If you burn 12 minutes fighting a brutal passage first, you may never reach an easy one at the end that you'd have aced. So take a few seconds up front to **triage**, and do the passages from easiest to hardest — banking secure points before the clock gets tight.
:::

:::definition
**Definition 19.2 — Passage triage.** A quick scan of all four passage sets at the section's start to decide the order to attempt them, doing the most approachable first. Judge approachability by: topic familiarity/readability, passage density, and number of questions (more questions = more points available). The goal is to guarantee you capture the easy passages' points before risking time on the hardest.
:::

:::callout-key
How to triage in ~20 seconds

At the start, glance at each passage: is it dense and abstract or relatively readable? How many questions does it have? Then attack the **readable, high-question passages first** and save the densest for last. If the last passage is brutal and time is short, you'll be guessing on *its* questions — the ones you were least likely to get anyway — rather than stranding easy points. This is the RC version of "bank the front" from Chapter 14.
:::

:::example
Worked Example 19.2 — order for maximum points

standard

**Scenario.** Four passages: (A) a readable history passage, 7 questions; (B) an extremely dense philosophy passage, 5 questions; (C) a clear science passage, 6 questions; (D) a comparative law set, 8 questions.

**Question.** What order gives you the best shot at the most points?

Answer: Roughly A → C → D → B. Do the readable, high-question passages (A, C, and the 8-question D) before the dense low-question philosophy passage (B), which you save for last.

**How we get there.** A (readable, 7 Qs) and C (clear, 6 Qs) are efficient points — do them early while fresh and while time is plentiful. D has the *most* questions (8) and, though comparative, is worth prioritizing because of its point value — place it before the hardest. B is dense *and* has the fewest questions (5), so it's the lowest points-per-effort: save it for last, and if time runs short, guess-fill its questions (you were least likely to get them anyway). **Teaching point:** order by "points per minute available" — readable and question-rich first, dense and question-poor last.
:::

:::callout-pitfall
Watch out for these mistakes

- **Doing passages in order out of habit.** The test doesn't reward order; it rewards points. Triage first.
- **Getting stranded on the hardest passage.** If the toughest passage is first, you may run out of time before reaching easy points. Save it for last.
- **Over-thinking the triage.** The scan should take ~20 seconds, not two minutes. A rough easy/hard sort is enough.
- **Forgetting to bubble.** Whatever order you use, every question gets an answer (Chapters 3, 14) — especially on the passage you save for last.
:::

### Practice — 19.2

:::problem[Q1]{difficulty="easy"}
In what order should you generally attempt RC passages?

::::solution[Solution]
**Easiest to hardest** — bank the approachable, question-rich passages' points first; save the densest for last (where a time crunch costs you the fewest likely points).
::::
:::

:::problem[Q2]{difficulty="standard"}
Two features to judge a passage's priority in triage?

::::solution[Solution]
**Readability/density** (how hard it is to get through) and **number of questions** (points available). Prefer readable, high-question passages early.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is saving the hardest passage for last a points-protecting move?

::::solution[Solution]
Because if time runs short, you'll be rushing/guessing on the **hardest** passage's questions — the ones you were least likely to get right anyway — rather than stranding easy points on a passage you never reached. It concentrates any time loss where it costs the least.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A dense passage has 8 questions; a readable one has 4. Does "easiest first" still mean the readable one goes first? Discuss the tension.

::::solution[Solution]
There's a real tension: the readable passage is *faster per question*, but the dense one holds *twice the points*. A reasonable approach: do the readable 4-question passage early (quick, secure points), but do **not** leave the 8-question passage for dead last if it risks being rushed — its point value justifies attempting it while you still have adequate time (e.g., second or third). Balance points-available against difficulty; pure "easiest first" bends when a hard passage carries disproportionate points. Never let the highest-value passage be the one you run out of time on.
::::
:::

## 19.3 · When to skim vs. slow down

:::callout-intuition
Intuition first

Not every sentence deserves the same attention. Structural reading means **varying your speed**: glide over examples, lists, and dense technical detail (noting only their *function*), and slow down at the high-value spots — the main point, pivot words, the author's opinion, and the boundaries between positions. Reading everything at one uniform pace is what makes RC feel slow; reading *selectively* is what makes strong readers fast.
:::

:::definition
**Definition 19.3 — Variable-speed reading.** Adjusting reading pace by a sentence's structural importance. *Slow down* for: the main point, pivot words (but/however/yet), attitude cues, the start of a new position, and each author's conclusion. *Speed up* (note function only) for: illustrative examples, technical detail, enumerated lists, and background — content you can look up later if a question needs it.
:::

:::callout-key
The "note it, don't master it" rule

When you hit a dense passage — three sentences on an enzyme pathway, a list of six treaty provisions — **don't try to absorb it.** Note its *function* ("detailed evidence for the claim," "a list of the rule's exceptions") and its *location* ("that's in P3"), and move on. If a question asks about it, you'll go back and read those specific lines then. This keeps your one read-through fast while guaranteeing you can find any detail on demand.
:::

:::example
Worked Example 19.3 — vary the speed

standard

"The author's central claim is that oral traditions preserved history reliably. *[SLOW — main point]* Consider the West African griots, who memorized genealogies spanning centuries; the Icelandic sagas; the Polynesian navigational chants. *[SKIM — a list of examples]* However, critics counter that oral transmission inevitably distorts. *[SLOW — pivot + opposing view]*"

**Task.** Mark which parts to slow down on and which to skim, and why.

Slow down on the main claim ("oral traditions preserved history reliably") and the pivot to the critics' view ("However, critics counter…"). Skim the list of examples (griots, sagas, chants), noting only "examples supporting the claim."

**How we get there.** The main claim and the "However" pivot are high-value: they carry the passage's structure and the opposing position — questions will target them. The three examples are interchangeable illustrations; you need only that they *support* the reliability claim, not their details (if a question asks "the griots are mentioned to…," you already know: "as an example of reliable oral tradition," and can glance back for specifics). Reading the example list slowly would waste ~20 seconds for nothing. **Teaching point:** spend your attention where the structure and opinions are; glide over interchangeable detail.
:::

:::callout-pitfall
Watch out for these mistakes

- **Uniform-speed reading.** Treating a list of examples with the same care as the thesis wastes time and blurs what matters.
- **Skimming the pivots.** The sentence after "however/but/yet" is high-value — never skim it (Chapter 15).
- **Trying to memorize detail "just in case."** Note function and location; retrieve on demand. Memorizing detail is slow and usually wasted.
:::

### Practice — 19.3

:::problem[Q1]{difficulty="easy"}
Name two things you should slow down for and two you can skim.

::::solution[Solution]
**Slow down:** the main point and pivot words (also attitude cues, new positions). **Skim:** examples/illustrations and dense technical detail or lists (note function/location only).
::::
:::

:::problem[Q2]{difficulty="standard"}
You hit a paragraph listing six enzymes and their functions. What do you record before moving on?

::::solution[Solution]
Its **function and location** — e.g., "P3: detailed mechanism supporting the hypothesis." Don't memorize the six enzymes; if a question needs one, return to P3 and read those lines.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why does variable-speed reading make you faster overall, not just at parts?

::::solution[Solution]
Because you spend your limited time on the **high-value structural content** (which questions actually target) and glide over interchangeable detail, so total reading time drops while your grasp of what matters stays intact — leaving more time for answering.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A student says, "But what if a question asks about a detail I skimmed?" Answer their worry.

::::solution[Solution]
That's fine and expected: you noted the detail's **location and function**, so when a question targets it you **go back and read those two or three lines carefully** — which is exactly what you'd do anyway (RC rewards returning to the text, Chapter 18). Skimming detail on the first pass doesn't lose the point; it defers reading that detail until you know it's needed, saving time on the (many) details no question ever asks about.
::::
:::

## 19.4 · Scenario drills

Eight in-section decision scenarios. Decide your move, then check. These train judgment, not reading.

:::problem[1]{difficulty="easy"}
It's 20 minutes into the section and you've finished only 2 of 4 passages. On pace?

::::solution[Solution]
**Slightly behind** — 2 passages should take ~17.5 min, so you're ~2–3 min over with 2 passages left in ~15 min. Speed up: read more selectively, and prioritize the more approachable of the remaining two. Don't over-read.
::::
:::

:::problem[2]{difficulty="standard"}
You've read a passage twice and still find it baffling, and 4 minutes are gone. Move?

::::solution[Solution]
**Move to the questions now** (or, if it's the hardest passage, do the questions you can and guess the rest). Don't read a third time — you've spent too much. Use the questions themselves to send you back to specific lines; often answering is easier than fully "getting" the passage.
::::
:::

:::problem[3]{difficulty="standard"}
At the section's start, which passage should you do first?

::::solution[Solution]
The **most approachable** one (readable, decent question count), per a ~20-second triage. Bank secure points early; save the densest passage for last.
::::
:::

:::problem[4]{difficulty="standard"}
With 3 minutes left you have one unread passage (6 questions). Realistic plan?

::::solution[Solution]
**Skim for structure fast (~1 min)** — grab the main point and map — then answer the questions you can, prioritizing global/main-point and easy detail questions, and **bubble a guess on all 6** so none is blank. You won't get all 6, but structural skimming plus guessing beats leaving them empty.
::::
:::

:::problem[5]{difficulty="standard"}
You're a fast reader but always miss questions. Where should your time go?

::::solution[Solution]
Into **answering more carefully and returning to the text**, not reading faster. If reading isn't your bottleneck, reallocate saved reading time to working questions and verifying answers against specific lines — accuracy, not speed, is your lever.
::::
:::

:::problem[6]{difficulty="challenge"}
A comparative (two-passage) set is next. How should you adjust your time split versus a single passage?

::::solution[Solution]
Budget **slightly more reading time** (you're reading two mini-passages and must map both plus their relationship), but keep total set time near the ~8.5–9 min norm by reading each passage structurally and pinning the relationship up front (Chapter 17). The relationship summary then makes the questions fast, offsetting the extra reading.
::::
:::

:::problem[7]{difficulty="challenge"}
You finish RC with 3 minutes to spare and all questions answered. Best use of the time?

::::solution[Solution]
**Revisit questions you flagged or felt unsure about**, returning to the relevant lines to verify. Spare time in RC is best spent converting shaky answers into confident ones on questions you already attempted — not idling. (Also confirm no bubble is blank.)
::::
:::

:::problem[8]{difficulty="challenge"}
In one or two sentences, state the governing goal of RC section management and the two levers that most control it.

::::solution[Solution]
The goal is to **capture the most points across four passages in 35 minutes**, not to fully understand every passage. The two decisive levers are **controlling reading time** (structural, variable-speed reading — Chapters 15, 19.3) and **ordering the passages** so you bank easy points first and never get stranded on the hardest one with no time left.
::::
:::

## Chapter summary

:::summary
#### RC section management, distilled

- **Budget ~8.5–9 min per set** (~3.5 reading + ~5 answering). Reading is overhead — minimize it with structural reading; points are in the questions.
- **Triage and reorder:** do readable, question-rich passages first; save the densest for last so any time crunch costs the fewest likely points.
- **Read at variable speed:** slow for the main point, pivots, and opinions; skim examples and detail, noting only function and location.
- **Note it, don't master it:** return to specific lines when a question needs them — the text rewards going back.
- **Never leave blanks;** spend spare time verifying shaky answers, not idling.
:::

:::callout-connect
End of Part III

That completes Reading Comprehension. You can now read any passage for structure (Ch 15), handle any subject (Ch 16), tackle comparative sets (Ch 17), answer every question type (Ch 18), and manage the clock (Ch 19). Next, Part IV is a single short chapter on the Argumentative Writing task — required but unscored — before Part V turns to the study plan that ties the whole course together.
:::

LSAT Mastery — Chapter 19. Independent study material, not affiliated with LSAC. Pacing figures are guidelines; calibrate to your own timed practice. Use official LSAC PrepTests for timed practice.
