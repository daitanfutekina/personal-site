---
title: "Scoring, Percentiles & Targets"
source: "lsat_ch3_scoring.html"
---

Part I · Chapter 3

# Scoring, Percentiles & Targets

How your answers become the single number law schools see — and how to turn that number into a goal that's tied to real schools instead of a figure you picked out of the air.

**Est. study time:** 45–55 min — **Sections:** 4 — **Practice:** 20+ items

## Overview

Every question you answer eventually collapses into one number between 120 and 180. This chapter follows that number's whole life: how your count of correct answers becomes a *scaled score*, how the scaled score becomes a *percentile* that ranks you against everyone else, why the scale is unusually "dense" in the middle (so a few questions swing more points than you'd expect), and how to convert all of that into a concrete target driven by the schools you actually want to attend.

The goal isn't just to understand scoring — it's to make you **strategic** about it: to see why eliminating careless errors is worth so many points, why chasing a 178 is usually the wrong plan, and how to set a target that's a decision rather than a daydream.

:::callout-tip
Prerequisites

Chapter 1 (skill test; the credited-response idea) and Chapter 2 (three scored sections, ~75–77 scored questions, no wrong-answer penalty). We build the number directly on those facts.
:::

## 3.1 · From raw score to scaled score to percentile

:::callout-intuition
Intuition first

Your score goes through three forms. First the **raw score** — literally how many questions you got right (there's no penalty for wrong answers, so this is just a count of correct bubbles). Then that raw count is converted onto the **120–180 scaled score** everyone talks about. Finally, the scaled score is matched to a **percentile** that says what fraction of test-takers you beat. Think of it as: *count* → *standardized number* → *ranking*. Each step exists to make scores comparable across different test dates.
:::

### Step 1 — the raw score

Add up your correct answers across the three scored sections — roughly 75–77 questions. Because the LSAT has **no penalty for wrong answers** (Chapter 2), your raw score is simply the number correct, and there is never a reason to leave a blank. That raw number, by itself, isn't reported to anyone; it's the input to the next step.

### Step 2 — the scaled score (120–180)

LSAC converts your raw score to a **scaled score between 120 and 180** using a conversion specific to that particular test form. Why convert at all? Because no two test forms are exactly equally hard. **Equating** adjusts for that: on a slightly harder form you might need a few fewer correct answers to earn the same scaled score as on an easier form. This is what makes a 160 mean the same thing in June as in October, even though the questions differ.

:::definition
**Definition 3.1 — Raw, scaled, and equated scores.** Your *raw score* is the count of questions answered correctly. Your *scaled score* (120–180) is that raw score mapped through a form-specific conversion table. *Equating* is the statistical adjustment that makes the conversion slightly more forgiving on harder forms and slightly stricter on easier ones, so a given scaled score represents the same ability regardless of which test you took.
:::

### Step 3 — the percentile

Finally, your scaled score is tied to a **percentile rank** — the percentage of recent test-takers who scored *below* you. A percentile is what actually communicates your standing: a 160 isn't meaningful as "160," but as "you scored higher than about 73% of test-takers." Percentiles are computed over a multi-year pool and shift slightly year to year.

:::definition
**Definition 3.2 — Percentile rank.** The percentage of test-takers whose scores fall below yours. A score at the 90th percentile means you performed better than about 90% of test-takers. Percentiles — not raw or even scaled numbers — are how schools intuitively read where you stand in the applicant pool.
:::

:::callout-key
Why "no penalty" is a strategic gift

Because raw score is just correct answers with no deduction for guessing, **every blank is a pure loss and every guess is free upside.** On a 5-choice question a blind guess is right ~20% of the time; an educated guess after eliminating two choices is right ~33%. Over a section, guess-filling every unanswered question reliably adds points. This single fact — established in Chapter 2, quantified here — is worth several scaled points to people who currently leave blanks.
:::

### Practice — 3.1

:::problem[Q1]{difficulty="easy"}
Put these in order from first to last in a score's "life": percentile, raw score, scaled score.

::::solution[Solution]
**Raw score → scaled score → percentile.** Count correct, convert to 120–180, then rank against other test-takers.
::::
:::

:::problem[Q2]{difficulty="standard"}
Two students earn a 162. One took a slightly harder form and got 2 fewer questions right than the other. How can they have the same scaled score?

::::solution[Solution]
**Equating.** The conversion table for the harder form is a touch more forgiving, so a slightly lower raw score maps to the same 162. Equating is precisely what makes scaled scores comparable across forms of differing difficulty.
::::
:::

:::problem[Q3]{difficulty="easy"}
A 165 is at roughly the 86th percentile. In plain English, what does that mean?

::::solution[Solution]
You scored higher than about **86% of test-takers** — i.e., in the top ~14%. The percentile, not the number 165 itself, conveys your standing in the pool.
::::
:::

:::problem[Q4]{difficulty="standard"}
Explain, using the "no wrong-answer penalty" rule, why leaving three questions blank at the end of a section is strictly worse than guessing on them.

::::solution[Solution]
Since raw score counts only correct answers with **no deduction for wrong ones**, blanks can only score 0, while guesses have a positive chance of scoring (≈20% blind, higher if you eliminated choices). Guessing dominates leaving blanks in every case — there's no downside, only upside. Expected gain from blind-guessing 3 questions is about 0.6 correct; from eliminating down to 3 choices, about 1.
::::
:::

## 3.2 · The shape of the curve

:::callout-intuition
Intuition first

Test-takers cluster in the middle of the scale and thin out toward the ends — the familiar bell shape. That clustering has a powerful consequence: near the middle (around 150), *many* people are packed into each score, so getting a few more questions right leapfrogs you past a lot of them and moves your percentile a lot. Near the top (around 170+), almost no one is left to pass, so each additional point demands near-perfection for a small percentile gain. The curve's shape is why **150→160 is a very different project from 165→175.**
:::

### Representative score-to-percentile landmarks

Percentiles shift slightly year to year; these (recent, ~2025) are close enough to plan with:

| Scaled score | ~Percentile | Reads as |
| --- | --- | --- |
| 180 | ~99.9th | Perfect / near-perfect |
| 175 | ~99th | Top 1% |
| 170 | ~95th | Top 5% |
| 165 | ~86th | Top ~14% — scholarship territory |
| 160 | ~73rd | Top quarter |
| 155 | ~58th | Above average |
| 150 | ~44th | Near the median test-taker |
| 145 | ~26th | Below median |

The **median** scaled score across all test-takers is around **150–152** (the 50th percentile sits right about there).

:::example
Worked Example 3.1 — where a few questions move you most

standard

**Question.** Using the landmarks above, compare the percentile jump from 150→155 with the jump from 170→175. Which improvement moves you past more of the field?

Answer: 150→155 moves you past far more of the field (~14 percentile points) than 170→175 (~4 points).

**How we get there.** Read the deltas off the table. 150 is ~44th percentile; 155 is ~58th. Difference: 58 − 44 = **~14 percentile points**. Now the top: 170 is ~95th; 175 is ~99th. Difference: 99 − 95 = **~4 percentile points**.

Same five scaled points in each case — but near the crowded middle those five points vault you past ~14% of test-takers, while near the sparse top they pass only ~4%. **Teaching point:** improvement is "cheaper" in percentile terms the closer you are to the middle, because that's where the people are. This is the curve's shape made concrete.
:::

:::callout-key
The planning takeaway

Climbing out of the middle is comparatively fast; the last few points near the top are brutally expensive. In practical terms: **going from 150 to 160 is far more achievable than going from 165 to 175.** Set your target with that asymmetry in mind — and recognize that eliminating careless errors, which are concentrated among questions you *could* have gotten, is the highest-return improvement of all because it converts near-misses into raw points exactly where the curve rewards them.
:::

:::callout-pitfall
Watch out for these mistakes

- **Treating all point gains as equal effort.** Five points near 150 and five points near 172 are wildly different projects. Plan accordingly.
- **Chasing a "perfect" score.** Unless your target schools demand it, the effort to squeeze 174→178 is usually better spent elsewhere (or not at all).
- **Dismissing careless errors as "silly."** They're raw points you already had the ability to earn. Recovering them is the single most efficient way to climb, especially in the mid-range.
:::

### Practice — 3.2

:::problem[Q1]{difficulty="easy"}
Roughly what scaled score sits at the 50th percentile (the median test-taker)?

::::solution[Solution]
About **150–152**. Half of test-takers score below it, half above.
::::
:::

:::problem[Q2]{difficulty="standard"}
Using the landmarks, how many percentile points is the jump from 160 to 165, and from 175 to 180?

::::solution[Solution]
160 (~73rd) → 165 (~86th) = **~13 points**. 175 (~99th) → 180 (~99.9th) = **~1 point**. Same five scaled points, hugely different movement — the curve thins dramatically at the top.
::::
:::

:::problem[Q3]{difficulty="standard"}
A student scoring ~168 wants "a perfect 180 or nothing." Why is that usually a poor use of effort, per the curve?

::::solution[Solution]
Because 168→180 requires near-flawless performance for a tiny percentile gain (168 is already ~top 3–5%). Unless a specific goal demands 180, that effort yields little marginal admissions benefit; it's better spent consolidating the score or on the rest of the application.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does eliminating careless errors tend to give the biggest score boost for a mid-range scorer specifically?

::::solution[Solution]
Two reasons combine. (1) Careless errors are questions you already *could* answer correctly, so recovering them adds raw points at essentially no new skill cost. (2) A mid-range scorer sits in the **crowded part of the curve**, where each recovered raw point moves the percentile a lot. So converting near-misses into points is both easy and unusually high-yield precisely in the mid-range.
::::
:::

## 3.3 · Setting a target score

:::callout-intuition
Intuition first

"I want a 170" is a wish, not a target. A real target is *derived*: you start from the schools you'd actually attend, look up the scores of the students they admit, and work backward to the number that makes *you* competitive there. This flips the question from "how high can I get?" to "what do I need?" — which is both more motivating and more useful, because it tells you when you're done.
:::

In Chapter 1 you learned that schools admit heavily on two numbers: LSAT and GPA, benchmarked against each school's published **medians**. Here's the procedure that turns that into a target.

:::definition
**Definition 3.3 — A derived target score.** The lowest scaled score that makes your *best realistic* target school likely — generally a score **at or above that school's median LSAT**, adjusted upward if your GPA sits below the school's median GPA (so the LSAT can compensate). It is computed from published medians and your fixed GPA, not chosen by ambition alone.
:::

### The four-step procedure

1. **List 6–12 schools you'd actually attend.** Be honest — dream, target, and safer options.
2. **Look up each school's median LSAT and median GPA** (from ABA 509 reports / free aggregators).
3. **Compare your fixed GPA to each median.** If your GPA is *below* a school's median, you'll want your LSAT comfortably *above* that school's LSAT median to compensate (you're a partial splitter there). If your GPA is above, meeting or slightly beating the LSAT median is often enough.
4. **Set the target at the score that makes your best realistic school likely** — at or (better) above its LSAT median — and treat a higher score as the ticket to reach schools and scholarships.

:::example
Worked Example 3.2 — turning a diagnostic into a plan

standard

**The setup.** Sam's GPA is 3.65 (fixed). Cold diagnostic: 157. Target schools:

| School | Median LSAT | Median GPA |
| --- | --- | --- |
| X (reach) | 166 | 3.7 |
| Y (target) | 159 | 3.6 |
| Z (safer) | 153 | 3.5 |

**Question.** What target score should Sam set, and what does the diagnostic imply about the workload?

Answer: Target ~161–163 (above School Y's median), with School X (~166) as a stretch. That's roughly a 4–9 point climb from 157 — a realistic multi-month project.

**How we get there.**

1. **Locate the GPA.** 3.65 is just below X's median (3.7), just above Y's (3.6) and Z's (3.5). So Sam is roughly "on-median" at Y and Z, and a hair under at X.
2. **Pick the best realistic anchor.** School Y (median LSAT 159) is the natural primary target. Because Sam's GPA merely matches Y's median (not far above), aim *above* 159 — say **161–163** — to be safely competitive and to open scholarship money.
3. **Size the climb.** From 157 to ~162 is about **5 points**. Using §3.2's curve logic, points in this range are relatively attainable and often come substantially from eliminating careless errors — a realistic goal with disciplined prep.
4. **Keep the reach honest.** School X needs ~166 (a ~9-point jump) and Sam's GPA is slightly under X's median, so X wants an LSAT clearly above 166 to compensate. Treat X as a stretch that a great prep cycle could reach — not the plan the whole timeline depends on.
5. **Confirm the floor.** Even ~155 clears Z's median (153) with a GPA above Z's — a likely admit. So Sam has a safe floor and real upside: a sound target.

**Teaching point:** the target (~162) isn't Sam's ambition — it's the number the *medians* demand for the best realistic school, sized against a fixed GPA and a known diagnostic.
:::

:::callout-connect
Connects to

This procedure operationalizes the two-number model from §1.4 and the splitter idea from that section. The *curve shape* from §3.2 tells you how hard your specific climb is; the *study schedules* in Part V (Ch 25) tell you how to staff the hours to get there.
:::

:::callout-pitfall
Watch out for these mistakes

- **Setting a target with no school attached.** A number like "170" only means something relative to where you want to go. Derive it.
- **Anchoring only to a dream school's median.** A score just above a slightly-less-selective school's median can bring a large scholarship — sometimes a better outcome than scraping into a "higher" school at sticker price.
- **Ignoring your GPA's position.** If your GPA is below a school's median, meeting its LSAT median may not be enough; aim higher to compensate.
- **Confusing median with cutoff.** The median is the middle admit, not a minimum — but scoring below it means you're leaning on other strengths.
:::

### Practice — 3.3

:::problem[Q1]{difficulty="easy"}
What two published numbers per school anchor a derived target?

::::solution[Solution]
The school's **median LSAT** and **median GPA** (from its ABA 509 report). You aim at/above the LSAT median, adjusting for how your GPA compares to the GPA median.
::::
:::

:::problem[Q2]{difficulty="standard"}
Your GPA is 3.3; a target school's medians are 3.6 GPA / 162 LSAT. Should you aim *at* 162 or higher, and why?

::::solution[Solution]
**Higher than 162.** Your GPA (3.3) is well below the school's GPA median (3.6), so you're a splitter there; the LSAT must **compensate**. Clearing the LSAT median comfortably (e.g., 164–165+) offsets the low GPA and keeps you competitive.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why might a 161 that clears School B's median beat a 161 that falls below School A's median, for the same applicant?

::::solution[Solution]
Because competitiveness (and scholarship money) is **relative to each school's medians**. The same 161 is above-median at B (strong candidate, likely scholarship) but below-median at A (weaker candidate, likely no money). The number is identical; its *value* depends on the school you measure it against.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Diagnostic 158, GPA 3.9. Best realistic school: median 160 LSAT / 3.5 GPA. Set a target and justify the size of the climb.

::::solution[Solution]
Your GPA (3.9) is **well above** the school's GPA median (3.5), so you're a reverse-splitter — the strong GPA gives cushion. You don't need to overshoot the LSAT median much: a target around **160–161** (at/just above median) makes you very competitive, and even that is only a ~2–3 point climb from 158 — quite achievable, likely reachable largely by cleaning up careless errors. Extra points would chase scholarships or reach schools, but aren't required for the primary goal.
::::
:::

## 3.4 · Score release & reporting

:::callout-intuition
Intuition first

After the test there's a short wait, then your score appears — but there's a catch that trips people up every cycle: your score **won't be released at all until your writing sample is on file.** And the score doesn't travel to schools by itself; it's packaged with your transcripts and letters through the CAS (Chapter 2). Understanding this pipeline keeps you from accidentally blocking your own score at the finish line.
:::

Here's the post-test pipeline:

- **Score release.** Scores are typically released a few weeks after your test date; you're notified by email and can view them in your LSAC account.
- **The writing gate.** Your multiple-choice score is **not released** until you have a completed, approved [LSAT Argumentative Writing](./lsat_textbook_toc.html) sample on file (Chapter 20). The writing is unscored, but skipping it silently withholds your whole score from schools. Complete it as soon as you're eligible.
- **Reporting via CAS.** Through the Credential Assembly Service, your scores, transcripts, and letters are bundled into a standardized report and sent to each school you apply to (with a per-school fee). Schools generally see all your LSAT scores but decide on your **highest** (§2.5) — verify individual policies.
- **Retake decisions.** If your score lands well below your practice-test average and the cycle still has runway, a retake is a normal move (Chapter 2's timing rules apply). Your highest score is what most schools weigh.

:::callout-warning
The most common self-inflicted delay

**Not completing the writing task.** Every cycle, people finish the multiple-choice test, feel done, and forget the writing sample — then wonder why their score hasn't reached schools. The score exists; it's just locked until the writing is on file. Do the writing task promptly and you avoid the whole problem.
:::

### Practice — 3.4

:::problem[Q1]{difficulty="easy"}
Your multiple-choice score won't be released until what is on file?

::::solution[Solution]
An approved **LSAT Argumentative Writing sample**. It's unscored but mandatory for score release — complete it as soon as you're eligible.
::::
:::

:::problem[Q2]{difficulty="standard"}
How does your score actually reach the law schools you apply to?

::::solution[Solution]
Through the **CAS (Credential Assembly Service)**, which bundles your scores with transcripts and letters into a standardized report sent per-school (for a fee). The score doesn't travel on its own.
::::
:::

:::problem[Q3]{difficulty="standard"}
A student's official score is 6 points below their steady practice average, and it's still early in the cycle. What's a reasonable move and what makes it low-risk?

::::solution[Solution]
A **planned retake**. It's low-risk because most schools decide on your **highest** score, and applying early in a rolling cycle is still possible if they retake soon. The underperformance likely reflects test-day variance versus a stable practice average worth trying to realize.
::::
:::

## Chapter summary

:::summary
#### The essentials of Chapter 3

- **Three forms:** raw score (count correct) → scaled score (120–180, equated across forms) → percentile (rank vs. others).
- **No wrong-answer penalty** makes guessing pure upside and blanks pure loss — worth several points to fix.
- **The curve is dense in the middle.** The same 5 points move you far more near 150 than near 175; 150→160 ≪ 165→175 in effort.
- **Careless-error recovery is the highest-yield gain** for mid-range scorers — free raw points where the curve rewards them most.
- **Targets are derived, not wished.** Aim at/above your best realistic school's LSAT median, adjusted for your GPA's position.
- **The writing sample gates score release;** CAS delivers scores to schools; most weigh your highest.
:::

| Landmark | Value |
| --- | --- |
| Scale | 120–180 |
| Median score / percentile | ~150–152 / 50th |
| 160 / 165 / 170 | ~73rd / ~86th / ~95th percentile |
| Score released only after | approved writing sample on file |
| Schools decide on | your highest score (usually) |

## Mixed practice set

Twelve items across the whole chapter, mixed order and difficulty.

:::problem[1]{difficulty="easy"}
What is the LSAT's scaled-score range, and roughly where is the median?

::::solution[Solution]
**120–180**, with the median around **150–152** (~50th percentile).
::::
:::

:::problem[2]{difficulty="standard"}
Define "equating" in one sentence and say what problem it solves.

::::solution[Solution]
**Equating** is the statistical adjustment mapping raw scores to scaled scores slightly differently per form, so that a given scaled score reflects the same ability regardless of the test's difficulty. It solves the problem that different test forms aren't equally hard.
::::
:::

:::problem[3]{difficulty="standard"}
Same 5 scaled points: which yields a bigger percentile jump, 152→157 or 171→176? Roughly quantify.

::::solution[Solution]
**152→157** — it's in the crowded middle, so ~12–14 percentile points, versus only ~2–3 for 171→176 near the sparse top. The curve's density in the middle makes mid-range gains "cheaper" in percentile terms.
::::
:::

:::problem[4]{difficulty="easy"}
Why is leaving a question blank never correct on the LSAT?

::::solution[Solution]
There's **no penalty for wrong answers**, so a blank scores 0 while a guess has positive expected value. Always fill in every bubble.
::::
:::

:::problem[5]{difficulty="standard"}
A 164 clears one school's median (162) but falls under another's (167). Is 164 "good"? Explain.

::::solution[Solution]
It depends on the school — competitiveness is **relative to each median**. 164 is above-median (strong, scholarship-likely) at the first school and below-median (leaning on other strengths) at the second. "Good" is meaningful only against a specific target.
::::
:::

:::problem[6]{difficulty="challenge"}
GPA 3.2 (fixed), diagnostic 160. Best realistic school: median 161 LSAT / 3.7 GPA. Set a target and justify it.

::::solution[Solution]
The GPA (3.2) is **well below** the school's GPA median (3.7), so you're a splitter and the LSAT must carry the file. Aim **clearly above** the 161 median — say **164–166** — to compensate for the GPA gap. From 160, that's a ~4–6 point climb: demanding but realistic, and necessary because merely hitting 161 likely won't offset the low GPA.
::::
:::

:::problem[7]{difficulty="standard"}
Order the three forms a score takes and name what each is used for.

::::solution[Solution]
**Raw** (internal input; count of correct) → **scaled** (the 120–180 number reported) → **percentile** (communicates standing vs. the field). Each step increases comparability/interpretability.
::::
:::

:::problem[8]{difficulty="easy"}
After the multiple-choice test, what one task must you complete for your score to be released?

::::solution[Solution]
The **LSAT Argumentative Writing** sample (unscored but mandatory). Without it on file, the score stays locked.
::::
:::

:::problem[9]{difficulty="standard"}
Why is "eliminate careless errors" often better advice than "learn harder question types" for someone at 154?

::::solution[Solution]
Careless errors are points already within reach — recovering them adds raw score at little skill cost, and at 154 you're in the **dense part of the curve** where each recovered point moves the percentile a lot. Harder-type mastery matters too, but cleaning up errors is faster and higher-yield first.
::::
:::

:::problem[10]{difficulty="standard"}
A friend brags their 176 is "way better" than your 172. In percentile terms, how big is that gap, and what does it suggest about the effort behind it?

::::solution[Solution]
172 is ~top 2%; 176 is ~top 1% — a gap of only about **1 percentile point**. Both are elite. The 4 extra scaled points near the top require near-perfect execution for a tiny ranking difference — an illustration of the curve's expensive tail, not a meaningful practical advantage at most schools.
::::
:::

:::problem[11]{difficulty="challenge"}
Explain why two applicants with the same 3.6 GPA and same 165 LSAT might still be advised to set *different* target scores going forward.

::::solution[Solution]
Because targets depend on **which schools each wants**. If applicant A's dream schools have 168 medians and B's have 162 medians, A still needs to climb (165 is below A's targets' medians) while B is already above-median and "done" for admission — B might instead aim for scholarships or stop. Identical current numbers, different derived targets, because the target is defined by the goal schools, not the score alone.
::::
:::

:::problem[12]{difficulty="challenge"}
In one or two sentences, tie together the "no penalty" rule, the curve's shape, and careless errors into a single strategic statement.

::::solution[Solution]
Because there's no wrong-answer penalty, every question is worth attempting; because the curve is densest in the middle, recovered raw points there move your percentile the most; so for a mid-range scorer, the highest-return strategy is to **answer everything and systematically eliminate careless errors**, converting near-misses into points exactly where they count most.
::::
:::

LSAT Mastery — Chapter 3. Independent study material, not affiliated with LSAC. Percentiles and score conversions shift over time and by form; the landmarks here are approximate (recent) and for planning only — verify current data at lsac.org. Practice questions are original.
