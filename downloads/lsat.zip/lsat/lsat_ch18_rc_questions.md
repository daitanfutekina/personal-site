---
title: "RC Question Types"
source: "lsat_ch18_rc_questions.html"
---

Part III · Chapter 18

# RC Question Types

Reading Comprehension recycles a handful of question types. Each has a distinct task and a distinct trap — and each is answered from the structural reading you learned in Chapter 15.

**Est. study time:** 65–80 min — **Sections:** 6 — **Practice:** 22+ items

## Overview

Just as Logical Reasoning has a finite set of question types, so does Reading Comprehension — about seven recurring kinds. This chapter names each, gives its task and its characteristic trap, and shows how your paragraph map, attribution tags, and main-point sentence (Chapter 15) feed the answers. The through-line: **global** questions are answered from your map and main point; **detail and inference** questions send you *back to the text*; **function/structure** questions ask *why* a part exists; and **attitude** questions read tone. Every one obeys the credited-response principle (Chapter 1): the answer is what the passage supports, not what sounds reasonable.

:::callout-tip
Prerequisites

Chapter 15 (map, pivots, attribution, main point) is the engine for all of these. Chapter 1 (outside-knowledge trap) governs the traps. Inference questions here mirror the "must be true / most supported" logic of Chapter 10.
:::

## 18.1 · Global questions (main point & primary purpose)

:::callout-intuition
Intuition first

Global questions ask about the passage *as a whole*: its main point (the central claim) or its primary purpose (what the author is trying to *do* — argue, describe, evaluate, refute). You answer these directly from the one-sentence main point and paragraph map you built while reading. The defining trap is **scope**: an answer that's true of only one paragraph, or that overstates/understates the author's actual claim.
:::

:::definition
**Definition 18.1 — Global questions.** *Main point:* "the central idea/main point of the passage is…". *Primary purpose:* "the author's primary purpose is to…" — answered with a verb (to argue, propose, describe, refute, evaluate, reconcile). The correct answer covers the **whole** passage, reflects the **author's** view, and matches its **strength**.
:::

:::callout-key
Purpose = the right verb

For Primary Purpose, first nail the **verb**: is the author *arguing* for a position, *describing* a phenomenon neutrally, *refuting* a view, *reconciling* two positions, or *evaluating* options? A passage that rebuts a traditional account has the purpose "to challenge/argue against" — not "to describe." Matching the verb to the author's activity (from your map) eliminates most wrong answers immediately.
:::

:::example
Worked Example 18.1 — purpose verb & scope

standard

**Map recap (from a passage):** P1 states the traditional "great man" theory of history; P2–3 present evidence that social conditions, not individuals, drive change; P4 concludes the traditional theory overstates individuals' role.

**Stem.** The author's primary purpose is to…

- **(A)** prove that individuals never affect history.
- **(B)** trace the great-man theory to its earliest proponents.
- **(C)** survey all major theories of historical causation.
- **(D)** describe the biographies of several great historical figures.
- **(E)** argue that the traditional "great man" theory overstates the role of individuals in historical change.

Answer: (E).

**How we get there.** The verb from the map is *argue/challenge* (the passage builds a case against the traditional theory), and the scope is the whole passage. (E) matches both. Traps: (D) describes only background (P1) and uses the wrong verb (describe vs. argue); (A) overshoots ("never" — the author says *overstates*, not that individuals have zero effect); (C) "survey all major theories" is broader than the passage, which focuses on one. **Teaching point:** right verb + whole-passage scope + correct strength = the global answer.
:::

:::callout-pitfall
Watch out for these mistakes

- **Too-narrow answers** that capture only one paragraph. The main point must span the passage.
- **Wrong purpose verb.** "Describe" vs. "argue" vs. "refute" — a purpose answer with the wrong verb is wrong even if the topic is right.
- **Overshooting the strength.** "Proves," "never," "always" rarely match a hedged passage. Match the author's actual force.
:::

### Practice — 18.1

:::problem[Q1]{difficulty="easy"}
What two things does a Primary Purpose answer need to get right?

::::solution[Solution]
The **verb** (what the author is *doing* — argue/describe/refute/reconcile) and the **whole-passage scope** (plus matching the author's strength). Right topic with the wrong verb is a trap.
::::
:::

:::problem[Q2]{difficulty="standard"}
A passage neutrally explains how a volcano forms, taking no side. What purpose verb fits, and which is a trap?

::::solution[Solution]
Fits: "**to describe/explain**" a process. Trap: "to **argue** that…" — there's no argument or position, so an argue/refute verb overstates what the neutral passage does.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is an answer true of only paragraph 3 usually wrong on a Main Point question?

::::solution[Solution]
Main Point must cover the **entire** passage; a claim confined to one paragraph is too **narrow** — accurate but not the overall thesis. Classic scope trap.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A passage argues a traditional view is "incomplete" and needs supplementing. Why would a Main Point answer saying the traditional view is "entirely wrong" be incorrect?

::::solution[Solution]
Because it **overshoots the strength**. "Incomplete/needs supplementing" is a moderate claim that the traditional view is partly right but insufficient; "entirely wrong" asserts far more than the author committed to. The credited main point must match the author's actual (moderate) force, not exaggerate it.
::::
:::

## 18.2 · Detail & inference questions

:::callout-intuition
Intuition first

These are the "go back to the text" questions. **Detail** questions ("according to the passage…") ask what the passage *stated* — the answer is there in the text, usually paraphrased. **Inference** questions ("the passage suggests / implies…") ask for a small, guaranteed step *beyond* the literal words. For both, the killer habit is **returning to the relevant lines** rather than trusting memory — RC traps feast on plausible-sounding answers you "remember" reading.
:::

:::definition
**Definition 18.2 — Detail & inference.** *Detail (recognition):* the answer is explicitly stated in the passage (often reworded). *Inference:* the answer follows from the passage by a short, supported step — it must be what the text *implies*, not merely what's plausible. Both forbid outside knowledge (Chapter 1) and both reward locating the specific lines.
:::

:::callout-key
Always go back — and read a little around

For a detail or inference question, **return to the exact lines** (your map tells you which paragraph) and read a sentence before and after for context. The credited answer is a faithful paraphrase (detail) or a one-step consequence (inference) of those specific lines. An answer you can't tie to a location is almost certainly a trap — the same "defend it from the text" habit as Chapter 10.
:::

:::example
Worked Example 18.2 — detail vs. inference

standard

"The novelist rarely revised her manuscripts; her first drafts were typically her last. Editors who suggested changes were usually rebuffed. Yet the polish of her prose led many readers to assume she labored over every sentence."

**Detail Q.** According to the passage, the novelist's response to editors' suggestions was usually to…

Detail answer: reject them ("rebuffed").

**Inference Q.** The passage suggests that the novelist's prose…

Inference answer: appeared more labored-over than it actually was.

**How we get there.** The *detail* answer is stated: editors "were usually rebuffed" → she rejected suggestions. Paraphrase, straight from the text. The *inference* requires one step: readers *assumed* she labored over every sentence ("polish… led many to assume"), but the passage says she rarely revised — so the prose *seemed* more labored than it was. That's implied, not stated, but guaranteed by combining the two facts. A trap inference like "she was a careless writer" overshoots — rare revision plus polished prose doesn't imply carelessness. **Teaching point:** detail = find it stated; inference = one supported step, no overshoot.
:::

:::callout-pitfall
Watch out for these mistakes

- **Answering from memory.** Go back and read the lines; the difference between the credited answer and a trap is often one word you'll misremember.
- **Over-inferring.** An inference is a *small* guaranteed step, not a leap. "Suggests/implies" doesn't license adding outside claims.
- **Outside knowledge.** A real-world-true answer unsupported by the passage is wrong (Chapter 1). Support beats plausibility.
- **Extreme words.** "Always," "never," "only" in an answer rarely match a hedged passage — check the text's exact strength.
:::

### Practice — 18.2

:::problem[Q1]{difficulty="easy"}
What's the difference in task between a Detail and an Inference question?

::::solution[Solution]
**Detail**: find what the passage *explicitly states* (paraphrased). **Inference**: identify a small, guaranteed step *beyond* the literal text — what it *implies*. Both require textual support, no outside knowledge.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why should you return to the passage even on a question you think you remember?

::::solution[Solution]
Because RC traps exploit **plausible misremembering** — the credited answer often hinges on an exact word or qualifier you won't recall precisely. Re-reading the specific lines (plus context) is how you defend the answer from the text.
::::
:::

:::problem[Q3]{difficulty="standard"}
An inference answer is factually true in the real world but not supported by the passage. Correct?

::::solution[Solution]
**No** — support, not truth, is the standard. Unsupported real-world facts are the outside-knowledge trap (Chapter 1), even on "suggests/implies" questions.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A passage says a policy "reduced emissions in the pilot city." An inference answer says "the policy will reduce emissions nationwide." Why is it wrong?

::::solution[Solution]
It **over-infers / overshoots scope**: a result in one pilot city doesn't guarantee a nationwide effect (different conditions, scale). An inference must be a small guaranteed step; generalizing from one city to a whole country adds an unsupported assumption the passage doesn't license.
::::
:::

## 18.3 · Attitude & tone questions

:::callout-intuition
Intuition first

Attitude questions ask how the author *feels* about something in the passage — a theory, a figure, a proposal. The answer comes from the author's **word choice** (the attitude cues from Chapter 15.2) and the structure of their argument (do they endorse, critique, concede?). The single most reliable fact about LSAT attitude answers: they're almost always **measured**. Authors are rarely gushing or contemptuous; they're "cautiously skeptical," "qualified in their admiration," "critical of one aspect." Extreme tone words are usually traps.
:::

:::definition
**Definition 18.3 — Attitude / tone.** A question asking the author's stance toward a specified subject. Answers pair a *polarity* (positive / negative / neutral / mixed) with a *degree* (mild to strong). Correct answers are usually moderate and specific ("qualified approval," "measured skepticism"); wrong answers are often too extreme ("enthusiastic endorsement," "outright contempt") or the wrong polarity.
:::

:::callout-key
Two dials: polarity and degree

Read every attitude answer as two dials. **Polarity:** is the author for, against, neutral, or mixed? (Get this from whether they endorse or rebut.) **Degree:** how strongly? (Get this from intensity of word choice.) Eliminate answers with the wrong polarity first, then among the survivors pick the *degree* that matches — usually the more moderate one, unless the author's language is genuinely strong.
:::

:::example
Worked Example 18.3 — measured, not extreme

standard

"The proposal has undeniable appeal, and its authors deserve credit for tackling a real problem. Nonetheless, it rests on optimistic assumptions about funding that recent history does not support."

**Stem.** The author's attitude toward the proposal is best described as…

- **(A)** appreciative but skeptical of its feasibility.
- **(B)** unreserved enthusiasm.
- **(C)** total contempt.
- **(D)** complete indifference.
- **(E)** unqualified enthusiasm.

Answer: (A).

**How we get there.** Two dials. Polarity: *mixed* — the author gives credit ("undeniable appeal," "deserve credit") *and* raises a serious doubt ("Nonetheless… optimistic assumptions… history does not support"). Degree: moderate on both sides. (A) "appreciative but skeptical" captures the mixed, measured stance exactly. Traps: (E) ignores the "Nonetheless" critique (wrong — too positive); (C) "contempt" is far too negative and ignores the credit given; (D) "indifference" is wrong polarity (the author clearly cares). **Teaching point:** the "Nonetheless" pivot signaled a mixed attitude; extreme words (A, C) and neutral (D) all miss it.
:::

:::callout-pitfall
Watch out for these mistakes

- **Choosing extreme tone.** "Contempt," "adoration," "outrage" rarely fit measured LSAT prose. Favor moderate descriptions unless the language is truly strong.
- **Missing a mixed attitude.** Concessions plus critiques ("credit… nonetheless…") signal a *mixed* stance; don't pick a purely positive or purely negative answer.
- **Confusing the author's tone with a described view's tone.** The author may report someone else's strong feelings while remaining measured themselves. Track whose attitude is asked.
:::

### Practice — 18.3

:::problem[Q1]{difficulty="easy"}
LSAT attitude answers tend to be extreme or measured?

::::solution[Solution]
**Measured.** Authors are usually "qualified," "cautious," "mixed." Extreme tone words (contempt, adoration) are typically traps.
::::
:::

:::problem[Q2]{difficulty="standard"}
What two "dials" define an attitude answer?

::::solution[Solution]
**Polarity** (positive/negative/neutral/mixed) and **degree** (mild to strong). Eliminate wrong polarity first, then match the degree — usually moderate.
::::
:::

:::problem[Q3]{difficulty="standard"}
"The theory is ingenious but ultimately unpersuasive." What polarity is the author's attitude?

::::solution[Solution]
**Mixed / on balance negative**: credits ingenuity but concludes it fails ("ultimately unpersuasive"). A purely positive or purely dismissive answer would miss the blend; the net lean is skeptical.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A passage reports that "critics were outraged" by a policy, but the author's own language stays even-handed. On a question about the *author's* attitude, why is "outraged" wrong?

::::solution[Solution]
Because "outraged" is the **critics'** attitude, not the author's. Attribution (Chapter 15.3) matters here: the question asks the *author's* stance, and the author's even-handed language indicates a measured attitude — picking the critics' strong emotion misattributes a reported feeling to the author.
::::
:::

## 18.4 · Function & structure questions

:::callout-intuition
Intuition first

These ask *why* something is in the passage, not *what* it says. A **function** question targets a specific piece ("the author mentions the 1929 crash in order to…" / "the second paragraph serves to…"): you answer with its *job* — to support a claim, to give a counterexample, to concede a point, to illustrate. A **structure/organization** question asks how the *whole* passage is arranged. Both are answered straight from your paragraph map — this is exactly why you built it.
:::

:::definition
**Definition 18.4 — Function & structure.** *Function:* "the author refers to X in order to…" / "the third paragraph functions to…" — identify the *role* of that element in the argument. *Structure:* "which best describes the organization of the passage?" — describe the abstract flow (e.g., "a theory is presented, two objections are raised, and a revised theory is proposed"). Answer from the map, not the content.
:::

:::example
Worked Example 18.4 — why is this here?

standard

"Skeptics doubt that the ancient road network could have supported large-scale trade. But the discovery of standardized weights at sites hundreds of miles apart — identical to the gram for gram — is hard to explain except as the residue of a regulated commercial system."

**Stem.** The author mentions the standardized weights primarily in order to…

- **(A)** illustrate the difficulty of dating archaeological finds.
- **(B)** provide evidence against the skeptics' doubt that large-scale trade existed.
- **(C)** argue that the roads were poorly built.
- **(D)** introduce a new topic unrelated to trade.
- **(E)** describe ancient measurement practices for their own sake.

Answer: (B).

**How we get there.** Ask the function question: *why* did the author bring up the weights? The pivot "But" turns from the skeptics' doubt to the author's rebuttal; the weights are the *evidence* the author uses to counter the skeptics ("hard to explain except as… a regulated commercial system"). So their function is to provide evidence against the skeptics — (B). Traps: (E) treats the weights as a topic in themselves (they're evidence, not the subject); (C), (D) misdescribe the role. **Teaching point:** function = the element's *job* in the argument; here, rebuttal evidence, signaled by the pivot.
:::

:::callout-pitfall
Watch out for these mistakes

- **Answering "what it says" instead of "why it's there."** Function questions want the role, not a summary of the content.
- **Ignoring the pivot/context.** A detail's function often depends on the surrounding move (rebuttal, concession, example). Read around it.
- **Picking a structure answer that misorders the passage.** Match the sequence in your map exactly — "presents A then rebuts it" ≠ "rebuts A then presents it."
:::

### Practice — 18.4

:::problem[Q1]{difficulty="easy"}
A Function question asks about a detail's \_\_\_, not its \_\_\_.

::::solution[Solution]
Its **role/job** in the argument, not its **content** (what it says). E.g., "to provide a counterexample," not a summary of the example.
::::
:::

:::problem[Q2]{difficulty="standard"}
An author gives a vivid anecdote right after stating a general claim. Likely function?

::::solution[Solution]
To **illustrate/support the general claim** with a concrete example. (Confirm with context — occasionally an anecdote sets up a counterpoint — but illustration is the default when it follows a claim it exemplifies.)
::::
:::

:::problem[Q3]{difficulty="standard"}
Where do you get the answer to a Structure/organization question fastest?

::::solution[Solution]
From your **paragraph map** — the one-phrase-per-paragraph functions already describe the passage's arrangement. Structure questions are essentially "read your map aloud."
::::
:::

:::problem[Q4]{difficulty="challenge"}
A paragraph presents a fact that seems to support the opposing view, and the author immediately explains it away. What is that paragraph's function?

::::solution[Solution]
To **raise and then rebut a potential objection** (acknowledge a counter-consideration and neutralize it) — strengthening the author's position by pre-empting the opposing evidence. Recognizing this "concede-and-counter" move (Chapters 11, 15) is exactly what a function question tests.
::::
:::

## 18.5 · Analogy / application questions

:::callout-intuition
Intuition first

Analogy (or "application") questions ask you to take a relationship or principle from the passage and find a *new situation* that mirrors it — usually on a completely different topic. "Which of the following is most analogous to the relationship the author describes between the patron and the artist?" You're matching the underlying **structure of the relationship**, not the surface content — exactly the abstraction skill from Parallel Reasoning (Chapter 12), now on RC.
:::

:::definition
**Definition 18.5 — Analogy / application.** A question asking which scenario best parallels a relationship, process, or principle from the passage. Method: (1) state the relationship abstractly ("A depends on B but resents that dependence"), (2) ignore the topic, and (3) find the answer with the same abstract structure. Correct answers match the *relationship*; traps match the *topic* or only part of the relationship.
:::

:::example
Worked Example 18.5 — match the relationship

challenge

"The passage describes how each new generation of critics defines itself precisely by rejecting the tastes of the generation before — yet, in doing so, remains utterly shaped by what it rejects."

**Stem.** Which one is most analogous to this relationship?

- **(A)** A composer who writes in a style no one has attempted before.
- **(B)** A student who carefully follows every rule set by her teacher.
- **(C)** A political party that forms its entire platform in opposition to the rival party, and so is defined by that rival.
- **(D)** Two companies that independently develop the same product.
- **(E)** A scientist who confirms an earlier researcher's findings.

Answer: (C).

**How we get there.** Abstract the relationship: *X defines itself by rejecting Y, yet is shaped/determined by Y precisely through that rejection.* Now match the structure, ignoring topic. (C): a party defines its platform by opposing a rival and is thereby defined by that rival — same "shaped by what it rejects" structure. Traps: (B) is following, not rejecting (opposite); (D) is independent parallel development (no rejection relationship); (E) is confirmation, not rejection. Only (C) reproduces the abstract relationship. **Teaching point:** strip to the relationship's skeleton and match that — the critics-vs-party topic gap is irrelevant, just like Parallel Reasoning.
:::

:::callout-pitfall
Watch out for these mistakes

- **Matching on topic.** An answer about the same subject as the passage is a trap. Match the abstract relationship.
- **Matching only part of the relationship.** If the passage's relationship has two features (rejects *and* is shaped by), the answer must have both. A partial match loses.
- **Getting the direction wrong.** "Defined by rejecting" ≠ "defined by following." Preserve the polarity of the relationship.
:::

### Practice — 18.5

:::problem[Q1]{difficulty="standard"}
What do you match in an analogy question — topic or relationship?

::::solution[Solution]
The **abstract relationship/structure**, ignoring topic. Same-subject answers are traps; the credited answer mirrors the underlying relationship on a different topic.
::::
:::

:::problem[Q2]{difficulty="standard"}
Passage relationship: "a tool that solves one problem while creating a worse one." Which is analogous — "a pesticide that kills pests but poisons the water supply" or "a pesticide that safely kills pests"?

::::solution[Solution]
The **first** — it solves one problem (pests) while creating a worse one (poisoned water), matching the abstract structure. The second lacks the "creates a worse problem" feature.
::::
:::

:::problem[Q3]{difficulty="challenge"}
Why is an analogy question essentially a Parallel Reasoning question (Chapter 12) in RC clothing?

::::solution[Solution]
Because both require **abstracting a structure and matching it across different content**: Parallel matches an argument's logical form; analogy matches a passage's relationship/process. In each, you strip away the topic, reduce to a skeleton, and find the choice with the same skeleton — so the same abstraction-and-match method applies.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A passage's relationship has the structure "depends on B yet resents that dependence." An answer captures "depends on B" but not the resentment. Correct?

::::solution[Solution]
**No** — it's a **partial match**. The relationship has two features (dependence *and* resentment of it); a correct analogy must reproduce *both*. Capturing only the dependence misses half the structure, so it loses to an answer that includes the resentment too.
::::
:::

## 18.6 · Worked passage (mixed question types)

:::example
Passage — natural science

(1) For a century, biologists explained the vivid coloration of many poison frogs as a straightforward warning signal: bright colors advertise toxicity, teaching predators to stay away. (2) This "aposematism" account is elegant and well supported for many species.

(3) Recent fieldwork, however, has revealed a puzzle. (4) In several frog populations, individuals vary enormously in brightness, yet all are equally toxic. (5) If color simply signals toxicity, why would equally poisonous frogs differ so much in appearance? (6) One team proposes that brightness also functions in mate choice: brighter males attract more mates, creating a second selective pressure alongside predator warning. (7) On this view, a frog's color reflects a compromise between two demands — being conspicuous enough to warn predators and attractive enough to reproduce.

(8) Skeptics note that increased brightness should also make frogs more visible to predators that have not learned to avoid them. (9) The mate-choice team concedes the point but argues that, where predators are already well-conditioned, the reproductive advantage of brightness outweighs the small added risk. (10) The debate remains unsettled, but it has already enriched a picture once thought complete.

#### Map & main point

- **P1:** the traditional warning-signal (aposematism) account — well supported. **P2 (3–7):** pivot "however" → a puzzle (equally toxic frogs vary in brightness) and a new hypothesis: brightness also serves mate choice, so color is a compromise. **P3 (8–10):** a skeptics' objection, the team's concession-and-rebuttal, and the author's wrap-up: debate unsettled but productive.
- **Main point:** the traditional view that frog color merely warns predators is incomplete; recent work suggests color also reflects mate-choice pressures, though the question is unresolved. *(Hedged — the author reports rather than endorses one side.)*

### Questions

::::problem[Q1]{difficulty="standard"}
*(Global)* The primary purpose of the passage is to…

- **(A)** compare the coloration of frogs with that of other amphibians.
- **(B)** argue that mate choice is the sole explanation for frog coloration.
- **(C)** prove that frog coloration has nothing to do with warning predators.
- **(D)** present a puzzle for the traditional account of frog coloration and describe a new hypothesis and the debate around it.
- **(E)** describe the life cycle of poison frogs.

:::::solution[Solution]
**(D).** Right verb (present/describe a puzzle and debate) and whole-passage scope. (C) and (B) overshoot to extremes the author avoids; (E) is off-topic. The author reports rather than takes a firm side.
:::::
::::

::::problem[Q2]{difficulty="standard"}
*(Detail)* According to the passage, the puzzle prompting new research is that…

- **(A)** toxic frogs are always brighter than non-toxic ones.
- **(B)** predators cannot see frog coloration.
- **(C)** frogs change color seasonally.
- **(D)** brighter frogs are less toxic than duller frogs.
- **(E)** equally toxic frogs vary greatly in brightness.

:::::solution[Solution]
**(E).** Stated in sentences 4–5 ("individuals vary enormously in brightness, yet all are equally toxic"). (D) reverses it; (B),(C) aren't stated.
:::::
::::

::::problem[Q3]{difficulty="standard"}
*(Function)* The author raises the skeptics' objection in sentence 8 primarily to…

- **(A)** present a challenge to the mate-choice hypothesis, which its proponents then address.
- **(B)** introduce a third, unrelated hypothesis.
- **(C)** restate the traditional warning-signal account.
- **(D)** refute the mate-choice hypothesis conclusively.
- **(E)** provide evidence that toxicity and brightness are unrelated.

:::::solution[Solution]
**(A).** Sentence 8 is an objection; sentence 9 has the team concede and rebut it. Its function is to raise a challenge that's then addressed — the concede-and-counter move. (D) overstates; (B),(C) misdescribe.
:::::
::::

::::problem[Q4]{difficulty="standard"}
*(Attitude)* The author's attitude toward the mate-choice hypothesis is best described as…

- **(A)** enthusiastic endorsement.
- **(B)** open interest without firm commitment.
- **(C)** outright dismissal.
- **(D)** complete indifference.
- **(E)** cautious hostility.

:::::solution[Solution]
**(B).** The author presents it seriously and says it "enriched" the picture, but calls the debate "unsettled" — interested, not committed. (A) and (C) are too strong in opposite directions; (D) is contradicted by the engaged treatment.
:::::
::::

::::problem[Q5]{difficulty="challenge"}
*(Inference)* The passage suggests that a satisfactory account of poison-frog coloration may need to…

- **(A)** rely solely on mate-choice explanations.
- **(B)** abandon the idea that color warns predators.
- **(C)** consider more than one selective pressure acting on color.
- **(D)** conclude that color is unrelated to toxicity.
- **(E)** establish that brightness carries no cost to the frog.

:::::solution[Solution]
**(C).** The passage frames color as a possible "compromise between two demands" (warning + mate choice), implying a full account may combine multiple pressures. (B),(D),(A) are extremes the passage explicitly avoids (it retains warning value and calls the debate unsettled).
:::::
::::

::::problem[Q6]{difficulty="challenge"}
*(Analogy)* The "compromise between two demands" shaping frog color (sentence 7) is most analogous to…

- **(A)** a car built only for speed with no other consideration.
- **(B)** two identical cars produced by different factories.
- **(C)** a car that fails to meet any of its design goals.
- **(D)** a car designed to be both fuel-efficient and fast, whose final design balances the two competing goals.
- **(E)** a car whose design was copied wholesale from an earlier model.

:::::solution[Solution]
**(D).** Abstract structure: a single feature shaped by balancing *two competing pressures*. A car balancing efficiency and speed matches. (A) has only one demand; (B) is about duplication; (C) lacks the balancing structure.
:::::
::::
:::

## Chapter summary

:::summary
#### RC question types, distilled

- **Global (main point/purpose):** answer from your main-point sentence and map; nail the purpose *verb*, whole-passage scope, and correct strength.
- **Detail & inference:** go *back to the lines*; detail = stated (paraphrased), inference = one guaranteed step. No outside knowledge, no overshoot.
- **Attitude:** two dials — polarity and degree; answers are usually measured, and track *whose* attitude is asked.
- **Function & structure:** answer *why* a part exists (its role), and describe the whole passage's arrangement from your map.
- **Analogy:** Parallel Reasoning in RC — match the abstract relationship, both features, right direction; ignore topic.
:::

| Type | Where the answer comes from | Signature trap |
| --- | --- | --- |
| Main point / purpose | your main-point sentence + map | too narrow / wrong verb / overshoot |
| Detail | the exact stated lines | plausible misremembering |
| Inference | one supported step from the lines | over-inference / outside knowledge |
| Attitude | word choice + structure | too extreme / wrong polarity |
| Function | the element's role (map + context) | summarizing content instead of role |
| Structure | the paragraph map | misordered sequence |
| Analogy | abstract relationship | topic match / partial match |

LSAT Mastery — Chapter 18. Independent study material, not affiliated with LSAC. Practice passage and questions are original, written to illustrate the skills; use official LSAC PrepTests for timed practice.
