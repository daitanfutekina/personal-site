---
title: "The Four Passage Subjects"
source: "lsat_ch16_subjects.html"
---

Part III · Chapter 16

# The Four Passage Subjects

RC passages rotate through four topic families. You don't need to know any of them in advance — but knowing each family's typical *structure* and traps lets you stay calm when a passage looks alien.

**Est. study time:** 45–55 min — **Sections:** 5 — **Practice:** 14+ items

## Overview

Every Reading Comprehension section draws its four passages from four broad areas: **natural sciences, social sciences, humanities and the arts, and law.** On any given test you'll face a topic — coral symbiosis, medieval guilds, a poet's late style, a doctrine of contract — that you may know nothing about. That's fine and expected: the credited-response principle (Chapter 1) guarantees everything you need is on the page. But each subject family has *characteristic structures, question tendencies, and traps*, and recognizing them turns "I've never heard of this" into "ah, this is a science passage arguing for a new hypothesis — I know how these go." This chapter is orientation, not content: you'll learn the shape of each family, not its facts.

:::callout-tip
Prerequisites

Chapter 15 (read for structure, map the paragraphs, track voices, state the main point). This chapter applies that method to each subject's typical architecture. Chapter 1's outside-knowledge trap is especially relevant — familiarity with a topic is a liability, not an asset, in these passages.
:::

:::callout-key
The universal move for an intimidating passage

When a passage's *content* is over your head, retreat to **structure**: you don't need to understand the biochemistry to see that P1 states a puzzle, P2 offers hypothesis A, P3 offers hypothesis B, and P4 says the evidence favors B. Answer from the architecture. Difficulty of content ≠ difficulty of questions — dense science passages often have very mechanical question sets.
:::

## 16.1 · Natural sciences

:::callout-intuition
What to expect

Science passages read as the most intimidating (unfamiliar jargon, technical detail) but are often the most *structurally predictable*. They typically pose a phenomenon or puzzle, present one or more hypotheses to explain it, and weigh evidence. The jargon is a paper tiger: you rarely need to understand the mechanism, only to track which hypothesis each paragraph supports.
:::

:::definition
**Typical natural-science structures.** (a) *Phenomenon → competing explanations → evaluation* ("Why do some birds migrate at night? Theory 1… Theory 2… evidence favors…"). (b) *Old model → anomaly → new model*. (c) *Description of a process/discovery* (more neutral, expository). Questions lean on **function** ("why does the author mention X?"), **detail**, and **hypothesis-tracking**.
:::

:::callout-tip
How to stay calm

**Don't try to learn the science.** When you hit "the mitochondrial electron transport chain," note it as "[a technical detail supporting the claim]" and move on. Track the *argument*: which theory is being described, is this evidence *for* or *against* it, whose view is it. If a question needs the technical detail, go back and read those two lines then. Underlining/highlighting the names of competing theories helps you navigate.
:::

:::example
Worked micro-excerpt — track the hypothesis, not the chemistry

standard

"Why do leaves turn red in autumn? One hypothesis holds that red pigments (anthocyanins) are merely a byproduct of chlorophyll breakdown. A rival view proposes that trees actively produce anthocyanins as a sunscreen, protecting leaves during the vulnerable period of nutrient reabsorption. Supporting the latter, red coloration is strongest on the sun-exposed side of leaves."

**Task.** Without any botany, state the structure and which hypothesis the evidence supports.

Structure: phenomenon (red leaves) → Hypothesis 1 (byproduct) → Hypothesis 2 (active sunscreen) → evidence favoring Hypothesis 2. The sun-exposed-side evidence supports the "active sunscreen" view.

**How we get there.** You don't need to know what anthocyanins are. Tag: H1 = "byproduct" (passive), H2 = "sunscreen" (active/protective). The last sentence ("Supporting the latter…") explicitly attaches the evidence to H2. If a question asked "the sun-exposed-side fact functions to…," the answer is "support the sunscreen hypothesis." **Teaching point:** reduce the science to competing labels and track which one each sentence backs — the chemistry is scenery.
:::

:::callout-pitfall
Watch out for these mistakes

- **Trying to understand the mechanism.** You'll burn time and it's rarely tested. Track roles (which hypothesis, for/against), not chemistry.
- **Panicking at jargon.** Technical terms are labels to navigate by, not concepts to master. Note their function and move on.
- **Confusing two hypotheses.** When a passage weighs rival explanations, tag them clearly so you don't attribute H1's evidence to H2.
:::

## 16.2 · Social sciences

:::callout-intuition
What to expect

Social-science passages (history, economics, sociology, anthropology, political science) usually revolve around *interpretations* and *causal claims* about human behavior and societies. Expect competing scholarly views, a traditional account being revised, and lots of hedged, argumentative prose. These passages are often the most **opinion-dense**, so attribution (Chapter 15.3) is at a premium — there are many voices to keep straight.
:::

:::definition
**Typical social-science structures.** (a) *Traditional interpretation → revisionist challenge → author's synthesis* (like the Chapter 15 worked passage). (b) *A causal claim about society, examined* ("Did the printing press cause the Reformation?"). (c) *Two schools of thought compared.* Questions emphasize **author's attitude**, **whose-view attribution**, and **the main point of a debate**.
:::

:::callout-tip
How to stay calm & sharp

Because these passages stack opinions, **tag every view with its owner** as you read: traditionalists, revisionists, the author. Watch pivots ("however," "yet," "more recently") that introduce a new camp or the author's synthesis. The single biggest error here is attributing a reported scholarly view to the author — so know, at every moment, *who is speaking.*
:::

:::example
Worked micro-excerpt — count the voices

standard

"Earlier scholars saw the guild system as a brake on economic growth, protecting inefficient producers. More recent work, however, emphasizes the guilds' role in training skilled labor and maintaining quality standards. The truth likely lies between: guilds both preserved outdated practices and transmitted valuable expertise."

**Task.** Identify the voices and the author's position.

Voices: earlier scholars (guilds = brake on growth), recent scholars (guilds = beneficial training/quality), author (a middle synthesis — both harmful and valuable). Author's view: the balanced middle position.

**How we get there.** Tag: "Earlier scholars saw" = [camp 1], not the author. "More recent work, however, emphasizes" = [camp 2], introduced by the pivot "however," still not the author. "The truth likely lies between" = the author's own synthesis (hedged: "likely," "between"). A trap answer might attribute camp 1's "brake on growth" view to the author — but the author explicitly balances the two. **Teaching point:** social-science passages reward the attribution discipline from Chapter 15; the author's view is often a synthesis stated last.
:::

:::callout-pitfall
Watch out for these mistakes

- **Attributing a scholarly camp's view to the author.** The dominant social-science trap. Tag every position's owner.
- **Missing the author's synthesis.** The author's own view often arrives at the end as a middle ground ("the truth lies between," "a more nuanced view"). Don't stop reading at the second camp.
- **Over-reading a causal claim as settled.** These passages often *examine* a causal claim rather than assert it — note the author's degree of commitment.
:::

## 16.3 · Humanities & the arts

:::callout-intuition
What to expect

Humanities passages cover literature, art, music, philosophy, and cultural criticism. They tend to be the most *interpretive* and least "factual" — often an author advancing a reading of a work, an artist, or a movement, sometimes with lyrical or abstract prose. The challenge isn't jargon (as in science) but *slipperiness*: the claims are about meaning, style, and influence, and the author's attitude can be subtle. Nuance and tone matter more here than anywhere else.
:::

:::definition
**Typical humanities structures.** (a) *An interpretation of an artist/work advanced and defended* ("Dickinson's dashes are not eccentric punctuation but a deliberate prosody"). (b) *A reassessment of a figure's reputation.* (c) *An abstract argument about aesthetics or method.* Questions emphasize **author's attitude/tone**, **the meaning/function of a phrase**, and **nuanced main point**.
:::

:::callout-tip
How to stay calm & precise

Two habits. First, **pin the author's thesis about the work** in plain terms ("the author argues X's late paintings reject realism deliberately"). Second, **read tone carefully** — humanities authors are rarely neutral, but their attitude is usually *measured* ("admiring but critical of the excesses," not "worshipful"). Don't let elegant prose obscure a simple structural claim; strip it to "who thinks what about this work, and what does the author conclude."
:::

:::example
Worked micro-excerpt — pin the interpretation and the tone

standard

"Critics have often dismissed the composer's final quartets as the incoherent products of failing health. Such a view mistakes difficulty for disorder. The late works are not confused but uncompromising — they demand a listener willing to abandon the comfortable resolutions of his earlier style."

**Task.** State the author's interpretation and attitude.

Interpretation: the late quartets are deliberately demanding and coherent, not the incoherent result of illness. Attitude: admiring of the late works; dismissive of the critics who misread them.

**How we get there.** Tag the critics' view ("Critics have often dismissed… incoherent") as [others], which the author rejects ("Such a view mistakes difficulty for disorder"). The author's thesis: the works are "uncompromising," demanding — a positive reinterpretation. Tone toward the works: appreciative; toward the critics: corrective. A trap on an attitude question might offer "the author finds the late works confusing" — but that's the critics' view the author refutes. **Teaching point:** in humanities, separate the reputation/critics' view from the author's reinterpretation, and read the author's attitude as specific and measured.
:::

:::callout-pitfall
Watch out for these mistakes

- **Missing subtle tone.** Humanities attitude answers are finely graded ("qualified admiration," "gentle skepticism"). Extreme tone words (contempt, adoration) are usually wrong.
- **Letting lyrical prose hide a simple structure.** Beneath the style is usually "critics said X; the author argues Y." Find it.
- **Confusing the work's qualities with the author's attitude.** "The paintings are chaotic" (a described quality) ≠ "the author disapproves" (an attitude). Keep them separate.
:::

## 16.4 · Law

:::callout-intuition
What to expect

Law passages discuss legal doctrines, cases, statutes, or debates in legal theory — fitting, given the exam. They're often *argumentative* and precise, hinging on distinctions, definitions, and conditions ("a contract requires offer, acceptance, and consideration"). The good news: your Logical Reasoning training pays off directly here — these passages reward exactly the conditional-logic and careful-distinction skills from Part II. Note that **no legal knowledge is required or rewarded**; everything is defined in the passage.
:::

:::definition
**Typical law structures.** (a) *A doctrine/rule explained, then applied or critiqued.* (b) *Two legal interpretations or standards compared.* (c) *A tension between competing legal principles or values.* Questions emphasize **precise application of a rule to cases** (like Principle questions, Chapter 13), **fine distinctions**, and **the function of an example or hypothetical.**
:::

:::callout-tip
How to stay calm & exact

**Treat legal rules like conditionals** (Chapter 5): note the conditions a rule requires and any exceptions, and track how cases/hypotheticals do or don't satisfy them. Law passages often introduce a hypothetical to *test* a rule's boundaries — recognize its function. Precision with words like "unless," "only if," "provided that," and "except" is decisive, exactly as in conditional logic.
:::

:::example
Worked micro-excerpt — treat the rule as a conditional

challenge

"Under the traditional rule, a promise is enforceable only if supported by consideration — something of value exchanged for it. Some courts, however, now enforce a promise lacking consideration when the promisee has reasonably relied on it to their detriment. Consider a charity that begins constructing a building after a donor pledges funds: under the traditional rule the pledge is unenforceable, but under the reliance doctrine it may be."

**Task.** State the two rules as conditions and the function of the charity example.

Traditional rule: enforceable → supported by consideration. Reliance doctrine: a promise may be enforceable even without consideration if the promisee reasonably relied to their detriment. The charity example functions to illustrate how the two rules yield different outcomes on the same facts.

**How we get there.** Translate: traditional rule = `enforceable → consideration` ("only if" marks the necessary condition — Chapter 5). The reliance doctrine adds an alternative path to enforceability (detrimental reliance). The charity hypothetical isn't decoration — its *function* is to show the doctrines diverge (unenforceable traditionally, possibly enforceable under reliance). A Function question would ask exactly that. **Teaching point:** law passages are LR in disguise — parse conditions, note exceptions, and identify what each example is *doing.*
:::

:::callout-pitfall
Watch out for these mistakes

- **Importing legal knowledge.** Even if you know some law (or think you do), answer only from the passage's definitions — outside knowledge is the usual trap (Chapter 1).
- **Sloppy reading of conditions.** "Only if," "unless," and "except" set precise logical relationships; misreading them mis-applies the rule.
- **Missing a hypothetical's function.** Examples in law passages usually *test or illustrate* a rule's boundary — identify that role rather than treating it as a random detail.
:::

## 16.5 · Drill set

Short excerpts from each subject family. For each, identify the structure/voices without needing outside knowledge. Difficulty rises.

:::problem[1]{difficulty="easy"}
(Science) "Astronomers once assumed the rings of Saturn were solid. Observations of starlight passing through them, however, showed the rings must be composed of countless separate particles." Structure?

::::solution[Solution]
**Old model → anomaly/observation → revised model.** Voices: "astronomers once assumed" = old view (not author's); "however… showed" = the corrected view. No astronomy needed — track the reversal.
::::
:::

:::problem[2]{difficulty="standard"}
(Social science) "Traditional accounts credit the railroad with driving nineteenth-century economic growth. Recent economic historians argue its impact was smaller than believed, since canals and roads already provided cheap transport." Whose view is each sentence?

::::solution[Solution]
Sentence 1 = **traditional accounts** (railroad = key driver). Sentence 2 = **recent economic historians** (impact overstated). Neither is yet clearly the author's — watch for a later synthesis. Attribution is the skill.
::::
:::

:::problem[3]{difficulty="standard"}
(Humanities) "Far from being the sentimental verses their popularity might suggest, the poet's ballads conceal a sharp irony beneath their simple surfaces." Author's interpretation and tone?

::::solution[Solution]
Interpretation: the ballads are **ironic and complex, not merely sentimental**. Tone: appreciative of their hidden sophistication; implicitly correcting the "sentimental" misreading. Note the reinterpretation structure ("Far from being X, they are Y").
::::
:::

:::problem[4]{difficulty="standard"}
(Law) "A search is lawful only if authorized by a warrant, unless it falls within a recognized exception such as consent." Translate the rule.

::::solution[Solution]
`lawful search → (warrant OR a recognized exception like consent)`. "Only if" sets the necessary condition; "unless" introduces an alternative path (exception). A consented search can be lawful without a warrant.
::::
:::

:::problem[5]{difficulty="standard"}
(Science) A passage spends a paragraph on the biochemistry of how a toxin blocks nerve signals. On your first read, what should you extract?

::::solution[Solution]
Its **function** — e.g., "detailed mechanism supporting the claim that the toxin causes paralysis" — not the biochemistry itself. Note it as a supporting detail and move on; return only if a question requires the specifics.
::::
:::

:::problem[6]{difficulty="challenge"}
(Social science) "The truth, as so often, resists both camps' certainties." Whose view is this, and what does it tell you about the passage's structure?

::::solution[Solution]
It's the **author's** voice delivering a **synthesis/middle position** that rejects both previously described camps' strong claims. Structurally, it signals that two opposing views preceded it and the author is now staking out a balanced thesis — likely the main point.
::::
:::

:::problem[7]{difficulty="challenge"}
(Law) "Consider a passerby who, seeing a stranger's house on fire, breaks in to rescue a child. Is she liable for trespass?" What is this hypothetical's likely function?

::::solution[Solution]
To **test the boundary of a rule** — probably introducing an exception or defense (e.g., necessity) to the trespass rule. Law passages use hypotheticals to probe where a doctrine applies or breaks down; recognize the example's role rather than treating it as narrative.
::::
:::

:::problem[8]{difficulty="challenge"}
In one or two sentences, explain why "I know a lot about this topic" can hurt you on an RC passage in that subject.

::::solution[Solution]
Because RC rewards only what the **passage** supports, and topic familiarity tempts you to answer from outside knowledge — picking a choice that's true in the real world but unsupported by (or even contrary to) the text (the Chapter 1 outside-knowledge trap). Experts also risk assuming the passage says what they'd expect rather than what it actually says. Structure-reading and strict textual support protect you regardless of subject.
::::
:::

## Chapter summary

:::summary
#### The four subjects, distilled

- **Natural sciences:** intimidating jargon, predictable structure. Track competing hypotheses (for/against), ignore the mechanism unless a question needs it.
- **Social sciences:** opinion-dense debates. Tag every camp's view; the author's synthesis often comes last. Attribution is everything.
- **Humanities & arts:** interpretive and tonal. Pin the author's thesis about the work; read attitude as specific and measured, not extreme.
- **Law:** LR in disguise. Treat rules as conditionals, note exceptions ("unless/only if"), and identify what each hypothetical tests.
- **Universal:** retreat to structure when content overwhelms; no outside knowledge — familiarity is a liability, not an asset.
:::

LSAT Mastery — Chapter 16. Independent study material, not affiliated with LSAC. Practice excerpts are original, written to illustrate the structures; use official LSAC PrepTests for timed practice.
