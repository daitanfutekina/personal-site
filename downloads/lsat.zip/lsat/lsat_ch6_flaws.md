---
title: "The Flaw Catalog"
source: "lsat_ch6_flaws.html"
---

Part II · Chapter 6

# The Flaw Catalog

The LSAT reuses the same dozen reasoning errors over and over. Learn them as a vocabulary and you'll spot the mistake in an argument before you've finished reading it — the core skill behind Flaw, Weaken, and half of Parallel questions.

**Est. study time:** 70–85 min — **Sections:** 6 — **Practice:** 28+ items

## Overview

In Chapter 4 you learned to find the *gap* in an argument. This chapter is a field guide to the specific gaps the LSAT loves — the recurring ways arguments go wrong. There are only about a dozen, they appear on every test, and the credited answers to Flaw questions describe them in stock phrases. Once these are second nature, you'll often read a stimulus and think "that's a causation flaw" before you even reach the question — and the right answer will be the one that names it.

Treat this as a catalog to *internalize*, not just read. For each flaw, learn (1) the plain-English tell, (2) how the LSAT phrases it in answer choices, and (3) how it connects to weakening (deny the flawed assumption) and to the conditional logic of Chapter 5. We group ~12 flaws into six families.

:::callout-tip
Prerequisites

Chapter 4 (conclusion, premise, gap) and Chapter 5 (necessary/sufficient, the four forms). Several flaws here are just those Chapter 5 fallacies wearing real-world clothing.
:::

## 6.1 · Causation flaws

:::callout-intuition
Intuition first

This is the most tested flaw family on the LSAT, so learn it cold. The pattern: the argument notices that two things go together (a *correlation*) and leaps to "one causes the other" (a *causal claim*). But things can travel together for reasons that have nothing to do with one causing the other. Whenever a conclusion says X *causes*, *produces*, *leads to*, or is *responsible for* Y — while the evidence is just that X and Y occur together — a causation flaw is almost certainly present.
:::

:::definition
**Definition 6.1 — Causal flaw (correlation ≠ causation).** Concluding that X causes Y from evidence that X and Y merely correlate. The argument overlooks three standard alternatives: **(a) an alternative cause** — some third thing Z causes both; **(b) reversed causation** — Y actually causes X; and **(c) coincidence** — the correlation is chance. Any of these, if possible, sinks the causal conclusion.
:::

### How the LSAT phrases it (learn these stock lines)

- "…takes for granted that one thing caused another merely because it preceded/accompanied it."
- "…fails to consider that another factor may be responsible for both."
- "…overlooks the possibility that the causal relationship is reversed."
- "…concludes a causal relationship from a mere correlation."

:::example
Worked Example 6.1 — the three alternatives

standard

"Cities with more police officers per capita have higher crime rates. Clearly, hiring more police officers causes crime to rise."

**Question.** The reasoning is flawed because it fails to consider that…

Answer: the causation may be reversed — high-crime cities hire more police in response to the crime, not the other way around.

**How we get there.** Evidence: police-per-capita correlates with crime. Conclusion: police *cause* crime. Run the three alternatives: **(a) alternative cause** — poverty or population density could drive both more police *and* more crime; **(b) reversed causation** — cities with lots of crime hire more police *because* of the crime (overwhelmingly the real story); **(c) coincidence** — unlikely across many cities. The most damning is reversed causation. Any Flaw answer naming one of these overlooked possibilities is correct. **Teaching point:** to attack a causal argument, you don't disprove the cause — you just show another explanation was ignored.
:::

:::callout-connect
Connects to Weaken (Chapter 8)

Causation is the bridge between Flaw and Weaken. On a *Flaw* question you *name* the overlooked alternative ("ignores a possible common cause"); on a *Weaken* question you *supply* one ("Study finds poverty drives both"). Same underlying gap, two jobs. Master causation here and you've pre-loaded half of Chapter 8.
:::

:::callout-pitfall
Watch out for these mistakes

- **Requiring the argument to be "disproven."** A causal flaw exists as soon as an alternative is *possible and overlooked* — you needn't prove the alternative is true.
- **Missing reverse causation.** It's the least intuitive of the three and therefore the most heavily tested. Always ask "could Y cause X?"
- **Confusing "after this" with "because of this."** "Crime fell after the new mayor took office" doesn't mean the mayor caused it (the *post hoc* version of the flaw).
:::

### Practice — 6.1

:::problem[Q1]{difficulty="easy"}
"People who take vitamin C report fewer colds. So vitamin C prevents colds." Name the flaw family and one overlooked alternative.

::::solution[Solution]
**Causal flaw** (correlation→causation). Overlooked alternative: people who take vitamins may be healthier/wealthier overall (common cause), or those who rarely get colds may simply choose to take vitamins (reverse). The correlation doesn't establish prevention.
::::
:::

:::problem[Q2]{difficulty="standard"}
"Neighborhoods with more coffee shops have higher property values. To raise property values, the city should encourage coffee shops." Identify the flaw and the most likely real direction of causation.

::::solution[Solution]
**Causal flaw**, most plausibly **reversed**: rising/high property values (affluent areas) attract coffee shops, not the reverse. Also a possible common cause (neighborhood desirability drives both). Encouraging coffee shops needn't raise values.
::::
:::

:::problem[Q3]{difficulty="standard"}
Which stock LSAT phrase describes overlooking a common cause?

::::solution[Solution]
"**Fails to consider that another factor may be responsible for both**" (a third variable causing both the supposed cause and effect). Contrast with the reversed-causation phrase and the coincidence phrase.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"Every time the rooster crows, the sun rises shortly after. The rooster's crowing causes the sunrise." Which of the three causal alternatives most cleanly defeats this, and why not the others?

::::solution[Solution]
**Alternative/common cause** is cleanest: the earth's rotation (dawn approaching) causes *both* the light that prompts the rooster *and* the sunrise. Reverse causation ("sunrise causes crowing") is closer to true than the original but still misses that a third factor drives both. Coincidence fails because the correlation is perfectly reliable. The rooster and sunrise share a common cause; neither causes the other.
::::
:::

## 6.2 · Necessary/sufficient confusion

:::callout-intuition
Intuition first

You met this in Chapter 5 as the converse and inverse errors. In the wild, it shows up as an argument treating "you need X" as if it means "X is enough," or vice versa. Because it's so mechanical, it's one of the easiest flaws to catch *if* you translate the conditionals — and one of the easiest to miss if you read casually.
:::

:::definition
**Definition 6.2 — Necessary/sufficient confusion.** Treating a *necessary* condition as if it were *sufficient* (or the reverse). In conditional terms: from `A → B`, wrongly concluding `B → A` (affirming the consequent / converse) or `not A → not B` (denying the antecedent / inverse). The argument mistakes "required for" as "guarantees," or "enough for" as "the only way."
:::

### Stock LSAT phrasings

- "…confuses a condition necessary for an outcome with one sufficient for it."
- "…treats something that guarantees a result as though it were required for that result."
- "…assumes that because something is required, it must be enough."

:::example
Worked Example 6.2 — necessary read as sufficient

standard

"To get an A in the course, students must attend every lecture. Miguel attended every lecture, so he will get an A."

**Question.** The argument is flawed because it…

Answer: treats a necessary condition (attending every lecture) as if it were sufficient for the outcome (getting an A).

**How we get there.** Translate: "To get an A, must attend every lecture" → `A grade → attended all` (attendance is *necessary*). Miguel satisfied the necessary condition (attended all), and the argument concludes the outcome (an A). But there are surely other requirements — exams, papers. Satisfying a necessary condition doesn't guarantee the result. This is affirming the consequent from Chapter 5, now in prose. **Teaching point:** the instant you see "must," "requires," "only," or "needs," translate to an arrow — the flaw becomes obvious.
:::

:::callout-pitfall
Watch out for these mistakes

- **Not translating.** This flaw hides in plain language ("you need," "the key is," "as long as"). Convert to `A → B` and check the direction.
- **Confusing it with a causal flaw.** Necessary/sufficient is about *conditions*, not causes. If the argument says "requires/enough/only," it's this flaw; if it says "causes/produces," it's 6.1.
:::

### Practice — 6.2

:::problem[Q1]{difficulty="standard"}
"Great novelists read widely. Priya reads widely, so she'll be a great novelist." Flaw?

::::solution[Solution]
**Necessary/sufficient confusion.** `great novelist → reads widely` (reading widely is necessary, at most). Priya meets the necessary condition, but that doesn't guarantee the outcome — affirming the consequent.
::::
:::

:::problem[Q2]{difficulty="standard"}
"If you train hard, you'll finish the marathon. Sam didn't train hard, so Sam won't finish." Flaw?

::::solution[Solution]
**Necessary/sufficient confusion** (denying the antecedent). `train hard → finish`; denying the sufficient condition (didn't train) doesn't establish "won't finish" — Sam might finish anyway.
::::
:::

:::problem[Q3]{difficulty="challenge"}
Distinguish this flaw from a causal flaw using a one-line test.

::::solution[Solution]
Check the conclusion's verb. **"Causes/produces/leads to"** → causal flaw (6.1). **"Requires/is enough for/only/must"** → necessary-sufficient (6.2). One is about what brings something about; the other about what conditions accompany it.
::::
:::

## 6.3 · Sampling & statistical flaws

:::callout-intuition
Intuition first

Arguments often generalize from a small slice to a whole, or juggle percentages and raw numbers. Both invite specific errors: a slice that isn't representative can't speak for the whole, and a percentage without the underlying number (or vice versa) can mislead badly. When you see a survey, a study group, or a stat in the premises and a sweeping claim in the conclusion, check whether the numbers actually support the leap.
:::

:::definition
**Definition 6.3 — Sampling and statistical flaws.** Three common forms: **(a) unrepresentative sample** — generalizing from a group that differs systematically from the whole (biased or self-selected); **(b) too-small sample** — drawing a broad conclusion from too few cases; and **(c) percentage/number confusion** — treating a percentage as if it told you a raw count, or vice versa (a rising *percentage* can come with a falling *number* if the total shrank).
:::

:::example
Worked Example 6.3 — the biased sample

standard

"A magazine asked its readers to mail in whether they support stricter gun laws; 80% of respondents said yes. So most people in the country support stricter gun laws."

**Question.** The reasoning is most vulnerable to criticism because…

Answer: the sample (self-selected readers of one magazine who chose to respond) is not representative of the country.

**How we get there.** Two biases stack: the respondents are (1) readers of one particular magazine, whose views likely skew, and (2) *self-selected* — people who feel strongly and bother to mail in. Generalizing from this group to "most people in the country" is unwarranted. **Teaching point:** ask "who is in this sample, and how do they differ from the population the conclusion is about?" Self-selected and voluntary-response samples are the LSAT's favorite trap.
:::

:::example
Worked Example 6.4 — percent vs. number

challenge

"This year, a larger percentage of our budget went to research than last year. So we spent more money on research this year."

**Question.** Why might this fail?

Answer: a larger percentage of a smaller total can be less money — the overall budget could have shrunk.

**How we get there.** Percentage and raw amount are different. If last year's budget was $1,000,000 with 10% ($100k) to research, and this year's budget is $500,000 with 15% ($75k), the *percentage* rose but the *dollars* fell. The conclusion about money spent doesn't follow from the percentage alone. **Teaching point:** whenever a premise gives a percentage and the conclusion asserts an amount (or vice versa), suspect this flaw — you need the total to bridge them.
:::

:::callout-pitfall
Watch out for these mistakes

- **Ignoring self-selection.** Volunteers, call-in respondents, and online polls over-represent the motivated and are rarely representative.
- **Accepting a percentage as a count.** Always ask "percentage of *what*, and did the total change?"
- **Assuming a small study generalizes.** A handful of cases can't support a claim about millions.
:::

### Practice — 6.3

:::problem[Q1]{difficulty="standard"}
"We surveyed shoppers leaving a luxury store; most owned two or more cars. So most people in the city own two or more cars." Flaw?

::::solution[Solution]
**Unrepresentative sample.** Luxury-store shoppers aren't representative of the city; they skew wealthier. Can't generalize to the whole population.
::::
:::

:::problem[Q2]{difficulty="standard"}
"The percentage of traffic accidents involving teens fell this year. So fewer teens had accidents." What must you know before accepting this?

::::solution[Solution]
Whether the **total number of accidents (and the number of teen drivers) changed.** A smaller percentage of a larger total could be the same or more teen accidents. Percentage ≠ count without the base.
::::
:::

:::problem[Q3]{difficulty="standard"}
A company reports "complaints as a share of orders dropped, so customers are happier," but its order volume tripled. What's the issue?

::::solution[Solution]
Percentage/number confusion: with 3× the orders, a lower *rate* of complaints can still mean many *more* complaining customers. "Happier" doesn't follow from the falling share alone.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why are voluntary online polls especially prone to the sampling flaw, in two respects?

::::solution[Solution]
(1) **Self-selection**: only people motivated by the topic respond, over-representing strong opinions. (2) **Coverage bias**: the respondents are limited to that site's/platform's users, who differ from the general population. Both make the sample unrepresentative of any broad group the conclusion targets.
::::
:::

## 6.4 · Flaws of relevance

:::callout-intuition
Intuition first

These arguments dodge the actual issue and appeal to something beside the point — the arguer's character, an authority's say-so, popularity, or emotion. The tell is a mismatch: the conclusion is about whether a *claim is true*, but the support is about *who said it*, *how many believe it*, or *how it makes you feel*. None of those bear on truth.
:::

:::definition
**Definition 6.4 — Flaws of relevance.** Supporting (or rejecting) a claim with something logically irrelevant to it: **ad hominem** (attacking the person instead of the argument), **appeal to authority** (it's true because an authority — possibly unqualified or biased — says so), **appeal to popularity** (true because many believe/do it), and **appeal to emotion** (fear, pity, etc. in place of evidence).
:::

:::example
Worked Example 6.5 — ad hominem

standard

"Dr. Alvarez argues that the bridge is structurally unsafe. But Dr. Alvarez was once fined for a parking violation, so we can dismiss her claim about the bridge."

**Question.** The reasoning is flawed because it…

Answer: rejects a claim by attacking the person who made it rather than addressing the claim's merits.

**How we get there.** The conclusion is about the *bridge's safety* — an engineering question. The support is about Dr. Alvarez's *parking record* — irrelevant to whether the bridge is safe. Even a person with flaws can be right about a bridge. Attacking the source instead of the argument is **ad hominem**. **Teaching point:** ask "does this support bear on the *claim*, or just on the *claimant*?" If it's about the person, it's a relevance flaw.
:::

:::callout-connect
A subtlety worth knowing

Pointing out that a source is *biased* can be a legitimate reason to scrutinize their evidence — but it is **not** a valid reason to conclude their claim is *false*. "The tobacco-funded study may be biased, so let's examine its methods" is fair; "…so its conclusion is false" is ad hominem. The LSAT tests this line carefully.
:::

:::callout-pitfall
Watch out for these mistakes

- **Treating an authority's opinion as proof.** Even real experts can be wrong or biased; "an expert said so" isn't evidence the claim is true.
- **Mistaking popularity for truth.** "Most people believe it" and "everyone's doing it" establish nothing about correctness.
- **Confusing legitimate bias-flagging with ad hominem.** Questioning evidence quality is fair; declaring the conclusion false because of who said it is the flaw.
:::

### Practice — 6.4

:::problem[Q1]{difficulty="easy"}
"Nine out of ten dentists use this toothpaste, so it must be the best." Flaw?

::::solution[Solution]
**Appeal to popularity/authority.** What most dentists use doesn't establish that it's *best* — popularity and even expert usage aren't proof of superiority.
::::
:::

:::problem[Q2]{difficulty="standard"}
"My opponent's tax plan can't be trusted — he's been divorced twice." Flaw?

::::solution[Solution]
**Ad hominem.** His marital history is irrelevant to the merits of a tax plan. Attacking the person, not the proposal.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Think of the children who will suffer if this program is cut — therefore the program's budget is well managed." What relevance flaw, and what's the mismatch?

::::solution[Solution]
**Appeal to emotion.** The conclusion is about whether the budget is *well managed* (a factual/managerial claim); the support is an emotional appeal about suffering children, which doesn't bear on management quality.
::::
:::

:::problem[Q4]{difficulty="challenge"}
When is pointing out a source's funding a legitimate move, and when does it become ad hominem?

::::solution[Solution]
**Legitimate** when used to justify scrutinizing the source's *evidence or methods* ("industry-funded — let's check the data"). **Ad hominem** when used to declare the *conclusion false* solely because of the funding ("industry-funded, therefore wrong"). Bias warrants closer examination, not automatic falsehood.
::::
:::

## 6.5 · Flaws of language & structure

:::callout-intuition
Intuition first

Some arguments break not because of bad evidence but because of slippery *words* or a hidden loop. In **equivocation**, a single word quietly changes meaning between premise and conclusion, so the argument only "works" by trading on the shift. In **circular reasoning**, the conclusion is smuggled into the premises, so the argument assumes the very thing it claims to prove. Both feel persuasive until you slow down and check the words.
:::

:::definition
**Definition 6.5a — Equivocation.** Using the same term in two different senses within one argument, so that a premise and the conclusion appear connected but actually talk about different things. **Definition 6.5b — Circular reasoning (begging the question).** An argument whose conclusion is already assumed by one of its premises — it "proves" a claim by restating it. The tell: the premise is just the conclusion in other words.
:::

:::example
Worked Example 6.6 — equivocation

standard

"Any law that is just should be obeyed. This statute is a natural law of economics — it describes how markets behave. Therefore this economic law should be obeyed."

**Question.** The argument is flawed because it…

Answer: uses "law" in two different senses — a moral/legal rule versus a scientific description of how things behave.

**How we get there.** The first premise is about "law" meaning a *rule you can obey or break* (a just law). The conclusion is about an "economic law" meaning a *description of how markets behave* — which isn't the kind of thing you "obey" at all. The word "law" shifts meaning midway, so the premises never actually connect to the conclusion. **Teaching point:** when a key term repeats, verify it means the same thing each time; a meaning shift is equivocation.
:::

:::example
Worked Example 6.7 — circular reasoning

standard

"This novel is the greatest of the century, because no other novel of the century is as good as it is."

**Question.** The reasoning is flawed because it…

Answer: assumes what it sets out to prove — the premise restates the conclusion.

**How we get there.** The conclusion ("greatest of the century") and the premise ("no other is as good") say the *same thing*. The argument offers no independent reason; it just asserts the conclusion twice. That's circular reasoning / begging the question. **Teaching point:** check whether the premise gives *new* support or merely re-states the conclusion. If you could swap them and lose nothing, it's circular.
:::

:::callout-pitfall
Watch out for these mistakes

- **Missing a subtle meaning shift.** Equivocation can turn on ordinary words ("free," "natural," "right," "law"). Track a repeated key term's sense.
- **Calling every weak argument "circular."** Circularity specifically means the premise *is* the conclusion restated — not merely that the argument is unconvincing.
- **Overlooking circularity because it "sounds" like support.** Rephrasing the conclusion in fancier words can disguise the loop.
:::

### Practice — 6.5

:::problem[Q1]{difficulty="standard"}
"Feathers are light. What is light cannot be dark. So feathers cannot be dark." Flaw?

::::solution[Solution]
**Equivocation** on "light": first meaning *low in weight*, then *pale in color*. The shift makes the argument appear valid while connecting unrelated senses.
::::
:::

:::problem[Q2]{difficulty="standard"}
"The defendant is telling the truth, because he would never lie." Flaw?

::::solution[Solution]
**Circular reasoning.** "He would never lie" is essentially the same claim as "he's telling the truth" — the premise restates the conclusion rather than supporting it independently.
::::
:::

:::problem[Q3]{difficulty="challenge"}
Explain the difference between an equivocation flaw and a circular-reasoning flaw in one sentence each.

::::solution[Solution]
**Equivocation:** a key word changes meaning between premise and conclusion, so they only appear connected. **Circular:** the conclusion is assumed within a premise, so no independent support is offered. One is a meaning-shift; the other is a self-referential loop.
::::
:::

:::problem[Q4]{difficulty="standard"}
"Miracles are events that violate natural laws. Since a true miracle would break the laws of nature, and nothing can break those laws, miracles are impossible." Is there an equivocation risk, and on what word?

::::solution[Solution]
Potentially on "**laws of nature**" / "cannot be broken" — if "law of nature" is defined as an exceptionless regularity, the argument may smuggle its conclusion into the definition (bordering on circular). At minimum, whether laws "cannot be broken" is doing hidden work. Watch definitional terms that pre-decide the conclusion.
::::
:::

## 6.6 · Whole/part errors & false choice

:::callout-intuition
Intuition first

Two more high-frequency flaws. **Composition/division** errors slide between a whole and its parts: what's true of each part need not be true of the whole (and vice versa). **False dilemma** pretends there are only two options when more exist, then eliminates one to force the other. Both work by quietly narrowing reality.
:::

:::definition
**Definition 6.6a — Composition & division.** *Composition*: assuming what's true of the parts is true of the whole ("each player is excellent, so the team is excellent"). *Division*: assuming what's true of the whole is true of each part ("the team is excellent, so each player is excellent"). **Definition 6.6b — False dilemma.** Presenting two alternatives as the only possibilities when others exist, then arguing for one by rejecting the other.
:::

:::example
Worked Example 6.8 — composition

standard

"Every ingredient in this dish is delicious on its own. Therefore, the dish as a whole must be delicious."

**Question.** The flaw is that it…

Answer: assumes a property of the parts (each ingredient is delicious) transfers to the whole (the dish).

**How we get there.** Ice cream is delicious; pickles are delicious; the combination may be revolting. A property of each part needn't hold for the whole — that's the **composition** error. (The reverse — "the dish is delicious, so each ingredient is" — would be *division*.) **Teaching point:** notice when an argument moves between "each/every [part]" and "the [whole]"; the transfer is rarely guaranteed.
:::

:::example
Worked Example 6.9 — false dilemma

standard

"We must either cut the education budget or raise taxes. Raising taxes is unacceptable. So we must cut the education budget."

**Question.** The reasoning is flawed because it…

Answer: presents only two options as if they were the only possibilities, ignoring alternatives.

**How we get there.** The argument assumes the *only* two choices are cutting education or raising taxes. But there could be many others — cut a different program, borrow, find efficiencies, grow revenue elsewhere. By pretending it's binary and rejecting one branch, it forces the other. That's a **false dilemma**. **Teaching point:** whenever an argument says "either X or Y" and eliminates one, ask "are those really the only options?"
:::

:::callout-pitfall
Watch out for these mistakes

- **Accepting "either/or" framing.** Most real situations have more than two options; a genuine dilemma must show the alternatives are truly exhaustive.
- **Missing the part↔whole shift.** Watch the move between "each/all members" and "the group"; properties don't automatically transfer either direction.
- **Confusing composition/division with sampling.** Sampling generalizes from *some* members to *all* members; composition/division moves between *parts* and the *whole entity* — related but distinct.
:::

### Practice — 6.6

:::problem[Q1]{difficulty="standard"}
"Our company is the most profitable in the industry, so everyone who works here must be highly paid." Flaw?

::::solution[Solution]
**Division.** A property of the whole (company profitability) is assumed to apply to each part (each worker's pay). Profitable companies can pay individual workers little.
::::
:::

:::problem[Q2]{difficulty="standard"}
"Either you support this war or you don't support the troops. You oppose the war, so you don't support the troops." Flaw?

::::solution[Solution]
**False dilemma.** Supporting the troops and opposing a particular war are not the only two mutually exclusive options; one can do both. The binary framing is false.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Each brick is light enough to lift, so the whole wall is light enough to lift." Flaw?

::::solution[Solution]
**Composition.** A property of each part (liftable) is wrongly assumed to hold for the whole (the wall). Parts' properties don't automatically compose.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Distinguish false dilemma from a legitimate either/or premise. When is "either X or Y" acceptable?

::::solution[Solution]
An either/or is legitimate when the two options are genuinely **exhaustive and mutually exclusive** (e.g., "a whole number is either even or odd"). It's a false dilemma when other options exist but are hidden. The test: could there be a third possibility the argument ignored? If yes, it's a false dilemma; if the two truly cover all cases, the premise is fine.
::::
:::

## Chapter summary

:::summary
#### The flaw catalog at a glance

- **Causation** (most tested): correlation→cause; check alternative cause, reversed causation, coincidence.
- **Necessary/sufficient**: "required" read as "enough" (or reverse) — translate to arrows.
- **Sampling/statistics**: unrepresentative or tiny sample; percentage vs. raw number.
- **Relevance**: ad hominem, appeal to authority/popularity/emotion — attacks the person or crowd, not the claim.
- **Language/structure**: equivocation (word shifts meaning); circular reasoning (premise = conclusion).
- **Whole/part & false choice**: composition/division; false dilemma (only-two-options).
:::

| Flaw | The tell | Stock answer phrasing |
| --- | --- | --- |
| Causal | correlation → "causes" | "fails to consider another factor / reversed causation" |
| Nec/suff | "required" treated as "enough" | "confuses a necessary with a sufficient condition" |
| Sampling | biased/small group → all | "relies on an unrepresentative sample" |
| %/number | percentage ↔ count | "infers an amount from a proportion" |
| Ad hominem | attacks the person | "criticizes the source rather than the argument" |
| Appeal (pop./auth.) | "many/experts say so" | "takes popularity/authority as proof" |
| Equivocation | word shifts meaning | "uses a term in two different senses" |
| Circular | premise = conclusion | "presupposes what it seeks to establish" |
| Composition/division | part ↔ whole transfer | "assumes what's true of parts is true of the whole" |
| False dilemma | "only two options" | "treats two alternatives as exhaustive" |

## Mixed practice set

Fourteen items, mixed order and difficulty. For each, name the flaw — that's the skill Flaw questions test.

:::problem[1]{difficulty="easy"}
"Sales rose the month after our rebrand, so the rebrand boosted sales." Flaw?

::::solution[Solution]
**Causal** (post hoc): "after" isn't "because." Ignores other causes (seasonality, a sale, ads) for the rise.
::::
:::

:::problem[2]{difficulty="standard"}
"To be hired here you must speak Spanish. Lee speaks Spanish, so Lee will be hired." Flaw?

::::solution[Solution]
**Necessary/sufficient confusion.** Speaking Spanish is necessary, not sufficient; meeting it doesn't guarantee hiring.
::::
:::

:::problem[3]{difficulty="standard"}
"A poll on our fan forum shows 95% love the team's new logo, so the public loves it." Flaw?

::::solution[Solution]
**Unrepresentative (self-selected) sample.** Fan-forum respondents aren't the public and are self-selected. Can't generalize.
::::
:::

:::problem[4]{difficulty="standard"}
"You can't trust her argument about climate policy; she flew on a private jet once." Flaw?

::::solution[Solution]
**Ad hominem** (with a whiff of hypocrisy/*tu quoque*). Her travel doesn't bear on whether her policy argument is sound.
::::
:::

:::problem[5]{difficulty="standard"}
"This medicine is safe because it doesn't cause harm." Flaw?

::::solution[Solution]
**Circular reasoning.** "Doesn't cause harm" restates "safe"; no independent support is given.
::::
:::

:::problem[6]{difficulty="standard"}
"Each part of this machine is inexpensive, so the whole machine must be inexpensive." Flaw?

::::solution[Solution]
**Composition.** Cheap parts can sum to an expensive whole (many parts, assembly costs). Part property doesn't compose to the whole.
::::
:::

:::problem[7]{difficulty="standard"}
"Either we ban cars downtown or the air will never improve. We won't ban cars, so the air will never improve." Flaw?

::::solution[Solution]
**False dilemma.** Banning cars isn't the only way to improve air (emissions standards, transit, EVs). The binary is false.
::::
:::

:::problem[8]{difficulty="challenge"}
"Countries that adopted the policy grew faster afterward, so the policy causes growth" — but the fastest-growing were already booming before adopting it. Which flaw, and which alternative does the extra fact expose?

::::solution[Solution]
**Causal flaw**; the extra fact exposes **reverse causation / a pre-existing common cause** — booming economies adopted the policy (growth → adoption), or an underlying boom drove both. The correlation doesn't show the policy caused growth.
::::
:::

:::problem[9]{difficulty="standard"}
"The share of our revenue from overseas rose, so we earned more overseas." What's missing?

::::solution[Solution]
**Percentage/number confusion.** A larger share of a possibly smaller total revenue could be fewer dollars. Need the totals to conclude an amount.
::::
:::

:::problem[10]{difficulty="standard"}
"Millions of people can't be wrong — this diet works." Flaw?

::::solution[Solution]
**Appeal to popularity.** The number of adherents doesn't establish that the diet works.
::::
:::

:::problem[11]{difficulty="challenge"}
"Nothing is better than lifelong happiness. A cheese sandwich is better than nothing. So a cheese sandwich is better than lifelong happiness." Name the flaw and the shifting word.

::::solution[Solution]
**Equivocation** on "**nothing**." First it means "no thing is better" (a universal claim); second it means "not having anything" (a comparison to having nothing). The two senses don't connect, producing an absurd conclusion.
::::
:::

:::problem[12]{difficulty="standard"}
"A study of 12 patients at one clinic found the drug effective, so it's effective for everyone." Two flaws present — name them.

::::solution[Solution]
**Too-small sample** (12 patients) and **unrepresentative sample** (one clinic). Both undercut generalizing to "everyone."
::::
:::

:::problem[13]{difficulty="challenge"}
"The team is the best in the league, so its rookie backup goalie is the best backup goalie in the league." Flaw, and how would you weaken it?

::::solution[Solution]
**Division** (whole → part). To weaken: show the whole's excellence doesn't rest on that part — e.g., "the team is strong on offense despite a weak bench," or evidence the rookie is below-average. Any fact severing the part from the whole's quality undercuts it.
::::
:::

:::problem[14]{difficulty="challenge"}
In one or two sentences, explain how the flaw catalog connects to Weaken questions (Chapter 8).

::::solution[Solution]
Each flaw is a flawed *assumption*; a Weaken answer typically **denies that assumption**. So recognizing the flaw tells you exactly what a weakener will do: for a causal flaw, supply an alternative cause; for a sampling flaw, show the sample is biased; for a false dilemma, present a third option. Naming the flaw pre-loads the weakener.
::::
:::

LSAT Mastery — Chapter 6. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
