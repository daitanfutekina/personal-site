---
title: "The Complete LSAT Prep Guide"
source: "lsat_prep_guide.html"
---

Self-Study Field Guide

# The Complete LSAT Prep Guide

Everything the test covers, and exactly how to prepare for it — 2026 edition.

**Read time:** ~60 min — **Scope:** Full test + study plan — **Score scale:** 120–180 — **Updated:** June 2026

## 0 · How to use this guide

This is a study guide built around one idea: the LSAT is not a knowledge test, it's a *skill* test. You cannot cram facts for it. You improve the way you improve at a sport — by drilling specific movements, reviewing your mistakes obsessively, and building endurance over weeks. This guide gives you the full map of what's tested and a concrete, week-by-week plan to train for it.

:::callout-key
The single most important fact about the LSAT

Your score is almost entirely a function of **how you review**, not how many questions you do. A test-taker who does 20 questions and spends an hour understanding why every wrong answer was wrong will out-improve someone who does 100 questions and just checks the answer key. The chapter on [blind review](#blindreview) is the heart of this guide — if you read nothing else, read that.
:::

#### Recommended path

If you're brand new, read sections 1–3 to understand the test, then take a cold diagnostic (section 7 explains how) *before* reading the strategy sections. You learn the strategy much faster once you've felt the test bite you. After the diagnostic, work through Logical Reasoning and Reading Comprehension, then build your schedule from section 7.

:::callout-warning
A note on dates and fees

Test format, dates, and fees change. Every structural fact here was checked against LSAC and major prep sources in June 2026, but **always confirm specifics on [lsac.org](https://www.lsac.org)** — the official Law School Admission Council site — before you register or pay for anything.
:::

## 1 · What the LSAT is (and what it measures)

:::callout-intuition
Intuition first

Law school is, fundamentally, three years of reading dense arguments, finding their hidden assumptions, spotting where they break, and arguing about it in writing. The LSAT is a four-hour simulation of exactly that skill set, stripped of any actual legal knowledge. That's why you can't study "law" for it — there's no law on it. You're being measured on reasoning under time pressure.
:::

The **LSAT (Law School Admission Test)** is the standardized test administered by the **Law School Admission Council (LSAC)** and accepted by every ABA-accredited law school in the United States and Canada. Alongside your undergraduate GPA, it is the single most important number in your application — for many schools, the two numbers (LSAT + GPA) together drive the bulk of the admissions decision and nearly all merit scholarship money.

It tests three things, and only three things:

1. **Logical reasoning** — can you analyze a short argument, find its assumptions, and judge what strengthens, weakens, or follows from it?
2. **Reading comprehension** — can you absorb dense, unfamiliar academic prose quickly and answer precise questions about its structure and claims?
3. **Argumentative writing** — can you construct a coherent written argument that takes a position and addresses opposing views? (Required but unscored — more on this in section 6.)

:::callout-connect
Major change you should know about

Until August 2024, the LSAT had a famous "Logic Games" section (formally *Analytical Reasoning* — the grouping/ordering puzzles). **It was removed.** If you find old prep books or advice that talk about logic games, diagramming game boards, or "sequencing setups," that material is obsolete for the current test. The games were replaced by a second scored Logical Reasoning section.
:::

## 2 · Test structure & logistics

### The sections, at a glance

The multiple-choice LSAT has **four 35-minute sections**: three that count toward your score and one that doesn't.

| Section | Counts? | # of questions | Time |
| --- | --- | --- | --- |
| Logical Reasoning #1 | Scored | ~24–26 | 35 min |
| Logical Reasoning #2 | Scored | ~24–26 | 35 min |
| Reading Comprehension | Scored | ~26–28 | 35 min |
| Unscored "experimental" | **Not scored** | ~24–28 | 35 min |
| 10-minute break | — | — | after section 2 |

So of your four multiple-choice sections, **two are Logical Reasoning and one is Reading Comprehension that count**, plus one unscored section that is *either* an extra LR or an extra RC. Total scored questions: roughly 75–77. The whole multiple-choice portion runs about **2 hours 40 minutes** including the break.

:::callout-pitfall
Watch out for: the experimental section

The unscored section is **not labeled** and can appear anywhere in the test. LSAC uses it to try out new questions. You will not know which section doesn't count, so you must treat all four with full effort. The practical consequence: you will face **two LR sections and two RC sections, or three LR and one RC** on test day — and you have to sustain focus across all of them. This is why endurance training matters.
:::

### Logical Reasoning is now ~50% of your score

Because two of the three scored sections are LR, **Logical Reasoning makes up roughly half of your scored questions.** If you have limited time, LR is where the points are. This guide weights it accordingly.

~50% — of score is LR

~25% — of score is RC

35 — min per section

~1.4 — min per question

### How and where you take it

As of 2026 the LSAT is administered **entirely online**. You take it on your own computer from a private room, monitored by a live remote proctor over webcam and screen-share (LSAC also offers in-person testing at designated centers for those who need it; confirm current options when registering). You'll use LSAC's digital testing interface, which includes on-screen tools: a highlighter, line-spacing/font controls, a flag-for-review button, and an answer-elimination tool. **Get fluent with these tools before test day** by doing your practice tests in the same official interface (LawHub — see section 8).

### The writing task is separate

The **LSAT Argumentative Writing** task is taken separately from the multiple-choice exam — on your own computer, in a flexible window (you can complete it in the days leading up to or after your test date). It's included in your registration fee. It is currently **unscored**, but **your multiple-choice score will not be released to schools until you have an approved writing sample on file.** Don't skip it; you'll just be blocking your own score. Full details in section 6.

### Registration, timing, and retakes

- **When it's offered:** the LSAT is administered many times a year (roughly monthly, across multi-day windows). Check current dates at [lsac.org/LSATdates](https://www.lsac.org/LSATdates).
- **When to take it:** aim to take your *final* LSAT roughly 9–12 months before you want to start law school, and apply **early** in the admissions cycle (most schools use rolling admissions — applying in the fall beats applying in the spring).
- **Retakes:** LSAC limits how often you can take it (currently capped over a rolling multi-year period and across your lifetime — confirm the exact limits before registering). Most schools see all your scores but make decisions on your **highest**. Retaking is normal and often worth it.
- **Fees & waivers:** there's a test fee plus the CAS (Credential Assembly Service) fee most schools require. LSAC offers **fee waivers** for those who qualify — apply for one before paying full price if money is tight.

:::callout-tip
Practical move

Register for a test date *before* you feel ready. A fixed deadline 3–4 months out is the single best motivator for consistent study. You can push your date if needed, but an open-ended "someday" timeline is how people study for two years and never sit the test.
:::

## 3 · Scoring & percentiles

:::callout-intuition
Intuition first

You don't get a percentage-correct score. Your number of correct answers (the "raw score") is converted onto a **120–180 scale**, and that scaled number is mapped to a **percentile** telling schools how you did relative to everyone else. Because every point on the scale corresponds to a different number of questions depending on the test's difficulty, a handful of questions can swing your score several points — which is exactly why careful, no-careless-error practice pays off.
:::

### The scale

Scores run from **120 (lowest) to 180 (highest)**. There is no penalty for wrong answers, so **you should answer every single question** — never leave a blank. The median score across all test-takers is around **150–152**, which sits near the 50th percentile.

### What scores mean (approximate percentiles)

Percentiles shift slightly year to year, but these are representative of recent (2025) data:

| Scaled score | ~Percentile | What it signals |
| --- | --- | --- |
| 180 | ~99.9th | Perfect / near-perfect |
| 175 | ~99th | Top 1% — competitive at every school |
| 170 | ~95th | Top 5% — strong at T14 schools |
| 165 | ~86th | Top 14% — very competitive, scholarship territory |
| 160 | ~73rd | Top quarter — solid at many good schools |
| 155 | ~58th | Above average |
| 150 | ~44th | Roughly the median test-taker |
| 145 | ~26th | Below median |

:::callout-key
The shape of the curve matters

The scale is densest in the middle. Near 150, a single additional correct answer might move you ~1 point and several percentile spots. Near 175, each point requires near-perfection. In practical terms: **going from 150 to 160 is far easier than going from 165 to 175.** Set your target with that in mind.
:::

### Setting a target score

Your target shouldn't be a vanity number — it should be driven by **where you want to go to school.** Here's the process:

1. **List your target schools.** Pick 6–12 you'd realistically attend.
2. **Look up each school's "medians."** Every ABA school publishes its *median LSAT* and *median GPA* (in its ABA 509 report, and on free aggregators). The median is the score of the middle admitted student.
3. **Aim to beat the median.** Scoring *above* a school's median LSAT dramatically improves both your admission odds and your scholarship offers. Scoring below it means you usually need something else (high GPA, strong "softs") to compensate.
4. **Set your goal at or above the highest median on your list** that's realistic given your diagnostic. Then build the study plan to close the gap.

:::callout-tip
A realistic mental model of improvement

Most committed test-takers who put in **250–400 focused hours** improve **10–15+ points** over their cold diagnostic; some improve 20+. Improvement is real and trainable — but it comes from quality reps and review, not raw volume. Your diagnostic is your starting line, not your ceiling.
:::

### Score release & reporting

Scores are typically released a few weeks after your test date (you'll get an email). Through LSAC's **Credential Assembly Service (CAS)**, your scores, transcripts, and letters of recommendation are packaged and sent to the schools you apply to. Remember: scores are **not released at all** until your [writing sample](#writing) is on file.

## 4 · Logical Reasoning (the big one)

:::callout-key
Why this section gets the most space

Two of your three scored sections are Logical Reasoning, so it's **~50% of your score**. It's also the most *teachable* section — the question types are finite and recurring, so targeted practice produces the fastest, most reliable point gains. Master this and you've won half the test.
:::

:::callout-intuition
What LR actually asks of you

Each question gives you a short paragraph — the **stimulus**, usually a mini-argument of 2–5 sentences — followed by a question and five answer choices. The entire skill is: (1) separate the argument's *conclusion* from its *evidence*, (2) find the *gap* between them, and (3) use that gap to do whatever the question asks (strengthen it, attack it, name the flaw, etc.). Almost every LR question is a variation on "find the gap between premises and conclusion."
:::

### Anatomy of a Logical Reasoning question

Three parts, always in this order:

1. **Stimulus** — the paragraph. Contains either an *argument* (premises leading to a conclusion) or a *set of facts* (no conclusion).
2. **Question stem** — the sentence telling you your job. *Read this first or second, but always identify the type before evaluating answers.*
3. **Five answer choices** — exactly one is correct; the other four are "wrong" in specific, learnable ways.

#### The two things you must label in every stimulus

:::definition
**Conclusion:** the main point the author is trying to get you to accept. Test: "What is this person ultimately trying to convince me of?" Watch for indicator words — *therefore, thus, hence, so, clearly, it follows that, this shows that.*

**Premises:** the support offered for the conclusion. Indicator words — *because, since, for, given that, as, after all.*

**The gap (the assumption):** what must be true for the premises to actually deliver the conclusion. Most LR questions live in this gap.
:::

:::callout-tip
The single best habit in LR

Before you look at a single answer choice, **say the argument's conclusion and main gap out loud (or in your head) in your own words.** Then often **pre-phrase** what the right answer should do. Test-takers who jump straight to the choices get seduced by attractive wrong answers; test-takers who pre-phrase already know what they're hunting for.
:::

### Every Logical Reasoning question type

There are roughly 10–13 recurring types. They cluster into families. Crucially, **three types — Assumption, Flaw, and Inference — make up about 40% of all LR questions, and adding Strengthen and Weaken pushes you past 75%.** Master those five and most of the section is yours.

#### Family A — "Help or hurt the argument"

| Type | The stem sounds like… | Your job |
| --- | --- | --- |
| **Strengthen** | "…most *supports* the argument?" | Find the choice that makes the conclusion *more* likely. You don't have to prove it — just help. |
| **Weaken** | "…most *undermines* / calls into question?" | Find the choice that makes the conclusion *less* likely. Attack the gap. |
| **Necessary Assumption** | "…argument *depends on* assuming?" | Find a premise the argument *needs* to be true. Test with negation: if negating the choice destroys the argument, it's required. |
| **Sufficient Assumption** | "…if assumed, allows the conclusion to be *properly drawn*?" | Find a premise that, added in, makes the conclusion airtight. Often bridges a term in the premises to a term in the conclusion. |

#### Family B — "Describe or evaluate the reasoning"

| Type | The stem sounds like… | Your job |
| --- | --- | --- |
| **Flaw** | "…reasoning is *flawed* / vulnerable to criticism because…" | Name the logical error. The wrong answers describe errors the argument *didn't* make. Learn the classic flaw catalog (below). |
| **Method / Argument Structure** | "…argument proceeds by…" | Describe *how* the argument is built (abstractly), not whether it's right. |
| **Role / Function** | "the claim that \_\_\_ plays which role?" | Identify what a specific sentence *does* — is it the conclusion, a premise, a counter-example? |
| **Point at Issue / Disagreement** | "two speakers disagree about whether…" | Find the exact claim one affirms and the other denies. |
| **Parallel Reasoning** | "…most *similar in its reasoning* to…" | Match the argument's *logical structure* (not topic) to one of five other arguments. |
| **Parallel Flaw** | "…contains *flawed reasoning most similar* to…" | Same as above, but match the *specific error*. |

#### Family C — "What can you conclude / reconcile"

| Type | The stem sounds like… | Your job |
| --- | --- | --- |
| **Inference / Must Be True** | "…which *must be true* / is *most supported*?" | The stimulus is facts (no conclusion). Find the choice the facts *guarantee* (or, for "most supported," strongly back). Don't bring outside info. |
| **Paradox / Resolve-Explain** | "…most helps to *resolve* the apparent discrepancy?" | Two facts seem to conflict. Find the choice that lets *both* be true at once. |
| **Principle** | "…conforms to / which principle justifies…" | Match a general rule to a specific case (in either direction). A hybrid that borrows from Strengthen/Inference. |

:::callout-warning
The classic flaw catalog — memorize these

Flaw and Weaken questions reuse the same handful of reasoning errors. Learn them as a vocabulary:

- **Correlation ≠ causation** — assuming because A and B occur together, A causes B.
- **Necessary vs. sufficient** — confusing "required for" with "guarantees."
- **Sampling / unrepresentative survey** — generalizing from a biased or tiny sample.
- **Ad hominem** — attacking the source instead of the argument.
- **Equivocation** — using one word in two different senses.
- **Circular reasoning** — assuming what you're trying to prove.
- **Part-to-whole (composition/division)** — what's true of the parts must be true of the whole, or vice-versa.
- **False dilemma** — presenting two options as if they're the only ones.
- **Appeal to authority / popularity** — "experts/most people say so, therefore true."
- **Confusing absence of evidence with evidence of absence.**
:::

### The Logical Reasoning method (repeat it every question)

1. **Read the stem first** to know your job (Strengthen? Flaw? Inference?). This tells you *how* to read the stimulus.
2. **Read the stimulus actively.** Find and mentally mark the conclusion. Everything else is either support or noise.
3. **Find the gap.** What is the author assuming to get from premises to conclusion? (For Inference questions, there's no conclusion — instead, combine the facts.)
4. **Pre-phrase.** Predict what the right answer should do before reading the choices.
5. **Eliminate aggressively.** Cross out choices that are out of scope, reverse the logic, or are too extreme. Aim to get down to two, then pick the one that does the job better.
6. **Confirm** the survivor actually answers *this* stem (not a different one).

:::callout-tip
Wrong-answer "flavors" to recognize on sight

Trap answers come in repeatable flavors: **out of scope** (introduces something irrelevant), **opposite** (does the reverse of what's asked — weakens when you need strengthen), **too strong** (uses "all/never/only" when the argument is modest), **half-right** (one clause is perfect, the other is wrong), and **true but useless** (a true statement that doesn't affect the conclusion). When stuck between two answers, name the flaw in the one you want to eliminate.
:::

### Worked examples (answer-first format)

Read the answer, then study the reasoning — the goal is to internalize the *process*, not memorize the items.

:::example
Worked Example 1 — Weaken

standard

**Stimulus.** "A new city ordinance banned cars from Main Street on weekends. In the three months since, foot traffic to Main Street shops rose 20%. Clearly, pedestrianizing the street caused the increase in shoppers."

**Question.** Which one of the following, if true, most weakens the argument?

- **(A)** Other cities have pedestrianized streets with mixed results.
- **(B)** Weekend car traffic on Main Street had been heavy before the ban.
- **(C)** Some shop owners opposed the ordinance.
- **(D)** A large new apartment complex opened one block from Main Street the same month the ban began.
- **(E)** Foot traffic is difficult to measure precisely.

Answer: (D).

**How we get there.** The conclusion is causal: *pedestrianizing caused the 20% rise*. The premise is just a correlation (ban happened, then traffic rose). The gap is the classic **correlation ≠ causation** assumption — the author assumes nothing *else* caused the rise. To weaken a causal claim, supply an **alternative cause**. (D) gives one: a new apartment complex full of potential shoppers opened at the same time. That makes the ban a less certain explanation.

Why not the others? (C) opinions about the ban don't bear on what caused traffic — *out of scope*. (E) measurement difficulty is vague and doesn't supply an alternative — *too weak*. (A) "mixed results elsewhere" doesn't address *this* street's cause — *out of scope*. (B) actually mildly *supports* the idea that removing cars mattered — *opposite*.
:::

:::example
Worked Example 2 — Necessary Assumption

standard

**Stimulus.** "The museum should display the newly donated painting. After all, displaying it would attract more visitors, and attracting more visitors is good for the museum."

**Question.** The argument depends on assuming which one of the following?

- **(A)** Visitors prefer paintings to sculptures.
- **(B)** The donor required that the painting be displayed.
- **(C)** The painting is the most valuable item the museum owns.
- **(D)** The museum has enough wall space to display the painting.
- **(E)** Nothing about displaying the painting would be bad enough for the museum to outweigh the benefit of more visitors.

Answer: (E).

**How we get there.** Conclusion: the museum *should* display it. Premise: doing so attracts visitors, which is good. The gap: the argument leaps from "has one good effect" to "should do it" — that only follows if there's **no overriding downside**. (E) plugs exactly that gap.

**The negation test (the key skill for Necessary Assumption).** Negate (E): "There *is* a downside bad enough to outweigh the extra visitors." If that's true, the argument collapses. Because negating the choice destroys the argument, the choice is *necessary*. Negate the others and the argument still stands, so they aren't required.
:::

:::example
Worked Example 3 — Inference / Must Be True

challenge

**Stimulus (facts only).** "Every employee who completed the safety course received a certificate. No one in the warehouse division has a certificate. Some warehouse employees have worked here over ten years."

**Question.** If the statements above are true, which one must also be true?

- **(A)** No warehouse employee completed the safety course.
- **(B)** Everyone outside the warehouse division completed the safety course.
- **(C)** The safety course was not offered to the warehouse division.
- **(D)** Most employees have certificates.
- **(E)** Some long-tenured employees completed the safety course.

Answer: (A).

**How we get there.** Chain the facts. "Completed course → has certificate." "No warehouse employee has a certificate." By contrapositive, *no certificate → did not complete course*. So no warehouse employee completed the course — that's (A), and it *must* be true.

Why not the others? (E) contradicts (A). (B) goes beyond the facts — we know nothing about whether non-warehouse staff all took it. (C) confuses "didn't complete" with "wasn't offered" — maybe it was offered and they skipped it. (D) we have no counts, so "most" is unsupported. **Lesson:** Inference answers must be *guaranteed* — anything needing an extra assumption is wrong.
:::

:::example
Worked Example 4 — Flaw

standard

**Stimulus.** "Dr. Lee argues that the city should fluoridate its water to reduce tooth decay. But Dr. Lee is a paid consultant for a company that sells fluoride. So the city should not fluoridate its water."

**Question.** The reasoning is most vulnerable to criticism on the grounds that it…

- **(A)** relies on a sample that is too small.
- **(B)** rejects a claim merely by criticizing the person who made it.
- **(C)** assumes what it sets out to prove.
- **(D)** confuses a necessary condition with a sufficient one.
- **(E)** generalizes from an exceptional case.

Answer: (B).

**How we get there.** The argument concludes the city *shouldn't* fluoridate solely because the recommender has a financial interest. Even if Dr. Lee is biased, that says nothing about whether fluoridation *works*. Attacking the arguer instead of the argument is the textbook **ad hominem** flaw — (B) names it exactly. The other choices describe real flaws the argument simply doesn't commit. **Lesson:** the right Flaw answer must match the error *actually* made.
:::

### Logical Reasoning drill set

Attempt each before opening the solution. Time yourself: aim for ~1:25 per question. Don't just check right/wrong — read the full explanation even when you're correct.

:::problem[Q1]{difficulty="easy"}
"All members of the chess club are students. Maria is not a student. Therefore, Maria is not a member of the chess club."

The reasoning above is most parallel to which one?

- **(A)** All squares are rectangles. So some rectangles are squares.
- **(B)** All cats are mammals. Rex is a mammal. So Rex is a cat.
- **(C)** All roses are flowers. This plant is not a flower. So this plant is not a rose.
- **(D)** Some birds can fly. Penguins are birds. So penguins can fly.
- **(E)** No fish are mammals. Whales are mammals. So whales are fish.

::::solution[Solution]
**(C).** The original is a valid contrapositive: "All A are B; not B; therefore not A." (C) has the identical structure (All roses are flowers; not a flower; therefore not a rose). (B) is the invalid "affirming the consequent." (D) misuses "some." (E) is invalid. (A) is a conversion, a different move. *Type: Parallel Reasoning. Skill: match logical form, ignore topic.*
::::
:::

:::problem[Q2]{difficulty="standard"}
"Sales of our magazine dropped after we raised the price. To reverse the decline, we should lower the price back to its original level."

Which one, if true, most weakens the recommendation?

- **(A)** The magazine's content has not changed in a year.
- **(B)** Lowering the price would reduce revenue per copy.
- **(C)** A competing magazine also raised its prices recently.
- **(D)** Most readers who canceled said they did so because a free online version became available, not because of price.
- **(E)** The price increase was smaller than the rate of inflation.

::::solution[Solution]
**(D).** The plan assumes the price rise *caused* the drop. (D) supplies a different cause (a free online alternative), so reversing the price wouldn't fix the real problem. (B) is a cost concern but doesn't attack the causal logic. (C), (E), (A) are out of scope. *Type: Weaken (plan). Skill: attack the assumed cause.*
::::
:::

:::problem[Q3]{difficulty="standard"}
"Studies show people who drink coffee live longer than those who don't. So drinking coffee must extend life."

The argument is most vulnerable to the criticism that it…

- **(A)** assumes that what is true of a group is true of each member.
- **(B)** uses the term "longer" in two different senses.
- **(C)** appeals to the opinions of people who are not experts.
- **(D)** relies on studies that were never published.
- **(E)** treats a correlation as though it established causation.

::::solution[Solution]
**(E).** Coffee-drinkers living longer is a correlation; concluding coffee *extends life* assumes causation, ignoring that, say, coffee-drinkers might exercise more. Classic correlation/causation flaw. *Type: Flaw. Skill: recognize the catalog flaw on sight.*
::::
:::

:::problem[Q4]{difficulty="standard"}
"To qualify for the scholarship, a student must have a GPA above 3.5. Jordan has a GPA of 3.8. Therefore, Jordan qualifies for the scholarship."

The reasoning is flawed because it…

- **(A)** treats a necessary condition as if it were sufficient.
- **(B)** treats a sufficient condition as if it were necessary.
- **(C)** relies on an unrepresentative sample.
- **(D)** draws a conclusion about a group from one individual.
- **(E)** assumes the conclusion among its premises.

::::solution[Solution]
**(A).** A GPA above 3.5 is *necessary* ("must have") but the argument treats it as *sufficient* ("therefore qualifies"). There may be other requirements (essays, deadlines). Meeting one requirement doesn't guarantee qualification. *Type: Flaw — necessary/sufficient. This confusion is one of the most tested errors on the LSAT.*
::::
:::

:::problem[Q5]{difficulty="standard"}
"The new bridge was supposed to reduce commute times. Yet since it opened, average commutes have gotten longer."

Which one, if true, most helps resolve the apparent discrepancy?

- **(A)** The bridge cost more than projected.
- **(B)** The bridge made the area so accessible that the population — and total traffic — grew sharply.
- **(C)** Commuters were skeptical of the bridge before it opened.
- **(D)** The old route is still available to drivers.
- **(E)** Bridge tolls are collected electronically.

::::solution[Solution]
**(B).** A paradox: better infrastructure, worse commutes. (B) explains both — the bridge worked *so* well that it drew far more people and cars, swamping the gain (the "induced demand" effect). Both facts can now be true at once. Others don't reconcile the two facts. *Type: Paradox/Resolve. Skill: find what lets both statements hold.*
::::
:::

:::problem[Q6]{difficulty="challenge"}
"Critic: This film cannot be considered great art, because great art challenges its audience, and this film was enormously popular with general audiences."

The critic's argument depends on assuming which one of the following?

- **(A)** Most great art is unpopular when first released.
- **(B)** General audiences cannot appreciate great art.
- **(C)** No film that is popular with general audiences challenges its audience.
- **(D)** All challenging films are unpopular.
- **(E)** Popularity is the only measure of a film's quality.

::::solution[Solution]
**(C).** The critic reasons: great art challenges; this film was popular; therefore not great. For that to work, the critic must assume popularity rules out being challenging — i.e., (C). Negate (C): "some films popular with general audiences *do* challenge them" — then popularity no longer disqualifies the film, and the argument fails. (D) and (B) are too strong / different claims. *Type: Necessary Assumption. Skill: negation test + spotting the suppressed link between "popular" and "not challenging."*
::::
:::

:::problem[Q7]{difficulty="challenge"}
"Economist: Raising the minimum wage will not increase unemployment. In the five cities that raised it last year, unemployment actually fell."

Which one, if true, most strengthens the economist's argument?

- **(A)** The five cities are located in different regions of the country.
- **(B)** The national economy was booming last year, lifting employment everywhere.
- **(C)** Comparable cities that did *not* raise the minimum wage saw unemployment fall by even more.
- **(D)** In those five cities, employment in low-wage industries specifically held steady or rose after the increase.
- **(E)** Minimum-wage workers in those cities reported higher job satisfaction.

::::solution[Solution]
**(D).** The worry is that the falling unemployment was caused by something else (general economy), not the wage policy — and that the wage hike might still have hurt the specific workers it targets. (D) addresses exactly the relevant group (low-wage industries), showing they didn't lose jobs — strengthening the causal claim. (B) and (C) *weaken* it by offering alternative causes / better comparison. (A) and (E) are out of scope. *Type: Strengthen (causal). Skill: protect the conclusion by ruling out the alternative explanation.*
::::
:::

:::problem[Q8]{difficulty="challenge"}
"Manager: We should adopt the four-day workweek. Productivity studies consistently show that well-rested employees produce higher-quality work, and our employees are frequently exhausted."

The claim that "our employees are frequently exhausted" plays which role in the argument?

- **(A)** It is a general principle that the conclusion illustrates.
- **(B)** It is a counter-consideration the manager then rejects.
- **(C)** It restates the conclusion in different words.
- **(D)** It is the main conclusion the manager is arguing for.
- **(E)** It is a premise offered as evidence that the policy would help.

::::solution[Solution]
**(E).** The conclusion is "we should adopt the four-day workweek." The exhaustion claim is evidence — combined with "rest improves work," it supports the recommendation. So it functions as a *premise*. (D) names the actual conclusion, not this claim; (A)/(B)/(C) mischaracterize its function. *Type: Role/Function. Skill: first find the conclusion, then ask what the target sentence does for it.*
::::
:::

## 5 · Reading Comprehension

:::callout-intuition
Intuition first

RC is what it sounds like — but harder and faster than school reading. You get dense, college-level passages on unfamiliar topics (law, science, history, the arts, social science) and must answer precise questions about them under time pressure. The trap is reading for *content* (trying to learn the material) when you should read for *structure* (who's arguing what, where the opinions are, how the parts connect). You're not studying the passage; you're mapping it.
:::

### Format and passage types

One scored RC section, 35 minutes, with **four passage sets** and ~26–28 questions total. Each set has a passage of roughly 400–500 words followed by 5–8 questions. The four sets break down as:

- **Three standard single passages.** One author, one extended argument or exposition.
- **One "comparative reading" set.** Instead of one long passage, you get *two shorter passages* (A and B) by different authors on a related topic. They agree on some points and disagree on others, and the questions focus on the *relationship* between them — points of agreement, disagreement, and how each author would react to the other.

Subjects rotate across four broad areas — **natural sciences, social sciences, humanities/arts, and law** — so you'll always face at least one topic that feels alien. That's by design; structural reading is what carries you through unfamiliar content.

### The question types

| Type | Stem sounds like… | Approach |
| --- | --- | --- |
| **Main Point / Primary Purpose** | "the main idea is…" / "the author's primary purpose is…" | Answer from your one-sentence summary of the whole passage. Right answers cover the *whole* passage, not one paragraph. |
| **Detail / Recognition** | "according to the passage…" | Go back and find the line. The answer is *stated*, often paraphrased. Don't rely on memory. |
| **Inference** | "the passage suggests / implies…" | One small logical step beyond what's stated. Must be supported by the text — not your outside knowledge. |
| **Author's Attitude / Tone** | "the author's attitude toward X is…" | Gauge from word choice. Usually moderate ("cautiously skeptical," not "contemptuous"). |
| **Function / Purpose of part** | "the author mentions X in order to…" / "the second paragraph functions to…" | Ask *why* the author included it — its job in the argument, not its content. |
| **Structure / Organization** | "which describes the organization of the passage?" | Track the abstract flow (e.g., "presents a theory, then two objections, then a defense"). |
| **Analogy / Application** | "which situation is most analogous to…" | Match the underlying relationship to a new scenario. |
| **Comparative (two-passage)** | "both passages / the authors would disagree about…" | Map each author's position first, then find overlap or conflict. |

### The Reading Comprehension method

1. **Read for structure, not mastery (~3–4 min per passage).** As you read, silently answer: What's the main point? What's the author's opinion (vs. others' opinions)? How is it organized? Where are the "pivot" words — *but, however, although, yet, surprisingly* — that signal a turn?
2. **Build a mental (or scratch) map.** One phrase per paragraph: what it does. "P1: old theory. P2: problem with it. P3: author's fix. P4: evidence." This map answers most Structure/Function questions instantly.
3. **Nail the main point in one sentence** before touching the questions.
4. **For each question, go back to the text.** RC rewards re-reading the relevant 2–3 lines. Memory-based answers are how you fall for traps.
5. **Eliminate on specifics.** Wrong RC answers are typically *too extreme*, *half-right/half-wrong*, *true but not the point asked*, or *not in the passage* (real-world true, but unsupported).

:::callout-pitfall
Watch out for these RC traps

- **The "outside knowledge" trap.** An answer can be factually true in the real world but unsupported by the passage. Only the passage counts.
- **Extreme language.** Words like *always, never, all, impossible, proves* rarely match the hedged tone of LSAT passages. Be suspicious.
- **Confusing the author's view with a view the author is describing.** Passages often present other people's positions before disagreeing. Always track *whose* opinion a sentence expresses.
- **Half-right answers.** The first half matches; the second half slips in a distortion. Read every word of every choice.
:::

:::callout-tip
Pacing on RC

Budget roughly **8–9 minutes per passage set** (≈3:30 reading, ≈5 answering). If a passage is brutal, do its questions *last* — bank the easier passages' points first. Many people gain points simply by reordering passages from easiest to hardest, since each set is worth the same.
:::

### Worked passage (with structural map)

:::example
Practice passage — social science

(1) For decades, economists assumed that consumers make decisions by rationally weighing costs and benefits. (2) This "rational actor" model elegantly predicted market behavior in many settings, and its mathematical tractability made it the foundation of modern economics.

(3) Yet a growing body of experimental work has revealed systematic deviations from rational choice. (4) People value avoiding a loss more than acquiring an equivalent gain; they over-weight small probabilities; they are swayed by how options are framed. (5) Such findings, the behavioral economists argue, are not random noise but predictable patterns that the classical model cannot accommodate.

(6) Defenders of the traditional view respond that these anomalies appear mainly in artificial laboratory settings, and that in real markets, competition and learning push behavior back toward rationality. (7) The behavioralists counter that many of the same biases persist in high-stakes, real-world decisions, from retirement savings to medical choices.

(8) The debate, ultimately, may be less about whether people are rational than about which model better predicts behavior in a given context. (9) On that pragmatic question, the evidence increasingly favors incorporating psychological realism into economic models.

#### The structural map

- **P1:** the old "rational actor" model — what it is and why it dominated.
- **P2:** the challenge — experiments show systematic, predictable irrationality.
- **P3:** the back-and-forth — traditionalists say "lab artifacts," behavioralists say "no, real-world too."
- **P4:** author's resolution — it's about predictive power, and evidence favors the behavioral side.

**Main point (one sentence):** Although the rational-actor model long dominated economics, experimental evidence of predictable irrationality increasingly favors building psychological realism into economic models.

**Author's attitude:** sympathetic to behavioral economics, but measured (note sentence 8's hedge "may be less about… than about"). Not a cheerleader; a careful judge.
:::

:::example
Questions on the passage

RC-a. standard The primary purpose of the passage is to…

- **(A)** describe a debate between two economic approaches and indicate which the evidence favors.
- **(B)** explain the mathematical foundations of classical economics.
- **(C)** argue that laboratory experiments are unreliable.
- **(D)** trace the history of economics from its origins.
- **(E)** prove that the rational-actor model is entirely false.

::::solution[Solution]
**(A).** The passage lays out the classical model, the behavioral challenge, the exchange between camps, and a verdict — that's "describe a debate and indicate which side the evidence favors." (E) is too strong ("entirely false" — the author says it's about predictive context, not total falsity). (B)/(D) cover only a fragment. (C) reverses the author's lean. *Type: Primary Purpose — must capture the whole passage.*
::::

RC-b. standard According to the passage, behavioral economists claim that the deviations they observe are…

- **(A)** random and therefore unimportant.
- **(B)** predictable patterns the classical model cannot accommodate.
- **(C)** confined to laboratory settings.
- **(D)** evidence that markets never reach equilibrium.
- **(E)** caused by insufficient competition.

::::solution[Solution]
**(B).** Stated almost verbatim in sentence 5 ("not random noise but predictable patterns that the classical model cannot accommodate"). (A) is the opposite. (C) is the *traditionalists'* claim, not the behavioralists'. (D)/(E) aren't supported. *Type: Detail — go back and find the line; watch for whose view it is.*
::::

RC-c. challenge The author would most likely agree that…

- **(A)** laboratory experiments have no bearing on real markets.
- **(B)** psychological factors should never enter economic models.
- **(C)** the value of an economic model lies primarily in its predictive accuracy in context.
- **(D)** traditional economists have refuted the behavioral findings.
- **(E)** consumers are entirely irrational.

::::solution[Solution]
**(C).** Sentences 8–9 reframe the debate around *which model better predicts behavior in a given context* — a pragmatic, predictive standard. (B) and (A) contradict the author's lean. (D) overstates the traditionalists' success. (E) is too extreme — the author never says people are *entirely* irrational, only systematically biased. *Type: Inference/Attitude — one careful step from the text, respecting its hedges.*
::::
:::

### Reading Comprehension drill (self-check)

Re-read the passage above and try these without looking back first; then verify against the text.

:::problem[Q1]{difficulty="easy"}
The phrase "rational actor" in paragraph 1 refers to a consumer who…

- **(A)** is swayed by framing.
- **(B)** distrusts economists.
- **(C)** always avoids losses.
- **(D)** makes decisions by weighing costs and benefits.
- **(E)** ignores probabilities.

::::solution[Solution]
**(D).** Sentence 1 defines it directly. The others describe the *biases* that violate the model. *Detail question.*
::::
:::

:::problem[Q2]{difficulty="standard"}
The function of paragraph 3 is to…

- **(A)** state the author's final conclusion.
- **(B)** provide statistical evidence for behavioral economics.
- **(C)** define key economic terms.
- **(D)** introduce the rational-actor model.
- **(E)** present the exchange of objections and replies between the two camps.

::::solution[Solution]
**(E).** P3 is the rebuttal/counter-rebuttal (lab-artifacts vs. real-world persistence). The conclusion is P4; the model is P1. *Function/structure question — answer from your map.*
::::
:::

:::problem[Q3]{difficulty="challenge"}
Which one, if true, would most *weaken* the author's final position?

- **(A)** A new study shows behavioral biases vanish entirely when decisions are repeated in competitive markets, and that classical models then predict best.
- **(B)** Behavioral economists have won major academic awards.
- **(C)** The rational-actor model uses advanced mathematics.
- **(D)** Some consumers report enjoying shopping.
- **(E)** Laboratory experiments are inexpensive to run.

::::solution[Solution]
**(A).** The author concludes evidence favors psychological realism on the *predictive* question. (A) attacks exactly that — if classical models predict best in real competitive settings, the pragmatic case for the behavioral approach weakens. The others are irrelevant to predictive accuracy. *Type: applying Weaken logic to RC — find what undercuts the specific conclusion.*
::::
:::

## 6 · LSAT Argumentative Writing

:::callout-intuition
Intuition first

This is the one part of the test where you actually *write*. It's currently **unscored**, so it doesn't move your 120–180 number — but it is **mandatory**: schools won't receive your score until an approved sample is on file, and admissions officers *can read it*. Treat it as a low-stakes-but-required formality you don't want to fumble: do it once, do it competently, move on.
:::

### Format

Taken separately from the multiple-choice test, on your own computer, in a flexible window (you can complete it in the days around your test date). You're given:

- A **debatable issue** (a decision or question with no obvious right answer).
- **Three or four short "perspectives"** — a few sentences each, representing different values or arguments around the issue.

You get about **50 minutes total: ~15 minutes of pre-writing analysis** (notes, brainstorming — you can't start the essay yet) **and ~35 minutes to write** the essay. Your job: **take a position** on the issue and defend it while **engaging with the competing perspectives** (addressing, rebutting, or conceding to them).

### A reliable template

:::definition
**Intro (2–3 sentences).** State the issue and clearly declare your position. Don't bury it.

**Body 1 — your strongest reason.** Make your best affirmative argument, drawing on the relevant perspective(s).

**Body 2 — address the opposition.** Acknowledge the strongest competing perspective, then explain why your position still holds (rebut it or show why your considerations outweigh it). This is the part graders/readers most want to see — it shows you can handle counter-arguments.

**Body 3 (optional) — a second supporting reason or a concession with a limit.**

**Conclusion (1–2 sentences).** Restate your position and the core reason. No new arguments.
:::

:::callout-tip
What "good" looks like here

Readers reward a **clear thesis, organized paragraphs, and genuine engagement with the other side** — not eloquence or a "correct" answer. There is no right position. Pick whichever side you can argue best, even if it's not what you personally believe. Use the 15 minutes to choose your side and outline; then write cleanly, leave 2–3 minutes to proofread.
:::

:::callout-pitfall
Common mistakes

- **Not picking a side** — wishy-washy "both have merit" essays read as evasive. Commit.
- **Ignoring the perspectives** — you must engage the provided viewpoints, not write a freeform op-ed.
- **Skipping it entirely** — this silently blocks your whole score from release. Do it as soon as you're eligible.
- **Over-investing** — it's unscored. Don't spend prep weeks here; one or two practice runs is plenty.
:::

## 7 · Building your prep plan

:::callout-key
The whole plan in one paragraph

Take a cold diagnostic to find your starting score. Spend the bulk of your time **learning the question types and drilling them by type**, reviewing every miss with the blind-review method. Layer in **full, timed practice tests** on a growing cadence to build endurance and pacing. Track your errors in a log so your drilling targets your actual weaknesses. Most people need **200–400 focused hours over 3–6 months** to move 10–20 points.
:::

### Step 0 — Take a cold diagnostic (do this first)

Before any studying, sit a **full, timed, official practice test** (LSAC gives several free ones — see [resources](#resources)). No pausing, no looking things up. This does three things: gives you an honest baseline, shows you which section hurts most, and makes the strategy you read next actually *stick* because you've felt the problem. Record the score; this is the number you'll measure improvement against.

### Step 1 — Learn the types before you grind

Don't start by hammering random questions. First *learn the question types* (sections 4 and 5 of this guide, plus a structured course or book). Knowing that a stem is a "Necessary Assumption" question tells you to run the negation test; knowing it's "Paradox" tells you to look for what reconciles two facts. Strategy first, volume second.

### Step 2 — Drill by type, then mixed

Practice **one question type at a time** until the pattern clicks (e.g., 20 Weaken questions in a row), then switch to **mixed sets** that mirror real test conditions. Type-focused drilling builds the recognition; mixed drilling builds the test-day skill of identifying the type on the fly.

### Step 3 — Blind review every session (the core skill)

This is the highest-leverage habit in all of LSAT prep, so it gets its own treatment below.

:::definition
**Blind Review, defined.** After finishing a timed set — but *before* checking answers — go back through every question you were unsure about, with **no time limit**, and re-solve it carefully. Mark your "untimed" answer. *Then* check the key. You now have two pieces of data per question:

1. Got it right timed → you know it. Move on.
2. Got it wrong timed, right on blind review → it's a **timing/pressure** problem (you *can* do it, just not fast enough). Fix: pacing drills.
3. Got it wrong even on blind review → it's a **knowledge/understanding** gap (you don't actually get the concept). Fix: study that type.

This split tells you *why* you're missing points, which tells you what to practice. Without it, you're guessing at your own weaknesses.
:::

:::callout-tip
How to review a single wrong question (5–10 minutes each)

1. Re-find the conclusion and the gap from scratch.
2. Articulate, in one sentence, **why the right answer is right.**
3. Articulate, for each of the four wrong answers, **the specific reason it's wrong** (out of scope, opposite, too strong, half-right, true-but-useless).
4. Name the **question type** and, if a flaw, the **specific flaw.**
5. Log it (see error log below).

If you can do steps 2–3 for every question, your score climbs almost automatically.
:::

### Step 4 — Keep an error log

A simple spreadsheet with columns: *date, source/PT#, question type, what I picked, right answer, why I missed it (timing vs. understanding), the takeaway lesson.* Every week or two, sort by question type and count your misses. The type at the top of that list is exactly what to drill next. The error log turns vague "I'm bad at LR" into "I miss Sufficient Assumption questions because I don't diagram the conditional logic" — which you can actually fix.

### Step 5 — Build endurance with full practice tests

Roughly the **middle and back third** of your prep should include regular full-length, timed PTs taken in the official LawHub interface, in one sitting, **including a fifth experimental-style section** to mirror real fatigue. Blind-review each one thoroughly (a full PT review can take longer than the test itself — that's normal and correct). Ramp from one every other week to one or two per week as test day approaches. Take your last full PT about **3–7 days before** the real thing, then taper — light review only, rest your brain.

:::callout-warning
How much time, realistically

Targets that consistently produce improvement: **~200–400 total hours**, at roughly **10–15 hours/week for 3–6 months**. You can compress into ~2 months if you can study heavily, or stretch to a year — but beyond about a year, returns flatten and burnout rises. Consistency (most days, moderate doses) beats occasional marathons.
:::

### Ready-made schedules

Pick the one matching your timeline. All assume you've taken a cold diagnostic first.

#### 3-month plan (the standard) — ~12 hrs/week

| Phase | Weeks | Focus |
| --- | --- | --- |
| Foundations | 1–4 | Learn all LR question types + RC method. Drill *untimed* by type. Blind-review everything. One PT at end of week 4 to recheck baseline. |
| Build | 5–8 | Timed type-drills, then mixed sections. Start the error log in earnest. One full PT per week, fully blind-reviewed. Attack your top-3 weak types. |
| Polish | 9–11 | 2 PTs/week under realistic conditions (5 sections, official interface). Drill only your persistent weak spots. Do 1–2 writing-task practice runs. |
| Taper | 12 | One final PT early in the week, then light review and rest. Confirm test-day logistics. |

#### 6-month plan — ~8–10 hrs/week

Same four phases, stretched: ~8 weeks foundations, ~10 weeks build, ~5 weeks polish, ~1 week taper. Best if you're working/in school full-time or starting far below your target. The extra runway lets concepts settle and avoids cramming — but only if you stay consistent; a 6-month plan you do sporadically becomes a rushed 6-week plan.

#### 1-month plan (compressed) — ~20–25 hrs/week

Only viable if you can study near-full-time and are starting reasonably close to your target. Week 1: learn all types + heavy untimed drilling. Weeks 2–3: timed drills + 3–4 full PTs with blind review. Week 4: 2–3 final PTs, weak-spot cleanup, taper the last two days. Accept that a month caps how much you'll gain — if you're far from your target, push your test date rather than under-prepare.

:::callout-tip
Weekly rhythm that works (any plan)

A repeatable week: **3–4 drilling sessions** (by type, timed) + **1 full or half PT** + **1 dedicated blind-review/error-log session** + **1 rest day.** Short daily reps beat one weekend cram. Protect the rest day — fatigue quietly tanks accuracy.
:::

## 8 · Resource directory

:::callout-key
Start free — you may not need to pay much at all

Many high scorers prep with mostly free official material plus one affordable course or book. **The most important resource is real, official, previously-administered LSAT questions** — they're what you must practice on. Third-party questions are imitations; use official PrepTests for anything timed.
:::

### Official (LSAC) — use these first

- **LawHub** ([lsac.org/lsat/prep](https://www.lsac.org/lsat/prep)) — LSAC's official platform. The *free* tier includes several full official PrepTests in the exact digital interface you'll use on test day. **LawHub Advantage** (paid yearly subscription) unlocks a large library of official PrepTests. This is the best single purchase most people make.
- **Khan Academy / official LSAC free prep** — LSAC has partnered to offer free guided LSAT practice and lessons. Excellent zero-cost starting point for learning the types.
- **Official LSAT PrepTest books** — LSAC publishes past tests in print; useful for untimed drilling away from a screen.

### Paid courses & books (optional, pick what fits)

- **Self-paced platforms** — e.g., 7Sage, Blueprint, LSAT Demon, Manhattan, Princeton Review, Kaplan. These bundle lesson videos, analytics, and question banks. Good if you want structure and don't want to self-assemble a curriculum. Costs vary widely; many offer free trials.
- **The LSAT Trainer (book)** — a well-regarded self-study book for building fundamentals affordably.
- **Tutoring** — highest cost; reserve for stubborn plateaus where you've drilled and reviewed but a specific weakness won't budge.

:::callout-tip
A sensible budget-conscious stack

(1) Free LawHub + Khan/official lessons to learn the types → (2) a single affordable book or self-paced course for structured strategy → (3) LawHub Advantage for a deep well of official PTs to drill and review. That combination has carried many people to strong scores without four-figure spending.
:::

### Free fee help

If cost is a barrier, apply for an **LSAC fee waiver** before paying — it can cover test fees and bundle in prep access. Check eligibility at [lsac.org](https://www.lsac.org).

## 9 · Test-day playbook

### The week before

- Confirm your test date, time, and (for online) that your computer, webcam, and room meet LSAC's tech and environment requirements.
- Run the official system check / onboarding LSAC requires *ahead* of test day — don't discover a webcam problem at the desk.
- Take your final full PT early in the week; then taper to light review.
- Sleep is training too — bank good sleep for several nights, not just the night before.

### The day before

- No new material. A light, confidence-building review at most. Then stop.
- Prep your space: clear desk, allowed scratch materials per LSAC rules, water, ID ready.
- Lay out everything; know exactly when you'll log in.

### During the test

:::callout-tip
Execution rules

- **Answer every question** — no wrong-answer penalty. With ~2 min left in a section, fill in any blanks with a single guess letter.
- **Don't get stuck.** If a question is eating your clock, flag it, guess, and move on; come back if time allows. One hard question is worth the same as one easy one.
- **Use the on-screen tools** you practiced with: highlighter, eliminator, flag.
- **Treat every section as scored** — you won't know which is experimental.
- **Use the 10-minute break** to physically reset — stand, breathe, hydrate. Endurance is a skill you trained; trust it.
- **If one section goes badly, let it go.** Spiraling costs you the next section too. Reset and keep scoring.
:::

### After

Complete the [Argumentative Writing](#writing) task as soon as you're eligible so your score releases on time. Scores arrive a few weeks later by email. If your score is well below your PT average and you've time in the cycle, a retake is normal — schools generally consider your highest score.

:::callout-warning
Mindset

By test day, the work is done — you can't cram in new ability overnight. Your job is execution: stay calm, keep moving, guess-and-flag when stuck, and let your training carry you. Nerves are normal; the test-takers who do best are simply the ones who keep answering.
:::

## 10 · Self-assessment checklist

You're ready for test day when you can honestly check most of these:

- I can name the question type of any LR stem within a few seconds.
- I run the negation test automatically on Necessary Assumption questions.
- I can recite the common-flaw catalog and spot each in a stimulus.
- For missed questions, I can state precisely why each wrong answer is wrong.
- I read RC passages for structure and can summarize the main point in one sentence.
- I track whose opinion each RC sentence expresses (author vs. others).
- My timed PT scores have stabilized at or above my target across several tests.
- I can finish sections within 35 minutes with time to review flagged questions.
- My error log shows my weak types shrinking over time.
- I've practiced in the official LawHub interface, including a 5-section full test.
- I've done at least one timed Argumentative Writing run.
- I've confirmed test-day logistics (tech check, ID, environment).

:::callout-key
The one-line summary of this whole guide

Learn the finite set of question types, drill them by type, and **blind-review every mistake until you can explain why each wrong answer is wrong** — then build endurance with full official practice tests. Do that consistently for a few months and your score will move.
:::

## Sources

Structural facts (sections, timing, scoring, writing task, question types, study timelines) were verified in June 2026 against the following. Always confirm current specifics on the official LSAC site before registering.

- [LSAC — Types of LSAT Questions](https://www.lsac.org/lsat/prepare/types-lsat-questions)
- [LSAC — LSAT Argumentative Writing](https://www.lsac.org/lsat/about/lsat-argumentative-writing)
- [LSAC — Free Official LSAT Prep (LawHub & Khan Academy)](https://www.lsac.org/lsat/prep)
- [LSAC — LSAT Percentiles](https://www.lsac.org/data-research/data/lsat-percentiles)
- [LSAC — LSAT Dates & Deadlines](https://www.lsac.org/LSATdates)
- [Princeton Review — What is on the LSAT?](https://www.princetonreview.com/law/lsat-sections)
- [Kaplan — What's Tested on the LSAT](https://www.kaptest.com/study/lsat/whats-tested-on-the-lsat/)
- [7Sage — Logical Reasoning Question Types](https://7sage.com/lr-question-types)
- [LSATHacks — LR Question Types Guide](https://lsathacks.com/logical-reasoning-question-types/)
- [Blueprint — LSAT Study Schedules](https://blueprintprep.com/lsat/lsat-study-schedules)
- [Leland — LSAT Format & Structure (2026)](https://www.joinleland.com/library/a/lsat-format)

Built as a self-study field guide, June 2026. The LSAT is administered by the Law School Admission Council (LSAC); this guide is independent and not affiliated with LSAC. Test format, fees, and dates change — verify all specifics at lsac.org before registering or paying.
