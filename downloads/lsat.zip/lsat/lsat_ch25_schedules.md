---
title: "Study Schedules"
source: "lsat_ch25_schedules.html"
---

Part V · Chapter 25

# Study Schedules

The methods from Chapters 21–24 arranged into concrete calendars. Pick the plan that fits your timeline, and use the weekly rhythm that makes any of them work.

**Est. study time:** 35–45 min — **Sections:** 5 — **Practice:** 12+ items

## Overview

You now have all the ingredients — diagnostic and gap analysis (21), blind review (22), the error log (23), and practice-test strategy (24). This chapter arranges them into ready-made calendars for the four most common timelines: **3 months** (the standard), **6 months**, **1 month** (compressed), and **12 months**. All four share the same four phases — *foundations, build, polish, taper* — just stretched or compressed. The right total investment is roughly **200–400 focused hours**; the schedule you choose mainly determines how those hours are spread. The chapter closes with the weekly rhythm that keeps any plan on track.

:::callout-tip
Prerequisites

All of Chapters 21–24, plus Chapter 2 (register for a real date to anchor the plan) and Chapter 3 (set a target from school medians so the plan has a goal). A schedule without a fixed test date and a target score tends to drift.
:::

:::callout-key
The four phases every plan shares

**Foundations:** learn all question types, drill untimed by type, blind-review everything. **Build:** timed type-drills → mixed sections, weekly full PTs, error-log-driven weak-spot work. **Polish:** frequent realistic PTs, drill only persistent weaknesses, writing-task runs. **Taper:** last full PT several days out, then light review and rest. Every calendar below is these four phases on a different clock.
:::

## 25.1 · The 3-month plan (standard) — ~12 hrs/week

:::callout-intuition
Intuition first

Three months at ~10–15 hours a week is the timeline most committed test-takers use, and it's the sweet spot: long enough for concepts to settle and skills to build, short enough to sustain focus without burning out. If you're not sure which plan to pick and you can commit ~12 hours a week, this is the default.
:::

| Phase | Weeks | Focus |
| --- | --- | --- |
| **Foundations** | 1–4 | Learn all LR question types + the RC method. Drill *untimed* by type. Blind-review everything. One PT at the end of week 4 to recheck your baseline against the diagnostic. |
| **Build** | 5–8 | Timed type-drills, then mixed sections. Run the error log in earnest. **One full PT per week**, fully blind-reviewed. Attack your top 2–3 weak types. |
| **Polish** | 9–11 | **Two PTs/week** under realistic conditions (5 sections, official interface). Drill only persistent weak spots. Do 1–2 writing-task practice runs. |
| **Taper** | 12 | One final PT early in the week, then light review and rest. Confirm test-day logistics (Chapter 27). |

:::callout-tip
Why this cadence works

The plan front-loads *learning* (foundations), shifts to *integration and diagnosis* (build), then to *realistic simulation* (polish), and ends with *rest* (taper) — matching the training order from Chapter 21. PT frequency ramps from one/week to two/week as test day nears, building endurance and pacing while there's still time to review each one thoroughly.
:::

### Practice — 25.1

:::problem[Q1]{difficulty="easy"}
What are the four phases of the standard 3-month plan?

::::solution[Solution]
**Foundations, Build, Polish, Taper.** Learn types → integrate + weekly PTs → realistic PTs + weak-spot polish → final PT and rest.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why do full PTs start only in the Build phase, not week 1?

::::solution[Solution]
Because you should **learn the type methods first** (Chapter 21) before full timed tests — early PTs would just measure untrained performance and burn material. Foundations builds the skills; Build then stress-tests them with weekly PTs.
::::
:::

:::problem[Q3]{difficulty="standard"}
When are the writing-task practice runs scheduled, and why then?

::::solution[Solution]
In the **Polish phase** (late), because the task is unscored and low-priority (Chapter 20) — one or two runs near the end suffice to be ready without diverting early study time from scored skills.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does PT frequency ramp up (1/week → 2/week) rather than staying constant?

::::solution[Solution]
Because early on you need **time between PTs to build skills and thoroughly review each one**, and taking them too often would outpace your ability to learn from them (Chapter 24). As test day nears and your skills solidify, more frequent PTs build the **endurance and pacing** that only realistic full tests train — so frequency rises once you can absorb it and once simulation matters most.
::::
:::

## 25.2 · The 6-month plan — ~8–10 hrs/week

:::callout-intuition
Intuition first

Six months is the same four phases, stretched — best if you're working or in school full-time, or starting well below your target and want concepts to settle without cramming. The extra runway is an advantage *only if you stay consistent*: a 6-month plan you do sporadically collapses into a rushed 6-week plan at the end. The danger of a long timeline is complacency, not difficulty.
:::

| Phase | Weeks (approx.) | Focus |
| --- | --- | --- |
| **Foundations** | 1–8 | Learn all types thoroughly; heavy untimed drilling; blind-review everything. Extra time lets concepts settle deeply. |
| **Build** | 9–18 | Timed drills → mixed sections; error-log-driven weak-spot work; one PT every 1–2 weeks, fully reviewed. |
| **Polish** | 19–23 | Realistic PTs (ramping toward ~2/week), persistent weak-spot drilling, writing runs. |
| **Taper** | 24 | Final PT several days out; light review; rest. |

:::callout-warning
The consistency trap

A long timeline's biggest risk is **drift** — "I have plenty of time" becomes weeks of skipped sessions, and you arrive at the last month having lost your momentum and much of what you learned early. Protect against it: keep a steady weekly rhythm (25.5), register for a real date to create accountability (Chapter 2), and treat the 6-month plan as 24 weeks of consistent work, not 6 months of "I'll get to it."
:::

### Practice — 25.2

:::problem[Q1]{difficulty="easy"}
Who is the 6-month plan best suited for?

::::solution[Solution]
People **working or in school full-time**, or those **starting well below target** who benefit from letting concepts settle without cramming — provided they stay consistent.
::::
:::

:::problem[Q2]{difficulty="standard"}
What is the main risk of a longer timeline, and how do you counter it?

::::solution[Solution]
**Drift/complacency** — a long runway invites skipped sessions until it becomes a rushed sprint. Counter with a **steady weekly rhythm, a registered test date for accountability, and consistent work**, treating it as 24 disciplined weeks.
::::
:::

:::problem[Q3]{difficulty="standard"}
The 6-month plan uses the same phases as the 3-month. What actually changes?

::::solution[Solution]
Mainly the **hours per week (lower) and the length of each phase (longer)** — the structure and order are identical; the same ~200–400 total hours are just spread over more weeks at a gentler weekly pace.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why isn't "more months" always better — is there a point of diminishing returns?

::::solution[Solution]
Yes. Beyond roughly a year, returns flatten and **burnout risk rises** (Chapter 26): motivation fades, early learning decays faster than new learning accrues, and very long timelines often reflect avoidance of committing to a date. The skill builds over months, but stretching prep indefinitely trades diminishing score gains for rising fatigue and drift — so a focused 3–6 months usually beats an open-ended year.
::::
:::

## 25.3 · The 1-month compressed plan — ~20–25 hrs/week

:::callout-intuition
Intuition first

One month is only viable under two conditions: you can study **near-full-time** (20–25+ hours/week), and you're starting **reasonably close to your target**. It's the same four phases crushed into four weeks, which means concepts get little time to settle. If you're far from your target, a month can't fix that — and the honest move is to **push your test date** rather than under-prepare and waste an attempt.
:::

| Week | Focus |
| --- | --- |
| **Week 1** | Learn/refresh all question types + RC method; heavy untimed drilling; blind-review everything. |
| **Weeks 2–3** | Timed drills + mixed sections; **3–4 full PTs** with thorough blind review; error-log-driven weak-spot attack. |
| **Week 4** | 2–3 final PTs, weak-spot cleanup, 1 writing run; **taper the last two days**. |

:::callout-pitfall
Watch out for these mistakes

- **Using it when you're far from target.** A month can't close a large gap; pushing the date beats burning an attempt on an under-prepared test.
- **Skipping review to fit more questions.** Even compressed, blind review is non-negotiable — it's still where the gains are (Chapter 22). Do fewer questions, reviewed well.
- **No taper.** Even in a sprint, taper the last two days; arriving exhausted wastes the month's work.
- **Ignoring burnout.** 20–25 hrs/week is intense; protect sleep and at least one lighter day to avoid crashing before test day.
:::

:::callout-warning
The honest caveat

A month caps how much you can realistically gain — you can sharpen and consolidate, but you can't build a large skill jump from scratch. If your diagnostic is far below your target, the disciplined choice is to **reschedule** (Chapter 2 allows it within limits) and use a 3-month plan. An under-prepared attempt costs money, an attempt on your record, and momentum.
:::

### Practice — 25.3

:::problem[Q1]{difficulty="easy"}
Two conditions that make a 1-month plan viable?

::::solution[Solution]
You can study **near-full-time (20–25+ hrs/week)** and you're starting **reasonably close to your target**. Otherwise, push the date.
::::
:::

:::problem[Q2]{difficulty="standard"}
Your diagnostic is 12 points below target and you have one month. Best move?

::::solution[Solution]
**Reschedule the test** (Chapter 2) and use a 3-month plan. A month can't reliably close a 12-point gap; an under-prepared attempt wastes money, momentum, and a slot on your record.
::::
:::

:::problem[Q3]{difficulty="standard"}
Even in a compressed plan, why keep blind review?

::::solution[Solution]
Because review is still **where improvement comes from** (Chapter 22) — skipping it to cram more questions just multiplies unlearned errors. Do *fewer* questions, thoroughly reviewed, not more done blindly.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does a compressed timeline make consolidation (vs. new learning) the realistic goal?

::::solution[Solution]
Because building a new skill from scratch and letting it **settle** takes weeks of spaced practice, which a month can't provide. In a month, what's achievable is **sharpening skills you mostly have** — cleaning up careless errors, tightening pacing, shoring up a couple of weak types — which is why the 1-month plan suits someone already near target. Expecting a large from-scratch jump misreads how skill acquisition works (Chapter 1).
::::
:::

## 25.4 · The 12-month plan — ~5–7 hrs/week

:::callout-intuition
Intuition first

A year at a gentle 5–7 hours a week suits people balancing heavy commitments (demanding job, full course load, family) who still want to prepare thoroughly. The same four phases spread very wide. The upside is a low weekly burden; the downsides are real and worth naming: **drift and decay**. Over a year, motivation flags and early learning fades, so a 12-month plan needs deliberate reinforcement built in — periodic re-consolidation of what you learned months earlier.
:::

| Phase | Months (approx.) | Focus |
| --- | --- | --- |
| **Foundations** | 1–4 | Learn all types unhurriedly; untimed drilling; blind review. Revisit earlier types periodically so they don't fade. |
| **Build** | 5–9 | Timed drills → mixed sections; error-log weak-spot work; roughly one PT every 2–3 weeks, reviewed fully. |
| **Polish** | 10–11 | Realistic PTs ramping up; persistent weak spots; writing runs. |
| **Taper** | 12 | Final PT several days out; light review; rest. |

:::callout-warning
Build in re-consolidation

Over a year, the material you learned in month 2 will fade by month 8 unless you revisit it. Schedule periodic **review passes** — re-read your error-log takeaways, re-do a set of an earlier-learned type — so the plan is cumulative rather than a series of forgotten segments. And, as always, protect against drift with a steady weekly rhythm and a real (even if distant) test date. Beyond ~12 months, returns flatten and burnout risk rises (Chapter 26) — a year is roughly the outer edge of useful runway.
:::

### Practice — 25.4

:::problem[Q1]{difficulty="easy"}
Who is a 12-month plan best for?

::::solution[Solution]
People with **heavy competing commitments** who can only give ~5–7 hrs/week but still want thorough prep — accepting a low weekly load in exchange for a long runway.
::::
:::

:::problem[Q2]{difficulty="standard"}
What extra element must a 12-month plan include that shorter plans need less?

::::solution[Solution]
**Periodic re-consolidation** — scheduled review passes over earlier-learned material — because over a year, early learning **decays** without revisiting. Shorter plans finish before much fading occurs.
::::
:::

:::problem[Q3]{difficulty="standard"}
Is a 12-month plan generally superior to a 3-month one because it's longer? Explain.

::::solution[Solution]
**No** — beyond the point where concepts have settled, extra months mainly add **decay and burnout risk**, not proportional score gains. A year suits constrained schedules, but "longer" isn't "better"; a focused 3–6 months is often ideal.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Design a re-consolidation habit for a 12-month plan in one or two sentences.

::::solution[Solution]
Every 3–4 weeks, spend one session **revisiting older material**: re-read your error-log takeaways, re-do a short block of a question type you learned months ago, and note any skills that have gone rusty for a refresher. This keeps the plan **cumulative** — each phase builds on retained skills rather than on half-forgotten ones — countering the decay that otherwise erodes a long timeline.
::::
:::

## 25.5 · The repeatable weekly rhythm

:::callout-intuition
Intuition first

Whatever the total length, what actually gets the work done is a **weekly rhythm** you repeat without having to re-decide each day. Short, consistent sessions beat occasional marathons — a skill consolidates through frequent, spaced practice, not through one heroic weekend. Design a default week and run it on autopilot; motivation is unreliable, but a habit isn't.
:::

:::definition
**Definition 25.1 — The default week.** A repeatable weekly template: roughly **3–4 drilling sessions** (by type, timed), **1 full or half practice test**, **1 dedicated blind-review / error-log session**, and **1 rest day**. Scale the session lengths to your plan's weekly hours; keep the *structure* constant so studying becomes automatic.
:::

| Day type | What you do | Per week |
| --- | --- | --- |
| Drilling | Timed type-drills or mixed sections on your weak spots (error-log driven) | 3–4 |
| Practice test | A full or half PT under realistic conditions | 1 |
| Deep review | Blind review + five-step review of misses + update the error log | 1 |
| Rest | No LSAT — protect it; fatigue quietly tanks accuracy | 1 |

:::callout-key
Protect the rest day

The rest day isn't optional slack — it's part of the training. Fatigue silently degrades accuracy (you saw this in endurance, Chapter 24), and consistent moderate effort with real recovery outperforms relentless grinding that leads to burnout (Chapter 26). Short daily-ish reps plus one genuine day off is more sustainable and more effective than five brutal days and a crash.
:::

### Practice — 25.5

:::problem[Q1]{difficulty="easy"}
What are the four components of the default week?

::::solution[Solution]
**3–4 drilling sessions, 1 practice test, 1 deep-review session, 1 rest day.** Keep the structure constant; scale session length to your plan's hours.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why do short consistent sessions beat occasional marathons?

::::solution[Solution]
Because skills **consolidate through frequent, spaced practice**, not single heroic pushes — and marathons invite fatigue and burnout. Regular reps build durable, retrievable skill; sporadic cramming builds little that lasts.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why keep a rest day even when you feel you "should" study more?

::::solution[Solution]
Because **fatigue degrades accuracy** and unbroken grinding leads to burnout (Chapter 26). Rest is active recovery that sustains performance; a genuine day off makes the other days more productive, not less.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why design a fixed weekly template instead of deciding each day what to study?

::::solution[Solution]
Because deciding daily relies on **motivation and willpower, which are unreliable** and drain over a long plan; a fixed template turns studying into a **habit you run on autopilot**, removing the daily negotiation that leads to skipped sessions. It also guarantees a healthy balance (drilling, PTs, review, rest) rather than defaulting to whatever feels easiest that day, keeping the plan complete and consistent.
::::
:::

## Chapter summary

:::summary
#### Study schedules, distilled

- **~200–400 focused hours** is the target investment; the plan mainly decides how they're spread. Same four phases every time: foundations → build → polish → taper.
- **3-month (standard):** ~12 hrs/week, the default if you can commit it.
- **6-month:** ~8–10 hrs/week for busy schedules; beware drift.
- **1-month:** only if near-full-time and close to target — otherwise push the date.
- **12-month:** ~5–7 hrs/week; build in re-consolidation to fight decay.
- **Weekly rhythm:** 3–4 drills + 1 PT + 1 deep review + 1 protected rest day. Consistency beats marathons.
:::

LSAT Mastery — Chapter 25. Independent study material, not affiliated with LSAC. Hours and cadences are guidelines — calibrate to your diagnostic, target, and life. Use official LSAC PrepTests for timed practice.
