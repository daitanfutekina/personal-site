---
title: "What the LSAT Is and Isn't"
source: "lsat_ch1_what_the_lsat_is.html"
---

Part I · Chapter 1

# What the LSAT Is and Isn't

Before any strategy makes sense, you have to understand what kind of test you're up against — and why it rewards a completely different kind of studying than any test you've taken before.

**Est. study time:** 45–60 min — **Sections:** 4 — **Practice:** 20+ items

## Overview

This chapter answers one question: *what is the LSAT actually testing?* The answer reshapes everything you do next. Most people arrive assuming the LSAT is like every exam they've met — a body of material to learn and reproduce. It isn't. It's a test of a **skill** you perform live, closer to a musical audition than a history final. Get this wrong and you'll waste weeks "studying" in ways that can't possibly work. Get it right and every later chapter clicks into place.

By the end, you'll be able to explain: why there is nothing to memorize, why the correct answer is the one the *text* supports rather than the one that sounds most reasonable, what changed in the big 2024 redesign (and why old prep books will now mislead you), and how law schools actually weigh your score against your GPA so you can set a target that means something.

:::callout-tip
Prerequisites

None — this is the starting line. Ideally you've already sat a **cold diagnostic** (a full, timed official practice test taken before any studying; see Front Matter F.3). If you haven't, read on anyway, but plan to take one soon: this chapter will make far more sense once you've felt the test bite you once.
:::

## 1.1 · A reasoning test, not a knowledge test

:::callout-intuition
Intuition first — why this test even exists

Law schools have a problem: thousands of applicants, all with good grades, and no way to compare a philosophy major from one college to a biology major from another. What they actually want to predict is a single thing — **can this person do the intellectual work of law school?** And that work is remarkably specific: read a dense, unfamiliar argument, find its hidden assumptions, notice exactly where it breaks, and reason precisely about what does and doesn't follow. So they created a test that measures *that* and nothing else — deliberately stripped of any content you could have studied in advance, so a bio major and a poetry major start on equal footing. That's the LSAT. It doesn't test what you *know*; it tests what you can *do* with a paragraph you've never seen.
:::

Almost every test you've taken rewards **recall**: you learn a body of facts, formulas, or vocabulary, and the exam checks whether you can reproduce it. The SAT tests arithmetic and grammar rules. The MCAT tests biology and chemistry. Even a history essay tests whether you absorbed the material. For all of them, the studying loop is the same: acquire information, store it, retrieve it.

The LSAT breaks that loop completely. There is **no body of facts to acquire.** There is no formula sheet, no reading list, no set of terms, no cases to memorize, no math beyond counting. Every question is self-contained: everything you need to answer it is printed right there in the paragraph. What varies from test-taker to test-taker is not *how much they know* but *how skillfully they process the paragraph in front of them.*

:::definition
**Definition 1.1 — Skill test vs. knowledge test.** A *knowledge test* measures the information you have stored and can recall. A *skill test* measures a repeatable mental performance you execute in real time. The LSAT is a skill test: it measures your ability to analyze arguments and read precisely, under time pressure, using only the material given. Because a skill is *trained* rather than *memorized*, it improves through **repetition and feedback** — not through accumulation of facts.
:::

### Why this changes how you study

If the LSAT were a knowledge test, cramming would work: read more, memorize more, score higher. Because it's a skill test, cramming *can't* work — you can't cram your way to a faster golf swing or a cleaner free throw. You improve a skill the way an athlete does:

- **Reps.** You do the movement (analyze an argument) many times until the pattern becomes automatic.
- **Feedback.** After each rep you study exactly what went wrong and why — this is where nearly all the improvement actually happens (Part V, the blind-review chapter, is built entirely around this).
- **Endurance.** The skill has to hold up across a long, tiring test, so you train stamina too.

This is genuinely good news. It means your score is **not fixed** by how "smart" you are or what you majored in. It's trainable, and people move their scores 10–20 points with disciplined practice precisely because a skill responds to training.

:::example
Worked Example 1.1 — knowledge doesn't help

standard

**The setup.** Here's a compressed, LSAT-style argument. Notice that knowing real biology neither helps nor is required.

"Every plant in the Rosewood greenhouse is watered by the automatic system. The automatic system waters only plants that are flagged as tropical. So every plant in the Rosewood greenhouse is flagged as tropical."

**Question.** The argument's reasoning is best described as…

- **(A)** flawed, because it assumes the greenhouse contains only one species.
- **(B)** valid, because greenhouses are typically climate-controlled.
- **(C)** flawed, because automatic systems sometimes malfunction.
- **(D)** flawed, because tropical plants do not all require the same amount of water.
- **(E)** valid, because it correctly chains two conditional statements.

Answer: (E).

**How we get there.** Translate to structure and ignore the botany entirely. Premise 1: greenhouse plant → watered by system. Premise 2: watered by system → flagged tropical. Chain them: greenhouse plant → watered → flagged tropical. The conclusion (greenhouse plant → flagged tropical) follows validly. Done.

Now look at the wrong answers — **every one of them is a fact about the real world** (plants' water needs, malfunctions, species, climate control). All might be *true in reality*, and none has anything to do with whether the *reasoning* is valid. That's the whole lesson: the test dangles real-world knowledge specifically to pull you away from the structure on the page. The credited answer is about the argument's *form*, which you can evaluate with zero botany.
:::

:::callout-pitfall
Watch out for these mistakes

- **Studying like it's a content test.** Making flashcards of "argument types" and trying to memorize your way up is the classic wrong move. You learn the types (later chapters) so you can *recognize* them fast, but the score comes from drilling and reviewing real questions, not from memorization.
- **Reaching for what you know.** When a stimulus touches a topic you happen to know about, the temptation to answer from your knowledge is strong — and it's a trap (much more on this in 1.2).
- **Believing the score is fixed.** "I'm just not a logic person" is a story, not a fact. A skill responds to training; treat a low diagnostic as a starting line, not a ceiling.
:::

### Practice — 1.1

Attempt each before revealing the solution. These check the *concept*, not test technique yet.

:::problem[Q1]{difficulty="easy"}
Which best explains why cramming facts the night before is a poor LSAT strategy?

- **(A)** The LSAT measures a trained skill, not stored information, so there are no facts whose recall would raise your score.
- **(B)** Law schools forbid last-minute studying.
- **(C)** The facts on the LSAT change every year.
- **(D)** The test is too long to cram for.
- **(E)** Because the test is scored on a curve against other test-takers.

::::solution[Solution]
**(A).** Since the test is self-contained and skill-based, there's no content whose memorization helps. Cramming raises recall, and recall isn't what's measured. *(D) and (B) are irrelevant; (C) is false — there are no facts to change.)*
::::
:::

:::problem[Q2]{difficulty="easy"}
A biology PhD and an art-history major sit the same LSAT. On a stimulus about cell metabolism, who has the advantage?

- **(A)** The art historian, because unfamiliarity forces closer reading.
- **(B)** Neither by default — the question is answerable purely from the passage, and the biologist may even be tempted to use outside knowledge that isn't supported by the text.
- **(C)** Whoever reads faster, regardless of the argument.
- **(D)** The biologist, because they know the content.
- **(E)** The biologist, because familiarity with the subject speeds up reading.

::::solution[Solution]
**(B).** The test is engineered so subject knowledge confers no built-in edge; everything needed is on the page. If anything, the expert risks importing outside facts the text doesn't support. This is exactly why the test can fairly compare different majors.
::::
:::

:::problem[Q3]{difficulty="standard"}
Which activity most resembles how you should practice for a skill test like the LSAT?

- **(A)** Watching lecture videos without ever doing questions.
- **(B)** Re-reading a summary of "the rules of logic" five times.
- **(C)** Doing timed question sets, then carefully reviewing why each miss was wrong and re-attempting it.
- **(D)** Memorizing a list of every question type and its definition.
- **(E)** Taking one full practice test a month with no review in between.

::::solution[Solution]
**(C).** Reps plus feedback is how any skill improves. (B), (D), (A) are all pure-intake strategies — useful in small doses to learn the vocabulary, but they don't build the performance. The review step in (C) is where most of the gain happens.
::::
:::

:::problem[Q4]{difficulty="standard"}
In Worked Example 1.1, why were answers (B), (D), and (E) wrong despite being plausible real-world statements?

::::solution[Solution]
Because the question asked about the **validity of the reasoning**, and validity depends only on the argument's logical form — not on whether tropical plants vary in water needs, whether the greenhouse has one species, or whether systems malfunction. Those are true-in-reality facts that are simply irrelevant to the structure. Recognizing "true but irrelevant" answers is a core LSAT skill introduced here and drilled throughout Part II.
::::
:::

## 1.2 · Nothing to memorize — and why outside knowledge is a trap

:::callout-intuition
Intuition first

Imagine a game where the referee tells you: "You may only use facts I hand you on this card. Anything you know from outside — however true — is off-limits, and if you use it, you lose the point." The LSAT is that game. Every question comes with its own card (the stimulus or passage), and the correct answer is the one that card *supports*. This is liberating (there's nothing to study in advance) and dangerous (your own knowledge becomes a source of wrong answers). Section 1.1 said there's nothing to memorize. This section says something sharper: **bringing in what you know outside the card is one of the fastest ways to get a question wrong.**
:::

Because the LSAT is self-contained, you never need a fact from outside the page. But "you don't need it" understates the situation. The test is *built* around the idea that the only admissible evidence is the text, and its wrong answers are frequently statements that are **true in the real world but not supported by the passage.** Those answers feel right — that's the point. They're bait for the part of your brain that wants to answer from general reasoning instead of from the words in front of you.

### The credited-response principle

:::definition
**Definition 1.2 — The credited response.** The *credited response* is the answer choice LSAC counts as correct. On a well-constructed LSAT question there is exactly one, and it is correct because it is **defensible strictly from the text of the stimulus** — you can point to the words that force it. The other four choices are *constructed* to be attractive on general reasoning, real-world truth, or partial matches, but each fails on a precise reading. The skill the test measures is choosing the text-supported answer *over* the merely reasonable-sounding one.
:::

:::callout-key
Say this back to yourself until it's automatic

The right answer is not "the most reasonable conclusion." It is **the one the passage lets you prove.** When two answers compete, don't ask "which sounds smarter?" — ask "which one can I defend by pointing at specific words in the text?" The one you can defend from the page wins, even if the other is more sophisticated, more likely in real life, or the one an expert would pick.
:::

This is exactly the phenomenon you may have noticed already: a question seems to reason toward one answer, but the credited answer is correct *only* because of some specific wording in the stimulus that makes it true. That's not a quirk — it's the entire design. The test-writers pick the credited response first, then engineer four distractors that a smart, fast reader will find tempting. Your job is to be the reader who checks every candidate against the literal text.

:::example
Worked Example 1.2 — the "true but unsupported" trap

standard

"A recent study of one coastal town found that residents who ate fish at least three times a week had lower rates of heart disease than residents who rarely ate fish. The researchers concluded that eating fish reduces the risk of heart disease."

**Question.** Which one of the following is most strongly supported by the information above?

- **(A)** Fish contains nutrients that protect the heart.
- **(B)** People who rarely eat fish will develop heart disease.
- **(C)** Eating fish three times a week is the healthiest possible diet.
- **(D)** In the town studied, frequent fish-eaters had lower rates of heart disease than infrequent fish-eaters.
- **(E)** Everyone should eat fish to avoid heart disease.

Answer: (D).

**How we get there.** Ask of each choice: *can I point to words in the stimulus that guarantee it?*

- **(D)** is a near-restatement of the study's finding: "residents who ate fish… had lower rates… than residents who rarely ate fish." The text *directly states* it. This is the credited response — provable from the page.
- **(A)** is the sophisticated, sciencey answer, and it may well be *true in the real world* — fish really does contain heart-healthy omega-3s. But **the stimulus never mentions nutrients.** You'd be importing outside knowledge. Trap.
- **(C)** "healthiest possible diet" — wildly beyond anything stated. Too strong.
- **(E)** "everyone should" — a recommendation the passage doesn't make; also ignores that it was one town.
- **(B)** "will develop heart disease" — the study showed *lower rates*, not certainty. Too strong.

**The teaching point.** (A) is the answer your general knowledge *wants*. It's true! But truth isn't the standard — *support from the text* is. On "most supported" questions, the credited answer is almost always the modest, close-to-the-text choice, and the trap is the confident real-world fact. Train yourself to feel suspicion, not comfort, when an answer is impressive but unmentioned.
:::

:::example
Worked Example 1.3 — one word decides it

challenge

"Manager: All of our top-performing salespeople attended the advanced training. Priya attended the advanced training. Therefore, Priya is one of our top-performing salespeople."

**Question.** The reasoning is flawed because it…

- **(A)** relies on the opinion of someone with a personal interest.
- **(B)** draws a conclusion about a group from facts about one person.
- **(C)** assumes training and performance are unrelated.
- **(D)** overlooks that some salespeople may have quit.
- **(E)** treats a condition that is necessary for being a top performer as though it were sufficient.

Answer: (E).

**How we get there — and why the exact wording matters.** The stimulus says "*All* top performers attended the training." Read literally, that means attending the training is something every top performer *did* — i.e., it's a **necessary** feature of being a top performer, not a **guarantee** of it. Plenty of non-top-performers could have attended too. So "Priya attended" doesn't establish "Priya is a top performer." That's the flaw in (E).

Notice how much turns on the single word "*all*" and its direction. If the stimulus had instead said "*everyone who* attended the training became a top performer," the arrow would point the other way and Priya's conclusion *would* follow. Same characters, same topic — one word flips the logic. This is the granular text-dependence the whole test runs on. The distractors (A)–(D) name real flaws the argument simply doesn't commit; only (E) matches what the words actually do.
:::

### The one real caveat: reading stamina is a skill, not content

"Nothing to memorize" does not mean "nothing to prepare." The LSAT hands you dense, college-level prose on unfamiliar topics — plate tectonics, 18th-century art criticism, administrative law — and expects you to digest it fast without panicking. That comfort is a **skill**, and it's trainable, but it isn't a syllabus. You build it two ways: directly, by drilling official passages; and indirectly, by making a habit of reading hard nonfiction (sources like *The Economist*, *The Atlantic*, *Aeon*, *Scientific American*). You're not learning the *content* of those articles — you're training your brain to find argument-heavy prose normal. It's stamina, not knowledge.

:::callout-connect
Connects to

This principle is the spine of the whole course. In Part II you'll apply it to *Inference* questions (the answer must be *guaranteed* by the text) and to *Strengthen/Weaken* (a tempting answer often addresses the topic but not the exact conclusion). In Part III you'll meet the "outside knowledge trap" again in Reading Comprehension. Everywhere, the move is the same: **defend your answer from the words on the page.**
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking the smartest-sounding answer.** Sophistication is bait. The credited response is often the plainest, most modest restatement of what the text guarantees.
- **Importing real-world facts.** "But that's actually true!" is not a reason — if the passage doesn't support it, it's wrong. This burns experts hardest on topics they know.
- **Skating past quantifiers.** *All, some, most, only, never* — and the *direction* of a conditional — routinely decide the whole question. Read them like a lawyer reads a contract.
- **Confusing "prepare" with "memorize."** You do prepare — by building reading stamina and drilling — you just don't memorize content.
:::

### Practice — 1.2

:::problem[Q1]{difficulty="easy"}
On the LSAT, an answer choice that is factually true in the real world but not mentioned or supported by the passage is…

- **(A)** usually a trap — truth is not the standard; support from the text is.
- **(B)** acceptable whenever no other choice is supported.
- **(C)** correct only on science passages.
- **(D)** never included by the test-writers.
- **(E)** correct, because true statements are always safe.

::::solution[Solution]
**(A).** The credited-response principle: the standard is textual support, not real-world truth. The test deliberately includes true-but-unsupported answers as bait.
::::
:::

:::problem[Q2]{difficulty="standard"}
In Worked Example 1.2, answer (D) said fish "contains nutrients that protect the heart." Why is it wrong even though it's scientifically accurate?

::::solution[Solution]
Because the stimulus never mentions nutrients or a mechanism — it reports only a correlation in one town. To choose (D) you must **import outside knowledge**, which the credited-response principle forbids. The accurate-but-unmentioned answer is a classic distractor. The provable answer, (A), just restates the finding.
::::
:::

:::problem[Q3]{difficulty="standard"}
Reread Worked Example 1.3. Rewrite the manager's first sentence so that "Priya attended the training" *would* validly establish that she is a top performer.

::::solution[Solution]
Flip the conditional's direction: "**Everyone who attended the advanced training is a top-performing salesperson.**" Now attending → top performer, so "Priya attended" gives "Priya is a top performer." The original said only that top performers *all attended* (top performer → attended), which doesn't let you go backward. One reversed arrow changes a flawed argument into a valid one — the essence of text-dependence.
::::
:::

:::problem[Q4]{difficulty="standard"}
Which preparation activity actually builds LSAT reading ability, consistent with "nothing to memorize"?

- **(A)** Reading only LSAT passages, since other prose is unrepresentative.
- **(B)** Regularly reading dense argument-driven nonfiction to build stamina with hard prose.
- **(C)** Studying a list of common passage topics and their facts.
- **(D)** Skipping reading practice and relying on general knowledge.
- **(E)** Memorizing definitions of scientific and legal terms in case they appear.

::::solution[Solution]
**(B).** You train the *skill* of absorbing hard prose, not the content. (E) and (C) are content-memorization — useless, since the passage supplies everything and outside facts are traps. (D) misunderstands the test entirely.
::::
:::

:::problem[Q5]{difficulty="challenge"}
Two answer choices remain and you're stuck. Choice X is a subtle, sophisticated claim that experts would agree with; choice Y is a plain restatement of two sentences from the passage. Which should you lean toward on a "most strongly supported" question, and what's the deciding test?

::::solution[Solution]
Lean toward **Y**. The deciding test: *can I point to specific words in the passage that force this answer?* Y is provable from the text; X requires believing something the passage never establishes, however true it may be in the world. On support/inference questions the credited response hugs the text, and the impressive-but-unmentioned claim is the trap. *(Caveat: always confirm Y isn't distorted — a restatement that adds an extreme word like "always" can still be wrong. Defend from the exact words.)*
::::
:::

## 1.3 · The 2024 redesign — what changed and why it matters to you

:::callout-intuition
Intuition first

For decades the LSAT had a beloved-and-feared section called **Logic Games** — the grid puzzles where you'd figure out the seating order at a dinner or which employees can be scheduled together. In 2024 it was **removed.** That single change matters to you for a very practical reason: a huge amount of the LSAT advice, books, and courses floating around were written for the old test. If you follow them, you'll spend weeks training a section that *no longer exists*. So before you buy anything or trust any tip, you need to know which test you're preparing for.
:::

### What Logic Games were

Officially "Analytical Reasoning," this section gave you a scenario with a set of rules — "Exactly six runners finish a race; Ana finishes before Bo; Cy does not finish last" — and asked questions you'd solve by diagramming the possibilities. Test-takers trained elaborate diagramming systems for it. It was highly learnable, and many people's biggest score gains came from it.

### Why it was removed

Following a legal settlement concerning test accessibility — the visual, spatial diagramming that made Logic Games work was very difficult to adapt for blind and low-vision test-takers using screen readers — LSAC committed to finding alternatives and ultimately retired the section. Starting with the **August 2024** administration, the Logic Games section was **replaced by a second scored section of Logical Reasoning.**

### The old format vs. the current format

| Scored sections | Before Aug 2024 | Now |
| --- | --- | --- |
| Logical Reasoning | 1 section | **2 sections** |
| Reading Comprehension | 1 section | 1 section |
| Analytical Reasoning (Logic Games) | 1 section | **0 — removed** |

(There's also one unscored "experimental" section either way — covered in Chapter 2.)

:::callout-key
The consequence you must internalize

Because a second LR section replaced the games, **Logical Reasoning now accounts for roughly half of your scored questions** — two of the three scored sections. That makes LR the single most important area to master, and it's why this course devotes its largest part (Part II, eleven chapters) to it. Points that used to live in Logic Games now live in Logical Reasoning.
:::

:::callout-warning
Watch out for obsolete materials

If a book, video, tutor, or forum post talks about "logic games," "game boards," "sequencing/grouping setups," or "diagramming the game," it was written for the **pre-2024 test** and is out of date on structure. Some of its *Logical Reasoning* and *Reading Comprehension* advice may still be fine — those sections didn't fundamentally change — but treat any games content as irrelevant, and double-check that any "how the test is structured" claims match the current three-scored-section format. When in doubt, trust the official source, [lsac.org](https://www.lsac.org), over any third party.
:::

### Practice — 1.3

:::problem[Q1]{difficulty="easy"}
What replaced the Logic Games (Analytical Reasoning) section starting in August 2024?

::::solution[Solution]
A **second scored section of Logical Reasoning.** The test kept its number of scored sections (three) but swapped the games out for an extra LR section.
::::
:::

:::problem[Q2]{difficulty="standard"}
A friend hands you a well-reviewed prep book from 2021 and says it's "the LSAT bible." How should you use it?

- **(A)** Use it exactly as written; the LSAT has not changed since 2021.
- **(B)** Use its Logic Games chapters most heavily, since those are hardest.
- **(C)** Ignore its Logic Games material entirely, verify its structural claims against the current format, and treat only its LR/RC reasoning tips as potentially still useful.
- **(D)** Throw it away; nothing pre-2024 has any value.
- **(E)** Follow it completely; the LSAT never changes.

::::solution[Solution]
**(C).** The games are gone, so that material is dead weight, and any "test structure" section is outdated — but core LR and RC reasoning strategy is largely unchanged and may still help. Verify structure against lsac.org.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why does the removal of Logic Games make Logical Reasoning more important than it was before, from a scoring standpoint?

::::solution[Solution]
Because the removed section was replaced by **another LR section**, so LR went from one of three scored sections to **two of three** — about half your scored questions. A larger share of your score now depends on LR, so mastering it yields the biggest, most reliable gains.
::::
:::

## 1.4 · How law schools actually use your score

:::callout-intuition
Intuition first

You might imagine admissions as a committee lovingly reading each essay and weighing your whole life story. For a few applicants at a few schools, that's partly true. But for the large majority of decisions, admissions is **heavily numbers-driven**, and two numbers dominate: your **LSAT** and your undergraduate **GPA**. Understanding *why* those two numbers carry so much weight tells you exactly how much your LSAT score is worth — and lets you set a target that actually means something instead of a vanity number.
:::

### The two-number model

Every ABA-accredited law school publicly reports, each year, the **median LSAT** and **median GPA** of its entering class (in a document called the *ABA 509 report*; free aggregator sites compile these). The median is the middle value — half of admitted students scored above it, half below. Schools care intensely about their medians because those numbers feed directly into national rankings, which affect prestige, applications, and revenue. The result: schools are strongly motivated to admit students **at or above their medians**, and to offer scholarship money to applicants whose numbers would *raise* them.

:::definition
**Definition 1.3 — Median LSAT / Median GPA.** A school's *median LSAT* is the score of the middle student in its entering class; likewise for GPA. These two published figures are the single best benchmark for your competitiveness at that school. Scoring **above** a school's median LSAT sharply improves both your odds of admission and your chances of merit scholarship money; scoring **below** it usually means you need a compensating strength (a high GPA, or notable "softs") to be competitive.
:::

### Why the LSAT is the number worth chasing

Here's the strategic asymmetry: by the time you're preparing for the LSAT, your **GPA is largely fixed** — years of transcripts you can't rewrite. But your **LSAT score is movable**, often by 10–20 points with disciplined training. So of the two dominant numbers, the LSAT is the one you can still change — which is precisely why investing months in it has such a high return on your application. A better LSAT can offset a mediocre GPA, unlock scholarships worth tens of thousands of dollars, and open schools that looked out of reach.

:::callout-connect
Splitters and reverse-splitters

Applicants whose two numbers don't match get nicknames. A **splitter** has a high LSAT but a lower GPA; a **reverse-splitter** has a high GPA but a lower LSAT. Because a strong LSAT is both movable and heavily weighted, splitters often fare surprisingly well — another reason to pour your energy into the score you can still raise. Chapter 3 covers target-setting in depth; here, just absorb the principle.
:::

### Where the rest of the application fits

None of this means essays, letters of recommendation, work experience, and your personal story don't matter — they do, especially as **tie-breakers** among applicants with similar numbers, at the margins, and at the most selective schools. But they rarely overcome numbers that are far below a school's medians. The honest framing: strong "softs" can move you at the edges; your LSAT and GPA decide which edges you're standing near.

:::example
Worked Example 1.4 — setting a target from medians

standard

**The setup.** Jordan wants to attend one of three schools. Their published medians and Jordan's fixed GPA (3.4) are:

| School | Median LSAT | Median GPA |
| --- | --- | --- |
| A (reach) | 168 | 3.8 |
| B (target) | 161 | 3.5 |
| C (safer) | 154 | 3.3 |

**Question.** Jordan's cold diagnostic was 152. What LSAT target should Jordan set, and why?

Answer: Aim for roughly 162+ (above School B's median), while treating 168 as a stretch goal.

**How we get there.** Work through the logic:

1. **GPA is fixed at 3.4.** Jordan can't change it, so the whole plan runs through the LSAT.
2. **Note where 3.4 sits.** It's *below* A's median (3.8) and B's (3.5), and above C's (3.3). So at A and B, Jordan leans *splitter* — the GPA is the weaker number, so the LSAT has to *compensate* by clearing the LSAT median comfortably.
3. **Set the target above the median of the best realistic school.** School B's LSAT median is 161. Scoring *above* it (say 162–164) both offsets the slightly-low GPA and puts scholarship money in play. That's the primary target.
4. **Keep the reach honest.** School A needs ~168 — a 16-point jump from the 152 diagnostic. That's a lot but not impossible over a long, disciplined prep; treat it as a stretch, not the plan.
5. **Confirm the floor.** Even hitting ~155 already clears School C's median (154) with a GPA above its median — a likely admit. So the plan has a safe floor and real upside.

**The teaching point.** A target isn't a wish; it's derived from published medians and your fixed GPA. Because the LSAT is the movable number, you set the goal at the score that makes your *best realistic* school likely — comfortably above its median — and let a stretch score chase the reach.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking a target score out of the air.** "I want a 170" means little on its own. Derive the number from the medians of schools you'd actually attend.
- **Fixating on one dream school's median** without a plan for the gap — or ignoring that a score just above a *slightly less* selective school's median may come with a huge scholarship.
- **Underrating the LSAT because "GPA matters too."** Both matter, but only one is still movable. The LSAT is where your remaining effort has leverage.
- **Overrating "softs."** Great essays help at the margins; they rarely rescue numbers far below median.
:::

### Practice — 1.4

:::problem[Q1]{difficulty="easy"}
A school's "median LSAT" is best described as…

- **(A)** the score at which half of all applicants are rejected.
- **(B)** the highest score in the class.
- **(C)** the minimum score required for admission.
- **(D)** the score of the middle admitted student — half scored above it, half below.
- **(E)** the average of all applicants' scores.

::::solution[Solution]
**(D).** The median is the middle value of admitted students, not a cutoff, an average, or a maximum. Scoring above it materially improves your odds and scholarship chances.
::::
:::

:::problem[Q2]{difficulty="standard"}
Of your GPA and your LSAT, which deserves the bulk of your remaining effort during a prep cycle, and why?

::::solution[Solution]
The **LSAT**. By prep time your GPA is essentially fixed, while the LSAT can still move 10–20 points with training. Since both numbers are heavily weighted, the movable one is where your effort has leverage — a better LSAT can offset a lower GPA and unlock scholarships.
::::
:::

:::problem[Q3]{difficulty="standard"}
An applicant has a 3.9 GPA but a 151 LSAT and is applying to a school with a 3.6 GPA median and a 160 LSAT median. What kind of applicant are they, and what does the two-number model suggest?

::::solution[Solution]
They're a **reverse-splitter** (high GPA, lower LSAT). Their GPA is well above the school's median, but their LSAT is 9 points below it. Since the LSAT is heavily weighted and still movable, the model suggests the highest-return move is to **retrain and retake to raise the LSAT toward/above 160**; the strong GPA gives them a real shot if they can close the LSAT gap.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Explain why two applicants with identical GPAs and identical personal statements can receive very different scholarship offers from the same school.

::::solution[Solution]
Because of the **LSAT**. Schools compete to raise their published LSAT median (it drives rankings), so they offer merit money to applicants whose scores would *lift* that median. The applicant with the higher LSAT — especially one above the school's median — is worth more to the school's numbers and is far likelier to be offered scholarship dollars, even with everything else equal. It illustrates how directly the LSAT converts into money, not just admission.
::::
:::

## Chapter summary

:::summary
#### The five things to carry out of Chapter 1

- **It's a skill test, not a knowledge test.** Nothing to memorize; your score reflects a trainable performance, so it responds to reps + feedback, not cramming.
- **The credited response is text-defensible.** The right answer is the one the passage lets you prove — not the most reasonable- or sophisticated-sounding one.
- **Outside knowledge is a trap.** True-in-the-real-world but unsupported answers are deliberate bait; quantifiers and the direction of conditionals often decide the whole question.
- **Logic Games are gone (Aug 2024).** Replaced by a second Logical Reasoning section, so LR is now ~half your score — and pre-2024 games material is obsolete.
- **LSAT + GPA drive admissions.** Beat your target school's medians; since GPA is fixed and the LSAT is movable, the LSAT is where your effort has the most leverage.
:::

| Concept | Key idea | Where it comes back |
| --- | --- | --- |
| Skill vs. knowledge | Trained performance, not stored facts | Part V (blind review, drilling) |
| Credited response | Defend the answer from the exact words | All of Parts II & III |
| Outside-knowledge trap | Truth ≠ textual support | Inference (Ch 10), RC (Ch 15–18) |
| Quantifiers/conditionals | One word can flip the logic | Formal logic (Ch 5) |
| 2024 redesign | LR is ~50% of scored questions | Part II (eleven chapters) |
| Medians & targets | LSAT is the movable, high-leverage number | Scoring & targets (Ch 3) |

## Mixed practice set

Twelve items spanning the whole chapter, in mixed order and difficulty. Attempt each before opening its solution — and for the LSAT-style items, practice *defending your answer from the text*.

:::problem[1]{difficulty="easy"}
True or false: to do well on the LSAT you should memorize common legal and scientific terms in advance.

::::solution[Solution]
**False.** The test is self-contained and skill-based; every question supplies what you need. Memorized outside content doesn't help and can lure you into unsupported answers.
::::
:::

:::problem[2]{difficulty="standard"}
"Only students who submitted the form by Friday were entered in the raffle. Devi was entered in the raffle. So Devi submitted the form by Friday." Is this reasoning valid?

- **(A)** Invalid — “only” makes submitting the form sufficient rather than necessary.
- **(B)** Invalid — it confuses necessary and sufficient conditions.
- **(C)** Invalid — it relies on outside knowledge about raffles.
- **(D)** Valid — because most raffles require forms.
- **(E)** Valid — "only" makes submitting-by-Friday necessary for entry, so entry guarantees submission.

::::solution[Solution]
**(E).** "Only students who submitted… were entered" means entry → submitted (submission is necessary for entry). Devi was entered, so Devi submitted. Valid. Watch the word "only" — it sets the direction of the conditional. *(Contrast Worked Example 1.3, where "all top performers attended" pointed the other way and the parallel move was invalid.)*
::::
:::

:::problem[3]{difficulty="standard"}
A prep video from 2022 spends an hour teaching you to diagram "grouping games." Keep watching or move on?

::::solution[Solution]
**Move on.** Grouping games are Logic Games, removed in August 2024. That hour trains a section that no longer exists. Redirect the time to Logical Reasoning, now ~half the scored test.
::::
:::

:::problem[4]{difficulty="standard"}
"A survey of visitors to a national park found that those who used the guided app reported enjoying their visit more than those who didn't. The park concluded the app increases enjoyment." Which is *most supported*?

- **(A)** Among surveyed visitors, app users reported more enjoyment than non-users.
- **(B)** The app contains features scientifically proven to boost mood.
- **(C)** Visitors who skip the app will not enjoy the park.
- **(D)** The app is the best way to enjoy any park.
- **(E)** The guided app caused visitors to enjoy their visit more.

::::solution[Solution]
**(A).** It restates the survey finding — provable from the text. (B) imports outside "scientific" claims never mentioned; (D) and (C) are too strong. Notice this mirrors the fish study in Worked Example 1.2: the modest restatement wins, the impressive-but-unmentioned claim is the trap.
::::
:::

:::problem[5]{difficulty="easy"}
Why can the LSAT fairly compare a chemistry major and a music major?

::::solution[Solution]
Because it tests a content-free **skill** — argument analysis and precise reading — using only material printed on the test. Neither major's coursework provides an edge, so the comparison is about reasoning ability, not background.
::::
:::

:::problem[6]{difficulty="standard"}
Your diagnostic is 156. Your top realistic school has a median LSAT of 160 and a median GPA of 3.5; your GPA is 3.6. What's the reasonable target and rationale?

::::solution[Solution]
Aim **above 160** (say 161–163). Your GPA (3.6) already clears the school's GPA median, so you're not relying on the LSAT to *rescue* a weak GPA — but scoring above the LSAT median strengthens admission odds and opens scholarship money. The gap from 156 to ~162 is a realistic training target. GPA is fixed; the LSAT is the movable lever.
::::
:::

:::problem[7]{difficulty="challenge"}
"All of the paintings in the east wing are by living artists. Some paintings by living artists have never been exhibited before. So some paintings in the east wing have never been exhibited before." Valid or flawed, and why?

- **(A)** Valid — the two premises combine to guarantee the conclusion.
- **(B)** Flawed — the "some living-artist paintings never exhibited" need not be the same paintings that are in the east wing.
- **(C)** Flawed — it relies on knowledge of art galleries.
- **(D)** Valid — because east-wing paintings are a large group.
- **(E)** Flawed — an “all” premise can never support a “some” conclusion.

::::solution[Solution]
**(B).** East-wing paintings are all by living artists, but the "some never-exhibited" living-artist paintings could all hang *elsewhere*. The two "some/all" statements don't force an overlap in the east wing. This is a subtle quantifier trap — exactly the granular, text-dependent reading the chapter warns about. (You'll formalize this in Ch 5.)
::::
:::

:::problem[8]{difficulty="easy"}
Blind review — reattempting missed questions untimed and studying why each wrong answer is wrong — is emphasized because…

- **(A)** schools require it.
- **(B)** it's faster than doing new questions.
- **(C)** feedback on your reps is where most skill improvement happens.
- **(D)** it lets you memorize the answer key.
- **(E)** it lets you finish more questions per hour.

::::solution[Solution]
**(C).** The LSAT is a skill; skills improve through reps *plus* feedback. Review is the feedback step and the main engine of improvement (Part V builds on this).
::::
:::

:::problem[9]{difficulty="standard"}
An answer choice on a "must be true" question is genuinely true in the real world but goes beyond what the passage states. Correct or trap?

::::solution[Solution]
**Trap.** "Must be true" means *guaranteed by the text*. Real-world truth that the passage doesn't establish fails the standard. Defend the answer from the words, not from your knowledge.
::::
:::

:::problem[10]{difficulty="standard"}
Since 2024, how many of the three *scored* sections are Logical Reasoning, and what does that imply for study priorities?

::::solution[Solution]
**Two of three** scored sections are LR (~50% of scored questions). Implication: LR is the highest-value area to master — the biggest, most reliable source of points — which is why it gets the most coverage in this course.
::::
:::

:::problem[11]{difficulty="challenge"}
A tutor guarantees "+15 points by memorizing our 200-flashcard deck of argument patterns." What's the flaw in this pitch, given Chapter 1?

::::solution[Solution]
It treats the LSAT as a **knowledge test**. Flashcards can help you *recognize* patterns faster, but recognition alone isn't the skill — the score comes from executing the analysis on novel stimuli under time and reviewing your misses. Memorization without heavy drilling-and-review can't reliably deliver the gain; the mechanism is wrong even if some study happens.
::::
:::

:::problem[12]{difficulty="challenge"}
In one sentence, state the single principle from this chapter that most governs how you pick answers, and give the one-question test that operationalizes it.

::::solution[Solution]
**Principle:** the credited answer is the one the text supports, not the one that sounds most reasonable. **Operational test:** for any candidate answer, ask "*can I point to specific words in the stimulus that force this?*" — if not, it's not your answer, however true or clever it seems.
::::
:::

LSAT Mastery — Chapter 1. Independent study material, not affiliated with LSAC. Test structure, dates, and policies change; verify current specifics at lsac.org. Practice questions here are original, written to illustrate concepts; use official LSAC PrepTests for timed practice.
