---
title: "Practice-Test Strategy & Endurance"
source: "lsat_ch24_practice_tests.html"
---

Part V · Chapter 24

# Practice-Test Strategy & Endurance

Drilling builds skill; full practice tests build the thing drilling can't — the stamina, pacing, and composure to sustain that skill across a real four-section exam. Here's how to use PTs well.

**Est. study time:** 45–55 min — **Sections:** 5 — **Practice:** 14+ items

## Overview

Type-drilling (Chapter 21) makes each question type automatic, but it happens in short, low-pressure bursts. The real LSAT demands something drilling never trains: **sustaining that skill for nearly three hours across four sections, under pressure, without your accuracy decaying as you tire.** Full-length practice tests (PTs) are how you build that endurance and calibrate your pacing — and, taken and reviewed properly, they're your most realistic feedback on where you actually stand. This chapter covers how to take PTs (in the official interface, full length), how to build stamina with a fifth section, how to *review* a PT (which takes longer than the test itself), and how to taper before test day.

:::callout-tip
Prerequisites

Chapter 2 (the four-section format and the digital interface), Chapter 22 (blind review — you'll apply it to entire PTs), and Chapter 23 (the error log, which every PT feeds). PTs are where all the earlier study machinery gets stress-tested under realistic conditions.
:::

:::callout-key
A PT is a diagnostic, not a scrimmage

The point of a practice test isn't the score — it's the *data*. A PT you take but don't review thoroughly is mostly wasted: you've spent three hours and learned only a number. The score tells you roughly where you are; the **review** (24.3) tells you *why*, and that's what moves you. Take fewer PTs and review them harder rather than the reverse.
:::

## 24.1 · Full, timed PTs in the official interface

:::callout-intuition
Intuition first

To practice the real thing, practice under real conditions. That means **full length, strictly timed, one sitting, in the official digital interface** (LawHub — Appendix H). Every deviation — an untimed section here, a paper test there, a pause to check your phone — makes the PT less predictive and hides a weakness that will surface on test day. The closer your practice conditions to the real exam, the more your PT score means and the fewer surprises await you.
:::

:::definition
**Definition 24.1 — A valid practice test.** A full official PrepTest taken under exam-realistic conditions: strictly timed sections, a single sitting with only the real break, the official on-screen interface and tools (highlighter, eliminator, flag), a quiet solo environment, and the writing task skipped or done separately. The result is a score and a full set of misses you can trust and review.
:::

:::callout-tip
Conditions that make a PT predictive

Mimic test day: same time of day if possible, the official interface, no notes or lookups, phone away, only the scheduled 10-minute break (Chapter 2). Doing your PTs in LawHub also builds fluency with the exact tools you'll use (Chapter 2), so none of your test-day energy goes to the software. A PT taken in a comfy chair with pauses and paper isn't measuring what test day will measure.
:::

:::callout-pitfall
Watch out for these mistakes

- **Un-timed or paused PTs.** They inflate your score and hide timing/endurance weaknesses — the very things PTs exist to reveal.
- **Practicing on paper, testing on screen.** The interface is part of the test; practice in it (Chapter 2).
- **Taking PTs too often to review them.** A PT you don't fully review is mostly wasted. Match your PT frequency to your capacity to review each one.
- **Burning every official test early.** Reserve fresh PrepTests for genuine timed practice once your methods are solid (Chapter 21).
:::

### Practice — 24.1

:::problem[Q1]{difficulty="easy"}
Name three conditions that make a practice test predictive of test day.

::::solution[Solution]
Any three of: **full length, strictly timed, single sitting, official digital interface, quiet solo environment, only the real break, no lookups**. The closer to real conditions, the more the score means.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why does taking PTs on paper when the real test is digital reduce their value?

::::solution[Solution]
Because the **digital interface is part of the exam** — reading on screen, scrolling passages, using the on-screen tools all cost time and focus. A paper PT hides that overhead and doesn't build interface fluency (Chapter 2), so it under-predicts your on-screen performance.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is the *score* the least valuable output of a PT?

::::solution[Solution]
Because the score only says *roughly where you are*; the **review** — the analysis of every miss — says *why*, which is what actually improves you. A PT is a diagnostic; its value is in the data, not the number.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A student takes an untimed PT and scores 168, then a timed one and scores 158. Which is meaningful, and what does the gap indicate?

::::solution[Solution]
The **timed 158** is the meaningful, test-day-predictive score. The 10-point gap indicates a large **timing/endurance** component to their misses — they have substantial untimed ability (168) they can't yet realize under time. Per Chapter 22, that points prep toward **speed, pacing, and section management** to close the gap, not toward more content study (which the untimed score shows is fairly solid).
::::
:::

## 24.2 · Adding a fifth section for endurance

:::callout-intuition
Intuition first

The real test has *four* scored-length sections (three scored + one experimental, Chapter 2), and mental fatigue is a genuine adversary — accuracy tends to sag in the last section as focus wears down. If your PTs are only three or four sections, you under-train that stamina and get ambushed on test day by a tiredness you never practiced through. The fix: periodically add a **fifth section** to your PTs, so four-section stamina feels easy by comparison.
:::

:::definition
**Definition 24.2 — The endurance section.** An extra (fifth) 35-minute section added to a practice test to build the mental stamina to sustain accuracy across the real four-section exam (which itself includes the unlabeled experimental section). Training slightly beyond the real length makes test-day endurance feel comfortable — the "train heavy, compete light" principle.
:::

:::callout-key
Why endurance is a trainable skill, not a fixed trait

Focus is like a muscle: it fatigues, and it strengthens with progressive load. Early in prep, your accuracy may crater in section three or four simply from mental tiredness — that's not a knowledge problem, it's a stamina problem, and blind review will flag those late-section misses as suspiciously concentrated. Adding a fifth section to some PTs progressively extends your focus capacity, so by test day, holding attention across four sections is routine. Don't do it every time (it's draining), but often enough to build the endurance the real test demands.
:::

:::callout-pitfall
Watch out for these mistakes

- **Only ever doing three-section practice.** You'll under-train stamina and fade on the real test's fourth section.
- **Blaming late-section misses on "being bad at that type."** If your accuracy specifically collapses in the last section, that's fatigue — an endurance fix, not a content fix.
- **Adding a fifth section every single time.** It's draining; use it periodically to build stamina, not so relentlessly that you burn out.
:::

### Practice — 24.2

:::problem[Q1]{difficulty="easy"}
Why add a fifth section to some practice tests?

::::solution[Solution]
To **build endurance** beyond the real test's length, so sustaining focus across four sections feels comfortable on test day. Train slightly heavy to compete light.
::::
:::

:::problem[Q2]{difficulty="standard"}
Your accuracy is fine for three sections but collapses in the fourth. Knowledge problem or something else?

::::solution[Solution]
**An endurance/fatigue problem**, not knowledge — the concentration of misses in the last section points to waning focus, not a content gap. Fix with stamina training (fifth-section PTs), not more studying of those types.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why not add a fifth section to every PT?

::::solution[Solution]
Because it's **mentally draining** and could contribute to burnout. Use it *periodically* to progressively build stamina, balancing endurance training against recovery.
::::
:::

:::problem[Q4]{difficulty="challenge"}
How does the error log (Chapter 23) help you detect a stamina problem specifically?

::::solution[Solution]
By sorting misses by **section position**: if your log shows misses disproportionately concentrated in the *last* section of your PTs (across many tests, and across question types you handle fine earlier), that pattern signals **fatigue** rather than a type-specific weakness. The data distinguishes "I decline when tired" from "I'm bad at X," directing you to endurance training instead of content re-study.
::::
:::

## 24.3 · Reviewing a practice test (the real work)

:::callout-intuition
Intuition first

Here's the fact that separates people who plateau from people who climb: **reviewing a PT should take longer than taking it.** Three hours to take, often four or more to review properly. That sounds absurd until you internalize Chapter 22 — the score comes from the review, not the sitting. A PT taken and superficially checked teaches almost nothing; a PT taken and *thoroughly* reviewed can be worth more than a week of drilling, because it shows you exactly how your skills hold up under real conditions and precisely where they break.
:::

:::definition
**Definition 24.3 — Full PT review.** A blind-review pass over an entire practice test: re-solving every uncertain question untimed *before* checking the key, diagnosing each miss as timing vs. knowledge, running the five-step review (Chapter 22) on knowledge gaps, and logging every miss (Chapter 23). It also includes a section-level look: where did time run short, where did fatigue hit, which section dragged your score.
:::

### How to review a whole PT

1. **Blind-review first** (Chapter 22): re-solve everything you flagged, untimed, before seeing answers. Record untimed answers.
2. **Check the key and diagnose each miss:** timing gap or knowledge gap.
3. **Five-step review every knowledge gap** (and every lucky guess): why right, why each wrong, type/flaw, your misstep, takeaway.
4. **Log every miss** (Chapter 23) so this PT feeds your pattern analysis.
5. **Zoom out to the section level:** note where you ran out of time, where accuracy sagged (fatigue), and which section cost you most — this guides pacing and endurance work.

:::callout-tip
Spread the review if you must

A full, honest review is long — it's fine to split it across a day or two so you stay fresh and thorough, rather than rushing it in one exhausted sitting after the test. What's *not* fine is skipping it. If you can't review a PT properly, take fewer PTs; an un-reviewed PT is three hours spent for a single number.
:::

:::callout-pitfall
Watch out for these mistakes

- **Only reading the score.** The score is the least useful output; the per-question and per-section review is the point.
- **Skipping blind review on a PT.** Without it you can't tell timing from knowledge gaps across the whole test — the most valuable read a PT gives you.
- **Not logging PT misses.** A PT is a rich source of pattern data; feed every miss into the error log.
- **Taking PTs faster than you can review them.** Un-reviewed PTs are wasted and deplete your limited official material.
:::

### Practice — 24.3

:::problem[Q1]{difficulty="easy"}
Roughly how long should reviewing a PT take relative to taking it?

::::solution[Solution]
**Longer than the test itself** — often 4+ hours for a 3-hour test. The review, not the sitting, is where improvement comes from.
::::
:::

:::problem[Q2]{difficulty="standard"}
Besides per-question review, what section-level information should a PT review capture?

::::solution[Solution]
Where you **ran out of time**, where **accuracy sagged (fatigue)**, and which **section cost you the most** — data that directs pacing (Chapters 14, 19) and endurance (24.2) work.
::::
:::

:::problem[Q3]{difficulty="standard"}
If you can't fully review each PT, what should you change?

::::solution[Solution]
**Take fewer PTs.** An un-reviewed PT is largely wasted (and burns limited official material); match PT frequency to your capacity to review each one thoroughly.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why can one thoroughly reviewed PT be worth more than a week of unreviewed drilling?

::::solution[Solution]
Because a full PT review delivers three things drilling alone can't: a **realistic, under-pressure test** of every skill at once; a **timing-vs-knowledge diagnosis across the whole exam** (via blind review); and **section-level insight** into pacing and fatigue. It converts one sitting into a precise, prioritized improvement agenda (fed to the error log), whereas a week of unreviewed drilling generates reps with little feedback — activity without direction. The review is where reps become learning (Chapter 1).
::::
:::

## 24.4 · The pre-test taper

:::callout-intuition
Intuition first

Athletes don't do their hardest training the day before a race — they *taper*, easing off so they arrive fresh. The LSAT is the same. In the final days you can't meaningfully raise your ability, but you *can* ruin your test-day performance by cramming yourself into exhaustion. The last stretch is for consolidation and rest, not last-minute grinding. Take your final full PT several days out, then wind down.
:::

:::definition
**Definition 24.4 — The taper.** The planned wind-down in the final days before the test: your last full-length PT roughly **3–7 days before** test day, followed by progressively lighter review (targeted weak-spot work, re-reading your error-log takeaways) and deliberate rest, so you arrive alert and confident rather than depleted.
:::

:::callout-key
Why cramming late backfires

Two reasons. First, the LSAT is a skill that improves slowly over weeks — nothing you do in the last 48 hours meaningfully raises it, so the upside of last-minute grinding is near zero. Second, the *downside* is real: mental fatigue and anxiety degrade performance, and a burned-out brain on test morning underperforms its own trained level. So the expected value of hard late cramming is negative. Rest is not "doing nothing" — it's an active performance strategy, like an athlete's taper. Bank good sleep across several nights (not just the night before), do light confidence-building review, and stop.
:::

:::callout-pitfall
Watch out for these mistakes

- **Taking a full PT the day before.** It exhausts you for no ability gain and can shake your confidence over a random bad section. Finish PTs several days out.
- **Cramming new material at the end.** The last days are for consolidation, not learning new techniques. A new method learned in a panic won't be reliable on test day.
- **Only sleeping well the night before.** One good night can't offset a week of deprivation; bank sleep across several nights (Chapter 27 covers test-day logistics).
- **Mistaking rest for laziness.** Tapering is a deliberate strategy to peak on the right day, not a lack of discipline.
:::

### Practice — 24.4

:::problem[Q1]{difficulty="easy"}
When should your last full-length PT be, relative to test day?

::::solution[Solution]
About **3–7 days before** — then taper into lighter review and rest. Don't take a full PT the day before.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why is hard cramming in the last 48 hours a net-negative move?

::::solution[Solution]
Because the LSAT is a slowly-built skill (near-zero ability gain from last-minute work) while the **downside is real** — fatigue and anxiety degrade performance. Little upside, meaningful downside → negative expected value. Rest instead.
::::
:::

:::problem[Q3]{difficulty="standard"}
What kind of study is appropriate in the final taper days?

::::solution[Solution]
**Light consolidation** — targeted weak-spot review and re-reading your error-log takeaways — plus deliberate rest. No new material or techniques, no exhausting full PTs.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why should you bank sleep across several nights rather than just the night before?

::::solution[Solution]
Because **sleep debt accumulates and one good night can't fully repay it** — arriving after a week of poor sleep leaves you cognitively impaired even if you sleep well the final night (and pre-test nerves often make that night's sleep poor anyway). Banking several solid nights ensures you're genuinely rested and buffers against a restless night before, protecting the focus and stamina the test demands.
::::
:::

## 24.5 · Scenario drills

Six practice-test scenarios. Decide the right move, then check.

:::problem[1]{difficulty="easy"}
You take a PT, check your score, and move on to the next one the same day. What's wrong?

::::solution[Solution]
You **skipped the review** — the part that actually improves you. Blind-review and log the PT thoroughly before taking another; taking PTs faster than you review them wastes them.
::::
:::

:::problem[2]{difficulty="standard"}
Your timed PTs are ~10 points below your untimed practice. What does prep need?

::::solution[Solution]
Emphasis on **speed, pacing, and endurance** — timed full sections and section management (Chapters 14, 19), plus fifth-section stamina work. Your knowledge is largely there; the gap is realizing it under time.
::::
:::

:::problem[3]{difficulty="standard"}
Your last three PTs all show your worst accuracy in the final section. Fix?

::::solution[Solution]
**Endurance training** — add a fifth section to some PTs to build stamina so focus holds through section four. It's fatigue, not a content gap.
::::
:::

:::problem[4]{difficulty="standard"}
Test is in two days. Should you take a full PT tomorrow?

::::solution[Solution]
**No** — you're in the taper. A full PT the day before exhausts you for no ability gain and risks rattling your confidence. Do light review and rest; your last full PT should have been several days ago.
::::
:::

:::problem[5]{difficulty="challenge"}
You have 6 fresh official PTs left and 8 weeks to go. How do you ration them?

::::solution[Solution]
Space them so each gets a **thorough review** and so you build toward a peak: roughly one every week to ~10 days, ramping frequency slightly as test day nears, with your **last one 3–7 days out**. Reserve fresh PTs for genuine timed practice (don't burn them as untimed drills), interleave drilling/review between them, and never take a new PT you won't have time to fully review. Rationing protects both your limited material and the quality of each test's feedback.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, explain the division of labor between drilling and full PTs.

::::solution[Solution]
**Drilling** builds and automates each individual skill/type in focused, low-pressure reps; **full PTs** stress-test all those skills together under realistic time, pressure, and fatigue, revealing pacing and endurance weaknesses drilling can't surface. Drilling makes the pieces work; PTs prove they hold up as a whole on test day — and both depend on blind review and the error log to convert results into improvement.
::::
:::

## Chapter summary

:::summary
#### Practice-test strategy, distilled

- **Take PTs under real conditions:** full length, strictly timed, one sitting, official interface. Deviations hide the weaknesses PTs exist to find.
- **Build endurance** by periodically adding a fifth section; late-section accuracy collapse is fatigue, not a content gap.
- **Review takes longer than the test.** Blind-review, diagnose each miss, five-step the knowledge gaps, log everything, and analyze the section level.
- **A PT is a diagnostic, not a score.** Take fewer and review them harder; don't burn official material you can't review.
- **Taper:** last full PT 3–7 days out, then light review and banked sleep. Late cramming is net-negative.
:::

LSAT Mastery — Chapter 24. Independent study material, not affiliated with LSAC. Use official LSAC PrepTests (via LawHub) for realistic practice; see Appendix H.
