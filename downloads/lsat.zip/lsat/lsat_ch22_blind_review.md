---
title: "The Blind-Review Method"
source: "lsat_ch22_blind_review.html"
---

Part V · Chapter 22

# The Blind-Review Method

If you read one chapter in Part V, read this one. Blind review is the single highest-leverage habit in all of LSAT prep — the difference between practicing and actually improving.

**Est. study time:** 45–55 min — **Sections:** 4 — **Practice:** 14+ items

## Overview

Here is the most important sentence in this course: **your score improves not from how many questions you do, but from how you review them.** A test-taker who does 20 questions and spends an hour understanding every wrong answer will out-improve someone who does 100 and just checks the key. Blind review is the disciplined method for extracting that learning — and most people who "study a lot" but plateau are skipping it. This chapter teaches the whole method: re-solving questions untimed before checking answers, using the results to diagnose *why* you miss points, and running a rigorous five-step review on every mistake.

:::callout-tip
Prerequisites

Chapter 1 (skill improves through reps + *feedback* — blind review is the feedback), Chapter 21 (the training plan this review powers), and the question-type methods from Parts II–III (you'll be applying them slowly and correctly during review).
:::

:::callout-key
Why it works

Under timed conditions, two very different failures look identical on the answer key — a question you *couldn't* do and a question you *could* do but rushed both show up as "wrong." Blind review separates them by having you re-attempt questions *untimed*. That separation tells you whether to fix your **understanding** or your **speed** — and you can't build a smart plan without knowing which. Everything in this chapter flows from that one insight.
:::

## 22.1 · Re-solve untimed before checking the key

:::callout-intuition
Intuition first

The core move is almost embarrassingly simple, and almost nobody does it: after finishing a timed set, but *before* looking at the answers, go back through every question you felt *at all* unsure about and **re-solve it with no time limit**. Take as long as you need. Reach a confident answer. *Then* check the key. This gives you two data points per question — your timed answer and your untimed answer — and the gap between them is pure gold.
:::

:::definition
**Definition 22.1 — Blind review.** The practice of re-solving uncertain questions *untimed and before consulting the answer key*, recording a second ("blind-review") answer for each. Comparing your *timed* answer, your *untimed* answer, and the *correct* answer reveals not just *whether* you were right, but *why* you were wrong — the information you need to improve.
:::

### The procedure

1. **During the timed set,** flag every question you're not fully certain of (even ones you answered).
2. **When time is up, stop** — but don't check answers yet.
3. **Re-solve each flagged question with unlimited time.** Work it fully and correctly, using the proper method (Parts II–III). Change your answer if your careful work disagrees with your rushed one. Record this untimed answer.
4. **Now check the key.** For each question, note the three-way comparison (timed / untimed / correct).
5. **Do the deep review** (22.3) on everything you got wrong even untimed, and note the pattern on everything you fixed by slowing down.

:::callout-tip
Why "before the key" is non-negotiable

The moment you see the correct answer, you lose the ability to test yourself — hindsight makes every right answer look obvious ("of course it's C"). Re-solving *blind* (without knowing the answer) is the only way to find out whether you can actually get the question right when you take your time. If you check the key first, you're not reviewing; you're just reading explanations, which teaches far less.
:::

:::callout-pitfall
Watch out for these mistakes

- **Checking the key first.** This destroys the whole method — you can't blind-review a question whose answer you've seen. Re-solve first, always.
- **Only re-solving questions you got wrong.** Also re-solve questions you got right but felt *unsure* about — a lucky guess is a weakness in disguise.
- **Rushing the untimed re-solve.** The point is to work it *properly*. If you rush, you learn nothing about what you're capable of with full effort.
:::

### Practice — 22.1

:::problem[Q1]{difficulty="easy"}
In one sentence, what is blind review?

::::solution[Solution]
Re-solving uncertain questions **untimed and before checking the answer key**, then comparing your timed answer, untimed answer, and the correct answer to learn *why* you missed points.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why must you re-solve *before* looking at the answers?

::::solution[Solution]
Because once you see the correct answer, **hindsight makes it look obvious** and you can no longer test whether you'd get it right on your own. Blind re-solving is the only way to measure your true untimed ability.
::::
:::

:::problem[Q3]{difficulty="standard"}
Should you blind-review a question you answered correctly but weren't sure about? Why?

::::solution[Solution]
**Yes.** An unsure-but-correct answer may be a **lucky guess** — a hidden weakness. Re-solving it untimed reveals whether you actually understand it or just got lucky, so you can fix it before it costs you next time.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is "reading the answer explanations" not the same as blind review, and which teaches more?

::::solution[Solution]
Reading explanations is **passive** — you absorb someone else's reasoning about a question whose answer you already know, which feels productive but tests nothing. **Blind review is active**: you re-derive the answer yourself without knowing it, exposing exactly where your reasoning breaks. The active struggle to re-solve teaches far more, because improvement comes from *your* mind doing the work, not from recognizing a correct explanation after the fact.
::::
:::

## 22.2 · The timing-gap vs. knowledge-gap diagnosis

:::callout-intuition
Intuition first

Now the payoff. Comparing your timed and untimed answers sorts every miss into one of two categories, and each has a *completely different fix*. If you got it wrong timed but right on blind review, you *can* do the question — you just couldn't fast enough: that's a **timing/pressure** problem, fixed by pacing practice. If you got it wrong even untimed, you genuinely don't understand it yet: that's a **knowledge/understanding** problem, fixed by studying that concept. Without this split, you'd "study harder" when the real issue was speed, or drill for speed when you needed to learn the concept.
:::

:::definition
**Definition 22.2 — The two-way diagnosis.** Each missed question falls into one bucket: **(a) timing gap** — wrong timed, right on blind review (you have the skill but not the speed) → fix with pacing/efficiency work; **(b) knowledge gap** — wrong even on blind review (you lack the understanding) → fix by re-learning the concept/type. A third useful case: **right timed but only by luck** (unsure guess that happened to be correct) → treat as a latent knowledge gap.
:::

| Timed | Blind review | Diagnosis | Fix |
| --- | --- | --- | --- |
| Right (confident) | — | You know it | Move on |
| Wrong | Right | **Timing gap** | Pacing/efficiency drills |
| Wrong | Wrong | **Knowledge gap** | Re-learn the concept/type |
| Right (lucky/unsure) | Wrong or shaky | Hidden knowledge gap | Re-learn; don't be fooled by the point |

:::example
Worked Example 22.1 — reading the diagnosis

standard

**Scenario.** On a section, you missed 6 questions timed. Blind review: you got 4 of them right untimed, and 2 still wrong.

**Question.** What does this tell you, and what should you do?

Answer: 4 timing gaps + 2 knowledge gaps. The 4 mean your skill is fine but your speed isn't — work pacing/efficiency. The 2 mean you don't yet understand those questions — re-learn those specific types/concepts.

**How we get there.** The 4 you fixed untimed prove you *can* do those questions — you simply ran out of time or rushed under pressure. Drilling those concepts harder would be wasted effort; the fix is *speed* (more efficient reading, faster elimination, better section management — Chapters 14, 19). The 2 you still missed untimed are true understanding gaps — no amount of extra time helps because you don't yet know how to do them; go back to the relevant chapter and block-drill that type (Chapter 21). **Teaching point:** the same six "wrong" answers demanded two opposite responses — pacing for four, studying for two. Only blind review reveals which is which.
:::

:::callout-pitfall
Watch out for these mistakes

- **Treating all misses the same.** Timing gaps and knowledge gaps need opposite fixes; lumping them wastes effort on the wrong remedy.
- **"Studying harder" for timing problems.** If you can do the question untimed, you don't need to study it more — you need to do it faster.
- **Drilling for speed on knowledge gaps.** Going faster on a concept you don't understand just makes you wrong faster. Learn it first.
- **Ignoring lucky rights.** An unsure correct answer is a knowledge gap wearing a disguise — review it too.
:::

### Practice — 22.2

:::problem[Q1]{difficulty="easy"}
Wrong timed, right on blind review — what's the diagnosis and fix?

::::solution[Solution]
**Timing gap** — you have the skill but not the speed. Fix with **pacing/efficiency work** (Chapters 14, 19), not more studying of that concept.
::::
:::

:::problem[Q2]{difficulty="easy"}
Wrong timed, still wrong untimed — diagnosis and fix?

::::solution[Solution]
**Knowledge gap** — you don't yet understand it. Fix by **re-learning the concept/type** and block-drilling it (Chapter 21). More time won't help until you know how.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is "study that question type harder" the wrong fix for a timing gap?

::::solution[Solution]
Because you already **can** do it (you got it right untimed) — the problem is *speed*, not understanding. Studying it more addresses a gap that isn't there; the real fix is doing it faster through pacing/efficiency practice.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Over several tests, most of your misses turn out to be timing gaps. What does that imply about your prep focus, and what would be a mistake?

::::solution[Solution]
It implies your **content knowledge is largely solid** and your bottleneck is **speed/efficiency** — so prep should shift toward pacing, faster reading/elimination, and section management (Chapters 14, 19), plus timed full sections to build speed under pressure. The mistake would be to keep **re-studying concepts you already know**, which won't move your score; the leverage is in converting untimed ability into timed performance.
::::
:::

## 22.3 · The five-step single-question review

:::callout-intuition
Intuition first

For every question you got wrong (especially the knowledge gaps), don't just note the right answer — *autopsy* it. A complete review of one question means you can explain not only why the right answer is right, but why *each* of the four wrong answers is wrong, and what you'd do differently next time. This feels slow — five to ten minutes per question — and it's exactly where the score gains come from. A thorough review of one question teaches more than ten new questions rushed.
:::

:::definition
**The five-step review (do this on every miss).**

1. **Re-find the conclusion and the gap** from scratch (Chapter 4) — or, for RC/inference, the relevant text.
2. **State why the right answer is right** in one sentence — pointing to the specific words that support it (the defense test, Chapter 4).
3. **State why each wrong answer is wrong** — name the flavor for each (out of scope, opposite, too strong, half-right, true-but-useless; Chapter 4).
4. **Name the question type** and, if a flaw, the specific flaw (Chapters 6, 9).
5. **Identify what went wrong for *you*** and the takeaway — the exact misstep and the rule to prevent it next time. Log it (Chapter 23).
:::

:::callout-key
The test of a complete review

You've truly reviewed a question when you can do step 3 for *all four* wrong answers — explain the specific reason each is wrong, not just "it's not as good as C." If you can articulate why every trap is a trap, you've internalized the pattern and will recognize it on future questions. This is the skill that compounds: each fully-reviewed question makes the next similar one easier.
:::

:::example
Worked Example 22.2 — a full five-step review

challenge

Question you missed (Weaken): "The town's crime rate fell after it installed streetlights. So the lights reduced crime." You picked (A); the answer is (D). Choices: (A) lights are expensive; (B) residents like the lights; (C) crime also fell statewide (D) the town simultaneously hired more police; (E) lights don't work in fog.

The five steps, executed:

**1. Conclusion & gap:** conclusion = lights reduced crime; premise = crime fell after install. Gap = correlation→causation; assumes no other cause.

**2. Why (D) is right:** "hired more police at the same time" supplies an *alternative cause* for the crime drop, undercutting the causal claim — a textbook causal weakener (Chapter 8).

**3. Why each wrong answer is wrong:** (A) cost — *true but useless* (doesn't address the cause); (B) residents like them — *out of scope*; (C) statewide drop — actually a *weakener too*, but weaker/vaguer than (D)'s specific local alternative — note this was a real second-best, so the trap was picking a partial answer over the strongest; (E) fog — *out of scope/irrelevant*. My pick (A) was the "true but useless" flavor.

**4. Type & flaw:** Weaken question; the argument's flaw is correlation→causation.

**5. What went wrong for me & takeaway:** I grabbed (A) because it was "true and about the lights," without asking whether it affected the *causal conclusion*. Takeaway: on Weaken, pre-phrase "find the alternative cause" and reject answers that don't act on the gap — don't reward mere on-topic truth.

**Teaching point:** that fifth step — naming *your* specific misstep and the rule to prevent it — is what converts one miss into a durable improvement. Without it, you'd likely fall for the same "true but useless" trap again.
:::

:::callout-pitfall
Watch out for these mistakes

- **Stopping at "the answer is D."** Knowing the right answer isn't reviewing — you must explain why the four wrong ones are wrong and what *you* did.
- **Skipping step 5.** The personal takeaway (your misstep + preventive rule) is where improvement actually happens; don't omit it.
- **Reviewing too fast.** A real review is 5–10 minutes per question. If you're doing 30 seconds each, you're checking answers, not reviewing.
- **Not logging it.** Feed the takeaway into your error log (Chapter 23) so patterns surface across sessions.
:::

### Practice — 22.3

:::problem[Q1]{difficulty="easy"}
Name the five steps of a single-question review.

::::solution[Solution]
(1) re-find conclusion & gap; (2) state why the right answer is right (from the text); (3) state why **each** wrong answer is wrong (name the flavor); (4) name the type/flaw; (5) identify *your* misstep + the takeaway, and log it.
::::
:::

:::problem[Q2]{difficulty="standard"}
What's the test of whether you've fully reviewed a question?

::::solution[Solution]
You can explain **why each of the four wrong answers is wrong** (its specific flavor), not merely why the right one is right. Articulating every trap means you've internalized the pattern.
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is step 5 (your misstep + preventive rule) the most important step?

::::solution[Solution]
Because it converts a single miss into a **durable behavioral change** — naming exactly what you did wrong and the rule to prevent it stops you repeating that error. Without it, you understand the question but haven't changed how you'll approach the next one.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"A thorough review of one question beats ten new questions rushed." Explain why, in terms of Chapter 1.

::::solution[Solution]
Because the LSAT is a **skill** improved by reps *plus feedback* (Chapter 1), and the deep review *is* the feedback — it's where you actually diagnose and correct your reasoning. Ten rushed new questions are ten reps with *no* feedback: you repeat whatever errors you already make, learning little. One fully-reviewed question extracts a correctable lesson (the trap you fell for, the rule to fix it) that transfers to many future questions, so its yield per minute is far higher than raw volume.
::::
:::

## 22.4 · Scenario drills

Six review scenarios. Decide the right response, then check.

:::problem[1]{difficulty="easy"}
You finish a timed section and immediately check the answer key. What did you skip, and what's lost?

::::solution[Solution]
You skipped **blind review** (re-solving untimed before the key). Lost: the ability to tell timing gaps from knowledge gaps, since seeing the answers makes them look obvious. Re-solve *first* next time.
::::
:::

:::problem[2]{difficulty="standard"}
A question you got wrong timed, you get right untimed. Do you need to re-study that concept?

::::solution[Solution]
**No** — it's a **timing gap**; you can do it. Work on **speed/pacing**, not re-studying the concept.
::::
:::

:::problem[3]{difficulty="standard"}
You reviewed a miss in 30 seconds by reading the explanation. Adequate?

::::solution[Solution]
**No** — that's passive answer-reading, not review. Do the **five-step review** (5–10 min): re-derive it, explain every wrong answer, name the type, and record your misstep.
::::
:::

:::problem[4]{difficulty="standard"}
You got a question right but were totally unsure. Skip it in review?

::::solution[Solution]
**No** — an unsure right is a **hidden knowledge gap** (possibly a lucky guess). Blind-review it; if you can't confidently re-derive it, study it as you would a miss.
::::
:::

:::problem[5]{difficulty="challenge"}
After blind-reviewing a full PT, you have 12 timing gaps and 3 knowledge gaps. How do you allocate the next week?

::::solution[Solution]
Mostly toward **speed and section management**, since timing gaps dominate (Chapters 14, 19) — do timed sections and efficiency work to convert untimed ability into timed points. Also spend some focused time **re-learning the 3 knowledge-gap types** (block-drill them, Chapter 21). Weight effort to the larger, dominant cause while still closing the concept gaps.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, explain why blind review is called the highest-leverage habit in LSAT prep.

::::solution[Solution]
Because it's the mechanism that turns practice into *improvement*: it separates timing from knowledge gaps (so you fix the right thing), forces you to understand every trap (so you stop falling for them), and produces specific, logged takeaways (so errors don't recur) — making each reviewed question yield far more score gain than raw volume ever could. Without it, you practice your mistakes; with it, you systematically eliminate them.
::::
:::

## Chapter summary

:::summary
#### Blind review, distilled

- **Re-solve uncertain questions untimed, before checking the key.** Get a confident second answer, then compare timed / untimed / correct.
- **Diagnose each miss:** wrong timed + right untimed = *timing gap* (fix speed); wrong untimed = *knowledge gap* (re-learn). Lucky rights = hidden knowledge gaps.
- **Five-step review every miss:** conclusion/gap → why right → why each wrong → type/flaw → *your* misstep + takeaway.
- **The completeness test:** you can say why all four wrong answers are wrong. Log the takeaway (Chapter 23).
- **Reviewing beats volume.** One fully-reviewed question outteaches ten rushed new ones — this is where the score actually moves.
:::

LSAT Mastery — Chapter 22. Independent study material, not affiliated with LSAC. Use official LSAC PrepTests for timed practice and blind review.
