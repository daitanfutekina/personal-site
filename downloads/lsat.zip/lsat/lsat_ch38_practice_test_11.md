---
title: "Practice Test 11"
source: "markdown"
---

Part VI · Chapter 38

# Practice Test 11

An original advanced LSAT simulation emphasizing adversarial causal reasoning, conditional logic, and closely competing reading interpretations.

## Overview

Take all three sections in one sitting, allowing **35 minutes per section** and a **10-minute break after Section II**. Use a timer. Do not open solutions until all three sections are finished. **Flag, do not guess silently:** record each question whose answer you are uncertain about, even if you ultimately select an answer. A lucky guess hides a study opportunity. After timing, blind-review flagged questions untimed (Chapter 22), then consult the key, explain all four wrong choices, and log misses (Chapter 23).

This is an original practice test written for this book, not an official LSAC PrepTest. It contains the three scored-section equivalents only; the real multiple-choice LSAT also includes an unscored section. Official PrepTests on LawHub remain the gold standard for timed practice (Chapter 24).

## 38.1 Section I: Logical Reasoning

:::problem[Question I.1]
A neighborhood library's director claims that the library should keep its self-checkout stations even though staff members report occasional malfunctions. The stations let patrons borrow items when the service desk is busy, and their use has risen steadily since installation. Critics point out that the library has not yet compared the time spent correcting checkout mistakes with the time the stations save. That comparison would be useful before any expansion. Still, the lack of such a study is not a reason to remove a service that already offers a distinct option to patrons.

Which one of the following most accurately expresses the main conclusion of the argument?

- **(A)** The library should expand the number of self-checkout stations immediately.
- **(B)** The library ought to retain its self-checkout stations.
- **(C)** Use of the stations has increased since they were installed.
- **(D)** A formal comparison of staff time saved and staff time lost would be informative.
- **(E)** The stations have eliminated the need for a staffed service desk.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The author recommends retention, not expansion.
2. **Support.** Increasing use and availability during busy periods are offered as reasons; the author concedes a missing time study.
3. **Prephrase.** Find the prescription that the other statements defend.
4. **Why (B) is right.** Retention is expressly recommended at the opening and defended by the final sentence despite the acknowledged uncertainty.
5. **Why the others fail.**
   - **(A)** **Scope inflation:** expansion is expressly postponed pending a comparison.
   - **(C)** **Premise/conclusion reversal:** increased use is evidence, not the recommendation.
   - **(D)** **Concession trap:** the study is acknowledged as useful, not the central recommendation.
   - **(E)** **Overstatement:** the argument expressly says the desk can be busy, not redundant.

**Check:** The last sentence restates why the recommendation to keep the stations survives the objection.
::::
:::

:::problem[Question I.2]
An insurer plans to offer a lower premium to households that choose a larger deductible. Its analyst predicts that the change will reduce the insurer's administrative costs, since small claims cost nearly as much to process as large ones. The analyst notes that most claims filed by the eligible households last year were small enough that a larger deductible would have left those claims unreimbursed. A board member worries that the discount might instead attract more frequent claimants, increasing total claims processing despite the new deductible.

Which one of the following, if true, most strengthens the analyst's prediction?

- **(A)** Households choosing the larger deductible will receive a substantially larger premium discount than was originally planned.
- **(B)** Most eligible households say that they prefer insurance policies that are simple to understand.
- **(C)** Claims just above the larger deductible are more costly to process than claims below it.
- **(D)** Among otherwise comparable households, choosing the larger deductible does not increase the frequency of claims exceeding that deductible.
- **(E)** The insurer has historically earned a profit on most of its policies.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The proposed pricing change will cut processing expense.
2. **Support.** Many formerly payable small claims would no longer be filed for reimbursement; the board suggests offsetting larger claims.
3. **Prephrase.** Neutralize the specific possibility that large-claim volume rises enough to defeat savings.
4. **Why (D) is right.** Holding the frequency of above-deductible claims steady among comparable households preserves the reduction in processable small claims.
5. **Why the others fail.**
   - **(A)** **Backfire trap:** a larger discount concerns premium revenue and may increase selection pressure.
   - **(B)** **Preference diversion:** simplicity of policies does not establish the number of processed claims.
   - **(C)** **Wrong comparison:** greater cost per large claim does not show their frequency will fall.
   - **(E)** **Historical-profit diversion:** profitability does not show this policy reduces administrative expense.

**Check:** With large claims not made more frequent, removing small claims tends to reduce claim processing.
::::
:::

:::problem[Question I.3]
At a fictional observatory, all teams that have discovered a new transient object used the telescope after midnight at least once. A committee wants to maximize discoveries next season, so it proposes requiring every team to observe after midnight. The committee argues that because every successful team met that scheduling condition, imposing it on the remaining teams will make them successful as well. Yet the observatory has not examined whether the late sessions enabled the discoveries, nor whether teams with no discoveries also observed late.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** Treats a condition present in every successful case as one that guarantees success.
- **(B)** Presumes that discoveries cannot occur at any observatory other than the fictional one.
- **(C)** Assumes that every successful team used exactly one session after midnight.
- **(D)** Denies that nighttime observations might occasionally be useful.
- **(E)** Uses the committee's preference as proof that the proposed schedule is inexpensive.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Mandating late observations will make the remaining teams successful.
2. **Support.** Success implies at least one late session, but the proposal infers late session implies success.
3. **Prephrase.** Name the reversal of a necessary condition into a sufficient one.
4. **Why (A) is right.** Discoveries → late observation does not yield late observation → discoveries; unsuccessful teams may observe late too.
5. **Why the others fail.**
   - **(B)** **Invented exclusivity:** no comparison with other observatories is asserted or needed.
   - **(C)** **Quantifier distortion:** at least one is not exactly one.
   - **(D)** **Opposite-position trap:** the argument favors late observing rather than denying possible benefits.
   - **(E)** **Wrong flaw:** the committee does not argue from desire to budget cost.

**Check:** Diagram D → L; proposed inference L → D is the invalid converse.
::::
:::

:::problem[Question I.4]
In a hypothetical clinical trial, participants using an electronic reminder to take a medication completed a higher percentage of scheduled doses than participants using paper calendars. The trial coordinator concludes that the reminders themselves improved adherence. Participants were assigned to the two groups by clinic rather than individually, and one clinic had recently introduced longer appointment hours. The coordinator argues that appointment hours were unrelated to adherence because each group's visits were scheduled with the same frequency, despite the different hours available for arranging those visits.

Which one of the following is an assumption on which the coordinator's argument depends?

- **(A)** The electronic reminders were preferred by every participant who received them.
- **(B)** Both clinics had exactly the same number of patients enrolled.
- **(C)** The electronic reminder caused no missed doses in either clinic.
- **(D)** Paper calendars cannot improve adherence under any circumstances.
- **(E)** The difference in appointment-hour availability did not entirely account for the groups' adherence difference.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The reminders improved dose adherence.
2. **Support.** Adherence differed by clinic and reminder, but clinic-level conditions also differed.
3. **Prephrase.** Require at least some adherence advantage not wholly attributable to appointment access.
4. **Why (E) is right.** If appointment availability completely explains the observed difference, the comparative trial supplies no basis for attributing improvement to reminders.
5. **Why the others fail.**
   - **(A)** **Too strong:** unanimous preference is unnecessary to a dose-completion effect.
   - **(B)** **Irrelevant equality:** unequal sample sizes do not automatically explain the difference in percentages.
   - **(C)** **Perfection trap:** reminders may improve adherence while some doses remain missed.
   - **(D)** **Absolute alternative:** paper calendars need not be useless for reminders to help relative to them.

**Check:** Negate the credited choice: appointment availability fully accounts for the difference, defeating this attribution.
::::
:::

:::problem[Question I.5]
In the fictional town of Larchport, revenue from curbside parking meters rose after the town shortened the maximum permitted stay from four hours to two. Surprisingly, the transportation department reports that the total number of vehicle-hours actually occupied at those meters fell. The meter rate per hour did not change, and the town did not add or remove meters. Some officials take these results as evidence that the department's vehicle-hour estimates are necessarily erroneous, while others think a change in payment behavior could reconcile the two reports.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** After the rule change, many drivers parked for exactly two hours instead of four.
- **(B)** The town spent less maintaining meters after the new rule took effect.
- **(C)** After the rule change, many drivers bought a full two-hour block for very brief stays, whereas previously drivers usually bought only the time they expected to occupy.
- **(D)** Officials considered raising hourly meter rates but ultimately did not.
- **(E)** Public parking lots outside the metered area filled more quickly than before.

::::solution[Solution]
**Answer:** (C)

**Type:** Resolve paradox (Chapter 13)

1. **Conclusion.** Revenue increased while estimated actual vehicle-hours declined at unchanged price and supply.
2. **Support.** Revenue reflects paid hours; the department measures vehicle-hours actually occupied.
3. **Prephrase.** Find a reason paid hours and actual occupied hours can move in opposite directions.
4. **Why (C) is right.** More paid hours going unused after the change allow purchased hours, and hence revenue, to rise even while actual occupied vehicle-hours decline.
5. **Why the others fail.**
   - **(A)** **Same-direction trap:** shorter stays alone does not explain why paid hours increase despite fewer occupied hours.
   - **(B)** **Wrong budget:** maintenance costs concern net proceeds, not meter revenue.
   - **(D)** **Counterfactual trap:** an unadopted rate change cannot explain actual receipts.
   - **(E)** **Area mismatch:** other lots do not establish a change in purchased versus occupied time at the metered curbs.

**Check:** Paid meter-hours, not vehicle-hours, generate receipts; reduced unused purchases changes their ratio.
::::
:::

:::problem[Question I.6]
A volunteer at a hypothetical emergency shelter promises a visitor that the visitor's location will not be disclosed without permission. Later, a caller says that learning the location would make it easier to send an expensive medicine the visitor may need. The shelter has no way to authenticate the caller or verify the claimed medical need before responding. The volunteer refuses to share the location but offers to pass a message privately to the visitor. A supervisor praises the volunteer, saying that possible benefit does not override a serious promise when an equally direct, less intrusive option remains.

Which one of the following principles most helps to justify the supervisor's judgment?

- **(A)** Confidential information should never be disclosed, even with the person's permission.
- **(B)** Any claim involving medicine must be treated as intentionally deceptive.
- **(C)** When a credible alternative can offer a claimed benefit without breaking a confidentiality promise, the promise should be respected.
- **(D)** A promise may be broken whenever breaking it could produce some benefit.
- **(E)** Organizations should always prioritize lower-cost procedures over visitors' preferences.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The volunteer acted properly by declining disclosure and offering to relay information.
2. **Support.** The benefit was unverified, and an alternative could convey the purported aid without revealing location.
3. **Prephrase.** Protect the promise where an alternative preserves the benefit and avoids disclosure.
4. **Why (C) is right.** The principle directly matches the shelter's promise, the possible benefit, and the available message relay.
5. **Why the others fail.**
   - **(A)** **Too absolute:** confidentiality with consent is not at issue.
   - **(B)** **Unsupported accusation:** the caller may be sincere; unverifiability, not deceit, matters.
   - **(D)** **Opposite principle:** possible benefit alone would authorize the very breach rejected.
   - **(E)** **Wrong value:** cost is not cited as the reason for refusing disclosure.

**Check:** Apply the principle: relay message preserves the benefit path while keeping the promise.
::::
:::

:::problem[Question I.7]
A company introduces an app that lets homeowners photograph hail damage and submit claims without an in-person adjuster visit. During the first quarter, the average time between claim filing and payment falls from twelve days to eight. Its manager attributes the improvement to the app and proposes making it mandatory. The company has not compared claims filed through the app with other claims during the same quarter. Most recent hailstorms also affected areas close to the company's newly established regional payment office.

Which one of the following, if true, most seriously weakens the manager's explanation?

- **(A)** Claims submitted without the app during the same quarter were paid just as quickly as app-submitted claims, after controlling for claim complexity.
- **(B)** The app contains a feature for attaching more than one photograph.
- **(C)** Several homeowners found the app difficult to install at first.
- **(D)** The regional office cost more to establish than the app cost to develop.
- **(E)** Even some app submissions needed subsequent in-person inspections.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The app caused the faster payout times.
2. **Support.** A before-and-after average improved amid another operational change.
3. **Prephrase.** Provide a contemporaneous control that does not share the claimed cause.
4. **Why (A) is right.** Equally fast payment for comparable non-app claims points to a shared quarter-level explanation instead of the app.
5. **Why the others fail.**
   - **(B)** **Feature diversion:** attachment capacity says nothing about payments.
   - **(C)** **Anecdote trap:** installation difficulty need not erase the observed speed gain.
   - **(D)** **Cost/revenue swap:** development or office costs do not explain processing times.
   - **(E)** **Partial exception:** inspections for some app claims do not show the app failed to speed the average.

**Check:** Within-quarter non-app outcomes isolate the purported app effect from shared conditions.
::::
:::

:::problem[Question I.8]
A museum's curator observes that visitors who attended its late-night exhibit gave higher enjoyment ratings than those visiting in the afternoon. The curator concludes that the exhibition's lighting is better at night and therefore caused the higher ratings. But the museum charged lower admission after six o'clock, and a different set of visitors attended the late-night sessions. No attempt was made to separate visitors' reactions to the art from their reactions to the price or the evening event atmosphere.

The reasoning in the curator's argument is flawed because it...

- **(A)** Assumes that no visitor attended both the afternoon and evening sessions.
- **(B)** Deduces the precise number of afternoon visitors from a percentage rating.
- **(C)** Concludes that increased enjoyment must reduce museum revenue.
- **(D)** Attributes a difference in reported satisfaction to one feature although other features and the groups themselves differed.
- **(E)** Claims that visitors who attended late never valued the art itself.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Night lighting produced the greater ratings.
2. **Support.** Different visitors and lower prices coincide with late sessions.
3. **Prephrase.** Identify a causal confound or self-selection alternative.
4. **Why (D) is right.** The comparison does not isolate lighting from discounted price, mood, or who chose the time.
5. **Why the others fail.**
   - **(A)** **Invented premise:** repeat visitors are not discussed; the flaw exists either way.
   - **(B)** **Made-up arithmetic:** no headcount inference is made.
   - **(C)** **Unasserted implication:** satisfaction and revenue are not linked in the conclusion.
   - **(E)** **Extreme caricature:** the curator does not claim late visitors ignored the art.

**Check:** Hold lighting constant while changing price or audience: ratings might still differ.
::::
:::

:::problem[Question I.9]
A hypothetical county permits transfers from its emergency reserve only for expenditures that have been classified as urgent. Every transfer classified as urgent also requires a signed authorization from the finance director. During June, three transfers were made from the emergency reserve, and one of the three was used to repair an air-conditioning unit in a courthouse. That repair was not classified as urgent. County policy allows departures from these procedures only after approval by the full council, and the council issued no departure approvals during June.

If the statements above are true, which one of the following must also be true?

- **(A)** None of the three June transfers had a signed authorization.
- **(B)** At least one June transfer failed to satisfy the county's stated transfer policy.
- **(C)** The finance director knew in advance that the repair transfer violated policy.
- **(D)** The two other June transfers were both properly classified as urgent.
- **(E)** The courthouse air-conditioning unit had never needed repair before June.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** An unclassified-as-urgent use occurred among reserve transfers.
2. **Support.** Reserve transfers require urgent classification unless council approves an exception, and no exceptions were approved.
3. **Prephrase.** Infer at least one procedural violation, not unseen motivations or other transfers.
4. **Why (B) is right.** One transfer necessarily failed the urgent-classification condition, and there was no approved exception.
5. **Why the others fail.**
   - **(A)** **All-from-one:** authorization status of any transfer is unreported.
   - **(C)** **Mind-reading:** the director's knowledge is not entailed.
   - **(D)** **Unsupported extrapolation:** the other transfers might also be irregular.
   - **(E)** **Temporal invention:** repair history before June is unknown.

**Check:** Reserve transfer → urgent or council exception; the repair has neither.
::::
:::

:::problem[Question I.10]
A pharmacist reviewing a hypothetical clinic's procedures notes that every patient who receives a personalized counseling call is entered into a follow-up registry. Every patient entered into that registry receives a medication review during the following month. One patient, Hani, received a printed medication guide. The pharmacist concludes that Hani will receive a medication review next month, even though the clinic's record contains no mention of a counseling call to Hani.

The conclusion follows logically if which one of the following is assumed?

- **(A)** Some patients who receive a counseling call are given a printed medication guide.
- **(B)** Every patient in the registry is offered a printed medication guide.
- **(C)** Patients sometimes receive a medication review without receiving counseling.
- **(D)** Hani understood the printed guide without assistance.
- **(E)** Every patient who receives a printed medication guide also receives a personalized counseling call.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Hani will receive a review.
2. **Support.** Call → registry → review; known Hani has guide, which has no stated arrow to call.
3. **Prephrase.** Add guide → call so the supplied chain applies to Hani.
4. **Why (E) is right.** Guide → call → registry → review yields the conclusion by two instances of modus ponens.
5. **Why the others fail.**
   - **(A)** **Quantifier trap:** some calls with guides does not place Hani among callers.
   - **(B)** **Reverse arrow:** registry → guide cannot turn a guide recipient into a registry member.
   - **(C)** **Alternative-route trap:** some reviews without calls does not guarantee Hani a review.
   - **(D)** **Understanding diversion:** comprehension is unrelated to registry enrollment.

**Check:** Diagram G → C → R → M; Hani has G, hence Hani gets M.
::::
:::

:::problem[Question I.11]
A research team comparing hypothetical asteroid photographs claims that its new image-filtering procedure increases the number of faint objects detected. The team reports more detections in processed photographs than in untreated versions of those same photographs. A critic notes that aggressive filtering can sometimes turn random pixel fluctuations into apparent objects. The team replies that the reported detections were subsequently checked against independent observations, and only confirmed objects were included in its comparison. Thus, the team's higher count cannot be explained merely by that specific kind of false detection.

The statement that aggressive filtering can turn random pixel fluctuations into apparent objects serves which one of the following roles?

- **(A)** It is the team's final conclusion about why filtering works.
- **(B)** It is the principal evidence that the untreated images contain more objects.
- **(C)** It identifies a premise that both sides explicitly reject as false.
- **(D)** It raises a possible alternative explanation that the team attempts to eliminate.
- **(E)** It establishes that independent observations are less reliable than image filtering.

::::solution[Solution]
**Answer:** (D)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The team rejects the critic's false-detection explanation for its count difference.
2. **Support.** The critic suggests artifacts; team answers with independent confirmation.
3. **Prephrase.** Describe the challenged claim's function as an objection, not the defended thesis.
4. **Why (D) is right.** The pixel-fluctuation concern is the alternative cause that independent verification addresses.
5. **Why the others fail.**
   - **(A)** **Speaker swap:** the team does not assert the concern as its conclusion.
   - **(B)** **Direction reversal:** the processed versions have more verified detections.
   - **(C)** **Concession confusion:** the team does not deny filters can create artifacts, only that they explain this dataset.
   - **(E)** **Unjustified ranking:** independent observations are used as a check, not condemned.

**Check:** Remove the critic's statement and the subsequent verification rebuttal loses its target.
::::
:::

:::problem[Question I.12]
A fictitious city plans to refinance an outstanding bond through a replacement bond carrying a lower stated interest rate. The treasurer claims this will reduce the city's total future borrowing costs. The replacement will require a one-time underwriting fee, and the outstanding bond can be redeemed early only after paying a contractual charge. The treasurer has calculated the interest payments under both bonds but has not mentioned those transaction costs in the presentation to council.

Which one of the following is an assumption required by the treasurer's reasoning?

- **(A)** The refinancing will lower the stated interest rate by at least half.
- **(B)** The total fees and early-redemption charge will not entirely eliminate the interest-payment savings.
- **(C)** No city has ever paid an underwriting fee when refinancing.
- **(D)** The outstanding bond was issued under an unusually high interest rate.
- **(E)** The city will never again issue bonds after the refinancing.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Refinancing will lower total future borrowing costs.
2. **Support.** Interest drops, but offsetting one-time costs are omitted.
3. **Prephrase.** Require positive net savings after fees.
4. **Why (B) is right.** If fees and charge meet or exceed all interest savings, total costs cannot decline as claimed.
5. **Why the others fail.**
   - **(A)** **Overprecision:** a small reduction can produce net savings.
   - **(C)** **Contradicts given facts:** this deal expressly incurs a fee.
   - **(D)** **Wrong comparison:** historical unusualness of the old rate is unnecessary.
   - **(E)** **Future distraction:** subsequent bond issuance is independent of this deal's total cost.

**Check:** Net saving = interest saving minus fees and redemption charge; it must be positive.
::::
:::

:::problem[Question I.13]
A hospital ethics committee, in a hypothetical pilot program, moved its routine consultations from weekly meetings to a shared written queue. The committee chair claims that this will shorten the time required to resolve straightforward cases without sacrificing review quality. In the pilot, routine cases reached a decision sooner than under the old process, but critics suggest that speed came from ignoring difficult objections. The chair notes that the queue records objections yet acknowledges that simply recording an objection does not ensure it was meaningfully considered.

Which one of the following, if true, most strengthens the chair's claim?

- **(A)** The written queue was less expensive to operate than the weekly meeting schedule.
- **(B)** More staff members accessed the queue than attended the old meetings.
- **(C)** The queue contained fewer routine cases than the meetings had handled during the prior year.
- **(D)** The chair personally preferred reading objections to listening to them.
- **(E)** Independent reviewers found that written-queue decisions addressed material objections as completely as comparable decisions made during meetings.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The queue improves speed without reducing quality.
2. **Support.** The pilot had faster decisions but critics suspect neglect of substantive objections.
3. **Prephrase.** Show preserved treatment of objections in comparable cases, not just speed or participation.
4. **Why (E) is right.** Independent quality review directly tests the alleged sacrifice and finds none in comparable cases.
5. **Why the others fail.**
   - **(A)** **Cost diversion:** cost is not the challenged quality dimension.
   - **(B)** **Participation proxy:** access does not prove consideration of important arguments.
   - **(C)** **Wrong denominator:** fewer cases might affect speed, not show that quality survived.
   - **(D)** **Authority/preference trap:** the chair's taste does not validate decision quality.

**Check:** The alternative explanation "faster because objections were ignored" loses force under independent content review.
::::
:::

:::problem[Question I.14]
An insurance analyst argues that a storm-response reserve should be funded using a rainfall index rather than last year's claim count. Claims depend partly on how widely policyholders report damage, and reporting campaigns change that number. Rainfall measurements can be checked independently of policyholder reporting. The analyst does not say the rainfall index predicts losses perfectly; rather, the analyst argues that an imperfect indicator insulated from reporting campaigns is preferable, for this funding decision, to a seemingly more direct number distorted by administrative activity.

Which one of the following most accurately describes the method of reasoning in the argument?

- **(A)** It supports an alternative measure by identifying a systematic source of distortion in the competing measure.
- **(B)** It argues that any independently measured quantity is an exact predictor of claim costs.
- **(C)** It infers from a single unusual storm that past claims data are always worthless.
- **(D)** It establishes a universal rule by citing expert consensus about insurance pricing.
- **(E)** It shows that reporting campaigns increase actual storm frequency.

::::solution[Solution]
**Answer:** (A)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The rainfall index should guide the reserve rather than last year's claim count.
2. **Support.** Reporting campaigns alter claim counts; rainfall can be observed independently.
3. **Prephrase.** Name a comparative evaluation of measurement reliability.
4. **Why (A) is right.** The argument identifies bias in a direct-looking measure and recommends a less confounded proxy while conceding it is imperfect.
5. **Why the others fail.**
   - **(B)** **Too strong:** the analyst explicitly denies perfection.
   - **(C)** **Invented case:** no single storm is cited, and worthless is stronger than distorted.
   - **(D)** **Appeal to authority:** no expert consensus is offered.
   - **(E)** **Causal switch:** campaigns affect reports, not the storms themselves.

**Check:** Premise about measurement distortion is used to favor an alternate index, not to prove causation.
::::
:::

:::problem[Question I.15]
At a hypothetical bakery, any employee certified to operate the overnight ovens must have completed the safety workshop. Employees who completed the workshop are allowed to request an overnight assignment, though a request may still be denied. Mira is certified to operate the overnight ovens. Therefore, Mira is eligible to request an overnight assignment. The manager emphasizes that this conclusion is only about eligibility to request, not about whether Mira will actually receive that assignment.

Which one of the following arguments is most similar in its reasoning?

- **(A)** All licensed guides have taken the orientation. Devin took the orientation; so Devin is a licensed guide.
- **(B)** Everyone who may apply for access has taken the orientation. Devin took the orientation; so Devin may apply.
- **(C)** All licensed guides have taken the orientation, and everyone who has taken the orientation may apply for route access. Devin is a licensed guide; so Devin may apply for route access.
- **(D)** All licensed guides may apply for route access. Devin may apply; so Devin is a licensed guide.
- **(E)** Some licensed guides have taken the orientation and some orientation participants may apply. Devin is licensed; so Devin may apply.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Mira may request the assignment.
2. **Support.** Certified → workshop → request eligible; Mira certified.
3. **Prephrase.** Match a valid A → B → C, A, therefore C chain.
4. **Why (C) is right.** Guide → orientation → may apply; licensed guide Devin therefore may apply, with no guarantee of admission.
5. **Why the others fail.**
   - **(A)** **Converse:** orientation does not prove licensed status.
   - **(B)** **Converse:** the necessary orientation condition is treated as sufficient.
   - **(D)** **Affirming consequent:** may apply does not establish licensing.
   - **(E)** **Some-to-all:** existential claims cannot show every licensed individual is eligible.

**Check:** C → W → R; C(Mira), hence R(Mira).
::::
:::

:::problem[Question I.16]
A hypothetical manufacturer opened a telephone hotline to collect reports of possible side effects from people taking a new formulation. Calls reporting headaches doubled during the hotline's first month. A spokesperson concludes that the formulation must have doubled the incidence of headaches among users. During the same month, the manufacturer placed reminder notices on every package and mailed doctors instructions encouraging reporting even mild symptoms. The spokesperson dismisses those changes because neither notice was intended to cause headaches.

The argument is most vulnerable to criticism because it...

- **(A)** Assumes that all callers were intentionally making false reports.
- **(B)** Treats a randomized comparison as though it were an uncontrolled survey.
- **(C)** Assumes that an event can never have more than one physical cause.
- **(D)** Confuses a dosage reduction with an increase in the number of medicine users.
- **(E)** Fails to distinguish a change in the number of reported events from a change in the incidence of those events.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The drug formulation doubled headache incidence.
2. **Support.** Reports doubled, but efforts to increase reporting coincided.
3. **Prephrase.** Separate observation/ascertainment rate from underlying symptom rate.
4. **Why (E) is right.** Packaging and physician notices could elevate calls even if headache frequency stayed constant; intent not to cause headaches is irrelevant.
5. **Why the others fail.**
   - **(A)** **Invented dishonesty:** truthful calls can still rise with higher reporting propensity.
   - **(B)** **Wrong study design:** no randomized comparison is described.
   - **(C)** **Different causal error:** multiple physical causes are not ruled out.
   - **(D)** **Unmentioned variables:** dosage changes and population size are not invoked.

**Check:** Reports = occurrences × probability of reporting; the latter changed.
::::
:::

:::problem[Question I.17]
At a hypothetical observatory, researchers classify an observed dimming as a provisional transit candidate only if it repeats and passes a basic image-quality check. A subset of provisional candidates is then examined for signals suggesting contamination from nearby sources. None of the candidates rejected at that second stage proceeds to the costly telescope follow-up stage. In the last cycle, every candidate that received telescope follow-up was subsequently classified either as confirmed or as unresolved; no other final labels were assigned to that subset. Several provisional candidates were never examined at the second stage.

Which one of the following is most strongly supported by the information above?

- **(A)** Every provisional candidate ultimately received telescope follow-up.
- **(B)** All unresolved candidates failed the initial image-quality check.
- **(C)** Every candidate receiving telescope follow-up had previously avoided rejection at the second screening stage.
- **(D)** Any signal passing the basic check is a confirmed transit.
- **(E)** Several candidates rejected at the second stage were nevertheless confirmed in follow-up.

::::solution[Solution]
**Answer:** (C)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Find a supported restriction on the follow-up population.
2. **Support.** Second-stage rejection excludes follow-up; every follow-up has one of two final labels.
3. **Prephrase.** Use the contrapositive of rejected → no follow-up.
4. **Why (C) is right.** Follow-up → not rejected at the second stage, regardless of whether some candidates skipped that screening.
5. **Why the others fail.**
   - **(A)** **All-from-some:** some provisional candidates never reached the second stage.
   - **(B)** **Stage confusion:** unresolved is a follow-up outcome, not an initial failed check.
   - **(D)** **Premature confirmation:** basic screening yields only candidacy.
   - **(E)** **Direct contradiction:** the passage rules out follow-up for rejected candidates.

**Check:** Rejected → not followed; followed → not rejected.
::::
:::

:::problem[Question I.18]
A municipal finance director argues that a proposed small tax on vacant storefronts will increase occupancy. Owners of empty shops, the director says, will prefer collecting rent to paying the tax. The proposal would apply only to properties whose owners can legally lease them immediately. A council member objects that owners may respond by transferring the property to a related company and leaving the space unused. The director replies that such transfers would still be subject to the tax and therefore would not alter incentives.

Which one of the following, if true, most seriously weakens the director's prediction?

- **(A)** Owners who transfer a property to a related company would still owe the tax.
- **(B)** For many affected properties, the cost of adapting otherwise legally leasable premises to attract a tenant is greater than both the tax and the rent obtainable during the relevant period.
- **(C)** Some currently occupied storefronts have remained occupied for years.
- **(D)** The city expects to spend some of the tax revenue on street repairs.
- **(E)** Many potential tenants would rather lease a different kind of property.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The tax will induce owners to lease vacant storefronts.
2. **Support.** Tax raises cost of vacancy, supposedly making rent relatively attractive.
3. **Prephrase.** Find a reason leasing remains worse than vacancy plus tax.
4. **Why (B) is right.** If adapting a legally leasable space to suit prospective tenants costs more than rent and avoided tax combined, rational owners can remain vacant despite the tax.
5. **Why the others fail.**
   - **(A)** **Repeats defender:** transfer taxation strengthens the rebuttal to avoidance.
   - **(C)** **Wrong group:** already occupied properties do not test decisions about vacancies.
   - **(D)** **Revenue diversion:** street repairs are not an immediate leasing incentive.
   - **(E)** **Weak market hint:** tenant preferences may matter, but without a comparison to net lease incentives they are less direct.

**Check:** Compare leasing payoff (rent minus readiness cost) against vacant payoff (minus tax).
::::
:::

:::problem[Question I.19]
A recreational sports league intends to rotate referees among fields to reduce complaints of favoritism. The league director explains that recurring assignments allow friendships between referees and teams, and that players perceive even impartial calls as suspicious when such friendships are visible. The director therefore expects rotating assignments to reduce the number of complaints. However, the league's reporting system records all complaints together, regardless of whether they concern favoritism, confusing rules, or unsafe field conditions.

Which one of the following does the director's prediction require assuming?

- **(A)** Every accusation of favoritism against a referee has been justified.
- **(B)** The league can eliminate friendships between referees and teams entirely.
- **(C)** Players understand every rule that referees must enforce.
- **(D)** Any additional complaints caused by the rotation will not fully offset the reduction in favoritism-related complaints.
- **(E)** Rotating referees will reduce injuries on the fields.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Total recorded complaints will fall after rotation.
2. **Support.** Rotation targets perceived favoritism, yet reported totals include unrelated or newly induced complaints.
3. **Prephrase.** Require an overall net reduction, not merely decline in one category.
4. **Why (D) is right.** If rotation produces enough new complaints to replace those about favoritism, the total need not fall.
5. **Why the others fail.**
   - **(A)** **False validation:** perceptions can produce complaints even when calls are impartial.
   - **(B)** **Overstatement:** fewer recurring assignments may reduce suspicion without erasing every friendship.
   - **(C)** **Idealization:** complete rules knowledge is not required for net complaints to decrease.
   - **(E)** **Different outcome:** injury rates are not the predicted complaint count.

**Check:** Total change = reduced favoritism complaints plus changes in other complaint categories.
::::
:::

:::problem[Question I.20]
A fictional insurer wrote a policy promising to reimburse losses caused by sudden pipe failures but excluding deterioration. In an unusual claim, both a sudden break and years of gradual weakening contributed to damage. The insurer's reviewer must decide how to apply language that does not say what happens when both causes operate. The reviewer recommends giving the policyholder the interpretation a reasonable buyer would have drawn, since the insurer drafted the wording and could have clarified the overlap when the policy was sold.

Which one of the following principles, if accepted, most supports the reviewer's approach?

- **(A)** Where one party drafts an ambiguous term and the other reasonably relies on it, unresolved ambiguity should ordinarily be interpreted against the drafter.
- **(B)** Every insurance claim involving two causes must be paid in full.
- **(C)** A contract should always be construed to minimize the insurer's expenses.
- **(D)** An ambiguous term should be enforced according to the private intention of the drafting party.
- **(E)** Any policy containing an exclusion is invalid in its entirety.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Reasonable buyer interpretation should govern unresolved drafting ambiguity.
2. **Support.** Insurer controlled language and could specify mixed causes.
3. **Prephrase.** Assign risk of ambiguity to party controlling wording, not assume all claims paid.
4. **Why (A) is right.** The drafter-responsibility principle precisely connects control of terms, reasonable reliance, and interpretive rule.
5. **Why the others fail.**
   - **(B)** **Blanket-outcome trap:** does not distinguish ambiguous from unambiguous dual-cause clauses.
   - **(C)** **Opposite incentive:** saving insurer expenses favors drafter irrespective of reasonable expectation.
   - **(D)** **Hidden-intent trap:** private intent undermines reliance on communicated terms.
   - **(E)** **Extreme remedy:** one unclear overlap does not make every term void.

**Check:** Apply only to unresolved ambiguity; the principle does not predetermine the factual payout.
::::
:::

:::problem[Question I.21]
An ethics instructor surveys twenty volunteers who signed up for a seminar on conflicts of interest. Eighteen say they would disclose a minor conflict even if disclosure were personally inconvenient. The instructor concludes that nearly all employees in the institution would do the same. Those attending the seminar had been recruited through a notice expressly inviting staff who were interested in ethical decision making. Employees who did not volunteer were not surveyed, and the instructor offers no evidence that the volunteers mirror the workforce.

The argument is most vulnerable to criticism because it...

- **(A)** Generalizes from a self-selected group likely to differ in relevant attitudes from the larger population.
- **(B)** Infers that disclosure is morally obligatory solely because many respondents endorse it.
- **(C)** Assumes that all conflicts of interest are equally severe.
- **(D)** Treats the survey as invalid because exactly twenty people answered it.
- **(E)** Uses the respondents' job titles to prove their stated answers were insincere.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Nearly all employees would voluntarily disclose an inconvenient conflict.
2. **Support.** Eighteen of twenty ethics-seminar volunteers say they would disclose.
3. **Prephrase.** Identify volunteer selection tied to the measured willingness, not merely small size.
4. **Why (A) is right.** Interest in ethics may correlate with willingness to disclose; the sample is not shown representative of employees.
5. **Why the others fail.**
   - **(B)** **Normative switch:** the instructor predicts behavior, not moral duty.
   - **(C)** **Invented equivalence:** different conflict severities are not used to generalize.
   - **(D)** **Sample-size-only trap:** the specific problem is recruitment bias, which would remain even with more volunteers.
   - **(E)** **Fabricated credibility attack:** no job-title or lying inference occurs.

**Check:** The sampling frame is volunteers drawn by an ethics invitation; target is all employees.
::::
:::

:::problem[Question I.22]
A fictional town's procurement rule states that every contract approved by the emergency board is exempt from competitive bidding. A second rule states that any contract exempt from competitive bidding must be reviewed by the auditor before payment. The town has just signed a contract to repair an unstable footbridge. The finance officer concludes that this contract must receive an auditor review before the town pays, but the officer gives no information about which board approved the repair.

Which one of the following, if assumed, makes the officer's conclusion logically follow?

- **(A)** The emergency board has approved at least one contract this year.
- **(B)** The auditor often reviews contracts that were competitively bid.
- **(C)** Every contract reviewed by the auditor was approved by the emergency board.
- **(D)** The footbridge must be repaired before residents can cross safely.
- **(E)** The footbridge repair contract was approved by the emergency board.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The footbridge contract needs auditor review before payment.
2. **Support.** Emergency approval → bidding exempt → auditor review; no link from this contract to the chain.
3. **Prephrase.** Attach the footbridge contract to the first link of the chain.
4. **Why (E) is right.** Emergency approval supplies the sufficient starting condition, so the two rules yield mandatory review.
5. **Why the others fail.**
   - **(A)** **Existential irrelevance:** approval of a different contract proves nothing here.
   - **(B)** **Weak frequency:** often reviewing bid contracts does not guarantee review here.
   - **(C)** **Reverse conditional:** auditor review → emergency approval cannot infer review from contract existence.
   - **(D)** **Practical urgency:** a safety need alone does not satisfy a board-approval rule.

**Check:** Approved(E) → exempt(B) → reviewed(A); contract has E, therefore A.
::::
:::

:::problem[Question I.23]
Pharmacist: In a hypothetical trial, offering patients smaller, more frequent medication packages may improve adherence. But because trial participants know when packages are counted, observed improvements cannot establish that packaging works outside a monitored setting. Even a limited rollout outside this study should wait until an unmonitored test clarifies the effect. Trial designer: Monitoring may inflate adherence, but it does not logically follow that the observed improvement is entirely due to monitoring. The current evidence is enough to justify a limited rollout while a less-monitored study is conducted.

The pharmacist and the trial designer disagree about whether...

- **(A)** Monitoring might influence patient adherence.
- **(B)** The medication packages were smaller in the trial.
- **(C)** The present trial evidence is sufficient to justify beginning a limited rollout of the packaging intervention.
- **(D)** A less-monitored study could provide useful additional evidence.
- **(E)** Adherence outside a trial can never improve through packaging changes.

::::solution[Solution]
**Answer:** (C)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Identify the question to which the two speakers give opposite answers.
2. **Support.** Pharmacist opposes any rollout pending study; designer permits rollout now while studying.
3. **Prephrase.** Find a specific present-action threshold, not a shared concern.
4. **Why (C) is right.** Pharmacist says no rollout until less monitoring; designer says a limited rollout is already justified.
5. **Why the others fail.**
   - **(A)** **Shared concession:** both allow monitoring effects.
   - **(B)** **Background fact:** neither disputes the packaging intervention described.
   - **(D)** **Shared plan:** both support additional less-monitored inquiry.
   - **(E)** **Extreme extrapolation:** pharmacist questions proof, not the possibility of benefit.

**Check:** Pharmacist: not yet; designer: yes, limited rollout.
::::
:::

:::problem[Question I.24]
At a fictional observatory, only projects approved for high-resolution tracking can use the precision spectrograph. Project Selene has obtained approval for high-resolution tracking. Its lead astronomer therefore concludes that Selene will use the precision spectrograph. Yet the approval does not require use of that instrument; projects may instead rely on a different telescope or leave the approval unused during the season. The lead insists that having permission settles what the team will do, although the next season's observation calendar remains undecided.

Which one of the following arguments exhibits the most similar flaw?

- **(A)** All employees who enter the control room are licensed. Nia entered, so Nia is licensed.
- **(B)** Only licensed technicians may enter the control room. Nia is licensed, so she will enter the control room.
- **(C)** Anyone assigned the late shift must attend training. Nia has the late shift, so she must attend training.
- **(D)** Only technicians who passed the exam may enter. Nia did not pass, so Nia cannot enter.
- **(E)** Some licensed technicians enter the room. Nia is licensed, so it is possible she will enter.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** Approval guarantees eventual spectrograph use.
2. **Support.** Use → approval; approval obtained.
3. **Prephrase.** Match the invalid converse, but preserve the eligibility-versus-actual-use distinction.
4. **Why (B) is right.** Enter → license is inverted to license → will enter, mirroring use → approval converted to approval → use.
5. **Why the others fail.**
   - **(A)** **Valid modus ponens:** entry gives the license required.
   - **(C)** **Valid direct rule:** late shift entails training.
   - **(D)** **Valid contrapositive:** not passed → cannot enter.
   - **(E)** **Modal distinction:** possible entry is not the guaranteed entry error in the original.

**Check:** Both flawed arguments infer action from a necessary eligibility condition.
::::
:::

:::problem[Question I.25]
A hypothetical insurer is considering replacing staff flood-damage inspectors with a specialist subcontractor. The insurer claims the change will reduce its total inspection spending because the subcontractor's quoted fee per completed inspection is lower than the staff team's average direct labor expense per inspection. The insurer's staff currently perform quality checks on disputed claims, and the subcontractor contract would not include those checks. Some managers say the staff could absorb the additional disputed-claim work; others say extra employees would be needed.

Which one of the following questions would be most useful to answer in evaluating the insurer's prediction?

- **(A)** Do policyholders find the subcontractor's company name easy to pronounce?
- **(B)** Has the subcontractor ever inspected damage caused by a storm rather than a flood?
- **(C)** Would the subcontractor agree to advertise the insurer's policies?
- **(D)** Would the cost of providing the omitted quality checks eliminate the fee savings achieved by subcontracting inspections?
- **(E)** Is the quoted fee lower than the direct labor expense for the insurer's least experienced staff inspector?

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** Total spending falls by moving routine inspections to subcontractor.
2. **Support.** Per-inspection direct fees are lower but omitted quality checking may create an extra cost.
3. **Prephrase.** Ask about whether omitted work wipes out apparent savings.
4. **Why (D) is right.** A yes answer could erase savings; a no answer leaves the savings prediction substantially stronger.
5. **Why the others fail.**
   - **(A)** **Cosmetic diversion:** pronunciation cannot determine cost.
   - **(B)** **Unrelated qualification:** previous storm specialty does not quantify spending.
   - **(C)** **Marketing diversion:** advertisement is not inspection process cost.
   - **(E)** **Wrong comparator:** the conclusion compares total system cost, not one least-experienced inspector.

**Check:** Calculate vendor fees + retained quality-check expense versus present full inspection expense.
::::
:::

## 38.2 Section II: Reading Comprehension

### Passage 1

In a hypothetical jurisdiction, a Consumer Decisions Act requires an agency that denies an application for a household energy grant to provide the applicant with a “written explanation of the grounds for denial.” The Act defines neither “written” nor “explanation.” To manage a high volume of applications, the agency begins sending standardized letters that reproduce the applicable eligibility requirement and state that the applicant failed to meet it. Each letter identifies the relevant requirement but offers no details about the applicant's circumstances. An applicant argues that the letters supply conclusions, not explanations. The agency replies that the letters contain words, state the grounds in the language of the Act, and therefore satisfy the text.

One interpretive approach begins with the ordinary sense of the enacted words. On that account, “written” presents little difficulty: the communication is in writing. “Explanation,” however, is not simply a synonym for “statement.” To explain a decision is ordinarily to make intelligible why that decision follows from the facts or reasons being invoked. A letter saying only that an applicant “does not satisfy the household test” might be a statement of the result and a citation to a rule without explaining how the rule applies. Yet ordinary language alone does not establish the required level of detail. An explanation may be brief, and it need not recount every fact the agency reviewed.

A second approach looks to the Act's function. If requiring reasons is intended to help applicants identify mistakes and decide whether to seek review, a bare formula can frustrate that function. But functional reasoning has its own hazard. An interpreter who insists on the most comprehensive conceivable account of each denial may convert a modest obligation to explain into a duty to furnish an entire case file. That would substitute an attractive policy for the one the legislature actually enacted. Nor can the agency's administrative convenience, though relevant to implementation, decide the meaning of a requirement imposed partly to constrain administrative action.

The more persuasive interpretation combines the approaches without treating either as a blank check. The ordinary distinction between announcing a conclusion and explaining it gives the statutory text a minimum demand for an intelligible connection between the rule and the particular decision. The Act's apparent function confirms why a connection matters. At the same time, the text's silence about format, length, and document production cautions against importing elaborate procedural duties. A short explanation identifying which factual condition was not met could suffice. The standardized letters in this example, by contrast, leave an applicant unable to tell whether the agency misread a submitted bill, applied the wrong period, or simply lacked required evidence. The statute need not be stretched into a demand for exhaustive disclosure to recognize that those letters fall short of explanation.


:::problem[Question II.1]
Which one of the following most accurately states the main point of the passage?

- **(A)** A statutory requirement of a written explanation demands some case-specific connection between a rule and a denial, without requiring exhaustive disclosure.
- **(B)** The statute unambiguously obliges the agency to disclose its entire internal file for every denial.
- **(C)** Administrative efficiency should always determine how detailed a denial letter must be.
- **(D)** Plain statutory words have no role when the legislature has a beneficial purpose.
- **(E)** Standardized written notices are necessarily invalid regardless of their contents.

::::solution[Solution]
**Answer:** (A)

**Type:** Main point (Chapter 18)

1. **Conclusion.** The author endorses a constrained interpretation combining linguistic content and statutory function.
2. **Support.** Paragraphs two and three assess textual and functional approaches; paragraph four provides the synthesis.
3. **Prephrase.** State the intermediate rule: more than a bare conclusion, less than a complete file.
4. **Why (A) is right.** It captures the author's precise threshold and limits, including case-specific linkage and no exhaustive duty.
5. **Why the others fail.**
   - **(B)** **Too strong:** the author rejects an entire-case-file obligation.
   - **(C)** **Priority reversal:** convenience cannot decide statutory meaning.
   - **(D)** **False dilemma:** ordinary meaning supplies the core minimum.
   - **(E)** **Format/content swap:** standardized language could work if it explains a particular denial.

**Check:** Both linguistic minimum and anti-overreach limit appear in the final paragraph.
::::
:::

:::problem[Question II.2]
According to the passage, what is the central difficulty with treating the agency's letters as sufficient merely because they state an eligibility rule?

- **(A)** The letters are not in writing and thus fail an explicit format requirement.
- **(B)** The letters omit a complete transcript of every agency deliberation.
- **(C)** Stating a rule and outcome does not necessarily explain the application of that rule to a particular applicant.
- **(D)** The letters are illegible to all applicants who receive them.
- **(E)** The eligibility rule itself has been declared invalid.

::::solution[Solution]
**Answer:** (C)

**Type:** Detail (Chapter 18)

1. **Conclusion.** The second paragraph distinguishes explanation from announcement.
2. **Support.** The letters state eligibility tests, not facts connecting those tests to individual cases.
3. **Prephrase.** Locate the ordinary-language difference between statement and explanation.
4. **Why (C) is right.** The author says an explanation makes a decision intelligible by linking rule and facts.
5. **Why the others fail.**
   - **(A)** **Direct contradiction:** the letters plainly contain writing.
   - **(B)** **Overdemand:** a transcript is not made necessary.
   - **(D)** **Unsupported universal:** no evidence about legibility is given.
   - **(E)** **Invented holding:** validity of the eligibility rule is not challenged.

**Check:** Return to paragraph two: explanation ≠ bare statement of an outcome.
::::
:::

:::problem[Question II.3]
The discussion of an interpreter demanding the “most comprehensive conceivable account” primarily serves to...

- **(A)** Prove that statutory text always has a single fixed meaning.
- **(B)** Show that the agency already supplies a complete file with every letter.
- **(C)** Deny that applicants benefit from understanding reasons for a decision.
- **(D)** Introduce an alternative interpretation the author ultimately accepts without reservation.
- **(E)** Identify a risk in relying on legislative function without respecting the limits of enacted language.

::::solution[Solution]
**Answer:** (E)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** The author warns against exaggerating purpose into an additional duty.
2. **Support.** The argument values reasons but refuses to infer exhaustive disclosure.
3. **Prephrase.** Explain why the extreme hypothetical appears between functional purpose and the final synthesis.
4. **Why (E) is right.** It is a limiting objection to unconstrained purposivism.
5. **Why the others fail.**
   - **(A)** **Too sweeping:** the passage notes genuine ambiguity.
   - **(B)** **Opposite fact:** no full file is supplied.
   - **(C)** **Reversed position:** understanding reasons is treated as important.
   - **(D)** **Attribution error:** the extreme interpretation is rejected.

**Check:** The sentence follows “functional reasoning has its own hazard.”
::::
:::

:::problem[Question II.4]
Which one of the following is most strongly supported by the author's treatment of administrative convenience?

- **(A)** Any agency with a large caseload is prohibited from using templates.
- **(B)** An agency's workload may influence how it implements an explanation duty, but cannot by itself erase that duty.
- **(C)** Administrative costs must be ignored in every legal interpretation.
- **(D)** An agency is free to substitute its operational preferences for statutory terms.
- **(E)** The Act affirmatively requires hiring additional employees before any grant denial.

::::solution[Solution]
**Answer:** (B)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Convenience can matter operationally, but does not determine meaning.
2. **Support.** Paragraph three distinguishes practical implementation from the statutory requirement.
3. **Prephrase.** Extract limited relevance, not total irrelevance or absolute priority.
4. **Why (B) is right.** This matches the express contrast between implementation and interpretive control.
5. **Why the others fail.**
   - **(A)** **Overbreadth:** templates themselves are not prohibited.
   - **(C)** **Overcorrected absolute:** costs may matter to implementation.
   - **(D)** **Opposite principle:** operational preferences do not supersede enacted requirements.
   - **(E)** **Invented remedy:** hiring is never required by the text.

**Check:** The passage: convenience is relevant to implementation, not decisive of meaning.
::::
:::

:::problem[Question II.5]
Suppose a revised standardized letter states: “Your household income was recorded as 4,200 units for the relevant month; the Act's limit for your household size is 4,000 units.” Under the author's approach, the strongest assessment would be that the letter...

- **(A)** Must fail because any standardized template is forbidden.
- **(B)** Must fail unless every internal computation is attached.
- **(C)** Must succeed even if the recorded income figure is known to be a fabrication.
- **(D)** Could satisfy the statute because it connects a specific recorded fact to the operative rule without narrating every item of evidence.
- **(E)** Is insufficient because it does not discuss whether the legislature ought to change the income threshold.

::::solution[Solution]
**Answer:** (D)

**Type:** Application (Chapter 18)

1. **Conclusion.** Apply the case-specific connection requirement.
2. **Support.** The hypothetical adds the measured fact and corresponding threshold.
3. **Prephrase.** Decide if brief reasons can be sufficient.
4. **Why (D) is right.** The text permits a short explanation identifying which factual condition was not met; the hypothetical supplies exactly that.
5. **Why the others fail.**
   - **(A)** **Format absolutism:** templates can contain individualized data.
   - **(B)** **Exhaustiveness trap:** all computations need not be reproduced.
   - **(C)** **Accuracy shell game:** a fabricated fact would not be a genuine explanation of the decision's grounds.
   - **(E)** **Policy diversion:** legislative revision is not part of an applicant-specific denial.

**Check:** Specific measured income + threshold is the intelligible connection the passage asks for.
::::
:::

:::problem[Question II.6]
Which one of the following best describes the organization of the passage?

- **(A)** It describes a historical sequence of judicial decisions ending in a binding precedent.
- **(B)** It presents a disputed practice, evaluates two interpretive approaches and their limits, then defends a bounded synthesis.
- **(C)** It lists the technical steps by which agencies calculate grant amounts.
- **(D)** It proposes abolishing explanation requirements after reviewing their costs.
- **(E)** It compares several enacted statutes and ranks their enforcement agencies.

::::solution[Solution]
**Answer:** (B)

**Type:** Organization (Chapter 18)

1. **Conclusion.** The passage advances a synthesized interpretive position.
2. **Support.** Opening problem, ordinary-language reasoning, purpose plus hazard, qualified resolution.
3. **Prephrase.** Follow paragraph transitions, not mere topic labels.
4. **Why (B) is right.** Each stage directly corresponds to the four-paragraph structure.
5. **Why the others fail.**
   - **(A)** **Invented history:** no judicial holdings appear.
   - **(C)** **Wrong genre:** grant calculation details are not the subject.
   - **(D)** **Conclusion reversal:** the author defends meaningful explanations.
   - **(E)** **Scope expansion:** only one fictional statute and agency are considered.

**Check:** Paragraph map: scenario → text → purpose and risk → combined standard.
::::
:::

:::problem[Question II.7]
The author's attitude toward interpretations that require production of an entire agency case file is most accurately described as...

- **(A)** Supportive because the author thinks any detail serves legislative function.
- **(B)** Indifferent because the author finds the meaning of explanation unknowable.
- **(C)** Hostile to any applicant receiving additional information voluntarily.
- **(D)** Skeptical because they risk adding an obligation not grounded in the statutory wording.
- **(E)** Confident that the legislature expressly forbade full-file disclosure.

::::solution[Solution]
**Answer:** (D)

**Type:** Author attitude (Chapter 18)

1. **Conclusion.** The author refuses to mandate exhaustive disclosure.
2. **Support.** Paragraphs three and four warn against stretching the text.
3. **Prephrase.** Match skepticism toward imposed duty without claiming voluntary disclosure prohibited.
4. **Why (D) is right.** The passage calls the full-file demand an unwarranted conversion of a modest requirement.
5. **Why the others fail.**
   - **(A)** **Overstated purposivism:** the author rejects limitless function-based duties.
   - **(B)** **False agnosticism:** author offers a workable definition.
   - **(C)** **Conflation:** legal minimum does not limit voluntary information.
   - **(E)** **Fabricated prohibition:** silence about format is not an express ban.

**Check:** Author opposes making file disclosure mandatory, not disclosure itself.
::::
:::

### Passage 2

A materials laboratory seeking longer-lived protective coatings has been experimenting with capsules that contain a liquid resin. The capsules are embedded within a solid coating. When a crack intersects a capsule, the capsule can rupture and release resin into part of the opening; after the resin hardens, the crack may become less permeable to water. This mechanism is attractive because it does not require a worker to locate and treat every microscopic crack. It can act only where cracks actually encounter capsules, however; a capsule untouched by a crack contributes no resin to that opening. Yet the word “healed” invites a misleading inference: preventing water from passing through a crack is not the same as restoring all the mechanical strength that the original uncracked coating possessed.

Consider a hypothetical experiment with three coatings placed on identically prepared panels. Coating R contains a high density of resin capsules, coating S contains fewer capsules, and coating T contains none. After researchers impose comparable small cracks, both capsule-bearing coatings show lower water permeability than T. R initially appears best: its average post-crack permeability is lowest. A simple ranking would recommend R. But tests on intact panels reveal that R also has more initiation sites for mechanical failure. Some capsules behave like discontinuities in the solid matrix, so adding capsules may help a damaged coating seal while leaving an undamaged coating more susceptible to cracking under certain stresses.

The investigators then alter the test protocol. Instead of testing permeability after one controlled crack, they subject the panels to repeated loading and wetting cycles. Coating R's apparent advantage diminishes. Microscopic inspection in this hypothetical experiment suggests that a few early cracks exhaust nearby capsules, leaving later cracks without fresh resin. Coating S, although less effective after the first crack, retains sufficient unused capsules across a larger fraction of the surface. The investigators cannot infer from this result that a lower capsule density is universally better. The spatial distribution of capsules and the pattern of cracking may be as important as the total number of capsules.

These findings expose a problem with treating any single measurement as a verdict on self-repair. Water permeability measures a barrier function; a strength test probes the coating's response to load; and repeated-cycle testing asks whether its protective effect persists. None is a perfect proxy for the others. A ranking derived under one loading history might therefore be accurate for that test and misleading when transferred to another use. For a pipe coating exposed mainly to intermittent moisture, post-crack sealing might dominate the choice. For a structural component subject to repeated stress, loss of intact strength or exhaustion of capsules could matter more. Selecting a formulation therefore requires matching evidence to the expected failure mode, rather than announcing that the coating with the greatest first-cycle sealing performance is simply the most durable.


:::problem[Question II.8]
Which one of the following most accurately states the main point of the passage?

- **(A)** A coating with the highest capsule density is always the safest choice.
- **(B)** Measuring water permeability is scientifically useless for protective coatings.
- **(C)** Repeated loading proves that capsule systems cannot provide any practical benefit.
- **(D)** Every capsule-containing material recovers its original mechanical strength after cracking.
- **(E)** Evaluating capsule-based crack-sealing coatings requires comparing distinct performance measures under conditions relevant to their intended use.

::::solution[Solution]
**Answer:** (E)

**Type:** Main point (Chapter 18)

1. **Conclusion.** No one metric, particularly first-cycle sealing, establishes overall suitability.
2. **Support.** Three formulations and tests reveal trade-offs between barrier performance, strength and persistence.
3. **Prephrase.** Choose evaluation suited to failure mode, not universal ranking.
4. **Why (E) is right.** It summarizes the experiments and the final design recommendation.
5. **Why the others fail.**
   - **(A)** **Overgeneralization:** R has disadvantages under some tests.
   - **(B)** **Overcorrected dismissal:** permeability measures an important function.
   - **(C)** **Extreme negation:** repeated tests reveal limits, not universal uselessness.
   - **(D)** **False equivalence:** sealing is explicitly distinct from strength restoration.

**Check:** The final paragraph names separate measures and insists on application-specific testing.
::::
:::

:::problem[Question II.9]
According to the passage, the capsules are intended to reduce water permeability primarily by...

- **(A)** Releasing a liquid resin into cracks that intersect capsules, where it can harden.
- **(B)** Increasing the thickness of every panel after a crack forms.
- **(C)** Preventing any crack from ever forming in the solid coating.
- **(D)** Absorbing all water passing through the coating into the capsule shell.
- **(E)** Making intact coatings completely immune to mechanical stress.

::::solution[Solution]
**Answer:** (A)

**Type:** Detail (Chapter 18)

1. **Conclusion.** Microcapsules can release resin at intersection with cracks.
2. **Support.** First paragraph states rupture, flow into crack and hardening.
3. **Prephrase.** Follow the physical sequence described.
4. **Why (A) is right.** The passage explicitly describes this barrier-restoration mechanism.
5. **Why the others fail.**
   - **(B)** **Added process:** thickening is not the mechanism stated.
   - **(C)** **Absolute prevention:** cracks are required to trigger release.
   - **(D)** **Mechanism swap:** resin fills cracks rather than shells absorbing all water.
   - **(E)** **Mechanical overreach:** capsules can reduce intact strength.

**Check:** Crack meets capsule → rupture → resin enters opening → hardens.
::::
:::

:::problem[Question II.10]
Which one of the following is most strongly supported by the hypothetical results from the repeated-cycle experiment?

- **(A)** Coating T has the lowest permeability under every possible testing protocol.
- **(B)** Coating R contains no resin after a single crack is imposed.
- **(C)** The formulation that best resists water flow immediately after a first crack need not remain best after additional cracking.
- **(D)** Coating S will outperform every other formulation in all structural uses.
- **(E)** The researchers demonstrated that capsule size alone determines long-term durability.

::::solution[Solution]
**Answer:** (C)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Different tests may reverse an initial preference.
2. **Support.** R leads initially but advantage diminishes under repetitions; S retains unused capsules.
3. **Prephrase.** Infer nonidentity of one-time performance and longer-term performance.
4. **Why (C) is right.** The comparison expressly supplies an instance where initial advantage weakens on cycling.
5. **Why the others fail.**
   - **(A)** **Wrong direction:** T had higher permeability after controlled cracks.
   - **(B)** **All-or-none trap:** only nearby capsules may be exhausted.
   - **(D)** **Unjustified universality:** authors reject universal density rule.
   - **(E)** **Single-variable attribution:** capsule distribution and crack patterns also matter.

**Check:** First-cycle ordering does not guarantee repeated-cycle ordering.
::::
:::

:::problem[Question II.11]
The reference to capsules as “discontinuities in the solid matrix” primarily serves to...

- **(A)** Demonstrate that the researchers accidentally used different panel substrates.
- **(B)** Show that water permeability and mechanical strength are identical measurements.
- **(C)** Prove that resin capsules never break when intersected by a crack.
- **(D)** Establish that the most numerous capsules are always the most evenly distributed.
- **(E)** Explain why an addition beneficial to crack sealing might impair a different property of the coating.

::::solution[Solution]
**Answer:** (E)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** The account introduces trade-off between healing and intact strength.
2. **Support.** R improves sealing but initiates failures in intact panel tests.
3. **Prephrase.** Explain why the microstructural sentence appears after the ranking of R.
4. **Why (E) is right.** It provides a plausible mechanism for R's mechanical disadvantage.
5. **Why the others fail.**
   - **(A)** **Unmentioned experimental error:** substrates were identically prepared.
   - **(B)** **Conflation:** the text distinguishes these measures.
   - **(C)** **Opposite mechanism:** rupture is essential to the strategy.
   - **(D)** **Density/distribution swap:** number does not ensure uniform placement.

**Check:** Second paragraph pivots from best permeability to weaker intact performance.
::::
:::

:::problem[Question II.12]
Suppose a designer needs a coating mainly to exclude occasional moisture but expects very little repeated mechanical stress. Which decision best follows the author's framework?

- **(A)** Ignore water permeability because it is not a measure of tensile strength.
- **(B)** Choose coating R solely because its capsule count is highest.
- **(C)** Use repeated-cycle results as the only permissible evidence.
- **(D)** Place relatively greater weight on post-crack sealing tests while still checking that the coating meets minimum strength requirements.
- **(E)** Assume a capsule-free coating cannot ever protect against moisture.

::::solution[Solution]
**Answer:** (D)

**Type:** Application (Chapter 18)

1. **Conclusion.** Application decides which property matters, not whether others disappear.
2. **Support.** Final paragraph contrasts moisture-dominated and repeated-stress-dominated cases.
3. **Prephrase.** Emphasize permeability for intended duty but retain checks against weaknesses.
4. **Why (D) is right.** This balances use-specific relevance with the documented distinct performance dimensions.
5. **Why the others fail.**
   - **(A)** **Metric confusion:** moisture resistance directly concerns permeability.
   - **(B)** **Single-number shortcut:** higher density carries potential strength cost.
   - **(C)** **Universal test rule:** stress cycling need not dominate intermittent moisture service.
   - **(E)** **Overstatement:** even T was a coating; its protection is not shown to be zero.

**Check:** Pipe-coating example explicitly gives sealing more weight for intermittent moisture.
::::
:::

:::problem[Question II.13]
The author would most likely regard the statement “R is the most durable formulation because it seals best after one crack” as...

- **(A)** Precisely established by the laboratory's first experiment.
- **(B)** Unjustifiably broad, since performance after one crack does not settle strength or persistence under repeated exposure.
- **(C)** Invalid only because the panels were not identically prepared.
- **(D)** Correct for every use except where costs are considered.
- **(E)** A conclusive proof that coating S has no useful properties.

::::solution[Solution]
**Answer:** (B)

**Type:** Author attitude (Chapter 18)

1. **Conclusion.** Author warns that first-cycle sealing cannot settle durability.
2. **Support.** R later shows initiation sites and advantage loss under cycles.
3. **Prephrase.** Evaluate claim strength against the multiple tests.
4. **Why (B) is right.** The inference elevates one barrier measurement into a universal durability ranking.
5. **Why the others fail.**
   - **(A)** **Ignores later evidence:** first experiment assessed one dimension.
   - **(C)** **Contradiction:** panels were identical in preparation.
   - **(D)** **Invented exception:** cost is not the only further factor.
   - **(E)** **Opposite result:** S retains unused capsules and has a distinct advantage.

**Check:** The passage explicitly rejects “most durable” from greatest first-cycle sealing.
::::
:::

### Passage 3 (comparative)

**Passage A**

Suppose two hypothetical cities report very different annual rates of emergency medical visits. One city has a substantially older population, while the other has recently attracted many younger residents. A simple comparison of visits divided by total population can confuse differences in age composition with differences in the likelihood that similarly aged residents seek emergency care. A demographer seeking to compare underlying rates might therefore calculate age-specific visit rates and apply each city's rates to the same reference age distribution. This age-standardized comparison does not describe either city's actual number of visits; instead, it answers a deliberately artificial but useful question: what would their overall rates look like if the age distributions were held constant?

Some critics object that a hypothetical population is too detached from reality to guide any decision. That criticism misses the distinction between measurement and prediction. An age-standardized rate is not a forecast of next year's hospital workload. It is a diagnostic device for separating composition from age-specific behavior or circumstances. Where the policy question is whether one city has an unusually high visit rate after accounting for residents' ages, ignoring composition can attribute to service conditions a difference driven by population structure. The standardized comparison is indispensable for that particular inference, though it cannot tell an administrator how many beds to staff. A difference that survives the adjustment also calls for explanation rather than immediate attribution to any single institutional cause.

**Passage B**

Age-standardized rates can clarify comparisons, but policy analysts often give them a prominence that obscures the quantities local administrators must actually manage. A city's older population is not a statistical inconvenience to be removed from its budget: it is a real feature of the people who require services. If a city's actual visits are rising because the number of older residents is increasing, the added workload is not made less real by a stable age-standardized rate. For staffing and facility planning, analysts must examine projected populations and age-specific demand, then reconstruct expected visit counts rather than treating the standardized figure as the final answer.

This argument is not a defense of crude rates as measures of service quality. A high crude visit rate can arise from composition rather than anything that hospitals do differently, and a standardized rate helps prevent that mistake. The problem comes when analysts slide from “the difference disappears after standardization” to “the difference needs no operational response.” The first is a statement about a constructed comparison; the second concerns actual patients. Good demographic analysis should report both kinds of information and state clearly which question each answers. In particular, a budget memo should not substitute a comparison adjusted for population age for an estimate that reflects the residents who will actually seek care. Removing composition may be appropriate for diagnosing a difference, while retaining composition is essential when estimating the care a population will need.


:::problem[Question II.14]
The relationship between the main points of passages A and B is best described as which one of the following?

- **(A)** Both accept age standardization for comparing underlying rates, while B emphasizes a policy use for actual population composition that A expressly distinguishes from comparison.
- **(B)** A says standardization cannot compare rates, while B says it is the only reliable way to forecast hospital visits.
- **(C)** A attributes all variation to age, while B denies that age ever changes service use.
- **(D)** Both argue that crude rates alone provide adequate measures of hospital quality.
- **(E)** B rejects the analytic usefulness of reference populations altogether.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** Both defend distinct uses of two metrics.
2. **Support.** A calls standardization diagnostic not forecast; B calls it useful but insufficient for planning.
3. **Prephrase.** Pin shared endorsement and different emphasis.
4. **Why (A) is right.** A restricts its argument to underlying-rate comparison; B stresses operational counts and warns against conflation.
5. **Why the others fail.**
   - **(B)** **Positions reversed:** A champions comparison; B rejects standardized forecasts, not their comparison use.
   - **(C)** **Extreme attribution:** neither makes an all-or-none age claim.
   - **(D)** **Shared rejection:** both reject crude rates as standalone quality measures.
   - **(E)** **Straw opposition:** B explicitly says standardization can clarify comparisons.

**Check:** Both separate diagnostic rates from staffing or visit-count prediction.
::::
:::

:::problem[Question II.15]
Both authors would most likely agree with which one of the following?

- **(A)** Age-standardized rates always predict the number of patients a hospital will see next year.
- **(B)** Age-specific rates are never useful for municipal planning.
- **(C)** A high crude visit rate does not by itself establish that a city has worse service conditions than another city.
- **(D)** Two cities with different crude rates must have identical age-specific rates.
- **(E)** Comparisons between cities should ignore residents' ages entirely.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative agreement (Chapter 17)

1. **Conclusion.** Both object to treating crude population rates as direct indicators of service conditions.
2. **Support.** A calls age composition a confound; B says crude high rate can reflect composition.
3. **Prephrase.** Seek a common explicit caution, not universal claims.
4. **Why (C) is right.** Each author rejects inference from crude differences to hospitals' performance.
5. **Why the others fail.**
   - **(A)** **Opposite of both:** standardized rates are not forecasts.
   - **(B)** **Opposite of B:** B wants age-specific demand for projected counts.
   - **(D)** **Unsupported equality:** age-specific rates could also differ.
   - **(E)** **Overgeneralized omission:** both consider age essential to correct analysis.

**Check:** A and B both say crude differences may be compositional.
::::
:::

:::problem[Question II.16]
The passages most clearly differ in the emphasis they place on which one of the following?

- **(A)** Whether age composition can influence crude visit rates at all.
- **(B)** The risk that analytically removing age composition will be mistaken for removing a real operational burden.
- **(C)** Whether a reference population is constructed rather than the city's actual population.
- **(D)** Whether hospitals provide emergency medical services.
- **(E)** Whether age-specific rates can be combined with population counts to forecast visits.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** Find a difference of concern rather than an outright factual contradiction.
2. **Support.** A anticipates misuse by differentiating diagnosis and forecasts; B foregrounds precisely that misuse.
3. **Prephrase.** B focuses on operational inference A mainly sets aside.
4. **Why (B) is right.** B's warning is the dominant theme and is present in A only as a scope distinction.
5. **Why the others fail.**
   - **(A)** **Shared premise:** both say composition affects crude rates.
   - **(C)** **Shared definition:** both know reference age distributions are hypothetical.
   - **(D)** **Background fact:** service type is not disputed.
   - **(E)** **Only B elaborates:** A does not reject using counts and rates for workload.

**Check:** An emphasis question need not imply incompatible factual beliefs.
::::
:::

:::problem[Question II.17]
Passage A most strongly supports which one of the following?

- **(A)** An age-standardized rate is meaningless unless the cities have identical age distributions.
- **(B)** The city with more older residents will necessarily have poorer medical services.
- **(C)** Applying a common reference age distribution eliminates all possible confounding differences.
- **(D)** A standardized comparison can be useful precisely because it does not represent either city's actual population composition.
- **(E)** Forecasts based on actual visit counts must be statistically invalid.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative inference (Chapter 17)

1. **Conclusion.** A seeks an artificial controlled comparison.
2. **Support.** Common reference distribution removes one compositional source from rate comparison.
3. **Prephrase.** Recognize a deliberate abstraction with narrow interpretive value.
4. **Why (D) is right.** Holding age composition constant is the reason the rate comparison isolates an age component.
5. **Why the others fail.**
   - **(A)** **Reverse purpose:** the method is useful when actual age distributions differ.
   - **(B)** **Quality leap:** older age composition does not establish inferior care.
   - **(C)** **Too strong:** standardization only controls age, not every factor.
   - **(E)** **Different task:** forecasts remain useful for workloads.

**Check:** Passage A calls the reference distribution artificial but useful.
::::
:::

:::problem[Question II.18]
Suppose a city's age-standardized visit rate stays constant while the number of older residents and total emergency visits rise. Which response would passage B most likely endorse?

- **(A)** Conclude that emergency departments will face no increase in workload.
- **(B)** Ignore age-specific information because crude rates are easier to calculate.
- **(C)** Use the standardized rate alone to calculate the exact number of future visits.
- **(D)** Attribute the change solely to a deterioration in hospital quality.
- **(E)** Plan for increased capacity using projected populations and age-specific demand, notwithstanding the stable standardized rate.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative application (Chapter 17)

1. **Conclusion.** B distinguishes controlled-rate constancy from growing total demand.
2. **Support.** A more populous older group generates actual service counts despite stable standardization.
3. **Prephrase.** Do not treat constancy of a constructed metric as constancy of workload.
4. **Why (E) is right.** B explicitly says the workload remains real and calls for reconstructing counts.
5. **Why the others fail.**
   - **(A)** **Metric substitution:** stable standardized rate need not mean stable count.
   - **(B)** **Opposite method:** B calls for age-specific projections.
   - **(C)** **Insufficient data:** standardized rate alone cannot determine actual count.
   - **(D)** **Causal overreach:** population composition is a provided alternative.

**Check:** Actual workload and age-standardized rate answer different questions.
::::
:::

:::problem[Question II.19]
How would the author of passage A most likely respond to B's statement that an older population “is not a statistical inconvenience to be removed from its budget”?

- **(A)** Agree that actual age composition matters for budgeting, while maintaining that standardization serves a different diagnostic question.
- **(B)** Reject the statement because older residents should never count in resource planning.
- **(C)** Insist that a standardized rate directly gives the number of beds a hospital requires.
- **(D)** Claim that age-specific rates can be measured only in younger populations.
- **(E)** Agree only if crude rates are treated as conclusive measures of service quality.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative author response (Chapter 17)

1. **Conclusion.** A grants the practical point but preserves diagnostic distinction.
2. **Support.** A says standardization cannot tell how many beds to staff.
3. **Prephrase.** Find qualified agreement without conflating tasks.
4. **Why (A) is right.** The remark matches A's own explicit limitation of standardized rates.
5. **Why the others fail.**
   - **(B)** **Fabricated hostility:** A does not discount older residents.
   - **(C)** **Explicit contradiction:** A denies staffing predictions from standardized rates alone.
   - **(D)** **Unstated exclusion:** A uses age-specific rates across the age distribution.
   - **(E)** **Opposite caveat:** A warns crude rates can mislead about conditions.

**Check:** A explicitly distinguishes diagnostic measurement from predicting next year's workload.
::::
:::

:::problem[Question II.20]
In passage B, the contrast between “the difference disappears after standardization” and “the difference needs no operational response” serves primarily to...

- **(A)** Claim that standardized calculations cannot be performed correctly.
- **(B)** Offer two expressions the author treats as logically equivalent.
- **(C)** Expose an invalid transition from an adjusted comparative result to a decision about actual service demand.
- **(D)** Show that cities should never compare medical visit rates.
- **(E)** Prove that population projections are immune to error.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative function (Chapter 17)

1. **Conclusion.** B attacks sliding from diagnostic rate to practical implication.
2. **Support.** The first is a constructed comparison; the second claims no actual workload issue.
3. **Prephrase.** Identify leap between measures and decisions.
4. **Why (C) is right.** The author explicitly names the first a metric statement and the second a statement about patients.
5. **Why the others fail.**
   - **(A)** **Method repudiation:** B accepts the calculations.
   - **(B)** **Opposite relationship:** the author contrasts rather than equates claims.
   - **(D)** **Total rejection:** intercity comparisons are still worthwhile.
   - **(E)** **Unfounded certainty:** forecast accuracy is not asserted.

**Check:** The two quoted statements are explicitly differentiated immediately afterward.
::::
:::

### Passage 4

Consider an imagined exhibition of six tall sculptural frames arranged along a narrow gallery. Each frame contains an irregular opening rather than a carved figure. From a marked position near the entrance, the openings align to make what resembles a continuous ring. Visitors who move toward the final frame find that the ring dissolves into disjointed fragments. A curatorial label describes the sequence as a celebration of lost unity: it says the artist invites spectators to glimpse a complete order and then mourn its disappearance. This account is attractive because the initial alignment is striking and the subsequent fragmentation is easy to experience. Its simplicity also makes it easy to repeat in an exhibition catalogue, where the still photograph of the entrance view cannot show how the work changes as a person walks.

But the label's vocabulary of loss assumes that the view from the entrance deserves priority over every later view. Nothing in the arrangement itself establishes that hierarchy. A spectator approaching from the gallery's far end encounters discontinuity first and discovers the apparent ring only after walking backward. Others pause beside individual frames and notice not a broken circle but a shifting division of light and shadow across the floor. The works do not simply alternate between one complete image and its degradation; their relationships change continuously with position. The curatorial story turns a provisional vantage point into an original condition from which all others are treated as decline.

An alternative reading emphasizes how the installation distributes authorship of the visible form between constructed objects and moving observers. The frames remain stationary, but their relationships are repeatedly made and unmade by visitors' routes. The result is neither a completely private visual invention nor a message delivered intact to a passive audience; it arises from the encounter between a fixed arrangement and an observer occupying a particular place. This is not to say that viewers can produce absolutely any meaning they wish. The openings have definite dimensions, and the gallery constrains where observers may stand. Indeed, the near-ring alignment is possible only along a narrow set of sightlines. The work's invitation to participate is therefore structured, not unlimited; it depends on material restrictions that make some encounters likely and others impossible.

Nor does the alternative reading prove that the curator's theme of loss is illegitimate. A visitor who sees the ring first can reasonably experience its dissolution as poignant. The mistake is to treat that experience as the sculpture's necessary message rather than one route through a field of possible perceptions. The same sequence can make another visitor feel the pleasure of discovering an order that had not initially been visible. The most productive criticism, then, would resist identifying a privileged image with the work's true form. Its achievement lies less in delivering a fixed symbol of unity than in making visitors notice the conditions under which something seems unified at all.


:::problem[Question II.21]
Which one of the following most accurately expresses the main point of the passage?

- **(A)** The curator's interpretation is demonstrably false for every spectator.
- **(B)** The installation is better understood as exposing how shifting viewpoints construct perceptions of unity than as conveying only the loss of an originally complete form.
- **(C)** The sculpture celebrates the superiority of two-dimensional images over moving objects.
- **(D)** All interpretations of an artwork are equally defensible if a viewer sincerely holds them.
- **(E)** The arrangement was intended to conceal the ring alignment from every visitor.

::::solution[Solution]
**Answer:** (B)

**Type:** Main point (Chapter 18)

1. **Conclusion.** The author favors a positional, constrained account while allowing loss as one experience.
2. **Support.** Entrance ring, shifting views, constrained agency, qualified critique of curatorial label.
3. **Prephrase.** Find the alternative reading with caveat, not a total rejection.
4. **Why (B) is right.** The answer captures viewpoint-dependent unity and rejects a single fixed loss narrative.
5. **Why the others fail.**
   - **(A)** **Overstatement:** the author explicitly permits a loss reading.
   - **(C)** **Invented hierarchy:** medium comparison is never made.
   - **(D)** **Unlimited relativism:** material constraints restrict possible views.
   - **(E)** **Contradiction:** entrance alignment is striking and accessible.

**Check:** Final sentence emphasizes conditions under which forms seem unified.
::::
:::

:::problem[Question II.22]
The author suggests that the curatorial interpretation depends especially on which one of the following assumptions?

- **(A)** All gallery visitors follow exactly the same walking route.
- **(B)** Light and shadow do not change across the gallery.
- **(C)** The frames must have been carved from a single continuous piece.
- **(D)** The gallery has no restrictions on where visitors may stand.
- **(E)** The alignment visible near the entrance should be treated as the work's primary or original state.

::::solution[Solution]
**Answer:** (E)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Critique targets privileged starting perspective.
2. **Support.** Curator labels subsequent fragmentation as loss from unity.
3. **Prephrase.** Identify what must be presupposed to call other views declines.
4. **Why (E) is right.** The second paragraph says the loss account assumes priority of entrance view.
5. **Why the others fail.**
   - **(A)** **Overstrong behavioral condition:** many may take other routes; the label still has its narrative.
   - **(B)** **Direct contradiction:** moving shadow is discussed.
   - **(C)** **Material invention:** nothing indicates a single carved piece.
   - **(D)** **Opposite constraint:** physical layout restricts vantage points.

**Check:** To describe later views as lost unity, entrance alignment must count as initial wholeness.
::::
:::

:::problem[Question II.23]
The author mentions a visitor approaching from the far end primarily in order to...

- **(A)** Demonstrate that the artist intended visitors to ignore the entrance.
- **(B)** Prove that the far end gives the only objectively correct interpretation.
- **(C)** Suggest that gallery lighting fails to meet safety standards.
- **(D)** Show that reversing a viewing route can reverse the apparent sequence from fragmentation to unity.
- **(E)** Establish that the ring cannot be perceived by anyone who moves through the gallery.

::::solution[Solution]
**Answer:** (D)

**Type:** Function of a part (Chapter 18)

1. **Conclusion.** Route changes the temporal story.
2. **Support.** A far-end spectator sees fragments before a ring.
3. **Prephrase.** Use example as counterexample to privileged beginning.
4. **Why (D) is right.** If progression reverses, the curatorial order of loss cannot be obligatory.
5. **Why the others fail.**
   - **(A)** **Author-intent invention:** no instruction to ignore entrance is supplied.
   - **(B)** **Replacement dogma:** critic refuses any sole privileged viewpoint.
   - **(C)** **Off-topic safety:** lighting affects visual reading, not hazard compliance.
   - **(E)** **Contradiction:** the far-end visitor eventually discovers the ring.

**Check:** The same frames yield loss or discovery depending on direction.
::::
:::

:::problem[Question II.24]
According to the passage, the viewer's role in constructing the work's visible relationships is limited by...

- **(A)** The fixed dimensions of the openings and the gallery's restrictions on accessible vantage points.
- **(B)** A rule requiring every visitor to stand only at the entrance marker.
- **(C)** The absence of any geometry relating the sculptural frames.
- **(D)** The curator's power to change the frames during each visit.
- **(E)** The fact that every opening is precisely circular.

::::solution[Solution]
**Answer:** (A)

**Type:** Detail (Chapter 18)

1. **Conclusion.** Participation is structured rather than limitless.
2. **Support.** Third paragraph identifies opening dimensions and permitted positions.
3. **Prephrase.** Find the physical limits on interpretation.
4. **Why (A) is right.** The text explicitly cites both geometry and gallery constraints.
5. **Why the others fail.**
   - **(B)** **Exaggerated restriction:** visitors can move along multiple routes.
   - **(C)** **Denies structure:** specific alignment depends on geometry.
   - **(D)** **Invented motion:** frames are stationary.
   - **(E)** **False geometry:** openings are irregular.

**Check:** “Definite dimensions” and constrained standing places appear together.
::::
:::

:::problem[Question II.25]
Suppose another installation forms the image of a square only when seen from a balcony; from the floor it resembles intersecting lines. Which criticism would the passage's author most likely favor?

- **(A)** The work must be aesthetically worthless because it lacks one view shared by all spectators.
- **(B)** The artist intended a square even if no source mentions intention.
- **(C)** An account that calls the floor view a failed square needs justification for privileging the balcony view.
- **(D)** No one can rationally perceive a square because other views exist.
- **(E)** The floor view alone must be recognized as the true artwork.

::::solution[Solution]
**Answer:** (C)

**Type:** Application (Chapter 18)

1. **Conclusion.** The author resists unquestioned hierarchy of positions.
2. **Support.** Entrance viewpoint is not established as original; multiple readings are constrained by forms.
3. **Prephrase.** Ask which view is unfairly made norm without a reason.
4. **Why (C) is right.** Treating floor view as failed requires a special status for balcony vantage, exactly the queried assumption.
5. **Why the others fail.**
   - **(A)** **Aesthetic overreach:** multiplicity is not shown to reduce worth.
   - **(B)** **Intent invention:** perceptual geometry does not prove intended symbolism.
   - **(D)** **Exclusive negation:** square perception may be valid from balcony.
   - **(E)** **Reverse dogma:** author rejects privileging any view without argument.

**Check:** Balcony is analogous to entrance ring; floor analogous to later fragments.
::::
:::

:::problem[Question II.26]
The author's attitude toward the curatorial interpretation is best described as...

- **(A)** Unqualified dismissal because no one could experience loss in this installation.
- **(B)** Complete endorsement because the entrance view is objectively supreme.
- **(C)** Indifference because art criticism has no standards of evidence.
- **(D)** Approval only insofar as the curator introduces biographical facts about the artist.
- **(E)** Qualified disagreement: the interpretation can capture a genuine experience but is too restrictive when treated as the work's necessary meaning.

::::solution[Solution]
**Answer:** (E)

**Type:** Author attitude (Chapter 18)

1. **Conclusion.** The critique is qualified, not absolute.
2. **Support.** Final paragraph calls loss reasonable for some and rejects its monopoly.
3. **Prephrase.** Preserve both concession and objection.
4. **Why (E) is right.** It matches “not illegitimate” and “mistake ... necessary message.”
5. **Why the others fail.**
   - **(A)** **Ignores concession:** some visitors can feel poignant dissolution.
   - **(B)** **Contradiction:** no view has proven supremacy.
   - **(C)** **Relativism trap:** author uses geometry and route evidence.
   - **(D)** **Invented evidence:** artist biography is absent.

**Check:** Author allows the experience but disputes its universality.
::::
:::

:::problem[Question II.27]
Which one of the following best describes the structure of the passage?

- **(A)** It begins with artist biography, then traces the work's sale history.
- **(B)** It presents an appealing interpretation, challenges an assumption underlying it, proposes a constrained alternative, and preserves a limited version of the original interpretation.
- **(C)** It describes a scientific experiment and concludes that every observer sees the same image.
- **(D)** It lists six independent sculptures without considering their relationships.
- **(E)** It rejects both curatorial and visitor perspectives in favor of the artist's private notes.

::::solution[Solution]
**Answer:** (B)

**Type:** Organization (Chapter 18)

1. **Conclusion.** Author replaces exclusive loss symbolism with positional reading but concedes one valid route.
2. **Support.** Paragraphs: label; counterexample via route; relational alternative and bounds; concession plus thesis.
3. **Prephrase.** Map pivot and qualification.
4. **Why (B) is right.** All four stages match the actual argumentative sequence.
5. **Why the others fail.**
   - **(A)** **Invented history:** no biography or market history occurs.
   - **(C)** **Wrong result:** variable views are essential to the passage.
   - **(D)** **Whole/part confusion:** relationships between frames are the focus.
   - **(E)** **No private notes:** author does not appeal to artist intention.

**Check:** P1 claim → P2 critique → P3 alternative → P4 qualification.
::::
:::

## 38.3 Section III: Logical Reasoning

:::problem[Question III.1]
A hypothetical pharmacy orders a temperature-sensitive medicine from one of two suppliers. Whenever the primary supplier ships a batch, the pharmacy receives a tracking notice before delivery. If a shipment comes from the backup supplier, the pharmacy receives a refrigerated-container certificate before it is released to the courier. Last Thursday the pharmacy received neither a tracking notice nor a certificate, although it did receive a shipment of the medicine. The pharmacy's log records that the shipment was delivered through an emergency local exchange rather than through either supplier.

Which one of the following statements must be true on the basis of the information given?

- **(A)** No shipments from the primary supplier were ever delayed by the courier.
- **(B)** The emergency local exchange was cheaper than either supplier.
- **(C)** Last Thursday's shipment did not come through either of the two ordinary supplier procedures described.
- **(D)** All medicine received by the pharmacy has a refrigerated-container certificate.
- **(E)** The pharmacy placed no medicine orders during the previous week.

::::solution[Solution]
**Answer:** (C)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** Classify Thursday's delivered batch relative to stated procedures.
2. **Support.** Primary supplier guarantees notice; backup guarantees certificate; neither document was received and exchange is given.
3. **Prephrase.** Use the negative evidence to exclude the two standard channels.
4. **Why (C) is right.** No notice excludes primary and no certificate excludes backup; the log independently identifies an emergency exchange.
5. **Why the others fail.**
   - **(A)** **Temporal leap:** no evidence about other days' delays.
   - **(B)** **Cost invention:** price is absent from the facts.
   - **(D)** **Overgeneralization:** the Thursday exchange lacks a certificate.
   - **(E)** **Order/delivery confusion:** absence of documentation says nothing about earlier orders.

**Check:** Primary → notice and backup → certificate; neither notice nor certificate occurred Thursday.
::::
:::

:::problem[Question III.2]
In a hypothetical town, a public-garden board generally prohibits removing mature trees. It makes an exception when a tree poses an imminent safety danger that cannot be adequately addressed by pruning or temporary barriers. An inspector recommends removal of a mature tree because a cracked limb hangs over a frequently used path. An arborist reports that the limb can be removed safely without taking down the tree, and the board rejects the inspector's recommendation. A resident claims that any visible hazard should automatically justify complete removal.

Which one of the following principles is most consistent with the board's decision?

- **(A)** All mature trees must be preserved even when no action can prevent serious injury.
- **(B)** An inspector's safety opinion must always prevail over an arborist's advice.
- **(C)** Removing any hazardous limb is prohibited if the tree is mature.
- **(D)** Temporary barriers should be used even where they cannot reduce risk adequately.
- **(E)** A broad protective rule should yield to a safety exception only when the narrower alternatives cannot adequately address the danger.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Removal is not warranted when safe limb removal addresses the threat.
2. **Support.** Exception requires danger that cannot be addressed by narrower measures; pruning is available.
3. **Prephrase.** Match necessity of the exception, not hazard alone.
4. **Why (E) is right.** Adequate limb removal defeats the exception's second condition, preserving the default protection.
5. **Why the others fail.**
   - **(A)** **Absolute rule:** the town explicitly recognizes dangerous exceptions.
   - **(B)** **Authority swap:** the board resolves by available alternatives, not an official's rank.
   - **(C)** **Overrestriction:** removing a limb is the offered solution.
   - **(D)** **Ineffective-means trap:** exception requires adequate measures, not any barrier regardless of efficacy.

**Check:** Danger AND no adequate alternative are required; adequate pruning blocks tree removal.
::::
:::

:::problem[Question III.3]
At a hypothetical mountain observatory, researchers estimate that their newly installed protective dome reduced optical distortion. They compare images of a reference star taken during the month before installation with images taken the following month, finding narrower apparent star profiles afterward. The dome was installed to block windblown dust, so researchers infer that reduced dust exposure caused the improvement. However, the telescope's internal focus-control software was also replaced during installation, and no images were recorded with the old software inside the new dome.

Which one of the following, if true, most weakens the inference about the dome?

- **(A)** The telescope's new dome was built from a stronger metal than the old one.
- **(B)** Reprocessing the earlier images with the new focus-control corrections produces profiles as narrow as the later images.
- **(C)** Windblown dust sometimes accumulates on observatory equipment.
- **(D)** The researchers intend to use the telescope for objects other than stars.
- **(E)** Other observatories are considering protective domes for unrelated reasons.

::::solution[Solution]
**Answer:** (B)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The dome's dust shielding caused the improved profiles.
2. **Support.** Profiles narrowed after installation, but focusing software also changed.
3. **Prephrase.** Show the software alone explains before/after profile change.
4. **Why (B) is right.** New processing equalizes earlier and later observations without changing historical dust exposure, indicating the software corrections account for the improvement.
5. **Why the others fail.**
   - **(A)** **Material diversion:** structural strength does not isolate optical change.
   - **(C)** **Background plausibility:** dust risk supports the proposed mechanism, not weakens it.
   - **(D)** **Future-use diversion:** later target types do not diagnose the observed before/after.
   - **(E)** **Bandwagon trap:** other observatories' plans do not test causation here.

**Check:** The old physical observations with new software mimic the alleged dome effect.
::::
:::

:::problem[Question III.4]
An insurer surveys every policyholder who received a claims payment last month, asking whether the settlement amount was fair. Only a small minority respond, and nearly all responders say it was fair. The insurer's executive announces that nearly all paid claimants regard their settlements as fair. The executive acknowledges that people satisfied with payments might be more motivated to answer, but argues that because the respondents were invited using identical email messages, response differences cannot compromise the survey.

The reasoning is flawed because it...

- **(A)** Assumes uniform invitations eliminate bias resulting from who chooses to answer.
- **(B)** Infers that the insurer is profitable from customers' satisfaction.
- **(C)** Ignores that a survey can be administered by telephone rather than email.
- **(D)** Treats all policyholders as having received a payment last month.
- **(E)** Concludes that sending any email necessarily changes a customer's satisfaction.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Nearly all paid claimants judge settlement amounts fair.
2. **Support.** Nearly all respondents say fair, but most invitees did not respond.
3. **Prephrase.** Identify selection/nonresponse bias rather than different invitations.
4. **Why (A) is right.** Sending identical messages does not guarantee respondents represent nonrespondents; motivation can affect reply rates.
5. **Why the others fail.**
   - **(B)** **Different conclusion:** profitability is never claimed.
   - **(C)** **Medium diversion:** telephone is one alternate method, not the specific logical gap.
   - **(D)** **Scope invention:** the sample was limited to those paid last month.
   - **(E)** **Unasserted causal effect:** satisfaction is measured, not alleged caused by email.

**Check:** Uniform invitation ≠ uniform response propensity.
::::
:::

:::problem[Question III.5]
A community theater's wardrobe manager proposes repairing its aging costumes instead of replacing the entire collection. While some garments require careful stitching, most have sound fabric and only minor damage. Purchasing new costumes would also require fitting sessions that would consume rehearsal time. The manager admits that a few severely damaged garments should be retired, but maintains that this does not justify discarding the usable majority. Therefore, the company should adopt repairs as its default policy while permitting targeted replacement when repair is not practical.

Which one of the following most accurately states the main conclusion?

- **(A)** Every costume in the theater's collection can be restored successfully.
- **(B)** Fitting new costumes would require rehearsal time.
- **(C)** Replacing a few garments is always cheaper than repairing them.
- **(D)** The theater should ordinarily repair costumes and replace only those that cannot reasonably be repaired.
- **(E)** The theater must never purchase a new costume in the future.

::::solution[Solution]
**Answer:** (D)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The manager recommends a repair-first policy with exceptions.
2. **Support.** Most fabric is sound and full replacement consumes fitting time.
3. **Prephrase.** Identify the qualified recommendation supported by the evidence.
4. **Why (D) is right.** The final sentence states the recommended policy while retaining targeted replacements.
5. **Why the others fail.**
   - **(A)** **Overstatement:** manager acknowledges some garments cannot be repaired.
   - **(B)** **Premise trap:** rehearsal time is evidence for the policy.
   - **(C)** **Unmade cost assertion:** no absolute relative price claim is offered.
   - **(E)** **Absolute prohibition:** targeted purchases are explicitly allowed.

**Check:** The stated conclusion is qualified by practicability, as the argument requires.
::::
:::

:::problem[Question III.6]
A fictitious city compares two flood-barrier designs. Design A costs less to construct, but an engineer predicts that Design B will have lower maintenance expenses over the next fifteen years. The budget director recommends B as the less costly option over the whole period. The analysis assumes both barriers would provide comparable flood protection and ignores demolition costs because neither is scheduled to be removed during those years. It does not report how much more B costs to build or how large its expected maintenance savings are.

Which one of the following is an assumption on which the recommendation depends?

- **(A)** Design B's projected maintenance savings over the fifteen years exceed its additional construction cost.
- **(B)** Design B will require no maintenance at all.
- **(C)** Design A will never protect the city from a major flood.
- **(D)** Design B will have a longer usable life than every other barrier design.
- **(E)** Flood damage is certain to occur during the next fifteen years.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** B has lower total cost over the chosen horizon.
2. **Support.** B costs more initially but less to maintain, and protection is comparable.
3. **Prephrase.** Require lifetime operating advantage greater than upfront premium.
4. **Why (A) is right.** If the construction premium is as large as or larger than maintenance savings, B is not the cheaper total-cost option.
5. **Why the others fail.**
   - **(B)** **Perfection trap:** lower maintenance can be nonzero.
   - **(C)** **Protection distraction:** the comparison expressly holds protection comparable.
   - **(D)** **Extraneous ranking:** comparison is only A versus B over fifteen years.
   - **(E)** **Unnecessary hazard assumption:** cost ranking can hold whether a flood occurs or not.

**Check:** Cost(B) < cost(A) precisely if maintenance savings exceed build premium.
::::
:::

:::problem[Question III.7]
A hypothetical clinic randomized consenting patients to receive identical tablets either in dated blister packs or in standard bottles. Both groups received the same appointment schedule. After eight weeks, the blister-pack group had fewer missed doses according to pill counts. A researcher concludes that the dated packaging helped patients remember their medication. A colleague points out that patients may have removed pills from blister packs simply to make the counted supply look complete, even if they did not swallow them.

Which one of the following, if true, most strengthens the researcher's explanation?

- **(A)** The blister packs were more expensive to manufacture than the standard bottles.
- **(B)** An independently recorded biological indicator of medication use was more consistent with scheduled dosing in the blister-pack group.
- **(C)** All participants had been told that adherence was important.
- **(D)** The clinic's pharmacy was open for the same hours throughout the trial.
- **(E)** Some patients in both groups reported disliking the taste of the tablets.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Dated packaging improved actual medication-taking by helping memory.
2. **Support.** Random assignment and pill counts suggest greater adherence but pill removal might mimic ingestion.
3. **Prephrase.** Find a measure of actual use independent from pill counts.
4. **Why (B) is right.** An independent biological use measure supports genuine ingestion rather than decorative pill removal.
5. **Why the others fail.**
   - **(A)** **Cost distraction:** cost has no bearing on what participants swallowed.
   - **(C)** **Shared factor:** same instructions do not verify pill counts or isolate mechanism.
   - **(D)** **Baseline control:** stable pharmacy hours does not rule out pill removal.
   - **(E)** **Common nuisance:** shared complaints about taste do not validate recorded dosing.

**Check:** Independent evidence of ingestion closes the principal measurement gap.
::::
:::

:::problem[Question III.8]
A rescue coordinator argues that, when two distress calls arrive simultaneously, the crew should be sent first to the location where it can reasonably be expected to save more lives. Another officer responds that rescuers cannot always know how many people are at risk. The coordinator agrees that estimates can be uncertain but says uncertainty is not a reason to abandon comparative estimates altogether; it is a reason to use ranges and update them as reports improve. The coordinator concludes that a consistently applied estimate-based rule is better than prioritizing whichever caller is most persistent.

The statement that rescuers cannot always know how many people are at risk plays which one of the following roles?

- **(A)** It is the coordinator's final reason for rejecting comparative estimates.
- **(B)** It establishes that the first caller is always in greater danger.
- **(C)** It is presented as a fact that the coordinator explicitly denies.
- **(D)** It supplies an example of the final rule being implemented successfully.
- **(E)** It introduces a practical objection that the coordinator concedes in part and then addresses.

::::solution[Solution]
**Answer:** (E)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** An estimate-based allocation rule beats caller persistence.
2. **Support.** Officer raises uncertainty; coordinator accepts uncertainty but proposes ranges and updating.
3. **Prephrase.** Describe objection, concession, and response.
4. **Why (E) is right.** The officer's remark is an obstacle to implementing the preferred rule, not its rejection.
5. **Why the others fail.**
   - **(A)** **Speaker and conclusion swap:** coordinator favors estimates.
   - **(B)** **Invented comparison:** order of calls is not discussed.
   - **(C)** **Denial trap:** coordinator acknowledges the uncertainty.
   - **(D)** **Example confusion:** no actual rescue application is described.

**Check:** The coordinator's following sentence directly replies to the uncertainty objection.
::::
:::

:::problem[Question III.9]
A fictional insurer introduced automatic text notices telling claimants when an inspection appointment was available. After the notices began, the proportion of claimants attending their first scheduled inspection increased. Nevertheless, the average number of days from filing a claim to completed inspection also increased. The insurer hired no fewer inspectors, and the average time required to conduct an inspection remained unchanged. Management suspects that improved attendance and longer overall delays can be reconciled by considering when appointments are first offered.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The insurer sent nearly every claimant the identical wording in its notices.
- **(B)** Inspectors filed their completed reports electronically rather than on paper.
- **(C)** The insurer began scheduling first appointments farther into the future because a larger backlog of new claims arrived at the same time.
- **(D)** The rate of claim denials fell slightly during the same period.
- **(E)** Claimants who miss appointments often find the process frustrating.

::::solution[Solution]
**Answer:** (C)

**Type:** Resolve paradox (Chapter 13)

1. **Conclusion.** First-appointment attendance rises while total filing-to-completion time increases.
2. **Support.** Attendance controls missed visits; scheduling delays occur before first visit.
3. **Prephrase.** Show waiting time before appointments grew enough to outweigh fewer missed visits.
4. **Why (C) is right.** A larger backlog postpones initial scheduling, even while more people attend once offered a slot.
5. **Why the others fail.**
   - **(A)** **Uniform-message trap:** content does not account for longer queue.
   - **(B)** **Downstream swap:** report submission does not govern time to completed inspection.
   - **(D)** **Different outcome:** denials follow the claims process and do not explain inspection queues.
   - **(E)** **General tendency:** frustration does not quantify the changed delay.

**Check:** Total delay = time to first appointment + delays from missed visits; first term can rise as second falls.
::::
:::

:::problem[Question III.10]
An astronomy educator selects ten binary-star systems for a public lecture because their periodic brightness changes are especially dramatic. In those selected systems, the changes are easy for students to discern from graphs. The educator concludes that brightness variations are easy to discern in nearly all binary-star systems. An assistant objects that the lecturer deliberately chose conspicuous examples, and that systems with subtler variations were excluded precisely because their graphs would be harder to interpret.

The educator's argument is most vulnerable to the criticism that it...

- **(A)** Claims that every periodic brightness change has the same physical cause.
- **(B)** Infers that there are no binary stars outside the selected systems.
- **(C)** Assumes that charts cannot represent changes in brightness.
- **(D)** Treats deliberately selected conspicuous cases as representative of a broader population.
- **(E)** Excludes students' reactions from the definition of astronomy.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Nearly all binary systems show easily discernible variability.
2. **Support.** Ten deliberately dramatic systems illustrate the effect well.
3. **Prephrase.** Point to sample selection on the very property generalized.
4. **Why (D) is right.** Selecting conspicuous examples makes easy detection more frequent in the sample than it need be in the population.
5. **Why the others fail.**
   - **(A)** **Cause distraction:** no mechanism is generalized.
   - **(B)** **Universe-size caricature:** the existence of other systems is not denied.
   - **(C)** **Contradiction:** charts are presented as clearly showing changes.
   - **(E)** **Category invention:** the educator does not define astronomy or students' role.

**Check:** Selection criterion = conspicuous variation; generalization = conspicuous variation.
::::
:::

:::problem[Question III.11]
A hypothetical museum's restoration committee has two written rules: any work considered historically fragile must be examined by an external conservator, and any work examined by an external conservator must receive a photographic condition report. A painting donated last month has a damaged frame. A trustee predicts that the painting will receive a photographic condition report before it is displayed, although the damaged frame alone does not establish that the painting is historically fragile.

The trustee's conclusion can be properly drawn if which one of the following is assumed?

- **(A)** Every work receiving a condition report has been examined by a conservator.
- **(B)** Some paintings with damaged frames are historically fragile.
- **(C)** External conservators sometimes recommend replacing damaged frames.
- **(D)** The trustee believes photographic documentation is aesthetically valuable.
- **(E)** The donated painting is considered historically fragile and the required reviews occur before display.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** This painting must have a photographic report before display.
2. **Support.** Fragile → conservator → report, but no fragility classification or timing given.
3. **Prephrase.** Establish both membership in chain and timing relative to display.
4. **Why (E) is right.** Given fragility, the rules require the two steps; stipulated pre-display timing makes the conclusion fully follow.
5. **Why the others fail.**
   - **(A)** **Converse:** report → conservator cannot give the report to this painting.
   - **(B)** **Some-to-particular:** some damaged-frame paintings may be fragile, not necessarily this one.
   - **(C)** **Different action:** frame replacement is unrelated to mandatory reports.
   - **(D)** **Preference vs. duty:** personal belief supplies neither fragility nor a deadline.

**Check:** Fragile(P) → conservator(P) → report(P), with the added timing condition.
::::
:::

:::problem[Question III.12]
In a hypothetical county, all neighborhoods enrolled in the overnight waste-collection pilot have been given sealed communal bins. Some neighborhoods with sealed bins are not enrolled in the pilot. Residents in every pilot neighborhood were surveyed about noise at the end of the month, although respondents in one neighborhood were too few to permit a neighborhood-specific estimate. The county will expand the pilot only if its countywide noise index falls below a preset threshold. No decision about expansion has yet been made.

Which one of the following is most strongly supported?

- **(A)** Every neighborhood that received sealed bins was surveyed about noise.
- **(B)** Having sealed communal bins does not by itself establish that a neighborhood is enrolled in the overnight pilot.
- **(C)** The countywide noise index has already fallen below the preset threshold.
- **(D)** The neighborhood with few respondents was not actually part of the pilot.
- **(E)** No neighborhood outside the pilot possesses sealed communal bins.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Identify what can be inferred about bin-equipped versus enrolled neighborhoods.
2. **Support.** Pilot → bins; some bins are not pilot; all pilots surveyed; expansion undecided.
3. **Prephrase.** Reject the converse bins → pilot.
4. **Why (B) is right.** An explicit subgroup with bins but no pilot shows that bins are not a sufficient enrollment test.
5. **Why the others fail.**
   - **(A)** **Converse universal:** nonpilot bin neighborhoods are not guaranteed a survey.
   - **(C)** **Premature outcome:** index status is not given.
   - **(D)** **Quantifier misread:** the undersampled neighborhood is explicitly within the survey of pilots.
   - **(E)** **Direct contradiction:** some nonpilot neighborhoods do have sealed bins.

**Check:** Some B ∧ not P, so B cannot imply P.
::::
:::

:::problem[Question III.13]
A research reviewer is asked whether a hypothetical medicine's association with better sleep proves that the medicine caused the improvement. The original report compared volunteers who chose the medicine with volunteers who did not. The reviewer first grants that the treated volunteers slept longer on average, then points out that volunteers choosing treatment also reported different work schedules. The reviewer argues that until schedules are accounted for, the observed association cannot support the report's causal language. The reviewer does not assert that the medicine lacks any effect.

Which one of the following most accurately describes the reviewer's method of reasoning?

- **(A)** The reviewer accepts an observed association but offers a potential alternative explanation that limits the causal inference.
- **(B)** The reviewer disputes the reported sleep measurements and replaces them with estimated values.
- **(C)** The reviewer proves that work schedules alone explain all differences in sleep.
- **(D)** The reviewer deduces that choosing a medicine cannot change any physiological outcome.
- **(E)** The reviewer cites an authority to establish a universal rule about randomized trials.

::::solution[Solution]
**Answer:** (A)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** Current evidence does not establish causation.
2. **Support.** Groups differ in schedule as well as treatment; mean sleep differs.
3. **Prephrase.** Identify a conceded observation with a confounding alternative.
4. **Why (A) is right.** The reviewer separates real observed differences from an unsupported attribution to medicine.
5. **Why the others fail.**
   - **(B)** **Evidence-denial trap:** sleep measurement is conceded.
   - **(C)** **Overreach:** scheduling is offered as a possibility, not proved sole cause.
   - **(D)** **Extreme claim:** reviewer explicitly leaves open genuine medicine effects.
   - **(E)** **Unstated authority:** no expert or trial rule is cited.

**Check:** Association conceded + alternative cause introduced → causal conclusion withheld.
::::
:::

:::problem[Question III.14]
A city's treasurer argues that moving some bus-maintenance spending from an annual appropriation to a dedicated reserve will prevent repairs from being postponed during budget disputes. The reserve would be funded by a fixed monthly transfer and could be spent only on repairs. The treasurer notes that disagreements over general appropriations previously delayed payments to contractors. Critics respond that a reserve may merely move the bottleneck from payments to authorization, since every repair would still need a separate council vote before work could begin.

Which one of the following, if true, most seriously weakens the treasurer's argument?

- **(A)** The reserve would be kept in a separately labeled bank account.
- **(B)** Some bus repairs require more than one day of labor.
- **(C)** In most past delays, contractors had funds available for payment but could not start until council approved the individual repair.
- **(D)** The monthly transfers would occur on the first business day of each month.
- **(E)** The dedicated fund would be subject to annual financial auditing.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The reserve will prevent repair postponements.
2. **Support.** Past disputes supposedly created funding delays, but individual approvals persist.
3. **Prephrase.** Identify the real binding bottleneck as something untouched by the reserve.
4. **Why (C) is right.** If approvals delayed the work even when money was available, earmarking money fails to remove the predominant cause of delays.
5. **Why the others fail.**
   - **(A)** **Bookkeeping proxy:** labeling does not cure approvals.
   - **(B)** **Duration distraction:** repair length does not explain wait before authorization.
   - **(D)** **Timing microdetail:** exact transfer day does not solve council votes.
   - **(E)** **Oversight diversion:** audits do not determine authorization timing.

**Check:** When authorization, not funding, was binding, adding funds alone cannot start repairs.
::::
:::

:::problem[Question III.15]
A hypothetical astronomy lab claims that a new clock-synchronization protocol eliminated disagreements between two telescopes about the ordering of near-simultaneous events. After the lab introduced the protocol, the recorded timestamps from the two telescopes matched more often. The lab therefore concludes that the events are now being ordered more accurately. However, both telescopes began receiving the same central timestamp stream at the same time as the protocol change, and the lab has no independent measurement of the actual event order.

Which one of the following is an assumption required by the lab's reasoning?

- **(A)** Every event in the universe can be assigned an exact timestamp by the protocol.
- **(B)** The two telescopes are physically identical in every respect.
- **(C)** The protocol eliminates every possible source of measurement error.
- **(D)** The increased agreement between the telescopes is not solely the result of their sharing a common timestamp error.
- **(E)** Near-simultaneous events are more scientifically important than widely separated ones.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Timestamp ordering grew more accurate, not merely more consistent.
2. **Support.** Agreement rose, but timestamps can agree because both share an error.
3. **Prephrase.** Exclude the possibility that agreement is entirely spurious common-mode error.
4. **Why (D) is right.** If both instruments now make the same incorrect ordering because of the shared stream, agreement gives no evidence of increased accuracy.
5. **Why the others fail.**
   - **(A)** **Universal overstatement:** only these observations are at issue.
   - **(B)** **Unneeded identity:** different telescopes can synchronize accurately.
   - **(C)** **Perfection trap:** improvement does not imply zero error.
   - **(E)** **Value judgment:** scientific importance does not determine ordering accuracy.

**Check:** Negate credited claim: all added agreement is shared error; agreement ceases to support accuracy.
::::
:::

:::problem[Question III.16]
A university interviewer may release a transcript only if the interview subject has consented to release. In addition, every transcript cleared for public release has been reviewed for accidental identifying details. The interviewer has released a transcript from the research project. Therefore, the subject consented and the transcript was reviewed for identifying details. The argument relies on the two separate prerequisites of release and does not conclude that consent plus review would necessarily have required release.

Which one of the following arguments most closely parallels the reasoning above?

- **(A)** A museum loans artifacts if owners give permission and reports are prepared. The owner gave permission; therefore the artifact was loaned.
- **(B)** Every loaned artifact has a report. An artifact has a report; therefore it was loaned.
- **(C)** A museum loans an artifact only with the owner's permission, and every loaned artifact receives a condition report. Since an artifact was loaned, it had permission and a condition report.
- **(D)** Artifacts sometimes receive reports before loans. This artifact received a report; therefore it probably was loaned.
- **(E)** Only artifacts owned by the museum may be loaned. An artifact is museum-owned; therefore it must be loaned.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Release entails both consent and review.
2. **Support.** Release → consent and release → review; release occurred.
3. **Prephrase.** Match antecedent verified, hence both required conditions.
4. **Why (C) is right.** Loan → permission and loan → report, so actual loan establishes both prerequisites.
5. **Why the others fail.**
   - **(A)** **Missing condition and converse:** permission alone does not establish a loan.
   - **(B)** **Affirming consequent:** possessing a report does not guarantee a loan.
   - **(D)** **Probability diversion:** a report alone does not support the same deductive conclusion.
   - **(E)** **Necessary/sufficient reversal:** museum ownership does not force a loan.

**Check:** R → C and R → V; R, therefore C ∧ V.
::::
:::

:::problem[Question III.17]
A fictitious city states that the share of its school budget spent on classroom repairs rose from eight percent to ten percent. A council member says this proves that the city spent more money on repairs this year, so concerns about deferred maintenance must be exaggerated. Yet the council member offers no total budget amounts for either year. The city's total school budget could have fallen considerably, and there is no information about whether the number or severity of repair needs also changed.

The argument is most vulnerable to criticism because it...

- **(A)** Assumes that every repair need could be addressed by private donations.
- **(B)** Concludes that school enrollment rose solely because repairs were funded.
- **(C)** Uses the size of a contractor's bid to estimate a budget share.
- **(D)** Presumes that ten percent is a smaller fraction than eight percent.
- **(E)** Infers an increase in an absolute amount from an increase in its share of a total whose size may have changed.

::::solution[Solution]
**Answer:** (E)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Absolute repair spending rose and maintenance worries are exaggerated.
2. **Support.** Share rose from 8% to 10%, with unknown total size.
3. **Prephrase.** Distinguish percentage from amount with changing denominator.
4. **Why (E) is right.** Ten percent of a much smaller budget can be less money than eight percent of a larger one; maintenance need is also not measured.
5. **Why the others fail.**
   - **(A)** **Invented funding:** donation proposals never appear.
   - **(B)** **Unasserted outcome:** enrollment is not discussed.
   - **(C)** **Fabricated input:** contractor bids do not appear.
   - **(D)** **Arithmetic caricature:** the member knows the share rose; the error concerns its denominator.

**Check:** For example, 8% of 100 = 8 but 10% of 60 = 6.
::::
:::

:::problem[Question III.18]
A hypothetical insurer tests a new rule for deciding which unusual claims receive a second review. The rule flags files with several jointly suspicious indicators rather than any single unusual expense. In a retrospective sample, it would have flagged fewer innocent claims than the old rule while still identifying most claims later found fraudulent. A compliance officer worries that the test is misleading because confirmed fraud cases had originally been chosen for intense investigation and might not represent fraud among ordinary claims.

Which one of the following, if true, most strengthens the evidence supporting adoption of the new rule?

- **(A)** The new rule is easier for experienced adjusters to describe to one another.
- **(B)** In a separately selected random set of ordinary claims independently checked for fraud, the new rule preserved the same reduction in innocent flags without missing more confirmed fraud.
- **(C)** Several claims in the original dataset involved unusually expensive repairs.
- **(D)** The old rule had originally been introduced after a committee meeting.
- **(E)** The insurer's advertising department prefers describing the rule as data-driven.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The new flagging rule improves false-positive burden without harmful fraud misses.
2. **Support.** Retrospective biased sample appears favorable, with selection concern.
3. **Prephrase.** Validate in independently examined representative ordinary claims.
4. **Why (B) is right.** Random independent verification addresses selection of investigated fraud and directly repeats the performance comparison.
5. **Why the others fail.**
   - **(A)** **Usability diversion:** explanation ease does not establish predictive accuracy.
   - **(C)** **Sample anecdote:** unusual repair prices do not settle selection bias.
   - **(D)** **Origin story:** old rule's adoption process does not validate this one.
   - **(E)** **Marketing appeal:** promotional preference does not measure error rates.

**Check:** Test on independently screened ordinary claims, not only historically investigated cases.
::::
:::

:::problem[Question III.19]
Clinical pharmacist: Our fictional clinic should not retain patients' medication-alert histories after the immediate reminder has been delivered. The reminders work without persistent storage, so retaining detailed histories creates an avoidable privacy burden. Research director: I agree that sending reminders does not require long-term storage. But I disagree that the retention is avoidable: without historical records we could not assess whether the system systematically fails certain patients, and that evaluation is worth the limited privacy burden when records are carefully restricted.

The speakers disagree about whether...

- **(A)** Retaining medication-alert histories is justified despite not being needed to deliver immediate reminders.
- **(B)** The reminder system can function without long-term historical storage.
- **(C)** Privacy burdens are relevant to the policy decision.
- **(D)** Historical records might help researchers investigate unequal system performance.
- **(E)** Medication-alert histories should be made public to improve accountability.

::::solution[Solution]
**Answer:** (A)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Determine precisely what each speaker supports and opposes.
2. **Support.** Both grant reminders function without storage; pharmacist rejects retention; director favors it for research.
3. **Prephrase.** Contrast the ethics of retaining information with the technical necessity of delivering messages.
4. **Why (A) is right.** The pharmacist says the burden is unnecessary and retention should stop; director says evaluation warrants retention.
5. **Why the others fail.**
   - **(B)** **Agreement:** the director expressly agrees storage is not technically needed.
   - **(C)** **Shared consideration:** both treat privacy as a burden.
   - **(D)** **One-sided claim:** only the director asserts evaluation utility; pharmacist does not deny it.
   - **(E)** **Unaddressed extreme:** neither proposes making records public.

**Check:** Pharmacist: no retention; research director: justified restricted retention.
::::
:::

:::problem[Question III.20]
A neighborhood cafe plans to require small refundable deposits for large-table reservations. The owner predicts the policy will lower the number of tables left empty because parties fail to appear. Customers who cancel by a stated deadline receive their deposits back; those who fail to appear lose them. The owner does not expect the policy to change how often parties ultimately attend; instead, prospective no-shows will supposedly cancel earlier, giving the cafe time to offer their tables to other customers. The cafe currently receives some walk-ins, but no count is given for when they arrive.

Which one of the following is an assumption required by the owner's prediction?

- **(A)** Every party that places a deposit will arrive on time.
- **(B)** All walk-in customers prefer the largest tables.
- **(C)** The cafe will earn more money from forfeited deposits than from food sales.
- **(D)** At least some tables released by earlier cancellations will be occupied by other customers who otherwise would not have used those tables.
- **(E)** Not a single customer will object to the deposit requirement.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The deposit will reduce empty tables associated with no-shows.
2. **Support.** The proposed mechanism is earlier cancellation, not greater attendance; a released table can still remain empty.
3. **Prephrase.** Require released slots to reach actual replacement diners rather than remain empty.
4. **Why (D) is right.** If no replacement customers occupy released tables, shifting a no-show into an earlier cancellation merely changes the label on the same empty table.
5. **Why the others fail.**
   - **(A)** **Perfection trap:** some parties can still be late while aggregate emptiness falls.
   - **(B)** **Size mismatch:** walk-ins need not all want large tables.
   - **(C)** **Different outcome:** deposit income is not occupancy.
   - **(E)** **Unanimity trap:** objections can occur without negating the beneficial incentive.

**Check:** Negate: no released tables are filled by replacement patrons; with attendance otherwise unchanged, the empty-table count does not fall.
::::
:::

:::problem[Question III.21]
A nonprofit studying food-assistance access asks participants to submit optional diaries of their experiences. Its written policy promises that diary passages can be withdrawn before publication. A participant withdraws a paragraph after the nonprofit has spent substantial time preparing a report. The report's editor suggests keeping the paragraph anonymously because removing it would disrupt the narrative. Another editor says the promise should control: the inconvenience resulted from adopting a withdrawal policy, and removing the paragraph would not invalidate the report's findings.

Which one of the following principles most supports the second editor's position?

- **(A)** Participants should always be able to change every factual finding after publication.
- **(B)** An organization may ignore withdrawal promises whenever identifying details are removed.
- **(C)** All research based on voluntary diaries is inherently unreliable.
- **(D)** An organization should honor a clearly communicated withdrawal option when doing so does not defeat the legitimate purpose of the project, even if compliance is inconvenient.
- **(E)** Editorial convenience should prevail whenever a withdrawal reduces narrative flow.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The nonprofit should remove the withdrawn passage.
2. **Support.** The participant exercised an explicit promise and removal does not undermine results.
3. **Prephrase.** Respect a foreseeable commitment despite editorial inconvenience.
4. **Why (D) is right.** The principle contains the precise conditions: clear withdrawal promise, tolerable compliance, and intact research purpose.
5. **Why the others fail.**
   - **(A)** **Extreme extension:** postpublication factual rewriting is not promised.
   - **(B)** **Anonymity shell game:** the promised right concerns use of passages, not only identities.
   - **(C)** **Research-method diversion:** reliability of all diaries is irrelevant.
   - **(E)** **Opposite priority:** narrative inconvenience is the rejected reason for breach.

**Check:** The policy grants withdrawal before publication, which is the participant's stated act.
::::
:::

:::problem[Question III.22]
In a hypothetical insurer's repair-vendor program, every vendor whose preferred-list status has been activated must carry a current safety certificate. Every vendor with a current safety certificate is eligible for an expedited payment review, though eligibility alone does not guarantee approval of a particular invoice. A contractor called Northline has applied for preferred-list status, but the manager does not know whether its application has been activated. The claims manager concludes that Northline is eligible for expedited payment review under the program's rules.

Which one of the following, if assumed, would allow the conclusion to be properly drawn?

- **(A)** Some vendors with safety certificates are not included on the preferred list.
- **(B)** Every vendor eligible for expedited payment review is preferred.
- **(C)** Northline has previously received payment on at least one invoice.
- **(D)** No vendor has ever had an expedited invoice rejected.
- **(E)** Northline's preferred-list status has been activated.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Northline is eligible for expedited review.
2. **Support.** Activated preferred status → certificate → eligible; Northline is only an applicant.
3. **Prephrase.** Establish that Northline has activated status, not merely a pending application.
4. **Why (E) is right.** Activated status supplies the missing first link; the rules then yield a current certificate and expedited-review eligibility.
5. **Why the others fail.**
   - **(A)** **Irrelevant existential:** some nonlisted certified firms say nothing about Northline.
   - **(B)** **Reverse relation:** eligible → preferred does not prove eligibility from a preferred label.
   - **(C)** **Past payment:** ordinary payment does not establish expedited eligibility.
   - **(D)** **Approval confusion:** outcome of invoices is distinct from eligibility to request review.

**Check:** Activated(N) → certified(N) → eligible(N).
::::
:::

:::problem[Question III.23]
A fictional observatory's director notes that every project awarded funding last year received at least one vote from a senior astronomer. A new project has received a senior astronomer's vote, so the director declares that it will receive funding. But several projects that received senior votes were rejected, and funding also depends on available telescope time and adherence to safety requirements. The director replies that the senior vote is valuable; nevertheless, that does not answer whether it is enough for an award.

The director's reasoning is most vulnerable to the criticism that it...

- **(A)** Treats a condition required of previously funded projects as sufficient to secure funding.
- **(B)** Assumes that telescope time is the only criterion for awarding funding.
- **(C)** Concludes that the senior astronomer's vote has no value.
- **(D)** Uses a funding decision to establish the astronomical truth of a proposal.
- **(E)** Claims that every rejected proposal violated a safety requirement.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The new project will receive funding.
2. **Support.** All previously funded projects had a senior vote; new project has vote.
3. **Prephrase.** Name affirming the consequent / necessary-sufficient confusion.
4. **Why (A) is right.** Funded → vote does not justify vote → funded, especially with expressly rejected voted projects.
5. **Why the others fail.**
   - **(B)** **Wrong exclusivity:** director fails to account for other criteria, not elevate only telescope time.
   - **(C)** **Opposite attitude:** director calls senior vote valuable.
   - **(D)** **Science/administration swap:** no truth claim is made.
   - **(E)** **Invented diagnosis:** specific reasons for rejected projects are not established.

**Check:** Funding → vote; vote ⇏ funding, given rejected projects with votes.
::::
:::

:::problem[Question III.24]
A county commissioner observes that road-repair spending occupied a larger percentage of the county's annual budget this year than last year. The commissioner concludes that the county must have spent a larger absolute number of dollars on road repairs. The commissioner rejects a request to provide the total budget figures for each year, saying that the increased share is sufficient evidence of a larger expenditure. Several other spending categories were reorganized during the period.

Which one of the following arguments contains the most similar error?

- **(A)** A cafe sold thirty cups of tea last month and forty this month; therefore it sold ten more cups this month.
- **(B)** A cafe increased the price of tea and sold the same number of cups; therefore revenue from tea increased.
- **(C)** A cafe says tea sales made up a larger share of its revenue this month; therefore, it must have collected more dollars from tea, without considering whether total revenue fell.
- **(D)** A cafe sold more tea than coffee this month; therefore tea revenue was greater if both drinks had the same price.
- **(E)** A cafe devoted fewer shelf spaces to tea than coffee; therefore fewer tea varieties were displayed than coffee varieties.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** Absolute spending increased just because budget share increased.
2. **Support.** Percent share = amount / total; total is unknown.
3. **Prephrase.** Match inference about numerator from ratio with changing denominator.
4. **Why (C) is right.** Tea-share increase likewise cannot prove more tea dollars if overall revenue shrinks.
5. **Why the others fail.**
   - **(A)** **Valid arithmetic:** forty minus thirty is ten.
   - **(B)** **Valid multiplication:** higher price at same quantity yields greater revenue.
   - **(D)** **Valid conditional comparison:** more units at same price yields more revenue.
   - **(E)** **Different evidence:** shelf allocations and varieties have no ratio-to-total-dollar inference.

**Check:** 8% of 100 > 10% of 60; larger share need not mean more absolute units.
::::
:::

:::problem[Question III.25]
A hypothetical clinic began sending automated refill reminders to patients whose prescriptions were nearly exhausted. The proportion of patients picking up a refill within a week increased after the program started. The clinic director says the reminders caused the improvement and wants to fund the system permanently. At about the same time, the pharmacy changed its hours to remain open later, and the number of prescriptions needing refills fluctuated across the two periods. No comparison group was included in the director's report.

Which one of the following would be most useful to determine in evaluating the director's explanation?

- **(A)** Did the reminder messages use a font that most recipients could read?
- **(B)** Did comparable patients who did not receive reminders show a similar improvement when pharmacy hours were extended?
- **(C)** Was the reminder software purchased from a local company?
- **(D)** Would some patients prefer to call the pharmacy themselves?
- **(E)** Could the pharmacy offer an additional generic medicine next year?

::::solution[Solution]
**Answer:** (B)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** Reminders caused improved refill pickup.
2. **Support.** Pickup rose after reminders and later hours were introduced.
3. **Prephrase.** Compare equivalent people exposed to the concurrent change but not reminders.
4. **Why (B) is right.** If nonreminded comparable patients improved equally, extended hours explain gains; if not, the reminder hypothesis gains support.
5. **Why the others fail.**
   - **(A)** **Narrow usability:** legibility matters but cannot separate reminders from opening hours.
   - **(C)** **Vendor diversion:** seller location does not identify the cause.
   - **(D)** **Preference proxy:** preferred communication channel does not reveal actual pickup effect.
   - **(E)** **Future supply:** a prospective generic has no bearing on the past comparison.

**Check:** Use a simultaneous unreminded group to control for changed hours.
::::
:::

## 38.4 Scoring and review

Count one point for every correct answer. Your **raw score is out of 77**. This original practice test has not been statistically equated, so do not convert its raw scores to official 120–180 scores or LSAT percentiles. Compare section performance and error patterns instead.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | --- |
| I.1 | B | Main conclusion | Chapter 11 |
| I.2 | D | Strengthen | Chapter 8 |
| I.3 | A | Flaw | Chapter 9 |
| I.4 | E | Necessary assumption | Chapter 7 |
| I.5 | C | Resolve paradox | Chapter 13 |
| I.6 | C | Principle | Chapter 13 |
| I.7 | A | Weaken | Chapter 8 |
| I.8 | D | Flaw | Chapter 9 |
| I.9 | B | Must be true | Chapter 10 |
| I.10 | E | Sufficient assumption | Chapter 7 |
| I.11 | D | Role of a statement | Chapter 11 |
| I.12 | B | Necessary assumption | Chapter 7 |
| I.13 | E | Strengthen | Chapter 8 |
| I.14 | A | Method of reasoning | Chapter 11 |
| I.15 | C | Parallel reasoning | Chapter 12 |
| I.16 | E | Flaw | Chapter 9 |
| I.17 | C | Most strongly supported | Chapter 10 |
| I.18 | B | Weaken | Chapter 8 |
| I.19 | D | Necessary assumption | Chapter 7 |
| I.20 | A | Principle | Chapter 13 |
| I.21 | A | Flaw | Chapter 9 |
| I.22 | E | Sufficient assumption | Chapter 7 |
| I.23 | C | Point at issue | Chapter 11 |
| I.24 | B | Parallel flaw | Chapter 12 |
| I.25 | D | Evaluate | Chapter 8 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | --- |
| II.1 | A | Main point | Chapter 18 |
| II.2 | C | Detail | Chapter 18 |
| II.3 | E | Function of a part | Chapter 18 |
| II.4 | B | Inference | Chapter 18 |
| II.5 | D | Application | Chapter 18 |
| II.6 | B | Organization | Chapter 18 |
| II.7 | D | Author attitude | Chapter 18 |
| II.8 | E | Main point | Chapter 18 |
| II.9 | A | Detail | Chapter 18 |
| II.10 | C | Inference | Chapter 18 |
| II.11 | E | Function of a part | Chapter 18 |
| II.12 | D | Application | Chapter 18 |
| II.13 | B | Author attitude | Chapter 18 |
| II.14 | A | Comparative relationship | Chapter 17 |
| II.15 | C | Comparative agreement | Chapter 17 |
| II.16 | B | Comparative relationship | Chapter 17 |
| II.17 | D | Comparative inference | Chapter 17 |
| II.18 | E | Comparative application | Chapter 17 |
| II.19 | A | Comparative author response | Chapter 17 |
| II.20 | C | Comparative function | Chapter 17 |
| II.21 | B | Main point | Chapter 18 |
| II.22 | E | Inference | Chapter 18 |
| II.23 | D | Function of a part | Chapter 18 |
| II.24 | A | Detail | Chapter 18 |
| II.25 | C | Application | Chapter 18 |
| II.26 | E | Author attitude | Chapter 18 |
| II.27 | B | Organization | Chapter 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | --- |
| III.1 | C | Must be true | Chapter 10 |
| III.2 | E | Principle | Chapter 13 |
| III.3 | B | Weaken | Chapter 8 |
| III.4 | A | Flaw | Chapter 9 |
| III.5 | D | Main conclusion | Chapter 11 |
| III.6 | A | Necessary assumption | Chapter 7 |
| III.7 | B | Strengthen | Chapter 8 |
| III.8 | E | Role of a statement | Chapter 11 |
| III.9 | C | Resolve paradox | Chapter 13 |
| III.10 | D | Flaw | Chapter 9 |
| III.11 | E | Sufficient assumption | Chapter 7 |
| III.12 | B | Most strongly supported | Chapter 10 |
| III.13 | A | Method of reasoning | Chapter 11 |
| III.14 | C | Weaken | Chapter 8 |
| III.15 | D | Necessary assumption | Chapter 7 |
| III.16 | C | Parallel reasoning | Chapter 12 |
| III.17 | E | Flaw | Chapter 9 |
| III.18 | B | Strengthen | Chapter 8 |
| III.19 | A | Point at issue | Chapter 11 |
| III.20 | D | Necessary assumption | Chapter 7 |
| III.21 | D | Principle | Chapter 13 |
| III.22 | E | Sufficient assumption | Chapter 7 |
| III.23 | A | Flaw | Chapter 9 |
| III.24 | C | Parallel flaw | Chapter 12 |
| III.25 | B | Evaluate | Chapter 8 |

:::

Use the question-type map below to return to the appropriate lessons after blind review. Review questions you answered correctly but flagged, not only missed questions.

| Question type | Review chapter |
| --- | --- |
| Necessary and sufficient assumption | Chapter 7 |
| Strengthen, weaken and evaluate | Chapter 8 |
| Flaw | Chapter 6 and 9 |
| Must be true and most strongly supported | Chapter 10 |
| Main conclusion, method, role, point at issue | Chapter 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Resolve paradox and principle | Chapter 13 |
| RC main point, detail, inference, attitude, function, organization, application | Chapter 15 and 18 |
| RC comparative agreement, disagreement and responses | Chapter 17 |
| Blind review and error log | Chapter 22 and 23 |
