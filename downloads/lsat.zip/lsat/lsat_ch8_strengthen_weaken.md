---
title: "Strengthen & Weaken"
source: "lsat_ch8_strengthen_weaken.html"
---

Part II · Chapter 8

# Strengthen & Weaken

Two sides of one coin, and together among the most common questions on the test. Both live in the gap you learned to find — one reinforces the bridge across it, the other pulls a plank loose.

**Est. study time:** 65–80 min — **Sections:** 4 — **Practice:** 24+ items

## Overview

Strengthen and Weaken questions ask you to find the answer that makes the conclusion *more* likely (strengthen) or *less* likely (weaken). They're mirror images, so we teach them together: whatever weakens an argument, its opposite tends to strengthen it. Crucially, you do **not** have to prove or disprove the conclusion — just move the needle. And because most of these questions attack or defend an *assumption*, everything from Chapters 4, 6, and 7 pays off directly here.

You'll learn the core move (act on the gap), the special and heavily-tested case of **causal** arguments (where five standard strengtheners and weakeners recur), and how **degree and scope** separate a real answer from a trap that's technically on-topic but too weak or too extreme.

:::callout-tip
Prerequisites

Chapter 4 (the gap), Chapter 6 (causal and other flaws), Chapter 7 (assumptions — a strengthener often affirms the necessary assumption; a weakener denies it). If those are shaky, review them first; this chapter leans on all three.
:::

## 8.1 · Helping vs. hurting the conclusion

:::callout-intuition
Intuition first

Picture the argument as a bridge from premises to conclusion, resting on an assumption. To **strengthen**, you reinforce that assumption or add a supporting beam — the conclusion becomes more believable. To **weaken**, you knock out a support or reveal a crack — the conclusion becomes shakier. You're not building or demolishing the whole bridge; you're just making it sturdier or wobblier. Even a modest push counts.
:::

:::definition
**Definition 8.1 — Strengthen / Weaken.** A *strengthen* answer, if true, makes the conclusion *more likely* to hold; a *weaken* answer, if true, makes it *less likely*. Neither must be decisive — "most strengthens/weakens" asks only for the biggest push in the right direction. Stems: strengthen — "most supports," "most strengthens," "provides the most support for"; weaken — "most undermines," "most seriously weakens," "casts most doubt on," "calls into question."
:::

### The method: find the gap, then act on it

1. Identify the **conclusion** and the **gap/assumption** (Chapters 4, 7).
2. **Pre-phrase:** to strengthen, affirm the assumption or rule out an objection; to weaken, deny the assumption or raise an objection.
3. Match to the choice that acts on *this* gap — not one that's merely on the same topic.

:::callout-key
The link to assumptions

A strengthener and a necessary assumption are cousins: the assumption is what the argument *needs*; a strengthener *supports* that need (sometimes it's the assumption itself, sometimes just help toward it). A weakener is the assumption's *enemy* — it asserts the thing whose negation the argument depends on. So if you found the assumption in a Chapter 7 way, you already know what strengthens and weakens: affirm it or attack it.
:::

:::example
Worked Example 8.1 — the same gap, both directions

standard

"The company should switch to the new supplier, because the new supplier's parts are cheaper."

**Gap.** Cheaper parts → should switch assumes the cheaper parts aren't worse in some way that outweighs the savings (quality, reliability, delivery).

**Strengthener (pre-phrased):** "The new supplier's parts are just as reliable as the current ones." — affirms the assumption; switching looks smart.

**Weakener (pre-phrased):** "The new supplier's parts fail twice as often, causing costly downtime." — denies the assumption; the savings are illusory.

Both answers act on the identical gap (are the cheaper parts secretly worse?), in opposite directions.

**Teaching point:** once you name the gap, strengthen and weaken answers write themselves. On the real test you'll pick from five choices, but your pre-phrase tells you exactly what to hunt for.
:::

:::callout-pitfall
Watch out for these mistakes

- **Thinking you must prove/disprove the conclusion.** You only need to shift its likelihood. A choice that makes it "somewhat less plausible" can be the credited weakener.
- **Picking an on-topic but inert answer.** Same subject ≠ acts on the gap. The choice must bear on the *conclusion's* support (true-but-useless flavor, Chapter 4).
- **Reversing direction.** On Weaken, the trap is often a strong *strengthener* (and vice versa). Confirm which way the stem points before committing.
- **Ignoring your pre-phrase.** Diving into choices without predicting is how the opposite-direction trap catches you.
:::

### Practice — 8.1

:::problem[Q1]{difficulty="easy"}
Does a Weaken answer have to prove the conclusion false?

::::solution[Solution]
**No.** It only has to make the conclusion *less likely* — introduce doubt or an objection. "Most weakens" asks for the biggest push against, not a disproof.
::::
:::

:::problem[Q2]{difficulty="standard"}
"We should adopt a four-day week; a trial team was more productive on it." Pre-phrase one strengthener and one weakener.

::::solution[Solution]
Gap: the trial team's gain would generalize / wasn't due to something special about that team. **Strengthener:** "the trial team was typical of the company." **Weakener:** "the trial team was a hand-picked group of top performers" (so the gain won't generalize). Both act on whether the trial result transfers.
::::
:::

:::problem[Q3]{difficulty="standard"}
On a Strengthen question about whether a tax will cut smoking, an answer says "the tax will raise significant revenue." Why is it wrong?

::::solution[Solution]
**True but useless / off-gap.** Revenue is a different outcome from *smoking rates*; it doesn't bear on whether the tax reduces smoking. On-topic-ish, but it doesn't act on the conclusion's gap.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Explain how a Chapter 7 necessary assumption converts into both a strengthener and a weakener.

::::solution[Solution]
The necessary assumption is what the argument requires (e.g., "no other factor caused the result"). **Affirming** it — "no other factor was present" — *strengthens*. **Denying** it — "another factor was present" — *weakens* (indeed the negation used in the negation test *is* a maximal weakener). One assumption yields both answers by direction.
::::
:::

## 8.2 · Strengthening & weakening causal arguments

:::callout-intuition
Intuition first

Causal arguments (X causes Y) are the most common target of Strengthen/Weaken, and they have a *predictable* menu of attacks and defenses drawn straight from the causal flaw (Chapter 6). If you memorize this menu, causal questions become almost mechanical: you know in advance the five shapes a weakener can take and the five shapes a strengthener can take.
:::

:::definition
**The causal menu.** For a conclusion "X causes Y":

| To WEAKEN, show… | To STRENGTHEN, show… |
| --- | --- |
| an alternative cause of Y | no plausible alternative cause |
| Y occurs without X | when X is absent, Y is absent |
| X occurs without Y | when X is present, Y follows |
| the causation is reversed (Y causes X) | the causal order can't be reversed |
| the correlation is coincidental | the correlation holds across many cases |
:::

:::example
Worked Example 8.2 — weaken a causal claim

standard

"Employees who attended the new training program had higher sales afterward. The training program improved their sales performance."

**Stem.** Which one, if true, most weakens the argument?

- **(A)** Only the company's most ambitious employees volunteered for the training.
- **(B)** Some employees enjoyed the training.
- **(C)** Sales rose company-wide, including among those who did not attend.
- **(D)** The training lasted three days.
- **(E)** The training program was expensive to run.

Answer: (C) (with (A) a strong secondary weakener).

**How we get there.** Conclusion: training caused higher sales. Menu weakeners: alternative cause, Y-without-X, reversed causation, coincidence. (C) shows **Y without X** — sales rose even among non-attendees — implying something *other* than the training drove sales (a market-wide boom). That directly undercuts the causal claim. (A) is also a genuine weakener via **alternative cause / selection**: the attendees were the already-ambitious, so their sales might have risen regardless. Between them, (C) most cleanly severs training from the effect for everyone. Traps: (E), (D) are true-but-useless; (B) is irrelevant. **Teaching point:** the menu told you what to look for before you read the choices.
:::

:::example
Worked Example 8.3 — strengthen a causal claim

challenge

"After the town added fluoride to its water, cavities among children dropped sharply. The fluoride caused the decline in cavities."

**Stem.** Which one, if true, most strengthens the argument?

- **(A)** Dentists generally recommend fluoride.
- **(B)** Cavities can also be reduced by regular brushing.
- **(C)** Fluoride is inexpensive to add to water.
- **(D)** A neighboring town that did not add fluoride saw no change in children's cavities over the same period.
- **(E)** Some children in the town do not drink tap water.

Answer: (D).

**How we get there.** To strengthen "fluoride caused the drop," rule out alternative causes. (D) is a **controlled comparison**: a similar town *without* fluoride saw *no* decline — so a general trend (better diets, less sugar) isn't the cause; the difference tracks the fluoride. That's the "when X absent, Y absent" strengthener, and it's the strongest kind. Traps: (B) actually *weakens* by offering an alternative cause (brushing); (A) is appeal-to-authority, off-gap; (C), (E) are irrelevant or slightly unhelpful. **Teaching point:** a comparison group that differs only in the cause is the gold-standard causal strengthener.
:::

:::callout-pitfall
Watch out for these mistakes

- **Missing that "an alternative cause exists" weakens** even if it doesn't disprove X. The mere *availability* of another explanation dents a causal claim.
- **Picking the reversed-direction trap.** On causal Strengthen, a weakener (e.g., an alternative cause like (B) above) is a classic decoy. Check direction.
- **Overvaluing appeals to authority or cost.** "Experts recommend it," "it's cheap" don't bear on the causal link.
:::

### Practice — 8.2

:::problem[Q1]{difficulty="standard"}
"Students who ate breakfast scored higher on the exam, so breakfast improves exam scores." Give a menu weakener.

::::solution[Solution]
Any of: an **alternative cause** ("breakfast-eaters also slept more"), **reversed causation** is awkward here, or a **selection** effect ("more organized students both eat breakfast and study more"). E.g., "students who eat breakfast tend to come from homes that also provide tutoring." That offers another cause of the higher scores.
::::
:::

:::problem[Q2]{difficulty="standard"}
Same argument. Give a menu strengthener.

::::solution[Solution]
Rule out alternatives / show X-absent → Y-absent: e.g., "In a controlled study, the same students scored lower on days they skipped breakfast, with all else held constant." That isolates breakfast as the cause.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Sales rose after we launched the loyalty program, so the program boosted sales." Which weakens more: "a competitor went out of business that month" or "the program was popular with customers"? Why?

::::solution[Solution]
"**A competitor went out of business that month**" — it supplies an **alternative cause** for the sales rise, undercutting the causal claim. "Popular with customers" is vague and if anything mildly supportive; it doesn't sever the link.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does a comparison/control group that differs *only* in the suspected cause make such a powerful strengthener?

::::solution[Solution]
Because it eliminates alternative explanations by design: if two groups are alike in every relevant respect except the cause, and only the group *with* the cause shows the effect, then rival factors (trends, selection, coincidence) are ruled out and the cause is isolated. It converts a mere correlation into something much closer to a controlled demonstration — hitting several menu items at once.
::::
:::

## 8.3 · Degree & scope — how much, about what

:::callout-intuition
Intuition first

Two answers can both point the "right way" and still differ enormously in power. One barely nudges the conclusion; the other slams it. And an answer can address the wrong *scope* — the right topic but not the exact claim, or a bigger/smaller group than the conclusion is about. "Most strengthens/weakens" means you want the choice with the most force *on the actual conclusion*. Reading degree words and matching scope precisely is what separates a 158 from a 168 on these questions.
:::

### Degree: match the strength of the answer to the job

When two choices both weaken (or both strengthen), the **stronger, more direct** one usually wins. "The parts fail *twice as often*" weakens more than "the parts *might* occasionally fail." But beware the flip side: an answer can be **too extreme** to be true or relevant, or can overshoot the conclusion's modest claim.

:::definition
**Definition 8.2 — Scope match.** The credited answer must act on the *conclusion's actual claim* — same subject, same outcome, same population, same time frame. Common scope traps: right topic but wrong *outcome* (revenue vs. profit); right claim but wrong *group* (addresses all customers when the conclusion is about new customers); or a comparison the conclusion never made.
:::

:::example
Worked Example 8.4 — degree decides between two weakeners

challenge

"The airline's on-time rate will improve next year, because it is adding more ground crew at its busiest airports."

**Stem.** Which one, if true, most weakens the argument?

- **(A)** The airline's competitors are also hiring ground crew.
- **(B)** The airline's competitors are also adding ground crew at their busiest airports.
- **(C)** Ground crew wages have risen in recent years.
- **(D)** A few of the new ground crew are still in training.
- **(E)** Most of the airline's delays are caused by weather and air-traffic congestion, which more ground crew cannot address.

Answer: (E).

**How we get there.** Both (D) and (E) point the right way (against improvement), so **degree** decides. (D) is a tiny dent — "a few… still in training" barely affects the on-time rate. (E) is devastating: if *most* delays come from weather and congestion, then adding ground crew — the argument's whole mechanism — can't fix the main cause, so the predicted improvement is undercut at its root. (E) has vastly more force on the actual conclusion. Traps: (A), (C) are off-gap. **Teaching point:** when two answers agree in direction, pick the one that strikes the *central* support hardest.
:::

:::example
Worked Example 8.5 — scope trap

standard

"Our new website design will increase purchases by first-time visitors, because it makes the checkout process simpler."

**Stem.** Which one, if true, most strengthens the argument?

- **(A)** In user tests, first-time visitors completed checkout more often with the new design than with the old one.
- **(B)** The old design's checkout had more steps than any competitor's.
- **(C)** The new design loads slightly faster.
- **(D)** Simpler checkouts are common on competitor sites.
- **(E)** Returning customers report liking the new design.

Answer: (A).

**How we get there.** The conclusion's scope is *first-time visitors* and *purchases/checkout*. (A) matches exactly: first-time visitors, completing checkout more often with the new design — direct support. (E) is a **scope mismatch**: *returning* customers, not first-time visitors, and "liking" isn't "purchasing." (C) and (D) are off-gap. **Teaching point:** an answer about the right topic but the wrong *group* or wrong *outcome* is a trap; demand a match on subject, population, and outcome.
:::

:::callout-pitfall
Watch out for these mistakes

- **Choosing a weak answer because it's "technically" right.** On "most" questions, force matters — pick the biggest push.
- **Falling for a scope shift.** Right topic, wrong group/outcome/timeframe is the most common near-miss trap.
- **Over-rewarding extreme wording.** Strong is good *if* it stays on the conclusion; an over-broad claim that misses the actual point still loses.
:::

### Practice — 8.3

:::problem[Q1]{difficulty="standard"}
Conclusion is about reducing *childhood* obesity. An answer shows a policy reduced obesity among *adults*. Strong answer?

::::solution[Solution]
**No — scope mismatch** (wrong population: adults vs. children). Even if strongly worded, it doesn't act on the conclusion's actual group. A credited answer must address childhood obesity.
::::
:::

:::problem[Q2]{difficulty="standard"}
Two weakeners: (i) "the plan may face some opposition"; (ii) "the plan is illegal under current law and cannot be implemented." Which weakens more and why?

::::solution[Solution]
**(ii)**, by far. "May face some opposition" is a weak nudge; "illegal and cannot be implemented" strikes the plan's very feasibility. Same direction, far greater degree.
::::
:::

:::problem[Q3]{difficulty="standard"}
Conclusion: "the drug reduces *heart attacks*." An answer: "the drug lowers cholesterol." Strengthen, and how strongly?

::::solution[Solution]
Only **weakly / indirectly** — it's a plausible mechanism but a *different outcome* (cholesterol, not heart attacks). A direct answer would show reduced heart attacks. Watch the outcome scope; a mechanism isn't the endpoint.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why can a strongly-worded answer still lose to a moderately-worded one on a "most strengthens" question?

::::solution[Solution]
Because **scope beats raw strength**. A powerful claim about the wrong group, outcome, or timeframe does nothing for the actual conclusion, while a moderate claim that lands squarely on the conclusion's exact assumption genuinely raises its likelihood. Force only counts when it's aimed at the right target.
::::
:::

## 8.4 · Drill set

Ten mixed Strengthen/Weaken questions. Read the stem's direction first, find the gap, pre-phrase, then choose. Difficulty rises through the set.

:::problem[1]{difficulty="easy"}
"The café should start opening at 6 a.m., because many commuters pass by before 7." *Most strengthens?*

- **(A)** The café's staff are willing to begin work at 5:30 a.m.
- **(B)** A large share of those early commuters regularly buy coffee on their way to work.
- **(C)** The café has plenty of seating.
- **(D)** Rent in the area is high.
- **(E)** The café's coffee is highly rated.

::::solution[Solution]
**(B).** The gap: commuters passing by must actually become customers. (B) affirms it. (E),(C),(D) are off-gap.
::::
:::

:::problem[2]{difficulty="standard"}
"Our city's new curfew reduced youth crime, since youth crime fell after it took effect." *Most weakens?*

- **(A)** The curfew was enforced more strictly in its second year than in its first.
- **(B)** Police supported the curfew.
- **(C)** Youth crime also fell in cities without curfews during the same period.
- **(D)** The curfew was unpopular with teenagers.
- **(E)** The curfew applies only after 10 p.m.

::::solution[Solution]
**(C).** A menu weakener — Y fell without X elsewhere, pointing to a broader cause (alternative cause). Undercuts the curfew as the reason. Others are off-gap.
::::
:::

:::problem[3]{difficulty="standard"}
"This fertilizer increases crop yield; fields using it produced more than fields that didn't." *Most weakens?*

- **(A)** The fertilizer costs more per acre than conventional alternatives.
- **(B)** Some farmers dislike the fertilizer's smell.
- **(C)** The fertilizer is sold nationwide.
- **(D)** The fertilized fields also received more rainfall this season.
- **(E)** The fertilizer is organic.

::::solution[Solution]
**(D).** Alternative cause (more rainfall) for the higher yield. Classic causal weakener. Others irrelevant.
::::
:::

:::problem[4]{difficulty="standard"}
"Reading aloud to toddlers boosts their vocabulary; toddlers read to daily had larger vocabularies." *Most strengthens?*

- **(A)** Most of the toddlers in the study were between two and three years old.
- **(B)** Many popular children's books have simple vocabulary.
- **(C)** Toddlers enjoy being read to.
- **(D)** Vocabulary can also grow through conversation.
- **(E)** The toddlers read to daily and those not read to were similar in family income and preschool attendance.

::::solution[Solution]
**(E).** Controls for alternative causes (income, preschool), isolating reading-aloud. (D) is a weakener (alternative cause); (B),(C) off-gap.
::::
:::

:::problem[5]{difficulty="standard"}
"We should require bike helmets citywide, because helmets reduce head injuries." *Most weakens the recommendation?*

- **(A)** A mandatory-helmet law would sharply reduce the number of people who bike, decreasing the health benefits of cycling and increasing overall harm.
- **(B)** Some cyclists already wear helmets.
- **(C)** Helmets come in many colors.
- **(D)** Helmets are uncomfortable in hot weather.
- **(E)** Helmet prices have fallen substantially in recent years.

::::solution[Solution]
**(A).** Attacks the *recommendation* (not the fact that helmets help) by showing the policy's net effect could be harmful — a strong, on-conclusion weakener. Degree and scope both favor it over (D).
::::
:::

:::problem[6]{difficulty="standard"}
"The company's profits will rise after moving to a cheaper office, since rent is its biggest expense." *Most weakens?*

- **(A)** Rent has risen citywide.
- **(B)** The cheaper office is in a less accessible area, and the company expects to lose many clients as a result.
- **(C)** The new office has fewer windows.
- **(D)** The move will take one weekend.
- **(E)** The company's rent at the new office is fixed for five years.

::::solution[Solution]
**(B).** Introduces a countervailing effect (lost clients → lost revenue) that could swamp the rent savings, undercutting the profit conclusion. On-gap and high-degree.
::::
:::

:::problem[7]{difficulty="challenge"}
"The vaccine is effective: in the trial, vaccinated people caught the disease far less often than unvaccinated people." *Most weakens?*

- **(A)** The disease is rare in the region.
- **(B)** The trial lasted six months.
- **(C)** The vaccinated group was mostly young and healthy, while the unvaccinated group was older and had more chronic illness.
- **(D)** The vaccine requires two doses.
- **(E)** Some vaccinated participants reported mild soreness after the injection.

::::solution[Solution]
**(C).** Selection/alternative cause: the groups differed in baseline risk (age, health), so lower infection among the vaccinated could stem from their being healthier, not from the vaccine. Breaks the comparison. Others off-gap.
::::
:::

:::problem[8]{difficulty="challenge"}
"Our tutoring program works: students who used it improved their grades more than students who didn't." *Most strengthens?*

- **(A)** Tutors are paid hourly.
- **(B)** The program is popular.
- **(C)** Students chose whether to use the tutoring.
- **(D)** Students were randomly assigned to tutoring or no tutoring, and only the tutored group improved.
- **(E)** The tutoring program has operated for five years.

::::solution[Solution]
**(D).** Random assignment removes self-selection (the main alternative explanation), so the improvement tracks the tutoring — the strongest causal strengthener. (C) actually *weakens* (self-selection); (A),(B) off-gap.
::::
:::

:::problem[9]{difficulty="challenge"}
"The museum's late-night hours caused attendance to rise, since attendance grew after they began." *Which most weakens?*

- **(A)** The late hours run until 9 p.m.
- **(B)** Staff were paid overtime for the late hours.
- **(C)** Attendance is measured by ticket scans.
- **(D)** The museum's website was redesigned the following year.
- **(E)** The museum launched a blockbuster exhibit the same week the late hours began.

::::solution[Solution]
**(E).** Alternative cause (a blockbuster exhibit) that could explain the attendance rise instead of the late hours. Textbook causal weakener; the rest are inert.
::::
:::

:::problem[10]{difficulty="challenge"}
"Switching to remote work will cut our costs, because we'll save on office rent." *Most weakens?*

- **(A)** The company would have to pay to equip and support home offices, and productivity losses would raise other costs by more than the rent saved.
- **(B)** Remote work is increasingly common.
- **(C)** The current office lease ends soon.
- **(D)** The company's current office rent is above the city average.
- **(E)** Employees prefer working from home.

::::solution[Solution]
**(A).** Shows offsetting costs that exceed the rent savings, undercutting the "cut our costs" conclusion at its core — high degree, on-gap. (E),(B) off-gap; (C) is neutral-to-helpful.
::::
:::

## Chapter summary

:::summary
#### Strengthen & Weaken, distilled

- **Act on the gap.** Find the assumption; to strengthen, affirm it/rule out objections; to weaken, deny it/raise an objection. No need to prove or disprove.
- **Causal arguments have a menu.** Weaken with alternative cause, Y-without-X, X-without-Y, reversed causation, or coincidence; strengthen with the opposites (esp. a controlled comparison).
- **Degree matters.** On "most" questions, pick the answer with the greatest force on the *central* support.
- **Scope must match.** Same subject, outcome, population, timeframe. Right-topic/wrong-group is the top trap.
- **Check direction.** The opposite-direction answer is a favorite decoy — confirm strengthen vs. weaken before you commit.
:::

LSAT Mastery — Chapter 8. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
