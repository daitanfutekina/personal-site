---
title: "Building Your Plan"
source: "lsat_ch21_building_plan.html"
---

Part V · Chapter 21

# Building Your Plan

You know the test cold now. This chapter turns knowledge into a plan: find your real weaknesses with a diagnostic, learn the types before grinding volume, and drill in the order that actually builds skill.

**Est. study time:** 40–50 min — **Sections:** 4 — **Practice:** 14+ items

## Overview

Parts I–IV taught you *what* the LSAT tests and *how* to handle every part of it. Part V teaches you how to *train* — because the LSAT is a skill (Chapter 1), and skills improve through structured practice, not knowledge alone. This chapter is the foundation of your training: take an honest diagnostic to find where you actually lose points, translate that into a gap analysis, and then practice in the right sequence — learn the types first, drill them by type, then mix. Get the *order* of training right and every hour you spend converts to more points than random practice ever would.

:::callout-tip
Prerequisites

Chapter 1 (skill test, trained through reps + feedback) and Chapter 3 (careless-error recovery is high-yield; the curve rewards mid-range gains). This chapter operationalizes both. The next chapter (22, blind review) is the feedback engine that makes this plan work.
:::

:::callout-key
The whole plan in one line

**Diagnose → learn the types → drill by type → drill mixed → take full tests → review everything obsessively.** This chapter covers the first four; Chapters 22–24 cover review and full-test practice. The order is not arbitrary — each stage builds the foundation the next one needs.
:::

## 21.1 · The diagnostic & gap analysis

:::callout-intuition
Intuition first

You can't fix what you can't see. Before building any study plan, you need an honest picture of where you stand and — more importantly — *which specific things* cost you points. That's what a diagnostic gives you: not just a score, but a map of your weaknesses. A test-taker who knows "I miss Strengthen questions and I run out of time on the last RC passage" can target exactly those; one who only knows "I got a 154" is studying blind.
:::

:::definition
**Definition 21.1 — Diagnostic & gap analysis.** A *diagnostic* is a full, timed, official practice test taken under real conditions before (or early in) your prep. A *gap analysis* is what you do with it: categorize every miss by **question type**, **section**, and **cause** (didn't know the concept vs. knew it but ran out of time vs. careless error), producing a ranked list of what to fix.
:::

### How to run the diagnostic

- **Use a real, official test** (LawHub — Chapter 24/Appendix H) in the official digital interface. Third-party imitations won't diagnose accurately.
- **Timed, full length, one sitting** — including a fifth experimental-style section if you can, to feel real fatigue (Chapter 2).
- **No help, no pausing.** An inflated diagnostic hides the very weaknesses you need to find.
- **Record everything:** your score, your per-section performance, and — crucially — *every question you missed or guessed on.*

:::example
Worked Example 21.1 — turning misses into a plan

standard

**Scenario.** A diagnostic of 156. The misses break down as: 6 Logical Reasoning misses (4 Assumption/Strengthen, 2 Flaw), 3 RC misses (all on the last passage, rushed), and 2 LR misses that were careless (misread the stem).

**Question.** What's the gap analysis and the resulting priorities?

Analysis: (1) a concept gap in Assumption/Strengthen (the biggest cluster), (2) a timing gap in RC (last-passage rush), (3) careless stem-misreading in LR. Priorities: drill Assumption/Strengthen first, fix RC pacing/ordering, and build a stem-reading habit.

**How we get there.** Sort the 11 misses by cause. The 4 Assumption/Strengthen misses are a *concept* gap — the largest single cluster and the highest-yield fix (revisit Chapters 7–8, then drill those types). The 3 RC misses share a *cause*, not a type: all on a rushed final passage — that's a *pacing/ordering* problem (Chapter 19), fixed by triage, not by RC content. The 2 careless LR misses (misread stems) are an *execution* problem, fixed by the habit of reading the stem first (Chapter 4). Notice how the *same score* hides three different problems with three different fixes — which is exactly why a gap analysis beats a bare number. **Teaching point:** categorize by cause, then let the biggest, most fixable cluster set your first priority.
:::

:::callout-pitfall
Watch out for these mistakes

- **Taking an "easy" diagnostic.** Pausing, un-timing, or looking things up produces a flattering score that hides your real gaps. Keep it honest.
- **Recording only the score.** The number is nearly useless alone; the *breakdown of misses by type and cause* is the point.
- **Confusing a timing problem with a concept problem.** Missing questions because you rushed is a pacing fix, not a "study that type harder" fix — distinguish them (this is what blind review, Chapter 22, formalizes).
:::

### Practice — 21.1

:::problem[Q1]{difficulty="easy"}
What's the difference between a diagnostic score and a gap analysis?

::::solution[Solution]
The **score** is a single number; the **gap analysis** categorizes your misses by type, section, and *cause* — producing a ranked list of what to fix. The analysis, not the number, drives your plan.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why take the diagnostic timed, full-length, and without help?

::::solution[Solution]
So it reveals your **true** weaknesses. Pausing or un-timing inflates the score and hides the gaps (pacing, endurance, shaky types) you most need to find and fix.
::::
:::

:::problem[Q3]{difficulty="standard"}
Three "causes" you should sort each missed question into?

::::solution[Solution]
**Concept gap** (didn't know how to do it), **timing** (could do it but ran out of time), and **careless error** (knew it but slipped). Each has a different fix.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Two students both score 158. Why might their study plans look completely different?

::::solution[Solution]
Because the **same score can come from very different mixes of misses**. One might lose points to a Logical Reasoning concept gap (fix: study/drill those types); the other to RC timing and careless errors (fix: pacing/ordering and an execution habit). The gap analysis — not the score — determines the plan, so identical numbers can demand opposite priorities.
::::
:::

## 21.2 · Learn the types before grinding volume

:::callout-intuition
Intuition first

A tempting but wrong instinct is to "just do lots of questions." Volume without understanding entrenches bad habits — you practice your mistakes. The right sequence is **strategy first, volume second**: learn what each question type asks and the method for it (which this whole course taught), *then* drill. Knowing that a stem is a "Necessary Assumption" tells you to run the negation test; a "Paradox" tells you to reconcile two facts. Without that recognition, extra questions just repeat errors faster.
:::

:::definition
**Definition 21.2 — Strategy before volume.** The principle that you should learn each question type's *task and method* before doing high-volume practice on it. Recognition (naming the type and knowing its approach) must precede repetition, or the repetition reinforces guesswork rather than skill.
:::

:::callout-key
Why volume-first backfires

Doing hundreds of questions before you understand the types produces the illusion of work with little gain: you repeat the same misreadings, "learn" idiosyncratic tricks that don't generalize, and burn through official material (a limited resource) without the framework to learn from it. Learn the method first, and every subsequent question *teaches* you something because you can see *why* you got it right or wrong. This is why the course front-loaded the types (Parts II–III) before this planning chapter.
:::

:::callout-pitfall
Watch out for these mistakes

- **"Just do more questions."** Volume without method entrenches mistakes and wastes limited official material.
- **Skipping the boring part.** Learning type methods feels slower than grinding, but it's what makes grinding pay off. Don't skip it.
- **Burning official tests early.** Do concept-learning and type-drills on older/practice material; save fresh full PrepTests for timed practice once you have the method (Chapter 24).
:::

### Practice — 21.2

:::problem[Q1]{difficulty="easy"}
Strategy or volume first, and why?

::::solution[Solution]
**Strategy first.** Learn each type's task and method before high-volume drilling, so practice builds skill instead of entrenching mistakes. Recognition must precede repetition.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why does "just do 1,000 questions" tend to disappoint?

::::solution[Solution]
Because without the method, you **repeat the same errors**, adopt non-generalizing tricks, and burn limited official material — lots of activity, little gain. Method-first practice makes each question actually teach you something.
::::
:::

:::problem[Q3]{difficulty="standard"}
Once you can name a stem as "Necessary Assumption," what does that immediately tell you to do?

::::solution[Solution]
Apply the **negation test** (Chapter 7) — negate a choice and see if the argument collapses. Recognition of the type triggers the right method; that's the payoff of learning types first.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is official LSAT material worth "saving," and how does that shape when you do volume?

::::solution[Solution]
Because official questions are a **limited, non-renewable resource** — the most accurate practice exists in a finite supply of released PrepTests. If you grind them early without method, you waste your best timed-practice material before you can learn from it. So: learn methods and do early type-drills economically, and reserve fresh full PrepTests for *timed* practice once your method is in place (Chapter 24), maximizing the diagnostic value of each real test.
::::
:::

## 21.3 · Drilling by type, then mixed

:::callout-intuition
Intuition first

Once you know the methods, practice in two phases. First, **drill one question type at a time** — twenty Weaken questions in a row — until the pattern becomes automatic and you can feel the gap without effort. Then switch to **mixed practice** that mirrors the real test, where questions arrive in random order and your first job is to *identify the type on the fly*. Type-drilling builds the recognition and method; mixed drilling builds the test-day skill of applying them cold. You need both, in that order.
:::

:::definition
**Definition 21.3 — Type-drilling vs. mixed practice.** *Type-drilling*: repeated practice of a single question type in a block, to internalize its method (isolation builds the skill). *Mixed practice*: sets or full sections with question types in random order, to build the test-day ability to recognize the type and switch methods on demand (integration applies the skill). Progress from the first to the second as each type solidifies.
:::

:::callout-key
Why the two-phase order works

Blocked (single-type) practice gives fast, clear feedback on one skill — you see the pattern quickly because every question is the same kind. But the real test never announces the type, so pure blocked practice leaves you unprepared for the *recognition* demand. Mixed practice trains that recognition. Do blocked first (to build each method), then mixed (to integrate them). Skipping straight to mixed before the methods are solid means you're guessing at both the type *and* the approach at once — too much to learn simultaneously.
:::

:::example
Worked Example 21.2 — sequencing a weak type

standard

**Scenario.** Your gap analysis (21.1) flagged Assumption/Strengthen as your worst types. How do you attack them?

Answer: (1) Re-learn the method (Chapters 7–8). (2) Type-drill: do blocks of Necessary Assumption, then Strengthen, until the negation test and gap-attack are automatic. (3) Mix them back into full LR sets so you can distinguish and apply them cold. (4) Blind-review every miss throughout.

**How we get there.** Start with method (re-read the relevant chapters), because volume-first would just repeat your errors (21.2). Then isolate: a block of, say, 15 Necessary Assumption questions trains the negation test until it's reflexive; a block of Strengthen questions trains gap-affirming. Once each feels automatic in isolation, reintegrate them into mixed LR sections — now the challenge is *recognizing* "is this Assumption or Strengthen?" under time, which only mixed practice builds. Throughout, blind review (Chapter 22) tells you whether remaining misses are concept or timing. **Teaching point:** weak type → method → blocked drills → mixed reintegration → review. That loop, repeated per weak type, is the engine of improvement.
:::

:::callout-pitfall
Watch out for these mistakes

- **Only ever doing mixed practice.** Without blocked drilling first, weak types never get the concentrated reps they need to become automatic.
- **Only ever doing blocked practice.** Without mixed practice, you never train the test-day skill of identifying the type cold — you'll be slow and unsure when types are shuffled.
- **Not letting your gap analysis pick the drills.** Drill your *weakest* types most, not your favorites. Let the data (21.1) and your error log (Chapter 23) set the agenda.
:::

### Practice — 21.3

:::problem[Q1]{difficulty="easy"}
What does type-drilling build, and what does mixed practice build?

::::solution[Solution]
Type-drilling builds **the method/recognition of a single type** (through isolated reps); mixed practice builds **the test-day skill of identifying the type on the fly and switching methods**. You need both, blocked first.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why do blocked drills before mixed sets?

::::solution[Solution]
Because blocked drills give fast, focused feedback that makes each type's method **automatic** first; jumping to mixed too early means learning both *type recognition* and *method* at once — too much simultaneously, so the method never solidifies.
::::
:::

:::problem[Q3]{difficulty="standard"}
What decides which types you drill most?

::::solution[Solution]
Your **gap analysis and error log** — drill your *weakest* types most heavily, not the ones you already enjoy or ace. Let the data set the agenda.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Someone only does full mixed sections and plateaus on Flaw questions. Diagnose and prescribe.

::::solution[Solution]
**Diagnosis:** mixed-only practice spreads attention across all types, so a specific weak type (Flaw) never gets concentrated reps — it stays weak while everything else improves. **Prescription:** pause and **block-drill Flaw questions** (re-learn the catalog, Chapters 6/9; do a run of Flaw-only questions with blind review) until the type feels automatic, then reintegrate into mixed sections. Targeted isolation breaks the plateau that mixed practice alone can't.
::::
:::

## 21.4 · Scenario drills

Six planning scenarios. Decide your move, then check.

:::problem[1]{difficulty="easy"}
You're about to start prep and haven't taken a diagnostic. First step?

::::solution[Solution]
**Take a full, timed, official diagnostic** under real conditions, then do a gap analysis. You need to know your baseline and weaknesses before building any plan.
::::
:::

:::problem[2]{difficulty="standard"}
Your diagnostic misses cluster in RC's last passage (all rushed). Is the fix "study RC harder"?

::::solution[Solution]
**No** — the cause is **timing/ordering**, not RC concepts. Fix with passage triage and pacing (Chapter 19), not more RC content study. Match the fix to the cause.
::::
:::

:::problem[3]{difficulty="standard"}
You want to "just grind 500 LR questions" this week. Better approach?

::::solution[Solution]
Learn/refresh the type **methods first**, then drill your *weakest* types in blocks with blind review, then mix. Grinding without method entrenches errors and wastes material.
::::
:::

:::problem[4]{difficulty="standard"}
You've block-drilled Weaken until it feels automatic. Next step?

::::solution[Solution]
**Reintegrate it into mixed LR sets** so you practice *recognizing* Weaken among other types under time — the test-day skill. Then move blocked drilling to your next weakest type.
::::
:::

:::problem[5]{difficulty="challenge"}
You have only 5 weeks and a big gap. How does gap analysis help you allocate?

::::solution[Solution]
It lets you **concentrate limited time on the highest-yield fixes**: attack the largest, most fixable clusters first (often a couple of LR types plus careless-error cleanup, which Chapter 3 showed is high-yield in the mid-range), and don't spread effort evenly across things you already do well. With little time, precision about *what* to fix matters most.
::::
:::

:::problem[6]{difficulty="challenge"}
In one or two sentences, state the correct training order and why each stage precedes the next.

::::solution[Solution]
**Diagnose → learn types → block-drill → mixed practice → full tests → review throughout.** Each precedes the next because you can't target weaknesses you haven't diagnosed, can't drill productively without the method, can't recognize types cold without first automating them in isolation, and can't build endurance/pacing without full tests — with blind review (Chapter 22) as the feedback loop that makes every stage actually improve you.
::::
:::

## Chapter summary

:::summary
#### Building your plan, distilled

- **Start with an honest diagnostic** (full, timed, official) and a *gap analysis* — sort misses by type, section, and cause (concept / timing / careless).
- **Match the fix to the cause:** concept gaps → study & drill that type; timing → pacing/ordering; careless → execution habits.
- **Strategy before volume.** Learn each type's method before grinding, or you entrench mistakes and waste limited official material.
- **Block-drill, then mix.** Isolated reps automate a type's method; mixed practice builds test-day type-recognition. Do both, in that order.
- **Let the data set the agenda:** drill your *weakest* types most, guided by your gap analysis and error log (Chapter 23).
:::

LSAT Mastery — Chapter 21. Independent study material, not affiliated with LSAC. Use official LSAC PrepTests for diagnostics and timed practice.
