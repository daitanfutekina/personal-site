---
title: "Practice Test 2"
source: "markdown"
---

Part VI · Chapter 29

# Practice Test 2

An original 77-question examination in two Logical Reasoning sections and one Reading Comprehension section, followed by complete, answer-first worked solutions.

## Overview

Take all three sections **in one sitting**, allowing **35 minutes per section** and a **10-minute break after Section II**. Use a timer; on the actual LSAT, there is also an unscored experimental section, not reproduced in this three-scored-section exercise. Do not open any solution until every section is complete.

**Flag, don't guess silently.** Write down the number of each question you are uncertain about, even if you choose an answer. After the timed sitting, blind-review every flagged question *untimed*, without looking at the answers (Chapter 22). Only then check the key, review all four wrong choices for each miss, and record recurring errors in your log (Chapter 23).

This test was **written originally for this book**. It is **not** an official LSAC PrepTest and has not been equated or statistically calibrated. Official PrepTests on LawHub remain the gold standard for measuring readiness under timed conditions (Chapter 24).

## 29.1 Section I: Logical Reasoning

**25 questions · 35 minutes**

:::problem[Question I.1]
A phone maker insists that customers benefit when its repairs are sold through an annual subscription rather than priced individually. Its spokesperson points out that subscribers pay less per repair than nonsubscribers. Yet subscriptions renew whether or not customers request a repair, and the company’s own records show that most subscribers need no repairs during a typical year. A cheaper price for an event that seldom occurs does not establish a cheaper total expense. Thus, before calling the subscription a consumer benefit, the company ought to compare what customers actually spend under each plan.

Which one of the following most accurately expresses the main conclusion of the argument?

- **(A)** The company should discontinue the subscription plan even for customers who save money by using it.
- **(B)** Repair subscriptions are necessarily more expensive for every customer.
- **(C)** Subscribers pay less for each individual repair than nonsubscribers do.
- **(D)** Most subscribers do not need repairs in a typical year.
- **(E)** The company should compare customers’ actual total spending under the subscription and per-repair plans before claiming the subscription benefits them.

::::solution[Solution]
**Answer:** (E)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** The company ought to compare total customer spending before advertising a benefit.
2. **Support.** Per-repair discounts do not settle total cost when most subscribers pay without using repairs.
3. **Prephrase.** Find the normative “thus” claim rather than a fact used to support it.
4. **Why (E) is right.** This restates the recommendation, preserving the conditional “before claiming” qualification.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Overstates the recommendation: checking total spending does not justify eliminating a plan that benefits some users.
   - **(B)** **Trap: too strong.** Too strong: heavy repair users may save.
   - **(C)** **Trap: premise for conclusion.** True background concession, not the point advocated.
   - **(D)** **Trap: premise for conclusion.** Supporting evidence about frequency, not the recommendation.

**Check:** Replace the discounted-per-repair statistic with total annual expenditures: that is the proposed test.
::::
:::

:::problem[Question I.2]
At an agricultural trial station, tomato plants beneath a new reflective shade cloth produced more fruit than plants beneath ordinary cloth. The station's manager concludes that the reflective surface itself caused the difference and recommends that local growers switch immediately. The manager notes that both plots used the same seed variety and received equal amounts of irrigation. But the trial was conducted over a single growing season, and staff assigned plants to the two plots before installing the cloth. The manager has not discussed differences in the plots' prior soil treatments.

Which one of the following, if true, most seriously weakens the manager’s argument?

- **(A)** The reflective cloth costs slightly more than ordinary cloth.
- **(B)** The station used the reflective cloth on a windier side of the field.
- **(C)** The reflective-cloth plot received a slow-release fertilizer the previous year, while the ordinary-cloth plot received none.
- **(D)** Both plots received the same hours of daylight during the trial.
- **(E)** Some growers prefer tomato varieties not included in the trial.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The reflective surface caused increased yield and merits adoption.
2. **Support.** Higher yields occurred with equal seeds and water, leaving plot history uncontrolled.
3. **Prephrase.** Look for a factor independently capable of increasing yield that traveled with the new cloth.
4. **Why (C) is right.** Unequal residual fertilizer offers a direct alternative cause of the measured yield gap.
5. **Why the others fail.**
   - **(A)** **Trap: half-right / insufficient.** Cost may affect purchase value, but not whether it caused the yield difference.
   - **(B)** **Trap: half-right / insufficient.** A difference exists, but without evidence of its effect, it does not rival the established fertility difference.
   - **(D)** **Trap: wrong direction.** Controls another variable and tends to strengthen rather than weaken.
   - **(E)** **Trap: unsupported leap.** Limits generalization but does not explain the observed plot difference as directly.

**Check:** In a matched-soil comparison, the original causal inference would be stronger; the supplied fertilizer history breaks that match.
::::
:::

:::problem[Question I.3]
A sportswear company surveyed people who voluntarily entered its six-week step-count competition. Nearly nine in ten participants reported enjoying daily exercise. The company therefore claims that almost everyone in the country enjoys exercising and that reluctance to be active is not a meaningful barrier to selling its fitness devices. Its marketing director says the survey was sufficiently large to eliminate sampling concerns: more than ten thousand responses were recorded. No one who declined to enter the competition was invited to participate in the survey.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** assumes that people who enjoy exercise also purchase fitness devices at the same rate as those who do not.
- **(B)** concludes that exercising is popular solely because some people report exercising frequently.
- **(C)** generalizes from people who selected themselves into an exercise competition to the broader population.
- **(D)** rejects the testimony of experts on exercise psychology without examination.
- **(E)** treats the absence of evidence that exercise is enjoyable as proof that it is unpleasant.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Exercise reluctance is not a meaningful general barrier because almost everyone enjoys exercise.
2. **Support.** All respondents volunteered for an exercise-focused competition; size cannot cure selection bias.
3. **Prephrase.** Name the unrepresentative-survey flaw, not a defect invented outside the argument.
4. **Why (C) is right.** The participant pool is unusually likely to enjoy exercise and cannot justify a nationwide conclusion.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Introduces a relationship between enjoyment and purchasing that is not used to infer nationwide enjoyment.
   - **(B)** **Trap: unsupported leap.** The respondents actually report enjoyment; this choice substitutes exercise frequency for an attitude survey.
   - **(D)** **Trap: half-right / insufficient.** No expert testimony is mentioned or rejected.
   - **(E)** **Trap: reversal.** Reversal: the company has positive survey responses, not an absence of evidence.

**Check:** Even a million volunteers can be unrepresentative if their willingness to participate is related to the surveyed characteristic.
::::
:::

:::problem[Question I.4]
A publisher gives translation contracts only to vendors that pass its terminology audit. Every vendor that passes the terminology audit receives access to a protected glossary. Some vendors with glossary access are also authorized to edit the publisher's marketing copy, but marketing authorization is not part of the translation-contract requirements. Last spring, several vendors applied for contracts without requesting marketing authorization, and all of the vendors awarded translation contracts had completed the terminology audit. The publisher has not said whether vendors can obtain glossary access by other means.

Which one of the following must be true on the basis of the statements above?

- **(A)** Every vendor awarded a translation contract received access to the protected glossary.
- **(B)** All vendors who completed the terminology audit obtained translation contracts.
- **(C)** At least one vendor authorized to edit marketing copy was awarded a translation contract.
- **(D)** Every vendor with glossary access was awarded a translation contract.
- **(E)** Vendors lacking marketing authorization cannot pass the terminology audit.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The task is to derive an unavoidable consequence, not assess an argument.
2. **Support.** Contract → audit passed → glossary access; marketing permission is optional and irrelevant.
3. **Prephrase.** Chain the two universal conditionals in their stated direction.
4. **Why (A) is right.** Contract → glossary access follows by transitivity for every awarded vendor.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Passing a necessary condition is not sufficient for award.
   - **(C)** **Trap: half-right / insufficient.** The groups may or may not overlap.
   - **(D)** **Trap: reversal.** Reverses the direction of the contract-to-audit-to-access chain.
   - **(E)** **Trap: unsupported leap.** Marketing permission is expressly not a contract condition.

**Check:** Diagram C → A → G. The reverse G → C is not supported.
::::
:::

:::problem[Question I.5]
A grocery chain plans to replace disposable price labels on bulk-food jars with washable electronic tags. Its operations chief predicts that the change will substantially reduce plastic waste from labeling. A pilot store did discard fewer plastic labels after adopting the tags, but the chief has calculated waste only inside the store, not at the supplier or disposal stage. Critics contend that the electronic tags' plastic casings, batteries, and eventual replacements might generate more plastic waste than the old labels. The chain intends to deploy the tags for five years.

Which one of the following, if true, most strengthens the operations chief’s prediction?

- **(A)** The pilot store sells more bulk food than most other stores.
- **(B)** Electronic tags allow the store to change prices more frequently.
- **(C)** Shoppers find digital prices easier to read than printed labels.
- **(D)** Over five years, each tag replaces thousands of disposable labels, and the plastic from tag manufacture and disposal totals far less than the labels avoided.
- **(E)** The electronic tags are partly made from reclaimed plastic rather than entirely new plastic.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The replacement will substantially reduce labeling-related plastic waste.
2. **Support.** The pilot shows fewer labels discarded, but upstream and end-of-life plastic could offset that saving.
3. **Prephrase.** Find lifecycle waste data, not a tangential advantage of digital tags.
4. **Why (D) is right.** The measured total, including manufacture and disposal, directly defeats the offset objection.
5. **Why the others fail.**
   - **(A)** **Trap: half-right / insufficient.** Might increase labels avoided, but does not resolve manufacturing and disposal waste.
   - **(B)** **Trap: unsupported leap.** An operational advantage does not quantify waste.
   - **(C)** **Trap: unsupported leap.** Addresses convenience rather than lifecycle plastic.
   - **(E)** **Trap: half-right / insufficient.** Recycled content might help, but a tag could still involve more total plastic than the discarded labels it replaces.

**Check:** Compare five-year plastic generated by tags with five-year disposable-label plastic; the former is markedly smaller.
::::
:::

:::problem[Question I.6]
A linguist predicts that a recently borrowed word will become common in the city's everyday speech within three years. The word is now frequent on a popular local podcast, and the linguist cites earlier expressions that spread from that podcast into everyday conversation. However, the podcast's audience consists largely of language enthusiasts who enjoy adopting unusual terms. The linguist argues that those earlier cases make the new prediction reasonable despite the unusual audience. The current word has not yet appeared in any of the informal-conversation recordings available to the research team.

Which one of the following is an assumption on which the linguist’s argument depends?

- **(A)** The circumstances that enabled at least some earlier podcast expressions to spread are not entirely absent for the new word.
- **(B)** Every expression featured on the podcast eventually becomes common.
- **(C)** The podcast has more listeners than all other local broadcasts combined.
- **(D)** The new word has a spelling that differs from the pronunciation used on the podcast.
- **(E)** The borrowed word originated in the city rather than elsewhere.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The new podcast word is reasonably likely to become common, given earlier podcast-to-conversation shifts.
2. **Support.** The inference uses past analogues as evidence for a new diffusion case.
3. **Prephrase.** The new case must not be wholly cut off from every relevant mechanism behind the precedents.
4. **Why (A) is right.** If all enabling circumstances of earlier successful diffusion are absent now, citing those successes provides no basis for this projection.
5. **Why the others fail.**
   - **(B)** **Trap: too strong.** Too strong: a few successful precedents suffice for the projection.
   - **(C)** **Trap: unsupported leap.** Audience supremacy is unnecessary to the analogical prediction.
   - **(D)** **Trap: half-right / insufficient.** Unusual spelling could influence diffusion, but the prediction can survive without assuming matching spelling and speech.
   - **(E)** **Trap: unsupported leap.** Origin does not determine whether podcast usage can diffuse.

**Check:** Negate: none of the conditions responsible for previous spread are present here. The analogy loses its force.
::::
:::

:::problem[Question I.7]
A consumer council argues that advertisements for protective equipment should report performance on the test conditions buyers are most likely to encounter, rather than advertise a best-case laboratory result without qualification. A bicycle-helmet maker tested its product at several impact angles. The helmet performed exceptionally well in the straight-on test, although most actual cycling accidents in the council's database involved angled impacts, where its scores were merely average. The maker wants to print the straight-on score alone in large type on its packaging.

Which one of the following principles most strongly supports the council’s objection?

- **(A)** Whenever several valid test scores exist, a manufacturer may advertise whichever score is highest without indicating the test condition.
- **(B)** When an advertised measurement would mislead buyers about ordinary use because it reflects an atypical condition, the advertisement should disclose the relevant limitation.
- **(C)** A product that performs averagely in realistic conditions is necessarily unsafe.
- **(D)** Manufacturers must publish every measurement collected during product testing.
- **(E)** No safety product should ever be marketed unless it performs equally well in every laboratory test.

::::solution[Solution]
**Answer:** (B)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The maker should not advertise only its exceptional straight-on score without qualification.
2. **Support.** Typical crashes occur at angles for which performance is merely average.
3. **Prephrase.** Find a rule aligning displayed evidence with ordinary-use conditions.
4. **Why (B) is right.** The principle treats selective atypical reporting as a misleading representation requiring qualification.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** This competing principle would authorize the exact selective headline the council objects to.
   - **(C)** **Trap: too strong.** Conflates average performance with danger; no such claim is made.
   - **(D)** **Trap: too strong.** Broader disclosure burden than required to prevent the identified misleading impression.
   - **(E)** **Trap: too strong.** Too strong: the council objects to presentation, not differing performance.

**Check:** Apply the rule: atypical straight-on headline + unmentioned typical angled results → disclose the limitation.
::::
:::

:::problem[Question I.8]
A local basketball league recorded a lower injury rate this season than last season. The commissioner attributes the drop entirely to the league's stricter substitution rule, which was adopted just before the season began. Yet an unusually large number of experienced players returned this year, and the league also switched from outdoor asphalt courts to indoor wooden ones. The commissioner says these other changes cannot matter because the substitution rule occurred first in the list of reforms announced at the preseason meeting.

The commissioner’s reasoning is flawed because it...

- **(A)** infers that an injury-rate decrease must have occurred merely because fewer total injuries were counted.
- **(B)** confuses the order in which reforms were announced with evidence about which change caused the decline in injuries.
- **(C)** treats a necessary condition for a rule as a sufficient condition for compliance.
- **(D)** assumes that all returning experienced players faced exactly the same injury risks as new players.
- **(E)** assumes without evidence that experienced players always sustain more injuries.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The substitution rule alone caused the injury-rate decline.
2. **Support.** Several conditions changed, but the commissioner relies on an announcement sequence to isolate cause.
3. **Prephrase.** Spot post hoc and ignored alternative causes, in particular the irrelevant order of announcements.
4. **Why (B) is right.** Announcement order says nothing about medical effects; courts and player experience remain plausible explanations.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The premise explicitly reports injury rates, not just counts.
   - **(C)** **Trap: unsupported leap.** The reasoning is causal, not about a rule’s logical requirements.
   - **(D)** **Trap: too strong.** The commissioner never compares player risk in this fashion; this choice invents a particular comparison rather than naming the agenda-order error.
   - **(E)** **Trap: too strong.** Opposite of the plausible competing factor and not the premise used.

**Check:** Keep every physical change fixed but reorder the meeting agenda; the commissioner’s evidence changes while injury causes do not.
::::
:::

:::problem[Question I.9]
A farm cooperative reduced the number of delivery trucks entering its city distribution center by twenty percent last year. Nevertheless, total diesel consumption by trucks serving that center increased. Each truck used the same kind of fuel in both years, and none carried a heavier load than the vehicle's permitted capacity. Cooperative leaders were surprised because they expected fewer truck visits to mean less fuel burned. The record of visits counts each time a truck arrived at the gate, but it does not record how far the truck traveled before arriving.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The distribution center switched to a more fuel-efficient fleet of trucks during the year.
- **(B)** Some delivery customers began requesting their orders during quieter morning hours.
- **(C)** The center shortened the average wait at the gate for incoming trucks.
- **(D)** Diesel prices fell sharply during the year.
- **(E)** The cooperative consolidated deliveries onto fewer trucks that traveled much longer collection routes before reaching the center.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** There is no conclusion to prove; two true observations appear inconsistent.
2. **Support.** Truck visits fell, but truck diesel increased; total distance per visit was omitted.
3. **Prephrase.** Find a per-truck activity increase large enough to offset fewer visits.
4. **Why (E) is right.** Longer routes raise fuel use per visit, allowing aggregate diesel to climb even as visit counts fall.
5. **Why the others fail.**
   - **(A)** **Trap: wrong direction.** More efficient trucks would normally predict less fuel per route, making higher diesel harder to explain.
   - **(B)** **Trap: half-right / insufficient.** Quieter travel hours could reduce congestion and fuel consumption; it does not explain why diesel increased.
   - **(C)** **Trap: wrong direction.** Would tend to reduce idling fuel, deepening rather than resolving the surprise.
   - **(D)** **Trap: too strong.** Price changes affect expenditure, not necessarily liters consumed.

**Check:** Total diesel ≈ visits × average diesel per visit; the second factor can rise faster than the first falls.
::::
:::

:::problem[Question I.10]
A dictionary editor argues that removing regional labels from certain word entries would make the dictionary less informative. Some readers interpret those labels as judgments that regional speech is inferior, and the editor acknowledges that this interpretation can discourage users. But a label accurately identifying where a word is used tells readers when their audience may be unfamiliar with it. The editor proposes retaining the labels while rewriting the dictionary's introduction to explain that regional variation is not a sign of linguistic deficiency. The possibility of user discomfort, the editor concludes, is a reason to explain labels, not erase them.

The claim that some readers interpret regional labels as judgments of inferiority plays which one of the following roles in the argument?

- **(A)** It establishes that regional words have no identifiable distribution.
- **(B)** It presents a concern the editor acknowledges but seeks to address without accepting the proposed removal of labels.
- **(C)** It is the conclusion supported by the discussion of the dictionary introduction.
- **(D)** It is an empirical claim that the editor argues is false.
- **(E)** It supplies the editor’s main reason for eliminating regional labels.

::::solution[Solution]
**Answer:** (B)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** Retain regional labels and explain them rather than remove them.
2. **Support.** The editor concedes the harm objection but notes the labels’ informational value and offers an alternative remedy.
3. **Prephrase.** Identify a conceded counterconsideration rather than a premise offered as affirmative support.
4. **Why (B) is right.** The claim voices the concern motivating removal, which the proposed explanatory introduction answers.
5. **Why the others fail.**
   - **(A)** **Trap: scope shift.** Reader attitudes are distinct from geographic patterns.
   - **(C)** **Trap: unsupported leap.** The final proposal concerns retaining and explaining labels, not proving user discomfort.
   - **(D)** **Trap: unsupported leap.** The editor concedes the interpretation occurs.
   - **(E)** **Trap: unsupported leap.** The editor explicitly opposes elimination.

**Check:** Remove that concession and the editor still prefers labels; the concession is addressed, not adopted as the conclusion.
::::
:::

:::problem[Question I.11]
A technology company’s policy states that every product approved by its external privacy committee may be offered to schools. An internal team has certified the new classroom messaging app as meeting the company’s encryption standard. The product manager therefore concludes that the app may be offered to schools. Meeting the encryption standard by itself is not mentioned in the policy as a way to gain school eligibility; the manager assumes that the certification places the app in the category of products approved by the external committee.

The product manager’s conclusion follows logically if which one of the following is assumed?

- **(A)** The new messaging app is more secure than the company’s older school products.
- **(B)** All products offered to schools are certified by the internal team.
- **(C)** The external committee sometimes approves products without encryption certification.
- **(D)** Some products approved by the external privacy committee meet the encryption standard.
- **(E)** Every product certified by the internal team as meeting the encryption standard is approved by the external privacy committee.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The app may be offered to schools.
2. **Support.** Internal certification is given; committee approval guarantees school eligibility, but the missing link is certification → approval.
3. **Prephrase.** Supply the universal conditional connecting the app’s known property to the policy’s sufficient condition.
4. **Why (E) is right.** Certification → committee approval → may be offered. The new premise closes the entire chain.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Relative security is not a formal path to committee approval.
   - **(B)** **Trap: reversal.** Reverses the relevant policy and does not give school eligibility.
   - **(C)** **Trap: half-right / insufficient.** Possible but supplies no bridge from this app to approval.
   - **(D)** **Trap: wrong logical form.** Existential overlap does not establish this app’s approval.

**Check:** Diagram: E(app); E → P; P → S; therefore S(app).
::::
:::

:::problem[Question I.12]
A consumer-appliance manufacturer estimates that moving from wooden shipping pallets to a reusable composite pallet will reduce delivery damage. In a pilot, shipments on composite pallets had fewer broken appliance casings, even though transport distances were comparable. Warehouse employees are skeptical because the pilot shipments contained newer appliances with sturdier outer boxes. The manufacturer cannot yet repeat the entire pilot, but it has retained records that indicate which box designs were used and how frequently items were damaged within each design.

Which one of the following, if true, most strengthens the manufacturer’s estimate?

- **(A)** Wooden pallets have been common in appliance shipping for decades.
- **(B)** Newer box designs were used more frequently with composite pallets.
- **(C)** Composite pallets require fewer replacements after repeated shipments than wooden pallets.
- **(D)** Within each outer-box design used in the pilot, shipments on composite pallets had a substantially lower damage rate than shipments on wooden pallets.
- **(E)** Some warehouse employees dislike changing established procedures.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Composite pallets will reduce shipping damage.
2. **Support.** A raw pilot difference may be explained by sturdier boxes.
3. **Prephrase.** Control box design while comparing pallet types.
4. **Why (D) is right.** Lower damage within every design reduces the chance that box selection explains the association.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Historical popularity gives no comparative damage evidence.
   - **(B)** **Trap: unsupported leap.** Makes the box-design confound more threatening.
   - **(C)** **Trap: half-right / insufficient.** Durability could reduce pallet costs, but does not compare appliance-casing damage after controlling box design.
   - **(E)** **Trap: unsupported leap.** Attacks critics’ attitudes instead of addressing the confounding variable.

**Check:** Stratify by box design: the composite advantage persists in like-with-like comparisons.
::::
:::

:::problem[Question I.13]
A software firm reports that ninety percent of customers who responded to its satisfaction poll intend to renew their subscriptions. The chief financial officer predicts that at least ninety percent of all subscriptions will renew next year. The poll appeared only after a customer opened the app's advanced settings menu, a menu primarily used by enthusiastic customers who customize the service. The officer dismisses a warning about nonrespondents, saying the poll's stated margin of error is just two percentage points. No independent information about the views of customers who never saw the poll was collected.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** uses a statistical margin of error to dismiss systematic selection bias in who encountered the poll.
- **(B)** assumes that an advanced settings menu is required for every subscriber.
- **(C)** infers that customers who access advanced settings are more likely to have their subscription canceled by the company.
- **(D)** infers an intention from observed renewal behavior rather than the reverse.
- **(E)** concludes that a small sample can never support an accurate prediction.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** At least 90 percent of all subscriptions will renew.
2. **Support.** The 90 percent intention rate is from a selectively reached sample; the reported margin addresses sampling variation, not that selection.
3. **Prephrase.** Find the flaw in applying a precisely measured biased response group to everyone.
4. **Why (A) is right.** Even negligible random sampling error does not correct systematically missing disengaged subscribers.
5. **Why the others fail.**
   - **(B)** **Trap: too strong.** Nothing says the officer believes every subscriber uses it; representativeness is the actual unstated claim.
   - **(C)** **Trap: scope shift.** The stimulus concerns customers’ voluntary renewal; company-initiated cancellation is a different event.
   - **(D)** **Trap: unsupported leap.** The premise is stated intention, and the conclusion predicts behavior, not vice versa.
   - **(E)** **Trap: too strong.** The officer touts a margin of error but the sample size itself is not the identified defect.

**Check:** Imagine infinitely many enthusiastic settings users respond: selection bias remains.
::::
:::

:::problem[Question I.14]
A tennis academy opened additional indoor courts in January. Coaches report that the average student now practices more hours per week, but the academy also introduced an optional advanced program at the same time. Students who joined that program practice far longer than students who did not, and most advanced-program students already had high practice totals before January. In contrast, the academy's records show little change in hours among continuing students who did not join the program. No similar academy without either change was studied.

Which one of the following is most strongly supported by the information above?

- **(A)** The increase in the academy-wide average does not by itself establish that additional court space increased practice time for continuing students.
- **(B)** The indoor courts had no effect on any student’s practice schedule.
- **(C)** The optional advanced program caused every participating student to practice more.
- **(D)** Academies without indoor courts always have lower practice averages.
- **(E)** All continuing students practiced exactly the same hours before and after January.

::::solution[Solution]
**Answer:** (A)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The supported inference concerns what cannot be concluded from a changing overall average.
2. **Support.** Program composition and previously intensive students confound attribution to more courts.
3. **Prephrase.** Prefer the modest statement that average movement does not identify a causal source.
4. **Why (A) is right.** The additional program and unchanged nonparticipant patterns mean the average alone cannot isolate the courts’ effect.
5. **Why the others fail.**
   - **(B)** **Trap: too strong.** Too strong: some students could have benefited even if group averages obscure it.
   - **(C)** **Trap: too strong.** The participants already practiced a great deal; individual changes are unreported.
   - **(D)** **Trap: too strong.** No comparison with other academies is given.
   - **(E)** **Trap: too strong.** “Little change” for one subgroup does not mean exact equality for all.

**Check:** The stated facts permit a model in which advanced-program selection drives the rise without any court effect.
::::
:::

:::problem[Question I.15]
Researcher A: A tutoring chatbot should be evaluated principally by whether students can carry their improved speaking skills into unscripted conversations with people. A chatbot can produce flawless practice dialogues yet fail that test. Researcher B: Unscripted transfer matters, but a standardized dialogue score is the better primary measure for comparing chatbot systems because it can be reproduced across institutions. Such scores should never be mistaken for proof that students will converse successfully outside a test.

The researchers disagree about whether...

- **(A)** students learn speaking skills from chatbots at all.
- **(B)** success in unscripted human conversation should be the principal measure used to evaluate tutoring chatbots.
- **(C)** standardized dialogue scores can be reproduced across institutions.
- **(D)** unscripted conversational transfer is relevant when evaluating a tutoring chatbot.
- **(E)** excellent scores guarantee conversational success with people.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** A makes transfer primary; B says standardized scoring should be primary.
2. **Support.** Both concede that scripted scores do not guarantee transfer.
3. **Prephrase.** A point-at-issue answer requires opposing views, not a claim only one mentions.
4. **Why (B) is right.** A says yes to primacy of transfer, B says no by favoring standardized dialogue scores as primary.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Neither takes a definite position on whether improvement occurs in every case.
   - **(C)** **Trap: unsupported leap.** B affirms this; A does not address its reproducibility.
   - **(D)** **Trap: unsupported leap.** Both treat transfer as relevant, disagreeing over its priority.
   - **(E)** **Trap: unsupported leap.** Both reject treating dialogue performance as sufficient proof of transfer.

**Check:** A: primary transfer = yes; B: primary transfer = no.
::::
:::

:::problem[Question I.16]
A farmers market eliminated single-use checkout bags in April. According to stall owners, the number of bags distributed at the stalls immediately dropped to almost zero. The market director concludes that the policy has substantially reduced the total amount of disposable packaging associated with market purchases. The director measured only the bags handed out by sellers and did not examine what customers used to transport produce after leaving the stalls. Many customers buy loose fruits and vegetables and need some kind of container before traveling home.

Which one of the following, if true, most seriously weakens the director’s conclusion?

- **(A)** The number of sellers attending the market increased modestly.
- **(B)** Customers bring reusable canvas bags more frequently than before.
- **(C)** Many customers favor bringing their own reusable bags rather than using sellers’ containers.
- **(D)** The market sells more varieties of vegetables than last year.
- **(E)** Customers now commonly purchase several disposable plastic liners from a kiosk at the market entrance to carry the same produce.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** The ban reduced total disposable packaging associated with purchases.
2. **Support.** Stall-bag distribution dropped, but customers’ replacement containers were excluded.
3. **Prephrase.** Look for displaced disposable packaging rather than onsite bag totals.
4. **Why (E) is right.** New disposable liners could replace the removed bags, erasing the net reduction.
5. **Why the others fail.**
   - **(A)** **Trap: half-right / insufficient.** Could affect quantities but has no direct link to the replacement liners.
   - **(B)** **Trap: wrong direction.** Supports rather than weakens the waste-reduction conclusion.
   - **(C)** **Trap: half-right / insufficient.** This preference may encourage less disposable packaging and does not demonstrate the offset required to weaken the conclusion.
   - **(D)** **Trap: half-right / insufficient.** Variety does not establish offsetting disposable packaging.

**Check:** Count all disposable carriers used for purchases, not just those given by stall owners.
::::
:::

:::problem[Question I.17]
An engineer argues that a new voice assistant will recognize the speech of rural residents as accurately as that of urban residents. The evaluation dataset includes thousands of rural and urban speakers and reports identical error rates for the two groups. However, rural recordings in the dataset were made primarily in quiet recording booths, whereas urban recordings were made in homes, cars, and offices. The assistant is to be used in ordinary daily environments. The engineer says group parity in the test provides adequate evidence of parity in use.

Which one of the following is an assumption required by the engineer’s argument?

- **(A)** Every rural user speaks in a completely quiet room.
- **(B)** The differences in recording conditions do not conceal a rural-versus-urban performance disparity that would emerge in ordinary use.
- **(C)** The evaluation dataset contains precisely equal numbers of rural and urban speakers.
- **(D)** Background noise never affects speech recognition accuracy.
- **(E)** The assistant is more accurate than every competing device.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Observed error-rate parity will persist under everyday conditions.
2. **Support.** The measured groups were recorded under different conditions; the argument extrapolates to ordinary use.
3. **Prephrase.** Rule out a hidden group disparity induced by the mismatched environments.
4. **Why (B) is right.** If the recording setup concealed a real rural disadvantage outside booths, equal test rates would not justify the claim.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Contradicts the intended everyday-use setting and is unnecessary.
   - **(C)** **Trap: unsupported leap.** Equal sample sizes are unnecessary for comparing error rates and would not correct the unequal recording environments.
   - **(D)** **Trap: too strong.** Much stronger than needed: noise may affect both groups equally.
   - **(E)** **Trap: too strong.** Comparative competitiveness is not at issue.

**Check:** Negate: conditions do conceal a rural disadvantage in actual use. The projection of parity fails.
::::
:::

:::problem[Question I.18]
A club grants free use of its training room to every team that has at least six registered athletes and books a weekly practice slot. The rowing team has eight registered athletes and has booked a weekly slot. The treasurer concludes that the rowing team qualifies for free use. The conclusion does not depend on whether any team with fewer than six members ever receives a special exception, since the rowing team already satisfies the stated qualifying conditions.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Some enrolled hikers have permits; Rae is enrolled, so Rae probably has a permit.
- **(B)** Only ticket holders enter the concert; Leila has a ticket, so she will enter.
- **(C)** All residents who pay the fee may use the pool; Marcus may use it, so Marcus paid the fee.
- **(D)** Every museum member who pays annual dues and reserves a date may tour the archive; Elena paid her dues and reserved a date, so Elena may tour it.
- **(E)** All licensed mechanics completed training; Imran completed training, so Imran is licensed.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The rowing team qualifies for free use.
2. **Support.** The rule is (six or more athletes AND booking) → eligibility; both antecedent components hold.
3. **Prephrase.** Match a conjunction of two satisfied sufficient requirements leading to permission.
4. **Why (D) is right.** The museum example uses dues AND reservation → archive access, and states both antecedents.
5. **Why the others fail.**
   - **(A)** **Trap: wrong logical form.** Infers an individual property from existential overlap.
   - **(B)** **Trap: reversal.** Treats a necessary condition as sufficient.
   - **(C)** **Trap: reversal.** Reverses a sufficient condition.
   - **(E)** **Trap: unsupported leap.** Affirms the consequent rather than applying sufficient conditions.

**Check:** Let P and Q be conditions: (P ∧ Q) → R; P; Q; therefore R.
::::
:::

:::problem[Question I.19]
An arena manager observes that the average ticket price for this season's games is higher than last season's. She concludes that the arena raised ticket prices for every seating category. Last year, most tickets sold were in inexpensive upper sections; this year, after a promotional package ended, a larger share of buyers selected premium lower-section seats. The arena has not published a category-by-category price comparison. The manager argues that a higher overall average cannot occur unless each component price has increased.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** confuses a season’s total ticket revenue with its per-ticket average.
- **(B)** ignores the possibility that all seating categories became cheaper in absolute terms.
- **(C)** assumes that ticket sales increased merely because the average price increased.
- **(D)** overlooks how a change in the proportions of expensive and inexpensive tickets sold can increase an average without any category price increase.
- **(E)** fails to establish that the median ticket price rose by as much as the mean ticket price.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Every seating category underwent a price increase.
2. **Support.** Only the overall weighted average rose, while seat mix shifted toward premium sections.
3. **Prephrase.** Identify a composition effect, not a claim about total income.
4. **Why (D) is right.** A changing sales mix can change the weighted mean even when each underlying price stays constant.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The stimulus discusses average paid price, not revenue totals.
   - **(B)** **Trap: too strong.** Even if possible, the core identified defect is the changing weighted mix, not a universal price decline.
   - **(C)** **Trap: unsupported leap.** The conclusion is about each category’s price, not units sold.
   - **(E)** **Trap: too strong.** A median comparison might describe the distribution, but cannot establish increases within every seating category.

**Check:** Example: $20/$80 categories with premium share increasing from 10% to 50% raises the mean from $26 to $50 without price changes.
::::
:::

:::problem[Question I.20]
A delivery platform claims that its route algorithm reduces delivery times. An independent analyst notes that the platform compared only average delivery times before and after adoption, despite changes in restaurant participation and customer geography. Instead of claiming that the algorithm cannot work, the analyst proposes comparing drivers who use it with drivers who do not during the same weeks and across similar neighborhoods. If the predicted gap persists under that comparison, the platform's explanation will receive stronger support.

Which one of the following most accurately describes the analyst’s method of reasoning?

- **(A)** The analyst infers the superiority of a competing algorithm from an expert’s reputation.
- **(B)** The analyst argues that any outcome with several possible causes is inherently impossible to study.
- **(C)** The analyst establishes that the algorithm is ineffective by showing a numerical contradiction.
- **(D)** The analyst rejects any before-and-after comparison as inherently incapable of revealing a causal influence.
- **(E)** The analyst identifies uncontrolled changes in a before-and-after comparison and recommends a more closely matched test of the causal claim.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** A better-matched comparison is needed before crediting the algorithm.
2. **Support.** The initial time trend is confounded by shifting participating restaurants and customer locations.
3. **Prephrase.** Describe diagnosis of a causal confound followed by a controlled test.
4. **Why (E) is right.** The analyst neither proves nor disproves the benefit, but specifies how to isolate the algorithm’s contribution.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** No competing algorithm or appeal to authority is given.
   - **(B)** **Trap: unsupported leap.** The suggested controlled comparison is precisely a way to study it.
   - **(C)** **Trap: unsupported leap.** No contradiction or proof of ineffectiveness is offered.
   - **(D)** **Trap: too strong.** Overstates the criticism: the analyst objects to confounded comparisons, not all temporal comparisons.

**Check:** The proposed design holds week and neighborhood more nearly constant while changing algorithm use.
::::
:::

:::problem[Question I.21]
A home-appliance maker discovers that one production batch of kettles has an overheating defect. It can identify the affected serial numbers exactly, and replacement heating units are available. A trade association recommends issuing a public warning about all kettles of that model, including those from unaffected batches. A consumer advocate objects that broad warnings can needlessly alarm buyers and divert repair capacity from those with genuine risk. The advocate says the maker should contact identifiable affected owners promptly and describe the defect precisely.

Which one of the following principles, if valid, most strongly justifies the advocate’s recommendation?

- **(A)** Manufacturers should never publicly announce a defect that can be repaired.
- **(B)** Warnings should be issued only when more than half the production run is defective.
- **(C)** When a product hazard is reliably confined to identifiable units, a company should give specific, prompt notice to their owners rather than imply that unaffected units share that hazard.
- **(D)** Companies must wait to notify customers until every replacement part has shipped.
- **(E)** An inaccurate warning about unaffected products is justified whenever it attracts greater public attention than a narrowly targeted warning.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Promptly target accurate warnings to owners of the defective batch.
2. **Support.** Serial numbers identify affected devices; sweeping warnings could misstate risk and misallocate resources.
3. **Prephrase.** Find proportional, accurate risk disclosure based on a reliable boundary.
4. **Why (C) is right.** The rule directly applies to batch-specific warnings without barring other useful communication.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Too broad; specific notice may itself need public delivery.
   - **(B)** **Trap: scope shift.** Invents a prevalence threshold irrelevant to identifiable risk.
   - **(D)** **Trap: too strong.** Undercuts prompt notice and delays risk communication.
   - **(E)** **Trap: too strong.** This principle prioritizes attention over accuracy, exactly the tradeoff the advocate rejects.

**Check:** Affected identifiable batch + confined hazard → targeted accurate warning.
::::
:::

:::problem[Question I.22]
An insurer says its new mobile frost alerts will reduce crop losses among growers enrolled in its service. During last winter's trial, growers receiving alerts reported fewer frost losses than growers who did not receive them. However, the alert group consisted entirely of farmers who opted in, and many already owned expensive crop-protection equipment. The insurer argues that alerts allow farmers to act before temperatures fall and that the trial's results demonstrate this benefit. No data were collected on whether the two groups actually used their protective equipment at comparable rates.

Which one of the following assumptions is necessary to the insurer’s argument?

- **(A)** The observed loss difference was not entirely due to factors other than the alerts.
- **(B)** Every farmer receiving an alert used a single identical method to protect crops.
- **(C)** The alerts prevented every possible kind of crop loss.
- **(D)** Every alert recipient acted on every message.
- **(E)** Every farmer without alerts lacked crop-protection equipment.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The alerts reduce frost damage.
2. **Support.** Recipients incurred fewer losses but self-selection and equipment could produce the difference.
3. **Prephrase.** A causal claim requires that the whole difference not be explainable without the alleged cause.
4. **Why (A) is right.** If other factors fully explain the difference, the trial provides no evidence of alert effectiveness.
5. **Why the others fail.**
   - **(B)** **Trap: too strong.** Uniform protection methods are much stronger than necessary; varied actions could still produce an alert benefit.
   - **(C)** **Trap: too strong.** Far beyond the narrower frost-loss claim.
   - **(D)** **Trap: too strong.** Overly strong: a partial response rate could still produce a benefit.
   - **(E)** **Trap: too strong.** Unnecessary and not suggested by the described groups.

**Check:** Negate “not entirely”: the difference was entirely due to other factors, defeating the trial-based attribution.
::::
:::

:::problem[Question I.23]
A household-goods store installed four self-checkout kiosks and eliminated one staffed register. During the first month, the average time a customer spent actively scanning and paying for items decreased. Nevertheless, the average time from joining a checkout line to leaving the store increased. Managers initially blamed slow kiosks, but transaction logs show that checkout itself was completed faster than before, even for customers with full baskets. The store did not track time spent waiting for a machine to become free.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The new kiosks printed receipts more quickly than the old register.
- **(B)** The kiosks were easier for customers to learn on subsequent visits.
- **(C)** The kiosks often sat unused while customers with restricted-sale items waited in a single line for the one remaining staffed register.
- **(D)** The store lowered prices on several frequently purchased items.
- **(E)** Most kiosk customers purchased fewer items than staffed-register customers.

::::solution[Solution]
**Answer:** (C)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** Explain two compatible time measures, not establish a new conclusion.
2. **Support.** Active checkout sped up, while total line-to-exit time slowed; waiting is the missing component.
3. **Prephrase.** Look for congestion at a distinct bottleneck while kiosk service is fast.
4. **Why (C) is right.** A long staffed-register queue can dominate total time even if kiosk scanning is quick.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Makes active transaction time shorter and leaves the longer waiting time unexplained.
   - **(B)** **Trap: unsupported leap.** Faster learning predicts even less service time; it does not explain longer end-to-end checkout time.
   - **(D)** **Trap: unsupported leap.** Prices do not explain a gap between service and total checkout time.
   - **(E)** **Trap: half-right / insufficient.** Can explain fast transactions but not the increased overall wait by itself.

**Check:** Total time = waiting + service; lower service and higher total imply higher waiting.
::::
:::

:::problem[Question I.24]
A recruiting manager says that everyone hired to translate the company’s technical manuals has passed a demanding terminology exam. A candidate passed that exam last month. The manager therefore concludes that the candidate has already been hired to translate technical manuals, despite having no information about the candidate's application status. The hiring policy establishes an obligation for successful hires, not an automatic job offer to anyone who passes.

Which one of the following arguments contains reasoning most similar in its flaw?

- **(A)** All warehouse inspectors carry an ID badge; Malik is an inspector, so Malik carries a badge.
- **(B)** Some reviewers who like the novel are teachers; Priya likes it, so Priya is a teacher.
- **(C)** Every licensed pilot has passed a medical examination; Noor passed a medical examination, so Noor must be a licensed pilot.
- **(D)** If a runner completes a marathon, the runner trained; Suri did not train, so Suri did not complete the marathon.
- **(E)** Only certified produce may bear this seal; this produce lacks certification, so it cannot bear the seal.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The exam-passing candidate has been hired.
2. **Support.** Hired → passed; passed is mistakenly treated as → hired.
3. **Prephrase.** Match affirming the consequent, not simply any invalid inference.
4. **Why (C) is right.** Licensed → medical passed; medical passed → licensed is the same invalid converse.
5. **Why the others fail.**
   - **(A)** **Trap: wrong logical form.** Valid application of a universal conditional.
   - **(B)** **Trap: wrong logical form.** Invalid existential-to-individual move rather than affirming a universal consequent.
   - **(D)** **Trap: reversal.** Valid contraposition, not converse confusion.
   - **(E)** **Trap: half-right / insufficient.** Valid necessity-based inference, not the erroneous reverse.

**Check:** In both arguments: H → P; P; therefore H, which is invalid.
::::
:::

:::problem[Question I.25]
A rechargeable-tool manufacturer claims that extending its battery warranty from one year to three years will increase profits. The marketing team estimates that the longer warranty will attract enough additional buyers to raise revenue significantly. Warranty administrators warn that failures occurring in years two and three could require costly replacements. The company’s president says added sales will more than compensate for these liabilities, but the prediction does not include an estimate of the total cost of new warranty claims.

The answer to which one of the following questions would be most useful in evaluating the president’s argument?

- **(A)** Are customers generally satisfied with the one-year warranty?
- **(B)** What percentage of buyers prefer this manufacturer’s tools over competing brands at the current price?
- **(C)** Will existing buyers receive a replacement battery without charge during the first year of the new warranty?
- **(D)** Will the profit from the additional sales exceed the additional cost of fulfilling claims during years two and three?
- **(E)** Will competitors also use longer warranties in their advertising?

::::solution[Solution]
**Answer:** (D)

**Type:** Evaluate the argument (Chapter 8)

1. **Conclusion.** Longer warranties will increase profit.
2. **Support.** Extra purchases may produce margin while added years introduce replacement costs.
3. **Prephrase.** Evaluate net incremental profit, not one side of the ledger.
4. **Why (D) is right.** Yes strongly supports the conclusion; no undermines it. Both outcomes directly change its credibility.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Past satisfaction does not quantify future net margin.
   - **(B)** **Trap: half-right / insufficient.** Brand preference may help predict demand, but it cannot determine whether extra margin exceeds new warranty costs.
   - **(C)** **Trap: half-right / insufficient.** The warranty already covers year one; this does not measure new years-two-and-three liability.
   - **(E)** **Trap: half-right / insufficient.** Could influence sales but does not directly compare incremental revenue and warranty expense.

**Check:** Net effect = extra contribution from sales − extra warranty expense; determine the sign.
::::
:::


## 29.2 Section II: Reading Comprehension

**27 questions · 4 passages · 35 minutes**


### Passage 1

Evidence law commonly treats an earlier identification of a suspect as useful corroboration when a witness later identifies the same person in court. The rationale is straightforward: an identification made near the event may preserve a memory less altered by time. Yet this rationale depends on how the earlier identification occurred. A witness who sees a suspect's photograph repeatedly before an identification procedure may acquire confidence in the photograph rather than in the original memory of the event. The issue is not simply whether a witness is sincere. Sincerity and reliability can diverge when a procedure changes what is remembered.

Some courts respond by focusing on the formal fairness of an identification procedure. Did the officer present several reasonably similar photographs? Did the officer avoid explicitly telling the witness which person to choose? These safeguards matter, but they may fail to capture the influence of information the witness encountered before the procedure. For instance, if the suspect's photograph circulated widely in news coverage, an otherwise orderly array might still encourage a witness to select the familiar face. In such a case, the procedure can be impeccably conducted at the station while the evidentiary value of its outcome remains uncertain.

An alternative approach asks judges to distinguish two questions that often become tangled: whether the police used a suggestive procedure and whether the identification gives reliable information about the event itself. A court could require documentation of significant exposures to suspect images before the identification, the witness’s first description, and the witness’s initial level of confidence before any confirming feedback. Such records do not guarantee accuracy. They make it possible for counsel and fact finders to evaluate whether apparently strong courtroom testimony grew from independent recollection or from later reinforcement. A contemporaneous low-confidence identification, for example, would deserve careful scrutiny if it eventually became an emphatic courtroom assertion.

Critics worry that additional documentation will burden investigators and that excluding identifications whenever a witness has seen a news image would deprive juries of useful evidence. Those are genuine concerns, but neither justifies a rigid exclusion rule. Documentation could be concentrated on information that is easily lost, particularly a witness’s first statement and early confidence. And rather than mandating exclusion for every prior exposure, courts could permit competing experts to explain the exposure's potential effect while judges assess the probative value of the identification in context.

The strongest reform, then, is neither automatic trust in an orderly police lineup nor automatic distrust of an exposed witness. It is a more discriminating record of how an identification formed. The legal system cannot recreate an untouched memory once it has been influenced, but it can do a better job of preserving the evidence needed to judge what an identification actually establishes.


:::problem[Question II.1]
Which one of the following best expresses the main point of the passage?

- **(A)** Eyewitness identifications are inherently worthless as evidence in criminal proceedings.
- **(B)** The central legal problem is that sincere witnesses deliberately mislead juries.
- **(C)** A formally proper photographic array is sufficient to establish identification reliability.
- **(D)** Courts should evaluate identifications through better records of their formation rather than relying solely on lineup regularity or automatically excluding previously exposed witnesses.
- **(E)** Investigators should prohibit all publicity about suspects before trial.

::::solution[Solution]
**Answer:** (D)

**Type:** Main point / primary purpose (RC) (Chapter 18)

1. **Conclusion.** The passage advocates process-sensitive evaluation with contemporaneous documentation.
2. **Support.** It presents memory contamination, limits of formal fairness, a records-based remedy, and responses to burdens.
3. **Prephrase.** Choose an answer spanning all paragraphs and the moderate compromise.
4. **Why (D) is right.** This captures the proposal and rejects both extremes explicitly disclaimed in the final paragraph.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Too strong: the author recommends contextual evaluation, not rejection.
   - **(B)** **Trap: unsupported leap.** The passage distinguishes sincere confidence from accuracy and does not accuse witnesses of deception.
   - **(C)** **Trap: unsupported leap.** This is the narrower approach the passage challenges.
   - **(E)** **Trap: unsupported leap.** The passage proposes recordkeeping and assessment, not controlling all media coverage.

**Check:** Map P1 problem → P2 limits of lineup fairness → P3 records → P4 objections → P5 calibrated reform.
::::
:::

:::problem[Question II.2]
According to the passage, why might a properly conducted photographic array nevertheless yield a questionable identification?

- **(A)** A witness who sees publicity about a suspect before a lineup is necessarily lying if the witness later selects that suspect.
- **(B)** The witness may recognize a suspect’s face from earlier publicity rather than from the witnessed event.
- **(C)** An identification made using several similar photographs is necessarily less reliable than one using a single photograph.
- **(D)** A witness who is highly confident must have remembered the event accurately.
- **(E)** Officers necessarily manipulate photographs in any array of multiple images.

::::solution[Solution]
**Answer:** (B)

**Type:** Detail / recognition (RC) (Chapter 18)

1. **Conclusion.** Formal procedural fairness does not ensure independent recollection.
2. **Support.** Paragraph two describes pre-array news exposure making one face familiar.
3. **Prephrase.** Return to the familiar-face example rather than infer police misconduct.
4. **Why (B) is right.** Earlier exposure can influence selection even when police behave properly during the array.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Conflates an unreliable identification with intentional deception; the passage expressly separates sincerity from accuracy.
   - **(C)** **Trap: reversal.** Reverses the role of safeguards: the author describes similarity among photographs as generally useful, though insufficient by itself.
   - **(D)** **Trap: unsupported leap.** The author warns against this very inference.
   - **(E)** **Trap: too strong.** The example assumes an orderly array, not manipulation.

**Check:** An orderly array and a contaminated memory can coexist.
::::
:::

:::problem[Question II.3]
The author discusses a witness whose initially hesitant identification becomes emphatic in court primarily in order to...

- **(A)** establish that memory inevitably becomes less accurate every day.
- **(B)** show that all increases in confidence result from police misconduct.
- **(C)** prove that jurors always trust confident witnesses.
- **(D)** argue that low-confidence witnesses should never testify.
- **(E)** illustrate how early confidence records can reveal changes that later testimony alone would conceal.

::::solution[Solution]
**Answer:** (E)

**Type:** Function / purpose (RC) (Chapter 18)

1. **Conclusion.** Initial confidence should be preserved to aid later reliability assessment.
2. **Support.** Paragraph three contrasts an early hesitant response with later certainty.
3. **Prephrase.** Ask what the example demonstrates about records, not which witness should win.
4. **Why (E) is right.** A documented shift in confidence helps fact finders evaluate the source of later certainty.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** The example concerns reinforcement, not a universal daily deterioration.
   - **(B)** **Trap: unsupported leap.** Feedback is one possible influence; exclusive police causation is not claimed.
   - **(C)** **Trap: too strong.** The example does not state a universal claim about jurors.
   - **(D)** **Trap: too strong.** The author supports contextual evaluation rather than categorical exclusion.

**Check:** The example connects the proposed recordkeeping directly to its evidentiary payoff.
::::
:::

:::problem[Question II.4]
It can most reasonably be inferred that the author would favor which one of the following policies?

- **(A)** Replacing every photographic identification with courtroom identification alone.
- **(B)** Keeping all early confidence records secret from both sides at trial.
- **(C)** Excluding every identification that follows any exposure to a suspect’s image.
- **(D)** Assigning decisive weight to the number of photos in an array regardless of prior exposure.
- **(E)** Requiring investigators to record a witness’s earliest description and confidence even if the identification is not ultimately excluded.

::::solution[Solution]
**Answer:** (E)

**Type:** Inference (RC) (Chapter 18)

1. **Conclusion.** Preserve early evidentiary conditions even when the testimony is admitted.
2. **Support.** Paragraphs three and four favor documentation as distinct from categorical exclusion.
3. **Prephrase.** Seek a policy consistent with both the recordkeeping proposal and admitted evidence.
4. **Why (E) is right.** Recording first descriptions and confidence preserves facts for contextual evaluation without automatic exclusion.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Courtroom testimony may reflect reinforcement; it is not offered as the solution.
   - **(B)** **Trap: unsupported leap.** Defeats the proposed use by counsel and fact finders.
   - **(C)** **Trap: too strong.** Directly contrary to the author’s rejection of rigid exclusion.
   - **(D)** **Trap: unsupported leap.** Restores the narrow procedural focus the author critiques.

**Check:** Documentation is proposed to aid weighing, not to impose a yes/no admissibility result.
::::
:::

:::problem[Question II.5]
The author’s attitude toward concerns about investigative burdens is best described as...

- **(A)** dismissing them as invented excuses with no factual basis.
- **(B)** acknowledging the concerns as legitimate but believing they can be addressed through focused documentation.
- **(C)** accepting them as decisive reasons to abandon any reform.
- **(D)** treating them as more serious than the danger of mistaken identification in every case.
- **(E)** remaining wholly neutral about whether the suggested records should be made.

::::solution[Solution]
**Answer:** (B)

**Type:** Author attitude / tone (RC) (Chapter 18)

1. **Conclusion.** The author’s tone is measured and reformist.
2. **Support.** Paragraph four calls the burdens genuine while proposing limited preservation of easily lost information.
3. **Prephrase.** Look for concession plus practical reply.
4. **Why (B) is right.** The answer preserves both the acknowledged cost and the author’s preference for targeted records.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The author explicitly calls the concerns genuine.
   - **(C)** **Trap: unsupported leap.** The passage nonetheless supports a narrower reform.
   - **(D)** **Trap: too strong.** No universal ranking is claimed.
   - **(E)** **Trap: unsupported leap.** The author advocates targeted recording.

**Check:** Signal words: “genuine concerns” followed by “neither justifies” and “documentation could be concentrated.”
::::
:::

:::problem[Question II.6]
Which one of the following courtroom practices best illustrates the author’s preferred approach?

- **(A)** A prosecutor withholds the witness’s original description because confidence later increased.
- **(B)** A court bases accuracy solely on the witness’s current sincerity.
- **(C)** A judge admits an identification but allows evidence of the witness’s earlier news exposure and initial uncertainty to be evaluated alongside it.
- **(D)** A judge excludes every identification once any pretrial publicity is shown.
- **(E)** A judge admits every identification so long as the lineup used at least six photos.

::::solution[Solution]
**Answer:** (C)

**Type:** Application / analogy (RC) (Chapter 18)

1. **Conclusion.** Admit and scrutinize when appropriate, using the formation record.
2. **Support.** Paragraphs three and four support contextual probative assessment and explanatory evidence.
3. **Prephrase.** Find a practice that neither blindly admits nor automatically excludes.
4. **Why (C) is right.** It allows the fact finder to confront the identified influences while still considering the testimony.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Suppresses precisely the early information to be preserved.
   - **(B)** **Trap: unsupported leap.** Confuses sincerity with reliability, the passage’s initial warning.
   - **(D)** **Trap: too strong.** Uses the blanket exclusion the author rejects.
   - **(E)** **Trap: too strong.** Elevates procedural form over the memory history the author wants considered.

**Check:** Both admissibility and weight remain open to contextual evaluation.
::::
:::

:::problem[Question II.7]
Which one of the following best describes the organization of the passage?

- **(A)** An example of a reliable lineup is used to show that formal police procedures eliminate most dangers to witness memory.
- **(B)** A case for excluding identifications influenced by prior publicity is developed and then limited to those involving low initial confidence.
- **(C)** Two methods for determining which suspect a witness saw are compared according to their cost and accuracy.
- **(D)** An evidentiary rationale is qualified, a narrow procedural response is criticized, and a more contextual reform is defended against objections.
- **(E)** A general defense of pretrial identification is followed by a recommendation that courts admit all such evidence without qualification.

::::solution[Solution]
**Answer:** (D)

**Type:** Structure / organization (RC) (Chapter 18)

1. **Conclusion.** The passage proceeds from a familiar justification through a critique to a qualified remedy.
2. **Support.** P1 initial rationale and risk; P2 lineup insufficiency; P3-4 reform and objections; P5 synthesis.
3. **Prephrase.** Match the argumentative transitions, not merely the subject matter.
4. **Why (D) is right.** The sequence matches the actual paragraph map and conclusion.
5. **Why the others fail.**
   - **(A)** **Trap: wrong direction.** The orderly-array example has the opposite function: it exposes dangers that formal procedures do not eliminate.
   - **(B)** **Trap: unsupported leap.** The proposed remedy is preserving information for contextual evaluation, not a confidence-based exclusion test.
   - **(C)** **Trap: unsupported leap.** The author compares approaches to judicial evaluation, not rival techniques for discovering a suspect’s identity.
   - **(E)** **Trap: half-right / insufficient.** The opening rationale is qualified rather than accepted without limits, and the final recommendation calls for contextual review.

**Check:** Trace pivot terms: “yet,” “but,” “alternative,” “critics,” “then.”
::::
:::

### Passage 2

Planetary scientists often use the craters on a moon's surface as a rough clock. A heavily cratered plain is generally older than a nearby plain with few impact scars, because impacts accumulate over long periods. This approach is especially useful where no rock samples have been dated in a laboratory. But the apparent simplicity of crater counting depends on an assumption that is sometimes overlooked: the visible surface must have retained most of the craters produced during the period being studied. A moon with a restless crust may have a misleadingly youthful face.

Consider a hypothetical icy moon called Neris, whose southern hemisphere contains many circular depressions while its northern hemisphere is comparatively smooth. A conventional crater count would suggest that the northern terrain formed more recently. Yet spacecraft images reveal narrow ridges crossing the northern plains and regions of fresh, reflective ice along some ridge margins. These features could result from fractures that brought slushy material upward, covering older depressions. If so, the low crater count would date the most recent resurfacing event rather than the original formation of the underlying ice.

Researchers distinguish between formation age and surface-retention age by combining several imperfect clues. They examine whether crater rims are truncated by ridges, whether ejecta blankets are buried beneath newer material, and whether small craters disappear more frequently near suspected fractures than farther away. A pattern in which ridges cut across crater rims would establish that at least some deformation occurred after those impacts. It would not, however, reveal how much time elapsed between the impacts and deformation, nor would it prove that every smooth plain had been resurfaced in the same episode.

Another complication is that impacts themselves may not arrive at a uniform rate. A temporary increase in debris crossing a moon's orbit could generate many craters over a short interval. Conversely, a shortage of debris might leave a long-lived region lightly cratered. Models of the impacting population are therefore used to translate crater densities into approximate durations. The models can be checked against other worlds where some surfaces have independent age estimates, but such comparisons depend on how similar the impact environments really are. Precision in counting visible circles is not the same thing as precision in assigning a calendar age. Even careful mapping leaves unanswered questions about the original terrain.

The case of Neris illustrates why crater maps are best treated as layered histories rather than as simple age charts. The depressions record impacts; the ridges may record tectonic or cryovolcanic disruption; and their intersections give relative order even when absolute dates remain uncertain. By reading those relationships together, scientists can draw stronger conclusions than they could from crater totals alone, while preserving the uncertainty that the evidence cannot remove.


:::problem[Question II.8]
Which one of the following best states the central idea of the passage?

- **(A)** Crater counting has been disproved and should never be used on icy moons.
- **(B)** All smooth plains on moons formed more recently than heavily cratered plains.
- **(C)** Scientists can determine precise absolute ages whenever two ridges intersect.
- **(D)** Crater densities are useful for reconstructing planetary surfaces, but resurfacing and variable impact rates require scientists to interpret them with other geological evidence.
- **(E)** Surface ridges always result from cryovolcanic activity rather than tectonic stress.

::::solution[Solution]
**Answer:** (D)

**Type:** Main point / primary purpose (RC) (Chapter 18)

1. **Conclusion.** The passage advocates layered, qualified interpretation of crater maps.
2. **Support.** Crater survival, resurfacing relationships, and impact-rate variation complicate a simple clock.
3. **Prephrase.** Find a balanced answer preserving usefulness and limits.
4. **Why (D) is right.** The answer covers both classes of complication and the evidence-integration response.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Too strong; the author treats it as useful but conditional.
   - **(B)** **Trap: unsupported leap.** Resurfacing specifically challenges this inference.
   - **(C)** **Trap: too strong.** Intersections establish relative order, not calendar dates.
   - **(E)** **Trap: too strong.** Both mechanisms remain possibilities.

**Check:** P1 clock caveat; P2 resurfacing; P3 cross-cutting clues; P4 rates; P5 synthesis.
::::
:::

:::problem[Question II.9]
Suppose a ridge on Neris clearly cuts across the rim of a particular crater. What can be inferred from this observation alone?

- **(A)** The deformation that produced the ridge occurred after the impact that formed the crater.
- **(B)** The ridge formed from liquid water rather than ice.
- **(C)** The absolute age of the ridge can be calculated to the nearest year.
- **(D)** Every other crater on Neris is older than the ridge.
- **(E)** The crater formed immediately before the ridge.

::::solution[Solution]
**Answer:** (A)

**Type:** Inference (RC) (Chapter 18)

1. **Conclusion.** Cross-cutting geometry determines relative age.
2. **Support.** Paragraph three expressly says a ridge cutting a crater rim postdates that impact.
3. **Prephrase.** Limit the inference to before/after.
4. **Why (A) is right.** A feature that disrupts an existing rim must be younger than the disrupted rim.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Composition cannot be inferred from cross-cutting order alone.
   - **(C)** **Trap: unsupported leap.** Cross-cutting evidence gives sequence, not absolute date.
   - **(D)** **Trap: too strong.** One intersection cannot order unrelated features.
   - **(E)** **Trap: half-right / insufficient.** Relative order does not establish a short time interval.

**Check:** Impact first → crater rim exists → ridge cuts it later.
::::
:::

:::problem[Question II.10]
The comparison of small-crater frequencies near and far from fractures is mentioned primarily as a way to...

- **(A)** test whether resurfacing near the fractures preferentially erased earlier impact features.
- **(B)** calculate the exact mass of the moon’s impactors.
- **(C)** demonstrate that all crater sizes have identical survival probabilities.
- **(D)** replace every other type of geological evidence.
- **(E)** show that small impacts occur only near tectonic fractures.

::::solution[Solution]
**Answer:** (A)

**Type:** Function / purpose (RC) (Chapter 18)

1. **Conclusion.** The comparison is evidence for selective resurfacing.
2. **Support.** Paragraph three compares preservation around suspected geological activity.
3. **Prephrase.** Look for an observational diagnostic of erasure, not a complete age calculation.
4. **Why (A) is right.** A local deficit near fractures is consistent with alteration or burial of old small craters.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Crater location patterns do not directly yield exact masses.
   - **(C)** **Trap: too strong.** The comparison is motivated by possible differences in preservation.
   - **(D)** **Trap: too strong.** The author proposes combining imperfect clues.
   - **(E)** **Trap: unsupported leap.** The proposal looks for missing craters near fractures, not their exclusive formation there.

**Check:** Compare near-versus-far under the same broad impact environment; local disparity points to surface processes.
::::
:::

:::problem[Question II.11]
According to the passage, a low crater count on an icy plain that has been repeatedly resurfaced would most directly provide information about...

- **(A)** the age of the oldest buried layer, with no assumptions.
- **(B)** the chemical composition of debris in the moon’s orbit.
- **(C)** the exact date on which the moon itself originated.
- **(D)** the certainty that the plain has never undergone deformation.
- **(E)** how recently the visible surface was renewed, rather than necessarily when the underlying ice first formed.

::::solution[Solution]
**Answer:** (E)

**Type:** Detail / recognition (RC) (Chapter 18)

1. **Conclusion.** Visible crater density often dates retention since resurfacing.
2. **Support.** Paragraph two contrasts the original underlying terrain with the most recent covering event.
3. **Prephrase.** Distinguish underlying formation age from visible retention age.
4. **Why (E) is right.** The resurfacing reset removes older craters from sight, so the visible count tracks the new exposed layer.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Burial hides older surface history.
   - **(B)** **Trap: unsupported leap.** Counts alone do not identify debris chemistry.
   - **(C)** **Trap: unsupported leap.** The passage denies that crater density directly gives planetary birth dates.
   - **(D)** **Trap: too strong.** The stated scenario includes repeated resurfacing.

**Check:** Formation of underlying ice precedes resurfacing; a low count need not make the original substrate young.
::::
:::

:::problem[Question II.12]
The author views models of the population of impacting objects as...

- **(A)** perfectly accurate whenever a spacecraft image is sharp enough.
- **(B)** more informative about surface composition than about impact rates.
- **(C)** useful but subject to uncertainty when comparisons involve worlds with different impact environments.
- **(D)** unnecessary because crater density provides exact elapsed time by itself.
- **(E)** fundamentally fraudulent because researchers cannot count craters.

::::solution[Solution]
**Answer:** (C)

**Type:** Author attitude / tone (RC) (Chapter 18)

1. **Conclusion.** Models aid temporal estimates but carry cross-world assumptions.
2. **Support.** Paragraph four explains variable impact flux and conditional calibration.
3. **Prephrase.** Choose qualified utility rather than certainty or rejection.
4. **Why (C) is right.** The author values comparison yet cautions that different debris environments weaken precise transfers.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Image precision is distinguished from age precision.
   - **(B)** **Trap: unsupported leap.** The models are explicitly used for rate-to-duration conversion.
   - **(D)** **Trap: half-right / insufficient.** The author says translation requires models and qualifications.
   - **(E)** **Trap: unsupported leap.** No suggestion of dishonesty or inability to count.

**Check:** “Can be checked” is immediately qualified by “depend on how similar.”
::::
:::

:::problem[Question II.13]
A scientist finds fresh-looking ice on a smooth plain but no visible ridges intersecting any craters. Which conclusion would best fit the passage’s reasoning?

- **(A)** Resurfacing is plausible, but without cross-cutting evidence the chronology and extent of resurfacing remain uncertain.
- **(B)** Fresh-looking ice proves that the moon formed only recently.
- **(C)** Absence of crossed rims proves that resurfacing never occurred.
- **(D)** The impact rate must have been constant since the moon formed.
- **(E)** Every smooth plain on the moon must share an identical age.

::::solution[Solution]
**Answer:** (A)

**Type:** Application / analogy (RC) (Chapter 18)

1. **Conclusion.** Treat evidence as suggestive without over-reading chronology.
2. **Support.** The author emphasizes imperfect clues and stronger conclusions when independent relationships align.
3. **Prephrase.** Infer plausible resurfacing, but not a proven relative sequence without intersections.
4. **Why (A) is right.** It respects uncertainty while taking the fresh-looking surface seriously.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Conflates visible appearance with body formation age.
   - **(C)** **Trap: too strong.** Other resurfacing mechanisms or buried evidence remain possible.
   - **(D)** **Trap: unsupported leap.** No inference from ice appearance to impact flux is supported.
   - **(E)** **Trap: too strong.** Homogeneous age is explicitly warned against.

**Check:** No cross-cutting order means the claimed timeline lacks a key independent constraint.
::::
:::

:::problem[Question II.14]
Which one of the following best describes the passage’s organization?

- **(A)** A resurfacing hypothesis is accepted as conclusive and used to reject the need for impact-rate models.
- **(B)** A rejected theory is replaced with a newly established exact formula.
- **(C)** A sequence of experiments establishes that impact rates never change.
- **(D)** A standard method is introduced, its assumptions and complications are examined through an example, and a qualified combination of methods is recommended.
- **(E)** The crater densities of two hemispheres are contrasted to prove that one hemisphere formed later than the other.

::::solution[Solution]
**Answer:** (D)

**Type:** Structure / organization (RC) (Chapter 18)

1. **Conclusion.** The structure moves from technique through caveats to synthesis.
2. **Support.** P1 crater clock; P2-3 Neris and stratigraphy; P4 impact flux; P5 layered reconstruction.
3. **Prephrase.** Match the method-problem-integration arc.
4. **Why (D) is right.** Each clause maps to a distinct portion of the passage.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The author treats resurfacing as a possibility and still emphasizes uncertainty in rates.
   - **(B)** **Trap: unsupported leap.** The conclusion emphasizes uncertainty, not an exact replacement.
   - **(C)** **Trap: too strong.** The author explicitly notes variable rates.
   - **(E)** **Trap: unsupported leap.** The hemispheric example raises the possibility of resurfacing instead of proving a later formation date.

**Check:** Outline: common metric → preservation caveat → rate caveat → combined geological reasoning.
::::
:::

### Passage 3 (comparative)

**Passage A**

A city's public benches and small plazas often appear on planning maps as neutral amenities. Urban sociologists, however, have observed that their design affects which encounters can occur there. An open plaza with moveable chairs permits people to gather in changing configurations, while a narrow strip of fixed seating along a busy road offers fewer opportunities to linger or talk. These effects matter particularly for residents who cannot afford to meet regularly in commercial establishments. Public space can support casual relationships outside the household and workplace without requiring an admission fee.

Some planners have therefore proposed measuring the success of public space chiefly through counts of visitors and minutes of occupancy. Those measures are helpful but incomplete. A plaza may attract a crowd for a short festival while offering little opportunity for repeated interaction among residents. Another space may draw fewer visitors overall while sustaining regular meetings among neighbors who exchange information about jobs, childcare, or local services. For sociological purposes, the latter space may contribute more to durable community ties. Evaluation should therefore combine activity counts with observation of the kinds of interaction and repeated access the design permits. This requires more than a snapshot. Researchers might watch whether people recognize and greet one another across several visits, while remaining careful not to equate familiar faces with friendship.

**Passage B**

City officials frequently justify redesigning small plazas on the ground that the improvements will strengthen neighborhood social networks. Before making that claim, they should be cautious about treating a public setting as the cause of the social ties observed there. People who already share interests may choose to meet in the same square. A thriving mutual-aid group might make an otherwise ordinary plaza look socially successful even if benches and paths contributed little to the group's formation.

That difficulty does not make design irrelevant. A covered seat, for example, may enable older residents to continue meeting through rainy months. But an evaluation based only on who uses the improved square afterward risks confusing the selection of sociable residents with the effect of the redesign. One way forward would compare the same groups' interaction patterns before and after a change and collect observations at similar spaces that were not redesigned. Interviews could also distinguish meetings that arose because of the new features from meetings merely relocated to them.

Visitor counts, then, are a particularly poor substitute for evidence of causal change. A plaza that fills after renovation may have become socially valuable, or it may have attracted people who previously met elsewhere. To make that judgment, the researcher must identify a plausible comparison and explain what would likely have happened without the improvement. The proper question is not simply whether sociability is visible in a public place, but what difference the public place itself made.


:::problem[Question II.15]
Both authors would most likely agree with which one of the following statements?

- **(A)** Only a controlled experiment can provide any useful information about urban life.
- **(B)** Counting visitors alone is inadequate for determining a public space’s contribution to neighborhood social relationships.
- **(C)** Plaza design has no influence on how residents interact.
- **(D)** Neighborhoods should replace public plazas with commercial meeting spaces.
- **(E)** Any plaza with many visitors necessarily creates durable social networks.

::::solution[Solution]
**Answer:** (B)

**Type:** Agreement (comparative RC) (Chapter 17)

1. **Conclusion.** Both reject head counts as sufficient measures of social contribution.
2. **Support.** A focuses on kinds of interactions and repeated access; B focuses on causal changes versus relocation.
3. **Prephrase.** Use the both-must-have-a-stake test, identifying common ground without forcing identical reasoning.
4. **Why (B) is right.** Both explicitly say activity or visitor counts alone cannot demonstrate the claimed social contribution.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** B recommends comparisons but neither demands experiments as the sole evidence.
   - **(C)** **Trap: unsupported leap.** Both leave room for design effects and A emphasizes them.
   - **(D)** **Trap: unsupported leap.** A stresses the advantage of free public space; B does not propose replacement.
   - **(E)** **Trap: too strong.** Both question volume as a proxy for social benefits.

**Check:** A: counts “helpful but incomplete.” B: counts a “poor substitute” for causal evidence.
::::
:::

:::problem[Question II.16]
Which one of the following most accurately distinguishes the approaches of the two passages?

- **(A)** Passage A argues against public space, whereas Passage B calls for building as many plazas as possible.
- **(B)** Passage A denies that people choose where to meet, whereas Passage B denies that design can matter.
- **(C)** Passage A emphasizes who is excluded from paid meeting places, whereas Passage B argues that unpaid public spaces cannot sustain social networks.
- **(D)** Passage A seeks a single numerical score, whereas Passage B insists on visitor totals alone.
- **(E)** Passage A emphasizes what kinds of social interactions a design accommodates, whereas Passage B emphasizes isolating the design’s causal contribution to observed interactions.

::::solution[Solution]
**Answer:** (E)

**Type:** Different approach (comparative RC) (Chapter 17)

1. **Conclusion.** A asks what social function a setting supports; B asks how much of the function the setting caused.
2. **Support.** A contrasts durable ties with crowds; B highlights preexisting sociability and relocation.
3. **Prephrase.** Identify scope of evaluation versus causal identification.
4. **Why (E) is right.** The answer captures the difference in analytical emphasis while preserving shared interest in public space.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** A values public space; B offers no quantity mandate.
   - **(B)** **Trap: unsupported leap.** Neither writer makes either sweeping denial about the value or effects of plaza design.
   - **(C)** **Trap: wrong attribution.** A mentions economic access, but B does not reject the value of free spaces; its question is attribution of effects.
   - **(D)** **Trap: unsupported leap.** Both warn against single count measures.

**Check:** A: contribution quality. B: causal attribution and before/after controls.
::::
:::

:::problem[Question II.17]
How would the author of Passage A most likely respond to Passage B’s proposal to examine interactions before and after redesign?

- **(A)** The proposal could improve evaluation, provided it also captures the kinds and durability of interactions rather than merely changes in attendance.
- **(B)** The proposal proves that public spaces do not contribute to social relationships.
- **(C)** The proposal should replace all inquiry into how people use spaces.
- **(D)** The proposal would be acceptable only if visitor counts remained the principal measure of a plaza’s social value.
- **(E)** The proposal is invalid because nothing can be learned from observations over time.

::::solution[Solution]
**Answer:** (A)

**Type:** Author reaction (comparative RC) (Chapter 17)

1. **Conclusion.** A would welcome stronger evidence but insist on measuring social quality.
2. **Support.** A critiques head counts, not all longitudinal comparison; B’s design addresses attribution.
3. **Prephrase.** Combine methodological compatibility with A’s substantive priority.
4. **Why (A) is right.** The answer accepts controlled comparison while maintaining A’s concern with durable ties.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** B does not claim this, and A would reject it.
   - **(C)** **Trap: unsupported leap.** A values qualitative interaction measures and would not discard them.
   - **(D)** **Trap: half-right / insufficient.** A regards visitor counts as incomplete, so making them primary would recreate the deficiency A highlights.
   - **(E)** **Trap: unsupported leap.** A advocates observation of repeated access.

**Check:** The response does not assume the authors are opponents merely because their emphases differ.
::::
:::

:::problem[Question II.18]
Which one of the following inferences from the observations described in Passage A would the author of Passage B be most likely to challenge?

- **(A)** That urban sociologists study relationships outside workplaces.
- **(B)** That public interactions sometimes occur without payment.
- **(C)** That public plazas can include seating arrangements.
- **(D)** That festival crowds may be temporary.
- **(E)** That regular meetings observed at a plaza demonstrate the plaza itself contributes substantially to the formation of durable community ties.

::::solution[Solution]
**Answer:** (E)

**Type:** Author reaction (comparative RC) (Chapter 17)

1. **Conclusion.** B would demand causal evidence before assigning credit to the place.
2. **Support.** B warns that preexisting groups may choose to meet in a space regardless of design.
3. **Prephrase.** Find a claim making an inference from observed ties to the space’s own contribution.
4. **Why (E) is right.** B would say such ties might predate or merely relocate to the plaza, so observation alone is insufficient.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** B does not contest the field’s subject matter.
   - **(B)** **Trap: half-right / insufficient.** B offers no objection to the absence of admission fees.
   - **(C)** **Trap: unsupported leap.** B does not dispute this descriptive fact.
   - **(D)** **Trap: half-right / insufficient.** B would likely agree that attendance does not prove lasting ties.

**Check:** B’s alternative explanation leaves the observed meetings intact while denying the claimed cause.
::::
:::

:::problem[Question II.19]
A redesigned plaza adds a sheltered bench, and an existing group of older residents begins meeting there during rainy months. Which assessment would best accommodate both passages?

- **(A)** The meetings are socially meaningless because the residents already knew each other.
- **(B)** Visitor totals alone conclusively measure the bench’s contribution.
- **(C)** The improvement has unquestionably created a new group of residents who did not previously know one another.
- **(D)** The bench may make meetings easier, but researchers should still determine whether the group met elsewhere previously and whether the new pattern strengthens durable contact.
- **(E)** Shelter can never affect meeting practices, since sociability is always predetermined.

::::solution[Solution]
**Answer:** (D)

**Type:** Application (comparative RC) (Chapter 17)

1. **Conclusion.** A values supported interaction; B requires a causal comparison.
2. **Support.** Shelter enables contact in bad weather, but the group could have shifted its meeting site.
3. **Prephrase.** Credit possible facilitation without treating location change as creation of ties.
4. **Why (D) is right.** This integrates A’s durability criterion and B’s warning about relocation.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** A values sustaining ties; B does not deem existing ties worthless.
   - **(B)** **Trap: unsupported leap.** Both authors reject treating visitor totals alone as decisive evidence of social benefit.
   - **(C)** **Trap: unsupported leap.** The group is expressly existing; creation is unsupported.
   - **(E)** **Trap: too strong.** B expressly gives covered seating as a possible design effect.

**Check:** Ask both “what interaction is sustained?” and “what difference did the bench cause?”
::::
:::

:::problem[Question II.20]
Which one of the following ideas is explicitly advanced in Passage A but not in Passage B?

- **(A)** Existing social groups may select a plaza even if its design did little to create them.
- **(B)** Public space can be particularly useful to residents who cannot afford frequent meetings in commercial venues.
- **(C)** Meetings can be moved from one location to another without forming new ties.
- **(D)** Observation before and after redesign can help isolate changes.
- **(E)** A covered bench may help older residents continue meeting in wet weather.

::::solution[Solution]
**Answer:** (B)

**Type:** Detail / attribution (comparative RC) (Chapter 17)

1. **Conclusion.** The task is attribution to A alone.
2. **Support.** A’s first paragraph discusses the access value of free public locations; B does not mention economic access.
3. **Prephrase.** Return to the distinctive cost/access observation in A.
4. **Why (B) is right.** Only A explicitly contrasts public gathering with paid commercial establishments.
5. **Why the others fail.**
   - **(A)** **Trap: wrong attribution.** This is B’s distinctive causal alternative.
   - **(C)** **Trap: half-right / insufficient.** B explicitly raises relocation.
   - **(D)** **Trap: wrong attribution.** Passage B, not Passage A, recommends observation before and after the redesign.
   - **(E)** **Trap: wrong attribution.** The covered-bench example occurs specifically in Passage B, not in Passage A.

**Check:** The other choices are all identifiable in B’s paragraphs.
::::
:::

### Passage 4

The novelist Ada Vey is often assigned to the so-called Lantern Circle, an informal group of writers who published short fiction in industrial port towns during the early twentieth century. Critics once described the Circle as a movement devoted to documentary realism: its members wrote about shipping yards, rented rooms, and the routines of ordinary workers. Under this account, Vey's importance lies chiefly in her accurate representation of a particular social setting. More recent readings, however, have noticed that the apparently documentary details of her fiction frequently behave in ways that realism alone cannot explain.

In Vey's novel *The Second Window*, a boardinghouse corridor appears at several decisive moments. At first it is described with practical precision, down to a cracked tile and a faulty lamp. Later the same corridor seems longer or narrower depending on which character enters it. These descriptions are not necessarily errors in physical continuity. The novel’s shifting spatial account mirrors the characters' uncertainty about what they owe one another. A worker who believes he has betrayed his friend experiences the route to the friend's door as almost impossibly long; in a later chapter, another character crosses it in a sentence.

One influential critic interprets this technique as evidence that Vey rejected realism in favor of pure psychological symbolism. The interpretation captures something important: settings in the novel are not passive containers. Yet it risks replacing one restrictive label with another. The corridor's social function remains concrete. It is the shared passage between rooms that tenants rent separately, a place where privacy and communal obligation collide. The novel’s changing description gains force precisely because readers also understand the corridor as part of an economically constrained household. The psychological and material aspects of the scene work together rather than cancel each other.

This interaction helps explain why grouping Vey with the Lantern Circle remains useful, if the label is handled carefully. Several Circle writers explored how industrial employment reorganized domestic life, though they did not all use the same narrative techniques. Their shared subject matter offers a point of comparison, not a fixed template into which every work must fit. Vey's narrative experiments can be read as one way of examining a concern she shared with more conventional realists: what happens to human obligations when the spaces of work and home are organized by economic pressure?

A literary movement, then, need not be understood as a set of identical stylistic commitments. In Vey's case, the movement provides a historical conversation in which both documentary detail and formal innovation become intelligible. To regard her as only a chronicler of port life is to overlook her fiction's shifting forms; to regard her as only a symbolist is to overlook why those forms mattered.


:::problem[Question II.21]
Which one of the following most accurately states the main point of the passage?

- **(A)** Every Lantern Circle novelist used exactly the same narrative method.
- **(B)** Historical groupings of writers should be abandoned because they have no interpretive value.
- **(C)** Vey’s fiction is best understood through the interaction of material realism and narrative experimentation, with the Lantern Circle serving as a useful but flexible context.
- **(D)** Vey and the Lantern Circle rejected all realistic description.
- **(E)** Vey should be classified solely as a psychological symbolist.

::::solution[Solution]
**Answer:** (C)

**Type:** Main point / primary purpose (RC) (Chapter 18)

1. **Conclusion.** Vey belongs in a historical conversation while resisting a single stylistic label.
2. **Support.** Corridor scenes unite material conditions and shifting perception; the movement supplies a thematic comparison.
3. **Prephrase.** Look for an integrated interpretation rather than either exclusive category.
4. **Why (C) is right.** The answer captures the author’s consistent both-and argument and final conclusion.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** The passage explicitly says they did not.
   - **(B)** **Trap: unsupported leap.** The author defends qualified usefulness of the grouping.
   - **(D)** **Trap: unsupported leap.** The passage emphasizes persistent material detail.
   - **(E)** **Trap: unsupported leap.** This is the second restrictive view criticized.

**Check:** P1 old label → P2 form → P3 synthesis → P4 movement reassessed → P5 conclusion.
::::
:::

:::problem[Question II.22]
The detailed discussion of the corridor in *The Second Window* serves primarily to...

- **(A)** establish that the corridor is the only setting in the novel.
- **(B)** prove that actual boardinghouses commonly changed shape during the period.
- **(C)** show how an ordinary physical setting can convey psychological changes without losing its concrete social meaning.
- **(D)** show that character development is irrelevant to spatial description.
- **(E)** demonstrate that Vey was unable to keep the architecture of her fictional building consistent.

::::solution[Solution]
**Answer:** (C)

**Type:** Function / purpose (RC) (Chapter 18)

1. **Conclusion.** The corridor example makes the synthesis of formal and material interpretation concrete.
2. **Support.** Shifting perceived length tracks conscience while a shared rental corridor embodies social obligation.
3. **Prephrase.** Identify the two functions at once rather than choosing symbolic OR physical.
4. **Why (C) is right.** The setting is psychologically elastic and materially specific, which is the passage’s central interpretive point.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** No claim about every setting appears.
   - **(B)** **Trap: unsupported leap.** The descriptions are a narrative device, not a physical historical claim.
   - **(D)** **Trap: scope shift.** Character psychology motivates the spatial shifts.
   - **(E)** **Trap: unsupported leap.** The author expressly cautions against reading variations as continuity errors.

**Check:** One image does both: subjective passage length and objectively shared tenant space.
::::
:::

:::problem[Question II.23]
Which one of the following can most reasonably be inferred about the critic who reads Vey as a pure psychological symbolist?

- **(A)** The critic notices an important aspect of Vey’s technique but gives inadequate weight to the social function of her settings.
- **(B)** The critic has never read *The Second Window* in full.
- **(C)** The critic correctly notices Vey’s shifting descriptions but emphasizes the economic meaning of the corridor more than the author does.
- **(D)** The critic denies that Vey wrote about industrial workers.
- **(E)** The critic places Vey within the Lantern Circle largely because her techniques are identical to those of its other writers.

::::solution[Solution]
**Answer:** (A)

**Type:** Inference (RC) (Chapter 18)

1. **Conclusion.** The pure-symbolism reading captures form but is reductive.
2. **Support.** Paragraph three grants insight, then criticizes disregard for economic and communal setting.
3. **Prephrase.** Look for a modest qualified criticism.
4. **Why (A) is right.** The answer reproduces the concession and omission without inventing biographical facts.
5. **Why the others fail.**
   - **(B)** **Trap: too strong.** Nothing is said about the critic’s reading habits.
   - **(C)** **Trap: half-right / insufficient.** The critic notices psychological symbolism, while it is the passage’s author who restores the corridor’s economic meaning.
   - **(D)** **Trap: unsupported leap.** The author says the reading risks neglecting context, not that it explicitly denies workers.
   - **(E)** **Trap: too strong.** The passage attributes pure-symbolist interpretation to this critic, not a claim of identical techniques across the Circle.

**Check:** “Captures something important” + “risks replacing one restrictive label with another.”
::::
:::

:::problem[Question II.24]
Which one of the following approaches to another literary movement would be most consistent with the author’s treatment of the Lantern Circle?

- **(A)** Comparing writers’ shared historical concerns while allowing for substantial differences in form and style.
- **(B)** Treating any technical innovation as proof that an author cannot belong to a movement.
- **(C)** Assuming that writers with similar subjects must have identical political opinions.
- **(D)** Ignoring all historical circumstances to avoid making generalizations.
- **(E)** Defining membership only by identical sentence length and narrative point of view.

::::solution[Solution]
**Answer:** (A)

**Type:** Application / analogy (RC) (Chapter 18)

1. **Conclusion.** Use literary groupings as comparative contexts, not prescriptions.
2. **Support.** Paragraph four explicitly separates shared concerns from identical techniques.
3. **Prephrase.** Choose a flexible thematic comparison.
4. **Why (A) is right.** The option maps directly onto the author’s definition of a useful movement.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Vey’s innovation is presented as compatible with meaningful membership.
   - **(C)** **Trap: too strong.** Shared concerns do not establish uniform ideology.
   - **(D)** **Trap: unsupported leap.** The author uses historical context as a useful conversation.
   - **(E)** **Trap: too strong.** The passage rejects a rigid stylistic template.

**Check:** Shared subject → basis for comparison; varied style → not disqualifying.
::::
:::

:::problem[Question II.25]
The author’s attitude toward the earlier documentary-realist interpretation of Vey is best characterized as...

- **(A)** rejecting every factual claim made by readers who identify industrial settings.
- **(B)** concluding that it proves Vey never experimented with form.
- **(C)** regarding it as informative about Vey’s subject matter but insufficient to explain her narrative techniques.
- **(D)** condemning it as deliberately deceptive scholarship.
- **(E)** accepting it as a complete interpretation that requires no revision.

::::solution[Solution]
**Answer:** (C)

**Type:** Author attitude / tone (RC) (Chapter 18)

1. **Conclusion.** The tone is qualified disagreement rather than dismissal.
2. **Support.** Earlier realism captures social setting, but misses psychologically shifting physical descriptions.
3. **Prephrase.** Match partial validity plus insufficiency.
4. **Why (C) is right.** The answer preserves the contribution of documentary detail while identifying the omitted formal feature.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Those details are accepted as important.
   - **(B)** **Trap: too strong.** The corridor passages exhibit precisely such experimentation.
   - **(D)** **Trap: unsupported leap.** The critique is interpretive, not a claim of dishonesty.
   - **(E)** **Trap: unsupported leap.** The passage explicitly moves beyond it.

**Check:** The author first describes old reading and then says realism alone cannot explain some details.
::::
:::

:::problem[Question II.26]
According to the passage, one concern Vey shared with other Lantern Circle writers involved...

- **(A)** whether the shared corridors in boardinghouses could be represented using strictly consistent physical dimensions.
- **(B)** why every writer should abandon ordinary working-class settings.
- **(C)** how industrial employment reshaped domestic life and obligations among people living under economic pressure.
- **(D)** whether port employers should regulate every aspect of tenants’ private lives.
- **(E)** whether psychological symbolism always produces unreliable narrators.

::::solution[Solution]
**Answer:** (C)

**Type:** Detail / recognition (RC) (Chapter 18)

1. **Conclusion.** The shared subject is social obligations shaped by work and home arrangements.
2. **Support.** Paragraph four connects industrial labor, domestic space, and economic pressure.
3. **Prephrase.** Distinguish common historical concerns from identical artistic technique.
4. **Why (C) is right.** The answer synthesizes the passage’s explicit common question.
5. **Why the others fail.**
   - **(A)** **Trap: half-right / insufficient.** The corridor’s changing dimensions illustrate Vey’s technique, not a stated theme shared by the entire Circle.
   - **(B)** **Trap: too strong.** The shared focus is on those settings, not their abandonment.
   - **(D)** **Trap: too strong.** This specific proposed policy is not the author’s stated shared concern about industrial work and domestic obligation.
   - **(E)** **Trap: too strong.** The passage does not posit this common question.

**Check:** The shared concern is specified in paragraph four’s final sentence.
::::
:::

:::problem[Question II.27]
Which one of the following best describes the passage’s overall structure?

- **(A)** The economic history of port towns is surveyed and then claimed to explain every formal feature of Vey’s work.
- **(B)** A conventional classification is introduced, a novelistic example complicates it, and a broader interpretation reconciles style with historical context.
- **(C)** A novelist’s changing spatial imagery is described and used to argue that documentary realism has no interpretive value.
- **(D)** A purely biographical account establishes that Vey wrote without artistic intention.
- **(E)** A literary movement is introduced as stylistically uniform and ultimately defended as an entirely fixed category.

::::solution[Solution]
**Answer:** (B)

**Type:** Structure / organization (RC) (Chapter 18)

1. **Conclusion.** The author moves from a restrictive label to a synthetic account.
2. **Support.** P1 realism classification, P2 corridor complication, P3 synthesis, P4-5 qualified movement framework.
3. **Prephrase.** Match the argument’s staging rather than individual images.
4. **Why (B) is right.** The credited sequence describes the whole passage and the final “both-and” resolution.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Historical context matters, but the author explicitly avoids reducing formal innovation to a single exhaustive social explanation.
   - **(C)** **Trap: unsupported leap.** The imagery is relevant, but the author preserves the value of documentary detail rather than dismissing it.
   - **(D)** **Trap: half-right / insufficient.** The analysis concerns textual technique and interpretive framing.
   - **(E)** **Trap: unsupported leap.** The argument begins with a restrictive categorization but ends by rejecting fixed stylistic templates.

**Check:** Map: old classification → counterexample → integrated interpretation → historical reframing.
::::
:::


## 29.3 Section III: Logical Reasoning

**25 questions · 35 minutes**


:::problem[Question III.1]
A laptop manufacturer replaced the thermal pads used in a particular workstation model. After the change, devices in a customer-service database showed fewer sudden shutdowns from overheating. Engineers believe the new pads were responsible, although the company also released a firmware update that made the cooling fan engage earlier. The database contains warranty service dates and firmware versions, enabling comparison of units that received the firmware update before and after the new pads were installed.

Which one of the following, if true, most strengthens the engineers’ explanation?

- **(A)** The firmware update made the fan more audible.
- **(B)** The company plans to use the new pads in its other computers.
- **(C)** Among machines running the same firmware version under comparable workloads, those with the new pads experienced substantially fewer heat-related shutdowns.
- **(D)** Some new-pad units received a different operating-system update than old-pad units.
- **(E)** The new pads are cheaper to manufacture.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The replacement pads reduced heat-related shutdowns.
2. **Support.** Overall incidents fell but firmware changed too, creating a confound.
3. **Prephrase.** Hold firmware and workload constant to isolate pad material.
4. **Why (C) is right.** Within-firmware comparisons show a persistent pad effect and weaken the firmware-only explanation.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Sound changes do not isolate the pads’ contribution.
   - **(B)** **Trap: unsupported leap.** An intention to expand is not evidence that pads caused the improvement.
   - **(D)** **Trap: unsupported leap.** This supplies a further possible confound rather than isolating the pad as the cause of the shutdown reduction.
   - **(E)** **Trap: unsupported leap.** Cost does not demonstrate a cooling benefit.

**Check:** Compare old versus new pads conditional on identical firmware; the effect remains.
::::
:::

:::problem[Question III.2]
A cereal producer expects a new cardboard box design to raise sales without changing the cereal itself. In a supermarket trial, shoppers preferred the new package when the two boxes were displayed side by side. The producer plans to replace every old package nationwide, so buyers will not be choosing between the two designs in a single display. The marketing director nonetheless argues that the side-by-side preference demonstrates that the new packaging will generate additional purchases rather than merely redirect existing customers to a differently presented box.

Which one of the following is an assumption on which the director’s argument depends?

- **(A)** The preference observed side by side is equally strong in every region.
- **(B)** The cereal tastes better in the new box.
- **(C)** Every shopper who sees the new design will buy a box.
- **(D)** The new box is made from less cardboard than the old box.
- **(E)** At least some shoppers whose purchases will be influenced by the new package would not otherwise have purchased that cereal.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Changing the box will create additional sales, not merely shift preferences among existing buyers.
2. **Support.** Side-by-side preference says nothing about purchases from people who otherwise would not buy.
3. **Prephrase.** Some induced buyers must be incremental rather than existing customers.
4. **Why (E) is right.** If all influenced purchasers would have bought the cereal anyway, package replacement cannot create the claimed new sales through that influence.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Regional uniformity is not necessary for a net increase.
   - **(B)** **Trap: half-right / insufficient.** The cereal is unchanged and packaging may influence sales independently of taste.
   - **(C)** **Trap: too strong.** Far stronger than needed for a sales increase.
   - **(D)** **Trap: half-right / insufficient.** Lower packaging material may be desirable, but it does not establish that side-by-side preference creates new purchases.

**Check:** Negate: every influenced shopper would have bought it anyway; preference alone yields no added purchases.
::::
:::

:::problem[Question III.3]
An aquaculture entrepreneur reports that fish in ponds using an automated oxygen sensor survived the summer at higher rates than fish in nearby ponds without the sensor. She concludes that the sensor caused the survival improvement. Sensor-equipped ponds were, however, the only ponds managed by technicians trained to adjust feed rates and inspect water pumps daily. The entrepreneur discounts this distinction because all ponds had identical oxygen readings on the one afternoon she checked them.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** uses too small a pond count even though no pond count is given.
- **(B)** assumes that sensor-equipped ponds received fewer hours of daylight than nearby ponds.
- **(C)** fails to consider that the technicians’ other management practices, rather than the sensors, may account for the better survival rates.
- **(D)** claims that all ponds had identical oxygen levels throughout the summer.
- **(E)** concludes that sensors were installed after survival rates had already risen.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Sensors caused the survival advantage.
2. **Support.** Sensors co-occurred with trained technicians and varied management; a single oxygen measurement cannot isolate cause.
3. **Prephrase.** Name the ignored common accompanying factor.
4. **Why (C) is right.** Better feeding or pump maintenance offers an alternative cause of survival.
5. **Why the others fail.**
   - **(A)** **Trap: half-right / insufficient.** Sample size could matter but is not evidenced as the specific problem.
   - **(B)** **Trap: unsupported leap.** This invents a daylight difference not described by the entrepreneur; the real confound concerns technicians’ feed and pump practices.
   - **(D)** **Trap: too strong.** Only one afternoon is cited; the argument does not explicitly claim universal equality.
   - **(E)** **Trap: unsupported leap.** The temporal order is not misstated in this fashion.

**Check:** Countermodel: technicians improve survival while sensors are inert; all stated observations remain possible.
::::
:::

:::problem[Question III.4]
A neighborhood running club has traditionally reserved its leadership election for members who attend at least ten meetings a year. Supporters of the rule say attendance demonstrates commitment, and active volunteers do tend to attend often. But members whose work schedules prevent regular meeting attendance still organize races and recruit new runners. Moreover, the club now offers reliable online participation. Commitment can be shown in more than one way. The election rule should therefore be revised to count substantial service to the club as an alternative qualification.

Which one of the following most accurately states the main conclusion?

- **(A)** The running club should permit substantial service as an alternative way to qualify for leadership elections.
- **(B)** Active volunteers tend to attend club meetings frequently.
- **(C)** Online participation is always better than attending meetings.
- **(D)** A member can contribute to the club without attending ten meetings.
- **(E)** The club should abolish all qualifications for its leaders.

::::solution[Solution]
**Answer:** (A)

**Type:** Main conclusion (Chapter 11)

1. **Conclusion.** Count substantial service as an alternative eligibility condition.
2. **Support.** Useful volunteers can miss meetings; remote participation broadens forms of commitment.
3. **Prephrase.** Identify the “should therefore” proposal and retain its narrow scope.
4. **Why (A) is right.** The answer matches the proposed revision without claiming automatic eligibility for everyone.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** A supporting observation offered by defenders of the old rule.
   - **(C)** **Trap: too strong.** Too strong and never asserted.
   - **(D)** **Trap: premise for conclusion.** A premise motivating the proposed rule change, not the final recommendation.
   - **(E)** **Trap: unsupported leap.** The proposal changes qualification, not removes it entirely.

**Check:** Replace “ten meetings only” with “ten meetings OR substantial service”; the latter is the argument’s policy recommendation.
::::
:::

:::problem[Question III.5]
A retailer introduced free returns for online running shoes in March. Its total number of online orders rose over the next quarter, and its return rate rose too. Yet the total number of pairs kept by customers at the end of the return window declined. The purchasing manager found the result surprising because more orders should ordinarily yield more pairs kept, even if more merchandise is returned. Orders are counted at checkout, while kept pairs are counted only after all eligible refunds and exchanges finish processing.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** The retail price of each shoe model remained unchanged throughout the quarter.
- **(B)** Free returns reduced the company’s shipping charges to customers.
- **(C)** Most shoppers who ordered in March lived near a delivery depot.
- **(D)** The retailer’s website loaded more quickly after March.
- **(E)** Shoppers increasingly ordered several sizes of the same shoe and returned all but one, sometimes returning every size.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** Explain how more orders coexist with fewer retained pairs.
2. **Support.** A higher return rate can more than offset the order increase, especially through multi-size ordering.
3. **Prephrase.** Identify a rise in pairs ordered for trial rather than for retention.
4. **Why (E) is right.** Multi-size purchasing inflates placed orders while a large fraction flows back as returns.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Constant prices control a possible purchasing influence but do not explain why retention fell amid rising orders.
   - **(B)** **Trap: unsupported leap.** Rephrases the policy but lacks the multiple-item return mechanism.
   - **(C)** **Trap: unsupported leap.** Delivery distance does not account for the returned fraction.
   - **(D)** **Trap: half-right / insufficient.** May explain extra orders but not fewer kept pairs by itself.

**Check:** Kept pairs = ordered pairs − returned pairs; returns can increase by more than orders do.
::::
:::

:::problem[Question III.6]
A suburban landscaping company claims that installing smart irrigation controllers reduces household electricity use because the controllers automatically shorten sprinkler operation during cool weather. Its evidence is an analysis of houses whose owners voluntarily purchased controllers: their electricity bills were lower afterward. The report notes that many participating owners bought the devices when they also moved from electric well pumps to municipal water connections. The company argues that the post-installation decline in bills shows the controller itself reduces energy consumption.

Which one of the following, if true, most seriously weakens the company’s argument?

- **(A)** The controllers are compatible with both municipal and well-water systems.
- **(B)** Some owners praise the controllers’ smartphone interface.
- **(C)** Municipal water users pay a separate water-service fee.
- **(D)** The reduction in electricity bills occurred almost entirely in households that stopped operating electric well pumps.
- **(E)** The controllers consume a small amount of electricity to run their displays.

::::solution[Solution]
**Answer:** (D)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Controllers themselves reduced electricity consumption.
2. **Support.** Bills fell after installation, but many owners simultaneously eliminated electric pumps.
3. **Prephrase.** Look for evidence that pump removal, not controller action, explains the drop.
4. **Why (D) is right.** Concentration of savings among pump-switching households directly supports the alternative cause.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Compatibility does not remove the well-pump confound.
   - **(B)** **Trap: unsupported leap.** Satisfaction cannot establish the causal energy effect.
   - **(C)** **Trap: unsupported leap.** New charges do not establish the source of reduced electricity consumption.
   - **(E)** **Trap: half-right / insufficient.** A minor use may offset some savings but not as directly explain the observed large decline.

**Check:** Compare homes with unchanged pump arrangements; absence of comparable savings would undermine controller attribution.
::::
:::

:::problem[Question III.7]
A digital archive permits public downloads of every work whose author granted a redistribution license. It also preserves drafts that authors have not licensed, but these drafts can only be viewed in a reading room. All works in the archive's “Open Translation” collection have redistribution licenses, and at least one work in that collection is a translation of a stage play. Some licensed works are not in any named collection. The archive has not stated whether every downloadable work is licensed.

Which one of the following must be true?

- **(A)** Every item available for public download belongs to the Open Translation collection.
- **(B)** Every downloadable item has a redistribution license.
- **(C)** Some unlicensed drafts can be downloaded from the public site.
- **(D)** At least one translation of a stage play in the archive is available for public download.
- **(E)** Every licensed work is a translation of a stage play.

::::solution[Solution]
**Answer:** (D)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** Derive one guaranteed downloadable play translation.
2. **Support.** Open Translation → licensed → downloadable; at least one Open Translation item is a play translation.
3. **Prephrase.** Apply the universal chain to the specified existent item.
4. **Why (D) is right.** That item must be licensed and therefore downloadable.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** The archive allows licensed works outside named collections.
   - **(B)** **Trap: reversal.** Reverses a sufficient condition; the archive expressly leaves this open.
   - **(C)** **Trap: unsupported leap.** Conflicts with the reading-room-only restriction.
   - **(E)** **Trap: wrong logical form.** An existential translated play does not characterize all licensed works.

**Check:** Choose a play translation P in Open Translation: O(P) → L(P) → D(P).
::::
:::

:::problem[Question III.8]
A city food board is considering whether supermarkets may place discounted “freshness” tags on produce nearing the end of its usual display life. One proposal would require the stores to discard any item past an internal display date, even if independent tests show it remains safe and edible. A competing proposal would permit sale after that date when a reliable inspection confirms safety and the tag accurately indicates reduced quality. A board member favors the second proposal because it protects purchasers without destroying usable food.

Which one of the following principles most supports the board member’s proposal?

- **(A)** Internal display dates always provide more reliable safety information than testing.
- **(B)** When produce passes a safety inspection, sellers need not disclose reduced taste or texture.
- **(C)** Food that is verifiably safe but below ordinary quality standards may be sold with accurate disclosure rather than discarded solely because of a non-safety display date.
- **(D)** Food should be discarded whenever its flavor changes in any detectable way.
- **(E)** Every food item should be sold regardless of its safety condition.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Permit inspected safe goods after the display date with quality disclosure.
2. **Support.** A date may track aesthetic freshness rather than actual safety.
3. **Prephrase.** Use a safety-plus-honest-disclosure principle rather than a blanket prohibition.
4. **Why (C) is right.** The principle exactly separates safety from quality and allows sale with accurate labeling.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** Favors the opposite policy and overstates date reliability.
   - **(B)** **Trap: unsupported leap.** This omits the accurate quality warning required by the board member’s proposal.
   - **(D)** **Trap: too strong.** Contradicts the proposal’s tolerance of disclosed quality reduction.
   - **(E)** **Trap: too strong.** Eliminates the inspection safeguard essential to the proposal.

**Check:** Safe inspection + reduced quality disclosed → permitted sale, matching the proposed rule.
::::
:::

:::problem[Question III.9]
A game studio reports that players using its revised networking code won more competitive matches than players on the older code. The producer infers that reduced input latency caused the wins. But the revised-code group played primarily on low-latency local servers, while the older-code group mostly used distant servers. A tester asks for a comparison within the same server region. The producer refuses, arguing that a greater win rate is itself proof that the code produced an improvement in latency.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** draws a conclusion about all games from evidence about one game.
- **(B)** fails to compare the two code versions on whether players found the interface more enjoyable.
- **(C)** attributes an outcome to revised code without separating the code’s effect from the influence of server location.
- **(D)** argues that competitive success guarantees the absence of software bugs.
- **(E)** assumes that faster code is always more enjoyable.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Revised networking code reduced latency and thereby increased wins.
2. **Support.** Groups differed by server proximity, an obvious alternative source of latency and success.
3. **Prephrase.** Name confounding: a matched geographic comparison was omitted.
4. **Why (C) is right.** Regional proximity could explain both measured performance and win rates independently of code.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The conclusion is about this studio’s code in this setting.
   - **(B)** **Trap: half-right / insufficient.** Enjoyment might affect retention but does not test the specified code-versus-server cause of wins.
   - **(D)** **Trap: unsupported leap.** The conclusion concerns latency, not all errors.
   - **(E)** **Trap: too strong.** No claim about enjoyment appears.

**Check:** Hold server region constant; if the difference vanishes, the supposed code effect was confounded.
::::
:::

:::problem[Question III.10]
A retailer buys waterproof jackets only from suppliers whose products meet its abrasion-resistance criterion. Any jacket that satisfies both the abrasion-resistance criterion and the retailer’s seam-sealing criterion receives an “all-weather” certificate. A supplier's new jacket meets the abrasion criterion, but nothing has yet been said about its seams. The supplier argues that the jacket is entitled to the all-weather certificate simply because the retailer has agreed to stock it.

Which one of the following, if assumed, allows the supplier’s conclusion to be properly drawn?

- **(A)** Every jacket the retailer has agreed to stock also satisfies the seam-sealing criterion.
- **(B)** All abrasion-resistant jackets satisfy the retailer’s preferred outer-fabric specifications.
- **(C)** Every all-weather-certified jacket meets the abrasion criterion.
- **(D)** Some stocked jackets have received all-weather certificates.
- **(E)** Seam-sealing is more expensive than abrasion-resistant fabric.

::::solution[Solution]
**Answer:** (A)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** This stocked jacket is entitled to an all-weather certificate.
2. **Support.** Stocking policy supplies abrasion resistance; certificate requires abrasion AND seams.
3. **Prephrase.** Supply the missing seam condition for this stocked jacket.
4. **Why (A) is right.** Stocked → seams; the existing policy gives stocked → abrasion, so both certification requirements hold.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** This repeats information about fabric or abrasion, but supplies nothing about the missing seam criterion.
   - **(C)** **Trap: reversal.** Reverses one component of the rule and adds no seam evidence.
   - **(D)** **Trap: unsupported leap.** Existence of other certificates cannot establish this jacket’s status.
   - **(E)** **Trap: unsupported leap.** Cost ranking does not satisfy a condition.

**Check:** S → A and S → M; (A ∧ M) → C; S, therefore C.
::::
:::

:::problem[Question III.11]
A farm-equipment seller predicts that bundling a rugged solar-powered tablet with a crop-monitoring kit will lower total customer service costs. A preliminary review found that customers who used the tablet contacted support less often, but those customers were also more experienced with the monitoring kit. The seller has now introduced the tablet to randomly assigned new customers and plans to compare their number of support calls with a control group receiving identical training and equipment except for the tablet.

Which one of the following, if true, most strengthens the seller’s prediction?

- **(A)** The printed installation instructions were identical in both new-customer groups.
- **(B)** Among randomly assigned new customers with otherwise identical training, the tablet group made substantially fewer support calls without incurring greater replacement or maintenance expenses.
- **(C)** The tablet contains a larger battery than the previous field display.
- **(D)** Experienced customers praised the tablet’s screen brightness.
- **(E)** New customers using tablets placed more calls during the first two days.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Tablet bundling reduces total service costs.
2. **Support.** The original fewer-calls group was more experienced; random allocation can isolate device effect.
3. **Prephrase.** Find a controlled comparison showing call savings without hidden maintenance costs.
4. **Why (B) is right.** Randomization and equal training address experience, while no extra maintenance cost closes the net-cost gap.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** A controlled instruction booklet reduces one confound, but by itself supplies no evidence of fewer calls or lower total costs.
   - **(C)** **Trap: unsupported leap.** Hardware specification alone provides no total support-cost comparison.
   - **(D)** **Trap: half-right / insufficient.** Preference from the originally confounded group does not establish service savings.
   - **(E)** **Trap: unsupported leap.** This can undermine the savings claim unless offset later.

**Check:** Compare support plus maintenance costs between randomized groups; the tablet group is lower.
::::
:::

:::problem[Question III.12]
A linguist doubts the claim that a disappearing verb ending was never used by younger speakers. The available recordings come mainly from formal interviews, where younger speakers may monitor their language. The linguist proposes examining informal peer conversations from the same communities and comparing speakers of similar ages across settings. If the ending appears in the informal recordings, it would undermine the claim that younger speakers abandoned it entirely. The linguist does not assume the ending is common; a single clear counterexample would refute the absolute claim.

Which one of the following most accurately describes the linguist’s reasoning?

- **(A)** The linguist concludes that younger speakers use the ending more often than older speakers.
- **(B)** The linguist treats interviewer testimony as proof that informal speech is identical.
- **(C)** The linguist argues that a claim is true unless a counterexample is found.
- **(D)** The linguist proposes a setting-sensitive observation capable of providing a counterexample to a universal negative claim.
- **(E)** The linguist rejects all recorded evidence as inherently unreliable.

::::solution[Solution]
**Answer:** (D)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** The universal absence claim should be tested with recordings that can reveal a single counterexample.
2. **Support.** Formal interviewing may suppress a usage that persists informally.
3. **Prephrase.** Describe a test of an absolute proposition by looking for a counterexample.
4. **Why (D) is right.** A single occurrence by a younger speaker disproves “never,” and matched settings address recording bias.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** No frequency comparison has been established.
   - **(B)** **Trap: unsupported leap.** The concern is that settings differ, not that they are identical.
   - **(C)** **Trap: unsupported leap.** Absence of a counterexample would not demonstrate truth.
   - **(E)** **Trap: unsupported leap.** The proposal is to improve evidence, not reject recordings generally.

**Check:** Universal “none use it” is falsified by one qualifying observed use.
::::
:::

:::problem[Question III.13]
A farming cooperative intends to use a drone's color-based images to identify fields with a particular fungal disease. Engineers say the image classifier performs accurately on infected leaves in greenhouse conditions. The cooperative argues that it can therefore send treatment crews only to fields flagged by the drone, saving labor without leaving any severely infected field untreated. However, the drone flies above dense crop canopies, and the disease sometimes starts on leaves hidden beneath healthy upper growth.

Which one of the following assumptions is required by the cooperative’s argument?

- **(A)** The drone’s flight path avoids fields that have already been treated against fungal disease.
- **(B)** No severely infected field will consistently escape the drone’s detection because the relevant symptoms are hidden from the camera.
- **(C)** The drone correctly labels every individual leaf in every field.
- **(D)** All healthy fields appear the same color from the air.
- **(E)** The disease never begins on lower leaves.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Treat only flagged fields without missing any severely infected field.
2. **Support.** Greenhouse leaf-level accuracy may not translate to aerial visibility through dense canopies.
3. **Prephrase.** Rule out completely hidden severe infections that lead to false negatives.
4. **Why (B) is right.** If severely infected fields can remain consistently invisible, limiting crews to flagged fields will miss them.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Skipping treated fields says nothing about whether an untreated severely infected field is visible under the canopy.
   - **(C)** **Trap: too strong.** Much stronger than necessary to avoid missing severely infected fields.
   - **(D)** **Trap: half-right / insufficient.** Not required for detecting severe infections; healthy fields may vary.
   - **(E)** **Trap: too strong.** The passage says it sometimes does; the system might still detect serious cases later.

**Check:** Negate: some severely infected fields consistently evade detection due to occlusion; the no-missed-field promise fails.
::::
:::

:::problem[Question III.14]
Operations director: Our grocery service should assign drivers to fixed neighborhoods. Familiarity with streets improves reliability, and customers care most about getting orders within their promised windows. Analyst: Neighborhood familiarity may improve reliability, but fixed assignments prevent the company from shifting spare drivers toward sudden spikes in demand. The service should prioritize the flexibility to move drivers between neighborhoods, even if that occasionally makes an arrival window less predictable. Both agree that deliveries should be safe and that the company must obey drivers' work-hour limits.

The speakers disagree over whether...

- **(A)** deliveries should be completed safely.
- **(B)** drivers must comply with legal work-hour limits.
- **(C)** knowing local streets can improve reliability.
- **(D)** customer demand sometimes changes unexpectedly.
- **(E)** flexibly moving drivers between neighborhoods should take priority over consistent arrival-window reliability.

::::solution[Solution]
**Answer:** (E)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** The issue is prioritizing reliability versus cross-neighborhood flexibility.
2. **Support.** The director favors fixed familiarity and delivery windows; the analyst favors reallocating spare drivers despite some unpredictability.
3. **Prephrase.** Find the choice with determinable and opposite priorities.
4. **Why (E) is right.** The director gives priority to window reliability; the analyst expressly gives priority to flexibility instead.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Both explicitly agree on safety.
   - **(B)** **Trap: unsupported leap.** Both explicitly agree that they must.
   - **(C)** **Trap: unsupported leap.** The analyst explicitly concedes this point.
   - **(D)** **Trap: unsupported leap.** The analyst raises this; the director does not deny it.

**Check:** Director: flexibility over reliability, no. Analyst: yes.
::::
:::

:::problem[Question III.15]
A software firm uses a security checklist that every product patch must pass before release. The firm’s latest patch has passed the checklist. A sales representative tells customers that the patch therefore must already have been deployed to every supported device. The representative acknowledges that many patches remain in a staging queue while staff schedule updates, but insists that passing the checklist is enough to demonstrate deployment because no unapproved patches are deployed.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** argues that a security checklist cannot detect any software problem.
- **(B)** confuses a necessary condition for deployment with a sufficient condition for deployment.
- **(C)** assumes that passing a security checklist takes the same amount of time for every patch.
- **(D)** treats staged updates as evidence that no patches will ever be deployed.
- **(E)** relies on a statistical sample that might be unrepresentative.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The approved patch has been deployed to every supported device.
2. **Support.** Deployment → checklist passed; the patch passed; staged patches show approval need not trigger immediate deployment.
3. **Prephrase.** Spot the invalid reverse arrow.
4. **Why (B) is right.** From “deployed only if approved,” the representative infers “approved, therefore deployed.”
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The representative does not criticize the checklist’s reliability.
   - **(C)** **Trap: too strong.** Time needed for approval is not the mistaken logical link from approval to deployment.
   - **(D)** **Trap: unsupported leap.** The claim concerns this patch’s current deployment, not permanent delays.
   - **(E)** **Trap: half-right / insufficient.** No sample-based inference appears.

**Check:** Diagram D → C; C does not imply D.
::::
:::

:::problem[Question III.16]
A regional grocery chain tested advertisements in two languages. Its marketing report says that bilingual households remembered the campaign more often than monolingual households did. The bilingual households were mostly recruited from a neighborhood where advertisements ran twice daily, while the monolingual households came largely from an area where the same advertisements ran once a week. Within the small group of households that received the same number of exposures, recall rates were nearly identical. The chain did not measure purchase behavior in either group.

Which one of the following is most strongly supported by the statements above?

- **(A)** The campaign would fail if advertisements aired only weekly.
- **(B)** The reported difference in recall cannot confidently be attributed to households’ bilingual status independently of advertising exposure.
- **(C)** All households exposed equally often remembered the ads at exactly the same rate.
- **(D)** Monolingual households are less attentive to all forms of advertising.
- **(E)** Bilingual advertising necessarily reduces purchases among monolingual shoppers.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The bilingual-status difference is not an isolated explanation for recall.
2. **Support.** Groups received drastically different ad frequencies; the limited exposure-matched subgroup showed similar recall.
3. **Prephrase.** State the confound without claiming bilingualism has no effect at all.
4. **Why (B) is right.** Variation in exposure is a plausible account of the observed gap, so bilingual status is not independently established as the cause.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The data concern differences in recall, not overall campaign failure.
   - **(C)** **Trap: too strong.** “Nearly identical” does not mean exact equality.
   - **(D)** **Trap: unsupported leap.** Overgeneralizes beyond one confounded campaign.
   - **(E)** **Trap: too strong.** No purchasing data were collected.

**Check:** Hold exposure constant: the observed large gap disappears in the small matched subset.
::::
:::

:::problem[Question III.17]
In a regional tennis league, every player who wins at least four qualifying events and submits an eligibility form may enter the year-end championship. Dana won five qualifying events and submitted the form before the deadline. The league secretary concludes that Dana may enter. Whether Dana will win any championship matches is irrelevant to that eligibility conclusion; the rule specifies only what must be satisfied to enter.

Which one of the following arguments uses reasoning most similar to that used by the secretary?

- **(A)** If a cyclist registers, the cyclist may race; Theo may race, so Theo registered.
- **(B)** Any vendor that passes inspection and pays the booth fee may sell at the fair; Kiran did both, so Kiran may sell at the fair.
- **(C)** Only users with verified accounts can comment; Jo has a verified account, so Jo must have commented.
- **(D)** All marathon finishers trained regularly; Lila trained regularly, so she finished a marathon.
- **(E)** Some qualified referees attend games; Mara is qualified, so Mara attends games.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Dana is eligible to enter the championship.
2. **Support.** Winning four or more AND submitting form is sufficient for eligibility; Dana satisfies both.
3. **Prephrase.** Match modus ponens with two jointly required antecedents, not a converse or an action-versus-permission switch.
4. **Why (B) is right.** Inspection AND fee → may sell; both true for Kiran, so permission follows.
5. **Why the others fail.**
   - **(A)** **Trap: reversal.** Reverses sufficient-condition direction.
   - **(C)** **Trap: reversal.** Necessary eligibility is mistaken for actual behavior.
   - **(D)** **Trap: reversal.** Invalid converse: training may not be sufficient.
   - **(E)** **Trap: wrong logical form.** Existential fact does not give Mara’s attendance.

**Check:** (P ∧ Q) → R; P; Q; hence R.
::::
:::

:::problem[Question III.18]
A college placed battery-recycling bins outside dormitories and counted three times as many batteries collected on campus the following semester. Administrators claim that the bins caused students to recycle substantially more batteries overall rather than throw them in household trash. Previously, students could place batteries in a municipal drop-off station just beyond campus. No counts were collected at that municipal station after the new dormitory bins were installed, and students were not surveyed about whether they had changed their disposal habits.

Which one of the following, if true, most seriously weakens the administrators’ claim?

- **(A)** The increase in batteries collected on campus closely matched a decline in batteries deposited at the nearby municipal station.
- **(B)** Some students keep used batteries in drawers for months.
- **(C)** The college has more dormitory residents than several nearby colleges.
- **(D)** The new dormitory bins are more visible to students than the municipal collection station.
- **(E)** A portion of the collected batteries came from faculty offices.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Students recycled more overall due to the new dorm bins.
2. **Support.** Collection at one campus location increased, but other collection sites were not counted.
3. **Prephrase.** Test diversion from another recycling channel instead of newly recycled batteries.
4. **Why (A) is right.** An equal drop at the municipal site implies relocation of recycling, not a net increase.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** Possible delay does not quantify the overall recycling change.
   - **(C)** **Trap: unsupported leap.** Cross-campus comparisons do not resolve the before-and-after claim.
   - **(D)** **Trap: half-right / insufficient.** Greater visibility can explain why campus collections rose, but not whether total recycling rose rather than merely shifted sites.
   - **(E)** **Trap: wrong attribution.** Could affect attribution to students but does not as directly explain the entire increase as displaced municipal returns.

**Check:** Total recycling = campus collections + municipal collections + others; one component can rise while total stays flat.
::::
:::

:::problem[Question III.19]
A book reviewer claims that a novelist's recent work should not be dismissed as merely nostalgic. The reviewer concedes that the novel repeatedly depicts a vanished kind of neighborhood market, and some critics regard that focus as evidence of nostalgia. Yet the novel’s central conflict concerns present-day workers deciding which traditions to abandon, not characters longing to restore the past. The reviewer concludes that the old marketplaces function primarily as a device for exposing contemporary choices rather than as a plea to return to an earlier era.

The statement that the novel repeatedly depicts vanished neighborhood markets serves primarily to...

- **(A)** acknowledge a fact that might initially support a competing interpretation, before the reviewer explains why that interpretation is incomplete.
- **(B)** state the reviewer’s final interpretation of the novel.
- **(C)** offer an example of the workers’ actual present-day decisions.
- **(D)** provide decisive evidence that the novel advocates restoration of the past.
- **(E)** establish that the novel is historically inaccurate.

::::solution[Solution]
**Answer:** (A)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The novel uses old markets to illuminate present choices, not simply to indulge nostalgia.
2. **Support.** The critic admits a nostalgic-looking detail, then shows that narrative function differs from superficial subject matter.
3. **Prephrase.** The asked-for sentence is a concession to opposing evidence.
4. **Why (A) is right.** The reviewer acknowledges the observation critics use but denies their inference about the novel’s central purpose.
5. **Why the others fail.**
   - **(B)** **Trap: unsupported leap.** The final view concerns contemporary choices, not merely the presence of old markets.
   - **(C)** **Trap: unsupported leap.** The markets are a setting and symbol, not the workers’ choices.
   - **(D)** **Trap: unsupported leap.** The reviewer explicitly resists that interpretation.
   - **(E)** **Trap: unsupported leap.** No factual accuracy claim about markets is made.

**Check:** Remove the concession and the reviewer’s thesis remains, but the rebuttal loses its acknowledged opposing evidence.
::::
:::

:::problem[Question III.20]
A toy company recalls two product lines because the same detachable part may pose a choking hazard. Customers who bought the inexpensive model are offered immediate free replacement parts; customers who bought the premium model must pay a shipping charge for the identical replacement part. The company argues that premium customers are usually wealthier. A consumer ombudsperson objects that, where a defect and its remedy are identical, the company’s duty to correct its own safety error should not depend on what it guesses about buyers' income.

Which one of the following principles most strongly supports the ombudsperson’s objection?

- **(A)** Only customers who can prove low income should receive safety remedies.
- **(B)** No manufacturer should sell products containing detachable components.
- **(C)** Companies should always charge exactly the same initial price for every product.
- **(D)** Premium products must carry longer warranties than budget products.
- **(E)** When a manufacturer remedies the same defect it introduced into two products, customers should not face different charges for the identical correction merely because of assumptions about their wealth.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Charge no special premium-buyer shipping fee for the identical safety correction.
2. **Support.** Same manufacturer-caused defect and remedy; income guesses do not alter the duty.
3. **Prephrase.** Look for equal defect-remedy treatment, not identical product prices.
4. **Why (E) is right.** The principle prohibits assigning unequal correction costs solely on assumed affluence.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Contradicts the obligation to remedy a common defect.
   - **(B)** **Trap: unsupported leap.** Overbroad: the objection concerns a specific hazardous defect.
   - **(C)** **Trap: too strong.** The dispute concerns recall remedies, not original prices.
   - **(D)** **Trap: unsupported leap.** Warranty duration is a separate issue and would endorse differing terms.

**Check:** Same defect + identical correction + wealth-based differential → prohibited under the principle.
::::
:::

:::problem[Question III.21]
An educational technology vendor says its self-paced programming course is more effective than the instructor-led course it replaced because a higher percentage of students who finished the self-paced course passed the final assessment. The old course included every student enrolled at the start of term in its reported pass rate, including those who stopped participating. The vendor's new statistic excludes students who quit before the assessment, even though the new format had a higher dropout rate. The vendor insists that the figures are comparable because both represent a percentage of students.

The argument is most vulnerable to criticism on the grounds that it...

- **(A)** concludes from lower test scores that the new course is ineffective.
- **(B)** mistakes a necessary condition for completion as sufficient for enrollment.
- **(C)** assumes that the new and old final assessments tested equally difficult material.
- **(D)** compares pass rates calculated using different populations while ignoring students who dropped out of the new course.
- **(E)** assumes that passing an assessment has no relationship to course effectiveness.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The new course is more effective than its predecessor.
2. **Support.** The percentage bases differ; the new format discards noncompleters despite a higher dropout rate.
3. **Prephrase.** Identify denominator or selection mismatch.
4. **Why (D) is right.** Comparing completers’ success with all starters’ success can create an apparent improvement without a true increase.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** The vendor claims effectiveness from higher scores, not ineffectiveness from lower scores.
   - **(B)** **Trap: unsupported leap.** No conditional-logic inference appears.
   - **(C)** **Trap: half-right / insufficient.** The comparative difficulty is not supplied, but the explicit defect is that one denominator excludes dropouts while the other includes them.
   - **(E)** **Trap: unsupported leap.** It uses assessment success as evidence; the trouble is denominators.

**Check:** Use the same starting cohort denominator for both pass rates to make them comparable.
::::
:::

:::problem[Question III.22]
A seed cooperative plans to print a “drought resilient” label on a new variety. In experimental plots, the variety produced more grain under limited irrigation than an older variety did. The plots were protected from common local insects with an intensive pesticide regimen, whereas farmers who will buy the seed generally cannot use that regimen. The cooperative argues that the measured water-stress advantage will translate into greater harvests for ordinary farmers under dry conditions, despite the difference in insect pressure.

Which one of the following is an assumption on which the cooperative’s argument depends?

- **(A)** The new variety resists every insect found in the region.
- **(B)** The older variety is never grown with pesticides.
- **(C)** Insect pressure in ordinary fields will not eliminate every harvest advantage the new variety showed under limited irrigation.
- **(D)** All farmers use exactly the same irrigation schedule.
- **(E)** The new variety yields more than every variety under ideal watering.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The new seed’s trial advantage will benefit ordinary dry-field harvests.
2. **Support.** Protection from insects in the trial may conceal losses under normal insect pressure.
3. **Prephrase.** The pesticide-to-farm difference must not wipe out the entire projected benefit.
4. **Why (C) is right.** If insect pressure removes every yield advantage, trial results cannot support the claimed real-field advantage.
5. **Why the others fail.**
   - **(A)** **Trap: too strong.** An extreme condition unnecessary for a net yield advantage.
   - **(B)** **Trap: too strong.** Outside the needed transfer from test conditions to farms.
   - **(D)** **Trap: too strong.** Uniform practice is not required for comparative drought performance.
   - **(E)** **Trap: too strong.** The claim is restricted to dry conditions and comparison with an older variety.

**Check:** Negate: ordinary insects erase all superiority; the farm-transfer conclusion fails.
::::
:::

:::problem[Question III.23]
A municipality simplified its application form for home-insulation rebates. As expected, the average amount of staff time required to review each fully completed application declined. Unexpectedly, the average calendar time between submission and decision increased, even though the office hired an additional reviewer. Applicants reported that the online application was easier, and far more people submitted forms than in the previous year. The office measures review time only after a case reaches a staff member, but it measures decision time from the instant of submission.

Which one of the following, if true, most helps resolve the apparent discrepancy?

- **(A)** The easier form increased incoming applications by much more than the added reviewer and faster processing could handle, causing a growing queue.
- **(B)** The simplified application required fewer supporting documents to be uploaded.
- **(C)** Fewer applicants asked to correct errors after a decision.
- **(D)** The rebate amount was unchanged throughout the period.
- **(E)** Reviewers became more accurate at checking insulation receipts.

::::solution[Solution]
**Answer:** (A)

**Type:** Paradox / resolve (Chapter 13)

1. **Conclusion.** Explain decreased work per case but increased elapsed waiting.
2. **Support.** Arrivals rose sharply while time spent on each reviewed application fell.
3. **Prephrase.** Look for queue growth when demand outstrips capacity.
4. **Why (A) is right.** Even efficient processing can yield longer waits if incoming workload increases faster than throughput.
5. **Why the others fail.**
   - **(B)** **Trap: half-right / insufficient.** Easier submission may attract applicants, but without the capacity-overload mechanism this does not itself establish longer queues.
   - **(C)** **Trap: unsupported leap.** This occurs after the measured decision time and cannot explain its rise.
   - **(D)** **Trap: unsupported leap.** Payment size does not explain the time discrepancy.
   - **(E)** **Trap: unsupported leap.** Accuracy alone does not explain longer elapsed processing time.

**Check:** Decision time = queue wait + review; queue wait increased more than review time fell.
::::
:::

:::problem[Question III.24]
A consumer columnist observes that all stores that received the association's “transparent pricing” award display final prices including taxes. One electronics store displays tax-inclusive prices, so the columnist concludes that it must have received the award. The columnist has not checked whether the store applied for evaluation and knows that many unawarded stores voluntarily publish tax-inclusive prices. Nonetheless, the columnist treats the common feature of award winners as sufficient proof of an award.

Which one of the following arguments exhibits the same error in reasoning?

- **(A)** If a parcel bears the express label, it is tracked; this parcel is not tracked, so it has no express label.
- **(B)** Only employees may enter the server room; Lee is not an employee, so Lee may not enter.
- **(C)** Some elected officers speak two languages; Pat is elected, so Pat speaks two languages.
- **(D)** Every certified organic farm records its harvest inputs; a farm records its inputs, so it must be certified organic.
- **(E)** All qualifying cars passed inspection; this car qualifies, so it passed inspection.

::::solution[Solution]
**Answer:** (D)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The electronics store won an award.
2. **Support.** Award → tax-inclusive; tax-inclusive → award is the unsupported converse.
3. **Prephrase.** Choose affirming the consequent with a universally stated condition.
4. **Why (D) is right.** Certified → records inputs; records inputs → certified repeats the very same reversal.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** This correctly uses the contrapositive, rather than affirming the consequent.
   - **(B)** **Trap: half-right / insufficient.** Valid necessary-condition denial.
   - **(C)** **Trap: reversal.** Invalid existential generalization rather than the universal converse.
   - **(E)** **Trap: wrong logical form.** This applies the original sufficient condition in its valid forward direction.

**Check:** Both take A → F and F as sufficient to conclude A.
::::
:::

:::problem[Question III.25]
A technology firm says a newly released language model is more reliable for customer support because its average accuracy on a benchmark is higher than the prior model's. The benchmark contains many easy classification tasks but relatively few questions requiring a correct refusal when a customer asks for an unauthorized account change. The firm’s support contracts impose large penalties for unauthorized changes, while ordinary classification errors cost little. The manager argues that the higher average score necessarily makes the new model the better operational choice.

Which one of the following questions would be most useful to answer in evaluating the manager’s argument?

- **(A)** Does the newer model have more parameters than the older model?
- **(B)** Which model correctly classifies a larger share of routine low-risk customer inquiries?
- **(C)** Does the newer model outperform the older model on a second benchmark with a similarly large proportion of easy classification tasks?
- **(D)** Can every benchmark problem be answered without outside knowledge?
- **(E)** How do the two models compare on the costly unauthorized-change cases, and how are those errors weighted in actual operations?

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate the argument (Chapter 8)

1. **Conclusion.** The higher overall benchmark average guarantees superior operational reliability.
2. **Support.** The benchmark heavily weights low-cost tasks, while real operations punish rare unauthorized changes severely.
3. **Prephrase.** Evaluate performance on the high-stakes subgroup and its operational weighting.
4. **Why (E) is right.** If the new model is worse on critical cases, the mean may conceal greater real-world losses; if better, confidence increases.
5. **Why the others fail.**
   - **(A)** **Trap: unsupported leap.** Size cannot settle reliability under contract-specific error costs.
   - **(B)** **Trap: unsupported leap.** This emphasizes the plentiful, low-cost classification tasks and can miss costly unauthorized-action failures.
   - **(C)** **Trap: unsupported leap.** Replication on another similarly weighted benchmark still does not determine performance on the expensive authorization errors.
   - **(D)** **Trap: too strong.** Benchmark composition matters, but this does not directly assess relative costly failure.

**Check:** Compare risk-weighted error costs, not unweighted average accuracy.
::::
:::


## 29.4 Scoring and review

Count **one point per correct answer**, with **no penalty for an incorrect answer**. Section I contributes 25 points, Section II contributes 27, and Section III contributes 25, for **77 total**. Because this original exam has not been equated by LSAC, **do not translate its raw score into a purported official 120–180 score**. Compare your raw totals and missed question types with your own earlier practice; use official LawHub tests for calibrated benchmarks.

**Answer key**

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| I.1 | E | Main conclusion | 11 |
| I.2 | C | Weaken | 8 |
| I.3 | C | Flaw | 9 |
| I.4 | A | Must be true / inference | 10 |
| I.5 | D | Strengthen | 8 |
| I.6 | A | Necessary assumption | 7 |
| I.7 | B | Principle | 13 |
| I.8 | B | Flaw | 9 |
| I.9 | E | Paradox / resolve | 13 |
| I.10 | B | Role of a statement | 11 |
| I.11 | E | Sufficient assumption | 7 |
| I.12 | D | Strengthen | 8 |
| I.13 | A | Flaw | 9 |
| I.14 | A | Most strongly supported | 10 |
| I.15 | B | Point at issue | 11 |
| I.16 | E | Weaken | 8 |
| I.17 | B | Necessary assumption | 7 |
| I.18 | D | Parallel reasoning | 12 |
| I.19 | D | Flaw | 9 |
| I.20 | E | Method of reasoning | 11 |
| I.21 | C | Principle | 13 |
| I.22 | A | Necessary assumption | 7 |
| I.23 | C | Paradox / resolve | 13 |
| I.24 | C | Parallel flaw | 12 |
| I.25 | D | Evaluate the argument | 8 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| II.1 | D | Main point / primary purpose (RC) | 18 |
| II.2 | B | Detail / recognition (RC) | 18 |
| II.3 | E | Function / purpose (RC) | 18 |
| II.4 | E | Inference (RC) | 18 |
| II.5 | B | Author attitude / tone (RC) | 18 |
| II.6 | C | Application / analogy (RC) | 18 |
| II.7 | D | Structure / organization (RC) | 18 |
| II.8 | D | Main point / primary purpose (RC) | 18 |
| II.9 | A | Inference (RC) | 18 |
| II.10 | A | Function / purpose (RC) | 18 |
| II.11 | E | Detail / recognition (RC) | 18 |
| II.12 | C | Author attitude / tone (RC) | 18 |
| II.13 | A | Application / analogy (RC) | 18 |
| II.14 | D | Structure / organization (RC) | 18 |
| II.15 | B | Agreement (comparative RC) | 17 |
| II.16 | E | Different approach (comparative RC) | 17 |
| II.17 | A | Author reaction (comparative RC) | 17 |
| II.18 | E | Author reaction (comparative RC) | 17 |
| II.19 | D | Application (comparative RC) | 17 |
| II.20 | B | Detail / attribution (comparative RC) | 17 |
| II.21 | C | Main point / primary purpose (RC) | 18 |
| II.22 | C | Function / purpose (RC) | 18 |
| II.23 | A | Inference (RC) | 18 |
| II.24 | A | Application / analogy (RC) | 18 |
| II.25 | C | Author attitude / tone (RC) | 18 |
| II.26 | C | Detail / recognition (RC) | 18 |
| II.27 | B | Structure / organization (RC) | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| III.1 | C | Strengthen | 8 |
| III.2 | E | Necessary assumption | 7 |
| III.3 | C | Flaw | 9 |
| III.4 | A | Main conclusion | 11 |
| III.5 | E | Paradox / resolve | 13 |
| III.6 | D | Weaken | 8 |
| III.7 | D | Must be true / inference | 10 |
| III.8 | C | Principle | 13 |
| III.9 | C | Flaw | 9 |
| III.10 | A | Sufficient assumption | 7 |
| III.11 | B | Strengthen | 8 |
| III.12 | D | Method of reasoning | 11 |
| III.13 | B | Necessary assumption | 7 |
| III.14 | E | Point at issue | 11 |
| III.15 | B | Flaw | 9 |
| III.16 | B | Most strongly supported | 10 |
| III.17 | B | Parallel reasoning | 12 |
| III.18 | A | Weaken | 8 |
| III.19 | A | Role of a statement | 11 |
| III.20 | E | Principle | 13 |
| III.21 | D | Flaw | 9 |
| III.22 | C | Necessary assumption | 7 |
| III.23 | A | Paradox / resolve | 13 |
| III.24 | D | Parallel flaw | 12 |
| III.25 | E | Evaluate the argument | 8 |

:::

**Review routes**

| Missed skill | Return to |
| --- | --- |
| Argument structure, conclusions, flaw vocabulary | Chapters 4, 6, 9 |
| Necessary and sufficient assumptions | Chapters 5, 7 |
| Strengthen, weaken, evaluation of evidence | Chapter 8 |
| Must be true, most strongly supported | Chapter 10 |
| Method, statement role, point at issue | Chapter 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Paradox, resolve, and principles | Chapter 13 |
| RC main point, structure, detail, inference, attitude, application | Chapters 15, 18 |
| RC subject-specific strategy and comparative reading | Chapters 16, 17 |
| Time allocation and blind review | Chapters 14, 19, 22, 23 |

Your most useful follow-up is not merely the raw total. Record every flagged question you got right by luck, separate timed misses from blind-review misses, and revisit each chapter associated with a repeatable error.
