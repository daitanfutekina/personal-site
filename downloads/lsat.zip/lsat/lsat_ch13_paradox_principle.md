---
title: "Paradox & Principle"
source: "lsat_ch13_paradox_principle.html"
---

Part II · Chapter 13

# Paradox & Principle

Two final Logical Reasoning types. Paradox asks you to make two conflicting facts coexist; Principle asks you to move between a general rule and a specific case. Both are highly learnable once you know the exact task.

**Est. study time:** 55–70 min — **Sections:** 3 — **Practice:** 20+ items

## Overview

This chapter finishes the Logical Reasoning question types with two more. **Paradox** (also called Resolve/Explain) questions present two facts that seem to conflict and ask for the answer that makes both true at once — you're not judging an argument, you're reconciling a puzzle. **Principle** questions ask you to bridge between a general rule and a specific situation, in either direction: apply a rule to a case, or find the rule a case illustrates. Both are approachable with a precise sense of the task, and Principle in particular blends skills from Strengthen (Chapter 8) and Inference (Chapter 10).

:::callout-tip
Prerequisites

Chapter 4 (reading precisely), Chapter 8 (Strengthen — principle-strengthen questions borrow its logic), and Chapter 10 (Inference — principle-application resembles a must-be-true). The paradox section stands mostly on its own.
:::

## 13.1 · Paradox / resolve–explain

:::callout-intuition
Intuition first

A paradox question hands you two facts that seem to *fight* each other: "Sales of the product doubled, yet the company's revenue from it fell." Your instinct is "that can't both be true!" — but they are, and the right answer is the missing piece of information that makes the tension dissolve, so both facts sit comfortably side by side. You're not attacking either fact or picking a winner; you're finding the third fact that lets both stand.
:::

:::definition
**Definition 13.1 — Paradox (resolve/explain).** A question presenting two statements that appear to conflict, asking which answer best *reconciles* them — makes both true simultaneously — or *explains* the surprising situation. Stems: "most helps to resolve the apparent discrepancy," "most helps to explain," "if true, would most help to reconcile." The correct answer leaves *both* facts intact and shows how they fit together.
:::

### The method: state the tension, then bridge it

1. **Pin the two conflicting facts** precisely. What exactly seems to clash?
2. **Pre-phrase a bridge:** what could be true that would let both hold at once?
3. **Pick the answer that keeps both facts true.** Reject any answer that denies one of the facts, deepens the mystery, or is irrelevant.

:::example
Worked Example 13.1 — reconcile the facts

standard

"After the store doubled the number of checkout lanes, customers reported spending *more* time waiting in line, not less."

**Stem.** Which one, if true, most helps to resolve the apparent discrepancy?

- **(A)** The new checkout lanes were more expensive to install than expected.
- **(B)** The added lanes attracted so many new customers that total store traffic more than tripled.
- **(C)** Some customers prefer self-checkout lanes.
- **(D)** The store's employees liked having more lanes.
- **(E)** The old checkout lanes were rarely used at night.

Answer: (B).

**How we get there.** The tension: *more lanes* (should mean shorter waits) but *longer waits*. Pre-phrase a bridge: something that increased demand for the lanes even more than the supply of lanes grew. (B) delivers exactly that — doubling lanes but *tripling* customers means each lane serves even more people than before, so waits get longer. Both facts now hold: lanes doubled *and* waits grew, reconciled by a bigger surge in traffic. Traps: (A), (D) are irrelevant to wait times; (C), (E) don't explain why *more* lanes produced *longer* waits. **Teaching point:** the answer added a fact (a traffic surge) that dissolves the conflict without denying either original fact.
:::

:::callout-pitfall
Watch out for these mistakes

- **Picking an answer that denies one fact.** The correct answer keeps *both* facts true. If a choice implies one of them is false, it's wrong.
- **Choosing something that deepens the mystery.** A relevant-sounding fact that makes the conflict *worse* is a trap; you want reconciliation.
- **Grabbing an irrelevant true statement.** Cost, preferences, and side details often don't touch the specific tension. Bridge the exact clash.
- **Treating it like an argument.** There's no conclusion to strengthen or weaken; you're explaining a situation, not evaluating reasoning.
:::

### Practice — 13.1

:::problem[Q1]{difficulty="easy"}
What must a correct paradox answer do with the two conflicting facts?

::::solution[Solution]
**Keep both true** and show how they fit together. It reconciles/explains the tension without denying either fact.
::::
:::

:::problem[Q2]{difficulty="standard"}
"A company cut its advertising budget in half, yet its sales rose that year." Pre-phrase a resolving fact.

::::solution[Solution]
Some fact that boosted sales independent of (or via) the cut — e.g., "a competitor went out of business, sending its customers to the company," or "the company shifted from expensive ads to a far more effective low-cost campaign." Either keeps both facts true (budget halved *and* sales rose).
::::
:::

:::problem[Q3]{difficulty="standard"}
Why is an answer that makes the discrepancy *more* puzzling a trap?

::::solution[Solution]
Because the task is to **resolve** the tension, not intensify it. An answer that widens the gap between the two facts moves in the wrong direction, however on-topic it sounds.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"A new drug reduced the death rate from the disease, yet the total number of deaths from the disease rose after the drug was introduced." Give a resolving fact.

::::solution[Solution]
Something that increased the number of people *with* the disease enough to raise total deaths despite a lower per-person death *rate* — e.g., "the disease became far more widespread after the drug's release (an epidemic), greatly increasing the number of cases." A lower rate applied to a much larger population can yield more total deaths. Both facts hold (rate down, total up), reconciled by a surge in cases. (Note the percentage-vs-number distinction from Ch 6.)
::::
:::

## 13.2 · Principle questions

:::callout-intuition
Intuition first

A **principle** is a general rule — "people should be held responsible only for outcomes they could foresee." Principle questions ask you to move between such a rule and a specific case, in one of two directions. *Apply*: given a rule (or a case), find the specific case (or rule) that fits it. Because a principle is essentially a broad conditional, these questions are really Strengthen or Inference questions wearing a "principle" label — and you can use those chapters' tools directly.
:::

:::definition
**Definition 13.2 — Principle questions, two directions.** **(a) Principle → case (apply/conform):** given a general rule, find the specific situation that conforms to it (or the judgment the rule yields). Stems: "which judgment conforms to the principle," "the principle, if valid, most supports which action?" **(b) Case → principle (identify/justify):** given a specific judgment or argument, find the general rule that *justifies* or underlies it. Stems: "which principle most helps to justify the reasoning," "the argument's reasoning conforms to which principle?"
:::

### Technique: treat the principle as a conditional

Most principles translate into "If [conditions], then [judgment]." Then:

- **Applying a rule to a case** is *modus ponens* (Chapter 5): check the case meets the conditions, then the judgment follows — like a must-be-true (Chapter 10).
- **Finding the rule that justifies a case** is like *Sufficient Assumption* (Chapter 7): pick the general rule broad enough to *guarantee* the specific judgment, without being so broad it's clearly false or so narrow it misses.

:::example
Worked Example 13.2 — apply the principle

standard

"Principle: A business should issue a refund whenever a product fails within its warranty period, unless the failure was caused by customer misuse."

**Stem.** Which judgment conforms to the principle?

- **(A)** A blender failed two days after its warranty expired due to a manufacturing defect; the store refused a refund.
- **(B)** A phone stopped working within its warranty period because the owner dropped it in water; the store issued a refund.
- **(C)** A toaster failed within its warranty period from an internal short circuit, with no misuse; the store issued a refund.
- **(D)** A laptop failed within warranty due to a factory defect; the store refused a refund.
- **(E)** A watch failed after warranty due to misuse; the store issued a refund.

Answer: (C).

**How we get there.** Translate the principle: `(fails within warranty) AND (not misuse) → should refund`. Now test each case against it. (C): fails within warranty, no misuse → the rule says refund, and the store refunded. Conforms. Check others: (A) failure was *after* warranty, so the rule doesn't require a refund — but the refusal doesn't violate it either; still, (C) is a cleaner positive conformance and (A)'s "two days after" plus defect is outside the rule's trigger. (B) misuse (dropped in water) → rule does *not* require a refund, yet the store gave one — not required by the principle, arguably contrary to it. (D) within warranty, factory defect (no misuse) → rule says refund, but the store *refused* — violates the principle. (E) after warranty + misuse → rule doesn't require a refund; refunding contradicts its spirit. Only (C) is a case the principle's conditions are met *and* the action matches. **Teaching point:** conforming = the case meets the rule's conditions *and* the outcome matches what the rule prescribes.
:::

:::example
Worked Example 13.3 — find the justifying principle

challenge

"The city fined the factory for pollution even though the factory broke no existing law, because the pollution caused serious, foreseeable harm to residents."

**Stem.** Which principle most helps to justify the city's action?

- **(A)** Factories are responsible only for harms they intend to cause.
- **(B)** Penalties should be proportional to a company's revenue.
- **(C)** Businesses should never be penalized unless they violate a specific written law.
- **(D)** An entity may be penalized for conduct that causes serious, foreseeable harm, even if no specific law prohibits it.
- **(E)** Cities should prioritize economic growth over environmental concerns.

Answer: (D).

**How we get there.** The city's specific judgment: penalize despite no law broken, *because* of serious foreseeable harm. Find the general rule that would *justify* (guarantee) that judgment. (D) is exactly that rule — "may be penalized for serious, foreseeable harm even absent a specific law" — broad enough to license the fine, matched to the case's stated reason. This is the Sufficient-Assumption move (Chapter 7): the rule bridges the case's facts to its conclusion. Traps: (C) and (A) would *forbid* the fine (opposite); (E), (B) are off-topic. **Teaching point:** the justifying principle must be general enough to cover the case and must actually yield the case's judgment — not contradict it.
:::

:::callout-pitfall
Watch out for these mistakes

- **Ignoring the "unless"/exception clause.** Many principles have conditions and exceptions (like "unless misuse"). A case that triggers the exception is treated differently — read the whole rule.
- **Picking a principle that's too narrow or too broad.** For justify questions, the rule must exactly cover the case's reasoning — not a fragment of it, and not so sweeping it endorses obviously wrong things.
- **Choosing the opposite-direction principle.** A rule that would *forbid* the action can't justify it. Check that the principle yields the case's actual judgment.
- **Forgetting these are conditionals.** Translating "should… whenever… unless…" into an if-then makes application mechanical.
:::

### Practice — 13.2

:::problem[Q1]{difficulty="standard"}
Translate to a conditional: "A student should receive extra time on an exam only if they have a documented need."

::::solution[Solution]
`receives extra time → has documented need` ("only if" marks the necessary condition, Ch 5). So documentation is required for extra time; a student without documentation should not receive it.
::::
:::

:::problem[Q2]{difficulty="standard"}
A "justify the reasoning" principle question is most like which earlier question type, and why?

::::solution[Solution]
**Sufficient Assumption** (Ch 7). You supply a general rule broad enough to **guarantee** the case's judgment — bridging its facts to its conclusion, just as a sufficient assumption completes an argument.
::::
:::

:::problem[Q3]{difficulty="standard"}
Principle: "One should keep a promise unless doing so would cause serious harm." A person breaks a promise to avoid serious harm. Conform or violate?

::::solution[Solution]
**Conforms.** The exception ("unless… serious harm") applies, so breaking the promise to avoid serious harm is exactly what the principle permits. Reading the exception clause is essential.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is a principle that would *forbid* the action a wrong answer on a "justify the action" question, even if it's on the same topic?

::::solution[Solution]
Because to **justify** an action, the principle must *yield* or permit it. A rule that forbids the action produces the opposite judgment, so it can't justify what was done — topic overlap is irrelevant; the rule has to actually license the case's conclusion.
::::
:::

## 13.3 · Drill set

Ten questions, mixed between Paradox and Principle. Identify the task from the stem, then apply the right method. Difficulty rises.

:::problem[1]{difficulty="easy"}
"The bakery raised its prices, yet it sold more loaves than ever." *Most helps to resolve?*

- **(A)** The bakery uses organic flour.
- **(B)** Bread is a popular food.
- **(C)** The bakery's rent also increased.
- **(D)** The bakery has been in business for forty years.
- **(E)** A nearby competing bakery closed, sending its customers to this one.

::::solution[Solution]
**(E).** A surge of new customers (from the closed competitor) explains more sales despite higher prices — both facts stay true. Others are irrelevant.
::::
:::

:::problem[2]{difficulty="standard"}
"Principle: A review should be published only if it is based on firsthand experience of the product." *Which conforms?*

- **(A)** An editor rejected a review because its author had only read about the product, not used it.
- **(B)** An editor published a negative review to boost controversy.
- **(C)** An editor rejected a firsthand review because it was negative.
- **(D)** An editor published a review after its author admitted relying on a friend's account of the product rather than using it.
- **(E)** An editor published a review written by someone who never used the product.

::::solution[Solution]
**(A).** `publish → firsthand`; no firsthand experience → shouldn't publish, and the editor rejected it. Conforms. (E) violates; (C) rejects a firsthand review, which the principle permits publishing (not required, but rejecting for being negative isn't grounded in the rule); (B) off-principle.
::::
:::

:::problem[3]{difficulty="standard"}
"Despite installing energy-efficient lighting throughout the building, the company's electricity bill went up." *Most helps to explain?*

- **(A)** Employees liked the brighter light.
- **(B)** The company expanded into two additional floors and added many new employees and devices.
- **(C)** Energy-efficient bulbs last longer.
- **(D)** The new bulbs cost more to purchase than the ones they replaced.
- **(E)** The lighting was installed by contractors.

::::solution[Solution]
**(B).** A big expansion (more floors, people, devices) raised total consumption more than efficient lighting saved — both facts hold. Others don't touch the bill.
::::
:::

:::problem[4]{difficulty="standard"}
"The professor gave the student a failing grade for the plagiarized essay even though the student didn't know the rules, because ignorance of the rules does not excuse academic dishonesty." *Which principle justifies this?*

- **(A)** Professors should grade leniently.
- **(B)** Plagiarism is common in universities.
- **(C)** Students should be penalized for rule violations regardless of whether they knew the rule.
- **(D)** Penalties should be proportional to the harm a violation causes.
- **(E)** Students should only be penalized for intentional wrongdoing.

::::solution[Solution]
**(C).** The general rule that penalties apply regardless of knowledge of the rule justifies failing the unaware plagiarist. (E) would forbid it (opposite); (A),(B) off-topic.
::::
:::

:::problem[5]{difficulty="standard"}
"A city added a new subway line, but average commute times across the city did not improve." *Most helps to resolve?*

- **(A)** Subways are common in large cities.
- **(B)** Some residents enjoy taking the subway.
- **(C)** The subway line opened three months behind schedule.
- **(D)** The subway line served only a small area, while most residents commute elsewhere by congested roads.
- **(E)** The subway was expensive to build.

::::solution[Solution]
**(D).** If the line helped only a small area while most commute by unchanged congested roads, citywide averages could stay flat despite the improvement for a few — both facts hold.
::::
:::

:::problem[6]{difficulty="challenge"}
"Principle: One may break a rule if and only if following it would cause greater harm than breaking it." A driver crossed a double line (normally prohibited) to avoid hitting a child who ran into the road. *Does the action conform?*

- **(A)** No — the rule against crossing double lines is absolute.
- **(B)** No — the driver should have stopped instead.
- **(C)** Yes — any rule may be broken whenever a life is at stake.
- **(D)** Cannot be determined from the principle.
- **(E)** Yes — following the rule would have caused greater harm (hitting the child) than breaking it.

::::solution[Solution]
**(E).** The principle permits breaking a rule exactly when following it causes greater harm. Hitting a child is greater harm than crossing a line, so the action conforms. (Reading the "if and only if" condition is key.)
::::
:::

:::problem[7]{difficulty="challenge"}
"Sales of umbrellas at the shop fell sharply this spring, even though the region had far more rainy days than usual." *Most helps to explain?*

- **(A)** A large discount store opened nearby and sold umbrellas far more cheaply, capturing most umbrella buyers.
- **(B)** Umbrellas come in many colors.
- **(C)** The shop extended its opening hours during the spring.
- **(D)** The shop also sells raincoats.
- **(E)** Spring is generally a rainy season.

::::solution[Solution]
**(A).** Rain would raise umbrella demand overall, but a cheaper competitor capturing buyers explains why *this shop's* sales fell despite the rain — both facts hold. (D),(E),(B) don't reconcile the drop.
::::
:::

:::problem[8]{difficulty="challenge"}
"The board denied the manager a bonus despite the department hitting its targets, because he achieved them by methods that violated company ethics rules." *Which principle justifies the denial?*

- **(A)** Managers should always receive bonuses for hitting targets.
- **(B)** Rewards should be withheld when goals are met through unethical means, regardless of the results.
- **(C)** Employees should be judged by the results they achieve rather than by the methods they use.
- **(D)** Bonuses should be based solely on whether targets are met.
- **(E)** Ethics rules should be relaxed for high performers.

::::solution[Solution]
**(B).** The rule that unethical methods forfeit rewards regardless of results justifies denying the bonus. (D),(A) would *require* the bonus (opposite); (E) is off-point.
::::
:::

:::problem[9]{difficulty="challenge"}
"A study found that patients who received the experimental therapy reported feeling better, yet objective medical tests showed their condition had not improved." *Most helps to resolve?*

- **(A)** Doctors recommended the therapy.
- **(B)** The objective medical tests were performed by independent laboratories.
- **(C)** The therapy produced a strong placebo effect, improving patients' subjective sense of well-being without changing the underlying disease.
- **(D)** The therapy was expensive.
- **(E)** The study had many participants.

::::solution[Solution]
**(C).** A placebo effect improves subjective feeling while leaving objective measures unchanged — reconciling "felt better" with "no measured improvement." Both facts remain true.
::::
:::

:::problem[10]{difficulty="challenge"}
In one or two sentences, explain how a "justify the reasoning" principle question and a paradox question differ in what the correct answer *does*.

::::solution[Solution]
A **justify-principle** answer supplies a general rule that *guarantees* a specific judgment (bridging facts to a conclusion, like a sufficient assumption). A **paradox** answer supplies a new fact that *reconciles* two conflicting statements so both remain true (explaining a situation, not supporting a conclusion). One licenses a judgment; the other dissolves a tension.
::::
:::

## Chapter summary

:::summary
#### Paradox & Principle, distilled

- **Paradox:** pin the two conflicting facts, then find the answer that keeps *both* true. Reject anything that denies a fact, deepens the mystery, or is irrelevant.
- **Principle is a conditional.** Translate "should… whenever… unless…" into if-then, then apply it.
- **Apply (rule→case)** works like Inference/must-be-true: does the case meet the conditions and match the prescribed outcome?
- **Justify (case→rule)** works like Sufficient Assumption: pick the rule broad enough to guarantee the judgment, in the right direction.
- **Mind exceptions and direction:** "unless" clauses change the outcome, and a rule that forbids an action can't justify it.
:::

LSAT Mastery — Chapter 13. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
