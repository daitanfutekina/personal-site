---
title: "The Writing Task"
source: "lsat_ch20_writing.html"
---

Part IV · Chapter 20

# The Writing Task

LSAT Argumentative Writing: the one part where you actually write. It's unscored — but mandatory, and it quietly gates the release of your whole score. Here's how to do it competently, once, and move on.

**Est. study time:** 35–45 min — **Sections:** 4 — **Practice:** 12+ items

## Overview

LSAT Argumentative Writing is the only part of the exam where you produce writing rather than choose answers. It is currently **unscored** — it does not affect your 120–180 number — but it is **mandatory**, and here's the catch that trips people up every cycle: *your multiple-choice score is not released to schools until an approved writing sample is on file.* So while you shouldn't pour prep weeks into it, you must do it, and do it competently, or you'll block your own score at the finish line. This chapter shows you the format, gives you a reliable template, walks through an annotated sample, and flags the mistakes that cause problems.

:::callout-tip
Prerequisites

Chapter 2 (the writing task is taken separately, in a flexible window, and gates score release) and — usefully — your whole Logical Reasoning training: constructing and evaluating arguments (Part II) is exactly the skill this task rewards. You already know how to find gaps and weigh considerations; here you *build* an argument instead of critiquing one.
:::

:::callout-key
The right mindset

Treat this as a **competent, required formality** — not a masterpiece and not an afterthought. There's no "right" answer and no score, so don't agonize; but admissions officers *can* read it, and a coherent, well-organized essay reflects well while a sloppy or skipped one can hurt. Aim for clear, organized, and on-task. One or two timed practice runs before test day is plenty of preparation.
:::

## 20.1 · Format & the perspectives

:::callout-intuition
Intuition first

You're given a *debatable issue* — a decision or question with no obvious right answer — plus three or four short **perspectives** that each capture a different value or argument around it. Your job is to **take a position** and defend it in a short essay while **engaging** the competing perspectives. It's essentially a structured op-ed: pick a side, argue it, and show you can handle the other side.
:::

:::definition
**Definition 20.1 — The task & timing.** You get a debatable prompt and 3–4 brief perspectives representing competing considerations. Total time is about **50 minutes: ~15 minutes of prewriting analysis** (brainstorm/outline — you can't start the essay yet) and **~35 minutes to write** the argumentative essay. It's taken on your own computer in a flexible window around your test date, and is unscored but required for score release.
:::

Example prompt (illustrative):

A mid-sized city has funds to improve public transit and must choose between (a) building a new light-rail line connecting downtown to the suburbs, or (b) expanding and modernizing the existing bus network. Write an essay arguing for one option over the other.

Perspective 1:

Light rail is a long-term investment that shapes development and attracts riders who would never take a bus.

Perspective 2:

Buses are far cheaper and more flexible; the same money serves more neighborhoods sooner.

Perspective 3:

Whatever is built, the priority should be serving low-income residents who most depend on transit.

:::callout-tip
Use the 15 minutes of prewriting well

Don't waste the prewriting window. Use it to (1) **pick the side you can argue best** — not necessarily what you personally believe — (2) jot your two or three strongest reasons, and (3) decide which competing perspective you'll address and how you'll answer it. Walk into the writing phase with a skeleton, so the 35 minutes go to clean prose, not deciding what to say.
:::

### Practice — 20.1

:::problem[Q1]{difficulty="easy"}
What are you given in the writing task, and what's your job?

::::solution[Solution]
A **debatable issue** plus **3–4 short perspectives**. Your job: **take a position and defend it** in an argumentative essay while engaging the competing perspectives.
::::
:::

:::problem[Q2]{difficulty="easy"}
How is the ~50 minutes split?

::::solution[Solution]
About **15 minutes of prewriting analysis** (brainstorm/outline, can't start the essay yet) and **~35 minutes to write**.
::::
:::

:::problem[Q3]{difficulty="standard"}
Should you pick the side you personally believe or the side you can argue best?

::::solution[Solution]
The side you can **argue best**. There's no "correct" position and it's unscored — choose whichever gives you the strongest, best-supported essay, regardless of personal belief.
::::
:::

:::problem[Q4]{difficulty="standard"}
What three things should the 15-minute prewriting produce?

::::solution[Solution]
(1) your **chosen side**, (2) your **two–three strongest reasons**, and (3) a plan for **which opposing perspective you'll address and how**. A skeleton so the writing phase is just execution.
::::
:::

## 20.2 · A reliable template

:::callout-intuition
Intuition first

Under time pressure, a **predictable structure** frees your attention for content. You don't want to invent an essay shape on the fly; you want a template you can pour any prompt into. The one below works for essentially every Argumentative Writing prompt and signals exactly what graders/readers look for: a clear thesis, organized reasons, and genuine engagement with the other side.
:::

:::definition
**Definition 20.2 — The five-part template.**

1. **Intro (2–3 sentences):** state the issue and *declare your position* clearly. Don't bury it.
2. **Body 1 — your strongest reason:** make your best affirmative case, drawing on the relevant perspective(s).
3. **Body 2 — address the opposition:** acknowledge the strongest competing perspective, then explain why your position still holds (rebut it or show your considerations outweigh it). *This is the paragraph readers most want to see.*
4. **Body 3 (optional) — a second supporting reason** or a limited concession.
5. **Conclusion (1–2 sentences):** restate your position and core reason. No new arguments.
:::

:::callout-key
The paragraph that matters most

Body 2 — engaging the opposition — is the heart of a strong Argumentative Writing essay. It demonstrates the exact skill the task assesses: constructing a cogent argument that *addresses competing considerations* rather than ignoring them. A one-sided essay that never acknowledges the other perspectives reads as weaker, even if its own points are good. Concede what's true, then show why your side wins anyway.
:::

:::callout-tip
Mechanics that read well

Write in clear, complete sentences and organized paragraphs. Take a firm position (avoid wishy-washy "both sides have merit" conclusions). Reference the provided perspectives by their substance. Leave 2–3 minutes at the end to **proofread** for typos and clarity. Length: a focused five-paragraph essay is plenty — quality of reasoning beats word count.
:::

### Practice — 20.2

:::problem[Q1]{difficulty="easy"}
Where in the essay should your position appear?

::::solution[Solution]
In the **introduction** — declare it clearly and early. Don't bury or delay it; readers should know your side from the first few sentences.
::::
:::

:::problem[Q2]{difficulty="standard"}
Which body paragraph is most important, and why?

::::solution[Solution]
**Body 2 — addressing the opposition.** Engaging the strongest competing perspective (concede + rebut/outweigh) is the core skill the task assesses; ignoring the other side weakens the essay.
::::
:::

:::problem[Q3]{difficulty="standard"}
What should the conclusion do and avoid?

::::solution[Solution]
**Do:** restate your position and core reason. **Avoid:** introducing new arguments. Keep it to 1–2 sentences.
::::
:::

:::problem[Q4]{difficulty="standard"}
Why is a firm position better than "both sides have merit"?

::::solution[Solution]
Because the task asks you to **take a position and defend it**; a wishy-washy "both have merit" essay reads as evasive and fails the core requirement. You can *acknowledge* the other side (Body 2) but must ultimately **commit** to one.
::::
:::

## 20.3 · Annotated sample essay

Here is a full response to the transit prompt from 20.1, following the template. Annotations (gold) explain what each move accomplishes.

INTRO — states the issue and declares the position in the first sentences.

Faced with a choice between a new light-rail line and an expanded bus network, the city should **modernize and expand its existing buses**. While light rail has undeniable appeal, buses deliver more transit benefit to more residents, sooner, and better serve the people who depend on public transportation most.

BODY 1 — strongest affirmative reason, drawing on Perspectives 2 and 3.

The decisive advantage of buses is reach per dollar. As the second perspective notes, buses are far cheaper and more flexible than rail: the same budget can add routes, increase frequency, and modernize vehicles across many neighborhoods at once, rather than sinking most of the funds into a single fixed corridor. That breadth matters especially for the residents the third perspective highlights — lower-income riders who most depend on transit and who are spread throughout the city, not just along one downtown-to-suburb line. A denser, more frequent bus network reaches them where they actually live and work; a single rail line, however impressive, does not.

BODY 2 — the crucial paragraph: acknowledges the strongest opposing perspective (rail), then explains why buses still win.

Advocates of light rail, reflected in the first perspective, make a real point: rail is a long-term investment that can shape development and attract "choice" riders who would never board a bus. This is a genuine benefit, and I do not dismiss it. But it is a benefit weighted toward the future and toward wealthier, car-owning commuters, purchased at the cost of serving current, transit-dependent riders now. When a city must choose, meeting present, widespread need should outweigh a speculative, concentrated payoff. Moreover, a modernized bus fleet — with dedicated lanes and better shelters — can capture much of rail's appeal at a fraction of the cost, narrowing the very gap that rail advocates emphasize.

BODY 3 — a second supporting reason (flexibility/risk) with a limited concession.

Flexibility is a further advantage. Bus routes can be adjusted as neighborhoods change; a rail line, once laid, is fixed for decades, and if ridership projections prove optimistic, the city is left with an expensive, underused asset. Admittedly, buses lack rail's permanence and symbolic draw — but in a mid-sized city with uncertain growth, adaptability is worth more than permanence.

CONCLUSION — restates the position and core reason; no new arguments.

Because expanding the bus network serves more residents, prioritizes those who most need transit, and preserves flexibility, the city should invest in modern buses rather than a single light-rail line.

:::callout-tip
What makes this essay work

It **declares a position immediately**, **uses the provided perspectives by substance** (not just name), and — most importantly — **engages the strongest opposing view fairly** in Body 2 before explaining why its own side prevails. It concedes real points ("this is a genuine benefit," "Admittedly, buses lack rail's permanence") without wavering on its thesis. It's organized, firm, and finishes cleanly. Note it isn't eloquent or long — it's *clear and complete*, which is exactly the standard.
:::

### Practice — 20.3

:::problem[Q1]{difficulty="standard"}
In the sample, what does Body 2 do that a one-sided essay would omit?

::::solution[Solution]
It **acknowledges the strongest opposing perspective (light rail's long-term/development benefits) and then rebuts/outweighs it** — demonstrating the engagement-with-competing-views skill the task most rewards, which a one-sided essay skips.
::::
:::

:::problem[Q2]{difficulty="standard"}
How does the essay use the provided perspectives?

::::solution[Solution]
By **engaging their substance** — drawing on P2 (cost/flexibility) and P3 (serving the transit-dependent) for its case, and addressing P1 (rail's long-term appeal) as the opposing view. It integrates the perspectives' arguments rather than merely listing them.
::::
:::

:::problem[Q3]{difficulty="standard"}
The sample concedes "buses lack rail's permanence and symbolic draw." Why include a concession at all?

::::solution[Solution]
A concession shows **fair-mindedness and awareness of the tradeoffs**, strengthening credibility — then the essay immediately explains why the conceded point doesn't change the conclusion ("adaptability is worth more than permanence"). Conceding real points and outweighing them is more persuasive than pretending the other side has none.
::::
:::

:::problem[Q4]{difficulty="challenge"}
The essay isn't especially eloquent or long. Why is that acceptable — even ideal — for this task?

::::solution[Solution]
Because the task rewards **a clear thesis, organization, and genuine engagement with competing views — not eloquence or length**. It's unscored, and readers want coherence and reasoning, not literary flourish. A focused, well-structured five-paragraph essay that commits to a position and handles the opposition fully meets the standard; padding or purple prose adds nothing and risks errors under time pressure.
::::
:::

## 20.4 · The score gate & common mistakes

:::callout-intuition
Intuition first

The most damaging thing about the writing task has nothing to do with essay quality: **if you don't complete it, your entire multiple-choice score stays locked and never reaches schools.** People finish the hard part, feel done, and forget the writing — then wonder why their score isn't showing up. Understanding this gate, and a few content pitfalls, is what this section protects you from.
:::

:::callout-warning
The score-release gate

Your 120–180 score is **not released to law schools until you have a completed, approved LSAT Argumentative Writing sample on file.** The writing is unscored, but skipping it silently withholds your whole score. **Complete it as soon as you're eligible** (you can do it in the flexible window around your test date) so nothing delays your applications — especially given the rolling-admissions timing pressure from Chapter 2.
:::

:::callout-pitfall
Common mistakes

- **Skipping it entirely.** The cardinal error — it blocks score release. Do it promptly.
- **Not picking a side.** "Both have merit" essays read as evasive; commit to one position.
- **Ignoring the perspectives.** You must engage the provided viewpoints, not write a freeform opinion piece.
- **Never addressing the opposition.** A one-sided essay misses the task's core skill (Body 2).
- **Over-investing prep time.** It's unscored — one or two practice runs suffice; don't spend prep weeks here.
- **No proofreading.** Leave 2–3 minutes to fix typos and clarity; sloppy mechanics undercut an otherwise fine essay.
:::

### Practice — 20.4

:::problem[Q1]{difficulty="easy"}
What happens to your score if you never complete the writing sample?

::::solution[Solution]
It is **not released to law schools** — the whole multiple-choice score stays locked until an approved writing sample is on file. Skipping the writing blocks your own score.
::::
:::

:::problem[Q2]{difficulty="standard"}
When should you complete the writing task, and why then?

::::solution[Solution]
**As soon as you're eligible** (in the flexible window around test day), so score release isn't delayed — important given rolling admissions, where applying early matters (Chapter 2).
::::
:::

:::problem[Q3]{difficulty="standard"}
Name three content mistakes that weaken an Argumentative Writing essay.

::::solution[Solution]
Any three of: **not picking a side**, **ignoring the provided perspectives**, **never addressing the opposition**, or **skipping proofreading**. (Skipping the essay entirely is the worst logistical error.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
Since the task is unscored, why do it carefully at all rather than typing anything to satisfy the requirement?

::::solution[Solution]
Because admissions officers **can read it**, and a coherent, well-argued sample reflects well while a careless or incoherent one can raise doubts about your writing and reasoning — the very skills law school demands. The requirement is satisfied by any completed sample, but a competent essay is a low-cost way to make a positive (rather than negative) impression, so a modest, organized effort is worth it even without a score.
::::
:::

## Chapter summary

:::summary
#### The writing task, distilled

- **Unscored but mandatory:** your score is not released until an approved writing sample is on file. Do it promptly.
- **The task:** a debatable issue + 3–4 perspectives; take a position and defend it while engaging the competing views. ~15 min prewrite + ~35 min write.
- **Template:** intro (declare position) → body 1 (best reason) → body 2 (address opposition — the key paragraph) → body 3 (optional) → conclusion.
- **Commit to a side** (argue the one you can defend best), use the perspectives by substance, and concede-then-outweigh the opposition.
- **Don't over-prepare** (one or two runs), but do proofread and never skip it.
:::

LSAT Mastery — Chapter 20. Independent study material, not affiliated with LSAC. The writing task's scoring status and requirements can change — confirm current details at lsac.org. Sample prompt and essay are original.
