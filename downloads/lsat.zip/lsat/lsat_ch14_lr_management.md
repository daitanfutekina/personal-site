---
title: "LR Section Management"
source: "lsat_ch14_lr_management.html"
---

Part II · Chapter 14

# LR Section Management

Per-question skill isn't a section score until you can deploy it across 35 minutes and ~25 questions. This chapter is the difference between "I can do these untimed" and "I score well under the clock."

**Est. study time:** 40–50 min — **Sections:** 4 — **Practice:** 15+ items

## Overview

You've now learned every Logical Reasoning question type (Chapters 4–13). But a section isn't a pile of isolated questions — it's a 35-minute race in which your job is to *capture the most points*, not to conquer every question in order. This chapter teaches the meta-skill: how to spend your minutes so that the questions you're capable of getting all get got. Most people who "can do the questions" but underperform on test day are losing points to *management*, not ability — they sink five minutes into one brutal question and rush past three easy ones they'd have aced.

Three levers: **pacing with skip-and-return**, **reading difficulty** so you invest where points are cheap, and a disciplined **guessing** policy so no blank ever costs you.

:::callout-tip
Prerequisites

Chapter 2 (the pacing math: ~1:24 per LR question, no wrong-answer penalty) and Chapter 3 (every raw point matters, and careless-error recovery is high-yield). This chapter turns those facts into an in-section playbook. The full study plan for building this stamina is Part V.
:::

## 14.1 · Pacing & the skip-and-return strategy

:::callout-intuition
Intuition first

Every question is worth exactly one point — the agonizing Parallel question and the gimme Main-Conclusion question count the same. So the worst thing you can do is pour four minutes into one hard question while three easy points wait unseen at the end of the section. The fix is **skip-and-return**: when a question resists, you flag it, guess, and move on, banking the easy points first and coming back with whatever time remains. You're maximizing points per minute, not honor per question.
:::

:::definition
**Definition 14.1 — Skip-and-return.** A pacing method: on your first pass through the section, solve the questions you can do efficiently and *temporarily skip* any that bog you down — flagging each (Chapter 2's flag tool) and **bubbling a placeholder guess** before moving on. After the first pass, return to flagged questions with your remaining time. This guarantees you see every question and never lose an easy point to a hard one.
:::

### The "two-minute" rule of thumb

A practical trigger: if you've spent roughly **90 seconds to 2 minutes** on a question and don't see the path to the answer, **flag it, guess, and go**. The math from Chapter 2 (~84 seconds average) means every extra minute on one question is stolen from others. One hard question is never worth two easy ones.

:::example
Worked Example 14.1 — the cost of stubbornness

standard

**Scenario.** With 8 minutes left you have 6 questions to go. Question 20 is a brutal Parallel question. You could (a) spend 4 minutes cracking it, leaving 4 minutes for 5 questions, or (b) flag-and-guess it in 30 seconds, leaving 7.5 minutes for the other 5.

**Question.** Which choice likely captures more points?

Answer: (b) — flag and move on.

**How we get there.** Compare expected points. Option (a): maybe you get Q20 (1 point), but 5 questions now share 4 minutes (48 sec each) — you'll rush and likely miss 2–3 of them. Net: perhaps 1 + 3 = ~4 of these 6. Option (b): Q20 becomes a ~20% guess (0.2 expected points), but the other 5 get 90 seconds each — comfortable — so you likely get ~4–5 of them. Net: ~0.2 + 4.5 = ~4.7. Skipping the time-sink yields *more* total points, because it protects five easier points from being rushed. **Teaching point:** the question you're tempted to fight is usually the *least* efficient place to spend time.
:::

:::callout-pitfall
Watch out for these mistakes

- **Sunk-cost stubbornness.** "I've already spent two minutes, I can't quit now" is exactly backwards — the two minutes are gone either way; protect the remaining questions.
- **Skipping without bubbling a guess.** Always fill a placeholder answer before you move on, in case you never make it back (Chapter 2: no penalty for wrong answers).
- **Not flagging.** Use the flag tool so you can find skipped questions instantly on your return pass.
- **Never returning.** Budget a return pass; skip-and-return only works if you actually come back with your banked time.
:::

### Practice — 14.1

:::problem[Q1]{difficulty="easy"}
What three actions make up "skip" in skip-and-return?

::::solution[Solution]
**Flag** the question, **bubble a placeholder guess**, and **move on** — so you can find it later and never leave it blank.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why does spending 4 minutes on one hard question usually cost more than one point?

::::solution[Solution]
Because those 4 minutes are drained from other questions (~84 sec each), forcing you to rush several **easier** questions you'd otherwise get — so you risk losing 2–3 easy points to salvage a coin-flip on one hard one. Net points fall.
::::
:::

:::problem[Q3]{difficulty="standard"}
You realize at minute 2 you have no path on a question. What's the disciplined move?

::::solution[Solution]
**Flag, guess, and go.** Don't chase sunk cost; protect the remaining questions' time and come back if the return pass allows.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why is the question you most *want* to keep fighting often the worst place to spend time?

::::solution[Solution]
Because your reluctance to quit signals it's **hard for you specifically** — low probability of a quick, correct solve — so each additional minute has a poor expected return, while that same minute spent on easier remaining questions reliably converts to points. Emotional investment isn't correlated with point efficiency; often it's inversely correlated.
::::
:::

## 14.2 · Difficulty ordering within a section

:::callout-intuition
Intuition first

LR sections tend to get *harder toward the middle-to-end* — roughly, the easiest questions cluster early and the nastiest live in the back half (though it's not strictly monotonic). Knowing this shapes your plan: move briskly through the early questions to bank easy points and preserve time for the harder back stretch — and don't be rattled when questions get tough late; that's expected, not a sign you're failing.
:::

:::definition
**Definition 14.2 — The difficulty curve.** Within an LR section, question difficulty generally *rises* after the first several questions, with many of the hardest around the last third — but individual placement varies, and an easy question can appear late. Practical implication: don't spend "early-question time" on early questions (they're meant to be quick) and budget extra for the back.
:::

:::callout-key
Two ordering tactics

**(1) Bank the front fast.** Early questions are usually the cheapest points on the section — solve them efficiently and don't over-check; the time you save funds the hard back end. **(2) Two-pass the section.** On pass one, do every question you can handle at a normal pace and skip-and-return the rest (14.1); on pass two, spend your banked time on the flagged hard ones. This naturally routes your minutes to where they're needed without you having to predict difficulty perfectly.
:::

:::callout-tip
Don't confuse "late" with "impossible"

A hard question late in the section is worth the same one point as an easy one early. If a late question is genuinely too hard, that's a fine place to take your guess and invest the time confirming answers on questions you can actually get. Conversely, watch for the occasional easy question hiding at the end — don't reflexively skip it just because of its position.
:::

:::callout-pitfall
Watch out for these mistakes

- **Over-investing early.** Triple-checking easy early questions burns the time you'll need later. Be efficient, then move.
- **Panicking when it gets hard.** Rising difficulty late is normal and expected; it doesn't mean you're doing badly.
- **Assuming strict order.** Difficulty isn't perfectly monotonic — judge each question on its own, and don't skip a late gimme.
:::

### Practice — 14.2

:::problem[Q1]{difficulty="easy"}
Where in an LR section do the hardest questions tend to cluster?

::::solution[Solution]
Generally in the **middle-to-back** (often the last third), after the easier early questions — though placement isn't strictly ordered.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why should you move quickly through the first several questions?

::::solution[Solution]
They're usually the **easiest, cheapest points**; solving them efficiently (without over-checking) banks time for the harder back stretch. Over-investing early steals time you'll need later.
::::
:::

:::problem[Q3]{difficulty="standard"}
How does the two-pass method route your time correctly without predicting each question's difficulty?

::::solution[Solution]
By solving whatever you can at normal pace on pass one and skipping the rest, your **banked time automatically flows to the flagged hard questions** on pass two — the section itself sorts the questions into "quick now" and "hard later," so you don't need to forecast difficulty in advance.
::::
:::

:::problem[Q4]{difficulty="challenge"}
A very hard question sits at position 22 of 25. Give a defensible plan for it and justify it in point terms.

::::solution[Solution]
**Skip-and-guess it on pass one, and only return if time remains after securing every gettable question.** Since it's one point equal to any other and it's low-probability for you, the time it would consume is better spent confirming answers on questions you can actually get (protecting existing points) or attempting other flagged questions with higher solve odds. If your return pass has spare time, take a real attempt; otherwise the guess stands. This maximizes expected points rather than honoring a hard question.
::::
:::

## 14.3 · Guessing strategy & never leaving blanks

:::callout-intuition
Intuition first

Because the LSAT has **no penalty for wrong answers** (Chapters 2–3), a blank is strictly worse than a guess — a blank scores zero, a guess has a positive chance. This one fact yields an iron rule: **every bubble gets filled, always.** Beyond that, a little strategy makes your guesses slightly better: guess early (as a placeholder when you skip), eliminate what you can before guessing, and keep a consistent "letter of the day" for pure blind guesses.
:::

:::definition
**Definition 14.3 — The guessing policy.** (1) **Never leave a blank** — fill every question. (2) When you skip (14.1), immediately bubble a *placeholder* guess so a missed return never costs you. (3) When you can, **eliminate** even one or two choices before guessing — it raises your odds from ~20% to ~25–33%. (4) For pure blind guesses with no time to eliminate, pick a **single consistent letter** for all of them.
:::

### The math of guessing

A blind guess on a 5-choice question is right ~20% of the time. Eliminate one choice → ~25%; eliminate two → ~33%. Across a section, this adds up: guess-filling 5 unanswered questions blindly earns ~1 point on average; if you'd eliminated down to 3 choices on each, ~1.7 points. And the "single consistent letter" tactic slightly beats scattered guessing because answer keys aren't perfectly uniform across a small set and, more importantly, it's *fast and mistake-proof* — you don't waste time deciding.

:::example
Worked Example 14.2 — end-of-section triage

standard

**Scenario.** 60 seconds left; 4 questions unanswered. You can meaningfully attempt only one.

**Question.** What's the point-maximizing sequence of actions?

Answer: Immediately bubble a guess on all 4; then spend the remaining ~50 seconds actually working the one you can, updating its bubble if your worked answer differs.

**How we get there.** Step 1 — *guarantee no blanks*: with 4 blanks, first fill all four with your letter-of-the-day (takes ~5 seconds). Now the worst case is 4 guesses (~0.8 expected points) instead of 4 zeros. Step 2 — *convert one guess to a solve*: use the remaining time on the one question you can realistically get, and overwrite its guess with the real answer. This ordering guarantees you capture the guaranteed value first (no blanks) before spending time on upside. Reversing the order risks running out of time mid-solve and leaving three blanks. **Teaching point:** lock in the guaranteed points, then chase the upside.
:::

:::callout-pitfall
Watch out for these mistakes

- **Leaving any blank.** The cardinal sin — a blank can only score zero. Fill everything.
- **Solving before guess-filling when time is nearly up.** If the clock might beat you, bubble all blanks *first*, then solve — so a time-out doesn't leave blanks.
- **Agonizing over which letter to guess.** Pick one letter and use it for all blind guesses; the deliberation isn't worth the seconds.
- **Not eliminating when you easily could.** Even crossing off one obviously-wrong choice improves your guess; do it when it's fast.
:::

### Practice — 14.3

:::problem[Q1]{difficulty="easy"}
Why pick one letter and use it for every blind guess, rather than varying them?

::::solution[Solution]
Because varying them buys nothing and costs something. A blind guess has the same expected value whichever letter you bubble, so there is no advantage to spreading them — but choosing between five letters, twenty times, under a clock, spends seconds you do not have and attention you need elsewhere. Fixing the letter before test day means the decision is already made: bubbling becomes automatic, and the only thinking left is whether you can eliminate anything first.
::::
:::

:::problem[Q2]{difficulty="standard"}
With 40 seconds left and 3 blanks you can't fully solve, what do you do first?

::::solution[Solution]
**Immediately bubble a guess on all 3** (letter of the day). Lock in the guaranteed expected points before the clock runs out; only then attempt any partial elimination if time remains.
::::
:::

:::problem[Q3]{difficulty="standard"}
Eliminating two of five choices raises your guess odds to roughly what?

::::solution[Solution]
About **1 in 3 (~33%)** — versus ~20% blind. Even partial elimination meaningfully improves guesses, so do it whenever it's quick.
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why bubble a placeholder guess the moment you *skip* a question, rather than waiting until the end?

::::solution[Solution]
Because you might never make it back — you could run out of time or lose track. Bubbling immediately means **every skipped question already has a scoring chance**, so a forgotten or time-blocked return costs you nothing beyond the guess. It converts "skip" from a risk into a safe deferral.
::::
:::

## 14.4 · Scenario drills

Eight in-section decision scenarios. These train judgment, not content — decide your move, then check.

:::problem[1]{difficulty="easy"}
You're 10 minutes in and only on question 6 of 25. What does this tell you and what should you change?

::::solution[Solution]
You're **well behind pace** (should be ~q7–8 by 10 min). Change: speed up, be more willing to skip-and-guess sticky questions, and stop over-checking. Bank easier points faster; don't let early questions eat the clock.
::::
:::

:::problem[2]{difficulty="standard"}
A question 1 (very first) is taking you 3 minutes. What likely went wrong and what's the fix?

::::solution[Solution]
Early questions should be quick; 3 minutes means you're either over-thinking a simple question or hit an unusually placed hard one. Fix: **flag, guess, move on** — don't let the very first question blow your pacing. Return later if time allows.
::::
:::

:::problem[3]{difficulty="standard"}
With 5 minutes left you have 3 flagged questions and 2 unseen questions. Where do you go first?

::::solution[Solution]
Generally to the **unseen questions first** — they might be easy points you haven't yet captured, whereas the flagged ones already have placeholder guesses and were hard enough to skip. Grab fresh gettable points before re-fighting known-hard ones. (Ensure all 5 are bubbled regardless.)
::::
:::

:::problem[4]{difficulty="standard"}
You finish the section with 4 minutes to spare and feel confident. Good sign or warning?

::::solution[Solution]
Possibly a **warning** — finishing early with lots of time can mean you rushed and didn't verify. Use the spare time to **recheck flagged questions and confirm your work**, especially on questions where you hesitated. Don't sit idle; convert extra time into accuracy.
::::
:::

:::problem[5]{difficulty="standard"}
You're stuck between two answers on a question and 1.5 minutes have passed. Move?

::::solution[Solution]
**Make your best choice (or eliminate to the better of the two) and move on** — don't burn more time at a 50/50. If truly torn, pick one, flag it, and return later with fresh eyes if time permits. Two-answer deadlocks rarely resolve by staring longer.
::::
:::

:::problem[6]{difficulty="challenge"}
Two questions remain, 3 minutes left: one is a short, familiar-looking Assumption question, the other a long Parallel question. Order?

::::solution[Solution]
Do the **short Assumption question first** — it's likely faster and higher-probability, so secure that point, then give the remaining time to the long Parallel one (guess-bubbled already). Prioritize the higher expected-value-per-minute question. Never leave the Parallel blank regardless.
::::
:::

:::problem[7]{difficulty="challenge"}
Halfway through, a wave of anxiety hits and you feel you're "failing." Reframe using this chapter.

::::solution[Solution]
Rising difficulty and a few skipped questions are **expected and built into good management**, not signs of failure. The plan already accounts for skipping hard questions and guessing; you're executing it. Refocus on capturing the next gettable point rather than judging the section — the score comes from steady point-capture, not from feeling in control.
::::
:::

:::problem[8]{difficulty="challenge"}
In one or two sentences, state the governing goal of section management and how it changes your in-the-moment decisions.

::::solution[Solution]
The goal is to **maximize total points captured in 35 minutes**, not to solve every question in order. That reframes each decision as "where does my next minute earn the most points?" — leading you to bank easy questions fast, skip-and-guess time-sinks, fill every blank, and spend saved time verifying gettable points rather than conquering hard ones.
::::
:::

## Chapter summary

:::summary
#### LR section management, distilled

- **Maximize points per minute,** not questions solved in order. Every question is one point.
- **Skip-and-return:** at ~90 sec–2 min with no path, flag, bubble a guess, move on; come back on a second pass.
- **Bank the front fast;** expect the back third to be harder. Two-pass so time flows to hard questions automatically.
- **Never leave a blank.** No wrong-answer penalty, so guess everything; eliminate when quick; use a letter of the day.
- **End-of-section:** bubble all blanks first, then solve the one you can — lock guaranteed value before chasing upside.
:::

:::callout-connect
End of Part II

That completes Logical Reasoning — roughly half your score. You now have the full toolkit: argument foundations (Ch 4), formal logic (Ch 5), the flaw catalog (Ch 6), every question type (Ch 7–13), and section management (Ch 14). Next, Part III turns to Reading Comprehension, where many of these same instincts — finding conclusions, tracking whose view is whose, defending answers from the text — reappear on longer passages.
:::

LSAT Mastery — Chapter 14. Independent study material, not affiliated with LSAC. Pacing figures are guidelines; calibrate them to your own timed practice. Use official LSAC PrepTests for timed practice.
