---
title: "Foundations of Argument"
source: "lsat_ch4_foundations.html"
---

Part II · Chapter 4

# Foundations of Argument

Logical Reasoning is half your score, and every question in it is built on one skeleton: a conclusion, some premises, and a gap between them. Learn to see that skeleton and the rest of Part II becomes variations on a theme.

**Est. study time:** 60–75 min — **Sections:** 5 — **Practice:** 25+ items

## Overview

This is the most important chapter in Part II, because everything after it depends on the moves you learn here. Almost every Logical Reasoning question — Strengthen, Weaken, Flaw, Assumption, and more — is the same underlying task wearing a different mask: *find the conclusion, find the support, find the gap between them, and do something to the gap.* Master the anatomy of an argument and you're not learning a dozen unrelated question types later; you're learning a dozen things to *do* with one structure you can already see.

You'll learn to split any argument into conclusion and premises using indicator words, to name the *gap* (the assumption) that the whole test revolves around, to run a repeatable six-step method on every question, to apply the credited-response principle from Chapter 1 with surgical precision, and to recognize the five recurring "flavors" of wrong answer the test writers reuse.

:::callout-tip
Prerequisites

Chapter 1 — especially the credited-response principle (the right answer is the one the text supports) and the outside-knowledge trap. This chapter turns that principle into concrete technique. No formal logic yet; that's Chapter 5.
:::

## 4.1 · Conclusion vs. premise

:::callout-intuition
Intuition first

Every argument is somebody trying to get you to believe something (**the conclusion**) by offering reasons (**the premises**). If you can reliably answer "what is this person ultimately trying to convince me of, and what are they offering as support?" you've done 70% of the work on most LR questions before you even read the answer choices. The trouble is that arguments in the wild don't arrive labeled — the conclusion can sit at the start, the end, or buried in the middle — so you need a way to find it every time.
:::

:::definition
**Definition 4.1 — Conclusion and premise.** The *conclusion* is the main claim the author wants you to accept — the point of the argument. A *premise* is a statement offered as support for the conclusion. A quick test: the conclusion is the claim that the premises are trying to *prove*; the premises are the claims you'd cite if asked "why should I believe that?"
:::

### Indicator words: the fastest way to find each

Authors signal structure with recurring words. They're not foolproof, but they're your first tool:

| Conclusion indicators | Premise indicators |
| --- | --- |
| therefore, thus, hence, so | because, since, for |
| consequently, it follows that | given that, as, after all |
| clearly, this shows/means that | the reason is, on the grounds that |
| we can conclude that | as indicated by, in that |

:::callout-tip
The "therefore / because" test

When you think you've found the conclusion, test it: put "**therefore**" in front of it and "**because**" in front of the support. If "[support], *therefore* [conclusion]" reads naturally, you've split it correctly. If it reads backwards, swap them. This works even when the argument uses no indicator words at all, because it tests the *logical* direction, not the wording.
:::

:::example
Worked Example 4.1 — conclusion at the end

easy

"The bridge has needed repairs for years, and the recent inspection found dangerous corrosion. So the city should close the bridge until it can be fixed."

**Task.** Identify the conclusion and the premises.

Conclusion: "the city should close the bridge until it can be fixed." Premises: it has needed repairs for years; the inspection found dangerous corrosion.

**How we get there.** The word "*So*" is a conclusion indicator, pointing at the recommendation. Confirm with the test: "[needed repairs + corrosion], *therefore* [close the bridge]" reads naturally; the reverse ("[close the bridge] *because*... no") doesn't. The two factual claims are the reasons offered *for* the recommendation, so they're premises.
:::

:::example
Worked Example 4.2 — conclusion at the front

standard

"The new medication should not be approved. It has severe side effects in a significant minority of patients, and its benefits are only marginally greater than those of drugs already on the market."

**Task.** Identify the conclusion.

Conclusion: "The new medication should not be approved." (It's the first sentence.)

**How we get there.** There's no indicator word, so use the therefore/because test. Try it two ways: "[side effects + marginal benefit], *therefore* [should not be approved]" — reads perfectly. The reverse, "[should not be approved], *therefore* [side effects]," is nonsense. So the *first* sentence is the conclusion and the later sentences are premises. **Teaching point:** conclusions frequently lead. Never assume the last sentence is the conclusion — test it.
:::

:::example
Worked Example 4.3 — the buried conclusion & the "opponent's view" trap

challenge

"Many people claim that raising the driving age would reduce accidents. But teens are not disproportionately represented in the most serious crashes, and older new drivers are just as accident-prone in their first year. The real cause of crashes is inexperience, not youth."

**Task.** Identify the author's conclusion.

Conclusion: "The real cause of crashes is inexperience, not youth." (Last sentence.)

**How we get there.** Notice the first sentence is what *other people* claim ("Many people claim..."), flagged by the pivot word "**But**." The author is *disagreeing* with it, so that opening claim is not the author's conclusion — it's the position being rebutted. The two middle sentences are premises (evidence), and the final sentence is the claim they support. **Teaching point:** always track *whose* view a sentence expresses (Chapter 1's principle). A common trap is to grab the loud opening claim that the author actually argues *against*.
:::

:::callout-pitfall
Watch out for these mistakes

- **Assuming the last (or first) sentence is the conclusion.** Position varies; always run the therefore/because test.
- **Grabbing an opponent's claim.** When you see "some argue…," "many believe…," "it is often said…," followed by "but/however," that first claim is usually the view the author *rebuts*, not the conclusion.
- **Confusing a premise for the conclusion.** A striking, quotable statement can be mere support. Ask: is this the point, or a reason for the point?
- **Treating background/context as the argument.** Setup sentences ("Recently, the town installed cameras…") often just frame the situation; they're neither premise nor conclusion.
:::

### Practice — 4.1

For each, name the conclusion. Reveal only after committing.

:::problem[Q1]{difficulty="easy"}
"Exercise improves mood. Studies show people who exercise report less anxiety and depression. Therefore, doctors should recommend exercise to patients with mild depression."

::::solution[Solution]
Conclusion: **"doctors should recommend exercise to patients with mild depression."** Signaled by "Therefore." The first two sentences are premises (a claim + supporting studies).
::::
:::

:::problem[Q2]{difficulty="standard"}
"This restaurant will not survive another year. Its lease payments just doubled, its head chef quit last month, and customer traffic has fallen every quarter for two years."

::::solution[Solution]
Conclusion: **"This restaurant will not survive another year"** (the first sentence). No indicator, so test it: "[rent doubled + chef quit + traffic falling], *therefore* [won't survive]" reads correctly. The three facts are premises.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Some economists insist that tax cuts always pay for themselves through growth. However, revenues fell sharply after the last three major cuts. Tax cuts do not reliably fund themselves."

::::solution[Solution]
Conclusion: **"Tax cuts do not reliably fund themselves."** The opening "Some economists insist…" + "However" marks a view the author *rebuts*; the revenue fact is a premise; the last sentence is the author's point. Don't grab the economists' claim.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"It is widely assumed that reading to children makes them better readers. But wealthier parents both read more to their children and provide many other advantages. Perhaps those other advantages, not the reading itself, explain the gains."

::::solution[Solution]
Conclusion: **"Perhaps those other advantages, not the reading itself, explain the gains."** The opening is a widely-held view the author questions ("But"); the wealth observation is a premise; the final hedged sentence ("Perhaps…") is the author's tentative conclusion. Note that conclusions can be *hedged* — "perhaps," "may," "likely" — and still be the main point.
::::
:::

:::problem[Q5]{difficulty="standard"}
"The museum's attendance rose 30% this year. After all, it launched a popular new exhibit and slashed ticket prices."

::::solution[Solution]
Conclusion: **"The museum's attendance rose 30% this year."** "After all" is a *premise* indicator introducing the reasons (new exhibit, lower prices), so what precedes it is the claim being supported. A good check that indicator words point you in the right direction.
::::
:::

## 4.2 · Finding the gap — the assumption

:::callout-intuition
Intuition first

Here's the secret at the center of Logical Reasoning: arguments almost never fully prove their conclusions. There's a leap — a place where the premises don't *quite* reach the conclusion, and the author quietly assumes something to bridge it. That leap is **the gap**, and the thing that would fill it is **the assumption**. Nearly every LR question is secretly about this gap: *Strengthen* asks you to reinforce it, *Weaken* to pry it open, *Assumption* to name it, *Flaw* to describe why it's a problem. Find the gap and you hold the key to the whole section.
:::

:::definition
**Definition 4.2 — The gap and the assumption.** The *gap* is the logical distance between what the premises establish and what the conclusion claims. An *assumption* is an unstated premise the argument needs in order to cross that gap — something the author takes for granted. If the assumption were false, the argument would fail.
:::

### How to find the gap: watch for new terms and jumps

The gap most often lives where the conclusion introduces an idea the premises never quite covered. Two reliable tells:

- **A new term in the conclusion.** If the conclusion mentions something the premises didn't (the premises talk about "sales" but the conclusion is about "profit"), the assumption is usually the link between them ("sales track profit here").
- **A jump in kind.** Premises give a correlation, the conclusion asserts causation; premises describe what *is*, the conclusion says what *ought* to be; premises describe a part, the conclusion claims something about the whole. Each jump hides an assumption.

:::example
Worked Example 4.4 — spot the gap

standard

"Our online ads reached twice as many people this year as last year. So our online ads generated twice as much revenue this year."

**Task.** State the gap and the assumption.

Gap: "reached people" ≠ "generated revenue." Assumption: the rate at which reached people become paying customers (and their spending) stayed the same, so doubling reach doubles revenue.

**How we get there.** The premise is about *reach* (how many people saw the ads); the conclusion is about *revenue* (money). Those are different terms — a classic new-term-in-the-conclusion gap. For "double the reach" to yield "double the revenue," the author must assume the conversion from viewers to dollars didn't change (same conversion rate, same average purchase). If, say, this year's extra viewers were far less likely to buy, reach could double while revenue barely moves. Naming that assumption *is* finding the gap.
:::

:::example
Worked Example 4.5 — the causation jump

standard

"Employees who use our new ergonomic chairs report fewer back problems than those who don't. The chairs clearly prevent back problems."

**Task.** Identify the gap.

Gap: correlation → causation. Assumption: nothing else explains the difference — the chairs themselves, not some other factor, cause the reduction.

**How we get there.** The premise reports a *correlation* (chair-users have fewer problems); the conclusion asserts *causation* (the chairs prevent problems). That leap from "goes together" to "causes" is the gap. The hidden assumption is that there's no alternative explanation — e.g., maybe healthier or younger employees chose the new chairs. You'll meet this exact jump constantly in Weaken and Flaw questions (Chapters 8–9); here just practice *seeing* it.
:::

:::callout-key
Why this is the master skill

Once you can state the gap in your own words, you can pre-answer almost any question about the argument: to *strengthen*, affirm the assumption ("there's no other explanation"); to *weaken*, deny it ("here's another explanation"); to name the *flaw*, describe the leap ("treats correlation as causation"); to state the *assumption*, just say it. **The gap is the hub; the question types are spokes.** This is why finding it comes before everything else.
:::

:::callout-pitfall
Watch out for these mistakes

- **Reading passively.** If you just absorb the argument as "sounds reasonable," you'll miss the gap. Read like a skeptic hunting for the leap.
- **Looking for the gap before finding the conclusion.** You can't locate the leap until you know where the argument is trying to land. Conclusion first (4.1), then gap.
- **Inventing gaps that aren't there.** Some inference questions have no argument at all (just facts). The gap idea applies to *arguments* — premises aiming at a conclusion.
:::

### Practice — 4.2

:::problem[Q1]{difficulty="easy"}
"Sales of our app rose after we added a dark-mode feature. Users clearly love dark mode." State the gap.

::::solution[Solution]
Correlation-to-causation gap: sales rising *after* the feature doesn't establish the feature *caused* it (maybe a marketing push or seasonal effect did). Assumption: nothing else explains the sales rise, and users' behavior reflects love of dark mode specifically.
::::
:::

:::problem[Q2]{difficulty="standard"}
"The new principal raised graduation requirements, and test scores went up the next year. Tougher requirements improve student learning." Name the gap and one assumption.

::::solution[Solution]
Gaps: correlation→causation *and* "test scores" standing in for "learning." Assumptions: the requirements (not some other change) caused the rise, *and* higher test scores actually reflect improved learning rather than, say, teaching to the test or a change in who took the test.
::::
:::

:::problem[Q3]{difficulty="standard"}
"Every member of the winning debate team studies philosophy. To build a winning team next year, the coach should recruit philosophy students." Identify the gap.

::::solution[Solution]
Gap: from "winners happen to study philosophy" (a correlation/description) to "recruiting philosophy students will *produce* winners" (a causal, forward-looking claim). Assumption: studying philosophy *causes* debate success (rather than, say, strong students being drawn both to philosophy and to debate) — so selecting on it will reproduce the winning.
::::
:::

:::problem[Q4]{difficulty="challenge"}
"Our factory's output per worker doubled after we installed the new machines. Therefore, our profits must have doubled." Give the gap and explain why it matters.

::::solution[Solution]
Gap: "output per worker" (productivity) ≠ "profits" (money after costs) — a new-term jump. Assumption: costs, prices, and demand held such that doubling output doubles profit. It matters because the expensive new machines, higher wages, or unsold inventory could raise output while leaving profit flat or lower. Output and profit are different quantities, and the argument silently equates them.
::::
:::

:::problem[Q5]{difficulty="standard"}
Why must you find the conclusion *before* you look for the gap?

::::solution[Solution]
Because the gap is the distance between the premises and the **conclusion** — you can't measure the leap until you know where the argument is trying to land. Misidentify the conclusion and you'll look for the gap in the wrong place. Structure (4.1) precedes gap-finding (4.2).
::::
:::

## 4.3 · The six-step method

:::callout-intuition
Intuition first

Strong test-takers don't improvise each question — they run the *same routine* every time, so their attention is free for the hard part (the reasoning) instead of "what do I do now?" This section gives you that routine. It feels slow at first and becomes automatic with reps, exactly like any trained skill (Chapter 1). Do it deliberately on every practice question until you stop noticing you're doing it.
:::

:::definition
**The six-step Logical Reasoning method.**

1. **Read the question stem first.** Know your job (Strengthen? Flaw? Inference?) before reading the stimulus — it tells you *how* to read.
2. **Read the stimulus actively** and find the **conclusion** (§4.1). Mentally mark it.
3. **Find the gap / assumption** (§4.2). State it in your own words. (For pure-fact "inference" stimuli, instead note what the facts combine to.)
4. **Pre-phrase** the answer: predict what the correct choice should do *before* reading the options.
5. **Eliminate aggressively.** Cross out choices that are out of scope, reversed, or too extreme; aim to get to two, then choose the one that better does the job.
6. **Confirm** the survivor actually answers *this* stem — not a different question you imagined.
:::

:::example
Worked Example 4.6 — the method in motion

standard

**Stem.** "Which one of the following, if true, most weakens the argument?"

"Ever since our town installed bright LED streetlights, nighttime crime has dropped 15%. The brighter lighting is deterring criminals."

- **(A)** Some residents find the new lights too harsh.
- **(B)** Nighttime crime also dropped in a neighboring town.
- **(C)** Daytime crime was unchanged over the same period.
- **(D)** LED lights use less electricity than the old lights.
- **(E)** The town also hired 20 additional night-shift police officers the same month the lights were installed.

Answer: (E).

**How we get there — narrating the six steps.**

1. **Stem:** it's a *Weaken* question. Job: make the conclusion less likely.
2. **Conclusion:** "The brighter lighting is deterring criminals." Premise: crime fell 15% after the lights went in.
3. **Gap:** correlation→causation — the author assumes the *lights* caused the drop, ruling out other causes.
4. **Pre-phrase:** the weakener should supply an *alternative cause* for the crime drop.
5. **Eliminate:** (D) electricity use — irrelevant, out of scope. (A) harsh lights — irrelevant to crime cause. (B) neighboring town also dropped — actually this *hints* at a broader cause, mildly weakening, keep as backup. (C) daytime unchanged — if anything slightly *supports* a nighttime-specific cause like lights. (E) 20 new officers hired the same month — a strong alternative cause.
6. **Confirm:** (E) directly gives another explanation for the exact effect, undercutting the causal claim. It beats (B), which is suggestive but vaguer. **Answer: (E).**

**Teaching point:** the pre-phrase ("find an alternative cause") did the heavy lifting — by step 4 you already knew what you were hunting for, so the choices sorted themselves quickly.
:::

:::callout-tip
Why "stem first" matters

The same stimulus is read differently depending on the job. For *Weaken* you hunt the gap to attack it; for *Inference* you ignore any conclusion and combine facts; for *Role* you track what each sentence *does*. Reading the stem first tunes your attention correctly the first time through, so you rarely have to re-read.
:::

:::callout-pitfall
Watch out for these mistakes

- **Skipping the pre-phrase** and diving into the choices. That's how attractive wrong answers catch you — you have no prediction to measure them against.
- **Reading the stimulus before the stem.** You'll read it "generically" and often have to go back.
- **Falling in love with the first good-looking choice.** Always check all five; the LSAT places tempting traps before the credited answer.
- **Answering a different question.** Step 6 exists because it's easy to pick the choice that "sounds true" instead of the one the *stem* asked for.
:::

### Practice — 4.3

:::problem[Q1]{difficulty="easy"}
Why is reading the question stem *before* the stimulus recommended?

::::solution[Solution]
Because your **job** determines *how* to read the stimulus (hunt the gap vs. combine facts vs. track roles). Knowing the task first tunes your attention correctly on the first read, saving a re-read.
::::
:::

:::problem[Q2]{difficulty="standard"}
In your own words, what is "pre-phrasing," and what mistake does it prevent?

::::solution[Solution]
Pre-phrasing is **predicting what the correct answer should do before reading the choices**. It prevents getting seduced by attractive wrong answers, because you're matching each option against a prediction rather than judging them cold.
::::
:::

:::problem[Q3]{difficulty="standard"}
Apply steps 1–4 (don't pick yet) to: Stem: "The argument's reasoning is most vulnerable to criticism because it…" Stimulus: "The company's most productive engineers all work from home. So allowing everyone to work from home will raise overall productivity."

::::solution[Solution]
**1. Stem:** Flaw question. **2. Conclusion:** letting everyone WFH will raise productivity; premise: the most productive engineers work from home. **3. Gap:** the top engineers may be productive for other reasons (talent/experience) and merely *choose* WFH — the argument confuses a correlation among top performers with a cause that would generalize to everyone. **4. Pre-phrase:** the flaw is "assumes what's true of a self-selected high performer group will transfer to everyone / mistakes correlation for cause." (Any Flaw answer describing that leap is the target.)
::::
:::

:::problem[Q4]{difficulty="challenge"}
Why does the method end with an explicit "confirm it answers this stem" step, rather than stopping once you've found an appealing choice?

::::solution[Solution]
Because the LSAT deliberately includes choices that are *true*, or that answer a *different* question, or that match the topic but not the task. Without a final check against the exact stem (e.g., "did I actually weaken it, not strengthen it? did I name the flaw the argument *made*?"), it's easy to pick a plausible-but-wrong answer. Step 6 catches that.
::::
:::

## 4.4 · The credited-response rule, applied

:::callout-intuition
Intuition first

Chapter 1 gave you the principle: the right answer is the one the *text* supports, not the one that sounds most reasonable. This section makes it a working habit. On every question you'll do the same thing to your finalists: try to **defend each one by pointing at specific words** in the stimulus. The choice you can defend from the page wins — and, crucially, you learn to *convict* the tempting one by naming exactly which word it violates.
:::

:::callout-key
The defense test (use it on every tough question)

For each remaining answer, force yourself to complete this sentence: "This is correct *because the stimulus says* \_\_\_." If you can quote or point to the words, it's a real candidate. If the best you can do is "well, it's probably true" or "that makes sense," you're reasoning from the world, not the text — and that's the trap. **Support beats plausibility, every time.**
:::

:::example
Worked Example 4.7 — plausible vs. provable

challenge

**Stem.** "The statements above, if true, most support which one of the following?"

"All of the town's licensed electricians attended the safety seminar. Some of those electricians later failed the certification exam. No one who failed the certification exam may work on commercial buildings."

- **(A)** Some of the town's licensed electricians may not work on commercial buildings.
- **(B)** Most licensed electricians are highly skilled.
- **(C)** The certification exam is unfair to licensed electricians.
- **(D)** Everyone who attended the seminar is a licensed electrician.
- **(E)** Licensed electricians should not have to take a separate exam.

Answer: (A).

**How we get there — running the defense test.**

- **(A):** Can I defend it from the words? Chain them: some of the town's licensed electricians failed the exam, and no one who failed may work on commercial buildings. So those electricians may not work on commercial buildings — which is exactly what (A) says, hedged to *some* because the stimulus only ever said some. Every word of it is on the page. Keep.
- **(B):** "highly skilled" — nothing about skill anywhere. Pure real-world plausibility. Trap.
- **(C):** "unfair" — a value judgment the text never makes. Out of scope.
- **(D):** reverses a relationship — we know electricians all attended, not that all attendees are electricians. Reversal.
- **(E):** "should not have to" — a recommendation the facts don't support. Out of scope.

**Teaching point:** (B) is the answer general reasoning might like ("electricians are skilled — sure"), but you cannot point to a single word supporting it. (A) is modest and hedged ("may"), and it's the only one the chained statements actually permit. The provable-but-modest choice beats the plausible-but-unmentioned one — the credited-response rule in action.
:::

:::callout-connect
Connects forward

This defense test is the same move you'll use on *Inference* questions (Chapter 10: the answer must be *guaranteed*), on *Strengthen/Weaken* (Chapter 8: the choice must act on the actual conclusion), and throughout Reading Comprehension (Part III: no outside knowledge). It's one habit that pays off across the entire test.
:::

:::callout-pitfall
Watch out for these mistakes

- **Rewarding sophistication.** The impressive, expert-sounding answer is often the trap; the credited answer is frequently a plain restatement of what the text guarantees.
- **Overlooking hedge words.** "May," "some," "could" make a claim *weaker* and thus *easier* to support; "all," "never," "must" make it stronger and harder. On support/inference questions, the safely-hedged answer is often correct.
- **Defending with "it's basically true."** "Basically" means you're importing something. Demand actual words.
:::

### Practice — 4.4

:::problem[Q1]{difficulty="easy"}
State the "defense test" in one sentence.

::::solution[Solution]
For each candidate answer, require yourself to finish "this is correct **because the stimulus says** \_\_\_" by pointing to specific words; if you can't, it's not text-supported and is likely a trap.
::::
:::

:::problem[Q2]{difficulty="standard"}
On a "most strongly supported" question, why does a hedged answer ("some X may be Y") tend to beat a strong one ("all X are Y")?

::::solution[Solution]
Because a **weaker claim needs less support** to be justified. "Some… may" can be true on far more readings of the text than "all… are," so it's easier to defend strictly from the words. Strong/absolute wording is harder to prove and is a common trap on support questions.
::::
:::

:::problem[Q3]{difficulty="standard"}
A stimulus about a vaccine study offers an answer: "Vaccines are one of medicine's greatest achievements." It's true. Why is it likely wrong?

::::solution[Solution]
Because **truth isn't the standard — textual support is**. Unless the stimulus actually establishes that sweeping evaluative claim (it won't), you'd be importing outside knowledge. It's the plausible-but-unsupported trap; the credited answer will stay tied to the study's specific findings.
::::
:::

:::problem[Q4]{difficulty="challenge"}
You're down to two answers: (P) restates two sentences of the passage exactly; (Q) draws a clever, likely-true conclusion the passage gestures toward but never states. Which do you pick on a support question, and what single question decides it?

::::solution[Solution]
Pick **(P)**. The deciding question: "*Can I point to words that force this?*" (P) is anchored in the text; (Q) requires a step the passage doesn't take, however plausible. On support/inference questions the credited answer hugs the text. (Caveat: double-check (P) hasn't slipped in a distorting word — a "restatement" that adds "always" can still be wrong.)
::::
:::

## 4.5 · The five wrong-answer flavors

:::callout-intuition
Intuition first

The LSAT recycles the *same kinds* of wrong answers over and over. Once you can name them on sight, elimination becomes fast and confident: instead of vaguely feeling "that's off," you say "that's *out of scope*" and cross it out. Learning these five flavors is like a doctor learning symptoms — you start diagnosing traps instead of agonizing over them.
:::

:::definition
**The five recurring wrong-answer flavors.**

1. **Out of scope.** Introduces something the argument never dealt with — a new topic, an irrelevant comparison. *Tell:* you can't tie it to the conclusion.
2. **Opposite (reversal).** Does the reverse of what's asked — strengthens on a Weaken question, or flips a conditional's direction. *Tell:* it's relevant but pointed the wrong way.
3. **Too strong / extreme.** Uses absolute language (all, never, only, impossible, proves) the modest argument can't support. *Tell:* one overstated word breaks it.
4. **Half-right.** The first part is perfect; the second part slips in a distortion. *Tell:* you nod, then hit a word that's wrong.
5. **True but useless.** A true statement (often real-world true) that doesn't affect the conclusion or answer the stem. *Tell:* "yes, and…?"
:::

:::example
Worked Example 4.8 — name every trap

challenge

**Stem.** "Which one, if true, most strengthens the argument?"

"Our city's recycling rate rose after we switched to larger recycling bins. The larger bins caused residents to recycle more."

- **(A)** Larger bins are more expensive to manufacture.
- **(B)** The city did not change anything else about its recycling program when it switched bins.
- **(C)** Recycling is beneficial for the environment.
- **(D)** The larger bins made every resident recycle.
- **(E)** The recycling rate fell after the larger bins were introduced.

Answer: (B). The others illustrate the four trap flavors.

**How we get there.** This is a causal argument (bigger bins → more recycling); to *strengthen* a causal claim, rule out other causes.

- **(B) — correct.** "Nothing else changed" eliminates alternative explanations, so the bins are the likely cause. Defensible strengthener.
- **(A) — true but useless.** Manufacturing cost is real information but has zero bearing on whether bins caused more recycling. "Yes, and…?"
- **(C) — out of scope.** Whether recycling is *good* is a different topic from whether the bins *caused* the increase.
- **(D) — too strong.** "Every resident" is an extreme claim the modest argument doesn't need and that's almost certainly false; overreach makes it a poor (and unsupportable) choice.
- **(E) — opposite.** It says the rate *fell*, contradicting the premise — the reverse of support.

**Teaching point:** naming the flavor is faster and surer than re-litigating each option. Once you tag (A) "true but useless" and (E) "opposite," they're gone — no agonizing.
:::

:::callout-pitfall
Watch out for these mistakes

- **Getting seduced by "too strong" answers** because they sound decisive. Decisiveness isn't support; the LSAT loves modest conclusions.
- **Missing the second half of a half-right answer.** Read every word — traps hide in the final clause.
- **Mistaking "true" for "relevant."** True-but-useless is the most seductive flavor because there's nothing *false* to catch. Ask what it *does* for the conclusion.
- **Not noticing a reversal** on Weaken/Strengthen and conditional questions. Always check the *direction*.
:::

### Practice — 4.5

:::problem[Q1]{difficulty="easy"}
Name the flavor: on a Weaken question, an answer that actually makes the conclusion *more* likely.

::::solution[Solution]
**Opposite (reversal).** It's relevant to the conclusion but points the wrong way — it strengthens when you needed to weaken.
::::
:::

:::problem[Q2]{difficulty="standard"}
Name the flavor and the tell: "Studies prove that no one who eats breakfast is ever overweight" as an answer to a modest argument about breakfast and metabolism.

::::solution[Solution]
**Too strong / extreme.** Tell: absolute words — "prove," "no one," "ever." A modest argument can't be supported (and this can't be true) at that strength; the overstatement breaks it.
::::
:::

:::problem[Q3]{difficulty="standard"}
"The mayor's plan will reduce traffic, and it will also make the city the safest in the nation." If only the first clause is supported, what flavor is this and why?

::::solution[Solution]
**Half-right.** The first clause ("reduce traffic") may be fine, but "safest in the nation" is an unsupported distortion tacked on. You must read the whole choice; the trap lives in the second half.
::::
:::

:::problem[Q4]{difficulty="standard"}
A Strengthen question about whether a fertilizer boosts crop yield offers: "The fertilizer is sold in most hardware stores." Flavor?

::::solution[Solution]
**True but useless** (also arguably out of scope). Where it's *sold* is likely true but does nothing to show it *boosts yield*. "Yes, and…?" — no effect on the conclusion.
::::
:::

:::problem[Q5]{difficulty="challenge"}
Why is "true but useless" often the hardest flavor to eliminate, and what question defeats it?

::::solution[Solution]
Because there's nothing *false* to catch — your instinct to reject "wrong" statements doesn't fire. It defeats itself once you ask not "is this true?" but "**what does this do to the conclusion / does it answer the stem?**" A true statement that does nothing for the argument fails that question, however accurate it is.
::::
:::

## Chapter summary

:::summary
#### The foundations to carry into every LR chapter

- **Split every argument into conclusion + premises.** Use indicator words and the "therefore/because" test; watch for opponents' views the author rebuts.
- **Find the gap.** The assumption bridging premises to conclusion is the hub of nearly every question type; look for new terms and jumps (correlation→cause, is→ought, part→whole).
- **Run the six-step method** every time: stem → conclusion → gap → pre-phrase → eliminate → confirm.
- **Apply the defense test.** Keep the answer you can support with specific words; reject the plausible-but-unmentioned one.
- **Name the five wrong-answer flavors** on sight: out of scope, opposite, too strong, half-right, true but useless.
:::

| Tool | Use it to… |
| --- | --- |
| Therefore/because test | Locate the conclusion regardless of position |
| Gap / assumption | Predict what strengthens, weakens, or is assumed |
| Six-step method | Run a consistent routine so attention goes to reasoning |
| Defense test | Choose the text-supported answer over the plausible one |
| Five flavors | Eliminate wrong answers fast and by name |

## Mixed practice set

Fourteen items across the whole chapter, mixed order and difficulty. Defend every answer from the text.

:::problem[1]{difficulty="easy"}
"Since the library extended its hours, student visits have climbed. The longer hours are clearly responsible." What is the conclusion?

::::solution[Solution]
Conclusion: **"The longer hours are clearly responsible"** (for the climb in visits). "Since" introduces the premise (extended hours); "clearly" flags the conclusion.
::::
:::

:::problem[2]{difficulty="standard"}
Same argument as #1. State the gap.

::::solution[Solution]
Correlation→causation: visits rising after the change doesn't prove the *hours* caused it (maybe exams, a new café, or enrollment growth did). Assumption: no alternative cause explains the increase.
::::
:::

:::problem[3]{difficulty="standard"}
Name the flavor: on a Strengthen question, "The plan has been used successfully in other countries" when the argument is about whether the plan will lower *this* city's specific costs.

::::solution[Solution]
Borderline **out of scope** / weak relevance — success elsewhere doesn't establish the cost effect *here*. It sounds supportive but doesn't act on the specific conclusion; a precise strengthener would address this city's cost mechanism.
::::
:::

:::problem[4]{difficulty="easy"}
Which comes first in the six-step method: reading the stimulus or reading the stem?

::::solution[Solution]
The **stem** first — it defines your job and tunes how you read the stimulus.
::::
:::

:::problem[5]{difficulty="standard"}
"Critics say the film is shallow. But it broke box-office records and won three major awards. The critics are wrong." Identify the conclusion and one premise, and note any trap structure.

::::solution[Solution]
Conclusion: **"The critics are wrong."** Premises: box-office records; three awards. Trap structure: the first sentence is the *critics'* view (signaled by "But"), which the author rebuts — don't mistake it for the conclusion. (Note also a lurking gap: commercial/award success doesn't directly refute "shallow.")
::::
:::

:::problem[6]{difficulty="challenge"}
"Every product we recalled had been made in the Ohio plant. So the Ohio plant must have a quality-control problem." Conclusion, gap, and one assumption.

::::solution[Solution]
Conclusion: the Ohio plant has a quality-control problem. Gap: "all recalled products came from Ohio" doesn't establish Ohio is *defective* — maybe Ohio makes *all* the products, so of course recalls trace there. Assumption: other plants also make products that *could* have been recalled (i.e., Ohio isn't the sole source), so the concentration of recalls in Ohio is meaningful rather than trivial.
::::
:::

:::problem[7]{difficulty="standard"}
Flavor check: on a Weaken question, an answer that repeats a premise from the stimulus. Why is it wrong?

::::solution[Solution]
It's **true but useless** (and can't weaken). Restating something already given adds no new consideration against the conclusion. A weakener must introduce a *new* fact that undercuts the reasoning.
::::
:::

:::problem[8]{difficulty="standard"}
"The forecast says 70% chance of rain, so it will definitely rain tomorrow." Name the flaw in terms of a "jump," and which wrong-answer flavor an answer like "weather forecasts are often inaccurate" would be for a question asking to identify the argument's flaw.

::::solution[Solution]
The jump is from a **probability** ("70% chance") to a **certainty** ("definitely") — the conclusion is far stronger than the premise supports (a "too strong" conclusion). An answer like "forecasts are often inaccurate" would be **out of scope / true but useless**: it attacks forecasts generally rather than naming the actual error (treating 70% as 100%).
::::
:::

:::problem[9]{difficulty="easy"}
Give two conclusion-indicator words and two premise-indicator words.

::::solution[Solution]
Conclusion: e.g., **therefore, thus** (also so, hence, clearly). Premise: e.g., **because, since** (also for, given that, after all).
::::
:::

:::problem[10]{difficulty="standard"}
Why can't you locate an argument's gap before identifying its conclusion?

::::solution[Solution]
The gap is the distance between premises and the **conclusion**; without knowing where the argument lands, you can't see the leap. Conclusion (4.1) → gap (4.2) is the required order.
::::
:::

:::problem[11]{difficulty="challenge"}
A "most supported" question leaves you with (X) a strong claim using "all" and (Y) a hedged claim using "some… may." The passage gives limited information. Which is the safer pick and why?

::::solution[Solution]
**(Y).** Hedged claims require less evidence to justify, so they're easier to defend from limited text; "all" demands the passage rule out every exception, which limited information rarely does. On support/inference questions, weaker wording is usually safer — provided (Y) isn't otherwise distorted.
::::
:::

:::problem[12]{difficulty="standard"}
In the six-step method, which step most directly prevents "falling in love" with an attractive wrong answer, and how?

::::solution[Solution]
**Pre-phrasing (step 4).** By predicting what the right answer must do *before* reading choices, you evaluate each option against your prediction instead of its surface appeal, so a slick-but-wrong choice has to survive comparison rather than win on charm.
::::
:::

:::problem[13]{difficulty="challenge"}
"Because our best-selling author writes mysteries, we should have all our authors write mysteries to boost sales." Identify conclusion, the key gap, and pre-phrase what would weaken it.

::::solution[Solution]
Conclusion: all our authors should write mysteries (to boost sales). Gap: assumes the *genre* caused the sales (not the author's individual talent/following) and that it would transfer to everyone. Weakener pre-phrase: something showing the best-seller's success comes from the author, not the genre — e.g., "other publishers' mysteries sell poorly," or "the author's non-mystery books also sell well." Any of these attacks the genre-causes-sales assumption.
::::
:::

:::problem[14]{difficulty="challenge"}
In one or two sentences, explain how the gap concept unifies Strengthen, Weaken, Assumption, and Flaw questions.

::::solution[Solution]
All four target the same gap between premises and conclusion: **Strengthen** reinforces the assumption that bridges it, **Weaken** denies that assumption, **Assumption** states it, and **Flaw** describes why the leap is illegitimate. Find the gap once and you can handle whichever of these the stem asks for — which is why this chapter precedes them all.
::::
:::

LSAT Mastery — Chapter 4. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
