---
title: "Flaw Questions"
source: "lsat_ch9_flaw.html"
---

Part II · Chapter 9

# Flaw Questions

You already know the flaws (Chapter 6). Flaw questions add two twists: the answer must match the error the argument *actually* made, and it's written in abstract, lawyerly language you have to translate on the fly.

**Est. study time:** 55–70 min — **Sections:** 3 — **Practice:** 22+ items

## Overview

Flaw questions ask: "the reasoning is most vulnerable to criticism on the grounds that it…" — and then five answer choices each describe a possible reasoning error in abstract terms. Your job is to pick the one that names the flaw the argument *committed*. The content of the flaws you already learned in Chapter 6; this chapter is about two new skills: (1) matching — the answer must describe the *actual* error, not just any real error, and (2) translation — LSAT flaw answers are written in a dense, generic style ("takes for granted that…," "presumes, without justification, that…") that you must decode into plain English quickly.

Flaw is one of the most common LR question types, so fluency here pays off twice over — and the same "abstract description" skill reappears in Method and Parallel questions (Chapters 11–12).

:::callout-tip
Prerequisites

Chapter 6 (the flaw catalog — you'll be naming these), Chapter 4 (conclusion/gap), and the necessary/sufficient material from Chapter 5. If you can't yet name the common flaws on sight, review Chapter 6 first; this chapter assumes them.
:::

## 9.1 · Match the error the argument actually made

:::callout-intuition
Intuition first

Here's the trap that defines Flaw questions: four of the five answers describe *real* reasoning errors — errors that *exist* and that arguments *can* make — but that *this particular argument* didn't commit. They sound like legitimate criticisms in the abstract, so they're tempting. The credited answer is the one error the argument in front of you actually made. So the winning move is to **name the flaw yourself before reading the choices** (pre-phrase), then find the choice that matches your pre-phrase.
:::

:::definition
**Definition 9.1 — The matching requirement.** A correct Flaw answer must satisfy two conditions: (1) it describes a genuine reasoning error, *and* (2) the argument actually *commits* that error. Wrong answers usually fail condition (2): they name real flaws the argument didn't make. Method: identify the flaw in your own words first, then match.
:::

:::example
Worked Example 9.1 — real flaws that don't apply

standard

"The mayor claims the new stadium will boost the local economy. But the mayor stands to profit personally from the stadium deal. So the stadium will not boost the economy."

**Stem.** The reasoning is most vulnerable to criticism because it…

- **(A)** relies on a sample too small to support its conclusion.
- **(B)** rejects a claim solely by impugning the motives of the person who made it.
- **(C)** confuses a cause with its effect.
- **(D)** assumes that what is true of a group is true of each of its members.
- **(E)** treats a necessary condition as if it were sufficient.

Answer: (B).

**How we get there.** Pre-phrase first: the argument dismisses the stadium claim because of the mayor's *motives*, not the claim's merits — that's **ad hominem** (Chapter 6). Now match: (B) describes exactly that ("impugning the motives of the person"). The others — small sample, cause/effect, composition, necessary/sufficient — are all *real* flaws, but this argument commits none of them. They're pure temptation for someone who didn't pre-phrase. **Teaching point:** because every wrong answer is a genuine error-type, you can't pick by "does this describe a real flaw?" — you must ask "did *this* argument do it?"
:::

:::callout-tip
The elimination question

For each answer, ask: "**Did the argument actually do this?**" If you can't point to where in the stimulus the argument commits the described error, eliminate it — no matter how real the error sounds. The credited answer is the one you can pin to a specific move the argument made.
:::

:::callout-pitfall
Watch out for these mistakes

- **Choosing a "real flaw" that isn't present.** The most common Flaw error. Every wrong choice is designed to be a legitimate error-type.
- **Skipping the pre-phrase.** Without your own name for the flaw, all five abstract descriptions look plausible.
- **Over-reading a fine argument as flawed.** Occasionally a choice describes something the argument reasonably did; make sure the "flaw" is genuinely a defect, not sound reasoning.
:::

### Practice — 9.1

:::problem[Q1]{difficulty="standard"}
"Every successful startup founder I've met is a risk-taker. So risk-taking must be what makes startups succeed." Pre-phrase the flaw, then say which real-but-wrong flaw might tempt you.

::::solution[Solution]
Pre-phrase: **correlation→causation** (and a possibly unrepresentative sample of "founders I've met"). A tempting wrong answer might describe *necessary/sufficient confusion* or *circular reasoning* — real flaws the argument doesn't clearly commit. Match the causal (or sampling) description instead.
::::
:::

:::problem[Q2]{difficulty="standard"}
Why can't you choose a Flaw answer just because it accurately describes a common logical error?

::::solution[Solution]
Because **all four wrong answers also accurately describe common errors** — they just aren't the error *this* argument made. The answer must both be a real flaw *and* be one the argument actually committed. Only the second condition distinguishes them.
::::
:::

:::problem[Q3]{difficulty="standard"}
"The bill must be bad policy — it's supported mostly by politicians who take donations from oil companies." What flaw, and what's the one-line elimination test you'd use on the choices?

::::solution[Solution]
Flaw: **ad hominem / appeal to motive** (attacking supporters' funding rather than the bill's merits). Elimination test: for each choice ask "*did this argument actually do this?*" — keep only the one you can pin to the source-attack move.
::::
:::

:::problem[Q4]{difficulty="challenge"}
An argument reasons validly. A Flaw stem still asks what it's "vulnerable to." What should you suspect about the answer choices?

::::solution[Solution]
Either the argument does contain a subtle flaw you haven't spotted yet (re-examine the gap), or the question expects the choice that describes the *least unsupported* assumption. In practice, a genuine Flaw question always has a real defect — so look harder for the gap (often a hidden assumption or a scope shift). Don't invent a flaw, but don't assume validity just because it "sounds" reasonable; the credited answer names an actual weakness.
::::
:::

## 9.2 · Decoding abstract flaw descriptions

:::callout-intuition
Intuition first

The LSAT deliberately writes Flaw answers in generic, abstract language so you can't pattern-match on keywords. "Takes for granted that a condition sufficient for a result is also necessary for it" is just "necessary/sufficient confusion" in a lab coat. Learning to translate this house style into the plain flaw names from Chapter 6 — in both directions — is the core skill of section 9.2.
:::

:::definition
**Definition 9.2 — LSAT flaw-answer vocabulary.** A set of stock phrases the test reuses. "Takes for granted / presumes / assumes without justification" = *relies on an unstated assumption*. "Fails to consider / overlooks the possibility that" = *ignores an alternative*. "Treats X as though it were Y" = *a confusion or conflation*. Learn to map each phrase to a concrete flaw.
:::

### A translation table

| LSAT abstract phrasing | Plain-English flaw |
| --- | --- |
| "takes for granted that because one event followed another, the first caused the second" | correlation/causation (post hoc) |
| "fails to consider that another factor might account for…" | overlooks an alternative cause |
| "treats a condition necessary for an outcome as though it were sufficient" | necessary/sufficient confusion |
| "draws a general conclusion from an unrepresentative sample" | sampling flaw |
| "rejects a position merely by criticizing its proponent" | ad hominem |
| "presumes, without warrant, the very point it aims to establish" | circular reasoning |
| "relies on a term used in two different senses" | equivocation |
| "assumes what is true of the whole must be true of its parts" | division (whole→part) |
| "treats two options as exhaustive when others exist" | false dilemma |
| "infers that a claim is false merely because it has not been proven true" | appeal to ignorance |

:::example
Worked Example 9.2 — translate, then match

challenge

"No one has ever proven that the lake monster does not exist. Therefore, the lake monster is real."

**Stem.** The argument's reasoning is flawed because it…

- **(A)** generalizes from an atypical example.
- **(B)** confuses the cause of an event with its effect.
- **(C)** infers that a claim is true merely because it has not been shown to be false.
- **(D)** relies on the testimony of people who did not witness the events.
- **(E)** takes a condition sufficient for a conclusion to be necessary for it.

Answer: (C).

**How we get there.** Pre-phrase in plain English: "it treats 'not disproven' as 'proven' — absence of evidence as evidence." That's the **appeal to ignorance**. Now translate the choices: (C) says "true merely because not shown false" — an exact match for appeal to ignorance. The others translate to testimony problems, hasty generalization, and cause/effect confusion — none present. **Teaching point:** do the translation in *both* directions — name the flaw plainly from the stimulus, name each choice plainly, then match the two plain versions. Matching in plain English is far easier than matching abstract-to-abstract.
:::

:::callout-pitfall
Watch out for these mistakes

- **Keyword-matching.** An answer can share vocabulary with the stimulus yet describe the wrong error. Translate the whole phrase, don't grab a familiar word.
- **Being intimidated by the abstraction.** Every stock phrase reduces to a Chapter 6 flaw. Practice the translations until they're automatic.
- **Accepting a subtly-off description.** "Treats a *sufficient* condition as necessary" ≠ "treats a *necessary* condition as sufficient." Read the direction of the described error carefully — it's the same trap as Chapter 5, embedded in the answer.
:::

### Practice — 9.2

:::problem[Q1]{difficulty="standard"}
Translate: "presumes, without providing justification, the very conclusion it purports to prove."

::::solution[Solution]
**Circular reasoning** (begging the question) — assuming the conclusion within the premises.
::::
:::

:::problem[Q2]{difficulty="standard"}
Translate: "fails to exclude the possibility that some other factor produced both the supposed cause and the supposed effect."

::::solution[Solution]
**Overlooks a common cause** (a causal flaw) — a third factor causing both.
::::
:::

:::problem[Q3]{difficulty="challenge"}
Two choices: (i) "treats a necessary condition as sufficient"; (ii) "treats a sufficient condition as necessary." The argument reasons: "You must have a permit to build; the Smiths have a permit, so they'll build." Which describes its flaw, and why is the other a trap?

::::solution[Solution]
**(i).** "Must have a permit to build" makes the permit *necessary*; concluding "they'll build" from having it treats that necessary condition as *sufficient*. (ii) reverses the direction — a real but different error the argument didn't make. The near-identical wording makes (ii) a classic trap; read the direction precisely.
::::
:::

:::problem[Q4]{difficulty="standard"}
Translate to a plain flaw name: "generalizes about all members of a group on the basis of a sample drawn only from an atypical subset."

::::solution[Solution]
**Unrepresentative-sample flaw** (a sampling error) — generalizing from a biased subset to the whole group.
::::
:::

## 9.3 · Drill set

Twelve Flaw questions. For each: **name the flaw in plain English first**, then match the abstract choice. Watch for real-but-wrong-flaw traps and reversed descriptions.

:::problem[1]{difficulty="easy"}
"Sales rose right after the ad campaign, so the campaign boosted sales." The reasoning is flawed because it…

- **(A)** relies on an unrepresentative sample.
- **(B)** treats a necessary condition as sufficient.
- **(C)** attacks the source rather than the claim.
- **(D)** takes for granted that because one event followed another, the first caused the second.
- **(E)** treats a claim as true merely because it is widely believed.

::::solution[Solution]
**(D).** Post hoc / correlation-causation. Others are real flaws not committed here.
::::
:::

:::problem[2]{difficulty="standard"}
"To pass, you must submit all homework. Ravi submitted all homework, so he'll pass." Flawed because it…

- **(A)** generalizes from a single case.
- **(B)** confuses correlation with causation.
- **(C)** presumes what it sets out to prove.
- **(D)** draws a conclusion about a whole from facts about its parts.
- **(E)** treats a condition necessary for an outcome as though it guaranteed that outcome.

::::solution[Solution]
**(E).** Necessary/sufficient confusion. Submitting all homework is required, not enough.
::::
:::

:::problem[3]{difficulty="standard"}
"This economist's forecast is worthless — she failed to predict the last recession." Flawed because it…

- **(A)** dismisses a claim on the basis of the arguer's past record rather than the claim's merits.
- **(B)** relies on a false dilemma.
- **(C)** equivocates on a key term.
- **(D)** infers that because two things occur together, one must cause the other.
- **(E)** assumes what is true of a part is true of the whole.

::::solution[Solution]
**(A).** Ad hominem — attacking the forecaster's track record instead of the forecast's reasoning.
::::
:::

:::problem[4]{difficulty="standard"}
"Each musician in the orchestra is world-class, so the orchestra is world-class." Flawed because it…

- **(A)** treats two options as exhaustive.
- **(B)** assumes that what is true of each part must be true of the whole.
- **(C)** overlooks an alternative cause.
- **(D)** relies on a term whose meaning shifts during the argument.
- **(E)** infers a claim is true because it is not disproven.

::::solution[Solution]
**(B).** Composition (part→whole). Great individuals needn't make a great ensemble.
::::
:::

:::problem[5]{difficulty="standard"}
"We either cut arts funding or go bankrupt. We won't go bankrupt, so we must cut arts funding." Flawed because it…

- **(A)** confuses a sufficient condition with a necessary one.
- **(B)** generalizes from an atypical example.
- **(C)** presents two alternatives as the only options when others may exist.
- **(D)** treats the absence of evidence against a claim as evidence for it.
- **(E)** relies on the testimony of a biased source.

::::solution[Solution]
**(C).** False dilemma. Cutting arts vs. bankruptcy aren't the only choices.
::::
:::

:::problem[6]{difficulty="standard"}
"The policy is fair because it treats everyone equitably." Flawed because it…

- **(A)** draws a conclusion about individuals from facts about a group.
- **(B)** relies on an appeal to popular opinion.
- **(C)** generalizes from a sample unlikely to represent the population.
- **(D)** uses a premise that merely restates the conclusion in different words.
- **(E)** overlooks a possible common cause.

::::solution[Solution]
**(D).** Circular — "equitable" restates "fair"; no independent support.
::::
:::

:::problem[7]{difficulty="challenge"}
"Surveys of visitors to the national park's website show strong support for higher entrance fees. So most park visitors support higher fees." Flawed because it…

- **(A)** confuses the cause of visitation with its effect.
- **(B)** treats a necessary condition as sufficient.
- **(C)** assumes that what is true of a whole must be true of each of its parts.
- **(D)** infers that a claim is false because it has not been proven.
- **(E)** generalizes about all visitors from a group of respondents who may not be representative of them.

::::solution[Solution]
**(E).** Sampling flaw — website-survey respondents (self-selected, online) may differ from park visitors generally.
::::
:::

:::problem[8]{difficulty="challenge"}
"Light beer is light, and light things float, so light beer floats." Flawed because it…

- **(A)** relies on a term that is used in two different senses.
- **(B)** overlooks an alternative explanation.
- **(C)** presents two alternatives as though they were the only ones available.
- **(D)** draws a general conclusion from too few instances.
- **(E)** mistakes a correlation for a cause.

::::solution[Solution]
**(A).** Equivocation on "light" — low-calorie vs. low-density. The senses don't connect.
::::
:::

:::problem[9]{difficulty="challenge"}
"Countries with higher chocolate consumption have more Nobel laureates. So eating chocolate boosts a nation's intellectual achievement." Flawed because it…

- **(A)** assumes what is true of a group is true of each member.
- **(B)** fails to consider that a third factor, such as national wealth, could account for both.
- **(C)** uses as a premise a restatement of the very claim it concludes.
- **(D)** treats a sufficient condition as necessary.
- **(E)** rejects a claim by attacking its source.

::::solution[Solution]
**(B).** Overlooks a common cause (wealth drives both chocolate consumption and research funding). Note (A) is tempting but describes division, which isn't the error here.
::::
:::

:::problem[10]{difficulty="challenge"}
"No study has shown this supplement to be unsafe, so it must be safe." Flawed because it…

- **(A)** confuses a part with the whole.
- **(B)** mistakes a correlation between two things for a causal link.
- **(C)** treats the absence of evidence against a claim as evidence for it.
- **(D)** relies on an unrepresentative sample.
- **(E)** presumes the point it sets out to prove.

::::solution[Solution]
**(C).** Appeal to ignorance — "not shown unsafe" treated as "shown safe."
::::
:::

:::problem[11]{difficulty="challenge"}
"Our top-performing salesperson skips morning meetings. So skipping morning meetings improves sales performance." Two answer choices tempt you: (X) "mistakes a correlation for causation" and (Y) "draws a general conclusion from a single, possibly atypical case." Which is better and why?

::::solution[Solution]
**(Y)** is the strongest single description here: the argument generalizes from *one* salesperson (a single, likely atypical case). (X) is also arguably present (correlation→cause), but the more precise and defensible defect is the leap from one exceptional individual to a general rule. When two real flaws seem present, pick the one that most directly captures the argument's central overreach — here, generalizing from n = 1. (On the real test the choices are worded so only one cleanly fits.)
::::
:::

:::problem[12]{difficulty="challenge"}
"The committee's proposal can't be sound — after all, half its members have no formal training in economics." Identify the flaw and explain in one line why a choice reading "treats a necessary condition as sufficient" would be a trap.

::::solution[Solution]
Flaw: **ad hominem** (rejecting the proposal by attacking the members' credentials rather than the proposal's reasoning). The "necessary/sufficient" choice is a trap because it describes a *real* flaw the argument simply didn't commit — there's no conditional being mis-handled here; the defect is attacking people, not confusing conditions.
::::
:::

## Chapter summary

:::summary
#### Flaw questions, distilled

- **Pre-phrase the flaw** in plain English before reading choices — Chapter 6's catalog is your vocabulary.
- **Match, don't just recognize.** Four wrong answers describe real errors the argument *didn't* make. Ask "did this argument actually do this?"
- **Translate the abstraction.** LSAT flaw answers are lawyerly; convert each to a plain flaw name, then match plain-to-plain.
- **Mind the direction.** "Necessary treated as sufficient" ≠ its reverse; read described errors precisely.
- **Pin it to the text.** The credited answer corresponds to a specific move the argument made.
:::

| Step | Action |
| --- | --- |
| 1 | Find conclusion & gap (Ch 4) |
| 2 | Name the flaw yourself (Ch 6 catalog) |
| 3 | Translate each choice to plain English |
| 4 | Match your name to a choice; verify the argument commits it |

LSAT Mastery — Chapter 9. Independent study material, not affiliated with LSAC. Practice questions are original, written to illustrate the reasoning patterns; use official LSAC PrepTests for timed practice.
