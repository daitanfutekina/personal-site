---
title: "Practice Test 7"
source: "markdown"
---

Part VI · Chapter 34

# Practice Test 7

Original full-length scored-section practice in contract analysis, neuroscience, architectural conservation, sociolinguistics, and varied Logical Reasoning scenarios.

## Overview

Take Sections I, II, and III in one sitting, **35 minutes per section**, with a **10-minute break after Section II**. This chapter simulates only the three scored sections; the actual LSAT also includes an unscored experimental section (Chapter 2). Use a timer and do not open any solution or scoring box until you have finished all three sections.

**Flag, don’t guess silently.** Write down each question you are uncertain about, including questions you guess correctly. After finishing the timed test, return to those questions without a timer for blind review (Chapter 22). Only then check the key, analyze the tempting wrong answers, and log each miss or shaky correct guess (Chapter 23).

This is an **original practice test for this book, not an official LSAC PrepTest**. Official PrepTests on LawHub remain the gold standard for timed practice (Chapter 24). Named institutions, datasets, rules, examples, and experiments in the LR section are fictional reasoning scenarios unless indicated otherwise; they do not purport to report actual cases or studies.

## 34.1 Section I: Logical Reasoning

:::problem[Question I.1]
At Briar College, introductory chemistry students who visited the voluntary tutoring room withdrew from the course less often than students who did not. The dean argues that expanding the room's hours will reduce withdrawals next semester. A faculty member objects that motivated students might be more likely both to seek tutoring and to remain enrolled. The dean acknowledges this possibility but maintains that the observed relationship is a reason to expand access. The college has enough tutors to staff the additional hours without reducing existing services.

Which one of the following, if true, most strengthens the dean’s argument?

- **(A)** The dean hopes to publicize the expansion in admissions materials.
- **(B)** Students using tutoring report that the room is pleasant.
- **(C)** Tutoring-room visitors usually spent longer in the library than nonvisitors.
- **(D)** Students randomly offered additional tutoring appointments withdrew less often than otherwise similar students who were not offered them.
- **(E)** The chemistry course is harder than most other introductory courses.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Expanding tutoring hours should reduce chemistry withdrawals.
2. **Support.** Lower withdrawal rates among voluntary users may reflect selection.
3. **Prephrase.** Look for a controlled comparison that separates tutoring access from prior motivation.
4. **Why (D) is right.** Random assignment sharply reduces the self-selection alternative; it supplies independent evidence that access can change withdrawals rather than merely track motivation.
5. **Why the others fail.
   - **(A)** Motive trap: publicity plans do not establish an effect on persistence.
   - **(B)** Half-right trap: satisfaction is not evidence that withdrawals decline.
   - **(C)** Common-cause trap: library time may also reflect motivation, not a tutoring effect.
   - **(E)** Wrong comparison: relative course difficulty does not show that tutoring changes withdrawal.

**Check:** The randomized comparison supports an effect; the four alternatives leave self-selection intact.
::::
:::

:::problem[Question I.2]
A track coach reports that runners who completed the team’s optional sprint-technique workshop had fewer hamstring injuries last season than runners who skipped it. The coach concludes that the workshop prevented injuries and insists that every runner should be required to attend next year. But workshop attendance was optional, and runners recovering from injuries at the season’s start were discouraged from participating. The coach does not discuss that restriction when comparing the groups. The proposed requirement would apply to all runners, including those initially excluded.

The argument is most vulnerable to criticism on the grounds that it…

- **(A)** treats a necessary condition for recovery as sufficient for preventing injury.
- **(B)** assumes that any policy benefiting some runners must benefit every runner equally.
- **(C)** rejects all injury reports collected by the runners themselves.
- **(D)** overlooks a preexisting difference between the groups that could account for the injury rates.
- **(E)** uses a conclusion about training to support a conclusion about nutrition.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The workshop prevented injuries, so attendance should be mandatory.
2. **Support.** Attendees had fewer injuries but were selected for having no current injury limitation.
3. **Prephrase.** Name the selection bias that creates an alternative explanation.
4. **Why (D) is right.** The workshop group began with fewer injured or recovering athletes, so the comparison is confounded before any instruction occurs.
5. **Why the others fail.
   - **(A)** Wrong flaw family: no recovery-to-prevention conditional appears.
   - **(B)** Too broad: equal-sized benefit is not claimed; the flaw arises before the universal policy.
   - **(C)** Invented conduct: the coach does not reject self-reports.
   - **(E)** Wrong subject trap: the coach draws a conclusion about injury prevention and workshop attendance, without mentioning nutrition or a diet intervention.

**Check:** Already-injured athletes were disproportionately in the nonattendee group; that alone could produce the difference.
::::
:::

:::problem[Question I.3]
A university library has established three rules for lending rare maps. Every map that may leave the archive has already been digitized. No map requiring climate-controlled handling may leave the archive. Some maps donated by the Merrin estate may leave the archive, although the archivist has not said whether those particular maps require conservation work. Each map, whether lendable or not, must have a catalog record. The rules govern the status of individual maps, not necessarily entire donations as collections.

Which one of the following must be true?

- **(A)** No digitized map requires climate-controlled handling.
- **(B)** Every Merrin map may leave the archive.
- **(C)** Every map needing conservation work must remain in the archive.
- **(D)** At least one Merrin map requires climate-controlled handling.
- **(E)** At least one map from the Merrin estate has been digitized.

::::solution[Solution]
**Answer:** (E)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** Identify the necessarily true intersection of the donation and digitization categories.
2. **Support.** Some Merrin maps are lendable; all lendable maps are digitized.
3. **Prephrase.** Chain some Merrin → lendable → digitized.
4. **Why (E) is right.** Some Merrin maps may leave; every map that may leave is digitized. Combining the existential and universal claims guarantees at least one digitized Merrin map.
5. **Why the others fail.
   - **(A)** Converse trap: digitized maps can still be nonlendable.
   - **(B)** Quantifier reversal: some lendable maps does not mean all are lendable.
   - **(C)** New restriction: conservation work was never equated with climate handling.
   - **(D)** Unsupported existence: the rules do not establish such a map.

**Check:** A witness map that is Merrin and lendable must also be digitized.
::::
:::

:::problem[Question I.4]
A property manager proposes replacing the office’s current telephone hotline with an online maintenance portal. In a pilot building, tenants submitting repair requests through the portal received a first response sooner than tenants calling the hotline. The manager concludes that replacing the hotline throughout the company will reduce the time tenants wait for a first response. The pilot used a separate employee to monitor the portal, whereas the proposed companywide portal would be handled by the same employees who presently answer calls.

Which one of the following is an assumption on which the manager’s argument depends?

- **(A)** A telephone hotline is more expensive to operate than an online portal.
- **(B)** The company will completely eliminate all maintenance delays.
- **(C)** The pilot building contains more apartments than any other building.
- **(D)** Every tenant prefers entering requests online to making telephone calls.
- **(E)** The staffing change accompanying the companywide rollout will not eliminate the response-time advantage observed in the pilot.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Companywide portal replacement will shorten first-response waits.
2. **Support.** The pilot’s portal was faster but had dedicated staffing unavailable during rollout.
3. **Prephrase.** A necessary bridge must rule out the rollout change wiping out the observed advantage.
4. **Why (E) is right.** If shared staffing destroys that advantage, the pilot cannot support the proposed systemwide reduction; the argument depends on the advantage surviving this relevant change.
5. **Why the others fail.
   - **(A)** Other metric: operating cost is not the cited benefit.
   - **(B)** Extreme outcome: the conclusion concerns first response, not repair completion.
   - **(C)** Wrong comparison: building rank is irrelevant to transfer of performance.
   - **(D)** Too strong: preference is unnecessary to a claim about response times.

**Check:** Negate the answer: shared staffing erases the advantage; the pilot no longer supports the rollout prediction.
::::
:::

:::problem[Question I.5]
A bookseller argues: “We should stop accepting unlimited preorders for imported editions. When an edition arrives late, customers frequently ask us to hold stock beyond the promised pickup date. Those holds occupy the small shelf reserved for new releases, leaving less space for books that walk-in customers are ready to purchase. Capping preorders would not eliminate special orders; customers could still request a copy once the first shipment arrives. We ought to preserve the shop’s ability to display its new stock rather than promise shelf space to an unlimited number of advance orders.”

Which one of the following most accurately expresses the argument’s main conclusion?

- **(A)** The shop’s shelf reserved for new releases is comparatively small.
- **(B)** Delayed deliveries sometimes cause customers to request longer holds.
- **(C)** The bookstore should impose a limit on preorders for imported editions.
- **(D)** Special orders should be prohibited until every new release sells.
- **(E)** New releases generate more revenue than imported editions.

::::solution[Solution]
**Answer:** (C)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** Limit imported-edition preorders.
2. **Support.** Late arrivals and long holds crowd out sellable display space; limited special orders remain possible.
3. **Prephrase.** Distinguish what the speaker recommends from reasons offered for it.
4. **Why (C) is right.** The inventory-space evidence and proposed alternative are reasons for the policy recommendation stated at the beginning and reaffirmed at the end.
5. **Why the others fail.
   - **(A)** Background premise: capacity is a reason, not the advocated decision.
   - **(B)** Premise trap: this supports the recommendation but is not it.
   - **(D)** Overstatement: the speaker explicitly preserves special orders.
   - **(E)** Invented comparison: no revenue totals are supplied.

**Check:** The other statements are premises, unsupported assertions, or stronger policies than advocated.
::::
:::

:::problem[Question I.6]
A wildlife volunteer proposes installing striped decals on every window of the municipal aviary. During a two-week trial, staff observed fewer bird collisions at windows with decals than at windows without them. The volunteer attributes the entire difference to the stripes and predicts similarly reduced collisions throughout the year. The trial took place while half the building was closed for renovations, and the volunteer’s notes show only the number of collisions, not the number of birds flying near each group of windows.

Which one of the following, if true, most seriously weakens the prediction?

- **(A)** The decal-covered windows faced a courtyard that was closed to birds during most of the trial.
- **(B)** The aviary also sells bird guidebooks to visitors.
- **(C)** The striped design can be printed in several colors.
- **(D)** Some decals were installed by volunteers rather than employees.
- **(E)** The renovation was finished after the trial ended.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Decals caused the lower collision count and will reduce collisions broadly.
2. **Support.** The trial lacks standardized exposure counts and occurred during renovations.
3. **Prephrase.** Find a concrete reason the treated windows were less exposed to birds.
4. **Why (A) is right.** This supplies a direct exposure difference: fewer collisions may reflect fewer opportunities to collide, not better visibility of the glass.
5. **Why the others fail.
   - **(B)** Out of scope: retail activity has no bearing on collision rates.
   - **(C)** Appearance trap: available colors do not explain the recorded difference.
   - **(D)** Irrelevant implementation: installer identity does not account for counts.
   - **(E)** Timing alone is not fatal unless renovation changed exposure across groups.

**Check:** With little bird traffic, collision counts would be low even if decals had no effect.
::::
:::

:::problem[Question I.7]
The principal claims that the school orchestra should rehearse immediately after classes instead of before school. She notes that many bus riders arrive too late to attend the current morning rehearsal. The music teacher replies: “A later rehearsal would indeed allow most bus riders to attend. Yet the gym will be occupied then, and the orchestra room is too small for the full ensemble. Unless another suitable room becomes available, moving the rehearsal would increase attendance at the cost of making full rehearsals impossible.” The teacher has not proposed canceling rehearsals.

In the music teacher’s argument, the statement that a later rehearsal would allow most bus riders to attend serves which one of the following roles?

- **(A)** It challenges the principal’s claim about bus arrival times.
- **(B)** It concedes a benefit of the proposed change before identifying a competing obstacle.
- **(C)** It is the conclusion the teacher ultimately seeks to establish.
- **(D)** It states a rule governing which students may join the orchestra.
- **(E)** It is evidence that the current rehearsal space is large enough.

::::solution[Solution]
**Answer:** (B)

**Type:** Role (Chapter 11)

1. **Conclusion.** The proposed move is impractical without another room.
2. **Support.** The bus-rider benefit is conceded; a room-capacity problem is then introduced.
3. **Prephrase.** Label the sentence a concession, not the ultimate position.
4. **Why (B) is right.** The teacher accepts the principal’s attendance premise but argues that room capacity defeats the proposed schedule under current conditions.
5. **Why the others fail.
   - **(A)** Opposite: the teacher explicitly accepts the attendance benefit.
   - **(C)** Role reversal: the teacher’s point concerns inability to rehearse as a full ensemble.
   - **(D)** Unsupported policy: no membership rule is introduced.
   - **(E)** Wrong inference: attendance has no bearing on room capacity.

**Check:** Removing the conceded benefit would not remove the room problem driving the objection.
::::
:::

:::problem[Question I.8]
A volunteer sports league adopted this rule: whenever a player is declared ineligible because of a document that the league itself misplaced, the league must provisionally allow the player to compete while it searches for the document, provided there is no independent indication that the player is ineligible. The league misplaced Mara’s age-verification form, and another committee member asks whether to bench her until the document turns up. The committee has checked its remaining records and found no independent indication of ineligibility.

Which one of the following actions most closely conforms to the league’s stated principle?

- **(A)** Let Mara compete provisionally while staff search for the misplaced form.
- **(B)** Declare Mara permanently eligible because one record was misplaced.
- **(C)** Let every player with any missing document compete, regardless of cause.
- **(D)** Cancel all games until every eligibility record has been located.
- **(E)** Bench Mara until she personally supplies another form.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Apply the eligibility rule to Mara.
2. **Support.** League misplaced the record and independent checking found no eligibility concern.
3. **Prephrase.** Permit temporary play, not unrestricted or permanent eligibility.
4. **Why (A) is right.** The league caused the missing-document problem and has no separate evidence against eligibility, so both conditions for provisional participation hold.
5. **Why the others fail.
   - **(B)** Overreach: provisional participation is not a final eligibility finding.
   - **(C)** Too broad: the rule applies to league-misplaced documents absent independent concerns.
   - **(D)** Wrong remedy: the principle supplies a narrow interim action.
   - **(E)** Opposes the rule: it shifts the league-caused burden to the player.

**Check:** Both stipulated conditions are met; the recommended action matches the rule’s exact scope.
::::
:::

:::problem[Question I.9]
A real-estate columnist notes that, in a survey of apartments renovated last year, units receiving new kitchens sold for more money on average than units whose kitchens were left unchanged. The columnist concludes that a new kitchen increases an apartment’s sale price by at least the entire average difference between the groups. Yet the survey did not record initial property values, square footage, or location within the city. The apartments with renovated kitchens could have been more valuable properties before any work began.

The reasoning is flawed because it…

- **(A)** assumes that apartment sale prices cannot fall after any renovation.
- **(B)** reasons from the price of one apartment to the prices of all apartments.
- **(C)** fails to prove that every prospective buyer likes new kitchens.
- **(D)** attributes a difference between groups to renovation without establishing that the groups were otherwise comparable.
- **(E)** treats a condition sufficient for a sale as necessary for a sale.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** A new kitchen raises price by at least the average group difference.
2. **Support.** Only post-sale averages are compared; major baseline differences are unmeasured.
3. **Prephrase.** Identify the uncontrolled comparison and implausible attribution of the whole difference.
4. **Why (D) is right.** Existing value and location may account for the price difference, so the full gap cannot be credited to kitchen renovations.
5. **Why the others fail.
   - **(A)** Too specific: the argument estimates an increase but never claims prices cannot fall.
   - **(B)** Wrong sample description: the data compare groups, not a single case.
   - **(C)** Extreme trap: universal tastes are unnecessary to an average price effect.
   - **(E)** Wrong logical form: no conditional rule about selling appears.

**Check:** The groups may have different baseline values even if renovation has no effect.
::::
:::

:::problem[Question I.10]
An editor follows two established rules. Every article that receives the magazine’s “field-report” label has been independently fact-checked. Every independently fact-checked article is eligible for consideration for the annual print anthology. A new piece by Sora has been assigned to the field-report desk, but the editor has not yet confirmed whether that assignment leads to the official label. The editor nevertheless concludes that Sora’s piece is eligible for anthology consideration. No other eligibility route is described.

The conclusion follows logically if which one of the following is assumed?

- **(A)** Sora has previously written an article for the anthology.
- **(B)** The fact-checking desk reviews articles only after they are published.
- **(C)** Some eligible anthology pieces were never assigned to the field-report desk.
- **(D)** Every piece assigned to the field-report desk receives the field-report label.
- **(E)** Every field-report article is considered for the anthology rather than merely eligible.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Sora’s new piece is eligible.
2. **Support.** Label → fact-checked → eligible, but assignment has not been linked to label.
3. **Prephrase.** Supply assignment → labeled to form an unbroken conditional chain.
4. **Why (D) is right.** Adding desk assignment → official label completes the chain: assigned → label → fact-checked → eligible.
5. **Why the others fail.
   - **(A)** Biographical substitution: prior success does not establish this piece’s eligibility.
   - **(B)** Timing trap: this does not show the new piece has been checked.
   - **(C)** Wrong direction: alternative eligibility routes say nothing about Sora.
   - **(E)** Missing bridge: the stated conclusion still needs assignment linked to the label.

**Check:** Plug in the new rule: Sora assigned; therefore labeled, checked, and eligible.
::::
:::

:::problem[Question I.11]
A regional museum extended its Thursday closing time from six to nine in the evening to attract people who work during the day. Surveys taken before the change suggested considerable interest in late visits. Yet the first six Thursdays after the extension brought fewer total visitors per Thursday than comparable Thursdays the previous month, even though the museum did not raise admission prices and offered the same exhibitions. The director is puzzled because staff reliably counted visitors at every entrance on both schedules.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** To fund evening staffing, the museum began opening three hours later on Thursdays, losing a popular school-group period.
- **(B)** A few survey respondents preferred late Friday visits.
- **(C)** The director previously worked for a different museum.
- **(D)** The museum’s Saturday hours stayed unchanged.
- **(E)** The same exhibitions were discussed in the local newspaper.

::::solution[Solution]
**Answer:** (A)

**Type:** Paradox (Chapter 13)

1. **Conclusion.** Reconcile greater stated interest in later hours with fewer overall Thursday visits.
2. **Support.** Evening extension occurred, prices and exhibitions did not change, counts are credible.
3. **Prephrase.** Look for an offsetting loss of visits in a different time window.
4. **Why (A) is right.** The longer evening availability was offset by reduced morning access; losing many school visits can reduce total attendance despite new evening visitors.
5. **Why the others fail.
   - **(B)** Insufficient and wrong day: a few preferences do not explain the decrease.
   - **(C)** Personal-history distraction: not an attendance mechanism.
   - **(D)** Other-day trap: Saturdays do not reconcile Thursday totals.
   - **(E)** Background publicity without a direction of effect.

**Check:** Later opening removes an existing high-volume school window while adding evening access.
::::
:::

:::problem[Question I.12]
A soccer trainer claims that a short visual-cue drill improves goalkeepers’ ability to choose the correct direction before a penalty kick. In an informal demonstration, keepers who practiced the drill made more correct initial movements than keepers who did not. Skeptics note that the groups contained different players and that experienced keepers volunteered for the drill more often. The trainer proposes including the drill in the academy’s next training cycle, arguing that the demonstration points toward a useful effect.

Which one of the following, if true, most supports the trainer’s causal claim?

- **(A)** The volunteer drill group liked the trainer’s presentation style.
- **(B)** The same keepers performed more accurately on unfamiliar simulated kicks after the drill than before it, while a matched group without the drill did not improve.
- **(C)** Experienced keepers were more likely to volunteer than novices.
- **(D)** Keepers in both groups wore the same color jerseys.
- **(E)** The academy routinely changes its penalty-kick curriculum.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The cue drill improves directional decisions.
2. **Support.** Initial comparison may reflect expertise selection.
3. **Prephrase.** Seek matched or within-person evidence of improvement specific to the drill.
4. **Why (B) is right.** The before/after comparison with a matched control isolates improvement attributable to the drill and reduces experience and volunteer-selection objections.
5. **Why the others fail.
   - **(A)** Satisfaction is not accuracy or causal evidence.
   - **(C)** This amplifies, rather than answers, the selection concern.
   - **(D)** Irrelevant control: jersey color does not address skill imbalance.
   - **(E)** Practice-policy background gives no evidence of improvement.

**Check:** Change in a treatment group without corresponding control change supports the proposed cause.
::::
:::

:::problem[Question I.13]
A council member says: “Critics claim the proposed online comment form will silence older residents because some do not use computers. But the proposal does not replace in-person testimony; residents will still be able to speak at every meeting. Adding another channel therefore cannot, by itself, remove the existing route for older residents to be heard. The proposal may have other defects, but the particular objection that it abolishes in-person participation rests on a false description of what we proposed.”

The council member’s argument proceeds primarily by…

- **(A)** deducing that any added communication channel will increase turnout.
- **(B)** appealing to the popularity of online comment forms in other towns.
- **(C)** arguing that the benefits of the form outweigh every possible disadvantage.
- **(D)** challenging an objection by identifying a mistaken factual premise on which the objection depends.
- **(E)** showing that all older residents are comfortable using computers.

::::solution[Solution]
**Answer:** (D)

**Type:** Method (Chapter 11)

1. **Conclusion.** The specific silencing objection misdescribes the proposal.
2. **Support.** In-person testimony remains available even after the new channel is added.
3. **Prephrase.** Identify a targeted rebuttal of a premise, not a blanket defense.
4. **Why (D) is right.** The speaker does not prove the form is universally beneficial; the attack is limited to the allegation that existing testimony is eliminated.
5. **Why the others fail.
   - **(A)** Stronger inference: no turnout prediction is made.
   - **(B)** Invented method: no popularity evidence appears.
   - **(C)** Too broad: other defects are explicitly left open.
   - **(E)** Unsupported generalization: the speaker concedes some may not be.

**Check:** The speaker’s concession about other defects confirms the deliberately narrow method.
::::
:::

:::problem[Question I.14]
A publishing consultant notes that every novel on a particular independent press’s bestseller list had received a favorable review from the press’s own newsletter before launch. The consultant concludes that newsletter praise is enough to make any novel a bestseller and recommends writing enthusiastic reviews of all forthcoming titles. The newsletter also reviewed many books that never appeared on the bestseller list, but the consultant has not examined those cases. The press’s list includes only a small number of titles each year.

The argument is most vulnerable to criticism on the grounds that it…

- **(A)** compares the same title’s sales in two different years.
- **(B)** assumes that all books on the list are novels.
- **(C)** confuses a feature shared by all bestsellers with a condition sufficient to create a bestseller.
- **(D)** presumes that the newsletter has no readers outside the publishing company.
- **(E)** argues that favorable reviews must lower demand for books.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Praise is sufficient to generate bestseller status.
2. **Support.** All bestsellers received praise, but many praised titles did not become bestsellers.
3. **Prephrase.** Diagram bestseller → praise; spot the mistaken reversal.
4. **Why (C) is right.** Bestseller → praised does not imply praised → bestseller. The many praised nonbestsellers directly expose the invalid converse.
5. **Why the others fail.
   - **(A)** Wrong comparison: no longitudinal sales comparison is used.
   - **(B)** Irrelevant categorization: the causal-to-sufficient leap remains either way.
   - **(D)** Invented premise: reach is not the identified conditional error.
   - **(E)** Opposite conclusion: the consultant expects an increase.

**Check:** A praised nonbestseller is a direct counterexample to praise → bestseller.
::::
:::

:::problem[Question I.15]
At an experimental middle school, each class that used a teacher microphone reported fewer requests to repeat instructions during the trial week than during the previous week. Teachers did not report whether they changed the wording or length of instructions. In two classes where students were already seated close to the teacher, there was almost no change. School staff also noted that microphone use was voluntary and that some teachers tested it only for certain activities. The study was not designed to measure academic achievement.

Which one of the following is most strongly supported by the information above?

- **(A)** Every classroom should replace its sound system with a microphone.
- **(B)** The microphone arrangement may have been more useful for some classroom configurations than for others.
- **(C)** Microphone use improved examination scores during the trial.
- **(D)** Microphones caused the improvement in each participating class.
- **(E)** Students seated near the teacher cannot benefit from microphones.

::::solution[Solution]
**Answer:** (B)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Find the modest inference supported by the varied classroom patterns.
2. **Support.** Repeat requests changed unevenly; seating and instructional differences were uncontrolled.
3. **Prephrase.** Prefer a qualified claim about varying usefulness over causation or unmeasured outcomes.
4. **Why (B) is right.** Different observed changes between near-seated classes and other classes support a cautious possibility of context-dependent usefulness, not a universal causal conclusion.
5. **Why the others fail.
   - **(A)** Policy overreach: no comparison of alternatives is offered.
   - **(C)** Unmeasured outcome: achievement was not tested.
   - **(D)** Causal overreach: instruction changes and selective use were uncontrolled.
   - **(E)** Absolute inference: almost no observed change is not impossibility.

**Check:** The answer says may and some contexts; the other choices assert evidence not present.
::::
:::

:::problem[Question I.16]
A neighborhood bird sanctuary has announced that a sponsor will match individual donations made after an upcoming fundraiser, up to a fixed ceiling. The director predicts that the sanctuary will receive some money from the sponsor for next spring’s nesting-platform repairs. According to the written pledge, the sponsor will contribute nothing unless at least one individual makes a qualifying gift after the fundraiser announcement; it is not an unconditional donation. The director expects generous participation because last year’s repair appeal attracted many donors, but has not yet received any qualifying gifts under the new pledge.

The director’s reasoning depends on assuming which one of the following?

- **(A)** The sponsor has never funded a conservation project before.
- **(B)** At least one individual will make a qualifying donation after the announcement.
- **(C)** Every donor will contribute the maximum amount the sponsor will match.
- **(D)** Nesting platforms are the sanctuary’s only maintenance expense.
- **(E)** Residents will stop supporting other community organizations.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The sanctuary will receive some sponsor money.
2. **Support.** The sponsor pays only if a qualifying donor contributes; no qualifying gifts have yet arrived.
3. **Prephrase.** Identify the event necessary to trigger any sponsor money.
4. **Why (B) is right.** Without a qualifying gift, the sponsor must pay nothing under the stated terms, defeating the prediction of any sponsor funds.
5. **Why the others fail.
   - **(A)** Background: prior sponsorship is irrelevant to this pledge’s conditional payment.
   - **(C)** Too strong: a total increase requires neither universal nor maximum giving.
   - **(D)** Wrong budget scope: the prediction concerns cash for one repair fund.
   - **(E)** Out of scope: gifts to unrelated charities need not cease.

**Check:** Negate: no qualifying donor gives after the announcement. Under the pledge, sponsor payment is exactly zero.
::::
:::

:::problem[Question I.17]
Every vendor permitted to sell plants at the city garden fair must complete safety training. Every vendor who completes safety training receives a badge. Every cooperative member who will sell plants at the fair has obtained an individual permit to sell there. Therefore, every member of the cooperative who is vending at the fair will have a badge. The conclusion concerns only cooperative members who are vendors at the fair, not every cooperative member regardless of participation.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Most trained runners wear trackers, and most trackers are expensive; therefore most runners buy expensive trackers.
- **(B)** All licensed ushers receive orientation, and everyone receiving orientation gets an ID. Each theater-club member serving as a licensed usher therefore gets an ID.
- **(C)** No archived map is displayed, and this map is displayed; therefore this map is not archived.
- **(D)** Every chef wears an apron; therefore every apron wearer is a chef.
- **(E)** All award-winning poems were edited, and the poem was edited; therefore it won an award.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Cooperative vendors have badges.
2. **Support.** Vendor permission → safety training → badge.
3. **Prephrase.** Find two linked universal rules applied to an identified subset.
4. **Why (B) is right.** Both arguments chain necessary conditions from a subset of participants to a resulting status: authorized role → training/orientation → badge/ID.
5. **Why the others fail.
   - **(A)** Quantifier trap: two most-statements do not yield the conclusion.
   - **(C)** Valid contrapositive but not the two-step positive chain in the stimulus.
   - **(D)** Invalid reversal trap: chef → apron does not allow the reverse implication apron → chef, unlike the valid two-link forward chain in the stimulus.
   - **(E)** Converse fallacy: editing is treated as sufficient rather than necessary.

**Check:** The matching choice preserves the two-arrow transitive inference.
::::
:::

:::problem[Question I.18]
A real-estate agent claims that scheduling Sunday open houses rather than Saturday ones will produce more offers. In the agency’s records, Sunday events drew more visitors per event and were followed by more offers per listing. The agent therefore urges the office to switch all open houses to Sundays. However, sellers chose their own days, and properties with extensive staging and professional photographs were especially likely to be listed for Sunday events. The agent treats the schedule difference as the decisive factor.

Which one of the following, if true, most weakens the agent’s reasoning?

- **(A)** Some people prefer touring homes in the morning.
- **(B)** Sunday events required slightly more staff time.
- **(C)** The office’s busiest month contained more Sundays than some months.
- **(D)** The agency photographs all listings before posting them.
- **(E)** When equally staged listings were randomly assigned to Saturday or Sunday, the two groups received similar numbers of offers.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Sunday scheduling itself increases offers.
2. **Support.** Sunday listings also tend to have stronger staging and photography.
3. **Prephrase.** Find controlled evidence undermining the claimed day effect.
4. **Why (E) is right.** An experimental comparison holding presentation quality comparable fails to reproduce the proposed Sunday advantage.
5. **Why the others fail.
   - **(A)** Vague preference: does not compare Saturdays and Sundays on offers.
   - **(B)** Different metric: staffing cost does not show offers will be unchanged.
   - **(C)** Calendar distraction: month composition does not isolate day-of-week causation.
   - **(D)** Half-right: having photographs says nothing about quality differences.

**Check:** Equal offer outcomes under random day assignment undermine Sunday as cause.
::::
:::

:::problem[Question I.19]
Coach Anika: “A judging rubric should reserve a separate category for whether speakers acknowledge a serious objection. Without that category, a polished but one-sided presentation can receive top marks.” Coach Bram: “Acknowledging objections is valuable, but a separate category will not help. Judges already reward good answers to objections under the existing reasoning category, and the rubric should remain compact.” Both coaches want judges to notice substantive reasoning rather than surface confidence. They disagree about the design of the rubric, not whether objections have any value.

On which one of the following points do Anika and Bram most clearly disagree?

- **(A)** Whether every polished speech is one-sided.
- **(B)** Whether responding to serious objections can ever be valuable.
- **(C)** Whether debate tournaments should abolish judging rubrics.
- **(D)** Whether judges currently give more weight to confidence than reasoning.
- **(E)** Whether creating a distinct rubric category for handling objections would improve the judging process.

::::solution[Solution]
**Answer:** (E)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** The dispute concerns a separate objection-handling category.
2. **Support.** One endorses it; the other opposes its usefulness.
3. **Prephrase.** Apply the two-speaker yes/no test to the same policy.
4. **Why (E) is right.** Anika advocates a separate category; Bram explicitly says it will not help. Both have determinate opposite positions.
5. **Why the others fail.
   - **(A)** Straw man: Anika says a speech can be polished and one-sided.
   - **(B)** False disagreement: both explicitly regard it as valuable.
   - **(C)** Extreme scope: neither coach favors abolition.
   - **(D)** Unestablished on both sides: no quantitative ranking is supplied.

**Check:** Anika yes, Bram no; the other options lack opposed positions.
::::
:::

:::problem[Question I.20]
A birder surveyed species at one reed-filled pond every dawn for five mornings and detected no marsh terns. She concludes that marsh terns are absent from the entire county this year. Her colleague notes that the county includes shoreline and open-water sites the survey did not reach, and that dawn at the pond is only one of several possible observation periods. The birder responds that the pond is easy to reach and that she followed the same method on each visit. She takes methodological consistency to justify countywide completeness.

The argument is most vulnerable to criticism on the grounds that it…

- **(A)** infers that marsh terns prefer shoreline habitat to ponds.
- **(B)** treats absence from the county as a prerequisite for absence from a pond.
- **(C)** generalizes from observations at a narrow set of sites and times to a much larger population of locations and times.
- **(D)** claims that species counts cannot vary from morning to morning.
- **(E)** relies on an attack on the colleague’s character instead of evidence.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Terns are absent from the county.
2. **Support.** No sightings at one pond during five dawn surveys.
3. **Prephrase.** Spot unrepresentative spatial and temporal sampling.
4. **Why (C) is right.** Consistent sampling does not establish representativeness. An undetected species at one pond need not be absent countywide.
5. **Why the others fail.
   - **(A)** Unmade ecological claim: habitat preference is not concluded.
   - **(B)** Wrong direction: the conclusion is county absence from pond observations.
   - **(D)** Overstatement: regular method does not assert identical counts.
   - **(E)** Invented ad hominem: the birder discusses the method, not the colleague.

**Check:** Another location or time could contain a tern without contradicting the survey.
::::
:::

:::problem[Question I.21]
A small newspaper adopts the following editorial standard: if the paper publishes a factual claim that its own records already contradict, it must issue a visible correction, even if the error appeared only in an online preview. An editor learns that an advance article described an interview as occurring on Tuesday, although the paper’s dated recording shows it occurred on Wednesday. Before print distribution, the editor corrects the date in the article but considers leaving the online preview untouched because few people saw it.

Which one of the following judgments is most strongly justified by the newspaper’s standard?

- **(A)** The paper must correct all subjective disagreements between interviewers and sources.
- **(B)** No correction is necessary because the print edition is not yet distributed.
- **(C)** The editor should visibly correct the online preview as well as changing the version prepared for print.
- **(D)** The editor should discipline the interview subject for the date error.
- **(E)** The interview should be deleted from every newspaper archive.

::::solution[Solution]
**Answer:** (C)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The online date requires a visible correction.
2. **Support.** A dated internal recording contradicts the advance article, which was published online.
3. **Prephrase.** Apply the own-records contradiction trigger even to previews.
4. **Why (C) is right.** The paper’s own dated record contradicts a published factual claim, and the rule explicitly covers online previews.
5. **Why the others fail.
   - **(A)** Overgeneralization: the standard addresses contradicted factual claims.
   - **(B)** Express-exception trap: the written standard explicitly requires corrections even for factual errors appearing only in online previews.
   - **(D)** Wrong actor: the newspaper’s publication duty does not assign blame to the subject.
   - **(E)** Wrong remedy: the standard requires correction, not erasure.

**Check:** Both conditions, a factual conflict and publication in a preview, are met.
::::
:::

:::problem[Question I.22]
A landlord says tenants will miss fewer mandatory inspections if the building switches from paper notices under doors to text-message notices. The landlord points out that most tenants carry a phone and that text messages arrive faster than paper notices are delivered by staff. The proposed system would stop distributing paper notices entirely. The landlord has not checked whether all tenants have agreed to receive building notices by text or whether the numbers on file are current.

The argument depends on assuming which one of the following?

- **(A)** At least some tenants who would miss an inspection under paper notices will receive a usable text notice in time to attend.
- **(B)** Paper notices can never be misplaced.
- **(C)** Every tenant reads each text within one minute.
- **(D)** The building will also shorten inspection appointments.
- **(E)** Inspections are unpleasant for all tenants.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Switching to text-only notices will reduce missed inspections.
2. **Support.** Texts are faster, but current contact details and tenant consent are uncertain.
3. **Prephrase.** The new method must reach at least some tenants whose inspections the paper method would otherwise miss.
4. **Why (A) is right.** A reduction in missed inspections by means of notice delivery requires at least one otherwise-missed inspection to be saved by the new communication channel.
5. **Why the others fail.
   - **(B)** Opposite irrelevant extreme: the argument does not require flawless paper.
   - **(C)** Too strong: instant reading by every tenant is unnecessary.
   - **(D)** Different policy: appointment duration is unrelated to notification success.
   - **(E)** Irrelevant preference: unpleasantness does not establish delivery effects.

**Check:** Negate: no otherwise-missed tenant gets a usable timely text. The claimed reduction through notification cannot occur.
::::
:::

:::problem[Question I.23]
A school superintendent argues that all schools with highly successful science fairs purchased new laboratory benches last year. Therefore, purchasing new benches this year will guarantee that North Academy holds a highly successful science fair. The superintendent supplies no evidence about schools that purchased benches but held mediocre fairs. The proposal might have other merits, but the superintendent’s stated guarantee is based entirely on what the successful schools happened to have done.

Which one of the following arguments contains the most similar flaw?

- **(A)** All acclaimed biographies published by this press had extensive indexes. Thus, adding an extensive index to our next biography ensures that it will be acclaimed.
- **(B)** No unregistered supplier may bid; Dax is registered, so Dax may bid.
- **(C)** If a building has a green roof, it receives a grant; this building has a green roof, so it receives a grant.
- **(D)** All orchestra members practice daily; Kim is a member, so Kim practices daily.
- **(E)** Most winning teams have coaches; this team has a coach, so it is likely to win.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** Purchasing benches guarantees success.
2. **Support.** Successful fairs had benches, but bench-owning unsuccessful fairs were unexamined.
3. **Prephrase.** Match all successful → feature, therefore feature → successful.
4. **Why (A) is right.** Both incorrectly reverse a necessary association: successful → feature is treated as feature → successful.
5. **Why the others fail.
   - **(B)** Different flaw: rejecting a prohibition’s antecedent rather than affirming its consequent.
   - **(C)** Valid-form trap: from green roof → grant and green roof it correctly infers grant; it never reverses the arrow.
   - **(D)** Valid-form trap: membership implies practicing, and Kim is a member; this correctly applies the given universal rather than reversing it.
   - **(E)** Related but shifts from all/guarantee to most/likely, changing logical force.

**Check:** The acclaimed-biography analogy repeats the exact invalid converse with universal force.
::::
:::

:::problem[Question I.24]
At a nonfiction publisher, a manuscript is placed on the autumn release schedule only if it has passed the legal review desk. Any manuscript placed on that schedule is announced to distributors. The editor knows that a history manuscript has passed legal review and asserts that it will therefore be announced to distributors. The editor also knows that some legally reviewed manuscripts are held for later seasons, but says this particular manuscript should be different. No other path to a distributor announcement is provided.

Which one of the following, if assumed, enables the editor’s conclusion to be properly drawn?

- **(A)** Every manuscript announced to distributors passed legal review.
- **(B)** All history manuscripts are eventually offered to bookstores.
- **(C)** This history manuscript will be placed on the autumn release schedule.
- **(D)** Some autumn-schedule manuscripts were submitted earlier than this one.
- **(E)** The legal review desk approved the manuscript unanimously.

::::solution[Solution]
**Answer:** (C)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The history manuscript will be announced.
2. **Support.** Autumn schedule → announcement; legal review is merely required for scheduling.
3. **Prephrase.** Provide the missing fact that this manuscript is actually scheduled.
4. **Why (C) is right.** Given scheduling → distributor announcement, stating that this manuscript is scheduled is sufficient. Legal-review approval alone is not.
5. **Why the others fail.
   - **(A)** Converse side condition: does not put this manuscript on the announcement list.
   - **(B)** Different and weaker outcome: eventual offers do not entail an autumn announcement.
   - **(D)** Irrelevant-comparison trap: another manuscript arriving earlier does not prove that this history manuscript has been assigned to the autumn schedule.
   - **(E)** More of the same necessary condition still does not imply scheduling.

**Check:** Scheduled → announced applies directly to the manuscript.
::::
:::

:::problem[Question I.25]
A school board is deciding whether to fund a reading-mentorship program. The pilot’s participants improved more on a reading assessment than nonparticipants, and the board chair says this proves that adding mentors caused the improvement. Families chose whether to enroll their children, however, and the program offered both individual mentoring and free take-home books. The chair proposes preserving both features in an expansion, but attributes the measured effect specifically to mentoring rather than to the books or differences among families.

The answer to which one of the following questions would be most useful in evaluating the chair’s attribution?

- **(A)** Did the library expand its adult-fiction collection last year?
- **(B)** Did the chair visit the pilot classroom before speaking to the board?
- **(C)** Were the mentors paid the same hourly rate as substitute teachers?
- **(D)** Would participating families support future education tax increases?
- **(E)** Did students given the take-home books without mentoring show gains comparable to those of mentored participants?

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** Mentoring, rather than books or selection, caused the gains.
2. **Support.** Pilot participants selected themselves and received two bundled services.
3. **Prephrase.** Ask for an outcome that would differ if books rather than mentoring were responsible.
4. **Why (E) is right.** If books alone yield comparable gains, the mentoring-specific causal claim is weakened; if not, this alternative explanation loses force.
5. **Why the others fail.
   - **(A)** Different-population trap: an adult-fiction collection has no bearing on whether mentoring or take-home books improved children’s reading scores.
   - **(B)** Credentials trap: personal observation is not a causal comparison.
   - **(C)** Cost comparison is not a test of mentoring’s effect.
   - **(D)** Political preference does not identify what caused the reading gains.

**Check:** Opposite answers to the credited question move confidence in the mentoring-specific attribution in opposite directions.
::::
:::

## 34.2 Section II: Reading Comprehension

### Passage 1

A dispute over a failed business arrangement can be emotionally straightforward yet legally difficult. One party may have spent money preparing for a transaction; the other may insist that negotiations never matured into a binding contract. The temptation is to begin with the loss and work backward, treating a substantial loss as proof that a promise must have been enforceable. Contract analysis, however, usually proceeds in the opposite direction. The initial inquiry concerns what the parties communicated and whether their words or conduct manifested agreement to sufficiently definite terms. Only after identifying an enforceable obligation does a court ordinarily ask what remedy its breach warrants.

Offer and acceptance are central to this inquiry, but not every favorable statement made during bargaining is an offer. A supplier who invites a retailer to discuss prices may be soliciting negotiations rather than committing to sell at a particular price. Conversely, an agreement need not be labeled a “contract” to be binding. In many circumstances, the parties’ conduct can communicate assent as effectively as words. Consideration, generally understood as an exchange within the bargain, also matters; a gratuitous assurance ordinarily differs from a commitment made in return for a specified performance. These concepts prevent disappointment alone from doing the work of contract formation.

The distinction also matters when choosing remedies. Expectation damages ordinarily take the position the injured party would have occupied had the contract been performed as the point of reference. Reliance damages, by contrast, attend to expenditures made in reliance on a promise or arrangement. A legal system may recognize relief for certain harmful reliance even when an ordinary bargain is not established, but that possibility does not imply that every costly preparation is reimbursable. Nor should the difference be reduced to the slogan that expectation remedies reward optimism whereas reliance remedies merely reimburse receipts. Determining which expenditures resulted from a promise, and whether they are legally recoverable, can be as contested as estimating a lost contractual benefit.

Imagine a hypothetical furniture maker that buys specialized tools after receiving an enthusiastic email from a hotel manager. The manager later orders nothing. If the email was only an invitation to continue discussing a possible order, lost anticipated profit cannot simply be presumed recoverable as damages for breach of a contract. Yet the maker’s tools might still raise distinct questions about whether a sufficiently specific assurance induced reasonable reliance and whether any doctrine makes that loss compensable. Neither the money spent nor the manager’s disappointment settles these questions by itself.

This sequence is not an argument that formation and remedies are unrelated. The remedies a legal system makes available can influence how bargaining parties communicate and rely. Rather, it is an argument for keeping analytically separate questions separate. A convincing account of harm should not replace evidence of agreement; likewise, the absence of a conventional exchange should not end every inquiry into a promise’s effects.

:::problem[Question II.1]
Which one of the following most accurately states the main point of the passage?

- **(A)** Courts should give negotiation labels more weight than parties’ conduct.
- **(B)** Expectation damages are categorically inferior to reliance damages.
- **(C)** Offer and acceptance no longer matter when one party has spent substantial funds.
- **(D)** Questions about contractual agreement and questions about compensation for disappointed expectations or reliance should be distinguished, though they can affect one another.
- **(E)** A disappointed party should always recover at least the amount spent preparing for an agreement.

::::solution[Solution]
**Answer:** (D)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The author defends a structured distinction between agreement and remedies.
2. **Support.** The furniture-maker hypothetical shows how losses alone settle neither issue.
3. **Prephrase.** Choose a balanced thesis reflecting separation without treating categories as wholly unrelated.
4. **Why (D) is right.** The introduction and conclusion explicitly separate formation from remedy while retaining possible interaction; the middle paragraphs develop the distinction.
5. **Why the others fail.
   - **(A)** Contradiction: conduct can manifest agreement without a label.
   - **(B)** False comparison: the passage describes distinct functions without ranking them.
   - **(C)** Reversal: expenditure cannot substitute for evidence of assent.
   - **(E)** Overstatement: the passage expressly denies universal reimbursement.

**Check:** The final paragraph states both separation and possible interaction.
::::
:::

:::problem[Question II.2]
According to the passage, a supplier who invites discussion of prices may not have made an offer because…

- **(A)** only written communications can form contracts.
- **(B)** a transaction is never enforceable unless both sides use the word “contract.”
- **(C)** retailers cannot accept offers from suppliers.
- **(D)** consideration is never required when prices are being discussed.
- **(E)** the communication may merely initiate bargaining without committing the supplier to a definite transaction.

::::solution[Solution]
**Answer:** (E)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** Distinguish preliminary bargaining from firm commitment.
2. **Support.** Second paragraph specifically describes price discussions as possibly exploratory.
3. **Prephrase.** Return to the supplier example, not general contract slogans.
4. **Why (E) is right.** The second paragraph distinguishes an invitation to negotiate from a commitment to sell at a price.
5. **Why the others fail.
   - **(A)** Contradicted: words or conduct may manifest agreement.
   - **(B)** Contradicted by the discussion of agreement without a label.
   - **(C)** Invented categorical rule: no party-type prohibition is described.
   - **(D)** Wrong doctrine: discussion alone does not establish consideration or dispense with it.

**Check:** An invitation to negotiate lacks the commitment that an offer would manifest.
::::
:::

:::problem[Question II.3]
The furniture-maker example primarily serves to…

- **(A)** illustrate how the same failed negotiation can raise separate formation and reliance questions without deciding either one.
- **(B)** prove that specialized tools must be fully reimbursed whenever a buyer withdraws.
- **(C)** demonstrate that an actual sale is necessary before a contract can exist.
- **(D)** show that enthusiasm in emails always creates enforceable contracts.
- **(E)** criticize hotels for ordering furniture from small manufacturers.

::::solution[Solution]
**Answer:** (A)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The example stages two questions rather than deciding a lawsuit.
2. **Support.** Enthusiastic email, purchase of tools, no order: these facts do not conclusively answer either doctrine.
3. **Prephrase.** Look for illustration of analytical separation.
4. **Why (A) is right.** The example contrasts a potentially nonbinding email with a distinct possible reliance question and refuses to decide compensation from expenditure alone.
5. **Why the others fail.
   - **(B)** Overreach: the example explicitly leaves recoverability unresolved.
   - **(C)** Invented principle: contract formation can precede performance.
   - **(D)** Contradiction: the email may only invite discussion.
   - **(E)** Wrong purpose: no general criticism of hotels appears.

**Check:** The paragraph explicitly says neither expenditure nor disappointment alone settles the matter.
::::
:::

:::problem[Question II.4]
Which one of the following is most strongly supported by the passage?

- **(A)** A party can recover expectation damages without ever establishing a breached contractual obligation.
- **(B)** All statements during price discussions are legally meaningless.
- **(C)** Any exchange of emails creates legally enforceable obligations.
- **(D)** An arrangement may be binding even when the parties did not expressly call it a contract.
- **(E)** Reliance damages are awarded in every case lacking an ordinary bargain.

::::solution[Solution]
**Answer:** (D)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** Infer the limited significance of the word contract.
2. **Support.** Assent can be manifested by conduct and is not controlled by labels.
3. **Prephrase.** Choose the modest claim about unlabeled enforceable arrangements.
4. **Why (D) is right.** The second paragraph says exactly that conduct can communicate assent and labels need not determine enforceability.
5. **Why the others fail.
   - **(A)** Unsupported as a general assertion by a passage that separates those inquiries.
   - **(B)** Overcorrection: some communications may be actual offers.
   - **(C)** Too strong: the specificity and commitment of communications remain crucial.
   - **(E)** False universal: relief for certain reliance is possible, not automatic.

**Check:** The passage explicitly permits agreement without a formal label.
::::
:::

:::problem[Question II.5]
A consultant begins work after a prospective client sends a vague message saying a contract is “likely.” The client later declines to hire the consultant. Which one of the following responses would be most consistent with the author’s approach?

- **(A)** Treat the likely wording as conclusive proof of contract formation.
- **(B)** Award the consultant all projected profits because work had begun.
- **(C)** Examine separately whether the message and conduct formed an agreement and whether any legally protected reliance followed from the assurance.
- **(D)** Ignore the message and evaluate only whether the consultant can resell completed work.
- **(E)** Reject every possible claim because no signed document exists.

::::solution[Solution]
**Answer:** (C)

**Type:** RC application (Chapter 18)

1. **Conclusion.** Apply separate analysis to a potentially nonbinding assurance and reliance expenditure.
2. **Support.** A vague likelihood and preparatory work leave both enforceability and relief unresolved.
3. **Prephrase.** Avoid automatic award or dismissal; ask each question independently.
4. **Why (C) is right.** The framework requires independent formation and reliance inquiries rather than deciding solely from work performed.
5. **Why the others fail.
   - **(A)** Overreading a vague assurance: the passage insists on commitment and definiteness.
   - **(B)** Premature remedy: assumes binding contract and expected gain.
   - **(D)** Too narrow: mitigation-like facts cannot replace formation and reliance analysis.
   - **(E)** Formal-label trap: conduct or other promise-based grounds may matter.

**Check:** The correct response mirrors the author’s explicit sequence.
::::
:::

:::problem[Question II.6]
The author’s attitude toward treating financial loss as sufficient evidence of a contractual obligation is best described as…

- **(A)** hostile to all forms of reliance relief.
- **(B)** indifferent, because contractual remedies have no effect on bargaining.
- **(C)** enthusiastic, because it reduces the time spent analyzing offers.
- **(D)** skeptical, because it substitutes the consequences of negotiations for proof of agreement.
- **(E)** accepting whenever a loss involves specialized equipment.

::::solution[Solution]
**Answer:** (D)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author rejects loss-to-contract inference.
2. **Support.** Opening and conclusion criticize working backward from injury.
3. **Prephrase.** Choose measured skepticism rather than a denial of remedies.
4. **Why (D) is right.** The opening calls the move a temptation; the conclusion says harm should not replace evidence of agreement.
5. **Why the others fail.
   - **(A)** Overstatement: the author discusses circumstances where reliance may matter.
   - **(B)** Contradicted: the author acknowledges influence on behavior.
   - **(C)** Opposite attitude: the author warns against that shortcut.
   - **(E)** Exception invented from the example; even those tools do not settle formation.

**Check:** The text disallows harm as substitute proof, not as a relevant consideration.
::::
:::

:::problem[Question II.7]
The third paragraph distinguishes expectation damages from reliance damages primarily by…

- **(A)** claiming that expectation damages punish misconduct while reliance rewards honesty.
- **(B)** asserting that reliance expenditures are always easier to establish.
- **(C)** differentiating a performance-based reference point from attention to expenditures induced by a promise.
- **(D)** stating that expectation damages are awarded only when no contract was formed.
- **(E)** requiring courts to choose whichever remedy is larger.

::::solution[Solution]
**Answer:** (C)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** Identify the two distinct objects of remedy measurement.
2. **Support.** Third paragraph defines expectation as performance position and reliance as expenditures.
3. **Prephrase.** Match those bases without inventing eligibility or priority rules.
4. **Why (C) is right.** Expectation looks to the position if performed; reliance looks to expenditures tied to reliance.
5. **Why the others fail.
   - **(A)** Wrong framework: no character-based division is given.
   - **(B)** Contradiction: the author says they can be contested.
   - **(D)** Reversal of the ordinary contract-remedy discussion.
   - **(E)** Invented rule: no automatic size comparison is supplied.

**Check:** The credited answer restates the stated distinction without overgeneralization.
::::
:::

### Passage 2

One influential proposal in cognitive neuroscience treats perception not as the passive reception of sensory data but as a process in which the nervous system continually predicts incoming signals. On this account, discrepancies between expected and received input, often called prediction errors, can help revise a model of the environment. The proposal is attractive partly because it gives a common language to learning, perception, and adaptation. Yet a common vocabulary can outpace the evidence: observing that a brain responds differently to expected and unexpected stimuli is not, by itself, proof that the response implements the computation proposed by a particular theory.

Consider a hypothetical experiment in which participants hear a sequence of identical tones interrupted occasionally by a different tone. Researchers record a stronger neural response to the unusual tone than to the repeated ones. A predictive account interprets that difference as a signal that the unusual tone violated an expectation established by repetition. But another explanation is available. Neural responses to a frequently repeated stimulus can diminish with exposure, a phenomenon often discussed under the broad heading of sensory adaptation. The unusual tone may produce a larger response partly because the relevant neurons have been stimulated less recently. Both accounts can predict the original observation, though they interpret it differently.

The two explanations need not be mutually exclusive. Repetition could both change physiological responsiveness and generate expectations. The problem lies in using a result compatible with several mechanisms as decisive evidence for just one. To distinguish them, researchers might compare responses to physically identical tones appearing after different sequences, while also varying how predictable the sequences are. Such a design could hold parts of the immediate sensory input constant and ask whether response differences track probability, recent stimulation, or some combination. Even then, finding a response associated with an unexpected event would not establish exactly what information the neural signal encodes.

A more demanding test would begin with predictions that the competing accounts do not share. Suppose a particular adaptation model predicts the same response whenever the recent history of stimulation is matched, whereas a predictive model expects different responses because a learned sequence gives the next tone a different probability. If the physical stimulus and recent stimulation history are equated but the response still varies in the predicted direction, that result counts against the specified adaptation model. It does not, however, establish that all versions of adaptation are false or that every element of predictive processing is correct.

This caution is sometimes mistaken for resistance to grand explanations. It is better understood as a way to make them informative. A theory gains empirical force not from accommodating every observed pattern after the fact but from risking failure on observations that plausible alternatives cannot accommodate equally well.

:::problem[Question II.8]
Which one of the following best expresses the author’s central argument?

- **(A)** A useful neuroscience theory must explain every aspect of perception in one mechanism.
- **(B)** Sensory adaptation is the only legitimate explanation for responses to unusual tones.
- **(C)** Neural responses consistent with predictive processing support that theory most strongly when experiments distinguish its predictions from plausible competing explanations.
- **(D)** Predictive processing has been conclusively disproved by studies of repeated tones.
- **(E)** Brains respond more strongly to unusual tones in every experimental context.

::::solution[Solution]
**Answer:** (C)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** The key is discriminating prediction-error and adaptation interpretations.
2. **Support.** Initial observations fit both; controlled designs and unique predictions can separate them.
3. **Prephrase.** Choose an argument about evidentiary standards, not outright theory rejection.
4. **Why (C) is right.** The passage repeatedly emphasizes discriminating tests rather than interpreting any surprise response as unique evidence.
5. **Why the others fail.
   - **(A)** Invented standard: the author values risky distinctive predictions.
   - **(B)** Opposite extreme: the passage treats both as possible.
   - **(D)** Opposite and too strong: it remains a viable account.
   - **(E)** Universal empirical claim not made; only a hypothetical example is described.

**Check:** The conclusion expressly privileges predictions that alternatives cannot explain equally well.
::::
:::

:::problem[Question II.9]
According to the second paragraph, sensory adaptation could explain the hypothetical stronger response to the unusual tone because…

- **(A)** the unusual tone must have a greater physical intensity.
- **(B)** the brain ceases making predictions during repetitive sequences.
- **(C)** researchers cannot measure responses to repeated tones at all.
- **(D)** unusual tones are always perceived as louder than repeated tones.
- **(E)** repeated tones may produce reduced neural responsiveness, whereas the unusual tone activates less recently stimulated responses.

::::solution[Solution]
**Answer:** (E)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** Explain larger deviant response without invoking prediction violation.
2. **Support.** Frequent stimulation can reduce responsiveness to repeated stimulus.
3. **Prephrase.** Point to recent-stimulation differences.
4. **Why (E) is right.** The paragraph states the adaptation mechanism directly as an alternative to violated expectation.
5. **Why the others fail.
   - **(A)** Invented stimulus difference: different does not mean stronger.
   - **(B)** Contrary to the coexistence point in paragraph three.
   - **(C)** Contradicted by the hypothetical recorded comparison.
   - **(D)** Unsupported subjective comparison: the outcome is neural response.

**Check:** Adaptation yields unequal response magnitudes even without the specific proposed predictive code.
::::
:::

:::problem[Question II.10]
Which one of the following is most strongly supported by the passage?

- **(A)** Identical physical tones must always evoke identical neural responses.
- **(B)** A single neural response pattern may be compatible with both expectancy-related processing and stimulus-specific adaptation.
- **(C)** Predictive models are empirically useless unless all adaptation mechanisms are disproved.
- **(D)** Any adaptation effect rules out the presence of predictions in the nervous system.
- **(E)** Learning cannot occur when the same sensory signal is repeated.

::::solution[Solution]
**Answer:** (B)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** Draw a coexistence implication rather than choosing one mechanism exclusively.
2. **Support.** Paragraph three explicitly says repetition might affect responsiveness and expectations.
3. **Prephrase.** Prefer compatibility over exclusivity claims.
4. **Why (B) is right.** The third paragraph explicitly permits both mechanisms to operate and says the same result can fit several.
5. **Why the others fail.
   - **(A)** Contradicted by the proposed controlled designs.
   - **(C)** Unreasonable standard: evidence can count against a specified alternative without disproving every version.
   - **(D)** False-dilemma trap: the passage explicitly says repetition can alter both neural responsiveness and learned expectations at once.
   - **(E)** Unsupported-universal trap: the passage never says repetition prevents learning, and it describes expectations formed through repeated sequences.

**Check:** The source directly states mechanisms need not be mutually exclusive.
::::
:::

:::problem[Question II.11]
The author’s description of matching recent stimulation histories in the fourth paragraph is primarily intended to…

- **(A)** deny that expectations can be learned from sequences.
- **(B)** describe a condition under which the two explanatory models might yield different predictions.
- **(C)** show that all adaptation models require physical stimuli to be different.
- **(D)** argue that recording equipment is incapable of distinguishing tones.
- **(E)** establish that the predictive account has already won such an experiment.

::::solution[Solution]
**Answer:** (B)

**Type:** RC function (Chapter 18)

1. **Conclusion.** The matched-history example constructs a potential falsifying comparison.
2. **Support.** It fixes an input history while varying learned probability.
3. **Prephrase.** Identify an experimental control that exposes model-specific predictions.
4. **Why (B) is right.** If the adaptation model predicts equality under matched recent history while the predictive account predicts a probability effect, the comparison can discriminate.
5. **Why the others fail.
   - **(A)** Opposite: learned probabilities drive the contrasting prediction.
   - **(C)** Universal overreach: one specified model is used as an example.
   - **(D)** Wrong-target trap: matching stimulus histories is proposed to distinguish models, not to criticize the equipment recording neural responses.
   - **(E)** Hypothetical-study trap: no completed result is reported.

**Check:** The paragraph explicitly states the divergent forecasts of the two models.
::::
:::

:::problem[Question II.12]
In the hypothetical test described in the fourth paragraph, which result would most directly challenge the specified adaptation model?

- **(A)** Participants become better at identifying the speaker delivering instructions.
- **(B)** With recent stimulation histories matched, neural responses systematically differ in accordance with the learned probability of the next tone.
- **(C)** Participants report disliking the unusual tone.
- **(D)** Responses remain identical when recent stimulation histories are matched.
- **(E)** Responses differ when recent stimulation histories differ widely.

::::solution[Solution]
**Answer:** (B)

**Type:** RC application (Chapter 18)

1. **Conclusion.** Find a violation of same history → same response for the specified adaptation model.
2. **Support.** The fourth paragraph explicitly contrasts predictions of response equality versus probability sensitivity.
3. **Prephrase.** Use a matched-history counterexample.
4. **Why (B) is right.** The stated adaptation model predicts equal response under matched history, so the systematic probability-linked difference contradicts it.
5. **Why the others fail.
   - **(A)** Different task and outcome: not tone-history responses.
   - **(C)** Subjective attitude does not test the neural forecast.
   - **(D)** Supports rather than challenges the specified adaptation prediction.
   - **(E)** Compatible with adaptation: its input condition is not controlled.

**Check:** Same recent history yet learned-probability differences produce unequal responses.
::::
:::

:::problem[Question II.13]
The author’s attitude toward predictive processing is best characterized as…

- **(A)** qualified interest combined with skepticism about interpreting ambiguous observations as decisive confirmation.
- **(B)** indifference to whether predictions distinguish alternatives.
- **(C)** unreserved endorsement of every published prediction-error interpretation.
- **(D)** certainty that sensory adaptation alone explains all perception.
- **(E)** outright rejection of the theory as incapable of empirical testing.

::::solution[Solution]
**Answer:** (A)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** The author sees promise but demands stronger tests.
2. **Support.** The opening values conceptual reach; closing calls for risk of falsification.
3. **Prephrase.** Choose balanced critical engagement.
4. **Why (A) is right.** The proposal is called attractive, but the author repeatedly cautions against underdetermined inferences.
5. **Why the others fail.
   - **(B)** Contradicted by the concluding methodological standard.
   - **(C)** Extreme-attitude trap: the author calls the theory attractive but repeatedly rejects treating ambiguous patterns as decisive confirmation.
   - **(D)** Unsupported-exclusivity trap: the author never says adaptation accounts for all perception and expressly allows predictive processes too.
   - **(E)** Opposite: the author proposes discriminating experiments.

**Check:** Neither blanket enthusiasm nor outright rejection matches the passage.
::::
:::

:::problem[Question II.14]
The final paragraph principally serves to…

- **(A)** summarize the history of sensory-adaptation research.
- **(B)** defend the demand for discriminating evidence against the charge that such caution is hostile to broad theories.
- **(C)** recommend using only subjective reports rather than neural recordings.
- **(D)** introduce a new dataset that settles the dispute between the theories.
- **(E)** declare that broad theories must be abandoned in favor of isolated observations.

::::solution[Solution]
**Answer:** (B)

**Type:** RC function (Chapter 18)

1. **Conclusion.** Identify a response to a possible criticism of the author’s methodology.
2. **Support.** Caution may seem anti-theoretical, but the author calls it empirical discipline.
3. **Prephrase.** Read the last two sentences as rebuttal and restatement of standard.
4. **Why (B) is right.** The author explicitly reframes methodological caution as a way to make theories more informative.
5. **Why the others fail.
   - **(A)** Wrong-purpose trap: the closing paragraph evaluates how theories earn support rather than tracing the chronological development of adaptation research.
   - **(C)** Invented-method trap: the author never recommends replacing neural recordings with subjective reports; the debate is over model-discriminating controls.
   - **(D)** Invented evidence: the closing is methodological, not empirical.
   - **(E)** Opposite: caution improves rather than bans broad explanations.

**Check:** The paragraph says risky predictions give a theory empirical force.
::::
:::

### Passage 3

When a disused building is converted to a new purpose, architects face an apparent choice: preserve historic fabric or make the structure useful again. That opposition is too simple. An unused building may deteriorate, while an intervention that keeps it occupied can protect it from neglect. But new uses also impose demands that older buildings were not designed to meet. The interesting question is not whether change should occur, but how its consequences should be judged. Two influential conservation ideals, reversibility and legibility, offer guidance without supplying automatic answers.

A reversible intervention can, at least in principle, be removed without permanently damaging significant existing material. It preserves options for future caretakers whose priorities or information may differ. Legibility concerns a different matter: visitors should be able to distinguish new work from what survives of the old. A modern stair inserted into a former market hall might be visually distinct yet require cuts that cannot be undone; a removable partition might leave the masonry intact while imitating an old wall so convincingly that it obscures the building’s history. It would be a mistake to treat reversibility and legibility as synonyms.

Consider a hypothetical brick market hall that has remained vacant for years. A proposal would turn it into a public workshop center. One architect favors freestanding interior structures bolted to removable floor plates; another argues that durable alterations to a service corridor will be necessary for safe access. The first plan is more reversible on paper, but its temporary-looking structures may require constant maintenance. The second is less reversible, yet might allow the building to remain in active use for decades. Neither cost nor reversibility alone establishes which design better conserves the hall. Assessment should include which historic elements are affected, how the interventions will age, and what future users will be able to understand about the site.

The label “original” creates a related difficulty. Historic buildings often record more than one phase of use, and eliminating later changes to recreate a selected early appearance can erase genuine evidence of the building’s subsequent life. A carefully designed conversion should distinguish between alterations that obscure significant features and later additions that are themselves significant. Documentation before work begins can preserve information, but a photograph of a destroyed feature is not equivalent to preserving the feature. Conversely, a prohibition on every permanent alteration may leave the building unusable and ultimately imperil the material the rule was meant to protect.

Good conservation therefore requires comparative judgments rather than a mechanical hierarchy of techniques. Reversibility and legibility remain important tests, but each tests only one aspect of a proposal. A successful adaptation preserves what is valuable, makes present use credible, and leaves future caretakers both material evidence and an intelligible record of the changes.

:::problem[Question II.15]
Which one of the following best states the central claim of the passage?

- **(A)** The history of market halls is more important than all other building types.
- **(B)** New architectural elements should always visually imitate historic elements.
- **(C)** Adaptive reuse should be evaluated through several conservation goals, because neither reversibility nor legibility alone determines whether an intervention is appropriate.
- **(D)** An alteration is acceptable only if it can be removed without leaving a trace.
- **(E)** Unused historic buildings can never be preserved successfully.

::::solution[Solution]
**Answer:** (C)

**Type:** RC main point (Chapter 18)

1. **Conclusion.** Conservation is a multi-criterion judgment, not a single-technique rule.
2. **Support.** Reversibility and legibility can diverge, and safe ongoing use can require durable change.
3. **Prephrase.** Choose the synthesis at both opening and conclusion.
4. **Why (C) is right.** The opening refuses a binary preservation/use choice, and the conclusion calls for comparative judgments integrating multiple goals.
5. **Why the others fail.
   - **(A)** Example-to-thesis trap: the hall is hypothetical and illustrative.
   - **(B)** Reversal trap: legibility requires new work to be distinguishable rather than disguised as original historical material.
   - **(D)** Absolute reversibility contradicts the acceptance of some durable changes.
   - **(E)** Too strong: vacancy creates risks but impossibility is not asserted.

**Check:** The final paragraph explicitly calls both ideals partial tests, not automatic decisions.
::::
:::

:::problem[Question II.16]
According to the passage, which one of the following best distinguishes reversibility from legibility?

- **(A)** Reversibility concerns whether a building can change owners; legibility concerns whether its use is commercial.
- **(B)** Reversibility requires imitation of old materials; legibility forbids every new material.
- **(C)** Reversibility addresses only exterior walls; legibility addresses only interiors.
- **(D)** Reversibility concerns whether a modification can be removed without lasting harm, whereas legibility concerns whether old and new work remain distinguishable.
- **(E)** Reversibility concerns the popularity of a design; legibility concerns its construction cost.

::::solution[Solution]
**Answer:** (D)

**Type:** RC detail (Chapter 18)

1. **Conclusion.** Define each ideal without merging it with the other.
2. **Support.** Second paragraph contrasts permanence of intervention with readable historical layers.
3. **Prephrase.** Return to the formal definitions and examples.
4. **Why (D) is right.** The second paragraph provides these separate definitions.
5. **Why the others fail.
   - **(A)** Topic substitution: reversibility and legibility concern interventions and visible historical distinctions, not ownership transfers or commercial zoning.
   - **(B)** Conflation: the author explicitly distinguishes rather than equates criteria.
   - **(C)** False location restriction: both can apply across a building.
   - **(E)** Definition-shell trap: popularity and expense can matter to decisions, but the passage defines these two criteria as removability and historical readability.

**Check:** A visually obvious alteration can still be irreversible, proving the separation.
::::
:::

:::problem[Question II.17]
The examples of the modern stair and removable partition in the second paragraph mainly serve to…

- **(A)** demonstrate that a design can satisfy one conservation ideal while failing to satisfy the other.
- **(B)** establish that removable partitions damage masonry more than permanent stairs.
- **(C)** show that both ideals always point toward the same architectural decision.
- **(D)** suggest that conservation should ignore how structures appear to visitors.
- **(E)** prove that a building’s newest feature must be its most historically important.

::::solution[Solution]
**Answer:** (A)

**Type:** RC function (Chapter 18)

1. **Conclusion.** Locate the analytic function of paired contrasting cases.
2. **Support.** One case meets legibility without reversibility; the other reversibility without legibility.
3. **Prephrase.** Seek a demonstration of independence of criteria.
4. **Why (A) is right.** The stair is legible but irreversible; the partition is removable but potentially misleading.
5. **Why the others fail.
   - **(B)** Wrong comparison: the partition leaves masonry intact.
   - **(C)** Direct contradiction: the examples show divergence.
   - **(D)** Opposite: legibility concerns visitor understanding.
   - **(E)** Invented-ranking trap: the examples contrast reversibility with legibility and do not claim that a newer element has greater historical value.

**Check:** The examples are constructed to separate, not unite, the two ideals.
::::
:::

:::problem[Question II.18]
Which one of the following is most strongly supported by the fourth paragraph?

- **(A)** Every permanent alteration must be treated as historically significant.
- **(B)** Documenting a feature makes its physical preservation unnecessary.
- **(C)** A later addition to a historic building may itself deserve preservation because it records a meaningful phase of the building’s history.
- **(D)** All later additions are more significant than an original structure.
- **(E)** A building ought to be returned to its earliest appearance whenever possible.

::::solution[Solution]
**Answer:** (C)

**Type:** RC inference (Chapter 18)

1. **Conclusion.** Infer possible significance of later fabric.
2. **Support.** The author rejects erasing later phases merely to recreate one selected period.
3. **Prephrase.** Choose may deserve rather than always preserve.
4. **Why (C) is right.** The author warns that removal of later changes can erase genuine historical evidence and recommends assessing their significance.
5. **Why the others fail.
   - **(A)** Unsupported automatic rule; significance remains a judgment.
   - **(B)** Contradiction: photos are explicitly not equivalent to preserved material.
   - **(D)** Extreme reversal: the author insists on assessing significance, not automatic priority.
   - **(E)** Opposite-policy trap: the author warns that recreating a single earliest appearance may erase valuable later historical phases.

**Check:** A genuine later historical layer can be part of what is valuable.
::::
:::

:::problem[Question II.19]
Which one of the following approaches to the hypothetical market hall would best fit the author’s framework?

- **(A)** Choose the freestanding structures automatically because they are easier to remove.
- **(B)** Refuse all new uses so that no contemporary alteration can occur.
- **(C)** Choose any design that maximizes public attendance, regardless of historic damage.
- **(D)** Reconstruct the hall’s earliest appearance and remove all later additions.
- **(E)** Compare each proposed intervention’s material effects, historical readability, upkeep, and ability to support continued use before selecting a design.

::::solution[Solution]
**Answer:** (E)

**Type:** RC application (Chapter 18)

1. **Conclusion.** Apply multidimensional evaluation to competing reuse plans.
2. **Support.** The example juxtaposes reversible-but-maintenance-intensive and durable-but-altering plans.
3. **Prephrase.** Look for tradeoff assessment, not a bright-line winner.
4. **Why (E) is right.** The author explicitly names affected elements, aging, future understanding, and functional survival as relevant criteria.
5. **Why the others fail.
   - **(A)** Single-factor trap: reversibility is not decisive by itself.
   - **(B)** False preservation/use dilemma rejected in opening.
   - **(C)** Other extreme: use cannot erase conservation concerns.
   - **(D)** Contradicts the multiple-layer historical analysis.

**Check:** The option examines precisely the criteria the author identifies as material.
::::
:::

:::problem[Question II.20]
The author’s attitude toward the ideal of reversibility is best characterized as…

- **(A)** unqualified because it always prevents historical loss.
- **(B)** respectful but unwilling to treat it as the sole measure of good conservation.
- **(C)** dismissive because it has no conceivable value.
- **(D)** hostile because it is useful only for new buildings.
- **(E)** indifferent because maintenance and use are entirely unrelated to conservation.

::::solution[Solution]
**Answer:** (B)

**Type:** RC attitude (Chapter 18)

1. **Conclusion.** Identify a qualified endorsement of reversibility.
2. **Support.** Second paragraph values removal without harm; later paragraphs deny automatic priority.
3. **Prephrase.** Match measured approval plus limits.
4. **Why (B) is right.** Reversibility is called important and future-protective, yet may conflict with lasting usefulness or other values.
5. **Why the others fail.
   - **(A)** Absolute trap: removable work can obscure history.
   - **(C)** Contradiction: future options are an explicit benefit.
   - **(D)** Unsupported restriction: reversibility is applied to historic work.
   - **(E)** Contradiction: upkeep and credible use are part of the author’s test.

**Check:** The final paragraph explicitly says reversibility is important but partial.
::::
:::

### Passage 4 (comparative)

**Passage A**

Speakers rarely use precisely the same pronunciation, vocabulary, and level of formality in every conversation. One productive explanation of this stylistic variation begins with audience. A person addressing a new supervisor may choose more formal phrasing than when talking with a close friend, not because the speaker possesses two isolated personalities but because each encounter supplies different expectations. The relevant audience includes more than the immediate addressee: an overhearing colleague or an imagined future reader may influence a speaker’s choices. Changes in topic and setting can matter as well, sometimes because each is associated with particular sorts of listeners. A person may even adjust speech when drafting a message nobody will hear aloud, anticipating how its eventual readers will interpret it. The physical absence of the audience does not eliminate the audience’s explanatory role.

This account is not a claim that speakers mechanically copy whoever happens to be present. Someone may deliberately depart from an audience’s style or invoke the speech associated with an absent group. But even a conspicuous departure is intelligible partly against a landscape of expected audience relationships. The analytic advantage of beginning with audience is that it identifies a structured source of variation rather than simply declaring every choice an expression of personality. Researchers should therefore ask first whose presence or anticipated response made a particular style relevant, while remaining open to other explanations.

**Passage B**

Audience matters, but treating it as the starting point for every account of style can obscure what speakers accomplish by speaking. Imagine a student who adopts an exaggeratedly formal tone while joking with friends. It would be misleading to explain this only as an accommodation to listeners who expect formality. The student may be momentarily performing the role of a school official, creating an ironic stance that the friends recognize precisely because the style departs from ordinary expectations. Style in such cases does not merely respond to an already defined social situation; it helps construct one. An observer who recorded only the friends’ ordinary speech styles might predict the student's usual casual manner and miss why the mock-official voice was chosen. Explaining that choice requires asking what contrast the performance made available to the participants.

Linguistic forms can carry multiple possible social associations, and which association becomes salient depends on context and interaction. A pronunciation linked in one setting with professional authority may, in another, be used playfully to mock that authority. Audience expectations still provide resources for interpretation, but speakers also select and reshape those resources. Consequently, beginning with audience as a general rule is a mistake: the most revealing question is not always which audience prompted a shift. It may instead be what social position, relationship, or stance the speaker is making recognizable through the shift. An adequate account must explain both responsiveness and initiative.

:::problem[Question II.21]
Which one of the following most accurately describes the relationship between Passages A and B?

- **(A)** Both recognize audience-related influences, but Passage B places greater emphasis on speakers’ active construction of social meaning.
- **(B)** Passage B demonstrates that audience expectations have no explanatory value.
- **(C)** Passage A offers historical evidence that Passage B disputes with newer dates.
- **(D)** Passage A rejects intentional style changes, whereas Passage B accepts them.
- **(E)** Both argue that pronunciation carries only one stable social meaning.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative relationship (Chapter 17)

1. **Conclusion.** A emphasizes audience as analytic starting point; B emphasizes initiative and stance.
2. **Support.** Both concede relevance of audiences; they differ in theoretical priority.
3. **Prephrase.** Find agreement in relevance and contrast in emphasis, not flat contradiction.
4. **Why (A) is right.** A begins explanation with audiences while allowing initiative; B agrees audience matters but argues it may be insufficient as a starting point.
5. **Why the others fail.
   - **(B)** Overstatement: B calls audiences a resource for interpretation.
   - **(C)** Invented historical comparison: neither passage develops chronological evidence.
   - **(D)** False opposition: A explicitly recognizes deliberate departures and absent groups.
   - **(E)** Contradiction: B stresses multiple possible associations; A does not impose uniqueness.

**Check:** Each author’s qualifying sentences prevent an all-or-nothing reading.
::::
:::

:::problem[Question II.22]
Both authors would most likely agree with which one of the following statements?

- **(A)** Audience characteristics are never relevant to stylistic choices.
- **(B)** Stylistic variation is impossible to investigate systematically.
- **(C)** Speech styles are fixed properties of isolated personalities.
- **(D)** Every shift in speech style is caused by a desire to mock authority.
- **(E)** Speakers can make stylistic choices that cannot be described adequately as simple imitation of an immediate listener.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative agreement (Chapter 17)

1. **Conclusion.** Identify shared recognition of deliberate nonimitative variation.
2. **Support.** A acknowledges departures; B treats departures as meaningful action.
3. **Prephrase.** Demand a position affirmable from both texts.
4. **Why (E) is right.** A allows deliberate divergence and invocation of an absent group; B gives an ironic role-performance example.
5. **Why the others fail.
   - **(A)** Shared-position trap: Passage A begins with audience-based variation and Passage B explicitly says audience matters.
   - **(B)** Opposite of both passages’ proposed research approaches.
   - **(C)** Opposed by A explicitly and B’s interactive account.
   - **(D)** Example-to-universal trap: B’s student is one case.

**Check:** Both passages describe shifts not reducible to copying present listeners.
::::
:::

:::problem[Question II.23]
The authors would most likely disagree about which one of the following?

- **(A)** Whether audiences sometimes influence the way people speak.
- **(B)** Whether a speaker can deliberately depart from the surrounding speech style.
- **(C)** Whether speakers ever address friends in a playful manner.
- **(D)** Whether an investigation of a style shift should generally begin by identifying whose expected response made the style relevant.
- **(E)** Whether pronunciation and vocabulary can vary across conversations.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative disagreement (Chapter 17)

1. **Conclusion.** The contrast concerns explanatory priority, not existence of audience effects.
2. **Support.** A recommends asking first whose anticipated response matters; B opposes that as a general research default.
3. **Prephrase.** Look for competing methodological emphases each author addresses.
4. **Why (D) is right.** Passage A says audience should be the initial analytic question; Passage B explicitly rejects audience-first investigation as a general rule.
5. **Why the others fail.
   - **(A)** Shared-position trap: Passage A recommends audience analysis and Passage B begins by affirming that audiences sometimes influence style.
   - **(B)** Shared-position trap: Passage A discusses deliberate divergence and Passage B describes a student deliberately adopting a mock-official voice.
   - **(C)** B gives an example; A offers no conflicting claim.
   - **(E)** Shared-premise trap: the two accounts disagree over the explanation of shifts, not over the observation that pronunciation and vocabulary can vary.

**Check:** A endorses audience-first as a general method; B states that beginning with it as a general rule is a mistake.
::::
:::

:::problem[Question II.24]
How would the author of Passage A most likely respond to the hypothetical student’s exaggeratedly formal joking style in Passage B?

- **(A)** It establishes that supervisors always speak more formally than friends.
- **(B)** It proves that all audience-based accounts are false.
- **(C)** It is impossible because speakers cannot intentionally shift styles.
- **(D)** It should be classified as a genuine change in the student’s permanent personality.
- **(E)** It is compatible with audience analysis because a deliberate departure can draw on expectations associated with a social role or imagined reference group.

::::solution[Solution]
**Answer:** (E)

**Type:** Comparative author response (Chapter 17)

1. **Conclusion.** A would try to explain the role-playing example without denying initiative.
2. **Support.** A treats audience expectations and absent groups as explanatory resources.
3. **Prephrase.** Predict a qualified incorporation, not an absolute rejection.
4. **Why (E) is right.** A specifically allows deliberate divergence and absent reference groups while treating audience relationships as an initial explanatory frame.
5. **Why the others fail.
   - **(A)** Unsupported generalization from a different role-playing example.
   - **(B)** Overreach: the example can fit A’s qualified account.
   - **(C)** Contradiction: A explicitly recognizes intentional divergence.
   - **(D)** Misreads A’s rejection of isolated personality explanations.

**Check:** A’s second paragraph already accommodates deliberate departures.
::::
:::

:::problem[Question II.25]
In Passage A, the reference to an absent group primarily serves to…

- **(A)** qualify a simple audience-imitation model while retaining audience relationships as an explanatory framework.
- **(B)** claim that all departures from listener style are accidental.
- **(C)** argue that only physically present listeners can affect speech.
- **(D)** establish that topic has no relationship to stylistic variation.
- **(E)** reject any possibility of systematic explanation.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative function (Chapter 17)

1. **Conclusion.** Identify a concession that broadens A’s audience concept.
2. **Support.** A allows deliberate divergence and symbolic reference to absent listeners.
3. **Prephrase.** Read the sentence as a refinement, not a repudiation.
4. **Why (A) is right.** The reference occurs immediately after the author says speakers do not mechanically copy present listeners.
5. **Why the others fail.
   - **(B)** Contradiction trap: the passage explicitly treats the departure as deliberate and as interpretable through audience relationships.
   - **(C)** Reversal trap: Passage A introduces absent reference groups precisely to show that stylistic choices can invoke people not present.
   - **(D)** False exclusion: topic may matter through listener associations.
   - **(E)** Opposite: the account seeks a structured source of variation.

**Check:** A keeps its audience-starting method immediately after the caveat.
::::
:::

:::problem[Question II.26]
Passage B most strongly suggests that a single linguistic feature may…

- **(A)** convey different social meanings depending on how it is used in a particular interaction.
- **(B)** lack any interpretable social meaning when used humorously.
- **(C)** have a meaning determined solely by a speaker’s formal education.
- **(D)** be controlled entirely by the identity of the immediate addressee.
- **(E)** have exactly the same social meaning in every conversation.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative inference (Chapter 17)

1. **Conclusion.** Find context-dependent meaning rather than fixed one-to-one symbolism.
2. **Support.** B’s professional-authority pronunciation can become playful critique in another setting.
3. **Prephrase.** Choose a limited may claim supported by the example.
4. **Why (A) is right.** B explicitly contrasts authority-associated pronunciation used seriously and used to mock that authority.
5. **Why the others fail.
   - **(B)** Opposite: ironic use depends on recognizable association.
   - **(C)** New-factor trap: Passage B attributes variation to interactional stance and context, not solely to a speaker’s formal education.
   - **(D)** Reduces initiative to the mechanism B criticizes.
   - **(E)** Contradiction: B emphasizes contextual multiplicity.

**Check:** The same form with altered stance can index different relationships.
::::
:::

:::problem[Question II.27]
A researcher observes a student using a regional expression while speaking to classmates who do not ordinarily use it. Which approach would the author of Passage B most likely favor?

- **(A)** Assuming the expression must mean the same thing in every context.
- **(B)** Investigating what identity or stance the student may be expressing, as well as how classmates interpret the expression.
- **(C)** Inferring that the classmates must belong to the same regional group as the student.
- **(D)** Automatically concluding that the student misunderstood the classmates’ pronunciation.
- **(E)** Discarding the observation because audience expectations are irrelevant to language.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative application (Chapter 17)

1. **Conclusion.** B would examine the communicative work of a stylistic choice.
2. **Support.** B asks what relationship, identity or stance a shift makes recognizable.
3. **Prephrase.** Investigate speaker initiative and audience interpretation together.
4. **Why (B) is right.** B emphasizes active positioning and interpretation rather than only matching an addressee’s existing style.
5. **Why the others fail.
   - **(A)** Fixed-meaning trap: Passage B expressly says the same form may convey distinct social meanings across contexts.
   - **(C)** Invalid inference: they do not ordinarily use that expression.
   - **(D)** Unsupported error attribution; B considers intentional agency.
   - **(E)** False rejection: B still treats audience as a resource.

**Check:** This method tracks B’s concluding question about social positioning.
::::
:::

## 34.3 Section III: Logical Reasoning

:::problem[Question III.1]
An art-school administrator recommends making admissions interviews mandatory. Applicants who volunteered for interviews last year were more likely to enroll after receiving an offer than applicants who did not interview. The administrator reasons that the interviews generated stronger commitment to the school and that requiring them will therefore increase enrollment yield. Yet the admissions office invited candidates to interview only after they had expressed interest in an upcoming campus event, and applicants who lived farther away often could not attend. The administrator has not compared similarly interested applicants.

Which one of the following, if true, most weakens the administrator’s argument?

- **(A)** Some interviewers also taught first-year classes.
- **(B)** The admissions office received more applications than expected.
- **(C)** Among equally interested applicants randomly offered interviews, those who attended were no more likely to enroll than those who did not attend.
- **(D)** The interview questions concerned applicants’ artistic interests.
- **(E)** Several interviewed students later joined campus clubs.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Mandatory interviews will raise enrollment yield.
2. **Support.** Volunteers had higher yield, but interview invitations favored preinterested candidates.
3. **Prephrase.** Find evidence separating interview effects from prior interest.
4. **Why (C) is right.** A controlled comparison eliminates the outcome difference while addressing the motivation confound; the observed voluntary correlation does not support causation.
5. **Why the others fail.
   - **(A)** Background detail with no comparison of enrollment outcomes.
   - **(B)** Different total: application volume is not post-offer yield.
   - **(D)** Content alone does not establish an effect on enrollment decisions.
   - **(E)** Selection trap: downstream activity by some enrollees does not show interviews caused enrollment.

**Check:** Equal-interest comparison with no yield advantage defeats the asserted causal mechanism.
::::
:::

:::problem[Question III.2]
A baseball columnist observes that the five players with the highest batting averages on one club all subscribe to a swing-analysis service. She therefore argues that a subscription is the primary reason those players hit well and that any struggling player who subscribes will soon become a top hitter. The service is also widely used by reserve players, but the columnist did not collect their batting records. Nor did she account for differences in training history or playing time. Her recommendation is based entirely on identifying a shared feature of the top five players.

The argument is most vulnerable to criticism on the grounds that it…

- **(A)** bases a conclusion about hitting on an irrelevant measure of pitching skill.
- **(B)** establishes that reserve players have lower subscription fees.
- **(C)** infers both causation and universal effectiveness from a feature observed only among selected successful players.
- **(D)** requires that every top hitter on every team subscribe.
- **(E)** assumes that batting average is never used to evaluate performance.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Buying the service will make any struggling player a top hitter.
2. **Support.** A selected set of top hitters uses the service; countercases were omitted.
3. **Prephrase.** Identify selection on success plus a causal and universal leap.
4. **Why (C) is right.** The sample is conditioned on success; nonelite subscribers and other determinants were ignored. The evidence does not show the service causes hitting success.
5. **Why the others fail.
   - **(A)** Wrong statistic: batting average is a hitting measure.
   - **(B)** Invented-cost trap: the passage mentions reserve players using the app but gives no subscription-price comparison for any player group.
   - **(D)** Overstatement: the conclusion about struggling users is flawed without a leaguewide claim.
   - **(E)** Opposite of the argument: it uses batting averages as the success measure.

**Check:** A reserve subscriber who still struggles would fit the known facts but contradict the prediction.
::::
:::

:::problem[Question III.3]
A librarian says: “The city should offer several short reading circles instead of one long weekly discussion. The present group has no vacancies, and interested residents frequently say they cannot attend at the fixed time. Shorter sessions on different evenings would offer more opportunities without requiring a larger room. Some longtime members worry that friendships would weaken if meetings were divided, but members could still attend multiple sessions. Our central obligation is to make room for interested readers, and changing the schedule is the best practical way to do it.”

Which one of the following most accurately states the main conclusion?

- **(A)** The present reading group has no vacant seats.
- **(B)** Interested residents sometimes cannot attend the fixed meeting time.
- **(C)** The city ought to replace the single weekly discussion with several shorter reading circles.
- **(D)** The city must build a larger library meeting room.
- **(E)** Members would necessarily form stronger friendships in smaller groups.

::::solution[Solution]
**Answer:** (C)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** Split the weekly circle into several shorter sessions.
2. **Support.** Limited capacity and conflicting schedules impede access; multiple sessions are feasible.
3. **Prephrase.** Find the actionable ought-claim that the rest supports.
4. **Why (C) is right.** The speaker gives access, capacity, and friendship-related reasons for a definite restructuring recommendation.
5. **Why the others fail.
   - **(A)** Premise trap: the reading group’s lack of vacancies explains why the librarian recommends scheduling several shorter circles.
   - **(B)** Evidence-as-conclusion trap: residents’ scheduling conflicts are offered as reasons for the proposed multiple-circle policy.
   - **(D)** Contrary proposal: the speaker expressly avoids requiring a larger room.
   - **(E)** Unsupported prediction; the speaker only addresses an objection.

**Check:** The other options supply premises, invent benefits, or recommend the opposite resource solution.
::::
:::

:::problem[Question III.4]
A condominium association replaced its usual quarterly elevator inspections with monthly inspections in two buildings. Those buildings subsequently experienced fewer emergency shutdowns than three buildings still using the quarterly schedule. The board argues that increasing inspection frequency caused the improvement. A resident objects that the pilot buildings had newer elevators and had fewer shutdowns even before the change. The board proposes spending reserve funds to expand the monthly schedule to all buildings over the coming year.

Which one of the following, if true, most strengthens the board’s causal conclusion?

- **(A)** The association has a reserve fund large enough to pay for the plan.
- **(B)** All buildings have a posted list of maintenance contacts.
- **(C)** Residents in all buildings would welcome shorter elevator outages.
- **(D)** The pilot buildings have especially attractive elevator interiors.
- **(E)** The pilot buildings’ shutdown rates fell sharply after the schedule change, while the comparison buildings’ rates stayed near their own earlier levels.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Monthly inspections contributed to fewer shutdowns.
2. **Support.** Treated buildings were newer and initially more reliable.
3. **Prephrase.** Seek difference-in-changes evidence, not just later level differences.
4. **Why (E) is right.** Contrasting changes relative to each building’s own baseline addresses the older-versus-newer equipment objection better than comparing levels alone.
5. **Why the others fail.
   - **(A)** Feasibility is not evidence that inspection frequency caused fewer failures.
   - **(B)** Shared policy offers no variation explaining the decline.
   - **(C)** Preference is not the mechanism or measured effect.
   - **(D)** Appearance does not isolate mechanical outcomes.

**Check:** Improvement uniquely after the intervention weakens the preexisting-age explanation.
::::
:::

:::problem[Question III.5]
At the athletics center, every athlete eligible for the recovery room has completed a safety orientation. No athlete currently serving a suspension is eligible for the recovery room. Some distance runners are eligible, and every eligible distance runner must reserve a slot before entering. No rule states that all athletes who complete orientation become eligible, or that a reservation guarantees eligibility. The staff are checking only what follows from these posted conditions, not from customary practice.

Which one of the following must be true?

- **(A)** No distance runner has ever served a suspension.
- **(B)** Some distance runners who are not suspended have completed the safety orientation.
- **(C)** Some suspended athletes have reserved a slot.
- **(D)** Every oriented athlete may use the recovery room.
- **(E)** Every distance runner who reserves a slot is eligible.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true (Chapter 10)

1. **Conclusion.** Locate a guaranteed eligible distance runner and infer required properties.
2. **Support.** Some runners eligible; eligible → oriented and not currently suspended.
3. **Prephrase.** Combine existential inclusion with two universal conditions.
4. **Why (B) is right.** Because some distance runners are eligible, and eligibility implies both orientation and absence of suspension, at least one such runner exists.
5. **Why the others fail.
   - **(A)** Time and quantifier error: current eligibility does not describe every runner’s history.
   - **(C)** Unsupported existence: nothing entails any suspended reservations.
   - **(D)** Necessary/sufficient reversal: orientation is required but not sufficient.
   - **(E)** Invalid converse: eligible runners need reservations, not vice versa.

**Check:** Choose any eligible distance runner; both properties follow by the posted rules.
::::
:::

:::problem[Question III.6]
An editor recommends increasing an author’s advance because the author’s next novel has already received substantially more bookstore requests than the previous novel did at the same prepublication stage. The editor predicts that final sales will exceed those of the previous novel. Bookstores, however, may request more copies than they ultimately purchase, and the publisher has recently changed the form used to submit requests. The editor has not verified whether the new form encourages duplicate entries or whether duplicate entries are removed from the totals.

Which one of the following is an assumption required by the editor’s reasoning?

- **(A)** The author’s previous novel received no favorable reviews.
- **(B)** The publisher will never alter its request form again.
- **(C)** All bookstores use exactly the same ordering system.
- **(D)** The apparent increase in requests does not result entirely from a counting change that leaves underlying demand unchanged.
- **(E)** Every requested copy will ultimately sell to a reader.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** More recorded requests justify forecasting higher sales.
2. **Support.** A changed form may inflate current totals through duplicates.
3. **Prephrase.** Exclude the possibility that the whole measured increase is merely an artifact.
4. **Why (D) is right.** If the entire increase is a duplication artifact, the cited comparison gives no basis for predicting higher final sales.
5. **Why the others fail.
   - **(A)** Irrelevant comparison: review history is not the evidence cited.
   - **(B)** Future policy has no bearing on whether the current data are comparable.
   - **(C)** Uniformity is unnecessary if the comparison is meaningful.
   - **(E)** Too strong: an increase can predict higher sales despite some cancellations.

**Check:** Negate: all added requests are duplicate entries, so the sole evidence of rising demand vanishes.
::::
:::

:::problem[Question III.7]
A bird sanctuary restored a patch of native shrubs because staff expected it to attract more winter birds. During the following winter, observers recorded more individual birds in the restored patch than in the adjacent unrestored patch. Strangely, the restored patch had fewer distinct species recorded over the same dates. The observers used equal-length watches and worked in both patches at similar times of day. Staff wonder how a habitat improvement could increase the number of birds seen while decreasing the recorded variety of birds.

Which one of the following, if true, most helps to resolve the discrepancy?

- **(A)** A few birds were observed outside the formal watch periods.
- **(B)** Observers wrote species names in notebooks instead of entering them directly into a database.
- **(C)** The sanctuary began selling postcards showing its birds.
- **(D)** The unrestored patch covered about the same area as the restored patch.
- **(E)** One common seed-eating species gathered in large flocks at the new shrubs, while several less common species rarely used the restored patch.

::::solution[Solution]
**Answer:** (E)

**Type:** Paradox (Chapter 13)

1. **Conclusion.** Reconcile higher individual abundance with lower species richness.
2. **Support.** Equal effort yields more birds but fewer types in the restored patch.
3. **Prephrase.** Recognize many individuals of one kind can coexist with fewer kinds overall.
4. **Why (E) is right.** A large concentration of one species boosts individual counts while a lack of other species reduces species richness; the two measures need not move together.
5. **Why the others fail.
   - **(A)** Uncounted sightings do not explain the documented in-period pattern.
   - **(B)** Recording medium does not explain opposing count patterns.
   - **(C)** Unrelated-activity trap: souvenir sales have no causal connection to the equal-effort winter bird counts or species variety.
   - **(D)** Area similarity removes one possible confound but does not resolve the disparity.

**Check:** A flocked dominant species directly produces the contrasting metrics.
::::
:::

:::problem[Question III.8]
A strength coach tested a new hydration reminder at the start of summer training and noticed that athletes’ times on a short agility course improved during the next month. He concludes that the reminder caused the improvement because the same athletes took the same course. Yet the team also introduced a new footwork routine, and athletes repeated the course frequently enough to become familiar with its turns. The coach dismisses both possibilities because neither program required buying equipment, whereas the hydration reminder used a paid mobile application.

The argument is most vulnerable to criticism because it…

- **(A)** dismisses plausible alternative causes of improvement for a reason unrelated to their causal relevance.
- **(B)** bases its conclusion on a logical contradiction in the rules of agility courses.
- **(C)** claims the hydration reminder was the only change in the training program.
- **(D)** assumes that paid applications cannot improve performance.
- **(E)** uses the athletes’ own course times rather than times from a rival team.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The paid reminder caused the agility improvement.
2. **Support.** Footwork work and practice familiarity are plausible alternatives.
3. **Prephrase.** Identify an irrelevant price-based dismissal of alternative causes.
4. **Why (A) is right.** Cost of an intervention does not show that it, rather than footwork training or repeated practice, caused the improved times.
5. **Why the others fail.
   - **(B)** Invented contradiction: no inconsistency in the course rules is supplied.
   - **(C)** Subtle misdescription: the coach acknowledges other changes but wrongly dismisses them.
   - **(D)** Opposite: the coach attributes improvement to the paid application.
   - **(E)** Wrong target: repeated measures can be useful, though they are confounded here.

**Check:** An unpaid routine could still improve agility; cost has no logical causal priority.
::::
:::

:::problem[Question III.9]
A teacher says: “The district cites a survey showing that most respondents favor later school start times. But the survey was sent only to parents who had previously subscribed to a newsletter advocating later starts. It does tell us what those respondents think; it does not establish what the district’s parents as a whole think. Before making a districtwide claim, the board should sample parents who did not choose to join that newsletter as well.” The teacher makes no claim about whether later start times are beneficial.

The teacher’s argument primarily does which one of the following?

- **(A)** shows that supporters of later start times are mistaken about sleep.
- **(B)** refutes the reported majority among survey respondents.
- **(C)** concludes that a random survey must find a majority opposed.
- **(D)** distinguishes a finding about respondents from a broader claim about the population from which they were selected.
- **(E)** argues that every newsletter subscriber answered the survey.

::::solution[Solution]
**Answer:** (D)

**Type:** Method (Chapter 11)

1. **Conclusion.** The districtwide extrapolation is unsupported.
2. **Support.** Respondents came from a self-selected advocacy-newsletter group.
3. **Prephrase.** Separate internal sample accuracy from external representativeness.
4. **Why (D) is right.** The teacher accepts the within-sample result but challenges the inference to all parents because the selection method is biased.
5. **Why the others fail.
   - **(A)** Out-of-scope substantive claim: no benefits or drawbacks of starts are discussed.
   - **(B)** Opposite: the sample result is explicitly accepted.
   - **(C)** Unwarranted forecast: a representative survey could favor either side.
   - **(E)** Invented response rate: the teacher speaks only about respondents.

**Check:** The teacher preserves the reported survey result while rejecting its population inference.
::::
:::

:::problem[Question III.10]
A city library adopts a review rule: a book may be removed from general circulation for factual inaccuracy only if an independent reviewer identifies a specific material error and the publisher is given a chance to respond. Complaints alleging merely that a book’s interpretation is unpopular do not satisfy the rule. A patron objects to a local-history book because its account of the town’s growth conflicts with the patron’s family stories. No independent reviewer has examined the book, and no alleged error has yet been identified with supporting evidence.

Which one of the following actions is most consistent with the rule?

- **(A)** Require the publisher to prove that every sentence in the book is correct.
- **(B)** Immediately remove the book because the patron’s family history is firsthand testimony.
- **(C)** Forbid the patron from submitting evidence in the future.
- **(D)** Keep the book in circulation unless the specified factual review and response process is completed.
- **(E)** Remove the book temporarily whenever a complaint is filed.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** No removal on present facts.
2. **Support.** A complaint about interpretation lacks independent finding and publisher response.
3. **Prephrase.** Apply both necessary prerequisites of the removal rule.
4. **Why (D) is right.** Neither the specific verified error nor opportunity for publisher response exists; disagreement with an interpretation cannot itself trigger removal.
5. **Why the others fail.
   - **(A)** Burden shift and overreach: the rule begins with a specific identified error.
   - **(B)** Source-appeal trap: family testimony does not meet the two procedural conditions.
   - **(C)** Too restrictive: the rule does not prohibit future evidence or review.
   - **(E)** Wrong threshold: the rule requires a reviewer’s material error finding.

**Check:** Neither specified requirement has been satisfied.
::::
:::

:::problem[Question III.11]
A shopkeepers’ association claims that converting curbside parking into a bicycle lane will reduce total sales on Elm Street. Before construction, an association survey found that many customers arrived by car, and the board assumes those customers will stop shopping if the nearby spaces disappear. Yet the street will retain two public parking lots within a short walk, and the proposed lane will connect several neighborhoods directly to the shopping block. The association has not estimated how shoppers might change their routes or travel modes.

Which one of the following, if true, most weakens the association’s prediction?

- **(A)** The proposed lane will require painted pavement markings.
- **(B)** Stores sell different categories of merchandise.
- **(C)** In a comparable street conversion, lost curbside parking was offset by new bicycle and walking customers, and aggregate store receipts did not decline.
- **(D)** The association’s survey asked customers about shopping frequency.
- **(E)** Some existing customers prefer driving to bicycling.

::::solution[Solution]
**Answer:** (C)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Loss of curb parking will reduce total street sales.
2. **Support.** Car arrival was common but substitute access and new customers were ignored.
3. **Prephrase.** Find analogous evidence of replacement trips maintaining aggregate receipts.
4. **Why (C) is right.** This bears directly on the missing substitution mechanism and the total-sales prediction rather than just travel preferences.
5. **Why the others fail.
   - **(A)** Implementation detail with no sales implication.
   - **(B)** General heterogeneity does not show the total will be maintained.
   - **(D)** Questionnaire detail does not overturn the asserted sales effect.
   - **(E)** Already consistent with the association’s premise; says nothing about replacement trips.

**Check:** Stable total receipts after a comparable change directly counters the predicted loss.
::::
:::

:::problem[Question III.12]
At the university’s continuing-education office, every seminar carrying the advanced designation qualifies for professional-development credit. Any seminar that qualifies for that credit is listed in the annual credential catalog. Maya enrolled in a seminar entitled “Spatial Data for Builders,” but the registrar has not said whether its advanced-sounding title corresponds to the official designation. The office director concludes that Maya’s seminar will appear in the credential catalog. Merely having a technical title has no stated consequence under the office rules.

Which one of the following, if assumed, makes the director’s conclusion follow logically?

- **(A)** Maya hopes to use the seminar toward a later certification.
- **(B)** Every catalog-listed seminar has a technical title.
- **(C)** At least one advanced seminar concerns spatial data.
- **(D)** The seminar in which Maya enrolled carries the office’s official advanced designation.
- **(E)** No seminar lacking credit can be placed in the catalog.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Maya’s seminar is catalog-listed.
2. **Support.** Advanced designation guarantees credit and credit guarantees catalog listing.
3. **Prephrase.** Supply this seminar’s designation status.
4. **Why (D) is right.** Official advanced → credit-qualifying → catalog listing. This inserted fact starts the valid conditional chain.
5. **Why the others fail.
   - **(A)** Intention has no bearing on official qualification.
   - **(B)** Reverse-direction trap: tells us about listed items, not Maya’s.
   - **(C)** Existential substitution: not necessarily Maya’s seminar.
   - **(E)** Necessary condition for listing still fails to establish this seminar qualifies.

**Check:** Substitute the new premise and apply both arrows in order.
::::
:::

:::problem[Question III.13]
A reporter argues that a correction must be issued for a profile that described a researcher as the founder of a laboratory. “The laboratory already existed when she joined,” the reporter says. “She later reorganized it and supervised important projects, and none of those accomplishments is in doubt. But the specific claim that she founded it remains inaccurate, and the newspaper’s correction policy concerns particular factual claims, not whether the subject deserves public recognition.” The editor agrees that the researcher made valuable contributions but wonders whether a correction might understate them.

In the reporter’s argument, the claim about the researcher’s later accomplishments serves primarily to…

- **(A)** acknowledge a fact compatible with the reporter’s conclusion so that it cannot be mistaken for a reason to retain the error.
- **(B)** identify the newspaper’s only factual error in its entire edition.
- **(C)** supply evidence that she established the laboratory.
- **(D)** prove that readers prefer profiles celebrating accomplishments.
- **(E)** show that the newspaper’s correction policy is unnecessary.

::::solution[Solution]
**Answer:** (A)

**Type:** Role (Chapter 11)

1. **Conclusion.** The “founder” claim should be corrected.
2. **Support.** Existing lab predates her arrival; her later accomplishments do not change that.
3. **Prephrase.** Classify positive achievements as a concession with limited relevance.
4. **Why (A) is right.** The reporter concedes those merits while separating them from the narrow factual issue of founding the lab.
5. **Why the others fail.
   - **(B)** Scope exaggeration: only the profile’s one claim is discussed.
   - **(C)** Opposite of the point: contributions occurred after the lab existed.
   - **(D)** Unsupported-reaction trap: the reporter concedes a researcher’s achievements but never makes any claim about what readers prefer.
   - **(E)** Contrary to the conclusion: the reporter invokes that policy.

**Check:** Both sides can accept her contributions while the founding statement remains false.
::::
:::

:::problem[Question III.14]
A horticulture club claims that placing native flowering pots on apartment balconies increases visits by pollinating insects to neighboring rooftop planters. In a club demonstration, the roof with more flowering balconies had more insect visits than a nearby roof with fewer such balconies. But the busier roof also stood beside a municipal garden, and observers counted visits on different days. Club members now propose a neighborhood-scale balcony planting campaign based on the apparent attraction effect.

Which one of the following, if true, most strengthens the club’s explanation?

- **(A)** Municipal gardeners also plant some flowers each spring.
- **(B)** The two original roofs were painted similar shades.
- **(C)** Residents reported enjoying the flowers.
- **(D)** The club offered discounts on decorative pots.
- **(E)** When identical flowering pots were added to alternating balconies of one building, visits to its rooftop planters rose relative to a similar unchanged building observed on the same days.

::::solution[Solution]
**Answer:** (E)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Flowering balconies attract additional insect visits to rooftop planters.
2. **Support.** Initial comparison is confounded by municipal garden and different observation days.
3. **Prephrase.** Look for a matched intervention and synchronous control.
4. **Why (E) is right.** A controlled before/after contrast addresses municipal-garden proximity and day-to-day conditions, connecting the proposed plantings to insect visits.
5. **Why the others fail.
   - **(A)** Further alternative cause rather than direct support of balcony effects.
   - **(B)** Minor similarity does not control the garden or observation-day confounds.
   - **(C)** Outcome-switch trap: residents enjoying flowers does not establish that adding balcony flowers increases pollinator visits to the roof.
   - **(D)** Sales policy does not establish an effect on pollinator visits.

**Check:** The treated building’s relative increase after pots are added favors the causal effect.
::::
:::

:::problem[Question III.15]
A housing commentator points out that the median sale price of houses in a district declined after several small new homes were completed. She concludes that the construction forced sellers of existing houses to accept lower prices. But the new, smaller houses were included in the later districtwide median, while the earlier median represented almost exclusively larger houses. The commentator has not compared the sale prices of similar existing houses across the two periods. Even if no existing house changed value, adding cheaper properties could lower the overall median.

The reasoning is flawed because it…

- **(A)** infers that prices cannot ever rise again after declining.
- **(B)** confuses a change in the composition of sales with a change in the prices commanded by comparable existing properties.
- **(C)** assumes that every new small home sells for exactly the same price.
- **(D)** relies on home buyers’ survey responses rather than sale prices.
- **(E)** treats the lowest price in the district as equal to the median price.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** New construction lowered prices for existing homes.
2. **Support.** The median pooled different sizes and sales compositions.
3. **Prephrase.** Identify a composition effect mistaken for a within-type price change.
4. **Why (B) is right.** An aggregate median may fall when a new low-price category enters the measured set, without any existing property losing value.
5. **Why the others fail.
   - **(A)** Invented-forecast trap: the commentator claims construction lowered existing-home prices, not that prices will never rise again.
   - **(C)** Unnecessary: mix changes can affect the median even with variable prices.
   - **(D)** Wrong data type: the reported statistic is actual sale price.
   - **(E)** Invented statistical error: those measures are not conflated in the text.

**Check:** Hold comparable old-home prices fixed and add cheaper new-home sales: median may fall.
::::
:::

:::problem[Question III.16]
A citizen-science group introduced an optional app that prompts observers to describe habitat before submitting a bird sighting. In its first month, the proportion of submitted reports with habitat notes increased. However, total submissions declined, and staff found that several experienced observers had switched from the app to the website, where notes are optional. The group also found that most new app users submitted at least one report. It has not independently assessed whether the added habitat descriptions are accurate.

Which one of the following is most strongly supported by the information above?

- **(A)** Experienced observers wrote no habitat notes after switching to the website.
- **(B)** The app caused every observer to report fewer sightings.
- **(C)** Most submitted habitat descriptions were false.
- **(D)** Total submissions would recover if the website were removed.
- **(E)** The rise in the percentage of reports with habitat notes does not by itself establish that observers became more accurate.

::::solution[Solution]
**Answer:** (E)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** Choose a cautious inference about report completeness versus correctness.
2. **Support.** More reports have notes, fewer reports total, and note accuracy was not independently tested.
3. **Prephrase.** Separate presence of information from truth of information.
4. **Why (E) is right.** The app altered reporting patterns, but accuracy was not checked; an increased proportion of completed fields cannot establish quality.
5. **Why the others fail.
   - **(A)** Too-strong inference: website notes were optional, so experienced observers might still have supplied them after switching platforms.
   - **(B)** Universal cause trap: group totals decreased, not necessarily every individual’s reports.
   - **(C)** Opposite unsupported extreme: accuracy is unmeasured.
   - **(D)** Unwarranted forecast about a hypothetical policy.

**Check:** All the data can hold even if some or many descriptions are inaccurate.
::::
:::

:::problem[Question III.17]
A department chair urges replacing live review sessions with recordings of last year’s sessions. The chair argues that every question students are likely to ask this semester was covered in last year’s sessions, so recordings will provide the same academic help without requiring instructors to repeat themselves. Yet the course adopted different reading assignments and a new grading rubric this semester. The chair has not compared the old sessions with questions arising from those changes and is relying on apparent overlap in the basic subject matter.

The argument depends on assuming which one of the following?

- **(A)** No recording contains an error of pronunciation.
- **(B)** The university has eliminated all limits on video storage.
- **(C)** Every student prefers recordings to speaking with an instructor.
- **(D)** The chair teaches every course in the department.
- **(E)** The changed assignments and rubric will not create any important review needs that the existing recordings fail to address.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Recordings will provide the same help as live reviews.
2. **Support.** Old recordings cover old questions, but new assignments and rubric may create new needs.
3. **Prephrase.** Rule out important new needs unaddressed by old recordings.
4. **Why (E) is right.** If the new requirements generate material unanswered needs, recordings cannot provide the same help as responsive live sessions.
5. **Why the others fail.
   - **(A)** Irrelevant quality detail: pronunciation errors are not the identified gap.
   - **(B)** Implementation detail does not establish informational sufficiency.
   - **(C)** Overstrong preference condition unnecessary for equivalence of academic help.
   - **(D)** Personal authority trap: teacher coverage does not settle content equivalence.

**Check:** Negating the answer produces a consequential unmet need, contradicting equivalence.
::::
:::

:::problem[Question III.18]
Every race certified by the club’s safety committee is listed on the public calendar. No race listed on that calendar may use an unmarked route. The Harbor Loop has been certified by the committee. Consequently, the Harbor Loop may not use an unmarked route. The argument does not depend on whether other races are calendar-listed for different reasons; it follows the rules governing this particular certified event.

Which one of the following arguments most closely parallels the reasoning above?

- **(A)** Some archived drawings are restored; all restored drawings are labeled; therefore all archived drawings are labeled.
- **(B)** Every grant approved by the council is posted online; no grant posted online is confidential; the Elm Grant was approved, so it is not confidential.
- **(C)** Every licensed vendor has a permit; Kay has a permit, so Kay is licensed.
- **(D)** No closed road permits trucks; the service road is not closed, so trucks may use it.
- **(E)** All finalists are interviewed, but this student was not interviewed, so this student is not a finalist.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Harbor Loop cannot use an unmarked route.
2. **Support.** Certified → listed; listed → marked-route requirement.
3. **Prephrase.** Find two chained inclusions ending in exclusion.
4. **Why (B) is right.** Both arguments chain an affirmative inclusion with a negative rule: approved/certified → posted/listed → not confidential/unmarked.
5. **Why the others fail.
   - **(A)** Quantifier trap: some archived drawings being restored cannot establish that all archived drawings have labels.
   - **(C)** Invalid converse rather than a valid two-step chain.
   - **(D)** Inverse-error trap: a rule about closed roads does not tell us what trucks may do on open roads; the stimulus instead uses a valid chained rule.
   - **(E)** Valid contrapositive but a single direct conditional, not the two-step positive-negative chain.

**Check:** The council-grant reasoning duplicates the two arrows, including the negative final property.
::::
:::

:::problem[Question III.19]
Editor Leila: “Anonymous submissions should be permitted in the campus literary review. Blind review will prevent a reviewer from favoring familiar names, even though identity may sometimes help assess an author’s experience.” Editor Nolan: “Favoritism is a concern, but I oppose anonymity. Reviewers should evaluate how authors use their stated experiences, and hiding identities would make that task harder. We ought to manage bias through reviewer training instead.” Neither editor proposes abolishing review or allowing authors to choose their own reviewers.

The editors disagree about whether…

- **(A)** favoritism among reviewers is a legitimate concern.
- **(B)** an author’s experiences may matter to an evaluation.
- **(C)** the literary review should allow submissions that conceal their authors’ identities.
- **(D)** authors are currently permitted to select the reviewers of their work.
- **(E)** all campus publications should use the same anonymous-review system.

::::solution[Solution]
**Answer:** (C)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Anonymity should be allowed or disallowed.
2. **Support.** Leila yes to anonymous submissions; Nolan no, preferring training.
3. **Prephrase.** Ask for a binary proposition each explicitly evaluates.
4. **Why (C) is right.** Leila explicitly endorses anonymity and Nolan opposes it; both have definite opposing stances on the same policy.
5. **Why the others fail.
   - **(A)** Shared ground: Nolan explicitly concedes it; Leila also worries about it.
   - **(B)** Shared or not disputed: Leila concedes experience can matter and Nolan emphasizes it.
   - **(D)** Unaddressed fact: the speakers only reject that as a proposal.
   - **(E)** Scope-extension trap: the two editors debate their own campus review, not a common procedure for all campus publications.

**Check:** The speakers’ policy recommendations conflict directly while other issues are shared or unaddressed.
::::
:::

:::problem[Question III.20]
A seller claims that her house must be worth at least as much as the highest-priced house sold anywhere in the town last month. “Both properties have three bedrooms,” she explains. “The comparison house’s expensive waterfront lot, larger floor area, and recent structural upgrades do not change the bedroom count. Therefore its price is the correct minimum for mine.” She does not consider whether the other characteristics explain the price difference. Her argument is not that her house is identical to every other house, only that matching bedrooms settles the value comparison.

The argument is most vulnerable to criticism because it…

- **(A)** assumes that similarity in one feature makes other potentially price-relevant differences immaterial.
- **(B)** compares houses that were sold in different decades.
- **(C)** requires that her house have more bedrooms than the comparison property.
- **(D)** concludes that waterfront property is always undesirable.
- **(E)** relies on a legal rule requiring houses to sell at their appraised values.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Her house is worth at least the other house’s highest price.
2. **Support.** One matching attribute is treated as sufficient despite major differences.
3. **Prephrase.** Spot false comparability based on one shared trait.
4. **Why (A) is right.** Shared bedroom count cannot by itself justify a price floor when land, area, and condition differ substantially.
5. **Why the others fail.
   - **(B)** Misreported timing: the comparison sale occurred last month.
   - **(C)** Contrary premise: she explicitly says both have three.
   - **(D)** Opposite of the concern: waterfront may explain the higher price.
   - **(E)** Invented rule: no appraisal or legal price floor is discussed.

**Check:** Two three-bedroom houses may command different prices for the stipulated reasons.
::::
:::

:::problem[Question III.21]
A school administrator argues that an automated translation line can replace the district’s human interpreter at parent conferences. During a demonstration, the line successfully handled routine scheduling questions in each language the district tested. The administrator concludes it can handle all important conversations that arise in parent conferences. Yet some conferences involve unfamiliar educational terminology, and the demonstration included no discussion of specialized learning plans, disciplinary disputes, or confidential matters. The administrator expects the same tool to be used without a human backup.

Which one of the following is an assumption on which the argument depends?

- **(A)** No parent will ever disagree with a school administrator.
- **(B)** There will not be a type of important conference conversation that the automated line cannot handle adequately.
- **(C)** The district will stop discussing student learning plans.
- **(D)** Every family prefers automated translation.
- **(E)** The line translates routine scheduling questions more rapidly than every human interpreter.

::::solution[Solution]
**Answer:** (B)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The line adequately handles every important conference conversation.
2. **Support.** Successful routine test is generalized to untested specialized discussions.
3. **Prephrase.** The argument needs no important counterexample to coverage.
4. **Why (B) is right.** The replacement recommendation requires broad adequacy; a single important unsupported category defeats the all-important-conversations conclusion.
5. **Why the others fail.
   - **(A)** Extraneous extreme: disagreement can occur even with adequate translation.
   - **(C)** Unnecessary drastic policy: the technology could in principle handle such topics.
   - **(D)** Preference cannot substitute for conversational coverage.
   - **(E)** Too strong and wrong metric: speed is not needed to show adequacy.

**Check:** Negate: an important unhandled conversation exists, directly falsifying the universal adequacy claim.
::::
:::

:::problem[Question III.22]
A city parks office states that when two groups request the same field at the same time, the group that has used the field fewer times during the current season receives priority, provided both applications meet the posted deadline. A late application is ineligible for that slot, and the office applies the same deadline to every group. This week the adult softball association and a youth running group request the same Saturday slot. The softball association used the field six times and applied on time; the youth group used it twice but applied one day late.

Which one of the following decisions best follows the stated policy?

- **(A)** Give the softball association the slot because the youth group missed the deadline that limits the fewer-uses preference.
- **(B)** Give the youth group the field because two uses are fewer than six.
- **(C)** Divide the field into equal halves throughout the game.
- **(D)** Cancel the slot because neither group has an absolute right to it.
- **(E)** Give the field to whichever group has more members.

::::solution[Solution]
**Answer:** (A)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Choose the timely application despite the rival’s lower use count.
2. **Support.** Youth fewer uses but is late; adult group on time.
3. **Prephrase.** Apply the exception before the default preference.
4. **Why (A) is right.** Lower historical use provides priority only when the competing application is not late; the youth application fails that condition.
5. **Why the others fail.
   - **(B)** Half-right trap: ignores the explicit deadline exception.
   - **(C)** Invented compromise with no support in the priority rule.
   - **(D)** Invented rule: the policy resolves competing applications.
   - **(E)** Unauthorized-criterion trap: the stated allocation policy compares prior field use and deadline compliance, not membership totals.

**Check:** The exception removes the late youth group’s use-count priority.
::::
:::

:::problem[Question III.23]
A museum director argues that every exhibition that won the regional visitors’ award featured an extensive audio guide. It follows, she says, that any exhibition provided with an extensive audio guide will win that award. She wants to spend the entire promotion budget on audio production, even though many exhibitions with audio guides were never considered for the award. The director has no evidence that the guide rather than curatorial selection explains the association.

Which one of the following arguments exhibits the same flawed pattern?

- **(A)** No paintings in the storage room are on display; this painting is displayed, so it is not in storage.
- **(B)** Every championship rowing crew in the league used a particular timing app; therefore any crew using the app will win the championship.
- **(C)** Some well-reviewed books have indexes; one book has an index, so it could be reviewed well.
- **(D)** Any employee who passes the security exam receives an ID; Jo passed, so Jo receives one.
- **(E)** Every winner trained regularly; this athlete did not train regularly, so the athlete did not win.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** An extensive guide guarantees award success.
2. **Support.** All award winners have guides; no evidence all guide users are winners.
3. **Prephrase.** Match illicit conversion of success → feature into feature → success.
4. **Why (B) is right.** Both infer feature → success from the observed success → feature, affirming the consequent with universal force.
5. **Why the others fail.
   - **(A)** Valid-form trap: displayed → not in storage follows from no stored painting being displayed; it does not affirm the consequent.
   - **(C)** Possibility claim is not a guarantee from all success cases.
   - **(D)** Valid-form trap: an employee passed an exam that guarantees an ID, so the conclusion follows directly without reversing the condition.
   - **(E)** Valid-contrapositive trap: winner → trained legitimately implies not trained → not winner, unlike the director’s invalid reversal.

**Check:** A guide-equipped nonwinner is consistent with premise but contradicts conclusion.
::::
:::

:::problem[Question III.24]
In a fictional town’s zoning procedure, any proposal that would convert a residential lot to mixed use must receive a public hearing. Any proposal receiving a public hearing must be placed on the clerk’s monthly agenda. A developer’s submission concerns a vacant lot whose current zoning classification is uncertain. The clerk concludes that the submission must appear on the monthly agenda, but the file says only that the developer hopes to construct apartments over retail space. The clerk has not established the lot’s present zoning.

Which one of the following, if assumed, allows the clerk’s conclusion to be properly drawn?

- **(A)** The developer prefers a hearing to a written staff review.
- **(B)** Every agenda-listed project concerns land with a known zoning history.
- **(C)** Most projects combining apartments and retail are popular with residents.
- **(D)** The developer’s submission would convert a residentially zoned lot to mixed use.
- **(E)** Some mixed-use proposals were placed on last month’s agenda.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** The developer’s proposal must be on the agenda.
2. **Support.** Residential-to-mixed conversion → hearing → agenda; existing zoning unknown.
3. **Prephrase.** Supply the triggering current-zoning fact.
4. **Why (D) is right.** That classification triggers a mandatory hearing, which triggers a mandatory agenda listing.
5. **Why the others fail.
   - **(A)** Preference cannot satisfy the specified condition.
   - **(B)** Reverse implication: gives a property of listed projects, not a reason to list this one.
   - **(C)** Wrong-criterion trap: the fictional procedure requires a residential-to-mixed-use conversion, not majority support among residents.
   - **(E)** Existential example cannot establish this proposal’s status.

**Check:** Assume conversion classification and apply both procedural rules.
::::
:::

:::problem[Question III.25]
A school district bought an automatic essay-feedback system and reports that teachers now spend fewer hours writing comments. The procurement director argues that this proves the program saves the district money and should be renewed. The district paid an annual licensing fee, teachers received paid training, and some teachers used the freed time for additional student conferences rather than reducing paid hours. The director has measured time spent commenting but has not measured changes in payroll, conference staffing, or other expenditures. The renewal decision concerns total cost, not convenience alone.

The answer to which one of the following questions would be most useful in evaluating the director’s argument?

- **(A)** Did the time saved on comments actually reduce paid staffing expenditures by more than the licensing and training costs?
- **(B)** Do students enjoy the interface’s color scheme?
- **(C)** Do teachers prefer typed feedback to handwritten comments?
- **(D)** Were some teachers initially skeptical about using the system?
- **(E)** Did the vendor publish a white paper describing its features?

::::solution[Solution]
**Answer:** (A)

**Type:** Evaluate (Chapter 8)

1. **Conclusion.** The program saved money and merits renewal for cost reasons.
2. **Support.** Writing-comment hours declined but license, training, and payroll effects are unknown.
3. **Prephrase.** Test whether the documented time savings translate to actual net budget savings once the purchased system’s costs are included.
4. **Why (A) is right.** This tests the cost-saving mechanism: saved staff time matters financially only insofar as it reduces spending enough to outweigh the program’s costs.
5. **Why the others fail.
   - **(B)** Aesthetic reaction does not measure the budget effect.
   - **(C)** Preference and format are not districtwide money savings.
   - **(D)** Attitudes are irrelevant to whether total expenditure declined.
   - **(E)** Vendor description is no substitute for actual cost measurement.

**Check:** If payroll savings exceed licensing and training expenses, the cost rationale gains support; if not, fewer comment hours do not establish savings.
::::
:::

## 34.4 Scoring and review

Open the answer key only after completing timed work and blind review. Each correct response earns one raw point; there is no penalty for an incorrect response.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| I.1 | D | Strengthen | Chapter 8 |
| I.2 | D | Flaw | Chapter 9 |
| I.3 | E | Must be true | Chapter 10 |
| I.4 | E | Necessary assumption | Chapter 7 |
| I.5 | C | Main conclusion | Chapter 4 |
| I.6 | A | Weaken | Chapter 8 |
| I.7 | B | Role | Chapter 11 |
| I.8 | A | Principle | Chapter 13 |
| I.9 | D | Flaw | Chapter 9 |
| I.10 | D | Sufficient assumption | Chapter 7 |
| I.11 | A | Paradox | Chapter 13 |
| I.12 | B | Strengthen | Chapter 8 |
| I.13 | D | Method | Chapter 11 |
| I.14 | C | Flaw | Chapter 9 |
| I.15 | B | Most strongly supported | Chapter 10 |
| I.16 | B | Necessary assumption | Chapter 7 |
| I.17 | B | Parallel reasoning | Chapter 12 |
| I.18 | E | Weaken | Chapter 8 |
| I.19 | E | Point at issue | Chapter 11 |
| I.20 | C | Flaw | Chapter 9 |
| I.21 | C | Principle | Chapter 13 |
| I.22 | A | Necessary assumption | Chapter 7 |
| I.23 | A | Parallel flaw | Chapter 12 |
| I.24 | C | Sufficient assumption | Chapter 7 |
| I.25 | E | Evaluate | Chapter 8 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| II.1 | D | RC main point | Chapter 18 |
| II.2 | E | RC detail | Chapter 18 |
| II.3 | A | RC function | Chapter 18 |
| II.4 | D | RC inference | Chapter 18 |
| II.5 | C | RC application | Chapter 18 |
| II.6 | D | RC attitude | Chapter 18 |
| II.7 | C | RC detail | Chapter 18 |
| II.8 | C | RC main point | Chapter 18 |
| II.9 | E | RC detail | Chapter 18 |
| II.10 | B | RC inference | Chapter 18 |
| II.11 | B | RC function | Chapter 18 |
| II.12 | B | RC application | Chapter 18 |
| II.13 | A | RC attitude | Chapter 18 |
| II.14 | B | RC function | Chapter 18 |
| II.15 | C | RC main point | Chapter 18 |
| II.16 | D | RC detail | Chapter 18 |
| II.17 | A | RC function | Chapter 18 |
| II.18 | C | RC inference | Chapter 18 |
| II.19 | E | RC application | Chapter 18 |
| II.20 | B | RC attitude | Chapter 18 |
| II.21 | A | Comparative relationship | Chapter 17 |
| II.22 | E | Comparative agreement | Chapter 17 |
| II.23 | D | Comparative disagreement | Chapter 17 |
| II.24 | E | Comparative author response | Chapter 17 |
| II.25 | A | Comparative function | Chapter 17 |
| II.26 | A | Comparative inference | Chapter 17 |
| II.27 | B | Comparative application | Chapter 17 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | --- | --- | --- |
| III.1 | C | Weaken | Chapter 8 |
| III.2 | C | Flaw | Chapter 9 |
| III.3 | C | Main conclusion | Chapter 4 |
| III.4 | E | Strengthen | Chapter 8 |
| III.5 | B | Must be true | Chapter 10 |
| III.6 | D | Necessary assumption | Chapter 7 |
| III.7 | E | Paradox | Chapter 13 |
| III.8 | A | Flaw | Chapter 9 |
| III.9 | D | Method | Chapter 11 |
| III.10 | D | Principle | Chapter 13 |
| III.11 | C | Weaken | Chapter 8 |
| III.12 | D | Sufficient assumption | Chapter 7 |
| III.13 | A | Role | Chapter 11 |
| III.14 | E | Strengthen | Chapter 8 |
| III.15 | B | Flaw | Chapter 9 |
| III.16 | E | Most strongly supported | Chapter 10 |
| III.17 | E | Necessary assumption | Chapter 7 |
| III.18 | B | Parallel reasoning | Chapter 12 |
| III.19 | C | Point at issue | Chapter 11 |
| III.20 | A | Flaw | Chapter 9 |
| III.21 | B | Necessary assumption | Chapter 7 |
| III.22 | A | Principle | Chapter 13 |
| III.23 | B | Parallel flaw | Chapter 12 |
| III.24 | D | Sufficient assumption | Chapter 7 |
| III.25 | A | Evaluate | Chapter 8 |
:::

**Raw score:** number correct out of **77**. Section scores are out of 25 (I), 27 (II), and 25 (III). This original test has not been statistically equated; do **not** convert your raw result to an official 120–180 LSAT score. Use it to spot patterns of errors and to measure improvement across comparable practice.

| Missed question type | Review chapter |
| --- | --- |
| Conclusions, premises, argument foundations | Chapter 4 |
| Conditional chains and quantifiers | Chapter 5 |
| Flaw catalog | Chapter 6 |
| Necessary and sufficient assumptions | Chapter 7 |
| Strengthen, weaken, evaluate | Chapter 8 |
| Flaw questions | Chapter 9 |
| Must be true, most strongly supported | Chapter 10 |
| Method, role, point at issue | Chapter 11 |
| Parallel reasoning and parallel flaw | Chapter 12 |
| Paradox and principle | Chapter 13 |
| Passage structure and main idea | Chapter 15 |
| Comparative Reading | Chapter 17 |
| RC detail, inference, tone, function, application | Chapter 18 |
| Blind review and error log | Chapters 22–23 |

When reviewing, write a one-sentence reason for the correct answer and a specific reason each other answer fails. Prioritize repeated error patterns rather than treating every miss as equally informative.
