---
title: "Practice Test 5"
source: "markdown"
---

Part VI · Chapter 32

# Practice Test 5

A demanding original LSAT practice test emphasizing precise conditional reasoning, causal alternatives, and close comparative reading.

## Overview

Work through three scored sections in one sitting: **35 minutes for Section I**, **35 minutes for Section II**, a **10-minute break**, then **35 minutes for Section III**. Do not open a solution or the answer key until all three sections are finished. This is a 77-question scored-core simulation, not the four-section official administration with its additional experimental section.

**Flag, do not guess silently.** Record every question number on which you feel uncertain, even if you choose an answer. After timing, blind-review those questions without the key (Chapter 22). Only then reveal the solutions, record misses and lucky guesses in your error log (Chapter 23), and revisit the relevant lesson.

All questions and passages here are original and are **not** an official LSAC PrepTest. Official LawHub PrepTests remain the gold standard for timed calibration (Chapter 24).

## 32.1 Section I: Logical Reasoning

:::problem[Question I.1]
A lender compared manufacturers that sold their unpaid invoices to factoring firms with manufacturers that did not. In the following year, the factoring clients had substantially higher rates of insolvency. The lender concluded that factoring itself weakens manufacturers, probably because the discount at which invoices are sold erodes margins. But clients often turn to factoring when customers begin paying late, and the comparison did not record whether either group had experienced payment delays before the year began. The lender nevertheless recommends that otherwise healthy firms avoid factoring as a threat to their solvency.

The lender’s argument is most vulnerable to criticism on the grounds that it

- **(A)** treats factoring discounts as the sole possible explanation for the higher insolvency rate, even though the lender describes them only as a probable mechanism.
- **(B)** does not adequately consider that financial distress could lead firms to seek factoring rather than result from factoring.
- **(C)** fails to compare the discounts charged by factoring firms with the interest rates manufacturers would face on ordinary bank loans.
- **(D)** mistakes a higher rate of insolvency for evidence that every factoring client failed.
- **(E)** assumes that two groups are financially identical merely because both manufacture goods.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The recommendation depends on factoring causing financial deterioration.
2. **Support.** The correlation compares subsequent failures but ignores the financial condition that prompted factoring.
3. **Prephrase.** Look for reverse causation, not an objection to factoring's price alone.
4. **Why (B) is right.** Choice (B) describes the live alternative: late-paying customers could damage cash flow, causing both factoring and later insolvency. The observed association is compatible with that sequence.
5. **Why the others fail.**
   - **(A)** The lender proposes a probable mechanism but does not insist discounts are the only conceivable cause. The real defect is the untested direction of causation.
   - **(C)** This wrong-comparison choice concerns the relative price of finance. Even an unusually high factoring discount would not answer whether struggling firms selected into factoring before they failed.
   - **(D)** (D) is a quantifier trap: the argument says rates are higher, not that all clients fail.
   - **(E)** (E) overstates the required comparability; the specific missing variable is prior distress, not identical firms in every respect.

**Check:** Put distress before factoring in the causal diagram; the same data remain possible.
::::
:::

:::problem[Question I.2]
A distributor is considering replacing weekly manual temperature inspections with an automated system. Its pilot warehouses recorded substantially fewer spoiled shipments after installing sensors that alert staff when storage rooms exceed a temperature threshold. Management proposes installing sensors everywhere and eliminating inspections, arguing that the alerts can prevent spoilage at least as effectively as inspections did. The pilot, however, retained its inspections during the trial. The proposed savings come almost entirely from stopping those inspections, not from lowering spoilage during a period in which both methods operate.

Which one of the following is an assumption on which management’s argument depends?

- **(A)** At least 90 percent of the automated warnings in the pilot prompted a documented staff response.
- **(B)** Automated alerts cost less to maintain than all manual warehouse procedures combined.
- **(C)** The pilot warehouses handled at least as large a share of temperature-sensitive products as the warehouses scheduled for conversion.
- **(D)** Spoilage never occurs when a storage room remains below the alert threshold.
- **(E)** The reduction in spoilage observed at the pilot warehouses was not entirely the result of inspections or of cooperation between inspections and alerts that would disappear if inspections ended.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Management concludes that sensors can replace inspections without sacrificing spoilage prevention.
2. **Support.** The pilot tested sensors alongside inspections, not as a substitute.
3. **Prephrase.** The sensor benefit must survive at least the loss of inspections.
4. **Why (E) is right.** Negate (E): all measured improvement depended on inspections or on their interaction with alerts and would disappear without inspections. The pilot then gives no basis for the replacement conclusion.
5. **Why the others fail.**
   - **(A)** High response rates would strengthen the case for alerts but are not a necessary threshold, and responses could still have required inspection staff.
   - **(B)** (B) is a wrong comparison: the cost claim concerns eliminating inspections, not all warehouse procedures.
   - **(C)** Pilot generalizability is helpful but is not required for the narrower claim that alerts can replace inspections. It never isolates alerts from the inspections retained during the pilot.
   - **(D)** (D) is too strong: sensors could be equally effective despite some below-threshold spoilage.

**Check:** (E) denied removes the only link between the combined trial and sensors-alone performance.
::::
:::

:::problem[Question I.3]
A regional health authority found that reported infections declined after it began publishing weekly wastewater measurements. Officials attribute at least part of the decline to the reports: they reason that people reduced risky indoor contacts when measurements rose. Critics point out that reported cases might have fallen because fewer people sought diagnostic testing, and that wastewater measurements themselves can rise or fall without any change in public behavior. The authority wants additional evidence that publication, rather than changes in measurement practices, reduced actual transmission.

Which one of the following, if true, most strengthens the officials’ explanation?

- **(A)** Two neighboring regions published similar reports, although their diagnostic rules differed.
- **(B)** Within the region, independently measured contact rates fell shortly after unusually high readings were published, while testing access and diagnostic protocols remained stable.
- **(C)** Residents who saw the wastewater charts were substantially more likely to remember which weeks had high measurements than were residents who had not seen them.
- **(D)** The concentrations of viral material varied substantially among sampling locations.
- **(E)** Clinics in the region performed fewer diagnostic tests after the wastewater reports began.

::::solution[Solution]
**Answer:** (B)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Publication of the reports helped reduce actual transmission through behavioral change.
2. **Support.** Reported case counts alone could be explained by testing behavior.
3. **Prephrase.** Find a behavioral change linked in time to the reports, independently of the reporting system.
4. **Why (B) is right.** (B) supplies the hypothesized mechanism and rules out the salient testing alternative. It does not prove causation, but it strongly favors the officials over the measurement-only account.
5. **Why the others fail.**
   - **(A)** (A) tells us other authorities made reports, but no comparison of behavior or infections follows.
   - **(C)** Recognition shows that people noticed the reports, but it is a half-right mechanism: it does not establish altered contacts or actual transmission.
   - **(D)** (D) concerns spatial variation in wastewater, not behavior after publication.
   - **(E)** (E) bolsters the critics' testing-artifact alternative.

**Check:** Evidence must touch actual contacts, not merely test counts or the aesthetics of charts.
::::
:::

:::problem[Question I.4]
An analyst notes that appliance makers increasingly advertise products as repairable, yet few publish affordable prices for replacement components. A label alone therefore need not make an appliance economical to repair. Some legislators propose mandatory disclosure of parts prices before sale; opponents say that repairability labels provide buyers all they need. But a buyer cannot compare the cost of keeping two appliances working merely by knowing that both can be repaired. Accordingly, disclosure of parts prices would improve consumers' ability to make meaningful long-term cost comparisons, even if it had little effect on manufacturers' design choices.

Which one of the following most accurately expresses the analyst’s main conclusion?

- **(A)** Requiring advance disclosure of replacement-part prices would help buyers compare appliances' long-term costs.
- **(B)** Some manufacturers advertise repairability without providing inexpensive components.
- **(C)** Consumers should disregard manufacturers’ repairability claims whenever estimated replacement-part costs are unavailable.
- **(D)** Manufacturers' design choices are unlikely to change in response to disclosure requirements.
- **(E)** A product that can be repaired is not always economical to repair.

::::solution[Solution]
**Answer:** (A)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The analyst ultimately favors parts-price disclosure as useful for comparing ownership costs.
2. **Support.** The label criticism and information gap support the final recommendation.
3. **Prephrase.** Distinguish the advocated result from the observations that motivate it.
4. **Why (A) is right.** (A) restates the final 'accordingly' claim with the same limited strength, even if design changes do not follow.
5. **Why the others fail.**
   - **(B)** (B) is factual background, not the policy conclusion.
   - **(C)** That prescribes ignoring repairability entirely; the analyst only says a repairability label is insufficient for comparing total costs, not useless information.
   - **(D)** (D) turns a concession ('even if') into a forecast.
   - **(E)** (E) is a subordinate premise explaining why labels are insufficient.

**Check:** Remove the label and cost premises; the disclosure conclusion is the statement those premises support.
::::
:::

:::problem[Question I.5]
A hospital network has doses of an experimental vaccine that cannot be supplied to everyone eligible. Its ethics committee adopts this rule: when two patients have equal medical prospects of benefiting from a dose, priority may be given to the one whose lack of vaccination would expose more other people to infection, provided that the committee does not use occupational prestige or wealth as a proxy for exposure. The rule is meant to reduce secondary harm without treating one person's social status as inherently more valuable than another's.

Which one of the following decisions most closely conforms to the committee’s principle?

- **(A)** Use expected exposure to others as the overriding priority even when the two patients have substantially different medical prospects of benefiting.
- **(B)** Prefer a celebrated performer whose work reaches millions of people over an isolated caregiver with equal medical prospects.
- **(C)** Prefer the patient with the better prognosis, regardless of how their vaccination affects others.
- **(D)** Prefer a wealthy patient to a low-income patient because the wealthy patient can sponsor research.
- **(E)** Among equally likely beneficiaries, prefer a caregiver with frequent unavoidable close contacts over an office worker with minimal contacts, based on documented exposure patterns.

::::solution[Solution]
**Answer:** (E)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The committee permits exposure-based priority only among equally promising recipients.
2. **Support.** The rule separates epidemiological impact from status and financial standing.
3. **Prephrase.** Locate an equal-prognosis tie and break it by measured exposure to others.
4. **Why (E) is right.** (E) satisfies both the equal-medical-prospects condition and the exposure criterion without smuggling in prestige.
5. **Why the others fail.**
   - **(A)** Exposure is a permitted tie-break only when medical prospects are equal; this choice illicitly applies it outside that condition.
   - **(B)** (B) substitutes celebrity reach for infection exposure, an attractive prestige shell game.
   - **(C)** (C) changes the tie condition: differing prognoses make the rule inapplicable, not automatically exposure-blind.
   - **(D)** (D) violates the explicit prohibition on wealth as proxy.

**Check:** Equal benefit + greater documented secondary exposure, not social importance, earns priority.
::::
:::

:::problem[Question I.6]
A financial columnist recommends the Northstar bond fund over the Beacon fund because Northstar's investors received higher average annual distributions during the past five years. Both funds invest primarily in investment-grade corporate bonds, and Northstar's published distribution rate exceeded Beacon's every year. The columnist concedes that Northstar charges a higher management fee but says the stronger distributions demonstrate superior results even after that difference. The published rates, however, are calculated as amounts paid per fund share rather than as gains on equal initial investments.

Which one of the following, if true, most seriously weakens the columnist’s argument?

- **(A)** Both funds disclosed their distribution rates accurately under the same reporting rules.
- **(B)** Northstar distributed a greater fraction of its investment income as cash, whereas Beacon retained more income inside the fund.
- **(C)** Some investors reinvest their distributions rather than taking them in cash.
- **(D)** Beacon’s portfolio was less concentrated in high-yield, high-default-risk issuers than Northstar’s portfolio.
- **(E)** Northstar's share price was sufficiently higher throughout the period that an equal dollar investment in Beacon produced a higher total return after fees and changes in share value.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Northstar delivered better investment results despite higher fees.
2. **Support.** The sole direct comparison is distribution per share, not return for equal capital.
3. **Prephrase.** Equalize the initial dollars and include fees and share-price changes.
4. **Why (E) is right.** (E) supplies a like-for-like return comparison that reverses the claimed ranking. A higher dollar amount per *share* can conceal a lower return on invested capital.
5. **Why the others fail.**
   - **(A)** (A) assures reporting accuracy but leaves the denominator mismatch intact.
   - **(B)** Different payout policies could help explain per-share distributions and weaken the inference, but the choice supplies no comparison of the actual total returns after fees and share-price changes, unlike (E).
   - **(C)** (C) is a choice about what investors do with distributions, not a systematic difference in fund performance.
   - **(D)** Risk concentration affects prospective safety but does not settle which fund earned the greater net return over the compared five years.

**Check:** One high-priced share can pay more dollars yet yield less wealth than the same investment in lower-priced shares.
::::
:::

:::problem[Question I.7]
Under a county ordinance, any temporary quarantine order issued without a hearing must be reviewed by a magistrate within forty-eight hours. Any order that the magistrate rejects must be terminated immediately. All orders based solely on a preliminary laboratory screen are issued without a hearing. Early Monday morning, the county issued an order against a food-processing site based solely on such a screen. By Wednesday evening the order remained in force, and the county complied with every requirement of the ordinance. No other kind of order is described.

Which one of the following must be true?

- **(A)** The magistrate did not reject the order during the required review period.
- **(B)** The magistrate issued an explicit written approval of the order before the end of the forty-eight-hour review period.
- **(C)** A public hearing was held before the order was issued.
- **(D)** The preliminary laboratory screen yielded an accurate result.
- **(E)** The food-processing site had violated a separate food-safety law.

::::solution[Solution]
**Answer:** (A)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** There is no advocated policy conclusion; the task is to deduce what the rules and facts force.
2. **Support.** Screen-only implies no hearing, which implies forty-eight-hour review; rejection implies immediate termination.
3. **Prephrase.** Use the contrapositive of rejected → terminated, given continuation after the deadline.
4. **Why (A) is right.** (A) follows: since the order remained in force after the review deadline with full compliance, it cannot have been rejected in that period.
5. **Why the others fail.**
   - **(B)** The ordinance requires review, and continued validity rules out rejection, but it does not require an affirmative written approval; non-rejection is enough for the inference.
   - **(C)** (C) is the opposite of the screen-only implication.
   - **(D)** (D) adds a claim about test accuracy that the ordinance does not require.
   - **(E)** (E) imports unrelated legal wrongdoing absent from the facts.

**Check:** Rejected → terminated; not terminated → not rejected, within the specified review window.
::::
:::

:::problem[Question I.8]
An agricultural supplier tested a seed treatment on six experimental plots. Each treated plot yielded more grain than the untreated plot located beside it. In a subsequent presentation, the supplier combined all grain harvested from the treated plots and all grain harvested from the untreated plots and reported that the total for the treated group exceeded that for the untreated group. The supplier then argued that farmers using the treatment would necessarily have higher profit per hectare, regardless of location or input prices. The study did not measure treatment costs or the price farmers would receive for the harvested grain.

The argument is most vulnerable to criticism because it

- **(A)** draws an unqualified conclusion about profit from evidence about physical output while leaving costs and revenues per unit unexamined.
- **(B)** treats the plots as randomly assigned despite explicitly saying their locations were paired.
- **(C)** fails to establish that every treated plot yielded more grain than its neighboring control.
- **(D)** assumes that a higher total harvest is impossible unless every individual plot improves.
- **(E)** attributes its yield findings to random differences in the number of treated and untreated plots, even though the plots were paired.

::::solution[Solution]
**Answer:** (A)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The supplier predicts necessarily higher profit per hectare everywhere.
2. **Support.** The trial supports a yield comparison only, with no cost or price accounting.
3. **Prephrase.** Spot the switch from quantity harvested to net profit.
4. **Why (A) is right.** (A) names the outcome shell game precisely: a yield increase can be overwhelmed by treatment cost or changed sale prices. The universal prediction also exceeds the sample.
5. **Why the others fail.**
   - **(B)** (B) attacks a randomization claim the supplier never makes.
   - **(C)** (C) contradicts the explicit pairwise yield results.
   - **(D)** (D) reverses the actual move: the supplier has individual improvements and draws a profit conclusion, not a total-to-individual yield inference.
   - **(E)** The supplier does not attribute the results to unequal plot counts; the evidence states each pair favored treatment. Its error comes when it changes the outcome from yield to profit.

**Check:** Profit = revenue − cost; a positive yield difference alone fixes neither term sufficiently.
::::
:::

:::problem[Question I.9]
Councilor Vega: If the transit authority extends late-night buses to the industrial district, more night-shift employees will be able to travel home without cars. Even if the extension fails the authority’s usual cost-efficiency threshold, accessibility should independently justify funding it. Councilor Lin: I agree that the extension would give some employees an alternative to driving. But its cost per passenger would be unusually high, and the authority has promised to devote scarce operating funds only to routes that meet its published cost-efficiency threshold. Accessibility cannot excuse abandoning that commitment.

The councilors disagree about whether

- **(A)** the authority's operating budget has increased in recent years.
- **(B)** accessibility can justify funding a transit route that fails the authority's adopted cost-efficiency standard.
- **(C)** a late-night extension would provide at least some workers with an alternative to driving.
- **(D)** the industrial district employs people who commute by car.
- **(E)** late-night ridership would necessarily exceed daytime ridership.

::::solution[Solution]
**Answer:** (B)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Vega treats accessibility as a potential independent justification; Lin refuses that exception.
2. **Support.** Both accept improved access, but weigh it against an efficiency commitment differently.
3. **Prephrase.** Find an issue on which each takes opposite positions, not one only mentions.
4. **Why (B) is right.** (B) captures the genuine normative disagreement: Vega says the criterion should count even with low ridership; Lin says it cannot override the standard.
5. **Why the others fail.**
   - **(A)** (A) has no position from either councilor, a classic one-sided or no-sided point-at-issue trap.
   - **(C)** (C) is shared agreement, explicitly acknowledged by Lin.
   - **(D)** (D) might be true but neither disputes workers' existing commuting modes.
   - **(E)** (E) is unaddressed by both, an unsupported comparison with daytime.

**Check:** Vega: access may suffice despite poor efficiency. Lin: poor efficiency disqualifies regardless of access.
::::
:::

:::problem[Question I.10]
A manufacturer grants its highest compliance rating only to suppliers whose testing records are independently auditable. Every supplier in its closed-loop recycling program has independently auditable testing records. Orion Components is in the recycling program. An auditor therefore claims that Orion must receive the manufacturer's highest compliance rating. But the manufacturer's rule states only a condition that suppliers with the highest rating must meet; it does not say that meeting this condition is enough for the rating. The auditor's conclusion would follow if an appropriate additional condition were supplied.

Which one of the following, if assumed, enables the auditor’s conclusion to be properly drawn?

- **(A)** Orion's testing records are more detailed than those of most suppliers.
- **(B)** Every supplier with the highest rating belongs to the recycling program.
- **(C)** At least one recycling-program supplier has already received the highest rating.
- **(D)** Every supplier with independently auditable testing records receives the highest compliance rating.
- **(E)** Any supplier that lacks auditable records is denied the highest rating.

::::solution[Solution]
**Answer:** (D)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Orion is guaranteed to receive the highest rating.
2. **Support.** Recycling membership implies auditable records; the stated rating rule runs highest rating → auditable, not auditable → rating.
3. **Prephrase.** Bridge auditable records to the highest rating in the forward direction.
4. **Why (D) is right.** (D) supplies the missing arrow. Orion → recycling → auditable → highest, so the conclusion follows deductively.
5. **Why the others fail.**
   - **(A)** (A) offers a relative-detail comparison, not the missing guarantee.
   - **(B)** (B) reverses an unrelated membership relation and never awards a rating to Orion.
   - **(C)** (C) moves from one program member to all members, a sample-to-universal leap.
   - **(E)** (E) merely restates the contrapositive of the original necessary condition.

**Check:** Complete the chain; no appeal to probability or another supplier is needed.
::::
:::

:::problem[Question I.11]
A coastal municipality required restaurants to replace disposable takeaway containers with returnable ones. One year later, its sanitation department measured 40 percent fewer discarded takeaway containers by weight. Yet the total weight of material sent from restaurant districts to the landfill increased. Officials had expected both measures to fall, since containers made up a conspicuous part of litter before the rule. The numbers came from the same districts, covered the same seasons, and used unchanged weighing procedures, so the discrepancy cannot be attributed simply to different coverage or measurement.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Returnable containers usually weigh more individually than disposable containers.
- **(B)** Restaurants used additional water and cleaning chemicals to wash the returnable containers after the policy took effect.
- **(C)** Restaurants began sending substantially more food scraps to landfill after a separate composting contractor ceased collecting them, more than offsetting the decline in discarded containers.
- **(D)** Restaurants purchased more disposable utensils after the container requirement took effect, but no figures are available for how many were discarded.
- **(E)** The total number of takeaway orders placed in the restaurant districts declined during the period.

::::solution[Solution]
**Answer:** (C)

**Type:** Paradox / resolve–explain (Chapter 13)

1. **Conclusion.** The puzzle is falling container waste alongside rising total landfill mass.
2. **Support.** Container waste is only one component of all material from restaurant districts.
3. **Prephrase.** Look for another waste stream that rose by more than the container stream fell.
4. **Why (C) is right.** (C) supplies precisely that offset: food scraps now enter the landfill stream in sufficient mass to dominate the net total. Both reports can be accurate.
5. **Why the others fail.**
   - **(A)** (A) concerns the weight of containers *used*, not the reported weight *discarded* at landfill.
   - **(B)** Cleaning has other environmental consequences but does not increase the measured mass of landfill-bound material by itself.
   - **(D)** Utensils are another plausible waste stream, but without information on their landfill mass the choice cannot reconcile the increase; (C) explicitly gives an offset larger than the decrease in container mass.
   - **(E)** A drop in orders does not explain why the total landfill mass increased while discarded containers fell; if anything, it makes the increase harder to account for.

**Check:** Total mass = container mass + other mass; a larger increase in other mass reconciles the signs.
::::
:::

:::problem[Question I.12]
A pension trustee argues that the fund should change its assumptions about employee retirement ages. The fund projects obligations using a retirement age of sixty-five, yet its recent retirees have tended to leave at sixty-two. Critics reply that the sample is skewed by a temporary early-retirement incentive. The trustee accepts that the incentive explains part of the pattern but notes that surveys conducted before it was offered already showed a growing preference for retirement before sixty-five. The trustee therefore says the present model is insufficiently conservative, even if the recent average is not itself a reliable long-term prediction.

In the trustee’s argument, the statement about surveys conducted before the incentive serves primarily to

- **(A)** state the recommendation that the retirement-age assumption should be changed.
- **(B)** establish that the early-retirement incentive had no effect on the observed retirement ages.
- **(C)** introduce the objection concerning an incentive that biases the sample.
- **(D)** provide evidence that an underlying earlier-retirement tendency exists independently of the temporary incentive.
- **(E)** concede that all evidence from retirees is worthless.

::::solution[Solution]
**Answer:** (D)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The trustee concludes that the current pension model underestimates earlier retirement risk.
2. **Support.** The surveys support that concern even after the trustee concedes the distortion in recent-retiree data.
3. **Prephrase.** Identify what the pre-incentive surveys do in the dispute: answer a challenge, not make the recommendation.
4. **Why (D) is right.** (D) correctly identifies the surveys as independent support for a secular preference trend that the incentive cannot fully explain.
5. **Why the others fail.**
   - **(A)** (A) mistakes evidence for the trustee's ultimate prescription.
   - **(B)** The trustee explicitly concedes some incentive effect; surveys before it show an independent trend, not zero effect of the incentive.
   - **(C)** (C) assigns the surveys the role of the critics' objection rather than a response to it.
   - **(E)** (E) overstates the trustee's limited concession about one sample.

**Check:** Remove the survey fact; the conceded sampling objection becomes considerably harder to answer.
::::
:::

:::problem[Question I.13]
At one assembly plant, a new scheduling algorithm increased the number of finished units produced per hour that its automated welding machines were operating. The operations director therefore declared that the algorithm increased the plant's total productivity. During the same period, however, the machines were operating fewer hours per shift because the schedule required long changeovers, and additional employees were hired to manage inventory buffers. The director did not calculate finished units per labor hour or per dollar of total input, and offered only the welding-machine rate as evidence.

The director’s argument is most vulnerable to criticism on the grounds that it

- **(A)** assumes any change in inventory must have been caused by employee preferences.
- **(B)** treats increased output per active machine-hour as if it established increased productivity for the plant as a whole.
- **(C)** infers that the new schedule reduced the number of welding machines.
- **(D)** assumes the welding machines produced no defective units before implementation.
- **(E)** assumes that welding-machine efficiency is necessarily the most important factor in a plant’s operating performance.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The director concludes overall plant productivity improved.
2. **Support.** A per-active-machine-hour figure does not account for idle time or additional labor inputs.
3. **Prephrase.** Find the part-to-whole and denominator shift.
4. **Why (B) is right.** (B) identifies the exact unlicensed generalization from one machine-level rate to a plant-wide input-output measure. Other input costs could rise and total output could fall.
5. **Why the others fail.**
   - **(A)** (A) makes up a psychological cause for inventory changes.
   - **(C)** (C) invents a claim about machine count.
   - **(D)** (D) demands an unrelated preexisting zero-defect claim; the flaw is aggregation, not defect history.
   - **(E)** The director effectively privileges the machine rate, but the exact error is claiming that one rate establishes total *productivity*, not asserting which factor matters most to all dimensions of operating performance.

**Check:** Compare total good units with *all* relevant resources before and after, not one favorable ratio.
::::
:::

:::problem[Question I.14]
An epidemiologist proposes mailing screening invitations to households in neighborhoods with unusually low recorded disease rates. Her colleagues object that the letters would be wasted where relatively few residents have the disease. She responds that recorded rates are an unreliable indicator of true rates when access to diagnostic clinics is limited; the neighborhoods with the fewest diagnoses may have the greatest number of undetected cases. She predicts that targeted invitations will identify more previously undiagnosed cases per hundred letters than mailing to neighborhoods with high recorded rates.

Which one of the following, if true, most strengthens the epidemiologist’s prediction?

- **(A)** Residents of high-recorded-rate neighborhoods are more likely to recognize the disease's name.
- **(B)** The high-recorded-rate neighborhoods have larger populations overall.
- **(C)** A random door-to-door assessment found that undiagnosed disease prevalence was substantially higher in the low-recorded-rate neighborhoods than in the high-recorded-rate neighborhoods.
- **(D)** Residents of low-recorded-rate neighborhoods made fewer visits to diagnostic clinics than residents of high-recorded-rate neighborhoods.
- **(E)** Households in the low-recorded-rate neighborhoods are more likely to open official health mail than are households in high-recorded-rate neighborhoods.

::::solution[Solution]
**Answer:** (C)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Invitations to low-recorded-rate areas will find more undiagnosed cases per hundred.
2. **Support.** Low diagnosis could conceal high undetected prevalence because access differs.
3. **Prephrase.** Find an independent measure of undiagnosed prevalence in the two target groups.
4. **Why (C) is right.** (C) directly validates the hidden-cases premise and the relevant per-person comparison. It makes the outreach yield prediction much more plausible, though responses could still differ.
5. **Why the others fail.**
   - **(A)** (A) measures name recognition among already-diagnosed areas, not undetected case prevalence.
   - **(B)** (B) is a wrong denominator: the claim concerns yield per hundred letters, not total population.
   - **(D)** This supports the limited-access story but does not show how many undiagnosed cases outreach would find; the independent prevalence measurement in (C) is much more direct.
   - **(E)** More letters being opened could help outreach, but it does not establish the prevalence of undiagnosed cases among people who would respond or yield a screening diagnosis.

**Check:** More undiagnosed people in the low-recorded group, with comparable invitations, raises expected detection yield.
::::
:::

:::problem[Question I.15]
A mining regulator recommends raising the required restoration bond for a proposed graphite mine. The operator estimates that its current bond will cover the expected cost of restoring the site under normal operating conditions. The regulator notes that an unexpected tailings-dam failure would require remediation far more expensive than the bond and argues that a higher bond is needed to ensure that public funds will not be used for such remediation. The operator has not disputed the estimated cost of a failure, but the regulator has not discussed insurance or other sources of payment.

The regulator’s argument requires assuming which one of the following?

- **(A)** The mine has already suffered a tailings-dam failure at another location.
- **(B)** All proposed graphite mines should be denied approval unless their bonds cover every imaginable event.
- **(C)** The operator has intentionally understated every expense associated with normal closure.
- **(D)** A tailings-dam failure is more likely than a routine restoration operation.
- **(E)** The costs of an expensive tailings-dam failure would not be fully met by some separate source of funding that would leave public funds untouched even with the current bond.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The bond must increase so taxpayers do not pay for an exceptional failure.
2. **Support.** The failure cost exceeds the bond, but it might still be privately covered without a larger bond.
3. **Prephrase.** Rule out a fully sufficient alternative funding source.
4. **Why (E) is right.** (E) passes the negation test: if separate insurance or private funds completely pay the failure costs without public money, the stated necessity of raising the bond to protect taxpayers disappears.
5. **Why the others fail.**
   - **(A)** (A) supplies a history that could make the risk more salient but is not logically required.
   - **(B)** (B) turns a particular bond recommendation into an extreme universal ban.
   - **(C)** (C) is an unsupported accusation about routine estimates.
   - **(D)** (D) confuses magnitude with probability; the argument could work for rare catastrophic losses.

**Check:** (E) negated supplies full outside coverage, defeating the 'needed to protect public funds' rationale.
::::
:::

:::problem[Question I.16]
An engineer argues: Every batch fired in this kiln that exhibited microscopic surface pitting was later rejected by customers. A newly fired batch from this same kiln has no microscopic pitting. Therefore, customers will not reject this batch. The engineer acknowledges that rejection can also occur for reasons unrelated to pitting, including dimensional errors, but maintains that the absence of a symptom associated with rejection is decisive. The plant manager asks which argument commits the same logical mistake, rather than merely reaching an overly confident conclusion.

Which one of the following arguments exhibits reasoning most similar in its flaw?

- **(A)** Every recalled pump produced a distinctive vibration. This pump produced no such vibration, so it cannot be a recalled pump.
- **(B)** Some damaged paintings have cracked varnish; this painting has cracked varnish, so it is probably damaged.
- **(C)** Whenever a bank receives a certified fraud alert about a payment, it freezes that payment. No certified fraud alert was received for this payment, so it will not be frozen.
- **(D)** All products certified for marine use passed a salt-spray test. This part passed a salt-spray test, so it must be certified for marine use.
- **(E)** Every urgent shipment has a red tag. This shipment has a red tag, so it must be urgent.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The engineer infers no rejection from no pitting, although pitting is only one sufficient route to rejection.
2. **Support.** Form: pitting → rejection; not pitting → not rejection (denying the antecedent).
3. **Prephrase.** Choose the choice that denies the antecedent, not one affirming the consequent or taking a valid contrapositive.
4. **Why (C) is right.** (C) matches the invalid inverse: certified alert → frozen, but no alert does not guarantee no freeze, because other reasons for freezing remain possible.
5. **Why the others fail.**
   - **(A)** (A) uses the valid contrapositive of recall → vibration; it does not contain the engineer's error.
   - **(B)** (B) reasons from a 'some' premise, not a universal conditional or its inverse.
   - **(D)** (D) affirms the consequent (passed test → certified) instead of denying antecedent.
   - **(E)** (E) also affirms the consequent (red tag → urgent), which is a different flaw.

**Check:** Identify the inverse error: if P → R, not P does not imply not R.
::::
:::

:::problem[Question I.17]
Across three growing seasons, farms using aerial images to spot fungal lesions identified outbreaks earlier than otherwise similar farms relying solely on weekly field walks. Early detection was associated with fewer acres requiring treatment, but the image-using farms also had more trained agronomists. An independent trial subsequently supplied both groups with identical agronomic support and found that the image-equipped farms still identified lesions earlier. The trial did not track whether those earlier alerts ultimately increased profits or reduced pesticide resistance.

Which one of the following is most strongly supported by the information above?

- **(A)** Weekly field walks generally required more staff-hours per acre than analysis of aerial images.
- **(B)** The image-equipped farms earned higher net profits in each of the three growing seasons.
- **(C)** Aerial imaging always reduces chemical use regardless of crop and climate.
- **(D)** Additional agronomic staffing cannot by itself fully explain the earlier detection associated with aerial imaging in the independent trial.
- **(E)** Fungal resistance to pesticides is prevented whenever treatment begins early.

::::solution[Solution]
**Answer:** (D)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The passage supports a limited causal inference about detection, not profits or resistance.
2. **Support.** Equal agronomic support in the independent trial holds the original staffing difference constant while early detection persists.
3. **Prephrase.** Conclude only that the original staffing explanation is insufficient for the trial difference.
4. **Why (D) is right.** (D) expresses that appropriately modest result. It does not claim aerial images always work or that imaging is the sole possible cause.
5. **Why the others fail.**
   - **(A)** Labor intensity might matter to operating cost, but the supported inference concerns earlier lesion detection after equal agronomic staffing, not time expenditure.
   - **(B)** (B) invents profit findings the trial never measured.
   - **(C)** (C) overgeneralizes from certain farm comparisons to every crop and climate.
   - **(E)** (E) infers pesticide-resistance prevention from earlier detection despite no resistance data.

**Check:** Controlled staffing with remaining earlier detection blocks 'staffing alone' as a complete account.
::::
:::

:::problem[Question I.18]
A supplier proposes inspecting only one unit out of every twenty in a production run. Its quality manager argues that this will save money without allowing more defective shipments to reach customers, because defect rates in last year's inspected units were extremely low. Yet last year's inspectors concentrated their attention on units produced immediately after machine recalibrations, when errors were thought to be most common. Under the new proposal, a randomly chosen sample would replace that targeted monitoring, and the manager has not compared defect distributions across different periods of production.

Which one of the following would be most useful to determine in evaluating the manager’s argument?

- **(A)** Whether the supplier has installed faster packaging machines this year.
- **(B)** Whether units found defective during inspection can usually be repaired before the factory ships them to customers.
- **(C)** Whether defects are concentrated immediately after recalibrations rather than spread approximately evenly throughout production.
- **(D)** Whether inspectors are paid hourly or by the number of units examined.
- **(E)** Whether machine recalibration is required under a separate industry standard.

::::solution[Solution]
**Answer:** (C)

**Type:** Evaluate the argument (Chapter 8)

1. **Conclusion.** Random inspection supposedly preserves the protective effectiveness of targeted inspection.
2. **Support.** The old low defect figures were produced with special scrutiny at suspect intervals.
3. **Prephrase.** Ask whether random sampling will miss a clustered hazard that targeted sampling catches.
4. **Why (C) is right.** (C) directly tests the pivotal distributional assumption. If failures cluster after recalibration, losing targeted scrutiny is risky; if they are evenly distributed, random sampling looks more defensible.
5. **Why the others fail.**
   - **(A)** (A) mentions a possible operational change without testing sampling coverage.
   - **(B)** Repairability can affect ultimate shipment quality, but it does not compare the ability of targeted versus random inspection to find faults clustered after recalibration.
   - **(D)** (D) concerns inspector compensation, not placement of defects.
   - **(E)** (E) substitutes regulatory compliance for the empirical effectiveness of two inspection methods.

**Check:** Evaluate both answers to (C): clustering weakens, even distribution strengthens the proposal.
::::
:::

:::problem[Question I.19]
A greenhouse operator claims that releasing an additional species of predatory mite will reduce leaf damage from a particular pest. The new mite has eliminated that pest in isolated laboratory enclosures, and it survives greenhouse temperatures. The operator reasons that it can therefore be introduced alongside the predatory mite already used in the greenhouse, producing at least as much pest control as before. Both mites feed on the pest, but the operator has not studied how they interact when confined to the same crop canopy.

Which one of the following, if true, most weakens the operator’s argument?

- **(A)** When each mite species is released alone, the two species usually occupy different portions of a crop canopy.
- **(B)** Greenhouse temperatures sometimes vary by several degrees from one week to the next.
- **(C)** The pest population has become resistant to several chemical sprays previously used in the greenhouse.
- **(D)** The laboratory enclosures were smaller than the production greenhouse.
- **(E)** In trials with both predators present, the newly introduced mite consumed the established predator's eggs so extensively that pest populations increased above the levels seen with the established predator alone.

::::solution[Solution]
**Answer:** (E)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Introducing the new mite alongside the old will improve or preserve pest control.
2. **Support.** Separate-enclosure success and thermal tolerance say nothing about predator-on-predator interference.
3. **Prephrase.** Find a specific interaction that makes the combined system perform worse than the old system.
4. **Why (E) is right.** (E) gives observed intraguild predation that reverses the expected net effect. It directly defeats the inference that two effective predators will combine beneficially.
5. **Why the others fail.**
   - **(A)** Spatial separation in solitary introductions does not reveal their interaction after joint release; it cannot displace the direct mixed-predator evidence in (E).
   - **(B)** (B) raises a speculative temperature issue already partly addressed by survival evidence.
   - **(C)** Resistance to chemical controls does not tell us whether the introduced mite will undermine or improve the existing biological-control interaction.
   - **(D)** (D) notes scale alone, but supplies no direction or consequence; it is weaker than demonstrated interference.

**Check:** The correct comparison is pest damage with both predators versus the existing predator alone.
::::
:::

:::problem[Question I.20]
A claims analyst reasons as follows: Every claim eligible for expedited payment is supported by a verified incident report. No claim with a verified incident report is routed to external investigation unless the claimant requests review. The Rivera claim is eligible for expedited payment, and its claimant has not requested review. Therefore, the Rivera claim will not be routed to external investigation. The analyst does not claim that a verified incident report alone makes a claim eligible for expedited payment.

Which one of the following arguments is most similar in its pattern of reasoning?

- **(A)** Every funded project has a signed agreement. A project with a signed agreement is not archived unless its director resigns. Alder is funded, and its director has not resigned; therefore Alder is not archived.
- **(B)** All overdue invoices trigger a reminder, and some reminders prompt payment. This invoice is overdue; therefore it will prompt payment.
- **(C)** Only manuscripts receiving peer review can be accepted. This manuscript was peer reviewed; therefore it was accepted.
- **(D)** All accredited workshops maintain attendance logs. This workshop maintains an attendance log; therefore it is accredited.
- **(E)** No membership applicant may vote unless dues are paid. Lena paid her dues, so Lena may vote.

::::solution[Solution]
**Answer:** (A)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** The conclusion is a guaranteed negative routing outcome for a qualifying claim with no exception.
2. **Support.** Eligible → verified; verified and not requested → not investigated.
3. **Prephrase.** Match a two-stage valid chain with a stated exception ruled out.
4. **Why (A) is right.** (A) has funded → agreement; agreement and not resigned → not archived. The same conjunction lets the negative conclusion follow validly.
5. **Why the others fail.**
   - **(B)** (B) shifts 'some reminders' into a guarantee for a particular invoice.
   - **(C)** (C) makes the same converse mistake with peer review.
   - **(D)** (D) affirms the consequent, reversing workshop → log.
   - **(E)** (E) mistakes dues as sufficient for voting when only necessary.

**Check:** Chain the first conditional into the exception-limited second rule; the named project meets both requirements.
::::
:::

:::problem[Question I.21]
A metals manufacturer has advertised that its recycled alloy satisfies a stringent aerospace standard. The advertising executive defending the claim argues that independent auditors have never formally determined that the alloy fails the standard. Moreover, several competitors whose alloys are less widely used have also not been found noncompliant. Since the manufacturer has no official finding against it, the executive says the claim of full compliance must be accepted. The standard requires the manufacturer to establish particular test results, but it has not released results from the relevant fatigue test.

The executive’s reasoning is flawed because it

- **(A)** treats wider commercial adoption of an alloy as decisive evidence that its fatigue performance meets the aerospace standard.
- **(B)** mistakes a requirement to run tests for a requirement to advertise those tests.
- **(C)** assumes that independent auditors cannot disagree about the results of fatigue testing.
- **(D)** treats the absence of proof of noncompliance as proof that the affirmative compliance requirement has been met.
- **(E)** draws a causal conclusion about advertising from changing market share.

::::solution[Solution]
**Answer:** (D)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The executive claims the alloy must count as fully compliant.
2. **Support.** No adverse finding is not affirmative evidence of the required fatigue performance.
3. **Prephrase.** Look for absence-of-disproof shifted into proof.
4. **Why (D) is right.** (D) identifies the burden-of-proof error: compliance must be supported by tests; silence from auditors does not demonstrate it. The competitor comparison does not close the evidentiary gap.
5. **Why the others fail.**
   - **(A)** The executive compares competitors’ popularity but does not directly infer compliance from adoption; the claimed proof instead rests on the absence of formal findings of noncompliance.
   - **(B)** (B) targets a different distinction: the flaw is missing evidence of meeting the standard, not whether results must be advertised.
   - **(C)** (C) imputes a claim about auditors' disagreement that the executive never makes.
   - **(E)** (E) alleges a causal market-share argument absent from the stimulus.

**Check:** 'Not shown false' does not entail 'shown true,' especially under an affirmative test requirement.
::::
:::

:::problem[Question I.22]
A portfolio manager says a firm's new dividend is not, by itself, evidence that its underlying business is healthier. A dividend can be paid from cash accumulated in previous years or from new borrowing, even if current operations are deteriorating. The manager does not deny that dividends sometimes signal managerial confidence; indeed, she concedes that such signals can be informative when accompanied by operating figures. Her objection is that investors who rely on the announcement without examining its funding source make an unsupported inference from a financial decision to a financial condition.

The portfolio manager’s method of reasoning is primarily to

- **(A)** argue that every dividend payment necessarily results in deteriorating operations.
- **(B)** undermine an inference by identifying alternative ways in which the observed event could have occurred without the inferred condition.
- **(C)** cite investor confidence in dividend announcements as evidence that dividends generally convey reliable information.
- **(D)** reject all financial signals on the ground that market prices can be manipulated.
- **(E)** infer a firm's prospects from the relative size of its dividend and its competitors' dividends.

::::solution[Solution]
**Answer:** (B)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** A dividend announcement alone does not establish improved business health.
2. **Support.** Cash reserves and borrowing are alternative sources of a payout.
3. **Prephrase.** Identify a method that supplies rival explanations rather than a sweeping denial.
4. **Why (B) is right.** (B) accurately describes using alternative causal and financial paths to block one asserted inference. The concession about operating figures reinforces the limited point.
5. **Why the others fail.**
   - **(A)** (A) overstates a warning into a universal negative causal claim.
   - **(C)** The manager mentions the signal interpretation as a concession, not as authority supporting her own warning about funding sources.
   - **(D)** (D) broadens the claim to wholesale rejection of signals and price manipulation.
   - **(E)** (E) invents a dividend-size cross-company comparison.

**Check:** A healthy operation is one possible explanation of a dividend, not a necessary condition for paying one.
::::
:::

:::problem[Question I.23]
A conservation group plans to restore a rare orchid to a mountain meadow using seeds held in a regional bank. Researchers have shown that the seeds can germinate after years in cold storage, and the proposed meadow has the temperature and rainfall range in which the species once grew. The group therefore predicts that planting the stored seeds will establish a self-sustaining wild population. The orchid's young plants, however, normally depend on a compatible soil fungus, and the group's field survey measured only weather and soil acidity, not fungal partners.

Which one of the following is an assumption on which the group’s prediction depends?

- **(A)** All orchid species require exactly the same soil fungi.
- **(B)** No other plant species has established itself in the meadow since the orchid disappeared.
- **(C)** The restored meadow will provide the biological conditions needed for at least some planted seedlings to survive and reproduce, including any essential fungal partnership.
- **(D)** The seed bank has successfully germinated the orchid seeds under several distinct artificial temperature regimes.
- **(E)** Seeds will germinate at precisely the same percentage in the meadow as in the laboratory.

::::solution[Solution]
**Answer:** (C)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** Planting stored seeds will yield a self-sustaining wild population.
2. **Support.** Storage viability and suitable climate do not guarantee later establishment if required symbionts are absent.
3. **Prephrase.** At least some seedlings must have a viable path to reproductive maturity.
4. **Why (C) is right.** (C) is a necessary biological bridge. Negate it: the site lacks an indispensable condition for survival and reproduction. Self-sustaining establishment from these seeds is then impossible.
5. **Why the others fail.**
   - **(A)** (A) universalizes a species-specific relationship without necessity.
   - **(B)** (B) demands an empty plant community; other species can coexist with restored orchids.
   - **(D)** More proof of germination in controlled conditions remains silent about soil symbionts and self-sustaining field reproduction.
   - **(E)** (E) demands exact lab-field germination equality, much stronger than establishment requires.

**Check:** No seedlings capable of living and reproducing → no self-sustaining population from the planting.
::::
:::

:::problem[Question I.24]
An equipment supplier claims that a variable-speed ventilator will reduce the total electricity consumed by a metal-finishing factory. In a controlled laboratory demonstration the ventilator moved the same volume of air using fewer kilowatt-hours than the existing fixed-speed unit. The factory's engineer cautions that the total electricity bill also includes heating replacement air and running filtration equipment, whose demand may change with ventilation patterns. The supplier nevertheless predicts a net decrease in electricity use over an entire production year.

Which one of the following, if true, most strengthens the supplier’s prediction?

- **(A)** A year-long trial in a comparable factory showed that savings in fan electricity exceeded any increases in heating and filtration electricity under similar production schedules.
- **(B)** A laboratory technician measured identical air volumes in the two ventilators during one afternoon.
- **(C)** The old fan has been in service for several years, but remains within its design life.
- **(D)** The variable-speed unit automatically lowers its airflow during periods when production does not require full ventilation.
- **(E)** The variable-speed ventilator is marketed in more countries than the fixed-speed unit.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** A replacement will decrease total annual electricity use, not just fan electricity.
2. **Support.** Lab data establish one component's efficiency but leave interactions with other equipment open.
3. **Prephrase.** Look for a whole-system, comparable duration net-use measurement.
4. **Why (A) is right.** (A) confirms that the favorable fan savings exceed the potentially offsetting costs in a similar system across a year. That directly addresses the engineer's concern.
5. **Why the others fail.**
   - **(B)** (B) repeats a narrow volume comparison already contained in the premise and ignores seasonal system loads.
   - **(C)** (C) gives age without quantified energy impact.
   - **(D)** This describes another potentially favorable fan mechanism, but still leaves unanswered the net increases in heating and filtration consumption over the entire year.
   - **(E)** (E) substitutes distribution popularity for energy performance.

**Check:** Net change = fan savings − any added heating/filtration usage; the trial shows positive net savings.
::::
:::

:::problem[Question I.25]
An applied-ethics committee advises brands on when to disclose safety incidents involving subcontractors. Its rule is that a brand should promptly disclose a credible incident when withholding it would deprive purchasers of information material to a foreseeable safety decision. The committee distinguishes disclosure from the separate question of whether the brand is legally at fault, and cautions against announcing unverified rumors merely to appear transparent. Several managers now face claims varying in reliability, relevance, and potential severity.

Which one of the following actions is most consistent with the committee’s principle?

- **(A)** Withhold a corroborated contamination warning because customers might overreact to safety information.
- **(B)** Publicize only incidents that caused immediate financial losses to the brand.
- **(C)** Publicize every anonymous allegation of wrongdoing, regardless of corroboration or relevance to a buyer's decisions.
- **(D)** Publicize a substantiated subcontractor chemical-exposure incident that could affect the safe handling of a product, even though legal liability remains disputed.
- **(E)** Withhold all confirmed incidents whenever a court has not yet assigned liability.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** The rule mandates prompt disclosure of credible, decision-material safety information independent of fault.
2. **Support.** Credibility and prospective buyer safety, not public-relations value or court judgments, are the criteria.
3. **Prephrase.** Pick an action respecting verification and consumer decision relevance.
4. **Why (D) is right.** (D) satisfies both substantive conditions and correctly separates material safety disclosure from unsettled legal liability.
5. **Why the others fail.**
   - **(A)** (A) turns possible consumer concern into a reason to suppress exactly the warning the principle covers.
   - **(B)** (B) replaces buyer safety with the brand's short-term accounting losses.
   - **(C)** (C) drops credibility and materiality, an extreme transparency trap.
   - **(E)** (E) makes final legal liability a prerequisite the committee explicitly rejects.

**Check:** Credible + material to foreseeable safety choice → prompt disclosure, regardless of unresolved legal blame.
::::
:::

## 32.2 Section II: Reading Comprehension

### Passage 1

An agency responsible for granting shoreline construction permits used to publish a guide listing factors its examiners would consider: projected erosion, ecological disruption, and available alternatives. The guide did not specify weights. Applicants could address each factor, and examiners documented their reasons. Recently the agency adopted a computational screening model that assigns applications a risk score. The agency characterizes the model as an internal aid, exempt from the public consultation generally required before it adopts a binding rule. Permit denials still bear an examiner's signature, but records show that applications assigned the model's highest risk category are almost invariably denied.

A dispute about this arrangement concerns not the desirability of computers in administration, but the difference between an instrument that organizes evidence and one that effectively determines outcomes. The agency observes that examiners retain authority to override scores and that the model's numerical weights were developed from the same factors named in the published guide. Critics respond that a theoretically available override may be negligible if the agency requires supervisors to justify departures while never requiring explanations for following the score. Under those circumstances, the model may alter the practical standard an applicant must satisfy. Some administrative-law doctrines look to a policy's effect rather than its label when deciding whether public participation was necessary before adoption.

The critics' strongest argument, however, is not that every statistical aid is a hidden rule. Numerical tools can improve consistency by exposing differences in how examiners have treated similar applications. Nor would forcing public debate over every spreadsheet cell necessarily make decisions more intelligible. The concern arises when the agency declines to explain which changes in an applicant's evidence could alter the score and thereby change the outcome. Even a carefully validated model can become difficult to contest if applicants cannot identify the factors that matter decisively. The demand for a meaningful opportunity to respond is distinct from an insistence that every administrative process be understandable in exhaustive technical detail.

One proposed remedy is to require the agency to publish a range of illustrative applications, showing how changed facts affect classification, and to record the frequency and reasoning of examiner overrides. Such disclosure need not reveal proprietary code or every underlying datum. It would enable observers to distinguish a score functioning as advisory evidence from one functioning as a nearly conclusive threshold. If disclosure reveals a virtually automatic denial rule, the agency would have a stronger obligation to justify its policy through the procedures appropriate to a binding standard. If instead varied reasons routinely overcome scores, the claim that the model merely organizes evidence would gain support. The issue, then, is how administrative discretion actually operates, not whether a human name appears at the bottom of a decision.

:::problem[Question II.1]


Which one of the following most accurately expresses the main point of the passage?

- **(A)** Legal notice requirements are always triggered whenever a model uses numerical weights.
- **(B)** The validity of every computational model can be established solely by publishing its source code.
- **(C)** Whether an administrative scoring tool effectively establishes a binding standard should be judged by its real influence on decisions, aided by disclosures that make that influence contestable.
- **(D)** A human signature is sufficient to guarantee meaningful discretionary review.
- **(E)** Agencies should be prohibited from using predictive computer models in permit decisions.

::::solution[Solution]
**Answer:** (C)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The author argues for an effects-based distinction between evidence-organizing tools and de facto rules.
2. **Support.** Paragraphs two through four develop how to test practical discretion, with disclosure as a remedy.
3. **Prephrase.** Choose a qualified institutional criterion, not a blanket anti-model rule.
4. **Why (C) is right.** (C) captures both the central distinction and the proposed means of evaluating it.
5. **Why the others fail.**
   - **(A)** (A) makes the presence of weights automatically dispositive, whereas the passage emphasizes practical effects.
   - **(B)** (B) exaggerates one possible disclosure method the author explicitly says is unnecessary.
   - **(D)** (D) reverses the passage's warning that a signature may conceal automatic decisions.
   - **(E)** (E) is an extreme prohibition contradicted by the author's praise for useful numerical tools.

**Check:** The final sentence makes actual operation, not nominal human participation, decisive.
::::
:::

:::problem[Question II.2]


The passage most strongly suggests that which one of the following agency practices would make a model’s classification particularly likely to function as a binding rule?

- **(A)** Giving applicants examples of cases that received different scores.
- **(B)** Requiring special supervisory justification for departing from a high-risk score while treating conformity with that score as self-explanatory.
- **(C)** Recording overrides and publishing how often they occur.
- **(D)** Updating the model's predictions when new environmental data become available.
- **(E)** Permitting staff to provide written comments on model design before implementation.

::::solution[Solution]
**Answer:** (B)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The issue is whether override authority is real or merely formal.
2. **Support.** Paragraph two identifies asymmetric justification burdens as a reason overrides may rarely occur.
3. **Prephrase.** Seek the specific operational incentive against deviation.
4. **Why (B) is right.** (B) mirrors the passage's strongest illustration of apparent discretion becoming near-automatic compliance.
5. **Why the others fail.**
   - **(A)** (A) is the author's suggested transparency measure, which could expose rather than cause binding use.
   - **(C)** (C) is an audit of discretion, not necessarily a barrier to it.
   - **(D)** (D) changes predictive accuracy; accuracy alone says nothing about whether staff can depart from scores.
   - **(E)** (E) concerns design input, not post-scoring decision constraints.

**Check:** Asymmetric burden on overrides predicts scores becoming de facto thresholds.
::::
:::

:::problem[Question II.3]


The author’s observation that numerical tools can expose inconsistent treatment of similar applications serves primarily to

- **(A)** show that the agency is entitled to disregard procedural requirements whenever technology improves accuracy.
- **(B)** establish that the new model has in fact corrected every inconsistency in permit decisions.
- **(C)** replace the discussion of public participation with a discussion of statistical precision.
- **(D)** qualify the critics' objection by acknowledging a genuine administrative benefit of scoring aids.
- **(E)** concede that applicants have no legitimate interest in understanding decisive factors.

::::solution[Solution]
**Answer:** (D)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The author rejects blanket condemnation while preserving the concern about de facto rules.
2. **Support.** Paragraph three says the critics' strongest argument is not that every aid is hidden regulation.
3. **Prephrase.** Recognize a concession that narrows the target of criticism.
4. **Why (D) is right.** (D) identifies the favorable function of numerical aids within the author's balanced analysis.
5. **Why the others fail.**
   - **(A)** (A) invents a legal exemption the text never supports.
   - **(B)** (B) mistakes a possible benefit for a documented result of this model.
   - **(C)** (C) exaggerates a brief concession into a new primary topic.
   - **(E)** (E) contradicts the ensuing concern about meaningful response.

**Check:** The benefit is introduced immediately after a warning against treating every aid as a hidden rule.
::::
:::

:::problem[Question II.4]


According to the passage, which one of the following is a possible benefit of publishing illustrative applications and override records?

- **(A)** The agency would no longer need to gather ecological evidence.
- **(B)** The agency could conclusively demonstrate that its computer code contains no errors.
- **(C)** All applicants would receive permits after seeing how scores are calculated.
- **(D)** Observers could better distinguish a score used as advisory input from a score functioning as an almost automatic denial rule.
- **(E)** Proprietary code would necessarily become public information.

::::solution[Solution]
**Answer:** (D)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The remedy aims to reveal the model's practical force on decisions.
2. **Support.** The last paragraph directly contrasts almost automatic denials with routinely overridden scores.
3. **Prephrase.** Locate the stated role of illustrations and override frequencies.
4. **Why (D) is right.** (D) faithfully restates the passage's intended diagnostic function of disclosure.
5. **Why the others fail.**
   - **(A)** (A) invents freedom from evidence collection.
   - **(B)** (B) makes an unsupported claim of mathematical certainty.
   - **(C)** (C) confuses contestability with guaranteed approval.
   - **(E)** (E) contradicts the express statement that proprietary code need not be revealed.

**Check:** The measure reveals how facts alter scores and how often humans meaningfully depart from scores.
::::
:::

:::problem[Question II.5]


Which one of the following situations most closely illustrates the distinction central to the passage?

- **(A)** An agency invites public comments before adopting a clearly binding rule.
- **(B)** A benefits agency calls an eligibility score advisory, but staff deny virtually every application above a threshold and must obtain rare supervisory approval to depart from it.
- **(C)** A commission keeps numerical weights secret because its software vendor charges a licensing fee.
- **(D)** A city replaces paper permit forms with an online portal but preserves the same review procedure and standards.
- **(E)** A board publishes every line of code for a model that staff seldom consult.

::::solution[Solution]
**Answer:** (B)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The distinction is between nominal advice and practical decisiveness.
2. **Support.** The passage's high-risk cases are nearly always denied despite formal override authority.
3. **Prephrase.** Find a rule disguised by an advisory label and reinforced by asymmetric practice.
4. **Why (B) is right.** (B) is structurally identical: the purported aid operates as a near-conclusive gate, suggesting a binding policy in effect.
5. **Why the others fail.**
   - **(A)** (A) describes open rulemaking without the advisory-versus-binding puzzle.
   - **(C)** (C) deals with secrecy but does not show actual decisional force.
   - **(D)** (D) only changes delivery medium, not the decisional standard.
   - **(E)** (E) shows full code disclosure yet minimal model influence, undermining the example's relevance.

**Check:** The threshold's practical operation matters more than the agency's description.
::::
:::

:::problem[Question II.6]


The author’s attitude toward the critics’ concern is best described as

- **(A)** dismissive because human examiners formally sign denials.
- **(B)** unreserved endorsement of publishing every mathematical weight.
- **(C)** certainty that this agency has already violated binding legal requirements.
- **(D)** qualified sympathy, accepting the risk of a hidden binding standard while rejecting indiscriminate suspicion of numerical tools.
- **(E)** indifference to applicants' ability to contest negative decisions.

::::solution[Solution]
**Answer:** (D)

**Type:** Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author treats the practical concern seriously but resists blanket rules.
2. **Support.** The middle and final paragraphs both grant model benefits and demand evidence of real discretion.
3. **Prephrase.** Look for a measured position with two sides, not outrage or certainty.
4. **Why (D) is right.** (D) captures the passage's nuanced, conditional appraisal.
5. **Why the others fail.**
   - **(A)** (A) adopts the very human-signature defense the author contests.
   - **(B)** (B) demands exhaustive disclosure the passage says need not occur.
   - **(C)** (C) converts an open empirical question about discretion into a settled legal conclusion.
   - **(E)** (E) contradicts the focus on meaningful opportunity to respond.

**Check:** 'If disclosure reveals' marks a conditional legal consequence, not a proven violation.
::::
:::

### Passage 2

Early investigations of certain industrial oxidation reactions often measured little more than the quantities of reactants consumed and products recovered. From such balances, chemists proposed pathways by which bonds broke and formed. But distinct microscopic sequences can yield identical overall chemical equations. Thus the success of a reaction equation at predicting product proportions did not, on its own, establish that the proposed intermediate steps were correct. An important methodological shift occurred when chemists began using atoms of the same element with different isotopic masses as tracers, allowing them to ask where particular atoms traveled during a reaction.

One controversy involved oxygen exchanged between a dissolved compound and surrounding water before the compound underwent oxidation. A conventional model treated the oxygen in a final product as originating directly from an oxidizing reagent. Researchers using isotope-enriched water, however, found tracer oxygen in some final products even when the oxidizing reagent carried no tracer. At first this seemed to disprove the conventional model. Yet the tracer might have entered an intermediate compound *before* the step the model described. The final location of a tagged atom therefore distinguished some proposed pathways but did not uniquely reconstruct the timing of every bond change.

To narrow the alternatives, researchers varied the duration for which reactants contacted isotope-enriched water before oxidation. They also measured whether isotopic exchange occurred in mixtures lacking the oxidizing reagent. Short contact periods produced less tracer incorporation, while longer periods produced more. Exchange was detectable without the oxidant. These findings supported a model in which a preliminary reversible exchange furnished labeled intermediates that later participated in oxidation. They did not establish that a single pathway operated under every temperature and acidity condition. Indeed, secondary pathways could be negligible under one experimental arrangement and dominant under another. Interpreting the measurements also required checks that the label had not been diluted by untracked oxygen in solvents or apparatus. Such controls did not make inference automatic; they helped clarify which alternative explanations an experiment genuinely ruled out. A result could be repeatable and still leave multiple microscopic routes open.

Some historians describe isotopic tracing as the moment chemistry began to observe reaction mechanisms directly. That description captures the excitement of tracking atoms previously indistinguishable from one another, but it overstates what the measurements delivered. A tracer's destination is an observation; the intervening route remains an inference constrained by other experiments. The lasting achievement was a more discriminating system of tests. Chemists could now design experiments in which competing mechanisms predicted different patterns of isotope distribution across time and conditions. The value of the method lay less in replacing interpretation with sight than in making interpretations answerable to stronger evidence. This distinction also explains why a surprising label in a product was the start of a new investigation, not its conclusion.

:::problem[Question II.7]


The primary purpose of the passage is to

- **(A)** defend a conventional oxidation model against every possible alternative.
- **(B)** explain how isotope tracing sharpened the experimental testing of reaction mechanisms while showing why observed atomic destinations do not by themselves reveal complete pathways.
- **(C)** argue that historians rather than laboratory chemists first identified oxygen intermediates.
- **(D)** demonstrate that reaction equations cannot predict the amounts of final chemical products.
- **(E)** show that isotope exchange occurs at exactly the same rate at all temperatures.

::::solution[Solution]
**Answer:** (B)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The author evaluates the power and inferential limits of tracing methods.
2. **Support.** An initial seeming disproof is resolved by timing experiments; the last paragraph qualifies claims of direct observation.
3. **Prephrase.** Capture both methodological advance and limitation.
4. **Why (B) is right.** (B) covers the entire passage and preserves the observation-versus-inference distinction.
5. **Why the others fail.**
   - **(A)** (A) exaggerates a possible rescue of one model into a universal defense.
   - **(C)** (C) attributes a scientific discovery to historians, who are discussed as interpreters of the method.
   - **(D)** (D) falsely denies overall equations' predictive success, which the opening acknowledges.
   - **(E)** (E) contradicts the stated sensitivity to conditions and timing.

**Check:** The final evaluation credits stronger tests, not direct visual access to every microscopic step.
::::
:::

:::problem[Question II.8]


Why did tracer oxygen in the final product not necessarily establish that the conventional oxidation model was wrong?

- **(A)** The product proportions had necessarily been recorded incorrectly.
- **(B)** The laboratory had no reliable way to distinguish isotopes of oxygen by mass.
- **(C)** Tracer oxygen could have entered an intermediate through exchange before the step described by that model.
- **(D)** The oxidizing reagent was always manufactured from isotope-enriched water.
- **(E)** Oxygen isotope tracing can identify only atoms of carbon.

::::solution[Solution]
**Answer:** (C)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Finding a tagged atom at the end does not locate every intermediate step.
2. **Support.** Paragraph two explicitly introduces exchange before the oxidation step as an alternative.
3. **Prephrase.** Preserve the possible timing of tracer entry.
4. **Why (C) is right.** (C) states the passage's key caveat about the apparently disconfirming finding.
5. **Why the others fail.**
   - **(A)** (A) substitutes measurement error for the passage's chemical explanation.
   - **(B)** (B) denies the tracer method that grounds the research.
   - **(D)** (D) supplies a universal reagent-source claim opposite to the experiment's setup.
   - **(E)** (E) confuses oxygen isotopes with an entirely different element.

**Check:** A label arriving before oxidation is consistent with the tracer appearing in final products afterward.
::::
:::

:::problem[Question II.9]


The experiments conducted without the oxidizing reagent are discussed primarily because they

- **(A)** supplied evidence for an exchange process that could precede, rather than form part of, the oxidation stage.
- **(B)** showed that every proposed oxidation mechanism was false.
- **(C)** proved that the final oxidation product could form in the complete absence of all reactants.
- **(D)** established that a reaction pathway never varies with acidity.
- **(E)** demonstrated that tracer oxygen could not be transferred to any dissolved species.

::::solution[Solution]
**Answer:** (A)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The authors use the control to test a preliminary route for tracer incorporation.
2. **Support.** Exchange without oxidant means incorporation need not occur during the oxidation stage.
3. **Prephrase.** Ask what mechanism the minus-oxidant test isolates.
4. **Why (A) is right.** (A) identifies the independent pre-oxidation exchange process supported by the control.
5. **Why the others fail.**
   - **(B)** (B) confuses testing one stage with disproving all pathways.
   - **(C)** (C) makes a claim about final product formation never made in the control.
   - **(D)** (D) contradicts the paragraph's caveat about acidity conditions.
   - **(E)** (E) says the opposite of observed exchange in the control.

**Check:** If exchange happens without the oxidant, oxidation cannot be necessary for that exchange.
::::
:::

:::problem[Question II.10]


Which one of the following patterns was reported when researchers varied pre-oxidation contact with isotope-enriched water?

- **(A)** The oxidizing reagent itself became permanently depleted of ordinary oxygen.
- **(B)** Shorter contact increased incorporation, but only after the oxidant was added.
- **(C)** Longer contact produced more tracer incorporation, and some exchange also occurred without oxidant.
- **(D)** Contact duration had no measurable relation to isotope incorporation.
- **(E)** Tracer incorporation disappeared at every acidity once mixing exceeded a threshold.

::::solution[Solution]
**Answer:** (C)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The passage reports a duration gradient and a control experiment.
2. **Support.** The third paragraph pairs less labeling at short durations with more at long durations.
3. **Prephrase.** Combine the two directly stated observations.
4. **Why (C) is right.** (C) accurately retains both the temporal trend and the oxidant-absent exchange.
5. **Why the others fail.**
   - **(A)** (A) switches from tracer distribution to permanent depletion of the reagent.
   - **(B)** (B) reverses the trend and wrongly makes oxidant essential.
   - **(D)** (D) negates the observed time trend.
   - **(E)** (E) invents a universal acidity threshold.

**Check:** The data are expressly paired in paragraph three, not inferred from the historian's appraisal.
::::
:::

:::problem[Question II.11]


The passage most strongly supports which one of the following statements?

- **(A)** The absence of tracer in a final product proves that no reversible exchange occurred.
- **(B)** Observing how tracer distribution changes under carefully altered conditions can help distinguish hypotheses that yield the same overall reaction equation.
- **(C)** A tracer atom in a product uniquely determines the order of every molecular event that preceded it.
- **(D)** Historians of science unanimously agree that isotopic tracing converted mechanisms from hypotheses into direct observations.
- **(E)** A chemical mechanism that explains one set of tracer results must explain every possible temperature condition.

::::solution[Solution]
**Answer:** (B)

**Type:** Inference (Chapter 18)

1. **Conclusion.** The text commends discriminating experiments, not uniquely observed pathways.
2. **Support.** The first and final paragraphs contrast same net equations with divergent tracer predictions.
3. **Prephrase.** State a modest methodological implication: varying conditions separates candidate mechanisms.
4. **Why (B) is right.** (B) is directly supported by the described research program.
5. **Why the others fail.**
   - **(A)** (A) infers absence of exchange from a final measurement that may not capture transient labeling.
   - **(C)** (C) is precisely the overstatement the passage rejects.
   - **(D)** (D) exaggerates a view attributed to 'some historians' and changes its substance.
   - **(E)** (E) generalizes beyond the stated condition-dependence of pathways.

**Check:** Different predicted tracer patterns permit empirical discrimination even with identical net equations.
::::
:::

:::problem[Question II.12]


The author’s appraisal of the historical description of isotope tracing as direct observation of mechanisms is best characterized as

- **(A)** dismissive of its significance because isotope tracing added no new tests.
- **(B)** accepting it without qualification because all reaction steps are now visible.
- **(C)** critical because the method relied exclusively on mistaken product balances.
- **(D)** neutral about whether any scientific interpretation could be evidence-based.
- **(E)** acknowledging its expressive appeal while rejecting its literal implication that intermediate steps became directly observable.

::::solution[Solution]
**Answer:** (E)

**Type:** Author’s attitude / tone (Chapter 18)

1. **Conclusion.** The author distinguishes the excitement of tracing atoms from seeing their routes.
2. **Support.** The final paragraph calls the description appealing but overstated.
3. **Prephrase.** Choose a mixed attitude: appreciation plus precision.
4. **Why (E) is right.** (E) corresponds exactly to the stated historical appraisal.
5. **Why the others fail.**
   - **(A)** (A) denies the acknowledged methodological achievement.
   - **(B)** (B) removes the explicit objection.
   - **(C)** (C) invents exclusive dependence on faulty balances rather than tracer measurements.
   - **(D)** (D) contradicts the account of stronger evidence-based interpretation.

**Check:** Destination is observed; route is inferred is the controlling contrast.
::::
:::

:::problem[Question II.13]


Which one of the following investigations would most closely follow the methodological lesson the author draws?

- **(A)** Choose a single reaction temperature because all alternative pathways must be absent there.
- **(B)** Compare only the total mass of final product in two reactions known to share the same overall equation.
- **(C)** Select a preferred reaction diagram and regard any final product as proof of it.
- **(D)** Repeat a reaction unchanged many times and ignore intermediate measurements.
- **(E)** Design isotope-labeling conditions under which two candidate pathways predict different time-dependent labeling patterns, then compare those predictions with measurements.

::::solution[Solution]
**Answer:** (E)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The method tests rival pathways through differing observational implications.
2. **Support.** Paragraph four emphasizes varying conditions and time to make theories answerable to evidence.
3. **Prephrase.** Generate discriminating predictions rather than merely reproducing totals.
4. **Why (E) is right.** (E) is the discriminating experiment: predicted labeling differences are compared against outcomes to test rival mechanisms.
5. **Why the others fail.**
   - **(A)** (A) assumes competing pathways must vanish at one temperature, which is not the proposed test.
   - **(B)** (B) repeats the undiagnostic overall-balance measurement.
   - **(C)** (C) is confirmation-by-assumption, not a genuine test.
   - **(D)** (D) gathers repetitions without probing mechanism.

**Check:** Two different predicted label trajectories can separate otherwise indistinguishable models.
::::
:::

### Passage 3 (comparative)

**Passage A**

In many grain-producing regions, merchants once extended credit on the expectation of repayment after harvest, when farmers could sell crops. Standardized warehouse receipts changed this relationship. A receipt certified that a specified quantity and grade of grain had been deposited in a recognized storehouse, allowing a lender to accept something more transferable than a promise tied to a particular farmer. Historians sometimes treat the spread of receipts as a technical improvement in bookkeeping. Yet their transformative effect depended on courts enforcing transfers and inspectors certifying grades consistently. Without trustworthy institutions, a document describing grain could neither reassure distant creditors nor circulate as collateral. That is why the introduction of receipts mattered most where institutional reforms made their claims credible. Changes in local bargaining power followed as consequences of this broader transformation in enforceable property claims.

The evidence often cited for receipts' success comes from comparisons of interest charges before and after legal recognition. Rates generally declined most where lenders could confidently sell claims against stored grain. But the data support an institutional story more directly than a story about better measurement alone: scales and grade lists existed long before distant lenders accepted warehouse paper. It was the improved enforceability of the paper that made grain legible to markets beyond the producing district. This claim need not imply that every region developed credit in the same way. A history centered on institutions can recognize variation in local practices while arguing that standardized, enforceable claims created new possibilities for distance lending. The question is which condition made a change in scale possible, rather than whether local negotiations ceased.

**Passage B**

Warehouse receipts are frequently celebrated as devices that connected farmers to impersonal credit markets. In practice, access to the recognized storehouses could be controlled by a small group of local merchants. Farmers needing immediate cash could be compelled to accept unfavorable grading decisions or high storage charges. Legal enforceability did make receipts more attractive to distant lenders, but that security often increased the market power of those authorized to issue them. A national statute might have created a transferable claim without giving small producers meaningful choice over the terms on which their crops entered storage.

The most revealing records are therefore not simply regional interest-rate averages but disputes between growers, graders, and warehouse operators. In one set of district ledgers, nominal borrowing costs fell after receipt-based lending expanded, while fees paid at deposit rose. Farmers who owned large storage facilities benefited; tenants who could not store grain independently sometimes gained little. This does not mean receipts were economically useless, or that enforcement was irrelevant. It means the distribution of benefits depended on bargaining arrangements that aggregate credit statistics often concealed. To understand whether the innovation broadened opportunity, one must examine who controlled its point of entry as well as who could enforce the claims it created.

:::problem[Question II.14]


Which one of the following best describes the relationship between passages A and B?

- **(A)** A emphasizes the enforceable institutional basis of wider credit markets, while B argues that analysis must also account for local control over access and the distribution of gains.
- **(B)** A disputes that warehouse receipts were legally transferable; B defends their transferability.
- **(C)** A attributes falling interest rates to better scales alone; B attributes them to more accurate crop measurements.
- **(D)** A argues that receipt systems had no effect on credit; B says they eliminated all rural inequality.
- **(E)** A concerns grain production technology while B concerns only international shipping.

::::solution[Solution]
**Answer:** (A)

**Type:** Comparative reading (Chapter 17)

1. **Conclusion.** Both address the economic consequences of receipts but emphasize different causal levels.
2. **Support.** A focuses on institutions enabling claims to circulate; B stresses gatekeepers and costs concealed by aggregates.
3. **Prephrase.** Map A's thesis, B's thesis, then their difference in emphasis.
4. **Why (A) is right.** (A) captures complementary but tense perspectives without claiming complete opposition.
5. **Why the others fail.**
   - **(B)** (B) falsely claims A denies transferability, which is its central mechanism.
   - **(C)** (C) attributes a technical-scale thesis that A explicitly rejects as sufficient.
   - **(D)** (D) exaggerates both passages into absolute opposite claims never made.
   - **(E)** (E) assigns unrelated subjects and erases both authors' interest in credit markets.

**Check:** B explicitly grants enforceability matters, so it supplements rather than simply negates A.
::::
:::

:::problem[Question II.15]


The authors of both passages would most likely agree with which one of the following statements?

- **(A)** Receipt-based lending always improved the position of every tenant farmer.
- **(B)** Technological improvements in grain weighing were the only factor that mattered to receipt-based finance.
- **(C)** Recognized warehouse operators were invariably selected through open elections.
- **(D)** The legal reliability of claims represented by receipts could matter to the willingness of lenders beyond a local district to extend credit.
- **(E)** An increase in storage fees necessarily eliminated every reduction in borrowing costs.

::::solution[Solution]
**Answer:** (D)

**Type:** Comparative reading (Chapter 17)

1. **Conclusion.** The shared ground is the value of trustworthy claims to distant creditors.
2. **Support.** A centrally argues this; B says legal enforceability made receipts more attractive to distant lenders.
3. **Prephrase.** Find a modest proposition each author actually endorses.
4. **Why (D) is right.** (D) is supported by explicit statements in both passages.
5. **Why the others fail.**
   - **(A)** (A) is denied or at least challenged by B's examples of tenants gaining little.
   - **(B)** (B) asserts the measurement-only story A criticizes and B does not defend.
   - **(C)** (C) invents governance arrangements neither author discusses.
   - **(E)** (E) converts potentially offsetting charges into a necessary total cancellation unsupported by either.

**Check:** Both must have a stake: each links enforcement to lender confidence, even though B questions who benefits.
::::
:::

:::problem[Question II.16]


The authors differ most clearly in their emphasis on which kind of historical evidence?

- **(A)** Both reject documentary records in favor of oral histories alone.
- **(B)** A and B both claim that prices are irrelevant to economic history.
- **(C)** A gives particular explanatory weight to legal recognition and changes in credit terms, while B urges examination of local ledgers, fees, and disputes that average rates can conceal.
- **(D)** A relies exclusively on individual farmer diaries, while B relies exclusively on national statutes.
- **(E)** A studies how fertilizer altered crop yields, while B measures the weather.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative reading (Chapter 17)

1. **Conclusion.** A's evidentiary interest is system-level enforceability; B wants distributional and bargaining records.
2. **Support.** A cites interest comparisons and institutional reforms; B cites disputes and district ledgers.
3. **Prephrase.** Distinguish aggregate/institutional emphasis from transactions at the point of entry.
4. **Why (C) is right.** (C) accurately characterizes the evidence each author highlights without falsely saying either uses only one source.
5. **Why the others fail.**
   - **(A)** (A) attributes an exclusive oral-history position absent from either.
   - **(B)** (B) contradicts both authors' attention to rates and costs.
   - **(D)** (D) reverses or invents exclusivity and misstates their sources.
   - **(E)** (E) shifts the subject from rural credit to agricultural inputs and weather.

**Check:** Both cite rates, but B insists nominal rates alone cannot determine growers' actual gain.
::::
:::

:::problem[Question II.17]


How would the author of passage B most likely respond to passage A’s evidence that interest charges declined after receipts gained legal recognition?

- **(A)** By denying that warehouse receipts recorded grain quantity or grade.
- **(B)** By suggesting that the declines might coexist with higher storage or grading charges, leaving some farmers with little net benefit.
- **(C)** By claiming that interest charges always rose as legal enforcement improved.
- **(D)** By asserting that no lender ever accepted a transferable receipt.
- **(E)** By arguing that declines in interest are sufficient to establish equal gains for all borrowers.

::::solution[Solution]
**Answer:** (B)

**Type:** Comparative reading (Chapter 17)

1. **Conclusion.** B challenges the interpretation of aggregate interest rates as distributive success.
2. **Support.** B's district example explicitly combines reduced nominal borrowing costs with rising deposit fees.
3. **Prephrase.** Acknowledge A's rate evidence, then introduce hidden cost incidence.
4. **Why (B) is right.** (B) restates B's precise qualification, not a denial that rates could fall.
5. **Why the others fail.**
   - **(A)** (A) is false about the basic receipt definition that both accept.
   - **(C)** (C) denies an empirical decline B expressly reports in a case.
   - **(D)** (D) contradicts B's recognition of distant-market lending.
   - **(E)** (E) makes the very equal-benefits inference B challenges.

**Check:** Nominal borrowing cost reductions do not determine the net position of each depositor.
::::
:::

:::problem[Question II.18]


According to passage A, why were scales and grade lists by themselves insufficient to make warehouse receipts widely acceptable to distant lenders?

- **(A)** Local merchants were prohibited from lending to farmers in every region.
- **(B)** Measurements of grain quantity were universally inaccurate before modern mechanization.
- **(C)** Distant lenders preferred unverifiable personal promises over grain collateral.
- **(D)** Without reliably enforced transferable claims, measurements of stored grain did not assure distant creditors that they could realize the collateral.
- **(E)** No region adopted rules for grading grain until after warehouse receipts disappeared.

::::solution[Solution]
**Answer:** (D)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** A attributes expanded collateral markets to credibility backed by institutions.
2. **Support.** The final paragraph says measurement tools predated distant acceptance of paper.
3. **Prephrase.** Identify the missing legal credibility of the document, not deficiencies of scales.
4. **Why (D) is right.** (D) closely tracks A's institutional explanation.
5. **Why the others fail.**
   - **(A)** (A) invents a universal legal ban on merchant lending.
   - **(B)** (B) is a universal accuracy claim unsupported by A.
   - **(C)** (C) reverses the preference change the passage explains.
   - **(E)** (E) contradicts the chronology of existing grading technology.

**Check:** Existing scales + absent enforcement did not yield marketable paper, so measurement alone was insufficient.
::::
:::

:::problem[Question II.19]


Which one of the following findings would most directly weaken the concern, raised in passage B, that warehouse gatekeepers limited the benefits of receipt-based credit to small producers?

- **(A)** Some large warehouse operators profited greatly from receipt-based lending.
- **(B)** Banks could sell warehouse claims more easily once courts recognized them.
- **(C)** Across nearly all districts formerly dominated by a few storehouse operators, independent small growers obtained competing low-fee storage access and recorded substantial gains in net returns after receipt systems expanded.
- **(D)** Nominal regional interest rates fell after warehouse receipts became legally recognized.
- **(E)** Recognized warehouses sometimes imposed high storage fees on tenants.

::::solution[Solution]
**Answer:** (C)

**Type:** Comparative reading (Chapter 17)

1. **Conclusion.** B says institutional improvement could coexist with persistent gatekeeper power and negligible gains for smaller farmers.
2. **Support.** The argument hinges on point-of-entry control and net, not merely nominal, outcomes.
3. **Prephrase.** Find evidence of access and realized net gains for the disadvantaged group.
4. **Why (C) is right.** (C) would weaken B's distributive concern in the settings it identifies. It need not refute every district example.
5. **Why the others fail.**
   - **(A)** (A) reinforces distributional skew rather than challenging it.
   - **(B)** (B) is the lender-side improvement B already grants.
   - **(D)** (D) is a half-right aggregate fact B explicitly says is inadequate.
   - **(E)** (E) is direct evidence for B's fee-offset concern.

**Check:** The proposed finding changes both the bargaining-access condition and the farmers' ultimate payoffs.
::::
:::

:::problem[Question II.20]


Which one of the following scenarios most closely parallels the difference between the authors’ emphases?

- **(A)** One analyst explains how enforceable digital invoices make lending possible across distances; another studies whether small firms can use the system without being disadvantaged by the dominant invoicing platforms.
- **(B)** Two researchers both attribute lower prices exclusively to newer weighing equipment.
- **(C)** One analyst claims all electronic payments are fraudulent; another finds some are not.
- **(D)** One researcher measures rainfall while another researches the date a bridge was built.
- **(E)** Two historians disagree on whether a national law ever existed, but neither examines its effects.

::::solution[Solution]
**Answer:** (A)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** A explains institutional feasibility; B examines unequal access and distribution within that system.
2. **Support.** The passages are not simple law-versus-no-law opposition.
3. **Prephrase.** Look for an enabling infrastructure story supplemented by gatekeeper scrutiny.
4. **Why (A) is right.** (A) preserves the two analytic levels and the possibility that both claims hold.
5. **Why the others fail.**
   - **(B)** (B) duplicates a single technological explanation instead of contrasting access and institutions.
   - **(C)** (C) is a crude universal-versus-exception contrast with no distributive dimension.
   - **(D)** (D) compares unrelated topics rather than complementary explanations.
   - **(E)** (E) substitutes a factual dispute over a law's existence, not a dispute over what it means.

**Check:** Infrastructure can broaden markets while intermediaries retain bargaining power over entry.
::::
:::

### Passage 4

The surviving promptbook of a theatrical production may look like an unusually precise record of performance. Its pages can identify entrances, lighting cues, changes to dialogue, and even the duration of pauses. Theater historians have consequently used promptbooks to reconstruct productions that were never filmed. But a promptbook occupies an ambiguous position between a plan for performance and evidence of what spectators actually witnessed. Some annotations were made before rehearsals, others during a run, and still others by later companies reusing the script. Without knowing when a note was entered, scholars may mistakenly translate a proposed movement into a movement that occurred onstage.

This problem is particularly acute in accounts of experimental theater that emphasized improvisation. In one surviving set of records for a late twentieth-century production, the stage manager repeatedly changed a notation for the moment when an actor crossed a narrow bridge of light. Several reviews nevertheless described that crossing as an apparently spontaneous interruption. It would be tempting to conclude either that the actors abandoned their formal cues or that the spontaneity was entirely manufactured. Neither inference is justified. A repeated alteration in the book shows that the company worked on the crossing, but it does not establish what happened on any particular night or what degree of discretion the actor retained within the planned sequence.

Historians can partly repair this limitation by comparing promptbooks with audience diaries, photographs, ticketed-performance reports, and the recollections of technicians. Each source has a characteristic distortion. Reviewers select moments that support an argument; photographs freeze transitions; recollections become more coherent with time. These records are most illuminating when they disagree in ways that can be explained by different performance dates or different vantage points. Thus conflicting accounts are not always defective evidence. They can reveal a production's deliberate variability, provided that the researcher does not automatically interpret every discrepancy as intentional improvisation. A useful archive preserves both the dates attached to its documents and the gaps where dates are uncertain. Researchers should resist smoothing those gaps into a seamless story merely because a coherent sequence would be easier to stage or publish. The uncertainty itself can be part of the historical finding.

A further difficulty is that reconstructing a production can itself become a performance. Modern directors may enact the promptbook's instructions exactly and describe the result as historically authentic. Yet fidelity to the written cues might erase the flexible relationships among actors, technicians, and audiences that the original production cultivated. The better historical reconstruction may therefore be one that makes its uncertainties visible: it distinguishes documented instructions from witnessed actions and states which interpretive choices a new company has made. This approach does not abandon the possibility of historical knowledge. Instead, it treats performance as an event reconstructed from partial, differently situated records rather than as a fixed artwork silently waiting inside an annotated script.

:::problem[Question II.21]


Which one of the following best states the central claim of the passage?

- **(A)** A faithfully copied promptbook always reproduces the original audience's experience.
- **(B)** Audience reviews are categorically more trustworthy than theatrical records kept by technicians.
- **(C)** Because performers sometimes improvise, no reliable evidence about theatrical history survives.
- **(D)** The most authentic reconstructions eliminate improvisation so that cues are standardized.
- **(E)** Promptbooks are valuable but incomplete evidence of historical theater, so responsible reconstructions should distinguish written plans from witnessed events and acknowledge interpretive uncertainty.

::::solution[Solution]
**Answer:** (E)

**Type:** Main point / primary purpose (Chapter 18)

1. **Conclusion.** The author advocates cautious reconstruction from heterogeneous records.
2. **Support.** The text traces uncertain annotations, conflicting witness records, and the limitations of literal reenactment.
3. **Prephrase.** Choose a balanced claim about evidentiary limits and transparent reconstruction.
4. **Why (E) is right.** (E) spans every paragraph and preserves the author's positive confidence in historical inquiry.
5. **Why the others fail.**
   - **(A)** (A) reverses the warning that exact cue fidelity can erase flexible interactions.
   - **(B)** (B) creates a hierarchy of sources the author does not endorse.
   - **(C)** (C) turns qualified skepticism into total impossibility, explicitly rejected.
   - **(D)** (D) imposes standardized reenactment, the approach the author questions.

**Check:** The final paragraph expressly says the approach does not abandon historical knowledge.
::::
:::

:::problem[Question II.22]


The account of the actor crossing a bridge of light serves primarily to

- **(A)** prove that the crossing happened at the identical moment on every night of the run.
- **(B)** illustrate why changing written cues and reports of spontaneity do not by themselves reveal exactly what occurred in performance.
- **(C)** demonstrate that a single reviewer consistently recorded every onstage event.
- **(D)** establish that directors forbade actors to make unscripted movements.
- **(E)** show that the promptbook's annotations were all entered decades after the production.

::::solution[Solution]
**Answer:** (B)

**Type:** Function / purpose of a part (Chapter 18)

1. **Conclusion.** The example demonstrates the gap between rehearsal records and actual performance.
2. **Support.** The author contrasts changing notes with reviewers' perceptions and rejects both tempting extreme inferences.
3. **Prephrase.** Identify the specific evidentiary ambiguity the case exemplifies.
4. **Why (B) is right.** (B) closely paraphrases the lesson: neither unscripted abandonment nor total fabrication of spontaneity follows.
5. **Why the others fail.**
   - **(A)** (A) contradicts the documented revisions and the lack of nightly evidence.
   - **(C)** (C) exaggerates the reliability of an individual review.
   - **(D)** (D) invents a production-wide ban not established by the crossing.
   - **(E)** (E) assigns an unmentioned date to every annotation.

**Check:** A planned, revised cue can coexist with variable live execution.
::::
:::

:::problem[Question II.23]


The passage suggests that conflicting accounts of a production can be historically useful when

- **(A)** all individual reports are merged into a single description with no uncertainties.
- **(B)** all contradictions are assumed to be intentional acts of improvisation.
- **(C)** the promptbook is rejected and the account of the most famous reviewer is accepted instead.
- **(D)** technicians' recollections are accepted without comparison to other sources.
- **(E)** their divergence can plausibly be related to different dates or audience positions and used to test a more nuanced account of the performance.

::::solution[Solution]
**Answer:** (E)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Disagreement need not be pure error; it may reveal meaningful variation.
2. **Support.** Paragraph three lists multiple source limitations and the conditions under which disagreement illuminates.
3. **Prephrase.** Select a conditional use of conflict without assuming every mismatch is intentional.
4. **Why (E) is right.** (E) follows the stated method of considering dates and vantage points.
5. **Why the others fail.**
   - **(A)** (A) conceals the very uncertainties the author recommends exposing.
   - **(B)** (B) is the specific overinterpretation the author warns against.
   - **(C)** (C) substitutes reviewer prestige for corroboration.
   - **(D)** (D) treats memory as infallible despite its described distortions.

**Check:** Different nights can differ; different observers can see different details without one text being universally false.
::::
:::

:::problem[Question II.24]


Which one of the following pairings of evidence and limitation is explicitly supported by the passage?

- **(A)** Audience diaries: they can contain only technical accounts, never personal interpretations.
- **(B)** Recollections: their accuracy necessarily improves as more years pass.
- **(C)** Photographs: they arrest a transition at one instant and may not convey its unfolding in time.
- **(D)** Photographs: they reliably preserve the duration of every dramatic pause.
- **(E)** Reviews: they reproduce every movement with equal attention, regardless of a reviewer's thesis.

::::solution[Solution]
**Answer:** (C)

**Type:** Detail / recognition (Chapter 18)

1. **Conclusion.** The paragraph compares media by characteristic distortions.
2. **Support.** Photographs freeze transitions, whereas recollections cohere retrospectively and reviews select scenes.
3. **Prephrase.** Match one medium to its explicitly named limitation.
4. **Why (C) is right.** (C) faithfully restates the photography point and does not elevate one source over all others.
5. **Why the others fail.**
   - **(A)** (A) invents an exclusive technical genre for diaries.
   - **(B)** (B) reverses the warning about retrospectively smoothed memory.
   - **(D)** (D) assigns photographs impossible temporal completeness.
   - **(E)** (E) denies the selective framing of reviews stated in the passage.

**Check:** A still image captures a slice of action, not the temporal progression itself.
::::
:::

:::problem[Question II.25]


Why does the author regard literal enactment of a historical promptbook as potentially misleading?

- **(A)** Strict adherence to recorded cues can suppress flexible relationships among performers, technicians, and audiences that mattered to the original event.
- **(B)** Promptbooks contain only audience criticism and never performance instructions.
- **(C)** The original production necessarily had no rehearsals or planned movements.
- **(D)** Every modern theater uses a different language from its historical source.
- **(E)** The original scripts generally have no directions for lighting.

::::solution[Solution]
**Answer:** (A)

**Type:** Inference (Chapter 18)

1. **Conclusion.** Authenticity is not equivalent to fidelity to the recorded plan.
2. **Support.** The last paragraph contrasts exact cues with historically cultivated flexibility.
3. **Prephrase.** Identify what the copy may erase, rather than what it may reproduce.
4. **Why (A) is right.** (A) is the author's stated reason that exact replication can paradoxically misrepresent the event.
5. **Why the others fail.**
   - **(B)** (B) contradicts the definition of promptbooks as annotated performance scripts.
   - **(C)** (C) incorrectly treats planning and rehearsals as absent.
   - **(D)** (D) invents a universal language difference.
   - **(E)** (E) is contradicted by promptbooks' lighting cues in the opening.

**Check:** A faithful plan may be an unfaithful rendition of live variation.
::::
:::

:::problem[Question II.26]


Which one of the following best describes the organization of the passage?

- **(A)** A seemingly authoritative source is problematized, an illustrative case and corroborating methods are discussed, and a qualified approach to reconstruction is proposed.
- **(B)** An incontrovertible factual record is presented, then a chronological biography of one actor.
- **(C)** A staging method is recommended, and all remaining paragraphs describe successful modern copies of that method.
- **(D)** A list of equipment is followed by a formal legal rule governing theater archives.
- **(E)** Two irreconcilable art movements are contrasted, without a judgment about either.

::::solution[Solution]
**Answer:** (A)

**Type:** Structure / organization (Chapter 18)

1. **Conclusion.** The passage develops an evidentiary problem into a methodological proposal.
2. **Support.** Promptbook ambiguity → bridge-of-light case → triangulation → responsible reenactment.
3. **Prephrase.** Map each paragraph's function in sequence.
4. **Why (A) is right.** (A) accurately tracks both the critical and constructive stages of the author's reasoning.
5. **Why the others fail.**
   - **(B)** (B) mistakes the passage's uncertainty for an unquestioned archive and adds biography.
   - **(C)** (C) places the proposal before the evidence and invents successful copies.
   - **(D)** (D) substitutes an inventory and regulation for the author's historiographical argument.
   - **(E)** (E) turns evidentiary analysis into art-movement opposition.

**Check:** The final paragraph offers a proposed method rather than merely recapping the records.
::::
:::

:::problem[Question II.27]


Which one of the following approaches to reconstructing an early improvised music performance best reflects the author's recommended approach?

- **(A)** Discard the score because any divergence between written notes and recordings proves it was fraudulent.
- **(B)** Play every notation in a surviving score exactly and claim this necessarily duplicates the historic concert.
- **(C)** Use the loudest audience member's recollection as the sole authoritative source.
- **(D)** Assume every difference between two accounts was a deliberate artistic variation.
- **(E)** Compare the surviving score with eyewitness reports and rehearsal recordings, then label which choices are documented and which require present-day interpretation.

::::solution[Solution]
**Answer:** (E)

**Type:** Analogy / application (Chapter 18)

1. **Conclusion.** The passage recommends triangulation with declared uncertainty.
2. **Support.** Theater documents are plans and reports, each partial and situated.
3. **Prephrase.** Translate that distinction into score, recordings, witnesses, and candid labeling.
4. **Why (E) is right.** (E) is structurally parallel and retains the evidentiary humility the author urges.
5. **Why the others fail.**
   - **(A)** (A) treats divergence as fraud rather than potentially informative variation.
   - **(B)** (B) conflates written plan with an actual event.
   - **(C)** (C) elevates one impression over corroboration and source criticism.
   - **(D)** (D) commits the all-discrepancies-are-intentional error the author names.

**Check:** Documented instructions and witnessed sounds remain separate even when used together.
::::
:::

## 32.3 Section III: Logical Reasoning

:::problem[Question III.1]
A banking consultant argues that the closing of physical branches has caused customers to withdraw deposits from small banks. Over the past two years, small banks that closed more branches lost a larger share of their deposits than banks that kept most branches open. But branch closings are often undertaken because deposits have already begun to decline, leaving too few customers to justify maintaining a location. The consultant neither examined deposit trends before the closings nor distinguished voluntary account transfers from closures initiated by struggling banks.

The argument is most vulnerable to criticism on the grounds that it

- **(A)** concludes that all small banks should increase their branch counts.
- **(B)** confuses total deposits with total bank assets, though it compares no asset data.
- **(C)** fails to consider that declining deposits may have prompted branch closings rather than resulted from them.
- **(D)** assumes that branches are operated exclusively by the banks' largest depositors.
- **(E)** assumes that the deposits lost by closing banks were withdrawn only by customers who used the branches that closed.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The consultant attributes deposit losses to closing branches.
2. **Support.** The correlation might instead result from earlier losses inducing closures.
3. **Prephrase.** Test the direction of the timeline before accepting the causal claim.
4. **Why (C) is right.** (C) pinpoints reverse causation: financial contraction may cause the very decision treated as a cause of contraction.
5. **Why the others fail.**
   - **(A)** (A) imposes a universal recommendation not given.
   - **(B)** (B) identifies an asset/deposit distinction never used in the reasoning.
   - **(D)** (D) imports an ownership claim irrelevant to the causal direction.
   - **(E)** That would be too specific an account of who withdrew funds; the causal inference can be flawed even when withdrawals occurred elsewhere or through online transfers.

**Check:** Prior deposit decline → closure is consistent with subsequent loss observations.
::::
:::

:::problem[Question III.2]
A conservation group wants to reintroduce a native fish into irrigation channels to reduce mosquito larvae. Historical records indicate that the fish consumed mosquito larvae before the channels were lined with concrete. Ecologists warn that the channels now receive occasional pesticide runoff, so the fish might fail to establish populations even if they can still eat larvae. The group predicts that reintroduction will nevertheless provide lasting larval control without repeated human stocking, and it seeks evidence concerning the main uncertainty in that prediction.

Which one of the following, if true, most strengthens the group’s prediction?

- **(A)** In several matched lined channels with the same runoff pattern, introduced fish reproduced over multiple seasons and sustained lower larval densities than channels without the fish.
- **(B)** A related native fish can reproduce in concrete-lined channels where pesticide runoff has not been observed.
- **(C)** Residents would be more willing to tolerate a native fish than recurring pesticide applications in the channels.
- **(D)** The proposed fish consumes mosquito larvae efficiently in an aquarium containing low concentrations of the pesticide found in runoff.
- **(E)** The concrete lining makes water temperatures more stable than the channels’ temperatures before they were lined.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The proposed biological control can persist and reduce larvae in present conditions.
2. **Support.** Old feeding records do not settle reproduction under runoff and concrete conditions.
3. **Prephrase.** Find sustained establishment *and* reduced larval density in a comparable setting.
4. **Why (A) is right.** (A) supplies both the ecological persistence and causal comparison central to the prediction.
5. **Why the others fail.**
   - **(B)** The result is an attractive analogy but changes both species and runoff conditions, leaving the establishment question for this fish unresolved.
   - **(C)** Public acceptability might ease implementation but does not show that the species can reproduce under runoff conditions or suppress larvae.
   - **(D)** The aquarium result concerns feeding under some exposure, not whether self-sustaining populations persist across several runoff seasons; (A) directly demonstrates both.
   - **(E)** Stable temperature might help survival in some circumstances, but it does not establish reproduction under actual runoff patterns or durable larval control.

**Check:** Repeated reproduction plus matching controls directly addresses the feared failure to establish.
::::
:::

:::problem[Question III.3]
A publicly traded firm created an anonymous reporting hotline and then documented a rise in employee complaints about procurement irregularities. The audit chair says this rise shows that misconduct has become more common, and urges immediate disciplinary staffing increases. Several department managers counter that employees may simply be more willing to report existing problems now that anonymity is guaranteed. The chair replies that the raw number of complaints is the best available indicator of misconduct and sees no need to distinguish incidents newly occurring from older incidents newly being reported.

Which one of the following is an assumption required by the chair’s reasoning?

- **(A)** The number of employees assigned to procurement remained roughly similar before and after the hotline was introduced.
- **(B)** Employees had been reluctant to report procurement concerns before the anonymous hotline existed.
- **(C)** No procurement irregularities occurred before the hotline was created.
- **(D)** Every anonymous complaint can be independently proven true.
- **(E)** The increased willingness or opportunity to report misconduct does not fully account for the rise in complaints without an increase in misconduct itself.

::::solution[Solution]
**Answer:** (E)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** More complaints means more actual misconduct.
2. **Support.** Anonymity changes reporting behavior, which may inflate measured complaints even at unchanged misconduct.
3. **Prephrase.** Rule out a complete reporting-propensity explanation.
4. **Why (E) is right.** (E) is a necessary defensive assumption. If reporting changes fully explain the increase with no misconduct increase, the chair's inference from complaints to rising misconduct loses its basis.
5. **Why the others fail.**
   - **(A)** A stable denominator may aid count comparisons, but the argument still requires ruling out changing willingness to report without more misconduct.
   - **(B)** This gives a plausible competing explanation for the complaint increase, not a premise the chair needs to infer more misconduct.
   - **(C)** (C) exaggerates past conditions and is not required for a relative rise.
   - **(D)** (D) demands perfect validity of all complaints, stronger than the trend claim needs.

**Check:** Negate (E): reporting change alone accounts for the entire rise; the alleged increase is unsupported.
::::
:::

:::problem[Question III.4]
In a drug manufacturer's quality system, every batch released for sale has passed both a sterility audit and a packaging audit. A failed sterility audit automatically requires quarantine. No quarantined batch can be released until a new sterility audit has been passed. Batch K passed its packaging audit but failed its first sterility audit. It was subsequently subjected to a new sterility audit, but the record supplied here does not state the result. The factory has complied with all its release rules.

Which one of the following must be true?

- **(A)** Batch K cannot pass any later sterility audit once it has failed one.
- **(B)** If Batch K was eventually released, it must have passed the new sterility audit.
- **(C)** Batch K has been released because it passed its packaging audit.
- **(D)** Batch K is permanently disqualified from sale under the rules.
- **(E)** Batch K failed its packaging audit as well as its initial sterility audit.

::::solution[Solution]
**Answer:** (B)

**Type:** Must be true / inference (Chapter 10)

1. **Conclusion.** The task is a conditional inference; no conclusion is proposed in the stimulus.
2. **Support.** Failure → quarantine; release after quarantine → passed new audit.
3. **Prephrase.** Do not assume the unstated retest result; use a conditional.
4. **Why (B) is right.** (B) is exactly the necessary condition for subsequent release stated in the quality rules.
5. **Why the others fail.**
   - **(A)** (A) invents permanent inability to retest successfully.
   - **(C)** (C) mistakes packaging approval for joint release sufficiency.
   - **(D)** (D) infers a permanent bar where a retest pathway is supplied.
   - **(E)** (E) directly contradicts the packaging pass.

**Check:** Released after initial failure → released from quarantine → new sterility pass.
::::
:::

:::problem[Question III.5]
A clinic expanded its appointment capacity by adding evening sessions and employing two new physicians. During the following quarter, the average number of days between a patient's first request and the scheduled appointment increased. The clinic had advertised that additional capacity would shorten waits, and its existing physicians continued to see as many patients per week as before. The administrator verified that the appointment software measured requests and dates the same way in both quarters. The seemingly conflicting changes therefore call for an explanation other than a statistical redefinition.

Which one of the following, if true, most helps to resolve the apparent discrepancy?

- **(A)** Most of the new appointments were scheduled using the same software platform as before.
- **(B)** The new evening physicians have the same average length of consultation as the clinic’s original physicians.
- **(C)** The evening sessions occurred after regular business hours rather than during lunchtime.
- **(D)** Publicity surrounding the new hours brought in so many first-time requests that demand rose by more appointments per week than the increase in capacity.
- **(E)** The new evening physicians see patients in the same rooms already used for daytime appointments.

::::solution[Solution]
**Answer:** (D)

**Type:** Paradox / resolve–explain (Chapter 13)

1. **Conclusion.** More appointment slots accompanied a longer wait.
2. **Support.** The paradox disappears if appointment requests grew faster than capacity.
3. **Prephrase.** Compare demand growth with supply growth rather than hours alone.
4. **Why (D) is right.** (D) provides exactly the demand surge required for a longer queue despite more service slots.
5. **Why the others fail.**
   - **(A)** (A) repeats measurement continuity that the question already stipulates.
   - **(B)** Similar appointment lengths help verify nominal capacity, but they do not explain longer waits once capacity increased; the unexpected rise in requests does.
   - **(C)** (C) describes scheduling location in the day without the necessary demand/supply quantity.
   - **(E)** Shared examination rooms are not a demonstrated constraint on additional sessions at different hours; this provides no increase in the waiting queue.

**Check:** Waiting can rise when arrival rate increases by more than service rate.
::::
:::

:::problem[Question III.6]
An endowment officer wants to increase the university's allocation to private-equity funds. She notes that over the last decade private-equity investments included in the endowment's annual reports earned higher average reported returns than its publicly traded stock holdings. Although valuations of private holdings are supplied periodically rather than quoted daily, she argues that this difference proves the private allocation is the better way to meet next year's cash obligations. The university must pay scholarships on fixed dates and may need to sell investments quickly during a market downturn.

Which one of the following, if true, most weakens the officer’s argument?

- **(A)** The private-equity contracts sharply restrict withdrawals for years, and selling the holdings early in stressed markets would require discounts large enough to outweigh their reported return advantage.
- **(B)** Publicly traded stocks are quoted at different prices during a trading day.
- **(C)** The private-equity funds require investors to commit more money to future projects on schedules determined by fund managers.
- **(D)** The endowment’s private-equity holdings appreciated on paper during a period when several publicly traded stock indices declined.
- **(E)** The price of the endowment’s publicly traded stocks has fluctuated more frequently than its periodically valued private holdings.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Superior reported historical returns show private assets best meet imminent liquidity needs.
2. **Support.** Annual valuation figures do not establish reliable cash availability when obligations come due.
3. **Prephrase.** Attack the liquidity bridge from reported returns to funds available next year.
4. **Why (A) is right.** (A) directly exposes the mismatch: lockups and forced-sale discounts may make the asset unsuitable despite accounting returns.
5. **Why the others fail.**
   - **(B)** (B) describes liquid-market pricing without undermining ability to sell.
   - **(C)** Potential future capital calls are relevant to liquidity but do not directly establish that the reported higher-return holdings cannot fund scholarships as readily as the lockup-and-discount evidence in (A).
   - **(D)** Appreciation bolsters the return narrative rather than undermining it, and is not a direct answer to the near-term cash availability concern.
   - **(E)** Frequently observed price changes are not evidence that private holdings are more liquid or that their stated return can be realized when scholarship bills arrive.

**Check:** A high mark-to-model return is not spendable cash on scholarship dates.
::::
:::

:::problem[Question III.7]
A hospital administrator observes that disposable masks kept in opened cartons can absorb moisture in poorly ventilated storerooms. Not every damp mask fails quality checks, but the hospital has recently recorded more failures in supplies stored on lower shelves. Laboratory staff found no manufacturing differences between the lower- and upper-shelf cartons. Since humidity is highest near the storeroom floor, it would be prudent to move opened cartons onto raised racks and monitor moisture there before purchasing an entirely new mask brand. Replacing suppliers might still be necessary, but the storage arrangement should be tested first.

Which one of the following most accurately states the administrator’s main conclusion?

- **(A)** All damp masks fail quality checks.
- **(B)** The hospital should first test raised, monitored storage for opened mask cartons before deciding to change suppliers.
- **(C)** The hospital should discard all lower-shelf cartons immediately, without first monitoring the effect of elevated storage.
- **(D)** Humidity is always the only reason masks fail checks.
- **(E)** The hospital must stop purchasing disposable masks entirely.

::::solution[Solution]
**Answer:** (B)

**Type:** Main conclusion (Chapter 4)

1. **Conclusion.** The policy recommendation is to alter and monitor storage before changing brands.
2. **Support.** Shelf distribution of failures and a humidity gradient motivate the proposal; it is explicitly tentative.
3. **Prephrase.** Select the action advocated, not an observed difference or an absolute causal claim.
4. **Why (B) is right.** (B) captures the order and tentative strength of the recommendation.
5. **Why the others fail.**
   - **(A)** (A) contradicts the express statement that not all damp masks fail.
   - **(C)** Immediate disposal is a plausible precaution but not the recommended sequence; the author urges a measured storage test before supplier decisions.
   - **(D)** (D) exaggerates a potential contributing cause into an exclusive universal one.
   - **(E)** (E) recommends total abandonment rather than a storage trial.

**Check:** The 'it would be prudent' sentence is the author's operative conclusion.
::::
:::

:::problem[Question III.8]
A project developer claims that a coastal forest will permanently compensate for carbon released by a new factory. Its field measurements show substantial carbon uptake by the trees over the last four years. Because the forest grew during every monitored year, the developer projects that the same annual uptake will continue for the entire century. The report acknowledges that the forest's growth slows as trees mature and that storm damage could release stored carbon, but it neither models mature growth nor adjusts for severe storm risk in the long-term projection.

The argument is most vulnerable to criticism because it

- **(A)** compares the forest to an unnamed alternative carbon project.
- **(B)** assumes that carbon uptake must have been uniform across all months of the monitoring period.
- **(C)** extrapolates a short-run rate into the distant future despite acknowledged conditions that could alter growth and storage.
- **(D)** assumes that the factory will never reduce its emissions through other means.
- **(E)** fails to report precisely when each tree was planted.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The forest will permanently offset the factory's emissions.
2. **Support.** Short-run uptake does not settle century-scale sequestration when aging and loss risks exist.
3. **Prephrase.** Name the temporal extrapolation rather than disputing the measured past uptake.
4. **Why (C) is right.** (C) describes the precise weakness of assuming an observed rate remains stable under materially changing conditions.
5. **Why the others fail.**
   - **(A)** (A) demands a benchmark never needed for the claimed absolute offset.
   - **(B)** The developer projects a constant annual rate into the future, not equal monthly uptake during the four observed years; the flaw is extrapolation under changing future conditions.
   - **(D)** (D) introduces factory mitigation unrelated to the forest's projected permanence.
   - **(E)** (E) seeks a detail that would not itself fix the model's time horizon.

**Check:** Four years of uptake ≠ century of permanent net storage without modeling maturity and release.
::::
:::

:::problem[Question III.9]
A logistics attorney reasons as follows: Whenever a shipping contract qualifies for priority unloading, the contract includes a certified arrival window. Every contract with a certified arrival window is exempt from delay penalties unless the shipper misses the window. The Meridian shipment qualifies for priority unloading and did not miss its window. It follows that Meridian is exempt from delay penalties. The attorney's reasoning relies on both the general window rule and the specified exception, not on any assumption about the shipment's profitability.

Which one of the following exhibits a reasoning pattern most similar to the attorney’s?

- **(A)** Some projects with safety reviews gain funding. The Rowan project had a review, so it is funded.
- **(B)** All certified laboratory results have two signatures. Any result with two signatures is published unless a reviewer flags it. The result is certified and no reviewer flagged it; therefore it is published.
- **(C)** All valid parking permits have serial numbers. This permit has a serial number; hence it is valid.
- **(D)** No discounted ticket can be refunded without managerial approval. A refund was approved, so the ticket was discounted.
- **(E)** Every written complaint is reviewed. The complaint was reviewed, so it must have been written.

::::solution[Solution]
**Answer:** (B)

**Type:** Parallel reasoning (Chapter 12)

1. **Conclusion.** Meridian is penalty-exempt under a valid two-stage rule with an exception absent.
2. **Support.** Priority → certified window; certified window and not missed → exemption.
3. **Prephrase.** Match chained entailment and the removal of a disqualifying exception.
4. **Why (B) is right.** (B) has certified → two signatures; two signatures and not flagged → published. The logical structure is identical.
5. **Why the others fail.**
   - **(A)** (A) turns a 'some' statement into a guarantee.
   - **(C)** (C) affirms the consequent of permit → serial.
   - **(D)** (D) reverses a necessary approval condition and invents discounted status.
   - **(E)** (E) affirms the consequent of written → reviewed.

**Check:** Feed the first condition into the second and rule out the specified exception.
::::
:::

:::problem[Question III.10]
A manufacturer states its recall principle: when credible evidence indicates that a product defect can cause severe injury during ordinary use, the manufacturer must suspend sales while testing proceeds, even if the defect's frequency is unknown. But a mere uncorroborated allegation is insufficient; and defects affecting only cosmetic appearance do not meet the severe-injury condition. The principle gives precautionary priority to credible severity, not to the expected number of disappointed customers or the public-relations cost of suspension.

Which one of the following actions conforms most closely to this principle?

- **(A)** Recall all products with minor discoloration even though tests exclude physical danger.
- **(B)** Suspend sales solely because one anonymous online post claims a defect, without any corroboration.
- **(C)** Continue sales because a recall would reduce the firm's quarterly earnings.
- **(D)** Suspend sales of an appliance after independent tests credibly show a wiring fault capable of causing serious burns in ordinary use, while engineers measure its frequency.
- **(E)** Continue sales despite verified reports that the product can overheat dangerously, because the measured failure rate is still unknown.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Credible severe-injury risk triggers immediate suspension pending testing.
2. **Support.** Frequency uncertainty is expressly not an excuse; unsupported rumor and cosmetic defects are excluded.
3. **Prephrase.** Check credibility, severity, ordinary use, and precautionary timing.
4. **Why (D) is right.** (D) satisfies every element and does not demand proof of frequent injury.
5. **Why the others fail.**
   - **(A)** (A) responds to cosmetic-only harm outside the triggering condition.
   - **(B)** (B) eliminates the credibility gate by relying on an unverified claim.
   - **(C)** (C) replaces safety criteria with earnings considerations.
   - **(E)** (E) invokes the precise uncertainty the rule says cannot delay suspension.

**Check:** Credible risk of serious burns in ordinary use → suspend now while frequency remains studied.
::::
:::

:::problem[Question III.11]
A credit analyst advises against downgrading a city's bonds solely because the city posted a deficit last year. The city paid for a one-time flood-control repair from its operating budget, and its recurring revenue still exceeds recurring operating expenses. Some analysts say the deficit shows persistent financial weakness. The credit analyst concedes that the repair has reduced reserves, which makes the city less resilient to future shocks. Nevertheless, the unusual expense does not by itself establish an ongoing structural imbalance, and a downgrade premised on such an imbalance would therefore be premature.

In the analyst’s reasoning, the statement that reserves have been reduced serves primarily to

- **(A)** establish that recurring expenses have exceeded recurring revenue for years.
- **(B)** acknowledge a genuine concern supporting the opposing position while distinguishing it from evidence of a persistent budget imbalance.
- **(C)** state the final conclusion that the city should be downgraded immediately.
- **(D)** establish that the flood-control expense, rather than some recurring commitment, accounted for last year’s deficit.
- **(E)** prove that reduced reserves can never affect a bond's creditworthiness.

::::solution[Solution]
**Answer:** (B)

**Type:** Role of a statement (Chapter 11)

1. **Conclusion.** The analyst rejects a structural-deficit downgrade based on one abnormal expense.
2. **Support.** The reserve reduction is an admitted adverse fact, but a different issue from recurring expenses exceeding revenues.
3. **Prephrase.** Recognize a concession the argument limits, not its central support.
4. **Why (B) is right.** (B) states the role exactly: grant liquidity vulnerability without granting that a structural mismatch exists.
5. **Why the others fail.**
   - **(A)** (A) invents the recurring deficit the analyst says is unproven.
   - **(C)** (C) reverses the conclusion by recommending immediate downgrade.
   - **(D)** The one-time nature of the repair is part of the analyst’s supporting evidence, but the specified statement about *reserves* functions as a concession about diminished shock tolerance.
   - **(E)** (E) overstates the concession into immunity from credit risk.

**Check:** Concession about reserves is followed by 'nevertheless' and the main argument's narrower claim.
::::
:::

:::problem[Question III.12]
A seed company argues that coating drought-sensitive seeds with a particular biodegradable film will improve establishment in dry regions. A greenhouse study found that coated seeds germinated more frequently under brief simulated dry periods. Researchers caution that a field environment differs: soil microbes may degrade the film quickly, and the film might prevent water penetration during an unexpectedly heavy rain. The company maintains that its coating will increase the fraction of planted seeds that become mature plants under the region's typical weather patterns.

Which one of the following, if true, most strengthens the company’s claim?

- **(A)** Across multiple dry-region field seasons, coated seeds produced a higher proportion of mature plants than matched uncoated seeds in the same soil and weather conditions.
- **(B)** Growers in the region generally favor biodegradable materials over conventional plastics.
- **(C)** Uncoated seeds tend to be cheaper to transport than coated seeds.
- **(D)** Laboratory tests found that the coating remained intact through several simulated dry periods of different lengths.
- **(E)** The same film improved the germination rate of a different seed species in a laboratory using dry soil.

::::solution[Solution]
**Answer:** (A)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** The coating improves mature plant establishment under actual regional conditions.
2. **Support.** Lab germination is an intermediate outcome and may not survive field complications.
3. **Prephrase.** Seek matched field evidence of final establishment across relevant seasons.
4. **Why (A) is right.** (A) directly measures the correct outcome with a control exposed to the same conditions, addressing both microbial decay and rain concerns.
5. **Why the others fail.**
   - **(B)** (B) is consumer preference, not biological effectiveness.
   - **(C)** (C) concerns transport cost, not successful establishment.
   - **(D)** Additional greenhouse durability evidence does not address field microbes, unexpected rain, or mature-plant establishment as the multiseason matched trial does.
   - **(E)** An analogous laboratory result is a weak generalization across species and still does not address mature-plant survival in field conditions.

**Check:** Mature plants per seeds planted is the outcome the claim predicts.
::::
:::

:::problem[Question III.13]
An independent auditor reviewed only purchase orders above $50,000 and found no unauthorized purchases among those examined. A charity's treasurer uses this audit to reassure donors that the charity has no unauthorized purchasing whatsoever. The treasurer acknowledges that smaller purchase orders were not individually tested, but argues that large transactions represent most of the charity's annual procurement spending. Donors concerned about internal controls ask whether the monetary share covered by the audit warrants the claim about the existence of any unauthorized purchases.

Which one of the following is an assumption on which the treasurer’s argument depends?

- **(A)** There are no unauthorized purchases among the smaller orders that were not examined by the audit.
- **(B)** The charity has more purchase orders above $50,000 than below it.
- **(C)** The total monetary value of smaller purchases is zero.
- **(D)** The auditor selected the $50,000 cutoff because those orders accounted for most of the charity’s total procurement dollars.
- **(E)** Every purchase order above $50,000 was approved by at least three employees.

::::solution[Solution]
**Answer:** (A)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The charity has *no* unauthorized purchases of any size.
2. **Support.** The audit gives evidence only about large orders, while the conclusion covers all orders.
3. **Prephrase.** The unaudited lower-value set must also be clean.
4. **Why (A) is right.** (A) is logically necessary: if even one unaudited small order was unauthorized, the universal conclusion would be false despite the clean large-order audit.
5. **Why the others fail.**
   - **(B)** (B) compares counts, whereas even a single small error defeats the conclusion.
   - **(C)** (C) overstates the necessary condition: authorized smaller purchases can have positive value.
   - **(D)** This restates a monetary-coverage rationale but cannot rule out unauthorized small orders; the treasurer concludes none exists anywhere.
   - **(E)** (E) imposes a specific approval mechanism not needed for authorization.

**Check:** Negate (A) to 'at least one unauthorized small order'; the treasurer's 'none anywhere' conclusion collapses.
::::
:::

:::problem[Question III.14]
School-board member Chen: Monitoring classroom carbon dioxide can reveal when ventilation is inadequate. If a room repeatedly exceeds the advisory level, the school should temporarily reduce occupancy, even before it can upgrade its air system; instruction can be redistributed across rooms. Member Mora: Such readings can reveal inadequate ventilation, and long-term upgrades are desirable. But the advisory level is not a legal safety limit. We should not displace students on that measurement alone, without evidence of a specific health hazard in the room.

The two members disagree about whether

- **(A)** improvements to school ventilation can be desirable.
- **(B)** readings should be suppressed from parents to avoid concern.
- **(C)** repeated readings above an advisory level are sufficient to justify temporary reductions in classroom occupancy without separate evidence of a specific health hazard.
- **(D)** every school can buy an upgraded ventilation system this year.
- **(E)** carbon dioxide readings can give information about ventilation adequacy.

::::solution[Solution]
**Answer:** (C)

**Type:** Point at issue (Chapter 11)

1. **Conclusion.** Chen says repeated exceedance alone can justify temporary action; Mora says it cannot.
2. **Support.** They agree about the indicator's relevance and desirability of system upgrades.
3. **Prephrase.** Find the precise decision rule on which they take opposed positions.
4. **Why (C) is right.** (C) expresses the conflicting threshold for occupancy reduction, with both speakers' positions explicit.
5. **Why the others fail.**
   - **(A)** (A) is also common ground, not conflict.
   - **(B)** (B) is an information-withholding issue absent from both positions.
   - **(D)** (D) is an unsupported universal feasibility claim neither makes.
   - **(E)** (E) is a stated agreement.

**Check:** Chen: repeated exceedance → temporary reduction. Mora: not without additional hazard evidence.
::::
:::

:::problem[Question III.15]
A trade association surveyed firms attending a conference for high-efficiency building-panel producers. Among respondents, a large majority expected strong demand for insulated panels next year. The association then announced that most construction firms nationwide would invest in such panels. Attendance at the conference required a membership fee and was promoted primarily to companies already selling insulated products. Firms specializing in conventional materials were scarcely represented, and the survey did not ask companies whether they would actually invest rather than merely anticipate demand.

The argument is most vulnerable to criticism because it

- **(A)** mistakes an increase in the number of conference attendees for an increase in sales.
- **(B)** generalizes from a self-selected and unrepresentative population of specialized sellers to nationwide investment decisions by all construction firms.
- **(C)** assumes there are no restrictions on interstate trade in construction supplies.
- **(D)** concludes that respondents dislike insulated panels despite their stated optimism.
- **(E)** fails to demonstrate that energy-efficient panels can be produced in every climate.

::::solution[Solution]
**Answer:** (B)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** Most nationwide construction firms will invest in insulated panels.
2. **Support.** The survey sampled interested sellers and measured expectations, not all firms' buying plans.
3. **Prephrase.** Watch for both selection bias and a shift in what the survey actually measured.
4. **Why (B) is right.** (B) identifies both flaws in their proper direction; the advertised population and outcome exceed the evidence.
5. **Why the others fail.**
   - **(A)** (A) describes attendee-count confusion the argument does not make.
   - **(C)** (C) invents a legal prerequisite nowhere invoked.
   - **(D)** (D) reverses respondents' optimism rather than questioning its generalizability.
   - **(E)** (E) concerns universal product feasibility, not the sampled population or investment prediction.

**Check:** Confidence among specialized conference attendees ≠ investment by most firms nationally.
::::
:::

:::problem[Question III.16]
A consumer advocate argues that Delta Electronics must give purchasers a written notice about a recurring battery fault. A state rule requires written notice to buyers whenever a seller knows that a defect is likely to emerge during ordinary use and materially affect safety. Delta knows of the battery fault, and some internal reports describe overheating, but those facts alone do not establish both the likelihood and safety significance specified by the rule. The advocate's conclusion would be logically justified if an additional premise connected the known fault to the notice requirement.

Which one of the following, if assumed, allows the advocate’s conclusion to be properly drawn?

- **(A)** Any company that issues a battery notice has previously sold a device with a defect.
- **(B)** Every battery fault is visible to a purchaser before use.
- **(C)** Some other electronics companies have voluntarily issued battery warnings.
- **(D)** A court previously upheld a written battery-fault warning issued by a different electronics seller under the same state rule.
- **(E)** Delta knows that this battery fault is likely to emerge during ordinary use and materially affect safety.

::::solution[Solution]
**Answer:** (E)

**Type:** Sufficient assumption (Chapter 7)

1. **Conclusion.** Delta has a mandatory written-notice duty under the rule.
2. **Support.** The existing conditional is knowledge of a likely, materially unsafe ordinary-use defect → notice.
3. **Prephrase.** Supply exactly the antecedent of the statutory requirement.
4. **Why (E) is right.** (E) provides the missing conjunction. Together with the rule, it deductively entails Delta's duty.
5. **Why the others fail.**
   - **(A)** (A) is a converse observation about firms that already issue notices; it cannot trigger Delta's duty.
   - **(B)** (B) does not establish safety risk and might undercut surprise, without satisfying the rule.
   - **(C)** (C) invokes other firms' voluntary behavior rather than a binding condition on Delta.
   - **(D)** An unrelated application of the rule does not establish that Delta knows both triggering facts concerning *this* battery fault, which is required to make the conclusion deductive.

**Check:** Known likely ordinary-use emergence + known material safety effect → required notice.
::::
:::

:::problem[Question III.17]
At a furniture factory, investigators mapped reported respiratory symptoms against workstations. Reports were concentrated among workers at the finishing line, where solvent-based coatings were applied. The finishing workers, however, also tended to work longer shifts. A later survey controlling for shift length found that finishing workers still reported symptoms more often than comparable assemblers. Investigators had not yet measured individual solvent doses, and no study established that the symptoms were caused by the coatings rather than by some other feature of finishing work.

Which one of the following is most strongly supported?

- **(A)** No employee outside the finishing line was ever exposed to solvent.
- **(B)** Solvent coatings were the sole cause of all respiratory symptoms in the factory.
- **(C)** The later survey proved that individual chemical doses were identical in both groups.
- **(D)** Every worker on the finishing line had more symptoms than every assembler.
- **(E)** Differences in shift length do not by themselves fully explain the observed association between finishing-line assignment and reported symptoms in the later survey.

::::solution[Solution]
**Answer:** (E)

**Type:** Most strongly supported (Chapter 10)

1. **Conclusion.** The reported association persists even after a specific confounder is controlled.
2. **Support.** Longer shifts were a plausible shared factor, but the later survey matched shift length and still found a difference.
3. **Prephrase.** Infer only the inadequacy of shift-length differences as a complete explanation.
4. **Why (E) is right.** (E) states that narrow result and avoids asserting a unique cause.
5. **Why the others fail.**
   - **(A)** (A) asserts zero exposure outside finishing, which was never measured.
   - **(B)** (B) turns an association into exclusive causation without dose evidence.
   - **(C)** (C) invents equal chemical doses despite the stated lack of measurements.
   - **(D)** (D) shifts from group rates to universal individual rankings.

**Check:** After matching shift length, the association remains; therefore that variable alone cannot eliminate it.
::::
:::

:::problem[Question III.18]
A city's finance director predicts that doubling the hourly parking-meter fee will almost double annual meter revenue. During the past year, drivers paid for roughly the same number of parking hours each month, despite minor weather changes, so she treats demand as stable. But she has no evidence about how drivers respond to changes in price, and some adjacent neighborhoods have unmetered spaces. The budget committee must decide whether the projected revenue is sufficiently secure to finance a long-term maintenance obligation.

Which one of the following, if true, most weakens the director’s projection?

- **(A)** A comparable nearby district that doubled its meter fee saw paid parking hours fall by more than half because drivers shifted to unmetered streets.
- **(B)** The meter system maintained about the same paid parking hours after the last increase of five cents per hour.
- **(C)** The proposed fee increase would be announced two months before taking effect.
- **(D)** Some drivers prefer parking closer to stores when fees are unchanged.
- **(E)** The city devotes a substantial part of the existing meter revenue to enforcing its parking regulations.

::::solution[Solution]
**Answer:** (A)

**Type:** Weaken (Chapter 8)

1. **Conclusion.** Doubling unit price will nearly double total revenue.
2. **Support.** Stable hours at nearly constant prices do not imply inelastic demand after a major price change.
3. **Prephrase.** Find elastic demand, especially substitution into unmetered spaces.
4. **Why (A) is right.** (A) shows that quantity can fall so sharply that revenue would not nearly double and might fall. A close comparator directly challenges the hidden constant-demand premise.
5. **Why the others fail.**
   - **(B)** Demand stability after a very small price change does not weaken the projection for a much larger increase; it may modestly favor inelasticity instead.
   - **(C)** (C) affects notice timing without showing a significant behavioral reaction.
   - **(D)** (D) holds fees unchanged and gives no elasticity estimate.
   - **(E)** Enforcement spending affects net proceeds or the budget but cannot by itself refute a claim about the gross meter receipts after a price increase.

**Check:** Revenue = price × hours; if price doubles and hours fall below half, revenue falls.
::::
:::

:::problem[Question III.19]
A quality inspector argues: Every component that has passed the factory's thermal endurance test receives a green barcode. The valve on my desk has a green barcode. Therefore, the valve has passed the thermal endurance test. The inspector has no information about whether barcodes are also issued after other tests or for components awaiting final verification. The inspector has not examined the valve’s test record, but claims that checking it would be redundant. A colleague suspects that green barcodes may also be issued for reasons unrelated to endurance testing and looks for an argument using the same mistaken inference.

Which one of the following arguments most closely parallels the inspector’s flawed reasoning?

- **(A)** No certified laboratory may issue reports without supervision. This laboratory is certified and has issued reports, so it used supervision.
- **(B)** Every bicycle that lacks functioning brakes fails inspection. This bicycle lacks functioning brakes, so it fails inspection.
- **(C)** All licensed importers maintain a customs bond. This merchant maintains a customs bond, so it must be a licensed importer.
- **(D)** All stores that open before sunrise employ a morning manager. This store opens before sunrise, so it employs a morning manager.
- **(E)** Every payment made after the deadline incurs a penalty. This payment was not late, so it incurred no penalty.

::::solution[Solution]
**Answer:** (C)

**Type:** Parallel flaw (Chapter 12)

1. **Conclusion.** The inspector concludes test passed from barcode issued.
2. **Support.** Form passed → green barcode; green barcode → passed, an affirming-the-consequent error.
3. **Prephrase.** Match the converse error, not the inverse or a valid application.
4. **Why (C) is right.** (C) has licensed → bond; bond → licensed. The very same unlicensed reversal drives the argument.
5. **Why the others fail.**
   - **(A)** (A) validly applies the supervision requirement to a certified lab that actually issued reports.
   - **(B)** (B) validly applies a stated sufficient condition.
   - **(D)** (D) validly applies opens early → manager.
   - **(E)** (E) denies the antecedent, a different invalid form.

**Check:** P → Q, Q, therefore P is invalid unless Q → P is separately established.
::::
:::

:::problem[Question III.20]
A policy researcher disputes the assertion that subsidies for industrial recycling necessarily decrease the amount of raw material extracted. She does not challenge the finding that subsidized plants processed more recycled feedstock. Instead, she notes that cheaper recycled input may lower manufacturers' total production costs, permitting them to expand output enough that they purchase more virgin material in absolute terms even while using a smaller virgin share per product. The researcher urges measuring total extraction rather than only recycled material's proportion of manufacturing input.

The researcher’s method is primarily to

- **(A)** argue that an economic effect must be impossible because it has not yet been measured.
- **(B)** assert that every change in production cost produces exactly the same output response.
- **(C)** infer that lower-cost recycled inputs have no value to firms unless the inputs completely eliminate virgin-material purchases.
- **(D)** question whether the plants receiving recycling subsidies represent all manufacturers in the economy.
- **(E)** challenge an asserted consequence by identifying an indirect response through which the measured intermediate effect could coexist with its opposite at the aggregate level.

::::solution[Solution]
**Answer:** (E)

**Type:** Method of reasoning (Chapter 11)

1. **Conclusion.** More recycling as a share need not mean lower total raw-material extraction.
2. **Support.** Lower input cost can boost overall output, offsetting reduced virgin content per product.
3. **Prephrase.** Track the rebound mechanism and different denominators.
4. **Why (E) is right.** (E) captures the method: grant the narrow measured fact and show an indirect volume effect can defeat the broad aggregate conclusion.
5. **Why the others fail.**
   - **(A)** (A) turns a possibility-based objection into a claim of impossibility.
   - **(B)** (B) overstates a possible output response into a universal deterministic rule.
   - **(C)** The researcher argues about total output and material proportions; she does not set a value threshold requiring the elimination of virgin inputs.
   - **(D)** The researcher does not attack the sample as unrepresentative; she concedes its measured recycling effect and challenges the move from share to aggregate quantity.

**Check:** Total virgin demand = units produced × virgin material per unit; opposite movements can offset.
::::
:::

:::problem[Question III.21]
An employer offered a voluntary transit-pass subsidy and found that employees who enrolled were absent less often than employees who declined. A human-resources officer concludes that the subsidy itself improves attendance and proposes making it compulsory. The officer did not examine whether employees with reliable commute schedules were more likely to join, nor whether the enrollee group differed in work location or shift predictability. In fact, the program was advertised most aggressively at the central office, whose staff already had the company's lowest absence rate.

The officer’s argument is most vulnerable to criticism because it

- **(A)** presumes that central-office employees had the same work schedules as employees at the company’s other locations.
- **(B)** infers that employee attendance rose after the program without comparing participants and nonparticipants.
- **(C)** fails to rule out preexisting differences between self-selected participants and nonparticipants that could account for the attendance gap.
- **(D)** claims that the transit subsidy has no financial cost to the employer.
- **(E)** concludes that all employees travel by public transit.

::::solution[Solution]
**Answer:** (C)

**Type:** Flaw (Chapter 9)

1. **Conclusion.** The subsidy caused the attendance advantage and should be mandatory.
2. **Support.** Enrollment is voluntary and concentrated in a lower-absence office, so the comparison is confounded.
3. **Prephrase.** Look for selection bias and alternative causes rather than assuming the observed gap is an effect.
4. **Why (C) is right.** (C) exactly captures the methodological defect: self-selection and office differences can explain absence without any causal subsidy impact.
5. **Why the others fail.**
   - **(A)** The office may differ in schedule predictability, but the officer does not expressly assert schedule equality. The flaw is the failure to rule out selection and location confounds.
   - **(B)** (B) misdescribes the evidence, which does compare enrollees with nonenrollees but not their prior baselines.
   - **(D)** (D) addresses costs absent from the inference.
   - **(E)** (E) invents a universal commute claim.

**Check:** An association between joining and attendance can be present even if the subsidy changes nobody's attendance.
::::
:::

:::problem[Question III.22]
A packaging company asserts that replacing conventional wrapping with a plant-based film will reduce its environmental impact. The new film degrades quickly in a commercial composting facility, and laboratory tests show that it can be produced with fewer petroleum inputs per kilogram than the old film. The firm's distribution network, however, sells to communities with very different collection and waste-processing systems. Managers also know that the plant-based film is thicker, so each packaged item may require more material than before.

Which one of the following would be most useful to determine in evaluating the company’s argument?

- **(A)** Whether the plant-based film meets a widely recognized standard for industrial compostability.
- **(B)** Whether the plant-based film comes from agricultural feedstock transported a longer distance than the petroleum feedstock for current wrapping.
- **(C)** Whether the new film can run on existing packaging machines without more electricity per wrapped item.
- **(D)** Whether the plant-based film contains a slightly larger percentage of renewable carbon than comparable new films sold by competitors.
- **(E)** Whether the total production and disposal impacts per wrapped item, given actual collection systems and material quantities, are lower for the proposed film than for the current wrapping.

::::solution[Solution]
**Answer:** (E)

**Type:** Evaluate the argument (Chapter 8)

1. **Conclusion.** The proposed replacement yields a net environmental improvement.
2. **Support.** Per-kilogram feedstock and industrial-compost performance may not describe per-item material or real disposal conditions.
3. **Prephrase.** Ask for whole-life-cycle impacts at the functional unit actually sold.
4. **Why (E) is right.** (E) directly tests whether the measured favorable properties outweigh thicker use and noncompost disposal routes. Its yes/no outcomes bear strongly on the conclusion.
5. **Why the others fail.**
   - **(A)** Certification may validate the lab degradation claim but does not establish that customers actually have matching processing access or that thicker wrapping yields lower impacts.
   - **(B)** Supply-chain distance is only one lifecycle input; without quantities or disposal outcomes it cannot evaluate the total change as decisively as (E).
   - **(C)** Electricity demand is one partial factor, but it does not resolve end-of-life treatment or material-use changes; the question asks about the net environmental claim.
   - **(D)** The competitor comparison may be interesting for marketing, but the claim compares the proposed film with this company’s *current wrapping*, not other new alternatives.

**Check:** If per-item real-world impacts are higher, the claim weakens; if lower, it strengthens.
::::
:::

:::problem[Question III.23]
A regulator proposes a mandatory central netting service for a set of derivative contracts. Under bilateral settlement, some banks owe others at the same time that they are owed comparable amounts, and gross payments can become delayed when one institution lacks cash. The regulator argues that netting will necessarily reduce the cash required for settlement throughout the network, because many offsetting obligations can be combined into smaller net transfers. But the proposal would impose collateral requirements at the central service, and the regulator has not estimated how much cash those requirements would tie up.

Which one of the following is an assumption on which the regulator’s prediction depends?

- **(A)** All derivative contracts in the entire economy will be settled through the service.
- **(B)** No participating bank will ever face losses on any contract.
- **(C)** Bilateral payments are always late even when banks have ample cash.
- **(D)** Collateral and other cash requirements created by the service will not fully offset or exceed the settlement-cash savings from netting.
- **(E)** Every bank will have precisely the same net liability after clearing.

::::solution[Solution]
**Answer:** (D)

**Type:** Necessary assumption (Chapter 7)

1. **Conclusion.** The service necessarily reduces total cash required throughout the system.
2. **Support.** Smaller net transfers may be counterbalanced by new collateral cash demands.
3. **Prephrase.** Exclude a complete offset by collateral.
4. **Why (D) is right.** (D) is a required bridge. Negate it: the additional requirements fully offset or exceed transfer savings, so total required cash cannot fall as predicted.
5. **Why the others fail.**
   - **(A)** (A) extends the proposal to unrelated contracts unnecessarily.
   - **(B)** (B) invents universal avoidance of losses, irrelevant to settlement cash.
   - **(C)** (C) overstates the fact that gross payments *can* be delayed into permanent lateness.
   - **(E)** (E) makes equal bank-level liabilities a condition not required for aggregate savings.

**Check:** Net saving = gross-transfer reduction − added cash requirements; it must be positive for the conclusion.
::::
:::

:::problem[Question III.24]
A firm claims that shorter, distributed training sessions improve technicians' retention of safety procedures compared with a single intensive workshop. Its initial internal assessment found higher quiz scores among volunteers who chose the distributed sessions, but supervisors note that enthusiastic trainees may have self-selected into that format. The firm now wants to demonstrate that the schedule itself, rather than prior motivation, accounts for better retention after several weeks, when technicians must apply the procedures without prompts.

Which one of the following, if true, most strengthens the firm’s claim?

- **(A)** The technicians who volunteered for the distributed program worked lighter shifts during training than volunteers in the intensive workshop.
- **(B)** The trainees who volunteered for distributed sessions described the classes as more enjoyable.
- **(C)** The intensive workshop included slightly more total instruction time than the distributed program, although both taught the same procedures.
- **(D)** Technicians randomly assigned to the distributed schedule performed better on an unannounced procedure test six weeks later than randomly assigned technicians taught the same content in one workshop.
- **(E)** More technicians signed up for the distributed schedule than for the intensive workshop.

::::solution[Solution]
**Answer:** (D)

**Type:** Strengthen (Chapter 8)

1. **Conclusion.** Distributed schedule itself yields better retained safety knowledge.
2. **Support.** Volunteer quiz scores confound motivation with training format.
3. **Prephrase.** Control self-selection while comparing delayed performance on equivalent content.
4. **Why (D) is right.** (D) directly supplies random assignment and an objective delayed outcome, addressing both the cause and the claimed retention endpoint.
5. **Why the others fail.**
   - **(A)** Workload differences offer another selection or exposure explanation of the original quiz gap, not support that session distribution caused superior delayed retention.
   - **(B)** (B) shows preference, not durable learning.
   - **(C)** An unequal dosage of instruction is a possible confounder, not positive evidence that distributing sessions independently improves delayed retention. Random assignment and later testing in (D) remain more decisive.
   - **(E)** (E) indicates popularity, which worsens selection concerns rather than proving effectiveness.

**Check:** Randomization weakens the prior-motivation explanation; the six-week test targets retention rather than immediate satisfaction.
::::
:::

:::problem[Question III.25]
A research ethics board adopts a compensation rule for studies involving volunteers. Payment should reimburse reasonable time and travel burdens, and may include modest inconvenience compensation, but should not be made contingent on a participant suppressing symptoms or remaining in a study despite a reasonable desire to withdraw. The board adds that volunteers may withdraw without forfeiting reimbursement already earned. Investigators propose several payment schedules, claiming that each will improve recruitment and data completeness.

Which one of the following payment arrangements most closely conforms to the board’s rule?

- **(A)** Offer a large bonus conditioned on participants reporting no adverse effects during a trial.
- **(B)** Require a participant to repay earlier reimbursement whenever the participant declines another dose.
- **(C)** Pay nothing to participants who withdraw, even for travel costs already incurred.
- **(D)** Reimburse travel and completed-visit time as incurred, with modest inconvenience compensation, regardless of whether volunteers later withdraw or report symptoms.
- **(E)** Pay the full transportation reimbursement only to volunteers who complete every visit without reporting symptoms.

::::solution[Solution]
**Answer:** (D)

**Type:** Principle (Chapter 13)

1. **Conclusion.** Compensation must not coerce silence or continued participation; earned reimbursement is retained.
2. **Support.** The rule permits reasonable burden compensation without completion or symptom-based conditions.
3. **Prephrase.** Choose earned, noncontingent reimbursement and a free right of withdrawal.
4. **Why (D) is right.** (D) satisfies each condition and avoids making payment depend on study completion or favorable reporting.
5. **Why the others fail.**
   - **(A)** (A) offers a powerful inducement to conceal adverse symptoms.
   - **(B)** (B) uses repayment pressure to discourage withdrawal.
   - **(C)** (C) violates retention of earned reimbursement upon withdrawal.
   - **(E)** (E) penalizes symptom disclosure and noncompletion.

**Check:** Earned time/travel reimbursement + free symptom reporting and withdrawal fits the ethical rule.
::::
:::

## 32.4 Scoring and review

Count one point for each correct answer. Your **raw score is out of 77**. Because this original test has not been statistically equated by LSAC, **do not convert it into a purported official 120–180 scaled score**. Use your section breakdown, flagged guesses, and error log to measure progress.

:::answer[Answer]

**Section I**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| I.1 | B | Flaw | 9 |
| I.2 | E | Necessary assumption | 7 |
| I.3 | B | Strengthen | 8 |
| I.4 | A | Main conclusion | 4 |
| I.5 | E | Principle | 13 |
| I.6 | E | Weaken | 8 |
| I.7 | A | Must be true / inference | 10 |
| I.8 | A | Flaw | 9 |
| I.9 | B | Point at issue | 11 |
| I.10 | D | Sufficient assumption | 7 |
| I.11 | C | Paradox / resolve–explain | 13 |
| I.12 | D | Role of a statement | 11 |
| I.13 | B | Flaw | 9 |
| I.14 | C | Strengthen | 8 |
| I.15 | E | Necessary assumption | 7 |
| I.16 | C | Parallel flaw | 12 |
| I.17 | D | Most strongly supported | 10 |
| I.18 | C | Evaluate the argument | 8 |
| I.19 | E | Weaken | 8 |
| I.20 | A | Parallel reasoning | 12 |
| I.21 | D | Flaw | 9 |
| I.22 | B | Method of reasoning | 11 |
| I.23 | C | Necessary assumption | 7 |
| I.24 | A | Strengthen | 8 |
| I.25 | D | Principle | 13 |

**Section II**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| II.1 | C | Main point / primary purpose | 18 |
| II.2 | B | Inference | 18 |
| II.3 | D | Function / purpose of a part | 18 |
| II.4 | D | Detail / recognition | 18 |
| II.5 | B | Analogy / application | 18 |
| II.6 | D | Author’s attitude / tone | 18 |
| II.7 | B | Main point / primary purpose | 18 |
| II.8 | C | Inference | 18 |
| II.9 | A | Function / purpose of a part | 18 |
| II.10 | C | Detail / recognition | 18 |
| II.11 | B | Inference | 18 |
| II.12 | E | Author’s attitude / tone | 18 |
| II.13 | E | Analogy / application | 18 |
| II.14 | A | Comparative reading | 17 |
| II.15 | D | Comparative reading | 17 |
| II.16 | C | Comparative reading | 17 |
| II.17 | B | Comparative reading | 17 |
| II.18 | D | Detail / recognition | 18 |
| II.19 | C | Comparative reading | 17 |
| II.20 | A | Analogy / application | 18 |
| II.21 | E | Main point / primary purpose | 18 |
| II.22 | B | Function / purpose of a part | 18 |
| II.23 | E | Inference | 18 |
| II.24 | C | Detail / recognition | 18 |
| II.25 | A | Inference | 18 |
| II.26 | A | Structure / organization | 18 |
| II.27 | E | Analogy / application | 18 |

**Section III**

| Question | Answer | Type | Review chapter |
| --- | :---: | --- | :---: |
| III.1 | C | Flaw | 9 |
| III.2 | A | Strengthen | 8 |
| III.3 | E | Necessary assumption | 7 |
| III.4 | B | Must be true / inference | 10 |
| III.5 | D | Paradox / resolve–explain | 13 |
| III.6 | A | Weaken | 8 |
| III.7 | B | Main conclusion | 4 |
| III.8 | C | Flaw | 9 |
| III.9 | B | Parallel reasoning | 12 |
| III.10 | D | Principle | 13 |
| III.11 | B | Role of a statement | 11 |
| III.12 | A | Strengthen | 8 |
| III.13 | A | Necessary assumption | 7 |
| III.14 | C | Point at issue | 11 |
| III.15 | B | Flaw | 9 |
| III.16 | E | Sufficient assumption | 7 |
| III.17 | E | Most strongly supported | 10 |
| III.18 | A | Weaken | 8 |
| III.19 | C | Parallel flaw | 12 |
| III.20 | E | Method of reasoning | 11 |
| III.21 | C | Flaw | 9 |
| III.22 | E | Evaluate the argument | 8 |
| III.23 | D | Necessary assumption | 7 |
| III.24 | D | Strengthen | 8 |
| III.25 | D | Principle | 13 |

:::

| Skill to review | Chapter |
| --- | :---: |
| Argument core, main conclusion | 4 |
| Formal logic and conditional chains | 5 |
| Flaw recognition and matching | 6, 9 |
| Necessary / sufficient assumption | 7 |
| Strengthen, weaken, evaluate | 8 |
| Inference / most supported | 10 |
| Method, role, point at issue | 11 |
| Parallel reasoning / parallel flaw | 12 |
| Paradox and principle | 13 |
| Reading structure and author positions | 15 |
| Comparative reading | 17 |
| RC detail, inference, function and attitude | 18 |
| Blind review and error logging | 22–23 |
