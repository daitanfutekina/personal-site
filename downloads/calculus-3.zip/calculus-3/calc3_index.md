---
title: "MA 2733 Calculus III"
meta:
  - "Danielle Young"
  - "Stewart Calculus 8e"
  - "0–4 + Appendices"
  - "Chapters complete ✓"
source: "calc3_index.html"
---

Self-Study Textbook · Mississippi State University · Stewart 8e, Ch. 10–13

Overall progress — 5 chapters + 5 appendices done

Prerequisites & Foundation

✓

Chapter 0 — Prerequisites

Calc I/II recap: functions, trig, limits, differentiation, integration, sequences warm-up

Calc I/II review — Notation

3–4 hrs

✓ Done

Core Chapters — Stewart Ch. 10–13

✓

Chapter 1 — Parametric Equations & Polar Coordinates

Stewart Ch. 10 · Parametric curves, polar graphs, area & arc length in polar

Stewart Ch. 10 — Polar — Parametric

5–6 hrs

✓ Done

✓

Chapter 2 — Infinite Sequences and Series

Stewart Ch. 11 · Convergence tests, power series, Taylor & Maclaurin series, applications

Stewart Ch. 11 — Heaviest chapter — 11 sections

10–12 hrs

✓ Done

✓

Chapter 3 — Vectors and the Geometry of Space

Stewart Ch. 12 · 3D coordinates, dot & cross products, lines, planes, quadric surfaces

Stewart Ch. 12 — Geometry — 6 sections

7–8 hrs

✓ Done

✓

Chapter 4 — Vector-Valued Functions

Stewart Ch. 13 · Space curves, derivatives/integrals, arc length, curvature, TNB frame, motion

Stewart Ch. 13 — Physics — TNB frame

8–10 hrs

✓ Done

Appendices

A

Appendix A — Series Convergence Decision Tree

Flowchart: which convergence test to apply and when. All 8 tests, quick-reference table, pitfalls.

Decision tree — All 8 tests

Reference

✓ Done

B

Appendix B — Master Formula Sheet

Every key formula from Ch. 0–4 in one print-friendly two-column layout.

Print-friendly — Ch. 0–4

Reference

✓ Done

C

Appendix C — Trig Identities Reference

Pythagorean, double-angle, half-angle, sum/difference, product-to-sum, unit circle, trig sub guide.

Print-friendly — Unit circle

Reference

✓ Done

D

Appendix D — Selected Answers

Final answers to all mixed practice problems from Ch. 1–4 for self-checking.

Ch. 1–4 — Mixed practice

Reference

✓ Done

E

Appendix E — MSU Final Exam Guide

Young's high-yield topics, top 10 mistakes, 7-day study schedule, must-memorize formulas.

Exam prep — Study schedule

Reference

✓ Done

Study Tips for This Course

🎯

Answer first, then work

Every worked example states the answer before the solution. Check your guess, then study the steps. Don't skip to the answer on practice problems.

📐

Notation matters

Vectors use arrow notation $\vec{v}$, components use angle brackets $\langle a,b,c\rangle$. Young's tests are strict — match the notation.

⚠️

Read the pitfall callouts

Each section has a "Watch out for" box listing the 2–3 most common mistakes. These are the exact errors that lose points on Young's exams.

🔁

Ch. 2 needs the most time

Series (Ch. 2) is the hardest and most tested chapter. Budget at least 3 separate study sessions and drill convergence tests until automatic.

✏️

Work problems by hand

Use the "Hide all solutions" mode. Attempt every problem on paper before revealing. Passive reading does not build exam skills.

🔗

Follow the chapter connections

Each section has "Chapter connection" callouts showing how the current concept links to earlier and later material. These are the threads that tie everything together.

MA 2733 Calculus III Self-Study Textbook  ·  Mississippi State University  ·  Built with Claude
