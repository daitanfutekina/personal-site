---
title: "Appendix D — Selected Answers"
source: "markdown"
---

MA 2733 · Thomas 15e · Selected practice-answer index for book Chapters 1–4

How to use this appendix.

These are the original chapter 1–4 selected answers, retained as quick reference — no work shown. Use them to check whether you got the right answer after attempting a problem yourself. For full solutions, use the collapsed solution blocks inside each chapter. The source questions for Chapters 1–4 were **not uploaded in this request**; consequently these entries are preserved, but not independently validated against their problem statements. Verify them with their matching chapter files before relying on them as a corrected answer key.

## Chapter 1 — Parametric Equations & Polar Coordinates

### Section Practice

1.1.1 — Ellipse: $x^2+y^2/4=1$

1.1.2 — $dy/dx = -\cos t/\sin t = -\cot t$

1.1.3 — Horizontal at $t=0,\pi$; vertical at $t=\pi/2,3\pi/2$

1.2.1 — $A = 6\pi$

1.2.2 — $L = 8$

1.3.1

$r = 3$

(circle)

1.3.2 — $x^2 + (y-1)^2 = 1$

1.3.3 — $r = 2\cos\theta$

1.4.1 — $A = \pi/2$

1.4.2 — $A = 2\pi - 3\sqrt{3}/2$ (area between circles)

### Mixed Practice (1.M1–1.M10)

1.M1 — Tangent: $y = \sqrt{3}(x-1)+\sqrt{3}$

1.M2 — $L = 3\sqrt{10}$

1.M3 — $A = 9\pi/2$

1.M4 — Limaçon; inner loop area $= \pi - 3\sqrt{3}/2$

1.M5 — $d^2y/dx^2 = -1/4$ at $t=1$

1.M6 — $A = 2$

1.M7 — $r^2 = \sec 2\theta$ (lemniscate)

1.M8 — 3 intersections

1.M9 — $L = \int_0^{2\pi}\sqrt{(1-\cos\theta)^2+\sin^2\theta}\,d\theta = 8$

1.M10 — Surface area $= 12\pi$ (retained; source problem not provided)

## Chapter 2 — Infinite Sequences and Series

### Mixed Practice (2.M1–2.M10)

2.M1 — Converges; $L = 0$

2.M2 — Diverges (Ratio Test: $L=\infty$)

2.M3 — Converges absolutely (Ratio Test: $L=0$)

2.M4 — Diverges (p-series, $p=1/2\leq1$)

2.M5 — Converges conditionally (AST); diverges absolutely

2.M6 — $R=1$; interval $(-1,1]$

2.M7 — $f(x) = \sum_{n=0}^\infty(-1)^n x^{2n}$, $|x|<1$

2.M8 — $T_3(x) = 1+x+x^2/2+x^3/6$

2.M9 — Error $\leq 1/5!=1/120\approx0.00833$ (**not on Test 4**: Taylor remainder)

2.M10 — $\approx0.310$ (4 decimal accuracy)

## Chapter 3 — Vectors and the Geometry of Space

### Mixed Practice (3.M1–3.M10)

3.M1 — Midpoint $(1,1,3)$; $d=2\sqrt{17}$

3.M2 — $\theta=\arccos(1/\sqrt{3})\approx54.7°$

3.M3 — $\vec{a}\cdot\vec{b}=0$ ✓; normal: $\langle1,-1,1\rangle$

3.M4 — Scalar: $12/7$; vector: $\langle24/49,36/49,72/49\rangle$

3.M5 — Area $=5\sqrt{2}/2$; angle at $P\approx106°$

3.M6 — $x-y-z=2$

3.M7 — Ellipsoid; semi-axes $1,2,3$

3.M8 — $D=6/\sqrt{14}=3\sqrt{14}/7$

3.M9 — $V=13$

3.M10 — Hyperboloid of one sheet, centered $(-1,1,1)$, axis along $y$

## Chapter 4 — Vector-Valued Functions

### Mixed Practice (4.M1–4.M10)

4.M1 — Domain: $[0,1]$

4.M2 — $L=\sqrt{2}\sinh1\approx1.662$

4.M3 — Line: $\langle1+t,1-t,t\rangle$; angle with $z$-axis $\approx54.7°$

4.M4 — $\vec{r}(2)=\langle9,4,3\rangle$

4.M5 — $\kappa=2$ at $t=0$

4.M6 — $t=\sqrt{3}\approx1.73$ s; $H=15$ m; $R=20\sqrt{3}\approx34.6$ m

4.M7 — $\kappa=1/2$; $\hat{T}=\langle0,1/\sqrt{2},1/\sqrt{2}\rangle$; $\hat{N}=\langle-1,0,0\rangle$

4.M8 — $\vec{r}\times\vec{r}\,''$

4.M9 — $a_T=22/\sqrt{14}$; $a_N=\sqrt{38/7}$

4.M10 — Proof: constant speed $\Rightarrow a_T=0\Rightarrow|\vec{a}|=a_N=\kappa v^2$


## How to Use This Key on a Written Exam

For series items, give the test name, relevant hypotheses and limiting calculation. For Test 4 power-series problems, include **both endpoint tests**; for AST classify absolute versus conditional separately. For Test 2 vectors, write dot/cross product components and the plane normal. For Test 3, report $\mathbf v$, $|\mathbf v|$, direction, $\mathbf T$, $\mathbf N$, or $\kappa$ in the form asked. A result alone is not the graded written reasoning.

:::callout-warning[Source-audit boundary]
Answers for book Chapters 1–4 are not verifiable from this appendix alone; do not infer the original question or silently replace one of its answers without the matching problems and solutions.
:::
