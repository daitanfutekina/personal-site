---
title: "Appendix A — Series Convergence Decision Tree"
source: "markdown"
---

MA 2733 · Thomas 15e §10.1–10.8 · Test 4 (November 20, 2026)

:::callout-key[What this flowchart proves]
First classify the expression: **sequence limit**, **infinite series**, **power series**, or **Taylor polynomial**. The convergence tests below apply to *infinite series*, not to sequence limits or finite Taylor polynomials. In written answers, name the test, state its hypotheses, calculate the relevant limit or integral, and conclude.
:::

## The Decision Tree

```text
Input: Σ a_n
  |
  +-- Is lim a_n nonzero, infinite, or nonexistent? --> DIVERGES (nth-term test)
  |   (If lim a_n = 0, this does NOT prove convergence.)
  |
  +-- Geometric? Σ a r^n --> |r|<1: sum a/(1-r); |r|>=1: diverges
  |
  +-- p-series? Σ 1/n^p --> p>1: converges; p<=1: diverges
  |
  +-- Alternating? --> Test absolute value first; then use AST if needed
  |       |a_n| converges: absolutely convergent
  |       |a_n| diverges and b_n decreases to 0: conditionally convergent
  |       b_n does not approach 0: divergent
  |
  +-- Factorials? --> Ratio Test, simplify (n+1)!=(n+1)n!
  +-- Whole expression raised to n? --> Root Test
  +-- Rational / bounded trig? --> Direct or Limit Comparison to p-series
  +-- Positive, continuous, decreasing f(x) with an easy integral? --> Integral Test
  +-- L=1 from Ratio/Root? --> INCONCLUSIVE; return to another test
```

**Power-series branch, §10.7:** Rewrite as $\sum c_n(x-a)^n$. Find $R$ with Ratio/Root Test (or coefficient growth), get $|x-a|< R$, then test **each finite endpoint separately**. $R=0$ means only the center can converge; $R=\infty$ means all real $x$ converge. A convergence test yielding $L=1$ at an endpoint says nothing: do another test there.

**Taylor branch, §10.8:** For a polynomial of degree $m$, compute $P_m(x)=\sum_{k=0}^m f^{(k)}(a)(x-a)^k/k!$. This is a *finite* sum; do not ask whether it converges.

## Step 2 — Geometric Series

If $\sum_{n=m}^\infty ar^n$, the first term is $ar^m$. The sum for $|r|<1$ is $ar^m/(1-r)$, not automatically $a/(1-r)$. If $|r|\ge1$ and $a\ne0$, the terms do not approach zero.

Young-style two-series example:

$$
\sum_{n=1}^{\infty}\frac{4^n+7^n}{9^n}
=\sum_{n=1}^{\infty}\left(\frac49\right)^n+\sum_{n=1}^{\infty}\left(\frac79\right)^n
=\frac{4/9}{1-4/9}+\frac{7/9}{1-7/9}=\frac45+\frac72=\frac{43}{10}.
$$

Here both ratios have absolute value less than one.

## Step 3 — p-Series

$$\sum_{n=1}^{\infty} n^{-p}\ \begin{cases}\text{converges},&p>1,\\\text{diverges},&p\le1.\end{cases}$$

Examples: $\sum1/n^{5/2}$ converges and $\sum1/\sqrt n$ diverges. A **finite nonzero constant multiple** does not change either result. $\sum 1/[n(\ln n)^p]$ is *not* a $p$-series; examine its integral for $n\ge2$.

## Step 4 — Alternating Series Test (AST)

For $\sum (-1)^n b_n$, check the **three classroom conditions** explicitly: (1) signs alternate, with $b_n\ge0$; (2) $b_n$ is eventually nonincreasing; and (3) $\lim b_n=0$. These guarantee convergence, but do **not** by themselves prove it is conditional.

**Classification:** If $\sum|a_n|$ converges, convergence is **absolute**. If $\sum|a_n|$ diverges but AST holds, convergence is **conditional**. If $a_n\not\to0$, the series **diverges**. If AST fails because monotonicity is absent, the result is **inconclusive**, not automatically divergent.

Example: $\sum_{n=1}^\infty (-1)^{n+1}/n$ converges by AST and diverges absolutely because $\sum1/n$ is harmonic, so it is **conditional**.

:::callout-pitfall[AST does not mean conditional]
The old wording “AST only proves conditional convergence” was wrong. AST establishes convergence, not the classification. You must separately test $\sum|a_n|$.
:::

## Step 5 — Ratio Test & Root Test

| Test | Compute | $L<1$ | $L>1$ or $L=\infty$ | $L=1$ |
| --- | --- | --- | --- | --- |
| Ratio | $\displaystyle L=\lim_{n\to\infty}\left|a_{n+1}/a_n\right|$ | Absolute convergence | Divergence | Inconclusive |
| Root | $\displaystyle L=\lim_{n\to\infty}\sqrt[n]{|a_n|}$ | Absolute convergence | Divergence | Inconclusive |

The ratio formula presumes the relevant terms are eventually nonzero and its limit exists. For example, $\sum n!/5^n$: $|a_{n+1}/a_n|=(n+1)/5\to\infty$, so it diverges. For $\sum (3n/(4n+1))^n$, the Root Test gives $L=3/4<1$, so it converges absolutely. When $L=1$, neither test decides anything; $\sum1/n$ and $\sum1/n^2$ both give $L=1$ and behave differently.

## Step 6 — Comparison & Limit Comparison Tests

For **nonnegative** terms, comparison directions matter.

| Desired result | Sufficient evidence |
| --- | --- |
| Convergence by DCT | $0\le a_n\le b_n$ eventually, and $\sum b_n$ converges |
| Divergence by DCT | $0\le b_n\le a_n$ eventually, and $\sum b_n$ diverges |
| LCT equivalence | $a_n,b_n>0$ eventually and $\displaystyle\lim a_n/b_n=L$ with $0< L<\infty$ |

For $a_n=(n^2+3)/(n^4-2)$ and $b_n=1/n^2$ (for sufficiently large $n$),

$$\lim_{n\to\infty}\frac{a_n}{b_n}=\lim\frac{n^4+3n^2}{n^4-2}=1.$$ 

Since $\sum1/n^2$ converges, the target converges by Limit Comparison. For $\sin^2 n/n^{5/2}$, use $0\le\sin^2 n/n^{5/2}\le1/n^{5/2}$; DCT proves convergence **without** needing a limit of $\sin^2 n$.

:::callout-tip[Young's bounded functions: direct comparison]
For $n\ge1$, $0\le\arctan n\le\pi/2$, so

$$0\le\frac{\arctan n}{1+n^2}\le\frac{\pi}{2n^2}.$$

Because $\sum 1/n^2$ converges, the target converges by Direct Comparison. An oscillating numerator such as $\sin^2 n$ is handled the same way: bound it between $0$ and $1$ rather than trying to take its limit.
:::

## Step 7 — Integral Test

If $f$ is **continuous, positive and eventually decreasing**, and $a_n=f(n)$, then $\sum a_n$ and $\int f(x)\,dx$ have the **same convergence behavior** (not the same numerical value). Begin past any singular points.

Young-style demonstration: $f(x)=6/[x(\ln x)^2]$ on $[2,\infty)$. It is positive and continuous there. Its derivative is

$$f'(x)=-\frac{6(\ln x+2)}{x^2(\ln x)^3}<0\quad(x\ge2).$$

Then $u=\ln x$, $du=dx/x$:

$$\int_2^\infty\frac{6}{x(\ln x)^2}\,dx=\lim_{b\to\infty}\left[-\frac6{\ln x}\right]_2^b=\frac6{\ln2}.$$

The integral is finite, so $\sum_{n=2}^\infty6/[n(\ln n)^2]$ converges. Contrast $\int_2^b dx/[x\ln x]=\ln(\ln b)-\ln(\ln2)\to\infty$.

**Arctangent Integral Test prototype:** For $f(x)=7/(x^2+81)$ on $[1,\infty)$, $f$ is continuous, positive, and decreasing since $f'(x)=-14x/(x^2+81)^2<0$. With $\int dx/(x^2+81)=\arctan(x/9)/9$,

$$\int_1^\infty\frac{7}{x^2+81}\,dx=\frac79\left[\frac\pi2-\arctan\frac19\right]<\infty.$$

Hence $\sum_{n=1}^\infty7/(n^2+81)$ converges by Integral Test. These hypotheses are part of the written justification.

## Quick Reference — All Tests at a Glance

| Test | Cue | Must write for full justification |
| --- | --- | --- |
| nth-term | Terms fail to tend to zero | $\lim a_n\ne0$ or DNE; therefore divergent |
| Geometric | Constant ratio | First term, ratio, $|r|<1$ or not; sum if requested |
| p-series | Exactly $n^{-p}$ | $p$ and cutoff $p>1$ |
| Integral | Integrable positive decreasing function | All three hypotheses, evaluated improper limit |
| Direct/Limit Comparison | Rational forms, bounded numerators | Positive terms, inequality or finite positive limit, benchmark result |
| Ratio/Root | Factorials or $n$th powers | Limit $L$ and the correct one of three outcomes |
| AST | Alternating positive magnitudes | Alternation, eventually decreasing $b_n$, $b_n\to0$; absolute check separately |
| Radius/interval | Parameter $x$ in $\sum c_n(x-a)^n$ | Center, $R$, both endpoints independently |
| Taylor $P_0$–$P_3$ | Derivatives at center | $f(a),f'(a),f''(a),f^{(3)}(a)$ and factorial denominators |

:::callout-pitfall[Failure modes]
If the term limit is zero, that is **inconclusive**, not convergence. If Ratio or Root Test gives $1$, switch tests. If the input is alternating, distinguish **absolute**, **conditional**, and **divergent**. On Test 4, telescoping and Taylor remainder/error bounds are **not on Test 4** in the supplied review material.
:::
