---
title: "Infinite Sequences and Series"
crumb: "Calculus 3 · Chapter 2 (Thomas Ch. 10)"
meta:
  - "Est. study time: ~8–10 hours"
  - "Thomas 15e, Ch. 10 · Young Test 4"
  - "Heaviest chapter — pace yourself"
source: "markdown"
---

## Overview

This chapter answers three precise questions: does a sequence have a limit; does a numerical series converge; and how closely does a Taylor polynomial match a function near its center? The central question sounds simple: *if you add infinitely many numbers together, can you get a finite answer?* Sometimes yes, sometimes no — and the chapter is a systematic toolkit for telling which.

The chapter breaks into three distinct acts. **Act I (§2.1–2.7)** is about sequences and series: you learn to ask "does this converge?" and you build seven different tests to answer that question. **Act II (§2.8–2.9)** introduces power series — series whose terms involve a variable $x$, so the answer becomes "it depends on $x$." **Act III (§2.10–2.11)** is the payoff: Taylor series, which let you represent functions as infinite polynomials. This is arguably the most powerful idea in all of calculus.

One warning about pacing: §2.1–2.7 contains several tests. Students often try to memorize all seven at once and mix them up on exams. The smarter approach is to learn the *pattern recognition* — each test has a natural trigger (factorials? → Ratio Test; everything to the $n$? → Root Test; alternating signs? → AST). Section 2.7 makes this explicit with a flowchart. Internalize that flowchart and the rest of the chapter opens up.

:::callout-key[Prerequisites from Chapter 0]
- **Improper integrals** (Ch. 0 §0.5.7) — the Integral Test is literally just evaluating $\int_1^\infty f(x)\,dx$
- **L'Hôpital's rule** (Ch. 0 §0.3.3) — used constantly to evaluate sequence limits
- **Growth-rate hierarchy** (Ch. 0 §0.3.4): $\ln n \ll n^a \ll b^n \ll n! \ll n^n$ — you will use this to eyeball limits instantly
- **Higher-order derivatives** (Ch. 0 §0.4.6) — Taylor series coefficients are $f^{(n)}(a)/n!$
- **Geometric series warm-up** (Ch. 0 §0.7) — §2.2 formalizes what you previewed there
:::

:::callout-warning[⚠ Exam Weighting (Young's MA 2733)]
Young’s Test 4 review covers Thomas 10.1–10.8. Prove convergence by naming the test and checking its conditions; do not infer what is on other exams. The decision tree in §2.7 is the single highest-leverage page in the chapter. Learn to apply it in under 30 seconds per series.
:::

## 10.1 Sequences

**Thomas 10.1 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Sequences | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition — What is a sequence?]
A **sequence** is simply an ordered, infinite list of numbers: $a_1, a_2, a_3, a_4, \ldots$. You can think of it as a function $f: \mathbb{Z}^+ \to \mathbb{R}$ where $a_n = f(n)$. Examples you already know: the integers $1, 2, 3, 4, \ldots$; the reciprocals $1, \frac{1}{2}, \frac{1}{3}, \frac{1}{4}, \ldots$; the alternating signs $1, -1, 1, -1, \ldots$.

The central question is: **as $n$ grows toward infinity, where does the sequence go?** Does it settle toward some fixed number (converge), or does it wander, oscillate, or blow up (diverge)? This question is the foundation of everything else in the chapter — before you can talk about the sum of an infinite series, you need to understand the behavior of its terms.

The key insight is that limits of sequences work almost exactly like limits of functions — all the tools from Chapter 0 (L'Hôpital, squeeze theorem, growth-rate hierarchy) carry over. The only difference is that $n$ takes integer values rather than all real values, but that rarely matters for computing limits.
:::

:::definition[Definition 2.1 — Convergence of a Sequence]
A sequence $\{a_n\}$ **converges to $L$**, written $\displaystyle\lim_{n\to\infty} a_n = L$, if for every $\varepsilon > 0$ there exists a positive integer $N$ such that $n > N \Rightarrow |a_n - L| < \varepsilon$. In plain English: the terms $a_n$ get arbitrarily close to $L$ and stay there. If no such $L$ exists, the sequence **diverges**.
:::

### Computing sequence limits: the full toolkit

**Tool 1 — Treat it like a continuous function limit.** If $a_n = f(n)$ for some function $f$ that's defined for all real $x$, and $\lim_{x\to\infty}f(x) = L$, then $\lim_{n\to\infty}a_n = L$ as well. This is the bridge that lets you use all your Calc I limit techniques on sequences. In particular, it lets you use L'Hôpital's rule: if $a_n = f(n)/g(n)$ gives $\infty/\infty$, differentiate numerator and denominator as functions of a continuous variable.

**Tool 2 — The growth-rate hierarchy.** This hierarchy tells you which functions "win" as their argument goes to infinity:

$$
\ln n \;\ll\; n^{0.001} \;\ll\; n \;\ll\; n^{100} \;\ll\; 1.001^n \;\ll\; n! \;\ll\; n^n.
$$

The symbol $\ll$ means "grows much slower than." Any expression that has a faster-growing function in the denominator than in the numerator has limit 0. This lets you call many limits by inspection: $n^{100}/2^n \to 0$ because exponentials beat polynomials; $(\ln n)/\sqrt{n} \to 0$ because any positive power of $n$ beats $\ln n$.

:::callout-connect[🔁 Connects to Ch. 0 §0.3.4]
The growth-rate hierarchy was introduced in the limits review. It was designed to reappear here. If you are fuzzy on it, flip back and reread that section before continuing.
:::

**Tool 3 — Squeeze Theorem.** If you can bound $a_n$ between two sequences that both converge to the same limit, then $a_n$ must converge to that limit too. Formally: if $b_n \le a_n \le c_n$ and $\lim b_n = \lim c_n = L$, then $\lim a_n = L$. The classic application is any sequence with an oscillating or absolute-value factor like $(-1)^n/n$: bound it above by $1/n$ and below by $-1/n$, both of which go to 0.

**Tool 4 — Limit laws.** The usual arithmetic rules hold for sequences: if $\{a_n\}$ and $\{b_n\}$ both converge, then so do their sum, difference, product, and (assuming nonzero limit denominator) quotient. Constant multiples and powers also work as expected. These rules reduce most limits to finding the limits of simpler pieces.

**Tool 5 — The exponential trick for $a_n^{b_n}$ forms.** When you have an indeterminate form like $1^\infty$ or $0^0$, write $a_n^{b_n} = e^{b_n \ln a_n}$, find $\lim b_n \ln a_n$ (which is usually a L'Hôpital problem), and then exponentiate the result.

:::theorem[Theorem 2.1 — Monotonic Sequence Theorem]
Every bounded, monotonic sequence converges. Specifically: if $\{a_n\}$ is *increasing* ($a_{n+1} \ge a_n$) and *bounded above* (there exists $M$ with $a_n \le M$ for all $n$), then $\{a_n\}$ converges. Similarly if it's decreasing and bounded below.
:::

This theorem is more philosophically important than computationally so. It guarantees convergence without you having to find the limit explicitly — useful for existence proofs and for sequences defined recursively (where you can show monotonicity and boundedness without having a closed form). It is mainly an existence theorem; the Test 4 review instead emphasizes calculating recursive terms like $a_{n+1} = \sqrt{2 + a_n}$.

### Worked Examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Points of a sequence one over n approaching zero">
<path class="fig-axis" d="M 20 155 L 380 155 M 45 20 L 45 205"/>
<path class="fig-point" d="M 70 120.0 l 0.1 0"/>
<path class="fig-point" d="M 95 137.5 l 0.1 0"/>
<path class="fig-point" d="M 120 143.33333333333334 l 0.1 0"/>
<path class="fig-point" d="M 145 146.25 l 0.1 0"/>
<path class="fig-point" d="M 170 148.0 l 0.1 0"/>
<path class="fig-point" d="M 195 149.16666666666666 l 0.1 0"/>
<path class="fig-point" d="M 220 150.0 l 0.1 0"/>
<path class="fig-point" d="M 245 150.625 l 0.1 0"/>
<path class="fig-point" d="M 270 151.11111111111111 l 0.1 0"/>
<path class="fig-point" d="M 295 151.5 l 0.1 0"/>
<path class="fig-point" d="M 320 151.8181818181818 l 0.1 0"/>

</svg>
<figcaption>The points $a_n=1/n$ fall toward the horizontal axis: convergence concerns individual terms, not the sum of those terms.</figcaption>
</figure>


:::example[🧠 Example 10.1.1 — Polynomial ratio]
Find $\displaystyle\lim_{n\to\infty}\frac{3n^3 - 5n + 2}{7n^3 + n^2}$.

**Answer: $\dfrac{3}{7}$**

Work — the leading-term strategy

When both numerator and denominator are polynomials in $n$, only the highest-degree terms matter as $n\to\infty$. Every lower-degree term becomes negligible. The standard technique is to divide every term by $n^3$ (the highest power anywhere in the expression):

$$
\frac{3n^3 - 5n + 2}{7n^3 + n^2} = \frac{3 - 5/n^2 + 2/n^3}{7 + 1/n}.
$$

As $n\to\infty$, every term with $n$ in the denominator $\to 0$, leaving $\dfrac{3 - 0 + 0}{7 + 0} = \dfrac{3}{7}$.

**Shortcut:** if you recognize this as a ratio of polynomials with equal degree, just take the ratio of the leading coefficients: $3/7$. You don't need to write out the full division every time.
:::

:::example[🧠 Example 10.1.2 — L'Hôpital on a sequence]
Find $\displaystyle\lim_{n\to\infty}\frac{\ln n}{\sqrt{n}}$.

**Answer: $0$**

**Hand calculation.**
Both numerator and denominator grow to infinity, giving $\infty/\infty$. Treat $n$ as a continuous variable and apply L'Hôpital:

$$
\lim_{x\to\infty}\frac{\ln x}{\sqrt{x}} \stackrel{\text{L'H}}{=} \lim_{x\to\infty}\frac{1/x}{1/(2\sqrt{x})} = \lim_{x\to\infty}\frac{2\sqrt{x}}{x} = \lim_{x\to\infty}\frac{2}{\sqrt{x}} = 0.
$$

This confirms what the growth-rate hierarchy predicts: $\ln n$ grows far slower than any positive power of $n$, so $\sqrt{n}$ "wins."
:::

:::example[🧠 Example 10.1.3 — Oscillating sequence]
Does $a_n = (-1)^n$ converge?

**Answer: Diverges.**

**Hand calculation.**
The sequence is: $-1, +1, -1, +1, -1, \ldots$. It oscillates between two values forever and never settles. More formally: consider the two subsequences $\{a_{2k}\} = \{1, 1, 1, \ldots\}$ converging to $1$, and $\{a_{2k-1}\} = \{-1, -1, -1, \ldots\}$ converging to $-1$. If $\{a_n\}$ converged to $L$, every subsequence would have to converge to the same $L$. Since two subsequences approach different values, no such $L$ can exist. The sequence diverges.

*But note:* $a_n = (-1)^n/n$ does converge (to 0), because the oscillation gets damped down to zero. Oscillating alone doesn't guarantee divergence — the magnitude must not shrink to zero for it to diverge.
:::

:::example[🧠 Example 10.1.4 — The exponential trick]
Show that $\displaystyle\lim_{n\to\infty}n^{1/n} = 1$.

**Answer: Limit equals 1.**

**Hand calculation.**
This is the indeterminate form $\infty^0$. Use the exponential trick: write $n^{1/n} = e^{(1/n)\ln n}$ and analyze the exponent separately.

$$
\lim_{n\to\infty}\frac{\ln n}{n} \stackrel{\text{L'H}}{=} \lim_{x\to\infty}\frac{1/x}{1} = 0.
$$

So the exponent $(1/n)\ln n \to 0$, and therefore $n^{1/n} = e^{(1/n)\ln n} \to e^0 = 1$.

This result is worth memorizing: $n^{1/n} \to 1$. It comes up repeatedly in the Root Test.
:::

:::example[🧠 Example 10.1.5 — Squeeze Theorem]
Find $\displaystyle\lim_{n\to\infty}\frac{\cos n}{n}$.

**Answer: $0$**

**Hand calculation.**
The numerator $\cos n$ oscillates between $-1$ and $1$ with no pattern (since $n$ is in radians and there's no nice periodicity over integers). You can't simplify it directly. But you can bound it: $-1 \le \cos n \le 1$, so

$$
-\frac{1}{n} \le \frac{\cos n}{n} \le \frac{1}{n}.
$$

Both $-1/n$ and $1/n$ go to $0$ as $n\to\infty$. By the Squeeze Theorem, $\dfrac{\cos n}{n} \to 0$.
:::

:::example[🧠 Example 10.1.6 — Recognizing $e$ as a limit]
Find $\displaystyle\lim_{n\to\infty}\left(1 + \frac{1}{n}\right)^n$.

**Answer: $e \approx 2.71828\ldots$**

**Hand calculation.**
This is one of the fundamental limits of calculus — it's actually one of several equivalent definitions of $e$. To verify it rigorously: let $L = \lim_{n\to\infty}(1+1/n)^n$. Take the natural log:

$$
\ln L = \lim_{n\to\infty} n\ln\!\left(1+\tfrac{1}{n}\right) = \lim_{n\to\infty}\frac{\ln(1+1/n)}{1/n}.
$$

This is $0/0$. Let $x = 1/n$ (so $x\to 0^+$) and apply L'Hôpital:

$$
\lim_{x\to 0^+}\frac{\ln(1+x)}{x} \stackrel{\text{L'H}}{=} \lim_{x\to 0^+}\frac{1/(1+x)}{1} = 1.
$$

So $\ln L = 1$, meaning $L = e$. Variants like $(1 + k/n)^n \to e^k$ come up in probability and finance.
:::

:::callout-pitfall[⚠ Three Classic Sequence Mistakes]
- **Confusing sequences with series.** A sequence is a list: $\{a_n\}$. A series is a sum: $\sum a_n$. They have completely different convergence machinery. When your instinct says "apply the Ratio Test," check: are you working with a sequence or a series? The Ratio Test applies only to series.
- **Thinking bounded ⇒ convergent.** The Monotonic Sequence Theorem requires BOTH bounded AND monotonic. The sequence $(-1)^n$ is bounded ($|a_n| \le 1$) but diverges because it's not monotonic.
- **Applying L'Hôpital to a non-indeterminate form.** L'Hôpital only works on $0/0$ or $\infty/\infty$. If you have $1/\infty$ or $0/5$, just evaluate directly.
:::

::::problem[Problem 10.1.1 easy]{difficulty=easy}
Find $\displaystyle\lim_{n\to\infty}\frac{5n^3 - 2n}{n^3 + 7}$.

:::solution[Solution]
**Answer:** $5$

1. **Method: divide by the highest power of $n$.** Both polynomials have degree three, so divide every numerator and denominator term by $n^3$ (which is nonzero for $n\ge1$):

   $$
   \frac{5n^3-2n}{n^3+7}=\frac{5-2/n^2}{1+7/n^3}.
   $$

2. **Take the limit term by term.** Because $1/n^2\to0$ and $1/n^3\to0$, the denominator tends to $1\ne0$. The quotient limit law therefore applies:

   $$
   \lim_{n\to\infty}\frac{5-2/n^2}{1+7/n^3}=\frac{5-0}{1+0}=5.
   $$

3. **Conclusion.** The sequence converges to $5$. The result also matches the ratio of leading coefficients, $5/1$.
:::
::::
::::problem[Problem 10.1.2 easy]{difficulty=easy}
Does $a_n = \dfrac{(-1)^n}{n}$ converge? If so, to what?

:::solution[Solution]
**Answer:** Converges to $0$.

1. **Method: Squeeze Theorem.** The factor $(-1)^n$ changes sign, so directly taking its limit would not work. However, its absolute value always equals one: $|(-1)^n|=1$.

2. **Construct upper and lower bounds.** For every integer $n\ge1$, $-1\le(-1)^n\le1$. Dividing by the positive number $n$ preserves the inequalities:

   $$
   -\frac1n\le\frac{(-1)^n}{n}\le\frac1n.
   $$

3. **Check the bounds' limits.** Both $-1/n$ and $1/n$ tend to zero as $n\to\infty$. The Squeeze Theorem applies because the sequence is trapped between bounds with the same limit.

4. **Conclusion.** $\displaystyle\lim_{n\to\infty}(-1)^n/n=0$, so the sequence converges, despite alternating signs.
:::
::::
::::problem[Problem 10.1.3 easy]{difficulty=easy}
Find $\displaystyle\lim_{n\to\infty}\frac{e^n}{n^{100}}$.

:::solution[Solution]
**Answer:** Diverges to $+\infty$.

1. **Method: compare exponential and polynomial growth.** The numerator $e^n$ and denominator $n^{100}$ are positive for $n\ge1$. An exponential with base $e>1$ eventually grows faster than any fixed polynomial.

2. **Justify that comparison by a function limit.** Treat the index as a real variable and take logarithms of the positive quotient:

   $$
   \ln\!\left(\frac{e^x}{x^{100}}\right)=x-100\ln x.
   $$

   To check its growth, L'Hôpital's rule applies to the $\infty/\infty$ form in $\ln x/x$:

   $$
   \lim_{x\to\infty}\frac{\ln x}{x}=\lim_{x\to\infty}\frac{1/x}{1}=0.
   $$

   Hence $x-100\ln x=x(1-100\ln x/x)\to+\infty$.

3. **Conclusion.** Exponentiating gives $e^n/n^{100}\to+\infty$. Since no finite limit exists, the sequence diverges.
:::
::::
::::problem[Problem 10.1.4 standard]{difficulty=standard}
Find $\displaystyle\lim_{n\to\infty}\frac{\ln(n^2+1)}{\ln(n+1)}$.

:::solution[Solution]
**Answer:** $2$

1. **Method: L'Hôpital's rule.** Replace integer $n$ with real $x>0$. Both $\ln(x^2+1)$ and $\ln(x+1)$ tend to $+\infty$, so the quotient has the required $\infty/\infty$ form.

2. **Differentiate the numerator and denominator separately.** By the chain rule,

   $$
   \frac{d}{dx}\ln(x^2+1)=\frac{2x}{x^2+1},\qquad
   \frac{d}{dx}\ln(x+1)=\frac1{x+1}.
   $$

   L'Hôpital's rule gives

   $$
   \lim_{x\to\infty}\frac{\ln(x^2+1)}{\ln(x+1)}
   =\lim_{x\to\infty}\frac{2x(x+1)}{x^2+1}.
   $$

3. **Divide by $x^2$.** The new ratio is $\frac{2+2/x}{1+1/x^2}$, which tends to $2/1=2$.

4. **Conclusion.** The original sequence converges to $2$, since the continuous function has that limit.
:::
::::
::::problem[Problem 10.1.5 standard]{difficulty=standard}
Determine whether $a_n = \left(1 + \dfrac{3}{n}\right)^n$ converges, and find the limit.

:::solution[Solution]
**Answer:** $e^3$

1. **Method: logarithm of an indeterminate power.** The base $1+3/n$ tends to $1$ while the exponent $n$ tends to infinity; this is a $1^\infty$ form. All bases are positive, so taking natural logarithms is valid.

2. **Evaluate the logarithm.** Write $y_n=(1+3/n)^n$. Then

   $$
   \ln y_n=n\ln(1+3/n)=3\frac{\ln(1+3/n)}{3/n}.
   $$

   Put $t=3/n$, so $t\to0^+$; the quotient $\ln(1+t)/t$ has form $0/0$. L'Hôpital's rule gives

   $$
   \lim_{t\to0^+}\frac{\ln(1+t)}t
   =\lim_{t\to0^+}\frac{1/(1+t)}1=1.
   $$

3. **Undo the logarithm.** Thus $\ln y_n\to3$. By continuity of $e^x$, $y_n=e^{\ln y_n}\to e^3$.

4. **Conclusion.** The sequence converges to $e^3$.
:::
::::
::::problem[Problem 10.1.6 challenge]{difficulty=challenge}
Show that $a_n = \dfrac{2^n}{n!}$ converges to 0. (Hint: use the Squeeze Theorem by bounding the tail of the product.)

:::solution[Solution]
**Answer:** $0$

1. **Method: squeeze by a geometric sequence.** Rewrite the factorial as $n!=1\cdot2\cdot3\cdots n$, so

   $$
   \frac{2^n}{n!}=\frac21\cdot\frac22\cdot\frac23\cdots\frac2n.
   $$

2. **Bound the tail factors.** The first two factors multiply to $2$. For every $k\ge3$, $0<2/k\le2/3$. There are $n-2$ such factors, hence for $n\ge3$,

   $$
   0<\frac{2^n}{n!}\le2\left(\frac23\right)^{n-2}.
   $$

3. **Check the comparison limit.** Since $0<2/3<1$, repeated multiplication by $2/3$ tends to zero. Therefore $2(2/3)^{n-2}\to0$; the lower bound is also zero.

4. **Conclusion.** By the Squeeze Theorem, $\displaystyle\lim_{n\to\infty}2^n/n!=0$. Thus the sequence converges to zero.
:::
::::

### Test 4 workshop: recursive terms and finding a formula

On Young’s review, a sequence question may supply only $a_1$ and a rule for $a_{n+1}$. A recursion is not a request to plug the same number in ten times. For the second term, put $n=1$ into the rule and use the supplied $a_1$. For the third, put $n=2$ into the rule and use the $a_2$ you just calculated. **Write the substituted index on every line.** If your arithmetic goes wrong at $a_3$, all later terms inherit the mistake; the visible substitutions make partial credit possible.

A different question may show $1,-4,9,-16,25,\ldots$ and ask for $a_n$. Separate the **magnitude** and **sign**: the magnitudes are $n^2$, while the signs are positive when $n$ is odd. Thus $(-1)^{n+1}n^2$ is the formula. Check $n=1$ and $n=2$ before committing. For a fractional sequence, look for numerator and denominator patterns independently. For example $1/12,2/15,4/18,8/21,\ldots$ has numerator $2^{n-1}$ and denominator $12+3(n-1)=3n+9$.

:::callout-key[What earns the sequence-limit points]
Start with the original expression; name the indeterminate form only when one occurs; perform the algebra or L’Hôpital step; display the limit of the simplified expression; then write **converges to $L$** or **diverges**. A sequence going to $+\infty$ is divergent; “the limit is infinity” does not make it convergent.
:::

:::example[Example 10.1.7 — Young-style ten-term recursion]
Given $a_1=2$ and $a_{n+1}=\frac{n}{n+2}a_n$, find $a_1$ through $a_{10}$ and a formula for $a_n$.

**Answer: $a_n=\frac{4}{n(n+1)}$; the first ten terms are $2,\frac23,\frac13,\frac15,\frac{2}{15},\frac{2}{21},\frac{1}{14},\frac{1}{18},\frac{2}{45},\frac{2}{55}$.**


**Step 1: substitute the correct index each time.**

$$
\begin{aligned}
a_2&=\tfrac{1}{3}(2)=\tfrac23,\\
a_3&=\tfrac{2}{4}(\tfrac23)=\tfrac13,\\
a_4&=\tfrac35(\tfrac13)=\tfrac15,\\
a_5&=\tfrac46(\tfrac15)=\tfrac{2}{15},\\
a_6&=\tfrac57(\tfrac{2}{15})=\tfrac{2}{21},\\
a_7&=\tfrac68(\tfrac{2}{21})=\tfrac1{14},\\
a_8&=\tfrac79(\tfrac1{14})=\tfrac1{18},\\
a_9&=\tfrac8{10}(\tfrac1{18})=\tfrac2{45},\\
a_{10}&=\tfrac9{11}(\tfrac2{45})=\tfrac2{55}.
\end{aligned}
$$

**Step 2: multiply the recurrence factors.** Starting at 2, every ratio contributes its own numerator and denominator:

$$
a_n=2\left(\frac13\right)\left(\frac24\right)\cdots\left(\frac{n-1}{n+1}\right)
=2\frac{(n-1)!}{(n+1)!/2!}=\frac4{n(n+1)}.
$$
**Step 3: verify the formula.** At $n=1$, $4/(1\cdot2)=2$. Also $a_{n+1}/a_n=\frac{n}{n+2}$, exactly the assigned recurrence. The limit is $0$ because the denominator grows like $n^2$.

:::

:::example[Example 10.1.8 — Logarithmic L’Hôpital limit]
Determine whether $a_n=\frac{\ln(n+6)}{n}$ converges.

**Answer: $\displaystyle\lim_{n\to\infty}a_n=0$; the sequence converges.**


The numerator $\ln(n+6)\to\infty$ and denominator $n\to\infty$, so L’Hôpital applies to the continuous function:

$$
\lim_{x\to\infty}\frac{\ln(x+6)}x
=\lim_{x\to\infty}\frac{1/(x+6)}{1}
=\lim_{x\to\infty}\frac1{x+6}=0.
$$
We differentiated the numerator with the chain rule: $(\ln(x+6))'=1/(x+6)$. The denominator derivative is $1$. We took a **function limit** to justify the **sequence limit**, rather than pretending that $n$ is continuously differentiable.

:::

## 10.2 Series — Definitions and Two Special Families

**Thomas 10.2 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Series as sums of sequences” — Khan Academy

“Geometric series | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition — From sequence to series]
A **series** is what you get when you try to add up all the terms of a sequence: $\sum_{n=1}^\infty a_n = a_1 + a_2 + a_3 + \cdots$. But you can't literally add infinitely many numbers — instead, you add the first $N$ terms, see what you get, and ask whether that running total stabilizes as $N\to\infty$.

The bridge from sequence to series is the *partial sum sequence*. You form a new sequence $S_1, S_2, S_3, \ldots$ where $S_N$ is the sum of the first $N$ terms. If *this* sequence converges, the series converges to the same limit. If the partial-sum sequence diverges, so does the series.

Think of it like a bank account: each $a_n$ is a deposit (or withdrawal). $S_N$ is your running balance after $N$ transactions. "The series converges" means your balance is approaching a fixed amount, not growing to infinity or oscillating wildly.
:::

:::definition[Definition 2.2 — Series and Convergence]
Given a sequence $\{a_n\}$, define the $N$-th **partial sum**:

$$
S_N = \sum_{n=1}^N a_n = a_1 + a_2 + \cdots + a_N.
$$

 The **infinite series** $\displaystyle\sum_{n=1}^\infty a_n$ **converges** to $S$ if $\displaystyle\lim_{N\to\infty} S_N = S$. In that case we write $\displaystyle\sum_{n=1}^\infty a_n = S$. If $\{S_N\}$ diverges, the series **diverges**.
:::

### The Geometric Series

The geometric series is the single most important series in the chapter. Not only does it have an exact closed-form sum, it also serves as the comparison benchmark for nearly every other convergence test, and it underlies all of power series theory.

:::theorem[Theorem 2.2 — Geometric Series]
The geometric series $\displaystyle\sum_{n=0}^\infty ar^n = a + ar + ar^2 + ar^3 + \cdots$ converges if and only if $|r| < 1$, and its sum is:

$$
\sum_{n=0}^\infty ar^n = \frac{a}{1-r}, \qquad |r|<1.
$$

 If $|r| \ge 1$ (and $a \ne 0$), the series diverges.
:::

:::proof[Why the formula works.]
Why the formula works.

The partial sum $S_N = a + ar + ar^2 + \cdots + ar^{N-1}$. Multiply both sides by $r$: $rS_N = ar + ar^2 + \cdots + ar^N$. Subtract: $S_N - rS_N = a - ar^N$, so $S_N(1-r) = a(1-r^N)$, giving $S_N = \dfrac{a(1-r^N)}{1-r}$. If $|r|<1$, then $r^N \to 0$ as $N\to\infty$, so $S_N \to \dfrac{a}{1-r}$.
:::

**Index shift warning.** The formula $a/(1-r)$ applies when the series starts at $n=0$. If your series starts at $n=1$ or another index, you need to adjust. The two cleanest approaches: (1) factor out powers of $r$ to reduce it to the $n=0$ case, or (2) write the full $n=0$ series and subtract the missing initial terms.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Geometric partial sums approach horizontal limit two">
<path class="fig-axis" d="M 20 155 L 380 155 M 45 20 L 45 205"/>
<path class="fig-point" d="M 45.0 155.0 l 0.1 0"/>
<path class="fig-point" d="M 78.0 115.0 l 0.1 0"/>
<path class="fig-point" d="M 111.0 95.0 l 0.1 0"/>
<path class="fig-point" d="M 144.0 85.0 l 0.1 0"/>
<path class="fig-point" d="M 177.0 80.0 l 0.1 0"/>
<path class="fig-point" d="M 210.0 77.5 l 0.1 0"/>
<path class="fig-point" d="M 243.0 76.2 l 0.1 0"/>
<path class="fig-point" d="M 276.0 75.6 l 0.1 0"/>
<path class="fig-point" d="M 309.0 75.3 l 0.1 0"/>
<path class="fig-point" d="M 342.0 75.2 l 0.1 0"/>
<path class="fig-point" d="M 375.0 75.1 l 0.1 0"/>
<path class="fig-guide" d="M 45 75 L 370 75"/>

</svg>
<figcaption>The partial sums $S_N=2(1-2^{-N})$ of $1+1/2+1/4+\cdots$ approach 2 even though infinitely many terms are added.</figcaption>
</figure>


:::example[🧠 Example 10.2.1 — Standard geometric]
Find the sum $\displaystyle\sum_{n=0}^\infty \frac{5}{4^n}$.

**Answer: $\dfrac{20}{3}$**

**Hand calculation.**
Rewrite as $\displaystyle\sum_{n=0}^\infty 5\cdot\left(\frac{1}{4}\right)^n$. This is geometric with $a = 5$ and $r = 1/4$. Since $|r| = 1/4 < 1$, the series converges:

$$
\sum_{n=0}^\infty 5\cdot\left(\frac{1}{4}\right)^n = \frac{5}{1 - 1/4} = \frac{5}{3/4} = \frac{20}{3}.
$$
:::

:::example[🧠 Example 10.2.2 — Shifted starting index]
Find $\displaystyle\sum_{n=3}^\infty \left(\frac{2}{5}\right)^n$.

**Answer: $\dfrac{8}{75}$**

Work — two methods

**Method 1 (factor out):** Factor out $(2/5)^3$ from every term so the exponent starts at $n=0$:

$$
\sum_{n=3}^\infty \left(\frac{2}{5}\right)^n = \left(\frac{2}{5}\right)^3 \sum_{n=0}^\infty \left(\frac{2}{5}\right)^n = \frac{8}{125}\cdot\frac{1}{1-2/5} = \frac{8}{125}\cdot\frac{5}{3} = \frac{8}{75}.
$$

**Method 2 (subtract missing terms):** The full series starting at $n=0$ has sum $\frac{1}{1-2/5} = \frac{5}{3}$. Subtract the $n=0,1,2$ terms:

$$
\frac{5}{3} - 1 - \frac{2}{5} - \frac{4}{25} = \frac{5}{3} - \frac{25+10+4}{25} = \frac{5}{3} - \frac{39}{25} = \frac{125-117}{75} = \frac{8}{75}.\checkmark
$$
:::

:::example[🧠 Example 10.2.3 — Repeating decimal as a geometric series]
Express $0.\overline{36} = 0.363636\ldots$ as a fraction.

**Answer: $\dfrac{4}{11}$**

**Hand calculation.**
Write the decimal as a sum: $0.\overline{36} = \frac{36}{100} + \frac{36}{100^2} + \frac{36}{100^3} + \cdots$. This is geometric with $a = 36/100$ and $r = 1/100$:

$$
0.\overline{36} = \frac{36/100}{1 - 1/100} = \frac{36/100}{99/100} = \frac{36}{99} = \frac{4}{11}.
$$
:::

### Telescoping Series

**Not on Test 4.** Enrichment only.

A telescoping series is one where writing out the partial sum causes massive cancellation — most of the middle terms cancel, leaving only the first and last. The name comes from an old-fashioned collapsible telescope: you push the segments into each other and they disappear. The technique always begins with **partial fraction decomposition** to expose the cancellation structure.

:::example[🧠 Example 10.2.4 — Standard telescoping]
Find $\displaystyle\sum_{n=1}^\infty \frac{1}{n(n+1)}$.

**Answer: $1$**

**Hand calculation.**
**Step 1 — Partial fractions.** Write $\dfrac{1}{n(n+1)} = \dfrac{1}{n} - \dfrac{1}{n+1}$. (Verify: $\dfrac{(n+1)-n}{n(n+1)} = \dfrac{1}{n(n+1)}$. ✓)

**Step 2 — Write out the partial sum and watch the cancellation.**

$$
\begin{aligned}
 S_N &= \left(\frac{1}{1} - \frac{1}{2}\right) + \left(\frac{1}{2} - \frac{1}{3}\right) + \left(\frac{1}{3} - \frac{1}{4}\right) + \cdots + \left(\frac{1}{N} - \frac{1}{N+1}\right)\\
 &= 1 - \frac{1}{N+1}.
 \end{aligned}
$$

**Step 3 — Take the limit.** $\displaystyle\lim_{N\to\infty}S_N = \lim_{N\to\infty}\left(1 - \frac{1}{N+1}\right) = 1 - 0 = 1$.
:::

:::example[🧠 Example 10.2.5 — Telescoping with a non-obvious decomposition]
Find $\displaystyle\sum_{n=1}^\infty \ln\!\left(\frac{n+1}{n}\right)$.

**Answer: Diverges.**

**Hand calculation.**
Use the logarithm property $\ln\!\left(\frac{n+1}{n}\right) = \ln(n+1) - \ln(n)$. The partial sum telescopes:

$$
S_N = [\ln 2 - \ln 1] + [\ln 3 - \ln 2] + \cdots + [\ln(N+1) - \ln N] = \ln(N+1).
$$

 As $N\to\infty$, $\ln(N+1)\to\infty$. The series diverges. This is a good reminder that "telescoping" doesn't automatically mean "converges."
:::

### The $n$-th Term Test for Divergence

This is always the first test to apply. It's fast and catches many divergent series immediately.

:::theorem[Theorem 2.3 — $n$-th Term Test (Divergence Test)]
If $\displaystyle\sum_{n=1}^\infty a_n$ converges, then $\displaystyle\lim_{n\to\infty}a_n = 0$. Equivalently (taking the contrapositive): if $\displaystyle\lim_{n\to\infty}a_n \ne 0$, or if the limit doesn't exist, then $\displaystyle\sum_{n=1}^\infty a_n$ **diverges**.
:::

:::proof[Proof sketch.]
Proof sketch.

If the series converges to $S$, then $S_N \to S$ and $S_{N-1} \to S$. But $a_N = S_N - S_{N-1} \to S - S = 0$.
:::

:::callout-pitfall[⚠ The Converse is FALSE — this is the #1 series error]
The $n$-th Term Test says: if terms don't go to 0, the series diverges. It does **NOT** say: if the terms go to 0, the series converges. The harmonic series $\displaystyle\sum_{n=1}^\infty \frac{1}{n}$ has $a_n = 1/n \to 0$, yet it diverges. This failure of the converse trips up almost every student at least once. The test can only prove divergence, never convergence.

When $a_n \to 0$, your only conclusion is "the test is inconclusive — try something else."
:::

### Why does the harmonic series diverge?

It's worth understanding this intuitively. Group the terms cleverly:

$$
1 + \underbrace{\frac{1}{2}}_{\ge\,1/2} + \underbrace{\frac{1}{3}+\frac{1}{4}}_{\ge\,1/2} + \underbrace{\frac{1}{5}+\frac{1}{6}+\frac{1}{7}+\frac{1}{8}}_{\ge\,1/2} + \cdots
$$

 Each group of $2^k$ consecutive terms sums to at least $1/2$. There are infinitely many such groups, so the total is at least $1/2 \cdot \infty = \infty$. The series diverges, even though the individual terms go to zero. The terms go to zero, but not fast *enough*.

::::problem[Problem 10.2.1 easy]{difficulty=easy}
Use the $n$-th Term Test on $\displaystyle\sum_{n=1}^\infty\frac{n}{2n+1}$.

:::solution[Solution]
**Answer:** Diverges by the nth-term test.

1. **Method: nth-term divergence test.** Before testing the sum, examine its individual summand $a_n=n/(2n+1)$. A necessary condition for $\sum a_n$ to converge is $a_n\to0$.

2. **Compute the term limit.** Divide the numerator and denominator by $n$, permissible for $n\ge1$:

   $$
   \lim_{n\to\infty}\frac{n}{2n+1}
   =\lim_{n\to\infty}\frac1{2+1/n}
   =\frac1{2+0}=\frac12.
   $$

3. **Check the test condition.** The term limit exists, but it is $1/2$, not zero. Therefore the necessary condition for series convergence fails.

4. **Conclusion.** The series $\displaystyle\sum_{n=1}^\infty n/(2n+1)$ diverges by the nth-term test. No other convergence test is needed.
:::
::::
::::problem[Problem 10.2.2 easy]{difficulty=easy}
Find the sum $\displaystyle\sum_{n=1}^\infty\frac{4}{3^n}$.

:::solution[Solution]
**Answer:** $2$

1. **Method: geometric series.** Write the summand as $4(1/3)^n$. The ratio of successive terms is $r=1/3$, and $|r|<1$, so the infinite geometric series converges.

2. **Account for the starting index.** Since the series starts at $n=1$, its first term is $4/3$, not $4$. The geometric sum formula uses the actual first term $a=4/3$:

   $$
   \sum_{n=1}^\infty\frac4{3^n}
   =\frac{4/3}{1-1/3}.
   $$

3. **Simplify the fractions by hand.** The denominator is $1-1/3=2/3$. Dividing fractions means multiplying by the reciprocal:

   $$
   \frac{4/3}{2/3}=\frac43\cdot\frac32=\frac42=2.
   $$

4. **Conclusion.** The series converges, and its exact sum is $2$.
:::
::::
::::problem[Problem 10.2.3 standard]{difficulty=standard}
Find the sum $\displaystyle\sum_{n=1}^\infty\frac{3}{n^2+5n+6}$.

:::solution[Solution]
**Answer:** $1$

1. **Method: telescoping by partial fractions.** Factor the quadratic: $n^2+5n+6=(n+2)(n+3)$. Seek constants $A,B$ with

   $$
   \frac3{(n+2)(n+3)}=\frac A{n+2}+\frac B{n+3}.
   $$

   Multiplying out gives $3=A(n+3)+B(n+2)$. Substituting $n=-2$ gives $A=3$; substituting $n=-3$ gives $B=-3$.

2. **Expand the partial sum.**

   $$
   S_N=\sum_{n=1}^N\left(\frac3{n+2}-\frac3{n+3}\right)
   =\left(\frac33-\frac34\right)+\left(\frac34-\frac35\right)
   +\cdots+\left(\frac3{N+2}-\frac3{N+3}\right).
   $$

   All interior terms cancel, leaving $S_N=1-3/(N+3)$.

3. **Take the limit.** Since $3/(N+3)\to0$, $S_N\to1$.

4. **Conclusion.** The telescoping series converges to the exact sum $1$.
:::
::::
::::problem[Problem 10.2.4 standard]{difficulty=standard}
Write $2.\overline{153} = 2.153153153\ldots$ as a fraction.

:::solution[Solution]
**Answer:** $239/111$

1. **Method: convert a repeating decimal to a geometric series.** Split off the whole-number part: $2.\overline{153}=2+0.\overline{153}$. One repetition contributes $153/1000$, and each subsequent block is $1/1000$ of the previous one.

2. **Write and sum the geometric series.** Here $a=153/1000$ and $r=1/1000$; since $|r|<1$,

   $$
   0.\overline{153}=\frac{153}{1000}+\frac{153}{1000^2}+\cdots
   =\frac{153/1000}{1-1/1000}
   =\frac{153}{999}.
   $$

3. **Reduce and restore the integer.** Divide numerator and denominator by $9$ to obtain $153/999=17/111$. Then

   $$
   2+\frac{17}{111}=\frac{222}{111}+\frac{17}{111}=\frac{239}{111}.
   $$

4. **Conclusion.** The exact fraction for $2.\overline{153}$ is $239/111$.
:::
::::
::::problem[Problem 10.2.5 challenge]{difficulty=challenge}
For what values of $x$ does $\displaystyle\sum_{n=0}^\infty(2x-1)^n$ converge, and what is the sum?

:::solution[Solution]
**Answer:** Converges for $0< x<1$; sum $1/[2(1-x)]$.

1. **Method: geometric series with an $x$-dependent ratio.** The first term is $(2x-1)^0=1$ and the common ratio is $r=2x-1$. Such a series converges exactly when $|r|<1$.

2. **Solve the convergence inequality.**

   $$
   |2x-1|<1\iff-1<2x-1<1
   \iff0<2x<2\iff0< x<1.
   $$

   At $x=0$, $r=-1$ and terms oscillate; at $x=1$, $r=1$ and terms equal one. Neither endpoint converges.

3. **Compute the sum inside the interval.** Because $|r|<1$ there,

   $$
   S=\frac1{1-r}=\frac1{1-(2x-1)}
   =\frac1{2-2x}=\frac1{2(1-x)}.
   $$

4. **Conclusion.** The series converges only for $0< x<1$, with the stated sum.
:::
::::

### Test 4 workshop: two geometric series in one expression

Young’s review asks for $\sum_{n=1}^\infty(4^n+7^n)/9^n$. There is no need to invent a new test for the sum. Distribute the denominator, use the sum law for convergent series, and apply the $n=1$ version of the geometric formula to **each** piece. If a series begins at $n=1$, its first term is $r$, not $1$. Equivalently, $\sum_{n=1}^\infty r^n=r/(1-r)$ for $|r|<1$.

The other favorite is the nth-term test. Before doing algebra, examine $\lim_{n\to\infty}a_n$. A nonzero limit or a nonexistent limit proves divergence. **A zero limit says nothing either way.** The two series $\sum 1/n$ and $\sum 1/n^2$ both have terms approaching zero, yet only the second converges. That single counterexample is why the nth-term test cannot prove convergence.

### Finite geometric sums and why the infinite formula works

When $r\ne1$, multiply $S_N=a+ar+\cdots+ar^{N-1}$ by $r$ and subtract. Every interior term cancels; $(1-r)S_N=a-ar^N$. Dividing gives $S_N=a(1-r^N)/(1-r)$. For $|r|<1$ the remainder $r^N$ vanishes; for $r=1$ the partial sum is $Na$; for $r=-1$ nonzero partial sums oscillate. These last two cases explain the strict inequality $|r|<1$, not $|r|\le1$.

:::example[Example 10.2.6 — Sum of two geometric series]
Find the exact sum $\displaystyle\sum_{n=1}^{\infty}\frac{4^n+7^n}{9^n}$.

**Answer: $\frac{43}{10}$.**


Separate the terms before using a formula:

$$\sum_{n=1}^{\infty}\left(\frac49\right)^n+\sum_{n=1}^{\infty}\left(\frac79\right)^n.$$

For the first series, $r_1=4/9$ and $a_1=4/9$. For the second, $r_2=7/9$ and $a_2=7/9$. Both absolute ratios are less than 1, so both converge:

$$
\frac{4/9}{1-4/9}+\frac{7/9}{1-7/9}
=\frac{4/9}{5/9}+\frac{7/9}{2/9}
=\frac45+\frac72=\frac{8+35}{10}=\frac{43}{10}.
$$
The displayed positive sum makes sense: the first term alone is $11/9$ and all remaining terms are positive, so the answer must exceed $11/9$.

:::

:::example[Example 10.2.7 — Nth-term divergence]
Apply the nth-term test to $\displaystyle\sum_{n=1}^\infty\cos\!\left(\frac4n\right)$.

**Answer: $\text{Diverges.}$**


Let $a_n=\cos(4/n)$. Since $4/n\to0$ and cosine is continuous,

$$\lim_{n\to\infty}a_n=\cos 0=1\ne0.$$

Therefore the **nth-term test for divergence** proves the series diverges. Note that this is not the sum $\sum 4/n$ and not the sequence limit question; we evaluated a single term to infer the behavior of its infinite series.

:::

::::problem[Problem 10.2.6 — Two ratios]{difficulty=standard}
Find $\sum_{n=1}^\infty\frac{2^n+5^n}{8^n}$ exactly. State why splitting is valid.

:::solution[Solution]
**Answer:** $2$; both pieces converge geometrically.

1. **Method: split into two geometric series.** Divide each numerator term by $8^n$:

   $$
   \sum_{n=1}^\infty\frac{2^n+5^n}{8^n}
   =\sum_{n=1}^\infty\left(\frac14\right)^n
   +\sum_{n=1}^\infty\left(\frac58\right)^n.
   $$

2. **Check that splitting is valid.** Both absolute ratios satisfy $1/4<1$ and $5/8<1$, so each geometric series converges. The sum law for convergent series therefore permits adding their sums.

3. **Use the $n=1$ geometric formula.** For $|r|<1$, $\sum_{n=1}^\infty r^n=r/(1-r)$. Thus

   $$
   S=\frac{1/4}{1-1/4}+\frac{5/8}{1-5/8}
   =\frac{1/4}{3/4}+\frac{5/8}{3/8}
   =\frac13+\frac53=\frac63=2.
   $$

4. **Conclusion.** The original series converges absolutely and has exact sum $2$.
:::
::::

### Exam reasoning: the series is not its summand

Young’s nth-term divergence questions are deliberately simple-looking. Do not turn them into an Integral Test problem. A series $\sum a_n$ can converge only if $a_n\to0$. That is a **necessary** condition, never a sufficient one. For instance, $\cos(4/n)\to\cos 0=1$, so $\sum\cos(4/n)$ diverges immediately. There is no need to calculate even one partial sum. In contrast, $1/n\to0$ but $\sum1/n$ diverges. The zero limit merely clears the first obstruction; it does not finish the convergence problem.

A geometric series is a different kind of question: here a complete sum is possible because the ratio is fixed. Suppose the index starts at $n=3$ rather than $n=0$. The first term is $ar^3$, so the sum is $ar^3/(1-r)$ when $|r|<1$. The expression $a/(1-r)$ assumes that $a$ denotes the **actual first term**, not the coefficient in a formula that begins several indices later. To keep the two meanings separate, write the first two terms before applying the formula.

The most reliable split for a numerator containing two exponentials is

$$
\sum_{n=1}^{\infty}\frac{A^n+B^n}{C^n}
=\sum_{n=1}^{\infty}\left(\frac AC\right)^n
+\sum_{n=1}^{\infty}\left(\frac BC\right)^n.
$$

Both ratios must have absolute value below one for this sum-of-two-geometric calculation to be valid. If one ratio has magnitude at least one, the term test or nonconvergent geometric behavior must be addressed first. Write the two separate $r$ values and two separate sums before combining fractions. This demonstrates *why* the series converges and where the final fraction came from, exactly the distinction between a bare answer and a complete written solution.

**Paper check.** After finding a geometric sum with positive terms, compare it to the first two terms: your total must be larger than their sum. If your computation gives less, you probably began the formula at $n=0$ when the problem started at $n=1$. For alternating geometric terms, use the exact algebraic identity instead of that positivity check.


## 10.3 The Integral Test and $p$-Series

**Thomas 10.3 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Integral test for convergence” — Khan Academy
:::

:::callout-intuition[Intuition — connecting sums and integrals]
Suppose $f$ is a positive, decreasing function with $f(n) = a_n$. Draw the graph of $f$ and draw rectangles of width 1 with heights $a_1, a_2, a_3, \ldots$. The series $\sum a_n$ is the total area of all those rectangles. The improper integral $\int_1^\infty f(x)\,dx$ is the area under the curve. Because $f$ is positive and decreasing, the rectangles and the curve are locked in a tight embrace — they can't diverge without each other.

More precisely: you can shift the rectangles to show that the integral is sandwiched between consecutive partial sums of the series. If the integral is finite, the series is squeezed into a finite range; if the integral blows up, so does the series. This is the Integral Test.

The immediate payoff is the $p$-series result — a clean rule that tells you instantly whether $\sum 1/n^p$ converges, based solely on whether you're integrating $1/x^p$ over $[1,\infty)$.
:::

:::theorem[Theorem 2.4 — Integral Test]
Suppose $f$ is a function that is *continuous*, *positive*, and *decreasing* on $[1,\infty)$, with $f(n) = a_n$. Then:

$$
\sum_{n=1}^\infty a_n \text{ converges} \iff \int_1^\infty f(x)\,dx \text{ converges}.
$$

 Note: the test tells you whether the series converges or diverges. The value of the integral is **not** equal to the sum of the series.
:::

:::callout-warning[⚠ Check All Three Hypotheses]
The function must be (1) **continuous**, (2) **positive**, and (3) **decreasing** on $[1,\infty)$. If any one of these fails, the Integral Test cannot be used — not "gives an inconclusive result," but literally does not apply. For (3), it's sufficient for $f$ to be eventually decreasing (decreasing for all $x$ beyond some point). You can verify (3) by showing $f'(x) < 0$ on $[1,\infty)$, or by noting that it's a decreasing function by inspection.
:::

### The $p$-Series

:::theorem[Theorem 2.5 — $p$-Series Test]
$$
\sum_{n=1}^\infty \frac{1}{n^p} \;\begin{cases}\text{converges} & \text{if } p > 1 \\ \text{diverges} & \text{if } p \le 1.\end{cases}
$$
:::

:::proof[Proof via the Integral Test.]
Proof via the Integral Test.

For $p \ne 1$: $\displaystyle\int_1^\infty x^{-p}\,dx = \left[\frac{x^{-p+1}}{-p+1}\right]_1^\infty$. If $p > 1$, then $-p+1 < 0$, so $x^{-p+1}\to 0$ as $x\to\infty$, and the integral equals $\frac{1}{p-1}$ — finite. If $p < 1$, then $-p+1 > 0$, so $x^{-p+1}\to\infty$, and the integral diverges. For $p=1$: $\int_1^\infty \frac{dx}{x} = [\ln x]_1^\infty = \infty$ — diverges.
:::

You must know the $p$-series test cold. It is the most-used comparison benchmark in the course — every Limit Comparison Test problem ultimately compares against a $p$-series.

| Series | $p$ | Result |
| --- | --- | --- |
| $\sum 1/n$ | $1$ | Diverges (harmonic series) |
| $\sum 1/\sqrt{n}$ | $1/2$ | Diverges ($p \le 1$) |
| $\sum 1/n^2$ | $2$ | Converges ($p > 1$) |
| $\sum 1/n^{1.001}$ | $1.001$ | Converges (barely!) |
| $\sum 1/n^{0.999}$ | $0.999$ | Diverges (barely!) |

### Remainder Estimation with the Integral Test

**Not on Test 4.** The integral convergence check is assessed, not the remainder bounds.

A bonus from the Integral Test: if you use $S_N$ to approximate $S = \sum a_n$, the error (remainder) $R_N = S - S_N$ satisfies:

$$
\int_{N+1}^\infty f(x)\,dx \;\le\; R_N \;\le\; \int_N^\infty f(x)\,dx.
$$

 This gives both a lower and upper bound on how much you're missing by stopping after $N$ terms.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Integral test curve with decreasing rectangles">
<path class="fig-axis" d="M 20 155 L 380 155 M 45 20 L 45 205"/>
<path class="fig-curve" d="M50.0 109.0 L51.0 110.4 L51.9 111.7 L52.9 113.0 L53.9 114.2 L54.8 115.4 L55.8 116.5 L56.7 117.5 L57.7 118.5 L58.7 119.5 L59.6 120.4 L60.6 121.2 L61.6 122.1 L62.5 122.9 L63.5 123.6 L64.5 124.4 L65.4 125.1 L66.4 125.8 L67.4 126.4 L68.3 127.0 L69.3 127.6 L70.2 128.2 L71.2 128.8 L72.2 129.3 L73.1 129.9 L74.1 130.4 L75.1 130.8 L76.0 131.3 L77.0 131.8 L78.0 132.2 L78.9 132.6 L79.9 133.0 L80.9 133.4 L81.8 133.8 L82.8 134.2 L83.8 134.6 L84.7 134.9 L85.7 135.3 L86.6 135.6 L87.6 135.9 L88.6 136.2 L89.5 136.5 L90.5 136.8 L91.5 137.1 L92.4 137.4 L93.4 137.7 L94.4 137.9 L95.3 138.2 L96.3 138.4 L97.2 138.7 L98.2 138.9 L99.2 139.1 L100.1 139.4 L101.1 139.6 L102.1 139.8 L103.0 140.0 L104.0 140.2 L105.0 140.4 L105.9 140.6 L106.9 140.8 L107.9 141.0 L108.8 141.2 L109.8 141.3 L110.8 141.5 L111.7 141.7 L112.7 141.8 L113.6 142.0 L114.6 142.2 L115.6 142.3 L116.5 142.5 L117.5 142.6 L118.5 142.8 L119.4 142.9 L120.4 143.0 L121.4 143.2 L122.3 143.3 L123.3 143.4 L124.2 143.6 L125.2 143.7 L126.2 143.8 L127.1 143.9 L128.1 144.1 L129.1 144.2 L130.0 144.3 L131.0 144.4 L132.0 144.5 L132.9 144.6 L133.9 144.7 L134.9 144.8 L135.8 144.9 L136.8 145.0 L137.8 145.1 L138.7 145.2 L139.7 145.3 L140.6 145.4 L141.6 145.5 L142.6 145.6 L143.5 145.7 L144.5 145.8 L145.5 145.8 L146.4 145.9 L147.4 146.0 L148.4 146.1 L149.3 146.2 L150.3 146.2 L151.2 146.3 L152.2 146.4 L153.2 146.5 L154.1 146.5 L155.1 146.6 L156.1 146.7 L157.0 146.8 L158.0 146.8 L159.0 146.9 L159.9 147.0 L160.9 147.0 L161.9 147.1 L162.8 147.1 L163.8 147.2 L164.8 147.3 L165.7 147.3 L166.7 147.4 L167.6 147.5 L168.6 147.5 L169.6 147.6 L170.5 147.6 L171.5 147.7 L172.5 147.7 L173.4 147.8 L174.4 147.8 L175.4 147.9 L176.3 147.9 L177.3 148.0 L178.2 148.0 L179.2 148.1 L180.2 148.1 L181.1 148.2 L182.1 148.2 L183.1 148.3 L184.0 148.3 L185.0 148.4 L186.0 148.4 L186.9 148.5 L187.9 148.5 L188.9 148.6 L189.8 148.6 L190.8 148.6 L191.8 148.7 L192.7 148.7 L193.7 148.8 L194.6 148.8 L195.6 148.8 L196.6 148.9 L197.5 148.9 L198.5 149.0 L199.5 149.0 L200.4 149.0 L201.4 149.1 L202.4 149.1 L203.3 149.1 L204.3 149.2 L205.2 149.2 L206.2 149.2 L207.2 149.3 L208.1 149.3 L209.1 149.3 L210.1 149.4 L211.0 149.4 L212.0 149.4 L213.0 149.5 L213.9 149.5 L214.9 149.5 L215.9 149.6 L216.8 149.6 L217.8 149.6 L218.8 149.7 L219.7 149.7 L220.7 149.7 L221.6 149.7 L222.6 149.8 L223.6 149.8 L224.5 149.8 L225.5 149.9 L226.5 149.9 L227.4 149.9 L228.4 149.9 L229.4 150.0 L230.3 150.0 L231.3 150.0 L232.2 150.0 L233.2 150.1 L234.2 150.1 L235.1 150.1 L236.1 150.1 L237.1 150.2 L238.0 150.2 L239.0 150.2 L240.0 150.2 L240.9 150.3 L241.9 150.3 L242.9 150.3 L243.8 150.3 L244.8 150.3 L245.7 150.4 L246.7 150.4 L247.7 150.4 L248.6 150.4 L249.6 150.4 L250.6 150.5 L251.5 150.5 L252.5 150.5 L253.5 150.5 L254.4 150.6 L255.4 150.6 L256.4 150.6 L257.3 150.6 L258.3 150.6 L259.2 150.6 L260.2 150.7 L261.2 150.7 L262.1 150.7 L263.1 150.7 L264.1 150.7 L265.0 150.8 L266.0 150.8 L267.0 150.8 L267.9 150.8 L268.9 150.8 L269.9 150.8 L270.8 150.9 L271.8 150.9 L272.8 150.9 L273.7 150.9 L274.7 150.9 L275.6 150.9 L276.6 151.0 L277.6 151.0 L278.5 151.0 L279.5 151.0 L280.5 151.0 L281.4 151.0 L282.4 151.1 L283.4 151.1 L284.3 151.1 L285.3 151.1 L286.2 151.1 L287.2 151.1 L288.2 151.1 L289.1 151.2 L290.1 151.2 L291.1 151.2 L292.0 151.2 L293.0 151.2 L294.0 151.2 L294.9 151.2 L295.9 151.3 L296.9 151.3 L297.8 151.3 L298.8 151.3 L299.8 151.3 L300.7 151.3 L301.7 151.3 L302.6 151.4 L303.6 151.4 L304.6 151.4 L305.5 151.4 L306.5 151.4 L307.5 151.4 L308.4 151.4 L309.4 151.4 L310.4 151.5 L311.3 151.5 L312.3 151.5 L313.2 151.5 L314.2 151.5 L315.2 151.5 L316.1 151.5 L317.1 151.5 L318.1 151.5 L319.0 151.6 L320.0 151.6"/>
<path class="fig-guide" d="M 50 154 L 50 109.0"/>
<path class="fig-guide" d="M 95 154 L 95 138.1"/>
<path class="fig-guide" d="M 140 154 L 140 145.3"/>
<path class="fig-guide" d="M 185 154 L 185 148.4"/>
<path class="fig-guide" d="M 230 154 L 230 150.0"/>
<path class="fig-guide" d="M 275 154 L 275 150.9"/>

</svg>
<figcaption>For positive decreasing $f(x)=x^{-3/2}$, rectangles and the area under the curve are comparable; both tails converge.</figcaption>
</figure>


:::example[🧠 Example 10.3.1 — Applying the Integral Test]
Test $\displaystyle\sum_{n=1}^\infty \frac{1}{n^2+4}$ for convergence.

**Answer: Converges.**

**Hand calculation.**
Let $f(x) = \dfrac{1}{x^2+4}$. Check hypotheses: (1) continuous on $[1,\infty)$ ✓; (2) positive ✓; (3) $f'(x) = \dfrac{-2x}{(x^2+4)^2} < 0$ for $x > 0$, so decreasing ✓.

Evaluate the improper integral (this is a standard arctangent form $\int \frac{dx}{x^2+a^2} = \frac{1}{a}\arctan(x/a)+C$):

$$
\int_1^\infty \frac{dx}{x^2+4} = \frac{1}{2}\Big[\arctan\!\left(\frac{x}{2}\right)\Big]_1^\infty = \frac{1}{2}\left(\frac{\pi}{2} - \arctan\!\frac{1}{2}\right) \approx \frac{1}{2}(1.571 - 0.464) \approx 0.554.
$$

 The integral converges, so the series converges.
:::

:::example[🧠 Example 10.3.2 — $p$-series recognition]
Classify each series as convergent or divergent: (a) $\displaystyle\sum_{n=1}^\infty\frac{1}{n^{3/2}}$, (b) $\displaystyle\sum_{n=1}^\infty\frac{1}{\sqrt[3]{n}}$, (c) $\displaystyle\sum_{n=1}^\infty\frac{5}{n^2}$.

**Answer: (a) Converges. (b) Diverges. (c) Converges.**

**Hand calculation.**
(a) $p = 3/2 > 1$ → converges. (b) $p = 1/3 < 1$ → diverges. (c) The constant 5 doesn't affect convergence: $\sum 5/n^2 = 5\sum 1/n^2$. Since $p=2 > 1$, converges.
:::

:::example[🧠 Example 10.3.3 — Integral Test with substitution]
Test $\displaystyle\sum_{n=1}^\infty ne^{-n^2}$.

**Answer: Converges.**

**Hand calculation.**
Let $f(x) = xe^{-x^2}$. (1) Continuous ✓. (2) Positive for $x > 0$ ✓. (3) $f'(x) = e^{-x^2}(1-2x^2) < 0$ for $x > 1/\sqrt{2}$, so eventually decreasing ✓.

Evaluate with substitution $u = x^2$, $du = 2x\,dx$:

$$
\int_1^\infty xe^{-x^2}\,dx = \frac{1}{2}\int_1^\infty e^{-u}\,du = \frac{1}{2}\Big[-e^{-u}\Big]_1^\infty = \frac{1}{2}\cdot e^{-1} = \frac{1}{2e}.
$$

 Finite → series converges.
:::

::::problem[Problem 10.3.1 easy]{difficulty=easy}
Does $\displaystyle\sum_{n=1}^\infty\frac{1}{n^{4/3}}$ converge?

:::solution[Solution]
**Answer:** Converges (p-series).

1. **Method: $p$-series test.** The expression is already in the standard form $\sum_{n=1}^\infty 1/n^p$, so no algebraic rearrangement or Integral Test calculation is necessary.

2. **Identify the exponent.** Compare $1/n^{4/3}$ with $1/n^p$: the power is $p=4/3$.

3. **Check the criterion.** A $p$-series with positive terms converges exactly when $p>1$ and diverges when $p\le1$. Here $4/3>3/3=1$, so the convergence condition holds.

4. **Conclusion.** $\displaystyle\sum_{n=1}^\infty1/n^{4/3}$ converges by the $p$-series test. The test classifies convergence; it does not supply an elementary closed-form sum.
:::
::::
::::problem[Problem 10.3.2 easy]{difficulty=easy}
Does $\displaystyle\sum_{n=1}^\infty\frac{3}{\sqrt{n}}$ converge?

:::solution[Solution]
**Answer:** Diverges (p-series).

1. **Method: constant multiple of a $p$-series.** Rewrite the summand using $\sqrt n=n^{1/2}$:

   $$
   \sum_{n=1}^\infty\frac3{\sqrt n}
   =3\sum_{n=1}^\infty\frac1{n^{1/2}}.
   $$

2. **Identify and check the exponent.** This is a positive-term $p$-series with $p=1/2$. The convergence rule requires $p>1$, but $1/2<1$, so the underlying $p$-series diverges.

3. **Check the constant factor.** Multiplication by the nonzero finite constant $3$ cannot turn divergent partial sums into convergent ones. In fact, if $T_N=\sum_{n=1}^N n^{-1/2}$ tends to infinity, then $3T_N$ does too.

4. **Conclusion.** The given series diverges by the $p$-series test.
:::
::::
::::problem[Problem 10.3.3 standard]{difficulty=standard}
Use the Integral Test on $\displaystyle\sum_{n=2}^\infty\frac{1}{n\ln n}$.

:::solution[Solution]
**Answer:** Diverges (Integral Test).

1. **Method: Integral Test.** Set $f(x)=1/(x\ln x)$ for $x\ge2$, so $f(n)$ equals the summand. On $[2,\infty)$, $x>1$ and $\ln x>0$, making $f$ positive and continuous.

2. **Check decreasing behavior.** Differentiate:

   $$
   f'(x)=-\frac{\ln x+1}{x^2(\ln x)^2}<0\qquad(x\ge2).
   $$

   Thus all Integral Test hypotheses hold.

3. **Evaluate the improper integral.** With $u=\ln x$ and $du=dx/x$,

   $$
   \int_2^b\frac{dx}{x\ln x}
   =\int_{\ln2}^{\ln b}\frac{du}{u}
   =\ln(\ln b)-\ln(\ln2).
   $$

   As $b\to\infty$, $\ln(\ln b)\to+\infty$.

4. **Conclusion.** The integral diverges, so $\sum_{n=2}^\infty1/(n\ln n)$ diverges by the Integral Test.
:::
::::
::::problem[Problem 10.3.4 standard]{difficulty=standard}
For what values of $p$ does $\displaystyle\sum_{n=2}^\infty\frac{1}{n(\ln n)^p}$ converge?

:::solution[Solution]
**Answer:** Converges exactly when $p>1$.

1. **Method: Integral Test with a parameter.** Let $f(x)=1/[x(\ln x)^p]$ for $x\ge2$. Since $x>1$, $\ln x>0$; $f$ is positive and continuous for every real $p$.

2. **Check decreasing behavior eventually.** Logarithmic differentiation gives

   $$
   \frac{f'(x)}{f(x)}=-\frac1x-\frac{p}{x\ln x}=-\frac{\ln x+p}{x\ln x}.
   $$

   For sufficiently large $x$, $\ln x+p>0$, so $f'(x)<0$. Removing finitely many initial terms does not change convergence.

3. **Evaluate the improper integral.** Substitute $u=\ln x$, $du=dx/x$:

   $$
   \int_2^\infty\frac{dx}{x(\ln x)^p}
   =\int_{\ln2}^\infty u^{-p}\,du.
   $$

   If $p\ne1$, the antiderivative is $u^{1-p}/(1-p)$, which has a finite upper limit precisely when $1-p<0$, or $p>1$. If $p=1$, the antiderivative is $\ln u\to\infty$.

4. **Conclusion.** The series converges for $p>1$ and diverges for $p\le1$.
:::
::::
::::problem[Problem 10.3.5 challenge]{difficulty=challenge}
Use the remainder estimate to find how many terms of $\displaystyle\sum_{n=1}^\infty\frac{1}{n^2}$ are needed so that the partial sum is within 0.01 of $\pi^2/6$.

:::solution[Solution]
**Answer:** 100 terms suffice (and 100 is the least number guaranteed by the integral bounds).

1. **Method: Integral Test remainder estimate.** For $f(x)=1/x^2$, $f$ is positive, continuous, and strictly decreasing for $x\ge1$, since $f'(x)=-2/x^3<0$. Hence the tail $R_N=\sum_{n=N+1}^\infty1/n^2$ satisfies the strict upper estimate

   $$
   R_N<\int_N^\infty\frac{dx}{x^2}.
   $$

2. **Evaluate the integral.**

   $$
   \int_N^\infty x^{-2}\,dx
   =\lim_{b\to\infty}\left[-\frac1x\right]_N^b
   =\lim_{b\to\infty}\left(-\frac1b+\frac1N\right)=\frac1N.
   $$

3. **Choose $N$ for the requested accuracy.** At $N=100$, the strict estimate gives $R_{100}<1/100=0.01$. For $N=99$, the lower estimate gives $R_{99}>\int_{100}^\infty x^{-2}\,dx=0.01$.

4. **Conclusion.** Summing through $n=100$ guarantees an error strictly below $0.01$; 99 terms do not suffice.
:::
::::

### The three Integral Test hypotheses, in the order to write them

For $\sum_{n=N}^\infty f(n)$, write: (1) $f$ is **positive** on the relevant tail; (2) $f$ is **continuous** there; (3) $f$ is **decreasing** there. Then evaluate $\int_N^\infty f(x)\,dx$ as an improper integral, with a finite upper cutoff $b$ and a displayed $b\to\infty$ limit. The series and integral have the **same convergence status**, not generally the same numerical sum.

If $f$ initially rises, the Integral Test can still work: replace the starting point by a sufficiently large integer where it becomes decreasing. Adding or deleting finitely many terms never changes whether an infinite series converges. This is especially important for $f(x)=5x/(x^2+9)$, which increases on $(0,3)$ and decreases when $x>3$. A claim that it decreases from $x=1$ is false, even though the divergence conclusion is correct.

The $p$-series criterion is a shortcut derived from the same integral. For $p\ne1$, $\int_1^b x^{-p}\,dx=(b^{1-p}-1)/(1-p)$. If $p>1$, then $1-p<0$, hence $b^{1-p}\to0$. If $p<1$, the power $b^{1-p}$ grows without bound. At $p=1$, the antiderivative is $\ln b$, which also grows without bound. Do not confuse $\sum 1/n^p$ with $\sum 1/(n^p+7)$; the latter may be handled with comparison.

:::callout-tip[Integral-Test written-work checklist]
Show $f(x)$, its tail interval, and either a derivative sign or a clear monotone-factor argument. Set up $\lim_{b\to\infty}\int_N^b f(x)\,dx$. If using a substitution, transform both bounds before evaluating. End with the named theorem and the word “converges” or “diverges.”
:::

:::example[Example 10.3.4 — Logarithmic u-sub with full hypotheses]
Test $\displaystyle\sum_{k=4}^\infty\frac{6}{k(\ln k)^2}$.

**Answer: $\text{Converges}$; the corresponding improper integral is $\frac6{\ln4}$.**


Let $f(x)=6/[x(\ln x)^2]$ for $x\ge4$. Positivity is clear. Continuity follows because $x>0$ and $\ln x\ne0$. Both $x$ and $(\ln x)^2$ increase for $x>1$, so $f$ decreases; to verify by differentiation,

$$f'(x)=-\frac{6(\ln x+2)}{x^2(\ln x)^3}<0\quad(x\ge4).$$

For the improper integral, set $u=\ln x$ and $du=dx/x$. At $x=4$, $u=\ln4$; as $x\to\infty$, $u\to\infty$:

$$
\begin{aligned}
\int_4^\infty\frac6{x(\ln x)^2}\,dx
&=\int_{\ln4}^\infty6u^{-2}\,du\\
&=\lim_{B\to\infty}[-6u^{-1}]_{\ln4}^{B}\\
&=\lim_{B\to\infty}\left(-\frac6B+\frac6{\ln4}\right)
=\frac6{\ln4}.
\end{aligned}
$$
The integral is finite. **Integral Test:** the original series converges. The number $6/\ln4$ is the integral, **not** the exact series sum.

:::

:::example[Example 10.3.5 — Integral Test with an initially increasing term]
Test $\displaystyle\sum_{n=1}^\infty\frac{5n}{n^2+9}$.

**Answer: $\text{Diverges}$.**


Take $f(x)=5x/(x^2+9)$. It is positive and continuous for $x\ge1$. Its derivative is

$$
f'(x)=\frac{5(x^2+9)-5x(2x)}{(x^2+9)^2}
=\frac{5(9-x^2)}{(x^2+9)^2}.
$$
For $x>3$, $9-x^2<0$, so $f$ decreases on $[4,\infty)$. We may discard the first three terms when testing convergence. Set $u=x^2+9$, $du=2x\,dx$:

$$
\begin{aligned}
\int_4^b\frac{5x}{x^2+9}\,dx
&=\frac52\int_{25}^{b^2+9}\frac{du}{u}\\
&=\frac52[\ln u]_{25}^{b^2+9}\\
&=\frac52\bigl(\ln(b^2+9)-\ln25\bigr)\to\infty.
\end{aligned}
$$
By the Integral Test on the tail, the tail diverges; therefore the full series diverges. This argument is still valid despite the original function increasing on $[1,3]$.

:::

:::example[Example 10.3.6 — Arctan antiderivative]
Use the Integral Test to determine the status of $\displaystyle\sum_{n=1}^\infty\frac7{n^2+81}$.

**Answer: $\text{Converges}$; the integral equals $\frac{7\pi}{18}-\frac79\arctan(1/9)$.**


For $x\ge1$, $f(x)=7/(x^2+81)$ is positive, continuous, and decreasing because

$$f'(x)=-\frac{14x}{(x^2+81)^2}<0.$$

Use the memorized antiderivative $\int dx/(x^2+a^2)=(1/a)\arctan(x/a)+C$ with $a=9$:

$$
\begin{aligned}
\int_1^b\frac7{x^2+81}\,dx
&=\left[\frac79\arctan\!\left(\frac x9\right)\right]_1^b\\
&=\frac79\arctan(b/9)-\frac79\arctan(1/9).
\end{aligned}
$$
As $b\to\infty$, $\arctan(b/9)\to\pi/2$, so the integral is finite and equals $7\pi/18-(7/9)\arctan(1/9)$. Hence the series **converges** by the Integral Test.

:::

::::problem[Problem 10.3.6 — Borderline logarithm]{difficulty=standard}
Test $\sum_{n=3}^\infty\frac4{n\ln n}$ using an improper integral. Check hypotheses.

:::solution[Solution]
**Answer:** $\text{Diverges}$.

1. **Method: Integral Test.** Take $f(x)=4/(x\ln x)$ on $[3,\infty)$. There $x>1$, so $x\ln x>0$. Therefore $f$ is continuous and positive.

2. **Check that $f$ decreases.** Differentiate using the chain and product rules:

   $$
   f'(x)=-\frac{4(\ln x+1)}{x^2(\ln x)^2}<0\qquad(x\ge3).
   $$

   All three Integral Test hypotheses hold.

3. **Integrate with a substitution.** Put $u=\ln x$ and $du=dx/x$:

   $$
   \int_3^b\frac4{x\ln x}\,dx
   =4\int_{\ln3}^{\ln b}\frac{du}{u}
   =4\left[\ln u\right]_{\ln3}^{\ln b}
   =4\bigl(\ln(\ln b)-\ln(\ln3)\bigr).
   $$

4. **Take the improper limit.** As $b\to\infty$, $\ln(\ln b)\to\infty$, so the integral diverges.

5. **Conclusion.** By the Integral Test, $\sum_{n=3}^\infty4/(n\ln n)$ diverges.
:::
::::

### Checking decreasing behavior without guessing

The Integral Test needs a function $f$ that is **positive, continuous, and decreasing** on the interval beginning at some integer $N$. “It looks like it decreases” is not proof. Positivity and continuity often follow from a positive denominator; for decreasing behavior, calculate $f'(x)$ and show it is nonpositive. You need the conditions eventually, not necessarily from the first printed index, because removing finitely many terms never changes whether an infinite series converges.

For a typical rational example $f(x)=5x/(x^2+9)$, the denominator is always positive and $f$ is positive for $x>0$. Use the quotient rule rather than asserting the derivative’s sign:

$$
\begin{aligned}
f'(x)&=\frac{5(x^2+9)-5x(2x)}{(x^2+9)^2}\\
&=\frac{45-5x^2}{(x^2+9)^2}.
\end{aligned}
$$

This derivative is negative when $x>3$, so you may apply the test from $N=4$, even if the displayed series begins at $n=1$. To decide convergence, substitute $u=x^2+9$, giving $du=2x\,dx$. The improper integral becomes a constant times $\ln(x^2+9)$ at the upper limit, so it diverges. Notice the division of labor: the derivative checks the *eligibility* of the test; the improper integral supplies the *verdict*.

For $f(x)=6/[x(\ln x)^2]$ on $x\ge4$, positivity and continuity are immediate because $\ln x>0$. The denominator $x(\ln x)^2$ strictly increases; therefore its reciprocal decreases. With $u=\ln x$, $du=dx/x$, so the improper integral becomes $6\int_{\ln4}^{\infty}u^{-2}\,du$. Write the converted lower limit. Keeping $4$ after changing the variable to $u$ is a common substitution error.

The $p$-series rule is not a separate mysterious fact. For $p\ne1$, the corresponding improper integral is $\int_1^b x^{-p}\,dx=(b^{1-p}-1)/(1-p)$. If $p>1$, then $1-p<0$ and $b^{1-p}\to0$, giving a finite limit. If $p<1$, then $1-p>0$ and $b^{1-p}\to\infty$. The boundary $p=1$ produces $\int_1^b dx/x=\ln b\to\infty$. That single calculation explains the full rule.


## 10.4 The Comparison Tests

**Thomas 10.4 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Direct comparison test” — Khan Academy

“Limit comparison test” — Khan Academy
:::

:::callout-intuition[Intuition — comparing to something you already know]
You have two powerful anchors: the geometric series (converges when $|r|<1$) and the $p$-series (converges when $p>1$). Most series you encounter in this course can be settled by comparing to one of these. The comparison tests give you two ways to do it: literally (every term is bigger or smaller) or asymptotically (the ratio of terms approaches a finite nonzero constant).

The **Direct Comparison Test (DCT)** is logically simple but requires finding an inequality that works for every single term. The **Limit Comparison Test (LCT)** is usually far easier: instead of finding a term-by-term inequality, you just compute a limit. If that limit is a positive finite number, the two series have identical convergence behavior — they live or die together.

The LCT is your workhorse for rational-function-type series. The DCT is better when absolute-value bounds are obvious (like bounding $\sin^2(n)$ between 0 and 1).
:::

:::theorem[Theorem 2.6 — Direct Comparison Test (DCT)]
Suppose $0 \le a_n \le b_n$ for all $n \ge N_0$ (for some starting index). Then:

 • If $\displaystyle\sum b_n$ converges, then $\displaystyle\sum a_n$ converges.

 • If $\displaystyle\sum a_n$ diverges, then $\displaystyle\sum b_n$ diverges.
:::

The logic is intuitive: if you're smaller than something finite, you're finite. If you're larger than something infinite, you're infinite. Notice the direction matters: to show convergence of $\sum a_n$, you need $a_n$ on the *smaller* side. To show divergence of $\sum a_n$, you need it on the *larger* side.

:::callout-pitfall[⚠ Getting the inequality direction backwards]
This is the most common DCT error. If $0 \le a_n \le b_n$ and $\sum b_n$ *diverges*, you can conclude nothing about $\sum a_n$ — it might converge or diverge. And if $0 \le b_n \le a_n$ and $\sum b_n$ *converges*, again you conclude nothing about $\sum a_n$. Only the two directions above (smaller than convergent, or larger than divergent) give you definitive information.
:::

:::theorem[Theorem 2.7 — Limit Comparison Test (LCT)]
Suppose $a_n > 0$ and $b_n > 0$. If $\displaystyle\lim_{n\to\infty}\frac{a_n}{b_n} = c$ where $0 < c < \infty$, then $\displaystyle\sum a_n$ and $\displaystyle\sum b_n$ either both converge or both diverge.
:::

The condition $0 < c < \infty$ means $c$ is a positive, finite number. The limit being positive means $a_n$ and $b_n$ are roughly the same size; the limit being finite means neither is overwhelmingly larger. In that case, both series have the same fate.

### How to choose the comparison series

This is a skill you build with practice. The strategy is: **identify the dominant behavior of $a_n$ for large $n$**, then let that be $b_n$. Specifically:

- Drop additive constants: $n^2 + 5 \approx n^2$
- Drop lower-order terms: $3n^3 - 2n^2 + 7 \approx 3n^3$
- Drop multiplicative constants from $b_n$ (they don't affect convergence)
- For $\sqrt{n^2 + 1}$, the dominant behavior is $\sqrt{n^2} = n$

After simplifying, $b_n$ should look like $1/n^p$ (a $p$-series) or $1/c^n$ (a geometric series). Then apply the LCT.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Graph sampled exactly from x to the power negative five halves and sin squared x over x to the power five halves">
<path class="fig-axis" d="M20 165 L380 165 M45 20 L45 200"/>
<path class="fig-curve" d="M54.0 65.0 L54.9 72.6 L55.9 79.4 L56.8 85.6 L57.7 91.1 L58.7 96.1 L59.6 100.7 L60.5 104.8 L61.5 108.6 L62.4 112.0 L63.3 115.2 L64.3 118.1 L65.2 120.8 L66.1 123.2 L67.0 125.5 L68.0 127.6 L68.9 129.6 L69.8 131.4 L70.8 133.1 L71.7 134.6 L72.6 136.1 L73.6 137.5 L74.5 138.7 L75.4 139.9 L76.4 141.1 L77.3 142.1 L78.2 143.1 L79.2 144.0 L80.1 144.9 L81.0 145.7 L82.0 146.5 L82.9 147.2 L83.8 147.9 L84.8 148.6 L85.7 149.2 L86.6 149.8 L87.6 150.4 L88.5 150.9 L89.4 151.4 L90.4 151.9 L91.3 152.3 L92.2 152.8 L93.2 153.2 L94.1 153.6 L95.0 154.0 L95.9 154.3 L96.9 154.7 L97.8 155.0 L98.7 155.3 L99.7 155.6 L100.6 155.9 L101.5 156.2 L102.5 156.4 L103.4 156.7 L104.3 156.9 L105.3 157.2 L106.2 157.4 L107.1 157.6 L108.1 157.8 L109.0 158.0 L109.9 158.2 L110.9 158.4 L111.8 158.5 L112.7 158.7 L113.7 158.9 L114.6 159.0 L115.5 159.2 L116.5 159.3 L117.4 159.5 L118.3 159.6 L119.2 159.7 L120.2 159.9 L121.1 160.0 L122.0 160.1 L123.0 160.2 L123.9 160.3 L124.8 160.5 L125.8 160.6 L126.7 160.7 L127.6 160.8 L128.6 160.9 L129.5 160.9 L130.4 161.0 L131.4 161.1 L132.3 161.2 L133.2 161.3 L134.2 161.4 L135.1 161.4 L136.0 161.5 L137.0 161.6 L137.9 161.7 L138.8 161.7 L139.8 161.8 L140.7 161.9 L141.6 161.9 L142.6 162.0 L143.5 162.0 L144.4 162.1 L145.3 162.1 L146.3 162.2 L147.2 162.3 L148.1 162.3 L149.1 162.4 L150.0 162.4 L150.9 162.5 L151.9 162.5 L152.8 162.5 L153.7 162.6 L154.7 162.6 L155.6 162.7 L156.5 162.7 L157.5 162.8 L158.4 162.8 L159.3 162.8 L160.3 162.9 L161.2 162.9 L162.1 162.9 L163.1 163.0 L164.0 163.0 L164.9 163.0 L165.9 163.1 L166.8 163.1 L167.7 163.1 L168.7 163.2 L169.6 163.2 L170.5 163.2 L171.4 163.3 L172.4 163.3 L173.3 163.3 L174.2 163.3 L175.2 163.4 L176.1 163.4 L177.0 163.4 L178.0 163.4 L178.9 163.5 L179.8 163.5 L180.8 163.5 L181.7 163.5 L182.6 163.5 L183.6 163.6 L184.5 163.6 L185.4 163.6 L186.4 163.6 L187.3 163.7 L188.2 163.7 L189.2 163.7 L190.1 163.7 L191.0 163.7 L192.0 163.7 L192.9 163.8 L193.8 163.8 L194.8 163.8 L195.7 163.8 L196.6 163.8 L197.6 163.8 L198.5 163.9 L199.4 163.9 L200.3 163.9 L201.3 163.9 L202.2 163.9 L203.1 163.9 L204.1 163.9 L205.0 164.0 L205.9 164.0 L206.9 164.0 L207.8 164.0 L208.7 164.0 L209.7 164.0 L210.6 164.0 L211.5 164.0 L212.5 164.1 L213.4 164.1 L214.3 164.1 L215.3 164.1 L216.2 164.1 L217.1 164.1 L218.1 164.1 L219.0 164.1 L219.9 164.1 L220.9 164.2 L221.8 164.2 L222.7 164.2 L223.6 164.2 L224.6 164.2 L225.5 164.2 L226.4 164.2 L227.4 164.2 L228.3 164.2 L229.2 164.2 L230.2 164.2 L231.1 164.3 L232.0 164.3 L233.0 164.3 L233.9 164.3 L234.8 164.3 L235.8 164.3 L236.7 164.3 L237.6 164.3 L238.6 164.3 L239.5 164.3 L240.4 164.3 L241.4 164.3 L242.3 164.3 L243.2 164.4 L244.2 164.4 L245.1 164.4 L246.0 164.4 L247.0 164.4 L247.9 164.4 L248.8 164.4 L249.8 164.4 L250.7 164.4 L251.6 164.4 L252.5 164.4 L253.5 164.4 L254.4 164.4 L255.3 164.4 L256.3 164.4 L257.2 164.4 L258.1 164.5 L259.1 164.5 L260.0 164.5 L260.9 164.5 L261.9 164.5 L262.8 164.5 L263.7 164.5 L264.7 164.5 L265.6 164.5 L266.5 164.5 L267.5 164.5 L268.4 164.5 L269.3 164.5 L270.3 164.5 L271.2 164.5 L272.1 164.5 L273.1 164.5 L274.0 164.5 L274.9 164.5 L275.8 164.5 L276.8 164.5 L277.7 164.6 L278.6 164.6 L279.6 164.6 L280.5 164.6 L281.4 164.6 L282.4 164.6 L283.3 164.6 L284.2 164.6 L285.2 164.6 L286.1 164.6 L287.0 164.6 L288.0 164.6 L288.9 164.6 L289.8 164.6 L290.8 164.6 L291.7 164.6 L292.6 164.6 L293.6 164.6 L294.5 164.6 L295.4 164.6 L296.4 164.6 L297.3 164.6 L298.2 164.6 L299.2 164.6 L300.1 164.6 L301.0 164.6 L301.9 164.6 L302.9 164.6 L303.8 164.7 L304.7 164.7 L305.7 164.7 L306.6 164.7 L307.5 164.7 L308.5 164.7 L309.4 164.7 L310.3 164.7 L311.3 164.7 L312.2 164.7 L313.1 164.7 L314.1 164.7 L315.0 164.7"/>
<path class="fig-curve-alt" d="M54.0 94.2 L54.9 96.9 L55.9 99.6 L56.8 102.1 L57.7 104.6 L58.7 107.1 L59.6 109.4 L60.5 111.7 L61.5 113.9 L62.4 116.1 L63.3 118.2 L64.3 120.3 L65.2 122.3 L66.1 124.2 L67.0 126.1 L68.0 127.9 L68.9 129.7 L69.8 131.4 L70.8 133.1 L71.7 134.7 L72.6 136.2 L73.6 137.8 L74.5 139.2 L75.4 140.6 L76.4 142.0 L77.3 143.3 L78.2 144.6 L79.2 145.8 L80.1 147.0 L81.0 148.1 L82.0 149.2 L82.9 150.3 L83.8 151.3 L84.8 152.2 L85.7 153.1 L86.6 154.0 L87.6 154.8 L88.5 155.6 L89.4 156.4 L90.4 157.1 L91.3 157.8 L92.2 158.4 L93.2 159.0 L94.1 159.6 L95.0 160.1 L95.9 160.6 L96.9 161.1 L97.8 161.5 L98.7 161.9 L99.7 162.3 L100.6 162.6 L101.5 163.0 L102.5 163.2 L103.4 163.5 L104.3 163.7 L105.3 164.0 L106.2 164.1 L107.1 164.3 L108.1 164.5 L109.0 164.6 L109.9 164.7 L110.9 164.8 L111.8 164.9 L112.7 164.9 L113.7 165.0 L114.6 165.0 L115.5 165.0 L116.5 165.0 L117.4 165.0 L118.3 165.0 L119.2 164.9 L120.2 164.9 L121.1 164.9 L122.0 164.8 L123.0 164.7 L123.9 164.7 L124.8 164.6 L125.8 164.5 L126.7 164.4 L127.6 164.4 L128.6 164.3 L129.5 164.2 L130.4 164.1 L131.4 164.0 L132.3 163.9 L133.2 163.8 L134.2 163.8 L135.1 163.7 L136.0 163.6 L137.0 163.5 L137.9 163.4 L138.8 163.4 L139.8 163.3 L140.7 163.2 L141.6 163.2 L142.6 163.1 L143.5 163.1 L144.4 163.0 L145.3 163.0 L146.3 162.9 L147.2 162.9 L148.1 162.9 L149.1 162.8 L150.0 162.8 L150.9 162.8 L151.9 162.8 L152.8 162.8 L153.7 162.8 L154.7 162.8 L155.6 162.8 L156.5 162.8 L157.5 162.8 L158.4 162.8 L159.3 162.8 L160.3 162.9 L161.2 162.9 L162.1 162.9 L163.1 163.0 L164.0 163.0 L164.9 163.1 L165.9 163.1 L166.8 163.2 L167.7 163.2 L168.7 163.3 L169.6 163.3 L170.5 163.4 L171.4 163.4 L172.4 163.5 L173.3 163.6 L174.2 163.6 L175.2 163.7 L176.1 163.8 L177.0 163.8 L178.0 163.9 L178.9 163.9 L179.8 164.0 L180.8 164.1 L181.7 164.1 L182.6 164.2 L183.6 164.2 L184.5 164.3 L185.4 164.4 L186.4 164.4 L187.3 164.5 L188.2 164.5 L189.2 164.6 L190.1 164.6 L191.0 164.6 L192.0 164.7 L192.9 164.7 L193.8 164.8 L194.8 164.8 L195.7 164.8 L196.6 164.9 L197.6 164.9 L198.5 164.9 L199.4 164.9 L200.3 164.9 L201.3 165.0 L202.2 165.0 L203.1 165.0 L204.1 165.0 L205.0 165.0 L205.9 165.0 L206.9 165.0 L207.8 165.0 L208.7 165.0 L209.7 165.0 L210.6 165.0 L211.5 165.0 L212.5 165.0 L213.4 165.0 L214.3 164.9 L215.3 164.9 L216.2 164.9 L217.1 164.9 L218.1 164.9 L219.0 164.9 L219.9 164.8 L220.9 164.8 L221.8 164.8 L222.7 164.8 L223.6 164.8 L224.6 164.7 L225.5 164.7 L226.4 164.7 L227.4 164.7 L228.3 164.7 L229.2 164.6 L230.2 164.6 L231.1 164.6 L232.0 164.6 L233.0 164.6 L233.9 164.5 L234.8 164.5 L235.8 164.5 L236.7 164.5 L237.6 164.5 L238.6 164.5 L239.5 164.5 L240.4 164.4 L241.4 164.4 L242.3 164.4 L243.2 164.4 L244.2 164.4 L245.1 164.4 L246.0 164.4 L247.0 164.4 L247.9 164.4 L248.8 164.4 L249.8 164.4 L250.7 164.4 L251.6 164.4 L252.5 164.4 L253.5 164.4 L254.4 164.4 L255.3 164.4 L256.3 164.5 L257.2 164.5 L258.1 164.5 L259.1 164.5 L260.0 164.5 L260.9 164.5 L261.9 164.5 L262.8 164.5 L263.7 164.6 L264.7 164.6 L265.6 164.6 L266.5 164.6 L267.5 164.6 L268.4 164.6 L269.3 164.7 L270.3 164.7 L271.2 164.7 L272.1 164.7 L273.1 164.7 L274.0 164.7 L274.9 164.8 L275.8 164.8 L276.8 164.8 L277.7 164.8 L278.6 164.8 L279.6 164.8 L280.5 164.9 L281.4 164.9 L282.4 164.9 L283.3 164.9 L284.2 164.9 L285.2 164.9 L286.1 164.9 L287.0 164.9 L288.0 165.0 L288.9 165.0 L289.8 165.0 L290.8 165.0 L291.7 165.0 L292.6 165.0 L293.6 165.0 L294.5 165.0 L295.4 165.0 L296.4 165.0 L297.3 165.0 L298.2 165.0 L299.2 165.0 L300.1 165.0 L301.0 165.0 L301.9 165.0 L302.9 165.0 L303.8 165.0 L304.7 165.0 L305.7 165.0 L306.6 165.0 L307.5 165.0 L308.5 165.0 L309.4 165.0 L310.3 164.9 L311.3 164.9 L312.2 164.9 L313.1 164.9 L314.1 164.9 L315.0 164.9"/>

</svg>
<figcaption>Direct comparison: $0\le\sin^2(n)/n^{5/2}\le1/n^{5/2}$. A smaller nonnegative term series inherits convergence.</figcaption>
</figure>


:::example[🧠 Example 10.4.1 — LCT with a $p$-series]
Determine whether $\displaystyle\sum_{n=1}^\infty\frac{3n^2+2}{n^4-5n+1}$ converges.

**Answer: Converges.**

**Hand calculation.**
**Step 1 — Identify dominant behavior.** Numerator is dominated by $3n^2$, denominator by $n^4$. So $a_n \approx \dfrac{3n^2}{n^4} = \dfrac{3}{n^2}$. Let $b_n = \dfrac{1}{n^2}$ (a $p$-series with $p=2$, which converges).

**Step 2 — Compute the limit.**

$$
\lim_{n\to\infty}\frac{a_n}{b_n} = \lim_{n\to\infty}\frac{3n^2+2}{n^4-5n+1}\cdot n^2 = \lim_{n\to\infty}\frac{3n^4+2n^2}{n^4-5n+1}.
$$

 Divide numerator and denominator by $n^4$:

$$
= \lim_{n\to\infty}\frac{3 + 2/n^2}{1 - 5/n^3 + 1/n^4} = \frac{3}{1} = 3.
$$

**Step 3 — Conclude.** $c = 3 > 0$ and finite. Since $\sum 1/n^2$ converges, $\sum a_n$ converges.
:::

:::example[🧠 Example 10.4.2 — LCT showing divergence]
Test $\displaystyle\sum_{n=1}^\infty\frac{1}{\sqrt{n^2+n}}$.

**Answer: Diverges.**

**Hand calculation.**
For large $n$: $\sqrt{n^2+n} \approx \sqrt{n^2} = n$, so $a_n \approx 1/n$. Use $b_n = 1/n$ (harmonic series, diverges).

$$
\lim_{n\to\infty}\frac{1/\sqrt{n^2+n}}{1/n} = \lim_{n\to\infty}\frac{n}{\sqrt{n^2+n}} = \lim_{n\to\infty}\frac{1}{\sqrt{1+1/n}} = \frac{1}{1} = 1.
$$

 $c=1$, finite and positive. Since $\sum 1/n$ diverges, $\sum a_n$ diverges.
:::

:::example[🧠 Example 10.4.3 — DCT with a bounded factor]
Show $\displaystyle\sum_{n=1}^\infty\frac{\cos^2 n}{n^2}$ converges.

**Answer: Converges.**

**Hand calculation.**
Since $0 \le \cos^2 n \le 1$ for all $n$, we have:

$$
0 \le \frac{\cos^2 n}{n^2} \le \frac{1}{n^2}.
$$

 Since $\sum 1/n^2$ converges ($p=2$), by the DCT, $\sum \cos^2(n)/n^2$ converges. (Notice: LCT wouldn't work cleanly here because $\cos^2 n / (1/n^2) = n^2\cos^2 n$ has no well-defined limit — the DCT is the natural tool when a bounded oscillating factor is present.)
:::

:::example[🧠 Example 10.4.4 — LCT with a geometric comparison]
Test $\displaystyle\sum_{n=1}^\infty\frac{n+2}{n\cdot 3^n}$.

**Answer: Converges.**

**Hand calculation.**
The $3^n$ in the denominator dominates everything. Compare to $b_n = (1/3)^n$, a geometric series with $r=1/3<1$ that converges.

$$
\lim_{n\to\infty}\frac{(n+2)/(n\cdot 3^n)}{1/3^n} = \lim_{n\to\infty}\frac{n+2}{n} = 1.
$$

 $c=1$. Since $\sum (1/3)^n$ converges, so does the original.
:::

::::problem[Problem 10.4.1 easy]{difficulty=easy}
Use the DCT to show $\displaystyle\sum_{n=1}^\infty\frac{\sin^2 n}{n^3}$ converges.

:::solution[Solution]
**Answer:** Converges by direct comparison.

1. **Method: Direct Comparison Test.** The trigonometric factor is nonnegative because it is squared. For every integer $n$, $-1\le\sin n\le1$, so $0\le\sin^2n\le1$.

2. **Build a term-by-term upper bound.** Because $n^3>0$ for $n\ge1$, dividing all parts of the inequality by $n^3$ gives

   $$
   0\le\frac{\sin^2n}{n^3}\le\frac1{n^3}.
   $$

3. **Check the benchmark series.** The comparison series $\sum_{n=1}^\infty1/n^3$ is a $p$-series with $p=3>1$, so it converges.

4. **Conclusion.** A nonnegative series bounded above term by term by a convergent positive series must converge. Therefore $\sum\sin^2n/n^3$ converges by Direct Comparison.
:::
::::
::::problem[Problem 10.4.2 standard]{difficulty=standard}
Test $\displaystyle\sum_{n=1}^\infty\frac{n}{\sqrt{n^5+1}}$ using the LCT.

:::solution[Solution]
**Answer:** Converges by limit comparison.

1. **Method: Limit Comparison Test.** Since $\sqrt{n^5+1}$ behaves like $n^{5/2}$, the term behaves like $n/n^{5/2}=n^{-3/2}$. Choose $b_n=1/n^{3/2}$. Both $a_n$ and $b_n$ are positive for $n\ge1$.

2. **Compute the ratio without skipping exponents.**

   $$
   \frac{a_n}{b_n}=\frac{n/\sqrt{n^5+1}}{1/n^{3/2}}
   =\frac{n^{5/2}}{\sqrt{n^5+1}}
   =\sqrt{\frac{n^5}{n^5+1}}
   =\frac1{\sqrt{1+1/n^5}}.
   $$

3. **Take the limit and check the criterion.** The ratio tends to $L=1$, with $0< L<\infty$. Thus the two series have the same convergence behavior. The benchmark $\sum1/n^{3/2}$ converges because $p=3/2>1$.

4. **Conclusion.** The original series converges by the Limit Comparison Test.
:::
::::
::::problem[Problem 10.4.3 standard]{difficulty=standard}
Does $\displaystyle\sum_{n=1}^\infty\frac{\ln n}{n}$ converge?

:::solution[Solution]
**Answer:** Diverges by direct comparison.

1. **Method: Direct Comparison Test.** The terms $\ln n/n$ are nonnegative for $n\ge1$. To prove divergence, compare from below with the harmonic series $\sum1/n$.

2. **Find an index where the inequality holds.** For $n\ge3$, $n>e$, so $\ln n>\ln e=1$. Dividing by $n>0$ gives

   $$
   \frac{\ln n}{n}>\frac1n\qquad(n\ge3).
   $$

3. **Check the comparison series.** The harmonic series $\sum_{n=3}^\infty1/n$ diverges; this follows from the $p$-series rule with $p=1$. Removing its first two terms does not change divergence.

4. **Conclusion.** Since the original nonnegative terms eventually exceed those of a divergent series, $\sum_{n=1}^\infty(\ln n)/n$ diverges by Direct Comparison.
:::
::::
::::problem[Problem 10.4.4 standard]{difficulty=standard}
Test $\displaystyle\sum_{n=0}^\infty\frac{1}{2^n+3^n}$.

:::solution[Solution]
**Answer:** Converges by limit comparison.

1. **Method: Limit Comparison Test.** The $3^n$ term dominates $2^n$ in the denominator. Choose $b_n=1/3^n$; both the given terms and $b_n$ are positive for every $n\ge0$.

2. **Calculate the comparison limit.**

   $$
   \frac{a_n}{b_n}=\frac{1/(2^n+3^n)}{1/3^n}
   =\frac{3^n}{2^n+3^n}
   =\frac1{(2/3)^n+1}.
   $$

   As $n\to\infty$, $(2/3)^n\to0$ because $|2/3|<1$. Therefore $L=1/(0+1)=1$, which is positive and finite.

3. **Check the benchmark.** The series $\sum_{n=0}^\infty(1/3)^n$ is geometric with ratio $1/3$ of magnitude below one, hence convergent.

4. **Conclusion.** By Limit Comparison, $\sum_{n=0}^\infty1/(2^n+3^n)$ converges.
:::
::::
::::problem[Problem 10.4.5 challenge]{difficulty=challenge}
Test $\displaystyle\sum_{n=1}^\infty\frac{1}{\sqrt{n(n+1)(n+2)}}$.

:::solution[Solution]
**Answer:** Converges by limit comparison.

1. **Method: Limit Comparison Test.** The denominator contains a product of three factors each comparable to $n$. Taking the square root gives growth like $n^{3/2}$. Compare with $b_n=1/n^{3/2}$, positive for $n\ge1$.

2. **Compute the ratio exactly.**

   $$
   \frac{a_n}{b_n}
   =\frac{n^{3/2}}{\sqrt{n(n+1)(n+2)}}
   =\sqrt{\frac{n^3}{n(n+1)(n+2)}}
   =\frac1{\sqrt{(1+1/n)(1+2/n)}}.
   $$

3. **Take the limit.** Since $1/n\to0$ and $2/n\to0$, the ratio tends to $L=1/\sqrt{1\cdot1}=1$. This satisfies $0< L<\infty$.

4. **Check the benchmark and conclude.** The $p$-series $\sum1/n^{3/2}$ converges because $3/2>1$. Therefore the original series converges by the Limit Comparison Test.
:::
::::

### Why the direction of an inequality matters

The Direct Comparison Test has exactly two useful arrows. To prove **convergence**, place your nonnegative term **below** the term of a known convergent series: $0\le a_n\le b_n$ and $\sum b_n$ converges. To prove **divergence**, place your nonnegative term **above** a known divergent term: $0\le b_n\le a_n$ and $\sum b_n$ diverges. The reversed directions prove nothing. Think of a smaller collection of nonnegative deposits and a larger collection: a finite upper total bounds the smaller total, while an infinite lower total forces the larger total to grow without bound.

For Limit Comparison, choose a benchmark $b_n$ with the same dominant growth. Compute $L=\lim a_n/b_n$; when $0< L<\infty$, the two series have the same convergence status. A constant multiple is fine: $L=3$, $L=1/8$, and $L=\sqrt2$ are all valid. But $L=0$ or $\infty$ does **not** satisfy the standard two-way criterion. Consider a different comparison or invoke a correct one-sided argument instead.

### Bounded trigonometric and inverse-trigonometric numerators

Young’s review includes $\sin^2n/n^{5/2}$ and $\arctan(n)/(1+n^2)$. Do not differentiate the oscillating $\sin n$ with respect to the **integer** index or try to infer that the terms alternate. You already know $0\le\sin^2n\le1$. Because $n^{5/2}>0$, divide every part of the inequality by $n^{5/2}$ and compare directly to a convergent $p$-series. For $n>0$, $0<\arctan n<\pi/2$. Since $1+n^2\ge n^2$, you have a simple convergent upper bound $(\pi/2)n^{-2}$.

:::callout-key[Test selection in ten seconds]
If numerator and denominator are polynomials, try Limit Comparison using leading degrees. If an obvious $0\le f(n)\le1$ multiplier sits on top of a $p$-series, try Direct Comparison. If the sign changes, compare **absolute values** or use the alternating tools of §2.5. State the inequalities before naming the test.
:::

:::example[Example 10.4.5 — Young-style bounded sine]
Determine convergence of $\displaystyle\sum_{n=1}^\infty\frac{\sin^2n}{n^{5/2}}$.

**Answer: $\text{Converges absolutely}$.**


Since $-1\le\sin n\le1$, squaring gives $0\le\sin^2n\le1$. For every positive integer $n$,

$$0\le\frac{\sin^2n}{n^{5/2}}\le\frac1{n^{5/2}}.$$

The comparison series $\sum n^{-5/2}$ is a $p$-series with $p=5/2>1$, so it converges. By **Direct Comparison**, the given series converges. All terms are nonnegative, so it also converges absolutely.

:::

:::example[Example 10.4.6 — Arctan divided by a quadratic]
Test $\displaystyle\sum_{n=1}^\infty\frac{\arctan n}{1+n^2}$.

**Answer: $\text{Converges}$.**


For $n\ge1$, $0<\arctan n<\pi/2$ and $1+n^2\ge n^2$. Therefore

$$
0\le\frac{\arctan n}{1+n^2}
\le\frac{\pi/2}{1+n^2}
\le\frac{\pi}{2n^2}.
$$
The rightmost series is $(\pi/2)\sum 1/n^2$, which converges because $p=2>1$. The given series converges by Direct Comparison. No inverse-trigonometric differentiation was necessary.

:::

::::problem[Problem 10.4.6 — Leading terms and LCT]{difficulty=standard}
Test $\sum_{n=1}^\infty\frac{4n^2+1}{n^4+3n+7}$ with an explicit Limit Comparison limit.

:::solution[Solution]
**Answer:** $\text{Converges}$.

1. **Method: Limit Comparison Test.** For large $n$, the numerator behaves like $4n^2$ and the denominator like $n^4$. Compare with $b_n=1/n^2$. All terms of both series are positive for $n\ge1$.

2. **Form the ratio and clear the fractions.**

   $$
   \frac{a_n}{b_n}=
   \frac{(4n^2+1)/(n^4+3n+7)}{1/n^2}
   =\frac{4n^4+n^2}{n^4+3n+7}.
   $$

3. **Evaluate the limit.** Divide the numerator and denominator by $n^4$:

   $$
   L=\lim_{n\to\infty}\frac{4+1/n^2}{1+3/n^3+7/n^4}=\frac41=4.
   $$

   Hence $0< L<\infty$, so Limit Comparison is conclusive.

4. **Conclusion.** Since $\sum1/n^2$ converges by the $p$-series test ($p=2>1$), the given series converges by Limit Comparison.
:::
::::

### Build a comparison from the dominant power

For a large-index rational term, the powers of $n$ with the highest exponents usually determine a suitable benchmark. Write the numerator’s leading order and the denominator’s leading order *before* deciding which $p$-series to compare with. If the term resembles $n^2/n^5$, it resembles $1/n^3$; if it resembles $n^4/n^5$, it resembles $1/n$. Only after choosing the benchmark should you form the limit-comparison ratio.

Consider the generic structure $a_n=(an^2+b)/(cn^4+dn+e)$, with positive leading coefficients $a,c$. The natural benchmark is $b_n=1/n^2$. Its limit-comparison ratio is

$$
\frac{a_n}{b_n}
=\frac{n^2(an^2+b)}{cn^4+dn+e}
=\frac{a+b/n^2}{c+d/n^3+e/n^4}
\longrightarrow\frac ac.
$$

Provided the original terms are eventually positive, $0< a/c<\infty$, so the two series have the same convergence behavior. In a written proof, state that $\sum1/n^2$ converges because $p=2>1$, and *then* conclude convergence by the Limit Comparison Test. “Limit equals a positive number” without a benchmark conclusion is an incomplete justification.

Direct comparison reverses the reasoning according to what you are trying to establish. To prove convergence, put your term **below** a known convergent term: $0\le a_n\le b_n$ and $\sum b_n$ convergent. To prove divergence, put your term **above** a known divergent term: $0\le b_n\le a_n$ and $\sum b_n$ divergent. The other two inequality directions by themselves establish nothing. When a term is not nonnegative, compare its absolute value if you are trying to prove absolute convergence.

### Why bounded numerators are exam-friendly

Young's $\sin^2n/n^{5/2}$ and $\arctan n/(1+n^2)$ examples are a reminder to **bound before differentiating**. Because $0\le\sin^2n\le1$, we have $0\le\sin^2n/n^{5/2}\le1/n^{5/2}$, a convergent $p$-series. Also $0\le\arctan n\le\pi/2$ for $n\ge1$; hence $0\le\arctan n/(1+n^2)\le(\pi/2)/n^2$. The constants change the numerical sum but not its convergence. These inequalities are often substantially shorter than taking a limit, differentiating a complicated function, or attempting an integral of an inverse trigonometric expression.

At the end, check the result against intuition: making the numerator smaller or denominator larger cannot destroy convergence of a nonnegative series already bounded by a convergent one. That is not a substitute for the proof, but it catches comparisons written in the wrong direction.


## 10.5 Absolute Convergence; Ratio and Root Tests

**Thomas 10.5 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Ratio test for convergence” — Khan Academy

“Absolute and conditional convergence” — Khan Academy
:::

:::callout-intuition[Intuition — what these tests actually measure]
Both the Ratio Test and the Root Test ask the same underlying question: *is the series shrinking fast enough to converge?* Specifically, they check whether the terms eventually behave like a geometric series. If consecutive terms have a ratio approaching some $L < 1$, the series behaves like a convergent geometric series and must converge. If $L > 1$, the terms are growing — instant divergence.

The **Ratio Test** computes $|a_{n+1}/a_n|$. It shines whenever the formula for $a_n$ involves factorials or exponentials, because those simplify beautifully in a ratio: $(n+1)!/n! = n+1$ and $c^{n+1}/c^n = c$.

The **Root Test** computes $\sqrt[n]{|a_n|}$. It shines whenever $a_n$ is something raised to the $n$-th power, because the $n$-th root instantly cancels that exponent.

Both tests fail (are inconclusive) exactly when $L = 1$. This happens for $p$-series, so never use either test on $1/n^p$ — they'll just tell you "I don't know."
:::

:::theorem[Theorem 2.11 — Ratio Test]
Let $\displaystyle L = \lim_{n\to\infty}\left|\frac{a_{n+1}}{a_n}\right|$. Then:

 If $L < 1$: the series $\displaystyle\sum a_n$ converges absolutely.
 If $L > 1$ (or $L = \infty$): the series diverges.
 If $L = 1$: the test is **inconclusive** — try another test.
:::

:::theorem[Theorem 2.12 — Root Test]
Let $\displaystyle L = \lim_{n\to\infty}\sqrt[n]{|a_n|}$. Same three conclusions as the Ratio Test.
:::

### Working with factorials in the Ratio Test

The key factorial identities to internalize:

- $\dfrac{(n+1)!}{n!} = n+1$
- $\dfrac{(2n+2)!}{(2n)!} = (2n+2)(2n+1)$
- $\dfrac{n!}{(n+1)!} = \dfrac{1}{n+1}$

When you compute $|a_{n+1}/a_n|$, write out $a_{n+1}$ explicitly by replacing every $n$ with $n+1$, then divide. Cancel as many factors as possible before taking the limit.

:::example[🧠 Example 10.5.1 — Ratio Test with factorials]
Test $\displaystyle\sum_{n=0}^\infty\frac{n!}{5^n}$.

**Answer: Diverges.**

**Hand calculation.**
Identify $a_n = n!/5^n$. Write $a_{n+1} = (n+1)!/5^{n+1}$. Compute the ratio:

$$
\left|\frac{a_{n+1}}{a_n}\right| = \frac{(n+1)!}{5^{n+1}}\cdot\frac{5^n}{n!} = \frac{(n+1)\cdot n!}{5\cdot n!} = \frac{n+1}{5}.
$$

 Take the limit: $\displaystyle\lim_{n\to\infty}\frac{n+1}{5} = \infty > 1$. The series diverges. (Factorials grow faster than exponentials — the growth-rate hierarchy strikes again.)
:::

:::example[🧠 Example 10.5.2 — Ratio Test with exponentials]
Test $\displaystyle\sum_{n=1}^\infty\frac{n^2\cdot 3^n}{n!}$.

**Answer: Converges absolutely.**

**Hand calculation.**
$a_{n+1} = \dfrac{(n+1)^2\cdot 3^{n+1}}{(n+1)!}$. The ratio:

$$
\left|\frac{a_{n+1}}{a_n}\right| = \frac{(n+1)^2\cdot 3^{n+1}}{(n+1)!}\cdot\frac{n!}{n^2\cdot 3^n} = \frac{(n+1)^2\cdot 3}{(n+1)\cdot n^2} = \frac{3(n+1)}{n^2} = \frac{3n+3}{n^2}.
$$

 As $n\to\infty$: $\dfrac{3n+3}{n^2}\to 0 < 1$. Converges absolutely. (Factorials in the denominator grow faster than any exponential times polynomial.)
:::

:::example[🧠 Example 10.5.3 — Ratio Test, one more]
Test $\displaystyle\sum_{n=1}^\infty\frac{n^n}{n!}$.

**Answer: Diverges.**

**Hand calculation.**
$$
\left|\frac{a_{n+1}}{a_n}\right| = \frac{(n+1)^{n+1}}{(n+1)!}\cdot\frac{n!}{n^n} = \frac{(n+1)^{n+1}}{(n+1)\cdot n^n} = \frac{(n+1)^n}{n^n} = \left(1+\frac{1}{n}\right)^n \to e > 1.
$$

 The series diverges. This also confirms the hierarchy: $n^n$ grows faster than $n!$.
:::

:::example[🧠 Example 10.5.4 — Root Test]
Test $\displaystyle\sum_{n=1}^\infty\left(\frac{2n+1}{3n-2}\right)^n$.

**Answer: Converges absolutely.**

**Hand calculation.**
The entire term is raised to the $n$-th power — classic Root Test setup. Take the $n$-th root:

$$
\sqrt[n]{|a_n|} = \sqrt[n]{\left(\frac{2n+1}{3n-2}\right)^n} = \frac{2n+1}{3n-2} \to \frac{2}{3} < 1.
$$

 Converges absolutely. The $n$-th root eliminated the exponent in one step.
:::

:::example[🧠 Example 10.5.5 — Root Test with a trickier form]
Test $\displaystyle\sum_{n=1}^\infty\left(\frac{1}{1+1/n}\right)^{n^2}$.

**Answer: Converges absolutely.**

**Hand calculation.**
$$
\sqrt[n]{|a_n|} = \left(\frac{1}{1+1/n}\right)^n = \frac{1}{(1+1/n)^n} \to \frac{1}{e} < 1.
$$

 Converges. (Used $(1+1/n)^n \to e$, Example 10.1.6.)
:::

:::callout-pitfall[⚠ "Inconclusive" does not mean "diverges"]
When the Ratio or Root Test gives $L=1$, you know nothing — the series could converge or diverge. Both $\sum 1/n$ (diverges) and $\sum 1/n^2$ (converges) give $L=1$ under both tests. When $L=1$, abandon the test and try LCT, Integral Test, or AST instead.
:::

::::problem[Problem 10.5.1 easy]{difficulty=easy}
Apply the Ratio Test to $\displaystyle\sum_{n=0}^\infty\frac{4^n}{n!}$.

:::solution[Solution]
**Answer:** Converges absolutely; ratio limit 0.

1. **Method: Ratio Test.** Factorials simplify when dividing successive terms, making this test natural. Set $a_n=4^n/n!$, with $a_n>0$ for $n\ge0$.

2. **Form the successive-term ratio.** Use $(n+1)!=(n+1)n!$ and $4^{n+1}=4\cdot4^n$:

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\frac{4^{n+1}}{(n+1)!}\cdot\frac{n!}{4^n}
   =\frac{4\cdot4^n n!}{(n+1)n!4^n}
   =\frac4{n+1}.
   $$

3. **Take the limit.** $L=\lim_{n\to\infty}4/(n+1)=0$. Because $L<1$, the Ratio Test proves convergence of the series of absolute values.

4. **Conclusion.** The series converges absolutely. Its sum also equals $e^4$, but finding that sum is not required for the test.
:::
::::
::::problem[Problem 10.5.2 standard]{difficulty=standard}
Test $\displaystyle\sum_{n=1}^\infty\frac{n^3}{3^n}$ with the Ratio Test.

:::solution[Solution]
**Answer:** Converges absolutely; ratio limit $1/3$.

1. **Method: Ratio Test.** The summand contains a polynomial divided by an exponential. Let $a_n=n^3/3^n>0$. Taking $a_{n+1}/a_n$ cancels the exponential factors.

2. **Calculate the ratio.**

   $$
   \frac{a_{n+1}}{a_n}
   =\frac{(n+1)^3}{3^{n+1}}\cdot\frac{3^n}{n^3}
   =\frac13\left(\frac{n+1}{n}\right)^3
   =\frac13\left(1+\frac1n\right)^3.
   $$

3. **Find the limit and check the cutoff.** Since $1/n\to0$,

   $$
   L=\lim_{n\to\infty}\frac13(1+1/n)^3=\frac13<1.
   $$

   This is the decisive Ratio Test condition; no endpoint check is needed for a numerical series.

4. **Conclusion.** The positive-term series converges, hence it is absolutely convergent.
:::
::::
::::problem[Problem 10.5.3 standard]{difficulty=standard}
Use the Root Test on $\displaystyle\sum_{n=2}^\infty\frac{1}{(\ln n)^n}$.

:::solution[Solution]
**Answer:** Converges absolutely; root limit 0.

1. **Method: Root Test.** The entire factor $(\ln n)^{-1}$ is raised to the $n$th power, so taking the $n$th root removes that exponent. For $n\ge2$, $\ln n>0$; hence each term is positive.

2. **Take the $n$th root.** For $a_n=1/(\ln n)^n$,

   $$
   \sqrt[n]{|a_n|}=\sqrt[n]{\left(\frac1{\ln n}\right)^n}
   =\frac1{\ln n}.
   $$

3. **Evaluate the root limit.** Because $\ln n\to+\infty$ as $n\to\infty$,

   $$
   L=\lim_{n\to\infty}\frac1{\ln n}=0<1.
   $$

4. **Conclusion.** By the Root Test, the series converges absolutely. Although $\ln n$ grows slowly, raising its reciprocal to the $n$th power ultimately makes the summand small enough.
:::
::::
::::problem[Problem 10.5.4 standard]{difficulty=standard}
Test $\displaystyle\sum_{n=1}^\infty\frac{(2n)!}{(n!)^2\cdot 4^n}$ with the Ratio Test.

:::solution[Solution]
**Answer:** Ratio limit 1 (inconclusive); the series actually diverges.

1. **Method: Ratio Test first.** Set $a_n=(2n)!/[(n!)^2 4^n]>0$. Factorial cancellation gives

   $$
   \frac{a_{n+1}}{a_n}=
   \frac{(2n+2)(2n+1)}{4(n+1)^2}
   =\frac{2n+1}{2n+2}\longrightarrow1.
   $$

   The Ratio Test is inconclusive when $L=1$; do not conclude convergence.

2. **Switch to Direct Comparison.** By the binomial theorem,

   $$
   4^n=\sum_{k=0}^{2n}\binom{2n}{k}.
   $$

   There are $2n+1$ nonnegative coefficients, each no larger than the central coefficient $\binom{2n}{n}$. Thus $4^n\le(2n+1)\binom{2n}{n}$, so

   $$
   a_n=\frac{\binom{2n}{n}}{4^n}\ge\frac1{2n+1}.
   $$

3. **Check the divergent benchmark.** For $n\ge1$, $1/(2n+1)\ge1/[3n]$, and $\sum1/(3n)$ is a divergent harmonic multiple.

4. **Conclusion.** The given series diverges by Direct Comparison, not by the inconclusive Ratio Test.
:::
::::
::::problem[Problem 10.5.5 challenge]{difficulty=challenge}
Show that $\displaystyle\sum_{n=1}^\infty\frac{(-3)^n}{n\cdot 2^{2n}}$ converges absolutely, and find the interval of convergence interpretation.

:::solution[Solution]
**Answer:** Converges absolutely; root limit $3/4$.

1. **Method: Root Test.** First write $2^{2n}=4^n$ and simplify the term:

   $$
   a_n=\frac{(-3)^n}{n4^n}=\frac{(-3/4)^n}{n},
   \qquad |a_n|=\frac{(3/4)^n}{n}.
   $$

2. **Compute the root limit.**

   $$
   \sqrt[n]{|a_n|}=\frac{3/4}{n^{1/n}}
   \longrightarrow\frac{3/4}{1}=\frac34<1,
   $$

   because $n^{1/n}\to1$. By the Root Test the series converges absolutely.

3. **Interpret it as a power series.** The related series $\sum_{n=1}^\infty x^n/n=-\ln(1-x)$ has radius $R=1$ and interval $[-1,1)$. Substituting $x=-3/4$ reproduces $a_n$, and $|-3/4|<1$, so this point is inside its convergence interval.

4. **Conclusion.** The numerical series converges absolutely, consistent with the power-series radius.
:::
::::

### Factorial cancellation: a written exam method

The Ratio Test measures how the next term compares with the current one. When a factorial appears, write $a_{n+1}$ by replacing **every** $n$ by $(n+1)$ before simplifying anything. Next use $(n+1)!=(n+1)n!$ and $(2n+2)!=(2n+2)(2n+1)(2n)!$. Cancel only after displaying the whole quotient. A common wrong move is to replace $(2n+2)!$ with $(2n+2)(2n)!$, forgetting the factor $2n+1$.

A finite nonnegative ratio limit $L$ gives three cases: $L<1$ means absolute convergence; $L>1$, including $L=\infty$, means divergence; $L=1$ means **inconclusive**. The Root Test has precisely the same cutoffs, but its input is $\sqrt[n]{|a_n|}$. It is best for a term of the form $[f(n)]^n$ because the root cancels the outer $n$ immediately. If the term has several factors raised to different powers, take logarithms or split roots carefully.

### A ratio limit of one is not a verdict

Both $\sum 1/n$ and $\sum1/n^2$ have ratio limits $1$: for $1/n$, $a_{n+1}/a_n=n/(n+1)\to1$; for $1/n^2$, the ratio is $n^2/(n+1)^2\to1$. But the first diverges and the second converges. Once $L=1$, switch tests. A series containing $n!$ may still be approachable by another comparison; never write “diverges because the ratio is 1.”

:::callout-tip[Exam order]
Write $L=\lim|a_{n+1}/a_n|$ or $L=\lim\sqrt[n]{|a_n|}$; show the substitution; simplify factorials or the $n$th root; take the limit; compare with 1; conclude with the name of the test. Every displayed intermediate expression is a potential source of partial credit.
:::

:::example[Example 10.5.6 — Factorial in the denominator]
Test $\sum_{n=1}^\infty\frac{n!\,2^n}{(2n)!}$.

**Answer: $\text{Converges absolutely}$; $L=0$.**


Let $a_n=n!2^n/(2n)!>0$. Form the **entire** quotient:

$$
\begin{aligned}
\frac{a_{n+1}}{a_n}
&=\frac{(n+1)!2^{n+1}}{(2n+2)!}\frac{(2n)!}{n!2^n}\\
&=\frac{(n+1)n!\cdot2\cdot2^n}{(2n+2)(2n+1)(2n)!}\frac{(2n)!}{n!2^n}\\
&=\frac{2(n+1)}{(2n+2)(2n+1)}\\
&=\frac1{2n+1}.
\end{aligned}
$$
Thus $L=\lim_{n\to\infty}1/(2n+1)=0<1$. By the Ratio Test the series converges absolutely.

:::

:::example[Example 10.5.7 — Root Test by canceling an nth power]
Test $\sum_{n=1}^\infty\left(\frac{3n+2}{5n+1}\right)^n$.

**Answer: $\text{Converges absolutely}$; $L=\frac35$.**


The entire fraction is positive. Take the $n$th root of the absolute value:

$$\sqrt[n]{\left|\left(\frac{3n+2}{5n+1}\right)^n\right|}=\frac{3n+2}{5n+1}.$$

Now divide numerator and denominator by $n$:

$$L=\lim_{n\to\infty}\frac{3+2/n}{5+1/n}=\frac35.$$

Since $3/5<1$, the Root Test proves convergence. There was no need to evaluate the sum and no need to expand any binomial power.

:::

::::problem[Problem 10.5.6 — Ratio with two factorials]{difficulty=standard}
Test $\sum_{n=1}^\infty\frac{3^n n!}{(2n)!}$ by Ratio Test.

:::solution[Solution]
**Answer:** $\text{Converges absolutely}$; $L=0$.

1. **Method: Ratio Test.** The term $a_n=3^nn!/(2n)!$ is positive, and dividing adjacent factorial expressions will cancel almost everything.

2. **Expand the factorials.** Since $(n+1)!=(n+1)n!$ and $(2n+2)!=(2n+2)(2n+1)(2n)!$,

   $$
   \frac{a_{n+1}}{a_n}
   =\frac{3^{n+1}(n+1)!}{(2n+2)!}\frac{(2n)!}{3^nn!}
   =\frac{3(n+1)}{(2n+2)(2n+1)}.
   $$

3. **Simplify and take the limit.** Substitute $2n+2=2(n+1)$ and cancel $n+1$:

   $$
   L=\lim_{n\to\infty}\frac{3}{2(2n+1)}=0.
   $$

4. **Check the criterion and conclude.** Because $L=0<1$, the Ratio Test proves that $\sum_{n=1}^\infty3^nn!/(2n)!$ converges absolutely.
:::
::::

### Ratio Test: cancel before taking the limit

The Ratio Test asks you to evaluate $L=\lim_{n\to\infty}|a_{n+1}/a_n|$. The first line of work should show $a_{n+1}$ with **every $n$ replaced by $n+1$**. This matters especially with factorials: $(n+1)!=(n+1)n!$, while $(2n+2)!=(2n+2)(2n+1)(2n)!$. You must use both new factors in the second identity; treating $(2n+2)!$ as $(2n+2)(2n)!$ drops one factor and can reverse the verdict.

A practical written method is to leave all factorial symbols alone in the first ratio, invert the fraction that came from the denominator, and cancel only after both factors are visible. Thus a term containing $n!/3^n$ leads to

$$
\left|\frac{a_{n+1}}{a_n}\right|
=\frac{(n+1)!}{3^{n+1}}\frac{3^n}{n!}
=\frac{n+1}{3}.
$$

The last expression tends to infinity, so the original series diverges by the Ratio Test. In contrast, for $3^n/n!$ the ratio is $3/(n+1)\to0$, and the series converges absolutely. Same ingredients, opposite placement. The ratio calculation, not simply the presence of a factorial, decides what happens.

### Root Test: expose the repeated $n$th power

The Root Test is often shorter when the whole term is already raised to $n$. In $a_n=[(3n+2)/(5n+1)]^n$, calculate

$$
\sqrt[n]{|a_n|}=\left|\frac{3n+2}{5n+1}\right|
=\frac{3+2/n}{5+1/n}\longrightarrow\frac35.
$$

That is less than one, so the series converges absolutely. There is no need to expand the exponent or differentiate. For $a_n=n^{-n}$, the root is $1/n\to0$, another immediate convergence verdict. The root test is not interchangeable with the nth-term divergence test: the root test takes the $n$th root of the **absolute term** and compares the limit to one.

Both tests have the same decision boundary: $L<1$ gives absolute convergence, $L>1$ (or $L=+\infty$) gives divergence, and $L=1$ is inconclusive. A result of exactly one is not an error in your algebra; it means the test supplied no decision. Both $\sum1/n$ and $\sum1/n^2$ have ratio and root limits equal to one, although their convergence differs. Follow the evidence toward comparison, an integral, or the Alternating Series Test instead of pretending the boundary means divergence.

To receive the justification points, display the expression for $a_{n+1}$, the simplified ratio/root, the limiting value, and the named test verdict. If the original terms have alternating signs, keep the absolute-value bars until the end: a ratio limit below one proves *absolute* convergence, which is stronger than the alternating test's ordinary convergence.

### A practical test-selection boundary

The Ratio and Root Tests are especially powerful when terms contain factorials, products of many successive integers, or a base raised to $n$. They are usually not the fastest first choice for an ordinary rational term such as $n/(n^3+1)$; comparing its leading powers directly with $1/n^2$ involves less writing. The selection rule is about algebraic effort, not which test is more prestigious. If you see a square root of a polynomial, first ask whether a $p$-series comparison is available. If you see $(3/4)^n$ together with polynomial factors, a ratio is usually excellent because successive exponential factors cancel.

Be careful with a zero limit of $a_n$ versus a zero limit of the ratio. In the series $\sum1/n$, the terms tend to zero but the ratio $(n/(n+1))$ tends to one. That is why a zero term limit does not establish convergence. Conversely, when the Ratio Test gives $L=0$, it means successive absolute terms become smaller by factors whose limiting size is zero, so the test **does** prove absolute convergence. These are limits of different expressions, and naming which limit you computed is essential.


## 10.6 Alternating Series

**Thomas 10.6 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Alternating series test” — Khan Academy
:::

:::callout-intuition[Intuition — why alternating series behave so nicely]
An **alternating series** has terms that switch sign every step: $b_1 - b_2 + b_3 - b_4 + \cdots$ where all $b_n > 0$. Visualize what happens to the partial sums: $S_1 = b_1$ (big jump forward), $S_2 = b_1 - b_2$ (step back), $S_3 = b_1 - b_2 + b_3$ (step forward again), $\ldots$ The partial sums oscillate back and forth, but if the steps are *getting smaller*, each correction overshoots by less and less. The partial sums close in on the true value like a thermostat hunting for the right temperature.

The beautiful bonus is the **Alternating Series Estimation Theorem**: the error from stopping at term $N$ is at most the very next term $b_{N+1}$. This gives an incredibly tight and simple error bound — no integration needed.
:::

:::theorem[Theorem 2.8 — Alternating Series Test (AST / Leibniz's Test)]
The alternating series $\displaystyle\sum_{n=1}^\infty(-1)^{n-1}b_n = b_1 - b_2 + b_3 - b_4 + \cdots$ with $b_n > 0$ converges if both conditions hold:

 (i) the sequence $\{b_n\}$ is *decreasing*: $b_{n+1} \le b_n$ for all large $n$

 (ii) $\displaystyle\lim_{n\to\infty}b_n = 0$
:::

Condition (ii) is necessary (if $b_n \not\to 0$ the $n$-th Term Test immediately kills it). Condition (i) guarantees the oscillations actually converge rather than bouncing around chaotically. Together, they're sufficient for convergence.

**How to check that $\{b_n\}$ is decreasing:** Either (a) show $b_{n+1}/b_n \le 1$ algebraically, or (b) let $f(x) = b_n$ treated as a continuous function and show $f'(x) \le 0$. The function approach is usually cleaner when $b_n$ involves a fraction.

:::theorem[Theorem 2.9 — Alternating Series Estimation Theorem]
If the AST conditions hold and the series converges to $S$, then the error of approximating $S$ by the $N$-th partial sum $S_N$ satisfies:

$$
|S - S_N| \le b_{N+1}.
$$

 Moreover, $S$ lies between any two consecutive partial sums: $S_{N+1} \le S \le S_N$ (or $S_N \le S \le S_{N+1}$ depending on the sign of the last included term).
:::

### Absolute vs. Conditional Convergence

:::definition[Definition 2.3 — Absolute and Conditional Convergence]
A series $\displaystyle\sum a_n$ is **absolutely convergent** if $\displaystyle\sum|a_n|$ converges. It is **conditionally convergent** if $\displaystyle\sum a_n$ converges but $\displaystyle\sum|a_n|$ diverges.
:::

:::theorem[Theorem 2.10 — Absolute Convergence Implies Convergence]
If $\displaystyle\sum|a_n|$ converges, then $\displaystyle\sum a_n$ converges.
:::

The converse is false: the alternating harmonic series $\sum(-1)^{n-1}/n$ converges (by AST), but $\sum 1/n$ diverges — so it's conditionally, not absolutely, convergent. Absolute convergence is the "stronger" property.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Alternating partial sums oscillate closer to a single limit">
<path class="fig-axis" d="M 20 155 L 380 155 M 45 20 L 45 205"/>
<path class="fig-point" d="M 65.0 90.0 l 0.1 0"/>
<path class="fig-point" d="M 85.0 122.5 l 0.1 0"/>
<path class="fig-point" d="M 105.0 100.8 l 0.1 0"/>
<path class="fig-point" d="M 125.0 117.1 l 0.1 0"/>
<path class="fig-point" d="M 145.0 104.1 l 0.1 0"/>
<path class="fig-point" d="M 165.0 114.9 l 0.1 0"/>
<path class="fig-point" d="M 185.0 105.6 l 0.1 0"/>
<path class="fig-point" d="M 205.0 113.8 l 0.1 0"/>
<path class="fig-point" d="M 225.0 106.5 l 0.1 0"/>
<path class="fig-point" d="M 245.0 113.0 l 0.1 0"/>
<path class="fig-point" d="M 265.0 107.1 l 0.1 0"/>
<path class="fig-point" d="M 285.0 112.5 l 0.1 0"/>
<path class="fig-point" d="M 305.0 107.5 l 0.1 0"/>
<path class="fig-point" d="M 325.0 112.2 l 0.1 0"/>
<path class="fig-point" d="M 345.0 107.9 l 0.1 0"/>

</svg>
<figcaption>The alternating partial sums of $1-1/2+1/3-\cdots$ lie on opposite sides of a common limit; the decreasing step lengths tend to zero.</figcaption>
</figure>


:::example[🧠 Example 10.6.1 — Applying the AST]
Show $\displaystyle\sum_{n=1}^\infty\frac{(-1)^{n-1}}{n^2}$ converges and determine whether it's absolute or conditional.

**Answer: Converges absolutely.**

**Hand calculation.**
**Step 1 — Check AST conditions.** Here $b_n = 1/n^2$. (i) $b_{n+1} = 1/(n+1)^2 < 1/n^2 = b_n$ ✓ (ii) $b_n = 1/n^2 \to 0$ ✓. Both hold, so the series converges.

**Step 2 — Check absolute convergence.** $\sum|a_n| = \sum 1/n^2$ is a $p$-series with $p=2>1$. It converges. Therefore the original series is *absolutely* convergent.
:::

:::example[🧠 Example 10.6.2 — Conditional convergence]
Is $\displaystyle\sum_{n=1}^\infty\frac{(-1)^{n-1}}{\sqrt{n}}$ absolutely or conditionally convergent?

**Answer: Conditionally convergent.**

**Hand calculation.**
**AST check:** $b_n = 1/\sqrt{n}$. (i) Decreasing: $1/\sqrt{n+1} < 1/\sqrt{n}$ ✓. (ii) $1/\sqrt{n} \to 0$ ✓. Converges.

**Absolute convergence check:** $\sum 1/\sqrt{n} = \sum n^{-1/2}$ is a $p$-series with $p=1/2 < 1$. Diverges. So the series is only conditionally convergent.
:::

:::example[🧠 Example 10.6.3 — Error estimation]
How many terms of $\displaystyle\sum_{n=1}^\infty\frac{(-1)^{n+1}}{n^3} = 1 - \frac{1}{8} + \frac{1}{27} - \cdots$ are needed to estimate the sum within 0.005?

**Answer: $N = 5$ terms suffice.**

**Hand calculation.**
By the Estimation Theorem, the error after $N$ terms is $\le b_{N+1} = \dfrac{1}{(N+1)^3}$. We need:

$$
\frac{1}{(N+1)^3} < 0.005 = \frac{1}{200} \implies (N+1)^3 > 200 \implies N+1 > \sqrt[3]{200} \approx 5.85.
$$

 So $N+1 \ge 6$, meaning $N \ge 5$. Use 5 terms: $1 - 1/8 + 1/27 - 1/64 + 1/125 = 0.9045\ldots$. The true sum is $S = \frac{3\pi^2}{32} - \frac{\pi}{8} + \frac{1}{2}\approx 0.9016$, error $\approx 0.003 < b_6 = 1/216 \approx 0.0046$. ✓
:::

:::example[🧠 Example 10.6.4 — When AST conditions fail]
Does $\displaystyle\sum_{n=1}^\infty(-1)^{n-1}\frac{n}{n+1}$ converge?

**Answer: Diverges.**

**Hand calculation.**
Check the $n$-th Term Test first: $\lim_{n\to\infty}\frac{n}{n+1} = 1 \ne 0$. Since the terms don't go to zero, the series diverges immediately. You don't even need the AST.
:::

::::problem[Problem 10.6.1 easy]{difficulty=easy}
Test $\displaystyle\sum_{n=1}^\infty\frac{(-1)^n}{n+3}$ for convergence.

:::solution[Solution]
**Answer:** Converges conditionally.

1. **Method: Alternating Series Test (AST).** Separate the sign and magnitude: $a_n=(-1)^nb_n$ with $b_n=1/(n+3)>0$ for every $n\ge1$.

2. **Check decreasing magnitudes.** Because $n+4>n+3>0$,

   $$
   b_{n+1}=\frac1{n+4}<\frac1{n+3}=b_n.
   $$

   Also $\lim_{n\to\infty}b_n=0$ because the denominator grows without bound. Thus all AST conditions are satisfied, and the alternating series converges.

3. **Test absolute convergence separately.** The absolute series is $\sum_{n=1}^\infty1/(n+3)=\sum_{k=4}^\infty1/k$, the harmonic series with only three starting terms removed. It diverges.

4. **Conclusion.** The original series converges by AST but not absolutely, so it is **conditionally convergent**.
:::
::::
::::problem[Problem 10.6.2 standard]{difficulty=standard}
How many terms of $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n}{n!}$ are needed to approximate the sum $e^{-1}$ within $0.001$?

:::solution[Solution]
**Answer:** 7 terms, indices 0 through 6.

1. **Method: Alternating Series Estimation Theorem.** Write $b_n=1/n!$. For $n\ge0$, $b_n>0$; also $b_{n+1}/b_n=1/(n+1)\le1$, and $b_n\to0$. Hence the alternating error bound applies.

2. **State the remainder estimate.** If $S_N$ sums indices $0$ through $N$, there are $N+1$ terms and

   $$
   |e^{-1}-S_N|\le b_{N+1}=\frac1{(N+1)!}.
   $$

3. **Choose the first sufficient index.** We require $1/(N+1)!<1/1000$. Since $6!=720<1000$ but $7!=5040>1000$, take $N+1=7$, or $N=6$:

   $$
   |e^{-1}-S_6|\le\frac1{5040}<\frac1{1000}.
   $$

4. **Conclusion.** Seven terms, from $n=0$ through $n=6$, guarantee an error below $0.001$.
:::
::::
::::problem[Problem 10.6.3 standard]{difficulty=standard}
Classify $\displaystyle\sum_{n=1}^\infty\frac{(-1)^n}{\ln(n+1)}$ as absolutely convergent, conditionally convergent, or divergent.

:::solution[Solution]
**Answer:** Converges conditionally.

1. **Method: Alternating Series Test.** Let $b_n=1/\ln(n+1)$. For $n\ge1$, $\ln(n+1)>0$, so $b_n>0$. Because $\ln(n+2)>\ln(n+1)$, we have $b_{n+1}< b_n$.

2. **Check the term limit.** As $n\to\infty$, $\ln(n+1)\to\infty$, so $b_n\to0$. The three AST conditions hold; therefore the alternating series converges.

3. **Test its absolute series.** For $n\ge1$, the inequality $\ln(n+1)\le n$ follows from $\ln t\le t-1$ with $t=n+1$. Thus

   $$
   \frac1{\ln(n+1)}\ge\frac1n>0.
   $$

   The harmonic series $\sum1/n$ diverges, so Direct Comparison shows the absolute series diverges.

4. **Conclusion.** The given series is **conditionally convergent**, not absolutely convergent.
:::
::::
::::problem[Problem 10.6.4 challenge]{difficulty=challenge}
For $\displaystyle S = \sum_{n=1}^\infty\frac{(-1)^{n+1}}{n^2}$, find an $N$ such that $S_N$ approximates $S = \pi^2/12$ with error less than $0.01$, and compute that approximation.

:::solution[Solution]
**Answer:** $N=10$ terms guarantee error below 0.01; $S_{10}\approx0.817962$.

1. **Method: Alternating Series Estimation Theorem.** Here $b_n=1/n^2>0$, $b_{n+1}< b_n$, and $b_n\to0$. The series satisfies AST, so after summing through $n=N$,

   $$
   |S-S_N|\le b_{N+1}=\frac1{(N+1)^2}.
   $$

2. **Find the required number of terms.** We want $1/(N+1)^2<0.01=1/100$. Hence $(N+1)^2>100$ and $N+1>10$. The smallest integer choice is $N=10$.

3. **Write the approximation.**

   $$
   S_{10}=1-\frac14+\frac19-\frac1{16}+\frac1{25}
   -\frac1{36}+\frac1{49}-\frac1{64}+\frac1{81}-\frac1{100}
   \approx0.817962.
   $$

   The error is at most $1/11^2=1/121<1/100$.

4. **Conclusion.** Ten terms give the stated approximation with a rigorous error smaller than $0.01$.
:::
::::

### Three hypotheses, then a second question

For an alternating series $\sum(-1)^n b_n$ or $\sum(-1)^{n+1}b_n$, first rewrite it so $b_n$ is **nonnegative**. The Alternating Series Test needs: $b_n>0$ eventually; $b_n$ decreases eventually; and $b_n\to0$. Write all three, not a check mark without a justification. Often the decrease is obvious from a growing denominator; for a quotient with $n$ in both places, differentiate the continuous extension and check its sign.

After the series converges by AST, ask the separate question: does $\sum|a_n|=\sum b_n$ converge? If yes, say **absolutely convergent**. If no, say **conditionally convergent**. If the original series does not converge, say **divergent**, not conditional. These three labels are mutually exclusive. As a shortcut, if a suitable positive comparison establishes absolute convergence, AST is unnecessary for convergence itself, although its conditions may still be worth recognizing.

### What if the term limit is not zero?

For $a_n=(-1)^{n-1}\frac{n}{n+1}$, the positive magnitude $b_n=n/(n+1)$ approaches 1, not zero. The terms alternate between values near $1$ and $-1$; their limit does not exist. The nth-term test gives immediate divergence. Checking the alternating sign alone never establishes the AST result. If the magnitudes decrease but level off at a positive constant, AST still fails.

:::callout-pitfall[The three-way classification trap]
“Converges by AST” and “converges conditionally” are **not** synonymous. The series $\sum(-1)^n/n^2$ converges absolutely because $\sum1/n^2$ converges. Check absolute values after applying AST, and do not claim absolute convergence merely because $|a_n|\to0$.
:::

:::example[Example 10.6.5 — Distinguish conditional from absolute]
Classify $\sum_{n=1}^\infty\frac{(-1)^{n-1}}{\sqrt{n^2+9}}$.

**Answer: $\text{Conditionally convergent}$.**


Set $b_n=1/\sqrt{n^2+9}$. First, $b_n>0$ for $n\ge1$. Second, as $n$ increases, $n^2+9$ increases, so $b_{n+1}< b_n$. Third,

$$
\lim_{n\to\infty}b_n
=\lim_{n\to\infty}\frac{1/n}{\sqrt{1+9/n^2}}=0.
$$
All three AST conditions hold, so the **signed** series converges. Test absolute convergence with $c_n=1/n$:

$$
\lim_{n\to\infty}\frac{b_n}{c_n}
=\lim_{n\to\infty}\frac{n}{\sqrt{n^2+9}}
=\lim_{n\to\infty}\frac1{\sqrt{1+9/n^2}}=1.
$$
Since $\sum1/n$ diverges and the LCT limit is finite positive, $\sum b_n$ diverges. Thus the signed series is **conditional**, not absolute.

:::

::::problem[Problem 10.6.5 — AST and absolute status]{difficulty=standard}
Classify $\sum_{n=1}^\infty(-1)^{n-1}/n^{3/2}$ and show the three AST conditions.

:::solution[Solution]
**Answer:** $\text{Absolutely convergent}$.

1. **Method: Alternating Series Test (AST).** Write $a_n=(-1)^{n-1}b_n$, where $b_n=n^{-3/2}$. The AST hypotheses are $b_n>0$, decreasing magnitudes, and $b_n\to0$.

2. **Check all three hypotheses.** For $n\ge1$, $b_n=1/n^{3/2}>0$. Since $n+1>n$,

   $$
   b_{n+1}=\frac1{(n+1)^{3/2}}<\frac1{n^{3/2}}=b_n.
   $$

   Finally, $n^{3/2}\to\infty$ implies $b_n\to0$. Thus AST establishes convergence.

3. **Check absolute convergence.** Taking absolute values removes the sign:

   $$
   \sum_{n=1}^\infty|a_n|=\sum_{n=1}^\infty\frac1{n^{3/2}}.
   $$

   This $p$-series converges because $p=3/2>1$.

4. **Conclusion.** The series is **absolutely convergent**, which is stronger than merely satisfying AST.
:::
::::

::::problem[Problem 10.6.6 — Failure of term test]{difficulty=challenge}
Classify $\sum_{n=1}^\infty(-1)^n\frac{2n+3}{2n+5}$. Explain why an alternating sign is insufficient.

:::solution[Solution]
**Answer:** $\text{Divergent}$.

1. **Method: nth-term test.** An alternating sign alone cannot make a series converge; its unsigned magnitudes must at least approach zero. Set $b_n=(2n+3)/(2n+5)>0$.

2. **Compute the magnitude limit.** Divide numerator and denominator by $n$:

   $$
   \lim_{n\to\infty}b_n=\lim_{n\to\infty}\frac{2+3/n}{2+5/n}=\frac22=1\ne0.
   $$

3. **Check the signed terms.** When $n=2k$ is even, $a_{2k}=b_{2k}\to1$. When $n=2k+1$ is odd, $a_{2k+1}=-b_{2k+1}\to-1$. These subsequences have different limits, so $a_n$ has no limit, in particular not zero.

4. **Conclusion.** The series diverges by the nth-term test. AST fails because the magnitude tends to $1$, not $0$.
:::
::::

### The three conditions are separate proof obligations

The Alternating Series Test applies to $\sum(-1)^nb_n$ or $\sum(-1)^{n+1}b_n$ when $b_n>0$, $b_n$ is eventually nonincreasing, and $b_n\to0$. Write down all three checks. The fact that a term contains $(-1)^n$ does not force convergence: if $b_n=1$, the partial sums oscillate between two values forever. Conversely, if the sign is alternating and $b_n=1/n$, the terms shrink to zero and AST gives convergence despite the divergence of the positive harmonic series.

When $b_n$ is rational, show monotonicity without overcomplicating it. For $b_n=1/(n+3)$, the denominator increases as $n$ increases, so $b_{n+1}< b_n$. For $b_n=n/(n^2+1)$, monotonicity may require a derivative or a direct inequality; it is unsafe to state it without a check. In fact, the continuous derivative is $(1-x^2)/(x^2+1)^2$, nonpositive once $x\ge1$. That establishes the needed eventual decrease.

### Conditional convergence is a second, independent decision

After AST says convergent, the problem may not be finished. If the instruction says “absolute, conditional, or divergent,” remove the sign factor and test $\sum|a_n|$. An absolutely convergent alternating series is still **absolutely** convergent; do not label it conditional just because it alternates. Conditional means both statements hold: the signed series converges and the absolute-value series diverges.

For example, $\sum(-1)^{n+1}/\sqrt n$ has $b_n=n^{-1/2}\to0$, and its positive magnitudes decrease. AST proves convergence. But $\sum|(-1)^{n+1}/\sqrt n|=\sum n^{-1/2}$ is a divergent $p$-series because $p=1/2\le1$. That establishes **conditional** convergence with two distinct tests. If the power were $2$ instead, the absolute series $\sum1/n^2$ would converge, so the signed series would converge absolutely. The sign pattern is the same; the magnitude's decay rate makes the difference.

The alternating-series error estimate is a useful extra technique, **not on Test 4** according to the supplied scope notes. If you do use it while studying, label the partial sum carefully: $S_N=\sum_{n=1}^N a_n$ has first omitted term $a_{N+1}$, and the error obeys $|S-S_N|\le b_{N+1}$ under the AST hypotheses. Be precise about whether the requested inequality says strictly less than or less than or equal to a threshold. An omitted term exactly equal to the threshold does not meet a strict inequality.

### Write the decreasing proof at the right level

When you apply AST to a factor of the form $b_n=1/[n(\ln n)^p]$ for $n\ge2$, inspect the denominator. For $p>0$, both $n$ and $\ln n$ increase on that domain, so their positive product increases and its reciprocal decreases. That is a valid monotonicity argument without differentiating a messy quotient. The remaining limit is $b_n\to0$ because the denominator grows without bound. If $p=0$, the same logic reduces to $1/n$. If $p<0$, the product expression needs more care because $(\ln n)^p$ decreases; a routine assertion of monotonicity is no longer justified.

The test also does not care whether the first sign is plus or minus. Replacing $(-1)^n$ by $(-1)^{n+1}$ negates each partial sum and therefore negates the limiting total, but leaves convergence classification unchanged. What matters is that the terms alternate after any finite starting segment and that their **positive magnitudes** eventually decrease to zero. In a short solution, a three-line checklist reading “positive, decreasing, limit zero” followed by the named test is much stronger than simply writing “alternating, so converges.”


## 10.7 Power Series

**Thomas 10.7 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Power series | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition — series that depend on $x$]
Everything up to now has been about series of fixed numbers. A **power series** introduces a variable $x$: each term involves a power of $(x-a)$, so the series becomes a function of $x$. Think of it as an infinitely long polynomial.

The central new question is: *for which values of $x$ does this polynomial converge?* The answer always has the same shape: a symmetric interval centered at $a$. Inside the interval, the series converges absolutely. Outside it, the series diverges. At the endpoints, you must check individually — anything can happen there.

The half-length of this interval is the **radius of convergence** $R$. When $R = \infty$, the series converges for all $x$. When $R = 0$, it converges only at the center $x = a$.
:::

:::definition[Definition 2.4 — Power Series]
A **power series centered at $a$** is a series of the form:

$$
\sum_{n=0}^\infty c_n(x-a)^n = c_0 + c_1(x-a) + c_2(x-a)^2 + c_3(x-a)^3 + \cdots
$$

 where the **coefficients** $c_n$ are constants and $a$ is the **center**. When $a=0$ this simplifies to $\sum c_n x^n$.
:::

### Finding the Radius of Convergence

Apply the Ratio Test to the power series. The key step is treating $x$ as a parameter — it comes out of the limit, leaving you with a condition on $|x-a|$.

Concretely: compute $L = \lim_{n\to\infty}\left|\dfrac{c_{n+1}(x-a)^{n+1}}{c_n(x-a)^n}\right| = |x-a|\cdot\lim_{n\to\infty}\left|\dfrac{c_{n+1}}{c_n}\right|$. Call the coefficient limit $\rho = \lim|c_{n+1}/c_n|$. Then:

 If $\rho \ne 0$: $R = 1/\rho$, and the series converges absolutely on $(a-R,\,a+R)$.
 If $\rho = 0$: $R = \infty$, converges for all $x$.
 If $\rho = \infty$: $R = 0$, converges only at $x=a$.

:::callout-pitfall[⚠ The Endpoint Trap — Never Skip This Step]
The Ratio Test gives you an *open* interval $(a-R, a+R)$. The endpoints $x = a\pm R$ are a separate question. At each endpoint, you plug in that specific value of $x$, which turns the power series into an ordinary series of constants. Then you test that constant series using any appropriate method (AST, $p$-series, etc.).

Each endpoint can independently converge or diverge, so the interval of convergence may be open $(a-R, a+R)$, closed $[a-R, a+R]$, or half-open $[a-R, a+R)$ or $(a-R, a+R]$. You must check both.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Convergence interval centered at a with two endpoints">
<path class="fig-axis" d="M 20 135 L 380 135"/>
<path class="fig-curve" d="M 110 135 L 290 135"/>
<path class="fig-point" d="M 110 135 l 0.1 0"/>
<path class="fig-point" d="M 290 135 l 0.1 0"/>
<text class="fig-label" x="105" y="160">a−R</text><text class="fig-label" x="198" y="160">a</text><text class="fig-label" x="285" y="160">a+R</text>
</svg>
<figcaption>A power series can converge inside $|x-a|< R$ while either endpoint behaves differently; both endpoints must be tested separately.</figcaption>
</figure>


:::example[🧠 Example 10.7.1 — Basic power series centered at 0]
Find the radius and interval of convergence of $\displaystyle\sum_{n=1}^\infty\frac{x^n}{n\cdot 2^n}$.

**Answer: $R = 2$; interval $[-2, 2)$.**

**Hand calculation.**
**Step 1 — Ratio Test.** $c_n = 1/(n\cdot 2^n)$. Ratio of successive terms:

$$
\left|\frac{x^{n+1}/(n+1)2^{n+1}}{x^n/n\cdot 2^n}\right| = |x|\cdot\frac{1}{2}\cdot\frac{n}{n+1} \to \frac{|x|}{2}.
$$

 Converges when $|x|/2 < 1$, i.e., $|x| < 2$. So $R = 2$, open interval $(-2, 2)$.

**Step 2 — Endpoint $x = 2$.** The series becomes $\displaystyle\sum_{n=1}^\infty\frac{2^n}{n\cdot 2^n} = \sum_{n=1}^\infty\frac{1}{n}$, the harmonic series. **Diverges.**

**Step 3 — Endpoint $x = -2$.** The series becomes $\displaystyle\sum_{n=1}^\infty\frac{(-2)^n}{n\cdot 2^n} = \sum_{n=1}^\infty\frac{(-1)^n}{n}$, the alternating harmonic series. By AST, **converges.**

**Conclusion:** Interval of convergence is $[-2, 2)$. Include $-2$, exclude $2$.
:::

:::example[🧠 Example 10.7.2 — Power series centered at $a = 3$]
Find the radius and interval of convergence of $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n(x-3)^n}{n+1}$.

**Answer: $R = 1$; interval $(2, 4]$.**

**Hand calculation.**
**Ratio Test.** Let $u = x-3$ for clarity:

$$
\left|\frac{(-1)^{n+1}u^{n+1}/(n+2)}{(-1)^n u^n/(n+1)}\right| = |u|\cdot\frac{n+1}{n+2} \to |u| = |x-3|.
$$

 Converges when $|x-3| < 1$, i.e., $2 < x < 4$. So $R=1$.

**Endpoint $x = 4$ ($u=1$):** $\displaystyle\sum\frac{(-1)^n}{n+1}$. By AST: $b_n = 1/(n+1)$ decreasing and $\to 0$. **Converges.**

**Endpoint $x = 2$ ($u=-1$):** $\displaystyle\sum\frac{(-1)^n(-1)^n}{n+1} = \sum\frac{1}{n+1}$. Harmonic series. **Diverges.**

**Conclusion:** Interval $(2, 4]$. Exclude $2$, include $4$.
:::

:::example[🧠 Example 10.7.3 — Infinite radius]
Find the radius of convergence of $\displaystyle\sum_{n=0}^\infty\frac{x^n}{n!}$.

**Answer: $R = \infty$ — converges for all $x \in \mathbb{R}$.**

**Hand calculation.**
Ratio: $\left|\dfrac{x^{n+1}/(n+1)!}{x^n/n!}\right| = \dfrac{|x|}{n+1} \to 0$ for any fixed $x$. Since $L = 0 < 1$ regardless of $x$, the series converges for all real $x$. No endpoints to check. This is the Maclaurin series for $e^x$.
:::

::::problem[Problem 10.7.1 easy]{difficulty=easy}
Find $R$ for $\displaystyle\sum_{n=0}^\infty n!\,x^n$.

:::solution[Solution]
**Answer:** $R=0$; only $x=0$.

1. **Method: Ratio Test for a power series.** For fixed $x$, let $a_n=n!x^n$. Factorials make the ratio particularly simple.

2. **Compute the absolute ratio.** If $x\ne0$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\left|\frac{(n+1)!x^{n+1}}{n!x^n}\right|
   =(n+1)|x|.
   $$

3. **Classify nonzero $x$.** For any fixed $|x|>0$, the ratio tends to $+\infty>1$. The Ratio Test proves divergence at every nonzero $x$.

4. **Test $x=0$ separately.** The series becomes $1+0+0+\cdots$, because $0!x^0=1$ by the constant term convention. It converges to $1$.

5. **Conclusion.** The convergence set is the single point $x=0$, so the radius of convergence is $R=0$.
:::
::::
::::problem[Problem 10.7.2 standard]{difficulty=standard}
Find the interval of convergence of $\displaystyle\sum_{n=1}^\infty\frac{(-3)^n x^n}{\sqrt{n}}$.

:::solution[Solution]
**Answer:** $R=1/3$; interval $(-1/3,1/3]$.

1. **Method: Ratio Test.** Set $a_n=(-3x)^n/\sqrt n$. For $x\ne0$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =3|x|\sqrt{\frac n{n+1}}\longrightarrow3|x|.
   $$

   The series converges absolutely when $3|x|<1$, giving $-1/3< x<1/3$ and $R=1/3$. At $x=0$ it trivially converges.

2. **Check the right endpoint.** If $x=1/3$, $a_n=(-1)^n/\sqrt n$. Its magnitudes are positive, decreasing, and tend to zero, so AST proves convergence.

3. **Check the left endpoint.** If $x=-1/3$, $a_n=1/\sqrt n$. This is a divergent $p$-series because $p=1/2\le1$.

4. **Conclusion.** Include $x=1/3$ and exclude $x=-1/3$. The interval is $(-1/3,1/3]$.
:::
::::
::::problem[Problem 10.7.3 standard]{difficulty=standard}
Find the interval of convergence of $\displaystyle\sum_{n=1}^\infty\frac{(x+2)^n}{n^2\cdot 5^n}$.

:::solution[Solution]
**Answer:** $R=5$; interval $[-7,3]$.

1. **Method: Ratio Test.** Write $a_n=(x+2)^n/(n^25^n)$. For $x\ne-2$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\frac{|x+2|}{5}\frac{n^2}{(n+1)^2}
   \longrightarrow\frac{|x+2|}{5}.
   $$

2. **Find the open interval.** Convergence holds for $|x+2|/5<1$, or $-5< x+2<5$, hence $-7< x<3$. The center is $-2$ and $R=5$.

3. **Check $x=3$.** The series becomes $\sum1/n^2$, which converges by the $p$-series test ($p=2>1$).

4. **Check $x=-7$.** The series becomes $\sum(-1)^n/n^2$; the absolute series $\sum1/n^2$ converges. Thus this endpoint is included as well.

5. **Conclusion.** The full interval of convergence is $[-7,3]$.
:::
::::

### Endpoint testing is a second convergence problem

Treat the Ratio Test as a way to obtain an **open** interval. It does not choose the brackets. When the inequality is $|x-a|< R$, the candidates are $x=a-R$ and $x=a+R$. Put each into the **original series**, simplify the numerical series and apply an appropriate test. An alternating harmonic series at one endpoint and a harmonic series at the other are common. A series with $1/n^2$ at both endpoints may include both, while one with terms $1$ or $(-1)^n$ at its endpoints excludes them.

Three radius outcomes must be distinguished: $R=0$ means convergence only at the center $x=a$ for an ordinary power series, because higher terms vanish there; $0< R<\infty$ means test two endpoints; and $R=\infty$ means convergence for every real $x$, so there are no finite endpoints to test. The radius is a **nonnegative number or infinity**, while the interval is a **set of $x$-values**. Reporting just $R=3$ when the question asks for an interval loses information.

:::callout-tip[Written-paper endpoint table]
Make two little columns labeled $x=a-R$ and $x=a+R$. For each, write the substituted series, name the convergence test, and mark include or exclude. Only after these two tests write the final bracketed interval. This avoids the classic error of copying the Ratio Test’s strict inequality as the entire answer.
:::

:::example[Example 10.7.4 — Endpoint decisions differ]
Find $R$ and the full interval for $\sum_{n=1}^\infty\frac{(x+2)^n}{n5^n}$.

**Answer: $R=5$, interval $[-7,3)$.**


Let $a_n=(x+2)^n/(n5^n)$. The Ratio Test gives

$$
\begin{aligned}
L&=\lim_{n\to\infty}\left|\frac{(x+2)^{n+1}}{(n+1)5^{n+1}}\frac{n5^n}{(x+2)^n}\right|\\
&=\lim_{n\to\infty}\frac{|x+2|}{5}\frac{n}{n+1}=\frac{|x+2|}{5}.
\end{aligned}
$$
Thus $|x+2|<5$, or $-7< x<3$, and the radius is $5$. At $x=-7$, the original series becomes $\sum(-1)^n/n$, which converges by AST: positive magnitudes $1/n$ decrease to zero. At $x=3$, it becomes $\sum1/n$, the divergent harmonic series. Therefore include $-7$ and exclude $3$: $[-7,3)$.

:::

:::example[Example 10.7.5 — Radius zero]
Find the convergence set of $\sum_{n=1}^\infty n!(x-1)^n$.

**Answer: $R=0$; converges only at $x=1$.**


Use Ratio Test away from the center:

$$
L=\lim_{n\to\infty}\left|\frac{(n+1)!(x-1)^{n+1}}{n!(x-1)^n}\right|
=\lim_{n\to\infty}(n+1)|x-1|.
$$
For any $x\ne1$, this equals $\infty>1$, hence divergence. At $x=1$, every term is $n!\cdot0^n=0$ for $n\ge1$, so the sum is $0$ and converges. Radius zero, convergence set $\{1\}$.

:::

::::problem[Problem 10.7.4 — Both endpoints included]{difficulty=standard}
Find the radius and interval of $\sum_{n=1}^\infty\frac{(x-4)^n}{n^2 3^n}$.

:::solution[Solution]
**Answer:** $R=3$; interval $[1,7]$.

1. **Method: Ratio Test.** Let $a_n=(x-4)^n/(n^23^n)$. For $x\ne4$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\left|\frac{(x-4)^{n+1}}{(n+1)^23^{n+1}}
   \frac{n^23^n}{(x-4)^n}\right|
   =\frac{|x-4|}{3}\frac{n^2}{(n+1)^2}.
   $$

2. **Find the radius.** The last factor tends to $1$, so $L=|x-4|/3$. Require $L<1$: $|x-4|<3$, equivalent to $1< x<7$. Thus $R=3$.

3. **Test endpoints separately.** At $x=1$, the series is $\sum(-1)^n/n^2$, absolutely convergent because $\sum1/n^2$ converges. At $x=7$, it is $\sum1/n^2$, convergent by $p=2>1$.

4. **Conclusion.** Both endpoints belong to the interval, so the answer is $[1,7]$.
:::
::::

::::problem[Problem 10.7.5 — Radius infinity]{difficulty=easy}
Find $R$ and the convergence interval for $\sum_{n=0}^\infty\frac{(2x)^n}{n!}$.

:::solution[Solution]
**Answer:** $R=\infty$, interval $(-\infty,\infty)$.

1. **Method: Ratio Test.** Fix any real $x$ and let $a_n=(2x)^n/n!$. When $x\ne0$, the factorials cancel in the successive-term ratio.

2. **Compute the absolute ratio.**

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\left|\frac{(2x)^{n+1}}{(n+1)!}\frac{n!}{(2x)^n}\right|
   =\frac{|2x|}{n+1}.
   $$

3. **Take the limit and check conditions.** For any fixed real $x$, the numerator $|2x|$ is constant while the denominator tends to infinity. Thus $L=0<1$, proving absolute convergence. At $x=0$ the series is simply $1$, so it converges there too.

4. **Conclusion.** Every real $x$ is allowed, giving radius $R=\infty$ and interval $(-\infty,\infty)$. There are no finite endpoints to check.
:::
::::

::::problem[Problem 10.7.6 — Endpoint trap]{difficulty=challenge}
Find the interval for $\sum_{n=1}^\infty\frac{(-1)^n(x-2)^n}{n4^n}$.

:::solution[Solution]
**Answer:** $(-2,6]$.

1. **Method: Ratio Test for the interior.** Let $a_n=(-1)^n(x-2)^n/(n4^n)$. For $x\ne2$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\frac{|x-2|}{4}\frac n{n+1}
   \longrightarrow\frac{|x-2|}{4}.
   $$

2. **Solve the inequality.** Require $|x-2|/4<1$, so $-4< x-2<4$, which is $-2< x<6$. The endpoints remain undecided because $L=1$ there.

3. **Test the left endpoint.** At $x=-2$, $(-1)^n(-4)^n/(n4^n)=1/n$. The harmonic series diverges, so exclude $-2$.

4. **Test the right endpoint.** At $x=6$, the series is $\sum(-1)^n/n$. The magnitudes $1/n$ decrease to zero, so AST gives convergence; include $6$.

5. **Conclusion.** The interval of convergence is $(-2,6]$.
:::
::::

### First find the radius; only then decide the endpoints

Treat a power series as a family of numerical series, one for each fixed $x$. The Ratio or Root Test normally produces an inequality involving $|x-a|$. Convert that inequality into an **open** interval as your first stage. The ratio/root limit is usually exactly one at each boundary, so it deliberately cannot decide whether those two endpoints belong. That is why the final interval must be determined in a second stage using whatever numerical-series tests apply after substitution.

In a power series $\sum_{n=1}^{\infty}(x-3)^n/[n2^n]$, compare consecutive absolute terms:

$$
\left|\frac{a_{n+1}}{a_n}\right|
=\left|\frac{x-3}{2}\right|\frac{n}{n+1}
\longrightarrow\frac{|x-3|}{2}.
$$

The interior condition $|x-3|/2<1$ means $|x-3|<2$, or $1< x<5$. Now substitute **both** endpoints into the original series: at $x=1$, the term becomes $(-1)^n/n$, convergent by AST; at $x=5$, it becomes $1/n$, divergent. Therefore the endpoint decision is asymmetric even though both endpoints are the same distance from the center. If you had written the final interval before doing these substitutions, you would have missed this distinction.

### What R=0 and R=infinity actually mean

A radius of zero is not an empty convergence set: a standard power series always converges at its center $x=a$ when the terms have nonnegative integer powers of $x-a$ and the coefficients are finite. The correct interval is then the single point $\{a\}$. A radius of infinity means the series converges for every real $x$, so there are **no finite endpoints** to check. A factorial denominator such as $(x-a)^n/n!$ typically gives an infinite radius because the ratio includes $|x-a|/(n+1)\to0$ for every fixed $x$. A numerator containing a factorial may instead give radius zero, since its ratio can grow like $n|x-a|$ for any $x\ne a$.

Do not confuse the radius with the interval. A radius is a nonnegative distance (or infinity); the interval includes or excludes specific endpoints according to the actual boundary series. Write your concluding answer in interval notation with brackets only for endpoints proved convergent. When $R=0$, say the single convergence point explicitly rather than trying to force it into an empty-looking open interval.

A final mechanical check: if the center is $a=3$ and the radius is $2$, your interior interval must be centered at $3$, namely $(1,5)$, not $(-2,2)$. The latter is a radius inequality accidentally left in the variable $x-a$. Translate to $x$ before testing either endpoint.

### Why the endpoint substitution must use the original term

After a ratio test you may have an inequality such as $|x-a|/R<1$. The expression on the left is a *ratio limit*, not the original series itself. At an endpoint, that limit equals one, but the endpoint series might become harmonic, alternating harmonic, a $p$-series, or even a series whose terms fail to approach zero. Thus you cannot classify an endpoint by substituting into the ratio limit and then declaring “divergent because the ratio equals one.” Start over from $a_n(x)$ with that concrete endpoint inserted.

Also check for signs introduced by odd powers. If the left endpoint gives $(a-R-a)^n=(-R)^n$, an alternating factor often appears; the right endpoint gives $R^n$ and may stay positive. An alternating endpoint is not *automatically* convergent: the remaining positive magnitudes still need to decrease to zero. When both endpoints are complicated, compute one carefully and compare the structure of the other rather than assuming symmetry.

If a radius calculation yields $|x+4|<3$, the center is $-4$, so the interior is $-7< x<-1$. Draw a short number line if you tend to lose a sign when adding or subtracting the center. Finish by stating $R=3$ separately from the final interval, then include or exclude each bracket according to the endpoint tests.


## 10.8 Taylor and Maclaurin Series

**Thomas 10.8 · Test 4.** Write the reason beside each conclusion, not only “converges” or “diverges.”

:::callout-connect
📺 Watch before this section

“Taylor series | Chapter 11, Essence of Calculus” — 3Blue1Brown

“Maclaurin series intuition” — Khan Academy
:::

:::callout-intuition[Intuition — the big idea]
If a function $f$ can be represented as a power series centered at $a$, what must the coefficients be? Plug in $x=a$: $f(a) = c_0$. Differentiate and plug in $x=a$: $f'(a) = c_1$. Differentiate twice: $f''(a) = 2c_2$, so $c_2 = f''(a)/2$. In general, $c_n = f^{(n)}(a)/n!$. This is the Taylor series: a power series whose coefficients are determined entirely by the derivatives of $f$ at a single point.

The deep idea is that if $f$ is "infinitely smooth" at $a$ (all derivatives exist), we can reconstruct $f$ in a neighborhood of $a$ from only local information at that one point. The Taylor polynomial of degree $n$ is the best degree-$n$ polynomial approximation to $f$ near $a$ — it matches $f$ and all its first $n$ derivatives at $x=a$.

When $a=0$, the series is called a **Maclaurin series**. In practice, you almost always build series by manipulating the six standard Maclaurin series rather than computing Taylor coefficients from scratch. Those six are your alphabet — learn them cold.
:::

:::definition[Definition 2.5 — Taylor and Maclaurin Series]
If $f$ has derivatives of all orders at $a$, the **Taylor series of $f$ centered at $a$** is:

$$
\sum_{n=0}^\infty\frac{f^{(n)}(a)}{n!}(x-a)^n = f(a) + f'(a)(x-a) + \frac{f''(a)}{2!}(x-a)^2 + \frac{f'''(a)}{3!}(x-a)^3 + \cdots
$$

 When $a=0$, this is the **Maclaurin series**: $\displaystyle\sum_{n=0}^\infty\frac{f^{(n)}(0)}{n!}x^n$.
:::

### The Six Maclaurin Series to Memorize

**Test 4 scope:** the first four nonzero terms and degree-zero through degree-three Taylor polynomials. Full closed-form power-series proofs and remainder bounds are not required.

These are the building blocks. Know them without hesitation. Every other series in this course is built by manipulating these six.

| Function | Maclaurin Series | $R$ |
| --- | --- | --- |
| $e^x$ | $\displaystyle\sum_{n=0}^\infty\frac{x^n}{n!} = 1 + x + \frac{x^2}{2!} + \frac{x^3}{3!} + \cdots$ | $\infty$ |
| $\sin x$ | $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{(2n+1)!} = x - \frac{x^3}{3!} + \frac{x^5}{5!} - \cdots$ | $\infty$ |
| $\cos x$ | $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n x^{2n}}{(2n)!} = 1 - \frac{x^2}{2!} + \frac{x^4}{4!} - \cdots$ | $\infty$ |
| $\dfrac{1}{1-x}$ | $\displaystyle\sum_{n=0}^\infty x^n = 1 + x + x^2 + x^3 + \cdots$ | $1$ |
| $\ln(1+x)$ | $\displaystyle\sum_{n=1}^\infty\frac{(-1)^{n-1}x^n}{n} = x - \frac{x^2}{2} + \frac{x^3}{3} - \cdots$ | $1$ (incl. $x=1$) |
| $\arctan x$ | $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{2n+1} = x - \frac{x^3}{3} + \frac{x^5}{5} - \cdots$ | $1$ (incl. $\pm 1$) |

:::callout-connect[🔁 Memory trick for $\sin$ and $\cos$]
$\sin x$ has only odd powers, alternating in sign starting positive. $\cos x$ has only even powers, alternating starting positive. This is because $\sin$ is an odd function (all even-power coefficients vanish) and $\cos$ is even (all odd-power coefficients vanish). Euler's formula $e^{ix} = \cos x + i\sin x$ interleaves them perfectly.
:::

### How to derive a Taylor series from scratch

When manipulation won't work (e.g., the function is centered at $a \ne 0$ and substitution isn't clean), compute the Taylor coefficients directly:

1. Compute $f(a), f'(a), f''(a), f'''(a), \ldots$ until you spot a pattern.
2. Write $c_n = f^{(n)}(a)/n!$.
3. Write the series $\sum c_n(x-a)^n$.
4. Find $R$ using the Ratio Test on the general term.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Exponential curve with second degree Taylor polynomial sampled from exact formulas">
<path class="fig-axis" d="M 20 197 L 380 197 M 178 10 L 178 210"/>
<path class="fig-curve" d="M130.0 189.9 L130.4 189.8 L130.7 189.7 L131.1 189.6 L131.5 189.5 L131.8 189.4 L132.2 189.4 L132.6 189.3 L132.9 189.2 L133.3 189.1 L133.7 189.0 L134.0 188.9 L134.4 188.8 L134.8 188.7 L135.1 188.6 L135.5 188.5 L135.9 188.4 L136.2 188.3 L136.6 188.2 L136.9 188.1 L137.3 188.0 L137.7 187.9 L138.0 187.8 L138.4 187.7 L138.8 187.6 L139.1 187.5 L139.5 187.4 L139.9 187.3 L140.2 187.2 L140.6 187.1 L141.0 186.9 L141.3 186.8 L141.7 186.7 L142.1 186.6 L142.4 186.5 L142.8 186.3 L143.2 186.2 L143.5 186.1 L143.9 186.0 L144.3 185.8 L144.6 185.7 L145.0 185.6 L145.4 185.5 L145.7 185.3 L146.1 185.2 L146.5 185.1 L146.8 184.9 L147.2 184.8 L147.6 184.6 L147.9 184.5 L148.3 184.4 L148.7 184.2 L149.0 184.1 L149.4 183.9 L149.7 183.8 L150.1 183.6 L150.5 183.5 L150.8 183.3 L151.2 183.1 L151.6 183.0 L151.9 182.8 L152.3 182.7 L152.7 182.5 L153.0 182.3 L153.4 182.2 L153.8 182.0 L154.1 181.8 L154.5 181.6 L154.9 181.5 L155.2 181.3 L155.6 181.1 L156.0 180.9 L156.3 180.7 L156.7 180.6 L157.1 180.4 L157.4 180.2 L157.8 180.0 L158.2 179.8 L158.5 179.6 L158.9 179.4 L159.3 179.2 L159.6 179.0 L160.0 178.8 L160.4 178.6 L160.7 178.4 L161.1 178.1 L161.5 177.9 L161.8 177.7 L162.2 177.5 L162.5 177.3 L162.9 177.0 L163.3 176.8 L163.6 176.6 L164.0 176.3 L164.4 176.1 L164.7 175.9 L165.1 175.6 L165.5 175.4 L165.8 175.1 L166.2 174.9 L166.6 174.6 L166.9 174.4 L167.3 174.1 L167.7 173.8 L168.0 173.6 L168.4 173.3 L168.8 173.0 L169.1 172.7 L169.5 172.5 L169.9 172.2 L170.2 171.9 L170.6 171.6 L171.0 171.3 L171.3 171.0 L171.7 170.7 L172.1 170.4 L172.4 170.1 L172.8 169.8 L173.2 169.5 L173.5 169.2 L173.9 168.9 L174.3 168.5 L174.6 168.2 L175.0 167.9 L175.3 167.5 L175.7 167.2 L176.1 166.9 L176.4 166.5 L176.8 166.2 L177.2 165.8 L177.5 165.5 L177.9 165.1 L178.3 164.7 L178.6 164.4 L179.0 164.0 L179.4 163.6 L179.7 163.2 L180.1 162.8 L180.5 162.4 L180.8 162.0 L181.2 161.6 L181.6 161.2 L181.9 160.8 L182.3 160.4 L182.7 160.0 L183.0 159.6 L183.4 159.1 L183.8 158.7 L184.1 158.2 L184.5 157.8 L184.9 157.4 L185.2 156.9 L185.6 156.4 L186.0 156.0 L186.3 155.5 L186.7 155.0 L187.1 154.5 L187.4 154.1 L187.8 153.6 L188.1 153.1 L188.5 152.6 L188.9 152.0 L189.2 151.5 L189.6 151.0 L190.0 150.5 L190.3 149.9 L190.7 149.4 L191.1 148.9 L191.4 148.3 L191.8 147.7 L192.2 147.2 L192.5 146.6 L192.9 146.0 L193.3 145.4 L193.6 144.8 L194.0 144.2 L194.4 143.6 L194.7 143.0 L195.1 142.4 L195.5 141.8 L195.8 141.1 L196.2 140.5 L196.6 139.8 L196.9 139.2 L197.3 138.5 L197.7 137.9 L198.0 137.2 L198.4 136.5 L198.8 135.8 L199.1 135.1 L199.5 134.4 L199.9 133.7 L200.2 132.9 L200.6 132.2 L200.9 131.4 L201.3 130.7 L201.7 129.9 L202.0 129.2 L202.4 128.4 L202.8 127.6 L203.1 126.8 L203.5 126.0 L203.9 125.2 L204.2 124.3 L204.6 123.5 L205.0 122.7 L205.3 121.8 L205.7 120.9 L206.1 120.1 L206.4 119.2 L206.8 118.3 L207.2 117.4 L207.5 116.5 L207.9 115.5 L208.3 114.6 L208.6 113.7 L209.0 112.7 L209.4 111.7 L209.7 110.8 L210.1 109.8 L210.5 108.8 L210.8 107.7 L211.2 106.7 L211.6 105.7 L211.9 104.6 L212.3 103.6 L212.7 102.5 L213.0 101.4 L213.4 100.3 L213.7 99.2 L214.1 98.1 L214.5 96.9 L214.8 95.8 L215.2 94.6 L215.6 93.5 L215.9 92.3 L216.3 91.1 L216.7 89.8 L217.0 88.6 L217.4 87.4 L217.8 86.1 L218.1 84.8 L218.5 83.5 L218.9 82.2 L219.2 80.9 L219.6 79.6 L220.0 78.2 L220.3 76.9 L220.7 75.5 L221.1 74.1 L221.4 72.7 L221.8 71.2 L222.2 69.8 L222.5 68.3 L222.9 66.9 L223.3 65.4 L223.6 63.9 L224.0 62.3 L224.4 60.8 L224.7 59.2 L225.1 57.6 L225.5 56.0 L225.8 54.4 L226.2 52.8 L226.5 51.1 L226.9 49.4 L227.3 47.7 L227.6 46.0 L228.0 44.3 L228.4 42.5 L228.7 40.8 L229.1 39.0 L229.5 37.1 L229.8 35.3 L230.2 33.4 L230.6 31.6 L230.9 29.7 L231.3 27.7 L231.7 25.8 L232.0 23.8 L232.4 21.8"/>
<path class="fig-curve-alt" d="M130.0 177.0 L130.4 177.2 L130.7 177.4 L131.1 177.5 L131.5 177.7 L131.8 177.9 L132.2 178.0 L132.6 178.2 L132.9 178.3 L133.3 178.5 L133.7 178.6 L134.0 178.8 L134.4 178.9 L134.8 179.0 L135.1 179.2 L135.5 179.3 L135.9 179.4 L136.2 179.5 L136.6 179.6 L136.9 179.7 L137.3 179.8 L137.7 179.9 L138.0 180.0 L138.4 180.1 L138.8 180.2 L139.1 180.3 L139.5 180.3 L139.9 180.4 L140.2 180.5 L140.6 180.5 L141.0 180.6 L141.3 180.7 L141.7 180.7 L142.1 180.8 L142.4 180.8 L142.8 180.8 L143.2 180.9 L143.5 180.9 L143.9 180.9 L144.3 181.0 L144.6 181.0 L145.0 181.0 L145.4 181.0 L145.7 181.0 L146.1 181.0 L146.5 181.0 L146.8 181.0 L147.2 181.0 L147.6 181.0 L147.9 180.9 L148.3 180.9 L148.7 180.9 L149.0 180.9 L149.4 180.8 L149.7 180.8 L150.1 180.7 L150.5 180.7 L150.8 180.6 L151.2 180.6 L151.6 180.5 L151.9 180.4 L152.3 180.4 L152.7 180.3 L153.0 180.2 L153.4 180.1 L153.8 180.1 L154.1 180.0 L154.5 179.9 L154.9 179.8 L155.2 179.7 L155.6 179.6 L156.0 179.4 L156.3 179.3 L156.7 179.2 L157.1 179.1 L157.4 179.0 L157.8 178.8 L158.2 178.7 L158.5 178.5 L158.9 178.4 L159.3 178.3 L159.6 178.1 L160.0 177.9 L160.4 177.8 L160.7 177.6 L161.1 177.4 L161.5 177.3 L161.8 177.1 L162.2 176.9 L162.5 176.7 L162.9 176.5 L163.3 176.3 L163.6 176.1 L164.0 175.9 L164.4 175.7 L164.7 175.5 L165.1 175.3 L165.5 175.1 L165.8 174.8 L166.2 174.6 L166.6 174.4 L166.9 174.2 L167.3 173.9 L167.7 173.7 L168.0 173.4 L168.4 173.2 L168.8 172.9 L169.1 172.6 L169.5 172.4 L169.9 172.1 L170.2 171.8 L170.6 171.5 L171.0 171.3 L171.3 171.0 L171.7 170.7 L172.1 170.4 L172.4 170.1 L172.8 169.8 L173.2 169.5 L173.5 169.2 L173.9 168.8 L174.3 168.5 L174.6 168.2 L175.0 167.9 L175.3 167.5 L175.7 167.2 L176.1 166.9 L176.4 166.5 L176.8 166.2 L177.2 165.8 L177.5 165.5 L177.9 165.1 L178.3 164.7 L178.6 164.4 L179.0 164.0 L179.4 163.6 L179.7 163.2 L180.1 162.8 L180.5 162.4 L180.8 162.0 L181.2 161.6 L181.6 161.2 L181.9 160.8 L182.3 160.4 L182.7 160.0 L183.0 159.6 L183.4 159.2 L183.8 158.7 L184.1 158.3 L184.5 157.9 L184.9 157.4 L185.2 157.0 L185.6 156.5 L186.0 156.1 L186.3 155.6 L186.7 155.1 L187.1 154.7 L187.4 154.2 L187.8 153.7 L188.1 153.2 L188.5 152.8 L188.9 152.3 L189.2 151.8 L189.6 151.3 L190.0 150.8 L190.3 150.3 L190.7 149.8 L191.1 149.3 L191.4 148.7 L191.8 148.2 L192.2 147.7 L192.5 147.2 L192.9 146.6 L193.3 146.1 L193.6 145.5 L194.0 145.0 L194.4 144.4 L194.7 143.9 L195.1 143.3 L195.5 142.8 L195.8 142.2 L196.2 141.6 L196.6 141.1 L196.9 140.5 L197.3 139.9 L197.7 139.3 L198.0 138.7 L198.4 138.1 L198.8 137.5 L199.1 136.9 L199.5 136.3 L199.9 135.7 L200.2 135.1 L200.6 134.4 L200.9 133.8 L201.3 133.2 L201.7 132.6 L202.0 131.9 L202.4 131.3 L202.8 130.6 L203.1 130.0 L203.5 129.3 L203.9 128.7 L204.2 128.0 L204.6 127.3 L205.0 126.7 L205.3 126.0 L205.7 125.3 L206.1 124.6 L206.4 123.9 L206.8 123.2 L207.2 122.5 L207.5 121.8 L207.9 121.1 L208.3 120.4 L208.6 119.7 L209.0 119.0 L209.4 118.3 L209.7 117.5 L210.1 116.8 L210.5 116.1 L210.8 115.3 L211.2 114.6 L211.6 113.9 L211.9 113.1 L212.3 112.3 L212.7 111.6 L213.0 110.8 L213.4 110.1 L213.7 109.3 L214.1 108.5 L214.5 107.7 L214.8 106.9 L215.2 106.2 L215.6 105.4 L215.9 104.6 L216.3 103.8 L216.7 103.0 L217.0 102.1 L217.4 101.3 L217.8 100.5 L218.1 99.7 L218.5 98.9 L218.9 98.0 L219.2 97.2 L219.6 96.4 L220.0 95.5 L220.3 94.7 L220.7 93.8 L221.1 93.0 L221.4 92.1 L221.8 91.2 L222.2 90.4 L222.5 89.5 L222.9 88.6 L223.3 87.7 L223.6 86.9 L224.0 86.0 L224.4 85.1 L224.7 84.2 L225.1 83.3 L225.5 82.4 L225.8 81.5 L226.2 80.5 L226.5 79.6 L226.9 78.7 L227.3 77.8 L227.6 76.8 L228.0 75.9 L228.4 75.0 L228.7 74.0 L229.1 73.1 L229.5 72.1 L229.8 71.2 L230.2 70.2 L230.6 69.2 L230.9 68.3 L231.3 67.3 L231.7 66.3 L232.0 65.3 L232.4 64.4"/>

</svg>
<figcaption>Near $x=0$, the Maclaurin polynomial $1+x+x^2/2$ tracks $e^x$ closely; the error grows as $x$ moves farther from the center.</figcaption>
</figure>


:::example[🧠 Example 10.8.1 — Deriving the Maclaurin series for $e^x$]
Find the Maclaurin series for $f(x) = e^x$ from scratch.

**Answer: $\displaystyle\sum_{n=0}^\infty\frac{x^n}{n!}$, $R=\infty$.**

**Hand calculation.**
Every derivative of $e^x$ is $e^x$ itself, so $f^{(n)}(x) = e^x$ for all $n$. Evaluate at $a=0$: $f^{(n)}(0) = e^0 = 1$. Therefore $c_n = 1/n!$, and the series is:

$$
e^x = \sum_{n=0}^\infty\frac{x^n}{n!} = 1 + x + \frac{x^2}{2} + \frac{x^3}{6} + \frac{x^4}{24} + \cdots
$$

 Radius: Ratio Test gives $|x|/(n+1)\to 0$, so $R=\infty$. The series converges to $e^x$ for all real $x$.
:::

:::example[🧠 Example 10.8.2 — Substitution]
Find the Maclaurin series for $e^{-x^2}$.

**Answer: $\displaystyle\sum_{n=0}^\infty\frac{(-1)^n x^{2n}}{n!}$, $R=\infty$.**

**Hand calculation.**
Replace $x$ with $-x^2$ in the series for $e^x$:

$$
e^{-x^2} = \sum_{n=0}^\infty\frac{(-x^2)^n}{n!} = \sum_{n=0}^\infty\frac{(-1)^n x^{2n}}{n!} = 1 - x^2 + \frac{x^4}{2} - \frac{x^6}{6} + \cdots
$$

 This function has no elementary antiderivative, but its series can be integrated term by term — critical in statistics and physics.
:::

:::example[🧠 Example 10.8.3 — Taylor series centered at $a\ne 0$]
Find the Taylor series for $f(x) = \cos x$ centered at $a = \pi/2$.

**Answer: $\displaystyle\sum_{n=0}^\infty\frac{(-1)^{n+1}(x-\pi/2)^{2n+1}}{(2n+1)!}$, $R=\infty$.**

**Hand calculation.**
Compute derivatives at $a=\pi/2$:

| $n$ | $f^{(n)}(x)$ | $f^{(n)}(\pi/2)$ | $c_n = f^{(n)}(\pi/2)/n!$ |
| --- | --- | --- | --- |
| 0 | $\cos x$ | 0 | 0 |
| 1 | $-\sin x$ | $-1$ | $-1$ |
| 2 | $-\cos x$ | 0 | 0 |
| 3 | $\sin x$ | 1 | $1/6$ |
| 4 | $\cos x$ | 0 | 0 |

Pattern: nonzero coefficients only at odd $n$, alternating in sign starting $-1$. The series is:

$$
\cos x = -(x-\tfrac{\pi}{2}) + \frac{(x-\pi/2)^3}{3!} - \frac{(x-\pi/2)^5}{5!} + \cdots = \sum_{n=0}^\infty\frac{(-1)^{n+1}(x-\pi/2)^{2n+1}}{(2n+1)!}.
$$

 This makes sense: $\cos x = -\sin(x-\pi/2)$, so it's just the negative sine series centered at $\pi/2$.
:::

:::example[🧠 Example 10.8.4 — Using a series to evaluate a limit]
Evaluate $\displaystyle\lim_{x\to 0}\frac{e^x - 1 - x - x^2/2}{x^3}$.

**Answer: $\dfrac{1}{6}$**

**Hand calculation.**
L'Hôpital would require differentiating three times. The series approach is instant. Substitute $e^x = 1 + x + x^2/2 + x^3/6 + x^4/24 + \cdots$:

$$
\text{Numerator} = \left(1 + x + \frac{x^2}{2} + \frac{x^3}{6} + \cdots\right) - 1 - x - \frac{x^2}{2} = \frac{x^3}{6} + \frac{x^4}{24} + \cdots
$$

 Divide by $x^3$: $\dfrac{x^3/6 + O(x^4)}{x^3} = \dfrac{1}{6} + O(x) \to \dfrac{1}{6}$.
:::

:::example[🧠 Example 10.8.5 — Integrating a series]
Express $\displaystyle\int_0^1 e^{-x^2}\,dx$ as a series and estimate it to 4 decimal places.

**Answer: $\approx 0.7468$**

**Hand calculation.**
From Example 10.8.2, integrate term by term:

$$
\int_0^1 e^{-x^2}\,dx = \sum_{n=0}^\infty\frac{(-1)^n}{n!}\int_0^1 x^{2n}\,dx = \sum_{n=0}^\infty\frac{(-1)^n}{n!(2n+1)}.
$$

 First four terms: $1 - \frac{1}{3} + \frac{1}{10} - \frac{1}{42} + \frac{1}{216} - \cdots$

$$
= 1 - 0.3333 + 0.1000 - 0.0238 + 0.00463 - 0.000758 + \cdots \approx 0.7468.
$$

 This integral equals $\frac{\sqrt\pi}{2}\,\text{erf}(1) \approx 0.74682\ldots$ — verified.
:::

### Taylor's Inequality — Controlling the Error

**Not on Test 4.** Retained because it appears in the original example set.

:::theorem[Theorem 2.14 — Taylor's Inequality]
If $|f^{(n+1)}(x)| \le M$ for all $x$ in an interval containing $a$ and $x_0$, then the remainder $R_n(x_0) = f(x_0) - T_n(x_0)$ satisfies:

$$
|R_n(x_0)| \le \frac{M}{(n+1)!}\,|x_0-a|^{n+1}.
$$

 Here $T_n$ is the degree-$n$ Taylor polynomial and $M$ bounds the $(n+1)$-st derivative on the relevant interval.
:::

To apply this: (1) identify which derivative you need to bound, (2) find a valid bound $M$ on that interval, (3) plug in and solve for the minimum $n$ that meets your accuracy requirement.

:::example[🧠 Example 10.8.6 — Taylor's Inequality in practice]
How many terms of the Maclaurin series for $\sin x$ are needed to approximate $\sin(0.3)$ with error less than $10^{-6}$?

**Answer: 3 terms (the polynomial $T_5$) suffice.**

**Hand calculation.**
The Maclaurin series for $\sin x$ is $x - x^3/6 + x^5/120 - \cdots$. All derivatives of $\sin x$ have $|\text{derivative}| \le 1$, so we can use $M=1$ always. The remainder after the $T_n$ polynomial:

$$
|R_n(0.3)| \le \frac{1}{(n+1)!}(0.3)^{n+1}.
$$

 For $n=5$ (so error involves the $n=6$ term): $\dfrac{(0.3)^7}{7!} = \dfrac{0.0002187}{5040} \approx 4.3\times10^{-8} < 10^{-6}$. ✓
 Three nonzero terms: $0.3 - 0.3^3/6 + 0.3^5/120 = 0.3 - 0.0045 + 0.0000202 \approx 0.295520$. True value: $0.295520\ldots$. ✓
:::

::::problem[Problem 10.8.1 easy]{difficulty=easy}
Write the first 4 nonzero terms and the general term of the Maclaurin series for $\cos(2x)$.

:::solution[Solution]
**Answer:** $1-2x^2+\frac23x^4-\frac4{45}x^6+\cdots$.

1. **Method: substitute into a known Maclaurin series.** The cosine expansion is

   $$
   \cos u=\sum_{n=0}^\infty\frac{(-1)^nu^{2n}}{(2n)!}
   =1-\frac{u^2}{2!}+\frac{u^4}{4!}-\frac{u^6}{6!}+\cdots.
   $$

2. **Set $u=2x$ and simplify each coefficient.**

   $$
   \cos(2x)=1-\frac{4x^2}{2}+\frac{16x^4}{24}-\frac{64x^6}{720}+\cdots
   =1-2x^2+\frac23x^4-\frac4{45}x^6+\cdots.
   $$

3. **Write the general term.** The substitution in the summation gives $\displaystyle\sum_{n=0}^\infty(-1)^n(2x)^{2n}/(2n)!$.

4. **Conclusion.** The four displayed terms are the first four nonzero terms. Because cosine's Maclaurin series converges for every real input, the new series does too.
:::
::::
::::problem[Problem 10.8.2 easy]{difficulty=easy}
Find the Maclaurin series for $f(x) = x^2 e^x$.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty\frac{x^{n+2}}{n!}$.

1. **Method: multiply a known Maclaurin series.** Recall that the exponential function has expansion

   $$
   e^x=\sum_{n=0}^\infty\frac{x^n}{n!}
   =1+x+\frac{x^2}{2!}+\frac{x^3}{3!}+\cdots.
   $$

2. **Multiply every term by $x^2$.**

   $$
   x^2e^x=x^2+x^3+\frac{x^4}{2!}+\frac{x^5}{3!}+\cdots
   =\sum_{n=0}^\infty\frac{x^{n+2}}{n!}.
   $$

3. **Optional index shift.** Setting $k=n+2$ means $n=k-2$; when $n=0$, $k=2$. Thus the identical series is $\sum_{k=2}^\infty x^k/(k-2)!$.

4. **Conclusion.** Either summation form is the Maclaurin series for $x^2e^x$. Multiplication by a polynomial does not change the exponential series' infinite radius of convergence.
:::
::::
::::problem[Problem 10.8.3 standard]{difficulty=standard}
Use Maclaurin series to evaluate $\displaystyle\lim_{x\to 0}\frac{\sin x - x}{x^3}$.

:::solution[Solution]
**Answer:** $-1/6$

1. **Method: Maclaurin expansion.** Both numerator and denominator vanish as $x\to0$, but the question asks for a series method. Use the known sine expansion:

   $$
   \sin x=x-\frac{x^3}{3!}+\frac{x^5}{5!}-\frac{x^7}{7!}+\cdots.
   $$

2. **Subtract $x$ explicitly.**

   $$
   \sin x-x=\left(x-\frac{x^3}{6}+\frac{x^5}{120}-\cdots\right)-x
   =-\frac{x^3}{6}+\frac{x^5}{120}-\cdots.
   $$

3. **Divide every term by $x^3$.** For $x\ne0$,

   $$
   \frac{\sin x-x}{x^3}
   =-\frac16+\frac{x^2}{120}-\frac{x^4}{5040}+\cdots.
   $$

   All terms after the constant approach zero.

4. **Conclusion.** The limit equals $-1/6$. The cancellation of the linear terms is why the cubic term determines the answer.
:::
::::
::::problem[Problem 10.8.4 standard]{difficulty=standard}
Find the Taylor series for $f(x) = \ln x$ centered at $a=1$.

:::solution[Solution]
**Answer:** $\sum_{n=1}^\infty\frac{(-1)^{n-1}(x-1)^n}{n}$ on $(0,2]$.

1. **Method: Taylor coefficients at $a=1$.** Differentiate $f(x)=\ln x$ repeatedly:

   $$
   f'(x)=\frac1x,\quad f''(x)=-\frac1{x^2},\quad
   f^{(3)}(x)=\frac2{x^3},\quad
   f^{(n)}(x)=\frac{(-1)^{n-1}(n-1)!}{x^n}.
   $$

2. **Evaluate at the center and divide by $n!$.** Since $f(1)=0$ and $f^{(n)}(1)=(-1)^{n-1}(n-1)!$,

   $$
   \frac{f^{(n)}(1)}{n!}=\frac{(-1)^{n-1}(n-1)!}{n!}
   =\frac{(-1)^{n-1}}n.
   $$

3. **Determine convergence.** The Ratio Test gives $|x-1|<1$, or $0< x<2$. At $x=2$ the series is alternating harmonic and converges by AST; at $x=0$ it is negative harmonic and diverges.

4. **Conclusion.** The Taylor series and its interval are as stated above; its radius is $R=1$.
:::
::::
::::problem[Problem 10.8.5 challenge]{difficulty=challenge}
How many terms of the Maclaurin series for $e^x$ are needed to compute $e$ correct to 8 decimal places?

:::solution[Solution]
**Answer:** 13 terms (through degree 12), for the specified Taylor remainder guarantee.

At $x=1$, $e^x = \sum 1/n!$. We need $R_n(1) \le M/(n+1)! \cdot 1^{n+1} < 5\times10^{-9}$. Since $e < 3$, use $M=3$: need $3/(n+1)! < 5\times10^{-9}$, i.e., $(n+1)! > 6\times10^8$. Check: $12! = 479001600 \approx 4.8\times10^8$, $13! \approx 6.2\times10^9 > 6\times10^8$. So need $n+1=13$, i.e., $n=12$. Use 13 terms (through $x^{12}/12!$).
:::

::::

### P0, P1, P2, P3: coefficients rather than memorized series

A **Taylor polynomial** is finite. Define $P_0(x)=f(a)$, then add one more derivative-based term each time:

$$
\begin{aligned}
P_1(x)&=f(a)+f'(a)(x-a),\\
P_2(x)&=P_1(x)+\frac{f''(a)}{2}(x-a)^2,\\
P_3(x)&=P_2(x)+\frac{f^{(3)}(a)}{6}(x-a)^3.
\end{aligned}
$$
The factorial denominator is tied to **derivative order**, not “the third nonzero coefficient.” For cosine centered at zero, $P_1=P_0=1$ because the linear coefficient vanishes; $P_3=1-x^2/2$ because the cubic coefficient also vanishes. By contrast, the first four *nonzero* Maclaurin terms of cosine are $1-x^2/2!+x^4/4!-x^6/6!$. These are two different requests. Young’s review uses both wordings; read them carefully.

When the center is not zero, do not change $(x-a)$ to $x$. In $\sqrt{x}$ centered at $a=9$, the polynomial is expressed in powers of $(x-9)$; at $x=9$, all higher-order terms vanish, leaving $P_3(9)=3$, exactly $\sqrt9$. That center check catches many misplaced signs or denominators.

:::callout-pitfall[Polynomial degree versus number of nonzero terms]
$P_3$ always stops at the cubic **power**, even if its cubic coefficient happens to be zero. “First four nonzero Maclaurin terms” keeps going until four nonzero terms have appeared. Distinguish $f^{(3)}(a)/3!$ from $f^{(3)}(a)/3$.
:::

:::example[Example 10.8.7 — P0 through P3 for e^(5x)]
Find $P_0,P_1,P_2,P_3$ for $f(x)=e^{5x}$ centered at $0$.

**Answer: $P_0=1$, $P_1=1+5x$, $P_2=1+5x+\frac{25x^2}{2}$, $P_3=1+5x+\frac{25x^2}{2}+\frac{125x^3}{6}$.**


Use the chain rule at every derivative:

$$
\begin{array}{c|c|c}
\text{order}&f^{(k)}(x)&f^{(k)}(0)\\\hline
0&e^{5x}&1\\
1&5e^{5x}&5\\
2&25e^{5x}&25\\
3&125e^{5x}&125
\end{array}
$$
Insert these into the Taylor formula at $a=0$:

$$
\begin{aligned}
P_0&=1,\\
P_1&=1+5x,\\
P_2&=1+5x+\frac{25}{2!}x^2,\\
P_3&=1+5x+\frac{25}{2!}x^2+\frac{125}{3!}x^3.
\end{aligned}
$$
Since $2!=2$ and $3!=6$, the answer follows. If the prompt instead asks for four nonzero **Maclaurin terms**, these happen to be the same four because none of the coefficients vanish.

:::

:::example[Example 10.8.8 — P3 for sqrt(x) centered at nine]
Find $P_3$ of $f(x)=\sqrt x$ at $a=9$.

**Answer: $P_3(x)=3+\frac{x-9}{6}-\frac{(x-9)^2}{216}+\frac{(x-9)^3}{3888}$.**


Write $f(x)=x^{1/2}$. Differentiate with the power rule, **one order at a time**:

$$
\begin{aligned}
f'(x)&=\tfrac12x^{-1/2},\\
f''(x)&=\tfrac12(-\tfrac12)x^{-3/2}=-\tfrac14x^{-3/2},\\
f^{(3)}(x)&=-\tfrac14(-\tfrac32)x^{-5/2}=\tfrac38x^{-5/2}.
\end{aligned}
$$
At $9$, $9^{1/2}=3$, $9^{3/2}=27$, and $9^{5/2}=243$:

$$f(9)=3,\quad f'(9)=\frac16,\quad f''(9)=-\frac1{108},\quad f^{(3)}(9)=\frac1{648}.$$

Divide the second derivative by $2!=2$, obtaining $-1/216$; divide the third by $3!=6$, obtaining $1/3888$. Substitute into $P_3=f(9)+f'(9)(x-9)+f''(9)(x-9)^2/2!+f^{(3)}(9)(x-9)^3/3!$.

:::

:::example[Example 10.8.9 — P3 for 3 ln x centered at one]
Find $P_0$ through $P_3$ for $f(x)=3\ln x$, $a=1$.

**Answer: $P_0=0$, $P_1=3(x-1)$, $P_2=3(x-1)-\frac32(x-1)^2$, $P_3=3(x-1)-\frac32(x-1)^2+(x-1)^3$.**


Differentiate:

$$f(x)=3\ln x,\quad f'(x)=\frac3x,\quad f''(x)=-\frac3{x^2},\quad f^{(3)}(x)=\frac6{x^3}.$$

At $a=1$ these are $0,3,-3,6$. The constant term is $3\ln1=0$, so the first polynomial is zero. Add derivative terms in order:

$$
\begin{aligned}
P_0&=0,\\P_1&=0+3(x-1),\\
P_2&=3(x-1)-\frac{3}{2!}(x-1)^2,\\
P_3&=3(x-1)-\frac{3}{2}(x-1)^2+\frac{6}{3!}(x-1)^3.
\end{aligned}
$$
Since $6/3!=6/6=1$, simplify the cubic coefficient to 1.

:::

:::example[Example 10.8.10 — P3 for cube root at one]
Find $P_3$ of $f(x)=\sqrt[3]x=x^{1/3}$ centered at $1$.

**Answer: $P_3=1+\frac13(x-1)-\frac19(x-1)^2+\frac5{81}(x-1)^3$.**


The successive power-rule derivatives are

$$
\begin{aligned}
f'(x)&=\frac13x^{-2/3},\\
f''(x)&=\frac13\left(-\frac23\right)x^{-5/3}=-\frac29x^{-5/3},\\
f^{(3)}(x)&=-\frac29\left(-\frac53\right)x^{-8/3}=\frac{10}{27}x^{-8/3}.
\end{aligned}
$$
At $x=1$, the values are $f(1)=1$, $f'(1)=1/3$, $f''(1)=-2/9$, and $f^{(3)}(1)=10/27$. Divide the quadratic coefficient by $2$, getting $(-2/9)/2=-1/9$. Divide the cubic coefficient by $6$, getting $(10/27)/6=5/81$. Write these beside the powers of $(x-1)$, not beside powers of $x$.

:::

:::example[Example 10.8.11 — Cosine centered at pi over six]
Find the cubic Taylor polynomial of $\cos x$ about $a=\pi/6$.

**Answer: $P_3(x)=\frac{\sqrt3}{2}-\frac12h-\frac{\sqrt3}{4}h^2+\frac1{12}h^3$, where $h=x-\pi/6$.**


The derivative cycle is $\cos x,-\sin x,-\cos x,\sin x$. At $a=\pi/6$, use $\cos(\pi/6)=\sqrt3/2$ and $\sin(\pi/6)=1/2$:

$$f(a)=\frac{\sqrt3}{2},\quad f'(a)=-\frac12,\quad f''(a)=-\frac{\sqrt3}{2},\quad f^{(3)}(a)=\frac12.$$

Then

$$
\begin{aligned}
P_3(x)&=f(a)+f'(a)h+\frac{f''(a)}{2!}h^2+\frac{f^{(3)}(a)}{3!}h^3\\
&=\frac{\sqrt3}{2}-\frac12h-\frac{\sqrt3/2}{2}h^2+\frac{1/2}{6}h^3\\
&=\frac{\sqrt3}{2}-\frac12h-\frac{\sqrt3}{4}h^2+\frac1{12}h^3.
\end{aligned}
$$
Here $h$ is only shorthand for $x-\pi/6$. The final answer must make the center clear.

:::

::::problem[Problem 10.8.6 — Logarithm at zero]{difficulty=standard}
Write $P_0$ through $P_3$ for $f(x)=\ln(1+7x)$ centered at zero.

:::solution[Solution]
**Answer:** $P_0=0$, $P_1=7x$, $P_2=7x-\frac{49}{2}x^2$, $P_3=7x-\frac{49}{2}x^2+\frac{343}{3}x^3$.

1. **Method: Taylor polynomials at zero.** Use $P_n(x)=\sum_{k=0}^nf^{(k)}(0)x^k/k!$ with $f(x)=\ln(1+7x)$, defined near $0$.

2. **Differentiate and evaluate.** The chain rule gives

   $$
   f(0)=0,\quad f'(x)=\frac7{1+7x},\quad f'(0)=7;
   $$

   $$
   f''(x)=-\frac{49}{(1+7x)^2},\quad f''(0)=-49;
   \qquad f^{(3)}(x)=\frac{686}{(1+7x)^3},\quad f^{(3)}(0)=686.
   $$

3. **Build each polynomial by adding one term.** Start with $P_0=f(0)=0$. Add $7x$ for $P_1$; add $(-49)x^2/2!=-49x^2/2$ for $P_2$; add $686x^3/3!=343x^3/3$ for $P_3$.

4. **Conclusion.** The four polynomials are the stated successive Maclaurin approximations. Each higher-degree polynomial retains all earlier terms.
:::
::::

## 10.9 Strategy for Testing Series

**Not on Test 4.** Retained for cross-references and later study; prioritize Thomas 10.1–10.8.

:::callout-key[🔑 Highest-leverage section in the chapter]
You now have seven convergence tests. The problem is knowing which one to reach for, and reaching for it fast. This section is pattern recognition training. On an exam, you won't have time to methodically try every test — you need to identify the right test within a few seconds of reading the series.
:::

### The Decision Flowchart

Work through these steps in order every time. Stop as soon as one step gives a definitive answer.

1. **Step 1 — $n$-th Term Test.** Compute $\lim_{n\to\infty} a_n$. If it's nonzero (or doesn't exist), the series diverges. Done. If it's 0, the test is inconclusive — continue.
2. **Step 2 — Recognize special forms.**

   - Form $\sum ar^n$? → Geometric series. Converges iff $|r|<1$, sum $= a/(1-r)$.
   - Form $\sum 1/n^p$? → $p$-series. Converges iff $p>1$.
   - Partial fractions cause telescoping? → Write out $S_N$ and take the limit.

3. **Step 3 — Signs alternate?** If the series is $\sum(-1)^n b_n$ with $b_n > 0$, try the Alternating Series Test. Also ask: does $\sum |a_n|$ converge by some other test? (Absolute convergence implies convergence.)
4. **Step 4 — Factorials or $n$ in an exponent?** Try the Ratio Test. The ratio $a_{n+1}/a_n$ simplifies beautifully when factorials or exponential powers are present.
5. **Step 5 — Entire term raised to the $n$-th power?** Try the Root Test. The $n$-th root collapses things like $f(n)^n$ immediately.
6. **Step 6 — Positive series resembling a rational function?** Drop lower-order terms to identify the dominant behavior, then use the Limit Comparison Test against the resulting $p$-series or geometric series.
7. **Step 7 — Can you integrate $f(x) = a_n$?** Use the Integral Test — especially useful when $a_n$ involves $\ln n$ or $e^{-n^2}$ style expressions.

:::callout-tip[Pattern Recognition Triggers]
Train yourself to see these patterns instantly:

- **Factorial anywhere** → Ratio Test
- **$[\ldots]^n$ as the entire term** → Root Test
- **Alternating signs** → AST (or check absolute convergence first)
- **Polynomial over polynomial** → LCT against $p$-series
- **$\ln n$ involved** → Integral Test
- **Looks like $ar^n$** → Geometric series
- **Looks like $1/n^p$** → $p$-series
:::

### Worked Battery — 12 Series, One Each

:::example[🧠 Battery #1 — Geometric recognition]
$\displaystyle\sum_{n=1}^\infty\frac{e^n}{5^n}$

**Answer: Converges. Sum $= e/(5-e)$.**

**Hand calculation.**
Rewrite: $\sum (e/5)^n$. Geometric with $r = e/5 \approx 0.544 < 1$. Converges. The sum (starting at $n=1$) is $\dfrac{e/5}{1-e/5} = \dfrac{e}{5-e}$.
:::

:::example[🧠 Battery #2 — $n$-th Term Test catches it]
$\displaystyle\sum_{n=1}^\infty\frac{n^2}{n^2+1}$

**Answer: Diverges.**

**Hand calculation.**
$\lim_{n\to\infty}\frac{n^2}{n^2+1} = 1 \ne 0$. Diverges immediately by the $n$-th Term Test. No further work needed.
:::

:::example[🧠 Battery #3 — LCT against harmonic]
$\displaystyle\sum_{n=1}^\infty\frac{1}{\sqrt{n^2+4}}$

**Answer: Diverges.**

**Hand calculation.**
Dominant behavior: $1/\sqrt{n^2} = 1/n$. LCT with $b_n = 1/n$: $\lim\frac{n}{\sqrt{n^2+4}} = \lim\frac{1}{\sqrt{1+4/n^2}} = 1$. Since $\sum 1/n$ diverges and $c=1$, the series diverges.
:::

:::example[🧠 Battery #4 — Ratio Test (factorial)]
$\displaystyle\sum_{n=0}^\infty\frac{(2n)!}{4^n(n!)^2}$

**Answer: Diverges (Ratio Test gives $L=1$ — inconclusive; deeper analysis needed; this actually diverges).**

**Hand calculation.**
Ratio: $\frac{(2n+2)!}{4^{n+1}((n+1)!)^2}\cdot\frac{4^n(n!)^2}{(2n)!} = \frac{(2n+2)(2n+1)}{4(n+1)^2} = \frac{2n+1}{2(n+1)} \to 1$. Inconclusive. Since $4^n=\sum_{k=0}^{2n}\binom{2n}{k}\le(2n+1)\binom{2n}{n}$, this term is at least $1/(2n+1)$. The odd harmonic series diverges, so the original series diverges by comparison.
:::

:::example[🧠 Battery #5 — AST (conditional convergence)]
$\displaystyle\sum_{n=2}^\infty\frac{(-1)^n}{\ln n}$

**Answer: Converges conditionally.**

**Hand calculation.**
AST: $b_n = 1/\ln n$. Decreasing (for $n \ge 2$) ✓; $b_n\to 0$ ✓. Converges. Absolute: $\sum 1/\ln n \ge \sum 1/n$ (since $\ln n < n$), so $\sum 1/\ln n$ diverges. Conditionally convergent.
:::

:::example[🧠 Battery #6 — Root Test]
$\displaystyle\sum_{n=1}^\infty\left(\frac{n}{2n+1}\right)^n$

**Answer: Converges absolutely.**

**Hand calculation.**
Entire term to the $n$-th power → Root Test. $\sqrt[n]{|a_n|} = \frac{n}{2n+1} \to \frac{1}{2} < 1$. Converges absolutely.
:::

:::example[🧠 Battery #7 — Integral Test with $\ln$]
$\displaystyle\sum_{n=2}^\infty\frac{1}{n(\ln n)^2}$

**Answer: Converges.**

**Hand calculation.**
$\ln n$ → Integral Test. $\int_2^\infty\frac{dx}{x(\ln x)^2}$. Sub $u=\ln x$: $\int_{\ln 2}^\infty u^{-2}\,du = [-1/u]_{\ln 2}^\infty = 1/\ln 2$. Finite → converges.
:::

:::example[🧠 Battery #8 — Ratio Test (exponential wins)]
$\displaystyle\sum_{n=1}^\infty\frac{n^{10}}{2^n}$

**Answer: Converges absolutely.**

**Hand calculation.**
Ratio: $\frac{(n+1)^{10}/2^{n+1}}{n^{10}/2^n} = \frac{1}{2}\left(\frac{n+1}{n}\right)^{10} \to \frac{1}{2} < 1$. Converges. Exponential beats polynomial.
:::

:::example[🧠 Battery #9 — LCT against $p=3/2$]
$\displaystyle\sum_{n=1}^\infty\frac{\sqrt{n}}{n^2+3n+2}$

**Answer: Converges.**

**Hand calculation.**
Dominant: $\sqrt{n}/n^2 = n^{-3/2}$. LCT with $1/n^{3/2}$: $\lim\frac{\sqrt{n}\cdot n^{3/2}}{n^2+3n+2} = \lim\frac{n^2}{n^2+3n+2} = 1$. Since $\sum n^{-3/2}$ converges ($p=3/2>1$), so does the original.
:::

:::example[🧠 Battery #10 — Absolute convergence via Ratio]
$\displaystyle\sum_{n=1}^\infty\frac{(-1)^n n^2}{3^n}$

**Answer: Converges absolutely.**

**Hand calculation.**
Apply Ratio Test to $|a_n| = n^2/3^n$: ratio $\to 1/3 < 1$. Since $\sum|a_n|$ converges, the alternating series converges absolutely.
:::

:::example[🧠 Battery #11 — Telescoping after partial fractions]
$\displaystyle\sum_{n=1}^\infty\frac{2}{n^2+2n}$

**Answer: Converges; sum $= \frac{3}{2}$.**

**Hand calculation.**
$n^2+2n = n(n+2)$. Partial fractions: $\frac{2}{n(n+2)} = \frac{1}{n} - \frac{1}{n+2}$. Telescope: $S_N = \left(1 - \frac{1}{3}\right)+\left(\frac{1}{2}-\frac{1}{4}\right)+\left(\frac{1}{3}-\frac{1}{5}\right)+\cdots$. The surviving terms are $1 + \frac{1}{2} - \frac{1}{N+1} - \frac{1}{N+2} \to \frac{3}{2}$.
:::

:::example[🧠 Battery #12 — LCT with geometric comparison]
$\displaystyle\sum_{n=1}^\infty\sin\!\left(\frac{\pi}{3^n}\right)$

**Answer: Converges.**

**Hand calculation.**
For small angles, $\sin\theta\approx\theta$. So $\sin(\pi/3^n)\approx\pi/3^n$. LCT with $b_n = (1/3)^n$ (geometric, converges): $\lim\frac{\sin(\pi/3^n)}{\pi/3^n} = 1$ (standard limit $\sin\theta/\theta\to 1$ as $\theta\to 0$). Since $c=1$ and $\sum(1/3)^n$ converges, the original converges.
:::

## 10.10 Beyond Test 4: Representations of Functions as Power Series

**Not on Test 4.** Retained for cross-references and later study; prioritize Thomas 10.1–10.8.

:::callout-connect
📺 Watch before this section

“Function as a geometric series | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition — building new series from old ones]
The geometric series formula $\dfrac{1}{1-u} = \sum_{n=0}^\infty u^n$ is your master template. By plugging in clever expressions for $u$, differentiating, or integrating, you can manufacture power series for a huge variety of functions without ever computing a single derivative. This is almost always faster than computing all the Taylor coefficients from scratch.

Why does term-by-term differentiation and integration work? Intuitively, inside the radius of convergence, a power series is essentially an infinite polynomial, and polynomials can be differentiated and integrated term by term without issue. The theorem formalizes this and guarantees the radius of convergence is unchanged (though endpoints may differ after integration).
:::

:::theorem[Theorem 2.13 — Term-by-Term Differentiation and Integration]
If $\displaystyle f(x) = \sum_{n=0}^\infty c_n(x-a)^n$ with radius of convergence $R > 0$, then on the open interval $(a-R, a+R)$:

$$
f'(x) = \sum_{n=1}^\infty n\,c_n(x-a)^{n-1} \qquad \text{(same radius } R\text{)}
$$

$$
\int f(x)\,dx = C + \sum_{n=0}^\infty \frac{c_n}{n+1}(x-a)^{n+1} \qquad \text{(same radius } R\text{)}
$$

 Endpoints may change after integration — always recheck them.
:::

### The Master Template and its Relatives

Every manipulation below starts from:

$$
\frac{1}{1-u} = \sum_{n=0}^\infty u^n = 1 + u + u^2 + u^3 + \cdots, \qquad |u| < 1.
$$

| Function | How to get it | Power series |
| --- | --- | --- |
| $\dfrac{1}{1+x}$ | Substitute $u=-x$ | $\sum(-1)^n x^n$, $|x|<1$ |
| $\dfrac{1}{1-x^2}$ | Substitute $u=x^2$ | $\sum x^{2n}$, $|x|<1$ |
| $\dfrac{1}{(1-x)^2}$ | Differentiate $1/(1-x)$ | $\sum_{n=1}^\infty n x^{n-1}$, $|x|<1$ |
| $\ln(1+x)$ | Integrate $1/(1+x)$ | $\sum_{n=1}^\infty\frac{(-1)^{n-1}x^n}{n}$, $-1 < x \le 1$ |
| $\arctan x$ | Integrate $1/(1+x^2)$ | $\sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{2n+1}$, $-1 \le x \le 1$ |

:::example[🧠 Example 10.10.1 — Substitution]
Find a power series for $\dfrac{1}{1+x^2}$.

**Answer: $\displaystyle\sum_{n=0}^\infty(-1)^n x^{2n}$, valid for $|x|<1$.**

**Hand calculation.**
Substitute $u = -x^2$ into the master template:

$$
\frac{1}{1+x^2} = \frac{1}{1-(-x^2)} = \sum_{n=0}^\infty(-x^2)^n = \sum_{n=0}^\infty(-1)^n x^{2n} = 1 - x^2 + x^4 - x^6 + \cdots
$$

 Valid when $|-x^2| = x^2 < 1$, i.e., $|x|<1$.
:::

:::example[🧠 Example 10.10.2 — Integrate to get $\arctan x$]
Use the previous result to find a power series for $\arctan x$.

**Answer: $\displaystyle\arctan x = \sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{2n+1}$, valid for $|x|\le 1$.**

**Hand calculation.**
Since $\dfrac{d}{dx}[\arctan x] = \dfrac{1}{1+x^2}$, integrate both sides from 0 to $x$:

$$
\arctan x = \int_0^x\frac{dt}{1+t^2} = \int_0^x\sum_{n=0}^\infty(-1)^n t^{2n}\,dt = \sum_{n=0}^\infty(-1)^n\frac{x^{2n+1}}{2n+1}.
$$

 The radius of convergence is still 1. At $x=1$: $\sum(-1)^n/(2n+1)$ — converges by AST (this gives $\pi/4$, so $\arctan 1 = \pi/4$ ✓). At $x=-1$: similarly converges. So the interval is the full $[-1,1]$.
:::

:::example[🧠 Example 10.10.3 — Differentiate to get $1/(1-x)^2$]
Find a power series for $\dfrac{1}{(1-x)^2}$.

**Answer: $\displaystyle\sum_{n=0}^\infty(n+1)x^n$, valid for $|x|<1$.**

**Hand calculation.**
Since $\dfrac{d}{dx}\!\left[\dfrac{1}{1-x}\right] = \dfrac{1}{(1-x)^2}$, differentiate the geometric series term by term:

$$
\frac{1}{(1-x)^2} = \frac{d}{dx}\!\left[\sum_{n=0}^\infty x^n\right] = \sum_{n=1}^\infty n x^{n-1}.
$$

 Re-index by letting $m = n-1$: $= \sum_{m=0}^\infty(m+1)x^m$. So the $n$-th coefficient is $n+1$.
:::

:::example[🧠 Example 10.10.4 — Evaluating an integral via power series]
Find $\displaystyle\int_0^{0.5}\frac{1}{1+x^4}\,dx$ as a series, and estimate it to 4 decimal places.

**Answer: $\approx 0.4940$**

**Hand calculation.**
Substitute $u = -x^4$: $\dfrac{1}{1+x^4} = \sum_{n=0}^\infty(-1)^n x^{4n}$. Integrate term by term:

$$
\int_0^{0.5}\frac{dx}{1+x^4} = \sum_{n=0}^\infty\frac{(-1)^n(0.5)^{4n+1}}{4n+1}.
$$

 This is an alternating series, so error $\le$ first omitted term. First few terms:

 $n=0$: $0.5/1 = 0.5$
 $n=1$: $-(0.5)^5/5 = -0.03125/5 = -0.00625$
 $n=2$: $(0.5)^9/9 \approx 0.001953/9 \approx 0.000217$
 $n=3$: $-(0.5)^{13}/13 \approx 0.0000122/13 \approx -9.4\times10^{-7}$

 Sum through $n=2$: $0.5 - 0.00625 + 0.000217 \approx 0.493967$. Add $n=3$ correction: $\approx 0.493958$. The next omitted term has magnitude $(0.5)^{17}/17< 5\times10^{-7}$. More precisely: $0.493958\ldots \approx 0.4940$.
:::

::::problem[Problem 10.10.1 easy]{difficulty=easy}
Find a power series for $\dfrac{x}{1-x^3}$.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty x^{3n+1}$ for $|x|<1$.

1. **Method: substitute into the geometric series.** The identity

   $$
   \frac1{1-u}=\sum_{n=0}^\infty u^n=1+u+u^2+\cdots
   $$

   holds whenever $|u|<1$.

2. **Replace the geometric variable.** Take $u=x^3$, obtaining

   $$
   \frac1{1-x^3}=\sum_{n=0}^\infty(x^3)^n
   =\sum_{n=0}^\infty x^{3n}.
   $$

3. **Multiply through by $x$.** This gives

   $$
   \frac{x}{1-x^3}=\sum_{n=0}^\infty x\cdot x^{3n}
   =\sum_{n=0}^\infty x^{3n+1}
   =x+x^4+x^7+\cdots.
   $$

4. **Check the domain.** The geometric condition $|x^3|<1$ is equivalent to $|x|<1$. At $x=1$, terms equal $1$; at $x=-1$, terms alternate between signs without tending to zero.

5. **Conclusion.** The stated series represents $x/(1-x^3)$ exactly on $(-1,1)$.
:::
::::
::::problem[Problem 10.10.2 standard]{difficulty=standard}
Use the series for $\dfrac{1}{1+x}$ to find a power series for $\ln(1+x)$.

:::solution[Solution]
**Answer:** $\sum_{n=1}^\infty(-1)^{n-1}x^n/n$, on $(-1,1]$.

1. **Method: integrate a geometric series.** For $|x|<1$, set $u=-x$ in $1/(1-u)=\sum u^n$:

   $$
   \frac1{1+x}=\sum_{n=0}^\infty(-1)^nx^n
   =1-x+x^2-x^3+\cdots.
   $$

2. **Integrate from zero to $x$.** Term-by-term integration is valid inside the radius $1$:

   $$
   \int_0^x\frac{dt}{1+t}=\ln(1+x),
   \qquad \int_0^x\sum_{n=0}^\infty(-1)^nt^n\,dt
   =\sum_{n=0}^\infty\frac{(-1)^nx^{n+1}}{n+1}.
   $$

3. **Reindex.** Put $k=n+1$: $\ln(1+x)=\sum_{k=1}^\infty(-1)^{k-1}x^k/k$.

4. **Check endpoints.** At $x=1$, the alternating harmonic series converges by AST and equals $\ln2$. At $x=-1$, the series becomes $-\sum1/k$, which diverges.

5. **Conclusion.** The power series represents $\ln(1+x)$ on $(-1,1]$.
:::
::::
::::problem[Problem 10.10.3 standard]{difficulty=standard}
Find a power series for $\dfrac{x}{(1-x)^2}$.

:::solution[Solution]
**Answer:** $\sum_{n=1}^\infty nx^n$ for $|x|<1$.

1. **Method: differentiate the geometric series.** Begin with

   $$
   \frac1{1-x}=\sum_{n=0}^\infty x^n=1+x+x^2+x^3+\cdots,
   \qquad |x|<1.
   $$

2. **Differentiate term by term.** This is allowed strictly inside a power series' radius of convergence:

   $$
   \frac{d}{dx}(1-x)^{-1}=(1-x)^{-2},
   \qquad \frac{d}{dx}\sum_{n=0}^\infty x^n
   =\sum_{n=1}^\infty nx^{n-1}.
   $$

3. **Multiply both sides by $x$.**

   $$
   \frac{x}{(1-x)^2}=\sum_{n=1}^\infty nx^n
   =x+2x^2+3x^3+\cdots.
   $$

4. **Check the interval.** The radius remains $R=1$ under differentiation. At $x=1$, terms are $n$; at $x=-1$, terms are $n(-1)^n$. Neither tends to zero, so both endpoints diverge.

5. **Conclusion.** The representation is valid exactly when $|x|<1$.
:::
::::
::::problem[Problem 10.10.4 challenge]{difficulty=challenge}
Use the $\arctan$ series to show that $\pi = 4\displaystyle\sum_{n=0}^\infty\frac{(-1)^n}{2n+1}$, and explain why this series converges slowly.

:::solution[Solution]
**Answer:** $\pi=4\sum_{n=0}^\infty(-1)^n/(2n+1)$.

1. **Method: use the arctangent power series.** From integrating $1/(1+t^2)$ we have, for $|x|<1$,

   $$
   \arctan x=\sum_{n=0}^\infty\frac{(-1)^nx^{2n+1}}{2n+1}
   =x-\frac{x^3}{3}+\frac{x^5}{5}-\cdots.
   $$

2. **Use the endpoint $x=1$.** The coefficients $1/(2n+1)$ are positive, decreasing, and tend to zero, so the resulting alternating series converges. By continuity at the endpoint (or Abel's theorem), its sum is $\arctan1=\pi/4$.

3. **Multiply by four.**

   $$
   \frac\pi4=1-\frac13+\frac15-\frac17+\cdots
   \quad\Longrightarrow\quad
   \pi=4\sum_{n=0}^\infty\frac{(-1)^n}{2n+1}.
   $$

4. **Explain the slow convergence.** After terms $n=0$ through $N$, the alternating error is at most $4/(2N+3)$. This decreases only like $1/N$, so many terms are needed for even modest precision.

5. **Conclusion.** The Leibniz series is exact but converges slowly.
:::
::::
## 10.11 Beyond Test 4: Applications of Taylor Polynomials

**Not on Test 4.** Retained for cross-references and later study; prioritize Thomas 10.1–10.8.

:::callout-connect
📺 Watch before this section

“Taylor polynomial approximations” — Khan Academy
:::

:::callout-intuition[Intuition — why approximation matters]
Most "exact" formulas in science and engineering are in fact polynomial approximations — often first or second order Taylor polynomials. The small-angle approximation in pendulum physics, the linear approximation in optics, the quadratic approximation in thermodynamics — all are Taylor polynomials in disguise. The power of this section is learning to recognize when you're near a special point, identify which Taylor polynomial applies, and quantify the error you're accepting.
:::

### Approximation and Error Estimation

The workflow is always the same:

1. Identify the function $f$ and the center $a$ (usually a point where $f$ is simple).
2. Write the Taylor polynomial $T_n(x)$ of whatever degree is needed.
3. Use Taylor's Inequality to bound the error $|f(x) - T_n(x)|$.
4. Solve for the minimum $n$ that meets the required precision.

:::example[🧠 Example 10.11.1 — Approximating $\sqrt{e}$]
Use the Maclaurin series for $e^x$ to approximate $\sqrt{e} = e^{1/2}$ with error less than $0.001$.

**Answer: $\sqrt{e} \approx 1 + \frac{1}{2} + \frac{1}{8} + \frac{1}{48} + \frac{1}{384} \approx 1.6484$. Error $< 0.001$.**

**Hand calculation.**
At $x=1/2$, $e^{1/2} = \sum_{n=0}^\infty\frac{(1/2)^n}{n!}$. By Taylor's Inequality with $M = e^{1/2} < 2$ (a bound on all derivatives of $e^x$ on $[0,1/2]$):

$$
|R_n| \le \frac{2}{(n+1)!}\left(\frac{1}{2}\right)^{n+1}.
$$

 For $n=4$: $\dfrac{2}{5!}(1/2)^5 = \dfrac{2}{120\cdot 32} \approx 0.00052 < 0.001$. ✓

Sum through $n=4$:

$$
1 + \frac{1}{2} + \frac{1/4}{2} + \frac{1/8}{6} + \frac{1/16}{24} = 1 + 0.5 + 0.125 + 0.02083 + 0.002604 \approx 1.6484.
$$

 True value: $\sqrt{e} \approx 1.64872\ldots$. Error $\approx 0.0003 < 0.001$. ✓
:::

:::example[🧠 Example 10.11.2 — Small-angle approximation in physics]
Explain why a simple pendulum of length $L$ has period $T = 2\pi\sqrt{L/g}$ only for small oscillations, using Taylor series.

**Answer: The exact equation involves $\sin\theta$; the approximation $\sin\theta\approx\theta$ is the first Taylor term, valid for small $\theta$.**

**Hand calculation.**
The exact equation of motion for a pendulum is $\ddot\theta = -(g/L)\sin\theta$. This is nonlinear and has no closed-form solution. The Maclaurin series for $\sin\theta$ is:

$$
\sin\theta = \theta - \frac{\theta^3}{6} + \frac{\theta^5}{120} - \cdots
$$

 For small $\theta$ (say, $\theta < 15° \approx 0.26$ rad), the $\theta^3/6$ term contributes less than $0.26^3/6 \approx 0.003$, which is less than 1% error. Approximating $\sin\theta \approx \theta$ gives the linear equation $\ddot\theta = -(g/L)\theta$, which is simple harmonic motion with $\omega = \sqrt{g/L}$ and period $T = 2\pi/\omega = 2\pi\sqrt{L/g}$. The quadratic correction $\theta^3$ gives the first nonlinear correction to the period.
:::

:::example[🧠 Example 10.11.3 — Using Taylor series to compute an integral]
Approximate $\displaystyle\int_0^{0.4}\sqrt{1+x^3}\,dx$ to within $0.0001$.

**Answer: $\approx 0.4032$**

**Hand calculation.**
Use the binomial series: $\sqrt{1+u} = (1+u)^{1/2} = 1 + \frac{1}{2}u - \frac{1}{8}u^2 + \cdots$ for $|u|<1$. Substitute $u=x^3$:

$$
\sqrt{1+x^3} = 1 + \frac{x^3}{2} - \frac{x^6}{8} + \cdots
$$

 Integrate term by term from 0 to 0.4:

$$
\int_0^{0.4}\sqrt{1+x^3}\,dx \approx \left[x + \frac{x^4}{8} - \frac{x^7}{56} + \cdots\right]_0^{0.4}
$$

$$
= 0.4 + \frac{(0.4)^4}{8} - \frac{(0.4)^7}{56} + \cdots = 0.4 + 0.0032 - 0.00002926 + \cdots \approx 0.4032.
$$

 The next omitted integral term is $0.4^7/56\approx2.93\times10^{-5}<0.0001$, so two terms already guarantee absolute error below $0.0001$. Including the third term gives $0.4031707\ldots$, agreeing with the rounded answer $0.4032$.
:::

:::callout-tip[🚀 Why This Matters for Calc IV]
Taylor series generalize to functions of two variables as the **multivariable Taylor expansion**:

$$
f(x,y) \approx f(a,b) + f_x\,\Delta x + f_y\,\Delta y + \tfrac{1}{2}[f_{xx}(\Delta x)^2 + 2f_{xy}\,\Delta x\,\Delta y + f_{yy}(\Delta y)^2] + \cdots
$$

 The second-order terms form the Hessian matrix — the basis of the Second Derivative Test for multivariable optimization. Every linear approximation, every tangent plane, every error bound in Calc IV traces back to the Taylor expansion you learned here.
:::

::::summary

## Chapter Summary

### Convergence Tests at a Glance

| Test | When to Use | Conclusion |
| --- | --- | --- |
| **Geometric** | $\sum ar^n$ | Conv. iff $|r|<1$; sum $=a/(1-r)$ |
| **$n$-th Term** | Always first | $a_n\not\to 0$ ⇒ diverges |
| **$p$-Series** | $\sum 1/n^p$ | Conv. iff $p>1$ |
| **Integral Test** | Easy-to-integrate positive decreasing $f$ | Same fate as $\int_1^\infty f$ |
| **LCT** | Rational-type positive series | Same fate as comparison series (if $0< c<\infty$) |
| **AST** | Alternating signs, $b_n\searrow 0$ | Converges; error $\le b_{N+1}$ |
| **Ratio Test** | Factorials, exponentials | $L<1$: abs. conv.; $L>1$: div.; $L=1$: ❓ |
| **Root Test** | $[\cdots]^n$ | Same as Ratio |

### The Six Maclaurin Series

$$
e^x = \sum_{n=0}^\infty\frac{x^n}{n!}\qquad \sin x = \sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{(2n+1)!}\qquad \cos x = \sum_{n=0}^\infty\frac{(-1)^n x^{2n}}{(2n)!}
$$



$$
\frac{1}{1-x}=\sum_{n=0}^\infty x^n\qquad \ln(1+x)=\sum_{n=1}^\infty\frac{(-1)^{n-1}x^n}{n}\qquad \arctan x=\sum_{n=0}^\infty\frac{(-1)^n x^{2n+1}}{2n+1}
$$

### Power Series Procedure

1. Ratio Test → open interval of convergence
2. Plug in each endpoint → test the resulting constant series
3. Assemble with correct brackets

:::callout-key[If you remember nothing else]
$n$-th Term Test first (catches lazy divergence). Geometric and $p$-series are your two benchmarks. LCT against one of them handles most positive series. Factorials → Ratio. $[\cdots]^n$ → Root. Alternating → AST + check absolute convergence. Taylor: $c_n = f^{(n)}(a)/n!$; manipulate the six standard series instead of computing from scratch whenever possible.
:::
::::

## Mixed Practice

These problems are in mixed order across all topics — as on a real exam. No hints about which test to use.

::::problem[MP-1 easy]{difficulty=easy}
Does $\displaystyle\sum_{n=1}^\infty\frac{3^n+1}{5^n}$ converge? If so, find its sum.

:::solution[Solution]
**Answer:** $7/4$

1. **Method: separate two geometric series.** Distribute the denominator before applying any test:

   $$
   \sum_{n=1}^\infty\frac{3^n+1}{5^n}
   =\sum_{n=1}^\infty\left(\frac35\right)^n
   +\sum_{n=1}^\infty\left(\frac15\right)^n.
   $$

2. **Verify convergence.** Both common ratios, $3/5$ and $1/5$, have absolute value less than one. Each series converges, so their sums may legitimately be added.

3. **Apply the $n=1$ formula.** For a geometric series beginning with $r$, the sum is $r/(1-r)$:

   $$
   \frac{3/5}{1-3/5}+\frac{1/5}{1-1/5}
   =\frac{3/5}{2/5}+\frac{1/5}{4/5}
   =\frac32+\frac14=\frac64+\frac14=\frac74.
   $$

4. **Conclusion.** The given positive-term series converges, and its exact sum is $7/4$.
:::
::::
::::problem[MP-2 standard]{difficulty=standard}
Test $\displaystyle\sum_{n=1}^\infty\frac{n^2+3n}{n^4-2}$.

:::solution[Solution]
**Answer:** Converges by LCT.

1. **Method: Limit Comparison Test.** The highest-degree terms suggest $(n^2+3n)/(n^4-2)\sim1/n^2$. Let $b_n=1/n^2$. The given terms are positive for $n\ge2$; ignoring the finite initial term does not affect convergence.

2. **Compute the ratio.**

   $$
   \frac{a_n}{b_n}=
   \frac{(n^2+3n)/(n^4-2)}{1/n^2}
   =\frac{n^4+3n^3}{n^4-2}.
   $$

3. **Divide by the highest power.**

   $$
   L=\lim_{n\to\infty}\frac{1+3/n}{1-2/n^4}
   =\frac11=1.
   $$

   The required condition $0< L<\infty$ holds.

4. **Check the benchmark.** The $p$-series $\sum_{n=2}^\infty1/n^2$ converges because $p=2>1$.

5. **Conclusion.** The original series converges by Limit Comparison; its initial finitely many terms do not alter this result.
:::
::::
::::problem[MP-3 standard]{difficulty=standard}
Find the interval of convergence of $\displaystyle\sum_{n=1}^\infty\frac{(x-1)^n}{n\cdot 3^n}$.

:::solution[Solution]
**Answer:** $R=3$, interval $[-2,4)$.

1. **Method: Ratio Test for a power series.** Write $a_n=(x-1)^n/(n3^n)$. For $x\ne1$,

   $$
   \left|\frac{a_{n+1}}{a_n}\right|
   =\frac{|x-1|}{3}\frac n{n+1}
   \longrightarrow\frac{|x-1|}{3}.
   $$

2. **Find the interior.** The convergence inequality $|x-1|/3<1$ is equivalent to $-3< x-1<3$, or $-2< x<4$. The radius is $R=3$.

3. **Check $x=4$.** The summand becomes $3^n/(n3^n)=1/n$. The harmonic series diverges, so $4$ is excluded.

4. **Check $x=-2$.** The summand becomes $(-3)^n/(n3^n)=(-1)^n/n$. Magnitudes $1/n$ decrease to zero, so AST proves convergence and $-2$ is included.

5. **Conclusion.** The interval of convergence is $[-2,4)$.
:::
::::
::::problem[MP-4 standard]{difficulty=standard}
Find the Maclaurin series for $\dfrac{1}{(1+x)^2}$ and state its radius of convergence.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty(-1)^n(n+1)x^n$, $R=1$.

1. **Method: differentiate a geometric series.** For $|x|<1$,

   $$
   \frac1{1+x}=1-x+x^2-x^3+\cdots
   =\sum_{n=0}^\infty(-1)^nx^n.
   $$

2. **Differentiate both sides.** Inside the radius of convergence, term-by-term differentiation is valid:

   $$
   -\frac1{(1+x)^2}
   =\sum_{n=1}^\infty(-1)^n n x^{n-1}.
   $$

3. **Multiply by $-1$ and reindex.**

   $$
   \frac1{(1+x)^2}
   =\sum_{n=1}^\infty(-1)^{n+1}nx^{n-1}
   =\sum_{k=0}^\infty(-1)^k(k+1)x^k.
   $$

4. **Check the radius and endpoints.** Differentiation preserves $R=1$. At either $x=1$ or $x=-1$, the term magnitude $n+1$ does not tend to zero, so both endpoints diverge.

5. **Conclusion.** The expansion has radius $1$ and interval $(-1,1)$.
:::
::::
::::problem[MP-5 standard]{difficulty=standard}
Classify $\displaystyle\sum_{n=1}^\infty\frac{(-1)^n}{\sqrt{n^2+1}}$ as absolutely convergent, conditionally convergent, or divergent.

:::solution[Solution]
**Answer:** Converges conditionally.

1. **Method: Alternating Series Test.** Let $b_n=1/\sqrt{n^2+1}$. It is positive for all $n\ge1$. As $n$ increases, $n^2+1$ increases, so $b_{n+1}< b_n$.

2. **Check the zero-limit condition.** Divide top and bottom by $n$ (positive for $n\ge1$):

   $$
   b_n=\frac1{n\sqrt{1+1/n^2}}\longrightarrow0.
   $$

   Therefore AST proves convergence of the alternating series.

3. **Test absolute convergence by Limit Comparison.** Compare with the harmonic term $1/n$:

   $$
   L=\lim_{n\to\infty}\frac{1/\sqrt{n^2+1}}{1/n}
   =\lim_{n\to\infty}\frac n{\sqrt{n^2+1}}
   =\lim_{n\to\infty}\frac1{\sqrt{1+1/n^2}}=1.
   $$

   Since $0< L<\infty$ and $\sum1/n$ diverges, the absolute series diverges.

4. **Conclusion.** The given series converges conditionally, not absolutely.
:::
::::
::::problem[MP-6 standard]{difficulty=standard}
Use Maclaurin series to evaluate $\displaystyle\lim_{x\to 0}\frac{\cos x - 1 + x^2/2}{x^4}$.

:::solution[Solution]
**Answer:** $1/24$

1. **Method: Maclaurin expansion.** The cosine series about zero is

   $$
   \cos x=1-\frac{x^2}{2!}+\frac{x^4}{4!}-\frac{x^6}{6!}+\cdots.
   $$

   The question's numerator is arranged to cancel the first two nonzero terms.

2. **Substitute and cancel explicitly.**

   $$
   \cos x-1+\frac{x^2}{2}
   =\left(1-\frac{x^2}{2}+\frac{x^4}{24}-\frac{x^6}{720}+\cdots\right)-1+\frac{x^2}{2}
   =\frac{x^4}{24}-\frac{x^6}{720}+\cdots.
   $$

3. **Divide by $x^4$.** When $x\ne0$,

   $$
   \frac{\cos x-1+x^2/2}{x^4}
   =\frac1{24}-\frac{x^2}{720}+\cdots.
   $$

4. **Conclusion.** As $x\to0$, the remaining positive-power terms vanish, so the limit is $1/24$.
:::
::::
::::problem[MP-7 challenge]{difficulty=challenge}
Test $\displaystyle\sum_{n=1}^\infty\frac{(n!)^2\cdot 4^n}{(2n)!}$.

:::solution[Solution]
**Answer:** Diverges (nth-term test; ratio test inconclusive).

1. **Method: Ratio Test first.** Let $a_n=(n!)^24^n/(2n)!>0$. Cancel adjacent factorials:

   $$
   \frac{a_{n+1}}{a_n}
   =\frac{4(n+1)^2}{(2n+2)(2n+1)}
   =\frac{2(n+1)}{2n+1}\longrightarrow1.
   $$

   A ratio limit of $1$ gives no verdict.

2. **Switch to the nth-term test.** The binomial theorem gives

   $$
   4^n=(1+1)^{2n}=\sum_{k=0}^{2n}\binom{2n}{k}
   \ge\binom{2n}{n}=\frac{(2n)!}{(n!)^2}.
   $$

3. **Rearrange the inequality.** Dividing by the positive central coefficient yields

   $$
   a_n=\frac{4^n}{\binom{2n}{n}}\ge1.
   $$

   Consequently the summands cannot tend to zero.

4. **Conclusion.** The series diverges by the nth-term divergence test; the Ratio Test alone was inconclusive.
:::
::::
::::problem[MP-8 challenge]{difficulty=challenge}
Find the power series for $f(x)=\displaystyle\int_0^x\frac{\sin t}{t}\,dt$ and state its radius of convergence.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty\frac{(-1)^nx^{2n+1}}{(2n+1)(2n+1)!}$, $R=\infty$.

1. **Method: integrate the sine Maclaurin series.** For all real $t$,

   $$
   \sin t=\sum_{n=0}^\infty\frac{(-1)^nt^{2n+1}}{(2n+1)!}
   =t-\frac{t^3}{3!}+\frac{t^5}{5!}-\cdots.
   $$

2. **Divide by $t$ and handle zero continuously.** For $t\ne0$,

   $$
   \frac{\sin t}{t}=\sum_{n=0}^\infty\frac{(-1)^nt^{2n}}{(2n+1)!}.
   $$

   Its value at $t=0$ is the limit $1$, so the integrand extends continuously there.

3. **Integrate term by term.** The sine series has infinite radius, so this is valid on any finite interval:

   $$
   \int_0^x\frac{\sin t}{t}\,dt
   =\sum_{n=0}^\infty\frac{(-1)^n}{(2n+1)!}
   \left[\frac{t^{2n+1}}{2n+1}\right]_0^x
   =\sum_{n=0}^\infty\frac{(-1)^nx^{2n+1}}{(2n+1)(2n+1)!}.
   $$

4. **Conclusion.** The required series has radius $R=\infty$, inherited under integration.
:::
::::
::::problem[MP-9 challenge]{difficulty=challenge}
Find the closed-form sum of the power series $\displaystyle\sum_{n=2}^\infty n(n-1)x^n$ for $|x|<1$.

:::solution[Solution]
**Answer:** $2x^2/(1-x)^3$

1. **Method: twice differentiate the geometric series.** For $|x|<1$,

   $$
   \frac1{1-x}=\sum_{n=0}^\infty x^n.
   $$

2. **Differentiate once.** The derivative of $(1-x)^{-1}$ is $(1-x)^{-2}$, so

   $$
   \frac1{(1-x)^2}=\sum_{n=1}^\infty nx^{n-1}.
   $$

3. **Differentiate again.** By the chain rule, the derivative of $(1-x)^{-2}$ is $2(1-x)^{-3}$; on the right, the $n=1$ term differentiates to zero:

   $$
   \frac2{(1-x)^3}=\sum_{n=2}^\infty n(n-1)x^{n-2}.
   $$

4. **Multiply by $x^2$.**

   $$
   \sum_{n=2}^\infty n(n-1)x^n=\frac{2x^2}{(1-x)^3}.
   $$

5. **Conclusion.** This is the exact closed form for $|x|<1$, where term-by-term differentiation is justified.
:::
::::
::::problem[MP-10 challenge]{difficulty=challenge}
Approximate $\displaystyle\int_0^{1/2}\frac{\arctan x}{x}\,dx$ to 4 decimal places using power series.

:::solution[Solution]
**Answer:** $0.4872$ (four decimal places).

1. **Method: integrate the arctangent power series.** For $|x|<1$,

   $$
   \arctan x=\sum_{n=0}^\infty\frac{(-1)^nx^{2n+1}}{2n+1}.
   $$

   Divide by $x$ (using the continuous value $1$ at zero), then integrate term by term on $[0,1/2]$:

   $$
   I=\sum_{n=0}^\infty\frac{(-1)^n(1/2)^{2n+1}}{(2n+1)^2}.
   $$

2. **Compute enough terms.**

   $$
   I=\frac12-\frac1{72}+\frac1{800}-\frac1{6272}+\frac1{41472}
   -\frac1{247808}+\cdots.
   $$

3. **Control the error before rounding.** The magnitudes decrease to zero, so the alternating remainder after $n=5$ is at most the $n=6$ term $1/[13^2 2^{13}]<10^{-6}$. Adding the six displayed terms gives $I\approx0.487222$.

4. **Conclusion.** Since the error bound is safely smaller than the gap to the nearest four-decimal rounding threshold, $I$ rounds to $\boxed{0.4872}$.
:::
::::
★

Extended Drill — 20 Mastery Problems (selected enrichment; not all on Test 4)

These problems are harder than typical exam questions. Work each one yourself first — then expand the solution to see every substep explained. The goal is not just the answer but understanding *why* each move works.

::::problem[D1 — Ratio Test with Factorials]{difficulty=challenge}
Determine whether the series converges or diverges:

$$
\sum_{n=1}^{\infty} \frac{n! \cdot 2^n}{(2n)!}
$$

:::solution[Solution]
**Answer:** Converges absolutely; ratio limit 0.

1. **Choose a test.** Factorials in both numerator and denominator scream *Ratio Test*. The Ratio Test asks: what is $L = \lim_{n\to\infty}\left|\dfrac{a_{n+1}}{a_n}\right|$?

2. **Write $a_{n+1}/a_n$.**

$$
\frac{a_{n+1}}{a_n} = \frac{(n+1)!\cdot 2^{n+1}}{(2(n+1))!} \cdot \frac{(2n)!}{n!\cdot 2^n}
$$

3. **Simplify each piece.**

*Factorial ratio:* $\dfrac{(n+1)!}{n!} = n+1$.

*Power ratio:* $\dfrac{2^{n+1}}{2^n} = 2$.

*Bottom factorial ratio:* $\dfrac{(2n)!}{(2n+2)!} = \dfrac{1}{(2n+2)(2n+1)}$.

4. **Combine.**

$$
\frac{a_{n+1}}{a_n} = (n+1)\cdot 2 \cdot \frac{1}{(2n+2)(2n+1)} = \frac{2(n+1)}{2(n+1)(2n+1)} = \frac{1}{2n+1}
$$

5. **Take the limit.**

$$
L = \lim_{n\to\infty} \frac{1}{2n+1} = 0
$$

6. **Conclude.** Since $L = 0 < 1$, the Ratio Test says the series **converges absolutely**.

**Intuition.**
Intuition:

$(2n)!$ grows far faster than $n!\cdot 2^n$ because it contains twice as many factors. The ratio shrinks to zero, guaranteeing convergence.
:::
::::

::::problem[D2 — Limit Comparison with a Rational]{difficulty=challenge}
Test for convergence:

$$
\sum_{n=1}^{\infty} \frac{3n^2 + 2}{n^4 - n + 5}
$$

:::solution[Solution]
**Answer:** Converges by LCT; comparison limit 3.

1. **Identify dominant terms.** For large $n$, the numerator behaves like $3n^2$ and the denominator like $n^4$, so $a_n \approx \dfrac{3}{n^2}$. This suggests comparing to the *p*-series $\sum \dfrac{1}{n^2}$ with $p=2>1$ (converges).

2. **Set up LCT.** Let $b_n = \dfrac{1}{n^2}$. Compute:

$$
L = \lim_{n\to\infty}\frac{a_n}{b_n} = \lim_{n\to\infty} \frac{3n^2+2}{n^4-n+5}\cdot n^2 = \lim_{n\to\infty}\frac{3n^4+2n^2}{n^4-n+5}
$$

3. **Evaluate the limit.** Divide top and bottom by $n^4$:

$$
L = \lim_{n\to\infty}\frac{3 + 2/n^2}{1 - 1/n^3 + 5/n^4} = \frac{3}{1} = 3
$$

4. **Conclude.** $L = 3$ is finite and positive. By LCT, since $\sum b_n = \sum 1/n^2$ **converges**, our series also **converges**.

**Pitfall.**
Pitfall:

The standard two-way LCT needs $0< L<\infty$. When $L=0$ with a convergent comparison, or $L=\infty$ with a divergent comparison, one-sided comparison can still prove the conclusion; otherwise choose a different benchmark.
:::
::::

::::problem[D3 — AST + Conditional vs Absolute]{difficulty=challenge}
For the series $\displaystyle\sum_{n=1}^{\infty} \frac{(-1)^n}{\sqrt{n}}$, determine whether it converges conditionally, absolutely, or diverges.

:::solution[Solution]
**Answer:** Converges conditionally.

1. **Test absolute convergence first.** The series of absolute values is $\sum \dfrac{1}{\sqrt{n}} = \sum n^{-1/2}$, a *p*-series with $p = \tfrac{1}{2} \le 1$. This **diverges**, so the series is NOT absolutely convergent.

2. **Apply the Alternating Series Test.** Write $b_n = \dfrac{1}{\sqrt{n}}$. Check three conditions:

(i) All terms positive? Yes, $b_n > 0$. ✓

(ii) Decreasing? $b_{n+1} = \dfrac{1}{\sqrt{n+1}} < \dfrac{1}{\sqrt{n}} = b_n$ since $\sqrt{n+1} > \sqrt{n}$. ✓

(iii) $\lim_{n\to\infty} b_n = \lim_{n\to\infty}\dfrac{1}{\sqrt{n}} = 0$. ✓

3. **Conclude.** All three AST conditions hold, so the series **converges**. Because it converges but does NOT converge absolutely, it converges **conditionally**.

**Key point.**
Key distinction:

Absolute convergence ⟹ convergence, but not vice versa. The Alternating Harmonic series is the canonical conditional convergence example.
:::
::::

::::problem[D4 — Integral Test]{difficulty=challenge}
Determine convergence:

$$
\sum_{n=2}^{\infty} \frac{1}{n(\ln n)^2}
$$

:::solution[Solution]
**Answer:** Converges by Integral Test; integral $1/\ln2$.

1. **Verify Integral Test conditions.** Let $f(x)=\dfrac{1}{x(\ln x)^2}$. On $[2,\infty)$: $f$ is positive, continuous, and decreasing (both $x$ and $\ln x$ increase). ✓

2. **Set up the integral.**

$$
\int_2^{\infty} \frac{dx}{x(\ln x)^2}
$$

3. **Substitute.** Let $u = \ln x$, so $du = \dfrac{dx}{x}$. When $x=2$, $u=\ln 2$; when $x\to\infty$, $u\to\infty$.

$$
\int_{\ln 2}^{\infty} \frac{du}{u^2} = \left[-\frac{1}{u}\right]_{\ln 2}^{\infty} = 0 - \left(-\frac{1}{\ln 2}\right) = \frac{1}{\ln 2}
$$

4. **Conclude.** The improper integral converges (to $1/\ln 2$), so by the Integral Test, the series **converges**.

**Intuition.**
Why $\sum 1/(n \ln n)$ diverges but this converges:

That series has $p=1$ in the "log" position; our series has $p=2$. The Integral Test applied to $\int dx/(x\ln x)$ gives $\ln(\ln x)\to\infty$, which diverges.
:::
::::

::::problem[D5 — Squeeze / Comparison with Trig]{difficulty=challenge}
Test for convergence:

$$
\sum_{n=1}^{\infty} \frac{|\sin n|}{n^2}
$$

:::solution[Solution]
**Answer:** Converges absolutely by direct comparison.

1. **Bound the trig term.** For all $n$, $|\sin n| \le 1$. Therefore:

$$
0 \le \frac{|\sin n|}{n^2} \le \frac{1}{n^2}
$$

2. **Identify the bounding series.** $\sum \dfrac{1}{n^2}$ is a *p*-series with $p=2>1$, which **converges**.

3. **Apply Direct Comparison Test.** Since $0 \le a_n \le 1/n^2$ and $\sum 1/n^2$ converges, by DCT our series **converges absolutely**.

**Key point.**
Trig comparison trick:

Whenever you see $\sin$, $\cos$, or any bounded function over a power of $n$, immediately bound the trig part by 1 and compare to the resulting

p

-series.
:::
::::

::::problem[D6 — Root Test]{difficulty=challenge}
Determine convergence:

$$
\sum_{n=1}^{\infty} \left(\frac{3n}{4n+1}\right)^n
$$

:::solution[Solution]
**Answer:** Converges absolutely; root limit $3/4$.

1. **Spot the form.** The term is an expression raised to the $n$th power — a perfect signal for the *Root Test*.

2. **Compute $\sqrt[n]{|a_n|}$.**

$$
\sqrt[n]{\left(\frac{3n}{4n+1}\right)^n} = \frac{3n}{4n+1}
$$

3. **Take the limit.**

$$
L = \lim_{n\to\infty} \frac{3n}{4n+1} = \lim_{n\to\infty}\frac{3}{4+1/n} = \frac{3}{4}
$$

4. **Conclude.** $L = \tfrac{3}{4} < 1$, so by the Root Test the series **converges absolutely**.

**Intuition.**
Intuition:

Each term behaves like $(3/4)^n$, a geometric series with ratio $3/4 < 1$. The root test formalises this geometric decay.
:::
::::

::::problem[D7 — Interval of Convergence with Endpoint Testing]{difficulty=challenge}
Find the interval of convergence of:

$$
\sum_{n=1}^{\infty} \frac{(-1)^n (x-2)^n}{n \cdot 3^n}
$$

:::solution[Solution]
**Answer:** Interval $(-1,5]$.

1. **Apply Ratio Test to find radius.** Let $a_n = \dfrac{(-1)^n(x-2)^n}{n\cdot 3^n}$.

$$
\left|\frac{a_{n+1}}{a_n}\right| = \left|\frac{(x-2)^{n+1}}{(n+1)\cdot 3^{n+1}}\cdot\frac{n\cdot 3^n}{(x-2)^n}\right| = \frac{n}{n+1}\cdot\frac{|x-2|}{3}
$$

2. **Take limit.**

$$
L = \lim_{n\to\infty}\frac{n}{n+1}\cdot\frac{|x-2|}{3} = \frac{|x-2|}{3}
$$

3. **Convergence requires $L<1$.** So $|x-2| < 3$, giving the open interval $(-1, 5)$ with radius $R=3$.

4. **Test endpoint $x = -1$.** Then $x-2=-3$, so the series becomes:

$$
\sum_{n=1}^{\infty} \frac{(-1)^n(-3)^n}{n\cdot 3^n} = \sum_{n=1}^{\infty}\frac{(-1)^n(-1)^n 3^n}{n\cdot 3^n} = \sum_{n=1}^{\infty}\frac{(-1)^{2n}}{n} = \sum_{n=1}^{\infty}\frac{1}{n}
$$

 This is the harmonic series: **diverges**.

5. **Test endpoint $x = 5$.** Then $x-2=3$:

$$
\sum_{n=1}^{\infty}\frac{(-1)^n\cdot 3^n}{n\cdot 3^n} = \sum_{n=1}^{\infty}\frac{(-1)^n}{n}
$$

 This is the alternating harmonic series: **converges** (by AST).

6. **Conclusion.** The interval of convergence is $\boxed{(-1,\,5]}$.

**Pitfall.**
Pitfall:

Never skip endpoint testing. The endpoints are the places where $L=1$ exactly, so the Ratio Test is silent — you must test each endpoint separately.
:::
::::

::::problem[D8 — Power Series from Geometric]{difficulty=challenge}
Express $\dfrac{1}{(1-x)^2}$ as a power series centered at 0 and state its interval of convergence.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty(n+1)x^n$, interval $(-1,1)$.

1. **Start from the geometric series.**

$$
\frac{1}{1-x} = \sum_{n=0}^{\infty} x^n, \quad |x|<1
$$

2. **Differentiate both sides with respect to $x$.**

$$
\frac{d}{dx}\left[\frac{1}{1-x}\right] = \frac{1}{(1-x)^2}
$$



$$
\frac{d}{dx}\left[\sum_{n=0}^{\infty}x^n\right] = \sum_{n=1}^{\infty} n x^{n-1}
$$

(The $n=0$ term vanishes since it's a constant.)

3. **Equate.**

$$
\frac{1}{(1-x)^2} = \sum_{n=1}^{\infty} n x^{n-1} = \sum_{n=0}^{\infty}(n+1)x^n
$$

(Re-indexed by substituting $m = n-1$.)

4. **Interval of convergence.** Differentiation preserves the radius of convergence, so $|x|<1$, i.e., $(-1,1)$. Check endpoints: at $x=\pm 1$ the terms $(n+1)(\pm 1)^n$ do not go to 0, so both endpoints diverge. Interval: $(-1,1)$.

**Connection.**
Connection:

This same technique (differentiate or integrate the geometric series) generates power series for $\ln(1-x)$, $\arctan x$, and many other functions without Taylor expansion work.
:::
::::

::::problem[D9 — Series Multiplication]{difficulty=challenge}
Find the first four nonzero terms of the Maclaurin series for $e^x \sin x$.

:::solution[Solution]
**Answer:** $e^x\sin x=x+x^2+x^3/3-x^5/30+\cdots$.

1. **Write out each series to sufficient terms.**

$$
e^x = 1 + x + \frac{x^2}{2!} + \frac{x^3}{3!} + \frac{x^4}{4!} + \cdots
$$



$$
\sin x = x - \frac{x^3}{3!} + \frac{x^5}{5!} - \cdots
$$

2. **Multiply, collecting by degree.** We need terms up to degree 4 (the first four nonzero terms will be degrees 1, 2, 3, 4).

$x^1:$ $1\cdot x = x$

$x^2:$ $x\cdot x = x^2$ (from $e^x$'s $x$ term times $\sin x$'s $x$ term)

$x^3:$ $\dfrac{x^2}{2}\cdot x + 1\cdot\left(-\dfrac{x^3}{6}\right) = \dfrac{x^3}{2} - \dfrac{x^3}{6} = \dfrac{x^3}{3}$

$x^4:$ $\dfrac{x^3}{6}\cdot x + x\cdot\left(-\dfrac{x^3}{6}\right) = \dfrac{x^4}{6}-\dfrac{x^4}{6} = 0$ (the $1\cdot$ and $\tfrac{x^2}{2}\cdot$ pairings need an even power from $\sin x$, which has none)

The degree-4 coefficient vanishes, so the fourth nonzero term is degree 5. Only two pairings reach it — $1\cdot\tfrac{x^5}{120}$, $\tfrac{x^2}{2}\cdot\left(-\tfrac{x^3}{6}\right)$ and $\tfrac{x^4}{24}\cdot x$:

$x^5:$ $\dfrac{1}{120}-\dfrac{1}{12}+\dfrac{1}{24} = \dfrac{1-10+5}{120} = -\dfrac{1}{30}$

3. **Result.**

$$
e^x\sin x = x + x^2 + \frac{x^3}{3} - \frac{x^5}{30} + \cdots
$$

**Key point.**
Key technique:

When multiplying two series, organize the work by target degree. List all pairs of terms whose degrees add to the target degree, then sum the products of coefficients.
:::
::::

::::problem[D10 — Limit via Taylor Series]{difficulty=challenge}
Evaluate without L'Hôpital's rule:

$$
\lim_{x\to 0}\frac{\sin x - x + \frac{x^3}{6}}{x^5}
$$

:::solution[Solution]
**Answer:** $1/120$

1. **Write the Maclaurin series for $\sin x$.**

$$
\sin x = x - \frac{x^3}{3!} + \frac{x^5}{5!} - \frac{x^7}{7!}+\cdots
$$

2. **Substitute into the numerator.**

$$
\sin x - x + \frac{x^3}{6} = \left(x - \frac{x^3}{6} + \frac{x^5}{120} - \cdots\right) - x + \frac{x^3}{6}
$$

The $x$ terms cancel: $x - x = 0$.

The $x^3$ terms cancel: $-\dfrac{x^3}{6} + \dfrac{x^3}{6} = 0$.

What remains: $\dfrac{x^5}{120} - \dfrac{x^7}{5040}+\cdots$

3. **Divide by $x^5$ and take the limit.**

$$
\frac{\sin x - x + x^3/6}{x^5} = \frac{x^5/120 - x^7/5040+\cdots}{x^5} = \frac{1}{120} - \frac{x^2}{5040}+\cdots
$$



$$
\lim_{x\to 0} = \boxed{\dfrac{1}{120}}
$$

**Intuition.**
Why Taylor beats L'Hôpital here:

L'Hôpital would require differentiating 5 times — painful. Taylor series reduces the problem to polynomial arithmetic.
:::
::::

::::problem[D11 — Taylor Polynomial Approximation & Error Bound]{difficulty=challenge}
Use the degree-4 Maclaurin polynomial for $\cos x$ to approximate $\cos(0.1)$. Then give a rigorous upper bound on the error.

:::solution[Solution]
**Answer:** $\cos(0.1)\approx0.9950042$; error at most $0.1^5/120$.

1. **Write the Maclaurin series for $\cos x$.**

$$
\cos x = 1 - \frac{x^2}{2!} + \frac{x^4}{4!} - \frac{x^6}{6!}+\cdots
$$

The degree-4 polynomial is $T_4(x) = 1 - \dfrac{x^2}{2} + \dfrac{x^4}{24}$.

2. **Substitute $x=0.1$.**

$$
T_4(0.1) = 1 - \frac{(0.1)^2}{2} + \frac{(0.1)^4}{24} = 1 - \frac{0.01}{2}+\frac{0.0001}{24}
$$



$$
= 1 - 0.005 + 0.000004166\ldots \approx 0.995004166\ldots
$$

3. **Error bound via Taylor's Inequality.** The remainder after a degree-$n$ Taylor polynomial satisfies:

$$
|R_n(x)| \le \frac{M}{(n+1)!}|x-a|^{n+1}
$$

 where $M$ is a bound on $|f^{(n+1)}|$ on the interval between $a$ and $x$.

Here $n=4$, $a=0$, $x=0.1$. The 5th derivative of $\cos x$ is $-\sin x$, so $|f^{(5)}(t)| = |\sin t| \le 1$ for all $t$. Thus $M=1$.

$$
|R_4(0.1)| \le \frac{1}{5!}(0.1)^5 = \frac{(0.1)^5}{120} = \frac{0.00001}{120} \approx 8.3\times10^{-8}
$$

4. **Conclusion.** $\cos(0.1) \approx 0.9950042$ with error at most $8.3\times10^{-8}$ — accurate to 7 decimal places.

**Key point.**
Key formula:

$|R_n(x)| \le \dfrac{M}{(n+1)!}|x-a|^{n+1}$. The bound improves rapidly as $n$ increases because of the factorial in the denominator.
:::
::::

::::problem[D12 — Integrating a Power Series]{difficulty=challenge}
Use a power series to express $\displaystyle\int_0^{0.5}\frac{\sin x}{x}\,dx$ as an infinite series, then approximate to 4 decimal places.

:::solution[Solution]
**Answer:** $\int_0^{1/2}(\sin x)/x\,dx\approx0.4931$.

1. **Express $\sin x / x$ as a power series.**

$$
\sin x = x - \frac{x^3}{3!}+\frac{x^5}{5!}-\frac{x^7}{7!}+\cdots
$$



$$
\frac{\sin x}{x} = 1 - \frac{x^2}{3!}+\frac{x^4}{5!}-\frac{x^6}{7!}+\cdots = \sum_{n=0}^{\infty}\frac{(-1)^n x^{2n}}{(2n+1)!}
$$

(This is valid for all $x\neq 0$, and the limit as $x\to 0$ gives 1, so the series is valid on all of $\mathbb{R}$.)

2. **Integrate term by term.**

$$
\int_0^{0.5}\frac{\sin x}{x}\,dx = \sum_{n=0}^{\infty}\frac{(-1)^n}{(2n+1)!}\cdot\frac{x^{2n+1}}{2n+1}\Bigg|_0^{0.5} = \sum_{n=0}^{\infty}\frac{(-1)^n(0.5)^{2n+1}}{(2n+1)\cdot(2n+1)!}
$$

3. **Compute terms.**

$n=0$: $\dfrac{(0.5)^1}{1\cdot 1!} = 0.5$

$n=1$: $-\dfrac{(0.5)^3}{3\cdot 3!} = -\dfrac{0.125}{18} \approx -0.006944$

$n=2$: $\dfrac{(0.5)^5}{5\cdot 5!} = \dfrac{0.03125}{600} \approx 0.0000521$

$n=3$: $-\dfrac{(0.5)^7}{7\cdot 7!} \approx -\dfrac{0.0078125}{35280}\approx -2.2\times10^{-7}$ (negligible)

4. **Sum.**

$$
\approx 0.5 - 0.006944 + 0.0000521 \approx 0.4931
$$

To 4 decimal places: $\approx \boxed{0.4931}$.

**Connection.**
Connection:

$\int_0^x \sin(t)/t\,dt$ is called $\text{Si}(x)$, the sine integral — a special function with no closed form, expressible only as a series.
:::
::::

::::problem[D13 — Sequence Limit via L'Hôpital]{difficulty=challenge}
Find $\displaystyle\lim_{n\to\infty} n^2 e^{-n}$.

:::solution[Solution]
**Answer:** $0$

1. **Identify the indeterminate form.** As $n\to\infty$, $n^2\to\infty$ and $e^{-n}\to 0$, giving the form $\infty\cdot 0$. Rewrite as a fraction:

$$
\lim_{n\to\infty}\frac{n^2}{e^n} \quad (\infty/\infty \text{ form})
$$

2. **Apply L'Hôpital (treating $n$ as continuous variable $x$).**

$$
\lim_{x\to\infty}\frac{x^2}{e^x} \xrightarrow{L'H} \lim_{x\to\infty}\frac{2x}{e^x} \xrightarrow{L'H} \lim_{x\to\infty}\frac{2}{e^x} = 0
$$

3. **Conclude for the sequence.** Since the continuous limit is 0, the sequence limit is also $\boxed{0}$.

**Key point.**
Exponential beats polynomials:

$e^n$ grows faster than any power $n^k$. More precisely, $\lim n^k e^{-n}=0$ for every fixed $k$.
:::
::::

::::problem[D14 — Telescoping Series]{difficulty=challenge}
Find the exact sum:

$$
\sum_{n=1}^{\infty} \frac{1}{n(n+2)}
$$

:::solution[Solution]
**Answer:** $3/4$

1. **Partial fractions.**

$$
\frac{1}{n(n+2)} = \frac{A}{n}+\frac{B}{n+2}
$$



$$
1 = A(n+2)+Bn
$$

Set $n=0$: $1=2A \Rightarrow A=1/2$.

Set $n=-2$: $1=-2B \Rightarrow B=-1/2$.

$$
\frac{1}{n(n+2)} = \frac{1}{2}\left(\frac{1}{n}-\frac{1}{n+2}\right)
$$

2. **Write partial sums and spot the telescope.**

$$
S_N = \frac{1}{2}\sum_{n=1}^{N}\left(\frac{1}{n}-\frac{1}{n+2}\right)
$$

Writing out terms:

$$
S_N = \frac{1}{2}\!\left[\!\left(\frac{1}{1}-\frac{1}{3}\right)+\left(\frac{1}{2}-\frac{1}{4}\right)+\left(\frac{1}{3}-\frac{1}{5}\right)+\cdots+\left(\frac{1}{N}-\frac{1}{N+2}\right)\!\right]
$$

Surviving terms (the "un-cancelled" pieces): $\dfrac{1}{1}+\dfrac{1}{2}-\dfrac{1}{N+1}-\dfrac{1}{N+2}$.

$$
S_N = \frac{1}{2}\!\left(1+\frac{1}{2}-\frac{1}{N+1}-\frac{1}{N+2}\right)
$$

3. **Take the limit.**

$$
\sum_{n=1}^{\infty}\frac{1}{n(n+2)} = \lim_{N\to\infty}S_N = \frac{1}{2}\!\left(1+\frac{1}{2}\right) = \frac{1}{2}\cdot\frac{3}{2} = \boxed{\frac{3}{4}}
$$
:::
::::

::::problem[D15 — Interval of Convergence with Factorial Denominator]{difficulty=challenge}
Find the interval of convergence:

$$
\sum_{n=0}^{\infty}\frac{x^n}{n!}
$$

:::solution[Solution]
**Answer:** $R=\infty$, interval $(-\infty,\infty)$.

1. **Ratio Test.**

$$
\left|\frac{a_{n+1}}{a_n}\right| = \left|\frac{x^{n+1}}{(n+1)!}\cdot\frac{n!}{x^n}\right| = \frac{|x|}{n+1}
$$

2. **Limit.**

$$
L = \lim_{n\to\infty}\frac{|x|}{n+1} = 0
$$

  for every fixed $x$.

3. **Conclude.** $L = 0 < 1$ for all $x \in \mathbb{R}$. The series converges for **all real numbers**. Interval of convergence: $(-\infty, \infty)$, radius $R = \infty$.

**Key point.**
This is the exponential function:

$\displaystyle\sum_{n=0}^{\infty}\frac{x^n}{n!} = e^x$. Factorial denominators make convergence extremely rapid.
:::
::::

::::problem[D16 — Leibniz Formula for π/4]{difficulty=challenge}
Starting from the geometric series, derive the Leibniz formula:

$$
\frac{\pi}{4} = 1 - \frac{1}{3}+\frac{1}{5}-\frac{1}{7}+\cdots
$$

:::solution[Solution]
**Answer:** $\pi/4=1-1/3+1/5-1/7+\cdots$.

1. **Start with the geometric series.**

$$
\frac{1}{1-t} = 1+t+t^2+t^3+\cdots, \quad |t|<1
$$

Substitute $t = -x^2$:

$$
\frac{1}{1+x^2} = 1 - x^2+x^4-x^6+\cdots = \sum_{n=0}^{\infty}(-1)^n x^{2n}, \quad |x|<1
$$

2. **Integrate both sides from 0 to $x$.**

$$
\int_0^x\frac{dt}{1+t^2} = \sum_{n=0}^{\infty}\frac{(-1)^n x^{2n+1}}{2n+1}
$$

Left side: $\arctan x$. So:

$$
\arctan x = x - \frac{x^3}{3}+\frac{x^5}{5}-\frac{x^7}{7}+\cdots
$$

3. **Plug in $x = 1$.** The series on the right converges at $x=1$ by the AST (terms decrease to 0 in absolute value). Abel's Theorem (or a direct argument) shows the series value equals $\arctan 1$.

$$
\arctan 1 = \frac{\pi}{4} = 1 - \frac{1}{3}+\frac{1}{5}-\frac{1}{7}+\cdots \quad \blacksquare
$$

**Intuition.**
Intuition:

We essentially extended the power series to its boundary point $x=1$. This is valid because the alternating series converges there — not all series can be evaluated at boundary points.
:::
::::

::::problem[D17 — Taylor Series at a Non-Zero Center]{difficulty=challenge}
Find the Taylor series for $f(x) = \ln x$ centered at $a = 1$. Write the general term and state the radius of convergence.

:::solution[Solution]
**Answer:** $\sum_{n=1}^\infty(-1)^{n-1}(x-1)^n/n$, interval $(0,2]$.

1. **Compute derivatives.**

$$
f(x) = \ln x,\quad f'(x) = \frac{1}{x},\quad f''(x) = -\frac{1}{x^2},\quad f'''(x) = \frac{2}{x^3},\quad f^{(n)}(x) = \frac{(-1)^{n-1}(n-1)!}{x^n}
$$

2. **Evaluate at $x=1$.**

$$
f(1)=0,\quad f'(1)=1,\quad f''(1)=-1,\quad f'''(1)=2,\quad f^{(n)}(1)=(-1)^{n-1}(n-1)!
$$

3. **Build the Taylor series.**

$$
\ln x = \sum_{n=1}^{\infty}\frac{f^{(n)}(1)}{n!}(x-1)^n = \sum_{n=1}^{\infty}\frac{(-1)^{n-1}(n-1)!}{n!}(x-1)^n = \sum_{n=1}^{\infty}\frac{(-1)^{n-1}}{n}(x-1)^n
$$

(Note: the $n=0$ term is $f(1)=0$, so the sum starts at $n=1$.)

4. **Radius of convergence via Ratio Test.**

$$
\left|\frac{a_{n+1}}{a_n}\right| = \frac{n}{n+1}|x-1|\to|x-1| \Rightarrow R=1
$$

Interval: $|x-1|<1$, i.e., $(0,2)$. At $x=2$: alternating harmonic series, converges. At $x=0$: harmonic series, diverges. Interval of convergence: $(0,2]$.

**Connection.**
Special case:

Substituting $x = 1+t$ gives the familiar $\ln(1+t) = t - t^2/2 + t^3/3 - \cdots$ centered at 0.
:::
::::

::::problem[D18 — Trig Series via Substitution]{difficulty=challenge}
Find the Maclaurin series for $\cos(x^2)$ and use it to compute $\displaystyle\int_0^1 \cos(x^2)\,dx$ as a series.

:::solution[Solution]
**Answer:** $\sum_{n=0}^\infty(-1)^nx^{4n}/(2n)!$ and $\int_0^1\cos(x^2)\,dx\approx0.9045$.

1. **Start from the known cosine series.**

$$
\cos u = \sum_{n=0}^{\infty}\frac{(-1)^n u^{2n}}{(2n)!} = 1-\frac{u^2}{2!}+\frac{u^4}{4!}-\cdots
$$

2. **Substitute $u = x^2$.**

$$
\cos(x^2) = \sum_{n=0}^{\infty}\frac{(-1)^n x^{4n}}{(2n)!} = 1-\frac{x^4}{2}+\frac{x^8}{24}-\frac{x^{12}}{720}+\cdots
$$

(Valid for all $x$ since $\cos u$ converges everywhere.)

3. **Integrate term by term from 0 to 1.**

$$
\int_0^1\cos(x^2)\,dx = \sum_{n=0}^{\infty}\frac{(-1)^n}{(2n)!}\cdot\frac{x^{4n+1}}{4n+1}\Bigg|_0^1 = \sum_{n=0}^{\infty}\frac{(-1)^n}{(2n)!(4n+1)}
$$

4. **Compute terms.**

$n=0$: $\dfrac{1}{1\cdot 1} = 1$

$n=1$: $-\dfrac{1}{2\cdot 5} = -0.1$

$n=2$: $\dfrac{1}{24\cdot 9} \approx 0.004630$

$n=3$: $-\dfrac{1}{720\cdot 13} \approx -0.0001068$

$$
\int_0^1\cos(x^2)\,dx \approx 1 - 0.1 + 0.004630 - 0.000107 \approx \boxed{0.9045}
$$

**Connection.**
This is the Fresnel integral

$C(1)$, which appears in optics and diffraction theory. Like $\text{Si}(x)$, it has no elementary closed form.
:::
::::

::::problem[D19 — Remainder Estimation]{difficulty=challenge}
How many terms of the series $\displaystyle\sum_{n=0}^{\infty}\frac{(-1)^n}{n!}$ are needed to approximate $e^{-1}$ to within $0.001$?

:::solution[Solution]
**Answer:** 7 terms, indices 0 through 6.

1. **Identify the series.** The series $\sum_{n=0}^{\infty}\dfrac{(-1)^n}{n!}$ is the Maclaurin series for $e^x$ evaluated at $x=-1$, so it sums to $e^{-1}$.

2. **Apply the Alternating Series Estimation Theorem.** For an alternating series satisfying the AST conditions, the error after $N+1$ terms (partial sum $S_N$) satisfies:

$$
|e^{-1}-S_N| \le b_{N+1} = \frac{1}{(N+1)!}
$$

 where $b_n = 1/n!$ is the $n$th term's absolute value. (Check: terms decrease since $(n+1)! > n!$; limit is 0. ✓)

3. **Solve the inequality.** We need:

$$
\frac{1}{(N+1)!} < 0.001 = \frac{1}{1000}
$$

$$
(N+1)! > 1000
$$

Check: $6! = 720 < 1000$ but $7! = 5040 > 1000$. So $N+1 = 7$, meaning $N=6$.

4. **Conclusion.** We need the partial sum $S_6$ — that is, terms from $n=0$ through $n=6$ (7 terms total) — to guarantee accuracy within 0.001.

**Key point.**
ASET shortcut:

For alternating series, just find the first omitted term and that bounds the error. No need for the full Taylor remainder formula.
:::
::::

::::problem[D20 — Combining Series & Finding a Closed Form]{difficulty=challenge}
Find the exact sum:

$$
\sum_{n=0}^{\infty}\frac{(n+1)x^n}{2^n}, \quad |x|<2
$$

:::solution[Solution]
**Answer:** $4/(2-x)^2$ for $|x|<2$.

1. **Rewrite using a substitution.** Let $t = x/2$, so $|t|<1$.

$$
\sum_{n=0}^{\infty}(n+1)t^n
$$

2. **Recognise the series.** From D8, we showed that $\dfrac{1}{(1-t)^2} = \displaystyle\sum_{n=0}^{\infty}(n+1)t^n$ for $|t|<1$.

3. **Substitute back.**

$$
\sum_{n=0}^{\infty}(n+1)t^n = \frac{1}{(1-t)^2} = \frac{1}{(1-x/2)^2}
$$

Simplify: $1-x/2 = (2-x)/2$, so $(1-x/2)^2 = (2-x)^2/4$.

$$
\sum_{n=0}^{\infty}\frac{(n+1)x^n}{2^n} = \frac{4}{(2-x)^2}
$$

4. **Verify with $x=0$.** $\sum(n+1)\cdot 0^n = 1$ (only $n=0$ term survives). Formula: $4/(2-0)^2 = 4/4 = 1$. ✓

**Intuition.**
General strategy:

Series involving $(n+1)a_n$ or $na_n$ almost always reduce to differentiating a known closed-form series. Memorize $\sum_{n=0}^\infty(n+1)x^n = 1/(1-x)^2$ as a tool.
:::
::::
