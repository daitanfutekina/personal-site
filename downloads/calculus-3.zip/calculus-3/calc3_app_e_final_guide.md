---
title: "Appendix E — MSU Final Exam Guide"
source: "markdown"
---

MA 2733 Calculus III · Instructor Danielle Young · Thomas 15e · Tests 1–4 / cumulative final

:::callout-key
About this guide.

The supplied course notes describe each test as **six written questions**, 15 or 20 points each, with no calculator. Young's stated topic lists and review materials are stronger evidence for what to study than speculative final-exam percentages. Practice exact expressions, hypotheses, and algebraic setup.
:::

## Topic Weight Estimates

**No defensible percentage estimates are available.** The earlier 35/25/20/15/5 weighting was conjecture, not published final-exam policy. Use the demonstrated test scopes instead; the final's distribution has not been supplied.

| Exam | Thomas 15e | Confirmed emphasis from supplied course notes |
| --- | --- | --- |
| Test 1 | Ch. 11, book Ch. 1 | Parametric and polar work (released keys were referenced but not included in this upload) |
| Test 2 | Ch. 12, book Ch. 3 | Vectors, 3D geometry and planes (keys referenced but not included here) |
| Test 3 | §§13.1–13.4, book Ch. 4 | Six questions chosen from nine: vector limit; velocity/speed/direction; tangent line; vector integral; IVP; arc length; $\mathbf T$; $\kappa$; $\mathbf N$ |
| Test 4 | §§10.1–10.8, book Ch. 2 | Recursive sequences, sequence limits; geometric and nth-term; Integral/p-series; Direct/LCT; Ratio/Root; alternating/absolute; intervals of power-series convergence; Taylor polynomials $P_0$–$P_3$ |

:::callout-key[What to omit on a time-limited review]
**Not on Test 3:** §§13.5–13.6, hyperbolic functions, integration by parts, advanced derivatives (csc/sec/cot, inverse trig, $a^t$). Only $\sin^2t+\cos^2t=1$ is needed as a trig identity. **Not on Test 4:** telescoping, Taylor remainder/error bounds, §§10.9–10.10. These may remain useful background, but they are not on those individual tests. Final coverage beyond the four test scopes is unconfirmed.
:::

## The Five Highest-Yield Problem Types

### 1. Convergence Tests for Series

This is a central skill on Test 4. You must be able to identify which test applies in under 30 seconds and execute it cleanly. Exam problems will have one right test and several plausible wrong ones.

:::callout-key
Written answer standard:

Name the test, show its hypotheses, compute the deciding limit or integral, and state the conclusion. The notes emphasize the justification; a precise point deduction for leaving it out was not supplied.
:::

Typical exam problem — Series convergence

Determine whether $\displaystyle\sum_{n=1}^\infty\frac{n^2+3}{n^4-2}$ converges or diverges.

:::solution[Approach]
**Identify:** Rational function of $n$ → Limit Comparison Test. Compare to $\sum 1/n^2$ (dominant terms: $n^2/n^4=1/n^2$).

**Compute:** $\lim_{n\to\infty}\dfrac{(n^2+3)/(n^4-2)}{1/n^2}=\lim\dfrac{n^2(n^2+3)}{n^4-2}=\lim\dfrac{n^4+3n^2}{n^4-2}=1$.

**Conclude:** Since $0<1<\infty$ and $\sum 1/n^2$ converges (p-series, $p=2>1$), our series converges by LCT.
:::

### 2. Taylor / Maclaurin Series and Intervals of Convergence

Test 4 includes radius/interval of convergence and $P_0$–$P_3$ Taylor polynomials from derivative data. Manipulating known power-series representations in §§10.9–10.10 is **not on Test 4**.

:::callout-warning
Endpoint testing is mandatory.

Finding the open interval and stopping loses points. Always test $x=\pm R$ (or $x=a\pm R$) separately using the tests you know.
:::

Typical exam problem — Maclaurin series

Find the Maclaurin series for $f(x)=x^2e^{-x}$ and state its radius of convergence.

:::solution[Approach]
Start from $e^u=\sum u^n/n!$. Set $u=-x$: $e^{-x}=\sum(-1)^n x^n/n!$. Multiply by $x^2$:

$$
x^2 e^{-x}=\sum_{n=0}^\infty\frac{(-1)^n x^{n+2}}{n!}.
$$

 Re-index ($m=n+2$): $\displaystyle\sum_{m=2}^\infty\frac{(-1)^{m-2}x^m}{(m-2)!}$. Radius $R=\infty$ (same as $e^x$).
:::

:::callout-tip[Test 4 Taylor polynomial template]
For $f(x)=3\ln x$ at $a=1$, take derivatives: $f(1)=0$, $f'(x)=3/x$ so $f'(1)=3$, $f''(x)=-3/x^2$ so $f''(1)=-3$, and $f^{(3)}(x)=6/x^3$ so $f^{(3)}(1)=6$. Thus

$$P_0=0,\quad P_1=3(x-1),\quad P_2=3(x-1)-\frac32(x-1)^2,$$

$$P_3=3(x-1)-\frac32(x-1)^2+(x-1)^3.$$

Write each derivative and its value at the center. This is a **polynomial** problem from §10.8, not a Taylor-remainder question.
:::

### 3. Equations of Lines and Planes in 3D

These are common Thomas Ch. 12 setups to practice for Test 2. The source notes do not establish how many appear on an individual exam.

Typical exam problem — Planes

Find the equation of the plane through $A(2,0,-1)$, $B(1,3,2)$, $C(4,-1,1)$.

:::solution[Approach]
Two vectors in plane: $\overrightarrow{AB}=\langle-1,3,3\rangle$, $\overrightarrow{AC}=\langle2,-1,2\rangle$.

Normal: $\vec{n}=\overrightarrow{AB}\times\overrightarrow{AC}=\langle(3)(2)-(3)(-1),\;(3)(2)-(-1)(2),\;(-1)(-1)-(3)(2)\rangle=\langle9,8,-5\rangle$.

Plane through $A(2,0,-1)$: $9(x-2)+8y-5(z+1)=0\Rightarrow9x+8y-5z=23$.
:::

### 4. Dot and Cross Product Applications

Angle between vectors, projections, area of triangles/parallelograms, volume of parallelepipeds. These are fast points if you know the formulas cold.

:::callout-pitfall
Most missed point:

In the cross product determinant, the $\hat{\jmath}$ term has a negative sign. Students rush this and lose the sign, getting a wrong normal vector, which then ruins the plane equation.
:::

### 5. Curvature and the TNB Frame

On Test 3, $\kappa$, $\hat{T}$ and $\hat{N}$ are explicitly among Young's nine listed topics. Tangential/normal acceleration components belong to later material, **not on Test 3**.

Typical exam problem — Curvature

For $\vec{r}(t)=\langle 3\cos t,3\sin t,4t\rangle$, find: (a) the curvature $\kappa$, (b) the unit tangent $\hat{T}$ at $t=\pi/2$.

:::solution[Approach]
$\vec{r}\,'=\langle-3\sin t,3\cos t,4\rangle$, $|\vec{r}\,'|=\sqrt{9+16}=5$. $\vec{r}\,''=\langle-3\cos t,-3\sin t,0\rangle$.

Cross product, with the middle cofactor carrying its minus sign:

$$
\vec{r}\,'\times\vec{r}\,''=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\-3\sin t&3\cos t&4\\-3\cos t&-3\sin t&0\end{vmatrix}=\langle12\sin t,\;-12\cos t,\;9\rangle.
$$

$$
|\vec{r}\,'\times\vec{r}\,''|=\sqrt{144\sin^2t+144\cos^2t+81}=\sqrt{144+81}=\sqrt{225}=15.
$$

$$
\kappa=15/5^3=15/125=\mathbf{3/25}.
$$

 At $t=\pi/2$: $\vec{r}\,'=\langle-3,0,4\rangle$, so $\hat{T}=\langle-3/5,0,4/5\rangle$.
:::

## Top 10 Exam Mistakes to Avoid

1. Series Stopping after finding the open interval — always test endpoints.
2. Series Concluding convergence from the Divergence Test. It can only prove divergence.
3. Series Ratio/Root Test returning $L=1$ and stopping — this is inconclusive, not convergent.
4. Vectors Forgetting the negative sign on the $\hat{\jmath}$ cofactor in the cross product.
5. Vectors Using $|\vec{r}\,''|$ as curvature — curvature is $|\vec{r}\,'\times\vec{r}\,''|/|\vec{r}\,'|^3$, not $|\vec{r}\,''|$.
6. Vectors Mixing up direction vector (lines) and normal vector (planes).
7. Motion Saying "constant speed = zero acceleration." Zero $a_T$ ≠ zero $\vec{a}$.
8. Polar Using the wrong limits of integration for polar area — sketch the curve first.
9. Polar Forgetting the $1/2$ in the polar area formula $A=\tfrac{1}{2}\int r^2\,d\theta$.
10. Taylor Computing Taylor coefficients without checking the pattern — always verify $f^{(n)}(a)/n!$.

## Recommended Final Exam Study Schedule

Assumes 7 days before the exam. Adjust to your timeline.

| Day | Focus | Target |
| --- | --- | --- |
| Day 7–6 | Ch. 2 convergence tests — drill assigned test types until identification is automatic. Use Appendix A decision tree. | Can identify a suitable test and give written justification |
| Day 5 | Ch. 2 power series, radius/interval of convergence, Taylor polynomials $P_0$–$P_3$. Practice derivative tables at a center. | Can find $R$ via Ratio Test and test both endpoints |
| Day 4 | Ch. 3 — dot product, cross product, lines, planes. Do a full written set by hand. | Can set up and solve a plane through three points correctly |
| Day 3 | Ch. 4 — vector limits, velocity/speed/direction, tangent lines, vector integrals and IVPs, arc length, curvature, $\mathbf T$ and $\mathbf N$. | Can compute $\mathbf T$, $\mathbf N$, and $\kappa$ at a stated parameter |
| Day 2 | Ch. 1 — parametric slope, arc length, polar area. Use course examples rather than unsupported student rankings. | Confident with polar area integral setup including limits |
| Day 1 | Mixed review — do the 10 mixed practice problems from each chapter. Check against Appendix D. Identify any gaps. | No chapter feels unfamiliar; all formula sheet entries memorized |
| Exam day | Light review of Appendix B formula sheet. No new problems. Get sleep. | — |

## Must-Memorize Formulas (Prepare Without a Calculator)

:::callout-warning
Tests 1–4 have a no-calculator policy in the supplied notes. The final's formula-sheet policy was not included; memorize these rather than presuming a sheet will be provided.

These are the formulas most likely needed without reference:

- Geometric series: $\sum ar^n = a/(1-r)$ for $|r|<1$
- Taylor polynomials $P_0$–$P_3$: $\sum_{k=0}^m f^{(k)}(a)(x-a)^k/k!$ (Test 4); known Maclaurin formulas can be a supplementary reference
- Angle formula: $\cos\theta=\vec{a}\cdot\vec{b}/(|\vec{a}||\vec{b}|)$
- Curvature: $\kappa=|\vec{r}\,'\times\vec{r}\,''|/|\vec{r}\,'|^3$
- Plane equation: $a(x-x_0)+b(y-y_0)+c(z-z_0)=0$
- Point-to-plane distance: $D=|ax_1+by_1+cz_1-d|/\sqrt{a^2+b^2+c^2}$
- Polar area: $A=\tfrac{1}{2}\int r^2\,d\theta$
- Space-curve arc length: $L=\int_a^b\sqrt{(dx/dt)^2+(dy/dt)^2+(dz/dt)^2}\,dt$; plane parametric arc length omits the $z$ component
:::


## Six-Question Written Test Simulation

Do one timed, no-calculator mock from the confirmed topic pools. **Test 3 sample lineup:** (1) finite vector limit with a $0/0$ component, (2) velocity, speed and direction at $t_0$, (3) tangent line, (4) vector integral with an initial condition, (5) arc length with a speed simplifying via $\sin^2+\cos^2=1$ and a $u$-substitution, (6) $\mathbf T$ plus $\mathbf N$ or curvature. This lineup is a **study simulation**, not a prediction of the actual six questions.

**Test 4 sample lineup:** (1) recursive terms, nth-term pattern and sequence limit; (2) geometric sums and nth-term divergence; (3) Integral Test with all three function hypotheses; (4) direct/limit comparison; (5) Ratio/Root and alternating absolute/conditional classification; (6) radius/interval with endpoints and $P_0$–$P_3$. Grouping is a practice convenience; actual exam grouping is unspecified.

:::callout-pitfall[What earns written points]
An answer without the correct **setup and named method** is incomplete. For L'Hôpital, show $0/0$ (or $\infty/\infty$) before differentiating top and bottom. For Integral Test, record continuity, positivity, and decreasing behavior. For AST, state all three conditions and separately classify absolute versus conditional. For a parametric tangent, give the point and direction vector. For curvature, calculate $|\mathbf v\times\mathbf a|/|\mathbf v|^3$, not $|\mathbf a|$.
:::
