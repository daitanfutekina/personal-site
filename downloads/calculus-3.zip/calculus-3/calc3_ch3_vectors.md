---
title: "Vectors and the Geometry of Space"
crumb: "Calculus 3 · Chapter 3 (Thomas Ch. 12)"
meta:
  - "Est. study time: ~5–6 hours"
  - "Thomas' Calculus ET 15e, Ch. 12"
  - "Welcome to 3D"
source: "markdown"
---


## Overview

Everything up to this point has lived in two dimensions — curves in the plane, series on the number line. This chapter is where calculus steps into three-dimensional space, and it changes your geometric intuition permanently. The key objects are **vectors**: quantities that have both magnitude and direction. Unlike scalars (plain numbers), vectors let you encode direction in the mathematics itself, which turns out to be essential for describing motion, force, and geometry in 3D.

The chapter builds the vocabulary and algebraic toolkit of 3D geometry from the ground up. You start with coordinates (§12.1), introduce vectors and their arithmetic (§12.2), then develop two products — the **dot product** (§12.3), which measures how much two vectors align, and the **cross product** (§12.4), which produces a vector perpendicular to both. With those tools, §12.5 gives you the equations of lines and planes in 3D space. The chapter closes with a catalogue of the important 3D surfaces you'll encounter (§12.6).

This chapter is foundational — every topic in Chapter 4 (Thomas Ch. 13: vector functions, curvature, motion) and all of multivariable calculus (Calc IV) builds directly on it. The good news is that most of the algebra is mechanical once you learn the patterns. The hard part is building 3D spatial intuition; the worked examples are designed to help you do that.

:::callout-key[Notation used in this chapter]
- Vectors: $\vec{v}$ (arrow over letter, never bold)
- Components: angle-bracket form $\langle a, b, c\rangle$
- Standard basis: $\hat{\imath} = \langle 1,0,0\rangle$, $\hat{\jmath} = \langle 0,1,0\rangle$, $\hat{k} = \langle 0,0,1\rangle$
- Magnitude: $|\vec{v}|$ (never $\|\vec{v}\|$ in this course)
:::

:::callout-key[Prerequisites from Chapter 0]
- Distance formula and coordinate geometry in 2D (Ch. 0 §0.8) — we extend both to 3D
- Trigonometry — especially $\cos\theta$ and $\sin\theta$ — appears in both the dot and cross product geometry
- Systems of equations — for intersection problems in §12.5
:::

## 12.1 Three-Dimensional Coordinate Systems

:::callout-connect
📺 Watch before this section

“3D coordinate systems | Multivariable Calculus” — Khan Academy
:::

:::callout-intuition[Intuition — adding a third axis]
In 2D you locate a point with two numbers $(x,y)$: right/left and up/down. In 3D you need a third number $z$ for the in/out direction. The three axes — $x$, $y$, and $z$ — are mutually perpendicular and meet at the **origin**. The choice of which direction $z$ points follows the **right-hand rule**: curl the fingers of your right hand from the positive $x$-axis toward the positive $y$-axis, and your thumb points in the direction of positive $z$. This convention is universal in mathematics and physics.

With the three axes established, every point in space has a unique address $(x, y, z)$. The three coordinate planes — the $xy$-plane ($z=0$), the $xz$-plane ($y=0$), and the $yz$-plane ($x=0$) — divide space into eight regions called **octants**. The first octant is where all three coordinates are positive.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 277 300" width="277" height="300" role="img" aria-label="The point P(2,3,4) in space, joined to the axes by the dashed edges of its coordinate box">
<path class="fig-fill" d="M91.54 217.11L53.08 246.53L161.58 270L200.05 240.58Z"/>
<path class="fig-axis" d="M91.54 217.11L30 264.19"/>
<path class="fig-axis" d="M91.54 217.11L247.07 250.75"/>
<path class="fig-axis" d="M91.54 217.11L91.54 30"/>
<path class="fig-guide" d="M53.08 246.53L161.58 270"/>
<path class="fig-guide" d="M53.08 246.53L53.08 96.84"/>
<path class="fig-guide" d="M200.05 240.58L161.58 270"/>
<path class="fig-guide" d="M200.05 240.58L200.05 90.89"/>
<path class="fig-guide" d="M91.54 67.42L53.08 96.84"/>
<path class="fig-guide" d="M91.54 67.42L200.05 90.89"/>
<path class="fig-guide" d="M161.58 270L161.58 120.31"/>
<path class="fig-guide" d="M53.08 96.84L161.58 120.31"/>
<path class="fig-guide" d="M200.05 90.89L161.58 120.31"/>
<path class="fig-axis" d="M30.01 264.17L30 264.19L30.02 264.18"/>
<path class="fig-axis" d="M247.04 250.75L247.07 250.75L247.05 250.73"/>
<path class="fig-axis" d="M91.55 30.02L91.54 30L91.53 30.02"/>
<circle class="fig-point" cx="91.54" cy="217.11" r="3.2"/>
<circle class="fig-point" cx="161.58" cy="120.31" r="3.2"/>
<text class="fig-label-em" x="19.06" y="273.26">x</text>
<text class="fig-label-em" x="253.84" y="255.86">y</text>
<text class="fig-label-em" x="88.54" y="23">z</text>
<text class="fig-label-em" x="167.58" y="115.31">P(2, 3, 4)</text>
<text class="fig-label" x="44.08" y="255.53">2</text>
<text class="fig-label" x="202.05" y="252.58">3</text>
<text class="fig-label" x="80.54" y="71.42">4</text>
<text class="fig-label" x="165.58" y="282">(2, 3, 0)</text>
<text class="fig-label" x="81.54" y="229.11">O</text>
</svg>
<figcaption>The point $P(2,3,4)$ is reached by going $2$ along $x$, $3$ along $y$ and $4$ up in $z$; the dashed box has $P$ and the origin as opposite corners, and its foot $(2,3,0)$ is the shadow of $P$ in the $xy$-plane.</figcaption>
</figure>

Plotting a point in three dimensions is harder than in two, because the page is flat and the point does not look as though it sits at its numbers. The trick that helps most is to picture the point as the far corner of a box. Start at the origin, walk $x$ units along the $x$-axis, then $y$ units parallel to the $y$-axis, then $z$ units parallel to the $z$-axis. The figure above does this for the point $(2,3,4)$: the dashed edges are the three walks, and the point is where the third walk ends. A negative coordinate simply means you walk the opposite way along that axis.

:::::example[Example 3.1 — Plotting points, and which plane is nearest]
Sketch the points $(1,5,3)$, $(0,2,-3)$, $(-3,0,2)$ and $(2,-2,-1)$ on a single set of axes. Which point is closest to the $xy$-plane? Which point lies in the $xz$-plane?

::::answer[Answer]
**Answer:** $(2,-2,-1)$ is closest to the $xy$-plane, and $(-3,0,2)$ lies in the $xz$-plane.

1. To sketch each point, build its box. For $(1,5,3)$, go $1$ unit along the positive $x$-axis, then $5$ units in the positive $y$ direction, then $3$ units up. For $(0,2,-3)$ the $x$-walk has length $0$, so the point sits in the $yz$-plane: go $2$ units along $y$, then $3$ units down. For $(-3,0,2)$ go $3$ units in the negative $x$ direction, do not move in $y$, and go $2$ units up. For $(2,-2,-1)$ go $2$ along $x$, $2$ in the negative $y$ direction, and $1$ down.

2. Now the two questions. The $xy$-plane is the plane $z=0$, and the distance from a point to it is the size of its $z$-coordinate, $|z|$. The four $z$-values are $3$, $-3$, $2$ and $-1$, so the four distances are

$$
|3|=3,\qquad |-3|=3,\qquad |2|=2,\qquad |-1|=1.
$$

3. The smallest is $1$, which belongs to $(2,-2,-1)$. So that point is closest to the $xy$-plane.

4. The $xz$-plane is the plane $y=0$, so a point lies in it exactly when its $y$-coordinate is $0$. The four $y$-values are $5$, $2$, $0$ and $-2$. Only $(-3,0,2)$ has $y=0$, so it is the point in the $xz$-plane.

5. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

### Distance Formula in $\mathbb{R}^3$

The 2D distance formula $d = \sqrt{(x_2-x_1)^2+(y_2-y_1)^2}$ extends to 3D by applying the Pythagorean theorem twice — first in a horizontal plane, then vertically.

:::theorem[Theorem 12.1.1 — Distance Formula in $\mathbb{R}^3$]
The distance between points $P_1 = (x_1,y_1,z_1)$ and $P_2 = (x_2,y_2,z_2)$ is:

$$
|P_1P_2| = \sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}.
$$
:::

### Equations of Spheres

A sphere is the set of all points at a fixed distance $r$ (the radius) from a center $(h,k,l)$. Using the distance formula, the equation is immediate.

:::definition[Definition 12.1.1 — Equation of a Sphere]
The sphere with center $(h, k, l)$ and radius $r$ has equation:

$$
(x-h)^2 + (y-k)^2 + (z-l)^2 = r^2.
$$
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 278 300" width="278" height="300" role="img" aria-label="The sphere with center (1,2,3) and radius 2, with its equator and center marked">
<path class="fig-axis" d="M95.15 220.16L30 270"/>
<path class="fig-axis" d="M95.15 220.16L248.31 253.29"/>
<path class="fig-axis" d="M95.15 220.16L95.15 30"/>
<path class="fig-guide" d="M209.47 149.81L209.34 148.82L209.13 147.84L208.84 146.86L208.46 145.89L208 144.92L207.45 143.96L206.83 143.01L206.12 142.07L205.33 141.14L204.46 140.22L203.51 139.31L202.49 138.42L201.39 137.54L200.22 136.68L198.97 135.83L197.65 135.01L196.26 134.2L194.8 133.41L193.28 132.65L191.69 131.91L190.04 131.19L188.33 130.49L186.56 129.82L184.73 129.17L182.85 128.55L180.91 127.96L178.93 127.39L176.9 126.86L174.82 126.35L172.7 125.87L170.54 125.42L168.35 125.01L166.12 124.62L163.86 124.27L161.57 123.95L159.25 123.66L156.91 123.41L154.55 123.18L152.18 123L149.78 122.84L147.38 122.72L144.97 122.64L142.55 122.59L140.13 122.57L137.71 122.59L135.29 122.64L132.87 122.72L130.47 122.84L128.08 123L125.7 123.18L123.34 123.41L121 123.66L118.69 123.95L116.4 124.27L114.13 124.62L111.9 125.01L109.71 125.42L107.55 125.87L105.43 126.35L103.36 126.86L101.33 127.39L99.34 127.96L97.41 128.55L95.53 129.17L93.7 129.82L91.93 130.49L90.21 131.19L88.56 131.91L86.97 132.65L85.45 133.41L83.99 134.2L82.6 135.01L81.28 135.83L80.04 136.68L78.86 137.54L77.76 138.42L76.74 139.31L75.79 140.22L74.93 141.14L74.14 142.07L73.43 143.01L72.8 143.96L72.26 144.92L71.79 145.89L71.42 146.86L71.12 147.84L70.91 148.82L70.78 149.81L70.74 150.79"/>
<path class="fig-guide" d="M97.57 95.99L96.06 97.23L94.6 98.53L93.2 99.9L91.85 101.32L90.56 102.81L89.34 104.36L88.17 105.96L87.07 107.62L86.03 109.33L85.06 111.09L84.16 112.9L83.32 114.76L82.56 116.66L81.86 118.6L81.24 120.58L80.68 122.6L80.2 124.65L79.79 126.73L79.46 128.85L79.2 130.99L79.01 133.15L78.9 135.34L78.86 137.54L78.9 139.76L79.01 141.99L79.2 144.24L79.46 146.49L79.79 148.75L80.2 151.01L80.68 153.27L81.24 155.53L81.86 157.78L82.56 160.02L83.32 162.25L84.16 164.47L85.06 166.67L86.03 168.85L87.07 171.01L88.17 173.14L89.34 175.25L90.56 177.33L91.85 179.37L93.2 181.39L94.6 183.36L96.06 185.29L97.57 187.18L99.13 189.03L100.75 190.83L102.41 192.58L104.12 194.28L105.87 195.93L107.66 197.52L109.49 199.06L111.37 200.54L113.27 201.95L115.21 203.31L117.18 204.6L119.17 205.82L121.2 206.98L123.24 208.07L125.31 209.09L127.39 210.04L129.49 210.91L131.6 211.72L133.72 212.45L135.85 213.1L137.99 213.68L140.13 214.18L142.27 214.6L144.4 214.95L146.53 215.22L148.65 215.4L150.77 215.52L152.86 215.55L154.95 215.5L157.01 215.37L159.06 215.17L161.08 214.89L163.08 214.53L165.05 214.09L166.98 213.57L168.89 212.98L170.76 212.31L172.59 211.57L174.39 210.75L176.14 209.86L177.85 208.9L179.51 207.86L181.12 206.76L182.68 205.59"/>
<path class="fig-guide" d="M78.86 232.62L140.13 245.87"/>
<path class="fig-guide" d="M156.41 233.41L140.13 245.87"/>
<path class="fig-guide" d="M140.13 245.87L140.13 150.79"/>
<path class="fig-guide" d="M140.13 150.79L201.39 164.04"/>
<path class="fig-curve-alt" d="M182.28 205.9L183.99 204.55L185.66 203.15L187.28 201.69L188.86 200.18L190.39 198.63L191.86 197.03L193.29 195.38L194.67 193.69L195.99 191.95L197.25 190.18L198.46 188.36L199.61 186.51L200.7 184.63L201.74 182.71L202.71 180.76L203.62 178.77L204.47 176.77L205.25 174.73L205.97 172.68L206.63 170.6L207.22 168.5L207.74 166.38L208.2 164.25L208.58 162.11L208.91 159.95L209.16 157.78L209.35 155.61L209.46 153.44L209.51 151.26L209.49 149.08L209.4 146.9L209.25 144.73L209.02 142.56L208.73 140.4L208.37 138.25L207.94 136.11L207.45 133.99L206.89 131.88L206.26 129.79L205.57 127.73L204.81 125.68L203.99 123.66L203.11 121.67L202.16 119.71L201.15 117.77L200.09 115.87L198.96 114.01L197.78 112.18L196.53 110.38L195.24 108.63L193.89 106.92L192.48 105.26L191.03 103.63L189.52 102.06L187.96 100.53L186.36 99.05L184.71 97.63L183.02 96.25L181.29 94.93L179.51 93.67L177.7 92.46L175.85 91.31L173.96 90.21L172.04 89.18L170.09 88.21L168.11 87.3L166.1 86.45L164.07 85.67L162.01 84.95L159.93 84.29L157.83 83.7L155.72 83.18L153.59 82.72L151.44 82.33L149.29 82.01L147.12 81.76L144.95 81.57L142.77 81.45L140.59 81.41L138.41 81.42L136.24 81.51L134.06 81.67L131.89 81.89L129.73 82.19L127.58 82.55L125.45 82.97L123.32 83.47L121.22 84.03L119.13 84.66L117.06 85.35L115.02 86.11L113 86.93L111.01 87.81L109.04 88.76L107.11 89.76L105.21 90.83L103.34 91.96L101.51 93.14L99.72 94.38L97.97 95.68L96.26 97.03L94.59 98.44L92.97 99.89L91.39 101.4L89.87 102.95L88.39 104.56L86.96 106.2L85.59 107.89L84.27 109.63L83 111.4L81.79 113.22L80.64 115.07L79.55 116.95L78.52 118.87L77.54 120.83L76.63 122.81L75.79 124.81L75 126.85L74.28 128.91L73.63 130.98L73.04 133.08L72.51 135.2L72.06 137.33L71.67 139.47L71.35 141.63L71.09 143.8L70.91 145.97L70.79 148.14L70.74 150.32L70.76 152.5L70.85 154.68L71.01 156.86L71.23 159.02L71.52 161.18L71.88 163.33L72.31 165.47L72.81 167.59L73.37 169.7L73.99 171.79L74.69 173.85L75.44 175.9L76.26 177.92L77.15 179.91L78.09 181.87L79.1 183.81L80.17 185.71L81.29 187.57L82.48 189.4L83.72 191.2L85.02 192.95L86.37 194.66L87.77 196.33L89.23 197.95L90.73 199.52L92.29 201.05L93.89 202.53L95.54 203.95L97.23 205.33L98.97 206.65L100.74 207.91L102.55 209.12L104.41 210.27L106.29 211.37L108.21 212.4L110.16 213.37L112.14 214.28L114.15 215.13L116.18 215.91L118.24 216.63L120.32 217.29L122.42 217.88L124.54 218.4L126.67 218.86L128.81 219.25L130.97 219.57L133.13 219.82L135.3 220.01L137.48 220.13L139.66 220.17L141.84 220.16L144.02 220.07L146.19 219.91L148.36 219.69L150.52 219.39L152.67 219.03L154.81 218.61L156.93 218.11L159.04 217.55L161.12 216.92L163.19 216.23L165.24 215.47L167.25 214.65L169.25 213.77L171.21 212.82L173.14 211.82L175.04 210.75L176.91 209.62L178.74 208.44L180.53 207.2L182.28 205.9"/>
<path class="fig-curve" d="M107.55 175.71L109.71 176.16L111.9 176.57L114.13 176.96L116.4 177.31L118.69 177.63L121 177.92L123.34 178.17L125.7 178.4L128.08 178.58L130.47 178.74L132.87 178.86L135.29 178.94L137.71 178.99L140.13 179.01L142.55 178.99L144.97 178.94L147.38 178.86L149.78 178.74L152.18 178.58L154.55 178.4L156.91 178.17L159.25 177.92L161.57 177.63L163.86 177.31L166.12 176.96L168.35 176.57L170.54 176.16L172.7 175.71L174.82 175.23L176.9 174.72L178.93 174.19L180.91 173.62L182.85 173.03L184.73 172.41L186.56 171.76L188.33 171.09L190.04 170.39L191.69 169.67L193.28 168.93L194.8 168.17L196.26 167.38L197.65 166.57L198.97 165.75L200.22 164.9L201.39 164.04L202.49 163.16L203.51 162.27L204.46 161.36L205.33 160.44L206.12 159.51L206.83 158.57L207.45 157.62L208 156.66L208.46 155.69L208.84 154.72L209.13 153.74L209.34 152.76L209.47 151.78L209.51 150.79L209.47 149.81"/>
<path class="fig-curve" d="M70.74 150.79L70.78 151.78L70.91 152.76L71.12 153.74L71.42 154.72L71.79 155.69L72.26 156.66L72.8 157.62L73.43 158.57L74.14 159.51L74.93 160.44L75.79 161.36L76.74 162.27L77.76 163.16L78.86 164.04L80.04 164.9L81.28 165.75L82.6 166.57L83.99 167.38L85.45 168.17L86.97 168.93L88.56 169.67L90.21 170.39L91.93 171.09L93.7 171.76L95.53 172.41L97.41 173.03L99.34 173.62L101.33 174.19L103.36 174.72L105.43 175.23L107.55 175.71"/>
<path class="fig-curve" d="M201.39 164.04L201.35 161.82L201.24 159.59L201.06 157.34L200.8 155.09L200.46 152.83L200.05 150.57L199.57 148.31L199.02 146.05L198.39 143.8L197.7 141.56L196.93 139.33L196.09 137.11L195.19 134.91L194.22 132.73L193.18 130.57L192.08 128.44L190.92 126.33L189.69 124.25L188.4 122.21L187.06 120.2L185.66 118.22L184.2 116.29L182.68 114.4L181.12 112.55L179.51 110.75L177.85 109L176.14 107.3L174.39 105.65L172.59 104.06L170.76 102.52L168.89 101.04L166.98 99.63L165.05 98.27L163.08 96.98L161.08 95.76L159.06 94.6L157.01 93.51L154.95 92.49L152.86 91.54L150.77 90.67L148.65 89.86L146.53 89.13L144.4 88.48L142.27 87.9L140.13 87.4L137.99 86.98L135.85 86.63L133.72 86.36L131.6 86.18L129.49 86.06L127.39 86.03L125.31 86.08L123.24 86.21L121.2 86.41L119.17 86.69L117.18 87.05L115.21 87.49L113.27 88.01L111.37 88.6L109.49 89.27L107.66 90.01L105.87 90.83L104.12 91.72L102.41 92.68L100.75 93.72L99.13 94.82L97.57 95.99"/>
<path class="fig-curve" d="M182.68 205.59L184.2 204.35L185.66 203.05L187.06 201.68L188.4 200.26L189.69 198.77L190.92 197.22L192.08 195.62L193.18 193.96L194.22 192.25L195.19 190.49L196.09 188.68L196.93 186.82L197.7 184.92L198.39 182.98L199.02 181L199.57 178.98L200.05 176.93L200.46 174.85L200.8 172.73L201.06 170.59L201.24 168.43L201.35 166.24L201.39 164.04"/>
<path class="fig-axis" d="M30.01 269.99L30 270L30.01 270"/>
<path class="fig-axis" d="M248.29 253.29L248.31 253.29L248.29 253.27"/>
<path class="fig-axis" d="M95.16 30.02L95.15 30L95.14 30.02"/>
<circle class="fig-point" cx="140.13" cy="150.79" r="3.2"/>
<circle class="fig-point" cx="201.39" cy="164.04" r="3.2"/>
<text class="fig-label-em" x="19.06" y="279.08">x</text>
<text class="fig-label-em" x="255.09" y="258.4">y</text>
<text class="fig-label-em" x="92.15" y="23">z</text>
<text class="fig-label-em" x="102.13" y="142.79">C(1, 2, 3)</text>
<text class="fig-label" x="164.76" y="172.41">r = 2</text>
</svg>
<figcaption>The sphere $(x-1)^2+(y-2)^2+(z-3)^2=4$ is every point at distance $2$ from the center $C(1,2,3)$; the solid curves are its equator $z=3$ and the great circle $x=1$, the dashed parts are on the far side.</figcaption>
</figure>

When you encounter a second-degree equation in $x$, $y$, and $z$ with equal coefficients on the squared terms and no cross terms, it may be a sphere in disguise. **Complete the square** in each variable to reveal the center and radius.

:::::example[Example 3.2 — Distance in 3D]
Find the distance between $A = (1, -2, 4)$ and $B = (3, 0, -1)$.

::::answer[Answer]
**Answer:** $\sqrt{33}$

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. Apply the distance formula directly:

$$
|AB| = \sqrt{(3-1)^2+(0-(-2))^2+(-1-4)^2} = \sqrt{4+4+25} = \sqrt{33}.
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::example[Example 3.3 — Two more distances]
Find the distance between the points (a) $P_1(-1,1,5)$ and $P_2(2,5,0)$, and (b) $P_1(3,4,5)$ and $P_2(2,3,4)$.

::::answer[Answer]
**Answer:** (a) $5\sqrt2$. (b) $\sqrt3$.

1. (a) Subtract coordinates in the same order for all three pairs, then square. Note that $2-(-1)=3$, because subtracting a negative adds.

$$
\begin{aligned}
|P_1P_2| &= \sqrt{\left(2-(-1)\right)^2+(5-1)^2+(0-5)^2}\\
&= \sqrt{9+16+25}\\
&= \sqrt{50}=\sqrt{25\cdot 2}=5\sqrt2.
\end{aligned}
$$

2. (b) Here each difference is $-1$, and squaring removes the sign.

$$
\begin{aligned}
|P_1P_2| &= \sqrt{(2-3)^2+(3-4)^2+(4-5)^2}\\
&= \sqrt{1+1+1}=\sqrt3.
\end{aligned}
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

Distance to a plane or to an axis is a special case of the distance formula, and each has a shortcut worth knowing. The distance from a point to a coordinate plane is the absolute value of the one coordinate that plane fixes: to the $xy$-plane ($z=0$) it is $|z|$, to the $xz$-plane ($y=0$) it is $|y|$, to the $yz$-plane ($x=0$) it is $|x|$. The same idea works for a plane parallel to one of these, such as $y=-5$: subtract the plane's constant from the matching coordinate and take the absolute value. To find the distance to an axis, use the nearest point on that axis, which shares the point's coordinate along the axis and has zero in the other two.

:::::example[Example 3.4 — Distance to planes and to an axis]
Find the distance from the point $(3,-4,2)$ to each of: (a) the $xz$-plane, (b) the plane $y=-5$, (c) the $z$-axis.

::::answer[Answer]
**Answer:** (a) $4$. (b) $1$. (c) $5$.

1. (a) The $xz$-plane is $y=0$. The point has $y=-4$, so the distance is $|-4-0|=4$.

2. (b) The plane $y=-5$ is parallel to the $xz$-plane. The nearest point on it keeps $x=3$ and $z=2$ and changes only $y$ to $-5$, giving the foot $(3,-5,2)$. The distance from $(3,-4,2)$ to that foot is

$$
d=\sqrt{(3-3)^2+(-5-(-4))^2+(2-2)^2}=\sqrt{0+1+0}=1.
$$

3. Equivalently, $d=|y_0-(-5)|=|-4+5|=1$.

4. (c) The nearest point on the $z$-axis keeps $z=2$ and sets $x=0$, $y=0$, so it is $(0,0,2)$. Then

$$
\begin{aligned}
d &= \sqrt{(3-0)^2+(-4-0)^2+(2-2)^2}\\
&= \sqrt{9+16}\\
&= \sqrt{25}=5.
\end{aligned}
$$

5. The $z$-coordinate drops out because the point and its foot on the $z$-axis are at the same height. So for the $z$-axis the distance is just $\sqrt{x^2+y^2}$.

6. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

:::::example[Example 3.5 — Equation of a sphere]
Write the equation of the sphere with center $(2, -1, 3)$ and radius $5$. Then check whether the point $(6, -1, 3)$ lies on it.

::::answer[Answer]
**Answer:** $(x-2)^2+(y+1)^2+(z-3)^2=25$; $(6,-1,3)$ is **not on the sphere**, since $16\ne25$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Direct substitution into the formula: $(x-2)^2+(y-(-1))^2+(z-3)^2=5^2$, i.e., $(x-2)^2+(y+1)^2+(z-3)^2=25$.

3. Check $(6,-1,3)$: $(6-2)^2+(-1+1)^2+(3-3)^2 = 16+0+0=16 \ne 25$. That point is NOT on the sphere. Try $(7,-1,3)$: $(7-2)^2=25=25$. ✓
::::
:::::

:::::example[Example 3.6 — Sphere equations with fractional data]
Find an equation of the sphere with (a) center $C=(1,2,3)$ and radius $\sqrt{14}$, and (b) center $C=\left(-1,\tfrac12,-\tfrac23\right)$ and radius $\tfrac49$.

::::answer[Answer]
**Answer:** (a) $(x-1)^2+(y-2)^2+(z-3)^2=14$. (b) $(x+1)^2+\left(y-\tfrac12\right)^2+\left(z+\tfrac23\right)^2=\tfrac{16}{81}$.

1. Substitute the center into $(x-h)^2+(y-k)^2+(z-l)^2=r^2$ and square the radius on the right.

2. (a) Since $\left(\sqrt{14}\right)^2=14$,

$$
(x-1)^2+(y-2)^2+(z-3)^2=\left(\sqrt{14}\right)^2=14.
$$

3. (b) Write each subtraction out, remembering that subtracting a negative number gives a plus sign:

$$
\left(x-(-1)\right)^2+\left(y-\tfrac12\right)^2+\left(z-\left(-\tfrac23\right)\right)^2=\left(\tfrac49\right)^2.
$$

4. Simplify the signs, and square the radius: $\left(\tfrac49\right)^2=\tfrac{16}{81}$. Therefore

$$
(x+1)^2+\left(y-\tfrac12\right)^2+\left(z+\tfrac23\right)^2=\tfrac{16}{81}.
$$

5. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::example[Example 3.7 — Completing the square to identify a sphere]
Show that $x^2+y^2+z^2-4x+2y-6z+5=0$ is a sphere and find its center and radius.

::::answer[Answer]
**Answer:** Center $(2,-1,3)$, radius $3$.

1. Group by variable and complete the square in each:

$$
\underbrace{(x^2-4x)}_{\text{need }+4}+\underbrace{(y^2+2y)}_{\text{need }+1}+\underbrace{(z^2-6z)}_{\text{need }+9}+5=0.
$$

2. Add the completing amounts to both sides:

$$
(x^2-4x+4)+(y^2+2y+1)+(z^2-6z+9) = -5+4+1+9 = 9.
$$

$$
(x-2)^2+(y+1)^2+(z-3)^2 = 9 = 3^2.
$$

3. Sphere with center $(2,-1,3)$ and radius $3$.

4. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::example[Example 3.8 — Center and radius, with fractions]
Find the center $C$ and radius $a$ of each sphere: (a) $(x-1)^2+\left(y+\tfrac12\right)^2+(z+3)^2=25$, and (b) $3x^2+3y^2+3z^2+2y-2z=9$.

::::answer[Answer]
**Answer:** (a) $C=\left(1,-\tfrac12,-3\right)$, $a=5$. (b) $C=\left(0,-\tfrac13,\tfrac13\right)$, $a=\dfrac{\sqrt{29}}{3}$.

1. (a) The equation is already in standard form. Rewrite each factor as a subtraction so the center can be read off:

$$
(x-1)^2+\left(y-\left(-\tfrac12\right)\right)^2+\left(z-(-3)\right)^2=25.
$$

2. So $C=\left(1,-\tfrac12,-3\right)$, and $a=\sqrt{25}=5$.

3. (b) This one is not in standard form, so complete the square. First divide every term by $3$, so that the squared terms have coefficient $1$:

$$
x^2+y^2+z^2+\tfrac23y-\tfrac23z=3.
$$

4. Group the terms by variable. The $x$ part is already a perfect square:

$$
x^2+\left(y^2+\tfrac23y\right)+\left(z^2-\tfrac23z\right)=3.
$$

5. To complete the square in $y$, take half the coefficient of $y$ and square it: $\left(\tfrac{2/3}{2}\right)^2=\left(\tfrac13\right)^2=\tfrac19$. For $z$ the coefficient is $-\tfrac23$, and $\left(\tfrac{-2/3}{2}\right)^2=\left(-\tfrac13\right)^2=\tfrac19$. Add $\tfrac19$ inside each bracket, and add the same amounts to the right side so the equation stays balanced:

$$
x^2+\left(y^2+\tfrac23y+\tfrac19\right)+\left(z^2-\tfrac23z+\tfrac19\right)=3+\tfrac19+\tfrac19.
$$

6. Factor each bracket, and add on the right: $3+\tfrac29=\tfrac{27}{9}+\tfrac29=\tfrac{29}{9}$. So

$$
x^2+\left(y+\tfrac13\right)^2+\left(z-\tfrac13\right)^2=\tfrac{29}{9}.
$$

7. Reading off, $C=\left(0,-\tfrac13,\tfrac13\right)$ and $a=\sqrt{\tfrac{29}{9}}=\tfrac{\sqrt{29}}{3}$. Note that the center's $x$-coordinate is $0$ because $x$ appears as $x^2=(x-0)^2$.

8. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::


### Hand-checking a Sphere Without a Calculator

Once you have a candidate center and radius, you can check its equation two different ways. First use a point known to be one radius away. If the center is $(3,-2,1)$ and the radius is $5$, then $(8,-2,1)$ must lie on the sphere because its change from the center is $\langle5,0,0\rangle$ and its distance is $\sqrt{5^2}=5$. Substitute the point into $(x-3)^2+(y+2)^2+(z-1)^2=25$: you obtain $25+0+0=25$. This checks the *standard form*, though it cannot prove you copied the *original* equation correctly.

For that second check, expand the entire left side:
$$
\begin{aligned}
(x-3)^2+(y+2)^2+(z-1)^2&=25\\
x^2-6x+9+y^2+4y+4+z^2-2z+1&=25\\
x^2+y^2+z^2-6x+4y-2z+14&=25\\
x^2+y^2+z^2-6x+4y-2z&=11.
\end{aligned}
$$
This recovers the expanded Test 2 equation. The visible $+9,+4,+1$ are the precise amounts you added while completing the square, so this is a useful independent check of every center sign and the radius.

Also separate a **point** from a **vector**. A center is a point $(h,k,\ell)$; the vector $\langle h,k,\ell\rangle$ happens to have the same three numbers, but only the point description determines where the sphere sits in space. The sphere is a surface, not the entire solid interior. In contrast, an inequality such as $(x-h)^2+(y-k)^2+(z-\ell)^2\le r^2$ includes the interior and boundary. That distinction is tested in the challenge practice.


:::::example[Example 3.9 — Test 2 Version B Sphere, With Every Scoring Step]
Convert $x^2-8x+y^2-6y+z^2+10z=11$ into sphere form, and state its center and radius.

::::answer[Answer]
**Answer:** $(x-4)^2+(y-3)^2+(z+5)^2=61$; center $(4,3,-5)$; radius $\sqrt{61}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. First group the $x$, $y$ and $z$ terms separately. The coefficient of $x$ is $-8$, and half of it is $-4$, so add $(-4)^2=16$. The coefficient of $y$ is $-6$: half is $-3$, so add $9$. The coefficient of $z$ is $10$: half is $5$, so add $25$. The same amounts must be added to the other side:
$$
\begin{aligned}
(x^2-8x+16)+(y^2-6y+9)+(z^2+10z+25)&=11+16+9+25\\
(x-4)^2+(y-3)^2+(z+5)^2&=61.
\end{aligned}
$$
Match the result to $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$: $h=4$, $k=3$, $\ell=-5$, and $r^2=61$. A radius is a **length**, so $r=\sqrt{61}$, not $61$. This exact radical is the expected no-decimal final form.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::callout-pitfall[⚠ Common Errors]
- **Sign errors in the center.** The equation $(x-h)^2$ gives center coordinate $h$, NOT $-h$. If the equation reads $(x+3)^2$, the center has $x$-coordinate $-3$.
- **Forgetting to take the square root for $r$.** If the right side is 25, the radius is $r=5$, not $r=25$.
- **Adding the wrong completing numbers.** To complete $x^2-4x$, add $(4/2)^2=4$, not 4/2=2.
:::

:::::problem[Problem 3.1 — Compute a 3D distance]{difficulty=easy}
Find the distance from the origin to the point $(3, -4, 5)$.

::::solution[Solution]
**Answer:** $5\sqrt{2}$.

1. **Use the 3D distance formula.** Distance is the length of the straight segment between two points. The origin is $O=(0,0,0)$, and the other point is $P=(3,-4,5)$. The formula applies to any two points in three-dimensional space.

2. **Subtract corresponding coordinates.** The three changes from $O$ to $P$ are $3-0=3$, $-4-0=-4$, and $5-0=5$. Square each change and add:

$$
d=\sqrt{(3-0)^2+(-4-0)^2+(5-0)^2}
=\sqrt{9+16+25}=\sqrt{50}.
$$

3. **Simplify and check.** Since $50=25\cdot2$, $d=\sqrt{25}\sqrt2=5\sqrt2$. Squaring $5\sqrt2$ returns $50$, the sum of the three squared coordinate differences. Therefore the distance is $5\sqrt2$ units.
::::
:::::

:::::problem[Problem 3.2 — Sphere equation and geometry]{difficulty=easy}
Write the equation of the sphere with center $(-1,0,4)$ and radius $\sqrt{7}$.

::::solution[Solution]
**Answer:** $(x+1)^2+y^2+(z-4)^2=7$.

1. **Choose the sphere formula.** A sphere consists of all points exactly $r$ units from a fixed center $(h,k,\ell)$, so its equation is $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$. Here the center is $(-1,0,4)$ and $r=\sqrt7>0$.

2. **Substitute each coordinate without changing its sign.** The $x$ term is $x-(-1)=x+1$; the $y$ term is $y-0=y$; and the $z$ term is $z-4$. Also $(\sqrt7)^2=7$:

$$
(x-(-1))^2+(y-0)^2+(z-4)^2=(\sqrt7)^2.
$$

3. **Simplify and check.** This becomes $(x+1)^2+y^2+(z-4)^2=7$. For example, $(-1+\sqrt7,0,4)$ gives $7+0+0=7$, confirming the radius. Thus the displayed equation describes the required sphere.
::::
:::::

:::::problem[Problem 3.3 — Practice calculation]{difficulty=standard}
Find the center and radius of $x^2+y^2+z^2+6x-4z-3=0$.

::::solution[Solution]
**Answer:** Center $(-3,0,2)$; radius $4$.

1. **Complete the square** because the equation has squared coordinates and linear $x,z$ terms, rather than sphere standard form. Move the constant to the right:

$$
(x^2+6x)+y^2+(z^2-4z)=3.
$$

2. **Find the completing numbers.** Half of $6$ is $3$, so add $3^2=9$ to the $x$ group. Half of $-4$ is $-2$, so add $(-2)^2=4$ to the $z$ group. No extra term is needed for $y^2$:

$$
(x^2+6x+9)+y^2+(z^2-4z+4)=3+9+4=16.
$$

3. **Factor and identify.** The standard equation is $(x+3)^2+y^2+(z-2)^2=16$. Matching $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$ gives center $(-3,0,2)$ and $r=\sqrt{16}=4$. Expanding the squares recovers the original equation, so both values check.
::::
:::::

:::::problem[Problem 3.4 — Find a segment midpoint]{difficulty=standard}
Find the midpoint of the segment from $P(1,3,-2)$ to $Q(5,-1,4)$, and verify it is equidistant from both endpoints.

::::solution[Solution]
**Answer:** Midpoint $M=(3,1,1)$; $|PM|=|QM|=\sqrt{17}$.

1. **Use the coordinatewise midpoint formula.** A midpoint averages the corresponding coordinates of endpoints $P=(1,3,-2)$ and $Q=(5,-1,4)$:

$$
M=\left(\frac{1+5}{2},\frac{3+(-1)}{2},\frac{-2+4}{2}\right)
=\left(\frac62,\frac22,\frac22\right)=(3,1,1).
$$

2. **Calculate the first distance.** Apply the 3D distance formula to $P$ and $M$:

$$
|PM|=\sqrt{(3-1)^2+(1-3)^2+(1-(-2))^2}
=\sqrt{4+4+9}=\sqrt{17}.
$$

3. **Independently check the second distance.** From $Q$ to $M$, the coordinate differences are $3-5=-2$, $1-(-1)=2$, and $1-4=-3$:

$$
|QM|=\sqrt{(-2)^2+2^2+(-3)^2}=\sqrt{17}.
$$

The distances agree, so $(3,1,1)$ is equidistant from both endpoints, as required of the midpoint.
::::
:::::

:::::problem[Problem 3.5 — Practice calculation]{difficulty=challenge}
Describe the set of points satisfying $x^2+y^2+z^2-2x-4y+1\le 0$.

::::solution[Solution]
**Answer:** The closed ball centered at $(1,2,0)$ with radius $2$, including its boundary.

1. **Complete the square** to recognize the geometric inequality. Move the constant to the right and group the $x$ and $y$ terms:

$$
(x^2-2x)+(y^2-4y)+z^2\le-1.
$$

2. **Complete both squares while preserving the inequality.** Half of $-2$ is $-1$, whose square is $1$; half of $-4$ is $-2$, whose square is $4$. Add $1+4$ to both sides:

$$
(x^2-2x+1)+(y^2-4y+4)+z^2\le-1+1+4=4.
$$

3. **Interpret the result.** Factoring gives $(x-1)^2+(y-2)^2+(z-0)^2\le2^2$. Its left side is the squared distance from $(x,y,z)$ to $(1,2,0)$. Therefore the distance must be at most $2$. Equality is permitted, so the set contains the sphere's surface as well as all interior points: a closed ball.

4. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.6 — Compute a 3D distance]{difficulty=easy}
Find the distance from $P(-2,3,6)$ to the $y$-axis.

::::solution[Solution]
**Answer:** $2\sqrt{10}$.

1. **Find the nearest point on the axis.** A point on the $y$-axis has the form $(0,y,0)$. The shortest segment from $P=(-2,3,6)$ to that axis is perpendicular to the axis, so it keeps the same $y$-coordinate. The foot is $Q=(0,3,0)$.

2. **Apply the distance formula.** Subtract the matching coordinates:

$$
|PQ|=\sqrt{(-2-0)^2+(3-3)^2+(6-0)^2}
=\sqrt{(-2)^2+0^2+6^2}
=\sqrt{4+0+36}=\sqrt{40}.
$$

3. **Simplify and check.** Since $40=4\cdot10$, $\sqrt{40}=2\sqrt{10}$. The $y$-difference is zero, as it should be for a perpendicular distance to the $y$-axis. Thus the shortest distance is $2\sqrt{10}$ units.
::::
:::::

:::::problem[Problem 3.7 — Sphere equation and geometry]{difficulty=standard}
**Test 2 style.** Put $x^2-6x+y^2+4y+z^2-2z=11$ into standard sphere form. Give the center and radius.

::::solution[Solution]
**Answer:** $(x-3)^2+(y+2)^2+(z-1)^2=25$; center $(3,-2,1)$; radius $5$.

1. **Complete the square**, because the equation contains three squared coordinates and linear terms. Group matching variables:

$$
(x^2-6x)+(y^2+4y)+(z^2-2z)=11.
$$

2. **Find and add the square-completion terms.** Half of $-6$ is $-3$, so add $9$; half of $4$ is $2$, so add $4$; half of $-2$ is $-1$, so add $1$. Add them to both sides:

$$
(x^2-6x+9)+(y^2+4y+4)+(z^2-2z+1)
=11+9+4+1=25.
$$

3. **Factor and identify the geometry.** The equation becomes $(x-3)^2+(y+2)^2+(z-1)^2=25$. Hence $(h,k,\ell)=(3,-2,1)$ and $r=\sqrt{25}=5>0$.

4. **Check.** Expanding the left side yields $x^2+y^2+z^2-6x+4y-2z+14=25$; subtracting $14$ recovers the given equation with right side $11$. The center, radius, and equation are therefore consistent.
::::
:::::

:::callout-key[Test 2 scoring path: completing a sphere]
The released versions A and B both start from $x^2+y^2+z^2$ plus linear terms. Show all three of these written steps: (1) move the constant to the right; (2) add each of the three half-coefficient squares to **both** sides; (3) write the three squared binomials and separately state **center** and **positive radius**. Do not read the signs of the center directly from expanded coefficients. For example, $x^2-8x$ needs $+16$, not $-16$, and $(x-4)^2$ means center coordinate $4$.
:::

A strong check is to expand the standard form again. If you claim $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$, expand the left side and subtract $r^2$; it must recover the original equation up to moving a constant. This reverse check catches sign errors without a calculator. A second check is $r^2>0$: a negative radius-squared would not define a real sphere, and $r^2=0$ is only one point, not an ordinary sphere. None of the released Test 2 sphere problems requires decimal answers.


:::callout-tip[No-calculator checkpoint for the sphere question]
A standard-form sphere gives three immediate intercept-style checks. Starting at the center $(h,k,\ell)$, move $r$ in either $x$, $y$ or $z$: the six points $(h\pm r,k,\ell)$, $(h,k\pm r,\ell)$, $(h,k,\ell\pm r)$ all lie on the sphere. For center $(3,-2,1)$ and radius $5$, this includes $(-2,-2,1)$, $(8,-2,1)$, $(3,-7,1)$, $(3,3,1)$, $(3,-2,-4)$ and $(3,-2,6)$. Each produces precisely one squared difference of $25$ and two zero squared differences. This makes it easy to sketch which way the sphere is shifted.

The phrase “center and radius” asks for two different sorts of output: a coordinate triple and a **nonnegative** length. In version A, $(x-3)^2+(y+2)^2+(z-1)^2=25$ gives $(3,-2,1)$ and $5$, not $(-3,2,-1)$ and $25$. Version B illustrates the same principle with $r=\sqrt{61}$. A radius stays under a radical unless it simplifies to an integer; no approximation is needed.
:::

\n\nBefore committing a sphere equation to a final box, perform the fastest possible reverse check. Read the proposed center from the signs inside its parentheses, substitute that center, and make sure the left-hand side is zero. Next add the proposed radius to just one coordinate of the center. Substitution should give precisely $r^2$. For example, $(x-1)^2+(y+2)^2+(z-3)^2=16$ has center $(1,-2,3)$; $(5,-2,3)$ produces $4^2+0+0=16$. These checks catch both forgotten squares and incorrect center signs without requiring a calculator.\n
## 12.2 Vectors

:::callout-connect
📺 Watch before this section

“Vectors, what even are they? | Essence of Linear Algebra #1” — 3Blue1Brown

“Vector intro for linear algebra” — Khan Academy
:::

:::callout-intuition[Intuition — what a vector is]
A **vector** is a quantity that has both *magnitude* (size) and *direction*. A scalar has only magnitude. Speed is a scalar; velocity is a vector (speed plus direction). Force is a vector (you care not just how hard you push but which way). Displacement is a vector (walking 5 miles northeast is different from walking 5 miles southwest).

Geometrically, you draw a vector as an arrow. The length of the arrow is the magnitude; the arrowhead shows the direction. Two arrows represent the *same* vector if they have the same length and point the same direction — it doesn't matter where in space the arrow starts. This "free vector" idea is important: $\langle 3, 2, 1\rangle$ is the same vector whether its tail is at the origin or at $(5, -7, 2)$.

Algebraically, a vector in $\mathbb{R}^3$ is an ordered triple $\langle a, b, c\rangle$. The numbers $a$, $b$, $c$ are the **components**: how far you travel in the $x$-, $y$-, and $z$-directions, respectively. If the vector goes from point $P=(x_1,y_1,z_1)$ to point $Q=(x_2,y_2,z_2)$, then $\vec{PQ} = \langle x_2-x_1, y_2-y_1, z_2-z_1\rangle$ — always terminal minus initial.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 320 249" width="320" height="249" role="img" aria-label="The vector from P(1,1,0) to Q(3,4,2) with its three components drawn as dashed legs">
<path class="fig-fill" d="M124.49 167.6L87.3 196.05L192.23 218.75Z"/>
<path class="fig-axis" d="M108.11 145.81L30 205.56"/>
<path class="fig-axis" d="M108.11 145.81L290 185.15"/>
<path class="fig-axis" d="M108.11 145.81L108.11 30"/>
<path class="fig-guide" d="M124.49 167.6L87.3 196.05"/>
<path class="fig-guide" d="M87.3 196.05L192.23 218.75"/>
<path class="fig-guide" d="M192.23 218.75L192.23 146.37"/>
<path class="fig-axis" d="M30.01 205.55L30 205.56L30.01 205.56"/>
<path class="fig-axis" d="M289.98 185.15L290 185.15L289.98 185.13"/>
<path class="fig-axis" d="M108.12 30.02L108.11 30L108.1 30.02"/>
<path class="fig-curve" d="M124.49 167.6L186.55 148.15"/>
<path class="fig-arrow" d="M192.23 146.37L185.2 152.35L183.04 145.48Z"/>
<circle class="fig-point" cx="124.49" cy="167.6" r="3.2"/>
<circle class="fig-point" cx="192.23" cy="146.37" r="3.2"/>
<text class="fig-label-em" x="19.06" y="214.64">x</text>
<text class="fig-label-em" x="296.77" y="190.26">y</text>
<text class="fig-label-em" x="105.11" y="23">z</text>
<text class="fig-label-em" x="94.49" y="183.6">P(1, 1, 0)</text>
<text class="fig-label-em" x="196.23" y="138.37">Q(3, 4, 2)</text>
<text class="fig-label" x="102.89" y="194.83">2</text>
<text class="fig-label" x="137.76" y="220.4">3</text>
<text class="fig-label" x="198.23" y="186.56">2</text>
<text class="fig-label-em" x="146.36" y="154.98">v</text>
</svg>
<figcaption>The vector $\overrightarrow{PQ}=\langle 3-1,\,4-1,\,2-0\rangle=\langle 2,3,2\rangle$: subtract the coordinates of the tail from those of the head; the dashed legs run $2$ in $x$, $3$ in $y$ and $2$ in $z$.</figcaption>
</figure>

Read the figure as a recipe. The tail is $P=(1,1,0)$ and the head is $Q=(3,4,2)$. The three dashed legs are the trips in the $x$-, $y$- and $z$-directions, and each leg's length is a head coordinate minus the matching tail coordinate: $3-1=2$, $4-1=3$, $2-0=2$. That is all the formula "terminal minus initial" is saying.

:::definition[Definition 12.2.1 — Vector, Components, Magnitude]
A **vector** $\vec{v} = \langle a, b, c\rangle$ in $\mathbb{R}^3$ has components $a, b, c$. Its **magnitude** (or length) is:

$$
|\vec{v}| = \sqrt{a^2+b^2+c^2}.
$$

 The **zero vector** $\vec{0} = \langle 0,0,0\rangle$ has magnitude 0 and no defined direction.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 320 220" width="320" height="220" role="img" aria-label="A vector parallelogram with u, v and their diagonal sum">
<path class="fig-curve" d="M55.0 195.0L211.0 149.0"/>
<path class="fig-curve-alt" d="M55.0 195.0L107.0 103.0"/>
<path class="fig-axis" d="M55.0 195.0L263.0 57.0"/>
<path class="fig-guide" d="M211.0 149.0L263.0 57.0"/>
<path class="fig-guide" d="M107.0 103.0L263.0 57.0"/>
<circle class="fig-point" cx="55.0" cy="195.0" r="3"/><text class="fig-label" x="62.0" y="187.0">O</text>
<circle class="fig-point" cx="211.0" cy="149.0" r="3"/><text class="fig-label" x="218.0" y="141.0">u</text>
<circle class="fig-point" cx="107.0" cy="103.0" r="3"/><text class="fig-label" x="114.0" y="95.0">v</text>
<circle class="fig-point" cx="263.0" cy="57.0" r="3"/><text class="fig-label" x="270.0" y="49.0">u+v</text>
</svg>
<figcaption>Adding $\vec u=\langle3,1\rangle$ and $\vec v=\langle1,2\rangle$ tip-to-tail reaches $\vec u+\vec v=\langle4,3\rangle$; the dashed parallelogram confirms the same endpoint.</figcaption>
</figure>

### Vector Arithmetic

All vector operations are done component-by-component. Let $\vec{u} = \langle u_1,u_2,u_3\rangle$ and $\vec{v} = \langle v_1,v_2,v_3\rangle$, and let $c$ be a scalar.

| Operation | Formula | Geometric meaning |
| --- | --- | --- |
| **Addition** | $\vec{u}+\vec{v} = \langle u_1+v_1,\,u_2+v_2,\,u_3+v_3\rangle$ | Place tail of $\vec{v}$ at head of $\vec{u}$; result goes from tail of $\vec{u}$ to head of $\vec{v}$ (triangle law) |
| **Subtraction** | $\vec{u}-\vec{v} = \langle u_1-v_1,\,u_2-v_2,\,u_3-v_3\rangle$ | The vector from the tip of $\vec{v}$ to the tip of $\vec{u}$ (when both start at origin) |
| **Scalar mult.** | $c\vec{v} = \langle cv_1,cv_2,cv_3\rangle$ | Scales the length by $|c|$; reverses direction if $c<0$ |

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 320 268" width="320" height="268" role="img" aria-label="Vectors u and v drawn from a common point with the parallelogram they span; the diagonal is u plus v">
<path class="fig-fill" d="M30 238L225 173L290 30L95 95Z"/>
<path class="fig-guide" d="M225 173L290 30"/>
<path class="fig-guide" d="M95 95L290 30"/>
<path class="fig-curve-alt" d="M30 238L225 173"/>
<path class="fig-curve-alt" d="M218.07 179.07L225 173L215.81 172.3"/>
<path class="fig-curve-alt" d="M30 238L95 95"/>
<path class="fig-curve-alt" d="M94.73 104.22L95 95L88.23 101.26"/>
<path class="fig-curve" d="M30 238L285.35 33.72"/>
<path class="fig-arrow" d="M290 30L285.61 38.12L281.11 32.5Z"/>
<circle class="fig-point" cx="30" cy="238" r="3.2"/>
<text class="fig-label-em" x="129.5" y="219.5">u</text>
<text class="fig-label-em" x="50.5" y="168.5">v</text>
<text class="fig-label" x="263.5" y="105.5">v</text>
<text class="fig-label" x="189.5" y="56.5">u</text>
<text class="fig-label-em" x="296" y="26">u + v</text>
</svg>
<figcaption>Parallelogram law: place $\mathbf{u}$ and $\mathbf{v}$ tail to tail; the sum $\mathbf{u}+\mathbf{v}$ is the diagonal from the common tail, and sliding either vector to the tip of the other (dashed) gives the same endpoint.</figcaption>
</figure>

There are two pictures of the same sum, and they agree. In the triangle law you slide $\vec{v}$ so its tail sits on the head of $\vec{u}$. In the parallelogram law you leave both vectors on the same starting point and complete the parallelogram; the diagonal from that common starting point is $\vec{u}+\vec{v}$. Both give the same endpoint, which in components is $\langle u_1+v_1,\,u_2+v_2,\,u_3+v_3\rangle$.

### Unit Vectors and the Standard Basis

A **unit vector** has magnitude exactly 1. Given any nonzero vector $\vec{v}$, you can produce a unit vector in the same direction by dividing by its magnitude:

$$
\hat{v} = \frac{\vec{v}}{|\vec{v}|}.
$$

 This process is called **normalizing** $\vec{v}$. The three **standard basis vectors** are unit vectors along the coordinate axes:

$$
\hat{\imath} = \langle 1,0,0\rangle,\qquad \hat{\jmath} = \langle 0,1,0\rangle,\qquad \hat{k} = \langle 0,0,1\rangle.
$$

 Every vector can be written in terms of these: $\langle a,b,c\rangle = a\hat{\imath}+b\hat{\jmath}+c\hat{k}$. Both notations are used interchangeably.

:::::example[Example 3.10 — Component form from two points]
Find the vector from $P = (1, 4, -2)$ to $Q = (5, 1, 3)$. Then find its magnitude.

::::answer[Answer]
**Answer:** $\vec{PQ} = \langle 4,-3,5\rangle$, $|\vec{PQ}| = 5\sqrt{2}$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Components: terminal minus initial.

$$
\vec{PQ} = \langle 5-1,\;1-4,\;3-(-2)\rangle = \langle 4,-3,5\rangle.
$$

3. Magnitude:

$$
|\vec{PQ}| = \sqrt{4^2+(-3)^2+5^2} = \sqrt{16+9+25} = \sqrt{50} = 5\sqrt{2}.
$$

4. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.11 — Component form between points, and a sum of two such vectors]
(a) Find the component form of $\vec{PQ}$ where $P=(1,3)$ and $Q=(2,-1)$. (b) Find the sum of $\vec{AB}$ and $\vec{CD}$, where $A=(1,-1)$, $B=(2,0)$, $C=(-1,3)$ and $D=(-2,2)$.

::::answer[Answer]
**Answer:** (a) $\vec{PQ}=\langle 1,-4\rangle$. (b) $\vec{AB}+\vec{CD}=\langle 0,0\rangle=\vec{0}$.

1. This example lives in the plane, so each vector has two components instead of three. The rule is the same: terminal point minus initial point, one coordinate at a time.

2. (a) The initial point is $P$ and the terminal point is $Q$, so we subtract the $x$-coordinates and then the $y$-coordinates, always head minus tail:

$$
\vec{PQ}=\langle 2-1,\;-1-3\rangle=\langle 1,-4\rangle.
$$

3. (b) There are three things to do: find $\vec{AB}$, find $\vec{CD}$, and add them. First $\vec{AB}$, head $B$ minus tail $A$:

$$
\vec{AB}=\langle 2-1,\;0-(-1)\rangle=\langle 1,1\rangle.
$$

4. Then $\vec{CD}$, head $D$ minus tail $C$. Take care with the signs: $-2-(-1)=-2+1=-1$.

$$
\vec{CD}=\langle -2-(-1),\;2-3\rangle=\langle -1,-1\rangle.
$$

5. Now add component by component:

$$
\vec{AB}+\vec{CD}=\langle 1,1\rangle+\langle -1,-1\rangle=\langle 1+(-1),\;1+(-1)\rangle=\langle 0,0\rangle=\vec{0}.
$$

6. The two arrows are equal in length and point in exactly opposite directions, so they cancel to the zero vector.

7. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.12 — Vector arithmetic]
Given $\vec{u} = \langle 2,-1,4\rangle$ and $\vec{v} = \langle -1,3,0\rangle$, find $3\vec{u} - 2\vec{v}$ and its magnitude.

::::answer[Answer]
**Answer:** $\langle 8,-9,12\rangle$, magnitude $\sqrt{289} = 17$.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. Scale first, then subtract component by component:

$$
3\vec{u} = \langle 6,-3,12\rangle, \qquad 2\vec{v} = \langle -2,6,0\rangle.
$$

$$
3\vec{u}-2\vec{v} = \langle 6-(-2),\;-3-6,\;12-0\rangle = \langle 8,-9,12\rangle.
$$

3. Magnitude: $\sqrt{64+81+144} = \sqrt{289} = 17$.

4. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::example[Example 3.13 — Component form and magnitude of a combination]
Let $\vec{u}=\langle -2,4,8\rangle$ and $\vec{v}=\langle 1,4,-7\rangle$. For each combination below, find (a) the component form and (b) the magnitude: **1.** $2\vec{u}-3\vec{v}$ and **2.** $\tfrac35\vec{u}+\tfrac45\vec{v}$.

::::answer[Answer]
**Answer:** **1.** $2\vec{u}-3\vec{v}=\langle -7,-4,37\rangle$, magnitude $\sqrt{1434}$. **2.** $\tfrac35\vec{u}+\tfrac45\vec{v}=\left\langle -\tfrac25,\tfrac{28}{5},-\tfrac45\right\rangle$, magnitude $\tfrac{2\sqrt{201}}{5}$.

1. Part 1. Scale each vector first, then subtract. Multiplying by $2$ doubles every component of $\vec{u}$, and multiplying by $3$ triples every component of $\vec{v}$:

$$
\begin{aligned}
2\vec{u}-3\vec{v} &= 2\langle -2,4,8\rangle-3\langle 1,4,-7\rangle\\
&=\langle -4,8,16\rangle-\langle 3,12,-21\rangle\\
&=\langle -4-3,\;8-12,\;16-(-21)\rangle\\
&=\langle -7,-4,37\rangle.
\end{aligned}
$$

2. The last component is $16-(-21)=16+21=37$. For the magnitude, square each component, add, and take the root:

$$
\begin{aligned}
|2\vec{u}-3\vec{v}| &= \sqrt{(-7)^2+(-4)^2+37^2}\\
&=\sqrt{49+16+1369}\\
&=\sqrt{1434}.
\end{aligned}
$$

3. Since $1434=2\cdot 3\cdot 239$ has no repeated prime factor, $\sqrt{1434}$ cannot be simplified, and we leave it there.

4. Part 2. The same plan, now with fractions. Multiply each component by the fraction:

$$
\begin{aligned}
\tfrac35\vec{u}+\tfrac45\vec{v} &=\tfrac35\langle -2,4,8\rangle+\tfrac45\langle 1,4,-7\rangle\\
&=\left\langle -\tfrac65,\tfrac{12}{5},\tfrac{24}{5}\right\rangle+\left\langle \tfrac45,\tfrac{16}{5},-\tfrac{28}{5}\right\rangle\\
&=\left\langle -\tfrac65+\tfrac45,\;\tfrac{12}{5}+\tfrac{16}{5},\;\tfrac{24}{5}-\tfrac{28}{5}\right\rangle\\
&=\left\langle -\tfrac25,\tfrac{28}{5},-\tfrac45\right\rangle.
\end{aligned}
$$

5. The denominators are all $5$, so we only combine the numerators. For the magnitude:

$$
\begin{aligned}
\left|\tfrac35\vec{u}+\tfrac45\vec{v}\right| &=\sqrt{\left(-\tfrac25\right)^2+\left(\tfrac{28}{5}\right)^2+\left(-\tfrac45\right)^2}\\
&=\sqrt{\tfrac{4}{25}+\tfrac{784}{25}+\tfrac{16}{25}}\\
&=\sqrt{\tfrac{804}{25}}\\
&=\tfrac{\sqrt{804}}{5}\\
&=\tfrac{2\sqrt{201}}{5}.
\end{aligned}
$$

6. The last step uses $804=4\cdot 201$, so $\sqrt{804}=2\sqrt{201}$.

7. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.14 — Finding a unit vector]
Find the unit vector in the direction of $\vec{v} = \langle 3, -4, 0\rangle$.

::::answer[Answer]
**Answer:** $\langle 3/5, -4/5, 0\rangle$

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. First compute the magnitude: $|\vec{v}| = \sqrt{9+16+0} = \sqrt{25} = 5$.
 Then divide: $\hat{v} = \dfrac{\vec{v}}{|\vec{v}|} = \dfrac{1}{5}\langle 3,-4,0\rangle = \left\langle\dfrac{3}{5},-\dfrac{4}{5},0\right\rangle$.
 Check: $\sqrt{9/25+16/25+0} = \sqrt{25/25} = 1$. ✓
::::
:::::

:::callout-key[Key concept — length times direction]
Every nonzero vector is its length times its direction: $\vec{v}=|\vec{v}|\cdot\dfrac{\vec{v}}{|\vec{v}|}$. The first factor is a plain number that says how long; the second is a unit vector that says which way. Splitting a vector into these two factors is exactly what the next example does.
:::

:::::example[Example 3.15 — Length times direction]
Express each vector as the product of its length and its direction: (a) $9\hat{\imath}-2\hat{\jmath}+6\hat{k}$ and (b) $\dfrac{1}{\sqrt6}\hat{\imath}-\dfrac{1}{\sqrt6}\hat{\jmath}-\dfrac{1}{\sqrt6}\hat{k}$.

::::answer[Answer]
**Answer:** (a) $11\left(\dfrac{9\hat{\imath}-2\hat{\jmath}+6\hat{k}}{11}\right)$. (b) $\dfrac{1}{\sqrt2}\left[\sqrt2\left(\dfrac{1}{\sqrt6}\hat{\imath}-\dfrac{1}{\sqrt6}\hat{\jmath}-\dfrac{1}{\sqrt6}\hat{k}\right)\right]$.

1. Each part has three steps: find the length, divide the vector by the length to get the direction, then write length times direction.

2. (a) Length:

$$
|\vec{v}|=\sqrt{9^2+(-2)^2+6^2}=\sqrt{81+4+36}=\sqrt{121}=11.
$$

3. Direction, the vector divided by its length:

$$
\frac{\vec{v}}{|\vec{v}|}=\frac{9\hat{\imath}-2\hat{\jmath}+6\hat{k}}{11}.
$$

4. Product form:

$$
11\left(\frac{9\hat{\imath}-2\hat{\jmath}+6\hat{k}}{11}\right).
$$

5. (b) Length. Each component squared is $\tfrac16$, and there are three of them:

$$
|\vec{v}|=\sqrt{\left(\tfrac{1}{\sqrt6}\right)^2+\left(-\tfrac{1}{\sqrt6}\right)^2+\left(-\tfrac{1}{\sqrt6}\right)^2}=\sqrt{\tfrac16+\tfrac16+\tfrac16}=\sqrt{\tfrac36}=\sqrt{\tfrac12}=\tfrac{1}{\sqrt2}.
$$

6. Direction. Dividing by $\tfrac{1}{\sqrt2}$ is the same as multiplying by $\sqrt2$:

$$
\frac{\vec{v}}{|\vec{v}|}=\frac{\frac{1}{\sqrt6}\hat{\imath}-\frac{1}{\sqrt6}\hat{\jmath}-\frac{1}{\sqrt6}\hat{k}}{1/\sqrt2}=\sqrt2\left(\tfrac{1}{\sqrt6}\hat{\imath}-\tfrac{1}{\sqrt6}\hat{\jmath}-\tfrac{1}{\sqrt6}\hat{k}\right).
$$

7. Product form:

$$
\frac{1}{\sqrt2}\left[\sqrt2\left(\tfrac{1}{\sqrt6}\hat{\imath}-\tfrac{1}{\sqrt6}\hat{\jmath}-\tfrac{1}{\sqrt6}\hat{k}\right)\right].
$$

8. Multiplying the two factors back together returns the original vector, since $\tfrac{1}{\sqrt2}\cdot\sqrt2=1$. That is the check.
::::
:::::

### Midpoint of a Segment

Sometimes the question is not about a vector but about the point exactly halfway between two points. Averaging each coordinate does it: halfway in $x$ is the average of the two $x$-values, and likewise for $y$ and $z$.

:::definition[Definition 12.2.2 — Midpoint]
The **midpoint** $M$ of the line segment joining $P_1(x_1,y_1,z_1)$ and $P_2(x_2,y_2,z_2)$ is the point

$$
M=\left(\frac{x_1+x_2}{2},\;\frac{y_1+y_2}{2},\;\frac{z_1+z_2}{2}\right).
$$
:::

:::::example[Example 3.16 — Direction and midpoint]
Find (a) the direction of $\vec{P_1P_2}$ and (b) the midpoint of the line segment $P_1P_2$, if $P_1(-1,1,5)$ and $P_2(2,5,0)$.

::::answer[Answer]
**Answer:** (a) $\dfrac{\langle 3,4,-5\rangle}{5\sqrt2}$. (b) $M=\left(\tfrac12,3,\tfrac52\right)$.

1. Both parts start from the same vector, so find it first, terminal minus initial:

$$
\vec{P_1P_2}=\langle 2-(-1),\;5-1,\;0-5\rangle=\langle 3,4,-5\rangle.
$$

2. (a) The direction is this vector divided by its length. Compute the length inside the fraction:

$$
\frac{\vec{P_1P_2}}{|\vec{P_1P_2}|}=\frac{\langle 3,4,-5\rangle}{\sqrt{3^2+4^2+(-5)^2}}=\frac{\langle 3,4,-5\rangle}{\sqrt{9+16+25}}=\frac{\langle 3,4,-5\rangle}{\sqrt{50}}=\frac{\langle 3,4,-5\rangle}{5\sqrt2}.
$$

3. The last step uses $\sqrt{50}=\sqrt{25\cdot 2}=5\sqrt2$. If you prefer no root in the denominator, multiply top and bottom by $\sqrt2$ to write the same unit vector as $\left\langle \tfrac{3\sqrt2}{10},\tfrac{2\sqrt2}{5},-\tfrac{\sqrt2}{2}\right\rangle$.

4. (b) Average each coordinate of the two endpoints:

$$
M=\left(\frac{x_1+x_2}{2},\frac{y_1+y_2}{2},\frac{z_1+z_2}{2}\right)=\left(\frac{-1+2}{2},\frac{1+5}{2},\frac{5+0}{2}\right)=\left(\tfrac12,3,\tfrac52\right).
$$

5. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::example[Example 3.17 — Finding a starting point]
If $\vec{AB}=\hat{\imath}+4\hat{\jmath}-2\hat{k}$ and $B$ is the point $(5,1,3)$, find $A$.

::::answer[Answer]
**Answer:** $A=(4,-3,5)$.

1. We know the vector and the head, and we want the tail. Write $A=(x,y,z)$. The rule "terminal minus initial" gives

$$
\vec{AB}=\langle 5-x,\;1-y,\;3-z\rangle.
$$

2. The given vector is $\hat{\imath}+4\hat{\jmath}-2\hat{k}=\langle 1,4,-2\rangle$. Two vectors are equal exactly when their components are equal, so we match the components and solve each equation on its own:

$$
5-x=1\;\Rightarrow\;x=4,\qquad 1-y=4\;\Rightarrow\;y=-3,\qquad 3-z=-2\;\Rightarrow\;z=5.
$$

3. So $A=(4,-3,5)$. Check by walking the vector from $A$: $(4+1,\;-3+4,\;5+(-2))=(5,1,3)=B$. ✓
::::
:::::

:::::example[Example 3.18 — Force equilibrium]
A particle is acted on by forces $\vec{F}_1 = \langle 3, 0, -2\rangle$ N and $\vec{F}_2 = \langle -1, 4, 1\rangle$ N. Find the third force $\vec{F}_3$ needed for equilibrium (net force = $\vec{0}$).

::::answer[Answer]
**Answer:** $\vec{F}_3 = \langle -2,-4,1\rangle$ N.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. For equilibrium: $\vec{F}_1+\vec{F}_2+\vec{F}_3 = \vec{0}$. Solve for $\vec{F}_3$:

$$
\vec{F}_3 = -(\vec{F}_1+\vec{F}_2) = -\langle 3+(-1),0+4,-2+1\rangle = -\langle 2,4,-1\rangle = \langle -2,-4,1\rangle.
$$

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::


### Hand-checking a Direction Vector

Before accepting a unit vector, perform two independent checks. A direction vector must point the correct way, so dividing by a **positive** length preserves the signs of the components. It must also have length $1$. For $\vec v=\langle-2,3,6\rangle$, calculate
$$
|\vec v|=\sqrt{(-2)^2+3^2+6^2}=\sqrt{4+9+36}=\sqrt{49}=7,
$$
so the unit direction is $\hat v=\langle-2/7,3/7,6/7\rangle$. Recompute its length:
$$
|\hat v|=\sqrt{\frac4{49}+\frac9{49}+\frac{36}{49}}=\sqrt{\frac{49}{49}}=1.
$$
If the problem requests the **opposite** direction, make the vector $-\hat v=\langle2/7,-3/7,-6/7\rangle$, whose length remains $1$. Multiplying by any positive prescribed length $L$ then gives $L\hat v$ or $-L\hat v$ as required.

The $\hat\imath,\hat\jmath,\hat k$ basis notation is simply a different way to write a component list. For example, $-2\hat\imath+3\hat\jmath+6\hat k=\langle-2,3,6\rangle$; it is not multiplication of three unrelated letters. If the coefficient of one basis vector is missing, that component is zero: $4\hat\imath-\hat k=\langle4,0,-1\rangle$. When you combine vectors, combine like basis vectors exactly as you combine the entries in a component list. This is particularly useful when the professor gives the dot-product inputs in $\hat\imath,\hat\jmath,\hat k$ form on Test 2.

:::callout-pitfall[⚠ Common Errors]
- **Initial minus terminal instead of terminal minus initial.** $\vec{PQ} = Q - P$, always. Getting this backwards flips the direction of your vector.
- **Dividing by magnitude squared when normalizing.** You divide by $|\vec{v}|$ (the magnitude), not by $|\vec{v}|^2$.
- **Treating $\langle a,b,c\rangle$ as a point rather than a displacement.** Vectors are displacements, not locations. $\langle 1,2,3\rangle$ as a vector means "move 1 unit in $x$, 2 in $y$, 3 in $z$," not "the point $(1,2,3)$."
:::

:::::problem[Problem 3.8 — Practice calculation]{difficulty=easy}
Find $\vec{AB}$ and $|\vec{AB}|$ for $A=(0,2,-1)$ and $B=(4,-1,2)$.

::::solution[Solution]
**Answer:** $\vec{AB}=\langle4,-3,3\rangle$; $|\vec{AB}|=\sqrt{34}$.

1. **Use terminal minus initial coordinates.** A vector from $A$ to $B$ points toward $B$, so its components are $B-A$, not $A-B$. Here $A=(0,2,-1)$ and $B=(4,-1,2)$:

$$
\vec{AB}=\langle4-0,-1-2,2-(-1)\rangle
=\langle4,-3,3\rangle.
$$

2. **Apply the 3D magnitude formula.** Square all three vector components and add. A negative component still contributes a positive square:

$$
|\vec{AB}|=\sqrt{4^2+(-3)^2+3^2}
=\sqrt{16+9+9}=\sqrt{34}.
$$

3. **Check direction and length.** Adding $\langle4,-3,3\rangle$ to $A$ gives $(4,-1,2)=B$. Also $(\sqrt{34})^2=16+9+9$. Therefore the displacement and its length are correct.
::::
:::::

:::::problem[Problem 3.9 — Compute a unit vector]{difficulty=easy}
Find the unit vector in the direction of $\vec{w}=\langle 1,2,-2\rangle$.

::::solution[Solution]
**Answer:** $\left\langle\frac13,\frac23,-\frac23\right\rangle$.

1. **Normalize the vector.** For any nonzero vector $\vec{w}$, the unit vector in the same direction is $\vec{w}/|\vec{w}|$. Here $\vec{w}=\langle1,2,-2\rangle$ is nonzero, so normalization is valid.

2. **Find the magnitude before dividing.** Use the three-dimensional length formula:

$$
|\vec{w}|=\sqrt{1^2+2^2+(-2)^2}
=\sqrt{1+4+4}=\sqrt9=3.
$$

3. **Divide each component by the magnitude.** This preserves direction because the divisor $3$ is positive:

$$
\frac{\vec{w}}{|\vec{w}|}=\frac13\langle1,2,-2\rangle
=\left\langle\frac13,\frac23,-\frac23\right\rangle.
$$

4. **Check unit length.** Its magnitude squared is $\frac19+\frac49+\frac49=1$. Therefore its magnitude is $1$, making it the requested unit vector.
::::
:::::

:::::problem[Problem 3.10 — Vector arithmetic]{difficulty=standard}
Find a vector of length 5 pointing in the direction opposite to $\vec{v}=\langle 3,0,-4\rangle$.

::::solution[Solution]
**Answer:** $\langle-3,0,4\rangle$.

1. **Use direction and magnitude separately.** To reverse the direction of a nonzero vector $\vec v$, multiply its unit vector by $-1$; to give the result length $5$, multiply by $5$ instead of $1$. Here $\vec v=\langle3,0,-4\rangle$.

2. **Find its magnitude.** By the vector length formula,

$$
|\vec v|=\sqrt{3^2+0^2+(-4)^2}
=\sqrt{9+0+16}=\sqrt{25}=5.
$$

3. **Reverse and scale.** The required vector is

$$
\vec w=-5\frac{\vec v}{|\vec v|}
=-\frac55\langle3,0,-4\rangle
=\langle-3,0,4\rangle.
$$

4. **Check both conditions.** $|\vec w|=\sqrt{(-3)^2+0^2+4^2}=5$, and $\vec w=-\vec v$, so it points exactly opposite to $\vec v$. This is the requested vector.
::::
:::::

:::::problem[Problem 3.11 — Vector arithmetic]{difficulty=standard}
Given $\vec{u}=\langle 1,-2,3\rangle$ and $\vec{v}=\langle 4,1,-1\rangle$, find the vector $\vec{w}$ such that $2\vec{u}-\vec{w}=3\vec{v}$.

::::solution[Solution]
**Answer:** $\vec w=\langle-10,-7,9\rangle$.

1. **Isolate the unknown vector.** Treat the vector equation $2\vec u-\vec w=3\vec v$ like an ordinary linear equation. Add $\vec w$ to both sides, then subtract $3\vec v$:

$$
2\vec u=3\vec v+\vec w
\quad\Longrightarrow\quad\vec w=2\vec u-3\vec v.
$$

2. **Multiply componentwise.** With $\vec u=\langle1,-2,3\rangle$ and $\vec v=\langle4,1,-1\rangle$,

$$
2\vec u=\langle2,-4,6\rangle,
\qquad3\vec v=\langle12,3,-3\rangle.
$$

3. **Subtract componentwise.** Thus

$$
\vec w=\langle2-12,-4-3,6-(-3)\rangle
=\langle-10,-7,9\rangle.
$$

4. **Check in the original equation.** $2\vec u-\vec w=\langle2+10,-4+7,6-9\rangle=\langle12,3,-3\rangle=3\vec v$. The vector therefore satisfies the equation exactly.
::::
:::::

:::::problem[Problem 3.12 — Angle from a dot product]{difficulty=challenge}
A 100 N weight hangs from two cables. Cable 1 makes a 30° angle with the ceiling and Cable 2 makes a 45° angle. Find the tension in each cable. (Set up the equilibrium equations using component vectors.)

::::solution[Solution]
**Answer:** Cable 1: $T_1=100(\sqrt3-1)\text{ N}\approx73.2\text{ N}$; cable 2: $T_2=50\sqrt2(3-\sqrt3)\text{ N}\approx89.7\text{ N}$.

1. **Resolve forces into components.** Assume cable 1 runs up-left at $30^\circ$ to the horizontal ceiling and cable 2 runs up-right at $45^\circ$. Because the weight hangs at rest, horizontal and vertical forces each sum to zero:

$$
-T_1\cos30^\circ+T_2\cos45^\circ=0,
\qquad T_1\sin30^\circ+T_2\sin45^\circ=100.
$$

2. **Substitute exact trig values.** Using $\cos30^\circ=\sqrt3/2$, $\cos45^\circ=\sin45^\circ=\sqrt2/2$, and $\sin30^\circ=1/2$, the horizontal equation gives $T_2=T_1\sqrt3/\sqrt2$. Insert that into the vertical equation:

$$
\frac{T_1}{2}+\frac{T_1\sqrt3}{\sqrt2}\frac{\sqrt2}{2}=100
\quad\Longrightarrow\quad T_1(1+\sqrt3)=200.
$$

3. **Solve exactly.** Rationalize the denominator:

$$
T_1=\frac{200}{1+\sqrt3}=100(\sqrt3-1),
\qquad T_2=\frac{100\sqrt3(\sqrt3-1)}{\sqrt2}
=50\sqrt2(3-\sqrt3).
$$

4. **Check equilibrium.** Since $T_2\sqrt2=T_1\sqrt3$, horizontal forces cancel. Vertical forces sum to $T_1(1+\sqrt3)/2=100$ N. Both positive tensions therefore balance the weight.
::::
:::::

:::::problem[Problem 3.13 — Find a segment midpoint]{difficulty=easy}
Find the midpoint of $A(-2,3,1)$ and $B(4,-1,5)$.

::::solution[Solution]
**Answer:** $(1,1,3)$.

1. **Select the midpoint formula.** The midpoint of a segment with endpoints $A(x_1,y_1,z_1)$ and $B(x_2,y_2,z_2)$ is found by averaging each corresponding coordinate. Here $A=(-2,3,1)$ and $B=(4,-1,5)$.

2. **Substitute and simplify the averages.** Keep the negative coordinate in parentheses:

$$
M=\left(\frac{-2+4}{2},\frac{3+(-1)}{2},\frac{1+5}{2}\right)
=\left(\frac22,\frac22,\frac62\right)=(1,1,3).
$$

3. **Check the midpoint condition.** The vector from $A$ to $M$ is $\langle1-(-2),1-3,3-1\rangle=\langle3,-2,2\rangle$. The vector from $M$ to $B$ is $\langle4-1,-1-1,5-3\rangle=\langle3,-2,2\rangle$. The halves have the same displacement, proving that $(1,1,3)$ lies halfway along the segment.
::::
:::::

:::::problem[Problem 3.14 — Practice calculation]{difficulty=standard}
Let $\vec{u}=\langle1,-2,3\rangle$, $\vec{v}=\langle-1,4,2\rangle$. Find $2\vec{u}-\vec{v}$ and its exact length.

::::solution[Solution]
**Answer:** $2\vec u-\vec v=\langle3,-8,4\rangle$; its length is $\sqrt{89}$.

1. **Perform vector arithmetic componentwise.** First multiply each component of $\vec u=\langle1,-2,3\rangle$ by $2$:

$$
2\vec u=\langle2,-4,6\rangle.
$$

2. **Subtract the components of $\vec v$.** Because $\vec v=\langle-1,4,2\rangle$, subtracting the negative first component adds one:

$$
2\vec u-\vec v=\langle2-(-1),-4-4,6-2\rangle
=\langle3,-8,4\rangle.
$$

3. **Use the magnitude formula on the resulting vector**, not on its separate terms:

$$
|2\vec u-\vec v|=\sqrt{3^2+(-8)^2+4^2}
=\sqrt{9+64+16}=\sqrt{89}.
$$

4. **Check.** Adding $\vec v$ to $\langle3,-8,4\rangle$ gives $\langle2,-4,6\rangle=2\vec u$. The squared length is $89$, so both reported results satisfy the problem.
::::
:::::

:::callout-key[Test 2 connection: vectors are the ingredients, not the finish line]
Versions A and B use vectors inside later questions even when the prompt never says “compute a vector.” For a triangle, construct two vectors **from the same vertex**; for a plane through three points, the same two differences determine a normal; for a line through two points, one subtraction determines its direction. Write the endpoint subtraction before performing a cross product. A direction vector may be multiplied by any nonzero constant, but a point on a line may not be changed arbitrarily.
:::

Whenever a vector expression has fractions, it is usually safest to leave one common denominator across all components. For instance, $\frac12\langle2,-4,6\rangle-\frac13\langle3,0,-3\rangle=\langle1,-2,3\rangle-\langle1,0,-1\rangle=\langle0,-2,4\rangle$. The magnitude comes **after** combining components: $\sqrt{0^2+(-2)^2+4^2}=2\sqrt5$. This shows why $|\vec u-\vec v|$ is not generally $|\vec u|-|\vec v|$. In a written solution, keeping the component arithmetic visible earns more credit than jumping to the final vector.


:::callout-tip[How to show a vector is the requested direction]
A common proof step in §12.5 is to say that the new line is perpendicular to two given vectors. Do not just announce a cross product. First compute $\vec d=\vec u\times\vec v$ and then check $\vec d\cdot\vec u=0$ and $\vec d\cdot\vec v=0$. For example, $\langle1,2,3\rangle\times\langle3,4,5\rangle=\langle-2,4,-2\rangle$, and
$$
\langle-2,4,-2\rangle\cdot\langle1,2,3\rangle=-2+8-6=0,
$$
$$
\langle-2,4,-2\rangle\cdot\langle3,4,5\rangle=-6+16-10=0.
$$
It can also be shortened to $\langle1,-2,1\rangle$ by multiplying by $-\tfrac12$. Both directions define exactly the same line. This direct computation is a fast way to identify an accidental sign reversal in only one component.
:::

\n\nWhen a direction is all that matters, simplify it before doing anything else. The vectors $\langle6,-9,12\rangle$, $\langle2,-3,4\rangle$ and $\langle-2,3,-4\rangle$ point along the same line: the first two have the same orientation, while the last points backward. Divide $\langle6,-9,12\rangle$ by $3$ to obtain the primitive integer direction $\langle2,-3,4\rangle$. If a problem instead requests a **unit** vector, divide by its length $\sqrt{2^2+(-3)^2+4^2}=\sqrt{29}$. A primitive direction and a unit direction are not interchangeable when the magnitude is explicitly specified.\n
## 12.3 The Dot Product

:::callout-connect
📺 Watch before this section

“Dot products and duality | Essence of Linear Algebra #9” — 3Blue1Brown

“Dot product introduction” — Khan Academy
:::

:::callout-intuition
Intuition first.

You've added vectors and scaled them — but is there a way to **multiply** two vectors and get something useful? The dot product is one answer. Unlike ordinary multiplication it doesn't give you a vector; it gives you a **number** — specifically, a number that encodes how much the two vectors point in the same direction. That single number turns out to unlock: the angle between vectors, the concept of perpendicularity (orthogonality), projection (how far does one vector cast a shadow onto another?), and even the physics of work done by a force along a displacement. One operation, four payoffs.
:::

### Definition — Component Form

:::definition
Definition 12.3.1 — Dot Product

For $\vec{a}=\langle a_1,a_2,a_3\rangle$ and $\vec{b}=\langle b_1,b_2,b_3\rangle$, their **dot product** is the scalar

$$
\vec{a}\cdot\vec{b}=a_1 b_1+a_2 b_2+a_3 b_3.
$$

 In two dimensions drop the third term. The result is always a *real number*, never a vector.
:::

The dot product satisfies several algebraic laws you'd expect from multiplication. For any vectors $\vec{a},\vec{b},\vec{c}$ and scalar $c$:

- **Commutativity:** $\vec{a}\cdot\vec{b}=\vec{b}\cdot\vec{a}$
- **Distributivity:** $\vec{a}\cdot(\vec{b}+\vec{c})=\vec{a}\cdot\vec{b}+\vec{a}\cdot\vec{c}$
- **Scalar associativity:** $(c\vec{a})\cdot\vec{b}=c(\vec{a}\cdot\vec{b})$
- **Self dot product:** $\vec{a}\cdot\vec{a}=|\vec{a}|^2$ (just the sum of squares of components)

:::::example[Example 3.19 — Dot Products in Component Form and in $\mathbf{i},\mathbf{j},\mathbf{k}$ Notation]
Find $\mathbf{a}\cdot\mathbf{b}$ in each case.

(a) $\mathbf{a}=\langle 6,-2,3\rangle$ and $\mathbf{b}=\langle 2,5,-1\rangle$.

(b) $\mathbf{a}=3\mathbf{i}+2\mathbf{j}-\mathbf{k}$ and $\mathbf{b}=4\mathbf{i}+5\mathbf{k}$.

::::answer[Answer]
**Answer:** (a) $\mathbf{a}\cdot\mathbf{b}=-1$. (b) $\mathbf{a}\cdot\mathbf{b}=7$.

1. In both parts the plan is the same: multiply the first components together, the second components together, the third components together, and add the three products.

2. For part (a), the three products are $6\cdot 2=12$, then $(-2)(5)=-10$, then $3\cdot(-1)=-3$. Adding them:

$$
\mathbf{a}\cdot\mathbf{b}=6(2)+(-2)(5)+3(-1)=12-10-3=-1.
$$

3. For part (b), the only new difficulty is that $\mathbf{b}=4\mathbf{i}+5\mathbf{k}$ has no $\mathbf{j}$ term. Nothing is missing, though: a missing term just means its coefficient is zero. So first rewrite the vectors as component lists, $\mathbf{a}=\langle 3,2,-1\rangle$ and $\mathbf{b}=\langle 4,0,5\rangle$. Then

$$
\mathbf{a}\cdot\mathbf{b}=3(4)+2(0)+(-1)(5)=12+0-5=7.
$$

4. Both answers are single numbers, as they must be: a dot product never produces a vector. The negative answer in (a) also tells us the angle between those two vectors is obtuse, and the positive answer in (b) tells us that angle is acute.

5. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### The Geometric Form — Angle Between Vectors

:::theorem[Theorem 12.3.1 — Dot Product and Angle]
If $\theta$ is the angle between nonzero vectors $\vec{a}$ and $\vec{b}$ (with $0\le\theta\le\pi$), then

$$
\vec{a}\cdot\vec{b}=|\vec{a}|\,|\vec{b}|\cos\theta.
$$
:::

Rearranging gives the angle formula:

$$
\cos\theta=\frac{\vec{a}\cdot\vec{b}}{|\vec{a}|\,|\vec{b}|},\qquad\theta=\arccos\!\left(\frac{\vec{a}\cdot\vec{b}}{|\vec{a}|\,|\vec{b}|}\right).
$$

 This is probably the single most-used formula in all of Chapter 3. Memorize it now.

:::callout-key
Sign of the dot product tells direction:

- $\vec{a}\cdot\vec{b}>0$: angle is acute ($\theta<90°$) — vectors lean the same way
- $\vec{a}\cdot\vec{b}=0$: angle is exactly 90° — vectors are *orthogonal*
- $\vec{a}\cdot\vec{b}<0$: angle is obtuse ($\theta>90°$) — vectors lean opposite ways
:::

:::::example[Example 3.20 — Exact Angle and Radian Approximation]
Find the angle between each pair of vectors. Give the exact answer, then approximate the radian measure to two decimal places.

(a) $\mathbf{u}=2\mathbf{i}+\mathbf{j}$ and $\mathbf{v}=\mathbf{i}+2\mathbf{j}-\mathbf{k}$.

(b) $\mathbf{u}=\sqrt{3}\,\mathbf{i}-7\mathbf{j}$ and $\mathbf{v}=\sqrt{3}\,\mathbf{i}+\mathbf{j}-2\mathbf{k}$.

::::answer[Answer]
**Answer:** (a) $\theta=\cos^{-1}\!\left(\dfrac{4}{\sqrt{5}\sqrt{6}}\right)\approx 0.75$ rad. (b) $\theta=\cos^{-1}\!\left(\dfrac{-4}{\sqrt{52}\sqrt{8}}\right)\approx 1.77$ rad.

1. Every angle problem has three ingredients: the dot product on top, and the two lengths on the bottom of the formula $\theta=\cos^{-1}\!\left(\dfrac{\mathbf{u}\cdot\mathbf{v}}{|\mathbf{u}||\mathbf{v}|}\right)$. We find each ingredient separately and then assemble.

2. Part (a). Write the vectors with all three components: $\mathbf{u}=\langle 2,1,0\rangle$ and $\mathbf{v}=\langle 1,2,-1\rangle$. The dot product is

$$
\mathbf{u}\cdot\mathbf{v}=2(1)+1(2)+0(-1)=2+2+0=4.
$$

3. The lengths are

$$
|\mathbf{u}|=\sqrt{4+1+0}=\sqrt{5},\qquad|\mathbf{v}|=\sqrt{1+4+1}=\sqrt{6}.
$$

4. Putting them into the formula gives the exact answer

$$
\theta=\cos^{-1}\!\left(\frac{4}{\sqrt{5}\sqrt{6}}\right)=\cos^{-1}\!\left(\frac{4}{\sqrt{30}}\right).
$$

5. For the approximation, $\sqrt{30}\approx 5.4772$, so the fraction is about $0.7303$, and $\cos^{-1}(0.7303)\approx 0.7520$ radians. To two decimal places, $\theta\approx 0.75$ rad.

6. Part (b). Now $\mathbf{u}=\langle\sqrt{3},-7,0\rangle$ and $\mathbf{v}=\langle\sqrt{3},1,-2\rangle$. Notice that $\sqrt{3}\cdot\sqrt{3}=3$, because a square root times itself gives back the number under it. The dot product is

$$
\mathbf{u}\cdot\mathbf{v}=\sqrt{3}(\sqrt{3})+(-7)(1)+0(-2)=3-7+0=-4.
$$

7. The lengths are

$$
|\mathbf{u}|=\sqrt{3+49+0}=\sqrt{52},\qquad|\mathbf{v}|=\sqrt{3+1+4}=\sqrt{8}.
$$

8. So the exact answer is

$$
\theta=\cos^{-1}\!\left(\frac{-4}{\sqrt{52}\sqrt{8}}\right).
$$

9. To approximate, multiply the square roots first: $\sqrt{52}\sqrt{8}=\sqrt{416}\approx 20.396$. The fraction is $-4/20.396\approx -0.1961$, and $\cos^{-1}(-0.1961)\approx 1.7681$ radians. To two decimal places, $\theta\approx 1.77$ rad.

10. Two sanity checks. In (a) the dot product is positive and the angle, $0.75$ rad, is below $\pi/2\approx 1.57$, so it is acute. In (b) the dot product is negative and the angle, $1.77$ rad, is above $\pi/2$, so it is obtuse. Both agree with the sign rule.

11. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.21 — Angles of a Triangle]
Find the measures of the angles of the triangle with vertices $A=(-1,0)$, $B=(2,1)$ and $C=(1,-2)$. Round each answer to the nearest hundredth of a degree.

::::answer[Answer]
**Answer:** $\angle BAC\approx 63.43^\circ$, $\angle ABC\approx 53.13^\circ$, $\angle ACB\approx 63.43^\circ$.

1. The plan: at each vertex, take the two vectors that run along the two sides meeting there, and apply the angle formula to them. There are three angles, so there are three such computations. Start by building the side vectors, always as "head minus tail":

$$
\overrightarrow{AB}=\langle 2-(-1),\,1-0\rangle=\langle 3,1\rangle,\qquad
\overrightarrow{AC}=\langle 1-(-1),\,-2-0\rangle=\langle 2,-2\rangle,
$$

$$
\overrightarrow{BA}=-\overrightarrow{AB}=\langle -3,-1\rangle,\qquad
\overrightarrow{BC}=\langle 1-2,\,-2-1\rangle=\langle -1,-3\rangle.
$$

2. The lengths we will need are $|\overrightarrow{AB}|=\sqrt{9+1}=\sqrt{10}$, $|\overrightarrow{AC}|=\sqrt{4+4}=\sqrt{8}$, and $|\overrightarrow{BC}|=\sqrt{1+9}=\sqrt{10}$.

3. The angle at $A$. The two sides meeting at $A$ are $\overrightarrow{AB}$ and $\overrightarrow{AC}$. Their dot product is $3(2)+1(-2)=6-2=4$. So

$$
\angle BAC=\cos^{-1}\!\left(\frac{4}{\sqrt{10}\sqrt{8}}\right)=\cos^{-1}\!\left(\frac{4}{\sqrt{80}}\right)\approx\cos^{-1}(0.44721)\approx 63.43^\circ.
$$

4. The angle at $B$. The sides meeting at $B$ are $\overrightarrow{BA}$ and $\overrightarrow{BC}$. Their dot product is $(-3)(-1)+(-1)(-3)=3+3=6$. So

$$
\angle ABC=\cos^{-1}\!\left(\frac{6}{\sqrt{10}\sqrt{10}}\right)=\cos^{-1}\!\left(\frac{6}{10}\right)=\cos^{-1}(0.6)\approx 53.13^\circ.
$$

5. The angle at $C$. The sides meeting at $C$ are $\overrightarrow{CA}=\langle -2,2\rangle$ and $\overrightarrow{CB}=\langle 1,3\rangle$. Their dot product is $(-2)(1)+(2)(3)=-2+6=4$, and the lengths are $\sqrt{8}$ and $\sqrt{10}$. So

$$
\angle ACB=\cos^{-1}\!\left(\frac{4}{\sqrt{8}\sqrt{10}}\right)=\cos^{-1}\!\left(\frac{4}{\sqrt{80}}\right)\approx 63.43^\circ.
$$

6. This is exactly the same expression as the angle at $A$, which is not a coincidence: $|\overrightarrow{AB}|=|\overrightarrow{BC}|=\sqrt{10}$, so the triangle is isosceles, and the angles opposite the two equal sides are equal. It gives a good check on the work: the unrounded angles are about $63.4349^\circ$, $53.1301^\circ$ and $63.4349^\circ$, and these add to $180^\circ$.
::::
:::::

:::callout-pitfall
Do not get the last angle by subtracting rounded angles:

Many people find the third angle of a triangle as $180^\circ$ minus the other two, which is a fine idea. The trap is doing it with numbers that were already rounded. Here $63.43^\circ+53.13^\circ=116.56^\circ$, and $180^\circ-116.56^\circ=63.44^\circ$. That is one hundredth too big, because the true angle is $63.4349^\circ$, which rounds to $63.43^\circ$. Each of the two rounded angles was off by a little, the errors added up rather than cancelling, and the third angle absorbed both. The lecture slide for this triangle makes exactly this slip. When the question says "round to the nearest hundredth", compute every angle directly from its own dot product, as above, and round only once, at the very end. Subtracting from $180^\circ$ is still a useful check, but do it with the unrounded values.
:::

:::::example[Example 3.22 — Acute Angle Between Two Lines]
Find the acute angle between the lines $3x+4y=3$ and $x-y=7$. Round the radian measure to two decimal places.

::::answer[Answer]
**Answer:** $\theta=\cos^{-1}\!\left(\dfrac{1}{5\sqrt{2}}\right)\approx 1.43$ rad.

1. The angle between two lines is the angle between vectors that point along them, so the plan is to find one direction vector for each line and then use the angle formula. A direction vector is easy to read off from the slope, because slope means rise over run.

2. Line 1. Solve for $y$: $4y=-3x+3$, so $y=-\tfrac{3}{4}x+\tfrac{3}{4}$. The slope is $-\tfrac34$, which means "run 4, rise $-3$". So a direction vector is $\mathbf{v}_1=\langle 4,-3\rangle$. (The opposite vector $\langle -4,3\rangle$ points along the same line too.)

3. Line 2. Solve for $y$: $y=x-7$. The slope is $1=\tfrac11$, so a direction vector is $\mathbf{v}_2=\langle 1,1\rangle$.

4. Now the choice of arrow matters. Each line can be described by either of two opposite direction vectors, and those two choices give the angle $\theta$ or its supplement $\pi-\theta$. We want the acute angle, so we need $\mathbf{v}_1\cdot\mathbf{v}_2>0$. The choice $\mathbf{v}_1=\langle 4,-3\rangle$ gives $4(1)+(-3)(1)=1>0$, so it is the right one. (A safe habit is to put absolute value bars around the dot product, which automatically selects the acute angle.) Then

$$
\theta=\cos^{-1}\!\left(\frac{|\mathbf{v}_1\cdot\mathbf{v}_2|}{|\mathbf{v}_1||\mathbf{v}_2|}\right)=\cos^{-1}\!\left(\frac{4(1)+(-3)(1)}{\sqrt{16+9}\,\sqrt{1+1}}\right)=\cos^{-1}\!\left(\frac{1}{5\sqrt{2}}\right).
$$

5. Since $5\sqrt{2}\approx 7.0711$, the fraction is about $0.1414$, and $\cos^{-1}(0.1414)\approx 1.4289$ radians. To two decimal places, $\theta\approx 1.43$ rad, which is about $81.9^\circ$. It is acute, as required.

6. The fact used here is that the angle between two lines equals the angle between their direction vectors, and also the angle between their normal vectors. Either pair gives the same acute angle.

7. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### Orthogonality

Two vectors are **orthogonal** (perpendicular) if and only if their dot product is zero. This is a clean algebraic test — no angle computation needed.

:::definition
Definition 12.3.2 — Orthogonal Vectors

$\vec{a}\perp\vec{b}$ if and only if $\vec{a}\cdot\vec{b}=0$.
:::

:::::example[Example 3.23 — Orthogonal, Parallel, or Neither]
Determine whether the given vectors are orthogonal, parallel, or neither.

(a) $\mathbf{a}=\langle -5,4,-2\rangle$ and $\mathbf{b}=\langle 3,4,-1\rangle$.

(b) $\mathbf{a}=9\mathbf{i}-6\mathbf{j}+3\mathbf{k}$ and $\mathbf{b}=-6\mathbf{i}+4\mathbf{j}-2\mathbf{k}$.

(c) $\mathbf{a}=\langle c,c,c\rangle$ and $\mathbf{b}=\langle c,0,-c\rangle$.

::::answer[Answer]
**Answer:** (a) neither. (b) parallel. (c) orthogonal (for $c\neq 0$).

1. Two different tests are needed, and it pays to keep them straight. Vectors are *orthogonal* when their dot product is zero. Vectors are *parallel* when one is a scalar multiple of the other, which means the ratios of matching components are all equal.

2. Part (a). First the orthogonality test:

$$
\mathbf{a}\cdot\mathbf{b}=(-5)(3)+(4)(4)+(-2)(-1)=-15+16+2=3\neq 0.
$$

3. The dot product is not zero, so the vectors are not orthogonal. Now the parallel test. The ratios of matching components are $\dfrac{-5}{3}\approx-1.67$, then $\dfrac{4}{4}=1$, then $\dfrac{-2}{-1}=2$. These are not all equal, so the vectors are not parallel. The answer is **neither**.

4. Part (b). Compare components of $\mathbf{a}=\langle 9,-6,3\rangle$ and $\mathbf{b}=\langle -6,4,-2\rangle$:

$$
\frac{9}{-6}=-1.5,\qquad\frac{-6}{4}=-1.5,\qquad\frac{3}{-2}=-1.5.
$$

5. All three ratios equal $-1.5$, so $\mathbf{a}=-1.5\,\mathbf{b}$, and the vectors are **parallel**. (Check by multiplying: $-1.5\cdot(-6,4,-2)=\langle 9,-6,3\rangle$.) They point in opposite directions because the ratio is negative. They are certainly not orthogonal: the dot product is $9(-6)+(-6)(4)+3(-2)=-54-24-6=-84$, which is far from zero.

6. Part (c). The dot product is

$$
\mathbf{a}\cdot\mathbf{b}=c(c)+c(0)+c(-c)=c^2+0-c^2=0.
$$

7. It is zero for every value of $c$, so the vectors are **orthogonal**. The one caveat is $c=0$, where both vectors become the zero vector; for any $c\neq 0$ they are genuine perpendicular arrows.

8. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 320 220" width="320" height="220" role="img" aria-label="The perpendicular shadow from u onto v, with its foot">
<path class="fig-axis" d="M30.0 170.0L290.0 170.0"/>
<path class="fig-curve" d="M55.0 170.0L229.0 66.0"/>
<path class="fig-curve-alt" d="M55.0 170.0L287.0 170.0"/>
<path class="fig-guide" d="M229.0 66.0L229.0 170.0"/>
<path class="fig-axis" d="M55.0 170.0L229.0 170.0"/>
<circle class="fig-point" cx="229.0" cy="66.0" r="3"/><text class="fig-label" x="236.0" y="58.0">u</text>
<circle class="fig-point" cx="229.0" cy="170.0" r="3"/><text class="fig-label" x="236.0" y="162.0">proj</text>
<circle class="fig-point" cx="287.0" cy="170.0" r="3"/><text class="fig-label" x="294.0" y="162.0">v</text>
<circle class="fig-point" cx="55.0" cy="170.0" r="3"/><text class="fig-label" x="62.0" y="162.0">O</text>
</svg>
<figcaption>The projection of $\vec u=\langle3,2\rangle$ onto $\vec v=\langle4,0\rangle$ ends at $(3,0)$: $\operatorname{proj}_{\vec v}\vec u=(\vec u\cdot\vec v/|\vec v|^2)\vec v=\langle3,0\rangle$.</figcaption>
</figure>

### Scalar and Vector Projections

Imagine shining a flashlight perpendicular to $\vec{b}$ and asking: what shadow does $\vec{a}$ cast onto $\vec{b}$? That shadow has a length (scalar projection) and a direction (vector projection).

:::definition
Definition 12.3.3 — Projections

The **scalar projection** (component) of $\vec{a}$ onto $\vec{b}$ is

$$
\operatorname{comp}_{\vec{b}}\vec{a}=\frac{\vec{a}\cdot\vec{b}}{|\vec{b}|}.
$$

 The **vector projection** of $\vec{a}$ onto $\vec{b}$ is

$$
\operatorname{proj}_{\vec{b}}\vec{a}=\frac{\vec{a}\cdot\vec{b}}{|\vec{b}|^2}\,\vec{b}=\frac{\vec{a}\cdot\vec{b}}{\vec{b}\cdot\vec{b}}\,\vec{b}.
$$
:::

Memory trick: scalar projection = dot product divided by the *length* of $\vec{b}$; vector projection = scalar projection times the *unit vector* in the direction of $\vec{b}$.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 320 246" width="320" height="246" role="img" aria-label="Vector u, vector v, and the projection of u onto v with the perpendicular dropped from the tip of u">
<path class="fig-axis" d="M207.3 173.5L203.29 156.64L220.15 152.62"/>
<path class="fig-axis" d="M84.2 202.81L83.85 201.41L83.46 200.01L83.03 198.63L82.57 197.26L82.07 195.9L81.54 194.56L80.98 193.23L80.37 191.91L79.74 190.61L79.07 189.33L78.37 188.07L77.64 186.82L76.87 185.59L76.07 184.39L75.24 183.2L74.39 182.04L73.5 180.9L72.58 179.78L71.63 178.69L70.66 177.62L69.65 176.58L68.62 175.56L67.57 174.57L66.49 173.61"/>
<path class="fig-guide" d="M190.95 30L224.16 169.48"/>
<path class="fig-curve-alt" d="M30 215.71L290 153.81"/>
<path class="fig-curve-alt" d="M282.56 159.25L290 153.81L280.9 152.31"/>
<path class="fig-curve-alt" d="M30 215.71L190.95 30"/>
<path class="fig-curve-alt" d="M188.08 38.76L190.95 30L182.69 34.09"/>
<path class="fig-curve" d="M30 215.71L218.37 170.86"/>
<path class="fig-arrow" d="M224.16 169.48L216.73 174.96L215.06 167.95Z"/>
<circle class="fig-point" cx="30" cy="215.71" r="3.2"/>
<text class="fig-label-em" x="296" y="157.81">v</text>
<text class="fig-label-em" x="186.95" y="22">u</text>
<text class="fig-label" x="111.08" y="209.6">proj<tspan dy="2.5">v</tspan><tspan dy="-2.5"> u</tspan></text>
<text class="fig-label" x="213.56" y="101.74">u − proj<tspan dy="2.5">v</tspan><tspan dy="-2.5"> u</tspan></text>
<text class="fig-label" x="52" y="206.71">θ</text>
</svg>
<figcaption>The projection $\operatorname{proj}_{\mathbf{v}}\mathbf{u}=\dfrac{\mathbf{u}\cdot\mathbf{v}}{\mathbf{v}\cdot\mathbf{v}}\,\mathbf{v}$ is the shadow of $\mathbf{u}$ on the line of $\mathbf{v}$: drop a perpendicular from the tip of $\mathbf{u}$, and the foot is the tip of the projection; its length is $|\mathbf{u}|\cos\theta$.</figcaption>
</figure>

:::::example[Example 3.24 — Scalar Component and Vector Projection]
Find the scalar component of $\mathbf{u}$ in the direction of $\mathbf{v}$, and the vector projection $\operatorname{proj}_{\mathbf{v}}\mathbf{u}$.

(a) $\mathbf{u}=\langle 2,2,1\rangle$ and $\mathbf{v}=\langle 2,10,-11\rangle$.

(b) $\mathbf{u}=-3\mathbf{i}+\sqrt{5}\,\mathbf{j}$ and $\mathbf{v}=7\mathbf{i}+2\mathbf{j}$.

::::answer[Answer]
**Answer:** (a) scalar component $\dfrac{13}{15}$, and $\operatorname{proj}_{\mathbf{v}}\mathbf{u}=\dfrac{13}{225}\langle 2,10,-11\rangle$. (b) scalar component $\dfrac{-21+2\sqrt{5}}{\sqrt{53}}$, and $\operatorname{proj}_{\mathbf{v}}\mathbf{u}=\dfrac{-21+2\sqrt{5}}{53}\langle 7,2\rangle$.

1. The scalar component is $\dfrac{\mathbf{u}\cdot\mathbf{v}}{|\mathbf{v}|}$, and the vector projection is that scalar times the unit vector $\dfrac{\mathbf{v}}{|\mathbf{v}|}$. So both answers come from the same two numbers, $\mathbf{u}\cdot\mathbf{v}$ and $|\mathbf{v}|$.

2. Part (a). The dot product is $2(2)+2(10)+1(-11)=4+20-11=13$. The length of $\mathbf{v}$ is $|\mathbf{v}|=\sqrt{4+100+121}=\sqrt{225}=15$. The scalar component is therefore

$$
\frac{\mathbf{u}\cdot\mathbf{v}}{|\mathbf{v}|}=\frac{13}{15}.
$$

3. For the vector projection, multiply this by the unit vector $\dfrac{\mathbf{v}}{15}$:

$$
\operatorname{proj}_{\mathbf{v}}\mathbf{u}=\frac{13}{15}\cdot\frac{\langle 2,10,-11\rangle}{15}=\frac{13}{225}\langle 2,10,-11\rangle=\left\langle\frac{26}{225},\frac{130}{225},\frac{-143}{225}\right\rangle.
$$

4. (The middle entry reduces to $\tfrac{26}{45}$.) This agrees with the other form of the formula, $\dfrac{\mathbf{u}\cdot\mathbf{v}}{|\mathbf{v}|^2}\,\mathbf{v}=\dfrac{13}{225}\mathbf{v}$.

5. Part (b). Here $\mathbf{u}=\langle -3,\sqrt{5}\rangle$ and $\mathbf{v}=\langle 7,2\rangle$. The dot product is $(-3)(7)+\sqrt{5}(2)=-21+2\sqrt{5}$. The length is $|\mathbf{v}|=\sqrt{49+4}=\sqrt{53}$. The scalar component is

$$
\frac{\mathbf{u}\cdot\mathbf{v}}{|\mathbf{v}|}=\frac{-21+2\sqrt{5}}{\sqrt{53}}\approx\frac{-16.53}{7.28}\approx-2.27.
$$

6. For the vector projection, multiply by $\dfrac{\mathbf{v}}{\sqrt{53}}$. The two square roots multiply to $\sqrt{53}\sqrt{53}=53$:

$$
\operatorname{proj}_{\mathbf{v}}\mathbf{u}=\frac{-21+2\sqrt{5}}{\sqrt{53}}\cdot\frac{\langle 7,2\rangle}{\sqrt{53}}=\frac{-21+2\sqrt{5}}{53}\langle 7,2\rangle.
$$

7. The scalar component is negative because $\mathbf{u}$ leans away from the direction of $\mathbf{v}$, so its shadow on the line of $\mathbf{v}$ points backwards.

8. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.25 — Projection of a Force]
Find the vector projection of the force $\mathbf{F}=5\mathbf{i}+2\mathbf{j}$ onto $\mathbf{v}=\mathbf{i}-3\mathbf{j}$, and the scalar component of $\mathbf{F}$ in the direction of $\mathbf{v}$.

::::answer[Answer]
**Answer:** Scalar component $=-\dfrac{1}{\sqrt{10}}$, and $\operatorname{proj}_{\mathbf{v}}\mathbf{F}=-\dfrac{1}{10}\langle 1,-3\rangle=\left\langle-\dfrac{1}{10},\dfrac{3}{10}\right\rangle$.

1. This is the same recipe as the previous example, with a physical reading: the projection is the part of the force that actually acts along the direction $\mathbf{v}$.

2. The dot product is $\mathbf{F}\cdot\mathbf{v}=5(1)+2(-3)=5-6=-1$. The length of $\mathbf{v}$ is $|\mathbf{v}|=\sqrt{1+9}=\sqrt{10}$. So the scalar component is

$$
\frac{\mathbf{F}\cdot\mathbf{v}}{|\mathbf{v}|}=\frac{-1}{\sqrt{10}}\approx-0.316.
$$

3. Multiplying by the unit vector $\dfrac{\mathbf{v}}{\sqrt{10}}$, and using $\sqrt{10}\sqrt{10}=10$, gives the vector projection

$$
\operatorname{proj}_{\mathbf{v}}\mathbf{F}=\frac{-1}{\sqrt{10}}\cdot\frac{\mathbf{i}-3\mathbf{j}}{\sqrt{10}}=-\frac{1}{10}(\mathbf{i}-3\mathbf{j})=-\frac{1}{10}\langle 1,-3\rangle=\left\langle-\frac{1}{10},\frac{3}{10}\right\rangle.
$$

4. The negative sign means that, along the direction of $\mathbf{v}$, this force pushes slightly backwards rather than forwards. It is a small effect because $\mathbf{F}$ is almost perpendicular to $\mathbf{v}$: the dot product $-1$ is tiny next to the size of the vectors.

5. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::


### Work as a Dot Product

In physics, work done by a constant force $\vec{F}$ along a displacement $\vec{d}$ is

$$
W=\vec{F}\cdot\vec{d}=|\vec{F}|\,|\vec{d}|\cos\theta,
$$

 where $\theta$ is the angle between force and displacement. If you push perpendicular to the motion, $\theta=90°$, $\cos\theta=0$, and you do zero work — which matches intuition (pushing sideways on a cart that rolls forward accomplishes nothing energetically).

### Worked Examples — Dot Product

:::::example[Example 3.26 — Computing a Dot Product]
Find $\vec{a}\cdot\vec{b}$ for $\vec{a}=\langle 3,-1,2\rangle$ and $\vec{b}=\langle 1,4,-1\rangle$.

::::answer[Answer]
**Answer:** $\vec{a}\cdot\vec{b}=-3$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Apply the calculation in the displayed expression.

$$
\vec{a}\cdot\vec{b}=(3)(1)+(-1)(4)+(2)(-1)=3-4-2=-3.
$$

3. (Negative means obtuse angle between these vectors.)

4. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.27 — Angle Between Two Vectors]
Find the angle between $\vec{a}=\langle 3,-1,2\rangle$ and $\vec{b}=\langle 1,4,-1\rangle$.

::::answer[Answer]
**Answer:** $\theta=\arccos\!\left(\tfrac{-3}{\sqrt{14}\sqrt{18}}\right)\approx100.9°$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Apply the calculation in the displayed expression.

$$
|\vec{a}|=\sqrt{9+1+4}=\sqrt{14},\qquad|\vec{b}|=\sqrt{1+16+1}=\sqrt{18}=3\sqrt{2}.
$$

$$
\cos\theta=\frac{\vec{a}\cdot\vec{b}}{|\vec{a}|\,|\vec{b}|}=\frac{-3}{\sqrt{14}\cdot 3\sqrt{2}}=\frac{-3}{3\sqrt{28}}=\frac{-1}{\sqrt{28}}.
$$

$$
\theta=\arccos\!\left(\frac{-1}{\sqrt{28}}\right)\approx\arccos(-0.1890)\approx100.9°.
$$

3. The negative dot product correctly predicts an obtuse angle.

4. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.28 — Testing Orthogonality]
Find $z$ so that $\vec{a}=\langle 4,z,3\rangle$ is perpendicular to $\vec{b}=\langle 1,2,-1\rangle$.

::::answer[Answer]
**Answer:** $z=-\tfrac{1}{2}$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Set $\vec{a}\cdot\vec{b}=0$:

$$
4(1)+z(2)+3(-1)=0\implies 4+2z-3=0\implies 2z=-1\implies z=-\tfrac{1}{2}.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.29 — Vector Projection]
Find the scalar and vector projection of $\vec{a}=\langle 3,1\rangle$ onto $\vec{b}=\langle 1,1\rangle$.

::::answer[Answer]
**Answer:** Scalar projection $\operatorname{comp}_{\vec{b}}\vec{a}=2\sqrt{2}$; vector projection $\operatorname{proj}_{\vec{b}}\vec{a}=\langle 2,2\rangle$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Apply the calculation in the displayed expression.

$$
\vec{a}\cdot\vec{b}=3(1)+1(1)=4,\qquad|\vec{b}|^2=1+1=2.
$$

3. Scalar projection:

$$
\operatorname{comp}_{\vec{b}}\vec{a}=\frac{4}{\sqrt{2}}=2\sqrt{2}.
$$

4. Vector projection:

$$
\operatorname{proj}_{\vec{b}}\vec{a}=\frac{4}{2}\langle 1,1\rangle=2\langle 1,1\rangle=\langle 2,2\rangle.
$$

5. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.30 — Work Done by a Force]
A force $\vec{F}=\langle 5,3,-2\rangle$ N moves an object along displacement $\vec{d}=\langle 4,3,2\rangle$ m. Find the work done.

::::answer[Answer]
**Answer:** $W=25$ J.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. Apply the calculation in the displayed expression.

$$
W=\vec{F}\cdot\vec{d}=(5)(4)+(3)(3)+(-2)(2)=20+9-4=25\text{ J}.
$$

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::callout-pitfall
Watch out for:

- **Dot product is a scalar, not a vector.** Writing $\vec{a}\cdot\vec{b}=\langle\ldots\rangle$ is always wrong.
- **Projection direction matters.** $\operatorname{proj}_{\vec{b}}\vec{a}\ne\operatorname{proj}_{\vec{a}}\vec{b}$ in general — the denominator changes.
- **Dividing by $|\vec{b}|^2$, not $|\vec{b}|$.** In the vector projection formula, the denominator is $\vec{b}\cdot\vec{b}=|\vec{b}|^2$. A common error is dividing by $|\vec{b}|$ instead.
:::

:::::problem[Problem 3.15 — Practice calculation]{difficulty=easy}
Compute $\langle 2,-3,1\rangle\cdot\langle 4,0,-5\rangle$.

::::solution[Solution]
**Answer:** $3$.

1. **Choose the dot-product formula.** For vectors $\langle a_1,a_2,a_3\rangle$ and $\langle b_1,b_2,b_3\rangle$, multiply matching components and add. Both given vectors have three components, so the formula applies directly.

2. **Write the three products before adding.** For $\langle2,-3,1\rangle$ and $\langle4,0,-5\rangle$,

$$
\langle2,-3,1\rangle\cdot\langle4,0,-5\rangle
=(2)(4)+(-3)(0)+(1)(-5).
$$

3. **Evaluate each product.** The terms are $8$, $0$, and $-5$, so

$$
8+0-5=3.
$$

4. **Check the sign.** The negative third-coordinate contribution subtracts from the positive first-coordinate contribution, yielding a positive scalar. Thus the dot product is $3$, not a vector, which is the form the question asks for.
::::
:::::

:::::problem[Problem 3.16 — Angle from a dot product]{difficulty=easy}
Find the angle between $\vec{u}=\langle 1,0,0\rangle$ and $\vec{v}=\langle 1,1,0\rangle$.

::::solution[Solution]
**Answer:** $45^\circ$ (or $\pi/4$ radians).

1. **Use the dot-product angle formula** $\cos\theta=(\vec u\cdot\vec v)/(|\vec u||\vec v|)$. It applies because neither $\vec u=\langle1,0,0\rangle$ nor $\vec v=\langle1,1,0\rangle$ is the zero vector.

2. **Compute the dot product and magnitudes.** Write out each component:

$$
\vec u\cdot\vec v=1(1)+0(1)+0(0)=1,
$$
$$
|\vec u|=\sqrt{1^2+0^2+0^2}=1,
\qquad|\vec v|=\sqrt{1^2+1^2+0^2}=\sqrt2.
$$

3. **Solve for the angle.** Then $\cos\theta=1/\sqrt2=\sqrt2/2$. The exact special angle whose cosine equals $\sqrt2/2$ is $45^\circ$.

4. **Check.** The positive dot product means the angle is acute, consistent with $45^\circ$. Therefore the vectors meet at an angle of $\pi/4$ radians.
::::
:::::

:::::problem[Problem 3.17 — Practice calculation]{difficulty=standard}
Find $c$ such that $\langle c,2,1\rangle\perp\langle 3,c,-5\rangle$.

::::solution[Solution]
**Answer:** $c=1$.

1. **Use the perpendicularity test.** Two vectors in Euclidean space are perpendicular precisely when their dot product is zero. The given vectors are $\langle c,2,1\rangle$ and $\langle3,c,-5\rangle$.

2. **Multiply matching components and set their sum to zero:**

$$
(c)(3)+(2)(c)+(1)(-5)=0.
$$

3. **Collect like terms and solve.** The equation becomes $3c+2c-5=0$, then $5c=5$, then $c=1$ after division by $5\ne0$.

4. **Substitute back as a check.** At $c=1$ the vectors become $\langle1,2,1\rangle$ and $\langle3,1,-5\rangle$, whose dot product is

$$
1(3)+2(1)+1(-5)=3+2-5=0.
$$

Therefore $c=1$ makes the two vectors perpendicular, and the linear equation gives no other value.
::::
:::::

:::::problem[Problem 3.18 — Practice calculation]{difficulty=standard}
Find $\operatorname{proj}_{\vec{b}}\vec{a}$ for $\vec{a}=\langle 1,2,3\rangle$, $\vec{b}=\langle 2,1,0\rangle$.

::::solution[Solution]
**Answer:** $\operatorname{proj}_{\vec b}\vec a=\left\langle\frac85,\frac45,0\right\rangle$.

1. **Choose the vector projection formula.** The projection of $\vec a$ onto a nonzero vector $\vec b$ is $((\vec a\cdot\vec b)/|\vec b|^2)\vec b$. Here $\vec b=\langle2,1,0\rangle\ne\vec0$, so the denominator is nonzero.

2. **Compute the two scalar ingredients.** Multiply component pairs and square the components of $\vec b$:

$$
\vec a\cdot\vec b=1(2)+2(1)+3(0)=2+2+0=4,
$$
$$
|\vec b|^2=2^2+1^2+0^2=4+1=5.
$$

3. **Scale $\vec b$ by the quotient.** Thus

$$
\operatorname{proj}_{\vec b}\vec a
=\frac45\langle2,1,0\rangle
=\left\langle\frac85,\frac45,0\right\rangle.
$$

4. **Check orthogonality.** The remainder is $\vec a-\operatorname{proj}=\langle-3/5,6/5,3\rangle$, and its dot product with $\vec b$ is $-6/5+6/5+0=0$. Therefore the projection is correct.
::::
:::::

:::::problem[Problem 3.19 — Practice calculation]{difficulty=standard}
A force of magnitude 10 N acts at 60° to a displacement of 5 m. Find the work done.

::::solution[Solution]
**Answer:** $25\text{ J}$.

1. **Use the constant-force work formula.** Work equals the dot product $W=\vec F\cdot\vec d=|\vec F||\vec d|\cos\theta$. The force and displacement are nonzero, and their included angle is given as $60^\circ$.

2. **Identify the quantities with units.** The force magnitude is $|\vec F|=10\text{ N}$; the displacement magnitude is $|\vec d|=5\text{ m}$; and from the special-angle table $\cos60^\circ=1/2$.

3. **Substitute without a calculator:**

$$
W=(10)(5)\cos60^\circ
=50\left(\frac12\right)=25\text{ N}\cdot\text{m}=25\text{ J}.
$$

4. **Check interpretation.** Because the angle is acute, the force has a positive component along the displacement, so the work must be positive. The result is $25$ joules of work, with the correct units and sign.
::::
:::::

:::::problem[Problem 3.20 — Practice calculation]{difficulty=challenge}
Decompose $\vec{a}=\langle 3,2,1\rangle$ into a component parallel to $\vec{b}=\langle 1,1,1\rangle$ and a component orthogonal to $\vec{b}$. Verify your orthogonal component is indeed perpendicular to $\vec{b}$.

::::solution[Solution]
**Answer:** Parallel component $\langle2,2,2\rangle$; orthogonal component $\langle1,0,-1\rangle$.

1. **Use projection to split the vector.** Because $\vec b=\langle1,1,1\rangle\ne\vec0$, write $\vec a=\vec a_{\parallel}+\vec a_{\perp}$ with $\vec a_{\parallel}=((\vec a\cdot\vec b)/|\vec b|^2)\vec b$.

2. **Compute the projection coefficient.** For $\vec a=\langle3,2,1\rangle$,

$$
\vec a\cdot\vec b=3(1)+2(1)+1(1)=6,
\qquad |\vec b|^2=1+1+1=3.
$$

3. **Find both parts.** Therefore

$$
\vec a_{\parallel}=\frac63\langle1,1,1\rangle=\langle2,2,2\rangle,
$$
$$
\vec a_{\perp}=\vec a-\vec a_{\parallel}
=\langle3-2,2-2,1-2\rangle=\langle1,0,-1\rangle.
$$

4. **Check both requirements.** The perpendicularity test gives $\vec a_{\perp}\cdot\vec b=1+0-1=0$. Adding the two parts yields $\langle2,2,2\rangle+\langle1,0,-1\rangle=\langle3,2,1\rangle=\vec a$. This proves the requested decomposition.
::::
:::::

## 12.4 The Cross Product

:::callout-connect
📺 Watch before this section

“Cross products | Essence of Linear Algebra #10” — 3Blue1Brown

“Cross product introduction” — Khan Academy
:::

:::callout-intuition
The dot product takes two vectors and returns a scalar that measures alignment. The **cross product** takes two vectors and returns a new **vector** perpendicular to both, so it gives the missing direction for a plane normal. Think of it this way: if you lay your right hand flat, fingers pointing along $\vec{a}$, and curl them toward $\vec{b}$, your thumb points in the direction of $\vec{a}\times\vec{b}$. The length of the cross product equals the area of the parallelogram spanned by $\vec{a}$ and $\vec{b}$. Applications: finding a normal to a plane (essential for §12.5), computing torque in physics, and defining the scalar triple product used for volumes.
:::

### The Determinant Formula

:::definition
Definition 12.4.1 — Cross Product

For $\vec{a}=\langle a_1,a_2,a_3\rangle$ and $\vec{b}=\langle b_1,b_2,b_3\rangle$,

$$
\vec{a}\times\vec{b}=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\a_1&a_2&a_3\\b_1&b_2&b_3\end{vmatrix}
 =\langle a_2 b_3-a_3 b_2,\;a_3 b_1-a_1 b_3,\;a_1 b_2-a_2 b_1\rangle.
$$
:::

Expand the determinant by cofactors along the top row:

$$
\vec{a}\times\vec{b}=\hat{\imath}(a_2 b_3-a_3 b_2)-\hat{\jmath}(a_1 b_3-a_3 b_1)+\hat{k}(a_1 b_2-a_2 b_1).
$$

 Notice the minus sign on the $\hat{\jmath}$ term — this is the most common arithmetic error on exams.

:::callout-key
Algebraic properties of the cross product:

- **Anti-commutativity:** $\vec{a}\times\vec{b}=-(\vec{b}\times\vec{a})$
- **Self cross product:** $\vec{a}\times\vec{a}=\vec{0}$ for any vector
- **Distributivity:** $\vec{a}\times(\vec{b}+\vec{c})=\vec{a}\times\vec{b}+\vec{a}\times\vec{c}$
- **Basis vectors:** $\hat{\imath}\times\hat{\jmath}=\hat{k}$, $\hat{\jmath}\times\hat{k}=\hat{\imath}$, $\hat{k}\times\hat{\imath}=\hat{\jmath}$
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 320 220" width="320" height="220" role="img" aria-label="Parallelogram on u and v with an altitude dropped to the base">
<path class="fig-curve" d="M55.0 178.0L235.0 178.0"/>
<path class="fig-curve-alt" d="M55.0 178.0L110.0 70.0"/>
<path class="fig-guide" d="M110.0 70.0L290.0 70.0"/>
<path class="fig-guide" d="M235.0 178.0L290.0 70.0"/>
<path class="fig-guide" d="M110.0 70.0L110.0 178.0"/>
<circle class="fig-point" cx="55.0" cy="178.0" r="3"/><text class="fig-label" x="62.0" y="170.0">O</text>
<circle class="fig-point" cx="235.0" cy="178.0" r="3"/><text class="fig-label" x="242.0" y="170.0">u</text>
<circle class="fig-point" cx="110.0" cy="70.0" r="3"/><text class="fig-label" x="117.0" y="62.0">v</text>
</svg>
<figcaption>For planar vectors $\vec u=\langle3,0,0\rangle$ and $\vec v=\langle1,2,0\rangle$, the cross-product magnitude is $|\langle0,0,6\rangle|=6$, agreeing with base $3$ times height $2$.</figcaption>
</figure>

### Geometric Meaning

:::theorem[Theorem 12.4.1 — Geometric Cross Product]
$$
|\vec{a}\times\vec{b}|=|\vec{a}|\,|\vec{b}|\sin\theta,
$$

 where $0\le\theta\le\pi$ is the angle between $\vec{a}$ and $\vec{b}$. The direction of $\vec{a}\times\vec{b}$ is perpendicular to both, given by the right-hand rule. Geometrically, $|\vec{a}\times\vec{b}|$ equals the area of the parallelogram with sides $\vec{a}$ and $\vec{b}$.
:::


<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 320 168" width="320" height="168" role="img" aria-label="A parallelogram spanned by u and v with its height h dropped to the base, area labeled magnitude of u cross v">
<path class="fig-fill" d="M30 137.92L226.23 137.92L290 30L93.77 30Z"/>
<path class="fig-axis" d="M104.57 137.92L104.57 127.13L93.77 127.13"/>
<path class="fig-axis" d="M66.79 137.92L66.76 136.34L66.66 134.75L66.48 133.17L66.24 131.6L65.94 130.04L65.56 128.49L65.12 126.96L64.62 125.46L64.04 123.97L63.41 122.52L62.71 121.09L61.96 119.69L61.14 118.33L60.26 117L59.33 115.71L58.34 114.47L57.3 113.26L56.21 112.11L55.07 111L53.89 109.94L52.66 108.93L51.38 107.98L50.07 107.09L48.72 106.25"/>
<path class="fig-guide" d="M226.23 137.92L290 30"/>
<path class="fig-guide" d="M93.77 30L290 30"/>
<path class="fig-guide" d="M93.77 30L93.77 137.92"/>
<path class="fig-curve-alt" d="M30 137.92L226.23 137.92"/>
<path class="fig-curve-alt" d="M217.73 141.49L226.23 137.92L217.73 134.35"/>
<path class="fig-curve" d="M30 137.92L90.75 35.12"/>
<path class="fig-arrow" d="M93.77 30L92.55 39.15L86.35 35.49Z"/>
<circle class="fig-point" cx="30" cy="137.92" r="3.2"/>
<text class="fig-label-em" x="137.92" y="152.92">u</text>
<text class="fig-label-em" x="87.77" y="22">v</text>
<text class="fig-label" x="98.77" y="87.96">h</text>
<text class="fig-label" x="54" y="131.92">θ</text>
<text class="fig-label-em" x="137" y="87.96">|u × v|</text>
</svg>
<figcaption>The parallelogram spanned by $\mathbf{u}$ and $\mathbf{v}$ has base $|\mathbf{u}|$ and height $h=|\mathbf{v}|\sin\theta$, so its area is $|\mathbf{u}||\mathbf{v}|\sin\theta=|\mathbf{u}\times\mathbf{v}|$.</figcaption>
</figure>


The picture above is the whole reason the length formula works. Take $\vec{a}$ as the base of the parallelogram. Its height is the part of $\vec{b}$ that sticks out sideways from $\vec{a}$, and that is $|\vec{b}|\sin\theta$. Base times height is $|\vec{a}|\,|\vec{b}|\sin\theta$, which is exactly $|\vec{a}\times\vec{b}|$. So when a problem asks for an area, the cross product is the tool, and you take its length at the end.


<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 180 300" width="180" height="300" role="img" aria-label="Vectors u and v in the xy-plane and their cross product pointing straight up along the z direction">
<path class="fig-fill" d="M72.35 198.76L30 247.49L107.32 270L149.67 221.27Z"/>
<path class="fig-axis" d="M60.84 212.01L62.6 212.24L64.4 212.44L66.21 212.59L68.05 212.71L69.9 212.78L71.75 212.81L73.61 212.81L75.46 212.76L77.3 212.67L79.13 212.54L80.94 212.38L82.73 212.17L84.48 211.92L86.2 211.64L87.88 211.32L89.52 210.96L91.1 210.57L92.64 210.14L94.11 209.68L95.52 209.19L96.86 208.67L98.14 208.12L99.33 207.54L100.45 206.94"/>
<path class="fig-guide" d="M30 247.49L107.32 270"/>
<path class="fig-guide" d="M149.67 221.27L107.32 270"/>
<path class="fig-curve-alt" d="M72.35 198.76L30 247.49"/>
<path class="fig-curve-alt" d="M32.88 238.73L30 247.49L38.27 243.42"/>
<path class="fig-curve-alt" d="M72.35 198.76L149.67 221.27"/>
<path class="fig-curve-alt" d="M140.51 222.32L149.67 221.27L142.51 215.47"/>
<path class="fig-curve" d="M72.35 198.76L72.35 35.95"/>
<path class="fig-arrow" d="M72.35 30L75.95 38.5L68.75 38.5Z"/>
<path class="fig-axis" d="M99.36 208.23L100.45 206.94L98.77 207.06"/>
<circle class="fig-point" cx="72.35" cy="198.76" r="3.2"/>
<text class="fig-label-em" x="45.06" y="241.56">u</text>
<text class="fig-label-em" x="155.67" y="225.27">v</text>
<text class="fig-label-em" x="54.35" y="23">u × v</text>
</svg>
<figcaption>The cross product $\mathbf{u}\times\mathbf{v}$ is perpendicular to the plane of $\mathbf{u}$ and $\mathbf{v}$; curl the fingers of your right hand from $\mathbf{u}$ toward $\mathbf{v}$ (the arc) and your thumb points along $\mathbf{u}\times\mathbf{v}$, here up the $z$ direction.</figcaption>
</figure>


Corollaries: Two nonzero vectors are parallel ($\theta=0$ or $\pi$) if and only if $\vec{a}\times\vec{b}=\vec{0}$. This is the cross-product analog of the dot-product orthogonality test.

There are two different things you can ask about a cross product, and they are worth keeping apart. Its **length** is $|\vec{a}\times\vec{b}|$, a single nonnegative number. Its **direction** is the unit vector you get by dividing the cross product by that length, and it is only defined when the length is not zero. The next two examples ask for both, and the first one is the case where the direction does not exist.

:::::example[Example 3.31 — Parallel Vectors Give a Zero Cross Product]
Find the length and direction (when defined) of $\vec{u}\times\vec{v}$ and $\vec{v}\times\vec{u}$ for $\vec{u}=2\hat{\imath}-2\hat{\jmath}+4\hat{k}$ and $\vec{v}=-\hat{\imath}+\hat{\jmath}-2\hat{k}$.

::::answer[Answer]
**Answer:** $\vec{u}\times\vec{v}=\vec{0}$ and $\vec{v}\times\vec{u}=\vec{0}$. Both have length $0$ and neither has a direction.

1. Set up the determinant with $\vec{u}=\langle 2,-2,4\rangle$ in the middle row and $\vec{v}=\langle -1,1,-2\rangle$ in the bottom row, then expand along the top row. Remember the minus sign on the $\hat{\jmath}$ term:

$$
\vec{u}\times\vec{v}=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\2&-2&4\\-1&1&-2\end{vmatrix}
=\begin{vmatrix}-2&4\\1&-2\end{vmatrix}\hat{\imath}-\begin{vmatrix}2&4\\-1&-2\end{vmatrix}\hat{\jmath}+\begin{vmatrix}2&-2\\-1&1\end{vmatrix}\hat{k}.
$$

2. Now evaluate each $2\times 2$ determinant as (top-left times bottom-right) minus (top-right times bottom-left):

$$
\begin{vmatrix}-2&4\\1&-2\end{vmatrix}=(-2)(-2)-(4)(1)=4-4=0,
$$

$$
\begin{vmatrix}2&4\\-1&-2\end{vmatrix}=(2)(-2)-(4)(-1)=-4-(-4)=0,
$$

$$
\begin{vmatrix}2&-2\\-1&1\end{vmatrix}=(2)(1)-(-2)(-1)=2-2=0.
$$

3. So $\vec{u}\times\vec{v}=0\hat{\imath}-0\hat{\jmath}+0\hat{k}=\vec{0}$.

4. Because $\vec{u}\times\vec{v}=-(\vec{v}\times\vec{u})$, we get $\vec{v}\times\vec{u}=-\vec{0}=\vec{0}$ as well. The zero vector has length $0$ and points nowhere, so there is no direction to report.

5. *Why this happened:* $\vec{v}=-\tfrac12\vec{u}$, so the two vectors are parallel, and parallel vectors always give the zero cross product. The parallelogram they span is squashed flat and has area $0$.

6. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.32 — Length and Direction of a Cross Product]
Find the length and direction (when defined) of $\vec{u}\times\vec{v}$ and $\vec{v}\times\vec{u}$ for $\vec{u}=-8\hat{\imath}-2\hat{\jmath}-4\hat{k}$ and $\vec{v}=2\hat{\imath}+2\hat{\jmath}+\hat{k}$.

::::answer[Answer]
**Answer:** $\vec{u}\times\vec{v}=6\hat{\imath}-12\hat{k}$, length $6\sqrt{5}$, direction $\dfrac{\hat{\imath}-2\hat{k}}{\sqrt{5}}$. Reversing the order gives $\vec{v}\times\vec{u}=-6\hat{\imath}+12\hat{k}$, same length, direction $\dfrac{-\hat{\imath}+2\hat{k}}{\sqrt{5}}$.

1. Write the determinant with $\vec{u}=\langle -8,-2,-4\rangle$ and $\vec{v}=\langle 2,2,1\rangle$ and expand along the top row:

$$
\vec{u}\times\vec{v}=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\-8&-2&-4\\2&2&1\end{vmatrix}
=\begin{vmatrix}-2&-4\\2&1\end{vmatrix}\hat{\imath}-\begin{vmatrix}-8&-4\\2&1\end{vmatrix}\hat{\jmath}+\begin{vmatrix}-8&-2\\2&2\end{vmatrix}\hat{k}.
$$

2. The three small determinants:

$$
\begin{vmatrix}-2&-4\\2&1\end{vmatrix}=(-2)(1)-(-4)(2)=-2-(-8)=6,
$$

$$
\begin{vmatrix}-8&-4\\2&1\end{vmatrix}=(-8)(1)-(-4)(2)=-8-(-8)=0,
$$

$$
\begin{vmatrix}-8&-2\\2&2\end{vmatrix}=(-8)(2)-(-2)(2)=-16-(-4)=-12.
$$

3. Assemble, keeping the minus sign in front of the $\hat{\jmath}$ term:

$$
\vec{u}\times\vec{v}=6\hat{\imath}-0\hat{\jmath}-12\hat{k}=6\hat{\imath}-12\hat{k}.
$$

4. *Length.*

$$
|\vec{u}\times\vec{v}|=\sqrt{6^2+0^2+(-12)^2}=\sqrt{36+144}=\sqrt{180}=\sqrt{36\cdot 5}=6\sqrt{5}.
$$

5. *Direction.* Divide the vector by its length:

$$
\frac{\vec{u}\times\vec{v}}{|\vec{u}\times\vec{v}|}=\frac{6\hat{\imath}-12\hat{k}}{6\sqrt{5}}=\frac{\hat{\imath}-2\hat{k}}{\sqrt{5}}.
$$

6. *The other order.* Anti-commutativity says $\vec{v}\times\vec{u}=-(\vec{u}\times\vec{v})$, so

$$
\vec{v}\times\vec{u}=-6\hat{\imath}+12\hat{k}.
$$

7. Flipping a vector does not change its length, so $|\vec{v}\times\vec{u}|=6\sqrt{5}$, and the direction is the opposite unit vector, $\dfrac{-\hat{\imath}+2\hat{k}}{\sqrt{5}}$.

8. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::

### The Scalar Triple Product and Parallelepiped Volume

*Not on the released Test 2 versions A/B.* Kept for the next chapter and mixed practice.

:::definition
Definition 12.4.2 — Scalar Triple Product

For three vectors $\vec{a},\vec{b},\vec{c}$:

$$
\vec{a}\cdot(\vec{b}\times\vec{c})=\begin{vmatrix}a_1&a_2&a_3\\b_1&b_2&b_3\\c_1&c_2&c_3\end{vmatrix}.
$$

 The **volume** of the parallelepiped with adjacent edges $\vec{a},\vec{b},\vec{c}$ is $V=|\vec{a}\cdot(\vec{b}\times\vec{c})|$.
:::

Geometric reason: $|\vec{b}\times\vec{c}|$ is the area of the base parallelogram, and $|\vec{a}\cdot(\vec{b}\times\vec{c})|/|\vec{b}\times\vec{c}|$ is the height — so the product gives base × height = volume.


<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 261 300" width="261" height="300" role="img" aria-label="A parallelepiped whose three edges from one corner are the vectors u, v and w">
<path class="fig-fill" d="M77.78 155.94L30 226.15L170.69 270L218.47 199.79Z"/>
<path class="fig-axis" d="M30 226.15L170.69 270"/>
<path class="fig-axis" d="M218.47 199.79L170.69 270"/>
<path class="fig-axis" d="M30 226.15L42.05 100.21"/>
<path class="fig-axis" d="M218.47 199.79L230.51 73.85"/>
<path class="fig-axis" d="M170.69 270L182.74 144.06"/>
<path class="fig-axis" d="M89.82 30L42.05 100.21"/>
<path class="fig-axis" d="M89.82 30L230.51 73.85"/>
<path class="fig-axis" d="M42.05 100.21L182.74 144.06"/>
<path class="fig-axis" d="M230.51 73.85L182.74 144.06"/>
<path class="fig-curve-alt" d="M77.78 155.94L30 226.15"/>
<path class="fig-curve-alt" d="M31.83 217.11L30 226.15L37.73 221.13"/>
<path class="fig-curve-alt" d="M77.78 155.94L218.47 199.79"/>
<path class="fig-curve-alt" d="M209.29 200.67L218.47 199.79L211.41 193.86"/>
<path class="fig-curve" d="M77.78 155.94L89.26 35.92"/>
<path class="fig-arrow" d="M89.82 30L92.6 38.8L85.43 38.12Z"/>
<circle class="fig-point" cx="77.78" cy="155.94" r="3.2"/>
<text class="fig-label-em" x="47.5" y="209.56">u</text>
<text class="fig-label-em" x="157.15" y="194.06">v</text>
<text class="fig-label-em" x="75.82" y="26">w</text>
<text class="fig-label" x="114.23" y="216.97">base</text>
</svg>
<figcaption>The parallelepiped spanned by $\mathbf{u},\mathbf{v},\mathbf{w}$: the shaded base has area $|\mathbf{u}\times\mathbf{v}|$ and the height is the length of the projection of $\mathbf{w}$ on $\mathbf{u}\times\mathbf{v}$, so the volume is $|(\mathbf{u}\times\mathbf{v})\cdot\mathbf{w}|$.</figcaption>
</figure>


A useful way to say all this in one line: the triple scalar product $\vec{a}\cdot(\vec{b}\times\vec{c})$ is the **signed volume** of the box. The absolute value is the ordinary volume, which is never negative. The sign only records whether $\vec{a},\vec{b},\vec{c}$ form a right-handed set (positive) or a left-handed set (negative). Two more facts follow. First, the order of the dot and cross does not matter, so $\vec{a}\cdot(\vec{b}\times\vec{c})=(\vec{a}\times\vec{b})\cdot\vec{c}$, which is why the lecture writes it as $(\vec{u}\times\vec{v})\cdot\vec{w}$. Second, the triple product is also called the **box product**.

To compute it, you build a $3\times 3$ determinant whose rows are the three vectors, in order, and expand along the top row.

:::::example[Example 3.33 — Volume of a Parallelepiped from Four Vertices]
Find the volume of the parallelepiped with one vertex at $A(-1,2,3)$ and three adjacent vertices at $B(2,0,1)$, $C(1,-3,2)$, and $D(-2,1,-1)$.

::::answer[Answer]
**Answer:** $V=53$.

1. The three edges that meet at $A$ are the vectors from $A$ to each neighbor. Subtract the coordinates of $A$ from each:

$$
\overrightarrow{AB}=\langle 2-(-1),\,0-2,\,1-3\rangle=\langle 3,-2,-2\rangle,
$$

$$
\overrightarrow{AC}=\langle 1-(-1),\,-3-2,\,2-3\rangle=\langle 2,-5,-1\rangle,
$$

$$
\overrightarrow{AD}=\langle -2-(-1),\,1-2,\,-1-3\rangle=\langle -1,-1,-4\rangle.
$$

2. The volume is the absolute value of the triple product. Put the three vectors in the rows of a determinant and expand along the top row, with signs $+,-,+$:

$$
(\overrightarrow{AB}\times\overrightarrow{AC})\cdot\overrightarrow{AD}=\begin{vmatrix}3&-2&-2\\2&-5&-1\\-1&-1&-4\end{vmatrix}
=3\begin{vmatrix}-5&-1\\-1&-4\end{vmatrix}-(-2)\begin{vmatrix}2&-1\\-1&-4\end{vmatrix}+(-2)\begin{vmatrix}2&-5\\-1&-1\end{vmatrix}.
$$

3. Evaluate the three minors:

$$
\begin{vmatrix}-5&-1\\-1&-4\end{vmatrix}=(-5)(-4)-(-1)(-1)=20-1=19,
$$

$$
\begin{vmatrix}2&-1\\-1&-4\end{vmatrix}=(2)(-4)-(-1)(-1)=-8-1=-9,
$$

$$
\begin{vmatrix}2&-5\\-1&-1\end{vmatrix}=(2)(-1)-(-5)(-1)=-2-5=-7.
$$

4. Substitute:

$$
3(19)-(-2)(-9)+(-2)(-7)=57-18+14=53.
$$

5. Finally, $V=|53|=53$ cubic units.

6. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

### Coplanarity: When the Box Is Flat

*Not on the released Test 2 versions A/B.* Keep the zero-volume test as a useful extension.

:::callout-intuition
Three edge vectors that start at the same point normally span a solid box. But if all three lie in one flat plane, the box has been squashed into that plane and has no thickness, so its volume is $0$. The reverse is also true: if the volume is $0$, the box must be flat. That gives a clean test for whether four points lie in one plane.
:::

:::theorem[Theorem 12.4.2 — Coplanarity Test]
Four points $A$, $B$, $C$, $D$ lie in a common plane (are **coplanar**) if and only if

$$
(\overrightarrow{AB}\times\overrightarrow{AC})\cdot\overrightarrow{AD}=0.
$$

Equivalently, the $3\times 3$ determinant whose rows are $\overrightarrow{AB}$, $\overrightarrow{AC}$, $\overrightarrow{AD}$ is zero. Three vectors are called coplanar when their triple scalar product is zero.
:::

Here is why, in plain words. Use $A$ as the corner and think of $\overrightarrow{AB}$, $\overrightarrow{AC}$, $\overrightarrow{AD}$ as the three edges of a parallelepiped. The triple product is the signed volume of that box, so the test says: the volume is zero exactly when the box has no thickness. If $D$ sits in the plane through $A$, $B$, $C$, then $\overrightarrow{AD}$ lies in that plane, and the vector $\overrightarrow{AB}\times\overrightarrow{AC}$ is perpendicular to the plane, hence perpendicular to $\overrightarrow{AD}$, so their dot product is $0$. If $D$ is off the plane, $\overrightarrow{AD}$ has some height above it, the dot product equals that height times the base area, and it cannot be $0$.

Two practical notes. It does not matter which of the four points you call $A$; any choice gives the same yes-or-no answer, although the number itself may change sign. And the test needs the determinant to be exactly zero, so an answer of $0$ is what you are hunting for, not a small number.

:::::example[Example 3.34 — Are These Four Points Coplanar?]
Determine whether $A(1,1,1)$, $B(-1,0,4)$, $C(0,2,1)$, and $D(2,-2,3)$ are coplanar.

::::answer[Answer]
**Answer:** Yes, the triple product is $0$, so the points are coplanar.

1. Take $A$ as the corner and form the three vectors out of it:

$$
\overrightarrow{AB}=\langle -1-1,\,0-1,\,4-1\rangle=\langle -2,-1,3\rangle,
$$

$$
\overrightarrow{AC}=\langle 0-1,\,2-1,\,1-1\rangle=\langle -1,1,0\rangle,
$$

$$
\overrightarrow{AD}=\langle 2-1,\,-2-1,\,3-1\rangle=\langle 1,-3,2\rangle.
$$

2. Put them in the rows of a determinant and expand along the top row:

$$
(\overrightarrow{AB}\times\overrightarrow{AC})\cdot\overrightarrow{AD}=\begin{vmatrix}-2&-1&3\\-1&1&0\\1&-3&2\end{vmatrix}
=(-2)\begin{vmatrix}1&0\\-3&2\end{vmatrix}-(-1)\begin{vmatrix}-1&0\\1&2\end{vmatrix}+3\begin{vmatrix}-1&1\\1&-3\end{vmatrix}.
$$

3. The minors:

$$
\begin{vmatrix}1&0\\-3&2\end{vmatrix}=(1)(2)-(0)(-3)=2,
$$

$$
\begin{vmatrix}-1&0\\1&2\end{vmatrix}=(-1)(2)-(0)(1)=-2,
$$

$$
\begin{vmatrix}-1&1\\1&-3\end{vmatrix}=(-1)(-3)-(1)(1)=3-1=2.
$$

4. Substitute:

$$
(-2)(2)-(-1)(-2)+(3)(2)=-4-2+6=0.
$$

5. The triple product is $0$, so the box has zero volume and the four points are **coplanar**.

6. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::

### Worked Examples — Cross Product

:::::example[Example 3.35 — Computing a Cross Product]
Compute $\vec{a}\times\vec{b}$ for $\vec{a}=\langle 2,3,-1\rangle$ and $\vec{b}=\langle 1,-2,4\rangle$.

::::answer[Answer]
**Answer:** $\vec{a}\times\vec{b}=\langle 10,-9,-7\rangle$.

1. Expand the determinant:

$$
\vec{a}\times\vec{b}=\hat{\imath}\begin{vmatrix}3&-1\\-2&4\end{vmatrix}-\hat{\jmath}\begin{vmatrix}2&-1\\1&4\end{vmatrix}+\hat{k}\begin{vmatrix}2&3\\1&-2\end{vmatrix}.
$$

$$
\hat{\imath}\text{-component}:\;(3)(4)-(-1)(-2)=12-2=10.
$$

$$
\hat{\jmath}\text{-component}:\;-[(2)(4)-(-1)(1)]=-(8+1)=-9.
$$

$$
\hat{k}\text{-component}:\;(2)(-2)-(3)(1)=-4-3=-7.
$$

$$
\vec{a}\times\vec{b}=\langle 10,-9,-7\rangle.
$$

2. *Verify orthogonality:* $\langle 10,-9,-7\rangle\cdot\langle 2,3,-1\rangle=20-27+7=0$. ✓
::::
:::::

:::::example[Example 3.36 — Area of a Parallelogram]
Find the area of the parallelogram with vertices $A(1,0,0)$, $B(2,3,1)$, $C(4,1,2)$, $D=A+\overrightarrow{AB}+\overrightarrow{AC}$.

::::answer[Answer]
**Answer:** Area $=3\sqrt{10}\approx9.49$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Let $\vec{u}=\overrightarrow{AB}=\langle 1,3,1\rangle$ and $\vec{v}=\overrightarrow{AC}=\langle 3,1,2\rangle$.

$$
\vec{u}\times\vec{v}=\langle(3)(2)-(1)(1),\;(1)(3)-(1)(2),\;(1)(1)-(3)(3)\rangle=\langle 5,1,-8\rangle.
$$

$$
\text{Area}=|\vec{u}\times\vec{v}|=\sqrt{25+1+64}=\sqrt{90}=3\sqrt{10}\approx9.49.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.37 — Area of a Parallelogram from Four Vertices]
Find the area of the parallelogram with vertices $A(0,0,0)$, $B(3,2,4)$, $C(5,1,4)$, $D(2,-1,0)$.

::::answer[Answer]
**Answer:** Area $=\sqrt{129}$.

1. Pick the corner $A$. Its two neighbors in the parallelogram are $B$ and $D$; $C$ is the far corner and is not needed (check: $\overrightarrow{AB}+\overrightarrow{AD}=\langle 5,1,4\rangle$ lands exactly on $C$). The two sides from $A$ are

$$
\overrightarrow{AB}=\langle 3,2,4\rangle,\qquad\overrightarrow{AD}=\langle 2,-1,0\rangle.
$$

2. Cross them, expanding along the top row:

$$
\overrightarrow{AB}\times\overrightarrow{AD}=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\3&2&4\\2&-1&0\end{vmatrix}
=\begin{vmatrix}2&4\\-1&0\end{vmatrix}\hat{\imath}-\begin{vmatrix}3&4\\2&0\end{vmatrix}\hat{\jmath}+\begin{vmatrix}3&2\\2&-1\end{vmatrix}\hat{k}.
$$

3. The minors:

$$
\begin{vmatrix}2&4\\-1&0\end{vmatrix}=(2)(0)-(4)(-1)=0-(-4)=4,
$$

$$
\begin{vmatrix}3&4\\2&0\end{vmatrix}=(3)(0)-(4)(2)=-8,
$$

$$
\begin{vmatrix}3&2\\2&-1\end{vmatrix}=(3)(-1)-(2)(2)=-3-4=-7.
$$

4. So

$$
\overrightarrow{AB}\times\overrightarrow{AD}=4\hat{\imath}-(-8)\hat{\jmath}+(-7)\hat{k}=4\hat{\imath}+8\hat{\jmath}-7\hat{k}.
$$

5. The area is the length of this vector:

$$
A=\sqrt{4^2+8^2+(-7)^2}=\sqrt{16+64+49}=\sqrt{129}.
$$

6. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.38 — Normal Vector to a Plane]
Three points $P(1,0,0)$, $Q(0,1,0)$, $R(0,0,1)$ lie in a plane. Find a normal vector.

::::answer[Answer]
**Answer:** $\vec{n}=\langle 1,1,1\rangle$ (or any scalar multiple).

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. Two vectors in the plane: $\overrightarrow{PQ}=\langle -1,1,0\rangle$ and $\overrightarrow{PR}=\langle -1,0,1\rangle$.

$$
\vec{n}=\overrightarrow{PQ}\times\overrightarrow{PR}=\langle(1)(1)-(0)(0),\;(0)(-1)-(-1)(1),\;(-1)(0)-(1)(-1)\rangle=\langle 1,1,1\rangle.
$$

3. Check: $\langle 1,1,1\rangle\cdot\langle -1,1,0\rangle=0$. ✓
::::
:::::

:::::example[Example 3.39 — Triangle Area and a Unit Normal]
Find the area of the triangle with vertices $P(1,-1,2)$, $Q(2,0,-1)$, $R(0,2,1)$, and find a unit vector perpendicular to the plane $PQR$.

::::answer[Answer]
**Answer:** Area $=2\sqrt{6}$. A unit vector perpendicular to the plane is $\dfrac{-2\hat{\imath}-\hat{\jmath}-\hat{k}}{\sqrt{6}}$ (its negative works equally well).

1. Build two edge vectors out of $P$ by subtracting $P$'s coordinates from each other point:

$$
\overrightarrow{PR}=\langle 0-1,\,2-(-1),\,1-2\rangle=\langle -1,3,-1\rangle,
$$

$$
\overrightarrow{PQ}=\langle 2-1,\,0-(-1),\,-1-2\rangle=\langle 1,1,-3\rangle.
$$

2. Cross them, with $\overrightarrow{PR}$ in the middle row:

$$
\overrightarrow{PR}\times\overrightarrow{PQ}=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\-1&3&-1\\1&1&-3\end{vmatrix}
=\begin{vmatrix}3&-1\\1&-3\end{vmatrix}\hat{\imath}-\begin{vmatrix}-1&-1\\1&-3\end{vmatrix}\hat{\jmath}+\begin{vmatrix}-1&3\\1&1\end{vmatrix}\hat{k}.
$$

3. The minors:

$$
\begin{vmatrix}3&-1\\1&-3\end{vmatrix}=(3)(-3)-(-1)(1)=-9-(-1)=-8,
$$

$$
\begin{vmatrix}-1&-1\\1&-3\end{vmatrix}=(-1)(-3)-(-1)(1)=3-(-1)=4,
$$

$$
\begin{vmatrix}-1&3\\1&1\end{vmatrix}=(-1)(1)-(3)(1)=-1-3=-4.
$$

4. Assemble, remembering the minus sign on the $\hat{\jmath}$ term:

$$
\overrightarrow{PR}\times\overrightarrow{PQ}=-8\hat{\imath}-4\hat{\jmath}-4\hat{k}.
$$

5. Its length is

$$
|\overrightarrow{PR}\times\overrightarrow{PQ}|=\sqrt{64+16+16}=\sqrt{96}=\sqrt{16\cdot 6}=4\sqrt{6}.
$$

6. *Triangle area.* The parallelogram on $\overrightarrow{PR}$ and $\overrightarrow{PQ}$ has area $4\sqrt{6}$, and the triangle is half of it:

$$
A_\Delta=\tfrac12\,|\overrightarrow{PR}\times\overrightarrow{PQ}|=\tfrac12\cdot 4\sqrt{6}=2\sqrt{6}.
$$

7. *Unit normal.* The cross product is perpendicular to both edges, hence to the plane. Divide by its length:

$$
\frac{-8\hat{\imath}-4\hat{\jmath}-4\hat{k}}{4\sqrt{6}}=\frac{-2\hat{\imath}-\hat{\jmath}-\hat{k}}{\sqrt{6}}.
$$

8. The opposite vector $\dfrac{2\hat{\imath}+\hat{\jmath}+\hat{k}}{\sqrt{6}}$ is perpendicular too; a plane has two unit normals, one on each side.

9. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.40 — Parallelepiped Volume]
Find the volume of the parallelepiped with edges $\vec{a}=\langle 1,2,0\rangle$, $\vec{b}=\langle 0,1,2\rangle$, $\vec{c}=\langle 2,0,1\rangle$.

::::answer[Answer]
**Answer:** $V=9$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Compute the scalar triple product:

$$
V=\left|\begin{vmatrix}1&2&0\\0&1&2\\2&0&1\end{vmatrix}\right|=|1(1-0)-2(0-4)+0|=|1+8|=9.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### Why the Half-Factor Belongs Only to Triangles

Let the neighboring edges of a parallelogram be $\vec u$ and $\vec v$. If the angle between them is $\theta$, the height relative to base $|\vec u|$ is $|\vec v|\sin\theta$. Consequently
$$
A_{\text{parallelogram}}=|\vec u|\bigl(|\vec v|\sin\theta\bigr)=|\vec u\times\vec v|.
$$
A diagonal splits a parallelogram into two equal-area triangles, so a triangle determined by two edges from a common vertex has area $\frac12|\vec u\times\vec v|$. The cross product itself does **not** change between the two questions; only the area multiplier changes. For a fast arithmetic check, take $\vec u=\langle3,0,0\rangle$ and $\vec v=\langle1,2,0\rangle$: their cross product is $\langle0,0,6\rangle$, giving parallelogram area $6$ and triangle area $3$. A claimed triangle area of $6$ is exactly the common mistake of forgetting the half-factor.

:::callout-pitfall
Watch out for:

- **Minus sign on $\hat{\jmath}$.** The middle cofactor carries a negative sign: $-\hat{\jmath}(a_1 b_3-a_3 b_1)$. Forgetting it is the #1 cross product error.
- **Anti-commutativity.** $\vec{b}\times\vec{a}=-\vec{a}\times\vec{b}$. If the problem gives $\vec{b}\times\vec{a}$, flip the sign of your $\vec{a}\times\vec{b}$ answer.
- **Cross product only in 3D.** There's no cross product in 2D (well, the 2D "cross product" gives a scalar — the $\hat{k}$ component — but it's not a full 3D vector).
:::

:::::problem[Problem 3.21 — Practice calculation]{difficulty=easy}
Compute $\langle 1,0,0\rangle\times\langle 0,1,0\rangle$.

::::solution[Solution]
**Answer:** $\langle0,0,1\rangle$.

1. **Recognize the standard basis vectors.** The first vector is $\hat\imath=\langle1,0,0\rangle$ and the second is $\hat\jmath=\langle0,1,0\rangle$. Their order matters because a cross product changes sign if its operands are reversed.

2. **Use the component cross-product formula.** For $\vec a\times\vec b$, the components are $\langle a_2b_3-a_3b_2,\;a_3b_1-a_1b_3,\;a_1b_2-a_2b_1\rangle$. Substituting gives

$$
\langle0(0)-0(1),\;0(0)-1(0),\;1(1)-0(0)\rangle
=\langle0,0,1\rangle.
$$

3. **Check the direction.** The right-hand rule sends positive $x$ crossed with positive $y$ toward positive $z$, or $\hat\imath\times\hat\jmath=\hat k$. Thus the cross product is $\langle0,0,1\rangle$.
::::
:::::

:::::problem[Problem 3.22 — Practice calculation]{difficulty=standard}
Compute $\langle 2,-1,3\rangle\times\langle 1,2,-1\rangle$.

::::solution[Solution]
**Answer:** $\langle-5,5,5\rangle$.

1. **Use the cross-product determinant** because the question asks for a vector perpendicular to the two given directions. Write the input vectors in their original order:

$$
\vec a\times\vec b=
\begin{vmatrix}\hat\imath&\hat\jmath&\hat k\\2&-1&3\\1&2&-1\end{vmatrix}.
$$

2. **Expand with signs $+,-,+$.** The $x$ component is $(-1)(-1)-3(2)=1-6=-5$. The $y$ component is $-\big(2(-1)-3(1)\big)=-(-2-3)=5$. The $z$ component is $2(2)-(-1)(1)=4+1=5$.

3. **Collect the components.** Hence $\vec a\times\vec b=\langle-5,5,5\rangle$.

4. **Check perpendicularity.** The dot products are $2(-5)+(-1)(5)+3(5)=-10-5+15=0$ and $1(-5)+2(5)+(-1)(5)=-5+10-5=0$. Thus the answer is perpendicular to each original vector.
::::
:::::

:::::problem[Problem 3.23 — Plane equation and normal]{difficulty=standard}
Find a unit normal to the plane containing $A(0,0,0)$, $B(1,2,0)$, $C(0,1,3)$.

::::solution[Solution]
**Answer:** $\dfrac1{\sqrt{46}}\langle6,-3,1\rangle$ (or its negative).

1. **Create two directions in the plane.** Since $A,B,C$ are three noncollinear points, $\overrightarrow{AB}$ and $\overrightarrow{AC}$ span the plane:

$$
\overrightarrow{AB}=\langle1-0,2-0,0-0\rangle=\langle1,2,0\rangle,
\quad\overrightarrow{AC}=\langle0,1,3\rangle.
$$

2. **Take their cross product for a normal.** Componentwise,

$$
\overrightarrow{AB}\times\overrightarrow{AC}
=\langle2(3)-0(1),\;0(0)-1(3),\;1(1)-2(0)\rangle
=\langle6,-3,1\rangle.
$$

3. **Normalize.** The normal is nonzero and has magnitude $\sqrt{6^2+(-3)^2+1^2}=\sqrt{46}$. Divide by that length to obtain the stated unit normal.

4. **Check.** Its unscaled dot products are $6-6+0=0$ with $\overrightarrow{AB}$ and $0-3+3=0$ with $\overrightarrow{AC}$. Its squared normalized length is $46/46=1$. Hence it is a unit normal to the plane.
::::
:::::

:::::problem[Problem 3.24 — Angle from a dot product]{difficulty=standard}
Find the area of the triangle with vertices $P(1,1,0)$, $Q(2,3,1)$, $R(0,2,2)$.

::::solution[Solution]
**Answer:** $\dfrac{3\sqrt3}{2}$ square units.

1. **Use the triangle cross-product area formula.** Two side vectors starting at the same vertex form a parallelogram of area $|\vec u\times\vec v|$. The requested triangle occupies half of that area. The vertices are distinct and noncollinear here.

2. **Construct the sides from $P$.** Subtract $P=(1,1,0)$ from the other two vertices:

$$
\overrightarrow{PQ}=\langle2-1,3-1,1-0\rangle=\langle1,2,1\rangle,
$$
$$
\overrightarrow{PR}=\langle0-1,2-1,2-0\rangle=\langle-1,1,2\rangle.
$$

3. **Take the cross product.** Its components are $2(2)-1(1)=3$, $1(-1)-1(2)=-3$, and $1(1)-2(-1)=3$. Thus $\overrightarrow{PQ}\times\overrightarrow{PR}=\langle3,-3,3\rangle$.

4. **Take half its length and check.** The magnitude is $\sqrt{9+9+9}=\sqrt{27}=3\sqrt3$. Hence $A=\frac12(3\sqrt3)=3\sqrt3/2$. The nonzero cross product confirms a nondegenerate triangle.
::::
:::::

:::::problem[Problem 3.25 — Practice calculation]{difficulty=challenge}
Prove that $|\vec{a}\times\vec{b}|^2+(\vec{a}\cdot\vec{b})^2=|\vec{a}|^2|\vec{b}|^2$ using $\sin^2\theta+\cos^2\theta=1$.

::::solution[Solution]
**Answer:** $|\vec a\times\vec b|^2+(\vec a\cdot\vec b)^2=|\vec a|^2|\vec b|^2$.

1. **Use the geometric product identities.** If both vectors are nonzero, they have an angle $\theta$ between them. The dot-product identity is $\vec a\cdot\vec b=|\vec a||\vec b|\cos\theta$, and the cross-product magnitude identity is $|\vec a\times\vec b|=|\vec a||\vec b|\sin\theta$.

2. **Square each expression separately.** Squaring eliminates the sign of the cosine and gives

$$
|\vec a\times\vec b|^2=|\vec a|^2|\vec b|^2\sin^2\theta,
$$
$$
(\vec a\cdot\vec b)^2=|\vec a|^2|\vec b|^2\cos^2\theta.
$$

3. **Add and factor.** The sum is $|\vec a|^2|\vec b|^2(\sin^2\theta+\cos^2\theta)$, which equals $|\vec a|^2|\vec b|^2$ because $\sin^2\theta+\cos^2\theta=1$.

4. **Check the zero-vector case.** If either vector is zero, both sides are zero, so the identity still holds. Therefore the claimed identity is proven for all vectors in $\mathbb R^3$.
::::
:::::

:::::problem[Problem 3.26 — Practice calculation]{difficulty=easy}
Find $\langle1,0,1\rangle\times\langle0,2,0\rangle$.

::::solution[Solution]
**Answer:** $\langle-2,0,2\rangle$.

1. **Use the component cross-product formula** to preserve the specified order. For $\vec a=\langle1,0,1\rangle$ and $\vec b=\langle0,2,0\rangle$, compute the $x$, $y$, then $z$ components with the pattern $(a_2b_3-a_3b_2,\;a_3b_1-a_1b_3,\;a_1b_2-a_2b_1)$.

2. **Calculate each component.** The $x$ component is $0(0)-1(2)=-2$. The $y$ component is $1(0)-1(0)=0$. The $z$ component is $1(2)-0(0)=2$.

3. **Combine the result.** Therefore $\vec a\times\vec b=\langle-2,0,2\rangle$.

4. **Check both dot products.** $\langle-2,0,2\rangle\cdot\langle1,0,1\rangle=-2+0+2=0$ and $\langle-2,0,2\rangle\cdot\langle0,2,0\rangle=0$. The result is perpendicular to both input vectors, as a cross product must be.
::::
:::::

:::::problem[Problem 3.27 — Angle from a dot product]{difficulty=standard}
**Test 2 version B style.** Find the *exact* area of triangle $P(4,-2,3)$, $Q(8,7,-2)$, $R(5,9,1)$.

::::solution[Solution]
**Answer:** $\dfrac{\sqrt{2603}}{2}$ square units.

1. **Select the cross-product area formula.** A triangle with adjacent sides $\overrightarrow{PQ}$ and $\overrightarrow{PR}$ has area $\frac12|\overrightarrow{PQ}\times\overrightarrow{PR}|$.

2. **Subtract coordinates from the same starting vertex.** Here

$$
\overrightarrow{PQ}=\langle8-4,7-(-2),-2-3\rangle=\langle4,9,-5\rangle,
$$
$$
\overrightarrow{PR}=\langle5-4,9-(-2),1-3\rangle=\langle1,11,-2\rangle.
$$

3. **Calculate the cross product componentwise.** The result is

$$
\langle9(-2)-(-5)(11),\;(-5)(1)-4(-2),\;4(11)-9(1)\rangle
=\langle37,3,35\rangle.
$$

4. **Compute the exact area.** Square and add: $37^2=1369$, $3^2=9$, and $35^2=1225$, totaling $2603$. Thus $A=\frac12\sqrt{2603}$.

5. **Check the geometry.** The cross product is nonzero, so the three vertices do not lie on one line. The factor $1/2$ correctly converts parallelogram area to triangle area. No decimal approximation is needed.
::::
:::::

:::callout-key[Test 2 scoring path: exact cross-product area]
Both released versions ask for an area from coordinates. First name the common vertex. Write the two edge vectors from that vertex explicitly. Next show a three-column determinant and the **plus, minus, plus** cofactor signs. Square all three cross-product components before taking the root. The answer is $|\vec u\times\vec v|$ for a parallelogram and **half** that for a triangle. Version B explicitly says *exact*: leave the radical and do not replace it with a decimal.
:::

For an order check, compute the dot product of your cross product with both input edges. Each should be zero, because the result is perpendicular to both. This is not extra algebra for its own sake: a single wrong sign in the middle component almost always breaks one of these zero checks. Remember that reversing the edge order changes the normal vector's sign but **never changes the area**, because length is nonnegative.

\n\nA determinant can be correct while the requested area is not. The cross product produces a vector, so the final scalar is its **length**, not a coordinate or its signed components. When three vertices name a triangle, that length counts the doubled triangle. A plane equation uses the same cross product differently: keep its three components as coefficients of $x$, $y$ and $z$.\n
## 12.5 Lines and Planes in Space

:::callout-key[Test 2 priority]
Versions A and B ask for a vector **and** parametric line equation and a component plane equation. A complete plane answer must display two independent in-plane vectors, their cross product as a normal, and the substituted point-normal equation before the simplified form. Optional distance/angle cases below are useful extensions but are **not on the released Test 2 keys**.
:::

:::callout-connect
📺 Watch before this section

“Equations of lines and planes in space | Multivariable Calculus” — Khan Academy
:::

:::callout-intuition
Intuition first.

In 2D you describe a line with one equation $ax+by=c$. In 3D a single equation gives a **plane**, not a line. To pin down a 3D line you need either two equations (the intersection of two planes) or a smarter parameterization. The parametric approach is much cleaner: start at a known point $P_0$, add a multiple of a direction vector $\vec{v}$, and as the parameter $t$ ranges over all reals you trace out the entire line. For planes, a point and a **normal** vector (perpendicular to the plane) determine the plane completely — that's where the cross product from §12.4 pays off.
:::

### Equations of a Line in 3D

A line through point $P_0(x_0,y_0,z_0)$ in direction $\vec{v}=\langle a,b,c\rangle$ has three equivalent forms:

:::definition
Definition 12.5.1 — Three Forms of a Line

**Vector equation:**

$$
\vec{r}(t)=\vec{r}_0+t\vec{v}=\langle x_0+at,\;y_0+bt,\;z_0+ct\rangle,\qquad t\in\mathbb{R}.
$$

 **Parametric equations:**

$$
x=x_0+at,\quad y=y_0+bt,\quad z=z_0+ct.
$$

 **Symmetric equations** (when $a,b,c\ne 0$):

$$
\frac{x-x_0}{a}=\frac{y-y_0}{b}=\frac{z-z_0}{c}.
$$

 If one direction component is zero (say $b=0$), replace that fraction with the equation $y=y_0$.
:::

The direction vector is not unique — any nonzero scalar multiple works. The parametric equations are the most computationally useful form.

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 301 300" width="301" height="300" role="img" aria-label="The line through P0(1,2,1) parallel to the vector v = &lt;2,1,2>, with the position vectors r0 and r drawn dashed">
<path class="fig-axis" d="M118.53 202.28L30 270"/>
<path class="fig-axis" d="M118.53 202.28L270.56 235.15"/>
<path class="fig-axis" d="M118.53 202.28L118.53 30"/>
<path class="fig-guide" d="M137.78 187.55L118.53 202.28"/>
<path class="fig-guide" d="M82.34 194.45L118.53 202.28"/>
<path class="fig-guide" d="M118.53 239.73L118.53 202.28"/>
<path class="fig-curve-alt" d="M173.75 229.07L173.59 226.58L173.44 224.08L173.29 221.59L173.14 219.1L172.99 216.61L172.83 214.11L172.68 211.62L172.53 209.13L172.38 206.63L172.23 204.14L172.07 201.65L171.92 199.15L171.77 196.66L171.62 194.17L171.47 191.68L171.31 189.18L171.16 186.69L171.01 184.2L170.86 181.7L170.7 179.21L170.55 176.72L170.4 174.23L170.25 171.73L170.1 169.24L169.94 166.75L169.79 164.25L169.64 161.76L169.49 159.27L169.34 156.77L169.18 154.28L169.03 151.79L168.88 149.3L168.73 146.8L168.58 144.31L168.42 141.82L168.27 139.32L168.12 136.83L167.97 134.34L167.82 131.85L167.66 129.35"/>
<path class="fig-axis" d="M30.01 269.99L30 270L30.02 270"/>
<path class="fig-axis" d="M270.54 235.16L270.56 235.15L270.54 235.14"/>
<path class="fig-axis" d="M118.54 30.02L118.53 30L118.52 30.02"/>
<path class="fig-guide" d="M118.53 202.28L171.68 195.2"/>
<path class="fig-axis" d="M163.73 199.86L171.68 195.2L162.78 192.79"/>
<path class="fig-guide" d="M118.53 202.28L167.66 129.35"/>
<path class="fig-axis" d="M165.87 138.4L167.66 129.35L159.95 134.41"/>
<path class="fig-curve" d="M171.68 195.2L169.75 163.51"/>
<path class="fig-arrow" d="M169.38 157.57L173.5 165.84L166.31 166.28Z"/>
<circle class="fig-point" cx="171.68" cy="195.2" r="3.2"/>
<circle class="fig-point" cx="167.66" cy="129.35" r="3.2"/>
<text class="fig-label-em" x="19.06" y="279.08">x</text>
<text class="fig-label-em" x="277.33" y="240.27">y</text>
<text class="fig-label-em" x="115.53" y="23">z</text>
<text class="fig-label-em" x="179.68" y="209.2">P₀(1, 2, 1)</text>
<text class="fig-label-em" x="173.66" y="125.35">P(x, y, z)</text>
<text class="fig-label-em" x="177.38" y="165.57">v</text>
<text class="fig-label" x="131.11" y="204.74">r₀</text>
<text class="fig-label" x="156.01" y="166.52">r</text>
</svg>
<figcaption>The line through $P_0(1,2,1)$ parallel to $\mathbf{v}=\langle 2,1,2\rangle$ is $\mathbf{r}(t)=\mathbf{r}_0+t\mathbf{v}$: start at $P_0$ and move any multiple of $\mathbf{v}$; here $x=1+2t$, $y=2+t$, $z=1+2t$.</figcaption>
</figure>

For every line problem, first locate one point and one nonzero direction vector. A point sets the location; a direction determines the line.

Three sources of line direction: two given points supply $\overrightarrow{AB}$; a parallel line supplies its coefficients of $t$; perpendicularity to two vectors supplies their cross product. Each route leads to the same equation $\vec r=\vec r_0+t\vec v$.

:::::example[Example 3.41 — Line Through a Point, Parallel to a Vector]
Find a vector equation and parametric equations for the line through $(3,-4,-1)$ parallel to $\mathbf i+\mathbf j+\mathbf k$.

::::answer[Answer]
**Answer:** $\vec r(t)=\langle 3,-4,-1\rangle+t\langle 1,1,1\rangle$, that is $x=3+t,\;y=-4+t,\;z=-1+t$.

1. Everything we need is given. The point is $P_0=(3,-4,-1)$, so $\vec r_0=\langle 3,-4,-1\rangle$. The direction is $\vec v=\langle 1,1,1\rangle$. The vector equation is $\vec r(t)=\vec r_0+t\vec v$:

$$
\vec r(t)=\langle 3,-4,-1\rangle+t\langle 1,1,1\rangle=\langle 3+t,\;-4+t,\;-1+t\rangle.
$$

2. Reading off the three components gives the parametric equations

$$
x=3+t,\qquad y=-4+t,\qquad z=-1+t,\qquad -\infty\lt t\lt\infty.
$$

3. At $t=0$ we are at the given point $(3,-4,-1)$, which is a good sanity check.
::::
:::::

:::::example[Example 3.42 — Line Through Two Points]
Find a vector equation and parametric equations for the line through $(1,2,-1)$ and $(-1,0,1)$.

::::answer[Answer]
**Answer:** $\vec r(t)=\langle 1,2,-1\rangle+t\langle -2,-2,2\rangle$, that is $x=1-2t,\;y=2-2t,\;z=-1+2t$.

1. We have two points but no direction, so we manufacture one: subtract the first point from the second. Component by component,

$$
\vec v=\langle -1-1,\;0-2,\;1-(-1)\rangle=\langle -2,-2,2\rangle.
$$

2. Use the first point $P_0=(1,2,-1)$ as the starting point:

$$
\vec r(t)=\langle 1,2,-1\rangle+t\langle -2,-2,2\rangle,
$$

$$
x=1-2t,\qquad y=2-2t,\qquad z=-1+2t.
$$

3. Check that both points really lie on it. At $t=0$ we get $(1,2,-1)$. At $t=1$ we get $(1-2,\,2-2,\,-1+2)=(-1,0,1)$, the second point.

4. The answer is not unique. Dividing the direction by $-2$ gives $\langle 1,1,-1\rangle$, and $x=1+t,\;y=2+t,\;z=-1-t$ is exactly the same line described with a different speed and a different sign of $t$. Starting from the second point instead would also give a correct answer. On a test, if your answer looks different from the key's, check whether your direction is a scalar multiple of theirs and whether your point satisfies their equations before deciding you are wrong.
::::
:::::

:::::example[Example 3.43 — Line Parallel to Another Line]
Find parametric equations for the line through $(3,-2,1)$ that is parallel to the line $x=1+2t,\;y=2-t,\;z=3t$.

::::answer[Answer]
**Answer:** $x=3+2t,\;y=-2-t,\;z=1+3t$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Parallel lines share a direction vector. In parametric form the direction is the list of coefficients of $t$: from $x=1+2t$ we read $2$, from $y=2-t$ we read $-1$, from $z=3t$ we read $3$. So $\vec v=\langle 2,-1,3\rangle$. The starting point $(1,2,0)$ of the given line is irrelevant, because we are told to pass through $(3,-2,1)$ instead. Therefore

$$
x=3+2t,\qquad y=-2-t,\qquad z=1+3t.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::example[Example 3.44 — Line Perpendicular to Two Vectors]
Find parametric equations for the line through $(2,4,5)$ perpendicular to $\mathbf a=\mathbf i+2\mathbf j+3\mathbf k$ and $\mathbf b=3\mathbf i+4\mathbf j+5\mathbf k$.

::::answer[Answer]
**Answer:** $x=2+t,\;y=4-2t,\;z=5+t$.

1. The line must be perpendicular to both $\mathbf a$ and $\mathbf b$, and the cross product $\mathbf a\times\mathbf b$ is the vector perpendicular to both, so we use it as the direction. Expanding the determinant along the top row,

$$
\mathbf a\times\mathbf b=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\1&2&3\\3&4&5\end{vmatrix}
=(2\cdot5-3\cdot4)\mathbf i-(1\cdot5-3\cdot3)\mathbf j+(1\cdot4-2\cdot3)\mathbf k=-2\mathbf i+4\mathbf j-2\mathbf k.
$$

2. Any nonzero multiple of this vector points along the same line, so we clean it up by multiplying by $-\tfrac12$:

$$
\vec v=\langle 1,-2,1\rangle.
$$

3. Check with dot products, since perpendicular means dot product zero: $\vec v\cdot\mathbf a=1-4+3=0$ and $\vec v\cdot\mathbf b=3-8+5=0$. Both vanish, so the direction is right. Through $(2,4,5)$:

$$
x=2+t,\qquad y=4-2t,\qquad z=5+t.
$$

4. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

### Do Two Lines Intersect, Run Parallel, or Miss Each Other?

In a plane, two lines that are not parallel always meet. In space they do not. Two lines can cross at one point, they can be parallel, or they can be **skew**: not parallel, and yet never meeting, like a road passing over a motorway on a bridge. Deciding which case you are in is a standard test question, and it is a fixed three-stage procedure.

:::callout-key[Method — Classifying Two Lines]
Take line 1 with direction $\vec v_1$ and line 2 with direction $\vec v_2$.

**Step 1. Are the directions parallel?** Check whether $\vec v_1$ is a scalar multiple of $\vec v_2$. If it is, the lines are parallel (or identical, if a point of one lies on the other). Stop.

**Step 2. If not parallel, set the coordinates equal, using different parameters.** Call the parameter of line 1 $t$ and the parameter of line 2 $s$. Setting $x_1=x_2$, $y_1=y_2$, $z_1=z_2$ gives three equations in the two unknowns $t$ and $s$.

**Step 3. Solve two of the equations, then test the third.** Solve any two of the three equations for $t$ and $s$. Substitute those values into the equation you left out. If it holds, the lines intersect, and plugging $t$ into line 1 (or $s$ into line 2) gives the point. If it fails, the lines are skew.
:::

Use separate parameters $t$ and $s$ because an intersection point can occur at different parameter values on the two lines. Two coordinate equations determine candidates; the third must also hold. Otherwise the lines are skew.

:::::example[Example 3.45 — Do Two Lines Intersect?]
Determine whether the lines $x=2t+1,\;y=3t+2,\;z=4t+3$ and $x=s+2,\;y=2s+4,\;z=-4s-1$ intersect, and if so find the point.

::::answer[Answer]
**Answer:** Yes, they intersect at $(1,2,3)$.

1. The directions are $\langle 2,3,4\rangle$ and $\langle 1,2,-4\rangle$. The first components would need a factor of $2$ to turn the second vector into the first, but the second components would need a factor of $\tfrac32$, so neither vector is a multiple of the other and the lines are not parallel. Now set the coordinates equal, with different parameters:

$$
2t+1=s+2,\qquad 3t+2=2s+4,\qquad 4t+3=-4s-1.
$$

2. Solve the first two. From the first equation, $s=2t-1$. Substitute this into the second equation:

$$
3t+2=2(2t-1)+4=4t-2+4=4t+2.
$$

3. Subtracting $3t+2$ from both sides gives $0=t$, so $t=0$, and then $s=2(0)-1=-1$.

4. Now test the third equation, which we have not used. Left side: $4(0)+3=3$. Right side: $-4(-1)-1=4-1=3$. They agree, so the lines intersect.

5. To find the point, put $t=0$ into the first line: $(2\cdot0+1,\;3\cdot0+2,\;4\cdot0+3)=(1,2,3)$. As a check, $s=-1$ in the second line gives $(-1+2,\;-2+4,\;4-1)=(1,2,3)$, the same point.
::::
:::::

### Equations of a Plane

:::definition
Definition 12.5.2 — Equation of a Plane

A plane through $P_0(x_0,y_0,z_0)$ with normal vector $\vec{n}=\langle a,b,c\rangle$ satisfies

$$
a(x-x_0)+b(y-y_0)+c(z-z_0)=0,
$$

 or in standard form $ax+by+cz=d$ where $d=ax_0+by_0+cz_0$.
:::

Geometric reason: any point $P(x,y,z)$ lies in the plane iff $\overrightarrow{P_0P}$ is perpendicular to $\vec{n}$, i.e. $\vec{n}\cdot\overrightarrow{P_0P}=0$, which gives the formula above.

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 320 272" width="320" height="272" role="img" aria-label="A plane through the point P0 with a normal vector n standing perpendicular to it, and a vector in the plane">
<path class="fig-fill" d="M290 186.57L97.11 242.4L30 85.83L222.89 30Z"/>
<path class="fig-gridline" d="M290 186.57L222.89 30"/>
<path class="fig-gridline" d="M290 186.57L97.11 242.4"/>
<path class="fig-gridline" d="M241.78 200.53L174.67 43.96"/>
<path class="fig-gridline" d="M273.22 147.43L80.33 203.26"/>
<path class="fig-gridline" d="M193.55 214.49L126.45 57.91"/>
<path class="fig-gridline" d="M256.45 108.29L63.55 164.12"/>
<path class="fig-gridline" d="M145.33 228.45L78.22 71.87"/>
<path class="fig-gridline" d="M239.67 69.14L46.78 124.97"/>
<path class="fig-gridline" d="M97.11 242.4L30 85.83"/>
<path class="fig-gridline" d="M222.89 30L30 85.83"/>
<path class="fig-axis" d="M290 186.57L97.11 242.4L30 85.83L222.89 30L290 186.57"/>
<path class="fig-axis" d="M170.23 127.63L148.92 122.14L138.69 130.71"/>
<path class="fig-curve-alt" d="M160 136.2L86.88 117.36"/>
<path class="fig-curve-alt" d="M96 116.03L86.88 117.36L94.22 122.94"/>
<path class="fig-curve" d="M160 136.2L220.23 85.74"/>
<path class="fig-arrow" d="M224.79 81.92L220.59 90.14L215.97 84.62Z"/>
<circle class="fig-point" cx="160" cy="136.2" r="3.2"/>
<circle class="fig-point" cx="86.88" cy="117.36" r="3.2"/>
<text class="fig-label-em" x="142" y="150.2">P₀</text>
<text class="fig-label-em" x="92.88" y="120.36">P</text>
<text class="fig-label-em" x="230.79" y="79.92">n</text>
<text class="fig-label" x="115.44" y="142.78">r − r₀</text>
</svg>
<figcaption>The plane through $P_0$ with normal $\mathbf{n}$ is the set of points $P$ for which $\overrightarrow{P_0P}$ is perpendicular to $\mathbf{n}$, that is $\mathbf{n}\cdot(\mathbf{r}-\mathbf{r}_0)=0$; the normal stands at right angles to every direction lying in the plane.</figcaption>
</figure>

The whole plane is described by one fact: every vector lying in the plane is perpendicular to the normal $\vec n$. So to write a plane you need a point and a normal, and the only real work is finding the normal. If the normal is given, you are done at once. If the plane is described by three points, or by a point and a line, the normal is a cross product of two vectors that lie in the plane. The next four lecture examples run through those cases, and then the fourth tells you where a line pierces a plane.

:::::example[Example 3.46 — Plane Through a Point with a Given Normal]
Find the component equation of the plane through $(0,2,-1)$ normal to $3\mathbf i-2\mathbf j-\mathbf k$.

::::answer[Answer]
**Answer:** $3x-2y-z=-3$.

1. The normal is $\vec n=\langle 3,-2,-1\rangle$ and the point is $P_0=(0,2,-1)$. Substitute into $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$:

$$
3(x-0)-2(y-2)-1\bigl(z-(-1)\bigr)=0.
$$

2. Distribute, being careful with the two negatives:

$$
3x-2y+4-z-1=0\quad\Longrightarrow\quad 3x-2y-z=-3.
$$

3. Check with $D=Ax_0+By_0+Cz_0=3(0)-2(2)-1(-1)=-4+1=-3$, which matches the right-hand side.
::::
:::::

:::::example[Example 3.47 — Plane Through Three Points]
Find the component equation of the plane through $P(1,1,-1)$, $Q(2,0,2)$ and $R(0,-2,1)$.

::::answer[Answer]
**Answer:** $7x-5y-4z=6$.

1. Two vectors that lie in the plane are

$$
\overrightarrow{PQ}=\langle 2-1,\;0-1,\;2-(-1)\rangle=\langle 1,-1,3\rangle,\qquad
\overrightarrow{PR}=\langle 0-1,\;-2-1,\;1-(-1)\rangle=\langle -1,-3,2\rangle.
$$

2. The normal is their cross product:

$$
\vec n=\overrightarrow{PQ}\times\overrightarrow{PR}=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\1&-1&3\\-1&-3&2\end{vmatrix}
=\bigl((-1)(2)-3(-3)\bigr)\mathbf i-\bigl(1\cdot2-3(-1)\bigr)\mathbf j+\bigl(1(-3)-(-1)(-1)\bigr)\mathbf k.
$$

3. Working out each bracket: the $\mathbf i$ coefficient is $-2+9=7$; the $\mathbf j$ coefficient is $2+3=5$, which enters with a minus sign, giving $-5$; the $\mathbf k$ coefficient is $-3-1=-4$. So $\vec n=\langle 7,-5,-4\rangle$.

4. Use the point $P(1,1,-1)$:

$$
7(x-1)-5(y-1)-4(z+1)=0\quad\Longrightarrow\quad 7x-5y-4z=7-5+4=6.
$$

5. Check all three points. $P$: $7-5+4=6$. $Q$: $14-0-8=6$. $R$: $0+10-4=6$. All give $6$, so the plane is right.
::::
:::::

:::::example[Example 3.48 — Plane Containing a Point and a Line]
Find the component equation of the plane through $A(2,4,5)$ that contains the line $x=5+t,\;y=1+3t,\;z=4t$.

::::answer[Answer]
**Answer:** $-3x+17y-12z=2$, equivalently $3x-17y+12z=-2$.

1. The plane contains the whole line, so it contains the line's direction, and it contains any vector joining a point of the line to $A$. The line passes through $B=(5,1,0)$ (at $t=0$) with direction $\vec v=\langle 1,3,4\rangle$. The vector from $A$ to $B$ is

$$
\overrightarrow{AB}=\langle 5-2,\;1-4,\;0-5\rangle=\langle 3,-3,-5\rangle.
$$

2. These two vectors lie in the plane and are not parallel, so their cross product is the normal:

$$
\vec n=\vec v\times\overrightarrow{AB}=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\1&3&4\\3&-3&-5\end{vmatrix}
=(-15+12)\mathbf i-(-5-12)\mathbf j+(-3-9)\mathbf k=\langle -3,17,-12\rangle.
$$

3. Through $A(2,4,5)$:

$$
-3(x-2)+17(y-4)-12(z-5)=0\quad\Longrightarrow\quad -3x+17y-12z=-6+68-60=2.
$$

4. Check that the whole line lies in the plane by substituting its parametric equations:

$$
-3(5+t)+17(1+3t)-12(4t)=-15-3t+17+51t-48t=2
$$

5. for every value of $t$, because the $t$ terms cancel: $-3+51-48=0$. So the line is in the plane, and $A$ is too by construction.

6. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::example[Example 3.49 — Where a Line Meets a Plane]
Find the point where the line $x=1-t,\;y=3t,\;z=1+t$ meets the plane $2x-y+3z=6$.

::::answer[Answer]
**Answer:** $\left(\tfrac32,-\tfrac32,\tfrac12\right)$, at $t=-\tfrac12$.

1. A point on the line has the form $(1-t,\,3t,\,1+t)$ for some $t$. It is also on the plane exactly when those coordinates satisfy the plane's equation, so substitute them in:

$$
2(1-t)-(3t)+3(1+t)=6.
$$

2. Expand and collect:

$$
2-2t-3t+3+3t=6\quad\Longrightarrow\quad 5-2t=6\quad\Longrightarrow\quad -2t=1\quad\Longrightarrow\quad t=-\tfrac12.
$$

3. Put this $t$ back into the line:

$$
x=1-\left(-\tfrac12\right)=\tfrac32,\qquad y=3\left(-\tfrac12\right)=-\tfrac32,\qquad z=1+\left(-\tfrac12\right)=\tfrac12.
$$

4. Check in the plane: $2\left(\tfrac32\right)-\left(-\tfrac32\right)+3\left(\tfrac12\right)=3+\tfrac32+\tfrac32=6$. It works.
::::
:::::

:::callout-connect[Further geometry, outside the released Test 2 keys]
The source chapter also includes point-to-line distance, planes containing two lines, and distances/angles between lines and planes. All original examples and theorem labels are retained in **Beyond Test 2 — Further Line and Plane Geometry** at the end of this chapter, rather than letting nonexam methods crowd out the six written test questions.
:::

### Worked Examples — Lines and Planes

:::::example[Example 3.50 — Line Through Two Points]
Find the parametric and symmetric equations of the line through $A(1,2,-1)$ and $B(2,5,-3)$.

::::answer[Answer]
**Answer:** Parametric: $x=1+t,\;y=2+3t,\;z=-1-2t$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Direction vector: $\vec{v}=\overrightarrow{AB}=\langle 1,3,-2\rangle$. Using point $A$:

$$
x=1+t,\quad y=2+3t,\quad z=-1-2t.
$$

3. Symmetric form:

$$
\frac{x-1}{1}=\frac{y-2}{3}=\frac{z+1}{-2}.
$$

4. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::example[Example 3.51 — Do Two Lines Intersect?]
Line 1: $x=1+2t,\;y=-1+2t,\;z=2-t$. Line 2: $x=1+s,\;y=1-s,\;z=s$. Find the intersection, or show they are skew.

::::answer[Answer]
**Answer:** The lines are skew; they do not intersect.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Set equal (use different parameters $t$ and $s$ — same point, different travel times):

$$
1+2t=1+s\Rightarrow 2t=s.
$$

$$
-1+2t=1-s\Rightarrow -1+2t=1-2t\Rightarrow 4t=2\Rightarrow t=\tfrac{1}{2},\;s=1.
$$

3. Check $z$: $2-\tfrac{1}{2}=\tfrac{3}{2}$ vs $s=1$. These differ ($\tfrac{3}{2}\ne1$), so the lines are *skew* — they don't intersect and aren't parallel.
::::
:::::

:::::example[Example 3.52 — Plane Through Three Points]
Find the equation of the plane through $P(1,0,0)$, $Q(0,1,0)$, $R(0,0,1)$.

::::answer[Answer]
**Answer:** $x+y+z=1$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Two vectors in the plane: $\overrightarrow{PQ}=\langle -1,1,0\rangle$, $\overrightarrow{PR}=\langle -1,0,1\rangle$. Normal:

$$
\vec{n}=\overrightarrow{PQ}\times\overrightarrow{PR}=\langle(1)(1)-(0)(0),\;(0)(-1)-(-1)(1),\;(-1)(0)-(1)(-1)\rangle=\langle 1,1,1\rangle.
$$

3. Plane through $P(1,0,0)$ with normal $\langle 1,1,1\rangle$:

$$
1(x-1)+1(y-0)+1(z-0)=0\implies x+y+z=1.
$$

4. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::example[Example 3.53 — Distance from a Point to a Plane]
Find the distance from $P(1,-2,3)$ to the plane $2x-y+3z=4$.

::::answer[Answer]
**Answer:** $D=\frac{9}{\sqrt{14}}\approx2.41$.

1. For a point-to-plane distance, evaluate the plane equation at the point and divide the absolute value by the length of the plane normal.

2. Apply the calculation in the displayed expression.

$$
D=\frac{|2(1)-(-2)+3(3)-4|}{\sqrt{4+1+9}}=\frac{|2+2+9-4|}{\sqrt{14}}=\frac{9}{\sqrt{14}}\approx2.41.
$$

3. **Check.** A distance must be nonnegative; taking the absolute value removes any dependence on which side of the plane contains the point.
::::
:::::

:::::example[Example 3.54 — Angle Between Two Planes]
Find the angle between $x+2y-z=3$ and $2x-y+3z=1$.

::::answer[Answer]
**Answer:** $\theta\approx70.9°$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Normals: $\vec{n}_1=\langle 1,2,-1\rangle$, $\vec{n}_2=\langle 2,-1,3\rangle$.

$$
\cos\theta=\frac{|\vec{n}_1\cdot\vec{n}_2|}{|\vec{n}_1||\vec{n}_2|}=\frac{|2-2-3|}{\sqrt{6}\sqrt{14}}=\frac{3}{\sqrt{84}}=\frac{3}{2\sqrt{21}}.
$$

$$
\theta=\arccos\!\left(\frac{3}{2\sqrt{21}}\right)\approx\arccos(0.327)\approx70.9°.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::callout-pitfall
Watch out for:

- **Skew vs. parallel vs. intersecting.** Two lines in 3D can be skew (don't meet, not parallel). Always check both the direction-parallel test AND the intersection system — don't assume they must meet.
- **Point-to-plane distance needs absolute value.** $D=|ax_1+by_1+cz_1-d|/\sqrt{a^2+b^2+c^2}$. If you forget the absolute value you may get a negative "distance."
- **Direction vs. normal.** A line has a *direction* vector; a plane has a *normal* vector. Mixing these up produces an equation for the wrong geometric object.
:::

:::callout-pitfall
Two more slips from the distance formulas.

- **The order of the cross product in the point-to-line distance does not matter.** $|\overrightarrow{PS}\times\vec v|=|\vec v\times\overrightarrow{PS}|$, because swapping the factors only flips the sign of the vector, never its length. Do not reject an answer choice for having the factors in the "wrong" order.
- **Divide by the right length.** In the point-to-line distance the denominator is $|\vec v|$, the length of the direction vector. In the point-to-plane distance it is $|\vec n|$, the length of the normal. Dividing by $|\overrightarrow{PS}|$ is a common slip.
:::

:::::problem[Problem 3.28 — Line equation and direction]{difficulty=easy}
Write the parametric equations of the line through $(2,-1,3)$ with direction $\langle 1,2,-2\rangle$.

::::solution[Solution]
**Answer:** $x=2+t,\quad y=-1+2t,\quad z=3-2t$, for $t\in\mathbb R$.

1. **Use the point-direction form of a line.** A line through point $P=(x_0,y_0,z_0)$ with nonzero direction vector $\vec d=\langle a,b,c\rangle$ has vector equation $\vec r(t)=\langle x_0,y_0,z_0\rangle+t\langle a,b,c\rangle$.

2. **Substitute the given data.** Here $P=(2,-1,3)$ and $\vec d=\langle1,2,-2\rangle$ is nonzero, so

$$
\vec r(t)=\langle2,-1,3\rangle+t\langle1,2,-2\rangle
=\langle2+t,-1+2t,3-2t\rangle.
$$

3. **Read off the parametric coordinates.** Therefore $x=2+t$, $y=-1+2t$, and $z=3-2t$.

4. **Check point and direction.** At $t=0$, the equations give $(2,-1,3)$. Increasing $t$ by $1$ changes the coordinates by $\langle1,2,-2\rangle$. The equations consequently describe the requested line.
::::
:::::

:::::problem[Problem 3.29 — Plane equation and normal]{difficulty=easy}
Find the equation of the plane through $(1,2,3)$ with normal $\langle 3,-1,2\rangle$.

::::solution[Solution]
**Answer:** $3x-y+2z=7$.

1. **Use point-normal form.** A plane with nonzero normal $\vec n=\langle a,b,c\rangle$ through point $(x_0,y_0,z_0)$ satisfies $a(x-x_0)+b(y-y_0)+c(z-z_0)=0$. The given normal $\langle3,-1,2\rangle$ is nonzero.

2. **Substitute the components and point.** Using $(1,2,3)$ gives

$$
3(x-1)+(-1)(y-2)+2(z-3)=0.
$$

3. **Distribute every term and collect constants.** Expand to $3x-3-y+2+2z-6=0$. The constants sum to $-3+2-6=-7$, leaving $3x-y+2z-7=0$, or $3x-y+2z=7$.

4. **Check.** Inserting $(1,2,3)$ gives $3(1)-2+2(3)=3-2+6=7$. The coefficient vector is $\langle3,-1,2\rangle$, matching the required normal. Hence this is the plane equation.
::::
:::::

:::::problem[Problem 3.30 — Plane equation and normal]{difficulty=standard}
Find the plane through $A(1,1,0)$, $B(2,0,1)$, $C(0,2,1)$.

::::solution[Solution]
**Answer:** $x+y=2$.

1. **Find two directions lying in the plane.** Three noncollinear points determine a unique plane. Subtract the coordinates of $A=(1,1,0)$ from $B=(2,0,1)$ and $C=(0,2,1)$:

$$
\overrightarrow{AB}=\langle1,-1,1\rangle,
\qquad\overrightarrow{AC}=\langle-1,1,1\rangle.
$$

2. **Cross the two directions for a normal.** Componentwise,

$$
\overrightarrow{AB}\times\overrightarrow{AC}
=\langle(-1)(1)-(1)(1),\;(1)(-1)-(1)(1),\;(1)(1)-(-1)(-1)\rangle
=\langle-2,-2,0\rangle.
$$

This is nonzero, confirming noncollinearity. Dividing by $-2$ gives the simpler normal $\langle1,1,0\rangle$.

3. **Apply point-normal form at $A$.** The equation is $(x-1)+(y-1)+0(z-0)=0$, which simplifies to $x+y=2$.

4. **Check all three points.** Their $x+y$ values are $1+1=2$, $2+0=2$, and $0+2=2$. Hence the plane contains $A,B,C$.
::::
:::::

:::::problem[Problem 3.31 — Compute a 3D distance]{difficulty=standard}
Find the distance from the origin to the plane $3x-4y+12z=26$.

::::solution[Solution]
**Answer:** $2$ units.

1. **Use the point-to-plane distance formula.** For $ax+by+cz=d$ and point $(x_0,y_0,z_0)$, the perpendicular distance is $D=|ax_0+by_0+cz_0-d|/\sqrt{a^2+b^2+c^2}$. The normal is nonzero because $(a,b,c)=(3,-4,12)$.

2. **Identify the point and coefficients.** The origin is $(0,0,0)$, and the plane $3x-4y+12z=26$ has $a=3$, $b=-4$, $c=12$, and $d=26$.

3. **Substitute carefully.** Compute the numerator and denominator separately:

$$
D=\frac{|3(0)-4(0)+12(0)-26|}{\sqrt{3^2+(-4)^2+12^2}}
=\frac{|-26|}{\sqrt{9+16+144}}
=\frac{26}{\sqrt{169}}=\frac{26}{13}=2.
$$

4. **Check.** The distance is positive and is measured along the plane's normal, so it is the shortest distance. Therefore the origin lies $2$ units from the plane.
::::
:::::

:::::problem[Problem 3.32 — Line equation and direction]{difficulty=standard}
Determine whether the lines $\ell_1:\,x=t,\;y=1+t,\;z=2t$ and $\ell_2:\,x=2s,\;y=s,\;z=s+1$ are parallel, intersecting, or skew.

::::solution[Solution]
**Answer:** The lines are skew.

1. **Compare directions first.** The lines have direction vectors $\vec d_1=\langle1,1,2\rangle$ and $\vec d_2=\langle2,1,1\rangle$. They are not scalar multiples: matching the $x$ components would require multiplier $2$, but matching the $y$ components would require multiplier $1$. The lines are therefore not parallel.

2. **Test whether a common point exists.** If the lines intersect, the $x$ and $y$ coordinates must satisfy

$$
t=2s,\qquad1+t=s.
$$

Substitute $t=2s$ into the second equation: $1+2s=s$, hence $s=-1$ and $t=-2$.

3. **Check the remaining $z$ equation.** On $\ell_1$, $z=2t=2(-2)=-4$. On $\ell_2$, $z=s+1=-1+1=0$. Since $-4\ne0$, those parameters do not give an intersection; there are no others because $x,y$ fixed the pair uniquely.

4. **Conclude.** The lines are neither parallel nor intersecting. By definition, they are skew lines in three-dimensional space.
::::
:::::

:::::problem[Problem 3.33 — Line equation and direction]{difficulty=challenge}
Find the line of intersection of the planes $x+y+z=1$ and $x-y+2z=0$.

::::solution[Solution]
**Answer:** $\vec r(t)=\left\langle\frac12,\frac12,0\right\rangle+t\langle3,-1,-2\rangle$.

1. **Find the direction of the intersection.** The plane normals are $\vec n_1=\langle1,1,1\rangle$ and $\vec n_2=\langle1,-1,2\rangle$. Their cross product is perpendicular to both normals, hence parallel to both planes:

$$
\vec d=\vec n_1\times\vec n_2
=\langle1(2)-1(-1),\;1(1)-1(2),\;1(-1)-1(1)\rangle
=\langle3,-1,-2\rangle.
$$

The result is nonzero, so the planes have a line of intersection.

2. **Find one common point.** Choose $z=0$. The two plane equations reduce to $x+y=1$ and $x-y=0$. Adding gives $2x=1$, hence $x=1/2$; then $y=1/2$. So $P=(1/2,1/2,0)$.

3. **Write and check the line.** Use $\vec r=P+t\vec d$ as in the answer. Substitution into the first plane gives $(1/2+3t)+(1/2-t)-2t=1$, and into the second gives $(1/2+3t)-(1/2-t)+2(-2t)=0$. Both hold for every $t$. Thus the line lies in both planes.
::::
:::::

## 12.6 Cylinders and Quadric Surfaces

:::callout-connect
📺 Watch before this section

“Quadric surfaces | Multivariable Calculus” — Khan Academy
:::

:::callout-intuition
Intuition first.

In 2D you can have conic sections: circles, ellipses, parabolas, hyperbolas. Extend those to 3D by allowing a third variable and you get

quadric surfaces

— the 3D analogs of conics. The strategy for understanding any quadric surface is to look at its

traces

: cross-sections obtained by setting one variable equal to a constant and seeing what 2D curve you get. A surface is an ellipsoid if all three traces are ellipses; it's a hyperboloid if some traces are hyperbolas; it's a paraboloid if traces in one direction are parabolas. You don't need to memorize 20 formulas — just master the trace method and the six standard types.
:::

### Cylinders

A **cylinder** in 3D is a surface that contains all lines parallel to a given axis passing through a given curve. If a variable is *missing* from the equation, the surface extends infinitely in that direction.

Example: $y^2+z^2=4$ is a cylinder of radius 2 extending infinitely along the $x$-axis. The equation $y=x^2$ is a parabolic cylinder extending along the $z$-axis.


For now, here is the simplest cylinder, $x^2+z^2=4$. There is no $y$ in the equation, so nothing limits $y$: the circle of radius 2 in the $xz$-plane is slid along the $y$-axis in both directions, and every slice $y=k$ is the same circle.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 320 246" width="320" height="246" role="img" aria-label="A circular cylinder x squared plus z squared equals 4 around the y-axis, drawn as circles and straight lines">
<path class="fig-axis" d="M151.95 129.36L100.89 168.43"/>
<path class="fig-axis" d="M151.95 129.36L290 159.22"/>
<path class="fig-axis" d="M151.95 129.36L151.95 30"/>
<path class="fig-guide" d="M76.4 43.48L77.51 43.78L78.59 44.19L79.65 44.69L80.67 45.3L81.67 46.01L82.64 46.81L83.58 47.72L84.48 48.72L85.35 49.81L86.18 51L86.98 52.27L87.73 53.64L88.45 55.09L89.13 56.63L89.76 58.25L90.35 59.95L90.9 61.72L91.4 63.57L91.86 65.49L92.27 67.48L92.63 69.54L92.95 71.66L93.22 73.83L93.44 76.07L93.61 78.35L93.73 80.68L93.8 83.06L93.83 85.48L93.8 87.94L93.73 90.43L93.61 92.95L93.44 95.5L93.22 98.06L92.95 100.65L92.63 103.25L92.27 105.87L91.86 108.48L91.4 111.1L90.9 113.72L90.35 116.33L89.76 118.94L89.13 121.53L88.45 124.1L87.73 126.64L86.98 129.17L86.18 131.66L85.35 134.12L84.48 136.54L83.58 138.92L82.64 141.26L81.67 143.55L80.67 145.79L79.65 147.97L78.59 150.09L77.51 152.15L76.4 154.14L75.28 156.07L74.13 157.93L72.96 159.71L71.78 161.41L70.58 163.04L69.36 164.58L68.14 166.04L66.91 167.41L65.67 168.7L64.42 169.89L63.17 170.99L61.91 172L60.66 172.91L59.41 173.72L58.16 174.43L56.92 175.05L55.69 175.56L54.46 175.98L53.25 176.29L52.05 176.5L50.87 176.61L49.7 176.61L48.55 176.51L47.43 176.31"/>
<path class="fig-guide" d="M166.44 62.95L167.54 63.25L168.62 63.66L169.68 64.16L170.71 64.77L171.71 65.48L172.68 66.29L173.61 67.19L174.52 68.19L175.38 69.28L176.22 70.47L177.01 71.74L177.77 73.11L178.48 74.56L179.16 76.1L179.79 77.72L180.38 79.42L180.93 81.19L181.43 83.04L181.89 84.96L182.3 86.95L182.66 89.01L182.98 91.13L183.25 93.3L183.47 95.54L183.64 97.82L183.76 100.15L183.84 102.53L183.86 104.95L183.84 107.41L183.76 109.9L183.64 112.42L183.47 114.97L183.25 117.54L182.98 120.12L182.66 122.72L182.3 125.34L181.89 127.95L181.43 130.57L180.93 133.19L180.38 135.81L179.79 138.41L179.16 141L178.48 143.57L177.77 146.12L177.01 148.64L176.22 151.13L175.38 153.59L174.52 156.01L173.61 158.4L172.68 160.73L171.71 163.02L170.71 165.26L169.68 167.44L168.62 169.56L167.54 171.62L166.44 173.61L165.31 175.54L164.16 177.4L162.99 179.18L161.81 180.88L160.61 182.51L159.4 184.05L158.17 185.51L156.94 186.88L155.7 188.17L154.45 189.36L153.2 190.46L151.95 191.47L150.7 192.38L149.44 193.19L148.2 193.91L146.96 194.52L145.72 195.04L144.5 195.45L143.29 195.76L142.09 195.97L140.9 196.08L139.74 196.08L138.59 195.98L137.46 195.78"/>
<path class="fig-guide" d="M256.47 82.42L257.58 82.72L258.66 83.13L259.71 83.64L260.74 84.24L261.74 84.95L262.71 85.76L263.65 86.66L264.55 87.66L265.42 88.75L266.25 89.94L267.05 91.22L267.8 92.58L268.52 94.03L269.19 95.57L269.83 97.19L270.42 98.89L270.96 100.66L271.47 102.51L271.92 104.44L272.33 106.43L272.7 108.48L273.01 110.6L273.28 112.78L273.5 115.01L273.68 117.29L273.8 119.62L273.87 122L273.9 124.42L273.87 126.88L273.8 129.37L273.68 131.89L273.5 134.44L273.28 137.01L273.01 139.59L272.7 142.2L272.33 144.81L271.92 147.43L271.47 150.05L270.96 152.66L270.42 155.28L269.83 157.88L269.19 160.47L268.52 163.04L267.8 165.59L267.05 168.11L266.25 170.6L265.42 173.06L264.55 175.49L263.65 177.87L262.71 180.2L261.74 182.49L260.74 184.73L259.71 186.91L258.66 189.03L257.58 191.09L256.47 193.09L255.34 195.01L254.2 196.87L253.03 198.65L251.84 200.35L250.64 201.98L249.43 203.52L248.21 204.98L246.97 206.35L245.73 207.64L244.49 208.83L243.23 209.93L241.98 210.94L240.73 211.85L239.48 212.66L238.23 213.38L236.99 213.99L235.76 214.51L234.53 214.92L233.32 215.23L232.12 215.44L230.94 215.55L229.77 215.55L228.62 215.45L227.49 215.25"/>
<path class="fig-guide" d="M77.87 43.9L167.91 63.38L257.94 82.85"/>
<path class="fig-guide" d="M89.55 57.7L179.59 77.17L269.62 96.64"/>
<path class="fig-guide" d="M93.83 85.48L183.86 104.95L273.9 124.42"/>
<path class="fig-guide" d="M89.55 119.8L179.59 139.27L269.62 158.74"/>
<path class="fig-guide" d="M77.87 151.47L167.91 170.94L257.94 190.41"/>
<path class="fig-guide" d="M61.91 172L151.95 191.47L241.98 210.94"/>
<path class="fig-curve-alt" d="M30 134.31L120.03 153.78L210.07 173.25"/>
<path class="fig-curve-alt" d="M34.28 99.98L124.31 119.46L214.34 138.93"/>
<path class="fig-curve-alt" d="M45.96 68.32L135.99 87.79L226.02 107.26"/>
<path class="fig-curve-alt" d="M61.91 47.79L151.95 67.26L241.98 86.73"/>
<path class="fig-curve-alt" d="M45.96 175.88L135.99 195.35L226.02 214.82"/>
<path class="fig-curve-alt" d="M34.28 162.09L124.31 181.56L214.34 201.03"/>
<path class="fig-curve" d="M30 134.31L30.02 131.85L30.1 129.36L30.22 126.84L30.39 124.29L30.61 121.72L30.88 119.13L31.2 116.53L31.56 113.92L31.97 111.3L32.43 108.68L32.93 106.06L33.48 103.45L34.07 100.85L34.7 98.26L35.38 95.69L36.1 93.14L36.85 90.62L37.65 88.12L38.48 85.66L39.35 83.24L40.25 80.86L41.19 78.52L42.16 76.24L43.16 74L44.18 71.82L45.24 69.7L46.32 67.64L47.43 65.64L48.55 63.72L49.7 61.86L50.87 60.08L52.05 58.37L53.25 56.75L54.46 55.21L55.69 53.75L56.92 52.37L58.16 51.09L59.41 49.9L60.66 48.8L61.91 47.79L63.17 46.88L64.42 46.07L65.67 45.35L66.91 44.74L68.14 44.22L69.36 43.81L70.58 43.5L71.78 43.29L72.96 43.18L74.13 43.17L75.28 43.27L76.4 43.48"/>
<path class="fig-curve" d="M47.43 176.31L46.32 176.01L45.24 175.6L44.18 175.09L43.16 174.48L42.16 173.78L41.19 172.97L40.25 172.07L39.35 171.07L38.48 169.98L37.65 168.79L36.85 167.51L36.1 166.15L35.38 164.69L34.7 163.16L34.07 161.54L33.48 159.84L32.93 158.06L32.43 156.21L31.97 154.29L31.56 152.3L31.2 150.25L30.88 148.13L30.61 145.95L30.39 143.72L30.22 141.44L30.1 139.1L30.02 136.73L30 134.31"/>
<path class="fig-curve" d="M120.03 153.78L120.06 151.32L120.13 148.83L120.25 146.31L120.43 143.76L120.65 141.19L120.92 138.61L121.23 136L121.6 133.39L122.01 130.77L122.46 128.15L122.97 125.54L123.51 122.92L124.1 120.32L124.74 117.73L125.41 115.16L126.13 112.61L126.89 110.09L127.68 107.6L128.51 105.14L129.38 102.71L130.28 100.33L131.22 98L132.19 95.71L133.19 93.47L134.22 91.29L135.27 89.17L136.35 87.11L137.46 85.11L138.59 83.19L139.74 81.33L140.9 79.55L142.09 77.85L143.29 76.22L144.5 74.68L145.72 73.22L146.96 71.85L148.2 70.56L149.44 69.37L150.7 68.27L151.95 67.26L153.2 66.35L154.45 65.54L155.7 64.82L156.94 64.21L158.17 63.69L159.4 63.28L160.61 62.97L161.81 62.76L162.99 62.65L164.16 62.65L165.31 62.75L166.44 62.95"/>
<path class="fig-curve" d="M137.46 195.78L136.35 195.48L135.27 195.07L134.22 194.56L133.19 193.96L132.19 193.25L131.22 192.44L130.28 191.54L129.38 190.54L128.51 189.45L127.68 188.26L126.89 186.98L126.13 185.62L125.41 184.17L124.74 182.63L124.1 181.01L123.51 179.31L122.97 177.53L122.46 175.68L122.01 173.76L121.6 171.77L121.23 169.72L120.92 167.6L120.65 165.42L120.43 163.19L120.25 160.91L120.13 158.57L120.06 156.2L120.03 153.78"/>
<path class="fig-curve" d="M210.07 173.25L210.09 170.79L210.17 168.3L210.29 165.78L210.46 163.23L210.68 160.66L210.95 158.08L211.27 155.47L211.63 152.86L212.04 150.24L212.5 147.62L213 145.01L213.55 142.39L214.14 139.79L214.77 137.2L215.45 134.63L216.16 132.08L216.92 129.56L217.71 127.07L218.55 124.61L219.42 122.18L220.32 119.8L221.26 117.47L222.22 115.18L223.22 112.94L224.25 110.76L225.31 108.64L226.39 106.58L227.49 104.58L228.62 102.66L229.77 100.8L230.94 99.02L232.12 97.32L233.32 95.69L234.53 94.15L235.76 92.69L236.99 91.32L238.23 90.03L239.48 88.84L240.73 87.74L241.98 86.73L243.23 85.82L244.49 85.01L245.73 84.29L246.97 83.68L248.21 83.16L249.43 82.75L250.64 82.44L251.84 82.23L253.03 82.12L254.2 82.12L255.34 82.22L256.47 82.42"/>
<path class="fig-curve" d="M227.49 215.25L226.39 214.95L225.31 214.54L224.25 214.03L223.22 213.43L222.22 212.72L221.26 211.91L220.32 211.01L219.42 210.01L218.55 208.92L217.71 207.73L216.92 206.45L216.16 205.09L215.45 203.64L214.77 202.1L214.14 200.48L213.55 198.78L213 197.01L212.5 195.16L212.04 193.23L211.63 191.24L211.27 189.19L210.95 187.07L210.68 184.9L210.46 182.66L210.29 180.38L210.17 178.05L210.09 175.67L210.07 173.25"/>
<path class="fig-axis" d="M100.89 168.41L100.89 168.43L100.9 168.42"/>
<path class="fig-axis" d="M289.98 159.22L290 159.22L289.98 159.21"/>
<path class="fig-axis" d="M151.96 30.02L151.95 30L151.94 30.02"/>
<text class="fig-label-em" x="89.94" y="177.5">x</text>
<text class="fig-label-em" x="296.77" y="164.33">y</text>
<text class="fig-label-em" x="148.95" y="23">z</text>
</svg>
<figcaption>The cylinder $x^2+z^2=4$ has no $y$ in its equation, so every plane $y=c$ cuts it in the same circle of radius $2$ (the circle traces) and the surface is those circles stacked along the $y$-axis, swept out by lines parallel to the $y$-axis (the rulings).</figcaption>
</figure>

A cylinder is named after the curve in the two variables that are present. A circle gives a circular cylinder, an ellipse gives an elliptic cylinder, a parabola gives a parabolic cylinder and a hyperbola gives a hyperbolic cylinder. The variable that is missing tells you which axis the tube runs along.

:::definition[Definition 12.6.1 — Cylinder Standard Forms]
If exactly one of $x,y,z$ is missing from the equation, the surface is a cylinder. It is a copy of the 2D curve in the other two variables, slid along the axis of the missing variable.

| Equation | Missing variable | Runs along | Cylinder type |
| --- | --- | --- | --- |
| $x^2+z^2=r^2$ | $y$ | $y$-axis | circular |
| $\dfrac{y^2}{a^2}+\dfrac{z^2}{b^2}=1$ | $x$ | $x$-axis | elliptic |
| $y=x^2$ | $z$ | $z$-axis | parabolic |
| $\dfrac{x^2}{a^2}-\dfrac{y^2}{b^2}=1$ | $z$ | $z$-axis | hyperbolic |
:::


### The Six Standard Quadric Surfaces

:::definition
Definition 12.6.2 — Quadric Surface Standard Forms

Each surface below is centered at the origin; shifting replaces $x,y,z$ with $x-h,y-k,z-l$.

| Name | Equation | Key traces |
| --- | --- | --- |
| Ellipsoid | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}+\dfrac{z^2}{c^2}=1$ | All traces are ellipses (or circles if $a=b=c$) |
| Elliptic paraboloid | $z=\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}$ | Horizontal traces: ellipses; vertical traces: parabolas; opens upward |
| Hyperbolic paraboloid | $z=\dfrac{x^2}{a^2}-\dfrac{y^2}{b^2}$ | Saddle shape: $y\!=\!0$ trace is upward parabola, $x\!=\!0$ trace is downward parabola |
| Elliptic cone | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}=\dfrac{z^2}{c^2}$ | Horizontal traces: ellipses; vertical traces: hyperbolas; two nappes meeting at origin |
| Hyperboloid of one sheet | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}-\dfrac{z^2}{c^2}=1$ | Horizontal traces: ellipses; vertical traces: hyperbolas; connected surface (like a waist) |
| Hyperboloid of two sheets | $-\dfrac{x^2}{a^2}-\dfrac{y^2}{b^2}+\dfrac{z^2}{c^2}=1$ | Two separate bowls above $z=c$ and below $z=-c$; no trace for $|z|< c$ |
:::


Here are the six standard quadric surfaces, each drawn with its traces. Look at the first three side by side. The ellipsoid is closed, the elliptic paraboloid is a bowl that opens one way, and the elliptic cone is two bowls tip to tip.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 320 184" width="320" height="184" role="img" aria-label="The ellipsoid x squared over 4 plus y squared over 9 plus z squared equals 1, with its three coordinate-plane ellipses">
<path class="fig-axis" d="M145.21 101.16L89.4 143.85"/>
<path class="fig-axis" d="M145.21 101.16L290 132.47"/>
<path class="fig-axis" d="M145.21 101.16L145.21 30"/>
<path class="fig-axis" d="M247.66 135.73L249.26 134.45L250.77 133.13L252.16 131.78L253.46 130.41L254.64 129L255.72 127.56L256.69 126.1L257.55 124.62L258.3 123.11L258.93 121.58L259.46 120.03L259.87 118.46L260.17 116.88L260.35 115.27L260.42 113.66L260.38 112.03L260.22 110.39L259.95 108.75L259.57 107.09L259.08 105.43L258.47 103.76L257.75 102.1L256.92 100.43L255.97 98.76L254.92 97.09L253.77 95.43L252.5 93.78L251.13 92.13L249.65 90.49L248.07 88.86L246.39 87.24L244.61 85.64L242.73 84.05L240.76 82.48L238.69 80.93L236.52 79.4L234.27 77.88L231.93 76.4L229.51 74.93L227 73.49L224.41 72.08L221.74 70.7L219 69.35L216.18 68.03L213.3 66.74L210.35 65.49L207.33 64.27L204.25 63.09L201.11 61.94L197.92 60.84L194.68 59.77L191.38 58.75L188.05 57.76L184.67 56.82L181.25 55.92L177.79 55.07L174.3 54.27L170.79 53.51L167.25 52.79L163.68 52.13L160.1 51.51L156.51 50.94L152.9 50.42L149.28 49.95L145.67 49.54L142.05 49.17L138.43 48.85L134.82 48.59L131.22 48.38L127.64 48.22L124.07 48.11L120.52 48.05L117 48.05L113.5 48.1L110.04 48.2L106.61 48.35L103.22 48.56L99.87 48.82L96.57 49.13L93.31 49.49L90.11 49.9L86.96 50.36L83.86 50.87L80.83 51.44L77.86 52.05L74.96 52.71L72.12 53.41L69.36 54.17L66.68 54.97L64.07 55.82L61.54 56.71L59.09 57.64L56.73 58.62L54.46 59.64L52.27 60.7L50.18 61.8L48.18 62.94L46.28 64.12L44.47 65.33L42.76 66.58L41.16 67.87L39.66 69.18L38.26 70.53L36.97 71.91L35.78 73.32L34.7 74.75L33.73 76.21L32.87 77.7L32.13 79.21L31.49 80.74L30.97 82.29L30.55 83.85L30.26 85.44L30.07 87.04L30 88.66L30.04 90.28L30.2 91.92L30.47 93.57L30.85 95.23L31.35 96.89L31.96 98.55L32.68 100.22L33.51 101.89L34.45 103.56L35.5 105.22L36.66 106.88L37.92 108.54L39.3 110.19L40.77 111.83L42.35 113.46L44.03 115.07L45.81 116.68L47.69 118.26L49.67 119.83L51.74 121.39L53.9 122.92L56.15 124.43L58.49 125.92L60.91 127.38L63.42 128.82L66.01 130.23L68.68 131.61L71.42 132.97L74.24 134.29L77.12 135.57L80.08 136.83L83.09 138.05L86.17 139.23L89.31 140.37L92.5 141.48L95.75 142.54L99.04 143.57L102.38 144.55L105.76 145.49L109.18 146.39L112.63 147.24L116.12 148.05L119.64 148.81L123.18 149.52L126.74 150.19L130.32 150.81L133.92 151.38L137.52 151.89L141.14 152.36L144.76 152.78L148.38 153.15L151.99 153.46L155.6 153.73L159.2 153.94L162.79 154.1L166.35 154.21L169.9 154.26L173.42 154.27L176.92 154.22L180.38 154.12L183.81 153.96L187.2 153.76L190.55 153.5L193.85 153.19L197.11 152.83L200.32 152.42L203.47 151.96L206.56 151.44L209.59 150.88L212.56 150.27L215.47 149.61L218.3 148.9L221.06 148.15L223.75 147.35L226.36 146.5L228.89 145.61L231.33 144.67L233.69 143.7L235.97 142.68L238.15 141.61L240.24 140.51L242.24 139.37L244.15 138.2L245.95 136.98L247.66 135.73"/>
<path class="fig-guide" d="M260.42 113.28L260.35 112.15L260.16 111.02L259.86 109.87L259.44 108.72L258.91 107.55L258.27 106.38L257.52 105.21L256.66 104.03L255.69 102.85L254.61 101.67L253.42 100.48L252.12 99.3L250.72 98.12L249.22 96.94L247.61 95.77L245.9 94.6L244.09 93.44L242.18 92.29L240.18 91.14L238.09 90L235.9 88.88L233.62 87.77L231.26 86.67L228.81 85.58L226.28 84.51L223.67 83.46L220.98 82.43L218.21 81.41L215.38 80.41L212.47 79.43L209.5 78.48L206.47 77.54L203.37 76.63L200.22 75.75L197.01 74.89L193.75 74.05L190.45 73.25L187.1 72.46L183.7 71.71L180.27 70.99L176.81 70.3L173.31 69.63L169.79 69L166.24 68.4L162.67 67.83L159.09 67.3L155.49 66.8L151.88 66.33L148.26 65.9L144.64 65.5L141.03 65.14L137.41 64.81L133.8 64.52L130.21 64.26L126.63 64.04L123.07 63.86L119.53 63.71L116.01 63.6L112.52 63.53L109.07 63.5L105.65 63.5L102.27 63.54L98.94 63.62L95.64 63.73L92.4 63.88L89.21 64.07L86.08 64.29L83 64.55L79.98 64.85L77.03 65.18L74.15 65.55L71.34 65.95L68.6 66.39L65.93 66.87L63.34 67.37L60.84 67.91L58.42 68.48L56.08 69.09L53.83 69.72L51.67 70.39L49.6 71.09L47.63 71.82L45.76 72.57L43.98 73.36L42.3 74.17L40.72 75.01L39.25 75.87L37.88 76.76L36.62 77.67L35.46 78.61L34.42 79.57L33.48 80.55L32.65 81.55L31.93 82.57L31.33 83.61L30.84 84.66L30.46 85.73L30.19 86.82L30.04 87.92L30 89.04"/>
<path class="fig-guide" d="M173.27 54.06L174.09 54.3L174.87 54.6L175.63 54.94L176.35 55.32L177.05 55.75L177.71 56.23L178.34 56.75L178.94 57.31L179.51 57.92L180.04 58.57L180.54 59.26L181 59.99L181.43 60.77L181.82 61.58L182.18 62.43L182.49 63.32L182.78 64.25L183.02 65.22L183.23 66.22L183.4 67.25L183.53 68.32L183.63 69.42L183.68 70.55L183.7 71.71L183.68 72.9L183.63 74.12L183.53 75.37L183.4 76.64L183.23 77.93L183.02 79.25L182.78 80.59L182.49 81.95L182.18 83.33L181.82 84.73L181.43 86.14L181 87.57L180.54 89.01L180.04 90.46L179.51 91.92L178.94 93.4L178.34 94.88L177.71 96.36L177.05 97.86L176.35 99.35L175.63 100.85L174.87 102.34L174.09 103.84L173.27 105.33L172.43 106.82L171.56 108.3L170.67 109.78L169.75 111.25L168.8 112.7L167.84 114.15L166.85 115.58L165.84 117L164.81 118.41L163.76 119.79L162.69 121.16L161.6 122.51L160.5 123.84L159.38 125.14L158.25 126.42L157.11 127.68L155.95 128.91L154.78 130.11L153.61 131.28L152.42 132.43L151.23 133.54L150.04 134.62L148.83 135.67L147.63 136.69L146.42 137.67L145.21 138.61L144 139.52L142.79 140.38L141.59 141.21L140.39 142L139.19 142.75L138 143.46L136.81 144.13L135.64 144.76L134.47 145.34L133.32 145.88L132.17 146.37L131.04 146.82L129.92 147.22L128.82 147.58L127.74 147.9L126.67 148.16L125.62 148.38L124.59 148.56L123.58 148.68L122.59 148.76L121.62 148.8L120.67 148.78L119.76 148.72L118.86 148.62L117.99 148.46L117.15 148.26"/>
<path class="fig-guide" d="M41.93 67.25L40.93 68.16L40.03 69.1L39.23 70.07L38.54 71.07L37.96 72.1L37.48 73.16L37.1 74.25L36.83 75.37L36.67 76.51L36.62 77.67L36.67 78.86L36.83 80.07L37.1 81.3L37.48 82.55L37.96 83.82L38.54 85.11L39.23 86.41L40.03 87.73L40.93 89.05L41.93 90.4L43.04 91.75L44.25 93.11L45.55 94.48L46.95 95.85L48.46 97.24L50.05 98.62L51.74 100.01L53.52 101.4L55.4 102.79L57.36 104.17L59.41 105.56L61.54 106.94L63.76 108.31L66.05 109.68L68.43 111.03L70.88 112.38L73.4 113.72L75.99 115.05L78.65 116.36L81.38 117.65L84.17 118.93L87.02 120.2L89.93 121.44L92.9 122.66L95.91 123.87L98.98 125.05L102.08 126.2L105.24 127.33L108.43 128.44L111.65 129.52L114.92 130.57L118.21 131.59L121.52 132.58L124.86 133.55L128.22 134.47L131.6 135.37L134.99 136.23L138.39 137.06L141.8 137.85L145.21 138.61L148.62 139.33L152.03 140.01L155.43 140.65L158.82 141.26L162.2 141.82L165.56 142.35L168.9 142.83L172.22 143.27L175.51 143.67L178.77 144.03L182 144.35L185.19 144.62L188.34 144.86L191.45 145.04L194.51 145.19L197.53 145.29L200.49 145.35L203.4 145.36L206.25 145.33L209.04 145.26L211.77 145.14L214.43 144.98L217.02 144.78L219.55 144.54L222 144.25L224.37 143.91L226.67 143.54L228.88 143.13L231.02 142.67L233.06 142.17L235.03 141.63L236.9 141.05L238.68 140.44L240.37 139.78L241.97 139.09L243.47 138.35L244.87 137.58L246.18 136.78L247.38 135.94L248.49 135.07"/>
<path class="fig-curve-alt" d="M106.72 130.6L106.74 129.41L106.79 128.19L106.89 126.95L107.02 125.68L107.19 124.38L107.4 123.06L107.65 121.72L107.93 120.36L108.25 118.99L108.6 117.59L108.99 116.18L109.42 114.75L109.88 113.31L110.38 111.85L110.91 110.39L111.48 108.92L112.08 107.44L112.71 105.95L113.37 104.46L114.07 102.97L114.8 101.47L115.55 99.97L116.34 98.48L117.15 96.99L117.99 95.5L118.86 94.01L119.76 92.54L120.67 91.07L121.62 89.61L122.59 88.17L123.58 86.73L124.59 85.31L125.62 83.91L126.67 82.52L127.74 81.16L128.82 79.81L129.92 78.48L131.04 77.18L132.17 75.89L133.32 74.64L134.47 73.41L135.64 72.21L136.81 71.03L138 69.89L139.19 68.77L140.39 67.69L141.59 66.64L142.79 65.63L144 64.65L145.21 63.71L146.42 62.8L147.63 61.93L148.83 61.1L150.04 60.31L151.23 59.56L152.42 58.85L153.61 58.19L154.78 57.56L155.95 56.98L157.11 56.44L158.25 55.95L159.38 55.5L160.5 55.09L161.6 54.73L162.69 54.42L163.76 54.15L164.81 53.93L165.84 53.76L166.85 53.63L167.84 53.55L168.8 53.52L169.75 53.53L170.67 53.59L171.56 53.7L172.43 53.85L173.27 54.06"/>
<path class="fig-curve-alt" d="M117.15 148.26L116.34 148.01L115.55 147.72L114.8 147.38L114.07 146.99L113.37 146.56L112.71 146.09L112.08 145.57L111.48 145L110.91 144.4L110.38 143.75L109.88 143.06L109.42 142.32L108.99 141.55L108.6 140.74L108.25 139.88L107.93 138.99L107.65 138.06L107.4 137.1L107.19 136.1L107.02 135.07L106.89 134L106.79 132.9L106.74 131.77L106.72 130.6"/>
<path class="fig-curve-alt" d="M253.8 124.64L253.75 123.45L253.59 122.24L253.32 121.01L252.95 119.76L252.47 118.49L251.88 117.21L251.19 115.91L250.39 114.59L249.49 113.26L248.49 111.92L247.38 110.57L246.18 109.21L244.87 107.84L243.47 106.46L241.97 105.08L240.37 103.7L238.68 102.31L236.9 100.92L235.03 99.53L233.06 98.14L231.02 96.76L228.88 95.38L226.67 94.01L224.37 92.64L222 91.28L219.55 89.93L217.02 88.6L214.43 87.27L211.77 85.96L209.04 84.66L206.25 83.38L203.4 82.12L200.49 80.88L197.53 79.65L194.51 78.45L191.45 77.27L188.34 76.11L185.19 74.98L182 73.88L178.77 72.8L175.51 71.75L172.22 70.72L168.9 69.73L165.56 68.77L162.2 67.84L158.82 66.95L155.43 66.08L152.03 65.25L148.62 64.46L145.21 63.71L141.8 62.99L138.39 62.31L134.99 61.66L131.6 61.06L128.22 60.49L124.86 59.97L121.52 59.49L118.21 59.04L114.92 58.64L111.65 58.28L108.43 57.97L105.24 57.69L102.08 57.46L98.98 57.27L95.91 57.13L92.9 57.03L89.93 56.97L87.02 56.95L84.17 56.98L81.38 57.06L78.65 57.17L75.99 57.33L73.4 57.53L70.88 57.78L68.43 58.07L66.05 58.4L63.76 58.77L61.54 59.19L59.41 59.65L57.36 60.15L55.4 60.68L53.52 61.26L51.74 61.88L50.05 62.54L48.46 63.23L46.95 63.96L45.55 64.73L44.25 65.54L43.04 66.38L41.93 67.25"/>
<path class="fig-curve-alt" d="M248.49 135.07L249.49 134.16L250.39 133.22L251.19 132.25L251.88 131.24L252.47 130.21L252.95 129.15L253.32 128.06L253.59 126.95L253.75 125.81L253.8 124.64"/>
<path class="fig-curve" d="M106.72 130.6L110.15 131.33L113.61 132.02L117.11 132.68L120.63 133.31L124.18 133.91L127.75 134.48L131.33 135.02L134.93 135.52L138.54 135.99L142.16 136.42L145.78 136.82L149.4 137.18L153.01 137.51L156.62 137.8L160.21 138.06L163.79 138.28L167.36 138.46L170.9 138.6L174.41 138.71L177.9 138.78L181.35 138.82L184.77 138.82L188.15 138.78L191.49 138.7L194.78 138.59L198.02 138.43L201.21 138.25L204.35 138.02L207.42 137.76L210.44 137.47L213.39 137.13L216.27 136.76L219.09 136.36L221.83 135.92L224.49 135.45L227.08 134.94L229.58 134.41L232.01 133.83L234.34 133.23L236.59 132.59L238.75 131.93L240.82 131.23L242.79 130.5L244.67 129.74L246.44 128.96L248.12 128.15L249.7 127.31L251.17 126.45L252.54 125.56L253.8 124.64L254.96 123.71L256.01 122.75L256.94 121.77L257.77 120.77L258.49 119.75L259.09 118.71L259.58 117.65L259.96 116.58L260.23 115.5L260.38 114.39L260.42 113.28"/>
<path class="fig-curve" d="M30 89.04L30.08 90.16L30.26 91.3L30.57 92.45L30.98 93.6L31.51 94.76L32.15 95.93L32.9 97.11L33.76 98.29L34.73 99.47L35.81 100.65L37 101.83L38.3 103.01L39.7 104.2L41.21 105.37L42.82 106.55L44.52 107.71L46.33 108.88L48.24 110.03L50.24 111.18L52.34 112.31L54.52 113.44L56.8 114.55L59.17 115.65L61.61 116.73L64.15 117.8L66.76 118.85L69.45 119.89L72.21 120.91L75.05 121.91L77.95 122.88L80.92 123.84L83.96 124.77L87.05 125.68L90.2 126.57L93.41 127.43L96.67 128.26L99.98 129.07L103.33 129.85L106.72 130.6"/>
<path class="fig-axis" d="M89.4 143.84L89.4 143.85L89.41 143.85"/>
<path class="fig-axis" d="M289.98 132.48L290 132.47L289.98 132.46"/>
<path class="fig-axis" d="M145.22 30.02L145.21 30L145.2 30.02"/>
<text class="fig-label-em" x="78.45" y="152.93">x</text>
<text class="fig-label-em" x="296.77" y="137.58">y</text>
<text class="fig-label-em" x="142.21" y="23">z</text>
</svg>
<figcaption>The ellipsoid $x^2/4+y^2/9+z^2=1$ meets each coordinate plane in an ellipse: $x^2/4+y^2/9=1$ in the $xy$-plane, $x^2/4+z^2=1$ in the $xz$-plane and $y^2/9+z^2=1$ in the $yz$-plane, with semi-axes $2$, $3$ and $1$ along $x$, $y$, $z$; the dashed parts are on the far side.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 320 249" width="320" height="249" role="img" aria-label="The elliptic paraboloid z equals x squared plus y squared over 4, drawn with horizontal ellipses and two parabolas">
<path class="fig-axis" d="M151.74 186.68L109.51 218.98"/>
<path class="fig-axis" d="M151.74 186.68L290 216.58"/>
<path class="fig-axis" d="M151.74 186.68L151.74 40.58"/>
<path class="fig-curve-alt" d="M136.1 168.2L138.42 168.69L140.76 169.17L143.12 169.62L145.5 170.05L147.88 170.46L150.27 170.84L152.66 171.21L155.05 171.55L157.43 171.87L159.8 172.16L162.17 172.43L164.51 172.68L166.84 172.9L169.15 173.09L171.42 173.26L173.67 173.4L175.88 173.51L178.06 173.6L180.19 173.66L182.28 173.7L184.33 173.7L186.32 173.68L188.26 173.64L190.14 173.57L191.97 173.47L193.73 173.34L195.43 173.19L197.06 173.01L198.62 172.8L200.11 172.57L201.52 172.32L202.86 172.04L204.12 171.73L205.3 171.4L206.39 171.05L207.4 170.68L208.33 170.28L209.17 169.86L209.92 169.42L210.57 168.96L211.14 168.48L211.62 167.98L212.01 167.47L212.3 166.93L212.5 166.38L212.6 165.82L212.61 165.24L212.53 164.64L212.35 164.03L212.08 163.42L211.72 162.78L211.26 162.14L210.72 161.49L210.08 160.84L209.35 160.17L208.53 159.5L207.63 158.82L206.64 158.14L205.56 157.46L204.4 156.78L203.16 156.09L201.84 155.4L200.45 154.72L198.98 154.04L197.43 153.36L195.82 152.69L194.14 152.02L192.39 151.35L190.58 150.7L188.71 150.05L186.78 149.42L184.8 148.79L182.76 148.18L180.68 147.57L178.56 146.99L176.39 146.41L174.19 145.85L171.95 145.31L169.68 144.78L167.38 144.27L165.06 143.78L162.72 143.31L160.36 142.86L157.99 142.43L155.6 142.02L153.22 141.63L150.82 141.27L148.44 140.93L146.05 140.61L143.68 140.32L141.31 140.05L138.97 139.8L136.64 139.58L134.34 139.39L132.06 139.22L129.81 139.08L127.6 138.97L125.43 138.88L123.29 138.82L121.2 138.78L119.16 138.77L117.16 138.79L115.22 138.84L113.34 138.91L111.51 139.01L109.75 139.14L108.05 139.29L106.42 139.47L104.86 139.67L103.37 139.91L101.96 140.16L100.62 140.44L99.36 140.75L98.18 141.07L97.09 141.43L96.08 141.8L95.15 142.2L94.32 142.62L93.57 143.06L92.91 143.52L92.34 143.99L91.86 144.49L91.48 145.01L91.18 145.54L90.99 146.09L90.88 146.66L90.87 147.24L90.95 147.84L91.13 148.44L91.4 149.06L91.76 149.69L92.22 150.33L92.77 150.98L93.4 151.64L94.13 152.31L94.95 152.98L95.85 153.65L96.85 154.33L97.92 155.02L99.08 155.7L100.32 156.39L101.64 157.07L103.03 157.76L104.51 158.44L106.05 159.12L107.66 159.79L109.35 160.46L111.09 161.12L112.91 161.78L114.78 162.42L116.7 163.06L118.68 163.69L120.72 164.3L122.8 164.9L124.92 165.49L127.09 166.07L129.29 166.63L131.53 167.17L133.8 167.7L136.1 168.2"/>
<path class="fig-curve-alt" d="M129.62 142.72L132.9 143.42L136.22 144.08L139.55 144.72L142.91 145.33L146.28 145.91L149.66 146.46L153.04 146.97L156.41 147.46L159.79 147.91L163.15 148.32L166.49 148.7L169.81 149.05L173.1 149.36L176.35 149.63L179.57 149.87L182.75 150.07L185.88 150.23L188.96 150.36L191.98 150.44L194.93 150.49L197.82 150.5L200.64 150.47L203.39 150.41L206.05 150.31L208.63 150.16L211.13 149.99L213.53 149.77L215.83 149.52L218.04 149.23L220.15 148.9L222.15 148.54L224.04 148.14L225.82 147.71L227.48 147.25L229.03 146.75L230.46 146.22L231.77 145.66L232.95 145.07L234.01 144.45L234.94 143.8L235.75 143.12L236.42 142.41L236.97 141.68L237.38 140.93L237.66 140.15L237.81 139.35L237.82 138.53L237.71 137.69L237.46 136.83L237.08 135.95L236.56 135.06L235.92 134.15L235.14 133.23L234.24 132.3L233.21 131.36L232.06 130.41L230.78 129.46L229.38 128.5L227.85 127.53L226.22 126.56L224.46 125.59L222.6 124.62L220.62 123.65L218.54 122.69L216.36 121.73L214.07 120.78L211.7 119.83L209.22 118.9L206.66 117.97L204.02 117.06L201.29 116.16L198.49 115.27L195.62 114.4L192.67 113.55L189.67 112.72L186.6 111.9L183.49 111.11L180.32 110.35L177.11 109.6L173.86 108.88L170.58 108.19L167.26 107.52L163.93 106.88L160.57 106.28L157.2 105.7L153.83 105.15L150.45 104.63L147.07 104.15L143.7 103.7L140.34 103.28L137 102.9L133.68 102.56L130.39 102.25L127.13 101.97L123.91 101.74L120.73 101.54L117.6 101.37L114.52 101.25L111.51 101.16L108.55 101.11L105.66 101.1L102.84 101.13L100.09 101.2L97.43 101.3L94.85 101.44L92.36 101.62L89.95 101.84L87.65 102.09L85.44 102.38L83.34 102.7L81.34 103.06L79.45 103.46L77.67 103.89L76 104.36L74.45 104.85L73.02 105.38L71.71 105.94L70.53 106.54L69.47 107.16L68.54 107.81L67.73 108.49L67.06 109.19L66.51 109.92L66.1 110.68L65.82 111.46L65.67 112.26L65.66 113.08L65.77 113.92L66.02 114.78L66.41 115.65L66.92 116.55L67.56 117.45L68.34 118.37L69.24 119.3L70.27 120.24L71.43 121.19L72.71 122.15L74.11 123.11L75.63 124.08L77.27 125.04L79.02 126.01L80.88 126.98L82.86 127.95L84.94 128.92L87.12 129.87L89.41 130.83L91.79 131.77L94.26 132.71L96.82 133.64L99.46 134.55L102.19 135.45L104.99 136.33L107.87 137.2L110.81 138.06L113.81 138.89L116.88 139.7L119.99 140.49L123.16 141.26L126.37 142L129.62 142.72"/>
<path class="fig-curve-alt" d="M124.65 116.09L128.67 116.94L132.73 117.76L136.81 118.54L140.92 119.28L145.05 119.99L149.19 120.66L153.33 121.29L157.47 121.89L161.59 122.44L165.71 122.95L169.8 123.41L173.87 123.84L177.9 124.22L181.89 124.55L185.83 124.84L189.72 125.09L193.55 125.28L197.32 125.44L201.02 125.54L204.64 125.6L208.18 125.62L211.63 125.58L214.99 125.5L218.26 125.38L221.42 125.2L224.47 124.99L227.41 124.72L230.24 124.41L232.94 124.06L235.52 123.66L237.97 123.22L240.28 122.73L242.46 122.2L244.5 121.63L246.4 121.02L248.15 120.38L249.75 119.69L251.2 118.96L252.5 118.2L253.64 117.4L254.63 116.57L255.46 115.71L256.12 114.82L256.63 113.89L256.97 112.94L257.15 111.96L257.17 110.95L257.03 109.92L256.72 108.87L256.25 107.8L255.63 106.7L254.84 105.59L253.89 104.47L252.78 103.33L251.52 102.18L250.11 101.01L248.54 99.84L246.82 98.67L244.96 97.48L242.95 96.3L240.81 95.11L238.52 93.92L236.1 92.74L233.56 91.55L230.88 90.38L228.08 89.21L225.17 88.05L222.14 86.91L219.01 85.77L215.77 84.65L212.43 83.55L209 82.47L205.48 81.4L201.87 80.36L198.19 79.34L194.44 78.35L190.62 77.38L186.74 76.44L182.81 75.52L178.83 74.64L174.81 73.79L170.75 72.98L166.67 72.2L162.56 71.45L158.43 70.74L154.29 70.07L150.15 69.44L146.02 68.85L141.89 68.3L137.77 67.79L133.68 67.32L129.62 66.9L125.59 66.52L121.6 66.18L117.65 65.89L113.76 65.65L109.93 65.45L106.16 65.3L102.46 65.19L98.84 65.13L95.3 65.12L91.85 65.15L88.49 65.23L85.22 65.36L82.06 65.53L79.01 65.75L76.07 66.01L73.24 66.32L70.54 66.68L67.96 67.08L65.51 67.52L63.2 68L61.02 68.53L58.98 69.1L57.08 69.71L55.33 70.36L53.73 71.05L52.28 71.77L50.98 72.53L49.84 73.33L48.85 74.16L48.03 75.02L47.36 75.92L46.85 76.84L46.51 77.79L46.33 78.78L46.31 79.78L46.45 80.81L46.76 81.86L47.23 82.94L47.86 84.03L48.65 85.14L49.59 86.26L50.7 87.4L51.96 88.56L53.38 89.72L54.94 90.89L56.66 92.07L58.52 93.25L60.53 94.44L62.68 95.62L64.96 96.81L67.38 98L69.93 99.18L72.6 100.35L75.4 101.52L78.31 102.68L81.34 103.83L84.48 104.96L87.72 106.08L91.05 107.18L94.49 108.27L98.01 109.33L101.61 110.37L105.29 111.39L109.04 112.39L112.86 113.36L116.74 114.3L120.67 115.21L124.65 116.09"/>
<path class="fig-curve-alt" d="M120.46 88.86L125.1 89.84L129.79 90.78L134.51 91.69L139.25 92.55L144.02 93.36L148.79 94.14L153.57 94.87L158.35 95.55L163.12 96.19L167.87 96.78L172.59 97.32L177.29 97.8L181.94 98.24L186.55 98.63L191.1 98.96L195.6 99.25L200.02 99.48L204.37 99.65L208.64 99.78L212.82 99.85L216.91 99.86L220.9 99.82L224.78 99.73L228.55 99.58L232.2 99.38L235.72 99.13L239.12 98.83L242.38 98.47L245.5 98.06L248.48 97.6L251.31 97.09L253.98 96.53L256.5 95.92L258.85 95.26L261.04 94.56L263.07 93.81L264.92 93.01L266.59 92.18L268.09 91.3L269.41 90.38L270.55 89.42L271.5 88.42L272.27 87.39L272.85 86.32L273.25 85.22L273.46 84.09L273.48 82.93L273.32 81.74L272.96 80.52L272.42 79.28L271.7 78.02L270.79 76.74L269.69 75.44L268.41 74.12L266.96 72.79L265.32 71.45L263.51 70.1L261.53 68.74L259.38 67.37L257.06 66L254.58 64.63L251.95 63.26L249.15 61.89L246.21 60.53L243.12 59.17L239.89 57.82L236.53 56.49L233.03 55.16L229.41 53.85L225.67 52.56L221.82 51.29L217.85 50.04L213.79 48.81L209.63 47.6L205.38 46.42L201.05 45.28L196.64 44.16L192.16 43.07L187.62 42.02L183.02 41L178.38 40.02L173.69 39.08L168.98 38.18L164.23 37.31L159.47 36.5L154.69 35.72L149.91 34.99L145.13 34.31L140.36 33.67L135.61 33.08L130.89 32.54L126.19 32.06L121.54 31.62L116.93 31.23L112.38 30.9L107.89 30.61L103.46 30.38L99.11 30.21L94.84 30.08L90.66 30.02L86.57 30L82.58 30.04L78.7 30.13L74.93 30.28L71.28 30.48L67.76 30.73L64.36 31.03L61.1 31.39L57.98 31.8L55 32.26L52.17 32.77L49.5 33.33L46.98 33.94L44.63 34.6L42.44 35.3L40.42 36.05L38.57 36.85L36.89 37.68L35.39 38.56L34.07 39.48L32.94 40.44L31.98 41.44L31.21 42.47L30.63 43.54L30.23 44.64L30.02 45.77L30 46.93L30.17 48.12L30.52 49.34L31.06 50.58L31.79 51.84L32.7 53.12L33.79 54.42L35.07 55.74L36.52 57.07L38.16 58.41L39.97 59.76L41.95 61.12L44.1 62.49L46.42 63.86L48.9 65.23L51.53 66.6L54.33 67.97L57.27 69.33L60.36 70.69L63.59 72.04L66.95 73.37L70.45 74.7L74.07 76.01L77.81 77.3L81.67 78.57L85.63 79.83L89.69 81.05L93.85 82.26L98.1 83.44L102.44 84.58L106.84 85.7L111.32 86.79L115.86 87.84L120.46 88.86"/>
<path class="fig-curve" d="M183.02 41L182.24 47.61L181.46 54.07L180.68 60.37L179.9 66.52L179.11 72.53L178.33 78.37L177.55 84.07L176.77 89.61L175.98 95.01L175.2 100.25L174.42 105.33L173.64 110.27L172.86 115.05L172.07 119.68L171.29 124.16L170.51 128.49L169.73 132.66L168.95 136.69L168.16 140.56L167.38 144.27L166.6 147.84L165.82 151.25L165.04 154.51L164.25 157.62L163.47 160.58L162.69 163.39L161.91 166.04L161.13 168.54L160.34 170.89L159.56 173.08L158.78 175.13L158 177.02L157.22 178.76L156.43 180.35L155.65 181.78L154.87 183.06L154.09 184.2L153.3 185.17L152.52 186L151.74 186.68L150.96 187.2L150.18 187.57L149.39 187.79L148.61 187.85L147.83 187.76L147.05 187.53L146.27 187.13L145.48 186.59L144.7 185.9L143.92 185.05L143.14 184.05L142.36 182.9L141.57 181.59L140.79 180.14L140.01 178.53L139.23 176.77L138.45 174.86L137.66 172.79L136.88 170.57L136.1 168.2L135.32 165.68L134.54 163.01L133.75 160.18L132.97 157.2L132.19 154.07L131.41 150.79L130.63 147.36L129.84 143.77L129.06 140.03L128.28 136.14L127.5 132.1L126.71 127.9L125.93 123.55L125.15 119.05L124.37 114.4L123.59 109.6L122.8 104.64L122.02 99.53L121.24 94.27L120.46 88.86"/>
<path class="fig-curve" d="M34.07 39.48L37.02 46.13L39.96 52.63L42.9 58.97L45.84 65.16L48.78 71.2L51.72 77.08L54.67 82.82L57.61 88.4L60.55 93.83L63.49 99.11L66.43 104.23L69.37 109.21L72.32 114.03L75.26 118.7L78.2 123.21L81.14 127.58L84.08 131.79L87.02 135.85L89.97 139.76L92.91 143.52L95.85 147.12L98.79 150.57L101.73 153.87L104.67 157.02L107.62 160.01L110.56 162.85L113.5 165.55L116.44 168.08L119.38 170.47L122.32 172.7L125.27 174.79L128.21 176.72L131.15 178.49L134.09 180.12L137.03 181.59L139.97 182.91L142.92 184.08L145.86 185.1L148.8 185.96L151.74 186.68L154.68 187.24L157.62 187.64L160.57 187.9L163.51 188L166.45 187.95L169.39 187.75L172.33 187.4L175.27 186.89L178.22 186.24L181.16 185.43L184.1 184.47L187.04 183.35L189.98 182.09L192.92 180.67L195.87 179.1L198.81 177.37L201.75 175.5L204.69 173.47L207.63 171.29L210.57 168.96L213.52 166.48L216.46 163.84L219.4 161.06L222.34 158.12L225.28 155.02L228.22 151.78L231.17 148.38L234.11 144.83L237.05 141.13L239.99 137.28L242.93 133.27L245.87 129.12L248.82 124.81L251.76 120.34L254.7 115.73L257.64 110.96L260.58 106.05L263.52 100.98L266.47 95.75L269.41 90.38"/>
<path class="fig-axis" d="M109.52 218.97L109.51 218.98L109.52 218.98"/>
<path class="fig-axis" d="M289.98 216.58L290 216.58L289.98 216.56"/>
<path class="fig-axis" d="M151.75 40.6L151.74 40.58L151.73 40.6"/>
<circle class="fig-point" cx="151.74" cy="186.68" r="3.2"/>
<text class="fig-label-em" x="98.57" y="228.06">x</text>
<text class="fig-label-em" x="296.77" y="221.69">y</text>
<text class="fig-label-em" x="148.74" y="33.58">z</text>
</svg>
<figcaption>The elliptic paraboloid $z=x^2+y^2/4$: the horizontal traces $z=k$ are the ellipses $x^2+y^2/4=k$ (nothing below $z=0$, a single point at $k=0$), while the vertical traces $y=0$ and $x=0$ are the parabolas $z=x^2$ and $z=y^2/4$, so the surface is a bowl with vertex at the origin.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 244 300" width="244" height="300" role="img" aria-label="The cone z squared equals x squared plus y squared, drawn with horizontal circles and lines in the coordinate planes">
<path class="fig-axis" d="M115.7 150L63.39 190.02"/>
<path class="fig-axis" d="M115.7 150L214.09 171.28"/>
<path class="fig-axis" d="M115.7 150L115.7 36.45"/>
<path class="fig-curve-alt" d="M75.46 259.09L78.47 259.71L81.52 260.28L84.64 260.8L87.8 261.27L91 261.69L94.24 262.06L97.52 262.38L100.82 262.64L104.15 262.85L107.49 263.01L110.85 263.12L114.21 263.17L117.57 263.16L120.94 263.11L124.29 263L127.63 262.83L130.96 262.62L134.26 262.35L137.53 262.02L140.77 261.65L143.97 261.22L147.12 260.75L150.23 260.22L153.28 259.64L156.28 259.02L159.21 258.35L162.08 257.63L164.87 256.87L167.59 256.06L170.23 255.21L172.78 254.32L175.25 253.39L177.62 252.42L179.9 251.41L182.08 250.37L184.16 249.29L186.13 248.18L188 247.04L189.75 245.87L191.39 244.68L192.91 243.45L194.31 242.21L195.59 240.94L196.75 239.66L197.79 238.36L198.69 237.04L199.47 235.7L200.12 234.36L200.64 233.01L201.03 231.65L201.29 230.28L201.41 228.92L201.4 227.55L201.26 226.18L200.99 224.81L200.59 223.46L200.05 222.1L199.39 220.76L198.6 219.43L197.68 218.11L196.63 216.81L195.46 215.53L194.16 214.27L192.75 213.02L191.21 211.81L189.56 210.61L187.8 209.45L185.92 208.31L183.94 207.2L181.85 206.13L179.66 205.09L177.37 204.09L174.98 203.12L172.5 202.2L169.94 201.31L167.29 200.46L164.56 199.66L161.76 198.9L158.89 198.19L155.95 197.52L152.94 196.9L149.88 196.33L146.77 195.81L143.61 195.34L140.41 194.92L137.17 194.55L133.89 194.24L130.59 193.97L127.26 193.76L123.92 193.6L120.56 193.5L117.2 193.45L113.83 193.45L110.47 193.51L107.12 193.62L103.78 193.78L100.45 194L97.15 194.27L93.88 194.59L90.64 194.97L87.44 195.39L84.29 195.87L81.18 196.4L78.13 196.97L75.13 197.6L72.2 198.27L69.33 198.98L66.54 199.75L63.82 200.55L61.18 201.4L58.63 202.3L56.16 203.23L53.79 204.2L51.51 205.21L49.33 206.25L47.25 207.33L45.28 208.43L43.41 209.57L41.66 210.74L40.02 211.94L38.5 213.16L37.1 214.41L35.82 215.67L34.66 216.96L33.62 218.26L32.72 219.58L31.94 220.91L31.29 222.25L30.77 223.61L30.38 224.97L30.12 226.33L30 227.7L30.01 229.07L30.15 230.44L30.42 231.8L30.82 233.16L31.35 234.51L32.02 235.85L32.81 237.18L33.73 238.5L34.78 239.8L35.95 241.09L37.25 242.35L38.66 243.59L40.2 244.81L41.85 246L43.61 247.17L45.49 248.3L47.47 249.41L49.56 250.48L51.75 251.52L54.04 252.53L56.43 253.49L58.91 254.42L61.47 255.31L64.12 256.15L66.85 256.95L69.65 257.71L72.52 258.42L75.46 259.09"/>
<path class="fig-curve-alt" d="M95.58 204.55L97.09 204.85L98.61 205.14L100.17 205.4L101.75 205.64L103.35 205.85L104.97 206.03L106.61 206.19L108.26 206.32L109.93 206.43L111.6 206.51L113.28 206.56L114.96 206.58L116.64 206.58L118.32 206.55L120 206.5L121.67 206.42L123.33 206.31L124.98 206.17L126.62 206.01L128.24 205.82L129.84 205.61L131.41 205.37L132.97 205.11L134.49 204.82L135.99 204.51L137.46 204.17L138.89 203.81L140.29 203.43L141.65 203.03L142.97 202.6L144.24 202.16L145.48 201.69L146.66 201.21L147.8 200.7L148.89 200.18L149.93 199.64L150.92 199.09L151.85 198.52L152.73 197.94L153.55 197.34L154.31 196.73L155.01 196.1L155.65 195.47L156.23 194.83L156.75 194.18L157.2 193.52L157.59 192.85L157.91 192.18L158.17 191.5L158.37 190.82L158.49 190.14L158.56 189.46L158.55 188.77L158.48 188.09L158.35 187.41L158.15 186.73L157.88 186.05L157.55 185.38L157.15 184.72L156.69 184.06L156.17 183.41L155.58 182.76L154.93 182.13L154.23 181.51L153.46 180.9L152.63 180.31L151.75 179.72L150.81 179.15L149.82 178.6L148.78 178.07L147.68 177.55L146.54 177.04L145.34 176.56L144.1 176.1L142.82 175.65L141.5 175.23L140.13 174.83L138.73 174.45L137.3 174.09L135.83 173.76L134.32 173.45L132.79 173.17L131.24 172.91L129.66 172.67L128.06 172.46L126.44 172.28L124.8 172.12L123.15 171.99L121.48 171.88L119.81 171.8L118.13 171.75L116.45 171.72L114.77 171.73L113.09 171.75L111.41 171.81L109.74 171.89L108.08 172L106.43 172.13L104.79 172.3L103.17 172.48L101.57 172.7L100 172.93L98.44 173.2L96.92 173.49L95.42 173.8L93.95 174.13L92.52 174.49L91.12 174.87L89.76 175.28L88.44 175.7L87.17 176.15L85.93 176.61L84.75 177.1L83.61 177.6L82.52 178.12L81.48 178.66L80.49 179.22L79.56 179.79L78.68 180.37L77.86 180.97L77.1 181.58L76.4 182.2L75.76 182.84L75.18 183.48L74.66 184.13L74.21 184.79L73.82 185.45L73.5 186.13L73.24 186.8L73.04 187.48L72.91 188.17L72.85 188.85L72.86 189.53L72.93 190.22L73.06 190.9L73.26 191.58L73.53 192.26L73.86 192.93L74.26 193.59L74.72 194.25L75.24 194.9L75.83 195.54L76.48 196.17L77.18 196.8L77.95 197.4L78.78 198L79.66 198.58L80.6 199.15L81.59 199.71L82.63 200.24L83.73 200.76L84.87 201.26L86.07 201.75L87.31 202.21L88.59 202.65L89.91 203.08L91.28 203.48L92.68 203.86L94.11 204.21L95.58 204.55"/>
<path class="fig-curve-alt" d="M95.58 126.24L97.09 126.55L98.61 126.83L100.17 127.09L101.75 127.33L103.35 127.54L104.97 127.72L106.61 127.88L108.26 128.01L109.93 128.12L111.6 128.2L113.28 128.25L114.96 128.28L116.64 128.27L118.32 128.25L120 128.19L121.67 128.11L123.33 128L124.98 127.87L126.62 127.7L128.24 127.52L129.84 127.3L131.41 127.07L132.97 126.8L134.49 126.51L135.99 126.2L137.46 125.87L138.89 125.51L140.29 125.13L141.65 124.72L142.97 124.3L144.24 123.85L145.48 123.39L146.66 122.9L147.8 122.4L148.89 121.88L149.93 121.34L150.92 120.78L151.85 120.21L152.73 119.63L153.55 119.03L154.31 118.42L155.01 117.8L155.65 117.16L156.23 116.52L156.75 115.87L157.2 115.21L157.59 114.55L157.91 113.87L158.17 113.2L158.37 112.52L158.49 111.83L158.56 111.15L158.55 110.47L158.48 109.78L158.35 109.1L158.15 108.42L157.88 107.74L157.55 107.07L157.15 106.41L156.69 105.75L156.17 105.1L155.58 104.46L154.93 103.83L154.23 103.2L153.46 102.6L152.63 102L151.75 101.42L150.81 100.85L149.82 100.29L148.78 99.76L147.68 99.24L146.54 98.74L145.34 98.25L144.1 97.79L142.82 97.35L141.5 96.92L140.13 96.52L138.73 96.14L137.3 95.79L135.83 95.45L134.32 95.15L132.79 94.86L131.24 94.6L129.66 94.36L128.06 94.15L126.44 93.97L124.8 93.81L123.15 93.68L121.48 93.57L119.81 93.49L118.13 93.44L116.45 93.42L114.77 93.42L113.09 93.45L111.41 93.5L109.74 93.58L108.08 93.69L106.43 93.83L104.79 93.99L103.17 94.18L101.57 94.39L100 94.63L98.44 94.89L96.92 95.18L95.42 95.49L93.95 95.83L92.52 96.19L91.12 96.57L89.76 96.97L88.44 97.4L87.17 97.84L85.93 98.31L84.75 98.79L83.61 99.3L82.52 99.82L81.48 100.36L80.49 100.91L79.56 101.48L78.68 102.06L77.86 102.66L77.1 103.27L76.4 103.9L75.76 104.53L75.18 105.17L74.66 105.82L74.21 106.48L73.82 107.15L73.5 107.82L73.24 108.5L73.04 109.18L72.91 109.86L72.85 110.54L72.86 111.23L72.93 111.91L73.06 112.59L73.26 113.27L73.53 113.95L73.86 114.62L74.26 115.28L74.72 115.94L75.24 116.59L75.83 117.24L76.48 117.87L77.18 118.49L77.95 119.1L78.78 119.69L79.66 120.28L80.6 120.85L81.59 121.4L82.63 121.93L83.73 122.45L84.87 122.96L86.07 123.44L87.31 123.9L88.59 124.35L89.91 124.77L91.28 125.17L92.68 125.55L94.11 125.91L95.58 126.24"/>
<path class="fig-curve-alt" d="M75.46 102.48L78.47 103.1L81.52 103.67L84.64 104.19L87.8 104.66L91 105.08L94.24 105.45L97.52 105.76L100.82 106.03L104.15 106.24L107.49 106.4L110.85 106.5L114.21 106.55L117.57 106.55L120.94 106.49L124.29 106.38L127.63 106.22L130.96 106L134.26 105.73L137.53 105.41L140.77 105.03L143.97 104.61L147.12 104.13L150.23 103.6L153.28 103.03L156.28 102.4L159.21 101.73L162.08 101.02L164.87 100.25L167.59 99.45L170.23 98.6L172.78 97.7L175.25 96.77L177.62 95.8L179.9 94.79L182.08 93.75L184.16 92.67L186.13 91.57L188 90.43L189.75 89.26L191.39 88.06L192.91 86.84L194.31 85.59L195.59 84.33L196.75 83.04L197.79 81.74L198.69 80.42L199.47 79.09L200.12 77.75L200.64 76.39L201.03 75.03L201.29 73.67L201.41 72.3L201.4 70.93L201.26 69.56L200.99 68.2L200.59 66.84L200.05 65.49L199.39 64.15L198.6 62.82L197.68 61.5L196.63 60.2L195.46 58.91L194.16 57.65L192.75 56.41L191.21 55.19L189.56 54L187.8 52.83L185.92 51.7L183.94 50.59L181.85 49.52L179.66 48.48L177.37 47.47L174.98 46.51L172.5 45.58L169.94 44.69L167.29 43.85L164.56 43.05L161.76 42.29L158.89 41.58L155.95 40.91L152.94 40.29L149.88 39.72L146.77 39.2L143.61 38.73L140.41 38.31L137.17 37.94L133.89 37.62L130.59 37.36L127.26 37.15L123.92 36.99L120.56 36.88L117.2 36.83L113.83 36.84L110.47 36.89L107.12 37L103.78 37.17L100.45 37.38L97.15 37.65L93.88 37.98L90.64 38.35L87.44 38.78L84.29 39.25L81.18 39.78L78.13 40.36L75.13 40.98L72.2 41.65L69.33 42.37L66.54 43.13L63.82 43.94L61.18 44.79L58.63 45.68L56.16 46.61L53.79 47.58L51.51 48.59L49.33 49.63L47.25 50.71L45.28 51.82L43.41 52.96L41.66 54.13L40.02 55.32L38.5 56.55L37.1 57.79L35.82 59.06L34.66 60.34L33.62 61.64L32.72 62.96L31.94 64.3L31.29 65.64L30.77 66.99L30.38 68.35L30.12 69.72L30 71.08L30.01 72.45L30.15 73.82L30.42 75.19L30.82 76.54L31.35 77.9L32.02 79.24L32.81 80.57L33.73 81.89L34.78 83.19L35.95 84.47L37.25 85.73L38.66 86.98L40.2 88.19L41.85 89.39L43.61 90.55L45.49 91.69L47.47 92.8L49.56 93.87L51.75 94.91L54.04 95.91L56.43 96.88L58.91 97.8L61.47 98.69L64.12 99.54L66.85 100.34L69.65 101.1L72.52 101.81L75.46 102.48"/>
<path class="fig-curve" d="M159.97 202.28L157.76 199.66L155.54 197.05L153.33 194.43L151.12 191.82L148.9 189.21L146.69 186.59L144.48 183.98L142.26 181.37L140.05 178.75L137.84 176.14L135.62 173.52L133.41 170.91L131.2 168.3L128.98 165.68L126.77 163.07L124.56 160.46L122.34 157.84L120.13 155.23L117.92 152.61L115.7 150L113.49 147.39L111.28 144.77L109.06 142.16L106.85 139.54L104.64 136.93L102.43 134.32L100.21 131.7L98 129.09L95.79 126.48L93.57 123.86L91.36 121.25L89.15 118.63L86.93 116.02L84.72 113.41L82.51 110.79L80.29 108.18L78.08 105.57L75.87 102.95L73.65 100.34L71.44 97.72"/>
<path class="fig-curve" d="M159.97 30L157.76 36L155.54 42L153.33 48L151.12 54L148.9 60L146.69 66L144.48 72L142.26 78L140.05 84L137.84 90L135.62 96L133.41 102L131.2 108L128.98 114L126.77 120L124.56 126L122.34 132L120.13 138L117.92 144L115.7 150L113.49 156L111.28 162L109.06 168L106.85 174L104.64 180L102.43 186L100.21 192L98 198L95.79 204L93.57 210L91.36 216L89.15 222L86.93 228L84.72 234L82.51 240L80.29 246L78.08 252L75.87 258L73.65 264L71.44 270"/>
<path class="fig-curve" d="M32.45 218.13L36.61 214.73L40.78 211.32L44.94 207.91L49.1 204.51L53.27 201.1L57.43 197.69L61.59 194.29L65.75 190.88L69.92 187.47L74.08 184.07L78.24 180.66L82.4 177.25L86.57 173.85L90.73 170.44L94.89 167.03L99.05 163.63L103.22 160.22L107.38 156.81L111.54 153.41L115.7 150L119.87 146.59L124.03 143.19L128.19 139.78L132.36 136.37L136.52 132.97L140.68 129.56L144.84 126.15L149.01 122.75L153.17 119.34L157.33 115.93L161.49 112.53L165.66 109.12L169.82 105.71L173.98 102.31L178.14 98.9L182.31 95.49L186.47 92.09L190.63 88.68L194.8 85.27L198.96 81.87"/>
<path class="fig-curve" d="M32.45 45.86L36.61 51.06L40.78 56.27L44.94 61.48L49.1 66.69L53.27 71.89L57.43 77.1L61.59 82.31L65.75 87.51L69.92 92.72L74.08 97.93L78.24 103.14L82.4 108.34L86.57 113.55L90.73 118.76L94.89 123.96L99.05 129.17L103.22 134.38L107.38 139.59L111.54 144.79L115.7 150L119.87 155.21L124.03 160.41L128.19 165.62L132.36 170.83L136.52 176.04L140.68 181.24L144.84 186.45L149.01 191.66L153.17 196.86L157.33 202.07L161.49 207.28L165.66 212.49L169.82 217.69L173.98 222.9L178.14 228.11L182.31 233.31L186.47 238.52L190.63 243.73L194.8 248.94L198.96 254.14"/>
<path class="fig-axis" d="M63.4 190L63.39 190.02L63.41 190.01"/>
<path class="fig-axis" d="M214.07 171.28L214.09 171.28L214.07 171.26"/>
<path class="fig-axis" d="M115.71 36.48L115.7 36.45L115.7 36.48"/>
<circle class="fig-point" cx="115.7" cy="150" r="3.2"/>
<text class="fig-label-em" x="52.45" y="199.09">x</text>
<text class="fig-label-em" x="220.87" y="176.39">y</text>
<text class="fig-label-em" x="112.7" y="29.45">z</text>
</svg>
<figcaption>The cone $z^2=x^2+y^2$: each horizontal trace $z=k$ is a circle of radius $|k|$ that shrinks to the origin at $k=0$, and the vertical traces $y=0$ and $x=0$ are the pairs of crossing lines $z=\pm x$ and $z=\pm y$.</figcaption>
</figure>

</div>

Now the two hyperboloids and the saddle. The one-sheet hyperboloid is a single connected piece with a waist, and the two-sheet hyperboloid is two separate bowls with a gap between them. They look alike from far away, so learn to tell them apart from the equation. The last picture is the hyperbolic paraboloid, the saddle.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 285 300" width="285" height="300" role="img" aria-label="The one-sheet hyperboloid x squared plus y squared minus z squared equals 1, drawn with horizontal circles and two hyperbolas">
<path class="fig-axis" d="M131.56 150L65.85 200.27"/>
<path class="fig-axis" d="M131.56 150L255.15 176.73"/>
<path class="fig-axis" d="M131.56 150L131.56 36.88"/>
<path class="fig-guide" d="M224.54 212.05L222.86 210.58L221.04 209.14L219.08 207.72L216.99 206.34L214.77 204.99L212.42 203.68L209.94 202.41L207.35 201.18L204.63 199.99L201.8 198.85L198.87 197.75L195.83 196.7L192.69 195.69L189.46 194.74L186.14 193.85L182.73 193L179.25 192.21L175.69 191.48L172.07 190.8L168.38 190.18L164.63 189.63L160.84 189.13L157 188.69L153.11 188.32L149.2 188L145.26 187.75L141.3 187.57L137.32 187.44L133.34 187.38L129.35 187.39L125.36 187.45L121.39 187.58L117.43 187.78L113.49 188.03L109.58 188.35L105.7 188.74L101.86 189.18L98.07 189.69L94.33 190.25L90.65 190.87L87.03 191.56L83.48 192.3L80.01 193.09L76.61 193.94L73.3 194.85L70.08 195.8L66.95 196.81L63.92 197.87L61 198.97L58.19 200.12L55.49 201.31L52.9 202.55L50.44 203.83L48.1 205.14L45.89 206.49L43.82 207.88L41.87 209.29L40.07 210.74L38.41 212.22L36.89 213.72"/>
<path class="fig-guide" d="M203.44 188.97L202.4 187.83L201.25 186.71L199.99 185.61L198.63 184.52L197.16 183.46L195.6 182.43L193.93 181.42L192.17 180.44L190.31 179.48L188.36 178.56L186.33 177.67L184.21 176.81L182.01 175.99L179.73 175.2L177.38 174.45L174.96 173.74L172.47 173.06L169.92 172.43L167.31 171.84L164.64 171.29L161.92 170.78L159.16 170.32L156.35 169.9L153.5 169.53L150.63 169.2L147.72 168.92L144.78 168.69L141.83 168.5L138.86 168.36L135.88 168.26L132.89 168.22L129.9 168.22L126.91 168.27L123.93 168.37L120.97 168.52L118.01 168.71L115.08 168.95L112.18 169.24L109.3 169.57L106.46 169.95L103.66 170.37L100.9 170.84L98.19 171.35L95.53 171.9L92.92 172.5L90.37 173.14L87.89 173.81L85.48 174.53L83.13 175.29L80.86 176.08L78.67 176.91L76.56 177.77L74.54 178.66L72.6 179.59L70.76 180.55L69.01 181.53L67.35 182.54L65.79 183.58L64.34 184.64L62.99 185.73L61.74 186.83L60.6 187.96L59.57 189.1L58.66 190.26"/>
<path class="fig-guide" d="M185.39 149.52L185.3 148.66L185.13 147.81L184.87 146.95L184.54 146.1L184.12 145.26L183.62 144.42L183.05 143.6L182.39 142.78L181.65 141.97L180.84 141.18L179.95 140.4L178.99 139.64L177.95 138.89L176.84 138.15L175.66 137.44L174.42 136.75L173.1 136.07L171.73 135.42L170.29 134.79L168.79 134.18L167.24 133.6L165.62 133.04L163.96 132.51L162.25 132.01L160.49 131.53L158.68 131.08L156.84 130.67L154.95 130.28L153.03 129.92L151.07 129.59L149.09 129.3L147.08 129.03L145.04 128.8L142.99 128.6L140.91 128.44L138.82 128.3L136.72 128.2L134.61 128.14L132.5 128.11L130.39 128.11L128.28 128.14L126.17 128.21L124.07 128.32L121.98 128.45L119.91 128.62L117.86 128.82L115.82 129.06L113.81 129.33L111.83 129.63L109.88 129.96L107.96 130.32L106.08 130.71L104.24 131.13L102.44 131.58L100.68 132.06L98.98 132.57L97.32 133.1L95.71 133.66L94.16 134.25L92.67 134.86L91.24 135.49L89.87 136.15L88.57 136.82L87.33 137.52L86.16 138.23L85.06 138.97L84.03 139.72L83.07 140.49L82.19 141.27L81.39 142.06L80.66 142.87L80.01 143.69L79.44 144.52L78.95 145.35L78.54 146.2L78.22 147.05L77.97 147.9L77.81 148.76L77.73 149.62L77.74 150.48"/>
<path class="fig-guide" d="M204.47 109.74L205.27 108.57L205.96 107.39L206.54 106.2L207 104.99L207.35 103.79L207.58 102.57L207.69 101.36L207.68 100.14L207.56 98.93L207.32 97.72L206.96 96.51L206.48 95.31L205.89 94.12L205.19 92.93L204.37 91.76L203.44 90.61L202.4 89.47L201.25 88.35L199.99 87.24L198.63 86.16L197.16 85.1L195.6 84.07L193.93 83.06L192.17 82.07L190.31 81.12L188.36 80.2L186.33 79.31L184.21 78.45L182.01 77.63L179.73 76.84L177.38 76.09L174.96 75.37L172.47 74.7L169.92 74.07L167.31 73.48L164.64 72.93L161.92 72.42L159.16 71.96L156.35 71.54L153.5 71.16L150.63 70.84L147.72 70.56L144.78 70.32L141.83 70.13L138.86 69.99L135.88 69.9L132.89 69.86L129.9 69.86L126.91 69.91L123.93 70.01L120.97 70.15L118.01 70.35L115.08 70.59L112.18 70.87L109.3 71.2L106.46 71.58L103.66 72.01L100.9 72.47L98.19 72.99L95.53 73.54L92.92 74.14L90.37 74.77L87.89 75.45L85.48 76.17L83.13 76.92L80.86 77.71L78.67 78.54L76.56 79.4L74.54 80.3L72.6 81.23L70.76 82.18L69.01 83.17L67.35 84.18L65.79 85.22L64.34 86.28L62.99 87.36L61.74 88.47L60.6 89.59L59.57 90.74L58.66 91.89L57.85 93.06L57.16 94.25L56.58 95.44L56.12 96.64L55.78 97.85L55.55 99.06L55.44 100.28L55.44 101.49L55.57 102.71L55.81 103.92L56.17 105.13L56.64 106.33L57.23 107.52L57.94 108.7L58.75 109.87L59.68 111.03"/>
<path class="fig-guide" d="M226.23 86.28L227.61 84.76L228.83 83.22L229.9 81.65L230.83 80.08L231.6 78.48L232.21 76.88L232.67 75.27L232.98 73.65L233.12 72.03L233.12 70.41L232.95 68.79L232.63 67.17L232.15 65.56L231.52 63.96L230.73 62.37L229.79 60.79L228.7 59.23L227.46 57.69L226.07 56.17L224.54 54.67L222.86 53.2L221.04 51.75L219.08 50.34L216.99 48.96L214.77 47.61L212.42 46.3L209.94 45.03L207.35 43.8L204.63 42.61L201.8 41.46L198.87 40.37L195.83 39.31L192.69 38.31L189.46 37.36L186.14 36.46L182.73 35.62L179.25 34.83L175.69 34.1L172.07 33.42L168.38 32.8L164.63 32.24L160.84 31.75L157 31.31L153.11 30.93L149.2 30.62L145.26 30.37L141.3 30.18L137.32 30.06L133.34 30L129.35 30L125.36 30.07L121.39 30.2L117.43 30.4L113.49 30.65L109.58 30.97L105.7 31.36L101.86 31.8L98.07 32.3L94.33 32.87L90.65 33.49L87.03 34.18L83.48 34.91L80.01 35.71L76.61 36.56L73.3 37.47L70.08 38.42L66.95 39.43L63.92 40.49L61 41.59L58.19 42.74L55.49 43.93L52.9 45.17L50.44 46.44L48.1 47.76L45.89 49.11L43.82 50.5L41.87 51.91L40.07 53.36L38.41 54.83L36.89 56.33L35.52 57.86L34.29 59.4L33.22 60.96L32.3 62.54L31.53 64.13L30.91 65.74L30.45 67.35L30.15 68.97L30 70.59L30.01 72.21L30.17 73.83L30.5 75.45L30.97 77.06L31.61 78.66L32.39 80.25L33.33 81.83L34.42 83.39L35.66 84.93L37.05 86.45L38.59 87.95"/>
<path class="fig-guide" d="M179.25 192.21L178.11 190.46L176.99 188.7L175.87 186.93L174.77 185.14L173.69 183.35L172.62 181.55L171.56 179.73L170.53 177.9L169.51 176.05L168.52 174.19L167.55 172.31L166.6 170.41L165.68 168.49L164.79 166.55L163.93 164.59L163.11 162.59L162.32 160.57L161.57 158.52L160.87 156.44L160.21 154.32L159.6 152.16L159.04 149.96L158.54 147.72L158.1 145.44L157.72 143.11L157.41 140.72L157.16 138.29L156.98 135.8L156.87 133.26L156.84 130.67L156.87 128.02L156.98 125.31L157.16 122.55L157.41 119.74L157.72 116.88L158.1 113.96L158.54 111L159.04 108L159.6 104.95L160.21 101.86L160.87 98.73L161.57 95.57L162.32 92.37L163.11 89.15L163.93 85.89L164.79 82.61L165.68 79.31L166.6 75.98L167.55 72.64L168.52 69.27L169.51 65.89L170.53 62.49L171.56 59.07L172.62 55.64L173.69 52.2L174.77 48.75L175.87 45.28L176.99 41.81L178.11 38.32L179.25 34.83"/>
<path class="fig-guide" d="M41.87 209.29L44.01 207.13L46.13 204.97L48.23 202.8L50.3 200.62L52.34 198.44L54.35 196.25L56.33 194.06L58.28 191.86L60.19 189.65L62.06 187.43L63.89 185.2L65.67 182.96L67.4 180.72L69.07 178.45L70.69 176.18L72.24 173.89L73.72 171.59L75.13 169.27L76.45 166.93L77.69 164.58L78.84 162.2L79.88 159.81L80.82 157.39L81.65 154.94L82.37 152.48L82.96 149.98L83.42 147.46L83.76 144.91L83.96 142.33L84.03 139.72L83.96 137.08L83.76 134.42L83.42 131.72L82.96 129L82.37 126.25L81.65 123.47L80.82 120.67L79.88 117.84L78.84 114.99L77.69 112.12L76.45 109.23L75.13 106.32L73.72 103.39L72.24 100.45L70.69 97.49L69.07 94.52L67.4 91.53L65.67 88.54L63.89 85.53L62.06 82.51L60.19 79.48L58.28 76.44L56.33 73.4L54.35 70.35L52.34 67.29L50.3 64.23L48.23 61.16L46.13 58.08L44.01 55L41.87 51.91"/>
<path class="fig-curve-alt" d="M83.87 265.17L87.43 265.9L91.06 266.58L94.75 267.2L98.49 267.76L102.29 268.25L106.13 268.69L110.01 269.07L113.92 269.38L117.86 269.63L121.83 269.82L125.8 269.94L129.79 270L133.78 270L137.76 269.93L141.74 269.8L145.7 269.6L149.64 269.35L153.55 269.03L157.42 268.64L161.26 268.2L165.05 267.7L168.79 267.13L172.47 266.51L176.09 265.82L179.64 265.09L183.12 264.29L186.51 263.44L189.83 262.53L193.05 261.58L196.17 260.57L199.2 259.51L202.12 258.41L204.94 257.26L207.64 256.07L210.22 254.83L212.69 253.56L215.02 252.24L217.23 250.89L219.31 249.5L221.25 248.09L223.05 246.64L224.72 245.17L226.23 243.67L227.61 242.14L228.83 240.6L229.9 239.04L230.83 237.46L231.6 235.87L232.21 234.26L232.67 232.65L232.98 231.03L233.12 229.41L233.12 227.79L232.95 226.17L232.63 224.55L232.15 222.94L231.52 221.34L230.73 219.75L229.79 218.17L228.7 216.61L227.46 215.07L226.07 213.55L224.54 212.05"/>
<path class="fig-curve-alt" d="M36.89 213.72L35.52 215.24L34.29 216.78L33.22 218.35L32.3 219.92L31.53 221.52L30.91 223.12L30.45 224.73L30.15 226.35L30 227.97L30.01 229.59L30.17 231.21L30.5 232.83L30.97 234.44L31.61 236.04L32.39 237.63L33.33 239.21L34.42 240.77L35.66 242.31L37.05 243.83L38.59 245.33L40.26 246.8L42.08 248.25L44.04 249.66L46.13 251.04L48.35 252.39L50.71 253.7L53.18 254.97L55.78 256.2L58.49 257.39L61.32 258.54L64.25 259.63L67.29 260.69L70.43 261.69L73.66 262.64L76.98 263.54L80.39 264.38L83.87 265.17"/>
<path class="fig-curve-alt" d="M95.82 226.52L98.49 227.07L101.2 227.58L103.97 228.04L106.77 228.46L109.62 228.84L112.5 229.16L115.41 229.44L118.34 229.68L121.3 229.87L124.27 230.01L127.25 230.1L130.23 230.14L133.22 230.14L136.21 230.09L139.19 229.99L142.16 229.85L145.11 229.65L148.04 229.41L150.95 229.13L153.82 228.8L156.66 228.42L159.47 227.99L162.23 227.53L164.94 227.01L167.6 226.46L170.2 225.86L172.75 225.23L175.23 224.55L177.65 223.83L179.99 223.08L182.26 222.29L184.45 221.46L186.56 220.6L188.58 219.7L190.52 218.77L192.37 217.82L194.12 216.83L195.77 215.82L197.33 214.78L198.79 213.72L200.14 212.64L201.38 211.53L202.52 210.41L203.55 209.26L204.47 208.11L205.27 206.94L205.96 205.75L206.54 204.56L207 203.36L207.35 202.15L207.58 200.94L207.69 199.72L207.68 198.51L207.56 197.29L207.32 196.08L206.96 194.87L206.48 193.67L205.89 192.48L205.19 191.3L204.37 190.13L203.44 188.97"/>
<path class="fig-curve-alt" d="M58.66 190.26L57.85 191.43L57.16 192.61L56.58 193.8L56.12 195.01L55.78 196.21L55.55 197.43L55.44 198.64L55.44 199.86L55.57 201.07L55.81 202.28L56.17 203.49L56.64 204.69L57.23 205.88L57.94 207.07L58.75 208.24L59.68 209.39L60.72 210.53L61.87 211.65L63.13 212.76L64.5 213.84L65.96 214.9L67.53 215.93L69.2 216.94L70.96 217.93L72.81 218.88L74.76 219.8L76.79 220.69L78.91 221.55L81.11 222.37L83.39 223.16L85.74 223.91L88.17 224.63L90.65 225.3L93.21 225.93L95.82 226.52"/>
<path class="fig-curve-alt" d="M95.82 128.16L98.49 128.71L101.2 129.22L103.97 129.68L106.77 130.1L109.62 130.47L112.5 130.8L115.41 131.08L118.34 131.31L121.3 131.5L124.27 131.64L127.25 131.74L130.23 131.78L133.22 131.78L136.21 131.73L139.19 131.63L142.16 131.48L145.11 131.29L148.04 131.05L150.95 130.76L153.82 130.43L156.66 130.05L159.47 129.63L162.23 129.16L164.94 128.65L167.6 128.1L170.2 127.5L172.75 126.86L175.23 126.19L177.65 125.47L179.99 124.71L182.26 123.92L184.45 123.09L186.56 122.23L188.58 121.34L190.52 120.41L192.37 119.45L194.12 118.47L195.77 117.46L197.33 116.42L198.79 115.36L200.14 114.27L201.38 113.17L202.52 112.04L203.55 110.9L204.47 109.74"/>
<path class="fig-curve-alt" d="M59.68 111.03L60.72 112.17L61.87 113.29L63.13 114.39L64.5 115.48L65.96 116.54L67.53 117.57L69.2 118.58L70.96 119.56L72.81 120.52L74.76 121.44L76.79 122.33L78.91 123.19L81.11 124.01L83.39 124.8L85.74 125.55L88.17 126.26L90.65 126.94L93.21 127.57L95.82 128.16"/>
<path class="fig-curve-alt" d="M83.87 107.79L87.43 108.52L91.06 109.2L94.75 109.82L98.49 110.37L102.29 110.87L106.13 111.31L110.01 111.68L113.92 112L117.86 112.25L121.83 112.43L125.8 112.56L129.79 112.62L133.78 112.61L137.76 112.55L141.74 112.42L145.7 112.22L149.64 111.97L153.55 111.65L157.42 111.26L161.26 110.82L165.05 110.31L168.79 109.75L172.47 109.13L176.09 108.44L179.64 107.7L183.12 106.91L186.51 106.06L189.83 105.15L193.05 104.2L196.17 103.19L199.2 102.13L202.12 101.03L204.94 99.88L207.64 98.69L210.22 97.45L212.69 96.17L215.02 94.86L217.23 93.51L219.31 92.12L221.25 90.71L223.05 89.26L224.72 87.78L226.23 86.28"/>
<path class="fig-curve-alt" d="M38.59 87.95L40.26 89.42L42.08 90.86L44.04 92.28L46.13 93.66L48.35 95.01L50.71 96.32L53.18 97.59L55.78 98.82L58.49 100.01L61.32 101.15L64.25 102.25L67.29 103.3L70.43 104.31L73.66 105.26L76.98 106.15L80.39 107L83.87 107.79"/>
<path class="fig-curve" d="M106.29 169.33L108.17 169.72L110.1 170.08L112.05 170.41L114.04 170.7L116.05 170.97L118.08 171.2L120.14 171.4L122.21 171.56L124.3 171.7L126.4 171.8L128.51 171.86L130.62 171.89L132.74 171.89L134.85 171.86L136.96 171.79L139.05 171.68L141.14 171.55L143.21 171.38L145.27 171.18L147.3 170.94L149.31 170.67L151.29 170.37L153.24 170.04L155.16 169.68L157.04 169.29L158.89 168.87L160.69 168.42L162.44 167.94L164.15 167.43L165.81 166.9L167.41 166.34L168.96 165.75L170.45 165.14L171.88 164.51L173.25 163.85L174.56 163.18L175.8 162.48L176.97 161.77L178.07 161.03L179.1 160.28L180.05 159.51L180.93 158.73L181.74 157.94L182.47 157.13L183.11 156.31L183.68 155.48L184.17 154.65L184.58 153.8L184.91 152.95L185.15 152.1L185.31 151.24L185.39 150.38L185.39 149.52"/>
<path class="fig-curve" d="M77.74 150.48L77.83 151.34L78 152.19L78.25 153.05L78.59 153.9L79 154.74L79.5 155.58L80.08 156.4L80.74 157.22L81.47 158.03L82.29 158.82L83.17 159.6L84.14 160.36L85.18 161.11L86.28 161.85L87.46 162.56L88.71 163.25L90.02 163.93L91.4 164.58L92.84 165.21L94.33 165.82L95.89 166.4L97.5 166.96L99.16 167.49L100.88 167.99L102.64 168.47L104.44 168.92L106.29 169.33"/>
<path class="fig-curve" d="M83.87 265.17L85.01 261.68L86.14 258.19L87.25 254.72L88.35 251.25L89.44 247.8L90.51 244.36L91.56 240.93L92.6 237.51L93.61 234.11L94.61 230.73L95.58 227.36L96.53 224.02L97.45 220.69L98.34 217.39L99.2 214.11L100.02 210.85L100.81 207.63L101.55 204.43L102.26 201.27L102.92 198.14L103.53 195.05L104.08 192L104.58 189L105.03 186.04L105.4 183.12L105.72 180.26L105.97 177.45L106.14 174.69L106.25 171.98L106.29 169.33L106.25 166.74L106.14 164.2L105.97 161.71L105.72 159.28L105.4 156.89L105.03 154.56L104.58 152.28L104.08 150.04L103.53 147.84L102.92 145.68L102.26 143.56L101.55 141.48L100.81 139.43L100.02 137.41L99.2 135.41L98.34 133.45L97.45 131.51L96.53 129.59L95.58 127.69L94.61 125.81L93.61 123.95L92.6 122.1L91.56 120.27L90.51 118.45L89.44 116.65L88.35 114.86L87.25 113.07L86.14 111.3L85.01 109.54L83.87 107.79"/>
<path class="fig-curve" d="M221.25 248.09L219.11 245L216.99 241.92L214.9 238.84L212.83 235.77L210.79 232.71L208.77 229.65L206.79 226.6L204.84 223.56L202.93 220.52L201.06 217.49L199.24 214.47L197.46 211.46L195.73 208.47L194.05 205.48L192.44 202.51L190.89 199.55L189.4 196.61L188 193.68L186.67 190.77L185.43 187.88L184.29 185.01L183.24 182.16L182.3 179.33L181.47 176.53L180.76 173.75L180.17 171L179.7 168.28L179.37 165.58L179.16 162.92L179.1 160.28L179.16 157.67L179.37 155.09L179.7 152.54L180.17 150.02L180.76 147.52L181.47 145.06L182.3 142.61L183.24 140.19L184.29 137.8L185.43 135.42L186.67 133.07L188 130.73L189.4 128.41L190.89 126.11L192.44 123.82L194.05 121.55L195.73 119.28L197.46 117.04L199.24 114.8L201.06 112.57L202.93 110.35L204.84 108.14L206.79 105.94L208.77 103.75L210.79 101.56L212.83 99.38L214.9 97.2L216.99 95.03L219.11 92.87L221.25 90.71"/>
<path class="fig-axis" d="M65.86 200.25L65.85 200.27L65.87 200.26"/>
<path class="fig-axis" d="M255.12 176.73L255.15 176.73L255.13 176.71"/>
<path class="fig-axis" d="M131.57 36.91L131.56 36.88L131.55 36.91"/>
<text class="fig-label-em" x="54.91" y="209.34">x</text>
<text class="fig-label-em" x="261.93" y="181.84">y</text>
<text class="fig-label-em" x="128.56" y="29.88">z</text>
</svg>
<figcaption>The hyperboloid of one sheet $x^2+y^2-z^2=1$: every horizontal trace $z=k$ is a circle of radius $\sqrt{1+k^2}$, smallest ($1$) at the waist $z=0$ and widening in both directions, and the vertical traces $y=0$ and $x=0$ are the hyperbolas $x^2-z^2=1$ and $y^2-z^2=1$.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 238 300" width="238" height="300" role="img" aria-label="The two-sheet hyperboloid z squared minus x squared minus y squared equals 1, drawn with horizontal circles and hyperbolas">
<path class="fig-axis" d="M112.09 150L60.91 189.15"/>
<path class="fig-axis" d="M112.09 150L208.36 170.82"/>
<path class="fig-axis" d="M112.09 150L112.09 33.08"/>
<path class="fig-curve-alt" d="M73.55 266.1L76.42 266.69L79.35 267.24L82.33 267.73L85.36 268.19L88.43 268.59L91.53 268.94L94.67 269.24L97.83 269.5L101.02 269.7L104.22 269.85L107.44 269.95L110.66 270L113.88 270L117.1 269.94L120.32 269.84L123.52 269.68L126.7 269.47L129.86 269.21L133 268.9L136.1 268.55L139.16 268.14L142.18 267.68L145.16 267.18L148.08 266.63L150.95 266.03L153.76 265.38L156.51 264.7L159.19 263.97L161.79 263.19L164.32 262.38L166.76 261.52L169.13 260.63L171.4 259.7L173.59 258.74L175.67 257.74L177.66 256.71L179.55 255.65L181.34 254.55L183.02 253.43L184.59 252.29L186.04 251.12L187.39 249.93L188.61 248.71L189.72 247.48L190.71 246.23L191.58 244.97L192.33 243.7L192.95 242.41L193.45 241.11L193.82 239.81L194.07 238.5L194.18 237.19L194.18 235.88L194.04 234.57L193.78 233.26L193.4 231.96L192.89 230.67L192.25 229.38L191.49 228.11L190.61 226.85L189.61 225.6L188.48 224.37L187.24 223.16L185.89 221.97L184.42 220.8L182.84 219.66L181.15 218.54L179.35 217.46L177.45 216.4L175.45 215.37L173.35 214.37L171.15 213.41L168.87 212.49L166.5 211.6L164.04 210.75L161.5 209.94L158.89 209.17L156.21 208.44L153.45 207.76L150.64 207.12L147.76 206.53L144.83 205.98L141.85 205.49L138.82 205.03L135.75 204.63L132.65 204.28L129.51 203.98L126.35 203.72L123.16 203.52L119.96 203.37L116.75 203.27L113.53 203.22L110.3 203.22L107.08 203.28L103.87 203.38L100.67 203.54L97.48 203.75L94.32 204.01L91.19 204.32L88.09 204.67L85.02 205.08L82 205.54L79.02 206.04L76.1 206.59L73.23 207.19L70.42 207.84L67.68 208.52L65 209.25L62.39 210.03L59.87 210.84L57.42 211.7L55.06 212.59L52.78 213.52L50.6 214.48L48.51 215.48L46.52 216.51L44.63 217.57L42.85 218.67L41.17 219.79L39.6 220.93L38.14 222.1L36.8 223.29L35.57 224.51L34.46 225.74L33.47 226.99L32.6 228.25L31.86 229.52L31.23 230.81L30.74 232.11L30.37 233.41L30.12 234.72L30 236.03L30.01 237.34L30.14 238.65L30.4 239.96L30.79 241.26L31.3 242.55L31.93 243.84L32.69 245.11L33.58 246.37L34.58 247.62L35.7 248.85L36.94 250.06L38.3 251.25L39.77 252.42L41.35 253.56L43.04 254.68L44.84 255.76L46.74 256.82L48.74 257.85L50.84 258.85L53.03 259.81L55.32 260.73L57.69 261.62L60.14 262.47L62.68 263.28L65.29 264.05L67.98 264.78L70.73 265.46L73.55 266.1"/>
<path class="fig-curve-alt" d="M87.21 233.99L89.07 234.37L90.96 234.73L92.88 235.05L94.84 235.34L96.82 235.6L98.82 235.83L100.85 236.02L102.89 236.19L104.95 236.32L107.01 236.41L109.09 236.48L111.17 236.51L113.25 236.51L115.33 236.47L117.4 236.41L119.47 236.3L121.52 236.17L123.56 236L125.59 235.8L127.59 235.57L129.57 235.31L131.52 235.01L133.44 234.69L135.33 234.33L137.18 233.95L138.99 233.53L140.76 233.09L142.49 232.62L144.17 232.12L145.8 231.59L147.38 231.04L148.91 230.46L150.38 229.86L151.79 229.24L153.13 228.6L154.42 227.93L155.64 227.24L156.79 226.54L157.87 225.82L158.89 225.08L159.83 224.32L160.7 223.55L161.49 222.77L162.2 221.98L162.84 221.17L163.4 220.35L163.88 219.53L164.29 218.7L164.61 217.86L164.85 217.02L165.01 216.18L165.08 215.33L165.08 214.49L164.99 213.64L164.82 212.8L164.57 211.96L164.24 211.12L163.83 210.29L163.34 209.47L162.77 208.66L162.13 207.85L161.4 207.06L160.6 206.28L159.73 205.51L158.78 204.75L157.76 204.02L156.67 203.3L155.51 202.59L154.28 201.91L152.99 201.25L151.63 200.6L150.22 199.98L148.74 199.39L147.21 198.81L145.62 198.26L143.99 197.74L142.3 197.25L140.57 196.78L138.79 196.34L136.97 195.92L135.12 195.54L133.23 195.19L131.3 194.87L129.35 194.58L127.37 194.32L125.36 194.09L123.34 193.89L121.3 193.73L119.24 193.6L117.17 193.5L115.1 193.44L113.02 193.4L110.94 193.41L108.86 193.44L106.78 193.51L104.72 193.61L102.66 193.75L100.62 193.91L98.6 194.11L96.6 194.34L94.62 194.61L92.67 194.9L90.75 195.23L88.86 195.58L87.01 195.97L85.19 196.38L83.42 196.83L81.69 197.3L80.01 197.8L78.38 198.32L76.8 198.88L75.28 199.45L73.81 200.05L72.4 200.67L71.05 201.32L69.77 201.98L68.55 202.67L67.39 203.38L66.31 204.1L65.3 204.84L64.36 205.59L63.49 206.36L62.7 207.14L61.98 207.94L61.34 208.75L60.78 209.56L60.3 210.38L59.9 211.21L59.58 212.05L59.34 212.89L59.18 213.74L59.1 214.58L59.11 215.43L59.19 216.27L59.36 217.12L59.61 217.96L59.94 218.79L60.35 219.62L60.84 220.45L61.41 221.26L62.06 222.06L62.78 222.86L63.58 223.64L64.46 224.41L65.41 225.16L66.43 225.9L67.52 226.62L68.68 227.32L69.91 228.01L71.2 228.67L72.55 229.31L73.97 229.93L75.44 230.53L76.97 231.1L78.56 231.65L80.2 232.17L81.88 232.67L83.62 233.14L85.39 233.58L87.21 233.99"/>
<path class="fig-curve-alt" d="M87.21 104.08L89.07 104.46L90.96 104.81L92.88 105.13L94.84 105.42L96.82 105.68L98.82 105.91L100.85 106.11L102.89 106.27L104.95 106.4L107.01 106.5L109.09 106.56L111.17 106.6L113.25 106.59L115.33 106.56L117.4 106.49L119.47 106.39L121.52 106.25L123.56 106.09L125.59 105.89L127.59 105.66L129.57 105.39L131.52 105.1L133.44 104.77L135.33 104.42L137.18 104.03L138.99 103.62L140.76 103.17L142.49 102.7L144.17 102.2L145.8 101.68L147.38 101.12L148.91 100.55L150.38 99.95L151.79 99.33L153.13 98.68L154.42 98.02L155.64 97.33L156.79 96.62L157.87 95.9L158.89 95.16L159.83 94.41L160.7 93.64L161.49 92.86L162.2 92.06L162.84 91.25L163.4 90.44L163.88 89.62L164.29 88.79L164.61 87.95L164.85 87.11L165.01 86.26L165.08 85.42L165.08 84.57L164.99 83.73L164.82 82.88L164.57 82.04L164.24 81.21L163.83 80.38L163.34 79.55L162.77 78.74L162.13 77.94L161.4 77.14L160.6 76.36L159.73 75.59L158.78 74.84L157.76 74.1L156.67 73.38L155.51 72.68L154.28 71.99L152.99 71.33L151.63 70.69L150.22 70.07L148.74 69.47L147.21 68.9L145.62 68.35L143.99 67.83L142.3 67.33L140.57 66.86L138.79 66.42L136.97 66.01L135.12 65.63L133.23 65.27L131.3 64.95L129.35 64.66L127.37 64.4L125.36 64.17L123.34 63.98L121.3 63.81L119.24 63.68L117.17 63.59L115.1 63.52L113.02 63.49L110.94 63.49L108.86 63.53L106.78 63.59L104.72 63.7L102.66 63.83L100.62 64L98.6 64.2L96.6 64.43L94.62 64.69L92.67 64.99L90.75 65.31L88.86 65.67L87.01 66.05L85.19 66.47L83.42 66.91L81.69 67.38L80.01 67.88L78.38 68.41L76.8 68.96L75.28 69.54L73.81 70.14L72.4 70.76L71.05 71.4L69.77 72.07L68.55 72.76L67.39 73.46L66.31 74.18L65.3 74.92L64.36 75.68L63.49 76.45L62.7 77.23L61.98 78.02L61.34 78.83L60.78 79.65L60.3 80.47L59.9 81.3L59.58 82.14L59.34 82.98L59.18 83.82L59.1 84.67L59.11 85.51L59.19 86.36L59.36 87.2L59.61 88.04L59.94 88.88L60.35 89.71L60.84 90.53L61.41 91.34L62.06 92.15L62.78 92.94L63.58 93.72L64.46 94.49L65.41 95.25L66.43 95.98L67.52 96.7L68.68 97.41L69.91 98.09L71.2 98.75L72.55 99.4L73.97 100.02L75.44 100.61L76.97 101.19L78.56 101.74L80.2 102.26L81.88 102.75L83.62 103.22L85.39 103.66L87.21 104.08"/>
<path class="fig-curve-alt" d="M73.55 92.88L76.42 93.47L79.35 94.02L82.33 94.51L85.36 94.97L88.43 95.37L91.53 95.72L94.67 96.02L97.83 96.28L101.02 96.48L104.22 96.63L107.44 96.73L110.66 96.78L113.88 96.78L117.1 96.72L120.32 96.62L123.52 96.46L126.7 96.25L129.86 95.99L133 95.68L136.1 95.33L139.16 94.92L142.18 94.46L145.16 93.96L148.08 93.41L150.95 92.81L153.76 92.16L156.51 91.48L159.19 90.75L161.79 89.97L164.32 89.16L166.76 88.3L169.13 87.41L171.4 86.48L173.59 85.52L175.67 84.52L177.66 83.49L179.55 82.43L181.34 81.33L183.02 80.21L184.59 79.07L186.04 77.9L187.39 76.71L188.61 75.49L189.72 74.26L190.71 73.01L191.58 71.75L192.33 70.48L192.95 69.19L193.45 67.89L193.82 66.59L194.07 65.28L194.18 63.97L194.18 62.66L194.04 61.35L193.78 60.04L193.4 58.74L192.89 57.45L192.25 56.16L191.49 54.89L190.61 53.63L189.61 52.38L188.48 51.15L187.24 49.94L185.89 48.75L184.42 47.58L182.84 46.44L181.15 45.32L179.35 44.24L177.45 43.18L175.45 42.15L173.35 41.15L171.15 40.19L168.87 39.27L166.5 38.38L164.04 37.53L161.5 36.72L158.89 35.95L156.21 35.22L153.45 34.54L150.64 33.9L147.76 33.31L144.83 32.76L141.85 32.27L138.82 31.81L135.75 31.41L132.65 31.06L129.51 30.76L126.35 30.5L123.16 30.3L119.96 30.15L116.75 30.05L113.53 30L110.3 30L107.08 30.06L103.87 30.16L100.67 30.32L97.48 30.53L94.32 30.79L91.19 31.1L88.09 31.45L85.02 31.86L82 32.32L79.02 32.82L76.1 33.37L73.23 33.97L70.42 34.62L67.68 35.3L65 36.03L62.39 36.81L59.87 37.62L57.42 38.48L55.06 39.37L52.78 40.3L50.6 41.26L48.51 42.26L46.52 43.29L44.63 44.35L42.85 45.45L41.17 46.57L39.6 47.71L38.14 48.88L36.8 50.07L35.57 51.29L34.46 52.52L33.47 53.77L32.6 55.03L31.86 56.3L31.23 57.59L30.74 58.89L30.37 60.19L30.12 61.5L30 62.81L30.01 64.12L30.14 65.43L30.4 66.74L30.79 68.04L31.3 69.33L31.93 70.62L32.69 71.89L33.58 73.15L34.58 74.4L35.7 75.63L36.94 76.84L38.3 78.03L39.77 79.2L41.35 80.34L43.04 81.46L44.84 82.54L46.74 83.6L48.74 84.63L50.84 85.63L53.03 86.59L55.32 87.51L57.69 88.4L60.14 89.25L62.68 90.06L65.29 90.83L67.98 91.56L70.73 92.24L73.55 92.88"/>
<path class="fig-curve" d="M149.92 35.65L148.66 38.72L147.4 41.77L146.14 44.8L144.88 47.81L143.62 50.79L142.36 53.75L141.1 56.67L139.84 59.57L138.58 62.43L137.31 65.25L136.05 68.04L134.79 70.78L133.53 73.47L132.27 76.11L131.01 78.69L129.75 81.22L128.49 83.67L127.23 86.06L125.96 88.36L124.7 90.58L123.44 92.71L122.18 94.74L120.92 96.66L119.66 98.47L118.4 100.17L117.14 101.74L115.88 103.18L114.61 104.49L113.35 105.66L112.09 106.69L110.83 107.59L109.57 108.35L108.31 108.97L107.05 109.46L105.79 109.81L104.53 110.05L103.26 110.17L102 110.17L100.74 110.07L99.48 109.87L98.22 109.58L96.96 109.21L95.7 108.75L94.44 108.23L93.18 107.63L91.91 106.98L90.65 106.27L89.39 105.51L88.13 104.7L86.87 103.84L85.61 102.95L84.35 102.01L83.09 101.05L81.83 100.05L80.57 99.02L79.3 97.97L78.04 96.89L76.78 95.79L75.52 94.67L74.26 93.53"/>
<path class="fig-curve" d="M40.94 49.2L43.31 51.82L45.68 54.42L48.05 57L50.43 59.55L52.8 62.08L55.17 64.59L57.54 67.06L59.91 69.51L62.29 71.92L64.66 74.29L67.03 76.62L69.4 78.91L71.77 81.15L74.14 83.34L76.52 85.47L78.89 87.54L81.26 89.55L83.63 91.48L86 93.33L88.37 95.1L90.75 96.77L93.12 98.35L95.49 99.82L97.86 101.18L100.23 102.43L102.61 103.54L104.98 104.53L107.35 105.39L109.72 106.11L112.09 106.69L114.46 107.14L116.84 107.44L119.21 107.61L121.58 107.65L123.95 107.55L126.32 107.34L128.69 107L131.07 106.56L133.44 106L135.81 105.35L138.18 104.61L140.55 103.79L142.93 102.88L145.3 101.9L147.67 100.86L150.04 99.75L152.41 98.59L154.78 97.37L157.16 96.11L159.53 94.81L161.9 93.46L164.27 92.08L166.64 90.66L169.01 89.21L171.39 87.73L173.76 86.23L176.13 84.7L178.5 83.14L180.87 81.57L183.25 79.98"/>
<path class="fig-curve" d="M149.92 206.47L148.66 205.33L147.4 204.21L146.14 203.11L144.88 202.03L143.62 200.98L142.36 199.95L141.1 198.95L139.84 197.99L138.58 197.05L137.31 196.16L136.05 195.3L134.79 194.49L133.53 193.73L132.27 193.02L131.01 192.37L129.75 191.77L128.49 191.25L127.23 190.79L125.96 190.42L124.7 190.13L123.44 189.93L122.18 189.83L120.92 189.83L119.66 189.95L118.4 190.19L117.14 190.54L115.88 191.03L114.61 191.65L113.35 192.41L112.09 193.31L110.83 194.34L109.57 195.51L108.31 196.82L107.05 198.26L105.79 199.83L104.53 201.53L103.26 203.34L102 205.26L100.74 207.29L99.48 209.42L98.22 211.64L96.96 213.94L95.7 216.33L94.44 218.78L93.18 221.31L91.91 223.89L90.65 226.53L89.39 229.22L88.13 231.96L86.87 234.75L85.61 237.57L84.35 240.43L83.09 243.33L81.83 246.25L80.57 249.21L79.3 252.19L78.04 255.2L76.78 258.23L75.52 261.28L74.26 264.35"/>
<path class="fig-curve" d="M40.94 220.02L43.31 218.43L45.68 216.86L48.05 215.3L50.43 213.77L52.8 212.27L55.17 210.79L57.54 209.34L59.91 207.92L62.29 206.54L64.66 205.19L67.03 203.89L69.4 202.63L71.77 201.41L74.14 200.25L76.52 199.14L78.89 198.1L81.26 197.12L83.63 196.21L86 195.39L88.37 194.65L90.75 194L93.12 193.44L95.49 193L97.86 192.66L100.23 192.45L102.61 192.35L104.98 192.39L107.35 192.56L109.72 192.86L112.09 193.31L114.46 193.89L116.84 194.61L119.21 195.47L121.58 196.46L123.95 197.57L126.32 198.82L128.69 200.18L131.07 201.65L133.44 203.23L135.81 204.9L138.18 206.67L140.55 208.52L142.93 210.45L145.3 212.46L147.67 214.53L150.04 216.66L152.41 218.85L154.78 221.09L157.16 223.38L159.53 225.71L161.9 228.08L164.27 230.49L166.64 232.94L169.01 235.41L171.39 237.92L173.76 240.45L176.13 243L178.5 245.58L180.87 248.18L183.25 250.8"/>
<path class="fig-axis" d="M60.92 189.14L60.91 189.15L60.92 189.15"/>
<path class="fig-axis" d="M208.33 170.82L208.36 170.82L208.34 170.8"/>
<path class="fig-axis" d="M112.1 33.1L112.09 33.08L112.08 33.1"/>
<circle class="fig-point" cx="112.09" cy="106.69" r="3.2"/>
<circle class="fig-point" cx="112.09" cy="193.31" r="3.2"/>
<text class="fig-label-em" x="49.96" y="198.23">x</text>
<text class="fig-label-em" x="215.13" y="175.93">y</text>
<text class="fig-label-em" x="109.09" y="26.08">z</text>
<text class="fig-label" x="120.09" y="118.69">(0, 0, 1)</text>
<text class="fig-label" x="60.09" y="207.31">(0, 0, −1)</text>
</svg>
<figcaption>The hyperboloid of two sheets $z^2-x^2-y^2=1$: the horizontal trace $z=k$ is the circle $x^2+y^2=k^2-1$ when $|k|>1$, a single point at $z=\pm1$ (the vertices) and empty for $|k|\lt 1$, which is why there are two separate sheets; the vertical traces $y=0$ and $x=0$ are hyperbolas.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 228 300" width="228" height="300" role="img" aria-label="The saddle z equals y squared minus x squared, drawn with two families of parabolas and the two lines where it crosses the xy-plane">
<path class="fig-axis" d="M114.01 145.21L75.12 174.96"/>
<path class="fig-axis" d="M114.01 145.21L187.13 161.03"/>
<path class="fig-axis" d="M114.01 145.21L114.01 31.72"/>
<path class="fig-guide" d="M88.32 111.04L90.89 114.46L93.46 117.88L96.03 121.29L98.6 124.71L101.17 128.13L103.73 131.55L106.3 134.96L108.87 138.38L111.44 141.8L114.01 145.21L116.58 148.63L119.14 152.05L121.71 155.46L124.28 158.88L126.85 162.3L129.42 165.71L131.99 169.13L134.55 172.55L137.12 175.96L139.69 179.38"/>
<path class="fig-guide" d="M198.01 134.77L189.61 135.81L181.21 136.86L172.81 137.9L164.41 138.95L156.01 139.99L147.61 141.03L139.21 142.08L130.81 143.12L122.41 144.17L114.01 145.21L105.61 146.26L97.21 147.3L88.8 148.35L80.4 149.39L72 150.44L63.6 151.48L55.2 152.53L46.8 153.57L38.4 154.61L30 155.66"/>
<path class="fig-curve-alt" d="M88.32 111.04L87.35 105.09L86.38 99.37L85.41 93.87L84.44 88.6L83.46 83.55L82.49 78.73L81.52 74.14L80.55 69.78L79.57 65.64L78.6 61.73L77.63 58.05L76.66 54.6L75.69 51.37L74.71 48.37L73.74 45.59L72.77 43.04L71.8 40.72L70.83 38.63L69.85 36.76L68.88 35.12L67.91 33.71L66.94 32.52L65.97 31.57L64.99 30.83L64.02 30.33L63.05 30.05L62.08 30L61.11 30.18L60.13 30.58L59.16 31.21L58.19 32.07L57.22 33.15L56.25 34.46L55.27 36L54.3 37.76L53.33 39.76L52.36 41.98L51.39 44.42L50.41 47.09L49.44 49.99L48.47 53.12L47.5 56.48L46.52 60.06L45.55 63.86L44.58 67.9L43.61 72.16L42.64 76.65L41.66 81.37L40.69 86.31L39.72 91.48L38.75 96.87L37.78 102.5L36.8 108.35L35.83 114.43L34.86 120.73L33.89 127.26L32.92 134.02L31.94 141.01L30.97 148.22L30 155.66"/>
<path class="fig-curve-alt" d="M112.7 186.93L111.73 180.98L110.76 175.26L109.78 169.76L108.81 164.49L107.84 159.44L106.87 154.62L105.89 150.03L104.92 145.67L103.95 141.53L102.98 137.62L102.01 133.94L101.03 130.48L100.06 127.26L99.09 124.25L98.12 121.48L97.15 118.93L96.17 116.61L95.2 114.52L94.23 112.65L93.26 111.01L92.29 109.6L91.31 108.41L90.34 107.45L89.37 106.72L88.4 106.22L87.43 105.94L86.45 105.89L85.48 106.06L84.51 106.47L83.54 107.1L82.57 107.96L81.59 109.04L80.62 110.35L79.65 111.89L78.68 113.65L77.71 115.65L76.73 117.86L75.76 120.31L74.79 122.98L73.82 125.88L72.84 129.01L71.87 132.36L70.9 135.94L69.93 139.75L68.96 143.79L67.98 148.05L67.01 152.54L66.04 157.25L65.07 162.2L64.1 167.37L63.12 172.76L62.15 178.39L61.18 184.24L60.21 190.32L59.24 196.62L58.26 203.15L57.29 209.91L56.32 216.9L55.35 224.11L54.38 231.55"/>
<path class="fig-curve-alt" d="M143.17 225.05L142.2 219.1L141.22 213.37L140.25 207.87L139.28 202.6L138.31 197.56L137.34 192.74L136.36 188.15L135.39 183.78L134.42 179.65L133.45 175.74L132.48 172.06L131.5 168.6L130.53 165.37L129.56 162.37L128.59 159.59L127.62 157.05L126.64 154.73L125.67 152.63L124.7 150.77L123.73 149.13L122.76 147.71L121.78 146.53L120.81 145.57L119.84 144.84L118.87 144.33L117.9 144.05L116.92 144L115.95 144.18L114.98 144.58L114.01 145.21L113.03 146.07L112.06 147.15L111.09 148.47L110.12 150L109.15 151.77L108.17 153.76L107.2 155.98L106.23 158.43L105.26 161.1L104.29 164L103.31 167.13L102.34 170.48L101.37 174.06L100.4 177.87L99.43 181.9L98.45 186.16L97.48 190.65L96.51 195.37L95.54 200.31L94.57 205.48L93.59 210.88L92.62 216.5L91.65 222.35L90.68 228.43L89.71 234.74L88.73 241.27L87.76 248.03L86.79 255.01L85.82 262.22L84.85 269.66"/>
<path class="fig-curve-alt" d="M173.64 200.11L172.67 194.16L171.69 188.43L170.72 182.94L169.75 177.66L168.78 172.62L167.81 167.8L166.83 163.21L165.86 158.85L164.89 154.71L163.92 150.8L162.95 147.12L161.97 143.66L161 140.44L160.03 137.43L159.06 134.66L158.09 132.11L157.11 129.79L156.14 127.7L155.17 125.83L154.2 124.19L153.23 122.78L152.25 121.59L151.28 120.63L150.31 119.9L149.34 119.4L148.36 119.12L147.39 119.07L146.42 119.24L145.45 119.65L144.48 120.28L143.5 121.13L142.53 122.22L141.56 123.53L140.59 125.07L139.62 126.83L138.64 128.82L137.67 131.04L136.7 133.49L135.73 136.16L134.76 139.06L133.78 142.19L132.81 145.54L131.84 149.12L130.87 152.93L129.9 156.97L128.92 161.23L127.95 165.72L126.98 170.43L126.01 175.38L125.04 180.55L124.06 185.94L123.09 191.57L122.12 197.42L121.15 203.49L120.18 209.8L119.2 216.33L118.23 223.09L117.26 230.08L116.29 237.29L115.31 244.73"/>
<path class="fig-curve-alt" d="M198.01 134.77L197.04 128.81L196.07 123.09L195.1 117.59L194.13 112.32L193.15 107.27L192.18 102.46L191.21 97.87L190.24 93.5L189.27 89.37L188.29 85.46L187.32 81.77L186.35 78.32L185.38 75.09L184.41 72.09L183.43 69.31L182.46 66.77L181.49 64.45L180.52 62.35L179.54 60.48L178.57 58.84L177.6 57.43L176.63 56.25L175.66 55.29L174.68 54.56L173.71 54.05L172.74 53.77L171.77 53.72L170.8 53.9L169.82 54.3L168.85 54.93L167.88 55.79L166.91 56.87L165.94 58.18L164.96 59.72L163.99 61.49L163.02 63.48L162.05 65.7L161.08 68.14L160.1 70.82L159.13 73.72L158.16 76.84L157.19 80.2L156.22 83.78L155.24 87.59L154.27 91.62L153.3 95.88L152.33 100.37L151.36 105.09L150.38 110.03L149.41 115.2L148.44 120.6L147.47 126.22L146.49 132.07L145.52 138.15L144.55 144.45L143.58 150.99L142.61 157.74L141.63 164.73L140.66 171.94L139.69 179.38"/>
<path class="fig-curve" d="M88.32 111.04L90.15 118.14L91.98 125L93.81 131.64L95.64 138.05L97.46 144.23L99.29 150.19L101.12 155.92L102.95 161.42L104.78 166.7L106.61 171.74L108.43 176.57L110.26 181.16L112.09 185.53L113.92 189.67L115.75 193.58L117.57 197.27L119.4 200.73L121.23 203.96L123.06 206.97L124.89 209.75L126.72 212.3L128.54 214.62L130.37 216.72L132.2 218.59L134.03 220.23L135.86 221.65L137.68 222.84L139.51 223.8L141.34 224.54L143.17 225.05L145 225.33L146.83 225.38L148.65 225.21L150.48 224.81L152.31 224.19L154.14 223.33L155.97 222.25L157.79 220.95L159.62 219.41L161.45 217.65L163.28 215.66L165.11 213.45L166.94 211.01L168.76 208.34L170.59 205.44L172.42 202.32L174.25 198.97L176.08 195.39L177.9 191.59L179.73 187.56L181.56 183.3L183.39 178.82L185.22 174.1L187.04 169.17L188.87 164L190.7 158.61L192.53 152.99L194.36 147.14L196.19 141.07L198.01 134.77"/>
<path class="fig-curve" d="M75.36 50.34L77.19 57.43L79.02 64.3L80.85 70.93L82.68 77.35L84.5 83.53L86.33 89.49L88.16 95.21L89.99 100.72L91.82 105.99L93.64 111.04L95.47 115.86L97.3 120.46L99.13 124.83L100.96 128.97L102.79 132.88L104.61 136.57L106.44 140.03L108.27 143.26L110.1 146.26L111.93 149.04L113.75 151.59L115.58 153.92L117.41 156.02L119.24 157.89L121.07 159.53L122.9 160.95L124.72 162.14L126.55 163.1L128.38 163.84L130.21 164.35L132.04 164.63L133.86 164.68L135.69 164.51L137.52 164.11L139.35 163.49L141.18 162.63L143.01 161.55L144.83 160.24L146.66 158.71L148.49 156.95L150.32 154.96L152.15 152.75L153.97 150.31L155.8 147.64L157.63 144.74L159.46 141.62L161.29 138.27L163.12 134.69L164.94 130.89L166.77 126.86L168.6 122.6L170.43 118.11L172.26 113.4L174.08 108.46L175.91 103.3L177.74 97.9L179.57 92.28L181.4 86.44L183.23 80.36L185.05 74.06"/>
<path class="fig-curve" d="M59.16 31.21L60.99 38.3L62.82 45.17L64.65 51.8L66.47 58.21L68.3 64.4L70.13 70.35L71.96 76.08L73.79 81.58L75.62 86.86L77.44 91.91L79.27 96.73L81.1 101.33L82.93 105.69L84.76 109.83L86.58 113.75L88.41 117.43L90.24 120.89L92.07 124.13L93.9 127.13L95.73 129.91L97.55 132.46L99.38 134.79L101.21 136.88L103.04 138.76L104.87 140.4L106.69 141.82L108.52 143.01L110.35 143.97L112.18 144.7L114.01 145.21L115.84 145.49L117.66 145.55L119.49 145.38L121.32 144.98L123.15 144.35L124.98 143.5L126.8 142.42L128.63 141.11L130.46 139.58L132.29 137.82L134.12 135.83L135.95 133.61L137.77 131.17L139.6 128.5L141.43 125.61L143.26 122.49L145.09 119.14L146.91 115.56L148.74 111.75L150.57 107.72L152.4 103.47L154.23 98.98L156.06 94.27L157.88 89.33L159.71 84.17L161.54 78.77L163.37 73.15L165.2 67.31L167.02 61.23L168.85 54.93"/>
<path class="fig-curve" d="M42.96 75.13L44.79 82.22L46.62 89.08L48.45 95.72L50.27 102.13L52.1 108.32L53.93 114.27L55.76 120L57.59 125.5L59.41 130.78L61.24 135.83L63.07 140.65L64.9 145.24L66.73 149.61L68.56 153.75L70.38 157.67L72.21 161.35L74.04 164.81L75.87 168.04L77.7 171.05L79.52 173.83L81.35 176.38L83.18 178.71L85.01 180.8L86.84 182.67L88.67 184.32L90.49 185.73L92.32 186.92L94.15 187.89L95.98 188.62L97.81 189.13L99.63 189.41L101.46 189.47L103.29 189.3L105.12 188.9L106.95 188.27L108.78 187.42L110.6 186.34L112.43 185.03L114.26 183.5L116.09 181.74L117.92 179.75L119.74 177.53L121.57 175.09L123.4 172.42L125.23 169.53L127.06 166.4L128.89 163.05L130.71 159.48L132.54 155.67L134.37 151.64L136.2 147.38L138.03 142.9L139.85 138.19L141.68 133.25L143.51 128.08L145.34 122.69L147.17 117.07L148.99 111.22L150.82 105.15L152.65 98.85"/>
<path class="fig-curve" d="M30 155.66L31.83 162.75L33.66 169.62L35.48 176.25L37.31 182.66L39.14 188.85L40.97 194.8L42.8 200.53L44.63 206.04L46.45 211.31L48.28 216.36L50.11 221.18L51.94 225.78L53.77 230.14L55.59 234.28L57.42 238.2L59.25 241.88L61.08 245.34L62.91 248.58L64.74 251.58L66.56 254.36L68.39 256.91L70.22 259.24L72.05 261.33L73.88 263.21L75.7 264.85L77.53 266.27L79.36 267.46L81.19 268.42L83.02 269.15L84.85 269.66L86.67 269.95L88.5 270L90.33 269.83L92.16 269.43L93.99 268.8L95.81 267.95L97.64 266.87L99.47 265.56L101.3 264.03L103.13 262.27L104.96 260.28L106.78 258.06L108.61 255.62L110.44 252.95L112.27 250.06L114.1 246.94L115.92 243.59L117.75 240.01L119.58 236.2L121.41 232.17L123.24 227.92L125.07 223.43L126.89 218.72L128.72 213.78L130.55 208.62L132.38 203.22L134.21 197.6L136.03 191.76L137.86 185.68L139.69 179.38"/>
<path class="fig-axis" d="M75.13 174.94L75.12 174.96L75.14 174.95"/>
<path class="fig-axis" d="M187.11 161.03L187.13 161.03L187.12 161.02"/>
<path class="fig-axis" d="M114.01 31.74L114.01 31.72L114 31.74"/>
<circle class="fig-point" cx="114.01" cy="145.21" r="3.2"/>
<text class="fig-label-em" x="64.18" y="184.03">x</text>
<text class="fig-label-em" x="193.91" y="166.14">y</text>
<text class="fig-label-em" x="111.01" y="24.72">z</text>
</svg>
<figcaption>The hyperbolic paraboloid $z=y^2-x^2$: the traces $x=c$ are parabolas $z=y^2-c^2$ opening up, the traces $y=c$ are parabolas $z=c^2-x^2$ opening down, and the level $z=0$ (dashed) is the pair of crossing lines $y=\pm x$, so the origin is a saddle point: a minimum along $y$, a maximum along $x$.</figcaption>
</figure>

</div>

Use the table and the sign-counting rule below together: the signs identify the family; traces identify its orientation and any gap.


:::callout-key
Quick identification rule:

Count the number of positive squared terms and whether there is a linear term.

- Three positive squares = 1 on right → **ellipsoid**
- Two positive, one negative squares = 1 → **hyperboloid of one sheet**
- One positive, two negative squares = 1 → **hyperboloid of two sheets**
- Two squares = one linear term (no constant) → **paraboloid** (elliptic or hyperbolic depending on signs)
- Two squares = one square (all on same side, = 0) → **cone**
:::


:::callout-key[Identify from the equation: a step-by-step method]
1. **Missing variable:** the surface is a cylinder. The absent coordinate gives the axis; identify the two-variable trace as circle, ellipse, parabola or hyperbola.
2. **One unsquared variable:** the surface is a paraboloid. Squared terms with matching signs give an elliptic paraboloid (a bowl); opposite signs give a hyperbolic paraboloid (a saddle). The unsquared variable gives the opening direction.
3. **Only squared variables:** if all have the same positive sign and the right side is $1$, the result is an ellipsoid. If the equation is homogeneous with zero on the right, it is a cone. With positive right side $1$, two positive squares and one negative mean a hyperboloid of one sheet; one positive and two negative mean a hyperboloid of two sheets.
4. **Sketch with traces:** set a variable equal to $0$, then to a simple nonzero constant. Look for ellipse, parabola, or hyperbola; identify the axis and any gap. Always divide by a **positive** right-hand constant before counting the signs.
:::



<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 320 220" width="320" height="220" role="img" aria-label="Two intersecting parabolas sampled from the saddle surface traces">
<path class="fig-axis" d="M30.0 118.0L300.0 118.0"/>
<path class="fig-axis" d="M165.0 20.0L165.0 210.0"/>
<path class="fig-curve" d="M90.2 54.4L92.4 58.1L94.6 61.7L96.8 65.1L99.0 68.5L101.2 71.7L103.4 74.9L105.6 77.9L107.8 80.8L110.0 83.6L112.2 86.3L114.4 88.9L116.6 91.4L118.8 93.7L121.0 96.0L123.2 98.1L125.4 100.2L127.6 102.1L129.8 103.9L132.0 105.6L134.2 107.2L136.4 108.7L138.6 110.1L140.8 111.3L143.0 112.5L145.2 113.5L147.4 114.5L149.6 115.3L151.8 116.0L154.0 116.6L156.2 117.1L158.4 117.5L160.6 117.8L162.8 117.9L165.0 118.0L167.2 117.9L169.4 117.8L171.6 117.5L173.8 117.1L176.0 116.6L178.2 116.0L180.4 115.3L182.6 114.5L184.8 113.5L187.0 112.5L189.2 111.3L191.4 110.1L193.6 108.7L195.8 107.2L198.0 105.6L200.2 103.9L202.4 102.1L204.6 100.2L206.8 98.1L209.0 96.0L211.2 93.7L213.4 91.4L215.6 88.9L217.8 86.3L220.0 83.6L222.2 80.8L224.4 77.9L226.6 74.9L228.8 71.7L231.0 68.5L233.2 65.1L235.4 61.7L237.6 58.1L239.8 54.4"/>
<path class="fig-curve-alt" d="M90.2 181.6L92.4 177.9L94.6 174.3L96.8 170.9L99.0 167.5L101.2 164.3L103.4 161.1L105.6 158.1L107.8 155.2L110.0 152.4L112.2 149.7L114.4 147.1L116.6 144.6L118.8 142.3L121.0 140.0L123.2 137.9L125.4 135.8L127.6 133.9L129.8 132.1L132.0 130.4L134.2 128.8L136.4 127.3L138.6 125.9L140.8 124.7L143.0 123.5L145.2 122.5L147.4 121.5L149.6 120.7L151.8 120.0L154.0 119.4L156.2 118.9L158.4 118.5L160.6 118.2L162.8 118.1L165.0 118.0L167.2 118.1L169.4 118.2L171.6 118.5L173.8 118.9L176.0 119.4L178.2 120.0L180.4 120.7L182.6 121.5L184.8 122.5L187.0 123.5L189.2 124.7L191.4 125.9L193.6 127.3L195.8 128.8L198.0 130.4L200.2 132.1L202.4 133.9L204.6 135.8L206.8 137.9L209.0 140.0L211.2 142.3L213.4 144.6L215.6 147.1L217.8 149.7L220.0 152.4L222.2 155.2L224.4 158.1L226.6 161.1L228.8 164.3L231.0 167.5L233.2 170.9L235.4 174.3L237.6 177.9L239.8 181.6"/>
<circle class="fig-point" cx="165.0" cy="118.0" r="3"/><text class="fig-label" x="172.0" y="110.0">O</text>
<text class="fig-label-em" x="251" y="38">z=x²</text>
<text class="fig-label-em" x="246" y="206">z=−y²</text>
</svg>
<figcaption>The two axial traces of the saddle $z=x^2-y^2$ bend in opposite directions: at $y=0$, $z=x^2$ opens upward, while at $x=0$, $z=-y^2$ opens downward. Curves are sampled from those equations.</figcaption>
</figure>

### The Trace Method

To sketch or identify a quadric surface: set each variable to a constant in turn and identify the resulting 2D curve. For example, to trace $4x^2+9y^2+z^2=36$ (divide by 36: $x^2/9+y^2/4+z^2/36=1$):

 $z=0$: $x^2/9+y^2/4=1$ — an ellipse with semi-axes 3 and 2
 $y=0$: $x^2/9+z^2/36=1$ — an ellipse with semi-axes 3 and 6
 $x=0$: $y^2/4+z^2/36=1$ — an ellipse with semi-axes 2 and 6

 All traces are ellipses → **ellipsoid**.

### Worked Examples — Quadric Surfaces

:::::example[Example 3.55 — Identify and Sketch]
Identify the quadric surface $z=4x^2+9y^2$.

::::answer[Answer]
**Answer:** Elliptic paraboloid, opening upward, vertex at origin.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. The equation has two squared terms on the right and a linear $z$ on the left — elliptic paraboloid. Traces:

$$
z=k>0:\;4x^2+9y^2=k\;\text{(ellipse)};\quad y=0:\;z=4x^2\;\text{(upward parabola)};\quad x=0:\;z=9y^2\;\text{(upward parabola)}.
$$

3. The surface bowls upward from the origin.

4. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.56 — Hyperboloid of One Sheet vs Two Sheets]
Identify: (a) $x^2+y^2-z^2=1$; (b) $-x^2-y^2+z^2=1$.

::::answer[Answer]
**Answer:** (a) one sheet; (b) two sheets.

1. (a) Two positive terms, one negative = 1: *hyperboloid of one sheet*. Horizontal traces ($z=k$) are circles $x^2+y^2=1+k^2$ — always exist. The waist circle ($z=0$) has radius 1.

2. (b) One positive term, two negative = 1: *hyperboloid of two sheets*. Need $z^2\ge1$, i.e. $|z|\ge1$. For $z=k$ with $|k|>1$, trace is $x^2+y^2=k^2-1$ (circle). No surface exists between $z=-1$ and $z=1$.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.57 — Completing the Square to Identify]
Identify $4x^2-8x+y^2+2y+z^2-4z+1=0$.

::::answer[Answer]
**Answer:** Ellipsoid centered at $(1,-1,2)$.

1. Complete the square in each variable:

$$
4(x^2-2x)+\;(y^2+2y)+\;(z^2-4z)=-1.
$$

$$
4(x-1)^2-4+\;(y+1)^2-1+\;(z-2)^2-4=-1.
$$

$$
4(x-1)^2+(y+1)^2+(z-2)^2=8.
$$

2. Divide by 8:

$$
\frac{(x-1)^2}{2}+\frac{(y+1)^2}{8}+\frac{(z-2)^2}{8}=1.
$$

3. Ellipsoid centered at $(1,-1,2)$ with semi-axes $\sqrt{2},2\sqrt{2},2\sqrt{2}$.

4. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::


### Lecture Examples — Identifying and Sketching

The following lecture examples model standard form, axis, name and coordinate-plane traces.

:::::example[Example 3.58 — Circular Cylinder]
Describe and sketch the surface $x^2+z^2=4$.

::::answer[Answer]
**Answer:** Circular cylinder of radius 2, running along the $y$-axis.

1. The variable $y$ is missing, so this is a cylinder, and it runs along the $y$-axis. The standard form is $x^2+z^2=2^2$, a circle of radius 2 in the variables $x$ and $z$, so it is a circular cylinder.

2. Traces in the coordinate planes:

3. $xz$-plane ($y=0$): the circle $x^2+z^2=4$.

4. $xy$-plane ($z=0$): $x^2=4$, so $x=\pm2$, the two lines parallel to the $y$-axis.

5. $yz$-plane ($x=0$): $z^2=4$, so $z=\pm2$, the two lines parallel to the $y$-axis.

6. Every plane $y=k$ cuts a circle of radius 2. To sketch it, draw the circle of radius 2 in the $xz$-plane and sweep it in both directions along $y$ to make a tube.

7. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.59 — Elliptic Cylinder]
Describe and sketch the surface $y^2+9z^2=9$.

::::answer[Answer]
**Answer:** Elliptic cylinder along the $x$-axis, with semi-axis 3 in the $y$ direction and 1 in the $z$ direction.

1. The variable $x$ is missing, so this is a cylinder along the $x$-axis. To get standard form, divide both sides by 9:

$$
\frac{y^2}{9}+\frac{z^2}{1}=1,\qquad\text{that is}\qquad \frac{y^2}{3^2}+\frac{z^2}{1^2}=1.
$$

2. That is an ellipse, so this is an elliptic cylinder.

3. Traces in the coordinate planes:

4. $yz$-plane ($x=0$): the ellipse $\frac{y^2}{9}+z^2=1$, with semi-axis 3 along $y$ and 1 along $z$.

5. $xy$-plane ($z=0$): $y^2=9$, so the lines $y=\pm3$.

6. $xz$-plane ($y=0$): $9z^2=9$, so the lines $z=\pm1$.

7. Every plane $x=k$ cuts the same ellipse. The sketch is an elliptical tube along $x$, wide in the $y$ direction and narrow in the $z$ direction.

8. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.60 — Elliptic Paraboloid]
Identify and sketch $x=y^2+4z^2$.

::::answer[Answer]
**Answer:** Elliptic paraboloid with vertex at the origin, opening in the $+x$ direction.

1. The variable $x$ appears only to the first power, and $y$ and $z$ are squared with the same sign, so this is an elliptic paraboloid. The axis is the $x$-axis. Because the right side is a sum of squares, $x\ge0$, so the bowl opens in the $+x$ direction. In standard form it is

$$
\frac{x}{1}=\frac{y^2}{1^2}+\frac{z^2}{(1/2)^2}.
$$

2. Traces in the coordinate planes:

3. $xy$-plane ($z=0$): the parabola $x=y^2$.

4. $xz$-plane ($y=0$): the parabola $x=4z^2$.

5. $yz$-plane ($x=0$): $y^2+4z^2=0$, which is only the origin.

6. Planes $x=k$ with $k\gt0$ cut the ellipse $y^2+4z^2=k$, with semi-axes $\sqrt{k}$ along $y$ and $\sqrt{k}/2$ along $z$. Planes with $k\lt0$ miss the surface. The sketch is a bowl with its bottom at the origin opening toward $+x$, narrower in the $z$ direction than in the $y$ direction.

7. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.61 — Elliptic Cone]
Identify and sketch $x^2=4y^2+z^2$.

::::answer[Answer]
**Answer:** Elliptic cone, two nappes along the $x$-axis meeting at the origin.

1. All three variables are squared, there is no constant term, and $x^2$ stands alone on one side against the other two squares. That is an elliptic cone, and its axis is the variable alone on its side, the $x$-axis. In standard form,

$$
\frac{y^2}{(1/2)^2}+\frac{z^2}{1^2}=\frac{x^2}{1^2}.
$$

2. Traces in the coordinate planes:

3. $xy$-plane ($z=0$): $x^2=4y^2$, the lines $x=\pm2y$.

4. $xz$-plane ($y=0$): $x^2=z^2$, the lines $x=\pm z$.

5. $yz$-plane ($x=0$): $4y^2+z^2=0$, only the origin.

6. Planes $x=k$ with $k\ne0$ cut the ellipse $4y^2+z^2=k^2$, that is $\frac{y^2}{(k/2)^2}+\frac{z^2}{k^2}=1$. The sketch is a double cone lying along the $x$-axis, one nappe for $x\gt0$ and one for $x\lt0$, with cross-sections twice as wide in $z$ as in $y$.

7. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::example[Example 3.62 — Ellipsoid]
Identify and sketch $x^2+4y^2+9z^2=36$.

::::answer[Answer]
**Answer:** Ellipsoid with semi-axes 6 along $x$, 3 along $y$ and 2 along $z$.

1. All three variables are squared, all three signs are positive, and the constant is not zero, so it is an ellipsoid. Divide by 36:

$$
\frac{x^2}{36}+\frac{y^2}{9}+\frac{z^2}{4}=1,\qquad\text{that is}\qquad \frac{x^2}{6^2}+\frac{y^2}{3^2}+\frac{z^2}{2^2}=1.
$$

2. An ellipsoid has no single axis. The semi-axes are 6 along $x$, 3 along $y$ and 2 along $z$, so it is longest along $x$. It crosses the axes at $(\pm6,0,0)$, $(0,\pm3,0)$ and $(0,0,\pm2)$.

3. Traces in the coordinate planes, all ellipses:

4. $xy$-plane ($z=0$): $\frac{x^2}{36}+\frac{y^2}{9}=1$.

5. $xz$-plane ($y=0$): $\frac{x^2}{36}+\frac{z^2}{4}=1$.

6. $yz$-plane ($x=0$): $\frac{y^2}{9}+\frac{z^2}{4}=1$.

7. The sketch is an egg-shaped closed surface, stretched most along $x$ and least along $z$.

8. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::example[Example 3.63 — Hyperboloid of One Sheet]
Identify and sketch $x^2-y^2+z^2=1$.

::::answer[Answer]
**Answer:** Hyperboloid of one sheet, centred on the $y$-axis, with waist radius 1 at $y=0$.

1. All three are squared, the right side is $1$, and there is exactly one minus sign, so it is a hyperboloid of one sheet. The minus sign is on $y$, so $y$ is the odd-one-out and the axis is the $y$-axis. In standard form,

$$
\frac{x^2}{1^2}+\frac{z^2}{1^2}-\frac{y^2}{1^2}=1.
$$

2. Traces in the coordinate planes:

3. $xz$-plane ($y=0$): the circle $x^2+z^2=1$, the narrowest waist.

4. $xy$-plane ($z=0$): the hyperbola $x^2-y^2=1$, opening along $\pm x$.

5. $yz$-plane ($x=0$): the hyperbola $z^2-y^2=1$, opening along $\pm z$.

6. Planes $y=k$ cut the circle $x^2+z^2=1+k^2$, which grows as $|k|$ grows. The sketch is a cooling-tower shape wrapped around the $y$-axis, narrowest at $y=0$ with radius 1, flaring out in both directions, in one connected piece.

7. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.64 — Hyperboloid of Two Sheets]
Identify and sketch $x^2-y^2-z^2=1$.

::::answer[Answer]
**Answer:** Hyperboloid of two sheets along the $x$-axis, with vertices $(\pm1,0,0)$.

1. All three are squared, the right side is $1$, and there are two minus signs, so it is a hyperboloid of two sheets. The plus sign is on $x$, so $x$ is the odd-one-out and the axis is the $x$-axis. In standard form,

$$
\frac{x^2}{1^2}-\frac{y^2}{1^2}-\frac{z^2}{1^2}=1.
$$

2. The vertices are $(\pm1,0,0)$, and the two sheets open toward $+x$ and $-x$.

3. Traces in the coordinate planes:

4. $xy$-plane ($z=0$): the hyperbola $x^2-y^2=1$.

5. $xz$-plane ($y=0$): the hyperbola $x^2-z^2=1$.

6. $yz$-plane ($x=0$): $-y^2-z^2=1$, which has **no points**. The surface never crosses the $yz$-plane.

7. Planes $x=k$ cut $y^2+z^2=k^2-1$: a circle when $|k|\gt1$, the single point $(\pm1,0,0)$ when $|k|=1$, and nothing when $|k|\lt1$. The sketch is two separate bowls, one starting at $(1,0,0)$ and opening toward $+x$, the mirror one starting at $(-1,0,0)$ and opening toward $-x$, with a gap between them.

8. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::example[Example 3.65 — Hyperbolic Paraboloid]
Identify $y=z^2-x^2$.

::::answer[Answer]
**Answer:** Hyperbolic paraboloid with its axis along $y$ and a saddle point at the origin.

1. The variable $y$ appears only to the first power, and the squares $z^2$ and $x^2$ have opposite signs, so this is a hyperbolic paraboloid. The linear variable $y$ is the axis. In standard form,

$$
\frac{z^2}{1^2}-\frac{x^2}{1^2}=\frac{y}{1}.
$$

2. Traces in the coordinate planes:

3. $yz$-plane ($x=0$): the parabola $y=z^2$, opening toward $+y$.

4. $xy$-plane ($z=0$): the parabola $y=-x^2$, opening toward $-y$.

5. $xz$-plane ($y=0$): $0=z^2-x^2$, the two crossing lines $z=\pm x$.

6. Planes $y=k$ cut the hyperbola $z^2-x^2=k$, which opens along $\pm z$ for $k\gt0$, along $\pm x$ for $k\lt0$, and degenerates to the lines $z=\pm x$ for $k=0$. The surface is a saddle centred at the origin: it curves up toward $+y$ along the $z$ direction and down toward $-y$ along the $x$ direction.

7. The instructor said that you will **not** have to draw a hyperbolic paraboloid on the test. You must, however, be able to identify one from its equation, which is what the steps above do: one variable to the first power, and the two squares with opposite signs.

8. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::


:::callout-pitfall
Watch out for:

- **One-sheet vs two-sheet hyperboloid.** Count the negatives: one negative squared term → one sheet (connected); two negative squared terms → two sheets (disconnected).
- **Missing variable = cylinder.** If $y$ is missing from the equation, the surface extends infinitely along the $y$-axis — it's a cylinder, not a bounded surface.
- **Cone has zero on the right.** $x^2/a^2+y^2/b^2=z^2/c^2$ is a cone (the right side is not 1, it's another squared term).
:::

:::::problem[Problem 3.34 — Sphere equation and geometry]{difficulty=easy}
Identify the surface $x^2+y^2+z^2=9$.

::::solution[Solution]
**Answer:** Sphere centered at the origin with radius $3$ (a special ellipsoid).

1. **Compare with a familiar standard form.** A sphere with center $(h,k,\ell)$ and radius $r>0$ satisfies $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$. The given equation is $x^2+y^2+z^2=9$.

2. **Match the three squared terms.** They have equal positive coefficients, all equal to $1$, and no first-degree terms. Thus $h=k=\ell=0$ and $r^2=9$.

3. **Solve for the radius.** Radius is a nonnegative length, so $r=\sqrt9=3$, not $9$ and not $-3$.

4. **Check points on the surface.** The points $(3,0,0)$, $(0,3,0)$, and $(0,0,3)$ each produce $9$ on the left side. All lie three units from the origin. Therefore the surface is the sphere of radius $3$.
::::
:::::

:::::problem[Problem 3.35 — Identify a paraboloid]{difficulty=easy}
Identify the surface $z=x^2-y^2$.

::::solution[Solution]
**Answer:** Hyperbolic paraboloid, also called a saddle surface.

1. **Identify the quadratic sign pattern.** The equation $z=x^2-y^2$ has one positive and one negative squared term, and $z$ appears to the first power. Opposite signs on the squared variables are the signature of a hyperbolic paraboloid rather than an elliptic paraboloid.

2. **Check the $xz$ trace by setting $y=0$.** The equation becomes $z=x^2$, an upward-opening parabola through the origin.

3. **Check the $yz$ trace by setting $x=0$.** The equation becomes $z=-y^2$, a downward-opening parabola through the same origin. Thus the surface bends upward in one direction and downward in the perpendicular direction.

4. **Check horizontal traces.** Setting $z=k$ gives $x^2-y^2=k$, a hyperbola for $k\ne0$; at $k=0$ the trace is the two lines $x=y$ and $x=-y$. These traces confirm the saddle classification.
::::
:::::

:::::problem[Problem 3.36 — Identify a hyperboloid]{difficulty=standard}
Identify and describe the traces of $\frac{x^2}{4}+\frac{y^2}{9}-\frac{z^2}{16}=1$.

::::solution[Solution]
**Answer:** Hyperboloid of one sheet centered at the origin, with axis along $z$; horizontal traces are ellipses, and the $xz$ and $yz$ traces are hyperbolas.

1. **Recognize the standard sign pattern.** In $x^2/4+y^2/9-z^2/16=1$, two squared terms are positive and one is negative. With a positive right side, this is a hyperboloid of one sheet. The negative term is $z^2$, so the axis runs along $z$.

2. **Take horizontal traces.** Fix $z=k$:

$$
\frac{x^2}{4}+\frac{y^2}{9}=1+\frac{k^2}{16}.
$$

The right side is positive for every $k$, so every horizontal slice is an ellipse. Its smallest waist occurs at $k=0$, with semi-axes $2$ and $3$.

3. **Take vertical traces.** At $y=0$ the equation is $x^2/4-z^2/16=1$, a hyperbola. At $x=0$ it is $y^2/9-z^2/16=1$, another hyperbola.

4. **Check connectedness.** The elliptical slices exist at every height, including $z=0$, confirming one continuous sheet rather than two separated sheets.
::::
:::::

:::::problem[Problem 3.37 — Practice calculation]{difficulty=standard}
Write the equation of an ellipsoid with semi-axes 2, 3, 5 centered at $(1,0,-1)$.

::::solution[Solution]
**Answer:** $\displaystyle\frac{(x-1)^2}{4}+\frac{y^2}{9}+\frac{(z+1)^2}{25}=1$.

1. **Use the centered ellipsoid equation.** An ellipsoid centered at $(h,k,\ell)$ with positive semi-axes $a,b,c$ aligned with $x,y,z$ satisfies $(x-h)^2/a^2+(y-k)^2/b^2+(z-\ell)^2/c^2=1$.

2. **Match the center.** The center $(1,0,-1)$ gives numerator terms $(x-1)^2$, $(y-0)^2=y^2$, and $(z-(-1))^2=(z+1)^2$.

3. **Square the semi-axis lengths.** The values $a=2$, $b=3$, and $c=5$ produce $a^2=4$, $b^2=9$, and $c^2=25$. Substitution gives the equation in the answer.

4. **Check the principal endpoints.** At $(3,0,-1)$, the first numerator is $4$, giving $4/4=1$; at $(1,3,-1)$ the second gives $9/9=1$; and at $(1,0,4)$ the third gives $25/25=1$. Hence the stated center and semi-axes are correct.
::::
:::::

:::::problem[Problem 3.38 — Identify a hyperboloid]{difficulty=challenge}
Identify $x^2-4x+z^2-y^2+2y=0$ by completing the square, and describe its shape.

::::solution[Solution]
**Answer:** Hyperboloid of one sheet centered at $(2,1,0)$, with axis parallel to the $y$-axis.

1. **Group variables for completing squares.** Rewrite the given equation as $(x^2-4x)-(y^2-2y)+z^2=0$. Complete the $x$ square using $(-4/2)^2=4$ and the $y$ square using $(-2/2)^2=1$.

2. **Preserve the signs when substituting the completed squares.** Because $x^2-4x=(x-2)^2-4$ and $-(y^2-2y)=-(y-1)^2+1$, the equation becomes

$$
(x-2)^2-4-(y-1)^2+1+z^2=0.
$$

Move constants to the right to obtain $(x-2)^2+z^2-(y-1)^2=3$.

3. **Divide by the positive constant.** The standard form is

$$
\frac{(x-2)^2}{3}+\frac{z^2}{3}-\frac{(y-1)^2}{3}=1.
$$

4. **Classify and check.** There are two positive squares and one negative square, so this is a one-sheet hyperboloid. The negative term marks the $y$-axis direction. At $y=1$, the trace is $(x-2)^2+z^2=3$, its circular waist. This confirms the stated shape, center, and orientation.
::::
:::::

:::::problem[Problem 3.39 — Identify a cylinder]{difficulty=easy}
Name $x^2+z^2=4$, give the direction in which the surface extends and the radius of its circular trace.

::::solution[Solution]
**Answer:** Circular cylinder parallel to the $y$-axis, with radius $2$.

1. **Look for a missing variable.** The equation $x^2+z^2=4$ contains only $x$ and $z$. There is no restriction on $y$, so if $(x,y,z)$ lies on the surface, then $(x,y+t,z)$ lies on it for every real $t$. The surface therefore extends along the $y$-direction.

2. **Analyze a perpendicular trace.** Fix any $y=k$. In the resulting $xz$-plane the equation remains $x^2+z^2=4=2^2$, the equation of a circle centered at $(0,k,0)$ with radius $2$.

3. **Check the cross-section and direction.** Both $(2,k,0)$ and $(0,k,-2)$ satisfy $x^2+z^2=4$ for every $k$. Their distance from the line $x=z=0$ is $2$. Thus stacking those identical circles for all $y$ produces the required circular cylinder.
::::
:::::

:::::problem[Problem 3.40 — Identify a hyperboloid]{difficulty=standard}
**Test 2 version B style.** Identify $-4x^2+3y^2-6z^2=9$, state its axis and vertices, and explain how the trace $y=k$ confirms the name.

::::solution[Solution]
**Answer:** Hyperboloid of two sheets along $y$, with vertices $(0,\pm\sqrt3,0)$.

1. **Put the equation into standard form.** Start with $-4x^2+3y^2-6z^2=9$ and divide every term by the positive number $9$:

$$
\frac{y^2}{3}-\frac{4x^2}{9}-\frac{2z^2}{3}=1.
$$

2. **Identify the surface.** One squared term is positive while the other two are negative; this pattern gives a hyperboloid of two sheets. The positive term is $y^2$, so the sheets separate along the $y$-axis.

3. **Locate the vertices.** Set $x=z=0$. Then $y^2/3=1$, so $y^2=3$ and $y=\pm\sqrt3$. The vertices are $(0,\sqrt3,0)$ and $(0,-\sqrt3,0)$.

4. **Verify using $y=k$ traces.** Solving for the remaining variables gives

$$
\frac{4x^2}{9}+\frac{2z^2}{3}=\frac{k^2}{3}-1.
$$

For $|k|<\sqrt3$ the right side is negative and no points exist; at equality the trace is a single point; for $|k|>\sqrt3$ it is an ellipse. The gap between two families of ellipses confirms two disconnected sheets.
::::
:::::

:::callout-key[Test 2 scoring path: names and sketches]
Both released keys contain four surface-identification/sketching parts, five points each. Name the **axis**, not just the family. If a variable is missing, the graph is a cylinder along that axis; if a variable is unsquared, it is the opening axis of a paraboloid. For a hyperboloid, first put the equation in form $=1$: two positive squares and one negative square means **one sheet**, while one positive and two negative means **two sheets**. Write one horizontal and one vertical trace to justify the sketch.
:::

### Test 2 problem sets from MA 2733

These 106 labeled exercises reproduce Homework 3 (§§12.1–12.2), Homework 4 (§§12.3–12.4), Homework 5 (§§12.5–12.6), and the MWF Test 2 review. The two released tests appear afterward with their own worked keys. Answers come first; the work retains the arithmetic, formulas, determinant signs, substitutions, and graph classifications needed for written credit. Homework 3 intentionally skips Q18, as in the original assignment. Multiple-choice and graph letters refer to the supplied homework choices.

### Homework 3 — §§12.1 and 12.2

:::::problem[Problem 3.41 — distance between two points]{difficulty=easy}
Find the distance between $P_1(3,5,1)$ and $P_2(6,3,7)$. Give an exact answer, using radicals as needed.

::::solution[Solution]
**Answer:** $7$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. Apply the calculation in the displayed expression.

$$
d=\sqrt{(6-3)^2+(3-5)^2+(7-1)^2}=\sqrt{9+4+36}=\sqrt{49}=7
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.42 — distance between two points]{difficulty=easy}
Find the distance between $P_1(3,2,5)$ and $P_2(11,-2,6)$.

::::solution[Solution]
**Answer:** $9$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. The differences are $11-3=8$, $-2-2=-4$ and $6-5=1$. Squaring the negative one gives $16$, so nothing is lost by the sign:

$$
d=\sqrt{8^2+(-4)^2+1^2}=\sqrt{64+16+1}=\sqrt{81}=9
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.43 — distance, radical answer]{difficulty=easy}
Find the distance between $P_1(5,0,-5)$ and $P_2(13,-5,-6)$.

::::solution[Solution]
**Answer:** $3\sqrt{10}$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. The differences are $8$, $-5$ and $-1$:

$$
d=\sqrt{8^2+(-5)^2+(-1)^2}=\sqrt{64+25+1}=\sqrt{90}
$$

$$
\sqrt{90}=\sqrt{9}\,\sqrt{10}=3\sqrt{10}
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.44 — distance to the coordinate planes]{difficulty=easy}
Find the distance from the point $(-2,-5,1)$ to (a) the $xy$-plane, (b) the $yz$-plane, (c) the $xz$-plane.

::::solution[Solution]
**Answer:** (a) $1$, (b) $2$, (c) $5$.

1. A coordinate plane fixes one coordinate at zero. Compare the absolute values of the perpendicular coordinates rather than the full distance from the origin.

2. The $xy$-plane is $z=0$, so the distance is $|z|=|1|=1$. - The $yz$-plane is $x=0$, so the distance is $|x|=|-2|=2$. - The $xz$-plane is $y=0$, so the distance is $|y|=|-5|=5$.

3. **Check.** The point lies on the specified coordinate plane exactly when its perpendicular coordinate is zero; plane distance is that coordinate’s absolute value.
::::
:::::

:::::problem[Problem 3.45 — equation of a sphere]{difficulty=easy}
Find the equation of the sphere with center $(4,1,3)$ and radius $\sqrt{10}$. Choose the correct equation.

A. $(x+4)^2+(y+1)^2+(z+3)^2=\sqrt{10}$

B. $(x+4)^2+(y+1)^2+(z+3)^2=10$

C. $(x-4)^2+(y-1)^2+(z-3)^2=10$

D. $(x-4)^2+(y-1)^2+(z-3)^2=\sqrt{10}$

::::solution[Solution]
**Answer:** C.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. A sphere with center $(a,b,c)$ and radius $r$ is $(x-a)^2+(y-b)^2+(z-c)^2=r^2$. There are two things to get right, and the options are built to test each.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.46 — equation of a sphere, fractions]{difficulty=standard}
Find an equation for the sphere with center $\left(-5,\frac16,-\frac27\right)$ and radius $\frac58$. Choose the correct equation.

A. $(x-5)^2+\left(y+\frac16\right)^2+\left(z-\frac27\right)^2=\frac58$

B. $(x+5)^2+\left(y-\frac16\right)^2+\left(z+\frac27\right)^2=\frac{25}{64}$

C. $(x+5)^2+\left(y-\frac16\right)^2+\left(z+\frac27\right)^2=\frac58$

D. $(x-5)^2+\left(y+\frac16\right)^2+\left(z-\frac27\right)^2=\frac{25}{64}$

::::solution[Solution]
**Answer:** B.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Subtract the center from each variable. A center coordinate of $-5$ gives $x-(-5)=x+5$. A center coordinate of $\frac16$ gives $y-\frac16$. A center coordinate of $-\frac27$ gives $z+\frac27$. That is the left side of B and C, and it rules out A and D, whose signs are all reversed.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.47 — read off center and radius]{difficulty=easy}
Find the center and radius of the sphere $(x+6)^2+y^2+(z-6)^2=20$.

::::solution[Solution]
**Answer:** center $(-6,0,6)$, radius $2\sqrt5$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Rewrite each term in the form (variable minus center). Then $(x+6)^2=(x-(-6))^2$ gives the $x$-coordinate $-6$; $y^2=(y-0)^2$ gives $0$; and $(z-6)^2$ gives $6$. The center is $(-6,0,6)$.

$$
r=\sqrt{20}=\sqrt{4\cdot5}=2\sqrt5
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::


### Homework 3: continued set 2

:::::problem[Problem 3.48 — complete the square]{difficulty=standard}
Find the center and radius of the sphere $x^2+y^2+z^2-2x-5z=0$. Write the equation in standard form by completing the squares on the $x$-, $y$- and $z$-terms.

::::solution[Solution]
**Answer:** $(x-1)^2+(y-0)^2+\left(z-\frac52\right)^2=\frac{29}{4}$; center $\left(1,0,\frac52\right)$; radius $\frac{\sqrt{29}}{2}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. To complete a square, take half the coefficient of the linear term and square it. For $x$: half of $-2$ is $-1$, and its square is $1$. For $z$: half of $-5$ is $-\frac52$, and its square is $\frac{25}{4}$. Add both numbers to **both** sides, so the equation stays balanced:

$$
(x^2-2x)+y^2+(z^2-5z)=0
$$

$$
(x^2-2x+1)+y^2+\left(z^2-5z+\tfrac{25}{4}\right)=1+\tfrac{25}{4}
$$

$$
(x-1)^2+y^2+\left(z-\tfrac52\right)^2=\frac{29}{4}
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.49 — complete the square]{difficulty=standard}
Find the center and radius of the sphere $x^2+y^2+z^2+6x-6z=0$.

::::solution[Solution]
**Answer:** center $(-3,0,3)$, radius $3\sqrt2$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Half of $6$ is $3$, and $3^2=9$. Half of $-6$ is $-3$, and $(-3)^2=9$. Add $9$ for the $x$-terms and $9$ for the $z$-terms to both sides:

$$
(x^2+6x+9)+y^2+(z^2-6z+9)=9+9
$$

$$
(x+3)^2+y^2+(z-3)^2=18
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.50 — complete the square with a leading coefficient]{difficulty=challenge}
Find the center and radius of the sphere $5x^2+5y^2+5z^2+x+y+z=9$.

::::solution[Solution]
**Answer:** center $\left(-\frac1{10},-\frac1{10},-\frac1{10}\right)$, radius $\frac{\sqrt{183}}{10}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. The linear coefficient in each variable is $\frac15$. Half of it is $\frac1{10}$, and its square is $\frac1{100}$. Add $\frac1{100}$ once for each of the three variables, so $\frac3{100}$ in all, to the right side:

$$
x^2+y^2+z^2+\frac x5+\frac y5+\frac z5=\frac95
$$

$$
\left(x+\tfrac1{10}\right)^2+\left(y+\tfrac1{10}\right)^2+\left(z+\tfrac1{10}\right)^2=\frac95+\frac3{100}=\frac{180}{100}+\frac3{100}=\frac{183}{100}
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.51 — scalar multiple of a vector]{difficulty=easy}
Let $\mathbf u=\langle7,-4\rangle$. Find the component form and the magnitude of the vector $3\mathbf u$.

::::solution[Solution]
**Answer:** $3\mathbf u=\langle21,-12\rangle$ and $|3\mathbf u|=3\sqrt{65}$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Since $585=9\cdot65$, this is $\sqrt9\,\sqrt{65}=3\sqrt{65}$. As a check, $|\mathbf u|=\sqrt{49+16}=\sqrt{65}$, and stretching a vector by $3$ multiplies its length by $3$.

$$
|3\mathbf u|=\sqrt{21^2+(-12)^2}=\sqrt{441+144}=\sqrt{585}
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.52 — a linear combination]{difficulty=easy}
Let $\mathbf u=\langle4,-4\rangle$ and $\mathbf v=\langle-1,1\rangle$. Find the component form and the magnitude of $4\mathbf u-4\mathbf v$.

::::solution[Solution]
**Answer:** $\langle20,-20\rangle$ and $20\sqrt2$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. First scale each vector: $4\mathbf u=\langle16,-16\rangle$ and $4\mathbf v=\langle-4,4\rangle$. Then subtract component by component, being careful with the double negative:

$$
4\mathbf u-4\mathbf v=\langle16-(-4),\,-16-4\rangle=\langle20,-20\rangle
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.53 — a linear combination with fractions]{difficulty=standard}
Let $\mathbf u=\langle7,-2\rangle$ and $\mathbf v=\langle-3,8\rangle$. Find (a) the component form and (b) the magnitude of $\frac{20}{29}\mathbf u+\frac{21}{29}\mathbf v$. Type integers or simplified fractions, and exact radicals.

::::solution[Solution]
**Answer:** (a) $\left\langle\frac{77}{29},\frac{128}{29}\right\rangle$; (b) $\frac{\sqrt{22313}}{29}$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Combine component by component over the common denominator $29$. For the $x$-component:

$$
\frac{20\cdot7+21\cdot(-3)}{29}=\frac{140-63}{29}=\frac{77}{29}
$$

$$
\frac{20\cdot(-2)+21\cdot8}{29}=\frac{-40+168}{29}=\frac{128}{29}
$$

$$
\frac{\sqrt{77^2+128^2}}{29}=\frac{\sqrt{5929+16384}}{29}=\frac{\sqrt{22313}}{29}
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::


### Homework 3: continued set 3

:::::problem[Problem 3.54 — vector from two points]{difficulty=easy}
Find the component form of the vector $\overrightarrow{PQ}$, where $P=(1,7)$ and $Q=(9,-3)$.

::::solution[Solution]
**Answer:** $\langle8,-10\rangle$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. The vector from $P$ to $Q$ is the terminal point minus the initial point: $\langle9-1,\,-3-7\rangle=\langle8,-10\rangle$.

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.55 — vector to the origin]{difficulty=easy}
Find the component form of the vector from the point $A=(2,9)$ to the origin.

::::solution[Solution]
**Answer:** $\langle-2,-9\rangle$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. The origin is the terminal point, so subtract $A$ from it: $\langle0-2,\,0-9\rangle=\langle-2,-9\rangle$. The vector points back toward the origin, so both components are negative.

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.56 — write a vector in i, j, k form]{difficulty=easy}
Express $\overrightarrow{P_1P_2}$ in the form $\mathbf v=v_1\mathbf i+v_2\mathbf j+v_3\mathbf k$, if $P_1=(-1,2,0)$ and $P_2=(-1,-1,1)$.

::::solution[Solution]
**Answer:** $0\,\mathbf i-3\,\mathbf j+1\,\mathbf k$.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. Terminal minus initial: $P_2-P_1=(-1-(-1),\,-1-2,\,1-0)=(0,-3,1)$. The coefficients are the components, so $\mathbf v=0\mathbf i-3\mathbf j+1\mathbf k$.

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.57 — write a vector in i, j, k form, multiple choice]{difficulty=easy}
Express $\overrightarrow{AB}$ in the form $v_1\mathbf i+v_2\mathbf j+v_3\mathbf k$, if $A=(-7,8,5)$ and $B=(-12,8,-2)$.

A. $5\mathbf i+7\mathbf k$

B. $19\mathbf i-16\mathbf j-3\mathbf k$

C. $-5\mathbf i-7\mathbf k$

D. $-19\mathbf i+16\mathbf j+3\mathbf k$

E. $-6\mathbf j+6\mathbf k$

F. $6\mathbf j-6\mathbf k$

::::solution[Solution]
**Answer:** C.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. $B-A=(-12+7,\;8-8,\;-2-5)=(-5,0,-7)$, which is $-5\mathbf i-7\mathbf k$. There is no $\mathbf j$ term because the two points have the same $y$-coordinate. Option A has the opposite signs, so it is $\overrightarrow{BA}$ instead.

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.58 — length times direction]{difficulty=standard}
Express the vector $6\mathbf i+7\mathbf j+6\mathbf k$ as a product of its length and its direction.

::::solution[Solution]
**Answer:** $11\left[\frac6{11}\mathbf i+\frac7{11}\mathbf j+\frac6{11}\mathbf k\right]$.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. The length is $\sqrt{36+49+36}=\sqrt{121}=11$. The direction is the unit vector $\frac{\mathbf v}{|\mathbf v|}=\left\langle\frac6{11},\frac7{11},\frac6{11}\right\rangle$. The vector is then its length times its direction, $\mathbf v=|\mathbf v|\cdot\frac{\mathbf v}{|\mathbf v|}$.

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.59 — length times direction, multiple choice]{difficulty=standard}
Express $\frac1{\sqrt2}\mathbf i-\frac1{\sqrt2}\mathbf j+\frac1{\sqrt2}\mathbf k$ as a product of its length and its direction.

A. $\frac1{\sqrt2}(\mathbf i-\mathbf j+\mathbf k)$

B. $\frac1{\sqrt3}\left(\sqrt{\tfrac32}\,\mathbf i-\sqrt{\tfrac32}\,\mathbf j+\sqrt{\tfrac32}\,\mathbf k\right)$

C. $\sqrt{\tfrac32}\left(\frac1{\sqrt3}\mathbf i-\frac1{\sqrt3}\mathbf j+\frac1{\sqrt3}\mathbf k\right)$

D. $\sqrt{\tfrac32}\left(\frac{\sqrt3}2\mathbf i-\frac{\sqrt3}2\mathbf j+\frac{\sqrt3}2\mathbf k\right)$

::::solution[Solution]
**Answer:** C.

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. The length is $\sqrt{\frac12+\frac12+\frac12}=\sqrt{\frac32}$. The direction is the vector divided by that length. Each component becomes $\frac1{\sqrt2}\cdot\sqrt{\frac23}=\frac1{\sqrt3}$, with its sign kept, so

$$
\mathbf v=\sqrt{\tfrac32}\left\langle\tfrac1{\sqrt3},-\tfrac1{\sqrt3},\tfrac1{\sqrt3}\right\rangle
$$

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.60 — direction and midpoint]{difficulty=standard}
For the points $P_1(-3,2,5)$ and $P_2(1,1,0)$, find the direction of $\overrightarrow{P_1P_2}$ and the midpoint of the segment $P_1P_2$.

::::solution[Solution]
**Answer:** direction $\frac4{\sqrt{42}}\mathbf i-\frac1{\sqrt{42}}\mathbf j-\frac5{\sqrt{42}}\mathbf k$; midpoint $\left(-1,\frac32,\frac52\right)$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. The vector is $\overrightarrow{P_1P_2}=\langle1-(-3),\,1-2,\,0-5\rangle=\langle4,-1,-5\rangle$. Its length is $\sqrt{16+1+25}=\sqrt{42}$. Dividing each component by the length gives the direction.

$$
\left(\frac{-3+1}2,\ \frac{2+1}2,\ \frac{5+0}2\right)=\left(-1,\frac32,\frac52\right)
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::


### Homework 3: continued set 4

:::::problem[Problem 3.61 — direction and midpoint]{difficulty=standard}
For $P_1(4,7,4)$ and $P_2(3,6,5)$, find the direction of $\overrightarrow{P_1P_2}$ and the midpoint of the segment.

::::solution[Solution]
**Answer:** direction $-\frac1{\sqrt3}\mathbf i-\frac1{\sqrt3}\mathbf j+\frac1{\sqrt3}\mathbf k$; midpoint $\left(\frac72,\frac{13}2,\frac92\right)$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. $\overrightarrow{P_1P_2}=\langle3-4,\,6-7,\,5-4\rangle=\langle-1,-1,1\rangle$, with length $\sqrt{1+1+1}=\sqrt3$. Dividing by the length gives the direction.

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.62 — recover the starting point]{difficulty=standard}
If $\overrightarrow{AB}=\mathbf i+8\mathbf j-3\mathbf k$ and $B$ is the point $(5,4,4)$, find $A$.

::::solution[Solution]
**Answer:** $A=(4,-4,7)$.

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. The vector $\overrightarrow{AB}$ is $B-A$, so $A=B-\overrightarrow{AB}$. Subtract the components:

$$
A=(5-1,\ 4-8,\ 4-(-3))=(4,-4,7)
$$

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::


### Homework 4 — §§12.3 and 12.4

:::::problem[Problem 3.63 — angle between vectors]{difficulty=standard}
Find the angle between $\mathbf u=4\mathbf i+5\mathbf j$ and $\mathbf v=2\mathbf i+\mathbf j+4\mathbf k$. Round to the nearest hundredth.

::::solution[Solution]
**Answer:** $\theta\approx1.11$ radians.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Use $\cos\theta=\dfrac{\mathbf u\cdot\mathbf v}{|\mathbf u||\mathbf v|}$. The dot product is $8+5+0=13$. The lengths are $|\mathbf u|=\sqrt{41}$ and $|\mathbf v|=\sqrt{4+1+16}=\sqrt{21}$. So

$$
\cos\theta=\frac{13}{\sqrt{861}}\approx0.4430,\qquad \theta=\arccos(0.4430)\approx1.1093\approx1.11
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.64 — angle between vectors with radicals]{difficulty=standard}
Find the angle between $\mathbf u=\sqrt5\,\mathbf i-7\mathbf j$ and $\mathbf v=\sqrt5\,\mathbf i+\mathbf j-4\mathbf k$. Round to the nearest hundredth.

::::solution[Solution]
**Answer:** $\theta\approx1.63$ radians.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The dot product is $\sqrt5\cdot\sqrt5+(-7)(1)+0\cdot(-4)=5-7=-2$. The lengths are $|\mathbf u|=\sqrt{5+49}=\sqrt{54}$ and $|\mathbf v|=\sqrt{5+1+16}=\sqrt{22}$. So

$$
\cos\theta=\frac{-2}{\sqrt{1188}}\approx-0.0580,\qquad\theta\approx1.6289\approx1.63
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.65 — angles of a triangle]{difficulty=challenge}
Find the measures of the angles of the triangle with vertices $A=(-3,0)$, $B=(2,2)$, $C=(1,-2)$. Round to the nearest thousandth of a degree.

::::solution[Solution]
**Answer:** $m\angle ABC=54.162^\circ$, $m\angle BCA=77.471^\circ$, $m\angle CAB=48.366^\circ$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. **At $B$.** $\overrightarrow{BA}=\langle-5,-2\rangle$ and $\overrightarrow{BC}=\langle-1,-4\rangle$. The dot product is $5+8=13$, and the lengths are $\sqrt{29}$ and $\sqrt{17}$:

$$
\cos B=\frac{13}{\sqrt{29}\sqrt{17}}=\frac{13}{\sqrt{493}},\qquad B=54.162^\circ
$$

$$
\cos C=\frac4{\sqrt{340}},\qquad C=77.471^\circ
$$

$$
\cos A=\frac{16}{\sqrt{580}},\qquad A=48.366^\circ
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.66 — dot product, angle, component and projection]{difficulty=challenge}
For $\mathbf v=-10\mathbf i-3\mathbf j-\sqrt3\,\mathbf k$ and $\mathbf u=10\mathbf i+3\mathbf j+\sqrt3\,\mathbf k$, find (a) $\mathbf v\cdot\mathbf u$, $|\mathbf v|$ and $|\mathbf u|$; (b) the cosine of the angle between $\mathbf v$ and $\mathbf u$; (c) the scalar component of $\mathbf u$ in the direction of $\mathbf v$; (d) $\operatorname{proj}_{\mathbf v}\mathbf u$.

::::solution[Solution]
**Answer:** (a) $-112$, $4\sqrt7$, $4\sqrt7$; (b) $-1$; (c) $-4\sqrt7$; (d) $10\mathbf i+3\mathbf j+\sqrt3\,\mathbf k$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. **(a)** $\mathbf v\cdot\mathbf u=-100-9-3=-112$. The squared length is $|\mathbf v|^2=100+9+3=112=16\cdot7$, so $|\mathbf v|=4\sqrt7$. The vector $\mathbf u$ has the same components with opposite signs, so $|\mathbf u|=4\sqrt7$ as well.

$$
\operatorname{proj}_{\mathbf v}\mathbf u=\frac{\mathbf u\cdot\mathbf v}{|\mathbf v|^2}\,\mathbf v=\frac{-112}{112}\,\mathbf v=-\mathbf v=10\mathbf i+3\mathbf j+\sqrt3\,\mathbf k
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.67 — dot product, angle, component and projection]{difficulty=challenge}
For $\mathbf v=10\mathbf i+11\mathbf j-2\mathbf k$ and $\mathbf u=7\mathbf i+24\mathbf j$, find the same four items (a) to (d) as in Q4.

::::solution[Solution]
**Answer:** (a) $334$, $15$, $25$; (b) $\frac{334}{375}$; (c) $\frac{334}{15}$; (d) $\frac{668}{45}\mathbf i+\frac{3674}{225}\mathbf j-\frac{668}{225}\mathbf k$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. **(a)** $\mathbf v\cdot\mathbf u=70+264+0=334$. The lengths are $|\mathbf v|=\sqrt{100+121+4}=\sqrt{225}=15$ and $|\mathbf u|=\sqrt{49+576}=\sqrt{625}=25$.

$$
\left\langle\frac{3340}{225},\ \frac{3674}{225},\ -\frac{668}{225}\right\rangle=\left\langle\frac{668}{45},\ \frac{3674}{225},\ -\frac{668}{225}\right\rangle
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.68 — dot product, angle, component and projection with radicals]{difficulty=challenge}
For $\mathbf v=3\mathbf i+\mathbf j$ and $\mathbf u=-7\mathbf i+\sqrt7\,\mathbf j$, find the same four items (a) to (d) as in Q4.

::::solution[Solution]
**Answer:** (a) $-21+\sqrt7$, $\sqrt{10}$, $2\sqrt{14}$; (b) $\frac{-21+\sqrt7}{4\sqrt{35}}$; (c) $\frac{-21+\sqrt7}{\sqrt{10}}$; (d) $\frac{-63+3\sqrt7}{10}\mathbf i+\frac{-21+\sqrt7}{10}\mathbf j$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. **(a)** $\mathbf v\cdot\mathbf u=-21+\sqrt7$. The lengths are $|\mathbf v|=\sqrt{9+1}=\sqrt{10}$ and $|\mathbf u|=\sqrt{49+7}=\sqrt{56}=2\sqrt{14}$.

$$
\left\langle\frac{-63+3\sqrt7}{10},\ \frac{-21+\sqrt7}{10}\right\rangle
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### Homework 4: continued set 2

:::::problem[Problem 3.69 — acute angle between two lines]{difficulty=standard}
The acute angle between intersecting lines that do not cross at right angles is the same as the angle between vectors normal to the lines, or between vectors parallel to the lines. Use this fact to find the acute angle between the lines $5x-9y=3$ and $x-y=3$. Round to two decimal places.

::::solution[Solution]
**Answer:** $\approx0.28$ radians.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. For a line $ax+by=c$, the vector $\langle a,b\rangle$ is normal to it. So the two normals are $\langle5,-9\rangle$ and $\langle1,-1\rangle$. The angle between them is

$$
\cos\theta=\frac{5+9}{\sqrt{106}\,\sqrt2}=\frac{14}{\sqrt{212}}\approx0.9615,\qquad\theta\approx0.2783\approx0.28
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.70 — acute angle between two lines, exact]{difficulty=standard}
The vector $\mathbf w=a\mathbf i+b\mathbf j$ is perpendicular to the line $ax+by=c$ and parallel to the line $bx-ay=c$. Use this to find the acute angle between the lines $3x+y=0$ and $2x-y=2$. Give an exact answer, using $\pi$.

::::solution[Solution]
**Answer:** $\dfrac\pi4$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The angle whose cosine is $\frac1{\sqrt2}$ is $\theta=\frac\pi4$.

$$
\cos\theta=\frac{6-1}{\sqrt{10}\,\sqrt5}=\frac5{\sqrt{50}}=\frac5{5\sqrt2}=\frac1{\sqrt2}
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.71 — cross product, length and direction]{difficulty=standard}
Find the length and direction (when defined) of $\mathbf u\times\mathbf v$ and $\mathbf v\times\mathbf u$, for $\mathbf u=6\mathbf i-2\mathbf j-7\mathbf k$ and $\mathbf v=7\mathbf i-7\mathbf k$. For each direction the options are: A, fill in the three components; or B, the direction is undefined.

::::solution[Solution]
**Answer:** $|\mathbf u\times\mathbf v|=21$ with direction $\frac23\mathbf i-\frac13\mathbf j+\frac23\mathbf k$ (option A); $|\mathbf v\times\mathbf u|=21$ with direction $-\frac23\mathbf i+\frac13\mathbf j-\frac23\mathbf k$ (option A).

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. The $\mathbf i$ bracket is $14$. The $\mathbf j$ bracket is $-42+49=7$, and it carries a minus sign in front. The $\mathbf k$ bracket is $14$. So $\mathbf u\times\mathbf v=\langle14,-7,14\rangle$.

$$
\mathbf u\times\mathbf v=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\6&-2&-7\\7&0&-7\end{vmatrix}=\mathbf i\big[(-2)(-7)-(-7)(0)\big]-\mathbf j\big[(6)(-7)-(-7)(7)\big]+\mathbf k\big[(6)(0)-(-2)(7)\big]
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.72 — cross product of parallel vectors]{difficulty=standard}
Find the length and direction (when defined) of $\mathbf u\times\mathbf v$ and $\mathbf v\times\mathbf u$, for $\mathbf u=-4\mathbf i+2\mathbf j-4\mathbf k$ and $\mathbf v=-2\mathbf i+\mathbf j-2\mathbf k$. For each direction the options are: A, fill in the three components; or B, the direction is not defined.

::::solution[Solution]
**Answer:** $|\mathbf u\times\mathbf v|=0$ and $|\mathbf v\times\mathbf u|=0$; in both cases the direction is not defined (option B).

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The zero vector has length $0$, and it has no direction: finding a direction means dividing by the length, and that would be dividing by zero. That is why option B is the right one for both orders.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.73 — cross product, length and direction]{difficulty=standard}
Find the length and direction (when defined) of $\mathbf u\times\mathbf v$ and $\mathbf v\times\mathbf u$, for $\mathbf u=-2\mathbf i-4\mathbf j-3\mathbf k$ and $\mathbf v=5\mathbf i+5\mathbf j+2\mathbf k$.

::::solution[Solution]
**Answer:** $|\mathbf u\times\mathbf v|=3\sqrt{30}$ with direction $\frac7{3\sqrt{30}}\mathbf i-\frac{11}{3\sqrt{30}}\mathbf j+\frac{10}{3\sqrt{30}}\mathbf k$; $|\mathbf v\times\mathbf u|=3\sqrt{30}$ with direction $-\frac7{3\sqrt{30}}\mathbf i+\frac{11}{3\sqrt{30}}\mathbf j-\frac{10}{3\sqrt{30}}\mathbf k$.

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. $\mathbf i$: $(-4)(2)-(-3)(5)=-8+15=7$. - $\mathbf j$: $-\big[(-2)(2)-(-3)(5)\big]=-[-4+15]=-11$. - $\mathbf k$: $(-2)(5)-(-4)(5)=-10+20=10$.

3. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::


### Homework 4: continued set 3

:::::problem[Problem 3.74 — area of a triangle and a unit normal]{difficulty=challenge}
(a) Find the area of the triangle determined by the points $P(-2,2,1)$, $Q(1,0,2)$, $R(0,1,-2)$. (b) Find a unit vector perpendicular to the plane $PQR$.

A. $\frac1{3\sqrt{19}}(11\mathbf i+7\mathbf j+\mathbf k)$

B. $\frac1{\sqrt2}(\mathbf i+\mathbf j)$

C. $\frac1{3\sqrt{19}}(7\mathbf i+11\mathbf j+\mathbf k)$

D. $\frac1{\sqrt6}(\mathbf i+2\mathbf j+\mathbf k)$

::::solution[Solution]
**Answer:** (a) $\frac{3\sqrt{19}}2$; (b) C.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Two sides from $P$ are $\overrightarrow{PQ}=\langle3,-2,1\rangle$ and $\overrightarrow{PR}=\langle2,-1,-3\rangle$. Their cross product is

$$
\overrightarrow{PQ}\times\overrightarrow{PR}=\mathbf i\big[(-2)(-3)-(1)(-1)\big]-\mathbf j\big[(3)(-3)-(1)(2)\big]+\mathbf k\big[(3)(-1)-(-2)(2)\big]=7\mathbf i+11\mathbf j+\mathbf k
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.75 — area of a triangle and a unit normal]{difficulty=challenge}
Answer the same two parts as in Q12 for $P(2,-2,-1)$, $Q(-1,0,-2)$, $R(0,-1,2)$.

A. $\frac1{\sqrt6}(\mathbf i+2\mathbf j+\mathbf k)$

B. $\frac1{\sqrt2}(\mathbf i+\mathbf j)$

C. $\frac1{3\sqrt{19}}(11\mathbf i+7\mathbf j+\mathbf k)$

D. $\frac1{3\sqrt{19}}(7\mathbf i+11\mathbf j+\mathbf k)$

::::solution[Solution]
**Answer:** (a) $\frac{3\sqrt{19}}2$; (b) D.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The $\mathbf i$ bracket is $6+1=7$. The $\mathbf j$ bracket is $-9-2=-11$, and the minus sign in front makes the term $+11$. The $\mathbf k$ bracket is $-3+4=1$. So the cross product is $7\mathbf i+11\mathbf j+\mathbf k$, the same as in Q12, with length $3\sqrt{19}$.

$$
\mathbf i\big[(2)(3)-(-1)(1)\big]-\mathbf j\big[(-3)(3)-(-1)(-2)\big]+\mathbf k\big[(-3)(1)-(2)(-2)\big]
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.76 — area of a parallelogram in the plane]{difficulty=standard}
Find the area of the parallelogram whose vertices are $A(-4,3)$, $B(1,0)$, $C(5,3)$, $D(0,6)$.

::::solution[Solution]
**Answer:** $27$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. For vectors with a zero third component, only the $\mathbf k$ term of the cross product survives: $5\cdot3-(-3)\cdot4=15+12=27$. The area is the length of the cross product, $|27|=27$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.77 — area of a parallelogram in space]{difficulty=standard}
Find the area of the parallelogram whose vertices are $A(0,0,0)$, $B(3,2,6)$, $C(5,0,6)$, $D(2,-2,0)$. Using side $\overrightarrow{AB}$ as $\mathbf u$ and $\overrightarrow{AD}$ as $\mathbf v$, find $\mathbf u\times\mathbf v$.

::::solution[Solution]
**Answer:** $\mathbf u\times\mathbf v=12\mathbf i+12\mathbf j-10\mathbf k$; area $2\sqrt{97}$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. $\mathbf i$: $2\cdot0-6\cdot(-2)=12$. - $\mathbf j$: $-\big[3\cdot0-6\cdot2\big]=-[-12]=12$. - $\mathbf k$: $3\cdot(-2)-2\cdot2=-10$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.78 — area of a triangle in space]{difficulty=standard}
Find the area of the triangle with vertices $A(1,-1,-2)$, $B(-2,0,-1)$, $C(0,-2,1)$. Using side $\overrightarrow{AB}$ as $\mathbf u$ and $\overrightarrow{AC}$ as $\mathbf v$, find $\mathbf u\times\mathbf v$.

::::solution[Solution]
**Answer:** $\mathbf u\times\mathbf v=4\mathbf i+8\mathbf j+4\mathbf k$; area $2\sqrt6$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. $\mathbf i$: $1\cdot3-1\cdot(-1)=4$. - $\mathbf j$: $-\big[(-3)(3)-(1)(-1)\big]=-[-9+1]=8$. - $\mathbf k$: $(-3)(-1)-(1)(-1)=3+1=4$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.79 — volume of a parallelepiped]{difficulty=standard}
Find the volume of the parallelepiped with one vertex at $A(0,0,0)$ and three adjacent vertices at $B(2,1,0)$, $C(0,-3,1)$, $D(4,-5,7)$.

::::solution[Solution]
**Answer:** $28$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The determinant is $-28$, and a volume cannot be negative, so $V=28$.

$$
V=\left|\det\begin{pmatrix}2&1&0\\0&-3&1\\4&-5&7\end{pmatrix}\right|
$$

$$
2\big[(-3)(7)-(1)(-5)\big]-1\big[(0)(7)-(1)(4)\big]+0=2(-21+5)-1(-4)=-32+4=-28
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.80 — are four points coplanar?]{difficulty=standard}
Determine whether the points $A(4,2,1)$, $B(3,-1,0)$, $C(1,4,1)$, $D(5,3,-1)$ are coplanar.

::::solution[Solution]
**Answer:** not coplanar; the volume of the parallelepiped is $27$.

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. That is $-1(-4)+3(6)-1(-5)=4+18+5=27$. The volume is $27$, which is not zero, so the points are **not** coplanar.

$$
-1\big[2(-2)-0\cdot1\big]-(-3)\big[(-3)(-2)-0\cdot1\big]+(-1)\big[(-3)(1)-(2)(1)\big]
$$

3. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::


### Homework 5 — §§12.5 and 12.6

:::::problem[Problem 3.81 — parametric line, point and direction]{difficulty=easy}
Find a parametric equation for the line through $P(5,2,3)$ parallel to the vector $8\mathbf i+5\mathbf j+2\mathbf k$. Choose the correct answer.

A. $x=5+8t,\ y=2+5t,\ z=3+2t$

B. $x=8+5t,\ y=5+2t,\ z=2+3t$

C. $x=8+5t,\ y=2+5t,\ z=3+2t$

D. $x=5+8t,\ y=5+2t,\ z=2+3t$

::::solution[Solution]
**Answer:** A.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. A line is a point plus $t$ times a direction: $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$, where $(x_0,y_0,z_0)$ is the point and $(a,b,c)$ the direction. With point $(5,2,3)$ and direction $(8,5,2)$ this is exactly $x=5+8t$, $y=2+5t$, $z=3+2t$. Each of B, C and D swaps a point coordinate with a direction coordinate somewhere.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.82 — parametric line with a zero coordinate]{difficulty=easy}
Find a parametric equation for the line through $P(-5,0,-1)$ parallel to $7\mathbf i+\mathbf j-8\mathbf k$.

A. $x=7-5t,\ y=t,\ z=-1-8t$

B. $x=-5+7t,\ y=1+t,\ z=-8-t$

C. $x=-5+7t,\ y=t,\ z=-1-8t$

D. $x=7-5t,\ y=1+t,\ z=-8-t$

::::solution[Solution]
**Answer:** C.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Take the point $(-5,0,-1)$ and the direction $(7,1,-8)$: $x=-5+7t$, $y=0+1\cdot t=t$, $z=-1-8t$. The zero $y$-coordinate of the point is what makes $y=t$ with no constant. Options A and D put the direction in the constant slot; option B has $y=1+t$ and swaps the last coordinates.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.83 — line parallel to an axis]{difficulty=easy}
Find parametric equations for the line through $(7,-4,-6)$ parallel to the $y$-axis.

A. $x=7,\ y=-4+t,\ z=-6,\ -\infty\lt t\lt\infty$

B. $x=7+t,\ y=-4,\ z=-6+t,\ -\infty\lt t\lt\infty$

C. $x=-7+t,\ y=4,\ z=6+t,\ -\infty\lt t\lt\infty$

D. $x=-7,\ y=4+t,\ z=6,\ -\infty\lt t\lt\infty$

::::solution[Solution]
**Answer:** A.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. A line parallel to the $y$-axis has the direction $\mathbf j=\langle0,1,0\rangle$. So $x$ and $z$ do not change and stay at their starting values $7$ and $-6$, while $y$ starts at $-4$ and grows with $t$: $x=7$, $y=-4+t$, $z=-6$. Option D uses the point $(-7,4,6)$, which is the wrong point with every sign flipped. Options B and C move $x$ and $z$, which is a line in the wrong direction.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.84 — a line perpendicular to two lines]{difficulty=standard}
Find a vector equation of the line through $(4,3,1)$ that is perpendicular to the lines $\mathbf r_1(t)=\langle5-3t,\,5+6t,\,2-5t\rangle$ and $\mathbf r_2(t)=\langle-3t,\,5+t,\,2-t\rangle$. The form is $\langle x,y,z\rangle=\langle\square,\square,\square\rangle+t\,\langle\ ?\ \rangle$, where the direction is chosen from a drop-down with four options: $\langle1,13,5\rangle$, $\langle-1,12,15\rangle$, $\langle-3,5,-13\rangle$, $\langle-3,5,-11\rangle$.

::::solution[Solution]
**Answer:** $\langle x,y,z\rangle=\langle4,3,1\rangle+t\,\langle-1,12,15\rangle$

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. A perpendicular direction must have zero dot product with both $\mathbf d_1$ and $\mathbf d_2$. For $\langle-1,12,15\rangle$: with $\mathbf d_1$, $3+72-75=0$; with $\mathbf d_2$, $3+12-15=0$. The others fail; for example $\langle1,13,5\rangle\cdot\mathbf d_1=-3+78-25=50$.

$$
\mathbf d_1\times\mathbf d_2=\mathbf i\big[6(-1)-(-5)(1)\big]-\mathbf j\big[(-3)(-1)-(-5)(-3)\big]+\mathbf k\big[(-3)(1)-6(-3)\big]
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.85 — intersection of two lines]{difficulty=standard}
Find the point of intersection of the lines $x=2t+4,\ y=5t+5,\ z=3t+3$ and $x=s+5,\ y=4s+9,\ z=-4s-1$, with both parameters running over all real numbers.

::::solution[Solution]
**Answer:** $(4,5,3)$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. From $y$: $5t+5=4s+9$. Substitute $s=2t-1$: $5t+5=4(2t-1)+9=8t+5$. Subtract $5t+5$ from both sides: $3t=0$, so $t=0$, and then $s=-1$.

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::


### Homework 5: continued set 2

:::::problem[Problem 3.86 — distance from a point to a line]{difficulty=standard}
Find the distance from the point $(0,0,-8)$ to the line $x=-4t,\ y=-2t,\ z=4t$. Fill in: "The cross product used when calculating the distance is (drop-down)", "The magnitude of the cross product is $\square$", "The distance is $\square$". Give exact answers, using radicals.

The four choices for the cross product are:

1. $\langle-4,-2,4\rangle\times\langle0,0,-8\rangle=\langle32,-16,0\rangle$

2. $\langle0,0,-8\rangle\times\langle-4,-2,4\rangle=\langle-16,32,0\rangle$

3. $\langle0,0,-8\rangle\times\langle-4,-2,4\rangle=\langle32,-16,0\rangle$

4. $\langle-4,-2,4\rangle\times\langle0,0,-8\rangle=\langle-16,32,0\rangle$

::::solution[Solution]
**Answer:** cross product choice 2, $\langle0,0,-8\rangle\times\langle-4,-2,4\rangle=\langle-16,32,0\rangle$; magnitude $16\sqrt5$; distance $\frac{8\sqrt5}3$.

1. For a point-to-line distance, locate a point on the line and use its direction vector. The cross-product magnitude divided by direction length gives the perpendicular distance.

2. $\mathbf i$: $0\cdot4-(-8)(-2)=-16$. - $\mathbf j$: $-\big[0\cdot4-(-8)(-4)\big]=-[-32]=32$. - $\mathbf k$: $0\cdot(-2)-0\cdot(-4)=0$.

3. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

:::::problem[Problem 3.87 — distance from a point to a line]{difficulty=standard}
Find the distance from the point $(5,3,-6)$ to the line $x=-6-2t,\ y=5-t,\ z=-1+3t$. Give an exact answer.

::::solution[Solution]
**Answer:** $\dfrac{5\sqrt{10}}2$.

1. For a point-to-line distance, locate a point on the line and use its direction vector. The cross-product magnitude divided by direction length gives the perpendicular distance.

2. The $\mathbf i$ bracket is $6+5=11$. The $\mathbf j$ bracket is $-33+10=-23$, so the term is $+23$. The $\mathbf k$ bracket is $11+4=15$. The cross product is $\langle11,23,15\rangle$, with magnitude $\sqrt{121+529+225}=\sqrt{875}=5\sqrt{35}$.

$$
\overrightarrow{PS}\times\mathbf v=\mathbf i\big[2\cdot3-5(-1)\big]-\mathbf j\big[(-11)(3)-5(-2)\big]+\mathbf k\big[(-11)(-1)-2(-2)\big]
$$

$$
d=\frac{5\sqrt{35}}{\sqrt{14}}=5\sqrt{\frac{35}{14}}=5\sqrt{\frac52}=\frac{5\sqrt{10}}2\approx7.91
$$

3. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

:::::problem[Problem 3.88 — plane through a point with a given normal]{difficulty=easy}
Find the equation for the plane through $P_0=(0,5,-4)$ and normal to $\mathbf n=4\mathbf i-8\mathbf j-\mathbf k$.

A. $(x+4)+5(y-8)-4(z-1)=-36$

B. $4x-8y-z=0$

C. $4x-8y-z=-36$

D. $4x-8(y+5)-(z-4)=0$

::::solution[Solution]
**Answer:** C.

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. A plane is $\mathbf n\cdot(\mathbf r-\mathbf r_0)=0$, that is $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$. Here that is $4(x-0)-8(y-5)-1(z+4)=0$. Multiply out: $4x-8y+40-z-4=0$, so $4x-8y-z=-36$.

3. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::

:::::problem[Problem 3.89 — plane through three points]{difficulty=standard}
Find the equation for the plane through $P_0(4,4,-2)$, $Q_0(-2,1,-4)$, $R_0(-5,5,0)$.

A. $-4x-33y+30z=170$

B. $4(-2+x)+4(1+y)-2(-4+z)=0$

C. $4(-2+x)-2(1+y)+4(-4+z)=0$

D. $-4x+30y-33z=170$

::::solution[Solution]
**Answer:** D.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. The $\mathbf i$ bracket is $-6+2=-4$. The $\mathbf j$ bracket is $-12-18=-30$, so the term is $+30$. The $\mathbf k$ bracket is $-6-27=-33$. The normal is $\langle-4,30,-33\rangle$, so the plane is $-4x+30y-33z=d$.

$$
\mathbf i\big[(-3)(2)-(-2)(1)\big]-\mathbf j\big[(-6)(2)-(-2)(-9)\big]+\mathbf k\big[(-6)(1)-(-3)(-9)\big]
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.90 — plane perpendicular to a line]{difficulty=easy}
Find the equation for the plane through $P_0(4,5,6)$ perpendicular to the line $x=4+t,\ y=5+2t,\ z=-3t$.

A. $4x+5y+6z=-4$

B. $x+2y-3z=-4$

C. $4x+5y+6z=2$

D. $x+2y-3z=2$

::::solution[Solution]
**Answer:** B.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. If the plane is perpendicular to the line, then the line's direction is the plane's normal. The direction is $\langle1,2,-3\rangle$, so the plane is $x+2y-3z=d$. Evaluate at $P_0$: $1\cdot4+2\cdot5-3\cdot6=4+10-18=-4$. The plane is $x+2y-3z=-4$. Options A and C wrongly use the point $(4,5,6)$ as the normal.

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.91 — plane containing two lines]{difficulty=challenge}
Find an equation of the plane containing the lines $x=4+t,\ y=2-4t,\ z=1$ and $x=3s,\ y=6s,\ z=3-2s$, if possible. Choices: A, an equation for the plane is $\square$; B, the plane does not exist.

::::solution[Solution]
**Answer:** A, $4x+y+9z=27$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Divide by $2$ to get the simpler normal $\langle4,1,9\rangle$. The plane is $4x+y+9z=d$; put in the crossing point $(3,6,1)$: $12+6+9=27$.

$$
\langle1,-4,0\rangle\times\langle3,6,-2\rangle=\mathbf i\big[(-4)(-2)-0\cdot6\big]-\mathbf j\big[1(-2)-0\cdot3\big]+\mathbf k\big[1\cdot6-(-4)(3)\big]=\langle8,2,18\rangle
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::


### Homework 5: continued set 3

:::::problem[Problem 3.92 — where a line meets a plane]{difficulty=standard}
Find the point $P$ at which the line $x=-5-2t,\ y=-8-4t,\ z=7+7t$ intersects the plane $-7x-9y+6z=-6$. Give integers or simplified fractions.

::::solution[Solution]
**Answer:** $P=\left(-\dfrac{75}{46},\,-\dfrac{29}{23},\,-\dfrac{441}{92}\right)$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Set this equal to $-6$: $92t=-155$, so $t=-\dfrac{155}{92}$. Now put this $t$ back into each coordinate of the line.

$$
-7(-5-2t)-9(-8-4t)+6(7+7t)=35+14t+72+36t+42+42t=149+92t
$$

$$
x=-5-2\left(-\tfrac{155}{92}\right)=-5+\tfrac{155}{46}=\tfrac{-230+155}{46}=-\tfrac{75}{46}
$$

$$
y=-8-4\left(-\tfrac{155}{92}\right)=-8+\tfrac{155}{23}=\tfrac{-184+155}{23}=-\tfrac{29}{23}
$$

$$
z=7+7\left(-\tfrac{155}{92}\right)=\tfrac{644-1085}{92}=-\tfrac{441}{92}
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.93 — where a line meets a plane]{difficulty=easy}
Find the point at which the line $x=-2+2t,\ y=-4+5t,\ z=-1+6t$ meets the plane $x+y+z=-7$.

::::solution[Solution]
**Answer:** $(-2,-4,-1)$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Substitute: $(-2+2t)+(-4+5t)+(-1+6t)=-7+13t$. Set this equal to $-7$: $13t=0$, so $t=0$. The point is the line's starting point, $(-2,-4,-1)$. That it lies on the plane can be seen directly: $-2-4-1=-7$.

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.94 — distance from a point to a plane]{difficulty=standard}
Find the distance from the point $(-1,-4,-1)$ to the plane $-x-2y-3z=20$.

::::solution[Solution]
**Answer:** $\dfrac{4\sqrt{14}}7$, which equals $\dfrac8{\sqrt{14}}$.

1. For a point-to-plane distance, evaluate the plane equation at the point and divide the absolute value by the length of the plane normal.

2. For a plane $ax+by+cz=D$ the distance from $(x_0,y_0,z_0)$ is $\dfrac{|ax_0+by_0+cz_0-D|}{\sqrt{a^2+b^2+c^2}}$. Here

$$
d=\frac{|(-1)(-1)+(-2)(-4)+(-3)(-1)-20|}{\sqrt{1+4+9}}=\frac{|1+8+3-20|}{\sqrt{14}}=\frac8{\sqrt{14}}
$$

3. **Check.** A distance must be nonnegative; taking the absolute value removes any dependence on which side of the plane contains the point.
::::
:::::

:::::problem[Problem 3.95 — distance from a point to a plane]{difficulty=easy}
Find the distance from the point $(0,7,0)$ to the plane $8x+y+4z=24$.

::::solution[Solution]
**Answer:** $\dfrac{17}9$.

1. For a point-to-plane distance, evaluate the plane equation at the point and divide the absolute value by the length of the plane normal.

2. The denominator is a perfect square, so there is no radical left in the answer.

$$
d=\frac{|8\cdot0+7+4\cdot0-24|}{\sqrt{64+1+16}}=\frac{|-17|}{\sqrt{81}}=\frac{17}9
$$

3. **Check.** A distance must be nonnegative; taking the absolute value removes any dependence on which side of the plane contains the point.
::::
:::::

:::::problem[Problem 3.96 — match $x^2+y^2+4z^2=3$]{difficulty=standard}
Match $x^2+y^2+4z^2=3$ to its graph and surface type.

Graph choices: A. one-sheet hyperboloid; B. double cone about $x$; C. downward paraboloid about $z$; D. cylinder along $x$; E. flattened closed ellipsoid, thin in $z$; F. saddle with opposing wings; G. cylinder along $y$; H. smaller twisted saddle.

Type choices: A. one-sheet hyperboloid; B. two-sheet hyperboloid; C. cylinder; D. elliptic paraboloid; E. hyperbolic paraboloid; F. elliptic cone; G. ellipsoid.

::::solution[Solution]
**Answer:** graph E; type G, ellipsoid.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. All three squared terms are added with positive coefficients, and the right side is a positive constant. That is the signature of an ellipsoid. Divide by $3$ to reach standard form:

$$
\frac{x^2}3+\frac{y^2}3+\frac{z^2}{3/4}=1
$$

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.97 — match $49y^2+z^2=16$]{difficulty=standard}
Match $49y^2+z^2=16$ to its graph and surface type.

Graph choices: A. one-sheet hyperboloid; B. cone about $x$; C. cone about $y$; D. dome about $z$; E. cylinder along $y$; F. cylinder along $x$ with elliptical ends; G. elongated ellipsoid; H. saddle.

Type choices: A. two-sheet hyperboloid; B. elliptic paraboloid; C. cylinder; D. elliptic cone; E. ellipsoid; F. hyperbolic paraboloid; G. one-sheet hyperboloid.

::::solution[Solution]
**Answer:** graph F; type C, cylinder.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. The variable $x$ does not appear in the equation. That means the cross-section is the same curve for every value of $x$: the ellipse $49y^2+z^2=16$ in the $yz$-plane, slid along the $x$-axis. A surface with one variable missing is a cylinder whose rulings are parallel to that variable's axis, here the $x$-axis.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::


### Homework 5: continued set 4

:::::problem[Problem 3.98 — match $14x=z^2-y^2$]{difficulty=standard}
Match $14x=z^2-y^2$ to a graph and type.

Graph choices: A. saddle centered at the origin; B. vertical hourglass (one-sheet hyperboloid); C. two separated panels along $x$.

Type choices: elliptic paraboloid, cylinder, hyperbolic paraboloid, one-sheet hyperboloid, two-sheet hyperboloid (misprinted as "hyperbola of two sheets"), ellipsoid.

::::solution[Solution]
**Answer:** graph A; hyperbolic paraboloid.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. One variable, $x$, appears to the first power, and the other two appear squared with opposite signs: $x=\dfrac{z^2-y^2}{14}$. That is a hyperbolic paraboloid, a saddle whose "height" axis is the $x$-axis.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.99 — match $y^2+4z^2=x^2$]{difficulty=standard}
Match $y^2+4z^2=x^2$ to its graph and surface type.

Graph choices: A. two elliptical cone nappes meeting at the origin along $x$; B. one-sheet hyperboloid about $x$ with a waist; C. saddle.

Type choices: A. ellipsoid; B. paraboloid; C. elliptic cone; D. hyperboloid (misspelled on the platform).

::::solution[Solution]
**Answer:** graph A; type C, elliptical cone.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. The rim at $x=c$ has semi-axis $|c|$ in $y$ and $|c|/2$ in $z$, so it is twice as wide in $y$ as in $z$. Picture A shows two nappes tip to tip on the $x$-axis. Picture B has a hole at the waist; that would need a constant term, as in $y^2+4z^2=x^2+1$. Picture C is a saddle.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.100 — sketch the ellipsoid $x^2+y^2+9z^2=9$]{difficulty=standard}
Choose the correct sketch of $x^2+y^2+9z^2=9$.

A. Ellipsoid: intercepts $x=\pm1$, $y=\pm3$, $z=\pm3$. B. Flattened ellipsoid: $x=\pm3$, $y=\pm3$, $z=\pm1$. C. Ellipsoid: $x=\pm3$, $y=\pm3$, $z=\pm2$.

::::solution[Solution]
**Answer:** B.

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. Divide by $9$ to get standard form:

$$
\frac{x^2}9+\frac{y^2}9+\frac{z^2}1=1
$$

3. $x^2/9+y^2/9+z^2=1$ gives semiaxes $3,3,1$, so B is flattened along $z$.

4. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.101 — graph the paraboloid $z=x^2+16y^2$]{difficulty=standard}
Which graph is $z=x^2+16y^2$?

A. Upward bowl, wider along $x$; B. upward bowl, wider along $y$; C. sideways bowl opening toward $+y$.

::::solution[Solution]
**Answer:** A.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. Both squares are added and $z$ is alone to the first power, so $z\ge0$ and the bowl opens upward. That rules out C, which opens sideways.

3. At $z=c>0$, $x^2+16y^2=c$ has semiaxes $\sqrt c$ and $\sqrt c/4$. The ellipse is wider in $x$.

4. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.102 — sketch the paraboloid $y=9-x^2-9z^2$]{difficulty=standard}
Choose the sketch of $y=9-x^2-9z^2$.

A. Vertex on $y=9$, opening toward $-y$, but intercepts $x=\pm1$, $z=\pm3$ at $y=0$. B. Same vertex and direction, with $x=\pm3$, $z=\pm1$. C. Vertex on $x=9$ instead.

::::solution[Solution]
**Answer:** B.

1. The variable to the first power is $y$, so the axis of the paraboloid is the $y$-axis. The vertex is at $(0,9,0)$, and because the coefficient of the squares is negative it opens toward $-y$. Where it crosses $y=0$: $x^2+9z^2=9$, which is $\dfrac{x^2}9+z^2=1$, so $x=\pm3$ and $z=\pm1$. Sketch B labels exactly those. Sketch A swaps the roles ($z=\pm3$, $x=1$), and sketch C puts the vertex on the wrong axis.

2. The vertex is $(0,9,0)$; at $y=0$, $x^2+9z^2=9$ gives $x=\pm3$, $z=\pm1$.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.103 — sketch the cone $4x^2+z^2=y^2$]{difficulty=standard}
Choose the cone $4x^2+z^2=y^2$. At the marked positive $y$-value the sketches show:

A. $y=2$, $z=2$, $x=5$. B. $y=4$, $z=4$, $x=3$. C. $y=2$, $z=2$, $x=1$.

::::solution[Solution]
**Answer:** C.

1. Written as $y^2=4x^2+z^2$, this is a double elliptical cone with the $y$-axis as its axis. At a height $y=c$ the cross-section is $4x^2+z^2=c^2$, which has $x=\pm\frac c2$ and $z=\pm c$. For $y=2$ that gives an $x$-semi-axis of $1$ and a $z$-semi-axis of $2$. Sketch C shows exactly $y=2$, $z=2$, $x=1$. Sketch B would need $x=2$ at $y=4$, but shows $3$. Sketch A shows $x=5$ at $y=2$.

2. At $y=2$, $4x^2+z^2=4$ gives $x=\pm1$, $z=\pm2$; only C matches.

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::


### Homework 5: continued set 5

:::::problem[Problem 3.104 — graph $x^2+y^2-z^2=49$]{difficulty=standard}
Choose the graph of $x^2+y^2-z^2=49$.

A. Single paraboloid; B. one-sheet hyperboloid along $y$; C. one-sheet hyperboloid along $z$; D. one-sheet hyperboloid along $x$.

::::solution[Solution]
**Answer:** C.

1. One negative square and a positive constant on the right: a hyperboloid of one sheet. The variable with the minus sign is $z$, so the axis of the hourglass is the $z$-axis. Slices at height $z=c$ are $x^2+y^2=49+c^2$, circles of radius at least $7$, with the smallest one, the waist of radius $7$, at $z=0$. That is picture C. Pictures B and D are hourglasses about the $y$- and $x$-axes, and A is a paraboloid.

2. At $z=c$, $x^2+y^2=49+c^2$, circles of radius $\sqrt{49+c^2}$. The smallest waist ($7$) is at $z=0$.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.105 — graph $z^2-x^2-y^2=81$]{difficulty=standard}
Choose the graph of $z^2-x^2-y^2=81$.

A. Single paraboloid; B. two-sheet hyperboloid along $y$; C. two separate sheets along $z$; D. two sheets along $x$.

::::solution[Solution]
**Answer:** C.

1. Move the $x$ and $y$ terms across: $z^2=81+x^2+y^2$. Since $x^2+y^2\ge0$, we have $z^2\ge81$, so $|z|\ge9$. The surface has two separate pieces, one with $z\ge9$ and one with $z\le-9$. That is a hyperboloid of two sheets with the $z$-axis as its axis. A slice $z=c$ with $|c|\lt9$ is empty, and that is the gap. Picture C.

2. $z^2=81+x^2+y^2\ge81$ gives $z\ge9$ or $z\le-9$, so the sheets are disconnected along $z$.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.106 — graph $z=1+y^2-x^2$]{difficulty=standard}
Choose the graph of $z=1+y^2-x^2$.

A. Connected saddle; B. one-sheet hyperboloid tube; C. disconnected two-sheet hyperboloid.

::::solution[Solution]
**Answer:** A.

1. The variable $z$ is alone to the first power, and the squares $y^2$ and $-x^2$ have opposite signs. That is a hyperbolic paraboloid, a saddle, shifted up by $1$. Slice $x=0$: $z=1+y^2$, a parabola opening up. Slice $y=0$: $z=1-x^2$, a parabola opening down. It is one connected surface passing through $(0,0,1)$. Pictures B and C are hyperboloids, which need three squared variables.

2. Traces $x=0$ and $y=0$ give $z=1+y^2$ and $z=1-x^2$: opposing curvatures identify a saddle.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::


### MWF Test 2 Review Assignment — all of Thomas ch. 12

:::::problem[Problem 3.107 — distance between two points]{difficulty=easy}
Find the distance between $P_1(2,5,3)$ and $P_2(6,-2,7)$. Give an exact answer.

::::solution[Solution]
**Answer:** $9$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. The distance formula is the Pythagorean theorem run three times: subtract matching coordinates, square each difference, add, and take the square root.

$$
d=\sqrt{(6-2)^2+(-2-5)^2+(7-3)^2}=\sqrt{16+49+16}=\sqrt{81}=9
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.108 — distance to the coordinate planes]{difficulty=easy}
Find the distance from the point $(4,-6,-1)$ to **a.** the $xy$-plane, **b.** the $yz$-plane, **c.** the $xz$-plane.

::::solution[Solution]
**Answer:** a. $1$, b. $4$, c. $6$.

1. A coordinate plane fixes one coordinate at zero. Compare the absolute values of the perpendicular coordinates rather than the full distance from the origin.

2. The $xy$-plane is $z=0$. Distance $=|-1|=1$. - The $yz$-plane is $x=0$. Distance $=|4|=4$. - The $xz$-plane is $y=0$. Distance $=|-6|=6$.

3. **Check.** The point lies on the specified coordinate plane exactly when its perpendicular coordinate is zero; plane distance is that coordinate’s absolute value.
::::
:::::

:::::problem[Problem 3.109 — sphere in standard form]{difficulty=easy}
Find the center and radius of the sphere $(x+8)^2+y^2+(z-8)^2=32$.

::::solution[Solution]
**Answer:** center $(-8,\,0,\,8)$, radius $4\sqrt2$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. $x+8=x-(-8)$, so $a=-8$. - $y^2$ is the same as $(y-0)^2$, so $b=0$. - $z-8$ gives $c=8$.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.110 — sphere, complete the square]{difficulty=standard}
Find the center and radius of the sphere $x^2+y^2+z^2-4x-5z=0$.

::::solution[Solution]
**Answer:** center $\left(2,\,0,\,\tfrac52\right)$, radius $\dfrac{\sqrt{41}}{2}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Half of $-4$ is $-2$, whose square is $4$. Half of $-5$ is $-\tfrac52$, whose square is $\tfrac{25}{4}$. Moving the two constants to the right side:

$$
x^2-4x=(x-2)^2-4,\qquad y^2 \text{ needs nothing},\qquad z^2-5z=\left(z-\tfrac52\right)^2-\tfrac{25}{4}
$$

$$
(x-2)^2+y^2+\left(z-\tfrac52\right)^2=4+\tfrac{25}{4}=\tfrac{16}{4}+\tfrac{25}{4}=\tfrac{41}{4}
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.111 — sphere with leading coefficient 3]{difficulty=challenge}
Find the center and radius of the sphere $3x^2+3y^2+3z^2+x+y+z=1$.

::::solution[Solution]
**Answer:** center $\left(-\tfrac16,\,-\tfrac16,\,-\tfrac16\right)$, radius $\dfrac{\sqrt{15}}{6}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. For each variable, half of $\tfrac13$ is $\tfrac16$, and $\left(\tfrac16\right)^2=\tfrac1{36}$. Add $\tfrac1{36}$ to the right side **three times**, once per variable, which is $\tfrac{3}{36}=\tfrac1{12}$:

$$
x^2+\tfrac13 x+y^2+\tfrac13 y+z^2+\tfrac13 z=\tfrac13
$$

$$
\left(x+\tfrac16\right)^2+\left(y+\tfrac16\right)^2+\left(z+\tfrac16\right)^2=\tfrac13+\tfrac1{12}=\tfrac{4}{12}+\tfrac{1}{12}=\tfrac{5}{12}
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.112 — sum of two vectors]{difficulty=easy}
For $\mathbf u=\langle 5,-2\rangle$ and $\mathbf v=\langle-1,-3\rangle$, find the component form and the magnitude of $\mathbf u+\mathbf v$.

::::solution[Solution]
**Answer:** $\mathbf u+\mathbf v=\langle 4,-5\rangle$, magnitude $\sqrt{41}$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. $41$ is prime, so the radical does not simplify.

$$
\langle 5+(-1),\ -2+(-3)\rangle=\langle 4,-5\rangle
$$

$$
|\mathbf u+\mathbf v|=\sqrt{4^2+(-5)^2}=\sqrt{16+25}=\sqrt{41}
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.113 — scalar multiples and a difference]{difficulty=easy}
Let $\mathbf u=\langle 1,-3\rangle$ and $\mathbf v=\langle-8,4\rangle$. Find the component form and the magnitude of $2\mathbf u-2\mathbf v$.

::::solution[Solution]
**Answer:** $\langle 18,-14\rangle$, magnitude $2\sqrt{130}$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Scale first: $2\mathbf u=\langle 2,-6\rangle$ and $2\mathbf v=\langle-16,8\rangle$. Then subtract component by component:

$$
2\mathbf u-2\mathbf v=\langle 2-(-16),\ -6-8\rangle=\langle 18,-14\rangle
$$

$$
\sqrt{18^2+14^2}=\sqrt{324+196}=\sqrt{520}=\sqrt{4\cdot 130}=2\sqrt{130}
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::


### MWF Test 2 Review Assignment: continued set 2

:::::problem[Problem 3.114 — the vector between two points]{difficulty=easy}
Express $\overrightarrow{P_1P_2}$ in the form $v_1\mathbf i+v_2\mathbf j+v_3\mathbf k$ if $P_1=(1,9,-9)$ and $P_2=(7,8,-8)$.

::::solution[Solution]
**Answer:** $(6)\mathbf i+(-1)\mathbf j+(1)\mathbf k$.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. The vector from $P_1$ to $P_2$ is the terminal point minus the initial point, coordinate by coordinate:

$$
(7-1,\ 8-9,\ -8-(-9))=(6,-1,1)
$$

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.115 — choose the vector $\overrightarrow{AB}$]{difficulty=easy}
Express $\overrightarrow{AB}$ as $v_1\mathbf i+v_2\mathbf j+v_3\mathbf k$ if $A=(-2,7,2)$ and $B=(-2,-9,-4)$. Choose the correct answer.

- A. $4\mathbf i+2\mathbf j+2\mathbf k$
- B. $-7\mathbf j+15\mathbf k$
- C. $7\mathbf j-15\mathbf k$
- D. $-16\mathbf j-6\mathbf k$
- E. $-4\mathbf i-2\mathbf j-2\mathbf k$
- F. $16\mathbf j+6\mathbf k$

::::solution[Solution]
**Answer:** D.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. The $x$-component is $0$, so there is no $\mathbf i$ term, and the vector is $-16\mathbf j-6\mathbf k$, which is D.

$$
B-A=(-2-(-2),\ -9-7,\ -4-2)=(0,\,-16,\,-6)
$$

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.116 — vectors from length and direction]{difficulty=standard}
Find the vectors whose lengths and directions are given.

- a. length $2$, direction $\mathbf k$
- b. length $\sqrt3$, direction $-\mathbf j$
- c. length $\tfrac12$, direction $\tfrac35\mathbf j+\tfrac45\mathbf k$
- d. length $7$, direction $\tfrac67\mathbf i-\tfrac27\mathbf j+\tfrac37\mathbf k$

Each answer is entered as $(\ )\mathbf i+(\ )\mathbf j+(\ )\mathbf k$; in part d the sheet already prints the minus sign before the $\mathbf j$ box.

::::solution[Solution]
**Answer:** (a) $2\mathbf k$; (b) $-\sqrt3\,\mathbf j$; (c) $\frac3{10}\mathbf j+\frac25\mathbf k$; (d) $6\mathbf i-2\mathbf j+3\mathbf k$.

1. Compute vectors component by component, preserving the coordinate order and the signs on subtraction. For a unit vector, divide each component by the original magnitude.

2. Multiply each unit direction by the given length. For (d), the $-\mathbf j$ sign is printed on the homework form, so the blank receives $2$.

$$
\tfrac12\langle0,\tfrac35,\tfrac45\rangle=\langle0,\tfrac3{10},\tfrac25\rangle,\quad 7\langle\tfrac67,-\tfrac27,\tfrac37\rangle=\langle6,-2,3\rangle.
$$

3. **Check.** Substituting the components back checks the required vector relation; a proposed unit vector must have squared components summing to one.
::::
:::::

:::::problem[Problem 3.117 — length times direction]{difficulty=standard}
Express $-9\mathbf i-2\mathbf j-6\mathbf k$ as a product of its length and direction, in the form $\text{length}\,\big[(\ )\mathbf i+(\ )\mathbf j+(\ )\mathbf k\big]$.

::::solution[Solution]
**Answer:** $11\left[\left(-\tfrac{9}{11}\right)\mathbf i+\left(-\tfrac{2}{11}\right)\mathbf j+\left(-\tfrac{6}{11}\right)\mathbf k\right]$.

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. Multiplying length by direction returns $\mathbf v$, which is the check: $11\cdot\left(-\tfrac{9}{11}\right)=-9$, and so on.

$$
|\mathbf v|=\sqrt{81+4+36}=\sqrt{121}=11
$$

$$
\frac{\mathbf v}{|\mathbf v|}=\left\langle-\tfrac{9}{11},\ -\tfrac{2}{11},\ -\tfrac{6}{11}\right\rangle
$$

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.118 — direction and midpoint]{difficulty=standard}
For $P_1(-5,2,2)$ and $P_2(2,5,0)$, find the direction of $\overrightarrow{P_1P_2}$ and the midpoint of segment $P_1P_2$.

::::solution[Solution]
**Answer:** direction $\left(\tfrac{7}{\sqrt{62}}\right)\mathbf i+\left(\tfrac{3}{\sqrt{62}}\right)\mathbf j+\left(-\tfrac{2}{\sqrt{62}}\right)\mathbf k$ (equivalently $\tfrac{7\sqrt{62}}{62},\ \tfrac{3\sqrt{62}}{62},\ -\tfrac{\sqrt{62}}{31}$); midpoint $\left(-\tfrac32,\ \tfrac72,\ 1\right)$.

1. Use the coordinate differences for the distance formula, or average corresponding endpoints for a midpoint. Keep the arithmetic exact rather than converting radicals to decimals.

2. **Direction.** The vector is $\overrightarrow{P_1P_2}=\langle 2-(-5),\ 5-2,\ 0-2\rangle=\langle 7,3,-2\rangle$. Its length is $\sqrt{49+9+4}=\sqrt{62}$. Divide each component by that length:

$$
\left\langle \tfrac{7}{\sqrt{62}},\ \tfrac{3}{\sqrt{62}},\ -\tfrac{2}{\sqrt{62}}\right\rangle
$$

$$
\left(\tfrac{-5+2}{2},\ \tfrac{2+5}{2},\ \tfrac{2+0}{2}\right)=\left(-\tfrac32,\ \tfrac72,\ 1\right)
$$

3. **Check.** Squaring the computed distance should reproduce the sum of the squared coordinate differences; for a midpoint, the two displacement vectors should match.
::::
:::::

:::::problem[Problem 3.119 — all four dot-product quantities, opposite vectors]{difficulty=standard}
For $\mathbf v=-4\mathbf i-5\mathbf j-\sqrt7\,\mathbf k$ and $\mathbf u=4\mathbf i+5\mathbf j+\sqrt7\,\mathbf k$, find:

- a. $\mathbf v\cdot\mathbf u$, $|\mathbf v|$, $|\mathbf u|$
- b. the cosine of the angle between $\mathbf v$ and $\mathbf u$
- c. the scalar component of $\mathbf u$ in the direction of $\mathbf v$
- d. the vector $\operatorname{proj}_{\mathbf v}\mathbf u$

::::solution[Solution]
**Answer:** 

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. a. $\mathbf v\cdot\mathbf u=-48$, $|\mathbf v|=4\sqrt3$, $|\mathbf u|=4\sqrt3$. b. $-1$. c. $-4\sqrt3$. d. $(4)\mathbf i+(5)\mathbf j+(\sqrt7)\mathbf k$.

$$
\frac{\mathbf u\cdot\mathbf v}{|\mathbf v|}=\frac{-48}{4\sqrt3}=-\frac{12}{\sqrt3}=-\frac{12\sqrt3}{3}=-4\sqrt3
$$

$$
\operatorname{proj}_{\mathbf v}\mathbf u=\frac{\mathbf u\cdot\mathbf v}{\mathbf v\cdot\mathbf v}\,\mathbf v=\frac{-48}{48}\,\mathbf v=-\mathbf v=4\mathbf i+5\mathbf j+\sqrt7\,\mathbf k
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### MWF Test 2 Review Assignment: continued set 3

:::::problem[Problem 3.120 — all four quantities, integer lengths]{difficulty=standard}
Find the same four things (parts a to d of Q13) for $\mathbf v=6\mathbf i+3\mathbf j-2\mathbf k$ and $\mathbf u=5\mathbf i+12\mathbf j$. Give d in terms of $\mathbf i$, $\mathbf j$, $\mathbf k$.

::::solution[Solution]
**Answer:** 

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. **a.** $\mathbf v\cdot\mathbf u=6\cdot5+3\cdot12+(-2)\cdot0=30+36+0=66$. Note $\mathbf u$ has no $\mathbf k$ term, so its $\mathbf k$-component is $0$. The lengths: $|\mathbf v|=\sqrt{36+9+4}=7$ and $|\mathbf u|=\sqrt{25+144}=13$.

$$
\frac{66}{49}\langle 6,3,-2\rangle=\left\langle \tfrac{396}{49},\ \tfrac{198}{49},\ -\tfrac{132}{49}\right\rangle
$$

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.121 — all four quantities, radicals]{difficulty=challenge}
Find the same four things for $\mathbf v=-6\mathbf i+\mathbf j$ and $\mathbf u=5\mathbf i+\sqrt{11}\,\mathbf j$. Give d as $(\ )\mathbf i+(\ )\mathbf j$.

::::solution[Solution]
**Answer:** 

1. Choose the defining equation for the requested quantity and substitute the data into it before simplifying, retaining exact fractions and radicals throughout.

2. **a.** $\mathbf v\cdot\mathbf u=(-6)(5)+(1)(\sqrt{11})=\sqrt{11}-30$. Lengths: $|\mathbf v|=\sqrt{36+1}=\sqrt{37}$, and $|\mathbf u|=\sqrt{25+11}=\sqrt{36}=6$.

$$
\frac{\sqrt{11}-30}{37}\langle-6,1\rangle=\left\langle \frac{-6\sqrt{11}+180}{37},\ \frac{\sqrt{11}-30}{37}\right\rangle
$$

3. **Check.** Substitute the final form back into the defining relation and compare it with the original data; this detects sign or arithmetic errors.
::::
:::::

:::::problem[Problem 3.122 — acute angle between two lines]{difficulty=standard}
The vector $\mathbf w=a\mathbf i+b\mathbf j$ is perpendicular to the line $ax+by=c$ and parallel to the line $bx-ay=c$. The acute angle between two intersecting lines that do not cross at right angles equals the angle determined by vectors normal to the lines (or by vectors parallel to them). Use this to find the acute angle between $\sqrt3\,x-y=4$ and $\sqrt3\,x+y=3$, in radians, using $\pi$.

::::solution[Solution]
**Answer:** $\dfrac{\pi}{3}$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The line $ax+by=c$ has normal vector $\langle a,b\rangle$, read straight from the coefficients. So:

$$
\mathbf n_1=\langle \sqrt3,-1\rangle,\qquad \mathbf n_2=\langle \sqrt3,1\rangle
$$

$$
\cos\theta=\frac{\mathbf n_1\cdot\mathbf n_2}{|\mathbf n_1||\mathbf n_2|}=\frac{3-1}{2\cdot 2}=\frac12 \quad\Longrightarrow\quad \theta=\frac{\pi}{3}
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.123 — cross product of parallel vectors]{difficulty=standard}
Find the length and direction (when defined) of $\mathbf u\times\mathbf v$ and of $\mathbf v\times\mathbf u$, for $\mathbf u=-12\mathbf i+6\mathbf j-9\mathbf k$ and $\mathbf v=-4\mathbf i+2\mathbf j-3\mathbf k$. For each, either give the direction as $(\ )\mathbf i+(\ )\mathbf j+(\ )\mathbf k$ or state that the direction is not defined.

::::solution[Solution]
**Answer:** 

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Look at the vectors before computing. Each component of $\mathbf u$ is $3$ times the matching component of $\mathbf v$: $-12=3(-4)$, $6=3(2)$, $-9=3(-3)$. So $\mathbf u=3\mathbf v$, the two vectors are parallel, and the cross product of parallel vectors is the zero vector.

$$
\mathbf u\times\mathbf v=\mathbf i\big(6(-3)-(-9)(2)\big)-\mathbf j\big((-12)(-3)-(-9)(-4)\big)+\mathbf k\big((-12)(2)-6(-4)\big)
$$

$$
=\mathbf i(-18+18)-\mathbf j(36-36)+\mathbf k(-24+24)=\mathbf 0
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.124 — cross product, length and direction]{difficulty=standard}
Find the length and direction (when defined) of $\mathbf u\times\mathbf v$ and $\mathbf v\times\mathbf u$ for $\mathbf u=-2\mathbf i-2\mathbf j-4\mathbf k$ and $\mathbf v=4\mathbf i+4\mathbf j+3\mathbf k$. Give each direction as $(\ )\mathbf i+(\ )\mathbf j+(\ )\mathbf k$ or say it is undefined.

::::solution[Solution]
**Answer:** 

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. $\mathbf i$: $(-2)(3)-(-4)(4)=-6+16=10$. - $\mathbf j$: $u_3v_1-u_1v_3=(-4)(4)-(-2)(3)=-16+6=-10$. - $\mathbf k$: $(-2)(4)-(-2)(4)=-8+8=0$.

$$
\mathbf u\times\mathbf v=\big\langle u_2v_3-u_3v_2,\ u_3v_1-u_1v_3,\ u_1v_2-u_2v_1\big\rangle
$$

3. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::

:::::problem[Problem 3.125 — triangle area and a unit normal]{difficulty=challenge}
For $P(1,-1,2)$, $Q(2,0,-1)$, $R(0,2,1)$: **a.** find the area of triangle $PQR$. **b.** Which of the following is a unit vector perpendicular to plane $PQR$?

- A. $\tfrac{1}{\sqrt2}(\mathbf i+\mathbf j)$
- B. $\tfrac{1}{\sqrt6}(\mathbf i+2\mathbf j+\mathbf k)$
- C. $\tfrac{1}{3\sqrt{19}}(7\mathbf i+11\mathbf j+\mathbf k)$
- D. $\tfrac{1}{\sqrt6}(2\mathbf i+\mathbf j+\mathbf k)$

::::solution[Solution]
**Answer:** a. $2\sqrt6$; b. D.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Two edge vectors from $P$: $\overrightarrow{PQ}=\langle 1,1,-3\rangle$ and $\overrightarrow{PR}=\langle-1,3,-1\rangle$. Their cross product is perpendicular to the plane:

$$
\overrightarrow{PQ}\times\overrightarrow{PR}=\big\langle (1)(-1)-(-3)(3),\ (-3)(-1)-(1)(-1),\ (1)(3)-(1)(-1)\big\rangle=\langle 8,4,4\rangle
$$

$$
\tfrac12\sqrt{64+16+16}=\tfrac12\sqrt{96}=\tfrac12\cdot 4\sqrt6=2\sqrt6
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::


### MWF Test 2 Review Assignment: continued set 4

:::::problem[Problem 3.126 — parallelogram area in the plane]{difficulty=standard}
Find the area of the parallelogram with vertices $A(-1,3)$, $B(1,0)$, $C(9,1)$, $D(7,4)$.

::::solution[Solution]
**Answer:** $26$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Take two edges from $A$: $\overrightarrow{AB}=\langle 2,-3\rangle$ and $\overrightarrow{AD}=\langle 8,1\rangle$. (As a sanity check, $\overrightarrow{DC}=\langle 2,-3\rangle$, equal to $\overrightarrow{AB}$, which is what makes it a parallelogram.)

$$
\text{Area}=\left|\det\begin{pmatrix} 2 &-3\\ 8 & 1\end{pmatrix}\right|=|2\cdot 1-(-3)(8)|=|2+24|=26
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.127 — parallelogram area in space]{difficulty=standard}
Find the area of the parallelogram with vertices $A(0,0,0)$, $B(5,2,4)$, $C(8,1,4)$, $D(3,-1,0)$.

::::solution[Solution]
**Answer:** $\sqrt{281}$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The edges from $A$ are $\overrightarrow{AB}=\langle 5,2,4\rangle$ and $\overrightarrow{AD}=\langle 3,-1,0\rangle$. Check that the fourth vertex lands correctly: $\overrightarrow{AB}+\overrightarrow{AD}=\langle 8,1,4\rangle$, which is $C$.

$$
\overrightarrow{AB}\times\overrightarrow{AD}=\big\langle 2\cdot 0-4(-1),\ 4\cdot 3-5\cdot 0,\ 5(-1)-2\cdot 3\big\rangle=\langle 4,12,-11\rangle
$$

$$
\sqrt{16+144+121}=\sqrt{281}
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.128 — volume of a box from three vectors]{difficulty=standard}
Find the volume of the parallelepiped determined by $\mathbf u=2\mathbf i+\mathbf j$, $\mathbf v=2\mathbf i-3\mathbf j+4\mathbf k$, $\mathbf w=4\mathbf i+\mathbf k$.

::::solution[Solution]
**Answer:** $8$ cubic units.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. So $V=|8|=8$. This is the same as the absolute value of the $3\times3$ determinant whose rows are $\mathbf u$, $\mathbf v$, $\mathbf w$.

$$
\mathbf v\times\mathbf w=\big\langle (-3)(1)-4\cdot 0,\ 4\cdot 4-2\cdot 1,\ 2\cdot 0-(-3)(4)\big\rangle=\langle-3,14,12\rangle
$$

$$
\mathbf u\cdot\langle-3,14,12\rangle=-6+14+0=8
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.129 — parametric line through a point, parallel to a vector]{difficulty=easy}
Find parametric equations for the line through $P(-5,-7,1)$ parallel to $8\mathbf i+\mathbf j+9\mathbf k$.

- A. $x=8-5t,\ y=-7+t,\ z=1+9t$
- B. $x=8-5t,\ y=1-7t,\ z=9+t$
- C. $x=-5+8t,\ y=1-7t,\ z=9+t$
- D. $x=-5+8t,\ y=-7+t,\ z=1+9t$

::::solution[Solution]
**Answer:** D.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The line is $(x,y,z)=P+t\,\mathbf v$. Coordinates of the point go in the constant slot; components of the direction vector are the coefficients of $t$:

$$
x=-5+8t,\qquad y=-7+1\cdot t,\qquad z=1+9t
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.130 — a line through a point with a zero coordinate]{difficulty=easy}
Find parametric equations for the line through $P(-2,0,-10)$ parallel to $9\mathbf i+3\mathbf j-5\mathbf k$.

- A. $x=-2+9t,\ y=3t,\ z=-10-5t$
- B. $x=9-2t,\ y=3+t,\ z=-5-10t$
- C. $x=-2+9t,\ y=3+t,\ z=-5-10t$
- D. $x=9-2t,\ y=3t,\ z=-10-5t$

::::solution[Solution]
**Answer:** A.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Point as constants, direction as coefficients: $x=-2+9t$, $y=0+3t=3t$, $z=-10-5t$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.131 — line perpendicular to a plane]{difficulty=standard}
Find parametric equations for the line through $(-6,0,9)$ perpendicular to the plane $2x+3y-8z=13$.

- A. $x=2-6t,\ y=3,\ z=-8+9t$
- B. $x=-6+2t,\ y=3t,\ z=9-8t$
- C. $x=2-6t,\ y=3t,\ z=-8+9t$
- D. $x=-6+2t,\ y=3,\ z=-8+9t$

::::solution[Solution]
**Answer:** B.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. A line perpendicular to a plane runs in the same direction as the plane's normal vector. The normal is read straight off the coefficients: $\mathbf n=\langle 2,3,-8\rangle$. Use it as the direction, and use the given point as the base:

$$
x=-6+2t,\qquad y=0+3t,\qquad z=9-8t
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::


### MWF Test 2 Review Assignment: continued set 5

:::::problem[Problem 3.132 — intersection point of two lines]{difficulty=standard}
Find the point where the lines $x=3t+1,\ y=3t-2,\ z=5t+1$ and $x=s+5,\ y=2s+3,\ z=-3s+3$ intersect.

::::solution[Solution]
**Answer:** $(4,\,1,\,6)$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. From $x$: $3t+1=s+5$, so $s=3t-4$. - From $y$: $3t-2=2s+3$. Substitute $s=3t-4$: $3t-2=6t-8+3=6t-5$, so $3=3t$ and $t=1$. Then $s=3(1)-4=-1$.

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.133 — distance from a point to a line (with a printing quirk)]{difficulty=challenge}
Find the distance from the point $(0,0,4)$ to the line $x=-2t,\ y=2t,\ z=t$. The problem asks you to (1) pick the cross product used, (2) give its magnitude, and (3) give the distance. The four printed options for (1), in order, are:

- 1. $\langle-2,2,1\rangle\times\langle 0,0,4\rangle=\langle-8,-8,0\rangle$
- 2. $\langle-2,2,1\rangle\times\langle 0,0,4\rangle=\langle-8,-8,0\rangle$
- 3. $\langle 0,0,4\rangle\times\langle-2,2,1\rangle=\langle-8,-8,0\rangle$
- 4. $\langle 0,0,4\rangle\times\langle-2,2,1\rangle=\langle-8,-8,0\rangle$

::::solution[Solution]
**Answer:** the cross product is $\langle 0,0,4\rangle\times\langle-2,2,1\rangle=\langle-8,-8,0\rangle$ (option 3, which prints identically as option 4); its magnitude is $8\sqrt2$; the distance is $\dfrac{8\sqrt2}{3}$.

1. For a point-to-line distance, locate a point on the line and use its direction vector. The cross-product magnitude divided by direction length gives the perpendicular distance.

2. Magnitude: $\sqrt{64+64}=\sqrt{128}=8\sqrt2$. Direction length: $|\mathbf v|=\sqrt{4+4+1}=3$. So $d=\dfrac{8\sqrt2}{3}$.

$$
\langle 0,0,4\rangle\times\langle-2,2,1\rangle=\big\langle 0\cdot 1-4\cdot 2,\ 4(-2)-0\cdot 1,\ 0\cdot 2-0\cdot(-2)\big\rangle=\langle-8,-8,0\rangle
$$

3. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

:::::problem[Problem 3.134 — distance from a point to a line]{difficulty=challenge}
Find the distance from the point $(5,-6,3)$ to the line $x=2-t,\ y=3-4t,\ z=-2+3t$.

::::solution[Solution]
**Answer:** $\dfrac{7\sqrt{91}}{13}$

1. For a point-to-line distance, locate a point on the line and use its direction vector. The cross-product magnitude divided by direction length gives the perpendicular distance.

2. Read a point $Q$ and direction $\mathbf v$ from the line: at $t=0$, $Q=(2,3,-2)$; the coefficients of $t$ give $\mathbf v=\langle-1,-4,3\rangle$, with $|\mathbf v|=\sqrt{1+16+9}=\sqrt{26}$. From $Q$ to the given point $P=(5,-6,3)$:

$$
\overrightarrow{QP}=\langle 3,-9,5\rangle
$$

$$
\overrightarrow{QP}\times\mathbf v=\big\langle (-9)(3)-5(-4),\ 5(-1)-3(3),\ 3(-4)-(-9)(-1)\big\rangle=\langle-7,-14,-21\rangle
$$

$$
d=\frac{7\sqrt{14}}{\sqrt{26}}=7\sqrt{\frac{14}{26}}=7\sqrt{\frac{7}{13}}=\frac{7\sqrt{7}}{\sqrt{13}}=\frac{7\sqrt{91}}{13}
$$

3. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

:::::problem[Problem 3.135 — plane from a point and a normal]{difficulty=standard}
Find the equation of the plane through $P_0=(0,5,-1)$ with normal vector $\mathbf n=2\mathbf i-3\mathbf j-\mathbf k$.

- A. $(x+2)+5(y-3)-1(z-1)=-14$
- B. $2x-3(y+5)-(z-1)=0$
- C. $2x-3y-z=-14$
- D. $2x-3y-z=0$

::::solution[Solution]
**Answer:** C.

1. Use the cross product when an area or a normal vector is required; expand the determinant with the negative sign on the middle component. Use a dot product with a third edge for volume.

2. The plane is all points $X=(x,y,z)$ with $\mathbf n\cdot(X-P_0)=0$:

$$
2(x-0)-3(y-5)-1(z-(-1))=0
$$

$$
2x-3y-z=-14
$$

3. **Check.** The cross product must be orthogonal to both input vectors; a magnitude or absolute triple product must be nonnegative.
::::
:::::

:::::problem[Problem 3.136 — plane through three points]{difficulty=challenge}
Find the equation of the plane through $P_0(-1,5,3)$, $Q_0(0,-5,-1)$, $R_0(1,-2,3)$.

- A. $-28x+13y-8z=27$
- B. $-28x-8y+13z=27$
- C. $-(x)+3(-5+y)+5(-1+z)=0$
- D. $-(x)+5(-5+y)+3(-1+z)=0$

::::solution[Solution]
**Answer:** B.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. So the plane is $-28x-8y+13z=d$. Find $d$ from $P_0$: $-28(-1)-8(5)+13(3)=28-40+39=27$.

$$
\overrightarrow{P_0Q_0}=\langle 1,-10,-4\rangle,\qquad \overrightarrow{P_0R_0}=\langle 2,-7,0\rangle
$$

$$
\big\langle (-10)(0)-(-4)(-7),\ (-4)(2)-(1)(0),\ (1)(-7)-(-10)(2)\big\rangle=\langle-28,-8,13\rangle
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.137 — plane containing two lines (starred)]{difficulty=challenge}
Find an equation of the plane containing the lines $x=4+t,\ y=5-5t,\ z=1$ and $x=3s,\ y=10s,\ z=6-5s$, if possible. Choose: A. an equation for the plane is ___, or B. the plane does not exist.

::::solution[Solution]
**Answer:** A, and the plane is $5x+y+5z=30$

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. The third equation gives $s=1$. The first then gives $4+t=3$, so $t=-1$. Check the second: $5-5(-1)=10$ and $10(1)=10$ ✓. All three hold, so the lines **intersect**, at $(3,10,1)$. That means the plane exists.

$$
4+t=3s,\qquad 5-5t=10s,\qquad 1=6-5s
$$

$$
\mathbf n=\mathbf d_1\times\mathbf d_2=\big\langle (-5)(-5)-0\cdot 10,\ 0\cdot 3-1\cdot(-5),\ 1\cdot 10-(-5)(3)\big\rangle=\langle 25,5,25\rangle
$$

$$
5(x-3)+(y-10)+5(z-1)=0 \quad\Longrightarrow\quad 5x+y+5z=30
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::


### MWF Test 2 Review Assignment: continued set 6

:::::problem[Problem 3.138 — where a line meets a plane]{difficulty=easy}
Find the point at which the line $x=-2+6t,\ y=-3+4t,\ z=2t$ meets the plane $x+y+z=-5$.

::::solution[Solution]
**Answer:** $(-2,\,-3,\,0)$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Put $t=0$ back into the line: $(-2,-3,0)$.

$$
(-2+6t)+(-3+4t)+2t=-5 \quad\Longrightarrow\quad-5+12t=-5 \quad\Longrightarrow\quad t=0
$$

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.139 — distance from a point to a plane]{difficulty=standard}
Find the distance from $(4,-4,-3)$ to the plane $x-2y+4z=2$.

::::solution[Solution]
**Answer:** $\dfrac{2}{\sqrt{21}}=\dfrac{2\sqrt{21}}{21}$.

1. For a point-to-plane distance, evaluate the plane equation at the point and divide the absolute value by the length of the plane normal.

2. Here $a=1$, $b=-2$, $c=4$, $d=2$:

$$
\frac{|ax_0+by_0+cz_0-d|}{\sqrt{a^2+b^2+c^2}}
$$

$$
\frac{|4-2(-4)+4(-3)-2|}{\sqrt{1+4+16}}=\frac{|4+8-12-2|}{\sqrt{21}}=\frac{|-2|}{\sqrt{21}}=\frac{2}{\sqrt{21}}
$$

3. **Check.** A distance must be nonnegative; taking the absolute value removes any dependence on which side of the plane contains the point.
::::
:::::

:::::problem[Problem 3.140 — distance from a point to a plane, clean denominator]{difficulty=easy}
Find the distance from $(0,0,7)$ to the plane $3x+2y+6z=9$.

::::solution[Solution]
**Answer:** $\dfrac{33}{7}$.

1. For a point-to-plane distance, evaluate the plane equation at the point and divide the absolute value by the length of the plane normal.

2. Same formula as Q33:

$$
\frac{|3(0)+2(0)+6(7)-9|}{\sqrt{9+4+36}}=\frac{|42-9|}{\sqrt{49}}=\frac{33}{7}
$$

3. **Check.** A distance must be nonnegative; taking the absolute value removes any dependence on which side of the plane contains the point.
::::
:::::

:::::problem[Problem 3.141 — the graph of a cylinder]{difficulty=easy}
Determine the graph of the cylinder $x^2+y^2=25$. Choose the correct graph.

- A. A circular cylinder lying along a nearly horizontal axis, the $y$-direction.
- B. A vertical circular cylinder standing along the $z$-axis, with the axes through its middle.
- C. A circular cylinder along the $x$-direction.

::::solution[Solution]
**Answer:** B.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. The equation has no $z$ in it, so $z$ is completely free. At every height the cross-section is the same circle $x^2+y^2=25$, of radius $5$. Stack those circles over all $z$ and you get a cylinder whose rulings (its straight lines) are parallel to the $z$-axis: it stands vertically.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.142 — the graph of an ellipsoid]{difficulty=standard}
Determine the graph of $49x^2+25y^2+z^2=1225$. Choose the correct graph.

- A. A tall thin ellipsoid elongated along the $z$-axis, narrow in $x$ and $y$.
- B. A sphere.
- C. A double cone or hourglass shape along the $z$-axis, two nappes meeting at the origin.

::::solution[Solution]
**Answer:** A.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. To read a quadric, put it in standard form, with $1$ on the right. Divide everything by $1225$:

$$
\frac{x^2}{25}+\frac{y^2}{49}+\frac{z^2}{1225}=1
$$

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.143 — the graph of an elliptic paraboloid]{difficulty=standard}
Determine the graph of the paraboloid $z=x^2+81y^2$. Choose the correct graph.

- A. A paraboloid opening toward the $+y$ side, its axis roughly along $y$.
- B. A paraboloid opening upward, narrow, its elliptical rim stretched along the $x$-direction and compressed in $y$.
- C. A paraboloid opening upward, its rim stretched wide along the $y$-direction.

::::solution[Solution]
**Answer:** B.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. This ellipse has $x$-semi-axis $\sqrt c$ and $y$-semi-axis $\dfrac{\sqrt c}{9}$. So it is nine times longer in $x$ than in $y$: long along the $x$-direction and thin along $y$. That is B. C is the reverse (wide in $y$), which would be the graph of $z=81x^2+y^2$.

$$
x^2+81y^2=c
$$

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::


### MWF Test 2 Review Assignment: continued set 7

:::::problem[Problem 3.144 — the graph of a cone]{difficulty=standard}
Determine the graph of the cone $x^2+y^2=16z^2$. Choose the correct graph.

- A. A double circular cone with vertical axis ($z$), two nappes meeting at the origin.
- B. An upward-opening paraboloid, vertex at the origin.
- C. A double cone lying on its side, axis along $y$.
- D. A double cone with axis along the $x$-direction.

::::solution[Solution]
**Answer:** A.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. The axis is the variable that appears *alone* on the other side, $z$. B is wrong because a paraboloid has $z$ to the first power. C and D put the axis along $y$ or $x$, which would need the squared variable to be $y$ or $x$ on the isolated side.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.145 — the graph of a hyperboloid of one sheet]{difficulty=standard}
Determine the graph of the hyperboloid $x^2+y^2-z^2=64$. Choose the correct graph.

- A. A one-sheet hourglass lying along the $y$-direction.
- B. A one-sheet hyperboloid with axis tilted along the $x$-direction.
- C. An upward-opening paraboloid (single bowl).
- D. A one-sheet hyperboloid with vertical axis (the $z$-axis through the middle, circular waist at the origin, flaring at top and bottom).

::::solution[Solution]
**Answer:** D.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. A and B are one-sheet hyperboloids about *other* axes. They would come from an equation such as $x^2-y^2+z^2=64$ (axis $y$) or $-x^2+y^2+z^2=64$ (axis $x$). C is a paraboloid.

3. $x^2+y^2=64+z^2$ has its smallest circular waist at $z=0$, with radius $8$.

4. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

:::::problem[Problem 3.146 — the graph of a hyperboloid of two sheets]{difficulty=standard}
Determine the graph of $z^2-x^2-y^2=100$. Choose the correct graph.

- A. Two separate bowl-shaped sheets, one above and one below the $xy$-plane, opening away from each other along the $z$-axis.
- B. A single upward-opening paraboloid.
- C. Two separate sheets separated along the $y$-direction (left and right of the origin).
- D. Two separate sheets along the $x$-direction.

::::solution[Solution]
**Answer:** A.

1. Classify the surface by its squared terms, signs, and any missing or unsquared variable. A coordinate trace fixes one variable and reveals the cross-section.

2. One positive square, two negative squares, positive constant: a hyperboloid of **two sheets**, opening along the axis of the *positive* term, $z$.

3. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

### Released Test 2 — Version A (Young, Fall 2026)

The following six questions reproduce Version A. For full credit, show the algebra or cross-product setup and box the exact result; for the four sketches in Q6, label the axis, vertices, and a representative trace.

:::::problem[Problem 3.147 — sphere by completing squares]{difficulty=standard}
Put $x^2-6x+y^2+4y+z^2-2z=11$ in standard sphere form; find its center and radius. (15 points)

::::solution[Solution]
**Answer:** $(x-3)^2+(y+2)^2+(z-1)^2=25$; center $(3,-2,1)$; radius $5$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Half the linear coefficients $-6,4,-2$ and square: $9,4,1$. Add these to both sides:

$$
(x^2-6x+9)+(y^2+4y+4)+(z^2-2z+1)=11+9+4+1=25.
$$
Thus $r^2=25$, so $r=5$.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.148 — exact dot product, angle, component, projection]{difficulty=challenge}
Let $\mathbf u=\langle7,-3,2\rangle$ and $\mathbf v=\langle8,2,-4\rangle$. Find (a) the exact angle between them, (b) the scalar component of $\mathbf u$ in the direction of $\mathbf v$, and (c) $\operatorname{proj}_{\mathbf v}\mathbf u$. No decimals. (15 points)

::::solution[Solution]
**Answer:** (a) $\cos^{-1}\!\left(\frac{42}{\sqrt{62}\sqrt{84}}\right)$; (b) $\frac{42}{\sqrt{84}}$; (c) $\langle4,1,-2\rangle$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Apply the calculation in the displayed expression.

$$
\mathbf u\cdot\mathbf v=7(8)+(-3)(2)+2(-4)=42,\qquad |\mathbf u|=\sqrt{49+9+4}=\sqrt{62},\quad |\mathbf v|=\sqrt{64+4+16}=\sqrt{84}.
$$

$$
\theta=\cos^{-1}\!\frac{\mathbf u\cdot\mathbf v}{|\mathbf u||\mathbf v|};\quad
\operatorname{comp}_{\mathbf v}\mathbf u=\frac{42}{\sqrt{84}};\quad
\operatorname{proj}_{\mathbf v}\mathbf u=\frac{42}{84}\langle8,2,-4\rangle=\langle4,1,-2\rangle.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.149 — parallelogram area]{difficulty=standard}
Find the area of the parallelogram with $A(1,2,3)$, $B(1,3,6)$, $C(3,8,6)$, and $D(3,7,3)$. (15 points)

::::solution[Solution]
**Answer:** $\sqrt{265}$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Use adjacent sides from the same vertex:

$$
\overrightarrow{AB}=\langle0,1,3\rangle,\quad\overrightarrow{AD}=\langle2,5,0\rangle,
$$
$$
\overrightarrow{AB}\times\overrightarrow{AD}=\langle1(0)-3(5),\,3(2)-0(0),\,0(5)-1(2)\rangle=\langle-15,6,-2\rangle.
$$
$$
A=|\overrightarrow{AB}\times\overrightarrow{AD}|=\sqrt{225+36+4}=\sqrt{265}.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.150 — vector and parametric line]{difficulty=standard}
Find the vector equation and parametric equations of the line through $(10,3,1)$ and $(5,6,-3)$. (15 points)

::::solution[Solution]
**Answer:** $\mathbf r(t)=\langle10,3,1\rangle+t\langle-5,3,-4\rangle$; $x=10-5t$, $y=3+3t$, $z=1-4t$.

1. Read the base point and direction from the parametric equations, or use the plane normal to form a point-normal equation. Match coordinates when solving for an intersection.

2. Set up the required expression.

$$
\mathbf v=\langle5-10,6-3,-3-1\rangle=\langle-5,3,-4\rangle.
$$
Insert the starting point and direction into $\mathbf r(t)=\mathbf r_0+t\mathbf v$, then read off components.

3. **Check.** Substitution of a known point must satisfy the resulting line or plane; an intersection must satisfy both original equations.
::::
:::::

:::::problem[Problem 3.151 — plane through point containing a line]{difficulty=challenge}
Find the component equation of the plane through $(6,0,-2)$ containing $x=4-2t$, $y=3+5t$, $z=2-t$. (20 points)

::::solution[Solution]
**Answer:** $23x+10y+4z=130$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. The line direction is $\mathbf v_1=\langle-2,5,-1\rangle$. At $t=0$ its point is $(4,3,2)$, so a second in-plane direction from $(6,0,-2)$ is $\mathbf v_2=\langle-2,3,4\rangle$.

$$
\mathbf n=\mathbf v_1\times\mathbf v_2=\langle5(4)-(-1)(3),\,(-1)(-2)-(-2)(4),\,(-2)(3)-5(-2)\rangle=\langle23,10,4\rangle.
$$
$$
23(x-6)+10(y-0)+4(z+2)=0\quad\Longrightarrow\quad23x+10y+4z=130.
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.152 — four quadric sketches]{difficulty=standard}
Identify and sketch (a) $-x^2+4y^2+z^2=1$, (b) $7z^2+5x^2=y^2$, (c) $x^2+6y^2=2$, and (d) $z=2x^2+6y^2$. (5 points per sketch)

::::solution[Solution]
**Answer:** (a) hyperboloid of one sheet, axis $x$; (b) elliptic cone, axis $y$; (c) elliptic cylinder, axis $z$; (d) elliptic paraboloid, opening toward $+z$.

1. **(a)** $4y^2+z^2=1+x^2$: at $x=0$ an ellipse $4y^2+z^2=1$; larger elliptical traces for $|x|>0$. Sketch one connected sheet with a waist.

2. **(b)** $y=\pm\sqrt{5x^2+7z^2}$: two cones meeting at the origin, opening toward $\pm y$.

3. **(c)** $x^2/2+3y^2=1$, independent of $z$: extrude the ellipse along the $z$-axis.

4. **(d)** $z\ge0$ and $z=c$ gives $2x^2+6y^2=c$: a bowl with vertex at the origin.

5. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::

### Released Test 2 — Version B (Young, Fall 2026)

:::::problem[Problem 3.153 — sphere by completing squares]{difficulty=standard}
Put $x^2-8x+y^2-6y+z^2+10z=11$ in standard sphere form; find center and radius. (15 points)

::::solution[Solution]
**Answer:** $(x-4)^2+(y-3)^2+(z+5)^2=61$; center $(4,3,-5)$; radius $\sqrt{61}$.

1. Use the standard sphere equation, with every center coordinate subtracted inside its own square and with the square of the radius on the right.

2. Half the linear coefficients $-8,-6,10$ and square: $16,9,25$.

$$
(x^2-8x+16)+(y^2-6y+9)+(z^2+10z+25)=11+16+9+25=61.
$$
Read off the center and $r=\sqrt{61}$.

3. **Check.** Reading the center back from the signs and taking the positive square root on the right checks the center and radius.
::::
:::::

:::::problem[Problem 3.154 — exact dot product, angle, component, projection]{difficulty=challenge}
Let $\mathbf u=\langle-6,9,11\rangle$ and $\mathbf v=\langle3,-7,5\rangle$. Find (a) exact angle, (b) scalar component of $\mathbf u$ along $\mathbf v$, and (c) $\operatorname{proj}_{\mathbf v}\mathbf u$. No decimals. (15 points)

::::solution[Solution]
**Answer:** (a) $\cos^{-1}\!\left(\frac{-26}{\sqrt{238}\sqrt{83}}\right)$; (b) $-\frac{26}{\sqrt{83}}$; (c) $\frac{-26}{83}\langle3,-7,5\rangle$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Set up the required expression.

$$
\mathbf u\cdot\mathbf v=(-6)(3)+9(-7)+11(5)=-18-63+55=-26.
$$
$$
|\mathbf u|=\sqrt{36+81+121}=\sqrt{238},\quad |\mathbf v|=\sqrt{9+49+25}=\sqrt{83}.
$$
Use $\theta=\cos^{-1}((\mathbf u\cdot\mathbf v)/(|\mathbf u||\mathbf v|))$, scalar component $(\mathbf u\cdot\mathbf v)/|\mathbf v|$, and projection $((\mathbf u\cdot\mathbf v)/|\mathbf v|^2)\mathbf v$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.155 — triangle area]{difficulty=standard}
Find the exact area of triangle $PQR$, where $P(4,-2,3)$, $Q(8,7,-2)$, and $R(5,9,1)$. (15 points)

::::solution[Solution]
**Answer:** $\dfrac{\sqrt{2603}}2$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. Apply the calculation in the displayed expression.

$$
\overrightarrow{PQ}=\langle4,9,-5\rangle,\qquad\overrightarrow{PR}=\langle1,11,-2\rangle.
$$
$$
\overrightarrow{PQ}\times\overrightarrow{PR}=\langle9(-2)-(-5)(11),\,(-5)(1)-4(-2),\,4(11)-9(1)\rangle=\langle37,3,35\rangle.
$$
$$
A=\tfrac12\sqrt{37^2+3^2+35^2}=\tfrac12\sqrt{1369+9+1225}=\tfrac{\sqrt{2603}}2.
$$

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.156 — vector and parametric line]{difficulty=standard}
Find the vector equation and parametric equations of the line through $(2,-7,3)$ parallel to $x=-4+2t$, $y=5-7t$, $z=8+9t$. (15 points)

::::solution[Solution]
**Answer:** $\mathbf r(t)=\langle2,-7,3\rangle+t\langle2,-7,9\rangle$; $x=2+2t$, $y=-7-7t$, $z=3+9t$.

1. For nonzero vectors, compute the dot product component by component. The angle formula divides this scalar by the product of the two magnitudes.

2. The original line has direction $\mathbf v=\langle2,-7,9\rangle$. Use this same direction and the required point $(2,-7,3)$ in $\mathbf r(t)=\mathbf r_0+t\mathbf v$.

3. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

:::::problem[Problem 3.157 — plane through three points]{difficulty=challenge}
Find the component equation of the plane through $A(3,-1,2)$, $B(8,2,4)$, $C(-1,-2,-3)$. (20 points)

::::solution[Solution]
**Answer:** $-13x+17y+7z+42=0$.

1. A scalar projection divides the dot product by the direction vector’s magnitude. A vector projection instead divides by its squared magnitude and multiplies by that vector.

2. Apply the calculation in the displayed expression.

$$
\overrightarrow{AB}=\langle5,3,2\rangle,\qquad\overrightarrow{AC}=\langle-4,-1,-5\rangle.
$$
$$
\mathbf n=\overrightarrow{AB}\times\overrightarrow{AC}=\langle3(-5)-2(-1),\,2(-4)-5(-5),\,5(-1)-3(-4)\rangle=\langle-13,17,7\rangle.
$$
$$
-13(x-3)+17(y+1)+7(z-2)=0\quad\Longrightarrow\quad-13x+17y+7z+42=0.
$$

3. **Check.** The projected vector must be parallel to its target direction; its dot product with that direction recovers the original component along it.
::::
:::::

:::::problem[Problem 3.158 — four quadric sketches]{difficulty=standard}
Identify and sketch (a) $7x^2+8y^2=z^2$, (b) $4z^2+4y^2=15$, (c) $x=4z^2+y^2$, and (d) $-4x^2+3y^2-6z^2=9$. (5 points per sketch)

::::solution[Solution]
**Answer:** (a) elliptic cone, axis $z$; (b) circular cylinder, axis $x$; (c) elliptic paraboloid, opening toward $+x$; (d) hyperboloid of two sheets, axis $y$.

1. **(a)** $z=\pm\sqrt{7x^2+8y^2}$: two nappes meeting at the origin, extending both directions along $z$.

2. **(b)** $y^2+z^2=15/4$, independent of $x$: circular cross section of radius $\sqrt{15}/2$.

3. **(c)** $x\ge0$ and $x=c$ gives $y^2+4z^2=c$: vertex at the origin, bowl opening along $+x$.

4. **(d)** $y^2/3-4x^2/9-2z^2/3=1$: no points when $|y|<\sqrt3$; vertices $(0,\pm\sqrt3,0)$, with two separated sheets along $y$.

5. **Check.** The stated family should have the same axis and cross-sections as the given equation, including any restriction on allowable coordinate values.
::::
:::::


## Chapter Summary

:::callout-key
If you remember nothing else from this chapter, remember this:

- $\vec{a}\cdot\vec{b}=\left|\vec{a}\right|\left|\vec{b}\right|\cos\theta$ — tells you angles and orthogonality.
- $\left|\vec{a}\times\vec{b}\right|=\left|\vec{a}\right|\left|\vec{b}\right|\sin\theta$ — gives perpendicular vectors and areas.
- Plane: one normal vector + one point. Line: one direction vector + one point.
- Identify quadric surfaces by counting signs on squared terms.
:::

| Formula / Concept | Expression | Notes |
| --- | --- | --- |
| Distance in 3D | $d=\sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}$ | Pythagorean theorem extended |
| Sphere (standard form) | $(x-h)^2+(y-k)^2+(z-\ell)^2=r^2$ | Complete the square in each variable: $x^2+bx=(x+b/2)^2-(b/2)^2$ |
| Vector from $A$ to $B$ | $\overrightarrow{AB}=\vec{B}-\vec{A}=\langle b_1-a_1,b_2-a_2,b_3-a_3\rangle$ | Terminal point minus initial point |
| Vector magnitude | $\left|\vec{v}\right|=\sqrt{v_1^2+v_2^2+v_3^2}$ | $\left|\vec{v}\right|^2=\vec{v}\cdot\vec{v}$ |
| Unit vector in the direction of $\vec{v}$ | $\dfrac{\vec{v}}{\left|\vec{v}\right|}$ | Requires $\vec{v}\ne\vec{0}$ |
| Midpoint | $M=\left(\dfrac{x_1+x_2}{2},\dfrac{y_1+y_2}{2},\dfrac{z_1+z_2}{2}\right)$ | Average corresponding coordinates |
| Dot product | $\vec{u}\cdot\vec{v}=u_1v_1+u_2v_2+u_3v_3=\left|\vec{u}\right|\left|\vec{v}\right|\cos\theta$ | Scalar result |
| Angle between vectors | $\theta=\arccos\!\left(\dfrac{\vec{u}\cdot\vec{v}}{\left|\vec{u}\right|\left|\vec{v}\right|}\right)$ | Exact form; $0\le\theta\le\pi$ |
| Orthogonal vectors | $\vec{u}\perp\vec{v}\iff\vec{u}\cdot\vec{v}=0$ | For nonzero vectors |
| Scalar component | $\operatorname{comp}_{\vec{v}}\vec{u}=\dfrac{\vec{u}\cdot\vec{v}}{\left|\vec{v}\right|}$ | Signed scalar projection of $\vec{u}$ onto $\vec{v}$ |
| Vector projection | $\operatorname{proj}_{\vec{v}}\vec{u}=\dfrac{\vec{u}\cdot\vec{v}}{\left|\vec{v}\right|^2}\vec{v}$ | Denominator is $\left|\vec{v}\right|^2$, not $\left|\vec{v}\right|$ |
| Cross product | $\vec{u}\times\vec{v}=\det\begin{pmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\u_1&u_2&u_3\\v_1&v_2&v_3\end{pmatrix}$ | Vector perpendicular to both |
| Cross-product order | $\vec{u}\times\vec{v}=-(\vec{v}\times\vec{u})$ | Reversing the order reverses the direction |
| Parallel vectors | $\vec{u}\parallel\vec{v}\iff\vec{u}\times\vec{v}=\vec{0}$ | For nonzero vectors |
| Parallelogram area | $A=\left|\vec{u}\times\vec{v}\right|$ | Area spanned by adjacent sides $\vec{u}$ and $\vec{v}$ |
| Triangle area | $A=\dfrac{1}{2}\left|\vec{u}\times\vec{v}\right|$ | Half the corresponding parallelogram area |
| Parallelepiped volume | $V=\lvert(\vec{u}\times\vec{v})\cdot\vec{w}\rvert$ | Absolute value of the scalar triple product |
| Coplanar vectors | $\vec{u},\vec{v},\vec{w}$ are coplanar $\iff(\vec{u}\times\vec{v})\cdot\vec{w}=0$ | Scalar triple product is zero |
| Line (vector form) | $\vec{r}=\vec{r}_0+t\vec{v}$ | Point $\vec{r}_0$ and direction $\vec{v}$ |
| Line (parametric) | $x=x_0+at,\;y=y_0+bt,\;z=z_0+ct$ | Direction $\vec{v}=\langle a,b,c\rangle$, point $(x_0,y_0,z_0)$ |
| Point-to-line distance | $d=\dfrac{\left|\overrightarrow{PS}\times\vec{v}\right|}{\left|\vec{v}\right|}$ | $S$ is any point on the line; $\vec{v}$ is its direction vector |
| Plane equation | $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$, or $Ax+By+Cz=D$ | Normal $\vec{n}=\langle A,B,C\rangle$ |
| Point-to-plane distance | $d=\left\lvert\dfrac{\overrightarrow{PS}\cdot\vec{n}}{\left|\vec{n}\right|}\right\rvert$ | $S$ is any point on the plane |
| Distance to coordinate plane | To $xy$: $\lvert z\rvert$; to $xz$: $\lvert y\rvert$; to $yz$: $\lvert x\rvert$ | Absolute value of the coordinate perpendicular to the plane |
| Distance to coordinate axis | To $x$: $\sqrt{y^2+z^2}$; to $y$: $\sqrt{x^2+z^2}$; to $z$: $\sqrt{x^2+y^2}$ | Use the two coordinates perpendicular to the axis |
| Cylinder | Example: $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}=1$ | The missing variable gives the cylinder's axis (here, the $z$-axis) |
| Ellipsoid | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}+\dfrac{z^2}{c^2}=1$ | All three squared terms have the same sign |
| Elliptic paraboloid | $z=\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}$ | One variable is unsquared; signs of squared terms match |
| Elliptic cone | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}=\dfrac{z^2}{c^2}$ | Homogeneous quadratic equation |
| Hyperboloid of one sheet | $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}-\dfrac{z^2}{c^2}=1$ | Two positive squared terms and one negative squared term |
| Hyperboloid of two sheets | $-\dfrac{x^2}{a^2}-\dfrac{y^2}{b^2}+\dfrac{z^2}{c^2}=1$ | One positive squared term and two negative squared terms |
| Work | $W=\vec{F}\cdot\vec{d}$ | Scalar; zero if force ⊥ displacement |

## Mixed Practice

These 10 problems span all six sections. They are scrambled in difficulty so you can't guess the method from the position.

:::::problem[Problem M.1 — Compute a 3D distance]{difficulty=easy}
Find the midpoint of the segment joining $A(3,-2,5)$ and $B(-1,4,1)$, and the distance $AB$.

::::solution[Solution]
**Answer:** Midpoint $(1,1,3)$; distance $AB=2\sqrt{17}$.

1. **Use the coordinatewise midpoint formula.** For $A=(3,-2,5)$ and $B=(-1,4,1)$, average each pair:

$$
M=\left(\frac{3+(-1)}2,\frac{-2+4}2,\frac{5+1}2\right)
=\left(\frac22,\frac22,\frac62\right)=(1,1,3).
$$

2. **Use the 3D distance formula.** Compute $B-A=\langle-1-3,4-(-2),1-5\rangle=\langle-4,6,-4\rangle$.

3. **Square, add, and simplify.** Thus

$$
AB=\sqrt{(-4)^2+6^2+(-4)^2}
=\sqrt{16+36+16}=\sqrt{68}
=\sqrt{4\cdot17}=2\sqrt{17}.
$$

4. **Check the midpoint.** The displacements $M-A=\langle-2,3,-2\rangle$ and $B-M=\langle-2,3,-2\rangle$ agree. Their lengths each equal $\sqrt{17}$, half of $AB$. Hence both the midpoint and the segment length check.
::::
:::::

:::::problem[Problem M.2 — Angle from a dot product]{difficulty=standard}
Find the angle between the diagonal of a cube (from one corner to the opposite corner) and one of the edges meeting at that corner.

::::solution[Solution]
**Answer:** $\theta=\arccos\!\left(\frac1{\sqrt3}\right)\approx54.7^\circ$.

1. **Model a cube using vectors.** The angle is independent of side length, so take a cube of side $1$. From one vertex at the origin, an edge is $\vec e=\langle1,0,0\rangle$ and the body diagonal is $\vec d=\langle1,1,1\rangle$. Neither vector is zero.

2. **Apply the dot-product angle formula.** First compute $\vec d\cdot\vec e=1(1)+1(0)+1(0)=1$. The magnitudes are $|\vec e|=\sqrt1=1$ and $|\vec d|=\sqrt{1+1+1}=\sqrt3$.

3. **Solve for the angle.** Therefore

$$
\cos\theta=\frac{\vec d\cdot\vec e}{|\vec d||\vec e|}
=\frac1{\sqrt3},\qquad\theta=\arccos\!\left(\frac1{\sqrt3}\right).
$$

4. **Check.** The cosine lies between $0$ and $1$, so the angle is acute; the exact inverse-cosine expression needs no calculator. Its approximate value is $54.7^\circ$, agreeing with the original result.
::::
:::::

:::::problem[Problem M.3 — Vector arithmetic]{difficulty=standard}
Show that the vectors $\vec{a}=\langle 3,1,-2\rangle$, $\vec{b}=\langle 1,5,4\rangle$ are perpendicular, then find a third vector orthogonal to both.

::::solution[Solution]
**Answer:** The vectors are perpendicular; one vector orthogonal to both is $\langle1,-1,1\rangle$.

1. **Test the original vectors with a dot product.** Two vectors are perpendicular exactly when their dot product is zero:

$$
\vec a\cdot\vec b=3(1)+1(5)+(-2)(4)=3+5-8=0.
$$

This confirms $\vec a\perp\vec b$.

2. **Use a cross product to find a common normal.** The cross product is perpendicular to each input vector:

$$
\vec a\times\vec b=
\langle1(4)-(-2)(5),\;(-2)(1)-3(4),\;3(5)-1(1)\rangle
=\langle14,-14,14\rangle.
$$

3. **Simplify the direction.** Dividing by the nonzero scalar $14$ gives $\vec n=\langle1,-1,1\rangle$.

4. **Check both perpendicularities.** $\vec n\cdot\vec a=3-1-2=0$ and $\vec n\cdot\vec b=1-5+4=0$. Thus $\vec n$ is a valid nonzero third vector perpendicular to both.
::::
:::::

:::::problem[Problem M.4 — Vector arithmetic]{difficulty=standard}
Find the vector and scalar projections of $\vec{b}=\langle 3,6,-2\rangle$ onto $\vec{a}=\langle 2,3,6\rangle$.

::::solution[Solution]
**Answer:** Scalar projection $12/7$; vector projection $\left\langle\frac{24}{49},\frac{36}{49},\frac{72}{49}\right\rangle$.

1. **Distinguish the two projections.** The signed scalar component of $\vec b$ along nonzero $\vec a$ is $(\vec b\cdot\vec a)/|\vec a|$. The vector projection is $((\vec b\cdot\vec a)/|\vec a|^2)\vec a$.

2. **Compute the dot product and length.** For $\vec b=\langle3,6,-2\rangle$ and $\vec a=\langle2,3,6\rangle$,

$$
\vec b\cdot\vec a=3(2)+6(3)+(-2)(6)=6+18-12=12,
$$
$$
|\vec a|=\sqrt{2^2+3^2+6^2}=\sqrt{4+9+36}=7.
$$

3. **Form both projections.** The scalar projection is $12/7$. Since $|\vec a|^2=49$, the vector projection is

$$
\frac{12}{49}\langle2,3,6\rangle
=\left\langle\frac{24}{49},\frac{36}{49},\frac{72}{49}\right\rangle.
$$

4. **Check.** The vector projection is a scalar multiple of $\vec a$, and its dot product with $\vec a$ is $(12/49)(49)=12=\vec b\cdot\vec a$. Hence the projection preserves exactly the component along $\vec a$.
::::
:::::

:::::problem[Problem M.5 — Angle from a dot product]{difficulty=challenge}
A triangle has vertices $P(1,0,1)$, $Q(3,2,0)$, $R(2,-1,3)$. Find: (a) the area of the triangle, (b) the angle at vertex $P$.

::::solution[Solution]
**Answer:** (a) Area $\dfrac{5\sqrt2}{2}$; (b) $\theta=\arccos\!\left(-\dfrac2{3\sqrt6}\right)\approx106^\circ$.

1. **Build sides from $P$**, the vertex at which the angle is requested. Subtract coordinates:

$$
\overrightarrow{PQ}=\langle3-1,2-0,0-1\rangle=\langle2,2,-1\rangle,
$$
$$
\overrightarrow{PR}=\langle2-1,-1-0,3-1\rangle=\langle1,-1,2\rangle.
$$

2. **Use the cross product for area.** Componentwise,

$$
\overrightarrow{PQ}\times\overrightarrow{PR}
=\langle2(2)-(-1)(-1),\;(-1)(1)-2(2),\;2(-1)-2(1)\rangle
=\langle3,-5,-4\rangle.
$$

Its length is $\sqrt{9+25+16}=\sqrt{50}=5\sqrt2$, so the triangle has area $A=\frac12(5\sqrt2)$.

3. **Use the dot product for the angle.** The dot product is $2(1)+2(-1)+(-1)(2)=2-2-2=-2$. The side lengths are $\sqrt{4+4+1}=3$ and $\sqrt{1+1+4}=\sqrt6$.

4. **Solve and check.** Thus $\cos\theta=-2/(3\sqrt6)$ and $\theta=\arccos(-2/(3\sqrt6))\approx106^\circ$. Its negative cosine correctly indicates an obtuse angle. The nonzero cross product confirms a positive area, so both answers are geometrically consistent.
::::
:::::

:::::problem[Problem M.6 — Plane equation and normal]{difficulty=standard}
Find the equation of the plane passing through $(2,1,-1)$ and perpendicular to both planes $x+2y-z=3$ and $2x-y+3z=1$.

::::solution[Solution]
**Answer:** $x-y-z=2$.

1. **Use plane normals to express perpendicularity.** The given planes have nonzero normals $\vec n_1=\langle1,2,-1\rangle$ and $\vec n_2=\langle2,-1,3\rangle$. A plane perpendicular to both must have a normal perpendicular to both of their normals. Take the cross product.

2. **Compute a candidate normal.** The components are

$$
\vec n_1\times\vec n_2
=\langle2(3)-(-1)(-1),\;(-1)(2)-1(3),\;1(-1)-2(2)\rangle
=\langle5,-5,-5\rangle.
$$

Divide by $5$ to obtain $\vec n=\langle1,-1,-1\rangle$.

3. **Use point-normal form at $(2,1,-1)$.** Substitute to get $(x-2)-(y-1)-(z+1)=0$. Expanding yields $x-2-y+1-z-1=0$, hence $x-y-z=2$.

4. **Check.** The given point satisfies $2-1-(-1)=2$. Also $\vec n\cdot\vec n_1=1-2+1=0$ and $\vec n\cdot\vec n_2=2+1-3=0$. The required plane is therefore perpendicular to both given planes.
::::
:::::


### Mixed practice: continued set 2

:::::problem[Problem M.7 — Ellipsoid and its axes]{difficulty=easy}
Identify the quadric surface $x^2+\frac{y^2}{4}+\frac{z^2}{9}=1$ and state its semi-axes.

::::solution[Solution]
**Answer:** Ellipsoid centered at $(0,0,0)$, with semi-axes $1$ along $x$, $2$ along $y$, and $3$ along $z$.

1. **Compare with the ellipsoid standard form.** A centered ellipsoid has equation $x^2/a^2+y^2/b^2+z^2/c^2=1$, with all denominators positive and $a,b,c>0$.

2. **Identify the denominators.** Rewrite the first term as $x^2/1$ so that the given equation is

$$
\frac{x^2}{1^2}+\frac{y^2}{2^2}+\frac{z^2}{3^2}=1.
$$

Thus $a=1$, $b=2$, and $c=3$.

3. **Check the center and intercepts.** Since there are no shifted variables, the center is the origin. Setting $y=z=0$ gives $x=\pm1$; setting $x=z=0$ gives $y=\pm2$; and setting $x=y=0$ gives $z=\pm3$.

4. **Conclude.** The three distinct axis intercept distances confirm an ellipsoid with the stated semi-axes, longest along $z$.
::::
:::::

:::::problem[Problem M.8 — Compute a 3D distance]{difficulty=standard}
Find the distance between the parallel planes $2x-3y+z=4$ and $2x-3y+z=10$.

::::solution[Solution]
**Answer:** $\dfrac{3\sqrt{14}}{7}$ units.

1. **Check the planes are parallel.** Both equations, $2x-3y+z=4$ and $2x-3y+z=10$, have the same nonzero normal $\langle2,-3,1\rangle$. They are distinct because the constants differ, so the shortest distance is the perpendicular distance from any point of the first plane to the second.

2. **Find an easy point on the first plane.** Set $y=z=0$, giving $2x=4$ and $x=2$. Thus $P=(2,0,0)$.

3. **Apply the point-to-plane formula to the second plane:**

$$
D=\frac{|2(2)-3(0)+0-10|}{\sqrt{2^2+(-3)^2+1^2}}
=\frac{|4-10|}{\sqrt{4+9+1}}=\frac6{\sqrt{14}}.
$$

4. **Rationalize and check.** Multiply top and bottom by $\sqrt{14}$ to get $6\sqrt{14}/14=3\sqrt{14}/7$. The direct parallel-plane formula $|10-4|/\sqrt{14}$ gives the same result. Hence the planes are $3\sqrt{14}/7$ units apart.
::::
:::::

:::::problem[Problem M.9 — Volume from a triple product]{difficulty=challenge}
Find the volume of the parallelepiped with one vertex at the origin and adjacent vertices at $A(1,2,0)$, $B(0,1,3)$, $C(2,0,1)$.

::::solution[Solution]
**Answer:** $13$ cubic units.

1. **Use the scalar triple product.** Three edge vectors from the same vertex determine a parallelepiped whose volume is $V=|\vec a\cdot(\vec b\times\vec c)|$. The origin is the shared vertex, so $\vec a=\langle1,2,0\rangle$, $\vec b=\langle0,1,3\rangle$, and $\vec c=\langle2,0,1\rangle$.

2. **Compute the cross product of two edges.** Componentwise,

$$
\vec b\times\vec c
=\langle1(1)-3(0),\;3(2)-0(1),\;0(0)-1(2)\rangle
=\langle1,6,-2\rangle.
$$

3. **Dot with the remaining edge.** Multiply and add:

$$
\vec a\cdot(\vec b\times\vec c)
=1(1)+2(6)+0(-2)=1+12+0=13.
$$

4. **Take absolute value and check.** Volume is never negative, so $V=|13|=13$. The nonzero triple product also confirms that the edges do not lie in one plane, so the parallelepiped has positive volume.
::::
:::::

:::::problem[Problem M.10 — Identify a hyperboloid]{difficulty=challenge}
Identify and sketch (describe all traces): $4x^2-y^2+4z^2+8x+2y-8z-4=0$.

::::solution[Solution]
**Answer:** Hyperboloid of one sheet centered at $(-1,1,1)$, with axis along $y$: $\frac{(x+1)^2}{11/4}+\frac{(z-1)^2}{11/4}-\frac{(y-1)^2}{11}=1.$

1. **Group the polynomial by variable.** Move $-4$ to the right: $4(x^2+2x)-(y^2-2y)+4(z^2-2z)=4$.

2. **Complete the three squares.** Write $x^2+2x=(x+1)^2-1$, $y^2-2y=(y-1)^2-1$, and $z^2-2z=(z-1)^2-1$. Then

$$
4(x+1)^2-4-(y-1)^2+1+4(z-1)^2-4=4.
$$

Move constants to obtain $4(x+1)^2+4(z-1)^2-(y-1)^2=11$, then divide by $11$ to reach the answer's standard form.

3. **Identify and describe traces.** Two positive squared terms and one negative give a one-sheet hyperboloid, oriented along $y$. At $y=k$ its traces are circles:

$$
(x+1)^2+(z-1)^2=\frac{11+(k-1)^2}{4}.
$$

The smallest circle occurs at $k=1$, radius $\sqrt{11}/2$. In the center planes $z=1$ and $x=-1$, respectively, the traces are $4(x+1)^2-(y-1)^2=11$ and $4(z-1)^2-(y-1)^2=11$, both hyperbolas.

4. **Check the sketch.** Circular $y=k$ slices exist for every $k$, connected through the waist, confirming one continuous sheet centered at $(-1,1,1)$.
::::
:::::

### Extended Drill — 20 Mastery Problems

The earlier extended drill is retained intact, now in labeled practice cards with hidden solutions.

:::::problem[Problem M.11 — Vector Arithmetic & Magnitude]{difficulty=standard}
Let $\vec{a} = \langle 3,-1,2\rangle$ and $\vec{b} = \langle -1,4,1\rangle$. Compute $2\vec{a}-3\vec{b}$ and $|2\vec{a}-3\vec{b}|$.

::::solution[Solution]
**Answer:** $2\vec a-3\vec b=\langle9,-14,1\rangle$; magnitude $\sqrt{278}$.

1. **Scalar multiply each vector.**

$$
2\vec{a} = \langle 6,-2,4\rangle, \qquad 3\vec{b} = \langle -3,12,3\rangle
$$

2. **Subtract component-wise.**

$$
2\vec{a}-3\vec{b} = \langle 6-(-3),\,-2-12,\,4-3\rangle = \langle 9,-14,1\rangle
$$

3. **Compute the magnitude.**

$$
|2\vec{a}-3\vec{b}| = \sqrt{9^2+(-14)^2+1^2} = \sqrt{81+196+1} = \sqrt{278}
$$

**Pitfall:**

$2\vec{a}-3\vec{b} \ne 2|\vec{a}|-3|\vec{b}|$. Magnitude is NOT linear — you must compute the result vector first, then take the magnitude.

4. **Check and conclusion.** Adding $3\vec b$ to the result returns $2\vec a$, and its squared magnitude is $81+196+1=278$. This checks both the vector and its length.
::::
:::::

:::::problem[Problem M.12 — Unit Vector and Direction]{difficulty=standard}
Find the unit vector in the direction of $\vec{v} = \langle 2,-2,1\rangle$. Then write $\vec{v}$ in terms of $\hat{\imath},\hat{\jmath},\hat{k}$.

::::solution[Solution]
**Answer:** Unit vector $\left\langle\frac23,-\frac23,\frac13\right\rangle$; $\vec v=2\hat\imath-2\hat\jmath+\hat k$.

1. **Compute $|\vec{v}|$.**

$$
|\vec{v}| = \sqrt{4+4+1} = \sqrt{9} = 3
$$

2. **Divide by the magnitude.**

$$
\hat{v} = \frac{\vec{v}}{|\vec{v}|} = \frac{1}{3}\langle 2,-2,1\rangle = \left\langle\frac{2}{3},-\frac{2}{3},\frac{1}{3}\right\rangle
$$

3. **Verify: $|\hat{v}|=1$.**

$$
\sqrt{\left(\frac{2}{3}\right)^2+\left(-\frac{2}{3}\right)^2+\left(\frac{1}{3}\right)^2} = \sqrt{\frac{4+4+1}{9}} = \sqrt{1} = 1\checkmark
$$

4. **Write in $\hat{\imath},\hat{\jmath},\hat{k}$ notation.**

$$
\vec{v} = 2\hat{\imath} - 2\hat{\jmath} + \hat{k}
$$

5. **Check and conclusion.** Its unit-vector length is $1$, and multiplying the unit vector by $3$ recovers the original $\vec v$. Both requested forms are correct.
::::
:::::

:::::problem[Problem M.13 — Dot Product and Angle]{difficulty=standard}
Find the angle between $\vec{u} = \langle 1,2,-1\rangle$ and $\vec{v} = \langle 3,0,2\rangle$.

::::solution[Solution]
**Answer:** $\theta=\arccos(1/\sqrt{78})\approx83.5^\circ$.

1. **Compute the dot product.**

$$
\vec{u}\cdot\vec{v} = (1)(3)+(2)(0)+(-1)(2) = 3+0-2 = 1
$$

2. **Compute the magnitudes.**

$$
|\vec{u}| = \sqrt{1+4+1} = \sqrt{6}, \qquad |\vec{v}| = \sqrt{9+0+4} = \sqrt{13}
$$

3. **Apply the angle formula.**

$$
\cos\theta = \frac{\vec{u}\cdot\vec{v}}{|\vec{u}||\vec{v}|} = \frac{1}{\sqrt{6}\cdot\sqrt{13}} = \frac{1}{\sqrt{78}}
$$

4. **Solve for $\theta$.**

$$
\theta = \arccos\!\left(\frac{1}{\sqrt{78}}\right) \approx \arccos(0.1132) \approx 83.5°
$$

**Key: Sign test.**

$\vec{u}\cdot\vec{v}>0 \Rightarrow \theta < 90°$ (acute); $<0 \Rightarrow$ obtuse; $=0 \Rightarrow$ perpendicular. Here the dot product is small and positive, consistent with nearly 90°.

5. **Check and conclusion.** The dot product is positive and both magnitudes are nonzero, so the angle must be acute. The exact inverse-cosine answer satisfies that condition.
::::
:::::

:::::problem[Problem M.14 — Projection]{difficulty=standard}
Find the scalar and vector projections of $\vec{b} = \langle 2,1,3\rangle$ onto $\vec{a} = \langle 1,0,1\rangle$.

::::solution[Solution]
**Answer:** Scalar projection $5/\sqrt2=5\sqrt2/2$; vector projection $\langle5/2,0,5/2\rangle$.

1. **Scalar projection (component of $\vec{b}$ along $\vec{a}$).**

$$
\text{comp}_{\vec{a}}\vec{b} = \frac{\vec{a}\cdot\vec{b}}{|\vec{a}|} = \frac{(1)(2)+(0)(1)+(1)(3)}{\sqrt{1+0+1}} = \frac{5}{\sqrt{2}} = \frac{5\sqrt{2}}{2}
$$

2. **Vector projection (the shadow of $\vec{b}$ on $\vec{a}$).**

$$
\text{proj}_{\vec{a}}\vec{b} = \frac{\vec{a}\cdot\vec{b}}{|\vec{a}|^2}\vec{a} = \frac{5}{2}\langle 1,0,1\rangle = \left\langle\frac{5}{2},0,\frac{5}{2}\right\rangle
$$

3. **Verify orthogonality of the remainder.** The component of $\vec{b}$ perpendicular to $\vec{a}$ is $\vec{b}-\text{proj}_{\vec{a}}\vec{b} = \langle 2-5/2,\,1-0,\,3-5/2\rangle = \langle -1/2,1,1/2\rangle$. Check: $\langle -1/2,1,1/2\rangle\cdot\langle 1,0,1\rangle = -1/2+0+1/2=0$. ✓

4. **Check and conclusion.** The remainder is perpendicular to $\vec a$ because its dot product with $\vec a$ is zero. Therefore the scalar and vector projections are both correct.
::::
:::::

:::::problem[Problem M.15 — Cross Product and Area]{difficulty=challenge}
Let $\vec{a} = \langle 1,2,0\rangle$, $\vec{b} = \langle 0,1,3\rangle$. Compute $\vec{a}\times\vec{b}$, verify it's perpendicular to both, and find the area of the parallelogram they span.

::::solution[Solution]
**Answer:** $\vec a\times\vec b=\langle6,-3,1\rangle$; parallelogram area $\sqrt{46}$.

1. **Set up the determinant.**

$$
\vec{a}\times\vec{b} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&2&0\\0&1&3\end{vmatrix}
$$

2. **Expand along the first row.**

$$
\hat{\imath}\begin{vmatrix}2&0\\1&3\end{vmatrix} -\hat{\jmath}\begin{vmatrix}1&0\\0&3\end{vmatrix}+\hat{k}\begin{vmatrix}1&2\\0&1\end{vmatrix}
$$



$$
= \hat{\imath}(6-0) - \hat{\jmath}(3-0) + \hat{k}(1-0) = \langle 6,-3,1\rangle
$$

3. **Verify perpendicularity.**

$$
\langle 6,-3,1\rangle\cdot\langle 1,2,0\rangle = 6-6+0=0\checkmark
$$



$$
\langle 6,-3,1\rangle\cdot\langle 0,1,3\rangle = 0-3+3=0\checkmark
$$

4. **Area of the parallelogram.**

$$
A = |\vec{a}\times\vec{b}| = \sqrt{36+9+1} = \sqrt{46}
$$

5. **Check and conclusion.** Both dot-product checks vanish, confirming a normal to the parallelogram. Its nonzero magnitude gives the exact area $\sqrt{46}$.
::::
:::::

:::::problem[Problem M.16 — Volume via Triple Product]{difficulty=challenge}
Find the volume of the parallelepiped determined by $\vec{a}=\langle 1,1,0\rangle$, $\vec{b}=\langle 0,1,2\rangle$, $\vec{c}=\langle 2,0,1\rangle$.

::::solution[Solution]
**Answer:** $5$ cubic units.

1. **Recall: Volume = $|\vec{a}\cdot(\vec{b}\times\vec{c})|$.**

2. **Compute $\vec{b}\times\vec{c}$.**

$$
\vec{b}\times\vec{c} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\0&1&2\\2&0&1\end{vmatrix} = \hat{\imath}(1\cdot1-2\cdot0)-\hat{\jmath}(0\cdot1-2\cdot2)+\hat{k}(0\cdot0-1\cdot2)
$$



$$
= \langle 1,4,-2\rangle
$$

3. **Dot with $\vec{a}$.**

$$
\vec{a}\cdot(\vec{b}\times\vec{c}) = \langle 1,1,0\rangle\cdot\langle 1,4,-2\rangle = 1+4+0 = 5
$$

4. **Volume.**

$$
V = |5| = \boxed{5}
$$

**Key: Shortcut.**

The scalar triple product equals the determinant of the matrix whose rows are $\vec{a},\vec{b},\vec{c}$. Expanding that $3\times3$ determinant gives the same answer.

5. **Check and conclusion.** The scalar triple product equals $5$, so the absolute value is positive and gives a volume of $5$ cubic units.
::::
:::::


### Extended Drill: continued set 2

:::::problem[Problem M.17 — Parametric Line Through Two Points]{difficulty=standard}
Write parametric equations and a symmetric equation for the line through $P(1,2,-1)$ and $Q(3,0,4)$.

::::solution[Solution]
**Answer:** $x=1+2t,\ y=2-2t,\ z=-1+5t$; $\dfrac{x-1}{2}=\dfrac{y-2}{-2}=\dfrac{z+1}{5}$.

1. **Find the direction vector.**

$$
\vec{d} = \overrightarrow{PQ} = \langle 3-1,\,0-2,\,4-(-1)\rangle = \langle 2,-2,5\rangle
$$

2. **Parametric equations (using point $P$).**

$$
x = 1+2t,\quad y = 2-2t,\quad z = -1+5t
$$

3. **Symmetric equations.** Solve each parametric equation for $t$ and equate:

$$
\frac{x-1}{2} = \frac{y-2}{-2} = \frac{z+1}{5}
$$

**Pitfall:**

The symmetric form requires all direction components to be nonzero. If, say, $d_y=0$, that equation drops out and you write "$y=2$" as a separate constraint alongside the remaining equalities.

4. **Check and conclusion.** At $t=0$ the point is $P$, while at $t=1$ it is $Q$. All three direction components are nonzero, so the symmetric equations are valid.
::::
:::::

:::::problem[Problem M.18 — Equation of a Plane]{difficulty=standard}
Find the equation of the plane that contains the point $(2,-1,3)$ and has normal vector $\vec{n} = \langle 4,1,-2\rangle$.

::::solution[Solution]
**Answer:** $4x+y-2z=1$.

1. **Point-normal form.** A plane with normal $\vec{n}=\langle a,b,c\rangle$ passing through $(x_0,y_0,z_0)$ satisfies:

$$
a(x-x_0)+b(y-y_0)+c(z-z_0)=0
$$

2. **Substitute.**

$$
4(x-2)+1(y+1)-2(z-3)=0
$$



$$
4x-8+y+1-2z+6=0
$$



$$
4x+y-2z-1=0
$$

3. **Standard form:** $\boxed{4x+y-2z=1}$.

4. **Check and conclusion.** Substitution of $(2,-1,3)$ gives $8-1-6=1$, and the coefficient vector is the required normal $\langle4,1,-2\rangle$. Because this normal vector is nonzero, the point-normal equation defines one plane rather than all of space. Each coefficient retains the correct sign, and the given point lies on the resulting plane.
::::
:::::

:::::problem[Problem M.19 — Plane Through Three Points]{difficulty=challenge}
Find the equation of the plane through $A(1,0,0)$, $B(0,2,0)$, and $C(0,0,3)$.

::::solution[Solution]
**Answer:** $6x+3y+2z=6$.

1. **Find two vectors in the plane.**

$$
\overrightarrow{AB} = \langle -1,2,0\rangle,\qquad \overrightarrow{AC} = \langle -1,0,3\rangle
$$

2. **Normal vector = $\overrightarrow{AB}\times\overrightarrow{AC}$.**

$$
\vec{n} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\-1&2&0\\-1&0&3\end{vmatrix} = \hat{\imath}(6-0)-\hat{\jmath}(-3-0)+\hat{k}(0-(-2)) = \langle 6,3,2\rangle
$$

3. **Plane equation using point $A(1,0,0)$.**

$$
6(x-1)+3(y-0)+2(z-0)=0 \implies 6x+3y+2z=6
$$

4. **Verify with the other points.**

$B(0,2,0)$: $0+6+0=6\checkmark$ $C(0,0,3)$: $0+0+6=6\checkmark$

**Connection: Intercept form.**

Dividing by 6 gives $x/1 + y/2 + z/3 = 1$ — the intercept form directly reads off the intercepts $(1,0,0)$, $(0,2,0)$, $(0,0,3)$.

5. **Check and conclusion.** All three given points satisfy $6x+3y+2z=6$, and the cross product is nonzero, establishing the unique plane.
::::
:::::

:::::problem[Problem M.20 — Distance from Point to Plane]{difficulty=challenge}
Find the distance from the point $P(3,1,-2)$ to the plane $2x-y+2z=4$.

::::solution[Solution]
**Answer:** $1$ unit.

1. **Recall the distance formula.** For a point $(x_0,y_0,z_0)$ and plane $ax+by+cz=d$:

$$
D = \frac{|ax_0+by_0+cz_0-d|}{\sqrt{a^2+b^2+c^2}}
$$

2. **Identify values.** $a=2,b=-1,c=2,d=4$ and $(x_0,y_0,z_0)=(3,1,-2)$.

3. **Substitute.**

$$
D = \frac{|2(3)+(-1)(1)+2(-2)-4|}{\sqrt{4+1+4}} = \frac{|6-1-4-4|}{\sqrt{9}} = \frac{|-3|}{3} = \frac{3}{3} = \boxed{1}
$$

4. **Check and conclusion.** The normal has length $3$, and the absolute signed offset of the point is $3$, giving the perpendicular distance $3/3=1$.
::::
:::::

:::::problem[Problem M.21 — Angle Between Planes]{difficulty=challenge}
Find the acute angle between the planes $x+2y-z=3$ and $2x-y+3z=1$.

::::solution[Solution]
**Answer:** $\theta=\arccos\!\left(\dfrac{3}{2\sqrt{21}}\right)\approx70.9^\circ$.

1. **Extract normal vectors.**

$$
\vec{n_1} = \langle 1,2,-1\rangle,\qquad \vec{n_2} = \langle 2,-1,3\rangle
$$

2. **Use the angle formula.** The dihedral angle satisfies $\cos\theta = \dfrac{|\vec{n_1}\cdot\vec{n_2}|}{|\vec{n_1}||\vec{n_2}|}$ (absolute value gives the acute angle).

$$
\vec{n_1}\cdot\vec{n_2} = 2-2-3 = -3
$$



$$
|\vec{n_1}| = \sqrt{6},\quad |\vec{n_2}| = \sqrt{14}
$$



$$
\cos\theta = \frac{|-3|}{\sqrt{6}\sqrt{14}} = \frac{3}{\sqrt{84}} = \frac{3}{2\sqrt{21}}
$$

3. **Solve.**

$$
\theta = \arccos\!\left(\frac{3}{2\sqrt{21}}\right) \approx \arccos(0.327) \approx 70.9°
$$

**Key: Why the absolute value?**

Normal vectors can point in opposite directions, giving a supplementary angle. Taking $|\vec{n_1}\cdot\vec{n_2}|$ always gives the acute dihedral angle.

4. **Check and conclusion.** The absolute dot product gives a positive cosine less than $1$, so the reported inverse-cosine expression is indeed the acute angle.
::::
:::::

:::::problem[Problem M.22 — Line of Intersection of Two Planes]{difficulty=challenge}
Find parametric equations for the line of intersection of $x+y+z=3$ and $x-y+2z=1$.

::::solution[Solution]
**Answer:** $x=2+3t,\ y=1-t,\ z=-2t$.

1. **Direction vector = $\vec{n_1}\times\vec{n_2}$.**

$$
\vec{n_1}=\langle 1,1,1\rangle,\quad\vec{n_2}=\langle 1,-1,2\rangle
$$



$$
\vec{d} = \vec{n_1}\times\vec{n_2} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&1&1\\1&-1&2\end{vmatrix} = \langle(2+1),-(2-1),(−1−1)\rangle = \langle 3,-1,-2\rangle
$$

2. **Find a point on both planes.** Set $z=0$ and solve the system:

$$
x+y=3,\quad x-y=1 \implies 2x=4 \implies x=2,\; y=1
$$

  Point: $(2,1,0)$.

3. **Parametric equations.**

$$
x=2+3t,\quad y=1-t,\quad z=-2t
$$

**Pitfall:**

Always verify your chosen point actually lies on BOTH planes. Here: $2+1+0=3\checkmark$ and $2-1+0=1\checkmark$.

4. **Check and conclusion.** Substituting the parametric equations gives $x+y+z=3$ and $x-y+2z=1$ identically for every $t$. Thus the line lies in both planes.
::::
:::::


### Extended Drill: continued set 3

:::::problem[Problem M.23 — Distance Between Parallel Planes]{difficulty=challenge}
Find the distance between the parallel planes $2x-3y+z=4$ and $2x-3y+z=-10$.

::::solution[Solution]
**Answer:** $\sqrt{14}$ units.

1. **Verify parallel.** The normal vector $\langle 2,-3,1\rangle$ is the same for both planes. Parallel confirmed.

2. **Pick any point on the first plane.** Set $y=0,z=0$: $2x=4\Rightarrow x=2$. Point: $(2,0,0)$.

3. **Distance from that point to the second plane $2x-3y+z=-10$.**

$$
D = \frac{|2(2)-3(0)+1(0)+10|}{\sqrt{4+9+1}} = \frac{|4+10|}{\sqrt{14}} = \frac{14}{\sqrt{14}} = \sqrt{14}
$$

**Connection: Pattern.**

For parallel planes $ax+by+cz=d_1$ and $ax+by+cz=d_2$, the distance simplifies to $\dfrac{|d_2-d_1|}{\sqrt{a^2+b^2+c^2}}$. Here: $\dfrac{|-10-4|}{\sqrt{14}} = \dfrac{14}{\sqrt{14}}$. ✓

4. **Check and conclusion.** The direct parallel-plane distance formula gives $|-10-4|/\sqrt{14}=\sqrt{14}$ as well, confirming the rationalized result.
::::
:::::

:::::problem[Problem M.24 — Skew Lines: Distance]{difficulty=challenge}
Show the lines $\ell_1: \langle 1+t,\,2t,\,3\rangle$ and $\ell_2: \langle 2+s,\,1,\,1+s\rangle$ are skew, then find the distance between them.

::::solution[Solution]
**Answer:** The lines are skew; shortest distance $5/3$.

1. **Direction vectors.** $\vec{d_1}=\langle 1,2,0\rangle$, $\vec{d_2}=\langle 1,0,1\rangle$.

2. **Check parallel:** $\vec{d_1}$ and $\vec{d_2}$ are not proportional (the ratio $1/1 \ne 2/0$). Not parallel.

3. **Check intersecting.** From $\ell_1$ and $\ell_2$:

$$
1+t=2+s,\quad 2t=1,\quad 3=1+s
$$

 From eq. 2: $t=1/2$. From eq. 3: $s=2$. Check eq. 1: $1+1/2=3/2$ but $2+2=4$. $3/2\ne4$. **No intersection.** Lines are skew.

4. **Distance formula for skew lines.**

$$
D = \frac{|(\vec{r_2}-\vec{r_1})\cdot(\vec{d_1}\times\vec{d_2})|}{|\vec{d_1}\times\vec{d_2}|}
$$

Connecting vector (using $t=s=0$): $\vec{r_2}-\vec{r_1} = \langle 2-1,1-0,1-3\rangle = \langle 1,1,-2\rangle$.

Cross product: $\vec{d_1}\times\vec{d_2} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&2&0\\1&0&1\end{vmatrix} = \langle 2,-1,-2\rangle$.

$$
|\vec{d_1}\times\vec{d_2}|=\sqrt{4+1+4}=3
$$



$$
(\vec{r_2}-\vec{r_1})\cdot\langle 2,-1,-2\rangle = 2-1+4=5
$$



$$
D = \frac{|5|}{3} = \boxed{\dfrac{5}{3}}
$$

5. **Check and conclusion.** The direction vectors are not parallel, the coordinate equations have no shared solution, and the scalar triple-product numerator is $5$. Hence the skew-line distance is $5/3$.
::::
:::::

:::::problem[Problem M.25 — Identify a Quadric Surface]{difficulty=standard}
Identify and sketch (describe the shape of) the surface $\dfrac{x^2}{4}+\dfrac{y^2}{9}-z^2=1$.

::::solution[Solution]
**Answer:** Hyperboloid of one sheet, centered at the origin, with axis along $z$.

1. **Standard form check.** The equation $\dfrac{x^2}{a^2}+\dfrac{y^2}{b^2}-\dfrac{z^2}{c^2}=1$ has two positive and one negative term on the left. This is a **hyperboloid of one sheet**.

2. **Read off parameters.** $a=2$, $b=3$, $c=1$. The axis of the hyperboloid is the $z$-axis (the variable with the negative sign).

3. **Cross-sections.**

*Horizontal slices* $z=k$: $\dfrac{x^2}{4}+\dfrac{y^2}{9} = 1+k^2$ — ellipses that get larger as $|k|$ increases.

*Slice $z=0$*: $\dfrac{x^2}{4}+\dfrac{y^2}{9}=1$, the "waist" ellipse with semi-axes 2 and 3.

*Vertical slices $x=0$*: $\dfrac{y^2}{9}-z^2=1$ — a hyperbola opening in the $\pm y$ direction.

**Key: Quick ID rule.**

Count signed terms: (++−)=1 → hyperboloid of one sheet; (++−)=−1 or equivalently (−−+)=1 → hyperboloid of two sheets; (+++)=1 → ellipsoid.

4. **Check and conclusion.** The waist ellipse exists at $z=0$, and an ellipse exists at every other height. Therefore the surface is one connected sheet along the $z$-axis.
::::
:::::

:::::problem[Problem M.26 — Equation to Identify: Paraboloid]{difficulty=standard}
Identify the surface $z = 4x^2 + y^2$ and describe its traces.

::::solution[Solution]
**Answer:** Upward-opening elliptic paraboloid with vertex $(0,0,0)$.

1. **Standard form.** $z = \dfrac{x^2}{(1/2)^2}+\dfrac{y^2}{1^2}$ — an **elliptic paraboloid** opening upward along the $z$-axis.

2. **Traces.**

*$z=k>0$:* $4x^2+y^2=k$ — ellipses (wider in the $y$ direction, narrower in $x$).

*$y=0$:* $z=4x^2$ — parabola in the $xz$-plane.

*$x=0$:* $z=y^2$ — parabola in the $yz$-plane.

3. **Vertex.** The minimum is at the origin $(0,0,0)$.

4. **Check and conclusion.** Because $4x^2+y^2\ge0$, no points exist below $z=0$; the minimum height is reached only at the origin. This confirms the upward opening and vertex.
::::
:::::

:::::problem[Problem M.27 — Torque as a Cross Product]{difficulty=challenge}
A force $\vec{F} = \langle 0,3,-2\rangle$ N is applied at the point $(1,2,0)$ m. The pivot is at the origin. Find the torque vector and its magnitude.

::::solution[Solution]
**Answer:** $\vec\tau=\langle-4,2,3\rangle\ \mathrm{N\cdot m}$; $|\vec\tau|=\sqrt{29}\ \mathrm{N\cdot m}$.

1. **Torque formula.** $\vec{\tau} = \vec{r}\times\vec{F}$, where $\vec{r}$ is the position vector from pivot to the point of application.

$$
\vec{r} = \langle 1,2,0\rangle
$$

2. **Compute the cross product.**

$$
\vec{\tau} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&2&0\\0&3&-2\end{vmatrix} = \hat{\imath}(-4-0)-\hat{\jmath}(-2-0)+\hat{k}(3-0) = \langle -4,2,3\rangle \text{ N·m}
$$

3. **Magnitude.**

$$
|\vec{\tau}| = \sqrt{16+4+9} = \sqrt{29} \approx 5.39 \text{ N·m}
$$

**Connection: Physical meaning.**

The direction of $\vec{\tau}$ (by the right-hand rule) gives the axis of rotation the force tends to produce. The magnitude is the rotational force (moment).

4. **Check and conclusion.** The cross product is perpendicular to both $\vec r$ and $\vec F$: its dot products with them are $-4+4=0$ and $6-6=0$. The units are newton-meters.
::::
:::::


### Extended Drill: continued set 4

:::::problem[Problem M.28 — Work via Dot Product]{difficulty=challenge}
A constant force $\vec{F}=\langle 2,3,1\rangle$ N moves an object from $A(0,1,2)$ to $B(3,4,0)$. Find the work done.

::::solution[Solution]
**Answer:** $13\ \mathrm{J}$.

1. **Displacement vector.**

$$
\vec{d} = \overrightarrow{AB} = \langle 3-0,\,4-1,\,0-2\rangle = \langle 3,3,-2\rangle \text{ m}
$$

2. **Work formula.** $W = \vec{F}\cdot\vec{d}$.

$$
W = (2)(3)+(3)(3)+(1)(-2) = 6+9-2 = \boxed{13 \text{ J}}
$$

**Intuition: Why dot product.**

Only the component of force along the displacement does work. The dot product extracts exactly that component and multiplies by distance in one step.

3. **Check and conclusion.** The three component contributions add to $6+9-2=13$. The positive sign means the force does net positive work over the displacement.
::::
:::::

:::::problem[Problem M.29 — Projection Decomposition]{difficulty=challenge}
Decompose $\vec{b}=\langle 3,4,-1\rangle$ into a component parallel to $\vec{a}=\langle 1,0,2\rangle$ and a component perpendicular to $\vec{a}$.

::::solution[Solution]
**Answer:** Parallel component $\langle1/5,0,2/5\rangle$; perpendicular component $\langle14/5,4,-7/5\rangle$.

1. **Parallel component** $= \text{proj}_{\vec{a}}\vec{b}$.

$$
\vec{a}\cdot\vec{b} = 3+0-2 = 1,\qquad |\vec{a}|^2 = 1+0+4=5
$$



$$
\vec{b}_{\parallel} = \frac{1}{5}\langle 1,0,2\rangle = \left\langle\frac{1}{5},0,\frac{2}{5}\right\rangle
$$

2. **Perpendicular component** $= \vec{b} - \vec{b}_\parallel$.

$$
\vec{b}_\perp = \langle 3,4,-1\rangle - \left\langle\frac{1}{5},0,\frac{2}{5}\right\rangle = \left\langle\frac{14}{5},4,-\frac{7}{5}\right\rangle
$$

3. **Verify.**

$$
\vec{b}_\perp\cdot\vec{a} = \frac{14}{5}+0-\frac{14}{5} = 0\checkmark
$$



$$
\vec{b}_\parallel + \vec{b}_\perp = \left\langle\frac{1}{5}+\frac{14}{5},\,0+4,\,\frac{2}{5}-\frac{7}{5}\right\rangle = \langle 3,4,-1\rangle = \vec{b}\checkmark
$$

4. **Check and conclusion.** The perpendicular part has zero dot product with $\vec a$, and adding it to the parallel part returns $\vec b$. The decomposition is therefore valid.
::::
:::::

:::::problem[Problem M.30 — Mixed: Plane Contains a Line]{difficulty=challenge}
Find the plane containing the line $x=1+t,\; y=2-t,\; z=3t$ and the point $P(2,1,0)$ (which is NOT on the line).

::::solution[Solution]
**Answer:** $x+y=3$.

1. **Pick a point on the line** (use $t=0$): $Q(1,2,0)$.

2. **Two vectors in the plane.**

Direction vector of the line: $\vec{d} = \langle 1,-1,3\rangle$.

Vector from $Q$ to $P$: $\overrightarrow{QP} = \langle 2-1,\,1-2,\,0-0\rangle = \langle 1,-1,0\rangle$.

3. **Normal = $\vec{d}\times\overrightarrow{QP}$.**

$$
\vec{n} = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&-1&3\\1&-1&0\end{vmatrix} = \hat{\imath}(0+3)-\hat{\jmath}(0-3)+\hat{k}(-1+1) = \langle 3,3,0\rangle
$$

  Simplify: $\vec{n} = \langle 1,1,0\rangle$.

4. **Plane equation using $Q(1,2,0)$.**

$$
1(x-1)+1(y-2)+0(z-0)=0 \implies x+y=3
$$

**Verify:** Point $P(2,1,0)$: $2+1=3\checkmark$. Line point at $t=1$: $(2,1,3)$: $2+1=3\checkmark$.

5. **Check and conclusion.** For an arbitrary line parameter $t$, $x+y=(1+t)+(2-t)=3$, and the given point also satisfies $2+1=3$. Thus the plane contains the entire line and $P$.
::::
:::::



## Beyond Test 2: Further Line and Plane Geometry

The following extensions preserve the original §12.5 subsections, named results, examples and exact derivations. They are not in the two released Fall 2026 Test 2 keys. Study them after the six tested question types.

### Distance from a Point to a Line

*Not on the released Test 2 versions A/B.* The formula remains useful for later vector geometry.

Suppose a line passes through a point $P$ with direction $\vec v$, and $S$ is a point somewhere off the line. The distance from $S$ to the line means the shortest distance, which is the length of the perpendicular dropped from $S$ onto the line. There is a slick way to get it with the cross product, and the reason it works is a picture of a parallelogram.

:::theorem[Theorem 12.5.1 — Distance from a Point to a Line]
Let a line pass through the point $P$ with direction vector $\vec v$, and let $S$ be any point. The distance from $S$ to the line is

$$
d=\frac{\left|\overrightarrow{PS}\times\vec v\right|}{|\vec v|}.
$$
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 320 193" width="320" height="193" role="img" aria-label="A point S, a line through P with direction v, and the perpendicular segment of length d from S to the line">
<path class="fig-fill" d="M84.74 146.56L187.37 114.89L180.51 30Z"/>
<path class="fig-axis" d="M186.3 101.66L205.3 95.8L206.37 109.03"/>
<path class="fig-guide" d="M180.51 30L187.37 114.89"/>
<path class="fig-curve-alt" d="M30 163.45L36.5 161.45L43 159.44L49.5 157.44L56 155.43L62.5 153.43L69 151.42L75.5 149.41L82 147.41L88.5 145.4L95 143.4L101.5 141.39L108 139.39L114.5 137.38L121 135.37L127.5 133.37L134 131.36L140.5 129.36L147 127.35L153.5 125.35L160 123.34L166.5 121.33L173 119.33L179.5 117.32L186 115.32L192.5 113.31L199 111.31L205.5 109.3L212 107.29L218.5 105.29L225 103.28L231.5 101.28L238 99.27L244.5 97.27L251 95.26L257.5 93.25L264 91.25L270.5 89.24L277 87.24L283.5 85.23L290 83.22"/>
<path class="fig-curve-alt" d="M84.74 146.56L180.51 30"/>
<path class="fig-curve-alt" d="M177.87 38.83L180.51 30L172.35 34.3"/>
<path class="fig-curve" d="M84.74 146.56L215.89 106.09"/>
<path class="fig-arrow" d="M221.58 104.34L214.52 110.28L212.4 103.4Z"/>
<circle class="fig-point" cx="84.74" cy="146.56" r="3.2"/>
<circle class="fig-point" cx="180.51" cy="30" r="3.2"/>
<circle class="fig-point" cx="187.37" cy="114.89" r="3.2"/>
<text class="fig-label-em" x="72.74" y="156.56">P</text>
<text class="fig-label-em" x="186.51" y="26">S</text>
<text class="fig-label-em" x="191.37" y="127.89">Q</text>
<text class="fig-label-em" x="229.58" y="110.34">v</text>
<text class="fig-label-em" x="191.94" y="74.45">d</text>
<text class="fig-label" x="112.62" y="84.28">PS</text>
</svg>
<figcaption>The distance from $S$ to the line through $P$ with direction $\mathbf{v}$ is the height of the parallelogram on $\overrightarrow{PS}$ and $\mathbf{v}$ over the base $|\mathbf{v}|$, so $d=\dfrac{|\overrightarrow{PS}\times\mathbf{v}|}{|\mathbf{v}|}$; the foot $Q$ is where the perpendicular meets the line.</figcaption>
</figure>

:::proof
Draw the two vectors $\overrightarrow{PS}$ and $\vec v$ from the common point $P$, and complete them to a parallelogram. From §12.4, the area of a parallelogram spanned by two vectors is the length of their cross product, so

$$
\text{area}=\left|\overrightarrow{PS}\times\vec v\right|.
$$

Now compute the same area the base-times-height way. Take the side along the line, which has length $|\vec v|$, as the base. The height of the parallelogram is the perpendicular distance from the opposite side to the line, and the opposite side runs through $S$, so that height is exactly the distance $d$ we want. Therefore

$$
\text{area}=|\vec v|\,d.
$$

Setting the two expressions for the area equal, $|\vec v|\,d=\left|\overrightarrow{PS}\times\vec v\right|$, and dividing by $|\vec v|$ gives the formula.
:::

So the formula is just "area divided by base equals height." That is the whole idea, and if you remember the picture you can rebuild the formula on a test.

Two practical remarks. First, $P$ can be any point on the line, since the perpendicular distance does not depend on which one you pick; the easiest is usually the point at $t=0$. Second, the order of the cross product does not matter for the distance. Swapping the factors gives $\vec v\times\overrightarrow{PS}=-\left(\overrightarrow{PS}\times\vec v\right)$, a vector pointing the opposite way but with exactly the same length. So $|\overrightarrow{PS}\times\vec v|=|\vec v\times\overrightarrow{PS}|$, and either version of the formula gives the same $d$. This is precisely the confusion that multiple-choice questions on this topic try to exploit: an answer choice written with $\vec v\times\overrightarrow{PS}$ in the numerator is just as correct as one written with $\overrightarrow{PS}\times\vec v$. What is not interchangeable is the denominator, which must be $|\vec v|$, the length of the line's direction and not of $\overrightarrow{PS}$.

:::::example[Example 3.66 — Distance from a Point to a Line]
Find the distance from the point $S(2,1,-1)$ to the line $x=2t,\;y=1+2t,\;z=2t$.

::::answer[Answer]
**Answer:** $d=\sqrt{\tfrac{14}{3}}=\dfrac{\sqrt{42}}{3}\approx 2.16$.

1. First extract a point and a direction from the line. At $t=0$ the line is at $P=(0,1,0)$, and the coefficients of $t$ give $\vec v=\langle 2,2,2\rangle$. The vector from $P$ to $S$ is

$$
\overrightarrow{PS}=\langle 2-0,\;1-1,\;-1-0\rangle=\langle 2,0,-1\rangle.
$$

2. Now the cross product $\overrightarrow{PS}\times\vec v$:

$$
\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\2&0&-1\\2&2&2\end{vmatrix}
=\bigl(0\cdot2-(-1)(2)\bigr)\mathbf i-\bigl(2\cdot2-(-1)(2)\bigr)\mathbf j+\bigl(2\cdot2-0\cdot2\bigr)\mathbf k
=2\mathbf i-6\mathbf j+4\mathbf k.
$$

3. Its length is

$$
\left|\overrightarrow{PS}\times\vec v\right|=\sqrt{2^2+(-6)^2+4^2}=\sqrt{4+36+16}=\sqrt{56}=2\sqrt{14}.
$$

4. The length of the direction vector is

$$
|\vec v|=\sqrt{4+4+4}=\sqrt{12}=2\sqrt3.
$$

5. Divide:

$$
d=\frac{2\sqrt{14}}{2\sqrt3}=\sqrt{\frac{14}{3}}=\frac{\sqrt{42}}{3}\approx 2.16.
$$

6. The factors of $2$ cancel. That is a hint that we could have used $\vec v=\langle1,1,1\rangle$ from the start, which is legitimate because the formula divides out the length of whatever direction you choose.

7. **Check.** The distance is nonnegative, and the cross-product numerator measures the perpendicular component, so the result has the correct geometric meaning.
::::
:::::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 320 220" width="320" height="220" role="img" aria-label="Tilted plane with one normal and an in-plane vector from a marked point">
<path class="fig-fill" d="M48.0 165.0L238.0 185.0L285.0 103.0L95.0 83.0L48.0 165.0"/>
<path class="fig-axis" d="M48.0 165.0L238.0 185.0L285.0 103.0L95.0 83.0L48.0 165.0"/>
<path class="fig-curve" d="M167.0 134.0L167.0 30.0"/>
<path class="fig-curve-alt" d="M167.0 134.0L232.0 142.0"/>
<circle class="fig-point" cx="167.0" cy="134.0" r="3"/><text class="fig-label" x="174.0" y="126.0">P0</text>
<circle class="fig-point" cx="167.0" cy="30.0" r="3"/><text class="fig-label" x="174.0" y="22.0">n</text>
<circle class="fig-point" cx="232.0" cy="142.0" r="3"/><text class="fig-label" x="239.0" y="134.0">w</text>
</svg>
<figcaption>A normal $\vec n$ is perpendicular to every in-plane direction $\vec w$, so the plane through $P_0$ is exactly the set of points satisfying $\vec n\cdot\overrightarrow{P_0P}=0$.</figcaption>
</figure>

### The Plane Containing Two Lines, If It Exists

*Not on the released Test 2 versions A/B.* This is an extension of the plane-through-a-line method.

A common wording is: "find the plane containing these two lines, if possible." The phrase "if possible" is doing real work. Two lines lie in a common plane only when they **intersect** or are **parallel**. Skew lines lie in no common plane, which is exactly what makes them skew. So the method has a decision at the front.

:::callout-key[Method — Plane Containing Two Lines]
1. Classify the lines with the method above. If they are skew, the answer is "no such plane exists," and you are finished.
2. Otherwise take one point $P_1$ on line 1 and one point $P_2$ on line 2.
3. Get two non-parallel vectors in the plane. If the lines intersect, use the two direction vectors $\vec v_1$ and $\vec v_2$. If they are parallel, the directions are useless (they are parallel to each other), so use one direction $\vec v_1$ and the connecting vector $\overrightarrow{P_1P_2}$.
4. The normal is the cross product of those two vectors. Write the plane through $P_1$.
:::

:::::example[Example 3.67 — Plane Containing Two Lines, If Possible]
(a) Find the plane containing the lines $x=2t+1,\;y=3t+2,\;z=4t+3$ and $x=s+2,\;y=2s+4,\;z=-4s-1$. (b) Find the plane containing the parallel lines $\vec r=t\langle 1,2,3\rangle$ and $\vec r=\langle 1,0,0\rangle+s\langle 2,4,6\rangle$.

::::answer[Answer]
**Answer:** (a) The two lines of Example 3.45 span the plane $-20x+12y+z=7$. (b) The parallel lines below span $3y-2z=0$. (c) Skew lines span no plane.

1. (a) In Example 3.45 we found that these lines intersect, at $(1,2,3)$, so a plane exists. The directions $\vec v_1=\langle 2,3,4\rangle$ and $\vec v_2=\langle 1,2,-4\rangle$ both lie in the plane, so

$$
\vec n=\vec v_1\times\vec v_2=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\2&3&4\\1&2&-4\end{vmatrix}
=(-12-8)\mathbf i-(-8-4)\mathbf j+(4-3)\mathbf k=\langle -20,12,1\rangle.
$$

2. Through the intersection point $(1,2,3)$:

$$
-20(x-1)+12(y-2)+(z-3)=0\quad\Longrightarrow\quad -20x+12y+z=-20+24+3=7.
$$

3. Check with a second point, $s=0$ on line 2, which is $(2,4,-1)$: $-40+48-1=7$. It lies in the plane.

4. (b) The directions are $\langle 1,2,3\rangle$ and $\langle 2,4,6\rangle=2\langle 1,2,3\rangle$, so the lines are parallel and the directions alone cannot give a normal (their cross product would be zero). Take $P_1=(0,0,0)$ on line 1 and $P_2=(1,0,0)$ on line 2. Then $\overrightarrow{P_1P_2}=\langle 1,0,0\rangle$ and

$$
\vec n=\vec v_1\times\overrightarrow{P_1P_2}=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\1&2&3\\1&0&0\end{vmatrix}
=(0-0)\mathbf i-(0-3)\mathbf j+(0-2)\mathbf k=\langle 0,3,-2\rangle.
$$

5. Through the origin: $3y-2z=0$. Check with $P_2=(1,0,0)$: $0-0=0$. And with the point $(3,4,6)$ on line 2 (at $s=1$): $12-12=0$.

6. (c) If the lines are skew, for instance the pair in Example 3.51, no plane can hold both; do not try to compute a normal, just say so.

7. **Check.** A valid cosine lies between negative one and one; a zero dot product confirms perpendicularity, and consistent component ratios confirm parallelism.
::::
:::::

### Intersections and Angles

**Angle between two planes** equals the angle between their normal vectors (or its supplement — take the acute angle):

$$
\cos\theta=\frac{|\vec{n}_1\cdot\vec{n}_2|}{|\vec{n}_1|\,|\vec{n}_2|}.
$$

 Two planes are parallel iff their normals are parallel; perpendicular iff their normals are orthogonal.

**Distance from point $P_1(x_1,y_1,z_1)$ to plane $ax+by+cz=d$**:

$$
D=\frac{|ax_1+by_1+cz_1-d|}{\sqrt{a^2+b^2+c^2}}.
$$

 This is the component of $\overrightarrow{P_0P_1}$ along $\hat{n}$ — a direct application of the scalar projection formula.

The same idea gives the distance from a point to a plane, and it is the same picture as the projection in §12.3. Pick any point $P$ on the plane and join it to the outside point $S$. The vector $\overrightarrow{PS}$ slants across; the distance to the plane is how far it reaches in the direction perpendicular to the plane, that is, along the normal $\vec n$. That reach is the length of the scalar projection of $\overrightarrow{PS}$ onto $\vec n$, taken as a positive number.

:::theorem[Theorem 12.5.2 — Distance from a Point to a Plane]
Let a plane have normal vector $\vec n$ and contain the point $P$, and let $S$ be any point. The distance from $S$ to the plane is

$$
d=\left|\overrightarrow{PS}\cdot\frac{\vec n}{|\vec n|}\right|=\frac{\left|\overrightarrow{PS}\cdot\vec n\right|}{|\vec n|}.
$$
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 320 277" width="320" height="277" role="img" aria-label="A point S above a plane, the vector PS from a point P of the plane, and the perpendicular segment of length d from S down to the plane">
<path class="fig-fill" d="M290 192.19L99.51 247.32L30 85.13L220.49 30Z"/>
<path class="fig-fill-alt" d="M230.78 150.08L120.46 113.64L186.51 58.3Z"/>
<path class="fig-gridline" d="M290 192.19L220.49 30"/>
<path class="fig-gridline" d="M290 192.19L99.51 247.32"/>
<path class="fig-gridline" d="M242.38 205.97L172.87 43.78"/>
<path class="fig-gridline" d="M272.62 151.64L82.13 206.77"/>
<path class="fig-gridline" d="M194.76 219.76L125.24 57.57"/>
<path class="fig-gridline" d="M255.24 111.09L64.76 166.23"/>
<path class="fig-gridline" d="M147.13 233.54L77.62 71.35"/>
<path class="fig-gridline" d="M237.87 70.55L47.38 125.68"/>
<path class="fig-gridline" d="M99.51 247.32L30 85.13"/>
<path class="fig-gridline" d="M220.49 30L30 85.13"/>
<path class="fig-axis" d="M290 192.19L99.51 247.32L30 85.13L220.49 30L290 192.19"/>
<path class="fig-axis" d="M131.34 104.53L153.83 111.96L142.95 121.08"/>
<path class="fig-guide" d="M230.78 150.08L120.46 113.64"/>
<path class="fig-guide" d="M186.51 58.3L120.46 113.64"/>
<path class="fig-curve-alt" d="M230.78 150.08L281.29 107.76"/>
<path class="fig-curve-alt" d="M277.07 115.96L281.29 107.76L272.48 110.48"/>
<path class="fig-curve" d="M230.78 150.08L189.1 63.66"/>
<path class="fig-arrow" d="M186.51 58.3L193.45 64.4L186.96 67.52Z"/>
<circle class="fig-point" cx="230.78" cy="150.08" r="3.2"/>
<circle class="fig-point" cx="186.51" cy="58.3" r="3.2"/>
<circle class="fig-point" cx="120.46" cy="113.64" r="3.2"/>
<text class="fig-label-em" x="218.78" y="158.08">P</text>
<text class="fig-label-em" x="192.51" y="55.3">S</text>
<text class="fig-label-em" x="126.46" y="125.64">Q</text>
<text class="fig-label-em" x="269.29" y="105.76">n</text>
<text class="fig-label-em" x="160.48" y="88.97">d</text>
<text class="fig-label" x="188.65" y="102.19">PS</text>
</svg>
<figcaption>The distance from $S$ to the plane is the length of the perpendicular segment $SQ$, which is the length of the projection of $\overrightarrow{PS}$ onto the normal: $d=\dfrac{|\overrightarrow{PS}\cdot\mathbf{n}|}{|\mathbf{n}|}$ for any point $P$ in the plane.</figcaption>
</figure>

The absolute value matters because $\overrightarrow{PS}\cdot\vec n$ is negative when $S$ is on the side of the plane opposite to where $\vec n$ points, and a distance can never be negative. The two forms of the formula agree because $|\vec n|$ is positive and can be pulled out of the absolute value. When the plane is given as $Ax+By+Cz=D$, choosing $P$ and expanding the dot product turns this into the formula $\dfrac{|Ax_1+By_1+Cz_1-D|}{\sqrt{A^2+B^2+C^2}}$ above, so you may use whichever version you find easier. Example 3.53 used the coordinate form; the next example uses the vector form, which is what the lecture used.

:::::example[Example 3.68 — Distance from a Point to a Plane]
Find the distance from $S(2,-3,4)$ to the plane $x+2y+2z=13$.

::::answer[Answer]
**Answer:** $d=3$.

1. Read the normal from the coefficients: $\vec n=\langle 1,2,2\rangle$, so

$$
|\vec n|=\sqrt{1+4+4}=\sqrt9=3.
$$

2. We need one point $P$ on the plane. Setting $y=0$ and $z=0$ in the equation gives $x=13$, so $P=(13,0,0)$ works. Then

$$
\overrightarrow{PS}=\langle 2-13,\;-3-0,\;4-0\rangle=\langle -11,-3,4\rangle.
$$

3. The dot product with the normal is

$$
\overrightarrow{PS}\cdot\vec n=(-11)(1)+(-3)(2)+(4)(2)=-11-6+8=-9.
$$

4. Therefore

$$
d=\frac{|-9|}{3}=3.
$$

5. Cross-check with the coordinate formula: $\dfrac{|1(2)+2(-3)+2(4)-13|}{3}=\dfrac{|2-6+8-13|}{3}=\dfrac{9}{3}=3$. Both routes agree. The negative sign of $-9$ just tells us $S$ is on the side of the plane opposite to $\vec n$.
::::
:::::

:::callout-connect
Chapter connection.

Finding a plane through three points (a very common exam question) uses the cross product from §12.4: compute two vectors in the plane from the three points, take their cross product to get the normal, then write the plane equation using any of the three points.
:::
