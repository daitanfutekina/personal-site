---
title: "Vector-Valued Functions and Motion in Space"
crumb: "Calculus 3 · Chapter 4 (Thomas Ch. 13)"
source: "markdown"
---

Thomas' Calculus ET 15e — Ch. 13 | Estimated study time: 8–10 hours


:::callout-warning[🚧 Work needed]
Six equation-sampled figures below illustrate space curves, tangents, projectile motion, arc length, and curvature; plotting is not assessed on Test 3.
:::

## Overview

Chapter 3 (Thomas Ch. 12) gave you the vocabulary of 3D space — vectors, dot products, cross products, planes. This chapter (Thomas Ch. 13) puts that vocabulary in motion. A **vector-valued function** assigns a vector to each value of a scalar parameter $t$, tracing out a curve through space as $t$ varies. Think of $t$ as time and the output vector as the position of a moving particle — and you immediately have the language of kinematics.

The chapter builds in a natural progression: define vector functions and their curves (§13.1), differentiate and integrate them componentwise (§13.1–13.2), measure the geometric shape of curves via arc length and curvature (§13.3–13.4), and use the results for velocity and acceleration (§13.1–13.2). Young’s written Test 3 covers only §§13.1–13.4; §§13.5–13.6 are explicitly outside Test 3.

:::callout-key
Prerequisites — make sure you have these solid:

- Parametric equations in 2D (Ch. 11)
- Vectors, dot product, cross product (Ch. 12)
- Single-variable differentiation and integration (Ch. 0)
- Chain rule, product rule, and basic trig derivatives
:::

:::callout-connect
Big picture.

Vector-valued functions are the bridge between the pure geometry of Chapter 3 (Thomas Ch. 12) and the multivariable calculus of Calc IV. Every concept here — tangent vectors, arc length, curvature — has a direct generalization when you move to surfaces and scalar fields next semester.
:::

## 13.1 Curves in Space and Their Tangents

:::callout-connect
📺 Watch before this section

“Vector-valued functions introduction | Multivariable Calculus” — Khan Academy
:::

:::callout-intuition
Intuition first.

A scalar function $f(t)$ gives one number for each input. A vector-valued function $\vec{r}(t)$ gives a whole vector — three numbers — for each input. As $t$ varies, the tip of $\vec{r}(t)$ sweeps out a path in 3D space. That path is a

space curve

. The parameter $t$ is usually time, but it can be anything. Once you realize that "parametric curve in 3D" is just the graph of a vector function, everything that follows in the chapter becomes a natural extension of ideas you already know from Calc I and Chapter 1.
:::

### Definition and Component Functions

:::definition
Definition 13.1.1 — Vector-Valued Function

A **vector-valued function** (or vector function) is a function of the form

$$
\vec{r}(t)=\langle f(t),g(t),h(t)\rangle=f(t)\hat{\imath}+g(t)\hat{\jmath}+h(t)\hat{k},
$$

 where $f$, $g$, $h$ are real-valued (component) functions. The domain of $\vec{r}$ is the set of $t$ where all three component functions are defined.
:::

Working with $\vec{r}(t)$ componentwise is the key skill. Nearly every operation — limits, derivatives, integrals — reduces to doing the same thing to each of $f$, $g$, $h$ separately.

### Limits and Continuity

:::definition
Definition 13.1.2 — Limit of a Vector Function

$$
\lim_{t\to a}\vec{r}(t)=\left\langle\lim_{t\to a}f(t),\;\lim_{t\to a}g(t),\;\lim_{t\to a}h(t)\right\rangle,
$$

 provided each component limit exists. $\vec{r}$ is **continuous** at $a$ if $\lim_{t\to a}\vec{r}(t)=\vec{r}(a)$, i.e. each component function is continuous at $a$.
:::

### Space Curves

The set of all points $(f(t),g(t),h(t))$ as $t$ ranges over the domain is the **space curve** $C$ traced by $\vec{r}(t)$. Some classic examples:

- **Helix:** $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$ — winds around the $z$-axis, climbing at constant rate
- **Circle in a plane:** $\vec{r}(t)=\langle a\cos t,a\sin t,c\rangle$ — horizontal circle at height $z=c$
- **Line:** $\vec{r}(t)=\vec{r}_0+t\vec{v}$ — the parametric line from §3.5

:::callout-connect
Connection to Chapter 1.

A 2D parametric curve $\langle f(t),g(t)\rangle$ is just a vector function with the $\hat{k}$ component set to zero. Everything in §13.1–13.5 generalizes what you learned about parametric curves in Chapter 1.
:::


:::callout-connect
📺 Watch before this section

“Derivatives of vector-valued functions” — Khan Academy
:::

:::callout-intuition
Intuition first.

Differentiating a scalar function gives you the instantaneous rate of change — a slope. Differentiating a vector function gives you the instantaneous rate of change of a position vector — a

velocity vector

that is tangent to the curve at that point. The beautiful thing is that you don't need any new theory: just differentiate each component separately. Integration works the same way. The only genuinely new idea is the concept of a

tangent vector

to a space curve, which is the geometric payload of the derivative.
:::

### The Derivative

:::definition
Definition 13.1.3 — Derivative of a Vector Function

$$
\vec{r}\,'(t)=\frac{d\vec{r}}{dt}=\lim_{h\to0}\frac{\vec{r}(t+h)-\vec{r}(t)}{h}=\langle f'(t),g'(t),h'(t)\rangle.
$$

 If $\vec{r}\,'(t_0)\ne\vec{0}$, it is a **tangent vector** to the curve at the point $\vec{r}(t_0)$. The **unit tangent vector** is $\hat{T}(t)=\vec{r}\,'(t)/|\vec{r}\,'(t)|$.
:::

Geometrically: $\vec{r}(t+h)-\vec{r}(t)$ is a secant vector pointing from one point on the curve to a nearby point. As $h\to0$, this secant vector rotates to become tangent to the curve. The derivative captures that limiting tangent direction.

### Differentiation Rules

All the rules from Calc I carry over — the proofs follow by differentiating componentwise.

:::theorem[Theorem 13.1.1 — Differentiation Rules for Vector Functions]
Let $\vec{u}(t)$ and $\vec{v}(t)$ be differentiable vector functions, $c$ a scalar, $f(t)$ a scalar function. Then:

$$
\begin{aligned}
 \frac{d}{dt}[\vec{u}+\vec{v}]&=\vec{u}'+\vec{v}'\\
 \frac{d}{dt}[c\vec{u}]&=c\vec{u}'\\
 \frac{d}{dt}[f(t)\vec{u}]&=f'(t)\vec{u}+f(t)\vec{u}'\quad\text{(scalar-vector product rule)}\\
 \frac{d}{dt}[\vec{u}\cdot\vec{v}]&=\vec{u}'\cdot\vec{v}+\vec{u}\cdot\vec{v}'\quad\text{(dot product rule)}\\
 \frac{d}{dt}[\vec{u}\times\vec{v}]&=\vec{u}'\times\vec{v}+\vec{u}\times\vec{v}'\quad\text{(cross product rule — order matters!)}\\
 \frac{d}{dt}[\vec{u}(f(t))]&=f'(t)\vec{u}'(f(t))\quad\text{(chain rule)}
 \end{aligned}
$$
:::

:::callout-key
Constant magnitude ↔ perpendicular derivative.

If $|\vec{r}(t)|=c$ (constant), then $\vec{r}(t)\cdot\vec{r}\,'(t)=0$. Proof: differentiate both sides of $\vec{r}\cdot\vec{r}=c^2$ to get $2\vec{r}\cdot\vec{r}\,'=0$. This is why the velocity of an object moving on a sphere is always perpendicular to its position vector — a fact used constantly in §13.4–13.5.
:::


:::callout-connect
📺 Watch before this section

“Parametric velocity and acceleration” — Khan Academy
:::

:::callout-intuition
Intuition first.

If $\vec{r}(t)$ is the position of a particle at time $t$, then differentiation gives velocity, differentiation again gives acceleration. This is the vector generalization of $v=x'$, $a=v'$ from Calc I — except now the motion can be in any direction in 3D space. The new insight in §13.5 is that acceleration decomposes naturally into two parts: one pointing along the direction of motion (changing speed) and one pointing perpendicular to motion (changing direction). These are called the

tangential

and

normal components

of acceleration. Projectile motion under gravity is the classic application.
:::

### Velocity, Speed, and Acceleration

:::definition
Definition 13.1.4 — Velocity and Acceleration

For a particle with position $\vec{r}(t)$:

$$
\text{Velocity:}\quad\vec{v}(t)=\vec{r}\,'(t),\qquad\text{Speed:}\quad|\vec{v}(t)|=|\vec{r}\,'(t)|.
$$

$$
\text{Acceleration:}\quad\vec{a}(t)=\vec{v}\,'(t)=\vec{r}\,''(t).
$$
:::

Speed is a scalar (always ≥ 0); velocity is a vector (has direction). The distinction matters — a particle on a circular path has constant speed but changing velocity because its direction constantly changes.

### Worked examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Perspective projection of equation sampled helix">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M237.6 183.0 L237.8 181.2 L237.9 179.4 L237.9 177.7 L237.8 175.9 L237.5 174.2 L237.2 172.4 L236.7 170.7 L236.1 169.0 L235.4 167.3 L234.6 165.7 L233.7 164.0 L232.7 162.4 L231.6 160.8 L230.4 159.3 L229.2 157.8 L227.8 156.3 L226.3 154.9 L224.7 153.5 L223.1 152.1 L221.4 150.8 L219.6 149.5 L217.8 148.3 L215.9 147.1 L213.9 146.0 L211.9 144.9 L209.8 143.9 L207.7 142.9 L205.5 142.0 L203.3 141.2 L201.1 140.4 L198.8 139.6 L196.5 139.0 L194.2 138.3 L191.9 137.7 L189.6 137.2 L187.3 136.8 L185.0 136.4 L182.7 136.0 L180.4 135.8 L178.2 135.5 L175.9 135.4 L173.7 135.3 L171.6 135.2 L169.4 135.2 L167.4 135.2 L165.3 135.3 L163.4 135.5 L161.5 135.7 L159.6 135.9 L157.8 136.2 L156.1 136.6 L154.5 137.0 L152.9 137.4 L151.5 137.9 L150.1 138.4 L148.8 138.9 L147.6 139.5 L146.5 140.1 L145.5 140.8 L144.6 141.4 L143.8 142.1 L143.1 142.8 L142.5 143.6 L142.1 144.3 L141.7 145.1 L141.5 145.9 L141.3 146.7 L141.3 147.5 L141.4 148.3 L141.6 149.1 L142.0 149.9 L142.4 150.7 L143.0 151.5 L143.7 152.3 L144.4 153.1 L145.4 153.8 L146.4 154.6 L147.5 155.3 L148.7 156.0 L150.1 156.7 L151.5 157.4 L153.1 158.0 L154.7 158.6 L156.5 159.2 L158.3 159.8 L160.2 160.3 L162.3 160.7 L164.4 161.2 L166.5 161.5 L168.8 161.9 L171.1 162.2 L173.5 162.4 L176.0 162.6 L178.5 162.8 L181.1 162.9 L183.7 163.0 L186.4 162.9 L189.1 162.9 L191.9 162.8 L194.6 162.6 L197.5 162.4 L200.3 162.1 L203.1 161.8 L206.0 161.4 L208.8 160.9 L211.7 160.4 L214.6 159.8 L217.4 159.2 L220.2 158.5 L223.0 157.8 L225.8 157.0 L228.6 156.1 L231.3 155.2 L234.0 154.2 L236.6 153.2 L239.2 152.1 L241.7 151.0 L244.1 149.8 L246.5 148.6 L248.9 147.4 L251.1 146.0 L253.3 144.7 L255.4 143.3 L257.4 141.8 L259.4 140.4 L261.2 138.9 L263.0 137.3 L264.6 135.7 L266.2 134.1 L267.6 132.5 L268.9 130.8 L270.2 129.1 L271.3 127.4 L272.3 125.7 L273.2 124.0 L274.0 122.2 L274.7 120.5 L275.3 118.7 L275.7 116.9 L276.1 115.1 L276.3 113.4 L276.4 111.6 L276.4 109.8 L276.2 108.1 L276.0 106.3 L275.6 104.6 L275.2 102.8 L274.6 101.1 L273.9 99.5 L273.1 97.8 L272.2 96.2 L271.2 94.6 L270.1 93.0 L268.9 91.4 L267.6 89.9 L266.2 88.4 L264.8 87.0 L263.2 85.6 L261.6 84.2 L259.9 82.9 L258.1 81.7 L256.2 80.4 L254.3 79.3 L252.3 78.1 L250.3 77.1 L248.2 76.1 L246.1 75.1 L243.9 74.2 L241.7 73.3 L239.5 72.5 L237.3 71.8 L235.0 71.1 L232.7 70.5 L230.4 69.9 L228.1 69.4 L225.8 68.9 L223.5 68.5 L221.2 68.2 L218.9 67.9 L216.6 67.7 L214.4 67.5 L212.2 67.4 L210.0 67.3 L207.9 67.3 L205.8 67.4 L203.8 67.5 L201.8 67.6 L199.9 67.8 L198.1 68.1 L196.3 68.4 L194.6 68.7 L192.9 69.1 L191.4 69.5 L189.9 70.0 L188.5 70.5 L187.2 71.1 L186.0 71.6 L184.9 72.3 L183.9 72.9 L183.0 73.6 L182.2 74.3 L181.6 75.0 L181.0 75.7 L180.5 76.5 L180.2 77.2 L179.9 78.0 L179.8 78.8 L179.8 79.6 L179.9 80.4 L180.1 81.2 L180.4 82.0 L180.9 82.8 L181.4 83.6 L182.1 84.4 L182.9 85.2 L183.8 86.0 L184.8 86.7 L185.9 87.5 L187.2 88.2 L188.5 88.9 L190.0 89.5 L191.5 90.2 L193.2 90.8 L194.9 91.4 L196.8 91.9 L198.7 92.4 L200.7 92.9 L202.8 93.3 L205.0 93.7 L207.3 94.0 L209.6 94.3 L212.0 94.6 L214.5 94.8 L217.0 94.9 L219.6 95.0 L222.2 95.1 L224.9 95.1 L227.6 95.0 L230.3 94.9 L233.1 94.7 L235.9 94.5 L238.7 94.2 L241.6 93.9 L244.4 93.5 L247.3 93.0 L250.2 92.5 L253.0 92.0 L255.8 91.3 L258.7 90.6 L261.5 89.9 L264.3 89.1 L267.0 88.2 L269.7 87.3 L272.4 86.4 L275.0 85.3 L277.6 84.3 L280.1 83.2 L282.6 82.0 L285.0 80.8 L287.3 79.5 L289.6 78.2 L291.8 76.8 L293.9 75.4 L295.9 74.0 L297.8 72.5 L299.7 71.0 L301.4 69.5 L303.1 67.9 L304.6 66.3 L306.1 64.6 L307.4 63.0 L308.6 61.3 L309.8 59.6 L310.8 57.9 L311.7 56.1 L312.5 54.4 L313.2 52.6 L313.7 50.8 L314.2 49.1 L314.5 47.3"/>

</svg>
<figcaption>For $\mathbf r(t)=\langle2\cos t,2\sin t,3t\rangle$, the horizontal position repeats every $2\pi$ while height increases by $6\pi$.</figcaption>
</figure>


<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Parabola and tangent sampled from parametric equations">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M143.0 153.0 L143.4 153.7 L143.7 154.4 L144.1 155.1 L144.4 155.8 L144.8 156.4 L145.1 157.1 L145.5 157.8 L145.8 158.4 L146.2 159.1 L146.5 159.7 L146.9 160.3 L147.3 160.9 L147.6 161.5 L148.0 162.2 L148.3 162.7 L148.7 163.3 L149.0 163.9 L149.4 164.5 L149.7 165.0 L150.1 165.6 L150.4 166.2 L150.8 166.7 L151.1 167.2 L151.5 167.7 L151.9 168.3 L152.2 168.8 L152.6 169.3 L152.9 169.8 L153.3 170.2 L153.6 170.7 L154.0 171.2 L154.3 171.7 L154.7 172.1 L155.0 172.6 L155.4 173.0 L155.8 173.4 L156.1 173.8 L156.5 174.3 L156.8 174.7 L157.2 175.1 L157.5 175.5 L157.9 175.8 L158.2 176.2 L158.6 176.6 L158.9 176.9 L159.3 177.3 L159.7 177.6 L160.0 178.0 L160.4 178.3 L160.7 178.6 L161.1 178.9 L161.4 179.2 L161.8 179.5 L162.1 179.8 L162.5 180.1 L162.8 180.4 L163.2 180.6 L163.5 180.9 L163.9 181.2 L164.3 181.4 L164.6 181.6 L165.0 181.9 L165.3 182.1 L165.7 182.3 L166.0 182.5 L166.4 182.7 L166.7 182.9 L167.1 183.0 L167.4 183.2 L167.8 183.4 L168.2 183.5 L168.5 183.7 L168.9 183.8 L169.2 184.0 L169.6 184.1 L169.9 184.2 L170.3 184.3 L170.6 184.4 L171.0 184.5 L171.3 184.6 L171.7 184.7 L172.1 184.7 L172.4 184.8 L172.8 184.8 L173.1 184.9 L173.5 184.9 L173.8 185.0 L174.2 185.0 L174.5 185.0 L174.9 185.0 L175.2 185.0 L175.6 185.0 L175.9 185.0 L176.3 184.9 L176.7 184.9 L177.0 184.9 L177.4 184.8 L177.7 184.8 L178.1 184.7 L178.4 184.6 L178.8 184.6 L179.1 184.5 L179.5 184.4 L179.8 184.3 L180.2 184.2 L180.6 184.0 L180.9 183.9 L181.3 183.8 L181.6 183.6 L182.0 183.5 L182.3 183.3 L182.7 183.2 L183.0 183.0 L183.4 182.8 L183.7 182.6 L184.1 182.4 L184.5 182.2 L184.8 182.0 L185.2 181.8 L185.5 181.5 L185.9 181.3 L186.2 181.1 L186.6 180.8 L186.9 180.6 L187.3 180.3 L187.6 180.0 L188.0 179.7 L188.3 179.4 L188.7 179.1 L189.1 178.8 L189.4 178.5 L189.8 178.2 L190.1 177.9 L190.5 177.5 L190.8 177.2 L191.2 176.8 L191.5 176.5 L191.9 176.1 L192.2 175.7 L192.6 175.3 L193.0 174.9 L193.3 174.5 L193.7 174.1 L194.0 173.7 L194.4 173.3 L194.7 172.8 L195.1 172.4 L195.4 172.0 L195.8 171.5 L196.1 171.0 L196.5 170.6 L196.9 170.1 L197.2 169.6 L197.6 169.1 L197.9 168.6 L198.3 168.1 L198.6 167.6 L199.0 167.0 L199.3 166.5 L199.7 166.0 L200.0 165.4 L200.4 164.8 L200.7 164.3 L201.1 163.7 L201.5 163.1 L201.8 162.5 L202.2 161.9 L202.5 161.3 L202.9 160.7 L203.2 160.1 L203.6 159.5 L203.9 158.8 L204.3 158.2 L204.6 157.5 L205.0 156.9 L205.4 156.2 L205.7 155.5 L206.1 154.8 L206.4 154.2 L206.8 153.5 L207.1 152.7 L207.5 152.0 L207.8 151.3 L208.2 150.6 L208.5 149.8 L208.9 149.1 L209.3 148.3 L209.6 147.6 L210.0 146.8 L210.3 146.0 L210.7 145.2 L211.0 144.4 L211.4 143.6 L211.7 142.8 L212.1 142.0 L212.4 141.2 L212.8 140.4 L213.1 139.5 L213.5 138.7 L213.9 137.8 L214.2 137.0 L214.6 136.1 L214.9 135.2 L215.3 134.3 L215.6 133.4 L216.0 132.5 L216.3 131.6 L216.7 130.7 L217.0 129.8 L217.4 128.8 L217.8 127.9 L218.1 126.9 L218.5 126.0 L218.8 125.0 L219.2 124.0 L219.5 123.0 L219.9 122.1 L220.2 121.1 L220.6 120.1 L220.9 119.0 L221.3 118.0 L221.7 117.0 L222.0 116.0 L222.4 114.9 L222.7 113.9 L223.1 112.8 L223.4 111.7 L223.8 110.6 L224.1 109.6 L224.5 108.5 L224.8 107.4 L225.2 106.3 L225.5 105.2 L225.9 104.0 L226.3 102.9 L226.6 101.8 L227.0 100.6 L227.3 99.5 L227.7 98.3 L228.0 97.1 L228.4 95.9 L228.7 94.8 L229.1 93.6 L229.4 92.4 L229.8 91.2 L230.2 89.9 L230.5 88.7 L230.9 87.5 L231.2 86.2 L231.6 85.0 L231.9 83.7 L232.3 82.5 L232.6 81.2 L233.0 79.9 L233.3 78.6 L233.7 77.3 L234.1 76.0 L234.4 74.7 L234.8 73.4 L235.1 72.1 L235.5 70.7 L235.8 69.4 L236.2 68.0 L236.5 66.7 L236.9 65.3 L237.2 63.9 L237.6 62.6 L237.9 61.2 L238.3 59.8 L238.7 58.4 L239.0 57.0 L239.4 55.5 L239.7 54.1 L240.1 52.7 L240.4 51.2 L240.8 49.8 L241.1 48.3 L241.5 46.8 L241.8 45.4 L242.2 43.9"/>
<path class="fig-guide" d="M183.0 201.0 L183.2 200.6 L183.4 200.3 L183.5 199.9 L183.7 199.6 L183.9 199.2 L184.1 198.9 L184.2 198.5 L184.4 198.2 L184.6 197.8 L184.8 197.5 L184.9 197.1 L185.1 196.7 L185.3 196.4 L185.5 196.0 L185.7 195.7 L185.8 195.3 L186.0 195.0 L186.2 194.6 L186.4 194.3 L186.5 193.9 L186.7 193.6 L186.9 193.2 L187.1 192.9 L187.3 192.5 L187.4 192.1 L187.6 191.8 L187.8 191.4 L188.0 191.1 L188.1 190.7 L188.3 190.4 L188.5 190.0 L188.7 189.7 L188.8 189.3 L189.0 189.0 L189.2 188.6 L189.4 188.2 L189.6 187.9 L189.7 187.5 L189.9 187.2 L190.1 186.8 L190.3 186.5 L190.4 186.1 L190.6 185.8 L190.8 185.4 L191.0 185.1 L191.1 184.7 L191.3 184.3 L191.5 184.0 L191.7 183.6 L191.9 183.3 L192.0 182.9 L192.2 182.6 L192.4 182.2 L192.6 181.9 L192.7 181.5 L192.9 181.2 L193.1 180.8 L193.3 180.5 L193.5 180.1 L193.6 179.7 L193.8 179.4 L194.0 179.0 L194.2 178.7 L194.3 178.3 L194.5 178.0 L194.7 177.6 L194.9 177.3 L195.0 176.9 L195.2 176.6 L195.4 176.2 L195.6 175.8 L195.8 175.5 L195.9 175.1 L196.1 174.8 L196.3 174.4 L196.5 174.1 L196.6 173.7 L196.8 173.4 L197.0 173.0 L197.2 172.7 L197.3 172.3 L197.5 171.9 L197.7 171.6 L197.9 171.2 L198.1 170.9 L198.2 170.5 L198.4 170.2 L198.6 169.8 L198.8 169.5 L198.9 169.1 L199.1 168.8 L199.3 168.4 L199.5 168.1 L199.7 167.7 L199.8 167.3 L200.0 167.0 L200.2 166.6 L200.4 166.3 L200.5 165.9 L200.7 165.6 L200.9 165.2 L201.1 164.9 L201.2 164.5 L201.4 164.2 L201.6 163.8 L201.8 163.4 L202.0 163.1 L202.1 162.7 L202.3 162.4 L202.5 162.0 L202.7 161.7 L202.8 161.3 L203.0 161.0 L203.2 160.6 L203.4 160.3 L203.5 159.9 L203.7 159.5 L203.9 159.2 L204.1 158.8 L204.3 158.5 L204.4 158.1 L204.6 157.8 L204.8 157.4 L205.0 157.1 L205.1 156.7 L205.3 156.4 L205.5 156.0 L205.7 155.7 L205.9 155.3 L206.0 154.9 L206.2 154.6 L206.4 154.2 L206.6 153.9 L206.7 153.5 L206.9 153.2 L207.1 152.8 L207.3 152.5 L207.4 152.1 L207.6 151.8 L207.8 151.4 L208.0 151.0 L208.2 150.7 L208.3 150.3 L208.5 150.0 L208.7 149.6 L208.9 149.3 L209.0 148.9 L209.2 148.6 L209.4 148.2 L209.6 147.9 L209.7 147.5 L209.9 147.1 L210.1 146.8 L210.3 146.4 L210.5 146.1 L210.6 145.7 L210.8 145.4 L211.0 145.0 L211.2 144.7 L211.3 144.3 L211.5 144.0 L211.7 143.6 L211.9 143.3 L212.1 142.9 L212.2 142.5 L212.4 142.2 L212.6 141.8 L212.8 141.5 L212.9 141.1 L213.1 140.8 L213.3 140.4 L213.5 140.1 L213.6 139.7 L213.8 139.4 L214.0 139.0 L214.2 138.6 L214.4 138.3 L214.5 137.9 L214.7 137.6 L214.9 137.2 L215.1 136.9 L215.2 136.5 L215.4 136.2 L215.6 135.8 L215.8 135.5 L215.9 135.1 L216.1 134.7 L216.3 134.4 L216.5 134.0 L216.7 133.7 L216.8 133.3 L217.0 133.0 L217.2 132.6 L217.4 132.3 L217.5 131.9 L217.7 131.6 L217.9 131.2 L218.1 130.9 L218.3 130.5 L218.4 130.1 L218.6 129.8 L218.8 129.4 L219.0 129.1 L219.1 128.7 L219.3 128.4 L219.5 128.0 L219.7 127.7 L219.8 127.3 L220.0 127.0 L220.2 126.6 L220.4 126.2 L220.6 125.9 L220.7 125.5 L220.9 125.2 L221.1 124.8 L221.3 124.5 L221.4 124.1 L221.6 123.8 L221.8 123.4 L222.0 123.1 L222.1 122.7 L222.3 122.3 L222.5 122.0 L222.7 121.6 L222.9 121.3 L223.0 120.9 L223.2 120.6 L223.4 120.2 L223.6 119.9 L223.7 119.5 L223.9 119.2 L224.1 118.8 L224.3 118.5 L224.5 118.1 L224.6 117.7 L224.8 117.4 L225.0 117.0 L225.2 116.7 L225.3 116.3 L225.5 116.0 L225.7 115.6 L225.9 115.3 L226.0 114.9 L226.2 114.6 L226.4 114.2 L226.6 113.8 L226.8 113.5 L226.9 113.1 L227.1 112.8 L227.3 112.4 L227.5 112.1 L227.6 111.7 L227.8 111.4 L228.0 111.0 L228.2 110.7 L228.3 110.3 L228.5 109.9 L228.7 109.6 L228.9 109.2 L229.1 108.9 L229.2 108.5 L229.4 108.2 L229.6 107.8 L229.8 107.5 L229.9 107.1 L230.1 106.8 L230.3 106.4 L230.5 106.1 L230.7 105.7 L230.8 105.3 L231.0 105.0 L231.2 104.6 L231.4 104.3 L231.5 103.9 L231.7 103.6 L231.9 103.2 L232.1 102.9 L232.2 102.5 L232.4 102.2 L232.6 101.8"/>
<path class="fig-point" d="M 207 153 l 0.1 0"/>

</svg>
<figcaption>For $\mathbf r(t)=\langle t,t^2\rangle$ at $t=1$, the tangent direction is $\langle1,2\rangle$; the tangent line is not the curve itself.</figcaption>
</figure>


:::example[Example 13.1.1 — Domain of a Vector Function]

**Answer: Domain is $[-1,0)\cup(0,1]$.**

Find the domain of $\vec{r}(t)=\langle\sqrt{1-t^2},\;\ln|t|,\;e^t\rangle$.

**Solution.** Each component must be defined:

 $\sqrt{1-t^2}$: need $1-t^2\ge0\Rightarrow t\in[-1,1]$
 $\ln|t|$: need $t\ne0$
 $e^t$: all reals

 Intersection: $t\in[-1,1]$ and $t\ne0$, so domain $=[-1,0)\cup(0,1]$.
:::

:::example[Example 13.1.2 — Limit of a Vector Function]

**Answer: $\langle 1, 0, 1\rangle$.**

Find $\displaystyle\lim_{t\to 0}\left\langle\frac{\sin t}{t},\;t^2\cos t,\;e^t\right\rangle$.

**Solution.** Take each limit separately:

$$
\lim_{t\to0}\frac{\sin t}{t}=1,\qquad\lim_{t\to0}t^2\cos t=0,\qquad\lim_{t\to0}e^t=1.
$$

 Result: $\langle 1,0,1\rangle$. The third component is the one to watch: $e^t$ at $t=0$ is $e^0 = 1$, not $e$. Seeing an exponential and writing $e$ without evaluating it is a reflex worth breaking here, where it is obvious, rather than later where it is not.
:::

:::example[Example 13.1.3 — Recognizing a Space Curve]

**Answer: A helix of radius 2, pitch $2\pi\cdot3=6\pi$ per revolution.**

Describe the space curve $\vec{r}(t)=\langle 2\cos t,2\sin t,3t\rangle$.

**Solution.** The $x$- and $y$-components trace a circle of radius 2 in the $xy$-plane. The $z$-component $3t$ grows linearly, so the curve spirals upward — a *circular helix*. For each full revolution ($t$ increases by $2\pi$), $z$ increases by $6\pi$. The axis of the helix is the $z$-axis.
:::

:::example[Example 13.1.4 — Intersection of Two Surfaces as a Space Curve]

**Answer: $\vec{r}(t)=\langle\cos t,\sin t,\cos^2 t\rangle$.**

Find a vector function representing the intersection of the cylinder $x^2+y^2=1$ with the paraboloid $z=x^2$.

**Solution.** On the cylinder, set $x=\cos t$, $y=\sin t$. Then $z=x^2=\cos^2 t$. So:

$$
\vec{r}(t)=\langle\cos t,\sin t,\cos^2 t\rangle,\qquad t\in[0,2\pi).
$$
:::

:::example[Example 13.1.5 — Differentiating a Vector Function]

**Answer: $\vec{r}\,'(t)=\langle -\sin t,2t,3t^2\rangle$.**

Find $\vec{r}\,'(t)$ for $\vec{r}(t)=\langle\cos t,t^2,t^3\rangle$.

**Solution.** Differentiate componentwise:

$$
\frac{d}{dt}[\cos t]=-\sin t,\quad\frac{d}{dt}[t^2]=2t,\quad\frac{d}{dt}[t^3]=3t^2.
$$

 So $\vec{r}\,'(t)=\langle -\sin t,2t,3t^2\rangle$.
:::

:::example[Example 13.1.6 — Tangent Line to a Space Curve]

**Answer: $\ell(t)=\langle 0,1,\pi/2\rangle+t\langle -1,0,1\rangle$.**

Find the tangent line to $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$ at $t=\pi/2$.

**Solution.** Point: $\vec{r}(\pi/2)=\langle\cos(\pi/2),\sin(\pi/2),\pi/2\rangle=\langle 0,1,\pi/2\rangle$.

Direction: $\vec{r}\,'(\pi/2)=\langle-\sin(\pi/2),\cos(\pi/2),1\rangle=\langle -1,0,1\rangle$.

Tangent line: $\ell(t)=\langle 0,1,\pi/2\rangle+t\langle -1,0,1\rangle$.
:::

:::example[Example 13.1.7 — Using the Dot Product Rule]

**Answer: $\frac{d}{dt}[\vec{u}\cdot\vec{v}]=1+3t^2-5t^4$.**

Given $\vec{u}(t)=\langle t,t^2,t^3\rangle$ and $\vec{v}(t)=\langle 1,t,-t^2\rangle$, compute $\frac{d}{dt}[\vec{u}\cdot\vec{v}]$ two ways: directly and via the product rule.

**Solution (direct).** $\vec{u}\cdot\vec{v}=t+t^3-t^5$. Differentiate: $1+3t^2-5t^4$.

**Solution (product rule).**

$$
\vec{u}'=\langle 1,2t,3t^2\rangle,\quad\vec{v}'=\langle 0,1,-2t\rangle.
$$

$$
\vec{u}'\cdot\vec{v}+\vec{u}\cdot\vec{v}'=(1+2t^2-3t^4)+(0+t^2-2t^4)=1+3t^2-5t^4.\;\checkmark
$$
:::

:::example[Example 13.1.8 — Velocity and Acceleration from Position]

**Answer: $\vec{v}(t)=\langle-\sin t,2t,3\rangle$, $\vec{a}(t)=\langle-\cos t,2,0\rangle$.**

A particle has position $\vec{r}(t)=\langle\cos t,t^2,3t\rangle$. Find its velocity and acceleration.

**Solution.** Differentiate componentwise:

$$
\vec{v}(t)=\vec{r}\,'(t)=\langle-\sin t,2t,3\rangle.
$$

$$
\vec{a}(t)=\vec{v}\,'(t)=\langle-\cos t,2,0\rangle.
$$

 At $t=0$: velocity $\langle 0,0,3\rangle$ (pointing along $z$-axis), acceleration $\langle -1,2,0\rangle$.
:::

:::example[Example 13.1.9 — Speed and Direction]

**Answer: Speed at $t=\pi/2$ is $\sqrt{10+\pi^2}$.**

For $\vec{r}(t)=\langle\cos t,t^2,3t\rangle$, find the speed at $t=\pi/2$ and the angle the velocity makes with the $z$-axis.

**Solution.** $\vec{v}(\pi/2)=\langle-\sin(\pi/2),\pi,3\rangle=\langle-1,\pi,3\rangle$.

$$
\text{speed}=|\vec{v}|=\sqrt{1+\pi^2+9}=\sqrt{10+\pi^2}\approx\sqrt{10+9.87}\approx\sqrt{19.87}\approx4.46.
$$

 Angle with $z$-axis: $\cos\alpha=3/\sqrt{10+\pi^2}$.
:::

### Practice problems

::::problem[Problem 13.1.1 easy]{difficulty=easy}
Find the domain of $\vec{r}(t)=\langle\sqrt{t},\;\frac{1}{t-1},\;\ln(4-t)\rangle$.

:::solution[Solution]
**Answer:** $[0,1)\cup(1,4)$.

1. **Use the domain-intersection rule.** A vector function is defined only when every component is defined at the same parameter value.
2. **Check the square root.** $\sqrt{t}$ requires $t\ge0$; a negative radicand would not give a real component.
3. **Check the fraction.** $1/(t-1)$ has denominator zero at $t=1$, so $t\ne1$.
4. **Check the logarithm.** The input of $\ln(4-t)$ must be positive: $4-t>0$, hence $t<4$.
5. **Intersect the restrictions.** Combining $t\ge0$ and $t<4$ gives $[0,4)$. Removing $t=1$ splits the set into $[0,1)\cup(1,4)$. Thus this union is the complete domain.
:::
::::
::::problem[Problem 13.1.2 easy]{difficulty=easy}
Find $\displaystyle\lim_{t\to1}\langle t^2-1,\;\frac{t^2-1}{t-1},\;\sin(\pi t)\rangle$.

:::solution[Solution]
**Answer:** $\langle0,2,0\rangle$.

1. **Use componentwise limits.** A vector limit exists if all three scalar limits exist; evaluate them separately.
2. **First component:** Since $t^2-1$ is a polynomial, substitute $t=1$ to get $1^2-1=0$.
3. **Second component:** Direct substitution gives $0/0$, so factor before taking the limit:

$$
\frac{t^2-1}{t-1}=\frac{(t-1)(t+1)}{t-1}=t+1\quad(t\ne1).
$$

   Since a limit depends on nearby values, canceling is valid for $t\to1$; the limit is $1+1=2$.
4. **Third component:** Sine is continuous, so $\lim_{t\to1}\sin(\pi t)=\sin\pi=0$.
5. **Combine the results.** Every component has a finite limit, hence the vector limit is $\langle0,2,0\rangle$.
:::
::::
::::problem[Problem 13.1.3 standard]{difficulty=standard}
Describe the curve $\vec{r}(t)=\langle t,t^2,t^3\rangle$. What familiar curve is the $xy$-trace?

:::solution[Solution]
**Answer:** The space curve $\langle t,t^2,t^3\rangle$ projects to the parabola $y=x^2$.

1. **Read the parameterization as coordinates.** Write $x=t$, $y=t^2$, and $z=t^3$. Each real $t$ gives one point on the space curve.
2. **Eliminate $t$ to describe the curve.** Because $x=t$, substitute $t=x$ into the other equations to obtain $y=x^2$ and $z=x^3$. The curve satisfies both equations simultaneously.
3. **Find its $xy$-trace or projection.** Looking from directly above means ignoring height $z$ and keeping $(x,y)=(t,t^2)$. Therefore $y=x^2$, the familiar upward-opening parabola in the $xy$-plane.
4. **Describe the space curve.** The height $z=x^3$ is negative for $x<0$, zero at the origin, and positive for $x>0$. Consequently the curve is a twisted cubic in three dimensions, not a parabola lying entirely in one plane.
:::
::::
::::problem[Problem 13.1.4 standard]{difficulty=standard}
Find a vector function for the curve of intersection of the plane $y=x$ and the sphere $x^2+y^2+z^2=4$.

:::solution[Solution]
**Answer:** $\langle\sqrt2\cos t,\sqrt2\cos t,2\sin t\rangle$.

1. **Impose the plane equation.** Every point of the intersection has $y=x$. Substitute this into the sphere equation:

$$
x^2+x^2+z^2=4\quad\Longrightarrow\quad 2x^2+z^2=4.
$$

2. **Put the equation in ellipse form.** Divide by $4$:

$$
\frac{x^2}{2}+\frac{z^2}{4}=1.
$$

3. **Parameterize using $\cos^2t+\sin^2t=1$.** Choose $x=\sqrt2\cos t$ and $z=2\sin t$, so $x^2/2+z^2/4=\cos^2t+\sin^2t=1$.
4. **Recover the remaining coordinate.** Since $y=x$, set $y=\sqrt2\cos t$.
5. **Check both surfaces.** The plane equation holds immediately, and $x^2+y^2+z^2=4\cos^2t+4\sin^2t=4$. Thus $\vec r(t)=\langle\sqrt2\cos t,\sqrt2\cos t,2\sin t\rangle$, $0\le t<2\pi$, traces the complete intersection once.
:::
::::
::::problem[Problem 13.1.5 challenge]{difficulty=challenge}
Show that the curve $\vec{r}(t)=\langle t,t^2,t^2\rangle$ lies on the paraboloid $y=x^2$ and on the plane $z=y$. Describe it geometrically.

:::solution[Solution]
**Answer:** It lies on both specified surfaces for all real t.

1. **Identify coordinates.** From $\vec r(t)=\langle t,t^2,t^2\rangle$, we have $x=t$, $y=t^2$, and $z=t^2$ for every real $t$.
2. **Check the first surface.** Calculate $x^2=t^2$, which equals $y$. Hence the equation $y=x^2$ holds identically, with no restriction on $t$.
3. **Check the second surface.** Because $z=t^2$ and $y=t^2$, we get $z=y$. Every point also belongs to the plane $z=y$.
4. **Describe the geometry.** Eliminate the parameter: $y=z=x^2$. Thus the curve is a parabola lying in the tilted plane $z=y$, with vertex $(0,0,0)$ and opening toward increasing $y$ and $z$ as $|x|$ grows. The plane makes a $45^\circ$ angle with the $xy$-plane.
5. **Conclude.** Both equations hold for every real parameter, so the curve is precisely their intersection.
:::
::::
::::problem[Problem 13.1.6 easy]{difficulty=easy}
Find $\vec{r}\,'(t)$ for $\vec{r}(t)=\langle e^{2t},\ln t,\tan t\rangle$.

:::solution[Solution]
**Answer:** $\langle2e^{2t},1/t,\sec^2t\rangle$.

1. **Use the componentwise derivative rule.** Differentiate each coordinate of $\vec r(t)$ independently; no cross products are needed.
2. **Differentiate the exponential using the chain rule.** With $u=2t$ and $u'=2$,

$$
\frac{d}{dt}e^{2t}=e^{2t}(2)=2e^{2t}.
$$

3. **Differentiate the logarithm.** For $t>0$, $\dfrac{d}{dt}\ln t=\dfrac1t$.
4. **Differentiate the trigonometric component.** The standard derivative identity gives $\dfrac{d}{dt}\tan t=\sec^2t$ wherever $\cos t\ne0$.
5. **Assemble the vector.** Therefore $\vec r\,'(t)=\langle2e^{2t},1/t,\sec^2t\rangle$. The derivative exists wherever the original function is defined: $t>0$ and $\cos t\ne0$.
:::
::::
::::problem[Problem 13.1.7 standard]{difficulty=standard}
Find the tangent line to $\vec{r}(t)=\langle t^2,t^3,t\rangle$ at $t=1$.

:::solution[Solution]
**Answer:** Line $\langle1+2s,1+3s,1+s\rangle$.

1. **Use the tangent-line formula.** A differentiable curve with $\vec r\,'(t_0)\ne\vec0$ has tangent line $\boldsymbol\ell(s)=\vec r(t_0)+s\vec r\,'(t_0)$, where $s$ is a new line parameter.
2. **Find the point at $t_0=1$.** Substitute into the position vector:

$$
\vec r(1)=\langle1^2,1^3,1\rangle=\langle1,1,1\rangle.
$$

3. **Find its tangent direction.** Differentiate coordinatewise and evaluate:

$$
\vec r\,'(t)=\langle2t,3t^2,1\rangle,\qquad \vec r\,'(1)=\langle2,3,1\rangle.
$$

4. **Write the line.** Add the point and a scalar multiple of the nonzero direction:

$$
\boldsymbol\ell(s)=\langle1,1,1\rangle+s\langle2,3,1\rangle=\langle1+2s,1+3s,1+s\rangle.
$$

   This line passes through the curve at $s=0$ and points along its instantaneous tangent.
:::
::::
::::problem[Problem 13.1.8 challenge]{difficulty=challenge}
Prove that if $|\vec{r}(t)|=c$ (constant), then $\vec{r}(t)\perp\vec{r}\,'(t)$ for all $t$.

:::solution[Solution]
**Answer:** $\mathbf r\cdot\mathbf r\prime=0$ if $|\mathbf r|$ is constant.

1. **State the assumption.** Assume $\vec r$ is differentiable and $|\vec r(t)|=c$, a constant, on the interval under consideration.
2. **Square the magnitude to remove the square root.** The identity $|\vec r|^2=\vec r\cdot\vec r$ yields

$$
\vec r(t)\cdot\vec r(t)=c^2.
$$

3. **Differentiate both sides.** Use the dot-product rule and the fact that the derivative of a constant is zero:

$$
\vec r\,'\cdot\vec r+\vec r\cdot\vec r\,'=0.
$$

4. **Simplify.** The dot product is commutative, so the left side equals $2\vec r\cdot\vec r\,'$. Divide by $2$ to obtain $\vec r\cdot\vec r\,'=0$.
5. **Interpret.** A zero dot product means $\vec r(t)$ and $\vec r\,'(t)$ are perpendicular whenever they are nonzero. If either is zero, the orthogonality equation still holds. This proves the claim.
:::
::::
::::problem[Problem 13.1.9 easy]{difficulty=easy}
Find the velocity and acceleration of $\vec{r}(t)=\langle e^t,\sin t,t^2\rangle$ at $t=0$.

:::solution[Solution]
**Answer:** $\mathbf v(0)=\langle1,1,0\rangle$, $\mathbf a(0)=\langle1,0,2\rangle$.

1. **Use the motion definitions.** Velocity is the derivative of position, $\vec v=\vec r\,'$, and acceleration is its derivative, $\vec a=\vec r\,''$.
2. **Differentiate position componentwise.** We use $(e^t)'=e^t$, $(\sin t)'=\cos t$, and $(t^2)'=2t$:

$$
\vec v(t)=\langle e^t,\cos t,2t\rangle.
$$

3. **Evaluate velocity at zero.** Since $e^0=1$, $\cos0=1$, and $2(0)=0$, we get $\vec v(0)=\langle1,1,0\rangle$.
4. **Differentiate velocity to get acceleration.** Componentwise,

$$
\vec a(t)=\langle e^t,-\sin t,2\rangle.
$$

5. **Evaluate acceleration at zero.** Use $e^0=1$ and $\sin0=0$: $\vec a(0)=\langle1,0,2\rangle$. Thus these are the instantaneous velocity and acceleration vectors at $t=0$.
:::
::::
::::problem[Problem 13.1.10 challenge]{difficulty=challenge}
A particle moves so that $|\vec{r}(t)|=1$ for all $t$ (it stays on the unit sphere). Show that at any instant its velocity is tangent to the sphere (i.e., perpendicular to $\vec{r}$).

:::solution[Solution]
**Answer:** $\mathbf r(t)\cdot\mathbf v(t)=0$ on the unit sphere.

1. **Translate the geometric condition.** Remaining on the unit sphere means $|\vec r(t)|=1$ for all $t$. Squaring gives the scalar identity $\vec r(t)\cdot\vec r(t)=1$.
2. **Differentiate the identity.** Assume the position is differentiable. The dot-product rule gives

$$
\vec r\,'(t)\cdot\vec r(t)+\vec r(t)\cdot\vec r\,'(t)=0.
$$

3. **Combine equal terms.** As $\vec v=\vec r\,'$ and dot products commute,

$$
2\vec r\cdot\vec v=0\quad\Longrightarrow\quad\vec r\cdot\vec v=0.
$$

4. **Connect to the tangent plane.** At a point of the unit sphere, the outward normal is the radius vector $\vec r$. Any vector perpendicular to this normal belongs to the tangent plane there.
5. **Conclude.** Since $\vec r\cdot\vec v=0$ at every time, the instantaneous velocity lies in the sphere's tangent plane, as required. This also holds at rest, when $\vec v=\vec0$.
:::
::::

### Young’s written-test layout: finite vector limits

Her released Test 3 begins with a **finite-parameter limit** containing several components. One may require L’Hôpital and the others may be direct substitution. Work **one component per line**. If a component is of the form $(t^2-t)/(4t^2-4)$ at $t=1$, direct substitution gives $0/0$, which is a reason to simplify or invoke L’Hôpital, not an answer. The derivative of its numerator is $2t-1$ and denominator $8t$, so the limit is $1/8$.

For tangent lines, Young writes the point $\mathbf r(t_0)$ and the direction $\mathbf v_T=\mathbf r'(t_0)$ before the three parametric equations. Be careful with two meanings of $t$: use the original curve parameter while finding $t_0$, then introduce a fresh line parameter $s$ to avoid accidentally using $t-t_0$ twice. Both $\mathbf r(t_0)+s\mathbf r'(t_0)$ and component equations $x=x_0+s v_1$, $y=y_0+s v_2$, $z=z_0+s v_3$ describe the same tangent line.

:::callout-tip[When a question asks for velocity, speed, and direction]
Differentiate first: $\mathbf v(t)=\mathbf r'(t)$. Substitute $t_0$ into all components. Speed is $|\mathbf v(t_0)|=\sqrt{v_1^2+v_2^2+v_3^2}$. Unit direction is $\mathbf v(t_0)/|\mathbf v(t_0)|$, and conversely velocity equals speed multiplied by unit direction. The last step normalizes; it does **not** differentiate again.
:::

:::example[Example 13.1.10 — Test 3 finite vector limit]
Find $\lim_{t\to1}\left\langle\frac{t^2-t}{4t^2-4},\ e^{t-1},\ \frac{\ln t}{t-1}\right\rangle$.

**Answer: $\left\langle\frac18,1,1\right\rangle$.**


**First component.** Numerator and denominator both tend to zero. Since they are differentiable near $1$, apply L’Hôpital:

$$
\lim_{t\to1}\frac{t^2-t}{4t^2-4}
=\lim_{t\to1}\frac{2t-1}{8t}
=\frac{2(1)-1}{8(1)}=\frac18.
$$
**Second component.** Exponential continuity gives $\lim_{t\to1}e^{t-1}=e^0=1$.

**Third component.** Again $0/0$: by L’Hôpital,

$$
\lim_{t\to1}\frac{\ln t}{t-1}
=\lim_{t\to1}\frac{1/t}{1}=1.
$$
Assemble the three component limits into $\langle1/8,1,1\rangle$. A vector limit exists only because all component limits exist.

:::

## 13.2 Integrals of Vector Functions; Projectile Motion

### Definite Integrals

:::definition
Definition 13.2.1 — Integral of a Vector Function

$$
\int_a^b\vec{r}(t)\,dt=\left\langle\int_a^b f(t)\,dt,\;\int_a^b g(t)\,dt,\;\int_a^b h(t)\,dt\right\rangle.
$$

 The antiderivative (indefinite integral) is computed the same way, adding a constant vector $\vec{C}$.
:::

The Fundamental Theorem of Calculus applies componentwise: if $\vec{R}(t)$ is an antiderivative of $\vec{r}(t)$, then $\int_a^b\vec{r}(t)\,dt=\vec{R}(b)-\vec{R}(a)$.

### Projectile Motion

**Not a standalone Test 3 graphing topic.** Projectile equations are useful for IVPs, but Young’s released Test 3 and hints concentrate on limits, tangents, integration, arc length, $T$, $N$, and $\kappa$.

A projectile launched with initial velocity $\vec{v}_0$ from position $\vec{r}_0$, subject only to gravity $\vec{a}=-g\hat{k}$ (taking upward as positive $z$):

$$
\vec{r}\,''=\langle 0,0,-g\rangle.
$$

 Integrating twice with initial conditions $\vec{r}\,'(0)=\vec{v}_0=\langle v_x,v_y,v_z\rangle$ and $\vec{r}(0)=\vec{r}_0$:

$$
\vec{r}(t)=\vec{r}_0+\vec{v}_0 t+\tfrac{1}{2}\langle 0,0,-g\rangle t^2.
$$

 In component form (launched from origin at angle $\theta$ in the $xz$-plane, speed $v_0$):

$$
x(t)=v_0\cos\theta\cdot t,\quad z(t)=v_0\sin\theta\cdot t-\tfrac{1}{2}gt^2.
$$

:::callout-key
Key projectile facts (from eliminating $t$):

- **Range:** $R=\dfrac{v_0^2\sin2\theta}{g}$ (maximized at $\theta=45°$)
- **Maximum height:** $H=\dfrac{v_0^2\sin^2\theta}{2g}$
- **Time of flight:** $T=\dfrac{2v_0\sin\theta}{g}$
:::

### Worked examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Equation sampled parabolic projectile trajectory">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M62.0 175.0 L63.0 173.3 L64.0 171.6 L65.0 169.9 L66.0 168.2 L66.9 166.6 L67.9 164.9 L68.9 163.3 L69.9 161.7 L70.9 160.1 L71.9 158.5 L72.9 156.9 L73.9 155.3 L74.9 153.7 L75.9 152.2 L76.8 150.7 L77.8 149.1 L78.8 147.6 L79.8 146.1 L80.8 144.6 L81.8 143.2 L82.8 141.7 L83.8 140.2 L84.8 138.8 L85.8 137.4 L86.7 136.0 L87.7 134.6 L88.7 133.2 L89.7 131.8 L90.7 130.4 L91.7 129.1 L92.7 127.7 L93.7 126.4 L94.7 125.1 L95.7 123.8 L96.6 122.5 L97.6 121.2 L98.6 120.0 L99.6 118.7 L100.6 117.5 L101.6 116.2 L102.6 115.0 L103.6 113.8 L104.6 112.6 L105.5 111.4 L106.5 110.3 L107.5 109.1 L108.5 108.0 L109.5 106.8 L110.5 105.7 L111.5 104.6 L112.5 103.5 L113.5 102.4 L114.5 101.3 L115.4 100.3 L116.4 99.2 L117.4 98.2 L118.4 97.2 L119.4 96.2 L120.4 95.2 L121.4 94.2 L122.4 93.2 L123.4 92.2 L124.4 91.3 L125.3 90.4 L126.3 89.4 L127.3 88.5 L128.3 87.6 L129.3 86.7 L130.3 85.9 L131.3 85.0 L132.3 84.1 L133.3 83.3 L134.3 82.5 L135.2 81.7 L136.2 80.9 L137.2 80.1 L138.2 79.3 L139.2 78.5 L140.2 77.8 L141.2 77.0 L142.2 76.3 L143.2 75.6 L144.1 74.9 L145.1 74.2 L146.1 73.5 L147.1 72.9 L148.1 72.2 L149.1 71.6 L150.1 70.9 L151.1 70.3 L152.1 69.7 L153.1 69.1 L154.0 68.5 L155.0 68.0 L156.0 67.4 L157.0 66.9 L158.0 66.3 L159.0 65.8 L160.0 65.3 L161.0 64.8 L162.0 64.3 L163.0 63.8 L163.9 63.4 L164.9 62.9 L165.9 62.5 L166.9 62.1 L167.9 61.7 L168.9 61.3 L169.9 60.9 L170.9 60.5 L171.9 60.1 L172.9 59.8 L173.8 59.5 L174.8 59.1 L175.8 58.8 L176.8 58.5 L177.8 58.2 L178.8 58.0 L179.8 57.7 L180.8 57.4 L181.8 57.2 L182.7 57.0 L183.7 56.8 L184.7 56.6 L185.7 56.4 L186.7 56.2 L187.7 56.0 L188.7 55.9 L189.7 55.7 L190.7 55.6 L191.7 55.5 L192.6 55.4 L193.6 55.3 L194.6 55.2 L195.6 55.2 L196.6 55.1 L197.6 55.1 L198.6 55.0 L199.6 55.0 L200.6 55.0 L201.6 55.0 L202.5 55.0 L203.5 55.1 L204.5 55.1 L205.5 55.2 L206.5 55.2 L207.5 55.3 L208.5 55.4 L209.5 55.5 L210.5 55.6 L211.5 55.7 L212.4 55.9 L213.4 56.0 L214.4 56.2 L215.4 56.4 L216.4 56.6 L217.4 56.8 L218.4 57.0 L219.4 57.2 L220.4 57.4 L221.3 57.7 L222.3 58.0 L223.3 58.2 L224.3 58.5 L225.3 58.8 L226.3 59.1 L227.3 59.5 L228.3 59.8 L229.3 60.1 L230.3 60.5 L231.2 60.9 L232.2 61.3 L233.2 61.7 L234.2 62.1 L235.2 62.5 L236.2 62.9 L237.2 63.4 L238.2 63.8 L239.2 64.3 L240.2 64.8 L241.1 65.3 L242.1 65.8 L243.1 66.3 L244.1 66.9 L245.1 67.4 L246.1 68.0 L247.1 68.5 L248.1 69.1 L249.1 69.7 L250.1 70.3 L251.0 70.9 L252.0 71.6 L253.0 72.2 L254.0 72.9 L255.0 73.5 L256.0 74.2 L257.0 74.9 L258.0 75.6 L259.0 76.3 L259.9 77.0 L260.9 77.8 L261.9 78.5 L262.9 79.3 L263.9 80.1 L264.9 80.9 L265.9 81.7 L266.9 82.5 L267.9 83.3 L268.9 84.1 L269.8 85.0 L270.8 85.9 L271.8 86.7 L272.8 87.6 L273.8 88.5 L274.8 89.4 L275.8 90.4 L276.8 91.3 L277.8 92.2 L278.8 93.2 L279.7 94.2 L280.7 95.2 L281.7 96.2 L282.7 97.2 L283.7 98.2 L284.7 99.2 L285.7 100.3 L286.7 101.3 L287.7 102.4 L288.7 103.5 L289.6 104.6 L290.6 105.7 L291.6 106.8 L292.6 108.0 L293.6 109.1 L294.6 110.3 L295.6 111.4 L296.6 112.6 L297.6 113.8 L298.5 115.0 L299.5 116.2 L300.5 117.5 L301.5 118.7 L302.5 120.0 L303.5 121.2 L304.5 122.5 L305.5 123.8 L306.5 125.1 L307.5 126.4 L308.4 127.7 L309.4 129.1 L310.4 130.4 L311.4 131.8 L312.4 133.2 L313.4 134.6 L314.4 136.0 L315.4 137.4 L316.4 138.8 L317.4 140.2 L318.3 141.7 L319.3 143.2 L320.3 144.6 L321.3 146.1 L322.3 147.6 L323.3 149.1 L324.3 150.7 L325.3 152.2 L326.3 153.7 L327.3 155.3 L328.2 156.9 L329.2 158.5 L330.2 160.1 L331.2 161.7 L332.2 163.3 L333.2 164.9 L334.2 166.6 L335.2 168.2 L336.2 169.9 L337.1 171.6 L338.1 173.3 L339.1 175.0"/>

</svg>
<figcaption>For $x(t)=10t$ and $z(t)=10\sqrt3t-5t^2$, horizontal travel continues while vertical velocity becomes zero at the peak.</figcaption>
</figure>


:::example[Example 13.2.1 — Integrating a Vector Function]

**Answer: $\displaystyle\int_0^1\vec{r}\,dt=\left\langle\frac{1}{2},\frac{1}{3},1-\cos 1\right\rangle$.**

Compute $\displaystyle\int_0^1\langle t,t^2,\sin t\rangle\,dt$.

**Solution.** Integrate each component:

$$
\int_0^1 t\,dt=\frac{1}{2},\quad\int_0^1 t^2\,dt=\frac{1}{3},\quad\int_0^1\sin t\,dt=[-\cos t]_0^1=1-\cos 1.
$$

 Answer: $\left\langle\dfrac{1}{2},\dfrac{1}{3},1-\cos 1\right\rangle$.
:::

:::example[Example 13.2.2 — Recovering Position from Velocity]

**Answer: $\vec{r}(t)=\langle e^t,\,t^2+1,\,-\cos t+2\rangle$.**

A particle has velocity $\vec{v}(t)=\langle e^t,2t,\sin t\rangle$ and initial position $\vec{r}(0)=\langle 1,1,1\rangle$. Find $\vec{r}(t)$.

**Solution.** Integrate $\vec{v}(t)$:

$$
\vec{r}(t)=\langle e^t+C_1,\;t^2+C_2,\;-\cos t+C_3\rangle.
$$

 Apply $\vec{r}(0)=\langle 1,1,1\rangle$:

$$
e^0+C_1=1\Rightarrow C_1=0;\qquad 0+C_2=1\Rightarrow C_2=1;\qquad -1+C_3=1\Rightarrow C_3=2.
$$

$$
\vec{r}(t)=\langle e^t,\;t^2+1,\;-\cos t+2\rangle.
$$
:::

:::example[Example 13.2.3 — Projectile Range]

**Answer: $R=\frac{3125\sqrt3}{98}\approx55.2$ m; maximum height $H=\frac{3125}{392}\approx7.97$ m.**

A ball is launched at $30°$ above the horizontal with initial speed $25$ m/s. Using $g=9.8$ m/s², find the range and maximum height.

**Solution.**

$$
v_x=25\cos30°=25\cdot\frac{\sqrt{3}}{2}\approx21.65\;\text{m/s},\quad v_z=25\sin30°=12.5\;\text{m/s}.
$$

 Time of flight:

$$
T=\frac{2v_z}{g}=\frac{2(12.5)}{9.8}\approx2.551\;\text{s}.
$$

 Range:

$$
R=v_x\cdot T\approx21.65\times2.551\approx55.2\;\text{m}.
$$

 Maximum height:

$$
H=\frac{v_z^2}{2g}=\frac{156.25}{19.6}\approx7.97\;\text{m}.
$$

 (Or use formula: $R=v_0^2\sin60°/g=625\cdot(\sqrt{3}/2)/9.8\approx55.2$ m.)
:::

:::example[Example 13.2.4 — Recovering Position from Acceleration]

**Answer: $\vec{r}(t)=\langle t^2+2t,\;\frac{1}{2}t^2-t,\;-\frac{1}{2}t^2+4t\rangle$.**

A particle has acceleration $\vec{a}(t)=\langle 2,1,-1\rangle$ (constant), initial velocity $\vec{v}(0)=\langle 2,-1,4\rangle$, and initial position $\vec{r}(0)=\langle 0,0,0\rangle$. Find $\vec{r}(t)$.

**Solution.** Integrate once:

$$
\vec{v}(t)=\langle 2t+C_1,t+C_2,-t+C_3\rangle.
$$

 Apply $\vec{v}(0)=\langle 2,-1,4\rangle$: $C_1=2,C_2=-1,C_3=4$. So $\vec{v}(t)=\langle 2t+2,t-1,-t+4\rangle$.
 Integrate again:

$$
\vec{r}(t)=\langle t^2+2t+D_1,\;\tfrac{1}{2}t^2-t+D_2,\;-\tfrac{1}{2}t^2+4t+D_3\rangle.
$$

 Apply $\vec{r}(0)=\vec{0}$: all $D_i=0$.

$$
\vec{r}(t)=\langle t^2+2t,\;\tfrac{1}{2}t^2-t,\;-\tfrac{1}{2}t^2+4t\rangle.
$$
:::

:::callout-pitfall
Watch out for:

- **Order in the cross product rule.** $\frac{d}{dt}[\vec{u}\times\vec{v}]=\vec{u}'\times\vec{v}+\vec{u}\times\vec{v}'$. Do NOT rearrange the order inside each cross product — the cross product is anti-commutative.
- **The constant of integration is a vector.** When integrating, add $\vec{C}=\langle C_1,C_2,C_3\rangle$, not a scalar. Use initial conditions to solve for all three constants.
- **Smooth vs. not smooth.** The curve is smooth at $t_0$ only if $\vec{r}\,'(t_0)\ne\vec{0}$. If the derivative is zero, the curve may have a cusp and the tangent vector is undefined there.
:::

### Practice problems

::::problem[Problem 13.2.1 easy]{difficulty=easy}
Compute $\displaystyle\int_0^\pi\langle\cos t,\sin t,t\rangle\,dt$.

:::solution[Solution]
**Answer:** $\langle0,2,\pi^2/2\rangle$.

1. **Use componentwise integration.** A definite integral of a vector function is the vector of the definite integrals of its components. All three components are continuous on $[0,\pi]$, so the integral exists.
2. **Integrate each scalar component:**

$$
\int\cos t\,dt=\sin t,\qquad\int\sin t\,dt=-\cos t,\qquad\int t\,dt=\frac{t^2}{2}.
$$

3. **Apply the same endpoints to each component:**

$$
\int_0^\pi\langle\cos t,\sin t,t\rangle\,dt
=\left\langle[\sin t]_0^\pi,[-\cos t]_0^\pi,\left[\frac{t^2}{2}\right]_0^\pi\right\rangle.
$$

4. **Subtract endpoint values.** The entries become $\sin\pi-\sin0=0$, $-\cos\pi+\cos0=1+1=2$, and $\pi^2/2-0=\pi^2/2$.
5. **Conclude.** The integral is the vector $\langle0,2,\pi^2/2\rangle$.
:::
::::
::::problem[Problem 13.2.2 standard]{difficulty=standard}
Find $\vec{r}(t)$ given $\vec{r}\,''(t)=\langle 0,0,-g\rangle$ (constant gravitational acceleration), $\vec{r}\,'(0)=\langle v_0,0,0\rangle$, and $\vec{r}(0)=\langle 0,0,h\rangle$.

:::solution[Solution]
**Answer:** $\langle v_0t,0,h-gt^2/2\rangle$.

1. **Integrate acceleration to get velocity.** Because $\vec r\,''=\langle0,0,-g\rangle$ with constant $g$, integrate componentwise:

$$
\vec r\,'(t)=\langle C_1,C_2,-gt+C_3\rangle.
$$

2. **Apply the initial velocity.** At $t=0$, the expression equals $\langle C_1,C_2,C_3\rangle$. Match this to $\langle v_0,0,0\rangle$, obtaining $C_1=v_0$, $C_2=C_3=0$.
3. **Integrate again for position:**

$$
\vec r(t)=\left\langle v_0t+D_1,D_2,-\frac{gt^2}{2}+D_3\right\rangle.
$$

4. **Apply the initial position.** Substitution of $t=0$ yields $\langle D_1,D_2,D_3\rangle=\langle0,0,h\rangle$. Therefore $D_1=D_2=0$, $D_3=h$.
5. **Conclude and check.** The path is $\langle v_0t,0,h-gt^2/2\rangle$; its second derivative recovers $\langle0,0,-g\rangle$, and both initial conditions hold. This is horizontal launch motion.
:::
::::
::::problem[Problem 13.2.3 standard]{difficulty=standard}
A projectile is fired at $45°$ with speed $40$ m/s. Find: (a) range, (b) maximum height, (c) speed when it hits the ground. Use $g=10$ m/s².

:::solution[Solution]
**Answer:** Range $160$ m, height $40$ m, landing speed $40$ m/s.

1. **Resolve the initial velocity.** With $v_0=40$, $\theta=45^\circ$, and $g=10$,

$$
v_{0x}=40\cos45^\circ=20\sqrt2,\qquad v_{0z}=40\sin45^\circ=20\sqrt2.
$$

2. **Write the motion equations.** From ground level, $x(t)=20\sqrt2\,t$ and $z(t)=20\sqrt2\,t-5t^2$. This assumes no air resistance and landing at launch height.
3. **Find flight time and range.** Set $z(t)=t(20\sqrt2-5t)=0$. The positive landing time is $t=4\sqrt2$ s. Thus

$$
R=x(4\sqrt2)=20\sqrt2(4\sqrt2)=160\text{ m}.
$$

4. **Find maximum height.** Vertical velocity is $v_z=20\sqrt2-10t$, which vanishes at $t=2\sqrt2$. Substitute into $z$:

$$
H=20\sqrt2(2\sqrt2)-5(2\sqrt2)^2=80-40=40\text{ m}.
$$

5. **Find impact speed.** At $t=4\sqrt2$, velocity is $\langle20\sqrt2,-20\sqrt2\rangle$. Its magnitude is $\sqrt{800+800}=40$ m/s. These are the requested range, height, and landing speed.
:::
::::
::::problem[Problem 13.2.4 standard]{difficulty=standard}
Find $\vec{r}(t)$ if $\vec{a}(t)=\langle\cos t,\sin t,0\rangle$, $\vec{v}(0)=\langle0,1,0\rangle$, $\vec{r}(0)=\langle1,0,0\rangle$.

:::solution[Solution]
**Answer:** $\langle2-\cos t,2t-\sin t,0\rangle$.

1. **Integrate acceleration for velocity.** Since $\vec a(t)=\langle\cos t,\sin t,0\rangle$,

$$
\vec v(t)=\langle\sin t+C_1,-\cos t+C_2,C_3\rangle.
$$

2. **Determine the velocity constants.** At $t=0$, $\vec v(0)=\langle C_1,-1+C_2,C_3\rangle=\langle0,1,0\rangle$. So $C_1=0$, $C_2=2$, $C_3=0$, giving $\vec v(t)=\langle\sin t,2-\cos t,0\rangle$.
3. **Integrate velocity for position:**

$$
\vec r(t)=\langle-\cos t+D_1,2t-\sin t+D_2,D_3\rangle.
$$

4. **Use the position initial condition.** At $t=0$, this becomes $\langle-1+D_1,D_2,D_3\rangle=\langle1,0,0\rangle$. Thus $D_1=2$, $D_2=0$, $D_3=0$.
5. **Verify.** Differentiating $\langle2-\cos t,2t-\sin t,0\rangle$ twice gives $\langle\cos t,\sin t,0\rangle$, and both initial vectors match. The displayed position is the unique solution.
:::
::::

### Integration problems are three independent one-variable problems

Write the integrated vector with a **constant vector**, not a single scalar $+C$. If $\mathbf r'(t)=\langle f(t),g(t),h(t)\rangle$, then $\mathbf r(t)=\langle\int f,\int g,\int h\rangle+\langle C_1,C_2,C_3\rangle$. Apply the supplied initial position **component by component**. When acceleration is specified instead, integrate twice, using initial velocity to find the first constant vector and initial position to find the second. Forgetting the first constant before the second integration erases a linear term in the final position.

The allowable tools from Young’s hints are ordinary powers, chain rule, derivatives of sine/cosine, exponentials, and basic u-substitution. Keep your work no-calculator friendly. For instance, $\int -\cos(3t)\,dt=-\frac13\sin(3t)$ because differentiating $\sin(3t)$ introduces the factor 3. The same chain-rule reversal gives $\int-e^{-t}\,dt=e^{-t}$. These are more likely on Test 3 than difficult integration by parts or inverse-trigonometric derivatives.

### A definite vector integral has no constants of integration

For a **definite** vector integral, integrate every component and subtract lower-endpoint values from upper-endpoint values. A single constant vector is unnecessary because the constants cancel in $F(b)-F(a)$. Keep separate brackets for each component when evaluating a nonzero lower endpoint. For an **indefinite** integral or IVP, include constants.

:::callout-pitfall[Vector IVP grading traps]
Do not use the initial position to determine a velocity constant after integrating acceleration: the first condition is $\mathbf v(t_0)$, then the second is $\mathbf r(t_0)$. Do not change $-\cos(3t)$ to $-\sin(3t)$ without dividing by 3. Finally, check by differentiating the completed $\mathbf r(t)$ back to the supplied differential equation.
:::

:::example[Example 13.2.5 — Released-key style first-order IVP]
Solve $\mathbf r^{\prime}(t)=\langle t^3,-\cos(3t),-e^{-t}\rangle$ with $\mathbf r(0)=\langle2,7,-5\rangle$.

**Answer: $\mathbf r(t)=\left\langle\frac{t^4}4+2,\ 7-\frac{\sin3t}3,\ e^{-t}-6\right\rangle$.**


Integrate each component, including a vector constant:

$$\mathbf r(t)=\left\langle\frac{t^4}4,-\frac{\sin3t}3,e^{-t}\right\rangle+\langle C_1,C_2,C_3\rangle.$$

The derivatives verify the antiderivatives: $(t^4/4)'=t^3$, $[-\sin(3t)/3]'=-\cos3t$, and $(e^{-t})'=-e^{-t}$. At $t=0$, the nonconstant part equals $\langle0,0,1\rangle$. Thus

$$\langle0,0,1\rangle+\langle C_1,C_2,C_3\rangle=\langle2,7,-5\rangle$$

so $C_1=2$, $C_2=7$, and $C_3=-6$. Substitute the constants into the integrated expression and box the whole vector, not just one component.

:::

:::example[Example 13.2.6 — Two integrations and two initial conditions]
Given $\mathbf r^{\prime\prime}(t)=\langle6t,2,-4\rangle$, $\mathbf r^{\prime}(0)=\langle1,-2,3\rangle$, and $\mathbf r(0)=\langle4,0,-1\rangle$, find $\mathbf r(t)$.

**Answer: $\mathbf r(t)=\langle t^3+t+4,\ t^2-2t,\ -2t^2+3t-1\rangle$.**


First integrate acceleration:

$$\mathbf r'(t)=\langle3t^2,2t,-4t\rangle+\langle A,B,C\rangle.$$

At $t=0$, $\langle A,B,C\rangle=\langle1,-2,3\rangle$. Therefore $\mathbf r'(t)=\langle3t^2+1,2t-2,-4t+3\rangle$.

Integrate **again**:

$$\mathbf r(t)=\langle t^3+t,t^2-2t,-2t^2+3t\rangle+\langle D,E,F\rangle.$$

The initial position gives $(D,E,F)=(4,0,-1)$. Inserting them produces the stated vector. Differentiating twice reproduces $\langle6t,2,-4\rangle$, which checks the entire answer.

:::

::::problem[Problem 13.2.5 — Written-test first-order IVP]{difficulty=standard}
Solve $\mathbf r^{\prime}(t)=\langle2t,\sin t,3e^t\rangle$ with $\mathbf r(0)=\langle1,2,0\rangle$.

:::solution[Solution]
**Answer:** $\mathbf r(t)=\langle t^2+1,3-\cos t,3e^t-3\rangle$.

1. **Use a first-order vector initial-value problem.** Integrate each component of $\mathbf r'(t)=\langle2t,\sin t,3e^t\rangle$; every component is continuous, so ordinary antiderivatives apply.
2. **Integrate componentwise, retaining three constants:**

$$
\mathbf r(t)=\langle t^2+C_1,-\cos t+C_2,3e^t+C_3\rangle.
$$

3. **Apply the initial position.** At $t=0$, $t^2=0$, $\cos0=1$, and $e^0=1$, giving

$$
\langle C_1,-1+C_2,3+C_3\rangle=\langle1,2,0\rangle.
$$

4. **Solve the three scalar equations.** $C_1=1$, $-1+C_2=2\Rightarrow C_2=3$, and $3+C_3=0\Rightarrow C_3=-3$.
5. **Check the result.** The derivative of $\langle t^2+1,3-\cos t,3e^t-3\rangle$ is $\langle2t,\sin t,3e^t\rangle$, and its value at zero is $\langle1,2,0\rangle$. Therefore it satisfies both requirements.
:::
::::

::::problem[Problem 13.2.6 — Definite vector integral]{difficulty=easy}
Compute $\int_0^2\langle3t^2,2t,\cos t\rangle\,dt$.

:::solution[Solution]
**Answer:** $\langle8,4,\sin2\rangle$.

1. **Apply the componentwise vector integral rule.** All components $3t^2$, $2t$, and $\cos t$ are continuous on $[0,2]$, so integrate each separately.
2. **Find antiderivatives using the power and trig rules:**

$$
\int3t^2\,dt=t^3,\qquad\int2t\,dt=t^2,\qquad\int\cos t\,dt=\sin t.
$$

3. **Build the vector antiderivative:**

$$
\mathbf F(t)=\langle t^3,t^2,\sin t\rangle.
$$

4. **Apply the Fundamental Theorem of Calculus componentwise.** Evaluate the upper endpoint and subtract the lower:

$$
\mathbf F(2)-\mathbf F(0)=\langle 2^3,2^2,\sin2\rangle-\langle0^3,0^2,\sin0\rangle.
$$

5. **Simplify each entry.** Since $2^3=8$, $2^2=4$, and $\sin0=0$, the definite vector integral equals $\langle8,4,\sin2\rangle$. No arbitrary constant remains in a definite integral.
:::
::::

### Turn an initial-value problem into three scalar equations

When Young gives $\mathbf r'(t)=\mathbf v(t)$ and one initial position, integrate each component *once* and carry three constants. If the equation gives $\mathbf r''(t)=\mathbf a(t)$, integrate *twice*: first to find velocity, then position. You need enough initial conditions to determine all constants. One initial position alone is not enough for an acceleration problem; an initial velocity or an equivalent condition is also needed.

For instance, suppose $\mathbf a(t)=\langle2,\,6t,\,e^t\rangle$, $\mathbf v(0)=\langle1,-2,3\rangle$, and $\mathbf r(0)=\langle0,4,-1\rangle$. A first antiderivative has the form

$$
\mathbf v(t)=\langle2t+C_1,3t^2+C_2,e^t+C_3\rangle.
$$

Substituting $t=0$ gives $C_1=1$, $C_2=-2$, and $1+C_3=3$, so $C_3=2$. Integrate again:

$$
\mathbf r(t)=\left\langle t^2+t+D_1,\ t^3-2t+D_2,\ e^t+2t+D_3\right\rangle.
$$

Now the position condition gives $D_1=0$, $D_2=4$, and $1+D_3=-1$, hence $D_3=-2$. Verify by differentiating twice and substituting both initial values. This backwards check catches a wrong integration constant with minimal additional writing.

### Integral signs, bounds, and componentwise substitution

A vector integral is a **vector**, not the scalar magnitude of the components. Thus $\int\langle f,g,h\rangle\,dt=\langle\int f\,dt,\int g\,dt,\int h\,dt\rangle+\mathbf C$. By contrast, $\int|\mathbf r'(t)|dt$ is scalar arc length and belongs to the next section. When definite bounds appear, integrate each component using those same bounds; the constants cancel and there is no $\mathbf C$ in the final definite integral.

On Young's written test, a component may require substitution. For $\int 2t\cos(t^2)\,dt$, let $u=t^2$ and $du=2t\,dt$; the integral is $\sin(t^2)+C$. But if this component sits beside $\int e^t dt$, do not use the same substitution on the exponential component. Each component is its own one-variable calculus problem. Write the vector with its three evaluated entries only after completing all three scalar calculations.

A useful dimensional check: a velocity vector has units of distance per time, and integrating with respect to time yields distance. Integrating acceleration once yields velocity. If the answer to a position IVP still contains an indefinite integral or unfixed constants, the problem is unfinished.


## 13.3 Arc Length in Space

:::callout-connect
📺 Watch before this section

“Arc length of a curve” — Khan Academy

“Curvature of a helix | Multivariable Calculus” — Khan Academy
:::

:::callout-intuition
Intuition first.

How long is a curve? How sharply does it bend? These are the two questions §13.3 and §13.4 answer. Arc length is the natural generalization of Calc II arc length for 2D curves — you still integrate $|\vec{r}\,'|$. Curvature is the new and deeper idea: it measures how rapidly the direction of the curve is changing per unit of arc length traveled. A straight line has zero curvature; a tight circle has large curvature. To make curvature independent of how fast a particle traverses the curve, you need the unit tangent vector $\hat{T}$ and the concept of arc-length parametrization. The reward at the end of §13.4 is the

TNB frame

— three mutually orthogonal unit vectors that provide a moving coordinate system perfectly adapted to the curve.
:::

### Arc Length

:::theorem[Theorem 13.3.1 — Arc Length Formula]
The arc length of the curve $\vec{r}(t)=\langle f(t),g(t),h(t)\rangle$, $a\le t\le b$, is

$$
L=\int_a^b|\vec{r}\,'(t)|\,dt=\int_a^b\sqrt{[f'(t)]^2+[g'(t)]^2+[h'(t)]^2}\,dt.
$$
:::

The **arc length function** from a base point $t=a$ is

$$
s(t)=\int_a^t|\vec{r}\,'(u)|\,du.
$$

 By the Fundamental Theorem, $ds/dt=|\vec{r}\,'(t)|$. Rearranging: $ds=|\vec{r}\,'(t)|\,dt$. This is the arc-length element.

### Worked examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Equation sampled parabola arc compared with its straight chord">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M80.0 185.0 L80.3 185.0 L80.7 185.0 L81.0 185.0 L81.4 185.0 L81.7 185.0 L82.1 184.9 L82.4 184.9 L82.7 184.9 L83.1 184.8 L83.4 184.8 L83.8 184.8 L84.1 184.7 L84.5 184.7 L84.8 184.6 L85.1 184.6 L85.5 184.5 L85.8 184.4 L86.2 184.4 L86.5 184.3 L86.9 184.2 L87.2 184.1 L87.5 184.1 L87.9 184.0 L88.2 183.9 L88.6 183.8 L88.9 183.7 L89.3 183.6 L89.6 183.5 L89.9 183.4 L90.3 183.2 L90.6 183.1 L91.0 183.0 L91.3 182.9 L91.7 182.7 L92.0 182.6 L92.3 182.5 L92.7 182.3 L93.0 182.2 L93.4 182.0 L93.7 181.9 L94.1 181.7 L94.4 181.5 L94.7 181.4 L95.1 181.2 L95.4 181.0 L95.8 180.9 L96.1 180.7 L96.5 180.5 L96.8 180.3 L97.1 180.1 L97.5 179.9 L97.8 179.7 L98.2 179.5 L98.5 179.3 L98.9 179.1 L99.2 178.9 L99.5 178.6 L99.9 178.4 L100.2 178.2 L100.6 177.9 L100.9 177.7 L101.3 177.5 L101.6 177.2 L101.9 177.0 L102.3 176.7 L102.6 176.5 L103.0 176.2 L103.3 175.9 L103.7 175.7 L104.0 175.4 L104.3 175.1 L104.7 174.8 L105.0 174.6 L105.4 174.3 L105.7 174.0 L106.1 173.7 L106.4 173.4 L106.7 173.1 L107.1 172.8 L107.4 172.5 L107.8 172.1 L108.1 171.8 L108.5 171.5 L108.8 171.2 L109.1 170.8 L109.5 170.5 L109.8 170.2 L110.2 169.8 L110.5 169.5 L110.9 169.1 L111.2 168.8 L111.5 168.4 L111.9 168.1 L112.2 167.7 L112.6 167.3 L112.9 166.9 L113.3 166.6 L113.6 166.2 L113.9 165.8 L114.3 165.4 L114.6 165.0 L115.0 164.6 L115.3 164.2 L115.7 163.8 L116.0 163.4 L116.3 163.0 L116.7 162.6 L117.0 162.1 L117.4 161.7 L117.7 161.3 L118.1 160.9 L118.4 160.4 L118.7 160.0 L119.1 159.5 L119.4 159.1 L119.8 158.6 L120.1 158.2 L120.5 157.7 L120.8 157.3 L121.1 156.8 L121.5 156.3 L121.8 155.8 L122.2 155.4 L122.5 154.9 L122.9 154.4 L123.2 153.9 L123.5 153.4 L123.9 152.9 L124.2 152.4 L124.6 151.9 L124.9 151.4 L125.3 150.9 L125.6 150.3 L125.9 149.8 L126.3 149.3 L126.6 148.8 L127.0 148.2 L127.3 147.7 L127.7 147.1 L128.0 146.6 L128.3 146.0 L128.7 145.5 L129.0 144.9 L129.4 144.4 L129.7 143.8 L130.1 143.2 L130.4 142.7 L130.7 142.1 L131.1 141.5 L131.4 140.9 L131.8 140.3 L132.1 139.7 L132.5 139.1 L132.8 138.5 L133.1 137.9 L133.5 137.3 L133.8 136.7 L134.2 136.1 L134.5 135.5 L134.9 134.8 L135.2 134.2 L135.5 133.6 L135.9 132.9 L136.2 132.3 L136.6 131.7 L136.9 131.0 L137.3 130.4 L137.6 129.7 L137.9 129.0 L138.3 128.4 L138.6 127.7 L139.0 127.0 L139.3 126.4 L139.7 125.7 L140.0 125.0 L140.3 124.3 L140.7 123.6 L141.0 122.9 L141.4 122.2 L141.7 121.5 L142.1 120.8 L142.4 120.1 L142.7 119.4 L143.1 118.7 L143.4 117.9 L143.8 117.2 L144.1 116.5 L144.5 115.8 L144.8 115.0 L145.1 114.3 L145.5 113.5 L145.8 112.8 L146.2 112.0 L146.5 111.3 L146.9 110.5 L147.2 109.7 L147.5 109.0 L147.9 108.2 L148.2 107.4 L148.6 106.6 L148.9 105.8 L149.3 105.1 L149.6 104.3 L149.9 103.5 L150.3 102.7 L150.6 101.9 L151.0 101.1 L151.3 100.2 L151.7 99.4 L152.0 98.6 L152.3 97.8 L152.7 96.9 L153.0 96.1 L153.4 95.3 L153.7 94.4 L154.1 93.6 L154.4 92.7 L154.7 91.9 L155.1 91.0 L155.4 90.2 L155.8 89.3 L156.1 88.4 L156.5 87.6 L156.8 86.7 L157.1 85.8 L157.5 84.9 L157.8 84.0 L158.2 83.2 L158.5 82.3 L158.9 81.4 L159.2 80.5 L159.5 79.5 L159.9 78.6 L160.2 77.7 L160.6 76.8 L160.9 75.9 L161.3 75.0 L161.6 74.0 L161.9 73.1 L162.3 72.2 L162.6 71.2 L163.0 70.3 L163.3 69.3 L163.7 68.4 L164.0 67.4 L164.3 66.4 L164.7 65.5 L165.0 64.5 L165.4 63.5 L165.7 62.6 L166.1 61.6 L166.4 60.6 L166.7 59.6 L167.1 58.6 L167.4 57.6 L167.8 56.6 L168.1 55.6 L168.5 54.6 L168.8 53.6 L169.1 52.6 L169.5 51.5 L169.8 50.5 L170.2 49.5 L170.5 48.5 L170.9 47.4 L171.2 46.4 L171.5 45.3 L171.9 44.3 L172.2 43.2 L172.6 42.2 L172.9 41.1 L173.3 40.1 L173.6 39.0 L173.9 37.9 L174.3 36.8 L174.6 35.8 L175.0 34.7 L175.3 33.6 L175.7 32.5 L176.0 31.4"/>
<path class="fig-guide" d="M80.0 185.0 L80.3 184.5 L80.7 183.9 L81.0 183.4 L81.4 182.8 L81.7 182.3 L82.1 181.7 L82.4 181.2 L82.7 180.6 L83.1 180.1 L83.4 179.5 L83.8 179.0 L84.1 178.4 L84.5 177.9 L84.8 177.3 L85.1 176.8 L85.5 176.2 L85.8 175.7 L86.2 175.1 L86.5 174.6 L86.9 174.0 L87.2 173.5 L87.5 172.9 L87.9 172.4 L88.2 171.8 L88.6 171.3 L88.9 170.7 L89.3 170.2 L89.6 169.6 L89.9 169.1 L90.3 168.5 L90.6 168.0 L91.0 167.4 L91.3 166.9 L91.7 166.3 L92.0 165.8 L92.3 165.3 L92.7 164.7 L93.0 164.2 L93.4 163.6 L93.7 163.1 L94.1 162.5 L94.4 162.0 L94.7 161.4 L95.1 160.9 L95.4 160.3 L95.8 159.8 L96.1 159.2 L96.5 158.7 L96.8 158.1 L97.1 157.6 L97.5 157.0 L97.8 156.5 L98.2 155.9 L98.5 155.4 L98.9 154.8 L99.2 154.3 L99.5 153.7 L99.9 153.2 L100.2 152.6 L100.6 152.1 L100.9 151.5 L101.3 151.0 L101.6 150.4 L101.9 149.9 L102.3 149.3 L102.6 148.8 L103.0 148.2 L103.3 147.7 L103.7 147.1 L104.0 146.6 L104.3 146.1 L104.7 145.5 L105.0 145.0 L105.4 144.4 L105.7 143.9 L106.1 143.3 L106.4 142.8 L106.7 142.2 L107.1 141.7 L107.4 141.1 L107.8 140.6 L108.1 140.0 L108.5 139.5 L108.8 138.9 L109.1 138.4 L109.5 137.8 L109.8 137.3 L110.2 136.7 L110.5 136.2 L110.9 135.6 L111.2 135.1 L111.5 134.5 L111.9 134.0 L112.2 133.4 L112.6 132.9 L112.9 132.3 L113.3 131.8 L113.6 131.2 L113.9 130.7 L114.3 130.1 L114.6 129.6 L115.0 129.0 L115.3 128.5 L115.7 127.9 L116.0 127.4 L116.3 126.9 L116.7 126.3 L117.0 125.8 L117.4 125.2 L117.7 124.7 L118.1 124.1 L118.4 123.6 L118.7 123.0 L119.1 122.5 L119.4 121.9 L119.8 121.4 L120.1 120.8 L120.5 120.3 L120.8 119.7 L121.1 119.2 L121.5 118.6 L121.8 118.1 L122.2 117.5 L122.5 117.0 L122.9 116.4 L123.2 115.9 L123.5 115.3 L123.9 114.8 L124.2 114.2 L124.6 113.7 L124.9 113.1 L125.3 112.6 L125.6 112.0 L125.9 111.5 L126.3 110.9 L126.6 110.4 L127.0 109.8 L127.3 109.3 L127.7 108.7 L128.0 108.2 L128.3 107.7 L128.7 107.1 L129.0 106.6 L129.4 106.0 L129.7 105.5 L130.1 104.9 L130.4 104.4 L130.7 103.8 L131.1 103.3 L131.4 102.7 L131.8 102.2 L132.1 101.6 L132.5 101.1 L132.8 100.5 L133.1 100.0 L133.5 99.4 L133.8 98.9 L134.2 98.3 L134.5 97.8 L134.9 97.2 L135.2 96.7 L135.5 96.1 L135.9 95.6 L136.2 95.0 L136.6 94.5 L136.9 93.9 L137.3 93.4 L137.6 92.8 L137.9 92.3 L138.3 91.7 L138.6 91.2 L139.0 90.6 L139.3 90.1 L139.7 89.5 L140.0 89.0 L140.3 88.5 L140.7 87.9 L141.0 87.4 L141.4 86.8 L141.7 86.3 L142.1 85.7 L142.4 85.2 L142.7 84.6 L143.1 84.1 L143.4 83.5 L143.8 83.0 L144.1 82.4 L144.5 81.9 L144.8 81.3 L145.1 80.8 L145.5 80.2 L145.8 79.7 L146.2 79.1 L146.5 78.6 L146.9 78.0 L147.2 77.5 L147.5 76.9 L147.9 76.4 L148.2 75.8 L148.6 75.3 L148.9 74.7 L149.3 74.2 L149.6 73.6 L149.9 73.1 L150.3 72.5 L150.6 72.0 L151.0 71.4 L151.3 70.9 L151.7 70.3 L152.0 69.8 L152.3 69.3 L152.7 68.7 L153.0 68.2 L153.4 67.6 L153.7 67.1 L154.1 66.5 L154.4 66.0 L154.7 65.4 L155.1 64.9 L155.4 64.3 L155.8 63.8 L156.1 63.2 L156.5 62.7 L156.8 62.1 L157.1 61.6 L157.5 61.0 L157.8 60.5 L158.2 59.9 L158.5 59.4 L158.9 58.8 L159.2 58.3 L159.5 57.7 L159.9 57.2 L160.2 56.6 L160.6 56.1 L160.9 55.5 L161.3 55.0 L161.6 54.4 L161.9 53.9 L162.3 53.3 L162.6 52.8 L163.0 52.2 L163.3 51.7 L163.7 51.1 L164.0 50.6 L164.3 50.1 L164.7 49.5 L165.0 49.0 L165.4 48.4 L165.7 47.9 L166.1 47.3 L166.4 46.8 L166.7 46.2 L167.1 45.7 L167.4 45.1 L167.8 44.6 L168.1 44.0 L168.5 43.5 L168.8 42.9 L169.1 42.4 L169.5 41.8 L169.8 41.3 L170.2 40.7 L170.5 40.2 L170.9 39.6 L171.2 39.1 L171.5 38.5 L171.9 38.0 L172.2 37.4 L172.6 36.9 L172.9 36.3 L173.3 35.8 L173.6 35.2 L173.9 34.7 L174.3 34.1 L174.6 33.6 L175.0 33.0 L175.3 32.5 L175.7 31.9 L176.0 31.4"/>

</svg>
<figcaption>Arc length follows the curve, not the straight chord: integrate $|\mathbf r\'(t)|$ rather than using endpoint distance.</figcaption>
</figure>


:::example[Example 13.3.1 — Arc Length of a Helix]

**Answer: $L=2\pi\sqrt{2}$.**

Find the arc length of $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$ for $0\le t\le 2\pi$.

**Solution.**

$$
\vec{r}\,'(t)=\langle-\sin t,\cos t,1\rangle,\qquad|\vec{r}\,'(t)|=\sqrt{\sin^2 t+\cos^2 t+1}=\sqrt{2}.
$$

 Since $|\vec{r}\,'(t)|$ is constant:

$$
L=\int_0^{2\pi}\sqrt{2}\,dt=2\pi\sqrt{2}.
$$

 The helix has the same length as a diagonal of a $2\pi\times2\pi$ rectangle — you can unroll it into a straight line.
:::

### Practice problems

::::problem[Problem 13.3.1 easy]{difficulty=easy}
Find the arc length of $\vec{r}(t)=\langle 3t,4t,0\rangle$ for $0\le t\le2$.

:::solution[Solution]
**Answer:** $L=10$.

1. **Use the space-curve arc-length formula.** For a continuously differentiable vector path, the distance traveled on $a\le t\le b$ is $L=\int_a^b|\vec r\,'(t)|\,dt$. The given polynomial path meets the differentiability condition on $[0,2]$.
2. **Differentiate each component:**

$$
\vec r\,'(t)=\langle3,4,0\rangle.
$$

3. **Find its magnitude, which is the speed:**

$$
|\vec r\,'(t)|=\sqrt{3^2+4^2+0^2}=\sqrt{9+16}=5.
$$

4. **Integrate the constant speed over the interval:**

$$
L=\int_0^2 5\,dt=[5t]_0^2=5(2)-5(0)=10.
$$

5. **Conclude and check geometrically.** The endpoints are $\vec r(0)=\langle0,0,0\rangle$ and $\vec r(2)=\langle6,8,0\rangle$. Their straight-line distance is $\sqrt{6^2+8^2}=10$, as expected for a straight path with no reversal.
:::
::::
::::problem[Problem 13.3.2 standard]{difficulty=standard}
Find the arc length of $\vec{r}(t)=\langle t^2,\frac{2}{3}t^3,t\rangle$ for $0\le t\le1$.

:::solution[Solution]
**Answer:** $L=5/3$.

1. **Use the arc-length formula** $L=\int_0^1|\vec r\,'(t)|\,dt$. The component polynomials are continuously differentiable on $[0,1]$.
2. **Differentiate each component:**

$$
\vec r\,'(t)=\left\langle 2t,2t^2,1\right\rangle.
$$

3. **Compute speed by taking the vector magnitude:**

$$
|\vec r\,'|=\sqrt{(2t)^2+(2t^2)^2+1^2}=\sqrt{4t^2+4t^4+1}.
$$

4. **Recognize a perfect square.** Reorder the radicand as $4t^4+4t^2+1=(2t^2+1)^2$. Thus the speed is $|2t^2+1|=2t^2+1$, since this expression is positive for every real $t$.
5. **Integrate exactly:**

$$
L=\int_0^1(2t^2+1)\,dt=\left[\frac{2t^3}{3}+t\right]_0^1=\frac23+1=\frac53.
$$

   Therefore the arc length over the stated interval is $5/3$.
:::
::::

### Why arc length uses speed and not displacement

The vector $\mathbf r(b)-\mathbf r(a)$ measures displacement between the endpoints. Its magnitude is the straight-line distance between them, which generally **underestimates** the distance traveled along a bending curve. Cut the parameter interval into tiny pieces: over a small increment $\Delta t$, the displacement is approximately $\mathbf r'(t)\Delta t$, so the length of that piece is approximately $|\mathbf r'(t)|\Delta t$. Add the pieces and take the limiting sum. This gives $L=\int_a^b|\mathbf r'(t)|dt$. The norm is outside the derivative and inside the integral.

The sequence of operations matters: compute $\mathbf r'$, square its components, add, take the square root, then integrate. Do not integrate $\mathbf r$ first or use the length of $\int\mathbf r'$. Square roots are where hand algebra earns most points. Look for a common square factor; for example $\sqrt{64t^2+144t^4}=4|t|\sqrt{4+9t^2}$. On an interval $0\le t\le1$, $|t|=t$. If the interval crosses zero, however, dropping absolute values would be wrong and you would need to split the integral.

:::theorem[Arc length of a regular space curve]
For a continuously differentiable curve $\mathbf r(t)=\langle x(t),y(t),z(t)\rangle$ on $[a,b]$, the length traveled is

$$
L=\int_a^b\sqrt{(x'(t))^2+(y'(t))^2+(z'(t))^2}\,dt
=\int_a^b|\mathbf r'(t)|\,dt.
$$
The formula remains valid for piecewise continuously differentiable curves, summing the lengths of the pieces.
:::

### Recognize a perfect square before choosing a substitution

Sometimes $|\mathbf r'|=\sqrt{1+4t^2+4t^4}$. Rather than attempting a difficult antiderivative, factor it as $\sqrt{(1+2t^2)^2}$. Because $1+2t^2>0$, this is just $1+2t^2$; the integral becomes a polynomial. Other times the speed takes the form $4t\sqrt{4+9t^2}$: then $u=4+9t^2$ has $du=18t\,dt$, and the outside factor $t$ matches perfectly. Both patterns are represented in Young’s released test.

### Keep the bounds attached to the variable

For a definite integral with $u=g(t)$, compute $u(a)$ and $u(b)$. After substitution the integral is in $u$, so keep the new $u$ bounds. For $u=4+9t^2$ on $0\le t\le1$, the new bounds are $4$ and $13$. Writing $[u^{3/2}]_0^1$ would be mixing the old bounds with the new variable, which gives a wrong answer even if the antiderivative was right.

:::callout-pitfall[What not to do in arc-length work]
$\sqrt{A+B}$ cannot be split into $\sqrt A+\sqrt B$. When factoring $\sqrt{t^2}$, write $|t|$ unless the interval establishes $t\ge0$. A displacement vector is not arc length. The norm $|\mathbf r'|$ is nonnegative, so the final length must be nonnegative too.
:::

:::example[Example 13.3.2 — Young Test 3 arc length u-sub]
Find the length of $\mathbf r(t)=\langle4t^2,9,4t^3\rangle$ for $0\le t\le1$.

**Answer: $L=\frac4{27}(13\sqrt{13}-8)$.**


Differentiate each coordinate:

$$\mathbf r'(t)=\langle8t,0,12t^2\rangle.$$

Compute speed and factor the square root:

$$
\begin{aligned}
|\mathbf r'(t)|&=\sqrt{(8t)^2+0^2+(12t^2)^2}\\
&=\sqrt{64t^2+144t^4}\\
&=\sqrt{16t^2(4+9t^2)}\\
&=4|t|\sqrt{4+9t^2}=4t\sqrt{4+9t^2}.
\end{aligned}
$$
The last equality uses $t\ge0$ on the specified interval. Now

$$L=\int_0^1 4t\sqrt{4+9t^2}\,dt.$$

Let $u=4+9t^2$; then $du=18t\,dt$ and $4t\,dt=(2/9)du$. At $t=0$, $u=4$; at $t=1$, $u=13$:

$$
\begin{aligned}
L&=\frac29\int_4^{13}u^{1/2}\,du
=\frac29\left[\frac{u^{3/2}}{3/2}\right]_4^{13}\\
&=\frac29\cdot\frac23\,[u^{3/2}]_4^{13}\\
&=\frac4{27}(13^{3/2}-4^{3/2})\\
&=\frac4{27}(13\sqrt{13}-8).
\end{aligned}
$$
This is an exact no-calculator answer. The original constant $y=9$ contributes derivative zero; it does not disappear from the curve, only from its speed.

:::

:::example[Example 13.3.3 — Perfect-square speed]
Find the length of $\mathbf r(t)=\langle t^2,\frac23t^3,t\rangle$ for $0\le t\le2$.

**Answer: $L=\frac{22}{3}$.**


Differentiate: $\mathbf r'(t)=\langle2t,2t^2,1\rangle$. Then

$$|\mathbf r'(t)|=\sqrt{4t^2+4t^4+1}=\sqrt{(2t^2+1)^2}=2t^2+1,$$

since $2t^2+1>0$ for every real $t$. Integrate directly:

$$
L=\int_0^2(2t^2+1)\,dt
=\left[\frac{2t^3}{3}+t\right]_0^2
=\frac{2\cdot8}{3}+2
=\frac{16+6}{3}=\frac{22}{3}.
$$
:::

::::problem[Problem 13.3.3 — U-sub arc length]{difficulty=standard}
Find $L$ for $\mathbf r(t)=\langle3t^2,0,2t^3\rangle$ on $0\le t\le1$.

:::solution[Solution]
**Answer:** $L=2(2\sqrt2-1)$.

1. **Use the arc-length integral.** The path is smooth on $[0,1]$, so $L=\int_0^1|\mathbf r'(t)|\,dt$.
2. **Differentiate and simplify the speed:**

$$
\mathbf r'(t)=\langle6t,0,6t^2\rangle,\quad |\mathbf r'|=\sqrt{36t^2+36t^4}=6|t|\sqrt{1+t^2}.
$$

   Since $0\le t\le1$, replace $|t|$ by $t$.
3. **Set up the integral and substitute.** Use $u=1+t^2$, so $du=2t\,dt$ and $6t\,dt=3du$. The limits change from $t=0,1$ to $u=1,2$:

$$
L=\int_0^1 6t\sqrt{1+t^2}\,dt=3\int_1^2 u^{1/2}\,du.
$$

4. **Integrate and apply the bounds:**

$$
L=3\left[\frac23u^{3/2}\right]_1^2=2(2^{3/2}-1)=2(2\sqrt2-1).
$$

5. **Conclude.** The exact arc length is $2(2\sqrt2-1)$; the coefficient is $3(2/3)=2$.
:::
::::

::::problem[Problem 13.3.4 — Three-component perfect square]{difficulty=standard}
Find the length of $\mathbf r(t)=\langle t,t^2,\frac23t^3\rangle$ on $0\le t\le1$.

:::solution[Solution]
**Answer:** $L=\frac53$.

1. **Apply the arc-length formula.** A polynomial vector function is continuously differentiable, so on $[0,1]$ its length is $L=\int_0^1|\mathbf r'(t)|\,dt$.
2. **Differentiate all three coordinates:**

$$
\mathbf r'(t)=\left\langle1,2t,2t^2\right\rangle.
$$

3. **Calculate the speed:**

$$
|\mathbf r'(t)|=\sqrt{1^2+(2t)^2+(2t^2)^2}=\sqrt{1+4t^2+4t^4}.
$$

4. **Factor the radicand.** Since $1+4t^2+4t^4=(1+2t^2)^2$, the square root is $|1+2t^2|=1+2t^2$. We can remove the absolute value because $t^2\ge0$.
5. **Integrate using the power rule:**

$$
L=\int_0^1(1+2t^2)\,dt=\left[t+\frac{2t^3}{3}\right]_0^1=1+\frac23=\frac53.
$$

   Therefore the length of the given space curve is $5/3$.
:::
::::

::::problem[Problem 13.3.5 — Straight path]{difficulty=easy}
Compute the length of $\mathbf r(t)=\langle2t,3t,6t\rangle$ from $t=1$ to $t=3$.

:::solution[Solution]
**Answer:** $L=14$.

1. **Use the arc-length formula.** Because $\mathbf r(t)$ is differentiable on $[1,3]$, $L=\int_1^3|\mathbf r'(t)|\,dt$.
2. **Find velocity by differentiating each component:**

$$
\mathbf r'(t)=\langle2,3,6\rangle.
$$

3. **Compute its constant magnitude:**

$$
|\mathbf r'(t)|=\sqrt{2^2+3^2+6^2}=\sqrt{4+9+36}=\sqrt{49}=7.
$$

4. **Integrate speed across the parameter interval:**

$$
L=\int_1^3 7\,dt=[7t]_1^3=21-7=14.
$$

5. **Check using endpoint distance.** Since the path is a straight line moving in one direction, its length equals the separation of the endpoints. Those endpoints are $\langle2,3,6\rangle$ and $\langle6,9,18\rangle$. Their difference is $\langle4,6,12\rangle$, with magnitude $\sqrt{16+36+144}=\sqrt{196}=14$. Thus $L=14$.
:::
::::

::::problem[Problem 13.3.6 — Parameter interval crossing zero]{difficulty=challenge}
Find the arc length of $\mathbf r(t)=\langle t^2,0,0\rangle$ for $-1\le t\le1$.

:::solution[Solution]
**Answer:** $L=2$.

1. **Apply the arc-length formula.** The continuously differentiable curve has length $L=\int_{-1}^{1}|\mathbf r'(t)|\,dt$.
2. **Differentiate and keep the absolute value:**

$$
\mathbf r'(t)=\langle2t,0,0\rangle,\qquad |\mathbf r'(t)|=\sqrt{4t^2}=2|t|.
$$

3. **Split the integral where $t$ changes sign.** On $[-1,0]$, $|t|=-t$; on $[0,1]$, $|t|=t$. Hence

$$
L=\int_{-1}^0(-2t)\,dt+\int_0^1(2t)\,dt.
$$

4. **Integrate each piece:**

$$
L=[-t^2]_{-1}^{0}+[t^2]_0^1=(0-(-1))+(1-0)=2.
$$

5. **Explain the result.** The particle starts at $x=1$, moves to $x=0$ at $t=0$, and returns to $x=1$. Its net displacement is zero, but its total distance traveled is $1+1=2$. This confirms the arc length $L=2$.
:::
::::

### The speed must come from the derivative of the curve

Arc length measures total distance **along** the path. Displacement measures only the straight-line separation of its endpoints. On any curved segment, distance traveled cannot be smaller than the magnitude of displacement. That inequality is a quick way to catch a missing square root or a missing factor in a proposed arc-length answer. The defining formula is $L=\int_a^b|\mathbf r'(t)|\,dt$, and the speed is $|\mathbf r'(t)|=\sqrt{(x')^2+(y')^2+(z')^2}$.

On a written solution, differentiate first and list all three components. Square them explicitly before combining them. If the speed contains sine and cosine, look for $\sin^2t+\cos^2t=1$, the one trig identity Young says to know. If there is a common factor, pull out that factor **before** hunting for a substitution. For example, a velocity with components $\langle2t,2t^2,1\rangle$ gives speed $\sqrt{4t^2+4t^4+1}$, which is not automatically a perfect square. You must inspect and factor the *actual* radicand rather than force a desired pattern.

A perfect-square pattern often looks like $(t^2+1)^2=t^4+2t^2+1$ or $(2t^2+1)^2=4t^4+4t^2+1$. The second pattern has coefficients $4,4,1$, not $4,2,1$. The distinction is precisely why writing the middle term matters. When $|\mathbf v(t)|=\sqrt{(2t^2+1)^2}$, the square root is $|2t^2+1|=2t^2+1$ because that expression is positive for real $t$. That last sign check is part of the simplification.

### Why the substitution changes the bounds

Young's review hints that a Test 3 arc length needs a $u$-substitution. Suppose your simplified speed is $6t\sqrt{1+3t^2}$ on $0\le t\le1$. Set $u=1+3t^2$. Then $du=6t\,dt$. When $t=0$, $u=1$; when $t=1$, $u=4$. Therefore the definite integral becomes

$$
\int_0^1 6t\sqrt{1+3t^2}\,dt
=\int_1^4u^{1/2}\,du
=\left[\frac23u^{3/2}\right]_1^4
=\frac23(8-1)=\frac{14}{3}.
$$

Every operation has a job: the derivative creates the speed, algebra exposes the square or common factor, substitution gives a recognizable integral, and changed bounds make evaluation direct. If you instead keep the old $t$ bounds after substituting $u$, the calculation is invalid even if the antiderivative is correct. You may keep the original bounds only when you **substitute back to $t$ before applying them**.

A final paper check distinguishes parameter intervals from curve geometry. Reparameterizing the same segment at a different speed changes the component derivatives, but the total length must remain the same. This is why the formula uses speed times parameter change and not just the difference between the parameter endpoints.

### Two ways to check an arc-length result

First compare the length with the endpoint displacement. For a curve $\mathbf r(t)$ on $[a,b]$, its displacement is $\mathbf r(b)-\mathbf r(a)$, and its straight-line distance is $|\mathbf r(b)-\mathbf r(a)|$. The computed arc length must be at least that large. Equality occurs for a straight segment traced without reversing direction. If your curved-path answer is smaller, inspect the derivative, the square root, and the bounds.

Second use a simple special case as a benchmark. If $\mathbf r(t)=\langle 3t,4t,0\rangle$ for $0\le t\le2$, then $\mathbf r'(t)=\langle3,4,0\rangle$, speed is $\sqrt{3^2+4^2}=5$, and length is $\int_0^2 5\,dt=10$. The displacement is $\langle6,8,0\rangle$ with magnitude $10$, matching the line segment. If you accidentally integrated $|\mathbf r(t)|$ rather than $|\mathbf r'(t)|$, you would get a different number and fail this basic check.

Finally, distinguish absolute values from parentheses after removing a perfect square: $\sqrt{g(t)^2}=|g(t)|$ universally, not just $g(t)$. If your interval crosses a root of $g$, split the integral into pieces at that root before removing the absolute value. Young’s examples are selected to simplify, but that simplification must still be justified rather than assumed.


## 13.4 Curvature and Normal Vectors of a Curve

### The Unit Tangent Vector and Curvature

:::definition
Definition 13.4.1 — Curvature

The **curvature** $\kappa$ (Greek letter kappa) of a smooth curve measures how fast the unit tangent vector turns per unit arc length:

$$
\kappa=\left|\frac{d\hat{T}}{ds}\right|.
$$

 In terms of $t$ (more computable):

$$
\kappa=\frac{|\hat{T}'(t)|}{|\vec{r}\,'(t)|}=\frac{|\vec{r}\,'(t)\times\vec{r}\,''(t)|}{|\vec{r}\,'(t)|^3}.
$$

 For a plane curve $y=f(x)$:

$$
\kappa=\frac{|f''(x)|}{[1+(f'(x))^2]^{3/2}}.
$$
:::

Memorize the cross-product formula — it's the most useful computational form and it's the one that appears most on exams.

### The TNB Frame

At each point of a smooth space curve, three mutually perpendicular unit vectors form a natural moving frame:

:::definition
Definition 13.4.2 — Frenet-Serret Frame (TNB)

$$
\hat{T}(t)=\frac{\vec{r}\,'(t)}{|\vec{r}\,'(t)|}\quad\text{(unit tangent)}
$$

$$
\hat{N}(t)=\frac{\hat{T}'(t)}{|\hat{T}'(t)|}\quad\text{(unit normal — points toward center of curvature)}
$$

$$
\hat{B}(t)=\hat{T}(t)\times\hat{N}(t)\quad\text{(unit binormal)}
$$
:::

The normal vector $\hat{N}$ always points toward the center of the osculating circle (the circle that best fits the curve at that point). The binormal $\hat{B}$ is perpendicular to both $\hat{T}$ and $\hat{N}$, completing the right-handed frame. The plane spanned by $\hat{T}$ and $\hat{N}$ is the **osculating plane**.

:::callout-key
Osculating circle.

The circle of curvature (osculating circle) at a point has radius $R=1/\kappa$ (the radius of curvature) and its center lies along $\hat{N}$ at distance $R$ from the curve. A tight bend = large $\kappa$ = small $R$; a gentle bend = small $\kappa$ = large $R$.
:::

### Worked examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Unit tangent points upward and normal points inward on circle">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M257.0 119.0 L257.0 117.6 L256.9 116.2 L256.9 114.8 L256.7 113.4 L256.6 111.9 L256.4 110.5 L256.2 109.1 L256.0 107.8 L255.7 106.4 L255.4 105.0 L255.1 103.6 L254.7 102.2 L254.3 100.9 L253.9 99.5 L253.5 98.2 L253.0 96.9 L252.5 95.5 L251.9 94.2 L251.4 92.9 L250.8 91.7 L250.1 90.4 L249.5 89.1 L248.8 87.9 L248.1 86.7 L247.3 85.5 L246.6 84.3 L245.8 83.1 L245.0 82.0 L244.1 80.8 L243.3 79.7 L242.4 78.6 L241.4 77.5 L240.5 76.5 L239.5 75.5 L238.5 74.5 L237.5 73.5 L236.5 72.5 L235.5 71.6 L234.4 70.6 L233.3 69.7 L232.2 68.9 L231.0 68.0 L229.9 67.2 L228.7 66.4 L227.5 65.7 L226.3 64.9 L225.1 64.2 L223.9 63.5 L222.6 62.9 L221.3 62.2 L220.1 61.6 L218.8 61.1 L217.5 60.5 L216.1 60.0 L214.8 59.5 L213.5 59.1 L212.1 58.7 L210.8 58.3 L209.4 57.9 L208.0 57.6 L206.6 57.3 L205.2 57.0 L203.9 56.8 L202.5 56.6 L201.1 56.4 L199.6 56.3 L198.2 56.1 L196.8 56.1 L195.4 56.0 L194.0 56.0 L192.6 56.0 L191.2 56.1 L189.8 56.1 L188.4 56.3 L186.9 56.4 L185.5 56.6 L184.1 56.8 L182.8 57.0 L181.4 57.3 L180.0 57.6 L178.6 57.9 L177.2 58.3 L175.9 58.7 L174.5 59.1 L173.2 59.5 L171.9 60.0 L170.5 60.5 L169.2 61.1 L167.9 61.6 L166.7 62.2 L165.4 62.9 L164.1 63.5 L162.9 64.2 L161.7 64.9 L160.5 65.7 L159.3 66.4 L158.1 67.2 L157.0 68.0 L155.8 68.9 L154.7 69.7 L153.6 70.6 L152.5 71.6 L151.5 72.5 L150.5 73.5 L149.5 74.5 L148.5 75.5 L147.5 76.5 L146.6 77.5 L145.6 78.6 L144.7 79.7 L143.9 80.8 L143.0 82.0 L142.2 83.1 L141.4 84.3 L140.7 85.5 L139.9 86.7 L139.2 87.9 L138.5 89.1 L137.9 90.4 L137.2 91.7 L136.6 92.9 L136.1 94.2 L135.5 95.5 L135.0 96.9 L134.5 98.2 L134.1 99.5 L133.7 100.9 L133.3 102.2 L132.9 103.6 L132.6 105.0 L132.3 106.4 L132.0 107.8 L131.8 109.1 L131.6 110.5 L131.4 111.9 L131.3 113.4 L131.1 114.8 L131.1 116.2 L131.0 117.6 L131.0 119.0 L131.0 120.4 L131.1 121.8 L131.1 123.2 L131.3 124.6 L131.4 126.1 L131.6 127.5 L131.8 128.9 L132.0 130.2 L132.3 131.6 L132.6 133.0 L132.9 134.4 L133.3 135.8 L133.7 137.1 L134.1 138.5 L134.5 139.8 L135.0 141.1 L135.5 142.5 L136.1 143.8 L136.6 145.1 L137.2 146.3 L137.9 147.6 L138.5 148.9 L139.2 150.1 L139.9 151.3 L140.7 152.5 L141.4 153.7 L142.2 154.9 L143.0 156.0 L143.9 157.2 L144.7 158.3 L145.6 159.4 L146.6 160.5 L147.5 161.5 L148.5 162.5 L149.5 163.5 L150.5 164.5 L151.5 165.5 L152.5 166.4 L153.6 167.4 L154.7 168.3 L155.8 169.1 L157.0 170.0 L158.1 170.8 L159.3 171.6 L160.5 172.3 L161.7 173.1 L162.9 173.8 L164.1 174.5 L165.4 175.1 L166.7 175.8 L167.9 176.4 L169.2 176.9 L170.5 177.5 L171.9 178.0 L173.2 178.5 L174.5 178.9 L175.9 179.3 L177.2 179.7 L178.6 180.1 L180.0 180.4 L181.4 180.7 L182.8 181.0 L184.1 181.2 L185.5 181.4 L186.9 181.6 L188.4 181.7 L189.8 181.9 L191.2 181.9 L192.6 182.0 L194.0 182.0 L195.4 182.0 L196.8 181.9 L198.2 181.9 L199.6 181.7 L201.1 181.6 L202.5 181.4 L203.9 181.2 L205.2 181.0 L206.6 180.7 L208.0 180.4 L209.4 180.1 L210.8 179.7 L212.1 179.3 L213.5 178.9 L214.8 178.5 L216.1 178.0 L217.5 177.5 L218.8 176.9 L220.1 176.4 L221.3 175.8 L222.6 175.1 L223.9 174.5 L225.1 173.8 L226.3 173.1 L227.5 172.3 L228.7 171.6 L229.9 170.8 L231.0 170.0 L232.2 169.1 L233.3 168.3 L234.4 167.4 L235.5 166.4 L236.5 165.5 L237.5 164.5 L238.5 163.5 L239.5 162.5 L240.5 161.5 L241.4 160.5 L242.4 159.4 L243.3 158.3 L244.1 157.2 L245.0 156.0 L245.8 154.9 L246.6 153.7 L247.3 152.5 L248.1 151.3 L248.8 150.1 L249.5 148.9 L250.1 147.6 L250.8 146.3 L251.4 145.1 L251.9 143.8 L252.5 142.5 L253.0 141.1 L253.5 139.8 L253.9 138.5 L254.3 137.1 L254.7 135.8 L255.1 134.4 L255.4 133.0 L255.7 131.6 L256.0 130.2 L256.2 128.9 L256.4 127.5 L256.6 126.1 L256.7 124.6 L256.9 123.2 L256.9 121.8 L257.0 120.4 L257.0 119.0"/>
<path class="fig-arrow" d="M 257 119 L 257 57"/>
<path class="fig-arrow" d="M 257 119 L 194 119"/>
<path class="fig-point" d="M 257 119 l 0.1 0"/>
<text class="fig-label" x="263" y="62">T</text><text class="fig-label" x="220" y="111">N</text>
</svg>
<figcaption>At each regular point the unit tangent $\mathbf T$ points along motion, while $\mathbf N$ points toward the direction in which the tangent turns.</figcaption>
</figure>


<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 400 225" width="400" height="225" role="img" aria-label="Equation sampled circles with different radii">
<path class="fig-axis" d="M 35 190 L 380 190 M 70 205 L 70 15"/>
<path class="fig-curve" d="M195.0 125.0 L195.0 123.5 L194.9 122.1 L194.9 120.6 L194.7 119.2 L194.6 117.7 L194.4 116.3 L194.2 114.8 L194.0 113.4 L193.7 112.0 L193.4 110.5 L193.0 109.1 L192.7 107.7 L192.3 106.3 L191.8 104.9 L191.4 103.5 L190.9 102.2 L190.3 100.8 L189.8 99.5 L189.2 98.1 L188.6 96.8 L187.9 95.5 L187.2 94.2 L186.5 92.9 L185.8 91.7 L185.0 90.4 L184.2 89.2 L183.4 88.0 L182.6 86.8 L181.7 85.6 L180.8 84.5 L179.9 83.3 L178.9 82.2 L178.0 81.1 L177.0 80.1 L176.0 79.0 L174.9 78.0 L173.9 77.0 L172.8 76.1 L171.7 75.1 L170.5 74.2 L169.4 73.3 L168.2 72.4 L167.0 71.6 L165.8 70.8 L164.6 70.0 L163.3 69.2 L162.1 68.5 L160.8 67.8 L159.5 67.1 L158.2 66.4 L156.9 65.8 L155.5 65.2 L154.2 64.7 L152.8 64.1 L151.5 63.6 L150.1 63.2 L148.7 62.7 L147.3 62.3 L145.9 62.0 L144.5 61.6 L143.0 61.3 L141.6 61.0 L140.2 60.8 L138.7 60.6 L137.3 60.4 L135.8 60.3 L134.4 60.1 L132.9 60.1 L131.5 60.0 L130.0 60.0 L128.5 60.0 L127.1 60.1 L125.6 60.1 L124.2 60.3 L122.7 60.4 L121.3 60.6 L119.8 60.8 L118.4 61.0 L117.0 61.3 L115.5 61.6 L114.1 62.0 L112.7 62.3 L111.3 62.7 L109.9 63.2 L108.5 63.6 L107.2 64.1 L105.8 64.7 L104.5 65.2 L103.1 65.8 L101.8 66.4 L100.5 67.1 L99.2 67.8 L97.9 68.5 L96.7 69.2 L95.4 70.0 L94.2 70.8 L93.0 71.6 L91.8 72.4 L90.6 73.3 L89.5 74.2 L88.3 75.1 L87.2 76.1 L86.1 77.0 L85.1 78.0 L84.0 79.0 L83.0 80.1 L82.0 81.1 L81.1 82.2 L80.1 83.3 L79.2 84.5 L78.3 85.6 L77.4 86.8 L76.6 88.0 L75.8 89.2 L75.0 90.4 L74.2 91.7 L73.5 92.9 L72.8 94.2 L72.1 95.5 L71.4 96.8 L70.8 98.1 L70.2 99.5 L69.7 100.8 L69.1 102.2 L68.6 103.5 L68.2 104.9 L67.7 106.3 L67.3 107.7 L67.0 109.1 L66.6 110.5 L66.3 112.0 L66.0 113.4 L65.8 114.8 L65.6 116.3 L65.4 117.7 L65.3 119.2 L65.1 120.6 L65.1 122.1 L65.0 123.5 L65.0 125.0 L65.0 126.5 L65.1 127.9 L65.1 129.4 L65.3 130.8 L65.4 132.3 L65.6 133.7 L65.8 135.2 L66.0 136.6 L66.3 138.0 L66.6 139.5 L67.0 140.9 L67.3 142.3 L67.7 143.7 L68.2 145.1 L68.6 146.5 L69.1 147.8 L69.7 149.2 L70.2 150.5 L70.8 151.9 L71.4 153.2 L72.1 154.5 L72.8 155.8 L73.5 157.1 L74.2 158.3 L75.0 159.6 L75.8 160.8 L76.6 162.0 L77.4 163.2 L78.3 164.4 L79.2 165.5 L80.1 166.7 L81.1 167.8 L82.0 168.9 L83.0 169.9 L84.0 171.0 L85.1 172.0 L86.1 173.0 L87.2 173.9 L88.3 174.9 L89.5 175.8 L90.6 176.7 L91.8 177.6 L93.0 178.4 L94.2 179.2 L95.4 180.0 L96.7 180.8 L97.9 181.5 L99.2 182.2 L100.5 182.9 L101.8 183.6 L103.1 184.2 L104.5 184.8 L105.8 185.3 L107.2 185.9 L108.5 186.4 L109.9 186.8 L111.3 187.3 L112.7 187.7 L114.1 188.0 L115.5 188.4 L117.0 188.7 L118.4 189.0 L119.8 189.2 L121.3 189.4 L122.7 189.6 L124.2 189.7 L125.6 189.9 L127.1 189.9 L128.5 190.0 L130.0 190.0 L131.5 190.0 L132.9 189.9 L134.4 189.9 L135.8 189.7 L137.3 189.6 L138.7 189.4 L140.2 189.2 L141.6 189.0 L143.0 188.7 L144.5 188.4 L145.9 188.0 L147.3 187.7 L148.7 187.3 L150.1 186.8 L151.5 186.4 L152.8 185.9 L154.2 185.3 L155.5 184.8 L156.9 184.2 L158.2 183.6 L159.5 182.9 L160.8 182.2 L162.1 181.5 L163.3 180.8 L164.6 180.0 L165.8 179.2 L167.0 178.4 L168.2 177.6 L169.4 176.7 L170.5 175.8 L171.7 174.9 L172.8 173.9 L173.9 173.0 L174.9 172.0 L176.0 171.0 L177.0 169.9 L178.0 168.9 L178.9 167.8 L179.9 166.7 L180.8 165.5 L181.7 164.4 L182.6 163.2 L183.4 162.0 L184.2 160.8 L185.0 159.6 L185.8 158.3 L186.5 157.1 L187.2 155.8 L187.9 154.5 L188.6 153.2 L189.2 151.9 L189.8 150.5 L190.3 149.2 L190.9 147.8 L191.4 146.5 L191.8 145.1 L192.3 143.7 L192.7 142.3 L193.0 140.9 L193.4 139.5 L193.7 138.0 L194.0 136.6 L194.2 135.2 L194.4 133.7 L194.6 132.3 L194.7 130.8 L194.9 129.4 L194.9 127.9 L195.0 126.5 L195.0 125.0"/>
<path class="fig-curve-alt" d="M340.0 125.0 L340.0 124.4 L340.0 123.9 L339.9 123.3 L339.9 122.8 L339.8 122.2 L339.8 121.6 L339.7 121.1 L339.6 120.5 L339.5 120.0 L339.4 119.4 L339.2 118.9 L339.1 118.3 L338.9 117.8 L338.8 117.3 L338.6 116.7 L338.4 116.2 L338.2 115.7 L338.0 115.2 L337.8 114.7 L337.5 114.2 L337.3 113.7 L337.0 113.2 L336.7 112.7 L336.5 112.2 L336.2 111.7 L335.9 111.2 L335.6 110.8 L335.2 110.3 L334.9 109.9 L334.5 109.4 L334.2 109.0 L333.8 108.6 L333.5 108.1 L333.1 107.7 L332.7 107.3 L332.3 106.9 L331.9 106.5 L331.4 106.2 L331.0 105.8 L330.6 105.5 L330.1 105.1 L329.7 104.8 L329.2 104.4 L328.8 104.1 L328.3 103.8 L327.8 103.5 L327.3 103.3 L326.8 103.0 L326.3 102.7 L325.8 102.5 L325.3 102.2 L324.8 102.0 L324.3 101.8 L323.8 101.6 L323.3 101.4 L322.7 101.2 L322.2 101.1 L321.7 100.9 L321.1 100.8 L320.6 100.6 L320.0 100.5 L319.5 100.4 L318.9 100.3 L318.4 100.2 L317.8 100.2 L317.2 100.1 L316.7 100.1 L316.1 100.0 L315.6 100.0 L315.0 100.0 L314.4 100.0 L313.9 100.0 L313.3 100.1 L312.8 100.1 L312.2 100.2 L311.6 100.2 L311.1 100.3 L310.5 100.4 L310.0 100.5 L309.4 100.6 L308.9 100.8 L308.3 100.9 L307.8 101.1 L307.3 101.2 L306.7 101.4 L306.2 101.6 L305.7 101.8 L305.2 102.0 L304.7 102.2 L304.2 102.5 L303.7 102.7 L303.2 103.0 L302.7 103.3 L302.2 103.5 L301.7 103.8 L301.2 104.1 L300.8 104.4 L300.3 104.8 L299.9 105.1 L299.4 105.5 L299.0 105.8 L298.6 106.2 L298.1 106.5 L297.7 106.9 L297.3 107.3 L296.9 107.7 L296.5 108.1 L296.2 108.6 L295.8 109.0 L295.5 109.4 L295.1 109.9 L294.8 110.3 L294.4 110.8 L294.1 111.2 L293.8 111.7 L293.5 112.2 L293.3 112.7 L293.0 113.2 L292.7 113.7 L292.5 114.2 L292.2 114.7 L292.0 115.2 L291.8 115.7 L291.6 116.2 L291.4 116.7 L291.2 117.3 L291.1 117.8 L290.9 118.3 L290.8 118.9 L290.6 119.4 L290.5 120.0 L290.4 120.5 L290.3 121.1 L290.2 121.6 L290.2 122.2 L290.1 122.8 L290.1 123.3 L290.0 123.9 L290.0 124.4 L290.0 125.0 L290.0 125.6 L290.0 126.1 L290.1 126.7 L290.1 127.2 L290.2 127.8 L290.2 128.4 L290.3 128.9 L290.4 129.5 L290.5 130.0 L290.6 130.6 L290.8 131.1 L290.9 131.7 L291.1 132.2 L291.2 132.7 L291.4 133.3 L291.6 133.8 L291.8 134.3 L292.0 134.8 L292.2 135.3 L292.5 135.8 L292.7 136.3 L293.0 136.8 L293.3 137.3 L293.5 137.8 L293.8 138.3 L294.1 138.8 L294.4 139.2 L294.8 139.7 L295.1 140.1 L295.5 140.6 L295.8 141.0 L296.2 141.4 L296.5 141.9 L296.9 142.3 L297.3 142.7 L297.7 143.1 L298.1 143.5 L298.6 143.8 L299.0 144.2 L299.4 144.5 L299.9 144.9 L300.3 145.2 L300.8 145.6 L301.2 145.9 L301.7 146.2 L302.2 146.5 L302.7 146.7 L303.2 147.0 L303.7 147.3 L304.2 147.5 L304.7 147.8 L305.2 148.0 L305.7 148.2 L306.2 148.4 L306.7 148.6 L307.3 148.8 L307.8 148.9 L308.3 149.1 L308.9 149.2 L309.4 149.4 L310.0 149.5 L310.5 149.6 L311.1 149.7 L311.6 149.8 L312.2 149.8 L312.8 149.9 L313.3 149.9 L313.9 150.0 L314.4 150.0 L315.0 150.0 L315.6 150.0 L316.1 150.0 L316.7 149.9 L317.2 149.9 L317.8 149.8 L318.4 149.8 L318.9 149.7 L319.5 149.6 L320.0 149.5 L320.6 149.4 L321.1 149.2 L321.7 149.1 L322.2 148.9 L322.7 148.8 L323.3 148.6 L323.8 148.4 L324.3 148.2 L324.8 148.0 L325.3 147.8 L325.8 147.5 L326.3 147.3 L326.8 147.0 L327.3 146.7 L327.8 146.5 L328.3 146.2 L328.8 145.9 L329.2 145.6 L329.7 145.2 L330.1 144.9 L330.6 144.5 L331.0 144.2 L331.4 143.8 L331.9 143.5 L332.3 143.1 L332.7 142.7 L333.1 142.3 L333.5 141.9 L333.8 141.4 L334.2 141.0 L334.5 140.6 L334.9 140.1 L335.2 139.7 L335.6 139.2 L335.9 138.8 L336.2 138.3 L336.5 137.8 L336.7 137.3 L337.0 136.8 L337.3 136.3 L337.5 135.8 L337.8 135.3 L338.0 134.8 L338.2 134.3 L338.4 133.8 L338.6 133.3 L338.8 132.7 L338.9 132.2 L339.1 131.7 L339.2 131.1 L339.4 130.6 L339.5 130.0 L339.6 129.5 L339.7 128.9 L339.8 128.4 L339.8 127.8 L339.9 127.2 L339.9 126.7 L340.0 126.1 L340.0 125.6 L340.0 125.0"/>

</svg>
<figcaption>A smaller circle has larger curvature: $\kappa=1/R$. Curvature measures turning per unit distance, not how rapidly the parameter advances.</figcaption>
</figure>


:::example[Example 13.4.1 — Unit Tangent Vector]

**Answer: $\hat{T}(0)=\langle0,1/\sqrt2,1/\sqrt2\rangle$.**

Find the unit tangent vector to $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$ at $t=0$.

**Solution.**

$$
\vec{r}\,'(t)=\langle-\sin t,\cos t,1\rangle,\qquad\vec{r}\,'(0)=\langle 0,1,1\rangle.
$$

$$
|\vec{r}\,'(0)|=\sqrt{0+1+1}=\sqrt{2}.
$$

$$
\hat{T}(0)=\frac{\langle 0,1,1\rangle}{\sqrt{2}}=\left\langle 0,\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right\rangle.
$$
:::

:::example[Example 13.4.2 — Curvature via Cross Product Formula]

**Answer: $\kappa=1/2$.**

Find the curvature of $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$.

**Solution.**

$$
\vec{r}\,'=\langle-\sin t,\cos t,1\rangle,\qquad\vec{r}\,''=\langle-\cos t,-\sin t,0\rangle.
$$

 Cross product:

$$
\vec{r}\,'\times\vec{r}\,''=\langle\sin t,-\cos t,1\rangle.
$$

 Let's use the determinant:

$$
\vec{r}\,'\times\vec{r}\,''=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\-\sin t&\cos t&1\\-\cos t&-\sin t&0\end{vmatrix}=\langle 0\cdot\cos t-(-\sin t)\cdot1,\;1\cdot(-\cos t)-(-\sin t)\cdot0,\;(-\sin t)(-\sin t)-\cos t(-\cos t)\rangle.
$$

$$
=\langle\sin t,\;-\cos t,\;\sin^2 t+\cos^2 t\rangle=\langle\sin t,-\cos t,1\rangle.
$$

$$
|\vec{r}\,'\times\vec{r}\,''|=\sqrt{\sin^2 t+\cos^2 t+1}=\sqrt{2},\qquad|\vec{r}\,'|^3=(\sqrt{2})^3=2\sqrt{2}.
$$

$$
\kappa=\frac{\sqrt{2}}{2\sqrt{2}}=\frac{1}{2}.
$$

Therefore the curvature is $1/2$. In a written test, simplify $|\mathbf v\times\mathbf a|/|\mathbf v|^3$ before drawing the final answer box.
:::

:::example[Example 13.4.3 — Curvature of a Plane Curve]

**Answer: $\kappa(0)=2$.**

Find the curvature of $y=x^2$ at $x=0$.

**Solution.** $f'(x)=2x$, $f''(x)=2$.

$$
\kappa(0)=\frac{|f''(0)|}{[1+(f'(0))^2]^{3/2}}=\frac{2}{[1+0]^{3/2}}=2.
$$

 The radius of curvature at the vertex is $R=1/\kappa=1/2$.
:::

:::example[Example 13.4.4 — Unit Normal Vector]

**Answer: $\hat{N}(t)=\langle-\cos t,-\sin t,0\rangle$.**

Find the unit normal vector to the helix $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$.

**Solution.**

$$
\hat{T}(t)=\frac{\vec{r}\,'}{|\vec{r}\,'|}=\frac{\langle-\sin t,\cos t,1\rangle}{\sqrt{2}}.
$$

$$
\hat{T}'(t)=\frac{\langle-\cos t,-\sin t,0\rangle}{\sqrt{2}},\qquad|\hat{T}'(t)|=\frac{1}{\sqrt{2}}.
$$

$$
\hat{N}(t)=\frac{\hat{T}'}{|\hat{T}'|}=\langle-\cos t,-\sin t,0\rangle.
$$

 The normal vector always points toward the $z$-axis — the center of the circular cross-sections of the helix. This makes geometric sense.
:::

:::example[Example 13.4.5 — Binormal and Osculating Plane]

**Answer: $\hat{B}=\langle\sin t/\sqrt{2},-\cos t/\sqrt{2},1/\sqrt{2}\rangle$.**

Find the binormal vector for the helix $\vec{r}(t)=\langle\cos t,\sin t,t\rangle$.

**Solution.**

$$
\hat{B}=\hat{T}\times\hat{N}=\frac{1}{\sqrt{2}}\langle-\sin t,\cos t,1\rangle\times\langle-\cos t,-\sin t,0\rangle.
$$

 Cross product of the un-scaled parts:

$$
\langle-\sin t,\cos t,1\rangle\times\langle-\cos t,-\sin t,0\rangle=\langle0+\sin t,\;-\cos t-0,\;\sin^2 t+\cos^2 t\rangle=\langle\sin t,-\cos t,1\rangle.
$$

$$
\hat{B}=\frac{1}{\sqrt{2}}\langle\sin t,-\cos t,1\rangle.
$$

 The binormal rotates as $t$ changes, even though its magnitude remains 1. The helix has constant torsion, but that does **not** mean its binormal points in a fixed direction.
:::

:::callout-pitfall
Watch out for:

- **Curvature is not the same as $|\vec{r}\,''|$.** Curvature depends on $|\vec{r}\,'\times\vec{r}\,''|/|\vec{r}\,'|^3$. Speeding up along a straight line gives large $|\vec{r}\,''|$ but zero curvature.
- **Unit normal requires normalization of $\hat{T}'$, not $\vec{r}\,'$.** Compute $\hat{T}$ first, then differentiate, then normalize. Differentiating $\vec{r}\,'$ directly gives something different.
- **Plane curve formula only for $y=f(x)$.** The formula $\kappa=|f''|/(1+f'^2)^{3/2}$ only applies to graphs in a plane. For general space curves, use the cross-product formula.
:::

### Practice problems

::::problem[Problem 13.4.1 standard]{difficulty=standard}
Find the unit tangent vector to $\vec{r}(t)=\langle 3\cos t,3\sin t,4t\rangle$ at $t=0$.

:::solution[Solution]
**Answer:** $\mathbf T(0)=\langle0,3/5,4/5\rangle$.

1. **Use the unit-tangent formula.** For a differentiable curve where $\vec r\,'(t)\ne\vec0$, the unit tangent is $\mathbf T(t)=\vec r\,'(t)/|\vec r\,'(t)|$.
2. **Differentiate each position component:**

$$
\vec r\,'(t)=\langle-3\sin t,3\cos t,4\rangle.
$$

3. **Evaluate at the requested time.** Since $\sin0=0$ and $\cos0=1$,

$$
\vec r\,'(0)=\langle0,3,4\rangle.
$$

4. **Find the speed and confirm it is nonzero:**

$$
|\vec r\,'(0)|=\sqrt{0^2+3^2+4^2}=\sqrt{25}=5>0.
$$

5. **Normalize the tangent vector:**

$$
\mathbf T(0)=\frac{\langle0,3,4\rangle}{5}=\left\langle0,\frac35,\frac45\right\rangle.
$$

   Its squared magnitude is $9/25+16/25=1$, confirming it is a unit tangent.
:::
::::
::::problem[Problem 13.4.2 standard]{difficulty=standard}
Find the curvature of $\vec{r}(t)=\langle t,t^2,0\rangle$ (a parabola in the $xy$-plane) at $t=0$.

:::solution[Solution]
**Answer:** $\kappa(0)=2$.

1. **Choose the curvature formula.** Since $\vec r\,'(0)\ne\vec0$, use $\kappa=|\vec r\,'\times\vec r\,''|/|\vec r\,'|^3$.
2. **Differentiate twice:**

$$
\vec r\,'(t)=\langle1,2t,0\rangle,\qquad\vec r\,''(t)=\langle0,2,0\rangle.
$$

3. **Evaluate at $t=0$.** We have $\vec r\,'(0)=\langle1,0,0\rangle$ and $\vec r\,''(0)=\langle0,2,0\rangle$.
4. **Compute the cross product and its magnitude:**

$$
\vec r\,'(0)\times\vec r\,''(0)=\langle0\cdot0-0\cdot2,\,0\cdot0-1\cdot0,\,1\cdot2-0\cdot0\rangle=\langle0,0,2\rangle.
$$

   Its magnitude is $2$; the speed is $\sqrt{1^2+0^2}=1$.
5. **Substitute.** $\kappa(0)=2/1^3=2$. Thus the parabola has curvature $2$ at the origin.
:::
::::
::::problem[Problem 13.4.3 standard]{difficulty=standard}
Find the curvature of $y=\sin x$ at $x=0$.

:::solution[Solution]
**Answer:** $\kappa(0)=0$.

1. **Use the graph curvature formula.** For a twice differentiable plane curve $y=f(x)$,

$$
\kappa(x)=\frac{|f''(x)|}{(1+[f'(x)]^2)^{3/2}}.
$$

   The denominator is positive, so this formula applies at $x=0$.
2. **Differentiate the given function.** For $f(x)=\sin x$,

$$
f'(x)=\cos x,\qquad f''(x)=-\sin x.
$$

3. **Evaluate at zero.** Since $\cos0=1$ and $\sin0=0$, we have $f'(0)=1$ and $f''(0)=0$.
4. **Substitute into the formula:**

$$
\kappa(0)=\frac{|0|}{(1+1^2)^{3/2}}=\frac0{2^{3/2}}=0.
$$

5. **Interpret the answer.** The sine graph has an inflection point at the origin and zero instantaneous curvature there. The tangent is still well defined; zero curvature does not mean zero slope.
:::
::::
::::problem[Problem 13.4.4 challenge]{difficulty=challenge}
Show that a curve with zero curvature everywhere is a straight line.

:::solution[Solution]
**Answer:** A regular curve with zero curvature everywhere lies on a straight line.

1. **State the needed conditions.** Assume $\vec r$ is a regular $C^2$ curve on a connected interval, so $|\vec r\,'(t)|>0$ and the unit tangent $\mathbf T(t)$ is defined throughout.
2. **Use the tangent-based curvature formula:**

$$
\kappa(t)=\frac{|\mathbf T'(t)|}{|\vec r\,'(t)|}.
$$

   If $\kappa(t)=0$ everywhere and the denominator is positive, then $|\mathbf T'(t)|=0$, so $\mathbf T'(t)=\vec0$.
3. **Infer constant direction.** On a connected interval, a differentiable vector with zero derivative is constant: $\mathbf T(t)=\mathbf c$, where $|\mathbf c|=1$.
4. **Recover the path.** Because $\vec r\,'=|\vec r\,'|\mathbf T$, we have $\vec r\,'(t)=|\vec r\,'(t)|\mathbf c$. Integrate from $a$ to $t$:

$$
\vec r(t)=\vec r(a)+\mathbf c\int_a^t|\vec r\,'(u)|\,du.
$$

5. **Conclude.** Every point differs from $\vec r(a)$ by a scalar multiple of the fixed vector $\mathbf c$. Thus the entire curve lies on one straight line, as claimed.
:::
::::
::::problem[Problem 13.4.5 challenge]{difficulty=challenge}
Find the TNB frame for $\vec{r}(t)=\langle 3\sin t,3\cos t,4t\rangle$ at $t=0$.

:::solution[Solution]
**Answer:** $\mathbf T(0)=\langle3/5,0,4/5\rangle$, $\mathbf N(0)=\langle0,-1,0\rangle$, $\mathbf B(0)=\langle4/5,0,-3/5\rangle$.

1. **Find the unit tangent.** Differentiate $\vec r(t)$ to get $\vec r\,'=\langle3\cos t,-3\sin t,4\rangle$. Its speed is $\sqrt{9\cos^2t+9\sin^2t+16}=5$, never zero. Therefore

$$
\mathbf T(t)=\frac15\langle3\cos t,-3\sin t,4\rangle,\qquad\mathbf T(0)=\langle3/5,0,4/5\rangle.
$$

2. **Find the principal normal.** Differentiate the unit tangent:

$$
\mathbf T'(t)=\frac15\langle-3\sin t,-3\cos t,0\rangle,\qquad |\mathbf T'|=\frac35.
$$

   Since this magnitude is nonzero, $\mathbf N=\mathbf T'/|\mathbf T'|=\langle-\sin t,-\cos t,0\rangle$, so $\mathbf N(0)=\langle0,-1,0\rangle$.
3. **Compute the binormal in the correct order:**

$$
\mathbf B(0)=\mathbf T(0)\times\mathbf N(0)=\left\langle\frac45,0,-\frac35\right\rangle.
$$

4. **Check.** Each vector has unit length, and their pairwise dot products vanish. Thus the displayed $\mathbf T$, $\mathbf N$, and $\mathbf B$ form the right-handed TNB frame at $t=0$.
:::
::::

### Which curvature formula should you choose?

For curvature, the **cross-product route** avoids differentiating a normalized tangent and is ideal when $\mathbf v=\mathbf r'$ and $\mathbf a=\mathbf r''$ have easy components. Calculate $\mathbf v\times\mathbf a$ with its three signs, find its norm, compute $|\mathbf v|^3$, then divide. The alternative $\kappa=|\mathbf T'|/|\mathbf v|$ is efficient when speed is a constant and $\mathbf T$ is already simple. Both must give the same nonnegative curvature.

The unit tangent $\mathbf T$ and unit principal normal $\mathbf N$ are **different**: $\mathbf T$ points in the direction of motion, while $\mathbf N$ points in the direction the tangent turns. Begin with $\mathbf T=\mathbf v/|\mathbf v|$, differentiate the **entire** expression to find $\mathbf T'$, and only then normalize $\mathbf T'/|\mathbf T'|$. The normal is undefined where $\mathbf T'=\mathbf0$, which can happen on straight portions of a curve.

### Constant-speed trig curves: look for sin² plus cos²

Young said her Test 3 uses only the identity $\sin^2t+\cos^2t=1$. For $\mathbf r(t)=\langle2\cos t,6t,2-2\sin t\rangle$, the speed is $\sqrt{4\sin^2t+36+4\cos^2t}=\sqrt{40}=2\sqrt{10}$. This **constant** denominator makes differentiating $\mathbf T$ trivial. If you find yourself using a double-angle or half-angle identity for a similar vector, you probably chose a harder route than necessary.

:::callout-tip[Two-part 20-point T and N question]
Line 1: $\mathbf v(t)=\mathbf r'(t)$. Line 2: $|\mathbf v(t)|=\sqrt{\cdots}$ and simplify with $\sin^2+\cos^2=1$. Line 3: $\mathbf T=\mathbf v/|\mathbf v|$. Line 4: $\mathbf T'$ with every differentiated component shown. Line 5: $|\mathbf T'|$. Line 6: $\mathbf N=\mathbf T'/|\mathbf T'|$. Check $|\mathbf T|=|\mathbf N|=1$ and $\mathbf T\cdot\mathbf N=0$.
:::

:::example[Example 13.4.6 — Released-key style T and N together]
Find the unit tangent and principal normal for $\mathbf r(t)=\langle2\cos t,6t,2-2\sin t\rangle$.

**Answer: $\mathbf T(t)=\left\langle-\frac{\sin t}{\sqrt{10}},\frac3{\sqrt{10}},-\frac{\cos t}{\sqrt{10}}\right\rangle$, $\mathbf N(t)=\langle-\cos t,0,\sin t\rangle$.**


**Differentiate position:**

$$\mathbf v(t)=\mathbf r'(t)=\langle-2\sin t,6,-2\cos t\rangle.$$

**Simplify speed with the permitted identity:**

$$
\begin{aligned}
|\mathbf v|&=\sqrt{(-2\sin t)^2+6^2+(-2\cos t)^2}\\
&=\sqrt{4(\sin^2t+\cos^2t)+36}
=\sqrt{4+36}=\sqrt{40}=2\sqrt{10}.
\end{aligned}
$$
**Normalize velocity:**

$$
\mathbf T=\frac1{2\sqrt{10}}\langle-2\sin t,6,-2\cos t\rangle
=\left\langle-\frac{\sin t}{\sqrt{10}},\frac3{\sqrt{10}},-\frac{\cos t}{\sqrt{10}}\right\rangle.
$$
**Differentiate $\mathbf T$ and normalize again:**

$$\mathbf T'=\left\langle-\frac{\cos t}{\sqrt{10}},0,\frac{\sin t}{\sqrt{10}}\right\rangle,$$

$$|\mathbf T'|=\sqrt{\frac{\cos^2t+\sin^2t}{10}}=\frac1{\sqrt{10}}.$$

Therefore

$$
\mathbf N=\frac{\mathbf T'}{|\mathbf T'|}
=\sqrt{10}\left\langle-\frac{\cos t}{\sqrt{10}},0,\frac{\sin t}{\sqrt{10}}\right\rangle
=\langle-\cos t,0,\sin t\rangle.
$$
As a check, $\mathbf T\cdot\mathbf N=\frac{\sin t\cos t}{\sqrt{10}}-\frac{\cos t\sin t}{\sqrt{10}}=0$.

:::

:::example[Example 13.4.7 — Curvature with a square-root component]
Find $\kappa(t)$ for $\mathbf r(t)=\langle t,4t^{3/2},-t^2\rangle$, $t>0$.

**Answer: $\displaystyle\kappa(t)=\frac{\sqrt{36t+4+9/t}}{(1+36t+4t^2)^{3/2}}$.**


Start with the power rule:

$$
\mathbf v=\langle1,6\sqrt t,-2t\rangle,\qquad
\mathbf a=\left\langle0,\frac3{\sqrt t},-2\right\rangle.
$$
Expand the cross product component by component:

$$
\begin{aligned}
\mathbf v\times\mathbf a
&=\langle(6\sqrt t)(-2)-(-2t)(3/\sqrt t),\\
&\hspace{28pt}(-2t)(0)-(1)(-2),\\
&\hspace{28pt}(1)(3/\sqrt t)-(6\sqrt t)(0)\rangle\\
&=\langle-12\sqrt t+6\sqrt t,2,3/\sqrt t\rangle\\
&=\langle-6\sqrt t,2,3/\sqrt t\rangle.
\end{aligned}
$$
Then $|\mathbf v\times\mathbf a|=\sqrt{36t+4+9/t}$ and $|\mathbf v|=\sqrt{1+36t+4t^2}$. Cube the speed by raising the square-root expression to $3/2$, giving the displayed curvature. The condition $t>0$ is necessary for the acceleration expression.

:::

::::problem[Problem 13.4.6 — 20-point T N check]{difficulty=standard}
For $\mathbf r(t)=\langle3\cos t,4t,3\sin t\rangle$, compute $\mathbf T(t)$ and $\mathbf N(t)$.

:::solution[Solution]
**Answer:** $\mathbf T=\langle-3\sin t/5,4/5,3\cos t/5\rangle$, $\mathbf N=\langle-\cos t,0,-\sin t\rangle$.

1. **Compute velocity.** The curve is differentiable for all $t$:

$$
\mathbf r'(t)=\langle-3\sin t,4,3\cos t\rangle.
$$

2. **Find speed and check it is nonzero:**

$$
|\mathbf r'|=\sqrt{9\sin^2t+16+9\cos^2t}=\sqrt{9+16}=5.
$$

3. **Normalize velocity to find the unit tangent:**

$$
\mathbf T(t)=\frac15\langle-3\sin t,4,3\cos t\rangle.
$$

4. **Differentiate $\mathbf T$ and normalize again:**

$$
\mathbf T'(t)=\frac15\langle-3\cos t,0,-3\sin t\rangle,\qquad |\mathbf T'|=\frac35.
$$

   Hence $\mathbf N(t)=\mathbf T'/|\mathbf T'|=\langle-\cos t,0,-\sin t\rangle$; this is defined because $|\mathbf T'|\ne0$.
5. **Verify orthonormality.** $|\mathbf T|^2=(9+16)/25=1$, $|\mathbf N|^2=1$, and $\mathbf T\cdot\mathbf N=(3\sin t\cos t-3\cos t\sin t)/5=0$. Both requested vectors are therefore correct.
:::
::::

### How to earn the points on a T-and-N two-parter

For a curve $\mathbf r(t)$, start with $\mathbf v=\mathbf r'$ and its magnitude. Divide by the magnitude to get $\mathbf T(t)$ **before evaluating the requested time** whenever you need $\mathbf N$. If you substitute $t=t_0$ into $\mathbf T$ prematurely, it becomes a constant vector and differentiating that constant would incorrectly give zero. Instead differentiate the *function* $\mathbf T(t)$ first, evaluate $\mathbf T'(t_0)$, and then divide by its norm to obtain $\mathbf N(t_0)$.

For curvature, $\kappa=|\mathbf v\times\mathbf a|/|\mathbf v|^3$ is often best when the velocity and acceleration have simple components. The alternative $\kappa=|\mathbf T'|/|\mathbf v|$ may be shorter when $\mathbf T$ simplifies to an obvious trigonometric vector. Choose whichever avoids the harder derivative. The denominator is the **cube of speed**, not the cube of the velocity vector and not $|\mathbf v|^2$. Explain why the speed is nonzero at the point, since neither $\mathbf T$ nor the curvature formula is defined for a stationary parameter value without additional analysis.


## 13.5 Tangential and Normal Components of Acceleration

**Not on Test 3.** Kept from the original chapter for completeness.

### Tangential and Normal Components of Acceleration

Since $\vec{v}=|\vec{v}|\hat{T}$, we can differentiate using the product rule to decompose $\vec{a}$:

$$
\vec{a}=\frac{d}{dt}[|\vec{v}|\hat{T}]=\frac{d|\vec{v}|}{dt}\hat{T}+|\vec{v}|\hat{T}'.
$$

 Using $\hat{T}'=\kappa|\vec{v}|\hat{N}$:

$$
\vec{a}=\underbrace{\frac{d|\vec{v}|}{dt}}_{a_T}\hat{T}+\underbrace{\kappa|\vec{v}|^2}_{a_N}\hat{N}.
$$

:::definition
Definition 13.5.1 — Tangential and Normal Components

The tangential acceleration component $a_T$ and normal acceleration component $a_N$ are:

$$
a_T=\frac{d|\vec{v}|}{dt}=\frac{\vec{a}\cdot\vec{v}}{|\vec{v}|},\qquad a_N=\kappa|\vec{v}|^2=\frac{|\vec{v}\times\vec{a}|}{|\vec{v}|}.
$$

 So $\vec{a}=a_T\hat{T}+a_N\hat{N}$, and $|\vec{a}|^2=a_T^2+a_N^2$.
:::

Physical meaning: $a_T$ is the rate of change of speed (positive when speeding up, negative when slowing down). $a_N$ is the centripetal acceleration — it's always non-negative and points toward the center of curvature. On a straight road, $a_N=0$. On a sharp curve at high speed, $a_N$ is large.

### Worked examples

:::example[Example 13.5.1 — Tangential and Normal Acceleration]

**Answer: $a_T=0$, $a_N=2$ (at $t=0$ for circular motion).**

A particle moves on the circle $\vec{r}(t)=\langle 2\cos t,2\sin t,0\rangle$. Find $a_T$ and $a_N$.

**Solution.**

$$
\vec{v}=\langle-2\sin t,2\cos t,0\rangle,\quad|\vec{v}|=2\;\text{(constant)}.
$$

 Since speed is constant, $a_T=d|\vec{v}|/dt=0$. The particle only changes direction, not speed.

$$
\vec{a}=\langle-2\cos t,-2\sin t,0\rangle,\quad|\vec{a}|=2.
$$

 Check: $|\vec{a}|^2=a_T^2+a_N^2\Rightarrow4=0+a_N^2\Rightarrow a_N=2$. All acceleration is centripetal.

Alternatively: $\kappa=1/R=1/2$ for a circle of radius 2, and $a_N=\kappa|\vec{v}|^2=(1/2)(4)=2$. ✓
:::

:::callout-pitfall
Watch out for:

- **Speed ≠ magnitude of acceleration.** $|\vec{a}|$ gives the magnitude of acceleration, not speed. Speed is $|\vec{v}|$.
- **Constant speed does NOT mean zero acceleration.** Circular motion has constant speed but centripetal acceleration $a_N=\kappa|\vec{v}|^2>0$. Only a particle moving in a straight line at constant speed has $\vec{a}=\vec{0}$.
- **Projectile sign convention.** Be consistent: if $z$ is upward, gravity is $-g\hat{k}$. If $y$ is upward (2D problems), it's $-g\hat{\jmath}$. Mixing up the axis is the most common setup error.
:::

### Practice problems

::::problem[Problem 13.5.1 standard]{difficulty=standard}
For $\vec{r}(t)=\langle t^2,2t,\ln t\rangle$, find $a_T$ and $a_N$ at $t=1$.

:::solution[Solution]
**Answer:** $a_T=1$, $a_N=2$.

1. **Check motion quantities.** For $t>0$, differentiate the position to get $\vec v(t)=\langle2t,2,1/t\rangle$ and $\vec a(t)=\langle2,0,-1/t^2\rangle$.
2. **Evaluate at $t=1$:**

$$
\vec v(1)=\langle2,2,1\rangle,\quad |\vec v(1)|=\sqrt{4+4+1}=3,\quad\vec a(1)=\langle2,0,-1\rangle.
$$

3. **Find tangential acceleration.** Since speed is nonzero, $a_T=(\vec v\cdot\vec a)/|\vec v|$. Therefore

$$
a_T=\frac{2(2)+2(0)+1(-1)}{3}=\frac{4-1}{3}=1.
$$

4. **Find normal acceleration.** Use $|\vec a|^2=a_T^2+a_N^2$ with $a_N\ge0$. Here $|\vec a|^2=2^2+0^2+(-1)^2=5$, so

$$
a_N=\sqrt{5-1^2}=\sqrt4=2.
$$

5. **Conclude.** The tangential component is $1$ and the normal component is $2$ at $t=1$, with $1^2+2^2=|\vec a|^2$ confirming the decomposition.
:::
::::
## 13.6 Velocity and Acceleration in Polar Coordinates

**Not on Test 3.** Kept from the original chapter for completeness.

:::callout-warning[🚧 Work needed]
Not written yet. Thomas 13.6 covers radial and transverse components of velocity and acceleration. Check whether MA 2733 covers it before writing.
:::

## Chapter Summary

:::callout-key
If you remember nothing else from this chapter, remember this:

- Differentiate and integrate vector functions componentwise — it reduces to Calc I.
- $\hat{T}=\vec{r}\,'/|\vec{r}\,'|$ is the unit tangent; $\kappa=|\vec{r}\,'\times\vec{r}\,''|/|\vec{r}\,'|^3$ is the curvature.
- Acceleration splits into $a_T\hat{T}$ (changing speed) and $a_N\hat{N}$ (changing direction).
- If speed is constant, all acceleration is centripetal ($a_T=0$, $a_N=\kappa v^2$).
:::

| Concept | Formula | Notes |
| --- | --- | --- |
| Derivative | $\vec{r}\,'(t)=\langle f',g',h'\rangle$ | Component-by-component; tangent vector |
| Unit tangent | $\hat{T}=\vec{r}\,'/|\vec{r}\,'|$ | Unit vector along curve direction |
| Arc length | $L=\int_a^b|\vec{r}\,'(t)|\,dt$ | $ds=|\vec{r}\,'|\,dt$ |
| Curvature (general) | $\kappa=|\vec{r}\,'\times\vec{r}\,''|/|\vec{r}\,'|^3$ | Most useful computational form |
| Curvature (plane $y=f(x)$) | $\kappa=|f''|/(1+f'^2)^{3/2}$ | Only for graph curves in a plane |
| Radius of curvature | $R=1/\kappa$ | Radius of osculating circle |
| Unit normal | $\hat{N}=\hat{T}'/|\hat{T}'|$ | Points toward center of curvature |
| Binormal | $\hat{B}=\hat{T}\times\hat{N}$ | Perpendicular to osculating plane |
| Velocity / Acceleration | $\vec{v}=\vec{r}\,'$, $\vec{a}=\vec{r}\,''$ | Speed $=|\vec{v}|$ |
| Tangential acceleration | $a_T=\vec{a}\cdot\vec{v}/|\vec{v}|=d|\vec{v}|/dt$ | Rate of speed change |
| Normal acceleration | $a_N=\kappa|\vec{v}|^2=|\vec{v}\times\vec{a}|/|\vec{v}|$ | Centripetal; always $\ge0$ |
| Projectile position | $\vec{r}(t)=\vec{r}_0+\vec{v}_0 t-\tfrac{1}{2}g t^2\hat{k}$ | Under gravity only |
| Range | $R=v_0^2\sin2\theta/g$ | Max at $\theta=45°$ |

## Mixed Practice

Ten problems spanning all four sections, in scrambled order.

::::problem[Problem 4.M1 easy]{difficulty=easy}
Find the domain of $\vec{r}(t)=\langle\arcsin t,\;\sqrt{t},\;1/(t-2)\rangle$.

:::solution[Solution]
**Answer:** Domain $[0,1]$.

1. **Intersect component domains.** All three components must be real and defined simultaneously.
2. **Inverse sine condition.** For $\arcsin t$, the real input must satisfy $-1\le t\le1$. This comes from sine taking values only in $[-1,1]$.
3. **Square-root condition.** For $\sqrt t$, require $t\ge0$, including $t=0$.
4. **Denominator condition.** For $1/(t-2)$, require $t-2\ne0$, so $t\ne2$.
5. **Combine the restrictions.** Intersect $[-1,1]$ and $[0,\infty)$ to obtain $[0,1]$. Every point of that interval is already different from $2$, so the denominator restriction removes nothing further.
6. **Conclude.** Both endpoints $0$ and $1$ are allowed, making the domain the closed interval $[0,1]$.
:::
::::
::::problem[Problem 4.M2 standard]{difficulty=standard}
A space curve is given by $\vec{r}(t)=\langle t,\cosh t,\sinh t\rangle$. Find the arc length from $t=0$ to $t=1$.

:::solution[Solution]
**Answer:** $L=\sqrt2\sinh1$.

1. **Use arc length.** Because $\cosh t$ and $\sinh t$ are smooth, $L=\int_0^1|\vec r\,'(t)|\,dt$ applies.
2. **Differentiate coordinatewise:**

$$
\vec r\,'(t)=\langle1,\sinh t,\cosh t\rangle.
$$

3. **Simplify speed using hyperbolic identities:**

$$
|\vec r\,'|=\sqrt{1+\sinh^2t+\cosh^2t}.
$$

   Since $\cosh^2t-\sinh^2t=1$, replace $1+\sinh^2t$ by $\cosh^2t$. This gives $\sqrt{2\cosh^2t}=\sqrt2\,|\cosh t|$. Because $\cosh t>0$ for all real $t$, the speed is $\sqrt2\cosh t$.
4. **Integrate exactly:**

$$
L=\sqrt2\int_0^1\cosh t\,dt=\sqrt2[\sinh t]_0^1=\sqrt2(\sinh1-\sinh0).
$$

5. **Conclude.** Since $\sinh0=0$, the length is $\sqrt2\sinh1$. No decimal approximation is needed.
:::
::::
::::problem[Problem 4.M3 standard]{difficulty=standard}
Find the tangent line to $\vec{r}(t)=\langle e^t,e^{-t},t\rangle$ at the point where $t=0$. Then find the angle this tangent makes with the $z$-axis.

:::solution[Solution]
**Answer:** Line $\langle1+s,1-s,s\rangle$; angle $\arccos(1/\sqrt3)$.

1. **Locate the point.** Substitute $t=0$ into the curve, using $e^0=e^{-0}=1$:

$$
\vec r(0)=\langle1,1,0\rangle.
$$

2. **Find a tangent direction.** Differentiate componentwise:

$$
\vec r\,'(t)=\langle e^t,-e^{-t},1\rangle,\quad\vec r\,'(0)=\langle1,-1,1\rangle.
$$

3. **Write the tangent line.** The derivative is nonzero, so the point-direction equation gives

$$
\boldsymbol\ell(s)=\vec r(0)+s\vec r\,'(0)=\langle1+s,1-s,s\rangle.
$$

4. **Use the dot-product angle formula.** The positive $z$-axis has direction $\mathbf k=\langle0,0,1\rangle$. With tangent $\mathbf d=\langle1,-1,1\rangle$, calculate $\mathbf d\cdot\mathbf k=1$, $|\mathbf d|=\sqrt{1+1+1}=\sqrt3$, and $|\mathbf k|=1$.
5. **Solve for the angle.** $\cos\theta=1/\sqrt3$, so $\theta=\arccos(1/\sqrt3)$. These give the required line and its angle with the positive $z$-axis.
:::
::::
::::problem[Problem 4.M4 easy]{difficulty=easy}
A particle moves with velocity $\vec{v}(t)=\langle 3t^2,2t,-1\rangle$ and $\vec{r}(0)=\langle 1,0,5\rangle$. Find the position when $t=2$.

:::solution[Solution]
**Answer:** $\mathbf r(2)=\langle9,4,3\rangle$.

1. **Use the velocity-position relationship.** Since $\vec v(t)=\vec r\,'(t)$, integrate velocity componentwise to recover the position vector.
2. **Integrate all three coordinates:**

$$
\vec r(t)=\left\langle\int3t^2\,dt,\int2t\,dt,\int(-1)\,dt\right\rangle=\langle t^3+C_1,t^2+C_2,-t+C_3\rangle.
$$

3. **Use the initial position to determine constants.** At $t=0$, the expression becomes $\langle C_1,C_2,C_3\rangle$. Matching $\vec r(0)=\langle1,0,5\rangle$ gives $C_1=1$, $C_2=0$, and $C_3=5$.
4. **Substitute $t=2$:**

$$
\vec r(2)=\langle2^3+1,2^2,5-2\rangle=\langle8+1,4,3\rangle=\langle9,4,3\rangle.
$$

5. **Check.** Differentiating $\langle t^3+1,t^2,5-t\rangle$ returns the given velocity, so $\langle9,4,3\rangle$ is the position at $t=2$.
:::
::::
::::problem[Problem 4.M5 standard]{difficulty=standard}
Find the curvature of the curve $\vec{r}(t)=\langle t^2,t,t^3\rangle$ at $t=0$.

:::solution[Solution]
**Answer:** $\kappa(0)=2$.

1. **Choose a curvature formula.** A smooth regular space curve has $\kappa=|\vec r\,'\times\vec r\,''|/|\vec r\,'|^3$; we check that the derivative at zero is nonzero below.
2. **Differentiate the position twice:**

$$
\vec r\,'(t)=\langle2t,1,3t^2\rangle,\qquad\vec r\,''(t)=\langle2,0,6t\rangle.
$$

3. **Evaluate at $t=0$.** The vectors are $\vec r\,'(0)=\langle0,1,0\rangle$ and $\vec r\,''(0)=\langle2,0,0\rangle$. The speed is $\sqrt{0+1+0}=1>0$.
4. **Calculate their cross product:**

$$
\vec r\,'(0)\times\vec r\,''(0)=\langle1\cdot0-0\cdot0,\,0\cdot2-0\cdot0,\,0\cdot0-1\cdot2\rangle=\langle0,0,-2\rangle.
$$

5. **Substitute magnitudes.** The numerator is $2$ and the denominator is $1^3=1$, giving $\kappa(0)=2$. This is the curve's instantaneous curvature at the specified time.
:::
::::
::::problem[Problem 4.M6 standard]{difficulty=standard}
A ball is kicked from the ground at $60°$ with initial speed $20$ m/s. Using $g=10$ m/s², find: (a) time to reach max height, (b) max height, (c) total range.

:::solution[Solution]
**Answer:** $t_{\max}=\sqrt3$ s, $H=15$ m, $R=20\sqrt3$ m.

1. **Resolve the launch velocity.** In still air with constant $g=10$, use $\sin60^\circ=\sqrt3/2$ and $\cos60^\circ=1/2$:

$$
v_{0x}=20(1/2)=10,\qquad v_{0z}=20(\sqrt3/2)=10\sqrt3.
$$

2. **Write vertical velocity and position.** $v_z(t)=10\sqrt3-10t$ and $z(t)=10\sqrt3\,t-5t^2$, with initial height zero.
3. **Find time to maximum height.** Set $v_z=0$: $10\sqrt3-10t=0$, hence $t_{\max}=\sqrt3$ s.
4. **Calculate maximum height:**

$$
H=z(\sqrt3)=10\sqrt3(\sqrt3)-5(\sqrt3)^2=30-15=15\text{ m}.
$$

5. **Find range from the landing time.** Set $z(t)=t(10\sqrt3-5t)=0$. The positive root is $t=2\sqrt3$. Multiply by horizontal speed:

$$
R=10(2\sqrt3)=20\sqrt3\text{ m}.
$$

   Thus the maximum occurs after $\sqrt3$ s, at $15$ m, and the ball lands $20\sqrt3$ m away.
:::
::::
::::problem[Problem 4.M7 challenge]{difficulty=challenge}
For $\vec{r}(t)=\langle\cos t,\sin t,\sin t\rangle$, find the curvature at $t=0$ and determine $\hat{T}$, $\hat{N}$, $\hat{B}$.

:::solution[Solution]
**Answer:** $\kappa(0)=1/2$, $\mathbf T=\langle0,1/\sqrt2,1/\sqrt2\rangle$, $\mathbf N=\langle-1,0,0\rangle$, $\mathbf B=\langle0,-1/\sqrt2,1/\sqrt2\rangle$.

1. **Find the velocity and speed at zero.** $\vec r\,'(t)=\langle-\sin t,\cos t,\cos t\rangle$, so $\vec r\,'(0)=\langle0,1,1\rangle$ and $|\vec r\,'(0)|=\sqrt2>0$.
2. **Normalize velocity.** $\mathbf T(0)=\langle0,1,1\rangle/\sqrt2$.
3. **Find curvature with a cross product.** $\vec r\,''(t)=\langle-\cos t,-\sin t,-\sin t\rangle$, so $\vec r\,''(0)=\langle-1,0,0\rangle$ and

$$
\vec r\,'(0)\times\vec r\,''(0)=\langle0,-1,1\rangle,\quad \kappa(0)=\frac{\sqrt2}{(\sqrt2)^3}=\frac12.
$$

4. **Find the principal normal.** For general $t$, $|\vec r\,'(t)|=\sqrt{\sin^2t+2\cos^2t}$. Its derivative vanishes at zero, so differentiating $\mathbf T=\vec r\,'/|\vec r\,'|$ there gives $\mathbf T'(0)=\vec r\,''(0)/\sqrt2=\langle-1/\sqrt2,0,0\rangle$. Normalizing gives $\mathbf N(0)=\langle-1,0,0\rangle$.
5. **Take the ordered cross product.** $\mathbf B=\mathbf T\times\mathbf N=\langle0,-1/\sqrt2,1/\sqrt2\rangle$. These are the curvature and right-handed TNB frame at $t=0$.
:::
::::
::::problem[Problem 4.M8 standard]{difficulty=standard}
Compute $\frac{d}{dt}[\vec{r}(t)\times\vec{r}\,'(t)]$ and simplify.

:::solution[Solution]
**Answer:** $d(\mathbf r\times\mathbf r\prime)/dt=\mathbf r\times\mathbf r\prime\prime$.

1. **Apply the cross-product differentiation rule.** For differentiable vector functions $\vec u$ and $\vec v$,

$$
\frac{d}{dt}(\vec u\times\vec v)=\vec u\,'\times\vec v+\vec u\times\vec v\,'.
$$

   Take $\vec u=\vec r$ and $\vec v=\vec r\,'$. The rule requires $\vec r$ to be twice differentiable.
2. **Substitute the derivatives:**

$$
\frac{d}{dt}(\vec r\times\vec r\,')=\vec r\,'\times\vec r\,'+\vec r\times\vec r\,''.
$$

3. **Simplify the first cross product.** Any vector crossed with itself is zero because its parallel components give determinant zero: $\vec r\,'\times\vec r\,'=\vec0$.
4. **Remove the zero term:**

$$
\frac{d}{dt}(\vec r\times\vec r\,')=\vec0+\vec r\times\vec r\,''=\vec r\times\vec r\,''.
$$

5. **Conclude.** The derivative simplifies exactly to $\vec r\times\vec r\,''$, without reversing the order of the surviving cross product.
:::
::::
::::problem[Problem 4.M9 challenge]{difficulty=challenge}
Find $a_T$ and $a_N$ for $\vec{r}(t)=\langle t,t^2,t^3\rangle$ at $t=1$.

:::solution[Solution]
**Answer:** $a_T=22/\sqrt{14}$, $a_N=\sqrt{38/7}$.

1. **Differentiate position twice.** $\vec v(t)=\langle1,2t,3t^2\rangle$ and $\vec a(t)=\langle0,2,6t\rangle$.
2. **Evaluate at one and find speed:**

$$
\vec v(1)=\langle1,2,3\rangle,\quad\vec a(1)=\langle0,2,6\rangle,\quad|\vec v(1)|=\sqrt{1+4+9}=\sqrt{14}>0.
$$

3. **Compute the tangential component:**

$$
a_T=\frac{\vec v\cdot\vec a}{|\vec v|}=\frac{1(0)+2(2)+3(6)}{\sqrt{14}}=\frac{22}{\sqrt{14}}.
$$

4. **Compute the normal magnitude.** Use $a_N=\sqrt{|\vec a|^2-a_T^2}$ and $|\vec a|^2=0^2+2^2+6^2=40$:

$$
a_N=\sqrt{40-\frac{22^2}{14}}=\sqrt{\frac{560-484}{14}}=\sqrt{\frac{76}{14}}=\sqrt{\frac{38}{7}}.
$$

5. **Check the decomposition.** $a_T^2+a_N^2=484/14+76/14=40=|\vec a|^2$. Hence the tangential and normal acceleration components at $t=1$ are exactly those stated.
:::
::::
::::problem[Problem 4.M10 challenge]{difficulty=challenge}
A particle moves with constant speed $v$ along a curve with curvature $\kappa$. Show that $|\vec{a}|=\kappa v^2$.

:::solution[Solution]
**Answer:** $|\mathbf a|=\kappa v^2$ for constant speed $v$.

1. **Use the tangential-normal decomposition.** For a regular twice-differentiable curve, acceleration satisfies $\vec a=a_T\mathbf T+a_N\mathbf N$, where $a_T=d|\vec v|/dt$ and $a_N=\kappa|\vec v|^2$.
2. **Apply the constant-speed hypothesis.** If $|\vec v(t)|=v$ is constant, then $a_T=dv/dt=0$.
3. **Eliminate the tangential contribution:**

$$
\vec a=0\mathbf T+\kappa v^2\mathbf N=\kappa v^2\mathbf N.
$$

4. **Take magnitudes.** Since $|\mathbf N|=1$ wherever the principal normal is defined, and curvature $\kappa\ge0$,

$$
|\vec a|=|\kappa v^2\mathbf N|=\kappa v^2.
$$

5. **Conclude.** Constant speed removes acceleration along the direction of motion, leaving only the normal acceleration associated with the curve's bending. The identity also gives zero acceleration when the constant-speed motion follows a straight line with $\kappa=0$.
:::
::::
★

Extended Drill — 20 Mastery Problems (selected enrichment; not all on Test 3)

Topics: vector function domains & limits, derivatives & integrals, arc length, curvature, TNB frame, and motion (velocity, acceleration, $a_T$/$a_N$ decomposition). Attempt each problem first.

::::problem[F1 — Domain of a Vector Function]{difficulty=standard}
Find the domain of $\vec{r}(t) = \left\langle \sqrt{4-t^2},\; \ln(t+1),\; \dfrac{1}{t}\right\rangle$.

:::solution[Solution]
**Answer:** Domain $(-1,0)\cup(0,2]$.

1. **Find restrictions from each component separately.**

Component 1: $\sqrt{4-t^2}$ requires $4-t^2\ge0 \Rightarrow t^2\le4 \Rightarrow -2\le t\le2$.

Component 2: $\ln(t+1)$ requires $t+1>0 \Rightarrow t>-1$.

Component 3: $1/t$ requires $t\ne0$.

2. **Intersect all three restrictions.**

$$
-2\le t\le2 \quad\cap\quad t>-1 \quad\cap\quad t\ne0
$$

Result: $-1 < t \le 2,\; t\ne0$, written as $(-1,0)\cup(0,2]$.

**Pitfall:**
Pitfall:

The domain is the intersection of component domains, not the union. Missing any one restriction gives wrong answers.
:::
::::

::::problem[F2 — Limit of a Vector Function]{difficulty=standard}
Evaluate $\displaystyle\lim_{t\to 0}\left\langle \frac{\sin 3t}{t},\; e^{2t}-1,\; \frac{1-\cos t}{t}\right\rangle$.

:::solution[Solution]
**Answer:** $\langle3,0,0\rangle$.

1. **Limits are taken component-wise.**

Component 1: $\displaystyle\lim_{t\to0}\frac{\sin 3t}{t} = \lim_{t\to0}\frac{\sin 3t}{3t}\cdot 3 = 1\cdot 3 = 3$.

Component 2: $\displaystyle\lim_{t\to0}(e^{2t}-1)$. At $t=0$: $e^0-1=0$. Direct substitution works: $0$.

Component 3: $\displaystyle\lim_{t\to0}\frac{1-\cos t}{t}$. This is a standard limit: $\displaystyle\lim_{t\to0}\frac{1-\cos t}{t}=0$ (use L'Hôpital or the known result $(1-\cos t)/t^2\to 1/2$, which implies $(1-\cos t)/t\to0$).

2. **Combine.**

$$
\lim_{t\to0}\vec{r}(t) = \langle 3,\,0,\,0\rangle
$$
:::
::::

::::problem[F3 — Derivative of a Vector Function]{difficulty=standard}
Differentiate $\vec{r}(t) = \langle t^3,\, e^{2t},\, \sin t\cdot\cos t\rangle$ and find the unit tangent vector at $t=0$.

:::solution[Solution]
**Answer:** $\mathbf r\prime(0)=\langle0,2,1\rangle$, $\mathbf T(0)=\langle0,2/\sqrt5,1/\sqrt5\rangle$.

1. **Differentiate componentwise.** The vector function is smooth for all real $t$, so its derivative is found by differentiating each coordinate. The power rule gives $(t^3)'=3t^2$, and the chain rule gives $(e^{2t})'=2e^{2t}$.
2. **Apply the product rule to the third coordinate.** For $\sin t\cos t$,

$$
\frac{d}{dt}(\sin t\cos t)=\cos t\cos t+\sin t(-\sin t)=\cos^2t-\sin^2t=\cos(2t).
$$

   Thus $\mathbf r'(t)=\langle3t^2,2e^{2t},\cos(2t)\rangle$.
3. **Evaluate at zero.** Using $e^0=1$ and $\cos0=1$, get $\mathbf r'(0)=\langle0,2,1\rangle$.
4. **Normalize to find the unit tangent.** The speed is $|\mathbf r'(0)|=\sqrt{0^2+2^2+1^2}=\sqrt5>0$, so the tangent exists and

$$
\mathbf T(0)=\frac{\mathbf r'(0)}{|\mathbf r'(0)|}=\left\langle0,\frac2{\sqrt5},\frac1{\sqrt5}\right\rangle.
$$

5. **Conclude.** The derivative and unit tangent are those stated, and the tangent has magnitude one.
:::
::::

::::problem[F4 — Integral of a Vector Function]{difficulty=standard}
Compute $\displaystyle\int_0^{\pi/2}\langle \cos t,\; t\sin t,\; te^t\rangle\,dt$.

:::solution[Solution]
**Answer:** $\langle1,1,(\pi/2-1)e^{\pi/2}+1\rangle$.

1. **Integrate component-wise.**

Component 1: $\displaystyle\int_0^{\pi/2}\cos t\,dt = [\sin t]_0^{\pi/2} = 1-0 = 1$.

Component 2: $\displaystyle\int_0^{\pi/2}t\sin t\,dt$. Integration by parts: $u=t$, $dv=\sin t\,dt$, so $du=dt$, $v=-\cos t$:

$$
= \big[-t\cos t\big]_0^{\pi/2}+\int_0^{\pi/2}\cos t\,dt = \left(-\frac{\pi}{2}\cos\frac{\pi}{2}+0\right)+[\sin t]_0^{\pi/2} = 0+1 = 1
$$

Component 3: $\displaystyle\int_0^{\pi/2}te^t\,dt$. IBP: $u=t$, $dv=e^t\,dt$:

$$
= [te^t]_0^{\pi/2}-\int_0^{\pi/2}e^t\,dt = \frac{\pi}{2}e^{\pi/2}-[e^t]_0^{\pi/2} = \frac{\pi}{2}e^{\pi/2}-(e^{\pi/2}-1) = \left(\frac{\pi}{2}-1\right)e^{\pi/2}+1
$$

2. **Result.**

$$
\int_0^{\pi/2}\vec{r}(t)\,dt = \left\langle 1,\;1,\;\left(\tfrac{\pi}{2}-1\right)e^{\pi/2}+1\right\rangle
$$
:::
::::

::::problem[F5 — Product Rule for Vector Functions]{difficulty=challenge}
Given $\vec{u}(t)=\langle t,t^2,0\rangle$ and $\vec{v}(t)=\langle 1,t,-t\rangle$, find $\dfrac{d}{dt}[\vec{u}\cdot\vec{v}]$ two ways: directly and via the product rule. Verify they match.

:::solution[Solution]
**Answer:** $1+3t^2$

1. **Compute $\vec{u}\cdot\vec{v}$ then differentiate.**

$$
\vec{u}\cdot\vec{v} = t\cdot1+t^2\cdot t+0\cdot(-t) = t+t^3
$$



$$
\frac{d}{dt}(t+t^3) = 1+3t^2
$$

2. **Dot product rule: $\frac{d}{dt}[\vec{u}\cdot\vec{v}] = \vec{u}'\cdot\vec{v}+\vec{u}\cdot\vec{v}'$.**

$$
\vec{u}'=\langle 1,2t,0\rangle,\quad\vec{v}'=\langle 0,1,-1\rangle
$$



$$
\vec{u}'\cdot\vec{v} = 1+2t^2+0 = 1+2t^2
$$



$$
\vec{u}\cdot\vec{v}' = 0+t^2+0 = t^2
$$



$$
\frac{d}{dt}[\vec{u}\cdot\vec{v}] = (1+2t^2)+t^2 = 1+3t^2\checkmark
$$

**Note:**
Three product rules to know:

scalar×vector, dot product, and cross product (order matters for cross!). All follow the same Leibniz structure $(fg)' = f'g + fg'$.
:::
::::

::::problem[F6 — Arc Length of a Space Curve]{difficulty=challenge}
Find the arc length of $\vec{r}(t) = \langle 2\cos t,\, 2\sin t,\, 3t\rangle$ for $0\le t\le 2\pi$.

:::solution[Solution]
**Answer:** $2\pi\sqrt{13}$

1. **Compute $\vec{r}'(t)$.**

$$
\vec{r}'(t) = \langle -2\sin t,\; 2\cos t,\; 3\rangle
$$

2. **Compute the speed $|\vec{r}'(t)|$.**

$$
|\vec{r}'(t)| = \sqrt{4\sin^2 t+4\cos^2 t+9} = \sqrt{4(\sin^2t+\cos^2t)+9} = \sqrt{4+9} = \sqrt{13}
$$

  The speed is constant — the curve is a circular helix.

3. **Integrate.**

$$
L = \int_0^{2\pi}\sqrt{13}\,dt = \sqrt{13}\cdot 2\pi = 2\pi\sqrt{13}
$$

**Note:**
Intuition:

A helix wraps around a cylinder. The arc length is like the hypotenuse of a right triangle with "horizontal" leg $2\pi\cdot 2 = 4\pi$ (circumference) and "vertical" leg $3\cdot 2\pi = 6\pi$ (rise). $\sqrt{(4\pi)^2+(6\pi)^2}=\pi\sqrt{52}=2\pi\sqrt{13}$. Equivalently, the constant speed is $\sqrt{4+9}=\sqrt{13}$ per radian, and the elapsed parameter interval is $2\pi$.
:::
::::

::::problem[F7 — Unit Tangent and Normal Vectors]{difficulty=challenge}
For $\vec{r}(t)=\langle t,\,t^2,\,0\rangle$, find the unit tangent vector $\hat{T}(t)$ and the unit normal vector $\hat{N}(t)$ at $t=1$.

:::solution[Solution]
**Answer:** $\mathbf T(1)=\langle1,2,0\rangle/\sqrt5$, $\mathbf N(1)=\langle-2,1,0\rangle/\sqrt5$.

1. **$\vec{r}'(t)$ and speed.**

$$
\vec{r}'(t)=\langle 1,2t,0\rangle,\qquad |\vec{r}'(t)| = \sqrt{1+4t^2}
$$

2. **Unit tangent.**

$$
\hat{T}(t) = \frac{\langle 1,2t,0\rangle}{\sqrt{1+4t^2}}
$$

  At $t=1$: $\hat{T}(1)=\dfrac{\langle 1,2,0\rangle}{\sqrt{5}}$.

3. **Differentiate $\hat{T}$ to find $\hat{N}$.**

$$
\hat{T}(t) = \frac{1}{\sqrt{1+4t^2}}\langle 1,2t,0\rangle
$$

  Use the quotient rule (or product rule with the scalar factor):


$$
\hat{T}'(t) = -\frac{4t}{(1+4t^2)^{3/2}}\langle 1,2t,0\rangle + \frac{1}{\sqrt{1+4t^2}}\langle 0,2,0\rangle
$$

  At $t=1$:


$$
\hat{T}'(1) = -\frac{4}{5^{3/2}}\langle 1,2,0\rangle + \frac{1}{\sqrt{5}}\langle 0,2,0\rangle = \frac{1}{5\sqrt{5}}\left(-4\langle 1,2,0\rangle + 5\langle 0,2,0\rangle\right)
$$



$$
= \frac{1}{5\sqrt{5}}\langle -4,\,-8+10,\,0\rangle = \frac{1}{5\sqrt{5}}\langle -4,2,0\rangle
$$

4. **Normalize.**

$$
|\hat{T}'(1)| = \frac{1}{5\sqrt{5}}\sqrt{16+4} = \frac{\sqrt{20}}{5\sqrt{5}} = \frac{2\sqrt{5}}{5\sqrt{5}} = \frac{2}{5}
$$



$$
\hat{N}(1) = \frac{\hat{T}'(1)}{|\hat{T}'(1)|} = \frac{\langle -4,2,0\rangle/(5\sqrt{5})}{2/5} = \frac{\langle -4,2,0\rangle}{2\sqrt{5}} = \frac{1}{\sqrt{5}}\langle -2,1,0\rangle
$$

**Note:**
$\hat{N}$ always points toward the "inside" of the curve

(toward the center of curvature). Here it points in the $-x,+y$ direction — toward the concave side of the parabola at $t=1$.
:::
::::

::::problem[F8 — Curvature via Cross-Product Formula]{difficulty=challenge}
Find the curvature of $\vec{r}(t)=\langle t,\,t^2,\,0\rangle$ at $t=1$.

:::solution[Solution]
**Answer:** $2/(5\sqrt5)$

1. **Use the formula $\kappa = \dfrac{|\vec{r}'\times\vec{r}''|}{|\vec{r}'|^3}$.**

2. **Compute derivatives.**

$$
\vec{r}'(t)=\langle 1,2t,0\rangle,\qquad\vec{r}''(t)=\langle 0,2,0\rangle
$$

  At $t=1$: $\vec{r}'(1)=\langle 1,2,0\rangle$, $\vec{r}''(1)=\langle 0,2,0\rangle$.

3. **Cross product.**

$$
\vec{r}'\times\vec{r}'' = \begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\1&2&0\\0&2&0\end{vmatrix} = \hat{\imath}(0-0)-\hat{\jmath}(0-0)+\hat{k}(2-0) = \langle 0,0,2\rangle
$$



$$
|\vec{r}'\times\vec{r}''| = 2
$$

4. **Speed cubed.**

$$
|\vec{r}'(1)|=\sqrt{5},\qquad |\vec{r}'(1)|^3 = 5\sqrt{5}
$$

5. **Curvature.**

$$
\kappa = \frac{2}{5\sqrt{5}} = \frac{2}{5^{3/2}} = \frac{2\sqrt{5}}{25}
$$

**Note:**
For plane curves $y=f(x)$:

$\kappa = \dfrac{|f''|}{(1+f'^2)^{3/2}}$. With $y=x^2$ at $x=1$: $\kappa = \dfrac{2}{(1+4)^{3/2}} = \dfrac{2}{5\sqrt{5}}$. Same answer, as expected.
:::
::::

::::problem[F9 — Binormal Vector & TNB Frame]{difficulty=challenge}
For the helix $\vec{r}(t) = \langle \cos t,\sin t,t\rangle$, find $\hat{T}$, $\hat{N}$, and $\hat{B}$ at $t=0$.

:::solution[Solution]
**Answer:** $\mathbf T(0)=\langle0,1,1\rangle/\sqrt2$, $\mathbf N(0)=\langle-1,0,0\rangle$, $\mathbf B(0)=\langle0,-1,1\rangle/\sqrt2$.

1. **$\vec{r}'(t)$ and speed.**

$$
\vec{r}'(t)=\langle -\sin t,\cos t,1\rangle,\qquad |\vec{r}'|=\sqrt{\sin^2t+\cos^2t+1}=\sqrt{2}
$$

2. **Unit tangent at $t=0$.**

$$
\hat{T}(0)=\frac{\langle 0,1,1\rangle}{\sqrt{2}} = \left\langle 0,\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right\rangle
$$

3. **$\hat{T}'(t)$ and unit normal.**

$$
\hat{T}(t)=\frac{1}{\sqrt{2}}\langle -\sin t,\cos t,1\rangle
$$



$$
\hat{T}'(t)=\frac{1}{\sqrt{2}}\langle -\cos t,-\sin t,0\rangle
$$

  At $t=0$: $\hat{T}'(0)=\dfrac{1}{\sqrt{2}}\langle -1,0,0\rangle$. Magnitude: $|\hat{T}'(0)|=\dfrac{1}{\sqrt{2}}$.

$$
\hat{N}(0)=\frac{\hat{T}'(0)}{|\hat{T}'(0)|}=\frac{\langle-1,0,0\rangle/\sqrt{2}}{1/\sqrt{2}}=\langle -1,0,0\rangle
$$

4. **Binormal.**

$$
\hat{B}(0)=\hat{T}(0)\times\hat{N}(0)=\left\langle 0,\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right\rangle\times\langle -1,0,0\rangle
$$



$$
=\begin{vmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\0&1/\sqrt{2}&1/\sqrt{2}\\-1&0&0\end{vmatrix}=\hat{\imath}(0-0)-\hat{\jmath}(0+1/\sqrt{2})+\hat{k}(0+1/\sqrt{2}) = \left\langle 0,-\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right\rangle
$$

**Note:**
The TNB frame

($\hat{T},\hat{N},\hat{B}$) is an orthonormal right-handed basis that moves with the curve. $\hat{T}$ points forward, $\hat{N}$ toward the center of curvature, $\hat{B}=\hat{T}\times\hat{N}$ completes the frame.
:::
::::

::::problem[F10 — Osculating Circle]{difficulty=challenge}
Find the radius and center of the osculating circle to $\vec{r}(t)=\langle t,t^2,0\rangle$ at $t=0$.

:::solution[Solution]
**Answer:** Radius $1/2$, center $(0,1/2,0)$.

1. **Curvature at $t=0$.**

$$
\vec{r}'(0)=\langle 1,0,0\rangle,\quad\vec{r}''(0)=\langle 0,2,0\rangle
$$



$$
\vec{r}'\times\vec{r}''=\langle 0,0,2\rangle,\quad|\vec{r}'\times\vec{r}''|=2,\quad|\vec{r}'(0)|=1
$$



$$
\kappa(0)=\frac{2}{1}=2
$$

2. **Radius of curvature.**

$$
\rho = \frac{1}{\kappa} = \frac{1}{2}
$$

3. **Unit normal at $t=0$.**

$$
\hat{T}'(t)=\frac{d}{dt}\left[\langle 1,2t,0\rangle/\sqrt{1+4t^2}\right]
$$

  At $t=0$: $\hat{T}(0)=\langle 1,0,0\rangle$, $\hat{T}'(0)=\langle 0,2,0\rangle$, $|\hat{T}'(0)|=2$, so $\hat{N}(0)=\langle 0,1,0\rangle$.

4. **Center of osculating circle.** Move from the curve point in the $\hat{N}$ direction by distance $\rho$:

$$
\text{center} = \vec{r}(0)+\frac{1}{\kappa}\hat{N}(0) = \langle 0,0,0\rangle+\frac{1}{2}\langle 0,1,0\rangle = \left(0,\frac{1}{2},0\right)
$$

**Note:**
Verification:

The circle of radius $1/2$ centered at $(0,1/2)$ is tangent to the parabola $y=x^2$ at the origin — the parabola "matches" this circle to second order there.
:::
::::

::::problem[F11 — Velocity and Acceleration from Position]{difficulty=standard}
An object has position $\vec{r}(t)=\langle t^2,\, 2t,\, t^3/3\rangle$. Find velocity, speed, and acceleration at $t=1$.

:::solution[Solution]
**Answer:** $\mathbf v(1)=\langle2,2,1\rangle$, speed $3$, $\mathbf a(1)=\langle2,0,2\rangle$.

1. **Start with the definitions.** Velocity is $\vec v(t)=\vec r\,'(t)$, speed is $|\vec v(t)|$, and acceleration is $\vec a(t)=\vec r\,''(t)$. The polynomial position function is differentiable for every $t$.
2. **Differentiate position componentwise:**

$$
\vec v(t)=\left\langle\frac{d}{dt}t^2,\frac{d}{dt}(2t),\frac{d}{dt}\left(\frac{t^3}{3}\right)\right\rangle=\langle2t,2,t^2\rangle.
$$

3. **Evaluate velocity and find its magnitude at $t=1$:**

$$
\vec v(1)=\langle2,2,1\rangle,\qquad|\vec v(1)|=\sqrt{2^2+2^2+1^2}=\sqrt9=3.
$$

4. **Differentiate velocity once more:**

$$
\vec a(t)=\langle2,0,2t\rangle,\qquad\vec a(1)=\langle2,0,2\rangle.
$$

5. **Conclude.** At $t=1$ the object moves in direction $\langle2,2,1\rangle$ with scalar speed $3$ and accelerates along $\langle2,0,2\rangle$.
:::
::::

::::problem[F12 — Recover Position from Acceleration]{difficulty=challenge}
A particle has acceleration $\vec{a}(t)=\langle 0,\,0,\,-g\rangle$ (gravity), initial velocity $\vec{v}(0)=\langle v_0\cos\theta,\,0,\,v_0\sin\theta\rangle$, and initial position $\vec{r}(0)=\langle 0,0,0\rangle$. Find $\vec{r}(t)$.

:::solution[Solution]
**Answer:** $\mathbf r(t)=\langle v_0t\cos\theta,0,v_0t\sin\theta-gt^2/2\rangle$.

1. **Integrate $\vec{a}$ to get $\vec{v}$.**

$$
\vec{v}(t)=\int\vec{a}\,dt = \langle 0,0,-gt\rangle + \vec{C}_1
$$

  Apply $\vec{v}(0)=\langle v_0\cos\theta,0,v_0\sin\theta\rangle$: $\vec{C}_1 = \langle v_0\cos\theta,0,v_0\sin\theta\rangle$.

$$
\vec{v}(t)=\langle v_0\cos\theta,\;0,\;v_0\sin\theta - gt\rangle
$$

2. **Integrate $\vec{v}$ to get $\vec{r}$.**

$$
\vec{r}(t)=\int\vec{v}\,dt = \langle v_0\cos\theta\cdot t,\;0,\;v_0\sin\theta\cdot t - \tfrac{1}{2}gt^2\rangle + \vec{C}_2
$$

  Apply $\vec{r}(0)=\langle 0,0,0\rangle$: $\vec{C}_2=\vec{0}$.

$$
\vec{r}(t) = \langle v_0\cos\theta\cdot t,\;0,\;v_0\sin\theta\cdot t - \tfrac{1}{2}gt^2\rangle
$$

**Note:**
This is projectile motion in the $xz$-plane.

The horizontal component $x=v_0\cos\theta\cdot t$ is linear; the vertical $z=v_0\sin\theta\cdot t - \frac{1}{2}gt^2$ is a downward parabola. The trajectory is a parabola in space.
:::
::::

::::problem[F13 — Tangential and Normal Acceleration Components]{difficulty=challenge}
For $\vec{r}(t)=\langle t^2,t,t^3\rangle$ at $t=1$, find the tangential component $a_T$ and normal component $a_N$ of acceleration.

:::solution[Solution]
**Answer:** $a_T=22/\sqrt{14}$, $a_N=\sqrt{38/7}$.

1. **Compute velocity and acceleration.** Since $\vec v=\vec r'$ and $\vec a=\vec r''$,

$$
\vec v(t)=\langle2t,1,3t^2\rangle,\qquad\vec a(t)=\langle2,0,6t\rangle.
$$

   At $t=1$, $\vec v=\langle2,1,3\rangle$, $\vec a=\langle2,0,6\rangle$, and speed is $\sqrt{2^2+1^2+3^2}=\sqrt{14}>0$. Thus the tangential-normal formulas apply.
2. **Find tangential acceleration using a dot product:**

$$
a_T=\frac{\vec v\cdot\vec a}{|\vec v|}=\frac{2(2)+1(0)+3(6)}{\sqrt{14}}=\frac{22}{\sqrt{14}}.
$$

3. **Compute normal acceleration with a cross product:**

$$
\vec v\times\vec a=\langle1(6)-3(0),\,3(2)-2(6),\,2(0)-1(2)\rangle=\langle6,-6,-2\rangle.
$$

   Its magnitude is $\sqrt{36+36+4}=\sqrt{76}$, giving

$$
a_N=\frac{|\vec v\times\vec a|}{|\vec v|}=\sqrt{\frac{76}{14}}=\sqrt{\frac{38}{7}}.
$$

4. **Check with Pythagoras.** $|\vec a|^2=4+36=40$, while $a_T^2+a_N^2=484/14+76/14=560/14=40$.
5. **Conclude.** The tangential and normal acceleration components match both requested values and the acceleration decomposition.
:::
::::

::::problem[F14 — Projectile Range and Max Height]{difficulty=standard}
A ball is launched from ground level at $60°$ with initial speed 20 m/s (take $g=10$ m/s²). Find the maximum height, the time of flight, and the range.

:::solution[Solution]
**Answer:** Maximum height $15$ m, flight $2\sqrt3$ s, range $20\sqrt3$ m.

1. **Resolve the initial velocity.** For a projectile without air resistance, $x(t)=v_{0x}t$ and $z(t)=v_{0z}t-gt^2/2$. Here

$$
v_{0x}=20\cos60^\circ=10,\qquad v_{0z}=20\sin60^\circ=10\sqrt3.
$$

2. **Find the time of maximum height.** Vertical velocity is $v_z(t)=10\sqrt3-10t$. At the peak $v_z=0$, hence $t_{\rm peak}=\sqrt3$ s.
3. **Compute the peak height:**

$$
z(\sqrt3)=10\sqrt3(\sqrt3)-5(\sqrt3)^2=30-15=15\text{ m}.
$$

4. **Find the nonzero landing time.** Since launch and landing are at height zero,

$$
0=z(t)=10\sqrt3\,t-5t^2=5t(2\sqrt3-t).
$$

   The roots are $t=0$ at launch and $t=2\sqrt3$ s at landing.
5. **Find horizontal range.** Since horizontal speed remains $10$ m/s, $R=x(2\sqrt3)=10(2\sqrt3)=20\sqrt3$ m. Thus the three requested results are $15$ m, $2\sqrt3$ s, and $20\sqrt3$ m.
:::
::::

::::problem[F15 — Chain Rule for Vector Functions]{difficulty=challenge}
Let $\vec{r}(t)=\langle \sin t, \cos t, e^t\rangle$ and $s(t)=t^2$. Find $\dfrac{d}{dt}[\vec{r}(s(t))]$ two ways.

:::solution[Solution]
**Answer:** $2t\langle\cos(t^2),-\sin(t^2),e^{t^2}\rangle$.

1. **Method one: substitute before differentiating.** The composition replaces the input of every component of $\vec r$ by $s(t)=t^2$:

$$
\vec r(s(t))=\langle\sin(t^2),\cos(t^2),e^{t^2}\rangle.
$$

2. **Differentiate every component using the scalar chain rule.** The inner derivative is $(t^2)'=2t$, so

$$
\frac{d}{dt}\vec r(s(t))=\langle2t\cos(t^2),-2t\sin(t^2),2te^{t^2}\rangle.
$$

3. **Method two: apply the vector chain rule.** For differentiable $\vec r$ and $s$, we have $\frac{d}{dt}\vec r(s(t))=\vec r'(s(t))\,s'(t)$. Here

$$
\vec r'(u)=\langle\cos u,-\sin u,e^u\rangle,\qquad s'(t)=2t.
$$

4. **Substitute and multiply by the inner derivative:**

$$
\vec r'(t^2)(2t)=2t\langle\cos(t^2),-\sin(t^2),e^{t^2}\rangle.
$$

5. **Conclude.** Both methods give the same derivative, verifying the chain rule component by component.
:::
::::

::::problem[F16 — Curve Lying on a Surface]{difficulty=challenge}
Show that the curve $\vec{r}(t)=\langle \cos t,\sin t, \sin t\rangle$ lies on the cylinder $x^2+y^2=1$ and also on the plane $y=z$.

:::solution[Solution]
**Answer:** $x^2+y^2=1$ and $z=y$ hold identically.

1. **Cylinder $x^2+y^2=1$.** Substitute $x=\cos t$, $y=\sin t$:

$$
x^2+y^2 = \cos^2t+\sin^2t = 1\checkmark
$$

The curve satisfies the cylinder equation for all $t$. ✓

2. **Plane $y=z$.** We have $y=\sin t$ and $z=\sin t$, so $y=z$ always. ✓

**Conclusion:** The curve is the intersection of the unit cylinder with the plane $y=z$. Geometrically it is an ellipse in the plane $z=y$ (its projection onto the $xy$-plane is the unit circle).

**Note:**
General technique:

To find a curve on two surfaces, parameterize one surface and impose the second surface's equation to find the parameter relationship.
:::
::::

::::problem[F17 — Curvature of a Plane Curve (Formula Method)]{difficulty=challenge}
Find the curvature of $y = \sin x$ at $x = \pi/2$.

:::solution[Solution]
**Answer:** $\kappa(\pi/2)=1$.

1. **Use the plane-curve curvature formula.**

$$
\kappa = \frac{|y''|}{(1+(y')^2)^{3/2}}
$$

2. **Compute derivatives.**

$$
y' = \cos x,\quad y'' = -\sin x
$$

  At $x=\pi/2$: $y'=0$, $y''=-1$.

3. **Substitute.**

$$
\kappa = \frac{|-1|}{(1+0)^{3/2}} = \frac{1}{1} = 1
$$

4. **Interpret.** At $x=\pi/2$ (the peak of $\sin x$), the curvature is 1, meaning the osculating circle has radius 1. The curve bends exactly as sharply as a unit circle at its peak.

**Note:**
At a local max or min

of $y=f(x)$, $y'=0$, so $\kappa = |y''|$ — the curvature is simply the absolute second derivative. The curve looks most like a parabola (or circle) there.
:::
::::

::::problem[F18 — Arc Length as a Function of Parameter]{difficulty=challenge}
For $\vec{r}(t)=\langle e^t\cos t,\,e^t\sin t,\,e^t\rangle$, compute the arc length from $t=0$ to $t=T$. Simplify as much as possible.

:::solution[Solution]
**Answer:** $L=\sqrt3\,|e^T-1|$ (for $T\ge0$, this is $\sqrt3(e^T-1)$).

1. **Use arc length for a smooth space curve.** Each component of $\vec r$ is differentiable for every real $t$, so the length between parameters $0$ and $T$ is the integral of speed over the interval between them.
2. **Differentiate by the product rule:**

$$
\vec r'(t)=\langle e^t(\cos t-\sin t),e^t(\sin t+\cos t),e^t\rangle.
$$

3. **Simplify the speed.** Since $e^t>0$,

$$
|\vec r'|=e^t\sqrt{(\cos t-\sin t)^2+(\sin t+\cos t)^2+1}.
$$

   Expand the squares: $\cos^2t-2\sin t\cos t+\sin^2t$ and $\sin^2t+2\sin t\cos t+\cos^2t$. Their sum is $2$, so $|\vec r'|=\sqrt3\,e^t$.
4. **Integrate with the correct endpoint order.** For $T\ge0$,

$$
L=\int_0^T\sqrt3\,e^t\,dt=\sqrt3[e^t]_0^T=\sqrt3(e^T-1).
$$

   If $T<0$, integrate from $T$ to $0$ instead, obtaining $\sqrt3(1-e^T)$.
5. **Conclude.** Both cases are $L=\sqrt3|e^T-1|$, the nonnegative arc length for any real $T$.
:::
::::

::::problem[F19 — Kepler's Second Law (Constant Areal Velocity)]{difficulty=challenge}
A planet moves so that its position satisfies the central force condition $\vec{a} = f(t)\vec{r}$ (acceleration always points toward/away from the origin). Show that $\vec{r}\times\vec{v}$ is constant (i.e., angular momentum is conserved).

:::solution[Solution]
**Answer:** $d(\mathbf r\times\mathbf v)/dt=0$ for a central force.

1. **Differentiate $\vec{r}\times\vec{v}$ with respect to $t$.**

$$
\frac{d}{dt}(\vec{r}\times\vec{v}) = \vec{r}'\times\vec{v}+\vec{r}\times\vec{v}'
$$

2. **Simplify each term.**

First term: $\vec{r}'\times\vec{v} = \vec{v}\times\vec{v} = \vec{0}$ (cross product of a vector with itself is zero).

Second term: $\vec{r}\times\vec{v}' = \vec{r}\times\vec{a} = \vec{r}\times(f(t)\vec{r}) = f(t)(\vec{r}\times\vec{r}) = \vec{0}$ (again, cross product with itself).

3. **Conclude.**

$$
\frac{d}{dt}(\vec{r}\times\vec{v}) = \vec{0}+\vec{0} = \vec{0}
$$

  Therefore $\vec{r}\times\vec{v} = \vec{h}$ (constant vector). Since $|\vec{r}\times\vec{v}| = |\vec{r}||\vec{v}|\sin\theta$ is twice the areal sweep rate, equal areas are swept in equal times. $\blacksquare$

**Note:**
Physics connection:

$\vec{L}=m(\vec{r}\times\vec{v})$ is angular momentum. Central forces (gravity, electrostatics) produce no torque about the center, so angular momentum is conserved.
:::
::::

::::problem[F20 — Full Motion Analysis]{difficulty=challenge}
A particle moves with $\vec{r}(t)=\langle 3\cos t,\,3\sin t,\,4t\rangle$. Find: (a) speed, (b) arc length from $t=0$ to $t=2\pi$, (c) curvature $\kappa$, and (d) $a_T$ and $a_N$.

:::solution[Solution]
**Answer:** Speed $5$, length $10\pi$, curvature $3/25$, $a_T=0$, $a_N=3$.

1. **Compute velocity and speed.** Differentiating the smooth helix gives

$$
\vec v(t)=\langle-3\sin t,3\cos t,4\rangle,\quad |\vec v|=\sqrt{9\sin^2t+9\cos^2t+16}=5>0.
$$

2. **Integrate speed for arc length.** Because the curve is regular on $[0,2\pi]$,

$$
L=\int_0^{2\pi}|\vec v|\,dt=\int_0^{2\pi}5\,dt=5(2\pi)=10\pi.
$$

3. **Calculate acceleration and the curvature numerator.** Differentiate again: $\vec a=\langle-3\cos t,-3\sin t,0\rangle$. Compute the ordered cross product:

$$
\vec v\times\vec a=\langle12\sin t,-12\cos t,9\rangle.
$$

   Its magnitude is $\sqrt{144(\sin^2t+\cos^2t)+81}=\sqrt{225}=15$.
4. **Use the curvature formula.** $\kappa=|\vec v\times\vec a|/|\vec v|^3=15/125=3/25$.
5. **Decompose acceleration.** The tangential component is $a_T=(\vec v\cdot\vec a)/|\vec v|=[9\sin t\cos t-9\cos t\sin t]/5=0$. The normal magnitude is $a_N=\kappa|\vec v|^2=(3/25)(25)=3$. Therefore the helix has constant speed $5$, arc length $10\pi$, curvature $3/25$, and acceleration components $0$ and $3$.
:::
::::
