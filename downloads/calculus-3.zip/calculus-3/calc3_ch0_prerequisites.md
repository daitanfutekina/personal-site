---
title: "Calculus Prerequisites"
crumb: "MA 2733 · Chapter 0"
meta:
  - "Est. study time: ~5–6 hrs total"
  - "Work only the sections where you feel gaps"
  - "Updated: November 2026"
source: "markdown"
---

## Overview

MA 2733 does not review prerequisites during lecture. When an integral appears inside a convergence test, or a trig identity needs to be applied inside a polar area formula, the assumption is that you already own it. This chapter collects every such tool in one place, taught at the depth you'll actually need — not just the formula, but the reasoning behind it and the common ways students misapply it.

**How to use this chapter:** run down the section headers and identify your weak spots. If a u-substitution or partial fraction feels shaky, work all of §0.5. If your trig is solid, skim §0.2 and move on. The mixed practice set at the end is a good diagnostic — try those problems first and trace any mistakes back to their source section.

:::callout-key[Prerequisites for this chapter]
- MA 1713 Calculus I — derivatives, antiderivatives, the Fundamental Theorem
- MA 1723 Calculus II — integration techniques, geometric applications, series introduction
:::

## 0.1 Functions, Graphs, and Algebraic Reflexes

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Functions | Precalculus” — Khan Academy
:::

:::callout-intuition[Intuition]
A function is a rule: give it one input, get exactly one output. The *domain* is the set of inputs the rule will accept; the *range* is the set of outputs it can produce. These are not the same thing — the range depends on which inputs you actually feed in. A function $f: A \to B$ says "every input from set $A$ gives an output in set $B$," but not every element of $B$ has to be hit.

In MA 2733 the algebraic tools in this section appear constantly in disguise. Completing the square shows up when you need to identify a sphere equation (§0.8). Partial fractions are the key step in integrating rational functions, which appear in the Integral Test (Chapter 2). Inverse functions build the inverse-trig antiderivatives you'll use in trig substitution (§0.5). These are not isolated skills — they're the algebraic infrastructure everything else rests on.
:::

### Domain and range

When finding the domain of a function, ask: *what inputs would break the rule?* Three things break functions:

- **Division by zero** — exclude values where the denominator is zero.
- **Even roots of negatives** — $\sqrt{g(x)}$ requires $g(x) \geq 0$.
- **Logarithms of non-positives** — $\ln(g(x))$ requires $g(x) > 0$.

For composition $f(g(x))$, first restrict the domain so $g(x)$ is defined, then additionally require that $g(x)$ falls in the domain of $f$.

### Even and odd functions

A function is **even** if $f(-x) = f(x)$ for all $x$ in its domain (graph is symmetric about the $y$-axis). It is **odd** if $f(-x) = -f(x)$ (graph has 180° rotational symmetry about the origin). Why care? Because for even functions, $\int_{-a}^{a} f(x)\,dx = 2\int_0^a f(x)\,dx$, and for odd functions, $\int_{-a}^{a} f(x)\,dx = 0$ — symmetry can cut your work in half.

:::definition[Reference 0.1.1 — Exponential and Logarithm Laws]
These must be instant reflexes — you will use them to simplify limits, rewrite series terms, and manipulate integrands.

$$
e^{a+b} = e^a e^b \qquad e^{ab} = (e^a)^b \qquad e^0 = 1 \qquad \ln(ab) = \ln a + \ln b
$$
$$
\ln(a/b) = \ln a - \ln b \qquad \ln(a^r) = r\ln a \qquad \ln(e^x) = x \qquad e^{\ln x} = x
$$
$$
\text{Change of base:}\quad \log_b x = \frac{\ln x}{\ln b}
$$
The number $e$ itself is defined by $\displaystyle e = \lim_{n\to\infty}\left(1+\frac{1}{n}\right)^n \approx 2.71828\ldots$
:::

:::definition[Reference 0.1.2 — Inverse Trig: Domains and Ranges]
The inverse trig functions have *restricted* ranges by convention — there are many angles with $\sin\theta = 1/2$, but $\arcsin(1/2)$ is defined to be exactly $\pi/6$, not $5\pi/6$ or any other solution. This restriction is what makes them functions.

| Function | Domain | Range | Key value |
| --- | --- | --- | --- |
| $\arcsin x$ | $[-1,1]$ | $[-\tfrac{\pi}{2},\tfrac{\pi}{2}]$ | $\arcsin(1)=\tfrac{\pi}{2}$ |
| $\arccos x$ | $[-1,1]$ | $[0,\pi]$ | $\arccos(0)=\tfrac{\pi}{2}$ |
| $\arctan x$ | $(-\infty,\infty)$ | $(-\tfrac{\pi}{2},\tfrac{\pi}{2})$ | $\arctan(1)=\tfrac{\pi}{4}$ |
| $\text{arcsec}\, x$ | $|x|\geq 1$ | $[0,\pi]\setminus\{\tfrac{\pi}{2}\}$ | $\text{arcsec}(2)=\tfrac{\pi}{3}$ |
:::

:::definition[Reference 0.1.3 — Completing the Square and Partial Fractions]
**Completing the square** — works on any $ax^2 + bx + c$:

$$
ax^2 + bx + c = a\!\left(x + \frac{b}{2a}\right)^{\!2} + c - \frac{b^2}{4a}
$$
The technique: factor out $a$ from the quadratic terms, then add and subtract $(b/2a)^2$ inside.

**Partial fractions** — the setup depends on the type of factor in the denominator:

| Denominator factor | Partial fraction term(s) |
| --- | --- |
| Distinct linear: $(x-a)$ | $\dfrac{A}{x-a}$ |
| Repeated linear: $(x-a)^2$ | $\dfrac{A}{x-a}+\dfrac{B}{(x-a)^2}$ |
| Irreducible quadratic: $(x^2+bx+c)$ | $\dfrac{Ax+B}{x^2+bx+c}$ |
| Repeated quadratic: $(x^2+bx+c)^2$ | $\dfrac{Ax+B}{x^2+bx+c}+\dfrac{Cx+D}{(x^2+bx+c)^2}$ |

**Important:** if the degree of the numerator $\geq$ degree of the denominator, do polynomial long division *first*.
:::

:::callout-tip[Test relevance]
On Test 4, simplify rational expressions before comparing series. If a term behaves like $n^2/n^4$, write the comparison $b_n=1/n^2$, then prove $\lim a_n/b_n=1$. On Test 2, completing squares changes a space-surface equation into recognizable standard form.
:::

**Full partial-fraction check.** To integrate $\int\frac{3x+1}{x(x+1)}\,dx$, set $\frac{3x+1}{x(x+1)}=\frac A x+\frac B{x+1}$. Clearing gives $3x+1=A(x+1)+Bx$. At $x=0$, $A=1$; at $x=-1$, $-2=-B$, so $B=2$. Integrate each: $\ln|x|+2\ln|x+1|+C$. Differentiate to verify $1/x+2/(x+1)=(3x+1)/(x(x+1))$.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="Parabola y=3(x+2)^2-5 with vertex at minus two minus five">
<path class="fig-axis" d="M32.00 111.08 L128.67 111.08 L225.33 111.08 L322.00 111.08"/>
<path class="fig-curve" d="M81.03 34.92 L81.82 37.09 L82.61 39.23 L83.40 41.36 L84.19 43.47 L84.98 45.56 L85.77 47.63 L86.56 49.69 L87.35 51.73 L88.14 53.75 L88.93 55.75 L89.72 57.73 L90.51 59.70 L91.30 61.65 L92.09 63.58 L92.88 65.49 L93.67 67.39 L94.46 69.27 L95.25 71.12 L96.04 72.97 L96.83 74.79 L97.62 76.59 L98.41 78.38 L99.20 80.15 L99.99 81.90 L100.78 83.64 L101.57 85.35 L102.36 87.05 L103.15 88.73 L103.94 90.39 L104.73 92.04 L105.52 93.67 L106.31 95.28 L107.10 96.87 L107.89 98.44 L108.68 99.99 L109.47 101.53 L110.26 103.05 L111.05 104.55 L111.84 106.04 L112.63 107.50 L113.42 108.95 L114.21 110.38 L115.00 111.79 L115.79 113.19 L116.58 114.56 L117.37 115.92 L118.16 117.26 L118.95 118.58 L119.74 119.89 L120.53 121.18 L121.32 122.45 L122.11 123.70 L122.90 124.93 L123.69 126.15 L124.48 127.34 L125.27 128.52 L126.06 129.68 L126.85 130.83 L127.64 131.95 L128.43 133.06 L129.22 134.15 L130.01 135.22 L130.80 136.28 L131.59 137.32 L132.38 138.33 L133.17 139.34 L133.96 140.32 L134.75 141.28 L135.54 142.23 L136.33 143.16 L137.12 144.07 L137.92 144.96 L138.71 145.84 L139.50 146.70 L140.29 147.54 L141.08 148.36 L141.87 149.16 L142.66 149.95 L143.45 150.72 L144.24 151.47 L145.03 152.20 L145.82 152.92 L146.61 153.61 L147.40 154.29 L148.19 154.95 L148.98 155.60 L149.77 156.22 L150.56 156.83 L151.35 157.42 L152.14 157.99 L152.93 158.54 L153.72 159.08 L154.51 159.60 L155.30 160.10 L156.09 160.58 L156.88 161.05 L157.67 161.49 L158.46 161.92 L159.25 162.33 L160.04 162.72 L160.83 163.10 L161.62 163.46 L162.41 163.80 L163.20 164.12 L163.99 164.42 L164.78 164.71 L165.57 164.97 L166.36 165.22 L167.15 165.46 L167.94 165.67 L168.73 165.87 L169.52 166.04 L170.31 166.20 L171.10 166.35 L171.89 166.47 L172.68 166.58 L173.47 166.67 L174.26 166.74 L175.05 166.79 L175.84 166.83 L176.63 166.84 L177.42 166.84 L178.21 166.83 L179.00 166.79 L179.79 166.73 L180.58 166.66 L181.37 166.57 L182.16 166.46 L182.95 166.34 L183.74 166.20 L184.53 166.03 L185.32 165.85 L186.11 165.66 L186.90 165.44 L187.69 165.21 L188.48 164.96 L189.27 164.69 L190.06 164.40 L190.85 164.10 L191.64 163.78 L192.43 163.44 L193.22 163.08 L194.01 162.70 L194.80 162.31 L195.59 161.90 L196.38 161.47 L197.17 161.02 L197.96 160.55 L198.75 160.07 L199.54 159.57 L200.33 159.05 L201.12 158.51 L201.91 157.96 L202.70 157.39 L203.49 156.79 L204.28 156.19 L205.07 155.56 L205.86 154.92 L206.65 154.25 L207.44 153.57 L208.23 152.88 L209.02 152.16 L209.81 151.43 L210.60 150.67 L211.39 149.91 L212.18 149.12 L212.97 148.31 L213.76 147.49 L214.55 146.65 L215.34 145.79 L216.13 144.91 L216.92 144.02 L217.71 143.11 L218.50 142.18 L219.29 141.23 L220.08 140.26 L220.87 139.28 L221.66 138.28 L222.45 137.26 L223.24 136.22 L224.03 135.16 L224.82 134.09 L225.61 133.00 L226.40 131.89 L227.19 130.76 L227.98 129.62 L228.77 128.45 L229.56 127.27 L230.35 126.07 L231.14 124.86 L231.93 123.62 L232.72 122.37 L233.51 121.10 L234.30 119.81 L235.09 118.51 L235.88 117.18 L236.67 115.84 L237.46 114.48 L238.25 113.10 L239.04 111.71 L239.83 110.30 L240.62 108.87 L241.41 107.42 L242.20 105.95 L242.99 104.46 L243.78 102.96 L244.57 101.44 L245.36 99.90 L246.15 98.35 L246.94 96.77 L247.73 95.18 L248.52 93.57 L249.31 91.94 L250.10 90.30 L250.89 88.63 L251.68 86.95 L252.47 85.25 L253.26 83.54 L254.05 81.80 L254.84 80.05 L255.63 78.28 L256.42 76.49 L257.21 74.68 L258.00 72.86 L258.79 71.02 L259.58 69.16 L260.38 67.28 L261.17 65.38 L261.96 63.47 L262.75 61.54 L263.54 59.59 L264.33 57.62 L265.12 55.63 L265.91 53.63 L266.70 51.61 L267.49 49.57 L268.28 47.51 L269.07 45.44 L269.86 43.35 L270.65 41.23 L271.44 39.11 L272.23 36.96 L273.02 34.80"/>
</svg>
<figcaption>Completing the square reveals that $y=3x^2+12x+7$ has vertex $(-2,-5)$; changing the constant shifts the graph vertically but never changes its axis $x=-2$.</figcaption>
</figure>

### Choosing an algebraic move before computing

In a series problem, do not reach for the Ratio Test just because a denominator is complicated. First ask what the *dominant* power would be if you divided every term by the denominator's largest power of $n$. In the prerequisite chapter this is simply the same algebra used to divide rational functions by a power of $x$: every smaller power becomes a fraction that approaches zero. When factoring a polynomial, write the factorization before canceling. A canceled factor may remove a hole from the algebraic expression, but it does **not** restore that input to the original function's domain.

In a rational integral, choose the partial-fraction template from the **factored denominator**, never from the appearance of the numerator. After solving for coefficients, multiply your proposed decomposition by the original denominator and confirm that the numerators agree. This back-substitution costs one line and catches most sign errors before you integrate. When completing a square, record the coefficient of the squared expression and the constant separately. In geometry, a minus sign on a squared term changes the shape; it is not just an aesthetic difference.

### Worked examples

:::::example[Example 0.1 — Finding a domain with multiple restrictions]
Find the domain of $\displaystyle f(x) = \frac{\ln(x-2)}{\sqrt{5-x}}$.

::::answer[Answer]
**Answer:** $(2,\, 5)$

1. Determine the allowable inputs before simplifying: logarithm arguments must be positive and denominators must be nonzero.
2. List every restriction separately, then combine:
3. **Numerator $\ln(x-2)$:** requires $x - 2 > 0$, so $x > 2$.
4. **Denominator $\sqrt{5-x}$:** requires $5 - x \geq 0$, so $x \leq 5$.
5. But also the denominator cannot be zero (we'd divide by zero), so $5 - x \neq 0$, meaning $x \neq 5$.
6. Combined: $x < 5$.
7. Take the intersection: $x > 2$ AND $x < 5$ gives $x \in (2, 5)$.
8. Check: a retained test input makes every logarithm valid and no denominator zero; each excluded endpoint violates a restriction.
::::
:::::
:::::example[Example 0.2 — Completing the square]
Rewrite $3x^2 + 12x + 7$ in the form $a(x-h)^2 + k$.

::::answer[Answer]
**Answer:** $3(x+2)^2 - 5$

1. Use the defining algebraic identity and preserve the original signs and denominators through every simplification.
2. Step 1: factor $3$ out of the quadratic and linear terms only (leave the constant alone for now):

$$
3(x^2 + 4x) + 7
$$
3. Step 2: inside the parentheses, find the value that completes the square.
4. Take the coefficient of $x$, which is $4$; divide by 2 to get $2$; square it to get $4$.
5. Add and subtract $4$ *inside* the parentheses:

$$
3(x^2 + 4x + 4 - 4) + 7 = 3\bigl[(x+2)^2 - 4\bigr] + 7
$$
6. Step 3: distribute the $3$ and combine constants:

$$
3(x+2)^2 - 12 + 7 = 3(x+2)^2 - 5
$$
7. So $h = -2$, $k = -5$.
8. The vertex of the parabola $y = 3x^2+12x+7$ is at $(-2, -5)$.
9. Check: expand or substitute the result into the starting identity to confirm equal values.
::::
:::::
:::::example[Example 0.3 — Partial fractions: distinct linear factors]
Decompose $\dfrac{5x - 3}{(x+1)(x-3)}$.

::::answer[Answer]
**Answer:** $\dfrac{2}{x+1} + \dfrac{3}{x-3}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. Write the decomposition with unknown numerators:

$$
\frac{5x-3}{(x+1)(x-3)} = \frac{A}{x+1} + \frac{B}{x-3}
$$
3. Multiply both sides by $(x+1)(x-3)$ to clear denominators:

$$
5x - 3 = A(x-3) + B(x+1)
$$
4. This must hold for all $x$.
5. The fastest way to find $A$ and $B$ is to choose values of $x$ that zero out one term at a time.
6. Plug in $x = -1$ (zeros out the $B$ term): $5(-1)-3 = A(-1-3) \Rightarrow -8 = -4A \Rightarrow A = 2$.
7. Plug in $x = 3$ (zeros out the $A$ term): $5(3)-3 = B(3+1) \Rightarrow 12 = 4B \Rightarrow B = 3$.
8. $\dfrac{2}{x+1} + \dfrac{3}{x-3}$.
9. You can verify by recombining over a common denominator.
10. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::
:::::example[Example 0.4 — Partial fractions: irreducible quadratic]
Decompose $\dfrac{2x^2 + x + 1}{x(x^2+1)}$.

::::answer[Answer]
**Answer:** $\dfrac{1}{x} + \dfrac{x+1}{x^2+1}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. The denominator has a linear factor $x$ and an irreducible quadratic $x^2+1$ (it can't be factored over the reals — its roots are $\pm i$).
3. The setup must reflect this:

$$
\frac{2x^2+x+1}{x(x^2+1)} = \frac{A}{x} + \frac{Bx+C}{x^2+1}
$$
4. Multiply through by $x(x^2+1)$:

$$
2x^2 + x + 1 = A(x^2+1) + (Bx+C)x = A x^2 + A + Bx^2 + Cx
$$
5. Compute the expression at this stage:

$$
= (A+B)x^2 + Cx + A
$$
6. Match coefficients on both sides:
7. $x^2$: $A + B = 2$ $x^1$: $C = 1$ $x^0$: $A = 1$
8. From $A=1$ and $A+B=2$: $B = 1$.
9. So $A=1, B=1, C=1$, giving $\dfrac{1}{x}+\dfrac{x+1}{x^2+1}$.
10. The coefficient of $x^1$ is the one to be careful with, because it comes from only one place.
11. Multiplying out, $(Bx+C)\cdot x = Bx^2 + Cx$, so the whole $x^1$ term on the right is $Cx$ — the $A(x^2+1)$ piece contributes an $x^2$ and a constant and nothing linear at all.
12. Matching against the $x$ in the original numerator therefore gives $C = 1$ directly.
13. Dropping that $C$, and writing $\frac{x}{x^2+1}$ instead of $\frac{x+1}{x^2+1}$, is the commonest way this decomposition goes wrong.
14. *Verification:* $\frac{x^2+1 + x(x+1)}{x(x^2+1)} = \frac{x^2+1+x^2+x}{x(x^2+1)} = \frac{2x^2+x+1}{x(x^2+1)}$.
15. ✓
16. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::
:::callout-pitfall[Watch out for]
- **Degree check before partial fractions.** If $\deg(\text{numerator}) \geq \deg(\text{denominator})$, divide first. For example, $\tfrac{x^3-1}{x^2-1}$ looks like it might decompose, but the degree of the top (3) is greater than the degree of the bottom (2). Long divide first: $x^3-1 = (x^2-1)\cdot x + (x-1)$, so $\frac{x^3-1}{x^2-1} = x + \frac{x-1}{x^2-1} = x + \frac{1}{x+1}$.
- **Repeated roots need multiple terms.** The factor $(x-2)^2$ in the denominator requires *two* partial fraction terms: $\frac{A}{x-2} + \frac{B}{(x-2)^2}$. Writing only $\frac{A}{x-2}$ leaves a gap that cannot be filled.
- **Inverse trig output ranges.** $\arcsin(\sin(5\pi/4))$ is NOT $5\pi/4$, because $5\pi/4$ is outside $[-\pi/2,\pi/2]$. Rewrite: $\sin(5\pi/4) = -\sqrt{2}/2$, so $\arcsin(-\sqrt{2}/2) = -\pi/4$.
:::

### Practice problems

:::::problem[Problem 0.1 — Domain of a logarithmic fraction]{difficulty=easy}
Find the domain of $g(x) = \dfrac{1}{\ln(x^2-4)}$.

::::solution[Solution]
**Answer:** $(-\infty,-2)\cup(2,\infty)\setminus\{-\sqrt5,\sqrt5\}$

1. Determine the allowable inputs before simplifying: logarithm arguments must be positive and denominators must be nonzero.
2. Need $x^2-4>0$ (for $\ln$) and $\ln(x^2-4)\neq 0$ (no division by zero).
3. $x^2-4>0\Rightarrow |x|>2$, so $x\in(-\infty,-2)\cup(2,\infty)$.
4. $\ln(x^2-4)=0$ when $x^2-4=1$, i.e. $x=\pm\sqrt{5}$.
5. Exclude these. Domain: $(-\infty,-\sqrt{5})\cup(-\sqrt{5},-2)\cup\ldots$ — actually $x\in(-\infty,-2)\cup(2,\infty)$ with $x\neq\pm\sqrt{5}$.
6. Check: a retained test input makes every logarithm valid and no denominator zero; each excluded endpoint violates a restriction.
::::
:::::

:::::problem[Problem 0.2 — Even and odd functions]{difficulty=easy}
Determine whether $f(x)=x^4-3x^2+1$ is even, odd, or neither. Then determine whether $g(x)=x^3-2x$ is even, odd, or neither.

::::solution[Solution]
**Answer:** $f$ even; $g$ odd

1. Use the definitions $f(-x)=f(x)$ for even and $g(-x)=-g(x)$ for odd functions; expand both substitutions.
2. $f(-x)=(-x)^4-3(-x)^2+1=x^4-3x^2+1=f(x)$.
3. So $f$ is **even**. $g(-x)=(-x)^3-2(-x)=-x^3+2x=-(x^3-2x)=-g(x)$.
4. So $g$ is **odd**. Consequence: $\int_{-2}^{2}g(x)\,dx=0$ by symmetry.
5. Check: the computed signs agree with the definitions of evenness and oddness for all real inputs.
::::
:::::

:::::problem[Problem 0.3 — Completing the square]{difficulty=easy}
Complete the square: $2x^2 - 8x + 3$.

::::solution[Solution]
**Answer:** $2(x-2)^2-5$

1. Use the defining algebraic identity and preserve the original signs and denominators through every simplification.
2. Factor 2 from quadratic terms: $2(x^2-4x)+3$.
3. Complete: half of $-4$ is $-2$, squared is $4$.
4. $2(x^2-4x+4-4)+3=2(x-2)^2-8+3=2(x-2)^2-5$.
5. Check: expand or substitute the result into the starting identity to confirm equal values.
::::
:::::

:::::problem[Problem 0.4 — Three linear partial fractions]{difficulty=standard}
Decompose $\dfrac{3x^2-4}{x(x-1)(x+2)}$ into partial fractions.

::::solution[Solution]
**Answer:** $\frac{2}{x}-\frac{1}{3(x-1)}+\frac{4}{3(x+2)}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. Write $\frac{A}{x}+\frac{B}{x-1}+\frac{C}{x+2}$.
3. Multiply through: $3x^2-4=A(x-1)(x+2)+Bx(x+2)+Cx(x-1)$.
4. At $x=0$: $-4=A(-1)(2)=-2A\Rightarrow A=2$.
5. At $x=1$: $-1=B(1)(3)=3B\Rightarrow B=-1/3$.
6. At $x=-2$: $8=C(-2)(-3)=6C\Rightarrow C=4/3$.
7. $\frac{2}{x}-\frac{1/3}{x-1}+\frac{4/3}{x+2}$.
8. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::

:::::problem[Problem 0.5 — Inverse exponential quotient]{difficulty=standard}
Find $f^{-1}(x)$ for $f(x) = \dfrac{e^x}{1+e^x}$. State its domain and range.

::::solution[Solution]
**Answer:** $f^{-1}(x)=\ln\!\frac{x}{1-x}$; domain $(0,1)$; range $\mathbb R$

1. Determine the allowable inputs before simplifying: logarithm arguments must be positive and denominators must be nonzero.
2. Set $y=\frac{e^x}{1+e^x}$.
3. Solve for $x$: $y(1+e^x)=e^x\Rightarrow y+ye^x=e^x\Rightarrow y=e^x(1-y)\Rightarrow e^x=\frac{y}{1-y}\Rightarrow x=\ln\!\left(\frac{y}{1-y}\right)$.
4. So $f^{-1}(x)=\ln\!\left(\frac{x}{1-x}\right)$.
5. Domain: need $\frac{x}{1-x}>0$, so $0< x<1$.
6. Range of $f^{-1}$ = domain of $f$ = $(-\infty,\infty)$.
7. Check: a retained test input makes every logarithm valid and no denominator zero; each excluded endpoint violates a restriction.
::::
:::::

:::::problem[Problem 0.6 — Repeated-factor partial fractions]{difficulty=standard}
Decompose $\dfrac{x^2+1}{(x-1)^2(x+1)}$. (Watch for the repeated root.)

::::solution[Solution]
**Answer:** $\frac{1}{2(x-1)}+\frac{1}{(x-1)^2}+\frac{1}{2(x+1)}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. Setup: $\frac{A}{x-1}+\frac{B}{(x-1)^2}+\frac{C}{x+1}$.
3. Multiply: $x^2+1=A(x-1)(x+1)+B(x+1)+C(x-1)^2$.
4. At $x=1$: $2=B(2)\Rightarrow B=1$.
5. At $x=-1$: $2=C(-2)^2=4C\Rightarrow C=1/2$.
6. Expand and match $x^2$ terms to find $A$: $x^2$ on right: $A+C=A+1/2$.
7. Must equal 1, so $A=1/2$.
8. $\frac{1/2}{x-1}+\frac{1}{(x-1)^2}+\frac{1/2}{x+1}$.
9. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::

:::::problem[Problem 0.7 — Polynomial division and partial fractions]{difficulty=challenge}
Decompose $\dfrac{x^3}{x^2+x-2}$ fully, starting with the degree check.

::::solution[Solution]
**Answer:** $x-1+\frac{8}{3(x+2)}+\frac{1}{3(x-1)}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. Degree of numerator (3) $\geq$ degree of denominator (2): divide first.
3. $x^3\div(x^2+x-2)$: $x^3=(x^2+x-2)\cdot x + (-x^2+2x)$.
4. So quotient is $x$, remainder $-x^2+2x$.
5. Continue: $-x^2+2x=(-x^2-x+2)+(3x-2)=(x^2+x-2)\cdot(-1)+(3x-2)$.
6. Quotient is $x-1$, remainder $3x-2$.
7. So $\frac{x^3}{x^2+x-2}=(x-1)+\frac{3x-2}{x^2+x-2}$.
8. Factor: $x^2+x-2=(x+2)(x-1)$.
9. PFD: $\frac{A}{x+2}+\frac{B}{x-1}$.
10. At $x=-2$: $-8=A(-3)\Rightarrow A=8/3$.
11. At $x=1$: $1=B(3)\Rightarrow B=1/3$.
12. Final: $x-1+\frac{8/3}{x+2}+\frac{1/3}{x-1}$.
13. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::

## 0.2 Trigonometry Tune-Up

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Trigonometry | Unit circle” — Khan Academy

“Trig identities reference” — Khan Academy
:::

:::callout-intuition[Intuition]
Trigonometry shows up in MA 2733 in two completely different ways. First, as a *coordinate system*: polar coordinates express every point as $(r,\theta)$, so polar area integrals are entirely written in trig functions. Second, as an *integration technique*: trig substitution and trig integrals (§0.5) convert radical expressions into clean trig functions. Both applications require you to move fluently between forms — replacing $\sin^2\theta$ with $\frac{1-\cos 2\theta}{2}$ or factoring a Pythagorean identity — without stopping to look anything up.

The single most important identity for MA 2733 integrals is the **power-reduction** (half-angle) pair: $\sin^2\theta = \frac{1-\cos 2\theta}{2}$ and $\cos^2\theta = \frac{1+\cos 2\theta}{2}$. These convert squared trig functions into integratable form. You will use them in Chapter 1 polar-area calculations; Test 3 requires only $\sin^2t+\cos^2t=1$.
:::

### The unit circle — exact values

These are the values you need to reproduce instantly on an exam with no calculator. Notice the pattern: as $\theta$ goes from $0$ to $\pi/2$, $\sin\theta$ reads $0, 1/2, \sqrt{2}/2, \sqrt{3}/2, 1$ — the "0, 1, 2, 3, 4 under a square root, divided by 2" pattern. $\cos\theta$ reads the same values in reverse.

:::definition[Reference 0.2.1 — Unit Circle Exact Values]
| $\theta$ (rad) | $\theta$ (deg) | $\sin\theta$ | $\cos\theta$ | $\tan\theta$ |
| --- | --- | --- | --- | --- |
| $0$ | $0°$ | $0$ | $1$ | $0$ |
| $\pi/6$ | $30°$ | $1/2$ | $\sqrt{3}/2$ | $1/\sqrt{3}$ |
| $\pi/4$ | $45°$ | $\sqrt{2}/2$ | $\sqrt{2}/2$ | $1$ |
| $\pi/3$ | $60°$ | $\sqrt{3}/2$ | $1/2$ | $\sqrt{3}$ |
| $\pi/2$ | $90°$ | $1$ | $0$ | undef. |
| $2\pi/3$ | $120°$ | $\sqrt{3}/2$ | $-1/2$ | $-\sqrt{3}$ |
| $3\pi/4$ | $135°$ | $\sqrt{2}/2$ | $-\sqrt{2}/2$ | $-1$ |
| $5\pi/6$ | $150°$ | $1/2$ | $-\sqrt{3}/2$ | $-1/\sqrt{3}$ |
| $\pi$ | $180°$ | $0$ | $-1$ | $0$ |
| $3\pi/2$ | $270°$ | $-1$ | $0$ | undef. |

**ASTC rule for signs in other quadrants:** All Students Take Calculus — All ($\sin,\cos,\tan$ positive in Q1), Sine (only $\sin$ positive in Q2), Tangent (only $\tan$ positive in Q3), Cosine (only $\cos$ positive in Q4).
:::

:::definition[Reference 0.2.2 — All the Identities You Need]
**Pythagorean identities** (derive the other two from $\sin^2+\cos^2=1$ by dividing by $\cos^2$ or $\sin^2$):

$$
\sin^2\theta+\cos^2\theta=1 \qquad 1+\tan^2\theta=\sec^2\theta \qquad \cot^2\theta+1=\csc^2\theta
$$
**Double-angle:**

$$
\sin 2\theta=2\sin\theta\cos\theta \qquad \cos 2\theta = \cos^2\theta-\sin^2\theta = 1-2\sin^2\theta = 2\cos^2\theta-1
$$
**Power-reduction (half-angle) — use these in integrals:**

$$
\sin^2\theta = \frac{1-\cos 2\theta}{2} \qquad \cos^2\theta = \frac{1+\cos 2\theta}{2} \qquad \tan^2\theta = \frac{1-\cos 2\theta}{1+\cos 2\theta}
$$
**Sum and difference:**

$$
\sin(A\pm B)=\sin A\cos B\pm\cos A\sin B \qquad \cos(A\pm B)=\cos A\cos B\mp\sin A\sin B
$$
**Product-to-sum (appear in Fourier-type problems):**

$$
\sin A\cos B=\tfrac{1}{2}[\sin(A-B)+\sin(A+B)] \qquad \cos A\cos B=\tfrac{1}{2}[\cos(A-B)+\cos(A+B)]
$$
:::

Key Idea — Three forms of $\cos 2\theta$

The double-angle formula for cosine has three equivalent forms, and the "right" one to use depends on what you want to eliminate:

- Use $\cos 2\theta = 1-2\sin^2\theta$ to replace $\sin^2\theta = \frac{1-\cos 2\theta}{2}$.
- Use $\cos 2\theta = 2\cos^2\theta - 1$ to replace $\cos^2\theta = \frac{1+\cos 2\theta}{2}$.
- Use $\cos 2\theta = \cos^2\theta-\sin^2\theta$ when both appear together.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="Unit circle parameterized by cosine and sine">
<path class="fig-axis" d="M80 108 L270 108 M175 10 L175 202"/>
<path class="fig-curve" d="M251.00 108.00 L250.99 107.04 L250.98 106.09 L250.95 105.14 L250.90 104.18 L250.85 103.23 L250.78 102.28 L250.71 101.32 L250.62 100.37 L250.51 99.42 L250.40 98.47 L250.28 97.53 L250.14 96.58 L249.99 95.64 L249.83 94.70 L249.65 93.76 L249.47 92.82 L249.27 91.89 L249.06 90.96 L248.84 90.03 L248.61 89.10 L248.37 88.18 L248.11 87.26 L247.85 86.34 L247.57 85.42 L247.28 84.51 L246.98 83.61 L246.67 82.71 L246.34 81.81 L246.01 80.91 L245.66 80.02 L245.31 79.14 L244.94 78.26 L244.56 77.38 L244.17 76.51 L243.77 75.64 L243.35 74.78 L242.93 73.92 L242.50 73.07 L242.05 72.23 L241.60 71.39 L241.13 70.55 L240.66 69.72 L240.17 68.90 L239.68 68.09 L239.17 67.28 L238.65 66.47 L238.13 65.68 L237.59 64.89 L237.04 64.10 L236.49 63.33 L235.92 62.56 L235.34 61.80 L234.76 61.04 L234.16 60.30 L233.56 59.56 L232.95 58.82 L232.32 58.10 L231.69 57.38 L231.05 56.67 L230.40 55.97 L229.74 55.28 L229.08 54.60 L228.40 53.92 L227.72 53.26 L227.03 52.60 L226.33 51.95 L225.62 51.31 L224.90 50.68 L224.18 50.05 L223.44 49.44 L222.70 48.84 L221.96 48.24 L221.20 47.66 L220.44 47.08 L219.67 46.51 L218.90 45.96 L218.11 45.41 L217.32 44.87 L216.53 44.35 L215.72 43.83 L214.91 43.32 L214.10 42.83 L213.28 42.34 L212.45 41.87 L211.61 41.40 L210.77 40.95 L209.93 40.50 L209.08 40.07 L208.22 39.65 L207.36 39.23 L206.49 38.83 L205.62 38.44 L204.74 38.06 L203.86 37.69 L202.98 37.34 L202.09 36.99 L201.19 36.66 L200.29 36.33 L199.39 36.02 L198.49 35.72 L197.58 35.43 L196.66 35.15 L195.74 34.89 L194.82 34.63 L193.90 34.39 L192.97 34.16 L192.04 33.94 L191.11 33.73 L190.18 33.53 L189.24 33.35 L188.30 33.17 L187.36 33.01 L186.42 32.86 L185.47 32.72 L184.53 32.60 L183.58 32.49 L182.63 32.38 L181.68 32.29 L180.72 32.22 L179.77 32.15 L178.82 32.10 L177.86 32.05 L176.91 32.02 L175.96 32.01 L175.00 32.00 L174.04 32.01 L173.09 32.02 L172.14 32.05 L171.18 32.10 L170.23 32.15 L169.28 32.22 L168.32 32.29 L167.37 32.38 L166.42 32.49 L165.47 32.60 L164.53 32.72 L163.58 32.86 L162.64 33.01 L161.70 33.17 L160.76 33.35 L159.82 33.53 L158.89 33.73 L157.96 33.94 L157.03 34.16 L156.10 34.39 L155.18 34.63 L154.26 34.89 L153.34 35.15 L152.42 35.43 L151.51 35.72 L150.61 36.02 L149.71 36.33 L148.81 36.66 L147.91 36.99 L147.02 37.34 L146.14 37.69 L145.26 38.06 L144.38 38.44 L143.51 38.83 L142.64 39.23 L141.78 39.65 L140.92 40.07 L140.07 40.50 L139.23 40.95 L138.39 41.40 L137.55 41.87 L136.72 42.34 L135.90 42.83 L135.09 43.32 L134.28 43.83 L133.47 44.35 L132.68 44.87 L131.89 45.41 L131.10 45.96 L130.33 46.51 L129.56 47.08 L128.80 47.66 L128.04 48.24 L127.30 48.84 L126.56 49.44 L125.82 50.05 L125.10 50.68 L124.38 51.31 L123.67 51.95 L122.97 52.60 L122.28 53.26 L121.60 53.92 L120.92 54.60 L120.26 55.28 L119.60 55.97 L118.95 56.67 L118.31 57.38 L117.68 58.10 L117.05 58.82 L116.44 59.56 L115.84 60.30 L115.24 61.04 L114.66 61.80 L114.08 62.56 L113.51 63.33 L112.96 64.10 L112.41 64.89 L111.87 65.68 L111.35 66.47 L110.83 67.28 L110.32 68.09 L109.83 68.90 L109.34 69.72 L108.87 70.55 L108.40 71.39 L107.95 72.23 L107.50 73.07 L107.07 73.92 L106.65 74.78 L106.23 75.64 L105.83 76.51 L105.44 77.38 L105.06 78.26 L104.69 79.14 L104.34 80.02 L103.99 80.91 L103.66 81.81 L103.33 82.71 L103.02 83.61 L102.72 84.51 L102.43 85.42 L102.15 86.34 L101.89 87.26 L101.63 88.18 L101.39 89.10 L101.16 90.03 L100.94 90.96 L100.73 91.89 L100.53 92.82 L100.35 93.76 L100.17 94.70 L100.01 95.64 L99.86 96.58 L99.72 97.53 L99.60 98.47 L99.49 99.42 L99.38 100.37 L99.29 101.32 L99.22 102.28 L99.15 103.23 L99.10 104.18 L99.05 105.14 L99.02 106.09 L99.01 107.04 L99.00 108.00 L99.01 108.96 L99.02 109.91 L99.05 110.86 L99.10 111.82 L99.15 112.77 L99.22 113.72 L99.29 114.68 L99.38 115.63 L99.49 116.58 L99.60 117.53 L99.72 118.47 L99.86 119.42 L100.01 120.36 L100.17 121.30 L100.35 122.24 L100.53 123.18 L100.73 124.11 L100.94 125.04 L101.16 125.97 L101.39 126.90 L101.63 127.82 L101.89 128.74 L102.15 129.66 L102.43 130.58 L102.72 131.49 L103.02 132.39 L103.33 133.29 L103.66 134.19 L103.99 135.09 L104.34 135.98 L104.69 136.86 L105.06 137.74 L105.44 138.62 L105.83 139.49 L106.23 140.36 L106.65 141.22 L107.07 142.08 L107.50 142.93 L107.95 143.77 L108.40 144.61 L108.87 145.45 L109.34 146.28 L109.83 147.10 L110.32 147.91 L110.83 148.72 L111.35 149.53 L111.87 150.32 L112.41 151.11 L112.96 151.90 L113.51 152.67 L114.08 153.44 L114.66 154.20 L115.24 154.96 L115.84 155.70 L116.44 156.44 L117.05 157.18 L117.68 157.90 L118.31 158.62 L118.95 159.33 L119.60 160.03 L120.26 160.72 L120.92 161.40 L121.60 162.08 L122.28 162.74 L122.97 163.40 L123.67 164.05 L124.38 164.69 L125.10 165.32 L125.82 165.95 L126.56 166.56 L127.30 167.16 L128.04 167.76 L128.80 168.34 L129.56 168.92 L130.33 169.49 L131.10 170.04 L131.89 170.59 L132.68 171.13 L133.47 171.65 L134.28 172.17 L135.09 172.68 L135.90 173.17 L136.72 173.66 L137.55 174.13 L138.39 174.60 L139.23 175.05 L140.07 175.50 L140.92 175.93 L141.78 176.35 L142.64 176.77 L143.51 177.17 L144.38 177.56 L145.26 177.94 L146.14 178.31 L147.02 178.66 L147.91 179.01 L148.81 179.34 L149.71 179.67 L150.61 179.98 L151.51 180.28 L152.42 180.57 L153.34 180.85 L154.26 181.11 L155.18 181.37 L156.10 181.61 L157.03 181.84 L157.96 182.06 L158.89 182.27 L159.82 182.47 L160.76 182.65 L161.70 182.83 L162.64 182.99 L163.58 183.14 L164.53 183.28 L165.47 183.40 L166.42 183.51 L167.37 183.62 L168.32 183.71 L169.28 183.78 L170.23 183.85 L171.18 183.90 L172.14 183.95 L173.09 183.98 L174.04 183.99 L175.00 184.00 L175.96 183.99 L176.91 183.98 L177.86 183.95 L178.82 183.90 L179.77 183.85 L180.72 183.78 L181.68 183.71 L182.63 183.62 L183.58 183.51 L184.53 183.40 L185.47 183.28 L186.42 183.14 L187.36 182.99 L188.30 182.83 L189.24 182.65 L190.18 182.47 L191.11 182.27 L192.04 182.06 L192.97 181.84 L193.90 181.61 L194.82 181.37 L195.74 181.11 L196.66 180.85 L197.58 180.57 L198.49 180.28 L199.39 179.98 L200.29 179.67 L201.19 179.34 L202.09 179.01 L202.98 178.66 L203.86 178.31 L204.74 177.94 L205.62 177.56 L206.49 177.17 L207.36 176.77 L208.22 176.35 L209.08 175.93 L209.93 175.50 L210.77 175.05 L211.61 174.60 L212.45 174.13 L213.28 173.66 L214.10 173.17 L214.91 172.68 L215.72 172.17 L216.53 171.65 L217.32 171.13 L218.11 170.59 L218.90 170.04 L219.67 169.49 L220.44 168.92 L221.20 168.34 L221.96 167.76 L222.70 167.16 L223.44 166.56 L224.18 165.95 L224.90 165.32 L225.62 164.69 L226.33 164.05 L227.03 163.40 L227.72 162.74 L228.40 162.08 L229.08 161.40 L229.74 160.72 L230.40 160.03 L231.05 159.33 L231.69 158.62 L232.32 157.90 L232.95 157.18 L233.56 156.44 L234.16 155.70 L234.76 154.96 L235.34 154.20 L235.92 153.44 L236.49 152.67 L237.04 151.90 L237.59 151.11 L238.13 150.32 L238.65 149.53 L239.17 148.72 L239.68 147.91 L240.17 147.10 L240.66 146.28 L241.13 145.45 L241.60 144.61 L242.05 143.77 L242.50 142.93 L242.93 142.08 L243.35 141.22 L243.77 140.36 L244.17 139.49 L244.56 138.62 L244.94 137.74 L245.31 136.86 L245.66 135.98 L246.01 135.09 L246.34 134.19 L246.67 133.29 L246.98 132.39 L247.28 131.49 L247.57 130.58 L247.85 129.66 L248.11 128.74 L248.37 127.82 L248.61 126.90 L248.84 125.97 L249.06 125.04 L249.27 124.11 L249.47 123.18 L249.65 122.24 L249.83 121.30 L249.99 120.36 L250.14 119.42 L250.28 118.47 L250.40 117.53 L250.51 116.58 L250.62 115.63 L250.71 114.68 L250.78 113.72 L250.85 112.77 L250.90 111.82 L250.95 110.86 L250.98 109.91 L250.99 108.96 L251.00 108.00"/>
</svg>
<figcaption>A point at angle $\theta$ has coordinates $(\cos\theta,\sin\theta)$ on the unit circle; signs of these coordinates determine the signs of sine and cosine in each quadrant.</figcaption>
</figure>

### Reading angles as geometry rather than memorized symbols

When a polar curve is involved, the angle tells you which *ray* from the origin you are looking along. The sign of $r$ tells you whether the point lies forward or backward along that ray. This is why you should not discard a negative radius when converting polar points: a negative radius represents a point on the opposite ray. For special angles, identify the **reference angle** first, then assign signs using the quadrant. A $150°$ angle has the same reference triangle as $30°$; only the cosine sign changes. The same reasoning handles angles larger than one revolution: subtract multiples of $2\pi$ until the angle lies in one standard turn.

### Choosing a trig identity for an integral

The goal is not to simplify every trigonometric expression to one universal form. It is to reach a form with an antiderivative you recognize. If both sine and cosine appear to an even power, power reduction is usually more productive than $u$-substitution. If a sine or cosine has an *odd* power, peel off one factor and use $\sin^2\theta+\cos^2\theta=1$ to rewrite the rest in the other function. If a square root came from a trigonometric substitution, use the quadrant restrictions you chose for the substitution to determine the sign of the square root.

On a written test, show the identity **before** applying it: for example, write $\sin^2\theta=(1-\cos2\theta)/2$ above the integral. Then put the factor $1/2$ outside. Keeping the factor visible is important in polar area, where the area formula already contributes another $1/2$. Those are two different factors and both must survive integration. Finally, state the interval of angles you used. A petal may only be traced once on a shorter interval; tracing the full $0$ to $2\pi$ interval can count the same geometric region multiple times. This tracing issue belongs to the parametric/polar test, not Young's Test 3 vector limit work.

### Worked examples

:::::example[Example 0.5 — Power-reduction integral (the polar area prototype)]
Compute $\displaystyle\int_0^{\pi}\cos^2\theta\,d\theta$.

::::answer[Answer]
**Answer:** $\pi/2$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. You cannot integrate $\cos^2\theta$ directly — it's a square, not a simple trig function.
3. The power-reduction identity converts it into something integrable:

$$
\cos^2\theta = \frac{1+\cos 2\theta}{2}
$$
4. Substitute and integrate term by term:

$$
\int_0^{\pi}\cos^2\theta\,d\theta = \int_0^{\pi}\frac{1+\cos 2\theta}{2}\,d\theta = \frac{1}{2}\int_0^{\pi}(1+\cos 2\theta)\,d\theta
$$
5. Compute the expression at this stage:

$$
= \frac{1}{2}\!\left[\theta + \frac{\sin 2\theta}{2}\right]_0^{\pi} = \frac{1}{2}\!\left[\!\left(\pi + \frac{\sin 2\pi}{2}\right)-\left(0+\frac{\sin 0}{2}\right)\right] = \frac{1}{2}(\pi + 0 - 0) = \frac{\pi}{2}
$$
6. *This exact computation appears inside polar area integrals of cardioids like $r=1+\cos\theta$.
7. Recognize the pattern now.*
8. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::
:::::example[Example 0.6 — Exact value using a sum formula]
Find the exact value of $\sin(7\pi/12)$.

::::answer[Answer]
**Answer:** $\dfrac{\sqrt{6}+\sqrt{2}}{4}$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. The angle $7\pi/12$ is not a standard unit-circle angle.
3. But $7\pi/12 = \pi/3 + \pi/4$, and both of those *are* standard.
4. Apply the sum formula:

$$
\sin\!\left(\frac{\pi}{3}+\frac{\pi}{4}\right) = \sin\frac{\pi}{3}\cos\frac{\pi}{4} + \cos\frac{\pi}{3}\sin\frac{\pi}{4}
$$
5. Compute the expression at this stage:

$$
= \frac{\sqrt{3}}{2}\cdot\frac{\sqrt{2}}{2} + \frac{1}{2}\cdot\frac{\sqrt{2}}{2} = \frac{\sqrt{6}}{4}+\frac{\sqrt{2}}{4} = \frac{\sqrt{6}+\sqrt{2}}{4}
$$
6. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::
:::::example[Example 0.7 — Solving a trig equation completely]
Solve $2\sin^2 x - \sin x - 1 = 0$ on $[0, 2\pi)$.

::::answer[Answer]
**Answer:** $x = \dfrac{\pi}{2},\; \dfrac{7\pi}{6},\; \dfrac{11\pi}{6}$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. This is a quadratic in $\sin x$.
3. Let $u = \sin x$: $2u^2 - u - 1 = 0$.
4. Factor: $(2u+1)(u-1)=0$.
5. **Case 1:** $u = 1$, i.e. $\sin x = 1$.
6. On $[0,2\pi)$: $x = \pi/2$.
7. ✓
8. **Case 2:** $u = -1/2$, i.e. $\sin x = -1/2$.
9. Sine is negative in Q3 and Q4.
10. Reference angle: $\arcsin(1/2) = \pi/6$.
11. Q3: $x = \pi + \pi/6 = 7\pi/6$ Q4: $x = 2\pi - \pi/6 = 11\pi/6$
12. All three solutions: $x = \pi/2,\; 7\pi/6,\; 11\pi/6$.
13. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::
:::::example[Example 0.8 — Power reduction for $\sin^4\theta$ (appears in Calc 3 integrals)]
Rewrite $\sin^4\theta$ as a sum of cosines without any squares.

::::answer[Answer]
**Answer:** $\dfrac{3}{8} - \dfrac{1}{2}\cos 2\theta + \dfrac{1}{8}\cos 4\theta$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. Apply the power-reduction identity once, then again:

$$
\sin^4\theta = (\sin^2\theta)^2 = \left(\frac{1-\cos 2\theta}{2}\right)^{\!2} = \frac{1 - 2\cos 2\theta + \cos^2 2\theta}{4}
$$
3. Now $\cos^2 2\theta$ is still squared.
4. Apply the power-reduction identity again, with $\theta$ replaced by $2\theta$:

$$
\cos^2 2\theta = \frac{1+\cos 4\theta}{2}
$$
5. Substitute back:

$$
\sin^4\theta = \frac{1-2\cos 2\theta+\frac{1+\cos 4\theta}{2}}{4} = \frac{\frac{3}{2}-2\cos 2\theta+\frac{\cos 4\theta}{2}}{4} = \frac{3}{8}-\frac{1}{2}\cos 2\theta+\frac{1}{8}\cos 4\theta
$$
6. *This identity makes $\int\sin^4\theta\,d\theta$ trivial — you just integrate three cosines.*
7. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::
:::callout-pitfall[Watch out for]
- **Missing solutions.** $\cos\theta = -1/2$ has *two* solutions on $[0,2\pi)$: $2\pi/3$ (Q2) and $4\pi/3$ (Q3). Students who only write the reference-angle solution lose half the answers. Always ask: in which quadrants does the trig function have the required sign?
- **ASTC sign errors.** In Q2: sine positive, cosine and tangent negative. In Q3: tangent positive, sine and cosine negative. In Q4: cosine positive, sine and tangent negative. The mnemonic "All Students Take Calculus" (Q1–Q4) keeps the quadrants straight.
- **Which power-reduction formula to use.** Both $\sin^2\theta$ and $\cos^2\theta$ need reducing, but they need *different* formulas. $\sin^2\theta = \frac{1-\cos 2\theta}{2}$ (minus sign). $\cos^2\theta = \frac{1+\cos 2\theta}{2}$ (plus sign). Mixing them up flips the sign of the whole computation.
:::

### Practice problems

:::::problem[Problem 0.8 — Unit-circle exact values]{difficulty=easy}
Evaluate without a calculator: $\cos(5\pi/6)$, $\tan(4\pi/3)$, $\sin(5\pi/4)$.

::::solution[Solution]
**Answer:** $-\sqrt3/2$, $\sqrt3$, $-\sqrt2/2$

1. Use the defining algebraic identity and preserve the original signs and denominators through every simplification.
2. $\cos(5\pi/6)$: Q2, reference angle $\pi/6$, cosine negative.
3. $-\sqrt{3}/2$.
4. $\tan(4\pi/3)$: Q3, reference angle $\pi/3$, tangent positive.
5. $\sqrt{3}$.
6. $\sin(5\pi/4)$: Q3, reference angle $\pi/4$, sine negative.
7. $-\sqrt{2}/2$.
8. Check: expand or substitute the result into the starting identity to confirm equal values.
::::
:::::

:::::problem[Problem 0.9 — Power-reduction identities]{difficulty=easy}
Rewrite using power-reduction: (a) $\sin^2(5x)$, (b) $\cos^2(x/2)$.

::::solution[Solution]
**Answer:** $(1-\cos10x)/2$; $(1+\cos x)/2$

1. Use the defining algebraic identity and preserve the original signs and denominators through every simplification.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. (a) $\sin^2(5x)=\frac{1-\cos 10x}{2}$.
4. (b) $\cos^2(x/2)=\frac{1+\cos x}{2}$ (using $2\theta=x$).
5. Check: expand or substitute the result into the starting identity to confirm equal values.
::::
:::::

:::::problem[Problem 0.10 — Integral of sine squared]{difficulty=standard}
Compute $\displaystyle\int_0^{2\pi}\sin^2\theta\,d\theta$.

::::solution[Solution]
**Answer:** $\pi$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Use $\sin^2\theta=\frac{1-\cos 2\theta}{2}$: $\int_0^{2\pi}\frac{1-\cos 2\theta}{2}\,d\theta=\frac{1}{2}\left[\theta-\frac{\sin 2\theta}{2}\right]_0^{2\pi}=\frac{1}{2}(2\pi-0)=\pi$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.11 — Trigonometric equation]{difficulty=standard}
Solve $\tan^2 x - 3\sec x + 3 = 0$ on $[0,2\pi)$. (*Hint: convert everything to $\sec x$ using $\tan^2 x = \sec^2 x - 1$.*)

::::solution[Solution]
**Answer:** $0,\;\pi/3,\;5\pi/3$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. Substitute: $(\sec^2 x-1)-3\sec x+3=0\Rightarrow\sec^2 x-3\sec x+2=0\Rightarrow(\sec x-1)(\sec x-2)=0$.
3. Case 1: $\sec x=1\Rightarrow\cos x=1\Rightarrow x=0$.
4. Case 2: $\sec x=2\Rightarrow\cos x=1/2\Rightarrow x=\pi/3$ or $x=5\pi/3$.
5. $x=0, \pi/3, 5\pi/3$.
6. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

:::::problem[Problem 0.12 — Double-angle formula]{difficulty=standard}
Use sum formulas to verify the double-angle formula $\cos 2\theta = \cos^2\theta - \sin^2\theta$.

::::solution[Solution]
**Answer:** $\cos2\theta=\cos^2\theta-\sin^2\theta$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $\cos 2\theta=\cos(\theta+\theta)=\cos\theta\cos\theta-\sin\theta\sin\theta=\cos^2\theta-\sin^2\theta$.
4. ✓
5. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

:::::problem[Problem 0.13 — Sine-cosine product integral]{difficulty=standard}
Compute $\displaystyle\int_0^{\pi/2}\sin^2\theta\cos^2\theta\,d\theta$. (*Hint: use $\sin\theta\cos\theta = \frac{1}{2}\sin 2\theta$.*)

::::solution[Solution]
**Answer:** $\pi/16$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. $\sin^2\theta\cos^2\theta = (\sin\theta\cos\theta)^2=\frac{\sin^2 2\theta}{4}=\frac{1-\cos 4\theta}{8}$.
3. Integral: $\int_0^{\pi/2}\frac{1-\cos 4\theta}{8}\,d\theta=\frac{1}{8}\left[\theta-\frac{\sin 4\theta}{4}\right]_0^{\pi/2}=\frac{1}{8}\cdot\frac{\pi}{2}=\frac{\pi}{16}$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.14 — Cosine of seventy-five degrees]{difficulty=challenge}
Evaluate $\cos 75°$ two different ways: (a) as $\cos(45°+30°)$, (b) as $\cos(150°/2)$ using the half-angle formula $\cos^2(\alpha/2)=\frac{1+\cos\alpha}{2}$ with $\alpha=150°$. Show the results agree.

::::solution[Solution]
**Answer:** $(\sqrt6-\sqrt2)/4=\sqrt{2-\sqrt3}/2$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. (a) $\cos 75°=\cos 45°\cos 30°-\sin 45°\sin 30°=\frac{\sqrt{2}}{2}\cdot\frac{\sqrt{3}}{2}-\frac{\sqrt{2}}{2}\cdot\frac{1}{2}=\frac{\sqrt{6}-\sqrt{2}}{4}$.
3. (b) Apply the half-angle formula **directly** to $75°=150°/2$, not to $37.5°$:

$$
\cos75°=+\sqrt{\frac{1+\cos150°}{2}}=\sqrt{\frac{1-\sqrt3/2}{2}}=\frac{\sqrt{2-\sqrt3}}{2}.
$$
4. The positive root is required because $75°$ is in Quadrant I.
5. The answers agree exactly: both are positive, and
6. Compute the expression at this stage:

$$
\left(\frac{\sqrt6-\sqrt2}{4}\right)^2=\frac{8-4\sqrt3}{16}=\frac{2-\sqrt3}{4}=\left(\frac{\sqrt{2-\sqrt3}}{2}\right)^2.
$$
7. This method is genuinely independent; the original method put $\cos75°$ on both sides and proved nothing.
8. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

## 0.3 Limits and Continuity

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Limits and continuity | AP Calculus” — Khan Academy

“Essence of Calculus — full playlist” — 3Blue1Brown
:::

:::callout-intuition[Intuition]
A limit asks: as $x$ inches closer and closer to some target value $a$, what value does $f(x)$ approach? The function doesn't have to be *defined* at $a$ — we're asking about the journey, not the destination. This matters because many important quantities in calculus are limits of things that are undefined at the point of interest (e.g., the derivative is $\lim_{h\to 0}(f(x+h)-f(x))/h$, undefined at $h=0$).

**Continuity** is the nice case: $f$ is continuous at $a$ if $\lim_{x\to a}f(x)$ exists, $f(a)$ is defined, and they're equal. Geometrically, continuous means you can draw the graph without lifting your pencil.

In MA 2733, limit intuition carries directly into sequences (Chapter 2) and vector functions (Chapter 4). The **growth-rate hierarchy** — knowing that exponentials beat polynomials, which beat logarithms — is the single most-used tool in Chapter 2's convergence tests. Memorize it now.
:::

:::definition[Reference 0.3.1 — Indeterminate Forms and What to Do]
L'Hôpital's Rule applies only when the limit has one of the first two forms below. The others must be *converted* first:

| Form | Strategy |
| --- | --- |
| $0/0$ or $\infty/\infty$ | Apply L'Hôpital directly: $\lim\frac{f}{g}=\lim\frac{f'}{g'}$ |
| $0\cdot\infty$ | Rewrite as $\frac{0}{1/\infty}=\frac{0}{0}$ or $\frac{\infty}{1/0}=\frac{\infty}{\infty}$ |
| $\infty - \infty$ | Combine over a common denominator, then L'Hôpital |
| $1^\infty$, $0^0$, $\infty^0$ | Take $\ln$, convert to $0/0$ or $\infty/\infty$, then exponentiate the result |
:::

:::definition[Reference 0.3.2 — Growth-Rate Hierarchy (memorize this)]
As $x\to\infty$, these function families are ordered from slowest to fastest growth. Any function to the right *dominates* — it grows faster and wins any race to infinity:

$$
\ln x \;\ll\; (\ln x)^k \;\ll\; x^a \;\ll\; x^b\ln x \;\ll\; e^x \;\ll\; x!\;\ll\; x^x \qquad (0< a< b,\;k>1)
$$
The practical consequence: any ratio where the denominator grows faster converges to 0.

- $\displaystyle\lim_{x\to\infty}\frac{(\ln x)^{100}}{x^{0.001}} = 0$ — polynomial beats log, no matter the power
- $\displaystyle\lim_{x\to\infty}\frac{x^{1000}}{e^x} = 0$ — exponential beats any polynomial
- $\displaystyle\lim_{n\to\infty}\frac{e^n}{n!} = 0$ — factorial beats exponential
:::

:::theorem[Theorem 0.3.3 — Squeeze Theorem]
If $g(x) \leq f(x) \leq h(x)$ near $x=a$, and $\displaystyle\lim_{x\to a}g(x) = \lim_{x\to a}h(x) = L$, then $\displaystyle\lim_{x\to a}f(x) = L$. Use this when direct computation and L'Hôpital both fail — it's especially useful when $f$ oscillates (e.g., $\sin$ or $\cos$ inside).
:::

:::callout-tip[Young's Test 3 finite-point limit]
Her specified limit tends to a **finite** $t$, not to infinity. Suppose $\lim_{t\to0}\frac{e^{2t}-1}{t}$ appears in one component of $\mathbf r(t)$. Substitute first: $0/0$. Differentiate numerator and denominator: $\lim_{t\to0}2e^{2t}/1=2$. For a vector limit, apply this step component by component. Test 4 separately uses limits of sequences as $n\to\infty$.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="Squeeze theorem oscillating function bounded by plus and minus x squared">
<path class="fig-guide" d="M32.00 53.94 L32.91 54.59 L33.81 55.23 L34.72 55.86 L35.62 56.49 L36.53 57.12 L37.44 57.74 L38.34 58.36 L39.25 58.97 L40.16 59.58 L41.06 60.19 L41.97 60.79 L42.88 61.39 L43.78 61.98 L44.69 62.57 L45.59 63.16 L46.50 63.74 L47.41 64.32 L48.31 64.89 L49.22 65.46 L50.12 66.03 L51.03 66.59 L51.94 67.15 L52.84 67.70 L53.75 68.25 L54.66 68.80 L55.56 69.34 L56.47 69.88 L57.38 70.41 L58.28 70.94 L59.19 71.47 L60.09 71.99 L61.00 72.50 L61.91 73.02 L62.81 73.53 L63.72 74.03 L64.62 74.53 L65.53 75.03 L66.44 75.53 L67.34 76.01 L68.25 76.50 L69.16 76.98 L70.06 77.46 L70.97 77.93 L71.88 78.40 L72.78 78.87 L73.69 79.33 L74.59 79.78 L75.50 80.24 L76.41 80.69 L77.31 81.13 L78.22 81.57 L79.12 82.01 L80.03 82.44 L80.94 82.87 L81.84 83.30 L82.75 83.72 L83.66 84.13 L84.56 84.55 L85.47 84.96 L86.38 85.36 L87.28 85.76 L88.19 86.16 L89.09 86.55 L90.00 86.94 L90.91 87.32 L91.81 87.71 L92.72 88.08 L93.62 88.45 L94.53 88.82 L95.44 89.19 L96.34 89.55 L97.25 89.90 L98.16 90.26 L99.06 90.61 L99.97 90.95 L100.88 91.29 L101.78 91.63 L102.69 91.96 L103.59 92.29 L104.50 92.61 L105.41 92.93 L106.31 93.25 L107.22 93.56 L108.12 93.87 L109.03 94.17 L109.94 94.47 L110.84 94.77 L111.75 95.06 L112.66 95.35 L113.56 95.63 L114.47 95.91 L115.38 96.19 L116.28 96.46 L117.19 96.73 L118.09 96.99 L119.00 97.25 L119.91 97.51 L120.81 97.76 L121.72 98.01 L122.62 98.25 L123.53 98.49 L124.44 98.73 L125.34 98.96 L126.25 99.18 L127.16 99.41 L128.06 99.63 L128.97 99.84 L129.88 100.05 L130.78 100.26 L131.69 100.47 L132.59 100.66 L133.50 100.86 L134.41 101.05 L135.31 101.24 L136.22 101.42 L137.12 101.60 L138.03 101.78 L138.94 101.95 L139.84 102.11 L140.75 102.28 L141.66 102.44 L142.56 102.59 L143.47 102.74 L144.38 102.89 L145.28 103.03 L146.19 103.17 L147.09 103.31 L148.00 103.44 L148.91 103.56 L149.81 103.69 L150.72 103.81 L151.62 103.92 L152.53 104.03 L153.44 104.14 L154.34 104.24 L155.25 104.34 L156.16 104.43 L157.06 104.53 L157.97 104.61 L158.88 104.69 L159.78 104.77 L160.69 104.85 L161.59 104.92 L162.50 104.98 L163.41 105.05 L164.31 105.11 L165.22 105.16 L166.12 105.21 L167.03 105.26 L167.94 105.30 L168.84 105.34 L169.75 105.37 L170.66 105.40 L171.56 105.43 L172.47 105.45 L173.38 105.47 L174.28 105.48 L175.19 105.49 L176.09 105.50 L177.00 105.50 L177.91 105.50 L178.81 105.49 L179.72 105.48 L180.62 105.47 L181.53 105.45 L182.44 105.43 L183.34 105.40 L184.25 105.37 L185.16 105.34 L186.06 105.30 L186.97 105.26 L187.88 105.21 L188.78 105.16 L189.69 105.11 L190.59 105.05 L191.50 104.98 L192.41 104.92 L193.31 104.85 L194.22 104.77 L195.12 104.69 L196.03 104.61 L196.94 104.53 L197.84 104.43 L198.75 104.34 L199.66 104.24 L200.56 104.14 L201.47 104.03 L202.38 103.92 L203.28 103.81 L204.19 103.69 L205.09 103.56 L206.00 103.44 L206.91 103.31 L207.81 103.17 L208.72 103.03 L209.63 102.89 L210.53 102.74 L211.44 102.59 L212.34 102.44 L213.25 102.28 L214.16 102.11 L215.06 101.95 L215.97 101.78 L216.88 101.60 L217.78 101.42 L218.69 101.24 L219.59 101.05 L220.50 100.86 L221.41 100.66 L222.31 100.47 L223.22 100.26 L224.12 100.05 L225.03 99.84 L225.94 99.63 L226.84 99.41 L227.75 99.18 L228.66 98.96 L229.56 98.73 L230.47 98.49 L231.38 98.25 L232.28 98.01 L233.19 97.76 L234.09 97.51 L235.00 97.25 L235.91 96.99 L236.81 96.73 L237.72 96.46 L238.62 96.19 L239.53 95.91 L240.44 95.63 L241.34 95.35 L242.25 95.06 L243.16 94.77 L244.06 94.47 L244.97 94.17 L245.88 93.87 L246.78 93.56 L247.69 93.25 L248.59 92.93 L249.50 92.61 L250.41 92.29 L251.31 91.96 L252.22 91.63 L253.13 91.29 L254.03 90.95 L254.94 90.61 L255.84 90.26 L256.75 89.90 L257.66 89.55 L258.56 89.19 L259.47 88.82 L260.38 88.45 L261.28 88.08 L262.19 87.71 L263.09 87.32 L264.00 86.94 L264.91 86.55 L265.81 86.16 L266.72 85.76 L267.62 85.36 L268.53 84.96 L269.44 84.55 L270.34 84.13 L271.25 83.72 L272.16 83.30 L273.06 82.87 L273.97 82.44 L274.88 82.01 L275.78 81.57 L276.69 81.13 L277.59 80.69 L278.50 80.24 L279.41 79.78 L280.31 79.33 L281.22 78.87 L282.12 78.40 L283.03 77.93 L283.94 77.46 L284.84 76.98 L285.75 76.50 L286.66 76.01 L287.56 75.53 L288.47 75.03 L289.38 74.53 L290.28 74.03 L291.19 73.53 L292.09 73.02 L293.00 72.50 L293.91 71.99 L294.81 71.47 L295.72 70.94 L296.62 70.41 L297.53 69.88 L298.44 69.34 L299.34 68.80 L300.25 68.25 L301.16 67.70 L302.06 67.15 L302.97 66.59 L303.88 66.03 L304.78 65.46 L305.69 64.89 L306.59 64.32 L307.50 63.74 L308.41 63.16 L309.31 62.57 L310.22 61.98 L311.12 61.39 L312.03 60.79 L312.94 60.19 L313.84 59.58 L314.75 58.97 L315.66 58.36 L316.56 57.74 L317.47 57.12 L318.38 56.49 L319.28 55.86 L320.19 55.23 L321.09 54.59 L322.00 53.94"/>
<path class="fig-guide" d="M32.00 157.06 L32.91 156.41 L33.81 155.77 L34.72 155.14 L35.62 154.51 L36.53 153.88 L37.44 153.26 L38.34 152.64 L39.25 152.03 L40.16 151.42 L41.06 150.81 L41.97 150.21 L42.88 149.61 L43.78 149.02 L44.69 148.43 L45.59 147.84 L46.50 147.26 L47.41 146.68 L48.31 146.11 L49.22 145.54 L50.12 144.97 L51.03 144.41 L51.94 143.85 L52.84 143.30 L53.75 142.75 L54.66 142.20 L55.56 141.66 L56.47 141.12 L57.38 140.59 L58.28 140.06 L59.19 139.53 L60.09 139.01 L61.00 138.50 L61.91 137.98 L62.81 137.47 L63.72 136.97 L64.62 136.47 L65.53 135.97 L66.44 135.47 L67.34 134.99 L68.25 134.50 L69.16 134.02 L70.06 133.54 L70.97 133.07 L71.88 132.60 L72.78 132.13 L73.69 131.67 L74.59 131.22 L75.50 130.76 L76.41 130.31 L77.31 129.87 L78.22 129.43 L79.12 128.99 L80.03 128.56 L80.94 128.13 L81.84 127.70 L82.75 127.28 L83.66 126.87 L84.56 126.45 L85.47 126.04 L86.38 125.64 L87.28 125.24 L88.19 124.84 L89.09 124.45 L90.00 124.06 L90.91 123.68 L91.81 123.29 L92.72 122.92 L93.62 122.55 L94.53 122.18 L95.44 121.81 L96.34 121.45 L97.25 121.10 L98.16 120.74 L99.06 120.39 L99.97 120.05 L100.88 119.71 L101.78 119.37 L102.69 119.04 L103.59 118.71 L104.50 118.39 L105.41 118.07 L106.31 117.75 L107.22 117.44 L108.12 117.13 L109.03 116.83 L109.94 116.53 L110.84 116.23 L111.75 115.94 L112.66 115.65 L113.56 115.37 L114.47 115.09 L115.38 114.81 L116.28 114.54 L117.19 114.27 L118.09 114.01 L119.00 113.75 L119.91 113.49 L120.81 113.24 L121.72 112.99 L122.62 112.75 L123.53 112.51 L124.44 112.27 L125.34 112.04 L126.25 111.82 L127.16 111.59 L128.06 111.37 L128.97 111.16 L129.88 110.95 L130.78 110.74 L131.69 110.53 L132.59 110.34 L133.50 110.14 L134.41 109.95 L135.31 109.76 L136.22 109.58 L137.12 109.40 L138.03 109.22 L138.94 109.05 L139.84 108.89 L140.75 108.72 L141.66 108.56 L142.56 108.41 L143.47 108.26 L144.38 108.11 L145.28 107.97 L146.19 107.83 L147.09 107.69 L148.00 107.56 L148.91 107.44 L149.81 107.31 L150.72 107.19 L151.62 107.08 L152.53 106.97 L153.44 106.86 L154.34 106.76 L155.25 106.66 L156.16 106.57 L157.06 106.47 L157.97 106.39 L158.88 106.31 L159.78 106.23 L160.69 106.15 L161.59 106.08 L162.50 106.02 L163.41 105.95 L164.31 105.89 L165.22 105.84 L166.12 105.79 L167.03 105.74 L167.94 105.70 L168.84 105.66 L169.75 105.63 L170.66 105.60 L171.56 105.57 L172.47 105.55 L173.38 105.53 L174.28 105.52 L175.19 105.51 L176.09 105.50 L177.00 105.50 L177.91 105.50 L178.81 105.51 L179.72 105.52 L180.62 105.53 L181.53 105.55 L182.44 105.57 L183.34 105.60 L184.25 105.63 L185.16 105.66 L186.06 105.70 L186.97 105.74 L187.88 105.79 L188.78 105.84 L189.69 105.89 L190.59 105.95 L191.50 106.02 L192.41 106.08 L193.31 106.15 L194.22 106.23 L195.12 106.31 L196.03 106.39 L196.94 106.47 L197.84 106.57 L198.75 106.66 L199.66 106.76 L200.56 106.86 L201.47 106.97 L202.38 107.08 L203.28 107.19 L204.19 107.31 L205.09 107.44 L206.00 107.56 L206.91 107.69 L207.81 107.83 L208.72 107.97 L209.63 108.11 L210.53 108.26 L211.44 108.41 L212.34 108.56 L213.25 108.72 L214.16 108.89 L215.06 109.05 L215.97 109.22 L216.88 109.40 L217.78 109.58 L218.69 109.76 L219.59 109.95 L220.50 110.14 L221.41 110.34 L222.31 110.53 L223.22 110.74 L224.12 110.95 L225.03 111.16 L225.94 111.37 L226.84 111.59 L227.75 111.82 L228.66 112.04 L229.56 112.27 L230.47 112.51 L231.38 112.75 L232.28 112.99 L233.19 113.24 L234.09 113.49 L235.00 113.75 L235.91 114.01 L236.81 114.27 L237.72 114.54 L238.62 114.81 L239.53 115.09 L240.44 115.37 L241.34 115.65 L242.25 115.94 L243.16 116.23 L244.06 116.53 L244.97 116.83 L245.88 117.13 L246.78 117.44 L247.69 117.75 L248.59 118.07 L249.50 118.39 L250.41 118.71 L251.31 119.04 L252.22 119.37 L253.13 119.71 L254.03 120.05 L254.94 120.39 L255.84 120.74 L256.75 121.10 L257.66 121.45 L258.56 121.81 L259.47 122.18 L260.38 122.55 L261.28 122.92 L262.19 123.29 L263.09 123.68 L264.00 124.06 L264.91 124.45 L265.81 124.84 L266.72 125.24 L267.62 125.64 L268.53 126.04 L269.44 126.45 L270.34 126.87 L271.25 127.28 L272.16 127.70 L273.06 128.13 L273.97 128.56 L274.88 128.99 L275.78 129.43 L276.69 129.87 L277.59 130.31 L278.50 130.76 L279.41 131.22 L280.31 131.67 L281.22 132.13 L282.12 132.60 L283.03 133.07 L283.94 133.54 L284.84 134.02 L285.75 134.50 L286.66 134.99 L287.56 135.47 L288.47 135.97 L289.38 136.47 L290.28 136.97 L291.19 137.47 L292.09 137.98 L293.00 138.50 L293.91 139.01 L294.81 139.53 L295.72 140.06 L296.62 140.59 L297.53 141.12 L298.44 141.66 L299.34 142.20 L300.25 142.75 L301.16 143.30 L302.06 143.85 L302.97 144.41 L303.88 144.97 L304.78 145.54 L305.69 146.11 L306.59 146.68 L307.50 147.26 L308.41 147.84 L309.31 148.43 L310.22 149.02 L311.12 149.61 L312.03 150.21 L312.94 150.81 L313.84 151.42 L314.75 152.03 L315.66 152.64 L316.56 153.26 L317.47 153.88 L318.38 154.51 L319.28 155.14 L320.19 155.77 L321.09 156.41 L322.00 157.06"/>
<path class="fig-curve" d="M32.00 154.43 L32.34 154.24 L32.68 154.06 L33.02 153.88 L33.36 153.69 L33.71 153.51 L34.05 153.33 L34.39 153.15 L34.73 152.96 L35.07 152.78 L35.41 152.60 L35.75 152.41 L36.09 152.23 L36.44 152.04 L36.78 151.86 L37.12 151.68 L37.46 151.49 L37.80 151.31 L38.14 151.12 L38.48 150.94 L38.82 150.76 L39.16 150.57 L39.51 150.39 L39.85 150.20 L40.19 150.02 L40.53 149.83 L40.87 149.65 L41.21 149.46 L41.55 149.27 L41.89 149.09 L42.24 148.90 L42.58 148.72 L42.92 148.53 L43.26 148.34 L43.60 148.16 L43.94 147.97 L44.28 147.79 L44.62 147.60 L44.96 147.41 L45.31 147.23 L45.65 147.04 L45.99 146.85 L46.33 146.66 L46.67 146.48 L47.01 146.29 L47.35 146.10 L47.69 145.91 L48.04 145.73 L48.38 145.54 L48.72 145.35 L49.06 145.16 L49.40 144.97 L49.74 144.79 L50.08 144.60 L50.42 144.41 L50.76 144.22 L51.11 144.03 L51.45 143.84 L51.79 143.65 L52.13 143.46 L52.47 143.27 L52.81 143.08 L53.15 142.89 L53.49 142.70 L53.84 142.51 L54.18 142.32 L54.52 142.13 L54.86 141.94 L55.20 141.75 L55.54 141.56 L55.88 141.37 L56.22 141.18 L56.56 140.99 L56.91 140.80 L57.25 140.61 L57.59 140.42 L57.93 140.22 L58.27 140.03 L58.61 139.84 L58.95 139.65 L59.29 139.46 L59.64 139.26 L59.98 139.07 L60.32 138.88 L60.66 138.69 L61.00 138.49 L61.34 138.30 L61.68 138.11 L62.02 137.92 L62.36 137.72 L62.71 137.53 L63.05 137.34 L63.39 137.14 L63.73 136.95 L64.07 136.75 L64.41 136.56 L64.75 136.37 L65.09 136.17 L65.44 135.98 L65.78 135.78 L66.12 135.59 L66.46 135.39 L66.80 135.20 L67.14 135.00 L67.48 134.81 L67.82 134.61 L68.16 134.42 L68.51 134.22 L68.85 134.02 L69.19 133.83 L69.53 133.63 L69.87 133.44 L70.21 133.24 L70.55 133.04 L70.89 132.85 L71.24 132.65 L71.58 132.45 L71.92 132.26 L72.26 132.06 L72.60 131.86 L72.94 131.66 L73.28 131.47 L73.62 131.27 L73.96 131.07 L74.31 130.87 L74.65 130.68 L74.99 130.48 L75.33 130.28 L75.67 130.08 L76.01 129.88 L76.35 129.69 L76.69 129.49 L77.04 129.29 L77.38 129.09 L77.72 128.89 L78.06 128.69 L78.40 128.49 L78.74 128.29 L79.08 128.09 L79.42 127.89 L79.76 127.69 L80.11 127.49 L80.45 127.29 L80.79 127.10 L81.13 126.90 L81.47 126.70 L81.81 126.50 L82.15 126.30 L82.49 126.09 L82.84 125.89 L83.18 125.69 L83.52 125.49 L83.86 125.29 L84.20 125.09 L84.54 124.89 L84.88 124.69 L85.22 124.49 L85.56 124.29 L85.91 124.09 L86.25 123.89 L86.59 123.69 L86.93 123.49 L87.27 123.28 L87.61 123.08 L87.95 122.88 L88.29 122.68 L88.64 122.48 L88.98 122.28 L89.32 122.08 L89.66 121.88 L90.00 121.68 L90.34 121.47 L90.68 121.27 L91.02 121.07 L91.36 120.87 L91.71 120.67 L92.05 120.47 L92.39 120.27 L92.73 120.07 L93.07 119.86 L93.41 119.66 L93.75 119.46 L94.09 119.26 L94.44 119.06 L94.78 118.86 L95.12 118.66 L95.46 118.46 L95.80 118.26 L96.14 118.06 L96.48 117.86 L96.82 117.66 L97.16 117.46 L97.51 117.26 L97.85 117.06 L98.19 116.86 L98.53 116.66 L98.87 116.46 L99.21 116.26 L99.55 116.06 L99.89 115.87 L100.24 115.67 L100.58 115.47 L100.92 115.27 L101.26 115.07 L101.60 114.88 L101.94 114.68 L102.28 114.48 L102.62 114.29 L102.96 114.09 L103.31 113.90 L103.65 113.70 L103.99 113.51 L104.33 113.31 L104.67 113.12 L105.01 112.92 L105.35 112.73 L105.69 112.54 L106.04 112.34 L106.38 112.15 L106.72 111.96 L107.06 111.77 L107.40 111.58 L107.74 111.39 L108.08 111.20 L108.42 111.01 L108.76 110.83 L109.11 110.64 L109.45 110.45 L109.79 110.27 L110.13 110.08 L110.47 109.90 L110.81 109.71 L111.15 109.53 L111.49 109.35 L111.84 109.17 L112.18 108.99 L112.52 108.81 L112.86 108.63 L113.20 108.46 L113.54 108.28 L113.88 108.11 L114.22 107.93 L114.56 107.76 L114.91 107.59 L115.25 107.42 L115.59 107.25 L115.93 107.08 L116.27 106.91 L116.61 106.75 L116.95 106.59 L117.29 106.42 L117.64 106.26 L117.98 106.10 L118.32 105.95 L118.66 105.79 L119.00 105.64 L119.34 105.48 L119.68 105.33 L120.02 105.19 L120.36 105.04 L120.71 104.89 L121.05 104.75 L121.39 104.61 L121.73 104.47 L122.07 104.34 L122.41 104.20 L122.75 104.07 L123.09 103.94 L123.44 103.81 L123.78 103.69 L124.12 103.57 L124.46 103.45 L124.80 103.33 L125.14 103.22 L125.48 103.11 L125.82 103.00 L126.16 102.89 L126.51 102.79 L126.85 102.69 L127.19 102.60 L127.53 102.51 L127.87 102.42 L128.21 102.33 L128.55 102.25 L128.89 102.17 L129.24 102.10 L129.58 102.03 L129.92 101.96 L130.26 101.90 L130.60 101.85 L130.94 101.79 L131.28 101.74 L131.62 101.70 L131.96 101.66 L132.31 101.62 L132.65 101.59 L132.99 101.56 L133.33 101.54 L133.67 101.53 L134.01 101.51 L134.35 101.51 L134.69 101.51 L135.04 101.51 L135.38 101.52 L135.72 101.54 L136.06 101.56 L136.40 101.58 L136.74 101.61 L137.08 101.65 L137.42 101.69 L137.76 101.74 L138.11 101.80 L138.45 101.86 L138.79 101.92 L139.13 101.99 L139.47 102.07 L139.81 102.15 L140.15 102.24 L140.49 102.34 L140.84 102.44 L141.18 102.54 L141.52 102.65 L141.86 102.77 L142.20 102.89 L142.54 103.01 L142.88 103.14 L143.22 103.28 L143.56 103.42 L143.91 103.56 L144.25 103.71 L144.59 103.86 L144.93 104.01 L145.27 104.17 L145.61 104.32 L145.95 104.48 L146.29 104.64 L146.64 104.80 L146.98 104.96 L147.32 105.12 L147.66 105.28 L148.00 105.43 L148.34 105.58 L148.68 105.73 L149.02 105.87 L149.36 106.01 L149.71 106.14 L150.05 106.26 L150.39 106.37 L150.73 106.48 L151.07 106.57 L151.41 106.65 L151.75 106.72 L152.09 106.78 L152.44 106.82 L152.78 106.84 L153.12 106.85 L153.46 106.84 L153.80 106.82 L154.14 106.78 L154.48 106.72 L154.82 106.65 L155.16 106.55 L155.51 106.45 L155.85 106.33 L156.19 106.20 L156.53 106.06 L156.87 105.91 L157.21 105.75 L157.55 105.60 L157.89 105.44 L158.24 105.30 L158.58 105.17 L158.92 105.05 L159.26 104.95 L159.60 104.88 L159.94 104.83 L160.28 104.82 L160.62 104.84 L160.96 104.90 L161.31 104.99 L161.65 105.10 L161.99 105.24 L162.33 105.39 L162.67 105.54 L163.01 105.68 L163.35 105.80 L163.69 105.88 L164.04 105.91 L164.38 105.88 L164.72 105.80 L165.06 105.68 L165.40 105.53 L165.74 105.38 L166.08 105.27 L166.42 105.23 L166.76 105.27 L167.11 105.38 L167.45 105.53 L167.79 105.65 L168.13 105.69 L168.47 105.62 L168.81 105.48 L169.15 105.36 L169.49 105.38 L169.84 105.52 L170.18 105.61 L170.52 105.53 L170.86 105.41 L171.20 105.49 L171.54 105.57 L171.88 105.45 L172.22 105.51 L172.56 105.50 L172.91 105.51 L173.25 105.47 L173.59 105.51 L173.93 105.51 L174.27 105.49 L174.61 105.51 L174.95 105.51 L175.29 105.50 L175.64 105.50 L175.98 105.50 L176.32 105.50 L176.66 105.50 M177.34 105.50 L177.68 105.50 L178.02 105.50 L178.36 105.50 L178.71 105.50 L179.05 105.49 L179.39 105.49 L179.73 105.51 L180.07 105.49 L180.41 105.49 L180.75 105.53 L181.09 105.49 L181.44 105.50 L181.78 105.49 L182.12 105.55 L182.46 105.43 L182.80 105.51 L183.14 105.59 L183.48 105.47 L183.82 105.39 L184.16 105.48 L184.51 105.62 L184.85 105.64 L185.19 105.52 L185.53 105.38 L185.87 105.31 L186.21 105.35 L186.55 105.47 L186.89 105.62 L187.24 105.73 L187.58 105.77 L187.92 105.73 L188.26 105.62 L188.60 105.47 L188.94 105.32 L189.28 105.20 L189.62 105.12 L189.96 105.09 L190.31 105.12 L190.65 105.20 L190.99 105.32 L191.33 105.46 L191.67 105.61 L192.01 105.76 L192.35 105.90 L192.69 106.01 L193.04 106.10 L193.38 106.16 L193.72 106.18 L194.06 106.17 L194.40 106.12 L194.74 106.05 L195.08 105.95 L195.42 105.83 L195.76 105.70 L196.11 105.56 L196.45 105.40 L196.79 105.25 L197.13 105.09 L197.47 104.94 L197.81 104.80 L198.15 104.67 L198.49 104.55 L198.84 104.45 L199.18 104.35 L199.52 104.28 L199.86 104.22 L200.20 104.18 L200.54 104.16 L200.88 104.15 L201.22 104.16 L201.56 104.18 L201.91 104.22 L202.25 104.28 L202.59 104.35 L202.93 104.43 L203.27 104.52 L203.61 104.63 L203.95 104.74 L204.29 104.86 L204.64 104.99 L204.98 105.13 L205.32 105.27 L205.66 105.42 L206.00 105.57 L206.34 105.72 L206.68 105.88 L207.02 106.04 L207.36 106.20 L207.71 106.36 L208.05 106.52 L208.39 106.68 L208.73 106.83 L209.07 106.99 L209.41 107.14 L209.75 107.29 L210.09 107.44 L210.44 107.58 L210.78 107.72 L211.12 107.86 L211.46 107.99 L211.80 108.11 L212.14 108.23 L212.48 108.35 L212.82 108.46 L213.16 108.56 L213.51 108.66 L213.85 108.76 L214.19 108.85 L214.53 108.93 L214.87 109.01 L215.21 109.08 L215.55 109.14 L215.89 109.20 L216.24 109.26 L216.58 109.31 L216.92 109.35 L217.26 109.39 L217.60 109.42 L217.94 109.44 L218.28 109.46 L218.62 109.48 L218.96 109.49 L219.31 109.49 L219.65 109.49 L219.99 109.49 L220.33 109.47 L220.67 109.46 L221.01 109.44 L221.35 109.41 L221.69 109.38 L222.04 109.34 L222.38 109.30 L222.72 109.26 L223.06 109.21 L223.40 109.15 L223.74 109.10 L224.08 109.04 L224.42 108.97 L224.76 108.90 L225.11 108.83 L225.45 108.75 L225.79 108.67 L226.13 108.58 L226.47 108.49 L226.81 108.40 L227.15 108.31 L227.49 108.21 L227.84 108.11 L228.18 108.00 L228.52 107.89 L228.86 107.78 L229.20 107.67 L229.54 107.55 L229.88 107.43 L230.22 107.31 L230.56 107.19 L230.91 107.06 L231.25 106.93 L231.59 106.80 L231.93 106.66 L232.27 106.53 L232.61 106.39 L232.95 106.25 L233.29 106.11 L233.64 105.96 L233.98 105.81 L234.32 105.67 L234.66 105.52 L235.00 105.36 L235.34 105.21 L235.68 105.05 L236.02 104.90 L236.36 104.74 L236.71 104.58 L237.05 104.41 L237.39 104.25 L237.73 104.09 L238.07 103.92 L238.41 103.75 L238.75 103.58 L239.09 103.41 L239.44 103.24 L239.78 103.07 L240.12 102.89 L240.46 102.72 L240.80 102.54 L241.14 102.37 L241.48 102.19 L241.82 102.01 L242.16 101.83 L242.51 101.65 L242.85 101.47 L243.19 101.29 L243.53 101.10 L243.87 100.92 L244.21 100.73 L244.55 100.55 L244.89 100.36 L245.24 100.17 L245.58 99.99 L245.92 99.80 L246.26 99.61 L246.60 99.42 L246.94 99.23 L247.28 99.04 L247.62 98.85 L247.96 98.66 L248.31 98.46 L248.65 98.27 L248.99 98.08 L249.33 97.88 L249.67 97.69 L250.01 97.49 L250.35 97.30 L250.69 97.10 L251.04 96.91 L251.38 96.71 L251.72 96.52 L252.06 96.32 L252.40 96.12 L252.74 95.93 L253.08 95.73 L253.42 95.53 L253.76 95.33 L254.11 95.13 L254.45 94.94 L254.79 94.74 L255.13 94.54 L255.47 94.34 L255.81 94.14 L256.15 93.94 L256.49 93.74 L256.84 93.54 L257.18 93.34 L257.52 93.14 L257.86 92.94 L258.20 92.74 L258.54 92.54 L258.88 92.34 L259.22 92.14 L259.56 91.94 L259.91 91.74 L260.25 91.54 L260.59 91.34 L260.93 91.14 L261.27 90.93 L261.61 90.73 L261.95 90.53 L262.29 90.33 L262.64 90.13 L262.98 89.93 L263.32 89.73 L263.66 89.53 L264.00 89.32 L264.34 89.12 L264.68 88.92 L265.02 88.72 L265.36 88.52 L265.71 88.32 L266.05 88.12 L266.39 87.92 L266.73 87.72 L267.07 87.51 L267.41 87.31 L267.75 87.11 L268.09 86.91 L268.44 86.71 L268.78 86.51 L269.12 86.31 L269.46 86.11 L269.80 85.91 L270.14 85.71 L270.48 85.51 L270.82 85.31 L271.16 85.11 L271.51 84.91 L271.85 84.70 L272.19 84.50 L272.53 84.30 L272.87 84.10 L273.21 83.90 L273.55 83.71 L273.89 83.51 L274.24 83.31 L274.58 83.11 L274.92 82.91 L275.26 82.71 L275.60 82.51 L275.94 82.31 L276.28 82.11 L276.62 81.91 L276.96 81.71 L277.31 81.51 L277.65 81.31 L277.99 81.12 L278.33 80.92 L278.67 80.72 L279.01 80.52 L279.35 80.32 L279.69 80.13 L280.04 79.93 L280.38 79.73 L280.72 79.53 L281.06 79.34 L281.40 79.14 L281.74 78.94 L282.08 78.74 L282.42 78.55 L282.76 78.35 L283.11 78.15 L283.45 77.96 L283.79 77.76 L284.13 77.56 L284.47 77.37 L284.81 77.17 L285.15 76.98 L285.49 76.78 L285.84 76.58 L286.18 76.39 L286.52 76.19 L286.86 76.00 L287.20 75.80 L287.54 75.61 L287.88 75.41 L288.22 75.22 L288.56 75.02 L288.91 74.83 L289.25 74.63 L289.59 74.44 L289.93 74.25 L290.27 74.05 L290.61 73.86 L290.95 73.66 L291.29 73.47 L291.64 73.28 L291.98 73.08 L292.32 72.89 L292.66 72.70 L293.00 72.51 L293.34 72.31 L293.68 72.12 L294.02 71.93 L294.36 71.74 L294.71 71.54 L295.05 71.35 L295.39 71.16 L295.73 70.97 L296.07 70.78 L296.41 70.58 L296.75 70.39 L297.09 70.20 L297.44 70.01 L297.78 69.82 L298.12 69.63 L298.46 69.44 L298.80 69.25 L299.14 69.06 L299.48 68.87 L299.82 68.68 L300.16 68.49 L300.51 68.30 L300.85 68.11 L301.19 67.92 L301.53 67.73 L301.87 67.54 L302.21 67.35 L302.55 67.16 L302.89 66.97 L303.24 66.78 L303.58 66.59 L303.92 66.40 L304.26 66.21 L304.60 66.03 L304.94 65.84 L305.28 65.65 L305.62 65.46 L305.96 65.27 L306.31 65.09 L306.65 64.90 L306.99 64.71 L307.33 64.52 L307.67 64.34 L308.01 64.15 L308.35 63.96 L308.69 63.77 L309.04 63.59 L309.38 63.40 L309.72 63.21 L310.06 63.03 L310.40 62.84 L310.74 62.66 L311.08 62.47 L311.42 62.28 L311.76 62.10 L312.11 61.91 L312.45 61.73 L312.79 61.54 L313.13 61.35 L313.47 61.17 L313.81 60.98 L314.15 60.80 L314.49 60.61 L314.84 60.43 L315.18 60.24 L315.52 60.06 L315.86 59.88 L316.20 59.69 L316.54 59.51 L316.88 59.32 L317.22 59.14 L317.56 58.96 L317.91 58.77 L318.25 58.59 L318.59 58.40 L318.93 58.22 L319.27 58.04 L319.61 57.85 L319.95 57.67 L320.29 57.49 L320.64 57.31 L320.98 57.12 L321.32 56.94 L321.66 56.76 L322.00 56.57"/>
</svg>
<figcaption>Even though $\sin(1/x)$ oscillates infinitely often near zero, $-x^2\le x^2\sin(1/x)\le x^2$ forces the product to zero.</figcaption>
</figure>

### The handwritten limit checklist

Start by substituting the approach value into the **original** expression. If you get a finite number with a nonzero denominator, stop: continuity has already solved it. If you obtain $0/0$ or $\infty/\infty$, record that indeterminate form and then decide between cancellation, conjugates, a standard limit, and L'Hôpital. Differentiating numerator and denominator is legal only for the relevant quotient forms under L'Hôpital's hypotheses. It is not the quotient rule, and it does not apply directly to a difference such as $\infty-\infty$. Turn that difference into a single fraction first.

For limits near a **finite** number $t=a$, also check whether logarithms, roots, or division create a one-sided domain. If the expression is only defined for $t>a$, a left-hand limit is not meaningful over the reals. If the question asks for a vector limit, evaluate the three components separately and put their limits back into the same vector order. Failure of even one component limit prevents the whole vector limit from existing. For a derivative-based computation, if L'Hôpital has to be used twice, show the new $0/0$ or $\infty/\infty$ after the first differentiation; do not assume another differentiation is automatically authorized.

The familiar standard limit $\lim_{u\to0}\sin u/u=1$ is particularly useful when a trigonometric argument contains a constant multiplier. Make the entire argument your new variable or multiply and divide by it. The constant you introduce has to be compensated elsewhere in the fraction. For a sequence limit, treating the integer index as a continuous real variable can unlock the same methods, provided the continuous extension agrees with the sequence at integer inputs.

### Worked examples

:::::example[Example 0.9 — L'Hôpital applied twice]
Evaluate $\displaystyle\lim_{x\to 0}\frac{\sin x - x}{x^3}$.

::::answer[Answer]
**Answer:** $-1/6$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Check the form at $x=0$: numerator $\sin 0 - 0 = 0$, denominator $0^3 = 0$.
3. Form is $0/0$. Apply L'Hôpital (differentiate numerator and denominator separately):

$$
\lim_{x\to 0}\frac{\sin x - x}{x^3} \overset{\text{L'H}}{=} \lim_{x\to 0}\frac{\cos x - 1}{3x^2}
$$
4. Check again: at $x=0$, numerator $\cos 0 - 1 = 0$, denominator $0$.
5. Still $0/0$. Apply again:

$$
\overset{\text{L'H}}{=} \lim_{x\to 0}\frac{-\sin x}{6x}
$$
6. Still $0/0$. Apply a third time:

$$
\overset{\text{L'H}}{=} \lim_{x\to 0}\frac{-\cos x}{6} = \frac{-\cos 0}{6} = \frac{-1}{6}
$$
7. *Note: each application of L'Hôpital must be preceded by verifying the form is still $0/0$ or $\infty/\infty$.
8. Applying it to $-\sin x/(6x)$ directly (plugging in) confirms it's still $0/0$, so we proceed.*
9. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::::example[Example 0.10 — The $1^\infty$ form]
Evaluate $\displaystyle\lim_{x\to\infty}\left(1+\frac{2}{x}\right)^{\!3x}$.

::::answer[Answer]
**Answer:** $e^6$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. This is $1^\infty$ — the base approaches 1 and the exponent approaches $\infty$.
3. The standard technique: let $L$ be the limit, take $\ln$ of both sides, evaluate that limit, then exponentiate.
4. Let $y = \left(1+\tfrac{2}{x}\right)^{3x}$.
5. Then:

$$
\ln y = 3x \ln\!\left(1+\frac{2}{x}\right)
$$
6. As $x\to\infty$ this is $\infty \cdot 0$ — rewrite as a fraction:

$$
\lim_{x\to\infty}\ln y = \lim_{x\to\infty}\frac{\ln\!\left(1+2/x\right)}{1/(3x)} \overset{\text{L'H}}{=} \lim_{x\to\infty}\frac{\frac{-2/x^2}{1+2/x}}{-1/(3x^2)}
$$
7. Simplify the algebra — the $x^2$ factors cancel:

$$
= \lim_{x\to\infty}\frac{-2/x^2}{1+2/x}\cdot\frac{3x^2}{-1} = \lim_{x\to\infty}\frac{6}{1+2/x} = \frac{6}{1+0} = 6
$$
8. So $\ln L = 6$, therefore $L = e^6$.
9. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::::example[Example 0.11 — Squeeze theorem]
Evaluate $\displaystyle\lim_{x\to 0} x^2 \sin\!\left(\frac{1}{x}\right)$.

::::answer[Answer]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. L'Hôpital won't help here — this is not a ratio, and the oscillation of $\sin(1/x)$ near 0 makes direct substitution impossible.
3. Use the Squeeze Theorem instead.
4. We know that for all $x\neq 0$: $-1 \leq \sin(1/x) \leq 1$.
5. Multiply through by $x^2$ (which is positive):

$$
-x^2 \leq x^2\sin\!\left(\frac{1}{x}\right) \leq x^2
$$
6. As $x\to 0$: $-x^2 \to 0$ and $x^2 \to 0$.
7. By the Squeeze Theorem:

$$
\lim_{x\to 0}x^2\sin\!\left(\frac{1}{x}\right) = 0
$$
8. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::::example[Example 0.12 — The $\infty - \infty$ form]
Evaluate $\displaystyle\lim_{x\to 0^+}\!\left(\frac{1}{\sin x} - \frac{1}{x}\right)$.

::::answer[Answer]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. This is $\infty - \infty$ as $x\to 0^+$.
3. First, combine over a common denominator:

$$
\frac{1}{\sin x}-\frac{1}{x} = \frac{x - \sin x}{x\sin x}
$$
4. Now as $x\to 0^+$: numerator $\to 0$, denominator $\to 0$.
5. Form is $0/0$. Apply L'Hôpital:

$$
\lim_{x\to 0^+}\frac{x-\sin x}{x\sin x} \overset{\text{L'H}}{=} \lim_{x\to 0^+}\frac{1-\cos x}{\sin x + x\cos x}
$$
6. Still $0/0$. Apply again:

$$
\overset{\text{L'H}}{=} \lim_{x\to 0^+}\frac{\sin x}{\cos x + \cos x - x\sin x} = \frac{0}{1+1-0} = 0
$$
7. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::callout-pitfall[Watch out for]
- **L'Hôpital on non-indeterminate forms.** If $\lim_{x\to a}g(x)\neq 0$, then $\lim f/g = (\lim f)/(\lim g)$ by the quotient limit law — no L'Hôpital needed or allowed. Applying L'Hôpital when the form is $3/7$ (not indeterminate) gives the wrong answer.
- **Forgetting to exponentiate after the $\ln$ trick.** After computing $\ln L = 6$, the answer is $L = e^6$, not $6$. Students frequently stop at the $\ln$ step and report the wrong number.
- **Growth hierarchy direction.** $\ln x \ll x$ means $\ln x$ is the *slower* grower, so $\frac{\ln x}{x}\to 0$ (not $\infty$) as $x\to\infty$.
:::

### Practice problems

:::::problem[Problem 0.15 — Removable-factor limit]{difficulty=easy}
Evaluate $\displaystyle\lim_{x\to 3}\frac{x^2-9}{x-3}$ without L'Hôpital.

::::solution[Solution]
**Answer:** $6$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Factor: $\frac{(x-3)(x+3)}{x-3}=x+3$ for $x\neq 3$.
3. Limit $= 3+3=6$.
4. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.16 — Logarithm versus powers]{difficulty=easy}
Use the growth hierarchy to evaluate $\displaystyle\lim_{n\to\infty}\frac{(\ln n)^{50}}{n}$.

::::solution[Solution]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Logarithm grows slower than any power of $n$, so $\frac{(\ln n)^{50}}{n}\to 0$.
3. (Formally: apply for $x>1$, take logarithms only as part of the comparison.
4. Repeated L'Hôpital requires the correct derivative at every stage; it does not produce a simple $50!/n^{51}$ expression.)
5. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.17 — Logarithmic product limit]{difficulty=standard}
Evaluate $\displaystyle\lim_{x\to 0^+}x\ln x$.

::::solution[Solution]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Form $0\cdot(-\infty)$.
3. Rewrite: $\frac{\ln x}{1/x}$, form $-\infty/\infty$.
4. L'Hôpital: $\frac{1/x}{-1/x^2}=\frac{x^2\cdot(1/x)}{-1}=-x\to 0$.
5. $0$.
6. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.18 — Conjugate-radical limit]{difficulty=standard}
Evaluate $\displaystyle\lim_{x\to\infty}\left(\sqrt{x^2+x}-x\right)$. (*Hint: multiply by the conjugate.*)

::::solution[Solution]
**Answer:** $1/2$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Multiply by $\frac{\sqrt{x^2+x}+x}{\sqrt{x^2+x}+x}$: $\frac{(x^2+x)-x^2}{\sqrt{x^2+x}+x}=\frac{x}{\sqrt{x^2+x}+x}$.
3. Divide top and bottom by $x$: $\frac{1}{\sqrt{1+1/x}+1}\to\frac{1}{\sqrt{1}+1}=\frac{1}{2}$.
4. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.19 — Repeated L'Hôpital limit]{difficulty=standard}
Evaluate $\displaystyle\lim_{x\to 0}\frac{e^x - 1 - x - x^2/2}{x^3}$.

::::solution[Solution]
**Answer:** $1/6$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Form $0/0$. L'Hôpital: $\frac{e^x-1-x}{3x^2}$.
3. Still $0/0$. Again: $\frac{e^x-1}{6x}$.
4. Still $0/0$. Again: $\frac{e^x}{6}\to\frac{1}{6}$.
5. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.20 — Indeterminate exponential]{difficulty=challenge}
Evaluate $\displaystyle\lim_{x\to 0^+}x^x$.

::::solution[Solution]
**Answer:** $1$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Form $0^0$. Let $y=x^x$, so $\ln y = x\ln x$.
3. From Problem 0.17, $\lim_{x\to0^+}x\ln x=0$.
4. So $\ln L=0$, giving $L=e^0=1$.
5. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.21 — Squeeze theorem limit]{difficulty=challenge}
Use the Squeeze Theorem to show $\displaystyle\lim_{n\to\infty}\frac{\cos n}{n}=0$.

::::solution[Solution]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. For all $n$: $-1\leq\cos n\leq 1$.
3. Divide by $n>0$: $-\frac{1}{n}\leq\frac{\cos n}{n}\leq\frac{1}{n}$.
4. Both bounds $\to 0$. By Squeeze Theorem, the limit is $0$.
5. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

## 0.4 Differentiation Recap

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“The paradox of the derivative” — 3Blue1Brown

“Chain rule | Derivative rules” — Khan Academy
:::

:::callout-intuition[Intuition]
The derivative $f'(x)$ is the instantaneous rate of change of $f$ at $x$ — the slope of the tangent line at that point. Geometrically: zoom in on the graph near $x$, and eventually it looks like a straight line; the slope of that line is $f'(x)$.

In MA 2733 differentiation appears in several disguises. The slope of a parametric curve $(x(t),y(t))$ is $dy/dx = (dy/dt)/(dx/dt)$ — just the chain rule applied to a different parameterization. Arc-length and curvature formulas involve $\vec{r}'(t)$ — a vector of derivatives. The gradient $\nabla f$ is the collection of all partial derivatives of $f$ (beyond this course segment). None of that machinery makes sense unless the one-variable derivatives feel automatic.

The **chain rule** is the most important rule here — it is applied constantly, often in several layers simultaneously. If you build one habit from this section, let it be: always ask "is there a composite function here?" before differentiating.
:::

:::definition[Reference 0.4.1 — Differentiation Rules Reference]
| Function | Derivative | Notes |
| --- | --- | --- |
| $x^n$ | $nx^{n-1}$ | Works for all real $n$ |
| $e^x$ | $e^x$ | The only function equal to its own derivative |
| $a^x$ | $a^x\ln a$ | Via $a^x=e^{x\ln a}$ |
| $\ln|x|$ | $1/x$ | The $|\cdot|$ lets this work for $x<0$ too |
| $\sin x$ | $\cos x$ |  |
| $\cos x$ | $-\sin x$ | Only one with a minus sign |
| $\tan x$ | $\sec^2 x$ |  |
| $\sec x$ | $\sec x\tan x$ |  |
| $\arcsin x$ | $\dfrac{1}{\sqrt{1-x^2}}$ | Domain $|x|<1$ |
| $\arctan x$ | $\dfrac{1}{1+x^2}$ | Domain: all reals |
| Product $fg$ | $f'g+fg'$ | "First times derivative of second plus…" |
| Quotient $f/g$ | $\dfrac{f'g-fg'}{g^2}$ | "Low d-high minus high d-low over low squared" |
| Chain $f(g(x))$ | $f'(g(x))\cdot g'(x)$ | Outside derivative × inside derivative |
:::

Key Idea — How to Apply the Chain Rule

Think of composite functions as having "layers" like an onion. To differentiate:

1. Identify the outermost function and differentiate it, leaving the inside unchanged.
2. Multiply by the derivative of the inside function.
3. Repeat for each additional layer, working from outside in.

Example with three layers: $h(x) = \ln(\sin(x^2))$. Outer: $\ln(\cdot)$. Middle: $\sin(\cdot)$. Inner: $x^2$.

$$
\frac{d}{dx}[\ln(\sin(x^2))] = \frac{1}{\sin(x^2)}\cdot\cos(x^2)\cdot 2x = \frac{2x\cos(x^2)}{\sin(x^2)}
$$
:::callout-tip[Test 3 derivative boundary]
Young permits powers, sine, cosine, tangent, exponentials $e^t$, logarithms, and their chain/product/quotient rules. She specifically excluded hard inverse-trig, secant, cosecant, cotangent, hyperbolic, and $a^t$ derivatives on Test 3. Keep those formulas here as background and for other chapters, but prioritize the permitted list for the six written questions.
:::

### Why vector derivatives are just familiar derivatives in a new wrapper

For a vector function $\mathbf r(t)=\langle x(t),y(t),z(t)\rangle$, differentiate **each coordinate** to obtain velocity $\mathbf r'(t)=\langle x'(t),y'(t),z'(t)\rangle$. The derivative changes the components, not the angle brackets. The speed is the scalar $|\mathbf r'(t)|$, found by squaring, adding, and taking a square root. A direction vector is obtained by dividing the entire velocity vector by its speed, provided the speed is nonzero. In Young's Test 3 questions, this separation is essential: writing velocity, speed, and direction as though they are interchangeable loses the distinction that the question is testing.

When you compute a tangent line, the point comes from $\mathbf r(t_0)$ and the direction comes from $\mathbf r'(t_0)$. These use the **same** input time but they are different objects. Introduce a fresh line parameter, say $s$, and write $\mathbf r(t_0)+s\mathbf r'(t_0)$; using $t$ for both the original curve time and the line parameter can obscure your work. For curvature, you will need both $\mathbf r'$ and $\mathbf r''$, so leave enough space to calculate them neatly before taking a cross product.

### Catching chain, product, and quotient mistakes

Underline the outermost operation first. If the expression is a product, write the two product-rule terms before differentiating either; otherwise it is very easy to forget the derivative of one factor. If it is a fraction, write the numerator and denominator as temporary quantities and use the quotient rule in a parenthesized numerator. If it is a nested function, differentiate from the outside inward, retaining a factor for each inner derivative. A useful self-check is to differentiate your answer's *structure* backward: does it contain the expected inner derivative, and is its sign right? For implicit differentiation, every occurrence of a term containing $y$ produces a factor $dy/dx$ by the chain rule. Gather all such factors on one side before dividing. Also verify that a purported point is actually on the given curve before evaluating a slope there.

### Worked examples

:::::example[Example 0.13 — Chain rule with multiple layers]
Differentiate $f(x) = e^{\sqrt{\tan x}}$.

::::answer[Answer]
**Answer:** $f'(x) = \dfrac{\sec^2 x}{2\sqrt{\tan x}}\cdot e^{\sqrt{\tan x}}$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Three layers: exponential wraps a square root wraps a tangent.
3. Work outside-in:

$$
\begin{aligned}
      \frac{d}{dx}\left[e^{\sqrt{\tan x}}\right] &= e^{\sqrt{\tan x}}\cdot\frac{d}{dx}[\sqrt{\tan x}] && \text{(outer: }e^u\text{, derivative is }e^u\cdot u'\text{)}\\
      &= e^{\sqrt{\tan x}}\cdot\frac{1}{2\sqrt{\tan x}}\cdot\frac{d}{dx}[\tan x] && \text{(middle: }\sqrt{u}\text{, derivative is }\frac{u'}{2\sqrt{u}}\text{)}\\
      &= e^{\sqrt{\tan x}}\cdot\frac{1}{2\sqrt{\tan x}}\cdot\sec^2 x && \text{(inner: }\tan x\text{, derivative is }\sec^2 x\text{)}\\
      &= \frac{\sec^2 x\,e^{\sqrt{\tan x}}}{2\sqrt{\tan x}}
    \end{aligned}
$$
4. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::
:::::example[Example 0.14 — Implicit differentiation]
Find $dy/dx$ and the slope of the tangent line at $(3,3)$ for $x^3 + y^3 = 6xy$.

::::answer[Answer]
**Answer:** $\dfrac{dy}{dx} = \dfrac{6y-3x^2}{3y^2-6x}$. At $(3,3)$: slope $= -1$.

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Differentiate both sides with respect to $x$.
3. Every time you differentiate a $y$-term, you must multiply by $dy/dx$ (by the chain rule — $y$ is a function of $x$).
4. The right side $6xy$ requires the product rule:

$$
\frac{d}{dx}[x^3] + \frac{d}{dx}[y^3] = \frac{d}{dx}[6xy]
$$
5. Compute the expression at this stage:

$$
3x^2 + 3y^2\frac{dy}{dx} = 6\!\left(y + x\frac{dy}{dx}\right) = 6y + 6x\frac{dy}{dx}
$$
6. Collect all $dy/dx$ terms on the left:

$$
3y^2\frac{dy}{dx} - 6x\frac{dy}{dx} = 6y - 3x^2
$$
7. Compute the expression at this stage:

$$
\frac{dy}{dx}(3y^2-6x) = 6y-3x^2 \implies \frac{dy}{dx} = \frac{6y-3x^2}{3y^2-6x}
$$
8. Check the point: $3^3+3^3=54$ and $6(3)(3)=54$, so $(3,3)$ lies on the curve.
9. Substitute $(x,y)=(3,3)$: $\dfrac{dy}{dx}=\dfrac{6(3)-3(3)^2}{3(3)^2-6(3)}=\dfrac{18-27}{27-18}=\dfrac{-9}{9}=-1$.
10. The tangent line is $y-3=-(x-3)$, or $y=-x+6$.
11. A tangent at $(1,1)$ would have been invalid because that point is not on the curve.
12. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::
:::::example[Example 0.15 — Logarithmic differentiation]
Differentiate $y = (x^2+1)^{\sin x}$.

::::answer[Answer]
**Answer:** $y' = (x^2+1)^{\sin x}\!\left(\cos x\cdot\ln(x^2+1) + \dfrac{2x\sin x}{x^2+1}\right)$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. The exponent is not a constant (it's $\sin x$), so power rule doesn't apply.
3. And the base is not $e$, so $e^x$-rule doesn't apply.
4. Use logarithmic differentiation.
5. Take $\ln$ of both sides:

$$
\ln y = \sin x \cdot \ln(x^2+1)
$$
6. Differentiate both sides with respect to $x$.
7. Left side: $\frac{1}{y}\frac{dy}{dx}$.
8. Right side: product rule on $\sin x \cdot \ln(x^2+1)$:

$$
\frac{1}{y}\frac{dy}{dx} = \cos x\cdot\ln(x^2+1) + \sin x\cdot\frac{2x}{x^2+1}
$$
9. Multiply both sides by $y = (x^2+1)^{\sin x}$:

$$
\frac{dy}{dx} = (x^2+1)^{\sin x}\!\left(\cos x\ln(x^2+1)+\frac{2x\sin x}{x^2+1}\right)
$$
10. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::
:::::example[Example 0.16 — Higher-order derivatives]
Find $y''$ for $y = x^4 - 3x^2 + 5$. Then find all $x$ where $y'' = 0$ (the inflection points).

::::answer[Answer]
**Answer:** $y'' = 12x^2 - 6$. Inflection points at $x = \pm 1/\sqrt{2}$.

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Differentiate once: $y' = 4x^3 - 6x$.
3. Differentiate again: $y'' = 12x^2 - 6$.
4. Set $y'' = 0$: $12x^2 - 6 = 0 \Rightarrow x^2 = 1/2 \Rightarrow x = \pm 1/\sqrt{2} = \pm\sqrt{2}/2$.
5. Because $12x^2-6$ is positive for $|x|>1/\sqrt2$ and negative for $|x|<1/\sqrt2$, the sign changes at both candidates;
6. these really are inflection $x$-coordinates.
7. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::
:::callout-pitfall[Watch out for]
- **The chain rule's "inside derivative" factor.** $\tfrac{d}{dx}[\sin(3x)] = 3\cos(3x)$, not $\cos(3x)$. The factor of 3 from differentiating the inside is non-negotiable. This is the most frequent mechanical error in Calc 3 derivative problems.
- **Product rule on implicit $xy$ terms.** $\tfrac{d}{dx}[xy] = y + x\tfrac{dy}{dx}$ — two terms, not one. Students who write just $y$ are missing the $x\,dy/dx$ term from the product rule.
- **When to use logarithmic differentiation.** If the variable appears in both the base and the exponent (like $x^x$ or $(x^2+1)^{\sin x}$), regular rules don't apply — you must use log differentiation. If only the base has the variable (like $x^3$) or only the exponent (like $e^x$ or $2^x$), use the standard power/exponential rules.
:::

### Practice problems

:::::problem[Problem 0.22 — Product and chain derivatives]{difficulty=easy}
Differentiate $f(x) = x^3\cos x - e^{2x}$.

::::solution[Solution]
**Answer:** $3x^2\cos x-x^3\sin x-2e^{2x}$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. $f'(x)=3x^2\cos x - x^3\sin x - 2e^{2x}$.
3. (Product rule on the first term; chain rule on $e^{2x}$.)
4. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem 0.23 — Inverse tangent chain derivative]{difficulty=easy}
Find $g'(x)$ for $g(x) = \arctan(e^x)$.

::::solution[Solution]
**Answer:** $e^x/(1+e^{2x})$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Chain rule: $g'(x)=\dfrac{1}{1+(e^x)^2}\cdot e^x = \dfrac{e^x}{1+e^{2x}}$.
4. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem 0.24 — Quotient-rule derivative]{difficulty=standard}
Differentiate $h(x) = \dfrac{x^2+1}{\sqrt{x^3-x}}$ using the quotient rule.

::::solution[Solution]
**Answer:** $(x^4-6x^2+1)/(2(x^3-x)^{3/2})$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Let $f=x^2+1$, $g=(x^3-x)^{1/2}$.
3. $f'=2x$, $g'=\frac{3x^2-1}{2\sqrt{x^3-x}}$.
4. Quotient rule: $h'=\frac{2x\sqrt{x^3-x}-(x^2+1)\frac{3x^2-1}{2\sqrt{x^3-x}}}{x^3-x}=\frac{2x(x^3-x)\cdot 2-(x^2+1)(3x^2-1)}{2(x^3-x)^{3/2}}$.
5. Numerator: $4x^4-4x^2-(3x^4+3x^2-x^2-1)=4x^4-4x^2-3x^4-2x^2+1=x^4-6x^2+1$.
6. So $h'=\frac{x^4-6x^2+1}{2(x^3-x)^{3/2}}$.
7. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem 0.25 — Implicit logarithmic derivative]{difficulty=standard}
Find $dy/dx$ implicitly: $\ln(xy) = x^2 + y^2$.

::::solution[Solution]
**Answer:** $y(2x^2-1)/(x(1-2y^2))$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Differentiate: $\frac{d}{dx}[\ln(xy)]=\frac{y+xy'}{xy}$ (chain rule + product rule).
3. Right side: $2x+2yy'$.
4. So $\frac{y+xy'}{xy}=2x+2yy'$.
5. Multiply by $xy$: $y+xy'=2x^2y+2xy^2y'$.
6. Collect $y'$: $xy'-2xy^2y'=2x^2y-y\Rightarrow y'(x-2xy^2)=y(2x^2-1)\Rightarrow y'=\frac{y(2x^2-1)}{x(1-2y^2)}$.
7. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem 0.26 — Logarithmic differentiation]{difficulty=standard}
Use logarithmic differentiation: $y = \dfrac{x^3\sqrt{1+x^2}}{(2+x)^4}$.

::::solution[Solution]
**Answer:** $\frac{x^3\sqrt{1+x^2}}{(2+x)^4}(\frac3x+\frac{x}{1+x^2}-\frac4{2+x})$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. $\ln y = 3\ln x+\frac{1}{2}\ln(1+x^2)-4\ln(2+x)$.
3. Differentiate: $\frac{y'}{y}=\frac{3}{x}+\frac{x}{1+x^2}-\frac{4}{2+x}$.
4. Multiply by $y$: $y'=\frac{x^3\sqrt{1+x^2}}{(2+x)^4}\!\left(\frac{3}{x}+\frac{x}{1+x^2}-\frac{4}{2+x}\right)$.
5. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem 0.27 — Higher derivatives by pattern]{difficulty=challenge}
Find $f'''(x)$ for $f(x) = x^2 e^x$. Look for a pattern and guess $f^{(n)}(x)$ in general.

::::solution[Solution]
**Answer:** $e^x(x^2+6x+6)$; general $e^x(x^2+2nx+n(n-1))$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. $f'=2xe^x+x^2e^x=e^x(x^2+2x)$.
3. $f''=e^x(x^2+2x)+e^x(2x+2)=e^x(x^2+4x+2)$.
4. $f'''=e^x(x^2+4x+2)+e^x(2x+4)=e^x(x^2+6x+6)$.
5. Pattern: the coefficient of $x^2$ stays 1; the coefficient of $x$ increases by 2 each time;
6. the constant increases by 2 each time (2, 4+2=6...).
7. In general, $f^{(n)}(x)=e^x(x^2+2nx+n(n-1))$ for $n\geq 0$.
8. Check: $n=0$: $e^x\cdot x^2$.
9. ✓ $n=1$: $e^x(x^2+2x)$.
10. ✓
11. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

## 0.5 Integration Techniques

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Integration and the fundamental theorem of calculus” — 3Blue1Brown

“Integration techniques | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition]
Integration is harder than differentiation for one reason: it's a reverse problem. Given an answer (the derivative), find the question (the original function). There's no universal algorithm — you have to *recognize* which pattern you're looking at and apply the right technique. Building this recognition is the goal of this section.

Think of integration techniques as a toolkit with multiple specialized tools. You pick the one that fits the problem in front of you. The challenge — and the skill — is learning to identify which tool fits at a glance. The decision table below is the most useful thing to internalize from this entire chapter.

In MA 2733, these techniques appear in Chapter 2 (the Integral Test requires you to evaluate actual improper integrals), Chapter 1 (polar area integrals involve $\sin^m\cos^n$ integrals), and Chapter 4 (arc-length integrals use a u-substitution after the speed simplifies). There is no warning before they appear — you are expected to handle them.
:::

:::definition[Reference 0.5.1 — Integration Decision Table]
| What you see in the integrand | Technique to reach for |
| --- | --- |
| Composite: $f(g(x))\cdot g'(x)$ | $u$-substitution: $u=g(x)$ |
| Product of algebraic and trig/exp/log | Integration by parts (use LIATE to pick $u$) |
| $\sin^m x\cos^n x$ with odd $m$ or $n$ | Save the odd factor, convert rest with $\sin^2+\cos^2=1$, sub $u=\cos x$ or $u=\sin x$ |
| $\sin^m x\cos^n x$ with both even | Power-reduction identities |
| $\sqrt{a^2-x^2}$ | Trig sub: $x=a\sin\theta$ |
| $\sqrt{a^2+x^2}$ or $a^2+x^2$ in denominator | Trig sub: $x=a\tan\theta$ |
| $\sqrt{x^2-a^2}$ | Trig sub: $x=a\sec\theta$ |
| Rational function $p(x)/q(x)$ | Long divide if deg(top)≥deg(bottom), then partial fractions |
| Upper limit is $\infty$, or integrand blows up at an endpoint | Improper integral — replace with variable, take limit |

**LIATE for integration by parts:** choose $u$ as the first type that appears: *L*ogarithm, *I*nverse trig, *A*lgebraic, *T*rig, *E*xponential. Everything else becomes $dv$.

Formula: $\int u\,dv = uv - \int v\,du$.
:::

:::theorem[Theorem 0.5.2 — Fundamental Theorem of Calculus]
**Part 1 (Differentiation of an integral):** If $F(x)=\int_a^x f(t)\,dt$, then $F'(x)=f(x)$ — provided $f$ is continuous.

**Part 2 (Evaluation of definite integrals):** $\displaystyle\int_a^b f(x)\,dx = F(b)-F(a)$, where $F$ is any antiderivative of $f$. The constant of integration cancels.
:::

:::callout-tip[The two Test 4 integral patterns]
For $\int\frac{6}{x(\ln x)^2}\,dx$, choose $u=\ln x$, $du=dx/x$: $6\int u^{-2}du=-6/u+C=-6/\ln x+C$. When the upper endpoint is infinity, replace it by $b$ **before** evaluating. For $\int\frac{7}{x^2+81}\,dx$, use $\int dx/(x^2+a^2)=\arctan(x/a)/a+C$: result $\frac79\arctan(x/9)+C$. Both occur in Young-style Integral Test arguments; include the positivity and decreasing checks for the corresponding series.
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="Two positive decreasing integrands one beneath the other">
<path class="fig-curve" d="M32.00 99.13 L33.21 100.60 L34.42 102.07 L35.62 103.51 L36.83 104.94 L38.04 106.36 L39.25 107.75 L40.46 109.12 L41.67 110.47 L42.88 111.79 L44.08 113.09 L45.29 114.37 L46.50 115.62 L47.71 116.84 L48.92 118.04 L50.12 119.21 L51.33 120.36 L52.54 121.47 L53.75 122.57 L54.96 123.63 L56.17 124.67 L57.38 125.69 L58.58 126.68 L59.79 127.65 L61.00 128.59 L62.21 129.51 L63.42 130.41 L64.62 131.28 L65.83 132.13 L67.04 132.96 L68.25 133.77 L69.46 134.56 L70.67 135.33 L71.88 136.08 L73.08 136.81 L74.29 137.52 L75.50 138.21 L76.71 138.89 L77.92 139.55 L79.12 140.19 L80.33 140.82 L81.54 141.43 L82.75 142.03 L83.96 142.61 L85.17 143.18 L86.38 143.73 L87.58 144.28 L88.79 144.80 L90.00 145.32 L91.21 145.82 L92.42 146.31 L93.62 146.79 L94.83 147.26 L96.04 147.72 L97.25 148.17 L98.46 148.60 L99.67 149.03 L100.87 149.45 L102.08 149.86 L103.29 150.25 L104.50 150.64 L105.71 151.03 L106.92 151.40 L108.13 151.76 L109.33 152.12 L110.54 152.47 L111.75 152.81 L112.96 153.15 L114.17 153.47 L115.38 153.80 L116.58 154.11 L117.79 154.42 L119.00 154.72 L120.21 155.01 L121.42 155.30 L122.62 155.59 L123.83 155.86 L125.04 156.14 L126.25 156.40 L127.46 156.66 L128.67 156.92 L129.88 157.17 L131.08 157.42 L132.29 157.66 L133.50 157.90 L134.71 158.13 L135.92 158.36 L137.12 158.59 L138.33 158.81 L139.54 159.02 L140.75 159.23 L141.96 159.44 L143.17 159.65 L144.38 159.85 L145.58 160.05 L146.79 160.24 L148.00 160.43 L149.21 160.62 L150.42 160.80 L151.62 160.98 L152.83 161.16 L154.04 161.34 L155.25 161.51 L156.46 161.68 L157.67 161.84 L158.88 162.01 L160.08 162.17 L161.29 162.33 L162.50 162.48 L163.71 162.63 L164.92 162.78 L166.12 162.93 L167.33 163.08 L168.54 163.22 L169.75 163.36 L170.96 163.50 L172.17 163.64 L173.38 163.77 L174.58 163.91 L175.79 164.04 L177.00 164.17 L178.21 164.29 L179.42 164.42 L180.62 164.54 L181.83 164.66 L183.04 164.78 L184.25 164.90 L185.46 165.01 L186.67 165.13 L187.87 165.24 L189.08 165.35 L190.29 165.46 L191.50 165.57 L192.71 165.68 L193.92 165.78 L195.12 165.88 L196.33 165.99 L197.54 166.09 L198.75 166.18 L199.96 166.28 L201.17 166.38 L202.38 166.47 L203.58 166.57 L204.79 166.66 L206.00 166.75 L207.21 166.84 L208.42 166.93 L209.62 167.02 L210.83 167.11 L212.04 167.19 L213.25 167.28 L214.46 167.36 L215.67 167.44 L216.88 167.52 L218.08 167.60 L219.29 167.68 L220.50 167.76 L221.71 167.84 L222.92 167.91 L224.12 167.99 L225.33 168.06 L226.54 168.14 L227.75 168.21 L228.96 168.28 L230.17 168.35 L231.38 168.42 L232.58 168.49 L233.79 168.56 L235.00 168.63 L236.21 168.69 L237.42 168.76 L238.62 168.82 L239.83 168.89 L241.04 168.95 L242.25 169.02 L243.46 169.08 L244.67 169.14 L245.88 169.20 L247.08 169.26 L248.29 169.32 L249.50 169.38 L250.71 169.44 L251.92 169.49 L253.12 169.55 L254.33 169.61 L255.54 169.66 L256.75 169.72 L257.96 169.77 L259.17 169.83 L260.38 169.88 L261.58 169.93 L262.79 169.98 L264.00 170.04 L265.21 170.09 L266.42 170.14 L267.62 170.19 L268.83 170.24 L270.04 170.28 L271.25 170.33 L272.46 170.38 L273.67 170.43 L274.88 170.48 L276.08 170.52 L277.29 170.57 L278.50 170.61 L279.71 170.66 L280.92 170.70 L282.12 170.75 L283.33 170.79 L284.54 170.83 L285.75 170.88 L286.96 170.92 L288.17 170.96 L289.38 171.00 L290.58 171.04 L291.79 171.08 L293.00 171.12 L294.21 171.16 L295.42 171.20 L296.62 171.24 L297.83 171.28 L299.04 171.32 L300.25 171.36 L301.46 171.40 L302.67 171.43 L303.88 171.47 L305.08 171.51 L306.29 171.54 L307.50 171.58 L308.71 171.61 L309.92 171.65 L311.12 171.69 L312.33 171.72 L313.54 171.75 L314.75 171.79 L315.96 171.82 L317.17 171.86 L318.38 171.89 L319.58 171.92 L320.79 171.95 L322.00 171.99"/>
<path class="fig-curve-alt" d="M32.00 66.46 L33.21 70.52 L34.42 74.33 L35.62 77.93 L36.83 81.32 L38.04 84.52 L39.25 87.56 L40.46 90.43 L41.67 93.15 L42.88 95.73 L44.08 98.19 L45.29 100.53 L46.50 102.75 L47.71 104.87 L48.92 106.89 L50.12 108.82 L51.33 110.67 L52.54 112.43 L53.75 114.12 L54.96 115.74 L56.17 117.29 L57.38 118.77 L58.58 120.20 L59.79 121.57 L61.00 122.89 L62.21 124.16 L63.42 125.37 L64.62 126.55 L65.83 127.68 L67.04 128.77 L68.25 129.82 L69.46 130.83 L70.67 131.81 L71.88 132.76 L73.08 133.67 L74.29 134.56 L75.50 135.41 L76.71 136.24 L77.92 137.04 L79.12 137.81 L80.33 138.57 L81.54 139.29 L82.75 140.00 L83.96 140.68 L85.17 141.35 L86.38 141.99 L87.58 142.62 L88.79 143.23 L90.00 143.82 L91.21 144.39 L92.42 144.95 L93.62 145.49 L94.83 146.02 L96.04 146.54 L97.25 147.04 L98.46 147.53 L99.67 148.00 L100.87 148.46 L102.08 148.91 L103.29 149.35 L104.50 149.78 L105.71 150.20 L106.92 150.61 L108.13 151.01 L109.33 151.39 L110.54 151.77 L111.75 152.14 L112.96 152.51 L114.17 152.86 L115.38 153.20 L116.58 153.54 L117.79 153.87 L119.00 154.19 L120.21 154.51 L121.42 154.82 L122.62 155.12 L123.83 155.41 L125.04 155.70 L126.25 155.99 L127.46 156.26 L128.67 156.53 L129.88 156.80 L131.08 157.06 L132.29 157.31 L133.50 157.56 L134.71 157.81 L135.92 158.05 L137.12 158.28 L138.33 158.52 L139.54 158.74 L140.75 158.96 L141.96 159.18 L143.17 159.39 L144.38 159.60 L145.58 159.81 L146.79 160.01 L148.00 160.21 L149.21 160.40 L150.42 160.59 L151.62 160.78 L152.83 160.97 L154.04 161.15 L155.25 161.32 L156.46 161.50 L157.67 161.67 L158.88 161.84 L160.08 162.00 L161.29 162.17 L162.50 162.33 L163.71 162.49 L164.92 162.64 L166.12 162.79 L167.33 162.94 L168.54 163.09 L169.75 163.23 L170.96 163.38 L172.17 163.52 L173.38 163.66 L174.58 163.79 L175.79 163.93 L177.00 164.06 L178.21 164.19 L179.42 164.32 L180.62 164.44 L181.83 164.56 L183.04 164.69 L184.25 164.81 L185.46 164.93 L186.67 165.04 L187.87 165.16 L189.08 165.27 L190.29 165.38 L191.50 165.49 L192.71 165.60 L193.92 165.71 L195.12 165.81 L196.33 165.92 L197.54 166.02 L198.75 166.12 L199.96 166.22 L201.17 166.32 L202.38 166.41 L203.58 166.51 L204.79 166.60 L206.00 166.69 L207.21 166.79 L208.42 166.88 L209.62 166.97 L210.83 167.05 L212.04 167.14 L213.25 167.23 L214.46 167.31 L215.67 167.39 L216.88 167.48 L218.08 167.56 L219.29 167.64 L220.50 167.72 L221.71 167.79 L222.92 167.87 L224.12 167.95 L225.33 168.02 L226.54 168.10 L227.75 168.17 L228.96 168.24 L230.17 168.32 L231.38 168.39 L232.58 168.46 L233.79 168.53 L235.00 168.59 L236.21 168.66 L237.42 168.73 L238.62 168.79 L239.83 168.86 L241.04 168.92 L242.25 168.99 L243.46 169.05 L244.67 169.11 L245.88 169.17 L247.08 169.23 L248.29 169.29 L249.50 169.35 L250.71 169.41 L251.92 169.47 L253.12 169.53 L254.33 169.58 L255.54 169.64 L256.75 169.69 L257.96 169.75 L259.17 169.80 L260.38 169.86 L261.58 169.91 L262.79 169.96 L264.00 170.01 L265.21 170.07 L266.42 170.12 L267.62 170.17 L268.83 170.22 L270.04 170.27 L271.25 170.31 L272.46 170.36 L273.67 170.41 L274.88 170.46 L276.08 170.50 L277.29 170.55 L278.50 170.60 L279.71 170.64 L280.92 170.69 L282.12 170.73 L283.33 170.78 L284.54 170.82 L285.75 170.86 L286.96 170.90 L288.17 170.95 L289.38 170.99 L290.58 171.03 L291.79 171.07 L293.00 171.11 L294.21 171.15 L295.42 171.19 L296.62 171.23 L297.83 171.27 L299.04 171.31 L300.25 171.35 L301.46 171.38 L302.67 171.42 L303.88 171.46 L305.08 171.50 L306.29 171.53 L307.50 171.57 L308.71 171.60 L309.92 171.64 L311.12 171.67 L312.33 171.71 L313.54 171.74 L314.75 171.78 L315.96 171.81 L317.17 171.85 L318.38 171.88 L319.58 171.91 L320.79 171.95 L322.00 171.98"/>
</svg>
<figcaption>For $x\ge1$, $1/\sqrt{x^3+1}\le 1/x^{3/2}$. The area under the smaller graph cannot exceed the finite comparison area.</figcaption>
</figure>

### Integral Test setup: what Young expects on the page

A series such as $\sum_{n=2}^{\infty}6/(n\ln^2 n)$ is not solved merely by writing an antiderivative. Define $f(x)$ to equal the term expression with $x$ in place of $n$. State the interval on which $f$ is continuous and positive. Check that it decreases there, either by showing $f'(x)<0$ or by showing the positive denominator increases. Then write the improper integral **with its limit**, replace the original variable by $u=\ln x$, and change the bounds. At the upper endpoint, $u\to\infty$; at the lower endpoint $x=2$, $u=\ln2$. Finally translate the conclusion back to the original series: the Integral Test says the series and integral share convergence behavior, not that their values are equal.

### Keeping three integration methods separate

A $u$-substitution works when part of the integrand is the derivative of another part. Write the proposed $u$ and compute $du$ on its own line. If the coefficient in $du$ is missing from the integrand, insert it **and compensate** with a constant factor. If the integral is definite, either substitute the bounds into the $u$ integral or return completely to $x$ before using the original bounds; never mix the two variable systems.

For partial fractions, factor the denominator and distinguish repeated linear factors from irreducible quadratics. For integration by parts, identify a factor that becomes simpler when differentiated and a remainder that is easy to integrate. Neither method should be your first choice when a one-line substitution already works. For an improper integral, the obstacle may be an infinite interval or a vertical blow-up at an endpoint. Replace **each** offending endpoint with a limit; if there is a singularity in the middle, split the integral into two one-sided integrals. You cannot let two infinities cancel and call the combined answer finite. Trig substitution and integration by parts remain review techniques here, not Test 3 material.

### Worked examples

:::::example[Example 0.17 — Integration by parts (tabular method)]
Evaluate $\displaystyle\int x^3 e^x\,dx$.

::::answer[Answer]
**Answer:** $e^x(x^3 - 3x^2 + 6x - 6) + C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. This needs IBP three times (differentiating $x^3$ to zero).
3. The **tabular method** organizes repeated IBP efficiently:
4. Set up two columns — differentiate $u=x^3$ repeatedly on the left; integrate $dv=e^x\,dx$ repeatedly on the right.
5. Alternate signs starting with $+$.
6. | Sign | Differentiate $\longrightarrow$ | Integrate $\longleftarrow$ | | --- | --- | --- | | $+$ | $x^3$ | $e^x$ | | $-$ | $3x^2$ | $e^x$ | | $+$ | $6x$ | $e^x$ | | $-$ | $6$ | $e^x$ | | $+$ | $0$ | $e^x$ |
7. Stop when the left column reaches 0.
8. Multiply diagonally (each left entry with the right entry one row below it), applying the sign of the left entry:

$$
\int x^3 e^x\,dx = (+)x^3\cdot e^x + (-)3x^2\cdot e^x + (+)6x\cdot e^x + (-)6\cdot e^x + C
$$
9. Compute the expression at this stage:

$$
= e^x(x^3 - 3x^2 + 6x - 6) + C
$$
10. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::
:::::example[Example 0.18 — Odd trig integral]
Evaluate $\displaystyle\int\sin^3 x\cos^4 x\,dx$.

::::answer[Answer]
**Answer:** $-\dfrac{\cos^5 x}{5} + \dfrac{\cos^7 x}{7} + C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. The power of $\sin x$ is odd (3).
3. Strategy: save one $\sin x$ factor (to pair with $dx$ after substitution), and convert the remaining $\sin^2 x$ using $\sin^2 x = 1-\cos^2 x$:

$$
\int\sin^3 x\cos^4 x\,dx = \int\sin^2 x\cos^4 x\cdot\sin x\,dx = \int(1-\cos^2 x)\cos^4 x\cdot\sin x\,dx
$$
4. Now substitute $u=\cos x$, $du=-\sin x\,dx$:

$$
= \int(1-u^2)u^4\cdot(-du) = -\int(u^4-u^6)\,du = -\frac{u^5}{5}+\frac{u^7}{7}+C
$$
5. Doing that integral carefully: $-\int(u^4-u^6)\,du = -\left[\frac{u^5}{5}-\frac{u^7}{7}\right]+C = -\frac{u^5}{5}+\frac{u^7}{7}+C$.
6. Back-substitute $u=\cos x$: $-\dfrac{\cos^5 x}{5}+\dfrac{\cos^7 x}{7}+C$.
7. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::
:::::example[Example 0.19 — Trig substitution with a full walkthrough]
Evaluate $\displaystyle\int\frac{x^2}{\sqrt{9-x^2}}\,dx$.

::::answer[Answer]
**Answer:** $\dfrac{9}{2}\arcsin\!\left(\dfrac{x}{3}\right) - \dfrac{x\sqrt{9-x^2}}{2} + C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Step 1: Choose the substitution.** The form $\sqrt{a^2-x^2}$ with $a=3$ calls for $x = 3\sin\theta$, so $dx = 3\cos\theta\,d\theta$.
3. Simplify the radical.
4. Compute the expression at this stage:

$$
\sqrt{9-x^2}=\sqrt{9-9\sin^2\theta}=\sqrt{9(1-\sin^2\theta)}=\sqrt{9\cos^2\theta}=3\cos\theta
$$
5. (We take the positive root $3|\cos\theta|=3\cos\theta$ since $\theta\in[-\pi/2,\pi/2]$ makes $\cos\theta\geq 0$.)
6. Substitute everything.
7. Compute the expression at this stage:

$$
\int\frac{9\sin^2\theta}{3\cos\theta}\cdot 3\cos\theta\,d\theta = \int 9\sin^2\theta\,d\theta
$$
8. Apply power-reduction.
9. Compute the expression at this stage:

$$
9\int\sin^2\theta\,d\theta = 9\int\frac{1-\cos 2\theta}{2}\,d\theta = \frac{9}{2}\!\left(\theta - \frac{\sin 2\theta}{2}\right)+C = \frac{9\theta}{2}-\frac{9\sin 2\theta}{4}+C
$$
10. **Step 5: Back-substitute.** Since $x=3\sin\theta$: $\theta=\arcsin(x/3)$.
11. For $\sin 2\theta$: use $\sin 2\theta=2\sin\theta\cos\theta$.
12. We know $\sin\theta=x/3$ and $\cos\theta=\sqrt{9-x^2}/3$.
13. So:

$$
\sin 2\theta = 2\cdot\frac{x}{3}\cdot\frac{\sqrt{9-x^2}}{3} = \frac{2x\sqrt{9-x^2}}{9}
$$
14. Putting it together:

$$
\frac{9}{2}\arcsin\!\left(\frac{x}{3}\right)-\frac{9}{4}\cdot\frac{2x\sqrt{9-x^2}}{9}+C = \frac{9}{2}\arcsin\!\left(\frac{x}{3}\right)-\frac{x\sqrt{9-x^2}}{2}+C
$$
15. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::
:::::example[Example 0.20 — Improper integral: comparison]
Determine whether $\displaystyle\int_1^{\infty}\frac{dx}{\sqrt{x^3+1}}$ converges or diverges.

::::answer[Answer]
**Answer:** Converges (by comparison).

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. This integral can't be evaluated in closed form, but we can determine convergence by comparing to a simpler function.
3. For $x\geq 1$: $x^3+1 > x^3$, so $\sqrt{x^3+1}>\sqrt{x^3}=x^{3/2}$, therefore:

$$
\frac{1}{\sqrt{x^3+1}} < \frac{1}{x^{3/2}}
$$
4. The comparison integral: $\displaystyle\int_1^{\infty}\frac{dx}{x^{3/2}} = \lim_{t\to\infty}\!\left[-\frac{2}{\sqrt{x}}\right]_1^t = \lim_{t\to\infty}\!\left(-\frac{2}{\sqrt{t}}+2\right) = 2$.
5. This converges.
6. Since our integrand is smaller than a convergent function, our integral also converges by the comparison test for improper integrals.
7. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::
:::callout-pitfall[Watch out for]
- **Mixing up the trig substitutions.** $\sqrt{a^2-x^2}\to x=a\sin\theta$. $\sqrt{a^2+x^2}\to x=a\tan\theta$. $\sqrt{x^2-a^2}\to x=a\sec\theta$. The structure of what's under the radical tells you which Pythagorean identity to invoke. Write out which identity each sub exploits.
- **Forgetting to change limits (or back-substitute).** On a definite integral with trig sub, you must either (a) change the limits to $\theta$-values when you substitute, or (b) back-substitute to $x$ before evaluating. Evaluating a $\theta$-expression at $x$-bounds gives garbage.
- **Declaring convergence without evaluating the limit.** $\int_1^\infty x^{-1}\,dx = \lim_{t\to\infty}[\ln t - 0] = \infty$ — the harmonic integral diverges. You must write the limit explicitly and check whether it's finite.
:::

### Practice problems

:::::problem[Problem 0.28 — Exponential substitution]{difficulty=easy}
Evaluate $\displaystyle\int xe^{-x^2}\,dx$.

::::solution[Solution]
**Answer:** $-e^{-x^2}/2+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $u=-x^2$, $du=-2x\,dx$: $\int e^u\frac{du}{-2}=-\frac{1}{2}e^{-x^2}+C$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.29 — Definite logarithmic substitution]{difficulty=easy}
Evaluate $\displaystyle\int_0^1 \frac{x}{x^2+1}\,dx$.

::::solution[Solution]
**Answer:** $\ln2/2$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. $u=x^2+1$, $du=2x\,dx$; limits: $u(0)=1$, $u(1)=2$.
3. $\int_1^2\frac{du}{2u}=\frac{1}{2}[\ln u]_1^2=\frac{\ln 2}{2}$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.30 — Integration by parts]{difficulty=standard}
Evaluate $\displaystyle\int x\sin x\,dx$.

::::solution[Solution]
**Answer:** $-x\cos x+\sin x+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. IBP: $u=x$ (Algebraic), $dv=\sin x\,dx$, $du=dx$, $v=-\cos x$.
3. $\int x\sin x\,dx = -x\cos x+\int\cos x\,dx = -x\cos x+\sin x+C$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.31 — Even trigonometric powers]{difficulty=standard}
Evaluate $\displaystyle\int\cos^4 x\,dx$.

::::solution[Solution]
**Answer:** $3x/8+\sin2x/4+\sin4x/32+C$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. Both powers even. $\cos^4 x=(\cos^2 x)^2=\left(\frac{1+\cos 2x}{2}\right)^2=\frac{1+2\cos 2x+\cos^2 2x}{4}$.
3. Now $\cos^2 2x=\frac{1+\cos 4x}{2}$.
4. So $\cos^4 x=\frac{1}{4}+\frac{\cos 2x}{2}+\frac{1+\cos 4x}{8}=\frac{3}{8}+\frac{\cos 2x}{2}+\frac{\cos 4x}{8}$.
5. Integrate: $\frac{3x}{8}+\frac{\sin 2x}{4}+\frac{\sin 4x}{32}+C$.
6. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

:::::problem[Problem 0.32 — Quadratic inverse-tangent integral]{difficulty=standard}
Evaluate $\displaystyle\int\frac{dx}{x^2+6x+13}$. (*Hint: complete the square first.*)

::::solution[Solution]
**Answer:** $\frac12\arctan((x+3)/2)+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Complete square: $x^2+6x+13=(x+3)^2+4$.
4. Let $u=x+3$: $\int\frac{du}{u^2+4}=\frac{1}{2}\arctan\!\left(\frac{u}{2}\right)+C=\frac{1}{2}\arctan\!\left(\frac{x+3}{2}\right)+C$.
5. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.33 — Improper exponential integral]{difficulty=standard}
Determine whether $\displaystyle\int_0^1\frac{dx}{\sqrt{x}}$ converges. If so, find its value.

::::solution[Solution]
**Answer:** Converges, $2$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Type II improper (integrand blows up at $x=0$).
3. $\lim_{\varepsilon\to 0^+}\int_\varepsilon^1 x^{-1/2}\,dx=\lim_{\varepsilon\to 0^+}[2\sqrt{x}]_\varepsilon^1=\lim_{\varepsilon\to 0^+}(2-2\sqrt{\varepsilon})=2$.
4. **Converges to 2.**
5. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem 0.34 — Rational integration]{difficulty=challenge}
Evaluate $\displaystyle\int\frac{3x+1}{x^2(x+1)}\,dx$.

::::solution[Solution]
**Answer:** $2\ln|x|-1/x-2\ln|x+1|+C$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. PFD: $\frac{3x+1}{x^2(x+1)}=\frac{A}{x}+\frac{B}{x^2}+\frac{C}{x+1}$.
3. Multiply: $3x+1=Ax(x+1)+B(x+1)+Cx^2$.
4. At $x=0$: $1=B$. At $x=-1$: $-2=C$.
5. Match $x^2$: $0=A+C=A-2\Rightarrow A=2$.
6. So $\int\!\left(\frac{2}{x}+\frac{1}{x^2}-\frac{2}{x+1}\right)dx=2\ln|x|-\frac{1}{x}-2\ln|x+1|+C$.
7. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::

:::::problem[Problem 0.35 — Improper rational integral]{difficulty=challenge}
Evaluate $\displaystyle\int_0^{\pi/2}\frac{\sin x}{1+\cos^2 x}\,dx$.

::::solution[Solution]
**Answer:** $\pi/4$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. $u=\cos x$, $du=-\sin x\,dx$; limits: $u(0)=1$, $u(\pi/2)=0$.
3. $-\int_1^0\frac{du}{1+u^2}=\int_0^1\frac{du}{1+u^2}=[\arctan u]_0^1=\frac{\pi}{4}-0=\frac{\pi}{4}$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

## 0.6 Geometric Applications of Integration

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Area between curves | AP Calculus” — Khan Academy
:::

:::callout-intuition[Intuition]
Integration measures accumulation — add up infinitely many thin slices to get a total area, volume, or length. The technique is always the same: identify what a thin slice looks like, write an expression for its contribution, and integrate. The hard part is setting up the integral; the computation is just the techniques from §0.5.

The arc-length formula is particularly important for MA 2733. In Chapter 1, parametric arc length is $\int\sqrt{(dx/dt)^2+(dy/dt)^2}\,dt$ — the same structure with $x(t)$ and $y(t)$ in place of $f(x)$. In Chapter 4, space-curve arc length is $\int|\vec{r}'(t)|\,dt$ — the 3D version of the same idea. Master the 2D version here, and the others are easy extensions.
:::

:::definition[Reference 0.6.1 — Key Formulas]
| Quantity | Formula | Key setup step |
| --- | --- | --- |
| Area between curves | $\int_a^b[f(x)-g(x)]\,dx$, $f\geq g$ | Find intersections; verify which is on top |
| Volume — disk method | $\pi\int_a^b[R(x)]^2\,dx$ | Rotating about $x$-axis; $R$ = outer radius |
| Volume — washer method | $\pi\int_a^b\!\left([R(x)]^2-[r(x)]^2\right)dx$ | $R$ = outer, $r$ = inner radius |
| Volume — shell method | $2\pi\int_a^b x\,f(x)\,dx$ | Rotating about $y$-axis; shells parallel to axis |
| Arc length | $\int_a^b\sqrt{1+[f'(x)]^2}\,dx$ | Compute $f'$, square it, add 1, take root |
| Surface area of revolution | $2\pi\int_a^b f(x)\sqrt{1+[f'(x)]^2}\,dx$ | Arc length integrand times the "radius" $f(x)$ |
:::

Key Idea — Disk vs. Washer vs. Shell

All three methods compute volumes of revolution. Choose based on which axis you're rotating about and which variable is more natural:

- **Rotating about the $x$-axis, function is $y=f(x)$:** disk/washer with $dx$. No algebra needed to rewrite the function.
- **Rotating about the $y$-axis, function is $y=f(x)$:** shells with $dx$ avoid rewriting; disks/washers require solving for $x=g(y)$ first.
- **General rule:** pick the method that avoids re-solving the function for the other variable.

:::callout-tip[Scope]
The arc-length technique directly supports Tests 1 and 3. Washer/shell volumes and surfaces of revolution here are retained prerequisite examples, **not listed on Tests 1–4** in the supplied course notes. Review their setup only if you need to refresh Calc II.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="Area bounded by y=x and y=x squared">
<path class="fig-curve" d="M32.00 178.00 L33.81 177.09 L35.62 176.19 L37.44 175.28 L39.25 174.38 L41.06 173.47 L42.88 172.56 L44.69 171.66 L46.50 170.75 L48.31 169.84 L50.12 168.94 L51.94 168.03 L53.75 167.12 L55.56 166.22 L57.38 165.31 L59.19 164.41 L61.00 163.50 L62.81 162.59 L64.62 161.69 L66.44 160.78 L68.25 159.88 L70.06 158.97 L71.88 158.06 L73.69 157.16 L75.50 156.25 L77.31 155.34 L79.12 154.44 L80.94 153.53 L82.75 152.62 L84.56 151.72 L86.38 150.81 L88.19 149.91 L90.00 149.00 L91.81 148.09 L93.62 147.19 L95.44 146.28 L97.25 145.38 L99.06 144.47 L100.88 143.56 L102.69 142.66 L104.50 141.75 L106.31 140.84 L108.12 139.94 L109.94 139.03 L111.75 138.12 L113.56 137.22 L115.38 136.31 L117.19 135.41 L119.00 134.50 L120.81 133.59 L122.62 132.69 L124.44 131.78 L126.25 130.88 L128.06 129.97 L129.88 129.06 L131.69 128.16 L133.50 127.25 L135.31 126.34 L137.12 125.44 L138.94 124.53 L140.75 123.62 L142.56 122.72 L144.38 121.81 L146.19 120.91 L148.00 120.00 L149.81 119.09 L151.62 118.19 L153.44 117.28 L155.25 116.38 L157.06 115.47 L158.88 114.56 L160.69 113.66 L162.50 112.75 L164.31 111.84 L166.12 110.94 L167.94 110.03 L169.75 109.12 L171.56 108.22 L173.38 107.31 L175.19 106.41 L177.00 105.50 L178.81 104.59 L180.62 103.69 L182.44 102.78 L184.25 101.88 L186.06 100.97 L187.88 100.06 L189.69 99.16 L191.50 98.25 L193.31 97.34 L195.12 96.44 L196.94 95.53 L198.75 94.62 L200.56 93.72 L202.38 92.81 L204.19 91.91 L206.00 91.00 L207.81 90.09 L209.62 89.19 L211.44 88.28 L213.25 87.38 L215.06 86.47 L216.88 85.56 L218.69 84.66 L220.50 83.75 L222.31 82.84 L224.12 81.94 L225.94 81.03 L227.75 80.12 L229.56 79.22 L231.38 78.31 L233.19 77.41 L235.00 76.50 L236.81 75.59 L238.62 74.69 L240.44 73.78 L242.25 72.88 L244.06 71.97 L245.88 71.06 L247.69 70.16 L249.50 69.25 L251.31 68.34 L253.12 67.44 L254.94 66.53 L256.75 65.62 L258.56 64.72 L260.38 63.81 L262.19 62.91 L264.00 62.00 L265.81 61.09 L267.62 60.19 L269.44 59.28 L271.25 58.38 L273.06 57.47 L274.88 56.56 L276.69 55.66 L278.50 54.75 L280.31 53.84 L282.12 52.94 L283.94 52.03 L285.75 51.12 L287.56 50.22 L289.38 49.31 L291.19 48.41 L293.00 47.50 L294.81 46.59 L296.62 45.69 L298.44 44.78 L300.25 43.88 L302.06 42.97 L303.88 42.06 L305.69 41.16 L307.50 40.25 L309.31 39.34 L311.12 38.44 L312.94 37.53 L314.75 36.62 L316.56 35.72 L318.38 34.81 L320.19 33.91 L322.00 33.00"/>
<path class="fig-curve-alt" d="M32.00 178.00 L33.81 177.99 L35.62 177.98 L37.44 177.95 L39.25 177.91 L41.06 177.86 L42.88 177.80 L44.69 177.72 L46.50 177.64 L48.31 177.54 L50.12 177.43 L51.94 177.31 L53.75 177.18 L55.56 177.04 L57.38 176.89 L59.19 176.73 L61.00 176.55 L62.81 176.36 L64.62 176.16 L66.44 175.96 L68.25 175.73 L70.06 175.50 L71.88 175.26 L73.69 175.00 L75.50 174.74 L77.31 174.46 L79.12 174.17 L80.94 173.87 L82.75 173.56 L84.56 173.24 L86.38 172.90 L88.19 172.56 L90.00 172.20 L91.81 171.83 L93.62 171.45 L95.44 171.06 L97.25 170.66 L99.06 170.25 L100.88 169.82 L102.69 169.38 L104.50 168.94 L106.31 168.48 L108.12 168.01 L109.94 167.53 L111.75 167.03 L113.56 166.53 L115.38 166.01 L117.19 165.49 L119.00 164.95 L120.81 164.40 L122.62 163.84 L124.44 163.27 L126.25 162.68 L128.06 162.09 L129.88 161.48 L131.69 160.87 L133.50 160.24 L135.31 159.60 L137.12 158.95 L138.94 158.28 L140.75 157.61 L142.56 156.92 L144.38 156.23 L146.19 155.52 L148.00 154.80 L149.81 154.07 L151.62 153.33 L153.44 152.57 L155.25 151.81 L157.06 151.03 L158.88 150.25 L160.69 149.45 L162.50 148.64 L164.31 147.82 L166.12 146.98 L167.94 146.14 L169.75 145.28 L171.56 144.42 L173.38 143.54 L175.19 142.65 L177.00 141.75 L178.81 140.84 L180.62 139.91 L182.44 138.98 L184.25 138.03 L186.06 137.08 L187.88 136.11 L189.69 135.13 L191.50 134.14 L193.31 133.13 L195.12 132.12 L196.94 131.10 L198.75 130.06 L200.56 129.01 L202.38 127.95 L204.19 126.88 L206.00 125.80 L207.81 124.71 L209.62 123.60 L211.44 122.49 L213.25 121.36 L215.06 120.22 L216.88 119.07 L218.69 117.91 L220.50 116.74 L222.31 115.55 L224.12 114.36 L225.94 113.15 L227.75 111.93 L229.56 110.71 L231.38 109.46 L233.19 108.21 L235.00 106.95 L236.81 105.68 L238.62 104.39 L240.44 103.09 L242.25 101.78 L244.06 100.46 L245.88 99.13 L247.69 97.79 L249.50 96.44 L251.31 95.07 L253.12 93.70 L254.94 92.31 L256.75 90.91 L258.56 89.50 L260.38 88.08 L262.19 86.64 L264.00 85.20 L265.81 83.74 L267.62 82.28 L269.44 80.80 L271.25 79.31 L273.06 77.81 L274.88 76.30 L276.69 74.77 L278.50 73.24 L280.31 71.69 L282.12 70.13 L283.94 68.56 L285.75 66.98 L287.56 65.39 L289.38 63.79 L291.19 62.18 L293.00 60.55 L294.81 58.91 L296.62 57.26 L298.44 55.61 L300.25 53.93 L302.06 52.25 L303.88 50.56 L305.69 48.85 L307.50 47.14 L309.31 45.41 L311.12 43.67 L312.94 41.92 L314.75 40.16 L316.56 38.39 L318.38 36.60 L320.19 34.81 L322.00 33.00"/>
<path class="fig-fill" d="M32.00 178.00 L33.81 177.09 L35.62 176.19 L37.44 175.28 L39.25 174.38 L41.06 173.47 L42.88 172.56 L44.69 171.66 L46.50 170.75 L48.31 169.84 L50.12 168.94 L51.94 168.03 L53.75 167.12 L55.56 166.22 L57.38 165.31 L59.19 164.41 L61.00 163.50 L62.81 162.59 L64.62 161.69 L66.44 160.78 L68.25 159.88 L70.06 158.97 L71.88 158.06 L73.69 157.16 L75.50 156.25 L77.31 155.34 L79.12 154.44 L80.94 153.53 L82.75 152.62 L84.56 151.72 L86.38 150.81 L88.19 149.91 L90.00 149.00 L91.81 148.09 L93.62 147.19 L95.44 146.28 L97.25 145.38 L99.06 144.47 L100.88 143.56 L102.69 142.66 L104.50 141.75 L106.31 140.84 L108.12 139.94 L109.94 139.03 L111.75 138.12 L113.56 137.22 L115.38 136.31 L117.19 135.41 L119.00 134.50 L120.81 133.59 L122.62 132.69 L124.44 131.78 L126.25 130.88 L128.06 129.97 L129.88 129.06 L131.69 128.16 L133.50 127.25 L135.31 126.34 L137.12 125.44 L138.94 124.53 L140.75 123.62 L142.56 122.72 L144.38 121.81 L146.19 120.91 L148.00 120.00 L149.81 119.09 L151.62 118.19 L153.44 117.28 L155.25 116.38 L157.06 115.47 L158.88 114.56 L160.69 113.66 L162.50 112.75 L164.31 111.84 L166.12 110.94 L167.94 110.03 L169.75 109.12 L171.56 108.22 L173.38 107.31 L175.19 106.41 L177.00 105.50 L178.81 104.59 L180.62 103.69 L182.44 102.78 L184.25 101.88 L186.06 100.97 L187.88 100.06 L189.69 99.16 L191.50 98.25 L193.31 97.34 L195.12 96.44 L196.94 95.53 L198.75 94.62 L200.56 93.72 L202.38 92.81 L204.19 91.91 L206.00 91.00 L207.81 90.09 L209.62 89.19 L211.44 88.28 L213.25 87.38 L215.06 86.47 L216.88 85.56 L218.69 84.66 L220.50 83.75 L222.31 82.84 L224.12 81.94 L225.94 81.03 L227.75 80.12 L229.56 79.22 L231.38 78.31 L233.19 77.41 L235.00 76.50 L236.81 75.59 L238.62 74.69 L240.44 73.78 L242.25 72.88 L244.06 71.97 L245.88 71.06 L247.69 70.16 L249.50 69.25 L251.31 68.34 L253.12 67.44 L254.94 66.53 L256.75 65.62 L258.56 64.72 L260.38 63.81 L262.19 62.91 L264.00 62.00 L265.81 61.09 L267.62 60.19 L269.44 59.28 L271.25 58.38 L273.06 57.47 L274.88 56.56 L276.69 55.66 L278.50 54.75 L280.31 53.84 L282.12 52.94 L283.94 52.03 L285.75 51.12 L287.56 50.22 L289.38 49.31 L291.19 48.41 L293.00 47.50 L294.81 46.59 L296.62 45.69 L298.44 44.78 L300.25 43.88 L302.06 42.97 L303.88 42.06 L305.69 41.16 L307.50 40.25 L309.31 39.34 L311.12 38.44 L312.94 37.53 L314.75 36.62 L316.56 35.72 L318.38 34.81 L320.19 33.91 L322.00 33.00 M322.00 33.00 L320.19 34.81 L318.38 36.60 L316.56 38.39 L314.75 40.16 L312.94 41.92 L311.12 43.67 L309.31 45.41 L307.50 47.14 L305.69 48.85 L303.88 50.56 L302.06 52.25 L300.25 53.93 L298.44 55.61 L296.62 57.26 L294.81 58.91 L293.00 60.55 L291.19 62.18 L289.38 63.79 L287.56 65.39 L285.75 66.98 L283.94 68.56 L282.12 70.13 L280.31 71.69 L278.50 73.24 L276.69 74.77 L274.88 76.30 L273.06 77.81 L271.25 79.31 L269.44 80.80 L267.62 82.28 L265.81 83.74 L264.00 85.20 L262.19 86.64 L260.38 88.08 L258.56 89.50 L256.75 90.91 L254.94 92.31 L253.12 93.70 L251.31 95.07 L249.50 96.44 L247.69 97.79 L245.88 99.13 L244.06 100.46 L242.25 101.78 L240.44 103.09 L238.62 104.39 L236.81 105.68 L235.00 106.95 L233.19 108.21 L231.38 109.46 L229.56 110.71 L227.75 111.93 L225.94 113.15 L224.12 114.36 L222.31 115.55 L220.50 116.74 L218.69 117.91 L216.88 119.07 L215.06 120.22 L213.25 121.36 L211.44 122.49 L209.62 123.60 L207.81 124.71 L206.00 125.80 L204.19 126.88 L202.38 127.95 L200.56 129.01 L198.75 130.06 L196.94 131.10 L195.12 132.12 L193.31 133.13 L191.50 134.14 L189.69 135.13 L187.88 136.11 L186.06 137.08 L184.25 138.03 L182.44 138.98 L180.62 139.91 L178.81 140.84 L177.00 141.75 L175.19 142.65 L173.38 143.54 L171.56 144.42 L169.75 145.28 L167.94 146.14 L166.12 146.98 L164.31 147.82 L162.50 148.64 L160.69 149.45 L158.88 150.25 L157.06 151.03 L155.25 151.81 L153.44 152.57 L151.62 153.33 L149.81 154.07 L148.00 154.80 L146.19 155.52 L144.38 156.23 L142.56 156.92 L140.75 157.61 L138.94 158.28 L137.12 158.95 L135.31 159.60 L133.50 160.24 L131.69 160.87 L129.88 161.48 L128.06 162.09 L126.25 162.68 L124.44 163.27 L122.62 163.84 L120.81 164.40 L119.00 164.95 L117.19 165.49 L115.38 166.01 L113.56 166.53 L111.75 167.03 L109.94 167.53 L108.12 168.01 L106.31 168.48 L104.50 168.94 L102.69 169.38 L100.88 169.82 L99.06 170.25 L97.25 170.66 L95.44 171.06 L93.62 171.45 L91.81 171.83 L90.00 172.20 L88.19 172.56 L86.38 172.90 L84.56 173.24 L82.75 173.56 L80.94 173.87 L79.12 174.17 L77.31 174.46 L75.50 174.74 L73.69 175.00 L71.87 175.26 L70.06 175.50 L68.25 175.73 L66.44 175.96 L64.63 176.16 L62.81 176.36 L61.00 176.55 L59.19 176.73 L57.38 176.89 L55.56 177.04 L53.75 177.18 L51.94 177.31 L50.12 177.43 L48.31 177.54 L46.50 177.64 L44.69 177.72 L42.87 177.80 L41.06 177.86 L39.25 177.91 L37.44 177.95 L35.62 177.98 L33.81 177.99 L32.00 178.00 Z"/>
</svg>
<figcaption>On $0\le x\le1$, $x$ is above $x^2$, so the area is $\int_0^1(x-x^2)\,dx=1/6$; reversing the order would give negative signed area.</figcaption>
</figure>

### What an area or length formula is actually measuring

The most important choice in a geometry integral is the quantity being accumulated. For area between ordinary graphs, a thin vertical slice has height top minus bottom, so its area is $(y_{\rm top}-y_{\rm bottom})\,dx$. A horizontal slice instead uses right minus left and integrates with respect to $y$. For polar area, the pieces are narrow **sectors**, which is why the factor $\tfrac12r^2$ appears. If a formula gives a negative area, do not accept the sign: the order of the bounding curves or the orientation of the parameter interval is wrong for the intended physical quantity.

Arc length is different. Each tiny piece of a planar graph is a slanted displacement, and the Pythagorean theorem makes its size $\sqrt{(dx)^2+(dy)^2}$. For a parametric curve, dividing by a tiny parameter change gives the speed $\sqrt{(x')^2+(y')^2}$; in three dimensions there is one more squared component. This is the direct bridge from Chapter 1 arc length to the vector-valued arc length in Young's Test 3. It is worth writing the intermediate speed calculation before integrating, because a common problem deliberately makes the square root collapse only after collecting like terms.

### Choosing bounds before writing an integral

To find intersections, set the two candidate boundary equations equal and solve **before** choosing a formula. Mark any interval on which the ordering of the two curves reverses. A single signed integral across a crossing may subtract areas and produce a misleading result; split at each crossing and use nonnegative differences on each subinterval. For solids, a washer has an outer radius and inner radius squared, whereas a shell has radius times height times thickness. Both represent volume, but they slice the solid in perpendicular directions. Decide which orientation avoids an inverse function or extra case split. These methods are prerequisite review, not the nine Test 3 topics listed by Young.

### Worked examples

:::::example[Example 0.21 — Arc length]
Find the arc length of $y = \dfrac{x^{3/2}}{3} - x^{1/2}$ from $x=1$ to $x=4$.

::::answer[Answer]
**Answer:** $10/3$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Find $y'$: $y' = \dfrac{1}{2}x^{1/2} - \dfrac{1}{2}x^{-1/2} = \dfrac{\sqrt{x}-1/\sqrt{x}}{2} = \dfrac{x-1}{2\sqrt{x}}$.
3. Compute $1+(y')^2$ and look for a perfect square (this is what makes arc-length problems tractable):

$$
(y')^2 = \frac{(x-1)^2}{4x} \implies 1+(y')^2 = 1+\frac{(x-1)^2}{4x} = \frac{4x+(x-1)^2}{4x} = \frac{x^2+2x+1}{4x} = \frac{(x+1)^2}{4x}
$$
4. The expression under the root is a perfect square:

$$
\sqrt{1+(y')^2} = \sqrt{\frac{(x+1)^2}{4x}} = \frac{x+1}{2\sqrt{x}}
$$
5. Now integrate:

$$
L = \int_1^4\frac{x+1}{2\sqrt{x}}\,dx = \frac{1}{2}\int_1^4(x^{1/2}+x^{-1/2})\,dx = \frac{1}{2}\left[\frac{2x^{3/2}}{3}+2x^{1/2}\right]_1^4
$$
6. Compute the expression at this stage:

$$
= \frac{1}{2}\!\left[\!\left(\frac{2\cdot 8}{3}+2\cdot 2\right)-\left(\frac{2}{3}+2\right)\right] = \frac{1}{2}\!\left[\left(\frac{16}{3}+4\right)-\frac{8}{3}\right] = \frac{1}{2}\left[\frac{8}{3}+4\right] = \frac{1}{2}\cdot\frac{20}{3} = \frac{10}{3}
$$
7. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::
:::::example[Example 0.22 — Washer method]
Find the volume of the solid formed by rotating the region bounded by $y=x^2$ and $y=x$ about the $x$-axis.

::::answer[Answer]
**Answer:** $2\pi/15$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. **Step 1: Find the intersection points.** $x^2=x\Rightarrow x(x-1)=0\Rightarrow x=0,1$.
3. **Step 2: Determine which is on top.** On $[0,1]$: test $x=1/2$.
4. $y=1/2 > y=1/4$. So $y=x$ is above $y=x^2$.
5. Rotating about the $x$-axis: outer radius $R=x$, inner radius $r=x^2$.
6. Set up and evaluate.
7. Compute the expression at this stage:

$$
V = \pi\int_0^1\!\left(x^2-(x^2)^2\right)dx = \pi\int_0^1(x^2-x^4)\,dx = \pi\left[\frac{x^3}{3}-\frac{x^5}{5}\right]_0^1 = \pi\!\left(\frac{1}{3}-\frac{1}{5}\right) = \frac{2\pi}{15}
$$
8. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::
:::::example[Example 0.23 — Shell method]
The same region from Example 0.22 — rotate it about the $y$-axis. Use the shell method.

::::answer[Answer]
**Answer:** $\pi/6$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Shells: the shell at position $x$ has radius $x$, height $x - x^2$ (top minus bottom), and thickness $dx$:

$$
V = 2\pi\int_0^1 x(x-x^2)\,dx = 2\pi\int_0^1(x^2-x^3)\,dx = 2\pi\left[\frac{x^3}{3}-\frac{x^4}{4}\right]_0^1 = 2\pi\!\left(\frac{1}{3}-\frac{1}{4}\right) = 2\pi\cdot\frac{1}{12} = \frac{\pi}{6}
$$
3. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::
:::::example[Example 0.24 — Area between curves with a sign check]
Find the area enclosed between $y=\sin x$ and $y=\cos x$ on $[0, 3\pi/2]$.

::::answer[Answer]
**Answer:** $4\sqrt{2}-2$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. The curves cross where $\sin x=\cos x$, i.e. $\tan x=1$, giving $x=\pi/4$ and $x=5\pi/4$ on this interval.
3. The sign of $\sin x - \cos x$ changes at each crossing.
4. Check each subinterval:
5. $[0,\pi/4]$: at $x=0$, $\sin 0=0 < \cos 0=1$.
6. So $\cos x\geq\sin x$: integrate $\cos x-\sin x$.
7. $[\pi/4, 5\pi/4]$: at $x=\pi/2$, $\sin(\pi/2)=1 > \cos(\pi/2)=0$.
8. So $\sin x\geq\cos x$: integrate $\sin x-\cos x$.
9. $[5\pi/4, 3\pi/2]$: at $x=4\pi/3$, check: $\sin(4\pi/3)=-\sqrt{3}/2$, $\cos(4\pi/3)=-1/2$.
10. $-1/2>-\sqrt{3}/2$, so $\cos x\geq\sin x$: integrate $\cos x-\sin x$.
11. Compute the expression at this stage:

$$
A=\int_0^{\pi/4}(\cos x-\sin x)\,dx+\int_{\pi/4}^{5\pi/4}(\sin x-\cos x)\,dx+\int_{5\pi/4}^{3\pi/2}(\cos x-\sin x)\,dx
$$
12. Each integral: $\int(\cos x-\sin x)\,dx = \sin x+\cos x$.
13. $\int(\sin x-\cos x)\,dx=-\cos x-\sin x$.
14. Compute the expression at this stage:

$$
A=[\sin x+\cos x]_0^{\pi/4}+[-\cos x-\sin x]_{\pi/4}^{5\pi/4}+[\sin x+\cos x]_{5\pi/4}^{3\pi/2}
$$
15. Compute the expression at this stage:

$$
=(\sqrt{2}-1)+({\sqrt{2}}+{\sqrt{2}})+((-1-0)-(-\sqrt{2})) = (\sqrt{2}-1)+2\sqrt{2}+(\sqrt{2}-1)=4\sqrt{2}-2
$$
16. *Note: numerical check — $4\sqrt{2}-2\approx3.66$.
17. This matches what you'd get by computing the three pieces separately and adding their absolute values.*
18. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::
:::::example[Example 0.25 — Arc length bridge to Young's vector-functions test]
A motion has velocity $\mathbf v(t)=\langle3t^2\cos(t^3),3t^2\sin(t^3),0\rangle$. Find the distance traveled from $t=0$ to $t=2$.

::::answer[Answer]
**Answer:** $8$.

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. For a vector position $\mathbf r(t)$, arc length is the integral of the **speed**, not the magnitude of the position.
3. Compute speed from velocity:

$$
|\mathbf v(t)|=\sqrt{9t^4\cos^2(t^3)+9t^4\sin^2(t^3)+0}
=\sqrt{9t^4\,[\cos^2(t^3)+\sin^2(t^3)]}.
$$
4. The identity $\cos^2u+\sin^2u=1$ gives $\sqrt{9t^4}=3t^2$ for $t\ge0$.
5. Now integrate:
$$L=\int_0^2 3t^2\,dt=[t^3]_0^2=2^3-0^3=8.$$
6. This is exactly the simplification Young said to expect on Test 3.
7. If you had first tried integrating the two trig components, you would have made the question harder for no reason.
8. It is the velocity **magnitude** that matters for arc length.
9. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::
:::callout-pitfall[Watch out for]
- **Not checking which function is on top.** Always test a point inside each sub-interval. If you integrate $f-g$ when $g>f$ on that interval, you get a negative area — and the total may cancel out rather than add up.
- **Arc-length integrals rarely simplify.** The expression $\sqrt{1+(y')^2}$ is almost never a "nice" function. Some classroom problems are engineered so it simplifies to a perfect square — look for that pattern. If you don't get a perfect square, double-check your $y'$ computation before proceeding.
:::

### Practice problems

:::::problem[Problem 0.36 — Area between parabolas]{difficulty=easy}
Find the area enclosed between $y=x$ and $y=x^2$ on $[0,1]$.

::::solution[Solution]
**Answer:** $1/6$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. On $[0,1]$: $x\geq x^2$.
4. $\int_0^1(x-x^2)\,dx=[x^2/2-x^3/3]_0^1=1/2-1/3=1/6$.
5. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

:::::problem[Problem 0.37 — Exponential disk volume]{difficulty=standard}
Find the volume when $y=e^x$ on $[0,2]$ is rotated about the $x$-axis.

::::solution[Solution]
**Answer:** $\pi(e^4-1)/2$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Disk: $V=\pi\int_0^2 e^{2x}\,dx=\pi\left[\frac{e^{2x}}{2}\right]_0^2=\frac{\pi(e^4-1)}{2}$.
4. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

:::::problem[Problem 0.38 — Arc length by a perfect square]{difficulty=standard}
Find the arc length of $y = \dfrac{x^2}{2} - \dfrac{\ln x}{4}$ from $x=1$ to $x=e$.

::::solution[Solution]
**Answer:** $(e^2-1)/2+1/4$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $y'=x-\frac{1}{4x}$. $1+(y')^2=1+x^2-\frac{1}{2}+\frac{1}{16x^2}=x^2+\frac{1}{2}+\frac{1}{16x^2}=\left(x+\frac{1}{4x}\right)^2$.
4. So $\sqrt{1+(y')^2}=x+\frac{1}{4x}$.
5. $L=\int_1^e\left(x+\frac{1}{4x}\right)dx=\left[\frac{x^2}{2}+\frac{\ln x}{4}\right]_1^e=\frac{e^2-1}{2}+\frac{1}{4}$.
6. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

:::::problem[Problem 0.39 — Shell volume for a square-root curve]{difficulty=standard}
The region bounded by $y=\sqrt{x}$, the $x$-axis, and $x=4$ is rotated about the $y$-axis. Use the shell method to find the volume.

::::solution[Solution]
**Answer:** $128\pi/5$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Shells: $V=2\pi\int_0^4 x\cdot\sqrt{x}\,dx=2\pi\int_0^4 x^{3/2}\,dx=2\pi\left[\frac{2x^{5/2}}{5}\right]_0^4=2\pi\cdot\frac{2\cdot32}{5}=\frac{128\pi}{5}$.
4. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

:::::problem[Problem 0.40 — Surface area of a sphere]{difficulty=challenge}
Find the surface area of the solid formed by rotating $y=\sqrt{4-x^2}$ (a semicircle of radius 2) about the $x$-axis. What geometric object is this, and does your answer match the known formula?

::::solution[Solution]
**Answer:** $16\pi$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. $y'=\frac{-x}{\sqrt{4-x^2}}$.
3. $1+(y')^2=1+\frac{x^2}{4-x^2}=\frac{4}{4-x^2}$.
4. $\sqrt{1+(y')^2}=\frac{2}{\sqrt{4-x^2}}$.
5. $SA=2\pi\int_{-2}^{2}\sqrt{4-x^2}\cdot\frac{2}{\sqrt{4-x^2}}\,dx=2\pi\int_{-2}^{2}2\,dx=4\pi\cdot4=16\pi$.
6. This is a sphere of radius 2.
7. Known formula: $4\pi r^2=4\pi(4)=16\pi$.
8. ✓
9. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

## 0.7 Sequences and Series Warm-Up

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Sequences | AP Calculus BC” — Khan Academy
:::

:::callout-intuition[Intuition]
A **sequence** is an ordered list of numbers: $a_1, a_2, a_3, \ldots$ Think of it as a function whose domain is the positive integers — $a_n = f(n)$. A **series** is what you get when you try to *add up* all the terms of a sequence: $\sum_{n=1}^\infty a_n = a_1 + a_2 + a_3 + \cdots$ The central question about both is convergence: does the sequence settle to a definite value? Does the sum reach a finite total?

Chapter 2 of this book is an intensive investigation of these questions, covering the assigned convergence tests. Everything in Chapter 2 assumes you can compute limits of sequences fluently (§0.3's hierarchy and L'Hôpital apply here directly) and that you understand sigma notation and the geometric series formula. This section builds that vocabulary.

One crucial distinction: *a sequence can converge even if the corresponding series diverges*. The sequence $\{1/n\}$ converges to 0, but the series $\sum 1/n$ diverges. Confusing these two is one of the most common conceptual errors in Chapter 2.
:::

:::definition[Reference 0.7.1 — Sequences: Convergence and Key Tools]
$\{a_n\}$ converges to $L$ if $\lim_{n\to\infty}a_n = L$ (finite). Otherwise it diverges.

**Continuous function theorem for sequences:** If $f$ is continuous and $f(n)=a_n$, then $\lim_{n\to\infty}a_n = \lim_{x\to\infty}f(x)$. This lets you apply L'Hôpital to sequences.

**Squeeze Theorem:** If $b_n\leq a_n\leq c_n$ for all large $n$ and $b_n,c_n\to L$, then $a_n\to L$.

**Monotone Convergence Theorem:** If $\{a_n\}$ is monotonically increasing and bounded above, it converges. Similarly for decreasing and bounded below. Useful when you can't find the limit explicitly.
:::

:::definition[Reference 0.7.2 — Series: Key Families]
**Geometric series:** $\displaystyle\sum_{n=0}^{\infty}ar^n = \frac{a}{1-r}$ if and only if $|r|<1$. If $|r|\geq 1$, the series diverges.

**Telescoping series:** write out partial sums and watch for cancellation. If $a_n = b_n - b_{n+1}$, then $\sum_{n=1}^N a_n = b_1 - b_{N+1}\to b_1 - \lim b_n$ if the limit exists.

**$p$-series:** $\displaystyle\sum_{n=1}^{\infty}\frac{1}{n^p}$ converges iff $p>1$. (Preview of Chapter 2 — but the result is simple enough to state now.)

**Test for divergence:** if $\lim_{n\to\infty}a_n\neq 0$, then $\sum a_n$ diverges. If the terms don't approach zero, there's no hope of a finite sum. However, $a_n\to 0$ does NOT guarantee convergence ($\sum 1/n$ is the famous counterexample).
:::

:::callout-tip[Factorials and recursive terms for Test 4]
$0!=1$, $1!=1$, $(n+1)!=(n+1)n!$. Therefore $\frac{(n+1)!}{n!}=n+1$, not $1$. The first three terms of $a_1=2,\ a_{n+1}=3a_n-1$ are $2,5,14$ because $a_2=3(2)-1=5$ and $a_3=3(5)-1=14$. To spot a formula from $3,6,12,24,\ldots$, check the constant ratio $2$ and write $a_n=3\cdot2^{n-1}$. A pattern needs a stated indexing convention, not just a guess.
:::

### From a pattern to a defensible nth-term formula

A finite list of numbers can fit many formulas, so an nth-term question assumes you are identifying the intended simple pattern, not proving uniqueness from a few terms. Check successive differences first. Constant differences suggest an arithmetic rule. Constant nonzero ratios suggest a geometric rule. Alternating signs may be represented by $(-1)^n$ or $(-1)^{n-1}$, and the exponent depends on whether your first listed index is $0$ or $1$. Before presenting the formula, substitute the first two indices back into it. This indexing check catches many otherwise correct-looking series answers.

Recursion is a different kind of description: a starting value and an update rule determine each later term. Compute recursive terms in order. Do not attempt to replace an update such as $a_{n+1}=2a_n+1$ with a geometric-series formula until you have accounted for the added constant. If you do spot a closed form, verify both its first term and its recurrence. On Test 4, these are quick questions if you keep your bookkeeping organized.

### Why a term approaching zero cannot settle convergence

For a series, the limit of the **terms** answers a necessary-condition question. The limit of the **partial sums** answers the real convergence question. If $S_N=\sum_{n=1}^N a_n$, the series converges exactly when $S_N$ tends to a finite number as $N$ increases. The nth-term divergence test is powerful only when $a_n$ fails to approach zero. When $a_n\to0$, infinitely many tiny contributions might still accumulate without bound. At that point use a geometric-series recognition, a $p$-series, or a proved comparison rather than claiming success from the term limit. Factorials in the Ratio Test should be canceled before taking any limit: write $(n+1)!=(n+1)n!$ explicitly and cancel $n!$; the remaining factor is what matters. Telescoping is useful background for recognizing cancellation, but Young did not include it in the supplied Test 4 scope.

### Worked examples

:::::example[Example 0.26 — Limit of a sequence using L'Hôpital]
Find $\displaystyle\lim_{n\to\infty}\frac{n^2}{e^n}$.

::::answer[Answer]
**Answer:** $0$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Replace $n$ by $x$ and apply the continuous function theorem.
3. Form is $\infty/\infty$.
4. L'Hôpital once:

$$
\lim_{x\to\infty}\frac{x^2}{e^x}\overset{\text{L'H}}{=}\lim_{x\to\infty}\frac{2x}{e^x}
$$
5. Still $\infty/\infty$.
6. L'Hôpital again:

$$
\overset{\text{L'H}}{=}\lim_{x\to\infty}\frac{2}{e^x} = 0
$$
7. Exponentials dominate polynomials — the growth hierarchy tells you this immediately.
8. L'Hôpital just makes it rigorous.
9. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::::example[Example 0.27 — Geometric series application]
Express the repeating decimal $0.\overline{142857}$ as a fraction.

::::answer[Answer]
**Answer:** $1/7$

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. The repeating block "142857" has 6 digits, so:

$$
0.\overline{142857} = \frac{142857}{10^6} + \frac{142857}{10^{12}} + \frac{142857}{10^{18}} + \cdots = \sum_{n=1}^{\infty}\frac{142857}{10^{6n}}
$$
3. This is a geometric series with $a = 142857/10^6$ and $r = 1/10^6$:

$$
= \frac{142857/10^6}{1-1/10^6} = \frac{142857}{10^6-1} = \frac{142857}{999999} = \frac{1}{7}
$$
4. (You can verify: $1\div 7 = 0.\overline{142857}$.)
5. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::
:::::example[Example 0.28 — Telescoping series]
Find $\displaystyle\sum_{n=1}^{\infty}\frac{1}{n(n+2)}$.

::::answer[Answer]
**Answer:** $3/4$

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. Partial fractions first: $\dfrac{1}{n(n+2)} = \dfrac{1}{2}\!\left(\dfrac{1}{n}-\dfrac{1}{n+2}\right)$.
3. Now write out partial sums — a "skip-one" telescoping pattern:

$$
S_N = \frac{1}{2}\sum_{n=1}^{N}\!\left(\frac{1}{n}-\frac{1}{n+2}\right)
$$
4. Write out the first several terms and see what cancels:

$$
\frac{1}{2}\!\left[\!\left(\frac{1}{1}-\frac{1}{3}\right)+\left(\frac{1}{2}-\frac{1}{4}\right)+\left(\frac{1}{3}-\frac{1}{5}\right)+\left(\frac{1}{4}-\frac{1}{6}\right)+\cdots\right]
$$
5. Terms $1/3, 1/4, 1/5, \ldots$ all eventually cancel.
6. What survives in $S_N$:

$$
S_N = \frac{1}{2}\!\left(1+\frac{1}{2}-\frac{1}{N+1}-\frac{1}{N+2}\right)
$$
7. As $N\to\infty$: $S = \dfrac{1}{2}\left(1+\dfrac{1}{2}\right) = \dfrac{1}{2}\cdot\dfrac{3}{2} = \dfrac{3}{4}$.
8. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::
:::::example[Example 0.29 — Proving convergence without finding the limit]
The sequence defined by $a_1 = 1$, $a_{n+1} = \sqrt{2 + a_n}$ is increasing and bounded above by 2. Prove it converges, then find the limit.

::::answer[Answer]
**Answer:** Converges to $L=2$.

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. **Convergence (Monotone Convergence Theorem):** The sequence is bounded above: $a_1=1<2$, and if $a_n<2$ then $a_{n+1}=\sqrt{2+a_n}<2$.
3. It is also increasing: $a_2=\sqrt3>1=a_1$; if $a_n>a_{n-1}$ then $\sqrt{2+a_n}>\sqrt{2+a_{n-1}}$, so $a_{n+1}>a_n$.
4. Thus both hypotheses of monotone convergence hold.
5. By the MCT, it converges to some limit $L$.
6. **Finding $L$:** Taking the limit of both sides of $a_{n+1}=\sqrt{2+a_n}$ as $n\to\infty$, and using continuity of $\sqrt{\cdot}$:

$$
L = \sqrt{2+L} \implies L^2 = 2+L \implies L^2-L-2=0 \implies (L-2)(L+1)=0
$$
7. So $L=2$ or $L=-1$. Since all terms are positive, $L=-1$ is impossible.
8. Therefore $L=2$.
9. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::::example[Example 0.30 — Recursive terms and the nth term]
Given $a_1=3$ and $a_{n+1}=2a_n+1$, find the first four terms and a formula for $a_n$.

::::answer[Answer]
**Answer:** $3,7,15,31$ and $a_n=2^{n+1}-1$.

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. Start with the supplied first term.
3. Each next term comes from the **previous** one:
$$a_2=2(3)+1=7,\quad a_3=2(7)+1=15,\quad a_4=2(15)+1=31.$$
4. Now look one step past the visible numbers: $a_n+1$ equals $4,8,16,32$, which doubles each time.
5. Since $a_1+1=4=2^2$, we conjecture $a_n+1=2^{n+1}$, so $a_n=2^{n+1}-1$.
6. Verify rather than relying on a pattern.
7. For $n=1$, $2^2-1=3$. If $a_n=2^{n+1}-1$, then
$$a_{n+1}=2a_n+1=2(2^{n+1}-1)+1=2^{n+2}-1,$$
8. which is the claimed formula with $n$ replaced by $n+1$.
9. The formula is therefore valid by induction.
10. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::
:::::example[Example 0.31 — Test 4 logarithmic sequence limit]
Evaluate $\displaystyle\lim_{n\to\infty}\frac{\ln(n+6)}{n}$.

::::answer[Answer]
**Answer:** $0$.

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Treat $n$ as a positive real variable $x$, because the sequence is sampled from $f(x)=\ln(x+6)/x$.
3. The form is $\infty/\infty$, so L'Hôpital is available:

$$
\lim_{x\to\infty}\frac{\ln(x+6)}{x}
=\lim_{x\to\infty}\frac{1/(x+6)}{1}
=\lim_{x\to\infty}\frac{1}{x+6}=0.
$$
4. The limit of a **sequence** is zero here.
5. This does *not* by itself prove convergence of the **series** $\sum \ln(n+6)/n$.
6. A series demands its own convergence test.
7. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::
:::callout-pitfall[Watch out for]
- **Sequence vs. series convergence.** $\lim_{n\to\infty}a_n=0$ is necessary but not sufficient for $\sum a_n$ to converge. $\sum 1/n$ diverges even though $1/n\to 0$. The Divergence Test only says: if $a_n\not\to 0$, the series diverges — not the converse.
- **Geometric series requires the sum to start at $n=0$ (or adjusting $a$).** $\sum_{n=1}^{\infty}r^n = \frac{r}{1-r}$, not $\frac{1}{1-r}$. Double-check what the first term is and adjust the formula $a/(1-r)$ accordingly.
:::

### Practice problems

:::::problem[Problem 0.41 — Rational sequence limit]{difficulty=easy}
Determine whether $a_n = \dfrac{5n^3-3n}{2n^3+n^2}$ converges. If so, find the limit.

::::solution[Solution]
**Answer:** Converges to $5/2$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Divide by $n^3$: $\dfrac{5-3/n^2}{2+1/n}\to\dfrac{5}{2}$.
4. Converges to $5/2$.
5. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.42 — Sum of geometric series]{difficulty=easy}
Find the sum: $\displaystyle\sum_{n=0}^{\infty}\left(\frac{2}{3}\right)^n + \sum_{n=0}^{\infty}\left(-\frac{1}{4}\right)^n$.

::::solution[Solution]
**Answer:** $19/5$

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. First: $a=1, r=2/3$: sum $=\frac{1}{1-2/3}=3$.
3. Second: $a=1,r=-1/4$: sum $=\frac{1}{1+1/4}=\frac{4}{5}$.
4. Total: $3+4/5=19/5$.
5. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::

:::::problem[Problem 0.43 — Limit of nth roots]{difficulty=standard}
Find $\displaystyle\lim_{n\to\infty}n^{1/n}$. (*Take $\ln$ and use L'Hôpital.*)

::::solution[Solution]
**Answer:** $1$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Let $L=\lim n^{1/n}$. Then $\ln L=\lim_{n\to\infty}\frac{\ln n}{n}\overset{\text{L'H}}{=}\lim_{x\to\infty}\frac{1/x}{1}=0$.
3. So $L=e^0=1$.
4. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem 0.44 — Telescoping logarithms]{difficulty=standard}
Find $\displaystyle\sum_{n=1}^{\infty}\ln\!\left(\frac{n+1}{n}\right)$. Does it converge?

::::solution[Solution]
**Answer:** Diverges ($S_N=\ln(N+1)\to\infty$)

1. Use the defining algebraic identity and preserve the original signs and denominators through every simplification.
2. Telescoping: $\ln\frac{n+1}{n}=\ln(n+1)-\ln n$.
3. Partial sum: $S_N=\ln(N+1)-\ln 1=\ln(N+1)\to\infty$.
4. The series **diverges**.
5. (Makes sense: the terms are $\ln(1+1/n)\approx 1/n$ for large $n$, similar to the harmonic series.)
6. Check: expand or substitute the result into the starting identity to confirm equal values.
::::
:::::

:::::problem[Problem 0.45 — Repeating decimal as a fraction]{difficulty=challenge}
Write $1.2\overline{45} = 1.24545\ldots$ as a fraction.

::::solution[Solution]
**Answer:** $137/110$

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. Split: $1.2\overline{45} = 1.2 + 0.0\overline{45}$.
3. The repeating part: $0.0\overline{45}=0.045+0.00045+\cdots = \frac{45/1000}{1-1/100}=\frac{45}{1000}\cdot\frac{100}{99}=\frac{45}{990}=\frac{1}{22}$.
4. So $1.2\overline{45}=\frac{6}{5}+\frac{1}{22}=\frac{132}{110}+\frac{5}{110}=\frac{137}{110}$.
5. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::

## 0.8 Coordinate Geometry Refresher

:::callout-connect[Optional reference]
Supplementary video topics for this section:

“Analytic geometry | Khan Academy” — Khan Academy
:::

:::callout-intuition[Intuition]
Everything in Chapters 3 and 4 happens in three-dimensional space $\mathbb{R}^3$. Before you can think in 3D, you need 2D geometry to feel automatic: lines, circles, and especially conics (ellipses, hyperbolas, parabolas). These appear in MA 2733 as cross-sections of 3D surfaces and as limits of polar/parametric curves.

The jump to 3D is conceptually simple: add one more coordinate. The distance formula picks up one more squared term. A circle becomes a sphere. Completing the square — which you already know for 2D circles and conics — applies to all three variables when you identify a sphere. Chapter 3 includes geometry, and students who find 2D geometry unfamiliar struggle immediately.
:::

:::definition[Reference 0.8.1 — Conics in Standard Form]
| Conic | Standard form | Key feature |
| --- | --- | --- |
| Circle | $(x-h)^2+(y-k)^2=r^2$ | Center $(h,k)$, radius $r$ |
| Ellipse | $\frac{(x-h)^2}{a^2}+\frac{(y-k)^2}{b^2}=1$ | Semi-axes $a,b$; longer axis determined by which denominator is bigger |
| Parabola (vertical) | $y-k=a(x-h)^2$ | Vertex $(h,k)$; opens up if $a>0$, down if $a<0$ |
| Parabola (horizontal) | $x-h=a(y-k)^2$ | Vertex $(h,k)$; opens right if $a>0$ |
| Hyperbola (horizontal) | $\frac{(x-h)^2}{a^2}-\frac{(y-k)^2}{b^2}=1$ | Opens left/right; asymptotes $y-k=\pm\frac{b}{a}(x-h)$ |
| Hyperbola (vertical) | $\frac{(y-k)^2}{a^2}-\frac{(x-h)^2}{b^2}=1$ | Opens up/down |

**How to tell which conic you have from general form $Ax^2+Bxy+Cy^2+Dx+Ey+F=0$ (with $B=0$):**

- $A=C$: circle (or point/empty)
- $A$ and $C$ same sign, $A\neq C$: ellipse
- $A$ and $C$ opposite signs: hyperbola
- Only one of $A,C$ is nonzero: parabola
:::

:::definition[Reference 0.8.2 — Three-Dimensional Coordinate Geometry]
A point in 3D is a triple $(x,y,z)$. The three coordinate axes are mutually perpendicular; the $z$-axis points "up" out of the $xy$-plane. The eight octants are determined by the signs of the coordinates.

$$
\text{Distance: }d = \sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}
$$
$$
\text{Midpoint: }\left(\frac{x_1+x_2}{2},\frac{y_1+y_2}{2},\frac{z_1+z_2}{2}\right)
$$
**Sphere** with center $(h,k,\ell)$ and radius $r$:

$$
(x-h)^2+(y-k)^2+(z-\ell)^2=r^2
$$
To identify a sphere from general form $x^2+y^2+z^2+Dx+Ey+Fz+G=0$: complete the square in all three variables simultaneously.

**Coordinate planes and traces:** The $xy$-plane is $z=0$; the $yz$-plane is $x=0$; the $xz$-plane is $y=0$. Setting one variable to a constant "slices" the surface — the resulting curve is called a *trace*. Reading traces is the key skill for identifying quadric surfaces in Chapter 3.
:::

:::callout-tip[Connection to Test 2 planes]
For a plane $2x-y+3z=6$, the coefficients give a normal vector $\langle2,-1,3\rangle$. To check whether a point lies on the plane, substitute its coordinates. For example $(1,-1,1)$ gives $2+1+3=6$, so it lies on the plane. Do not confuse this plane with a sphere or a conic section.
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 360 210" width="360" height="210" role="img" aria-label="A horizontal hyperbola with center at one two">
<path class="fig-curve" d="M64.62 33.28 L65.17 33.72 L65.71 34.15 L66.26 34.59 L66.80 35.02 L67.34 35.46 L67.89 35.90 L68.43 36.33 L68.97 36.77 L69.52 37.21 L70.06 37.65 L70.61 38.09 L71.15 38.54 L71.69 38.98 L72.24 39.43 L72.78 39.87 L73.32 40.32 L73.87 40.77 L74.41 41.22 L74.96 41.67 L75.50 42.12 L76.04 42.57 L76.59 43.02 L77.13 43.48 L77.68 43.93 L78.22 44.39 L78.76 44.85 L79.31 45.31 L79.85 45.77 L80.39 46.23 L80.94 46.70 L81.48 47.16 L82.03 47.63 L82.57 48.10 L83.11 48.57 L83.66 49.04 L84.20 49.52 L84.74 49.99 L85.29 50.47 L85.83 50.95 L86.38 51.43 L86.92 51.91 L87.46 52.40 L88.01 52.89 L88.55 53.38 L89.09 53.87 L89.64 54.36 L90.18 54.86 L90.72 55.36 L91.27 55.86 L91.81 56.37 L92.36 56.88 L92.90 57.39 L93.44 57.90 L93.99 58.42 L94.53 58.94 L95.08 59.46 L95.62 59.99 L96.16 60.52 L96.71 61.05 L97.25 61.59 L97.79 62.13 L98.34 62.68 L98.88 63.23 L99.42 63.78 L99.97 64.35 L100.51 64.91 L101.06 65.48 L101.60 66.06 L102.14 66.64 L102.69 67.23 L103.23 67.83 L103.78 68.43 L104.32 69.04 L104.86 69.66 L105.41 70.29 L105.95 70.93 L106.49 71.58 L107.04 72.23 L107.58 72.90 L108.12 73.58 L108.67 74.28 L109.21 74.99 L109.76 75.71 L110.30 76.45 L110.84 77.21 L111.39 77.99 L111.93 78.80 L112.47 79.63 L113.02 80.49 L113.56 81.39 L114.11 82.33 L114.65 83.31 L115.19 84.35 L115.74 85.46 L116.28 86.66 L116.83 87.98 L117.37 89.46 L117.91 91.22 L118.46 93.48 L119.00 98.91"/>
<path class="fig-curve" d="M47.77 177.65 L48.31 177.23 L48.86 176.82 L49.40 176.40 L49.94 175.99 L50.49 175.57 L51.03 175.15 L51.57 174.73 L52.12 174.31 L52.66 173.90 L53.21 173.48 L53.75 173.06 L54.29 172.64 L54.84 172.22 L55.38 171.79 L55.93 171.37 L56.47 170.95 L57.01 170.53 L57.56 170.10 L58.10 169.68 L58.64 169.25 L59.19 168.83 L59.73 168.40 L60.27 167.97 L60.82 167.55 L61.36 167.12 L61.91 166.69 L62.45 166.26 L62.99 165.83 L63.54 165.40 L64.08 164.97 L64.62 164.53 L65.17 164.10 L65.71 163.67 L66.26 163.23 L66.80 162.80 L67.34 162.36 L67.89 161.92 L68.43 161.48 L68.97 161.05 L69.52 160.61 L70.06 160.17 L70.61 159.72 L71.15 159.28 L71.69 158.84 L72.24 158.39 L72.78 157.95 L73.32 157.50 L73.87 157.05 L74.41 156.60 L74.96 156.15 L75.50 155.70 L76.04 155.25 L76.59 154.80 L77.13 154.34 L77.68 153.89 L78.22 153.43 L78.76 152.97 L79.31 152.51 L79.85 152.05 L80.39 151.58 L80.94 151.12 L81.48 150.65 L82.03 150.19 L82.57 149.72 L83.11 149.25 L83.66 148.78 L84.20 148.30 L84.74 147.83 L85.29 147.35 L85.83 146.87 L86.38 146.39 L86.92 145.90 L87.46 145.42 L88.01 144.93 L88.55 144.44 L89.09 143.95 L89.64 143.45 L90.18 142.96 L90.72 142.46 L91.27 141.95 L91.81 141.45 L92.36 140.94 L92.90 140.43 L93.44 139.92 L93.99 139.40 L94.53 138.88 L95.08 138.36 L95.62 137.83 L96.16 137.30 L96.71 136.77 L97.25 136.23 L97.79 135.69 L98.34 135.14 L98.88 134.59 L99.42 134.03 L99.97 133.47 L100.51 132.91 L101.06 132.34 L101.60 131.76 L102.14 131.17 L102.69 130.59 L103.23 129.99 L103.78 129.38 L104.32 128.77 L104.86 128.15 L105.41 127.53 L105.95 126.89 L106.49 126.24 L107.04 125.59 L107.58 124.92 L108.12 124.24 L108.67 123.54 L109.21 122.83 L109.76 122.11 L110.30 121.37 L110.84 120.61 L111.39 119.82 L111.93 119.02 L112.47 118.19 L113.02 117.33 L113.56 116.43 L114.11 115.49 L114.65 114.51 L115.19 113.47 L115.74 112.36 L116.28 111.16 L116.83 109.84 L117.37 108.35 L117.91 106.60 L118.46 104.34 L119.00 98.91"/>
<path class="fig-curve-alt" d="M235.00 98.91 L235.54 93.48 L236.09 91.22 L236.63 89.46 L237.18 87.98 L237.72 86.66 L238.26 85.46 L238.81 84.35 L239.35 83.31 L239.89 82.33 L240.44 81.39 L240.98 80.49 L241.53 79.63 L242.07 78.80 L242.61 77.99 L243.16 77.21 L243.70 76.45 L244.24 75.71 L244.79 74.99 L245.33 74.28 L245.88 73.58 L246.42 72.90 L246.96 72.23 L247.51 71.58 L248.05 70.93 L248.59 70.29 L249.14 69.66 L249.68 69.04 L250.22 68.43 L250.77 67.83 L251.31 67.23 L251.86 66.64 L252.40 66.06 L252.94 65.48 L253.49 64.91 L254.03 64.35 L254.57 63.78 L255.12 63.23 L255.66 62.68 L256.21 62.13 L256.75 61.59 L257.29 61.05 L257.84 60.52 L258.38 59.99 L258.93 59.46 L259.47 58.94 L260.01 58.42 L260.56 57.90 L261.10 57.39 L261.64 56.88 L262.19 56.37 L262.73 55.86 L263.27 55.36 L263.82 54.86 L264.36 54.36 L264.91 53.87 L265.45 53.38 L265.99 52.89 L266.54 52.40 L267.08 51.91 L267.62 51.43 L268.17 50.95 L268.71 50.47 L269.26 49.99 L269.80 49.52 L270.34 49.04 L270.89 48.57 L271.43 48.10 L271.98 47.63 L272.52 47.16 L273.06 46.70 L273.61 46.23 L274.15 45.77 L274.69 45.31 L275.24 44.85 L275.78 44.39 L276.32 43.93 L276.87 43.48 L277.41 43.02 L277.96 42.57 L278.50 42.12 L279.04 41.67 L279.59 41.22 L280.13 40.77 L280.68 40.32 L281.22 39.87 L281.76 39.43 L282.31 38.98 L282.85 38.54 L283.39 38.09 L283.94 37.65 L284.48 37.21 L285.02 36.77 L285.57 36.33 L286.11 35.90 L286.66 35.46 L287.20 35.02 L287.74 34.59 L288.29 34.15 L288.83 33.72 L289.38 33.28"/>
<path class="fig-curve-alt" d="M235.00 98.91 L235.54 104.34 L236.09 106.60 L236.63 108.35 L237.18 109.84 L237.72 111.16 L238.26 112.36 L238.81 113.47 L239.35 114.51 L239.89 115.49 L240.44 116.43 L240.98 117.33 L241.53 118.19 L242.07 119.02 L242.61 119.82 L243.16 120.61 L243.70 121.37 L244.24 122.11 L244.79 122.83 L245.33 123.54 L245.88 124.24 L246.42 124.92 L246.96 125.59 L247.51 126.24 L248.05 126.89 L248.59 127.53 L249.14 128.15 L249.68 128.77 L250.22 129.38 L250.77 129.99 L251.31 130.59 L251.86 131.17 L252.40 131.76 L252.94 132.34 L253.49 132.91 L254.03 133.47 L254.57 134.03 L255.12 134.59 L255.66 135.14 L256.21 135.69 L256.75 136.23 L257.29 136.77 L257.84 137.30 L258.38 137.83 L258.93 138.36 L259.47 138.88 L260.01 139.40 L260.56 139.92 L261.10 140.43 L261.64 140.94 L262.19 141.45 L262.73 141.95 L263.27 142.46 L263.82 142.96 L264.36 143.45 L264.91 143.95 L265.45 144.44 L265.99 144.93 L266.54 145.42 L267.08 145.90 L267.62 146.39 L268.17 146.87 L268.71 147.35 L269.26 147.83 L269.80 148.30 L270.34 148.78 L270.89 149.25 L271.43 149.72 L271.98 150.19 L272.52 150.65 L273.06 151.12 L273.61 151.58 L274.15 152.05 L274.69 152.51 L275.24 152.97 L275.78 153.43 L276.32 153.89 L276.87 154.34 L277.41 154.80 L277.96 155.25 L278.50 155.70 L279.04 156.15 L279.59 156.60 L280.13 157.05 L280.68 157.50 L281.22 157.95 L281.76 158.39 L282.31 158.84 L282.85 159.28 L283.39 159.72 L283.94 160.17 L284.48 160.61 L285.02 161.05 L285.57 161.48 L286.11 161.92 L286.66 162.36 L287.20 162.80 L287.74 163.23 L288.29 163.67 L288.83 164.10 L289.38 164.53 L289.92 164.97 L290.46 165.40 L291.01 165.83 L291.55 166.26 L292.09 166.69 L292.64 167.12 L293.18 167.55 L293.73 167.97 L294.27 168.40 L294.81 168.83 L295.36 169.25 L295.90 169.68 L296.44 170.10 L296.99 170.53 L297.53 170.95 L298.07 171.37 L298.62 171.79 L299.16 172.22 L299.71 172.64 L300.25 173.06 L300.79 173.48 L301.34 173.90 L301.88 174.31 L302.43 174.73 L302.97 175.15 L303.51 175.57 L304.06 175.99 L304.60 176.40 L305.14 176.82 L305.69 177.23 L306.23 177.65"/>
</svg>
<figcaption>The equation $\frac{(x-1)^2}{4}-\frac{(y-2)^2}{9}=1$ has center $(1,2)$ and opens left and right because the $x$-square is positive.</figcaption>
</figure>

### Read an equation by its free directions

In two variables, a circle or ellipse controls both $x$ and $y$. In three variables, a relation that contains only $x$ and $z$ generally places no restriction on $y$. Thus its two-dimensional cross-section gets extended along the entire $y$ direction, creating a cylinder. This is the fastest way to avoid mistaking a cylinder for a sphere. To classify a quadric, first group the squared terms, identify their signs, and compare the constants. A sum of positive squares equal to a positive constant gives a bounded ellipsoid-type surface; mixed positive and negative squared terms produce hyperbolic families. A variable that appears only to the first power often indicates a paraboloid instead. Coordinate geometry is not just naming shapes; it tells you how to set up a vector, line, or plane around the shape.

### Lines and planes: point plus direction versus point plus normal

A line needs a point and a **direction** vector. A plane needs a point and a **normal** vector. These roles cannot be exchanged. If a line has direction $\langle a,b,c\rangle$, increasing its parameter by one moves the point by precisely that vector. If a plane has normal $\langle A,B,C\rangle$, its defining equation says the displacement from a fixed plane point has dot product zero with the normal. For three noncollinear plane points, form two displacement vectors along the plane and cross them to get a normal. Check that the resulting normal is perpendicular to both in-plane vectors; the dot products should vanish.

Completing the square is useful again for locating sphere centers, but each coordinate must be handled independently. The constants produced by completing each square move to the right-hand side together; only then should you take a square root to obtain the radius. A negative computed radius-squared means the proposed real sphere has no points, not that its radius is a negative real number. Finally, if a 3D equation has no $z$, sketch a cross-section in the $xy$ plane and imagine dragging it parallel to the $z$ axis. This mental model helps identify the orientation of quadric cylinders on Test 2.

### Worked examples

:::::example[Example 0.32 — Identifying a conic by completing the square]
Identify the conic: $9x^2 - 4y^2 - 18x + 16y - 43 = 0$.

::::answer[Answer]
**Answer:** Hyperbola, center $(1,2)$, transverse axis horizontal.

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. The $x^2$ and $y^2$ coefficients have opposite signs (9 and $-4$) — this is a hyperbola.
3. Complete the square in both variables:

$$
9(x^2-2x) - 4(y^2-4y) = 43
$$
4. Compute the expression at this stage:

$$
9(x^2-2x+1-1) - 4(y^2-4y+4-4) = 43
$$
5. Compute the expression at this stage:

$$
9(x-1)^2 - 9 - 4(y-2)^2 + 16 = 43
$$
6. Compute the expression at this stage:

$$
9(x-1)^2 - 4(y-2)^2 = 43+9-16 = 36
$$
7. Compute the expression at this stage:

$$
\frac{(x-1)^2}{4} - \frac{(y-2)^2}{9} = 1
$$
8. Standard hyperbola form $\frac{(x-h)^2}{a^2}-\frac{(y-k)^2}{b^2}=1$ with center $(1,2)$, $a=2$, $b=3$.
9. Transverse axis horizontal (the positive term involves $x$).
10. Asymptotes: $y-2=\pm\frac{3}{2}(x-1)$.
11. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::
:::::example[Example 0.33 — Finding a sphere by completing the square in 3D]
Find the center and radius of the sphere: $x^2+y^2+z^2-6x+4y-2z=11$.

::::answer[Answer]
**Answer:** Center $(3,-2,1)$, radius $5$.

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Group terms by variable and complete the square in each.
3. The rule: for $x^2 + bx$, add $(b/2)^2$ to both sides.
4. Compute the expression at this stage:

$$
(x^2-6x\phantom{+9}) + (y^2+4y\phantom{+4}) + (z^2-2z\phantom{+1}) = 11
$$
5. Complete each square. For $x$: half of $-6$ is $-3$, square is $9$.
6. For $y$: half of $4$ is $2$, square is $4$.
7. For $z$: half of $-2$ is $-1$, square is $1$.
8. Add these to both sides:

$$
(x^2-6x+9) + (y^2+4y+4) + (z^2-2z+1) = 11+9+4+1 = 25
$$
9. Compute the expression at this stage:

$$
(x-3)^2+(y+2)^2+(z-1)^2 = 25
$$
10. Center $(3,-2,1)$, radius $\sqrt{25}=5$.
11. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::
:::::example[Example 0.34 — Distance and midpoint in 3D]
Points $P=(1,-2,4)$ and $Q=(3,0,-2)$. Find the distance $|PQ|$, the midpoint $M$, and verify that $|PM|=|PQ|/2$.

::::answer[Answer]
**Answer:** $|PQ|=\sqrt{44}=2\sqrt{11}$. $M=(2,-1,1)$. $|PM|=\sqrt{11}$. ✓

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Compute the expression at this stage:

$$
|PQ|=\sqrt{(3-1)^2+(0-(-2))^2+(-2-4)^2}=\sqrt{4+4+36}=\sqrt{44}=2\sqrt{11}
$$
3. Compute the expression at this stage:

$$
M=\left(\frac{1+3}{2},\frac{-2+0}{2},\frac{4+(-2)}{2}\right)=(2,-1,1)
$$
4. Compute the expression at this stage:

$$
|PM|=\sqrt{(2-1)^2+(-1+2)^2+(1-4)^2}=\sqrt{1+1+9}=\sqrt{11}=\frac{|PQ|}{2}\;\checkmark
$$
5. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::
:::::example[Example 0.35 — A line and a plane in three dimensions]
A line passes through $P=(1,0,-2)$ with direction vector $\mathbf d=\langle2,-1,3\rangle$. Write its parametric equations, find the point at parameter $s=2$, and check whether the line is parallel to the plane $x+2y=5$.

::::answer[Answer]
**Answer:** $x=1+2s,\ y=-s,\ z=-2+3s$; at $s=2$ the point is $(5,-2,4)$; the line is parallel to the plane and is not contained in it.

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. A point plus parameter times a direction vector traces a line:

$$
\mathbf r(s)=\langle1,0,-2\rangle+s\langle2,-1,3\rangle
=\langle1+2s,-s,-2+3s\rangle.
$$
3. At $s=2$, the coordinates are $1+2(2)=5$, $-2$, and $-2+3(2)=4$.
4. A plane $ax+by+cz=d$ has normal vector $\langle a,b,c\rangle$; here it is $\mathbf n=\langle1,2,0\rangle$.
5. Compute the dot product:
$$\mathbf n\cdot\mathbf d=(1)(2)+(2)(-1)+(0)(3)=2-2=0.$$
6. Because the normal is perpendicular to the line's direction, the line is parallel to the plane.
7. But $P$ does **not** lie on the plane: $1+2(0)=1\ne5$.
8. Therefore the line never intersects the plane.
9. This is a Test 2-style distinction between a direction vector and a plane normal.
10. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::
:::callout-pitfall[Watch out for]
- **Adding the wrong constant when completing the square in a factored group.** If you write $4(x^2-2x)$ and complete to $4(x^2-2x+1)$, you've added $4\cdot1=4$ to the left side — so you must add $4$ (not $1$) to the right side too. The coefficient outside the parentheses scales the added constant.
- **Getting a negative right-hand side in the sphere equation.** If, after completing the square, the right side is negative, the equation has no real solutions — there's no actual sphere. If it's zero, the "sphere" is just the single center point. Only positive right sides give genuine spheres.
:::

### Practice problems

:::::problem[Problem 0.46 — Three-dimensional distance]{difficulty=easy}
Find the distance between $(-1,3,0)$ and $(2,-1,4)$.

::::solution[Solution]
**Answer:** $\sqrt{41}$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $d=\sqrt{9+16+16}=\sqrt{41}$.
4. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem 0.47 — Standard-form ellipse]{difficulty=easy}
Identify the conic: $4x^2+9y^2=36$. Write it in standard form and state the semi-axes.

::::solution[Solution]
**Answer:** Ellipse, $x^2/9+y^2/4=1$; semi-axes $3,2$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Divide by 36: $\frac{x^2}{9}+\frac{y^2}{4}=1$.
3. Ellipse centered at origin, semi-axes $a=3$ (horizontal), $b=2$ (vertical).
4. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem 0.48 — Sphere by completing squares]{difficulty=standard}
Find center and radius: $x^2+y^2+z^2+2x-4z=0$.

::::solution[Solution]
**Answer:** Center $(-1,0,2)$, radius $\sqrt5$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Complete square: $(x+1)^2-1+(y^2)+(z-2)^2-4=0\Rightarrow(x+1)^2+y^2+(z-2)^2=5$.
4. Center $(-1,0,2)$, radius $\sqrt{5}$.
5. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem 0.49 — Horizontal parabola]{difficulty=standard}
Identify and sketch-describe the conic: $y^2 - 2y - 8x - 15 = 0$.

::::solution[Solution]
**Answer:** $(y-1)^2=8(x+2)$; vertex $(-2,1)$, rightward

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Only $y^2$ appears (not $x^2$) — parabola with horizontal axis.
3. Complete square in $y$: $(y-1)^2-1=8x+15\Rightarrow(y-1)^2=8x+16=8(x+2)$.
4. Parabola with vertex $(-2,1)$, horizontal axis, opening rightward (coefficient of $x$ is positive).
5. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem 0.50 — Sphere from a diameter]{difficulty=challenge}
Find the equation of the sphere that has the segment from $P=(0,0,0)$ to $Q=(4,2,-2)$ as a diameter.

::::solution[Solution]
**Answer:** $(x-2)^2+(y-1)^2+(z+1)^2=6$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Center = midpoint of $PQ$ = $(2,1,-1)$.
3. Radius = half the diameter = $\frac{|PQ|}{2}=\frac{\sqrt{16+4+4}}{2}=\frac{\sqrt{24}}{2}=\sqrt{6}$.
4. Equation: $(x-2)^2+(y-1)^2+(z+1)^2=6$.
5. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

## 0.9 Notation and Calculator Policy

### Notation used throughout this book

Consistent notation prevents errors. Here is every symbol that appears in MA 2733 together with the convention adopted in this book. The conventions below are for this book; write vector components in angle brackets.

:::definition[Reference 0.9.1 — Notation Standard]
| Concept | Notation in this book | Note |
| --- | --- | --- |
| Vectors | $\vec{v}$ (arrow) | Not bold; matches Thomas and most MSU sections |
| Vector components | $\langle a,b,c\rangle$ (angle brackets) | Not parentheses |
| Standard basis | $\hat{\imath},\hat{\jmath},\hat{k}$ | Unit vectors along $x,y,z$ axes |
| Magnitude of $\vec{v}$ | $|\vec{v}|$ |  |
| Derivative | $f'(x)$ or $df/dx$ | Both used; context determines which is cleaner |
| Partial derivative | $f_x$ inline; $\partial f/\partial x$ displayed | Not on Tests 1–4 |
| Gradient | $\nabla f$ | "Del $f$" |
| Natural log | $\ln x$ | Base $e$; $\log x$ reserved for base 10 in this book |
| Absolute value / distance | $|a|$ |  |
| Interval notation | $(a,b)$ open; $[a,b]$ closed; $(a,b]$ half-open | Don't write intervals as ordered pairs in the same context |
| Limits | Always write $\lim_{x\to a}$ — never substitute $\infty$ directly |  |
:::

### Calculator policy

:::callout-warning[Young's written tests: no calculator]
The supplied course notes explicitly say **no calculator** for all four tests. Give exact fractions, radicals, multiples of $\pi$, logarithms, and algebraic expressions, not decimals. Some other MSU sections may have different policies; do not apply them to this section. The final-exam device policy was not provided here, so prepare as if no calculator is available unless Young states otherwise.
:::

:::callout-tip[Checking work after a hand solution]
Desmos or GeoGebra can check shapes and Mathematica or SymPy can check derivatives and integrals outside exams. Neither replaces the written setup, hypothesis checks, and exact answer Young grades. No campus software license or tutoring location is asserted here without a current source.
:::

## Chapter Summary

:::summary[The essentials]

### Key results

| Section | The one formula to own cold |
| --- | --- |
| 0.1 Algebra | PFD setup: distinct linear $\to\frac{A}{x-a}$; repeated $\to\frac{A}{x-a}+\frac{B}{(x-a)^2}$; irreducible quadratic $\to\frac{Ax+B}{x^2+bx+c}$ |
| 0.2 Trig | Power-reduction: $\sin^2\theta=\frac{1-\cos 2\theta}{2}$, $\cos^2\theta=\frac{1+\cos 2\theta}{2}$. These unlock all even-power trig integrals. |
| 0.3 Limits | Growth hierarchy: $\ln n\ll n^a\ll b^n\ll n!$. L'Hôpital for $0/0,\infty/\infty$ only. $\ln$-trick for $1^\infty,0^0,\infty^0$. |
| 0.4 Derivatives | Chain rule: differentiate outside, multiply by inside derivative. Repeat for each layer. |
| 0.5 Integration | Decision table: odd trig power $\to$ save-one-and-sub; even $\to$ power-reduce; radical $\to$ trig sub; rational $\to$ PFD. |
| 0.6 Geometry | Arc length: $\int\sqrt{1+(y')^2}\,dx$. Look for a perfect-square simplification of $1+(y')^2$. |
| 0.7 Sequences | Geometric series: $\sum ar^n=a/(1-r)$ iff $|r|<1$. Sequence $\to 0$ does not imply series converges. |
| 0.8 3D Geometry | Sphere from general form: complete the square in all three variables. Center is the $(h,k,\ell)$ that appears; radius is $\sqrt{\text{RHS}}$. |

### If you remember nothing else

Every single technique in this chapter reappears in MA 2733 without any announcement. Power-reduction shows up in polar area integrals. L'Hôpital and the growth hierarchy run through Chapter 2 like a backbone. Arc length from §0.6 becomes parametric arc length in Chapter 1 and space-curve arc length in Chapter 4. Completing the square identifies spheres in Chapter 3. **This is not a chapter you read once and move on from — it's a reference you return to all semester.**

🚀 Why this matters going forward

**Chapter 1** (Parametric & Polar) uses §0.2 and §0.5 immediately — polar area is $\frac{1}{2}\int r^2\,d\theta$ where $r=f(\theta)$, producing integrals packed with $\cos^2\theta$ and $\sin^2\theta$ terms. **Chapter 2** (Series) runs on §0.3 and §0.7 — the growth hierarchy is the intuition behind almost every convergence test. **Chapter 3** (Vectors) builds on §0.8 — you identify spheres, planes, and quadric surfaces by completing the square. **Chapter 4** (Vector Functions) extends §0.6 arc length into 3D. Every topic in MA 2733 has a root in Chapter 0.
:::

## Mixed Practice

These 14 problems come from all nine sections, in random order, with mixed difficulties. Use them as a diagnostic before starting Chapter 1. Any problem that takes more than 10 minutes is a signal to revisit its source section.

:::::problem[Problem M.1 — Cosine-squared integral]{difficulty=easy}
Evaluate $\displaystyle\int_0^{\pi/2}\cos^2 x\,dx$.

::::solution[Solution]
**Answer:** $\pi/4$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $\int_0^{\pi/2}\frac{1+\cos 2x}{2}\,dx=\frac{1}{2}\left[x+\frac{\sin 2x}{2}\right]_0^{\pi/2}=\frac{1}{2}\cdot\frac{\pi}{2}=\frac{\pi}{4}$.
4. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem M.2 — Distance and midpoint]{difficulty=easy}
Find the distance between $(0,1,2)$ and $(3,-2,4)$ and the midpoint.

::::solution[Solution]
**Answer:** $\sqrt{22}$; midpoint $(3/2,-1/2,3)$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. $d=\sqrt{9+9+4}=\sqrt{22}$.
4. Midpoint: $(3/2,-1/2,3)$.
5. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem M.3 — Rational sequence limit]{difficulty=easy}
Evaluate $\displaystyle\lim_{n\to\infty}\frac{3n^4+2n^2-1}{7n^4-n^3}$.

::::solution[Solution]
**Answer:** $3/7$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Divide by $n^4$: $\frac{3+2/n^2-1/n^4}{7-1/n}\to\frac{3}{7}$.
4. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem M.4 — Inverse-sine chain rule]{difficulty=standard}
Differentiate $f(x) = \arcsin\!\left(\dfrac{x}{2}\right)$ and simplify.

::::solution[Solution]
**Answer:** $1/\sqrt{4-x^2}$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Chain rule: $f'(x)=\dfrac{1}{\sqrt{1-(x/2)^2}}\cdot\dfrac{1}{2}=\dfrac{1}{2\sqrt{1-x^2/4}}=\dfrac{1}{\sqrt{4-x^2}}$.
4. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem M.5 — Telescoping rational series]{difficulty=standard}
Find the sum of the series $\displaystyle\sum_{n=2}^{\infty}\frac{1}{n^2-1}$. (*Hint: PFD, then telescope.*)

::::solution[Solution]
**Answer:** $3/4$

1. Write the appropriate finite partial sum or sequence limit, then check the conditions needed to take its limit.
2. $\frac{1}{n^2-1}=\frac{1}{(n-1)(n+1)}=\frac{1}{2}\!\left(\frac{1}{n-1}-\frac{1}{n+1}\right)$.
3. Partial sum (telescoping, skip-2 pattern): $S_N=\frac{1}{2}\!\left(1+\frac{1}{2}-\frac{1}{N}-\frac{1}{N+1}\right)\to\frac{1}{2}\cdot\frac{3}{2}=\frac{3}{4}$.
4. Check: the partial-sum or geometric-series rule is used only after its convergence condition has been stated.
::::
:::::

:::::problem[Problem M.6 — Trigonometric substitution]{difficulty=standard}
Evaluate $\displaystyle\int\frac{dx}{x^2\sqrt{x^2+4}}$. Use trig substitution.

::::solution[Solution]
**Answer:** $-\sqrt{x^2+4}/(4x)+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. $x=2\tan\theta$, $dx=2\sec^2\theta\,d\theta$, $\sqrt{x^2+4}=2\sec\theta$.
3. $\int\frac{2\sec^2\theta\,d\theta}{4\tan^2\theta\cdot2\sec\theta}=\int\frac{\sec\theta}{4\tan^2\theta}\,d\theta=\frac{1}{4}\int\frac{\cos\theta}{\sin^2\theta}\,d\theta=\frac{1}{4}\int\csc\theta\cot\theta\,d\theta=-\frac{\csc\theta}{4}+C$.
4. Back-sub: $\tan\theta=x/2$, so $\sin\theta=x/\sqrt{x^2+4}$, $\csc\theta=\sqrt{x^2+4}/x$.
5. $-\dfrac{\sqrt{x^2+4}}{4x}+C$.
6. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem M.7 — Volume by the disk method]{difficulty=standard}
Find the volume of the solid formed by revolving the region under $y=1/x$ from $x=1$ to $x=3$ about the $x$-axis.

::::solution[Solution]
**Answer:** $2\pi/3$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Work with the original expression as written, carrying the sign and each constant through the calculation. If an intermediate denominator occurs, keep its restrictions in force before simplifying.
3. Disk: $V=\pi\int_1^3\frac{1}{x^2}\,dx=\pi\left[-\frac{1}{x}\right]_1^3=\pi\!\left(-\frac{1}{3}+1\right)=\frac{2\pi}{3}$.
4. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

:::::problem[Problem M.8 — Cosine double-angle equation]{difficulty=standard}
Solve $\cos x = \cos 2x$ on $[0,2\pi)$. (*Hint: use a double-angle formula to write everything in terms of $\cos x$.*)

::::solution[Solution]
**Answer:** $0,2\pi/3,4\pi/3$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. $\cos 2x=2\cos^2 x-1$.
3. So $\cos x=2\cos^2 x-1\Rightarrow 2\cos^2 x-\cos x-1=0\Rightarrow(2\cos x+1)(\cos x-1)=0$.
4. $\cos x=1\Rightarrow x=0$.
5. $\cos x=-1/2\Rightarrow x=2\pi/3,4\pi/3$.
6. $0, 2\pi/3, 4\pi/3$.
7. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

:::::problem[Problem M.9 — Variable power derivative]{difficulty=standard}
Find $dy/dx$ for $y = x^{\ln x}$ (logarithmic differentiation).

::::solution[Solution]
**Answer:** $2x^{\ln x}\ln x/x$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. $\ln y=\ln x\cdot\ln x=(\ln x)^2$.
3. Differentiate: $\frac{y'}{y}=\frac{2\ln x}{x}$.
4. So $y'=x^{\ln x}\cdot\frac{2\ln x}{x}$.
5. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem M.10 — Three-dimensional sphere]{difficulty=standard}
Identify the conic and find its center: $x^2+y^2+z^2-4x+6y-2z+5=0$. Also identify what geometric object the equation represents.

::::solution[Solution]
**Answer:** Sphere, center $(2,-3,1)$, radius $3$

1. Use the standard coordinate equations and complete squares or calculate distances component by component.
2. Complete the square: $(x-2)^2-4+(y+3)^2-9+(z-1)^2-1=-5\Rightarrow(x-2)^2+(y+3)^2+(z-1)^2=9$.
3. Sphere, center $(2,-3,1)$, radius $3$.
4. Check: substitute the derived standard form back into the original equation, or verify the distance using squared components.
::::
:::::

:::::problem[Problem M.11 — Correction to an exponential limit]{difficulty=challenge}
Evaluate $\displaystyle\lim_{x\to 0}\frac{(1+x)^{1/x} - e}{x}$. (*This limit gives the leading correction to the famous limit $(1+x)^{1/x}\to e$.*)

::::solution[Solution]
**Answer:** $-e/2$

1. Start by identifying the limit form. Use algebra, conjugates, the Squeeze Theorem, or L'Hôpital only when its hypotheses apply.
2. Write $(1+x)^{1/x}=e^{\ln(1+x)/x}$.
3. Let $g(x)=\frac{\ln(1+x)}{x}$.
4. Then $g(0)=1$ (limit) and $g'(0)=\lim_{x\to0}\frac{x/(1+x)-\ln(1+x)}{x^2}$.
5. L'Hôpital: $\frac{-x/(1+x)^2}{2x}=-\frac{1}{2(1+x)^2}\to-\frac{1}{2}$.
6. So $(1+x)^{1/x}=e^{g(x)}\approx e^{1-x/2+\cdots}\approx e\cdot e^{-x/2}\approx e(1-x/2+\cdots)$.
7. Thus $\frac{(1+x)^{1/x}-e}{x}\approx\frac{-ex/2}{x}=-\frac{e}{2}$.
8. The limit is $-\dfrac{e}{2}$.
9. Check: the final expression follows after taking the indicated limit of each remaining term.
::::
:::::

:::::problem[Problem M.12 — Improper substitution integral]{difficulty=challenge}
Evaluate $\displaystyle\int_0^{\infty}\frac{x}{(1+x^2)^2}\,dx$.

::::solution[Solution]
**Answer:** $1/2$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. Let $u=1+x^2$, $du=2x\,dx$; limits: $u(0)=1$, $u(\infty)=\infty$.
3. $\frac{1}{2}\int_1^{\infty}u^{-2}\,du=\frac{1}{2}\left[-\frac{1}{u}\right]_1^{\infty}=\frac{1}{2}(0+1)=\frac{1}{2}$.
4. Converges to $\dfrac{1}{2}$.
5. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem M.13 — Quartic partial fractions]{difficulty=challenge}
Decompose $\dfrac{1}{x^4-1}$ into partial fractions. Factor the denominator completely first.

::::solution[Solution]
**Answer:** $\frac1{4(x-1)}-\frac1{4(x+1)}-\frac1{2(x^2+1)}$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. $x^4-1=(x^2-1)(x^2+1)=(x-1)(x+1)(x^2+1)$.
3. Setup: $\frac{A}{x-1}+\frac{B}{x+1}+\frac{Cx+D}{x^2+1}$.
4. At $x=1$: $1=A\cdot2\cdot2=4A\Rightarrow A=1/4$.
5. At $x=-1$: $1=B\cdot(-2)\cdot2=-4B\Rightarrow B=-1/4$.
6. Match $x^3$ coefficients (must be 0): $A+B+C=0\Rightarrow C=0$.
7. For $D$ there is no convenient root left to substitute, so expand instead — guessing which factors survive at $x^0$ is where this goes wrong: $1=A(x+1)(x^2+1)+B(x-1)(x^2+1)+(Cx+D)(x-1)(x+1)$.
8. At $x^0$: $A(1)(1)+B(-1)(1)+D(-1)=1\Rightarrow A-B-D=1\Rightarrow 1/4+1/4-D=1\Rightarrow D=-1/2$.
9. Final: $\frac{1/4}{x-1}-\frac{1/4}{x+1}-\frac{1/2}{x^2+1}$.
10. Check: put the terms over one common denominator to recover the starting rational expression.
::::
:::::

:::::problem[Problem M.14 — Logarithmic shell volume]{difficulty=challenge}
The region between $y=\ln x$ and the $x$-axis from $x=1$ to $x=e$ is rotated about the $y$-axis. Find the volume using the shell method.

::::solution[Solution]
**Answer:** $\pi(e^2+1)/2$

1. Set up the correct area, length, or volume formula from the geometry and limits before evaluating the integral.
2. Shells: $V=2\pi\int_1^e x\ln x\,dx$.
3. IBP: $u=\ln x$, $dv=x\,dx$, $du=dx/x$, $v=x^2/2$.
4. $V=2\pi\left[\frac{x^2\ln x}{2}-\int\frac{x^2}{2}\cdot\frac{dx}{x}\right]_1^e=2\pi\left[\frac{x^2\ln x}{2}-\frac{x^2}{4}\right]_1^e=2\pi\!\left[\!\left(\frac{e^2}{2}-\frac{e^2}{4}\right)-\left(0-\frac{1}{4}\right)\right]=2\pi\!\left(\frac{e^2}{4}+\frac{1}{4}\right)=\frac{\pi(e^2+1)}{2}$.
5. Check: the final integral uses the original endpoints and nonnegative geometric dimensions.
::::
:::::

---

### Weak-Spot Drill: 20 Targeted Problems

These problems zero in on the Calc 1/2 skills that cause the most grief in Calc 3: the **chain rule** in all its forms, **trig derivatives** (including inverses), and **integration techniques** (u-substitution, integration by parts, trig integrals, partial fractions). Master these and the rest of the course gets dramatically easier.

:::::problem[Problem M.15 — Chain Rule: Single Composition]{difficulty=standard}
Differentiate $f(x) = \sin(x^3 + 2x)$.

::::solution[Solution]
**Answer:** $\cos(x^3+2x)(3x^2+2)$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Identify outer and inner functions.** Outer: $\sin(\square)$.
3. Inner: $u = x^3+2x$.
4. **Chain rule:** $f'(x) = \cos(u)\cdot u'$.
5. Compute the expression at this stage:

$$
u' = 3x^2+2
$$
6. Compute the expression at this stage:

$$
f'(x) = \cos(x^3+2x)\cdot(3x^2+2)
$$
7. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-key
Chain rule template:

$\dfrac{d}{dx}[f(g(x))] = f'(g(x))\cdot g'(x)$. Always: derivative of outside (leaving inside alone) times derivative of inside.
:::
::::
:::::

:::::problem[Problem M.16 — Chain Rule: Nested Composition]{difficulty=standard}
Differentiate $g(x) = e^{\sin^2(x)}$.

::::solution[Solution]
**Answer:** $e^{\sin^2x}\sin2x$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Three layers:** exponential → square → sine.
3. **Layer 1 (outer):** $\dfrac{d}{dx}[e^u] = e^u\cdot u'$ where $u=\sin^2 x$.
4. **Layer 2 (differentiating $\sin^2 x$):** $\dfrac{d}{dx}[\sin^2 x] = 2\sin x\cdot\cos x = \sin 2x$.
5. Compute the expression at this stage:

$$
g'(x) = e^{\sin^2 x}\cdot\sin 2x
$$
6. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-pitfall
Common mistake:

Writing $g'(x)=e^{\sin^2 x}$ without the chain factor $\sin 2x$. Every composition layer adds a factor.
:::
::::
:::::

:::::problem[Problem M.17 — Chain Rule: Quotient inside Trig]{difficulty=standard}
Differentiate $h(x) = \tan\!\left(\dfrac{x}{x^2+1}\right)$.

::::solution[Solution]
**Answer:** $\sec^2\!\left(\frac{x}{x^2+1}\right)\frac{1-x^2}{(x^2+1)^2}$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Outer:** $\sec^2(\square)$ times inner.
3. Inner: $u = \dfrac{x}{x^2+1}$.
4. **Differentiate $u$ with the quotient rule:**
5. Compute the expression at this stage:

$$
u' = \frac{(x^2+1)(1)-x(2x)}{(x^2+1)^2} = \frac{1-x^2}{(x^2+1)^2}
$$
6. Compute the expression at this stage:

$$
h'(x) = \sec^2\!\left(\frac{x}{x^2+1}\right)\cdot\frac{1-x^2}{(x^2+1)^2}
$$
7. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem M.18 — Trig Derivative: All Six Functions]{difficulty=standard}
Differentiate each: (a) $\tan x$ (b) $\csc x$ (c) $\sec x$ (d) $\cot x$.

::::solution[Solution]
**Answer:** $(\tan x)\'=\sec^2x$, $(\csc x)\'=-\csc x\cot x$, $(\sec x)\'=\sec x\tan x$, $(\cot x)\'=-\csc^2x$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. These are derived from sin and cos using quotient rule.
3. Know them cold.
4. (a) $\tan x = \sin x/\cos x$:

$$
\frac{d}{dx}[\tan x] = \frac{\cos x\cdot\cos x - \sin x(-\sin x)}{\cos^2 x} = \frac{\cos^2x+\sin^2x}{\cos^2x} = \frac{1}{\cos^2x} = \sec^2x
$$
5. (b) $\csc x = 1/\sin x$:

$$
\frac{d}{dx}[\csc x] = -\frac{\cos x}{\sin^2 x} = -\frac{1}{\sin x}\cdot\frac{\cos x}{\sin x} = -\csc x\cot x
$$
6. (c) $\sec x = 1/\cos x$:

$$
\frac{d}{dx}[\sec x] = \frac{\sin x}{\cos^2 x} = \sec x\tan x
$$
7. (d) $\cot x = \cos x/\sin x$:

$$
\frac{d}{dx}[\cot x] = \frac{-\sin^2x-\cos^2x}{\sin^2x} = -\frac{1}{\sin^2x} = -\csc^2x
$$
8. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-key
Memory pattern:

The co-functions (cos, csc, cot) each get a negative sign. The sec-tan pair and csc-cot pair go together.
:::
::::
:::::

:::::problem[Problem M.19 — Inverse Trig Derivatives]{difficulty=standard}
Differentiate: (a) $\arcsin(2x)$ (b) $\arctan(x^2)$ (c) $\arccos(\sqrt{x})$.

::::solution[Solution]
**Answer:** $2/\sqrt{1-4x^2}$; $2x/(1+x^4)$; $-1/(2\sqrt{x(1-x)})$

1. Apply the relevant trigonometric identity and use exact unit-circle values; determine all required angles on the stated interval.
2. **Formulas (derive once, memorize):** $\dfrac{d}{dx}[\arcsin u]=\dfrac{u'}{\sqrt{1-u^2}}$, $\dfrac{d}{dx}[\arctan u]=\dfrac{u'}{1+u^2}$, $\dfrac{d}{dx}[\arccos u]=-\dfrac{u'}{\sqrt{1-u^2}}$.
3. (a) $u=2x$, $u'=2$:

$$
\frac{d}{dx}[\arcsin(2x)] = \frac{2}{\sqrt{1-4x^2}}
$$
4. (b) $u=x^2$, $u'=2x$:

$$
\frac{d}{dx}[\arctan(x^2)] = \frac{2x}{1+x^4}
$$
5. (c) $u=\sqrt{x}=x^{1/2}$, $u'=\frac{1}{2\sqrt{x}}$:

$$
\frac{d}{dx}[\arccos(\sqrt{x})] = -\frac{1/(2\sqrt{x})}{\sqrt{1-x}} = -\frac{1}{2\sqrt{x(1-x)}}
$$
6. Check: substitute the derived identity or candidate angle into the original trigonometric expression.
::::
:::::

:::::problem[Problem M.20 — Chain Rule + Product Rule Together]{difficulty=challenge}
Differentiate $f(x) = x^2 e^{\cos x}$.

::::solution[Solution]
**Answer:** $e^{\cos x}(2x-x^2\sin x)$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Product rule first:** $(uv)' = u'v+uv'$ with $u=x^2$, $v=e^{\cos x}$.
3. Compute the expression at this stage:

$$
u' = 2x
$$
4. For $v' = \dfrac{d}{dx}[e^{\cos x}]$: outer is $e^{\square}$, inner is $\cos x$:

$$
v' = e^{\cos x}\cdot(-\sin x)
$$
5. Compute the expression at this stage:

$$
f'(x) = 2x\cdot e^{\cos x} + x^2\cdot(-\sin x)e^{\cos x} = e^{\cos x}(2x - x^2\sin x)
$$
6. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-key
Strategy:

When you see a product where one factor is a composition, apply the product rule and then the chain rule on the complicated factor.
:::
::::
:::::

:::::problem[Problem M.21 — Implicit Differentiation]{difficulty=challenge}
Find $dy/dx$ if $x^2y + \sin(xy) = 4$.

::::solution[Solution]
**Answer:** $-y(2x+\cos(xy))/(x^2+x\cos(xy))$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Differentiate both sides with respect to $x$, treating $y$ as a function of $x$.**
3. Left side, first term $x^2y$ — product rule:

$$
2xy + x^2\frac{dy}{dx}
$$
4. Left side, second term $\sin(xy)$ — chain rule, with inner $xy$, inner derivative by product rule:

$$
\cos(xy)\cdot\left(y + x\frac{dy}{dx}\right)
$$
5. **Put it together:**
6. Compute the expression at this stage:

$$
2xy + x^2\frac{dy}{dx} + \cos(xy)\left(y+x\frac{dy}{dx}\right) = 0
$$
7. **Collect $dy/dx$ terms:**
8. Compute the expression at this stage:

$$
\frac{dy}{dx}\left(x^2+x\cos(xy)\right) = -2xy - y\cos(xy)
$$
9. Compute the expression at this stage:

$$
\frac{dy}{dx} = \frac{-y(2x+\cos(xy))}{x^2+x\cos(xy)}
$$
10. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.
::::
:::::

:::::problem[Problem M.22 — u-Substitution: Basic]{difficulty=standard}
Compute $\displaystyle\int x\cos(x^2)\,dx$.

::::solution[Solution]
**Answer:** $\sin(x^2)/2+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Spot the substitution.** The integrand contains $\cos(x^2)$ and its inner derivative $x$ is sitting right next to it.
3. This is a perfect u-sub.
4. **Let $u = x^2$.** Then $du = 2x\,dx$, so $x\,dx = \dfrac{1}{2}du$.
5. Compute the expression at this stage:

$$
\int x\cos(x^2)\,dx = \int\cos u\cdot\frac{1}{2}\,du = \frac{1}{2}\sin u + C = \frac{1}{2}\sin(x^2)+C
$$
6. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-key
u-sub recognition:

Look for a function and its derivative (possibly off by a constant) in the same integral. Here $x = \frac{1}{2}\cdot(x^2)'$. If you see $f(g(x))\cdot g'(x)$, substitute $u=g(x)$.
:::
::::
:::::

:::::problem[Problem M.23 — u-Substitution: Definite Integral]{difficulty=standard}
Compute $\displaystyle\int_0^1 \frac{x}{(x^2+1)^3}\,dx$.

::::solution[Solution]
**Answer:** $3/16$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Let $u=x^2+1$.** Then $du=2x\,dx$, so $x\,dx=\frac{1}{2}du$.
3. **Change limits.** When $x=0$: $u=1$.
4. When $x=1$: $u=2$. No need to back-substitute.
5. Compute the expression at this stage:

$$
\int_0^1\frac{x}{(x^2+1)^3}\,dx = \int_1^2\frac{1}{u^3}\cdot\frac{1}{2}\,du = \frac{1}{2}\int_1^2 u^{-3}\,du = \frac{1}{2}\left[\frac{u^{-2}}{-2}\right]_1^2
$$
6. Compute the expression at this stage:

$$
= \frac{1}{2}\cdot\left(-\frac{1}{2}\right)\left[\frac{1}{u^2}\right]_1^2 = -\frac{1}{4}\left(\frac{1}{4}-1\right) = -\frac{1}{4}\cdot\left(-\frac{3}{4}\right) = \frac{3}{16}
$$
7. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-pitfall
Pitfall:

When you change variables in a definite integral, you MUST update the limits. Don't integrate in terms of $u$ and then plug in the old $x$-limits.
:::
::::
:::::

:::::problem[Problem M.24 — Integration by Parts]{difficulty=challenge}
Compute $\displaystyle\int x^2 e^x\,dx$.

::::solution[Solution]
**Answer:** $e^x(x^2-2x+2)+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Formula:** $\int u\,dv = uv - \int v\,du$.
3. Choose: $u=x^2$ (it simplifies when differentiated), $dv=e^x\,dx$.
4. **First application:** $du=2x\,dx$, $v=e^x$.
5. Compute the expression at this stage:

$$
\int x^2 e^x\,dx = x^2e^x - \int 2xe^x\,dx
$$
6. **Second application** on $\int 2xe^x\,dx$: let $u=2x$, $dv=e^x\,dx$, $du=2\,dx$, $v=e^x$.
7. Compute the expression at this stage:

$$
\int 2xe^x\,dx = 2xe^x - \int 2e^x\,dx = 2xe^x - 2e^x
$$
8. **Combine:**
9. Compute the expression at this stage:

$$
\int x^2e^x\,dx = x^2e^x - (2xe^x-2e^x) + C = e^x(x^2-2x+2)+C
$$
10. **Verify by differentiating:** $\dfrac{d}{dx}[e^x(x^2-2x+2)] = e^x(x^2-2x+2)+e^x(2x-2) = e^x\cdot x^2\checkmark$
11. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-key
LIATE priority for $u$:

Logarithm → Inverse trig → Algebraic (polynomials) → Trig → Exponential. Pick the leftmost type as $u$ because it differentiates toward something simpler. Here: Algebraic $x^2$ comes before Exponential $e^x$.
:::
::::
:::::

:::::problem[Problem M.25 — IBP: Logarithm]{difficulty=challenge}
Compute $\displaystyle\int \ln x\,dx$.

::::solution[Solution]
**Answer:** $x\ln x-x+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Trick:** Write $\ln x = \ln x\cdot 1$.
3. Apply IBP with $u=\ln x$, $dv=dx$.
4. Compute the expression at this stage:

$$
du = \frac{1}{x}\,dx,\qquad v = x
$$
5. Compute the expression at this stage:

$$
\int\ln x\,dx = x\ln x - \int x\cdot\frac{1}{x}\,dx = x\ln x - \int 1\,dx = x\ln x - x + C
$$
6. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-connect
General rule:

Whenever you see $\ln$, $\arctan$, or $\arcsin$ alone in an integrand (no matching derivative nearby), write it as $f(x)\cdot 1$ and use IBP with the log/inverse-trig as $u$.
:::
::::
:::::

:::::problem[Problem M.26 — Trig Integral: Powers of Sine and Cosine]{difficulty=challenge}
Compute $\displaystyle\int \sin^3 x\cos^2 x\,dx$.

::::solution[Solution]
**Answer:** $-\cos^3x/3+\cos^5x/5+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Strategy: odd power of sin.** Peel off one $\sin x$ to use with $dx$, convert remaining $\sin^2 x = 1-\cos^2 x$.
3. Compute the expression at this stage:

$$
\int\sin^3 x\cos^2 x\,dx = \int\sin^2 x\cos^2 x\cdot\sin x\,dx = \int(1-\cos^2x)\cos^2x\cdot\sin x\,dx
$$
4. **Substitute $u=\cos x$, $du=-\sin x\,dx$:**
5. Compute the expression at this stage:

$$
= -\int(1-u^2)u^2\,du = -\int(u^2-u^4)\,du = -\frac{u^3}{3}+\frac{u^5}{5}+C
$$
6. Compute the expression at this stage:

$$
= -\frac{\cos^3x}{3}+\frac{\cos^5x}{5}+C
$$
7. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-key
Rules for $\int\sin^m x\cos^n x\,dx$:

• Odd power of sin: peel one sin, sub $u=\cos x$.

• Odd power of cos: peel one cos, sub $u=\sin x$.

• Both even: use half-angle identities to reduce.
:::
::::
:::::

:::::problem[Problem M.27 — Trig Integral: Powers of Tangent and Secant]{difficulty=challenge}
Compute $\displaystyle\int\tan^2 x\sec^4 x\,dx$.

::::solution[Solution]
**Answer:** $\tan^3x/3+\tan^5x/5+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Strategy: even power of sec.** Peel off $\sec^2 x$ for $du$, convert remaining $\sec^2 x = 1+\tan^2 x$.
3. Compute the expression at this stage:

$$
\int\tan^2 x\sec^4 x\,dx = \int\tan^2 x\sec^2 x\cdot\sec^2 x\,dx = \int\tan^2 x(1+\tan^2 x)\sec^2 x\,dx
$$
4. **Sub $u=\tan x$, $du=\sec^2x\,dx$:**
5. Compute the expression at this stage:

$$
= \int u^2(1+u^2)\,du = \int(u^2+u^4)\,du = \frac{u^3}{3}+\frac{u^5}{5}+C = \frac{\tan^3x}{3}+\frac{\tan^5x}{5}+C
$$
6. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.
::::
:::::

:::::problem[Problem M.28 — Partial Fractions: Distinct Linear Factors]{difficulty=challenge}
Compute $\displaystyle\int\frac{2x+3}{x^2-x-2}\,dx$.

::::solution[Solution]
**Answer:** $(7/3)\ln|x-2|-(1/3)\ln|x+1|+C$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. **Step 1 — Factor the denominator.** $x^2-x-2=(x-2)(x+1)$.
3. Partial fraction decomposition.
4. Compute the expression at this stage:

$$
\frac{2x+3}{(x-2)(x+1)} = \frac{A}{x-2}+\frac{B}{x+1}
$$
5. Compute the expression at this stage:

$$
2x+3 = A(x+1)+B(x-2)
$$
6. Set $x=2$: $7=3A\Rightarrow A=7/3$.
7. Set $x=-1$: $1=-3B\Rightarrow B=-1/3$.
8. Integrate.
9. Compute the expression at this stage:

$$
\int\frac{2x+3}{x^2-x-2}\,dx = \frac{7}{3}\ln|x-2|-\frac{1}{3}\ln|x+1|+C = \frac{1}{3}\ln\!\left|\frac{(x-2)^7}{x+1}\right|+C
$$
10. Check: put the terms over one common denominator to recover the starting rational expression.

:::callout-key
Partial fractions procedure:

(1) Check degree — if improper, do long division first. (2) Factor denominator. (3) Write decomposition with undetermined numerators. (4) Clear denominators and solve by plugging in roots. (5) Integrate each piece.
:::
::::
:::::

:::::problem[Problem M.29 — Partial Fractions: Repeated and Quadratic Factors]{difficulty=challenge}
Compute $\displaystyle\int\frac{x^2+1}{x(x-1)^2}\,dx$.

::::solution[Solution]
**Answer:** $\ln|x|-2/(x-1)+C$

1. Factor the denominator and use the proper partial-fraction template; clear denominators before solving coefficients.
2. **Decomposition form.** Repeated linear factor $(x-1)^2$ needs two terms:

$$
\frac{x^2+1}{x(x-1)^2} = \frac{A}{x}+\frac{B}{x-1}+\frac{C}{(x-1)^2}
$$
3. Compute the expression at this stage:

$$
x^2+1 = A(x-1)^2 + Bx(x-1)+Cx
$$
4. Set $x=0$: $1=A$.
5. Set $x=1$: $2=C$.
6. Expand and match $x^2$ coefficient: $1 = A+B\Rightarrow B=0$.
7. Compute the expression at this stage:

$$
\frac{x^2+1}{x(x-1)^2} = \frac{1}{x}+\frac{2}{(x-1)^2}
$$
8. **Integrate:**
9. Compute the expression at this stage:

$$
\int\frac{x^2+1}{x(x-1)^2}\,dx = \ln|x| - \frac{2}{x-1}+C
$$
10. Check: put the terms over one common denominator to recover the starting rational expression.

:::callout-pitfall
Repeated factor rule:

$(x-a)^n$ in the denominator requires terms $\dfrac{A_1}{x-a}+\dfrac{A_2}{(x-a)^2}+\cdots+\dfrac{A_n}{(x-a)^n}$. Missing any term gives a wrong decomposition.
:::
::::
:::::

:::::problem[Problem M.30 — Trig Substitution]{difficulty=challenge}
Compute $\displaystyle\int\frac{dx}{\sqrt{9-x^2}}$ using trig substitution, and verify using the inverse sine formula.

::::solution[Solution]
**Answer:** $\arcsin(x/3)+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Pattern:** $\sqrt{a^2-x^2}$ suggests $x=a\sin\theta$.
3. Here $a=3$, so let $x=3\sin\theta$, $dx=3\cos\theta\,d\theta$.
4. Compute the expression at this stage:

$$
\sqrt{9-x^2} = \sqrt{9-9\sin^2\theta} = 3\sqrt{1-\sin^2\theta} = 3\cos\theta
$$
5. (assume $\cos\theta>0$ on $-\pi/2<\theta<\pi/2$)
6. Compute the expression at this stage:

$$
\int\frac{3\cos\theta\,d\theta}{3\cos\theta} = \int d\theta = \theta+C = \arcsin\!\left(\frac{x}{3}\right)+C
$$
7. **Verification:** $\dfrac{d}{dx}\arcsin(x/3) = \dfrac{1/3}{\sqrt{1-x^2/9}} = \dfrac{1}{\sqrt{9-x^2}}\checkmark$
8. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-key
Three trig-sub patterns:

$\sqrt{a^2-x^2}$ → $x=a\sin\theta$;
  $\sqrt{a^2+x^2}$ → $x=a\tan\theta$;
  $\sqrt{x^2-a^2}$ → $x=a\sec\theta$.
:::
::::
:::::

:::::problem[Problem M.31 — IBP + Cyclic Trick]{difficulty=challenge}
Compute $\displaystyle\int e^x\cos x\,dx$.

::::solution[Solution]
**Answer:** $e^x(\sin x+\cos x)/2+C$

1. Choose an antiderivative method from the integrand and write the substitution or integration-by-parts factors before integrating.
2. **Apply IBP twice — the integral will reappear.**
3. **First IBP:** $u=e^x$, $dv=\cos x\,dx$, $v=\sin x$, $du=e^x\,dx$.
4. Compute the expression at this stage:

$$
\int e^x\cos x\,dx = e^x\sin x - \int e^x\sin x\,dx
$$
5. **Second IBP** on $\int e^x\sin x\,dx$: $u=e^x$, $dv=\sin x\,dx$, $v=-\cos x$.
6. Compute the expression at this stage:

$$
\int e^x\sin x\,dx = -e^x\cos x + \int e^x\cos x\,dx
$$
7. **Substitute back:**
8. Compute the expression at this stage:

$$
\int e^x\cos x\,dx = e^x\sin x - \left(-e^x\cos x+\int e^x\cos x\,dx\right)
$$
9. Compute the expression at this stage:

$$
\int e^x\cos x\,dx = e^x\sin x + e^x\cos x - \int e^x\cos x\,dx
$$
10. Compute the expression at this stage:

$$
2\int e^x\cos x\,dx = e^x(\sin x+\cos x)
$$
11. Compute the expression at this stage:

$$
\int e^x\cos x\,dx = \frac{e^x(\sin x+\cos x)}{2}+C
$$
12. Check: differentiate the antiderivative to recover the original integrand, or evaluate both endpoints for a definite integral.

:::callout-intuition
The cyclic trick:

When two IBPs return the original integral, add it to both sides and solve algebraically. This works whenever the two functions "cycle" under differentiation (like $e^x$ and sin/cos).
:::
::::
:::::

:::::problem[Problem M.32 — Logarithmic Differentiation]{difficulty=challenge}
Differentiate $y = x^{\sin x}$ ($x>0$).

::::solution[Solution]
**Answer:** $x^{\sin x}(\cos x\ln x+\sin x/x)$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Take $\ln$ of both sides.
3. Compute the expression at this stage:

$$
\ln y = \sin x\cdot\ln x
$$
4. Differentiate implicitly with respect to $x$.
5. Compute the expression at this stage:

$$
\frac{1}{y}\cdot\frac{dy}{dx} = \cos x\cdot\ln x + \sin x\cdot\frac{1}{x}
$$
6. Solve for $dy/dx$.
7. Compute the expression at this stage:

$$
\frac{dy}{dx} = y\left(\cos x\ln x+\frac{\sin x}{x}\right) = x^{\sin x}\left(\cos x\ln x+\frac{\sin x}{x}\right)
$$
8. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-key
Logarithmic differentiation is required

whenever the variable appears in both the base and the exponent. The formula $d/dx[x^n]=nx^{n-1}$ only works for constant exponents; $d/dx[a^x]=a^x\ln a$ only for constant bases.
:::
::::
:::::

:::::problem[Problem M.33 — Fundamental Theorem of Calculus Part 1]{difficulty=challenge}
Find $\dfrac{d}{dx}\displaystyle\int_x^{x^2}\sin(t^2)\,dt$.

::::solution[Solution]
**Answer:** $2x\sin(x^4)-\sin(x^2)$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. Split using a constant, say $a=0$.
3. Compute the expression at this stage:

$$
\int_x^{x^2}\sin(t^2)\,dt = \int_0^{x^2}\sin(t^2)\,dt - \int_0^{x}\sin(t^2)\,dt
$$
4. Apply FTC Part 1 with the Chain Rule to each piece.
5. For $\displaystyle\int_0^{x^2}\sin(t^2)\,dt$: upper limit is $x^2$, so by FTC+chain rule:

$$
\frac{d}{dx}\int_0^{x^2}\sin(t^2)\,dt = \sin((x^2)^2)\cdot(x^2)' = \sin(x^4)\cdot 2x
$$
6. For $\displaystyle\int_0^{x}\sin(t^2)\,dt$: upper limit is $x$, so:

$$
\frac{d}{dx}\int_0^{x}\sin(t^2)\,dt = \sin(x^2)
$$
7. Combine.
8. Compute the expression at this stage:

$$
\frac{d}{dx}\int_x^{x^2}\sin(t^2)\,dt = 2x\sin(x^4) - \sin(x^2)
$$
9. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-key
FTC Part 1 with chain rule:

$\dfrac{d}{dx}\displaystyle\int_a^{g(x)}f(t)\,dt = f(g(x))\cdot g'(x)$. The "plugging in the upper limit" step always requires multiplying by the derivative of that limit.
:::
::::
:::::

:::::problem[Problem M.34 — Full Review: Chain Rule + Trig + Integration]{difficulty=challenge}
Let $F(x)=\displaystyle\int_1^{x^3}\frac{\ln t}{1+t^2}\,dt$. Find $F'(x)$ and determine the sign of $F'(2)$.

::::solution[Solution]
**Answer:** $F\'(x)=9x^2\ln x/(1+x^6)$; $F\'(2)=36\ln2/65>0$

1. Differentiate the given function rule by rule, keeping product, quotient, and chain-rule factors visible.
2. **Step 1 — Apply FTC Part 1 with chain rule.** The upper limit is $g(x)=x^3$, so:

$$
F'(x) = \frac{\ln(x^3)}{1+(x^3)^2}\cdot(x^3)' = \frac{3\ln x}{1+x^6}\cdot 3x^2 = \frac{9x^2\ln x}{1+x^6}
$$
3. (Used $\ln(x^3)=3\ln x$.)
4. Sign of $F'(2)$.
5. Compute the expression at this stage:

$$
F'(2)=\frac{9\cdot4\cdot\ln 2}{1+64} = \frac{36\ln 2}{65}
$$
6. Since $\ln 2 > 0$, we have $F'(2)>0$.
7. Therefore $F$ is increasing at $x=2$.
8. Check: each displayed factor comes from differentiating the corresponding factor or composition in the original function.

:::callout-connect
Interpretation:

$F(x)$ accumulates area under $\ln t/(1+t^2)$ from $t=1$ to $t=x^3$. Since the integrand is positive for $t>1$, and the upper limit $x^3$ is increasing for $x>0$, the accumulated area grows — $F$ is increasing. The derivative formula confirms this rigorously.
:::
::::
:::::
