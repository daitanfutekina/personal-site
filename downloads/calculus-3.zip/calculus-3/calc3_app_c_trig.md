---
title: "Appendix C — Trig Identities Reference"
source: "markdown"
---

MA 2733 Calculus III · Print-friendly · Thomas 15e reference · Test 1 polar / Test 3 basic identity

## Pythagorean Identities

| Identity | Alternate forms |
| --- | --- |
| Primary | $\sin^2\theta+\cos^2\theta=1$ |
| Tangent form | $\tan^2\theta+1=\sec^2\theta$ |
| Cotangent form | $1+\cot^2\theta=\csc^2\theta$ |

## Double-Angle Formulas

| Function | Formula |
| --- | --- |
| $\sin 2\theta$ | $2\sin\theta\cos\theta$ |
| $\cos 2\theta$ (three forms) | $\cos^2\theta-\sin^2\theta=1-2\sin^2\theta=2\cos^2\theta-1$ |
| $\tan 2\theta$ | $\dfrac{2\tan\theta}{1-\tan^2\theta}$ |

## Half-Angle / Power-Reduction Formulas

The power-reduction identities matter for polar-area integrals on Test 1. The **only** trig identity Young specifies on Test 3 is $\sin^2t+\cos^2t=1$.

| Function | Formula |
| --- | --- |
| $\sin^2\theta$ | $\dfrac{1-\cos 2\theta}{2}$ |
| $\cos^2\theta$ | $\dfrac{1+\cos 2\theta}{2}$ |
| $\tan^2\theta$ | $\dfrac{1-\cos 2\theta}{1+\cos 2\theta}$ |
| $\sin(\theta/2)$ | $\pm\sqrt{\dfrac{1-\cos\theta}{2}}$ |
| $\cos(\theta/2)$ | $\pm\sqrt{\dfrac{1+\cos\theta}{2}}$ |

## Sum and Difference Formulas

| Function | Formula |
| --- | --- |
| $\sin(\alpha\pm\beta)$ | $\sin\alpha\cos\beta\pm\cos\alpha\sin\beta$ |
| $\cos(\alpha\pm\beta)$ | $\cos\alpha\cos\beta\mp\sin\alpha\sin\beta$ |
| $\tan(\alpha\pm\beta)$ | $\dfrac{\tan\alpha\pm\tan\beta}{1\mp\tan\alpha\tan\beta}$ |

## Product-to-Sum Formulas

| Product | Sum form |
| --- | --- |
| $\sin\alpha\cos\beta$ | $\tfrac{1}{2}[\sin(\alpha+\beta)+\sin(\alpha-\beta)]$ |
| $\sin\alpha\sin\beta$ | $\tfrac{1}{2}[\cos(\alpha-\beta)-\cos(\alpha+\beta)]$ |
| $\cos\alpha\cos\beta$ | $\tfrac{1}{2}[\cos(\alpha-\beta)+\cos(\alpha+\beta)]$ |

## Sum-to-Product Formulas

| Sum | Product form |
| --- | --- |
| $\sin\alpha+\sin\beta$ | $2\sin\!\left(\tfrac{\alpha+\beta}{2}\right)\cos\!\left(\tfrac{\alpha-\beta}{2}\right)$ |
| $\sin\alpha-\sin\beta$ | $2\cos\!\left(\tfrac{\alpha+\beta}{2}\right)\sin\!\left(\tfrac{\alpha-\beta}{2}\right)$ |
| $\cos\alpha+\cos\beta$ | $2\cos\!\left(\tfrac{\alpha+\beta}{2}\right)\cos\!\left(\tfrac{\alpha-\beta}{2}\right)$ |
| $\cos\alpha-\cos\beta$ | $-2\sin\!\left(\tfrac{\alpha+\beta}{2}\right)\sin\!\left(\tfrac{\alpha-\beta}{2}\right)$ |

## Unit Circle — Key Angles

The entries below are exact. For missing quadrant angles use the reference angle and quadrant signs. The full $0$ to $2\pi$ chart is useful on Test 1; for Test 3, focus on $\sin^2t+\cos^2t=1$.

$0°$

$\sin=0$

$\cos=1$

$\tan=0$

$30°=\tfrac{\pi}{6}$

$\sin=\tfrac{1}{2}$

$\cos=\tfrac{\sqrt{3}}{2}$

$\tan=\tfrac{1}{\sqrt{3}}$

$45°=\tfrac{\pi}{4}$

$\sin=\tfrac{\sqrt{2}}{2}$

$\cos=\tfrac{\sqrt{2}}{2}$

$\tan=1$

$60°=\tfrac{\pi}{3}$

$\sin=\tfrac{\sqrt{3}}{2}$

$\cos=\tfrac{1}{2}$

$\tan=\sqrt{3}$

$90°=\tfrac{\pi}{2}$

$\sin=1$

$\cos=0$

$\tan=\text{und.}$

$120°=\tfrac{2\pi}{3}$

$\sin=\tfrac{\sqrt{3}}{2}$

$\cos=-\tfrac{1}{2}$

$\tan=-\sqrt{3}$

$135°=\tfrac{3\pi}{4}$

$\sin=\tfrac{\sqrt{2}}{2}$

$\cos=-\tfrac{\sqrt{2}}{2}$

$\tan=-1$

$150°=\tfrac{5\pi}{6}$

$\sin=\tfrac{1}{2}$

$\cos=-\tfrac{\sqrt{3}}{2}$

$\tan=-\tfrac{1}{\sqrt{3}}$

$180°=\pi$

$\sin=0$

$\cos=-1$

$\tan=0$

$210°=\tfrac{7\pi}{6}$

$\sin=-\tfrac{1}{2}$

$\cos=-\tfrac{\sqrt{3}}{2}$

$\tan=\tfrac{1}{\sqrt{3}}$

$270°=\tfrac{3\pi}{2}$

$\sin=-1$

$\cos=0$

$\tan=\text{und.}$

$300°=\tfrac{5\pi}{3}$

$\sin=-\tfrac{\sqrt{3}}{2}$

$\cos=\tfrac{1}{2}$

$\tan=-\sqrt{3}$

$225°=\tfrac{5\pi}{4}$

$\sin=-\tfrac{\sqrt{2}}{2}$

$\cos=-\tfrac{\sqrt{2}}{2}$

$\tan=1$

$240°=\tfrac{4\pi}{3}$

$\sin=-\tfrac{\sqrt{3}}{2}$

$\cos=-\tfrac{1}{2}$

$\tan=\sqrt{3}$

$315°=\tfrac{7\pi}{4}$

$\sin=-\tfrac{\sqrt{2}}{2}$

$\cos=\tfrac{\sqrt{2}}{2}$

$\tan=-1$

$330°=\tfrac{11\pi}{6}$

$\sin=-\tfrac{1}{2}$

$\cos=\tfrac{\sqrt{3}}{2}$

$\tan=-\tfrac{1}{\sqrt{3}}$

$360°=2\pi$

$\sin=0$

$\cos=1$

$\tan=0$

## Derivatives of Trig Functions

| Function | Derivative |
| --- | --- |
| $\sin x$ | $\cos x$ |
| $\cos x$ | $-\sin x$ |
| $\tan x$ | $\sec^2 x$ |
| $\cot x$ | $-\csc^2 x$ |
| $\sec x$ | $\sec x\tan x$ |
| $\csc x$ | $-\csc x\cot x$ |
| $\arcsin x$ | $1/\sqrt{1-x^2}$ |
| $\arccos x$ | $-1/\sqrt{1-x^2}$ |
| $\arctan x$ | $1/(1+x^2)$ |

## Integrals of Trig Functions

| Integral | Result |
| --- | --- |
| $\int\sin x\,dx$ | $-\cos x+C$ |
| $\int\cos x\,dx$ | $\sin x+C$ |
| $\int\tan x\,dx$ | $\ln|\sec x|+C$ |
| $\int\sec x\,dx$ | $\ln|\sec x+\tan x|+C$ |
| $\int\sec^2 x\,dx$ | $\tan x+C$ |
| $\int\sec x\tan x\,dx$ | $\sec x+C$ |
| $\int\dfrac{dx}{\sqrt{a^2-x^2}}$, $a>0$, $|x|< a$ | $\arcsin(x/a)+C$ |
| $\int\dfrac{dx}{a^2+x^2}$, $a>0$ | $\tfrac{1}{a}\arctan(x/a)+C$ |
| $\int\dfrac{dx}{x\sqrt{x^2-a^2}}$, $a>0$, $|x|>a$ | $\tfrac{1}{a}\operatorname{arcsec}(|x|/a)+C$ (on each domain interval) |

## Trig Substitution Guide

| Integrand contains | Substitute | Identity used |
| --- | --- | --- |
| $\sqrt{a^2-x^2}$ | $x=a\sin\theta$ | $1-\sin^2\theta=\cos^2\theta$ |
| $\sqrt{a^2+x^2}$ | $x=a\tan\theta$ | $1+\tan^2\theta=\sec^2\theta$ |
| $\sqrt{x^2-a^2}$ | $x=a\sec\theta$ | $\sec^2\theta-1=\tan^2\theta$ |

Memory trick for trig sub:

Memorize the match: $a^2-x^2\to x=a\sin\theta$; $a^2+x^2\to x=a\tan\theta$; $x^2-a^2\to x=a\sec\theta$. Choose a trig interval that makes the radical and sign correct.


## Exact-Value and Polar Shortcuts

| Conversion | Use |
| --- | --- |
| $180°=\pi$ radians | $30°=\pi/6$, $45°=\pi/4$, $60°=\pi/3$ |
| $\sin(-x)=-\sin x$, $\cos(-x)=\cos x$ | Odd/even simplification |
| $\sin(\pi-x)=\sin x$, $\cos(\pi-x)=-\cos x$ | Second-quadrant angles |
| $\sin(x+2\pi)=\sin x$, $\cos(x+2\pi)=\cos x$ | Periodic endpoints |
| $\int_0^{2\pi}\sin^2\theta\,d\theta=\pi$ | Polar area after power reduction |
| $\int_0^{2\pi}\cos^2\theta\,d\theta=\pi$ | Polar area after power reduction |
| $\int_0^{2\pi}\sin\theta\cos\theta\,d\theta=0$ | Periodic cancellation |

:::callout-pitfall[Domain and sign]
$\tan\theta=\sin\theta/\cos\theta$ is undefined when $\cos\theta=0$. Trig-sub radicals use $\sqrt{\cos^2\theta}=|\cos\theta|$, **not automatically** $\cos\theta$; justify the branch restriction. The $\pm$ in half-angle formulas depends on the quadrant of the half-angle.
:::
