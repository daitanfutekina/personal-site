---
title: "Appendix B — Master Formula Sheet"
source: "markdown"
---

MA 2733 Calculus III · Thomas 15e §§10–13 · Tests 1–4 and final · Hand-computation reference

## Ch. 0 — Prerequisites

| Formula | Expression |
| --- | --- |
| Power rule | $\dfrac{d}{dx}x^n=nx^{n-1}$ |
| Chain rule | $\dfrac{d}{dx}f(g(x))=f'(g(x))\cdot g'(x)$ |
| Trig derivatives | $(\sin x)'=\cos x,\;(\cos x)'=-\sin x$ |
| $\tan,\sec$ | $(\tan x)'=\sec^2 x,\;(\sec x)'=\sec x\tan x$ |
| Inverse trig | $(\arcsin x)'=\dfrac{1}{\sqrt{1-x^2}},\;(\arctan x)'=\dfrac{1}{1+x^2}$ |
| Exp / log | $(e^x)'=e^x,\;(\ln x)'=1/x$ |
| L'Hôpital | If $\lim f/g$ is $0/0$ or $\infty/\infty$ and the derivative-ratio limit exists, $\lim f/g=\lim f'/g'$ |
| Substitution | If $u=g(x)$, $du=g'(x)\,dx$; for definite integrals, change both bounds |
| Improper integral | $\int_a^\infty f=\lim_{b\to\infty}\int_a^b f$; if $f$ blows up at $a$, use $\lim_{c\to a^+}\int_c^b f$ |
| Factorial | $0!=1$, $(n+1)!=(n+1)n!$ |
| Partial fractions | Split each distinct linear factor $x-a$, each power $(x-a)^j$, and use $(Ax+B)$ over an irreducible quadratic |
| FTC Part 2 | $\displaystyle\int_a^b f(x)\,dx=F(b)-F(a)$ |
| Integration by parts | $\displaystyle\int u\,dv=uv-\int v\,du$ |

## Ch. 1 — Parametric & Polar

| Formula | Expression |
| --- | --- |
| Parametric tangent line | $\mathbf r(t_0)+s\mathbf r'(t_0)$; in 3D use $x=x_0+v_1s,\ y=y_0+v_2s,\ z=z_0+v_3s$ |
| Parametric area under curve | $\displaystyle A=\int_a^b y(t)x'(t)\,dt$ (signed; check orientation and regions) |
| Parametric slope | $\dfrac{dy}{dx}=\dfrac{dy/dt}{dx/dt}$ |
| Parametric 2nd deriv. | $\dfrac{d^2y}{dx^2}=\dfrac{d(dy/dx)/dt}{dx/dt}$ |
| Parametric arc length | $\displaystyle L=\int_a^b\sqrt{\left(\tfrac{dx}{dt}\right)^2+\left(\tfrac{dy}{dt}\right)^2}\,dt$ |
| Polar to Cartesian | $x=r\cos\theta,\;y=r\sin\theta$ |
| Cartesian to polar | $r^2=x^2+y^2,\;\tan\theta=y/x$ |
| Polar slope | $\dfrac{dy}{dx}=\dfrac{r'(\theta)\sin\theta+r(\theta)\cos\theta}{r'(\theta)\cos\theta-r(\theta)\sin\theta}$ if the denominator is nonzero |
| Polar area between curves | $\displaystyle A=\frac12\int_\alpha^\beta(r_{\rm outer}^2-r_{\rm inner}^2)\,d\theta$ on a ray interval with correct outer/inner order |
| Polar area | $\displaystyle A=\frac{1}{2}\int_\alpha^\beta r^2\,d\theta$ |
| Polar arc length | $\displaystyle L=\int_\alpha^\beta\sqrt{r^2+\left(\tfrac{dr}{d\theta}\right)^2}\,d\theta$ |

## Ch. 2 — Infinite Series

| Formula / Test | Expression / Condition |
| --- | --- |
| Geometric series sum | $\displaystyle\sum_{n=0}^\infty ar^n=\dfrac{a}{1-r},\;|r|<1$ |
| p-Series | Conv. iff $p>1$ |
| Ratio Test | $L=\lim|a_{n+1}/a_n|$: $L<1$ conv., $L>1$ div. |
| Root Test | $L=\lim\sqrt[n]{|a_n|}$: same conclusions |
| Power series radius | $R=1/L$ if $L=\lim_{n\to\infty}|c_{n+1}/c_n|$ exists, with $R=\infty$ for $L=0$ and $R=0$ for $L=\infty$ |
| Taylor series | $\displaystyle\sum_{n=0}^\infty\dfrac{f^{(n)}(a)}{n!}(x-a)^n$; equals $f(x)$ only where the Taylor remainder approaches zero |
| Maclaurin: $e^x$ | $\displaystyle\sum_{n=0}^\infty\dfrac{x^n}{n!}$, all $x$ |
| Maclaurin: $\sin x$ | $\displaystyle\sum_{n=0}^\infty\dfrac{(-1)^n x^{2n+1}}{(2n+1)!}$, all $x$ |
| Maclaurin: $\cos x$ | $\displaystyle\sum_{n=0}^\infty\dfrac{(-1)^n x^{2n}}{(2n)!}$, all $x$ |
| Maclaurin: $\ln(1+x)$ | $\displaystyle\sum_{n=1}^\infty\dfrac{(-1)^{n-1}x^n}{n}$, $-1< x\le1$ |
| Maclaurin: $\arctan x$ | $\displaystyle\sum_{n=0}^\infty\dfrac{(-1)^n x^{2n+1}}{2n+1}$, $|x|\le1$ |
| Maclaurin: $(1+x)^k$ | $\displaystyle\sum_{n=0}^\infty\binom{k}{n}x^n$, $|x|<1$ |
| Taylor remainder (not on Test 4) | $|R_n(x)|\le\dfrac{M|x-a|^{n+1}}{(n+1)!}$ if $|f^{(n+1)}|\le M$ on the interval between $a$ and $x$ |
| AST error bound (not on Test 4) | $|S-S_n|\le b_{n+1}$ provided AST hypotheses hold |

**Test 4, Thomas 10.1–10.8:**

| Formula or decision | Exact statement |
| --- | --- |
| nth-term divergence | If $\lim a_n\ne0$ or does not exist, $\sum a_n$ diverges; $\lim a_n=0$ is inconclusive |
| Integral Test | $f(n)=a_n$; $f$ eventually continuous, positive, decreasing; $\sum a_n$ and $\int f$ have matching convergence behavior |
| Direct Comparison | $0\le a_n\le b_n$, $\sum b_n$ convergent $\Rightarrow\sum a_n$ convergent; reverse for divergence with a smaller divergent series |
| Limit Comparison | $a_n,b_n>0$ eventually; $0<\lim a_n/b_n<\infty$ means same behavior |
| AST | Signs alternate; $b_n\ge0$ eventually decreases; $b_n\to0$; then converges. To classify, check $\sum|a_n|$ separately |
| Radius and interval | Ratio/Root on $\sum c_n(x-a)^n$; check each endpoint; include $R=0$ or $\infty$ cases |
| Taylor polynomial | $\displaystyle P_m(x)=\sum_{k=0}^{m}\frac{f^{(k)}(a)}{k!}(x-a)^k$, especially $m=0,1,2,3$ |
| Taylor coefficients | $P_0=f(a)$; $P_1=P_0+f'(a)(x-a)$; $P_2=P_1+f''(a)(x-a)^2/2$; $P_3=P_2+f^{(3)}(a)(x-a)^3/6$ |

**Interval of convergence:** always test endpoints separately after finding $R$. **Not on Test 4:** telescoping, Taylor remainder/error, function representations from §§10.9–10.10.

## Ch. 3 — Vectors & Geometry

| Formula | Expression |
| --- | --- |
| 3D distance | $\sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}$ |
| Magnitude | $|\vec{v}|=\sqrt{v_1^2+v_2^2+v_3^2}$ |
| Dot product | $\vec{a}\cdot\vec{b}=a_1b_1+a_2b_2+a_3b_3=|\vec{a}||\vec{b}|\cos\theta$ |
| Angle formula | $\theta=\arccos\!\left(\dfrac{\vec{a}\cdot\vec{b}}{|\vec{a}||\vec{b}|}\right)$ |
| Vector projection | $\operatorname{proj}_{\vec{b}}\vec{a}=\dfrac{\vec{a}\cdot\vec{b}}{|\vec{b}|^2}\vec{b}$ |
| Scalar projection | $\operatorname{comp}_{\vec{b}}\vec{a}=\dfrac{\vec{a}\cdot\vec{b}}{|\vec{b}|}$ |
| Cross product | $\vec{a}\times\vec{b}=\det\begin{pmatrix}\hat{\imath}&\hat{\jmath}&\hat{k}\\a_1&a_2&a_3\\b_1&b_2&b_3\end{pmatrix}$ |
| $|\vec{a}\times\vec{b}|$ | $|\vec{a}||\vec{b}|\sin\theta$ = parallelogram area |
| Parallelepiped vol. | $V=|\vec{a}\cdot(\vec{b}\times\vec{c})|$ |
| Line (parametric) | $x=x_0+at,\;y=y_0+bt,\;z=z_0+ct$ |
| Plane through 3 points | $\mathbf n=(B-A)\times(C-A)$, then $\mathbf n\cdot((x,y,z)-A)=0$ |
| Parallel or perpendicular | $\mathbf a\cdot\mathbf b=0$ means perpendicular; $\mathbf a\times\mathbf b=\mathbf0$ means parallel (nonzero vectors) |
| Angle between planes | Acute angle between their normals: $\cos\theta=|\mathbf n_1\cdot\mathbf n_2|/(|\mathbf n_1||\mathbf n_2|)$ |
| Point-to-line vector | $\overrightarrow{PQ}=\langle x_Q-x_P,y_Q-y_P,z_Q-z_P\rangle$ |
| Plane equation | $a(x-x_0)+b(y-y_0)+c(z-z_0)=0$ |
| Point-to-plane dist. | $D=\dfrac{|ax_1+by_1+cz_1-d|}{\sqrt{a^2+b^2+c^2}}$ |

## Ch. 4 — Vector-Valued Functions

| Formula | Expression |
| --- | --- |
| Derivative | $\vec{r}\,'=\langle f',g',h'\rangle$ |
| Integral | $\displaystyle\int\vec{r}\,dt=\left\langle\int f,\int g,\int h\right\rangle+\vec{C}$ |
| Arc length | $L=\displaystyle\int_a^b|\vec{r}\,'(t)|\,dt$ |
| Vector limit | $\displaystyle\lim_{t\to a}\mathbf r(t)=\langle\lim f(t),\lim g(t),\lim h(t)\rangle$ if component limits exist |
| Tangent line | $\mathbf r(t_0)+s\mathbf r'(t_0)$ |
| Unit tangent | $\hat{T}=\vec{r}\,'/|\vec{r}\,'|$ |
| Curvature | $\kappa=\dfrac{|\vec{r}\,'\times\vec{r}\,''|}{|\vec{r}\,'|^3}=\dfrac{|\hat{T}'|}{|\vec{r}\,'|}$ |
| Plane curvature | $\kappa=\dfrac{|f''|}{(1+f'^2)^{3/2}}$ |
| Unit normal | $\hat{N}=\hat{T}'/|\hat{T}'|$ |
| Binormal | $\hat{B}=\hat{T}\times\hat{N}$ |
| Velocity / accel. | $\vec{v}=\vec{r}\,',\;\vec{a}=\vec{r}\,'',\;\text{speed}=|\vec{v}|$ |
| Tangential accel. | $a_T=\vec{a}\cdot\vec{v}/|\vec{v}|=d|\vec{v}|/dt$ |
| Normal accel. | $a_N=\kappa|\vec{v}|^2=|\vec{v}\times\vec{a}|/|\vec{v}|$ |
| IVP reconstruction | $\mathbf v(t)=\int\mathbf a(t)\,dt+\mathbf C$; $\mathbf r(t)=\int\mathbf v(t)\,dt+\mathbf D$, use initial conditions after each integral |
| Direction | $\mathbf v(t_0)/|\mathbf v(t_0)|$; velocity = speed $\times$ direction |
| Projectile position | $\vec{r}(t)=\vec{r}_0+\vec{v}_0 t-\tfrac{1}{2}gt^2\hat{k}$ |
| Range (level launch/landing) | $R=v_0^2\sin(2\theta)/g$ (max at $\theta=45°$); not valid for unequal heights |
| Rise above launch height | $H=v_0^2\sin^2\theta/(2g)$ for constant downward gravity, $g>0$ |
