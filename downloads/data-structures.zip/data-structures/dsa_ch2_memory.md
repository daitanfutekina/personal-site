---
title: "Memory & Computation"
crumb: "Honors DSA · Chapter 2"
meta:
  - "Est. study time: ~60 min"
  - "Unit 0 — Foundations"
  - "CSE 2383 · MSState"
source: "dsa_ch2_memory.html"
---

## Overview

Before you can reason about whether a data structure is *fast*, you need a concrete mental model of what "fast" even means on real hardware. This chapter builds that model: how a running C++ program is laid out in memory, what the call stack actually does during a function call, how the heap is managed, and why memory access patterns (cache locality) can matter more than algorithmic complexity for real-world performance.

:::callout-key[Prerequisites]
- Chapter 1: pointers, `new`/`delete`, stack vs. heap vocabulary
- Basic understanding of functions and recursion
:::

## 1. Program Memory Layout

:::callout-intuition[Intuition]
When the OS launches your C++ program, it carves out a chunk of virtual memory and slices it into regions, each with a different job. Understanding these regions explains why local variables disappear when a function returns, why global variables persist, and why heap memory must be manually freed.
:::

:::definition[Definition 1.1 — Program Memory Segments]
A running C++ process has (at minimum) four memory regions:

- **Text (code) segment** — the compiled machine instructions. Read-only.
- **Data segment** — global and static variables. Subdivided into initialized (`.data`) and zero-initialized (`.bss`).
- **Stack** — local variables, function parameters, return addresses. Grows downward. Managed automatically.
- **Heap** — dynamically allocated memory (`new`/`delete`). Grows upward. Managed manually.
:::

```
High address  ┌─────────────────────────────┐
              │  Command-line args / env     │
              ├─────────────────────────────┤
              │         STACK               │  ← grows downward ↓
              │    (local vars, frames)      │
              │                             │
              │        (free space)          │
              │                             │
              │         HEAP                │  ← grows upward ↑
              │   (new / malloc memory)      │
              ├─────────────────────────────┤
              │   BSS  (uninit globals)      │
              ├─────────────────────────────┤
              │   Data (init globals/static) │
              ├─────────────────────────────┤
Low address   │   Text (machine code)        │
              └─────────────────────────────┘

```

```cpp
int  globalVar  = 42;          // Data segment (initialized)
int  zeroed;                   // BSS segment  (zero-initialized)
static int s = 7;              // Data segment

void foo() {
    int local = 10;            // Stack
    int* p = new int(99);      // p on stack; *p on heap
    delete p;
}
```

### Practice problems

:::problem[Problem 1.1 easy]{difficulty="easy"}
For each variable, name which memory segment it lives in:

 (a) `int x = 5;` inside `main()`

 (b) `static int count = 0;` inside a function

 (c) `int* p = new int(3);` — where does `p` live? Where does `*p` live?

 (d) `const char* msg = "hello";` — where is the string literal?

::::solution[Solution]
(a) **Stack** — local variable inside a function.

 (b) **Data segment** — static variables persist across calls even inside functions.

 (c) `p` (the pointer itself) is on the **stack**; `*p` (the int value 3) is on the **heap**.

 (d) The string literal `"hello"` is in the **text/rodata segment** (read-only); `msg` (the pointer) is on the stack.
::::
:::

:::problem[Problem 1.2 standard]{difficulty="standard"}
Why does the stack grow downward while the heap grows upward? What happens if they collide?

::::solution[Solution]
Growing in opposite directions maximizes the shared free space between them — neither region needs a fixed upper bound set at program start. If the stack and heap grow into each other (stack overflow or heap exhaustion), the OS kills the process with a segmentation fault or out-of-memory error. In practice, the OS enforces a maximum stack size (typically 1–8 MB) long before physical collision.
::::
:::

:::problem[Problem 1.3 standard]{difficulty="standard"}
A student writes a recursive function with no base case. Which segment runs out first? Why?

::::solution[Solution]
The **stack** overflows. Each recursive call pushes a new stack frame (local variables + return address). With no base case, frames accumulate without ever being popped. The OS enforces a fixed stack size limit (e.g., 8 MB on Linux), so a deep enough recursion triggers a stack overflow / segfault — even if there is plenty of heap memory available.
::::
:::

## 2. The Call Stack in Detail

:::callout-intuition[Intuition]
Every function call is a conversation between the caller and the callee, conducted through a *stack frame*. The frame holds the local variables, parameters, and the return address — where execution should resume when the function finishes. Because frames are pushed and popped in LIFO order, recursion works naturally: each recursive call gets its own isolated set of local variables.
:::

:::definition[Definition 2.1 — Stack Frame (Activation Record)]
A **stack frame** is the region of the stack allocated for a single function call. It contains: the function's local variables, the values of its parameters, the saved return address (where to go when the function returns), and the saved frame pointer (to restore the caller's frame).
:::

### Worked examples

:::example[Example 2.1 — Tracing stack frames through recursion]
Trace the call stack when `factorial(3)` is called. Show which frames exist at the deepest point.

::::answer[Answer]
At the deepest point (base case `factorial(0)`), there are 4 frames on the stack simultaneously.
::::

Work

```cpp
int factorial(int n) {
    if (n == 0) return 1;          // base case
    return n * factorial(n - 1);   // recursive call
}
```

```
Call sequence:  main → factorial(3) → factorial(2) → factorial(1) → factorial(0)

Stack (top = most recent frame):
┌──────────────────────────────────┐  ← TOP of stack (most recent)
│  factorial(0): n=0               │  returns 1
├──────────────────────────────────┤
│  factorial(1): n=1               │  waiting for factorial(0) to return
├──────────────────────────────────┤
│  factorial(2): n=2               │  waiting for factorial(1)
├──────────────────────────────────┤
│  factorial(3): n=3               │  waiting for factorial(2)
├──────────────────────────────────┤
│  main()                          │  waiting for factorial(3)
└──────────────────────────────────┘  ← BOTTOM of stack

```

As each call returns, its frame is popped and execution resumes in the frame below. The returned value propagates: 1 → 1×1=1 → 2×1=2 → 3×2=6 → `main` receives 6.
:::

:::example[Example 2.2 — Why pass-by-value copies live on the stack]
Explain why modifying a pass-by-value parameter inside a function doesn't affect the caller.

::::answer[Answer]
The copy lives in the callee's stack frame — a completely separate memory location from the caller's variable.
::::

Work

```
void double_it(int x) { x = x * 2; }   // x is in double_it's frame
int main() {
    int n = 5;    // n is in main's frame
    double_it(n); // a COPY of n is pushed into double_it's frame
    // n is still 5 — only the copy changed
}

Stack at moment double_it runs:
┌─────────────────────┐
│  double_it: x = 5   │  ← copy; changing x has no effect on n
├─────────────────────┤
│  main:      n = 5   │  ← original; untouched
└─────────────────────┘

```
:::

### Practice problems

:::problem[Problem 2.1 easy]{difficulty="easy"}
How many stack frames exist at the deepest point when computing `fibonacci(4)` using the naive recursive implementation (no memoization)?

::::solution[Solution]
**5 frames**: main → fib(4) → fib(3) → fib(2) → fib(1). The depth equals `n+1` for the deepest chain (always going left: fib(n-1)). Plus main = `n+1` frames total from fib calls = depth 4+1 = 5 including main.
::::
:::

:::problem[Problem 2.2 standard]{difficulty="standard"}
A linked-list traversal can be written recursively or iteratively. The iterative version uses a `Node* cur` pointer on the stack. The recursive version creates a new stack frame per node. For a list of 10,000 nodes, which is safer and why?

::::solution[Solution]
The **iterative** version is safer. It uses O(1) stack space (one pointer, one loop). The recursive version pushes 10,000 frames, which may exceed the default stack limit (~8 MB on Linux, ~1 MB on Windows). Each frame holds at minimum a return address + parameter — even at 64 bytes each, 10,000 frames = 640 KB, which can trigger a stack overflow. For data structures, always prefer iteration over recursion unless the depth is guaranteed small (like tree height in a balanced tree, which is O(log n)).
::::
:::

:::problem[Problem 2.3 challenge]{difficulty="challenge"}
Explain what a *tail call* is and why some compilers can optimize tail-recursive functions to use O(1) stack space.

::::solution[Solution]
A **tail call** is a function call that is the very last action in a function — the caller does nothing with the return value except return it directly. Example: `return factorial_tail(n-1, n * acc);` is a tail call; `return n * factorial(n-1);` is not (the multiplication happens after the recursive call returns).

In a tail call, the compiler notices that the current frame will never be needed again after the call. Instead of pushing a new frame, it can *reuse* the current frame — effectively converting the recursion into a loop. This is **tail call optimization (TCO)**. GCC and Clang perform TCO at higher optimization levels. C++ does not guarantee it in the standard, but it is common in practice.
::::
:::

## 3. Heap Internals

:::callout-intuition[Intuition]
The heap isn't magic — it's a large block of memory managed by an allocator (like `ptmalloc` or `jemalloc`). When you call `new`, the allocator finds a free chunk big enough for your request, marks it as used, and returns a pointer. When you call `delete`, the chunk is returned to the free list. This management has real costs: allocation is not O(1) in general, and fragmentation can slow things down over time.
:::

### What `new` actually does

When you write `int* p = new int(5);`, the compiler generates roughly:

1. Call `operator new(sizeof(int))` — asks the allocator for 4 bytes.
2. The allocator searches its free list, marks the chunk as allocated, returns a pointer.
3. The integer is constructed (value 5 written) at that address.
4. `p` receives the address.

When you write `delete p;`:

1. The integer's destructor runs (trivial for `int`).
2. `operator delete(p)` is called — the allocator marks the chunk free and may merge it with adjacent free chunks (coalescing).

:::callout-warning[Fragmentation]
**External fragmentation**: many small free chunks scattered through the heap, making it impossible to satisfy a large allocation even if total free bytes would be enough. **Internal fragmentation**: allocated chunk is larger than requested (due to alignment or minimum-block-size rules), wasting memory inside the chunk. Both are managed by the allocator but cannot be eliminated entirely.
:::

### Practice problems

:::problem[Problem 3.1 easy]{difficulty="easy"}
True or false: calling `delete p` immediately returns the memory to the OS so other programs can use it.

::::solution[Solution]
**False.** `delete` returns the memory to the *allocator's free list*, not necessarily to the OS. The allocator keeps a pool of memory obtained from the OS (via `sbrk` or `mmap`). Individual `delete` calls just mark chunks as reusable within your process. The OS may reclaim them when the process exits or when the allocator decides to release large free regions.
::::
:::

:::problem[Problem 3.2 standard]{difficulty="standard"}
A program repeatedly allocates 16-byte blocks, uses them, then frees them, then allocates 1024-byte blocks. Why might the 1024-byte allocations fail even if total freed bytes exceed 1024?

::::solution[Solution]
This is **external fragmentation**. The heap contains many free 16-byte chunks scattered at non-contiguous addresses. A 1024-byte allocation requires a *contiguous* free region of at least 1024 bytes. Even if there are 100 free 16-byte blocks (1600 bytes total), the allocator cannot satisfy the 1024-byte request if no single contiguous region is large enough.
::::
:::

:::problem[Problem 3.3 challenge]{difficulty="challenge"}
Explain why a linked list (many small separate heap allocations) is often slower in practice than a `std::vector` (one large contiguous allocation) even when both have the same Big-O complexity for traversal.

::::solution[Solution]
The answer is **cache locality** (covered next section). Each linked-list node is a separate heap allocation at a (possibly) random address. Traversing the list forces the CPU to load a new cache line for each node — up to one cache miss per node. A `std::vector` stores all elements contiguously; the CPU loads a cache line holding multiple elements at once, so most accesses are cache hits. For a list of 1,000,000 elements, the linked list may incur 1,000,000 cache misses; the vector might incur only ~15,000 (at 64-byte cache lines holding 16 ints each).
::::
:::

## 4. Cache & Locality

:::callout-intuition[Intuition]
RAM is slow — accessing a value in RAM takes ~100 ns. The CPU runs at ~3 GHz — one cycle is ~0.3 ns. To bridge this gap, CPUs have a hierarchy of **caches** (L1, L2, L3) that are much smaller but much faster. The cache system is automatic: whenever you access a memory address, the CPU loads an entire **cache line** (typically 64 bytes) surrounding that address into cache. If the next access is nearby (within the same cache line), it's a *cache hit* — nearly free. If it's somewhere else in RAM, it's a *cache miss* — expensive. This is why data layout matters enormously.
:::

| Memory level | Typical size | Access latency | Relative speed |
| --- | --- | --- | --- |
| L1 cache | 32–64 KB | ~1 ns (4 cycles) | Fastest |
| L2 cache | 256 KB – 1 MB | ~4 ns (12 cycles) | Fast |
| L3 cache | 8–64 MB | ~30 ns (100 cycles) | Moderate |
| RAM (DRAM) | GBs | ~100 ns (300 cycles) | Slow |
| SSD | TBs | ~100 µs | Very slow |

:::definition[Definition 4.1 — Spatial and Temporal Locality]
**Spatial locality**: if a memory address is accessed, nearby addresses are likely to be accessed soon. Arrays have excellent spatial locality — sequential access walks through a contiguous block. **Temporal locality**: if an address is accessed, it is likely to be accessed again soon. Loop variables have excellent temporal locality — the same counter is used on every iteration.
:::

:::callout-connect[Why this matters for data structures]
Arrays and `std::vector` have excellent spatial locality — elements are contiguous. Linked lists, trees, and graphs (stored as pointer-linked nodes) have poor spatial locality — each node may be at a random heap address. In practice, a sorted array can outperform a BST for search even though both are O(log n), because the array's cache behavior is so much better.
:::

### Practice problems

:::problem[Problem 4.1 easy]{difficulty="easy"}
Which loop order is faster for iterating over a 2D array stored in row-major order (C++ default)? Justify your answer in terms of cache lines.

```cpp
// Option A: row-major (outer = row, inner = column)
for (int i = 0; i < N; i++)
    for (int j = 0; j < N; j++)
        sum += arr[i][j];

// Option B: column-major (outer = column, inner = row)
for (int j = 0; j < N; j++)
    for (int i = 0; i < N; i++)
        sum += arr[i][j];
```

::::solution[Solution]
**Option A is faster.** C++ stores 2D arrays in row-major order: `arr[0][0], arr[0][1], arr[0][2], ...` are contiguous in memory. Option A accesses them in this exact order — each cache line load gives several "free" future values (spatial locality). Option B jumps between rows on every inner iteration, accessing addresses `arr[0][j], arr[1][j], arr[2][j]...` which are N integers apart — a new cache line per access. For large N, Option B can be 5–50× slower due to cache thrashing.
::::
:::

:::problem[Problem 4.2 standard]{difficulty="standard"}
A cache line is 64 bytes. An `int` is 4 bytes. If you access `arr[0]` in a fresh cache, how many subsequent accesses to `arr[1]` through `arr[15]` will be cache hits?

::::solution[Solution]
**All 15 will be cache hits.** Accessing `arr[0]` loads a 64-byte cache line containing 16 consecutive integers (`arr[0]` through `arr[15]`). All subsequent sequential accesses to `arr[1]` through `arr[15]` find their data already in the L1 cache — no further RAM accesses needed.
::::
:::

:::problem[Problem 4.3 challenge]{difficulty="challenge"}
A `struct` has fields `int id`, `char[60] name`, `double salary`. You have an array of 1,000,000 such structs and want to sum all the `salary` fields. Propose a data layout change that would significantly improve cache performance for this query, and explain why.

::::solution[Solution]
The current layout is **Array of Structures (AoS)**: each struct is 72+ bytes, so accessing just `salary` loads 64-byte cache lines but uses only 8 bytes (the double) — ~11% efficiency. The other 56 bytes (mostly the name) are cache pollution for this query.

Switch to **Structure of Arrays (SoA)**:

```cpp
int    ids[1000000];
char   names[1000000][60];
double salaries[1000000];   // contiguous array of just the doubles
```

Now iterating `salaries[]` achieves ~100% cache utilization — every byte loaded is a salary being summed. This is a standard optimization in game engines, databases, and HPC code. The tradeoff: operations touching all fields of one record now have worse locality.
::::
:::

## 5. Measuring Computational Cost

:::callout-intuition[Intuition]
When we say an algorithm is "fast" or "slow," we need a precise vocabulary. We don't care about the exact number of CPU cycles — that varies by machine, compiler, and input. We care about *how the cost grows* as the input grows. This idea — growth rate as a function of input size — is the foundation of the Big-O analysis we'll formalize in Chapter 3. But first, let's build intuition by counting operations.
:::

### Counting basic operations

We model the cost of an algorithm by counting **basic operations** — comparisons, assignments, arithmetic — as a function of input size $n$.

:::example[Example 5.1 — Counting operations in a simple loop]
How many comparisons does the following code perform as a function of $n$?

```cpp
int sum = 0;
for (int i = 0; i < n; i++)
    sum += i;
```

::::answer[Answer]
$n + 1$ comparisons (the loop condition `i < n` is tested $n+1$ times — once per successful iteration plus once for the final false check).
::::

Work

Each iteration: test `i < n` (1 comparison), execute `sum += i` (1 addition + 1 assignment), increment `i` (1 add). The loop runs for $i = 0, 1, \ldots, n-1$ — that's $n$ iterations, plus one final test where `i = n` and the loop exits. Total comparisons: $n + 1$. Total additions: $n$ (body) + $n$ (increment) = $2n$. Total assignments: $n$ (for `sum +=`) + $n$ (for `i++`) + 2 (initializations) = $2n + 2$.

In Chapter 3, we'll see that all of these — $n+1$, $2n$, $2n+2$ — are captured by the same Big-O expression: $O(n)$.
:::

:::example[Example 5.2 — Nested loops]
How many times does `count++` execute?

```cpp
int count = 0;
for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
        count++;
```

::::answer[Answer]
$n^2$ times.
::::

Work

The outer loop runs $n$ times. For each value of $i$, the inner loop runs $n$ times. So the total is $n \times n = n^2$. This is $O(n^2)$ — "quadratic." Doubling $n$ quadruples the work. This is why nested loops over the entire input are a red flag for performance.
:::

### Practice problems

:::problem[Problem 5.1 easy]{difficulty="easy"}
How many times does the body execute?

```cpp
for (int i = 0; i < n; i++)
    for (int j = i; j < n; j++)
        doWork();
```

::::solution[Solution]
When $i = 0$: inner loop runs $n$ times. When $i = 1$: $n-1$ times. ... When $i = n-1$: 1 time. Total: $n + (n-1) + \cdots + 1 = \dfrac{n(n+1)}{2}$. This is still $O(n^2)$, but about half as many operations as the full nested loop.
::::
:::

:::problem[Problem 5.2 standard]{difficulty="standard"}
How many times does `print(i)` execute?

```cpp
for (int i = 1; i <= n; i *= 2)
    print(i);
```

::::solution[Solution]
The loop variable `i` doubles each iteration: 1, 2, 4, 8, ..., up to $n$. We need to find how many times we can double before exceeding $n$. After $k$ iterations, $i = 2^k$. The loop stops when $2^k > n$, i.e., $k > \log_2 n$. So the loop runs $\lfloor \log_2 n \rfloor + 1$ times — this is $O(\log n)$. Loops that multiply/divide the counter are logarithmic.
::::
:::

:::problem[Problem 5.3 challenge]{difficulty="challenge"}
An algorithm performs the following work on input of size $n$: a nested loop doing $n^2$ work, then a separate loop doing $100n$ work, then a constant-time operation. Write the total work as an exact expression, then identify which term dominates for large $n$.

::::solution[Solution]
Total work $T(n) = n^2 + 100n + c$ where $c$ is the constant. For large $n$, the $n^2$ term dominates: even at $n = 200$, $n^2 = 40{,}000$ while $100n = 20{,}000$ — and the ratio only gets worse. As $n \to \infty$, the $n^2$ term accounts for essentially all of the cost. In Big-O terms: $O(n^2)$. The constants and lower-order terms are dropped because they don't affect the growth rate.
::::
:::

:::summary
## Chapter Summary

| Concept | Key point |
| --- | --- |
| Text segment | Machine code — read-only |
| Data/BSS | Global and static variables — persist for program lifetime |
| Stack | Local variables + call frames — LIFO, automatic, limited size (~8 MB) |
| Heap | Dynamic allocations — unlimited, manual, fragmentation possible |
| Stack frame | Created on each call; holds locals, params, return address |
| Cache line | 64 bytes loaded at once; sequential access = cache hits = fast |
| Spatial locality | Access nearby addresses together → contiguous arrays are cache-friendly |
| Operation counting | Express work as $T(n)$; dominant term = Big-O class |

### If you remember nothing else

Every heap allocation is slower than a stack allocation; every cache miss is ~100× slower than a cache hit. Data structure choice affects *both*. Big-O tells you the growth rate, but cache behavior determines the constant factor you live with in practice.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
Which executes faster: accessing `arr[5]` immediately after accessing `arr[0]`, or accessing `ptr->data` after following a linked-list pointer to a random heap address? Why?

::::solution[Solution]
`arr[5]` is almost certainly a **cache hit** — it is 20 bytes from `arr[0]`, well within the same 64-byte cache line. The linked-list access is almost certainly a **cache miss** — the next node was allocated separately and could be anywhere in the heap. Cache hits take ~1 ns; cache misses take ~100 ns.
::::
:::

:::problem[Problem M.2 standard]{difficulty="standard"}
A recursive function `f(n)` calls itself twice — once with `n-1` and once with `n-2` (like Fibonacci). What is the maximum call stack depth as a function of $n$?

::::solution[Solution]
The maximum depth follows the *leftmost* path of the call tree: $f(n) \to f(n-1) \to f(n-2) \to \cdots \to f(1)$. This has depth $n$, so the maximum number of frames on the stack at any one time is $n + 1$ (including `main`). The total number of calls is exponential (~$2^n$), but the stack depth is only linear.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
How many times does `work()` execute in the following? Express as a function of $n$ and name the Big-O class.

```cpp
for (int i = 0; i < n; i++)
    for (int j = 1; j < n; j *= 3)
        work();
```

::::solution[Solution]
The outer loop runs $n$ times. The inner loop multiplies by 3 each time: runs $\lceil \log_3 n \rceil$ times. Total: $n \cdot \log_3 n$. Big-O class: $O(n \log n)$. (The base of the logarithm is a constant factor, so $\log_3 n = \log_2 n / \log_2 3 = O(\log n)$.)
::::
:::

:::problem[Problem M.4 challenge]{difficulty="challenge"}
You're writing a graph algorithm that stores edges as a list of `struct Edge { int u, v, weight; }` objects. You'll iterate over all edges many times. Should you use `std::vector<Edge>` or `std::list<Edge>`? Justify with a memory/cache argument.

::::solution[Solution]
Use `std::vector<Edge>`. Reasons:

- **Contiguous layout**: all Edge objects are packed together. Iterating loads cache lines filled with multiple edges — excellent spatial locality.
- `std::list<Edge>` stores each node separately on the heap with `prev`/`next` pointers (24 bytes of overhead per node). Each node is a separate allocation, potentially at a random address — one cache miss per edge visited.
- For a graph with 10,000 edges, vector iteration might cause ~625 cache misses (10,000 edges × 12 bytes / 64-byte cache line). List iteration might cause ~10,000 cache misses.
- `std::list` only wins when you need O(1) insertion/deletion in the middle. For read-heavy traversal, `vector` always wins.
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook.
