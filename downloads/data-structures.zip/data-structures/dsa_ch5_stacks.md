---
title: "Stacks"
crumb: "Honors DSA · Chapter 5"
meta:
  - "Est. study time: ~120 min"
  - "Unit 2 — Linear Structures"
  - "CSE 2383 · MSState"
source: "markdown"
---

## Overview

A **stack** is the simplest restricted-access container: elements enter and leave from the same end, called the *top*. This Last-In-First-Out (LIFO) discipline appears everywhere — in the call stack that makes function recursion work, in undo/redo systems, in expression parsing, and in graph traversal.

This chapter covers two concrete implementations (array-backed and linked-list-backed), the C++ standard library adapter, and five classic algorithmic patterns that exploit the LIFO property: bracket matching, expression conversion and evaluation, monotonic stacks, the min-stack, and iterative DFS.

:::callout-key[Prerequisites]
- Arrays and dynamic memory (`new`/`delete[]`) — Ch 2
- Singly-linked lists — Ch 4
- Big-O notation and amortized analysis — Ch 3
:::

## 1. The Stack ADT

:::callout-intuition[Intuition]
Picture a stack of cafeteria trays. You can only put a new tray on top (**push**), take the top tray off (**pop**), or peek at what tray is on top (**peek/top**). You can never pull a tray from the middle. This restriction is the point: knowing that only the top can change makes stacks ideal for tracking "what was the most recent thing."
:::

:::definition[Definition 5.1 — Stack ADT]
A **stack** is a collection supporting exactly four operations:

- `push(x)` — insert element `x` at the top.
- `pop()` — remove and return the top element (undefined behavior on empty stack).
- `top()` / `peek()` — return the top element without removing it.
- `isEmpty()` / `size()` — query whether the stack is empty, and how many elements it holds.

All four operations must run in **O(1)** time (worst-case for linked; amortized for array).
:::

### Concrete interface in C++

```cpp
template <typename T>
class Stack {
public:
    virtual void push(const T& val) = 0;
    virtual T    pop()              = 0;  // removes AND returns top
    virtual T    top() const        = 0;  // peek, no removal
    virtual bool isEmpty() const    = 0;
    virtual int  size()   const     = 0;
};
```

:::callout-pitfall[Pitfall — std::stack pop() returns void]
The C++ standard library's `std::stack::pop()` returns **void**, not the element. To retrieve the top before removing it, you must call `top()` first, then `pop()`. Writing `int x = s.pop();` is a compile error. This trips up almost every student the first time.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
List the four operations of the Stack ADT and state the time complexity of each.

::::solution[Solution]
`push` O(1) amortized (array) or O(1) worst-case (linked); `pop` O(1) amortized/worst-case; `top` O(1); `isEmpty`/size O(1). All operations access only the top of the stack.
::::
:::

:::problem[Problem 2 · easy]{difficulty="easy"}
Trace the state of a stack after the sequence: push(5), push(3), push(9), pop(), push(1), pop(), top(). What does top() return?

::::solution[Solution]
Step by step: [5] → [5,3] → [5,3,9] → pop returns 9 → [5,3] → [5,3,1] → pop returns 1 → [5,3]. `top()` returns **3**.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Why does `std::stack::pop()` return `void` instead of the element? (Think about exception safety.)

::::solution[Solution]
If `pop()` both removed the element and returned it by value, the copy constructor of the return value could throw an exception after the element had already been removed — causing data loss with no way to recover. Separating `top()` (inspect) from `pop()` (remove) ensures the element is accessible even if copying it throws.
::::
:::

## 2. ArrayStack & Amortized Analysis

:::callout-intuition[Intuition]
The simplest stack implementation keeps elements in a plain array and tracks the index of the top element. Push increments the index and writes; pop reads and decrements. The snag: arrays have fixed capacity. When full, we need to grow — and growing is expensive (O(n) copy). The key insight is that if we *double* the capacity each time, expensive grows become rare enough that the average cost per push is still O(1).
:::

### Implementation

```cpp
template <typename T>
class ArrayStack {
    T*  data;
    int cap;
    int topIdx;   // index of top element; -1 when empty

    void grow() {
        int newCap = cap * 2;
        T* newData = new T[newCap];
        for (int i = 0; i <= topIdx; ++i)
            newData[i] = data[i];
        delete[] data;
        data = newData;
        cap  = newCap;
    }

public:
    ArrayStack(int initCap = 4)
      : cap(initCap), topIdx(-1) {
        data = new T[cap];
    }
    ~ArrayStack() { delete[] data; }

    void push(const T& val) {
        if (topIdx + 1 == cap) grow();   // O(n) but rare
        data[++topIdx] = val;            // O(1) normally
    }

    T pop() {
        if (isEmpty()) throw std::underflow_error("stack empty");
        return data[topIdx--];
    }

    T top() const {
        if (isEmpty()) throw std::underflow_error("stack empty");
        return data[topIdx];
    }

    bool isEmpty() const { return topIdx == -1; }
    int  size()   const  { return topIdx + 1; }
};
```

### Amortized Analysis — the Doubling Argument

Why is `push` O(1) *amortized*? Consider performing *n* pushes starting from capacity 1, doubling whenever full:

- Growths occur at sizes 1, 2, 4, 8, …, up to the largest power of 2 ≤ n.
- The total copy work across all grows: $1 + 2 + 4 + \cdots + n/2 < n$.
- Total work for n pushes (n cheap pushes + <n copy steps) = O(n).
- Average (amortized) cost per push = O(n)/n = **O(1)**.

:::theorem[Theorem 5.1 — Amortized Push Cost]
In an ArrayStack that doubles capacity on overflow, any sequence of $n$ push operations costs $O(n)$ total, giving an amortized cost of $O(1)$ per push.
:::

Formal potential argument

Assign each element a "credit" of 2 when it is pushed. One credit pays for the push itself. The second credit is stored and pays for the element's future copy during a grow. When we grow and copy $k$ elements, each of those $k$ elements already has one saved credit — so the grow is fully funded. No extra real work is needed.

:::example[Example 5.1 — Tracing a grow]
ArrayStack with cap=4, containing [10, 20, 30, 40] (topIdx=3). Push 50.

::::answer[Answer]
After push(50): array is [10, 20, 30, 40, 50, \_, \_, \_], cap=8, topIdx=4.
::::

Work

1. topIdx+1 == cap (4 == 4) → grow() is called.
2. newCap = 8; allocate new array of size 8.
3. Copy data[0..3] = {10,20,30,40} into new array.
4. delete[] old array; data = newArray; cap = 8.
5. data[++topIdx] = data[4] = 50; topIdx = 4.
:::

:::example[Example 5.2 — Total copy cost for 8 pushes]
Start with cap=1. Push elements 1 through 8. How many total element copies occur?

::::answer[Answer]
7 total copies.
::::

Work

- Push 1 into cap=1: full → grow to cap=2, copy 1 element. Then push. (1 copy)
- Push 2 into cap=2: full → grow to cap=4, copy 2 elements. (2 copies)
- Push 3: no grow.
- Push 4 into cap=4: full → grow to cap=8, copy 4 elements. (4 copies)
- Push 5, 6, 7, 8: no grows.
- Total copies = 1 + 2 + 4 = **7** < 8 = n. ✓
:::

:::callout-pitfall[Pitfall — Off-by-one with topIdx]
A common bug: checking `topIdx == cap` instead of `topIdx + 1 == cap` before growing. Since topIdx is the *index* of the top (0-based), the array is full when topIdx + 1 equals cap. Similarly, `isEmpty()` should check `topIdx == -1`, not `topIdx == 0` (that would lose the bottom element).
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
An ArrayStack starts at cap=2. After pushing 5 elements, what is the capacity?

::::solution[Solution]
Grows: 2→4 (after 2nd push), 4→8 (after 4th push). After 5 pushes: **cap = 8**.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
What is the amortized cost of `pop()` in an ArrayStack that *halves* capacity when size drops below cap/4? Justify briefly.

::::solution[Solution]
Pop is still O(1) amortized. We halve at 1/4 full, so after a shrink the array is 1/2 full. This means at least n/4 more pops must happen before the next expensive shrink, each of which costs O(1) real work. The amortized cost per pop stays O(1). (The key is using cap/4 as the threshold, not cap/2, to avoid thrashing.)
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
If you use increment-by-one (instead of doubling) to grow the array, what is the amortized cost of push? Show the total copy cost for n pushes.

::::solution[Solution]
Grows occur at every push once capacity is hit: 1 copy, then 2 copies, then 3, ... then n-1 copies. Total = 1+2+...+(n-1) = n(n-1)/2 = O(n²). Amortized cost per push = O(n²)/n = **O(n)**. Much worse than doubling!
::::
:::

:::problem[Problem 4 · challenge]{difficulty="challenge"}
Modify ArrayStack to support `getMin()` in O(1). (Hint: maintain an auxiliary stack.) Describe the push/pop behavior of the auxiliary stack.

::::solution[Solution]
Maintain a second "min-stack." On `push(x)`: push x onto the main stack; if the min-stack is empty or x ≤ minStack.top(), also push x onto the min-stack. On `pop()`: pop main stack to get val; if val == minStack.top(), also pop the min-stack. `getMin()` returns minStack.top(). All operations remain O(1). See Section 8 for the full treatment.
::::
:::

## 3. LinkedStack

:::callout-intuition[Intuition]
A linked stack keeps a pointer to the **head** of a singly-linked list. Push prepends a new node (the new head); pop removes the head. No capacity limit, no amortized analysis needed — every operation is O(1) *worst-case*. The trade-off: each element carries a pointer overhead (8 bytes on a 64-bit system), and cache locality is poor compared to an array.
:::

```cpp
template <typename T>
class LinkedStack {
    struct Node {
        T     data;
        Node* next;
        Node(const T& d, Node* n) : data(d), next(n) {}
    };
    Node* head;   // top of stack
    int   sz;

public:
    LinkedStack() : head(nullptr), sz(0) {}
    ~LinkedStack() { while (!isEmpty()) pop(); }

    void push(const T& val) {
        head = new Node(val, head);  // prepend
        ++sz;
    }

    T pop() {
        if (!head) throw std::underflow_error("stack empty");
        T val = head->data;
        Node* old = head;
        head = head->next;
        delete old;
        --sz;
        return val;
    }

    T top() const {
        if (!head) throw std::underflow_error("stack empty");
        return head->data;
    }

    bool isEmpty() const { return head == nullptr; }
    int  size()   const  { return sz; }
};
```

:::example[Example 5.3 — LinkedStack push/pop trace]
Trace the heap state after: push(7), push(4), push(2), pop().

::::answer[Answer]
After pop(): head → [4 | next→[7 | null]]. The node holding 2 is deleted.
::::

Work

```
push(7):  head → [7 | null]

push(4):  head → [4 | →] → [7 | null]

push(2):  head → [2 | →] → [4 | →] → [7 | null]

pop():    val=2, old=head, head=head→next
          delete old (node holding 2)
          head → [4 | →] → [7 | null]   sz=2

```
:::

:::callout-pitfall[Pitfall — Memory leak in pop()]
A common bug is: `head = head->next; return val;` — forgetting to `delete old`. The node that was removed leaks. Always save the old head pointer, advance head, then delete the saved pointer.
:::

### ArrayStack vs. LinkedStack — when to use which

| Property | ArrayStack | LinkedStack |
| --- | --- | --- |
| Push worst-case | O(n) (rare grow) | O(1) |
| Push amortized | O(1) | O(1) |
| Pop | O(1) | O(1) |
| Memory per element | ~4–8 bytes (T only) | T + pointer (extra 8 bytes) |
| Cache locality | Excellent (contiguous) | Poor (scattered nodes) |
| Max size known? | Use array if yes | Use linked if unbounded |

:::problem[Problem 1 · easy]{difficulty="easy"}
In a LinkedStack, which end of the linked list is the "top" — head or tail? Why?

::::solution[Solution]
The **head** is the top. Prepending to (and removing from) the head is O(1). Appending to or removing from the tail requires traversal: O(n). Using head = top gives us O(1) push and pop.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Write the destructor for LinkedStack without calling pop(). Use a while loop that directly manipulates `head`.

::::solution[Solution]
```cpp
~LinkedStack() {
    while (head) {
        Node* tmp = head;
        head = head->next;
        delete tmp;
    }
}
```
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
If a LinkedStack contains n items, how many nodes are on the heap? How many bytes of overhead (beyond the data) are used per node on a 64-bit system?

::::solution[Solution]
Exactly n nodes on the heap. Each node has one `Node*` pointer (8 bytes on 64-bit) plus any struct-alignment padding. So overhead per node is at least 8 bytes beyond the stored value T.
::::
:::

## 4. `std::stack` Adapter

:::callout-intuition[Intuition]
`std::stack` is not a container — it is a **container adapter**. It wraps an underlying container (by default `std::deque`) and restricts access to stack operations only. You can also use `std::vector` or `std::list` as the underlying container.
:::

```cpp
#include <stack>

std::stack<int> s;              // backed by std::deque<int>
std::stack<int, std::vector<int>> sv;  // backed by std::vector

s.push(10);
s.push(20);
s.push(30);

// CORRECT way to get top then remove:
int val = s.top();  // val = 30
s.pop();            // removes 30; returns void!

// WRONG — does NOT compile:
// int x = s.pop();

std::cout << s.size();   // 2
std::cout << s.empty();  // false
```

:::callout-pitfall[Pitfall — pop() returns void]
`std::stack::pop()` returns `void`. The pattern is always: (1) read with `top()`, (2) remove with `pop()`. Calling `pop()` on an empty stack is undefined behavior — no exception is thrown by default.
:::

:::callout-tip[Tip — Backing container choice]
- `std::deque` (default): O(1) amortized push, good cache behavior in blocks.
- `std::vector`: better raw cache performance, but push\_back may reallocate.
- `std::list`: O(1) worst-case push\_front/pop\_front, poor cache locality.

For most competitive programming and course work, `std::stack<T>` (deque-backed) is the default choice.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Write the correct two-line idiom to retrieve the top element of a `std::stack<int> s` into variable `x` and then remove it.

::::solution[Solution]
```cpp
int x = s.top();
s.pop();
```
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
What happens at runtime if you call `s.pop()` on an empty `std::stack`? How would you guard against it?

::::solution[Solution]
Undefined behavior — the standard does not require an exception. Always check `s.empty()` before calling `top()` or `pop()`:
 `if (!s.empty()) {
 int x = s.top();
 s.pop();
}`
::::
:::

## 5. Balanced Brackets

:::callout-intuition[Intuition]
A string like `({[]})` is balanced: every opening bracket has a matching closer in the right order. A stack is perfect here because whenever you see a closing bracket, the matching opener must be the most recently seen unmatched opener — exactly what the stack's top holds.
:::

### Algorithm

1. Scan left to right.
2. If the character is an opener (`(`, `[`, `{`), push it.
3. If the character is a closer, check if the stack is non-empty and `top()` is the matching opener. If yes, pop. If no, return **false**.
4. After scanning, return **true** iff the stack is empty.

```cpp
bool isBalanced(const std::string& s) {
    std::stack<char> st;
    for (char c : s) {
        if (c == '(' || c == '[' || c == '{') {
            st.push(c);
        } else if (c == ')' || c == ']' || c == '}') {
            if (st.empty()) return false;
            char top = st.top(); st.pop();
            if ((c == ')' && top != '(') ||
                (c == ']' && top != '[') ||
                (c == '}' && top != '{')) return false;
        }
    }
    return st.empty();
}
```

:::example[Example 5.4 — Balanced trace: ({\[\]})]
Trace the stack state character by character for the input `({[]})`.

::::answer[Answer]
Returns **true** (balanced).
::::

Work

| Char | Action | Stack (top→right) |
| --- | --- | --- |
| `(` | push | ( |
| `{` | push | ( { |
| `[` | push | ( { [ |
| `]` | top=[ → match → pop | ( { |
| `}` | top={ → match → pop | ( |
| `)` | top=( → match → pop | (empty) |

Stack empty at end → true.
:::

:::example[Example 5.5 — Unbalanced trace: (\[)\]]
Trace the stack state for `([)]`. Why does it fail?

::::answer[Answer]
Returns **false**.
::::

Work

| Char | Action | Stack |
| --- | --- | --- |
| `(` | push | ( |
| `[` | push | ( [ |
| `)` | top=[ ≠ ( → mismatch! | FAIL |
:::

:::example[Example 5.6 — Unbalanced trace: (()]
Trace `(()`. Why does it fail?

::::answer[Answer]
Returns **false** — stack non-empty at end.
::::

Work

Push (, push (, see ) → pop one (. End of string: stack still has one (. Stack not empty → return false.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Is `{[]()}` balanced? Trace the stack.

::::solution[Solution]
Push {, push [, see ] → pop [, push (, see ) → pop (, see } → pop {. Stack empty → **true** (balanced).
::::
:::

:::problem[Problem 2 · easy]{difficulty="easy"}
Is `]` balanced? What happens on the first character?

::::solution[Solution]
First character is a closer, stack is empty → return **false** immediately.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Modify `isBalanced` to return the index of the first offending character (or -1 if balanced). What changes?

::::solution[Solution]
Track index `i` in the loop. Return `i` instead of `false` when a mismatch or empty-stack-on-close is detected. If we finish and the stack is not empty, the error is the opener that was never closed — its index was stored when pushed, so push `pair<char,int>` instead of just `char`. Return the stored index of the unmatched opener.
::::
:::

:::problem[Problem 4 · standard]{difficulty="standard"}
What is the time complexity of `isBalanced`? What is the worst-case space complexity?

::::solution[Solution]
Time: O(n) — each character is processed exactly once. Space: O(n) — in the worst case (all openers, e.g., `((((`), the stack holds all n characters.
::::
:::

:::problem[Problem 5 · challenge]{difficulty="challenge"}
Given a string containing only `(` and `)`, find the minimum number of insertions needed to make it balanced. Example: `)(` needs 2 insertions. Write a O(n) algorithm using a stack or counters.

::::solution[Solution]
Use two counters: `open` (unmatched open parens) and `close` (unmatched close parens). Scan left to right: if `(`, increment open; if `)` and open > 0, decrement open (match found), else increment close (unmatched close). Answer = open + close.
 `int minInsertions(const string& s) {
 int open = 0, close = 0;
 for (char c : s) {
 if (c == '(') ++open;
 else if (open > 0) --open;
 else ++close;
 }
 return open + close;
}`
::::
:::

## 6. Infix → Postfix & Postfix Evaluation

:::callout-intuition[Intuition]
Humans write math as **infix**: `3 + 4 * 2`, where operator position and precedence rules determine order. Computers prefer **postfix** (Reverse Polish Notation): `3 4 2 * +`, where the operator immediately follows its operands — no parentheses or precedence rules needed. A stack handles both conversions cleanly: for conversion we hold operators; for evaluation we hold operands.
:::

### Operator Precedence (for the Shunting-Yard Algorithm)

| Operator | Precedence | Associativity |
| --- | --- | --- |
| `^` | 3 (highest) | Right |
| `* /` | 2 | Left |
| `+ -` | 1 (lowest) | Left |

### Shunting-Yard Algorithm (Infix → Postfix)

1. Read tokens left to right.
2. If token is a **number**: append to output.
3. If token is an **operator** op:

   - While the stack is not empty, the top is an operator with *higher* precedence (or equal precedence and left-associative), and the top is not a left paren: pop to output.
   - Push op.

4. If token is **(**: push it.
5. If token is **)**: pop to output until ( is found; discard the (.
6. After all tokens: pop all remaining operators to output.

:::example[Example 5.7 — Infix to Postfix: 3 + 4 \* 2]
Convert `3 + 4 * 2` to postfix using shunting-yard.

::::answer[Answer]
Postfix: `3 4 2 * +`
::::

Work

| Token | Action | Output | Op Stack |
| --- | --- | --- | --- |
| 3 | number → output | 3 | (empty) |
| + | stack empty → push | 3 | + |
| 4 | number → output | 3 4 | + |
| \* | prec(\*) > prec(+) → push | 3 4 | + \* |
| 2 | number → output | 3 4 2 | + \* |
| end | pop \* → output, pop + → output | 3 4 2 \* + | (empty) |
:::

:::example[Example 5.8 — Infix to Postfix with parentheses: (3 + 4) \* 2]
Convert `(3 + 4) * 2` to postfix.

::::answer[Answer]
Postfix: `3 4 + 2 *`
::::

Work

| Token | Action | Output | Op Stack |
| --- | --- | --- | --- |
| ( | push ( |  | ( |
| 3 | output | 3 | ( |
| + | top=( → push | 3 | ( + |
| 4 | output | 3 4 | ( + |
| ) | pop until (: pop + → output, discard ( | 3 4 + | (empty) |
| \* | stack empty → push | 3 4 + | \* |
| 2 | output | 3 4 + 2 | \* |
| end | pop \* → output | 3 4 + 2 \* | (empty) |
:::

### Postfix Evaluation Algorithm

1. Scan left to right.
2. If token is a number: push it.
3. If token is an operator: pop two operands (b = pop, a = pop), compute a op b, push result.
4. Final answer is the single value remaining on the stack.

:::example[Example 5.9 — Evaluate postfix: 3 4 2 \* +]
Evaluate `3 4 2 * +`.

::::answer[Answer]
11
::::

Work

| Token | Action | Stack (top→right) |
| --- | --- | --- |
| 3 | push | 3 |
| 4 | push | 3 4 |
| 2 | push | 3 4 2 |
| \* | b=2,a=4; push 4\*2=8 | 3 8 |
| + | b=8,a=3; push 3+8=11 | 11 |
:::

:::callout-pitfall[Pitfall — Operand pop order matters]
For non-commutative operators (- and /), the order you pop matters. Pop the **second** operand first (`b = pop()`), then the first (`a = pop()`), and compute `a op b`. If you pop in the wrong order, `5 3 -` gives -2 instead of 2.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Evaluate the postfix expression `5 1 2 + 4 * + 3 -`.

::::solution[Solution]
5, 1, 2 on stack. +: 1+2=3 → [5,3]. 4 → [5,3,4]. \*: 3\*4=12 → [5,12]. +: 5+12=17 → [17]. 3 → [17,3]. -: 17-3=14 → [14]. Answer: **14**.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Convert `a * b + c / d` to postfix.

::::solution[Solution]
a→out; \*→push; b→out; +: prec(+)<prec(\*) → pop \* to out, push +; c→out; /: prec(/)>prec(+) → push /; d→out; end: pop / then +. Postfix: `a b * c d / +`
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Convert `a ^ b ^ c` to postfix. (^ is right-associative, prec 3.) What distinguishes right-associative handling?

::::solution[Solution]
a→out; ^→push; b→out; second ^: prec equal but right-associative → do NOT pop the existing ^ (unlike left-assoc) → push second ^; c→out; end: pop ^ twice. Postfix: `a b c ^ ^`. For right-associative, the condition for popping is *strictly greater* precedence (not ≥).
::::
:::

:::problem[Problem 4 · challenge]{difficulty="challenge"}
Write a complete C++ function `int evalPostfix(const string& expr)` that evaluates a space-separated postfix expression of single-digit integers and operators +, -, \*, /.

::::solution[Solution]
```cpp
int evalPostfix(const string& expr) {
    stack<int> st;
    istringstream iss(expr);
    string token;
    while (iss >> token) {
        if (isdigit(token[0])) {
            st.push(stoi(token));
        } else {
            int b = st.top(); st.pop();
            int a = st.top(); st.pop();
            if (token == "+") st.push(a + b);
            else if (token == "-") st.push(a - b);
            else if (token == "*") st.push(a * b);
            else if (token == "/") st.push(a / b);
        }
    }
    return st.top();
}
```
::::
:::

## 7. Monotonic Stack

:::callout-intuition[Intuition]
A **monotonic stack** maintains elements in sorted order (monotonically increasing or decreasing from bottom to top). Whenever you push a new element, you first pop all elements that would violate the order. This lets you answer "what is the next greater/smaller element to the right?" for every element in O(n) total — rather than O(n²) with nested loops.
:::

### Next Greater Element

Given array `A`, for each index `i` find the nearest index `j > i` such that `A[j] > A[i]`, or -1 if none exists.

```cpp
vector<int> nextGreater(const vector<int>& A) {
    int n = A.size();
    vector<int> result(n, -1);
    stack<int> st;  // stores indices, stack is decreasing in A-value

    for (int i = 0; i < n; ++i) {
        // Pop all indices whose A-value is less than A[i]
        while (!st.empty() && A[st.top()] < A[i]) {
            result[st.top()] = i;  // A[i] is next greater for st.top()
            st.pop();
        }
        st.push(i);
    }
    return result;  // remaining indices in stack have no next greater → -1
}
```

:::example[Example 5.10 — Next Greater Element trace]
A = [2, 1, 5, 3, 4]. Find next greater element index for each position.

::::answer[Answer]
result = [2, 2, -1, 4, -1] (indices; values: 5, 5, none, 4, none)
::::

Work

| i | A[i] | Action | Stack (indices) | Result updates |
| --- | --- | --- | --- | --- |
| 0 | 2 | stack empty → push 0 | [0] |  |
| 1 | 1 | A[0]=2 > 1 → no pop. Push 1 | [0,1] |  |
| 2 | 5 | A[1]=1<5 → result[1]=2, pop; A[0]=2<5 → result[0]=2, pop; push 2 | [2] | result[0]=2, result[1]=2 |
| 3 | 3 | A[2]=5>3 → no pop. Push 3 | [2,3] |  |
| 4 | 4 | A[3]=3<4 → result[3]=4, pop; A[2]=5>4 → stop. Push 4 | [2,4] | result[3]=4 |
| end |  | indices 2,4 remain → result[2]=result[4]=-1 |  |  |
:::

### Stock Span Problem

Given daily stock prices, the *span* of day *i* is the maximum number of consecutive days (up to and including day *i*) for which the price was ≤ price[i]. Use a monotonic stack storing indices of days with decreasing prices.

```cpp
vector<int> stockSpan(const vector<int>& price) {
    int n = price.size();
    vector<int> span(n);
    stack<int> st;  // indices, prices are decreasing (monotone decreasing)
    for (int i = 0; i < n; ++i) {
        while (!st.empty() && price[st.top()] <= price[i])
            st.pop();
        span[i] = st.empty() ? i + 1 : i - st.top();
        st.push(i);
    }
    return span;
}
```

:::problem[Problem 1 · easy]{difficulty="easy"}
For A = [4, 3, 2, 1], what are the next greater elements (by index)?

::::solution[Solution]
result = [-1, -1, -1, -1]. The array is strictly decreasing, so no element has a greater element to its right. The stack never pops — all indices remain.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Compute stock spans for prices = [100, 80, 60, 70, 60, 75, 85].

::::solution[Solution]
Day 0: span=1 (no prev). Day 1: 80<100 → span=1. Day 2: 60<80 → span=1. Day 3: 70>60 → pop 60; 70<80 → stop; span=3-1=2. Day 4: 60<70 → span=1. Day 5: 75>60 pop; 75>70 pop; 75<80 stop; span=5-1=4. Day 6: 85>75 pop; 85>80 pop; stack empty; span=6+1=7. Spans: [1,1,1,2,1,4,6].
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Largest Rectangle in Histogram: Given heights[], find the area of the largest rectangle that fits within the histogram bars. Use a monotonic stack. State the algorithm and time complexity.

::::solution[Solution]
Use a monotonic increasing stack (by height). For each bar i, while the stack top has height > heights[i], pop it: the popped bar is the height of a rectangle; its width extends from the new top+1 to i-1. Also process remaining bars at the end (sentinel value 0 appended). Time: O(n) — each bar pushed and popped at most once.
 `int largestRect(vector<int>& h) {
 h.push_back(0); // sentinel
 stack<int> st;
 int maxArea = 0;
 for (int i = 0; i < h.size(); ++i) {
 while (!st.empty() && h[st.top()] > h[i]) {
 int height = h[st.top()]; st.pop();
 int width = st.empty() ? i : i - st.top() - 1;
 maxArea = max(maxArea, height * width);
 }
 st.push(i);
 }
 return maxArea;
}`
::::
:::

## 8. Min-Stack & Advanced Patterns

### Min-Stack (O(1) getMin)

:::callout-intuition[Intuition]
A regular stack can't find its minimum in less than O(n) without extra storage. The trick: maintain a parallel "min-tracker" stack that always holds the current minimum at its top. When you push a value ≤ current min, also push it to the min-stack. When you pop and the popped value equals the min-stack top, pop the min-stack too.
:::

```cpp
class MinStack {
    stack<int> main;
    stack<int> mins;  // top = current minimum
public:
    void push(int val) {
        main.push(val);
        if (mins.empty() || val <= mins.top())
            mins.push(val);
    }
    void pop() {
        if (main.top() == mins.top()) mins.pop();
        main.pop();
    }
    int top()    { return main.top(); }
    int getMin() { return mins.top(); }
};
```

:::example[Example 5.11 — MinStack trace]
Trace: push(5), push(3), push(7), push(3), pop(), getMin().

::::answer[Answer]
getMin() returns 3.
::::

Work

| Operation | main stack | mins stack |
| --- | --- | --- |
| push(5) | [5] | [5] |
| push(3) | [5,3] | [5,3] (3 ≤ 5) |
| push(7) | [5,3,7] | [5,3] (7 > 3, no push) |
| push(3) | [5,3,7,3] | [5,3,3] (3 ≤ 3) |
| pop() → removes 3 | [5,3,7] | [5,3] (3 == mins.top() → pop mins) |
| getMin() | [5,3,7] | [5,3] → returns **3** |
:::

### Iterative DFS with an Explicit Stack

Recursive DFS uses the call stack implicitly. For deep graphs (stack overflow risk) or when you need explicit control, use your own stack:

```cpp
void iterativeDFS(int start, const vector<vector<int>>& adj) {
    int n = adj.size();
    vector<bool> visited(n, false);
    stack<int> st;
    st.push(start);
    while (!st.empty()) {
        int v = st.top(); st.pop();
        if (visited[v]) continue;
        visited[v] = true;
        // process v here
        for (int neighbor : adj[v])
            if (!visited[neighbor]) st.push(neighbor);
    }
}
```

:::callout-connect[Connection — Stacks and Recursion]
Every recursive algorithm has an equivalent iterative form using an explicit stack. The recursive call stack *is* a stack data structure — local variables and return addresses are pushed when entering a function and popped on return. Converting recursion to iteration is thus always possible, though sometimes complex for mutual recursion or tree algorithms.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Trace MinStack with: push(2), push(0), push(3), push(0), pop(), getMin().

::::solution[Solution]
push(2): main=[2], mins=[2]. push(0): main=[2,0], mins=[2,0]. push(3): main=[2,0,3], mins=[2,0]. push(0): main=[2,0,3,0], mins=[2,0,0]. pop() removes 0: main=[2,0,3], mins=[2,0] (0==mins.top(), pop mins). getMin() = mins.top() = **0**.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Why do we use `val <= mins.top()` (not strict <) when deciding whether to push to the min-stack?

::::solution[Solution]
If the same minimum value is pushed twice, we need two copies in the min-stack. Without ≤, the second push of the same minimum value wouldn't update the min-stack, so when the first copy is popped (triggering a min-stack pop), the second copy would lose track of the minimum. Using ≤ ensures both copies are tracked.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
In the iterative DFS code, why might a node be visited multiple times before the `visited[v]` check? Could we avoid pushing duplicates onto the stack?

::::solution[Solution]
Multiple neighbors can push the same node before it is processed (the check happens at pop-time, not push-time). We can avoid duplicates by checking `visited[neighbor]` before pushing, but this requires marking as visited at push-time rather than pop-time — which changes the visit semantics slightly (the node is "visited" before we process it).
::::
:::

## The Course Implementation

This is the exact interface examined in CSE 2383, expanded into the reasoning needed to reproduce it correctly on paper. The stack reuses the singly linked `Node` from [Chapter 4's Node class](dsa_ch4_linked_lists.md#the-node-class); pointer syntax, `nullptr`, `new`, `delete`, `->`, constructors, initializer lists, access labels, references, `::`, destructors, and `this` are explained there and in [the Chapter 4 class walkthrough](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).

### The mental model: one accessible end

A stack is **last in, first out** (LIFO): the most recently pushed value must be the next value popped. The course representation stores one pointer, `top`, which points to that next value.

```text
top -> [8] -> [5] -> [2] -> nullptr
        ^
        next pop
```

There is one central invariant:

- The stack is empty exactly when `top == nullptr`.

When the stack is non-empty, following `next` from `top` reaches every node and eventually reaches `nullptr`. Every operation must preserve that fact as well, or the stack loses nodes.

Why does `top` name the **front** of the singly linked chain instead of its back? Adding to the front is O(1), and removing the front is O(1): both operations already have the address they need in `top`. Adding at the back could also be O(1) if the class stored a tail pointer, but removing the back still needs the address of the node immediately before it. A singly linked node has only `next`, so finding that predecessor requires a walk from the front: O(n). Choosing the front is what makes both `push` and `pop` O(1).

### The class definition

Here is Dr. Swan's listing verbatim. It omits `push`, `pop`, and `peek`:

```cpp
class Stack
{
   private:
      Node *top;

   public:
      Stack(): top(nullptr) {} // default contructor
      ~Stack();
      Stack(const Stack &old); // copy constructor
};
```

The final semicolon after `}` is required; omitting it is a common handwritten syntax error. For the full explanation of class declarations, `private:`, `public:`, constructors, initializer lists, `const &`, and that semicolon, see [Chapter 4's class definition](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).

The following is **not a second course listing**. It completes his partial listing by adding the three declarations whose definitions appear on his pages:

```cpp
class Stack
{
   private:
      Node *top;

   public:
      Stack(): top(nullptr) {} // default contructor
      ~Stack();
      Stack(const Stack &old); // copy constructor

      void push(int data);
      bool pop();
      bool peek(int &data);
};
```

The constructor establishes the invariant immediately: a new stack has no nodes, so `top` starts as `nullptr`. The three added lines are declarations, so each ends in `;`. In `int &data`, the `&` is essential: it lets `peek` change the caller's variable.

### `push`, line by line

`push` must make a new node the top while keeping the entire old chain reachable.

```text
Before push(8):
top -> [5] -> [2] -> nullptr

After push(8):
top -> [8] -> [5] -> [2] -> nullptr
```

His code, verbatim:

```cpp
void Stack::push(int data)
{
   Node *tmp = new Node(data); // create the new node
   tmp->next = top; // set the new node's next to top
   top = tmp; // set top to the node node
}
```

**Line by line**

- `void Stack::push(int data)` defines the `push` that belongs to `Stack`. `void` is correct because, in the course model, inserting a supplied integer has no empty-container failure to report. `Stack::` is the scope-resolution syntax reviewed in [Chapter 4's class definition](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).
- `{` opens the function body; the matching `}` closes it.
- `Node *tmp = new Node(data);` creates a separate heap node containing `data` and stores its address in the local pointer `tmp`. This uses the one-argument `Node` constructor from [Chapter 4](dsa_ch4_linked_lists.md#the-node-class).
- `tmp->next = top;` makes the new node point to the old first node. Use `->`, not `.`, because `tmp` is a pointer. This line must come before changing `top`; otherwise the old chain's address would be lost.
- `top = tmp;` makes the stack enter through the new node. Assignment uses one `=`. A test for equality would use `==` and would not change the pointer.

There is no empty-stack branch. If the stack is empty, `top` is already `nullptr`, so `tmp->next = top` correctly makes the new node's `next` null; then `top = tmp` makes it the only node:

```text
Before push(8):
top -> nullptr

After push(8):
top -> [8] -> nullptr
```

If the stack is non-empty, exactly the same two assignments put the new node before the old top. This differs from `LinkedList::append`, which needs an empty-list branch and a `tail` update; compare [Chapter 4's singly linked append](dsa_ch4_linked_lists.md#singly-linked-append). A stack has no tail to maintain.

### `pop`, line by line

`pop` removes the top node. It returns `false` when no node exists and `true` after a removal.

His code, verbatim:

```cpp
bool Stack::pop() // this operation is a bool because it can fail if the stack is empty
{
   Node *tmp = top; // store the current top of the stack in a temporary variable
   if (top == nullptr) return false; // return false if the stack is empty

   top = top->next; // set the new value of top to the next node in the stack

   delete tmp; // delete the previous top of the stack

   return true; // return true to report that pop worked.
}
```

**Line by line**

- `bool Stack::pop()` defines a member function whose Boolean result reports whether removal succeeded. The empty parentheses mean the caller supplies no argument.
- `Node *tmp = top;` saves the old top node's address. This happens before the empty check, but it is harmless: on an empty stack both `tmp` and `top` are `nullptr`, and the failure path never dereferences or deletes `tmp`.
- `if (top == nullptr) return false;` handles the empty case. `==` compares; writing `top = nullptr` would assign null, discard the chain, and make the condition false because a null pointer converts to false. The semicolon ends the `return` statement.
- `top = top->next;` advances the entry pointer while the old node is still alive, so its `next` field is safe to read.
- `delete tmp;` releases the old top node. Saving `tmp` was essential: if `top` moved first without another pointer holding the old address, no pointer would identify that removed node and it could never be deleted—a memory leak.
- `return true;` tells the caller that one node was removed.

For a non-empty stack, the pointer states are:

```text
Before pop():
top -> [8] -> [5] -> [2] -> nullptr

After top = top->next, before delete:
tmp -> [8] -> [5] -> [2] -> nullptr
               ^
               |
              top

After delete tmp:
top -> [5] -> [2] -> nullptr
```

For a one-node stack, `top->next` is `nullptr`, so moving `top` restores the empty invariant before the old node is deleted. For an empty stack, the early return leaves `top == nullptr` and changes nothing.

### `peek`: two results from one call

`peek` must answer two separate questions: did a top value exist, and, if so, what was it? The `bool` return value answers the first. The reference parameter carries the integer back to the caller.

His code, verbatim:

```cpp
bool Stack::peek(int &data) // this operation returns a bool because it can fail. It also uses pass-by-reference to return the data
{
   if (top == nullptr) return false; // return false if the stack is empty

   data = top->data; // store the data at the top of the stack in the pass-by-reference parameter

   return true; // return true to indicate success
}
```

**Line by line**

- `bool Stack::peek(int &data)` returns success as a `bool`. The `&` makes `data` another name for the caller's integer; without the `&`, the function would change only a local copy and the caller would never receive the value. References are introduced in [Chapter 4's class definition](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).
- `if (top == nullptr) return false;` checks emptiness before dereferencing `top`. Removing this line would make `top->data` invalid on an empty stack.
- `data = top->data;` copies the stored integer into the caller's variable. The stack itself is unchanged.
- `return true;` reports that `data` now contains a valid answer.

A caller uses both outputs together:

```cpp
int x;
if (s.peek(x))
{
   cout << x;
}
```

If `s` is non-empty, `peek` writes its top value into `x`, returns `true`, and the body prints `x`. If `s` is empty, it returns `false`, does not assign `x`, and the body is skipped. Returning only an `int` could not reserve a special failure value because every possible integer might legitimately be stored in the stack.

### The destructor and `while (pop());`

His code, verbatim:

```cpp
Stack::~Stack()
{
   while (pop()); // Pop deletes and updates the top and returns false when the stack is empty
                  // so just looping until pop returns false will empty the stack
}
```

The destructor syntax itself is reviewed in [Chapter 4's Rule of Three subsection](dsa_ch4_linked_lists.md#the-rule-of-three). The compact loop deserves to be read token by token:

- `while` starts a loop whose condition is tested before each iteration.
- `(` and `)` surround that condition.
- `pop()` calls the member function. On every successful call it deletes one node and returns `true`.
- The final `;` is the entire loop body: an **empty statement**. There are no braces because all useful work occurs during the condition call.

The loop terminates because every `true` call reduces the finite number of nodes by one. Once the stack is empty, the next `pop()` returns `false`; `while` stops and the destructor reaches its closing brace. Deleting the semicolon would accidentally make the next statement the loop body; changing `pop()` so it failed to remove a node while returning `true` would make the loop infinite.

### The copy constructor: preserving stack order

His copy constructor, verbatim:

```cpp
Stack::Stack(const Stack &old)
{
   Node *curr = old.top; // set curr to top element in the old stack
   Node *prev = nullptr; // set the previous pointer in the new stack to empty
   Node *tmp = nullptr; // variable to store the new node to add to copy
   top = nullptr; // set top to nullptr since the new stack starts empty

   while (curr != nullptr) // loop as long as there are nodes left in the stack
   {
      tmp = new Node(curr->data); // create a copy of the current node;
      if (top == nullptr) // is the new stack empty
      {
          top = tmp; // if it is, set top to the new node
      }
      else
      {
         prev->next = tmp; // set the next node in the stack to the new node
      }
      prev = tmp; // set the previous node in the stack to the new node
      curr = curr->next; // move to the next element to copy in the stack
   }
}
```

`const Stack &old` is the same non-copying, read-only source pattern explained in [Chapter 4's class definition](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).

**Line by line**

- `Node *curr = old.top;` starts a traversal at the source's top. A `Stack` member may access another `Stack` object's private member.
- `Node *prev = nullptr;` will remember the last node created in the new stack. There is no such node yet.
- `Node *tmp = nullptr;` declares the pointer that will hold each newly allocated node.
- `top = nullptr;` makes the destination a valid empty stack before copying. Constructors do not run the default constructor first, so omitting this assignment would leave `top` indeterminate.
- `while (curr != nullptr)` repeats once for every source node. `!=` is the not-equal comparison; the matching braces enclose the complete loop body.
- `tmp = new Node(curr->data);` allocates a new node containing the current source value. This is a deep copy: it copies the integer, not the node address.
- `if (top == nullptr)` detects only the first iteration, when the destination has no first node.
- `top = tmp;` makes that first new node the destination's top.
- `else` handles every later node.
- `prev->next = tmp;` links the formerly last new node to the new node. `prev` is a pointer, so the member access must be `->`.
- `prev = tmp;` advances the destination's trailing pointer for the next iteration. This assignment belongs after the link; moving it before the link would make `prev->next = tmp` point a node to itself.
- `curr = curr->next;` advances through the old stack. Without it, the condition would keep seeing the same node and the loop would never end.

Why not reuse `push`? Suppose the source is:

```text
old.top -> [8] -> [5] -> [2] -> nullptr
```

A traversal sees `8`, then `5`, then `2`. Using `push` produces:

```text
Start:       new.top -> nullptr
push(8):     new.top -> [8] -> nullptr
push(5):     new.top -> [5] -> [8] -> nullptr
push(2):     new.top -> [2] -> [5] -> [8] -> nullptr
```

The result is reversed: the old top `8` became the new bottom, and `2` became the new top.

The hand-linked version instead appends each copied node after `prev`:

```text
Copy 8:      top -> [8] -> nullptr
Copy 5:      top -> [8] -> [5] -> nullptr
Copy 2:      top -> [8] -> [5] -> [2] -> nullptr
```

On the first iteration, `top` receives the new node. On later iterations, `prev->next` receives it. Because the `Node(int data)` constructor initializes every new node's `next` to `nullptr`, the partial copy always has a valid last node. The original and copy finish with the same top-to-bottom values but different nodes.

### The missing copy assignment operator

Owning heap nodes requires the destructor, copy constructor, and copy assignment operator together; see [Chapter 4's Rule of Three](dsa_ch4_linked_lists.md#the-rule-of-three). Dr. Swan's stack pages omit `operator=`, so compiler-generated assignment would shallow-copy `top`, leak the destination's old nodes, and make two stacks try to delete the same chain.

The following declaration and definition are **not from his pages**. They complete the Rule of Three in his style while preserving order the same way as his copy constructor:

```cpp
// add this declaration in the public part of Stack
Stack &operator=(const Stack &old); // assign a deep copy of old

// define the copy assignment operator outside the class
Stack &Stack::operator=(const Stack &old) // assign old to this stack
{
   if (this == &old) return *this; // do nothing for self-assignment

   while (pop()); // delete every node currently owned by this stack

   Node *curr = old.top; // start at the top of the source stack
   Node *prev = nullptr; // remember the last node added to this stack
   Node *tmp = nullptr; // store each newly allocated node
   while (curr != nullptr) // loop through every source node
   {
      tmp = new Node(curr->data); // copy the current source value into a new node
      if (top == nullptr) // check whether this is the first copied node
      {
         top = tmp; // make the first copied node the new top
      }
      else
      {
         prev->next = tmp; // append later copied nodes after the previous one
      }
      prev = tmp; // remember the new last node
      curr = curr->next; // move to the next source node
   }

   return *this; // return the assigned stack
}
```

The self-assignment check must precede deletion: for `s = s`, deleting first would also erase the source. `this`, `&old`, and `*this` are explained in [Chapter 4's Rule of Three subsection](dsa_ch4_linked_lists.md#the-rule-of-three). After `while (pop());`, the existing `pop` invariant guarantees `top == nullptr`, so the copying loop can use the same first-node test as the copy constructor.

### Complexity at a glance

Let `n` be the number of nodes copied or destroyed. For assignment, let `m` be the destination's old size and `n` the source size.

| Operation | Time | Why |
| --- | --- | --- |
| `push` | O(1) | It changes one new node link and `top`. |
| `pop` | O(1) | `top` already identifies the node and its successor. |
| `peek` | O(1) | It reads only `top->data`. |
| Destructor | O(n) | It pops every owned node once. |
| Copy constructor | O(n) | It visits and copies every source node once. |
| Copy assignment | O(m + n) | It deletes `m` old nodes and copies `n` source nodes. |

The O(1) `push` and `pop` rows are the payoff for choosing the front of the chain as `top`.

:::summary
## Chapter 5 Summary

| Concept | Key Point | Complexity |
| --- | --- | --- |
| Stack ADT | LIFO: push/pop/top/isEmpty | All O(1) |
| ArrayStack push | Double capacity when full | O(1) amortized |
| ArrayStack pop | Decrement topIdx | O(1) |
| LinkedStack push/pop | Prepend/remove head node | O(1) worst-case |
| std::stack pop() | Returns void — must call top() first | O(1) |
| Balanced brackets | Push openers, match closers | O(n) time, O(n) space |
| Infix→Postfix | Shunting-yard: precedence + associativity | O(n) |
| Postfix eval | Operand stack; pop b then a, push a op b | O(n) |
| Monotonic stack | Maintain sorted order; answers NGE queries | O(n) amortized |
| Min-Stack | Parallel min-tracker stack | O(1) getMin, push, pop |
| Iterative DFS | Explicit stack replaces call stack | O(V+E) |
| Amortized proof | Doubling → total copies < n → O(1)/op |  |
:::

## Exam Prep

The following problems are representative of CSE 2383 Honors exam questions. Work each before revealing the solution.

:::problem[Exam Q1 · standard]{difficulty="standard"}
An ArrayStack starts with capacity 1. After exactly 17 pushes, (a) what is the capacity, and (b) how many total element copies have occurred due to grows?

::::solution[Solution]
(a) Grows at push 1 (1→2), push 2 (2→4), push 4 (4→8), push 8 (8→16), push 16 (16→32). After 17 pushes capacity = **32**. (b) Copies: 1+2+4+8+16 = **31**.
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
Convert the infix expression `a + b * c - d / e` to postfix. Show each step of the operator stack.

::::solution[Solution]
a→out; +→push; b→out; \*: prec(\*)>prec(+)→push; c→out; -: prec(-)<prec(\*) →pop \*, prec(-)≤prec(+)→pop +, push -; d→out; /: prec(/)>prec(-) →push; e→out; end: pop /, pop -. Postfix: `a b c * + d e / -`.
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
Evaluate: `6 2 3 + - 3 8 2 / + *`.

::::solution[Solution]
6,2,3→stack. +: 2+3=5 → [6,5]. -: 6-5=1 → [1]. 3,8,2→stack=[1,3,8,2]. /: 8/2=4 → [1,3,4]. +: 3+4=7 → [1,7]. \*: 1\*7=7 → [7]. Answer: **7**.
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
Is `{[(])}` balanced? Trace the stack and identify the failure point.

::::solution[Solution]
Push {, push [, push (. See ]: top is ( ≠ [ → **mismatch at index 3** (the ]). Returns false.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
For MinStack, trace: push(3), push(5), push(2), push(2), pop(), pop(), getMin(). What does getMin return?

::::solution[Solution]
push(3): main=[3],mins=[3]. push(5): main=[3,5],mins=[3]. push(2): main=[3,5,2],mins=[3,2]. push(2): main=[3,5,2,2],mins=[3,2,2]. pop(): removes 2, 2==mins.top→pop mins; main=[3,5,2],mins=[3,2]. pop(): removes 2, 2==mins.top→pop mins; main=[3,5],mins=[3]. getMin()→mins.top()=**3**.
::::
:::

:::problem[Exam Q6 · standard]{difficulty="standard"}
In a LinkedStack, what is the time complexity of finding the minimum element? How does this compare to MinStack?

::::solution[Solution]
O(n) — you must traverse all nodes since there is no ordering. MinStack achieves O(1) by maintaining auxiliary state. Space trade-off: MinStack uses O(n) extra space for the min-stack (worst case, all elements pushed in decreasing order).
::::
:::

:::problem[Exam Q7 · challenge]{difficulty="challenge"}
Given histogram heights = [2, 1, 5, 6, 2, 3], find the largest rectangle area using a monotonic stack. Show stack state at each bar.

::::solution[Solution]
Append sentinel 0: [2,1,5,6,2,3,0]. Process with increasing stack:
 i=0(h=2): push 0. st=[0].
 i=1(h=1): h<h[0]=2 → pop 0: area=2\*(1-empty?1:1-(-1)-1)=2\*1=2. st empty, push 1. st=[1].
 i=2(h=5): push. st=[1,2].
 i=3(h=6): push. st=[1,2,3].
 i=4(h=2): h<h[3]=6→pop 3: area=6\*(4-2-1)=6\*1=6. h<h[2]=5→pop 2: area=5\*(4-1-1)=5\*2=10. push 4. st=[1,4].
 i=5(h=3): push. st=[1,4,5].
 i=6(h=0): h<h[5]=3→pop 5: area=3\*(6-4-1)=3\*1=3. h<h[4]=2→pop 4: area=2\*(6-1-1)=2\*4=8. h<h[1]=1→pop 1: area=1\*(6-empty?6:6-(-1))=1\*6=6. Largest = **10**, from height 5 spanning the two bars at indices 2 and 3.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
Design a queue using two stacks. State the enqueue and dequeue procedures, and give amortized time complexity for each operation.

::::solution[Solution]
Use stack `in` and stack `out`. **Enqueue**: push to `in` — O(1). **Dequeue**: if `out` is empty, pour all of `in` into `out` (reverse order); then pop from `out`. Each element is moved at most once from `in` to `out`, so the amortized cost per dequeue is O(1). This is covered in detail in Chapter 6.
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook. Generated for personal study use.
