---
title: "Binary Trees"
crumb: "Honors DSA · Chapter 7"
meta:
  - "Est. study time: ~60 min"
  - "Unit 3"
  - "CSE 2383 · MSState"
source: "dsa_ch7_binary_trees.html"
---

## 1. Tree Terminology

A **tree** is a hierarchical data structure composed of **nodes** connected by **edges**. Every tree has exactly one **root** — the topmost node with no parent. Trees arise constantly in computing: file systems, compilers, databases, and network routing all use tree-shaped structures.

:::callout-key[Key Definitions]
**Node** — a single element storing data (and pointers to children).

 **Edge** — a link connecting a parent node to a child node.

 **Root** — the unique node with no parent.

 **Leaf** — a node with no children (also called an external node).

 **Internal node** — any non-leaf node.

 **Parent / Child** — if an edge connects A to B and A is above B, then A is B's parent and B is A's child.

 **Siblings** — nodes that share the same parent.

 **Subtree** — a node and all of its descendants form a subtree.
:::

### Depth and Height

Two measurements describe where a node sits in a tree:

- **Depth of a node** — the number of edges on the path from the root to that node. The root has depth 0.
- **Height of a node** — the number of edges on the longest downward path from that node to a leaf. A leaf has height 0.
- **Height of the tree** — the height of the root, equivalently the maximum depth of any leaf.

:::callout-warning[Warning]
Some textbooks define height as the number of *nodes* on the longest path rather than edges. Always check which convention your instructor uses. This chapter uses the **edge-count** convention: a single-node tree has height 0.
:::

:::example[Example 7.1 — Reading a Tree Diagram]
Consider the tree below. Identify the root, all leaves, the depth of node D, the height of node B, and the height of the tree.

```
            A          ← depth 0
           / \
          B   C        ← depth 1
         / \   \
        D   E   F      ← depth 2
           /
          G            ← depth 3
```

::::answer[Answer]
Root: **A**. Leaves: **D, F, G** (no children). Depth of D: **2** (A→B→D, two edges). Height of B: **2** (longest path B→E→G). Height of tree: **3** (deepest leaf G is at depth 3).
::::

Work

Count edges from root to D: A to B is one edge, B to D is a second — so depth = 2. For the height of B, find the longest path going downward: B→E→G has two edges, while B→D has one — so height(B) = 2. The tree's height equals the maximum depth of any leaf, which is depth(G) = 3.
:::

:::example[Example 7.2 — Path and Ancestor]
In the tree above, list all ancestors of G and describe the path from A to G.

::::answer[Answer]
Ancestors of G: **E, B, A**. Path from A to G: **A → B → E → G** (length 3 edges).
::::

Work

An ancestor of a node X is any node on the path from the root to X (not including X itself). Starting from G and moving upward: parent of G is E, parent of E is B, parent of B is A — giving the ancestor set {E, B, A}.
:::

### Section 1 Practice

:::problem[Problem 1 easy]{difficulty="easy"}
A tree has the following edges (parent → child): A→B, A→C, B→D, B→E, C→F, F→G, F→H. What is the height of the tree? What is the depth of node H?

::::solution[Solution]
Draw the tree: A is root at depth 0. B and C are depth 1. D, E, F are depth 2. G, H are depth 3. The deepest leaves are G and H at depth 3, so the **height of the tree = 3**. Depth of H = **3** (path A→C→F→H, three edges).
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Node X is at depth 4 in a tree of height 7. What is the height of X (as a node, not the whole tree)? How many edges are on the path from X to the deepest descendant of X?

::::solution[Solution]
The tree has height 7, meaning the deepest leaf is at depth 7. Node X is at depth 4. The deepest leaf reachable below X could be at depth 7 (in the worst case). Height of X = (deepest leaf below X) − (depth of X) = 7 − 4 = **3**. So there are 3 edges from X down to its deepest descendant.
::::
:::

## 2. Binary Tree Properties

A **binary tree** is a tree where every node has *at most two children*, conventionally called the **left child** and the **right child**. This simple constraint unlocks powerful structural guarantees that make binary trees the backbone of BSTs, heaps, and expression evaluators.

### Structural Classifications

| Type | Definition | Example Use |
| --- | --- | --- |
| **Full** | Every node has 0 or 2 children (never exactly 1) | Expression trees |
| **Complete** | All levels fully filled except possibly the last, which is filled left-to-right | Binary heaps |
| **Perfect** | All internal nodes have 2 children AND all leaves are at the same depth | Theoretical analysis |
| **Degenerate / Skewed** | Every internal node has exactly one child (essentially a linked list) | Worst-case BST |

:::callout-intuition[Intuition]
Perfect ⊂ Complete ⊂ Full is *not* accurate — "full" and "complete" are independent. A complete tree need not be full (the last level may have nodes with one child via the left-to-right fill rule), and a full tree need not be complete (levels can have gaps as long as every node has 0 or 2 children).
:::

### Key Formulas

- **Max nodes at level $i$**: $2^i$ (root is level 0).
- **Max nodes in a perfect tree of height $h$**: $2^{h+1} - 1$.
- **Height of a complete tree with $n$ nodes**: $\lfloor \log_2 n \rfloor$.
- **Number of leaves in a full binary tree with $n$ internal nodes**: $n + 1$.

:::example[Example 7.3 — Counting Nodes and Height]
A complete binary tree has 100 nodes. What is its height? How many nodes are at the deepest level?

::::answer[Answer]
Height = $\lfloor \log_2 100 \rfloor = \lfloor 6.64 \rfloor = \mathbf{6}$. The last level (level 6) contains $100 - (2^6 - 1) = 100 - 63 = \mathbf{37}$ nodes.
::::

Work

A perfect tree of height 5 has $2^6 - 1 = 63$ nodes. Since 100 > 63, we need a level 6. A perfect tree of height 6 would have $2^7 - 1 = 127$ nodes. With 100 nodes we don't fill level 6 completely — the number of nodes at level 6 is $100 - 63 = 37$.
:::

:::example[Example 7.4 — Classifying a Tree]
A binary tree has 7 nodes arranged as a perfect tree of height 2. Is it full? Complete? Degenerate?

::::answer[Answer]
**Full** — yes (every internal node has exactly 2 children). **Complete** — yes (all levels filled, last level filled left-to-right trivially). **Degenerate** — no.
::::
:::

:::example[Example 7.5 — Full but Not Complete]
Construct a tree that is full but not complete.

::::answer[Answer]
Any full tree where the last level is not filled strictly left-to-right works.
::::

Work

```
        A
       / \
      B   C
         / \
        D   E
```

Every node has 0 or 2 children (A has 2, B has 0, C has 2, D has 0, E has 0) — so it is **full**. But the last level has nodes D and E under the right child only; a complete tree would require B to have children before C's children can appear — so it is **not complete**.
:::

### Section 2 Practice

:::problem[Problem 3 easy]{difficulty="easy"}
A perfect binary tree has height 4. How many total nodes does it contain? How many leaf nodes?

::::solution[Solution]
Total nodes = $2^{h+1} - 1 = 2^5 - 1 = \mathbf{31}$. Leaves are all nodes at the deepest level (level 4): $2^4 = \mathbf{16}$ leaves. Alternatively, leaves = (internal nodes) + 1 = 15 + 1 = 16.
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
A complete binary tree has height 5. What is the minimum and maximum number of nodes it can contain?

::::solution[Solution]
Height 5 means at least one node is at level 5. **Minimum**: the tree fills all levels 0–4 perfectly and has exactly one node at level 5. Nodes in levels 0–4 = $2^5 - 1 = 31$. Adding 1 node at level 5 gives **32 nodes minimum**. **Maximum**: fill level 5 completely — $2^6 - 1 = \mathbf{63}$ nodes.
::::
:::

## 3. Tree Representation

### Linked Node Representation

The most natural representation stores each node as a struct with pointers to its left and right children:

```cpp
struct Node {
    int val;
    Node* left;
    Node* right;

    // Constructor for convenience
    Node(int v) : val(v), left(nullptr), right(nullptr) {}
};
```

Building a small tree manually:

```cpp
Node* root = new Node(1);
root->left  = new Node(2);
root->right = new Node(3);
root->left->left  = new Node(4);
root->left->right = new Node(5);
// Tree shape:
//       1
//      / \
//     2   3
//    / \
//   4   5
```

:::callout-pitfall[Pitfall]
Always initialize `left` and `right` to `nullptr`. An uninitialized pointer holds a garbage address; dereferencing it causes undefined behavior and hard-to-debug crashes.
:::

### Array Representation for Complete Trees

When the tree is complete (or nearly so), storing it in a 0-indexed array is more cache-friendly and eliminates pointer overhead. The mapping rules are:

- Node at index $i$ has its **parent** at index $\lfloor (i-1)/2 \rfloor$ (for $i > 0$).
- Node at index $i$ has its **left child** at index $2i + 1$.
- Node at index $i$ has its **right child** at index $2i + 2$.

:::example[Example 7.6 — Array Indexing]
A complete binary tree is stored in the array `[10, 20, 30, 40, 50, 60, 70]`. What are the children of the node at index 1 (value 20)? What is the parent of the node at index 5 (value 60)?

::::answer[Answer]
Children of index 1: left child at $2(1)+1 = 3$ (value **40**), right child at $2(1)+2 = 4$ (value **50**). Parent of index 5: $\lfloor(5-1)/2\rfloor = \lfloor 2 \rfloor = 2$ (value **30**).
::::
:::

:::example[Example 7.7 — Drawing from Array]
Draw the tree represented by `[5, 3, 8, 1, 4, 7, 9]`.

::::answer[Answer]
```
         5        (index 0)
        / \
       3   8      (indices 1, 2)
      / \ / \
     1  4 7  9   (indices 3, 4, 5, 6)
```
::::
:::

:::callout-connect[Connection]
The array representation is exactly how binary heaps are stored. When you study heaps in Chapter 10, these index formulas will be the core of `heapify-up` and `heapify-down`.
:::

### Section 3 Practice

:::problem[Problem 5 easy]{difficulty="easy"}
In a 0-indexed array representation, a node is stored at index 11. What index holds its parent? Its left child? Its right child?

::::solution[Solution]
Parent: $\lfloor(11-1)/2\rfloor = \lfloor 5 \rfloor = \mathbf{5}$. Left child: $2(11)+1 = \mathbf{23}$. Right child: $2(11)+2 = \mathbf{24}$.
::::
:::

:::problem[Problem 6 standard]{difficulty="standard"}
Write a C++ function `bool isLeaf(vector<int>& arr, int i)` that returns true if node at index `i` is a leaf in the complete binary tree stored in `arr`.

::::solution[Solution]
```cpp
bool isLeaf(vector<int>& arr, int i) {
    int n = arr.size();
    int leftChild  = 2 * i + 1;
    int rightChild = 2 * i + 2;
    // A node is a leaf if both children indices are out of bounds
    return leftChild >= n && rightChild >= n;
}
```

Since it's a complete tree, if the left child is out of bounds, the right child is too — so checking `leftChild >= n` alone suffices, but the explicit check on both is clearer.
::::
:::

## 4. Tree Traversals

A **traversal** visits every node in a tree exactly once in a defined order. The order matters — different traversals expose different structural information. There are four fundamental traversals for binary trees.

### Depth-First Traversals (Recursive)

All three depth-first orders follow the same recursive skeleton; only the position of the "visit root" step changes:

```cpp
// Preorder: Root → Left → Right
void preorder(Node* root) {
    if (root == nullptr) return;
    cout << root->val << " ";  // visit
    preorder(root->left);
    preorder(root->right);
}

// Inorder: Left → Root → Right
void inorder(Node* root) {
    if (root == nullptr) return;
    inorder(root->left);
    cout << root->val << " ";  // visit
    inorder(root->right);
}

// Postorder: Left → Right → Root
void postorder(Node* root) {
    if (root == nullptr) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->val << " ";  // visit
}
```

:::callout-intuition[Intuition]
**Preorder** — you see the parent before any of its descendants. Good for copying or serializing a tree.

 **Inorder** — for a BST, inorder gives keys in sorted ascending order. This is arguably the most useful traversal.

 **Postorder** — you process all children before the parent. Good for deleting a tree (free children first) or evaluating expression trees.
:::

### Level-Order Traversal (BFS)

Level-order visits nodes level by level, left to right. It uses a queue:

```cpp
#include <queue>
void levelOrder(Node* root) {
    if (root == nullptr) return;
    queue<Node*> q;
    q.push(root);
    while (!q.empty()) {
        Node* curr = q.front();
        q.pop();
        cout << curr->val << " ";
        if (curr->left)  q.push(curr->left);
        if (curr->right) q.push(curr->right);
    }
}
```

:::example[Example 7.8 — All Four Traversals]
Give all four traversal outputs for the tree below.

```
           1
          / \
         2   3
        / \   \
       4   5   6
```

::::answer[Answer]
**Preorder** (Root→L→R): 1 2 4 5 3 6

 **Inorder** (L→Root→R): 4 2 5 1 3 6

 **Postorder** (L→R→Root): 4 5 2 6 3 1

 **Level-order**: 1 2 3 4 5 6
::::

Work

*Preorder*: Visit 1 first, then recurse left subtree (visit 2, recurse to 4 — leaf, recurse to 5 — leaf), then recurse right subtree (visit 3, skip null left, recurse to 6 — leaf). *Inorder*: Go as far left as possible (4), back to 2, then 5, back to 1, then right side: 3 has no left so visit 3, then 6. *Postorder*: Process 4, 5, then 2; process 6, then 3; finally 1. *Level-order*: Queue starts with {1}. Dequeue 1, enqueue 2 and 3. Dequeue 2, enqueue 4 and 5. Dequeue 3, enqueue 6. Dequeue 4 (leaf), 5 (leaf), 6 (leaf).
:::

:::example[Example 7.9 — Reconstructing a Tree]
Given preorder = [A, B, D, E, C, F] and inorder = [D, B, E, A, C, F], reconstruct the tree.

::::answer[Answer]
```
        A
       / \
      B   C
     / \   \
    D   E   F
```
::::

Work

The first element of preorder is always the root: **A**. Find A in inorder: everything to its left (D, B, E) is the left subtree; everything to its right (C, F) is the right subtree. The next preorder element in the left partition is B — so B is the root of the left subtree. Find B in [D, B, E]: D is B's left child, E is B's right child. For the right subtree, preorder gives C first — C's right child is F.
:::

### Section 4 Practice

:::problem[Problem 7 easy]{difficulty="easy"}
Write the preorder, inorder, and postorder traversals for this tree:

```
        10
       /  \
      5    15
     / \   /
    3   7 12
```

::::solution[Solution]
**Preorder**: 10 5 3 7 15 12

 **Inorder**: 3 5 7 10 12 15

 **Postorder**: 3 7 5 12 15 10
::::
:::

:::problem[Problem 8 standard]{difficulty="standard"}
Modify the level-order traversal to print each level on its own line. Hint: track how many nodes are currently in the queue at the start of each level.

::::solution[Solution]
```cpp
void levelOrderLines(Node* root) {
    if (!root) return;
    queue<Node*> q;
    q.push(root);
    while (!q.empty()) {
        int levelSize = q.size();  // nodes on this level
        for (int i = 0; i < levelSize; i++) {
            Node* curr = q.front(); q.pop();
            cout << curr->val;
            if (i < levelSize - 1) cout << " ";
            if (curr->left)  q.push(curr->left);
            if (curr->right) q.push(curr->right);
        }
        cout << "\n";
    }
}
```
::::
:::

## 5. Tree Algorithms

With traversals in hand, most tree algorithms reduce to elegant recursive functions. The key insight: *every subtree is itself a tree*, so recursive solutions naturally apply the same logic to every node.

### Height

```cpp
int height(Node* root) {
    if (root == nullptr) return -1;  // height of empty tree = -1
    int leftH  = height(root->left);
    int rightH = height(root->right);
    return 1 + max(leftH, rightH);
}
// height of a single-node tree: 1 + max(-1, -1) = 0 ✓
```

:::callout-warning[Warning]
If you define height as number of nodes rather than edges, the base case returns 0 for null and 1 for a leaf. Be consistent with your definition throughout any single problem.
:::

### Count Nodes

```cpp
int countNodes(Node* root) {
    if (root == nullptr) return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}
```

### Check Balance

A tree is **height-balanced** if, for every node, the heights of the left and right subtrees differ by at most 1:

```cpp
// Returns height if balanced, -2 as sentinel if unbalanced
int checkBalanced(Node* root) {
    if (root == nullptr) return -1;
    int lh = checkBalanced(root->left);
    if (lh == -2) return -2;
    int rh = checkBalanced(root->right);
    if (rh == -2) return -2;
    if (abs(lh - rh) > 1) return -2;  // unbalanced here
    return 1 + max(lh, rh);
}

bool isBalanced(Node* root) {
    return checkBalanced(root) != -2;
}
```

### Mirror / Flip

```cpp
void mirror(Node* root) {
    if (root == nullptr) return;
    swap(root->left, root->right);
    mirror(root->left);
    mirror(root->right);
}
```

### Path from Root to Node

```cpp
bool findPath(Node* root, int target, vector<int>& path) {
    if (root == nullptr) return false;
    path.push_back(root->val);
    if (root->val == target) return true;
    if (findPath(root->left, target, path)) return true;
    if (findPath(root->right, target, path)) return true;
    path.pop_back();  // backtrack
    return false;
}
```

:::example[Example 7.10 — Tracing height()]
Trace `height()` on the tree with root 1, left child 2 (with left child 4), and right child 3.

::::answer[Answer]
height(root=1) = 1 + max(height(2), height(3)) = 1 + max(1 + max(height(4), height(null)), height(null)) = 1 + max(1 + max(0, -1), -1) = 1 + max(1, -1) = 1 + 1 = **2**.
::::
:::

:::example[Example 7.11 — Finding a Path]
Using `findPath()`, trace the path to value 5 in the tree: root=1, 1→2, 1→3, 2→4, 2→5.

::::answer[Answer]
Path = [1, 2, 5]. The function pushes 1, goes left to 2, pushes 2, tries left (4) — pushes 4, not found, backtracks (pops 4). Tries right of 2 (5) — pushes 5, found! Returns true with path = [1, 2, 5].
::::
:::

### Section 5 Practice

:::problem[Problem 9 standard]{difficulty="standard"}
Write a recursive C++ function `int sumNodes(Node* root)` that returns the sum of all node values in the tree.

::::solution[Solution]
```cpp
int sumNodes(Node* root) {
    if (root == nullptr) return 0;
    return root->val + sumNodes(root->left) + sumNodes(root->right);
}
```
::::
:::

:::problem[Problem 10 challenge]{difficulty="challenge"}
Write a C++ function `int diameter(Node* root)` that returns the diameter of the tree — the length (in edges) of the longest path between any two nodes. The path does not need to pass through the root.

::::solution[Solution]
```cpp
int diameterHelper(Node* root, int& maxDiam) {
    if (root == nullptr) return -1;
    int lh = diameterHelper(root->left, maxDiam);
    int rh = diameterHelper(root->right, maxDiam);
    // Path through this node spans lh + rh + 2 edges
    maxDiam = max(maxDiam, lh + rh + 2);
    return 1 + max(lh, rh);
}

int diameter(Node* root) {
    int maxDiam = 0;
    diameterHelper(root, maxDiam);
    return maxDiam;
}
```

Each call returns the height of its subtree. The diameter through any node is the sum of heights of its two subtrees plus 2 (for the edges connecting them). We track the maximum seen across all nodes.
::::
:::

## 6. Expression Trees

An **expression tree** is a binary tree where:

- **Internal nodes** hold operators (`+`, `-`, `*`, `/`).
- **Leaves** hold operands (numbers or variables).

Expression trees make operator precedence and associativity explicit through tree structure — no parentheses needed. They are always **full binary trees** (every operator takes exactly two operands).

### Traversal Gives Notation

| Traversal | Output notation | Example for (3 + 4) \* 5 |
| --- | --- | --- |
| Inorder (with parens) | Infix | (3 + 4) \* 5 |
| Preorder | Prefix (Polish) | \* + 3 4 5 |
| Postorder | Postfix (RPN) | 3 4 + 5 \* |

### Building from Postfix

Algorithm: scan the postfix expression left to right. For each token:

- If it is an **operand**, create a leaf node and push onto a stack.
- If it is an **operator**, pop two nodes (right then left), create an operator node with those as children, push the new node.

At the end, the stack contains the root.

```cpp
#include <stack>
#include <string>
#include <sstream>

struct ExprNode {
    string token;
    ExprNode* left;
    ExprNode* right;
    ExprNode(string t) : token(t), left(nullptr), right(nullptr) {}
};

bool isOperator(const string& t) {
    return t == "+" || t == "-" || t == "*" || t == "/";
}

ExprNode* buildFromPostfix(const string& postfix) {
    stack<ExprNode*> st;
    istringstream iss(postfix);
    string token;
    while (iss >> token) {
        ExprNode* node = new ExprNode(token);
        if (isOperator(token)) {
            node->right = st.top(); st.pop();
            node->left  = st.top(); st.pop();
        }
        st.push(node);
    }
    return st.top();
}
```

### Recursive Evaluation

```cpp
double evaluate(ExprNode* root) {
    if (root == nullptr) return 0;
    if (!isOperator(root->token))
        return stod(root->token);   // leaf: convert to number
    double left  = evaluate(root->left);
    double right = evaluate(root->right);
    if (root->token == "+") return left + right;
    if (root->token == "-") return left - right;
    if (root->token == "*") return left * right;
    if (root->token == "/") return left / right;
    return 0;
}
```

:::example[Example 7.12 — Build from Postfix]
Build the expression tree for the postfix expression `5 3 2 * + 4 -`. Then evaluate it and give the infix representation.

::::answer[Answer]
Tree (root to leaves):

```
          -
         / \
        +   4
       / \
      5   *
         / \
        3   2
```

Evaluation: 3 \* 2 = 6, 5 + 6 = 11, 11 - 4 = **7**. Infix (inorder with parens): **((5 + (3 \* 2)) - 4)**.
::::

Work

Scan left to right: push 5 (leaf), push 3 (leaf), push 2 (leaf). See `*`: pop 2 (right), pop 3 (left), create (\*,3,2) and push. See `+`: pop (\*,3,2) (right), pop 5 (left), create (+,5,\*) and push. Push 4. See `-`: pop 4 (right), pop (+,5,\*) (left), create (-,(+,5,\*),4) — this is the root.
:::

:::example[Example 7.13 — Expression Tree to Notations]
Given the expression tree for `a + b * c`, write the preorder and postorder traversals.

::::answer[Answer]
```
       +
      / \
     a   *
        / \
       b   c
```

**Preorder (prefix)**: + a \* b c

 **Postorder (postfix)**: a b c \* +
::::
:::

### Section 6 Practice

:::problem[Problem 11 easy]{difficulty="easy"}
Convert the postfix expression `6 2 / 3 4 * +` to an expression tree. Evaluate the expression.

::::solution[Solution]
```
        +
       / \
      /   *
     6 /2  3 4
```

More clearly:

```
           +
          / \
         /   *
        / \  / \
       6   2 3  4
```

Evaluation: 6/2 = 3, 3\*4 = 12, 3 + 12 = **15**.
::::
:::

:::problem[Problem 12 standard]{difficulty="standard"}
The inorder traversal of an expression tree does not always produce fully parenthesized infix. Write a C++ function `string toInfix(ExprNode* root)` that produces a fully parenthesized infix string (e.g., `((3+4)*5)`).

::::solution[Solution]
```cpp
string toInfix(ExprNode* root) {
    if (root == nullptr) return "";
    if (!isOperator(root->token)) return root->token;  // leaf
    string left  = toInfix(root->left);
    string right = toInfix(root->right);
    return "(" + left + root->token + right + ")";
}
```

For each operator node, wrap the entire sub-expression in parentheses. Leaves simply return their token.
::::
:::

## 7. Exam Prep

The following questions are representative of short-answer exam problems at MSState. Try each before opening the solution.

:::problem[Exam Q1 easy]{difficulty="easy"}
Define the terms *height* and *depth* for a binary tree. A node is at depth 5 in a tree of height 9. What is the maximum height that node could have as a subtree root?

::::solution[Solution]
**Depth** of a node: number of edges from the root to that node (root has depth 0). **Height** of a node: number of edges on the longest downward path to a leaf (leaf has height 0). Height of tree = height of root.

 If the node is at depth 5 in a tree of height 9, the deepest leaf below it is at depth 9. Its height as a subtree root = 9 - 5 = **4**.
::::
:::

:::problem[Exam Q2 easy]{difficulty="easy"}
A binary tree has 50 nodes. What is the minimum possible height? What tree shape achieves this minimum?

::::solution[Solution]
Height is minimized when nodes are distributed as evenly as possible — i.e., a **complete binary tree**. Minimum height = $\lfloor \log_2 50 \rfloor = \lfloor 5.64 \rfloor = \mathbf{5}$.
::::
:::

:::problem[Exam Q3 standard]{difficulty="standard"}
Give the preorder, inorder, and postorder traversals of the following tree:

```
          8
         / \
        3   10
       / \    \
      1   6    14
         / \   /
        4   7 13
```

::::solution[Solution]
**Preorder**: 8 3 1 6 4 7 10 14 13

 **Inorder**: 1 3 4 6 7 8 10 13 14

 **Postorder**: 1 4 7 6 3 13 14 10 8
::::
:::

:::problem[Exam Q4 standard]{difficulty="standard"}
A complete binary tree is stored in an array of size 15. Node at index 6 has value 42. What are the indices and values if the full array is [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]? State the parent, left child, and right child of index 6.

::::solution[Solution]
Index 6 has value **7** (1-indexed values map to 0-indexed: arr[6] = 7).

 Parent: $\lfloor(6-1)/2\rfloor = 2$, value **3**.

 Left child: $2(6)+1 = 13$, value **14**.

 Right child: $2(6)+2 = 14$, value **15**.
::::
:::

:::problem[Exam Q5 standard]{difficulty="standard"}
Explain why postorder traversal is appropriate for deleting all nodes of a binary tree in C++.

::::solution[Solution]
In postorder, both children are visited (and deleted) before the parent. If you deleted the parent first (preorder), you would lose the pointers to its children, causing a memory leak. Postorder ensures every child node is freed before its parent, so no pointer is orphaned.
::::
:::

:::problem[Exam Q6 standard]{difficulty="standard"}
Write a recursive C++ function `bool identical(Node* a, Node* b)` that returns true if two binary trees are structurally identical and contain the same values at each position.

::::solution[Solution]
```cpp
bool identical(Node* a, Node* b) {
    if (a == nullptr && b == nullptr) return true;
    if (a == nullptr || b == nullptr) return false;
    return (a->val == b->val)
        && identical(a->left,  b->left)
        && identical(a->right, b->right);
}
```
::::
:::

:::problem[Exam Q7 challenge]{difficulty="challenge"}
Given only the inorder and preorder traversal sequences, reconstruct the tree and give its postorder traversal.

 Preorder: [F, B, A, D, C, E, G, I, H]

 Inorder: [A, B, C, D, E, F, G, H, I]

::::solution[Solution]
Root = F (first in preorder). In inorder, F splits: left = {A,B,C,D,E}, right = {G,H,I}.

 Left subtree preorder = [B,A,D,C,E]. Root = B. In {A,B,C,D,E}: left of B = {A}, right = {C,D,E}.

 A is a leaf. Right of B: preorder [D,C,E], root = D; inorder {C,D,E}: left = C, right = E (both leaves).

 Right subtree of F: preorder [G,I,H], root = G; inorder {G,H,I}: left of G = empty, right = {H,I}. Preorder [I,H]: root = I; inorder {H,I}: left = H, right = empty.

```
              F
             / \
            B   G
           / \   \
          A   D   I
             / \ /
            C  E H
```

**Postorder**: A C E D B H I G F
::::
:::

:::problem[Exam Q8 challenge]{difficulty="challenge"}
Evaluate the expression tree built from postfix `2 3 4 * + 5 6 - *`. Show all steps.

::::solution[Solution]
Stack trace: push 2, push 3, push 4. See `*`: pop 4 and 3, push 3\*4=12. See `+`: pop 12 and 2, push 2+12=14. Push 5, push 6. See `-`: pop 6 and 5, push 5-6=-1. See `*`: pop -1 and 14, push 14\*(-1)=-14. Final answer: **-14**.
::::
:::

## Mixed Practice

:::problem[Mixed 1 easy]{difficulty="easy"}
How many nodes are in a perfect binary tree of height 6?

::::solution[Solution]
$2^{h+1} - 1 = 2^7 - 1 = \mathbf{127}$ nodes.
::::
:::

:::problem[Mixed 2 standard]{difficulty="standard"}
A binary tree has inorder traversal [2, 5, 6, 7, 11, 15, 19] and postorder traversal [2, 6, 5, 15, 19, 11, 7]. Reconstruct the tree and give its preorder traversal.

::::solution[Solution]
Last in postorder = root = **7**. In inorder, 7 splits: left = {2,5,6}, right = {11,15,19}.

 Left postorder = [2,6,5] → root = 5. In {2,5,6}: left = {2}, right = {6}. Both leaves.

 Right postorder = [15,19,11] → root = 11. In {11,15,19}: left = empty (11 is leftmost), right = {15,19}. Postorder [15,19] → root = 19. In {15,19}: left = 15, right = empty.

```
           7
          / \
         5   11
        / \    \
       2   6    19
               /
              15
```

**Preorder**: 7 5 2 6 11 19 15
::::
:::

:::problem[Mixed 3 standard]{difficulty="standard"}
Write a C++ function `int countLeaves(Node* root)` that returns the number of leaf nodes in a binary tree.

::::solution[Solution]
```cpp
int countLeaves(Node* root) {
    if (root == nullptr) return 0;
    if (root->left == nullptr && root->right == nullptr)
        return 1;  // it's a leaf
    return countLeaves(root->left) + countLeaves(root->right);
}
```
::::
:::

:::problem[Mixed 4 challenge]{difficulty="challenge"}
Prove (by induction or argument) that in any full binary tree, the number of leaves is exactly one more than the number of internal nodes.

::::solution[Solution]
**Base case**: A single node (the root, which is a leaf) — 1 leaf, 0 internal nodes. 1 = 0 + 1. True.

 **Inductive step**: Assume any full binary tree with $k$ internal nodes has $k+1$ leaves. Take a full binary tree with $k+1$ internal nodes. Its root has two children. If we remove the two children of any leaf-pair (a pair of siblings both being leaves), we convert the parent from internal to a leaf — decreasing internal nodes by 1 and leaves by 1 (net: still $\Delta = +1$ for leaves over internals). By induction the claim holds for the smaller tree, so it holds for the full tree.

 **Equivalently**: count edges. Every internal node contributes 2 edges downward; every node except the root has 1 edge from its parent. So $2I = I + L - 1$ (where I = internal, L = leaves), giving $I + 1 = L$.
::::
:::

:::problem[Mixed 5 challenge]{difficulty="challenge"}
Design a C++ function `vector<int> rightSideView(Node* root)` that returns the values visible when looking at the tree from the right side (the rightmost node at each level).

::::solution[Solution]
```cpp
vector<int> rightSideView(Node* root) {
    vector<int> result;
    if (!root) return result;
    queue<Node*> q;
    q.push(root);
    while (!q.empty()) {
        int sz = q.size();
        for (int i = 0; i < sz; i++) {
            Node* curr = q.front(); q.pop();
            if (i == sz - 1) result.push_back(curr->val);  // rightmost
            if (curr->left)  q.push(curr->left);
            if (curr->right) q.push(curr->right);
        }
    }
    return result;
}
```

Level-order traversal; at each level record the last node dequeued (that is the rightmost node visible from the right).
::::
:::

:::summary
## Chapter 7 Summary

Binary trees are hierarchical structures with at most two children per node. Their recursive definition makes recursive algorithms natural and elegant.

| Operation | Time Complexity | Notes |
| --- | --- | --- |
| Preorder / Inorder / Postorder traversal | $O(n)$ | Every node visited exactly once |
| Level-order traversal (BFS) | $O(n)$ | Uses a queue; $O(n)$ space |
| Height computation | $O(n)$ | Must visit all nodes to find max depth |
| Count nodes | $O(n)$ | Simple postorder accumulation |
| Find path to node | $O(n)$ | May need to explore entire tree |
| Mirror / flip | $O(n)$ | Swap left/right at every node |
| Build from postfix (expression tree) | $O(n)$ | Stack-based, one pass |
| Evaluate expression tree | $O(n)$ | Postorder traversal |

### Key Takeaways

- Depth is measured from root down; height is measured from the node up to its deepest leaf.
- A complete tree of $n$ nodes has height $\lfloor \log_2 n \rfloor$, making it efficient for heap storage.
- The three DFS traversals differ only in when the root is visited relative to its subtrees.
- Inorder traversal of a BST produces sorted output — a property leveraged throughout Chapter 8.
- Expression trees are always full; postorder evaluation is the natural recursive evaluation order.
:::
