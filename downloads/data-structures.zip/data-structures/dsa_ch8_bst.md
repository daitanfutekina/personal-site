---
title: "Binary Search Trees"
crumb: "Honors DSA · Chapter 8"
meta:
  - "Est. study time: ~65 min"
  - "Unit 3"
  - "CSE 2383 · MSState"
source: "dsa_ch8_bst.html"
---

## 1. The BST Property

A **Binary Search Tree (BST)** is a binary tree with one additional invariant on every node:

:::callout-key[BST Invariant]
For every node $N$ in the tree: all values in $N$'s **left subtree** are strictly less than $N$'s value, and all values in $N$'s **right subtree** are strictly greater than $N$'s value. This must hold for every node, not just the root.
:::

This property is what makes BSTs useful: at every node, you can eliminate half the remaining search space by comparing your target to the node's key. The struct is identical to a generic binary tree node:

```cpp
struct Node {
    int val;
    Node* left;
    Node* right;
    Node(int v) : val(v), left(nullptr), right(nullptr) {}
};
```

### Verifying the BST Property

A common mistake is checking only that a child's value is less/greater than its immediate parent. The invariant applies to entire subtrees. The correct approach uses a min/max range propagated down the tree:

```cpp
bool isBST(Node* root, long long minVal, long long maxVal) {
    if (root == nullptr) return true;
    if (root->val <= minVal || root->val >= maxVal) return false;
    return isBST(root->left,  minVal,    root->val)
        && isBST(root->right, root->val, maxVal);
}

// Top-level call:
bool isValidBST(Node* root) {
    return isBST(root, LLONG_MIN, LLONG_MAX);
}
```

:::example[Example 8.1 — Is This a Valid BST?]
Determine whether the following tree satisfies the BST property.

```
        10
       /  \
      5    15
     / \
    3   7
         \
          12   ← Problem!
```

::::answer[Answer]
**Not a valid BST.** Node 12 is in the left subtree of 10, but 12 > 10 — this violates the BST invariant. The immediate parent check (7 < 12) passes, but the range check from the root fails.
::::

Work

When we recurse left from 10, the maximum allowed value for any node in that subtree is 10. Node 12 exceeds that bound, so the BST property is violated.
:::

:::example[Example 8.2 — Building a Valid BST]
Insert the keys 8, 4, 12, 2, 6, 10, 14 into an initially empty BST (in that order). Draw the resulting tree.

::::answer[Answer]
```
            8
           / \
          4   12
         / \ /  \
        2  6 10  14
```

This is a perfect BST of height 2, and each subtree satisfies the invariant.
::::
:::

### Section 1 Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Is the following tree a valid BST? If not, identify the violating node.

```
       20
      /  \
    10    30
   /  \
  5    25
```

::::solution[Solution]
**Not valid.** Node 25 is in the left subtree of 20, so it must be less than 20. But 25 > 20 — violation. The immediate parent check (25 > 10) is irrelevant; the bound from 20 is what matters.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
Write the `isBST` check using inorder traversal instead of the min/max range method. Explain why this also works.

::::solution[Solution]
```cpp
bool isBSTInorder(Node* root, int& prev) {
    if (root == nullptr) return true;
    if (!isBSTInorder(root->left, prev)) return false;
    if (root->val <= prev) return false;  // not strictly increasing
    prev = root->val;
    return isBSTInorder(root->right, prev);
}

bool isValidBST(Node* root) {
    int prev = INT_MIN;
    return isBSTInorder(root, prev);
}
```

Inorder traversal of a valid BST visits keys in strictly ascending order. If any key is not greater than its predecessor in inorder sequence, the BST property is violated. This is equivalent to the range method but may be more intuitive.
::::
:::

## 2. Search

The BST property makes search elegant: at each node, compare the target to the current value. If equal, you found it. If less, go left. If greater, go right. Every step eliminates one subtree.

### Recursive Search

```cpp
Node* search(Node* root, int target) {
    if (root == nullptr)       return nullptr;  // not found
    if (target == root->val)   return root;     // found
    if (target < root->val)    return search(root->left,  target);
    else                       return search(root->right, target);
}
```

### Iterative Search

```cpp
Node* searchIter(Node* root, int target) {
    while (root != nullptr) {
        if (target == root->val) return root;
        root = (target < root->val) ? root->left : root->right;
    }
    return nullptr;  // not found
}
```

:::callout-tip[Tip]
In practice, the iterative version is preferred over the recursive version for search because it avoids function call overhead and uses $O(1)$ stack space instead of $O(h)$. For a balanced tree of one million nodes, the iterative version needs at most 20 comparisons.
:::

### Time Complexity

Search follows exactly one root-to-leaf path. The number of comparisons equals the depth of the target (plus 1 for the null check). Therefore:

- **Best case**: $O(1)$ — target is the root.
- **Average case**: $O(\log n)$ — for a balanced tree, height is $\Theta(\log n)$.
- **Worst case**: $O(n)$ — for a degenerate (skewed) tree, height is $n-1$.

:::example[Example 8.3 — Tracing a Search]
Trace `search(root, 6)` on the BST: 8 is root, left=4 (left=2, right=6), right=12 (left=10, right=14).

::::answer[Answer]
Step 1: root=8, 6 < 8, go left. Step 2: root=4, 6 > 4, go right. Step 3: root=6, 6 == 6, return node. **Found in 3 comparisons.**
::::
:::

:::example[Example 8.4 — Unsuccessful Search]
Trace `search(root, 9)` on the same BST.

::::answer[Answer]
Step 1: 9 > 8, go right. Step 2: root=12, 9 < 12, go left. Step 3: root=10, 9 < 10, go left. Step 4: root=nullptr, return nullptr. **Not found in 4 comparisons.**
::::
:::

### Section 2 Practice

:::problem[Problem 3 easy]{difficulty="easy"}
In a BST with 1023 nodes that is perfectly balanced, what is the maximum number of comparisons needed to search for any value?

::::solution[Solution]
1023 = $2^{10} - 1$, so this is a perfect binary tree of height 9. Searching requires at most height + 1 = **10 comparisons** (one per level, plus the null check at the bottom).
::::
:::

:::problem[Problem 4 standard]{difficulty="standard"}
Write a function `bool contains(Node* root, int target)` that returns true if the target exists in the BST. Then write `int minimum(Node* root)` that returns the minimum value. Where is the minimum always found in a BST?

::::solution[Solution]
```cpp
bool contains(Node* root, int target) {
    while (root != nullptr) {
        if (target == root->val) return true;
        root = (target < root->val) ? root->left : root->right;
    }
    return false;
}

int minimum(Node* root) {
    // The minimum is always the leftmost node
    while (root->left != nullptr) root = root->left;
    return root->val;
}
```

The minimum is always at the **leftmost node** — keep going left until you can't. Similarly, the maximum is the rightmost node.
::::
:::

## 3. Insertion

Inserting into a BST follows the same path as an unsuccessful search: navigate down the tree following the BST property until you reach a null pointer, then attach the new node there. **Insertion never restructures existing nodes** — it only attaches a new leaf.

```cpp
// Recursive insert — returns the (possibly updated) subtree root
Node* insert(Node* root, int val) {
    if (root == nullptr) return new Node(val);  // found insertion point
    if (val < root->val)
        root->left  = insert(root->left,  val);
    else if (val > root->val)
        root->right = insert(root->right, val);
    // if val == root->val: duplicate, do nothing (or handle as needed)
    return root;
}
```

```cpp
// Iterative insert
Node* insertIter(Node* root, int val) {
    Node* newNode = new Node(val);
    if (root == nullptr) return newNode;
    Node* curr   = root;
    Node* parent = nullptr;
    while (curr != nullptr) {
        parent = curr;
        if (val < curr->val)       curr = curr->left;
        else if (val > curr->val)  curr = curr->right;
        else return root;  // duplicate
    }
    if (val < parent->val) parent->left  = newNode;
    else                   parent->right = newNode;
    return root;
}
```

:::example[Example 8.5 — Insertion Trace]
Start with the BST {8, 4, 12} and insert 5, then 11. Show the tree after each insertion.

::::answer[Answer]
After inserting 8, 4, 12:

```
    8
   / \
  4   12
```

Insert 5: 5 < 8 → go left (4), 5 > 4 → go right (null), attach. Tree:

```
    8
   / \
  4   12
   \
    5
```

Insert 11: 11 > 8 → go right (12), 11 < 12 → go left (null), attach. Tree:

```
    8
   / \
  4   12
   \  /
    5 11
```
::::
:::

:::callout-warning[Warning]
Insertion order determines tree shape. Inserting a sorted sequence (e.g., 1, 2, 3, 4, 5) into an empty BST produces a degenerate right-skewed tree of height $n-1$. The first inserted value always becomes the root and is never moved.
:::

### Section 3 Practice

:::problem[Problem 5 easy]{difficulty="easy"}
Show the BST that results from inserting the following keys in order into an empty tree: 50, 30, 70, 20, 40, 60, 80.

::::solution[Solution]
```
           50
          /  \
        30    70
       /  \  /  \
      20  40 60  80
```

This happens to produce a perfect BST of height 2. The resulting tree shape depends entirely on insertion order.
::::
:::

:::problem[Problem 6 standard]{difficulty="standard"}
What BST results from inserting 1, 2, 3, 4, 5 in that order? What is the height? What is the time complexity of searching in this BST?

::::solution[Solution]
```
1
 \
  2
   \
    3
     \
      4
       \
        5
```

Height = 4. This is a degenerate (right-skewed) BST. Search is $O(n)$ in the worst case — equivalent to a linked list. This motivates the need for balanced BSTs (Chapter 9).
::::
:::

## 4. Deletion

Deletion is the most complex BST operation because removing a node with two children leaves a gap that must be filled by a valid BST value. There are three cases:

### Case 1: Deleting a Leaf Node

Simply remove it — set the parent's pointer to `nullptr`.

```
Before:        After deleting 6:
   8               8
  / \             / \
 4   12           4   12
  \
   6
```

### Case 2: Node with One Child

Bypass the node — connect the parent directly to the node's only child.

```
Before:        After deleting 4:
   8               8
  / \             / \
 4   12           6   12
  \
   6
```

### Case 3: Node with Two Children

Replace the node's value with its **inorder successor** (the smallest value in its right subtree — the leftmost node of the right subtree), then delete the inorder successor from its original position. The inorder successor has at most one child (no left child), so its deletion reduces to Case 1 or Case 2.

```
Before:        Find inorder successor of 8 = 10 (leftmost in right subtree):
   8               10
  / \             /  \
 4   12           4    12
    / \                 \
   10  14               14
```

```cpp
// Find and return the minimum node in a subtree
Node* findMin(Node* root) {
    while (root->left != nullptr) root = root->left;
    return root;
}

// Recursive delete — returns updated subtree root
Node* deleteNode(Node* root, int val) {
    if (root == nullptr) return nullptr;  // not found

    if (val < root->val) {
        root->left  = deleteNode(root->left,  val);
    } else if (val > root->val) {
        root->right = deleteNode(root->right, val);
    } else {
        // Found the node to delete
        if (root->left == nullptr) {
            Node* temp = root->right;
            delete root;
            return temp;                  // Case 1 or 2 (no left child)
        } else if (root->right == nullptr) {
            Node* temp = root->left;
            delete root;
            return temp;                  // Case 2 (no right child)
        } else {
            // Case 3: two children
            Node* successor = findMin(root->right);
            root->val   = successor->val; // copy successor's value
            root->right = deleteNode(root->right, successor->val); // delete successor
        }
    }
    return root;
}
```

:::callout-intuition[Intuition]
Why the inorder successor? It is the smallest value that is still greater than the deleted node. Placing it where the deleted node was preserves the BST property: everything in the left subtree is smaller (still valid), and everything remaining in the right subtree is larger (also valid, since we took the minimum of that subtree).
:::

:::example[Example 8.6 — Deleting a Two-Child Node]
Delete 4 from the BST: root=8, left=4 (left=2, right=6 (left=5)), right=12.

::::answer[Answer]
Node 4 has two children (2 and 6). Find inorder successor of 4: leftmost node of right subtree of 4 = leftmost of {6, 5} = **5**. Copy 5 into node 4's position. Then delete node 5 (which is a leaf) from its original position.

```
Before:    After:
   8          8
  / \        / \
 4   12      5   12
/ \         / \
2  6        2   6
  /
 5
```
::::
:::

### Section 4 Practice

:::problem[Problem 7 standard]{difficulty="standard"}
Delete 12 from the following BST. Show which case applies and draw the result.

```
        10
       /  \
      5    15
          /  \
         12   20
           \
            13
```

::::solution[Solution]
Node 12 has one child (right child 13) — this is **Case 2**. Bypass 12 by connecting 15's left pointer to 13.

```
        10
       /  \
      5    15
          /  \
         13   20
```
::::
:::

:::problem[Problem 8 challenge]{difficulty="challenge"}
An alternative deletion strategy uses the **inorder predecessor** (largest value in the left subtree) instead of the inorder successor. Rewrite `deleteNode` to use the inorder predecessor for Case 3. When might this choice matter?

::::solution[Solution]
```cpp
Node* findMax(Node* root) {
    while (root->right != nullptr) root = root->right;
    return root;
}

Node* deleteNodePred(Node* root, int val) {
    if (root == nullptr) return nullptr;
    if (val < root->val)
        root->left  = deleteNodePred(root->left,  val);
    else if (val > root->val)
        root->right = deleteNodePred(root->right, val);
    else {
        if (root->left == nullptr) { Node* t = root->right; delete root; return t; }
        if (root->right == nullptr){ Node* t = root->left;  delete root; return t; }
        // Case 3: use inorder predecessor
        Node* pred = findMax(root->left);
        root->val  = pred->val;
        root->left = deleteNodePred(root->left, pred->val);
    }
    return root;
}
```

In an always-successor strategy, right subtrees shrink while left subtrees grow, gradually skewing the tree. Alternating between predecessor and successor (or choosing based on subtree height) can keep the tree more balanced over many deletions.
::::
:::

## 5. BST Traversal

All traversals from Chapter 7 apply to BSTs, but **inorder traversal** has special significance: it visits BST keys in *strictly ascending order*. This is an immediate consequence of the BST property and makes BSTs a natural tool for sorted output.

```cpp
void inorder(Node* root) {
    if (root == nullptr) return;
    inorder(root->left);
    cout << root->val << " ";
    inorder(root->right);
}
// For a valid BST, this prints keys in sorted ascending order.
```

### Finding the k-th Smallest Element

Use inorder traversal with a counter. Stop when you have visited k nodes:

```cpp
void kthSmallest(Node* root, int k, int& count, int& result) {
    if (root == nullptr) return;
    kthSmallest(root->left, k, count, result);
    count++;
    if (count == k) { result = root->val; return; }
    kthSmallest(root->right, k, count, result);
}
```

:::example[Example 8.7 — Inorder as Sort Verification]
Give the inorder traversal of this BST and verify it is sorted: root=15, left=10 (left=7, right=12), right=20 (left=17, right=25).

::::answer[Answer]
Inorder: **7 10 12 15 17 20 25**. This is strictly ascending, confirming the tree is a valid BST.
::::
:::

### Section 5 Practice

:::problem[Problem 9 easy]{difficulty="easy"}
A BST contains keys {3, 7, 11, 14, 18, 22, 30}. Without knowing the tree's shape, what is the 4th smallest element?

::::solution[Solution]
Inorder traversal of any BST visits keys in sorted order. The sorted sequence is {3, 7, 11, 14, 18, 22, 30}. The 4th smallest is **14**.
::::
:::

:::problem[Problem 10 standard]{difficulty="standard"}
Write a function `void sortedToArray(Node* root, vector<int>& result)` that uses inorder traversal to store all BST keys in sorted order in `result`.

::::solution[Solution]
```cpp
void sortedToArray(Node* root, vector<int>& result) {
    if (root == nullptr) return;
    sortedToArray(root->left, result);
    result.push_back(root->val);
    sortedToArray(root->right, result);
}
```
::::
:::

## 6. BST Performance

The efficiency of all BST operations — search, insert, delete — is $O(h)$ where $h$ is the tree height. Everything hinges on how large $h$ is relative to $n$.

| Scenario | Height $h$ | Operation Cost |
| --- | --- | --- |
| Best case (perfect tree) | $\lfloor \log_2 n \rfloor$ | $O(\log n)$ |
| Average case (random insertions) | $\approx 1.39 \log_2 n$ | $O(\log n)$ |
| Worst case (sorted or reverse-sorted insertions) | $n - 1$ | $O(n)$ |

:::callout-pitfall[Pitfall]
Many students assume BSTs are always $O(\log n)$. They are *not* — that bound holds only for balanced trees. Inserting already-sorted data into a BST produces a degenerate structure with $O(n)$ operations, no better than a linked list. This is why AVL trees and Red-Black trees (Chapter 9) exist.
:::

### Comparison with Other Data Structures

| Operation | Sorted Array | Linked List | BST (balanced) | BST (degenerate) |
| --- | --- | --- | --- | --- |
| Search | $O(\log n)$ | $O(n)$ | $O(\log n)$ | $O(n)$ |
| Insert | $O(n)$ | $O(1)$\* | $O(\log n)$ | $O(n)$ |
| Delete | $O(n)$ | $O(1)$\* | $O(\log n)$ | $O(n)$ |
| Sorted output | $O(n)$ | $O(n)$ | $O(n)$ | $O(n)$ |

\* Assumes position is known; finding position in linked list is O(n).

:::callout-key[When BSTs Win]
A balanced BST beats sorted arrays for **dynamic data** — when you frequently insert and delete, not just search. A sorted array is expensive to keep sorted after modifications ($O(n)$ shift), while a balanced BST maintains $O(\log n)$ for all three operations simultaneously.
:::

### Section 6 Practice

:::problem[Problem 11 easy]{difficulty="easy"}
You insert 1000 random integers into a BST. Approximately how many comparisons does a search require on average? What is the worst case if the data were already sorted?

::::solution[Solution]
Average (random): height ≈ $1.39 \log_2 1000 \approx 1.39 \times 10 \approx \mathbf{14}$ comparisons. Worst case (sorted): the tree degenerates to a chain of height 999, requiring up to **1000 comparisons** — the same as a linear scan.
::::
:::

:::problem[Problem 12 standard]{difficulty="standard"}
Given a choice between a sorted array and a balanced BST, which structure would you choose for an application that performs 90% searches and 10% insertions on a dataset of 10,000 elements? Justify your answer with asymptotic analysis.

::::solution[Solution]
Both a sorted array and a balanced BST support $O(\log n)$ search. The difference is insertion: sorted array requires $O(n)$ to shift elements, while a balanced BST needs only $O(\log n)$. Even at 10% insertions on 10,000 elements, each insertion into the array costs ~10,000 operations vs. ~14 for a balanced BST. **The balanced BST wins** unless memory overhead matters critically (arrays are more cache-friendly, but the asymptotic gap is too large to ignore).
::::
:::

## 7. BST Applications

The BST property enables a rich set of operations beyond basic search, insert, and delete. These algorithms exploit the ordering structure to answer range queries, find neighbors, and validate correctness efficiently.

### Floor and Ceiling

**Floor(k)**: the largest key in the BST that is ≤ k. **Ceiling(k)**: the smallest key that is ≥ k.

```cpp
Node* floor(Node* root, int k) {
    if (root == nullptr) return nullptr;
    if (root->val == k) return root;
    if (k < root->val)  return floor(root->left, k);
    // k > root->val: this node could be the floor, but check right for closer
    Node* rightFloor = floor(root->right, k);
    return (rightFloor != nullptr) ? rightFloor : root;
}

Node* ceiling(Node* root, int k) {
    if (root == nullptr) return nullptr;
    if (root->val == k) return root;
    if (k > root->val)  return ceiling(root->right, k);
    // k < root->val: this node could be ceiling, but check left for closer
    Node* leftCeil = ceiling(root->left, k);
    return (leftCeil != nullptr) ? leftCeil : root;
}
```

### Range Search

Print all keys in the range [lo, hi]:

```cpp
void rangeSearch(Node* root, int lo, int hi) {
    if (root == nullptr) return;
    if (lo < root->val)  rangeSearch(root->left,  lo, hi);  // explore left if lo is there
    if (root->val >= lo && root->val <= hi)
        cout << root->val << " ";                           // this node is in range
    if (hi > root->val)  rangeSearch(root->right, lo, hi); // explore right if hi is there
}
```

### Count Nodes in Range

```cpp
int countInRange(Node* root, int lo, int hi) {
    if (root == nullptr) return 0;
    int count = (root->val >= lo && root->val <= hi) ? 1 : 0;
    if (lo < root->val)  count += countInRange(root->left,  lo, hi);
    if (hi > root->val)  count += countInRange(root->right, lo, hi);
    return count;
}
```

### Inorder Successor

The **inorder successor** of a node is the node that comes immediately after it in inorder traversal — the next larger key. Two cases:

- If the node has a **right subtree**: the successor is the leftmost node of that right subtree.
- If it has **no right subtree**: the successor is the lowest ancestor for which the node is in the left subtree. (Track the last "went left" turn while searching from the root.)

```cpp
Node* inorderSuccessor(Node* root, Node* target) {
    Node* successor = nullptr;
    while (root != nullptr) {
        if (target->val < root->val) {
            successor = root;        // this could be the successor
            root = root->left;
        } else if (target->val > root->val) {
            root = root->right;
        } else {
            // Found target; if it has a right subtree, min of that is successor
            if (root->right != nullptr)
                successor = findMin(root->right);
            break;
        }
    }
    return successor;
}
```

:::example[Example 8.8 — Floor and Ceiling]
In the BST {5, 10, 15, 20, 25, 30}, find floor(13) and ceiling(13).

::::answer[Answer]
floor(13) = **10** (largest key ≤ 13). ceiling(13) = **15** (smallest key ≥ 13).
::::

Work

Assuming the BST is built from those keys in some order, navigate: at each node, if 13 < node, the node is a ceiling candidate — go left for a closer one. If 13 > node, the node is a floor candidate — go right for a closer one. The algorithm returns the tightest such candidate.
:::

:::example[Example 8.9 — Range Search]
Print all keys in [8, 18] from the BST: root=12, left=8 (left=5, right=10), right=20 (left=15, right=25).

::::answer[Answer]
Keys in [8, 18]: **8, 10, 12, 15**. (5 < 8, so excluded; 20 > 18, so excluded; 25 > 18, excluded.)
::::
:::

### Section 7 Practice

:::problem[Problem 13 standard]{difficulty="standard"}
Find the inorder successor of node 10 in this BST: root=15, left=10 (left=7, right=13 (left=11, right=14)), right=20.

::::solution[Solution]
Node 10 has a right subtree rooted at 13. The inorder successor is the leftmost node of that right subtree: go left from 13 to **11**. Inorder successor of 10 = **11**.
::::
:::

:::problem[Problem 14 challenge]{difficulty="challenge"}
Write a function `Node* buildBalancedBST(vector<int>& sorted, int lo, int hi)` that takes a sorted array and builds a height-balanced BST from it. What is the time complexity?

::::solution[Solution]
```cpp
Node* buildBalancedBST(vector<int>& sorted, int lo, int hi) {
    if (lo > hi) return nullptr;
    int mid = lo + (hi - lo) / 2;       // avoid integer overflow
    Node* root = new Node(sorted[mid]);
    root->left  = buildBalancedBST(sorted, lo,      mid - 1);
    root->right = buildBalancedBST(sorted, mid + 1, hi);
    return root;
}
// Call: buildBalancedBST(sorted, 0, sorted.size() - 1)
```

Each of the $n$ elements is visited exactly once, so time complexity is $O(n)$. The resulting tree has height $\lfloor \log_2 n \rfloor$, which is optimal.
::::
:::

## 8. Exam Prep

:::problem[Exam Q1 easy]{difficulty="easy"}
Insert keys 45, 25, 60, 10, 35, 50, 70 into an empty BST. Write the inorder traversal of the result and confirm it is sorted.

::::solution[Solution]
```
          45
         /  \
        25   60
       /  \ /  \
      10  35 50  70
```

Inorder: **10 25 35 45 50 60 70**. Sorted ascending — confirms valid BST.
::::
:::

:::problem[Exam Q2 easy]{difficulty="easy"}
What is the worst-case time complexity for searching in a BST with $n$ nodes? Under what conditions does the worst case occur?

::::solution[Solution]
Worst case is $O(n)$. It occurs when the BST degenerates into a linear chain — this happens when elements are inserted in sorted (or reverse-sorted) order. Every new insertion becomes the rightmost (or leftmost) node, producing height $n - 1$.
::::
:::

:::problem[Exam Q3 standard]{difficulty="standard"}
Delete 25 from the BST produced in Q1. Which deletion case applies? Show the resulting tree.

::::solution[Solution]
Node 25 has two children (10 and 35) — **Case 3**. Inorder successor of 25 = leftmost node of right subtree of 25 = **35** (35 has no left child). Copy 35 to 25's position, then delete 35 (now a leaf).

```
          45
         /  \
        35   60
       /    /  \
      10   50   70
```
::::
:::

:::problem[Exam Q4 standard]{difficulty="standard"}
A BST has inorder traversal [2, 5, 8, 12, 15] and preorder traversal [8, 5, 2, 12, 15]. Draw the tree. Is it a valid BST?

::::solution[Solution]
Preorder first = root = **8**. Inorder split: left = {2, 5}, right = {12, 15}.

 Left preorder = [5, 2]: root = 5, left = 2 (leaf).

 Right preorder = [12, 15]: root = 12, right = 15 (leaf).

```
        8
       / \
      5   12
     /      \
    2        15
```

Inorder = 2, 5, 8, 12, 15 — strictly ascending. **Valid BST.**
::::
:::

:::problem[Exam Q5 standard]{difficulty="standard"}
Explain the three cases for BST deletion. Why must the inorder successor have at most one child?

::::solution[Solution]
**Case 1 (leaf)**: Remove the node, set parent pointer to null. **Case 2 (one child)**: Bypass the node — link parent directly to the node's only child. **Case 3 (two children)**: Replace the node's value with its inorder successor's value, then delete the inorder successor.

 The inorder successor is the leftmost node of the right subtree. Being the leftmost node means it has **no left child** (otherwise it would not be the leftmost). It may have a right child. Therefore it has at most one child, meaning its deletion is always Case 1 or Case 2 — never another Case 3.
::::
:::

:::problem[Exam Q6 standard]{difficulty="standard"}
Write a C++ function `int height(Node* root)` for a BST (same as for any binary tree). What is its time complexity and why?

::::solution[Solution]
```cpp
int height(Node* root) {
    if (root == nullptr) return -1;
    return 1 + max(height(root->left), height(root->right));
}
```

Time complexity: $O(n)$. To find the height, we must visit every node in the tree — there is no shortcut from the BST property that lets us skip nodes when computing height. Every node contributes exactly one recursive call.
::::
:::

:::problem[Exam Q7 challenge]{difficulty="challenge"}
Using the min/max range validation, trace `isValidBST` on this tree and identify where validation fails:

```
        10
       /  \
      5    15
     / \
    3   8
         \
          11
```

::::solution[Solution]
Trace (node, min, max):

 (10, -∞, +∞): 10 in range, ok.

 (5, -∞, 10): 5 in range, ok.

 (3, -∞, 5): 3 in range, ok — leaf, return true.

 (8, 5, 10): 8 in range, ok.

 (11, 8, 10): **11 >= 10 — FAIL.** 11 is in 5's right subtree, which means it must be less than 10 (the root constraint). 11 violates the upper bound of 10.
::::
:::

:::problem[Exam Q8 challenge]{difficulty="challenge"}
Given a sorted array [1, 3, 5, 7, 9, 11, 13, 15], build a height-balanced BST by always choosing the midpoint as the root. Draw the resulting tree and state its height.

::::solution[Solution]
Array indices 0–7. Midpoint = index 3, value **7** (root).

 Left: [1,3,5], midpoint = index 1 = **3**. Left of 3: [1] → **1**. Right of 3: [5] → **5**.

 Right: [9,11,13,15], midpoint = index 1 of this subarray = **11**. Left of 11: [9] → **9**. Right of 11: [13,15], midpoint = **13**, right = **15**.

```
            7
           / \
          3   11
         / \ /  \
        1  5 9   13
                   \
                    15
```

Height = **3**. This is the minimum achievable height for 8 nodes.
::::
:::

## Mixed Practice

:::problem[Mixed 1 easy]{difficulty="easy"}
What is the inorder successor of the maximum element in a BST? What about the inorder predecessor of the minimum element?

::::solution[Solution]
The maximum element has no right subtree. Its inorder successor does not exist — there is no node with a larger key. Similarly, the minimum element has no left subtree, so its inorder predecessor does not exist. In code, both return `nullptr`.
::::
:::

:::problem[Mixed 2 standard]{difficulty="standard"}
Insert keys in the order 30, 15, 45, 10, 20, 40, 50. Then delete 15. Show the tree before and after deletion, and state which deletion case was used.

::::solution[Solution]
Before deletion:

```
           30
          /  \
        15    45
       /  \  /  \
      10  20 40  50
```

Node 15 has two children — **Case 3**. Inorder successor = leftmost of right subtree of 15 = **20** (20 has no left child). Copy 20 to 15's position, delete 20 (leaf).

```
           30
          /  \
        20    45
       /     /  \
      10     40  50
```
::::
:::

:::problem[Mixed 3 standard]{difficulty="standard"}
Write a C++ function `int countNodes(Node* root)` for a BST. Then write `int countNodesInRange(Node* root, int lo, int hi)` that leverages the BST property to prune branches — avoiding unnecessary recursion.

::::solution[Solution]
```cpp
int countNodes(Node* root) {
    if (root == nullptr) return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}

int countNodesInRange(Node* root, int lo, int hi) {
    if (root == nullptr) return 0;
    // Prune: entire left subtree is below lo, skip it
    if (root->val < lo) return countNodesInRange(root->right, lo, hi);
    // Prune: entire right subtree is above hi, skip it
    if (root->val > hi) return countNodesInRange(root->left, lo, hi);
    // This node is in range; recurse both sides
    return 1 + countNodesInRange(root->left, lo, hi)
             + countNodesInRange(root->right, lo, hi);
}
```
::::
:::

:::problem[Mixed 4 challenge]{difficulty="challenge"}
Prove that the inorder traversal of a BST always produces a sorted sequence. (Formal proof by induction on tree height.)

::::solution[Solution]
**Claim**: The inorder traversal of any BST visits keys in strictly ascending order.

**Base case**: A BST with 0 nodes produces an empty sequence — trivially sorted. A BST with 1 node produces a single-element sequence — trivially sorted.

**Inductive hypothesis**: Assume the claim holds for all BSTs of height less than $h$.

**Inductive step**: Consider a BST of height $h$ with root $r$, left subtree $L$, and right subtree $R$. By the inductive hypothesis, inorder($L$) is sorted and inorder($R$) is sorted. Inorder traversal visits $L$ first, then $r$, then $R$. By the BST property: every key in $L$ < $r$ < every key in $R$. Therefore the concatenation inorder($L$) + [r] + inorder($R$) is also strictly sorted. The claim holds for height $h$. By induction, it holds for all finite BSTs.
::::
:::

:::problem[Mixed 5 challenge]{difficulty="challenge"}
Design a C++ class `BST` with a private root pointer and public methods: `insert(int)`, `remove(int)`, `contains(int)`, `min()`, `max()`, and `toSortedVector()`. Show the class skeleton with method signatures and brief inline implementations or stubs.

::::solution[Solution]
```cpp
class BST {
private:
    Node* root = nullptr;

    Node* insert(Node* n, int v) {
        if (!n) return new Node(v);
        if (v < n->val) n->left  = insert(n->left,  v);
        else if (v > n->val) n->right = insert(n->right, v);
        return n;
    }
    Node* remove(Node* n, int v) { /* deleteNode logic */ return n; }
    void  collect(Node* n, vector<int>& out) {
        if (!n) return;
        collect(n->left, out);
        out.push_back(n->val);
        collect(n->right, out);
    }

public:
    void insert(int v)         { root = insert(root, v); }
    void remove(int v)         { root = remove(root, v); }
    bool contains(int v) const {
        Node* cur = root;
        while (cur) {
            if (v == cur->val) return true;
            cur = (v < cur->val) ? cur->left : cur->right;
        }
        return false;
    }
    int  min() const { Node* n = root; while (n->left) n = n->left; return n->val; }
    int  max() const { Node* n = root; while (n->right) n = n->right; return n->val; }
    vector<int> toSortedVector() {
        vector<int> out;
        collect(root, out);
        return out;
    }
};
```
::::
:::

:::summary
## Chapter 8 Summary

A Binary Search Tree extends a binary tree with the ordering invariant: left subtree values < node < right subtree values at every node. This invariant enables efficient search, insertion, and deletion — all in $O(h)$ time.

| Operation | Best Case | Average Case | Worst Case | Notes |
| --- | --- | --- | --- | --- |
| Search | $O(1)$ | $O(\log n)$ | $O(n)$ | Follow left/right at each node |
| Insert | $O(1)$ | $O(\log n)$ | $O(n)$ | Always attaches a new leaf |
| Delete (Case 1/2) | $O(1)$ | $O(\log n)$ | $O(n)$ | Remove or bypass node |
| Delete (Case 3) | $O(\log n)$ | $O(\log n)$ | $O(n)$ | Find and delete inorder successor |
| Find Min / Max | $O(1)$ | $O(\log n)$ | $O(n)$ | Leftmost / rightmost node |
| Inorder Traversal | $O(n)$ | $O(n)$ | $O(n)$ | Produces sorted output |
| Range Search [lo, hi] | $O(k)$ | $O(k + \log n)$ | $O(n)$ | k = nodes in range |

### Key Takeaways

- The BST property must hold for entire subtrees, not just parent-child pairs. Use the min/max range method or inorder check to validate.
- All operations run in $O(h)$. For a balanced tree, $h = O(\log n)$; for a degenerate tree, $h = O(n)$.
- Insertion order determines tree shape. Sorted input produces the worst possible BST — a linked list.
- Deletion Case 3 (two children) always reduces to Case 1 or 2 via the inorder successor.
- Inorder traversal of a BST yields a sorted sequence — this is the proof that BSTs can sort in $O(n \log n)$ expected time.
- Chapter 9 (Balanced Trees) addresses the degenerate case with AVL and Red-Black trees that guarantee $O(\log n)$ height.
:::
