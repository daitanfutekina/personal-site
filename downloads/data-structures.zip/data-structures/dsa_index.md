---
title: "Honors Data Structures & Analysis of Algorithms"
crumb: "Self-study Textbook · MSState CSE 2383"
source: "dsa_index.html"
---

# Honors Data Structures &
Analysis of Algorithms

CSE 2383 (Honors)
 Mississippi State University
 C++ throughout

This textbook covers every topic in MSState's CSE 2383 Honors Data Structures course, from
 a C++ refresher through graphs and hashing, with an Honors extension unit on sorting theory,
 skip lists, and algorithm design paradigms. Each chapter includes worked examples, common-pitfall
 callouts, and practice problems with collapsible solutions. No prior data structures knowledge
 is assumed — only intro-level C++ (CSE 1384) and Calculus I.

18 / 18 — Chapters done

~1,330 min — Total study time

:::callout-key
Textbook Complete
:::

All 18 chapters are available. Work through them in order, or jump to any topic. Good luck! 🎉

## Chapters

✓ Complete — ⋯ In progress — ☐ Planned

Unit 0 — Foundations

- ✓
 Ch 1
 [C++ Refresher for Data Structures](./dsa_ch1_cpp_refresher.html)
 ~90 min
- ✓
 Ch 2
 [Memory & Computation](./dsa_ch2_memory.html)
 ~60 min

Unit 1 — Algorithm Analysis & Linear Structures

- ✓
 Ch 3
 [Algorithm Analysis & Big-O](./dsa_ch3_big_o.html)
 ~75 min
- ✓
 Ch 4
 [Linked Lists](./dsa_ch4_linked_lists.html)
 ~75 min
- ✓
 Ch 5
 [Stacks](./dsa_ch5_stacks.html)
 ~70 min
- ✓
 Ch 6
 [Queues](./dsa_ch6_queues.html)
 ~65 min

Unit 2 — Trees

- ✓
 Ch 7
 [Binary Trees — Structure & Traversal](./dsa_ch7_binary_trees.html)
 ~80 min
- ✓
 Ch 8
 [Binary Search Trees](./dsa_ch8_bst.html)
 ~85 min
- ✓
 Ch 9
 [Balanced Trees (AVL & Red-Black)](./dsa_ch9_balanced_trees.html)
 ~90 min
- ✓
 Ch 10
 [Heaps & Priority Queues](./dsa_ch10_heaps.html)
 ~75 min

Unit 3 — Graphs

- ✓
 Ch 11
 [Graph Fundamentals & Representations](./dsa_ch11_graphs.html)
 ~75 min
- ✓
 Ch 12
 [Graph Traversals (DFS & BFS)](./dsa_ch12_graph_traversals.html)
 ~90 min
- ✓
 Ch 13
 [Minimum Spanning Trees](./dsa_ch13_mst.html)
 ~60 min
- ✓
 Ch 14
 [Shortest Path Algorithms](./dsa_ch14_shortest_paths.html)
 ~75 min

Unit 4 — Hashing

- ✓
 Ch 15
 [Hash Tables](./dsa_ch15_hash_tables.html)
 ~65 min

Unit 5 — Honors Extensions

- ✓
 Ch 16
 [Sorting Algorithm Showdown](./dsa_ch16_sorting.html)
 ~70 min
- ✓
 Ch 17
 [Advanced & Probabilistic Data Structures](./dsa_ch17_advanced_ds.html)
 ~70 min
- ✓
 Ch 18
 [Algorithm Design Paradigms](./dsa_ch18_algorithm_design.html)
 ~80 min

## Resources

External references for this subject:

- No required textbook (per Dr. Adam Jones' syllabus)
- Instructor: Dr. J. Adam Jones — [jaj33@msstate.edu](mailto:jaj33@msstate.edu)
- Course page: [hi5lab.org (Spring 2023 syllabus)](https://hi5lab.org/doku.php?id=adam_jones:courses:cse2383_s23)
- Language: C++ (Microsoft Visual Studio or OnlineGDB)
- Honors project: implement and empirically compare a data structure (e.g. Skip List)
- Grading: 60% exams · 25% programming challenges · 10% quizzes · 5% C++ refresher challenge
