---
title: "Balanced Trees"
crumb: "Honors DSA · Chapter 9"
meta:
  - "Est. study time: ~70 min"
  - "Unit 3"
  - "CSE 2383 · MSState"
source: "dsa_ch9_balanced_trees.html"
---

## 1. Why Balance Matters

:::callout-intuition[Intuition]
A BST is only fast when it stays *short and wide*. The moment you insert keys in sorted order, the tree degenerates into a linked list and all the O(log n) promises evaporate. Balanced tree structures enforce a height guarantee so the worst case never sneaks up on you.
:::

Recall that for a BST with $n$ nodes the cost of search, insert, and delete is $\Theta(h)$ where $h$ is the tree height. In the best case (a perfect binary tree) $h = \lfloor \log_2 n \rfloor$. In the worst case, $h = n - 1$.

### The Degenerate Case

Insert the keys **1, 2, 3, 4, 5** into an ordinary BST in that order:

```text
1
 \
  2
   \
    3
     \
      4
       \
        5
```

Every node has only a right child. Height = 4 = $n - 1$. Searching for 5 requires visiting all 5 nodes — identical to a linear scan. For $n = 10^6$ sorted keys, you would visit 1 000 000 nodes instead of ~20.

The mathematical guarantee we want is:

$$
h = O(\log n)
$$

Achieving this requires the tree to *rebalance itself* after every modification. The two most common self-balancing BSTs taught in university courses are **AVL trees** and **Red-Black trees**.

:::example[Example 1.1 — Height comparison]
A BST holds 15 keys. What are the best-case and worst-case heights? How many comparisons might a search require in each case?

::::answer[Answer]
Best case (perfectly balanced): $h = \lfloor \log_2 15 \rfloor = 3$. Search costs at most 4 comparisons.

 Worst case (degenerate): $h = 14$. Search costs at most 15 comparisons.
::::

Work

A complete binary tree with height $h$ has $2^{h+1} - 1$ nodes. Solving $2^{h+1} - 1 \ge 15$ gives $h \ge 3$. The degenerate height is $n - 1 = 14$.
:::

:::example[Example 1.2 — Sorted insertion]
Draw the BST produced by inserting keys 10, 20, 30, 5, 15 in that order. What is the height?

::::answer[Answer]
Height = 2 (the tree is relatively balanced here because 5 and 15 go left and right of intermediate nodes).
::::

Work

```text
      10
     /  \
    5    20
        /
       15
          \  (30 would go here)
           30
```

Note that 30 is inserted after 20, so it goes right of 20. 15 is inserted after 30, so it goes left of 20. Final height is 2 (root at level 0, deepest node at level 2).
:::

:::callout-pitfall[Common Pitfall]
Students often assume "random" insertions keep a BST balanced. They do *on average*, but any sorted or nearly-sorted input causes degeneracy. Real-world data (timestamps, IDs) is frequently sorted — so you can never rely on "average" BST height in production systems.
:::

### Section 1 Practice

:::problem[Problem 1 easy]{difficulty="easy"}
A BST has $n = 31$ nodes inserted in sorted order. What is its height?

::::solution[Solution]
Height = $n - 1 = 30$. All nodes form a right-skewed chain.
::::
:::

:::problem[Problem 2 easy]{difficulty="easy"}
What is the minimum possible height of a BST with 31 nodes?

::::solution[Solution]
$\lfloor \log_2 31 \rfloor = 4$. A complete binary tree of height 4 can hold up to $2^5 - 1 = 31$ nodes.
::::
:::

:::problem[Problem 3 standard]{difficulty="standard"}
A company database has 1 000 000 records inserted in ID order. A plain BST is used. Estimate the number of comparisons for a worst-case search. How many would a balanced tree need?

::::solution[Solution]
Plain BST (degenerate): up to 1 000 000 comparisons. Balanced tree: $\lceil \log_2 1\,000\,001 \rceil = 20$ comparisons. The difference is factor of 50 000×.
::::
:::

## 2. AVL Trees — Definition

:::callout-intuition[Intuition]
An AVL tree is a BST that tracks the height of every node and enforces a simple rule: the heights of any node's left and right subtrees can differ by at most 1. This single constraint is enough to guarantee the tree's total height stays $O(\log n)$.
:::

Named after their inventors Adelson-Velsky and Landis (1962), AVL trees were the *first* self-balancing BST ever described. Every node stores an extra field: its **balance factor**.

$$
\text{bf}(v) = \text{height}(\text{left}(v)) - \text{height}(\text{right}(v))
$$

A node is **AVL-balanced** if $\text{bf}(v) \in \{-1, 0, 1\}$. A tree is an AVL tree if every node is AVL-balanced.

:::callout-key[Key Convention]
The height of an **empty tree (null pointer)** is defined as $-1$. A single leaf node has height 0. This avoids special-casing null children when computing balance factors.
:::

### Computing Height and Balance Factor

```cpp
struct AVLNode {
    int key;
    int height;   // height of subtree rooted here
    AVLNode* left;
    AVLNode* right;
};

int height(AVLNode* v) {
    return (v == nullptr) ? -1 : v->height;
}

int balanceFactor(AVLNode* v) {
    return height(v->left) - height(v->right);
}

void updateHeight(AVLNode* v) {
    v->height = 1 + std::max(height(v->left), height(v->right));
}
```

### Height Bound Proof Sketch

Let $N(h)$ = minimum number of nodes in an AVL tree of height $h$. Then:

$$
N(h) = N(h-1) + N(h-2) + 1, \quad N(-1) = 0,\; N(0) = 1
$$

This recurrence is similar to Fibonacci. It can be shown $N(h) \ge \phi^h / \sqrt{5} - 1$ where $\phi \approx 1.618$. Inverting: $h \le 1.44 \log_2(n+2)$. So AVL height is at most **44% worse than perfect** — still $\Theta(\log n)$.

:::example[Example 2.1 — Balance factor computation]
For each node below, compute the balance factor. Is this a valid AVL tree?

```text
        30  (h=2)
       /  \
     20    40  (h=0 each)
    /
   10  (h=0)
```

::::answer[Answer]
Node 30: bf = height(left=20) − height(right=40) = 1 − 0 = **+1**. Valid.

 Node 20: bf = height(left=10) − height(right=null) = 0 − (−1) = **+1**. Valid.

 Node 40: bf = (−1) − (−1) = **0**. Valid.

 Node 10: bf = (−1) − (−1) = **0**. Valid.

 All balance factors ∈ {−1, 0, 1} → **valid AVL tree**.
::::
:::

:::example[Example 2.2 — Detecting imbalance]
After inserting key 50 into the tree above, recompute balance factors. Which node becomes unbalanced?

```text
        30
       /  \
     20    40
    /        \
   10         50
```

::::answer[Answer]
Node 40: bf = (−1) − 0 = −1. Valid.

 Node 30: height(left subtree rooted at 20) = 1, height(right subtree rooted at 40) = 1. bf = 0. Still valid — this tree is balanced.
::::
:::

### Section 2 Practice

:::problem[Problem 4 easy]{difficulty="easy"}
What is the balance factor of a leaf node?

::::solution[Solution]
Both children are null (height −1 each). bf = (−1) − (−1) = 0.
::::
:::

:::problem[Problem 5 standard]{difficulty="standard"}
An AVL tree has 7 nodes. What are the possible heights?

::::solution[Solution]
Minimum height: $\lfloor \log_2 7 \rfloor = 2$ (complete tree). Maximum height: From the Fibonacci bound, the tallest AVL tree with 7 nodes has height 3 (N(3) = 7 exactly for the minimal-node case). So heights 2 or 3 are both possible.
::::
:::

:::problem[Problem 6 challenge]{difficulty="challenge"}
What is the minimum number of nodes in an AVL tree of height 4? (Use the recurrence $N(h) = N(h-1)+N(h-2)+1$.)

::::solution[Solution]
N(−1)=0, N(0)=1, N(1)=N(0)+N(−1)+1=2, N(2)=N(1)+N(0)+1=4, N(3)=N(2)+N(1)+1=7, N(4)=N(3)+N(2)+1=12. Answer: **12 nodes**.
::::
:::

## 3. AVL Rotations

:::callout-intuition[Intuition]
A rotation is a *local restructuring* of three nodes that preserves BST order while reducing height by 1 on the heavy side. Think of it as picking up a node and pivoting the subtree around its child. There are only 4 possible imbalance patterns, and each has exactly one corrective rotation (or pair of rotations).
:::

### Single Right Rotation (LL Case)

Triggered when a node `z` has bf = +2 and its left child `y` has bf ≥ 0 (left-heavy or balanced).

```text
    z                 y
   / \              /   \
  y   T4    →     x     z
 / \            / \   / \
x   T3        T1 T2  T3  T4
```

The subtrees T1–T4 represent arbitrary subtrees (possibly empty). The key invariant: after the rotation, $y$ is the new root, $x$ stays left, $z$ moves right. BST order is preserved because all keys in T3 are between $y$ and $z$.

```cpp
AVLNode* rotateRight(AVLNode* z) {
    AVLNode* y = z->left;
    AVLNode* T3 = y->right;
    // Perform rotation
    y->right = z;
    z->left  = T3;
    // Update heights (z first — it is now lower)
    updateHeight(z);
    updateHeight(y);
    return y;  // y is new root
}
```

### Single Left Rotation (RR Case)

Mirror image: bf = −2 at `z`, right child `y` has bf ≤ 0.

```text
  z                   y
 / \                /   \
T1   y     →      z     x
    / \          / \   / \
   T2   x      T1 T2  T3  T4
```

### Left-Right Rotation (LR Case)

Triggered when bf = +2 at `z` and its left child `y` has bf = −1. A single right rotation at `z` would not fix it — we need to *first rotate left on `y`*, then rotate right on `z`.

```text
Step 1 — left rotation on y:        Step 2 — right rotation on z:
    z                  z                    x
   / \                / \                 /   \
  y   T4    →       x   T4    →         y     z
 / \               / \                 / \   / \
T1   x            y   T3             T1  T2 T3  T4
    / \          / \
   T2  T3       T1  T2
```

### Right-Left Rotation (RL Case)

Triggered when bf = −2 at `z` and right child `y` has bf = +1. First rotate right on `y`, then left on `z`. Mirror image of LR.

:::callout-tip[Memory Aid]
The case name tells you where the imbalance *went*: "LL" means the insertion went Left-Left (two lefts from the unbalanced node). The fix is always a single rotation in the *opposite* direction. "LR" means the insertion went Left then Right — the fix is a double rotation.
:::

:::example[Example 3.1 — Identify the case and fix]
After an insertion the tree looks like this. Identify the rotation case and perform it.

```text
    50 (bf=+2)
   /
  30 (bf=+1)
 /
10
```

::::answer[Answer]
LL case. Apply right rotation at 50. Result:

```text
  30
 /  \
10   50
```
::::
:::

:::example[Example 3.2 — LR case]
Identify the case and fix:

```text
    50 (bf=+2)
   /
  10 (bf=-1)
    \
     30
```

::::answer[Answer]
LR case. Step 1: left-rotate at 10 → node 30 becomes the left child of 50, with 10 as its left child. Step 2: right-rotate at 50.

```text
After step 1:      After step 2:
    50                  30
   /                  /    \
  30                10      50
 /
10
```
::::
:::

### Section 3 Practice

:::problem[Problem 7 easy]{difficulty="easy"}
Which rotation case applies when the first unbalanced ancestor has bf = −2 and its right child has bf = −1?

::::solution[Solution]
RR case → single left rotation at the unbalanced ancestor.
::::
:::

:::problem[Problem 8 standard]{difficulty="standard"}
After an RL rotation, what are the balance factors of the three involved nodes (the new root and its two children)?

::::solution[Solution]
The new root $x$ has bf = 0. Both children $z$ (left) and $y$ (right) have bf = 0 (assuming the insertion added a single node at a leaf level). In general, the balance factors of the two children depend on which subtree of $x$ received the new node.
::::
:::

:::problem[Problem 9 challenge]{difficulty="challenge"}
Show that a right rotation preserves BST order (i.e., an in-order traversal yields the same sequence before and after).

::::solution[Solution]
Before rotation, in-order is: T1 → x → T2 → y → T3 → z → T4.

 After right rotation at z (y becomes root): in-order traversal of new tree is T1 → x → T2 → y → T3 → z → T4. Same sequence. The rotation only changes parent-child pointers, not the relative ordering of keys.
::::
:::

## 4. AVL Insertion

:::callout-intuition[Intuition]
AVL insertion is just BST insertion followed by a "fix-up" pass walking back toward the root. At each ancestor of the inserted node, update the height and check the balance factor. If bf goes outside {−1, 0, 1}, apply the appropriate rotation. After one rotation (or double rotation) the subtree's height returns to what it was before the insert, so the fix-up stops — at most **one rotation** is ever needed per insert.
:::

### Algorithm

1. Insert the new key as in a regular BST (recursive descent).
2. On the way back up (unwinding recursion), call `updateHeight` on each ancestor.
3. Call `balanceFactor` on each ancestor. If |bf| = 2, determine the case (LL/RR/LR/RL) and apply the rotation.
4. Return the (possibly new) root of the subtree.

```cpp
AVLNode* insert(AVLNode* v, int key) {
    // 1. Standard BST insert
    if (v == nullptr) return new AVLNode{key, 0, nullptr, nullptr};
    if (key < v->key)  v->left  = insert(v->left,  key);
    else if (key > v->key) v->right = insert(v->right, key);
    else return v;  // duplicate — ignore

    // 2. Update height
    updateHeight(v);

    // 3. Get balance factor
    int bf = balanceFactor(v);

    // LL Case
    if (bf > 1 && key < v->left->key)
        return rotateRight(v);
    // RR Case
    if (bf < -1 && key > v->right->key)
        return rotateLeft(v);
    // LR Case
    if (bf > 1 && key > v->left->key) {
        v->left = rotateLeft(v->left);
        return rotateRight(v);
    }
    // RL Case
    if (bf < -1 && key < v->right->key) {
        v->right = rotateRight(v->right);
        return rotateLeft(v);
    }
    return v;  // balanced
}
```

:::example[Example 4.1 — Full trace: insert sequence]
Insert 30, 20, 10 into an empty AVL tree. Show each step.

::::answer[Answer]
After inserting 30, 20, 10 an LL imbalance is detected at 30; one right rotation yields a balanced tree with 20 as root.
::::

Step-by-step

```text
Insert 30:     Insert 20:      Insert 10:        After LL rotation:
   30             30             30 (bf=+2!)         20
                 /              /                   /  \
                20             20                  10   30
                              /
                             10
bf at 30 = +2, left child 20 has bf = +1 → LL case → rotateRight(30)
```
:::

:::example[Example 4.2 — LR case during insertion]
Start from an empty AVL tree and insert 30, 10, 20. Trace the rotations.

::::answer[Answer]
After inserting 30, 10, 20 an LR imbalance is detected at 30. Double rotation (left on 10, then right on 30) yields 20 as root with 10 and 30 as children.
::::

Step-by-step

```text
Insert 30:  Insert 10:  Insert 20 (LR!):   Step1 rotateLeft(10):  Step2 rotateRight(30):
   30           30           30                  30                      20
               /            /                   /                       /  \
              10            10                 20                      10   30
                              \              /
                               20           10
bf at 30 = +2, left child 10 has bf = −1 → LR case
```
:::

:::callout-pitfall[Common Pitfall]
Always update the height of node `z` *before* updating the height of node `y` in a rotation — `z` is now `y`'s child and its height must be finalized first. Getting this order wrong produces silent bugs where stored heights are stale.
:::

### Section 4 Practice

:::problem[Problem 10 standard]{difficulty="standard"}
Insert the sequence 5, 10, 15, 20, 25 into an empty AVL tree. Draw the tree after each insertion and identify any rotations performed.

::::solution[Solution]
Insert 5: {5}. Insert 10: {5,10}, bf(5)=−1 — ok. Insert 15: bf(5)=−2, RR case → rotateLeft(5). Tree: root=10, left=5, right=15. Insert 20: bf(15)=−1 — ok. Insert 25: bf(15)=−2, RR → rotateLeft(15). Tree: root=10, left=5, right=20, 20's children are 15 and 25.
::::
:::

:::problem[Problem 11 standard]{difficulty="standard"}
How many rotations (counting each single rotation as 1) occur when inserting the sequence 50, 25, 75, 10, 30 into an empty AVL tree?

::::solution[Solution]
Insert 50 (no rotation), 25 (no rotation), 75 (no rotation), 10 (no rotation — bf(50)=+1 still ok), 30 (no rotation — all balance factors stay in range). Answer: **0 rotations**. The resulting tree has 50 as root, 25 with children 10 and 30, 75 as right child of 50.
::::
:::

## 5. AVL Deletion

:::callout-intuition[Intuition]
Deletion in an AVL tree follows the same pattern as insertion: remove using the standard BST algorithm, then rebalance bottom-up. The key difference is that deletion can cause *multiple rotations* — one per level as the height reduction propagates upward. Think of it as dominoes: fixing one level can expose imbalance at the next.
:::

### Algorithm

1. Delete the node using standard BST deletion (find in-order successor if the node has two children; replace key; delete the successor which has at most one child).
2. Walk back up to the root. At each ancestor, update height and check balance factor.
3. Apply rotation if needed. Unlike insertion, the rotation here *reduces the subtree height*, which can trigger another imbalance one level up — keep going until the root.

```cpp
// Find the minimum node in a subtree (for finding in-order successor)
AVLNode* minNode(AVLNode* v) {
    while (v->left) v = v->left;
    return v;
}

AVLNode* avlDelete(AVLNode* v, int key) {
    if (v == nullptr) return nullptr;

    if (key < v->key)
        v->left = avlDelete(v->left, key);
    else if (key > v->key)
        v->right = avlDelete(v->right, key);
    else {
        // Node to delete found
        if (!v->left || !v->right) {
            AVLNode* child = v->left ? v->left : v->right;
            delete v;
            return child;  // null or one child
        }
        // Two children: replace with in-order successor
        AVLNode* succ = minNode(v->right);
        v->key = succ->key;
        v->right = avlDelete(v->right, succ->key);
    }

    updateHeight(v);
    int bf = balanceFactor(v);

    // Same 4 rotation cases as insert
    if (bf > 1 && balanceFactor(v->left) >= 0)  return rotateRight(v);
    if (bf > 1 && balanceFactor(v->left) < 0)  { v->left = rotateLeft(v->left); return rotateRight(v); }
    if (bf < -1 && balanceFactor(v->right) <= 0) return rotateLeft(v);
    if (bf < -1 && balanceFactor(v->right) > 0) { v->right = rotateRight(v->right); return rotateLeft(v); }
    return v;
}
```

:::example[Example 5.1 — Deletion with rebalancing]
Given the AVL tree below, delete node 40. Show the rebalancing steps.

```text
        50
       /  \
     30    70
    /  \   /
   20   40 60
```

::::answer[Answer]
Delete 40 (a leaf). Update bf(30) = height(20) − height(null) = 0 − (−1) = +1. bf(50) = height(30)−height(70) = 1−1 = 0. No rotation needed. Tree is still balanced.
::::
:::

:::example[Example 5.2 — Deletion triggering rotation]
Delete node 70 from the same tree. Show what happens.

::::answer[Answer]
Delete 70 (a leaf). Now bf(50) = height(30) − height(null) = 1 − (−1) = **+2**. The left child 30 has bf = 0 (both children 20 and 40 present... but we deleted 40 earlier). Assuming we start fresh with 70 deleted from the original tree: bf(50)=+2, left child 30 has bf(30)=0 → LL case → rotateRight(50). New root = 30, left=20, right subtree = {50 with left=40, right=null}.
::::
:::

:::callout-warning[Warning]
In deletion, when the unbalanced node's heavy child has bf = 0, we still perform the single rotation (not the double), unlike in insertion where bf = 0 at the child is not a trigger. The rotation case chart for deletion uses ≥ 0 and ≤ 0 (not strictly +1 or −1) for this reason.
:::

### Section 5 Practice

:::problem[Problem 12 standard]{difficulty="standard"}
True or False: AVL deletion always requires at most one rotation (just like insertion).

::::solution[Solution]
**False.** Deletion can require $O(\log n)$ rotations as the height reduction propagates upward through multiple ancestors.
::::
:::

:::problem[Problem 13 challenge]{difficulty="challenge"}
When deleting a node with two children in an AVL tree, why do we replace it with its in-order successor (or predecessor) rather than just splicing it out?

::::solution[Solution]
A node with two children cannot simply be removed because doing so would disconnect its two subtrees. We copy the successor's key into the node and then delete the successor (which has at most one child — specifically, no left child), turning the problem into a simpler case. This preserves BST order while making the pointer update tractable.
::::
:::

## 6. Red-Black Trees

:::callout-intuition[Intuition]
Red-Black trees achieve balance through color labels rather than height measurements. The rules about colors implicitly constrain the height, guaranteeing that no root-to-leaf path is more than twice as long as any other. They allow slightly more imbalance than AVL trees but require fewer rotations — which is why the C++ STL `std::map` and Java's `TreeMap` use Red-Black trees internally.
:::

### The Five Red-Black Properties

1. Every node is colored either **red** or **black**.
2. The root is **black**.
3. Every leaf (NIL sentinel) is **black**.
4. **Red property:** If a node is red, both its children are black (no two consecutive red nodes on any path).
5. **Black-height property:** All paths from any node to its descendant NIL leaves contain the same number of black nodes.

The **black-height** of a node $v$, written $\text{bh}(v)$, is the number of black nodes on any path from $v$ to a NIL leaf, *not counting $v$ itself*.

:::callout-key[Key Theorem]
A red-black tree with $n$ internal nodes has height at most $2 \log_2(n+1)$. Proof sketch: since no red node has a red parent, at least half the nodes on any path are black. A subtree rooted at a node with black-height $k$ has at least $2^k - 1$ internal nodes. Combining these gives the bound.
:::

### Red-Black vs AVL: Trade-offs

| Property | AVL Tree | Red-Black Tree |
| --- | --- | --- |
| Height bound | $\le 1.44 \log_2 n$ | $\le 2 \log_2(n+1)$ |
| Balance strictness | Stricter (height-balanced) | Looser (color-balanced) |
| Rotations per insert | At most 1 | At most 2 |
| Rotations per delete | At most $O(\log n)$ | At most 3 |
| Read performance | Slightly faster | Slightly slower |
| Write performance | Slower (more rotations possible) | Faster in practice |
| Used in | Databases needing fast reads | STL map/set, Linux kernel |

### Insertion Overview

Insert as a red node (this can only violate property 4 — never 5). Then fix using **cases**:

- **Case 1:** Uncle is red → recolor parent, uncle to black; grandparent to red; move up.
- **Case 2:** Uncle is black, new node is "inside" grandchild → rotate to convert to Case 3.
- **Case 3:** Uncle is black, new node is "outside" grandchild → rotate grandparent, recolor.

:::example[Example 6.1 — Valid Red-Black tree?]
Verify whether the following tree satisfies all 5 properties (B = black, R = red).

```text
        13(B)
       /     \
     8(R)    17(R)
    /  \    /   \
  1(B) 11(B) 15(B) 25(B)
                  \
                  22(R)
```

::::answer[Answer]
Check each property:

 1. All nodes colored. ✓

 2. Root 13 is black. ✓

 3. NIL leaves implied black. ✓

 4. 8 is red, children 1 and 11 are black. 17 is red, children 15 and 25 are black. 22 is red, children are NIL (black). ✓

 5. Black-height of root: path to 1's NIL = 13(B)→8(R)→1(B)→NIL = 2 black. Path to 22: 13(B)→17(R)→25(B)→22(R)→NIL = 2 black. All paths = 2. ✓

 **Valid Red-Black tree.**
::::
:::

:::example[Example 6.2 — Spot the violation]
Which property does the following violate?

```text
      10(B)
      /   \
   5(R)   15(R)
   /
 2(R)
```

::::answer[Answer]
Property 4 is violated: node 5 is red and its child 2 is also red (two consecutive red nodes on the left path). Must fix with recolor or rotation.
::::
:::

### Section 6 Practice

:::problem[Problem 14 easy]{difficulty="easy"}
Why must the root of a Red-Black tree always be black?

::::solution[Solution]
If the root were red, it would violate property 4 if it had any red children (which are necessary once insertions occur). More fundamentally, property 2 is a simplifying convention: we can always recolor the root black without violating any other property (black-height only changes uniformly, and no path length relationship is broken), so enforcing this avoids special-casing in algorithms.
::::
:::

:::problem[Problem 15 standard]{difficulty="standard"}
A Red-Black tree has black-height 3. What is the minimum and maximum number of internal nodes it could contain?

::::solution[Solution]
Minimum: all nodes on every path are black → a perfect black tree of height 3 has $2^3 - 1 = 7$ nodes.

 Maximum: alternate red and black on every path → height up to $2 \times 3 = 6$, giving up to $2^7 - 1 = 127$ nodes (perfect tree of height 6).

 So minimum = 7, maximum = 127.
::::
:::

:::problem[Problem 16 challenge]{difficulty="challenge"}
Explain why inserting into a Red-Black tree always colors the new node red (not black), and what violation this might cause.

::::solution[Solution]
Inserting black would change the black-height along one path and potentially violate property 5 (black-height property) — the hardest property to fix. Inserting red can only violate property 4 (two consecutive reds), which is easier to fix by recoloring or local rotations. We prefer the easier violation.
::::
:::

## 7. B-Trees Overview

:::callout-intuition[Intuition]
B-trees are designed for *disk-based storage* where reading a single disk block is thousands of times slower than reading RAM. By storing many keys per node (filling an entire disk block), B-trees minimize the number of disk reads needed to find a key. A B-tree of order 1000 needs only 3–4 disk reads for a billion records.
:::

### Definition: Order-m B-Tree

A B-tree of order $m$ (also called a degree-$m$ or arity-$m$ B-tree) satisfies:

- Every node has at most $m$ children (and thus at most $m-1$ keys).
- Every non-root, non-leaf node has at least $\lceil m/2 \rceil$ children (at least $\lceil m/2 \rceil - 1$ keys).
- The root has at least 2 children (unless the tree has only one node).
- **All leaves appear at the same depth.**
- Keys within each node are sorted. Between keys $k_i$ and $k_{i+1}$, the subtree pointer leads to keys in the range $(k_i, k_{i+1})$.

:::callout-key[Why All Leaves at Same Depth?]
Unlike AVL and Red-Black trees which balance height approximately, B-trees maintain *perfect balance* at the leaf level. This guarantees that every search takes exactly the same number of disk reads (the tree height). The height of a B-tree with $n$ keys is $O(\log_m n)$ — logarithm base $m$, not 2. With $m = 1000$, a billion-key tree has height $\le 3$.
:::

### B-Tree Height

$$
h \le \log_{\lceil m/2 \rceil} \!\left( \frac{n+1}{2} \right)
$$

For $m=5$, $n=10^6$: $h \le \log_3(500001) \approx 11.7$, so at most 12 disk reads regardless of which key you seek.

### Applications

- **Databases**: PostgreSQL, MySQL use B+ trees (a variant where all data is in leaves and internal nodes only store routing keys). This allows sequential scans of all records efficiently.
- **Filesystems**: NTFS, HFS+, ext4 use B-trees for directory indexing.
- **Key-value stores**: RocksDB uses a variant (LSM-tree) inspired by B-tree ideas.

### B+ Tree Variant

In a **B+ tree**, internal nodes store only keys (no data), and all data records are stored in leaves. Leaves are linked in a doubly-linked list for efficient range queries. This is the most common variant in practice.

:::example[Example 7.1 — B-tree capacity]
A database uses a B-tree of order 201 (each node fits one 8KB disk block). What is the maximum number of records accessible in 3 disk reads?

::::answer[Answer]
Height 3 tree (root + 2 levels) can have at most $201^3 = 8\,120\,601$ leaves, each holding up to 200 keys. Maximum records ≈ $200 \times 201^2 = 8\,080\,200$ in a height-2 tree. For 3 reads: the root, one internal node, one leaf — so you can access any of $\approx 200 \times 201 = 40\,200$ keys at depth 2, or traverse to $201^2 = 40\,401$ leaf-level nodes at depth 3.
::::
:::

:::example[Example 7.2 — Valid B-tree check]
Is the following a valid B-tree of order 3 (2-3 tree)?

```text
        [20]
       /    \
   [10]     [30, 40]
  /   \    /   |    \
[5] [15] [25] [35] [45]
```

::::answer[Answer]
Order 3: each node has at most 3 children (2 keys) and non-root nodes have at least ⌈3/2⌉ = 2 children (1 key). Root [20]: 2 children — valid (root needs ≥ 2). Node [10]: 2 children, 1 key — valid. Node [30,40]: 3 children, 2 keys — valid. All leaves at same depth (level 2). **Valid 2-3 tree.**
::::
:::

### Section 7 Practice

:::problem[Problem 17 easy]{difficulty="easy"}
A B-tree of order 4 has height 2 (root at level 0, leaves at level 2). What is the maximum number of keys it can store?

::::solution[Solution]
Max children at each level: root has 4, each of 4 children has 4 leaves = 16 leaves. Each node holds up to $4-1=3$ keys. Total max keys = $3 + 4 \times 3 + 16 \times 3 = 3 + 12 + 48 = 63$.
::::
:::

:::problem[Problem 18 standard]{difficulty="standard"}
Why is the minimum occupancy rule ($\lceil m/2 \rceil - 1$ keys per node) important for B-tree deletion?

::::solution[Solution]
When a key is deleted, a node may drop below the minimum. The tree fixes this by either borrowing a key from a sibling (rotation) or merging with a sibling and pulling a key down from the parent. The minimum threshold ensures there is always room to merge two under-filled siblings into one valid node (they hold at most $2 \times (\lceil m/2 \rceil - 1) + 1 \le m - 1$ keys after the parent key is pulled down).
::::
:::

## 8. Exam Prep

Eight representative exam-style questions with full solutions.

:::example[Q1]
What is the balance factor of a node, and what values are permitted in an AVL tree?

::::answer[Answer]
Balance factor = height(left subtree) − height(right subtree). In an AVL tree, every node must have bf ∈ {−1, 0, +1}. Any value outside this range triggers a rotation.
::::
:::

:::example[Q2]
Describe the four AVL rotation cases and when each is applied.

::::answer[Answer]
**LL:** bf = +2 at node z, left child has bf ≥ 0 → single right rotation at z.

 **RR:** bf = −2 at z, right child has bf ≤ 0 → single left rotation at z.

 **LR:** bf = +2 at z, left child has bf = −1 → left rotate the left child, then right rotate z.

 **RL:** bf = −2 at z, right child has bf = +1 → right rotate the right child, then left rotate z.
::::
:::

:::example[Q3]
AVL insertion requires at most how many rotations? What about deletion?

::::answer[Answer]
Insertion: at most **1** rotation (or 2 single rotations in a double rotation). After one rotation, the subtree height is restored to its pre-insertion value, so no further rotations are needed.

 Deletion: up to **O(log n)** rotations, because each rotation may reduce the subtree height and expose a new imbalance one level up.
::::
:::

:::example[Q4]
List the 5 Red-Black tree properties.

::::answer[Answer]
1. Every node is red or black.

 2. The root is black.

 3. Every NIL leaf is black.

 4. A red node's children are both black.

 5. All paths from a node to descendant NIL leaves have the same number of black nodes (black-height property).
::::
:::

:::example[Q5]
Why does std::map in C++ use a Red-Black tree instead of an AVL tree?

::::answer[Answer]
std::map performs many insertions and deletions. Red-Black trees require at most 2 rotations for insertion and 3 for deletion (vs potentially O(log n) for AVL deletion), making writes faster. The slightly taller height costs a small constant factor in reads — acceptable since map is a general-purpose container.
::::
:::

:::example[Q6]
What is a B+ tree and how does it differ from a B-tree?

::::answer[Answer]
A B+ tree stores all data records in leaf nodes only. Internal nodes store only routing keys (copies of leaf keys) to guide searches. Leaves are linked in a sorted linked list for efficient range queries. A B-tree can store data at any node. B+ trees are preferred in databases because range scans are O(k) where k is the result size rather than requiring multiple tree traversals.
::::
:::

:::example[Q7]
Insert 1, 2, 3, 4 into an empty AVL tree. What is the final tree shape?

::::answer[Answer]
Insert 1: {1}. Insert 2: {1, right=2}. Insert 3: bf(1)=−2, RR case → rotateLeft(1). Root=2, left=1, right=3. Insert 4: bf(2)=−1 → ok, bf(3)=−1 → ok. Final tree: root=2, left=1, right=3, right of 3 = 4.
::::
:::

:::example[Q8]
What is the height of a B-tree of order 100 that stores 1 000 000 keys? (Assume minimum occupancy.)

::::answer[Answer]
Minimum children per non-root node = ⌈100/2⌉ = 50. Using the height bound: $h \le \log_{50}((10^6 + 1)/2) \approx \log_{50}(500000)$. Since $50^3 = 125000$ and $50^4 = 6250000$, we need $h \le 4$. So **at most 4 levels** (height 3, since root is level 0).
::::
:::

:::summary
## Chapter 9 Summary

Balanced trees solve the degenerate BST problem by enforcing structural invariants that keep height at $O(\log n)$.

| Structure | Balance Criterion | Height Bound | Insert Rotations | Delete Rotations | Best Use |
| --- | --- | --- | --- | --- | --- |
| AVL Tree | |bf| ≤ 1 at every node | $\le 1.44 \log_2 n$ | ≤ 1 | O(log n) | Read-heavy |
| Red-Black Tree | 5 color properties | $\le 2 \log_2(n+1)$ | ≤ 2 | ≤ 3 | Write-heavy (STL) |
| B-Tree (order m) | All leaves same depth | $O(\log_m n)$ | O(log n) splits | O(log n) merges | Disk-based (DB, FS) |

### Key Formulas

- AVL balance factor: $\text{bf}(v) = h(\text{left}) - h(\text{right}) \in \{-1, 0, +1\}$
- Height of empty tree: $-1$
- AVL minimum nodes: $N(h) = N(h-1) + N(h-2) + 1$, $N(-1)=0, N(0)=1$
- AVL max height: $\le 1.44 \log_2(n+2)$
- RB max height: $\le 2 \log_2(n+1)$
- B-tree height: $h \le \log_{\lceil m/2 \rceil}\!\left(\frac{n+1}{2}\right)$
:::
