---
title: "Algorithm Analysis & Big-O"
crumb: "Honors DSA · Chapter 3"
meta:
  - "Est. study time: ~75 min"
  - "Unit 1 — Analysis & Linear Structures"
  - "CSE 2383 · MSState"
source: "dsa_ch3_big_o.html"
---

## Overview

The whole point of studying data structures is to choose the right tool for the job. That choice requires a way to compare algorithms independent of machine speed, compiler version, or input quirks. **Asymptotic analysis** — the formalism behind Big-O — provides that common language. By the end of this chapter you will be able to read any code, count its dominant operations, and classify it into a complexity class that tells you exactly how it scales.

:::callout-key[Prerequisites]
- Chapter 2: operation counting, the concept of "dominant term"
- Basic logarithms: $\log_2 n$ means "how many times do we halve $n$ before reaching 1"
:::

## 1. Big-O, Big-Ω, and Big-Θ

:::callout-intuition[Intuition]
We want to say "this algorithm scales like $n^2$" without caring whether it's exactly $3n^2 + 7n + 1$ or $100n^2 - 5$. Big-O captures an *upper bound* on growth. Big-Ω captures a *lower bound*. Big-Θ captures the *tight bound* — both an upper and lower bound of the same class. In everyday usage, "Big-O" is used loosely to mean "the tight complexity," though formally it's only an upper bound.
:::

:::definition[Definition 1.1 — Big-O (upper bound)]
$T(n) = O(f(n))$ if there exist positive constants $c$ and $n_0$ such that

$$
T(n) \le c \cdot f(n) \quad \text{for all } n \ge n_0.
$$

 Informally: $T(n)$ grows no faster than $f(n)$ for large $n$.
:::

:::definition[Definition 1.2 — Big-Ω (lower bound)]
$T(n) = \Omega(f(n))$ if there exist positive constants $c$ and $n_0$ such that

$$
T(n) \ge c \cdot f(n) \quad \text{for all } n \ge n_0.
$$

 Informally: $T(n)$ grows at least as fast as $f(n)$.
:::

:::definition[Definition 1.3 — Big-Θ (tight bound)]
$T(n) = \Theta(f(n))$ if $T(n) = O(f(n))$ AND $T(n) = \Omega(f(n))$. There exist $c_1, c_2, n_0 > 0$ such that

$$
c_1 \cdot f(n) \le T(n) \le c_2 \cdot f(n) \quad \text{for all } n \ge n_0.
$$
:::

:::example[Example 1.1 — Proving Big-O from the definition]
Prove formally that $T(n) = 3n^2 + 7n + 1 = O(n^2)$.

::::answer[Answer]
Choose $c = 11$, $n_0 = 1$. Then $3n^2 + 7n + 1 \le 11n^2$ for all $n \ge 1$.
::::

Work

We need to find $c$ and $n_0$ such that $3n^2 + 7n + 1 \le c \cdot n^2$ for all $n \ge n_0$.

For $n \ge 1$, note that $n \le n^2$ and $1 \le n^2$, so:

$$
3n^2 + 7n + 1 \le 3n^2 + 7n^2 + n^2 = 11n^2.
$$

Thus $T(n) \le 11 \cdot n^2$ for all $n \ge 1$. By definition, $T(n) = O(n^2)$ with $c = 11$, $n_0 = 1$. $\square$

Note: there is no unique choice of $c$ and $n_0$. Choosing $c = 100, n_0 = 1$ also works; so does $c = 4, n_0 = 100$. Any valid pair suffices.
:::

:::example[Example 1.2 — Showing Big-O does NOT hold]
Show that $T(n) = n^2 \ne O(n)$.

::::answer[Answer]
No finite constant $c$ can keep $n^2 \le c \cdot n$ for all large $n$.
::::

Work

Suppose for contradiction that $n^2 = O(n)$. Then there exist $c, n_0$ such that $n^2 \le c \cdot n$ for all $n \ge n_0$. Dividing both sides by $n$ (which is positive): $n \le c$. But this must hold for all $n \ge n_0$, which is impossible since $n$ grows without bound while $c$ is fixed. Contradiction. Therefore $n^2 \ne O(n)$. $\square$
:::

### More worked examples

:::example[Example 1.3 — Identifying Θ]
Is $T(n) = \frac{n(n+1)}{2} = \Theta(n^2)$?

::::answer[Answer]
Yes.
::::

Work

Upper bound: $\dfrac{n(n+1)}{2} = \dfrac{n^2 + n}{2} \le \dfrac{n^2 + n^2}{2} = n^2$ for $n \ge 1$. So $T(n) = O(n^2)$ with $c = 1$.

Lower bound: $\dfrac{n(n+1)}{2} \ge \dfrac{n \cdot n}{2} = \dfrac{n^2}{2}$ for $n \ge 1$. So $T(n) = \Omega(n^2)$ with $c = \frac{1}{2}$.

Since both bounds hold, $T(n) = \Theta(n^2)$. $\square$
:::

### Practice problems

:::problem[Problem 1.1 easy]{difficulty="easy"}
Which of these are true? (a) $5n + 3 = O(n)$ (b) $5n + 3 = O(n^2)$ (c) $n^3 = O(n^2)$ (d) $\log n = O(n)$

::::solution[Solution]
(a) **True**: $5n+3 \le 8n$ for $n \ge 1$. (b) **True**: $O(n) \subseteq O(n^2)$ — any function that's $O(n)$ is also $O(n^2)$ (Big-O is an upper bound, not a tight bound). (c) **False**: $n^3$ grows faster than $n^2$; by the same contradiction argument as Example 1.2. (d) **True**: $\log n \le n$ for all $n \ge 1$.
::::
:::

:::problem[Problem 1.2 standard]{difficulty="standard"}
Prove that $T(n) = 100 = O(1)$. What are valid values for $c$ and $n_0$?

::::solution[Solution]
We need $100 \le c \cdot 1$ for all $n \ge n_0$. Choose $c = 100$, $n_0 = 1$. Then $100 \le 100 \cdot 1 = 100$ for all $n \ge 1$. ✓ Any $c \ge 100$ with $n_0 = 1$ works. The function is constant, so it is trivially $O(1)$.
::::
:::

:::problem[Problem 1.3 challenge]{difficulty="challenge"}
Prove that $T(n) = n \log n = \Omega(n)$ and $T(n) = O(n^2)$, then explain why $T(n) \ne \Theta(n)$ and $T(n) \ne \Theta(n^2)$.

::::solution[Solution]
**Lower bound $\Omega(n)$**: $n \log n \ge n \cdot 1 = n$ for $n \ge 2$ (since $\log n \ge 1$). Choose $c = 1, n_0 = 2$. ✓

**Upper bound $O(n^2)$**: $n \log n \le n \cdot n = n^2$ for $n \ge 1$ (since $\log n \le n$). Choose $c = 1, n_0 = 1$. ✓

**Not $\Theta(n)$**: would require $n \log n \le c \cdot n$, i.e., $\log n \le c$ for all large $n$ — impossible since $\log n \to \infty$.

**Not $\Theta(n^2)$**: would require $n \log n \ge c \cdot n^2$, i.e., $\log n \ge c \cdot n$ for all large $n$ — impossible since $n$ grows faster than $\log n$.

Therefore $n \log n$ is strictly between $\Theta(n)$ and $\Theta(n^2)$ — it is $\Theta(n \log n)$.
::::
:::

## 2. Simplification Rules

:::callout-intuition[Intuition]
In practice, you never go back to the formal definition. Instead, you apply a small set of rules that let you simplify complex expressions by eye. These rules follow directly from the definition but save enormous time.
:::

:::theorem[Rules for Big-O simplification]
1. **Drop constants**: $O(c \cdot f(n)) = O(f(n))$ for any positive constant $c$.
2. **Drop lower-order terms**: $O(f(n) + g(n)) = O(f(n))$ when $f$ dominates $g$ (i.e., $g = O(f)$).
3. **Product rule**: $O(f(n)) \cdot O(g(n)) = O(f(n) \cdot g(n))$.
4. **Sum rule**: $O(f(n)) + O(g(n)) = O(\max(f(n), g(n)))$.
5. **Logarithm base**: $\log_a n = \Theta(\log_b n)$ for any constants $a, b > 1$ — all log bases are equivalent in Big-O.
:::

:::example[Example 2.1 — Simplification chain]
Simplify $T(n) = 4n^3 + 12n^2 + 500n\log n + 9000$.

::::answer[Answer]
$O(n^3)$
::::

Work

Step 1: identify all terms: $4n^3, \; 12n^2, \; 500n\log n, \; 9000$.

Step 2: rank by growth rate: $n^3 \gg n^2 \gg n\log n \gg 1$.

Step 3: keep only the dominant term: $4n^3$.

Step 4: drop the constant: $O(n^3)$. Done.
:::

### Practice problems

:::problem[Problem 2.1 easy]{difficulty="easy"}
Simplify to Big-O: $T(n) = 3 + 6n + 2n^2$

::::solution[Solution]
$O(n^2)$. Dominant term is $2n^2$; drop the constant 2.
::::
:::

:::problem[Problem 2.2 easy]{difficulty="easy"}
Simplify: $T(n) = 17 \log_4 n + 3n$

::::solution[Solution]
$O(n)$. Since $\log n = O(n)$, the $3n$ term dominates. Drop constants.
::::
:::

:::problem[Problem 2.3 standard]{difficulty="standard"}
An algorithm has Phase 1 taking $O(n^2)$ and Phase 2 taking $O(n \log n)$, run sequentially. What is the overall complexity?

::::solution[Solution]
$O(n^2)$. By the sum rule, $O(n^2) + O(n \log n) = O(\max(n^2, n \log n)) = O(n^2)$ since $n^2$ dominates for large $n$.
::::
:::

:::problem[Problem 2.4 standard]{difficulty="standard"}
An outer loop runs $n$ times, and inside, an inner algorithm runs in $O(\log n)$. What is the combined complexity?

::::solution[Solution]
$O(n \log n)$. By the product rule: $O(n) \times O(\log n) = O(n \log n)$.
::::
:::

## 3. Common Complexity Classes

The following table lists complexity classes from best to worst, with typical examples you will encounter in CSE 2383.

| Class | Name | Example operations | For $n=10^6$, ops |
| --- | --- | --- | --- |
| $O(1)$ | Constant | Array index, hash table lookup (avg) | 1 |
| $O(\log n)$ | Logarithmic | Binary search, BST search (balanced) | ~20 |
| $O(n)$ | Linear | Linear search, array traversal | 1,000,000 |
| $O(n \log n)$ | Linearithmic | Mergesort, Heapsort, efficient sorting | ~20,000,000 |
| $O(n^2)$ | Quadratic | Bubble sort, naive string matching | $10^{12}$ |
| $O(n^3)$ | Cubic | Naive matrix multiply, Floyd-Warshall | $10^{18}$ |
| $O(2^n)$ | Exponential | Naive subset enumeration | Astronomical |

:::callout-key[Growth rate intuition]
If an $O(n)$ algorithm processes 1 million items in 1 second, the same machine running an $O(n^2)$ algorithm on 1 million items takes roughly *11 days*. This is why choosing the right data structure is not academic — it is the difference between a product that works and one that cannot ship.
:::

### Practice problems

:::problem[Problem 3.1 easy]{difficulty="easy"}
Rank from fastest to slowest: $O(n^2),\; O(\log n),\; O(n!),\; O(n \log n),\; O(1),\; O(n)$

::::solution[Solution]
$O(1) < O(\log n) < O(n) < O(n \log n) < O(n^2) < O(n!)$
::::
:::

:::problem[Problem 3.2 standard]{difficulty="standard"}
An $O(n^2)$ algorithm takes 4 seconds for $n = 1000$. Approximately how long for $n = 2000$?

::::solution[Solution]
Doubling $n$ multiplies the work by $2^2 = 4$. Time ≈ $4 \times 4 = \mathbf{16}$ seconds. In general, for $O(n^k)$, scaling $n$ by a factor of $r$ scales time by $r^k$.
::::
:::

:::problem[Problem 3.3 challenge]{difficulty="challenge"}
An $O(\log n)$ algorithm takes 30 ms for $n = 10^6$. Approximately how long for $n = 10^{12}$?

::::solution[Solution]
$\log_2(10^6) \approx 20$ and $\log_2(10^{12}) \approx 40$. The work doubles, so time ≈ $60$ ms. Logarithmic algorithms scale beautifully — multiplying $n$ by $10^6$ only doubles the work.
::::
:::

## 4. Best, Worst, and Average Case

:::callout-intuition[Intuition]
Big-O says nothing about which input. A linear search through an array is $O(1)$ if the target happens to be first, and $O(n)$ if it's last. These are best and worst cases. In practice, we most care about the *worst case* (guarantees) and the *average case* (expected everyday performance).
:::

:::definition[Definition 4.1 — Best / Worst / Average Case]
- **Best case**: the minimum cost over all possible inputs of size $n$. Usually not very useful — knowing an algorithm is fast on easy inputs tells you little.
- **Worst case**: the maximum cost over all inputs. Most useful for guarantees (e.g., real-time systems must never exceed a bound).
- **Average case**: expected cost over all inputs, assuming some probability distribution. Most relevant for typical usage. Requires knowledge of input distribution.
:::

:::example[Example 4.1 — Linear search cases]
For linear search in an unsorted array of $n$ elements, find the best, worst, and average-case number of comparisons.

::::answer[Answer]
Best: $1$. Worst: $n$. Average: $\frac{n+1}{2}$. All are $O(n)$ except best which is $O(1)$.
::::

Work

**Best case**: target is at index 0. One comparison. $O(1)$.

**Worst case**: target is at index $n-1$, or not present. $n$ comparisons. $O(n)$.

**Average case**: assume each position equally likely. Expected position = $\frac{1 + 2 + \cdots + n}{n} = \frac{n+1}{2}$ comparisons. $O(n)$.
:::

:::callout-warning[Quicksort: a cautionary tale]
Quicksort has an *average* case of $O(n \log n)$ and a *worst* case of $O(n^2)$ (when the pivot is always the smallest or largest element). In practice it's fast, but on sorted or nearly-sorted input with a naive pivot choice, it degrades to quadratic. This is why libraries use "introsort" (quicksort + heapsort fallback) for worst-case guarantees.
:::

### Practice problems

:::problem[Problem 4.1 easy]{difficulty="easy"}
Insertion sort's best case is $O(n)$ and worst case is $O(n^2)$. Describe an input that causes each.

::::solution[Solution]
**Best case ($O(n)$)**: already sorted input. Each element is in place; only 1 comparison per element is needed. **Worst case ($O(n^2)$)**: reverse-sorted input. Each new element must be moved all the way to position 0, requiring $1 + 2 + \cdots + (n-1) = \frac{n(n-1)}{2}$ swaps.
::::
:::

:::problem[Problem 4.2 standard]{difficulty="standard"}
Why do we most often care about worst-case complexity rather than best-case?

::::solution[Solution]
Best-case analysis tells you the cost on the luckiest possible input, which may be rare or impossible to guarantee. Worst-case gives a firm *upper bound* — the algorithm will never do more work than this, regardless of input. For system design, this guarantee is what you need: a database can't say "our queries are fast unless you get unlucky." Worst-case analysis also provides a baseline for comparison between algorithms that holds regardless of input distribution.
::::
:::

## 5. Analyzing Code Directly

:::callout-intuition[Intuition]
With the formal definitions behind you and the simplification rules in hand, analyzing real code becomes mechanical: find the loops, find what controls their length, multiply nested loops together, add sequential phases, keep the dominant term.
:::

### The recipe

1. **Identify basic operations** — comparisons, assignments, arithmetic. One constant cost each.
2. **For each loop**, find how many times it runs as a function of $n$.
3. **Multiply nested loops**. Add sequential blocks.
4. **Drop constants and lower-order terms**.
5. **Specify the case** — is this worst case? Average?

### Worked examples

:::example[Example 5.1 — Binary search]
Analyze the time complexity of binary search on a sorted array of size $n$.

::::answer[Answer]
Worst case: $O(\log n)$.
::::

Work

```cpp
int binarySearch(int arr[], int n, int target) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {                  // how many times?
        int mid = lo + (hi - lo) / 2;   // O(1)
        if (arr[mid] == target) return mid;
        else if (arr[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}
```

Each iteration cuts the search range in half. Starting with $n$ elements: after 1 step → $n/2$, after 2 steps → $n/4$, ..., after $k$ steps → $n/2^k$. The loop ends when $n/2^k = 1$, i.e., $k = \log_2 n$. So at most $\log_2 n + 1$ iterations. Each does $O(1)$ work. Total: $O(\log n)$.
:::

:::example[Example 5.2 — Recursive Fibonacci]
What is the time complexity of the naive recursive Fibonacci?

```cpp
int fib(int n) {
    if (n <= 1) return n;
    return fib(n-1) + fib(n-2);
}
```

::::answer[Answer]
$O(2^n)$ — exponential.
::::

Work

Let $T(n)$ = number of calls made by `fib(n)`. Then $T(n) = T(n-1) + T(n-2) + 1$, which is the Fibonacci recurrence itself. The Fibonacci sequence grows as $\phi^n$ where $\phi = \frac{1+\sqrt{5}}{2} \approx 1.618$. So $T(n) = O(\phi^n) = O(1.618^n)$, which is $O(2^n)$ as an upper bound. In practice: `fib(50)` requires ~$2^{50} \approx 10^{15}$ calls — completely infeasible.

With memoization (or bottom-up DP), this drops to $O(n)$. Dynamic programming in Chapter 18.
:::

### Practice problems

:::problem[Problem 5.1 easy]{difficulty="easy"}
What is the time complexity of this function?

```cpp
void printAll(int arr[], int n) {
    for (int i = 0; i < n; i++)
        std::cout << arr[i];
}
```

::::solution[Solution]
$O(n)$. One loop, runs $n$ times, each iteration $O(1)$.
::::
:::

:::problem[Problem 5.2 standard]{difficulty="standard"}
Analyze this function's time complexity:

```cpp
bool hasDuplicate(int arr[], int n) {
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (arr[i] == arr[j]) return true;
    return false;
}
```

::::solution[Solution]
**Worst case**: $O(n^2)$. The outer loop runs $n$ times; for each $i$, the inner loop runs $n - i - 1$ times. Total comparisons: $(n-1) + (n-2) + \cdots + 1 = \frac{n(n-1)}{2} = O(n^2)$. **Best case**: $O(1)$ if the first two elements are equal.
::::
:::

:::problem[Problem 5.3 standard]{difficulty="standard"}
What is the time complexity of this function? Careful — the inner loop bound is not $n$.

```cpp
void mystery(int n) {
    for (int i = 0; i < n; i++) {
        int j = n;
        while (j > 1) j /= 2;
    }
}
```

::::solution[Solution]
$O(n \log n)$. The outer loop runs $n$ times. For each iteration, `j` starts at $n$ and halves each time until it reaches 1 — that's $O(\log n)$ iterations of the inner loop. Note: `j` is reset to $n$ at the start of each outer iteration, so the inner loop always does $O(\log n)$ work regardless of $i$. Total: $n \times O(\log n) = O(n \log n)$.
::::
:::

:::problem[Problem 5.4 challenge]{difficulty="challenge"}
Solve this recurrence relation (merge sort's complexity): $T(n) = 2T(n/2) + n$, $T(1) = 1$. Show the work using the recursion tree method.

::::solution[Solution]
**Recursion tree method:**

Level 0: one problem of size $n$, costs $n$. Level 1: two problems of size $n/2$, costs $2 \cdot \frac{n}{2} = n$. Level 2: four problems of size $n/4$, costs $4 \cdot \frac{n}{4} = n$. Level $k$: $2^k$ problems of size $n/2^k$, costs $n$.

There are $\log_2 n$ levels (we stop when size = 1). Each level costs exactly $n$. Total cost: $n \cdot \log_2 n = O(n \log n)$. This is why merge sort is $\Theta(n \log n)$ — both a tight upper and lower bound.
::::
:::

:::summary
## Chapter Summary

| Notation | Meaning | Use |
| --- | --- | --- |
| $O(f(n))$ | Upper bound — grows no faster than $f$ | Worst-case guarantee |
| $\Omega(f(n))$ | Lower bound — grows at least as fast as $f$ | Best-case floor |
| $\Theta(f(n))$ | Tight bound — grows exactly like $f$ | Precise classification |

### Hierarchy (fastest → slowest)

$$
O(1) \subset O(\log n) \subset O(n) \subset O(n \log n) \subset O(n^2) \subset O(n^3) \subset O(2^n)
$$

### If you remember nothing else

Drop constants. Drop lower-order terms. Multiply nested loops. Add sequential phases. The result is the Big-O class — and that class determines whether your data structure can scale to the real world.
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
Give the Big-O for each: (a) accessing the 5th element of an array (b) finding the minimum in an unsorted array (c) searching a balanced BST of $n$ nodes.

::::solution[Solution]
(a) $O(1)$ — direct index. (b) $O(n)$ — must check every element. (c) $O(\log n)$ — balanced BST height is $O(\log n)$.
::::
:::

:::problem[Problem M.2 standard]{difficulty="standard"}
What is the overall complexity of an algorithm that: first sorts an array in $O(n \log n)$, then binary-searches it $n$ times?

::::solution[Solution]
$O(n \log n) + n \cdot O(\log n) = O(n \log n) + O(n \log n) = O(n \log n)$. Both phases are the same class, so the total is still $O(n \log n)$.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
A data structure supports `insert` in $O(\log n)$ and `search` in $O(\log n)$. You call `insert` $n$ times, then `search` $n$ times. What is the total cost?

::::solution[Solution]
Total cost = $n \cdot O(\log n) + n \cdot O(\log n) = O(n \log n) + O(n \log n) = O(n \log n)$.
::::
:::

:::problem[Problem M.4 challenge]{difficulty="challenge"}
Analyze the time complexity of this function precisely (not just Big-O — give the exact count of `work()` calls and then the Big-O):

```cpp
void f(int n) {
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= i; j++)
            for (int k = 1; k <= j; k++)
                work();
}
```

::::solution[Solution]
The number of calls is $\displaystyle\sum_{i=1}^{n} \sum_{j=1}^{i} j = \sum_{i=1}^{n} \frac{i(i+1)}{2} = \frac{1}{2}\sum_{i=1}^{n}(i^2+i) = \frac{1}{2}\left[\frac{n(n+1)(2n+1)}{6} + \frac{n(n+1)}{2}\right]$.

The dominant term is $\frac{n^3}{6}$, so the Big-O is $\mathbf{O(n^3)}$. Three nested loops each bounded by $n$ → cubic. The exact constant ($\frac{1}{6}$) doesn't affect the class.
::::
:::

:::problem[Problem M.5 challenge]{difficulty="challenge"}
True or false, with justification: "If algorithm A is $O(n^2)$ and algorithm B is $O(n \log n)$, then B is always faster than A in practice."

::::solution[Solution]
**False.** Big-O hides constants. If A has constant 1 and B has constant $10^6$, then for small $n$, A is faster. Also, "faster" depends on $n$: for small $n$ (say $n < 50$), an $O(n^2)$ algorithm with low overhead often beats an $O(n \log n)$ algorithm with high constant factors. This is why std::sort switches to insertion sort for small subarrays — insertion sort's constant is tiny even though it's quadratic.
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook.
