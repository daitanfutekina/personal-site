---
title: "Heaps & Priority Queues"
crumb: "Honors DSA · Chapter 10"
meta:
  - "Est. study time: ~60 min"
  - "Unit 3"
  - "CSE 2383 · MSState"
source: "dsa_ch10_heaps.html"
---

## 1. Priority Queue ADT

:::callout-intuition[Intuition]
Imagine a hospital emergency room: patients don't get served in the order they arrive — the most critical case always goes first. A priority queue is this exact concept in code: you can insert items with priorities, and you can always extract the item with the highest (or lowest) priority in O(log n) time, regardless of insertion order.
:::

### Core Operations

| Operation | Description | Complexity (heap) |
| --- | --- | --- |
| `insert(key)` | Add a new element with a given priority | O(log n) |
| `findMin()` | Return the minimum element without removing it | O(1) |
| `deleteMin()` | Remove and return the minimum element | O(log n) |
| `buildHeap(arr)` | Initialize from an unordered array | O(n) |

### Applications

- **Task scheduling:** OS process scheduler picks the highest-priority runnable process.
- **Dijkstra's shortest path:** Always expand the unvisited node with minimum tentative distance.
- **Huffman coding:** Repeatedly merge the two lowest-frequency symbols — a min-heap makes each merge O(log n).
- **A\* search:** Priority queue ordered by $f = g + h$ determines which node to expand next.
- **Median maintenance:** Use two heaps (max-heap for lower half, min-heap for upper half) to maintain the median in O(log n) per insert.

:::example[Example 1.1 — Priority queue simulation]
Simulate a min priority queue with operations: insert(5), insert(3), insert(8), findMin(), deleteMin(), findMin().

::::answer[Answer]
After inserts: queue contains {3, 5, 8} (conceptually). findMin() → 3. deleteMin() → removes 3. findMin() → 5.
::::
:::

:::example[Example 1.2 — Naive implementations]
Compare the complexity of insert and deleteMin for (a) unsorted array, (b) sorted array, (c) binary heap.

::::answer[Answer]
| Implementation | insert | deleteMin |
| --- | --- | --- |
| Unsorted array | O(1) | O(n) — must scan for min |
| Sorted array | O(n) — maintain sort order | O(1) — min is at end |
| Binary heap | O(log n) | O(log n) |

The heap achieves the best of both worlds: no O(n) operation.
::::
:::

### Section 1 Practice

:::problem[Problem 1 easy]{difficulty="easy"}
Name two real-world algorithms that use a priority queue as a core data structure.

::::solution[Solution]
Any two from: Dijkstra's shortest path, Prim's MST, Huffman coding, A\* search, heap sort, event-driven simulation.
::::
:::

:::problem[Problem 2 standard]{difficulty="standard"}
If you need to repeatedly find and remove the maximum (not minimum) element, what change would you make to a min-heap-based priority queue?

::::solution[Solution]
Either (a) negate all keys before insertion and treat the minimum of negated values as the maximum of original values, or (b) use a max-heap where the parent is always ≥ its children. The structure and algorithms are identical — only the comparison direction changes.
::::
:::

## 2. Binary Heap Structure

A **binary heap** is a complete binary tree stored efficiently in a plain array — no pointers needed. Being *complete* means every level is fully filled except possibly the last, which is filled from left to right.

### Array Indexing (0-based)

For a node at index `i`:

- Parent: `(i - 1) / 2`
- Left child: `2*i + 1`
- Right child: `2*i + 2`

### Array Indexing (1-based)

If the root is at index 1 (index 0 unused):

- Parent: `i / 2`
- Left child: `2*i`
- Right child: `2*i + 1`

The 1-based form has simpler formulas; the 0-based form is more natural in C++.

:::example[Example 10.1 — Heap Array Mapping]
The array [10, 20, 15, 30, 40] represents a min-heap. Draw the tree and verify parent–child relationships.

::::answer[Answer]
Root=10 (i=0), children: 20 (i=1) and 15 (i=2). Node 20's children: 30 (i=3) and 40 (i=4). All parents ≤ children, so min-heap property holds.
::::

Work

```
Index: 0   1   2   3   4
Value: 10  20  15  30  40

        10          (index 0)
       /  \
     20    15       (index 1, 2)
    /  \
  30    40          (index 3, 4)

parent(1) = (1-1)/2 = 0 → value 10 ✓
parent(3) = (3-1)/2 = 1 → value 20 ✓
```
:::

:::callout-key[Key Insight]
The array representation works *only* because the tree is complete. If any internal node were missing, the index formulas would break. This is why heaps are always kept complete.
:::

:::problem[Problem 3 · easy]{difficulty="easy"}
Given a 0-indexed heap array with 7 elements, what are the children of the node at index 2?

::::solution[Solution]
Left child: 2\*2+1 = 5. Right child: 2\*2+2 = 6.
::::
:::

:::problem[Problem 4 · standard]{difficulty="standard"}
A complete binary tree has 10 nodes. What is its height? How many nodes are at the last level?

::::solution[Solution]
Height = ⌊log₂(10)⌋ = 3. A perfect tree of height 3 has 15 nodes; our tree has 10, so 10 − 7 = 3 nodes at the last level.
::::
:::

## 3. The Heap Property

The critical invariant that makes heaps useful:

- **Max-heap:** Every node's value is ≥ both of its children's values. The maximum element is always at the root.
- **Min-heap:** Every node's value is ≤ both of its children's values. The minimum element is always at the root.

Note the heap property only constrains parent–child pairs, not siblings. A node's left child may be larger or smaller than its right child.

:::callout-pitfall[Common Pitfall]
A sorted array is a valid heap (trivially), but a heap is NOT necessarily sorted. The heap only guarantees the root is the min/max — not the order of other elements.
:::

:::example[Example 10.2 — Valid vs Invalid Heap]
Which of these arrays is a valid min-heap? A: [1, 3, 2, 7, 5, 6] B: [1, 3, 2, 5, 7, 4]

::::answer[Answer]
A is valid. B: node at index 2 (value 2) has right child at index 6 (value 4) — but 2 ≤ 4 ✓. Actually B is also valid. Both satisfy min-heap property.
::::

Work

Check each parent–child pair. For a 0-indexed array of length n, check all i from 0 to n/2−1: heap[i] ≤ heap[2i+1] and heap[i] ≤ heap[2i+2] (if they exist).
:::

:::problem[Problem 5 · easy]{difficulty="easy"}
Is [2, 4, 3, 8, 9, 5, 7] a valid min-heap?

::::solution[Solution]
Yes. Check: 2≤4✓, 2≤3✓, 4≤8✓, 4≤9✓, 3≤5✓, 3≤7✓. All parent–child constraints satisfied.
::::
:::

:::problem[Problem 6 · standard]{difficulty="standard"}
Is [5, 10, 8, 15, 12, 9, 6] a valid min-heap? If not, identify the violation.

::::solution[Solution]
No. Node at index 2 (value 8) has right child at index 6 (value 6). Since 8 > 6, the min-heap property is violated.
::::
:::

## 4. Insertion & Sift-Up

To insert a new element while maintaining the heap property:

1. Place the new element at the **end** of the array (next position in the complete tree).
2. **Sift up**: repeatedly compare the element with its parent; if it violates the heap property, swap. Continue until the property holds or the root is reached.

Time complexity: **O(log n)** — at most ⌊log₂n⌋ swaps, one per level.

:::example[Example 10.3 — Insert into Min-Heap]
Min-heap: [2, 5, 3, 8, 9, 7]. Insert 1.

::::answer[Answer]
After insertion: [1, 5, 2, 8, 9, 7, 3].
::::

Work

```
Start: [2, 5, 3, 8, 9, 7] → append 1 → [2, 5, 3, 8, 9, 7, 1]
                                                                  ^(index 6)
Sift up: parent(6) = (6-1)/2 = 2, value = 3. Is 1 < 3? Yes → swap.
[2, 5, 1, 8, 9, 7, 3]  (1 now at index 2)
parent(2) = 0, value = 2. Is 1 < 2? Yes → swap.
[1, 5, 2, 8, 9, 7, 3]  (1 now at index 0, the root)
Root reached. Done.
```
:::

```cpp
// Min-heap insert (0-indexed)
void insert(vector<int>& heap, int val) {
    heap.push_back(val);          // place at end
    int i = heap.size() - 1;
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (heap[parent] <= heap[i]) break;  // heap property ok
        swap(heap[parent], heap[i]);
        i = parent;
    }
}
```

:::problem[Problem 7 · standard]{difficulty="standard"}
Starting from an empty min-heap, insert elements in order: 10, 4, 15, 2, 8. Show the array after each insertion.

::::solution[Solution]
Insert 10: [10]
Insert 4: [10,4] → sift up: 4<10 → swap → [4,10]
Insert 15: [4,10,15] → 15>4, done → [4,10,15]
Insert 2: [4,10,15,2] → parent(3)=1=10, 2<10 swap → [4,2,15,10] → parent(1)=0=4, 2<4 swap → [2,4,15,10]
Insert 8: [2,4,15,10,8] → parent(4)=1=4, 8>4, done → [2,4,15,10,8]
::::
:::

:::problem[Problem 8 · challenge]{difficulty="challenge"}
In the worst case, how many comparisons does inserting n elements one-by-one into an empty heap require? Give a tight bound.

::::solution[Solution]
Each insert costs O(log k) where k is the current size. Total = Σ log k for k=1 to n = O(n log n). Tight: Θ(n log n) in the worst case.
::::
:::

## 5. Delete-Min & Sift-Down

To remove the minimum element from a min-heap:

1. The minimum is always at **index 0** (the root).
2. Replace the root with the **last element** (index n−1), then remove the last element.
3. **Sift down**: compare the new root with its smaller child; if it's larger, swap. Continue until the heap property holds or a leaf is reached.

Time complexity: **O(log n)**.

:::example[Example 10.4 — Delete-Min Trace]
Min-heap: [1, 4, 3, 8, 9, 7, 5]. Remove the minimum.

::::answer[Answer]
Minimum = 1. Result heap: [3, 4, 5, 8, 9, 7].
::::

Work

```
Remove root (1). Move last element (5) to root:
[5, 4, 3, 8, 9, 7]  (array now has 6 elements)
Sift down from index 0:
  Children: index 1 (val 4), index 2 (val 3). Smaller child = 3 at index 2.
  5 > 3 → swap. [3, 4, 5, 8, 9, 7]
  Now at index 2. Children: index 5 (val 7), index 6 (DNE).
  5 < 7 → heap property ok. Done.
```
:::

```cpp
// Sift down (min-heap, 0-indexed)
void siftDown(vector<int>& h, int i) {
    int n = h.size();
    while (true) {
        int smallest = i;
        int l = 2*i+1, r = 2*i+2;
        if (l < n && h[l] < h[smallest]) smallest = l;
        if (r < n && h[r] < h[smallest]) smallest = r;
        if (smallest == i) break;
        swap(h[i], h[smallest]);
        i = smallest;
    }
}

int deleteMin(vector<int>& h) {
    int minVal = h[0];
    h[0] = h.back(); h.pop_back();
    if (!h.empty()) siftDown(h, 0);
    return minVal;
}
```

:::callout-warning[Important Detail]
When sifting down, always swap with the *smaller* child (in a min-heap), not just any child that is smaller. Swapping with the wrong child can violate the heap property on the other side.
:::

:::problem[Problem 9 · standard]{difficulty="standard"}
Min-heap: [2, 4, 6, 8, 10, 9]. Perform delete-min and show each step.

::::solution[Solution]
Remove 2, move 9 to root: [9,4,6,8,10]. Sift down: children 4,6; min child = 4 at index 1. 9>4 → swap: [4,9,6,8,10]. At index 1: children 8,10; min=8. 9>8 → swap: [4,8,6,9,10]. At index 3: no children (index 7,8 out of bounds). Done. Result: [4,8,6,9,10].
::::
:::

:::problem[Problem 10 · challenge]{difficulty="challenge"}
Why is it incorrect to simply remove the root and promote the smaller child repeatedly (without using the last element)?

::::solution[Solution]
This approach would leave a "hole" that propagates down, potentially making the tree incomplete. Heaps must remain complete trees for the array representation to work. Moving the last element preserves completeness, then sift-down restores the heap property.
::::
:::

## 6. BuildHeap — O(n) Heapification

Given an arbitrary array, convert it into a valid heap. The naive approach (insert each element one by one) costs O(n log n). There's a better way.

### Linear-Time BuildHeap

Leaf nodes (indices n/2 through n−1) already satisfy the heap property trivially — they have no children. Start from the last internal node (index n/2 − 1) and sift down each node toward the root.

```cpp
void buildHeap(vector<int>& h) {
    int n = h.size();
    // Start from last non-leaf, go to root
    for (int i = n/2 - 1; i >= 0; i--) {
        siftDown(h, i);
    }
}
```

:::callout-intuition[Why O(n) and Not O(n log n)?]
Nodes near the bottom of the tree have very little work to do during sift-down. Half the nodes are leaves (0 work). A quarter are at height 1 (at most 1 swap each). Only the root does up to log n swaps. Summing: n/2·0 + n/4·1 + n/8·2 + ... = O(n). The series converges because most nodes are near leaves.
:::

:::example[Example 10.5 — BuildHeap Trace]
Convert [5, 3, 8, 1, 9, 2, 7] into a min-heap using BuildHeap.

::::answer[Answer]
Result: [1, 3, 2, 5, 9, 8, 7].
::::

Work

```
Array: [5, 3, 8, 1, 9, 2, 7],  n=7
Last internal node: n/2-1 = 2 (value 8)

i=2 (val 8): children 2 (val 7) at i=6. Careful: left=2*2+1=5 (val 2), right=2*2+2=6 (val 7).
  min child = 2 at index 5. 8 > 2 → swap. [5, 3, 2, 1, 9, 8, 7]

i=1 (val 3): children at 3 (val 1), 4 (val 9). min child = 1 at index 3. 3 > 1 → swap.
  [5, 1, 2, 3, 9, 8, 7]. Now at index 3 (val 3): children 7,8 — out of bounds. Done.

i=0 (val 5): children at 1 (val 1), 2 (val 2). min child = 1 at index 1. 5 > 1 → swap.
  [1, 5, 2, 3, 9, 8, 7]. Now at index 1 (val 5): children 3 (val 3), 4 (val 9). 5 > 3 → swap.
  [1, 3, 2, 5, 9, 8, 7]. At index 3 (val 5): no children in range. Done.

Final: [1, 3, 2, 5, 9, 8, 7]
```
:::

:::problem[Problem 11 · standard]{difficulty="standard"}
Apply BuildHeap to [10, 7, 2, 6, 4, 8, 1]. Show the array after each sift-down step.

::::solution[Solution]
n=7, last internal = index 2.

 i=2 (val 2): left=5 (val 8), right=6 (val 1). min=1 at 6. 2>1 → swap → [10,7,1,6,4,8,2]. At i=6: no children.

 i=1 (val 7): left=3 (val 6), right=4 (val 4). min=4 at 4. 7>4 → swap → [10,4,1,6,7,8,2]. At i=4: no children.

 i=0 (val 10): left=1 (val 4), right=2 (val 1). min=1 at 2. 10>1 → swap → [1,4,10,6,7,8,2]. At i=2: left=5(8), right=6(2). min=2 at 6. 10>2 → swap → [1,4,2,6,7,8,10].

 Final: [1,4,2,6,7,8,10]
::::
:::

## 7. Heapsort

Heapsort leverages the heap to sort an array in O(n log n) time, in-place, with O(1) extra space.

1. **Phase 1:** BuildHeap — convert the array into a max-heap. O(n).
2. **Phase 2:** Extraction — repeatedly swap the root (maximum) with the last unsorted element, reduce the heap size by 1, then sift-down. O(n log n).

```cpp
void heapsort(vector<int>& arr) {
    int n = arr.size();
    // Build max-heap
    for (int i = n/2 - 1; i >= 0; i--)
        siftDownMax(arr, i, n);
    // Extract elements one by one
    for (int end = n-1; end > 0; end--) {
        swap(arr[0], arr[end]);   // move max to sorted position
        siftDownMax(arr, 0, end); // restore heap for remaining elements
    }
}
```

:::callout-key[Heapsort Properties]
**Time:** O(n log n) in all cases (best, average, worst). **Space:** O(1) extra — truly in-place. **Stability:** NOT stable. **Cache:** poor — sift-down accesses distant memory locations, making it slower than quicksort in practice despite the same asymptotic complexity.
:::

:::example[Example 10.6 — Heapsort Trace]
Sort [4, 10, 3, 5, 1] using heapsort.

::::answer[Answer]
[1, 3, 4, 5, 10]
::::

Work

```
BuildHeap (max): [4,10,3,5,1] → [10,5,3,4,1]
Step 1: swap(arr[0],arr[4]): [1,5,3,4,10]. SiftDown(0, size=4): → [5,4,3,1 | 10]
Step 2: swap(arr[0],arr[3]): [1,4,3,5,10]. SiftDown(0,3): → [4,1,3 | 5,10]
Step 3: swap(arr[0],arr[2]): [3,1,4,5,10]. SiftDown(0,2): → [3,1 | 4,5,10]
Step 4: swap(arr[0],arr[1]): [1,3,4,5,10]. Done.
Result: [1, 3, 4, 5, 10] ✓
```
:::

:::problem[Problem 12 · standard]{difficulty="standard"}
Why does heapsort use a *max*-heap to sort in ascending order, not a min-heap?

::::solution[Solution]
Each extraction places the maximum at the current end of the array, building the sorted result from right to left. A min-heap would put the minimum at the front — but the "sorted" positions accumulate at the end, so we need the largest to go there first. You could sort descending using a min-heap, or sort ascending using a max-heap.
::::
:::

:::problem[Problem 13 · challenge]{difficulty="challenge"}
Compare heapsort, merge sort, and quicksort on: (a) time complexity, (b) space, (c) stability, (d) cache performance.

::::solution[Solution]
(a) All three are O(n log n) average; quicksort is O(n²) worst case while heap and merge are O(n log n) worst.

 (b) Heapsort O(1), Quicksort O(log n) stack frames, Mergesort O(n) auxiliary.

 (c) Mergesort is stable; quicksort and heapsort are not stable by default.

 (d) Mergesort and quicksort have good cache locality; heapsort has poor cache due to scattered array accesses during sift-down.
::::
:::

## 8. Exam Prep

:::callout-tip[Exam Focus]
Expect questions on: heap array indexing formulas, tracing insert/delete-min, explaining why BuildHeap is O(n), heapsort steps, and comparing heap to other priority queue implementations.
:::

:::problem[Exam Q1 · standard]{difficulty="standard"}
What is the time complexity of each operation for a binary heap: (a) insert, (b) find-min, (c) delete-min, (d) build-heap from n elements?

::::solution[Solution]
(a) O(log n). (b) O(1) — min is always at index 0. (c) O(log n). (d) O(n) using the bottom-up algorithm; O(n log n) if inserting one-by-one.
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
Draw the min-heap that results from inserting 5, 3, 8, 1, 4, 2 in that order. Show the array representation.

::::solution[Solution]
Insert 5: [5]
Insert 3: [5,3]→sift→[3,5]
Insert 8: [3,5,8]
Insert 1: [3,5,8,1]→sift: parent(3)=1=5, 1<5 swap→[3,1,8,5]→parent(1)=0=3, 1<3 swap→[1,3,8,5]
Insert 4: [1,3,8,5,4]→parent(4)=1=3, 4>3 done→[1,3,8,5,4]
Insert 2: [1,3,8,5,4,2]→parent(5)=2=8, 2<8 swap→[1,3,2,5,4,8]→parent(2)=0=1, 2>1 done.
Final: [1,3,2,5,4,8]
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
After delete-min on [1, 3, 2, 5, 4, 8], what is the resulting heap array?

::::solution[Solution]
Remove the root (1) and move the last element (8) into its place: `[8,3,2,5,4]`. Sift down from index 0: its children are 3 at index 1 and 2 at index 2, and the smaller is 2, so swap → `[2,3,8,5,4]`. The 8 now sits at index 2, whose children would be at indices 5 and 6 — both past the end of a five-element array — so it is a leaf and sifting stops. Result: `[2,3,8,5,4]`.
::::
:::

:::problem[Exam Q4 · challenge]{difficulty="challenge"}
Explain why the bottom-up BuildHeap algorithm runs in O(n) time. Use the heights of nodes in your argument.

::::solution[Solution]
A node at height h requires at most h sift-down steps. In a heap of n nodes, there are at most ⌈n/2^(h+1)⌉ nodes at height h. Total work = Σ(h=0 to log n) h · n/2^(h+1) = n · Σ(h=0 to ∞) h/2^(h+1). The series Σ h/2^h = 2, so total work = O(n). Contrast with O(n log n) for inserting one-by-one: each of n inserts costs O(log n).
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
You need a data structure supporting insert and find-max in O(1), and delete-max in O(log n). What do you use?

::::solution[Solution]
A max-heap. Find-max is O(1) (root always holds the max), insert and delete-max are O(log n).
::::
:::

:::problem[Exam Q6 · standard]{difficulty="standard"}
Is a sorted array in ascending order a valid min-heap? Is a sorted array in descending order a valid max-heap?

::::solution[Solution]
Yes to both. A sorted ascending array satisfies min-heap: every parent (earlier index) ≤ both children (later indices). Similarly, sorted descending satisfies max-heap property.
::::
:::

:::problem[Exam Q7 · challenge]{difficulty="challenge"}
Design an algorithm to find the k-th smallest element in an array of n elements using a heap. What is the time complexity?

::::solution[Solution]
Option 1: BuildHeap (O(n)), then call delete-min k times (O(k log n)). Total: O(n + k log n).
Option 2: Use a max-heap of size k. Insert first k elements, then for each remaining element: if it's smaller than the max (root), replace the root and sift-down. Final root = k-th smallest. Time: O(n log k).
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
Can you implement a heap that supports both find-min and find-max in O(1)? Describe an approach.

::::solution[Solution]
A min-max heap alternates between min and max levels. Even-depth levels maintain the min-heap property, odd-depth levels maintain the max-heap. The root is the global minimum (O(1)), and the global maximum is the larger of the root's two children (O(1) with a small constant). Insertions and deletions are O(log n).
::::
:::

:::summary
## Chapter 10 Summary

| Operation | Binary Heap | Sorted Array | Unsorted Array |
| --- | --- | --- | --- |
| find-min | O(1) | O(1) | O(n) |
| insert | O(log n) | O(n) | O(1) |
| delete-min | O(log n) | O(1) shift O(n) | O(n) |
| build from n elements | O(n) | O(n log n) | O(n) |
| heapsort | O(n log n) | — | — |

**Key formulas (0-indexed):** parent = (i−1)/2, left = 2i+1, right = 2i+2. Sift-up for insert; sift-down for delete-min. BuildHeap starts at index n/2−1, works toward root.
:::
