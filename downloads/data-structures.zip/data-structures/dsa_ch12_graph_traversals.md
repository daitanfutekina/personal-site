---
title: "Graph Traversals"
crumb: "Honors DSA · Chapter 12"
meta:
  - "Est. study time: ~65 min"
  - "Unit 4"
  - "CSE 2383 · MSState"
source: "dsa_ch12_graph_traversals.html"
---

## 1. BFS — Algorithm

:::callout-intuition[Intuition]
Breadth-First Search explores a graph layer by layer — like ripples spreading outward from a stone dropped in water. First all vertices at distance 1, then distance 2, and so on. This guarantees shortest paths in unweighted graphs.
:::

:::definition[Definition 12.1 — BFS]
**Breadth-First Search (BFS)** from a source vertex $s$ visits all vertices reachable from $s$ in order of increasing hop distance. It uses a queue (FIFO) to determine which vertex to explore next. Each vertex is visited exactly once.
:::

### BFS Algorithm Steps

1. Mark the source $s$ as visited. Enqueue $s$.
2. While the queue is not empty:

   1. Dequeue the front vertex $u$.
   2. For each unvisited neighbor $v$ of $u$: mark $v$ visited, enqueue $v$.

:::callout-pitfall[Critical Rule]
Mark a vertex visited *when you enqueue it*, not when you dequeue it. If you wait until dequeue, a vertex can be enqueued multiple times before processing, corrupting the traversal order and breaking the O(V+E) guarantee.
:::

```cpp
#include <vector>
#include <queue>
using namespace std;

// BFS from source s; returns visited array and parent array
void bfs(int s, int V, vector<vector<int>>& adj,
         vector<bool>& visited, vector<int>& parent, vector<int>& dist) {
    visited.assign(V, false);
    parent.assign(V, -1);
    dist.assign(V, -1);

    queue<int> q;
    visited[s] = true;   // mark BEFORE enqueue
    dist[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : adj[u]) {
            if (!visited[v]) {
                visited[v] = true;   // mark BEFORE enqueue
                parent[v] = u;
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
}
```

**Time complexity:** $O(V + E)$ — each vertex enqueued/dequeued once, each edge examined once (twice for undirected).

**Space complexity:** $O(V)$ — queue holds at most $V$ vertices; visited and parent arrays are size $V$.

:::example[Example 12.1 — BFS Trace]
Undirected graph: 0-1, 0-2, 1-3, 1-4, 2-5. Run BFS from vertex 0. Show the queue state and visited array at each step.

::::answer[Answer]
BFS order: 0, 1, 2, 3, 4, 5. Distances: d[0]=0, d[1]=1, d[2]=1, d[3]=2, d[4]=2, d[5]=2.
::::

Work

```
Step 1: visited[0]=T. Queue: [0]

Step 2: Dequeue 0. Neighbors: 1,2. Mark 1,2 visited, enqueue. Queue: [1, 2]

       dist[1]=1, dist[2]=1

Step 3: Dequeue 1. Neighbors: 0,3,4. 0 visited. Mark 3,4, enqueue. Queue: [2, 3, 4]

       dist[3]=2, dist[4]=2

Step 4: Dequeue 2. Neighbors: 0,5. 0 visited. Mark 5, enqueue. Queue: [3, 4, 5]

       dist[5]=2

Step 5: Dequeue 3. No unvisited neighbors. Queue: [4, 5]

Step 6: Dequeue 4. No unvisited neighbors. Queue: [5]

Step 7: Dequeue 5. No unvisited neighbors. Queue: []  Done.

visited: [T, T, T, T, T, T]   dist: [0, 1, 1, 2, 2, 2]

```
:::

### Section 1 Practice

:::problem[Problem 1 · easy]{difficulty="easy"}
Why does BFS use a queue (FIFO) rather than a stack (LIFO)?

::::solution[Solution]
A queue ensures vertices are processed in the order they were discovered — nearest vertices first. This is what guarantees level-by-level exploration. A stack would process the most recently discovered vertex first, which gives DFS behavior (depth-first, not breadth-first).
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Graph edges: 1-2, 1-3, 2-4, 3-4, 4-5. Run BFS from vertex 1. What is the BFS order and the distance from vertex 1 to vertex 5?

::::solution[Solution]
BFS order: 1, 2, 3, 4, 5 (or 1, 3, 2, 4, 5 depending on neighbor order).

 Distance from 1 to 5: d[5] = 3 (path: 1→2→4→5 or 1→3→4→5).
::::
:::

## 2. BFS Properties & Applications

BFS explores all vertices reachable from the source, visiting them in **non-decreasing order of distance** (number of edges). This makes BFS the algorithm of choice for unweighted shortest paths.

### Shortest Path in Unweighted Graphs

BFS guarantees `dist[v]` = shortest path length from source to v. Record parent pointers to reconstruct the path.

### Applications

- **Shortest path** (unweighted): web crawling, social-network distance
- **Connected components**: run BFS from each unvisited vertex
- **Bipartite check**: 2-color the graph during BFS; conflict = not bipartite
- **Level-order traversal** of a tree
- **Cycle detection** in undirected graphs

:::example[Example 12.2 — BFS Shortest Path]
Graph edges (undirected): 1-2, 1-3, 2-4, 3-4, 4-5. Find shortest path from 1 to 5.

::::answer[Answer]
Shortest path length = 3. Path: 1 → 2 → 4 → 5 (or 1 → 3 → 4 → 5).
::::

Work

```
BFS from 1:
dist[1]=0, dist[2]=1, dist[3]=1, dist[4]=2, dist[5]=3
parent[2]=1, parent[3]=1, parent[4]=2, parent[5]=4
Trace back from 5: 5←4←2←1. Path: 1,2,4,5.
```
:::

:::callout-key[BFS Space Complexity]
The queue holds at most O(V) vertices at once (when all neighbors of all vertices at the current level are enqueued). Visited array also O(V). Total space: **O(V)**.
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Given adjacency list: 1:[2,3], 2:[4], 3:[4,5], 4:[6], 5:[6], 6:[]. BFS from vertex 1. List vertices by discovery order and give each vertex's BFS distance from 1.

::::solution[Solution]
Order: 1,2,3,4,5,6. Distances: d[1]=0, d[2]=1, d[3]=1, d[4]=2, d[5]=2, d[6]=3.
::::
:::

:::problem[Problem 4 · challenge]{difficulty="challenge"}
How would you use BFS to check if an undirected graph is bipartite?

::::solution[Solution]
Assign source color 0. When visiting each neighbor, assign the opposite color. If a neighbor already has the same color as the current vertex, the graph is NOT bipartite (odd-length cycle found). If BFS completes with no conflict, it is bipartite. Run for all components.
::::
:::

## 3. DFS — Algorithm

Depth-First Search explores as far as possible along each branch before backtracking. It uses a **stack** (explicit or implicit via recursion).

```cpp
// Recursive DFS
vector<bool> visited;
void dfs(vector<vector<int>>& adj, int v) {
    visited[v] = true;
    for (int u : adj[v]) {
        if (!visited[u]) dfs(adj, u);
    }
}

// Iterative DFS (using explicit stack)
void dfsIterative(vector<vector<int>>& adj, int src) {
    vector<bool> visited(adj.size(), false);
    stack<int> st;
    st.push(src);
    while (!st.empty()) {
        int v = st.top(); st.pop();
        if (visited[v]) continue;
        visited[v] = true;
        for (int u : adj[v]) {
            if (!visited[u]) st.push(u);
        }
    }
}
```

:::callout-warning[Recursive vs Iterative DFS]
Recursive DFS is simpler but can cause stack overflow on large graphs (deep recursion). Iterative DFS uses an explicit stack heap memory and avoids overflow. Note: iterative DFS may visit neighbors in a different order than recursive DFS.
:::

:::example[Example 12.3 — DFS Trace]
Graph (undirected): 1-2, 1-3, 2-4, 2-5, 3-6. Run DFS from vertex 1 (visit lower-numbered neighbors first).

::::answer[Answer]
DFS order: 1, 2, 4, 5, 3, 6.
::::

Work

```
Visit 1 → recurse on 2 (lowest unvisited neighbor)
  Visit 2 → recurse on 4
    Visit 4 → no unvisited neighbors → backtrack
  Recurse on 5
    Visit 5 → no unvisited neighbors → backtrack
  Backtrack to 1 → recurse on 3
    Visit 3 → recurse on 6
      Visit 6 → backtrack
DFS order: 1, 2, 4, 5, 3, 6
```
:::

:::problem[Problem 5 · standard]{difficulty="standard"}
Graph edges: 1-2, 1-4, 2-3, 2-5, 4-5. Run DFS from vertex 1, visiting neighbors in ascending order. List the DFS traversal order.

::::solution[Solution]
Visit 1 → 2 → 3 (backtrack) → 5 → 4 (backtrack to 2, 1) → done. Order: 1, 2, 3, 5, 4.
::::
:::

:::problem[Problem 6 · easy]{difficulty="easy"}
What is the time complexity of DFS on a graph with V vertices and E edges represented as an adjacency list?

::::solution[Solution]
O(V + E). Each vertex is visited once (O(V)) and each edge is examined at most twice (once from each endpoint in undirected graphs), giving O(E).
::::
:::

## 4. DFS Properties & Applications

### Key Applications of DFS

- **Cycle detection:** in undirected graphs, a back edge (to an already-visited non-parent) indicates a cycle
- **Topological sort:** in DAGs, finish DFS then reverse finish times
- **Strongly Connected Components:** Kosaraju's or Tarjan's algorithm
- **Articulation points & bridges:** Tarjan's low-link algorithm
- **Maze solving:** DFS explores one path fully before backtracking

### Cycle Detection in Undirected Graph

```cpp
bool hasCycle(vector<vector<int>>& adj, int V) {
    vector<bool> visited(V, false);
    function<bool(int,int)> dfs = [&](int v, int parent) {
        visited[v] = true;
        for (int u : adj[v]) {
            if (!visited[u]) {
                if (dfs(u, v)) return true;
            } else if (u != parent) {
                return true; // back edge = cycle
            }
        }
        return false;
    };
    for (int i = 0; i < V; i++)
        if (!visited[i] && dfs(i, -1)) return true;
    return false;
}
```

:::problem[Problem 7 · standard]{difficulty="standard"}
Does the graph with edges 1-2, 2-3, 3-4, 4-2 have a cycle? Use DFS to detect it.

::::solution[Solution]
Yes. DFS from 1: visit 1→2→3→4. From 4, neighbor 2 is visited and is not the parent of 4 (parent of 4 is 3). This is a back edge → cycle detected (2→3→4→2).
::::
:::

:::problem[Problem 8 · challenge]{difficulty="challenge"}
How does cycle detection in a directed graph differ from an undirected graph using DFS?

::::solution[Solution]
In directed graphs, track three states: unvisited, in-stack (currently being explored), and done. A cycle exists if we reach an in-stack vertex. In undirected graphs we only track visited/unvisited, checking that back edges don't go to non-parent visited vertices. The parent-check trick doesn't work for directed graphs.
::::
:::

## 5. DFS Tree & Edge Classification

During DFS on a directed graph, edges are classified into four types based on the relationship between the endpoints in the DFS tree:

| Edge Type | Description | Significance |
| --- | --- | --- |
| **Tree edge** | Edge used to discover a new vertex | Forms the DFS spanning tree |
| **Back edge** | Edge to an ancestor in DFS tree | Indicates a cycle in directed graph |
| **Forward edge** | Edge to a descendant (not tree edge) | Only in directed graphs |
| **Cross edge** | Edge to neither ancestor nor descendant | Only in directed graphs |

:::callout-key[Key Fact]
In DFS on an **undirected** graph, only tree edges and back edges occur — no forward or cross edges. This simplifies cycle detection significantly.
:::

:::problem[Problem 9 · standard]{difficulty="standard"}
In a DFS of a directed graph, if we discover a back edge, what does it tell us?

::::solution[Solution]
A back edge in a directed graph indicates the presence of a cycle — the back edge connects a vertex to one of its ancestors in the DFS tree, forming a loop.
::::
:::

## 6. Connected Components

### Undirected Graphs

Run BFS or DFS from each unvisited vertex. Each "run" finds one connected component.

```cpp
int countComponents(int V, vector<vector<int>>& adj) {
    vector<bool> visited(V, false);
    int count = 0;
    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            dfs(adj, visited, i); // marks entire component visited
            count++;
        }
    }
    return count;
}
```

### Directed Graphs — Strongly Connected Components (SCC)

A **strongly connected component** is a maximal set of vertices where every vertex is reachable from every other. **Kosaraju's algorithm**:

1. Run DFS on the original graph, pushing vertices onto a stack in finish-time order.
2. Transpose the graph (reverse all edges).
3. Pop vertices from the stack, run DFS on the transposed graph — each DFS run finds one SCC.

Time complexity: O(V + E).

:::problem[Problem 10 · standard]{difficulty="standard"}
An undirected graph has 6 vertices and edges: 1-2, 2-3, 4-5. How many connected components does it have? List them.

::::solution[Solution]
3 components: {1,2,3}, {4,5}, {6}.
::::
:::

## 7. BFS vs DFS — When to Use Which

| Property | BFS | DFS |
| --- | --- | --- |
| Data structure | Queue (FIFO) | Stack (LIFO) / recursion |
| Space complexity | O(V) — wide frontier | O(V) — deep recursion |
| Shortest path (unweighted) | ✓ Guaranteed | ✗ Not guaranteed |
| Cycle detection | ✓ | ✓ (simpler code) |
| Topological sort | Kahn's (in-degree) | Finish-time reversal |
| SCC detection | ✗ | ✓ (Kosaraju, Tarjan) |
| Good for | Nearby vertices, min hops | Deep paths, backtracking |

## 8. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
What is the time complexity of BFS and DFS? What does it depend on?

::::solution[Solution]
Both are O(V + E). V for visiting each vertex once, E for examining each edge. With adjacency matrix it becomes O(V²) since checking all neighbors of a vertex costs O(V).
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
BFS tree on an undirected graph guarantees shortest paths. Why doesn't DFS give shortest paths?

::::solution[Solution]
BFS processes vertices level by level — all vertices at distance d are fully processed before any at distance d+1. DFS dives deep immediately, potentially finding a longer path before discovering the shorter one. Once a vertex is marked visited in DFS, shorter paths to it may be ignored.
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
Given the adjacency list: A:[B,C], B:[D], C:[D,E], D:[], E:[]. Run BFS from A. Give the order vertices are visited and the BFS distance for each.

::::solution[Solution]
Order: A, B, C, D, E. Distances: A=0, B=1, C=1, D=2, E=2.
::::
:::

:::problem[Exam Q4 · challenge]{difficulty="challenge"}
Explain Kosaraju's algorithm for finding strongly connected components in a directed graph.

::::solution[Solution]
1) DFS the original graph; push each vertex onto a stack when its DFS finishes. 2) Transpose the graph (reverse all edges). 3) Pop vertices from the stack; run DFS on the transposed graph from each unvisited vertex. Each DFS in step 3 discovers exactly one SCC. Time: O(V+E).
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
How many times is each vertex and each edge processed in a BFS traversal? Why?

::::solution[Solution]
Each vertex is enqueued and dequeued exactly once (O(V) total). Each edge is examined exactly twice in an undirected graph — once from each endpoint — or once in a directed graph (O(E) total). Hence O(V+E).
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
For a directed graph, list which edge types (tree, back, forward, cross) can appear in DFS vs BFS trees.

::::solution[Solution]
DFS: all four types can appear (tree, back, forward, cross). BFS: only tree edges and cross edges appear — no back edges or forward edges, because BFS processes vertices in non-decreasing distance order.
::::
:::

:::problem[Exam Q7 · standard]{difficulty="standard"}
What modification to BFS lets you reconstruct the actual shortest path (not just the distance)?

::::solution[Solution]
Maintain a `parent[]` array. When you discover vertex u through vertex v (i.e., v is dequeued and u is an unvisited neighbor), set parent[u] = v. To reconstruct the path to target t, trace back: t → parent[t] → parent[parent[t]] → ... → source. Reverse the sequence.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
You need to find if a path exists between two vertices in an undirected graph with 10^6 vertices. Which traversal do you use and why?

::::solution[Solution]
Either BFS or DFS works for reachability. BFS uses O(V) queue space but is iterative. DFS risks stack overflow with 10^6 vertices if implemented recursively. Use iterative DFS (explicit stack) or BFS. If you additionally need shortest path, BFS is the only correct choice.
::::
:::

:::summary
## Chapter 12 Summary

| Algorithm | Structure | Time | Space | Shortest Path? |
| --- | --- | --- | --- | --- |
| BFS | Queue | O(V+E) | O(V) | Yes (unweighted) |
| DFS | Stack/Recursion | O(V+E) | O(V) | No |

**BFS**: shortest paths, bipartite check, level-order. **DFS**: cycle detection, topological sort, SCC, articulation points. Both find connected components and have O(V+E) time with adjacency lists.
:::
