---
title: "Linked Lists"
crumb: "Honors DSA · Chapter 4"
meta:
  - "Est. study time: ~75 min"
  - "Unit 1 — Analysis & Linear Structures"
  - "CSE 2383 · MSState"
source: "markdown"
---

## Overview

The linked list is the simplest dynamic data structure and the foundation for stacks, queues, and many tree implementations. Unlike an array, a linked list does not require contiguous memory — each element (node) is an independent heap allocation connected to the next via a pointer. This flexibility costs cache performance but buys O(1) insertion and deletion anywhere in the list once you have a pointer to the location.

:::callout-key[Prerequisites]
- Chapter 1: pointers, `new`/`delete`, `struct`
- Chapter 3: Big-O notation for analyzing operations
:::

## 1. Singly Linked Lists

:::callout-intuition[Intuition]
Think of a singly linked list as a chain. Each link (node) contains a value and a pointer to the next link. The chain has a head (the first link) and the last link points to `nullptr` (the chain's end). You can only move forward — there's no way to go back without traversing from the head again.
:::

:::definition[Definition 1.1 — Singly Linked List]
A **singly linked list** is a sequence of nodes where each node holds a *data value* and a *pointer to the next node*. The list is accessed through a `head` pointer. The last node's `next` pointer is `nullptr`, marking the end of the list.
:::

```cpp
struct Node {
    int   data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;
    int   size_;
public:
    LinkedList() : head(nullptr), size_(0) {}
    ~LinkedList() { clear(); }

    int  size()    const { return size_; }
    bool empty()   const { return head == nullptr; }

    // Insert at front — O(1)
    void pushFront(int val) {
        Node* n = new Node(val);
        n->next = head;
        head = n;
        size_++;
    }

    // Insert at back — O(n)
    void pushBack(int val) {
        Node* n = new Node(val);
        if (!head) { head = n; }
        else {
            Node* cur = head;
            while (cur->next) cur = cur->next;
            cur->next = n;
        }
        size_++;
    }

    // Remove front — O(1)
    void popFront() {
        if (!head) return;
        Node* old = head;
        head = head->next;
        delete old;
        size_--;
    }

    // Print all elements — O(n)
    void print() const {
        Node* cur = head;
        while (cur) {
            std::cout << cur->data;
            if (cur->next) std::cout << " -> ";
            cur = cur->next;
        }
        std::cout << " -> nullptr\n";
    }

    // Free all nodes
    void clear() {
        while (head) popFront();
    }
};
```

```
After pushFront(30), pushFront(20), pushFront(10):

head
 │
 ▼
┌──────────┐    ┌──────────┐    ┌──────────┐
│ data: 10 │───►│ data: 20 │───►│ data: 30 │───► nullptr
│ next: ───┘    │ next: ───┘    │ next: ───┘
└──────────┘    └──────────┘    └──────────┘

```

### Key operations and complexities

| Operation | Time | Notes |
| --- | --- | --- |
| Access by index | $O(n)$ | Must traverse from head |
| Search | $O(n)$ | Linear scan |
| Insert at front | $O(1)$ | Adjust head pointer |
| Insert at back | $O(n)$ | Must find tail first (without tail pointer) |
| Insert at position | $O(n)$ | Traverse to position, then $O(1)$ link adjustment |
| Delete at front | $O(1)$ | Adjust head, delete old head |
| Delete by value | $O(n)$ | Search + $O(1)$ link adjustment |

### Worked examples

:::example[Example 1.1 — Inserting after a given node]
Write a function that inserts a new node with value `val` immediately after a given node `prev`. Show what happens to the links.

::::answer[Answer]
Save `prev->next`, point new node there, then point `prev->next` to the new node.
::::

Work

```cpp
void insertAfter(Node* prev, int val) {
    if (!prev) return;
    Node* n = new Node(val);
    n->next    = prev->next;   // step 1: new node points where prev pointed
    prev->next = n;            // step 2: prev now points to new node
}
```

```
Before: ... → [prev|───►next_node] → ...
Step 1: n->next = prev->next
         [n|───►next_node]
Step 2: prev->next = n
After:  ... → [prev|───►n|───►next_node] → ...

ORDER MATTERS: if you do step 2 first, you lose the pointer to next_node.

```
:::

:::example[Example 1.2 — Deleting a node by value]
Write a function to remove the first node containing `val` from a singly linked list. Handle the edge cases: empty list, deleting the head, value not found.

::::answer[Answer]
Use two pointers: `prev` (one behind) and `cur`. When `cur->data == val`, link `prev->next` around `cur` and delete it.
::::

Work

```cpp
void remove(int val) {
    if (!head) return;                       // empty list

    // Special case: head node holds val
    if (head->data == val) {
        Node* old = head;
        head = head->next;
        delete old;
        size_--;
        return;
    }

    // General case: search with prev pointer
    Node* prev = head;
    Node* cur  = head->next;
    while (cur) {
        if (cur->data == val) {
            prev->next = cur->next;         // bypass cur
            delete cur;
            size_--;
            return;
        }
        prev = cur;
        cur  = cur->next;
    }
    // val not found — no change
}
```

Why do we need a `prev` pointer? Because singly linked lists have no way to go backward. To remove `cur`, we must reach the node *before* it and update its `next`. The previous pointer tracks exactly that.
:::

:::example[Example 1.3 — Reversing a linked list in-place]
Reverse a singly linked list in O(n) time and O(1) space (no new nodes, no array).

::::answer[Answer]
Walk the list flipping `next` pointers with three variables: `prev`, `curr`, `next`.
::::

Work

```cpp
void reverse() {
    Node* prev = nullptr;
    Node* curr = head;
    while (curr) {
        Node* nxt  = curr->next;  // save next before overwriting
        curr->next = prev;         // flip the pointer
        prev       = curr;         // advance prev
        curr       = nxt;          // advance curr
    }
    head = prev;   // prev is now the new head
}
```

```
Initial:  head→[1]→[2]→[3]→nullptr

Iteration 1: prev=null, curr=[1]
  nxt=[2], [1]→null, prev=[1], curr=[2]

Iteration 2: prev=[1], curr=[2]
  nxt=[3], [2]→[1], prev=[2], curr=[3]

Iteration 3: prev=[2], curr=[3]
  nxt=null, [3]→[2], prev=[3], curr=null

head = prev = [3]
Result:  head→[3]→[2]→[1]→nullptr  ✓

```
:::

:::callout-pitfall[Watch out for]
- **Losing the rest of the list** — when adjusting pointers, always save `next` in a temporary before overwriting it.
- **Forgetting the head special case** — deleting the first node requires updating `head`, not just a `prev->next`.
- **Memory leaks on deletion** — always `delete` the removed node; don't just bypass it.
- **Off-by-one in traversal** — traversal ends at `cur == nullptr`, not at `cur->next == nullptr` (the latter misses the tail).
:::

### Practice problems

:::problem[Problem 1.1 easy]{difficulty="easy"}
Given `head` pointing to a non-empty singly linked list, write one line of code to access the data of the second node. Assume it exists.

::::solution[Solution]
```cpp
int second = head->next->data;
```
::::
:::

:::problem[Problem 1.2 easy]{difficulty="easy"}
What is printed by the following code for the list 10→20→30→nullptr?

```cpp
Node* cur = head;
while (cur->next != nullptr) cur = cur->next;
std::cout << cur->data;
```

::::solution[Solution]
**30**. The loop advances `cur` until `cur->next` is null — that's the tail node, which holds 30.
::::
:::

:::problem[Problem 1.3 standard]{difficulty="standard"}
Write a function `int kthFromEnd(Node* head, int k)` that returns the $k$-th element from the end of a singly linked list in a single pass (O(n) time, O(1) extra space). For a list of length $n$, the 1st from end is the tail.

::::solution[Solution]
```cpp
int kthFromEnd(Node* head, int k) {
    Node* fast = head;
    Node* slow = head;
    // Advance fast k steps ahead
    for (int i = 0; i < k; i++) {
        if (!fast) return -1;  // list shorter than k
        fast = fast->next;
    }
    // Move both until fast reaches nullptr
    while (fast) {
        fast = fast->next;
        slow = slow->next;
    }
    return slow->data;
}
```

The two-pointer technique: keep `fast` exactly `k` steps ahead. When `fast` hits the end, `slow` is exactly at the k-th from the end. Only one pass needed.
::::
:::

:::problem[Problem 1.4 standard]{difficulty="standard"}
Write a function `bool hasCycle(Node* head)` that detects whether a linked list has a cycle (a node whose `next` points back to a previous node). Use O(1) extra space.

::::solution[Solution]
```cpp
bool hasCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;  // cycle detected
    }
    return false;
}
```

**Floyd's cycle detection (tortoise and hare)**: `slow` moves one step at a time; `fast` moves two. If there's a cycle, `fast` eventually laps `slow` and they meet. If there's no cycle, `fast` reaches `nullptr`. Time: $O(n)$. Space: $O(1)$.
::::
:::

:::problem[Problem 1.5 challenge]{difficulty="challenge"}
Write a function that merges two sorted singly linked lists into a single sorted list. Do not allocate any new nodes — just re-link existing ones.

::::solution[Solution]
```cpp
Node* mergeSorted(Node* a, Node* b) {
    // Dummy head simplifies edge cases
    Node dummy(0);
    Node* tail = &dummy;
    while (a && b) {
        if (a->data <= b->data) { tail->next = a; a = a->next; }
        else                    { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a ? a : b;  // attach remaining nodes
    return dummy.next;
}
```

The **dummy head** technique avoids special-casing the first node. `dummy.next` is the true head of the merged list. We always extend the merged list from `tail`, advancing through whichever input has the smaller current value.
::::
:::

## 2. Doubly Linked Lists

:::callout-intuition[Intuition]
A singly linked list only lets you walk forward. A **doubly linked list** adds a `prev` pointer to each node, so you can walk either direction. This costs one extra pointer per node (8 bytes on a 64-bit system) but makes deletion of a given node truly O(1) — no need for a separate `prev` tracking variable — and makes backward traversal possible. This is how `std::list` is implemented.
:::

```cpp
struct DNode {
    int    data;
    DNode* prev;
    DNode* next;
    DNode(int val) : data(val), prev(nullptr), next(nullptr) {}
};

class DoublyLinkedList {
private:
    DNode* head;
    DNode* tail;   // maintain a tail pointer for O(1) pushBack
    int    size_;
public:
    DoublyLinkedList() : head(nullptr), tail(nullptr), size_(0) {}
    ~DoublyLinkedList() { clear(); }

    // Insert at back — O(1) with tail pointer
    void pushBack(int val) {
        DNode* n = new DNode(val);
        if (!tail) { head = tail = n; }
        else {
            n->prev    = tail;
            tail->next = n;
            tail       = n;
        }
        size_++;
    }

    // Delete a node directly — O(1) given a pointer to the node
    void deleteNode(DNode* node) {
        if (!node) return;
        if (node->prev) node->prev->next = node->next;
        else            head             = node->next;    // deleting head
        if (node->next) node->next->prev = node->prev;
        else            tail             = node->prev;    // deleting tail
        delete node;
        size_--;
    }

    void clear() {
        while (head) { DNode* n = head->next; delete head; head = n; }
        tail = nullptr; size_ = 0;
    }
};
```

```
Doubly linked list: 10 ↔ 20 ↔ 30

head                              tail
 │                                 │
 ▼                                 ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ prev: null   │  │ prev: ───────┼──│ prev: ───────┼──►[20]
│ data: 10     │  │ data: 20     │  │ data: 30     │
│ next: ───────┼─►│ next: ───────┼─►│ next: null   │
└──────────────┘  └──────────────┘  └──────────────┘

```

### Worked examples

:::example[Example 2.1 — O(1) deletion given a node pointer]
Show why deletion in a doubly linked list is O(1) when you have a pointer to the node to delete, but O(n) in a singly linked list.

::::answer[Answer]
In a doubly linked list, `node->prev` gives the predecessor immediately — no traversal. In a singly linked list, finding the predecessor requires a scan from `head`.
::::

Work

```cpp
// Doubly linked list — O(1) delete given node*
void deleteNode(DNode* node) {
    if (node->prev) node->prev->next = node->next;  // bypass left
    else head = node->next;                          // was head
    if (node->next) node->next->prev = node->prev;  // bypass right
    else tail = node->prev;                          // was tail
    delete node;   // no search needed — O(1) total
}

// Singly linked list — O(n) delete given value
void remove(int val) {
    Node* prev = nullptr, *cur = head;
    while (cur && cur->data != val) {  // O(n) search for predecessor
        prev = cur; cur = cur->next;
    }
    if (!cur) return;                  // not found
    if (prev) prev->next = cur->next;
    else head = cur->next;
    delete cur;
}
```

This O(1) deletion is exploited in the LRU Cache data structure, which uses a doubly linked list + hash map to achieve O(1) access and eviction.
:::

### Practice problems

:::problem[Problem 2.1 easy]{difficulty="easy"}
A doubly linked list has nodes A↔B↔C. Write the pointer assignments to insert new node X between B and C.

::::solution[Solution]
```cpp
// Insert X after B (before C):
X->prev = B;
X->next = C;
B->next = X;
C->prev = X;
```

Four pointer assignments. Order doesn't matter here since we set all of X's pointers first, then update B and C.
::::
:::

:::problem[Problem 2.2 standard]{difficulty="standard"}
Why does a doubly linked list with a `tail` pointer support O(1) `pushBack` while a singly linked list without a tail pointer requires O(n)?

::::solution[Solution]
Without a tail pointer, inserting at the back requires traversing the entire list from `head` to find the last node (O(n)). With a `tail` pointer, the last node is always directly accessible — insert the new node after `tail` and update `tail` to the new node: O(1). A singly linked list *can also* have a `tail` pointer for O(1) pushBack, but keeping `tail` consistent on deletion from the back still requires O(n) (you need the second-to-last node).
::::
:::

:::problem[Problem 2.3 challenge]{difficulty="challenge"}
Implement an LRU (Least Recently Used) cache of capacity `k` using a doubly linked list + `std::unordered_map`. Support O(1) `get(key)` and O(1) `put(key, value)`.

::::solution[Solution]
```cpp
#include <unordered_map>

struct CacheNode {
    int key, val;
    CacheNode *prev, *next;
    CacheNode(int k, int v) : key(k), val(v), prev(nullptr), next(nullptr) {}
};

class LRUCache {
    int capacity;
    std::unordered_map<int, CacheNode*> map;
    CacheNode *head, *tail;  // dummy sentinels

    void moveToFront(CacheNode* node) {
        // Unlink
        node->prev->next = node->next;
        node->next->prev = node->prev;
        // Reinsert after dummy head
        node->next = head->next;
        node->prev = head;
        head->next->prev = node;
        head->next = node;
    }
public:
    LRUCache(int cap) : capacity(cap) {
        head = new CacheNode(-1,-1);
        tail = new CacheNode(-1,-1);
        head->next = tail; tail->prev = head;
    }
    int get(int key) {
        if (!map.count(key)) return -1;
        moveToFront(map[key]);
        return map[key]->val;
    }
    void put(int key, int val) {
        if (map.count(key)) { map[key]->val = val; moveToFront(map[key]); return; }
        CacheNode* node = new CacheNode(key, val);
        map[key] = node;
        node->next = head->next; node->prev = head;
        head->next->prev = node; head->next = node;
        if ((int)map.size() > capacity) {
            CacheNode* lru = tail->prev;  // just before tail sentinel
            lru->prev->next = tail; tail->prev = lru->prev;
            map.erase(lru->key); delete lru;
        }
    }
};
```

Most-recently used is at the front (after head sentinel); least-recently used is at the back (before tail sentinel). The hash map gives O(1) lookup; the doubly linked list gives O(1) insertion/deletion. This is a classic interview problem.
::::
:::

## 3. Circular Lists & Sentinel Nodes

:::callout-intuition[Intuition]
Two implementation tricks dramatically simplify list code: **circular lists** (the tail's `next` points back to head, making all positions "the same") and **sentinel nodes** (dummy nodes at head and/or tail that never hold real data). Sentinels eliminate nearly all the special cases in insert/delete: you never need to check "is this the head?" because the sentinel is always there.
:::

### Sentinel (dummy head) technique

```cpp
// Without sentinel: insert-at-front special-cases the head
void insert(int val) {
    Node* n = new Node(val);
    if (!head) { head = n; return; }        // special case!
    n->next = head; head = n;
}

// With sentinel: head is always the dummy; real data starts at head->next
// sentinel never changes; no special case needed
void insert(int val) {
    Node* n = new Node(val);
    n->next         = sentinel->next;
    sentinel->next  = n;
}
```

:::callout-connect[Connection]
Tree implementations often use sentinel nodes too (a "nil" leaf that represents all empty children). The sentinel pattern appears throughout advanced data structures to remove edge-case branching and simplify correctness proofs.
:::

### Practice problems

:::problem[Problem 3.1 easy]{difficulty="easy"}
In a circular singly linked list where `tail->next == head`, write a traversal that prints every element exactly once.

::::solution[Solution]
```cpp
if (!head) return;
Node* cur = head;
do {
    std::cout << cur->data << " ";
    cur = cur->next;
} while (cur != head);
```

A `do-while` loop is natural here: we always visit `head` at least once, then stop when we wrap around back to it.
::::
:::

:::problem[Problem 3.2 standard]{difficulty="standard"}
Explain one advantage and one disadvantage of using a sentinel head node in a linked list implementation.

::::solution[Solution]
**Advantage**: Eliminates the "empty list" and "insert at head" special cases — every insert/delete works the same way regardless of position. Code is shorter and less error-prone. **Disadvantage**: Uses one extra heap allocation (the sentinel node) that holds no data. For very memory-constrained systems, this overhead may matter. The sentinel's `data` field is wasted. Also, code that iterates must start from `sentinel->next`, not `sentinel`.
::::
:::

## 4. Linked Lists vs. Arrays

| Operation | Array / vector | Linked list (singly) |
| --- | --- | --- |
| Random access by index | $O(1)$ | $O(n)$ |
| Search (unsorted) | $O(n)$ | $O(n)$ |
| Insert at front | $O(n)$ (shift elements) | $O(1)$ |
| Insert at back | $O(1)$ amortized | $O(n)$ without tail ptr; $O(1)$ with |
| Insert in middle | $O(n)$ (shift) | $O(n)$ search + $O(1)$ link |
| Delete at front | $O(n)$ (shift) | $O(1)$ |
| Memory overhead | Minimal (contiguous) | One pointer per node (8 bytes each) |
| Cache friendliness | Excellent | Poor (random heap addresses) |
| Size flexibility | Fixed (array) or amortized (vector) | Truly dynamic |

:::callout-tip[When to use a linked list]
- Frequent insertion/deletion at the *front* (implementing a stack or queue)
- You hold a pointer to arbitrary positions and need O(1) insert/delete there (e.g., LRU cache)
- The number of elements changes wildly and you can't afford vector's occasional O(n) reallocation

In most other cases, prefer `std::vector` — its cache behavior usually wins in practice.
:::

### Practice problems

:::problem[Problem 4.1 easy]{difficulty="easy"}
You need a data structure that supports: (a) frequent random access by index, (b) rare insertions at the end. Which do you choose: array/vector or linked list?

::::solution[Solution]
**Array / vector.** Random access is O(1) for vector vs. O(n) for linked list. Rare insertions at the back are O(1) amortized for vector. The linked list has no advantage here.
::::
:::

:::problem[Problem 4.2 standard]{difficulty="standard"}
A text editor needs to support efficient character insertion anywhere in a document. Why is a linked list better than an array for this, and what is the actual time complexity of "insert at position `k`" in each?

::::solution[Solution]
**Array**: inserting at position $k$ requires shifting all elements after position $k$ one spot right: $O(n-k)$ = $O(n)$ in the worst case (inserting at the front). **Linked list**: navigating to position $k$ is O(k) = O(n) worst case, but once there, the actual link adjustment is O(1). For a text editor, a **gap buffer** or **rope** is typically used in practice, but a doubly linked list is a reasonable simple solution for moderate document sizes.
::::
:::

## The Course Implementation

This is the exact interface examined in CSE 2383, walked through line by line. The earlier sections of this chapter teach the same ideas with other conventions; here the names, signatures, and code are the course versions you need to be able to reconstruct from understanding.

### The mental model before any code

Imagine memory as a long row of numbered cells. A pointer is a variable whose value is one of those numbers: an address. `nullptr` is the special value meaning “points at nothing.” An object created with `new` lives in heap memory until code releases it with `delete`. That differs from a local variable, which vanishes automatically at the end of its block. Review [Chapter 1's pointer section](dsa_ch1_cpp_refresher.md#1-pointers--references), [Chapter 1's `new` and `delete` section](dsa_ch1_cpp_refresher.md#2-dynamic-memory-new-and-delete), and [Chapter 2's heap section](dsa_ch2_memory.md#3-heap-internals) if any part of that model is uncertain.

A linked list is a collection of nodes scattered around the heap. Each node holds a value and the address of the next node. The `LinkedList` object itself does **not** contain all those nodes; it contains only two pointer variables, `head` and `tail`. Those point to the first and last nodes.

```text
LinkedList object                     heap nodes
+------------------+                 +---+---+    +---+---+
| head: address A  | --------------> | 3 | B | -> | 7 | ∅ |
| tail: address B  | ----------------------------^
+------------------+
```

The list **owns** its nodes: it created them with `new`, so it is responsible for destroying them with `delete`. If it forgets, the heap memory leaks.

:::definition[Invariant]
An **invariant** is a fact that must be true before and after every public operation, even though it may be temporarily false while that operation rearranges pointers.
:::

This implementation must preserve three invariants:

1. The list is empty exactly when `head == nullptr`, and that is also exactly when `tail == nullptr`. In other words, the two pointers agree about emptiness.
2. When the list is non-empty, `tail->next == nullptr`. Nothing comes after the tail.
3. Starting at `head` and repeatedly following `next` eventually reaches `tail`. No node in the chain becomes detached or unreachable.

Every operation has two jobs: make its intended change **and** leave those invariants true. Empty-list, one-node, first-node, and last-node cases deserve special attention precisely because they are where an invariant is easiest to break. This is the key to writing your own data type or class: decide what must always be true, then make every method restore those truths before it finishes.

### Naming conventions in the course

Dr. Swan uses the following names consistently:

| Structure | Member pointers | Class name |
| --- | --- | --- |
| Singly linked list | `head`, `tail` | `LinkedList` |
| Doubly linked list | `head`, `tail` | `LinkedList` |
| Stack | `top` only | `Stack` |
| Queue | `start`, `end` | `Queue` |

His course implementation stores `int` data, uses raw pointers and `nullptr`, and usually places the asterisk with the variable name: `Node *tmp`.

### The Node class

Here is his singly linked `Node` verbatim:

```cpp
class Node
{
   public:
      int data; // store an integer
      Node *next; // pointer to the next node in the chain

      Node(): data(0), next(nullptr) {} // the default constructor ... must have this
      Node(int data): data(data), next(nullptr) {}
      Node(int data, Node* next): data(data), next(next) {}
};
```

**Line by line**

- `class Node` begins a class definition.

  - `class` tells C++ to define a new user-made type.
  - `Node` is the new type's name. After this definition, code can declare a variable whose type is `Node`.

- `{` opens the class body. The declarations between this brace and its matching `}` belong to `Node`.
- `public:` changes access for everything that follows.

  - `public` means code outside `Node` may use those members.
  - The colon `:` ends the access label.
  - A `class` defaults to `private`. Dr. Swan's introductory Node page omitted `public:`; that makes even its constructors inaccessible, so outside code such as `new Node(data)` fails to compile. This later course listing fixes the problem.

- `int data; // store an integer` declares the stored value.

  - `int` is the integer type.
  - `data` is the member's name; every `Node` object gets its own `data`.
  - The semicolon `;` ends the declaration.
  - `//` begins a comment. The compiler ignores everything after it on that line.
  - Without the member, none of the list operations could store or compare the requested integer; references such as `tmp->data` would fail to compile. Removing only the comment would not change the program, but would remove its explanation for readers.

- `Node *next; // pointer to the next node in the chain` declares the link.

  - The first `Node` is the pointed-to type.
  - `*` says `next` is a pointer, so its value is a `Node` address rather than a whole `Node`.
  - `next` is the pointer member's name.
  - It cannot be `Node next;`: then each node would contain a whole second node, which would contain a whole third node, forever. The type would require infinite space. A pointer has a fixed size regardless of how many nodes are linked.
  - Without `next`, the nodes could not form a chain and every use of `tmp->next` would fail to compile.

- The blank line groups the data members separately from the constructors; it has no effect on the compiled program.
- `Node(): data(0), next(nullptr) {} // the default constructor ... must have this` is the default constructor.

  - A **constructor** has the same name as its class, has no return type, and runs automatically when an object is created.
  - `Node()` means this version takes no arguments. Empty parentheses are why it is the default constructor.
  - The colon after `Node()` starts the **member initializer list**. It initializes members directly before the constructor body begins.
  - `data(0)` initializes this object's `data` member to zero.
  - The comma separates one member initializer from the next.
  - `next(nullptr)` initializes this object's link to “points at nothing.” That immediately makes a new node safe to use as a last node.
  - `{}` is an empty constructor body. No further statements are needed because the initializer list already did the work.
  - Because the class declares other constructors, omitting this no-argument version would make `Node n;` invalid wherever a default-constructed node is needed. The shown list methods use the one-argument constructor, but the course's shared node interface includes this form.

- `Node(int data): data(data), next(nullptr) {}` constructs a node from one integer.

  - In `int data`, `int` is the parameter's type and `data` is the parameter's name.
  - In `data(data)`, the name **before** the parentheses is the member being initialized; the name **inside** the parentheses is the parameter supplying its value. Constructor initializer syntax makes that distinction unambiguous even though both names are `data`.
  - `next(nullptr)` makes the new node a valid end node until the list connects something after it.
  - Without this overload, every shown `new Node(data)` expression would fail to compile because no constructor would accept one integer.

- `Node(int data, Node* next): data(data), next(next) {}` constructs a node from both a value and a next-node address.

  - The comma in the parameter list separates the two parameters.
  - `Node* next` is a pointer parameter. This source writes the asterisk beside the type here, while writing `Node *next` above; C++ treats both forms the same.
  - In `next(next)`, the member `next` is initialized from the parameter `next`, by the same member-before-parentheses rule as `data(data)`.
  - The shown operations do not call this overload, but it permits other code to create a node already linked to a successor; without it, such a two-argument construction would fail.

- `};` closes the class body with `}` and then ends the class definition with `;`. C++ requires that final semicolon after a class definition; leaving it out produces a syntax error at this definition or the declaration that follows it.

The doubly linked node is the natural extension: each node also stores the address of the previous node. **Dr. Swan's exact doubly linked Node page was not captured.** The following definition is therefore **not from his pages**; it shows the necessary extension in his style:

```cpp
class Node // define the doubly linked node type
{
   public: // allow LinkedList to use these members
      int data; // store an integer
      Node *next; // pointer to the next node in the chain
      Node *prev; // pointer to the previous node in the chain

      Node(): data(0), next(nullptr), prev(nullptr) {} // initialize an empty-valued node
      Node(int data): data(data), next(nullptr), prev(nullptr) {} // initialize a node with data
      Node(int data, Node* next): data(data), next(next), prev(nullptr) {} // initialize data and next
};
```

The new pieces are `Node *prev;`, which stores a fixed-size address to the preceding node, and `prev(nullptr)` in **every** constructor, which says a new node initially has no predecessor. This detail matters: his doubly linked `prepend` never explicitly assigns `tmp->prev`, so that operation is correct only if the constructor has already set `prev` to `nullptr`.

### The LinkedList class definition

Here is his class definition verbatim:

```cpp
class LinkedList
{
  private:
   Node *head;
   Node *tail;
  public:
   LinkedList(): head(nullptr), tail(nullptr) {} // default constructor
   ~LinkedList(); // deconstructor
   LinkedList(const LinkedList &old); // copy contructor

   void append(int data);
   void prepend(int data);
   bool search(int data);
   bool remove(int data);

   void display(ostream &os);

   friend ostream &operator<<(ostream &os, LinkedList &right);
};
```

**Line by line**

- `class LinkedList` defines a new class named `LinkedList`; `{` opens its body.
- `private:` makes the following members inaccessible to ordinary outside code. A class is private by default, but writing the label makes the intent explicit. This is **encapsulation**: callers cannot set `head` or `tail` independently and break the invariants. The class alone is responsible for those pointers, so the class alone can guarantee them.
- `Node *head;` declares the pointer to the first node. Without it, the class has no entry point for traversal and all uses of `head` fail to compile. `Node *tail;` declares the pointer to the last node. Without it, this exact interface cannot maintain its last-node invariant or perform O(1) append, and all uses of `tail` fail to compile. These are addresses, not embedded nodes.
- `public:` begins the interface outside code may call.
- `LinkedList(): head(nullptr), tail(nullptr) {} // default constructor` is the no-argument constructor. Its initializer list sets both pointers to `nullptr` before its empty body runs. Therefore the new list satisfies the empty-list invariant immediately: `head` and `tail` agree that there are no nodes.
- `~LinkedList(); // deconstructor` declares the destructor.

  - The tilde `~` identifies a destructor, the special function that runs automatically when an object is destroyed—for example, when a local `LinkedList` reaches the end of its block.
  - `LinkedList` names the class being destroyed; `()` means the destructor takes no arguments.
  - The trailing `;` means “declared here, defined elsewhere.” The function body appears later as `LinkedList::~LinkedList()`.
  - The course comment says “deconstructor”; the C++ term is **destructor**.

- `LinkedList(const LinkedList &old); // copy contructor` declares the copy constructor, which creates a new list from an existing one.

  - The first `LinkedList` is the constructor name.
  - `const` promises this function will not modify the source object.
  - The second `LinkedList` is the parameter's type.
  - `&` makes `old` a reference—another name for the caller's existing object rather than a new copied parameter.
  - The reference is mandatory here. Passing `old` by value would first require copying it, which would call this copy constructor, which would need another value copy, forever.
  - `old` is the parameter name.
  - Again, `;` declares the function without defining its body here. The comment's “contructor” is merely a spelling error.

- The blank line separates lifetime functions from ordinary operations.
- `void append(int data);` declares `append`.

  - `void` means the function returns no value.
  - `append` is the function name.
  - Parentheses hold its parameter list.
  - `int data` means the caller supplies one integer, locally named `data`.
  - The semicolon makes this a declaration, not a definition.

- `void prepend(int data);` has the same syntax and declares front insertion.
- `bool search(int data);` declares a function returning `bool`—either `true` or `false`—to report whether the integer was found.
- `bool remove(int data);` returns a Boolean to report whether a matching node existed and was removed.
- The next blank line groups output separately.
- `void display(ostream &os);` declares output through a stream.

  - `ostream` is the stream type used by `cout` and by file output streams.
  - `&os` makes `os` a reference to the caller's actual stream, so output changes that stream rather than an unrelated copy.

- The blank line sets apart the non-member operator declaration.
- `friend ostream &operator<<(ostream &os, LinkedList &right);` declares stream insertion.

  - `friend` grants this non-member function access to `LinkedList`'s private members.
  - `ostream &` says it returns a reference to an output stream.
  - `operator<<` is the special function name for the `<<` operator.
  - Its parameters are the left operand (`ostream &os`) and right operand (`LinkedList &right`).
  - In this implementation, the operator only calls the **public** function `display`. Therefore `friend` is not strictly needed here. Friend exists for non-members that genuinely need private access; an operator does not automatically need friendship.

- `};` closes and terminates the class definition.

A **declaration** tells the compiler a function's name, parameter types, and return type. A **definition** supplies its body. For example, `void append(int data);` is the declaration above, while `void LinkedList::append(int data) { ... }` is its later definition. In that definition, `::` is the **scope-resolution operator**: `LinkedList::append` means “the `append` that belongs to `LinkedList`,” rather than an unrelated free function also named `append`.

From this point on, each `{` begins the body controlled by the function, `if`, `else`, or `while` immediately before it, and each `}` ends that body. They create structure rather than perform a pointer operation; omitting or misplacing one changes which statements are controlled or makes the program fail to compile. Course comments remain documentation only: deleting a comment does not alter execution.

### Singly linked append

`append` adds a value after the current tail. Because the class stores `tail`, it can reach the end directly instead of walking from `head`.

```text
Before append(9):
head
  |
  v
[3] -> [7] -> nullptr
        ^
        |
       tail

After append(9):
head
  |
  v
[3] -> [7] -> [9] -> nullptr
               ^
               |
              tail
```

His code, verbatim:

```cpp
void LinkedList::append(int data)
{
   Node *tmp = new Node(data); // create the new node
   if (head == nullptr) // check for an empty list
   {
      head = tmp; // if the list is empty, set the head to the new node
   }
   else
   {
      tail->next = tmp; // set tail's next to the new node
   }
   tail = tmp; // set tail to the new node
}
```

**Line by line**

- `void LinkedList::append(int data)` defines the member declared earlier. `void` means no return value; `LinkedList::` chooses the class's scope; `append` names the operation; `int data` receives the value to store.
- `{` begins the function body.
- `Node *tmp = new Node(data); // create the new node` allocates and remembers the new node.

  - `Node *tmp` declares a local pointer named `tmp` that can hold a `Node` address.
  - `=` is assignment: put the value produced on the right into the variable on the left. It does not compare.
  - `new Node(data)` asks the heap for enough memory for one `Node`, runs `Node(int data)` there using this function's `data` value, and returns the new node's address.
  - Because that constructor sets `next(nullptr)`, the new node is already safe to become the tail.
  - Without saving the returned address in `tmp`, the program would have no way to link or later delete that allocation.

- `if (head == nullptr) // check for an empty list` chooses the empty-list path.

  - `if` evaluates the parenthesized condition and runs its following statement or block only when the condition is true.
  - `==` compares two values for equality. It does not change either one.
  - Thus `head == nullptr` asks whether `head` points at nothing.

- `{` opens the true branch.
- `head = tmp; // if the list is empty, set the head to the new node` makes the new node first. Without it, an empty list's `head` would remain null and the new node would be unreachable from the front.
- `}` closes the true branch.
- `else` selects the alternative when `head` was not null; `{` opens that block.
- `tail->next = tmp; // set tail's next to the new node` connects the old last node to the new node.

  - `->` accesses a member through a pointer: `tail->next` means “follow the address in `tail`, then use that node's `next` member.”
  - A dot is used for an object itself (`object.member`); an arrow is used for a pointer to an object (`pointer->member`). Conceptually, `tail->next` is `(*tail).next`.
  - This line must be in the non-empty branch because dereferencing a null `tail` would be invalid.

- `}` closes the `else` block.
- `tail = tmp; // set tail to the new node` makes the new node last in **both** branches. Its constructor left `tmp->next` null, so the tail invariant holds.
- `}` closes the function body.

**Tracing it**

- Empty list, `append(5)`:

  1. Initially `head = nullptr` and `tail = nullptr`.
  2. After allocation, `tmp = address A` and node A is `[5 | next=nullptr]`.
  3. The `if` is true, so `head = A`.
  4. `tail = tmp` makes `tail = A`. Now both point to the only node.

- One-node list, `append(8)`:

  1. Initially `head = A`, `tail = A`, and A is `[5 | next=nullptr]`.
  2. After allocation, `tmp = B` and B is `[8 | next=nullptr]`.
  3. The `if` is false. `tail->next = tmp` changes A's next from null to B.
  4. `tail = tmp` makes `tail = B`. `head` remains A.

:::callout-pitfall[If `tail = tmp` is omitted]
After appending to a non-empty list, the new node is linked in, but `tail` still points to the old last node. The next append overwrites that old node's `next` and can detach the node just appended. After appending to an empty list, `head` becomes non-null while `tail` stays null, immediately violating the empty-list invariant.
:::

### Singly linked prepend

`prepend` adds a value before the current head. The critical order is: save the old head in the new node's `next`, then move `head`.

```text
Before prepend(1):
head
  |
  v
[3] -> [7] -> nullptr
        ^
        |
       tail

After prepend(1):
head
  |
  v
[1] -> [3] -> [7] -> nullptr
               ^
               |
              tail
```

His code, verbatim:

```cpp
void LinkedList::prepend(int data)
{
   Node *tmp = new Node(data); // create the new node
   if (head == nullptr) // check for an empty list
   {
      tail = tmp; // if the list is empty, set the tail to the new node
   }
   tmp->next = head; // set the new node's next to head
   head = tmp; // set the head to the newly created node
}
```

**Line by line**

- `void LinkedList::prepend(int data)` defines the no-return-value member that receives the integer to insert; `{` opens its body.
- `Node *tmp = new Node(data); // create the new node` allocates a node, runs its one-integer constructor, and stores its address in local pointer `tmp`.
- `if (head == nullptr) // check for an empty list` uses the comparison `==` to test the empty case; `{` opens that branch.
- `tail = tmp; // if the list is empty, set the tail to the new node` establishes the only node as the last node. No `else` is needed because prepending to a non-empty list does not change which node is last.
- `}` closes the conditional block.
- `tmp->next = head; // set the new node's next to head` uses `->` to set the pointed-to new node's link. It records the old first-node address **before** `head` changes. On an empty list, it simply assigns `nullptr` again.
- `head = tmp; // set the head to the newly created node` makes the new node first. This is deliberately after the link assignment.
- `}` closes the function.

**Tracing it**

- Empty list, `prepend(5)`:

  1. Initially `head = nullptr` and `tail = nullptr`.
  2. Allocation gives `tmp = A` with `A->next = nullptr`.
  3. The `if` sets `tail = A`.
  4. `tmp->next = head` sets A's next to null, and `head = tmp` sets `head = A`.

- One-node list, `prepend(2)`:

  1. Initially `head = A` and `tail = A` for node `[5]`.
  2. Allocation gives `tmp = B` for `[2]`.
  3. The `if` is false, so `tail` remains A.
  4. `tmp->next = head` makes `B->next = A`.
  5. `head = tmp` makes `head = B`. The chain is B then A, and `tail` is still A.

:::callout-pitfall[If `head` moves first]
If the code does `head = tmp` before `tmp->next = head`, then `head` already equals `tmp` when the second line runs. The new node points to itself, and the entire old chain becomes unreachable. Saving the old head address first is what preserves the list.
:::

### Singly linked search

`search` walks from `head` toward `tail` and returns as soon as it finds the first node whose value matches `data`. It never changes the list.

```text
Before search(7):
head/tmp
  |
  v
[3] -> [7] -> nullptr
        ^
        |
       tail

After match:
head -> [3] -> [7] -> nullptr
               ^
               |
           tail, tmp
The links and head/tail are unchanged.
```

His code, verbatim:

```cpp
bool LinkedList::search(int data)
{
   Node *tmp = head; // set the current tmp node to the head
   while (tmp != nullptr) // loop while the node is still in the list
   {
      if (tmp->data == data) // if the data is found
         return true; // return true
      tmp = tmp->next; // set tmp to the next node in the chain
   }
   return false; // return false if the loop has exited without finding the data
}
```

**Line by line**

- `bool LinkedList::search(int data)` defines a member returning a Boolean result. The parameter is the integer sought; `{` opens the body.
- `Node *tmp = head; // set the current tmp node to the head` makes `tmp` a traversal pointer. Copying the address does not copy a node: `tmp` and `head` initially point to the same node. We move `tmp` so `head` can continue to identify the list's start.
- `while (tmp != nullptr) // loop while the node is still in the list` controls repetition.

  - `while` checks its parenthesized condition before each iteration and repeats its following block while that condition is true.
  - `!=` means “is not equal to.”
  - The condition therefore means “there is still a current node.” It also prevents the body from dereferencing `nullptr`.

- `{` opens the loop body.
- `if (tmp->data == data) // if the data is found` follows `tmp`, reads that node's `data` member with `->`, and compares it with the parameter using `==`.
- `return true; // return true` immediately ends the entire function and gives `true` to the caller. Braces are optional for this `if` because it controls exactly one statement.
- `tmp = tmp->next; // set tmp to the next node in the chain` advances by replacing the current address with the next-node address. Without this line, a nonmatching first node would make the loop repeat forever.
- `}` closes the loop.
- `return false; // return false if the loop has exited without finding the data` runs only after `tmp` became null, meaning every reachable node was checked without a match.
- `}` closes the function.

**Tracing it**

- Empty list, `search(7)`:

  1. `head = nullptr` and `tail = nullptr`, so `tmp = head` makes `tmp = nullptr`.
  2. The `while` condition is false immediately. No pointer is dereferenced.
  3. The function returns `false`.

- One-node list containing 7:

  1. `head = A`, `tail = A`, and `tmp = A`.
  2. `tmp != nullptr` is true; `tmp->data == data` compares `7 == 7`.
  3. `return true` ends the function. `head`, `tail`, and all links remain unchanged.

- One-node list containing 3 while searching for 7:

  1. The comparison `3 == 7` is false.
  2. `tmp = tmp->next` makes `tmp = nullptr`.
  3. The loop stops and the function returns `false`.

:::callout-pitfall[`=` is not `==`]
Writing `if (tmp->data = data)` assigns the requested value into the node instead of comparing. The expression then acts as false when that value is zero and true for any nonzero value, so search both corrupts the list's data and reports misleading results. Use `==` for comparison.
:::

### Singly linked remove

`remove` finds the first node containing `data`, repairs the link around that node, updates `head` or `tail` when necessary, frees the node, and reports success. It tracks both `tmp` (the current node) and `prev` (the node immediately before it).

```text
Before remove(7):
head          tail
 |             |
 v             v
[3] -> [7] -> [9] -> nullptr
        ^      ^
       tmp   tmp->next
 ^
prev

After remove(7):
head          tail
 |             |
 v             v
[3] --------> [9] -> nullptr
```

His code, verbatim:

```cpp
bool LinkedList::remove(int data)
{
   Node *tmp = head; // set the current node to the head
   Node *prev = nullptr; // set the previous node to nullptr

   while (tmp != nullptr) // loop while the node is still in the list
   {
      if (tmp->data == data) // if the data is found
      {
         if (tmp == head) // check to see if we are deleting the head
         {
            head = tmp->next; // set head to the next node in the chain
         }
         else
         {
            prev->next = tmp->next; // set the previous node's next to the next node
         }
         if (tmp == tail) // check to see if we are deleting the tail
         {
            tail = prev; // set the tail to the previous node in the chain
         }
         delete tmp; // delete the current node
         return true;
      }
      prev = tmp; // set the previous node to the current node
      tmp = tmp->next; // set the current node to the next node in the chain
   }
   return false; // return false if the loop has exited without finding the data
}
```

**Line by line**

- `bool LinkedList::remove(int data)` defines an operation returning `true` for “removed” or `false` for “not found”; `{` opens it.
- `Node *tmp = head; // set the current node to the head` starts the current-node pointer at the first node.
- `Node *prev = nullptr; // set the previous node to nullptr` says there is no node before the head. `prev` will trail one node behind `tmp`.
- The blank line separates setup from traversal.
- `while (tmp != nullptr) // loop while the node is still in the list` repeats only while a current node exists; `{` opens the loop.
- `if (tmp->data == data) // if the data is found` compares the current node's value with the target; `{` opens the found case.
- `if (tmp == head) // check to see if we are deleting the head` compares addresses to determine whether the current node is first; `{` opens that case.
- `head = tmp->next; // set head to the next node in the chain` moves the list's entry point past the node being removed. The next address is read while `tmp` is still valid.
- `}` closes the head case.
- `else` means the node is not the head; `{` opens that branch.
- `prev->next = tmp->next; // set the previous node's next to the next node` bypasses `tmp`. Since this is not the head, `prev` points to a real node and may safely be dereferenced.
- `}` closes the non-head branch.
- `if (tmp == tail) // check to see if we are deleting the tail` is a **separate** test for whether the same node is last; `{` opens it.
- `tail = prev; // set the tail to the previous node in the chain` moves the last-node pointer backward. If the only node is being removed, `prev` is null, correctly making `tail` null.
- `}` closes the tail case.
- `delete tmp; // delete the current node` returns that node's heap storage to the allocator.

  - `delete` destroys and frees the object at the supplied address.
  - It does **not** clear the pointer variable. After this line, `tmp` still contains the old address, but that address is invalid—a dangling pointer. This code is safe because it never reads `tmp` again.

- `return true;` reports success and ends the function before any dangling-pointer use; `}` closes the found case.
- `prev = tmp; // set the previous node to the current node` runs only when `tmp` did not match. It advances the trailing pointer to the node just examined.
- `tmp = tmp->next; // set the current node to the next node in the chain` then advances the current pointer. The order maintains “`prev` is immediately before `tmp`.”
- `}` closes the loop.
- `return false; // return false if the loop has exited without finding the data` reports that traversal reached null without a match.
- `}` closes the function.

The cases are:

- **Not found:** traversal reaches `tmp = nullptr`; no links or endpoints change; return `false`.
- **Head of a multi-node list:** move `head` to `tmp->next`; `tail` stays; delete the old head.
- **Tail of a multi-node list:** set `prev->next` to the tail's null `next`, then set `tail = prev`; delete the old tail.
- **Middle node:** set `prev->next = tmp->next`; neither endpoint changes; delete `tmp`.
- **Only node:** it is both head and tail. Set `head = tmp->next`, which is null, and independently set `tail = prev`, which is also null; then delete the node.

**Tracing it**

- Empty list, `remove(5)`:

  1. `head = nullptr` and `tail = nullptr`; setup gives `tmp = nullptr` and `prev = nullptr`.
  2. The loop never runs. The function returns `false` and both endpoints remain null.

- One-node list `[5]`, removing 5:

  1. Initially `head = A`, `tail = A`, `tmp = A`, `prev = nullptr`.
  2. The data matches. Because `tmp == head`, `head = tmp->next` makes `head = nullptr`.
  3. Because `tmp == tail` is also true, `tail = prev` makes `tail = nullptr`.
  4. `delete tmp` frees A; the list is empty and both endpoint pointers agree.

- One-node list `[5]`, removing 8:

  1. The value does not match. `prev = tmp` makes `prev = A`; `tmp = tmp->next` makes `tmp = nullptr`.
  2. The loop stops and returns `false`. `head = tail = A` remain unchanged.

- Head case, `[3] -> [7] -> [9]`, removing 3: `tmp = A` and `prev = nullptr`. The head branch changes `head` from A to B. The tail test is false. A is deleted; `tail` remains C.
- Middle case, removing 7: after one failed comparison, `prev = A` and `tmp = B`. The non-head branch changes `A->next` from B to C. The tail test is false. B is deleted.
- Tail case, removing 9: on the match `prev = B` and `tmp = C`. The non-head branch changes `B->next` from C to null; the tail branch changes `tail` from C to B; C is deleted.
- Not-found case, removing 4: `tmp` visits A, B, C and then becomes null while `prev` ends at C. The function changes no link and returns `false`.

:::callout-pitfall[Relink and update endpoints before deleting]
If the tail update is skipped, `tail` keeps the address of freed memory; a later append dereferences that dangling pointer. If `delete tmp` happens before `head = tmp->next` or `prev->next = tmp->next`, the code must read `tmp->next` from freed memory. Save or install every needed address first, then delete.
:::

### Singly linked display

`display` visits every node from head to tail and writes each value followed by a newline to the stream supplied by the caller. It does not change the list.

```text
Before display:
head/tmp      tail
 |             |
 v             v
[3] -> [7] -> [9] -> nullptr

After display:
stream contains: 3 newline 7 newline 9 newline
head -> [3] -> [7] -> [9] -> nullptr
                            ^
                            tmp
The list itself is unchanged.
```

His code, verbatim:

```cpp
void LinkedList::display(ostream &os) // the ostream here allows us to display to the monitor or a file
{
   Node *tmp = head; // set the current tmp node to the head
   while (tmp != nullptr) // loop while the node is still in the list
   {
      os << tmp->data << endl; // output the data stored in the current node
      tmp = tmp->next; // set tmp to the next node in the chain
   }
}
```

**Line by line**

- `void LinkedList::display(ostream &os) // the ostream here allows us to display to the monitor or a file` defines a no-return-value member. `ostream` is the output-stream type, `&` passes the actual stream by reference, and `os` is its local name. The same function can therefore write to `cout` or an output file.
- `{` opens the function body.
- `Node *tmp = head; // set the current tmp node to the head` starts a traversal without moving `head`.
- `while (tmp != nullptr) // loop while the node is still in the list` repeats while a current node exists; `{` opens the loop body.
- `os << tmp->data << endl; // output the data stored in the current node` writes one value and ends its line.

  - Here `<<` is the stream-insertion operator: send the item on its right into the stream on its left.
  - `tmp->data` reads the current node's integer.
  - Operators of the same precedence associate left to right, so this means `(os << tmp->data) << endl`.
  - `endl` inserts a newline and flushes the stream.

- `tmp = tmp->next; // set tmp to the next node in the chain` advances traversal. Omitting it would repeatedly print the first value forever.
- `}` closes the loop; the final `}` closes the function.

**Tracing it**

- Empty list: `tmp = head` gives `nullptr`. The loop runs zero times, so the stream receives nothing and the endpoints remain null.
- One-node list `[5]`: `tmp = A`; the body writes `5` and `endl`; advancing makes `tmp = nullptr`; the loop stops. `head = tail = A` are unchanged.
- Multi-node list `[3] -> [7]`: the first iteration writes 3 and moves `tmp` from A to B; the second writes 7 and moves it from B to null.

:::callout-pitfall[Traverse with a temporary pointer]
If display advanced `head` instead of `tmp`, printing would empty the list's visible chain without deleting its nodes: `head` would end as null while `tail` stayed non-null, the nodes would leak, and every invariant would be broken.
:::

### The doubly linked operations

A doubly linked node adds `prev`, so every forward connection should have a matching backward connection. Doubly linked `search` is identical to singly linked `search`: it only walks forward through `next`, so repeating that code would add nothing.

**Doubly linked append**

The purpose is still to add after `tail`, but the new node must also point backward to the old tail.

```text
Before append(9):
          next -->
head -> [3] <-> [7] <- tail
        nullptr <- prev     next -> nullptr

After append(9):
head -> [3] <-> [7] <-> [9] <- tail
        prev -> nullptr      next -> nullptr
```

His code, verbatim:

```cpp
void LinkedList::append(int data)
{
   Node *tmp = new Node(data); // create the new node
   tmp->prev = tail; // set the new node's previous pointer to the tail
   if (head == nullptr) // check for an empty list
   {
      head = tmp; // if the list is empty, set the head to the new node
   }
   else
   {
      tail->next = tmp; // set tail's next to the new node
   }
   tail = tmp; // set tail to the new node
}
```

**Line by line**

- `void LinkedList::append(int data)` defines the class member receiving the value; `{` begins its body.
- `Node *tmp = new Node(data); // create the new node` allocates, constructs, and saves the address of a node whose `next` and `prev` should initially be null.
- `tmp->prev = tail; // set the new node's previous pointer to the tail` is the added doubly linked step. On a non-empty list it records the old last node; on an empty list it assigns null.
- `if (head == nullptr) // check for an empty list` tests emptiness; `{` opens the true branch.
- `head = tmp; // if the list is empty, set the head to the new node` makes the only node first; `}` closes that branch.
- `else` chooses the non-empty case; `{` opens it.
- `tail->next = tmp; // set tail's next to the new node` supplies the matching forward link from the old tail to the new node; `}` closes the branch.
- `tail = tmp; // set tail to the new node` updates the last-node pointer in either case. The new tail's `next` remains null.
- `}` closes the function.

**Tracing it**

- Empty list, `append(5)`: start with `head = tail = nullptr`. Allocation gives `tmp = A`. `tmp->prev = tail` leaves `A->prev = nullptr`. The true branch sets `head = A`, and the final line sets `tail = A`. Both outward links are null.
- One-node list, `append(8)`: start with `head = tail = A`. Allocation gives B. `B->prev = A`; the `else` makes `A->next = B`; then `tail = B`. Now A points forward to B and B points backward to A.

:::callout-pitfall[Both directions must agree]
If `tmp->prev = tail` is omitted, forward traversal reaches the new node but backward traversal cannot return to the old tail. If `tail = tmp` is omitted, the endpoint is stale just as in the singly linked version. The relationship must end as `oldTail->next == tmp` and `tmp->prev == oldTail`.
:::

**Doubly linked prepend**

Prepending must connect the new node forward to the old head and, when an old head exists, connect that node backward to the new one.

```text
Before prepend(1):
head -> [3] <-> [7] <- tail

After prepend(1):
head -> [1] <-> [3] <-> [7] <- tail
        prev -> nullptr
```

His code, verbatim:

```cpp
void LinkedList::prepend(int data)
{
   Node *tmp = new Node(data); // create the new node
   if (head == nullptr) // check for an empty list
   {
      tail = tmp; // if the list is empty, set the tail to the new node
   }
   else
   {
      head->prev = tmp; // set head's previous to the new node
   }
   tmp->next = head; // set the new node's next to head
   head = tmp; // set the head to the newly created node
}
```

**Line by line**

- `void LinkedList::prepend(int data)` defines front insertion; `{` opens its body.
- `Node *tmp = new Node(data); // create the new node` creates a node whose constructor must initialize `prev` to null as well as `next`.
- `if (head == nullptr) // check for an empty list` tests the empty case; `{` opens it.
- `tail = tmp; // if the list is empty, set the tail to the new node` makes the only node last; `}` closes this branch.
- `else` handles a list with an old head; `{` opens it.
- `head->prev = tmp; // set head's previous to the new node` gives the old first node its new backward link; `}` closes the branch. This line must not run when `head` is null.
- `tmp->next = head; // set the new node's next to head` gives the new node its forward link to the old head. As before, this happens before `head` changes.
- `head = tmp; // set the head to the newly created node` makes the new node first.
- `}` closes the function.

**Tracing it**

- Empty list, `prepend(5)`: allocation gives `tmp = A` with both links null. The true branch sets `tail = A`; `tmp->next = head` remains null; `head = A`. The only node is both endpoints.
- One-node list, `prepend(2)`: start with `head = tail = A`. Allocation gives B with `B->prev = nullptr`. The `else` makes `A->prev = B`; `B->next = A`; `head = B`. `tail` stays A.

This operation is correct only if the doubly linked constructor initializes `prev` to `nullptr`. His exact doubly linked Node page was not captured, and `prepend` never assigns `tmp->prev` itself.

:::callout-pitfall[Do not move `head` too early]
If `head = tmp` happens first, `tmp->next = head` makes the new node point to itself, and `head->prev = tmp` no longer updates the old head. The old chain is lost. If the constructor also fails to null `tmp->prev`, backward traversal before the head follows garbage.
:::

**Doubly linked remove**

The search is still forward, but unlinking uses the node's own `prev` pointer instead of maintaining a separate local `prev`. Both neighbors must be repaired.

```text
Before remove(7):
head -> [3] <-> [7] <-> [9] <- tail
                 ^
                tmp

After remove(7):
head -> [3] <----------> [9] <- tail
        [3].next = [9]
        [9].prev = [3]
```

His code is reproduced verbatim except for the marked correction:

```cpp
bool LinkedList::remove(int data)
{
   Node *tmp = head; // set the current node to the head

   while (tmp != nullptr) // loop while the node is still in the list
   {
      if (tmp->data == data) // if the data is found
      {
         if (tmp == head) // check to see if we are deleting the head
         {
            head = tmp->next; // set head to the next node in the chain
         }
         else
         {
            tmp->prev->next = tmp->next; // set the previous node's next to the next node
         }
         if (tmp == tail) // check to see if we are deleting the tail
         {
            tail = tmp->prev; // CORRECTED — his page reads `tail = prev;`, and `prev`
                              // is not declared in this function
         }
         else
         {
           tmp->next->prev = tmp->prev; // set the next node's previous to the previous node
         }
         delete tmp; // delete the current node
         return true;
      }
      tmp = tmp->next; // set the current node to the next node in the chain
   }
   return false; // return false if the loop has exited without finding the data
}
```

Dr. Swan's posted page reads `tail = prev;`, but no variable named `prev` exists in this function, so that line does not compile. The corrected `tail = tmp->prev;` reads the predecessor stored in the node being removed.

**Line by line**

- `bool LinkedList::remove(int data)` defines removal by value and its success/failure result; `{` opens the function.
- `Node *tmp = head; // set the current node to the head` starts the search at the first node.
- The blank line separates initialization from the loop.
- `while (tmp != nullptr) // loop while the node is still in the list` keeps searching while `tmp` names a real node; `{` opens the loop.
- `if (tmp->data == data) // if the data is found` tests the current value; `{` opens the match case.
- `if (tmp == head) // check to see if we are deleting the head` asks whether there is no preceding node; `{` opens that case.
- `head = tmp->next; // set head to the next node in the chain` moves the front endpoint past `tmp`. This can set `head` to null.
- `}` closes the head case.
- `else` means a predecessor exists; `{` opens the alternative.
- `tmp->prev->next = tmp->next; // set the previous node's next to the next node` follows `tmp->prev` to the preceding node and changes that node's `next` to bypass `tmp`. Chained arrows are evaluated left to right: “from `tmp`, go to `prev`, then assign that node's `next`.”
- `}` closes the non-head branch.
- `if (tmp == tail) // check to see if we are deleting the tail` independently asks whether there is no following node; `{` opens that case.
- `tail = tmp->prev;` moves the back endpoint to the predecessor stored in the node being removed. For a one-node list, that predecessor is null.
- The two-line comment after it records the correction: his posted page has `tail = prev;` here. Like every `//` comment, it has no runtime effect.
- `}` closes the tail case.
- `else` means a next node exists; `{` opens the alternative.
- `tmp->next->prev = tmp->prev; // set the next node's previous to the previous node` follows `tmp->next` and changes that successor's `prev` to bypass `tmp` in the backward direction.
- `}` closes the non-tail branch.
- `delete tmp; // delete the current node` frees the now-unlinked node; its address remains in `tmp` but is no longer used.
- `return true;` reports success immediately; `}` closes the match case.
- `tmp = tmp->next; // set the current node to the next node in the chain` advances only after a nonmatch.
- `}` closes the loop.
- `return false; // return false if the loop has exited without finding the data` reports that traversal reached null; the final `}` closes the function.

The two `if`/`else` pairs are intentionally independent. The first repairs the **left/front** side; the second repairs the **right/back** side. An only node is simultaneously `head` and `tail`, so both true branches must fire. Turning the second `if` into `else if` would leave `tail` pointing at freed memory in the one-node case.

**Tracing it**

- Empty list, `remove(5)`: `head = tail = nullptr` and `tmp = nullptr`. The loop does not run; return `false`.
- One-node list `[5]`, removing 5: `head = tail = tmp = A`. The head test sets `head = A->next = nullptr`. The independent tail test sets `tail = A->prev = nullptr`. Both `else` blocks are skipped; A is deleted.
- One-node list `[5]`, removing 8: the comparison fails; `tmp = tmp->next` becomes null; return `false` with both endpoints still A.
- Head of `[3] <-> [7] <-> [9]`: set `head = B`; the tail test is false, so set `B->prev = A->prev = nullptr`; delete A.
- Middle node B: the head test is false, so set `A->next = C`. The tail test is false, so set `C->prev = A`. Delete B.
- Tail C: the head test is false, so set `B->next = C->next = nullptr`. The tail test is true, so set `tail = C->prev = B`. Delete C.
- Not found: `tmp` follows each `next` to null; no endpoint or node link changes.

:::callout-pitfall[Repair both neighbors before `delete`]
Skipping the tail update leaves `tail` dangling when the last node is removed. Deleting `tmp` before either relink makes later uses of `tmp->prev` or `tmp->next` reads from freed memory. First use the still-valid node to reconnect neighbors and endpoints; only then free it.
:::

A doubly linked list still takes O(n) time to remove **by value**. Once `tmp` identifies the node, `prev` makes unlinking O(1), but finding that node by comparing values is the linear part.

### The Rule of Three

A class that owns heap memory needs three coordinated operations: a **destructor**, a **copy constructor**, and a **copy assignment operator** (`operator=`). The compiler-generated versions only copy pointer values. That is a shallow copy:

```text
After the default (shallow) copy, b = a:

list a:  head ---+          +--- tail
                 v          v
                [3] -----> [7] -> nullptr
                 ^          ^
list b:  head ---+          +--- tail

Both objects believe they own the same nodes.
a's destructor deletes [3] and [7].
b's destructor later tries to delete [3] and [7] again.
```

The first destruction leaves the other list's pointers dangling; the second attempts double deletion, which is undefined behavior. A deep copy instead creates different nodes containing the same values.

:::callout-pitfall[`operator<<` is not part of the Rule of Three]
The three are the destructor, copy constructor, and copy assignment operator (`operator=`). `operator<<` often appears beside them on course pages because it is another special-looking function, but output has nothing to do with ownership or copying and is **not** one of the three.
:::

**Destructor**

His destructor, verbatim:

```cpp
LinkedList::~LinkedList()
{
  Node *tmp = head; // set the current tmp node to the head
  while (tmp != nullptr) // loop while the node is still in the list
  {
     head = head->next; // move the head to the next node in the chain
     delete tmp; // delete the node stored in tmp
     tmp = head; // set the tmp node to the newly assigned head;
  }
  tail = nullptr; // set tail to nullptr;
}
```

**Line by line**

- `LinkedList::~LinkedList()` defines the destructor declared in the class.

  - `LinkedList::` says the function belongs to `LinkedList`.
  - `~LinkedList` names the destructor; the tilde distinguishes destruction from construction.
  - `()` contains no parameters.

- `{` opens the body.
- `Node *tmp = head; // set the current tmp node to the head` saves the address of the node that should be deleted next.
- `while (tmp != nullptr) // loop while the node is still in the list` repeats until no node remains; `{` opens the loop.
- `head = head->next; // move the head to the next node in the chain` saves access to the rest of the chain by advancing `head` **before** the current node is freed.
- `delete tmp; // delete the node stored in tmp` frees the old head. `tmp` now dangles, but the next line overwrites it without dereferencing it.
- `tmp = head; // set the tmp node to the newly assigned head;` selects the next still-live node.
- `}` closes the loop.
- `tail = nullptr; // set tail to nullptr;` restores agreement between the endpoints. When the loop finishes `head` is already null; now `tail` is too.
- `}` closes the destructor.

:::callout-warning[Advance before deleting]
If `delete tmp` came before `head = head->next`, then `head` and `tmp` would still point to freed storage and `head->next` would read that freed object. Deletion must be the last use of the node's contents.
:::

On an empty list, `tmp` starts null, the loop runs zero times, and `tail` is set to null again. On a one-node list, advancing `head` reads the node's null `next`; deletion frees that node; `tmp = head` becomes null; the loop ends; `tail` becomes null. On a longer list, the same three-line cycle removes one head at a time.

**Copy constructor**

His copy constructor, verbatim:

```cpp
LinkedList::LinkedList(const LinkedList &old)
{
    Node *tmp = old.head; // set the current tmp node to the original list's head

    head = nullptr; // set the head to nullptr
    tail = nullptr; // set the tail to nullptr

    while (tmp != nullptr) // loop while the node is still in the original list
    {
       append(tmp->data); // append the contents of the tmp node into the new list
       tmp = tmp->next; // set tmp to the next node in the original list's chain
     }
}
```

**Line by line**

- `LinkedList::LinkedList(const LinkedList &old)` defines the copy constructor: the first qualified `LinkedList` identifies the class and the second is the constructor name. `const LinkedList &old` refers to the unmodifiable source list without copying it merely to pass it in.
- `{` opens the body.
- `Node *tmp = old.head; // set the current tmp node to the original list's head` starts traversal at the source's private `head`. A member function may access private members of another object of the same class.
- The blank line separates source traversal setup from destination initialization.
- `head = nullptr; // set the head to nullptr` and `tail = nullptr; // set the tail to nullptr` establish a valid empty destination **before** `append` is called.

  A freshly constructed object's pointer members do not automatically hold null; until assigned, they contain indeterminate garbage. `append` reads `head` to test emptiness and may read `tail`, so calling it first would use invalid addresses.

- The next blank line separates initialization from copying.
- `while (tmp != nullptr) // loop while the node is still in the original list` repeats once per source node; `{` opens the loop.
- `append(tmp->data); // append the contents of the tmp node into the new list` reads the current source value and lets the already-correct `append` function allocate and link a separate destination node. Reuse is shorter and preserves order and invariants.
- `tmp = tmp->next; // set tmp to the next node in the original list's chain` advances through the source, not the growing destination.
- `}` (indented by five spaces in the posted code) closes the loop; the final `}` closes the constructor.

If `old` is empty, `tmp` begins null and the new list remains validly empty. If `old` has one node at A, `append(old.head->data)` creates a **different** node B with the same integer; the new list's `head` and `tail` point to B, never A.

**The missing copy assignment operator**

His posted `LinkedList` class has **no copy assignment operator**. Therefore code such as `LinkedList a, b; ... a = b;` uses the compiler's default shallow assignment: it leaks the nodes that `a` previously owned, makes `a` share `b`'s nodes, and eventually leads to double deletion.

The following code is **not from his pages**. It is the missing declaration and definition, written in his style:

```cpp
// add this declaration in the public part of LinkedList
LinkedList &operator=(const LinkedList &old); // assign a deep copy of old

// define the copy assignment operator outside the class
LinkedList &LinkedList::operator=(const LinkedList &old) // assign old to this list
{
   if (this == &old) return *this; // do nothing when an object is assigned to itself

   while (head != nullptr) // loop while this list still owns a node
   {
      Node *tmp = head; // save the current head so it can be deleted
      head = head->next; // move head before deleting the current node
      delete tmp; // free the old node
   }
   tail = nullptr; // make the now-empty list satisfy its invariants

   Node *tmp = old.head; // start at the first node in the source list
   while (tmp != nullptr) // loop through every source node
   {
      append(tmp->data); // append a separately allocated copy of the value
      tmp = tmp->next; // move to the next source node
   }

   return *this; // return the assigned list
}
```

The self-assignment check matters for `a = a`: without it, the function would delete the very nodes it was about to copy. In this context, `this` is an automatically available pointer to the object on the left side of `=`. `&old` uses `&` as the address-of operator and obtains the source object's address. Therefore `this == &old` asks whether both names refer to the same object.

`*this` dereferences that pointer and means “the current `LinkedList` object itself.” The function returns `LinkedList &`, a reference rather than another copied list, so assignment expressions can chain. In `a = b = c`, `b = c` runs first and returns `b` itself; that returned list then becomes the source for `a = b`.

### operator<<

This operator lets client code write `cout << list`. It delegates the actual traversal to `display`.

His code, verbatim:

```cpp
ostream &operator<<(ostream &os, LinkedList &right)
{
   right.display(os); // call the display operation for the LinkedList

   return os; // return the updated version of os
}
```

**Line by line**

- `ostream &operator<<(ostream &os, LinkedList &right)` defines the stream-insertion operator.

  - `ostream &` is the return type: a reference to the same output stream.
  - `operator<<` names the overload of `<<`.
  - `ostream &os` is the left operand, such as `cout` or a file stream.
  - `LinkedList &right` is the right operand, the list to print.
  - Returning the stream enables chaining: `cout << a << b` is grouped as `(cout << a) << b`. The first call must return `cout` so it can become the next call's left operand.

- `{` opens the function body.
- `right.display(os); // call the display operation for the LinkedList` uses `.` because `right` is an object reference, not a pointer. It calls the list's public `display` and passes the same stream onward.
- The blank line separates the action from the return.
- `return os; // return the updated version of os` ends the function and returns a reference to the caller's stream, now containing the list's output.
- `}` closes the function.

This must be a non-member operator because its left operand is an `ostream`. A member operator is invoked on its left operand; making this a `LinkedList` member would naturally support `list << something`, not `cout << list`. We cannot add a new member to the standard library's `ostream` class. A non-member accepts both operands explicitly. As noted earlier, `friend` is unnecessary for this exact body because it calls only public `display`.

### Complexity at a glance

Let `n` be the number of nodes traversed in the relevant list. For assignment, let `m` be the old destination size and `n` the source size.

| Operation | Singly linked with `tail` | Doubly linked with `tail` | Why |
| --- | --- | --- | --- |
| `append` | O(1) | O(1) | `tail` reaches the insertion point directly. |
| `prepend` | O(1) | O(1) | `head` reaches the insertion point directly. |
| `search` | O(n) | O(n) | Values may require a full forward scan. |
| `remove(data)` | O(n) | O(n) | Finding the value is linear; unlinking after it is found is O(1). |
| `display` | O(n) | O(n) | Every value is written once. |
| Destructor | O(n) | O(n) | Every owned node is deleted once. |
| Copy constructor | O(n) | O(n) | Every source value is visited and appended once. |
| Copy assignment | O(m + n) | O(m + n) | It deletes `m` old nodes and copies `n` source nodes. |
| `operator<<` | O(n) | O(n) | It calls `display`. |

The extra `prev` pointer improves operations only when the relevant node is already known. It does not make a value search sublinear.

### How to write any linked-list operation yourself

1. Draw the **before** and **after** chains, including `head`, `tail`, every link that changes, and `nullptr`.
2. List the cases: empty list, one node, first node, last node, middle node, and not found. Discard only cases that truly cannot apply to that operation.
3. Order pointer assignments so no node becomes unreachable before you have saved every address you still need.
4. Update `head` and `tail` for every case that changes the first or last node.
5. If you unlinked an owned heap node, free it with `delete` only after all needed links have been read and repaired.
6. Check every case against every invariant: endpoints agree about emptiness; a non-empty tail's `next` is null; following `next` from `head` reaches `tail`.

That is exactly how every function above was built. The code is not a collection of magic lines to memorize; it is the written form of the before/after drawing plus the invariants.

:::summary
## Chapter Summary

| Structure | Key advantage | Key disadvantage |
| --- | --- | --- |
| Singly linked list | O(1) front insert/delete; dynamic size | O(n) access; no backward traversal |
| Doubly linked list | O(1) deletion given node\*; bidirectional traversal | Extra pointer per node; more complex update logic |
| Circular list | Tail reaches head trivially | Traversal must detect wrap-around to avoid infinite loop |
| Sentinel node | Eliminates head/tail special cases | One wasted node allocation |

### If you remember nothing else

Linked lists trade random access (O(n)) for O(1) front insertion. The pointer manipulation follows a simple rule: always save the next pointer before overwriting it, and handle the head and tail as special cases (or use sentinels to make them disappear).
:::

## Mixed Practice

:::problem[Problem M.1 easy]{difficulty="easy"}
What is the time complexity of counting the number of nodes in a singly linked list (without a `size` field)?

::::solution[Solution]
$O(n)$ — you must traverse every node and increment a counter.
::::
:::

:::problem[Problem M.2 standard]{difficulty="standard"}
Write a function to find the middle node of a singly linked list in a single pass (O(n) time, O(1) space). If even length, return the second middle.

::::solution[Solution]
```cpp
Node* findMiddle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}
```

The **slow/fast pointer** technique: `fast` moves twice as fast as `slow`. When `fast` reaches the end, `slow` is at the middle. For a list of length $n$, `slow` has moved $\lfloor n/2 \rfloor$ steps.
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
Explain why the following destructor is O(n²) in the worst case, and rewrite it to be O(n):

```cpp
~LinkedList() {
    for (int i = 0; i < size_; i++) {
        // remove the i-th element
        Node* cur = head;
        for (int j = 0; j < i-1; j++) cur = cur->next;
        Node* old = cur->next; cur->next = old->next; delete old;
    }
}
```

::::solution[Solution]
The inner loop traverses to position $i$ for each deletion: $0 + 1 + 2 + \cdots + (n-1) = O(n^2)$ total steps.

**O(n) fix**: always delete the head — it's O(1) each time:

```cpp
~LinkedList() {
    while (head) {
        Node* old = head;
        head = head->next;
        delete old;
    }
}
```
::::
:::

:::problem[Problem M.4 challenge]{difficulty="challenge"}
Check if a singly linked list is a palindrome (reads the same forward and backward) in O(n) time and O(1) space.

::::solution[Solution]
```cpp
bool isPalindrome(Node* head) {
    if (!head || !head->next) return true;

    // Step 1: find middle using slow/fast
    Node* slow = head, *fast = head;
    while (fast->next && fast->next->next) {
        slow = slow->next; fast = fast->next->next;
    }

    // Step 2: reverse second half in-place
    Node* prev = nullptr, *cur = slow->next;
    while (cur) {
        Node* nxt = cur->next;
        cur->next = prev; prev = cur; cur = nxt;
    }

    // Step 3: compare first half and reversed second half
    Node* left = head, *right = prev;
    bool ok = true;
    while (right) {
        if (left->data != right->data) { ok = false; break; }
        left = left->next; right = right->next;
    }

    // (Optional: restore the list by reversing the second half again)
    return ok;
}
```

Three-step trick: find middle (slow/fast), reverse the second half, compare from both ends. All O(n) time, O(1) space.
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook.
