---
title: "Advanced Data Structures"
crumb: "Honors DSA · Chapter 17"
meta:
  - "Est. study time: ~70 min"
  - "Unit 6"
  - "CSE 2383 · MSState"
source: "dsa_ch17_advanced_ds.html"
---

## 1. Tries (Prefix Trees)

A **trie** is a tree where each path from root to a node represents a string prefix. Each node stores one character, and children correspond to the next character in the string. Unlike hash tables, tries support prefix queries natively.

```cpp
struct TrieNode {
    TrieNode* children[26] = {};
    bool isEnd = false;
};

struct Trie {
    TrieNode* root = new TrieNode();

    void insert(const string& word) {
        TrieNode* cur = root;
        for (char c : word) {
            int idx = c - 'a';
            if (!cur->children[idx])
                cur->children[idx] = new TrieNode();
            cur = cur->children[idx];
        }
        cur->isEnd = true;
    }

    bool search(const string& word) {
        TrieNode* cur = root;
        for (char c : word) {
            int idx = c - 'a';
            if (!cur->children[idx]) return false;
            cur = cur->children[idx];
        }
        return cur->isEnd;
    }

    bool startsWith(const string& prefix) {
        TrieNode* cur = root;
        for (char c : prefix) {
            int idx = c - 'a';
            if (!cur->children[idx]) return false;
            cur = cur->children[idx];
        }
        return true;
    }
};
```

:::callout-key[Time Complexity]
Insert, search, and prefix-check all run in **O(m)** where m is the length of the string — independent of how many strings are stored. Space: O(total characters across all strings × alphabet size).
:::

### Applications

- **Autocomplete**: given a prefix, enumerate all completions via DFS from the prefix node
- **Spell check**: check if a word exists in the dictionary trie
- **IP routing**: longest prefix matching using binary tries
- **Word games**: find all valid words from a set of letters

:::example[Example 17.1 — Trie Insert and Search]
Insert "cat", "car", "card", "care" into a trie. Then search for "car" and "care".

::::answer[Answer]
"car" → found (isEnd=true). "care" → found (isEnd=true).
::::

Work

```
Root → c → a → t (end)
              → r (end) → d (end)
                        → e (end)

Search "car": root→c→a→r, isEnd=true ✓
Search "care": root→c→a→r→e, isEnd=true ✓
```
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
After inserting "dog", "dot", "do" into a trie, does searching for "do" return true?

::::solution[Solution]
Yes. "do" was explicitly inserted, so the node after 'o' has isEnd=true.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
What is the space complexity of a trie storing n strings of average length m over an alphabet of size σ? What is the worst case?

::::solution[Solution]
Each node stores σ child pointers. In the worst case (no shared prefixes), n·m nodes are created, for O(n·m·σ) space. With heavy sharing, it can be much less. For English lowercase (σ=26), this is 26 pointers per node.
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
How would you implement an autocomplete function that returns all words with a given prefix?

::::solution[Solution]
Navigate to the prefix's end node (as in startsWith). Then run DFS from that node, collecting all paths where isEnd=true. Each such path, prepended with the prefix, is a valid completion. Time: O(m + output size) where m = prefix length.
::::
:::

## 2. Segment Trees

A **segment tree** stores aggregate information (sum, min, max) over contiguous sub-arrays, supporting both *point updates* and *range queries* in O(log n).

### Structure

Store the tree in an array of size 4n. Node at index i covers a range; its children are at 2i (left half) and 2i+1 (right half). Leaves hold individual elements; internal nodes hold aggregates.

```cpp
// Segment tree for range sum queries
struct SegTree {
    int n;
    vector<int> tree;
    SegTree(vector<int>& arr) : n(arr.size()), tree(4*arr.size(), 0) {
        build(arr, 1, 0, n-1);
    }
    void build(vector<int>& arr, int node, int l, int r) {
        if (l == r) { tree[node] = arr[l]; return; }
        int mid = (l+r)/2;
        build(arr, 2*node, l, mid);
        build(arr, 2*node+1, mid+1, r);
        tree[node] = tree[2*node] + tree[2*node+1];
    }
    void update(int node, int l, int r, int idx, int val) {
        if (l == r) { tree[node] = val; return; }
        int mid = (l+r)/2;
        if (idx <= mid) update(2*node, l, mid, idx, val);
        else update(2*node+1, mid+1, r, idx, val);
        tree[node] = tree[2*node] + tree[2*node+1];
    }
    int query(int node, int l, int r, int ql, int qr) {
        if (qr < l || r < ql) return 0;
        if (ql <= l && r <= qr) return tree[node];
        int mid = (l+r)/2;
        return query(2*node, l, mid, ql, qr) +
               query(2*node+1, mid+1, r, ql, qr);
    }
};
```

:::callout-key[Complexities]
Build: **O(n)**. Point update: **O(log n)**. Range query: **O(log n)**. Space: **O(n)** (4n array). Compare: naive prefix-sum supports O(1) query but O(n) update.
:::

:::problem[Problem 4 · standard]{difficulty="standard"}
Array: [1, 3, 5, 7, 9]. Build a range-sum segment tree. What is the root's value? What does the left child of the root represent?

::::solution[Solution]
Root value = 25 (total sum). Left child covers indices [0,2] with sum 1+3+5=9. Right child covers [3,4] with sum 7+9=16.
::::
:::

:::problem[Problem 5 · challenge]{difficulty="challenge"}
How would you extend a segment tree to support range updates (e.g., add 5 to all elements in [l, r])? What is this technique called?

::::solution[Solution]
Lazy propagation. Store a "lazy" array alongside the segment tree. When updating a range, push the update down lazily — record it in the lazy array and only propagate to children when that subtree is queried or updated again. This keeps range updates at O(log n).
::::
:::

## 3. Fenwick Trees (Binary Indexed Trees)

A **Fenwick tree** (BIT) is a simpler alternative to segment trees for prefix sum queries with point updates. It uses a clever bit manipulation trick to store partial sums efficiently.

### The lowbit Trick

`lowbit(i) = i & (-i)` isolates the lowest set bit of i. Each BIT position i stores the sum of elements from `i - lowbit(i) + 1` to `i`.

```cpp
// 1-indexed Fenwick Tree
struct BIT {
    int n;
    vector<int> tree;
    BIT(int n) : n(n), tree(n+1, 0) {}

    void update(int i, int delta) {
        for (; i <= n; i += i & (-i))
            tree[i] += delta;
    }

    int query(int i) {  // prefix sum [1..i]
        int sum = 0;
        for (; i > 0; i -= i & (-i))
            sum += tree[i];
        return sum;
    }

    int rangeQuery(int l, int r) {
        return query(r) - query(l-1);
    }
};
```

:::callout-connect[BIT vs Segment Tree]
BIT is simpler to code and has smaller constants, but is less flexible — it only works for operations where prefix queries suffice (sum, XOR, etc.). Segment trees support arbitrary range queries (min, max, GCD) and lazy propagation. For competitive programming, BIT is the go-to for prefix sums.
:::

:::problem[Problem 6 · standard]{difficulty="standard"}
In a Fenwick tree of size 8, which positions does `update(6, 1)` modify?

::::solution[Solution]
Start at i=6. lowbit(6)=6&(-6)=2. Next: i=6+2=8. lowbit(8)=8. Next: i=16 > 8, stop. Modifies positions 6 and 8.
::::
:::

:::problem[Problem 7 · standard]{difficulty="standard"}
Array: [2, 1, 1, 3, 2, 3, 4, 5]. Build a BIT and query the prefix sum for i=6 (1-indexed).

::::solution[Solution]
Prefix sum [1..6] = 2+1+1+3+2+3 = 12. Query(6): i=6, sum+=BIT[6]; i=6-lowbit(6)=4, sum+=BIT[4]; i=4-4=0, stop. BIT[6] stores sum of [5..6]=5, BIT[4] stores sum of [1..4]=7. Total=12.
::::
:::

## 4. Disjoint Set Union (DSU / Union-Find)

DSU maintains a collection of disjoint sets, supporting two operations efficiently: **find** (which set does x belong to?) and **union** (merge the sets containing x and y).

```cpp
struct DSU {
    vector<int> parent, rank;
    DSU(int n) : parent(n), rank(n, 0) {
        iota(parent.begin(), parent.end(), 0); // parent[i] = i
    }
    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]); // path compression
        return parent[x];
    }
    void unite(int x, int y) {
        x = find(x); y = find(y);
        if (x == y) return;
        if (rank[x] < rank[y]) swap(x, y);
        parent[y] = x;             // union by rank
        if (rank[x] == rank[y]) rank[x]++;
    }
    bool connected(int x, int y) { return find(x) == find(y); }
};
```

:::callout-key[Amortized Complexity]
With both **path compression** and **union by rank**, each operation runs in amortized O(α(n)) — the inverse Ackermann function, which is effectively O(1) for all practical n. Without optimizations: O(log n) per operation.
:::

### Applications

- **Kruskal's MST**: union vertices of each added edge, use find to detect cycles
- **Connected components**: check if two vertices share a root
- **Percolation**: does a path exist from top to bottom of a grid?

:::problem[Problem 8 · standard]{difficulty="standard"}
Run DSU with path compression on: unite(1,2), unite(3,4), unite(2,4). Then find(1) and find(3). Are they connected?

::::solution[Solution]
After unite(1,2): {1,2}, {3}, {4}. After unite(3,4): {1,2}, {3,4}. After unite(2,4): find(2)=root of {1,2}, find(4)=root of {3,4}; merge → {1,2,3,4}. find(1) == find(3) → yes, connected.
::::
:::

## 5. Sparse Tables

A **sparse table** answers static *range minimum (or maximum) queries* in O(1) after an O(n log n) preprocessing step. It only works on **static arrays** (no updates) and **idempotent operations** (min, max, GCD — not sum).

### Construction

Let `table[i][j]` = minimum in the range `[i, i + 2^j - 1]`.

```cpp
// Sparse table for range minimum query
const int LOG = 20;
int table[100005][LOG];
int lg[100005]; // precomputed log2

void build(int arr[], int n) {
    for (int i = 0; i < n; i++) table[i][0] = arr[i];
    for (int j = 1; (1<<j) <= n; j++)
        for (int i = 0; i+(1<<j)-1 < n; i++)
            table[i][j] = min(table[i][j-1], table[i+(1<<(j-1))][j-1]);
}

// O(1) RMQ query
int query(int l, int r) {
    int k = lg[r - l + 1]; // floor(log2(r-l+1))
    return min(table[l][k], table[r-(1<<k)+1][k]);
}
```

:::callout-intuition[Why O(1) Query Works]
For minimum (an idempotent operation), two overlapping ranges give the same result as their union. So query [l,r] with two overlapping power-of-2 ranges that cover [l,r] exactly — taking the min of both is correct even if they overlap, because min(x,x) = x.
:::

:::problem[Problem 9 · standard]{difficulty="standard"}
Why can't a sparse table be used for range sum queries?

::::solution[Solution]
Sum is not idempotent — summing overlapping ranges double-counts elements. Sparse tables rely on the fact that combining two overlapping ranges gives the same result as combining non-overlapping ones, which only holds for idempotent operations like min, max, and GCD.
::::
:::

## 6. Amortized Analysis

Amortized analysis gives a *per-operation average cost* over a sequence of operations, even when individual operations vary wildly in cost. It's stronger than average-case: it holds for *every* input sequence.

### Three Methods

#### 1. Aggregate Method

Show total cost of n operations is O(T(n)), so amortized cost per operation = T(n)/n. Example: dynamic array doublings cost n total for n pushes → O(1) amortized per push.

#### 2. Accounting Method

Assign each operation an amortized cost. "Prepay" for future expensive operations. The credit must always remain non-negative. Example: each push pays 2 — 1 for itself, 1 saved for future copy when array doubles.

#### 3. Potential Method

Define a potential function Φ. Amortized cost = actual cost + ΔΦ. Choose Φ so expensive operations correspond to large drops in Φ. Example: Φ = 2·(size) − capacity. Insert raises Φ by 2; doubling resets Φ to 0.

:::example[Example 17.2 — Dynamic Array Amortized Analysis]
Show that n push\_back operations on a dynamic array (doubling when full) cost O(n) total.

::::answer[Answer]
Total cost = O(n). Amortized cost per push = O(1).
::::

Work

```
Copying happens at sizes 1, 2, 4, 8, ..., n.
Total copies = 1 + 2 + 4 + ... + n = 2n - 1 = O(n).
Plus n pushes themselves = n.
Grand total = O(n). Average per operation = O(1).
```
:::

:::problem[Problem 10 · standard]{difficulty="standard"}
How does amortized O(1) differ from average-case O(1)?

::::solution[Solution]
Average-case O(1) holds over random inputs but could be slow on adversarial inputs. Amortized O(1) holds for ALL input sequences — it's a worst-case guarantee spread over a sequence. Amortized analysis is deterministic (no randomness assumed).
::::
:::

:::problem[Problem 11 · challenge]{difficulty="challenge"}
A stack supports push (O(1)) and multipop(k) which pops min(k, size) elements. Show that n operations have O(n) total cost.

::::solution[Solution]
Each element is pushed at most once and popped at most once, regardless of how many multipop calls happen. Total pushes ≤ n. Total pops ≤ total pushes ≤ n. So total work = O(n), and amortized cost per operation = O(1).
::::
:::

## 7. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
What is the time complexity of searching for a string of length m in a trie of n strings?

::::solution[Solution]
O(m) — only the length of the query string matters, not the number of strings stored. Navigate one node per character.
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
Compare segment tree vs Fenwick tree: when would you choose each?

::::solution[Solution]
Use Fenwick tree for prefix sum/XOR queries with point updates — simpler code, smaller constants. Use segment tree when you need: range min/max, arbitrary range aggregates, lazy range updates, or operations that don't support prefix decomposition.
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
What are the two optimizations that make DSU nearly O(1) per operation, and what does each do?

::::solution[Solution]
(1) Path compression: when finding the root, make every node on the path point directly to the root, flattening future queries. (2) Union by rank: always attach the shorter tree under the taller one, keeping tree heights at O(log n). Together they give amortized O(α(n)) ≈ O(1).
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
Why does sparse table only work for idempotent operations like min and max, but not sum?

::::solution[Solution]
The O(1) query uses two overlapping intervals that together cover [l,r]. For min/max, overlapping is fine because min(x, x) = x. For sum, overlapping double-counts elements, giving an incorrect result. Sum requires non-overlapping decomposition, which needs O(log n) time (like a Fenwick tree or segment tree).
::::
:::

:::problem[Exam Q5 · challenge]{difficulty="challenge"}
How is DSU used in Kruskal's MST algorithm? What operation detects a cycle?

::::solution[Solution]
Kruskal's processes edges in increasing weight order. For each edge (u,v): call find(u) and find(v). If they return the same root, adding this edge would create a cycle — skip it. Otherwise, unite(u,v) and add the edge to the MST. After V-1 edges are added, we have the MST.
::::
:::

:::problem[Exam Q6 · standard]{difficulty="standard"}
Describe the aggregate method of amortized analysis and apply it to show that n insertions into a dynamic array cost O(n) total.

::::solution[Solution]
Aggregate method: find the total cost T(n) of n operations, then amortized cost = T(n)/n. For dynamic array: direct insertions cost O(n) total. Copying during doublings costs 1+2+4+...+n/2+n = 2n−1 = O(n). Grand total T(n) = O(n). Amortized = O(n)/n = O(1) per operation.
::::
:::

:::problem[Exam Q7 · challenge]{difficulty="challenge"}
What is the space complexity of a trie vs a hash table for storing n strings of average length m?

::::solution[Solution]
Trie: O(n·m·σ) where σ is alphabet size (26 for lowercase). In practice, shared prefixes reduce this. Hash table: O(n·m) — stores strings directly with O(1) pointers per entry. Hash tables are more space-efficient but don't support prefix queries. Tries win for autocomplete and prefix operations.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
Build a segment tree on [3, 1, 4, 1, 5, 9] for range minimum queries. What is the root's value and what range does each child of the root cover?

::::solution[Solution]
Root covers [0,5], value = min(3,1,4,1,5,9) = 1. Left child covers [0,2], value = min(3,1,4) = 1. Right child covers [3,5], value = min(1,5,9) = 1.
::::
:::

:::summary
## Chapter 17 Summary

| Structure | Build | Query | Update | Use Case |
| --- | --- | --- | --- | --- |
| Trie | O(total chars) | O(m) | O(m) | String prefix queries |
| Segment Tree | O(n) | O(log n) | O(log n) | Range min/max/sum + updates |
| Fenwick Tree | O(n log n) | O(log n) | O(log n) | Prefix sums with updates |
| DSU | O(n) | O(α(n)) | O(α(n)) | Connected components, MST |
| Sparse Table | O(n log n) | O(1) | N/A (static) | Static RMQ (min/max) |
:::
