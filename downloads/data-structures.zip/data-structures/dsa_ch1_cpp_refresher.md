---
title: "C++ Refresher for Data Structures"
crumb: "Honors DSA · Chapter 1"
meta:
  - "Est. study time: ~90 min"
  - "Unit 0 — Foundations"
  - "CSE 2383 · MSState"
source: "markdown"
---

## Overview

Data structures are built *out of* C++ — the language isn't just a vehicle, it's the raw
 material. Before we can implement a linked list or a tree, we need a precise mental model of
 how C++ manages memory, how pointers actually work, and how classes let us package data with
 behavior. This chapter sharpens those fundamentals so nothing in the rest of the course surprises you.

If you have used C++ for a semester (CSE 1384), most of this will be review — but pay close
 attention to the memory-diagram sections and the `new`/`delete`
 mechanics. Misunderstanding those is the #1 source of bugs in data structure implementations.

:::callout-key[Prerequisites]
- Basic C++ syntax: variables, loops, `if`/`else`, functions
- Arrays and basic `struct` usage (CSE 1384 level)
- No prior knowledge of pointers or dynamic memory assumed
:::

## 1. Pointers & References

:::callout-intuition[Intuition]
Imagine every byte of your computer's RAM has a street address — a number like `0x7ffd2a10`.
 A **pointer** is a variable that stores one of those addresses. Instead of holding a value
 like `42`, it holds the *location* where `42` is stored.
 A **reference** is a friendlier alias — it acts like the original variable but is secretly
 implemented as a pointer. Data structures like linked lists are impossible without pointers,
 because a "link" from one node to the next is literally a pointer to the next node's address.
:::

:::definition[Definition 1.1 — Pointer]
A **pointer** is a variable whose value is the memory address of another variable.
 In C++, a pointer to type `T` is declared as `T*`.
 The **address-of operator** `&` yields the address of a variable.
 The **dereference operator** `*` yields the value at the address stored in a pointer.
:::

:::definition[Definition 1.2 — Reference]
A **reference** is an alias for an existing variable, declared as `T&`.
 Unlike a pointer, a reference cannot be null, cannot be reseated (reassigned to refer to a different variable),
 and does not need to be dereferenced to access the underlying value.
:::

### Pointer mechanics: the three operations

There are exactly three things you do with a pointer: declare it, assign it an address, and dereference it.

```cpp
int x = 42;

// 1. Declare a pointer-to-int
int* ptr;        // ptr holds garbage — dangerous! Always initialize.

// 2. Assign it the address of x
ptr = &x;        // Now ptr stores the address of x (e.g. 0x7ffd2a10)

// 3. Dereference: access the value at that address
std::cout << *ptr;   // prints 42

// Modifying through the pointer changes the original variable
*ptr = 100;
std::cout << x;      // prints 100 — x was changed via ptr
```

```
        Memory layout after the code above:

        0x7ffd2a10 │ 100    ← x  (changed by *ptr = 100)

        0x7ffd2a18 │ 0x7ffd2a10 ← ptr  (holds address of x)



        ptr ──────────────────────────────────► x

```

### References vs. pointers

```cpp
int a = 10;

// Reference — must be initialized at declaration, cannot be reseated
int& ref = a;
ref = 20;          // a is now 20; no dereference needed
// int& ref2;      // ERROR: references must be initialized

// Pointer — can be null, can be reseated
int b = 99;
int* p = &a;       // p points to a
p = &b;            // p now points to b — pointers CAN be reseated
p = nullptr;       // p points to nothing — safe sentinel value
```

| Feature | Pointer (`T*`) | Reference (`T&`) |
| --- | --- | --- |
| Can be null | Yes (`nullptr`) | No |
| Can be reseated | Yes | No |
| Needs dereference | Yes (`*p`) | No (`ref`) |
| Use in data structures | Yes — nodes use pointers | Rare — mainly function params |

:::callout-pitfall[Watch out for]
- **Uninitialized pointers** — `int* p;` holds garbage. Always initialize to `nullptr` or an address.
- **Dereferencing null or dangling pointers** — undefined behavior that causes crashes or silent data corruption.
- **Confusing `&` in declarations vs. expressions** — in `int& r = x` it means "reference"; in `p = &x` it means "address of."
- **Pointer arithmetic surprises** — `p + 1` advances by `sizeof(T)` bytes, not 1 byte.
:::

### Worked examples

:::example[Example 1.1 — Swap via pointers]
Write a function `swap(int* a, int* b)` that swaps the values of two integers using pointers. Then show it being called correctly.

::::answer[Answer]
Dereference both pointers; use a temporary variable to hold one value.
::::

Work

```cpp
void swap(int* a, int* b) {
    int temp = *a;   // save value at a's address
    *a = *b;         // write value-at-b into a's address
    *b = temp;       // write saved value into b's address
}

int main() {
    int x = 5, y = 10;
    swap(&x, &y);          // pass ADDRESSES, not values
    // x == 10, y == 5
}
```

The key insight: we pass `&x` (the address), not `x` (the value). The function then operates directly on the caller's memory through those addresses.
:::

:::example[Example 1.2 — Tracing pointer code]
What does the following code print? Trace it step by step.

```cpp
int arr[] = {10, 20, 30, 40};
int* p = arr;          // arr decays to a pointer to arr[0]
std::cout << *p << " ";
p++;
std::cout << *p << " ";
std::cout << *(p + 1) << "\n";
```

::::answer[Answer]
`10 20 30`
::::

Work

- `p = arr` → p points to `arr[0]`, which holds `10`. So `*p` = `10`.
- `p++` → p advances by `sizeof(int)` bytes, now pointing to `arr[1]`.
- `*p` = `arr[1]` = `20`.
- `*(p + 1)` → p is at `arr[1]`, so `p+1` is `arr[2]` = `30`. p itself is unchanged.
:::

:::example[Example 1.3 — Reference parameter vs. value parameter]
Explain why `increment(int x)` doesn't change the caller's variable, but `increment(int& x)` does.

::::answer[Answer]
Pass-by-value makes a copy; pass-by-reference aliases the caller's variable.
::::

Work

```cpp
void increment_val(int x)  { x++; }   // x is a COPY — caller unchanged
void increment_ref(int& x) { x++; }   // x IS the caller's variable

int main() {
    int n = 5;
    increment_val(n);  // n is still 5
    increment_ref(n);  // n is now 6
}
```

With `int x`, C++ creates a brand-new variable and copies `n`'s value into it. Any change to `x` in the function is invisible to the caller. With `int& x`, there is no copy — `x` is just another name for `n`. This matters enormously for data structure traversal functions.
:::

### Practice problems

:::problem[Problem 1.1 easy]{difficulty="easy"}
Declare an `int` variable `count = 7`. Declare a pointer `p` pointing to `count`. Using only `p`, print the value `7`, then change it to `99`. Write the three lines of code.

::::solution[Solution]
```cpp
int count = 7;
int* p = &count;
std::cout << *p;   // prints 7
*p = 99;           // count is now 99
```
::::
:::

:::problem[Problem 1.2 easy]{difficulty="easy"}
What is the output of this code? Explain each line.

```cpp
int x = 1, y = 2;
int* p = &x;
*p = 10;
p = &y;
*p = 20;
std::cout << x << " " << y;
```

::::solution[Solution]
**Output:** `10 20`

- `p = &x` — p points to x.
- `*p = 10` — x becomes 10.
- `p = &y` — pointer reseated; now p points to y.
- `*p = 20` — y becomes 20.
::::
:::

:::problem[Problem 1.3 standard]{difficulty="standard"}
Write a function `double* findMax(double* arr, int n)` that returns a *pointer to* the maximum element in an array of `n` doubles. Show how to call it and print the max value.

::::solution[Solution]
```cpp
double* findMax(double* arr, int n) {
    double* maxPtr = arr;
    for (int i = 1; i < n; i++) {
        if (arr[i] > *maxPtr) {
            maxPtr = &arr[i];
        }
    }
    return maxPtr;
}

int main() {
    double data[] = {3.1, 7.5, 2.0, 9.8, 1.1};
    double* m = findMax(data, 5);
    std::cout << "Max = " << *m;  // prints 9.8
}
```

`maxPtr` starts pointing at `arr[0]`. Each iteration we check if the current element beats the current max; if so, we update the pointer to point there instead. We return the pointer, not the value, which allows the caller to also modify the max element in-place if desired.
::::
:::

:::problem[Problem 1.4 standard]{difficulty="standard"}
Identify the bug in the code below and explain what would happen at runtime:

```cpp
int* makeInt() {
    int local = 42;
    return &local;      // returning address of local variable
}
int main() {
    int* p = makeInt();
    std::cout << *p;    // is this safe?
}
```

::::solution[Solution]
**Bug:** Returning the address of a local variable creates a *dangling pointer*.

When `makeInt()` returns, its stack frame is destroyed and `local` no longer exists. The address `p` now holds is for memory that has been released back to the stack. Reading `*p` is **undefined behavior** — it might print 42 (the value is still there by coincidence), it might print garbage, or it might crash. The fix is to use `new` (dynamic allocation) or return the value directly.
::::
:::

:::problem[Problem 1.5 challenge]{difficulty="challenge"}
A function receives `int** pp` (a pointer to a pointer). Write the function body of `void zeroOut(int** pp)` that sets the integer that `*pp` points to, to zero — without changing `pp` itself or the pointer stored in `*pp`.

::::solution[Solution]
```cpp
void zeroOut(int** pp) {
    **pp = 0;   // dereference twice: pp -> pointer -> int
}

int main() {
    int x = 99;
    int* p = &x;
    zeroOut(&p);        // pass address of the pointer
    std::cout << x;     // prints 0
}
```

`pp` is a pointer to `p`. `*pp` is `p` itself (the pointer to `x`). `**pp` is `x`. So `**pp = 0` sets `x = 0`. This double-pointer pattern appears frequently in linked list implementations where you need to modify the `head` pointer through a function.
::::
:::

## 2. Dynamic Memory: `new` and `delete`

:::callout-intuition[Intuition]
C++ gives you two pools of memory: the **stack** and the **heap**.
 The stack is fast and automatic — variables declared inside a function live there and vanish
 when the function returns. The heap is a larger, manually managed pool where memory persists
 until *you* explicitly free it. Every node in a linked list, every tree node, every
 dynamically-sized array — they all live on the heap. The operators `new` and
 `delete` are your controls for the heap.
:::

:::definition[Definition 2.1 — Stack vs. Heap]
The **stack** holds local variables and function call frames. It is managed
 automatically (LIFO). The **heap** (free store) holds memory allocated with
 `new`. Heap memory persists across function calls and must be released with
 `delete`. A memory **leak** occurs when heap memory is allocated
 but never freed.
:::

### Single object allocation

```cpp
// Allocate a single int on the heap
int* p = new int;       // allocates sizeof(int) bytes; p holds the address
*p = 42;                // store a value there
std::cout << *p;        // prints 42
delete p;               // release the memory back to the heap
p = nullptr;            // good practice: avoid dangling pointer
```

### Array allocation

```cpp
int n = 5;
int* arr = new int[n];  // allocate array of 5 ints on the heap

for (int i = 0; i < n; i++)
    arr[i] = i * 10;    // fill: 0, 10, 20, 30, 40

delete[] arr;           // MUST use delete[] for arrays, not delete
arr = nullptr;
```

```
        After  int* arr = new int[5]:

        Stack:

          0x7ffd0010 │ 0x20a3b400  ← arr (holds heap address)

        Heap:

          0x20a3b400 │ 0   ← arr[0]

          0x20a3b404 │ 10  ← arr[1]

          0x20a3b408 │ 20  ← arr[2]

          0x20a3b40c │ 30  ← arr[3]

          0x20a3b410 │ 40  ← arr[4]

```

:::callout-pitfall[Watch out for]
- **Memory leak** — forgetting `delete`. In a program running for minutes, this compounds quickly and exhausts RAM.
- **Double delete** — calling `delete` twice on the same pointer. Undefined behavior. Setting to `nullptr` after delete prevents this.
- **Mismatched delete** — using `delete` instead of `delete[]` for arrays. Only the first element is properly destroyed.
- **Using after delete** — the memory is freed but the pointer still holds the old address. Always set to `nullptr` after deleting.
:::

### Worked examples

:::example[Example 2.1 — A heap-allocated struct node]
Define a simple `Node` struct with an `int data` and a `Node* next`. Allocate two nodes on the heap, link them, and then properly free both.

::::answer[Answer]
Allocate with `new Node`, set fields, link via `next`, then `delete` in reverse order (or follow the chain).
::::

Work

```cpp
struct Node {
    int data;
    Node* next;
};

int main() {
    // Allocate first node
    Node* head = new Node;
    head->data = 10;
    head->next = nullptr;

    // Allocate second node and link it
    Node* second = new Node;
    second->data = 20;
    second->next = nullptr;
    head->next = second;   // head -> second -> nullptr

    // Traverse and print: 10 -> 20
    Node* cur = head;
    while (cur != nullptr) {
        std::cout << cur->data;
        if (cur->next) std::cout << " -> ";
        cur = cur->next;
    }

    // Free (follow the chain; don't lose the next before freeing head)
    delete second;
    delete head;
    head = second = nullptr;
}
```

Note: `head->data` is shorthand for `(*head).data`. The arrow operator dereferences the pointer and accesses the member in one step — you'll use it constantly for tree and list nodes.
:::

:::example[Example 2.2 — Spot the memory leak]
How many bytes are leaked in the following code? Explain and fix it.

```cpp
void process() {
    int* buf = new int[1000];
    // ... some computation ...
    if (someCondition) return;   // early return!
    delete[] buf;
}
```

::::answer[Answer]
`4000` bytes leaked (1000 ints × 4 bytes each) when `someCondition` is true.
::::

Work

The early `return` bypasses the `delete[]`. The heap memory for `buf` is never freed. Fix: delete before every exit path, or better — use RAII (`std::vector` or a smart pointer):

```cpp
// Fix 1: delete before early return
void process() {
    int* buf = new int[1000];
    if (someCondition) {
        delete[] buf;   // free before leaving
        return;
    }
    delete[] buf;
}

// Fix 2 (better): use std::vector — automatically freed on scope exit
#include <vector>
void process() {
    std::vector<int> buf(1000);   // heap-allocated, auto-freed
    if (someCondition) return;     // no leak!
}
```
:::

### Practice problems

:::problem[Problem 2.1 easy]{difficulty="easy"}
Write code that allocates a `double` on the heap, sets it to `3.14`, prints it, then frees it properly. Include the safety step after freeing.

::::solution[Solution]
```cpp
double* p = new double;
*p = 3.14;
std::cout << *p;
delete p;
p = nullptr;
```
::::
:::

:::problem[Problem 2.2 easy]{difficulty="easy"}
What is the bug? Fix it.

```cpp
int* arr = new int[10];
// ... fill and use arr ...
delete arr;
```

::::solution[Solution]
**Bug:** Using `delete` instead of `delete[]` for an array. This causes undefined behavior — only the first element's destructor is called properly.

**Fix:** `delete[] arr;`
::::
:::

:::problem[Problem 2.3 standard]{difficulty="standard"}
Write a function `int* makeArray(int n, int fillVal)` that allocates an array of `n` integers on the heap, fills each element with `fillVal`, and returns the pointer. Show how the caller should free it.

::::solution[Solution]
```cpp
int* makeArray(int n, int fillVal) {
    int* arr = new int[n];
    for (int i = 0; i < n; i++)
        arr[i] = fillVal;
    return arr;
}

int main() {
    int* data = makeArray(5, 7);  // [7, 7, 7, 7, 7]
    // ... use data ...
    delete[] data;    // caller is responsible for freeing
    data = nullptr;
}
```

Important design note: when a function returns a heap pointer, document clearly who is responsible for freeing it. This "ownership" question is exactly what C++11 smart pointers (`unique_ptr`) were designed to solve.
::::
:::

:::problem[Problem 2.4 standard]{difficulty="standard"}
Draw a memory diagram showing the stack and heap state after executing these lines:

```cpp
int x = 5;
int* p = new int(99);
int* q = p;
```

::::solution[Solution]
Two stack variables (`x` and `p` and `q`); one heap allocation:

```
              Stack:

                [x] │ 5

                [p] │ 0xHEAP  ──┐

                [q] │ 0xHEAP  ──┤



              Heap:

                0xHEAP │ 99  ← both p and q point here

```

`p` and `q` both hold the same address. Modifying `*q` also changes what `*p` sees. Calling `delete p` then `delete q` would be a double-delete bug.
::::
:::

:::problem[Problem 2.5 challenge]{difficulty="challenge"}
Write a function `int** makeMatrix(int rows, int cols)` that allocates a 2D matrix on the heap as an array of row pointers. Each row is itself a heap-allocated array. Write the corresponding `freeMatrix` function.

::::solution[Solution]
```cpp
int** makeMatrix(int rows, int cols) {
    int** mat = new int*[rows];        // array of row pointers
    for (int i = 0; i < rows; i++) {
        mat[i] = new int[cols]();      // allocate each row (zero-init)
    }
    return mat;
}

void freeMatrix(int** mat, int rows) {
    for (int i = 0; i < rows; i++) {
        delete[] mat[i];               // free each row first
    }
    delete[] mat;                      // then free the pointer array
}
```

Order matters: free the rows *before* freeing the pointer array. If you free the pointer array first, you lose the addresses of the rows and can never free them — a guaranteed leak.
::::
:::

## 3. Classes & Structs for Data Structures

:::callout-intuition[Intuition]
A data structure is data *plus* operations. A `struct` holds the data;
 a `class` bundles the data with the functions that operate on it.
 The difference in C++ is almost purely about default access: `struct` members are
 public by default, `class` members are private. For data structure nodes
 (like a linked-list node), a simple `struct` is conventional. For the
 data structure itself (the list, the tree), a `class` with a proper constructor
 and destructor is the right tool.
:::

:::definition[Definition 3.1 — Constructor & Destructor]
A **constructor** is a special member function that initializes an object when
 it is created. It has the same name as the class and no return type.
 A **destructor** is called automatically when an object is destroyed (goes out
 of scope, or is `delete`d). Its name is `~ClassName()`. For classes that
 own heap memory, the destructor is responsible for calling `delete` on that memory.
:::

### A minimal class anatomy

```cpp
class Stack {
private:
    int* data;      // heap-allocated array
    int  top;       // index of topmost element
    int  capacity;

public:
    // Constructor: runs when Stack s(10) is executed
    Stack(int cap) {
        capacity = cap;
        data = new int[capacity];
        top = -1;          // -1 means empty
    }

    // Destructor: runs when Stack goes out of scope or is deleted
    ~Stack() {
        delete[] data;     // prevent memory leak
    }

    bool isEmpty() const { return top == -1; }

    void push(int val) {
        if (top < capacity - 1)
            data[++top] = val;
    }

    int pop() {
        if (!isEmpty())
            return data[top--];
        return -1;  // error sentinel (a real impl would throw)
    }
};
```

### The rule of three

:::callout-warning[Important Rule]
If your class defines a **destructor**, you almost certainly also need to define
 a **copy constructor** and **copy assignment operator**. This is the
 *Rule of Three*. Without them, the default versions do a *shallow copy*:
 they copy the pointer value, not the pointed-to data. Two objects then share the same
 heap memory, and the first one to be destroyed leaves a dangling pointer in the other.
:::

```cpp
class Stack {
    // ... (same as above) ...

    // Copy constructor (deep copy)
    Stack(const Stack& other) {
        capacity = other.capacity;
        top = other.top;
        data = new int[capacity];          // allocate NEW memory
        for (int i = 0; i <= top; i++)
            data[i] = other.data[i];       // copy the elements
    }

    // Copy assignment operator
    Stack& operator=(const Stack& other) {
        if (this == &other) return *this;  // self-assignment guard
        delete[] data;                     // free old memory
        capacity = other.capacity;
        top = other.top;
        data = new int[capacity];
        for (int i = 0; i <= top; i++)
            data[i] = other.data[i];
        return *this;
    }
};
```

:::callout-pitfall[Watch out for]
- **Forgetting the destructor** — if your class owns heap memory, always write a destructor that frees it.
- **Shallow copy disaster** — the default copy constructor just copies pointer values. Two stacks then point to the same data array; the second `delete[]` is undefined behavior.
- **Missing the self-assignment guard** in `operator=` — if you write `s = s`, you'd `delete[]` the data before copying it.
- **Accessing private members from outside** — use getters/setters or `friend` declarations; don't make data members `public` just to avoid writing accessors.
:::

### Worked examples

:::example[Example 3.1 — Writing a simple Node struct]
Define a `Node` struct suitable for a singly-linked list of integers. Give it a constructor for convenience.

::::answer[Answer]
A minimal `Node` needs `data` and `next`, plus a constructor to initialize both.
::::

Work

```cpp
struct Node {
    int   data;
    Node* next;

    // Constructor: Node n(42) creates a node with data=42, next=nullptr
    Node(int val) : data(val), next(nullptr) {}
    //              ^^^^^^^^^^^^^^^^^^^^^^^ initializer list — preferred
};

// Usage:
Node* head = new Node(10);
head->next = new Node(20);
head->next->next = new Node(30);
// List: 10 -> 20 -> 30 -> nullptr
```

The **initializer list** syntax (`: data(val), next(nullptr)`) initializes members before the constructor body runs. It is more efficient than assignment inside the body and is required for `const` members and references.
:::

:::example[Example 3.2 — const member functions]
What does the `const` keyword mean when placed after a member function's parameter list? Why does it matter?

::::answer[Answer]
It means the function promises not to modify any member variables. It allows the function to be called on `const` objects.
::::

Work

```cpp
class Stack {
public:
    bool isEmpty() const { return top == -1; }  // const: read-only
    void push(int val)   { data[++top] = val; } // non-const: modifies
};

void printStatus(const Stack& s) {
    // s is const — only const member functions can be called here
    std::cout << s.isEmpty();   // OK: isEmpty is const
    // s.push(1);               // ERROR: push is not const
}
```

Mark every function that doesn't modify state as `const`. This is not just style — it determines what can be called when you have a `const` reference or pointer to an object.
:::

### Practice problems

:::problem[Problem 3.1 easy]{difficulty="easy"}
What is the one-word difference between a `struct` and a `class` in C++?

::::solution[Solution]
**Access.** In a `struct`, members are `public` by default. In a `class`, members are `private` by default. Otherwise, they are identical in C++.
::::
:::

:::problem[Problem 3.2 easy]{difficulty="easy"}
Add a constructor to this struct so that `Point p(3, 4);` initializes `x = 3` and `y = 4`. Use an initializer list.

```cpp
struct Point {
    double x, y;
    // your constructor here
};
```

::::solution[Solution]
```cpp
struct Point {
    double x, y;
    Point(double px, double py) : x(px), y(py) {}
};
```
::::
:::

:::problem[Problem 3.3 standard]{difficulty="standard"}
Explain why the following code causes undefined behavior. Then fix it by adding the missing special member function.

```cpp
class Buffer {
    int* data;
    int  size;
public:
    Buffer(int n) : size(n), data(new int[n]) {}
    ~Buffer() { delete[] data; }
};

int main() {
    Buffer a(100);
    Buffer b = a;   // copies a into b
}   // both destructors run — double delete!
```

::::solution[Solution]
The default copy constructor copies the pointer `data` itself (shallow copy). Now both `a` and `b` hold the same address. When both destructors run, `delete[]` is called twice on the same memory — undefined behavior.

**Fix: add a deep-copy constructor:**

```cpp
Buffer(const Buffer& other) : size(other.size) {
    data = new int[size];                       // NEW allocation
    for (int i = 0; i < size; i++)
        data[i] = other.data[i];               // copy contents
}
```
::::
:::

:::problem[Problem 3.4 standard]{difficulty="standard"}
Design a `class Counter` with a private `int count` initialized to 0, a method `increment()`, a method `reset()`, and a `const` method `getValue()`. Write the full class.

::::solution[Solution]
```cpp
class Counter {
private:
    int count;
public:
    Counter() : count(0) {}
    void increment()    { count++; }
    void reset()        { count = 0; }
    int  getValue() const { return count; }
};
```
::::
:::

:::problem[Problem 3.5 challenge]{difficulty="challenge"}
Write a `class DynArray` that wraps a heap-allocated integer array with a given capacity. Implement: constructor, destructor, copy constructor, `operator[]` for element access, and `size()`. Make sure it has no memory leaks or double-deletes.

::::solution[Solution]
```cpp
class DynArray {
private:
    int* data;
    int  cap;
public:
    DynArray(int n) : cap(n), data(new int[n]()) {}  // zero-init

    ~DynArray() { delete[] data; }

    DynArray(const DynArray& o) : cap(o.cap), data(new int[o.cap]) {
        for (int i = 0; i < cap; i++) data[i] = o.data[i];
    }

    DynArray& operator=(const DynArray& o) {
        if (this == &o) return *this;
        delete[] data;
        cap = o.cap;
        data = new int[cap];
        for (int i = 0; i < cap; i++) data[i] = o.data[i];
        return *this;
    }

    int&       operator[](int i)       { return data[i]; }
    const int& operator[](int i) const { return data[i]; }
    int        size() const            { return cap; }
};
```
::::
:::

## 4. Templates: Generic Data Structures

:::callout-intuition[Intuition]
Imagine writing a `Stack` class for integers, then realizing you also need one for
 `double`, then one for `std::string`. The logic is identical — only the
 type changes. **Templates** let you write the logic once and parameterize the type.
 The compiler generates the specific version you need. This is how the C++ Standard Library's
 containers (`std::vector`, `std::stack`) work — they're templates.
 Your own data structures should be too.
:::

### Function templates

```cpp
// A generic max function — works for any type that supports '>'
template <typename T>
T maxOf(T a, T b) {
    return (a > b) ? a : b;
}

// The compiler generates the right version automatically:
maxOf(3, 5);         // T = int
maxOf(2.7, 1.1);     // T = double
maxOf('z', 'a');     // T = char
```

### Class templates

```cpp
template <typename T>
class Stack {
private:
    T*  data;
    int top;
    int capacity;
public:
    Stack(int cap) : capacity(cap), top(-1), data(new T[cap]) {}
    ~Stack() { delete[] data; }

    void push(const T& val) {
        if (top < capacity - 1)
            data[++top] = val;
    }

    T pop() {
        return data[top--];
    }

    bool isEmpty() const { return top == -1; }
};

// Usage — specify the type in angle brackets:
Stack<int>         intStack(50);
Stack<std::string> strStack(20);

intStack.push(42);
strStack.push("hello");
```

:::callout-tip[Tip]
Template definitions must typically be in the *header file* (or visible at the point of use),
 not in a separate `.cpp` file. This is because the compiler needs to see the full
 template definition to instantiate it for a specific type. Keeping everything in a
 `.h` or `.hpp` file is the safest approach.
:::

:::callout-pitfall[Watch out for]
- **Cryptic compiler errors** — template errors often produce walls of text. Read the first error; ignore the rest until the first is fixed.
- **Splitting template definition across .h and .cpp** — usually causes linker errors.
- **Type requirements** — if your template uses `>`, the type `T` must support that operator. This is implicit; you'll get an error at instantiation, not at the template definition.
:::

### Practice problems

:::problem[Problem 4.1 easy]{difficulty="easy"}
Write a function template `swap` that swaps two values of any type using a temporary variable.

::::solution[Solution]
```cpp
template <typename T>
void swap(T& a, T& b) {
    T temp = a;
    a = b;
    b = temp;
}
```
::::
:::

:::problem[Problem 4.2 standard]{difficulty="standard"}
Convert the following `int`-only `Pair` struct into a class template that works with any two types (possibly different).

```cpp
struct Pair {
    int first;
    int second;
    Pair(int a, int b) : first(a), second(b) {}
};
```

::::solution[Solution]
```cpp
template <typename T1, typename T2>
struct Pair {
    T1 first;
    T2 second;
    Pair(const T1& a, const T2& b) : first(a), second(b) {}
};

// Usage:
Pair<int, std::string> p(1, "one");
Pair<double, double>   q(3.14, 2.72);
```
::::
:::

:::problem[Problem 4.3 challenge]{difficulty="challenge"}
Write a template function `linearSearch` that takes an array of type `T`, its size, and a target value, and returns the index of the first match (or `-1` if not found). It should work for any type that supports `==`.

::::solution[Solution]
```cpp
template <typename T>
int linearSearch(const T* arr, int n, const T& target) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) return i;
    }
    return -1;
}

// Works for any type:
int nums[] = {3, 1, 4, 1, 5};
std::cout << linearSearch(nums, 5, 4);         // prints 2

std::string words[] = {"cat", "dog", "bird"};
std::cout << linearSearch(words, 3, std::string("dog")); // prints 1
```
::::
:::

## 5. The Standard Library at a Glance

:::callout-intuition[Intuition]
The C++ Standard Library ships with ready-made implementations of all the data structures
 you're about to learn to build from scratch. You might wonder: why build them yourself?
 Because you cannot use what you don't understand, you cannot debug what you don't know
 the internals of, and interviews ask you to implement these from scratch.
 In CSE 2383, you'll build the structures yourself. In production code, you'll use the STL.
 Knowing both is the goal.
:::

### Containers you'll encounter this semester

| STL Container | Underlying structure | Key operations | Chapter we build it |
| --- | --- | --- | --- |
| `std::vector<T>` | Dynamic array | `push_back`, `[]`, `size` | Ch 4 |
| `std::list<T>` | Doubly-linked list | `push_front`, `push_back`, iterators | Ch 4 |
| `std::stack<T>` | Deque/vector adapter | `push`, `pop`, `top` | Ch 5 |
| `std::queue<T>` | Deque adapter | `push`, `pop`, `front` | Ch 6 |
| `std::priority_queue<T>` | Heap | `push`, `pop`, `top` | Ch 10 |
| `std::set<T>` | Red-black tree | `insert`, `find`, `erase` | Ch 9 |
| `std::unordered_map<K,V>` | Hash table | `[]`, `find`, `insert` | Ch 15 |

### Quick vector recap

```cpp
#include <vector>
#include <algorithm>  // for sort, find, etc.

std::vector<int> v;
v.push_back(10);
v.push_back(20);
v.push_back(30);

// Range-based for loop (C++11 and later)
for (int x : v) std::cout << x << " ";   // 10 20 30

// Access by index (no bounds checking)
v[0] = 99;

// Sort using the standard algorithm
std::sort(v.begin(), v.end());            // modifies v in-place

std::cout << v.size();   // number of elements
v.clear();               // remove all elements (size -> 0)
```

### Practice problems

:::problem[Problem 5.1 easy]{difficulty="easy"}
Using `std::vector`, write code that reads 5 integers from the user and prints them in reverse order.

::::solution[Solution]
```cpp
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v(5);
    for (int i = 0; i < 5; i++) std::cin >> v[i];
    for (int i = 4; i >= 0; i--) std::cout << v[i] << " ";
}
```
::::
:::

:::problem[Problem 5.2 standard]{difficulty="standard"}
Using `std::stack`, write a function `bool isBalanced(std::string s)` that returns `true` if the parentheses (only `(` and `)`) in `s` are balanced.

::::solution[Solution]
```cpp
#include <stack>
#include <string>

bool isBalanced(std::string s) {
    std::stack<char> stk;
    for (char c : s) {
        if (c == '(') stk.push(c);
        else if (c == ')') {
            if (stk.empty()) return false;  // unmatched ')'
            stk.pop();
        }
    }
    return stk.empty();  // true only if all '(' were matched
}
```

Test: `isBalanced("(())")` → true. `isBalanced("(()")` → false (one unmatched '(').
::::
:::

:::problem[Problem 5.3 standard]{difficulty="standard"}
What is the difference between `v.size()` and `v.capacity()` for a `std::vector`?

::::solution[Solution]
`size()` is the number of elements currently stored. `capacity()` is how many elements the underlying array can hold before a reallocation is needed. A vector typically doubles its capacity when it runs out of space — this amortized doubling strategy is why `push_back` is O(1) amortized.
::::
:::

## Writing Correct C++ by Hand

On a computer, the compiler points to a missing semicolon or brace. On paper, that safety net is
gone. The goal of this section is not to memorize one program. It is to understand the small set
of parts from which you can build a complete program: include the library features you use,
declare names before using them, put executable work in `main`, and close every statement and
block correctly.

### The skeleton of every program

Here is a minimal complete program:

```cpp
#include <iostream>

using namespace std;

int main()
{
    return 0;
}
```

Read it word by word:

- `#include <iostream>` is a **preprocessor directive**. Before compilation, the preprocessor
  makes the declarations from the standard `iostream` header available to this source file.
  `include` tells it what to include. The angle brackets tell it to look in the compiler's
  configured system-header locations; double quotes are normally used for a header from your own
  project. A preprocessor directive ends at the newline, so there is **no semicolon**. In this
  empty program, removing the line would not yet cause an error, but any use of `cin`, `cout`, or
  `endl` would then lack the header that supplies it.
- `using namespace std;` makes names from the standard-library namespace available without the
  `std::` prefix. A namespace is a named region that keeps one library's names from colliding with
  another library's names. With this line, you can write `cout`; without it, write `std::cout`.
  This is a C++ declaration rather than a preprocessor directive, so its semicolon **is required**.
- `int main()` defines the program's entry point. Execution starts by calling `main`. The `int`
  says that `main` returns an integer status code to the operating system. The empty parentheses
  mean this version receives no command-line arguments.
- `{` begins the body of `main`, and the matching `}` ends it. Removing either brace makes the
  compiler unable to determine the boundaries of the function.
- `return 0;` ends `main` and reports success to the operating system. A nonzero status normally
  reports failure. Reaching the end of `main` implicitly returns zero in modern C++, but writing
  the statement makes the result explicit and gives you a dependable paper-exam pattern. The
  semicolon terminates the return statement.

### Output with cout

This complete program prints a numeric answer alongside explanatory text:

```cpp
#include <iostream>

using namespace std;

int main()
{
    double celsius = 20.0;
    cout << "The temperature is " << celsius << " degrees Celsius." << endl;
    return 0;
}
```

In `cout << "text" << value << endl;`, each token has a job:

- `cout` is the standard output stream. Characters inserted into it normally appear in the
  terminal.
- `<<` is the **stream insertion operator**: it inserts the value on its right into the stream on
  its left. Its arrows point toward `cout`, matching the direction in which data moves.
- Double quotes create a **string literal**, so `"The temperature is "` is text, not a variable
  name.
- The operations chain from left to right. After inserting the first string, the expression still
  refers to the same output stream, so the next `<<` can insert `celsius`, then more text, then the
  line ending.
- `endl` inserts a newline and flushes the output buffer immediately. `"\n"` also inserts a
  newline but does not force a flush, so it is often faster for ordinary output. On an exam,
  either is correct when only a new line is required.
- The final semicolon ends the complete output statement.

The output is:

```text
The temperature is 20 degrees Celsius.
```

The spaces inside the string literals matter. Without the space after `is`, the program would
print `is20` because insertion does not invent spacing.

### Input with cin

`cin` is the standard input stream. This program reads one integer, then two more integers, then a
whole line of text:

```cpp
#include <iostream>
#include <limits>
#include <string>

using namespace std;

int main()
{
    int x;
    int a;
    int b;
    string fullName;

    cout << "Enter one integer: ";
    cin >> x;

    cout << "Enter two integers: ";
    cin >> a >> b;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter your full name: ";
    getline(cin, fullName);

    cout << fullName << " entered " << x << ", " << a << ", and " << b << endl;
    return 0;
}
```

In `cin >> x;`, `cin` is the source, `>>` is the **stream extraction operator**, and `x` is the
destination. The arrows point away from `cin`, again matching the direction of the data. The
variable must already be declared so the compiler knows its type and where to store the result.
Formatted extraction skips leading whitespace. Reading a `string` with `>>` stops at the next
whitespace; reading a number stops at the first character that cannot be part of that number.

The expression `cin >> a >> b;` chains left to right: read into `a`, then use the same stream to
read into `b`. The user may separate the values with spaces or newlines because both count as
whitespace.

There is one common trap when `cin >>` is followed by `getline`. Extraction leaves the delimiter
after the last token in the input stream. Usually that delimiter is the newline produced when the
user pressed Enter. An immediate `getline` would consume that newline and return an empty string.
If exactly one newline is waiting, `cin.ignore();` discards it. The longer call in the program is
safer: it discards everything through the next newline. It needs `<limits>` for
`numeric_limits<streamsize>::max()` and `<string>` for `string` and `getline`.

### Types, declarations and arithmetic you need

A declaration gives a name a type before the program uses it. These are the basic types you will
need most often:

- `int` stores whole numbers such as `-4`, `0`, and `27`.
- `double` stores numbers with a fractional part, such as `98.6`.
- `bool` stores exactly `true` or `false`.
- `char` stores one character in single quotes, such as `'F'`.
- `string` stores text in double quotes and requires `#include <string>`.

This complete program declares each type and computes Fahrenheit-to-Celsius conversion correctly
in two equivalent ways:

```cpp
#include <iostream>
#include <string>

using namespace std;

int main()
{
    int readingNumber = 1;
    double fahrenheit = 68.0;
    bool isFreezing = false;
    char scale = 'C';
    string label = "Room temperature";

    double wrongFactor = 5 / 9;
    double celsiusFirst = (5.0 / 9.0) * (fahrenheit - 32.0);
    double celsiusSecond = (fahrenheit - 32.0) * 5.0 / 9.0;

    cout << label << " reading " << readingNumber << ": "
         << celsiusFirst << scale << endl;
    cout << "The second formula gives " << celsiusSecond << scale << endl;
    cout << "The integer-division factor is " << wrongFactor << endl;
    cout << "Freezing? " << isFreezing << endl;
    return 0;
}
```

Integer division is the most common arithmetic error in a handwritten conversion program. Both
operands in `5 / 9` are integers, so C++ performs integer division and discards the fractional
part. The result is `0`, even when it is assigned to a `double` afterward. Multiplying by that
zero makes almost every conversion answer zero.

In `(5.0 / 9.0) * (fahrenheit - 32.0)`, the decimal points make the division floating-point
division. In `(fahrenheit - 32.0) * 5.0 / 9.0`, the first operation already involves a `double`,
and the later operations remain floating point. Both forms compute the same formula. The
parentheses around `fahrenheit - 32.0` are essential because the subtraction must happen before
the multiplication.

### Choosing and repeating

Branches choose which statements run; loops repeat statements. This program contains the four
forms you should be able to reproduce:

```cpp
#include <iostream>

using namespace std;

int main()
{
    int temperature = 75;

    if (temperature < 32)
    {
        cout << "Freezing" << endl;
    }
    else if (temperature < 80)
    {
        cout << "Moderate" << endl;
    }
    else
    {
        cout << "Hot" << endl;
    }

    int count = 0;
    while (count < 3)
    {
        cout << count << endl;
        count++;
    }

    for (int i = 0; i < 3; i++)
    {
        cout << i << endl;
    }

    int choice = 2;
    switch (choice)
    {
        case 1:
            cout << "First choice" << endl;
            break;
        case 2:
            cout << "Second choice" << endl;
            break;
        default:
            cout << "Unknown choice" << endl;
            break;
    }

    return 0;
}
```

An `if` tests its parenthesized condition. If it is true, that block runs and the rest of the
chain is skipped. Each `else if` offers another condition; the final `else` needs no condition
because it handles everything remaining. A `while` tests before every repetition, so its body may
run zero times. A `for` places initialization, condition, and update inside one pair of
parentheses: initialize `i` once, keep looping while `i < 3`, and run `i++` after each body.

A `switch` is especially useful for an integer menu:

- `switch (choice)` requires parentheses around the controlling expression. C++ compares that
  value with the case labels.
- `case 1:` uses a colon, not a comma or semicolon. The label means execution can begin there when
  the controlling value is `1`.
- `break;` exits the switch. Without it, execution **falls through** into the statements under the
  next case, even when that next label does not match.
- `default:` handles every value not named by a case. It also ends with a colon. A final `break;`
  is not strictly necessary at the bottom, but including it makes every case follow the same safe
  pattern.

### A complete menu-driven program

The following program displays a menu, reads a choice, performs a temperature conversion, and
keeps returning to the menu until the user chooses zero:

```cpp
#include <iostream>

using namespace std;

int main()
{
    int choice = -1;

    while (choice != 0)
    {
        cout << endl;
        cout << "Temperature Conversion" << endl;
        cout << "1. Fahrenheit to Celsius" << endl;
        cout << "2. Celsius to Fahrenheit" << endl;
        cout << "0. Quit" << endl;
        cout << "Choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
            {
                double fahrenheit;
                cout << "Enter degrees Fahrenheit: ";
                cin >> fahrenheit;
                double celsius = (fahrenheit - 32.0) * 5.0 / 9.0;
                cout << fahrenheit << " F = " << celsius << " C" << endl;
                break;
            }
            case 2:
            {
                double celsius;
                cout << "Enter degrees Celsius: ";
                cin >> celsius;
                double fahrenheit = celsius * 9.0 / 5.0 + 32.0;
                cout << celsius << " C = " << fahrenheit << " F" << endl;
                break;
            }
            case 0:
                cout << "Goodbye." << endl;
                break;
            default:
                cout << "Please enter 0, 1, or 2." << endl;
                break;
        }
    }

    return 0;
}
```

Read the program line by line:

- `#include <iostream>` supplies the input and output streams; without it, `cin`, `cout`, and
  `endl` are unavailable.
- `using namespace std;` permits those three names without `std::` in front of each one.
- `int main()` and its outer braces define the complete entry point. Every executable statement
  in this program is inside that function.
- `int choice = -1;` both declares the menu choice and initializes it to a value other than zero.
  If it started at zero, the loop would never display the menu.
- `while (choice != 0)` is the repeat-until-quit rule. Its braces contain one complete menu
  interaction.
- The six `cout` statements create a blank line, print the title and three choices, and then print
  the prompt. The prompt has no `endl`, so the user's input can appear on the same line.
- `cin >> choice;` stores the user's integer in the variable that controls both the switch and the
  next loop test. Without this update, the loop would keep using `-1` forever.
- `switch (choice)` dispatches to exactly the case whose label matches the entered number, unless
  a missing `break` allows fall-through.
- `case 1:` selects Fahrenheit-to-Celsius conversion. The extra braces give this case its own
  scope, so its local variables cannot conflict with variables declared in another case.
- `double fahrenheit;` creates storage for fractional input; the next `cout` asks for it, and
  `cin >> fahrenheit;` fills it.
- `double celsius = (fahrenheit - 32.0) * 5.0 / 9.0;` performs the conversion with floating-point
  arithmetic. Removing the parentheses changes the formula.
- The next `cout` combines the original value, unit labels, and result. Its `endl` finishes the
  output line.
- The first `break;` leaves the switch. Without it, execution would continue into case 2.
- `case 2:` follows the same sequence in the other direction: declare, prompt, read, compute,
  print, and break. The formula multiplies before adding 32, as the conversion requires.
- `case 0:` prints a farewell and breaks. Control reaches the bottom of the loop, where the
  condition sees zero and stops the next repetition.
- `default:` catches every choice other than 0, 1, or 2. Its message explains the valid inputs,
  and its `break;` exits the switch so the loop can show the menu again.
- The closing braces end the switch, loop, and function in reverse order. `return 0;` reports
  normal completion after the loop ends.

This is a reusable menu pattern: **loop, print, read, dispatch, repeat**. For a different menu
problem, keep that structure and replace the option text and case bodies. Understanding the
control flow is more reliable than memorizing the temperature formulas as part of the menu.

### Functions

A **declaration** tells the compiler a function's name, return type, and parameter types before a
call. A **definition** supplies the body that runs. This program declares two functions, calls
them, and defines them later:

```cpp
#include <iostream>

using namespace std;

void addOneByValue(int number);
void addOneByReference(int &number);

int main()
{
    int value = 10;

    cout << "Before either call: " << value << endl;
    addOneByValue(value);
    cout << "After pass-by-value: " << value << endl;
    addOneByReference(value);
    cout << "After pass-by-reference: " << value << endl;

    return 0;
}

void addOneByValue(int number)
{
    number++;
}

void addOneByReference(int &number)
{
    number++;
}
```

The two prototype lines end in semicolons because they are declarations without bodies. `void` is
the return type and means the function returns no value. Each parenthesized parameter gives the
function a local name through which it receives an argument. The later definitions repeat the
same signatures and add brace-delimited bodies.

`addOneByValue` receives a copy. Its `number` becomes 11, but that local copy disappears when the
function returns. `addOneByReference` receives an alias because of `&`; its `number` is the
caller's `value`, so incrementing it changes the caller's variable. The program's trace is:

```text
Before either call: 10
After pass-by-value: 10
After pass-by-reference: 11
```

This is why the course writes `peek(int &data)`: the `bool` return value can report whether the
stack was empty, while the reference parameter can carry the top value back to the caller. See
[Chapter 5's Course Implementation section](dsa_ch5_stacks.md#the-course-implementation) for the
method in its stack context. Without `&`, assigning to `data` would change only a disposable
copy.

### A complete class

A class joins data with the operations that maintain it. This complete program defines a
`Temperature` class, defines each method outside the class, and uses an object in `main`:

```cpp
#include <iostream>

using namespace std;

class Temperature
{
private:
    double fahrenheit;

public:
    Temperature(double value);
    void setFahrenheit(double value);
    double getFahrenheit() const;
    double toCelsius() const;
};

Temperature::Temperature(double value)
    : fahrenheit(value)
{
}

void Temperature::setFahrenheit(double value)
{
    fahrenheit = value;
}

double Temperature::getFahrenheit() const
{
    return fahrenheit;
}

double Temperature::toCelsius() const
{
    return (fahrenheit - 32.0) * 5.0 / 9.0;
}

int main()
{
    Temperature reading(68.0);
    cout << reading.getFahrenheit() << " F = "
         << reading.toCelsius() << " C" << endl;

    reading.setFahrenheit(32.0);
    cout << reading.getFahrenheit() << " F = "
         << reading.toCelsius() << " C" << endl;

    return 0;
}
```

Read the class line by line:

- `class Temperature` introduces a new type, and the following braces contain its members.
- `private:` makes the lines below it accessible only through the class's methods. That prevents
  outside code from changing `fahrenheit` without going through the class interface.
- `double fahrenheit;` is the private data stored separately in every `Temperature` object.
- `public:` begins the interface that outside code may call.
- `Temperature(double value);` declares a constructor. It has the class name and no return type
  because its job is to initialize a new object, not return a separate value.
- The next three lines declare a setter, getter, and conversion method. The setter returns
  `void`; the other two return `double`. The trailing `const` promises that those methods do not
  modify the object.
- `};` closes the class **and includes a required semicolon**. A bare `}` is not enough for a class
  definition.
- `Temperature::Temperature` names the constructor belonging to `Temperature`. The `::` is the
  scope-resolution operator; the same `ClassName::method` form appears on every out-of-class
  method definition.
- `: fahrenheit(value)` is the constructor's member initializer list. It initializes the data
  member directly from the parameter before the constructor body begins. Removing it would leave
  this built-in `double` without a useful initialized value because the body is empty.
- `Temperature::setFahrenheit` assigns the parameter to the object's data member. The getter
  returns that member, and `toCelsius` returns a computed value without changing the member.
- In `main`, `Temperature reading(68.0);` calls the constructor. The dot operator calls methods on
  the object. The later setter changes its stored value, proving that subsequent getter and
  conversion calls use the new temperature.

### A dynamic list of values

When the size is known only while the program runs, `new[]` can allocate an array on the heap.
This complete program stores and prints three integer temperatures:

```cpp
#include <iostream>

using namespace std;

int main()
{
    int n = 3;
    int *arr = new int[n];

    arr[0] = 72;
    arr[1] = 68;
    arr[2] = 75;

    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << endl;
    }

    delete[] arr;
    arr = nullptr;
    return 0;
}
```

`int *arr` declares a pointer to `int`. `new int[n]` creates a block large enough for `n`
consecutive integers and returns the address of the first one. Indexing with `arr[i]` reaches the
element at index `i`, and valid indexes run from `0` through `n - 1`.

The allocation used `new[]`, so the release must use `delete[] arr;`. Plain `delete` is only for a
single object created by plain `new`. Mixing the forms causes undefined behavior: the program may
appear to work, leak memory, crash, or corrupt the allocator. After release, assigning `nullptr`
prevents the pointer from continuing to look like a usable address.

A raw array cannot enlarge itself. When it fills, allocate a larger block, copy the existing
values, release the old block, and repoint the owning pointer:

```cpp
#include <iostream>

using namespace std;

int main()
{
    int capacity = 3;
    int count = 3;
    int *arr = new int[capacity];

    arr[0] = 72;
    arr[1] = 68;
    arr[2] = 75;

    if (count == capacity)
    {
        int newCapacity = capacity * 2;
        int *bigger = new int[newCapacity];

        for (int i = 0; i < count; i++)
        {
            bigger[i] = arr[i];
        }

        delete[] arr;
        arr = bigger;
        capacity = newCapacity;
    }

    arr[count] = 80;
    count++;

    for (int i = 0; i < count; i++)
    {
        cout << arr[i] << endl;
    }

    delete[] arr;
    arr = nullptr;
    return 0;
}
```

`count` records how many elements contain values; `capacity` records how many fit. Equality means
there is no valid open index, so the program doubles the capacity. The copy loop must run while
both arrays still exist. Only after every live element has been copied can `delete[] arr` release
the old storage. `arr = bigger;` then makes the original owning pointer refer to the new block, and
the final `delete[]` releases that block when the program is done.

Growing costs $O(n)$ because all `n` stored values must be copied. A linked list avoids moving the
existing values by allocating each new node separately and connecting it with a pointer. That
tradeoff is the motivation for [Chapter 4's singly linked lists](dsa_ch4_linked_lists.md#1-singly-linked-lists).

### Syntax that fails on paper

After writing an answer, use this as a compiler-free final pass. Read once for the algorithm, then
once only for punctuation and types:

- **Semicolon after a class definition:** wrong: `class Temperature { }` Right:
  `class Temperature { };` The class's closing brace does not terminate the declaration by itself.
- **Semicolon after a statement:** wrong: `total = total + value` Right:
  `total = total + value;` Statements such as declarations, assignments, calls, `break`, and
  `return` need semicolons.
- **Assignment versus comparison:** wrong in a condition: `if (choice = 1)` Right:
  `if (choice == 1)` A single equals sign stores `1` in `choice`; two equals signs ask whether the
  values are equal.
- **Matched braces:** wrong: `if (ready) { cout << "go";` Right:
  `if (ready) { cout << "go"; }` Pair each closing brace with the most recent unmatched opening
  brace, and check the class, every function, every branch, every loop, and the switch.
- **Arrow versus dot:** wrong for a pointer: `ptr.getValue()` Right: `ptr->getValue()` Use `.` with
  an object and `->` with a pointer to an object.
- **Reference marker:** wrong when the caller must receive the changed value: `bool peek(int data)`
  Right: `bool peek(int &data)` Without `&`, the function receives a copy.
- **Array deletion:** wrong after `new int[n]`: `delete arr;` Right: `delete[] arr;` The allocation
  and release forms must match.
- **The required header:** wrong: using `cout` with no `<iostream>` inclusion. Right: write
  `#include <iostream>` before the program and then use either `std::cout` or a valid
  `using namespace std;` declaration.
- **The end of `main`:** incomplete exam pattern: ending the function immediately after the last
  task. Right: finish with `return 0;` and then the closing brace. C++ does implicitly return zero
  from `main`, but the explicit line shows the operating-system result and removes doubt about
  whether you simply forgot the return statement.

Finally, check that every name is declared before use, every opening parenthesis and brace has a
match, every string uses double quotes, every `char` uses single quotes, and every case label ends
with a colon. That last mechanical pass is part of solving a handwritten programming problem.

:::summary
## Chapter Summary

### Key concepts at a glance

| Concept | One-liner |
| --- | --- |
| Pointer `T*` | Stores a memory address; dereference with `*` to get the value |
| Reference `T&` | Alias for an existing variable; no dereference needed; cannot be null |
| `new` / `delete` | Allocate / free heap memory; always match them; use `delete[]` for arrays |
| Constructor | Initializes an object on creation; use initializer lists |
| Destructor | Cleans up (especially heap memory) when object is destroyed |
| Rule of Three | If you write a destructor, also write copy constructor + copy assignment |
| Template `template <typename T>` | Parameterize a class or function by type; compiler generates the specific version |
| Stack memory | Automatic; destroyed when the function returns |
| Heap memory | Manual; persists until `delete` is called; all DS nodes live here |
| `nullptr` | Null pointer value; always set freed/unused pointers to this |

### If you remember nothing else

Every node in every data structure you build this semester lives on the heap, reached through a pointer. Get comfortable with `new`, `delete`, `->`, and `nullptr` — they will appear on every line of every implementation.

::::callout-connect[Connection to the rest of the course]
Chapter 2 dives deeper into memory — the stack, heap, and how your program is actually laid out in RAM. Chapters 4–6 will use everything here: you'll write `struct Node`, allocate with `new`, and link nodes with `next` pointers constantly. Templates show up when we make our structures generic.
::::
:::

## Mixed Practice

These problems draw on multiple topics from this chapter. Work through them without looking at your notes first.

:::problem[Problem M.1 easy]{difficulty="easy"}
What prints? `int x = 5; int* p = &x; std::cout << p == &x;`

::::solution[Solution]
**1** (true). `p == &x` compares two pointers — both hold the address of `x`, so they're equal. Note: operator precedence means this is actually parsed as `(std::cout << p) == &x` which prints the address and then compares the stream to the pointer — a subtle pitfall. Use parentheses: `std::cout << (p == &x);`
::::
:::

:::problem[Problem M.2 standard]{difficulty="standard"}
Write a template class `MinStack<T>` that supports `push`, `pop`, `top`, and `getMin` — where `getMin` returns the minimum element in O(1) time. Hint: maintain a second stack tracking the running minimum.

::::solution[Solution]
```cpp
template <typename T>
class MinStack {
    std::stack<T> main_stk;
    std::stack<T> min_stk;
public:
    void push(const T& val) {
        main_stk.push(val);
        if (min_stk.empty() || val <= min_stk.top())
            min_stk.push(val);
    }
    void pop() {
        if (main_stk.top() == min_stk.top())
            min_stk.pop();
        main_stk.pop();
    }
    T    top()    const { return main_stk.top(); }
    T    getMin() const { return min_stk.top();  }
    bool empty()  const { return main_stk.empty(); }
};
```

The min stack keeps track of the minimum at each point in history. When we pop the main stack, we only pop the min stack if the element being removed was the current minimum. This guarantees `getMin()` is always O(1).
::::
:::

:::problem[Problem M.3 standard]{difficulty="standard"}
A linked list node is defined as `struct Node { int val; Node* next; };`. Write a function `int length(Node* head)` that returns the number of nodes in the list.

::::solution[Solution]
```cpp
int length(Node* head) {
    int count = 0;
    while (head != nullptr) {
        count++;
        head = head->next;
    }
    return count;
}
```
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
What is the difference between passing a large object as `const MyClass& obj` versus as `MyClass obj`? Which is preferred and why?

::::solution[Solution]
`MyClass obj` (pass-by-value) creates a *copy* of the object — invoking the copy constructor. For large objects this is expensive in both time and memory. `const MyClass& obj` passes a reference (essentially a pointer behind the scenes), so no copy is made. The `const` guarantees the function won't modify the original. Pass-by-const-reference is almost always preferred for non-primitive types.
::::
:::

:::problem[Problem M.5 challenge]{difficulty="challenge"}
Write a function `Node* reverseList(Node* head)` that reverses a singly linked list in-place and returns the new head. No extra memory allowed (O(1) space).

::::solution[Solution]
```cpp
Node* reverseList(Node* head) {
    Node* prev = nullptr;
    Node* curr = head;
    while (curr != nullptr) {
        Node* next = curr->next;  // save next before overwriting
        curr->next = prev;         // reverse the link
        prev = curr;               // advance prev
        curr = next;               // advance curr
    }
    return prev;  // prev is now the new head
}
```

Trace with 1→2→3→nullptr:

1. curr=1, prev=null: save next=2, set 1→null, prev=1, curr=2
2. curr=2, prev=1: save next=3, set 2→1, prev=2, curr=3
3. curr=3, prev=2: save next=null, set 3→2, prev=3, curr=null
4. Loop ends. Return prev=3 (new head). List: 3→2→1→null ✓
::::
:::

:::problem[Problem M.6 challenge]{difficulty="challenge"}
Without using any STL containers, write a template function `T* cloneArray(const T* src, int n)` that allocates a new heap array of size `n`, copies all elements from `src`, and returns it. The caller is responsible for freeing the result.

::::solution[Solution]
```cpp
template <typename T>
T* cloneArray(const T* src, int n) {
    T* copy = new T[n];
    for (int i = 0; i < n; i++)
        copy[i] = src[i];   // requires T to have copy assignment
    return copy;
}

// Caller:
int arr[] = {1, 2, 3, 4, 5};
int* copy = cloneArray(arr, 5);
// ... use copy ...
delete[] copy;
```
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook. Generated for personal study use.
