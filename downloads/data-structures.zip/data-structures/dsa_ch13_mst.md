---
title: "Minimum Spanning Trees"
crumb: "Honors DSA · Chapter 13"
meta:
  - "Est. study time: ~60 min"
  - "Unit 4"
  - "CSE 2383 · MSState"
source: "dsa_ch13_mst.html"
---

## 1. Spanning Trees

:::definition[Definition 13.1 — Spanning Tree]
A **spanning tree** of a connected undirected graph $G = (V, E)$ is a subgraph $T$ that
 is a tree and includes every vertex of $G$. Equivalently, $T$ has exactly $|V|$ vertices,
 exactly $|V| - 1$ edges, is connected, and is acyclic.
:::

The three conditions — connected, acyclic, spans all vertices — are redundant: any two imply the third
 for a finite graph. So a spanning tree is the *minimal connected subgraph* of $G$.

### Counting spanning trees

For a complete graph $K_n$, Cayley's formula gives the number of labeled spanning trees:
 $n^{n-2}$. For $K_4$ that's $4^2 = 16$. In practice we care less about counting and more
 about finding the one with minimum total weight.

:::callout-key[Key Facts]
- Every spanning tree of $G$ has exactly $|V|-1$ edges.
- Adding any edge to a spanning tree creates exactly one cycle.
- Removing any edge from a spanning tree disconnects it into two components.
- A graph is a tree if and only if it has $|V|-1$ edges and is connected.
:::

## 2. The MST Problem

:::definition[Definition 13.2 — Minimum Spanning Tree]
Given a connected, undirected, weighted graph $G = (V, E, w)$, a **minimum spanning tree**
 (MST) is a spanning tree $T$ whose total edge weight $\sum_{e \in T} w(e)$ is minimized over
 all spanning trees of $G$.
:::

The MST may not be unique — if edge weights are distinct, there is exactly one MST.

### Applications

- **Network design:** lay the minimum total cable to connect all offices in a building.
- **Clustering:** remove the $k-1$ most expensive MST edges to get $k$ clusters.
- **Approximation algorithms:** the MST is a 2-approximation for the metric TSP.
- **Image segmentation, circuit design, phylogenetic trees.**

:::callout-connect[Connection to Graph Traversals]
BFS on an unweighted graph already gives a spanning tree (the BFS tree). The MST algorithms you
 are about to learn are the weighted generalization — they select *which* edges to include
 by weight rather than by discovery order.
:::

## 3. Cut Property & Cycle Property

Both Kruskal's and Prim's algorithms are greedy. Their correctness rests on two fundamental
 properties of MSTs.

:::theorem[Theorem 13.1 — Cut Property (Safe Edge)]
Let $S \subset V$ be any proper subset of vertices. Among all edges that cross the cut
 $(S, V \setminus S)$, a **minimum-weight crossing edge** is safe to add to any
 MST being grown — it belongs to some MST of $G$.
:::

:::theorem[Theorem 13.2 — Cycle Property]
For any cycle $C$ in $G$, the **maximum-weight edge** of $C$ is *not*
 in any MST (assuming distinct weights). If weights are not distinct, there exists an MST excluding
 that edge.
:::

:::callout-intuition[Intuition]
Cut property: any time you have two disconnected groups of vertices, the cheapest bridge between
 them must be in the MST — using a more expensive bridge would waste weight.

Cycle property: in any loop, the most expensive edge is redundant — you can reach the same
 vertices via the rest of the cycle for less cost.
:::

### Why greedy works

The cut property guarantees that locally optimal choices (always picking the cheapest safe edge)
 accumulate into a globally optimal solution. This is rare — greedy fails for shortest paths with
 negative weights, for example — but the special structure of spanning trees makes it work here.

## 4. Kruskal's Algorithm

:::callout-intuition[Intuition]
Sort all edges cheapest-first. Scan through them in order. Add each edge to the MST *unless*
 it would create a cycle. Stop when you have $|V|-1$ edges. The trick is checking "would this
 create a cycle?" efficiently — that is exactly what Union-Find is for.
:::

### Algorithm

```cpp
// Kruskal's MST — O(E log E)
struct Edge { int u, v, w; };

vector<Edge> kruskal(int n, vector<Edge> edges) {
    sort(edges.begin(), edges.end(),
         [](const Edge& a, const Edge& b){ return a.w < b.w; });

    DSU dsu(n);               // Union-Find (see Section 5)
    vector<Edge> mst;

    for (auto& e : edges) {
        if (dsu.find(e.u) != dsu.find(e.v)) {   // different components?
            mst.push_back(e);
            dsu.unite(e.u, e.v);
            if ((int)mst.size() == n - 1) break; // done
        }
    }
    return mst;  // |V|-1 edges
}
```

### Complexity

| Step | Cost |
| --- | --- |
| Sort edges | $O(E \log E)$ |
| Union-Find operations (E finds, V-1 unions) | $O(E \cdot \alpha(V)) \approx O(E)$ |
| Total | $O(E \log E)$ (dominated by sort) |

Since $E \leq V^2$, we have $\log E = O(\log V)$, so the complexity is also written $O(E \log V)$.

:::example[Example 13.1 — Kruskal's Step-by-Step Trace]
Run Kruskal's on this graph (6 vertices, 9 edges):
 A-B:4, A-C:2, B-C:1, B-D:5, C-D:8, C-E:10, D-E:2, D-F:6, E-F:3. Show each step.

::::answer[Answer]
MST edges selected: B-C:1, A-C:2, D-E:2, E-F:3, A-B:4 skipped (cycle!), B-D:5. Total weight = 1+2+2+3+5 = 13.
::::

Work

Sorted edges: B-C:1, A-C:2, D-E:2, E-F:3, A-B:4, B-D:5, D-F:6, C-D:8, C-E:10

1. **B-C:1** — B and C in different components. Add. MST={B-C}. Components: {A},{B,C},{D},{E},{F}
2. **A-C:2** — A and C different. Add. MST={B-C, A-C}. Components: {A,B,C},{D},{E},{F}
3. **D-E:2** — D and E different. Add. MST={B-C,A-C,D-E}. Components: {A,B,C},{D,E},{F}
4. **E-F:3** — E and F different. Add. MST={B-C,A-C,D-E,E-F}. Components: {A,B,C},{D,E,F}
5. **A-B:4** — A and B both in {A,B,C}. Skip (cycle).
6. **B-D:5** — B in {A,B,C}, D in {D,E,F}. Add. MST has 5 = |V|-1 edges. Done.

Final MST weight: 1 + 2 + 2 + 3 + 5 = **13**.
:::

### Practice — Kruskal's Algorithm

:::problem[Problem 1 · easy]{difficulty="easy"}
Graph with 4 vertices (A,B,C,D) and edges: A-B:3, A-C:1, B-C:4, B-D:2, C-D:5.
 Run Kruskal's and list the MST edges in order added.

::::solution[Solution]
Sorted: A-C:1, B-D:2, A-B:3, B-C:4, C-D:5.

 1. A-C:1 — add. {A,C},{B},{D}

 2. B-D:2 — add. {A,C},{B,D}

 3. A-B:3 — A and B different components. Add. {A,B,C,D} — done.

 MST = {A-C:1, B-D:2, A-B:3}, total weight = 6.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Graph: V={1,2,3,4,5}, edges: 1-2:10, 1-3:6, 1-4:5, 2-3:4, 2-5:8, 3-4:2, 4-5:7.
 Trace Kruskal's completely. What is the MST weight?

::::solution[Solution]
Sorted: 3-4:2, 2-3:4, 1-4:5, 4-5:7, 2-5:8, 1-3:6, 1-2:10.

 1. 3-4:2 add. {3,4} others separate.

 2. 2-3:4 add. {2,3,4}.

 3. 1-4:5 — 1 not in {2,3,4}. Add. {1,2,3,4}.

 4. 4-5:7 — skip? No, 5 is separate. Add. Done (4 edges for 5 vertices).

 MST = {3-4:2, 2-3:4, 1-4:5, 4-5:7}, total = **18**.
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Prove that if all edge weights in a connected graph are distinct, the MST is unique. Hint: use the cycle property.

::::solution[Solution]
Suppose two distinct MSTs $T_1$ and $T_2$ exist with distinct edge weights. Let $e$ be the minimum-weight edge in $T_1 \triangle T_2$ (symmetric difference). WLOG $e \in T_1 \setminus T_2$. Adding $e$ to $T_2$ creates a cycle $C$. Since $e$ is the minimum weight in $T_1 \triangle T_2$, all other edges of $C$ have weight greater than $w(e)$. By the cycle property, the max-weight edge of $C$ should be excluded from the MST. But $T_2$ already excluded $e$ (the cheapest), which means $T_2$ kept a more expensive edge instead — contradicting that $T_2$ is an MST. Therefore the MST is unique.
::::
:::

## 5. Union-Find / Disjoint Set Union (DSU)

Union-Find is the data structure that makes Kruskal's fast. It maintains a partition of $\{0, \ldots, n-1\}$
 into disjoint sets and supports two operations:

- **find(x)** — return the representative (root) of the set containing $x$.
- **unite(x, y)** — merge the sets containing $x$ and $y$.

### Implementation with union by rank + path compression

```cpp
struct DSU {
    vector<int> parent, rank_;

    DSU(int n) : parent(n), rank_(n, 0) {
        iota(parent.begin(), parent.end(), 0); // parent[i] = i
    }

    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]);  // path compression
        return parent[x];
    }

    bool unite(int x, int y) {
        x = find(x); y = find(y);
        if (x == y) return false;         // same component
        if (rank_[x] < rank_[y]) swap(x, y);
        parent[y] = x;                    // union by rank
        if (rank_[x] == rank_[y]) rank_[x]++;
        return true;
    }
};
```

### Complexity Analysis

| Strategy | find | unite | m operations |
| --- | --- | --- | --- |
| Naive (no optimization) | $O(n)$ | $O(1)$ | $O(mn)$ |
| Union by rank only | $O(\log n)$ | $O(\log n)$ | $O(m \log n)$ |
| Path compression only | $O(\log n)$ amortized | $O(\log n)$ | $O(m \log n)$ |
| Both (rank + compression) | $O(\alpha(n))$ amortized | $O(\alpha(n))$ | $O(m \cdot \alpha(n))$ |

$\alpha(n)$ is the inverse Ackermann function — it is at most 4 for any practical input size. Effectively constant.

:::callout-pitfall[Common Pitfall]
Path compression modifies the parent array during `find`. If you accidentally call `find`
 while iterating over edges and assume parent structure is unchanged, you may get subtle bugs. Always call `find`
 on both endpoints fresh before checking if they are in the same component.
:::

### Practice — Union-Find

:::problem[Problem 4 · easy]{difficulty="easy"}
Starting with DSU on {0,1,2,3,4}, perform: unite(0,1), unite(2,3), unite(1,2), find(4).
 Draw the parent array after each operation (no path compression for clarity).

::::solution[Solution]
Initial: parent = [0,1,2,3,4], rank = [0,0,0,0,0]

 unite(0,1): rank equal, parent[1]=0, rank[0]=1. parent=[0,0,2,3,4]

 unite(2,3): rank equal, parent[3]=2, rank[2]=1. parent=[0,0,2,2,4]

 unite(1,2): find(1)=0, find(2)=2. rank[0]=rank[2]=1, parent[2]=0, rank[0]=2. parent=[0,0,0,2,4]

 find(4): parent[4]=4, returns 4. (4 is its own component.)
::::
:::

:::problem[Problem 5 · standard]{difficulty="standard"}
What is the worst-case tree height with union by rank for $n$ elements? Prove it is $O(\log n)$.

::::solution[Solution]
Claim: a tree of rank $k$ has at least $2^k$ nodes. Proof by induction: rank 0 trees have 1 node = $2^0$. When we merge two rank-$k$ trees to form rank $k+1$, the result has at least $2^k + 2^k = 2^{k+1}$ nodes. Therefore $2^{rank} \leq n$, giving $rank \leq \log_2 n$. Since height $\leq$ rank, height is $O(\log n)$.
::::
:::

## 6. Prim's Algorithm

:::callout-intuition[Intuition]
Grow the MST one vertex at a time. Start from any vertex. Maintain a priority queue of edges
 that cross from the "inside" (already in MST) to the "outside" (not yet). Always pick the cheapest
 crossing edge and add its outside endpoint. This is the cut property applied repeatedly.
:::

### Algorithm with binary heap priority queue

```cpp
// Prim's MST — O(E log V) with binary heap
// adj[u] = list of {v, weight}
int prim(int n, vector<vector<pair<int,int>>>& adj) {
    vector<int> key(n, INT_MAX);   // min edge weight to reach v
    vector<bool> inMST(n, false);
    // {key, vertex}
    priority_queue<pair<int,int>, vector<pair<int,int>>,
                   greater<>> pq;

    key[0] = 0;
    pq.push({0, 0});
    int totalWeight = 0;

    while (!pq.empty()) {
        auto [w, u] = pq.top(); pq.pop();
        if (inMST[u]) continue;  // stale entry
        inMST[u] = true;
        totalWeight += w;

        for (auto [v, wt] : adj[u]) {
            if (!inMST[v] && wt < key[v]) {
                key[v] = wt;
                pq.push({wt, v});
            }
        }
    }
    return totalWeight;
}
```

### Complexity

| Heap type | Total complexity | Best for |
| --- | --- | --- |
| Binary heap | $O(E \log V)$ | Sparse graphs |
| Fibonacci heap | $O(E + V \log V)$ | Dense graphs (theoretical) |
| Simple array (no heap) | $O(V^2)$ | Dense graphs (practical) |

:::example[Example 13.2 — Prim's Step-by-Step Trace]
Run Prim's starting from vertex A on the same graph as Example 13.1:
 A-B:4, A-C:2, B-C:1, B-D:5, C-D:8, C-E:10, D-E:2, D-F:6, E-F:3.

::::answer[Answer]
MST weight = 13, same as Kruskal's. MST edges: A-C:2, B-C:1, D-E:2, E-F:3, B-D:5.
::::

Work

1. Start at A. key[A]=0. PQ: {(0,A),(4,B),(2,C)}
2. Extract A (w=0). Add A to MST. Neighbors: B (key=4), C (key=2). PQ: {(2,C),(4,B)}
3. Extract C (w=2). Add C to MST. totalWeight=2. Update neighbors: B via C costs 1 (better than 4), D via C costs 8. PQ: {(1,B),(4,B stale),(8,D)}
4. Extract B (w=1). Add B to MST. totalWeight=3. Update: D via B costs 5 (better than 8). PQ: {(5,D),(8,D stale)}
5. Extract D (w=5). Add D to MST. totalWeight=8. Update: E via D costs 2, F via D costs 6. PQ: {(2,E),(6,F)}
6. Extract E (w=2). Add E to MST. totalWeight=10. Update: F via E costs 3 (better than 6). PQ: {(3,F),(6,F stale)}
7. Extract F (w=3). Add F. totalWeight=13. All vertices added. Done.
:::

### Practice — Prim's Algorithm

:::problem[Problem 6 · easy]{difficulty="easy"}
Run Prim's starting at vertex 1 on: V={1,2,3,4}, edges: 1-2:5, 1-3:3, 2-3:2, 2-4:6, 3-4:4.

::::solution[Solution]
Start at 1. key[1]=0. Step 1: Extract 1. Neighbors: 2(5), 3(3). Step 2: Extract 3 (key=3). totalWeight=3. Update: 2 via 3 costs 2 (better), 4 via 3 costs 4. Step 3: Extract 2 (key=2). totalWeight=5. Update: 4 via 2 costs 6 (worse than 4, no change). Step 4: Extract 4 (key=4). totalWeight=9. MST edges: 1-3:3, 3-2:2, 3-4:4. Total = 9.
::::
:::

:::problem[Problem 7 · standard]{difficulty="standard"}
Explain why Prim's algorithm with an array (no heap) runs in $O(V^2)$ and when this is preferred over the $O(E \log V)$ heap version.

::::solution[Solution]
With an array, each step scans all $V$ vertices to find the one with minimum key — that is $O(V)$ per step, $V$ steps total, giving $O(V^2)$. With a heap, each edge causes at most one decrease-key operation costing $O(\log V)$, giving $O(E \log V)$. For dense graphs where $E = \Theta(V^2)$, the heap version costs $O(V^2 \log V)$ — worse than the array version's $O(V^2)$. So the simple array implementation wins for dense graphs.
::::
:::

:::problem[Problem 8 · challenge]{difficulty="challenge"}
Prove Prim's correctness using the cut property. Specifically, show each edge Prim's adds is safe.

::::solution[Solution]
At each step, let $S$ be the set of vertices already in the MST. Prim's picks the minimum-weight edge $e = (u,v)$ with $u \in S, v \notin S$. The cut $(S, V \setminus S)$ is a valid cut. By the cut property (Theorem 13.1), the minimum-weight crossing edge of any cut is safe — it belongs to some MST. Since $e$ is the minimum crossing edge for cut $(S, V \setminus S)$, $e$ is safe to add. Applying this argument inductively, all $|V|-1$ edges selected are safe, and together they form an MST.
::::
:::

## 7. Kruskal vs Prim Comparison

| Property | Kruskal's | Prim's |
| --- | --- | --- |
| Strategy | Global edge sort + Union-Find | Grow connected component |
| Complexity (sparse, $E \approx V$) | $O(V \log V)$ | $O(V \log V)$ |
| Complexity (dense, $E \approx V^2$) | $O(V^2 \log V)$ | $O(V^2)$ with array |
| Best for | Sparse graphs | Dense graphs |
| Requires connected graph? | No (finds MSF) | Yes (starts from one vertex) |
| Implementation complexity | Moderate (needs DSU) | Moderate (needs priority queue) |

:::callout-tip[Exam Tip]
If the graph has significantly more edges than vertices ($E \gg V$), Prim's with an adjacency
 matrix is simpler and faster. If the graph is sparse or you are given an edge list, Kruskal's is
 typically cleaner to implement and analyze.
:::

## 8. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
A connected graph has 8 vertices. How many edges does every spanning tree of this graph have? How many edges must be removed from the graph's MST to produce 3 connected components?

::::solution[Solution]
Every spanning tree has $|V| - 1 = 7$ edges. To produce 3 connected components from a tree, remove 2 edges (each removal increases the component count by 1).
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
True or False: Kruskal's algorithm always produces the same MST as Prim's algorithm on the same graph. Explain.

::::solution[Solution]
True (when edge weights are distinct — there is only one MST). Both algorithms find the unique MST. When edge weights are not all distinct, both still find *an* MST but may choose different ones (both are correct). The MST itself is unique iff edge weights are distinct.
::::
:::

:::problem[Exam Q3 · challenge]{difficulty="challenge"}
Suppose you have a graph and its MST $T$. A new edge $e = (u,v,w)$ is added. Give an efficient algorithm to update the MST.

::::solution[Solution]
Find the path from $u$ to $v$ in $T$ (using BFS/DFS, $O(V)$). Let $e_{max}$ be the maximum-weight edge on this path. If $w < w(e_{max})$, remove $e_{max}$ from $T$ and add $e$; the resulting tree is the new MST. Otherwise $T$ remains the MST. Total time: $O(V)$ — much better than re-running Kruskal's or Prim's.
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
What is the amortized time complexity of a single Union-Find operation with both union by rank and path compression? What is $\alpha(n)$ informally?

::::solution[Solution]
$O(\alpha(n))$ per operation, where $\alpha$ is the inverse Ackermann function. Informally, $\alpha(n) \leq 4$ for any $n$ that could arise in practice (including the number of atoms in the universe). For exam purposes it is treated as $O(1)$.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
Run Kruskal's on: V={A,B,C,D,E}, edges A-B:3, A-D:1, B-C:4, B-E:2, C-E:5, D-E:6, D-B:7. Show the order edges are added and the final MST weight.

::::solution[Solution]
Sorted: A-D:1, B-E:2, A-B:3, B-C:4, C-E:5, D-E:6, D-B:7.

 1. A-D:1 add. {A,D}.

 2. B-E:2 add. {B,E}.

 3. A-B:3 — {A,D} and {B,E} different. Add. {A,B,D,E}.

 4. B-C:4 — C not in component. Add. Done (4 edges).

 MST = {A-D:1, B-E:2, A-B:3, B-C:4}. Weight = 10.
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
Does Kruskal's algorithm work correctly on disconnected graphs? What does it produce?

::::solution[Solution]
Yes. On a disconnected graph, Kruskal's produces a **minimum spanning forest** — one MST per connected component. The algorithm terminates naturally when it runs out of edges to process, having connected each component internally. The result has $|V| - k$ edges, where $k$ is the number of connected components.
::::
:::

:::problem[Exam Q7 · standard]{difficulty="standard"}
State the cycle property and use it to show that edge C-D:8 from Example 13.1 is NOT in the MST.

::::solution[Solution]
Cycle property: the maximum-weight edge in any cycle does not belong to any MST (when weights are distinct). The path A-C-B-D uses edges A-C:2, B-C:1, B-D:5 (total path weight). Adding C-D:8 creates the cycle C-B-D-C with edges B-C:1, B-D:5, C-D:8. Edge C-D:8 is the maximum-weight edge in this cycle, so by the cycle property it is not in the MST.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
What is the time complexity of Prim's algorithm using a Fibonacci heap, and why is it rarely used in practice despite being theoretically superior?

::::solution[Solution]
$O(E + V \log V)$ with a Fibonacci heap, which beats the $O(E \log V)$ binary heap version for dense graphs. In practice, Fibonacci heaps have large constant factors, complex implementation, poor cache behavior, and high memory overhead. For typical graph sizes, binary heap Prim's or even simple array Prim's outperforms Fibonacci heap Prim's. The theoretical improvement only matters for very large dense graphs.
::::
:::

:::summary
## Chapter 13 Summary

| Algorithm | Time | Space | Key Idea |
| --- | --- | --- | --- |
| Kruskal's | $O(E \log E)$ | $O(V + E)$ | Sort edges, add if no cycle (DSU) |
| Prim's (binary heap) | $O(E \log V)$ | $O(V + E)$ | Grow component, pick min crossing edge |
| Prim's (array) | $O(V^2)$ | $O(V)$ | Linear scan for min key; best for dense |
| Prim's (Fibonacci) | $O(E + V \log V)$ | $O(V + E)$ | Theory; impractical constant factors |
| Union-Find (rank+compress) | $O(\alpha(n))$ amortized | $O(n)$ | Near-constant component tracking |

### Key Theorems

- **Cut Property:** the lightest edge crossing any cut is safe for the MST.
- **Cycle Property:** the heaviest edge in any cycle is not in the MST (distinct weights).
- **Uniqueness:** distinct edge weights imply a unique MST.
- **Spanning tree size:** always exactly $|V| - 1$ edges.
:::
