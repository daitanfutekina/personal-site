---
title: "Hash Tables"
crumb: "Honors DSA · Chapter 15"
meta:
  - "Est. study time: ~65 min"
  - "Unit 5"
  - "CSE 2383 · MSState"
source: "dsa_ch15_hash_tables.html"
---

## 1. Hash Table ADT

:::callout-intuition[Intuition]
Imagine a library where every book has a unique ISBN. Instead of searching shelf by shelf, you apply a formula to the ISBN that directly gives you the shelf number. That's a hash table: a formula maps a key to a storage slot, enabling near-instant lookup regardless of how many items are stored.
:::

A **hash table** (also called a hash map) is a data structure that implements the *dictionary ADT* — a collection of key-value pairs supporting three core operations:

- **insert(key, value)** — store a value associated with a key
- **search(key)** — retrieve the value for a given key
- **delete(key)** — remove the key-value pair

The magic: all three operations run in **O(1) average time**, independent of table size. This beats every comparison-based structure (BSTs give O(log n)). The cost is that keys must be *hashable* — you need a function to convert them to integer indices.

### The Hash Table Idea

Internally, a hash table is an array of *m* slots (called **buckets**). To store key *k*, you compute an index $h(k) \in \{0, 1, \ldots, m-1\}$ and place the item there. Lookup works the same way: compute $h(k)$ and go directly to that slot.

:::callout-key[Key Fact]
A hash table with *n* items and *m* buckets has **load factor** $\alpha = n/m$. Average-case O(1) operations assume $\alpha$ stays bounded (typically below 0.75 for open addressing, or any reasonable constant for chaining).
:::

:::example[Example 15.1 — Basic Hash Table Concept]
A hash table has m = 7 slots. We hash integer keys using h(k) = k mod 7. Where do keys 14, 22, 3 land?

::::answer[Answer]
14 mod 7 = **0**, 22 mod 7 = **1**, 3 mod 7 = **3**.
::::

Visualization

| Slot | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Key | 14 | 22 | — | 3 | — | — | — |

Each key maps directly to its slot — no iteration needed.
:::

:::example[Example 15.2 — Why Keys Must Be Hashable]
Can you use a std::vector as a key in a hash table?

::::answer[Answer]
Not by default. Vectors don't have a built-in hash function in C++. You must provide a custom hasher. This is why primitive types (int, string, pointer) work out of the box but compound types require extra work.
::::
:::

:::callout-pitfall[Pitfall]
**O(1) is average-case, not worst-case.** With a bad hash function or adversarial inputs, every key can collide in the same bucket, degrading all operations to O(n). Never assume O(1) in a worst-case analysis unless you use a randomized hash.
:::

### Section 1 Practice

:::problem[Problem 1.1 easy]{difficulty="easy"}
A hash table has m = 11 buckets. Using h(k) = k mod 11, where do keys 0, 11, 22, 33 map?

::::solution[Solution]
All four keys map to slot **0** (since 0, 11, 22, 33 are all multiples of 11). This is a collision — all four keys land in the same bucket, illustrating why choosing m as a prime number and using a better hash function matters.
::::
:::

:::problem[Problem 1.2 easy]{difficulty="easy"}
Name the three operations of the dictionary ADT and their average-case complexity in a hash table.

::::solution[Solution]
**insert(k, v)** — O(1) average. **search(k)** — O(1) average. **delete(k)** — O(1) average. All rely on the hash function mapping to the right bucket in constant time.
::::
:::

:::problem[Problem 1.3 standard]{difficulty="standard"}
What is the load factor of a hash table with 120 entries and 150 buckets? Is this healthy for a chaining-based table?

::::solution[Solution]
$\alpha = n/m = 120/150 = 0.8$. For chaining, $\alpha = 0.8$ is acceptable — average chain length is 0.8 items. For open addressing, this is approaching the threshold where rehashing is typically triggered (usually 0.75).
::::
:::

## 2. Hash Functions

:::callout-intuition[Intuition]
A hash function is the "formula" that converts any key into a bucket index. A bad hash function is like a bad librarian who always puts books in the same spot — you need one that spreads items evenly. The ideal hash function looks random even though it's deterministic.
:::

A good hash function satisfies four properties:

1. **Uniform distribution** — maps keys roughly evenly across all m buckets
2. **Fast to compute** — O(1) or O(key length) at most
3. **Deterministic** — same key always maps to same bucket
4. **Avalanche effect** — small change in key causes large change in hash output

### Division Method

The simplest approach:

$$
h(k) = k \bmod m
$$

 Works well when m is a prime not close to a power of 2. Avoid m = 2^p because then h(k) depends only on the lowest p bits of k, ignoring the rest of the key.

### Multiplication Method

Choose a constant $A \in (0,1)$. Then:

$$
h(k) = \lfloor m \cdot (kA \bmod 1) \rfloor
$$

 The quantity $kA \bmod 1$ extracts the fractional part of kA. Knuth recommends $A = (\sqrt{5}-1)/2 \approx 0.618$. This method is less sensitive to the choice of m.

### Polynomial Rolling Hash for Strings

For a string $s = s_0 s_1 \cdots s_{n-1}$, use a base prime p and a large modulus m:

$$
h(s) = \left( s_0 \cdot p^0 + s_1 \cdot p^1 + \cdots + s_{n-1} \cdot p^{n-1} \right) \bmod m
$$

 Typical choices: p = 31 (for lowercase letters), m = 10^9 + 7 (large prime). Computed iteratively in O(|s|) time.

```cpp
// Polynomial rolling hash for a string key
size_t stringHash(const std::string& s, int m) {
    const long long p = 31;
    long long hash = 0, power = 1;
    for (char c : s) {
        hash = (hash + (c - 'a' + 1) * power) % m;
        power = (power * p) % m;
    }
    return (size_t)hash;
}
```

:::example[Example 15.3 — Division Method]
Using the division method with m = 13, compute h(100) and h(107).

::::answer[Answer]
h(100) = 100 mod 13 = **9** (since 13 × 7 = 91, 100 − 91 = 9).

h(107) = 107 mod 13 = **3** (since 13 × 8 = 104, 107 − 104 = 3).
::::
:::

:::example[Example 15.4 — Rolling Hash for "cat"]
Compute the polynomial rolling hash of "cat" using p = 31, m = 100.

::::answer[Answer]
Map: c=3, a=1, t=20 (using c − 'a' + 1).

$h = (3 \cdot 31^0 + 1 \cdot 31^1 + 20 \cdot 31^2) \bmod 100$

$= (3 \cdot 1 + 1 \cdot 31 + 20 \cdot 961) \bmod 100$

$= (3 + 31 + 19220) \bmod 100$

$= 19254 \bmod 100 = \mathbf{54}$
::::
:::

:::callout-pitfall[Pitfall]
**Choosing m = 2^k is dangerous.** With division method, h(k) = k mod 2^k uses only the k lowest bits of the key. If keys have patterns in their low bits (common in practice), clustering occurs. Always use a prime m.
:::

### Section 2 Practice

:::problem[Problem 2.1 easy]{difficulty="easy"}
Using division method with m = 17, compute h(45), h(68), h(255).

::::solution[Solution]
45 mod 17 = **11** (17×2=34, 45−34=11). 68 mod 17 = **0** (17×4=68). 255 mod 17 = **0** (17×15=255). Notice 68 and 255 collide at slot 0!
::::
:::

:::problem[Problem 2.2 standard]{difficulty="standard"}
Why is the rolling hash computed iteratively rather than recomputing each power from scratch?

::::solution[Solution]
Recomputing each power from scratch would cost O(i) for the i-th term, giving O(1+2+…+n) = O(n²) total. By keeping a running `power` variable and multiplying by p each iteration, each term costs O(1), making the overall hash O(n) — linear in the string length.
::::
:::

:::problem[Problem 2.3 challenge]{difficulty="challenge"}
Two different strings can produce the same hash value — this is called a *hash collision*. Explain why this is mathematically unavoidable for any hash function mapping strings to a fixed-size table.

::::solution[Solution]
By the **Pigeonhole Principle**: there are infinitely many possible strings but only m bucket slots. Therefore, at least two distinct strings must map to the same slot. This is unavoidable regardless of how clever the hash function is — the table simply doesn't have enough room to give every possible string its own unique slot.
::::
:::

## 3. Chaining

:::callout-intuition[Intuition]
What happens when two keys hash to the same bucket? In chaining, each bucket holds a linked list of all items that mapped there. It's like a parking lot where multiple cars can share one space — they form a line, and you search down the line to find your car.
:::

In **separate chaining**, each of the m buckets contains a linked list (or another dynamic structure). When keys collide, they're appended to the same list. To search for key k: compute h(k), then scan the list at bucket h(k) for k.

```cpp
// Chaining hash table (simplified)
#include <list>
#include <vector>
#include <optional>

template<typename K, typename V>
class ChainingHashTable {
    int m;
    std::vector<std::list<std::pair<K,V>>> buckets;

    int hash(int k) const { return ((k % m) + m) % m; }

public:
    ChainingHashTable(int m) : m(m), buckets(m) {}

    void insert(K key, V val) {
        int idx = hash(key);
        // Check if key exists, update if so
        for (auto& [k, v] : buckets[idx])
            if (k == key) { v = val; return; }
        buckets[idx].emplace_front(key, val);
    }

    std::optional<V> search(K key) {
        int idx = hash(key);
        for (auto& [k, v] : buckets[idx])
            if (k == key) return v;
        return std::nullopt;
    }

    void remove(K key) {
        int idx = hash(key);
        buckets[idx].remove_if([&](auto& p){ return p.first == key; });
    }
};
```

### Load Factor and Complexity

With n items in m buckets, the **load factor** is $\alpha = n/m$. Under the *simple uniform hashing assumption* (each key equally likely to hash to any bucket), the expected list length at any bucket is $\alpha$. Therefore:

- **Successful search**: $O(1 + \alpha)$ expected (hash + short list scan)
- **Unsuccessful search**: $O(1 + \alpha)$ expected
- **Worst case**: $O(n)$ — all keys hash to the same bucket
- **Delete**: same as search — easy, just remove from list

If we keep $\alpha = O(1)$ (by resizing when needed), all operations are O(1) expected. Chaining is robust: even at $\alpha = 2$ or 3, performance degrades gracefully.

:::example[Example 15.5 — Chaining Collision Resolution]
Hash table with m = 5, using h(k) = k mod 5. Insert keys: 5, 10, 15, 3, 8. Show the final state.

::::answer[Answer]
h(5)=0, h(10)=0, h(15)=0, h(3)=3, h(8)=3.
::::

Final State

| Bucket | Chain |
| --- | --- |
| 0 | 15 → 10 → 5 (inserted front-first) |
| 1 | — |
| 2 | — |
| 3 | 8 → 3 |
| 4 | — |

Load factor α = 5/5 = 1. Average chain length is 1, but bucket 0 has 3 items — a sign of a poor hash function (all multiples of 5 collide).
:::

:::example[Example 15.6 — Deletion in Chaining]
From the table above, delete key 10. What changes?

::::answer[Answer]
Compute h(10) = 0. Scan bucket 0's list: 15 → 10 → 5. Find and remove node with key 10. Result: bucket 0 becomes 15 → 5. No other buckets change. Deletion in chaining is straightforward — just a linked-list removal.
::::
:::

:::callout-pitfall[Pitfall]
**Chaining uses extra memory for pointers.** Each list node needs a next pointer. For small value types, pointer overhead can double memory usage. In practice, consider using `std::vector` per bucket (cache-friendly) rather than `std::list` (pointer-chased). Also, chaining allows α > 1 without structural failure — but don't let it grow unbounded.
:::

### Section 3 Practice

:::problem[Problem 3.1 easy]{difficulty="easy"}
With m = 7, h(k) = k mod 7, insert keys {14, 1, 8, 22, 29, 36} using chaining. What is the chain at bucket 1?

::::solution[Solution]
h(14)=0, h(1)=1, h(8)=1, h(22)=1, h(29)=1, h(36)=1. Bucket 1 chain: 36→29→22→8→1 (assuming front insertion). Five of six keys land at bucket 1 — a terrible distribution for this key set.
::::
:::

:::problem[Problem 3.2 standard]{difficulty="standard"}
A chaining hash table has m = 10 buckets and 25 stored items. What is the expected number of comparisons for a successful search?

::::solution[Solution]
α = n/m = 25/10 = 2.5. Expected comparisons for successful search = 1 + α/2 = 1 + 1.25 = **2.25** (the 1 covers hashing plus finding the right bucket; α/2 is the expected position in the chain). Some sources simplify to O(1+α) = O(3.5), which is still constant.
::::
:::

:::problem[Problem 3.3 challenge]{difficulty="challenge"}
Why is `std::vector` often better than `std::list` as the chaining container, even though vector insertion is O(n)?

::::solution[Solution]
With short chains (α near 1), the constant factors dominate. `std::vector` stores elements contiguously in memory — scanning it benefits from CPU cache prefetching. `std::list` nodes are scattered in memory; each traversal step is a potential cache miss. For chains of length 2-4, the cache penalty of list can make it 3-5× slower in practice despite identical asymptotic complexity.
::::
:::

## 4. Open Addressing

:::callout-intuition[Intuition]
Instead of chaining, what if we keep everything in the array itself? When a collision occurs, probe for the next open slot. It's like arriving at a full parking spot — instead of stacking cars, you look at spots 1, 2, 3... ahead until you find an empty one. Everything stays in-array: better cache behavior, but deletion becomes tricky.
:::

In **open addressing**, all items live directly in the m-slot array. When h(k) is occupied, we *probe* a sequence of alternate slots until we find an empty one. The probe sequence for key k is:

$$
h(k,0),\ h(k,1),\ h(k,2),\ \ldots
$$

Every probe sequence must be a permutation of $\{0, 1, \ldots, m-1\}$ to guarantee we can always find an empty slot (if one exists).

### Linear Probing

The simplest strategy — step forward by 1 each time:

$$
h(k,i) = (h(k) + i) \bmod m
$$

 Problem: **primary clustering** — long runs of occupied cells form, making future probes slow.

### Quadratic Probing

Step size grows quadratically:

$$
h(k,i) = (h(k) + c_1 i + c_2 i^2) \bmod m
$$

 Common choice: c₁ = 0, c₂ = 1 (so steps are 0, 1, 4, 9, 16...). Reduces primary clustering but causes **secondary clustering** — keys with the same h(k) follow the same probe sequence.

### Double Hashing

Use a second hash function for the step size:

$$
h(k,i) = (h_1(k) + i \cdot h_2(k)) \bmod m
$$

 Typical choice: $h_1(k) = k \bmod m$, $h_2(k) = 1 + (k \bmod (m-1))$. This gives $m^2$ possible probe sequences — virtually no clustering. Requirement: h₂(k) must never be 0 and must be coprime with m (so use prime m).

```cpp
// Open addressing with linear probing
template<typename K, typename V>
class OpenHashTable {
    enum State { EMPTY, OCCUPIED, DELETED };
    struct Slot { K key; V val; State state = EMPTY; };
    int m, n = 0;
    std::vector<Slot> table;

    int h(K k) { return ((k % m) + m) % m; }

public:
    OpenHashTable(int m) : m(m), table(m) {}

    bool insert(K key, V val) {
        int i = 0, start = h(key);
        while (i < m) {
            int idx = (start + i) % m;  // linear probe
            if (table[idx].state != OCCUPIED) {
                table[idx] = {key, val, OCCUPIED};
                ++n; return true;
            }
            if (table[idx].key == key) { table[idx].val = val; return true; }
            ++i;
        }
        return false; // table full
    }

    std::optional<V> search(K key) {
        int i = 0, start = h(key);
        while (i < m) {
            int idx = (start + i) % m;
            if (table[idx].state == EMPTY) return std::nullopt;
            if (table[idx].state == OCCUPIED && table[idx].key == key)
                return table[idx].val;
            ++i;
        }
        return std::nullopt;
    }

    void remove(K key) {
        int i = 0, start = h(key);
        while (i < m) {
            int idx = (start + i) % m;
            if (table[idx].state == EMPTY) return;
            if (table[idx].state == OCCUPIED && table[idx].key == key) {
                table[idx].state = DELETED; // tombstone!
                --n; return;
            }
            ++i;
        }
    }
};
```

:::callout-key[Key Fact — Tombstones]
When deleting with open addressing, you can't simply mark the slot EMPTY — that would break probe sequences for keys inserted after this slot. Instead, mark it **DELETED** (tombstone). Tombstones count as occupied during search but as empty during insert. They accumulate over time and degrade performance — another reason to rehash periodically.
:::

:::example[Example 15.7 — Linear Probing Insertion]
m = 7, h(k) = k mod 7. Insert keys 50, 700, 76, 85, 92 using linear probing.

::::answer[Answer]
h(50)=1→slot 1 free → place at 1. h(700)=0→slot 0 free → place at 0. h(76)=6→slot 6 free → place at 6. h(85)=1→slot 1 occupied→probe slot 2 (free) → place at 2. h(92)=1→slot 1 occupied→probe slot 2 (occupied)→probe slot 3 (free) → place at 3.
::::

| Slot | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Key | 700 | 50 | 85 | 92 | — | — | 76 |

Keys 50, 85, 92 all hashed to slot 1, creating a cluster at slots 1-3.
:::

:::example[Example 15.8 — Double Hashing]
m = 7, h₁(k) = k mod 7, h₂(k) = 1 + (k mod 6). Insert 50 then 85 (both hash to slot 1). Where does 85 land?

::::answer[Answer]
50: h₁(50) = 1, slot 1 free → placed at 1.

85: h₁(85) = 1, occupied. Step = h₂(85) = 1 + (85 mod 6) = 1 + 1 = 2. Next slot: (1 + 1×2) mod 7 = 3. Slot 3 is free → 85 placed at slot 3. Unlike linear probing where 85 would land at slot 2 (adjacent to 50), double hashing places it at slot 3, avoiding the cluster buildup.
::::
:::

:::callout-pitfall[Pitfall]
**Open addressing requires α < 1** — the table can never be completely full (no empty slot means infinite probing). Performance degrades sharply as α approaches 1. For linear probing, expected probes for unsuccessful search ≈ $\frac{1}{(1-\alpha)^2}$, which explodes near α=1. Always keep α ≤ 0.75.
:::

### Section 4 Practice

:::problem[Problem 4.1 easy]{difficulty="easy"}
With m = 11 and linear probing h(k,i) = (k + i) mod 11, insert keys 10, 21, 32. Where does each land?

::::solution[Solution]
h(10,0) = 10 → slot 10 free → 10 at slot 10. h(21,0) = 10 → occupied → h(21,1) = 11 mod 11 = 0 → slot 0 free → 21 at slot 0. h(32,0) = 10 → occupied → h(32,1) = 0 → occupied → h(32,2) = 1 → slot 1 free → 32 at slot 1.
::::
:::

:::problem[Problem 4.2 standard]{difficulty="standard"}
After inserting and then deleting a key with open addressing, why must we use a tombstone instead of just clearing the slot?

::::solution[Solution]
Suppose key A is in slot 5 and key B probed slot 5 (full) and landed at slot 6. If we delete A and clear slot 5, then searching for B starts at slot 5, finds it EMPTY, and returns "not found" — even though B is in slot 6! The empty slot terminates the search prematurely. A tombstone (DELETED) keeps the probe chain intact: searches skip over DELETED slots but don't stop at them.
::::
:::

:::problem[Problem 4.3 challenge]{difficulty="challenge"}
Explain why h₂(k) must be coprime with m in double hashing, and why using prime m makes this easier to guarantee.

::::solution[Solution]
The probe sequence h₁(k) + i·h₂(k) mod m must visit all m slots (be a full permutation) to guarantee we find an empty slot. This happens if and only if gcd(h₂(k), m) = 1. If m is prime, then any h₂(k) in {1, 2, ..., m-1} is automatically coprime with m (since a prime has no divisors other than 1 and itself). This is why we force h₂(k) ≥ 1 and use prime m — it guarantees complete coverage with no wasted probes.
::::
:::

## 5. Load Factor & Rehashing

:::callout-intuition[Intuition]
A hash table is like a parking lot: it works great when half full, but terrible when nearly full. Rehashing is building a bigger parking lot and relocating every car. It's expensive once, but you do it so rarely that the cost averages out — this is the classic amortized O(1) argument.
:::

As items are inserted, the load factor α = n/m increases. Beyond a threshold:

- **Chaining**: chains get long, average lookup degrades from O(1) to O(α)
- **Open addressing**: probing becomes expensive, approaching O(1/(1-α)) per operation

The solution is **rehashing**: allocate a new array (typically 2× the old size), then re-insert every item from scratch using the new hash function h(k) mod m\_new.

### Rehashing Algorithm

```cpp
void rehash() {
    int new_m = nextPrime(2 * m);  // new size: about double, next prime
    std::vector<Slot> new_table(new_m);

    // Re-insert every live item into the new table
    for (auto& slot : table) {
        if (slot.state == OCCUPIED) {
            int idx = slot.key % new_m;
            while (new_table[idx].state == OCCUPIED)
                idx = (idx + 1) % new_m;
            new_table[idx] = slot;
        }
    }
    table = std::move(new_table);
    m = new_m;
}

void insert(K key, V val) {
    if ((double)(n + 1) / m > 0.75) rehash();  // trigger threshold
    // ... normal insert ...
}
```

### Amortized O(1) Analysis

Suppose we start with m = 1 and double each time α exceeds 0.75. After k doublings, m = 2^k. A rehash at size m costs O(m) to move all items. Charge each item a "credit" of O(1) at insert time. By the time we rehash from size m to 2m, we've collected O(m) credits — exactly enough to pay for the O(m) rehash. Thus, total cost for n inserts is O(n), giving O(1) amortized per insert.

:::callout-key[Key Fact]
The typical thresholds: **grow** when α > 0.75 (open addressing) or α > 1.0–2.0 (chaining). **Shrink** (optional) when α < 0.25 to reclaim memory. The new size should be the next prime after 2m for division-method hashing.
:::

:::example[Example 15.9 — Rehash Trigger]
A hash table starts with m = 4, threshold α = 0.75. Show when rehashes occur as we insert 10 items.

::::answer[Answer]
After 3 inserts: α = 3/4 = 0.75 → rehash to m = 11 (next prime after 8). After 9 inserts: α = 9/11 ≈ 0.82 → rehash to m = 23. Insert 10th item into new table (α = 10/23 ≈ 0.43, no rehash).
::::
:::

### Section 5 Practice

:::problem[Problem 5.1 easy]{difficulty="easy"}
A hash table with m = 16 and α-threshold 0.75 currently has 11 items. After the next insert, will a rehash trigger?

::::solution[Solution]
After inserting: n = 12, α = 12/16 = 0.75. This exactly hits the threshold, so yes — rehash triggers. New size: next prime after 32, which is 37.
::::
:::

:::problem[Problem 5.2 standard]{difficulty="standard"}
Why must all items be re-inserted (not just copied) during a rehash?

::::solution[Solution]
The hash function is h(k) mod m. When m changes, h(k) mod m\_new gives a completely different index for every key. You can't just copy slots — an item at slot 5 in the old table may need to go to slot 17 in the new table. Every item must be re-hashed through the new function to find its correct position.
::::
:::

## 6. C++ `unordered_map`

:::callout-intuition[Intuition]
The C++ STL provides production-ready hash tables through `std::unordered_map` and `std::unordered_set`. Understanding their interface and tuning knobs lets you use them effectively — and understand their performance characteristics before your next interview or exam.
:::

### Basic Usage

```cpp
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <iostream>

int main() {
    std::unordered_map<std::string, int> wordCount;

    // Insert / update
    wordCount["hello"]++;
    wordCount["world"]++;
    wordCount["hello"]++;   // "hello" is now 2

    // Search
    if (wordCount.count("hello"))
        std::cout << wordCount["hello"] << "\n"; // 2

    // Iterate
    for (auto& [word, cnt] : wordCount)
        std::cout << word << ": " << cnt << "\n";

    // Delete
    wordCount.erase("world");

    // unordered_set (keys only, no values)
    std::unordered_set<int> seen;
    seen.insert(42);
    if (seen.count(42)) std::cout << "found!\n";
}
```

### Performance Tuning

```cpp
std::unordered_map<int, int> mp;

// Reserve space upfront — avoids rehashes if you know n
mp.reserve(1000);  // ensures no rehash until n > 1000 * max_load_factor

// Control load factor threshold
mp.max_load_factor(0.5);  // rehash earlier, fewer collisions, more memory

// Inspect internals
std::cout << mp.bucket_count() << "\n";  // current m
std::cout << mp.load_factor() << "\n";   // current alpha
std::cout << mp.bucket(42) << "\n";      // which bucket key 42 is in
```

### Custom Hash for Structs

```cpp
struct Point { int x, y; };

// Equality operator required
struct PointEqual {
    bool operator()(const Point& a, const Point& b) const {
        return a.x == b.x && a.y == b.y;
    }
};

// Custom hasher: combine x and y hashes
struct PointHash {
    size_t operator()(const Point& p) const {
        size_t hx = std::hash<int>{}(p.x);
        size_t hy = std::hash<int>{}(p.y);
        // XOR with shift to reduce collisions between (x,y) and (y,x)
        return hx ^ (hy << 32) ^ (hy >> 32);
    }
};

std::unordered_map<Point, std::string, PointHash, PointEqual> grid;
grid[{1, 2}] = "treasure";
grid[{3, 4}] = "trap";
```

:::callout-warning[Warning — Worst-Case Attacks]
In competitive programming, adversaries can craft inputs where all keys collide in `std::unordered_map`, causing O(n²) behavior. Mitigate with a randomized hash (e.g., XOR with a random seed at startup). This is a real security concern for hash tables exposed to user input.
:::

:::example[Example 15.10 — Two Sum with unordered\_map]
Given array [2, 7, 11, 15] and target 9, find indices of two numbers that sum to target. Use O(n) time.

::::answer[Answer: indices 0 and 1 (values 2 + 7 = 9)]

::::

```cpp
std::vector<int> twoSum(std::vector<int>& nums, int target) {
    std::unordered_map<int, int> seen; // value → index
    for (int i = 0; i < (int)nums.size(); i++) {
        int complement = target - nums[i];
        if (seen.count(complement))
            return {seen[complement], i};
        seen[nums[i]] = i;
    }
    return {};
}
```

Each lookup and insert is O(1) average, so overall O(n) vs O(n²) for the naive nested loop.
:::

### Section 6 Practice

:::problem[Problem 6.1 easy]{difficulty="easy"}
What is the difference between `mp[key]` and `mp.at(key)` in `unordered_map`?

::::solution[Solution]
`mp[key]` inserts a default-constructed value if key doesn't exist (e.g., 0 for int, "" for string) — it never throws. `mp.at(key)` throws `std::out_of_range` if key is not found. Use `at()` when you need to assert the key exists; use `[]` when you want default-initialization behavior (e.g., counting frequencies).
::::
:::

:::problem[Problem 6.2 standard]{difficulty="standard"}
Write a function using `unordered_map` that finds the first non-repeating character in a string.

::::solution[Solution]
```cpp
char firstUnique(const std::string& s) {
    std::unordered_map<char, int> freq;
    for (char c : s) freq[c]++;
    for (char c : s)
        if (freq[c] == 1) return c;
    return '\0'; // none found
}
```

Two passes: O(n) time, O(k) space where k = alphabet size (at most 26 for lowercase English).
::::
:::

:::problem[Problem 6.3 challenge]{difficulty="challenge"}
Why does the XOR-based hash combiner `hx ^ (hy << 32)` work better than simply `hx ^ hy`?

::::solution[Solution]
Simple XOR is symmetric: hash(a,b) == hash(b,a). Points (3,5) and (5,3) would produce the same hash, causing unnecessary collisions for any table with symmetric key sets. Shifting hy by 32 bits before XOR makes the operation asymmetric — the x and y components occupy different bit positions, so (3,5) and (5,3) produce different hash values. In general, good hash combiners avoid symmetry and ensure mixing between all input bits.
::::
:::

## 7. Exam Prep

These questions cover the full chapter at exam depth. Work each one before revealing the answer.

:::problem[Q1 easy]{difficulty="easy"}
State the average-case time complexities for insert, search, and delete in (a) a chaining hash table and (b) an open-addressing hash table, both with α = O(1).

::::answer[Answer]
Both: **O(1) average** for all three operations when α is bounded by a constant. Worst case for both is O(n).
::::
:::

:::problem[Q2 easy]{difficulty="easy"}
What is the load factor of a hash table with 80 items and 100 slots?

::::answer[Answer]
$\alpha = 80/100 = 0.8$. This is above the typical 0.75 threshold for open addressing — a rehash would have been triggered already.
::::
:::

:::problem[Q3 standard]{difficulty="standard"}
Insert keys {5, 28, 19, 15, 20, 33, 12, 17, 10} into a hash table with m = 9, using h(k) = k mod 9 and chaining. Show all chains.

::::answer[Answer]
h(5)=5, h(28)=1, h(19)=1, h(15)=6, h(20)=2, h(33)=6, h(12)=3, h(17)=8, h(10)=1.

| Bucket | Chain |
| --- | --- |
| 0 | — |
| 1 | 10 → 19 → 28 |
| 2 | 20 |
| 3 | 12 |
| 4 | — |
| 5 | 5 |
| 6 | 33 → 15 |
| 7 | — |
| 8 | 17 |

α = 9/9 = 1. Bucket 1 has 3 items — a cluster.
::::
:::

:::problem[Q4 standard]{difficulty="standard"}
With m = 11, h₁(k) = k mod 11, h₂(k) = 7 − (k mod 7), use double hashing to insert 58, 14, 91, 25, 58... wait, 58 is a duplicate. Insert 58, then search for 58, then delete 58 and search again. What do you observe?

::::answer[Answer]
h₁(58) = 58 mod 11 = 3. Insert 58 at slot 3. Search(58): hash to slot 3, find key 58 → success. Delete(58): mark slot 3 as DELETED (tombstone). Search(58) again: hash to slot 3, state is DELETED (not EMPTY), so probe continues. Next probe: step = h₂(58) = 7 − (58 mod 7) = 7 − 2 = 5, go to slot (3+5) mod 11 = 8. Slot 8 is EMPTY → return "not found". The tombstone correctly allowed the search to terminate: if it were EMPTY, we'd still stop, but if another key was inserted at slot 8 earlier, the tombstone would have let us find it.
::::
:::

:::problem[Q5 standard]{difficulty="standard"}
Describe primary clustering and which probing strategy best avoids it.

::::answer[Answer]
**Primary clustering**: in linear probing, once a run of occupied slots forms, any key hashing into that run must probe past the entire run, extending it further. This creates long "chains" of occupied slots that grow superlinearly. **Double hashing** best avoids primary clustering because each key gets its own unique step size (h₂(k)), so keys that collide at h₁(k) diverge onto different probe sequences immediately after the first collision.
::::
:::

:::problem[Q6 standard]{difficulty="standard"}
Why do we use the next prime after 2m as the new size during rehashing?

::::answer[Answer]
Two reasons: (1) **Doubling** (×2) ensures the rehash cost is amortized O(1) per operation — growing by smaller amounts would require too-frequent rehashes. (2) **Prime size** improves distribution with division-method hashing. A prime modulus means keys don't share common factors with m, which prevents systematic clustering (e.g., even keys always landing in even slots if m is even).
::::
:::

:::problem[Q7 challenge]{difficulty="challenge"}
Compare chaining vs open addressing on: memory overhead, cache performance, and behavior as α increases.

::::answer[Answer]
**Memory**: Chaining needs extra pointer storage per node (8 bytes on 64-bit) — significant overhead for small values. Open addressing uses only the array itself — memory-efficient.

 **Cache**: Open addressing stores everything contiguously — excellent cache locality. Chaining traverses linked list nodes scattered in memory — poor cache locality per probe.

 **As α increases**: Chaining degrades gracefully — chains get longer, performance goes from O(1) to O(α). Open addressing degrades sharply near α=1 — probe sequences become very long. Chaining can handle α > 1 (more items than buckets); open addressing cannot.
::::
:::

:::problem[Q8 challenge]{difficulty="challenge"}
Design a hash function for C++ `std::pair<int,int>` that avoids the symmetric collision problem.

::::answer[Answer]
```cpp
struct PairHash {
    size_t operator()(const std::pair<int,int>& p) const {
        size_t seed = 0;
        // Boost-style hash combining
        seed ^= std::hash<int>{}(p.first) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        seed ^= std::hash<int>{}(p.second) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        return seed;
    }
};
```

The magic constant 0x9e3779b9 is derived from the golden ratio and ensures good bit mixing. The shifts and XOR pattern prevents symmetry: swapping first and second produces a different seed value at each step.
::::
:::

:::summary
## Chapter 15 Summary

### Core Concepts

- **Hash Table ADT**: implements dictionary (insert/search/delete) in O(1) average time using a hash function to map keys to array indices.
- **Load factor**: $\alpha = n/m$. Keeping α bounded ensures O(1) performance.
- **Hash function requirements**: uniform distribution, fast computation, deterministic. Division: h(k)=k mod m (use prime m). Multiplication method. Polynomial rolling hash for strings.

### Collision Resolution Comparison

| Property | Chaining | Open Addressing |
| --- | --- | --- |
| Storage | Separate linked lists | In-array only |
| Avg search | O(1 + α) | O(1/(1−α)) linear probing |
| Max α | Any (> 1 OK) | Must be < 1 |
| Deletion | Easy (list remove) | Tombstone required |
| Cache | Poor (pointer hops) | Excellent (contiguous) |
| Memory overhead | High (pointers) | Low |
| Clustering | None | Primary / secondary |

### Probing Strategies

- **Linear**: h(k,i) = (h(k)+i) mod m — simple, primary clustering
- **Quadratic**: h(k,i) = (h(k)+c₁i+c₂i²) mod m — secondary clustering
- **Double hashing**: h(k,i) = (h₁(k)+i·h₂(k)) mod m — best distribution

### Rehashing

Trigger at α > 0.75 (open) or α > 2 (chaining). New size = next prime after 2m. Re-insert all items. Amortized O(1) per insert across n operations.

### C++ STL

- `std::unordered_map<K,V>` — hash map
- `std::unordered_set<K>` — hash set
- Use `reserve(n)`, `max_load_factor(f)` to tune performance
- Provide custom hash functor for non-standard key types
:::
