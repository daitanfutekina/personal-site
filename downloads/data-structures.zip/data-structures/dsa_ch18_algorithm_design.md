---
title: "Algorithm Design Paradigms"
crumb: "Honors DSA · Chapter 18"
meta:
  - "Est. study time: ~80 min"
  - "Unit 6"
  - "CSE 2383 · MSState"
source: "dsa_ch18_algorithm_design.html"
---

## 1. Divide & Conquer

The **divide and conquer** paradigm solves problems by recursively breaking them into smaller subproblems, solving each independently, then combining results.

Pattern: **Divide** the input into subproblems → **Conquer** each recursively → **Combine** solutions.

### Classic Examples

- **Merge Sort**: divide array in half, sort each half, merge in O(n) → T(n) = 2T(n/2) + O(n)
- **Binary Search**: check midpoint, recurse on one half → T(n) = T(n/2) + O(1)
- **Strassen's Matrix Multiply**: 7 recursive multiplications instead of 8 → T(n) = 7T(n/2) + O(n²)
- **Closest Pair of Points**: split by x-coordinate, solve each half, check strip → O(n log n)

:::callout-key[Key Requirement]
Divide and conquer works best when subproblems are *independent* (no overlap). When subproblems overlap (same subproblem computed many times), dynamic programming is more efficient.
:::

:::example[Example 18.1 — Merge Sort Recurrence]
Write the recurrence for merge sort and explain each term.

::::answer[Answer]
T(n) = 2T(n/2) + O(n), solving to T(n) = O(n log n).
::::

Work

2T(n/2): we make two recursive calls on halves of size n/2. O(n): the merge step scans both halves once. The Master Theorem Case 2 applies (a=2, b=2, f(n)=n, n^log₂2 = n¹ = n = f(n)), giving Θ(n log n).
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Write the recurrence for binary search on an array of size n.

::::solution[Solution]
T(n) = T(n/2) + O(1). We check the middle element (O(1)) then recurse on one half. By Master Theorem Case 2 (a=1, b=2, f(n)=1, n^log₂1 = 1 = f(n)): T(n) = O(log n).
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Why is divide and conquer often implemented recursively? What is the main risk?

::::solution[Solution]
Recursion naturally expresses the "divide, conquer subproblems, combine" structure. The main risk is stack overflow for large n if recursion depth is O(n) (e.g., quicksort on sorted input). Solutions: tail recursion optimization, iterative bottom-up implementation, or random pivot selection.
::::
:::

## 2. Master Theorem

The Master Theorem solves recurrences of the form **T(n) = aT(n/b) + f(n)** where a ≥ 1, b > 1.

- **a**: number of subproblems
- **b**: factor by which input shrinks
- **f(n)**: cost of the work outside recursive calls

Let **c = log~b~(a)** (the "critical exponent"). Compare f(n) to n^c^:

| Case | Condition | Solution | Meaning |
| --- | --- | --- | --- |
| Case 1 | f(n) = O(n^(c−ε)) | T(n) = Θ(n^c) | Recursion dominates |
| Case 2 | f(n) = Θ(n^c) | T(n) = Θ(n^c · log n) | Both equal; log factor added |
| Case 3 | f(n) = Ω(n^(c+ε)) + regularity | T(n) = Θ(f(n)) | Combine step dominates |

:::example[Example 18.2 — Applying Master Theorem]
Solve: (a) T(n) = 4T(n/2) + n (b) T(n) = 4T(n/2) + n² (c) T(n) = 4T(n/2) + n³

::::answer[Answer]
(a) Θ(n²) (b) Θ(n² log n) (c) Θ(n³)
::::

Work

```
(a) a=4, b=2, c=log₂4=2. f(n)=n=O(n^(2-1)). Case 1 → T(n)=Θ(n²).
(b) a=4, b=2, c=2. f(n)=n²=Θ(n²). Case 2 → T(n)=Θ(n² log n).
(c) a=4, b=2, c=2. f(n)=n³=Ω(n^(2+1)). Check regularity: 4·(n/2)³=n³/2 ≤ cn³ ✓. Case 3 → T(n)=Θ(n³).
```
:::

:::callout-pitfall[Common Pitfall]
Case 3 requires a **regularity condition**: a·f(n/b) ≤ c·f(n) for some c < 1 and large n. Most polynomial f(n) satisfy this, but f(n) = n/log n does not. Always verify regularity for Case 3.
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Solve T(n) = 3T(n/3) + n using the Master Theorem.

::::solution[Solution]
a=3, b=3, c=log₃3=1. f(n)=n=Θ(n¹)=Θ(n^c). Case 2 → T(n) = Θ(n log n).
::::
:::

:::problem[Problem 4 · standard]{difficulty="standard"}
Solve T(n) = 2T(n/4) + 1 using the Master Theorem.

::::solution[Solution]
a=2, b=4, c=log₄2=0.5. f(n)=1=O(n^(0.5−0.5))=O(1). Case 1 → T(n) = Θ(n^0.5) = Θ(√n).
::::
:::

:::problem[Problem 5 · challenge]{difficulty="challenge"}
Strassen's matrix multiplication has recurrence T(n) = 7T(n/2) + O(n²). What is its complexity?

::::solution[Solution]
a=7, b=2, c=log₂7 ≈ 2.807. f(n)=n²=O(n^(2.807−0.807)). Case 1 → T(n) = Θ(n^log₂7) ≈ Θ(n^2.807). Better than naive O(n³).
::::
:::

## 3. Dynamic Programming — Principles

Dynamic programming (DP) applies when a problem has two properties:

- **Overlapping subproblems**: the same smaller problems are solved multiple times
- **Optimal substructure**: the optimal solution to the problem contains optimal solutions to subproblems

### Top-Down (Memoization)

Write the recursive solution, then cache results. Simple to implement from the recurrence directly.

```cpp
unordered_map<int,long long> memo;
long long fib(int n) {
    if (n <= 1) return n;
    if (memo.count(n)) return memo[n];
    return memo[n] = fib(n-1) + fib(n-2);
}
```

### Bottom-Up (Tabulation)

Fill a table iteratively, starting from base cases. More efficient (no recursion overhead).

```cpp
long long fib(int n) {
    if (n <= 1) return n;
    vector<long long> dp(n+1);
    dp[0]=0; dp[1]=1;
    for (int i=2; i<=n; i++) dp[i] = dp[i-1]+dp[i-2];
    return dp[n];
}
```

:::callout-intuition[State Design]
The hardest part of DP is defining the *state*. Ask: what information do I need to solve a subproblem? The state must capture enough to derive the answer, but be small enough to be tractable. For most 1D problems: dp[i] = answer for first i elements.
:::

:::problem[Problem 6 · easy]{difficulty="easy"}
Why is naive recursive Fibonacci O(2^n) while memoized Fibonacci is O(n)?

::::solution[Solution]
Naive recursion recomputes fib(k) exponentially many times — the recursion tree has O(2^n) nodes. Memoization computes each fib(k) exactly once (O(n) unique subproblems), looking up cached results in O(1) each time. Total: O(n) time, O(n) space.
::::
:::

## 4. DP — Classic Problems

### Longest Common Subsequence (LCS)

Given strings A and B, find the length of the longest subsequence common to both. *Subsequence*: characters in order, not necessarily contiguous.

State: `dp[i][j]` = LCS length of A[0..i-1] and B[0..j-1].

Recurrence: if A[i-1]==B[j-1]: dp[i][j] = dp[i-1][j-1]+1; else dp[i][j] = max(dp[i-1][j], dp[i][j-1]).

Time: O(mn). Space: O(mn), optimizable to O(min(m,n)).

### 0/1 Knapsack

n items with weights w[i] and values v[i]. Capacity W. Maximize value without exceeding capacity. Each item used at most once.

State: `dp[i][w]` = max value using first i items with capacity w.

Recurrence: dp[i][w] = max(dp[i-1][w], dp[i-1][w-w[i]] + v[i]) if w[i] ≤ w, else dp[i-1][w].

Time: O(nW). Space: O(nW), optimizable to O(W).

### Edit Distance (Levenshtein)

Minimum insert/delete/replace operations to transform string A into B.

State: `dp[i][j]` = edit distance between A[0..i-1] and B[0..j-1].

Recurrence: if A[i-1]==B[j-1]: dp[i][j]=dp[i-1][j-1]; else min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+1).

:::example[Example 18.3 — 0/1 Knapsack]
Items: weights=[1,3,4,5], values=[1,4,5,7], capacity W=7. Find max value.

::::answer[Answer]
Max value = 9 (items with weight 3 and 4, values 4+5=9).
::::

Work

```
Fill dp[i][w] table (4 items, capacity 0..7):
       w=0  1  2  3  4  5  6  7
item1:  0   1  1  1  1  1  1  1   (weight=1, val=1)
item2:  0   1  1  4  5  5  5  5   (weight=3, val=4)
item3:  0   1  1  4  5  6  6  9   (weight=4, val=5)
item4:  0   1  1  4  5  7  8  9   (weight=5, val=7)
dp[4][7] = 9.
```
:::

:::problem[Problem 7 · standard]{difficulty="standard"}
LCS of "ABCBDAB" and "BDCAB"? Use DP to find the length.

::::solution[Solution]
LCS length = 4. One LCS is "BCAB" or "BDAB". Fill the 7×5 DP table: dp[7][5]=4.
::::
:::

:::problem[Problem 8 · standard]{difficulty="standard"}
Edit distance from "kitten" to "sitting"?

::::solution[Solution]
Edit distance = 3. Operations: kitten → sitten (k→s), sitten → sittin (e→i), sittin → sitting (insert g).
::::
:::

:::problem[Problem 9 · challenge]{difficulty="challenge"}
What is the difference between the 0/1 knapsack and the fractional knapsack? Which one requires DP?

::::solution[Solution]
0/1 knapsack: each item either included entirely or not (binary choice). Fractional: can take any fraction of an item. Fractional knapsack is solved greedily (take items by value/weight ratio) in O(n log n). 0/1 knapsack has no greedy solution — it requires DP in O(nW). The difference: fractional satisfies the greedy choice property; 0/1 does not.
::::
:::

## 5. Greedy Algorithms

A **greedy algorithm** makes the locally optimal choice at each step, hoping it leads to a globally optimal solution. It works when the problem has:

- **Greedy choice property**: a globally optimal solution can be constructed by making locally optimal choices
- **Optimal substructure**: optimal solution contains optimal solutions to subproblems

### Activity Selection

Given n activities with start and end times, select the maximum number of non-overlapping activities. Greedy: always pick the activity that finishes earliest.

### Huffman Coding

Optimal prefix-free encoding. Build a min-heap of characters by frequency. Repeatedly merge the two lowest-frequency nodes. Result: shortest total encoded length.

:::example[Example 18.4 — Activity Selection]
Activities (start, end): (1,4),(3,5),(0,6),(5,7),(3,9),(5,9),(6,10),(8,11),(8,12),(2,14),(12,16). Select maximum non-overlapping set.

::::answer[Answer]
Maximum 4 activities: (1,4),(5,7),(8,11),(12,16).
::::

Work

Sort by end time: (1,4),(3,5),(0,6),(5,7),(3,9),(5,9),(6,10),(8,11),(8,12),(2,14),(12,16). Pick (1,4). Next ending after 4: (5,7). Next ending after 7: (8,11). Next ending after 11: (12,16). Total: 4.
:::

:::problem[Problem 10 · standard]{difficulty="standard"}
Why does the "earliest finish time" greedy strategy for activity selection produce an optimal result?

::::solution[Solution]
Exchange argument: suppose an optimal solution picks activity x instead of the earliest-finishing activity y. Since y finishes no later than x, replacing x with y in the optimal solution still leaves all subsequent activities compatible, and doesn't decrease the count. So the greedy choice is at least as good.
::::
:::

## 6. Greedy vs Dynamic Programming

| Property | Greedy | Dynamic Programming |
| --- | --- | --- |
| Approach | One pass, local decisions | Solve all subproblems, combine |
| Time | Usually O(n log n) or O(n) | Usually O(n²) or O(n·W) |
| Correctness | Requires proof (exchange arg) | Correct if recurrence is right |
| Works for | Activity selection, Huffman, Dijkstra, fractional knapsack | 0/1 knapsack, LCS, edit distance, matrix chain |

:::callout-pitfall[Classic Mistake]
Applying greedy to 0/1 knapsack fails. Example: capacity=10, items={(weight=6,val=12),(weight=5,val=10),(weight=5,val=10)}. Greedy by density picks the 6-item (val/weight=2) and then can't fit anything else → value=12. Optimal: take both weight-5 items → value=20.
:::

## 7. Backtracking

Backtracking is a systematic search that builds solutions incrementally and abandons (prunes) partial solutions that cannot possibly lead to valid completions.

### N-Queens Problem

Place n queens on an n×n board so no two attack each other. Backtracking: place queens row by row. If a column causes a conflict, try the next column; if no column works, backtrack to the previous row.

```cpp
bool solve(int row, int n, vector<int>& cols) {
    if (row == n) return true; // all queens placed
    for (int col = 0; col < n; col++) {
        if (isSafe(row, col, cols)) {
            cols[row] = col;
            if (solve(row+1, n, cols)) return true;
            cols[row] = -1; // backtrack
        }
    }
    return false;
}
```

:::callout-key[Pruning Effectiveness]
Without pruning, exhaustive search tries all n^n column assignments. With backtracking, many branches are cut early. N-queens with backtracking runs in roughly O(n!) but with pruning in practice is much faster — feasible for n ≤ 15.
:::

## 8. Complexity Classes (P, NP, NP-Complete)

| Class | Definition | Example Problems |
| --- | --- | --- |
| **P** | Decidable in polynomial time | Sorting, shortest path, MST |
| **NP** | Verifiable in polynomial time | 3-SAT, Hamiltonian path, subset sum |
| **NP-complete** | In NP and every NP problem reduces to it | 3-SAT, clique, vertex cover, TSP (decision) |
| **NP-hard** | At least as hard as NP-complete; may not be in NP | Halting problem, optimization versions of NP-complete |

The central open question: **P =? NP**. Most researchers believe P ≠ NP, but it remains unproven.

:::callout-connect[Practical Implication]
For NP-complete problems, we can't (likely) solve them exactly in polynomial time. In practice: use approximation algorithms, heuristics, or exponential algorithms with good pruning. Recognizing NP-complete problems prevents wasting time searching for a polynomial solution.
:::

## 9. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
Solve T(n) = 2T(n/2) + n² using the Master Theorem.

::::solution[Solution]
a=2, b=2, c=log₂2=1. f(n)=n²=Ω(n^(1+1)). Regularity: 2·(n/2)²=n²/2 ≤ (1/2)·n² ✓. Case 3 → T(n)=Θ(n²).
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
What are the two necessary conditions for DP to apply? Give an example problem for each.

::::solution[Solution]
(1) Optimal substructure: optimal solution contains optimal sub-solutions. Example: shortest paths (subpaths of shortest paths are shortest paths). (2) Overlapping subproblems: same subproblems recur. Example: Fibonacci — fib(n-2) is needed by both fib(n) and fib(n-1).
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
What is the time and space complexity of the classic 0/1 Knapsack DP solution?

::::solution[Solution]
Time: O(nW) where n = number of items, W = capacity. Space: O(nW) for the full table; optimizable to O(W) by using only two rows (current and previous). Note: O(nW) is pseudo-polynomial — polynomial in the numeric value of W, but exponential in the number of bits to represent W.
::::
:::

:::problem[Exam Q4 · challenge]{difficulty="challenge"}
Describe the exchange argument used to prove greedy algorithms correct. Apply it to activity selection.

::::solution[Solution]
Exchange argument: take any optimal solution OPT. Show you can transform it to match the greedy solution without decreasing its quality. For activity selection: if OPT picks activity x as its first activity and greedy picks y (earliest finish), since finish(y) ≤ finish(x), swapping x for y in OPT still allows all subsequent activities. So greedy's choice is at least as good, and by induction the greedy solution is optimal.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
What does it mean for a problem to be NP-complete?

::::solution[Solution]
A problem X is NP-complete if: (1) X is in NP (a given solution can be verified in polynomial time), and (2) every problem in NP can be reduced to X in polynomial time (X is NP-hard). This means X is among the "hardest" problems in NP — if any NP-complete problem is solvable in polynomial time, then P = NP.
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
Compare divide-and-conquer and dynamic programming. When does each apply?

::::solution[Solution]
Both decompose problems recursively. Key difference: D&C works when subproblems are *independent* (no overlap) — merge sort halves never share elements. DP works when subproblems *overlap* — Fibonacci sub-calls share fib(n-2). Using D&C on overlapping subproblems leads to exponential time; DP caches results for O(n) time. DP additionally requires optimal substructure.
::::
:::

:::problem[Exam Q7 · standard]{difficulty="standard"}
Solve T(n) = T(n-1) + n using substitution (not Master Theorem — it doesn't apply here).

::::solution[Solution]
Expand: T(n) = T(n-1)+n = T(n-2)+(n-1)+n = ... = T(1)+2+3+...+n = 1 + n(n+1)/2 − 1 = O(n²). This is the insertion sort recurrence.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
Explain the coin change problem as a DP. Given coins [1,5,6,9] and target 11, what is the minimum number of coins?

::::solution[Solution]
State: dp[i] = minimum coins to make amount i. Base: dp[0]=0. Recurrence: dp[i] = min over all coins c where c≤i of (dp[i-c]+1).
dp[1]=1(1), dp[2]=2, dp[3]=3, dp[4]=4, dp[5]=1(5), dp[6]=1(6), dp[7]=2(1+6), dp[8]=3, dp[9]=1(9), dp[10]=2(1+9), dp[11]=2(5+6). Answer: 2 coins.
::::
:::

:::summary
## Chapter 18 Summary

| Paradigm | Key Property | Time | Examples |
| --- | --- | --- | --- |
| Divide & Conquer | Independent subproblems | Master Theorem | Merge sort, binary search |
| Dynamic Programming | Overlapping subproblems + optimal substructure | O(states × transitions) | Knapsack, LCS, edit distance |
| Greedy | Greedy choice property + optimal substructure | O(n log n) typical | Activity selection, Huffman, Dijkstra |
| Backtracking | Exhaustive search with pruning | Exponential (pruned) | N-queens, subset sum |

### Master Theorem Quick Reference

T(n) = aT(n/b) + f(n), c = log~b~a:

- f(n) = O(n^(c−ε)) → **Θ(n^c)**
- f(n) = Θ(n^c) → **Θ(n^c log n)**
- f(n) = Ω(n^(c+ε)) + regularity → **Θ(f(n))**
:::
