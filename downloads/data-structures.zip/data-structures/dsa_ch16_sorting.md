---
title: "Sorting Algorithms"
crumb: "Honors DSA · Chapter 16"
meta:
  - "Est. study time: ~75 min"
  - "Unit 5"
  - "CSE 2383 · MSState"
source: "dsa_ch16_sorting.html"
---

## 1. The Sorting Problem & Terminology

Given a sequence of *n* elements from a totally ordered set, **sorting** rearranges them into non-decreasing order. Sorting is ubiquitous: databases index records, binary search requires sorted input, graph algorithms sort edges, and compilers sort symbol tables. A solid understanding of sorting complexities and trade-offs is essential for every technical interview.

:::definition[Definition 16.1 — Key Properties]
- **In-place:** uses only $O(1)$ extra memory beyond the input array.
- **Stable:** equal elements retain their original relative order.
- **Comparison-based:** the only access to element values is via pairwise comparisons.
- **Adaptive:** runs faster on inputs that are already partially sorted.
:::

:::callout-key[Why These Properties Matter]
Stability matters when sorting records by secondary keys (e.g., sort employees by department, then by salary — a stable sort preserves the salary ordering within each department). In-place matters when memory is tight. Adaptiveness gives insertion sort practical advantages over merge sort on nearly-sorted data despite the same asymptotic class.
:::

| Algorithm | In-place? | Stable? | Adaptive? | Best case |
| --- | --- | --- | --- | --- |
| Insertion Sort | Yes | Yes | Yes | $O(n)$ |
| Selection Sort | Yes | No | No | $O(n^2)$ |
| Bubble Sort | Yes | Yes | Yes | $O(n)$ |
| Merge Sort | No | Yes | No | $O(n \log n)$ |
| Quicksort | Yes | No | No | $O(n \log n)$ |
| Heapsort | Yes | No | No | $O(n \log n)$ |
| Counting Sort | No | Yes | — | $O(n+k)$ |

## 2. O(n²) Sorts — Insertion Sort

:::callout-intuition[Intuition]
Think of sorting a hand of playing cards: you pick up one card at a time and slide it left until it is in the right position among the cards you are already holding. The sorted portion grows one element per step.
:::

### Algorithm

```cpp
// Sorts array A[0..n-1] in non-decreasing order
void insertionSort(int A[], int n) {
    for (int i = 1; i < n; i++) {
        int key = A[i];
        int j = i - 1;
        // Shift elements greater than key one position right
        while (j >= 0 && A[j] > key) {
            A[j + 1] = A[j];
            j--;
        }
        A[j + 1] = key;
    }
}
```

### Complexity Analysis

- **Best case $O(n)$:** already sorted — inner while loop never executes.
- **Worst case $O(n^2)$:** reverse sorted — each element shifts past all previous elements.
- **Average case $O(n^2)$:** on random input, each insert shifts about half the sorted portion.
- **Space:** $O(1)$ in-place.
- **Stable:** yes — equal elements are never swapped past each other (strict $>$ in condition).

:::callout-key[When to Use Insertion Sort]
Insertion sort wins in practice for **small n** (typically n < 16) because its constants are tiny and it has excellent cache behavior. This is why standard library implementations of quicksort and merge sort switch to insertion sort for small subarrays. It is also ideal for nearly-sorted data, where its adaptive nature achieves close to O(n) performance.
:::

:::example[Example 16.1 — Insertion Sort Trace]
Trace insertion sort on the array `[5, 2, 4, 6, 1, 3]`. Show the array after each outer iteration.

::::answer[Answer]
After i=1: [2, 5, 4, 6, 1, 3] (2 inserted before 5)

 After i=2: [2, 4, 5, 6, 1, 3] (4 inserted between 2 and 5)

 After i=3: [2, 4, 5, 6, 1, 3] (6 already in place)

 After i=4: [1, 2, 4, 5, 6, 3] (1 shifts to front)

 After i=5: [1, 2, 3, 4, 5, 6] (3 inserted between 2 and 4)
::::

Work

At each step i, the subarray A[0..i] is sorted. For i=4, key=1: A[3]=6>1 shift, A[2]=5>1 shift, A[1]=4>1 shift, A[0]=2>1 shift, j becomes -1, place at index 0. Total shifts: 0+1+0+4+2 = 7 shifts.
:::

### Practice — Insertion Sort

:::problem[Problem 1 · easy]{difficulty="easy"}
How many comparisons does insertion sort make on the array `[1, 2, 3, 4, 5]` (already sorted)?

::::solution[Solution]
Exactly **n-1 = 4** comparisons. At each step i, the while loop executes once (checking A[j] > key fails immediately), so there is 1 comparison per outer iteration × 4 iterations = 4 total.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Trace insertion sort on `[3, 1, 4, 1, 5, 9, 2, 6]`. How many total element shifts occur?

::::solution[Solution]
Pass by pass: i=1 key=1: shift 3 → 1 shift. i=2 key=4: 0 shifts. i=3 key=1: shift 4,3 → 2 shifts. i=4 key=5: 0 shifts. i=5 key=9: 0 shifts. i=6 key=2: shift 9,5,4,3 → 4 shifts. i=7 key=6: shift 9 → 1 shift. Total: **8 shifts**. Result: [1,1,2,3,4,5,6,9].
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Prove that the number of comparisons made by insertion sort equals the number of *inversions* in the array plus (n-1). (An inversion is a pair (i,j) with i < j but A[i] > A[j].)

::::solution[Solution]
For each outer iteration i, the inner while loop makes exactly (number of inversions involving A[i] with elements A[0..i-1]) + 1 comparisons — the "+1" is the final comparison that stops the loop (or the one implicit comparison when j < 0 check fails). Summing across all i from 1 to n-1: total comparisons = (total inversions) + (n-1). Since a fully sorted array has 0 inversions, this gives exactly n-1 comparisons, confirming the O(n) best case.
::::
:::

## 3. O(n²) Sorts — Selection & Bubble Sort

### Selection Sort

Find the minimum element in the unsorted portion and swap it to its final position. Repeat.

```cpp
void selectionSort(int A[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++)
            if (A[j] < A[minIdx]) minIdx = j;
        std::swap(A[i], A[minIdx]);
    }
}
```

- **Always $O(n^2)$** comparisons regardless of input — no best case benefit.
- **O(n) swaps** — only n-1 swaps total, which is optimal. Good when writes are expensive.
- **Not stable:** swapping can move equal elements out of order.

:::callout-pitfall[Common Misconception]
Selection sort is *not* stable. Example: [2a, 2b, 1] — selecting minimum 1 at index 2 and swapping with index 0 gives [1, 2b, 2a], reversing the two equal elements.
:::

### Bubble Sort

Repeatedly scan the array swapping adjacent out-of-order elements. Each pass "bubbles" the next largest element to its final position.

```cpp
void bubbleSort(int A[], int n) {
    for (int i = 0; i < n - 1; i++) {
        bool swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (A[j] > A[j+1]) {
                std::swap(A[j], A[j+1]);
                swapped = true;
            }
        }
        if (!swapped) break;  // Early termination: already sorted
    }
}
```

- **Best case $O(n)$** with early-termination flag (already sorted: 0 swaps, break after first pass).
- **Worst case $O(n^2)$** — reverse sorted.
- **Stable:** only swaps when strictly greater, so equal elements never swap.
- Rarely used in practice — even insertion sort is faster in the average case.

### Practice — Selection & Bubble

:::problem[Problem 4 · easy]{difficulty="easy"}
Trace one full pass of bubble sort on `[4, 3, 2, 1]` (left to right). What does the array look like after pass 1?

::::solution[Solution]
Compare A[0]=4 and A[1]=3: swap → [3,4,2,1]. Compare A[1]=4 and A[2]=2: swap → [3,2,4,1]. Compare A[2]=4 and A[3]=1: swap → [3,2,1,4]. After pass 1: **[3, 2, 1, 4]**. The largest element (4) has bubbled to the end.
::::
:::

:::problem[Problem 5 · standard]{difficulty="standard"}
How many comparisons does selection sort make on any array of size 8, regardless of input values?

::::solution[Solution]
Selection sort makes exactly $\frac{n(n-1)}{2}$ comparisons always. For n=8: $\frac{8 \times 7}{2} = \mathbf{28}$ comparisons. This is because the inner loop runs n-1, n-2, ..., 1 times = sum = n(n-1)/2.
::::
:::

:::problem[Problem 6 · challenge]{difficulty="challenge"}
Design a version of selection sort that is stable. (Hint: instead of swapping, shift elements.)

::::solution[Solution]
Instead of swapping the minimum to position i, *insert* it there by shifting intermediate elements one position right (like insertion sort). Find minIdx, save A[minIdx], shift A[i..minIdx-1] right by one, place saved value at A[i]. This preserves relative order of equal elements but increases swaps from O(n) to O(n²).
::::
:::

## 4. Merge Sort

:::callout-intuition[Intuition]
Divide the array in half, recursively sort each half, then merge the two sorted halves into one sorted array. The merge step does the real work: compare the fronts of both halves and output the smaller, advancing its pointer.
:::

### Recurrence and Complexity

The recurrence is $T(n) = 2T(n/2) + O(n)$. By the Master Theorem (Case 2): $a=2, b=2, f(n)=n, n^{\log_b a} = n^1 = n$, so $T(n) = O(n \log n)$ in all cases.

```cpp
void merge(int A[], int l, int m, int r) {
    int n1 = m - l + 1, n2 = r - m;
    std::vector<int> L(A+l, A+l+n1), R(A+m+1, A+m+1+n2);
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2)
        A[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];
    while (i < n1) A[k++] = L[i++];
    while (j < n2) A[k++] = R[j++];
}

void mergeSort(int A[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(A, l, m);
        mergeSort(A, m + 1, r);
        merge(A, l, m, r);
    }
}
```

### Properties

- **Time:** $O(n \log n)$ best, average, and worst — guaranteed.
- **Space:** $O(n)$ auxiliary — requires a temporary array for merging.
- **Stable:** yes — the merge step uses $\leq$ (not $<$) to prefer left subarray on ties.
- **Not adaptive:** always takes $O(n \log n)$ even on sorted input.

### Bottom-up vs Top-down

**Top-down** (recursive) splits at the midpoint recursively. **Bottom-up** (iterative) starts with subarrays of size 1 and doubles the merge width each pass (1, 2, 4, 8, ...). Both have the same asymptotic complexity; bottom-up avoids recursion overhead and stack space.

:::example[Example 16.2 — Merge Sort Trace]
Show the merge sort recursion tree and merge steps for `[38, 27, 43, 3]`.

::::answer[Answer]
Split: [38,27] | [43,3]. Split again: [38] [27] and [43] [3]. Merge [38][27] → [27,38]. Merge [43][3] → [3,43]. Merge [27,38][3,43] → [3,27,38,43].
::::

Work

Final merge: compare 27 vs 3 → take 3; compare 27 vs 43 → take 27; compare 38 vs 43 → take 38; take 43. Result: [3, 27, 38, 43]. 3 comparisons in the final merge + 1 + 1 in earlier merges = 5 total comparisons.
:::

### Practice — Merge Sort

:::problem[Problem 7 · easy]{difficulty="easy"}
What is the maximum number of comparisons made in merging two sorted arrays of sizes 4 and 4?

::::solution[Solution]
At most **7** comparisons. The merge terminates when one array is exhausted. In the worst case (e.g., [1,3,5,7] and [2,4,6,8]), every element is compared before exhaustion: 7 comparisons (one element remains and is appended without comparison).
::::
:::

:::problem[Problem 8 · standard]{difficulty="standard"}
Trace merge sort on `[5, 1, 8, 3, 7, 2]`. Show the array at each merge step.

::::solution[Solution]
Split: [5,1,8] and [3,7,2]. Split [5,1,8]: [5,1] and [8]. Split [5,1]: [5] and [1]. Merge [5][1]→[1,5]. Merge [1,5][8]→[1,5,8]. Split [3,7,2]: [3,7] and [2]. Split [3,7]: [3] and [7]. Merge [3][7]→[3,7]. Merge [3,7][2]→[2,3,7]. Final merge [1,5,8][2,3,7]→**[1,2,3,5,7,8]**.
::::
:::

:::problem[Problem 9 · challenge]{difficulty="challenge"}
Explain how to use merge sort to count the number of inversions in an array in $O(n \log n)$ time.

::::solution[Solution]
During the merge step, whenever we take an element from the *right* subarray before exhausting the left subarray, that right element is smaller than all remaining left elements — each such event contributes (remaining left elements) inversions. Accumulate this count across all merge steps. Total inversions = number of such out-of-order picks summed across all merges. Time: O(n log n) since it piggybacks on the merge sort work.
::::
:::

## 5. Quicksort

:::callout-intuition[Intuition]
Choose a pivot element. Partition the array so all elements smaller than the pivot appear before it, all larger elements after. Then recursively sort each partition. Unlike merge sort, all the work happens during partition — merge is trivial (just concatenate).
:::

```cpp
int partition(int A[], int l, int r) {
    int pivot = A[r];   // Last element as pivot
    int i = l - 1;
    for (int j = l; j < r; j++) {
        if (A[j] <= pivot) {
            i++;
            std::swap(A[i], A[j]);
        }
    }
    std::swap(A[i+1], A[r]);
    return i + 1;   // Pivot's final index
}

void quickSort(int A[], int l, int r) {
    if (l < r) {
        int pi = partition(A, l, r);
        quickSort(A, l, pi - 1);
        quickSort(A, pi + 1, r);
    }
}
```

### Complexity Analysis

- **Best/Average case $O(n \log n)$:** pivot consistently splits array near the middle. Recurrence: $T(n) = 2T(n/2) + O(n)$.
- **Worst case $O(n^2)$:** pivot is always the minimum or maximum (sorted or reverse-sorted input with first/last pivot). Recurrence: $T(n) = T(n-1) + O(n)$.
- **Space:** $O(\log n)$ average (recursion stack depth); $O(n)$ worst case.
- **Not stable:** the partition step swaps non-adjacent elements.
- **In-place:** yes (partitioning uses only index variables).

### Pivot Selection Strategies

| Strategy | Worst-Case Input | Notes |
| --- | --- | --- |
| First element | Already sorted | Simple; terrible in practice |
| Last element | Already sorted or reverse sorted | Simple; same problem |
| Random element | None (with high probability) | Reduces to O(n log n) expected |
| Median-of-three | Adversarial construction | Used by most libraries; good in practice |

:::callout-warning[Worst Case in Practice]
Quicksort on a sorted array with the last-element pivot is O(n²). This is a common interview trap. Always mention random pivot or median-of-three when discussing quicksort performance. Also note: quicksort's average constant factor is smaller than merge sort's, which is why it wins in practice despite the same asymptotic average complexity.
:::

:::example[Example 16.3 — Quicksort Partition Trace]
Partition `[3, 6, 8, 10, 1, 2, 1]` using the last element (1) as pivot. Show the state of i and j at each step.

::::answer[Answer]
Pivot = 1. i starts at -1. j=0: A[0]=3 > 1, no swap. j=1: A[1]=6 > 1, no swap. j=2: A[2]=8 > 1, no swap. j=3: A[3]=10 > 1, no swap. j=4: A[4]=1 <= 1, i=0, swap A[0] and A[4] → [1,6,8,10,3,2,1]. j=5: A[5]=2 > 1, no swap. End: swap A[i+1]=A[1] with A[r]=A[6]: [1,1,8,10,3,2,6]. Pivot at index 1.
::::
:::

### Practice — Quicksort

:::problem[Problem 10 · standard]{difficulty="standard"}
For quicksort with last-element pivot, what is the worst-case input for an array of 5 distinct elements? How many comparisons does it make?

::::solution[Solution]
Worst case: **already sorted**, e.g., [1,2,3,4,5]. Each partition picks the largest element as pivot, creating partitions of size n-1 and 0. Comparisons: (n-1) + (n-2) + ... + 1 = $\frac{n(n-1)}{2} = \frac{5 \times 4}{2} = \mathbf{10}$ comparisons.
::::
:::

:::problem[Problem 11 · challenge]{difficulty="challenge"}
Trace quicksort (last-element pivot) on `[2, 8, 7, 1, 3, 5, 6, 4]`. Show the pivot placements at each level of recursion.

::::solution[Solution]
Level 0: pivot=4. Partition: elements <=4 are {2,1,3,4}, >4 are {8,7,5,6}. Result: [2,1,3,**4**,7,5,6,8] (4 at index 3). Level 1 left [2,1,3] pivot=3: [2,1,**3**]. Level 1 right [7,5,6,8] pivot=8: [7,5,6,**8**]. Level 2: [2,1] pivot=1: [**1**,2]. [7,5,6] pivot=6: [5,**6**,7]. Final: [1,2,3,4,5,6,7,8].
::::
:::

## 6. Quicksort Optimizations

### Insertion Sort for Small Subarrays

When the subarray size falls below a threshold (typically 8–16 elements), switch to insertion sort. This eliminates recursion overhead and exploits insertion sort's cache-friendly sequential access.

```cpp
void quickSort(int A[], int l, int r) {
    if (r - l < 16) { insertionSort(A + l, r - l + 1); return; }
    int pi = partition(A, l, r);
    quickSort(A, l, pi - 1);
    quickSort(A, pi + 1, r);
}
```

### Tail Recursion Elimination

Always recurse on the smaller partition first, then loop on the larger. This guarantees $O(\log n)$ stack depth even in the worst case for the recursion, because the smaller partition has at most n/2 elements.

### 3-Way Partitioning (Dutch National Flag)

When arrays have many duplicate keys, standard quicksort degrades. 3-way partitioning creates three regions: less-than, equal-to, and greater-than the pivot. Elements equal to the pivot are already in their final positions.

```cpp
// 3-way partition: A[l..lt-1] < pivot, A[lt..gt] == pivot, A[gt+1..r] > pivot
void quickSort3(int A[], int l, int r) {
    if (l >= r) return;
    int pivot = A[l], lt = l, i = l + 1, gt = r;
    while (i <= gt) {
        if      (A[i] < pivot)  std::swap(A[lt++], A[i++]);
        else if (A[i] > pivot)  std::swap(A[i],    A[gt--]);
        else                    i++;
    }
    quickSort3(A, l,    lt - 1);
    quickSort3(A, gt + 1, r);
}
```

:::callout-key[Performance on Duplicate Keys]
On an array with only k distinct values, 3-way quicksort runs in O(n log k) time — for constant k (e.g., sorting booleans or small integers), this is O(n) linear time. This is why Java's Arrays.sort() uses a dual-pivot quicksort variant.
:::

## 7. Heapsort

Heapsort uses a max-heap to sort in-place. Phase 1: build a max-heap from the input in $O(n)$. Phase 2: repeatedly extract the maximum (swap root with last, reduce heap size, sift down) in $O(n \log n)$.

```cpp
void heapify(int A[], int n, int i) {
    int largest = i, l = 2*i+1, r = 2*i+2;
    if (l < n && A[l] > A[largest]) largest = l;
    if (r < n && A[r] > A[largest]) largest = r;
    if (largest != i) {
        std::swap(A[i], A[largest]);
        heapify(A, n, largest);
    }
}

void heapSort(int A[], int n) {
    // Build max-heap: start from last non-leaf
    for (int i = n/2 - 1; i >= 0; i--)
        heapify(A, n, i);
    // Extract elements one by one
    for (int i = n - 1; i > 0; i--) {
        std::swap(A[0], A[i]);   // Move current max to end
        heapify(A, i, 0);        // Restore heap property
    }
}
```

- **Time:** $O(n \log n)$ guaranteed — best, average, worst all identical.
- **Space:** $O(1)$ — in-place heap.
- **Not stable:** the extract/sift-down step can reverse equal elements.
- **Poor cache performance:** heap accesses jump around memory (parent $\to$ child at $2i+1$, $2i+2$) rather than sequentially. This is why quicksort and merge sort are faster in practice despite the same asymptotic bound.

:::callout-connect[Connection to Priority Queues]
Heapsort is essentially a priority queue sort. If you already have a max-heap implementation, sorting is just: insert all n elements (O(n) with build-heap), then extract-max n times (O(n log n)). The in-place trick avoids the O(n) space by using the extracted region as sorted output.
:::

## 8. Counting, Radix, and Bucket Sort

:::callout-key[Key Idea]
These are non-comparison-based sorts. They exploit structure in the keys (e.g., integer range, digit structure) to sort without pairwise comparisons, breaking the $\Omega(n \log n)$ comparison lower bound.
:::

### Counting Sort

Assumes keys are integers in range $[0, k)$. Count occurrences, compute prefix sums (positions), then place each element at its computed position.

```cpp
// Sorts A[0..n-1] with values in [0, k)
void countingSort(int A[], int n, int k) {
    std::vector<int> count(k, 0), out(n);
    for (int i = 0; i < n; i++) count[A[i]]++;
    for (int i = 1; i < k; i++) count[i] += count[i-1];  // Prefix sums
    for (int i = n-1; i >= 0; i--)   // Right-to-left for stability
        out[--count[A[i]]] = A[i];
    std::copy(out.begin(), out.end(), A);
}
```

- **Time:** $O(n + k)$. If $k = O(n)$, this is $O(n)$ linear.
- **Space:** $O(n + k)$.
- **Stable** (with right-to-left pass).
- Not practical when $k \gg n$ (e.g., sorting 10 strings by Unicode code point).

### Radix Sort

Sort by each digit from least significant to most significant (LSD radix sort), using a stable sort (counting sort) at each digit position.

- **Time:** $O(d(n + k))$ where $d$ = number of digits, $k$ = digit range (e.g., 10 for decimal). For fixed-width integers: $O(n)$.
- **Requires a stable sub-sort** at each pass — correctness depends on it.
- Used in practice for large volumes of fixed-length records (e.g., network packet sorting, database record sorting).

### Bucket Sort

Distribute elements into buckets covering equal ranges of the input domain, sort each bucket (e.g., with insertion sort), then concatenate.

- **Average time:** $O(n)$ when input is uniformly distributed and n buckets are used (expected O(1) elements per bucket).
- **Worst case:** $O(n^2)$ if all elements land in one bucket.
- Best for floating-point values uniformly distributed in [0, 1).

| Sort | Time | Space | Restriction |
| --- | --- | --- | --- |
| Counting | $O(n+k)$ | $O(n+k)$ | Integer keys in [0, k) |
| Radix | $O(d(n+k))$ | $O(n+k)$ | Fixed-length keys |
| Bucket | $O(n)$ avg | $O(n)$ | Uniform distribution |

## 9. The Sorting Lower Bound

:::theorem[Theorem 16.1 — Comparison Sort Lower Bound]
Any comparison-based sorting algorithm requires $\Omega(n \log n)$ comparisons in the worst case.
:::

### Decision Tree Argument

Model any comparison sort as a **decision tree**: each internal node is a comparison $A[i] \leq A[j]?$, and each leaf is one of the $n!$ possible permutations (orderings). For the algorithm to be correct, all $n!$ leaves must be reachable.

A binary tree with $n!$ leaves has height at least $\lceil \log_2(n!) \rceil$. By Stirling's approximation: $\log_2(n!) = n \log_2 n - n \log_2 e + O(\log n) = \Omega(n \log n)$.

The height of the decision tree equals the worst-case number of comparisons, so every comparison sort makes $\Omega(n \log n)$ comparisons in the worst case. Merge sort and heapsort are asymptotically optimal comparison sorts.

:::callout-connect[Why Non-Comparison Sorts Break the Bound]
Counting/radix/bucket sorts do not operate via pairwise comparisons — they use the arithmetic structure of keys. The decision tree model does not apply to them. They can beat $\Omega(n \log n)$ precisely because they use more information than binary comparisons provide.
:::

## 10. Exam Prep

These questions reflect the style and depth of CSE 2383 exam questions on sorting.

:::problem[Exam Q1 · standard]{difficulty="standard"}
Which sorting algorithms are stable? List all that are stable from: insertion, selection, bubble, merge, quick, heap.

::::solution[Solution]
**Stable:** Insertion sort, Bubble sort, Merge sort. **Not stable:** Selection sort (swaps non-adjacent equal elements), Quicksort (partition step), Heapsort (sift-down step).
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
You need to sort 1 million student records by GPA (a float). Stability is required. Memory is limited to O(1) extra space. Which algorithm do you choose and why?

::::solution[Solution]
This is a contradiction — no comparison-based sort is simultaneously O(n log n) worst-case, stable, AND in-place. In practice, choose **merge sort** (sacrificing in-place) for the stability guarantee and O(n log n) worst case. If O(n) extra space is truly unavailable, a stable in-place merge sort exists but is complex to implement. Heapsort is in-place but not stable; insertion sort is stable and in-place but O(n²).
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
Solve the recurrence $T(n) = 2T(n/2) + cn$ for merge sort. What is the closed form?

::::solution[Solution]
By the Master Theorem: $a=2, b=2, f(n)=cn$. $n^{\log_b a} = n^{\log_2 2} = n^1 = n$. Since $f(n) = \Theta(n) = \Theta(n^{\log_b a})$, we are in Case 2. Therefore $T(n) = \Theta(n \log n)$. Explicitly: $T(n) = cn \log_2 n + O(n)$.
::::
:::

:::problem[Exam Q4 · challenge]{difficulty="challenge"}
Give an example showing that quicksort with last-element pivot achieves O(n²) on a sorted array. Then explain how randomization fixes this.

::::solution[Solution]
Array [1,2,3,4,5]: pivot=5, partition gives [1,2,3,4] | [5]. Recursion on size-4 subarray: pivot=4, gives [1,2,3] | [4]. Work per level: n-1, n-2, ..., 1 = n(n-1)/2 = O(n²).

With random pivot: pick a uniformly random element as pivot before partitioning. On any input, the expected partition quality is 50/50. The expected depth of recursion is O(log n), giving expected O(n log n) total work. No adversarial input can force O(n²) with high probability because the adversary cannot predict the random pivot.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
You have an array of 10,000 integers all in range [0, 100]. Which sort is fastest and why?

::::solution[Solution]
**Counting sort** with k=101. Time: O(n+k) = O(10,000 + 101) = O(10,101) ≈ O(n) linear. Compare to merge/quicksort O(n log n) ≈ O(10,000 × 13) = O(130,000). Counting sort is ~13x faster asymptotically here, and k is small relative to n so the O(k) space is negligible.
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
Explain the decision tree lower bound for sorting. Why does it imply $\Omega(n \log n)$ for comparison-based sorts?

::::solution[Solution]
Each comparison sort can be modeled as a binary decision tree where each internal node is a comparison A[i] vs A[j] and each leaf is a final permutation. Correctness requires all n! permutations to appear as distinct leaves. A binary tree with L leaves has height at least log₂(L). So height ≥ log₂(n!) = Ω(n log n) by Stirling. Height = worst-case comparisons. Therefore any comparison sort makes Ω(n log n) comparisons in the worst case.
::::
:::

:::problem[Exam Q7 · standard]{difficulty="standard"}
How many passes does LSD radix sort need to sort 32-bit integers using a base-256 (byte-by-byte) counting sort?

::::solution[Solution]
**4 passes.** A 32-bit integer has 4 bytes. LSD radix sort processes one byte (8 bits, values 0–255, so k=256) per pass from least significant to most significant. Each pass uses counting sort in O(n + 256) = O(n). Total time: 4 × O(n) = O(n). This is the standard technique used in hardware sorters and database systems.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
When would you choose heapsort over merge sort, even though merge sort is faster in practice?

::::solution[Solution]
Choose heapsort when: (1) **memory is severely constrained** — heapsort is in-place O(1) space vs merge sort's O(n); (2) you need a **guaranteed O(n log n) worst case in-place** algorithm (quicksort is not guaranteed); (3) implementing a **real-time system** where worst-case bounds matter more than average speed. In embedded systems or kernel code where allocating O(n) space is not allowed, heapsort is the standard choice.
::::
:::

:::summary
## Chapter 16 Summary — Sorting Algorithm Comparison

| Algorithm | Best | Average | Worst | Space | Stable? | In-place? |
| --- | --- | --- | --- | --- | --- | --- |
| Insertion Sort | $O(n)$ | $O(n^2)$ | $O(n^2)$ | $O(1)$ | Yes | Yes |
| Selection Sort | $O(n^2)$ | $O(n^2)$ | $O(n^2)$ | $O(1)$ | No | Yes |
| Bubble Sort | $O(n)$ | $O(n^2)$ | $O(n^2)$ | $O(1)$ | Yes | Yes |
| Merge Sort | $O(n \log n)$ | $O(n \log n)$ | $O(n \log n)$ | $O(n)$ | Yes | No |
| Quicksort | $O(n \log n)$ | $O(n \log n)$ | $O(n^2)$ | $O(\log n)$ | No | Yes |
| Heapsort | $O(n \log n)$ | $O(n \log n)$ | $O(n \log n)$ | $O(1)$ | No | Yes |
| Counting Sort | $O(n+k)$ | $O(n+k)$ | $O(n+k)$ | $O(n+k)$ | Yes | No |
| Radix Sort | $O(d(n+k))$ | $O(d(n+k))$ | $O(d(n+k))$ | $O(n+k)$ | Yes | No |
| Bucket Sort | $O(n)$ | $O(n)$ | $O(n^2)$ | $O(n)$ | Yes\* | No |

\* Bucket sort stability depends on the sub-sort used per bucket. d = number of digit positions; k = alphabet/range size.

### Quick Decision Guide

- **Small n (<16):** Insertion sort
- **General purpose, speed:** Quicksort (random/median-of-3 pivot)
- **Need stability + O(n log n) worst case:** Merge sort
- **In-place + O(n log n) worst case:** Heapsort
- **Integer keys in small range:** Counting sort
- **Fixed-width records at scale:** Radix sort
- **Uniform floats in [0,1):** Bucket sort
:::
