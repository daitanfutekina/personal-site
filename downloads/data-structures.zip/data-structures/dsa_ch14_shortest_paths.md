---
title: "Shortest Paths"
crumb: "Honors DSA · Chapter 14"
meta:
  - "Est. study time: ~70 min"
  - "Unit 4"
  - "CSE 2383 · MSState"
source: "dsa_ch14_shortest_paths.html"
---

## 1. Single-Source Shortest Path Problem

:::definition[Definition 14.1 — Single-Source Shortest Path (SSSP)]
Given a weighted directed graph $G = (V, E, w)$ and a source vertex $s$, find for every
 vertex $v \in V$ the path from $s$ to $v$ with minimum total weight, or report that no
 such path exists. The shortest-path weight is denoted $\delta(s, v)$.
:::

### Edge weight cases

- **Non-negative weights:** Dijkstra's algorithm solves this optimally in $O((V+E) \log V)$.
- **Negative weights (no negative cycles):** Bellman-Ford solves this in $O(VE)$.
- **Negative cycles:** shortest paths are undefined (you can loop forever to decrease cost). Bellman-Ford detects these.
- **DAG (any weights):** topological order + relaxation solves this in $O(V+E)$.

:::callout-key[Relaxation — The Core Operation]
All SSSP algorithms share one fundamental operation: **relaxation**. To relax edge $(u, v, w)$:

```cpp
if (dist[u] + w < dist[v]) {
    dist[v] = dist[u] + w;
    prev[v] = u;  // for path reconstruction
}
```

Relaxation asks: "Is it cheaper to reach $v$ via $u$ than our current best?" Algorithms differ only in the *order* in which they relax edges.
:::

## 2. Dijkstra's Algorithm

:::callout-intuition[Intuition]
Dijkstra's is the weighted generalization of BFS. Instead of a FIFO queue, use a min-priority
 queue ordered by current shortest-path estimate. Always finalize the vertex with the smallest
 known distance — because all edge weights are non-negative, its distance can never decrease further.
:::

```cpp
// Dijkstra's SSSP — O((V + E) log V) with binary heap
// adj[u] = list of {v, weight}
vector<long long> dijkstra(int n, int src,
    vector<vector<pair<int,int>>>& adj) {

    const long long INF = 1e18;
    vector<long long> dist(n, INF);
    priority_queue<pair<long long,int>,
                   vector<pair<long long,int>>,
                   greater<>> pq;

    dist[src] = 0;
    pq.push({0, src});

    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (d > dist[u]) continue;  // stale entry

        for (auto [v, w] : adj[u]) {
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}
```

:::example[Example 14.1 — Dijkstra Step-by-Step]
Directed graph, source = A. Edges: A→B:4, A→C:2, B→C:1, B→D:5, C→B:1, C→D:8, C→E:10, D→E:2, E→D:3.
 Trace Dijkstra's, showing dist[] after each extraction.

::::answer[Answer]
Final distances: A=0, B=3, C=2, D=8, E=10.
::::

Work

Initialize: dist = [A:0, B:INF, C:INF, D:INF, E:INF]. PQ: {(0,A)}

1. Extract A(0). Relax A→B: dist[B]=4. Relax A→C: dist[C]=2. PQ: {(2,C),(4,B)}
2. Extract C(2). Relax C→B: 2+1=3 < 4, dist[B]=3. Relax C→D: dist[D]=10. Relax C→E: dist[E]=12. PQ: {(3,B),(4,B stale),(10,D),(12,E)}
3. Extract B(3). Relax B→C: 3+1=4 > 2, no update. Relax B→D: 3+5=8 < 10, dist[D]=8. PQ: {(4,B stale),(8,D),(12,E)}
4. Extract B(4) — stale (dist[B]=3). Skip.
5. Extract D(8). Relax D→E: 8+2=10 < 12, dist[E]=10. PQ: {(10,E),(12,E stale)}
6. Extract E(10). No outgoing that improve. Done.

Final: dist = [A:0, B:3, C:2, D:8, E:10].
:::

### Practice — Dijkstra's

:::problem[Problem 1 · easy]{difficulty="easy"}
Directed graph, source=1. Edges: 1→2:6, 1→3:2, 2→4:3, 3→2:1, 3→4:8. Run Dijkstra's and give final dist[] for all vertices.

::::solution[Solution]
Init: dist=[1:0,2:INF,3:INF,4:INF]. PQ:{(0,1)}

 Extract 1: dist[2]=6, dist[3]=2. PQ:{(2,3),(6,2)}

 Extract 3(2): dist[2]=min(6, 2+1)=3, dist[4]=min(INF,2+8)=10. PQ:{(3,2),(6,2 stale),(10,4)}

 Extract 2(3): dist[4]=min(10,3+3)=6. PQ:{(6,4),(6,2 stale),(10,4 stale)}

 Extract 4(6). Done.

 Final dist: 1=0, 2=3, 3=2, 4=6.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Why does the "stale entry" check (`if (d > dist[u]) continue`) work? What happens if you omit it?

::::solution[Solution]
When we update dist[v] and push a new entry to the priority queue, the old entry remains. When the old (larger) distance is eventually extracted, the vertex already has its true shortest distance in dist[]. The check skips re-processing. Without it, we re-process vertices with outdated distances, which gives wrong results for any neighbors already finalized — or at minimum wastes work. In the worst case without the check, we may relax edges using stale larger distances and overwrite correct smaller values.
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Dijkstra fails on: 1→2:1, 1→3:4, 2→3:-3. Trace the failure and identify which dist[] value is wrong.

::::solution[Solution]
Init: dist=[1:0,2:INF,3:INF]. Extract 1: dist[2]=1, dist[3]=4. PQ:{(1,2),(4,3)}.

 Extract 2(1): dist[3]=min(4,1-3)=-2. PQ:{(-2,3),(4,3 stale)}.

 Extract 3(-2). Done.

 Final: dist[3]=-2. This is actually CORRECT here — but Dijkstra's can fail when a negative edge exists that should update an already-finalized vertex. Change: add edge 3→2:-10. Then after finalizing 2 with dist=1, we never revisit to apply the shorter path 1→3→2 = 4-10 = -6. Dijkstra gives dist[2]=1 (wrong, should be -6). The greedy "finalized is done" invariant breaks with negative edges.
::::
:::

## 3. Dijkstra's Correctness & Limitations

:::theorem[Theorem 14.1 — Dijkstra Correctness (Non-negative weights)]
When all edge weights are non-negative, when Dijkstra's algorithm finalizes a vertex $u$
 (extracts it from the priority queue), `dist[u]` equals $\delta(s, u)$, the true
 shortest-path weight.
:::

### Proof sketch

By contradiction. Suppose vertex $u$ is finalized with dist[u] > $\delta(s,u)$. Then there
 exists a true shortest path $P = s \to \cdots \to x \to y \to \cdots \to u$ where $y$ is the
 first unfinalized vertex on $P$. Since dist[x] = $\delta(s,x)$ (already finalized correctly) and
 the edge $x \to y$ has non-negative weight, dist[y] $\leq \delta(s,y) \leq \delta(s,u) <$ dist[u].
 But then $y$ would have been extracted before $u$ — contradiction.

:::callout-pitfall[When Dijkstra's Fails]
- **Any negative edge weight.** Even without a negative cycle, greedy finalization can lock in a wrong answer.
- **Negative cycles.** Dijkstra loops or gives nonsense.

Use Bellman-Ford for graphs with negative weights, and Bellman-Ford's cycle detection for negative cycles.
:::

## 4. Bellman-Ford Algorithm

:::callout-intuition[Intuition]
Repeatedly relax all edges. After $k$ rounds, you have the correct shortest-path distances
 for all paths using at most $k$ edges. Since any simple path uses at most $|V|-1$ edges,
 $|V|-1$ rounds suffice. A $|V|$-th round that still relaxes an edge signals a negative cycle.
:::

```cpp
// Bellman-Ford SSSP — O(VE)
// Returns true if no negative cycle reachable from src
struct Edge { int u, v, w; };

bool bellmanFord(int n, int src, vector<Edge>& edges,
                 vector<long long>& dist) {
    const long long INF = 1e18;
    dist.assign(n, INF);
    dist[src] = 0;

    // V-1 relaxation rounds
    for (int i = 0; i < n - 1; i++) {
        for (auto& e : edges) {
            if (dist[e.u] != INF &&
                dist[e.u] + e.w < dist[e.v]) {
                dist[e.v] = dist[e.u] + e.w;
            }
        }
    }

    // Check for negative cycles (Vth round)
    for (auto& e : edges) {
        if (dist[e.u] != INF &&
            dist[e.u] + e.w < dist[e.v]) {
            return false; // negative cycle detected
        }
    }
    return true; // no negative cycle
}
```

:::example[Example 14.2 — Bellman-Ford with Negative Edge]
Source=A. Edges: A→B:6, A→C:7, B→C:8, B→D:-4, B→E:5, C→B:-2, D→A:2, D→F:9, E→D:7, E→F:-3. Show dist[] after each round (4 vertices: A,B,C,D,E,F — 6 vertices total).

::::answer[Answer]
After 5 rounds (V-1=5): dist = [A:0, B:2, C:4, D:-2, E:7, F:4].
::::

Work

Round 0 (initial): [0, INF, INF, INF, INF, INF]

Round 1 (relax all): A→B: dist[B]=6. A→C: dist[C]=7. Others: INF+w remains INF.

 dist = [0, 6, 7, INF, INF, INF]

Round 2: B→C: 6+8=14 > 7 no. B→D: 6+(-4)=2. B→E: 6+5=11. C→B: 7+(-2)=5 < 6, dist[B]=5.

 dist = [0, 5, 7, 2, 11, INF]

Round 3: B→D: 5-4=1 < 2, dist[D]=1. B→E: 5+5=10 < 11, dist[E]=10. D→A: 2+2=4 > 0. D→F: 2+9=11. E→F: 11-3=8.

 dist = [0, 5, 7, 1, 10, 8]

Round 4: B→D: 5-4=1, same. E→D: 10+7=17 > 1. E→F: 10-3=7 < 8, dist[F]=7. D→F: 1+9=10 > 7.

 dist = [0, 5, 7, 1, 10, 7]

Round 5: No changes. Converged.
:::

### Practice — Bellman-Ford

:::problem[Problem 4 · easy]{difficulty="easy"}
Source=s. Edges: s→a:3, s→b:5, a→b:-2, a→c:4, b→c:1. Run Bellman-Ford (3 vertices + source = 4 total). Show dist[] each round.

::::solution[Solution]
Init: [s:0, a:INF, b:INF, c:INF]

 Round 1: s→a: dist[a]=3. s→b: dist[b]=5. a→b: INF (a=3 now, 3-2=1 < 5? Depends on order. In one pass of all edges after s→a: a→b: 3-2=1). dist=[0,3,1,INF]. a→c: 3+4=7. b→c: 1+1=2. dist=[0,3,1,2]

 Round 2: Check all — no improvements. Converged.

 Final: s=0, a=3, b=1, c=2.
::::
:::

:::problem[Problem 5 · standard]{difficulty="standard"}
Demonstrate negative cycle detection. Graph: A→B:1, B→C:2, C→A:-4. Source=A. Trace Bellman-Ford for V-1=2 rounds then the detection round.

::::solution[Solution]
Init: [A:0, B:INF, C:INF]

 Round 1: A→B: dist[B]=1. B→C: 1+2=3. C→A: INF (C=3 only after B→C in round 1, depending on order). After one clean pass: [0,1,3].

 Round 2: C→A: 3-4=-1 < 0. dist[A]=-1. A→B: -1+1=0 < 1, dist[B]=0. B→C: 0+2=2 < 3, dist[C]=2. dist=[-1,0,2].

 Detection round (round 3): C→A: 2-4=-2 < -1. Yes, still improving — negative cycle detected. Return false.
::::
:::

:::problem[Problem 6 · standard]{difficulty="standard"}
Compare Dijkstra and Bellman-Ford on a graph with 100 vertices and 200 edges, all non-negative weights. Which is faster and by how much (asymptotically)?

::::solution[Solution]
Dijkstra: $O((V+E) \log V) = O(300 \log 100) \approx O(300 \times 7) = O(2100)$ operations.

 Bellman-Ford: $O(VE) = O(100 \times 200) = O(20000)$ operations.

 Dijkstra is roughly 10x faster on this sparse graph. The gap grows as $V$ and $E$ grow. Dijkstra wins on any non-negative weight graph; Bellman-Ford is only chosen when negative edges may exist.
::::
:::

## 5. Bellman-Ford Analysis

:::theorem[Theorem 14.2 — Bellman-Ford Correctness]
After $k$ rounds of relaxing all edges, `dist[v]` is the weight of the shortest
 path from $s$ to $v$ using at most $k$ edges. After $|V|-1$ rounds, `dist[v]`
 equals $\delta(s,v)$ for all vertices (if no negative cycle exists), because any simple path
 uses at most $|V|-1$ edges.
:::

### Negative cycle detection

If after $|V|-1$ rounds, a $|V|$-th relaxation pass still finds an improvement (dist[v]
 decreases), then some path with $|V|$ edges is shorter than all paths with $\leq |V|-1$ edges.
 This is only possible if a negative cycle is reachable from $s$ — paths loop through it to
 decrease cost indefinitely.

:::callout-tip[Implementation Tip]
Early termination: if a round produces no relaxations, Bellman-Ford has converged and can stop.
 In the best case (e.g., the graph is a DAG with edges listed in topological order), only 1 round
 is needed.
:::

## 6. Floyd-Warshall (All-Pairs Shortest Paths)

:::definition[Definition 14.2 — All-Pairs Shortest Paths (APSP)]
Find $\delta(u, v)$ for every pair of vertices $(u, v)$ in a weighted directed graph.
:::

:::callout-intuition[Intuition]
Build up the solution by gradually allowing more intermediate vertices. Let $d^{(k)}[i][j]$
 = shortest path from $i$ to $j$ using only vertices $\{1, \ldots, k\}$ as intermediates.
 Base case: $d^{(0)}[i][j] = w(i,j)$ if edge exists, else $\infty$. Transition: either the
 shortest path uses vertex $k$ as an intermediate, or it doesn't.
:::

The recurrence is:

$$
d^{(k)}[i][j] = \min\!\left(d^{(k-1)}[i][j],\; d^{(k-1)}[i][k] + d^{(k-1)}[k][j]\right)
$$

```cpp
// Floyd-Warshall APSP — O(V^3) time, O(V^2) space
void floydWarshall(int n, vector<vector<long long>>& dist) {
    // dist[i][j] = edge weight, INF if no edge, 0 if i==j
    // (initialize before calling)

    for (int k = 0; k < n; k++)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (dist[i][k] != INF && dist[k][j] != INF)
                    dist[i][j] = min(dist[i][j],
                                     dist[i][k] + dist[k][j]);

    // Negative cycle: dist[i][i] < 0 for some i
}
```

:::example[Example 14.3 — Floyd-Warshall on a Small Graph]
3 vertices. Edge matrix: d[0][1]=3, d[0][2]=8, d[1][2]=-4, d[2][0]=2, d[1][0]=INF, d[2][1]=INF. Show the matrix after each k.

::::answer[Answer]
Final: d[0][0]=0, d[0][1]=3, d[0][2]=-1, d[1][0]=-2, d[1][1]=0, d[1][2]=-4, d[2][0]=2, d[2][1]=5, d[2][2]=0.
::::

Work

Initial (0-indexed, INF omitted, diagonal=0):

 d = [[0,3,8],[INF,0,-4],[2,INF,0]]

k=0 (allow vertex 0 as intermediate):

 d[1][2]: min(d[1][2], d[1][0]+d[0][2]) = min(-4, INF+8) = -4. No change.

 d[2][1]: min(INF, d[2][0]+d[0][1]) = min(INF, 2+3) = 5. Update.

 After k=0: [[0,3,8],[INF,0,-4],[2,5,0]]

k=1 (allow vertex 1):

 d[0][2]: min(8, d[0][1]+d[1][2]) = min(8, 3-4) = -1. Update.

 d[2][2]: min(0, d[2][1]+d[1][2]) = min(0, 5-4) = 0. No change.

 After k=1: [[0,3,-1],[INF,0,-4],[2,5,0]]

k=2 (allow vertex 2):

 d[0][1]: min(3, d[0][2]+d[2][1]) = min(3,-1+5)=3. No change.

 d[1][0]: min(INF, d[1][2]+d[2][0]) = min(INF,-4+2)=-2. Update.

 d[1][1]: min(0, d[1][2]+d[2][1]) = min(0,-4+5)=0. No change.

 After k=2: [[0,3,-1],[-2,0,-4],[2,5,0]]
:::

### Practice — Floyd-Warshall

:::problem[Problem 7 · standard]{difficulty="standard"}
Floyd-Warshall has $O(V^3)$ time. If you ran Dijkstra from every vertex on a sparse graph ($E = O(V)$), what is the total time? Which approach is better for dense vs sparse graphs?

::::solution[Solution]
Running Dijkstra from every vertex: $V \times O((V+E)\log V)$. For sparse $E=O(V)$: $O(V^2 \log V)$. This beats Floyd-Warshall's $O(V^3)$ for sparse graphs. For dense $E=O(V^2)$: Dijkstra from all sources = $O(V^3 \log V)$, worse than Floyd-Warshall. Floyd-Warshall wins on dense graphs; Dijkstra-from-each-source wins on sparse non-negative graphs (or use Johnson's algorithm for sparse graphs with negative edges).
::::
:::

:::problem[Problem 8 · standard]{difficulty="standard"}
How does Floyd-Warshall detect negative cycles? What is the condition?

::::solution[Solution]
After running Floyd-Warshall, check the diagonal: if `dist[i][i] < 0` for any vertex $i$, there is a negative cycle containing $i$. This means the "shortest path" from $i$ back to itself has negative total weight, which implies an infinite loop of cost reduction — the defining characteristic of a negative cycle reachable from (and returning to) $i$.
::::
:::

## 7. DAG Shortest Paths

If the graph is a DAG (directed acyclic graph), we can solve SSSP in $O(V+E)$ — faster than
 all other algorithms — and it handles negative edge weights correctly.

### Algorithm

1. Topologically sort the DAG: $O(V+E)$.
2. Initialize dist[src]=0, all others = $\infty$.
3. Process vertices in topological order. For each vertex $u$, relax all outgoing edges $(u,v,w)$.

```cpp
vector<long long> dagSSSP(int n, int src,
    vector<vector<pair<int,int>>>& adj) {
    // Step 1: topological sort (Kahn's or DFS-based)
    vector<int> indegree(n, 0);
    for (int u = 0; u < n; u++)
        for (auto [v, w] : adj[u]) indegree[v]++;

    queue<int> q;
    for (int i = 0; i < n; i++)
        if (indegree[i] == 0) q.push(i);

    vector<int> topo;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        topo.push_back(u);
        for (auto [v, w] : adj[u])
            if (--indegree[v] == 0) q.push(v);
    }

    // Step 2: relax in topological order
    const long long INF = 1e18;
    vector<long long> dist(n, INF);
    dist[src] = 0;
    for (int u : topo)
        if (dist[u] != INF)
            for (auto [v, w] : adj[u])
                dist[v] = min(dist[v], dist[u] + w);
    return dist;
}
```

:::callout-key[Why This Works]
In topological order, when we process $u$, all predecessors of $u$ have already been
 processed. So dist[u] is already finalized when we relax from $u$. No vertex is processed
 before its predecessors — the DAG structure guarantees this. Negative edges are fine because
 we never "go back" in topological order.
:::

## 8. Algorithm Comparison & Applications

| Algorithm | Time | Handles neg. weights? | Detects neg. cycles? | Graph type |
| --- | --- | --- | --- | --- |
| Dijkstra (binary heap) | $O((V+E)\log V)$ | No | No | Non-negative weights |
| Bellman-Ford | $O(VE)$ | Yes | Yes | General directed |
| DAG relaxation | $O(V+E)$ | Yes | N/A | DAG only |
| Floyd-Warshall | $O(V^3)$ | Yes | Yes | All-pairs, any |
| BFS (unit weights) | $O(V+E)$ | N/A | N/A | Unweighted |

### Applications

- **GPS/routing:** Dijkstra's (road networks have non-negative distances).
- **Network routing protocols (BGP):** Bellman-Ford distributed variant (distance vector routing).
- **Currency arbitrage detection:** Bellman-Ford negative cycle detection on log-converted exchange rates.
- **Project scheduling (PERT/CPM):** DAG longest path (negate weights for shortest path).
- **All-pairs routing tables:** Floyd-Warshall.

## 9. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
On a graph with $V=5, E=8$, how many relaxations does Bellman-Ford perform in the worst case?

::::solution[Solution]
$(V-1) \times E = 4 \times 8 = 32$ relaxations in the main loop, plus $E = 8$ more in the negative cycle detection pass. Total: **40** relaxations.
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
True or False: Dijkstra's algorithm on a graph with one negative edge (but no negative cycle) always produces incorrect results.

::::solution[Solution]
False. Dijkstra's *may* produce incorrect results, but not necessarily. If the negative edge is never on any shortest path, or if it goes from a late-visited vertex to an already-finalized vertex in a way that doesn't matter, Dijkstra can still give correct results. The correctness guarantee only holds for non-negative weights; failure is possible but not certain for any particular input.
::::
:::

:::problem[Exam Q3 · challenge]{difficulty="challenge"}
Give a directed graph where Dijkstra's gives the wrong answer. Show the correct answer and Dijkstra's (wrong) answer.

::::solution[Solution]
Graph: A→B:2, A→C:5, B→C:-10. Source=A.

 Correct: dist[A]=0, dist[B]=2, dist[C]=2+(-10)=-8.

 Dijkstra: Extract A(0). Relax A→B:2, A→C:5. Extract B(2). Relax B→C: 2-10=-8, dist[C]=-8. PQ has (5,C stale),(-8,C). Extract C(-8). Done.

 Actually Dijkstra gets -8 here too! Try: A→B:2, A→C:5, C→B:-10. Source=A.

 Correct: dist[B]=min(2, 5-10)=-5. Dijkstra: Extract A. dist[B]=2, dist[C]=5. Extract B(2). Finalize B. Later extract C(5), try C→B: 5-10=-5 < 2, but B is already finalized — Dijkstra gives dist[B]=2 (wrong, should be -5).
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
What is the time complexity of Bellman-Ford on a complete graph ($E = V^2$)? How does this compare to Floyd-Warshall for APSP?

::::solution[Solution]
Bellman-Ford from one source: $O(VE) = O(V \cdot V^2) = O(V^3)$. For APSP (run from each of $V$ sources): $O(V^4)$. Floyd-Warshall for APSP: $O(V^3)$. Floyd-Warshall is dramatically better for all-pairs on dense graphs.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
Why can DAG shortest paths handle negative edges but Dijkstra's cannot, even though both are "greedy" in a sense?

::::solution[Solution]
Dijkstra's greedy guarantee depends on the invariant that once a vertex is finalized, no future shorter path can reach it. A negative edge can invalidate this — a later vertex with a large dist might send a negative edge to an already-finalized vertex, lowering its true distance below what was locked in. DAG relaxation avoids this by processing vertices in topological order: every predecessor is processed before every successor, so when we relax edges from $u$, dist[u] is provably final (no back-edges exist in a DAG). The topological structure replaces the need for non-negative weights.
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
Explain Johnson's algorithm at a high level. When would you use it over Floyd-Warshall?

::::solution[Solution]
Johnson's algorithm: (1) Add a dummy vertex $q$ with zero-weight edges to all other vertices. (2) Run Bellman-Ford from $q$ to get reweighting function $h(v)$. (3) Reweight each edge: $w'(u,v) = w(u,v) + h(u) - h(v) \geq 0$. (4) Run Dijkstra from each vertex on the reweighted graph. (5) Adjust back: $\delta(u,v) = d'(u,v) - h(u) + h(v)$. Total: $O(VE + V(V+E)\log V)$. For sparse graphs ($E \ll V^2$), this beats Floyd-Warshall's $O(V^3)$. Use Johnson's for sparse APSP with possible negative weights; Floyd-Warshall for dense graphs or simpler implementation.
::::
:::

:::problem[Exam Q7 · standard]{difficulty="standard"}
Run Dijkstra from vertex 0 on: 0→1:7, 0→2:9, 0→5:14, 1→2:10, 1→3:15, 2→3:11, 2→5:2, 3→4:6, 4→5:9. List final dist[] for all vertices.

::::solution[Solution]
dist = [0:0, 1:7, 2:9, 3:20, 4:26, 5:11].

 Path to 3: 0→2→3 = 9+11=20. Path to 5: 0→2→5 = 9+2=11. Path to 4: 0→2→3→4 = 9+11+6=26.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
Prove that Bellman-Ford's $|V|-1$ rounds are sufficient for any simple path in a graph without a negative cycle.

::::solution[Solution]
A simple path visits each vertex at most once, so it contains at most $|V|-1$ edges. Claim: after $k$ rounds of relaxation, dist[v] equals the weight of the shortest path from $s$ to $v$ using at most $k$ edges. Base: $k=0$, dist[s]=0 correct, others INF correct (0 edges). Inductive step: if dist[u] is correct for paths up to $k-1$ edges after round $k-1$, then round $k$ relaxes all edges including $(u,v)$, setting dist[v] = min over all predecessors $u$ of dist[u] + w(u,v). This computes the minimum path to $v$ using at most $k$ edges. Since all simple paths have at most $|V|-1$ edges, after $|V|-1$ rounds, dist[v] = $\delta(s,v)$.
::::
:::

:::summary
## Chapter 14 Summary

| Algorithm | Time | Space | Neg. Weights | Neg. Cycles |
| --- | --- | --- | --- | --- |
| Dijkstra (bin. heap) | $O((V+E)\log V)$ | $O(V+E)$ | No | No |
| Dijkstra (Fib. heap) | $O(E + V\log V)$ | $O(V+E)$ | No | No |
| Bellman-Ford | $O(VE)$ | $O(V)$ | Yes | Detects |
| DAG relaxation | $O(V+E)$ | $O(V)$ | Yes | N/A |
| Floyd-Warshall (APSP) | $O(V^3)$ | $O(V^2)$ | Yes | Detects |

### Decision Guide

- **Non-negative weights, SSSP:** Dijkstra's.
- **Possible negative weights, no negative cycles:** Bellman-Ford.
- **Need to detect negative cycles:** Bellman-Ford or Floyd-Warshall.
- **DAG (any weights):** Topological relaxation $O(V+E)$.
- **All-pairs, dense graph:** Floyd-Warshall.
- **All-pairs, sparse graph, negative weights:** Johnson's algorithm.
:::
