---
title: "Graphs"
crumb: "Honors DSA · Chapter 11"
meta:
  - "Est. study time: ~65 min"
  - "Unit 4"
  - "CSE 2383 · MSState"
source: "dsa_ch11_graphs.html"
---

## 1. Graph Terminology

:::callout-intuition[Intuition]
A graph is the most general data structure we study. Trees are a special case. Arrays are a special case. Social networks, road maps, dependency systems, and circuits are all graphs. Mastering the vocabulary is the first step to modeling any real problem.
:::

:::definition[Definition 11.1 — Graph]
A **graph** $G = (V, E)$ is a pair of a finite set of **vertices** (also called *nodes*) $V$ and a set of **edges** (also called *arcs*) $E$ where each edge connects a pair of vertices.
:::

### Directed vs. Undirected

In an **undirected graph**, every edge $\{u, v\}$ is symmetric — you can travel from $u$ to $v$ and from $v$ to $u$. Road networks with two-way streets are undirected.

In a **directed graph** (digraph), each edge $(u, v)$ has a direction — it goes *from* $u$ *to* $v$ only. Twitter follows, web page links, and task dependencies are directed.

### Weighted vs. Unweighted

A **weighted graph** assigns a numeric value (weight or cost) to each edge. GPS maps use weighted graphs where edge weight = road distance or travel time. An **unweighted graph** treats all edges as equal.

### Degree

The **degree** of a vertex is the number of edges incident to it. For directed graphs we distinguish:

- **In-degree**: number of edges *entering* the vertex.
- **Out-degree**: number of edges *leaving* the vertex.

The sum of all degrees in an undirected graph equals $2|E|$ (each edge contributes to two vertices). This is the *handshaking lemma*.

### Paths and Cycles

:::definition[Definition 11.2 — Path]
A **path** from vertex $s$ to vertex $t$ is a sequence of vertices $v_0, v_1, \ldots, v_k$ where $v_0 = s$, $v_k = t$, and each consecutive pair $(v_i, v_{i+1})$ is an edge. The **path length** is the number of edges $k$. A **simple path** visits each vertex at most once.
:::

:::definition[Definition 11.3 — Cycle]
A **cycle** is a path where the first and last vertex are the same and all edges are distinct. A **simple cycle** also has all intermediate vertices distinct.
:::

### Connectivity

An undirected graph is **connected** if there is a path between every pair of vertices. A directed graph is **strongly connected** if there is a directed path from every vertex to every other vertex. It is **weakly connected** if the underlying undirected graph is connected.

:::definition[Definition 11.4 — DAG]
A **Directed Acyclic Graph (DAG)** is a directed graph with no directed cycles. DAGs are the foundation of topological sort, build systems, and dependency resolution.
:::

:::callout-key[Key Idea]
Every tree is a connected acyclic undirected graph. Conversely, any connected acyclic undirected graph on $n$ vertices has exactly $n-1$ edges and is a tree.
:::

:::example[Example 11.1 — Identifying Graph Properties]
Given the directed graph with edges: (A→B), (B→C), (C→A), (A→D). Find the in-degree and out-degree of each vertex. Is this graph a DAG?

::::answer[Answer]
A: in=1 (from C), out=2 (to B, D). B: in=1, out=1. C: in=1, out=1. D: in=1, out=0. This is NOT a DAG — there is a directed cycle A→B→C→A.
::::

Work

Count incoming edges for in-degree, outgoing for out-degree. Trace the path A→B→C→A to confirm the cycle. Remove (C→A) and the graph becomes a DAG.
:::

### Section 1 Practice

:::problem[Problem 1 · easy]{difficulty="easy"}
An undirected graph has 5 vertices and 7 edges. What is the sum of all vertex degrees?

::::solution[Solution]
By the handshaking lemma, the sum of all degrees = 2|E| = 2 × 7 = **14**.
::::
:::

:::problem[Problem 2 · easy]{difficulty="easy"}
True or False: Every strongly connected directed graph is also weakly connected.

::::solution[Solution]
**True.** If directed paths exist between every pair of vertices, then ignoring directions still leaves the graph connected.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Draw (describe as edge list) a DAG with 4 vertices {1,2,3,4} and 4 edges that represents the dependency order: 1 must come before 2 and 3; 2 must come before 4; 3 must come before 4.

::::solution[Solution]
Edges: (1→2), (1→3), (2→4), (3→4). This is a DAG — no directed cycles exist. Topological order: 1, 2, 3, 4 or 1, 3, 2, 4.
::::
:::

## 2. Graph Representations

How you store a graph determines the time and space complexity of every operation. The two dominant representations are the **adjacency matrix** and the **adjacency list**.

### Adjacency Matrix

A 2D array `A[V][V]` where `A[i][j] = 1` (or the edge weight) if edge $(i,j)$ exists, and `0` otherwise.

- **Space:** $O(V^2)$ — always allocates $V^2$ cells regardless of edge count.
- **Edge lookup:** $O(1)$ — just check `A[i][j]`.
- **List all neighbors of v:** $O(V)$ — must scan entire row.
- **Add/remove edge:** $O(1)$.

```cpp
// Adjacency matrix for 5-vertex graph
const int V = 5;
int adj[V][V] = {};   // all zeros = no edges

void addEdge(int u, int v) {
    adj[u][v] = 1;
    adj[v][u] = 1;   // omit for directed graph
}

bool hasEdge(int u, int v) {
    return adj[u][v] == 1;
}
```

### Adjacency List

An array (or vector) of lists where `adj[v]` contains all neighbors of vertex $v$.

- **Space:** $O(V + E)$ — proportional to actual edges, not all possible edges.
- **Edge lookup:** $O(\text{degree}(v))$ — must search the list.
- **List all neighbors of v:** $O(\text{degree}(v))$ — just iterate the list.
- **Add edge:** $O(1)$ amortized (append to list).

```cpp
#include <vector>
#include <list>
using namespace std;

const int V = 5;
vector<int> adj[V];   // adj[v] = list of neighbors

void addEdge(int u, int v) {
    adj[u].push_back(v);
    adj[v].push_back(u);  // omit for directed
}

// Iterate neighbors of u
void printNeighbors(int u) {
    for (int v : adj[u])
        cout << v << " ";
}
```

### Edge List

Simply store all edges as pairs `(u, v)` in an array. Space is $O(E)$. Good for algorithms that iterate all edges (e.g., Kruskal's MST), but edge lookup is $O(E)$.

### When to Use Which

| Criterion | Use Matrix | Use Adj. List |
| --- | --- | --- |
| Graph density | Dense ($E \approx V^2$) | Sparse ($E \ll V^2$) |
| Edge lookup frequency | Many O(1) lookups needed | Rare direct lookups |
| Memory concern | Small V (matrix fits in cache) | Large V with few edges |
| Typical use | Floyd-Warshall, dense networks | BFS/DFS, most graph algorithms |

:::callout-pitfall[Pitfall]
For a graph with 10,000 vertices, an adjacency matrix requires 10,000 × 10,000 = 100 million cells — roughly 400 MB for 32-bit integers. Unless the graph is dense, always prefer an adjacency list at scale.
:::

:::example[Example 11.2 — Converting Between Representations]
Undirected graph edges: {0-1, 0-2, 1-3, 2-3}. Write the 4×4 adjacency matrix and the adjacency lists.

::::answer[Answer]
Matrix (rows/cols 0..3): row 0 = [0,1,1,0], row 1 = [1,0,0,1], row 2 = [1,0,0,1], row 3 = [0,1,1,0].

Lists: adj[0]={1,2}, adj[1]={0,3}, adj[2]={0,3}, adj[3]={1,2}.
::::
:::

### Section 2 Practice

:::problem[Problem 4 · easy]{difficulty="easy"}
A directed graph has V=6 vertices and E=4 edges. How much space does each representation use asymptotically?

::::solution[Solution]
Adjacency matrix: $O(V^2) = O(36)$. Adjacency list: $O(V+E) = O(10)$. The adjacency list is much more space-efficient for this sparse graph.
::::
:::

:::problem[Problem 5 · standard]{difficulty="standard"}
You need to repeatedly check in O(1) whether any edge exists between two vertices in a graph of 500 vertices. Which representation do you choose and why?

::::solution[Solution]
Choose the **adjacency matrix**. Edge lookup is $O(1)$ — just read `A[u][v]`. The 500×500 matrix takes 250,000 cells (~1 MB for integers), which is acceptable at this scale.
::::
:::

## 3. Graph Properties & Types

### Complete Graph

A **complete graph** $K_n$ has an edge between every pair of vertices. It has $\binom{n}{2} = \frac{n(n-1)}{2}$ edges. Every vertex has degree $n-1$. Complete graphs are maximally dense.

### Bipartite Graph

:::definition[Definition 11.5 — Bipartite Graph]
A graph is **bipartite** if its vertices can be partitioned into two disjoint sets $U$ and $W$ such that every edge connects a vertex in $U$ to a vertex in $W$. No edge connects two vertices within the same set. A graph is bipartite if and only if it contains no odd-length cycles.
:::

Example: job assignment networks (workers U, jobs W), recommendation systems (users U, products W).

### Trees and Forests

A **tree** is a connected acyclic undirected graph. With $n$ vertices it has exactly $n-1$ edges. A **forest** is an acyclic undirected graph (a disjoint union of trees). Every tree is a graph, but not every graph is a tree.

### Sparse vs. Dense

These terms are relative, but useful rules of thumb:

- **Sparse graph:** $E = O(V)$ — few edges relative to vertices. Road networks, social networks.
- **Dense graph:** $E = O(V^2)$ — many edges, approaching complete. Clique-like structures.

The density boundary matters because it determines which algorithm and representation is most efficient.

:::callout-connect[Connection]
Bipartite check is done by BFS/DFS 2-coloring (Chapter 12). If you can 2-color the graph without coloring two adjacent vertices the same color, it is bipartite.
:::

### Section 3 Practice

:::problem[Problem 6 · easy]{difficulty="easy"}
How many edges does the complete graph $K_5$ have?

::::solution[Solution]
$\binom{5}{2} = \frac{5 \times 4}{2} = \mathbf{10}$ edges.
::::
:::

:::problem[Problem 7 · standard]{difficulty="standard"}
Is the cycle graph $C_5$ (5 vertices in a ring) bipartite? Explain.

::::solution[Solution]
**No.** $C_5$ has an odd cycle of length 5. A graph is bipartite if and only if all cycles have even length. Attempt to 2-color: starting at v1=red, v2=blue, v3=red, v4=blue, v5=red — but v5 and v1 are adjacent and both red. Contradiction.
::::
:::

## 4. Adjacency Matrix Operations

| Operation | Time | Code |
| --- | --- | --- |
| Add edge (u,v) | $O(1)$ | `A[u][v] = 1; A[v][u] = 1;` |
| Remove edge (u,v) | $O(1)$ | `A[u][v] = 0; A[v][u] = 0;` |
| Check if edge exists | $O(1)$ | `return A[u][v] != 0;` |
| List all neighbors of v | $O(V)$ | Scan entire row v |
| Count all edges | $O(V^2)$ | Sum all cells (divide by 2 for undirected) |

:::callout-key[Key Idea]
The adjacency matrix for an undirected graph is always *symmetric*: $A[i][j] = A[j][i]$ for all $i, j$. This is a useful sanity check. For directed graphs, the matrix is generally asymmetric.
:::

```cpp
// Full adjacency matrix graph class (undirected, unweighted)
#include <iostream>
using namespace std;

class GraphMatrix {
    int V;
    int** adj;
public:
    GraphMatrix(int v) : V(v) {
        adj = new int*[V];
        for (int i = 0; i < V; i++) {
            adj[i] = new int[V]();  // zero-initialized
        }
    }
    ~GraphMatrix() {
        for (int i = 0; i < V; i++) delete[] adj[i];
        delete[] adj;
    }
    void addEdge(int u, int v)    { adj[u][v] = adj[v][u] = 1; }
    void removeEdge(int u, int v) { adj[u][v] = adj[v][u] = 0; }
    bool hasEdge(int u, int v)    { return adj[u][v] != 0; }
    void neighbors(int u) {
        for (int v = 0; v < V; v++)
            if (adj[u][v]) cout << v << " ";
    }
};
```

## 5. Adjacency List Operations

| Operation | Time | Notes |
| --- | --- | --- |
| Add edge (u,v) | $O(1)$ | Append v to adj[u] |
| Remove edge (u,v) | $O(\deg(u))$ | Search and remove from list |
| Check if edge exists | $O(\deg(u))$ | Scan adj[u] for v |
| List all neighbors of v | $O(\deg(v))$ | Just iterate adj[v] |
| Iterate all edges | $O(V + E)$ | Iterate all lists |

```cpp
#include <vector>
#include <algorithm>
using namespace std;

class GraphList {
    int V;
    vector<vector<int>> adj;
public:
    GraphList(int v) : V(v), adj(v) {}

    void addEdge(int u, int v) {
        adj[u].push_back(v);
        adj[v].push_back(u);  // remove for directed
    }
    void removeEdge(int u, int v) {
        adj[u].erase(remove(adj[u].begin(), adj[u].end(), v), adj[u].end());
        adj[v].erase(remove(adj[v].begin(), adj[v].end(), u), adj[v].end());
    }
    bool hasEdge(int u, int v) {
        return find(adj[u].begin(), adj[u].end(), v) != adj[u].end();
    }
    const vector<int>& neighbors(int u) { return adj[u]; }
};
```

:::callout-tip[Tip]
For faster edge removal and lookup in an adjacency list, replace `vector<int>` with `unordered_set<int>`. This gives O(1) average-case add, remove, and lookup, at the cost of slightly more memory per vertex.
:::

### Sections 4 & 5 Practice

:::problem[Problem 8 · standard]{difficulty="standard"}
Using an adjacency list, what is the time complexity to check whether an edge (u, v) exists in a graph where all vertices have degree at most $k$?

::::solution[Solution]
$O(k)$ — you scan at most $k$ neighbors in adj[u]. If $k$ is small (sparse graph), this is effectively $O(1)$ in practice, but $O(\deg(u))$ in the worst case.
::::
:::

:::problem[Problem 9 · challenge]{difficulty="challenge"}
You are implementing a social network (10 million users, ~200 friends each on average). Should you use an adjacency matrix or list? Estimate the memory for each.

::::solution[Solution]
**Use an adjacency list.** Matrix: 10M × 10M = 10^14 cells — completely infeasible (400 TB). List: O(V + E) = O(10M + 2B) ≈ 2 billion entries × 4 bytes = ~8 GB — still large but tractable with careful implementation (compressed adjacency). The matrix is not even remotely viable here.
::::
:::

## 6. Graph Modeling

:::callout-intuition[Intuition]
The skill that separates a good algorithm designer from a great one is the ability to look at a real problem and say "this is a graph problem." Once you identify the vertices and edges, dozens of well-studied algorithms become available.
:::

### Mapping to Graphs

| Real Problem | Vertices | Edges | Directed? |
| --- | --- | --- | --- |
| Road network / GPS | Intersections | Roads (weighted by distance) | Sometimes (one-way) |
| Internet routing | Routers/hosts | Network links | Sometimes |
| Social network | Users | Friendships/follows | Directed (follows) |
| Course prerequisites | Courses | Prerequisite relationships | Yes (DAG) |
| Build system | Source files/targets | Dependencies | Yes (DAG) |
| Web pages | Pages | Hyperlinks | Yes |
| Spreadsheet cells | Cells | Formula references | Yes (DAG if no circular) |

:::example[Example 11.3 — Modeling Course Prerequisites]
CSE 1384 is a prerequisite for CSE 2383. CSE 2383 is a prerequisite for CSE 3183 and CSE 3813. Model this as a graph and determine what properties it must have.

::::answer[Answer]
Directed graph (digraph) with edges: CSE1384 → CSE2383, CSE2383 → CSE3183, CSE2383 → CSE3813. It must be a DAG (no cycles — you cannot take a course that is its own prerequisite).
::::

Work

Each directed edge (A→B) means "A must be completed before B." The DAG property guarantees a valid enrollment order exists — that order is a topological sort.
:::

### Section 6 Practice

:::problem[Problem 10 · standard]{difficulty="standard"}
You are modeling a network of airports where each flight is a directed, weighted edge (weight = flight duration). What graph questions correspond to: (a) finding the fastest route from city A to city B, and (b) determining whether all cities are reachable from a hub?

::::solution[Solution]
(a) **Shortest path** in a weighted directed graph — use Dijkstra's algorithm. (b) **Reachability / connectivity** — run DFS or BFS from the hub; if all vertices are visited, every city is reachable.
::::
:::

## 7. Topological Sort

:::definition[Definition 11.6 — Topological Order]
A **topological ordering** of a DAG is a linear ordering of all vertices such that for every directed edge $(u, v)$, vertex $u$ appears before $v$ in the ordering. A topological order exists if and only if the graph is a DAG (no directed cycles).
:::

### Kahn's Algorithm (BFS-based)

Kahn's algorithm uses in-degrees. The key insight: a vertex with in-degree 0 has no prerequisites — it can safely go first.

1. Compute in-degree for every vertex.
2. Enqueue all vertices with in-degree 0.
3. While queue is not empty:

   - Dequeue vertex $u$, add to topological order.
   - For each neighbor $v$ of $u$: decrement in-degree of $v$. If in-degree of $v$ becomes 0, enqueue $v$.

4. If the result contains all $V$ vertices, a valid topological order was found. Otherwise, a cycle exists.

```cpp
#include <vector>
#include <queue>
using namespace std;

vector<int> topoSort(int V, vector<vector<int>>& adj) {
    vector<int> inDeg(V, 0);
    for (int u = 0; u < V; u++)
        for (int v : adj[u])
            inDeg[v]++;

    queue<int> q;
    for (int v = 0; v < V; v++)
        if (inDeg[v] == 0) q.push(v);

    vector<int> order;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        order.push_back(u);
        for (int v : adj[u]) {
            if (--inDeg[v] == 0) q.push(v);
        }
    }
    // If order.size() != V, graph has a cycle
    return order;
}
```

**Time complexity:** $O(V + E)$ — each vertex and edge is processed once.

**Space complexity:** $O(V)$ for in-degree array and queue.

### DFS-based Topological Sort

Run DFS; when a vertex finishes (all descendants visited), push it onto a stack. Pop the stack for topological order. This is equivalent to Kahn's but leverages DFS recursion naturally.

```cpp
void dfsTopoHelper(int u, vector<vector<int>>& adj,
                   vector<bool>& visited, stack<int>& stk) {
    visited[u] = true;
    for (int v : adj[u])
        if (!visited[v])
            dfsTopoHelper(v, adj, visited, stk);
    stk.push(u);  // push after all descendants are processed
}

vector<int> dfsTopoSort(int V, vector<vector<int>>& adj) {
    vector<bool> visited(V, false);
    stack<int> stk;
    for (int v = 0; v < V; v++)
        if (!visited[v]) dfsTopoHelper(v, adj, visited, stk);
    vector<int> order;
    while (!stk.empty()) { order.push_back(stk.top()); stk.pop(); }
    return order;
}
```

### Applications

- **Build systems** (Make, CMake): compile files in dependency order.
- **Course scheduling**: determine valid enrollment order.
- **Spreadsheet evaluation**: compute cells in dependency order.
- **Package managers** (npm, pip): install dependencies before dependents.
- **CPU instruction scheduling**: order instructions respecting data dependencies.

:::callout-pitfall[Pitfall]
Topological sort is only defined for DAGs. If the graph has a cycle, Kahn's algorithm will leave some vertices in the queue with non-zero in-degree — the output will have fewer than V vertices. Always check `order.size() == V` to detect cycles.
:::

:::example[Example 11.4 — Kahn's Algorithm Trace]
DAG edges: 5→0, 5→2, 4→0, 4→1, 2→3, 3→1. Run Kahn's algorithm. Show in-degrees and queue state at each step.

::::answer[Answer]
One valid topological order: 4, 5, 2, 0, 3, 1.
::::

Work

Initial in-degrees: 0→2(from 5,4), 1→2(from 4,3), 2→1(from 5), 3→1(from 2), 4→0, 5→0.

Queue starts: {4, 5}. Process 4: decrement inDeg[0]→1, inDeg[1]→1. Queue: {5}. Process 5: decrement inDeg[0]→0 (enqueue 0), inDeg[2]→0 (enqueue 2). Queue: {0, 2}. Process 0: no outgoing edges. Queue: {2}. Process 2: decrement inDeg[3]→0 (enqueue 3). Queue: {3}. Process 3: decrement inDeg[1]→0 (enqueue 1). Queue: {1}. Process 1: done. Order: 4, 5, 0, 2, 3, 1.
:::

### Section 7 Practice

:::problem[Problem 11 · easy]{difficulty="easy"}
Can you perform topological sort on the graph with edges: A→B, B→C, C→A? Why or why not?

::::solution[Solution]
**No.** The graph contains a directed cycle (A→B→C→A). Topological sort requires a DAG. Kahn's algorithm would detect this: A, B, C all eventually have in-degree reduced, but at some point no vertex reaches in-degree 0 — the output would have fewer than 3 vertices.
::::
:::

:::problem[Problem 12 · standard]{difficulty="standard"}
DAG with edges: A→C, B→C, B→D, C→E, D→E. List all valid topological orderings.

::::solution[Solution]
Valid orderings (A and B have no prerequisites so either can come first): A, B, C, D, E | A, B, D, C, E | B, A, C, D, E | B, A, D, C, E | B, D, A, C, E. The key constraints are: A before C, B before C and D, C before E, D before E.
::::
:::

:::problem[Problem 13 · challenge]{difficulty="challenge"}
Modify Kahn's algorithm to detect whether a DAG has a *unique* topological ordering (i.e., at no step is there more than one vertex with in-degree 0 in the queue). What does a unique ordering tell you about the graph?

::::solution[Solution]
Check: at every step, the queue should have exactly 1 element. If at any step `q.size() > 1`, the ordering is not unique. A unique topological ordering means the DAG has a **Hamiltonian path** — a directed path that visits every vertex exactly once. This means the vertex ordering is completely forced.
::::
:::

## 8. Exam Prep

:::problem[Exam Q1 · standard]{difficulty="standard"}
What is the time complexity to find all neighbors of a vertex in (a) an adjacency matrix and (b) an adjacency list?

::::solution[Solution]
(a) $O(V)$ — must scan the entire row. (b) $O(\deg(v))$ — just iterate the list. For sparse graphs, adjacency list wins decisively.
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
Explain why every tree is a graph but not every graph is a tree.

::::solution[Solution]
A tree is a connected, acyclic undirected graph. Any graph that is connected and acyclic with $n$ vertices and $n-1$ edges is a tree. A general graph may have cycles, may be disconnected, or may have more/fewer edges than a tree with the same vertex count. Trees are a proper subset of graphs.
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
What is the space complexity of an adjacency list for a complete graph $K_n$?

::::solution[Solution]
$O(V + E) = O(n + n(n-1)/2) = O(n^2)$. For a complete graph, the adjacency list and matrix both require $O(n^2)$ space — the list loses its space advantage when the graph is dense.
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
Name two applications of topological sort and explain why each requires a DAG.

::::solution[Solution]
**Build systems:** files must be compiled in dependency order; circular dependencies would make compilation impossible (hence tools like make error on cycles). **Course scheduling:** you cannot satisfy circular prerequisites (impossible to enroll). Both require DAGs because a cycle would mean no valid linear ordering exists.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
In Kahn's algorithm, after the loop terminates, `order.size() < V`. What does this mean?

::::solution[Solution]
The graph contains a **directed cycle**. Vertices in the cycle never reach in-degree 0 (they're always waiting on each other), so they are never enqueued or processed. This is actually a cycle detection technique.
::::
:::

:::problem[Exam Q6 · challenge]{difficulty="challenge"}
A directed graph has V vertices and E edges stored as an adjacency list. What is the total time to compute the in-degree of every vertex?

::::solution[Solution]
$O(V + E)$. Initialize an in-degree array of size V: $O(V)$. Then iterate all adjacency lists — total iterations = total edges = $E$. For each edge $(u,v)$ found, increment inDeg[v]. Overall: $O(V + E)$.
::::
:::

:::problem[Exam Q7 · challenge]{difficulty="challenge"}
How does the adjacency matrix representation handle weighted graphs differently from unweighted graphs?

::::solution[Solution]
For weighted graphs, store the edge weight in `A[i][j]` instead of 1. Use a sentinel value (e.g., 0 or -1 or infinity) to indicate no edge. If weights can be 0, you need a separate boolean matrix or use infinity as the "no edge" sentinel. The space remains $O(V^2)$.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
What is the difference between a strongly connected graph and a weakly connected graph? Give an example of each using 3 vertices.

::::solution[Solution]
**Strongly connected:** directed paths exist in both directions between every pair of vertices. Example: A→B, B→C, C→A (every vertex can reach every other). **Weakly connected:** the underlying undirected graph is connected, but directed paths may not exist in both directions. Example: A→B, A→C (undirected: all connected, but B and C cannot reach A).
::::
:::

:::summary
## Chapter 11 Summary

| Concept | Adjacency Matrix | Adjacency List |
| --- | --- | --- |
| Space | $O(V^2)$ | $O(V + E)$ |
| Add edge | $O(1)$ | $O(1)$ |
| Remove edge | $O(1)$ | $O(\deg(v))$ |
| Check edge | $O(1)$ | $O(\deg(v))$ |
| List neighbors | $O(V)$ | $O(\deg(v))$ |
| Iterate all edges | $O(V^2)$ | $O(V + E)$ |
| Best for | Dense graphs, fast edge lookup | Sparse graphs, traversal algorithms |

| Algorithm | Time | Space | Requirement |
| --- | --- | --- | --- |
| Topological Sort (Kahn's) | $O(V + E)$ | $O(V)$ | DAG only |
| Topological Sort (DFS) | $O(V + E)$ | $O(V)$ | DAG only |

**Key terms:** vertex, edge, directed, undirected, weighted, degree, in-degree, out-degree, path, cycle, connected, strongly connected, DAG, complete graph, bipartite, tree, forest, sparse, dense, topological order.
:::
