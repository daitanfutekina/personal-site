---
title: "Queues"
crumb: "Honors DSA · Chapter 6"
meta:
  - "Est. study time: ~120 min"
  - "Unit 2 — Linear Structures"
  - "CSE 2383 · MSState"
source: "markdown"
---

## Overview

A **queue** is the fair-access container: the first element inserted is the first one out (FIFO — First-In, First-Out). Queues model waiting lines, print spoolers, CPU scheduling, and the BFS traversal algorithm. Where a stack tracks "most recent," a queue tracks "oldest unprocessed."

This chapter covers two concrete implementations (circular-array and linked), the C++ standard library wrappers, and four algorithmic patterns: BFS level-order traversal, queue-from-two-stacks, the sliding window maximum (monotonic deque), and producer-consumer / round-robin scheduling.

:::callout-key[Prerequisites]
- Arrays and modular arithmetic
- Singly- and doubly-linked lists — Ch 4
- Stacks — Ch 5 (the two-stacks pattern builds on this)
:::

## 1. The Queue ADT

:::callout-intuition[Intuition]
Picture a line at the MSU dining hall. People join at the back (enqueue) and leave from the front (dequeue). The person who arrived first eats first. Unlike the stack's "last in, first out," the queue is fundamentally *fair*. This fairness is exactly what makes queues the right data structure for BFS: process nodes layer by layer, never skipping ahead.
:::

:::definition[Definition 6.1 — Queue ADT]
A **queue** is a collection supporting four operations:

- `enqueue(x)` — insert element `x` at the back (tail).
- `dequeue()` — remove and return the element at the front (head).
- `front()` / `peek()` — return the front element without removing it.
- `isEmpty()` / `size()` — query the queue state.

All operations must run in **O(1)** time (worst-case for linked; amortized for array-backed).
:::

### Terminology: Front vs. Back

| Alias | Meaning |
| --- | --- |
| front / head | Where elements leave (dequeue end) |
| back / tail / rear | Where elements enter (enqueue end) |

:::callout-pitfall[Pitfall — Confusing front and back]
Enqueue adds at the **back**; dequeue removes from the **front**. Students frequently invert these. Remember: a real-world line — you join at the back, leave from the front.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
Trace the queue state after: enqueue(1), enqueue(2), enqueue(3), dequeue(), enqueue(4), dequeue(), front(). What does front() return?

::::solution[Solution]
[1] → [1,2] → [1,2,3] → dequeue removes 1 → [2,3] → [2,3,4] → dequeue removes 2 → [3,4]. front() returns **3**.
::::
:::

:::problem[Problem 2 · easy]{difficulty="easy"}
What is the key behavioral difference between a stack and a queue? Give one real-world analogy for each.

::::solution[Solution]
Stack: LIFO — last inserted, first removed. Analogy: stack of plates. Queue: FIFO — first inserted, first removed. Analogy: ticket line at a box office.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Why can't we implement an efficient queue using a plain (non-circular) array with head=0 always? What is the time complexity of dequeue in that design?

::::solution[Solution]
Dequeue with head=0 requires shifting all remaining elements one position left: O(n). This defeats the O(1) requirement. The circular-array design avoids this by advancing the head index instead of moving elements.
::::
:::

## 2. Circular Array Queue

:::callout-intuition[Intuition]
The circular array "wraps around" using modular arithmetic. Think of the indices as positions on a clock face. After using index cap-1, the next index is 0 again. We track two indices: `head` (front, where we dequeue) and `tail` (one past the last element, where we enqueue next). Both advance with `% cap` after each operation — no element shifting ever needed.
:::

:::definition[Definition 6.2 — Circular Array Invariant]
The queue occupies indices head, (head+1)%cap, ..., (head+size-1)%cap. The tail index always equals (head + size) % cap. The queue is full when size == cap; empty when size == 0.
:::

### Implementation

```cpp
template <typename T>
class CircularQueue {
    T*  data;
    int cap;
    int head;  // index of front element
    int sz;    // current number of elements
    // tail = (head + sz) % cap  (derived, not stored separately)

    void grow() {
        int newCap = cap * 2;
        T* newData = new T[newCap];
        for (int i = 0; i < sz; ++i)
            newData[i] = data[(head + i) % cap];
        delete[] data;
        data = newData;
        cap  = newCap;
        head = 0;           // reset head after linearizing
    }

public:
    CircularQueue(int initCap = 4)
      : cap(initCap), head(0), sz(0) {
        data = new T[cap];
    }
    ~CircularQueue() { delete[] data; }

    void enqueue(const T& val) {
        if (sz == cap) grow();
        int tail = (head + sz) % cap;
        data[tail] = val;
        ++sz;
    }

    T dequeue() {
        if (sz == 0) throw std::underflow_error("queue empty");
        T val = data[head];
        head  = (head + 1) % cap;
        --sz;
        return val;
    }

    T front() const {
        if (sz == 0) throw std::underflow_error("queue empty");
        return data[head];
    }

    bool isEmpty() const { return sz == 0; }
    int  size()   const  { return sz; }
};
```

:::example[Example 6.1 — Circular queue wrap-around]
cap=4. Enqueue A, B, C, D. Dequeue twice. Enqueue E. Show head, tail (derived), and array state.

::::answer[Answer]
Array: [E, B, C, D] (logically B→C→D→E). head=1, tail=(1+3)%4=0, sz=3.
::::

Work

```
enqueue(A): data=[A,_,_,_]  head=0, sz=1, tail=(0+1)%4=1

enqueue(B): data=[A,B,_,_]  head=0, sz=2, tail=2

enqueue(C): data=[A,B,C,_]  head=0, sz=3, tail=3

enqueue(D): data=[A,B,C,D]  head=0, sz=4, tail=0 (FULL)

dequeue():  returns A, head=(0+1)%4=1, sz=3

dequeue():  returns B, head=(1+1)%4=2, sz=2

enqueue(E): tail=(2+2)%4=0, data[0]=E → data=[E,B,C,D], sz=3

             head=2, logical order: C,D,E

```
:::

:::example[Example 6.2 — Grow during enqueue]
cap=4, head=2, sz=4 (full), data=[C,D,A,B] (head=2 so logical: A,B,C,D). Enqueue E.

::::answer[Answer]
After grow: cap=8, data=[A,B,C,D,E,\_,\_,\_], head=0, sz=5.
::::

Work

1. sz == cap → call grow().
2. Allocate newData[8].
3. Copy in logical order: i=0: data[(2+0)%4]=data[2]=A; i=1: data[3]=B; i=2: data[0]=C; i=3: data[1]=D.
4. newData = [A,B,C,D,\_,\_,\_,\_]. head=0, cap=8.
5. tail = (0+4)%8 = 4. data[4] = E. sz=5.
:::

:::example[Example 6.3 — Modular arithmetic full/empty check]
Why can't we distinguish full from empty with only head and tail (without a separate size counter)?

::::answer[Answer]
Both full and empty give head == tail. We need either a size counter or a "one slot wasted" convention.
::::

Work

Empty: head=0, tail=0. Full (cap=4): head=0, tail=(0+4)%4=0. The two conditions are indistinguishable from head and tail alone. Solutions: (a) store `sz` separately (our approach), or (b) keep one slot always empty and declare full when `(tail+1)%cap == head`.
:::

:::callout-pitfall[Pitfall — Forgetting to reset head after grow()]
After copying to a new array in linearized order (index 0 = logical front), you must set `head = 0`. If you forget, the head still points into the old wrapped position, but the new array is linear — you'll dequeue garbage.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
CircularQueue with cap=5, head=3, sz=4. What is the tail index? What index does enqueue write to next?

::::solution[Solution]
tail = (head + sz) % cap = (3 + 4) % 5 = **2**. The next enqueue writes to data[2].
::::
:::

:::problem[Problem 2 · easy]{difficulty="easy"}
After enqueue (or dequeue), how is head updated? How is tail derived?

::::solution[Solution]
Dequeue: `head = (head + 1) % cap`; sz--. Tail is not stored; it is derived as `(head + sz) % cap` whenever needed.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Trace a CircularQueue with cap=3: enqueue(10), enqueue(20), enqueue(30), dequeue(), enqueue(40), dequeue(). Show head and sz after each step.

::::solution[Solution]
enqueue(10): data=[10,\_,\_], head=0, sz=1.

 enqueue(20): data=[10,20,\_], head=0, sz=2.

 enqueue(30): data=[10,20,30], head=0, sz=3 (FULL).

 dequeue(): returns 10, head=1, sz=2.

 enqueue(40): tail=(1+2)%3=0, data[0]=40 → data=[40,20,30], head=1, sz=3.

 dequeue(): returns data[1]=20, head=2, sz=2.
::::
:::

:::problem[Problem 4 · challenge]{difficulty="challenge"}
What is the time complexity of `grow()` in CircularQueue? Is the amortized cost of enqueue still O(1)? Justify using the same doubling argument as ArrayStack.

::::solution[Solution]
grow() is O(n) — it copies all n elements. But the doubling argument applies: after a grow to 2n, the next grow requires n more enqueues. Total copy work for n operations is O(n) (geometric series). Amortized cost per enqueue = O(1). Same argument as ArrayStack, just with an extra modular indexing step in the copy loop.
::::
:::

## 3. LinkedQueue

:::callout-intuition[Intuition]
A linked queue maintains two pointers: `head` (front, where we dequeue) and `tail` (back, where we enqueue). Enqueue appends a new node at the tail in O(1); dequeue removes the head node in O(1). The critical bug zone: the tail pointer becomes dangling when the last element is dequeued — you must set `tail = nullptr` when the queue goes empty.
:::

```cpp
template <typename T>
class LinkedQueue {
    struct Node {
        T     data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    Node* head;  // front (dequeue end)
    Node* tail;  // back  (enqueue end)
    int   sz;

public:
    LinkedQueue() : head(nullptr), tail(nullptr), sz(0) {}
    ~LinkedQueue() { while (!isEmpty()) dequeue(); }

    void enqueue(const T& val) {
        Node* n = new Node(val);
        if (tail) tail->next = n;
        else      head = n;       // queue was empty; new node is also head
        tail = n;
        ++sz;
    }

    T dequeue() {
        if (!head) throw std::underflow_error("queue empty");
        T val   = head->data;
        Node* old = head;
        head    = head->next;
        if (!head) tail = nullptr; // queue is now empty — fix dangling tail!
        delete old;
        --sz;
        return val;
    }

    T front() const {
        if (!head) throw std::underflow_error("queue empty");
        return head->data;
    }

    bool isEmpty() const { return head == nullptr; }
    int  size()   const  { return sz; }
};
```

:::callout-pitfall[Pitfall — Dangling tail pointer after last dequeue]
When you dequeue the very last element: `head` becomes `nullptr` (correct), but `tail` still points to the deleted node (dangling pointer). The fix: `if (!head) tail = nullptr;` inside dequeue. The next enqueue into an empty queue uses the `else head = n;` branch precisely because tail is nullptr.
:::

:::example[Example 6.4 — LinkedQueue trace showing tail pitfall]
Trace: enqueue(A), enqueue(B), dequeue(), dequeue(), enqueue(C).

::::answer[Answer]
Final state: head → [C | null], tail → [C | null], sz=1.
::::

Work

```
enqueue(A): head→[A|null], tail→[A|null], sz=1

enqueue(B): [A|→]→[B|null]; head→A, tail→B, sz=2

dequeue():  val=A, head→B, head!=null so tail stays; delete A-node. sz=1

            head→[B|null], tail→[B|null]

dequeue():  val=B, head→null, head==null → tail=null. delete B-node. sz=0

            head=null, tail=null

enqueue(C): tail==null → head=C; tail=C. sz=1

            head→[C|null], tail→[C|null]

```
:::

### Comparison: CircularQueue vs. LinkedQueue

| Property | CircularQueue | LinkedQueue |
| --- | --- | --- |
| Enqueue | O(1) amortized | O(1) worst-case |
| Dequeue | O(1) | O(1) |
| Memory per element | T only (contiguous) | T + pointer overhead |
| Cache performance | Excellent | Poor (scattered nodes) |
| Max size known? | Yes → use circular array | Unknown/large → use linked |
| Key bug | Forgetting head reset on grow | Dangling tail on last dequeue |

:::problem[Problem 1 · easy]{difficulty="easy"}
In a LinkedQueue, which pointer is advanced during dequeue — head or tail?

::::solution[Solution]
**head** advances: `head = head->next`. Tail only changes when the queue becomes empty (set to nullptr) or when a new node is appended at the back during enqueue.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
What is the bug in this dequeue implementation? `T val = head->data; head = head->next; delete head; return val;`

::::solution[Solution]
Two bugs: (1) `delete head` deletes the *new* head (the second element), not the node we removed — we deleted the wrong node and created a memory leak for the original head. Fix: save old head before advancing. (2) Missing tail=nullptr check when queue becomes empty.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Write `enqueue` for a LinkedQueue that enqueues a value and handles the case where the queue is currently empty.

::::solution[Solution]
```cpp
void enqueue(const T& val) {
    Node* n = new Node(val);
    if (tail) {
        tail->next = n;
    } else {
        head = n;  // was empty: new node is the front too
    }
    tail = n;
    ++sz;
}
```
::::
:::

## 4. `std::queue` & `std::deque`

:::callout-intuition[Intuition]
Like `std::stack`, `std::queue` is a container adapter. It wraps an underlying container (default: `std::deque`) and restricts access to queue-only operations. `std::deque` (double-ended queue) is more powerful: it supports O(1) push and pop at *both* ends, making it the backbone of the sliding-window maximum algorithm.
:::

```cpp
#include <queue>
#include <deque>

// std::queue (FIFO only)
std::queue<int> q;
q.push(1);   q.push(2);   q.push(3);
int f = q.front();   // 1
int b = q.back();    // 3
q.pop();             // removes front (1); returns void!
std::cout << q.front();  // 2

// std::deque (both ends)
std::deque<int> dq;
dq.push_back(10);
dq.push_front(5);   // [5, 10]
dq.pop_front();     // removes 5; returns void
dq.pop_back();      // removes 10; returns void
dq[0];              // random access — O(1)
```

:::callout-pitfall[Pitfall — std::queue::pop() returns void]
Same as `std::stack`: `pop()` returns `void`. Retrieve the value with `front()` (or `back()`) first, then call `pop()`. Calling `pop()` on an empty queue is undefined behavior.
:::

:::callout-tip[Tip — std::deque internals]
`std::deque` is implemented as a sequence of fixed-size chunks (a "segmented array"). This gives O(1) push/pop at both ends and O(1) random access, but with higher constant factors than `std::vector`. It does not guarantee contiguous storage.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
What methods does `std::queue` expose? Which does it NOT expose that a deque has?

::::solution[Solution]
std::queue exposes: push, pop, front, back, empty, size. It does NOT expose: push\_front, pop\_back, random access (operator[]), or any iterator. It is intentionally restricted to FIFO access.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Write the correct idiom to dequeue the front element of `std::queue<string> q` into variable `s`.

::::solution[Solution]
```cpp
string s = q.front();
q.pop();
```
::::
:::

## 5. BFS & Level-Order Traversal

:::callout-intuition[Intuition]
Breadth-first search (BFS) explores a graph or tree layer by layer, closest nodes first. The queue is the essential ingredient: we enqueue the start node, then repeatedly dequeue a node, process it, and enqueue all its unvisited neighbors. Because neighbors are processed in the order they were discovered, BFS naturally visits all nodes at distance 1, then distance 2, etc.
:::

### BFS on a Graph

```cpp
void bfs(int start, const vector<vector<int>>& adj) {
    int n = adj.size();
    vector<bool> visited(n, false);
    queue<int> q;
    visited[start] = true;
    q.push(start);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        // process v here
        for (int u : adj[v]) {
            if (!visited[u]) {
                visited[u] = true;
                q.push(u);
            }
        }
    }
}
```

:::callout-pitfall[Pitfall — Mark visited at enqueue, not dequeue]
Mark `visited[u] = true` *when you enqueue* a node, not when you dequeue it. If you wait until dequeue, the same node can be enqueued multiple times by different neighbors, causing redundant processing and O(E) extra enqueue operations (or even infinite loops on undirected graphs).
:::

### Level-Order Traversal of a Binary Tree

Level-order traversal visits all nodes at depth 0, then depth 1, then depth 2, etc. Use a queue: the key to tracking level boundaries is counting nodes at the current level.

```cpp
struct TreeNode { int val; TreeNode *left, *right; };

vector<vector<int>> levelOrder(TreeNode* root) {
    vector<vector<int>> result;
    if (!root) return result;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        int levelSize = q.size();   // all nodes at current level
        vector<int> level;
        for (int i = 0; i < levelSize; ++i) {
            TreeNode* node = q.front(); q.pop();
            level.push_back(node->val);
            if (node->left)  q.push(node->left);
            if (node->right) q.push(node->right);
        }
        result.push_back(level);
    }
    return result;
}
```

:::example[Example 6.5 — Level-order traversal trace]
Binary tree: root=1, 1.left=2, 1.right=3, 2.left=4, 2.right=5. Trace level-order.

::::answer[Answer]
Result: [[1], [2, 3], [4, 5]]
::::

Work

| Iteration | Queue at start | levelSize | Nodes processed | Nodes enqueued |
| --- | --- | --- | --- | --- |
| 1 | [1] | 1 | 1 | 2, 3 |
| 2 | [2, 3] | 2 | 2, 3 | 4, 5 (from 2); 3 has no children |
| 3 | [4, 5] | 2 | 4, 5 | (leaf nodes, nothing enqueued) |
:::

:::example[Example 6.6 — BFS shortest path]
Graph: 0—1, 0—2, 1—3, 2—3, 3—4. Find shortest path (in hops) from 0 to 4.

::::answer[Answer]
Shortest path length: 3 hops (e.g., 0→1→3→4 or 0→2→3→4).
::::

Work

BFS from 0: dist[0]=0. Enqueue 0. Process 0: enqueue 1 (dist=1), 2 (dist=1). Process 1: enqueue 3 (dist=2). Process 2: 3 already visited. Process 3: enqueue 4 (dist=3). Dequeue 4 → done. dist[4] = **3**.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
What data structure does BFS use, and what data structure does DFS use?

::::solution[Solution]
BFS uses a **queue** (FIFO — processes nearest nodes first). DFS uses a **stack** (LIFO — dives deep before backtracking), either explicitly or via the call stack (recursion).
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Trace BFS on an undirected graph with nodes 0–4 and edges {0-1, 0-2, 1-3, 2-4}. Start at node 0. List nodes in the order they are dequeued.

::::solution[Solution]
Enqueue 0, mark 0. Dequeue 0 → enqueue 1, 2. Dequeue 1 → enqueue 3. Dequeue 2 → enqueue 4. Dequeue 3 (no unvisited neighbors). Dequeue 4. Order: **0, 1, 2, 3, 4**.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
In the level-order traversal, why do we save `int levelSize = q.size()` before the inner loop? What happens if we use `q.size()` as the loop condition directly?

::::solution[Solution]
If we write `for (int i = 0; i < q.size(); ++i)`, `q.size()` grows as we enqueue children during the same iteration. We'd process more nodes than intended in the current level, corrupting the level boundaries. Saving `levelSize` at the start of each outer iteration freezes the count for that level.
::::
:::

:::problem[Problem 4 · challenge]{difficulty="challenge"}
What is the time and space complexity of BFS on a graph with V vertices and E edges?

::::solution[Solution]
Time: O(V + E) — each vertex is enqueued/dequeued once (O(V)), and each edge is examined once when processing its endpoint's adjacency list (O(E)). Space: O(V) — the visited array is O(V) and the queue holds at most O(V) nodes at once (bounded by the widest BFS layer).
::::
:::

## 6. Queue from Two Stacks

:::callout-intuition[Intuition]
A single stack gives LIFO; we need FIFO. Two stacks can "reverse" each other. Think of stack `in` as the inbox and stack `out` as the outbox. Enqueue pushes to `in`. Dequeue pops from `out` — but if `out` is empty, pour all of `in` into `out` first (which reverses the order, giving FIFO). Each element is moved at most once from `in` to `out`, so the amortized cost is O(1).
:::

```cpp
class TwoStackQueue {
    stack<int> in;   // new elements arrive here
    stack<int> out;  // elements leave from here

    void transfer() {
        while (!in.empty()) {
            out.push(in.top());
            in.pop();
        }
    }

public:
    void enqueue(int val) { in.push(val); }

    int dequeue() {
        if (out.empty()) transfer();
        if (out.empty()) throw underflow_error("queue empty");
        int val = out.top(); out.pop();
        return val;
    }

    int front() {
        if (out.empty()) transfer();
        if (out.empty()) throw underflow_error("queue empty");
        return out.top();
    }

    bool empty() const { return in.empty() && out.empty(); }
    int  size()  const { return in.size() + out.size(); }
};
```

:::example[Example 6.7 — Two-stack queue trace]
Trace: enqueue(1), enqueue(2), enqueue(3), dequeue(), enqueue(4), dequeue().

::::answer[Answer]
First dequeue returns 1; second returns 2.
::::

Work

| Operation | in stack | out stack | Return |
| --- | --- | --- | --- |
| enqueue(1) | [1] | [] |  |
| enqueue(2) | [1,2] | [] |  |
| enqueue(3) | [1,2,3] | [] |  |
| dequeue() | [] (poured to out) | [3,2,1] | 1 (out.top=1, pop) |
| enqueue(4) | [4] | [3,2] |  |
| dequeue() | [4] | [3] (2 popped) | 2 |
:::

:::theorem[Theorem 6.1 — Amortized O(1) Dequeue]
In a two-stack queue, each element is pushed to `in` once and moved to `out` at most once. Therefore any sequence of n enqueue/dequeue operations costs O(n) total, giving O(1) amortized per operation.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
What is the worst-case time complexity of a single dequeue call in the two-stack queue?

::::solution[Solution]
O(n) — when `out` is empty and we must transfer all n elements from `in` to `out`. However, this expensive transfer is charged across subsequent cheap dequeues, giving O(1) amortized.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
When does the transfer from `in` to `out` happen? Will we ever transfer when `out` is non-empty?

::::solution[Solution]
Transfer happens only when `out` is empty and a dequeue is requested. We never transfer when `out` is non-empty — doing so would corrupt the FIFO order (elements already in `out` are older than those in `in`).
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Implement a stack using two queues. What is the amortized cost of push and pop?

::::solution[Solution]
Use queues q1 and q2. **Push(x)**: enqueue x to q1 — O(1). **Pop()**: move all but the last element of q1 to q2; dequeue the last from q1 (that's the top); swap q1 and q2 — O(n). Alternatively: push is O(n) by re-enqueuing all old elements after the new one so pop is O(1). Either way, one operation is O(n) worst-case — you can't match two-stack queue's amortized O(1) for both.
::::
:::

## 7. Sliding Window Maximum (Monotonic Deque)

:::callout-intuition[Intuition]
Given array A and window size k, find the maximum in each window of k consecutive elements. The naive approach is O(nk). The key insight: use a **monotonic deque** (double-ended queue) that stores indices and maintains a *decreasing* sequence of A-values from front to back. The front always holds the index of the current window maximum. Elements are removed from the back when they can't be the maximum (smaller than the new element) and from the front when they slide out of the window.
:::

```cpp
vector<int> slidingWindowMax(const vector<int>& A, int k) {
    deque<int> dq;   // stores indices; front = index of current max
    vector<int> result;

    for (int i = 0; i < A.size(); ++i) {
        // Remove indices that are out of the window
        while (!dq.empty() && dq.front() <= i - k)
            dq.pop_front();

        // Remove indices from back whose A-values are less than A[i]
        // (they can never be the max while A[i] is in the window)
        while (!dq.empty() && A[dq.back()] <= A[i])
            dq.pop_back();

        dq.push_back(i);

        // Window is full when i >= k-1
        if (i >= k - 1)
            result.push_back(A[dq.front()]);
    }
    return result;
}
```

:::example[Example 6.8 — Sliding window maximum trace]
A = [1, 3, -1, -3, 5, 3, 6, 7], k = 3. Find maximum in each window.

::::answer[Answer]
result = [3, 3, 5, 5, 6, 7]
::::

Work

| i | A[i] | Deque (indices) | Window | Max |
| --- | --- | --- | --- | --- |
| 0 | 1 | [0] | not full | — |
| 1 | 3 | pop 0 (A[0]=1≤3); push 1 → [1] | not full | — |
| 2 | -1 | push 2 → [1,2] | [1,3,-1] | A[1]=**3** |
| 3 | -3 | push 3 → [1,2,3] | [3,-1,-3] | A[1]=**3** |
| 4 | 5 | front=1≤4-3=1→pop 1; pop 2(A=-1≤5); pop 3(A=-3≤5); push 4 → [4] | [-1,-3,5] | A[4]=**5** |
| 5 | 3 | push 5 → [4,5] | [-3,5,3] | A[4]=**5** |
| 6 | 6 | pop 5(A=3≤6); pop 4(A=5≤6); push 6 → [6] | [5,3,6] | A[6]=**6** |
| 7 | 7 | pop 6(A=6≤7); push 7 → [7] | [3,6,7] | A[7]=**7** |
:::

:::callout-key[Key Insight — O(n) total]
Each index is pushed to the deque exactly once and popped at most once (either from the front when it exits the window, or from the back when a larger element arrives). Total pushes + pops = O(n). This beats the O(nk) naive approach.
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
In the monotonic deque for sliding window max, does the deque store values or indices? Why indices?

::::solution[Solution]
The deque stores **indices**, not values. We need the index to check whether an element has slid out of the window (`dq.front() <= i - k`). Storing only values would lose this position information.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
Apply the sliding window maximum algorithm to A = [2, 1, 5, 3, 6, 4, 8, 2], k = 4. List the result.

::::solution[Solution]
Windows: [2,1,5,3]→5, [1,5,3,6]→6, [5,3,6,4]→6, [3,6,4,8]→8, [6,4,8,2]→8. Result: **[5, 6, 6, 8, 8]**.
::::
:::

:::problem[Problem 3 · challenge]{difficulty="challenge"}
Modify the algorithm to find the sliding window *minimum* instead of maximum. What changes?

::::solution[Solution]
Change the monotone deque to maintain an *increasing* sequence (minimum at front). The back-removal condition flips: remove from back while `A[dq.back()] >= A[i]` (instead of ≤). Everything else stays the same. The front still holds the index of the current window minimum.
::::
:::

## 8. Producer-Consumer & Round-Robin Scheduling

:::callout-intuition[Intuition]
Queues are the canonical model for asynchronous handoffs: a *producer* generates work items and enqueues them; a *consumer* dequeues and processes them. Because the queue is FIFO, items are processed in arrival order — fair, and preserving causality. Round-robin scheduling extends this: when a process uses its CPU time slice, it is re-enqueued at the back, giving every process equal turns.
:::

### Round-Robin CPU Scheduling Simulation

```cpp
struct Process { string name; int burstTime; };

void roundRobin(vector<Process> procs, int quantum) {
    queue<Process> q;
    for (auto& p : procs) q.push(p);
    int time = 0;
    while (!q.empty()) {
        Process p = q.front(); q.pop();
        int run = min(p.burstTime, quantum);
        time += run;
        p.burstTime -= run;
        cout << "t=" << time << ": " << p.name;
        if (p.burstTime > 0) {
            cout << " (remaining=" << p.burstTime << ")\n";
            q.push(p);  // re-enqueue at back
        } else {
            cout << " FINISHED\n";
        }
    }
}
```

:::example[Example 6.9 — Round-robin scheduling trace]
Three processes: P1(burst=6), P2(burst=3), P3(burst=4). Quantum = 2. Trace execution.

::::answer[Answer]
P2 finishes at t=5, P3 at t=10, P1 at t=13.
::::

Work

| t | Process | Runs | Remaining | Queue after |
| --- | --- | --- | --- | --- |
| 0→2 | P1 | 2 | 4 | [P2,P3,P1] |
| 2→4 | P2 | 2 | 1 | [P3,P1,P2] |
| 4→6 | P3 | 2 | 2 | [P1,P2,P3] |
| 6→8 | P1 | 2 | 2 | [P2,P3,P1] |
| 8→9 | P2 | 1 | 0 → DONE | [P3,P1] |
| 9→11 | P3 | 2 | 0 → DONE | [P1] |
| 11→13 | P1 | 2 | 0 → DONE | [] |
:::

:::problem[Problem 1 · easy]{difficulty="easy"}
In the round-robin simulation, where is a process re-enqueued after using its quantum?

::::solution[Solution]
At the **back** of the queue — `q.push(p)`. This gives every other waiting process a chance to run before P runs again, ensuring fairness.
::::
:::

:::problem[Problem 2 · standard]{difficulty="standard"}
In a producer-consumer system with a bounded queue of capacity k, what should the producer do when the queue is full?

::::solution[Solution]
The producer must wait (block) until the consumer dequeues an item, creating space. In practice, this is implemented with a condition variable or semaphore. A common simplified model: the producer spins (busy-waits) or sleeps — but in real systems, blocking is preferred to avoid wasting CPU.
::::
:::

:::problem[Problem 3 · standard]{difficulty="standard"}
Two processes P1(burst=5), P2(burst=3), quantum=2. What is the completion time (turnaround) for each?

::::solution[Solution]
t=0→2: P1 runs, remaining=3. t=2→4: P2 runs, remaining=1. t=4→6: P1 runs, remaining=1. t=6→7: P2 runs 1, finishes. Turnaround P2=7. t=7→8: P1 runs 1, finishes. Turnaround P1=8.
::::
:::

## The Course Implementation

This is the exact CSE 2383 implementation, expanded so that each line can be reconstructed from the queue's rules. It reuses the singly linked `Node` from [Chapter 4's Node class](dsa_ch4_linked_lists.md#the-node-class). Chapter 4 already explains pointers, `nullptr`, `new`, `delete`, `->`, constructors and initializer lists, access labels, `const &`, `::`, destructors, the Rule of Three, and `this`; those ideas receive only short reminders here.

### The mental model: two ends with different jobs

A queue is **first in, first out** (FIFO). The course names the pointer to the next node removed `start` and the pointer to the most recently inserted node `end`.

```text
start -> [3] -> [7] -> [9] <- end
```

`start` marks the next pop; `end` marks the next push.

The representation must preserve these invariants:

1. The queue is empty exactly when `start == nullptr`, and that is also exactly when `end == nullptr`.
2. When the queue is non-empty, `end->next == nullptr`.
3. Following `next` from `start` reaches every node and eventually reaches `end`.

Why push at `end` and pop at `start`, rather than the reverse? Removing the front of a singly linked chain is O(1): `start->next` is the new front. Removing the back is O(n), because the new last node is the predecessor of `end`, and singly linked nodes have no pointer leading backward to it. Adding is O(1) at the front, and it is also O(1) at the back because the queue stores `end`. FIFO requires opposite ends, so the efficient choice is insert at the back and remove at the front.

### The class definition and the posted defect

Here is the source transcription of Dr. Swan's listing, with its documented correction in place:

```cpp
class Queue
{
   private:
      Node *start;
      Node *end;

   public:
      Queue(): start(nullptr), end(nullptr) {} // default contructor
      ~Queue();
      Queue(const Queue &old); // CORRECTED — his page reads `Queue(const Stack &old);`
};
```

The posted page says `Queue(const Stack &old);`, but the definition says `Queue::Queue(const Queue &old)`. A copy constructor for `Queue` must take a `Queue` reference. Because `Stack` and `Queue` are different types, the posted declaration does not declare the later definition; code that tries to copy a `Queue` has no matching declared copy constructor, and the out-of-class definition has no matching member declaration. This is a compile-time error, not a pointer-logic error.

The following is **not a second course listing**. It completes the partial class by retaining the correction and adding the three operation declarations used below:

```cpp
class Queue
{
   private:
      Node *start;
      Node *end;

   public:
      Queue(): start(nullptr), end(nullptr) {} // default contructor
      ~Queue();
      Queue(const Queue &old); // corrected copy constructor

      void push(int data);
      bool pop();
      bool peek(int &data);
};
```

The constructor makes both pointers null, so a new queue satisfies the empty invariant. The semicolon after the closing `}` is mandatory. Chapter 4 takes apart these declaration details in [the LinkedList class definition](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).

### `push`, line by line

`push` appends one node at the back. It is the same pointer operation as [Chapter 4's `LinkedList::append`](dsa_ch4_linked_lists.md#singly-linked-append), using `start` and `end` where the list uses `head` and `tail`.

```text
Before push(9):
start -> [3] -> [7] <- end

After push(9):
start -> [3] -> [7] -> [9] <- end
```

His code, verbatim:

```cpp
void Queue::push(int data)
{
   Node *tmp = new Node(data); // create the new node
   if (start == nullptr) // if the queue is empty
   {
      start = tmp; // set the first/head of the queue to the new node
   }
   else
   {
      end->next = tmp; // set the next node in the chain to the new node
   }
   end = tmp; // set end to the new node
}
```

**Line by line**

- `void Queue::push(int data)` defines the `Queue` member. It returns `void` because insertion has no empty-container failure to report in the course model.
- `Node *tmp = new Node(data);` allocates a node containing the supplied integer. The `Node` constructor initializes `tmp->next` to `nullptr`, which is exactly what a new last node needs.
- `if (start == nullptr)` asks whether the queue was empty. Use `==` for comparison; one `=` would assign null and lose the chain.
- `start = tmp;` gives an empty queue its first node. This branch must not execute `end->next = tmp`, because an empty queue has `end == nullptr` and null cannot be dereferenced.
- `else` selects the non-empty case.
- `end->next = tmp;` attaches the new node after the old last node. `end` is a pointer, so the syntax must be `->`, not `.`.
- `end = tmp;` makes the new node the last node in **both** cases. Keeping this line after the `if`/`else` avoids duplicating it.

On an empty queue, the trace is:

```text
Before push(9):
start -> nullptr
end   -> nullptr

After start = tmp and end = tmp:
start -> [9] <- end
```

Both endpoints now agree that the queue is non-empty, and the constructor-provided null `next` makes `end->next == nullptr`. On a non-empty queue, attaching through the old `end` keeps the old chain reachable, and moving `end` restores the last-node invariant.

### `pop`, line by line

`pop` removes the node at `start` and reports whether that was possible.

His code, verbatim:

```cpp
bool Queue::pop() // this operation is a bool because it can fail if the queue is empty
{
   Node *tmp = start; // store the current top of the queue in a temporary variable
   if (start == nullptr) return false; // return false if the queue is empty

   start = start->next; // set the new value of start to the next node in the queue

   if (start == nullptr) end = nullptr; // if the queue is now empty, set end to nullptr

   delete tmp; // delete the previous start of the stack
   return true; // return true to report that pop worked.
}
```

The comments saying “top of the queue” and “start of the stack” are copied verbatim from the posted page; those nouns are comment errors, not code errors.

**Line by line**

- `bool Queue::pop()` uses its Boolean result for success or failure. There is no data parameter because this operation only removes.
- `Node *tmp = start;` saves the node that may be deleted. On an empty queue this merely stores `nullptr`; the early return prevents any dereference or deletion on that path.
- `if (start == nullptr) return false;` handles the empty case before `start->next` is evaluated.
- `start = start->next;` moves the front to its successor while the old front is still alive.
- `if (start == nullptr) end = nullptr;` detects that the removed node was the only node and restores endpoint agreement.
- `delete tmp;` frees the old front only after its `next` link is no longer needed.
- `return true;` reports that one node was removed.

The one-element case exposes why the `end` reset is necessary:

```text
Before pop():
start -> [9] <- end

After start = start->next:
start -> nullptr
end   -> [9]

After end = nullptr and delete tmp:
start -> nullptr
end   -> nullptr
```

Without `end = nullptr`, deletion would leave `end` pointing at the deleted node: a dangling pointer. It is tempting to say that the next `push` in this exact listing would corrupt memory, but its `start == nullptr` branch actually overwrites `end` before dereferencing it. The first later call that trusts the broken invariant and reads the back—for example, a natural `peek_back` operation—would read freed storage. Likewise, in the common equivalent `push` that tests `end == nullptr`, the next `push` would enter its `else` branch and execute `end->next = tmp`, writing through the dangling pointer and corrupting memory. The reset makes every later operation safe by restoring the invariant immediately instead of depending on this particular `push` to repair it.

For two or more nodes, the new `start` is non-null, `end` is left alone, and the remaining chain still reaches it. For an empty queue, the early return changes neither endpoint.

### `peek`: the uncaptured operation

No `Queue::peek` page was captured. The following code is therefore **not from his pages**; it follows the exact result pattern of `Stack::peek` and uses `start` because that is the next value FIFO will remove:

```cpp
bool Queue::peek(int &data) // return false on an empty queue and return data by reference
{
   if (start == nullptr) return false; // stop before dereferencing an empty queue

   data = start->data; // copy the front value into the caller's variable

   return true; // report that data received a value
}
```

The `bool` reports whether a front node existed; `int &data` carries the value on success. The `&` is required. Without it, assignment would change only a local parameter. A caller uses the same pattern as the stack:

```cpp
int x;
if (q.peek(x))
{
   cout << x;
}
```

Neither success nor failure changes any pointer, so all queue invariants remain true.

### The destructor

His code, verbatim:

```cpp
Queue::~Queue()
{
   while (pop()); // Pop deletes and updates the top and returns false when the queue is empty
                  // so just looping until pop returns false will empty the queue
}
```

This is the same compact pattern explained token by token in [Chapter 5's stack destructor](dsa_ch5_stacks.md#the-destructor-and-while-pop). The semicolon is the empty loop body. Each successful condition call deletes one node; the first failed call stops the loop. Because the final successful `pop` nulls both `start` and `end`, destruction also leaves the empty invariant true.

### The copy constructor: why `push` works here

His code, verbatim:

```cpp
Queue::Queue(const Queue &old) // copy constructor
{
   Node *curr = old.start; // set the current node to be copied to the start of the queue

   start = nullptr; // set the start of the new queue to nullptr
   end = nullptr; // set the end of the new queue to the nullptr

   while (curr != nullptr) // while we aren't at the end of the queue
   {
     push(curr->data); // add the current data to the end of the queue
     curr = curr->next; // move the current node to the next node in the chain
   }
}
```

**Line by line**

- `Queue::Queue(const Queue &old)` defines the corrected copy constructor. `const &` refers to the existing source without modifying or first copying it; Chapter 4 covers the syntax in [the class definition walkthrough](dsa_ch4_linked_lists.md#the-linkedlist-class-definition).
- `Node *curr = old.start;` begins at the source's front.
- `start = nullptr;` and `end = nullptr;` establish a valid empty destination before `push` reads either pointer. A copy constructor does not first run the default constructor, so omitting these assignments would leave indeterminate addresses.
- `while (curr != nullptr)` repeats once per source node.
- `push(curr->data);` allocates and appends a separate node with the current value.
- `curr = curr->next;` advances through the source and guarantees termination.

This constructor **can** reuse `push`. Traversal sees the source front-to-back, and queue `push` appends each value at the destination's back:

```text
old:          start -> [3] -> [7] -> [9] <- end
copy 3:       start -> [3] <- end
copy 7:       start -> [3] -> [7] <- end
copy 9:       start -> [3] -> [7] -> [9] <- end
```

The order is preserved. A stack cannot do this because stack `push` inserts at the traversal's front, reversing the values; see [Chapter 5's copy-constructor trace](dsa_ch5_stacks.md#the-copy-constructor-preserving-stack-order).

### The missing copy assignment operator

The queue owns heap nodes, so it needs all three operations from [Chapter 4's Rule of Three](dsa_ch4_linked_lists.md#the-rule-of-three). Dr. Swan's captured queue pages omit `operator=`. The compiler-generated version would shallow-copy `start` and `end`, leaking the destination's former chain and creating shared ownership.

The following declaration and definition are **not from his pages**:

```cpp
// add this declaration in the public part of Queue
Queue &operator=(const Queue &old); // assign a deep copy of old

// define the copy assignment operator outside the class
Queue &Queue::operator=(const Queue &old) // assign old to this queue
{
   if (this == &old) return *this; // do nothing for self-assignment

   while (pop()); // delete every node currently owned by this queue

   Node *curr = old.start; // begin at the source queue's front
   while (curr != nullptr) // loop through every source node
   {
      push(curr->data); // append a separately allocated copy of the value
      curr = curr->next; // move to the next source node
   }

   return *this; // return the assigned queue
}
```

The self-assignment test must happen before deletion. After the clearing loop, `pop` guarantees both destination pointers are null. Reusing `push` then preserves source order and restores every invariant. The meanings of `this`, `&old`, and `*this` are already explained in [Chapter 4's Rule of Three subsection](dsa_ch4_linked_lists.md#the-rule-of-three).

### Complexity at a glance

Let `n` be the number of nodes copied or destroyed. For assignment, let `m` be the destination's old size and `n` the source size.

| Operation | Time | Why |
| --- | --- | --- |
| `push` | O(1) | `end` directly identifies the insertion point. |
| `pop` | O(1) | `start` directly identifies the removal point and successor. |
| `peek` | O(1) | It reads only `start->data`. |
| Destructor | O(n) | It pops every owned node once. |
| Copy constructor | O(n) | It visits and pushes every source value once. |
| Copy assignment | O(m + n) | It deletes `m` old nodes and copies `n` source nodes. |

## Designing Your Own Container

The deque below is **not from Dr. Swan's captured pages**. It is a new example written in his style to show how an implementation can be derived instead of memorized. We will follow [Chapter 4's method for writing any linked-list operation](dsa_ch4_linked_lists.md#how-to-write-any-linked-list-operation-yourself): draw before and after, list cases, save needed addresses, update endpoints, delete only after repairing links, and check every invariant.

### 1. Decide the interface from the allowed actions and failures

A double-ended queue, or **deque**, permits insertion, removal, and inspection at both ends:

```cpp
void push_front(int data);
void push_back(int data);
bool pop_front();
bool pop_back();
bool peek_front(int &data);
bool peek_back(int &data);
```

The return types come from failure modes:

- `push_front` and `push_back` receive an integer and always perform an insertion in the course model, so they return `void`.
- `pop_front` and `pop_back` cannot remove from an empty deque, so they return `bool`: `false` means no removal; `true` means one node was removed.
- `peek_front` and `peek_back` can also fail on an empty deque, so their `bool` reports success. On success, the separate `int &data` reference carries the stored integer back to the caller. The `&` must appear in both the declaration and definition.

### 2. Choose the representation from what each operation needs

With a singly linked chain and both endpoint pointers, front insertion, back insertion, and front removal are O(1). Back removal is the problem: after deleting the last node, `tail` must move to the preceding node, but a singly linked last node cannot lead backward to that predecessor. Finding it from `head` would cost O(n).

Therefore every node needs both `next` and `prev`, and the deque needs both `head` and `tail`. `prev` gives `pop_back` its new last node in O(1). This is the necessary doubly linked extension of [Chapter 4's Node class](dsa_ch4_linked_lists.md#the-node-class).

The following `Node` and `Deque` definitions are **not from his pages**:

```cpp
class Node // define one doubly linked node
{
   public: // allow the container to use the node's members
      int data; // store one integer
      Node *next; // point toward the back of the deque
      Node *prev; // point toward the front of the deque

      Node(int data): data(data), next(nullptr), prev(nullptr) {} // start detached
};

class Deque // define the double-ended queue
{
   private: // protect the representation invariants
      Node *head; // point to the front node
      Node *tail; // point to the back node

   public: // declare the operations callers may use
      Deque(): head(nullptr), tail(nullptr) {} // construct an empty deque
      ~Deque(); // destroy every owned node
      Deque(const Deque &old); // construct a deep copy
      Deque &operator=(const Deque &old); // assign a deep copy

      void push_front(int data); // add data at the front
      void push_back(int data); // add data at the back
      bool pop_front(); // remove the front node if one exists
      bool pop_back(); // remove the back node if one exists
      bool peek_front(int &data); // copy out the front value if one exists
      bool peek_back(int &data); // copy out the back value if one exists
};
```

The semicolon after each class's closing brace is required. Each out-of-class definition below must repeat the exact declared return type and parameter list.

### 3. Write the invariants before the code

The implementation must make these statements true after construction and after every public operation:

1. The deque is empty exactly when `head == nullptr`, and that is also exactly when `tail == nullptr`.
2. When non-empty, `head->prev == nullptr` and `tail->next == nullptr`.
3. If `x->next` points to `y`, then `y->prev` points back to `x`; if `y->prev` points to `x`, then `x->next` points forward to `y`.
4. Following `next` from `head` reaches every node and ends at `tail`; following `prev` from `tail` reaches every node and ends at `head`.
5. In a one-node deque, `head == tail`, and that node's `prev` and `next` are both null.

The constructor satisfies all five: both endpoints are null, so the deque is validly empty.

### 4. Derive each operation

#### `push_front`

The empty and non-empty drawings reveal the two cases:

```text
Empty before:
head -> nullptr
tail -> nullptr

Empty after push_front(8):
head -> [8] <- tail

Non-empty before:
head -> [5] <-> [2] <- tail

Non-empty after push_front(8):
head -> [8] <-> [5] <-> [2] <- tail
```

In the empty case, both endpoints must become the new node. In the non-empty case, connect the new node to the old head in both directions, then move `head`. The code is **not from his pages**:

```cpp
void Deque::push_front(int data) // add data at the front
{
   Node *tmp = new Node(data); // create a detached node with null links
   if (head == nullptr) // check whether the deque is empty
   {
      head = tmp; // make the new node the front
      tail = tmp; // make the same node the back
   }
   else // handle a deque that already has a front node
   {
      tmp->next = head; // link the new node forward to the old front
      head->prev = tmp; // link the old front backward to the new node
      head = tmp; // move the front pointer to the new node
   }
}
```

Invariant check:

- Empty case: `head` and `tail` both equal `tmp`; its constructor left both links null, so the one-node and endpoint invariants hold.
- Non-empty case: `tmp->prev` remains null, so the new `head` has no predecessor. The two assignments between `tmp` and the old head are reciprocal. `tail` and its null `next` are unchanged, and both traversals still reach every node.

#### `push_back`

This is the mirror image of `push_front`: exchange `head` with `tail`, `next` with `prev`, and forward with backward.

```text
Empty before:
head -> nullptr
tail -> nullptr

Empty after push_back(8):
head -> [8] <- tail

Non-empty before:
head -> [5] <-> [2] <- tail

Non-empty after push_back(8):
head -> [5] <-> [2] <-> [8] <- tail
```

The code is **not from his pages**:

```cpp
void Deque::push_back(int data) // add data at the back
{
   Node *tmp = new Node(data); // create a detached node with null links
   if (tail == nullptr) // check whether the deque is empty
   {
      head = tmp; // make the new node the front
      tail = tmp; // make the same node the back
   }
   else // handle a deque that already has a back node
   {
      tmp->prev = tail; // link the new node backward to the old back
      tail->next = tmp; // link the old back forward to the new node
      tail = tmp; // move the back pointer to the new node
   }
}
```

Invariant check:

- Empty case: both endpoints name the one node, and its constructor-provided null links satisfy both endpoint conditions.
- Non-empty case: `tmp->next` remains null, so the new `tail` has no successor. The old and new back nodes point to each other, `head` is unchanged, and both traversal directions remain connected.

#### `pop_front`

There are three cases: empty, one node, and at least two nodes.

```text
Empty before and after failed pop_front():
head -> nullptr
tail -> nullptr

One node before:
head -> [8] <- tail

One node after:
head -> nullptr
tail -> nullptr

Many nodes before:
head -> [8] <-> [5] <-> [2] <- tail

Many nodes after:
head -> [5] <-> [2] <- tail
```

Save the old head before moving it, repair the new head's backward link when one exists, and delete only afterward. The code is **not from his pages**:

```cpp
bool Deque::pop_front() // remove the front node if one exists
{
   Node *tmp = head; // save the old front node
   if (head == nullptr) return false; // report failure for an empty deque

   head = head->next; // move the front to the next node
   if (head == nullptr) // check whether the removed node was the only node
   {
      tail = nullptr; // make both endpoints agree that the deque is empty
   }
   else // handle a remaining non-empty chain
   {
      head->prev = nullptr; // remove the new front's link to the old front
   }

   delete tmp; // free the detached old front node
   return true; // report that removal succeeded
}
```

Invariant check:

- Empty case: the early return changes nothing, so both endpoints remain null.
- One-node case: moving through the old node's null `next` makes `head` null; setting `tail` null restores endpoint agreement before deletion.
- Many-node case: `head->prev = nullptr` removes the only surviving link to the deleted node. `tail` stays valid, all interior links remain reciprocal, and both traversals cover the shortened chain.

#### `pop_back`

This is the mirror image of `pop_front`. It needs `prev`; that one line is the reason the representation is doubly linked.

```text
Empty before and after failed pop_back():
head -> nullptr
tail -> nullptr

One node before:
head -> [8] <- tail

One node after:
head -> nullptr
tail -> nullptr

Many nodes before:
head -> [8] <-> [5] <-> [2] <- tail

Many nodes after:
head -> [8] <-> [5] <- tail
```

The code is **not from his pages**:

```cpp
bool Deque::pop_back() // remove the back node if one exists
{
   Node *tmp = tail; // save the old back node
   if (tail == nullptr) return false; // report failure for an empty deque

   tail = tail->prev; // move the back to the previous node
   if (tail == nullptr) // check whether the removed node was the only node
   {
      head = nullptr; // make both endpoints agree that the deque is empty
   }
   else // handle a remaining non-empty chain
   {
      tail->next = nullptr; // remove the new back's link to the old back
   }

   delete tmp; // free the detached old back node
   return true; // report that removal succeeded
}
```

Invariant check:

- Empty case: neither endpoint changes.
- One-node case: the old node's null `prev` makes `tail` null, then `head` is also nulled before deletion.
- Many-node case: the new `tail` is reached directly through `prev`; clearing its `next` restores the endpoint rule. The remaining reciprocal links and both traversals are intact.

#### `peek_front`

The cases are empty and non-empty. Peeking does not rearrange any link.

```text
Before and after successful peek_front(data):
head -> [8] <-> [5] <- tail
         |
         +--> data receives 8

Before and after failed peek_front(data):
head -> nullptr
tail -> nullptr
```

The code is **not from his pages**:

```cpp
bool Deque::peek_front(int &data) // copy out the front value if one exists
{
   if (head == nullptr) return false; // stop before dereferencing an empty deque

   data = head->data; // copy the front value into the caller's variable
   return true; // report that data received a value
}
```

Invariant check: failure returns before reading a node; success reads only `data`. Neither case assigns any pointer, so all five invariants remain exactly as they were.

#### `peek_back`

This is the mirror image of `peek_front`: read through `tail` rather than `head`.

```text
Before and after successful peek_back(data):
head -> [8] <-> [5] <- tail
                 |
                 +--> data receives 5

Before and after failed peek_back(data):
head -> nullptr
tail -> nullptr
```

The code is **not from his pages**:

```cpp
bool Deque::peek_back(int &data) // copy out the back value if one exists
{
   if (tail == nullptr) return false; // stop before dereferencing an empty deque

   data = tail->data; // copy the back value into the caller's variable
   return true; // report that data received a value
}
```

Invariant check: the empty case changes nothing and the non-empty case reads only the back integer. No endpoint or link can be broken by either path.

### 5. Complete the Deque's Rule of Three

Because `Deque` owns nodes created with `new`, it needs the three lifetime operations from [Chapter 4's Rule of Three](dsa_ch4_linked_lists.md#the-rule-of-three). The following implementations are **not from his pages**.

The destructor can repeatedly use the already-checked front removal:

```cpp
Deque::~Deque() // destroy every owned node
{
   while (pop_front()); // remove nodes until the empty call returns false
}
```

The semicolon is the empty loop body, exactly as in the course stack and queue destructors.

The copy constructor traverses from front to back and uses `push_back`, so values remain in the same order:

```cpp
Deque::Deque(const Deque &old) // construct a deep copy
{
   head = nullptr; // start with a valid empty destination
   tail = nullptr; // make both empty endpoints agree

   Node *curr = old.head; // begin at the source's front
   while (curr != nullptr) // visit every source node
   {
      push_back(curr->data); // append a separately allocated copy
      curr = curr->next; // advance through the source
   }
}
```

For source values front-to-back `8, 5, 2`, `push_back` builds `8`, then `8, 5`, then `8, 5, 2`. Using `push_front` would build `8`, then `5, 8`, then `2, 5, 8` and reverse the deque, for the same reason stack copying cannot reuse front insertion.

Assignment first protects self-assignment, clears the destination, then performs the same order-preserving copy:

```cpp
Deque &Deque::operator=(const Deque &old) // assign a deep copy
{
   if (this == &old) return *this; // preserve the source during self-assignment

   while (pop_front()); // delete every old destination node

   Node *curr = old.head; // begin at the source's front
   while (curr != nullptr) // visit every source node
   {
      push_back(curr->data); // append a separately allocated copy
      curr = curr->next; // advance through the source
   }

   return *this; // return the assigned deque
}
```

After the clearing loop, both endpoints are null because `pop_front` preserves the invariants. The self-assignment check must be first; otherwise `d = d` would delete the nodes that `old` also names before the copy begins.

### 6. Complexity at a glance

Every public deque operation is O(1): no operation traverses the chain.

| Operation | Time | Directly available address |
| --- | --- | --- |
| `push_front` | O(1) | `head` |
| `push_back` | O(1) | `tail` |
| `pop_front` | O(1) | `head` and `head->next` |
| `pop_back` | O(1) | `tail` and `tail->prev` |
| `peek_front` | O(1) | `head` |
| `peek_back` | O(1) | `tail` |

The lifetime operations necessarily touch every owned or copied node: the destructor and copy constructor are O(n), and assignment is O(m + n) for `m` old destination nodes and `n` source nodes.

### 7. One representation, different restrictions

A stack is a deque whose interface uses only one end: push, pop, and peek all occur at the front. A queue is a deque that pushes at one end and pops and peeks at the other. The structures in these chapters are therefore one linked-chain idea with different restrictions. The restrictions determine which pointers are necessary and which operations must remain fast.

### 8. Design exercises

:::problem[Design exercise 1 · Stack with O(1) size]{difficulty="standard"}
Add an `int size` member to the course `Stack` so that `getSize()` runs in O(1). Which functions must change, and how? Include the copy constructor and copy assignment operator.

::::solution[Solution]
`size` is another invariant: it must equal the number of reachable nodes. The constructor must start it at zero; each successful `push` increments it; each successful `pop` decrements it; `getSize` returns it. The destructor needs no new statement because it calls the updated `pop`. Both deep-copy operations start from an empty count and increment once for every copied node. The following complete class and affected definitions are **not from his pages**:

```cpp
class Stack
{
   private:
      Node *top; // point to the top node
      int size; // store the number of reachable nodes

   public:
      Stack(): top(nullptr), size(0) {} // construct an empty stack
      ~Stack(); // destroy every owned node
      Stack(const Stack &old); // construct a deep copy
      Stack &operator=(const Stack &old); // assign a deep copy

      void push(int data); // add one value
      bool pop(); // remove one value if possible
      bool peek(int &data); // copy out the top value if possible
      int getSize(); // return the stored node count
};

void Stack::push(int data) // add one value
{
   Node *tmp = new Node(data); // create the new node
   tmp->next = top; // link it to the old top
   top = tmp; // make it the new top
   size = size + 1; // count the newly reachable node
}

bool Stack::pop() // remove one value if possible
{
   Node *tmp = top; // save the old top
   if (top == nullptr) return false; // leave size unchanged on failure

   top = top->next; // move to the next node
   delete tmp; // free the old top
   size = size - 1; // count the successful removal
   return true; // report success
}

int Stack::getSize() // return the stored node count
{
   return size; // no traversal is needed
}

Stack::~Stack() // destroy every owned node
{
   while (pop()); // the updated pop also reduces size to zero
}

Stack::Stack(const Stack &old) // construct a deep copy
{
   top = nullptr; // start with an empty chain
   size = 0; // start with an empty count
   Node *curr = old.top; // begin at the source top
   Node *prev = nullptr; // remember the last copied node
   Node *tmp = nullptr; // store each new node
   while (curr != nullptr) // visit every source node
   {
      tmp = new Node(curr->data); // copy the current value
      if (top == nullptr) // check for the first copied node
      {
         top = tmp; // make the first copy the top
      }
      else // handle every later copied node
      {
         prev->next = tmp; // preserve source order
      }
      prev = tmp; // remember the new last copy
      curr = curr->next; // advance through the source
      size = size + 1; // count the copied node
   }
}

Stack &Stack::operator=(const Stack &old) // assign a deep copy
{
   if (this == &old) return *this; // protect self-assignment

   while (pop()); // clear the chain and reduce size to zero

   Node *curr = old.top; // begin at the source top
   Node *prev = nullptr; // remember the last copied node
   Node *tmp = nullptr; // store each new node
   while (curr != nullptr) // visit every source node
   {
      tmp = new Node(curr->data); // copy the current value
      if (top == nullptr) // check for the first copied node
      {
         top = tmp; // make the first copy the top
      }
      else // handle every later copied node
      {
         prev->next = tmp; // preserve source order
      }
      prev = tmp; // remember the new last copy
      curr = curr->next; // advance through the source
      size = size + 1; // count the copied node
   }

   return *this; // return the assigned stack
}
```

`peek` does not change the number of nodes, so its body does not change. The key failure-path detail is that an unsuccessful `pop` returns before decrementing; otherwise an empty stack could acquire a negative size.
::::
:::

:::problem[Design exercise 2 · Sorted singly linked insertion]{difficulty="standard"}
Design `SortedList::insert(int data)` for a singly linked list with `head` and `tail`. It must keep values in ascending order. Enumerate the empty, new-smallest, new-largest, and middle cases, then write the operation.

::::solution[Solution]
The cases come directly from the before/after positions:

1. **Empty:** both `head` and `tail` become the new node.
2. **New smallest:** link the new node to the old `head`, then move `head`.
3. **New largest:** link the old `tail` to the new node, then move `tail`.
4. **Middle:** walk until `curr` is the node after which the new value belongs; save the old successor in `tmp->next`, then link `curr->next` to `tmp`.

Using `<=` for the front test and `>=` for the back test gives duplicates a defined legal position while preserving nondecreasing order. Assume the singly linked `Node` from Chapter 4. This code is **not from his pages**:

```cpp
class SortedList // define the sorted container
{
   private: // protect the endpoint invariants
      Node *head; // point to the smallest value
      Node *tail; // point to the largest value

   public: // declare the caller's interface
      SortedList(): head(nullptr), tail(nullptr) {} // construct an empty list
      void insert(int data); // insert data in ascending position
};

void SortedList::insert(int data) // insert data in ascending position
{
   Node *tmp = new Node(data); // create a detached node for the value

   if (head == nullptr) // handle an empty list
   {
      head = tmp; // make the new node the first node
      tail = tmp; // make the same node the last node
      return; // finish so no later case runs
   }

   if (data <= head->data) // handle a new smallest value
   {
      tmp->next = head; // link the new node to the old first node
      head = tmp; // make the new node the first node
      return; // finish so no later case runs
   }

   if (data >= tail->data) // handle a new largest value
   {
      tail->next = tmp; // link the old last node to the new node
      tail = tmp; // make the new node the last node
      return; // finish so no later case runs
   }

   Node *curr = head; // begin searching from the first node
   while (curr->next->data < data) // stop before the first value not less than data
   {
      curr = curr->next; // move one node forward
   }

   tmp->next = curr->next; // save the old successor behind the new node
   curr->next = tmp; // link the predecessor to the new node
}
```

The middle loop may safely read `curr->next->data`: the earlier largest-value case guarantees the new value is less than `tail->data`, so the loop must stop before `curr` reaches `tail`. In every case, `tail->next` remains null, both endpoints agree about emptiness, and following `next` from `head` reaches values in ascending order through `tail`.
::::
:::

:::summary
## Chapter 6 Summary

| Concept | Key Point | Complexity |
| --- | --- | --- |
| Queue ADT | FIFO: enqueue at back, dequeue from front | All O(1) |
| Circular array | tail = (head + sz) % cap; grow doubles cap | O(1) amortized |
| LinkedQueue | head=front, tail=back; tail=null on empty | O(1) worst-case |
| std::queue pop() | Returns void; use front() first | O(1) |
| std::deque | O(1) push/pop both ends; O(1) random access | O(1) per op |
| BFS | Mark visited at enqueue; queue gives FIFO layer order | O(V+E) |
| Level-order BFS | Save levelSize before inner loop | O(n) |
| Two-stack queue | in-stack → out-stack pour on empty out | O(1) amortized |
| Sliding window max | Monotonic decreasing deque of indices | O(n) |
| Round-robin | Re-enqueue at back after quantum; FIFO = fairness | O(n·bursts) |
| Circular array pitfall | Reset head=0 in grow() after linearizing |  |
| LinkedQueue pitfall | tail=nullptr when queue goes empty |  |
:::

## Exam Prep

Work each problem before revealing the solution. These are representative of CSE 2383 Honors exam questions.

:::problem[Exam Q1 · standard]{difficulty="standard"}
CircularQueue: cap=6, head=4, sz=5. (a) What is the tail index? (b) After dequeue, what is head? (c) After enqueue of one more element (if possible), what is the new tail?

::::solution[Solution]
(a) tail = (4+5)%6 = **3**. (b) After dequeue: head=(4+1)%6=**5**, sz=4. (c) New enqueue: tail=(5+4)%6=**3**. (sz goes to 5 again, cap=6, not full.)
::::
:::

:::problem[Exam Q2 · standard]{difficulty="standard"}
In a LinkedQueue, the queue contains one element. Write the exact state of head and tail pointers before and after dequeuing that last element.

::::solution[Solution]
Before: head → [X | null], tail → [X | null] (both point to the same node). After: val=X. old=head. head=head→next=nullptr. head==nullptr → tail=nullptr. delete old. After: head=nullptr, tail=nullptr, sz=0.
::::
:::

:::problem[Exam Q3 · standard]{difficulty="standard"}
Trace the two-stack queue for: enqueue(A), enqueue(B), enqueue(C), dequeue(), dequeue(), enqueue(D), dequeue(), dequeue(). List return values in order.

::::solution[Solution]
enqueue A,B,C → in=[A,B,C], out=[]. dequeue: out empty → pour: out=[C,B,A]; pop A → return **A**. dequeue: out=[C,B]; pop B → return **B**. enqueue D: in=[D], out=[C]. dequeue: out=[C]; pop C → return **C**. dequeue: out empty → pour: out=[D]; pop D → return **D**. Returns: A, B, C, D (correct FIFO order).
::::
:::

:::problem[Exam Q4 · standard]{difficulty="standard"}
Apply sliding window maximum to A = [4, 2, 8, 3, 1, 9, 6], k = 3. Show the result array.

::::solution[Solution]
Windows: [4,2,8]→8, [2,8,3]→8, [8,3,1]→8, [3,1,9]→9, [1,9,6]→9. Result: **[8, 8, 8, 9, 9]**.
::::
:::

:::problem[Exam Q5 · standard]{difficulty="standard"}
BFS on a tree with level-order result [[1],[2,3],[4,5,6]]. Draw the tree. How many nodes are there? What is the tree's height?

::::solution[Solution]
Tree: root=1; 1's children: 2, 3; 2's children: 4, 5; 3's children: 6 (or 3 has one child, 6). 6 nodes total. Height = 2 (root at depth 0, leaves at depth 2).
::::
:::

:::problem[Exam Q6 · standard]{difficulty="standard"}
Why is the circular array grow() operation O(n), and why does it not hurt amortized performance? State the invariant that ensures this.

::::solution[Solution]
grow() copies all n elements (O(n)). After doubling, the next grow requires n more enqueues. Total copy work over all grows ≤ n (geometric series). Amortized per enqueue = O(n)/n = O(1). The invariant: after each grow, the array is exactly half full, guaranteeing at least n/2 cheap enqueues before the next costly grow.
::::
:::

:::problem[Exam Q7 · challenge]{difficulty="challenge"}
Compare iterative BFS (queue) vs. iterative DFS (stack) on a graph. For each: (a) what is the order nodes are processed? (b) what is the space complexity in the worst case?

::::solution[Solution]
BFS: processes nodes level by level (shortest-path order). Worst-case space: O(V) — a star graph has all V-1 neighbors in the queue at once. DFS: processes nodes by going as deep as possible first. Worst-case space: O(V) — a path graph has all V nodes on the stack (one per recursion level) in the worst case. Both are O(V) space worst-case, but BFS tends to use more space on wide graphs while DFS uses more on deep graphs.
::::
:::

:::problem[Exam Q8 · challenge]{difficulty="challenge"}
The monotonic deque in sliding window maximum pops from both ends. When is each end used, and why? Why does using only one end (a stack) not work?

::::solution[Solution]
Back removals: when a new element A[i] is larger than elements at the back — those elements can never be the window max (they're older and smaller), so they're evicted from the back. Front removals: when an element's index falls outside the current window — it's too old, evicted from the front. A stack (one end) cannot do both: we need back-removal for irrelevant elements AND front-removal for expired ones. The deque's two-ended access is essential for this combined behavior.
::::
:::

---

MSState CSE 2383 Honors — Self-study textbook. Generated for personal study use.
