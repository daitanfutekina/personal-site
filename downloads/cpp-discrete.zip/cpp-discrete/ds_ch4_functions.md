---
title: "DS–4: Functions"
source: "ds_ch4_functions.html"
---

CSE 2813

# DS–4: Functions

§3.1 – §3.8

:::callout-connect
Why functions?

Functions are the formal model for computation itself. A program is a function from inputs to outputs. Hash tables, sorting algorithms, encodings, Big-O notation, and cryptography all rely on precise properties of functions. This chapter gives you the mathematical vocabulary to reason about what programs can and cannot compute.
:::

## §4.1 — Function Definition

:::definition[Definition]
Function

A **function** $f$ from set $A$ to set $B$, written $f: A \to B$, assigns to each element $a \in A$ *exactly one* element $f(a) \in B$. $A$ is the **domain**, $B$ is the **codomain**, and the **range** (or image) is $\{f(a) \mid a \in A\} \subseteq B$.
:::

:::callout-pitfall
Range ≠ Codomain.

The codomain is the declared target type; the range is the set of values actually hit. For $f: \mathbb{R} \to \mathbb{R}$, $f(x) = x^2$: codomain is $\mathbb{R}$, but range is $[0, \infty)$ — not all reals are achieved.
In C++:

int square(int x) { return x\*x; }

has codomain

int

but range = perfect squares fitting in an int.
:::

### Formal Set-Theoretic Definition

A function $f: A \to B$ is a subset of $A \times B$ such that for every $a \in A$, there is exactly one pair $(a, b) \in f$. The conditions are:

- **Totality:** Every $a \in A$ appears as a first component.
- **Uniqueness:** No $a \in A$ appears with two different second components.

```
Domain A
1
2
3

1 → a
2 → c
3 → a

Codomain B
a
b
c
```

This is a valid function: every element of A maps to exactly one element in B. Note: two elements (1 and 3) map to the same output (a) — allowed. Element b is in the codomain but not in the range — also fine.

## §4.2 — One-to-One (Injective) Functions

:::definition[Definition]
Injective (One-to-One)

$f: A \to B$ is **injective** (one-to-one) if different inputs always produce different outputs: $\forall a_1, a_2 \in A,\ a_1 \neq a_2 \Rightarrow f(a_1) \neq f(a_2)$.

Equivalently (the contrapositive, easier to use in proofs): $f(a_1) = f(a_2) \Rightarrow a_1 = a_2$.
:::

:::callout-intuition
Injective = no two arrows land on the same target.

Think of each output element as a parking spot: in an injective function, no two inputs share a spot. This means $|A| \leq |B|$ must hold for an injection to exist (you can't squeeze a bigger set's elements into a smaller set uniquely).
:::

### Proving Injectivity

Prove $f(x) = 3x - 7$ is injective over $\mathbb{R}$.

Suppose $f(a_1) = f(a_2)$. Then $3a_1 - 7 = 3a_2 - 7 \Rightarrow 3a_1 = 3a_2 \Rightarrow a_1 = a_2$. ∎

Disprove: $f(x) = x^2$ is injective over $\mathbb{R}$.

Counterexample: $f(2) = 4 = f(-2)$ but $2 \neq -2$. Not injective. (It *is* injective on $[0, \infty)$ — domain matters!) ∎

## §4.3 — Onto (Surjective) Functions

:::definition[Definition]
Surjective (Onto)

$f: A \to B$ is **surjective** (onto) if every element of the codomain is hit: $\forall b \in B,\ \exists a \in A$ such that $f(a) = b$. Equivalently: range = codomain.
:::

:::callout-intuition
Surjective = every output is reachable.

No output is "left behind." This requires $|A| \geq |B|$ for finite sets.
:::

### Proving Surjectivity

Prove $f: \mathbb{R} \to \mathbb{R}$, $f(x) = 2x + 1$ is surjective.

Let $b \in \mathbb{R}$ (arbitrary element of codomain). We need $a$ such that $f(a) = b$. Set $a = (b-1)/2$. Then $f(a) = 2 \cdot \frac{b-1}{2} + 1 = b - 1 + 1 = b$. Since $a \in \mathbb{R}$ for all $b \in \mathbb{R}$, $f$ is surjective. ∎

:::callout-tip
Standard technique for surjectivity:

Start with an arbitrary $b$ in the codomain. Work backwards to find the preimage $a$ in terms of $b$. Verify $f(a) = b$ and that $a$ is in the domain.
:::

## §4.4 — Bijections & Inverse Functions

:::definition[Definition]
Bijection

$f: A \to B$ is a **bijection** (one-to-one correspondence) if it is both injective AND surjective. A bijection pairs elements of $A$ and $B$ perfectly: every element of $A$ maps to a unique element of $B$, and every element of $B$ is hit exactly once.
:::

| Type | Injective? | Surjective? | Each output used... | Requires |
| --- | --- | --- | --- | --- |
| General | No | No | 0, 1, or many times | — |
| Injective | Yes | No | At most once | $|A| ≤ |B|$ |
| Surjective | No | Yes | At least once | $|A| ≥ |B|$ |
| Bijective | Yes | Yes | Exactly once | $|A| = |B|$ |

### Inverse Functions

:::definition[Definition]
Inverse Function

If $f: A \to B$ is a bijection, then its **inverse** $f^{-1}: B \to A$ is defined by $f^{-1}(b) = a$ whenever $f(a) = b$. We have $f^{-1}(f(a)) = a$ and $f(f^{-1}(b)) = b$ for all $a \in A$, $b \in B$.
:::

:::callout-key
Only bijections have inverses.

If $f$ is not injective, $f^{-1}$ would have to map some output back to multiple inputs — not a function. If $f$ is not surjective, some elements of $B$ have no preimage — $f^{-1}$ would be undefined there.
:::

Example — Find the inverse of $f(x) = 3x - 7$

:::answer
Swap $x$ and $y$: $x = 3y - 7 \Rightarrow y = (x+7)/3$. So $f^{-1}(x) = (x+7)/3$. Check: $f(f^{-1}(x)) = 3 \cdot \frac{x+7}{3} - 7 = x + 7 - 7 = x$. ✓
:::

## §4.5 — Composition of Functions

:::definition[Definition]
Composition

Given $f: A \to B$ and $g: B \to C$, the **composition** $g \circ f: A \to C$ is $(g \circ f)(x) = g(f(x))$. Apply $f$ first, then $g$.
:::

:::callout-pitfall
Order matters!

$g \circ f$ means "f first, then g" — reading right to left. $f \circ g \neq g \circ f$ in general. In C++:

g(f(x))

is $g \circ f$, not $f \circ g$.
:::

Example

Let $f(x) = x^2$ and $g(x) = x + 3$ (both $\mathbb{R} \to \mathbb{R}$).

:::answer
$(g \circ f)(x) = g(f(x)) = g(x^2) = x^2 + 3$

$(f \circ g)(x) = f(g(x)) = f(x+3) = (x+3)^2 = x^2 + 6x + 9$

Different!
:::

### Composition Preserves Key Properties

| Condition | Result |
| --- | --- |
| $f$ and $g$ both injective | $g \circ f$ is injective |
| $f$ and $g$ both surjective | $g \circ f$ is surjective |
| $f$ and $g$ both bijective | $g \circ f$ is bijective, and $(g \circ f)^{-1} = f^{-1} \circ g^{-1}$ |

:::callout-connect
CS application — function pipelines:

Chaining operations (

transform

,

filter

,

map

in functional programming) is composition. Understanding what properties are preserved helps reason about correctness: if your encryption function is bijective, so is the composed encrypt-then-compress scheme (assuming compress is too).
:::

## §4.6 — Floor, Ceiling, and Modular Arithmetic

These functions are ubiquitous in algorithms and programming, and their mathematical properties are essential for algorithm analysis.

:::definition[Definition]
Floor and Ceiling

$\lfloor x \rfloor$ = the largest integer $≤ x$ | $\lceil x \rceil$ = the smallest integer $\geq x$
:::

| $x$ | $\lfloor x \rfloor$ | $\lceil x \rceil$ |
| --- | --- | --- |
| 3.7 | 3 | 4 |
| -3.7 | -4 | -3 |
| 5.0 | 5 | 5 |
| -2.0 | -2 | -2 |
| $1/2$ | 0 | 1 |

### Key Properties

- $\lfloor x \rfloor = n \iff n \leq x < n+1$ | $\lceil x \rceil = n \iff n-1 < x \leq n$
- $\lfloor -x \rfloor = -\lceil x \rceil$ (negate and flip)
- $\lceil n/2 \rceil + \lfloor n/2 \rfloor = n$ for any integer $n$
- $\lfloor x + n \rfloor = \lfloor x \rfloor + n$ for integer $n$

### Modular Arithmetic

:::definition[Definition]
Modulo

For integers $a$ and positive integer $m$: $a \bmod m = a - m \lfloor a/m \rfloor$. This is the remainder when $a$ is divided by $m$. Range: $0 \leq (a \bmod m) < m$.
:::

:::callout-pitfall
Negative numbers in C++ vs. math:

In math, $-7 \bmod 3 = 2$ (always non-negative). In C++,

-7 % 3 == -1

(truncation toward zero). To get the math definition in C++:

((a % m) + m) % m

.
:::

### Congruence

$a \equiv b \ (\bmod\ m)$ (read "$a$ is congruent to $b$ modulo $m$") means $m \mid (a - b)$, equivalently $a \bmod m = b \bmod m$.

Examples

:::answer
$17 \equiv 5 \pmod{6}$ because $17 - 5 = 12 = 6 \times 2$

$-3 \equiv 9 \pmod{6}$ because $-3 - 9 = -12 = 6 \times (-2)$

Congruence is an equivalence relation: reflexive, symmetric, transitive.
:::

### Arithmetic with Congruences

If $a \equiv b \pmod m$ and $c \equiv d \pmod m$, then:

- $(a + c) \equiv (b + d) \pmod m$
- $(a \cdot c) \equiv (b \cdot d) \pmod m$

:::callout-connect
Hashing:

hash(x) = x % table\_size

uses modular arithmetic to map any integer to a valid index. The wraparound property of mod is also why circular buffers work:

next = (pos + 1) % capacity

.
:::

## §4.7 — Special Functions in Computer Science

Several functions arise so frequently in CS that their properties deserve dedicated attention.

| Function | Definition | CS Context | Key Property |
| --- | --- | --- | --- |
| $\log_2 n$ | Inverse of $2^n$ | Tree height, binary search steps | Grows extremely slowly; $\log_2(10^9) \approx 30$ |
| $\lfloor \log_2 n \rfloor + 1$ | Number of bits to represent $n$ | Integer bit width | $\lfloor \log_2 n \rfloor + 1$ bits needed |
| $n!$ | $n \cdot (n-1) \cdots 1$ | Permutation count | Grows faster than exponential: $n! > 2^n$ for $n \geq ?$ |
| Polynomial $p(n)$ | $a_k n^k + \ldots + a_0$ | Polynomial-time algorithms | $O(n^k)$ growth |
| Exponential $c^n$ | $c^n$ for constant $c > 1$ | Brute-force search, NP-hard | Grows faster than any polynomial |

### Growth Rate Hierarchy

$1 < \log n < \sqrt{n} < n < n \log n < n^2 < n^3 < 2^n < n!$

:::callout-key
This hierarchy is the foundation of Big-O.

When you say "binary search is $O(\log n)$" you're saying it grows as the log function — one of the slowest-growing non-constant functions. Verifying an algorithm's time complexity means identifying where it falls in this hierarchy.
:::

### Logarithm Properties

- $\log_b(xy) = \log_b x + \log_b y$
- $\log_b(x^k) = k \log_b x$
- $\log_b x = \log_c x / \log_c b$ (change of base)
- $b^{\log_b x} = x$ and $\log_b(b^x) = x$

## §4.8 — Counting Functions (Pigeonhole Principle)

:::theorem[Theorem]
Pigeonhole Principle

If $f: A \to B$ and $|A| > |B|$, then $f$ is *not* injective — some element of $B$ has at least two preimages. Equivalently: if $n+1$ objects are placed into $n$ pigeonholes, at least one hole contains two objects.
:::

### Applications

Example 1 — Birthday Problem (Simplified)

:::answer
Among 367 people, at least two share a birthday. Domain = 367 people, Codomain = 366 possible birthdays (365 + leap day). $|A| > |B|$ ⇒ not injective ⇒ two people share a birthday. This is a certainty, not a probability statement.
:::

Example 2 — Hash Collisions

:::answer
A hash function maps $n$ keys to a table of size $m$. If $n > m$, by pigeonhole, at least one bucket contains two keys — a collision is inevitable. No hash function can avoid all collisions if $n > m$.
:::

:::theorem[Theorem]
Generalized Pigeonhole

If $n$ objects are placed in $k$ boxes, at least one box contains $\lceil n/k \rceil$ objects.
:::

Example 3 — Worst-case guarantee

:::answer
Among $n = 100$ students assigned to $k = 3$ dormitories, at least one dormitory has $\lceil 100/3 \rceil = \lceil 33.33 \rceil = 34$ students.
:::

:::summary
## Chapter Summary — DS–4: Functions

- **Function $f: A \to B$** assigns each domain element exactly one codomain element. Range (actual outputs) ≤ codomain (declared target set).
- **Injective (1-1):** $f(a_1)=f(a_2) \Rightarrow a_1=a_2$. Different inputs → different outputs. Proof: assume equal outputs, derive equal inputs.
- **Surjective (onto):** Every $b \in B$ has a preimage. Range = codomain. Proof: given arbitrary $b$, construct $a$ with $f(a) = b$.
- **Bijective:** Both injective and surjective. Only bijections have inverses. $|A| = |B|$ required for finite sets.
- **Composition $g \circ f$:** Apply $f$ first, then $g$. Not commutative. Preserves injectivity/surjectivity/bijectivity.
- **Floor/ceiling:** $\lfloor x \rfloor$ rounds down; $\lceil x \rceil$ rounds up. Negative numbers go further from zero on floor.
- **Modular arithmetic:** $a \bmod m$ = remainder in $[0, m)$. Congruence $a \equiv b \pmod m$ means $m \mid (a-b)$. Arithmetic operations preserve congruence.
- **Growth hierarchy:** $1 \ll \log n \ll n \ll n^2 \ll 2^n \ll n!$ — the backbone of algorithm complexity analysis.
- **Pigeonhole:** If $|A| > |B|$, no injection $A \to B$ exists. Guarantees collisions in hash functions, repeated birthdays, etc.
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Classify the Function

For each function from $A = \{1,2,3\}$ to $B = \{a,b,c,d\}$, determine if it is injective, surjective, or bijective. (a) $f = \{(1,a),(2,b),(3,c)\}$. (b) $g = \{(1,a),(2,a),(3,b)\}$. (c) $h = \{(1,a),(2,b),(3,a)\}$ with $B = \{a,b\}$.

::::solution[Solution]
**(a)** Injective (all outputs distinct). NOT surjective (d is not hit). NOT bijective.

**(b)** NOT injective (both 1 and 2 map to a). NOT surjective (c and d not hit).

**(c)** $B = \{a,b\}$, so $|A| = 3 > |B| = 2$. NOT injective (1 and 3 both map to a). Surjective (a is hit by 1 and 3; b is hit by 2 — all of B covered). Not bijective (not injective).
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Floor, Ceiling, and Mod

Compute: (a) $\lfloor 7.9 \rfloor$, (b) $\lceil -3.2 \rceil$, (c) $\lfloor -5.0 \rfloor$, (d) $17 \bmod 5$, (e) $-17 \bmod 5$ (mathematical definition, always non-negative), (f) the number of bits needed to represent $n = 200$ in binary.

::::solution[Solution]
(a) $\lfloor 7.9 \rfloor = 7$ (b) $\lceil -3.2 \rceil = -3$ (smallest integer $\geq -3.2$) (c) $\lfloor -5.0 \rfloor = -5$

(d) $17 = 3 \cdot 5 + 2$, so $17 \bmod 5 = 2$

(e) $-17 = (-4) \cdot 5 + 3$, so $-17 \bmod 5 = 3$. (Or: $-17 \bmod 5 = -17 - 5\lfloor{-17/5}\rfloor = -17 - 5(-4) = -17+20 = 3$.)

(f) $\lfloor \log_2 200 \rfloor + 1 = \lfloor 7.64 \rfloor + 1 = 7 + 1 = 8$ bits. (Check: $2^7 = 128 \leq 200 < 256 = 2^8$.) ✓
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Prove Bijectivity and Find the Inverse

Show that $f: \mathbb{R} \to \mathbb{R}$, $f(x) = \frac{x-1}{x+1}$ is injective but NOT surjective. What is its actual range? What is the inverse on the domain where $f$ is defined?

::::solution[Solution]
**Domain note:** $f$ is undefined at $x = -1$, so domain is $\mathbb{R} \setminus \{-1\}$.

**Injective:** Suppose $f(a) = f(b)$: $\frac{a-1}{a+1} = \frac{b-1}{b+1}$. Cross-multiply: $(a-1)(b+1) = (b-1)(a+1)$. Expand: $ab+a-b-1 = ab+b-a-1$. Simplify: $2a = 2b$, so $a = b$. Injective. \u2713

**Not surjective on $\mathbb{R}$:** Is $f(x) = 1$ possible? $\frac{x-1}{x+1} = 1 \Rightarrow x - 1 = x + 1 \Rightarrow -1 = 1$ — impossible. So 1 is not in the range.

**Range:** $y = \frac{x-1}{x+1}$. Solving for $x$: $y(x+1) = x-1 \Rightarrow yx + y = x - 1 \Rightarrow x(y-1) = -1-y \Rightarrow x = \frac{-(y+1)}{y-1} = \frac{y+1}{1-y}$. This is defined for all $y \neq 1$. Range = $\mathbb{R} \setminus \{1\}$.

**Inverse:** $f^{-1}(y) = \frac{y+1}{1-y}$ on domain $\mathbb{R} \setminus \{1\}$.
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Composition & Properties

Let $f: \mathbb{R} \to \mathbb{R}$, $f(x) = 2x + 1$ and $g: \mathbb{R} \to \mathbb{R}$, $g(x) = x^2$. (a) Find $g \circ f$ and $f \circ g$. (b) Is $g \circ f$ injective? Surjective? (c) Is $f \circ g$ injective? Surjective?

::::solution[Solution]
**(a)** $(g \circ f)(x) = g(2x+1) = (2x+1)^2 = 4x^2+4x+1$

$(f \circ g)(x) = f(x^2) = 2x^2+1$

**(b)** $g \circ f$: $(2x+1)^2$. Is it injective? $f(1) = 9$ and $f(-2) = (-3)^2 = 9$. NOT injective (two inputs give same output). Is it surjective? Range is $[0, \infty)$ (squares are non-negative), so negative numbers aren't hit. NOT surjective.

**(c)** $f \circ g$: $2x^2+1$. Is it injective? $f(-1) = 3 = f(1)$. NOT injective. Is it surjective? Range is $[1, \infty)$ since $x^2 \geq 0$. NOT surjective (e.g., 0 is not achieved).
::::
:::

:::problem[P5]{difficulty="standard"}
P5 — Pigeonhole Application

(a) In a programming contest with 250 participants, each solving problems numbered 1–14, prove that at least $\lceil 250/14 \rceil$ participants solved the same problem number first. (b) A 32-bit hash function maps arbitrarily many possible inputs to one of $2^{32} \approx 4.3 \times 10^9$ buckets. What is the minimum number of distinct inputs that guarantees a collision?

::::solution[Solution]
**(a)** 250 participants, 14 problem slots. By generalized pigeonhole: at least $\lceil 250/14 \rceil = \lceil 17.86 \rceil = 18$ participants solved the same problem first.

**(b)** $2^{32} + 1$ distinct inputs. With $2^{32}$ inputs and $2^{32}$ buckets, it's *possible* (but not guaranteed) to avoid collision. With $2^{32} + 1$ inputs and $2^{32}$ buckets: $|\text{domain}| > |\text{codomain}|$, so by pigeonhole, the hash function cannot be injective — collision guaranteed.
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — Cantor's Hotel (Bijections & Infinity)

Hilbert's Hotel is a hotel with infinitely many rooms numbered $1, 2, 3, \ldots$ (countably infinite). (a) If every room is occupied and a new guest arrives, how can you accommodate them? Write the function that re-assigns existing guests. Is it a bijection? (b) If an infinite bus arrives with countably many new guests, how do you accommodate all of them? (c) What does this tell you about countably infinite sets?

::::solution[Solution]
**(a)** Shift every guest from room $n$ to room $n+1$: define $f(n) = n+1$. This frees up room 1 for the new guest. $f: \mathbb{Z}^+ \to \{2,3,4,\ldots\}$ is a bijection (injective and surjective onto even-numbered rooms shifted). After the move, room 1 is free. Accommodated!

**(b)** Move each existing guest from room $n$ to room $2n$ (all even rooms). New guests take odd rooms: guest $k$ gets room $2k-1$. Function for existing guests: $g(n) = 2n$; for new guests: $h(k) = 2k-1$. All rooms filled exactly once.

**(c)** A countably infinite set can be put in bijection with a proper subset of itself (e.g., $\mathbb{Z}^+$ bijects with the even natural numbers via $n \mapsto 2n$). This is impossible for finite sets — it's a *defining property* of infinite sets (Dedekind's definition). The "same size" notion for infinite sets is captured by bijections, not by the intuition of "more" or "less."
::::
:::

## LeetCode Connections

Functions — especially bijections, modular arithmetic, and the pigeonhole principle — power a surprisingly large class of algorithm problems.

| # | Problem | Difficulty | Connection to This Chapter |
| --- | --- | --- | --- |
| [#933](https://leetcode.com/problems/number-of-recent-calls/) | Number of Recent Calls | Easy | Uses modular indexing for a sliding window — direct application of floor/mod (\u00a74.6). The function mapping timestamps to window counts is bounded by the mod-based circular range check. |
| [#535](https://leetcode.com/problems/encode-and-decode-tinyurl/) | Encode and Decode TinyURL | Medium | Build a bijection: every URL gets a unique short code, and the decode is the inverse function. Illustrates \u00a74.4 (bijection + inverse). A hash map implements the function; the challenge is guaranteeing injectivity (no two URLs get the same code). |
| [#448](https://leetcode.com/problems/find-all-numbers-disappeared-in-an-array/) | Find All Numbers Disappeared in an Array | Easy | The array is supposed to be a bijection $\{1,\ldots,n\} \to \{1,\ldots,n\}$. Missing numbers are elements of the codomain with no preimage — exactly the "not surjective" gaps. Uses the index-as-hash trick (mod-style placement) to find missing values in $O(1)$ space. |
| [#202](https://leetcode.com/problems/happy-number/) | Happy Number | Easy | Repeatedly applying the "sum of squares of digits" function — a function $f: \mathbb{Z}^+ \to \mathbb{Z}^+$. By pigeonhole, since values are bounded, a cycle must eventually appear. Floyd's cycle detection (from DS Ch 17) finds it; the mathematical guarantee it exists is the pigeonhole principle. |
| [#205](https://leetcode.com/problems/isomorphic-strings/) | Isomorphic Strings | Easy | Two strings are isomorphic iff there is a bijection from the characters of one to the characters of the other that maps every occurrence correctly. You must verify both injectivity (no two chars in $s$ map to the same char in $t$) and that the mapping is consistent — a direct application of the bijection definition from \u00a74.4. |
