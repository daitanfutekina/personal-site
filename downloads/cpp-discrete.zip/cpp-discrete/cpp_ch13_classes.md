---
title: "Chapter 13 — Objects & Classes"
crumb: "C++ · Chapter 13"
meta:
  - "Est. study time: ~3 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 13 — Objects & Classes

## Overview

Everything up to here has kept data and the code that operates on it apart. You had an array
of scores and, somewhere else, a function that averaged them; nothing connected the two except
your memory that they went together, and nothing stopped anyone from averaging the wrong array.

A **class** binds them. It puts the data and the operations in one place, and — the part that
matters more — it lets you make the data unreachable from outside, so the only way to change an
object is through the operations you wrote. That is **encapsulation**, and its practical effect
is that a class can guarantee things about itself. A `BankAccount` whose balance is private can
promise it is never negative, because every path that could change it runs through code you
control.

The chapter covers a lot of ground, and the shape is worth knowing in advance:

- **§13.1–13.5** — what a class is, and the public/private split
- **§13.6, §13.11** — constructors, initializer lists, and overloading them
- **§13.7–13.10** — classes containing collections, splitting into files, and testing
- **§13.12–13.14** — `this`, and making operators work on your own types
- **§13.15–13.17** — a vector built from scratch, namespaces, and static members
- **§13.18–13.20** — worked examples and the practice set

The single idea underneath all of it: **a class is a promise about what stays true.**

:::callout-key[What you'll learn]
- `public` and `private`, and why the default matters
- Constructors, member initializer lists, and the cases where assignment is too late
- Why accessors are `const` and parameters are `const&`
- Separate compilation of a class into a header and a source file
- Operator overloading, and the rules for member versus non-member
- `static` members, which belong to the class rather than any object
:::

:::callout-tip[Prerequisites]
Functions and parameter passing from Chapter 7, references from Chapter 6, `vector` and
`string` from Chapter 11, and exceptions from Chapter 15 for the validating examples. Chapter
14 (inheritance) and Chapter 18 (stacks and queues) both build directly on this material.
:::

## §13.1 – §13.3 · OOP Introduction & Defining a Class

**Object-Oriented Programming (OOP)** bundles related data and functions into a single unit
called a **class**. An **object** is one instance of a class — a variable whose type is that
class.

:::callout-intuition[What the bundling actually buys]
The usual list of OOP benefits — encapsulation, reuse, abstraction — is true and slightly
abstract. Here is the concrete version.

Without a class, a bank account is a `string` and a `double` sitting in a function somewhere,
and *any* code that can see them can set the balance to $-5000$. Nothing prevents it. To be
sure the balance is never negative you would have to inspect every line of the program that
touches it, and re-inspect after every change.

With a class, `balance` is private. There are exactly two functions that modify it, both a
dozen lines long, and both check first. The guarantee "this balance is never negative" now
needs a dozen lines of review instead of a whole program — and it stays true when someone else
adds a feature next year.

That is the whole argument. Encapsulation is not hiding for its own sake; it is shrinking the
amount of code that can break an invariant.
:::

### §13.2 Using a class (caller's perspective)

Before defining one, look at how a class is *used*. This is the interface a caller sees, and
designing it before the internals is a good habit.

```cpp
#include <iostream>
#include <string>
using namespace std;

// The class itself is defined in §13.3 below; this is the caller's view.
class BankAccount;
```

The calls a user of the class would write:

```cpp
BankAccount alice("Alice", 500.0);  // construct an object
BankAccount bob;                    // default-constructed object

alice.deposit(200.0);               // call member function
alice.withdraw(50.0);
cout << alice.getBalance() << '\n'; // 650.0

// Objects are independent — alice and bob have separate balances
bob.deposit(1000.0);
cout << bob.getBalance() << '\n';   // 1000.0
```

**The independence is the point of the last two lines.** `alice` and `bob` are separate objects
with their own copies of every data member, exactly as two `int` variables are independent.
Calling `bob.deposit` cannot affect `alice`. That sounds obvious and is worth saying, because
it is the difference between a class and a set of global variables with functions attached.

### §13.3 Defining a class

```cpp
class BankAccount {
private:                          // data members — hidden from outside
    string owner;
    double balance;

public:                           // member functions — the public interface
    // Default constructor
    BankAccount() : owner("Unknown"), balance(0.0) {}

    // Parameterized constructor
    BankAccount(const string& name, double initialBalance)
        : owner(name), balance(initialBalance) {}

    // Mutators (setters) — modify state
    void deposit(double amount) {
        if (amount > 0) balance += amount;
    }
    bool withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    // Accessors (getters) — read-only; declared const
    double getBalance() const { return balance; }
    string getOwner()   const { return owner;   }

    // Display
    void print() const {
        cout << owner << ": $" << balance << '\n';
    }
};
```

The same class as a UML diagram, the notation you will meet in design documents. Three symbols
mark visibility: `−` is private, `#` is protected, and `+` is public. `BankAccount` has nothing
protected — that mark only becomes useful once inheritance does, in §14.2 — but reading a diagram
someone else drew means knowing all three:

```
┌─────────────────────────────────────┐
│            BankAccount              │
├─────────────────────────────────────┤
│ − owner   : string                  │
│ − balance : double                  │
├─────────────────────────────────────┤
│ + BankAccount()                     │
│ + BankAccount(name, balance)        │
│ + deposit(amount)      : void       │
│ + withdraw(amount)     : bool       │
│ + getBalance() const   : double     │
│ + getOwner()   const   : string     │
│ + print()      const   : void       │
└─────────────────────────────────────┘
```

Three things in the class definition deserve more than a glance.

**Both mutators validate, and neither can be bypassed.** `deposit` ignores a non-positive
amount; `withdraw` refuses to overdraw. Because `balance` is private these are the *only* routes
to changing it — so the class can promise the balance never goes negative, and that promise
holds no matter who writes the calling code.

**`withdraw` returns `bool` and `deposit` returns `void`, an asymmetry worth questioning.** A
withdrawal can fail for a reason the caller must know about, so it reports success. A deposit of
a negative amount is silently ignored — arguably worse, since the caller believes money was
added. Throwing `invalid_argument`, as §13.5 does, would be the stronger design.

**Every accessor is `const`.** That keyword after the parameter list promises the function does
not modify the object, and the compiler enforces it. It is not decoration: without it you cannot
call `getBalance()` on a `const BankAccount&`, which is how objects are almost always passed.
Forgetting `const` on a getter is the commonest cause of "passing `const BankAccount` as `this`
discards qualifiers", an error message that does not obviously point at the missing keyword.

:::callout-key[What `private` and `public` actually mean]
`private` members can be accessed only by member functions of the class itself. External code
cannot read *or* write them — `alice.balance` will not compile.

`public` members form the interface: everything a user of the class needs and nothing more.

That separation is **encapsulation**, and its practical value is that the two halves change at
different rates. You can rewrite how `balance` is stored — as an integer count of cents, say, to
avoid floating-point rounding — and no calling code changes at all, because no calling code ever
touched it.

**Note the default.** In a `class`, members are private unless you say otherwise; in a `struct`
they are public. That is the *only* difference between the two keywords in C++.
:::

## §13.4 – §13.5 · Inline Functions, Accessors & Mutators

### §13.4 Inline member functions

Functions defined inside the class body are automatically **inline** — the compiler may expand
the call in place rather than generating a real function call. Short accessors and mutators are
ideal candidates.

```cpp
class Temperature {
    double celsius;
public:
    // Inline accessor — defined inside class body
    double getCelsius()    const { return celsius; }
    double getFahrenheit() const { return celsius * 9.0/5.0 + 32; }
    double getKelvin()     const { return celsius + 273.15; }

    void setCelsius(double c)    { celsius = c; }
    void setFahrenheit(double f) { celsius = (f - 32) * 5.0/9.0; }
};
```

**Notice there is one data member and three getters.** Fahrenheit and Kelvin are not stored;
they are computed on demand from `celsius`. That is a small but important design choice: storing
all three would mean three values that can disagree, and every setter would have to update the
other two or leave the object inconsistent. One stored value with derived views cannot get out
of step.

**The `9.0/5.0` is deliberately not `9/5`.** With integer literals that expression is 1, and
every temperature would come out wrong by a constant factor — the integer-division trap from
Chapter 19, hiding inside a formula that looks right.

Note this class has no constructor, so `celsius` is uninitialised until someone calls a setter.
Reading `getCelsius()` first gives garbage. The `Thermometer` class in the practice set fixes
exactly that.

### §13.5 Mutators, accessors, and private helpers

```cpp
class Password {
    string hash;                          // stored as hash, never plain text

    // Private helper — used internally only
    string computeHash(const string& plain) const {
        // (simplified hash — real code uses bcrypt/SHA-256)
        size_t h = 0;
        for (char c : plain) h = h * 31 + c;
        return to_string(h);
    }

public:
    void set(const string& plain) {
        if (plain.length() < 8)
            throw invalid_argument("Password must be >= 8 characters");
        hash = computeHash(plain);        // validates before storing
    }

    bool verify(const string& plain) const {
        return computeHash(plain) == hash;
    }
    // No getter for hash — callers NEVER see the stored hash
};
```

This is the strongest argument in the chapter for private data, because what is being protected
is a real security property rather than a tidiness preference.

**There is no getter, and that is the design.** The class exposes `set` and `verify` and nothing
else. A caller can ask "is this the right password?" but cannot ask "what is stored?" — so a
stored hash cannot leak through a log statement, a debug print, or a serialisation routine
someone adds later, because there is no way to obtain it.

**`computeHash` is private because it is an implementation detail.** Replacing the toy hash with
bcrypt changes this one function and nothing else, since no external code ever called it. Had it
been public, callers would start using it and that freedom would be gone.

**Validation happens before storage, in the only place it can.** `set` throws on a short password
*before* computing anything. There is no route into `hash` that skips the check.

The one thing this class does badly is worth saying plainly: the hash shown is not a
cryptographic hash. `h = h*31 + c` is the classic string-hashing function for hash *tables* —
fast, well-distributed, and trivially reversible. The comment says so, and it matters that it
does.

:::callout-intuition[Why a setter beats a public field]
`setX(value)` and a public `x` look equally convenient from outside, and the difference only
shows up later.

A public field can be assigned any value the type allows. Once code across the project depends
on that, adding validation means changing every assignment — and finding them all.

A setter is one function. Adding a range check, a log line, or a notification to observers is a
change in one place, and every existing call site gets it for free. The cost is one extra pair of
parentheses at the call site, paid once; the alternative is paid every time a rule changes.
:::

## §13.6 — Constructors & Member Initializer Lists

A **constructor** is a special member function that runs automatically when an object is
created. It has the same name as the class and no return type — not even `void`.

### Default vs. parameterized constructors

```cpp
class Rectangle {
private:
    double width, height;
public:
    // Default constructor — no arguments
    Rectangle() {
        width  = 1.0;
        height = 1.0;
    }

    // Parameterized constructor
    Rectangle(double w, double h) {
        width  = w;
        height = h;
    }

    double area() const { return width * height; }
};

int main() {
    Rectangle r1;          // calls default constructor  → 1×1
    Rectangle r2(5, 3);   // calls parameterized         → 5×3
    cout << r1.area() << "\n";  // 1
    cout << r2.area() << "\n";  // 15
}
```

**Note `Rectangle r1;` has no parentheses.** Writing `Rectangle r1();` declares a *function*
named `r1` taking no arguments and returning a `Rectangle` — it compiles, and then every attempt
to use `r1` as an object fails with a confusing message. This is the "most vexing parse", and it
catches everyone once.

Both constructors above assign in the body, which works here and is not what you should write.
The next section says why.

:::callout-key[Member initializer lists]
The preferred way to initialize members is the colon syntax, after the parameter list and before
the opening brace:

```cpp
Rectangle(double w, double h) : width(w), height(h) {
    // body can now be empty — members are already initialized
}
```

**The difference is initialize versus assign.** Members are constructed before the body runs, no
matter what. Assigning in the body therefore means: default-construct the member, then throw
that away and assign over it. For a `double` the waste is nothing; for a `string` or `vector`
member it is a whole construction discarded.

For **`const` members** and **reference members**, assignment in the body is not merely wasteful
but illegal — a `const` cannot be assigned after it exists, and a reference cannot be reseated.
The initializer list is the only way to give those a value, which is why the `Circle` below
requires it.
:::

### Why initializer lists matter for `const` and reference members

```cpp
class Circle {
private:
    const double PI = 3.14159265;   // const — must use init list
    double radius;
    const int id;                    // also const

public:
    Circle(double r, int i) : radius(r), id(i) {}
    // Trying to do: id = i;  inside the body is a compile error
    double area() const { return PI * radius * radius; }
};
```

`PI` uses a *default member initializer* — the `= 3.14159265` at the declaration — which applies
to every constructor without repeating it. `id` has no default and so must appear in every
constructor's initializer list; omit it and the compiler refuses, because a `const` member left
uninitialised could never be given a value afterwards.

:::callout-pitfall[Initialization order follows declaration order]
Members are initialized in the order they are **declared in the class**, not the order they
appear in the initializer list. The compiler will usually warn, and the bug is nasty when it does
not:

```cpp
class Bad {
    int size;
    int* data;
public:
    // Written in this order, but data is initialized FIRST — using size,
    // which does not exist yet. The array length is garbage.
    Bad(int n) : data(new int[size]), size(n) {}
};
```

`data` is declared before `size`, so `new int[size]` runs while `size` is still uninitialised.
The list *reads* as though `size(n)` happens first; it does not.

**The habit that avoids it entirely:** always write the initializer list in declaration order.
Then the two orders agree and the question never arises.
:::

:::problem[Practice 13.6 easy]{difficulty="easy"}
**Point3D constructor.** Write a `Point3D` class with `const double x, y, z` members. Provide a
parameterized constructor using an initializer list, and a `distanceTo` method.

::::solution[Solution]
```cpp
#include <cmath>
class Point3D {
private:
    const double x, y, z;
public:
    Point3D(double x, double y, double z) : x(x), y(y), z(z) {}
    double distanceTo(const Point3D& o) const {
        return sqrt(pow(x-o.x,2)+pow(y-o.y,2)+pow(z-o.z,2));
    }
    void print() const {
        cout << "(" << x << ", " << y << ", " << z << ")\n";
    }
};
```

**`x(x)` is not a typo and is not ambiguous.** Inside an initializer list, the name in
parentheses is looked up in the constructor's scope — so it is the *parameter* — while the name
before the parentheses always names the *member*. The compiler knows which is which by position.
Inside the function body the same trick fails, which is where `this->x = x;` becomes necessary
(§13.12).

**`const` members make the object immutable, and that has a consequence.** A `Point3D` cannot be
reassigned after construction, so the compiler deletes its assignment operator — meaning
`vector<Point3D>` will not support operations that move elements around, such as `sort` or
`erase`. That is a real trade: immutability is safe and inflexible. Dropping the `const` buys
back assignment.

**`o.x` reaches into another object's private member, and this is legal.** Access control is per
*class*, not per object: a member function of `Point3D` can see the privates of any `Point3D`.
That is what makes binary operations like comparison and arithmetic writable at all.
::::
:::

## §13.7 — Classes with Vectors of Objects

Classes often contain a `vector` member to manage a collection. The canonical example is a
roster or a playlist.

```cpp
#include <vector>
#include <string>
#include <algorithm>
#include <stdexcept>
#include <iostream>
using namespace std;

class Student {
private:
    string name;
    double gpa;
public:
    Student(const string& n, double g) : name(n), gpa(g) {}
    string getName() const { return name; }
    double getGPA()  const { return gpa;  }
};

class Roster {
private:
    vector<Student> students;

public:
    void addStudent(const Student& s) {
        students.push_back(s);
    }

    void printAll() const {
        for (const Student& s : students)
            cout << s.getName() << " — GPA: " << s.getGPA() << "\n";
    }

    // Find the student with highest GPA
    Student best() const {
        if (students.empty())
            throw logic_error("best() on an empty roster");
        Student top = students[0];
        for (const Student& s : students)
            if (s.getGPA() > top.getGPA()) top = s;
        return top;
    }

    int size() const { return (int)students.size(); }
};

int main() {
    Roster cs101;
    cs101.addStudent(Student("Alice", 3.9));
    cs101.addStudent(Student("Bob",   3.4));
    cs101.addStudent(Student("Carol", 3.95));
    cs101.printAll();
    cout << "Top student: " << cs101.best().getName() << "\n";
}
```

:::callout-pitfall[The empty-container check is not optional]
Written without the `if (students.empty())` guard, `best()` reads `students[0]` on an empty
vector. `operator[]` does no bounds checking, so this is undefined behaviour: it does not throw,
it does not crash reliably, it reads whatever is at that address and constructs a `Student` from
it. The program then reports a top student who does not exist.

**Any function that reads element zero needs this guard**, and the same applies to `front()`,
`back()`, and `*v.begin()`. `max_element` has the same problem in a different shape — it returns
`end()` on an empty range, and dereferencing that is undefined too.

The alternative to throwing is to return `optional<Student>`, which forces the caller to handle
the empty case rather than trusting them to.
:::

Two more details in that code.

**The parameters are `const&`, and so are the loop variables.** `addStudent(const Student& s)`
takes a reference, so the argument is not copied on the way in — only the `push_back` copies,
which is unavoidable since the vector owns its elements. Writing `Student s` instead would copy
twice for no benefit. Similarly `for (const Student& s : students)` avoids copying each student
on every iteration; `for (Student s : students)` would copy all of them, and on a large roster
that is real time spent for nothing.

**`getName()` returns `string` by value, which is a copy.** Returning `const string&` would avoid
it, at the cost of handing out a reference into the object that dangles if the `Student` is
destroyed. For short strings the copy is cheap and the safety is worth it; for a large member you
would return `const&` and document the lifetime.

:::callout-intuition[Pass by `const&`, return by value]
The rule of thumb for objects:

- **Parameters**: `const Type&` when you only read, `Type&` when you modify, `Type` by value only
  when you need your own copy anyway.
- **Returns**: by value unless you are certain the referent outlives the call.

A `const&` parameter costs one pointer to pass, whatever the size of the object, and the `const`
tells both the compiler and the reader that the argument comes back unchanged.
:::

## §13.8 — Separate Files for Classes

Real projects split each class in two.

| File | Contains |
| --- | --- |
| `Rectangle.h` | Class declaration — member variables and function *prototypes* |
| `Rectangle.cpp` | Member function *definitions* using the `Rectangle::` scope operator |
| `main.cpp` | `#include "Rectangle.h"` and uses the class |

:::callout-intuition[Why split at all]
Everything in this chapter so far has been one file, and it worked. The split matters as soon as
more than one file uses the class, for two reasons.

**A definition may appear only once in the whole program.** If two `.cpp` files both included a
file containing the *bodies* of the member functions, the linker would see two copies and refuse.
Declarations may be repeated; definitions may not.

**Rebuild time.** A header is recompiled by everything that includes it, so changing one rebuilds
much of the project. A `.cpp` is compiled once. Putting implementations in the source file means
that changing how a function works — as opposed to its signature — rebuilds exactly one file.
:::

### Rectangle.h

```cpp
#pragma once          // include guard — prevents double inclusion
#include <string>

class Rectangle {
private:
    double width, height;
public:
    Rectangle();
    Rectangle(double w, double h);
    double area()           const;
    double perimeter()      const;
    std::string describe()  const;
};
```

### Rectangle.cpp

```cpp
#include "Rectangle.h"
#include <sstream>
using namespace std;

Rectangle::Rectangle() : width(1.0), height(1.0) {}

Rectangle::Rectangle(double w, double h) : width(w), height(h) {}

double Rectangle::area()      const { return width * height; }
double Rectangle::perimeter() const { return 2*(width + height); }

string Rectangle::describe() const {
    ostringstream oss;
    oss << width << "x" << height
        << " (area=" << area() << ")";
    return oss.str();
}
```

**`Rectangle::` is what says "this is that class's function".** Without it, `double area() const`
in a `.cpp` file is a free function — and one with a stray `const` that will not compile. The
scope operator connects the definition to the declaration in the header.

**`const` must appear in both places** and match exactly. A `const` in the header and none in the
source declares two *different* functions, and the linker reports the declared one as undefined —
an error that points at the call site rather than at the mismatch.

**The header includes `<string>` because it uses `string`; the source includes `<sstream>`
because only the source needs it.** That is the rule: a header includes what its own declarations
need and no more, because everything it includes is inflicted on every file that includes it.

**Note the header writes `std::string` in full and has no `using namespace std;`.** That is
deliberate, and §13.16 explains why: a `using` directive in a header dumps the whole of `std` into
every file that includes it, whether that file wanted it or not. The `.cpp` may have one, because
it affects only itself.

:::callout-key[Include guards]
`#pragma once` prevents a header being processed twice in the same translation unit — which
happens easily, since `main.cpp` might include both `Rectangle.h` and a `Shapes.h` that itself
includes `Rectangle.h`. Without a guard the class would be defined twice and the compiler would
reject it.

The older, fully portable form is a manual include guard:

```cpp
#ifndef RECTANGLE_H
#define RECTANGLE_H
// ... class declaration ...
#endif
```

The first time through, `RECTANGLE_H` is not defined, so the body is compiled and the macro is
set. Any later inclusion finds the macro defined and skips to `#endif`.

Both work. `#pragma once` is simpler and supported by every compiler you are likely to meet; the
manual guard is in the standard and cannot be confused by a file reached through two different
paths. Use one or the other — never neither.
:::

## §13.9 — Choosing What to Make a Class

Good class design starts by finding *nouns* in the problem description that have both **state**
and **behavior**.

| Good class candidate | Why |
| --- | --- |
| `BankAccount` | Has balance, owner; supports deposit, withdraw, getBalance |
| `Student` | Has name, GPA, courses; supports enroll, drop, calculateGPA |
| `Date` | Has year/month/day; supports isLeapYear, daysUntil, advance |

**Both halves are required, and the failure modes differ.**

State with no behaviour is a `struct` — a `Point` with an `x` and a `y` and nothing else does not
need private members and an interface, and making it a class with two getters and two setters
adds ceremony without adding a guarantee.

Behaviour with no state is a free function, or a namespace of them. A class whose only member
function is `static` and which nobody ever instantiates is a namespace wearing a costume.

:::callout-tip[The design heuristic worth remembering]
If several variables always travel together — `x` and `y`, or `hours` and `minutes`, or `red`,
`green` and `blue` — they are asking to become a class or a struct.

The tell is the parameter lists. When you find yourself writing
`double dist(double x1, double y1, double x2, double y2)`, note that nothing stops a caller
passing `(x1, x2, y1, y2)` by mistake, and the compiler will not object because all four are
`double`. `double dist(Point a, Point b)` cannot be called wrongly that way.

Grouping turns a class of runtime bugs into compile errors, which is the best trade available.
:::

## §13.10 — Unit Testing Classes

Testing a class follows the same pattern as testing a function: call it and assert the result.
The one difference is that each test must start from a **fresh object in a known state**.

```cpp
#include <cassert>
#include "BankAccount.h"

void testDeposit() {
    BankAccount acct("Test", 0.0);
    acct.deposit(100.0);
    assert(acct.getBalance() == 100.0);   // passes
    acct.deposit(50.0);
    assert(acct.getBalance() == 150.0);   // passes
}

void testWithdrawInsufficient() {
    BankAccount acct("Test", 50.0);
    acct.withdraw(200.0);                  // should be rejected
    assert(acct.getBalance() == 50.0);    // balance unchanged
}

void testNegativeDeposit() {
    BankAccount acct("Test", 100.0);
    acct.deposit(-50.0);                   // should be rejected
    assert(acct.getBalance() == 100.0);
}

int main() {
    testDeposit();
    testWithdrawInsufficient();
    testNegativeDeposit();
    cout << "All tests passed!\n";
}
```

**Each test constructs its own account**, and that is not redundancy. Sharing one object across
tests makes each depend on the ones before it: a failure in the first leaves the object in an
unexpected state and the rest fail for reasons unrelated to what they were testing. Independent
tests fail independently, which is what makes a failure informative.

**Two of the three tests check that nothing happened.** `testWithdrawInsufficient` and
`testNegativeDeposit` assert the balance is *unchanged* — they test the validation, which is the
part most likely to be wrong and least likely to be exercised by ordinary use.

**`==` on doubles is doing something risky here** and gets away with it. Floating-point equality
is usually wrong, because $0.1 + 0.2 \ne 0.3$ in binary floating point. These particular values
are exactly representable, so the comparison holds — but a test that deposited 0.1 three times and
asserted 0.3 would fail. The robust form compares against a tolerance:
`assert(fabs(acct.getBalance() - 0.3) < 1e-9)`.

**`assert` disappears under `-DNDEBUG`.** It is a development tool, not error handling, and must
never be the thing that validates real input. Note also that a failing `assert` aborts
immediately, so only the first failure in a run is reported; a real test framework would continue
and report all of them.

:::callout-intuition[Test the edges, and test them first]
Zero, negative, empty, one element, maximum — these are where bugs live, because the happy path is
what the author was thinking about while writing the code.

Writing the tests *before* the implementation is Test-Driven Development, and the reason it works
is not discipline but specification: to write `assert(acct.getBalance() == 50.0)` after a failed
withdrawal, you must first decide what a failed withdrawal does. That decision is the hard part,
and TDD forces it to happen before the code rather than after.
:::

## §13.11 — Constructor Overloading

A class may have several constructors as long as their parameter lists differ — the ordinary
overloading rules apply.

```cpp
class Date {
private:
    int month, day, year;

public:
    // No-arg: defaults to Jan 1, 2000
    Date() : month(1), day(1), year(2000) {}

    // Year only
    explicit Date(int y) : month(1), day(1), year(y) {}

    // Full specification
    Date(int m, int d, int y) : month(m), day(d), year(y) {}

    void print() const {
        cout << month << "/" << day << "/" << year << "\n";
    }
};

int main() {
    Date d1;           // 1/1/2000
    Date d2(2024);     // 1/1/2024
    Date d3(5, 19, 2026); // 5/19/2026
    d1.print(); d2.print(); d3.print();
}
```

:::callout-key[`explicit`, and why the one-argument constructor has it]
Without `explicit`, a single-argument constructor doubles as an **implicit conversion** from that
argument type. So `Date(int)` would make an `int` silently convertible to a `Date`, and all of
this would compile:

```cpp
Date d = 2024;              // looks like assigning a number to a date
void schedule(Date when);
schedule(2024);             // an int, silently becoming a date
```

None of that is meant. `explicit` blocks the implicit path while leaving `Date d2(2024);` and
`Date{2024}` working exactly as before.

**The rule: mark every single-argument constructor `explicit` unless you specifically want the
conversion.** The exceptions are types where the conversion genuinely reads well — a `string` from
a `const char*`, for instance.
:::

Note that `Date` performs no validation at all: `Date(13, 45, 2024)` is accepted. A class that
promised to hold a valid date would check in the constructor and throw, and that promise is the
main reason to prefer a class over three loose `int`s.

## §13.12 — The `this` Implicit Parameter

Every non-static member function receives a hidden pointer called `this`, pointing at the object
the method was called on. You rarely need it explicitly, but three situations require it:

1. **Name shadowing** — a parameter with the same name as a member.
2. **Returning the current object** — which enables method chaining.
3. **Passing the object itself** to another function.

```cpp
class Builder {
private:
    int width = 0, height = 0;
    string color = "white";

public:
    // Parameter shadows member — use this-> to disambiguate
    Builder& setWidth(int width) {
        this->width = width;
        return *this;   // return current object → enables chaining
    }

    Builder& setHeight(int height) {
        this->height = height;
        return *this;
    }

    Builder& setColor(const string& color) {
        this->color = color;
        return *this;
    }

    void build() const {
        cout << color << " " << width << "x" << height << "\n";
    }
};

int main() {
    Builder b;
    b.setWidth(800).setHeight(600).setColor("blue").build();
    // Output: blue 800x600
}
```

**In `setWidth`, the bare name `width` means the parameter** — the nearer declaration wins — so
`width = width;` would assign the parameter to itself and leave the member untouched. The compiler
usually warns about self-assignment, but not always, and the object silently keeps its old value.
`this->width` names the member unambiguously.

The alternative is to avoid the collision by naming the parameter differently (`w`, or
`newWidth`), which many codebases prefer precisely because it removes the chance of forgetting the
`this->`.

**The return type is `Builder&`, not `Builder`.** A reference means the chain operates on the
original object; returning by value would copy, and each call in the chain would modify a
different temporary — so `b` would come out unchanged and `build()` would print the defaults. One
missing ampersand, and the whole pattern silently does nothing.

:::callout-intuition[`return *this` is not magic]
`this` is a pointer to the current object, so `*this` is the object, and returning it by reference
hands the caller the same object back.

Method chaining is then just repeated member access on that returned reference: `b.setWidth(800)`
evaluates to `b` itself, so `.setHeight(600)` is called on `b`, and so on. The chain is ordinary
syntax applied to a value that happens to be the object you started with.
:::

## §13.13 & §13.14 — Operator Overloading

C++ lets you redefine what `+`, `==`, `<<` and most other operators mean for your class, so that
user-defined types read as naturally as built-in ones.

### Arithmetic operators

```cpp
class Vector2D {
public:
    double x, y;

    Vector2D(double x = 0, double y = 0) : x(x), y(y) {}

    // Member operator: left operand is *this, right is 'other'
    Vector2D operator+(const Vector2D& other) const {
        return Vector2D(x + other.x, y + other.y);
    }

    Vector2D operator*(double scalar) const {
        return Vector2D(x * scalar, y * scalar);
    }

    Vector2D& operator+=(const Vector2D& other) {
        x += other.x;  y += other.y;
        return *this;
    }

    double magnitude() const { return sqrt(x*x + y*y); }
};

// Non-member: allows  scalar * vector  (left operand is double)
Vector2D operator*(double s, const Vector2D& v) {
    return v * s;
}

// Stream insertion
ostream& operator<<(ostream& out, const Vector2D& v) {
    out << "(" << v.x << ", " << v.y << ")";
    return out;
}

int main() {
    Vector2D a(1, 2), b(3, 4);
    cout << a + b << "\n";      // (4, 6)
    cout << 2.0 * a << "\n";   // (2, 4)
    a += b;
    cout << a << "\n";          // (4, 6)
}
```

**Why `operator*` appears twice.** A member operator's left operand is always the object, so
`Vector2D::operator*(double)` handles `v * 2.0` and *cannot* handle `2.0 * v` — there is no way to
make a `double` the object. The non-member version fills that gap, and it is written in terms of
the member one so the arithmetic exists in exactly one place.

**`operator+` returns by value and is `const`; `operator+=` returns a reference and is not.** That
mirrors what the operators mean. Addition produces a new value and leaves both operands alone, so
it must return a fresh object and can promise not to modify `*this`. Compound assignment modifies
the left operand and yields it, which is what makes `(a += b) += c` work.

**`operator<<` must be a non-member**, and the reason is the same asymmetry: its left operand is an
`ostream`, not your class, and you cannot add members to `ostream`. It takes the stream by
non-const reference and returns it, which is what allows `cout << a << "\n"` to chain — the first
`<<` returns `cout`, and the second operates on that.

### Comparison operators (§13.14)

```cpp
bool operator==(const Vector2D& a, const Vector2D& b) {
    return a.x == b.x && a.y == b.y;
}
bool operator!=(const Vector2D& a, const Vector2D& b) {
    return !(a == b);
}
bool operator<(const Vector2D& a, const Vector2D& b) {
    return a.magnitude() < b.magnitude();   // compare by length
}
```

**`operator!=` is defined in terms of `operator==`**, which is the right habit: two definitions
that can disagree eventually will. Since C++20 the compiler generates `!=` from `==`
automatically, so writing it by hand is no longer necessary.

**`operator<` here compares by magnitude, and that deserves a warning.** It is a legitimate
ordering, but it means two *different* vectors of the same length compare as neither less than nor
greater than each other — while `==` says they are not equal. Any container that assumes "not
less, not greater" implies "equal" — `std::set`, `std::map`, `sort`'s guarantees — will behave
surprisingly. When `<` and `==` disagree about what "the same" means, say so in a comment or make
`<` a total order consistent with `==`.

**And note `a.x == b.x` on doubles**, which has the exact-equality problem from §13.10: two
vectors computed by different routes to the same mathematical point can compare unequal.

:::callout-key[Rules of thumb for operator overloading]
- **Arithmetic and comparison** → non-member, so both operands are treated symmetrically and
  conversions apply equally to each.
- **Assignment-like** (`=`, `+=`, `-=`) → member, because the left operand must be `*this`.
- **`operator<<` and `operator>>`** → non-member, because the left operand is a stream.
- **Never overload an operator with surprising semantics.** `+` should combine, `<` should order,
  `==` should mean equal. An operator whose meaning must be looked up is worse than a named
  function.
- Some operators cannot be overloaded at all: `.`, `.*`, `::`, `?:` and `sizeof`.
:::

:::problem[Practice 13.13 standard]{difficulty="standard"}
**Fraction class.** Implement a `Fraction` with `int num, den`. Overload `+`, `*`, `==` and
`operator<<`. Reduce fractions using GCD in the constructor.

::::solution[Solution]
```cpp
#include <numeric>   // gcd (C++17)
#include <stdexcept>
#include <cstdlib>

class Fraction {
    int num, den;

    void reduce() {
        if (den == 0) throw invalid_argument("Fraction with zero denominator");
        if (den < 0) { num = -num; den = -den; }   // sign lives on the numerator
        int g = gcd(abs(num), abs(den));
        if (g != 0) { num /= g; den /= g; }        // g == 0 only when num == 0
        if (num == 0) den = 1;                     // canonical zero
    }

public:
    Fraction(int n, int d) : num(n), den(d) { reduce(); }

    Fraction operator+(const Fraction& o) const {
        return Fraction(num*o.den + o.num*den, den*o.den); }
    Fraction operator*(const Fraction& o) const {
        return Fraction(num*o.num, den*o.den); }
    bool operator==(const Fraction& o) const {
        return num==o.num && den==o.den; }
    friend ostream& operator<<(ostream& out, const Fraction& f) {
        return out << f.num << "/" << f.den; }
};
```

**Three things `reduce()` has to do, and the naive version does only one.**

*Reject a zero denominator.* Without the check, `gcd(n, 0)` returns `n`, so `Fraction(1,0)` reduces
to `1/0` and survives as a broken object. Worse, `Fraction(0,0)` gives `gcd(0,0) == 0` and the
division by `g` is a division by zero.

*Normalise the sign onto the numerator.* This is the subtle one. Without it, `Fraction(1,-2)`
stores $1/{-2}$ and `Fraction(-1,2)` stores $-1/2$ — the same number, stored two ways. Since
`operator==` compares the stored components, **`Fraction(-1,2) == Fraction(1,-2)` returns false**,
which is simply wrong. Moving the sign to the numerator gives every value one representation, and
equality then works.

*Give zero a canonical form.* `0/5` and `0/7` are both zero and would otherwise compare unequal.
Forcing `den = 1` when the numerator is zero fixes it.

**The general lesson is bigger than fractions.** An `operator==` that compares stored fields is
correct only if each value has exactly one stored form. Whenever a type can represent the same
value two ways, either canonicalise on construction — as here — or make `==` compare
mathematically (`num*o.den == o.num*den`), which for fractions also works and costs two
multiplications.

**`friend` grants `operator<<` access to the private members.** The alternative is public getters;
`friend` is the usual choice for stream operators specifically, because they are part of the
class's own interface rather than outside code.
::::
:::

## §13.15 — Vector ADT Implementation

Building a simplified dynamic array from scratch shows how `std::vector` works underneath.

```cpp
class MyVector {
private:
    int*  data;
    int   sz;       // logical size (elements stored)
    int   cap;      // physical capacity (allocated)

    void resize() {
        cap = (cap == 0) ? 1 : cap * 2;
        int* newData = new int[cap];
        for (int i = 0; i < sz; ++i) newData[i] = data[i];
        delete[] data;
        data = newData;
    }

public:
    MyVector() : data(nullptr), sz(0), cap(0) {}

    ~MyVector() { delete[] data; }

    void push_back(int val) {
        if (sz == cap) resize();
        data[sz++] = val;
    }

    void pop_back() { if (sz > 0) --sz; }

    int  size()           const { return sz; }
    int  operator[](int i) const { return data[i]; }
    int& operator[](int i)       { return data[i]; }

    void print() const {
        cout << "[";
        for (int i = 0; i < sz; ++i)
            cout << data[i] << (i<sz-1 ? ", " : "");
        cout << "]\n";
    }
};
```

**`operator[]` is written twice, and both are needed.** The non-const version returns `int&` so
that `v[0] = 5` works. The const version returns `int` by value and can be called on a
`const MyVector&` — without it, a function taking `const MyVector&` could not read a single
element. The two differ only in constness, which is enough for overload resolution to pick
correctly.

**`pop_back` moves an integer and destroys nothing**, exactly as §18.3's array stack does. The
value stays in memory until overwritten, and `sz` is what makes it unreachable.

**Neither `operator[]` checks bounds**, matching `std::vector`, which also does not — that is what
`.at()` is for. The choice is deliberate: bounds checking on every access costs measurably, and the
standard library leaves it to the caller to opt in.

:::callout-intuition[Why doubling]
Doubling on each resize is what makes `push_back` cheap on average. From capacity 1, the capacities
go $1, 2, 4, 8, \ldots$, so inserting $n$ elements copies

$$
1 + 2 + 4 + \cdots + n < 2n
$$

elements in total — fewer than two copies per push. Each individual `push_back` is $O(1)$
**amortized**, even though the occasional one that triggers a resize is $O(n)$.

Growing by a fixed amount instead — ten slots at a time — would give $n/10$ resizes copying $n/2$
elements on average, which is $O(n^2)$ overall. The multiplicative growth is what collapses the
total into a geometric series.
:::

:::callout-pitfall[This class is missing the Rule of Three]
`MyVector` owns raw memory and defines a destructor, but no copy constructor and no copy assignment
operator. The compiler therefore generates both, and both copy the *pointer*:

```cpp
MyVector a;
a.push_back(1);
MyVector b = a;     // b.data and a.data now point at the same array
```

Two objects now believe they own one array. When both destructors run, `delete[]` is called twice
on the same address — a **double free**, which corrupts the heap. And writing through `b[0]`
changes `a[0]`, since there is only one array.

**The Rule of Three:** if a class needs any one of destructor, copy constructor, or copy assignment
operator, it almost certainly needs all three. (Since C++11 this extends to the Rule of Five,
adding the move constructor and move assignment.)

The alternatives are to implement them, or to forbid copying outright:

```cpp
MyVector(const MyVector&) = delete;
MyVector& operator=(const MyVector&) = delete;
```

which turns a runtime heap corruption into a compile error. Best of all is to hold a `vector<int>`
instead of a raw pointer, at which point the compiler-generated copies are correct and there is no
rule to remember.
:::

## §13.16 — Namespaces

Namespaces prevent name collisions when combining code from several sources. Everything in the C++
standard library lives in namespace `std`.

```cpp
// geometry.h
namespace geometry {
    struct Point { double x, y; };

    inline double distance(Point a, Point b) {
        return sqrt(pow(a.x-b.x,2) + pow(a.y-b.y,2));
    }
}

// physics.h  — also has a Point, no collision!
namespace physics {
    struct Point { double x, y, z; };   // 3-D
}

// main.cpp
int main() {
    geometry::Point p1{0, 0}, p2{3, 4};
    cout << geometry::distance(p1, p2) << "\n";  // 5

    physics::Point p3{1, 2, 3};
    // No ambiguity because of the namespace prefix
}
```

Two libraries can each define `Point` and both remain usable, because the full name of each is
different. Without namespaces the only defence is a prefix on every name — `geo_Point`,
`phys_Point` — which is what C code does and why C library names look the way they do.

Note `inline` on the function in the header: a function *definition* in a header would otherwise be
compiled into every file that includes it, and the linker would see duplicates. `inline` tells it
to expect exactly that and keep one.

### `using` declarations versus `using` directives

```cpp
using std::cout;   // declaration — imports ONE name (preferred)
using namespace std; // directive — imports EVERYTHING (avoid in headers)
```

:::callout-warning[Never `using namespace std;` in a header]
A header is textually included into every file that asks for it, so a `using` directive at header
scope dumps the whole of `std` into the global namespace of code that never asked and cannot
easily undo it.

The failures are subtle rather than loud. `std::count`, `std::distance`, `std::size` and
`std::data` are all plausible names for something in your own program, and once both are visible
the call becomes ambiguous — or worse, silently resolves to the wrong one. The error appears in a
file that includes your header indirectly, and points nowhere near the cause.

Inside a `.cpp` file it affects only that file and is defensible. In a header, write `std::string`
in full — which is why `Rectangle.h` in §13.8 does.
:::

### Nested namespaces (C++17)

```cpp
namespace university::cs::intro {
    class Student { /* ... */ };
}
// Access:
university::cs::intro::Student s;
```

Before C++17 this needed three nested blocks and three closing braces. For long names, an alias
shortens the use site without importing anything: `namespace uci = university::cs::intro;`.

## §13.17 — Static Data Members and Functions

A **static** member belongs to the *class*, not to any individual object. Every object shares the
one copy.

```cpp
class Counter {
private:
    int id;
    static int count;   // shared across all Counter objects

public:
    Counter() : id(++count) {
        cout << "Counter #" << id << " created\n";
    }
    ~Counter() {
        --count;
        cout << "Counter #" << id << " destroyed\n";
    }

    static int getCount() { return count; }   // no 'this' pointer
};

// Definition OUTSIDE the class (required for static data members)
int Counter::count = 0;

int main() {
    cout << Counter::getCount() << "\n";  // 0
    {
        Counter a, b, c;
        cout << Counter::getCount() << "\n";  // 3
    }
    cout << Counter::getCount() << "\n";  // 0 — destructors ran
}
```

**The declaration inside the class is not a definition.** `static int count;` says the member
exists; `int Counter::count = 0;` at namespace scope is what actually allocates it. Omit the second
line and the code compiles but fails to *link*, with "undefined reference to `Counter::count`" —
an error reported without a line number in the class. (Since C++17, `inline static int count = 0;`
allows both in one place.)

**`getCount()` is `static`, so it has no `this`** and cannot read `id`. It is called as
`Counter::getCount()`, on the class rather than an object, which is what lets `main` ask the count
before any `Counter` exists.

**Destructors run in reverse order at the closing brace**, so `c`, then `b`, then `a` — which is
why the count returns to 0 and the printed destruction order is 3, 2, 1.

**This class conflates two ideas, and the practice problem below separates them.** Using one
counter for both "how many exist" and "what is the next id" means ids get reused: create `a`
(id 1), destroy it, create `b`, and `b` also gets id 1. If the ids are meant to be unique, a
separate never-decremented counter is required.

:::callout-key[Rules for static members]
- Static **data** members must be *defined* outside the class, usually in the `.cpp` file — or
  declared `inline` since C++17.
- Static **member functions** have no `this` and cannot touch non-static members.
- Call them as `ClassName::function()`. Calling through an instance compiles but misleads the
  reader into thinking the object matters.
- Common uses: counters, shared constants, factory methods, and the singleton pattern.
:::

:::problem[Practice 13.17 standard]{difficulty="standard"}
**ID generator.** Create a class `Entity` where each instance receives a unique sequential ID
starting from 1. Use a static counter. Provide `getID()` and a static `totalEntities()`.

::::solution[Solution]
```cpp
class Entity {
    int id;
    static int nextID;
    static int total;
public:
    Entity() : id(nextID++) { ++total; }
    ~Entity() { --total; }
    int getID() const { return id; }
    static int totalEntities() { return total; }
};
int Entity::nextID = 1;
int Entity::total  = 0;
```

**Two counters, because they answer two different questions.** `total` goes up and down with the
population — it is "how many exist right now". `nextID` only ever goes up — it is "how many have
ever existed", which is what makes an id unique.

Merging them, as the `Counter` example above does, breaks uniqueness the moment anything is
destroyed: the count falls, and the next object is issued an id a previous object already used. Any
record keyed by that id now refers to the wrong entity.

**`id(nextID++)` uses post-increment deliberately.** It yields the value *before* incrementing, so
the first entity gets 1 and `nextID` becomes 2. Pre-increment would start the ids at 2.

**One thing this does not handle:** the copy constructor. `Entity b = a;` is compiler-generated, so
it copies `a`'s id and never touches either counter — two entities with the same id, and a `total`
that undercounts. Fixing it means writing a copy constructor that allocates a fresh id, which is a
case where the Rule of Three applies for reasons that have nothing to do with memory.
::::
:::

## §13.18 — Worked Example: Employee Salary Manager

This combines classes, vectors, operator overloading and separated concerns into a small payroll
system.

```cpp
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <stdexcept>
using namespace std;

class Employee {
private:
    string name;
    double hourlyRate;
    double hoursWorked;

public:
    Employee(const string& n, double rate)
        : name(n), hourlyRate(rate), hoursWorked(0) {}

    void logHours(double h) {
        if (h < 0) throw invalid_argument("Hours cannot be negative");
        hoursWorked += h;
    }

    double grossPay() const {
        // Time-and-a-half for hours over 40
        if (hoursWorked <= 40)
            return hoursWorked * hourlyRate;
        return 40 * hourlyRate + (hoursWorked - 40) * hourlyRate * 1.5;
    }

    string getName()     const { return name; }
    double getHours()    const { return hoursWorked; }
    double getRate()     const { return hourlyRate; }

    bool operator<(const Employee& o) const {
        return grossPay() < o.grossPay();   // sort by pay
    }

    friend ostream& operator<<(ostream& out, const Employee& e) {
        out << e.name << ": $" << e.grossPay();
        return out;
    }
};

class Payroll {
    vector<Employee> staff;
public:
    void hire(const Employee& e) { staff.push_back(e); }

    double totalPayroll() const {
        double total = 0;
        for (const auto& e : staff) total += e.grossPay();
        return total;
    }

    void printSortedByPay() {
        sort(staff.begin(), staff.end());
        for (const auto& e : staff) cout << e << "\n";
    }

    Employee& topEarner() {
        if (staff.empty()) throw logic_error("topEarner() on empty payroll");
        return *max_element(staff.begin(), staff.end());
    }
};
```

**The overtime rule is where the arithmetic lives, and the two branches must agree at the
boundary.** At exactly 40 hours the first branch gives $40r$; the second would give
$40r + 0 \times 1.5r = 40r$ as well, so the function is continuous there. That is worth checking in
any piecewise calculation — a rule written as `< 40` in one place and `> 40` in another leaves 40
itself undefined or double-counted.

At 45 hours and \$25 an hour the pay is $40(25) + 5(25)(1.5) = 1000 + 187.50 = 1187.50$.

**`operator<` compares computed pay, not a stored field.** That is legitimate and slightly
expensive: `sort` calls it $O(n \log n)$ times and each call recomputes both salaries. For a
payroll it does not matter; for a large dataset you would compute the key once per element.

**`topEarner` returns `Employee&`, a reference into the vector, and that is a hazard.** Any later
`hire()` may reallocate the vector and leave the reference dangling — the amortized growth of
§13.15 moves the whole array. So does `printSortedByPay`, which reorders the elements and leaves
the reference pointing at whoever now occupies that slot. A returned reference into a container is
valid only until the next modification, and that constraint is invisible at the call site.

**`printSortedByPay` is not `const`, and cannot be**, since sorting modifies the vector. Note that
printing a list has changed the stored order as a side effect — a function called "print" that
rearranges your data is a surprise. Sorting a copy, or storing an index order, would leave the
payroll untouched.

## §13.19 — Worked Example: Domain Name Validator

The second worked example applies the same structure to string handling: private helpers doing the
checks, a public interface reporting a single verdict, and validation that cannot be bypassed. Its
shape is the `Password` class of §13.5 scaled up — the rules live in one place, and the object
cannot exist in an invalid state.

## Chapter summary

:::callout-key[Classes and objects]
- `private` data plus `public` functions is what lets a class promise something about itself
- `class` defaults to private, `struct` to public — that is the only difference
- Every accessor should be `const`, or it cannot be called on a `const` object
- Prefer the member initializer list to assignment in the body; for `const` and reference members
  it is the only option
- Members initialize in **declaration** order — write the list to match
- Mark single-argument constructors `explicit` unless the conversion is wanted
- `this->` disambiguates a shadowed member; `return *this` enables chaining
:::

:::callout-tip[Design and mechanics]
- Pass objects as `const Type&`; return by value unless the referent certainly outlives the call
- Guard every function that reads element zero — `best()`, `front()`, `max_element`
- Split into a header and a source once more than one file uses the class; never
  `using namespace std;` in a header
- Arithmetic and comparison operators non-member, assignment-like operators member, `operator<<`
  non-member
- If `==` compares stored fields, make sure each value has exactly one stored form
- A class owning raw memory needs destructor, copy constructor and copy assignment — or should hold
  a `vector` instead
- Static members belong to the class; static data must be defined outside it
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Thermometer.** Write a class storing a temperature in Celsius, with getters for Celsius,
Fahrenheit and Kelvin, and a setter that rejects temperatures below absolute zero.

::::solution[Solution]
```cpp
class Thermometer {
    double celsius;
public:
    Thermometer(double c = 0.0) { setTemperature(c); }
    void setTemperature(double c) {
        if (c < -273.15) throw invalid_argument("Below absolute zero");
        celsius = c;
    }
    double getCelsius()    const { return celsius; }
    double getFahrenheit() const { return celsius * 9.0/5.0 + 32; }
    double getKelvin()     const { return celsius + 273.15; }
};
```

**The constructor calls the setter rather than assigning**, so the validation exists in exactly one
place and applies to construction as well as to later changes. Writing `celsius = c;` in the
constructor would leave one route into the object that skips the check — and it is the first route
every object takes.

**One stored value, three views.** Fahrenheit and Kelvin are computed, so they cannot disagree with
Celsius. Storing all three would require every setter to update the other two.

**`double c = 0.0` gives a default argument**, so this one constructor serves as both the default
and the parameterized constructor. Adding a separate `Thermometer()` alongside it would be
ambiguous — `Thermometer t;` would match both.

**A subtlety at the boundary:** `-273.15` is rejected only if strictly below, so absolute zero
itself is allowed. That is the physically correct choice, and it is worth being deliberate about
which side of a boundary is included.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Matrix2x2.** Build a class storing four doubles in row-major order. Overload `+`, `*` (matrix
multiplication) and `<<`, and provide `determinant()` and `transpose()`.

::::solution[Solution]
```cpp
class Matrix2x2 {
    double a,b,c,d;  // | a b |
public:              // | c d |
    Matrix2x2(double a,double b,double c,double d):a(a),b(b),c(c),d(d){}
    Matrix2x2 operator+(const Matrix2x2& o) const {
        return {a+o.a,b+o.b,c+o.c,d+o.d}; }
    Matrix2x2 operator*(const Matrix2x2& o) const {
        return {a*o.a+b*o.c, a*o.b+b*o.d,
                c*o.a+d*o.c, c*o.b+d*o.d}; }
    double determinant() const { return a*d - b*c; }
    Matrix2x2 transpose() const { return {a,c,b,d}; }
    friend ostream& operator<<(ostream& out, const Matrix2x2& m) {
        return out << "|" << m.a << " " << m.b << "|\n"
                   << "|" << m.c << " " << m.d << "|"; }
};
```

**Matrix multiplication is rows times columns, and the four expressions say so.** The top-left entry
is row 1 of the left matrix against column 1 of the right: $a\cdot o.a + b\cdot o.c$. Note `o.c`,
not `o.b` — the second element of the right matrix's *first column* is its bottom-left entry, which
in row-major storage is `c`. Getting this wrong produces the transpose of the correct answer, and on
a symmetric test matrix it looks right.

**Addition is entrywise; multiplication is not.** This is the commonest misunderstanding about
matrices, and writing both operators side by side makes the difference concrete.

**`operator*` is not commutative**, so `A * B` and `B * A` generally differ — unlike every built-in
numeric type. That is a case where an overloaded operator behaves unlike its usual meaning for a
legitimate reason: it matches the mathematics.

**`return {a+o.a, ...}` uses brace initialization** to construct the return value without naming the
type again. It works because the constructor takes exactly four doubles.

The determinant is $ad - bc$, matching Chapter 3 of the linear algebra course — and it is zero
exactly when the matrix has no inverse.
::::
:::

:::problem[P3 challenge]{difficulty="challenge"}
**String builder with chaining.** Implement a class supporting
`sb.append("Hello").append(", ").append("world").toUpper().build()`.

::::solution[Solution]
```cpp
class StringBuilder {
    string buf;
public:
    StringBuilder& append(const string& s) { buf += s; return *this; }
    StringBuilder& toUpper() {
        for (char& c : buf) c = toupper(c); return *this; }
    StringBuilder& toLower() {
        for (char& c : buf) c = tolower(c); return *this; }
    StringBuilder& reverse() {
        std::reverse(buf.begin(), buf.end()); return *this; }
    string build() const { return buf; }
    void reset() { buf.clear(); }
};
```

**Every mutating method returns `StringBuilder&`** — a reference to the same object — which is what
makes the chain operate on one builder rather than a series of copies. Returning `StringBuilder` by
value instead would leave the original untouched and the whole chain would produce nothing.

**`build()` returns `string` by value and is `const`**, which ends the chain deliberately: it hands
back a copy the caller owns, and the builder is unchanged and reusable.

**`for (char& c : buf)` takes a reference**, so the assignment modifies the buffer. Without the `&`
it would modify a copy of each character and the string would be unchanged — the same
missing-ampersand bug as the chaining return type, in a different place.

**`std::reverse` is qualified because the member is also called `reverse`.** Inside the class, an
unqualified `reverse` finds the member first and the call fails to match. This is exactly the
name-shadowing problem of §13.12, resolved with a namespace rather than with `this->`.

**Why a builder at all.** Repeated `s = s + piece` allocates and copies the whole accumulated string
on every step, which is $O(n^2)$ over $n$ appends. `buf += s` appends in amortized constant time, so
building a large string is linear.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
These ask you to build a class from scratch to a specified interface, which is the skill this
chapter is for.

| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 705 | [Design HashSet](https://leetcode.com/problems/design-hashset/) | Easy | A class with add/remove/contains over buckets |
| 706 | [Design HashMap](https://leetcode.com/problems/design-hashmap/) | Easy | Key-value storage and collision handling |
| 232 | [Implement Queue Using Stacks](https://leetcode.com/problems/implement-queue-using-stacks/) | Easy | A class wrapping two stacks, amortized $O(1)$ |
| 155 | [Min Stack](https://leetcode.com/problems/min-stack/) | Medium | Track the minimum in $O(1)$ with a second stack |
:::
