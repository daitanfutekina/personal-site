---
title: "Branches"
source: "cpp_ch4_branches.html"
---

CSE 1384

# Branches

§4.1 – §4.21

## Chapter Overview

Every program so far has run the same code every time. **Branches** let your program ask a question and choose different paths depending on the answer. This is the first big leap toward programs that actually think — checking grades, validating input, computing variable rates, responding to user choices.

:::callout-key[Prerequisites]
Chapters 1–3. You should be comfortable with variables, arithmetic, and basic I/O.
:::

**What you'll learn:** if/else/else-if chains, relational and logical operators, detecting ranges and gaps, common branching pitfalls, switch statements, the bool type, string and character comparisons and manipulations, the ternary operator, floating-point comparison, and short-circuit evaluation.

## 1 · The if-else Family (§4.1–§4.4)

:::callout-intuition[Intuition]
An `if` statement is a fork in the road. The program evaluates a condition — a yes/no question — and takes one path if the answer is yes (the condition is *true*) and a different path if the answer is no (the condition is *false*). You can chain multiple forks with `else if` to handle several cases.
:::

### Basic if and if-else (§4.1)

```cpp
// if only — code runs when condition is true, skipped otherwise
if (score >= 90) {
    cout << "Excellent!" << endl;
}

// if-else — one branch or the other, never both
if (score >= 60) {
    cout << "Pass" << endl;
} else {
    cout << "Fail" << endl;
}
```

The condition inside `if ( )` is any expression that evaluates to true or false. The six **relational operators** produce boolean results:

| Operator | Meaning | Example (score=85) | Result |
| --- | --- | --- | --- |
| `==` | Equal to | `score == 85` | true |
| `!=` | Not equal to | `score != 90` | true |
| `<` | Less than | `score < 70` | false |
| `>` | Greater than | `score > 80` | true |
| `<=` | Less than or equal | `score <= 85` | true |
| `>=` | Greater than or equal | `score >= 85` | true |

### Detecting Ranges: if-else-if Chains (§4.3–§4.4)

When you have more than two cases, chain them with `else if`. Only the *first* true branch executes — the rest are skipped entirely:

```cpp
int score = 83;

if (score >= 90) {
    cout << "A" << endl;
} else if (score >= 80) {
    cout << "B" << endl;   // ← this one runs (83 >= 80)
} else if (score >= 70) {
    cout << "C" << endl;
} else if (score >= 60) {
    cout << "D" << endl;
} else {
    cout << "F" << endl;
}
```

The `else` at the end is a "catch-all" — it runs only if *none* of the conditions above were true. It's optional but usually good practice to include one.

:::callout-pitfall[= vs == — The Deadliest Bug in C++]
`if (x = 5)` assigns 5 to x and then evaluates to true (because 5 is nonzero). It will **always** be true and silently overwrites x. You almost certainly meant `if (x == 5)`. Many compilers warn about this (`-Wall` flag), but it compiles without error — making it especially dangerous.

```cpp
if (x = 5)    // BUG: assigns 5, then always true
if (x == 5)   // CORRECT: compares x to 5
```

Trick: write constants on the left — `if (5 == x)`. Then accidentally writing `if (5 = x)` is a compile error (you can't assign to a literal).
:::

### Detecting Equal Values (§4.2)

```cpp
char grade = 'B';

if (grade == 'A') {
    cout << "Excellent" << endl;
} else if (grade == 'B') {
    cout << "Good" << endl;        // ← runs
} else if (grade == 'C') {
    cout << "Satisfactory" << endl;
} else {
    cout << "Below passing" << endl;
}
```

:::example[Example 4.1 — Classify a triangle]
Given side lengths a, b, c, classify the triangle as equilateral, isosceles, or scalene.

::::answer[Answer]

::::

```cpp
int a = 5, b = 5, c = 3;

if (a == b && b == c) {
    cout << "Equilateral" << endl;
} else if (a == b || b == c || a == c) {
    cout << "Isosceles" << endl;   // ← runs: a==b
} else {
    cout << "Scalene" << endl;
}
```

(We use `&&` and `||` here — they're explained fully in the next section.)
:::

### Practice — if-else

:::problem[4.1easy]{difficulty="easy"}
Write an if-else statement that prints "positive", "negative", or "zero" based on an integer variable `n`.

::::solution[Solution]
```cpp
if (n > 0) {
    cout << "positive" << endl;
} else if (n < 0) {
    cout << "negative" << endl;
} else {
    cout << "zero" << endl;
}
```
::::
:::

:::problem[4.2easy]{difficulty="easy"}
What is wrong with this code? Fix it.

`int x = 10; if (x = 0) cout << "zero";`

::::solution[Solution]
**Bug:** `x = 0` assigns 0 to x (overwrites the value 10), then evaluates to 0 (false). The condition is always false AND x gets clobbered.

**Fix:** `if (x == 0)`
::::
:::

:::problem[4.3standard]{difficulty="standard"}
Write an if-else-if chain that assigns a letter grade string based on a numeric score: A (90–100), B (80–89), C (70–79), D (60–69), F (below 60).

::::solution[Solution]
```cpp
string letterGrade;
if      (score >= 90) letterGrade = "A";
else if (score >= 80) letterGrade = "B";
else if (score >= 70) letterGrade = "C";
else if (score >= 60) letterGrade = "D";
else                  letterGrade = "F";
```

Order matters — we check from highest to lowest. Because we already entered `else if`, we know the score is below 90 when checking the B condition, so `score >= 80` implicitly means 80–89.
::::
:::

:::problem[4.4challenge]{difficulty="challenge"}
What does this print when `x = 5`? Explain why.

`if (x > 3) cout << "A"; if (x > 4) cout << "B"; else cout << "C";`

::::solution[Solution]
**Output: AB**. This is two *separate* if statements, not an if-else-if chain. The first `if (x > 3)` is true → prints "A". The second `if (x > 4)` is also true → prints "B"; its `else` is skipped. If you wanted "A" or "B or C" (mutually exclusive), you'd need `else if`.
::::
:::

## 2 · Logical Operators (§4.5–§4.7)

:::callout-intuition[Intuition]
Real decisions rarely have a single condition. "Is the speed over 65 AND is it raining?" Both must be true. "Is the user an admin OR a superuser?" Either one qualifies. Logical operators let you combine simple conditions into compound ones.
:::

| Operator | Name | Meaning | True when… |
| --- | --- | --- | --- |
| `&&` | AND | Both conditions true | `a && b` — both a and b are true |
| `||` | OR | At least one true | `a || b` — a is true, or b is true, or both |
| `!` | NOT | Flips true/false | `!a` — a is false |

### Detecting Ranges with Logical Operators (§4.5)

```cpp
int age = 25;

// Range check: both conditions must hold
if (age >= 18 && age <= 65) {
    cout << "Working age adult" << endl;
}

// Common mistake — this does NOT work in C++:
// if (18 <= age <= 65)   ← evaluates as (18 <= age) <= 65
//                           = true <= 65 = 1 <= 65 = true  (always!)
```

### Detecting Ranges with Gaps (§4.6)

Sometimes you want to exclude a sub-range:

```cpp
// "Not between 10 and 20"
if (n < 10 || n > 20) {
    cout << "Outside [10, 20]" << endl;
}

// Equivalent using NOT:
if (!(n >= 10 && n <= 20)) {
    cout << "Outside [10, 20]" << endl;
}
```

### Multiple Features (§4.7)

```cpp
bool hasTicket = true;
int  age = 17;

// Need both conditions:
if (hasTicket && age >= 18) {
    cout << "Admitted" << endl;
} else if (hasTicket && age < 18) {
    cout << "Admitted (minor, guardian required)" << endl;
} else {
    cout << "No ticket — denied" << endl;
}
```

:::example[Example 4.2 — Leap year check]
A year is a leap year if: (divisible by 4) AND (NOT divisible by 100, OR divisible by 400). Check if 2000 and 1900 are leap years.

::::answer[2000: leap year. 1900: not a leap year.]

::::

```cpp
auto isLeap = [](int year) {
    return (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0);
};

cout << isLeap(2000) << endl;  // 1 (true:  div by 400)
cout << isLeap(1900) << endl;  // 0 (false: div by 100, not by 400)
cout << isLeap(2024) << endl;  // 1 (true:  div by 4, not by 100)
cout << isLeap(2023) << endl;  // 0 (false: not div by 4)
```
:::

:::callout-pitfall[Common Logical Pitfalls]
- **Using `&` instead of `&&`:** Single `&` is bitwise AND — it evaluates both sides and operates on bits. `&&` is logical AND with short-circuit evaluation. Use `&&` for conditions.
- **De Morgan's Law confusion:** `!(a && b)` is NOT the same as `!a && !b`. The correct expansion is `!a || !b`. Similarly `!(a || b)` = `!a && !b`.
- **Range written as math:** `0 < x < 10` looks right but compiles as `(0 < x) < 10` = `true < 10` = always true. Write `x > 0 && x < 10`.
:::

### Practice — Logical Operators

:::problem[4.5easy]{difficulty="easy"}
Write a condition that is true when an integer `n` is between 1 and 10 inclusive.

::::solution[Solution]
`n >= 1 && n <= 10`
::::
:::

:::problem[4.6standard]{difficulty="standard"}
A theme park ride requires: height between 48 and 80 inches, AND not a pregnant rider. Write the condition using `bool pregnant` and `int height`.

::::solution[Solution]
```cpp
if (height >= 48 && height <= 80 && !pregnant) {
    cout << "You may ride" << endl;
} else {
    cout << "Sorry, you cannot ride" << endl;
}
```
::::
:::

:::problem[4.7challenge]{difficulty="challenge"}
Apply De Morgan's Law to simplify: `!(x > 0 && y > 0)`. Then verify both forms give the same result for (x=1, y=-1) and (x=1, y=1).

::::solution[Solution]
De Morgan's: `!(A && B)` = `!A || !B`

 So: `!(x > 0 && y > 0)` = `(x <= 0 || y <= 0)`

Verify (x=1, y=-1): original: !(true && false) = !false = **true**. Simplified: false || true = **true** ✓

 Verify (x=1, y=1): original: !(true && true) = !true = **false**. Simplified: false || false = **false** ✓
::::
:::

## 3 · Common Errors & Evaluation Order (§4.8–§4.9)

### Common Branching Errors (§4.8)

| Error | Buggy Code | Problem | Fix |
| --- | --- | --- | --- |
| Assignment in condition | `if (x = 5)` | Always true; overwrites x | `if (x == 5)` |
| Semicolon after if | `if (x > 0); cout << "pos";` | Semicolon ends the if — body always executes | Remove the semicolon |
| Missing braces | `if (x > 0) a++; b++;` | Only `a++` is conditional; `b++` always runs | Add `{ }` around both statements |
| Dangling else | Nested ifs with ambiguous else | Else attaches to nearest if, not the intended one | Always use braces to clarify |
| Math-style range | `if (0 < x < 10)` | Parses as `(0 < x) < 10`, always true | `if (x > 0 && x < 10)` |

#### The Dangling Else Problem

```cpp
// Which if does the else belong to?
if (a > 0)
    if (b > 0)
        cout << "both positive";
    else                        // ← attaches to INNER if (b > 0)
        cout << "a positive, b not";

// To attach else to the outer if:
if (a > 0) {
    if (b > 0)
        cout << "both positive";
}
else {
    cout << "a not positive";
}
```

Rule: an `else` always matches the *nearest preceding unmatched* `if`. Braces eliminate ambiguity. **Always use braces.**

### Order of Evaluation (§4.9)

Operators have precedence — arithmetic is evaluated before comparison, comparison before logical:

```cpp
// Full precedence (high → low, relevant subset):
// 1. !  (unary NOT)
// 2. *  /  %
// 3. +  -
// 4. <  <=  >  >=
// 5. == !=
// 6. &&
// 7. ||
// 8. =  +=  -=  etc.

// Example:
bool result = 2 + 3 > 4 && !false;
// Step 1: 2+3 = 5
// Step 2: 5 > 4 = true
// Step 3: !false = true
// Step 4: true && true = true
```

When in doubt, add parentheses. `(a > 0) && (b < 10)` is clearer than `a > 0 && b < 10` even though both mean the same thing.

### Practice — Errors & Evaluation

:::problem[4.8easy]{difficulty="easy"}
What does this print? `int x = 5; if (x > 3); cout << "big";`

::::solution[Solution]
**"big"** — always, regardless of x. The semicolon after `if (x > 3)` ends the if statement (making it do nothing). `cout << "big"` is a separate statement that always executes.
::::
:::

:::problem[4.9standard]{difficulty="standard"}
Evaluate step-by-step: `bool b = 10 > 5 + 3 || false && true;` What is the value of `b`?

::::solution[Solution]
Step 1: `5 + 3 = 8` (arithmetic first)

 Step 2: `10 > 8 = true`

 Step 3: `false && true = false` (&& before ||)

 Step 4: `true || false = true`

**b = true**
::::
:::

## 4 · Switch Statements (§4.11)

:::callout-intuition[Intuition]
`switch` is a specialized multi-way branch designed for when you're comparing one variable against a list of specific values. It's faster and more readable than a long `if-else-if` chain when all the cases are exact equality checks on an integer or char.
:::

```cpp
int day = 3;

switch (day) {
    case 1:
        cout << "Monday" << endl;
        break;
    case 2:
        cout << "Tuesday" << endl;
        break;
    case 3:
        cout << "Wednesday" << endl;  // ← matches, prints this
        break;
    case 4:
        cout << "Thursday" << endl;
        break;
    case 5:
        cout << "Friday" << endl;
        break;
    default:
        cout << "Weekend" << endl;
        break;
}
```

### The Critical Role of `break`

Without `break`, execution *falls through* to the next case and keeps running until it hits a `break` or the end of the switch. This is a common bug — but also occasionally useful (see below):

```cpp
// BUGGY — forgot break:
switch (x) {
    case 1: cout << "one";    // no break!
    case 2: cout << "two";    // no break!
    case 3: cout << "three"; break;
}
// If x==1: prints "onetwothree" !!

// INTENTIONAL fall-through — group cases that share behavior:
switch (month) {
    case 1: case 3: case 5: case 7:
    case 8: case 10: case 12:
        days = 31; break;
    case 4: case 6: case 9: case 11:
        days = 30; break;
    case 2:
        days = 28; break;   // ignoring leap year here
}
```

:::callout-warning[switch Limitations]
- The switch expression must be an integer type (`int`, `char`, `enum`). Not `double`, not `string`.
- Case labels must be *compile-time constants* (literals or `const` variables). Not expressions like `case x+1:`.
- When in doubt between switch and if-else-if: if all conditions are exact equality on one integer/char variable → switch. Otherwise → if-else-if.
:::

### Practice — Switch

:::problem[4.10easy]{difficulty="easy"}
Write a switch statement that prints the name of a season given an integer month (1–12). Months 12, 1, 2 → Winter; 3–5 → Spring; 6–8 → Summer; 9–11 → Fall.

::::solution[Solution]
```cpp
switch (month) {
    case 12: case 1: case 2:
        cout << "Winter"; break;
    case 3: case 4: case 5:
        cout << "Spring"; break;
    case 6: case 7: case 8:
        cout << "Summer"; break;
    case 9: case 10: case 11:
        cout << "Fall"; break;
    default:
        cout << "Invalid month"; break;
}
```
::::
:::

:::problem[4.11standard]{difficulty="standard"}
Convert this if-else-if chain to a switch statement (assume `char grade`):

`if (grade=='A') cout<<"4.0"; else if (grade=='B') cout<<"3.0"; else if (grade=='C') cout<<"2.0"; else cout<<"below 2.0";`

::::solution[Solution]
```cpp
switch (grade) {
    case 'A': cout << "4.0"; break;
    case 'B': cout << "3.0"; break;
    case 'C': cout << "2.0"; break;
    default:  cout << "below 2.0"; break;
}
```
::::
:::

## 5 · The Boolean Type (§4.12)

C++ has a dedicated `bool` type with exactly two values: `true` and `false`. Internally, `true` = 1 and `false` = 0.

```cpp
bool isAdult    = (age >= 18);    // stores true or false
bool isEven     = (n % 2 == 0);
bool hasLicense = true;
bool isPaused   = false;

// Use boolalpha to print "true"/"false" instead of 1/0:
cout << boolalpha << isAdult << endl;    // "true" or "false"
cout << noboolalpha << isAdult << endl;  // 1 or 0 (default)

// Bool in arithmetic:
int x = true + true;    // 1 + 1 = 2
int y = false * 100;    // 0 * 100 = 0
```

Boolean variables make conditions more readable:

```cpp
// Hard to read:
if (speed > 65 && !seatbeltOn && passengers > 0) { ... }

// Better with named booleans:
bool isSpeeding     = (speed > 65);
bool unsafeDriving  = !seatbeltOn;
bool hasPassengers  = (passengers > 0);

if (isSpeeding && unsafeDriving && hasPassengers) {
    cout << "Issue citation" << endl;
}
```

## 6 · String & Character Operations (§4.13–§4.16)

### String Comparisons (§4.13)

:::callout-intuition[Intuition]
Strings support all six relational operators (`==`, `!=`, `<`, `>`, etc.) and compare *lexicographically* — like a dictionary. "apple" < "banana" because 'a' < 'b'. "Zoo" < "ant" because uppercase letters come before lowercase in ASCII.
:::

```cpp
string s1 = "apple";
string s2 = "banana";
string s3 = "apple";

cout << (s1 == s3) << endl;   // 1 (true)
cout << (s1 < s2)  << endl;   // 1 (true: 'a' < 'b')
cout << (s2 > s1)  << endl;   // 1 (true)
cout << ("Zoo" < "ant") << endl; // 1 (true: 'Z'=90 < 'a'=97 in ASCII)
```

### String Access Operations (§4.14)

```cpp
string s = "Hello, World!";

// Length:
int len = s.length();           // 13

// Access by index (0-based):
char first = s[0];              // 'H'
char last  = s[s.length()-1];   // '!'

// at() — same as [] but with bounds checking (throws exception):
char c = s.at(7);               // 'W'

// Front and back:
cout << s.front() << endl;      // 'H'
cout << s.back()  << endl;      // '!'
```

### Character Operations — `<cctype>` (§4.15)

The `<cctype>` header provides functions that classify and transform individual characters. These return `int` (nonzero = true, 0 = false):

| Function | Returns true when… | Example |
| --- | --- | --- |
| `isalpha(c)` | c is a letter (a-z, A-Z) | `isalpha('A')` → true |
| `isdigit(c)` | c is a digit (0-9) | `isdigit('7')` → true |
| `isalnum(c)` | c is a letter or digit | `isalnum('_')` → false |
| `islower(c)` | c is lowercase letter | `islower('a')` → true |
| `isupper(c)` | c is uppercase letter | `isupper('A')` → true |
| `isspace(c)` | c is whitespace (space, tab, newline) | `isspace(' ')` → true |
| `ispunct(c)` | c is punctuation | `ispunct('!')` → true |
| `tolower(c)` | — | Returns lowercase version of c |
| `toupper(c)` | — | Returns uppercase version of c |

```cpp
#include <cctype>
char ch = 'G';
cout << islower(ch)  << endl;  // 0 (false — it's uppercase)
cout << toupper(ch)  << endl;  // 71 (ASCII of 'G', already uppercase)
cout << (char)tolower(ch);     // 'g'
```

### Finding, Inserting, and Replacing Text (§4.16)

```cpp
string s = "The quick brown fox";

// find() — returns index of first match, or string::npos if not found
int pos = s.find("quick");        // 4
int bad = s.find("cat");          // string::npos (usually 18446744073709551615)

if (s.find("fox") != string::npos) {
    cout << "Found!" << endl;
}

// substr(start, length) — already seen in Ch 2:
cout << s.substr(4, 5) << endl;   // "quick"

// erase(start, length):
s.erase(4, 6);                    // removes "quick " → "The brown fox"

// insert(pos, str):
s.insert(4, "fast ");             // "The fast brown fox"

// replace(start, length, newStr):
s.replace(4, 4, "slow");          // "The slow brown fox"
```

:::example[Example 4.3 — Validate a username]
A username must be 3–12 characters, contain only letters and digits, and start with a letter. Check if "user42" and "42abc" are valid.

::::answer[user42: valid. 42abc: invalid (starts with digit).]

::::

```cpp
#include <cctype>
bool isValidUsername(const string& name) {
    int len = name.length();
    if (len < 3 || len > 12)      return false;
    if (!isalpha(name[0]))        return false;  // must start with letter
    for (int i = 1; i < len; i++) {
        if (!isalnum(name[i]))    return false;  // rest: letters or digits
    }
    return true;
}

cout << isValidUsername("user42") << endl;  // 1 (true)
cout << isValidUsername("42abc")  << endl;  // 0 (false)
cout << isValidUsername("ab")     << endl;  // 0 (too short)
```
:::

### Practice — String & Characters

:::problem[4.12easy]{difficulty="easy"}
What does `cout << ("cat" < "dog") << " " << ("Zebra" < "apple");` print?

::::solution[Solution]
**1 1**. "cat" < "dog" because 'c' (99) < 'd' (100). "Zebra" < "apple" because 'Z' (90) < 'a' (97) in ASCII — uppercase letters have smaller codes than lowercase.
::::
:::

:::problem[4.13standard]{difficulty="standard"}
Write code that converts a string to all-uppercase in place, using a loop (preview: we'll cover loops in Ch 5) — OR, describe the logic without writing the loop.

::::solution[Solution]
```cpp
string s = "Hello World";
for (int i = 0; i < s.length(); i++) {
    s[i] = toupper(s[i]);
}
cout << s;  // HELLO WORLD
```

Logic without the loop: for each character at position i, replace it with `toupper(s[i])`. `toupper` returns the uppercase version of a letter, or the character unchanged if it's not a letter.
::::
:::

:::problem[4.14challenge]{difficulty="challenge"}
Given `string s = "find the needle in find the haystack";`, write code that replaces every occurrence of "find" with "FOUND" using a loop and `find()`/`replace()`.

::::solution[Solution]
```cpp
string s = "find the needle in find the haystack";
string target = "find", replacement = "FOUND";
int pos = 0;
while ((pos = s.find(target, pos)) != string::npos) {
    s.replace(pos, target.length(), replacement);
    pos += replacement.length();  // advance past the replacement
}
cout << s;  // FOUND the needle in FOUND the haystack
```

The second argument to `find(target, pos)` says "start searching from index pos" — this prevents an infinite loop when the replacement is longer than the target.
::::
:::

## 7 · Conditional (Ternary) Expressions (§4.17)

:::callout-intuition[Intuition]
Sometimes you just need to choose between two values based on a condition — and a full `if-else` block feels heavy. The ternary operator `? :` is a compact inline choice: *"if condition, use this value, otherwise use that value."*
:::

```cpp
// Syntax: condition ? value_if_true : value_if_false

int a = 10, b = 20;
int larger = (a > b) ? a : b;    // larger = 20

// Equivalent if-else:
int larger2;
if (a > b) larger2 = a;
else       larger2 = b;

// Common uses:
string result = (score >= 60) ? "Pass" : "Fail";
cout << (x % 2 == 0 ? "even" : "odd") << endl;

// Nested ternary (readable if kept simple):
string grade = (score >= 90) ? "A" :
               (score >= 80) ? "B" :
               (score >= 70) ? "C" : "F";
```

:::callout-warning[Ternary Readability]
Use ternary for simple two-way choices where the expression fits on one line. If either branch involves multiple statements or the condition is complex, use a regular `if-else` — readability matters more than brevity.
:::

## 8 · Floating-Point Comparison (§4.18)

As we saw in Chapter 2, floating-point numbers are stored as approximations. Comparing them with `==` is almost always a bug:

```cpp
double x = 0.1 + 0.2;
cout << (x == 0.3) << endl;       // 0 (false!) — 0.1+0.2 ≈ 0.30000000000000004

// The right approach: check within a small tolerance (epsilon):
double epsilon = 1e-9;
cout << (fabs(x - 0.3) < epsilon) << endl;   // 1 (true) ✓
```

Choose epsilon based on your problem's needs:

- For scientific/engineering: `1e-9` or `1e-12`
- For currency (2 decimal places): compare after rounding — `round(val * 100) / 100.0`
- For relative comparison of large numbers: use relative epsilon — `fabs(a - b) / fabs(a) < 1e-9`

## 9 · Short-Circuit Evaluation (§4.19)

:::callout-intuition[Intuition]
C++ is lazy with logical operators in the best possible way. With `&&`: if the left side is false, the whole expression is already false — no need to check the right side. With `||`: if the left side is true, the whole expression is already true — skip the right. This isn't just an optimization; it's a feature you can rely on.
:::

```cpp
// && short-circuits on false:
if (ptr != nullptr && ptr->value > 0) {  // safe: if ptr is null,
    ...                                   // ptr->value is never accessed
}

// || short-circuits on true:
if (isAdmin || checkPermission(user)) {   // if isAdmin is true,
    ...                                   // checkPermission() is never called
}                                         // (expensive call avoided)
```

:::callout-key[Practical Rule]
Put the *cheaper or safer* check on the left side. For `&&`: put the check most likely to be false first (short-circuits fastest). For `||`: put the check most likely to be true first. And always guard pointer/index checks before dereferencing.
:::

```cpp
// Safe pattern — check before dereference:
if (index >= 0 && index < arr.size() && arr[index] > 0) { ... }

// Would crash without short-circuit:
// if (arr[index] > 0 && index < arr.size())  ← backwards! might access out of bounds
```

## 10 · Full Worked Examples (§4.10, §4.20–§4.21)

:::example[Example 4.4 — §4.10 Toll Calculation]
A toll road charges: cars $2.00, trucks $5.00, motorcycles $1.00. Add $1.00 during rush hour (7–9am and 4–6pm). Compute the toll for a truck at 8am.

::::answer[Answer: $6.00]

::::

```cpp
#include <iostream>
using namespace std;

int main() {
    char vehicleType = 'T';  // 'C'=car, 'T'=truck, 'M'=motorcycle
    int  hour = 8;           // 24-hour format

    double baseToll;
    switch (vehicleType) {
        case 'C': baseToll = 2.00; break;
        case 'T': baseToll = 5.00; break;
        case 'M': baseToll = 1.00; break;
        default:  baseToll = 0.00;
            cerr << "Unknown vehicle type" << endl;
    }

    bool rushHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18);
    double totalToll = baseToll + (rushHour ? 1.00 : 0.00);

    cout << "Toll: $" << totalToll << endl;   // $6.00
    return 0;
}
```
:::

:::example[Example 4.5 — §4.20 Salary Calculation with Branches]
Employees are classified by type: 'S' (salaried, flat $52,000/year), 'H' (hourly, rate × 2080 hours/year, overtime at 1.5× over 40 hrs/week), 'P' (part-time, 20 hrs/week × rate × 52 weeks). Calculate annual pay for an hourly worker at $18/hr working 45-hr weeks.

::::answer[Answer: $37,440 regular + $1,350 OT × 52 weeks ... actually let's compute correctly]

::::

```cpp
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    char   empType  = 'H';
    double hourRate = 18.0;
    int    hoursPerWeek = 45;

    double annualPay = 0.0;

    if (empType == 'S') {
        annualPay = 52000.0;
    } else if (empType == 'H') {
        double regularWeekly  = 40 * hourRate;
        int    overtimeHours  = (hoursPerWeek > 40) ? hoursPerWeek - 40 : 0;
        double overtimeWeekly = overtimeHours * hourRate * 1.5;
        double weeklyPay      = regularWeekly + overtimeWeekly;
        annualPay = weeklyPay * 52;
    } else if (empType == 'P') {
        annualPay = 20 * hourRate * 52;
    } else {
        cerr << "Unknown employee type" << endl;
        return 1;
    }

    cout << fixed << setprecision(2);
    cout << "Annual pay: $" << annualPay << endl;
    // Regular: 40 * 18 = $720/wk
    // Overtime: 5 * 18 * 1.5 = $135/wk
    // Weekly: $855, Annual: $855 * 52 = $44,460
    return 0;
}
```
:::

:::example[Example 4.6 — §4.21 Search for Name Using Branches]
Read a full name (first and last) from the user. If the last name is "Smith", print "Found: Smith family." If the first name is "John", print "Hi, John!" Otherwise print "Not found."

::::answer[demonstrates string comparison in branches]

::::

```cpp
#include <iostream>
#include <string>
using namespace std;

int main() {
    string firstName, lastName;
    cout << "Enter first name: "; cin >> firstName;
    cout << "Enter last name: ";  cin >> lastName;

    if (lastName == "Smith") {
        cout << "Found: Smith family." << endl;
    } else if (firstName == "John") {
        cout << "Hi, John!" << endl;
    } else {
        cout << "Not found." << endl;
    }

    // Case-insensitive comparison (convert both to lowercase first):
    // Requires a loop over each character with tolower()
    // (or use std::transform from  — previewed here)
    return 0;
}
```
:::

:::summary
## Chapter 4 Summary

| Concept | Key Syntax / Rule |
| --- | --- |
| if-else-if chain | Only the first matching branch executes; order matters for ranges |
| Relational operators | `== != < > <= >=` — produce bool |
| Logical operators | `&&` (AND), `||` (OR), `!` (NOT) |
| = vs == | `if (x = 5)` is assignment (bug!); `if (x == 5)` is comparison |
| Math-style range | `0 < x < 10` is WRONG; write `x > 0 && x < 10` |
| Dangling else | else attaches to nearest if — always use braces to clarify |
| switch | Integer/char only; must `break` each case; `default` is the catch-all |
| bool | true/false; print with `boolalpha`; nonzero int → true |
| String compare | `== != < >` work lexicographically; uppercase < lowercase |
| cctype functions | `isalpha`, `isdigit`, `tolower`, `toupper`, etc. — include `<cctype>` |
| string::find | Returns index or `string::npos`; use `!= string::npos` to check |
| Ternary | `condition ? val_true : val_false` — inline two-way choice |
| Float comparison | Never `==`; use `fabs(a - b) < epsilon` |
| Short-circuit | `&&` skips right if left is false; `||` skips right if left is true |
:::

## Mixed Practice

:::problem[M.1easy]{difficulty="easy"}
What does this print when `x = 5`?

`string s = (x > 3) ? "big" : (x > 1) ? "medium" : "small";`

`cout << s;`

::::solution[Solution]
**"big"**. `x > 3` is true (5 > 3), so the first branch is taken immediately. The nested ternary is never evaluated.
::::
:::

:::problem[M.2easy]{difficulty="easy"}
Write the correct C++ condition to check if a `double` variable `result` equals 1.0 / 3.0 \* 3.0 (the mathematical answer is 1.0).

::::solution[Solution]
```cpp
double result = 1.0 / 3.0 * 3.0;
double epsilon = 1e-9;
if (fabs(result - 1.0) < epsilon) {
    cout << "Equal to 1.0" << endl;
}
```
::::
:::

:::problem[M.3standard]{difficulty="standard"}
Write a complete program that reads a character from the user and reports: whether it's a letter, digit, whitespace, or other; and if it's a letter, whether it's upper or lowercase.

::::solution[Solution]
```cpp
#include <iostream>
#include <cctype>
using namespace std;
int main() {
    char c;
    cout << "Enter a character: "; cin >> c;
    if (isalpha(c)) {
        cout << "Letter: " << (isupper(c) ? "uppercase" : "lowercase") << endl;
    } else if (isdigit(c)) {
        cout << "Digit" << endl;
    } else if (isspace(c)) {
        cout << "Whitespace" << endl;
    } else {
        cout << "Other character" << endl;
    }
    return 0;
}
```
::::
:::

:::problem[M.4standard]{difficulty="standard"}
Rewrite without using `!` operator: `if (!(age >= 18 && hasID))`

::::solution[Solution]
Apply De Morgan's: `!(A && B)` = `!A || !B`

`if (age < 18 || !hasID)`
::::
:::

:::problem[M.5standard]{difficulty="standard"}
Write a program that reads a string and prints whether it starts with a vowel (a, e, i, o, u — case-insensitive) or a consonant, or neither (non-letter).

::::solution[Solution]
```cpp
#include <iostream>
#include <cctype>
#include <string>
using namespace std;
int main() {
    string word;
    cin >> word;
    char first = tolower(word[0]);
    if (first == 'a' || first == 'e' || first == 'i' ||
        first == 'o' || first == 'u') {
        cout << "Starts with vowel" << endl;
    } else if (isalpha(first)) {
        cout << "Starts with consonant" << endl;
    } else {
        cout << "Starts with non-letter" << endl;
    }
    return 0;
}
```
::::
:::

:::problem[M.6challenge]{difficulty="challenge"}
A vending machine accepts quarters (25¢), dimes (10¢), nickels (5¢). Given a total cents amount (e.g., 85¢), use integer division and modulo to find the minimum number of coins needed, then print the count of each coin type.

::::solution[Solution]
```cpp
int cents = 85;
int quarters = cents / 25;  cents %= 25;  // 3 quarters, 10 left
int dimes    = cents / 10;  cents %= 10;  // 1 dime, 0 left
int nickels  = cents / 5;   cents %= 5;   // 0 nickels, 0 left

cout << "Quarters: " << quarters << endl;  // 3
cout << "Dimes: "    << dimes    << endl;  // 1
cout << "Nickels: "  << nickels  << endl;  // 0
```

85 = 3×25 + 1×10 + 0×5 = 75 + 10 = 85 ✓. This greedy approach works because US coins have the right denominations for it.
::::
:::

## LeetCode Practice

:::callout-tip[LeetCode Problems for Chapter 4]
These problems are all about conditional logic — choosing the right branch, checking multiple conditions, and applying modulo to classify numbers. Solve in C++.

| # | Problem | Difficulty | Why it fits |
| --- | --- | --- | --- |
| [#412](https://leetcode.com/problems/fizz-buzz/) | Fizz Buzz | Easy | Classic multi-condition branching with `%`. Practice ordering conditions correctly (FizzBuzz before Fizz/Buzz alone). Connects §4.7 (multiple features) and §2.11 (modulo). |
| [#66](https://leetcode.com/problems/plus-one/) | Plus One | Easy | Requires a branch for the carry case (digit == 9). Good practice for nested conditions and edge cases — the "all 9s" input is a classic conditional check. |
| [#67](https://leetcode.com/problems/add-binary/) | Add Binary | Easy | Character comparisons (`c == '1'`) and branching on carry — directly exercises §4.13 (string/character comparisons) and §4.1 (basic if-else). |
| [#1](https://leetcode.com/problems/two-sum/) | Two Sum | Easy | The brute-force solution is two nested conditions with equality checks. Try the O(n²) approach first using what you know so far — we'll revisit with hash maps in Ch 16. |

**Tip for #412:** Check FizzBuzz (divisible by both 3 and 5) *before* Fizz and Buzz separately — otherwise the first matching branch runs and you never print "FizzBuzz". This is a perfect illustration of §4.3's lesson about order in if-else-if chains.
:::
