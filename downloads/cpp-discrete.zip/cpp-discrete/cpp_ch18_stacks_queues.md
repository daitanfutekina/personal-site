---
title: "Chapter 18: Stacks & Queues"
crumb: "C++ · Chapter 18"
meta:
  - "Est. study time: ~2.5 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 18: Stacks & Queues

## Overview

Chapter 17 gave you linked lists and Chapter 16 gave you arrays. Both let you store a
sequence and reach any element in it. This chapter does something that sounds like a step
backwards: it takes structures that can do everything and deliberately restricts them.

A **stack** lets you touch only the most recently added item. A **queue** lets you touch only
the oldest. Neither offers indexing, searching, or insertion in the middle — operations both
underlying structures are perfectly capable of.

The restriction is the point. Constraining the interface buys two things. First, **every
operation becomes $O(1)$**: there is no searching because there is nowhere to search, and no
shifting because nothing moves except at one end. Second, and more importantly, the
restriction *matches the problem*. When you are undoing edits, you only ever want the most
recent one. When you are serving print jobs, you only ever want the oldest. A structure that
offers exactly what the problem needs cannot be misused, and the code that reads it does not
have to explain which element it wants or why.

This chapter builds both, twice each — once on a linked list and once on an array — because
the two implementations trade off differently and the trade is worth seeing. It then
generalises to the **deque**, which allows both ends, and to the **array list**, which is
what `std::vector` actually is underneath.

:::callout-key[What you'll learn]
- The stack ADT, and its linked and array implementations
- The queue ADT, and why the naive array version is broken
- Circular buffers, and the modular arithmetic that makes them work
- The deque, which generalises both
- Dynamic arrays, and why `push_back` is $O(1)$ *amortized* rather than $O(1)$
:::

:::callout-tip[Prerequisites]
Linked lists and pointer manipulation from Chapter 17; templates and classes from Chapter 13;
exceptions from Chapter 15, since every one of these structures throws on an empty or full
container. Big-O notation from Chapter 10.
:::

## §18.1 — Stack ADT

:::callout-intuition[The one you already use constantly]
You have been using a stack since your first program, without being told. Every time a
function calls another function, the return address and the local variables are pushed onto
the **call stack**; every time one returns, its frame is popped. That is why recursion works,
and why infinite recursion produces a *stack overflow* rather than some other error.

The reason a stack is right for that job is that function calls nest perfectly: the most
recently called function is always the first to finish. Anything with that shape wants a
stack. Nested brackets, undo history, backtracking in a maze, HTML tags, the browser back
button — each is a case of "the most recent unfinished thing is the one to deal with next".

The moment you notice that shape in a problem, reach for a stack. It is not an optimisation;
it is the structure the problem already has.
:::

A **stack** is a Last-In-First-Out (LIFO) data structure. You can only access the top element
— like a stack of plates.

```
Stack (LIFO):

push(A) → push(B) → push(C)

       ┌───┐  ← top
       │ C │  push/pop here only
       ├───┤
       │ B │
       ├───┤
       │ A │  ← bottom
       └───┘

pop() → C    (returns C, removes it)
peek() → B   (returns B, does not remove)
```

| Operation | Description | Complexity |
| --- | --- | --- |
| `push(item)` | Add item to top | O(1) |
| `pop()` | Remove and return top item | O(1) |
| `peek()` | Return top without removing | O(1) |
| `isEmpty()` | True if no items | O(1) |
| `size()` | Number of items | O(1) |

Every operation is $O(1)$, and it is worth being clear about *why* rather than just noting
it. All the work happens at one designated end, so nothing has to be searched for and nothing
has to shift to make room. That is what the restriction bought.

Note the distinction between `pop` and `peek`, which is the one beginners blur. `pop`
**removes** and returns; `peek` returns and **leaves the stack alone**. Calling `pop` when you
only wanted to look destroys data, and the bug is silent because you did get the value you
asked for — it is the next read that goes wrong.

:::callout-connect[Where stacks turn up]
Function call stack (return addresses), undo/redo in an editor, the browser back button,
expression evaluation, depth-first search, balanced-parenthesis checking, and syntax parsing
in compilers.

The common thread in all seven: *the most recently started thing is the first to finish.*
:::

## §18.2 — Stacks Using Linked Lists

The head of the linked list serves as the stack top. Push = prepend, pop = remove head. Both
$O(1)$.

**Why the head and not the tail?** Because prepending to a singly linked list is $O(1)$ — you
allocate a node and repoint one pointer — while appending requires walking to the end, which
is $O(n)$ unless you keep a tail pointer. And even with a tail pointer, *removing* from the
tail of a singly linked list is $O(n)$, because you need the node *before* the last one and
there are no backward links. So the head is the only end where both operations are cheap, and
that settles it.

```cpp
#include <stdexcept>
#include <iostream>
using namespace std;

template <typename T>
class LinkedStack {
    struct Node {
        T     data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    Node* top_;
    int   sz;

public:
    LinkedStack() : top_(nullptr), sz(0) {}

    ~LinkedStack() {
        while (top_) {
            Node* tmp = top_;
            top_ = top_->next;
            delete tmp;
        }
    }

    void push(const T& val) {
        Node* node = new Node(val);
        node->next = top_;    // new node points to old top
        top_ = node;           // top advances to new node
        sz++;
    }

    T pop() {
        if (isEmpty()) throw underflow_error("Stack underflow");
        T val   = top_->data;
        Node* tmp = top_;
        top_ = top_->next;
        delete tmp;
        sz--;
        return val;
    }

    const T& peek() const {
        if (isEmpty()) throw underflow_error("Stack underflow");
        return top_->data;
    }

    bool isEmpty() const { return top_ == nullptr; }
    int  size()    const { return sz; }
};
```

Three details repay attention.

**The order of the two lines in `push`.** `node->next = top_` comes *before* `top_ = node`. Do
it the other way round and `top_` already points at the new node, so `node->next` points at
itself — a one-element cycle, the old contents unreachable and leaked. It is a single line out
of order and the structure is destroyed.

**`pop` copies the value before deleting the node.** `T val = top_->data;` happens first,
because after `delete tmp` the memory is gone and reading `tmp->data` is undefined behaviour
— which usually still *appears* to work, since freed memory is rarely overwritten
immediately. That is the worst kind of bug: correct in testing, wrong in production.

**`peek` returns `const T&` while `pop` returns `T`.** `peek` leaves the element in place, so
a reference to it stays valid and the copy is avoidable. `pop` destroys the node, so it must
return by value — a reference would dangle immediately. The two different return types encode
that difference, and the `const` stops a caller from reaching in and modifying the stack's
interior.

Using it:

```cpp
int main() {
    LinkedStack<int> s;
    s.push(10); s.push(20); s.push(30);
    cout << s.peek() << "\n";   // 30
    s.pop();
    cout << s.peek() << "\n";   // 20
    cout << s.size() << "\n";   // 2
}
```

### Application: balanced bracket checker

Every compiler you have ever used runs some version of this on your source before anything
else. It is the smallest problem where a stack is not just convenient but genuinely the right
answer.

```cpp
bool isBalanced(const string& s) {
    LinkedStack<char> st;
    for (char c : s) {
        if (c=='(' || c=='[' || c=='{') st.push(c);
        else if (c==')' || c==']' || c=='}') {
            if (st.isEmpty()) return false;
            char top = st.pop();
            if ((c==')' && top!='(') || (c==']' && top!='[') ||
                (c=='}' && top!='{')) return false;
        }
    }
    return st.isEmpty();
}
// "{[()]}"  → true
// "{[(])}"  → false (wrong order)
```

**Why a stack and not a counter.** Counting openers and closers would accept `{[(])}`, since
it has three of each. What the counter cannot express is *order* — that the bracket you close
must be the one you most recently opened. A stack expresses exactly that, and matching
`"{[(])}"` fails on the `]` because the top of the stack is `(`.

There are three distinct ways to fail, and the function has to catch all of them:

- **A closer with nothing open** — `st.isEmpty()` inside the loop. The string `")("` fails
  here.
- **A closer that does not match the most recent opener** — the three-way comparison.
- **Openers still unclosed at the end** — the final `return st.isEmpty()`. The string `"(("`
  gets all the way through the loop without error and fails only on this line.

Miss any one and the checker accepts something it should reject. That last one is the easiest
to forget, because the loop finished without complaint.

:::callout-pitfall[Where this goes wrong]
- **Reordering the two pointer assignments in `push`** creates a self-cycle and leaks
  everything below.
- **Reading through a pointer after `delete`** often appears to work. Copy the value out
  first.
- **Forgetting the destructor** leaks every node — a linked structure does not clean itself
  up.
- **`pop` on an empty stack** must be checked. Dereferencing `top_` when it is `nullptr` is a
  crash at best.
- **Returning a reference from `pop`** dangles the moment the node is deleted.
:::

## §18.3 — Array-Based Stacks

Use an array with a `topIndex` variable. Push increments the index; pop decrements it. Better
cache performance than a linked list, but it needs a maximum size — or dynamic resizing.

**Why the cache matters here**, given that both versions are $O(1)$. Big-O counts operations
and treats every memory access as equal, and on real hardware they are not: a read from cache
costs a few cycles, a read from main memory costs hundreds. An array holds its elements
contiguously, so pushing and popping touch adjacent addresses that are almost always already
in cache. A linked list scatters its nodes across the heap, and each `next` is potentially a
cache miss — plus a call to `new` per element, which is itself far from free.

In practice the array version is several times faster despite identical Big-O. This is the
standard reason `std::stack` defaults to a `deque` rather than a `list`.

```cpp
template <typename T>
class ArrayStack {
    T*  data;
    int topIdx;   // index of top element (-1 when empty)
    int capacity;

    void resize() {
        int newCap = capacity * 2;
        T* newData = new T[newCap];
        for (int i = 0; i <= topIdx; i++) newData[i] = data[i];
        delete[] data;
        data = newData;
        capacity = newCap;
    }

public:
    ArrayStack(int cap = 16)
        : topIdx(-1), capacity(cap) {
        data = new T[cap];
    }
    ~ArrayStack() { delete[] data; }

    void push(const T& val) {
        if (topIdx + 1 == capacity) resize();
        data[++topIdx] = val;
    }

    T pop() {
        if (isEmpty()) throw underflow_error("Stack underflow");
        return data[topIdx--];
    }

    const T& peek() const {
        if (isEmpty()) throw underflow_error("Stack underflow");
        return data[topIdx];
    }

    bool isEmpty() const { return topIdx == -1; }
    int  size()    const { return topIdx + 1; }
};
```

**The $-1$ sentinel** is what makes the rest of the class simple. `topIdx` names the index of
the top element, so an empty stack has no valid index and $-1$ stands for "none". Every other
line then falls out: `size()` is `topIdx + 1`, `isEmpty()` is `topIdx == -1`, and `push` can
write with a pre-increment.

**`data[++topIdx]` versus `data[topIdx--]`** — the two are deliberately different and it is
worth reading them slowly. `push` uses *pre*-increment: advance first, then write to the new
slot. `pop` uses *post*-decrement: read the current slot, then retreat. Swap either one and
you are off by one, writing past the top or returning the element below it.

### Trace: push(1), push(2), push(3), pop(), peek()

| Operation | topIdx | data[0] | data[1] | data[2] | Returns |
| --- | --- | --- | --- | --- | --- |
| push(1) | 0 | 1 | — | — | — |
| push(2) | 1 | 1 | 2 | — | — |
| push(3) | 2 | 1 | 2 | 3 | — |
| pop() | 1 | 1 | 2 | 3\* | 3 |
| peek() | 1 | 1 | 2 | 3\* | 2 |

\* The 3 is still physically in memory at index 2, but it is logically gone — `topIdx`
controls the boundary, not the array contents.

That asterisk is the whole idea of the array implementation. Popping does not erase anything;
it moves a single integer. The next `push` overwrites the stale value, and until then nobody
can reach it because every accessor is bounded by `topIdx`. This is why `pop` is genuinely
$O(1)$ rather than $O(1)$-with-a-cleanup-step.

## §18.4 — Queue ADT

:::callout-intuition[The other half of the pair]
A stack serves the most recent arrival first. That is right for nested work, and badly wrong
for anything involving fairness.

Imagine a print spooler built on a stack: submit a job, and every job submitted after yours
jumps ahead of it. On a busy printer your document might never print at all. What that
situation wants is the opposite discipline — oldest first — and that is a **queue**.

The two structures are near-mirror images, differing only in which end you take from, and
that single choice determines everything about how they behave. It is worth carrying both:
when a problem is about *nesting*, use a stack; when it is about *waiting*, use a queue.
:::

A **queue** is a First-In-First-Out (FIFO) data structure. Items enter at the back (enqueue)
and leave from the front (dequeue) — like a line at the grocery store.

```
Queue (FIFO):

enqueue(A) → enqueue(B) → enqueue(C)

FRONT                                BACK
  ▼                                    ▼
┌───┬───┬───┐
│ A │ B │ C │   dequeue → A   (front leaves)
└───┴───┴───┘   enqueue(D) → A,B,C,D added at back
 dequeue                     enqueue
```

| Operation | Description | Complexity |
| --- | --- | --- |
| `enqueue(item)` | Add to back | O(1) |
| `dequeue()` | Remove and return front | O(1) |
| `front()` | Return front without removing | O(1) |
| `isEmpty()` | True if no items | O(1) |

The queue needs **two** points of access where the stack needed one, and that is the source of
every implementation difficulty in the next two sections. Keeping one end cheap is easy;
keeping both cheap simultaneously takes either an extra pointer or modular arithmetic.

:::callout-connect[Where queues turn up]
Breadth-first search, operating-system process scheduling, the keyboard input buffer, print
spoolers, web server request handling, and network packet routing.

The common thread: *fairness*. Every one of these would behave badly if recent arrivals
overtook older ones.
:::

## §18.5 — Queues Using Linked Lists

Maintain both a `head` (front) and a `tail` (back) pointer. Enqueue at the tail is $O(1)$,
dequeue at the head is $O(1)$.

**Why this assignment of ends and not the reverse.** In a singly linked list you can delete
cheaply only where you have a pointer to the node *before* the target — and at the head there
is nothing before, which is exactly what makes it cheap. At the tail there is no backward
link, so deleting there costs a full traversal. So removal must happen at the head, which
forces the head to be the front. Insertion at the tail is cheap because a tail pointer gets
you there directly. Reverse the roles and dequeue becomes $O(n)$.

```cpp
template <typename T>
class LinkedQueue {
    struct Node {
        T     data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    Node* head_;   // front — dequeue here
    Node* tail_;   // back  — enqueue here
    int   sz;

public:
    LinkedQueue() : head_(nullptr), tail_(nullptr), sz(0) {}

    ~LinkedQueue() {
        while (head_) {
            Node* tmp = head_;
            head_ = head_->next;
            delete tmp;
        }
    }

    void enqueue(const T& val) {
        Node* node = new Node(val);
        if (tail_) tail_->next = node;   // link old tail to new node
        else       head_ = node;          // queue was empty
        tail_ = node;
        sz++;
    }

    T dequeue() {
        if (isEmpty()) throw underflow_error("Queue is empty");
        T val = head_->data;
        Node* tmp = head_;
        head_ = head_->next;
        if (!head_) tail_ = nullptr;      // queue became empty
        delete tmp;
        sz--;
        return val;
    }

    const T& front() const {
        if (isEmpty()) throw underflow_error("Queue is empty");
        return head_->data;
    }

    bool isEmpty() const { return head_ == nullptr; }
    int  size()    const { return sz; }
};
```

**The two pointers must agree, and the edge cases are where they stop agreeing.** Both special
cases in this code exist for that reason, and both involve the transition to or from an empty
queue.

Enqueueing into an *empty* queue: `tail_` is null, so there is no old tail to link from, and
the new node must become the head as well. Miss the `else head_ = node;` and the queue holds
an element that `head_` cannot see — it will report itself empty forever while leaking every
node pushed into it.

Dequeueing the *last* element: `head_` becomes null, and `tail_` must be nulled too. Miss the
`if (!head_) tail_ = nullptr;` and `tail_` dangles at freed memory. The next `enqueue` then
takes the `if (tail_)` branch, writes through that dangling pointer, and corrupts the heap.
That bug does not show up on the operation that caused it; it shows up later, somewhere else,
which is what makes it expensive to find.

The general lesson for any structure with more than one pointer into it: **the dangerous cases
are the transitions at the boundaries**, going from empty to non-empty and back. Test those
first.

Using it:

```cpp
int main() {
    LinkedQueue<int> q;
    q.enqueue(10); q.enqueue(20); q.enqueue(30);
    cout << q.dequeue() << "\n";   // 10 — first in, first out
    cout << q.front()   << "\n";   // 20
}
```

### Application: BFS with a queue

Breadth-first search visits a tree level by level, and the queue is what produces that order —
change it to a stack and the same code becomes depth-first.

```cpp
struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

// Level-order traversal of a binary tree using a queue
void bfs(TreeNode* root) {
    if (!root) return;
    LinkedQueue<TreeNode*> q;
    q.enqueue(root);
    while (!q.isEmpty()) {
        TreeNode* node = q.dequeue();
        cout << node->val << " ";
        if (node->left)  q.enqueue(node->left);
        if (node->right) q.enqueue(node->right);
    }
}
```

**Why this comes out level by level.** When a node is visited, its children go to the *back* of
the queue — behind every node already waiting, all of which are at the current level or
earlier. So the whole of level $k$ is dequeued before any node of level $k+1$ can be reached.
The FIFO discipline enforces the ordering; nothing in the code tracks depth at all.

Replace `LinkedQueue` with a stack and the traversal becomes depth-first, because a child
pushed last is popped first and the search dives before it spreads. Same algorithm, one data
structure swapped, entirely different order — which is as clean an illustration as there is of
why the choice of container is a real decision.

## §18.6 — Array-Based Queues (Circular Buffer)

:::callout-intuition[The naive version leaks space]
Put a queue in an array the obvious way: `front` at index 0, `back` advancing rightward.
Enqueue three items, dequeue two, and the array holds one element — starting at index 2, with
indices 0 and 1 unusable because `front` has moved past them.

Keep going and the whole thing crawls rightward until `back` hits the end of the array while
most of the array sits empty. You could shift everything left on each dequeue, but that makes
dequeue $O(n)$ and defeats the purpose.

The fix is to stop thinking of the array as a line and start thinking of it as a **ring**. When
an index runs off the right-hand end, it wraps to zero and reuses the space the front left
behind. Nothing ever moves; only the two indices travel, endlessly around.
:::

A naive array queue wastes space as the front advances. A **circular buffer** wraps indices
around using modular arithmetic, allowing reuse of the freed space.

```
Circular buffer of capacity 5, after enqueue(A,B,C) and dequeue():

Index:   0   1   2   3   4
Data:  [ _   B   C   _   _ ]
                             front=1  back=3  size=2

After enqueue(D,E,F):
Index:   0   1   2   3   4
Data:  [ F   B   C   D   E ]
         ▲   ▲
      back=1 front=1        (back wrapped past the end to 0, then to 1)
```

Follow that second step carefully, because the wrap is the whole idea. Starting from
`front=1, back=3`, enqueueing D writes index 3 and moves `back` to 4; E writes index 4 and
moves `back` to $(4+1) \bmod 5 = 0$; F writes index 0 — the slot A vacated — and moves `back`
to 1.

The queue is now full, and notice what that looks like: **`front` and `back` are equal**. They
are also equal when the queue is empty. The indices alone cannot distinguish the two states,
which is precisely why the class carries a separate `sz` counter.

```cpp
template <typename T>
class CircularQueue {
    T*  data;
    int front_;    // index of front element
    int back_;     // index of next empty slot
    int sz;
    int capacity;

public:
    CircularQueue(int cap = 16)
        : front_(0), back_(0), sz(0), capacity(cap) {
        data = new T[cap];
    }
    ~CircularQueue() { delete[] data; }

    void enqueue(const T& val) {
        if (sz == capacity)
            throw overflow_error("Queue is full");
        data[back_] = val;
        back_ = (back_ + 1) % capacity;   // wrap around
        sz++;
    }

    T dequeue() {
        if (isEmpty()) throw underflow_error("Queue is empty");
        T val = data[front_];
        front_ = (front_ + 1) % capacity;  // wrap around
        sz--;
        return val;
    }

    const T& front() const {
        if (isEmpty()) throw underflow_error("Queue is empty");
        return data[front_];
    }

    bool isEmpty() const { return sz == 0; }
    bool isFull()  const { return sz == capacity; }
    int  size()    const { return sz; }
};
```

### Circular buffer trace

Capacity 5. The array column shows the physical contents; `_` marks a slot that is logically
free, whether or not stale data still sits there.

| Op | front\_ | back\_ | sz | Array |
| --- | --- | --- | --- | --- |
| enqueue(A) | 0 | 1 | 1 | [A,\_,\_,\_,\_] |
| enqueue(B) | 0 | 2 | 2 | [A,B,\_,\_,\_] |
| dequeue()→A | 1 | 2 | 1 | [\_,B,\_,\_,\_] |
| enqueue(C,D,E) | 1 | **0** | 4 | [\_,B,C,D,E] |
| dequeue()→B | 2 | 0 | 3 | [\_,\_,C,D,E] |

The fourth row is the one to study. C, D and E go into indices 2, 3 and 4 in turn, and after
writing E at index 4 the expression $(4+1) \bmod 5$ sends `back_` to **0** — not past the end
of the array, but round to the beginning, where slot 0 is free because A left it. No data
moved; one index wrapped.

:::callout-key[The formula, and the counter]
Every index movement in the class is

$$
\texttt{index} = (\texttt{index} + 1) \bmod \texttt{capacity}
$$

so when either index reaches `capacity` it becomes 0, and freed slots are reused without
shifting a single element.

**Why `sz` cannot be dropped.** It is tempting to compute the size as
`(back_ - front_ + capacity) % capacity` and save a member. That expression gives 0 when the
queue is empty — and also 0 when it is completely full, since `back_` has wrapped all the way
round to meet `front_`. The two states are indistinguishable from the indices alone.

The alternatives are to keep the counter, as here, or to deliberately waste one slot so that
full means `(back_ + 1) % capacity == front_`. Keeping the counter is clearer and costs four
bytes.
:::

:::callout-pitfall[Where this goes wrong]
- **Forgetting `% capacity`** on either index. It works until the first wrap, then writes off
  the end of the array.
- **Using index equality to test full or empty.** They are equal in both states; that is what
  `sz` is for.
- **Modular arithmetic on a negative number.** Going *backwards* — as the deque does — needs
  `(i - 1 + capacity) % capacity`, because C++'s `%` can return a negative result and a
  negative index is not caught by anything.
- **Assuming `dequeue` clears the slot.** It does not; stale data stays until overwritten. That
  is fine for `int`, and a genuine leak if `T` owns a resource.
:::

## §18.7 — Deque ADT (Double-Ended Queue)

A **deque** (pronounced "deck") supports insertion and deletion at *both* ends — it is a
generalization of both the stack and the queue. Use only the back and it is a stack; enqueue
at the back and dequeue at the front and it is a queue.

```cpp
// Deque operations:
// pushFront(item), pushBack(item)
// popFront(),      popBack()
// peekFront(),     peekBack()

template <typename T>
class ArrayDeque {
    T*  data;
    int front_;
    int sz, capacity;

    int back_() const { return (front_ + sz) % capacity; }

    void resize() {
        int newCap = capacity * 2;
        T* newData = new T[newCap];
        for (int i = 0; i < sz; i++)
            newData[i] = data[(front_ + i) % capacity];
        delete[] data;
        data = newData;
        front_ = 0;
        capacity = newCap;
    }

public:
    ArrayDeque(int cap = 8) : front_(0), sz(0), capacity(cap) {
        data = new T[cap];
    }
    ~ArrayDeque() { delete[] data; }

    void pushBack(const T& val) {
        if (sz == capacity) resize();
        data[back_() ] = val;
        sz++;
    }

    void pushFront(const T& val) {
        if (sz == capacity) resize();
        front_ = (front_ - 1 + capacity) % capacity;  // wrap backward
        data[front_] = val;
        sz++;
    }

    T popFront() {
        if (sz == 0) throw underflow_error("Deque empty");
        T val = data[front_];
        front_ = (front_ + 1) % capacity;
        sz--;
        return val;
    }

    T popBack() {
        if (sz == 0) throw underflow_error("Deque empty");
        int b = (back_() - 1 + capacity) % capacity;
        T val = data[b];
        sz--;
        return val;
    }

    const T& peekFront() const { return data[front_]; }
    const T& peekBack()  const { return data[(back_()+capacity-1)%capacity]; }

    bool isEmpty() const { return sz == 0; }
    int  size()    const { return sz; }
};
```

Two design choices here are worth naming.

**`back_()` is computed, not stored.** The class keeps `front_` and `sz`, and derives the back
as `(front_ + sz) % capacity`. That removes a whole class of bug — two stored indices can
disagree; a derived one cannot — at the cost of an addition and a modulo per call.

**`pushFront` moves backwards, and the `+ capacity` is essential.** Writing
`front_ = (front_ - 1) % capacity` looks equivalent and is not. In C++, `-1 % 5` is $-1$, not
$4$: the sign of a modulo result follows the *dividend*. Adding `capacity` first keeps the
value non-negative before the modulo, so the index wraps to 4 as intended rather than to $-1$,
which would write outside the array.

**`popBack` does not clear anything either** — it computes the back index, copies the value,
and decrements `sz`. Since the back is derived from `sz`, decrementing it *is* the removal.

Using it:

```cpp
int main() {
    ArrayDeque<int> dq;
    dq.pushBack(2);   dq.pushBack(3);
    dq.pushFront(1);  dq.pushBack(4);
    // Deque: [1, 2, 3, 4]
    cout << dq.popFront() << "\n";  // 1
    cout << dq.popBack()  << "\n";  // 4
    // Deque: [2, 3]
}
```

:::callout-connect[The deque in the standard library]
`std::deque` implements this ADT, and it is the default container underneath both
`std::stack` and `std::queue` — which is why those two are fast: a deque gives $O(1)$ at both
ends with array-like locality.

Deques also power the **monotonic deque** technique, which answers "what is the maximum in the
last $k$ elements?" in $O(1)$ per query by keeping indices in decreasing order of value. That
is Problem P4 below, and LeetCode 239.
:::

## §18.8 — Array-Based Lists (Dynamic Array)

An **array-based list** stores elements in a contiguous array that grows as needed. This is
exactly what `std::vector` implements, and understanding the internals explains why some
operations are $O(1)$ amortized and others are $O(n)$.

```cpp
template <typename T>
class ArrayList {
    T*  data;
    int sz;
    int capacity;

    void resize() {
        int newCap = (capacity == 0) ? 1 : capacity * 2;
        T* newData = new T[newCap];
        for (int i = 0; i < sz; i++) newData[i] = data[i];
        delete[] data;
        data = newData;
        capacity = newCap;
    }

public:
    ArrayList() : data(nullptr), sz(0), capacity(0) {}
    ~ArrayList() { delete[] data; }

    void push_back(const T& val) {
        if (sz == capacity) resize();   // amortized O(1)
        data[sz++] = val;
    }

    void insert(int idx, const T& val) {  // O(n)
        if (idx < 0 || idx > sz)
            throw out_of_range("Invalid index");
        if (sz == capacity) resize();
        for (int i = sz; i > idx; i--) data[i] = data[i-1];
        data[idx] = val;
        sz++;
    }

    void erase(int idx) {               // O(n)
        if (idx < 0 || idx >= sz)
            throw out_of_range("Invalid index");
        for (int i = idx; i < sz-1; i++) data[i] = data[i+1];
        sz--;
    }

    T& operator[](int i)       { return data[i]; }
    const T& operator[](int i) const { return data[i]; }
    int  size()     const { return sz; }
    bool empty()    const { return sz == 0; }
    int  cap()      const { return capacity; }
};
```

Note the bounds check in `insert` allows `idx == sz` while `erase` does not. Inserting *at* the
end is legitimate — it means appending. Erasing at index `sz` is not, because there is no
element there. One comparison differs between the two, and it is `>` against `>=`.

:::callout-key[Why `push_back` is amortized $O(1)$]
Most calls to `push_back` write one element and return — genuinely $O(1)$. Occasionally the
array is full and `resize()` copies all $n$ elements, which is $O(n)$. So a *single* call is
not $O(1)$, and the claim needs the word **amortized**: the average cost over a long run of
calls is constant.

Here is why doubling makes that true. Inserting $n$ elements from empty triggers resizes at
sizes $1, 2, 4, 8, \ldots$ up to $n$, and the copying done totals

$$
1 + 2 + 4 + \cdots + n < 2n,
$$

because a geometric series with ratio 2 sums to less than twice its last term. So $n$ pushes
cost under $2n$ copies in total — under 2 copies each on average, which is a constant.

**The growth factor has to be multiplicative.** Growing by a fixed *amount* — say ten slots at
a time — gives $n/10$ resizes copying an average of $n/2$ elements each, which is $O(n^2)$
overall and disastrous. The doubling is not an arbitrary choice; it is what converts the
total into a geometric series.

**One consequence that bites people:** a resize *moves the array*, so every pointer, reference
and iterator into it is invalidated. Holding `T* p = &v[0]` across a `push_back` is a dangling
pointer, and the code usually appears to work until the one push that happens to reallocate.
:::

:::callout-key[Why insertion and deletion in the middle are $O(n)$]
Inserting at index $i$ requires shifting every element from $i$ to $sz-1$ one position right —
up to $n$ moves. Erasing shifts the same elements left.

That is the trade against a linked list, and it runs in both directions:

| | array list | linked list |
| --- | --- | --- |
| access by index | $O(1)$ | $O(n)$ |
| insert or erase at a known position | $O(n)$ | $O(1)$ |
| memory per element | just the element | element plus a pointer |
| cache behaviour | excellent | poor |

For frequent insertions in the middle, a linked list wins on paper. For random access and for
sheer speed on modern hardware, the array wins — and it wins often enough that `std::vector`
is the right default and `std::list` is the exception you should be able to justify.
:::

Using it:

```cpp
int main() {
    ArrayList<int> v;
    for (int i=0; i<5; i++) v.push_back(i*10);  // 0,10,20,30,40
    v.insert(2, 15);   // 0,10,15,20,30,40
    v.erase(4);        // 0,10,15,20,40
    for (int i=0;i<v.size();i++) cout << v[i] << " ";
}
```

Trace the last two lines, since the indices shift underneath them. After the loop the list is
`0,10,20,30,40`. Inserting 15 at index 2 pushes everything from index 2 rightward, giving
`0,10,15,20,30,40` — six elements. Erasing index 4 removes the **30**, not the 40, because
after the insertion index 4 holds 30. The result is `0,10,15,20,40`.

That shifting is exactly the hazard of index-based editing: an index captured before an
insertion refers to a different element afterwards.

## Chapter summary

:::callout-key[Stack]
- LIFO: `push`, `pop`, `peek` — all $O(1)$
- Linked: head is the top, because prepending is the only cheap end
- Array: a `topIdx` sentinel of $-1$ for empty; popping moves an integer, not data
- Applications: call stack, undo, DFS, bracket matching, parsing
- The shape to look for: *the most recent unfinished thing is next*
:::

:::callout-tip[Queue, deque, and dynamic array]
- FIFO: enqueue at the back, dequeue at the front
- Linked: `head_` = front and `tail_` = back; the bugs live at the empty-queue transitions
- Array: a circular buffer, with `index = (index + 1) % capacity`
- Keep a separate `sz` — the indices are equal when both full and empty
- Going backwards needs `(i - 1 + capacity) % capacity`, or the modulo goes negative
- Deque: both ends, and the base of `std::stack` and `std::queue`
- `push_back` is $O(1)$ amortized *because* the growth is multiplicative
- Applications: BFS, scheduling, buffering, sliding windows
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Reverse a string with a stack.** Write `string reverse(const string& s)` using only a stack —
no indexing backwards, no `std::reverse`.

::::solution[Solution]
```cpp
string reverseWithStack(const string& s) {
    LinkedStack<char> st;
    for (char c : s) st.push(c);
    string out;
    while (!st.isEmpty()) out += st.pop();
    return out;
}
```

Push every character, then pop them all. Because the last character pushed is the first popped,
the output comes out reversed — the LIFO discipline *is* the reversal, and no arithmetic on
indices is needed.

This is the smallest example of a general pattern: **a stack reverses whatever passes through
it.** That is why an iterative depth-first search using an explicit stack visits children in
the opposite order to the recursive version, unless you deliberately push them backwards.
::::
:::

:::problem[P2 easy]{difficulty="easy"}
**Why does the naive array queue fail?** Suppose a queue is implemented with an array,
`front` starting at 0 and `back` advancing, with no wrap-around. Capacity is 5. Show a sequence
of operations after which the queue holds one element but refuses to accept another.

::::solution[Solution]
Enqueue five items, then dequeue four:

```
enqueue A,B,C,D,E   →  [A,B,C,D,E]   front=0  back=5
dequeue ×4          →  [_,_,_,_,E]   front=4  back=5
```

The queue now holds one element and four slots are free — but `back` is 5, which is the end of
the array, so the next `enqueue` has nowhere to write. It must either fail or shift everything
left, and shifting makes the operation $O(n)$.

**The waste grows without bound.** Every dequeue permanently abandons a slot, so a queue that
processes items steadily runs out of array no matter how large the array is. The circular
buffer of §18.6 fixes it by letting `back` wrap to index 0, where the free space already is.
::::
:::

:::problem[P3 standard]{difficulty="standard"}
**Queue from two stacks.** Implement a queue using two stacks and nothing else. Achieve
amortized $O(1)$ enqueue and dequeue, and explain the amortized analysis.

::::solution[Solution]
```cpp
class MyQueue {
    stack<int> inbox, outbox;
    void transfer() {
        while (!inbox.empty()) {
            outbox.push(inbox.top()); inbox.pop();
        }
    }
public:
    void enqueue(int val) { inbox.push(val); }
    int dequeue() {
        if (outbox.empty()) transfer();  // O(n) but amortized O(1)
        int v = outbox.top(); outbox.pop(); return v;
    }
    int front() {
        if (outbox.empty()) transfer();
        return outbox.top();
    }
    bool empty() { return inbox.empty() && outbox.empty(); }
};
```

**The idea.** A stack reverses what passes through it, as P1 showed. Pouring `inbox` into
`outbox` therefore reverses the order, turning LIFO into FIFO — the oldest element, buried at
the bottom of `inbox`, ends up on top of `outbox`.

**The amortized analysis.** A single `dequeue` that triggers `transfer` is $O(n)$, so this is
not $O(1)$ per operation. But follow one element through its whole life: it is pushed to
`inbox` once, moved to `outbox` once, and popped from `outbox` once. Three operations, ever.
So $n$ elements cost $3n$ operations in total, which is $O(1)$ each on average.

**The condition that makes it work** is `if (outbox.empty())`. Transferring only when `outbox`
has run dry is what guarantees each element moves once. Transferring on every dequeue would
shuttle elements back and forth and give genuine $O(n)$ per operation.
::::
:::

:::problem[P4 standard]{difficulty="standard"}
**Monotonic deque — sliding window maximum.** Given `nums` and window size `k`, return the
maximum of each window of size $k$. Use a deque of indices in $O(n)$ total.

::::solution[Solution]
```cpp
vector<int> maxSlidingWindow(vector<int>& nums, int k) {
    deque<int> dq;   // stores indices
    vector<int> result;
    for (int i = 0; i < (int)nums.size(); i++) {
        // Remove indices outside window
        while (!dq.empty() && dq.front() < i-k+1) dq.pop_front();
        // Remove indices with smaller values (they can never be max)
        while (!dq.empty() && nums[dq.back()] < nums[i]) dq.pop_back();
        dq.push_back(i);
        // Deque front is always the max in current window
        if (i >= k-1) result.push_back(nums[dq.front()]);
    }
    return result;
}
// nums=[1,3,-1,-3,5,3,6,7], k=3 → [3,3,5,5,6,7]
```

**Why both ends are needed**, and hence why this must be a deque rather than a stack or queue.
The front is where indices *expire* as the window slides past them. The back is where smaller
values are *discarded* when a larger one arrives. Neither a stack nor a queue offers both.

**The key insight is the second loop.** If `nums[i]` is larger than the value at the back of the
deque, that older value can never be the maximum of any future window — every window containing
it from now on also contains `nums[i]`, which is bigger *and* stays in the window longer. So it
is safe to throw away permanently. That invariant keeps the deque in decreasing order, which
makes the front the maximum by construction.

**Why $O(n)$ despite the nested loops.** Each index is pushed exactly once and popped at most
once, so the total work across all iterations is bounded by $2n$ — the same amortized argument
as P3. The inner `while` loops can be long on a single iteration, but not often.

Running it on the stated input gives `3 3 5 5 6 7`, matching the comment.
::::
:::

:::problem[P5 challenge]{difficulty="challenge"}
**Min-stack.** Design a stack that also reports its minimum element in $O(1)$, alongside
$O(1)$ `push`, `pop` and `peek`. Extra space of $O(n)$ is allowed.

::::solution[Solution]
```cpp
class MinStack {
    LinkedStack<int> main_, mins_;
public:
    void push(int v) {
        main_.push(v);
        if (mins_.isEmpty() || v <= mins_.peek()) mins_.push(v);
    }
    int pop() {
        int v = main_.pop();
        if (v == mins_.peek()) mins_.pop();
        return v;
    }
    int peek() const { return main_.peek(); }
    int getMin() const { return mins_.peek(); }
    bool isEmpty() const { return main_.isEmpty(); }
};
```

**The idea.** Keep a second stack whose top is always the minimum of everything currently in
the first. A new value joins it only when it is a new minimum, and leaves when that value is
popped — so the two stacks stay synchronised without scanning anything.

**The `<=` is not a typo, and using `<` is the classic bug.** Push 3, push 3, then pop once.
With `<=`, both 3s were recorded in `mins_`, the pop removes one, and `getMin()` still
correctly reports 3. With `<`, the second 3 was never recorded — so the single pop removes the
*only* recorded 3, `mins_` is left empty, and the next `getMin()` throws `Stack underflow` on a
stack that still holds an element. Duplicated minima must each be recorded.

**Why $O(1)$ is achievable at all.** Recomputing the minimum on demand would be $O(n)$; the
trick is that the minimum only ever changes at a push or a pop, so it can be maintained
incrementally. Trading $O(n)$ extra space for $O(1)$ query time is the standard shape of this
kind of problem.
::::
:::

:::problem[P6 challenge]{difficulty="challenge"}
**Evaluate a postfix expression.** Write `int evalPostfix(const string& expr)` that evaluates a
space-separated postfix (reverse Polish) expression, such as `"3 4 + 2 *"` $= 14$. Support
`+`, `-`, `*`, `/`, and throw on malformed input or division by zero.

::::solution[Solution]
```cpp
int evalPostfix(const string& expr) {
    LinkedStack<int> st;
    istringstream in(expr);
    string tok;
    while (in >> tok) {
        if (tok=="+"||tok=="-"||tok=="*"||tok=="/") {
            if (st.size() < 2)
                throw invalid_argument("Operator '" + tok + "' needs two operands");
            int b = st.pop();          // second operand pops FIRST
            int a = st.pop();
            if (tok=="/" && b == 0)
                throw domain_error("Division by zero");
            st.push(tok=="+" ? a+b : tok=="-" ? a-b : tok=="*" ? a*b : a/b);
        } else {
            st.push(stoi(tok));        // throws invalid_argument on junk
        }
    }
    if (st.size() != 1) throw invalid_argument("Malformed expression");
    return st.pop();
}
```

**The order of the two pops is the thing to get right.** The stack returns the most recent
operand first, so the *second* operand of the expression comes off first. Writing
`int a = st.pop(); int b = st.pop();` reverses every subtraction and division: `"5 3 -"` gives
$-2$ instead of the correct $2$. Addition and multiplication still come out right, which is
what lets this bug survive casual testing.

**Why postfix needs no parentheses and no precedence rules.** The order of the tokens already
encodes the grouping, so the evaluator is a single pass with a stack and no lookahead. That is
why compilers convert infix to postfix before generating code, and why some calculators asked
you to enter expressions this way.

**The two validity checks are different failures.** Fewer than two operands when an operator
arrives means the expression is malformed mid-stream. More than one value left at the end
means there were too many operands — `"1 2 3 +"` leaves 1 and 5 on the stack. Checking only
one of the two lets the other class of bad input through silently.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 155 | [Min Stack](https://leetcode.com/problems/min-stack/) | Medium | Augment a stack to track its minimum in $O(1)$ — this is P5 |
| 232 | [Implement Queue Using Stacks](https://leetcode.com/problems/implement-queue-using-stacks/) | Easy | The two-stack queue of P3, amortized $O(1)$ |
| 225 | [Implement Stack Using Queues](https://leetcode.com/problems/implement-stack-using-queues/) | Easy | The reverse direction — rotate a queue to fake LIFO |
| 239 | [Sliding Window Maximum](https://leetcode.com/problems/sliding-window-maximum/) | Medium | The monotonic deque of P4, $O(n)$ overall |
| 150 | [Evaluate RPN](https://leetcode.com/problems/evaluate-reverse-polish-notation/) | Medium | Postfix evaluation, as in P6 |
| 20 | [Valid Parentheses](https://leetcode.com/problems/valid-parentheses/) | Easy | The bracket checker of §18.2, all three failure modes |
:::
