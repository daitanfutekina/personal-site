---
title: "Chapter 19: Additional Material"
crumb: "C++ · Chapter 19"
meta:
  - "Est. study time: ~2.5 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 19: Additional Material

## Overview

This chapter is the supplement — the topics that did not need a chapter of their own but that
you will reach for constantly, plus a second pass over arrays from an angle the first pass did
not cover.

It divides into three kinds of material, and it is worth knowing which you are reading.

**Things the earlier chapters skipped.** The `do-while` loop, `#define`, command-line
arguments, and how to actually invoke the compiler. Small topics, each complete in a section.

**Arrays revisited as patterns.** Chapter 16 taught the syntax; this chapter collects the five
or six loop shapes that appear in nearly every array problem, together with the classic bugs
that hide inside them.

**The build system.** Modular compilation and Makefiles — how a program made of many files
becomes one executable, and why that matters as soon as a project outgrows a single `.cpp`.

Use it as a reference. Nothing here depends on anything else here, so the sections can be read
in any order.

:::callout-key[What you'll learn]
- `do-while`, and the one situation it is genuinely right for
- The standard array traversal patterns, and the off-by-one bugs in each
- Why arrays decay to pointers, and what that breaks
- `struct` for grouping data, and why it beats parallel arrays
- `argc` and `argv`, and turning them into numbers safely
- Why `#define` is a hazard, demonstrated by a block that will not compile
- Separate compilation, linking, and Makefiles
:::

:::callout-tip[Prerequisites]
Arrays from Chapter 16, functions from Chapter 7, pointers from Chapter 8. Section 19.7 uses
`vector` and Chapter 15's exceptions.
:::

## §19.1 — Do-While Loops

:::callout-intuition[Test at the bottom, not the top]
A `while` loop checks its condition *before* the first iteration, which is right almost always
— you do not want to process an empty list, or divide before checking the divisor.

But there is one shape where checking first is impossible: **you cannot test the input until
you have read it.** Asking "is the number the user typed positive?" requires the user to have
typed a number, so the read must happen at least once regardless of the answer.

`do-while` moves the test to the bottom, so the body runs first and the condition decides only
whether to repeat. That is precisely the input-validation shape, and it is nearly the only
place `do-while` is the clearest option.
:::

A `do-while` loop executes the body *at least once*, then checks the condition. This is
perfect for input validation, where you need to try before you can test.

```cpp
void illustrate() {
// Standard while — might never execute
int x = 10;
while (x < 5) {
    cout << "never runs\n";
}

// do-while — always executes at least once
int n;
do {
    cout << "Enter a positive number: ";
    cin >> n;
} while (n <= 0);   // loop until valid input

// Equivalent while version (requires duplicate code or flag)
cout << "Enter a positive number: ";
cin >> n;
while (n <= 0) {
    cout << "Enter a positive number: ";
    cin >> n;
}
}
```

Compare the last two forms carefully, because the comparison is the whole argument for the
construct. The `while` version needs the prompt-and-read written **twice** — once before the
loop to get an initial value, and once inside to try again. Two copies of the same two lines,
which must be kept in step: change the prompt in one place and forget the other, and the
program asks two different questions for the same input.

The `do-while` version writes it once. That is a small saving in four lines and a real one in
a validation routine that does several things before testing.

**Note the semicolon.** `} while (n <= 0);` ends with one; a normal `while` loop's header does
not. Omitting it is a syntax error, and — more confusingly — *adding* a semicolon to an
ordinary `while` header, `while (n <= 0);`, compiles fine and produces an infinite loop with
an empty body.

:::callout-key[When to reach for it]
Use `do-while` when either:

1. the body must run before you can know whether to repeat — almost always because the body
   *produces* the value being tested; or
2. writing it as a `while` would duplicate the first attempt.

For everything else, `while` or `for` is clearer, because a reader can see the loop's
condition without scanning to the bottom first. `do-while` is genuinely rare in good C++, and
that rarity is itself a signal: when you see one, the "runs at least once" property is
probably load-bearing.
:::

:::problem[Practice 19.1 easy]{difficulty="easy"}
**Menu loop.** Write a `do-while` menu loop that prints options 1–4 and an Exit (0) choice,
reads the selection, and repeats until 0 is entered.

::::solution[Solution]
```cpp
void menu() {
    int choice;
    do {
    cout << "1) Add  2) Remove  3) List  4) Search  0) Exit\n";
    cout << "Choice: ";
    cin >> choice;
    switch (choice) {
        case 1: cout << "Adding...\n"; break;
        case 2: cout << "Removing...\n"; break;
        case 3: cout << "Listing...\n"; break;
        case 4: cout << "Searching...\n"; break;
        case 0: cout << "Goodbye!\n"; break;
        default: cout << "Invalid option\n";
    }
    } while (choice != 0);
}
```

**Why a menu is the archetypal `do-while`.** The menu must be shown before any choice exists to
test, and it must be shown again after every choice except the quit. A `while` loop would have
to print the menu once above the loop and again inside it.

**Two details in the `switch`.** Every case ends with `break`, because C++ cases fall through
to the next one otherwise — omit the `break` after case 1 and choosing "Add" also runs
"Remove". And `default` catches every value not listed, so typing 7 gets a message rather than
silence.

**One thing this does not handle:** if the user types a letter, `cin >> choice` fails, leaves
`choice` unchanged, and leaves the bad input in the stream — so the loop spins forever printing
the menu. Making it robust needs a `cin.fail()` check with `cin.clear()` and `cin.ignore()`,
which is the input-validation pattern from Chapter 4.
::::
:::

## §19.2–§19.5 — Arrays Review and Common Patterns

Arrays are fixed-size, contiguous blocks of memory. All elements have the same type, and they
are indexed from 0 to `size - 1`.

```cpp
// Declaration and initialization
int scores[5] = {92, 87, 78, 95, 83};
double temps[7] = {};   // all initialized to 0.0
int counts[100];        // uninitialized — garbage values!
```

Those three lines behave very differently and the difference matters.

The first initialises every element explicitly. The second uses an empty brace list, which
**zero-initialises all seven** — a genuinely useful idiom, and the standard way to get a zeroed
array. The third declares 100 ints and initialises none of them: reading `counts[0]` before
writing it gives whatever was in that memory, which is not necessarily zero and is not
necessarily the same on the next run. Debugging a program that works in one build and fails in
another very often ends here.

The rule: **local arrays are not zeroed unless you ask.** Write `int counts[100] = {};` and the
problem disappears.

```cpp
int scores[5] = {92, 87, 78, 95, 83};

// Common iteration patterns
int n = 5;
// Pattern 1: process all elements
for (int i = 0; i < n; i++) cout << scores[i] << " ";

// Pattern 2: find sum and average
int sum = 0;
for (int i = 0; i < n; i++) sum += scores[i];
double avg = (double)sum / n;

// Pattern 3: find min/max
int minVal = scores[0], maxVal = scores[0];
for (int i = 1; i < n; i++) {
    if (scores[i] < minVal) minVal = scores[i];
    if (scores[i] > maxVal) maxVal = scores[i];
}

// Pattern 4: loop to copy array
int copy[5];
for (int i = 0; i < n; i++) copy[i] = scores[i];

// Pattern 5: reverse an array
for (int i = 0, j = n-1; i < j; i++, j--) swap(scores[i], scores[j]);
```

Each of these has a detail worth naming, and together they are most of what array code ever
does.

**Pattern 2 — the cast is not optional.** `sum / n` with both operands `int` performs *integer*
division and throws away the fraction: scores summing to 435 over 5 elements give 87, but 434
over 5 give 86 rather than 86.8. The `(double)` on `sum` promotes the whole expression to
floating point. Casting the *result* — `(double)(sum / n)` — is too late; the truncation has
already happened.

**Pattern 3 — the loop starts at `i = 1`, and the seeds are `scores[0]`.** Seeding with 0
instead would be a real bug on all-negative data, where the maximum would be wrongly reported
as 0. Seeding from the first element is always safe and never needs a special case — provided
the array is non-empty, which is the one precondition this pattern has.

**Pattern 5 — the loop condition is `i < j`, not `i <= j` or `i < n`.** Two indices walk toward
each other and stop when they meet. Using `i <= j` swaps the middle element with itself on an
odd-length array, which is harmless but pointless; using `i < n` is the bug in the callout
below.

### §19.4 — Parallel Arrays

```cpp
// Parallel arrays: two arrays where index i connects related data
string names[4]  = {"Alice", "Bob", "Carol", "Dave"};
int    grades[4] = {92, 87, 78, 95};

// Find the highest scorer
int topIdx = 0;
for (int i = 1; i < 4; i++)
    if (grades[i] > grades[topIdx]) topIdx = i;
cout << "Top scorer: " << names[topIdx] << " with " << grades[topIdx] << "\n";
// Prefer struct over parallel arrays — harder to keep in sync, error-prone
```

**The technique and its weakness in one example.** Note what the loop tracks: the *index*, not
the maximum grade. That is what lets the answer be looked up in the other array afterwards — a
loop that tracked only `maxGrade` would find the number and lose the name.

The weakness is that nothing in the language ties the two arrays together. Sort `grades` and
`names` stays in the old order, silently pairing every student with someone else's mark. Add a
student to one and forget the other, and every index past that point is wrong. The compiler
cannot help, because as far as it is concerned these are two unrelated arrays.

§19.11 shows the fix: put the fields in a `struct` so that one student is one object and there
is nothing left to keep in step.

:::callout-pitfall[§19.6 — the classic array reversal bug]
```cpp
void reverseWrong(int arr[], int n) {
// WRONG: reversal loop runs too far
for (int i = 0; i < n; i++)    // should be i < n/2
    swap(arr[i], arr[n-1-i]);  // double-reverses when i > n/2

}
void reverseRight(int arr[], int n) {
// CORRECT:
for (int i = 0; i < n/2; i++)
    swap(arr[i], arr[n-1-i]);
}
```

Trace the wrong version on `[1,2,3,4]` to see why it fails so completely. At $i=0$ it swaps
positions 0 and 3, giving `[4,2,3,1]`. At $i=1$ it swaps 1 and 2, giving `[4,3,2,1]` — correct
so far, and the array is now fully reversed. But the loop keeps going: at $i=2$ it swaps
positions 2 and 1, undoing the previous step, and at $i=3$ it undoes the first. The final
array is `[1,2,3,4]` — exactly what it started as.

**The reversal is complete halfway through**, because each swap handles *two* elements. Running
the full length performs every swap twice, and a swap done twice is a swap not done at all.

Note this bug is invisible on an array of length 1, and on length 0 or 2 it produces the right
answer for the wrong reason. Test reversal on length 4 or more.
:::

## §19.7 — Engineering Examples with Arrays

Three examples where an array is the natural representation of a physical quantity. Each is a
loop pattern from §19.2 with domain meaning attached.

```cpp
// Example 1: Moving average (signal smoothing)
vector<double> movingAvg(const vector<double>& signal, int k) {
    vector<double> result;
    double windowSum = 0;
    for (int i = 0; i < (int)signal.size(); i++) {
        windowSum += signal[i];
        if (i >= k) windowSum -= signal[i - k];
        if (i >= k - 1) result.push_back(windowSum / k);
    }
    return result;
}

// Example 2: Resistors in series and parallel
double seriesResistance(const vector<double>& r) {
    double total = 0;
    for (double ri : r) total += ri;
    return total;
}

double parallelResistance(const vector<double>& r) {
    double sum = 0;
    for (double ri : r) {
        if (ri == 0) throw invalid_argument("Zero resistance in parallel");
        sum += 1.0 / ri;
    }
    return 1.0 / sum;
}

// Example 3: Simpson's rule numerical integration
// ∫f(x)dx ≈ h/3 * [f(a) + 4f(a+h) + 2f(a+2h) + ... + f(b)]
double simpsons(double (*f)(double), double a, double b, int n) {
    if (n % 2 != 0) n++;   // n must be even
    double h = (b - a) / n;
    double sum = f(a) + f(b);
    for (int i = 1; i < n; i++)
        sum += (i % 2 == 0 ? 2 : 4) * f(a + i * h);
    return h / 3.0 * sum;
}
```

**The moving average is $O(n)$, not $O(nk)$, and the two `if`s are why.** The naive version
re-adds all $k$ elements of every window. This one keeps a running total: each new element is
added, and the element that has just fallen out of the window — the one $k$ positions back — is
subtracted. One addition and one subtraction per step, whatever the window size.

The two conditions guard the start-up. `if (i >= k)` only subtracts once a full window has gone
by, since before that nothing has fallen out. `if (i >= k - 1)` only records a result once the
window is genuinely full, so no partial average is reported. On `[1,2,3,4,5,6]` with $k=3$ the
output is `[2,3,4,5]` — four windows from six elements, which is $n - k + 1$.

**The parallel-resistance formula is the reciprocal of a sum of reciprocals**,
$1/R = \sum 1/R_i$, which is why two 100 Ω resistors in parallel give 50 Ω, and why
$\{60, 30, 20\}$ gives exactly 10: the reciprocals are $\frac{1}{60}+\frac{2}{60}+\frac{3}{60}
= \frac{6}{60}$. The zero check is not defensive padding — a zero-ohm resistor is a short
circuit, the reciprocal is infinite, and without the check the function silently returns 0.

**Simpson's rule alternates its weights**, and the ternary `(i % 2 == 0 ? 2 : 4)` is what does
it: interior points at odd positions get weight 4, even positions get 2, and the two endpoints
get 1. That pattern comes from fitting a parabola through each consecutive triple of points,
which is also why $n$ must be even — an odd $n$ would leave a triple unfinished, and the
`if (n % 2 != 0) n++;` quietly repairs it.

Being exact for parabolas means Simpson's rule is exact for *cubics* too, as a symmetry
argument shows. So integrating $x^2$ over $[0,1]$ with $n=10$ returns $0.3333333333$ — the exact
$1/3$ to every digit shown. Integrating $\sin x$ over $[0,\pi]$ with $n=100$ gives
$2.0000000108$ against the true value of 2: not exact, because $\sin$ is not a cubic, but
accurate to eight digits from a hundred function evaluations.

## §19.8–§19.10 — Functions with Array Parameters

:::callout-intuition[The array that stops being an array]
Pass an array to a function and something surprising happens: the array is not copied, and
inside the function it is no longer an array. It has **decayed** to a pointer to its first
element.

That is why every array parameter needs a companion size parameter. The function has an
address and nothing else — no length, no bounds, no way to ask. All the information about how
many elements there are stayed in the caller.

This is a C inheritance, and it is the single largest reason `std::vector` exists. A vector
carries its size with it, so it cannot be separated from its own length.
:::

```cpp
// Arrays decay to pointers when passed to functions
// MUST pass size separately — no sizeof(arr) magic inside the function!

double average(const int arr[], int n) {     // arr[] same as int* arr
    double sum = 0;
    for (int i = 0; i < n; i++) sum += arr[i];
    return sum / n;
}

void scaleArray(double arr[], int n, double factor) {
    for (int i = 0; i < n; i++) arr[i] *= factor;   // modifies in place
}

int findMax(const int arr[], int n) {
    int m = arr[0];
    for (int i = 1; i < n; i++) if (arr[i] > m) m = arr[i];
    return m;
}

// COMMON ERROR: sizeof(arr) / sizeof(arr[0]) ONLY works in same scope
void wrong(int arr[]) {
    int size = sizeof(arr) / sizeof(arr[0]);  // BUG: arr is pointer (8 bytes)
}

int main() {
    int scores[] = {92, 87, 78, 95, 83};
    int n = sizeof(scores) / sizeof(scores[0]);  // OK here
    cout << average(scores, n) << "\n";
    cout << findMax(scores, n) << "\n";
}
```

**The `sizeof` trick works in `main` and fails in `wrong`, and the reason is decay.** In `main`,
`scores` really is an array of 5 ints, so `sizeof(scores)` is 20 bytes and dividing by
`sizeof(scores[0])` gives 5. In `wrong`, the parameter is a pointer despite the `[]` notation,
so `sizeof(arr)` is the size of a pointer — 8 bytes on a 64-bit machine — and the division
gives 2 regardless of how many elements were passed.

Worse, that 2 is a plausible-looking number. The function will happily process two elements of
a thousand-element array and report no error at all.

**`const` on the parameter is doing real work.** `average` and `findMax` take `const int arr[]`,
which promises not to modify the caller's data and is enforced by the compiler. `scaleArray`
omits it precisely because modifying in place is its job. Since the array is not copied, that
distinction is the only signal a caller has about whether their data is safe.

:::callout-key[Prefer `vector<T>` for parameters]
A `vector` carries its own size, works with range-`for`, checks bounds when you ask it to with
`.at()`, and does not decay. The three functions above become:

```cpp
double average(const vector<int>& v) {
    double sum = 0;
    for (int x : v) sum += x;
    return v.empty() ? 0 : sum / v.size();
}
```

— no size parameter to pass, no size parameter to get wrong, and an empty-check that is now
possible because the function can actually tell.

Note the `&`. Without it the entire vector is copied on every call, which for a large one is
far more expensive than the raw array it replaced. `const vector<T>&` is the idiomatic
read-only parameter: no copy, no modification.

Raw arrays remain common in embedded and legacy code, so know them. Write new code with
vectors.
:::

## §19.11–§19.14 — Grouping Data with `struct`

A **struct** groups related data under one name. Unlike a class, struct members are `public` by
default.

```cpp
struct Date {
    int month, day, year;
};

struct Student {
    string name;
    int    id;
    double gpa;
    Date   enrolled;
};

// Struct functions
void printStudent(const Student& s) {
    cout << s.name << " (ID:" << s.id << ", GPA:" << s.gpa << ")\n";
}

double averageGPA(const vector<Student>& students) {
    double sum = 0;
    for (const auto& s : students) sum += s.gpa;
    return students.empty() ? 0 : sum / students.size();
}

// §19.14 — Seat Reservation Example
struct Seat { string section; int row, col; bool reserved; };

bool reserveSeat(vector<Seat>& seats, const string& sec, int row, int col) {
    for (auto& s : seats) {
        if (s.section==sec && s.row==row && s.col==col) {
            if (s.reserved) return false;
            s.reserved = true; return true;
        }
    }
    return false;  // seat not found
}
```

Creating and using them:

```cpp
int main() {
    Student s1 = {"Alice", 12345, 3.9, {8, 25, 2023}};
    Student s2;
    s2.name = "Bob";
    s2.id   = 67890;
    s2.gpa  = 3.4;
    s2.enrolled = {1, 15, 2024};

    cout << s1.name << " enrolled " << s1.enrolled.month
         << "/" << s1.enrolled.day << "/" << s1.enrolled.year << "\n";
}
```

**Structs nest, and `Student` contains a `Date`.** The brace initialiser nests to match:
`{"Alice", 12345, 3.9, {8, 25, 2023}}` fills the three scalar fields and then the inner braces
fill the `Date`. Access nests the same way — `s1.enrolled.month` reads a field of a field.

**This is the answer to §19.4's parallel arrays.** One `Student` holds a name and a grade
together, so sorting a `vector<Student>` moves each name with its own mark and there is nothing
left to keep in step. The compiler now enforces what the programmer previously had to remember.

**`reserveSeat` returns `false` for two different reasons**, which is the weakness of a `bool`
return: the seat was already reserved, or the seat does not exist. A caller cannot tell them
apart, and they deserve different messages. An `enum class` result — `Ok`, `AlreadyTaken`,
`NoSuchSeat` — or an exception would carry the distinction; this is the return-code problem
from Chapter 15 in miniature.

**Note `auto& s` in the loop and not `auto s`.** The reference is essential: without it the loop
copies each seat, sets `reserved` on the *copy*, and the vector is unchanged. The function
would report success and reserve nothing. In `averageGPA` above, `const auto&` is used instead
— a reference to avoid copying each `Student`, and `const` because it only reads.

:::callout-connect[`struct` versus `class`]
Structurally identical in C++. The only difference is default access: `public` for `struct`,
`private` for `class`. Anything you can do with one you can do with the other, including
constructors, methods and inheritance.

The convention is about intent. Use `struct` for a plain aggregate of data with no invariant
to protect — a `Point`, a `Date`, a `Seat`. Use `class` when the object has an invariant that
must be maintained and the data therefore needs to be private, as `LinkedStack` in Chapter 18
does.
:::

## §19.15–§19.16 — Command-Line Arguments

`main()` can receive arguments from the shell through `argc` (argument count) and `argv`
(argument vector — an array of C-strings).

```cpp
// argc: number of arguments including the program name
// argv[0]: program name,  argv[1..argc-1]: actual arguments

int main(int argc, char* argv[]) {
    cout << "Program: " << argv[0] << "\n";
    cout << "Arguments: " << argc - 1 << "\n";

    for (int i = 1; i < argc; i++)
        cout << "  argv[" << i << "] = " << argv[i] << "\n";
}
```

**`argc` is never 0, and `argv[0]` is the program's own name.** That is why the loop starts at
`i = 1` and why the count of real arguments is `argc - 1`. Running `./prog a b` gives
`argc == 3`. Forgetting the off-by-one here means the program reports one argument too many
and reads its own name as data.

### §19.16 — Command-line arguments and files

```cpp
// Word counter: ./wordcount input.txt
int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <filename>\n";
        return 1;
    }
    ifstream f(argv[1]);
    if (!f) { cerr << "Cannot open: " << argv[1] << "\n"; return 1; }

    string word;
    int words = 0, lines = 0, chars = 0;
    string line;
    while (getline(f, line)) {
        lines++;
        chars += line.size();
        istringstream iss(line);
        while (iss >> word) words++;
    }
    cout << lines << " " << words << " " << chars << " " << argv[1] << "\n";
}
// Run: $ ./wordcount myfile.txt
// Out: 42 317 1842 myfile.txt
```

This is a miniature of how every command-line tool is built, and three habits in it are worth
copying.

**Check `argc` before touching `argv`.** Reading `argv[1]` when only the program name was given
reads past the end of the array. The check comes first, always.

**The usage message goes to `cerr` and uses `argv[0]`.** Errors belong on the error stream so
that they survive a redirect of the output. Using `argv[0]` rather than a hard-coded name means
the message stays correct if the executable is renamed.

**A non-zero `return` reports failure.** Shell scripts and `make` test the exit status, so a
program that fails and returns 0 will be treated as having succeeded — and the pipeline built
on it carries on with nothing.

**The word counting itself uses a stream-within-a-stream.** `getline` takes a whole line, and
`istringstream iss(line)` then treats that line as a stream so `iss >> word` can split it on
whitespace. That is the standard way to tokenise a line, and it handles runs of spaces and tabs
without any manual scanning. Note that `chars` counts the characters *within* lines and so
excludes the newlines themselves — a real `wc -c` would count those too.

:::callout-key[Converting `argv` strings to numbers]
```cpp
void convert(char* argv[]) {
int n    = stoi(argv[1]);    // string → int
double x = stod(argv[2]);    // string → double
// Both throw invalid_argument if argv[i] isn't a valid number
}
```

Everything in `argv` is text, always: running `./prog 42` gives you the two characters `4` and
`2`, not the number.

These throw rather than returning a sentinel, so an unguarded `stoi` on user input terminates
the program with an uncaught exception. Wrap it in a `try`, as Chapter 15 sets out, and print a
usage message instead. And recall from §15.5 that `stoi` is permissive: `stoi("42abc")` returns
42 without complaint, so a strict parser needs the extra checks made there.
:::

## §19.17 — The `#define` Directive

`#define` is a *preprocessor* directive that performs blind text substitution before the
compiler sees anything. It predates `const`, and it is now mostly a legacy feature.

```cpp
// Old style — avoid in new code
#define PI 3.14159265
#define MAX_SIZE 100
#define SQUARE(x) ((x)*(x))   // macro function — dangerous!
```

The modern replacements say the same things with types and scopes attached:

```cpp
const double Pi = 3.14159265;              // typed, scoped
constexpr int MaxSize = 100;               // compile-time constant
template <typename T> T square(T x) { return x*x; }  // type-safe
```

:::callout-pitfall[Why those had to be two separate blocks]
Put those six lines in *one* translation unit and it does not compile. The macros are still in
force, so `const double PI = 3.14159265;` is textually rewritten to

```text
const double 3.14159265 = 3.14159265;
```

which is the error `expected unqualified-id before numeric constant`. The macro has eaten the
variable name.

This is not a contrived illustration — it is what the compiler actually reports, and it is the
best possible demonstration of the hazard. **A macro is not a variable and obeys no scope**: it
replaces that sequence of characters everywhere after its definition, including in places where
the identifier was meant to be a name rather than a value.

The modern versions above are deliberately spelled `Pi` and `MaxSize` for the same reason. Had
they reused the macro names they would have been clobbered too, which is why the widespread
convention of `SHOUTING_CASE` for macros exists: it reserves a whole shape of identifier so
that ordinary names cannot collide with one.
:::

Now the function-like macro, which is the more insidious of the two:

```cpp
// Why macros are dangerous:
int a = 5;
// SQUARE(a+1) with #define expands to ((a+1)*(a+1)) = 36 ✓
// But SQUARE(a++) expands to ((a++)*(a++)) — undefined behavior!
// square(a++) with a template: a++ evaluated once ✓
```

`SQUARE(a+1)` survives only because the macro's definition is parenthesised as `((x)*(x))`.
Written the obvious way, as `x*x`, the expansion would be `a+1*a+1` — which by precedence is
$a + a + 1 = 11$, not 36. Every macro parameter needs parentheses around it *and* around the
whole body, and even then the next problem remains.

`SQUARE(a++)` expands to `((a++)*(a++))`, which increments `a` twice and reads it twice with no
sequencing between them: undefined behaviour, not merely a wrong answer. The template version
takes `a++` as an argument, evaluates it exactly once, and passes the resulting value. A macro
cannot do that because it never evaluates anything — it only substitutes text.

:::callout-warning[In modern C++]
- Use `const` or `constexpr` instead of `#define` for constants — they have types, respect
  scope, and appear in the debugger.
- Use `inline` functions or templates instead of function-like macros — they evaluate their
  arguments once and type-check them.
- `#define` remains legitimate for **include guards** (`#ifndef` / `#define` / `#endif`) and
  for conditional compilation, where text substitution is exactly what is wanted.
:::

## §19.18–§19.19 — Compiling from the Command Line

```text
# Basic compilation
$ g++ -o myprogram main.cpp
$ ./myprogram

# With warnings and C++17
$ g++ -Wall -Wextra -std=c++17 -o myprogram main.cpp

# Compile without linking (create .o file)
$ g++ -c main.cpp        # produces main.o
$ g++ -c helper.cpp      # produces helper.o

# Link object files
$ g++ -o myprogram main.o helper.o

# Debug build (add debug symbols)
$ g++ -g -o myprogram_debug main.cpp
$ gdb ./myprogram_debug

# Optimized release build
$ g++ -O2 -o myprogram main.cpp

# Compile and run in one line (bash)
$ g++ -std=c++17 -o run main.cpp && ./run
```

**Turn `-Wall -Wextra` on now and leave them on.** The compiler will tell you about unused
variables, comparisons between signed and unsigned, and functions that fall off the end without
returning — the exact bugs that are otherwise found by debugging. They are not on by default
for historical reasons, not because they are noisy.

**`-g` and `-O2` pull in opposite directions.** Debug symbols let `gdb` map machine code back to
your source lines; optimisation rearranges and deletes code until that mapping is approximate.
Build with `-g` while developing, `-O2` when shipping, and expect a debugger on an optimised
build to report variables as "optimised out".

**The `&&` in the last line is the shell's, not C++'s**, and it means "run the second command
only if the first succeeded". Without it a failed compilation would be followed by running the
*previous* successful executable, and you would debug output that your latest edit never
produced.

### §19.19 — Modular compilation

```text
Project structure:
  Calculator.h    ← declarations
  Calculator.cpp  ← definitions
  main.cpp        ← uses Calculator

Compilation:
  g++ -c Calculator.cpp   → Calculator.o
  g++ -c main.cpp         → main.o  (needs Calculator.h)
  g++ -o calc Calculator.o main.o

Benefit: only recompile changed files, not the whole project.
  Edit main.cpp → recompile only main.cpp + relink → fast!
```

**Compiling and linking are two different steps**, and separating them is what makes large
projects buildable. `-c` compiles one `.cpp` into an object file containing machine code with
unresolved references — `main.o` knows it calls `Calculator::add` but not where that lives. The
linker then matches every reference to its definition and produces the executable.

That separation is why the header/source split exists. The header declares *what* exists so
that any `.cpp` can be compiled against it; the source defines *how*, once. Change only an
implementation and just that one file recompiles. Change a header and everything that includes
it must be rebuilt, which is why headers are kept small.

It also explains the two most common build errors, which look similar and are not.
**"Undefined reference"** is a *linker* error: the declaration was found, the definition was
not — usually a `.cpp` left off the command line. **"Not declared in this scope"** is a
*compiler* error: a missing `#include`.

## §19.20 — Makefiles

A **Makefile** automates the build. `make` compares timestamps to work out which files have
changed and rebuilds only what is necessary.

```makefile
# Makefile for a simple project
# Syntax: target: dependencies
#         [TAB] command

CXX      = g++
CXXFLAGS = -Wall -Wextra -std=c++17 -g
OBJS     = main.o Calculator.o StringUtils.o

# Default target (first target = what 'make' builds)
all: myprogram

# Link step
myprogram: $(OBJS)
	$(CXX) $(CXXFLAGS) -o myprogram $(OBJS)

# Compile steps
main.o: main.cpp Calculator.h StringUtils.h
	$(CXX) $(CXXFLAGS) -c main.cpp

Calculator.o: Calculator.cpp Calculator.h
	$(CXX) $(CXXFLAGS) -c Calculator.cpp

StringUtils.o: StringUtils.cpp StringUtils.h
	$(CXX) $(CXXFLAGS) -c StringUtils.cpp

# Clean build artifacts
clean:
	rm -f $(OBJS) myprogram

# Phony targets don't produce files
.PHONY: all clean
```

```text
# Common make commands
$ make              # build the default target
$ make clean        # remove build artifacts
$ make myprogram    # build specific target
$ make -j4          # parallel build using 4 cores
```

**A rule is a target, its dependencies, and a command.** `make` rebuilds the target if it is
missing or if *any* dependency is newer than it. That single rule, applied recursively, is the
entire algorithm.

**The dependency lists are where the thought goes.** `main.o` depends on `main.cpp` *and* on
both headers it includes — so editing `Calculator.h` correctly rebuilds `main.o`. Leave a
header out of the list and `make` will not notice the change, producing a build that mixes new
headers with stale object files and fails in ways that make no sense until you run
`make clean`.

**`.PHONY` marks targets that are not files.** Without it, creating a file named `clean` in the
directory would make `make clean` report "nothing to be done" — the target would look
up-to-date, because a file by that name exists and has no dependencies.

**`make -j4` works because the dependency graph is explicit.** The three `.o` files depend on
nothing but their own sources, so `make` can see they are independent and compile them at once.

:::callout-pitfall[The tab]
The command line under each target must begin with a literal **TAB**, not spaces. This is the
most famous error in the tool, it has been that way since 1976, and the message you get —
`missing separator` — does not mention whitespace at all.

If your editor converts tabs to spaces, turn that off for Makefiles specifically.
:::

## §19.21 — Why Pointers?

Pointers were covered in depth in Chapter 8. This section is the higher-level view of *why*
they exist and where they remain unavoidable even in modern C++.

```cpp
// 1. Dynamic data structures (linked list, tree, graph)
struct Node { int data; Node* next; };   // must use pointer
```

The pointer is not a choice here. A `Node` containing a `Node` by value would need infinite
space — the compiler cannot even compute its size. A pointer is a fixed 8 bytes regardless of
what it points at, which is what allows a type to refer to itself.

```cpp
// 2. Polymorphism requires a pointer or reference
struct Shape { virtual double area() const = 0; virtual ~Shape() = default; };
struct Circle : Shape {
    double r;
    Circle(double r) : r(r) {}
    double area() const override { return 3.14159265 * r * r; }
};

void demo() {
    Shape* s = new Circle(5);
    s->area();     // calls Circle::area(), not Shape::area()
    delete s;
}
```

Virtual dispatch works only through a pointer or reference. Assigning a `Circle` to a `Shape`
*by value* **slices** it — the `Circle` part is discarded and only the `Shape` sub-object is
copied — which is the same slicing hazard that makes Chapter 15 insist on catching exceptions
by reference.

```cpp
// 3. Optional values (before std::optional)
struct ListNode { int data; ListNode* next; };

ListNode* findNode(ListNode* head, int val) {
    // returns nullptr if not found — the pointer IS the optional
    while (head && head->data != val) head = head->next;
    return head;
}
```

A pointer has a value meaning "nothing", which no `int` or `double` has. Modern C++ prefers
`std::optional<T>` for this, because it works for value types too and cannot be dereferenced by
accident — but the pattern is everywhere in existing code and needs reading.

Note the short-circuit in `head && head->data != val`: `&&` evaluates left to right and stops
at the first false, so `head->data` is never reached when `head` is null. Swap the two
conditions and the loop dereferences a null pointer at the end of every unsuccessful search.

## Chapter summary

:::callout-key[Language features]
- `do-while` tests at the bottom; use it for input validation and little else
- Local arrays are **not** zeroed — write `int a[100] = {};`
- Integer division truncates: cast *before* dividing, not after
- Reversal runs to `n/2`; running to `n` undoes itself
- Arrays decay to pointers on a function call, so `sizeof` fails and the size must be passed
- `struct` groups what parallel arrays only pretend to group
- `argv[0]` is the program name; check `argc` before reading anything
- Macros obey no scope and evaluate nothing — prefer `const`, `constexpr`, and templates
:::

:::callout-tip[Tooling]
- `-Wall -Wextra` always; `-g` while developing, `-O2` when shipping
- `-c` compiles, plain `g++` links — "undefined reference" is a linker error, "not declared"
  is a compiler error
- A header declares, a source defines; small headers mean fast rebuilds
- A Makefile rule is target, dependencies, command — and the command starts with a **TAB**
- List every header a `.o` depends on, or `make` will miss the change
- `.PHONY` for targets that are not files
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Find the second largest.** Write `int secondLargest(const int arr[], int n)` returning the
second largest *distinct* value. Throw `invalid_argument` if there are fewer than two distinct
values.

::::solution[Solution]
```cpp
int secondLargest(const int arr[], int n) {
    if (n < 2) throw invalid_argument("Need at least two elements");
    int first = INT_MIN, second = INT_MIN;
    bool haveFirst = false, haveSecond = false;
    for (int i = 0; i < n; i++) {
        if (!haveFirst || arr[i] > first) {
            if (haveFirst) { second = first; haveSecond = true; }
            first = arr[i]; haveFirst = true;
        } else if (arr[i] != first && (!haveSecond || arr[i] > second)) {
            second = arr[i]; haveSecond = true;
        }
    }
    if (!haveSecond) throw invalid_argument("No distinct second largest");
    return second;
}
```

**One pass, two variables** — this is Pattern 3 from §19.2 with a second slot. When a new
maximum arrives the old maximum demotes to second, which is the line people forget: without
`second = first;` the function finds the largest twice and never records a runner-up.

**"Distinct" is the whole difficulty.** On `[5,5,3]` the answer is 3, not 5, which is why the
`else if` tests `arr[i] != first`. On `[5,5]` there is no distinct second value at all and the
function must throw — a version that silently returns 5 is wrong in a way no test on distinct
data would catch.

**Why the `bool` flags rather than seeding with `INT_MIN` alone.** If the array genuinely
contains `INT_MIN`, a comparison against the sentinel cannot distinguish "no value yet" from "a
real value that happens to be the smallest possible". The flags remove that ambiguity, which is
the same reason §18.3 used a $-1$ index sentinel that no real index can take.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Struct instead of parallel arrays.** Rewrite the §19.4 example using a `struct`, and sort the
students by grade in descending order. Explain what breaks in the parallel-array version that
cannot break here.

::::solution[Solution]
```cpp
struct Student { string name; int grade; };

void sortByGrade(vector<Student>& v) {
    sort(v.begin(), v.end(),
         [](const Student& a, const Student& b) { return a.grade > b.grade; });
}

int main() {
    vector<Student> v = {{"Alice",92},{"Bob",87},{"Carol",78},{"Dave",95}};
    sortByGrade(v);
    for (const auto& s : v) cout << s.name << " " << s.grade << "\n";
}
```

Output: `Dave 95`, `Alice 92`, `Bob 87`, `Carol 78`.

**What cannot break here.** Sorting moves whole `Student` objects, so a name and its grade
travel together by construction. There is no step at which they could be separated, and no
discipline required of the programmer.

**What breaks in the parallel version.** Calling `sort(grades, grades+4)` reorders the grades
and leaves `names` untouched, so afterwards Alice has Dave's mark. Nothing in the language
objects — the two arrays were never related — and the program prints confident nonsense.
Sorting them together requires sorting an array of *indices* and permuting both arrays by it,
which is fiddly enough that people get it wrong.

**The lambda is the comparator**, and `>` gives descending order where `<` would give ascending.
It takes both parameters by `const&` to avoid copying a `string` on every one of the roughly
$n\log n$ comparisons.
::::
:::

:::problem[P3 standard]{difficulty="standard"}
**A safe `stoi` wrapper.** Write `int parseArg(const char* s, const string& what)` that converts
a command-line argument to an `int` and throws `invalid_argument` naming `what` if it is not a
valid number, or if trailing characters follow it.

::::solution[Solution]
```cpp
int parseArg(const char* s, const string& what) {
    string str(s);
    try {
        size_t pos;
        int v = stoi(str, &pos);
        if (pos != str.size())
            throw invalid_argument(what + ": trailing characters in '" + str + "'");
        return v;
    } catch (const out_of_range&) {
        throw invalid_argument(what + ": '" + str + "' is out of int range");
    }
}
```

**The `pos` check is what makes it strict.** `stoi("42abc")` returns 42 and reports success,
stopping at the first non-digit; comparing the stop position against the string length is the
only way to notice the leftovers. This is the same test §15.5 used in `parseInteger`.

**Naming the argument matters for a command-line tool.** `"Cannot parse '3x'"` leaves the user
guessing which argument was wrong; `"count: trailing characters in '3x'"` does not. When a
program is driven from a shell, the error message is the entire user interface.

**Note the catch converts rather than propagates.** An `out_of_range` from `stoi` is turned into
an `invalid_argument` with a clearer message, so every failure of this function is a single
exception type the caller can handle in one place. The `invalid_argument` thrown for trailing
characters passes through the handler untouched, because it is not an `out_of_range`.
::::
:::

:::problem[P4 challenge]{difficulty="challenge"}
**Dice statistics.** Simulate rolling two six-sided dice $N$ times, with $N$ from a
command-line argument. Count the frequency of each sum (2–12) and print a histogram with
asterisks proportional to frequency.

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc != 2) { cerr << "Usage: dice <N>\n"; return 1; }
    int N = stoi(argv[1]);
    srand(time(nullptr));
    int freq[13] = {};
    for (int i = 0; i < N; i++) {
        int sum = (rand()%6+1) + (rand()%6+1);
        freq[sum]++;
    }
    int maxFreq = *max_element(freq+2, freq+13);
    for (int s = 2; s <= 12; s++) {
        int bars = (int)(40.0 * freq[s] / maxFreq);
        cout << setw(3) << s << " | ";
        cout << string(bars, '*') << " (" << freq[s] << ")\n";
    }
}
```

**The includes are not optional here** and are the sort of thing that is easy to leave out:
`<iomanip>` for `setw`, `<algorithm>` for `max_element`, `<cstdlib>` for `rand` and `srand`,
`<ctime>` for `time`. Omit any one and the program fails to compile, usually with a message
that names the function rather than the header.

**Why the array is size 13 when there are only 11 possible sums.** Indices 2 through 12 are
used and 0 and 1 are wasted, so that `freq[sum]` needs no arithmetic. Two ints of waste in
exchange for removing an off-by-one from every access is a good trade, and `= {}` zeroes all
thirteen.

**`(rand()%6+1) + (rand()%6+1)` is two dice, and it matters that it is not `rand()%11+2`.**
Both produce values in 2–12, but the first gives the triangular distribution real dice have —
6 ways to roll a 7, one way to roll a 2 — while the second makes every sum equally likely. The
histogram is a picture of that difference, and running with a large $N$ should show a clear
peak at 7 roughly six times the height of the bar at 2.

**`max_element(freq+2, freq+13)` scales the histogram** to whatever the busiest sum turned out
to be, so the longest bar is always 40 characters. Note the range starts at `freq+2`, skipping
the two unused slots — including them would find a maximum of 0 among them, which is harmless
here but would divide by zero if $N$ were 0. That is the one input this program does not
defend against.

**`rand()` is a poor generator** and biased by `%` besides. It is fine for a histogram and
wrong for anything that matters; `<random>` provides `mt19937` and
`uniform_int_distribution<int> die(1,6)`, which is the modern form.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
These reinforce the supplemental topics — array patterns, struct design, and single-pass
algorithms.

| # | Problem | Difficulty | Topic connection |
| --- | --- | --- | --- |
| [1480](https://leetcode.com/problems/running-sum-of-1d-array/) | Running Sum of 1d Array | Easy | Prefix sums, in place — §19.2 |
| [1470](https://leetcode.com/problems/shuffle-the-array/) | Shuffle the Array | Easy | Array index arithmetic — §19.3 |
| [1603](https://leetcode.com/problems/design-parking-system/) | Design Parking System | Easy | A struct with several counters — §19.11 |
| [724](https://leetcode.com/problems/find-pivot-index/) | Find Pivot Index | Easy | Prefix and suffix sums — §19.7 |
| [169](https://leetcode.com/problems/majority-element/) | Majority Element | Easy | Single-pass array algorithm — §19.4 |
| [238](https://leetcode.com/problems/product-of-array-except-self/) | Product of Array Except Self | Medium | Prefix and suffix products, no division — §19.7 |
:::
