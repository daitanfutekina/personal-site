---
title: "DS–14: Trees"
source: "ds_ch14_trees.html"
---

CSE 2813

# DS–14: Trees

§14.1 – §14.6

:::callout-tip
What You'll Learn

— Trees are graphs stripped of every redundancy: connected, acyclic, with exactly one path between any two vertices. This final chapter covers the formal theory of trees (properties, rooted structures, traversals), then builds to the two crown jewels of weighted graph algorithms: spanning trees and minimum spanning trees via Prim's and Kruskal's algorithms. These are standard Honors DSA topics.
:::

## §14.1 Introduction to Trees

:::callout-intuition
Remove any edge from a tree and it falls apart into two disconnected pieces. Add any edge and you create a cycle. Trees are graphs balanced perfectly at the edge between connectivity and acyclicity — and this makes them uniquely tractable.
:::

:::definition[Definition 14.1 — Tree]
Tree and Forest

A **tree** is a connected acyclic undirected graph. A **forest** is an acyclic graph (not necessarily connected); each connected component of a forest is a tree.

A **rooted tree** designates one vertex as the **root**; this induces a parent-child relationship on all vertices. The root has no parent; every other vertex has exactly one parent.
:::

:::theorem[Theorem 14.1 — Equivalent Characterizations]
Tree Equivalences

For a graph $G$ with $n$ vertices, the following are equivalent:

1. $G$ is a tree (connected and acyclic).
2. $G$ is connected and has exactly $n-1$ edges.
3. $G$ is acyclic and has exactly $n-1$ edges.
4. There is a **unique path** between every pair of vertices in $G$.
5. $G$ is connected, and removing any single edge disconnects it (every edge is a bridge).
6. $G$ is acyclic, and adding any edge between non-adjacent vertices creates exactly one cycle.
:::

Example 14.1 — Verifying a Tree

A graph has 7 vertices and 6 edges and is connected. Must it be a tree?

:::answer[Answer]
Yes.
:::

:::answer
Work

By Theorem 14.1 (item 2): connected + $n-1$ edges $\iff$ tree. With $n=7$: $n-1=6$ edges and connected $\Rightarrow$ it is a tree.
:::

## §14.2 Tree Application Examples

:::callout-intuition
The tree structure appears naturally whenever data is hierarchical or decisions unfold sequentially. Recognizing these structures helps you immediately know which algorithms and properties apply.
:::

### Parse Trees

A compiler builds a **parse tree** (or abstract syntax tree, AST) from source code. Each internal node is an operator; leaves are operands. The tree structure captures operator precedence naturally without parentheses.

```
Expression:  3 * (4 + 5)

         *
        / \
       3   +
          / \
         4   5
```

Post-order traversal of the AST gives reverse Polish notation: `3 4 5 + *`

### Decision Trees

A **decision tree** models a sequence of yes/no decisions. Internal nodes are questions; leaves are outcomes. Used in machine learning (decision tree classifiers), game trees, and binary search (each comparison eliminates half the search space).

### Huffman Coding Trees

Huffman coding builds an optimal binary tree for lossless compression. Frequent characters get shorter bit strings (paths closer to root); rare characters get longer ones. The tree structure guarantees the prefix-free property needed for unambiguous decoding.

### Organizational Hierarchies and File Systems

Company org charts, Unix/Linux directory structures, and XML/HTML document trees are all rooted trees. The parent-child relationship maps directly to containment or authority.

## §14.3 Properties of Trees

:::definition[Definition 14.2 — Rooted Tree Terminology]
Rooted Tree Vocabulary

In a rooted tree rooted at $r$:

 **Parent** of $v$: the vertex adjacent to $v$ on the path from $v$ to $r$.
 **Children** of $v$: all vertices for which $v$ is the parent.
 **Leaf**: a vertex with no children (degree 1 in the underlying undirected tree, except when the root has degree 1).
 **Internal vertex**: a non-leaf vertex.
 **Subtree** rooted at $v$: the subgraph consisting of $v$ and all its descendants.
 **Level** of $v$: length of the path from root to $v$. Root is at level 0.
 **Height** of the tree: maximum level of any vertex.
 **$m$-ary tree**: every internal vertex has at most $m$ children. A **full $m$-ary tree** has every internal vertex with exactly $m$ children.
:::

:::theorem[Theorem 14.2 — Leaf Count in Full $m$-ary Trees]
Leaves in Full $m$-ary Trees

A full $m$-ary tree with $i$ internal vertices has:

- $mi + 1$ total vertices (including root)
- $\ell = (m-1)i + 1$ leaves

*Proof:* Total vertices $n = \ell + i$. Each internal vertex contributes $m$ edges downward; the root has no parent edge; so $n - 1 = mi$ edges, giving $n = mi + 1$. Then $\ell = n - i = (m-1)i + 1$. □
:::

:::theorem[Theorem 14.3 — Height vs Leaves (Binary Trees)]
Binary Tree Bounds

A binary tree ($m=2$) of height $h$:

- Has at most $2^h$ leaves.
- If it has $\ell$ leaves, its height satisfies $h \geq \lceil \log_2 \ell \rceil$.

*Application:* Any comparison-based sorting algorithm requires $\Omega(n \log n)$ comparisons — because its decision tree has $n!$ leaves (all permutations) and height $\geq \log_2(n!) = \Omega(n \log n)$ by Stirling's approximation.
:::

Example 14.2 — Full Binary Tree

A full binary tree has 10 internal vertices. How many leaves does it have? How many total vertices?

:::answer[Answer]
11 leaves, 21 total vertices.
:::

:::answer
Work

$m=2$, $i=10$.

Leaves: $\ell = (m-1)i + 1 = (1)(10) + 1 = 11$.

Total: $n = mi + 1 = 2(10)+1 = 21$. Check: $21 = 11 + 10$. ✓
:::

## 14.4 Tree Traversals

A **traversal** is a systematic method of visiting every vertex in a tree exactly once. The four classical traversals differ only in *when* the root is processed relative to its subtrees.

:::definition
Definition 14.3

The Four Standard Traversals

Let $T$ be a rooted ordered tree with root $r$ and (left-to-right ordered) subtrees $T_1, T_2, \ldots, T_k$.

- **Pre-order:** Visit $r$, then pre-order each $T_i$ left-to-right.
- **In-order** (binary trees): In-order $T_1$, visit $r$, in-order $T_2$.
- **Post-order:** Post-order each $T_i$ left-to-right, then visit $r$.
- **Level-order (BFS):** Visit vertices level by level, left-to-right within each level.
:::

:::callout-key
Memory trick:

the prefix tells you when to visit the root relative to the subtrees.

Pre

= root first.

Post

= root last.

In

= root in the middle (binary only).
:::

Example 14.3 — All Four Traversals

Given the binary search tree below, list each traversal order.

```

        4
       / \
      2   6
     / \ / \
    1  3 5  7
```

:::answer[Pre-order]
4, 2, 1, 3, 6, 5, 7
:::

:::answer[In-order]
1, 2, 3, 4, 5, 6, 7  ← sorted! (always true for BSTs)
:::

:::answer[Post-order]
1, 3, 2, 5, 7, 6, 4
:::

:::answer[Level-order]
4, 2, 6, 1, 3, 5, 7
:::

:::theorem[Theorem 14.4 — In-order and BSTs]
In-order Traversal Sorts a BST

The in-order traversal of a binary search tree visits the keys in non-decreasing order.

*Proof sketch:* By the BST property, every key in the left subtree $< r <$ every key in the right subtree. Induction on height completes the argument. □
:::

:::callout-key
Applications of traversal order:

- **Pre-order** — copy a tree; serialize a file-system directory.
- **In-order** — print BST contents in sorted order; expression trees (infix).
- **Post-order** — delete a tree (children before parent); evaluate expression trees (postfix / RPN).
- **Level-order** — BFS; find shortest path in unweighted graphs; heap array indexing.
:::

Example 14.4 — Expression Tree Evaluation

Build the expression tree for $(3+4)\times 5$ and give its pre-order, in-order, and post-order traversals.

```

      ×
     / \
    +   5
   / \
  3   4
```

:::answer[Pre-order (prefix)]
× + 3 4 5
:::

:::answer[In-order (infix)]
3 + 4 × 5  ← needs parentheses to be unambiguous
:::

:::answer[Post-order (postfix / RPN)]
3 4 + 5 ×  ← evaluate left-to-right with a stack: push 3, push 4, + → 7, push 5, × → 35
:::

## 14.5 Spanning Trees and Graph Traversals

:::definition
Definition 14.4

Spanning Tree

A **spanning tree** of a connected graph $G = (V, E)$ is a subgraph $T$ that:

- includes *all* vertices of $G$ (it "spans" $G$), and
- is a tree (connected and acyclic).

Every connected graph has at least one spanning tree. It has exactly $|V| - 1$ edges.
:::

:::callout-key
Why spanning trees matter:

Network designers use them to find the minimum set of connections that keeps every node reachable — no redundant cables, no cycles creating routing loops.
:::

### Building Spanning Trees with DFS and BFS

Both graph traversal algorithms naturally produce spanning trees as a by-product of traversal. The edges used to first discover each new vertex form the spanning tree.

:::theorem[Theorem 14.5 — DFS/BFS Spanning Trees]
Traversal Trees are Spanning Trees

Running DFS or BFS on a connected graph $G$ starting from any root $r$ produces a spanning tree of $G$. The tree edges are exactly the edges $(u,v)$ where $v$ was first discovered via $u$.
:::

Example 14.5 — DFS vs BFS Spanning Trees

Find a DFS spanning tree and a BFS spanning tree for the graph with edges: 1-2, 1-3, 2-4, 2-5, 3-5, 4-6, 5-6. Start from vertex 1.

```

Graph:   1 — 2 — 4 — 6
         |   |   |
         3 — 5 ——+
```

:::answer[DFS tree edges]
1→2, 2→4, 4→6, 6→5, 5→3  (deep path, long chains)
:::

:::answer[BFS tree edges]
1→2, 1→3, 2→4, 2→5, 4→6  (wide and shallow, vertices near root discovered first)
:::

:::answer
Key observation

Both use 5 edges (= $|V|-1 = 6-1$), but their shapes differ dramatically. BFS trees have small depth (good for shortest paths); DFS trees can be tall and snake-like.
:::

:::callout-warning
Back edges, forward edges, cross edges:

In DFS, non-tree edges are called

back edges

(to an ancestor) in undirected graphs. A back edge means a cycle exists — this is how DFS detects cycles in $O(V+E)$.
:::

## 14.6 Minimum Spanning Trees

When edges carry weights (distances, costs, latencies), we often want the cheapest spanning tree.

:::definition
Definition 14.5

Minimum Spanning Tree (MST)

Given a connected weighted graph $G$, a **minimum spanning tree** is a spanning tree $T$ whose total edge weight $\displaystyle\sum_{e \in T} w(e)$ is minimized over all spanning trees of $G$.
:::

:::theorem[Theorem 14.6 — Cut Property (Correctness of Greedy MST)]
The Cut Property

Let $(S, V \setminus S)$ be any cut of $G$ (a partition of vertices into two non-empty sets). If $e$ is the unique minimum-weight edge crossing the cut, then $e$ belongs to every MST of $G$.

*Intuition:* Swapping any other crossing edge for $e$ would lower the total weight — contradiction. This greedy "safe edge" principle underpins both Prim's and Kruskal's algorithms.
:::

### Prim's Algorithm

Grows the MST one vertex at a time, always adding the cheapest edge connecting the current tree to a new vertex.

:::callout-key
Prim's Algorithm

1. Start with any root vertex $r$; mark it visited.
2. Maintain a priority queue of edges from visited → unvisited vertices.
3. Repeat until all vertices are visited:
   a. Extract minimum-weight edge $(u, v)$ with $v$ unvisited.
   b. Add edge $(u,v)$ to MST; mark $v$ visited.
   c. Add all edges from $v$ to unvisited neighbors to the queue.

Time:

$O(E \log V)$ with a binary heap.
:::

Example 14.6 — Prim's Algorithm Step-by-Step

Find the MST using Prim's starting at vertex A. Weighted edges: A-B:4, A-C:2, B-C:1, B-D:5, C-D:8, C-E:10, D-E:2, D-F:6, E-F:3.

:::answer
Steps

1. Start at A. Candidates: A-B(4), A-C(2). Pick **A-C:2**. MST={A-C}.
2. From {A,C}. Candidates: A-B(4), C-B(1), C-D(8), C-E(10). Pick **C-B:1**. MST={A-C, C-B}.
3. From {A,C,B}. Candidates: A-B already visited, B-D(5), C-D(8), C-E(10). A-B dup. Pick **B-D:5**. MST={A-C, C-B, B-D}.
4. From {A,B,C,D}. Candidates: D-E(2), D-F(6), C-E(10). Pick **D-E:2**. MST={A-C,C-B,B-D,D-E}.
5. From {A,B,C,D,E}. Candidates: E-F(3), D-F(6). Pick **E-F:3**. MST complete.
:::

:::answer[MST edges]
A-C(2), B-C(1), B-D(5), D-E(2), E-F(3) — Total weight:

13
:::

### Kruskal's Algorithm

Sorts all edges by weight and adds them greedily, skipping any edge that would create a cycle.

:::callout-key
Kruskal's Algorithm

1. Sort all edges by weight (ascending).
2. Initialize each vertex as its own component (Union-Find).
3. For each edge $(u,v)$ in sorted order:
   a. If $u$ and $v$ are in different components:
      - Add $(u,v)$ to MST.
      - Merge the two components.
4. Stop when MST has $|V|-1$ edges.

Time:

$O(E \log E)$ (dominated by sorting).
:::

:::callout-key
Prim vs Kruskal:

Both always produce an MST (by the Cut Property). Prim's is faster on dense graphs (many edges); Kruskal's is faster on sparse graphs and is simpler to implement with Union-Find. For competitive programming, Kruskal's with Union-Find is the default.
:::

Example 14.7 — Kruskal's Algorithm

Apply Kruskal's to the same graph from Example 14.6.

:::answer
Sorted edges

B-C:1, A-C:2, D-E:2, E-F:3, A-B:4, B-D:5, D-F:6, C-D:8, C-E:10
:::

:::answer
Processing

1. B-C:1 — different components. Add. Components: {A},{B,C},{D},{E},{F}.
2. A-C:2 — A and C differ. Add. {A,B,C},{D},{E},{F}.
3. D-E:2 — differ. Add. {A,B,C},{D,E},{F}.
4. E-F:3 — E and F differ. Add. {A,B,C},{D,E,F}.
5. A-B:4 — A and B same component. *Skip* (would create cycle).
6. B-D:5 — B in {A,B,C}, D in {D,E,F}. Add. All merged. Done (5 = 6−1 edges).
:::

:::answer[MST edges]
B-C(1), A-C(2), D-E(2), E-F(3), B-D(5) — Total:

13

✓ (same as Prim's)
:::

## Chapter Summary

:::summary
### Key Definitions

- **Tree:** connected acyclic graph. $n$ vertices → exactly $n-1$ edges.
- **Rooted tree:** one vertex designated root; defines parent/child/ancestor/descendant/leaf/internal.
- **$m$-ary tree:** every internal vertex has $\leq m$ children; *full* if exactly $m$ children.
- **Height $h$:** length of longest root-to-leaf path.
- **Spanning tree:** subgraph that includes all vertices and is a tree.
- **MST:** spanning tree with minimum total edge weight.

### Key Theorems

- **6 Equivalent Characterizations** (Thm 14.1): connected+acyclic ⟺ connected+$(n-1)$ edges ⟺ acyclic+$(n-1)$ edges ⟺ unique path between every pair ⟺ connected but removing any edge disconnects ⟺ acyclic but adding any edge creates a cycle.
- **Full $m$-ary leaves** (Thm 14.2): $\ell = (m-1)i + 1$, $n = mi + 1$.
- **Binary tree height bound** (Thm 14.3): $h \geq \lceil \log_2 \ell \rceil$; sorting lower bound $\Omega(n \log n)$.
- **In-order = sorted** (Thm 14.4): in-order traversal of a BST visits keys in non-decreasing order.
- **DFS/BFS produce spanning trees** (Thm 14.5).
- **Cut Property** (Thm 14.6): minimum-weight edge across any cut belongs to every MST — justifies greedy correctness of Prim's and Kruskal's.

### Traversal Orders (Quick Reference)

| Traversal | Order | Key Use |
| --- | --- | --- |
| Pre-order | Root → Left → Right | Copy tree; prefix expressions |
| In-order | Left → Root → Right | Sort BST; infix expressions |
| Post-order | Left → Right → Root | Delete tree; postfix / RPN eval |
| Level-order | BFS level by level | Shortest path; heap indexing |

### Algorithm Complexity

| Algorithm | Time | Best For |
| --- | --- | --- |
| Any traversal | $O(n)$ | Visit all nodes once |
| DFS / BFS spanning tree | $O(V+E)$ | Connectivity, cycle detection |
| Prim's MST | $O(E \log V)$ | Dense graphs |
| Kruskal's MST | $O(E \log E)$ | Sparse graphs; simple to code |
:::

## Practice Problems

14.1 — Easy — Tree or Not?

For each graph, state whether it is a tree and justify with one of the six characterizations.

1. 6 vertices, 5 edges, connected.
2. 6 vertices, 6 edges, connected.
3. 6 vertices, 5 edges, not connected.

:::solution[Solution]
**a.** Yes — connected + $n-1$ edges is equivalent to being a tree.

**b.** No — 6 edges means exactly one cycle exists (connected graph with $n$ edges has exactly one cycle).

**c.** No — not connected, so not a tree (trees must be connected).
:::

14.2 — Easy — Full $m$-ary Counting

A full 3-ary tree has 7 internal vertices. How many leaves does it have? How many total vertices?

:::solution[Solution]
$m=3$, $i=7$.

Leaves: $\ell = (m-1)i+1 = (2)(7)+1 = \mathbf{15}$.

Total: $n = mi+1 = 3(7)+1 = \mathbf{22}$. Check: $22 = 15+7$. ✓
:::

14.3 — Easy — Traversal Orders

Give the pre-order, in-order, post-order, and level-order traversals of the following tree.

```

        A
       / \
      B   C
     / \   \
    D   E   F
```

:::solution[Solution]
**Pre-order:** A, B, D, E, C, F

**In-order:** D, B, E, A, C, F

**Post-order:** D, E, B, F, C, A

**Level-order:** A, B, C, D, E, F
:::

14.4 — Medium — Reconstruct a Tree

A binary tree has pre-order: `5 3 2 4 8 7 9` and in-order: `2 3 4 5 7 8 9`. Draw the tree.

:::solution[Solution]
Pre-order root is always the first element: root = **5**. In in-order, everything left of 5 ({2,3,4}) is the left subtree; everything right ({7,8,9}) is the right subtree.

Recurse on left ({3,2,4} pre, {2,3,4} in): root=3, left=2, right=4.

Recurse on right ({8,7,9} pre, {7,8,9} in): root=8, left=7, right=9.

```

        5
       / \
      3   8
     / \ / \
    2  4 7  9
```
:::

14.5 — Medium — Height Lower Bound

A binary tree must sort $n=8$ distinct keys using comparisons. What is the minimum possible height of its decision tree? Why can't we sort faster than $\Omega(n \log n)$ comparisons?

:::solution[Solution]
There are $8! = 40320$ possible orderings of 8 keys, so the decision tree needs at least $40320$ leaves. By Theorem 14.3, height $h \geq \lceil \log_2 40320 \rceil = \lceil 15.3 \rceil = \mathbf{16}$.

In general: $\ell = n!$ leaves requires $h \geq \log_2(n!) = \Omega(n \log n)$ by Stirling's approximation ($\ln n! \approx n \ln n - n$). No comparison sort can beat this lower bound.
:::

14.6 — Medium — MST by Hand

Find the MST of the graph with edges: A-B:3, A-D:1, B-C:4, B-D:2, C-D:5, C-E:6, D-E:7. Use either Prim's or Kruskal's and show each step.

:::solution[Solution]
**Kruskal's** (sorted edges: A-D:1, B-D:2, A-B:3, B-C:4, C-D:5, C-E:6, D-E:7):

1. A-D:1 → add. {A,D}, {B}, {C}, {E}
2. B-D:2 → add. {A,B,D}, {C}, {E}
3. A-B:3 → skip (cycle, A and B already connected).
4. B-C:4 → add. {A,B,C,D}, {E}
5. C-D:5 → skip (cycle).
6. C-E:6 → add. All connected. Done.

**MST edges:** A-D(1), B-D(2), B-C(4), C-E(6) — Total: **13**
:::

14.7 — Medium — DFS vs BFS Spanning Trees

For the graph with edges 1-2, 1-4, 2-3, 2-4, 3-4, 3-5, 4-5, starting from vertex 1, identify the DFS spanning tree and BFS spanning tree edges. Which produces a shorter (lower height) tree?

:::solution[Solution]
**BFS from 1** (queue: 1 → 2,4 → 3,5):
Tree edges: 1-2, 1-4, 2-3, 3-5. Height = 3 (path 1→2→3→5).

**DFS from 1** (visiting neighbors in order: 1→2→3→4→5):
Tree edges: 1-2, 2-3, 3-4, 4-5 (then 1-4 would be a back edge). Actually DFS: 1→2→3→4(4-2 back)→5(5-3 back)→back to 1→4 already visited. Tree edges: 1-2, 2-3, 3-4, 4-5, and 3-5 or 1-4. Height = 4.

**BFS always produces a shallower spanning tree** — it minimizes depth, which is why BFS is used for shortest-path problems.
:::

14.8 — Challenge — Prove the Cut Property

Prove: if $e$ is the unique minimum-weight edge crossing some cut $(S, V \setminus S)$ of a connected weighted graph, then $e$ belongs to every MST.

:::solution[Solution]
**Proof by contradiction.** Suppose $T$ is an MST that does not contain $e = (u,v)$ where $u \in S$, $v \notin S$. Since $T$ is a spanning tree, there is a unique path $P$ from $u$ to $v$ in $T$. This path must cross the cut $(S, V \setminus S)$ at some edge $f \neq e$.

Construct $T' = T - \{f\} + \{e\}$. Then $T'$ is still a spanning tree (removing $f$ splits $T$ into two components; adding $e$ reconnects them since $e$ also crosses the same cut). The weight of $T'$ is $w(T) - w(f) + w(e)$. Since $e$ is the *unique* minimum-weight crossing edge, $w(e) < w(f)$, so $w(T') < w(T)$. This contradicts $T$ being an MST. □
:::

## LeetCode Practice

These problems map directly to the concepts in this chapter. Work through them in order — each builds on the last.

| # | Problem | Difficulty | Chapter Connection |
| --- | --- | --- | --- |
| 104 | [Maximum Depth of Binary Tree](https://leetcode.com/problems/maximum-depth-of-binary-tree/) | Easy | §14.1 — height of a rooted tree; recursive definition |
| 226 | [Invert Binary Tree](https://leetcode.com/problems/invert-binary-tree/) | Easy | §14.3 — rooted tree structure; structural recursion |
| 112 | [Path Sum](https://leetcode.com/problems/path-sum/) | Easy | §14.4 — pre-order / post-order traversal; path tracking |
| 94 | [Binary Tree Inorder Traversal](https://leetcode.com/problems/binary-tree-inorder-traversal/) | Easy | §14.4 — in-order traversal directly; implement recursively and iteratively |
| 144 | [Binary Tree Preorder Traversal](https://leetcode.com/problems/binary-tree-preorder-traversal/) | Easy | §14.4 — pre-order traversal; compare iterative (stack) vs recursive |
| 102 | [Binary Tree Level Order Traversal](https://leetcode.com/problems/binary-tree-level-order-traversal/) | Medium | §14.4 — level-order / BFS traversal; queue-based implementation |
| 98 | [Validate Binary Search Tree](https://leetcode.com/problems/validate-binary-search-tree/) | Medium | §14.4 — Thm 14.4; in-order traversal of BST must be strictly increasing |
| 230 | [Kth Smallest Element in a BST](https://leetcode.com/problems/kth-smallest-element-in-a-bst/) | Medium | §14.4 — in-order gives sorted order; stop at k-th visited node |
| 236 | [Lowest Common Ancestor of a BST](https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-search-tree/) | Medium | §14.3 — ancestor/descendant definitions; BST property guides direction |
