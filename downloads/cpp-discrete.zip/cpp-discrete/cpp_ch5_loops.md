---
title: "Loops"
source: "cpp_ch5_loops.html"
---

CSE 1384

# Loops

§5.1 – §5.13

## Chapter Overview

Loops let your program repeat a block of code — summing a list of numbers, scanning every character of a string, printing a table, or running until the user decides to quit. Without loops you'd have to write the same statement hundreds of times. With loops you write it once and let the computer do the repetition.

:::callout-key[Prerequisites]
Chapters 1–4. You need variables, arithmetic, and if/else — loops combine all three.
:::

**What you'll learn:** `while` and `for` loops, the do-while variant, iterating over strings, nested loops, incremental program development, `break` and `continue`, loop variable scope, and enumerations.

## 1 · While Loops (§5.1–§5.3)

:::callout-intuition[Intuition]
A `while` loop is an `if` that keeps looping back to itself. Check the condition — if true, run the body, then go back and check again. Keep going until the condition becomes false. It's the most fundamental loop because it expresses the raw idea: "keep doing this while this is still true."
:::

### Anatomy of a While Loop (§5.2)

```cpp
// Pattern:
// 1. Initialize loop variable BEFORE the loop
// 2. Check condition
// 3. Body executes while condition is true
// 4. Update loop variable INSIDE the body (or the loop runs forever)

int i = 1;            // 1. initialize
while (i <= 5) {      // 2. condition check
    cout << i << " "; // 3. body
    i++;              // 4. update
}
// Output: 1 2 3 4 5
```

#### Tracing a Loop

The most reliable way to understand a loop is to trace it — write out each variable's value at the start of each iteration:

| Iteration | i (start) | i <= 5? | Output | i (after ++) |
| --- | --- | --- | --- | --- |
| 1 | 1 | true | 1 | 2 |
| 2 | 2 | true | 2 | 3 |
| 3 | 3 | true | 3 | 4 |
| 4 | 4 | true | 4 | 5 |
| 5 | 5 | true | 5 | 6 |
| 6 | 6 | **false** | — | loop exits |

### Common Loop Patterns (§5.3)

#### Counter-controlled loop

```cpp
int sum = 0;
int i = 1;
while (i <= 100) {
    sum += i;  // sum = 1+2+3+...+100
    i++;
}
cout << sum;   // 5050
```

#### Sentinel-controlled loop (run until special value)

```cpp
int value;
int total = 0, count = 0;

cout << "Enter numbers (-1 to stop): ";
cin >> value;
while (value != -1) {       // -1 is the sentinel
    total += value;
    count++;
    cin >> value;
}
if (count > 0)
    cout << "Average: " << static_cast(total) / count << endl;
```

#### Input-validation loop

```cpp
int age;
cout << "Enter age (1-120): ";
cin >> age;
while (age < 1 || age > 120) {
    cout << "Invalid. Try again: ";
    cin >> age;
}
// age is now guaranteed valid
```

#### do-while loop — body always runs at least once

```cpp
int n;
do {
    cout << "Enter a positive number: ";
    cin >> n;
} while (n <= 0);   // repeat only if invalid
// Great for menus and input prompts
```

:::callout-pitfall[Common While Loop Bugs]
- **Infinite loop:** forgot to update the loop variable inside the body — condition never becomes false.
- **Off-by-one:** using `<` vs `<=` wrong — loop runs one too many or too few times. Trace the boundary values to verify.
- **Unread input:** after the loop, there may be a leftover newline if you used `cin >>` — remember `cin.ignore()` if you need `getline` afterward.
:::

:::example[Example 5.1 — Count digits in an integer]
Given a positive integer `n`, count how many digits it has using only integer division.

::::answer[Answer: 1234 → 4 digits]

::::

```cpp
int n = 1234;
int digits = 0;
int temp = n;
while (temp > 0) {
    temp /= 10;   // chop off the last digit each iteration
    digits++;
}
cout << digits;   // 4
```

Trace: temp=1234→123→12→1→0, digits=0→1→2→3→4. Loop exits when temp becomes 0.

Edge case: what about `n = 0`? The loop body never runs, giving `digits = 0`. Fix: initialize `digits = (n == 0) ? 1 : 0;`
:::

:::example[Example 5.2 — Compute a power iteratively]
Compute $b^e$ (b to the power e) using a while loop, without `pow()`.

::::answer[Answer: 2^10 = 1024]

::::

```cpp
int base = 2, exp = 10;
long long result = 1;
int i = 0;
while (i < exp) {
    result *= base;
    i++;
}
cout << result;  // 1024
```
:::

### Practice — While Loops

:::problem[5.1easy]{difficulty="easy"}
Trace this loop. What are the final values of `x` and `s`?

`int x = 1, s = 0; while (x <= 4) { s += x * x; x++; }`

::::solution[Solution]
| x | x≤4? | s |
| --- | --- | --- |
| 1 | T | 0+1=1 |
| 2 | T | 1+4=5 |
| 3 | T | 5+9=14 |
| 4 | T | 14+16=30 |
| 5 | F | loop exits |

**x = 5, s = 30** (sum of squares 1²+2²+3²+4²).
::::
:::

:::problem[5.2standard]{difficulty="standard"}
Write a while loop that prints all multiples of 7 between 1 and 100 inclusive.

::::solution[Solution]
```cpp
int n = 7;
while (n <= 100) {
    cout << n << " ";
    n += 7;
}
// 7 14 21 28 35 42 49 56 63 70 77 84 91 98
```
::::
:::

:::problem[5.3standard]{difficulty="standard"}
Write an input-validation loop using `do-while` that keeps asking for a grade (0–100) until the user enters a valid one.

::::solution[Solution]
```cpp
int grade;
do {
    cout << "Enter grade (0-100): ";
    cin >> grade;
    if (grade < 0 || grade > 100)
        cout << "Invalid! ";
} while (grade < 0 || grade > 100);
cout << "Valid grade: " << grade << endl;
```
::::
:::

:::problem[5.4challenge]{difficulty="challenge"}
Write a loop that computes the sum $\displaystyle\sum_{k=1}^{n} \frac{1}{k}$ (the harmonic series) for a given `int n`. Print the result as a `double`.

::::solution[Solution]
```cpp
int n = 10;
double sum = 0.0;
int k = 1;
while (k <= n) {
    sum += 1.0 / k;   // cast: 1.0 forces double division
    k++;
}
cout << sum;  // ≈ 2.92897 for n=10
```

Writing `1 / k` would give integer division (always 0 for k > 1). The `1.0 /` forces floating-point division.
::::
:::

## 2 · For Loops (§5.4–§5.5)

:::callout-intuition[Intuition]
The `for` loop is the `while` loop's organized sibling. When you know you're counting — "do this exactly N times" or "loop from i=0 to i<n" — a `for` loop bundles the initialization, condition, and update into one line. Less chance of forgetting to update the counter, less visual noise.
:::

### For Loop Anatomy (§5.4)

```cpp
// for (initialization; condition; update)
for (int i = 0; i < 5; i++) {
    cout << i << " ";
}
// Output: 0 1 2 3 4

// Equivalent while loop:
int i = 0;
while (i < 5) {
    cout << i << " ";
    i++;
}
```

The three parts of the `for` header execute in order:

1. **Init** — runs once before the loop starts (`int i = 0`)
2. **Condition** — checked before every iteration (`i < 5`)
3. **Update** — runs after every iteration body (`i++`)

### Common For Loop Patterns (§5.5)

```cpp
// Count down:
for (int i = 10; i >= 1; i--) cout << i << " ";
// 10 9 8 7 6 5 4 3 2 1

// Step by 2:
for (int i = 0; i <= 20; i += 2) cout << i << " ";
// 0 2 4 6 8 10 12 14 16 18 20

// Accumulate:
int product = 1;
for (int i = 1; i <= 5; i++) product *= i;
cout << product;   // 120 (5! = 120)

// Sum of first N squares:
int n = 5, sum = 0;
for (int i = 1; i <= n; i++) sum += i * i;
cout << sum;   // 55
```

### Range-Based For Loop (C++11)

For iterating over every element of a collection (array, vector, string), the range-based for is cleaner:

```cpp
string s = "Hello";
for (char c : s) {          // c takes each character in turn
    cout << c << "-";
}
// Output: H-e-l-l-o-

// With reference (allows modification):
for (char& c : s) {
    c = toupper(c);
}
cout << s;   // HELLO
```

:::callout-pitfall[Off-by-One — The Loop Developer's Nemesis]
The most common loop bug. Ask yourself three questions for every loop:

- What value does i *start* at?
- What is the last value i should *have* when the body runs?
- Does my condition use `<` or `<=`?

Rule of thumb: `for (int i = 0; i < n; i++)` runs exactly **n** times (indices 0 through n-1). `for (int i = 1; i <= n; i++)` also runs exactly **n** times (values 1 through n). Both are correct — just be consistent.
:::

:::example[Example 5.3 — Print a multiplication table]
Print the 1–5 multiplication table using a for loop.

::::answer[Answer]

::::

```cpp
#include <iomanip>
for (int i = 1; i <= 5; i++) {
    for (int j = 1; j <= 5; j++) {
        cout << setw(4) << i * j;
    }
    cout << "\n";
}
```

```
   1   2   3   4   5
   2   4   6   8  10
   3   6   9  12  15
   4   8  12  16  20
   5  10  15  20  25
```
:::

### Practice — For Loops

:::problem[5.5easy]{difficulty="easy"}
How many times does this loop body execute?

`for (int i = 3; i <= 15; i += 3)`

::::solution[Solution]
Values of i: 3, 6, 9, 12, 15 → **5 times**.

 Formula: `(15 - 3) / 3 + 1 = 12/3 + 1 = 4 + 1 = 5`.
::::
:::

:::problem[5.6standard]{difficulty="standard"}
Write a for loop that computes $n!$ (n factorial) for a given `int n`. Use `long long` for the result.

::::solution[Solution]
```cpp
int n = 10;
long long factorial = 1;
for (int i = 2; i <= n; i++) factorial *= i;
cout << factorial;   // 3628800
```
::::
:::

:::problem[5.7standard]{difficulty="standard"}
Use a range-based for loop to count the number of vowels in a string.

::::solution[Solution]
```cpp
string s = "programming";
int vowels = 0;
for (char c : s) {
    c = tolower(c);
    if (c=='a'||c=='e'||c=='i'||c=='o'||c=='u') vowels++;
}
cout << vowels;  // 3  (o, a, i)
```
::::
:::

:::problem[5.8challenge]{difficulty="challenge"}
Write a loop that finds the largest prime number less than or equal to `n = 50`. (Hint: check divisibility from 2 up to the candidate's square root.)

::::solution[Solution]
```cpp
#include <cmath>
int n = 50, largest = 2;
for (int candidate = 2; candidate <= n; candidate++) {
    bool isPrime = true;
    for (int d = 2; d <= sqrt(candidate); d++) {
        if (candidate % d == 0) { isPrime = false; break; }
    }
    if (isPrime) largest = candidate;
}
cout << largest;   // 47
```
::::
:::

## 3 · Loops & Strings (§5.6)

Strings are sequences of characters, so loops are the natural tool for processing them character by character.

```cpp
string s = "Hello, World!";

// Index-based — when you need the position:
for (int i = 0; i < (int)s.length(); i++) {
    if (s[i] == 'l') cout << "Found 'l' at index " << i << "\n";
}

// Range-based — when you just need each character:
int spaces = 0;
for (char c : s) {
    if (c == ' ') spaces++;
}
cout << "Spaces: " << spaces << endl;   // 1
```

:::callout-warning[Cast s.length() when comparing to int]
`s.length()` returns `size_t`, which is *unsigned*. Comparing an `int` loop variable to an unsigned value can cause surprises if the int is negative. Safe habit: cast to `int` in the condition — `i < (int)s.length()`.
:::

:::example[Example 5.4 — Reverse a string]
Reverse the string "abcde" by building a new string from right to left.

::::answer[Answer: "edcba"]

::::

```cpp
string s = "abcde";
string rev = "";
for (int i = s.length() - 1; i >= 0; i--) {
    rev += s[i];
}
cout << rev;  // edcba
```
:::

:::example[Example 5.5 — Count words in a sentence]
Count the words in "the quick brown fox" by counting transitions from space to non-space.

::::answer[Answer: 4 words]

::::

```cpp
string sentence = "the quick brown fox";
int words = 0;
bool inWord = false;
for (char c : sentence) {
    if (!isspace(c) && !inWord) {
        words++;          // just entered a new word
        inWord = true;
    } else if (isspace(c)) {
        inWord = false;   // left a word
    }
}
cout << words;  // 4
```
:::

### Practice — Loops & Strings

:::problem[5.9easy]{difficulty="easy"}
Write a loop that checks whether a string is all digits (i.e., contains only '0'–'9'). Use `isdigit()`.

::::solution[Solution]
```cpp
string s = "12345";
bool allDigits = true;
for (char c : s) {
    if (!isdigit(c)) { allDigits = false; break; }
}
cout << boolalpha << allDigits;  // true
```
::::
:::

:::problem[5.10standard]{difficulty="standard"}
Write a loop that checks whether a string is a palindrome (reads the same forwards and backwards), e.g., "racecar" → true, "hello" → false.

::::solution[Solution]
```cpp
string s = "racecar";
bool isPalin = true;
int len = s.length();
for (int i = 0; i < len / 2; i++) {
    if (s[i] != s[len - 1 - i]) { isPalin = false; break; }
}
cout << boolalpha << isPalin;  // true
```

We only need to check the first half against the mirror positions. `len/2` with integer division naturally handles both even and odd length strings.
::::
:::

## 4 · Nested Loops (§5.7)

:::callout-intuition[Intuition]
Put a loop inside a loop and the inner one runs completely for each iteration of the outer one. If the outer runs M times and the inner runs N times, the total iterations is M × N. Think rows × columns, like filling a grid.
:::

```cpp
// 3 rows × 4 cols = 12 total iterations:
for (int row = 1; row <= 3; row++) {
    for (int col = 1; col <= 4; col++) {
        cout << "(" << row << "," << col << ") ";
    }
    cout << "\n";
}
// (1,1) (1,2) (1,3) (1,4)
// (2,1) (2,2) (2,3) (2,4)
// (3,1) (3,2) (3,3) (3,4)
```

:::example[Example 5.6 — Draw a right triangle of stars]
Print a right triangle pattern with 5 rows: row 1 has 1 star, row 2 has 2, …, row 5 has 5.

::::answer[Answer]

::::

```cpp
int rows = 5;
for (int r = 1; r <= rows; r++) {
    for (int s = 1; s <= r; s++) {
        cout << "* ";
    }
    cout << "\n";
}
```

```
*
* *
* * *
* * * *
* * * * *
```

Key insight: the inner loop runs `r` times (where `r` is the current row). As the outer loop increments `r`, the inner loop runs one more time per row.
:::

:::example[Example 5.7 — Check all pairs (brute-force Two Sum)]
Given an array of integers, find all pairs that sum to a target value using nested loops. (This O(n²) approach directly connects to LeetCode #1.)

::::answer[Answer]

::::

```cpp
int nums[] = {2, 7, 11, 15};
int target  = 9;
int n = 4;

for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {   // j starts at i+1 to avoid duplicates
        if (nums[i] + nums[j] == target) {
            cout << "Indices: " << i << ", " << j << endl;  // 0, 1
        }
    }
}
```

Why does `j` start at `i + 1`? Starting at 0 would count every pair twice (once as (i,j) and once as (j,i)) and also check an element with itself.
:::

### Practice — Nested Loops

:::problem[5.11easy]{difficulty="easy"}
How many total times does the inner body execute?

`for (int i=1; i<=4; i++) for (int j=1; j<=i; j++) { body; }`

::::solution[Solution]
i=1: inner runs 1×. i=2: 2×. i=3: 3×. i=4: 4×. Total: 1+2+3+4 = **10 times**.
::::
:::

:::problem[5.12standard]{difficulty="standard"}
Print a 5×5 checkerboard pattern using '\*' and ' ' (space), where (row+col) even → '\*', otherwise ' '.

::::solution[Solution]
```cpp
for (int r = 0; r < 5; r++) {
    for (int c = 0; c < 5; c++) {
        cout << ((r + c) % 2 == 0 ? '*' : ' ');
    }
    cout << "\n";
}
```

```
* * * * *
 * * * *
* * * * *
 * * * *
* * * * *
```
::::
:::

:::problem[5.13challenge]{difficulty="challenge"}
Print all pairs of integers (i, j) where `1 ≤ i ≤ j ≤ 4` and `i + j` is even. How many such pairs are there?

::::solution[Solution]
```cpp
int count = 0;
for (int i = 1; i <= 4; i++) {
    for (int j = i; j <= 4; j++) {
        if ((i + j) % 2 == 0) {
            cout << "(" << i << "," << j << ") ";
            count++;
        }
    }
}
cout << "\nCount: " << count;
// (1,1)(1,3)(2,2)(2,4)(3,3)(4,4)  →  6 pairs
```

Sum is even when both i and j are even, or both are odd.
::::
:::

## 5 · Incremental Development (§5.8)

:::callout-intuition[Intuition]
Don't write the whole loop at once and hope it works. Build it in steps: start with the loop skeleton that runs but does nothing, then add one piece of logic at a time, testing after each addition. This is how experienced programmers work — it makes bugs easy to isolate because you know exactly what changed between the last working version and the broken one.
:::

**The four-step method for building a loop:**

1. **Skeleton** — write the loop that iterates correctly (right start, condition, update) but prints only the loop variable. Verify the iteration count.
2. **Core logic** — add the main computation inside the body. Test with a small input where you know the answer.
3. **Accumulator** — if you need a running total, minimum, maximum, or string, add the accumulator variable and update it each iteration.
4. **Edge cases** — test with n=0, n=1, negative values, empty string, etc.

:::example[Example 5.8 — Building a "find minimum" loop incrementally]
```cpp
// Step 1: skeleton — does the loop iterate correctly?
for (int i = 0; i < 5; i++) cout << i << " ";  // 0 1 2 3 4 ✓

// Step 2: add an array to iterate over
int arr[] = {9, 3, 7, 1, 5};
for (int i = 0; i < 5; i++) cout << arr[i] << " ";  // 9 3 7 1 5 ✓

// Step 3: add the min accumulator
int minVal = arr[0];   // start with first element
for (int i = 1; i < 5; i++) {          // start at 1 (already have arr[0])
    if (arr[i] < minVal) minVal = arr[i];
}
cout << "Min: " << minVal;  // Min: 1 ✓

// Step 4: edge case — what if array has 1 element?
// Works fine: loop body never runs, minVal = arr[0] returned correctly.
```
:::

## 6 · break and continue (§5.9)

:::callout-intuition[Intuition]
`break` is an emergency exit — it immediately leaves the loop entirely. `continue` is a skip — it abandons the rest of the current iteration and jumps straight to the next one. Both are useful but can make loops harder to read if overused; prefer a clear condition in the loop header when possible.
:::

### `break` — Exit the Loop Early

```cpp
// Search for first negative number:
int nums[] = {5, 3, 8, -2, 7, -1};
int foundAt = -1;
for (int i = 0; i < 6; i++) {
    if (nums[i] < 0) {
        foundAt = i;
        break;    // stop at FIRST negative, don't continue
    }
}
cout << "First negative at index: " << foundAt;  // 3
```

`break` only exits the *innermost* loop. In nested loops, you need a flag or `goto` (rare) to break out of multiple levels:

```cpp
bool found = false;
for (int i = 0; i < rows && !found; i++) {
    for (int j = 0; j < cols; j++) {
        if (grid[i][j] == target) {
            cout << "Found at (" << i << "," << j << ")\n";
            found = true;
            break;          // exits inner loop
        }
    }
}   // outer loop also exits because of !found condition
```

### `continue` — Skip to Next Iteration

```cpp
// Print only odd numbers from 1–10:
for (int i = 1; i <= 10; i++) {
    if (i % 2 == 0) continue;   // skip even numbers
    cout << i << " ";
}
// Output: 1 3 5 7 9

// Skip invalid input in a file:
while (getline(inFile, line)) {
    if (line.empty()) continue;      // skip blank lines
    if (line[0] == '#') continue;    // skip comment lines
    // process valid line...
}
```

### Practice — break and continue

:::problem[5.14easy]{difficulty="easy"}
What does this print?

`for (int i=1; i<=6; i++) { if (i==4) break; cout << i << " "; }`

::::solution[Solution]
**1 2 3**. When i reaches 4, `break` exits the loop immediately — 4, 5, 6 are never printed.
::::
:::

:::problem[5.15easy]{difficulty="easy"}
What does this print?

`for (int i=1; i<=6; i++) { if (i==4) continue; cout << i << " "; }`

::::solution[Solution]
**1 2 3 5 6**. When i=4, `continue` skips the `cout` and jumps to the update (`i++`), then checks the condition again. 4 is the only value skipped.
::::
:::

:::problem[5.16standard]{difficulty="standard"}
Write a loop that reads integers from the user until they enter 0, but skips (ignores) any negative values and only sums the positive ones.

::::solution[Solution]
```cpp
int n, sum = 0;
while (true) {
    cin >> n;
    if (n == 0) break;
    if (n < 0) continue;   // skip negatives
    sum += n;
}
cout << "Sum of positives: " << sum << endl;
```
::::
:::

## 7 · Variable Scope (§5.10)

:::callout-intuition[Intuition]
A variable's **scope** is the region of code where it exists and can be used. In C++, scope is defined by curly braces `{ }`. A variable declared inside a pair of braces dies when the closing brace is reached. This matters most for loop variables.
:::

```cpp
int x = 10;          // outer scope

{
    int y = 20;      // inner scope
    cout << x;       // OK — x is visible here
    cout << y;       // OK — y is visible here
}
// cout << y;        // ERROR — y is out of scope

// Loop variable scope:
for (int i = 0; i < 3; i++) {
    // i exists here
}
// cout << i;        // ERROR — i died at the closing }

// You can declare i again in a new loop:
for (int i = 10; i > 0; i--) { ... }   // separate i, no conflict
```

#### Scope and Shadowing

```cpp
int count = 0;   // outer count

for (int i = 0; i < 3; i++) {
    int count = i * 2;   // SHADOWS outer count — separate variable!
    cout << count << " ";  // prints 0 2 4 (inner count)
}
cout << count;    // prints 0 (outer count, unchanged!)
```

:::callout-warning[Avoid Shadowing]
Declaring a variable inside a loop that has the same name as an outer variable silently shadows it — the outer variable is unchanged, which can cause logic bugs. Most compilers warn about this with `-Wshadow`. Best practice: use distinct names.
:::

## 8 · Enumerations (§5.11)

:::callout-intuition[Intuition]
Sometimes a variable should only hold one of a fixed set of named values: a direction (NORTH/SOUTH/EAST/WEST), a day of the week, a game state (PLAYING/PAUSED/GAME\_OVER). Storing these as magic integers like 0, 1, 2 works but is unreadable. An `enum` gives those integers meaningful names.
:::

### C-style enum

```cpp
enum Direction { NORTH, SOUTH, EAST, WEST };
// NORTH=0, SOUTH=1, EAST=2, WEST=3 (automatically assigned)

Direction d = NORTH;
if (d == NORTH) cout << "Heading north" << endl;

// Custom values:
enum HttpStatus { OK=200, NOT_FOUND=404, SERVER_ERROR=500 };
int code = OK;   // 200
```

### enum class (C++11) — Strongly Typed

`enum class` is the modern, safer version. Values are scoped to the enum name and won't accidentally convert to integers:

```cpp
enum class Color { RED, GREEN, BLUE };
enum class Fruit { APPLE, BANANA, CHERRY };

Color c = Color::RED;
// Fruit f = Color::RED;    // ERROR — type-safe, prevents mixing enums
// int n = Color::RED;      // ERROR — no implicit int conversion

// Use in switch:
switch (c) {
    case Color::RED:   cout << "Red";   break;
    case Color::GREEN: cout << "Green"; break;
    case Color::BLUE:  cout << "Blue";  break;
}

// To get the underlying int (rarely needed):
int val = static_cast(Color::GREEN);  // 1
```

:::callout-key[When to Use enum]
Whenever a variable should hold one of a fixed, named set of values and the set is known at compile time. `enum class` is preferred in modern C++ because it prevents accidental integer conversions and name collisions. Use plain `enum` only if you need the implicit integer conversion (e.g., loop over enum values).
:::

## 9 · Full Worked Examples (§5.12–§5.13)

:::example[Example 5.9 — §5.12 Salary Calculation with Loops]
Read weekly hours worked for 4 weeks. Compute total regular pay (40 hrs max/week at $18/hr) and overtime pay (over 40 hrs at 1.5×). Print a weekly breakdown and grand total.

```cpp
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const double RATE   = 18.0;
    const int    REG_HRS = 40;
    const int    WEEKS   = 4;

    double totalPay = 0.0;
    cout << fixed << setprecision(2);

    for (int week = 1; week <= WEEKS; week++) {
        int hours;
        cout << "Week " << week << " hours worked: ";
        cin >> hours;

        double regPay = min(hours, REG_HRS) * RATE;
        int otHours   = max(0, hours - REG_HRS);
        double otPay  = otHours * RATE * 1.5;
        double weekPay = regPay + otPay;
        totalPay += weekPay;

        cout << "  Week " << week << " pay: $" << weekPay << "\n";
    }
    cout << "  Total 4-week pay: $" << totalPay << "\n";
    return 0;
}
// Sample run (hours: 40, 45, 38, 50):
//   Week 1 pay:  $720.00
//   Week 2 pay:  $855.00  (40*18 + 5*18*1.5)
//   Week 3 pay:  $684.00
//   Week 4 pay:  $990.00  (40*18 + 10*18*1.5)
//   Total: $3249.00
```

`min()` and `max()` from `<algorithm>` (or available in many compilers via `<iostream>`) return the smaller/larger of two values.
:::

:::example[Example 5.10 — §5.13 Domain Name Validation with Loops]
Validate a domain name: must contain exactly one dot, consist only of alphanumeric characters and hyphens (plus the dot), not start or end with a hyphen, and have at least one character on each side of the dot.

```cpp
#include <iostream>
#include <cctype>
#include <string>
using namespace std;

bool isValidDomain(const string& domain) {
    int dotCount = 0, dotPos = -1;

    for (int i = 0; i < (int)domain.length(); i++) {
        char c = domain[i];
        if (c == '.') {
            dotCount++;
            dotPos = i;
        } else if (!isalnum(c) && c != '-') {
            return false;   // invalid character
        }
    }

    if (dotCount != 1)           return false;   // must have exactly one dot
    if (dotPos == 0)             return false;   // nothing before dot
    if (dotPos == (int)domain.length() - 1) return false; // nothing after dot
    if (domain[0] == '-')        return false;   // can't start with hyphen
    if (domain.back() == '-')    return false;   // can't end with hyphen

    return true;
}

int main() {
    cout << boolalpha;
    cout << isValidDomain("google.com")   << "\n";  // true
    cout << isValidDomain("-bad.com")     << "\n";  // false
    cout << isValidDomain("no-dot")       << "\n";  // false
    cout << isValidDomain("two..dots")    << "\n";  // false
    cout << isValidDomain("valid-name.io") << "\n"; // true
    return 0;
}
```
:::

:::summary
## Chapter 5 Summary

| Concept | Key Syntax / Rule |
| --- | --- |
| while loop | Initialize before, update inside body; runs while condition is true |
| do-while | Body always runs at least once; condition checked after |
| for loop | `for (init; condition; update)` — all three on one line |
| Range-based for | `for (char c : s)` — iterate every element; use `&` to modify |
| Off-by-one | `i < n` runs n times (0..n-1); `i <= n` runs n+1 times (0..n) |
| String loops | Cast `s.length()` to `int` when comparing with signed index |
| Nested loops | Inner loop runs fully per outer iteration; total = M × N iterations |
| break | Exits the innermost loop immediately |
| continue | Skips rest of current iteration; goes to next |
| Scope | Variables live inside their `{ }` block only; loop var dies at `}` |
| enum class | `enum class Color { RED, GREEN, BLUE };` — type-safe, scoped values |
:::

## Mixed Practice

:::problem[M.1easy]{difficulty="easy"}
Write a for loop that prints the squares of integers from 1 to 10: `1 4 9 16 25 36 49 64 81 100`.

::::solution[Solution]
```cpp
for (int i = 1; i <= 10; i++) cout << i * i << " ";
```
::::
:::

:::problem[M.2easy]{difficulty="easy"}
What is the output?

`int i = 10; while (i > 0) { cout << i << " "; i -= 3; }`

::::solution[Solution]
**10 7 4 1**. i goes 10→7→4→1→-2. Loop exits when i=-2 (not > 0).
::::
:::

:::problem[M.3standard]{difficulty="standard"}
Write a program that reads integers until 0 is entered, then prints: count of positive numbers, count of negative numbers, and the overall sum.

::::solution[Solution]
```cpp
int n, posCount=0, negCount=0, sum=0;
cin >> n;
while (n != 0) {
    if (n > 0) posCount++;
    else       negCount++;
    sum += n;
    cin >> n;
}
cout << "Pos: " << posCount << ", Neg: " << negCount << ", Sum: " << sum;
```
::::
:::

:::problem[M.4standard]{difficulty="standard"}
Write a loop that finds the first index where a string contains two identical consecutive characters (e.g., "abbcde" → index 1). Print -1 if none found.

::::solution[Solution]
```cpp
string s = "abbcde";
int found = -1;
for (int i = 0; i < (int)s.length() - 1; i++) {
    if (s[i] == s[i+1]) { found = i; break; }
}
cout << found;  // 1
```
::::
:::

:::problem[M.5challenge]{difficulty="challenge"}
Using nested loops, print all Pythagorean triples (a, b, c) where a ≤ b ≤ c ≤ 20 and a² + b² = c². (A Pythagorean triple satisfies the Pythagorean theorem.)

::::solution[Solution]
```cpp
for (int a = 1; a <= 20; a++) {
    for (int b = a; b <= 20; b++) {    // b >= a to avoid duplicates
        for (int c = b; c <= 20; c++) {
            if (a*a + b*b == c*c)
                cout << "(" << a << "," << b << "," << c << ") ";
        }
    }
}
// (3,4,5) (5,12,13) (6,8,10) (8,15,17) (9,12,15) (12,16,20)
```
::::
:::

:::problem[M.6challenge]{difficulty="challenge"}
Define an `enum class Season { SPRING, SUMMER, FALL, WINTER }`. Write a switch that prints the months belonging to each season, and a loop that iterates all four seasons printing their name. (Hint: loop from 0 to 3, cast int to Season.)

::::solution[Solution]
```cpp
enum class Season { SPRING, SUMMER, FALL, WINTER };

auto seasonName = [](Season s) -> string {
    switch(s) {
        case Season::SPRING: return "Spring (Mar-May)";
        case Season::SUMMER: return "Summer (Jun-Aug)";
        case Season::FALL:   return "Fall (Sep-Nov)";
        case Season::WINTER: return "Winter (Dec-Feb)";
    }
    return "";
};

for (int i = 0; i < 4; i++) {
    cout << seasonName(static_cast(i)) << "\n";
}
```
::::
:::

## LeetCode Practice

:::callout-tip[LeetCode Problems for Chapter 5]
These problems are all solved cleanly with loops — most have a loop as the core logic. Solve in C++; pay attention to your loop bounds and when to use `break`.

| # | Problem | Difficulty | Why it fits |
| --- | --- | --- | --- |
| [#202](https://leetcode.com/problems/happy-number/) | Happy Number | Easy | Loop until a condition is met (either reaches 1 or cycles). Directly uses digit extraction from Ch 2 inside a while loop — a perfect synthesis of Chapters 2 and 5. |
| [#412](https://leetcode.com/problems/fizz-buzz/) | Fizz Buzz | Easy | A for loop from 1 to n with branching inside — combine Ch 4 conditions with a Ch 5 loop. Simple but important to get right. |
| [#1](https://leetcode.com/problems/two-sum/) | Two Sum | Easy | The O(n²) brute-force solution uses nested loops (Example 5.7 in this chapter). Try it now — we'll revisit the O(n) hash map solution in Ch 16. |

**Tip for #202 (Happy Number):** The digit-sum loop is `while (n != 0) { sum += (n%10)*(n%10); n /= 10; }` — identical to the digit-extraction pattern from Ch 2. The outer loop runs until the sum equals 1 (happy) or you detect a cycle (use a `set` to track seen values, or use the fast/slow pointer trick from Ch 8 later).
:::
