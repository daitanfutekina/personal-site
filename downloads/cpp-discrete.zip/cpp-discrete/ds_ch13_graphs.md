---
title: "DS–13: Graphs"
source: "ds_ch13_graphs.html"
---

CSE 2813

# DS–13: Graphs

§13.1 – §13.9

:::callout-tip
What You'll Learn

— Graphs are the mathematical backbone of social networks, routing algorithms, compilers, dependency resolution, and circuit design. This chapter builds the formal theory: structural equivalence (isomorphism), path terminology, connectivity, Euler's theorem, Hamiltonian paths, planarity, and coloring. Everything here shows up in Honors DSA.
:::

## §13.1 Introduction to Graphs

:::callout-intuition
A graph is the most general structure for modeling pairwise relationships. Vertices are objects; edges are connections. By varying the rules on edges (directed? weighted? multiple allowed?) you get the right model for any application.
:::

:::definition[Definition 13.1 — Graph]
Graph

A **simple graph** $G = (V, E)$ consists of a nonempty set $V$ of **vertices** and a set $E$ of **edges**, where each edge is an unordered pair $\{u,v\}$ of distinct vertices ($u \neq v$, no self-loops, no multiple edges).

A **multigraph** allows multiple edges between the same pair of vertices. A **pseudograph** also allows self-loops.

A **directed graph (digraph)** has ordered pairs $(u,v)$ as edges; $u$ is the *tail* (source) and $v$ is the *head* (target). We write $u \to v$.
:::

:::definition[Definition 13.2 — Degree]
Degree of a Vertex

The **degree** $\deg(v)$ of vertex $v$ in a simple graph is the number of edges incident to $v$. In a digraph, $\deg^-(v)$ is the **in-degree** (edges into $v$) and $\deg^+(v)$ is the **out-degree** (edges out of $v$).
:::

:::theorem[Theorem 13.1 — Handshaking Lemma]
Handshaking Lemma

For any graph $G = (V,E)$:

$$
\sum_{v \in V} \deg(v) = 2|E|
$$

*Proof:* Each edge $\{u,v\}$ contributes 1 to $\deg(u)$ and 1 to $\deg(v)$, so it contributes 2 to the total sum. □

**Corollary:** Every graph has an even number of odd-degree vertices.
:::

Example 13.1 — Degree Sequence

A graph has 6 vertices with degree sequence $(1,2,2,3,3,3)$. How many edges does it have?

:::answer[Answer]
7 edges.
:::

:::answer
Work

By the handshaking lemma: $\sum \deg = 1+2+2+3+3+3 = 14 = 2|E|$, so $|E| = 7$.
:::

Example 13.2 — Special Graph Families

Define $K_n$, $C_n$, $K_{m,n}$, and $Q_n$.

:::answer[Definitions]

:::

:::answer
Key Families

**$K_n$** (complete graph): $n$ vertices, every pair connected. $|E| = \binom{n}{2}$. Every vertex has degree $n-1$.

**$C_n$** (cycle): $n$ vertices in a ring; $|E| = n$; every vertex has degree 2.

**$K_{m,n}$** (complete bipartite): two groups of $m$ and $n$ vertices; every vertex in one group connects to every vertex in the other; $|E| = mn$.

**$Q_n$** ($n$-cube): vertices are $n$-bit strings; edge between strings differing in exactly 1 bit; $|V| = 2^n$, $|E| = n \cdot 2^{n-1}$, every vertex has degree $n$.
:::

## §13.2 Graph Representations

:::callout-intuition
The same abstract graph can be stored in memory different ways. The choice matters enormously for algorithm efficiency.
:::

### Adjacency Matrix

For a graph with $n$ vertices labelled $1,\ldots,n$, the **adjacency matrix** $A$ is an $n \times n$ matrix where $A[i][j] = 1$ if edge $\{i,j\}$ exists (0 otherwise). For digraphs, $A[i][j]=1$ iff edge $(i \to j)$ exists.

- Space: $O(n^2)$ — good for dense graphs
- Edge lookup: $O(1)$
- Enumerating neighbours of $v$: $O(n)$ — scan entire row
- Symmetric for undirected graphs: $A[i][j] = A[j][i]$

### Adjacency List

Store a list (or set) of neighbours for each vertex. Typically an array of length $n$, where entry $v$ holds a list of vertices adjacent to $v$.

- Space: $O(n + m)$ where $m = |E|$ — efficient for sparse graphs
- Edge lookup: $O(\deg(v))$ — scan the list
- Enumerating neighbours of $v$: $O(\deg(v))$ — optimal

Example 13.3 — Both Representations

Draw the adjacency matrix and adjacency list for the graph $G$ with $V = \{1,2,3,4\}$ and $E = \{\{1,2\},\{1,3\},\{2,4\},\{3,4\}\}$.

:::answer[Answer]

:::

:::answer
Adjacency Matrix

Rows/columns labelled 1–4:

|  | 1 | 2 | 3 | 4 |
| --- | --- | --- | --- | --- |
| **1** | 0 | 1 | 1 | 0 |
| **2** | 1 | 0 | 0 | 1 |
| **3** | 1 | 0 | 0 | 1 |
| **4** | 0 | 1 | 1 | 0 |
:::

:::answer
Adjacency List

```
1: [2, 3]
2: [1, 4]
3: [1, 4]
4: [2, 3]
```

Note this is actually the cycle graph $C_4$.
:::

:::callout-pitfall
Adjacency matrix vs list tradeoff:

If your graph has $n=10^6$ vertices but only $O(n)$ edges (e.g., a road network), the adjacency matrix wastes $10^{12}$ entries. Always use the adjacency list for sparse graphs.
:::

## §13.3 Graph Isomorphism

:::callout-intuition
Two graphs are isomorphic if they are "the same graph drawn differently" — same structure, just different vertex labels. Identifying isomorphic graphs is important in chemistry (molecular structure), network analysis, and compiler optimisation.
:::

:::definition[Definition 13.3 — Graph Isomorphism]
Isomorphism

Graphs $G_1 = (V_1, E_1)$ and $G_2 = (V_2, E_2)$ are **isomorphic** (written $G_1 \cong G_2$) if there exists a bijection $f: V_1 \to V_2$ such that:

$$
\{u,v\} \in E_1 \iff \{f(u),f(v)\} \in E_2
$$

$f$ is called an **isomorphism**.
:::

### Invariants — Properties Preserved by Isomorphism

To prove two graphs are *not* isomorphic, find an invariant they differ on:

- Number of vertices $|V|$
- Number of edges $|E|$
- Degree sequence (sorted list of all vertex degrees)
- Number of connected components
- Length of shortest cycle (girth)
- Whether the graph contains $K_3$ (triangle)

:::callout-pitfall
Invariants can only

disprove

isomorphism. Two graphs sharing all known invariants may still not be isomorphic — you must find an explicit bijection to confirm it.
:::

Example 13.4 — Are These Graphs Isomorphic?

$G_1$: vertices $\{a,b,c,d\}$, edges $\{ab, bc, cd, da\}$. $G_2$: vertices $\{1,2,3,4\}$, edges $\{12, 13, 24, 34\}$. Isomorphic?

:::answer[Answer]
Yes — isomorphic. Both are $C_4$.
:::

:::answer
Work

Both have 4 vertices, 4 edges, degree sequence $(2,2,2,2)$, and a single 4-cycle. Explicit isomorphism: $f(a)=1, f(b)=2, f(c)=4, f(d)=3$. Check: $ab\to 12$ ✓, $bc\to 24$ ✓, $cd\to 43=34$ ✓, $da\to 31=13$ ✓.
:::

Example 13.5 — Proving Non-Isomorphism

$G_1$ has degree sequence $(1,2,2,3)$; $G_2$ has degree sequence $(2,2,2,2)$. Isomorphic?

:::answer[Answer]
No — different degree sequences.
:::

:::answer
Work

An isomorphism must map vertices to vertices of equal degree. Since $G_1$ has a degree-1 vertex and $G_2$ does not, no bijection preserving edges can exist.
:::

## §13.4 Walks, Trails, Circuits, Paths, and Cycles

:::callout-intuition
These terms describe different ways of "moving through" a graph. The distinctions matter because many problems (delivery routing, network protocols, maze solving) are precisely defined by which version of traversal is allowed.
:::

:::definition[Definition 13.4 — Walks and Paths]
Walk / Trail / Path / Circuit / Cycle

A **walk** of length $k$ from $v_0$ to $v_k$ is a sequence $v_0, e_1, v_1, e_2, v_2, \ldots, e_k, v_k$ of alternating vertices and edges where each $e_i = \{v_{i-1}, v_i\}$. Vertices and edges may repeat.

- A **trail**: a walk where no *edge* repeats (vertices may repeat).
- A **path**: a walk where no *vertex* repeats (and thus no edge repeats either).
- A **circuit**: a closed trail ($v_0 = v_k$, no edge repeats).
- A **cycle**: a closed path ($v_0 = v_k$, no vertex repeats except start/end, length $\geq 3$).
:::

| Name | Closed? | No repeated edges? | No repeated vertices? |
| --- | --- | --- | --- |
| Walk | No | No | No |
| Trail | No | Yes | No |
| Path | No | Yes | Yes |
| Circuit | Yes | Yes | No |
| Cycle | Yes | Yes | Yes (except endpoints) |

:::theorem[Theorem 13.2]
Walk Implies Path

If there is a walk from $u$ to $v$ in $G$, then there is a **path** from $u$ to $v$.

*Proof sketch:* If the walk repeats vertex $w$, the sub-walk between the two visits to $w$ forms a cycle; delete it. Repeat until no vertex repeats. □
:::

## §13.5 Graph Connectivity

:::definition[Definition 13.5 — Connected Graph]
Connectivity

An undirected graph is **connected** if there is a path between every pair of distinct vertices. A maximal connected subgraph is a **connected component**.

A directed graph is **strongly connected** if for every ordered pair $(u,v)$ there is a directed path from $u$ to $v$. It is **weakly connected** if the underlying undirected graph is connected.
:::

:::definition[Definition 13.6 — Cut Vertices and Bridges]
Cut Vertex / Bridge

A **cut vertex** (or articulation point) is a vertex whose removal disconnects the graph. A **bridge** is an edge whose removal disconnects the graph. These are the structural weak points of a network.
:::

:::callout-connect
Application — Network Reliability:

In a communication network, cut vertices are single points of failure. Finding all cut vertices (via DFS in $O(V+E)$) tells you which nodes need redundancy. Same for bridges: a bridge is a communication link that, if severed, partitions the network.
:::

Example 13.6 — Connectivity Analysis

A graph has vertices $\{1,2,3,4,5\}$ and edges $\{12, 23, 34, 45, 13\}$. Is it connected? Does it have a cut vertex?

:::answer[Answer]
Connected. Vertex 3 is a cut vertex.
:::

:::answer
Work

**Connected?** Path exists from any vertex to any other: e.g., $1\to 4$: $1-3-4$ or $1-2-3-4$. Yes, connected.

**Cut vertex?** Remove vertex 3 (and edges 23, 34, 13). Remaining: vertices $\{1,2,4,5\}$ with edges $\{12, 45\}$. Now $\{1,2\}$ and $\{4,5\}$ are disconnected — vertex 3 is a cut vertex.
:::

## §13.6 Euler Circuits and Trails

:::callout-intuition
Can you draw a figure without lifting your pen and without repeating any line? This is the

Königsberg Bridge Problem

, solved by Euler in 1736 — arguably the founding problem of graph theory. The answer depends entirely on vertex degrees.
:::

:::definition[Definition 13.7 — Euler Trail and Circuit]
Euler Trail / Circuit

An **Euler trail** is a trail (no repeated edges) that visits every edge of the graph. An **Euler circuit** is a closed Euler trail (starts and ends at the same vertex).
:::

:::theorem[Theorem 13.3 — Euler's Theorem]
Euler's Theorem

Let $G$ be a connected graph.

- $G$ has an **Euler circuit** $\iff$ every vertex has **even degree**.
- $G$ has an **Euler trail** (but not circuit) $\iff$ it has **exactly two odd-degree vertices** (which are the start and end of the trail).

*Proof idea (necessity for circuit):* Each time the trail passes through a vertex, it uses one entering edge and one leaving edge, consuming two edges at that vertex. So each vertex must have even degree.
:::

Example 13.7 — Königsberg Bridges

The Königsberg bridge problem: four land masses connected by 7 bridges, giving a multigraph where vertex degrees are $(3, 3, 3, 5)$. Does an Euler circuit exist? An Euler trail?

:::answer[Answer]
Neither exists.
:::

:::answer
Work

For an Euler *circuit*: need all even degrees. But all four vertices have odd degree (3,3,3,5). ✗

For an Euler *trail*: need exactly 2 odd-degree vertices. But there are 4 odd-degree vertices. ✗

Therefore it is impossible to cross every bridge exactly once.
:::

Example 13.8 — Euler Circuit Existence

Does $K_4$ (complete graph on 4 vertices) have an Euler circuit? What about $K_5$?

:::answer[Answer]
$K_4$: No. $K_5$: Yes.
:::

:::answer
Work

In $K_n$, every vertex has degree $n-1$.

$K_4$: degree $= 3$ (odd) for all 4 vertices — four odd-degree vertices — no Euler circuit or trail.

$K_5$: degree $= 4$ (even) for all 5 vertices — Euler circuit exists! ✓
:::

## §13.7 Hamiltonian Cycles and Paths

:::callout-intuition
A Hamiltonian path visits every

vertex

exactly once. Unlike Euler (every edge), this requires hitting every node — and there is no clean degree-based characterization. Determining whether a Hamiltonian cycle exists is NP-complete, making it fundamentally harder than Euler problems.
:::

:::definition[Definition 13.8 — Hamiltonian Path and Cycle]
Hamiltonian Path / Cycle

A **Hamiltonian path** is a path that visits every vertex of $G$ exactly once. A **Hamiltonian cycle** is a cycle that visits every vertex exactly once (then returns to the start).

A graph containing a Hamiltonian cycle is called a **Hamiltonian graph**.
:::

:::theorem[Theorem 13.4 — Dirac's Theorem (Sufficient Condition)]
Dirac's Theorem

If $G$ is a simple graph with $n \geq 3$ vertices and every vertex has degree $\geq n/2$, then $G$ has a Hamiltonian cycle.

*Note:* This is a *sufficient* condition only, not necessary. Many graphs with low-degree vertices still have Hamiltonian cycles.
:::

:::theorem[Theorem 13.5 — Ore's Theorem]
Ore's Theorem

If $G$ is a simple graph with $n \geq 3$ vertices and $\deg(u) + \deg(v) \geq n$ for every pair of *non-adjacent* vertices $u,v$, then $G$ has a Hamiltonian cycle.
:::

:::callout-key
Euler vs. Hamiltonian — Key Contrast

|  | Euler Circuit | Hamiltonian Cycle |
| --- | --- | --- |
| Visits | Every *edge* once | Every *vertex* once |
| Characterization | All even degrees (clean theorem) | No clean necessary+sufficient condition |
| Complexity | $O(E)$ — polynomial | NP-complete in general |
| Application | Route inspection, pen drawing | TSP, circuit board drilling |
:::

Example 13.9 — Hamiltonian Cycle in $K_n$

Does $K_4$ have a Hamiltonian cycle? If so, count the number of distinct Hamiltonian cycles.

:::answer[Answer]
Yes; there are 3 distinct Hamiltonian cycles.
:::

:::answer
Work

$K_4$ has vertices $\{1,2,3,4\}$. In $K_n$, every vertex has degree $n-1 = 3 \geq n/2 = 2$, so Dirac's theorem guarantees one exists.

One Hamiltonian cycle: $1 \to 2 \to 3 \to 4 \to 1$.

To count: fix vertex 1. Arrange the remaining 3 vertices in a cycle: $(3-1)!/2 = 2!/2 = 1$. The number of Hamiltonian cycles in $K_n$ is $(n-1)!/2$. For $n=4$: $3!/2 = 6/2 = 3$. The three distinct cycles are: $1234$, $1243$, $1324$ (treating reversals and rotations as the same).
:::

## §13.8 Planar Graphs

:::callout-intuition
A graph is planar if it can be drawn in the plane with no edges crossing. This matters in circuit board design: crossing wires require costly vias (connections between layers). Euler discovered a beautiful formula linking vertices, edges, and faces of any planar graph.
:::

:::definition[Definition 13.9 — Planar Graph]
Planar Graph

A graph is **planar** if it can be drawn in the plane such that no two edges cross. A particular drawing with no crossings is called a **planar representation**. A planar representation divides the plane into **regions** (or *faces*), including one unbounded outer face.
:::

:::theorem[Theorem 13.6 — Euler's Formula for Planar Graphs]
Euler's Formula

For any connected planar graph drawn without crossings, with $V$ vertices, $E$ edges, and $F$ faces:

$$
V - E + F = 2
$$

*Example:* A cube has $V=8, E=12, F=6$: $8 - 12 + 6 = 2$. ✓
:::

:::theorem[Theorem 13.7 — Planarity Bound]
Edge Bound for Planar Graphs

For any simple connected planar graph with $V \geq 3$ vertices:

$$
E \leq 3V - 6
$$

For graphs with no triangles (no 3-cycles): $E \leq 2V - 4$.

*Proof:* Each face is bounded by $\geq 3$ edges; each edge borders $\leq 2$ faces, so $3F \leq 2E$. Substituting into Euler's formula gives the bound. □
:::

:::theorem[Theorem 13.8 — Kuratowski's Theorem]
Kuratowski's Theorem

A graph is planar if and only if it contains no subdivision of $K_5$ (complete graph on 5 vertices) or $K_{3,3}$ (complete bipartite graph on $3+3$ vertices) as a subgraph.

A **subdivision** of a graph is obtained by inserting new vertices of degree 2 along edges. $K_5$ and $K_{3,3}$ are the two "minimal non-planar" graphs.
:::

Example 13.10 — Is $K_5$ Planar?

Use the edge bound to prove $K_5$ is not planar.

:::answer[Answer]
$K_5$ is not planar.
:::

:::answer
Work

$K_5$ has $V=5$, $E=\binom{5}{2}=10$.

The planarity bound requires $E \leq 3V - 6 = 3(5)-6 = 9$.

But $E = 10 > 9$. Contradiction — $K_5$ cannot be planar.
:::

Example 13.11 — Is $K_{3,3}$ Planar?

Show $K_{3,3}$ is not planar.

:::answer[Answer]
$K_{3,3}$ is not planar.
:::

:::answer
Work

$K_{3,3}$: $V=6$, $E=9$. The basic bound gives $E \leq 3(6)-6 = 12$, so it's not ruled out.

Use the stronger bound (no triangles, since $K_{3,3}$ is bipartite): $E \leq 2V-4 = 2(6)-4 = 8$.

But $E=9 > 8$. Contradiction — $K_{3,3}$ is not planar.
:::

## §13.9 Graph Coloring

:::callout-intuition
Graph coloring assigns colors to vertices so that no two adjacent vertices share a color. The minimum number of colors needed is the

chromatic number

. Applications: scheduling (adjacent = conflicting), register allocation in compilers (adjacent = interfering variables), and map coloring.
:::

:::definition[Definition 13.10 — Graph Coloring]
Chromatic Number

A **$k$-coloring** of $G$ is an assignment of one of $k$ colors to each vertex such that no two adjacent vertices receive the same color. The **chromatic number** $\chi(G)$ is the minimum $k$ for which a valid $k$-coloring exists.
:::

:::theorem[Theorem 13.9 — Four Color Theorem]
Four Color Theorem

Every planar graph has chromatic number at most 4: $\chi(G) \leq 4$. Equivalently, any map can be colored with at most 4 colors so that no two adjacent regions share a color. (Proved by Appel and Haken in 1976 using computer assistance.)
:::

:::theorem[Theorem 13.10 — Chromatic Number of Special Graphs]
Known Chromatic Numbers

$\chi(K_n) = n$ (each vertex must differ from all others)

$\chi(C_n) = 2$ if $n$ is even; $\chi(C_n) = 3$ if $n$ is odd

$\chi(K_{m,n}) = 2$ (bipartite graphs are 2-colorable)

A graph is bipartite $\iff$ $\chi(G) \leq 2$ $\iff$ it contains no odd cycle.
:::

Example 13.12 — Exam Scheduling

Five exams: Math (M), CS (C), Physics (P), Chemistry (Ch), English (E). Conflicts (a student takes both): M-C, M-P, C-P, C-Ch, P-E. What is the minimum number of time slots needed?

:::answer[Answer]
3 time slots.
:::

:::answer
Work

Build conflict graph: vertices = exams, edges = conflicts.

The graph contains triangle $\{M, C, P\}$ (all three conflict pairwise), so $\chi \geq 3$.

A valid 3-coloring: *slot 1* = {M, Ch, E}, *slot 2* = {C}, *slot 3* = {P}.

Check: M-C ✓ (slots 1,2), M-P ✓ (slots 1,3), C-P ✓ (slots 2,3), C-Ch ✓ (slots 2,1), P-E ✓ (slots 3,1). Valid!
:::

:::callout-connect
Register Allocation in Compilers

— When a compiler assigns variables to CPU registers, it builds an

interference graph

: two variables are adjacent if they are both "live" at the same program point (they can't share a register). Coloring this graph with $k$ colors allocates variables to $k$ registers. If $\chi > k$, some variables must be spilled to memory.
:::

:::summary
### Chapter 13 — Quick Reference

- **Handshaking:** $\sum \deg(v) = 2|E|$; always an even number of odd-degree vertices
- **Adjacency matrix:** $O(n^2)$ space, $O(1)$ edge lookup; use for dense graphs
- **Adjacency list:** $O(n+m)$ space, $O(\deg)$ neighbour scan; use for sparse graphs
- **Isomorphism:** bijection preserving edges; disprove with invariants (degree sequence, etc.)
- **Path vs trail vs walk:** path = no repeated vertices; trail = no repeated edges; walk = anything
- **Euler circuit:** exists $\iff$ connected + all vertices have even degree
- **Euler trail:** exists $\iff$ connected + exactly 2 odd-degree vertices
- **Hamiltonian cycle:** visits each vertex once; NP-complete to decide in general
- **Dirac's theorem:** $\deg(v) \geq n/2$ for all $v$ $\Rightarrow$ Hamiltonian cycle exists
- **Euler's formula (planar):** $V - E + F = 2$; implies $E \leq 3V-6$
- **Non-planar:** $K_5$ and $K_{3,3}$ (Kuratowski); use edge bounds to prove non-planarity
- **Chromatic number:** $\chi(K_n)=n$; $\chi(\text{bipartite})=2$; $\chi(\text{planar}) \leq 4$
:::

## Practice Problems

:::problem[13.1]{difficulty="easy"}
13.1

A graph has 8 vertices. Is it possible for the degree sequence to be $(1,1,2,2,3,3,4,4)$? Verify using the handshaking lemma.

::::solution[Solution]
Sum of degrees: $1+1+2+2+3+3+4+4 = 20 = 2|E|$, so $|E|=10$. The sum is even, so this is consistent with the handshaking lemma. Yes, such a graph could exist (and does).
::::
:::

:::problem[13.2]{difficulty="easy"}
13.2

Does the complete graph $K_6$ have an Euler circuit? An Euler trail? Justify using Euler's theorem.

::::solution[Solution]
In $K_6$, every vertex has degree $n-1 = 5$ (odd). So all 6 vertices are odd-degree.

Euler circuit: requires all even degrees. ✗ — no Euler circuit.

Euler trail: requires exactly 2 odd-degree vertices. Here all 6 are odd. ✗ — no Euler trail either.
::::
:::

:::problem[13.3]{difficulty="standard"}
13.3

Determine whether the following two graphs are isomorphic. $G_1$: $V=\{1,2,3,4,5\}$, $E = \{12,23,34,45,15,13\}$. $G_2$: $V=\{a,b,c,d,e\}$, $E=\{ab,bc,cd,de,ae,bd\}$. If isomorphic, give the bijection; if not, give an invariant that differs.

::::solution[Solution]
$G_1$ degree sequence: $\deg(1)=3$ (edges 12,15,13), $\deg(2)=2$ (12,23), $\deg(3)=3$ (23,34,13), $\deg(4)=2$ (34,45), $\deg(5)=2$ (45,15). Sorted: $(2,2,2,3,3)$.

$G_2$ degree sequence: $\deg(a)=2$ (ab,ae), $\deg(b)=3$ (ab,bc,bd), $\deg(c)=2$ (bc,cd), $\deg(d)=3$ (cd,de,bd), $\deg(e)=2$ (de,ae). Sorted: $(2,2,2,3,3)$.

Same degree sequences, same $|V|=5$, $|E|=6$. Both contain a 5-cycle (1-2-3-4-5 and a-b-c-d-e) with one extra chord. Map: $f(1)=a, f(2)=b, f(3)=d, f(4)=c, f(5)=e$. Check chord: $13 \to ad$? $ad \notin E_2$. Try $f(1)=b, f(2)=a, f(3)=d, f(4)=c, f(5)=e$: chord $13 \to bd$ ✓, and $5$-cycle $b\to a\to e\to c\to d\to b$ — but we need $ba,ae,ec,cd,db$. Check: $ba=ab$ ✓, $ae$ ✓, $ec=ce$? $ec \notin E_2$ (edges are ab,bc,cd,de,ae,bd). Adjust: $f(1)=b,f(2)=c,f(3)=d,f(4)=e,f(5)=a$, chord $13\to bd$ ✓, cycle $b\to c\to d\to e\to a\to b$ = $bc,cd,de,ae,ab$ ✓. Isomorphic!
::::
:::

:::problem[13.4]{difficulty="standard"}
13.4

A connected planar graph has 10 vertices and 15 edges. How many faces does its planar representation have?

::::solution[Solution]
By Euler's formula: $V - E + F = 2$.
$10 - 15 + F = 2 \implies F = 7$.
The planar representation has 7 faces (including the outer/unbounded face).
::::
:::

:::problem[13.5]{difficulty="standard"}
13.5

Find the chromatic number of $C_5$ (the 5-cycle). Give a valid coloring.

::::solution[Solution]
$C_5$ is an odd cycle, so $\chi(C_5) = 3$.

2 colors are insufficient: if you try to 2-color a 5-cycle, you'll reach a contradiction (alternating forces the last vertex to conflict).

Valid 3-coloring of vertices $1,2,3,4,5$ in a cycle: color 1 = Red, color 2 = Blue, color 3 = Red, color 4 = Blue, color 5 = Green. Check: $12$ RB ✓, $23$ BR ✓, $34$ RB ✓, $45$ BG ✓, $51$ GR ✓.
::::
:::

:::problem[13.6]{difficulty="challenge"}
13.6

Prove: in any graph, if every vertex has degree $\geq 2$, then the graph contains a cycle.

::::solution[Solution]
**Proof:** Start at any vertex $v_0$. Since $\deg(v_0) \geq 2$, move to a neighbor $v_1$. From $v_1$, since $\deg(v_1) \geq 2$, there is an edge other than $v_1v_0$ to follow; move to $v_2 \neq v_0$. Continue this process: at each step, since the current vertex has degree $\geq 2$, there is always an edge to a new vertex other than where we came from.

Since $G$ is finite, we must eventually revisit a vertex. Suppose we reach $v_k = v_j$ for some $j < k$. Then the trail $v_j, v_{j+1}, \ldots, v_k = v_j$ forms a closed trail. Removing any repeated vertices from this closed trail yields a cycle. □
::::
:::

:::problem[13.7]{difficulty="challenge"}
13.7

Show that $K_{3,3}$ is not planar using Euler's formula and the face-edge inequality, without appealing to Kuratowski's theorem.

::::solution[Solution]
$K_{3,3}$: $V=6$, $E=9$. Suppose it is planar. By Euler's formula: $F = 2 - V + E = 2 - 6 + 9 = 5$.

$K_{3,3}$ is bipartite, so it contains no odd cycles, meaning every cycle has length $\geq 4$. Therefore every face is bounded by at least 4 edges.

Each edge borders at most 2 faces, so $4F \leq 2E$, giving $F \leq E/2 = 9/2 = 4.5$, i.e., $F \leq 4$.

But we derived $F=5$. Contradiction — $K_{3,3}$ is not planar. □
::::
:::

## LeetCode Practice

| # | Problem | Difficulty | Connection |
| --- | --- | --- | --- |
| [1971](https://leetcode.com/problems/find-if-path-exists-in-graph/) | Find if Path Exists in Graph | Easy | Graph connectivity (§13.5) — BFS/DFS to check if path exists |
| [997](https://leetcode.com/problems/find-the-town-judge/) | Find the Town Judge | Easy | In-degree and out-degree of directed graph (§13.1) |
| [463](https://leetcode.com/problems/island-perimeter/) | Island Perimeter | Easy | Graph edges on a grid — count non-adjacent cell borders |
| [200](https://leetcode.com/problems/number-of-islands/) | Number of Islands | Medium | Connected components (§13.5) — count via DFS/BFS |
| [133](https://leetcode.com/problems/clone-graph/) | Clone Graph | Medium | Graph traversal with adjacency list representation (§13.2) |
| [207](https://leetcode.com/problems/course-schedule/) | Course Schedule | Medium | Cycle detection in directed graph — Hamiltonian / DAG (§13.7); topological sort requires no cycle |
| [695](https://leetcode.com/problems/max-area-of-island/) | Max Area of Island | Medium | Connected components with size — BFS/DFS on graph (§13.5) |
