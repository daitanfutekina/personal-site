---
title: "Chapter 15: Exceptions"
crumb: "C++ · Chapter 15"
meta:
  - "Est. study time: ~2 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 15: Exceptions

## Overview

Every function you have written so far has had a happy path and, usually, an unspoken
assumption: that the file opens, that the string really is a number, that the index is in
range. This chapter is about what to do when the assumption fails.

The obvious approach is to return a special value — $-1$ for "not found", `false` for
"didn't work", a null pointer for "couldn't allocate". That works, and it has one fatal
weakness: **the caller can ignore it**, and most callers do. Nothing in the language forces
anyone to look at a return value. A function that returns $-1$ into code that never checks
has not reported an error; it has silently produced a wrong number that will surface three
functions later as something inexplicable.

Exceptions fix exactly that. Throwing an exception does not return a value the caller may
discard — it abandons the current path entirely and searches upward through the call stack
for someone willing to handle it. If nobody is, the program terminates. That sounds harsh,
and it is the point: a crash with a message is enormously better than corrupted data that
looks fine.

The cost is a second control-flow mechanism to keep in your head, and a set of rules about
how objects are destroyed on the way out. Both are covered here.

:::callout-key[What you'll learn]
- `try`/`catch`/`throw`, and how control moves between them
- The standard exception hierarchy, and which class to reach for
- Stack unwinding, and why RAII makes it safe
- Handling file errors, which do *not* throw by default
- Writing your own exception classes that carry useful context
:::

:::callout-tip[Prerequisites]
Classes and inheritance from Chapters 13 and 14 — a custom exception is a derived class, and
catching by base-class reference is polymorphism doing its job. File streams from Chapter 15's
companion material on `<fstream>`.
:::

## §15.1 — Handling Exceptions

:::callout-intuition[Two paths through one function]
Read this function and count how much of it is about the actual work:

```cpp
struct Config { int port; };
bool parseLine(const string& line, Config& out);

bool loadConfig(const string& path, Config& out) {
    ifstream f(path);
    if (!f) return false;
    string line;
    if (!getline(f, line)) return false;
    if (!parseLine(line, out)) return false;
    return true;
}
```

Four of the six lines are error plumbing, the real work is buried, and every caller now has to
remember to check the `bool`. Worse, the function can only say *that* something failed, never
*what* — all four failures collapse into the same `false`.

Exceptions let you write the happy path as though nothing goes wrong, and describe the
failures separately. The work stays readable, each failure keeps its own identity, and the
caller cannot quietly skip the check.
:::

An **exception** is an object thrown when something goes wrong — division by zero, bad input,
a missing file. The `try`/`catch` mechanism separates the happy path from the error handling.

The control flow is worth fixing in your mind before any code, because it is unlike anything
else in the language:

```
try block executes normally...
  ↓ error detected — throw ExceptionObject
  ↓ control jumps immediately out of the try block
catch (ExceptionType& e) { ... handle it ... }
  ↓ program continues after the catch
remaining code runs normally
```

The word **immediately** is the one to notice. A `throw` is not a return: the rest of the
`try` block does not run, and neither does the rest of the function that threw, nor its
caller, nor its caller's caller, until a matching `catch` is found. Nothing partially
completes.

```cpp
#include <iostream>
#include <stdexcept>    // standard exception classes
using namespace std;

int divide(int a, int b) {
    if (b == 0)
        throw runtime_error("Division by zero");   // throw!
    return a / b;
}

int main() {
    try {
        cout << divide(10, 2) << "\n";   // 5 — no exception
        cout << divide(7, 0) << "\n";    // throws!
        cout << "This line never runs\n";
    }
    catch (const runtime_error& e) {
        cerr << "Error: " << e.what() << "\n";
    }
    cout << "Program continues after catch\n";
}
```

Trace what this prints, because two of the lines are traps.

The first call prints `5` normally. The second call throws, so nothing is printed for it —
not even a partial line, because the `<<` never receives a value. The line marked "never
runs" is inside the same `try` block, so it is skipped: once an exception is in flight, the
remainder of the block is abandoned.

Control lands in the `catch`, which prints the error. Then — and this is the part people
misread — execution continues *after* the whole try/catch, so the final line does print. The
program does not die. Output:

```
5
Error: Division by zero
Program continues after catch
```

Note also `cerr` rather than `cout` for the error. `cerr` is unbuffered and goes to the
standard error stream, so the message appears immediately and survives a redirect of normal
output to a file.

### Multiple catch blocks

One `try` can be followed by several `catch` clauses, and the first one whose type matches
wins.

```cpp
try {
    int x = stoi("abc");     // throws invalid_argument
    int y = stoi("99999999999999");  // throws out_of_range
}
catch (const invalid_argument& e) {
    cerr << "Bad format: " << e.what() << "\n";
}
catch (const out_of_range& e) {
    cerr << "Overflow: " << e.what() << "\n";
}
catch (const exception& e) {       // catch-all for std exceptions
    cerr << "Unknown error: " << e.what() << "\n";
}
catch (...) {                       // catch absolutely anything
    cerr << "Non-standard exception\n";
}
```

**Order matters, and it is not negotiable.** Matching is *first-fit*, not best-fit — the
compiler does not search for the closest type. Because `invalid_argument` derives from
`exception`, putting `catch (const exception&)` first would swallow every exception in the
list and the specific handlers below it would be unreachable. The rule: **most derived first,
most general last.**

Only one `catch` runs. In the block above, `stoi("abc")` throws on the first line, so the
second `stoi` never executes at all — the `out_of_range` handler is not reached by this
particular run, even though the code that would trigger it is right there.

The final `catch (...)` — three literal dots, the *ellipsis handler* — matches anything at
all, including exceptions of types that do not derive from `exception` and are therefore
outside every other clause. It is a backstop. Its weakness is that it gives you no object, so
there is nothing to call `what()` on; you know something went wrong and nothing more.

:::callout-key[The standard exception hierarchy]
From `<stdexcept>`:

```
exception
├─ logic_error       (programmer errors — detectable before runtime)
│   ├─ invalid_argument
│   ├─ length_error
│   ├─ out_of_range
│   └─ domain_error
└─ runtime_error     (errors that occur during execution)
    ├─ overflow_error
    ├─ underflow_error
    └─ range_error
```

The split at the top is a genuine design distinction and worth respecting when you choose
what to throw.

A **`logic_error`** means the program is wrong — a precondition was violated, and in principle
the bug could have been caught by reading the code. Passing a negative size to a constructor
is a `logic_error`; the fix belongs in the calling code.

A **`runtime_error`** means the program is right but the world did not cooperate — a file went
missing, a network dropped, a number overflowed. No amount of code review prevents these; they
must be handled.

Always **catch by `const` reference**, `catch (const exception& e)`. Catching by value copies
the exception, and worse, *slices* it: a `ValidationError` caught by value as an `exception`
loses everything that made it a `ValidationError`, including its overridden `what()`. Catching
by reference keeps the object whole and the polymorphism intact.
:::

:::callout-intuition[Why not just return an error code?]
Returning $-1$ to signal failure works for small programs, and it has three problems that
grow with the program.

**It can be ignored.** `divide(7, 0);` as a statement compiles happily and discards the
sentinel. No compiler warning, no runtime complaint. An exception cannot be discarded — if
nobody catches it, the program stops.

**The sentinel may be a legitimate answer.** If a function returns $-1$ for "not found", what
does it return when the correct answer *is* $-1$? Every sentinel scheme eventually collides
with real data, and the workarounds — out-parameters, a separate status code, a global
`errno` — are exactly the plumbing exceptions remove.

**Errors must be checked at every level.** With return codes, each function in the chain has to
test and re-report. With exceptions, the intermediate functions say nothing at all and the
error travels straight to whoever can act on it.

The trade is that exceptions are relatively slow *when thrown* — costly enough that they are
wrong for conditions that happen routinely. "End of file reached" is not an error; it is the
expected end of a loop. Reserve exceptions for the genuinely exceptional.
:::

## §15.2 — Throwing Exceptions

You throw with the `throw` keyword followed by an exception object. Any type can be thrown —
`int`, `string`, your own `struct` — but throwing a standard exception type is strongly
preferred, for a reason worth stating: a caller can only write `catch (const exception&)` and
expect it to work if everyone throws things that derive from `exception`. Throwing an `int`
means every handler in the program needs a special case for you.

```cpp
#include <stdexcept>
#include <string>
#include <cmath>
using namespace std;

class Vector {
    double* data;
    int sz;
public:
    Vector(int n) : sz(n) {
        if (n <= 0)
            throw invalid_argument("Vector size must be positive");
        data = new double[n]();
    }

    double& at(int i) {
        if (i < 0 || i >= sz)
            throw out_of_range("Index " + to_string(i) +
                               " out of range [0," + to_string(sz) + ")");
        return data[i];
    }

    ~Vector() { delete[] data; }
};

double sqrtChecked(double x) {
    if (x < 0)
        throw domain_error("sqrt of negative number: " + to_string(x));
    return sqrt(x);
}

int main() {
    try {
        Vector v(5);
        v.at(0) = 3.14;
        cout << v.at(0) << "\n";     // 3.14
        cout << v.at(10) << "\n";    // throws out_of_range
    }
    catch (const out_of_range& e) {
        cerr << "Bounds error: " << e.what() << "\n";
    }

    try {
        cout << sqrtChecked(-4) << "\n";   // throws domain_error
    }
    catch (const domain_error& e) {
        cerr << "Math error: " << e.what() << "\n";
    }
}
```

Three details in this code are worth pulling out.

**The constructor throws before allocating.** The size check comes first, so if it fails, `new`
never runs and there is nothing to leak. Order matters here: throwing *after* an allocation but
before the object is fully constructed is one of the classic leaks in C++, because **the
destructor of a partially constructed object does not run**. If the check came after
`data = new double[n]()`, an exception thrown later in the constructor would abandon that
memory with no `~Vector` to reclaim it.

**The messages carry the actual values.** `"Index 10 out of range [0,5)"` tells you what went
wrong; `"bad index"` tells you only that something did. Building the message with `to_string`
costs nothing on the path where no exception is thrown, since the string is only constructed at
the moment of failure.

**Each class matches its failure.** `invalid_argument` for a bad parameter, `out_of_range` for a
bad index, `domain_error` for a mathematically undefined input. All three are `logic_error`s —
each signals a bug in the calling code rather than a hostile world. Choosing the right one lets
a caller handle bounds problems differently from domain problems without parsing message text.

### Exception propagation

```cpp
// Exceptions propagate up the call stack until caught
void c() { throw runtime_error("error in c"); }
void b() { c(); }   // doesn't catch — propagates
void a() { b(); }   // doesn't catch — propagates

int main() {
    try {
        a();        // exception propagates through b and c
    }
    catch (const runtime_error& e) {
        // caught here — stack unwinds: c, b, a destroyed in order
        cout << "Caught: " << e.what() << "\n";
    }
}
```

Notice what `a` and `b` contain: nothing about errors at all. They neither check nor forward
nor mention the failure — and yet the error still reaches `main` intact, with its message
preserved.

That is the property that makes exceptions worth the machinery. With return codes, `b` would
have to test `c`'s result and return its own failure, and `a` would have to do the same, so
every function between the error and its handler carries error-handling code for errors it
knows nothing about. Here the intermediate layers stay silent, and the exception travels from
where the problem was detected to where it can be dealt with.

:::callout-key[Stack unwinding]
As an exception propagates, C++ destroys every local object between the throw site and the
catch, in reverse order of construction. This is called **stack unwinding**, and it is what
makes exceptions survivable rather than a guaranteed leak.

The consequence is that RAII types — *Resource Acquisition Is Initialization*, meaning a class
whose destructor releases whatever its constructor acquired — are automatically exception-safe.
A `unique_ptr` frees its memory, an `ofstream` closes its file, a `lock_guard` releases its
mutex, all without a single line of cleanup code on the error path.

The mirror image is also true, and it is the reason raw `new` and `delete` are dangerous:

```cpp
void mightThrow();

void risky() {
    double* buf = new double[1000];
    mightThrow();          // if this throws...
    delete[] buf;          // ...this never runs. Leak.
}
```

The pointer is a local, so unwinding destroys the *pointer* — but a raw pointer has no
destructor to speak of, so the 1000 doubles are stranded. Replacing it with
`vector<double> buf(1000);` fixes the leak completely and removes the `delete` as well.

**The one rule that goes with unwinding: destructors must not throw.** If a destructor throws
while unwinding is already in progress, there are two exceptions in flight, and the language's
answer is to call `std::terminate` immediately.
:::

:::problem[Practice 15.2 easy]{difficulty="easy"}
**Safe division calculator.** Write `double safeDivide(double a, double b)` that throws
`invalid_argument` if `b == 0`. Write a `main` that reads pairs of numbers until EOF, computing
each quotient and catching any exceptions.

::::solution[Solution]
```cpp
double safeDivide(double a, double b) {
    if (b == 0.0)
        throw invalid_argument("Denominator cannot be zero");
    return a / b;
}
int main() {
    double a, b;
    while (cin >> a >> b) {
        try {
            cout << a << " / " << b << " = " << safeDivide(a,b) << "\n";
        } catch (const invalid_argument& e) {
            cerr << "Error: " << e.what() << "\n";
        }
    }
}
```

**The design decision worth noting is where the `try` sits.** It is *inside* the loop, wrapping
one calculation. Put it outside the loop instead and the first bad pair ends the whole program:
the exception jumps out of the `while`, and there is no way back in to process the remaining
input.

The rule generalises — **the `try` belongs at the level where recovery makes sense.** Here, one
bad pair should cost one line of output, not the run, so the handler goes around one line's
worth of work.

Note also that `b == 0.0` is an exact comparison, which is normally poor practice with
floating-point numbers. It is right here, because division by *exactly* zero is what produces
the problem. A denominator of $10^{-300}$ is not an error; it just gives a very large quotient.
::::
:::

## §15.3 — Exceptions with Files

File operations do **not** throw by default. This surprises people, and it is the single most
important fact in this section: `ifstream f("missing.txt");` on a file that does not exist
throws nothing, returns nothing, and gives you a perfectly usable object that happens to be in
a failed state. Read from it and you get nothing, silently.

So with files you are back to checking — but you can convert those checks into exceptions at
one boundary, and then use exceptions everywhere above it.

### Manual checking (most common)

```cpp
#include <fstream>
#include <stdexcept>
using namespace std;

string readFileContents(const string& filename) {
    ifstream f(filename);
    if (!f.is_open())
        throw runtime_error("Cannot open file: " + filename);

    string contents, line;
    while (getline(f, line))
        contents += line + "\n";

    if (f.bad())
        throw runtime_error("Read error on file: " + filename);

    return contents;
}

void writeFile(const string& filename, const string& content) {
    ofstream f(filename);
    if (!f)
        throw runtime_error("Cannot create file: " + filename);
    f << content;
    if (!f)
        throw runtime_error("Write error on file: " + filename);
}

int main() {
    try {
        string text = readFileContents("input.txt");
        cout << text;
        writeFile("output.txt", text);
    }
    catch (const runtime_error& e) {
        cerr << "File error: " << e.what() << "\n";
        return 1;
    }
}
```

**Why `f.bad()` and not `f.fail()` after the loop.** The `getline` loop ends when the stream
becomes false, and that happens for two quite different reasons: the file ended normally, or
something went wrong. `eofbit` means "we reached the end", which is the expected outcome and not
an error. `badbit` means the stream is genuinely broken — a disk error, a device disconnected.
Testing `bad()` distinguishes the failure from the ordinary ending. Testing `fail()` there would
report an error on every successfully read file, since `fail()` is also set at EOF.

**Note `runtime_error` rather than `logic_error`.** A missing file is not a bug in the program;
it is the world declining to cooperate. This is the distinction from §15.1 applied.

**And note `return 1` from `main`.** The exception was handled, so the program does not crash,
but it also did not do its job — so it reports failure to whatever launched it. A handler that
prints a message and then returns success has hidden the problem from every script that runs
the program.

### Enabling stream exceptions

```cpp
// Alternative: tell the stream to throw on errors
ifstream f;
f.exceptions(ifstream::failbit | ifstream::badbit);
// Now f will throw ios_base::failure on errors
try {
    f.open("data.txt");     // throws if open fails
    int x;
    f >> x;                 // throws if read fails
}
catch (const ios_base::failure& e) {
    cerr << "Stream error: " << e.what() << "\n";
}
```

:::callout-intuition[Why almost nobody uses stream exceptions]
The feature exists, and most C++ code ignores it. The reason is the `failbit` problem from
above: reaching end of file sets `eofbit`, and the read that discovered it also sets `failbit`
— so a stream configured to throw on `failbit` throws at the end of **every** file, including
files read perfectly.

You then either wrap every normal loop termination in a `catch`, which is worse than the
checking you were trying to avoid, or enable only `badbit` and go back to testing `failbit`
by hand.

Manual checking is not a failure to use a better feature. It is the idiom because it gives
fine-grained control over which conditions are errors, and with files the answer is genuinely
situational.
:::

### An exception-safe file processing pattern

```cpp
// RAII + exceptions = automatic cleanup even on error
void processFile(const string& inputFile, const string& outputFile) {
    ifstream in(inputFile);
    if (!in) throw runtime_error("Cannot open input: " + inputFile);

    ofstream out(outputFile);
    if (!out) throw runtime_error("Cannot open output: " + outputFile);

    // Even if processing throws, both streams close automatically
    // because RAII destructors run during stack unwinding
    string line;
    int lineNum = 0;
    while (getline(in, line)) {
        lineNum++;
        out << lineNum << ": " << line << "\n";
    }
    cout << "Processed " << lineNum << " lines\n";
}   // <-- in and out close here (or on exception)
```

Count the cleanup code in that function: there is none. No `close()` call, no `catch` block, no
flag tracking which streams were opened. And yet if the loop throws halfway through, both files
close correctly, because `ifstream` and `ofstream` are RAII types and unwinding runs their
destructors.

Compare what this would take with `FILE*` and `fopen`: a `catch` block, two null checks, and two
`fclose` calls duplicated on both the success and failure paths — plus the bug you get when a
later edit adds a third early return and forgets one of them.

:::problem[Practice 15.3 standard]{difficulty="standard"}
**Safe file copy.** Write `void copyFile(string src, string dst)` that copies `src` to `dst`
line by line. Throw `runtime_error` if either file cannot be opened. Also throw if the source
and destination are the same filename.

::::solution[Solution]
```cpp
void copyFile(const string& src, const string& dst) {
    if (src == dst)
        throw invalid_argument("Source and destination must differ");
    ifstream in(src);
    if (!in) throw runtime_error("Cannot open source: " + src);
    ofstream out(dst);
    if (!out) throw runtime_error("Cannot open dest: " + dst);
    string line;
    while (getline(in, line)) out << line << "\n";
    if (in.bad()) throw runtime_error("Read error on: " + src);
}
```

**Why the same-name check comes first.** Opening a file for output with `ofstream` truncates it
to zero length immediately. If `src` and `dst` name the same file and we opened the output
first, the source would be destroyed before a single line was read — the "copy" would silently
erase the file. Checking before opening anything is not tidiness; it is the difference between
an error message and data loss.

**Why `invalid_argument` for that one and `runtime_error` for the others.** Same filename twice
is a bug in the calling code, detectable without touching the disk — a `logic_error`. A file
that will not open is the world's doing — a `runtime_error`. A caller can act on that
difference.

**And note what needs no cleanup.** If the `bad()` check throws on the last line, both streams
still close properly during unwinding. The partial output file is left behind, which is the
right behaviour for this function; a version that promised all-or-nothing would write to a
temporary name and rename it only on success.
::::
:::

## §15.4 — User-Defined Exception Classes

The standard classes carry a message and nothing else. That is often enough, but sometimes the
handler needs the *data*: which field failed validation, what the account balance actually was,
how much the shortfall came to. Deriving your own exception lets it carry that.

```cpp
#include <exception>
#include <string>
#include <stdexcept>
using namespace std;

// Custom exception — extends runtime_error
class ValidationError : public runtime_error {
    string field;
    string value;
public:
    ValidationError(const string& field,
                    const string& value,
                    const string& reason)
        : runtime_error("Validation failed for '" + field + "': " + reason),
          field(field), value(value) {}

    string getField() const { return field; }
    string getValue() const { return value; }
};

// Another custom exception
class NetworkError : public runtime_error {
    int errorCode;
public:
    NetworkError(int code, const string& msg)
        : runtime_error("Network error " + to_string(code) + ": " + msg),
          errorCode(code) {}

    int getCode() const { return errorCode; }
};

// Function that throws custom exceptions
void validateAge(const string& ageStr) {
    try {
        int age = stoi(ageStr);
        if (age < 0 || age > 150)
            throw ValidationError("age", ageStr,
                                  "must be between 0 and 150");
    } catch (const invalid_argument&) {
        throw ValidationError("age", ageStr, "not a valid integer");
    }
}

int main() {
    vector<string> inputs = {"25", "-5", "abc", "200"};

    for (const string& s : inputs) {
        try {
            validateAge(s);
            cout << "Valid age: " << s << "\n";
        }
        catch (const ValidationError& e) {
            // Can access custom fields
            cerr << "Field '" << e.getField()
                 << "', value '" << e.getValue()
                 << "': " << e.what() << "\n";
        }
        catch (const exception& e) {
            // Fallback — catches ValidationError too (it IS-A exception)
            cerr << "Error: " << e.what() << "\n";
        }
    }
}
```

There is a subtlety in `validateAge` that is easy to read straight past, and it is the whole
reason the code is arranged this way.

The range check `throw ValidationError(...)` sits **inside** a `try` whose handler catches
`invalid_argument`. Does that handler catch it — turning "age out of range" into "not a valid
integer"?

No, and the reason is the hierarchy. `ValidationError` derives from `runtime_error`, and
`invalid_argument` derives from `logic_error`. They are on opposite branches, so the range-check
exception passes straight through the handler and out of the function with its correct message.
The only thing that handler catches is the `invalid_argument` thrown by `stoi` itself.

Had `ValidationError` been declared `: public invalid_argument`, the same code would silently
mislabel every out-of-range age as a formatting error. **Which base class you choose is not
cosmetic** — it decides which handlers see your exception.

The two `catch` blocks in `main` demonstrate the payoff. The first catches `ValidationError`
specifically and can call `getField()` and `getValue()`, because it has the real object. The
second is a fallback for anything else. And the order is the §15.1 rule again: the derived
type must come first, or the fallback would swallow everything and the accessor calls would
never happen.

:::callout-key[Why inherit from `std::exception`]
- Callers can write `catch (const exception&)` as a broad fallback and actually catch yours.
- `what()` gives a standard message interface, so logging code needs no special case.
- Deriving from `runtime_error` or `logic_error` rather than `exception` directly saves you
  writing `what()` at all — the base stores the string and returns it.
- It puts your exception in the same hierarchy as the standard ones, so a handler can be as
  specific or as general as it needs.

The practical rule: **derive from `runtime_error` or `logic_error`, not from `exception`
itself.** Deriving straight from `exception` means implementing `what()` by hand, and doing it
correctly is fiddlier than it looks — `what()` is `noexcept`, so it cannot build a string on
demand.
:::

### An exception hierarchy for a bank system

```cpp
class BankException : public runtime_error {
    string accountId;
public:
    BankException(const string& id, const string& msg)
        : runtime_error(msg), accountId(id) {}
    string getAccountId() const { return accountId; }
};

class InsufficientFundsException : public BankException {
    double balance, amount;
public:
    InsufficientFundsException(const string& id, double bal, double amt)
        : BankException(id, "Insufficient funds: have $" + to_string(bal)
                           + ", need $" + to_string(amt)),
          balance(bal), amount(amt) {}
    double getShortfall() const { return amount - balance; }
};

class AccountFrozenException : public BankException {
public:
    AccountFrozenException(const string& id)
        : BankException(id, "Account " + id + " is frozen") {}
};

// Usage:
void withdraw(double& balance, double amount, bool frozen, const string& id) {
    if (frozen) throw AccountFrozenException(id);
    if (amount > balance)
        throw InsufficientFundsException(id, balance, amount);
    balance -= amount;
}
```

This is a three-level hierarchy, and each level exists for a different kind of handler.

A caller that wants to log every banking problem writes `catch (const BankException& e)` and
gets `getAccountId()` for all of them. A caller that wants to *do* something about a shortfall
— offer an overdraft, suggest a smaller amount — writes
`catch (const InsufficientFundsException& e)` and gets `getShortfall()`, a number it can act on.
A frozen account needs a different response entirely, and gets its own type.

Notice what `withdraw` does **not** do: it never modifies `balance` before the checks. Both
throws happen before the subtraction, so a failed withdrawal leaves the account exactly as it
was. That property — an operation either completes or changes nothing — is called the **strong
exception guarantee**, and for anything involving money it is the only acceptable behaviour.
Getting it here cost nothing but the ordering of three lines.

## §15.5 — Worked Example: Number Format Exception

This builds a robust number-parsing utility modelled on Java's `NumberFormatException` —
converting strings to numbers with a clear, specific error for each way the input can be wrong.

It is worth doing carefully, because parsing user input is where most real programs meet most
of their bad data, and because `stoi` alone is not enough: it accepts `"7abc"` (returning 7 and
ignoring the rest) and it accepts leading whitespace. A strict parser has to reject both.

```cpp
#include <iostream>
#include <string>
#include <stdexcept>
#include <sstream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;

// Custom exception
class NumberFormatException : public invalid_argument {
    string original;
    string reason;
public:
    NumberFormatException(const string& s, const string& why)
        : invalid_argument("Cannot parse '" + s + "': " + why),
          original(s), reason(why) {}

    string getOriginal() const { return original; }
    string getReason()   const { return reason; }
};

// Strict integer parser
int parseInteger(const string& s) {
    if (s.empty())
        throw NumberFormatException(s, "empty string");

    size_t start = 0;
    if (s[0] == '+' || s[0] == '-') start = 1;

    if (start == s.size())
        throw NumberFormatException(s, "sign only, no digits");

    for (size_t i = start; i < s.size(); ++i) {
        if (!isdigit(s[i]))
            throw NumberFormatException(s,
                string("invalid character '") + s[i] + "' at position "
                + to_string(i));
    }

    try {
        size_t pos;
        long long val = stoll(s, &pos);
        if (pos != s.size())
            throw NumberFormatException(s, "trailing characters");
        if (val > INT_MAX || val < INT_MIN)
            throw NumberFormatException(s, "value out of int range");
        return (int)val;
    } catch (const out_of_range&) {
        throw NumberFormatException(s, "value out of range");
    }
}

// Strict double parser
double parseDouble(const string& s) {
    if (s.empty())
        throw NumberFormatException(s, "empty string");
    try {
        size_t pos;
        double val = stod(s, &pos);
        if (pos != s.size())
            throw NumberFormatException(s,
                "trailing characters at position " + to_string(pos));
        return val;
    } catch (const invalid_argument&) {
        throw NumberFormatException(s, "not a valid number");
    } catch (const out_of_range&) {
        throw NumberFormatException(s, "value out of double range");
    }
}

// Process a list of inputs, collecting both successes and errors
struct ParseResult {
    string input;
    bool   success;
    int    value;   // valid if success
    string error;   // valid if !success
};

vector<ParseResult> parseAll(const vector<string>& inputs) {
    vector<ParseResult> results;
    for (const string& s : inputs) {
        try {
            int v = parseInteger(s);
            results.push_back({s, true, v, ""});
        } catch (const NumberFormatException& e) {
            results.push_back({s, false, 0, e.getReason()});
        }
    }
    return results;
}

int main() {
    vector<string> inputs = {
        "42", "-17", "+5", "3.14", "abc",
        "9999999999", "", " 7", "7 ", "07"
    };

    auto results = parseAll(inputs);

    cout << "=== Parse Results ===\n";
    int successes = 0, failures = 0;
    for (const auto& r : results) {
        if (r.success) {
            cout << "✓ \"" << r.input << "\" → " << r.value << "\n";
            successes++;
        } else {
            cout << "✗ \"" << r.input << "\" → " << r.error << "\n";
            failures++;
        }
    }
    cout << "\nParsed: " << successes << " ok, " << failures << " failed\n";
}
```

### Reading the parser

**Why the manual character scan at all**, when `stoll` is right there? Because `stoll` is
permissive in ways a strict parser must not be. It skips leading whitespace, so `" 7"` becomes
7. It stops at the first non-digit and reports success, so `"7abc"` becomes 7. The loop rejects
both before `stoll` ever sees the string — that is what "strict" means here.

**The `pos` check is a second line of defence.** `stoll(s, &pos)` writes the index where it
stopped into `pos`. If that is not the end of the string, characters were left over. The
character loop should already have caught it, and the check stays anyway because two cheap
tests are better than one assumption.

**The range check is done deliberately in a wider type.** `stoll` returns `long long`, so
`"9999999999"` parses fine into 64 bits and is only then compared against `INT_MAX`. Parsing
with `stoi` directly would have thrown `out_of_range` from inside the library, and the error
message would be the library's rather than ours. Widening first, then range-checking, keeps
control of the message.

**The `catch (const out_of_range&)` still matters**, for the case `stoll` itself cannot handle —
a string of forty digits overflows `long long` too.

**A subtlety in `NumberFormatException`'s base class.** It derives from `invalid_argument`, and
so does the exception `stod` throws. That is why `parseDouble`'s handler is
`catch (const invalid_argument&)` and not something narrower: it catches the library's
exception and rethrows ours with a better message. Worth noticing that this is safe only
because nothing inside that `try` throws a `NumberFormatException` of its own — if it did, the
handler would catch our exception and re-wrap it.

### The output, and why each line comes out that way

Running the program produces exactly this:

```
=== Parse Results ===
✓ "42" → 42
✓ "-17" → -17
✓ "+5" → 5
✗ "3.14" → invalid character '.' at position 1
✗ "abc" → invalid character 'a' at position 0
✗ "9999999999" → value out of int range
✗ "" → empty string
✗ " 7" → invalid character ' ' at position 0
✗ "7 " → invalid character ' ' at position 1
✓ "07" → 7

Parsed: 4 ok, 6 failed
```

Four of these deserve comment.

**`"+5"` succeeds.** The `start` variable skips a leading sign before the digit scan, so an
explicit plus is accepted — matching the behaviour of `stoll` and of most languages.

**`"3.14"` fails at position 1**, not position 0. The `3` is a perfectly good digit; the scan
only objects when it reaches the decimal point. This is `parseInteger`, so a decimal point is
simply not part of an integer. `parseDouble("3.14")` returns 3.14 without complaint.

**`" 7"` and `"7 "` both fail**, at positions 0 and 1 respectively — the two cases `stoll` alone
would have silently accepted. These two lines are the entire justification for the manual scan.

**`"07"` succeeds and returns 7.** Leading zeros are accepted, because every character is a
digit and `stoll` reads the value as decimal. Note that this differs from C's `strtol` with base
0, which would treat a leading zero as octal — a real source of bugs in configuration parsing,
and avoided here by `stoll` defaulting to base 10.

## Chapter summary

:::callout-key[Mechanics]
- `try { } catch (const Type& e) { }` — catch by `const` reference, always
- Multiple `catch` blocks are matched first-fit, so order most-derived to most-general
- `throw ExceptionObject;` — any type may be thrown, but throw something deriving from
  `std::exception`
- `catch (...)` catches everything, and gives you no object to inspect
- Stack unwinding destroys locals between the throw and the catch, in reverse order
- Destructors must never throw
:::

:::callout-tip[Design]
- Derive from `runtime_error` or `logic_error`, not from `exception` directly
- `logic_error` means the program is wrong; `runtime_error` means the world was
- Add fields to your exception when the handler needs data, not just a message
- Put the values in the message — `"index 10 out of [0,5)"`, not `"bad index"`
- File streams do **not** throw by default; check state and convert at one boundary
- Place the `try` where recovery makes sense, which is usually not the outermost scope
- Validate before you modify, so a failed operation changes nothing
- Reserve exceptions for the exceptional — end of file is not an error
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Safe array access.** Write `int safeGet(const int arr[], int size, int index)` that throws
`out_of_range` if the index is invalid. Test it in a loop that catches the exception and prints
an error message.

::::solution[Solution]
```cpp
int safeGet(const int arr[], int size, int index) {
    if (index < 0 || index >= size)
        throw out_of_range("Index " + to_string(index) +
                           " out of [0," + to_string(size) + ")");
    return arr[index];
}
int main() {
    int data[] = {10, 20, 30};
    for (int i = 0; i <= 4; i++) {
        try { cout << safeGet(data, 3, i) << "\n"; }
        catch (const out_of_range& e) { cerr << e.what() << "\n"; }
    }
}
```

The loop runs `i` from 0 to 4 against a three-element array, so it prints `10`, `20`, `30` and
then two error messages — the test deliberately goes out of bounds twice.

**Why both bounds are checked.** `index >= size` is the obvious one; `index < 0` matters just as
much, because a negative index on a raw array is not caught by anything. `arr[-1]` compiles,
runs, and reads whatever happens to be in memory before the array — no crash, no warning, just
a wrong number. That silent wrongness is exactly what this function exists to prevent.

**Why the `try` is inside the loop again.** Same reason as Practice 15.2: one bad index should
cost one iteration, not the run.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Exception hierarchy for a game.** Design a `GameException` base inheriting from
`runtime_error`. Derive `PlayerDeadException` (carries remaining health, which should always be
$\le 0$) and `InvalidMoveException` (carries the attempted move string). Test with a simple
combat function.

::::solution[Solution]
```cpp
class GameException : public runtime_error {
public: GameException(const string& m):runtime_error(m){} };

class PlayerDeadException : public GameException {
    int hp;
public:
    PlayerDeadException(int h):GameException("Player died with hp="+to_string(h)),hp(h){}
    int getHP() const { return hp; }
};

class InvalidMoveException : public GameException {
    string move;
public:
    InvalidMoveException(const string& m):GameException("Invalid move: "+m),move(m){}
    string getMove() const { return move; }
};

void attack(int& hp, const string& action, int damage) {
    if (action != "block" && action != "dodge" && action != "attack")
        throw InvalidMoveException(action);
    if (action != "block") hp -= damage;
    if (hp <= 0) throw PlayerDeadException(hp);
}
```

**The two exceptions are not the same kind of thing, and the code reflects it.**
`InvalidMoveException` is thrown *before* anything changes — it means the caller sent nonsense,
and the game state is untouched, so the caller can prompt again and retry.

`PlayerDeadException` is thrown *after* `hp` has already been reduced. It is not a rejected
request; it is a report that a legitimate action had a fatal result. Retrying makes no sense —
the handler should end the encounter.

That asymmetry is why `getHP()` is useful: the handler wants to know how far below zero the
player went, perhaps to show overkill damage. `getMove()` serves the parallel purpose for the
other type, letting the handler echo what was rejected.

**A caller wanting to treat both alike** — logging every game problem, say — can still write
`catch (const GameException&)` and get both, which is the reason for the shared base.
::::
:::

:::problem[P3 challenge]{difficulty="challenge"}
**Exception-safe stack.** Implement `SafeStack<T>` using `vector<T>`. `pop()` and `peek()` throw
`underflow_error` if empty; `push()` throws `overflow_error` at maximum capacity (a constructor
parameter). Verify every exception with tests.

::::solution[Solution]
```cpp
template <typename T>
class SafeStack {
    vector<T> data;
    int maxCap;
public:
    SafeStack(int cap) : maxCap(cap) {}
    void push(const T& val) {
        if ((int)data.size() == maxCap)
            throw overflow_error("Stack full (cap=" + to_string(maxCap) + ")");
        data.push_back(val);
    }
    T pop() {
        if (data.empty()) throw underflow_error("Stack is empty");
        T val = data.back(); data.pop_back(); return val;
    }
    const T& peek() const {
        if (data.empty()) throw underflow_error("Stack is empty");
        return data.back();
    }
    int size() const { return data.size(); }
    bool empty() const { return data.empty(); }
};
```

**Every check precedes its modification**, which gives the strong guarantee: a `push` that
overflows leaves the stack exactly as it was, and so does a `pop` on an empty stack. A caller
that catches the exception can carry on using the object with confidence.

**Why `pop()` returns by value while `peek()` returns by reference.** `pop` must copy the value
out *before* `pop_back` destroys it — returning a reference would hand back a dangling one.
`peek` leaves the element in place, so a reference is safe, and `const` prevents a caller from
modifying the stack's interior through it.

**Why the cast in `(int)data.size()`.** `size()` returns an unsigned type, and comparing it
directly against a signed `int` draws a warning — and worse, if `maxCap` were ever negative, the
usual-arithmetic-conversions rule would convert it to a huge unsigned value and the comparison
would silently be wrong. The cast makes both sides signed.

**Testing it** means confirming all three exceptions actually fire:

```cpp
SafeStack<int> s(2);
try { s.pop(); } catch (const underflow_error& e) { cerr << e.what() << "\n"; }
s.push(1); s.push(2);
try { s.push(3); } catch (const overflow_error& e) { cerr << e.what() << "\n"; }
cout << s.peek() << "\n";   // 2 — unchanged by the failed push
```

The last line is the real test: it confirms the failed `push` did not corrupt the stack.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
Exception handling pairs with robust class design. These require careful handling of invalid
inputs and edge cases — exactly where exceptions earn their keep in production code.

| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 66 | [Plus One](https://leetcode.com/problems/plus-one/) | Easy | Boundary handling (all 9s) without exceptions — the discipline, not the mechanism |
| 8 | [String to Integer (atoi)](https://leetcode.com/problems/string-to-integer-atoi/) | Medium | Robust parsing with overflow handling — the same problem as `parseInteger` in §15.5 |
| 155 | [Min Stack](https://leetcode.com/problems/min-stack/) | Medium | `pop()`/`top()` on an empty stack — model it on the `SafeStack` above |
| 150 | [Evaluate RPN](https://leetcode.com/problems/evaluate-reverse-polish-notation/) | Medium | Stack evaluator that must handle invalid tokens and division by zero |
:::
