---
title: "Chapter 6 — Arrays & Vectors"
source: "markdown"
---

CSE 1384

# Chapter 6 — Arrays & Vectors

§6.1 – §6.20

## §6.1 – §6.4 · Array Fundamentals

An **array** is a fixed-size, ordered collection of elements that all share the same type. Every element sits in a contiguous block of memory and is accessed by a zero-based **index**.

### Declaration and initialization

```cpp
// Declaration (elements are uninitialized — garbage values)
int scores[5];

// Declaration + initialization list
int scores[5] = {92, 88, 75, 95, 83};

// Size inferred from initializer
int primes[] = {2, 3, 5, 7, 11};   // compiler deduces size = 5

// All elements set to 0
double temps[7] = {};               // zero-initialization

// Partial init — remaining elements become 0
int flags[4] = {1, 1};             // {1, 1, 0, 0}
```

:::callout-key
Array size must be a

compile-time constant

in standard C++ (it can be a literal or a

const int

). Variable-length arrays (VLAs) are a GCC extension, not standard C++. Use

vector

(covered later) when you need a runtime size.
:::

### Indexing and memory layout

Indices run from `0` to `size - 1`. Think of the array name as pointing to the first element; index `i` means "skip forward `i` elements."

```cpp
int scores[5] = {92, 88, 75, 95, 83};
//  index         0   1   2   3   4

cout << scores[0];   // 92
cout << scores[4];   // 83
scores[2] = 100;     // modify element at index 2
```

Memory layout of `scores[5]`:

```
    92scores[0]
    88scores[1]
    100scores[2]
    95scores[3]
    83scores[4]

```

:::callout-pitfall
Off-by-one / out-of-bounds access

is the most common array bug in C++. Accessing

scores[5]

(or any negative index) is

undefined behavior

— the program may crash, silently corrupt data, or appear to work. C++ does not perform bounds checking on raw arrays.
:::

### Iterating over an array

```cpp
const int SIZE = 5;
int scores[SIZE] = {92, 88, 75, 95, 83};

// Classic index loop — preferred when you need the index
for (int i = 0; i < SIZE; ++i) {
    cout << "scores[" << i << "] = " << scores[i] << '\n';
}

// Range-based for — preferred when you only need the value
for (int val : scores) {
    cout << val << ' ';
}
cout << '\n';
```

:::callout-intuition
Use

for (int i = 0; i < SIZE; ++i)

when you need the index (e.g., comparing adjacent elements). Use range-based

for (int v : arr)

when you just need each value — it is cleaner and eliminates the off-by-one risk.
:::

### §6.3 Passing arrays to functions

When you pass an array to a function, C++ actually passes a **pointer to the first element** — the size information is lost. You must pass the size separately.

```cpp
#include <iostream>
using namespace std;

// Receives pointer to first element; size passed separately
double average(const int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; ++i) sum += arr[i];
    return static_cast<double>(sum) / size;
}

int main() {
    int scores[5] = {92, 88, 75, 95, 83};
    cout << "Average: " << average(scores, 5) << '\n';   // 86.6
}
```

:::callout-key
The

const

qualifier on

arr[]

tells the compiler (and the reader) that the function will not modify the array. Always use

const

when the function is read-only — it documents intent and catches accidental writes.
:::

### §6.4 Common array algorithms

Four fundamental single-pass algorithms you should be able to write from memory:

#### Example — find min, max, and sum

```cpp
int arr[] = {4, 1, 9, 2, 7};
const int N = 5;

int minVal = arr[0], maxVal = arr[0], sum = 0;
for (int i = 0; i < N; ++i) {
    if (arr[i] < minVal) minVal = arr[i];
    if (arr[i] > maxVal) maxVal = arr[i];
    sum += arr[i];
}
cout << "Min=" << minVal << " Max=" << maxVal
     << " Avg=" << static_cast<double>(sum)/N << '\n';
// Min=1 Max=9 Avg=4.6
```

:::callout-pitfall[Seed with `arr[0]`, never with `0`]
`minVal` and `maxVal` start at `arr[0]` rather than at `0`, and the difference is not stylistic.
Seeding `maxVal = 0` silently assumes the array holds a non-negative number: on `{-9, -4, -7}`
every comparison fails, the variable is never assigned, and the function reports a maximum of
`0` — a value that is not in the array at all. Seeding `minVal = 0` fails the same way on
all-positive input.

The identity for "largest so far" is not zero, it is *the first element*, which is why the loop
can equivalently start at `i = 1`. It also means the array must be non-empty: `arr[0]` on a
zero-length array is undefined behaviour, so a version taking the size as a parameter has to
reject `n == 0` before it reads anything.
:::

#### Example — linear search (find first occurrence)

```cpp
int arr[] = {4, 1, 9, 2, 7};
const int N = 5;
int target = 9, foundAt = -1;

for (int i = 0; i < N; ++i) {
    if (arr[i] == target) { foundAt = i; break; }
}

if (foundAt != -1) cout << "Found at index " << foundAt << '\n';
else               cout << "Not found\n";
```

#### Example — count occurrences

```cpp
int grades[] = {90, 80, 90, 70, 90};
int count = 0;
for (int g : grades) if (g == 90) ++count;
cout << "Count of 90: " << count << '\n';  // 3
```

#### Example — shifting elements to close a gap

Removing element `k` from a raw array means moving everything after it down one position. There
is no "delete" for an array; the shift *is* the removal.

```cpp
int arr[] = {10, 20, 30, 40, 50};
int n = 5, k = 1;                    // remove index 1 (the 20)

for (int i = k; i < n - 1; ++i)
    arr[i] = arr[i + 1];
--n;                                 // {10, 30, 40, 50}, n == 4
```

:::callout-pitfall[Assignment is sequential, not simultaneous]
A shift loop is where "the array updates all at once" quietly becomes wrong. Each
`arr[i] = arr[i + 1]` completes before the next iteration starts, so iteration `i` may be reading
a cell that iteration `i - 1` already overwrote.

Direction is what decides whether that matters. Shifting *left* is safe: `arr[i]` is written only
after `arr[i + 1]` has been read, and `arr[i + 1]` is never needed again. Shifting *right* with
the same ascending loop destroys the array — `arr[i + 1] = arr[i]` overwrites the value the next
iteration was about to read, smearing the first element across the whole tail. A right shift has
to run descending:

```cpp
for (int i = n - 1; i > k; --i)
    arr[i] = arr[i - 1];             // nothing is read after it has been written
```

The same care applies to tracing one by hand. Write a cell, redraw the array, then move on — do
not evaluate every right-hand side against the original array and fill the answers in together.
That shortcut happens to give the right answer for a left shift and the wrong one for a right
shift, which is precisely why it is worth doing the slow way every time.
:::

:::callout-pitfall[Print before update, or after — the order is the answer]
When a loop both prints and modifies, where the `cout` sits relative to the assignment changes
the output itself, not merely its formatting:

```cpp
int x = 5;
while (x > 0) { cout << x << " "; x -= 2; }   // 5 3 1

x = 5;
while (x > 0) { x -= 2; cout << x << " "; }   // 3 1 -1
```

The second loop prints *after* the decrement, so it never shows the starting value and does show
one the first loop stops before — including a negative, because the test happens after the body
has already run. Trace statements strictly in the order written, one line at a time.
:::

## §6.5 – §6.7 · Sorting & the Two-Pointer Pattern

### §6.5 Bubble sort

Bubble sort repeatedly compares adjacent elements and swaps them if they are out of order. After each full pass the largest unsorted element "bubbles" to its correct position.

```cpp
void bubbleSort(int arr[], int n) {
    for (int pass = 0; pass < n - 1; ++pass) {
        for (int j = 0; j < n - 1 - pass; ++j) {
            if (arr[j] > arr[j + 1]) {
                // swap
                int tmp = arr[j];
                arr[j]  = arr[j + 1];
                arr[j + 1] = tmp;
            }
        }
    }
}
```

Trace through `{5, 2, 8, 1}`:

| Pass | j=0 | j=1 | j=2 | Array after pass |
| --- | --- | --- | --- | --- |
| 0 | swap 5,2 | no swap | swap 8,1 | {2, 5, 1, 8} |
| 1 | no swap | swap 5,1 | — | {2, 1, 5, 8} |
| 2 | swap 2,1 | — | — | {1, 2, 5, 8} ✓ |

:::callout-intuition
Bubble sort is O(n²) — slow for large arrays. You will almost never use it in production. Its value here is that the logic is transparent: you can trace each swap by hand, which builds intuition for in-place swapping and nested loop analysis.
:::

### §6.6 Selection sort

Selection sort finds the minimum of the unsorted portion and swaps it into position. Exactly n−1 swaps — fewer writes than bubble sort.

```cpp
void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; ++i) {
        int minIdx = i;
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[minIdx]) minIdx = j;
        }
        // swap arr[i] and arr[minIdx]
        int tmp = arr[i]; arr[i] = arr[minIdx]; arr[minIdx] = tmp;
    }
}
```

### §6.7 Using <algorithm> — std::sort

In real code, use the standard library's `std::sort` (introductory sort, O(n log n)):

```cpp
#include <algorithm>
#include <iostream>
using namespace std;

int main() {
    int arr[] = {5, 2, 8, 1, 9, 3};
    int n = 6;

    sort(arr, arr + n);                        // ascending
    sort(arr, arr + n, greater<int>());        // descending

    // For a subrange, sort only indices [2, 5)
    sort(arr + 2, arr + 5);
}
```

:::callout-key
sort(begin, end)

takes two pointers:

arr

(=

&arr[0]

) and

arr + n

(one-past-the-end). This iterator pattern is universal in the STL — you will see it everywhere.
:::

### Two-pointer technique on sorted arrays

Many array problems become O(n) once the array is sorted by placing one pointer at each end and moving them inward:

#### Example — check if any two elements sum to a target

```cpp
#include <algorithm>
using namespace std;

bool hasPairSum(int arr[], int n, int target) {
    sort(arr, arr + n);      // O(n log n) one-time cost
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int s = arr[lo] + arr[hi];
        if      (s == target) return true;
        else if (s <  target) ++lo;   // need larger sum
        else                  --hi;   // need smaller sum
    }
    return false;
}
// hasPairSum({1,4,7,2,9}, 5, 11) → true (2+9)
```

## §6.8 – §6.11 · Vectors

A `vector` is a **dynamically-sized array** from the C++ Standard Library. It manages its own memory — you never have to specify a size upfront, and it grows automatically as you push elements.

### Declaration and basic operations

```cpp
#include <vector>
#include <iostream>
using namespace std;

int main() {
    vector<int> v;                      // empty vector
    vector<int> v2(5, 0);              // 5 elements, all 0
    vector<int> v3 = {10, 20, 30};    // initializer list

    // Add / remove
    v3.push_back(40);       // {10,20,30,40}
    v3.pop_back();          // {10,20,30}

    // Size
    cout << v3.size() << '\n';   // 3  (returns size_t, unsigned)

    // Access — same as array
    cout << v3[1] << '\n';      // 20 (no bounds check)
    cout << v3.at(1) << '\n';   // 20 (throws if out of bounds)

    // Iterate
    for (int x : v3) cout << x << ' ';
}
```

:::callout-pitfall
vector::size()

returns an

unsigned

type (`size_t`). Comparing it to a signed

int

can cause surprising results:

v.size() - 1

when the vector is empty wraps around to a huge positive number. Cast defensively:

(int)v.size()

or use a range-based for loop.
:::

### §6.9 Common vector methods

| Method | Effect | Example |
| --- | --- | --- |
| `push_back(x)` | Append element | `v.push_back(5)` |
| `pop_back()` | Remove last element | `v.pop_back()` |
| `size()` | Number of elements | `v.size() == 3` |
| `empty()` | True if size == 0 | `v.empty()` |
| `front()` / `back()` | First / last element | `v.back() = 9` |
| `insert(pos, x)` | Insert before iterator | `v.insert(v.begin()+1, 99)` |
| `erase(pos)` | Remove at iterator | `v.erase(v.begin())` |
| `clear()` | Remove all elements | `v.clear()` |
| `resize(n)` | Change size (fills with 0) | `v.resize(10)` |
| `assign(n, val)` | Replace contents | `v.assign(5, 0)` |

### §6.10 Passing vectors to functions

```cpp
// Pass by const reference — no copy, read-only
double average(const vector<int>& v) {
    int sum = 0;
    for (int x : v) sum += x;
    return static_cast<double>(sum) / v.size();
}

// Pass by reference — can modify
void scale(vector<int>& v, int factor) {
    for (int& x : v) x *= factor;     // note: int& to modify in place
}

// Return a new vector
vector<int> doubled(const vector<int>& v) {
    vector<int> result;
    for (int x : v) result.push_back(x * 2);
    return result;
}
```

:::callout-key
Always pass a

vector

by reference (

vector<T>&

) or const reference (

const vector<T>&

) — never by value unless you deliberately want a copy. Passing by value copies every element, which is expensive for large vectors.
:::

### §6.11 Sorting and searching vectors

```cpp
#include <algorithm>
#include <vector>
using namespace std;

int main() {
    vector<int> v = {5, 2, 8, 1, 9};

    sort(v.begin(), v.end());              // ascending: {1,2,5,8,9}
    sort(v.begin(), v.end(), greater<int>()); // descending

    // Binary search (requires sorted input)
    bool found = binary_search(v.begin(), v.end(), 5);  // true

    // Find position (linear)
    auto it = find(v.begin(), v.end(), 8);
    if (it != v.end())
        cout << "Found at index " << (it - v.begin()) << '\n';

    // Min / max element
    cout << *min_element(v.begin(), v.end()) << '\n';  // 1
    cout << *max_element(v.begin(), v.end()) << '\n';  // 9
}
```

## §6.12 – §6.15 · Two-Dimensional Arrays

A 2D array is an array of arrays — think of it as a grid with rows and columns. The declaration `int grid[ROWS][COLS]` allocates `ROWS × COLS` elements in row-major order.

### Declaration and initialization

```cpp
const int ROWS = 3, COLS = 4;
int matrix[ROWS][COLS] = {
    {1,  2,  3,  4},   // row 0
    {5,  6,  7,  8},   // row 1
    {9, 10, 11, 12}    // row 2
};

// Access element at row 1, col 2
cout << matrix[1][2] << '\n';  // 7

// Zero-initialize
int blank[3][4] = {};
```

### Nested loop traversal

```cpp
// Print entire matrix
for (int r = 0; r < ROWS; ++r) {
    for (int c = 0; c < COLS; ++c) {
        cout << matrix[r][c] << '\t';
    }
    cout << '\n';
}

// Row sum for each row
for (int r = 0; r < ROWS; ++r) {
    int rowSum = 0;
    for (int c = 0; c < COLS; ++c) rowSum += matrix[r][c];
    cout << "Row " << r << " sum: " << rowSum << '\n';
}
```

### §6.13 Passing 2D arrays to functions

When passing a 2D array to a function, the **number of columns must be specified** in the parameter (the compiler needs it to calculate row offsets). The number of rows is passed separately.

```cpp
const int COLS = 4;

void printMatrix(const int arr[][COLS], int rows) {
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < COLS; ++c)
            cout << arr[r][c] << '\t';
        cout << '\n';
    }
}

int main() {
    int m[3][COLS] = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};
    printMatrix(m, 3);
}
```

:::callout-pitfall
You cannot omit the column count for 2D array parameters — the compiler must know the stride (bytes per row) to compute

arr[r][c]

. If you want runtime-sized 2D grids, use

vector<vector<int>>

.
:::

### §6.14 Vector of vectors — dynamic 2D grid

```cpp
#include <vector>
using namespace std;

int main() {
    int rows = 3, cols = 4;

    // Build rows × cols grid filled with 0
    vector<vector<int>> grid(rows, vector<int>(cols, 0));

    grid[1][2] = 99;

    // Iterate
    for (const auto& row : grid) {
        for (int val : row) cout << val << '\t';
        cout << '\n';
    }

    // Add a new row at the end
    grid.push_back(vector<int>(cols, -1));
    cout << "Rows now: " << grid.size() << '\n';  // 4
}
```

### §6.15 Common 2D array algorithms

#### Example — transpose a square matrix in-place

```cpp
const int N = 3;
int mat[N][N] = {{1,2,3},{4,5,6},{7,8,9}};

// Only iterate upper triangle; swap (r,c) with (c,r)
for (int r = 0; r < N; ++r)
    for (int c = r + 1; c < N; ++c)
        swap(mat[r][c], mat[c][r]);

// Result: {{1,4,7},{2,5,8},{3,6,9}}
```

#### Example — diagonal sum

```cpp
int diagSum = 0;
for (int i = 0; i < N; ++i) diagSum += mat[i][i];   // main diagonal

int antiDiagSum = 0;
for (int i = 0; i < N; ++i) antiDiagSum += mat[i][N - 1 - i];
```

## §6.16 – §6.18 · Array Algorithms in Depth

### §6.16 Prefix sums — range queries in O(1)

A **prefix sum array** precomputes cumulative sums so that any subarray sum can be answered in O(1) after O(n) preprocessing.

```cpp
vector<int> arr = {3, 1, 4, 1, 5, 9, 2, 6};
int n = arr.size();

vector<int> prefix(n + 1, 0);
for (int i = 0; i < n; ++i)
    prefix[i + 1] = prefix[i] + arr[i];

// Sum of arr[l..r] inclusive (0-indexed)
auto rangeSum = [&](int l, int r) {
    return prefix[r + 1] - prefix[l];
};

cout << rangeSum(1, 4) << '\n';  // arr[1]+arr[2]+arr[3]+arr[4] = 1+4+1+5 = 11
```

:::callout-connect
Prefix sums appear constantly in competitive programming and interview problems. LeetCode #53 (Maximum Subarray) can be solved with a running prefix sum, and many "subarray with sum K" problems reduce to prefix sum + hash map.
:::

### §6.17 Sliding window — fixed and variable size

A **sliding window** maintains a contiguous sub-range of the array without recomputing from scratch each step.

#### Example — maximum sum of any k consecutive elements

```cpp
int maxSubarrayOfSize(const vector<int>& arr, int k) {
    int n = arr.size();
    if (n < k) return -1;

    // Build first window
    int windowSum = 0;
    for (int i = 0; i < k; ++i) windowSum += arr[i];

    int maxSum = windowSum;
    // Slide: add next element, remove leftmost
    for (int i = k; i < n; ++i) {
        windowSum += arr[i] - arr[i - k];
        maxSum = max(maxSum, windowSum);
    }
    return maxSum;
}
// maxSubarrayOfSize({2,1,5,1,3,2}, 3) → 9  (5+1+3)
```

### §6.18 Frequency / counting arrays

When values fall in a known range (e.g., 0–255 for bytes, 0–9 for digits, 'a'–'z' for letters), a counting array gives O(n) frequency analysis.

```cpp
string s = "mississippi";
int freq[26] = {};   // zero-initialized; freq['a'-'a'] = freq[0], etc.

for (char c : s) ++freq[c - 'a'];

for (int i = 0; i < 26; ++i)
    if (freq[i] > 0)
        cout << (char)('a' + i) << ": " << freq[i] << '\n';
// i: 4   m: 1   p: 2   s: 4
```

## §6.19 – §6.20 · Full Worked Examples

#### Example 1 — Grade roster statistics (§6.19)

Read a list of exam scores from the user, compute statistics, and show a letter-grade histogram.

```cpp
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    vector<int> scores;
    int s;
    cout << "Enter scores (-1 to stop): ";
    while (cin >> s && s != -1) {
        if (s >= 0 && s <= 100) scores.push_back(s);
        else cout << "  (out of range, skipped)\n";
    }

    if (scores.empty()) { cout << "No data.\n"; return 0; }

    int n = scores.size();
    double avg = accumulate(scores.begin(), scores.end(), 0.0) / n;
    int minS = *min_element(scores.begin(), scores.end());
    int maxS = *max_element(scores.begin(), scores.end());

    cout << "\n--- Statistics ---\n";
    cout << "Count : " << n    << '\n';
    cout << "Min   : " << minS << '\n';
    cout << "Max   : " << maxS << '\n';
    cout << "Avg   : " << avg  << '\n';

    // Histogram: A(90-100), B(80-89), C(70-79), D(60-69), F(<60)
    int hist[5] = {};
    for (int v : scores) {
        if      (v >= 90) ++hist[0];
        else if (v >= 80) ++hist[1];
        else if (v >= 70) ++hist[2];
        else if (v >= 60) ++hist[3];
        else               ++hist[4];
    }
    string grades = "ABCDF";
    cout << "\n--- Grade Distribution ---\n";
    for (int i = 0; i < 5; ++i)
        cout << grades[i] << ": " << string(hist[i], '*') << " (" << hist[i] << ")\n";
}
/* Sample run:
   Enter scores (-1 to stop): 92 88 75 95 83 67 91 -1
   Count : 7   Min: 67   Max: 95   Avg: 84.4286
   A: *** (3)   B: *** (3)   C: * (1)   D: (0)   F: (0)
*/
```

#### Example 2 — Rotate array k positions right (§6.20)

Rotate `{1,2,3,4,5}` right by `k=2` → `{4,5,1,2,3}`. Uses the "reverse three times" trick — O(n) time, O(1) extra space.

```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Reverse elements in v from index l to r inclusive
void reverseRange(vector<int>& v, int l, int r) {
    while (l < r) { swap(v[l++], v[r--]); }
}

void rotateRight(vector<int>& v, int k) {
    int n = v.size();
    k %= n;           // handle k >= n
    if (k == 0) return;

    reverseRange(v, 0, n - 1);    // reverse whole array
    reverseRange(v, 0, k - 1);    // reverse first k
    reverseRange(v, k, n - 1);    // reverse rest
}

int main() {
    vector<int> v = {1, 2, 3, 4, 5};
    rotateRight(v, 2);
    for (int x : v) cout << x << ' ';
    cout << '\n';   // 4 5 1 2 3
}
```

Trace of the three-reverse trick:

| Step | Array state |
| --- | --- |
| Initial | {1, 2, 3, 4, 5} |
| Reverse all | {5, 4, 3, 2, 1} |
| Reverse [0,1] (first k=2) | {4, 5, 3, 2, 1} |
| Reverse [2,4] (rest) | {4, 5, 1, 2, 3} ✓ |

:::summary
### Chapter 6 — Key Takeaways

- **Raw arrays** have fixed size, zero-based indexing, and *no bounds checking*. Pass with a separate size parameter.
- **Index range** is `0` to `size - 1`. Accessing outside this range is undefined behavior.
- **Vectors** (`#include <vector>`) grow dynamically. Prefer them over raw arrays in modern C++.
- Pass vectors by **const reference** (`const vector<T>&`) to avoid expensive copies.
- **`std::sort(begin, end)`** beats manual bubble/selection sort for real code — O(n log n).
- **Two-pointer** on a sorted array finds pairs in O(n).
- **2D arrays**: column count must be known at compile time when passed to functions; use `vector<vector<int>>` for dynamic grids.
- **Prefix sums** enable O(1) range-sum queries after O(n) build.
- **Sliding window** avoids recomputing subarray stats from scratch.
- `vector::size()` is unsigned — cast to `int` before subtracting to avoid wrap-around bugs.
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Array Reversal

Write a function `void reverseArray(int arr[], int n)` that reverses the array in-place (no extra array allowed). Test with `{1,2,3,4,5}`.

::::solution[Solution]
```cpp
void reverseArray(int arr[], int n) {
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int tmp = arr[lo];
        arr[lo] = arr[hi];
        arr[hi] = tmp;
        ++lo; --hi;
    }
}
// After: {5,4,3,2,1}
```

Two-pointer approach: swap the outermost pair, then move inward. Each element is visited once → O(n), O(1) space.
::::
:::

:::problem{difficulty="easy"}
P2 — Remove Duplicates (sorted vector)

Given a **sorted** `vector<int>`, remove all duplicates in-place and return the new length. The first *k* elements of the vector should hold the unique values after your function runs.

::::solution[Solution]
```cpp
int removeDuplicates(vector<int>& v) {
    if (v.empty()) return 0;
    int k = 1;               // v[0] is always unique
    for (int i = 1; i < (int)v.size(); ++i) {
        if (v[i] != v[k - 1]) {
            v[k++] = v[i];   // write unique value at position k
        }
    }
    return k;
}
// {1,1,2,3,3,4} → k=4, v begins with {1,2,3,4}
```

Slow-fast pointer: `k` is the write pointer; `i` is the read pointer. Because the array is sorted, duplicates are always adjacent.
::::
:::

:::problem{difficulty="easy"}
P3 — Contains Duplicate

Given a vector of integers, return `true` if any value appears more than once. Try two approaches: (a) sort then scan, (b) counting array for values 0–99.

::::solution[Solution]
```cpp
// (a) Sort approach — O(n log n)
bool containsDup_sort(vector<int>& v) {
    sort(v.begin(), v.end());
    for (int i = 1; i < (int)v.size(); ++i)
        if (v[i] == v[i-1]) return true;
    return false;
}

// (b) Counting array — O(n), works for values in [0,99]
bool containsDup_count(const vector<int>& v) {
    int freq[100] = {};
    for (int x : v) {
        if (++freq[x] > 1) return true;
    }
    return false;
}
```
::::
:::

:::problem{difficulty="standard"}
P4 — Best Time to Buy & Sell

You are given a vector `prices` where `prices[i]` is the stock price on day `i`. Find the maximum profit you can achieve by choosing one day to buy and a later day to sell. If no profit is possible, return 0.

::::solution[Solution]
```cpp
int maxProfit(const vector<int>& prices) {
    if (prices.empty()) return 0;
    int minPrice = prices[0];
    int maxProft = 0;
    for (int i = 1; i < (int)prices.size(); ++i) {
        int profit = prices[i] - minPrice;
        if (profit > maxProft)  maxProft  = profit;
        if (prices[i] < minPrice) minPrice = prices[i];
    }
    return maxProft;
}
// {7,1,5,3,6,4} → minPrice tracks the cheapest seen so far;
// at each day we compute today's profit and update max.
// Answer: 5 (buy day 1 at 1, sell day 4 at 6)
```

Key insight: the minimum price seen so far always precedes the current day, so we never accidentally sell before buying.
::::
:::

:::problem{difficulty="standard"}
P5 — Maximum Subarray (Kadane's Algorithm)

Find the contiguous subarray of a vector of integers with the largest sum and return that sum. Example: `{-2,1,-3,4,-1,2,1,-5,4}` → `6` (subarray `{4,-1,2,1}`).

::::solution[Solution]
```cpp
int maxSubArray(const vector<int>& v) {
    int currentSum = v[0];
    int bestSum    = v[0];
    for (int i = 1; i < (int)v.size(); ++i) {
        // Either extend current subarray or start fresh at v[i]
        currentSum = max(v[i], currentSum + v[i]);
        bestSum    = max(bestSum, currentSum);
    }
    return bestSum;
}
```

**Kadane's algorithm**: at each position decide "is it better to extend the previous subarray or restart here?" One pass, O(n) time, O(1) space.
::::
:::

:::problem{difficulty="challenge"}
P6 — Merge Two Sorted Arrays

Given two sorted vectors `a` and `b`, produce a single sorted vector containing all elements of both. Do it in O(n + m) time without calling `sort`.

::::solution[Solution]
```cpp
vector<int> mergeSorted(const vector<int>& a, const vector<int>& b) {
    vector<int> result;
    result.reserve(a.size() + b.size());
    int i = 0, j = 0;
    while (i < (int)a.size() && j < (int)b.size()) {
        if (a[i] <= b[j]) result.push_back(a[i++]);
        else               result.push_back(b[j++]);
    }
    // Append leftover elements from whichever list remains
    while (i < (int)a.size()) result.push_back(a[i++]);
    while (j < (int)b.size()) result.push_back(b[j++]);
    return result;
}
// {1,3,5} + {2,4,6} → {1,2,3,4,5,6}
```

This is the merge step from merge sort. Two pointers advance through each array independently; the smallest available element from either array is always taken next.
::::
:::

:::problem{difficulty="easy"}
P7 — Two-Pointer Sum

Given a sorted array, use the two-pointer technique to find two elements that sum to a target value. Return their indices or {-1,-1} if not found. Trace the algorithm on `{1, 3, 5, 7, 9, 11}`, target=14.

::::solution[Solution]
```cpp
pair<int,int> twoSum(const vector<int>& v, int target) {
    int lo = 0, hi = (int)v.size() - 1;
    while (lo < hi) {
        int s = v[lo] + v[hi];
        if      (s == target) return {lo, hi};
        else if (s <  target) ++lo;   // need larger sum
        else                  --hi;   // need smaller sum
    }
    return {-1, -1};
}
```

| lo | hi | v[lo] | v[hi] | Sum | Action |
| --- | --- | --- | --- | --- | --- |
| 0 | 5 | 1 | 11 | 12 | 12 < 14 → ++lo |
| 1 | 5 | 3 | 11 | 14 | 14 == 14 → return {1,5} ✓ |

**Complexity:** O(n) time, O(1) space. The key invariant: if the sum is too small, we must increase it (only way: advance lo to a larger value). If too large, decrease it (only way: retreat hi).
::::
:::

:::problem{difficulty="standard"}
P8 — Rotate Array

Rotate an array of n elements to the right by k steps in O(n) time and O(1) space (in-place). Example: `{1,2,3,4,5,6,7}`, k=3 → `{5,6,7,1,2,3,4}`. Hint: use three reversals.

::::solution[Solution]
```cpp
void reverseRange(vector<int>& v, int lo, int hi) {
    while (lo < hi) swap(v[lo++], v[hi--]);
}

void rotate(vector<int>& v, int k) {
    int n = v.size();
    k %= n;                          // handle k >= n
    reverseRange(v, 0, n-1);        // reverse whole array
    reverseRange(v, 0, k-1);        // reverse first k
    reverseRange(v, k, n-1);        // reverse remaining
}
// {1,2,3,4,5,6,7} k=3:
// Step 1 reverse all:  {7,6,5,4,3,2,1}
// Step 2 reverse [0,2]:{5,6,7,4,3,2,1}
// Step 3 reverse [3,6]:{5,6,7,1,2,3,4} ✓
```

**Why it works:** Right-rotating by k is equivalent to moving the last k elements to the front. Reversing the whole array places them first (but backwards), then reversing each half corrects the order. Three passes, O(1) extra space.
::::
:::

:::problem{difficulty="standard"}
P9 — 2D Array Spiral Traversal

Given an m×n 2D vector, return all elements in spiral order (outer ring clockwise, then inner, etc.). Implement this for a 4×4 matrix and trace the boundary shrinking.

::::solution[Solution]
```cpp
vector<int> spiralOrder(vector<vector<int>>& m) {
    vector<int> res;
    if (m.empty()) return res;
    int top=0, bottom=m.size()-1, left=0, right=m[0].size()-1;
    while (top <= bottom && left <= right) {
        for (int c = left;  c <= right;  ++c) res.push_back(m[top][c]);    ++top;
        for (int r = top;   r <= bottom; ++r) res.push_back(m[r][right]);  --right;
        if (top <= bottom)
            for (int c = right; c >= left;  --c) res.push_back(m[bottom][c]); --bottom;
        if (left <= right)
            for (int r = bottom;r >= top;   --r) res.push_back(m[r][left]);  ++left;
    }
    return res;
}
```

For a 4×4 matrix: →top row, ↓right col, ←bottom row, ↑left col (outer ring), then repeat for 2×2 inner ring. The boundary guards `if (top <= bottom)` and `if (left <= right)` handle non-square matrices.
::::
:::

:::problem{difficulty="standard"}
P10 — Prefix Sum Array

Build a prefix sum array from `{3, 1, 4, 1, 5, 9, 2, 6}`. Then answer range-sum queries (sum of elements from index l to r inclusive) in O(1) time. Write both the build function and the query function.

::::solution[Solution]
```cpp
vector<int> buildPrefix(const vector<int>& v) {
    int n = v.size();
    vector<int> pre(n + 1, 0);   // pre[i] = sum of v[0..i-1]
    for (int i = 0; i < n; ++i)
        pre[i + 1] = pre[i] + v[i];
    return pre;
}

// Sum of v[l..r] (0-indexed, inclusive) in O(1)
int rangeSum(const vector<int>& pre, int l, int r) {
    return pre[r + 1] - pre[l];
}

// Build: pre = {0, 3, 4, 8, 9, 14, 23, 25, 31}
// Query: sum(2, 5) = pre[6] - pre[2] = 23 - 4 = 19  (4+1+5+9=19 ✓)
```

Prefix sums enable O(1) range queries after O(n) preprocessing. This pattern is fundamental to many 2D problems (2D prefix sums), DP optimizations, and sliding-window problems that need fast sub-range sums.
::::
:::

:::callout-tip
These problems map directly to the techniques in this chapter. Work through them in order — the Easy problems reinforce fundamentals; the Medium problems require combining two ideas.

| # | Problem | Difficulty | Key Technique |
| --- | --- | --- | --- |
| 26 | [Remove Duplicates from Sorted Array](https://leetcode.com/problems/remove-duplicates-from-sorted-array/) | Easy | Slow-fast two-pointer write |
| 27 | [Remove Element](https://leetcode.com/problems/remove-element/) | Easy | In-place write pointer |
| 217 | [Contains Duplicate](https://leetcode.com/problems/contains-duplicate/) | Easy | Sort + scan, or frequency count |
| 121 | [Best Time to Buy and Sell Stock](https://leetcode.com/problems/best-time-to-buy-and-sell-stock/) | Easy | Running minimum + max profit |
| 88 | [Merge Sorted Array](https://leetcode.com/problems/merge-sorted-array/) | Easy | Two-pointer merge (fill from right) |
| 53 | [Maximum Subarray](https://leetcode.com/problems/maximum-subarray/) | Medium | Kadane's algorithm |
| 189 | [Rotate Array](https://leetcode.com/problems/rotate-array/) | Medium | Triple reverse trick |
:::
