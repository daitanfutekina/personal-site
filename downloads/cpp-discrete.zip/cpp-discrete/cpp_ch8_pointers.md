---
title: "Chapter 8 — Pointers"
source: "cpp_ch8_pointers.html"
---

CSE 1384

# Chapter 8 — Pointers

§8.1 – §8.17

## §8.1 · Pointer Basics

A **pointer** is a variable that stores a *memory address*. Instead of holding a value like `42`, it holds the location in RAM where a value lives. Pointers are how C++ gives you direct control over memory — and how data structures like linked lists and trees are built.

### Declaring and using pointers

```cpp
int x = 42;

int* ptr = &x;   // ptr holds the ADDRESS of x  (& = "address-of")

cout << x;       // 42   — the value
cout << &x;      // e.g. 0x7ffd1234  — x's address
cout << ptr;     // same address as &x
cout << *ptr;    // 42   — dereference: follow the pointer to get the value

*ptr = 99;       // dereference + assign: changes x through the pointer
cout << x;       // 99
```

Memory picture after `int* ptr = &x`:

0x1000

42

← x

0x1008

0x1000

← ptr  (stores x's address)

:::callout-key
Three operators to know cold:

- `&var` — **address-of**: gives the memory address of `var`
- `*type` in a declaration — declares a **pointer variable**
- `*ptr` in an expression — **dereference**: follows the pointer to the value it points at
:::

### Pointer types and null pointer

```cpp
int    x = 5;   int*    pi = &x;  // pointer to int
double d = 3.14; double* pd = &d; // pointer to double
char   c = 'A';  char*   pc = &c; // pointer to char

// Null pointer — points to nothing (safe "empty" state)
int* p = nullptr;    // C++11 preferred
int* q = NULL;       // older C-style (avoid in modern C++)

// Always check before dereferencing
if (p != nullptr) cout << *p;   // safe
// cout << *p;   // CRASH if p is nullptr — undefined behavior
```

:::callout-warning
Dereferencing a

nullptr

or an uninitialized pointer is undefined behavior and typically causes a segmentation fault (crash). Always initialize pointers — either to a valid address or to

nullptr

. Check for

nullptr

before dereferencing any pointer that might be null.
:::

### Pointer arithmetic

Adding an integer `n` to a pointer advances it by `n × sizeof(type)` bytes — exactly one element forward in an array.

```cpp
int arr[] = {10, 20, 30, 40};
int* p = arr;           // p points to arr[0]

cout << *p;             // 10
cout << *(p + 1);       // 20  (p + 1 → arr[1])
cout << *(p + 3);       // 40  (p + 3 → arr[3])

++p;                    // p now points to arr[1]
cout << *p;             // 20

// arr[i] is exactly equivalent to *(arr + i)
cout << arr[2];         // 30
cout << *(arr + 2);     // 30  — same thing
```

:::callout-intuition
Array indexing is pointer arithmetic in disguise.

arr[i]

compiles to exactly

\*(arr + i)

. Understanding this makes pointer-based linked-list code much more readable.
:::

## §8.2 – §8.3 · Dynamic Memory Allocation

All variables declared normally live on the **stack** — their memory is automatically reclaimed when the function returns. **Dynamic allocation** uses the **heap** — memory you request explicitly and must release explicitly.

### new and delete — single objects

```cpp
// Allocate a single int on the heap
int* p = new int;      // allocate, value uninitialized
int* q = new int(42);  // allocate and initialize to 42

cout << *q;  // 42

// You MUST release heap memory when done
delete p;
delete q;

// After delete, set to nullptr to prevent accidental reuse
p = nullptr;
q = nullptr;
```

### §8.2 Dynamically allocated arrays

```cpp
int n;
cout << "Enter size: ";
cin >> n;

// Allocate n ints at runtime — size doesn't need to be compile-time constant
int* arr = new int[n];

// Use it like a normal array
for (int i = 0; i < n; ++i) arr[i] = i * i;
for (int i = 0; i < n; ++i) cout << arr[i] << ' ';

// Release with delete[] (bracket form for arrays)
delete[] arr;
arr = nullptr;
```

:::callout-warning
- Use `delete` (no brackets) for single objects allocated with `new T`
- Use `delete[]` (brackets) for arrays allocated with `new T[n]`
- Mixing them is undefined behavior — typically a heap corruption crash
:::

### §8.3 Resizing a dynamically allocated array

Raw heap arrays cannot be resized in place. The manual approach: allocate a larger array, copy data, free the old one.

```cpp
int* resize(int* old, int oldSize, int newSize) {
    int* neo = new int[newSize];

    // Copy existing elements
    int copyCount = min(oldSize, newSize);
    for (int i = 0; i < copyCount; ++i) neo[i] = old[i];

    // Zero-initialize new slots (if expanding)
    for (int i = copyCount; i < newSize; ++i) neo[i] = 0;

    delete[] old;   // free old memory
    return neo;
}

int main() {
    int* data = new int[3]{1, 2, 3};
    data = resize(data, 3, 6);    // expand to 6
    for (int i = 0; i < 6; ++i) cout << data[i] << ' '; // 1 2 3 0 0 0
    delete[] data;
}
```

:::callout-connect
This manual resize is exactly what

std::vector

does internally — but automatically, with amortized doubling strategy, and with exception safety. This is why you almost always prefer

vector

over raw dynamic arrays.
:::

## §8.4 – §8.6 · Dynamically Allocating Objects

### §8.4 new and delete with classes

```cpp
struct Point {
    double x, y;
    Point(double x, double y) : x(x), y(y) {}
    void print() const { cout << "(" << x << ", " << y << ")\n"; }
};

int main() {
    // Stack allocation — automatic lifetime
    Point p1(1.0, 2.0);
    p1.print();

    // Heap allocation — manual lifetime
    Point* p2 = new Point(3.0, 4.0);
    p2->print();       // arrow operator: (*p2).print()
    delete p2;
    p2 = nullptr;
}
```

:::callout-key
The

arrow operator

->

is shorthand for dereference + member access:

ptr->member

means

(\*ptr).member

. You will use this constantly with linked lists and dynamically allocated objects.
:::

### §8.5 Arrays of objects

```cpp
// Heap array of 5 Points (requires default constructor)
struct Point { double x = 0, y = 0; };

Point* points = new Point[5];
points[2].x = 99.9;
points[2].y = -3.0;

// Iterate
for (int i = 0; i < 5; ++i)
    cout << "(" << points[i].x << ", " << points[i].y << ")\n";

delete[] points;
```

### §8.6 Classes with dynamically allocated data members

When a class owns heap memory (e.g., stores a pointer to a dynamic array), the constructor allocates it and the destructor must free it.

```cpp
class DynArray {
    int* data;
    int  size;
public:
    DynArray(int n) : size(n) {
        data = new int[n]();   // allocate + zero-initialize
    }
    ~DynArray() {              // destructor: always called when object is destroyed
        delete[] data;
    }
    int& operator[](int i) { return data[i]; }
    int  getSize() const    { return size; }
};

int main() {
    DynArray a(5);
    a[2] = 77;
    cout << a[2] << '\n';  // 77
    // destructor called automatically when 'a' goes out of scope
}
```

## §8.7 – §8.8 · String Pointers & A First Linked List

### §8.7 String functions with pointers

```cpp
// Implementing strlen manually to understand pointer traversal
size_t myStrlen(const char* s) {
    const char* p = s;
    while (*p != '\0') ++p;    // advance until null terminator
    return p - s;              // pointer difference = number of chars
}

// Implementing strchr: find first occurrence of c in s
char* myStrchr(char* s, char c) {
    while (*s != '\0') {
        if (*s == c) return s;  // return pointer to found character
        ++s;
    }
    return nullptr;             // not found
}

int main() {
    char msg[] = "hello world";
    cout << myStrlen(msg) << '\n';   // 11
    char* space = myStrchr(msg, ' ');
    if (space) cout << space << '\n'; // " world" (from space onward)
}
```

### §8.8 A first linked list

A **linked list** is a chain of **nodes**, each containing data and a pointer to the next node. Unlike arrays, nodes need not be contiguous in memory — each node is individually allocated on the heap.

```cpp
struct Node {
    int  data;
    Node* next;   // pointer to the next node (nullptr at tail)

    Node(int val) : data(val), next(nullptr) {}
};
```

Linked list: `head → [1] → [2] → [3] → nullptr`

head →

1

next →

→

2

next →

→

3

next →

→

nullptr

```cpp
#include <iostream>
using namespace std;

struct Node {
    int data; Node* next;
    Node(int v) : data(v), next(nullptr) {}
};

// Prepend a new node at the front — O(1)
void prepend(Node*& head, int val) {
    Node* neo = new Node(val);
    neo->next = head;
    head = neo;
}

// Append a new node at the back — O(n)
void append(Node*& head, int val) {
    Node* neo = new Node(val);
    if (!head) { head = neo; return; }
    Node* cur = head;
    while (cur->next) cur = cur->next;
    cur->next = neo;
}

// Print all nodes
void printList(Node* head) {
    for (Node* cur = head; cur; cur = cur->next)
        cout << cur->data << (cur->next ? " → " : " → nullptr\n");
}

// Free all nodes — MUST be called to avoid memory leak
void deleteList(Node*& head) {
    while (head) {
        Node* tmp = head;
        head = head->next;
        delete tmp;
    }
}

int main() {
    Node* head = nullptr;
    append(head, 1);
    append(head, 2);
    append(head, 3);
    printList(head);    // 1 → 2 → 3 → nullptr
    prepend(head, 0);
    printList(head);    // 0 → 1 → 2 → 3 → nullptr
    deleteList(head);
}
```

:::callout-pitfall
Notice

Node\*& head

— a

reference to a pointer

. This lets

prepend

and

append

modify the caller's

head

variable when the list was previously empty. Without the

&

, head would be a local copy and the caller's pointer would remain

nullptr

.
:::

## §8.9 – §8.12 · Heap vs. Stack, Destructors & Memory Leaks

### §8.9 Memory regions: Heap and Stack

| Property | Stack | Heap |
| --- | --- | --- |
| Allocation | Automatic (variable declaration) | Manual (`new`) |
| Deallocation | Automatic (function return) | Manual (`delete`) |
| Size | Limited (typically 1–8 MB) | Large (limited by RAM) |
| Speed | Very fast (just move stack pointer) | Slower (allocator bookkeeping) |
| Lifetime | Until end of enclosing scope | Until explicitly deleted |
| Use for | Local variables, function calls | Data whose size/lifetime is unknown at compile time |

```cpp
void example() {
    int stack_var = 5;         // stack — gone when example() returns
    int* heap_var = new int(5);// heap — survives function return
    // ...
    delete heap_var;           // must free manually
}  // stack_var automatically freed here; heap_var's memory freed by delete above
```

:::callout-warning
Stack overflow

occurs when the stack runs out of space — most commonly from infinite recursion. Each function call pushes a frame; if calls never return, the stack fills up and the program crashes.
:::

### §8.10 Destructors

A **destructor** is a special member function called automatically when an object is destroyed (goes out of scope or is `delete`d). Its job is to release any resources the object owns.

```cpp
class Buffer {
    char* data;
    int   capacity;
public:
    Buffer(int cap) : capacity(cap) {
        data = new char[cap];
        cout << "Buffer allocated\n";
    }

    ~Buffer() {                    // destructor — same name with ~
        delete[] data;
        cout << "Buffer freed\n";
    }

    void write(int i, char c) { data[i] = c; }
};

int main() {
    {
        Buffer b(1024);            // constructor called
        b.write(0, 'H');
    }                              // destructor called automatically here
    // "Buffer freed" is printed
}
```

:::callout-key
If your class owns heap memory (has a pointer data member that it

new

s), it almost certainly needs a

destructor

to

delete

that memory. Forgetting it causes a memory leak every time an object of that class is destroyed.
:::

### §8.11 Memory leaks

A **memory leak** occurs when heap memory is allocated but never freed. The program consumes more and more RAM over time until it crashes or is killed.

```cpp
// LEAK 1 — forgetting delete
void leaky() {
    int* p = new int(42);
    // function returns without delete p; — 4 bytes leaked every call
}

// LEAK 2 — pointer reassigned before delete
int* p = new int(1);
p = new int(2);     // the first int (value 1) is now unreachable — leaked!
delete p;           // only frees the second int

// LEAK 3 — exception before delete (this is why RAII / smart pointers exist)
int* arr = new int[100];
doSomethingThatThrows();   // if this throws, delete[] arr is never reached
delete[] arr;
```

### §8.12 Destructors for linked lists

```cpp
class LinkedList {
    struct Node { int data; Node* next; Node(int v):data(v),next(nullptr){} };
    Node* head = nullptr;
public:
    void append(int val) {
        Node* n = new Node(val);
        if (!head) { head = n; return; }
        Node* c = head; while(c->next) c=c->next; c->next = n;
    }

    ~LinkedList() {                 // frees every node
        while (head) {
            Node* tmp = head;
            head = head->next;
            delete tmp;
        }
    }

    void print() const {
        for (Node* c = head; c; c = c->next)
            cout << c->data << (c->next ? " → " : " → nullptr\n");
    }
};

int main() {
    LinkedList lst;
    lst.append(10); lst.append(20); lst.append(30);
    lst.print();    // 10 → 20 → 30 → nullptr
}   // destructor automatically walks the list and deletes every Node
```

## §8.13 – §8.15 · Copy Constructor, Copy Assignment & the Rule of Three

### §8.13 The shallow-copy problem

By default, copying an object copies its data members byte-for-byte. For pointer members this gives two objects pointing to the *same* heap allocation — a **shallow copy**. When either object is destroyed, the shared memory is freed, and the surviving pointer becomes a *dangling pointer*.

```cpp
class Bad {
public:
    int* data;
    Bad(int v)  { data = new int(v); }
    ~Bad()      { delete data; }
    // No copy constructor — compiler generates a shallow copy!
};

int main() {
    Bad a(5);
    Bad b = a;     // b.data == a.data — they share the same heap int!
}                  // both destructors run → double-free → CRASH
```

### §8.13 Copy constructor — deep copy

```cpp
class Good {
    int* data;
public:
    Good(int v)  { data = new int(v); }
    ~Good()      { delete data; }

    // Copy constructor: allocate FRESH memory and copy the VALUE
    Good(const Good& other) {
        data = new int(*other.data);   // deep copy
    }

    int get() const { return *data; }
};

int main() {
    Good a(5);
    Good b = a;       // calls copy constructor — b gets its own heap int
    *b.data = 99;
    cout << a.get() << ' ' << b.get() << '\n'; // 5 99 — independent!
}
```

### §8.14 Copy assignment operator

```cpp
Good& operator=(const Good& other) {
    if (this == &other) return *this;   // self-assignment guard
    delete data;                         // free existing heap memory
    data = new int(*other.data);         // deep copy
    return *this;                        // enable chaining: a = b = c
}
```

### §8.15 The Rule of Three

:::callout-key
Rule of Three

: if a class needs any one of the following, it almost certainly needs all three:

1. **Destructor** — to free owned resources
2. **Copy constructor** — to deep-copy when initialized from another instance
3. **Copy assignment operator** — to deep-copy when assigned after construction

The typical trigger: the class has a

pointer data member

it allocates with

new

.
:::

In C++11 and later there is a **Rule of Five** that adds move constructor and move assignment — but that is beyond this course. The key takeaway: if you write a destructor, write the other two as well.

## §8.16 · Smart Pointers

**Smart pointers** are wrapper classes that own a heap allocation and automatically call `delete` when they go out of scope — eliminating most manual memory management and its associated bugs.

```cpp
#include <memory>
using namespace std;

int main() {
    // unique_ptr — sole owner; deleted when it goes out of scope
    unique_ptr<int> p = make_unique<int>(42);
    cout << *p << '\n';   // 42
    // no delete needed — automatic

    // unique_ptr for arrays
    unique_ptr<int[]> arr = make_unique<int[]>(5);
    arr[0] = 10; arr[1] = 20;

    // shared_ptr — reference-counted; deleted when last owner is gone
    shared_ptr<int> s1 = make_shared<int>(99);
    shared_ptr<int> s2 = s1;           // both own the same int
    cout << s1.use_count() << '\n';    // 2 — two owners
}   // s1 and s2 both destroyed here → count reaches 0 → int deleted
```

| Smart pointer | Ownership | Use when |
| --- | --- | --- |
| `unique_ptr<T>` | Exclusive (one owner) | Most cases — prefer this by default |
| `shared_ptr<T>` | Shared (reference counted) | Multiple owners need the same object |
| `weak_ptr<T>` | Non-owning observer | Break cycles in graphs/trees |

:::callout-connect
Modern C++ style: use smart pointers instead of raw

new

/

delete

almost everywhere. Raw pointers are still used for

non-owning

references (e.g., navigating a linked list without claiming ownership). You will encounter both styles in real codebases and interview problems.
:::

## §8.17 · Worked Example — Employee List Using Dynamic Allocation

#### Employee roster with dynamic array and encapsulated resize

```cpp
#include <iostream>
#include <string>
using namespace std;

struct Employee {
    string name;
    double salary;
};

class EmployeeList {
    Employee* data;
    int       count;
    int       capacity;

    void grow() {
        int newCap = capacity * 2;
        Employee* neo = new Employee[newCap];
        for (int i = 0; i < count; ++i) neo[i] = data[i];
        delete[] data;
        data = neo;
        capacity = newCap;
    }

public:
    EmployeeList(int cap = 4) : count(0), capacity(cap) {
        data = new Employee[cap];
    }

    ~EmployeeList() { delete[] data; }

    // Rule of Three — deep copy
    EmployeeList(const EmployeeList& o) : count(o.count), capacity(o.capacity) {
        data = new Employee[capacity];
        for (int i = 0; i < count; ++i) data[i] = o.data[i];
    }

    void add(const string& name, double salary) {
        if (count == capacity) grow();
        data[count++] = {name, salary};
    }

    void printAll() const {
        for (int i = 0; i < count; ++i)
            cout << data[i].name << ": $" << data[i].salary << '\n';
    }

    double totalPayroll() const {
        double total = 0;
        for (int i = 0; i < count; ++i) total += data[i].salary;
        return total;
    }
};

int main() {
    EmployeeList roster;
    roster.add("Alice", 75000);
    roster.add("Bob",   62000);
    roster.add("Carol", 88000);
    roster.add("Dan",   71000);
    roster.add("Eve",   95000);   // triggers grow() — doubles capacity

    roster.printAll();
    cout << "Total payroll: $" << roster.totalPayroll() << '\n';
}
```

:::summary
### Chapter 8 — Key Takeaways

- `&var` gives the address of `var`; `*ptr` dereferences a pointer to get the value it points at.
- Always initialize pointers — to a valid address or `nullptr`. Never dereference `nullptr`.
- `new T` allocates one object on the heap; `new T[n]` allocates an array. Match with `delete` or `delete[]` respectively.
- The **heap** has large, manually managed lifetime. The **stack** is fast, small, and automatic.
- The **arrow operator** `ptr->member` is equivalent to `(*ptr).member`.
- A linked list node contains `data` and a `next` pointer. Walk with `cur = cur->next`; stop when `cur == nullptr`.
- Destructors free owned heap memory automatically when an object is destroyed.
- **Rule of Three**: a class with a destructor almost always needs a copy constructor and copy assignment operator too — otherwise you get a dangerous shallow copy.
- Prefer `unique_ptr` over raw `new`/`delete` — it eliminates leaks and double-frees automatically.
- `vector` and `string` are already RAII — they own their memory and clean up correctly. Use them instead of raw dynamic arrays whenever possible.
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Pointer Swap

Without using `std::swap`, write a function `void swapViaPointers(int* a, int* b)` that swaps the two ints using pointer dereferencing. Verify it works in `main`.

::::solution[Solution]
```cpp
void swapViaPointers(int* a, int* b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}
int main() {
    int x = 10, y = 20;
    swapViaPointers(&x, &y);
    cout << x << ' ' << y << '\n';  // 20 10
}
```

Pass the addresses with `&`; inside the function dereference with `*` to get/set the values.
::::
:::

:::problem{difficulty="easy"}
P2 — Middle of a Linked List

Given the head of a singly-linked list, find and return the middle node. If there are two middle nodes, return the second one. Example: `1→2→3→4→5` → return node `3`. Use the fast/slow pointer technique.

::::solution[Solution]
```cpp
struct Node { int data; Node* next; Node(int v):data(v),next(nullptr){} };

Node* findMiddle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;          // advances 1 step
        fast = fast->next->next;    // advances 2 steps
    }
    return slow;   // when fast reaches end, slow is at middle
}
// 1→2→3→4→5 → returns node with data=3
// 1→2→3→4   → returns node with data=3 (second middle)
```

**Fast/slow pointer**: fast moves twice as quickly. When fast hits the end, slow has only traveled half the distance — exactly the middle.
::::
:::

:::problem{difficulty="standard"}
P3 — Remove Duplicates from Sorted List

Given a sorted linked list, delete all duplicate nodes so each value appears only once. Do it in-place by relinking. Example: `1→1→2→3→3` → `1→2→3`.

::::solution[Solution]
```cpp
Node* removeDuplicates(Node* head) {
    Node* cur = head;
    while (cur && cur->next) {
        if (cur->data == cur->next->data) {
            Node* dup = cur->next;
            cur->next = dup->next;  // bypass the duplicate
            delete dup;             // free its memory
        } else {
            cur = cur->next;        // move forward only when no dup
        }
    }
    return head;
}
```

Because the list is sorted, duplicates are always adjacent. We only advance `cur` when the next node is different — otherwise we delete it and recheck the new `cur->next`.
::::
:::

:::problem{difficulty="standard"}
P4 — Merge Two Sorted Lists

Given the heads of two sorted linked lists, merge them into one sorted list and return the head. Reuse existing nodes — do not allocate new ones.

::::solution[Solution]
```cpp
Node* mergeSorted(Node* l1, Node* l2) {
    // Dummy head simplifies edge cases
    Node dummy(0);
    Node* tail = &dummy;
    while (l1 && l2) {
        if (l1->data <= l2->data) { tail->next = l1; l1 = l1->next; }
        else                        { tail->next = l2; l2 = l2->next; }
        tail = tail->next;
    }
    tail->next = l1 ? l1 : l2;   // attach remainder
    return dummy.next;
}
// l1: 1→3→5  l2: 2→4→6  →  1→2→3→4→5→6
```

The **dummy head** trick avoids special-casing the first node. `tail` always points to the last node of the merged list; we advance it after each attachment.
::::
:::

:::problem{difficulty="challenge"}
P5 — Deep Copy a Linked List

Write a function `Node* deepCopy(Node* head)` that returns a completely independent copy of the linked list — every node newly allocated, values identical, original untouched.

::::solution[Solution]
```cpp
Node* deepCopy(Node* head) {
    if (!head) return nullptr;
    Node dummy(0);
    Node* tail = &dummy;
    for (Node* cur = head; cur; cur = cur->next) {
        tail->next = new Node(cur->data);  // allocate fresh node
        tail = tail->next;
    }
    return dummy.next;
}
```

Walk the original list; for each node create a brand-new `Node` with the same data and append it to the copy. The dummy head simplifies building the new list without special-casing the first node.
::::
:::

:::callout-tip
Linked list problems are almost always solved via pointer manipulation — exactly what this chapter covers. Practice drawing the pointer state before and after each operation.

| # | Problem | Difficulty | Key Technique |
| --- | --- | --- | --- |
| 21 | [Merge Two Sorted Lists](https://leetcode.com/problems/merge-two-sorted-lists/) | Easy | Dummy head, pointer relinking |
| 876 | [Middle of the Linked List](https://leetcode.com/problems/middle-of-the-linked-list/) | Easy | Fast/slow (tortoise & hare) pointers |
| 83 | [Remove Duplicates from Sorted List](https://leetcode.com/problems/remove-duplicates-from-sorted-list/) | Easy | Single-pass pointer traversal, delete & relink |
:::
