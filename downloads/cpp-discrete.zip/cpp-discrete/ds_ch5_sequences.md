---
title: "DS–5: Sequences & Summations"
source: "ds_ch5_sequences.html"
---

CSE 2813

# DS–5: Sequences & Summations

§5.1 – §5.7

:::callout-connect
Why sequences and summations?

Every loop in a program produces a sequence of states. Every running-time analysis reduces to evaluating a sum. Understanding how to compute closed-form expressions for sums — instead of adding up millions of terms — is what separates efficient algorithm analysis from brute-force calculation. The formulas in this chapter appear in almost every Big-O proof you'll write.
:::

## §5.1 — Sequences

:::definition[Definition]
Sequence

A **sequence** is a function from a subset of integers (usually $\mathbb{N}$ or $\mathbb{Z}^+$) to a set $S$. The value at index $n$ is the **$n$-th term**, written $a_n$. A sequence is usually written as $\{a_n\}$ or listed as $a_1, a_2, a_3, \ldots$
:::

### Arithmetic Sequences

An **arithmetic sequence** has a constant difference $d$ between consecutive terms: $a_n = a_1 + (n-1)d$.

3 — 7 — 11 — 15 — 19 — … — $a_1=3$, $d=4$, $a_n = 3 + 4(n-1) = 4n - 1$

**Sum of first $n$ terms:** $S_n = \dfrac{n(a_1 + a_n)}{2} = \dfrac{n(2a_1 + (n-1)d)}{2}$

### Geometric Sequences

A **geometric sequence** has a constant ratio $r$ between consecutive terms: $a_n = a_1 \cdot r^{n-1}$.

2 — 6 — 18 — 54 — 162 — … — $a_1=2$, $r=3$, $a_n = 2 \cdot 3^{n-1}$

**Sum of first $n$ terms ($r \neq 1$):** $S_n = a_1 \cdot \dfrac{r^n - 1}{r - 1}$

### Recurrence Relations

A **recurrence relation** defines each term using previous terms. The sequence is fully determined once enough initial terms (base cases) are given.

| Recurrence | Base Case(s) | Named Sequence | First few terms |
| --- | --- | --- | --- |
| $a_n = a_{n-1} + a_{n-2}$ | $a_1=1, a_2=1$ | Fibonacci | 1, 1, 2, 3, 5, 8, 13, 21, … |
| $a_n = 2a_{n-1}$ | $a_1=1$ | Powers of 2 | 1, 2, 4, 8, 16, … |
| $a_n = a_{n-1} + n$ | $a_0=0$ | Triangular numbers | 0, 1, 3, 6, 10, 15, … |
| $a_n = n \cdot a_{n-1}$ | $a_0=1$ | Factorial | 1, 1, 2, 6, 24, 120, … |

:::callout-connect
Recurrences → algorithm analysis:

Recursive algorithms naturally produce recurrences. Merge sort: $T(n) = 2T(n/2) + n$ (divide step + merge step). Binary search: $T(n) = T(n/2) + 1$. Solving these recurrences — finding closed forms — is the heart of the Master Theorem (DS–9 / C++ Ch 10).
:::

## §5.2 — Summation Notation

:::definition[Definition]
Sigma Notation

$\displaystyle\sum_{i=m}^{n} a_i = a_m + a_{m+1} + \cdots + a_n$

$i$ is the **index of summation**, $m$ is the **lower limit**, $n$ is the **upper limit**.
:::

Reading Sigma Notation

| Sigma Expression | Expanded | Value |
| --- | --- | --- |
| $\displaystyle\sum_{i=1}^{5} i$ | $1+2+3+4+5$ | $15$ |
| $\displaystyle\sum_{i=0}^{4} 2^i$ | $1+2+4+8+16$ | $31$ |
| $\displaystyle\sum_{i=1}^{n} c$ | $c + c + \cdots + c$ ($n$ times) | $cn$ |
| $\displaystyle\sum_{i=1}^{n} i^2$ | $1+4+9+\cdots+n^2$ | $\frac{n(n+1)(2n+1)}{6}$ |

### Properties of Summation

| Property | Formula |
| --- | --- |
| Linearity (scalar) | $\displaystyle\sum_{i=m}^{n} ca_i = c\sum_{i=m}^{n} a_i$ |
| Linearity (sum) | $\displaystyle\sum_{i=m}^{n} (a_i + b_i) = \sum_{i=m}^{n} a_i + \sum_{i=m}^{n} b_i$ |
| Index shift | $\displaystyle\sum_{i=m}^{n} a_i = \sum_{j=m+k}^{n+k} a_{j-k}$ (substitute $j=i+k$) |
| Split range | $\displaystyle\sum_{i=1}^{n} a_i = \sum_{i=1}^{k} a_i + \sum_{i=k+1}^{n} a_i$ |

:::callout-pitfall
Off-by-one errors in sigma:

$\displaystyle\sum_{i=0}^{n} a_i$ has $n+1$ terms (indices 0 through $n$). $\displaystyle\sum_{i=1}^{n} a_i$ has $n$ terms. Always count the terms before applying a formula — this is the summation equivalent of array index bugs.
:::

## §5.3 — Closed-Form Summation Identities

These identities are essential tools. You should know them cold — they appear in nearly every algorithm analysis.

Constant Sum

$\displaystyle\sum_{i=1}^{n} 1 = n$

Count of terms

Triangular / Arithmetic Sum

$\displaystyle\sum_{i=1}^{n} i = \dfrac{n(n+1)}{2}$

$\approx n^2/2$ for large $n$

Sum of Squares

$\displaystyle\sum_{i=1}^{n} i^2 = \dfrac{n(n+1)(2n+1)}{6}$

$\approx n^3/3$ for large $n$

Sum of Cubes

$\displaystyle\sum_{i=1}^{n} i^3 = \left(\dfrac{n(n+1)}{2}\right)^2$

Square of the triangular number!

Geometric Series (finite)

$\displaystyle\sum_{i=0}^{n} r^i = \dfrac{r^{n+1}-1}{r-1},\ r\neq 1$

For $r=2$: $2^{n+1}-1$

Geometric Series (infinite)

$\displaystyle\sum_{i=0}^{\infty} r^i = \dfrac{1}{1-r},\ |r|<1$

Convergent when $|r| < 1$

Harmonic Series

$\displaystyle\sum_{i=1}^{n} \frac{1}{i} \approx \ln n + \gamma$

$\gamma \approx 0.5772$ (Euler–Mascheroni). Diverges as $n \to \infty$.

Telescoping Sum

$\displaystyle\sum_{i=1}^{n} (a_i - a_{i-1}) = a_n - a_0$

Middle terms cancel; only endpoints survive

### Proof of the Triangular Sum Formula

Claim: $1 + 2 + \cdots + n = n(n+1)/2$

**Gauss's pairing trick:** Write the sum forwards and backwards, then add column-by-column:

$S = 1 + 2 + 3 + \cdots + (n-1) + n$

$S = n + (n-1) + (n-2) + \cdots + 2 + 1$

$2S = (n+1) + (n+1) + \cdots + (n+1)$ ($n$ pairs)

$2S = n(n+1) \quad \Rightarrow \quad S = \dfrac{n(n+1)}{2}$ ∎

## §5.4 — Double Summations

A **double summation** sums over two indices — like a nested loop.

$\displaystyle\sum_{i=1}^{m}\sum_{j=1}^{n} a_{ij}$
  =   sum over all pairs $(i,j)$ with $1 \leq i \leq m$, $1 \leq j \leq n$

Example — Evaluate $\displaystyle\sum_{i=1}^{3}\sum_{j=1}^{2} (i+j)$

:::answer
| $i \backslash j$ | $j=1$ | $j=2$ | Row sum |
| --- | --- | --- | --- |
| $i=1$ | 2 | 3 | 5 |
| $i=2$ | 3 | 4 | 7 |
| $i=3$ | 4 | 5 | 9 |
| **Total** |  |  | **21** |
:::

### Swapping Order of Summation

When the limits are independent (rectangular range), the order of summation can be swapped:

$\displaystyle\sum_{i=1}^{m}\sum_{j=1}^{n} a_{ij} = \sum_{j=1}^{n}\sum_{i=1}^{m} a_{ij}$

:::callout-connect
Algorithm analysis:

Counting the operations of a nested loop with independent bounds is a double summation. The inner loop runs $n$ times for each of the $m$ outer iterations → total = $\displaystyle\sum_{i=1}^{m}\sum_{j=1}^{n} 1 = mn$ operations, giving $O(mn)$ or $O(n^2)$ if $m=n$.
:::

## §5.5 — Product Notation

:::definition[Definition]
Pi Notation

$\displaystyle\prod_{i=m}^{n} a_i = a_m \cdot a_{m+1} \cdots a_n$
:::

The most important product in discrete math is the factorial:

$n! = \displaystyle\prod_{i=1}^{n} i = 1 \cdot 2 \cdot 3 \cdots n$    (with $0! = 1$ by convention)

### Stirling's Approximation

For large $n$, $n! \approx \sqrt{2\pi n}\left(\dfrac{n}{e}\right)^n$. This gives us $\log(n!) \approx n\log n - n\log e = \Theta(n \log n)$, which explains why comparison-based sorting is $\Omega(n \log n)$ — the information-theoretic lower bound uses $\log(n!)$.

### Falling and Rising Factorials

| Name | Notation | Formula | Use |
| --- | --- | --- | --- |
| Falling factorial | $n^{\underline{k}}$ or $(n)_k$ | $n(n-1)\cdots(n-k+1)$ | Permutations: $P(n,k) = n^{\underline{k}}$ |
| Rising factorial | $n^{\overline{k}}$ | $n(n+1)\cdots(n+k-1)$ | Combinatorics, generating functions |

## §5.6 — Summations in Algorithm Analysis

This section shows how the identities above translate directly into Big-O bounds for common algorithm patterns.

| Loop Pattern | Summation | Closed Form | Big-O |
| --- | --- | --- | --- |
| `for i in 1..n: O(1) work` | $\displaystyle\sum_{i=1}^{n} 1$ | $n$ | $O(n)$ |
| `for i in 1..n: for j in 1..n` | $\displaystyle\sum_{i=1}^{n}\sum_{j=1}^{n} 1$ | $n^2$ | $O(n^2)$ |
| `for i in 1..n: for j in 1..i` | $\displaystyle\sum_{i=1}^{n} i$ | $\frac{n(n+1)}{2}$ | $O(n^2)$ |
| `for i in 1..n: for j in i..n` (bubble sort inner) | $\displaystyle\sum_{i=1}^{n}(n-i+1)$ | $\frac{n(n+1)}{2}$ | $O(n^2)$ |
| `while n > 1: n = n/2` | $\displaystyle\sum_{i=0}^{\lfloor\log_2 n\rfloor} 1$ | $\lfloor\log_2 n\rfloor + 1$ | $O(\log n)$ |
| Merge sort total merging work | $\displaystyle\sum_{k=0}^{\log_2 n} 2^k \cdot \frac{n}{2^k}$ | $n\log_2 n$ | $O(n\log n)$ |
| Full binary tree nodes at all levels | $\displaystyle\sum_{k=0}^{h} 2^k$ | $2^{h+1}-1$ | $O(2^h)$ or $O(n)$ |

### Worked Example — Bubble Sort Inner Loop

Count comparisons in bubble sort (outer loop i from 1 to n, inner loop j from 1 to n−i)

$T(n) = \displaystyle\sum_{i=1}^{n-1}(n-i) = (n-1) + (n-2) + \cdots + 1 = \dfrac{(n-1)n}{2} = \dfrac{n^2-n}{2}$

Reindexing: let $k = n-i$, so $k$ ranges from $n-1$ down to 1: $\displaystyle\sum_{k=1}^{n-1} k = \dfrac{(n-1)n}{2}$. This is $\Theta(n^2)$. ∎

:::callout-key
General strategy for loop counting:

1. Identify the innermost operation and count it as 1.
2. Write the count as a summation matching the loop bounds.
3. Apply identities to get a closed form.
4. Drop constants and lower-order terms → Big-O.
:::

## §5.7 — Special Sequences in CS

### Fibonacci Numbers

$F_1=1, F_2=1, F_n = F_{n-1} + F_{n-2}$. Closed form (Binet's formula): $F_n = \dfrac{\phi^n - \hat\phi^n}{\sqrt{5}}$ where $\phi = \dfrac{1+\sqrt{5}}{2} \approx 1.618$ (golden ratio) and $\hat\phi = \dfrac{1-\sqrt{5}}{2}$.

:::callout-intuition
Fibonacci in nature and CS:

Fibonacci numbers appear in branching trees, flower spirals, and — most relevantly — in AVL tree minimum-size bounds. An AVL tree of height $h$ has at least $F_{h+2} - 1$ nodes, which grows as $\phi^h/\sqrt{5}$. This is why AVL trees are guaranteed $O(\log n)$ height.
:::

### Catalan Numbers

$C_n = \dfrac{1}{n+1}\binom{2n}{n}$. First few: 1, 1, 2, 5, 14, 42, 132, 429, …

Catalan numbers count: the number of valid bracket sequences of length $2n$, the number of binary trees with $n$ nodes, the number of ways to triangulate a convex polygon.

### Number-Theoretic Sequences (for CS)

| Sequence | Formula | CS Relevance |
| --- | --- | --- |
| Primes | No simple closed form; $\pi(n) \approx n/\ln n$ | Cryptography, hashing |
| Powers of 2 | $2^n$ | Memory, binary representation, hash table sizing |
| $\binom{n}{k}$ (binomial coefficients) | $\dfrac{n!}{k!(n-k)!}$ | Counting, probability, Pascal's triangle |

:::summary
## Chapter Summary — DS–5: Sequences & Summations

- **Arithmetic sequences:** constant difference $d$; $a_n = a_1 + (n-1)d$; sum $= n(a_1+a_n)/2$.
- **Geometric sequences:** constant ratio $r$; $a_n = a_1 r^{n-1}$; sum $= a_1(r^n-1)/(r-1)$ for $r \neq 1$.
- **Recurrences** define terms from previous terms. Fibonacci, powers of 2, triangular numbers, factorials are all recurrences. Algorithm run-times are recurrences.
- **Sigma notation:** $\sum_{i=m}^{n} a_i$. Linearity (scale, split) and index-shifting are the core manipulation tools.
- **Key identities:** $\sum i = n(n+1)/2$; $\sum i^2 = n(n+1)(2n+1)/6$; $\sum r^i = (r^{n+1}-1)/(r-1)$; telescoping; harmonic. Know these cold.
- **Double summations** correspond to nested loops. Swapping summation order is valid for rectangular (independent) index ranges.
- **Algorithm analysis:** Count inner operations, write as a sum, apply identities. Bubble sort → $n(n-1)/2$ → $O(n^2)$. Merge sort merging → $n\log n$ → $O(n\log n)$.
- **Catalan numbers** count balanced bracket sequences, binary tree shapes, and other recursive combinatorial structures. Appear frequently in DP problems.
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Evaluate Summations

Evaluate using closed-form identities: (a) $\displaystyle\sum_{i=1}^{100} i$, (b) $\displaystyle\sum_{i=0}^{7} 3^i$, (c) $\displaystyle\sum_{i=1}^{10} (2i-1)$ (sum of first 10 odd numbers).

::::solution[Solution]
**(a)** $\dfrac{100 \cdot 101}{2} = 5050$. (The famous Gauss story!)

**(b)** $\dfrac{3^8-1}{3-1} = \dfrac{6561-1}{2} = \dfrac{6560}{2} = 3280$.

**(c)** $\displaystyle\sum_{i=1}^{10}(2i-1) = 2\sum_{i=1}^{10}i - \sum_{i=1}^{10}1 = 2 \cdot \dfrac{10\cdot11}{2} - 10 = 110 - 10 = 100$. (Sum of first $n$ odd numbers is always $n^2$!)
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Write Sigma Notation

Express each sum using sigma notation, then evaluate: (a) $2 + 4 + 6 + 8 + 10 + 12$ (b) $1 + 1/2 + 1/4 + 1/8 + 1/16$ (c) $1^2 - 2^2 + 3^2 - 4^2 + 5^2$.

::::solution[Solution]
**(a)** $\displaystyle\sum_{i=1}^{6} 2i = 2\cdot\dfrac{6\cdot7}{2} = 42$

**(b)** $\displaystyle\sum_{i=0}^{4}\left(\dfrac{1}{2}\right)^i = \dfrac{(1/2)^5-1}{(1/2)-1} = \dfrac{1/32-1}{-1/2} = \dfrac{-31/32}{-1/2} = \dfrac{31}{16}$

**(c)** $\displaystyle\sum_{i=1}^{5}(-1)^{i+1}i^2 = 1 - 4 + 9 - 16 + 25 = 15$
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Algorithm Analysis via Summation

Count the number of times the inner print executes in each algorithm, expressing as a closed-form (no sigma), then give Big-O:

```cpp
// (a)
for (int i = 1; i <= n; i++)
    for (int j = i; j <= n; j++)
        print("*");

// (b)
for (int i = n; i >= 1; i /= 2)
    for (int j = 1; j <= i; j++)
        print("*");
```

::::solution[Solution]
**(a)** Outer loop: $i$ from 1 to $n$. Inner loop: $j$ from $i$ to $n$ → $(n - i + 1)$ iterations.

$T = \displaystyle\sum_{i=1}^{n}(n-i+1) = \sum_{k=1}^{n} k = \dfrac{n(n+1)}{2}$ (substituting $k = n-i+1$). Big-O: $O(n^2)$.

**(b)** Outer loop: $i = n, n/2, n/4, \ldots, 1$ → $\lfloor\log_2 n\rfloor + 1$ iterations. At step $k$ (0-indexed), $i = n/2^k$, so inner loop runs $n/2^k$ times.

$T = \displaystyle\sum_{k=0}^{\log_2 n}\frac{n}{2^k} = n\sum_{k=0}^{\log_2 n}\left(\frac{1}{2}\right)^k \approx n \cdot \dfrac{1}{1-1/2} = 2n$. Big-O: $O(n)$.
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Recurrence — Find First 8 Terms and Identify Pattern

Given $a_0 = 1$, $a_n = 3a_{n-1} - 1$ for $n \geq 1$. (a) Compute $a_0$ through $a_5$. (b) Guess the closed form. (c) Prove your closed form by induction.

::::solution[Solution]
**(a)** $a_0=1$, $a_1=2$, $a_2=5$, $a_3=14$, $a_4=41$, $a_5=122$.

**(b)** $a_n = \dfrac{3^n+1}{2}$. Check: $a_0=(1+1)/2=1$✓, $a_1=(3+1)/2=2$✓, $a_2=(9+1)/2=5$✓.

**(c) Induction.** Base: $a_0=(3^0+1)/2=(1+1)/2=1$. ✓

IH: $a_k = (3^k+1)/2$. Show $a_{k+1} = (3^{k+1}+1)/2$.

$a_{k+1} = 3a_k - 1 = 3\cdot\dfrac{3^k+1}{2} - 1 = \dfrac{3^{k+1}+3}{2} - \dfrac{2}{2} = \dfrac{3^{k+1}+1}{2}$. ✓ ∎
::::
:::

:::problem[P5]{difficulty="standard"}
P5 — Double Summation

Compute $\displaystyle\sum_{i=1}^{n}\sum_{j=1}^{i} j$ in closed form. Interpret this as a loop-count for a triangular nested loop.

::::solution[Solution]
The inner sum: $\displaystyle\sum_{j=1}^{i} j = \dfrac{i(i+1)}{2}$.

Now sum over $i$: $\displaystyle\sum_{i=1}^{n}\dfrac{i(i+1)}{2} = \dfrac{1}{2}\sum_{i=1}^{n}(i^2+i) = \dfrac{1}{2}\left[\dfrac{n(n+1)(2n+1)}{6} + \dfrac{n(n+1)}{2}\right]$

$= \dfrac{n(n+1)}{2}\cdot\dfrac{1}{2}\left[\dfrac{2n+1}{3}+1\right] = \dfrac{n(n+1)}{4}\cdot\dfrac{2n+4}{3} = \dfrac{n(n+1)(n+2)}{6}$

This is $\binom{n+2}{3}$ — the tetrahedral number! Big-O: $O(n^3)$... wait, let's recount. The outer sum has $n$ terms each $\leq n$, so this is $O(n^3/6)=O(n^3)$. Actually the result is $O(n^3)$ but specifically $n(n+1)(n+2)/6 = \Theta(n^3)$.

**Loop interpretation:** `for i in 1..n: for j in 1..i: inner_work(j)` where work is proportional to $j$ — the total is $\Theta(n^3)$. Cubic!
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — Geometric Series + Merge Sort Analysis

Prove that the total work done by merge sort on $n = 2^k$ elements is exactly $n\log_2 n$ comparisons (in terms of merge operations). The work at each level of the recursion tree is $n$ total, and there are $\log_2 n$ levels. Formalize this as a geometric series evaluation.

::::solution[Solution]
At recursion depth $d$ (counting from 0 at the top), there are $2^d$ subproblems each of size $n/2^d$. Each merge of two subarrays of size $n/2^{d+1}$ does at most $n/2^d$ comparisons. Total work at depth $d$: $2^d \cdot (n/2^d) = n$.

The recursion has depth $0, 1, \ldots, \log_2 n - 1$ (base cases at depth $\log_2 n$ are size-1, no merging). So total:

$T(n) = \displaystyle\sum_{d=0}^{\log_2 n - 1} n = n \cdot \log_2 n$

The sum $\sum_{d=0}^{\log_2 n - 1} n$ is a constant-term sum (not geometric), giving $n \cdot \log_2 n$ directly. The "geometric series" structure is in the fact that at each level, $2^d$ subproblems of size $n/2^d$ — the product $2^d \cdot (n/2^d) = n$ stays constant, making each level contribute identically. This constant per level × $\log n$ levels = $n \log n$ total. ∎
::::
:::

## LeetCode Connections

| # | Problem | Difficulty | Connection |
| --- | --- | --- | --- |
| [#1480](https://leetcode.com/problems/running-sum-of-1d-array/) | Running Sum of 1D Array | Easy | Prefix sums = partial sums of a sequence: $S_k = \sum_{i=1}^{k} a_i$. The recurrence $S_k = S_{k-1} + a_k$ is the definition of a cumulative sum — direct application of §5.1 recurrences. |
| [#509](https://leetcode.com/problems/fibonacci-number/) | Fibonacci Number | Easy | Directly computes $F_n$ via the Fibonacci recurrence from §5.1. The iterative DP approach uses exactly two variables — the minimum space needed because only the last two terms are required. |
| [#303](https://leetcode.com/problems/range-sum-query-immutable/) | Range Sum Query — Immutable | Easy | $\text{sum}(i,j) = S_j - S_{i-1}$ where $S_k = \sum_{t=0}^{k} a_t$. Classic use of the summation telescoping identity: the range sum is the difference of two prefix sums. $O(1)$ per query after $O(n)$ preprocessing. |
| [#1137](https://leetcode.com/problems/nth-tribonacci-number/) | N-th Tribonacci Number | Easy | Recurrence with 3 base cases: $T_n = T_{n-1} + T_{n-2} + T_{n-3}$. Extends the Fibonacci recurrence (§5.1/§5.7). Requires strong induction for correctness proof — directly from DS–2. |
| [#96](https://leetcode.com/problems/unique-binary-search-trees/) | Unique Binary Search Trees | Medium | The answer is the $n$-th Catalan number $C_n = \binom{2n}{n}/(n+1)$ from §5.7. The recurrence $C_n = \sum_{i=0}^{n-1} C_i C_{n-1-i}$ is the convolution form; solving it by DP is the standard approach. |
