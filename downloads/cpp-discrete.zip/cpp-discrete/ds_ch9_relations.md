---
title: "DS–9: Relations"
source: "ds_ch9_relations.html"
---

CSE 2813

# DS–9: Relations

§9.1 – §9.9

## §9.1 Binary Relations

:::definition[Definition]
Binary Relation

A **binary relation** $R$ from set $A$ to set $B$ is a subset $R \subseteq A \times B$. We write $aRb$ or $(a,b)\in R$ to mean the pair is in the relation. When $A=B$, we say $R$ is a *relation on $A$*.
:::

Example 9.1 — Relations as Subsets

Let $A=\{1,2,3\}$. Define $R=\{(1,1),(1,2),(2,3),(3,3)\}$. Describe $R$ and compute its matrix.

:::answer[Solution]
$R$ is "less than or equal" restricted to certain pairs. Matrix $M_R$ (rows/cols indexed $1,2,3$):


$$
M_R = \begin{pmatrix}1&1&0\\0&0&1\\0&0&1\end{pmatrix}
$$

    $M_{ij}=1$ iff $(i,j)\in R$.
:::

### Representing Relations

- **Set of ordered pairs:** $R = \{(a,b) : \ldots\}$
- **Matrix:** $M_R[i][j] = 1$ iff $(i,j)\in R$. Composition = Boolean matrix multiplication.
- **Directed graph:** vertices = elements, directed edge $a\to b$ iff $(a,b)\in R$.

## §9.2 Properties of Relations

| Property | Definition | Example on $\mathbb{Z}$ | Example: NOT |
| --- | --- | --- | --- |
| **Reflexive** | $\forall a: aRa$ | $\le$, $=$ | $<$ |
| **Irreflexive** | $\forall a: \neg(aRa)$ | $<$, $\neq$ | $\le$ |
| **Symmetric** | $aRb\Rightarrow bRa$ | $=$, "same parity" | $<$ |
| **Antisymmetric** | $aRb \wedge bRa \Rightarrow a=b$ | $\le$, $\mid$ | $\neq$ |
| **Transitive** | $aRb \wedge bRc \Rightarrow aRc$ | $\le$, $=$, $<$ | "parent of" |

:::callout-pitfall[Common Pitfall]
Antisymmetric ≠ "not symmetric." The empty relation and equality are both symmetric AND antisymmetric. They are different properties. A relation can be neither symmetric nor antisymmetric (e.g., $\{(1,2),(2,1),(1,3)\}$).
:::

Example 9.2 — Classify a Relation

Let $R$ on $\{1,2,3\}$ be $\{(1,1),(2,2),(3,3),(1,2),(2,1)\}$. Classify all five properties.

:::answer[Solution]
Reflexive ✓ (all diagonal pairs present). Symmetric ✓ ($(1,2)$ and $(2,1)$ both present). Not antisymmetric ✗ ($(1,2)$ and $(2,1)$ present but $1\neq2$). Transitive ✓ (no violation). Not irreflexive ✗ (diagonal present).
:::

## §9.3 Composition and Matrix Representation

:::definition[Definition]
Composition of Relations

$(a,c)\in R\circ S$ iff $\exists b$ such that $(a,b)\in R$ and $(b,c)\in S$.

In matrix form: $M_{R\circ S} = M_R \otimes M_S$ (Boolean matrix product: AND instead of multiply, OR instead of add).
:::

Example 9.3 — Boolean Matrix Multiplication

Let $R=\{(1,2),(2,3)\}$ and $S=\{(2,1),(3,2)\}$ on $\{1,2,3\}$. Find $R\circ S$.

:::answer[Solution]
$(1,?)$: $(1,2)\in R$ and $(2,1)\in S$ → $(1,1)$. $(2,?)$: $(2,3)\in R$ and $(3,2)\in S$ → $(2,2)$.

$R\circ S = \{(1,1),(2,2)\}$.
:::

## §9.4 Closures and Warshall's Algorithm

:::definition[Definition]
Closures

The **closure** of relation $R$ with respect to property $P$ is the smallest relation containing $R$ that has property $P$.

- **Reflexive closure:** $R \cup \{(a,a) : a\in A\}$ (add the diagonal)
- **Symmetric closure:** $R \cup R^{-1}$ (add all reverses)
- **Transitive closure:** $R^+ = R\cup R^2\cup R^3\cup\cdots$ — computed efficiently by **Warshall's algorithm**
:::

:::theorem[Algorithm]
Warshall's Algorithm (Floyd–Warshall)

Computes transitive closure $R^+$ in $O(n^3)$:
:::

```cpp
// Warshall's Algorithm — O(n^3)
// reach[i][j] = true iff j is reachable from i
void warshall(vector<vector<bool>>& reach, int n) {
    for (int k = 0; k < n; k++)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (reach[i][k] && reach[k][j])
                    reach[i][j] = true;
}
```

:::callout-intuition[Intuition]
Warshall's algorithm asks: "Can we get from $i$ to $j$ using only vertices $\{0,\ldots,k\}$ as intermediates?" At each step $k$, we consider whether routing through vertex $k$ creates a new connection.
:::

## §9.5 Equivalence Relations and Union-Find

:::definition[Definition]
Equivalence Relation

A relation that is **reflexive, symmetric, and transitive**. It partitions the set into **equivalence classes**: $[a] = \{b : aRb\}$. The partition $\{[a] : a\in A\}$ is called the *quotient set*.
:::

Example 9.4 — Congruence mod 3

Describe the equivalence classes of $\equiv\pmod{3}$ on $\mathbb{Z}$.

:::answer[Solution]
$[0]=\{\ldots,-3,0,3,6,\ldots\}$, $[1]=\{\ldots,-2,1,4,7,\ldots\}$, $[2]=\{\ldots,-1,2,5,8,\ldots\}$. Three classes partition all integers.
:::

### Union-Find (Disjoint Set Union)

Tracks equivalence classes dynamically. Supports `find(x)` (returns representative of $x$'s class) and `union(x,y)` (merges the classes). With path compression and union by rank: near $O(1)$ amortized per operation.

```cpp
struct UnionFind {
    vector<int> parent, rank;
    UnionFind(int n) : parent(n), rank(n, 0) {
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {
        if (parent[x] != x) parent[x] = find(parent[x]); // path compression
        return parent[x];
    }
    bool unite(int x, int y) {
        x = find(x); y = find(y);
        if (x == y) return false;
        if (rank[x] < rank[y]) swap(x, y);
        parent[y] = x;
        if (rank[x] == rank[y]) rank[x]++;
        return true;
    }
};
```

## §9.6 Partial Orders

:::definition[Definition]
Partial Order

A relation that is **reflexive, antisymmetric, and transitive**. Denoted $(A, \preceq)$. A **total order** additionally satisfies: $\forall a,b$: $a\preceq b$ or $b\preceq a$. Examples: $\le$ on $\mathbb{R}$ (total), $\subseteq$ on power sets (partial), $\mid$ on $\mathbb{Z}^+$ (partial).
:::

:::definition[Definition]
Comparable, Maximal, Minimal

Elements $a,b$ are **comparable** if $a\preceq b$ or $b\preceq a$. An element $m$ is **maximal** if no element is strictly above it ($\nexists x: m\prec x$). A **greatest** element satisfies $a\preceq g$ for all $a$.
:::

## §9.7 Hasse Diagrams

A **Hasse diagram** is a compact visual representation of a partial order. Rules:

- Vertices represent elements.
- Draw an edge from $a$ up to $b$ if $a\prec b$ and there is no $c$ with $a\prec c\prec b$ (no "shortcuts" needed — implied by transitivity).
- Direction is implicit: higher position = greater element.

Example 9.5 — Hasse Diagram for Divisibility

Draw the Hasse diagram for divisibility on $\{1,2,3,4,6,12\}$.

:::answer[Solution]
```
           12
          /  \
         4    6
         |   / \
         2  3   (2)
          \ |
           1

```

Edges: $1\to2, 1\to3, 2\to4, 2\to6, 3\to6, 4\to12, 6\to12$. Transitivity (like $1\to12$) is omitted.
:::

## §9.8 Topological Sort

:::definition[Definition]
Topological Sort

A **topological sort** of a DAG (directed acyclic graph / partial order) is a linear ordering of all vertices such that if $(u,v)\in E$ then $u$ appears before $v$. A topological sort exists iff the graph has no cycles.
:::

**Kahn's Algorithm** (BFS-based): maintain a queue of all in-degree-0 vertices. Repeatedly remove a vertex from the queue, add it to the result, and decrement in-degrees of neighbors (adding any that reach 0).

```cpp
// Kahn's Algorithm: Topological Sort — O(V + E)
vector<int> topoSort(int n, vector<vector<int>>& adj) {
    vector<int> indeg(n, 0);
    for (int u = 0; u < n; u++)
        for (int v : adj[u]) indeg[v]++;
    queue<int> q;
    for (int i = 0; i < n; i++) if (indeg[i]==0) q.push(i);
    vector<int> order;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        order.push_back(u);
        for (int v : adj[u])
            if (--indeg[v] == 0) q.push(v);
    }
    return order; // empty if cycle detected
}
```

:::callout-connect[Connection → Build Systems]
Build tools (Make, Gradle, CMake) use topological sort to determine compilation order when source files depend on each other. A circular dependency causes an error — which is exactly "cycle detected."
:::

## §9.9 Relations in Databases

The **relational model** of databases (SQL) is founded directly on the mathematical notion of a relation. A **table** (relation) is a set of tuples; each column is an *attribute*.

- **Primary key:** a minimal set of attributes that uniquely identifies each tuple — corresponds to a functional dependency $K \to$ all attributes.
- **Foreign key:** a set of attributes in one relation that references the primary key of another — enforces referential integrity.
- **JOIN:** the relational composition $R\circ S$ — connects tuples from two tables via a common attribute.
- **Normal forms** (1NF, 2NF, 3NF, BCNF) formalize when relations are "well-structured" by eliminating redundant functional dependencies.

:::callout-tip[Tip]
Every SQL SELECT-FROM-WHERE query computes: SELECT (projection), FROM-JOIN (composition), WHERE (selection/restriction) — direct counterparts of operations on mathematical relations.
:::

:::summary
### Chapter 9 Summary

- **Binary relation** $R\subseteq A\times B$: represented as set, matrix, or directed graph.
- **Five properties:** reflexive, irreflexive, symmetric, antisymmetric, transitive — memorize definitions and counterexamples.
- **Closures:** reflexive (add diagonal), symmetric (add reverses), transitive (Warshall $O(n^3)$).
- **Equivalence relation:** reflexive + symmetric + transitive → partitions into equivalence classes. Union-Find tracks classes dynamically.
- **Partial order:** reflexive + antisymmetric + transitive. Visualized with Hasse diagrams.
- **Topological sort:** linear extension of a partial order — Kahn's algorithm $O(V+E)$; fails iff cycle exists.
- **Databases:** SQL tables are relations; JOIN = composition; keys = functional dependencies.
:::

## Practice Problems

:::problem[Problem 1]{difficulty="easy"}
Problem 1

Let $R = \{(1,2),(2,1),(1,3),(3,1),(2,3),(3,2),(1,1),(2,2),(3,3)\}$ on $\{1,2,3\}$. Which properties does $R$ satisfy?

::::solution[Solution]
Reflexive ✓. Symmetric ✓ (every pair $(a,b)$ has $(b,a)$). Antisymmetric ✗ ($(1,2)$ and $(2,1)$ both present, $1\neq2$). Transitive ✓ (this is the complete relation — everything is connected). This is the total (complete) relation.
::::
:::

:::problem[Problem 2]{difficulty="easy"}
Problem 2

Find the transitive closure of $R=\{(1,2),(2,3),(3,4)\}$ on $\{1,2,3,4\}$ using Warshall's algorithm (show the matrix at each step).

::::solution[Solution]
Initial matrix (1=relation exists):

$\begin{pmatrix}0&1&0&0\\0&0&1&0\\0&0&0&1\\0&0&0&0\end{pmatrix}$

After $k=1$: no new paths (nothing leads into row 1 except itself).

After $k=2$: $(1,3)$ added (via 2). After $k=3$: $(1,4),(2,4)$ added (via 3). Closure: $\{(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)\}$.
::::
:::

:::problem[Problem 3]{difficulty="standard"}
Problem 3

Define $a\sim b$ on $\mathbb{Z}$ iff $3\mid(a-b)$. Prove this is an equivalence relation and list the equivalence classes.

::::solution[Solution]
Reflexive: $3\mid(a-a)=0$ ✓. Symmetric: $3\mid(a-b)\Rightarrow3\mid(b-a)$ ✓. Transitive: $3\mid(a-b)$ and $3\mid(b-c)\Rightarrow3\mid(a-b+b-c)=3\mid(a-c)$ ✓. Classes: $[0]=3\mathbb{Z}$, $[1]=3\mathbb{Z}+1$, $[2]=3\mathbb{Z}+2$.
::::
:::

:::problem[Problem 4]{difficulty="standard"}
Problem 4

Draw the Hasse diagram for $\subseteq$ on $\mathcal{P}(\{a,b,c\})$.

::::solution[Solution]
8 elements. Bottom: $\emptyset$. Level 1: $\{a\},\{b\},\{c\}$. Level 2: $\{a,b\},\{a,c\},\{b,c\}$. Top: $\{a,b,c\}$. Edges connect each subset to its immediate supersets (those differing by exactly one element). This is the 3-dimensional Boolean lattice.
::::
:::

:::problem[Problem 5]{difficulty="standard"}
Problem 5

Given a graph with edges: $A\to B$, $A\to C$, $B\to D$, $C\to D$, $D\to E$. Perform a topological sort using Kahn's algorithm.

::::solution[Solution]
In-degrees: A=0,B=1,C=1,D=2,E=1. Queue: {A}. Remove A→add B,C (degrees 0,0). Queue:{B,C}. Remove B→D(1). Remove C→D(0). Queue:{D}. Remove D→E(0). Queue:{E}. Remove E. Order: $\mathbf{A,B,C,D,E}$.
::::
:::

:::problem[Problem 6]{difficulty="challenge"}
Problem 6

Prove that a relation $R$ on $A$ is a partial order iff its Hasse diagram contains no directed cycle. (Hint: use antisymmetry and transitivity.)

::::solution[Solution]
($\Rightarrow$) If $R$ is a partial order and there is a cycle $a_1\prec a_2\prec\cdots\prec a_k\prec a_1$, then by transitivity $a_1\prec a_1$, contradicting antisymmetry (since $a_1Ra_1$ and $a_1Ra_1$ with $a_1\neq a_1$ is impossible, but actually reflexivity allows $a_1Ra_1$; the issue is the strict order $a_1\prec a_1$ means $a_1Ra_1$ AND $a_1\neq a_1$, a contradiction). ($\Leftarrow$) If no cycle, the directed graph defines a consistent ordering — transitivity follows from path concatenation, antisymmetry from no 2-cycles. $\square$
::::
:::

:::problem[Problem 7]{difficulty="challenge"}
Problem 7

Implement Union-Find and use it to count connected components in an undirected graph given as an edge list.

::::solution[Solution]
```cpp
int countComponents(int n, vector<pair<int,int>>& edges) {
    UnionFind uf(n);
    int components = n;
    for (auto [u,v] : edges)
        if (uf.unite(u, v)) components--;
    return components;
}
```

Each successful union merges two components, so components starts at $n$ and decrements by 1 for each merge.
::::
:::

## LeetCode Practice

| # | Title | Difficulty | Concept |
| --- | --- | --- | --- |
| 547 | [Number of Provinces](https://leetcode.com/problems/number-of-provinces/) | Medium | Union-Find / equivalence classes |
| 207 | [Course Schedule](https://leetcode.com/problems/course-schedule/) | Medium | Topological sort (cycle detection) |
| 210 | [Course Schedule II](https://leetcode.com/problems/course-schedule-ii/) | Medium | Topological sort (Kahn's algorithm) |
| 990 | [Satisfiability of Equality Equations](https://leetcode.com/problems/satisfiability-of-equality-equations/) | Medium | Union-Find with equivalence relations |
| 1615 | [Maximal Network Rank](https://leetcode.com/problems/maximal-network-rank/) | Medium | Relation degree / adjacency reasoning |
