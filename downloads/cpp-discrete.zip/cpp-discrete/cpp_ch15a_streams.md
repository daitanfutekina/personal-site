---
title: "Chapter 15A: Streams & File I/O"
crumb: "C++ · Chapter 15A"
meta:
  - "Est. study time: ~2.5 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 15: Streams & File I/O

## Overview

Every program you have written so far has read from the keyboard and written to the screen. That
is fine for exercises and useless for anything that has to remember something between runs.

This chapter is about the rest of the picture — files, and strings used as if they were files — and
the striking thing is how little new there is to learn. `cout << x` writes to the screen;
`myFile << x` writes to a file; `myStringStream << x` writes into a string. **The same operator,
the same rules, the same manipulators.** That uniformity is not a coincidence: all three are
`ostream`s, and §15.11 shows the inheritance that makes it so.

What *is* new is that files can fail in ways the console cannot. The screen is always there; a file
may not exist, may be unreadable, may fill the disk halfway through a write. So most of the real
content here is about **checking**, and about the four state bits a stream uses to report what
happened.

Two traps in particular account for most beginner bugs with streams, and each gets its own section:

- **Mixing `>>` and `getline`** leaves a stray newline that `getline` then reads as an empty line.
- **File operations do not throw**; they set a flag and carry on, so an unchecked open produces a
  perfectly usable stream that silently does nothing.

:::callout-key[What you'll learn]
- The stream abstraction, and why one function can write to console, file, or string
- `ofstream` and `ifstream`, and always checking the open succeeded
- The four state bits — `good`, `eof`, `fail`, `bad` — and how to recover
- `getline`, and the newline trap when mixing it with `>>`
- File modes: append, truncate, binary
- `stringstream` for parsing and type conversion
- `<iomanip>` for aligned, formatted output
:::

:::callout-tip[Prerequisites]
`string` from Chapter 11 and functions from Chapter 7. Inheritance from Chapter 14 for §15.11,
though the polymorphism is usable well before it is explained. Exceptions from the companion
chapter are used in the validating examples.
:::

## §15.1 — The Stream Abstraction

A **stream** is a sequential flow of data — into your program or out of it. The design's real
achievement is that the *same interface* serves the console, a file, and a string in memory.

```
  Program
  ┌────────────┐
  │            │──── ostream ────► console (cout)
  │            │──── ofstream ───► file (grades.txt)
  │            │──── ostringstream► string buffer
  │            │
  │            │◄─── istream ────  console (cin)
  │            │◄─── ifstream ───  file (data.txt)
  │            │◄─── istringstream string buffer
  └────────────┘

Stream inheritance:
ios_base
  └─ ios
       ├─ istream ──► ifstream, istringstream
       └─ ostream ──► ofstream, ostringstream
            └─ iostream (cin & cout combined)
```

**Read the hierarchy as a promise.** Everything below `ostream` can be written to with `<<`;
everything below `istream` can be read from with `>>`. A function that takes an `ostream&` therefore
works with all three destinations, and — the part that matters — it works with destinations that did
not exist when it was written.

:::callout-key[Why one interface for three destinations]
Because `cout`, `ofstream` and `ostringstream` all inherit from `ostream`, any function taking an
`ostream&` can write to a console, a file, or a string. That is Chapter 14's polymorphism doing
real work in the standard library.

The practical consequence is worth stating: **write your output functions to take `ostream&`, not
to call `cout` directly.** A function that hard-codes `cout` can only ever print to the screen. The
same function taking `ostream&` can be redirected to a log file or captured into a string for
testing, with no change at all. §15.2 shows it, and it is the single most useful habit in this
chapter.
:::

## §15.2 — Output Streams & ofstream

```cpp
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int main() {
    // Open a file for writing (creates if not exists, truncates if exists)
    ofstream outFile("output.txt");

    if (!outFile) {           // stream evaluates to false on failure
        cerr << "Error: could not open output.txt\n";
        return 1;
    }

    outFile << "Hello, file!\n";
    outFile << "Pi is approximately " << 3.14159 << "\n";

    // Write a table
    outFile << "Name\tScore\n";
    outFile << "Alice\t95\n";
    outFile << "Bob\t87\n";

    outFile.close();   // optional — destructor closes it anyway
}
```

**"Truncates if exists" is the sentence to read twice.** Constructing an `ofstream` on an existing
file erases it immediately, before a single byte is written. If the program then fails, the old
contents are gone and the new ones were never written. Use `ios::app` (§15.6) when you meant to add
rather than replace.

**`close()` is optional and worth writing anyway** when the file is finished with well before the
end of the function. The destructor closes it during stack unwinding — that is the RAII guarantee —
but an explicit close releases the handle sooner and, more usefully, lets you check whether the
final flush succeeded.

**Errors go to `cerr`, and the program returns 1.** `cerr` is unbuffered and separate from `cout`,
so the message survives a redirect of normal output; the non-zero exit status is what a shell script
or a Makefile tests.

:::callout-intuition[Always check the open, immediately]
```cpp
ofstream f("results.txt");
f << data;                    // no check — this may do absolutely nothing
```

Opening a file can fail for reasons that have nothing to do with your program: the directory does
not exist, permissions are denied, the disk is full, the path is on a network share that is down.

**A failed stream does not throw and does not crash.** It sets `failbit` and every subsequent
operation becomes a no-op, so the code above runs to completion, reports success, and writes
nothing. The user finds out when they look for the file.

One `if (!f)` after every open. It is two lines and it is the difference between an error message
and silent data loss.
:::

### Writing to both console and file

```cpp
// Polymorphic output function — works for any ostream
void writeReport(ostream& out, const string& title, int value) {
    out << "=== " << title << " ===\n";
    out << "Value: " << value << "\n";
}

void demoReport() {
    ofstream log("report.txt");
    writeReport(cout, "Console Report", 42);   // to screen
    writeReport(log,  "File Report",    42);   // same function, to file
}
```

One function, two destinations, and no branching inside it. Adding a third — capture the report
into an `ostringstream` to compare against an expected string in a unit test — requires no change to
`writeReport` at all.

**Note the parameter is `ostream&` and not `ostream`.** Streams cannot be copied, so passing by
value does not compile — which is the language preventing a bug rather than merely warning about it.

## §15.3 — Input Streams & ifstream

```cpp
int demoRead() {
    ifstream inFile("data.txt");
    if (!inFile) {
        cerr << "Cannot open data.txt\n";
        return 1;
    }

    // Read word by word (stops at whitespace)
    string word;
    while (inFile >> word) {
        cout << "Word: " << word << "\n";
    }
    return 0;
}   // file closes automatically when inFile goes out of scope
```

**`>>` on a string reads one whitespace-delimited token**, skipping any leading whitespace and
stopping at the next. It never reads a whole line, and it never gives you the spaces — which is why
§15.5 exists.

### Reading numbers

```cpp
void demoNumbers() {
    ifstream nums("numbers.txt");
    int x;
    double sum = 0;
    int count = 0;
    while (nums >> x) {      // extraction returns false at EOF or error
        sum += x;
        count++;
    }
    if (count > 0)
        cout << "Average: " << sum / count << "\n";
}
```

**`sum` is a `double` while `x` is an `int`**, which is what makes `sum / count` a floating-point
division. Declaring `sum` as `int` would truncate the average — the §19.2 trap in a different
costume.

**The `if (count > 0)` guard prevents a division by zero** on an empty or unreadable file. Note it
also silently prints nothing in that case, which may or may not be what you want; reporting "no
data" would be better.

:::callout-key[The extraction loop idiom]
```cpp
while (stream >> value) { ... }
```

This works because `operator>>` returns a reference to the stream, and a stream used in a boolean
context is `true` when the last operation succeeded. So the loop reads and tests in one expression.

**It stops for two different reasons and does not distinguish them**: end of file, or a value that
would not parse. After the loop, `eof()` and `fail()` tell you which — and that distinction matters,
because one is the expected ending and the other means the file is malformed. §15.4 covers it.
:::

## §15.4 — Stream State Bits & Error Handling

Every stream carries four flags:

| Flag | Method | Meaning |
| --- | --- | --- |
| `goodbit` | `good()` | No errors — operations will succeed |
| `eofbit` | `eof()` | End of file reached |
| `failbit` | `fail()` | Type mismatch, e.g. reading `"abc"` into an `int` |
| `badbit` | `bad()` | Unrecoverable error — hardware or OS level |

```cpp
void demoState() {
    ifstream f("scores.txt");
    int score;

    while (f >> score) {
        cout << score << "\n";
    }

    if (f.eof())  cout << "Reached end of file\n";
    if (f.fail()) cout << "Type mismatch or bad input\n";
    if (f.bad())  cout << "Fatal stream error\n";

    // Recover from failbit to try again:
    f.clear();             // reset all error flags
    f.ignore(1000, '\n');  // discard the bad input line
}
```

:::callout-pitfall[`eof()` and `fail()` are both set at the end of a normal file]
This trips people constantly. Reaching end of file sets `eofbit`, and the read that *discovered* the
end also failed, so `failbit` is set too. After a perfectly successful loop over a well-formed file,
`f.fail()` is **true**.

So the three `if`s above will print both "Reached end of file" and "Type mismatch" on a file with
nothing wrong with it.

The reliable test for "something actually went wrong" is:

```cpp
if (!f.eof()) {
    // stopped early — a genuine parse error
}
```

or `f.bad()` for hardware-level failure. Use `fail()` to test a *single* operation immediately after
it, not to judge a loop that has run to completion. This is the same distinction §15.3's file-reading
example draws with `f.bad()`.
:::

**Recovery is two steps and both are needed.** `clear()` resets the flags so the stream will accept
operations again; without it every subsequent read is a no-op. But the offending characters are still
in the buffer, so `ignore()` must discard them — otherwise the next read hits the same bad input and
fails identically, forever. A validation loop missing the `ignore()` spins at 100% CPU printing the
same error, which is a distinctive and common symptom.

:::problem[Practice 15.4 easy]{difficulty="easy"}
**Safe integer reader.** Write `int readIntFromFile(const string& filename)` that opens the file,
reads the first integer, and throws `runtime_error` when it cannot open the file or finds no
integer.

::::solution[Solution]
```cpp
int readIntFromFile(const string& filename) {
    ifstream f(filename);
    if (!f) throw runtime_error("Cannot open: " + filename);
    int val;
    if (!(f >> val)) throw runtime_error("No integer found in: " + filename);
    return val;
}
```

**The two failures are checked separately because they are different problems.** "Cannot open"
means the file is missing or unreadable — the caller might create it. "No integer found" means the
file exists and its contents are wrong — the caller should report a format error. Collapsing both
into one message loses information the caller needs.

**`if (!(f >> val))` reads and tests in one expression**, and the parentheses are required:
`!f >> val` would apply `!` to `f` first and then shift the resulting `bool`, which compiles and is
nonsense.

**This function converts stream state into exceptions at one boundary**, which is the pattern the
exceptions chapter recommends. Above this line the caller writes ordinary code with no flag
checking; below it, every failure mode has been turned into a message.
::::
:::

## §15.5 — Reading Line by Line with getline

`getline(stream, string)` reads an entire line *including spaces*, stopping at `'\n'` — which it
consumes but does not store.

```cpp
void demoGetline() {
    ifstream f("poem.txt");
    string line;
    int lineNum = 1;
    while (getline(f, line)) {
        cout << lineNum++ << ": " << line << "\n";
    }
}
```

**`getline` is a free function, not a member** — `getline(f, line)`, not `f.getline(line)`. There
*is* a member `f.getline(char*, int)` for C-style strings, and confusing the two produces errors
about converting `string` to `char*`.

### Mixing `>>` and getline — the newline trap

```cpp
void demoTrap() {
    int age;
    string name;

    // PROBLEM: mixing >> and getline
    cin >> age;           // reads "25", leaves '\n' in the buffer
    getline(cin, name);   // immediately reads that '\n' → name is ""!

    // FIX: consume the leftover newline first
    cin >> age;
    cin.ignore();         // discard '\n'
    getline(cin, name);   // now reads correctly
}
```

**Here is exactly what happens.** The user types `25` and presses Enter, putting `2`, `5`, `\n` in
the buffer. `cin >> age` reads the digits and **stops at the newline, leaving it there** — extraction
stops at whitespace and does not consume it. `getline` then reads from the current position to the
next newline, finds one immediately, and returns the empty string between them.

The symptom is a prompt that appears to be skipped: the program asks for a name and moves straight
on without waiting. Nothing failed — `getline` succeeded and read a genuinely empty line.

:::callout-pitfall[The `ignore()` that actually works]
`cin.ignore()` with no arguments discards exactly **one** character, which is enough for the common
case and not in general — if the user typed `25 extra` the newline is still several characters away.

The robust form discards everything up to and including the next newline:

```cpp
#include <limits>
cin.ignore(numeric_limits<streamsize>::max(), '\n');
```

**The rule: whenever you switch from `>>` to `getline`, clear the buffer first.** Going the other
way is safe, because `>>` skips leading whitespace on its own — the asymmetry is what makes this
easy to forget.
:::

### Counting words and lines in a file

```cpp
void countFile(const string& path) {
    ifstream f(path);
    string line, word;
    int lineCount = 0, wordCount = 0, charCount = 0;

    while (getline(f, line)) {
        lineCount++;
        charCount += line.size();
        istringstream iss(line);       // stringstream to tokenize the line
        while (iss >> word) wordCount++;
    }
    cout << lineCount << " lines, " << wordCount << " words, "
         << charCount << " chars\n";
}
```

**Two nested streams, and the inner one is the interesting part.** `getline` gives a whole line as a
`string`; wrapping it in an `istringstream` lets `>>` split it into tokens. That handles runs of
spaces and tabs with no manual scanning, and it is the standard way to tokenise in C++.

**`charCount` excludes the newlines**, since `getline` discards them — so this reports fewer
characters than `wc -c` would. Whether that is right depends on what you meant by "characters", and
the point is to be deliberate about it.

## §15.6 — File Modes

The second argument to the constructor or `open()` is a bitmask:

| Flag | Meaning |
| --- | --- |
| `ios::in` | Open for reading (default for `ifstream`) |
| `ios::out` | Open for writing (default for `ofstream`) |
| `ios::app` | Append — writes go to the end, existing content preserved |
| `ios::trunc` | Truncate — delete existing content on open (default with `out`) |
| `ios::binary` | Binary mode — no newline translation |
| `ios::ate` | At end — seek to the end on open |

```cpp
void demoModes() {
    // Append to a log — don't erase existing entries
    ofstream logFile("app.log", ios::app);
    logFile << "[2026-05-19] Server started\n";

    // Open for both reading and writing
    fstream rw("database.txt", ios::in | ios::out);

    // Binary write
    ofstream bin("data.bin", ios::out | ios::binary);

    // Check whether a file exists, without modifying it
    ifstream check("config.txt");
    bool exists = check.good();
    check.close();
}
```

**`ios::app` versus `ios::ate`** looks like a distinction without a difference and is not. `app`
forces *every* write to the end, even after seeking elsewhere — which is what makes it safe for a
log several processes are writing to. `ate` merely positions you at the end once, and a later seek
moves you back.

**`ios::binary` matters only on Windows**, where text mode silently translates `\n` to `\r\n` on
write and back on read. For text that is helpful; for a struct written byte for byte it corrupts
every 0x0A in the data. **Always use `ios::binary` for non-text files** — code that works on Linux
and mangles files on Windows is almost always this.

**The existence check uses `ifstream`, not `ofstream`, and that is deliberate.** Opening a file for
*output* to see whether it exists would create it — and truncate it if it did. Opening for input
cannot damage anything.

## §15.7 — Stringstreams

A **stringstream** is a stream backed by a `string` in memory. It is the tool for parsing,
formatting, and converting between types.

```cpp
#include <sstream>

void demoStringStream() {
    // Type conversion: number → string
    int score = 95;
    ostringstream oss;
    oss << "Score: " << score << "/100";
    string result = oss.str();    // "Score: 95/100"

    // Type conversion: string → number (safer than atoi)
    string input = "3.14";
    istringstream iss(input);
    double d;
    iss >> d;          // d = 3.14

    // Parse a comma-separated line
    string csvLine = "Alice,95,3.9";
    istringstream parser(csvLine);
    string name, scoreStr, gpaStr;
    getline(parser, name,    ',');   // "Alice"
    getline(parser, scoreStr,',');   // "95"
    getline(parser, gpaStr,  ',');   // "3.9"

    // Reset a stringstream for reuse
    oss.str("");    // clear contents
    oss.clear();    // clear error flags
}
```

**`getline` takes an optional delimiter**, and that third argument is what makes CSV parsing a
three-liner. `getline(parser, name, ',')` reads to the next comma instead of the next newline. Note
the last field has no trailing comma, so that `getline` stops at end of stream — which works, and
sets `eofbit`, which is why the reset below matters.

**Resetting needs both calls, and they do different things.** `oss.str("")` replaces the contents;
`oss.clear()` resets the error flags. Doing only the first leaves `eofbit` set from the previous
read, so the next extraction fails immediately and silently. This is the stringstream version of the
`clear()`/`ignore()` pairing from §15.4.

:::callout-intuition[A string that behaves like a file]
`istringstream` lets you treat any `string` as though it were a file, which is more useful than it
first sounds.

The pattern that recurs everywhere: **read a line with `getline`, then wrap it in an
`istringstream` to parse its tokens.** That separates the two concerns — finding record boundaries,
and interpreting a record — and it means a malformed line fails on its own without derailing the
read of the rest of the file.

It is also how you test parsing code without touching the disk: feed the parser an
`istringstream` containing the input you want, and no file is involved.
:::

:::problem[Practice 15.7 standard]{difficulty="standard"}
**Generic conversion.** Implement `template <typename T> string toString(T val)` and
`template <typename T> T fromString(const string& s)` using stringstreams.

::::solution[Solution]
```cpp
template <typename T>
string toString(T val) {
    ostringstream oss; oss << val; return oss.str();
}
template <typename T>
T fromString(const string& s) {
    T val; istringstream iss(s); iss >> val; return val;
}
// Usage:
//   string s = toString(3.14);        // "3.14"
//   int    n = fromString<int>("42"); // 42
```

**These work for any type with a `<<` or `>>` overload**, including the `Vector2D` and `Fraction`
classes of Chapter 13 — which is the payoff for having written those stream operators.

**`fromString` needs its type argument spelled out** — `fromString<int>("42")` — because the return
type cannot be deduced from the arguments. `toString` needs no such help, since `T` is deducible
from `val`.

**The obvious weakness is that neither reports failure.** `fromString<int>("abc")` leaves `val`
uninitialised in C++98 and value-initialises it to 0 since C++11 — either way the caller gets a
number and no indication that nothing was parsed. A production version would check the stream and
throw, exactly as §15.4's reader does:

```cpp
template <typename T>
T fromStringChecked(const string& s) {
    T val; istringstream iss(s);
    if (!(iss >> val)) throw invalid_argument("Cannot parse: " + s);
    return val;
}
```
::::
:::

## §15.8 — Output Formatting with `<iomanip>`

```cpp
#include <iomanip>

void demoFormatting() {
    // Field width and fill character
    cout << setw(10) << "Name" << setw(8) << "Score" << "\n";
    cout << setw(10) << "Alice" << setw(8) << 95 << "\n";
    cout << setw(10) << "Bob"   << setw(8) << 87 << "\n";
    // Output:
    //       Name   Score
    //      Alice      95
    //        Bob      87

    // Floating point precision
    cout << fixed << setprecision(2) << 3.14159 << "\n";   // 3.14
    cout << scientific << setprecision(3) << 12345.6789;    // 1.235e+04

    // Fill character and alignment
    cout << left  << setfill('-') << setw(20) << "Alice" << "\n"; // Alice---------------
    cout << right << setfill(' ') << setw(20) << "Alice" << "\n"; //                Alice

    // Numeric bases
    cout << hex   << 255 << "\n";   // ff
    cout << oct   << 255 << "\n";   // 377
    cout << dec   << 255 << "\n";   // 255 (reset to decimal)
    cout << showbase << hex << 255 << "\n";  // 0xff
}
```

**The `#include <iomanip>` is not optional.** `setw`, `setprecision`, `setfill` and `showbase` all
live there, and omitting it gives "`setw` was not declared in this scope" — an error that names the
function and not the header, so it reads as though you misspelled something. Note that `hex`, `oct`,
`dec`, `left`, `right`, `fixed` and `scientific` are in `<ios>` and come in with `<iostream>`, which
is why a program can use half of these without the include and fail on the other half.

:::callout-key[`setw` is the one that is not sticky]
Most manipulators are **sticky**: set `hex` and every integer prints in hexadecimal until you set
`dec` again. Set `setprecision(2)` and it applies to every float thereafter.

**`setw` is the exception.** It applies to the very next output and then resets to 0. That is why the
table above repeats it on every field — writing it once at the top would pad only the first column.

The practical consequences of stickiness are worth naming:

- **Reset `hex` with `dec`**, or every later number is unreadable — including ones printed by code
  you did not write.
- `fixed` and `scientific` are sticky too, and `cout.unsetf(ios::floatfield)` returns to the default.
- `setfill('-')` persists, so a later `setw` pads with dashes unless you set it back to `' '`. The
  example above does exactly that on the following line, and it is easy to forget.
:::

### Formatting a table

```cpp
void printGradeTable(const vector<pair<string,int>>& grades) {
    cout << left << setfill(' ')
         << setw(15) << "Student"
         << right
         << setw(8)  << "Score"
         << setw(10) << "Grade" << "\n";
    cout << string(33, '-') << "\n";

    for (auto& [name, score] : grades) {
        string grade = score>=90?"A":score>=80?"B":score>=70?"C":"F";
        cout << left  << setw(15) << name
             << right << setw(8)  << score
             << setw(10) << grade << "\n";
    }
}
```

**Text left, numbers right** — the convention that makes tables readable, because right-aligned
digits line up by place value while left-aligned names line up by first letter.

**`string(33, '-')` builds the rule**, and 33 is $15 + 8 + 10$, the total width. That is a number
that will silently stop matching the moment a column width changes; computing it from the widths
would be sturdier.

**`auto& [name, score]` is a structured binding** (C++17), unpacking each `pair` into two named
variables. Without it the loop body would be full of `.first` and `.second`, and it is worth using
`const auto&` here since nothing is modified.

## §15.9 — Reading Structured Data (CSV)

Combining `getline` for lines with `istringstream` for fields is the standard CSV pattern, and it is
§15.5 and §15.7 put together.

```cpp
struct Student {
    string name;
    int    score;
    double gpa;
};

vector<Student> readCSV(const string& path) {
    ifstream f(path);
    if (!f) throw runtime_error("Cannot open " + path);

    vector<Student> out;
    string line;
    int lineNo = 0;
    while (getline(f, line)) {
        lineNo++;
        if (line.empty()) continue;          // skip blank lines

        istringstream ss(line);
        string name, scoreStr, gpaStr;
        if (!getline(ss, name, ',') ||
            !getline(ss, scoreStr, ',') ||
            !getline(ss, gpaStr)) {
            throw runtime_error("Malformed line " + to_string(lineNo));
        }
        out.push_back({name, stoi(scoreStr), stod(gpaStr)});
    }
    return out;
}
```

**Each field's `getline` is checked**, because a line with too few commas otherwise leaves the later
strings empty and `stoi("")` throws a message that says nothing about which line was bad. Reporting
the line number turns a mystery into a fix.

**The last `getline` has no delimiter**, reading to end of line — the final field has no trailing
comma.

**This is not a complete CSV parser and should not pretend to be.** Real CSV allows quoted fields
containing commas and newlines, and escaped quotes inside them. Splitting on every comma breaks on
`"Smith, Alice",95,3.9`. For anything beyond a file you generated yourself, use a library.

## §15.11 — Stream Inheritance & Polymorphism

The hierarchy at the top of the chapter is not decoration — it is why any of this composes.

```cpp
// One function, any destination
void writeCSVRow(ostream& out, const Student& s) {
    out << s.name << ',' << s.score << ',' << s.gpa << '\n';
}

void demoDestinations(const Student& s) {
    writeCSVRow(cout, s);                 // to the console

    ofstream file("out.csv");
    writeCSVRow(file, s);                 // to a file

    ostringstream buf;
    writeCSVRow(buf, s);                  // into a string
    string asText = buf.str();
}
```

**The same three lines of formatting logic serve all three**, and only the last one is interesting:
capturing output into a string is how you unit-test a function that prints. Assert on `buf.str()`
and no file or console is involved.

**Reading is symmetric.** A function taking `istream&` reads equally from `cin`, an `ifstream`, or
an `istringstream` — which means a parser can be tested against a literal string instead of a
fixture file.

## Chapter summary

:::callout-key[Mechanics]
- Streams share one interface: `cout`, `ofstream` and `ostringstream` are all `ostream`s
- **Check every open** with `if (!f)` — a failed stream does not throw, it silently does nothing
- `ofstream` truncates by default; use `ios::app` to add rather than replace
- The extraction loop `while (f >> x)` stops at EOF *or* at a parse error and does not say which
- After a normal read to end of file, both `eof()` and `fail()` are set
- Recover with `clear()` **and** `ignore()` — the first alone leaves the bad input in the buffer
- `getline` is a free function and reads a whole line, delimiter optional
- `setw` applies to the next output only; every other manipulator is sticky
- `<iomanip>` is needed for `setw`, `setprecision`, `setfill`
:::

:::callout-tip[Habits]
- Take `ostream&` and `istream&` as parameters, never hard-code `cout`
- Clear the buffer when switching from `>>` to `getline` — the reverse is safe
- `getline` a line, then `istringstream` its fields; do not try to parse the file in one pass
- Use `ios::binary` for anything that is not text, or Windows will corrupt it
- Reset a stringstream with both `.str("")` and `.clear()`
- Convert stream state into exceptions at one boundary, then write ordinary code above it
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Append a log line.** Write `void logMessage(const string& file, const string& msg)` that appends a
message to a file without erasing what is already there, and throws if the file cannot be opened.

::::solution[Solution]
```cpp
void logMessage(const string& file, const string& msg) {
    ofstream f(file, ios::app);
    if (!f) throw runtime_error("Cannot open log: " + file);
    f << msg << "\n";
    if (!f) throw runtime_error("Write failed on: " + file);
}
```

**`ios::app` is the whole point.** Without it the `ofstream` constructor truncates, so each call
erases the entire log and leaves one line — a bug that looks like "logging is broken" and is
actually "logging is working and deleting everything first".

**The stream is checked twice, and the second check is the one people omit.** Opening can succeed
and writing can still fail — a full disk, a disconnected network share. The write check catches
that; the open check cannot.

**No `close()` is needed.** The destructor closes and flushes at the end of the function, including
when the second `throw` fires, because that is stack unwinding doing its job.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Read and validate.** Write `vector<int> readInts(istream& in)` that reads whitespace-separated
integers until end of input, skipping non-numeric tokens rather than stopping at them, and returns
what it found.

::::solution[Solution]
```cpp
vector<int> readInts(istream& in) {
    vector<int> out;
    int value;
    while (!in.eof()) {
        if (in >> value) {
            out.push_back(value);
        } else {
            in.clear();                  // reset failbit
            string junk;
            if (!(in >> junk)) break;    // discard one bad token
        }
    }
    return out;
}
```

**Both recovery steps are present, and skipping either one hangs the program.** Without `clear()`
the stream stays in a failed state and every later read is a no-op, so the loop spins forever.
Without discarding the token, the next `>>` meets the same characters and fails identically — also
forever. This is §15.4's pairing, and the infinite loop is the classic symptom.

**Reading the junk into a `string` works because `>>` on a `string` accepts anything**
non-whitespace. That is the simplest way to consume exactly one bad token, and the `if` around it
handles genuine end of input.

**The parameter is `istream&`**, so the same function reads from `cin`, a file, or — most usefully
for testing — an `istringstream`:

```cpp
istringstream test("1 2 abc 3");
auto v = readInts(test);      // {1, 2, 3}
```
::::
:::

:::problem[P3 challenge]{difficulty="challenge"}
**Why does this print nothing?** The file exists and contains `42`. Explain, and give two fixes.

```cpp
ifstream f("value.txt");
int x;
f >> x;
cout << "Read: " << x << "\n";
f >> x;
cout << "Again: " << x << "\n";
```

::::solution[Solution]
It prints `Read: 42` and then `Again: 42` — the second read fails and leaves `x` untouched, so the
old value is printed again as though it were new data.

**What happens.** The first extraction succeeds. The second finds only end of file, so it sets
`eofbit` and `failbit` and **does not modify `x`** — since C++11 a failed extraction writes 0, but
either way the value has nothing to do with the file. Nothing is checked, so the program reports a
number it never read.

**Fix one — check every read:**

```cpp
if (f >> x) cout << "Read: " << x << "\n";
else        cerr << "No value in file\n";
```

**Fix two — let the loop do the checking**, which is why the extraction-loop idiom exists:

```cpp
int x;
while (f >> x) cout << "Read: " << x << "\n";
```

**The general lesson is the one the chapter opens with.** Stream operations report failure through
state, not through exceptions or return values you are forced to look at. An unchecked read
succeeds as far as the compiler is concerned, and the wrong number propagates silently into
whatever comes next. Check the stream, every time — either explicitly or by putting the read in the
loop condition.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
File I/O does not appear on LeetCode directly, but the parsing skills do — every one of these is a
`stringstream` problem in disguise.

| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 434 | [Number of Segments in a String](https://leetcode.com/problems/number-of-segments-in-a-string/) | Easy | Tokenising on whitespace — the `istringstream` loop |
| 58 | [Length of Last Word](https://leetcode.com/problems/length-of-last-word/) | Easy | Trailing-whitespace edge cases in tokenising |
| 68 | [Text Justification](https://leetcode.com/problems/text-justification/) | Hard | Field widths and padding — `setw` and `setfill` by hand |
| 271 | [Encode and Decode Strings](https://leetcode.com/problems/encode-and-decode-strings/) | Medium | Delimiters and why real CSV needs quoting |
:::
