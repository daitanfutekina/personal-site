---
title: "Chapter 7 — User-Defined Functions"
source: "cpp_ch7_functions.html"
---

CSE 1384

# Chapter 7 — User-Defined Functions

§7.1 – §7.20

## §7.1 – §7.3 · Function Basics

A **function** is a named, reusable block of code that performs one well-defined task. Functions are the primary tool for breaking a large program into manageable, testable pieces — a principle called *decomposition*.

### Anatomy of a function definition

```cpp
//  return-type   name     (parameter list)
    int           square   (int x)
{
    return x * x;   // return statement sends value back to caller
}
```

Every function has four components:

- **Return type** — the type of value sent back (`int`, `double`, `string`, or `void` for none)
- **Name** — a verb or verb-phrase that describes what the function does
- **Parameter list** — inputs the function needs (may be empty)
- **Body** — the statements that do the work, enclosed in `{ }`

### §7.2 Void functions — print functions

`void` functions perform an action but do not return a value. They are ideal for output tasks.

```cpp
#include <iostream>
using namespace std;

void printSeparator(int width, char ch = '-') {
    for (int i = 0; i < width; ++i) cout << ch;
    cout << '\n';
}

void printHeader(const string& title) {
    printSeparator(40);
    cout << "  " << title << '\n';
    printSeparator(40);
}

int main() {
    printHeader("Sales Report");
    cout << "Item A: $120\n";
    printSeparator(20, '=');
}
/* Output:
   ----------------------------------------
     Sales Report
   ----------------------------------------
   Item A: $120
   ====================
*/
```

### §7.3 Why decompose into functions?

- **Readability** — `printHeader("Sales")` is clearer than 5 lines of output code inline
- **Reuse** — write once, call anywhere; fix bugs in one place
- **Testability** — small functions with clear contracts are easy to test in isolation
- **Abstraction** — callers only need to know *what* a function does, not *how*

:::callout-key
Single Responsibility Principle

: each function should do exactly one thing and do it well. If you need the word "and" to describe what a function does, it should probably be two functions.
:::

## §7.4 – §7.6 · Return Values, Math & Control Flow

### §7.4 Writing mathematical functions

```cpp
#include <cmath>
using namespace std;

// Hypotenuse of a right triangle
double hypotenuse(double a, double b) {
    return sqrt(a*a + b*b);
}

// Clamp a value to [lo, hi]
double clamp(double val, double lo, double hi) {
    if (val < lo) return lo;
    if (val > hi) return hi;
    return val;
}

// Check if n is prime
bool isPrime(int n) {
    if (n < 2) return false;
    for (int i = 2; i * i <= n; ++i)   // only check up to sqrt(n)
        if (n % i == 0) return false;
    return true;
}

int main() {
    cout << hypotenuse(3, 4)      << '\n'; // 5
    cout << clamp(150, 0, 100)    << '\n'; // 100
    cout << boolalpha << isPrime(17) << '\n'; // true
}
```

:::callout-intuition
The

isPrime

loop only runs to √n because if n has a factor larger than √n, it must also have a corresponding factor

smaller

than √n that would have been found earlier. Using

i \* i <= n

avoids the floating-point cost of

sqrt

.
:::

### §7.5 Functions with branches

```cpp
// Letter grade — every path returns
char letterGrade(int score) {
    if      (score >= 90) return 'A';
    else if (score >= 80) return 'B';
    else if (score >= 70) return 'C';
    else if (score >= 60) return 'D';
    else                  return 'F';
}

// Absolute value (teaching example — std::abs exists)
int myAbs(int n) {
    return (n < 0) ? -n : n;
}
```

:::callout-pitfall
Missing return path

: if a non-void function can fall off the end without hitting a

return

, the compiler warns (or errors). Always ensure every control-flow path returns a value. The if-else chain above is correct; an if-without-else chain risks missing the final

return

.
:::

### §7.6 Functions with loops

```cpp
// Sum of digits of a non-negative integer
int digitSum(int n) {
    int sum = 0;
    while (n > 0) {
        sum += n % 10;   // last digit
        n   /= 10;       // chop last digit
    }
    return sum;
}
// digitSum(1234) → 10

// Repeat a string n times
string repeat(const string& s, int n) {
    string result;
    for (int i = 0; i < n; ++i) result += s;
    return result;
}
// repeat("ab", 3) → "ababab"

// Count vowels
int countVowels(const string& s) {
    int count = 0;
    string vowels = "aeiouAEIOU";
    for (char c : s)
        if (vowels.find(c) != string::npos) ++count;
    return count;
}
```

## §7.7 – §7.9 · Unit Testing, the Call Stack & Common Errors

### §7.7 Unit testing functions

A **unit test** calls a function with known inputs and asserts the output matches expectations. Testing small functions in isolation is far easier than debugging a 300-line `main`.

```cpp
#include <iostream>
#include <cassert>
using namespace std;

int square(int x) { return x * x; }

// Simple test harness using assert
void testSquare() {
    assert(square(0)  == 0);
    assert(square(3)  == 9);
    assert(square(-4) == 16);
    assert(square(10) == 100);
    cout << "testSquare: all passed\n";
}

int main() {
    testSquare();
}
```

:::callout-key
assert(expr)

terminates the program with an error message if

expr

is false. It is great for catching logic bugs during development. In production builds,

#define NDEBUG

disables all asserts (zero runtime cost).
:::

A more readable pattern uses a helper that prints pass/fail without aborting:

```cpp
void check(bool condition, const string& testName) {
    cout << (condition ? "PASS" : "FAIL") << " — " << testName << '\n';
}

void testLetterGrade() {
    check(letterGrade(95) == 'A', "score 95 is A");
    check(letterGrade(80) == 'B', "score 80 is B");
    check(letterGrade(59) == 'F', "score 59 is F");
}
```

### §7.8 How functions work — the call stack

Every time a function is called, the runtime creates a **stack frame**: a block of memory that holds the function's local variables and parameters. When the function returns, its frame is destroyed. Frames stack on top of each other — the currently executing function is always on top.

#### Stack trace for `main → hypotenuse → sqrt`

main (caller)

a=3.0, b=4.0

hypotenuse ← executing

a=3.0, b=4.0, (computing sqrt(25))

Stack grows upward; top frame is currently running. When hypotenuse returns 5.0, its frame is popped and main resumes.

```cpp
// Parameters are COPIES of the caller's arguments (pass by value)
void addTen(int x) {
    x += 10;          // modifies the LOCAL copy only
    cout << x << '\n'; // 15
}

int main() {
    int a = 5;
    addTen(a);
    cout << a << '\n'; // still 5 — the original is unchanged
}
```

:::callout-intuition
Think of pass-by-value like giving someone a

photocopy

of a document. They can scribble all over their copy — your original is safe. To let a function modify your original, you need pass-by-reference (§7.10).
:::

### §7.9 Common function errors

| Error | Description | Fix |
| --- | --- | --- |
| Missing return | Non-void function has a path with no `return` | Ensure all branches return a value |
| Wrong return type | `int` function returns `double` — silent truncation | Match return type to computation; use `static_cast` |
| Using before declaring | Calling a function defined *after* `main` | Add a **forward declaration** (prototype) above `main` |
| Parameter mismatch | Calling with wrong number or types of arguments | Check function signature; compiler will catch this |
| Forgetting `return` value | Calling a value-returning function but ignoring the result | Assign or use the return value; compiler may warn |

### Forward declarations (prototypes)

A **prototype** tells the compiler a function's signature before it sees the full definition. This lets you define functions in any order.

```cpp
// Prototypes at top — definitions can appear below main
bool isEven(int n);
bool isOdd(int n);

int main() {
    cout << isEven(4) << '\n';   // works — compiler knows isEven's signature
}

bool isEven(int n) { return n % 2 == 0; }
bool isOdd(int n)  { return !isEven(n); }   // mutual calls work with prototypes
```

## §7.10 – §7.12 · Pass by Reference & C-String Parameters

### §7.10 Pass by reference

Adding `&` to a parameter makes it a **reference** — an alias for the caller's variable. Changes to the parameter *are* changes to the original.

```cpp
void swap(int& a, int& b) {
    int tmp = a;
    a = b;
    b = tmp;
}

int main() {
    int x = 10, y = 20;
    swap(x, y);
    cout << x << ' ' << y << '\n';  // 20 10
}
```

Use pass-by-reference when you need to:

- Modify the caller's variable
- Return multiple values (use multiple ref params)
- Avoid copying a large object (use `const T&`)

#### Example — returning multiple values via reference parameters

```cpp
// Computes both quotient and remainder in one call
void divmod(int dividend, int divisor, int& quotient, int& remainder) {
    quotient  = dividend / divisor;
    remainder = dividend % divisor;
}

int main() {
    int q, r;
    divmod(17, 5, q, r);
    cout << "17 / 5 = " << q << " remainder " << r << '\n';
    // 17 / 5 = 3 remainder 2
}
```

### Pass by value vs. reference — summary

| Passing style | Syntax | Can modify original? | When to use |
| --- | --- | --- | --- |
| By value | `void f(int x)` | No | Small types, no modification needed |
| By reference | `void f(int& x)` | Yes | Must modify caller's variable; returning multiple values |
| By const reference | `void f(const int& x)` | No (enforced) | Large objects (string, vector) — avoid copy, prevent modification |

### §7.11 Modifying string and vector parameters

```cpp
// Capitalize every character in-place
void toUpperCase(string& s) {
    for (char& c : s)        // char& — reference into the string
        c = toupper(c);
}

// Remove all negative values from a vector
void removeNegatives(vector<int>& v) {
    int writeIdx = 0;
    for (int i = 0; i < (int)v.size(); ++i)
        if (v[i] >= 0) v[writeIdx++] = v[i];
    v.resize(writeIdx);
}

int main() {
    string msg = "hello world";
    toUpperCase(msg);
    cout << msg << '\n';   // HELLO WORLD

    vector<int> v = {3, -1, 4, -2, 5};
    removeNegatives(v);
    for (int x : v) cout << x << ' ';  // 3 4 5
}
```

### §7.12 C-string parameters

Before `std::string`, C used null-terminated character arrays (**C-strings**). You may encounter them in legacy code and system APIs.

```cpp
#include <cstring>
using namespace std;

void printCStr(const char* s) {
    while (*s != '\0') { cout << *s; ++s; }
    cout << '\n';
}

int main() {
    const char* greeting = "Hello";   // stored as {'H','e','l','l','o','\0'}
    cout << strlen(greeting) << '\n'; // 5 (excludes null terminator)

    char buf[20];
    strcpy(buf, "copy");              // copy C-string into buffer
    strcat(buf, " me");               // append
    cout << buf << '\n';             // copy me
}
```

:::callout-warning
C-string functions like

strcpy

and

strcat

do

not

check buffer bounds — writing past the end of

buf

corrupts memory. In modern C++, always prefer

std::string

. Use C-strings only when interfacing with C APIs.
:::

## §7.13 – §7.16 · Scope, Default Parameters, Overloading & Error Checking

### §7.13 Scope of variables and functions

A variable's **scope** is the region of code where it is visible. C++ uses *block scope*: a variable lives from its declaration to the closing `}` of the block that contains it.

```cpp
int g = 100;          // global scope — accessible anywhere in this file

void demo() {
    int x = 10;       // local to demo()
    {
        int y = 20;   // local to inner block
        cout << x + y + g << '\n';  // 130 — all three visible here
    }
    // y is gone here — compiler error if referenced
    cout << x << '\n'; // 10
}

int main() {
    demo();
    // x is gone here
    cout << g << '\n'; // 100 — global still accessible
}
```

:::callout-pitfall
Avoid global variables

. They make code harder to test and reason about because any function can change them at any time. Use parameters and return values instead. The only common exception is global

constants

:

const double PI = 3.14159;

at the top of a file is fine.
:::

:::callout-warning
Shadowing

: if a local variable has the same name as a global, the local

shadows

the global inside its scope. The global is not modified — but this silently hides your intent and causes bugs. Use distinct names.

```cpp
int count = 0;             // global
void increment() {
    int count = 0;         // ← shadows global; global is unchanged!
    ++count;
}
```
:::

### §7.14 Default parameter values

You can give parameters default values. Callers may omit trailing arguments that have defaults.

```cpp
// Defaults must appear in the declaration (or prototype), not the definition
void drawBox(int width, int height, char fill = '*', bool border = true);

void drawBox(int width, int height, char fill, bool border) {
    for (int r = 0; r < height; ++r) {
        for (int c = 0; c < width; ++c) {
            bool edge = (r==0 || r==height-1 || c==0 || c==width-1);
            cout << ((border && edge) ? '#' : fill);
        }
        cout << '\n';
    }
}

int main() {
    drawBox(5, 3);          // fill='*', border=true  (both defaults)
    drawBox(6, 2, '.');     // fill='.', border=true  (one default)
    drawBox(4, 4, ' ', false); // no defaults
}
```

:::callout-key
Default parameters must appear

from right to left

in the parameter list — you cannot skip a middle parameter. If you want to supply

border

but not

fill

, you must still provide

fill

.
:::

### §7.15 Function overloading

**Overloading** allows multiple functions to share a name as long as their parameter lists differ in type or count. The compiler picks the correct version at compile time.

```cpp
// Three overloads of "print"
void print(int n)          { cout << "int: "    << n << '\n'; }
void print(double d)       { cout << "double: " << d << '\n'; }
void print(const string& s){ cout << "string: " << s << '\n'; }

// Overloading on arity (number of parameters)
int add(int a, int b)           { return a + b; }
int add(int a, int b, int c)    { return a + b + c; }

int main() {
    print(42);         // int: 42
    print(3.14);       // double: 3.14
    print("hello");    // string: hello
    cout << add(1,2)     << '\n';  // 3
    cout << add(1,2,3)   << '\n';  // 6
}
```

:::callout-pitfall
Overloads are resolved by the compiler based on parameter

types

. Return type alone is

not

enough to distinguish overloads — two functions with the same name and parameters but different return types will cause a compilation error.
:::

### §7.16 Parameter error checking

Defensive functions validate their inputs and handle bad data gracefully rather than producing garbage or crashing.

```cpp
#include <stdexcept>
using namespace std;

// Option A — throw an exception (caller must handle)
double safeDivide(double a, double b) {
    if (b == 0.0)
        throw invalid_argument("Division by zero");
    return a / b;
}

// Option B — return a sentinel value
int safeSqrt(int n) {
    if (n < 0) return -1;   // sentinel: -1 means error
    return static_cast<int>(sqrt(n));
}

// Option C — assert (development-time check only)
#include <cassert>
double factorial(int n) {
    assert(n >= 0 && "factorial requires non-negative input");
    double result = 1;
    for (int i = 2; i <= n; ++i) result *= i;
    return result;
}
```

## §7.17 – §7.18 · Preprocessor & Separate Files

### §7.17 Preprocessor and #include

Before compilation begins, the **preprocessor** runs a text-transformation pass. The most important directives:

| Directive | What it does |
| --- | --- |
| `#include <file>` | Paste the contents of a system header (angle brackets) |
| `#include "file"` | Paste a local header file (quotes — searches current dir first) |
| `#define NAME value` | Text replacement (avoid for constants — use `const` instead) |
| `#ifndef / #define / #endif` | Include guard — prevents a header from being pasted twice |
| `#pragma once` | Modern alternative to include guards (compiler extension) |

```cpp
// mymath.h — a simple header file
#ifndef MYMATH_H   // include guard
#define MYMATH_H

double hypotenuse(double a, double b);
bool   isPrime(int n);
int    clamp(int val, int lo, int hi);

#endif // MYMATH_H
```

### §7.18 Splitting code into multiple files

Real projects separate **declarations** (what things are) from **definitions** (how they work):

```cpp
// ── mymath.h ──────────────────────────────────
#ifndef MYMATH_H
#define MYMATH_H
double hypotenuse(double a, double b);
bool   isPrime(int n);
#endif

// ── mymath.cpp ────────────────────────────────
#include "mymath.h"
#include <cmath>

double hypotenuse(double a, double b) { return sqrt(a*a + b*b); }

bool isPrime(int n) {
    if (n < 2) return false;
    for (int i = 2; i * i <= n; ++i)
        if (n % i == 0) return false;
    return true;
}

// ── main.cpp ──────────────────────────────────
#include <iostream>
#include "mymath.h"    // only the declarations — linker finds the definitions
using namespace std;

int main() {
    cout << hypotenuse(3, 4) << '\n';   // 5
    cout << isPrime(17)      << '\n';   // 1
}
```

Compile with: `g++ main.cpp mymath.cpp -o program`

:::callout-connect
Separate compilation is why large codebases build quickly after small changes — only modified

.cpp

files need to be recompiled. The header file is the

interface contract

; the

.cpp

file is the

implementation

. You'll use this pattern heavily in Data Structures (CSE 2813) and beyond.
:::

## §7.19 – §7.20 · Full Worked Examples

#### Example 1 — Salary calculator refactored into functions (§7.19)

This is the salary problem from Chapter 5, now properly decomposed. Each function has a single responsibility and is independently testable.

```cpp
#include <iostream>
#include <iomanip>
using namespace std;

// Returns gross pay for hours worked at given hourly rate (1.5x after 40h)
double calcGrossPay(double hours, double rate) {
    if (hours <= 40.0)
        return hours * rate;
    return 40.0 * rate + (hours - 40.0) * rate * 1.5;
}

// Returns tax owed based on simplified brackets
double calcTax(double gross) {
    if      (gross < 500)   return gross * 0.10;
    else if (gross < 1500)  return gross * 0.15;
    else                    return gross * 0.25;
}

// Prints a formatted pay stub
void printPayStub(const string& name, double hours, double rate) {
    double gross = calcGrossPay(hours, rate);
    double tax   = calcTax(gross);
    double net   = gross - tax;

    cout << fixed << setprecision(2);
    cout << "\n===== Pay Stub: " << name << " =====\n";
    cout << "Hours worked : " << hours   << '\n';
    cout << "Hourly rate  : $" << rate   << '\n';
    cout << "Gross pay    : $" << gross  << '\n';
    cout << "Tax withheld : $" << tax    << '\n';
    cout << "Net pay      : $" << net    << '\n';
}

// Unit tests
void runTests() {
    assert(calcGrossPay(40, 10.0) == 400.0);          // no overtime
    assert(calcGrossPay(45, 10.0) == 475.0);          // 5h OT at 1.5x
    assert(calcTax(400.0)  == 40.0);                  // 10% bracket
    assert(calcTax(1000.0) == 150.0);                 // 15% bracket
    cout << "All salary tests passed.\n";
}

int main() {
    runTests();
    printPayStub("Alice",  40.0, 15.00);
    printPayStub("Bob",    48.5, 12.50);
}
/* Output:
   All salary tests passed.
   ===== Pay Stub: Alice =====
   Hours worked : 40.00
   Hourly rate  : $15.00
   Gross pay    : $600.00
   Tax withheld : $90.00
   Net pay      : $510.00
   ...
*/
```

#### Example 2 — Domain name validator decomposed (§7.20)

Domain validation broken into small, testable helper functions.

```cpp
#include <iostream>
#include <string>
#include <cctype>
using namespace std;

bool isValidLength(const string& domain) {
    return domain.length() >= 4 && domain.length() <= 253;
}

bool hasValidChars(const string& domain) {
    for (char c : domain)
        if (!isalnum(c) && c != '-' && c != '.')
            return false;
    return true;
}

bool hasValidTLD(const string& domain) {
    size_t dot = domain.rfind('.');
    if (dot == string::npos) return false;
    string tld = domain.substr(dot + 1);
    return tld.length() >= 2 && tld.length() <= 6;
}

bool isValidDomain(const string& domain) {
    return isValidLength(domain)
        && hasValidChars(domain)
        && hasValidTLD(domain);
}

// Demonstrate with tests
void testDomains() {
    struct TestCase { string domain; bool expected; };
    TestCase cases[] = {
        {"google.com",   true},
        {"my-site.org",  true},
        {"bad domain",   false},  // space invalid
        {"x.c",          false},  // TLD too short
        {"ok.io",        true},
    };
    for (auto& tc : cases) {
        bool result = isValidDomain(tc.domain);
        cout << (result == tc.expected ? "PASS" : "FAIL")
             << " \"" << tc.domain << "\": "
             << (result ? "valid" : "invalid") << '\n';
    }
}

int main() { testDomains(); }
```

:::summary
### Chapter 7 — Key Takeaways

- Every function has a **return type, name, parameter list, and body**. Use `void` when nothing is returned.
- Parameters are **copies by default** (pass by value). Add `&` to pass by reference and allow modification of the caller's variable.
- Use `const T&` for large objects (string, vector) to avoid copying without allowing modification.
- **Forward declarations** (prototypes) let you define functions in any order — put them near the top of the file.
- `assert()` and test helper functions make debugging vastly easier — write tests alongside your functions.
- **Default parameters** must appear right-to-left in the signature and are specified only in the declaration.
- **Overloaded functions** share a name but differ in parameter types or count — the compiler resolves the call at compile time.
- **Include guards** (`#ifndef / #define / #endif`) prevent a header from being included twice.
- Split large programs into `.h` (interface) and `.cpp` (implementation) files; compile all `.cpp` files together.
- Avoid global variables; prefer parameters and return values to share data between functions.
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Reverse a String (in-place)

Write `void reverseString(string& s)` that reverses `s` in-place using pass-by-reference. Do not use `std::reverse`.

::::solution[Solution]
```cpp
void reverseString(string& s) {
    int lo = 0, hi = (int)s.length() - 1;
    while (lo < hi) {
        swap(s[lo], s[hi]);
        ++lo; --hi;
    }
}
// reverseString("hello") → s becomes "olleh"
```

Two-pointer approach identical to array reversal. Because `s` is passed by reference, the swap modifies the caller's string directly.
::::
:::

:::problem{difficulty="easy"}
P2 — Length of Last Word

Write `int lengthOfLastWord(const string& s)`. Given a string of words separated by spaces, return the length of the last word. Trailing spaces should be ignored. Example: `"Hello World "` → `5`.

::::solution[Solution]
```cpp
int lengthOfLastWord(const string& s) {
    int i = (int)s.length() - 1;
    // Skip trailing spaces
    while (i >= 0 && s[i] == ' ') --i;
    // Count last word
    int len = 0;
    while (i >= 0 && s[i] != ' ') { ++len; --i; }
    return len;
}
// "Hello World  " → 5
// "   fly me   to   the moon  " → 4
```

Walk backward: skip spaces, then count non-spaces. Two clean while loops, each with one job.
::::
:::

:::problem{difficulty="standard"}
P3 — Overloaded max3

Write three overloads of `max3` — one for `int`, one for `double`, and one for `string` (lexicographic max) — each taking three parameters and returning the largest.

::::solution[Solution]
```cpp
int    max3(int a, int b, int c)               { return max(a, max(b, c)); }
double max3(double a, double b, double c)      { return max(a, max(b, c)); }
string max3(const string& a, const string& b,
            const string& c)                  { return max(a, max(b, c)); }

int main() {
    cout << max3(3, 1, 4)            << '\n'; // 4
    cout << max3(1.5, 2.7, 0.9)     << '\n'; // 2.7
    cout << max3("apple","zebra","mango") << '\n'; // zebra
}
```
::::
:::

:::problem{difficulty="standard"}
P4 — isPalindrome with functions

Write `bool isPalindrome(const string& s)` using helper functions: one to strip non-alphanumeric characters and lowercase everything, and one to check if the cleaned string reads the same forwards and backwards.

::::solution[Solution]
```cpp
#include <cctype>
string cleanString(const string& s) {
    string result;
    for (char c : s)
        if (isalnum(c)) result += tolower(c);
    return result;
}

bool isPalindrome(const string& s) {
    string clean = cleanString(s);
    int lo = 0, hi = (int)clean.length() - 1;
    while (lo < hi) {
        if (clean[lo] != clean[hi]) return false;
        ++lo; --hi;
    }
    return true;
}
// isPalindrome("A man, a plan, a canal: Panama") → true
// isPalindrome("race a car") → false
```
::::
:::

:::problem{difficulty="challenge"}
P5 — Reverse Words in a String

Write `string reverseWords(const string& s)`. Given a sentence, reverse the order of the words. Multiple spaces between words should collapse to a single space, and leading/trailing spaces should be removed. Example: `" the sky is blue "` → `"blue is sky the"`.

::::solution[Solution]
```cpp
#include <sstream>
#include <vector>
string reverseWords(const string& s) {
    istringstream iss(s);
    vector<string> words;
    string word;
    while (iss >> word) words.push_back(word);  // >> skips whitespace

    string result;
    for (int i = (int)words.size() - 1; i >= 0; --i) {
        if (!result.empty()) result += ' ';
        result += words[i];
    }
    return result;
}
// "  the sky  is blue  " → "blue is sky the"
```

`istringstream >>` automatically handles multiple spaces, leading/trailing whitespace. Collect words into a vector, then build result in reverse order.
::::
:::

:::problem{difficulty="easy"}
P6 — Pass by Value vs Reference

Predict the output of the following code. Then rewrite `doubleIt` using pass-by-reference so it actually modifies the caller's variable.

```cpp
void doubleIt(int x) { x *= 2; }

int main() {
    int n = 5;
    doubleIt(n);
    cout << n << "
";   // What prints?
}
```

::::solution[Solution]
**Output: `5`** — `x` is a copy of `n`. Modifying `x` inside the function has no effect on `n` in the caller.

```cpp
void doubleIt(int& x) { x *= 2; }   // & makes it a reference

int main() {
    int n = 5;
    doubleIt(n);
    cout << n << "
";   // Now prints: 10
}
```

Rule of thumb: pass by value when the function shouldn't modify the argument (or the argument is a small primitive). Pass by reference when: (a) you need to modify the caller's variable, or (b) the argument is a large object and copying is expensive (use `const&` for read-only large objects).
::::
:::

:::problem{difficulty="standard"}
P7 — Overloaded Functions

Write three overloaded functions named `area` that compute: (a) area of a circle (radius), (b) area of a rectangle (width, height), (c) area of a triangle (base, height). Then write a test that calls each version. Why does C++ know which to call?

::::solution[Solution]
```cpp
#include <cmath>
const double PI = 3.14159265358979;

double area(double radius)                         { return PI * radius * radius; }
double area(double width, double height)           { return width * height; }
double area(double base, double height, bool tri)  { return 0.5 * base * height; }
// (bool parameter needed to distinguish triangle from rectangle call)

// Better: use named overloads or a shape type enum.
// Common pattern: use distinct parameter types or counts.

int main() {
    cout << area(5.0)         << "
";     // circle: 78.54
    cout << area(4.0, 6.0)    << "
";     // rectangle: 24
    cout << area(3.0,8.0,true)<< "
";     // triangle: 12
}
```

**C++ resolves overloads by signature** (number and types of parameters) at compile time. Return type alone cannot distinguish overloads. If two overloads have identical parameter types, the compiler produces a "ambiguous call" error.
::::
:::

:::problem{difficulty="standard"}
P8 — Recursive vs Iterative

Write both a recursive and an iterative implementation of `sumDigits(n)` that returns the sum of the digits of a non-negative integer n. Compare them for n=9875. Which is more efficient and why?

::::solution[Solution]
```cpp
// Iterative — O(d) time, O(1) space where d = number of digits
int sumDigitsIter(int n) {
    int sum = 0;
    while (n > 0) {
        sum += n % 10;   // extract last digit
        n /= 10;          // remove last digit
    }
    return sum;
}

// Recursive — O(d) time, O(d) space (call stack)
int sumDigitsRec(int n) {
    if (n < 10) return n;           // base case: single digit
    return n % 10 + sumDigitsRec(n / 10);
}

// n=9875: 5 + 7 + 8 + 9 = 29
```

**Comparison:** Both are O(d) time where d = log₁₀(n). The iterative version is more efficient in practice — O(1) space versus O(d) stack frames for the recursive version. For small numbers (d ≤ 10 for 32-bit int), the difference is negligible. The recursive version is more elegant and demonstrates the base-case/reduction pattern clearly.
::::
:::

:::problem{difficulty="standard"}
P9 — Default Parameters & Function Design

Design a function `printBorder(int width, char ch, bool newline)` that prints a horizontal border of `width` copies of character `ch`, optionally followed by a newline. Add default parameters so it can be called as: `printBorder(20)`, `printBorder(10, '*')`, and `printBorder(15, '-', false)`. What rule governs where default parameters can appear?

::::solution[Solution]
```cpp
// Default parameters must come RIGHTMOST in the parameter list
void printBorder(int width, char ch = '=', bool newline = true) {
    for (int i = 0; i < width; ++i) cout << ch;
    if (newline) cout << '
';
}

int main() {
    printBorder(20);           // ====================
    printBorder(10, '*');      // **********
    printBorder(15, '-', false);  // --------------- (no newline)
    printBorder(5);            // =====  (next line since previous had no newline)
}
```

**Rule:** Default arguments must be rightmost — you cannot have a default parameter followed by a non-default one. This is because C++ resolves which argument maps to which parameter left-to-right; a gap in the middle would be ambiguous.

**Good design:** default parameters are most useful when one value is "typical" (here: `'='` for borders, `true` for newline). Don't use defaults as a substitute for clear function design — if two variants are conceptually distinct operations, separate functions are cleaner.
::::
:::

:::callout-tip
These problems are excellent for practicing clean function decomposition and pass-by-reference. Aim to solve each one as a standalone function, then write a short test harness in `main`.

| # | Problem | Difficulty | Key Technique |
| --- | --- | --- | --- |
| 344 | [Reverse String](https://leetcode.com/problems/reverse-string/) | Easy | void function + pass vector by reference, two-pointer |
| 58 | [Length of Last Word](https://leetcode.com/problems/length-of-last-word/) | Easy | Backward scan with const string& parameter |
| 541 | [Reverse String II](https://leetcode.com/problems/reverse-string-ii/) | Easy | Helper reverseRange function + loop with step 2k |
:::
