---
title: "Chapter 14: Inheritance"
crumb: "C++ · Chapter 14"
meta:
  - "Est. study time: ~2.5 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 14: Inheritance

## Overview

Chapter 13 built classes that stand alone. This chapter connects them: **inheritance** lets one
class acquire everything another class has, and then add to it or change it.

The word usually attached to this is "code reuse", and that is the weaker half of the story. You
can already reuse code by calling a function. What inheritance adds is something a function call
cannot do: it lets you write one piece of code that works on objects whose *type you do not know
when you write it*. A function taking a `Shape&` will correctly compute the area of a `Circle`
that had not been invented when the function was compiled.

That is **polymorphism**, and it is what the chapter is really about. The first half — derived
classes, access levels, overriding — is machinery. §14.7 onwards is the payoff.

The machinery has sharp edges, and three of them cause most of the trouble:

- **A missing `virtual` destructor** leaks memory silently through a base pointer.
- **Passing by value slices** the derived part off, and the object quietly loses its identity.
- **Inheritance models "is-a", not "resembles"**, and the classic counterexample — `Square`
  inheriting from `Rectangle` — looks correct right up until it breaks.

Each gets its own section.

:::callout-key[What you'll learn]
- Deriving one class from another, and the three access specifiers
- `protected`, and why it sits between `public` and `private`
- Overriding, `virtual`, and `override`
- Calling base constructors, and the order construction actually happens in
- Abstract classes and pure virtual functions
- Polymorphism, dynamic binding, and the vtable that implements it
- Slicing, virtual destructors, and when *not* to use inheritance
:::

:::callout-tip[Prerequisites]
Chapter 13 in full — classes, constructors, initializer lists, `const` member functions and
access control. Pointers and references from Chapters 6 and 8, since polymorphism only works
through them.
:::

## §14.1 — Derived Classes

**Inheritance** lets one class — the *derived class* or subclass — acquire all the members of
another, the *base class* or superclass. It models an **is-a** relationship: a `Dog` *is an*
`Animal`.

### Syntax

```cpp
#include <iostream>
#include <string>
using namespace std;

class Base {
public:
    int x;
    void hello() { cout << "Base hello\n"; }
};

class Derived : public Base {     // Derived inherits from Base
public:
    int y;
    void world() { cout << "Derived world, x=" << x << "\n"; }
};

int main() {
    Derived d;
    d.x = 10;       // inherited from Base
    d.y = 20;       // own member
    d.hello();      // inherited method
    d.world();      // own method
}
```

A `Derived` object *contains* a complete `Base` object. `d.x` is not a copy or a forwarding
trick — the `Base` sub-object is physically part of `d`, laid out first in memory, and `x` is its
member. That layout is what makes the next section's conversions work at all: a `Derived*` can be
used as a `Base*` because the `Base` part is right there at the start of the object.

Here is the hierarchy the rest of the section builds, in the UML notation you will meet in design
documents:

```
              ┌───────────────────────────┐
              │          Animal           │
              ├───────────────────────────┤
              │ # name : string           │
              │ # age  : int              │
              ├───────────────────────────┤
              │ + eat()      : void       │
              │ + sleep()    : void       │
              │ + describe() : string     │
              └─────────────┬─────────────┘
                            △  (inherits)
              ┌─────────────┴─────────────┐
              │                           │
    ┌─────────────────────┐   ┌─────────────────────┐
    │        Dog          │   │        Cat          │
    ├─────────────────────┤   ├─────────────────────┤
    │ − breed  : string   │   │ − indoor : bool     │
    ├─────────────────────┤   ├─────────────────────┤
    │ + bark()   : void   │   │ + purr()   : void   │
    │ + fetch()  : void   │   │ + climb()  : void   │
    └─────────────────────┘   └─────────────────────┘
```

`#` marks protected, `−` private, `+` public. The arrow points from derived to base, which is the
direction of the "is-a" claim: a `Dog` is an `Animal`, not the reverse.

```cpp
class Animal {
protected:                    // accessible to derived classes
    string name;
    int    age;
public:
    Animal(const string& n, int a) : name(n), age(a) {}
    void eat()   const { cout << name << " is eating\n"; }
    void sleep() const { cout << name << " is sleeping\n"; }
    string describe() const {
        return name + " (age " + to_string(age) + ")";
    }
};

class Dog : public Animal {
private:
    string breed;
public:
    Dog(const string& n, int a, const string& b) : Animal(n, a), breed(b) {}
    void bark()  const { cout << name << " says: Woof!\n"; }
    void fetch() const { cout << name << " fetches the ball!\n"; }
    string describe() const {   // hides Animal::describe
        return Animal::describe() + ", " + breed;
    }
};

void demoDog() {
    Dog d("Rex", 3, "Labrador");
    d.eat();            // inherited
    d.bark();           // own
    cout << d.describe() << "\n";  // Rex (age 3), Labrador
}
```

Three things to notice.

**`Dog::bark` reads `name`, which `Dog` never declared.** It can, because `name` is `protected` in
`Animal` — the middle access level, invisible to outside code but visible to derived classes.
Had `name` been `private`, `bark` would not compile and `Dog` would need a getter.

**`Dog::describe` calls `Animal::describe()` explicitly** rather than duplicating the formatting.
That is the common pattern for extending rather than replacing behaviour: do what the base did,
then add. Without the `Animal::` qualifier the call would resolve to `Dog::describe` and recurse
until the stack overflowed.

**`describe` is *hidden* here, not overridden**, because `Animal::describe` is not `virtual`. The
distinction does not matter while you call it on a `Dog`, and matters enormously through an
`Animal*`. §14.3 is about exactly that.

:::callout-key[The three access specifiers in inheritance]
The keyword after the colon controls what happens to inherited members' visibility:

- **`public` inheritance** — public stays public, protected stays protected. Models **is-a**, and
  is what you want in almost every case.
- **`protected` inheritance** — public and protected members both become protected. Rare.
- **`private` inheritance** — public and protected members both become private. Models "implemented
  in terms of" rather than is-a, and composition is nearly always clearer.

**Omitting the keyword defaults to `private` for a `class`** and `public` for a `struct`. So
`class Dog : Animal` is private inheritance, almost certainly by accident — a `Dog*` will not
convert to an `Animal*` and polymorphism silently stops working. Always write `public` explicitly.
:::

## §14.2 — Access by Members of Derived Classes

| Declared in Base as | Accessible in Derived? | Accessible outside? |
| --- | --- | --- |
| `public` | Yes | Yes |
| `protected` | Yes | No |
| `private` | No | No |

:::callout-intuition[What `protected` is for, and why to be sparing with it]
`private` says "only this class". `public` says "anyone". `protected` is the middle setting: this
class and anything derived from it.

It exists because a derived class is in an awkward position — more trusted than outside code,
since it *is* the thing it extends, but not the same class. `Dog::bark` needs `name`; a random
function does not.

The reason to use it sparingly is that **`protected` is part of your public interface to every
future subclass.** Once a member is protected, any derived class anywhere may depend on it, and
changing it breaks them exactly as changing a public member breaks callers. The encapsulation
argument from Chapter 13 applies: a protected data member can be set to anything by any subclass,
so the base class can no longer promise anything about it.

The safer default is private data with protected *accessors*, which lets subclasses read and write
through code you still control.
:::

:::callout-pitfall[Private members are inherited but not accessible]
A `Dog` object *contains* every private member of `Animal` — they occupy space in the object and
the `Animal` constructor initialises them. `Dog`'s own code simply cannot name them.

The distinction matters when you are debugging object sizes or wondering where memory went: the
data is there. It is reachable only through `Animal`'s public and protected functions, which is
what "inherited but not accessible" means.
:::

## §14.3 — Overriding Member Functions

To *override* a base function — replace it in a way that works through a base pointer — the base
version must be declared `virtual`, and the derived version should be marked `override`.

```cpp
class Animal2 {
protected:
    string name;
public:
    Animal2(const string& n) : name(n) {}
    virtual ~Animal2() = default;               // see §14.8
    virtual string speak() const { return "..."; }
    virtual string describe() const {
        return name + " says " + speak();
    }
};

class Dog2 : public Animal2 {
public:
    Dog2(const string& n) : Animal2(n) {}
    string speak() const override { return "Woof!"; }
};

class Cat2 : public Animal2 {
public:
    Cat2(const string& n) : Animal2(n) {}
    string speak() const override { return "Meow"; }
};

void demoSpeak() {
    Dog2 d("Rex");
    Cat2 c("Tom");
    Animal2* pets[] = { &d, &c };
    for (Animal2* p : pets)
        cout << p->describe() << "\n";
    // Rex says Woof!
    // Tom says Meow
}
```

**`describe` is never overridden, and yet its output differs per animal.** It calls `speak()`,
which *is* virtual, so the call inside the base class's own function dispatches to the derived
version. That is the shape most polymorphic designs take: a base class that defines the general
algorithm and calls virtual functions for the parts that vary.

:::callout-key[`virtual` and `override`, and what each does]
**`virtual` on the base function** is what enables dynamic dispatch. Without it, a call through
`Animal2*` runs `Animal2::speak` no matter what the object really is — the decision is made at
compile time from the pointer's declared type.

**`override` on the derived function** changes nothing at runtime. It asks the compiler to check
that this function really does override something, and to fail if it does not. That check is worth
having because the ways to *almost* override are numerous and all silent:

```cpp
string speak()       const override;  // correct
string speak()             override;  // MISSING const — different signature
string Speak()       const override;  // capital S — different name
string speak(int)    const override;  // extra parameter
```

Each of the last three declares a brand-new function that hides nothing. Without `override` they
compile happily, and the program calls the base version forever while you stare at code that looks
right. **Write `override` on every override.**

**`final`** is the related keyword: `string speak() const final;` permits no further overriding
below this point.
:::

:::problem[Practice 14.3 easy]{difficulty="easy"}
**Shape hierarchy.** Create a base class `Shape` with a virtual `area()` returning 0, and derived
`Circle` and `Square` classes that override it. Demonstrate that the right version is called
through a `Shape*`.

::::solution[Solution]
```cpp
class Shape0 {
public:
    virtual ~Shape0() = default;
    virtual double area() const { return 0.0; }
    virtual string name() const { return "Shape"; }
};

class Circle0 : public Shape0 {
    double r;
public:
    Circle0(double r) : r(r) {}
    double area() const override { return 3.14159265 * r * r; }
    string name() const override { return "Circle"; }
};

class Square0 : public Shape0 {
    double s;
public:
    Square0(double s) : s(s) {}
    double area() const override { return s * s; }
    string name() const override { return "Square"; }
};

void demoShapes() {
    Circle0 c(2.0);
    Square0 q(3.0);
    Shape0* shapes[] = { &c, &q };
    for (const Shape0* s : shapes)
        cout << s->name() << ": " << s->area() << "\n";
    // Circle: 12.5664
    // Square: 9
}
```

**Every one of the three `virtual` keywords matters.** Remove it from `area()` and the loop prints
`0` twice, because the call is resolved from the pointer's type. Remove it from the destructor and
this particular code is still fine — the objects are stack-allocated, so `~Shape0` is never called
through a pointer — but the moment anything is `new`ed, it leaks. §14.8 covers that.

**Returning 0 from the base is a design choice worth questioning.** It means `Shape0` is
instantiable and reports an area of zero, which is not a meaningful shape. Making `area()` *pure*
virtual — §14.6 — forbids that and forces every subclass to answer.
::::
:::

## §14.4 — Calling Base Class Constructors & Functions

### Base class constructors

A derived constructor must ensure its base sub-object is constructed. It does that in the
initializer list, before its own members:

```cpp
class Vehicle {
protected:
    string make;
    int    wheels;
public:
    Vehicle(const string& m, int w) : make(m), wheels(w) {
        cout << "Vehicle constructed\n";
    }
    virtual ~Vehicle() { cout << "Vehicle destroyed\n"; }
};

class Car : public Vehicle {
    int doors;
public:
    Car(const string& m, int d)
        : Vehicle(m, 4),      // base constructor FIRST
          doors(d) {
        cout << "Car constructed\n";
    }
    ~Car() override { cout << "Car destroyed\n"; }
};

void demoOrder() {
    Car c("Toyota", 4);
}
// Output:
// Vehicle constructed
// Car constructed
// Car destroyed
// Vehicle destroyed
```

:::callout-key[Construction runs base-first, destruction derived-first]
The order is fixed by the language and is not negotiable:

1. The base sub-object is constructed.
2. The derived class's own members are constructed, in declaration order.
3. The derived constructor's body runs.

Destruction runs exactly backwards. The output above shows both.

**The reason is dependency.** A derived constructor's body may use inherited members, so the base
must already be built. On the way out, a derived destructor may still need the base parts, so the
base is torn down last.

**If you do not call a base constructor explicitly**, the compiler inserts a call to the base's
*default* constructor. When the base has no default constructor — as `Vehicle` does not — that is
a compile error, and the fix is to name it in the initializer list.
:::

### Calling the overridden version explicitly

```cpp
class Logger {
public:
    virtual ~Logger() = default;
    virtual void log(const string& msg) const {
        cout << "[LOG] " << msg << "\n";
    }
};

class TimestampLogger : public Logger {
public:
    void log(const string& msg) const override {
        cout << "[12:00] ";
        Logger::log(msg);       // extend, don't replace
    }
};
```

The `Logger::` qualifier says "call the base version, not whatever is most derived". It is the
only way to reuse the behaviour you are overriding, and it turns off virtual dispatch for that one
call — which is exactly what you want here, since dispatching would call `TimestampLogger::log`
again and recurse forever.

:::callout-intuition[Extend or replace]
Overriding gives you a choice, and it is worth making deliberately.

**Replace**: ignore the base version entirely. Right when the derived behaviour has nothing to do
with the base's — `Circle::area` shares no logic with a generic `Shape::area`.

**Extend**: call `Base::f()` and add to it. Right when the base does something every subclass
needs — logging, validation, resource setup — and the derived class only adds.

A third pattern avoids the choice: the base defines a non-virtual public function that does the
common work and calls a *protected virtual* hook for the varying part. Subclasses override the
hook and cannot forget to call the base, because the base is the only caller.
:::

## §14.5 — Abstract Classes: Introduction

Sometimes a base class exists purely to define an interface, and instantiating it makes no sense.
What is the area of "a shape"? The question has no answer, and a base class that returns 0 is
answering it wrongly rather than refusing.

An **abstract class** is one that cannot be instantiated. You make a class abstract by giving it
at least one **pure virtual** function — a virtual function with `= 0` in place of a body.

## §14.6 — Abstract Classes & Pure Virtual Functions

```cpp
class Employee2 {
protected:
    string name;
    int    id;
public:
    Employee2(const string& n, int i) : name(n), id(i) {}
    virtual ~Employee2() = default;

    // Pure virtual — no implementation here, subclasses MUST provide one
    virtual double calculatePay() const = 0;

    // Ordinary virtual — a default subclasses may keep or replace
    virtual string describe() const {
        return name + " (#" + to_string(id) + ")";
    }
};

class SalariedEmployee : public Employee2 {
    double annual;
public:
    SalariedEmployee(const string& n, int i, double a)
        : Employee2(n, i), annual(a) {}
    double calculatePay() const override { return annual / 26; }
};

class HourlyEmployee : public Employee2 {
    double rate, hours;
public:
    HourlyEmployee(const string& n, int i, double r, double h)
        : Employee2(n, i), rate(r), hours(h) {}
    double calculatePay() const override {
        return hours <= 40 ? rate * hours
                           : 40 * rate + (hours - 40) * rate * 1.5;
    }
};
```

**`Employee2 e("x", 1);` will not compile**, and that is the feature. The class has a pure virtual
function, so it is abstract, and the compiler refuses to create one. There is no way to end up with
an "employee" whose pay is undefined.

**A pure virtual function may still have a body.** `= 0` means "subclasses must override", not
"there is no implementation". Providing one gives subclasses a `Base::f()` to call for shared
default behaviour while still forcing each to say so explicitly.

**`calculatePay` is pure; `describe` is not.** That is a deliberate split: every employee is paid
differently, so there is no sensible default and the compiler should insist. Every employee
describes the same way, so a default is right and subclasses override only if they want to.

:::callout-connect[Abstract classes are C++'s interfaces]
A class with *only* pure virtual functions and a virtual destructor is what other languages call an
**interface**:

```cpp
class Drawable {
public:
    virtual ~Drawable() = default;
    virtual void draw() const = 0;
};
```

C++ has no `interface` keyword because it does not need one — this is the same thing, and unlike a
Java interface it may also carry data and implementations when that is useful.

Since C++ permits multiple inheritance, a class can implement several such interfaces at once:
`class Sprite : public Drawable, public Serializable`. That is the one case where multiple
inheritance is uncontroversial, because interfaces carry no state to conflict.
:::

## §14.7 — Polymorphism

**Polymorphism** — "many forms" — means one interface can refer to objects of different types, with
the correct function selected at runtime from the object's actual type.

```cpp
#include <vector>
#include <memory>

class Shape {
public:
    virtual double area()   const = 0;
    virtual string name()   const = 0;
    virtual ~Shape() = default;
};

class Circle : public Shape {
    double r;
public:
    Circle(double r) : r(r) {}
    double area() const override { return 3.14159 * r * r; }
    string name() const override { return "Circle"; }
};

class Rectangle : public Shape {
    double w, h;
public:
    Rectangle(double w, double h) : w(w), h(h) {}
    double area() const override { return w * h; }
    string name() const override { return "Rectangle"; }
};

class Triangle : public Shape {
    double base, height;
public:
    Triangle(double b, double h) : base(b), height(h) {}
    double area() const override { return 0.5 * base * height; }
    string name() const override { return "Triangle"; }
};

// Polymorphic function — works for ANY Shape
void printShapeInfo(const Shape& s) {
    cout << s.name() << ": area = " << s.area() << "\n";
}

double totalArea(const vector<Shape*>& shapes) {
    double total = 0;
    for (const Shape* s : shapes) total += s->area();
    return total;
}
```

Using it:

```cpp
void demoPolymorphism() {
    // Base-class pointers to derived objects
    vector<Shape*> shapes = {
        new Circle(5),
        new Rectangle(4, 6),
        new Triangle(3, 8)
    };

    for (const Shape* s : shapes)
        printShapeInfo(*s);      // correct override called each time

    cout << "Total: " << totalArea(shapes) << "\n";

    for (Shape* s : shapes) delete s;  // cleanup
}
```

**Note what `printShapeInfo` and `totalArea` do not contain**: no `if`, no `switch`, no type tag.
Without polymorphism, `totalArea` would need a chain of type tests and would have to be edited
every time a new shape was added. Here, adding a `Hexagon` requires touching neither function —
they were compiled before `Hexagon` existed and work on it anyway.

That is the property worth the machinery: **new types can be added without modifying existing
code.**

**The `vector` holds `Shape*`, not `Shape`, and it has to.** A `vector<Shape>` is impossible —
`Shape` is abstract — and even with a concrete base it would slice every element down to the base
part (§14.8). Polymorphism requires a pointer or a reference, always.

**The three areas** are $\pi \cdot 25 \approx 78.54$, $4 \times 6 = 24$, and
$\tfrac12 \times 3 \times 8 = 12$, totalling about $114.54$.

:::callout-key[Prefer smart pointers to raw `new`]
The loop of `delete`s at the end is a bug waiting to happen: an early `return` or a thrown
exception between the `new`s and the `delete`s leaks everything.

```cpp
vector<unique_ptr<Shape>> shapes;
shapes.push_back(make_unique<Circle>(5));
shapes.push_back(make_unique<Rectangle>(4, 6));
// no delete loop — destruction is automatic, exception-safe, and
// still polymorphic because unique_ptr holds a Shape*
```

`unique_ptr` calls `delete` in its own destructor, which runs during stack unwinding as well as on
a normal return. It is the same RAII argument as Chapter 15's, applied to polymorphic ownership,
and it depends on the base destructor being `virtual`.
:::

## §14.8 — Dynamic Binding & Virtual Tables

Understanding the mechanism makes the pitfalls predictable rather than mysterious.

### How the vtable works

```text
Object layout in memory (with virtual functions):

Circle object:
┌─────────────────┐
│  vptr  ──────────────► Circle vtable
│  radius = 5.0   │      [0] Circle::area()
└─────────────────┘      [1] Circle::name()
                         [2] Circle::~Circle()

Rectangle object:
┌─────────────────┐
│  vptr  ──────────────► Rectangle vtable
│  w = 4.0        │      [0] Rectangle::area()
│  h = 6.0        │      [1] Rectangle::name()
└─────────────────┘      [2] Rectangle::~Rectangle()

Shape* ptr = new Circle(5);
ptr->area();   // follows vptr → Circle vtable → Circle::area()  ✓
```

A class with any virtual function gets one hidden pointer per object — the **vptr** — pointing at a
per-class table of function addresses, the **vtable**. A virtual call reads the vptr, indexes the
table, and jumps.

Three consequences follow directly from that picture.

**The cost is one pointer per object and one indirection per call.** That is small but not nothing:
it also prevents inlining, since the target is unknown until runtime. This is why C++ makes you ask
for `virtual` rather than giving it by default — you pay only where you use it.

**The vptr is set by the constructor**, base part first, then derived. So during the `Shape`
constructor the object's vptr still points at `Shape`'s vtable, and a virtual call made from inside
a base constructor dispatches to the *base* version, not the derived one. Calling virtual functions
from constructors is therefore a trap: the object is not yet the type you think it is.

**Copying copies the data, not the identity.** The vptr belongs to the object, and this is precisely
what goes wrong next.

### The slicing problem

```cpp
// A concrete base, so it CAN be passed by value — which is the danger.
class Animal3 {
protected:
    string name;
public:
    Animal3(const string& n) : name(n) {}
    virtual ~Animal3() = default;
    virtual string speak() const { return "..."; }
};

class Dog3 : public Animal3 {
public:
    Dog3(const string& n) : Animal3(n) {}
    string speak() const override { return "Woof!"; }
};

// DANGER: passing by value copies only the Animal3 part
void bad(Animal3 a) {
    cout << a.speak() << "\n";     // always "..." — the Dog3 part is gone
}

// CORRECT: pass by reference or pointer — no copy, vptr preserved
void good(const Animal3& a) {
    cout << a.speak() << "\n";     // "Woof!" for a Dog3
}
```

**Slicing is what happens when a derived object is copied into a base-shaped box.** A `Dog3` is
larger than an `Animal3`; copying it into an `Animal3` parameter copies only the `Animal3` part and
discards the rest, vptr included. What arrives is a genuine `Animal3` — not a broken `Dog3` — so
`speak()` correctly returns `"..."`. Nothing crashes and nothing warns.

**Note that the base here is concrete, and it has to be for the bug to occur at all.** With an
abstract base, `void bad(Shape s)` does not compile: you cannot pass an abstract class by value.
That is the language protecting you, and it is why abstract bases are safer — but any concrete base
class remains sliceable.

The fix is always the same: **pass polymorphic types by reference or pointer, never by value.**

:::callout-pitfall[Always give a polymorphic base a virtual destructor]
```cpp
class Base { public: ~Base() { } };          // NOT virtual — bug
class Derived : public Base {
    int* buffer;
public:
    Derived() : buffer(new int[1000]) {}
    ~Derived() { delete[] buffer; }
};

void leak() {
    Base* p = new Derived();
    delete p;    // calls ~Base() only. ~Derived() never runs. 4KB leaked.
}
```

Deleting through a base pointer with a non-virtual destructor is **undefined behaviour**, and the
usual symptom is a silent leak: the derived destructor simply never runs, so whatever it would have
freed is not freed.

The fix is one word:

```cpp
class Base { public: virtual ~Base() = default; };
```

**The rule: if a class has any virtual function, give it a virtual destructor.** If it has none and
is not meant to be a base, that is fine — a virtual destructor on a class that never needs one adds
a vptr to every object for nothing.
:::

### Static vs. dynamic binding

| Feature | Static binding | Dynamic binding |
| --- | --- | --- |
| Decided at | Compile time | Runtime |
| Triggered by | Non-virtual functions, or calls on a value | `virtual` function via pointer or reference |
| Cost | None | One pointer dereference; no inlining |
| Flexibility | The type must be known when compiling | Works for types written later |

Both are needed for dynamic dispatch: a virtual function **and** a call through a pointer or
reference. A virtual function called on a value binds statically, because the value's type is known
exactly — which is another way of saying that slicing removes polymorphism.

## §14.9 — Inheritance Hierarchies

Hierarchies can go deeper than one level, and each level adds to the one above:

```cpp
class LivingThing {
public:
    virtual ~LivingThing() = default;
    virtual string classify() const { return "Living thing"; }
};

class Animal4 : public LivingThing {
public:
    string classify() const override { return "Animal"; }
    virtual string move() const { return "moves somehow"; }
};

class Mammal : public Animal4 {
public:
    string classify() const override { return "Mammal"; }
    virtual bool hasFur() const { return true; }
};

class Dog4 : public Mammal {
public:
    string classify() const override { return "Dog"; }
    string move() const override { return "runs on four legs"; }
};
```

A `Dog4` is simultaneously a `Mammal`, an `Animal4` and a `LivingThing`, and may be used wherever
any of them is expected. Each level's constructor runs in order from the top down, and the
destructors in reverse.

:::callout-warning[Deep hierarchies are usually a mistake]
Three or four levels is where inheritance starts causing more trouble than it saves.

**Every level is a dependency.** A change to `LivingThing` can break `Dog4` through two
intermediaries, and the code that breaks is nowhere near the code that changed. This is the
*fragile base class* problem.

**Behaviour becomes hard to locate.** Answering "what does `d.classify()` do?" means checking four
classes to find which one last overrode it.

**Real taxonomies do not fit single inheritance.** A `Penguin` is a `Bird` that cannot fly; a `Bat`
is a `Mammal` that can. Any hierarchy deep enough to be interesting eventually meets a case that
belongs in two branches.

The usual remedy is **composition**: instead of `Dog4` inheriting movement from three levels up,
give it a `MovementStrategy` member. Behaviour becomes a thing you assemble rather than a place in
a tree, and it can change at runtime.
:::

## §14.10 — Is-a Relationships & Design Guidelines

| Relationship | Implement as | Example |
| --- | --- | --- |
| Is-a | Inheritance (public) | Dog is-a Animal |
| Has-a | Composition (member) | Car has-a Engine |
| Uses-a | Parameter or local | Painter uses-a Brush |

The test for whether inheritance is right is not whether the two things are related, nor whether
one has all the other's data. It is the **Liskov Substitution Principle**: anywhere the base type
is expected, a derived object must work correctly — not merely compile.

### The classic violation: Square inheriting from Rectangle

```cpp
#include <cassert>

// PROBLEM: "a square is a rectangle" is true in geometry
// and false in code.

class Rect {
protected:
    double w, h;
public:
    Rect(double w, double h) : w(w), h(h) {}
    virtual ~Rect() = default;
    virtual void setWidth(double nw)  { w = nw; }
    virtual void setHeight(double nh) { h = nh; }
    double width()  const { return w; }
    double height() const { return h; }
    double area()   const { return w * h; }
};

class Square : public Rect {
public:
    Square(double s) : Rect(s, s) {}
    // must keep the invariant width == height
    void setWidth(double nw)  override { w = h = nw; }
    void setHeight(double nh) override { w = h = nh; }
};

// A function that is correct for every Rect
void doubleWidth(Rect& r) {
    double oldArea = r.area();
    r.setWidth(r.width() * 2);
    assert(r.area() == oldArea * 2);   // holds for Rect, FAILS for Square
}
```

**Trace it on a $3 \times 3$ square.** The old area is 9. `setWidth(6)` sets the width *and the
height* to 6, because a square must stay square. The new area is 36, not 18 — the assertion fails.

**Nothing here is a coding mistake.** `Square::setWidth` is correct in isolation: a square whose
width changes must change its height too. `doubleWidth` is correct in isolation: for any rectangle,
doubling the width doubles the area. They are individually right and jointly wrong, which is what
makes this failure worth studying — no amount of care in either function would have prevented it.

**The real error is the `is-a` claim.** A `Rect` promises that width and height move independently.
A `Square` cannot keep that promise. It has a *stricter* invariant, and inheritance requires the
derived class to promise at least as much as the base, never less.

:::callout-warning[The fix, and the general rule]
Do not derive `Square` from `Rect`. Give both an abstract `Shape` base with a pure virtual
`area()`, and let neither claim to be substitutable for the other.

Note also that the problem disappears entirely if `Rect` is **immutable** — with no setters there is
no promise about independent modification to break, and `Square` may safely derive from it. Many
LSP violations are really mutability problems wearing an inheritance costume.

**The rule to carry away:** before writing `: public Base`, ask what the base *promises*, and
whether the derived class can keep every one of those promises. If it must weaken one, it is not a
subtype — whatever the English sentence sounds like.
:::

### Composition over inheritance

```cpp
class Engine {
    int horsepower;
public:
    Engine(int hp) : horsepower(hp) {}
    void start() const { cout << "Engine starting (" << horsepower << " hp)\n"; }
};

// PREFER: has-a, rather than a fragile inheritance chain
class Car2 {
    Engine engine;        // Car HAS-A Engine
    string make;
public:
    Car2(const string& m, int hp) : engine(hp), make(m) {}
    void start() const {
        cout << make << ": ";
        engine.start();   // delegate
    }
};
```

`Car2` is not an `Engine` and does not pretend to be. It holds one and forwards to it, which is
both accurate and more flexible: the engine can be swapped, held by pointer, shared, or replaced at
runtime — none of which a base class allows, since a base is fixed at compile time.

**The default should be composition.** Reach for inheritance when you specifically need
polymorphism — one interface, many implementations, selected at runtime. When all you want is to
reuse an implementation, a member does it with fewer consequences.

## Chapter summary

:::callout-key[Mechanics]
- `class D : public B` — always write `public`, or you silently get private inheritance
- `protected` is visible to derived classes and nobody else; prefer private data with protected
  accessors
- `virtual` on the base enables dispatch; `override` on the derived makes the compiler check
- Construction runs base-first, destruction derived-first
- `= 0` makes a function pure virtual and the class abstract — it cannot be instantiated
- `Base::f()` calls the base version explicitly and skips dispatch
- A virtual call needs both a `virtual` function *and* a pointer or reference
:::

:::callout-tip[Traps and design]
- **Always give a polymorphic base a `virtual` destructor** — otherwise `delete` through a base
  pointer leaks the derived part
- **Never pass a polymorphic type by value** — slicing discards the derived part silently
- Do not call virtual functions from a constructor; the vptr is not yet the derived one
- Deep hierarchies are fragile — three levels is usually too many
- Use inheritance for **is-a** substitutability, composition for **has-a**
- Test the is-a claim with Liskov: can the derived class keep *every* promise the base makes?
- Prefer `unique_ptr` to raw `new` for polymorphic ownership
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Account hierarchy.** Write an abstract `Account` with a pure virtual `monthlyInterest()`, and
derive `Savings` (2% annual) and `Checking` (no interest, $5 monthly fee, so the return is
negative). Show both through an `Account*`.

::::solution[Solution]
```cpp
class Account {
protected:
    double balance;
public:
    Account(double b) : balance(b) {}
    virtual ~Account() = default;
    virtual double monthlyInterest() const = 0;
    virtual string type() const = 0;
    double getBalance() const { return balance; }
};

class Savings : public Account {
public:
    Savings(double b) : Account(b) {}
    double monthlyInterest() const override { return balance * 0.02 / 12; }
    string type() const override { return "Savings"; }
};

class Checking : public Account {
public:
    Checking(double b) : Account(b) {}
    double monthlyInterest() const override { return -5.0; }   // flat fee
    string type() const override { return "Checking"; }
};

void demoAccounts() {
    Savings  s(1200.0);
    Checking c(1200.0);
    Account* accts[] = { &s, &c };
    for (const Account* a : accts)
        cout << a->type() << ": " << a->monthlyInterest() << "\n";
    // Savings: 2
    // Checking: -5
}
```

**On \$1200, savings earn $1200 \times 0.02 / 12 = \$2$ a month**, and checking loses \$5 — so the
same balance moves in opposite directions depending only on the object's real type, which is the
whole demonstration.

**`monthlyInterest` is pure virtual because there is no sensible default.** A base returning 0
would silently be wrong for both subclasses. Making it pure means a new account type *cannot* be
added without answering the question.

**The negative return is deliberate and slightly uncomfortable**, which is a design signal:
"interest" that is really a fee suggests the function should be named `monthlyAdjustment`, or split
into `interest()` and `fees()`. Naming that has to be explained is usually naming that is wrong.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Spot the slice.** Explain what this prints and why, then fix it with a one-character change.

```cpp
struct Base  { virtual string who() const { return "Base"; } virtual ~Base() = default; };
struct Deriv : Base { string who() const override { return "Deriv"; } };

void show(Base b) { cout << b.who() << "\n"; }

int main() { Deriv d; show(d); }
```

::::solution[Solution]
It prints **`Up`**.

`show` takes its parameter **by value**, so passing `d` copies only the `Up` sub-object into `u`.
The copy is a real `Up` — its vptr points at `Up`'s vtable — so `u.who()` calls `Up::who`. The
`Down` part was discarded at the call, and no warning is issued.

**The one-character fix** is an ampersand:

```cpp
void showFixed(const Up& u) { cout << u.who() << "\n"; }
```

Now nothing is copied, `u` refers to the original `Down`, and the call dispatches to `Down::who`
— printing `Down`.

**Note that `virtual` was present and correct throughout.** Slicing is not a failure of `virtual`;
it is the object losing its identity before the call is made. That is what makes it hard to spot:
every keyword in the class definitions is right, and the bug is in the parameter list.
::::
:::

:::problem[P3 challenge]{difficulty="challenge"}
**Does this leak?** Say what happens, and give the fix.

```cpp
class Resource {
public:
    ~Resource() { cout << "Resource freed\n"; }   // not virtual
};
class Big : public Resource {
    int* data;
public:
    Big() : data(new int[1000]) {}
    ~Big() { delete[] data; cout << "Big freed\n"; }
};

int main() {
    Resource* p = new Big();
    delete p;
}
```

::::solution[Solution]
It prints only `Resource freed`, and leaks 4000 bytes.

`~Resource` is not virtual, so `delete p` — where `p` is declared `Resource*` — is resolved
statically and calls `~Resource` alone. `~Big` never runs, so `delete[] data` never happens. The
C++ standard calls deleting a derived object through a base pointer with a non-virtual destructor
**undefined behaviour**; the observed behaviour on every mainstream compiler is this silent leak.

**The fix is one word:**

```cpp
class Resource {
public:
    virtual ~Resource() { cout << "Resource freed\n"; }
};
```

Now `delete p` dispatches through the vtable to `~Big`, which frees the array and then — as §14.4
established — the base destructor runs automatically afterwards. The output becomes `Big freed`
then `Resource freed`.

**Why this is so easy to miss.** Nothing crashes, no compiler warning fires by default (`-Wall`
does not catch it; `-Wnon-virtual-dtor` or `-Weffc++` does), and the program produces correct
output. The only symptom is memory that never comes back, which shows up as a slow leak in a
long-running program and not at all in a test.

**The habit that prevents it:** the moment you write `virtual` anywhere in a class, write
`virtual ~ClassName() = default;` as well.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
Inheritance and polymorphism appear in design problems rather than algorithm problems, so these
ask you to build a hierarchy to a specified interface.

| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 1603 | [Design Parking System](https://leetcode.com/problems/design-parking-system/) | Easy | One class, several vehicle categories — composition versus inheritance |
| 355 | [Design Twitter](https://leetcode.com/problems/design-twitter/) | Medium | Interface design and delegation between objects |
| 622 | [Design Circular Queue](https://leetcode.com/problems/design-circular-queue/) | Medium | Implementing an interface exactly — compare §18.6 |
| 146 | [LRU Cache](https://leetcode.com/problems/lru-cache/) | Medium | Composition of two structures behind one interface |
:::
