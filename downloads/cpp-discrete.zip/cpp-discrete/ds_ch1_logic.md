---
title: "DS–1: Logic"
source: "ds_ch1_logic.html"
---

CSE 2813

# DS–1: Logic

§1.1 – §1.13

:::callout-connect
Why logic?

Logic is the mathematical language of

correct reasoning

. Every formal proof, every algorithm correctness argument, every specification of what a program should do — these are all expressed in logic. Digital circuits implement logic gates directly. Compilers use logical reasoning to optimize code. This chapter is the foundation for everything in discrete structures.
:::

## §1.1 — Propositions & Logical Operations

A **proposition** is a statement that is either TRUE or FALSE — never both, never neither.

✓ **Propositions:**

- "5 is prime" → TRUE
- "Every even number > 2 is not prime" → TRUE
- "The sky is green" → FALSE
- "17 is even" → FALSE

✗ **Not propositions:**

- "Is 5 prime?" (question)
- "x + 1 = 7" (truth depends on x)
- "Read the textbook!" (command)
- "This statement is false" (paradox)

### Logical Connectives

| Connective | Symbol | Name | English |
| --- | --- | --- | --- |
| Negation | $\neg p$ | NOT | "not p", "it is not the case that p" |
| Conjunction | $p \land q$ | AND | "p and q", "both p and q" |
| Disjunction | $p \lor q$ | OR (inclusive) | "p or q" (or both) |
| Exclusive Or | $p \oplus q$ | XOR | "p or q, but not both" |

### Truth Tables for Basic Connectives

Negation ($\neg p$)

| $p$ | $\neg p$ |
| --- | --- |
| T | F |
| F | T |

AND ($p \land q$)

| $p$ | $q$ | $p \land q$ |
| --- | --- | --- |
| T | T | T |
| T | F | F |
| F | T | F |
| F | F | F |

OR ($p \lor q$)

| $p$ | $q$ | $p \lor q$ |
| --- | --- | --- |
| T | T | T |
| T | F | T |
| F | T | T |
| F | F | F |

:::callout-key
Precedence (high to low):

$\neg$ > $\land$ > $\lor$ > $\to$ > $\leftrightarrow$

So $p \lor q \land r$ means $p \lor (q \land r)$ — AND binds tighter than OR.
:::

:::callout-connect
Connection to programming:

C++ logical operators directly implement these connectives:

!

= negation,

&&

= conjunction,

||

= disjunction,

^

(for bool) = XOR.
Short-circuit evaluation:

p && q

doesn't evaluate

q

if

p

is false (same truth value, but matters for side effects).
:::

## §1.2 — Evaluating Compound Propositions

Complex propositions are evaluated by constructing a truth table with one column per subexpression.

### Example: Evaluate $(p \land q) \lor \neg r$

| $p$ | $q$ | $r$ | $p \land q$ | $\neg r$ | $(p \land q) \lor \neg r$ |
| --- | --- | --- | --- | --- | --- |
| T | T | T | T | F | T |
| T | T | F | T | T | T |
| T | F | T | F | F | F |
| T | F | F | F | T | T |
| F | T | T | F | F | F |
| F | T | F | F | T | T |
| F | F | T | F | F | F |
| F | F | F | F | T | T |

For $n$ variables, a truth table has $2^n$ rows. Three variables → 8 rows; four → 16 rows.

### Special Propositions

| Name | Definition | Example |
| --- | --- | --- |
| **Tautology** | Always TRUE | $p \lor \neg p$ |
| **Contradiction** | Always FALSE | $p \land \neg p$ |
| **Contingency** | Sometimes T, sometimes F | $p \lor q$ |

:::problem{difficulty="easy"}
Practice 1.2 — Build a Truth Table

Construct the full truth table for $\neg p \lor (p \land q)$. Is it a tautology, contradiction, or contingency?

::::solution[Solution]
| $p$ | $q$ | $\neg p$ | $p \land q$ | $\neg p \lor (p \land q)$ |
| --- | --- | --- | --- | --- |
| T | T | F | T | T |
| T | F | F | F | F |
| F | T | T | F | T |
| F | F | T | F | T |

Result: FALSE when p is T and q is F. **Contingency** (not always T, not always F). This formula is equivalent to $\neg p \lor q$ — i.e., $p \to q$.
::::
:::

## §1.3 — Conditional Statements

The **conditional** (implication) $p \to q$ reads "if $p$ then $q$" or "$p$ implies $q$".

| $p$ | $q$ | $p \to q$ | Interpretation |
| --- | --- | --- | --- |
| T | T | T | Promise kept: condition true, result true |
| T | F | F | Promise broken: condition true, result false |
| F | T | T | Promise vacuously kept: condition false |
| F | F | T | Promise vacuously kept: condition false |

:::callout-intuition
The vacuous truth:

"If you score 100 on every test, I'll give you an A+" — if you never score 100, the promise is never broken, so it's technically true. A conditional is only FALSE when the hypothesis is TRUE and the conclusion is FALSE.
:::

### Related Conditionals

| Name | Form | Logically equivalent to |
| --- | --- | --- |
| Original | $p \to q$ | — |
| Converse | $q \to p$ | Inverse ($\neg p \to \neg q$) |
| Inverse | $\neg p \to \neg q$ | Converse |
| **Contrapositive** | $\neg q \to \neg p$ | **Original ($p \to q$)** |

:::callout-key
Key fact:

A conditional and its

contrapositive

are logically equivalent. This is crucial for proofs — proving "$\neg q \to \neg p$" is sometimes easier than proving "$p \to q$" directly.

The

biconditional

$p \leftrightarrow q$ ("p if and only if q") is TRUE exactly when $p$ and $q$ have the same truth value: $(p \to q) \land (q \to p)$.
:::

## §1.4 — Logical Equivalence

Two compound propositions $P$ and $Q$ are **logically equivalent**, written $P \equiv Q$, if they have identical truth values for every possible assignment of truth values to their variables. In other words, the column for $P$ and the column for $Q$ in a joint truth table are identical.

:::callout-key
Logical equivalence ≠ equality.

$P \equiv Q$ means these two

formulas

produce the same truth values — it does

not

mean $P = Q$ as strings. The symbol $\equiv$ (or sometimes $\Leftrightarrow$ in some textbooks) denotes this semantic sameness.
:::

### Verifying Equivalence with a Truth Table

**Claim:** $p \to q \equiv \neg p \lor q$

| $p$ | $q$ | $\neg p$ | $p \to q$ | $\neg p \lor q$ | Same? |
| --- | --- | --- | --- | --- | --- |
| T | T | F | T | T | ✓ |
| T | F | F | F | F | ✓ |
| F | T | T | T | T | ✓ |
| F | F | T | T | T | ✓ |

All four rows match → confirmed: $p \to q \equiv \neg p \lor q$. This is one of the most useful equivalences in all of logic — it lets us eliminate the implication symbol.

### Other Important Equivalences Involving Implication

| Equivalence | Name |
| --- | --- |
| $p \to q \equiv \neg p \lor q$ | Implication as Disjunction |
| $p \to q \equiv \neg q \to \neg p$ | Contrapositive |
| $\neg(p \to q) \equiv p \land \neg q$ | Negation of Implication |
| $p \leftrightarrow q \equiv (p \to q) \land (q \to p)$ | Biconditional Definition |
| $p \leftrightarrow q \equiv (p \land q) \lor (\neg p \land \neg q)$ | Biconditional as Cases |

:::callout-connect
Application — simplifying if statements:

In C++,

if (!p || q)

is logically equivalent to

if (p implies q)

. Recognizing $\neg p \lor q$ as an implication often makes code intent clearer during review.
:::

## §1.5 — Laws of Propositional Logic

These laws are the algebra of logic. They let you simplify and transform complex propositions into equivalent simpler forms — just as algebraic laws let you simplify expressions. Every law below can be verified by truth table.

| Law Name | AND Form | OR Form |
| --- | --- | --- |
| **Identity** | $p \land \mathbf{T} \equiv p$ | $p \lor \mathbf{F} \equiv p$ |
| **Domination** | $p \land \mathbf{F} \equiv \mathbf{F}$ | $p \lor \mathbf{T} \equiv \mathbf{T}$ |
| **Idempotent** | $p \land p \equiv p$ | $p \lor p \equiv p$ |
| **Double Negation** | $\neg(\neg p) \equiv p$ |
| **Commutative** | $p \land q \equiv q \land p$ | $p \lor q \equiv q \lor p$ |
| **Associative** | $(p \land q) \land r \equiv p \land (q \land r)$ | $(p \lor q) \lor r \equiv p \lor (q \lor r)$ |
| **Distributive** | $p \land (q \lor r) \equiv (p \land q) \lor (p \land r)$ | $p \lor (q \land r) \equiv (p \lor q) \land (p \lor r)$ |
| **De Morgan's** | $\neg(p \land q) \equiv \neg p \lor \neg q$ | $\neg(p \lor q) \equiv \neg p \land \neg q$ |
| **Absorption** | $p \land (p \lor q) \equiv p$ | $p \lor (p \land q) \equiv p$ |
| **Negation** | $p \land \neg p \equiv \mathbf{F}$ | $p \lor \neg p \equiv \mathbf{T}$ |

:::callout-intuition
De Morgan's Laws — the most important pair.

They tell you how to push a negation inside a compound statement by flipping AND↔OR:

• "NOT (A AND B)" = "(NOT A) OR (NOT B)"

• "NOT (A OR B)" = "(NOT A) AND (NOT B)"

In English: "It is not the case that it is both raining AND cold" = "It is not raining, OR it is not cold."
In code:

!(a && b)

≡

!a || !b

.
:::

### Using Laws to Simplify — Worked Example

Example — Simplify $\neg(p \lor q) \lor (\neg p \land q)$

:::answer[Step-by-step:]
| Step | Expression | Law Used |
| --- | --- | --- |
| Start | $\neg(p \lor q) \lor (\neg p \land q)$ | — |
| 1 | $(\neg p \land \neg q) \lor (\neg p \land q)$ | De Morgan's |
| 2 | $\neg p \land (\neg q \lor q)$ | Distributive (factor $\neg p$) |
| 3 | $\neg p \land \mathbf{T}$ | Negation: $\neg q \lor q \equiv \mathbf{T}$ |
| 4 | $\neg p$ | Identity: $\neg p \land \mathbf{T} \equiv \neg p$ |
:::

:::callout-pitfall
Common mistake — forgetting which form of De Morgan's applies:

Students often write $\neg(p \land q) \equiv \neg p \land \neg q$ (wrong!). The AND becomes OR when negation is distributed. A memory trick: "break the bar, change the sign" — break the negation over the connective, and flip AND↔OR.
:::

## §1.6 — Predicates & Quantifiers

Propositional logic is limited — it can't express "every student passed" or "some number is prime." **Predicate logic** (first-order logic) adds variables and quantifiers to handle these.

### Predicates

A **predicate** $P(x)$ is a statement whose truth value depends on the variable $x$. Once $x$ is fixed to a specific value, it becomes a proposition.

Predicate Examples

- $P(x)$: "$x$ is even" → $P(4)$ is T, $P(7)$ is F
- $Q(x,y)$: "$x > y$" → $Q(5,3)$ is T, $Q(2,8)$ is F
- $R(x)$: "$x^2 > x$" → $R(3)$ is T, $R(0.5)$ is F

Domain (Universe of Discourse)

The **domain** is the set from which variables are drawn. Truth values depend on domain:

- $P(x)$: "$x > 0$" is T for all $x \in \mathbb{Z}^+$
- $P(x)$: "$x > 0$" is F for $x = -1 \in \mathbb{Z}$

### Quantifiers

| Quantifier | Symbol | Reading | Meaning | True when... |
| --- | --- | --- | --- | --- |
| **Universal** | $\forall x\, P(x)$ | "for all x, P(x)" | P holds for every element | P(x) is T for every x in domain |
| **Existential** | $\exists x\, P(x)$ | "there exists x such that P(x)" | P holds for at least one element | P(x) is T for at least one x |

:::callout-key
Disproving universal; Proving existential:

- To show $\forall x\, P(x)$ is FALSE → find one **counterexample** where $P(x)$ is false.
- To show $\exists x\, P(x)$ is TRUE → find one **witness** (specific value) where $P(x)$ is true.
:::

### Bounded Quantifiers

Quantifiers are often restricted to a subset of the domain:

| Notation | Meaning | Expanded form |
| --- | --- | --- |
| $\forall x > 0\, P(x)$ | For all positive x, P(x) | $\forall x\,(x > 0 \to P(x))$ |
| $\exists x > 0\, P(x)$ | There exists a positive x with P(x) | $\exists x\,(x > 0 \land P(x))$ |

:::callout-pitfall
Note the connective difference!

Universal restrictions use $\to$; existential restrictions use $\land$. A very common error is writing $\forall x\,(x>0 \land P(x))$ — this says "every x is positive AND P(x)," which requires all elements to be positive. What you want is "every positive x satisfies P(x)."
:::

## §1.7 — Translating Quantified Statements

A critical skill in discrete math is moving fluently between English and logical notation. Context (the domain) is essential.

### English → Logic

| English Statement | Domain | Logical Form |
| --- | --- | --- |
| "All students passed." | $x$ = students | $\forall x\, \text{Passed}(x)$ |
| "Some student failed." | $x$ = students | $\exists x\, \neg\text{Passed}(x)$ |
| "Every positive integer has a square root." | $x \in \mathbb{Z}^+$ | $\forall x\, \exists y\, (y^2 = x)$ |
| "No one likes spam." | $x$ = people | $\forall x\, \neg\text{Likes}(x, \text{spam})$ or $\neg\exists x\, \text{Likes}(x, \text{spam})$ |
| "There's a student who knows everyone." | $x, y$ = students | $\exists x\, \forall y\, \text{Knows}(x, y)$ |

### Logic → English

Example — Translate $\forall x\,(x^2 \geq 0)$ over $\mathbb{R}$

:::answer
"For every real number $x$, $x^2 \geq 0$." (This is a true tautology over real numbers.)
:::

Example — Translate $\exists x\, \forall y\, (x \cdot y = y)$ over $\mathbb{R}$

:::answer
"There exists a real number $x$ such that for every real number $y$, $x \cdot y = y$." — The witness is $x = 1$ (the multiplicative identity). TRUE.
:::

:::callout-intuition
Order matters for mixed quantifiers!

$\forall x\, \exists y\, P(x,y)$ is very different from $\exists y\, \forall x\, P(x,y)$:

- $\forall x\, \exists y\, (y > x)$ over $\mathbb{Z}$: "For every integer, there's a larger one." ✓ TRUE
- $\exists y\, \forall x\, (y > x)$ over $\mathbb{Z}$: "There's a single integer larger than all integers." ✗ FALSE
:::

## §1.8 — De Morgan's Laws for Quantifiers

De Morgan's laws extend to quantifiers. They describe how to negate a quantified statement:

| Original | Negation | English |
| --- | --- | --- |
| $\neg\forall x\, P(x)$ | $\equiv \exists x\, \neg P(x)$ | "Not every x has P" = "Some x lacks P" |
| $\neg\exists x\, P(x)$ | $\equiv \forall x\, \neg P(x)$ | "No x has P" = "Every x lacks P" |

:::callout-intuition
The pattern:

When you push $\neg$ through a quantifier, flip $\forall \leftrightarrow \exists$ and negate the predicate. Analogous to De Morgan's for AND/OR: negate, flip, negate.
:::

### Worked Examples

Example 1 — Negate "Every prime number is odd."

:::answer[Original:]
$\forall x\, (\text{Prime}(x) \to \text{Odd}(x))$

$\exists x\, \neg(\text{Prime}(x) \to \text{Odd}(x))$

$\exists x\, (\text{Prime}(x) \land \neg\text{Odd}(x))$

"There exists a prime number that is not odd." (The counterexample is 2 — even and prime.)
:::

Example 2 — Negate "There is a student who got a perfect score."

:::answer[Original:]
$\exists x\, \text{Perfect}(x)$

$\forall x\, \neg\text{Perfect}(x)$

"No student got a perfect score."
:::

## §1.9 — Nested Quantifiers

Real-world statements often require multiple quantifiers. Nested quantifiers appear whenever variables are introduced one at a time, each potentially depending on the previous.

### Reading Nested Quantifiers

| Formula | English |
| --- | --- |
| $\forall x\, \forall y\, P(x,y)$ | For all x and all y, P(x,y). (Order of two $\forall$s doesn't matter.) |
| $\exists x\, \exists y\, P(x,y)$ | There exist x and y such that P(x,y). (Order of two $\exists$s doesn't matter.) |
| $\forall x\, \exists y\, P(x,y)$ | For every x, there exists a y (which may depend on x) such that P(x,y). |
| $\exists x\, \forall y\, P(x,y)$ | There is a single x such that P(x,y) holds for every y. |

### Example — Over integers, $P(x,y)$: $x + y = 0$

| Formula | Truth Value | Explanation |
| --- | --- | --- |
| $\forall x\, \forall y\, (x+y=0)$ | FALSE | 1+2 ≠ 0 |
| $\forall x\, \exists y\, (x+y=0)$ | TRUE | For any x, take y = −x |
| $\exists x\, \forall y\, (x+y=0)$ | FALSE | No single x works for all y |
| $\exists x\, \exists y\, (x+y=0)$ | TRUE | Take x=5, y=−5 |

### Negating Nested Quantifiers

Push $\neg$ inward one quantifier at a time, flipping each quantifier:

Negate $\forall x\, \exists y\, (x+y=0)$ over $\mathbb{Z}$

:::answer
$\neg\forall x\, \exists y\, (x+y=0)$

$\equiv \exists x\, \neg\exists y\, (x+y=0)$

$\equiv \exists x\, \forall y\, (x+y \neq 0)$

English: "There exists an integer x such that for every integer y, x+y ≠ 0." (This is FALSE, confirming the original is TRUE.)
:::

## §1.10 — Arguments & Logical Validity

An **argument** is a sequence of propositions — called **premises** — followed by a final proposition called the **conclusion**. An argument is **valid** if, whenever all premises are true, the conclusion must also be true.

:::definition[Definition]
Valid Argument

An argument with premises $p_1, p_2, \ldots, p_n$ and conclusion $c$ is **valid** if and only if $(p_1 \land p_2 \land \cdots \land p_n) \to c$ is a tautology.
:::

:::callout-pitfall
Valid ≠ True.

A valid argument with a false premise can still have a false conclusion in reality. "All fish fly. A salmon is a fish. Therefore, a salmon flies." — This is a VALID argument (the logical structure is correct), but the conclusion is false because the first premise is false. Validity is about

structure

, not

truth

.
:::

### Testing Validity with a Truth Table

Is this argument valid? Premises: $p \to q$, $p$. Conclusion: $q$.

:::answer
| $p$ | $q$ | $p \to q$ | Both premises T? | $q$ (conclusion) |
| --- | --- | --- | --- | --- |
| T | T | T | YES | T ✓ |
| T | F | F | NO | — (irrelevant) |
| F | T | T | NO | — |
| F | F | T | NO | — |

In the only row where both premises are T (row 1), the conclusion is also T.

Valid.

This is the rule of Modus Ponens.
:::

## §1.11 — Rules of Inference

Rather than building full truth tables every time, we use named **rules of inference** — pre-verified valid argument forms that can be applied directly in proofs.

| Rule Name | Premises | Conclusion | Mnemonic |
| --- | --- | --- | --- |
| **Modus Ponens** *(affirming the antecedent)* | $p \to q$ $p$ | $\therefore q$ | "If it rains, the ground is wet. It's raining. So the ground is wet." |
| **Modus Tollens** *(denying the consequent)* | $p \to q$ $\neg q$ | $\therefore \neg p$ | "If it rains, the ground is wet. The ground is NOT wet. So it did NOT rain." |
| **Hypothetical Syllogism** | $p \to q$ $q \to r$ | $\therefore p \to r$ | Chain of implications: if A → B → C, then A → C. |
| **Disjunctive Syllogism** | $p \lor q$ $\neg p$ | $\therefore q$ | "Either it's A or B. It's not A. So it must be B." |
| **Addition** | $p$ | $\therefore p \lor q$ | From a truth, you can always add an OR clause. |
| **Simplification** | $p \land q$ | $\therefore p$ | If both are true, each individually is true. |
| **Conjunction** | $p$ $q$ | $\therefore p \land q$ | Two truths can be combined into one AND statement. |
| **Resolution** | $p \lor q$ $\neg p \lor r$ | $\therefore q \lor r$ | Foundation of automated theorem provers (SAT solvers). |

### Applying Rules in a Proof Chain

Example — Chain of Inferences

**Given:** (1) $p \to q$, (2) $q \to r$, (3) $\neg r$. **Prove:** $\neg p$.

:::answer
| Step | Statement | Justification |
| --- | --- | --- |
| 1 | $p \to q$ | Premise |
| 2 | $q \to r$ | Premise |
| 3 | $\neg r$ | Premise |
| 4 | $p \to r$ | Hypothetical Syllogism (steps 1, 2) |
| 5 | $\neg p$ | Modus Tollens (steps 4, 3) ∎ |
:::

### Rules of Inference for Quantifiers

| Rule | Form | Meaning |
| --- | --- | --- |
| Universal Instantiation | $\forall x\,P(x)$ → $P(c)$ for any $c$ | A universal fact applies to any specific individual. |
| Universal Generalization | $P(c)$ for arbitrary $c$ → $\forall x\,P(x)$ | If proved for an arbitrary element, holds for all. |
| Existential Instantiation | $\exists x\,P(x)$ → $P(c)$ for some named $c$ | Give the mystery witness a name to work with. |
| Existential Generalization | $P(c)$ for specific $c$ → $\exists x\,P(x)$ | A specific example proves existence. |

## §1.12 — Common Logical Fallacies

Fallacies are **invalid argument forms** that *look* like valid rules but aren't. They're important to recognize in proofs, programming, and everyday reasoning.

| Fallacy | Form | Why it fails | Example |
| --- | --- | --- | --- |
| **Affirming the Consequent** | $p \to q$, $q$ → $\therefore p$? | $p \to q$ doesn't mean $q \to p$. The converse is not equivalent to the original. | "If it rains, the ground is wet. The ground is wet. Therefore it rained." — Could also be a sprinkler. |
| **Denying the Antecedent** | $p \to q$, $\neg p$ → $\therefore \neg q$? | $p \to q$ says nothing about what happens when $p$ is false. The inverse is not equivalent. | "If I study, I pass. I didn't study. Therefore I don't pass." — Maybe the test was easy. |
| **False Dilemma** | $p \lor q$, $p$ → $\therefore \neg q$? | Inclusive OR allows both to be true. Eliminating one doesn't rule out the other. | "Either you love math or you're lazy. You love math. Therefore you're not lazy." — Could be both. |

:::callout-key
Affirming the consequent

is the formal name for the "correlation implies causation" error. Modus Ponens goes forward ($p \to q$, know $p$, conclude $q$). Affirming the consequent tries to go backward ($p \to q$, know $q$, conclude $p$) — which is invalid because $q$ could be caused by many other things.
:::

:::callout-connect
CS application:

Affirming the consequent is a common debugging trap: "If my code has a memory leak, it runs slow. My code runs slow, so it must have a memory leak." — But slowness has many causes. Always check your reasoning direction matches a valid inference rule.
:::

## §1.13 — Normal Forms (DNF & CNF)

Any proposition can be rewritten in a **standard form** using only AND, OR, and NOT applied directly to variables. These normal forms are foundational for digital circuit design and automated reasoning.

### Key Terminology

| Term | Definition | Example |
| --- | --- | --- |
| **Literal** | A variable or its negation | $p$, $\neg q$, $r$ |
| **Minterm** | AND of all variables (each as literal) | $p \land \neg q \land r$ |
| **Maxterm** | OR of all variables (each as literal) | $p \lor \neg q \lor r$ |
| **DNF** | Disjunctive Normal Form — OR of minterms (AND-of-literals) | $(p \land q) \lor (\neg p \land r)$ |
| **CNF** | Conjunctive Normal Form — AND of maxterms (OR-of-literals) | $(p \lor \neg q) \land (\neg p \lor r)$ |

:::callout-intuition
Memory aid:

- **DNF** = "Disjunctions of miNterms" = *sums of products* (like $p\bar{q} + \bar{p}r$ in Boolean notation)
- **CNF** = "Conjunctions of Maxterms" = *products of sums* (like $(p+\bar{q})(\bar{p}+r)$ in Boolean notation)

DNF is natural for truth table rows where output is 1; CNF is natural for rows where output is 0.
:::

### Converting to DNF via Truth Table

Example — Find DNF for $p \to q$

:::answer
| $p$ | $q$ | $p \to q$ | Minterm (if output = T) |
| --- | --- | --- | --- |
| T | T | T | $p \land q$ |
| T | F | F | — |
| F | T | T | $\neg p \land q$ |
| F | F | T | $\neg p \land \neg q$ |

DNF:

$(p \land q) \lor (\neg p \land q) \lor (\neg p \land \neg q)$

This can be simplified using the laws: factor $q$ from first two terms → $(p \lor \neg p) \land q = q$, giving $q \lor (\neg p \land \neg q) \equiv q \lor \neg p \equiv \neg p \lor q$ — which we already knew was equivalent to $p \to q$. ✓
:::

:::callout-connect
Why normal forms matter in CS:

- **Logic circuits:** DNF maps to sum-of-products gates (AND gates feeding into OR); CNF maps to product-of-sums (OR gates feeding into AND).
- **SAT solvers:** The Boolean Satisfiability Problem (SAT) typically works on CNF. Every modern compiler, hardware verifier, and AI planner relies on SAT.
- **Database queries:** SQL WHERE clauses in CNF ($A$ AND $B$ AND ...) match how query optimizers represent conditions.
:::

:::summary
## Chapter Summary — DS–1: Logic

- **Propositions** are statements with definite T/F truth values. Logical connectives ($\neg, \land, \lor, \to, \leftrightarrow$) combine them into compound propositions.
- **Truth tables** enumerate all $2^n$ assignments for $n$ variables. A formula always T is a tautology; always F is a contradiction.
- **Conditionals** ($p \to q$) are false *only* when the hypothesis is T and conclusion is F. The contrapositive ($\neg q \to \neg p$) is logically equivalent; the converse and inverse are not.
- **Logical equivalence** ($P \equiv Q$) means identical truth tables. Key equivalence: $p \to q \equiv \neg p \lor q$.
- **Laws of propositional logic** (De Morgan's, distributive, absorption, etc.) allow algebraic simplification without truth tables.
- **Predicates** are propositions with free variables; **quantifiers** $\forall$ and $\exists$ bind them over a domain. Universal restrictions use $\to$; existential restrictions use $\land$.
- **Negating quantifiers:** $\neg\forall x\,P(x) \equiv \exists x\,\neg P(x)$ and $\neg\exists x\,P(x) \equiv \forall x\,\neg P(x)$. Push the negation inward, flip the quantifier.
- **Nested quantifiers:** Order matters when $\forall$ and $\exists$ are mixed. $\forall x\,\exists y$ differs fundamentally from $\exists y\,\forall x$.
- **Valid arguments** guarantee a true conclusion given true premises. Key rules: Modus Ponens, Modus Tollens, Hypothetical Syllogism, Disjunctive Syllogism.
- **Fallacies** (affirming the consequent, denying the antecedent) look like valid rules but aren't — they confuse a conditional with its converse or inverse.
- **Normal forms:** DNF = OR of AND-clauses; CNF = AND of OR-clauses. Used in circuit design, SAT solvers, and automated reasoning.
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Truth Table & Classification

Construct the truth table for $(p \leftrightarrow q) \land \neg(p \land q)$. Identify whether it is a tautology, contradiction, or contingency. What simpler formula is it equivalent to?

::::solution[Solution]
| $p$ | $q$ | $p \leftrightarrow q$ | $p \land q$ | $\neg(p \land q)$ | Result |
| --- | --- | --- | --- | --- | --- |
| T | T | T | T | F | F |
| T | F | F | F | T | F |
| F | T | F | F | T | F |
| F | F | T | F | T | T |

**Contingency.** Only T when both $p$ and $q$ are F. This is equivalent to $\neg p \land \neg q$ — both false. It's the NOR function, also writable as $\neg(p \lor q)$ by De Morgan's.
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Algebraic Simplification with Laws

Using the laws of propositional logic (not a truth table), simplify $\neg(\neg p \land q) \lor p$. Show each step and the law applied.

::::solution[Solution]
| Step | Expression | Law |
| --- | --- | --- |
| Start | $\neg(\neg p \land q) \lor p$ | — |
| 1 | $(\neg\neg p \lor \neg q) \lor p$ | De Morgan's |
| 2 | $(p \lor \neg q) \lor p$ | Double Negation |
| 3 | $p \lor (\neg q \lor p)$ | Associative + Commutative |
| 4 | $p \lor (p \lor \neg q)$ | Commutative |
| 5 | $(p \lor p) \lor \neg q$ | Associative |
| 6 | $p \lor \neg q$ | Idempotent |

Result: $p \lor \neg q$. (Equivalently, $\neg q \lor p \equiv q \to p$.)
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Quantifier Translation & Negation

Let the domain be all integers. Let $E(x)$: "$x$ is even", $P(x)$: "$x$ is prime". Translate each of the following into symbolic logic, then write its negation both symbolically and in plain English.

1. "Every even number greater than 2 is not prime."
2. "There exists a prime that is even."

::::solution[Solution]
**(a)**

Symbolic: $\forall x\,(E(x) \land x > 2 \to \neg P(x))$ or equivalently $\forall x\,(x > 2 \to (E(x) \to \neg P(x)))$

Negation: $\exists x\,(E(x) \land x > 2 \land P(x))$

English: "There exists an even number greater than 2 that is prime." (This is actually false — every even number > 2 is divisible by 2, hence not prime.)

**(b)**

Symbolic: $\exists x\,(P(x) \land E(x))$

Negation: $\forall x\,(P(x) \to \neg E(x))$ — "Every prime is odd."

English: "No prime number is even." (The original is TRUE — witness: x = 2.)
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Valid Inference or Fallacy?

For each argument, state whether it is valid. If valid, name the rule of inference. If invalid, name the fallacy.

1. Premises: "If a program compiles, it runs." "This program compiles." Conclusion: "This program runs."
2. Premises: "If a number is divisible by 4, it is divisible by 2." "17 is not divisible by 4." Conclusion: "17 is not divisible by 2."
3. Premises: "If it snows, school is cancelled." "School is cancelled." Conclusion: "It snowed."
4. Premises: "If $n > 100$, then $n^2 > 1000$." "If $n^2 > 1000$, then $\log_2 n > 5$." Conclusion: "If $n > 100$, then $\log_2 n > 5$."

::::solution[Solution]
**(a) VALID — Modus Ponens.** $p \to q$, $p$ → $\therefore q$.

**(b) INVALID — Denying the Antecedent.** The premise $p \to q$ with $\neg p$ does NOT allow us to conclude $\neg q$. 17 is odd, so it's indeed not divisible by 2 — but that's a coincidence here, not a valid logical conclusion from these premises alone.

**(c) INVALID — Affirming the Consequent.** $p \to q$, $q$ does not give $p$. School could be cancelled for many other reasons (power outage, holiday, etc.).

**(d) VALID — Hypothetical Syllogism.** $p \to q$, $q \to r$ → $\therefore p \to r$.
::::
:::

:::problem[P5]{difficulty="challenge"}
P5 — Proof Chain with Rules of Inference

From the following premises, prove that $w$ is true. Show each step with its justification.

1. $p \lor q$
2. $\neg p$
3. $q \to r$
4. $r \to (s \land t)$
5. $s \to w$

::::solution[Solution]
| Step | Statement | Justification |
| --- | --- | --- |
| 1 | $p \lor q$ | Premise 1 |
| 2 | $\neg p$ | Premise 2 |
| 3 | $q$ | Disjunctive Syllogism (1, 2) |
| 4 | $q \to r$ | Premise 3 |
| 5 | $r$ | Modus Ponens (3, 4) |
| 6 | $r \to (s \land t)$ | Premise 4 |
| 7 | $s \land t$ | Modus Ponens (5, 6) |
| 8 | $s$ | Simplification (7) |
| 9 | $s \to w$ | Premise 5 |
| 10 | $w$ | Modus Ponens (8, 9) ∎ |
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — CNF Conversion

Convert $p \to (q \land r)$ to Conjunctive Normal Form (CNF) using logical equivalences (no truth table). Show each step.

::::solution[Solution]
| Step | Expression | Law |
| --- | --- | --- |
| Start | $p \to (q \land r)$ | — |
| 1 | $\neg p \lor (q \land r)$ | Implication as Disjunction |
| 2 | $(\neg p \lor q) \land (\neg p \lor r)$ | Distributive: $A \lor (B \land C) \equiv (A \lor B) \land (A \lor C)$ |

**CNF:** $(\neg p \lor q) \land (\neg p \lor r)$. This is a conjunction of two clauses — exactly CNF form. Each clause is an OR of literals.

Interpretation: "$p \to q$" AND "$p \to r$" — if p then both q and r holds iff each implication holds separately. ✓
::::
:::

## LeetCode Connections

Logic and bitwise operations are deeply connected — each bit-manipulation problem is really propositional logic applied to individual bits. These problems let you practice logical reasoning in a concrete, testable setting.

| # | Problem | Difficulty | Connection to This Chapter |
| --- | --- | --- | --- |
| [#136](https://leetcode.com/problems/single-number/) | Single Number | Easy | XOR ($\oplus$): $x \oplus x = 0$, $x \oplus 0 = x$. Applies the XOR connective from §1.1 at the bit level — each number cancels its duplicate, leaving the single. |
| [#191](https://leetcode.com/problems/number-of-1-bits/) | Number of 1 Bits | Easy | Counting true literals in a conjunction — each bit is a proposition. The bit trick $n \mathbin{\&} (n-1)$ clears the lowest set bit, illustrating how AND interacts with two's-complement representation. |
| [#338](https://leetcode.com/problems/counting-bits/) | Counting Bits | Easy | Extends #191 to all integers 0…n with a DP recurrence. Reveals the structure of binary representation and how logical predicates (is this bit set?) compose across a sequence. |
| [#67](https://leetcode.com/problems/add-binary/) | Add Binary | Easy | Binary addition uses XOR for the sum bit and AND for the carry — a direct circuit-level application of §1.1 connectives and the normal-form ideas from §1.13. |
| [#371](https://leetcode.com/problems/sum-of-two-integers/) | Sum of Two Integers | Medium | Implements integer addition using only bitwise AND, OR, XOR, and shifts — no arithmetic operators. A pure logical-circuit problem: connect §1.1 connectives to full-adder logic gates, illustrating the computational power of the laws from §1.5. |
