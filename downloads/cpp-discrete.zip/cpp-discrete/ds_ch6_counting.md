---
title: "DS–6: Counting"
source: "ds_ch6_counting.html"
---

CSE 2813

# DS–6: Counting

§6.1 – §6.8

:::callout-connect
Why counting?

Counting is the foundation of algorithm analysis, probability, and cryptography. How many possible inputs does a brute-force algorithm check? How many keys does a 128-bit cipher have? How many ways can you arrange tasks in a schedule? Every question about "how many" — from password strength to hash collision probability to NP-completeness — is a counting problem.
:::

## §6.1 — Basic Counting Rules

:::theorem[Rule]
Product Rule (Multiplication Principle)

If a procedure has $k$ sequential stages, with $n_1$ ways to complete stage 1, $n_2$ ways to complete stage 2, …, and $n_k$ ways to complete stage $k$, and these choices are independent, then the total number of ways is $n_1 \cdot n_2 \cdots n_k$.
:::

:::theorem[Rule]
Sum Rule (Addition Principle)

If a task can be done in way A ($n_1$ ways) OR in way B ($n_2$ ways), and A and B are mutually exclusive, then the total number of ways is $n_1 + n_2$.
:::

Examples

**Product rule:** A password requires 1 uppercase letter, 1 digit, 1 special character (from a set of 10). How many 3-character passwords?

$26 \times 10 \times 10 = 2600$

**Sum rule:** You must choose a CS elective: 5 are offered in the morning OR 7 in the evening (no overlap).

$5 + 7 = 12$ choices.

**Combined:** How many 8-character passwords with letters and digits (case-insensitive)?

$36^8 = 2{,}821{,}109{,}907{,}456 \approx 2.8 \times 10^{12}$

:::callout-pitfall
Sum vs. Product:

Use the product rule for sequential/independent choices ("first choose X, THEN choose Y"). Use the sum rule for mutually exclusive alternatives ("choose X OR choose Y"). Mixing them up is the most common counting error.
:::

## §6.2 — Permutations

:::definition[Definition]
Permutation

A **permutation** is an ordered arrangement of objects. The number of ways to arrange $r$ objects chosen from $n$ distinct objects (without replacement) is:

$P(n,r) = \dfrac{n!}{(n-r)!} = n(n-1)(n-2)\cdots(n-r+1)$
:::

All n objects

$P(n,n) = n!$

Arrange all $n$ elements: $n$ choices for first, $n-1$ for second, etc.

r of n objects

$P(n,r) = \dfrac{n!}{(n-r)!}$

Order matters; choose and arrange $r$ from $n$

With repetition allowed

$n^r$

Each of $r$ positions: $n$ choices independently

Example — Horse Race

8 horses in a race. How many ways can first, second, and third place be assigned?

:::answer
$P(8,3) = 8 \times 7 \times 6 = 336$
:::

### Permutations with Identical Objects

If you have $n$ objects where $n_1$ are identical of type 1, $n_2$ of type 2, …, $n_k$ of type $k$ (and $n_1+\cdots+n_k = n$), the number of distinct arrangements is:

$\dfrac{n!}{n_1!\, n_2!\, \cdots\, n_k!}$

Example — Distinct arrangements of "MISSISSIPPI"

:::answer
M=1, I=4, S=4, P=2. Total: $\dfrac{11!}{1!\,4!\,4!\,2!} = \dfrac{39916800}{1 \cdot 24 \cdot 24 \cdot 2} = \dfrac{39916800}{1152} = 34650$
:::

## §6.3 — Combinations

:::definition[Definition]
Combination (Binomial Coefficient)

A **combination** is an unordered selection of $r$ objects from $n$ distinct objects (without replacement):

$C(n,r) = \binom{n}{r} = \dfrac{n!}{r!(n-r)!} = \dfrac{P(n,r)}{r!}$
:::

:::callout-key
The key insight:

$\binom{n}{r} = P(n,r)/r!$ because every combination of $r$ objects corresponds to exactly $r!$ permutations (the different orderings of the same $r$ objects). Division by $r!$ "undoes" the ordering.
:::

Combinations

$\binom{n}{r} = \dfrac{n!}{r!(n-r)!}$

Order does NOT matter; no replacement

Symmetry

$\binom{n}{r} = \binom{n}{n-r}$

Choosing $r$ to include = choosing $n-r$ to exclude

With repetition

$\binom{n+r-1}{r}$

Choose $r$ items from $n$ types, repetition OK (stars and bars)

### Permutations vs. Combinations — Decision Guide

| Question involves... | Use | Formula |
| --- | --- | --- |
| Ordered arrangement, no repeats | Permutation | $P(n,r)$ |
| Ordered arrangement, with repeats | Product rule | $n^r$ |
| Unordered selection, no repeats | Combination | $\binom{n}{r}$ |
| Unordered selection, with repeats | Multiset (stars & bars) | $\binom{n+r-1}{r}$ |

5-Card Poker Hand

:::answer
How many distinct 5-card hands from a 52-card deck? Order doesn't matter (a hand is a set): $\binom{52}{5} = \dfrac{52!}{5!\,47!} = 2{,}598{,}960$
:::

## §6.4 — Binomial Theorem & Pascal's Triangle

:::theorem[Theorem]
Binomial Theorem

$(x + y)^n = \displaystyle\sum_{k=0}^{n}\binom{n}{k} x^{n-k} y^k$

The coefficient of $x^{n-k}y^k$ in the expansion of $(x+y)^n$ is exactly $\binom{n}{k}$ — this is why $\binom{n}{k}$ are called *binomial coefficients*.
:::

Expand $(x+y)^4$

:::answer
$\binom{4}{0}x^4 + \binom{4}{1}x^3y + \binom{4}{2}x^2y^2 + \binom{4}{3}xy^3 + \binom{4}{4}y^4 = x^4 + 4x^3y + 6x^2y^2 + 4xy^3 + y^4$
:::

### Important Special Cases

| Substitution | Result | Meaning |
| --- | --- | --- |
| $x=y=1$ | $\displaystyle\sum_{k=0}^{n}\binom{n}{k} = 2^n$ | Total number of subsets of an $n$-element set |
| $x=1, y=-1$ | $\displaystyle\sum_{k=0}^{n}(-1)^k\binom{n}{k} = 0$ | Alternating sum of row of Pascal's triangle = 0 |
| $x=y=1$ (even/odd) | $\sum_{\text{even }k}\binom{n}{k} = \sum_{\text{odd }k}\binom{n}{k} = 2^{n-1}$ | Half the subsets have even size, half odd |

### Pascal's Triangle

1

1 — 1

1 — 2 — 1

1 — 3 — 3 — 1

1 — 4 — 6 — 4 — 1

1 — 5 — 10 — 10 — 5 — 1

1 — 6 — 15 — 20 — 15 — 6 — 1

Row $n$ contains $\binom{n}{0}, \binom{n}{1}, \ldots, \binom{n}{n}$. Pascal's identity gives the recurrence:

:::theorem[Identity]
Pascal's Identity

$\binom{n}{k} = \binom{n-1}{k-1} + \binom{n-1}{k}$ for $1 \leq k \leq n-1$

*Proof:* Consider whether element $n$ is in the chosen subset: if yes, choose $k-1$ from remaining $n-1$; if no, choose all $k$ from $n-1$.
:::

## §6.5 — Inclusion-Exclusion for Counting

:::theorem[Theorem]
Inclusion-Exclusion (Two Sets)

$|A \cup B| = |A| + |B| - |A \cap B|$
:::

:::theorem[Theorem]
Inclusion-Exclusion (Three Sets)

$|A \cup B \cup C| = |A|+|B|+|C| - |A\cap B| - |A\cap C| - |B\cap C| + |A\cap B\cap C|$
:::

Example — Integers from 1 to 1000 divisible by 3 or 5

:::answer
$|D_3| = \lfloor 1000/3 \rfloor = 333$,   $|D_5| = \lfloor 1000/5 \rfloor = 200$,   $|D_{15}| = \lfloor 1000/15 \rfloor = 66$

$|D_3 \cup D_5| = 333 + 200 - 66 = 467$
:::

:::callout-connect
Derangements

— a classic application. A

derangement

is a permutation where no element appears in its original position (everyone gets the wrong hat). The number of derangements of $n$ objects uses inclusion-exclusion:

$D_n = n!\sum_{i=0}^{n}\dfrac{(-1)^i}{i!} \approx n!/e$

For large $n$, about $1/e \approx 36.8\%$ of all permutations are derangements.
:::

## §6.6 — Stars and Bars

The **stars and bars** technique counts the number of ways to distribute indistinguishable objects into distinguishable bins.

:::theorem[Theorem]
Stars and Bars

The number of ways to place $r$ indistinguishable balls into $n$ distinguishable bins (with bins possibly empty) is $\displaystyle\binom{n+r-1}{r}$.
:::

:::callout-intuition
Why?

Represent the $r$ balls as stars (★) and use $n-1$ bars (|) as dividers between bins. Any arrangement of $r$ stars and $n-1$ bars gives a valid distribution. Total symbols: $r + (n-1) = n+r-1$. Choose positions for the $r$ stars: $\binom{n+r-1}{r}$.
:::

Example — Distribute 7 identical cookies among 4 children (each gets ≥ 0)

:::answer
$\binom{4+7-1}{7} = \binom{10}{7} = 120$ ways.
:::

Variation — Each child gets at least 1 cookie

:::answer
Give each child 1 cookie first (4 used, 3 remaining). Now distribute 3 among 4 with no lower bound: $\binom{4+3-1}{3} = \binom{6}{3} = 20$ ways.
:::

## §6.7 — Counting in Computer Science

### Password and Key Space Analysis

| Password Type | Count | Approx. bits of security |
| --- | --- | --- |
| 6 digits (PIN) | $10^6 = 1{,}000{,}000$ | 20 bits |
| 8-char lowercase | $26^8 \approx 2 \times 10^{11}$ | 37 bits |
| 8-char mixed (62 chars) | $62^8 \approx 2 \times 10^{14}$ | 47 bits |
| 12-char mixed + symbols (94 chars) | $94^{12} \approx 4.7 \times 10^{23}$ | 79 bits |
| 128-bit AES key | $2^{128} \approx 3.4 \times 10^{38}$ | 128 bits |

### Counting Algorithm Complexity

| Problem | Input space size | Why brute force fails |
| --- | --- | --- |
| Sort $n$ items | $n!$ permutations to check | $20! \approx 2.4 \times 10^{18}$ |
| Traveling Salesman (n cities) | $(n-1)!/2$ routes | Grows faster than $2^n$ |
| Subset-sum (n items) | $2^n$ subsets | $2^{60} \approx 10^{18}$ |
| 8-queen problem | $\binom{64}{8} \approx 4.4 \times 10^9$ placements | Large but feasible with backtracking |

:::callout-key
Counting arguments prove lower bounds.

The comparison-sort lower bound ($\Omega(n\log n)$) comes from counting: there are $n!$ possible input orderings, and each comparison can only halve the remaining possibilities. A decision tree of height $h$ handles at most $2^h$ inputs, so $2^h \geq n! \Rightarrow h \geq \log_2(n!) \approx n\log n$.
:::

## §6.8 — Multinomials & Advanced Identities

### Multinomial Coefficients

Generalization of binomial to $k$ groups: the number of ways to partition $n$ objects into groups of sizes $n_1, n_2, \ldots, n_k$ (where $\sum n_i = n$):

$\binom{n}{n_1,n_2,\ldots,n_k} = \dfrac{n!}{n_1!\,n_2!\,\cdots\,n_k!}$

### Key Combinatorial Identities

| Identity | Formula | Combinatorial meaning |
| --- | --- | --- |
| Vandermonde's | $\binom{m+n}{r} = \displaystyle\sum_{k=0}^{r}\binom{m}{k}\binom{n}{r-k}$ | Choose $r$ from two disjoint groups of $m$ and $n$ |
| Hockey stick | $\displaystyle\sum_{i=r}^{n}\binom{i}{r} = \binom{n+1}{r+1}$ | Sum of a column of Pascal's triangle |
| Upper index | $\displaystyle\sum_{i=0}^{n}\binom{i+k}{k} = \binom{n+k+1}{k+1}$ | Stars and bars cumulative sum |
| Symmetry | $\binom{n}{k} = \binom{n}{n-k}$ | Complementary counting |

:::summary
## Chapter Summary — DS–6: Counting

- **Product rule:** Sequential independent choices multiply. **Sum rule:** Mutually exclusive alternatives add.
- **Permutations:** Ordered selections. $P(n,r) = n!/(n-r)!$. With repeats: $n^r$. Identical objects: divide by $n_i!$ for each type.
- **Combinations:** Unordered selections. $\binom{n}{r} = n!/(r!(n-r)!)$. With repetition: $\binom{n+r-1}{r}$ (stars and bars).
- **Binomial theorem:** $(x+y)^n = \sum_k \binom{n}{k}x^{n-k}y^k$. Setting $x=y=1$ gives $\sum\binom{n}{k} = 2^n$.
- **Pascal's identity:** $\binom{n}{k} = \binom{n-1}{k-1} + \binom{n-1}{k}$ — each entry = sum of two above.
- **Inclusion-exclusion:** $|A\cup B| = |A|+|B|-|A\cap B|$. Alternates + and − for more sets.
- **Stars and bars:** $r$ indistinguishable items into $n$ bins → $\binom{n+r-1}{r}$.
- **CS applications:** Password strength, algorithm lower bounds (comparison sort needs $\Omega(n\log n)$ because $n!$ inputs), NP-hardness (exponential search spaces).
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Product & Sum Rule

A restaurant menu has 4 appetizers, 6 main courses, and 3 desserts. (a) How many 3-course meals (one of each) are possible? (b) If a customer chooses only ONE item (any course), how many choices? (c) How many meals if they can optionally skip dessert?

::::solution[Solution]
**(a)** Product rule: $4 \times 6 \times 3 = 72$

**(b)** Sum rule (mutually exclusive courses): $4 + 6 + 3 = 13$

**(c)** Either take dessert ($4 \times 6 \times 3 = 72$) or skip it ($4 \times 6 = 24$). Sum: $72 + 24 = 96$. Alternatively: $4 \times 6 \times 4 = 96$ (treat "no dessert" as a 4th option).
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Permutations vs. Combinations

A club has 12 members. (a) How many ways can they elect a president, vice-president, and secretary (distinct roles)? (b) How many ways can they choose a 3-person committee (no roles)? (c) How many ways can all 12 members line up for a photo?

::::solution[Solution]
**(a)** Order matters (different roles): $P(12,3) = 12 \times 11 \times 10 = 1320$

**(b)** Order doesn't matter: $\binom{12}{3} = \dfrac{12!}{3!\,9!} = \dfrac{12\times11\times10}{6} = 220$

**(c)** All 12 in a line: $12! = 479{,}001{,}600$
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Binomial Theorem Application

(a) Find the coefficient of $x^3y^5$ in $(x+y)^8$. (b) Find the coefficient of $x^4$ in $(2x-3)^7$. (c) Using the binomial theorem, prove $\sum_{k=0}^{n} \binom{n}{k} = 2^n$.

::::solution[Solution]
**(a)** $\binom{8}{3} = 56$. (Choose 3 positions for $x$, remaining 5 get $y$.)

**(b)** $(2x-3)^7 = \sum_{k=0}^{7}\binom{7}{k}(2x)^k(-3)^{7-k}$. For $x^4$: $k=4$. Coefficient: $\binom{7}{4}(2)^4(-3)^3 = 35 \cdot 16 \cdot (-27) = -15{,}120$.

**(c)** Set $x = y = 1$ in $(x+y)^n = \sum_{k=0}^{n}\binom{n}{k}x^{n-k}y^k$: $(1+1)^n = 2^n = \sum_{k=0}^{n}\binom{n}{k} \cdot 1^{n-k} \cdot 1^k = \sum_{k=0}^{n}\binom{n}{k}$. ∎
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Inclusion-Exclusion

Among integers 1 to 500: (a) How many are divisible by 2 or 3? (b) How many are divisible by 2, 3, or 5? (c) How many are divisible by neither 2, 3, nor 5?

::::solution[Solution]
**(a)** $|D_2| = 250$, $|D_3| = 166$, $|D_6| = 83$. $|D_2 \cup D_3| = 250 + 166 - 83 = 333$.

**(b)** $|D_5|=100$, $|D_{10}|=50$, $|D_{15}|=33$, $|D_{30}|=16$.

$|D_2\cup D_3\cup D_5| = 250+166+100-83-50-33+16 = 366$.

**(c)** $500 - 366 = 134$.
::::
:::

:::problem[P5]{difficulty="standard"}
P5 — Stars and Bars

A convenience store sells 5 types of soda. (a) How many ways can you choose 8 cans (any combination of types)? (b) How many ways if you must pick at least 2 of type 1 and at least 1 of type 3?

::::solution[Solution]
**(a)** $r = 8$ indistinguishable cans, $n = 5$ types: $\binom{5+8-1}{8} = \binom{12}{8} = \binom{12}{4} = 495$

**(b)** Pre-select: 2 of type 1, 1 of type 3 (3 cans used). Remaining: $8 - 3 = 5$ cans from 5 types freely: $\binom{5+5-1}{5} = \binom{9}{5} = 126$.
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — Counting Paths in a Grid

Count the number of shortest paths from $(0,0)$ to $(m,n)$ on a grid, moving only right (R) or up (U). Then: how many such paths pass through the point $(a,b)$ where $0 \leq a \leq m$ and $0 \leq b \leq n$?

::::solution[Solution]
**Total paths:** Every path is a sequence of $m+n$ steps: exactly $m$ rights and $n$ ups. Choose which $m$ of the $m+n$ positions are R steps: $\binom{m+n}{m}$.

**Paths through $(a,b)$:** Split into two segments:

 $(0,0)$ to $(a,b)$: $\binom{a+b}{a}$ paths
 $(a,b)$ to $(m,n)$: $\binom{(m-a)+(n-b)}{m-a}$ paths

Total via $(a,b)$: $\binom{a+b}{a} \cdot \binom{m+n-a-b}{m-a}$.

**CS connection:** This is the basis for counting DP states in problems like edit distance and LCS. Each grid path corresponds to an alignment of two sequences. Counting paths = counting alignments = $\binom{m+n}{m}$.
::::
:::

## LeetCode Connections

| # | Problem | Difficulty | Connection |
| --- | --- | --- | --- |
| [#70](https://leetcode.com/problems/climbing-stairs/) | Climbing Stairs | Easy | Counting sequences of 1-steps and 2-steps. The number of ways is $F_{n+1}$ (Fibonacci) — a direct combinatorial counting argument. With $k$ step sizes allowed, generalizes to a multinomial counting problem. |
| [#46](https://leetcode.com/problems/permutations/) | Permutations | Medium | Generate all $n!$ permutations of a list. Understanding there are exactly $n!$ and their structure is $P(n,n)$ from §6.2 helps plan the backtracking correctly and verify completeness. |
| [#77](https://leetcode.com/problems/combinations/) | Combinations | Medium | Generate all $\binom{n}{k}$ size-$k$ subsets of $\{1,\ldots,n\}$ (§6.3). Pruning the backtracking tree when remaining elements can't fill $k$ slots uses the formula $n - i + 1 \geq k - \text{chosen}$. |
| [#118](https://leetcode.com/problems/pascals-triangle/) | Pascal's Triangle | Easy | Directly builds Pascal's triangle using the recurrence $\binom{n}{k} = \binom{n-1}{k-1} + \binom{n-1}{k}$ from §6.4. The DP is just the combinatorial recurrence tabulated bottom-up. |
| [#17](https://leetcode.com/problems/letter-combinations-of-a-phone-number/) | Letter Combinations of a Phone Number | Medium | Product rule (§6.1): each digit maps to 3–4 letters; choosing one per digit multiplies the counts. An $n$-digit number with 4 letters per digit → $4^n$ combinations, exponential in input length — exactly why brute-force fails for long inputs. |
