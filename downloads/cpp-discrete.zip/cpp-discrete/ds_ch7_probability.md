---
title: "DS–7: Discrete Probability"
source: "ds_ch7_probability.html"
---

CSE 2813

# DS–7: Discrete Probability

§7.1 – §7.8

## §7.1 Sample Spaces and Events

Probability gives us a rigorous framework for reasoning about **uncertain outcomes**. Every probability problem starts with an experiment whose outcome we cannot predict with certainty.

:::definition[Definition]
Sample Space & Events

The **sample space** $\Omega$ is the set of all possible outcomes of an experiment. An **event** $A \subseteq \Omega$ is any subset of outcomes. The **complement** $\bar{A} = \Omega \setminus A$ is the event that $A$ does NOT occur.
:::

Example 7.1 — Rolling Two Dice

A fair die is rolled twice. Describe the sample space and the event "sum equals 7".

:::answer[Solution]
$\Omega = \{(i,j) \mid 1 \le i,j \le 6\}$, so $|\Omega| = 36$.

Event $A = \{(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)\}$, so $|A| = 6$.

For uniform sample spaces: $P(A) = |A|/|\Omega| = 6/36 = 1/6$.
:::

### Set Operations on Events

| Notation | Meaning | Occurs when... |
| --- | --- | --- |
| $A \cup B$ | $A$ or $B$ (or both) | at least one of $A$, $B$ occurs |
| $A \cap B$ | $A$ and $B$ | both $A$ and $B$ occur |
| $\bar{A}$ | not $A$ | $A$ does not occur |
| $A \setminus B$ | $A$ but not $B$ | $A$ occurs and $B$ does not |

:::theorem[Theorem]
Inclusion–Exclusion (two events)

$$
P(A \cup B) = P(A) + P(B) - P(A \cap B)
$$

Generalization: $P(A \cup B \cup C) = P(A)+P(B)+P(C) - P(A\cap B) - P(A\cap C) - P(B\cap C) + P(A\cap B\cap C)$.
:::

## §7.2 Probability Axioms and Basic Rules

:::theorem[Kolmogorov Axioms]
Foundation of Probability

1. **Non-negativity:** $P(A) \ge 0$ for every event $A$.
2. **Normalization:** $P(\Omega) = 1$.
3. **Additivity:** If $A \cap B = \emptyset$, then $P(A \cup B) = P(A) + P(B)$.
:::

From these three axioms everything else follows:

- $P(\emptyset) = 0$
- $P(\bar{A}) = 1 - P(A)$
- If $A \subseteq B$ then $P(A) \le P(B)$
- $0 \le P(A) \le 1$

Example 7.2 — Complement Rule

A password is 6 characters, each chosen uniformly from 62 alphanumeric characters. What is the probability it contains at least one digit?

:::answer[Solution]
Let $A$ = "at least one digit". Use complement: $\bar{A}$ = "no digits" (all 52 letters).

$P(\bar{A}) = (52/62)^6 \approx 0.343$

$P(A) = 1 - P(\bar{A}) \approx 1 - 0.343 = 0.657$.

Takeaway: complement is often far easier than counting "at least one" directly.
:::

## §7.3 Conditional Probability and Independence

:::definition[Definition]
Conditional Probability

The probability of $A$ *given* $B$ (where $P(B)>0$):

$$
P(A \mid B) = \frac{P(A \cap B)}{P(B)}
$$

 Intuitively: restrict the sample space to $B$, then ask how much of it is $A$.
:::

:::theorem[Theorem]
Multiplication Rule

$$
P(A \cap B) = P(A \mid B)\cdot P(B) = P(B \mid A)\cdot P(A)
$$
:::

:::definition[Definition]
Independence

Events $A$ and $B$ are **independent** iff $P(A \cap B) = P(A)\cdot P(B)$, equivalently $P(A \mid B) = P(A)$. Knowing $B$ gives no information about $A$.
:::

Example 7.3 — Conditional Probability

A fair coin is flipped 3 times. Given that the first flip was Heads, what is the probability that all 3 were Heads?

:::answer[Solution]
$\Omega = \{HHH, HHT, HTH, HTT, THH, THT, TTH, TTT\}$ (8 outcomes).

$B$ = "first flip H" = $\{HHH,HHT,HTH,HTT\}$, $P(B)=1/2$.

$A \cap B$ = $\{HHH\}$, $P(A\cap B) = 1/8$.

$P(A \mid B) = (1/8)/(1/2) = 1/4$. (Equivalently, flips 2 and 3 are independent — each $1/2$, so $1/4$.)
:::

:::theorem[Theorem]
Law of Total Probability

If $B_1, B_2, \ldots, B_n$ partition $\Omega$ (mutually exclusive and exhaustive):

$$
P(A) = \sum_{i=1}^{n} P(A \mid B_i)\cdot P(B_i)
$$
:::

## §7.4 Bayes' Theorem

:::theorem[Theorem]
Bayes' Theorem

$$
P(B \mid A) = \frac{P(A \mid B)\cdot P(B)}{P(A)}
$$

 where $P(A) = P(A\mid B)P(B) + P(A\mid\bar{B})P(\bar{B})$ by total probability.
:::

**Terminology:** $P(B)$ is the *prior*, $P(B\mid A)$ is the *posterior*, $P(A\mid B)$ is the *likelihood*.

Example 7.4 — Medical Test (Classic)

A disease affects 1% of the population. A test is 99% sensitive (true positive rate) and 99% specific (true negative rate). You test positive — what is the probability you have the disease?

:::answer[Solution]
Let $D$ = "has disease" ($P(D)=0.01$), $T$ = "tests positive".

$P(T\mid D) = 0.99$ (sensitivity), $P(T\mid\bar{D}) = 0.01$ (false positive rate = $1-0.99$).

$P(T) = 0.99\cdot0.01 + 0.01\cdot0.99 = 0.0198$.

$P(D\mid T) = (0.99\times0.01)/0.0198 = 0.0099/0.0198 = \mathbf{50\%}$.

Counterintuitive: even with a 99% accurate test, only 50% chance of disease when the base rate is 1%. The low prevalence ($P(D)=0.01$) dominates.
:::

Example 7.5 — Spam Filter

40% of emails are spam. The word "free" appears in 80% of spam but only 10% of legitimate email. An email contains "free" — probability it's spam?

:::answer[Solution]
$P(S)=0.4$, $P(\text{free}\mid S)=0.8$, $P(\text{free}\mid\bar{S})=0.1$.

$P(\text{free}) = 0.8\times0.4 + 0.1\times0.6 = 0.32+0.06 = 0.38$.

$P(S\mid\text{free}) = (0.8\times0.4)/0.38 = 0.32/0.38 \approx \mathbf{84.2\%}$.
:::

## §7.5 Random Variables and Expected Value

:::definition[Definition]
Random Variable

A **random variable** $X:\Omega\to\mathbb{R}$ assigns a real number to each outcome. Its **expected value** (mean) is:

$$
E[X] = \sum_{x} x \cdot P(X = x)
$$
:::

:::theorem[Theorem]
Linearity of Expectation

$$
E[X + Y] = E[X] + E[Y] \quad \text{(always — even if $X,Y$ are dependent!)}
$$

$$
E[cX] = c\cdot E[X]
$$

 This is the single most powerful tool in discrete probability.
:::

Example 7.6 — Expected Value of a Die

What is the expected value when rolling a fair 6-sided die?

:::answer[Solution]
$E[X] = 1\cdot\frac{1}{6}+2\cdot\frac{1}{6}+\cdots+6\cdot\frac{1}{6} = \frac{1+2+3+4+5+6}{6} = \frac{21}{6} = \mathbf{3.5}$
:::

Example 7.7 — Derangements via Linearity

$n$ people each put their hat in a box. Hats are randomly returned. What is the expected number of people who get their own hat back?

:::answer[Solution]
Let $X_i = 1$ if person $i$ gets their hat. $P(X_i=1) = 1/n$ for each $i$.

$E\left[\sum X_i\right] = \sum E[X_i] = n \cdot \frac{1}{n} = \mathbf{1}$.

Regardless of $n$, the expected number of "fixed points" is exactly 1. Linearity makes this trivial — computing it directly from the derangement formula would be painful.
:::

## §7.6 Common Distributions

### Bernoulli Distribution

A single trial with success probability $p$. $P(X=1)=p$, $P(X=0)=1-p$. $E[X]=p$, $\text{Var}(X)=p(1-p)$.

### Binomial Distribution

:::definition[Definition]
$X \sim \text{Bin}(n, p)$

$n$ independent Bernoulli trials, each with success probability $p$. Number of successes $X$:

$$
P(X=k) = \binom{n}{k}p^k(1-p)^{n-k}, \quad k=0,1,\ldots,n
$$

 $E[X]=np$, $\text{Var}(X)=np(1-p)$.
:::

Example 7.8 — Binomial

A fair coin is flipped 10 times. What is the probability of exactly 6 heads?

:::answer[Solution]
$X \sim \text{Bin}(10, 0.5)$. $P(X=6) = \binom{10}{6}(0.5)^6(0.5)^4 = 210 \cdot (1/1024) \approx 0.205$.
:::

### Geometric Distribution

:::definition[Definition]
$X \sim \text{Geom}(p)$

Number of trials until the first success:

$$
P(X=k) = (1-p)^{k-1}p, \quad k=1,2,3,\ldots
$$

 $E[X] = 1/p$. Memoryless: $P(X>m+n \mid X>m) = P(X>n)$.
:::

Example 7.9 — Geometric: Linear Probing

A hash table is 50% full. How many slots do you expect to probe on average before finding an empty slot (linear probing)?

:::answer[Solution]
Each probe hits an occupied slot with probability $p=0.5$. Number of probes $\sim \text{Geom}(0.5)$, so $E = 1/0.5 = \mathbf{2}$ probes on average. This explains why hash tables degrade sharply above 70–80% load.
:::

## §7.7 The Birthday Problem and Hash Collisions

:::theorem[Theorem]
Birthday Bound

Place $k$ items uniformly at random into $n$ buckets. The probability of *no collision* is:

$$
P(\text{no collision}) = \frac{n}{n}\cdot\frac{n-1}{n}\cdot\frac{n-2}{n}\cdots\frac{n-k+1}{n} = \frac{n!/(n-k)!}{n^k}
$$

 For $k \approx \sqrt{2n\ln 2} \approx 1.177\sqrt{n}$, this probability drops to about $1/2$.
:::

Example 7.10 — Birthday Paradox

In a room of 23 people, what is the probability that two share a birthday (ignoring leap years)?

:::answer[Solution]
$n=365$, $k=23$. $P(\text{no collision}) = \frac{365!/(365-23)!}{365^{23}} \approx 0.493$.

So $P(\text{at least one shared birthday}) \approx 1 - 0.493 = \mathbf{50.7\%}$.

With $k=70$ people, probability exceeds $99.9\%$. The $\sqrt{n}$ threshold is why: $\sqrt{2\cdot365\cdot\ln2} \approx 22.5$.
:::

:::callout-connect[Connection → Hashing & Cryptography]
A hash function producing $n$-bit digests ($2^n$ possible values) will have a collision among $k \approx 2^{n/2}$ inputs with probability $\approx 1/2$. SHA-256 ($n=256$): collision after $\approx 2^{128}$ inputs — computationally infeasible. MD5 ($n=128$): collision after $\approx 2^{64}$ — feasible with dedicated hardware (broken in practice).
:::

## §7.8 Variance, Standard Deviation, and Chebyshev's Inequality

:::definition[Definition]
Variance

$$
\text{Var}(X) = E[(X-E[X])^2] = E[X^2] - (E[X])^2
$$

 Standard deviation: $\sigma = \sqrt{\text{Var}(X)}$.

 $\text{Var}(X+Y) = \text{Var}(X) + \text{Var}(Y)$ when $X,Y$ are **independent**.
:::

:::theorem[Theorem]
Chebyshev's Inequality

For any random variable $X$ with mean $\mu$ and variance $\sigma^2$, and any $k>0$:

$$
P(|X - \mu| \ge k\sigma) \le \frac{1}{k^2}
$$

 Equivalently: $P(|X-\mu| \ge t) \le \sigma^2/t^2$.
:::

Example 7.11 — Chebyshev Applied

A randomized algorithm runs in expected time 100ms with standard deviation 20ms. What is the probability it takes more than 160ms?

:::answer[Solution]
$\mu=100$, $\sigma=20$. Deviation of 60ms = $3\sigma$, so $k=3$.

$P(|X-100| \ge 60) \le 1/9 \approx 11.1\%$.

$P(X \ge 160) \le P(|X-100|\ge 60) \le 1/9$.

Chebyshev gives a distribution-free bound — useful when we only know mean and variance.
:::

:::callout-intuition[Intuition — When to Use Each Tool]
- **Complement rule**: "at least one" ↔ $1 - P(\text{none})
- **Linearity of expectation**: counting expected "hits" — always works, even with dependence
- **Bayes' theorem**: updating belief given new evidence
- **Birthday bound**: estimating collision time — $\approx\sqrt{n}$ items suffice
- **Chebyshev**: bounding tail probability when only mean + variance are known
:::

:::summary
### Chapter 7 Summary

- **Sample space $\Omega$**, events as subsets; Kolmogorov axioms: non-negative, normalization, additivity.
- **Complement rule:** $P(A)=1-P(\bar{A})$ — often the fastest path for "at least one" problems.
- **Conditional probability:** $P(A\mid B)=P(A\cap B)/P(B)$; independence: $P(A\cap B)=P(A)P(B)$.
- **Total probability & Bayes':** update belief; low base rate dominates (medical test paradox).
- **Linearity of expectation:** $E[X+Y]=E[X]+E[Y]$ always — most powerful tool for discrete expected values.
- **Key distributions:** Bernoulli$(p)$, Binomial$(n,p)$ with $E=np$, Geometric$(p)$ with $E=1/p$.
- **Birthday bound:** collision after $\approx\sqrt{2n\ln 2}$ items — crucial for hashing & cryptography.
- **Chebyshev:** distribution-free tail bound $P(|X-\mu|\ge k\sigma)\le 1/k^2$.
:::

## Practice Problems

:::problem[Problem 1]{difficulty="easy"}
Problem 1

A card is drawn from a standard 52-card deck. What is the probability it is a face card (J, Q, K) or a heart?

::::solution[Solution]
Face cards: 12. Hearts: 13. Face card AND heart: 3 (J♥, Q♥, K♥).

$P = P(\text{face}) + P(\text{heart}) - P(\text{both}) = 12/52 + 13/52 - 3/52 = 22/52 = \mathbf{11/26} \approx 42.3\%$.
::::
:::

:::problem[Problem 2]{difficulty="easy"}
Problem 2

A biased coin lands heads with probability 0.6. If it is flipped 5 times, what is the probability of exactly 3 heads?

::::solution[Solution]
$X\sim\text{Bin}(5,0.6)$. $P(X=3)=\binom{5}{3}(0.6)^3(0.4)^2 = 10 \times 0.216 \times 0.16 = \mathbf{0.3456}$.
::::
:::

:::problem[Problem 3]{difficulty="standard"}
Problem 3

1% of a population carries a gene. A test is 95% accurate (both sensitivity and specificity). If you test positive, what is the probability you carry the gene?

::::solution[Solution]
$P(G)=0.01$, $P(+\mid G)=0.95$, $P(+\mid\bar{G})=0.05$.

$P(+)=0.95\times0.01+0.05\times0.99=0.0095+0.0495=0.059$.

$P(G\mid+)=0.0095/0.059\approx\mathbf{16.1\%}$.
::::
:::

:::problem[Problem 4]{difficulty="standard"}
Problem 4

A hash table has $n=10{,}000$ slots. Approximately how many keys must be inserted before the probability of a collision exceeds 50%?

::::solution[Solution]
Birthday bound: $k \approx \sqrt{2n\ln 2} = \sqrt{2\times10000\times0.693} \approx \sqrt{13860} \approx \mathbf{118}$ keys.
::::
:::

:::problem[Problem 5]{difficulty="standard"}
Problem 5

Use linearity of expectation: 100 people each independently buy a lottery ticket. Each has a $1/100$ chance of winning. What is the expected number of winners?

::::solution[Solution]
Let $X_i=1$ if person $i$ wins. $E[X_i]=1/100$. By linearity: $E\left[\sum_{i=1}^{100}X_i\right]=100\times(1/100)=\mathbf{1}$.
::::
:::

:::problem[Problem 6]{difficulty="challenge"}
Problem 6

Prove that the geometric distribution is memoryless: $P(X > m+n \mid X > m) = P(X > n)$ for $X \sim \text{Geom}(p)$.

::::solution[Solution]
$P(X>k) = (1-p)^k$ (first $k$ trials all fail).

$P(X>m+n \mid X>m) = \frac{P(X>m+n \text{ and } X>m)}{P(X>m)} = \frac{P(X>m+n)}{P(X>m)} = \frac{(1-p)^{m+n}}{(1-p)^m} = (1-p)^n = P(X>n)$. $\square$
::::
:::

:::problem[Problem 7]{difficulty="challenge"}
Problem 7

A fair coin is flipped repeatedly. What is the expected number of flips until you see "HH" (two consecutive heads)?

::::solution[Solution]
Let $E$ = expected flips from start, $E_H$ = expected additional flips after one H.

$E = 1 + \frac{1}{2}E_H + \frac{1}{2}E$ (flip T: reset; flip H: go to state H).

$E_H = 1 + \frac{1}{2}(0) + \frac{1}{2}E$ (flip H: done; flip T: reset to start).

From eq 2: $E_H = 1 + E/2$. Substitute into eq 1: $E = 1 + \frac{1}{2}(1+E/2)+\frac{1}{2}E = 1 + 1/2 + E/4 + E/2$.

$E - 3E/4 = 3/2 \Rightarrow E/4 = 3/2 \Rightarrow E = \mathbf{6}$.
::::
:::

## LeetCode Practice

| # | Title | Difficulty | Concept |
| --- | --- | --- | --- |
| 382 | [Linked List Random Node](https://leetcode.com/problems/linked-list-random-node/) | Medium | Reservoir sampling (uniform random) |
| 398 | [Random Pick Index](https://leetcode.com/problems/random-pick-index/) | Medium | Reservoir sampling |
| 470 | [Implement Rand10 Using Rand7](https://leetcode.com/problems/implement-rand10-using-rand7/) | Medium | Rejection sampling, probability |
| 519 | [Random Flip Matrix](https://leetcode.com/problems/random-flip-matrix/) | Medium | Uniform random, Fisher-Yates |
| 528 | [Random Pick with Weight](https://leetcode.com/problems/random-pick-with-weight/) | Medium | Prefix sums + binary search for weighted sampling |
