---
title: "Chapter 16: Introduction to Data Structures & Algorithms"
source: "cpp_ch16_dsa_intro.html"
---

CSE 2813

# Chapter 16: Introduction to Data Structures & Algorithms

§16.1 – §16.6

:::callout-connect
Bridge chapter:

Chapters 1–15 built your C++ toolkit. This chapter introduces the vocabulary and reasoning framework of Data Structures & Algorithms — the subject matter of CSE 2813 (Discrete Structures) and beyond. Everything here will reappear in greater depth next semester.
:::

## §16.1 — Data Structures

A **data structure** is a way of organizing, storing, and managing data in memory so that it can be accessed and modified efficiently. The choice of data structure directly determines what operations are fast and what operations are slow.

### Core Data Structures Overview

#### Array / Vector

Elements in contiguous memory. Fast random access by index. Slow insert/delete in the middle.

Access: O(1)   Insert: O(n)

#### Linked List

Nodes connected by pointers. Fast insert/delete at known position. Slow index access.

Access: O(n)   Insert: O(1)\*

#### Stack

LIFO (Last In, First Out). Push and pop from the top. Used in function calls, undo operations.

Push/Pop: O(1)

#### Queue

FIFO (First In, First Out). Enqueue at back, dequeue from front. Used in scheduling.

Enqueue/Dequeue: O(1)

#### Hash Table / Map

Key-value pairs. Average O(1) lookup by key using a hash function.

Lookup: O(1) avg

#### Tree

Hierarchical structure. Binary Search Tree gives O(log n) search if balanced.

Search: O(log n) balanced

### Choosing a Data Structure

| If you need… | Use… |
| --- | --- |
| Fast access by index | Array / Vector |
| Fast insert/delete anywhere | Linked List |
| LIFO order (undo, call stack) | Stack |
| FIFO order (job queue) | Queue |
| Fast lookup by key | Hash Table (unordered\_map) |
| Sorted data + fast search | BST / set / map |
| Priority-based retrieval | Heap / priority\_queue |

:::callout-intuition
Data structures don't compete — they specialize. A database uses multiple simultaneously: a B-tree for indexed lookups, a hash table for session management, a queue for pending writes. The skill is knowing which tool to reach for first.
:::

## §16.2 — Introduction to Algorithms

An **algorithm** is a finite, unambiguous sequence of steps that solves a specific problem. Good algorithms are:

- **Correct** — produces the right answer for all valid inputs
- **Efficient** — uses reasonable time and memory
- **Clear** — understandable and maintainable
- **Terminating** — always finishes in finite time

### Algorithm Design Techniques

| Technique | Idea | Example |
| --- | --- | --- |
| Brute Force | Try all possibilities | Linear search |
| Divide & Conquer | Split problem, solve halves, combine | Merge sort, binary search |
| Greedy | Always take the locally best choice | Dijkstra's shortest path |
| Dynamic Programming | Cache subproblem results | Fibonacci (memo), knapsack |
| Backtracking | Explore and undo bad choices | Sudoku solver, N-Queens |

### The Algorithm Design Process

```text
1. Understand the problem exactly (input/output, constraints)
2. Work through small examples by hand
3. Identify the pattern or technique
4. Write pseudocode or describe steps in plain English
5. Implement in code
6. Test with edge cases (empty input, one element, max size)
7. Analyze time and space complexity
8. Optimize if needed
```

## §16.3 — Relationship Between Data Structures and Algorithms

Data structures and algorithms are inseparable. The same algorithm behaves completely differently depending on the underlying data structure, and choosing the right data structure often makes an algorithm trivially simple.

### Case Study: Finding Duplicates

```cpp
// Approach 1: Brute force with array — O(n²)
bool hasDuplicate_BruteForce(const vector<int>& v) {
    for (int i = 0; i < (int)v.size(); i++)
        for (int j = i+1; j < (int)v.size(); j++)
            if (v[i] == v[j]) return true;
    return false;
}

// Approach 2: Sort first, then scan — O(n log n)
bool hasDuplicate_Sorted(vector<int> v) {   // copy
    sort(v.begin(), v.end());
    for (int i = 1; i < (int)v.size(); i++)
        if (v[i] == v[i-1]) return true;
    return false;
}

// Approach 3: Hash set — O(n) time, O(n) space
bool hasDuplicate_HashSet(const vector<int>& v) {
    unordered_set<int> seen;
    for (int x : v) {
        if (seen.count(x)) return true;
        seen.insert(x);
    }
    return false;
}
// Same problem, three data structures, three complexities!
```

:::callout-key
The fundamental trade-off: time vs. space.

- Approach 1: O(n²) time, O(1) space
- Approach 2: O(n log n) time, O(1) space (in-place sort)
- Approach 3: O(n) time, O(n) space

Which wins? For large n, Approach 3. For memory-constrained systems, Approach 2. For tiny n (under 10), Approach 1 is fine.
:::

### Niklauss Wirth's Famous Equation

:::callout-tip
Algorithms + Data Structures = Programs

— Niklaus Wirth, 1976 (creator of Pascal)
:::

## §16.4 — Abstract Data Types (ADTs)

An **Abstract Data Type (ADT)** defines a data type by its *behavior* (what operations it supports and what they mean) rather than its *implementation* (how those operations work internally).

An ADT is a *contract*: "I promise to provide these operations with these semantics." The internal implementation is hidden.

### Stack ADT

```text
Stack ADT:
  Operations:
    push(item)   — add item to the top
    pop()        — remove and return top item
    peek()       — return top item without removing
    isEmpty()    — return true if no items
    size()       — return number of items

  Invariants:
    - pop() and peek() on empty stack: undefined (or exception)
    - After push(x); peek() → x
    - After push(x); pop() → x, stack returns to previous state
```

```cpp
// Implementation 1: Stack using vector (good cache performance)
template <typename T>
class VectorStack {
    vector<T> data;
public:
    void push(const T& x) { data.push_back(x); }
    T    pop()  { T x=data.back(); data.pop_back(); return x; }
    T    peek() const { return data.back(); }
    bool isEmpty() const { return data.empty(); }
    int  size()    const { return data.size(); }
};

// Implementation 2: Stack using linked list (no reallocation)
template <typename T>
class ListStack {
    struct Node { T val; Node* next; };
    Node* top_ = nullptr;
    int sz = 0;
public:
    void push(const T& x) { top_ = new Node{x, top_}; sz++; }
    T pop() {
        T v = top_->val;
        Node* old = top_; top_ = top_->next;
        delete old; sz--;
        return v;
    }
    T    peek() const { return top_->val; }
    bool isEmpty() const { return top_ == nullptr; }
    int  size()    const { return sz; }
    ~ListStack() { while (!isEmpty()) pop(); }
};

// Both implement the SAME Stack ADT — users can't tell them apart
```

:::callout-intuition
ADTs are why

std::stack

in C++ is actually a

container adaptor

: it provides a Stack interface (push/pop/top) on top of any underlying container (

vector

,

deque

, or

list

). The ADT separates the

what

from the

how

.
:::

### Queue ADT

```text
Queue ADT:
  Operations:
    enqueue(item)  — add item to the back
    dequeue()      — remove and return front item
    front()        — return front item without removing
    isEmpty()      — return true if no items

  Invariants:
    - Items dequeued in the same order they were enqueued (FIFO)
    - dequeue() on empty: undefined/exception
```

### Priority Queue ADT

```cpp
// Priority Queue ADT: always dequeue the highest-priority item
// Implementation: min-heap or max-heap
#include <queue>

// Max-priority queue (largest value = highest priority)
priority_queue<int> maxPQ;
maxPQ.push(3);
maxPQ.push(1);
maxPQ.push(4);
maxPQ.push(1);
maxPQ.push(5);

while (!maxPQ.empty()) {
    cout << maxPQ.top() << " ";   // 5 4 3 1 1
    maxPQ.pop();
}

// Min-priority queue (smallest value = highest priority)
priority_queue<int, vector<int>, greater<int>> minPQ;
// Items come out smallest first
```

## §16.5 — Applications of ADTs

### Stack Applications

```cpp
// Application 1: Balanced parentheses checker
bool isBalanced(const string& s) {
    stack<char> st;
    for (char c : s) {
        if (c=='(' || c=='[' || c=='{') {
            st.push(c);
        } else if (c==')' || c==']' || c=='}') {
            if (st.empty()) return false;
            char top = st.top(); st.pop();
            if ((c==')' && top!='(') ||
                (c==']' && top!='[') ||
                (c=='}' && top!='{')) return false;
        }
    }
    return st.empty();
}

// Application 2: Reverse a string using a stack
string reverse(const string& s) {
    stack<char> st;
    for (char c : s) st.push(c);
    string result;
    while (!st.empty()) { result += st.top(); st.pop(); }
    return result;
}

// Application 3: Evaluate postfix expression (RPN)
// "3 4 + 2 *" = (3+4)*2 = 14
int evalPostfix(const string& expr) {
    stack<int> st;
    istringstream iss(expr);
    string token;
    while (iss >> token) {
        if (isdigit(token[0])) {
            st.push(stoi(token));
        } else {
            int b = st.top(); st.pop();
            int a = st.top(); st.pop();
            if (token=="+") st.push(a+b);
            else if (token=="-") st.push(a-b);
            else if (token=="*") st.push(a*b);
            else if (token=="/") st.push(a/b);
        }
    }
    return st.top();
}
```

### Queue Applications

```cpp
// Application: BFS (Breadth-First Search) on a graph
// Uses a queue to process nodes level by level
void bfs(vector<vector<int>>& adj, int start) {
    int n = adj.size();
    vector<bool> visited(n, false);
    queue<int> q;

    q.push(start);
    visited[start] = true;

    while (!q.empty()) {
        int node = q.front(); q.pop();
        cout << node << " ";

        for (int neighbor : adj[node]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }
}
```

:::callout-connect
Real-world ADT applications:

- **Stack:** function call stack, undo/redo, browser back button, compiler expression parsing
- **Queue:** print spooler, CPU scheduling, BFS graph traversal, network packet buffering
- **Priority Queue:** Dijkstra's shortest path, hospital triage, operating system scheduling
- **Hash Table:** database indexes, caches, symbol tables in compilers
- **Tree:** file systems, HTML/XML DOM, database B-trees, decision trees
:::

## §16.6 — Algorithm Efficiency

We measure algorithm efficiency with **Big-O notation** — a mathematical way to describe how running time (or memory) scales with input size $n$. (You saw this in Chapter 10; here we connect it to data structure choice.)

### Growth Rate Table

| Complexity | n=10 | n=100 | n=1,000 | n=1,000,000 |
| --- | --- | --- | --- | --- |
| O(1) — constant | 1 | 1 | 1 | 1 |
| O(log n) | 3 | 7 | 10 | 20 |
| O(n) — linear | 10 | 100 | 1,000 | 1,000,000 |
| O(n log n) | 33 | 664 | 9,966 | ~20M |
| O(n²) — quadratic | 100 | 10,000 | 1,000,000 | 10¹² |
| O(2ⁿ) — exponential | 1,024 | 10³⁰ | 10³⁰¹ | ☠ |

### Complexity of Common Operations

| Operation | Array | Linked List | BST (balanced) | Hash Table |
| --- | --- | --- | --- | --- |
| Access by index | O(1) | O(n) | — | — |
| Search (unsorted) | O(n) | O(n) | O(log n) | O(1) avg |
| Insert at front | O(n) | O(1) | O(log n) | O(1) avg |
| Delete at front | O(n) | O(1) | O(log n) | O(1) avg |

### Practical Efficiency: When Theory Meets Reality

```cpp
// Sometimes O(n²) beats O(n log n) in practice for small n
// due to cache effects and constant factors

// Insertion sort (O(n²)) is often faster than merge sort (O(n log n))
// for arrays smaller than ~32 elements — that's why std::sort
// uses introsort: quicksort → heapsort → insertion sort

// Benchmark example (pseudocode thinking):
// n=10:     insertionSort ~30 ops vs mergeSort ~33 ops → IS wins
// n=1000:   insertionSort ~500K  vs mergeSort ~10K    → MS wins
// n=1M:     insertionSort ~500B  vs mergeSort ~20M    → MS wins decisively
```

:::callout-tip
The Three Questions of Algorithm Analysis:

1. **Best case** — what's the minimum work required? (e.g., array already sorted)
2. **Worst case** — maximum work? (guarantees — this is Big-O)
3. **Average case** — expected work for random inputs? (most realistic)
:::

:::problem{difficulty="easy"}
Practice 16.6 — Identify Complexity

For each code snippet, identify the Big-O time complexity and justify your answer:

a) A nested loop where outer runs n times, inner runs log n times.

 b) A function that checks if a hash set contains a value.

 c) Recursive function that splits array in half each call and does O(n) work per level.

::::solution[Solution]
```text
a) O(n log n) — outer n × inner log n = n log n total operations.
   Example: outer iterates indices 0..n-1, inner does binary search.

b) O(1) average — hash set lookup is O(1) average case (hash computed,
   bucket accessed directly). O(n) worst case with many collisions.

c) O(n log n) — this is the merge sort recurrence.
   T(n) = 2T(n/2) + O(n)
   log n levels of recursion × O(n) work per level = O(n log n).
```
::::
:::

## Chapter 16 — Summary & Bridge to CSE 2813

:::callout-key
Concepts Introduced

- Data structures: array, list, stack, queue, tree, hash
- Algorithm design techniques (D&C, greedy, DP, etc.)
- ADT: behavior-defined types hiding implementation
- Stack ADT (LIFO) and Queue ADT (FIFO)
- Time/space complexity with Big-O
- The time vs. space trade-off
:::

:::callout-connect
Coming in CSE 2813 (Discrete Structures)

- Formal proof of algorithm correctness
- Recurrence relations (merge sort, Fibonacci)
- Graph theory (BFS, DFS, shortest paths)
- Trees: BST, AVL, heaps in depth
- Hashing: collision resolution strategies
- NP-completeness: limits of efficient algorithms
:::

## Practice Problems

:::problem{difficulty="easy"}
P1 — Stack as Calculator

Implement a postfix (RPN) calculator that reads tokens from a string. Operators: +, -, \*, /. Use a `stack<double>`. Handle division by zero with a thrown exception.

::::solution[Solution]
```cpp
double evalRPN(const string& expr) {
    stack<double> st;
    istringstream iss(expr);
    string tok;
    while (iss >> tok) {
        if (tok=="+"||tok=="-"||tok=="*"||tok=="/") {
            if (st.size() < 2) throw runtime_error("Bad expression");
            double b=st.top();st.pop(); double a=st.top();st.pop();
            if (tok=="+" ) st.push(a+b);
            if (tok=="-" ) st.push(a-b);
            if (tok=="*" ) st.push(a*b);
            if (tok=="/") {
                if (b==0) throw invalid_argument("Division by zero");
                st.push(a/b);
            }
        } else st.push(stod(tok));
    }
    if (st.size()!=1) throw runtime_error("Bad expression");
    return st.top();
}
```
::::
:::

:::problem{difficulty="standard"}
P2 — LRU Cache (Conceptual)

A Least Recently Used (LRU) Cache evicts the least-recently-used item when full. Describe: which data structures would you combine, and why? What is the complexity of get() and put()? Then implement a simplified version for integer keys/values.

::::solution[Solution]
```text
Structures: doubly-linked list + hash map
- List: maintains usage order (front = most recent, back = least recent)
- Map: maps key → list iterator for O(1) lookup

get(key): O(1) — hash map lookup, move node to front
put(key, val): O(1) — insert at front; evict back node if over capacity

Simple implementation (capacity=2):
```

```cpp
class LRUCache {
    int cap;
    list<pair<int,int>> order;          // front = most recent
    unordered_map<int, list<pair<int,int>>::iterator> map;
public:
    LRUCache(int c) : cap(c) {}
    int get(int key) {
        if (!map.count(key)) return -1;
        order.splice(order.begin(), order, map[key]);
        return map[key]->second;
    }
    void put(int key, int val) {
        if (map.count(key)) order.erase(map[key]);
        order.push_front({key, val});
        map[key] = order.begin();
        if ((int)order.size() > cap) {
            map.erase(order.back().first);
            order.pop_back();
        }
    }
};
```
::::
:::

## LeetCode Problems

:::callout-tip
These problems are chosen specifically to apply Stack, Queue, and Hash Table ADTs — reinforcing the key lesson of this chapter: the right data structure makes algorithms simple.

::::problem{difficulty="easy"}
P4 — Choosing the Right ADT

For each scenario, name the most appropriate ADT and justify: (a) Undo/Redo in a text editor, (b) Print job spooler, (c) Browser history (back button), (d) Autocomplete suggestions (top-k by frequency), (e) De-duplicate a stream of millions of user IDs.

:::::solution[Solution]
- **(a) Stack** — Undo pushes state; redo pops from a second stack. LIFO perfectly matches "most-recent-first" undo semantics.
- **(b) Queue** — Jobs are processed in the order they arrive (FIFO). A priority queue improves this by adding urgency ranking.
- **(c) Stack** — The back button pops the most recently visited page. A second stack handles "forward".
- **(d) Priority Queue (Max-Heap)** — Maintain a heap keyed by frequency. Top-k extraction is O(k log n).
- **(e) Hash Set** — O(1) average insert and lookup. A Bloom filter (probabilistic) works if a small false-positive rate is acceptable and memory is constrained.
:::::
::::

::::problem{difficulty="standard"}
P5 — Complexity Reasoning

An algorithm processes a list of n items in a nested loop: the outer loop runs n times; the inner loop runs from i=0 to i (increasing by 1 each outer iteration). (a) Write a recurrence or summation for the total operations. (b) Simplify to Big-O. (c) If n=1000, approximately how many operations?

:::::solution[Solution]
**(a) Summation:** Total = Σ(i=0 to n−1) of i = 0 + 1 + 2 + ... + (n−1) = n(n−1)/2

**(b) Big-O:** n(n−1)/2 = (n² − n)/2. Drop lower-order term and constant: **O(n²)**

**(c) n=1000:** 1000·999/2 = 499,500 ≈ **500,000 operations**. Compare to O(n log n): 1000·10 = 10,000. The O(n²) algorithm does ~50× more work.
:::::
::::

::::problem{difficulty="standard"}
P6 — Design an ADT

Design a **RecentCounter** ADT that tracks requests and returns the number of requests in the last 3000 milliseconds. Operations: `RecentCounter()`, `int ping(int t)` where t is the timestamp of a new request (guaranteed increasing). Specify the ADT operations, their complexities, and implement it.

:::::solution[Solution]
**ADT Specification:**

- `ping(t)` — Add request at time t; return count of requests in [t−3000, t]. Precondition: t > previous t. Postcondition: old requests outside window are discarded.

**Implementation — Queue (FIFO removes old timestamps):**

```cpp
class RecentCounter {
    queue<int> window;
public:
    int ping(int t) {
        window.push(t);
        // Evict requests older than 3000ms
        while (window.front() < t - 3000)
            window.pop();
        return window.size();
    }
};
```

**Complexity:** Each timestamp is pushed once and popped at most once → amortized O(1) per ping. Space: O(k) where k = number of requests in the current 3-second window.
:::::
::::

| # | Problem | Difficulty | ADT Used |
| --- | --- | --- | --- |
| 20 | [Valid Parentheses](https://leetcode.com/problems/valid-parentheses/) | Easy | Stack — LIFO matching of open/close brackets |
| 225 | [Implement Stack Using Queues](https://leetcode.com/problems/implement-stack-using-queues/) | Easy | ADT implementation — build one ADT from another |
| 1 | [Two Sum](https://leetcode.com/problems/two-sum/) | Easy | Hash table — O(n) lookup beats O(n²) brute force |
| 146 | [LRU Cache](https://leetcode.com/problems/lru-cache/) | Medium | Combined DS: list + hash map for O(1) get/put |
:::
