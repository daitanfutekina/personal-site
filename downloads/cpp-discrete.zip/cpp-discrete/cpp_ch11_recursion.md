---
title: "Chapter 11 — Recursion"
source: "cpp_ch11_recursion.html"
---

CSE 1384

DSA

# Chapter 11 — Recursion

§11.1 – §11.9

## §11.1 · Recursion: Introduction

A function is **recursive** when it calls itself. Rather than solving a big problem all at once, it reduces the problem to a slightly smaller version of itself — and trusts that version to do the same, until hitting a trivially small **base case** that it can answer directly.

Every correct recursive function has exactly two parts:

- **Base case** — the simplest input where the answer is known directly (no recursive call). Without this, the function recurses forever and crashes.
- **Recursive case** — reduces the problem toward the base case and combines smaller results to form the full answer.

:::callout-intuition
Think of recursion like Russian nesting dolls (Matryoshka). To open the outermost doll you open the next one, which opens the next, until you reach the smallest solid doll — the base case. On the way back out, each doll "closes" by combining its piece of the answer.
:::

### The simplest recursive function

```cpp
// Count down from n to 1, then print "Go!"
void countDown(int n) {
    if (n == 0) {           // base case
        cout << "Go!\n";
        return;
    }
    cout << n << "...\n";
    countDown(n - 1);       // recursive case: smaller problem
}
// countDown(3) prints:  3... 2... 1... Go!
```

Call sequence (each arrow = one recursive call):

```
countDown(3) → prints 3

  countDown(2) → prints 2

    countDown(1) → prints 1

      countDown(0) → prints "Go!" (base case — returns)
```

## §11.2 · Recursive Functions with Return Values

### Factorial

```cpp
// n! = n × (n-1)!    base: 0! = 1
long long factorial(int n) {
    if (n == 0) return 1;             // base case
    return n * factorial(n - 1);     // recursive case
}
```

Unrolling `factorial(4)`:

```
factorial(4) = 4 × factorial(3)

                 = 4 × 3 × factorial(2)

                 = 4 × 3 × 2 × factorial(1)

                 = 4 × 3 × 2 × 1 × factorial(0) → 1

= 4 × 3 × 2 × 1 × 1 = 24
```

Stack frames at deepest point (`factorial(0)` about to return):

bottom of stack

main: (calls factorial(4))

frame 1

factorial(4): n=4, waiting for factorial(3)

frame 2

factorial(3): n=3, waiting for factorial(2)

frame 3

factorial(2): n=2, waiting for factorial(1)

frame 4

factorial(1): n=1, waiting for factorial(0)

top — currently executing

factorial(0): n=0 → returns 1

### Power function

```cpp
// xⁿ = x × xⁿ⁻¹   base: x⁰ = 1
double power(double x, int n) {
    if (n == 0) return 1.0;
    if (n <  0) return 1.0 / power(x, -n);   // handle negative exponents
    return x * power(x, n - 1);
}
// power(2, 10) → 1024.0

// Optimized: fast exponentiation — O(log n) instead of O(n)
double fastPow(double x, int n) {
    if (n == 0) return 1.0;
    if (n <  0) return 1.0 / fastPow(x, -n);
    if (n % 2 == 0) {
        double half = fastPow(x, n / 2);
        return half * half;            // square the result instead of recurse twice
    }
    return x * fastPow(x, n - 1);
}
// fastPow(2, 10): depth = log₂(10) ≈ 4 calls  vs  10 calls for power()
```

:::callout-key
fastPow

is

O(log n)

because it halves n on every even step — the same halving that makes binary search fast. This is LeetCode #50 (Pow(x,n)) and a classic interview question. The key insight: $x^n = (x^{n/2})^2$, so you compute the half-power once and square it rather than recursing twice.
:::

## §11.3 · Recursive Algorithm: Search

### Recursive linear search

```cpp
// Search v[lo..hi] for target. Returns index or -1.
int linearSearchRec(const vector<int>& v, int target, int i = 0) {
    if (i == (int)v.size()) return -1;       // base: exhausted array
    if (v[i] == target)    return i;         // base: found
    return linearSearchRec(v, target, i+1); // recurse on rest
}
```

### Recursive binary search

```cpp
int bsRec(const vector<int>& v, int target, int lo, int hi) {
    if (lo > hi) return -1;                        // base: empty range
    int mid = lo + (hi - lo) / 2;
    if      (v[mid] == target) return mid;
    else if (v[mid] <  target) return bsRec(v, target, mid+1, hi);
    else                       return bsRec(v, target, lo, mid-1);
}
```

:::callout-intuition
Recursive binary search reads exactly like the mathematical definition of the algorithm: if the range is empty, stop; if we found it, return; otherwise recurse on the appropriate half. Many people find it cleaner to read than the iterative version — the logic maps 1-to-1 with the problem structure.
:::

## §11.4 · Adding Output Statements for Debugging

Recursive functions can be hard to debug because many call frames are active simultaneously. The standard technique is to add a `depth` parameter and print indented trace output to visualize the call tree.

```cpp
long long factorialDebug(int n, int depth = 0) {
    string indent(depth * 2, ' ');   // indent by 2 spaces per level
    cout << indent << "factorialDebug(" << n << ") called\n";

    if (n == 0) {
        cout << indent << "→ base case, returning 1\n";
        return 1;
    }

    long long result = n * factorialDebug(n - 1, depth + 1);
    cout << indent << "→ returning " << result << '\n';
    return result;
}
/* factorialDebug(3) output:
   factorialDebug(3) called
     factorialDebug(2) called
       factorialDebug(1) called
         factorialDebug(0) called
         → base case, returning 1
       → returning 1
     → returning 2
   → returning 6
*/
```

:::callout-key
The indent trick is invaluable. Once you can read the call tree from the output, most recursive bugs become immediately obvious — either the base case fires too early/late, or the recursive call passes the wrong argument.
:::

## §11.5 · Creating a Recursive Function — Design Recipe

Follow this four-step recipe every time you write a recursive function:

1. **Identify the base case(s).** What is the simplest version of the problem that can be answered directly, without further recursion?
2. **Identify the recursive case.** How do you reduce the current problem to a strictly smaller (closer-to-base) version?
3. **Trust the recursion.** Assume the recursive call returns the correct answer for the smaller input. Use that result to build the answer for the current input.
4. **Verify termination.** Confirm that every recursive call moves strictly toward the base case — otherwise you have infinite recursion.

#### Applying the recipe — sum of digits

```cpp
// Step 1: Base case — single digit (n < 10): digit sum is n itself
// Step 2: Recursive case — last digit is n%10; rest of digits: sumDigits(n/10)
// Step 3: sumDigits(n) = (n%10) + sumDigits(n/10)
// Step 4: n/10 < n for n ≥ 1, so we always shrink toward base

int sumDigits(int n) {
    if (n < 10) return n;                     // base case
    return (n % 10) + sumDigits(n / 10);      // recursive case
}
// sumDigits(1234): 4 + sumDigits(123)
//                    → 4 + 3 + sumDigits(12)
//                           → 4 + 3 + 2 + sumDigits(1) → 1
//                  = 10
```

#### Applying the recipe — reverse a string

```cpp
// Step 1: Base case — empty or single-char string: already reversed
// Step 2: Recursive case — swap first and last, recurse on middle
// Step 3: reverseStr(s) = s.back() + reverseStr(middle) + s.front()

string reverseStr(const string& s) {
    if (s.length() <= 1) return s;
    return s.back() + reverseStr(s.substr(1, s.length()-2)) + s.front();
}
// reverseStr("hello"): 'o' + reverseStr("ell") + 'h'
//                              = 'o' + 'l' + reverseStr("l") + 'l' + ... + 'h'
//                              = "olleh"
```

## §11.6 · Recursive Math Functions

### GCD — Euclidean algorithm

```cpp
// gcd(a, b) = gcd(b, a % b)   base: gcd(a, 0) = a
int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}
// gcd(48, 18): gcd(18, 12) → gcd(12, 6) → gcd(6, 0) → 6
```

### Fibonacci — naive, memoized, and iterative

```cpp
// Naive: O(2ⁿ) — recomputes sub-problems exponentially
int fibNaive(int n) {
    if (n <= 1) return n;
    return fibNaive(n-1) + fibNaive(n-2);
}

// Memoized: O(n) time, O(n) space
#include <unordered_map>
unordered_map<int,int> cache;
int fibMemo(int n) {
    if (n <= 1) return n;
    if (cache.count(n)) return cache[n];
    return cache[n] = fibMemo(n-1) + fibMemo(n-2);
}

// Bottom-up: O(n) time, O(1) space — best for production
int fib(int n) {
    if (n <= 1) return n;
    int a = 0, b = 1;
    for (int i = 2; i <= n; ++i) { int c = a+b; a = b; b = c; }
    return b;
}
```

:::callout-connect
Fibonacci is the gateway to

dynamic programming

. The memoized version introduces the key DP idea: "store results of sub-problems to avoid redundant recomputation." The bottom-up version shows that you can often eliminate recursion entirely once you understand the dependency structure — each fib(n) only needs the previous two values.
:::

### Climbing stairs — counting paths

```cpp
// Climbing n stairs, taking 1 or 2 steps at a time — how many ways?
// ways(n) = ways(n-1) + ways(n-2)   ← same recurrence as Fibonacci!
// Base: ways(0) = 1 (empty path), ways(1) = 1
int climbStairs(int n) {
    if (n <= 1) return 1;
    int a = 1, b = 1;
    for (int i = 2; i <= n; ++i) { int c = a+b; a = b; b = c; }
    return b;
}
// climbStairs(4): ways = 5  (1+1+1+1, 1+1+2, 1+2+1, 2+1+1, 2+2)
```

## §11.7 · Recursive Exploration of All Possibilities

**Backtracking** uses recursion to systematically explore all possibilities by making a choice, recursing, and then *undoing* the choice (backtracking) before trying the next option. It is the foundation of combinatorial algorithms: permutations, combinations, sudoku solvers, N-queens.

### Generating all subsets of {1, 2, 3}

```cpp
#include <vector>
#include <iostream>
using namespace std;

// At each index, decide: include nums[idx] in current subset, or skip it
void subsets(vector<int>& nums, int idx, vector<int>& current) {
    if (idx == (int)nums.size()) {
        // Base case: printed all elements — record this subset
        cout << "{";
        for (int i = 0; i < (int)current.size(); ++i)
            cout << (i?",":"") << current[i];
        cout << "}\n";
        return;
    }
    // Choice 1: INCLUDE nums[idx]
    current.push_back(nums[idx]);
    subsets(nums, idx + 1, current);
    current.pop_back();             // ← BACKTRACK (undo choice 1)

    // Choice 2: SKIP nums[idx]
    subsets(nums, idx + 1, current);
}

int main() {
    vector<int> nums = {1, 2, 3};
    vector<int> current;
    subsets(nums, 0, current);
}
/* Output (2³ = 8 subsets):
   {1,2,3}  {1,2}  {1,3}  {1}  {2,3}  {2}  {3}  {}
*/
```

:::callout-key
The

push / recurse / pop

pattern is the universal backtracking template:

```cpp
current.push_back(choice);   // make choice
recurse(next_state);          // explore
current.pop_back();           // undo choice (backtrack)
```

Every backtracking problem — permutations, combinations, sudoku, N-queens — uses this exact skeleton.
:::

### Generating all permutations

The order the two backtracking examples produce is worth predicting before you run
them, because getting it wrong is the usual sign that the recursion is not understood yet.

Subsets recurse *include first*, so the first branch taken all the way down keeps
every element and prints `{1,2,3}`. Unwinding one level and taking the skip
branch gives `{1,2}`, and the whole listing is that pattern repeated: the
sequence is a binary counter read from the top, and the empty set arrives last because it
is the branch where every choice was “skip”.

Permutations are less obvious, and the last two entries are where intuition usually
fails. With `lo = 0` the loop swaps position 0 with each of positions 0, 1 and 2
in turn. The third of those swaps `A` with `C`, giving
`CBA` before any deeper recursion happens — so `CBA` is printed
*before* `CAB`, not after. Alphabetical order is not what this algorithm
produces; it produces whatever the swap sequence yields. If you need sorted output, sort
the results or use `std::next_permutation`, which does guarantee it.

:::callout-pitfall[Pitfall]
Both functions restore their state after recursing —

pop\_back()

in one,
  the second

swap

in the other — and both would still

run

if you
  forgot. They would simply print the wrong sets, which is far harder to notice than a
  crash. When backtracking output looks almost right, the undo step is the first thing to
  check.
:::

```cpp
void permutations(string s, int lo, int hi) {
    if (lo == hi) { cout << s << '\n'; return; }
    for (int i = lo; i <= hi; ++i) {
        swap(s[lo], s[i]);               // choose: put s[i] at position lo
        permutations(s, lo + 1, hi);     // recurse on remaining positions
        swap(s[lo], s[i]);               // backtrack: restore original order
    }
}
// permutations("ABC", 0, 2)
// → ABC, ACB, BAC, BCA, CBA, CAB  (3! = 6 permutations)
```

## §11.8 · Stack Overflow

Recursion depth is not free, and the limit is lower than most people expect. Every call
holds its parameters, its locals and a return address on the stack, and the stack is
typically one to eight megabytes — so a frame of a hundred bytes runs out somewhere in
the tens of thousands of calls. That is fine for a tree of depth 20 and fatal for a linear
recursion over a million-element list.

The two causes below look different but are the same mistake: the base case is not
reachable from where the recursion is heading. The first has no base case at all; the second
has one and walks away from it. Both are worth being able to spot by reading, because the
symptom they produce — a segmentation fault with no message — tells you nothing
about which function was at fault.

Each recursive call pushes a new stack frame. If recursion is too deep — or never terminates — the stack runs out of space and the program crashes with a **stack overflow** (segmentation fault on most systems).

### Common causes

```cpp
// CAUSE 1 — Missing base case
int infinite(int n) {
    return infinite(n - 1);   // base case forgotten → infinite recursion
}

// CAUSE 2 — Base case never reached (wrong direction)
int badFactorial(int n) {
    if (n == 1) return 1;
    return n * badFactorial(n + 1);   // ← +1 instead of -1; n grows forever!
}

// CAUSE 3 — Input outside expected range
int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n - 1);
}
// factorial(-1) → factorial(-2) → ... → never hits n==0 → overflow
// Fix: assert(n >= 0) or if (n <= 0) return 1;
```

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Segfault / stack overflow immediately | No base case, or never reached | Add / fix base case; add debug prints |
| Correct for small n, crashes for large n | Recursion depth exceeds stack limit (~10,000–100,000 frames) | Convert to iterative or increase stack size |
| Wrong answer without crash | Base case returns wrong value, or recursive step wrong | Add depth-indented debug trace (§11.4) |

:::callout-pitfall
The default stack on most systems holds roughly 10,000–100,000 frames depending on frame size.

factorial(100000)

would overflow even though the logic is correct. When recursion depth could be large, use an iterative solution or explicit stack data structure instead.
:::

## §11.9 · Worked Example — Recursively Output Permutations

#### Full implementation: all permutations of a string, no duplicates

```cpp
#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;

// Collect all unique permutations of s[lo..hi] into result
void permHelper(string s, int lo, vector<string>& result) {
    if (lo == (int)s.size() - 1) {
        result.push_back(s);
        return;
    }
    for (int i = lo; i < (int)s.size(); ++i) {
        // Skip duplicate: if s[i] already appeared at position lo in this pass
        if (i != lo && s[i] == s[lo]) continue;

        swap(s[lo], s[i]);
        permHelper(s, lo + 1, result);
        swap(s[lo], s[i]);   // backtrack
    }
}

vector<string> allPermutations(string s) {
    sort(s.begin(), s.end());   // sort so duplicates are adjacent
    vector<string> result;
    permHelper(s, 0, result);
    sort(result.begin(), result.end());
    return result;
}

int main() {
    for (const string& p : allPermutations("ABC"))
        cout << p << '\n';
    cout << "---\n";
    // "AAB" has duplicates — only 3 unique permutations
    for (const string& p : allPermutations("AAB"))
        cout << p << '\n';
}
/* Output:
   ABC  ACB  BAC  BCA  CAB  CBA
   ---
   AAB  ABA  BAA
*/
```

Trace of call tree for `"AB"` (lo=0):

```
permHelper("AB", lo=0)

  i=0: swap(s[0],s[0])="AB" → permHelper("AB", lo=1)

                                   lo==size-1: record "AB"

     backtrack → "AB"

  i=1: swap(s[0],s[1])="BA" → permHelper("BA", lo=1)

                                   lo==size-1: record "BA"

     backtrack → "AB"
```

:::summary
### Chapter 11 — Key Takeaways

- Every recursive function needs a **base case** (stops recursion) and a **recursive case** (reduces toward the base).
- Each call gets its own stack frame. Deep recursion can cause **stack overflow** — convert to iterative when depth could be large.
- **Design recipe**: identify base case → recursive case → trust the recursion → verify termination.
- Add depth-indented print statements to debug — they make the call tree visible.
- **Fast exponentiation** (`fastPow`) is O(log n): square the half-power rather than multiply n times.
- Naive Fibonacci is O(2ⁿ); memoization brings it to O(n); bottom-up DP brings it to O(1) space.
- **Backtracking template**: push choice → recurse → pop (undo). Used for permutations, subsets, Sudoku, N-Queens.
- The number of permutations of n distinct items is n! — grows extremely fast (20! ≈ 2.4 × 10¹⁸).
- Recursion and iteration are equally powerful (any recursive function can be rewritten iteratively using an explicit stack).
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Fibonacci Number

Write `int fib(int n)` three ways: (a) naive recursion, (b) memoized recursion, (c) iterative O(1) space. State the time and space complexity of each.

::::solution[Solution]
```cpp
// (a) Naive — O(2ⁿ) time, O(n) space (call stack)
int fibA(int n){if(n<=1)return n;return fibA(n-1)+fibA(n-2);}

// (b) Memoized — O(n) time, O(n) space
unordered_map<int,int> m;
int fibB(int n){if(n<=1)return n;if(m.count(n))return m[n];return m[n]=fibB(n-1)+fibB(n-2);}

// (c) Iterative — O(n) time, O(1) space  ← preferred
int fibC(int n){if(n<=1)return n;int a=0,b=1;for(int i=2;i<=n;++i){int c=a+b;a=b;b=c;}return b;}
// fib(10) = 55
```
::::
:::

:::problem{difficulty="easy"}
P2 — Climbing Stairs

You can climb 1 or 2 steps at a time. How many distinct ways to reach step n? Write both a memoized recursive solution and an iterative solution.

::::solution[Solution]
```cpp
// Memoized
unordered_map<int,int> memo;
int climbRec(int n) {
    if (n <= 1) return 1;
    if (memo.count(n)) return memo[n];
    return memo[n] = climbRec(n-1) + climbRec(n-2);
}
// Iterative O(1) space
int climbDP(int n) {
    if (n <= 1) return 1;
    int a = 1, b = 1;
    for (int i = 2; i <= n; ++i) { int c = a+b; a = b; b = c; }
    return b;
}
// climbDP(5) → 8
```
::::
:::

:::problem{difficulty="standard"}
P3 — Recursive Power (Fast Exponentiation)

Implement `double myPow(double x, int n)` in O(log n) using the fast exponentiation technique. Handle negative exponents correctly.

::::solution[Solution]
```cpp
double myPow(double x, long long n) {
    if (n == 0) return 1.0;
    if (n <  0) return 1.0 / myPow(x, -n);
    if (n % 2 == 0) {
        double half = myPow(x, n / 2);
        return half * half;
    }
    return x * myPow(x, n - 1);
}
// myPow(2, 10) → 1024   myPow(2, -3) → 0.125
```

Note: use `long long n` because `-INT_MIN` overflows `int`. Each even step halves n → O(log n) depth.
::::
:::

:::problem{difficulty="standard"}
P4 — Sum of Nested List (Recursive)

You have a `vector<int>`. Write a recursive function `int sumRange(const vector<int>& v, int lo, int hi)` that sums `v[lo..hi]` using divide-and-conquer: split at the midpoint, sum both halves, combine.

::::solution[Solution]
```cpp
int sumRange(const vector<int>& v, int lo, int hi) {
    if (lo == hi) return v[lo];              // base: single element
    int mid = lo + (hi - lo) / 2;
    return sumRange(v, lo, mid) +            // left half
           sumRange(v, mid+1, hi);           // right half
}
// sumRange({1,2,3,4,5}, 0, 4) → 15
// Complexity: T(n) = 2T(n/2) + O(1) → O(n)  (visits each element once)
```
::::
:::

:::problem{difficulty="challenge"}
P5 — Generate All Combinations of Size k

Given n and k, generate all combinations of k numbers chosen from [1..n]. Example: n=4, k=2 → {1,2}, {1,3}, {1,4}, {2,3}, {2,4}, {3,4}.

::::solution[Solution]
```cpp
void combine(int n, int k, int start, vector<int>& current,
             vector<vector<int>>& result) {
    if ((int)current.size() == k) {
        result.push_back(current);
        return;
    }
    // Pruning: only iterate if enough numbers remain
    for (int i = start; i <= n - (k - (int)current.size()) + 1; ++i) {
        current.push_back(i);                         // choose i
        combine(n, k, i + 1, current, result);        // recurse
        current.pop_back();                           // backtrack
    }
}

vector<vector<int>> combinations(int n, int k) {
    vector<vector<int>> result;
    vector<int> current;
    combine(n, k, 1, current, result);
    return result;
}
// combinations(4, 2) → {{1,2},{1,3},{1,4},{2,3},{2,4},{3,4}}
```

The pruning condition `i <= n - (k - current.size()) + 1` avoids branches that can never produce k elements — it significantly speeds up backtracking for large inputs.
::::
:::

:::callout-tip
Work these in order — they build on each other. For #50 and #779, write the naive recursive solution first, analyze its complexity, then optimize.

| # | Problem | Difficulty | Recursive pattern |
| --- | --- | --- | --- |
| 509 | [Fibonacci Number](https://leetcode.com/problems/fibonacci-number/) | Easy | Base cases + memoization vs bottom-up |
| 70 | [Climbing Stairs](https://leetcode.com/problems/climbing-stairs/) | Easy | Same recurrence as Fibonacci; O(1) space target |
| 344 | [Reverse String](https://leetcode.com/problems/reverse-string/) | Easy | Two-pointer recursion; also iterative — compare both |
| 50 | [Pow(x, n)](https://leetcode.com/problems/powx-n/) | Medium | Fast exponentiation O(log n); handle INT\_MIN edge case |
| 779 | [K-th Symbol in Grammar](https://leetcode.com/problems/k-th-symbol-in-grammar/) | Medium | Recursive structure of grammar rows; parent-child pattern |
:::
