---
title: "C++ Programming & Discrete Structures"
crumb: "Mississippi State University · Computer Engineering"
source: "master_index.html"
---

CSE 1384 Computer Programming — CSE 2813 Discrete Structures — → Honors DSA — → Digital Devices

This self-study textbook combines two courses into a single reference: **CSE 1384** covers
 every section of the C++ programming curriculum from first principles through data structures.
 **CSE 2813** covers the most important Discrete Structures topics —
 the full course plus strategic emphasis on topics required for
 *Honors Data Structures & Algorithms* and
 *Digital Devices & Logic Design*.
 Sections tagged DSA and LOGIC have special importance for downstream courses.

0 / 38

Chapters done

0h

Study time

Update this manually as you progress

DSA Critical for Honors Data Structures & Algorithms — LOGIC Critical for Digital Devices & Logic Design — CORE Core to the current course — OPT Optional / enrichment — ☐ Planned ⋯ In progress ✓ Done

### 🌲 Honors Data Structures & Algorithms

- Ch 7 (Computation) — asymptotic analysis
- Ch 8 (Induction & Recursion) — recurrences, divide-and-conquer
- Ch 10–11 (Counting) — hash tables, expected case analysis
- Ch 12 (Probability) — randomized algorithms
- Ch 6 (Relations) — partial orders, DAGs, topological sort
- Ch 13 (Graphs) — BFS/DFS foundations, connectivity
- Ch 14 (Trees) — traversals, spanning trees, MST

### ⚡ Digital Devices & Logic Design

- Ch 1 (Logic) — propositional logic → combinational circuits
- Ch 5 (Boolean Algebra) — gates, minimization, canonical forms
- Ch 7 (Computation) — Finite State Machines (Mealy/Moore)
- Ch 9 §9.1–9.6 (Integer Properties) — number systems, binary arithmetic
- C++ Ch 2.13 (Binary), Ch 2.18 (Unsigned) — bit-level representation

Part I

## C++ Programming — CSE 1384

All 20 chapters of the zyBooks curriculum, every section included. Primary emphasis of the textbook.

:::solution[✓
 Ch 1
 \[Introduction to C++\](./cpp_ch1_intro.html)
 14 sections]
- 1.1Programming (general)
- 1.2Programming basics
- 1.3Console input
- 1.4Comments and whitespace
- 1.5Errors and warnings
- 1.6Computers and programs (general)
- 1.7Integrated development environment
- 1.8Computer tour
- 1.9Language history
- 1.10Problem solving
- 1.11Why programming
- 1.12Why whitespace and precision matter
- 1.13Example: Salary calculation
- 1.14Example: Married-couple names
:::

:::solution[✓
 Ch 2
 \[Variables & Assignments\](./cpp_ch2_variables.html)
 24 sections]
- 2.1Variables and assignments (general)
- 2.2Variables (int)
- 2.3Identifiers
- 2.4Arithmetic expressions (general)
- 2.5Arithmetic expressions (int)
- 2.6Example: Health data
- 2.7Floating-point numbers (double)
- 2.8Scientific notation for floating-point literals
- 2.9Constant variables
- 2.10Using math functions
- 2.11Integer division and modulo
- 2.12Type conversions
- 2.13Binary LOGIC
- 2.14Characters
- 2.15Strings
- 2.16Integer overflow
- 2.17Numeric data types
- 2.18Unsigned LOGIC
- 2.19Random numbers
- 2.20Debugging
- 2.21Auto (since C++11)
- 2.22Style guidelines
- 2.23Example: Salary calculation with variables
- 2.24Example: Married-couple names with variables
:::

:::solution[✓
 Ch 3
 \[Streams\](./cpp_ch3_io.html)
 9 sections]
- 3.1Output and input streams
- 3.2Output formatting
- 3.3Input string stream
- 3.4Output string stream
- 3.5File input
- 3.6Example: Parsing and validating input files
- 3.7File output
- 3.8Example: Saving and retrieving program data
- 3.9Overloading stream operators
:::

:::solution[✓
 Ch 4
 \[Branches\](./cpp_ch4_branches.html)
 21 sections]
- 4.1If-else branches (general)
- 4.2Detecting equal values with branches
- 4.3Detecting ranges with branches (general)
- 4.4Detecting ranges with branches
- 4.5Detecting ranges using logical operators
- 4.6Detecting ranges with gaps
- 4.7Detecting multiple features with branches
- 4.8Common branching errors
- 4.9Order of evaluation
- 4.10Example: Toll calculation
- 4.11Switch statements
- 4.12Boolean data type
- 4.13String comparisons
- 4.14String access operations
- 4.15Character operations
- 4.16Finding, inserting, and replacing text in a string
- 4.17Conditional expressions
- 4.18Floating-point comparison
- 4.19Short circuit evaluation
- 4.20Example: Salary calculation with branches
- 4.21Example: Search for name using branches
:::

:::solution[✓
 Ch 5
 \[Loops\](./cpp_ch5_loops.html)
 13 sections]
- 5.1Loops (general)
- 5.2While loops
- 5.3More while examples
- 5.4For loops
- 5.5More for loop examples
- 5.6Loops and strings
- 5.7Nested loops
- 5.8Developing programs incrementally
- 5.9Break and continue
- 5.10Variable name scope
- 5.11Enumerations
- 5.12Example: Salary calculation with loops
- 5.13Example: Domain name validation with loops
:::

:::solution[✓
 Ch 6
 \[Arrays / Vectors\](./cpp_ch6_arrays.html)
 17 sections]
- 6.1Array/vector concept (general)
- 6.2Vectors
- 6.3Array/vector iteration drill
- 6.4Iterating through vectors
- 6.5Multiple vectors
- 6.6Vector resize
- 6.7Vector back() and pop\_back()
- 6.8Using a loop to modify, copy, or compare vectors
- 6.9Swapping two variables (general)
- 6.10Debugging example: Reversing a vector
- 6.11Arrays vs. vectors
- 6.12Two-dimensional arrays
- 6.13Char arrays / C strings
- 6.14C-String library functions
- 6.15Char library functions: cctype
- 6.16Example: Annual salary tax rate calculation with vectors
- 6.17Example: Domain name validation with vectors
:::

:::solution[✓
 Ch 7
 \[User-Defined Functions\](./cpp_ch7_functions.html)
 20 sections]
- 7.1User-defined function basics
- 7.2Print functions
- 7.3Reasons for defining functions
- 7.4Writing mathematical functions
- 7.5Functions with branches
- 7.6Functions with loops
- 7.7Unit testing (functions)
- 7.8How functions work
- 7.9Functions: Common errors
- 7.10Pass by reference
- 7.11Using pass by reference to modify string/vector parameters
- 7.12Functions with C string parameters
- 7.13Scope of variable/function definitions
- 7.14Default parameter values
- 7.15Function name overloading
- 7.16Parameter error checking
- 7.17Preprocessor and include
- 7.18Separate files
- 7.19Example: Salary calculation with functions
- 7.20Example: Domain name validation with functions
:::

:::solution[✓
 Ch 8
 \[Pointers\](./cpp_ch8_pointers.html)
 17 sections]
- 8.1Pointers (general)
- 8.2Pointers and dynamically allocated arrays
- 8.3Changing the size of a dynamically allocated array
- 8.4Dynamically allocating objects
- 8.5Allocating arrays of objects
- 8.6Classes with dynamically allocated data
- 8.7String functions with pointers
- 8.8A first linked list
- 8.9Memory regions: Heap / Stack
- 8.10Destructors
- 8.11Memory leaks
- 8.12Destructors (simple linked lists)
- 8.13Copy constructors
- 8.14Copy assignment operator
- 8.15Rule of Three
- 8.16Smart pointers
- 8.17Example: Employee list using vectors
:::

:::solution[✓
 Ch 9
 \[Searching and Sorting Algorithms\](./cpp_ch9_sorting.html)
 7 sectionsDSA]
- 9.1Searching and algorithmsDSA
- 9.2Sorting: Introduction
- 9.3Binary searchDSA
- 9.4Sorting: Introduction (cont.)
- 9.5Bubble sort
- 9.6Selection sort
- 9.7Insertion sort
:::

:::solution[✓
 Ch 10
 \[Introduction to Algorithm Analysis\](./cpp_ch10_bigO.html)
 9 sectionsDSA]
- 10.1Searching and algorithms
- 10.2Binary searchDSA
- 10.3Constant time operationsDSA
- 10.4Growth of functions and complexityDSA
- 10.5O notationDSA
- 10.6Algorithm analysisDSA
- 10.7Recursive definitionsDSA
- 10.8Recursive algorithmsDSA
- 10.9Analyzing the time complexity of recursive algorithmsDSA
:::

:::solution[✓
 Ch 11
 \[Recursion\](./cpp_ch11_recursion.html)
 9 sectionsDSA]
- 11.1Recursion: Introduction
- 11.2Recursive functions
- 11.3Recursive algorithm: Search
- 11.4Adding output statements for debugging
- 11.5Creating a recursive function
- 11.6Recursive math functions
- 11.7Recursive exploration of all possibilities
- 11.8Stack overflow
- 11.9Example: Recursively output permutations
:::

:::solution[✓
 Ch 12
 \[Advanced Sorting Algorithms\](./cpp_ch12_adv_sorting.html)
 7 sectionsDSA]
- 12.1QuicksortDSA
- 12.2Merge sortDSA
- 12.3Shell sort
- 12.4Radix sort
- 12.5Bucket sort
- 12.6QuickselectDSA
- 12.7Overview of fast sorting algorithmsDSA
:::

:::solution[✓
 Ch 13
 \[Objects and Classes\](./cpp_ch13_classes.html)
 20 sections]
- 13.1Objects: Introduction
- 13.2Using a class
- 13.3Defining a class
- 13.4Inline member functions
- 13.5Mutators, accessors, and private helpers
- 13.6Initialization and constructors
- 13.7Classes and vectors/classes
- 13.8Separate files for classes
- 13.9Choosing classes to create
- 13.10Unit testing (classes)
- 13.11Constructor overloading
- 13.12Constructor initializer lists
- 13.13The 'this' implicit parameter
- 13.14Operator overloading
- 13.15Overloading comparison operators
- 13.16Vector ADT
- 13.17Namespaces
- 13.18Static data members and functions
- 13.19Example: Salary calculation with classes
- 13.20Example: Domain name availability with classes
:::

:::solution[✓
 Ch 14
 \[Inheritance\](./cpp_ch14_inheritance.html)
 10 sections]
- 14.1Derived classes
- 14.2Access by members of derived classes
- 14.3Overriding member functions
- 14.4Polymorphism and virtual member functions
- 14.5Abstract classes: Introduction (generic)
- 14.6Abstract classes
- 14.7Is-a versus has-a relationships
- 14.8UML
- 14.9Example: Employees and overriding class functions
- 14.10Example: Employees using an abstract class
:::

:::solution[✓
 Ch 15
 \[Exceptions\](./cpp_ch15_exceptions.html)
 5 sections]
- 15.1Handling exceptions
- 15.2Throwing exceptions
- 15.3Exceptions with files
- 15.4User-defined exceptions
- 15.5Example: Generate number format exception
:::

:::solution[✓
 Ch 15A
 \[Streams & File I/O\](./cpp_ch15a_streams.html)
 7 sections]
- Revisits Chapter 3’s ground and goes further: stream state bits, file modes, and the newline trap when `>>` and `getline` are mixed.
:::

:::solution[✓
 Ch 16
 \[Introduction to Data Structures and Algorithms\](./cpp_ch16_dsa_intro.html)
 6 sectionsDSA]
- 16.1Data structuresDSA
- 16.2Introduction to algorithmsDSA
- 16.3Relation between data structures and algorithmsDSA
- 16.4Abstract data typesDSA
- 16.5Applications of ADTsDSA
- 16.6Algorithm efficiencyDSA
:::

:::solution[✓
 Ch 17
 \[Linked Lists\](./cpp_ch17_linked_lists.html)
 12 sectionsDSA]
- 17.1List abstract data type (ADT)DSA
- 17.2Singly-linked listsDSA
- 17.3Singly-linked lists: Search and insertDSA
- 17.4Singly-linked lists: RemoveDSA
- 17.5Doubly-linked listsDSA
- 17.6Doubly-linked lists: Search and insertDSA
- 17.7Doubly-linked lists: RemoveDSA
- 17.8Circular lists
- 17.9Linked list traversalDSA
- 17.10Sorting linked lists
- 17.11Linked list dummy nodes
- 17.12Linked lists: RecursionDSA
:::

:::solution[✓
 Ch 18
 \[Stacks and Queues\](./cpp_ch18_stacks_queues.html)
 8 sectionsDSA]
- 18.1Stack abstract data type (ADT)DSA
- 18.2Stacks using linked listsDSA
- 18.3Array-based stacksDSA
- 18.4Queue abstract data type (ADT)DSA
- 18.5Queues using linked listsDSA
- 18.6Array-based queuesDSA
- 18.7Deque abstract data type (ADT)DSA
- 18.8Array-based listsDSA
:::

:::solution[✓
 Ch 19
 \[Additional Material\](./cpp_ch19_additional.html)
 26 sections]
- 19.1Do-while loops
- 19.2Arrays
- 19.3Iterating through arrays
- 19.4Multiple arrays
- 19.5Using a loop to modify or copy an array
- 19.6Debugging example: Reversing an array
- 19.7Engineering examples
- 19.8Functions with array parameters
- 19.9Functions with array parameters: Common errors
- 19.10Engineering examples using functions
- 19.11Grouping data: struct
- 19.12Structs and functions
- 19.13Structs and vectors
- 19.14Structs, vectors, and functions: Seat reservation example
- 19.15Command-line arguments
- 19.16Command-line arguments and files
- 19.17The #define directive
- 19.18Compiling and running using a command-line interface
- 19.19Modular compilation
- 19.20Makefiles
- 19.21Why pointers?
- 19.22Practice: Output art
- 19.23Practice: Grade calculation
- 19.24Practice: Abbreviation decoder
- 19.25Practice: Dice statistics
- 19.26zyBooks built-in programming window
:::

:::solution[✓
 Ch 20
 \[Artificial Intelligence\](./cpp_ch20_ai.html)
 5 sections]
- 20.1Artificial intelligence
- 20.2Generative AI and LLMs
- 20.3Generative AI in action
- 20.4Building AI systems
- 20.5Risks and ethics in AI
:::

Part II

## Discrete Structures — CSE 2813

All 14 substantive chapters from the 2813 curriculum. Topics are tagged by their downstream course relevance.
 Every section is included in the textbook; tags indicate where extra depth is warranted.

:::solution[✓
 DS–1
 \[Logic\](./ds_ch1_logic.html)
 13 sectionsLOGICDSA]
- 1.1Propositions and logical operationsLOGICCORE
- 1.2Evaluating compound propositionsLOGICCORE
- 1.3Conditional statementsCORE
- 1.4Logical equivalenceLOGICCORE
- 1.5Laws of propositional logicLOGICCORE
- 1.6Predicates and quantifiersCORE
- 1.7Quantified statementsCORE
- 1.8De Morgan's law for quantified statementsCORE
- 1.9Nested quantifiersCORE
- 1.10More nested quantified statements
- 1.11Logical reasoningDSA
- 1.12Rules of inference with propositionsDSA
- 1.13Rules of inference with quantifiersDSA
:::

:::solution[✓
 DS–2
 \[Proofs\](./ds_ch2_proofs.html)
 7 sectionsDSA]
- 2.1Mathematical definitionsCORE
- 2.2Introduction to proofsCORE
- 2.3Best practices and common errors in proofs
- 2.4Writing direct proofsDSA
- 2.5Proof by contrapositiveDSA
- 2.6Proof by contradictionDSA
- 2.7Proof by casesDSA
:::

:::solution[✓
 DS–3
 \[Sets\](./ds_ch3_sets.html)
 7 sections]
- 3.1Sets and subsetsCORE
- 3.2Sets of sets
- 3.3Union and intersectionCORE
- 3.4More set operationsCORE
- 3.5Set identitiesLOGIC
- 3.6Cartesian productsDSA
- 3.7PartitionsDSA
:::

:::solution[✓
 DS–4
 \[Functions\](./ds_ch4_functions.html)
 8 sectionsDSA]
- 4.1Definition of functionsCORE
- 4.2Floor and ceiling functionsDSA
- 4.3Properties of functionsCORE
- 4.4The inverse of a function
- 4.5Composition of functions
- 4.6Logarithms and exponentsDSA
- 4.7Infinite setsOPT
- 4.8Uncountable setsOPT
:::

:::solution[✓
 DS–5
 \[Sequences & Summations\](./ds_ch5_sequences.html)
 6 sections★★★ LOGIC]
- 5.1An introduction to Boolean algebraLOGICCORE
- 5.2Boolean functionsLOGICCORE
- 5.3Disjunctive and conjunctive normal form (DNF/CNF)LOGICCORE
- 5.4Functional completenessLOGIC
- 5.5Boolean satisfiabilityDSA
- 5.6Gates and circuitsLOGICCORE
:::

:::solution[✓
 DS–6
 \[Counting\](./ds_ch6_counting.html)
 10 sectionsDSA]
- 6.1Introduction to binary relationsCORE
- 6.2Properties of binary relationsCORE
- 6.3Directed graphs, paths, and cyclesDSACORE
- 6.4Composition of relations
- 6.5Graph powers and the transitive closureDSA
- 6.6Matrix multiplication and graph powersDSA
- 6.7Partial ordersDSA
- 6.8Strict orders and directed acyclic graphs (DAGs)DSA
- 6.9Equivalence relationsDSA
- 6.10n-ary relations and relational databasesOPT
:::

:::solution[✓
 DS–7
 \[Probability\](./ds_ch7_probability.html)
 6 sectionsDSALOGIC]
- 7.1An introduction to algorithmsDSACORE
- 7.2Asymptotic growth of functions (Big-O, Θ, Ω)DSACORE
- 7.3Analysis of algorithmsDSACORE
- 7.4Finite state machines (FSMs)LOGICCORE
- 7.5Turing machinesOPT
- 7.6Decision problems and languagesDSA
:::

:::solution[✓
 DS–8
 \[Number Theory\](./ds_ch8_number_theory.html)
 17 sections★★★ DSA]
- 8.1SequencesCORE
- 8.2Recurrence relationsDSACORE
- 8.3SummationsDSACORE
- 8.4Mathematical inductionDSACORE
- 8.5More inductive proofsDSA
- 8.6Strong induction and well-orderingDSA
- 8.7Loop invariantsDSA
- 8.8Recursive definitionsDSACORE
- 8.9Structural inductionDSA
- 8.10Recursive algorithmsDSACORE
- 8.11Induction and recursive algorithmsDSA
- 8.12Analyzing the time complexity of recursive algorithmsDSACORE
- 8.13Divide-and-conquer: Intro and mergesortDSACORE
- 8.14Divide-and-conquer: Binary searchDSACORE
- 8.15Solving linear homogeneous recurrence relationsDSA
- 8.16Solving linear nonhomogeneous recurrence relationsDSA
- 8.17Divide-and-conquer recurrence relations (Master Theorem)DSA
:::

:::solution[✓
 DS–9
 \[Relations\](./ds_ch9_relations.html)
 9 sectionsLOGIC]
- 9.1The Division AlgorithmCORE
- 9.2Modular arithmeticLOGICCORE
- 9.3Prime factorizationsCORE
- 9.4Factoring and primality testing
- 9.5Greatest common divisor and Euclid's algorithmDSA
- 9.6Number representation (binary, hex, two's complement)LOGICCORE
- 9.7Fast exponentiationDSA
- 9.8Introduction to cryptographyOPT
- 9.9The RSA cryptosystemOPT
:::

:::solution[✓
 DS–10
 \[Graphs\](./ds_ch10_graphs.html)
 12 sectionsDSA]
- 10.1Sum and product rulesCORE
- 10.2The bijection ruleCORE
- 10.3The generalized product ruleCORE
- 10.4Counting permutationsCORE
- 10.5Counting subsetsCORE
- 10.6Subset and permutation examples
- 10.7Counting by complementDSA
- 10.8Permutations with repetitions
- 10.9n-ary relations and relational databasesOPT
- 10.10Assignment problems: Balls in bins
- 10.11Inclusion-exclusion principleDSA
- 10.12Counting problem examples
:::

:::solution[✓
 DS–11
 \[Trees\](./ds_ch11_trees.html)
 4 sectionsDSA]
- 11.1Generating permutations and combinationsDSA
- 11.2Binomial coefficients and combinatorial identitiesDSA
- 11.3The pigeonhole principleDSACORE
- 11.4Generating functionsOPT
:::

:::solution[✓
 DS–12
 \[Discrete Probability\](./ds_ch12_probability.html)
 8 sectionsDSA]
- 12.1Probability of an eventCORE
- 12.2Unions and complements of eventsCORE
- 12.3Conditional probability and independenceDSA
- 12.4Bayes' theoremDSA
- 12.5Random variablesDSA
- 12.6Expectation of a random variableDSA
- 12.7Linearity of expectationsDSA
- 12.8Bernoulli trials and the binomial distributionDSA
:::

:::solution[✓
 DS–13
 \[Graphs\](./ds_ch13_graphs.html)
 9 sections★★★ DSA]
- 13.1Introduction to graphsDSACORE
- 13.2Graph representations (adjacency list/matrix)DSACORE
- 13.3Graph isomorphism
- 13.4Walks, trails, circuits, paths, and cyclesDSACORE
- 13.5Graph connectivityDSACORE
- 13.6Euler circuits and trailsDSA
- 13.7Hamiltonian cycles and pathsDSA
- 13.8Planar graphs
- 13.9Graph coloringDSA
:::

:::solution[✓
 DS–14
 \[Trees\](./ds_ch14_trees.html)
 6 sections★★★ DSA]
- 14.1Introduction to treesDSACORE
- 14.2Tree application examplesDSA
- 14.3Properties of treesDSACORE
- 14.4Tree traversalsDSACORE
- 14.5Spanning trees and graph traversals (BFS/DFS)DSACORE
- 14.6Minimum spanning trees (Prim's, Kruskal's)DSACORE
:::

## Textbook Stats

38

Total chapters

252+

Total sections

20

C++ chapters (all)

14

Discrete chapters

2

Downstream courses served

How to use this index:

Click any chapter row to expand and see all sections.
    Tag key:

DSA

= needed for Honors Data Structures & Algorithms,

LOGIC

= needed for Digital Devices & Logic Design,

CORE</spa
