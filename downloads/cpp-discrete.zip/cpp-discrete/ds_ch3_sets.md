---
title: "DS–3: Sets"
source: "ds_ch3_sets.html"
---

CSE 2813

# DS–3: Sets

§3.1 – §3.8

:::callout-connect
Why sets?

Sets are the foundational language of all of mathematics. Every data structure you've seen — arrays, hash tables, trees — is a set with extra structure. Databases operate on sets of records. Type systems describe sets of values. Graph vertices and edges are sets. Mastering set notation and operations lets you speak precisely about collections of any kind.
:::

## §3.1 — Sets: Notation & Membership

A **set** is an unordered collection of distinct objects called **elements** (or **members**). Sets have no duplicates and no inherent order.

### Roster Notation

List elements explicitly: $A = \{1, 2, 3, 4, 5\}$, $B = \{a, e, i, o, u\}$, $\emptyset = \{\}$ (empty set).

### Set-Builder Notation

Describe elements by property: $\{x \mid P(x)\}$ reads "the set of all $x$ such that $P(x)$."

Examples: $\{x \in \mathbb{Z} \mid x > 0\}$ = positive integers; $\{x^2 \mid x \in \mathbb{Z}\}$ = perfect squares.

### Standard Number Sets

| Symbol | Name | Examples |
| --- | --- | --- |
| $\mathbb{N}$ | Natural numbers | $\{0, 1, 2, 3, \ldots\}$ (sometimes $\{1,2,3,\ldots\}$) |
| $\mathbb{Z}$ | Integers | $\{\ldots, -2, -1, 0, 1, 2, \ldots\}$ |
| $\mathbb{Z}^+$ | Positive integers | $\{1, 2, 3, \ldots\}$ |
| $\mathbb{Q}$ | Rational numbers | $\{p/q \mid p, q \in \mathbb{Z},\ q \neq 0\}$ |
| $\mathbb{R}$ | Real numbers | All points on the number line |
| $\mathbb{C}$ | Complex numbers | $\{a + bi \mid a, b \in \mathbb{R}\}$ |

### Membership Notation

$a \in S$ means "$a$ is an element of $S$." $a \notin S$ means "$a$ is not in $S$."

$A = \{1, 3, 5, 7, 9\}$  →  $3 \in A$ ✓  |  $4 \notin A$ ✓  |  $\{3\} \notin A$ (a set is not the same as its element)

:::callout-pitfall
$\{3\} \neq 3$.

The set containing 3 is distinct from the element 3. Similarly, $\emptyset \neq \{\emptyset\}$ — the empty set has no elements, but $\{\emptyset\}$ is a set containing one element (the empty set itself). This distinction matters for power sets.
:::

## §3.2 — Subsets & Power Sets

:::definition[Definition]
Subset

$A \subseteq B$ ("$A$ is a subset of $B$") if every element of $A$ is also in $B$: $\forall x\,(x \in A \to x \in B)$. $A \subset B$ denotes proper subset: $A \subseteq B$ and $A \neq B$.
:::

### Key Subset Facts

- $\emptyset \subseteq A$ for every set $A$ (vacuously true — no element of $\emptyset$ fails to be in $A$).
- $A \subseteq A$ for every set $A$ (reflexivity).
- If $A \subseteq B$ and $B \subseteq C$, then $A \subseteq C$ (transitivity).
- $A = B \iff A \subseteq B \land B \subseteq A$ — the standard way to prove two sets equal.

### Power Set

:::definition[Definition]
Power Set

The **power set** of $A$, written $\mathcal{P}(A)$ or $2^A$, is the set of ALL subsets of $A$: $\mathcal{P}(A) = \{S \mid S \subseteq A\}$.
:::

Example — Power Set of $\{a, b, c\}$

:::answer
$\mathcal{P}(\{a,b,c\}) = \{\emptyset,\ \{a\},\ \{b\},\ \{c\},\ \{a,b\},\ \{a,c\},\ \{b,c\},\ \{a,b,c\}\}$

Size: $|\mathcal{P}(\{a,b,c\})| = 2^3 = 8$
:::

:::theorem[Theorem]
Size of the Power Set

If $|A| = n$ (finite), then $|\mathcal{P}(A)| = 2^n$.

*Why:* For each element, independently choose IN or OUT — that's $2^n$ binary choices. This is provable by induction.
:::

## §3.3 — Set Operations

Set operations build new sets from existing ones. Let $A$ and $B$ be sets within a **universal set** $U$.

| Operation | Notation | Definition | Logical equivalent |
| --- | --- | --- | --- |
| **Union** | $A \cup B$ | $\{x \mid x \in A \lor x \in B\}$ | OR |
| **Intersection** | $A \cap B$ | $\{x \mid x \in A \land x \in B\}$ | AND |
| **Difference** | $A - B$ or $A \setminus B$ | $\{x \mid x \in A \land x \notin B\}$ | A AND NOT B |
| **Complement** | $\overline{A}$ or $A^c$ | $\{x \in U \mid x \notin A\}$ | NOT A |
| **Symmetric Diff.** | $A \oplus B$ | $(A - B) \cup (B - A)$ | XOR |

### Visual Example

Let $A = \{1,2,3,4,5\}$ and $B = \{3,4,5,6,7\}$, $U = \{1,\ldots,9\}$.

$A \cup B$

1

2

3

4

5

6

7

$A \cap B$

3

4

5

$A - B$

1

2

$\overline{A}$

(relative to U = {1..9})

6

7

8

9

:::callout-key
Disjoint sets:

$A$ and $B$ are

disjoint

if $A \cap B = \emptyset$ — they share no elements.

Partition:

A collection of sets $A_1, A_2, \ldots, A_n$ is a partition of $U$ if they are pairwise disjoint and their union is $U$. Like pigeonholes — every element goes in exactly one bucket.
:::

## §3.4 — Set Identities (Algebra of Sets)

Set operations obey the same algebraic laws as propositional logic — with $\cup \leftrightarrow \lor$, $\cap \leftrightarrow \land$, and $\overline{\cdot} \leftrightarrow \neg$. This is not a coincidence: sets and logic are dual systems.

| Law | Union Form | Intersection Form |
| --- | --- | --- |
| **Identity** | $A \cup \emptyset = A$ | $A \cap U = A$ |
| **Domination** | $A \cup U = U$ | $A \cap \emptyset = \emptyset$ |
| **Idempotent** | $A \cup A = A$ | $A \cap A = A$ |
| **Complement** | $A \cup \overline{A} = U$ | $A \cap \overline{A} = \emptyset$ |
| **Double Complement** | $\overline{\overline{A}} = A$ |
| **Commutative** | $A \cup B = B \cup A$ | $A \cap B = B \cap A$ |
| **Associative** | $(A \cup B) \cup C = A \cup (B \cup C)$ | $(A \cap B) \cap C = A \cap (B \cap C)$ |
| **Distributive** | $A \cup (B \cap C) = (A \cup B) \cap (A \cup C)$ | $A \cap (B \cup C) = (A \cap B) \cup (A \cap C)$ |
| **De Morgan's** | $\overline{A \cup B} = \overline{A} \cap \overline{B}$ | $\overline{A \cap B} = \overline{A} \cup \overline{B}$ |
| **Absorption** | $A \cup (A \cap B) = A$ | $A \cap (A \cup B) = A$ |

### Proving Set Identities

There are two main methods:

1. **Element-chasing (membership proof):** Show $x \in \text{LHS} \Leftrightarrow x \in \text{RHS}$ by unpacking with logical equivalences.
2. **Algebraic:** Apply the identity laws step-by-step, like simplifying a propositional formula.

Prove: $\overline{A \cup B} = \overline{A} \cap \overline{B}$ (De Morgan's for Sets — element proof)

**($\subseteq$) Let $x \in \overline{A \cup B}$.** Then $x \notin A \cup B$, meaning $\neg(x \in A \lor x \in B)$, i.e., $x \notin A \land x \notin B$. So $x \in \overline{A}$ and $x \in \overline{B}$, thus $x \in \overline{A} \cap \overline{B}$.

**($\supseteq$) Let $x \in \overline{A} \cap \overline{B}$.** Then $x \notin A$ and $x \notin B$. So $x \notin A \cup B$, meaning $x \in \overline{A \cup B}$.

Since containment holds both ways, $\overline{A \cup B} = \overline{A} \cap \overline{B}$. ∎

## §3.5 — Venn Diagrams

A **Venn diagram** visualizes relationships between sets as overlapping regions inside a universal rectangle.

$A \cup B$ — shaded region

U

A

B

$A \cap B$ — only overlap

U

A

B

$A - B$ — A without overlap

U

A

B

:::callout-tip
Three-set Venn diagrams

have 8 regions (including the outside): $\emptyset$, $A$ only, $B$ only, $C$ only, $A \cap B$ only, $A \cap C$ only, $B \cap C$ only, and $A \cap B \cap C$. Any combination of three sets can be described by which of these 8 regions are included. This is directly connected to the $2^n$ subsets of a 3-element set!
:::

## §3.6 — Cardinality

:::definition[Definition]
Cardinality

The **cardinality** of a set $A$, written $|A|$, is the number of elements in $A$. For finite sets, this is a non-negative integer.
:::

### Inclusion-Exclusion Principle

:::theorem[Theorem]
Inclusion-Exclusion (Two Sets)

$|A \cup B| = |A| + |B| - |A \cap B|$

You add both sets but subtract the overlap because it was double-counted.
:::

Example — Class Survey

In a class of 30 students: 18 like Python, 15 like Java, 8 like both. How many like at least one?

:::answer
$|P \cup J| = 18 + 15 - 8 = 25$ students. The remaining $30 - 25 = 5$ like neither.
:::

:::theorem[Theorem]
Inclusion-Exclusion (Three Sets)

$|A \cup B \cup C| = |A| + |B| + |C| - |A \cap B| - |A \cap C| - |B \cap C| + |A \cap B \cap C|$
:::

### Countably Infinite vs. Uncountable Sets

For infinite sets, cardinality requires more care. A set is **countably infinite** if its elements can be put in a 1-1 correspondence with $\mathbb{N}$.

| Set | Cardinality | Countable? |
| --- | --- | --- |
| $\mathbb{N}$, $\mathbb{Z}$, $\mathbb{Q}$, any infinite subset of $\mathbb{Q}$ | $\aleph_0$ (aleph-null) | Yes |
| $\mathbb{R}$, $(0,1) \subset \mathbb{R}$, $\mathcal{P}(\mathbb{N})$ | $\mathfrak{c} = 2^{\aleph_0}$ | No (Cantor's theorem) |

:::callout-intuition
Cantor's diagonal argument

(sketch): Suppose you list all real numbers between 0 and 1 in a table. Construct a new number by taking the $n$th digit of the $n$th entry and changing it (e.g., add 1 mod 10). This new number differs from every entry in the table at position $n$ — so it was never in your list. No list can contain all reals: $\mathbb{R}$ is uncountable.
:::

## §3.7 — Cartesian Product

:::definition[Definition]
Ordered Pair & Cartesian Product

An **ordered pair** $(a, b)$ has a first component $a$ and second component $b$. The **Cartesian product** $A \times B = \{(a, b) \mid a \in A \land b \in B\}$.
:::

Example — $\{1,2\} \times \{a,b,c\}$

:::answer
$\{(1,a),\ (1,b),\ (1,c),\ (2,a),\ (2,b),\ (2,c)\}$

$|\{1,2\} \times \{a,b,c\}| = 2 \times 3 = 6$. In general $|A \times B| = |A| \cdot |B|$.
:::

$A \times A$ is often written $A^2$. In general, $A^n = A \times A \times \cdots \times A$ ($n$ times) — the set of all $n$-tuples with components from $A$.

:::callout-connect
CS applications of Cartesian products everywhere:

- **Relations & databases:** A relation on $A \times B$ is a subset of the Cartesian product — exactly what a SQL JOIN computes.
- **2D arrays:** An $m \times n$ array indexes positions $(i,j) \in \{0,\ldots,m-1\} \times \{0,\ldots,n-1\}$.
- **Graph edges:** Edges of a graph are elements of $V \times V$ (ordered for directed graphs).
- **Function domain/codomain:** A function $f: A \to B$ is a subset of $A \times B$ — see DS–4.
:::

## §3.8 — Sets in Computer Science

Sets appear directly in programming. Understanding the mathematical foundations helps you choose the right data structure and reason about correctness.

| Mathematical Set Operation | C++ Data Structure / Operation | Complexity |
| --- | --- | --- |
| $x \in A$ | `unordered_set<T>::count(x)` | $O(1)$ avg |
| $A \cup B$ (sorted) | `set_union` (STL algorithm) | $O(m + n)$ |
| $A \cap B$ (sorted) | `set_intersection` | $O(m + n)$ |
| $A - B$ (sorted) | `set_difference` | $O(m + n)$ |
| $A \subseteq B$ | `std::includes` | $O(m + n)$ |
| $A \oplus B$ (symmetric diff.) | `set_symmetric_difference` | $O(m + n)$ |

:::callout-connect
Hash sets vs. sorted sets:

std::unordered\_set

stores elements in a hash table — average $O(1)$ lookup, no inherent order.

std::set

uses a red-black BST — $O(\log n)$ lookup, elements always sorted. Mathematically, both represent the same abstract set; the choice is a performance trade-off, not a logical one.
:::

### Bit-Vector Representation

If the universal set $U$ has $n$ elements labeled $0, 1, \ldots, n-1$, any subset $A \subseteq U$ can be represented as an $n$-bit integer where bit $i = 1$ iff $i \in A$. Set operations then reduce to bitwise operations:

| Set Operation | Bit operation | C++ |
| --- | --- | --- |
| $A \cup B$ | OR | `a | b` |
| $A \cap B$ | AND | `a & b` |
| $\overline{A}$ | NOT | `~a & mask` |
| $A - B$ | AND NOT | `a & ~b` |
| $A \oplus B$ | XOR | `a ^ b` |
| $x \in A$ | bit test | `(a >> x) & 1` |

This is the foundation for *bitmask DP* — a competitive programming technique where subsets of a small set are enumerated and memoized by their bitmask.

:::summary
## Chapter Summary — DS–3: Sets

- **Set notation:** Roster $\{1,2,3\}$ vs. set-builder $\{x \mid P(x)\}$. Key standard sets: $\mathbb{N}, \mathbb{Z}, \mathbb{Q}, \mathbb{R}$. Membership: $a \in A$.
- **Subsets:** $A \subseteq B$ iff every element of $A$ is in $B$. Prove $A = B$ by showing $A \subseteq B$ AND $B \subseteq A$. The empty set is a subset of every set.
- **Power set:** $\mathcal{P}(A)$ = all subsets of $A$. If $|A| = n$, then $|\mathcal{P}(A)| = 2^n$.
- **Operations:** $\cup$ (OR), $\cap$ (AND), $-$ (AND NOT), $\overline{\cdot}$ (NOT), $\oplus$ (XOR). Every set operation is the set-theoretic analogue of a logical connective.
- **Set identities:** De Morgan's, distributive, absorption — mirror the propositional logic laws exactly. Prove identities by element-chasing (show $x \in$ LHS ↔ $x \in$ RHS).
- **Cardinality:** $|A \cup B| = |A| + |B| - |A \cap B|$ (inclusion-exclusion). $\mathbb{Z}$ and $\mathbb{Q}$ are countably infinite ($\aleph_0$); $\mathbb{R}$ is uncountable.
- **Cartesian product:** $A \times B$ = all ordered pairs $(a,b)$. $|A \times B| = |A| \cdot |B|$. Foundation for relations, functions, graphs, and database tables.
- **CS connections:** `unordered_set` / `set` implement abstract sets. Bit-vector representation maps set operations to bitwise ops — $O(1)$ per operation for small universes.
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Power Set Construction

Let $A = \{x, y, z, w\}$. (a) List all elements of $\mathcal{P}(A)$ (there should be 16). (b) How many subsets of $A$ have exactly 2 elements? (c) How many subsets of $A$ contain the element $x$?

::::solution[Solution]
**(a)** $|\mathcal{P}(A)| = 2^4 = 16$. Subsets by size:

- Size 0: $\emptyset$
- Size 1: $\{x\}, \{y\}, \{z\}, \{w\}$
- Size 2: $\{x,y\}, \{x,z\}, \{x,w\}, \{y,z\}, \{y,w\}, \{z,w\}$
- Size 3: $\{x,y,z\}, \{x,y,w\}, \{x,z,w\}, \{y,z,w\}$
- Size 4: $\{x,y,z,w\}$

**(b)** $\binom{4}{2} = 6$ subsets of size 2.

**(c)** Subsets containing $x$: fix $x$ in the set, then each of the remaining 3 elements is independently in or out → $2^3 = 8$ such subsets. (Equivalently, $|\mathcal{P}(\{y,z,w\})| = 8$.)
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Set Operations

Let $A = \{2, 4, 6, 8, 10\}$, $B = \{1, 2, 3, 4, 5\}$, $C = \{4, 8, 12\}$, $U = \{1, 2, \ldots, 12\}$. Compute: (a) $A \cup B$, (b) $A \cap B$, (c) $A - B$, (d) $\overline{A}$, (e) $A \cap (B \cup C)$.

::::solution[Solution]
**(a)** $A \cup B = \{1,2,3,4,5,6,8,10\}$

**(b)** $A \cap B = \{2,4\}$

**(c)** $A - B = \{6,8,10\}$ (elements of A not in B)

**(d)** $\overline{A} = U - A = \{1,3,5,7,9,11,12\}$

**(e)** First: $B \cup C = \{1,2,3,4,5,8,12\}$. Then $A \cap (B \cup C) = \{2,4,8\}$.
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Inclusion-Exclusion

In a group of 100 students: 55 passed the midterm, 70 passed the final, and 40 passed both. How many passed at least one exam? How many passed neither?

::::solution[Solution]
$|M \cup F| = |M| + |F| - |M \cap F| = 55 + 70 - 40 = 85$ passed at least one.

$100 - 85 = 15$ passed neither.

**Sanity check:** Midterm only = 55 - 40 = 15; Final only = 70 - 40 = 30; Both = 40; Neither = 15. Total = 15 + 30 + 40 + 15 = 100. ✓
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Prove a Set Identity by Element-Chasing

Prove: $A \cap (B \cup C) = (A \cap B) \cup (A \cap C)$ (Distributive Law).

::::solution[Solution]
We show $x \in \text{LHS} \iff x \in \text{RHS}$.

$x \in A \cap (B \cup C)$

$\iff x \in A \land x \in (B \cup C)$

$\iff x \in A \land (x \in B \lor x \in C)$

$\iff (x \in A \land x \in B) \lor (x \in A \land x \in C)$ (by distributive law of logic)

$\iff x \in (A \cap B) \lor x \in (A \cap C)$

$\iff x \in (A \cap B) \cup (A \cap C)$

Since every step is an if-and-only-if, LHS = RHS. ∎
::::
:::

:::problem[P5]{difficulty="standard"}
P5 — Cartesian Product & Bit Representation

(a) Let $A = \{0,1\}$. Describe $A^3$ (all 3-tuples from $A$) and give its size. (b) Let $U = \{0,1,2,3,4\}$ (5 elements). If $A = \{0,2,4\}$ is represented as a 5-bit integer, what is the bit-vector? What is the bit-vector for $\overline{A}$? Compute $A \cap \{1,2,3\}$ using bitwise AND.

::::solution[Solution]
**(a)** $A^3 = \{(0,0,0),(0,0,1),(0,1,0),(0,1,1),(1,0,0),(1,0,1),(1,1,0),(1,1,1)\}$. Size: $2^3 = 8$. These are exactly the 3-bit binary numbers — another set/logic connection!

**(b)** Number elements 0–4, bit $i = 1$ if $i \in A$. $A = \{0,2,4\}$ → bits for positions 4,3,2,1,0: position 4=1, 3=0, 2=1, 1=0, 0=1 → $10101_2 = 21$.

$\overline{A} = \{1,3\}$ → $01010_2 = 10$. (Complement = NOT with mask 11111.)

$B = \{1,2,3\} $ → $01110_2 = 14$. $A \cap B$: $10101_2 \mathbin{\&} 01110_2 = 00100_2$, which represents $\{2\}$. ✓
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — Prove by Induction — Power Set Size

Prove by mathematical induction: If $|A| = n$, then $|\mathcal{P}(A)| = 2^n$.

::::solution[Solution]
**Base case ($n = 0$):** $A = \emptyset$. $\mathcal{P}(\emptyset) = \{\emptyset\}$, so $|\mathcal{P}(\emptyset)| = 1 = 2^0$. ✓

**IH:** Assume any set with $k$ elements has $2^k$ subsets.

**Inductive step:** Let $|A| = k+1$. Pick any element $a \in A$, and let $A' = A \setminus \{a\}$, so $|A'| = k$.

Every subset of $A$ either *contains $a$* or *does not contain $a$*:

- Subsets not containing $a$: these are exactly the subsets of $A'$. By IH, there are $2^k$ of them.
- Subsets containing $a$: these are $\{a\} \cup S$ for each $S \subseteq A'$. Also $2^k$ of them.

Total: $2^k + 2^k = 2^{k+1}$. By induction, $|\mathcal{P}(A)| = 2^n$ for all $n \geq 0$. ∎
::::
:::

## LeetCode Connections

Set operations and bit-vector representations directly enable efficient subset enumeration, intersection queries, and containment checks — all common in competitive programming and real-world algorithms.

| # | Problem | Difficulty | Connection to This Chapter |
| --- | --- | --- | --- |
| [#349](https://leetcode.com/problems/intersection-of-two-arrays/) | Intersection of Two Arrays | Easy | Direct implementation of $A \cap B$ using a hash set. The mathematical definition "$x \in A \cap B \iff x \in A \land x \in B$" maps straight to the code: insert one array into a set, then check membership for each element of the second. |
| [#350](https://leetcode.com/problems/intersection-of-two-arrays-ii/) | Intersection of Two Arrays II | Easy | Multiset intersection (with duplicates) — extends the pure-set $\cap$ to multisets. Uses a frequency map instead of a membership set; comparing to the set version reinforces the "no duplicates" property of mathematical sets. |
| [#78](https://leetcode.com/problems/subsets/) | Subsets | Medium | Generate all $2^n$ subsets — the power set $\mathcal{P}(A)$. The bitmask approach (iterate integers 0 to $2^n-1$; bit $i$ set means element $i$ is in the subset) directly implements the bit-vector representation from §3.8. |
| [#90](https://leetcode.com/problems/subsets-ii/) | Subsets II (with duplicates) | Medium | Power set with duplicate elements — must avoid listing the same subset twice. The key insight is the same "in or out" binary choice from §3.2, but duplicates require the set property (no repeated elements) to be enforced by sorting + skipping. |
| [#2215](https://leetcode.com/problems/find-the-difference-of-two-arrays/) | Find the Difference of Two Arrays | Easy | Returns $[A \setminus B,\ B \setminus A]$ — both set differences. Directly implements the $A - B$ operation from §3.3. The distinct values requirement enforces the "no duplicates" set property. |
