---
title: "Chapter 10 — Introduction to Algorithm Analysis"
source: "cpp_ch10_bigO.html"
---

CSE 1384

DSA

# Chapter 10 — Introduction to Algorithm Analysis

§10.1 – §10.9

## §10.1 – §10.2 · Why Algorithm Analysis Matters

Two programs can solve the same problem correctly yet differ wildly in speed. Algorithm analysis gives us a machine-independent way to measure and compare how performance scales with input size — before we ever run the code.

### A concrete motivator — searching 1 billion records

| Algorithm | Operations on 10⁹ items | At 10⁹ ops/sec |
| --- | --- | --- |
| Linear search | 1,000,000,000 | ~1 second |
| Binary search | ≈ 30 (log₂ 10⁹ ≈ 30) | ~30 nanoseconds |
| Ratio | Binary search is ~33 million× faster on this input |

The difference is not the hardware, the compiler, or the programmer's typing speed — it is the **algorithm**. This is why an O(log n) algorithm is always worth the extra thought, especially at scale.

:::callout-key
Algorithm analysis

answers the question: as input size $n$ grows toward infinity, how does the number of operations (or memory used) grow? We focus on growth

rate

, not exact counts — because constants and small terms disappear at scale.
:::

## §10.3 · Constant Time Operations

An operation is **O(1) — constant time** if it takes the same amount of time regardless of how large the input is.

```cpp
vector<int> v = {10, 20, 30, 40, 50};

v[2]        // O(1) — direct index calculation: base + 2*sizeof(int)
v.size()    // O(1) — size stored as a member variable
v.push_back(60)  // O(1) amortized — occasionally triggers a resize
v.back()    // O(1)
v.front()   // O(1)
swap(a, b)  // O(1) — just three assignments
```

```cpp
// NOT O(1):
v.insert(v.begin(), 99)   // O(n) — must shift all elements right
v.erase(v.begin())        // O(n) — must shift all elements left
find(v.begin(),v.end(),x) // O(n) — may scan entire vector
```

:::callout-intuition
O(1) is the gold standard — it means "scales for free." Accessing an array element, reading a hash map entry, pushing onto a stack — these all stay fast no matter how large the data gets. When you can reformulate a problem to use O(1) lookups instead of O(n) scans, you often unlock dramatic speedups.
:::

## §10.4 – §10.5 · Growth of Functions & Big-O Notation

### The common complexity classes

n

O(1)

O(log n)

O(n)

O(n log n)

O(n²)

O(2ⁿ)

10

1

3

10

33

100

1,024

100

1

7

100

664

10,000

10³⁰

1,000

1

10

1,000

10,000

1,000,000

too large

1,000,000

1

20

10⁶

2×10⁷

10¹²

∞ (effectively)

### Formal definition of Big-O

We say $f(n) = O(g(n))$ if there exist positive constants $c$ and $n_0$ such that:

$$
f(n) \le c \cdot g(n) \quad \text{for all } n \ge n_0
$$

In plain English: past some threshold input size $n_0$, $f(n)$ is bounded above by $g(n)$ scaled by some constant. We care about the *shape* of the curve, not the exact value.

### Big-O simplification rules

| Rule | Example | Simplified |
| --- | --- | --- |
| Drop constants | $O(5n)$ | $O(n)$ |
| Drop lower-order terms | $O(n^2 + n + 1)$ | $O(n^2)$ |
| Keep only the dominant term | $O(n^3 + n^2 \log n)$ | $O(n^3)$ |
| Product rule for nested loops | $O(n) \times O(n)$ | $O(n^2)$ |
| Sum rule for sequential steps | $O(n) + O(n^2)$ | $O(n^2)$ |

### Big-O, Big-Ω, and Big-Θ

| Notation | Meaning | Analogy |
| --- | --- | --- |
| $O(g(n))$ | **Upper bound** — worst case grows no faster than $g$ | ≤ |
| $\Omega(g(n))$ | **Lower bound** — best case grows at least as fast as $g$ | ≥ |
| $\Theta(g(n))$ | **Tight bound** — grows exactly like $g$ (both upper and lower) | = |

In practice, interviews and courses usually say "Big-O" when they really mean Θ (tight bound). Context makes this clear.

## §10.6 · Algorithm Analysis — Reading Code for Complexity

The most useful skill is being able to look at a loop (or nested loops) and immediately state its time complexity. Here is a systematic way to do it.

### Single loops

```cpp
// O(n) — runs n times
for (int i = 0; i < n; ++i) { /* O(1) work */ }

// O(n) — runs n/2 times; constant factor dropped
for (int i = 0; i < n; i += 2) { /* O(1) work */ }

// O(log n) — i doubles each iteration: 1, 2, 4, 8, ... reaches n after log₂n steps
for (int i = 1; i < n; i *= 2) { /* O(1) work */ }

// O(log n) — i halves each iteration
for (int i = n; i > 1; i /= 2) { /* O(1) work */ }
```

:::callout-key
The tell for O(log n) is a loop where the counter is

multiplied or divided

by a constant each step (instead of incremented). Doubling or halving cuts the remaining work in half — that's the hallmark of logarithmic growth.
:::

### Nested loops

```cpp
// O(n²) — classic double loop, inner runs n times per outer iteration
for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j) { /* O(1) */ }

// O(n²) — triangular loop: inner runs i times → total = 0+1+2+...+(n-1) = n(n-1)/2 = O(n²)
for (int i = 0; i < n; ++i)
    for (int j = 0; j < i; ++j) { /* O(1) */ }

// O(n log n) — outer O(n), inner O(log n)
for (int i = 0; i < n; ++i)
    for (int j = 1; j < n; j *= 2) { /* O(1) */ }

// O(n²) — even though loops look different
for (int i = 0; i < n; ++i)
    for (int j = i; j < n; ++j) { /* O(1) */ }   // still n(n+1)/2 iterations
```

#### Example — analyze this function step by step

```cpp
int mystery(vector<int>& v) {         // n = v.size()
    int total = 0;                     // O(1)
    for (int x : v)                    // O(n)
        total += x;                    //   O(1) body → total O(n)

    sort(v.begin(), v.end());          // O(n log n)

    for (int i = 0; i < (int)v.size(); ++i)  // O(n)
        for (int j = i+1; j < (int)v.size(); ++j)  // O(n) worst
            if (v[i] + v[j] == total) return i;    //   O(1) body → O(n²) total

    return -1;                         // O(1)
}
// Overall: O(1) + O(n) + O(n log n) + O(n²) = O(n²)
// Dominant term: O(n²)  — the nested loop wins
```

### Space complexity

**Space complexity** measures how much extra memory an algorithm uses as a function of input size — not counting the input itself.

| Code pattern | Space complexity | Reason |
| --- | --- | --- |
| A few scalar variables | O(1) | Fixed number of variables regardless of n |
| Allocate an array of size n | O(n) | Extra storage grows linearly |
| Allocate n×n matrix | O(n²) | Quadratic storage |
| Recursive function, depth d | O(d) | Each call frame uses O(1) stack space; d frames total |
| In-place sort (bubble, insertion) | O(1) | No extra arrays allocated |
| Merge sort | O(n) | Needs a temporary merge buffer |

:::callout-connect
Interview problems often ask for solutions that are O(n) time

and

O(1) space — meaning "don't use any extra data structures that scale with n." The in-place array rotation from Ch 6 (triple reverse) is a classic example of hitting both targets simultaneously.
:::

## §10.7 – §10.9 · Recursive Definitions & Analyzing Recursive Algorithms

### §10.7 Recursive definitions

A **recursive definition** defines something in terms of a smaller version of itself, plus a base case that stops the recursion. The classic example is factorial:

$$
n! = \begin{cases} 1 & \text{if } n = 0 \\ n \cdot (n-1)! & \text{if } n > 0 \end{cases}
$$

```cpp
int factorial(int n) {
    if (n == 0) return 1;           // base case
    return n * factorial(n - 1);   // recursive case
}
// factorial(4) → 4 * factorial(3)
//                    → 3 * factorial(2)
//                           → 2 * factorial(1)
//                                  → 1 * factorial(0) → 1
```

### §10.8 Recursive algorithms — call tree analysis

To analyze a recursive algorithm, draw its **call tree** and count the total work across all nodes.

#### Binary search — recursive version and analysis

```cpp
int binarySearchRec(const vector<int>& v, int target, int lo, int hi) {
    if (lo > hi) return -1;                              // base: empty range
    int mid = lo + (hi - lo) / 2;
    if      (v[mid] == target) return mid;
    else if (v[mid] <  target) return binarySearchRec(v, target, mid+1, hi);
    else                       return binarySearchRec(v, target, lo, mid-1);
}
```

Each recursive call halves the range. Call tree on n=8:

```
binarySearch(v, t, 0, 7)  — 8 elements

└─ binarySearch(v, t, 4, 7)  — 4 elements

   └─ binarySearch(v, t, 6, 7)  — 2 elements

      └─ binarySearch(v, t, 7, 7)  — 1 element

         └─ return (found or -1)
```

Depth = log₂(8) = 3 levels. Each level does O(1) work → total: **O(log n)**. Same as iterative — recursion adds call-stack overhead but the same number of comparisons.

### §10.9 Recurrence relations

A **recurrence relation** expresses the running time of a recursive algorithm in terms of the time for smaller inputs. Two important ones to know:

| Recurrence | Example algorithm | Solution |
| --- | --- | --- |
| $T(n) = T(n-1) + O(1)$ | Factorial, linear recursion | $O(n)$ |
| $T(n) = T(n/2) + O(1)$ | Binary search | $O(\log n)$ |
| $T(n) = 2T(n/2) + O(n)$ | Merge sort | $O(n \log n)$ |
| $T(n) = T(n-1) + O(n)$ | Insertion sort | $O(n^2)$ |
| $T(n) = 2T(n-1) + O(1)$ | Naive Fibonacci, subset enumeration | $O(2^n)$ |

#### Why naive Fibonacci is O(2ⁿ) — and how to fix it

```cpp
// Naive — exponential: each call spawns TWO recursive calls
int fibSlow(int n) {
    if (n <= 1) return n;
    return fibSlow(n-1) + fibSlow(n-2);   // T(n) = 2T(n-1) + O(1) → O(2ⁿ)
}
// fibSlow(40) ≈ 300 million calls!

// Memoized — O(n) time, O(n) space: cache each sub-result
#include <unordered_map>
unordered_map<int,int> memo;
int fibMemo(int n) {
    if (n <= 1) return n;
    if (memo.count(n)) return memo[n];    // return cached answer
    return memo[n] = fibMemo(n-1) + fibMemo(n-2);
}

// Bottom-up DP — O(n) time, O(1) space: no recursion at all
int fibDP(int n) {
    if (n <= 1) return n;
    int a = 0, b = 1;
    for (int i = 2; i <= n; ++i) { int c = a+b; a = b; b = c; }
    return b;
}
```

Memoization avoids recomputing sub-problems by caching results — each of the n unique inputs is solved exactly once → O(n). The bottom-up version eliminates the call stack entirely.

:::callout-connect
Memoization is the gateway to

dynamic programming (DP)

— one of the most important algorithmic techniques in DSA and software interviews. You'll build on this pattern in Ch 11 (Recursion) and encounter full DP in later courses.
:::

## Big-O Case Study · Two Sum — Three Approaches

LeetCode #1 is the perfect teaching problem for algorithm analysis: the same problem admits solutions with wildly different complexities, and you can measure the difference concretely.

**Problem:** Given an array `nums` and a target integer, return the indices of the two numbers that add up to target. Exactly one solution exists.

#### Approach 1 — Brute force: O(n²) time, O(1) space

```cpp
vector<int> twoSumBrute(vector<int>& nums, int target) {
    int n = nums.size();
    for (int i = 0; i < n; ++i)           // O(n)
        for (int j = i + 1; j < n; ++j)   // O(n)
            if (nums[i] + nums[j] == target)
                return {i, j};
    return {};
}
// Total: O(n²) — checks every pair. Works but slow: 10⁸ pairs for n=10,000.
```

#### Approach 2 — Sort + two pointer: O(n log n) time, O(n) space

```cpp
vector<int> twoSumSort(vector<int>& nums, int target) {
    // Must save original indices before sorting
    int n = nums.size();
    vector<pair<int,int>> indexed(n);          // O(n) space
    for (int i = 0; i < n; ++i) indexed[i] = {nums[i], i};

    sort(indexed.begin(), indexed.end());       // O(n log n)

    int lo = 0, hi = n - 1;
    while (lo < hi) {                          // O(n)
        int s = indexed[lo].first + indexed[hi].first;
        if      (s == target) return {indexed[lo].second, indexed[hi].second};
        else if (s <  target) ++lo;
        else                  --hi;
    }
    return {};
}
// Total: O(n log n) — dominated by sort step.
```

#### Approach 3 — Hash map: O(n) time, O(n) space

```cpp
#include <unordered_map>
vector<int> twoSum(vector<int>& nums, int target) {
    unordered_map<int, int> seen;   // value → index

    for (int i = 0; i < (int)nums.size(); ++i) {
        int complement = target - nums[i];
        if (seen.count(complement))
            return {seen[complement], i};  // found the pair!
        seen[nums[i]] = i;                 // remember this value
    }
    return {};
}
// Total: O(n) — one pass; hash map lookup/insert is O(1) average.
// Trade-off: uses O(n) extra space for the map.
```

Key insight: instead of asking "does any *other* element complete the pair?" for every i, ask "have I *already seen* the complement?" — one O(1) hash map lookup.

| Approach | Time | Space | Notes |
| --- | --- | --- | --- |
| Brute force | O(n²) | O(1) | Fine for tiny n; unusable at scale |
| Sort + two-pointer | O(n log n) | O(n) | Good when sorting the input is acceptable |
| Hash map (optimal) | O(n) | O(n) | Best time; standard interview answer |

:::summary
### Chapter 10 — Key Takeaways

- **Big-O** measures the *growth rate* of time or space as input size n → ∞. Drop constants and lower-order terms.
- Hierarchy: $O(1) \ll O(\log n) \ll O(n) \ll O(n \log n) \ll O(n^2) \ll O(2^n)$
- **Single loop counting**: +1 step → O(n); ×2/÷2 each step → O(log n).
- **Nested loops**: multiply their individual complexities. Triangular loops are still O(n²).
- **Sum rule**: sequential steps → keep the dominant term. $O(n \log n) + O(n^2) = O(n^2)$.
- **Space complexity** counts extra memory, not the input. In-place algorithms are O(1) space.
- A recursive algorithm's complexity comes from its call-tree shape: depth × work per level.
- **Recurrence $T(n) = T(n/2) + O(1)$** → O(log n). **$T(n) = 2T(n/2) + O(n)$** → O(n log n).
- Naive Fibonacci is O(2ⁿ); memoization drops it to O(n) by caching sub-results.
- When you can replace an O(n) lookup (scan) with an O(1) lookup (hash map), you often turn O(n²) into O(n).
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Classify Loop Complexity

State the time complexity (Big-O) of each code fragment. Assume n is the input size and each loop body is O(1).

```cpp
(a) for (int i = n; i > 0; i -= 3) { }
(b) for (int i = 1; i < n; i *= 3) { }
(c) for (int i = 0; i < n; ++i)
       for (int j = 0; j < 100; ++j) { }
(d) for (int i = 0; i < n; ++i)
       for (int j = n; j > 0; j /= 2) { }
```

::::solution[Solution]
- **(a)** O(n) — decrements by 3 (constant), so n/3 iterations → O(n)
- **(b)** O(log n) — multiplies by 3 each step → log₃n iterations
- **(c)** O(n) — outer is O(n), inner is O(100) = O(1) → O(n × 1) = O(n)
- **(d)** O(n log n) — outer O(n), inner O(log n) → product O(n log n)
::::
:::

:::problem{difficulty="easy"}
P2 — Missing Number (Three Approaches)

Given an array containing n distinct numbers in the range [0, n], find the one missing number. Solve it three ways and state each approach's time and space complexity: (a) sort then scan, (b) math formula, (c) XOR.

::::solution[Solution]
```cpp
// (a) Sort then scan — O(n log n) time, O(1) space (in-place sort)
int missingSort(vector<int> v) {
    sort(v.begin(), v.end());
    for (int i = 0; i < (int)v.size(); ++i)
        if (v[i] != i) return i;
    return v.size();
}

// (b) Math formula — O(n) time, O(1) space
// Sum of 0..n is n*(n+1)/2; subtract actual sum to find missing value
int missingMath(const vector<int>& v) {
    int n = v.size();
    int expected = n * (n + 1) / 2;
    int actual   = 0;
    for (int x : v) actual += x;
    return expected - actual;
}

// (c) XOR — O(n) time, O(1) space
// XOR all indices [0..n] with all values; duplicates cancel out
int missingXOR(const vector<int>& v) {
    int xorAll = 0;
    int n = v.size();
    for (int i = 0; i <= n; ++i) xorAll ^= i;
    for (int x : v)               xorAll ^= x;
    return xorAll;   // only the missing number remains
}
// missingMath({3,0,1}) → 2   missingXOR({9,6,4,2,3,5,7,0,1}) → 8
```

Math and XOR are both O(n) time and O(1) space — the optimal approaches. XOR is elegant: every number XOR'd with itself is 0, so only the unpaired value survives.
::::
:::

:::problem{difficulty="standard"}
P3 — Two Sum II (Sorted Array)

Given a *sorted* array and a target, return the 1-based indices of two numbers that sum to target. Solve it two ways: (a) two-pointer O(n), (b) binary search O(n log n). State the complexity of each.

::::solution[Solution]
```cpp
// (a) Two-pointer — O(n) time, O(1) space
vector<int> twoSumII_tp(const vector<int>& nums, int target) {
    int lo = 0, hi = (int)nums.size() - 1;
    while (lo < hi) {
        int s = nums[lo] + nums[hi];
        if      (s == target) return {lo+1, hi+1};
        else if (s <  target) ++lo;
        else                  --hi;
    }
    return {};
}

// (b) Binary search — O(n log n) time, O(1) space
vector<int> twoSumII_bs(const vector<int>& nums, int target) {
    int n = nums.size();
    for (int i = 0; i < n; ++i) {           // O(n) outer
        int complement = target - nums[i];
        int lo = i+1, hi = n-1;
        while (lo <= hi) {                  // O(log n) binary search
            int mid = lo + (hi-lo)/2;
            if      (nums[mid] == complement) return {i+1, mid+1};
            else if (nums[mid] <  complement) lo = mid+1;
            else                              hi = mid-1;
        }
    }
    return {};
}
// {2,7,11,15}, target=9 → {1,2}
```

Two-pointer wins here: O(n) vs O(n log n). We can use two-pointer because the array is sorted — the same trick that made Ch 6's pair-sum fast.
::::
:::

:::problem{difficulty="standard"}
P4 — Analyze a Recursive Function

Write the recurrence relation for the following function and determine its Big-O time complexity. Explain your reasoning.

```cpp
int sumArray(const vector<int>& v, int n) {
    if (n == 0) return 0;
    return v[n-1] + sumArray(v, n-1);
}
```

::::solution[Solution]
**Recurrence:** $T(n) = T(n-1) + O(1)$

Each call does O(1) work (one addition + one recursive call with n reduced by 1). Unrolling:

$T(n) = T(n-1) + 1 = T(n-2) + 2 = \ldots = T(0) + n = O(n)$

**Answer: O(n) time, O(n) space** (n stack frames, one per recursive call)
::::
:::

:::problem{difficulty="challenge"}
P5 — Optimize a Duplicate Checker

The following function checks if any integer appears twice in an array. It is currently O(n²). Rewrite it to be O(n) time and explain the trade-off.

```cpp
bool hasDuplicate_slow(const vector<int>& v) {
    for (int i = 0; i < (int)v.size(); ++i)
        for (int j = i+1; j < (int)v.size(); ++j)
            if (v[i] == v[j]) return true;
    return false;
}
```

::::solution[Solution]
```cpp
#include <unordered_set>
bool hasDuplicate_fast(const vector<int>& v) {
    unordered_set<int> seen;
    for (int x : v) {
        if (seen.count(x)) return true;  // already saw this value
        seen.insert(x);
    }
    return false;
}
// O(n) time — one pass; O(1) hash set lookup/insert on average
// O(n) space — hash set can grow to size n in the worst case
```

**Trade-off:** We spend O(n) extra space on the hash set to buy O(n) time instead of O(n²). This is the classic *time-space trade-off*: use memory to avoid recomputation. If memory is severely constrained, the O(n log n) sort-then-scan approach uses O(1) extra space at the cost of some runtime.
::::
:::

:::callout-tip
For each problem below, first write the naive solution and analyze its complexity, then optimize. The contrast between the two approaches is more valuable than the final answer alone.

| # | Problem | Difficulty | Analysis goal |
| --- | --- | --- | --- |
| 1 | [Two Sum](https://leetcode.com/problems/two-sum/) | Easy | O(n²) brute → O(n) hash map; articulate the trade-off |
| 268 | [Missing Number](https://leetcode.com/problems/missing-number/) | Easy | Compare sort O(n log n), math O(n), XOR O(n) — all O(1) space |
| 167 | [Two Sum II — Input Array Is Sorted](https://leetcode.com/problems/two-sum-ii-input-array-is-sorted/) | Medium | Two-pointer O(n) vs binary search O(n log n); why sorted enables O(n) |
:::
