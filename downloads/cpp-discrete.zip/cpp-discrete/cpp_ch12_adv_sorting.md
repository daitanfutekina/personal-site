---
title: "Chapter 12 — Advanced Sorting Algorithms"
source: "cpp_ch12_adv_sorting.html"
---

CSE 1384

DSA

# Chapter 12 — Advanced Sorting Algorithms

§12.1 – §12.7

Quicksort

Best/Avg: O(n log n)

Worst: O(n²)

Space: O(log n) · Unstable

Merge Sort

All cases: O(n log n)

Guaranteed — no bad pivots

Space: O(n) · Stable ✓

Shell Sort

Avg: O(n^1.3) – O(n^1.5)

Worst: O(n²) (bad gaps)

Space: O(1) · Unstable

Radix / Bucket Sort

O(nk) / O(n + k)

Non-comparison sorts

Space: O(n + k)

## §12.1 · Quicksort

Quicksort is the most widely used sorting algorithm in practice. It works by selecting a **pivot** element and **partitioning** the array into two halves: elements less than the pivot and elements greater than the pivot. Then it recursively sorts each half.

### Partition — the core operation

The Lomuto partition scheme: choose the last element as pivot, then walk a pointer `i` that tracks where the "less-than" region ends.

```cpp
// Partition v[lo..hi] around pivot = v[hi].
// Returns final index of pivot.
int partition(vector<int>& v, int lo, int hi) {
    int pivot = v[hi];
    int i = lo - 1;               // i = boundary of "less than" region

    for (int j = lo; j < hi; ++j) {
        if (v[j] <= pivot) {
            ++i;
            swap(v[i], v[j]);     // move small element into left region
        }
    }
    swap(v[i + 1], v[hi]);        // place pivot in its final position
    return i + 1;                 // return pivot's final index
}
```

Visual: partitioning `{3, 6, 8, 10, 1, 2, 1}` with pivot = 1 (last element):

1

1

1 ← pivot

3

6

8

10

After partition: pivot (1) is at its final sorted position; left side ≤ pivot; right side ≥ pivot. Recurse on each half.

```cpp
void quicksort(vector<int>& v, int lo, int hi) {
    if (lo >= hi) return;                   // base: 0 or 1 elements
    int pivotIdx = partition(v, lo, hi);
    quicksort(v, lo, pivotIdx - 1);         // sort left half
    quicksort(v, pivotIdx + 1, hi);         // sort right half
}

// Wrapper
void quicksort(vector<int>& v) {
    quicksort(v, 0, (int)v.size() - 1);
}
```

:::callout-pitfall
Worst case O(n²)

: if the pivot is always the smallest or largest element (e.g., sorting an already-sorted array with last-element pivot), every partition produces one sub-array of size n−1 and one of size 0. The fix is

random pivot selection

:

```cpp
// Randomized partition — avoids worst case on sorted/reverse-sorted input
int partitionRand(vector<int>& v, int lo, int hi) {
    int r = lo + rand() % (hi - lo + 1);
    swap(v[r], v[hi]);           // move random element to last position
    return partition(v, lo, hi); // then use standard partition
}
```

With random pivots, expected time is O(n log n) regardless of input order.
:::

### Step-by-step partition trace

Trace Lomuto partition on `{3, 6, 8, 10, 1, 2, 1}`, pivot = last element (1):

| j | v[j] | v[j] ≤ pivot? | i | Array state (| marks boundary) |
| --- | --- | --- | --- | --- |
| start | — | — | -1 | {3, 6, 8, 10, 1, 2, | 1←pivot} |
| 0 | 3 | No (3>1) | -1 | {3, 6, 8, 10, 1, 2, | 1←pivot} no swap |
| 1 | 6 | No | -1 | {3, 6, 8, 10, 1, 2, | 1←pivot} no swap |
| 2 | 8 | No | -1 | {3, 6, 8, 10, 1, 2, | 1←pivot} no swap |
| 3 | 10 | No | -1 | {3, 6, 8, 10, 1, 2, | 1←pivot} no swap |
| 4 | 1 | Yes (1≤1) | 0 | swap(v[0],v[4]) → {**1**, 6, 8, 10, 3, 2, | 1←pivot} |
| 5 | 2 | No (2>1) | 0 | {1, 6, 8, 10, 3, 2, | 1←pivot} no swap |
| end | — | swap pivot to i+1=1 | 0 | {1, **1**←pivot final, 8, 10, 3, 2, 6} |

Result: pivot (1) placed at index 1. Left subarray {1} ≤ pivot. Right subarray {8,10,3,2,6} ≥ pivot. Recurse on each.

:::callout-intuition
Think of

i

as a "fence" marking the right edge of the "≤ pivot" region. When we find an element ≤ pivot, we advance the fence and swap it inside. At the end, the pivot itself moves to fence+1 — its permanently correct sorted position.
:::

### Three-way partition (Dutch National Flag)

When the array contains many **duplicate** values, the standard two-way partition degrades. The **three-way (Dutch National Flag) partition** groups elements into three regions: < pivot, == pivot, > pivot. All equal elements are placed in one pass and never recurse into again.

```cpp
// Partition v[lo..hi] into [ <pivot | ==pivot | >pivot ]
// Returns {lt, gt}: indices bounding the == region
pair<int,int> threeWayPartition(vector<int>& v, int lo, int hi) {
    int pivot = v[lo];
    int lt = lo;      // v[lo..lt-1]  < pivot
    int gt = hi;      // v[gt+1..hi]  > pivot
    int i  = lo;      // v[lt..i-1]  == pivot, v[i..gt] unexplored
    while (i <= gt) {
        if      (v[i] < pivot) swap(v[lt++], v[i++]);
        else if (v[i] > pivot) swap(v[i],    v[gt--]);
        else                   ++i;
    }
    return {lt, gt};
}

void quicksort3(vector<int>& v, int lo, int hi) {
    if (lo >= hi) return;
    auto [lt, gt] = threeWayPartition(v, lo, hi);
    quicksort3(v, lo,   lt - 1);  // sort elements < pivot
    quicksort3(v, gt+1, hi    );  // sort elements > pivot
    // elements == pivot are already in place — skip them
}
```

:::callout-connect
The three-way partition is the algorithm behind LeetCode #75 (Sort Colors / Dutch National Flag). It reduces quicksort's complexity to O(n) when all elements are equal, and O(n log n) with many duplicates — far better than two-way partition's O(n²) on all-same arrays.
:::

## §12.2 · Merge Sort

Merge sort follows the **divide and conquer** paradigm: split the array in half, recursively sort each half, then **merge** the two sorted halves back together. Unlike quicksort it is **guaranteed O(n log n)** in all cases and is stable.

```cpp
// Merge two sorted halves: v[lo..mid] and v[mid+1..hi]
void merge(vector<int>& v, int lo, int mid, int hi) {
    vector<int> tmp(hi - lo + 1);  // temporary buffer

    int i = lo, j = mid + 1, k = 0;
    while (i <= mid && j <= hi) {
        if (v[i] <= v[j]) tmp[k++] = v[i++];   // stable: <= keeps equal elements in order
        else               tmp[k++] = v[j++];
    }
    while (i <= mid) tmp[k++] = v[i++];         // flush left remainder
    while (j <= hi)  tmp[k++] = v[j++];         // flush right remainder

    for (int x = 0; x < k; ++x) v[lo + x] = tmp[x];  // copy back
}

void mergeSort(vector<int>& v, int lo, int hi) {
    if (lo >= hi) return;                        // base: single element
    int mid = lo + (hi - lo) / 2;
    mergeSort(v, lo, mid);                       // sort left half
    mergeSort(v, mid + 1, hi);                   // sort right half
    merge(v, lo, mid, hi);                       // merge sorted halves
}

void mergeSort(vector<int>& v) { mergeSort(v, 0, (int)v.size()-1); }
```

Call tree for `{5, 3, 8, 1, 4, 2}`:

```

mergeSort([5,3,8,1,4,2])
├─ mergeSort([5,3,8])
│   ├─ mergeSort([5]) ← base
│   ├─ mergeSort([3,8])
│   │   ├─ mergeSort([3]) ← base
│   │   ├─ mergeSort([8]) ← base
│   │   └─ merge → [3,8]
│   └─ merge([5],[3,8]) → [3,5,8]
├─ mergeSort([1,4,2])
│   ├─ mergeSort([1]) ← base
│   ├─ mergeSort([4,2])
│   │   ├─ mergeSort([4]) ← base
│   │   ├─ mergeSort([2]) ← base
│   │   └─ merge → [2,4]
│   └─ merge([1],[2,4]) → [1,2,4]
└─ merge([3,5,8],[1,2,4]) → [1,2,3,4,5,8] ✓
```

:::callout-key
Merge sort splits perfectly in half at every level → tree depth = log₂n. Each level does O(n) total merge work → T(n) = O(n log n)

regardless

of input order. The cost is O(n) extra space for the merge buffer. When stability or guaranteed performance matters more than space, choose merge sort over quicksort.
:::

## §12.3 · Shell Sort

Shell sort is a generalization of insertion sort. Instead of comparing adjacent elements, it first compares elements separated by a large **gap**, which moves elements quickly toward their final positions. The gap shrinks each pass until it reaches 1, at which point it becomes a standard insertion sort — but on a nearly-sorted array (fast).

```cpp
void shellSort(vector<int>& v) {
    int n = v.size();
    // Knuth's gap sequence: 1, 4, 13, 40, 121, ...  (h = 3h+1)
    int gap = 1;
    while (gap < n / 3) gap = 3 * gap + 1;

    while (gap >= 1) {
        // Insertion sort with step size 'gap'
        for (int i = gap; i < n; ++i) {
            int key = v[i], j = i;
            while (j >= gap && v[j - gap] > key) {
                v[j] = v[j - gap];
                j -= gap;
            }
            v[j] = key;
        }
        gap /= 3;   // shrink gap
    }
}
```

:::callout-intuition
Imagine you're sorting books on a shelf. Shell sort first compares books 10 positions apart, then 4 apart, then 1 apart. Each pass makes the shelf "more ordered," so by the time you do adjacent comparisons everything is close to its final spot — vastly fewer swaps than starting insertion sort on the fully unsorted data.
:::

## §12.4 · Radix Sort

Radix sort is a **non-comparison sort**: it sorts integers by processing one digit at a time, using a stable counting sort on each digit position. Because it never compares elements, it breaks the O(n log n) comparison-sort lower bound — achieving O(nk) where k is the number of digits.

```cpp
// Counting sort on digit at 'exp' position (1, 10, 100, ...)
void countingSort(vector<int>& v, int exp) {
    int n = v.size();
    vector<int> output(n), count(10, 0);

    for (int x : v) ++count[(x / exp) % 10];        // count digit frequencies
    for (int i = 1; i < 10; ++i) count[i] += count[i-1];  // cumulative

    // Fill output right-to-left to keep stable sort property
    for (int i = n - 1; i >= 0; --i) {
        int digit = (v[i] / exp) % 10;
        output[--count[digit]] = v[i];
    }
    v = output;
}

void radixSort(vector<int>& v) {
    int maxVal = *max_element(v.begin(), v.end());
    for (int exp = 1; maxVal / exp > 0; exp *= 10)
        countingSort(v, exp);
}
// radixSort({170,45,75,90,802,24,2,66}) → {2,24,45,66,75,90,170,802}
```

| Pass (digit) | Sort on units (exp=1) | Sort on tens (exp=10) | Sort on hundreds (exp=100) |
| --- | --- | --- | --- |
| Array | {170,45,75,90,802,24,2,66} | {170,90,802,2,24,45,75,66} | {2,24,45,66,75,90,170,802} |
| Key digit | 0,5,5,0,2,4,2,6 | 7,9,0,0,2,4,7,6 | 1,0,0,0,0,0,1,8 |

## §12.5 · Bucket Sort

Bucket sort distributes elements into a fixed number of **buckets** based on their value range, sorts each bucket individually (usually with insertion sort), then concatenates the buckets. Best for uniformly distributed floating-point data in [0, 1).

```cpp
void bucketSort(vector<double>& v) {
    int n = v.size();
    vector<vector<double>> buckets(n);

    // Distribute: element x goes into bucket floor(x * n)
    for (double x : v)
        buckets[(int)(x * n)].push_back(x);

    // Sort each bucket (insertion sort — small buckets are fast)
    for (auto& b : buckets)
        sort(b.begin(), b.end());

    // Concatenate
    int idx = 0;
    for (auto& b : buckets)
        for (double x : b) v[idx++] = x;
}
// Input: {0.78, 0.17, 0.39, 0.26, 0.72, 0.94, 0.21, 0.12, 0.23, 0.68}
// → {0.12, 0.17, 0.21, 0.23, 0.26, 0.39, 0.68, 0.72, 0.78, 0.94}
```

## §12.6 · Quickselect

**Quickselect** finds the k-th smallest element in an unsorted array in **O(n) average time** — without fully sorting. It uses the same partition step as quicksort but only recurses into the side that contains the k-th element.

```cpp
// Returns the k-th smallest element (0-indexed) in v[lo..hi]
int quickselect(vector<int>& v, int lo, int hi, int k) {
    if (lo == hi) return v[lo];

    // Random pivot for O(n) expected time
    int r = lo + rand() % (hi - lo + 1);
    swap(v[r], v[hi]);
    int pivotIdx = partition(v, lo, hi);   // reuse partition from quicksort

    if      (k == pivotIdx) return v[pivotIdx];   // pivot IS the answer
    else if (k <  pivotIdx) return quickselect(v, lo, pivotIdx - 1, k);
    else                    return quickselect(v, pivotIdx + 1, hi, k);
}

int kthSmallest(vector<int> v, int k) {   // pass by value — may be modified
    return quickselect(v, 0, (int)v.size()-1, k-1);  // convert 1-indexed to 0-indexed
}
// kthSmallest({3,2,1,5,6,4}, 2) → 2  (2nd smallest)
```

:::callout-key
Quickselect is

O(n) average, O(n²) worst case

. Using random pivots makes the worst case extremely rare. The key insight: after each partition, the pivot is in its final sorted position. If that position equals k, we're done. Otherwise we recurse into

only one

side — unlike quicksort which recurses into both.
:::

## §12.7 · Overview — Choosing a Sorting Algorithm

| Algorithm | Best | Average | Worst | Space | Stable | Use when |
| --- | --- | --- | --- | --- | --- | --- |
| Quicksort | O(n log n) | O(n log n) | O(n²) | O(log n) | No | General purpose, cache-friendly, large random data |
| Merge sort | O(n log n) | O(n log n) | O(n log n) | O(n) | Yes | Need guaranteed time, need stable sort, sorting linked lists |
| Heap sort | O(n log n) | O(n log n) | O(n log n) | O(1) | No | Need O(1) space + O(n log n) guarantee |
| Shell sort | O(n log n) | O(n^1.3) | O(n²) | O(1) | No | Medium-sized data, embedded systems (no recursion) |
| Radix sort | O(nk) | O(nk) | O(nk) | O(n+k) | Yes | Integers with bounded digit count; large n |
| Bucket sort | O(n+k) | O(n+k) | O(n²) | O(n+k) | Yes | Uniform floating-point data in known range |
| Counting sort | O(n+k) | O(n+k) | O(n+k) | O(k) | Yes | Small integer range k; e.g., sort grades 0–100 |
| std::sort | O(n log n) | O(n log n) | O(n log n) | O(log n) | No | 99% of real-world sorting; introsort hybrid |

:::callout-connect
std::sort

in most implementations is

introsort

: quicksort by default, switches to heapsort if recursion depth exceeds 2 log n (preventing O(n²) worst case), and uses insertion sort for small sub-arrays (n ≤ ~16). It combines the best properties of all three. This is why "just use std::sort" is almost always the right answer in production code.
:::

:::summary
### Chapter 12 — Key Takeaways

- **Quicksort**: O(n log n) average via partitioning. Use random pivot to avoid O(n²) worst case. Three-way partition handles duplicates efficiently.
- **Merge sort**: guaranteed O(n log n) all cases. Stable. Costs O(n) extra space. Best choice when stability is required or sorting linked lists.
- **Shell sort**: in-place improvement over insertion sort; no recursion; practical for embedded systems and medium datasets.
- **Radix sort / Bucket sort**: break the O(n log n) barrier by exploiting digit/range structure instead of comparing elements. Linear time but require bounded keys.
- **Quickselect**: finds k-th smallest in O(n) average — use instead of sorting when you only need one order statistic.
- `std::sort` is introsort (quicksort + heapsort + insertion sort hybrid) — O(n log n) guaranteed, cache-efficient, use it in production.
- Divide-and-conquer recurrence $T(n) = 2T(n/2) + O(n)$ → O(n log n). The "n" term comes from the merge/partition work at each level.
:::

### Practice Problems

:::problem{difficulty="standard"}
P1 — Sort Colors (Dutch National Flag)

Given an array with only values 0, 1, and 2, sort it in-place so all 0s come first, then 1s, then 2s. Do it in one pass with O(1) space. This is the Dutch National Flag problem.

::::solution[Solution]
```cpp
void sortColors(vector<int>& v) {
    int lo = 0, mid = 0, hi = (int)v.size() - 1;
    while (mid <= hi) {
        if      (v[mid] == 0) swap(v[lo++], v[mid++]);
        else if (v[mid] == 1) ++mid;
        else                  swap(v[mid], v[hi--]);
    }
}
// {2,0,2,1,1,0} → {0,0,1,1,2,2}
```

Three-pointer invariant: v[0..lo-1]=0, v[lo..mid-1]=1, v[hi+1..n-1]=2, v[mid..hi] unexplored. When mid sees a 2, swap with hi and shrink hi — don't advance mid (the swapped element needs checking).
::::
:::

:::problem{difficulty="standard"}
P2 — Merge Intervals

Given a list of intervals `{start, end}`, merge all overlapping intervals and return the result. Example: `{{1,3},{2,6},{8,10},{15,18}}` → `{{1,6},{8,10},{15,18}}`.

::::solution[Solution]
```cpp
vector<pair<int,int>> mergeIntervals(vector<pair<int,int>> ivs) {
    if (ivs.empty()) return {};
    sort(ivs.begin(), ivs.end());          // sort by start time

    vector<pair<int,int>> result;
    result.push_back(ivs[0]);

    for (int i = 1; i < (int)ivs.size(); ++i) {
        if (ivs[i].first <= result.back().second)   // overlaps
            result.back().second = max(result.back().second, ivs[i].second);
        else
            result.push_back(ivs[i]);               // no overlap — new interval
    }
    return result;
}
```

Sort by start → scan left to right. An interval overlaps the last merged interval iff its start ≤ merged end. Extend the end if needed; otherwise push a new interval. O(n log n) from sort, O(n) scan.
::::
:::

:::problem{difficulty="standard"}
P3 — Kth Largest Element (Quickselect)

Find the k-th largest element in an unsorted array in O(n) average time. Example: `{3,2,1,5,6,4}`, k=2 → 5.

::::solution[Solution]
```cpp
int kthLargest(vector<int>& v, int k) {
    // k-th largest = (n-k)-th smallest (0-indexed)
    int target = (int)v.size() - k;
    int lo = 0, hi = (int)v.size() - 1;
    while (lo < hi) {
        int r = lo + rand() % (hi - lo + 1);
        swap(v[r], v[hi]);
        int p = partition(v, lo, hi);
        if      (p == target) break;
        else if (p <  target) lo = p + 1;
        else                  hi = p - 1;
    }
    return v[target];
}
// Reuse the partition() function from §12.1
```
::::
:::

:::problem{difficulty="challenge"}
P4 — Sort a Linked List (Merge Sort)

Sort a singly linked list in O(n log n) time and O(log n) space. Quicksort is not ideal for linked lists (no random access); use merge sort with the fast/slow pointer split.

::::solution[Solution]
```cpp
struct Node { int val; Node* next; Node(int v):val(v),next(nullptr){} };

// Find mid using slow/fast; split list in two
Node* getMid(Node* head) {
    Node* slow = head, *fast = head->next;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }
    return slow;  // slow is the last node of left half
}

// Merge two sorted lists
Node* merge(Node* l1, Node* l2) {
    Node dummy(0); Node* tail = &dummy;
    while (l1 && l2) {
        if (l1->val <= l2->val) { tail->next = l1; l1 = l1->next; }
        else                      { tail->next = l2; l2 = l2->next; }
        tail = tail->next;
    }
    tail->next = l1 ? l1 : l2;
    return dummy.next;
}

Node* sortList(Node* head) {
    if (!head || !head->next) return head;  // base: 0 or 1 node
    Node* mid  = getMid(head);
    Node* right = mid->next;
    mid->next = nullptr;                    // split list
    return merge(sortList(head), sortList(right));
}
```

Linked list merge sort: split at midpoint (slow/fast pointers), sort each half recursively, merge. No random access needed. O(n log n) time, O(log n) space (recursion depth).
::::
:::

:::callout-tip
::::problem{difficulty="standard"}
P5 — Trace Merge Sort

Manually trace merge sort on the array `{9, 4, 7, 2, 6, 1}`. Show the recursive split tree and the merge steps in order. What are the time and space complexities?

:::::solution[Solution]
**Split tree:**

```

mergeSort([9,4,7,2,6,1])
├─ mergeSort([9,4,7])
│   ├─ mergeSort([9]) → [9]
│   ├─ mergeSort([4,7])
│   │   ├─ mergeSort([4]) → [4]
│   │   ├─ mergeSort([7]) → [7]
│   │   └─ merge([4],[7]) → [4,7]
│   └─ merge([9],[4,7]) → [4,7,9]
├─ mergeSort([2,6,1])
│   ├─ mergeSort([2]) → [2]
│   ├─ mergeSort([6,1])
│   │   ├─ mergeSort([6]) → [6]
│   │   ├─ mergeSort([1]) → [1]
│   │   └─ merge([6],[1]) → [1,6]
│   └─ merge([2],[1,6]) → [1,2,6]
└─ merge([4,7,9],[1,2,6]) → [1,2,4,6,7,9] ✓
```

**Final merge step — merge([4,7,9],[1,2,6]):**

| i (left) | j (right) | Append | Result so far |
| --- | --- | --- | --- |
| 4 | 1 | 1 (right smaller) | [1] |
| 4 | 2 | 2 | [1,2] |
| 4 | 6 | 4 (left smaller) | [1,2,4] |
| 7 | 6 | 6 | [1,2,4,6] |
| 7 | done | flush left: 7,9 | [1,2,4,6,7,9] ✓ |

**Complexity:** Time O(n log n) all cases. Space O(n) for merge buffers. For n=6: depth=3, each level merges 6 elements → 18 total comparisons (versus bubble sort's up to 15 for nearly-sorted, up to 5²/2=12.5 average for small n, but O(n²) worst).
:::::
::::

::::problem{difficulty="standard"}
P6 — Worst-Case Quicksort Avoidance

Explain why choosing the last element as pivot causes O(n²) performance on a sorted array. Then show two strategies that avoid this worst case and describe the tradeoffs.

:::::solution[Solution]
**Why sorted input breaks last-element pivot:**

 On `{1,2,3,4,5}` with pivot = last element (5): partition produces left=[1,2,3,4], right=[].

 Each call reduces n by 1 → n recursion levels × O(n) partition work each = O(n²).

 The recurrence is T(n) = T(n-1) + O(n), solving to O(n²).

**Strategy 1 — Random pivot:** Pick a uniformly random element from [lo, hi] and swap it to position hi before partitioning. Expected time O(n log n) on any input — adversarial inputs can't be crafted without knowing the random choices. Cost: a call to rand() per partition.

**Strategy 2 — Median-of-three:** Choose the median of v[lo], v[mid], v[hi] as pivot. Eliminates worst case for already-sorted and reverse-sorted inputs (the most common pathological cases in practice). Slightly better than random for real-world data because it tends to pick near-median pivots. No random number generator needed. Cost: 2 extra comparisons per partition.

**What std::sort does:** Introsort — starts as quicksort with median-of-three, switches to heapsort if recursion depth exceeds 2·log₂(n) (guaranteeing O(n log n) worst case), and uses insertion sort for subarrays of size ≤ ~16 (lower overhead for tiny arrays).
:::::
::::

::::problem{difficulty="standard"}
P7 — When to Use Each Sort

For each scenario, choose the best sorting algorithm and explain why: (a) Sorting 10 million 32-bit integers where values are in range [0, 10000]. (b) Sorting 50 employee records by hire date, preserving alphabetical tie-breaking. (c) Sorting a nearly-sorted array of 100,000 elements. (d) Finding the median of 1 million random integers without full sorting.

:::::solution[Solution]
- **(a) Radix sort** — 10M integers in [0,10000] means k=5 digits (base 10). Radix sort runs O(5n) = O(n) vs O(n log n) for comparison sorts. With 10M elements, this is ~50M vs ~230M operations.
- **(b) std::stable\_sort** — Employee records are objects (comparison sort required, not radix). Stability guarantees alphabetical tie-breaking is preserved from the initial ordering. Regular std::sort may break ties arbitrarily.
- **(c) Insertion sort or Timsort** — Insertion sort is O(n) on nearly-sorted data (few inversions). Timsort (used in Python/Java) detects and merges existing sorted runs, excelling on partially-sorted data. std::sort will still do O(n log n) but has higher constant for this case.
- **(d) nth\_element** — std::nth\_element finds the k-th smallest element in O(n) average time without fully sorting the array. For median: k = n/2. No sort needed at all. Alternatively, maintain two heaps (max-heap of lower half, min-heap of upper half) for a streaming solution.
:::::
::::

| # | Problem | Difficulty | Algorithm |
| --- | --- | --- | --- |
| 912 | [Sort an Array](https://leetcode.com/problems/sort-an-array/) | Medium | Implement merge sort or quicksort from scratch |
| 75 | [Sort Colors](https://leetcode.com/problems/sort-colors/) | Medium | Dutch National Flag — three-way partition, one pass |
| 56 | [Merge Intervals](https://leetcode.com/problems/merge-intervals/) | Medium | Sort + linear scan merge |
| 148 | [Sort List](https://leetcode.com/problems/sort-list/) | Medium | Merge sort on linked list; split with slow/fast pointers |
:::
