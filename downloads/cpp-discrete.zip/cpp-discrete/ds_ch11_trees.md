---
title: "DS–11: Trees"
source: "ds_ch11_trees.html"
---

CSE 2813

# DS–11: Trees

§11.1 – §11.8

## §11.1 Tree Definitions and Properties

:::definition[Definition]
Tree

A **tree** is a connected, acyclic undirected graph. A **rooted tree** designates one vertex as the root. Key terminology:

- **Root:** topmost node (no parent)
- **Leaf:** node with no children
- **Internal node:** non-leaf node
- **Height:** length of the longest root-to-leaf path
- **Depth of node $v$:** length of path from root to $v$
- **Subtree rooted at $v$:** $v$ and all its descendants
:::

:::theorem[Theorem]
Tree Properties

For a tree with $n$ vertices: (1) exactly $n-1$ edges, (2) any two vertices are connected by exactly one path, (3) removing any edge disconnects the tree, (4) adding any edge creates exactly one cycle.
:::

## §11.2 Binary Trees

:::definition[Definition]
Binary Tree

A **binary tree** is a rooted tree where each node has at most 2 children (left and right). A **full** binary tree has every node with 0 or 2 children. A **complete** binary tree has all levels full except possibly the last, which is filled left-to-right. A **perfect** binary tree has all leaves at the same level.
:::

```cpp
struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};
```

:::theorem[Theorem]
Binary Tree Properties

A perfect binary tree of height $h$: has $2^h-1$ internal nodes, $2^h$ leaves, and $2^{h+1}-1$ total nodes. A binary tree of height $h$ has at most $2^{h+1}-1$ nodes. A complete binary tree with $n$ nodes has height $\lfloor\log_2 n\rfloor$.
:::

## §11.3 Tree Traversals

Three canonical DFS traversals differ only in *when* the root is processed relative to its subtrees:

```cpp
void preorder(TreeNode* root) {   // Root → Left → Right
    if (!root) return;
    cout << root->val << " ";
    preorder(root->left);
    preorder(root->right);
}

void inorder(TreeNode* root) {    // Left → Root → Right
    if (!root) return;
    inorder(root->left);
    cout << root->val << " ";
    inorder(root->right);
}

void postorder(TreeNode* root) {  // Left → Right → Root
    if (!root) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->val << " ";
}

// Level-order (BFS)
void levelorder(TreeNode* root) {
    if (!root) return;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        TreeNode* node = q.front(); q.pop();
        cout << node->val << " ";
        if (node->left)  q.push(node->left);
        if (node->right) q.push(node->right);
    }
}
```

Example 11.1 — Traversal Orders

For the BST with root 4, left subtree {2,1,3}, right subtree {6,5,7}: list all four traversal orders.

:::answer[Solution]
Preorder

(root first): 4,2,1,3,6,5,7

Inorder

(left–root–right): 1,2,3,4,5,6,7 ←

sorted order for BST!

Postorder

(children first): 1,3,2,5,7,6,4

Level-order

: 4,2,6,1,3,5,7
:::

## §11.4 Binary Search Trees (BST)

:::definition[Definition]
BST Property

For every node $v$ in a BST: all keys in the left subtree are $<v.\text{key}$, all keys in the right subtree are $>v.\text{key}$. This guarantees that inorder traversal yields keys in sorted order.
:::

| Operation | Average | Worst (unbalanced) |
| --- | --- | --- |
| Search | $O(\log n)$ | $O(n)$ |
| Insert | $O(\log n)$ | $O(n)$ |
| Delete | $O(\log n)$ | $O(n)$ |

```cpp
TreeNode* insert(TreeNode* root, int val) {
    if (!root) return new TreeNode(val);
    if (val < root->val)      root->left  = insert(root->left,  val);
    else if (val > root->val) root->right = insert(root->right, val);
    return root;
}

bool search(TreeNode* root, int val) {
    if (!root) return false;
    if (val == root->val) return true;
    if (val <  root->val) return search(root->left,  val);
    return                       search(root->right, val);
}
```

:::callout-pitfall[Common Pitfall]
Inserting sorted data into an unbalanced BST degenerates it into a linked list ($O(n)$ operations). Always use a balanced BST (AVL, Red-Black) in production code, or just use

std::map

/

std::set

.
:::

## §11.5 AVL Trees

:::definition[Definition]
AVL Tree

A self-balancing BST where the **balance factor** $= h(\text{left}) - h(\text{right}) \in \{-1,0,1\}$ for every node. Insertions and deletions that violate this trigger **rotations** to restore balance.
:::

### The Four Rotation Cases

| Imbalance | Fix |
| --- | --- |
| Left-Left (LL) | Right rotation at unbalanced node |
| Right-Right (RR) | Left rotation at unbalanced node |
| Left-Right (LR) | Left rotation on left child, then right rotation |
| Right-Left (RL) | Right rotation on right child, then left rotation |

All operations (search, insert, delete) are guaranteed $O(\log n)$ since height $\le 1.44\log_2(n+2) - 0.33$.

:::callout-connect[Connection → C++ STL]
std::map

and

std::set

in C++ are typically implemented as red-black trees (a different self-balancing BST). Both guarantee $O(\log n)$ operations. AVL trees have slightly faster lookups; red-black trees have faster insertions/deletions.
:::

## §11.6 Heaps and Heap Sort

:::definition[Definition]
Binary Heap

A **max-heap** is a complete binary tree where every parent is $\ge$ its children. A **min-heap** has every parent $\le$ children. Implemented efficiently as an array: node $i$ has children at $2i+1$ and $2i+2$, parent at $\lfloor(i-1)/2\rfloor$.
:::

| Operation | Time |
| --- | --- |
| Find max/min | $O(1)$ |
| Insert | $O(\log n)$ |
| Extract max/min | $O(\log n)$ |
| Build heap from array | $O(n)$ |

```cpp
// Heapify down (max-heap) — O(log n)
void heapifyDown(vector<int>& h, int i, int n) {
    int largest = i, l = 2*i+1, r = 2*i+2;
    if (l < n && h[l] > h[largest]) largest = l;
    if (r < n && h[r] > h[largest]) largest = r;
    if (largest != i) {
        swap(h[i], h[largest]);
        heapifyDown(h, largest, n);
    }
}

// Build heap in O(n) — start from last internal node
void buildHeap(vector<int>& h) {
    for (int i = h.size()/2 - 1; i >= 0; i--)
        heapifyDown(h, i, h.size());
}

// Heap sort — O(n log n), in-place
void heapSort(vector<int>& a) {
    buildHeap(a);
    for (int n = a.size()-1; n > 0; n--) {
        swap(a[0], a[n]);        // move max to end
        heapifyDown(a, 0, n);   // restore heap on remaining
    }
}
```

## §11.7 Expression Trees

An **expression tree** represents an arithmetic expression: internal nodes are operators, leaves are operands. The three traversals give the three standard expression forms:

| Traversal | Gives | Example for $(3+4)\times2$ |
| --- | --- | --- |
| Inorder | Infix | $3+4\times2$ (needs parentheses) |
| Preorder | Prefix (Polish) | $\times\ +\ 3\ 4\ 2$ |
| Postorder | Postfix (RPN) | $3\ 4\ +\ 2\ \times$ |

:::callout-connect[Connection → Compilers]
Compilers build an Abstract Syntax Tree (AST) — a generalization of expression trees — for all code constructs. Code generation walks the AST in postorder: evaluate children before the parent operator.
:::

## §11.8 Other Tree Types

### B-Trees

A **B-tree of order $m$** is a balanced tree where each node has between $\lceil m/2\rceil$ and $m$ children. Used in databases and file systems (disk I/O minimization). All leaves at the same depth. Operations: $O(\log n)$.

### Tries (Prefix Trees)

A tree where each edge is labeled with a character. A path from root to a marked node represents a string. Used for: autocomplete, spell checkers, IP routing (Patricia trie).

```cpp
struct TrieNode {
    unordered_map<char, TrieNode*> children;
    bool isEnd = false;
};

void insert(TrieNode* root, const string& word) {
    TrieNode* cur = root;
    for (char c : word) {
        if (!cur->children.count(c))
            cur->children[c] = new TrieNode();
        cur = cur->children[c];
    }
    cur->isEnd = true;
}

bool search(TrieNode* root, const string& word) {
    TrieNode* cur = root;
    for (char c : word) {
        if (!cur->children.count(c)) return false;
        cur = cur->children[c];
    }
    return cur->isEnd;
}
```

### Segment Trees

A **segment tree** stores aggregates (sum, min, max) over intervals of an array, supporting range queries and point updates in $O(\log n)$. A segment tree on $n$ elements uses $O(4n)$ space.

:::summary
### Chapter 11 Summary

- **Tree:** connected acyclic graph; $n$ vertices $\Rightarrow$ $n-1$ edges.
- **Binary tree:** each node $\le$ 2 children; height $h$ $\Rightarrow$ at most $2^{h+1}-1$ nodes; complete $\Rightarrow$ height $\lfloor\log_2 n\rfloor$.
- **Traversals:** preorder (root–L–R), inorder (L–root–R, gives sorted BST), postorder (L–R–root), level-order (BFS).
- **BST:** $O(\log n)$ average search/insert/delete; $O(n)$ worst (unbalanced).
- **AVL tree:** balanced BST; balance factor $\in\{-1,0,1\}$; 4 rotation cases; guaranteed $O(\log n)$.
- **Heap:** complete binary tree with heap property; $O(1)$ peek, $O(\log n)$ insert/extract, $O(n)$ build; array representation.
- **Expression trees:** inorder=infix, preorder=prefix, postorder=postfix (RPN).
- **B-trees:** disk-optimized; **Tries:** string prefix matching; **Segment trees:** range queries $O(\log n)$.
:::

## Practice Problems

:::problem[Problem 1]{difficulty="easy"}
Problem 1

Insert the sequence 5, 3, 7, 1, 4, 6, 8 into an initially empty BST. Draw the resulting tree and give its inorder traversal.

::::solution[Solution]
Root=5. 3<5→left. 7>5→right. 1<5<3→3's left. 4<5,>3→3's right. 6<7→7's left. 8>7→7's right.

```
           5
          / \
         3   7
        / \ / \
       1  4 6  8
```

Inorder:

1, 3, 4, 5, 6, 7, 8

(sorted ✓).
::::
:::

:::problem[Problem 2]{difficulty="easy"}
Problem 2

Compute the height and number of nodes in a perfect binary tree with 4 levels (height = 3). Verify using the formula.

::::solution[Solution]
Height $h=3$. Nodes $= 2^{h+1}-1 = 2^4-1 = \mathbf{15}$. Leaves $= 2^3 = 8$. Internal nodes $= 7$. ✓
::::
:::

:::problem[Problem 3]{difficulty="standard"}
Problem 3

Build a max-heap from the array [3, 1, 6, 5, 2, 4]. Show the array after `buildHeap`.

::::solution[Solution]
Start heapifying from index 2 down to 0.

i=2: compare 6 with children (none large enough): [3,1,6,5,2,4].

i=1: compare 1 with children 5,2: swap with 5: [3,5,6,1,2,4].

i=0: compare 3 with children 5,6: swap with 6: [6,5,3,1,2,4].

Heap:

[6, 5, 3, 1, 2, 4]

. Verify: parent≥children at every index. ✓
::::
:::

:::problem[Problem 4]{difficulty="standard"}
Problem 4

Write the expression $((a+b)\times(c-d))/e$ as an expression tree. Give its postfix (postorder) form.

::::solution[Solution]
Root: $/$ with children: $\times$ (left) and $e$ (right). $\times$ has children $+$ and $-$. $+$ has children $a,b$; $-$ has children $c,d$.

Postorder:

a b + c d - × e /
::::
:::

:::problem[Problem 5]{difficulty="standard"}
Problem 5

Implement search in a Trie for the word "cat" given the trie contains "cat", "car", "card", "care", "dog".

::::solution[Solution]
Follow path: root→c→a→t. At 't', check

isEnd==true

. Result:

true

. If we searched "ca": path c→a exists but

isEnd==false

at 'a', so false. If we searched "cats": c→a→t exists but t has no child 's', so false.
::::
:::

:::problem[Problem 6]{difficulty="challenge"}
Problem 6

Prove that a binary tree with $n$ leaves has exactly $n-1$ internal nodes, if every internal node has exactly 2 children (full binary tree).

::::solution[Solution]
Let $I$ = internal nodes, $L$ = leaves. Count edges two ways: (1) each non-root node has exactly 1 parent edge → $I+L-1$ edges total. (2) each internal node contributes exactly 2 edges downward → $2I$ edges total. So $2I = I+L-1$, giving $I = L-1$. $\square$
::::
:::

## LeetCode Practice

| # | Title | Difficulty | Concept |
| --- | --- | --- | --- |
| 104 | [Maximum Depth of Binary Tree](https://leetcode.com/problems/maximum-depth-of-binary-tree/) | Easy | Tree height, recursion |
| 98 | [Validate Binary Search Tree](https://leetcode.com/problems/validate-binary-search-tree/) | Medium | BST property, inorder |
| 102 | [Binary Tree Level Order Traversal](https://leetcode.com/problems/binary-tree-level-order-traversal/) | Medium | Level-order BFS |
| 208 | [Implement Trie (Prefix Tree)](https://leetcode.com/problems/implement-trie-prefix-tree/) | Medium | Trie insert/search |
| 215 | [Kth Largest Element in an Array](https://leetcode.com/problems/kth-largest-element-in-an-array/) | Medium | Heap / quickselect |
