---
title: "DS–12: Discrete Probability"
source: "ds_ch12_probability.html"
---

CSE 2813

# DS–12: Discrete Probability

§12.1 – §12.8

:::callout-tip[What You'll Learn]
Probability gives CS a language for reasoning about

uncertainty

. Randomized algorithms, hashing, machine learning, cryptography, and algorithm analysis all rely on exactly the tools in this chapter: computing event probabilities, conditioning on partial information (Bayes), modeling outcomes as random variables, and finding their expected values.
:::

## §12.1 Probability of an Event

:::callout-intuition
Before we formalize anything: a

probability

is just a number between 0 and 1 that captures how likely an outcome is. The formal machinery — sample spaces, events, probability functions — exists so we can compute probabilities precisely and prove things about them.
:::

:::definition[Definition 12.1 — Sample Space and Event]
Sample Space & Events

The **sample space** $S$ of an experiment is the set of all possible outcomes. An **event** is any subset $E \subseteq S$.

A **probability function** $P$ assigns to each event $E$ a value $P(E) \in [0,1]$ satisfying:

$$
P(S) = 1 \qquad P(E_1 \cup E_2) = P(E_1) + P(E_2) \text{ when } E_1 \cap E_2 = \emptyset
$$
:::

:::definition[Definition 12.2 — Uniform Probability Space]
Uniform Distribution

When all outcomes in $S$ are equally likely, we have a **uniform probability space** and:

$$
P(E) = \frac{|E|}{|S|}
$$

This is counting in disguise — the probability equals the fraction of outcomes in the event.
:::

### Worked Examples

Example 12.1 — Standard Die

A fair six-sided die is rolled. What is the probability of rolling a prime number?

:::answer[Answer]
$P = 1/2$
:::

:::answer
Work

Sample space: $S = \{1, 2, 3, 4, 5, 6\}$, so $|S| = 6$.

Primes in $S$: $E = \{2, 3, 5\}$, so $|E| = 3$.

$$
P(E) = \frac{|E|}{|S|} = \frac{3}{6} = \frac{1}{2}
$$
:::

Example 12.2 — Drawing a Card

One card is drawn from a standard 52-card deck. Find the probability it is (a) a heart, (b) a face card (J, Q, K), (c) a heart face card.

:::answer[Answers]
(a) $13/52 = 1/4$    (b) $12/52 = 3/13$    (c) $3/52$
:::

:::answer
Work

**(a)** 13 hearts out of 52 cards: $P = 13/52 = 1/4$.

**(b)** 4 suits × 3 face cards = 12 face cards: $P = 12/52 = 3/13$.

**(c)** Hearts that are face cards: $\{J♥, Q♥, K♥\}$ = 3 cards: $P = 3/52$.
:::

Example 12.3 — Two Dice

Two fair dice are rolled. What is the probability the sum equals 7?

:::answer[Answer]
$P = 6/36 = 1/6$
:::

:::answer
Work

Sample space: all ordered pairs $(i, j)$ with $i, j \in \{1,\ldots,6\}$, so $|S| = 36$.

Pairs summing to 7: $(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)$ — six pairs.

$$
P(\text{sum}=7) = \frac{6}{36} = \frac{1}{6}
$$
:::

:::callout-pitfall[Common Pitfall]
When rolling two dice, the outcome $(1,6)$ and $(6,1)$ are

different

outcomes in the sample space. Students often forget to count ordered pairs and under-count the sample space. Always be explicit about whether outcomes are ordered or unordered.
:::

## §12.2 Unions and Complements of Events

:::callout-intuition
If two events can't happen at the same time, their probabilities just add. If they can overlap, we'd double-count the overlap — so we subtract it back. This is the probabilistic version of inclusion-exclusion.
:::

:::theorem[Theorem 12.1 — Addition Rule]
Union of Events

For any two events $E$ and $F$:

$$
P(E \cup F) = P(E) + P(F) - P(E \cap F)
$$

If $E$ and $F$ are **mutually exclusive** (i.e., $E \cap F = \emptyset$), then $P(E \cap F) = 0$ and the formula simplifies to $P(E \cup F) = P(E) + P(F)$.
:::

:::theorem[Theorem 12.2 — Complement Rule]
Probability of the Complement

For any event $E$, its complement $\bar{E} = S \setminus E$ satisfies:

$$
P(\bar{E}) = 1 - P(E)
$$

*Strategy:* when it's easier to count "not $E$" than to count $E$ directly, compute $P(E) = 1 - P(\bar{E})$.
:::

Example 12.4 — Addition Rule

One card drawn from a 52-card deck. What is $P(\text{heart or face card})$?

:::answer[Answer]
$P = 22/52 = 11/26$
:::

:::answer
Work

Let $H$ = heart, $F$ = face card.

$P(H) = 13/52$, $\quad P(F) = 12/52$, $\quad P(H \cap F) = 3/52$ (heart face cards).

$$
P(H \cup F) = \frac{13}{52} + \frac{12}{52} - \frac{3}{52} = \frac{22}{52} = \frac{11}{26}
$$
:::

Example 12.5 — Complement Strategy

A fair coin is flipped 5 times. What is the probability of getting *at least one* head?

:::answer[Answer]
$P = 31/32$
:::

:::answer
Work

Direct counting is messy (need to count sequences with 1, 2, 3, 4, or 5 heads).

Complement: $\bar{E}$ = "zero heads" = all tails = exactly one outcome: TTTTT.

$|S| = 2^5 = 32$ total sequences.

$$
P(\bar{E}) = \frac{1}{32} \implies P(E) = 1 - \frac{1}{32} = \frac{31}{32}
$$

The complement shortcut saves enormous work.
:::

## §12.3 Conditional Probability and Independence

:::callout-intuition
Conditional probability answers: "if I already know $F$ happened, what's the chance $E$ happens?" Knowing something happened restricts the universe of possibilities to just $F$, and we re-normalize within that smaller universe.
:::

:::definition[Definition 12.3 — Conditional Probability]
Conditional Probability

The **conditional probability** of event $E$ given event $F$ (with $P(F) > 0$) is:

$$
P(E \mid F) = \frac{P(E \cap F)}{P(F)}
$$

Intuitively: we restrict the sample space to $F$ and ask how much of $F$ lies in $E$.
:::

:::definition[Definition 12.4 — Independence]
Independent Events

Events $E$ and $F$ are **independent** if knowing one occurred gives no information about the other:

$$
P(E \cap F) = P(E) \cdot P(F)
$$

Equivalently (when $P(F) > 0$): $P(E \mid F) = P(E)$.
:::

:::theorem[Theorem 12.3 — Multiplication (Chain) Rule]
Chain Rule

$$
P(E \cap F) = P(F) \cdot P(E \mid F) = P(E) \cdot P(F \mid E)
$$

For three events: $P(E_1 \cap E_2 \cap E_3) = P(E_1)\cdot P(E_2 \mid E_1)\cdot P(E_3 \mid E_1 \cap E_2)$.
:::

Example 12.6 — Drawing Without Replacement

Two cards are drawn from a 52-card deck without replacement. What is the probability that both are aces?

:::answer[Answer]
$P = 1/221$
:::

:::answer
Work

Let $A_1$ = first card is ace, $A_2$ = second card is ace.

$P(A_1) = 4/52$ (4 aces in 52 cards).

$P(A_2 \mid A_1) = 3/51$ (3 aces left in 51 remaining cards).

$$
P(A_1 \cap A_2) = P(A_1) \cdot P(A_2 \mid A_1) = \frac{4}{52} \cdot \frac{3}{51} = \frac{12}{2652} = \frac{1}{221}
$$
:::

Example 12.7 — Testing Independence

A fair die is rolled. Let $E = \{2,4,6\}$ (even) and $F = \{1,2,3\}$ (at most 3). Are $E$ and $F$ independent?

:::answer[Answer]
Yes, independent.
:::

:::answer
Work

$P(E) = 3/6 = 1/2$, $\quad P(F) = 3/6 = 1/2$.

$E \cap F = \{2\}$, so $P(E \cap F) = 1/6$.

Check: $P(E) \cdot P(F) = (1/2)(1/2) = 1/4$. But $P(E \cap F) = 1/6 \neq 1/4$.

Counting again, carefully: $E = \{2,4,6\}$ and $F = \{1,2,3\}$, so $E \cap F = \{2\}$, giving $P(E \cap F) = 1/6$.

And $P(E)\cdot P(F) = (3/6)(3/6) = 9/36 = 1/4 \neq 1/6$. So they are **not independent**.

For an independent example: let $F = \{1,2,3,4\}$ ("at most 4"). Then $P(F) = 4/6 = 2/3$, $E \cap F = \{2,4\}$, $P(E \cap F) = 2/6 = 1/3 = P(E)\cdot P(F) = (1/2)(2/3)$. ✓
:::

:::callout-pitfall[Common Pitfall]
Mutually exclusive ≠ independent.

If $E \cap F = \emptyset$ and both have positive probability, then $P(E \cap F) = 0 \neq P(E) \cdot P(F)$ — so mutually exclusive events with positive probability are always

dependent

. The intuition: if you know $F$ happened, you know $E$ didn't.
:::

## §12.4 Bayes' Theorem

:::callout-intuition
Bayes' theorem lets you "flip" a conditional probability. If you know $P(\text{test positive} \mid \text{disease})$, Bayes gives you $P(\text{disease} \mid \text{test positive})$ — the probability you actually care about. It's the mathematical foundation of spam filters, medical diagnosis, and Bayesian machine learning.
:::

:::theorem[Theorem 12.4 — Law of Total Probability]
Total Probability

Let $F_1, F_2, \ldots, F_n$ partition $S$ (they are mutually exclusive and exhaustive). For any event $E$:

$$
P(E) = \sum_{i=1}^{n} P(E \mid F_i)\, P(F_i)
$$

This decomposes $P(E)$ by considering each possible "cause" $F_i$.
:::

:::theorem[Theorem 12.5 — Bayes' Theorem]
Bayes' Theorem

For events $E$ and $F$ with $P(E) > 0$:

$$
P(F \mid E) = \frac{P(E \mid F)\, P(F)}{P(E)}
$$

Using total probability to expand the denominator (with $\bar{F}$ as the complementary partition):

$$
P(F \mid E) = \frac{P(E \mid F)\, P(F)}{P(E \mid F)\, P(F)\;+\; P(E \mid \bar{F})\, P(\bar{F})}
$$
:::

### Terminology

- $P(F)$ — the **prior**: your belief before seeing evidence
- $P(E \mid F)$ — the **likelihood**: how probable the evidence is given the hypothesis
- $P(F \mid E)$ — the **posterior**: updated belief after seeing evidence

Example 12.8 — Medical Testing (Classic)

A disease affects 1% of the population. A test for it has: 99% sensitivity (if you have it, test positive 99% of the time) and 95% specificity (if you don't have it, test negative 95% of the time). You test positive. What is the probability you actually have the disease?

:::answer[Answer]
$P(\text{disease} \mid +) \approx 16.7\%$ — surprisingly low!
:::

:::answer
Work

Let $D$ = has disease, $+$ = tests positive.

**Given:** $P(D) = 0.01$, $P(+ \mid D) = 0.99$, $P(+ \mid \bar{D}) = 0.05$.

**Step 1 — Total probability of testing positive:**

$$
P(+) = P(+ \mid D)\,P(D) + P(+ \mid \bar{D})\,P(\bar{D})
$$

$$
= (0.99)(0.01) + (0.05)(0.99) = 0.0099 + 0.0495 = 0.0594
$$

**Step 2 — Apply Bayes:**

$$
P(D \mid +) = \frac{P(+ \mid D)\,P(D)}{P(+)} = \frac{(0.99)(0.01)}{0.0594} = \frac{0.0099}{0.0594} \approx 0.167
$$

**Intuition:** The disease is rare (1%). Out of 10,000 people: ~100 have it (99 test positive), ~9,900 don't (but 495 still test positive by false alarm). So among the 594 positives, only 99 actually have the disease: $99/594 \approx 16.7\%$.
:::

:::callout-connect[Connection — Spam Filters]
Bayesian spam filters compute $P(\text{spam} \mid \text{email contains word } w)$ for each word $w$. Prior $P(\text{spam})$ is estimated from historical data. After seeing many training emails, the filter updates its posterior belief for each new message. This is Bayes' theorem applied at scale.
:::

Example 12.9 — Two Boxes

Box A has 3 red and 7 blue balls. Box B has 6 red and 4 blue balls. A box is chosen at random (50/50), and one ball is drawn. It is red. What is the probability that Box A was chosen?

:::answer[Answer]
$P(A \mid \text{red}) = 1/3$
:::

:::answer
Work

$P(A) = P(B) = 1/2$. $\quad P(\text{red}\mid A) = 3/10$. $\quad P(\text{red}\mid B) = 6/10$.

$$
P(\text{red}) = \frac{3}{10}\cdot\frac{1}{2} + \frac{6}{10}\cdot\frac{1}{2} = \frac{3}{20} + \frac{6}{20} = \frac{9}{20}
$$

$$
P(A \mid \text{red}) = \frac{(3/10)(1/2)}{9/20} = \frac{3/20}{9/20} = \frac{3}{9} = \frac{1}{3}
$$

Since Box B has twice as many red balls, drawing red makes Box B twice as likely as Box A.
:::

## §12.5 Random Variables

:::callout-intuition
A random variable is a function that assigns a number to each outcome. Instead of saying "the event 'rolled a 6'", we say "the random variable $X$ equals 6". This lets us use algebra and calculus on probabilistic outcomes — leading directly to expectation, variance, and distributions.
:::

:::definition[Definition 12.5 — Random Variable]
Random Variable

A **random variable** $X$ is a function $X : S \to \mathbb{R}$ from the sample space to the real numbers.

For a **discrete** random variable, the **probability distribution** specifies $P(X = k)$ for each value $k$ that $X$ can take. We require $\sum_k P(X = k) = 1$.
:::

Example 12.10 — Die Roll Distribution

Let $X$ be the result of rolling one fair die. Write out the probability distribution of $X$.

:::answer[Answer]
$P(X = k) = 1/6$ for $k \in \{1,2,3,4,5,6\}$.
:::

:::answer
Distribution Table

| $k$ | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- |
| **$P(X=k)$** | $\frac{1}{6}$ | $\frac{1}{6}$ | $\frac{1}{6}$ | $\frac{1}{6}$ | $\frac{1}{6}$ | $\frac{1}{6}$ |

All six outcomes equally likely; probabilities sum to 1. ✓
:::

Example 12.11 — Number of Heads in 2 Flips

A fair coin is flipped twice. Let $X$ = number of heads. Find the distribution of $X$.

:::answer[Answer]
$P(X=0) = 1/4$, $P(X=1) = 1/2$, $P(X=2) = 1/4$.
:::

:::answer
Work

Sample space: $\{HH, HT, TH, TT\}$, each with probability $1/4$.

$X(HH) = 2$, $X(HT) = 1$, $X(TH) = 1$, $X(TT) = 0$.

| $k$ | 0 | 1 | 2 |
| --- | --- | --- | --- |
| **$P(X=k)$** | $\frac{1}{4}$ | $\frac{2}{4}$ | $\frac{1}{4}$ |

Sum: $1/4 + 2/4 + 1/4 = 1$. ✓
:::

## §12.6 Expectation of a Random Variable

:::callout-intuition
The

expectation

(expected value, mean) of $X$ is the long-run average: if you ran the experiment many times and averaged all the $X$ values you saw, you'd converge to $E[X]$. It's the "center of mass" of the distribution. Expected value is not necessarily a value $X$ can actually take — for a die, $E[X] = 3.5$.
:::

:::definition[Definition 12.6 — Expected Value]
Expectation

The **expected value** (or **expectation**) of a discrete random variable $X$ is:

$$
E[X] = \sum_{k} k \cdot P(X = k)
$$

where the sum runs over all values $k$ that $X$ can take. Each value is weighted by its probability.
:::

Example 12.12 — Expected Value of a Die Roll

Find $E[X]$ where $X$ is the result of one fair die roll.

:::answer[Answer]
$E[X] = 3.5$
:::

:::answer
Work

$$
E[X] = 1\cdot\frac{1}{6} + 2\cdot\frac{1}{6} + 3\cdot\frac{1}{6} + 4\cdot\frac{1}{6} + 5\cdot\frac{1}{6} + 6\cdot\frac{1}{6}
$$

$$
= \frac{1+2+3+4+5+6}{6} = \frac{21}{6} = 3.5
$$
:::

Example 12.13 — Geometric Random Variable (First Success)

You keep flipping a fair coin until you get heads. Let $X$ be the number of flips needed. Find $P(X = k)$ and $E[X]$.

:::answer[Answer]
$P(X=k) = (1/2)^k$; $E[X] = 2$
:::

:::answer
Work

To need exactly $k$ flips: get $k-1$ tails then one head.

$$
P(X = k) = \left(\frac{1}{2}\right)^{k-1} \cdot \frac{1}{2} = \left(\frac{1}{2}\right)^k, \quad k = 1,2,3,\ldots
$$

For the expected value, use the geometric series result: if each trial has success probability $p$, then $E[X] = 1/p$. Here $p = 1/2$, so $E[X] = 2$. On average you need 2 flips to get your first head.
:::

:::callout-connect[Connection — Hashing]
In a hash table with $n$ slots and the balls-into-bins model, the expected number of collisions when inserting $m$ items is $m(m-1)/(2n)$ — derived directly from expected value. Understanding expectation is essential for analyzing hash table performance.
:::

## §12.7 Linearity of Expectation

:::callout-intuition
Linearity of expectation is one of the most powerful tools in combinatorics and algorithm analysis. The remarkable fact: $E[X + Y] = E[X] + E[Y]$ holds even when $X$ and $Y$ are

dependent

. You never need to know the joint distribution — just compute each piece separately and add.
:::

:::theorem[Theorem 12.6 — Linearity of Expectation]
Linearity of Expectation

For any random variables $X$ and $Y$ (not necessarily independent) and any constants $a, b \in \mathbb{R}$:

$$
E[aX + bY] = aE[X] + bE[Y]
$$

More generally, for any $X_1, X_2, \ldots, X_n$:

$$
E\!\left[\sum_{i=1}^{n} X_i\right] = \sum_{i=1}^{n} E[X_i]
$$
:::

:::callout-key[Key Technique — Indicator Variables]
The most common application: define an

indicator variable

$X_i = 1$ if event $i$ occurs and $X_i = 0$ otherwise. Then $E[X_i] = P(\text{event } i)$. The total count $X = \sum_i X_i$ has expected value $E[X] = \sum_i P(\text{event } i)$. This decomposes one hard problem into many easy ones.
:::

Example 12.14 — Expected Sum of Two Dice

Two fair dice are rolled. Find the expected value of their sum.

:::answer[Answer]
$E[\text{sum}] = 7$
:::

:::answer
Work

Let $X_1$ = value of die 1, $X_2$ = value of die 2. Both have $E = 3.5$.

By linearity (no need to compute the joint distribution):

$$
E[X_1 + X_2] = E[X_1] + E[X_2] = 3.5 + 3.5 = 7
$$
:::

Example 12.15 — Expected Number of Fixed Points (Derangements)

A deck of $n$ cards is shuffled randomly. What is the expected number of cards that end up in their original position?

:::answer[Answer]
$E = 1$, regardless of $n$!
:::

:::answer
Work

Let $X_i = 1$ if card $i$ is in position $i$, else $0$. The total number of fixed points is $X = \sum_{i=1}^{n} X_i$.

By symmetry, $P(X_i = 1) = 1/n$ for each card (it's equally likely to end up anywhere).

So $E[X_i] = 1/n$.

By linearity:

$$
E[X] = \sum_{i=1}^{n} E[X_i] = \sum_{i=1}^{n} \frac{1}{n} = n \cdot \frac{1}{n} = 1
$$

This is elegant: on average, exactly 1 card is a fixed point, no matter how big the deck is.
:::

Example 12.16 — Expected Comparisons in Randomized Search

A list of $n$ distinct items is searched linearly. The target is equally likely to be at any position. What is the expected number of comparisons?

:::answer[Answer]
$E = (n+1)/2$
:::

:::answer
Work

If the target is at position $k$, we make $k$ comparisons. Each position is equally likely: $P(\text{position} = k) = 1/n$.

$$
E[\text{comparisons}] = \sum_{k=1}^{n} k \cdot \frac{1}{n} = \frac{1}{n} \cdot \frac{n(n+1)}{2} = \frac{n+1}{2}
$$

This confirms the intuitive answer: on average, you find it halfway through the list.
:::

## §12.8 Bernoulli Trials and the Binomial Distribution

:::callout-intuition
A

Bernoulli trial

is any yes/no experiment: does a bit flip? does this packet get dropped? does this hash slot get hit? When you run $n$ independent Bernoulli trials, the number of successes follows the

binomial distribution

, which is one of the most important distributions in CS.
:::

:::definition[Definition 12.7 — Bernoulli Trial]
Bernoulli Trial

A **Bernoulli trial** is an experiment with exactly two outcomes: *success* (probability $p$) and *failure* (probability $1-p = q$). The random variable $X$ taking value 1 (success) or 0 (failure) has:

$$
E[X] = p \qquad \text{Var}[X] = pq
$$
:::

:::definition[Definition 12.8 — Binomial Distribution]
Binomial$(n, p)$

If $X$ counts the number of successes in $n$ independent Bernoulli trials each with success probability $p$, then $X \sim \text{Binomial}(n, p)$ and:

$$
P(X = k) = \binom{n}{k} p^k (1-p)^{n-k}, \quad k = 0, 1, \ldots, n
$$

The $\binom{n}{k}$ counts the ways to choose which $k$ of the $n$ trials succeed; $p^k(1-p)^{n-k}$ is the probability of one such arrangement.
:::

:::theorem[Theorem 12.7 — Binomial Mean and Variance]
Binomial Parameters

If $X \sim \text{Binomial}(n,p)$:

$$
E[X] = np \qquad \text{Var}[X] = np(1-p)
$$

*Proof of mean:* Write $X = X_1 + \cdots + X_n$ where each $X_i$ is an indicator for trial $i$. Each $E[X_i] = p$. By linearity, $E[X] = np$.
:::

Example 12.17 — Binomial Probability

A network link drops each packet independently with probability 0.1. A burst of 8 packets is sent. (a) What is the probability exactly 2 are dropped? (b) What is the expected number dropped?

:::answer[Answers]
(a) $P(X=2) \approx 14.9\%$    (b) $E[X] = 0.8$
:::

:::answer
Work

$n=8$, $p=0.1$, so $X \sim \text{Binomial}(8, 0.1)$.

**(a)**

$$
P(X=2) = \binom{8}{2}(0.1)^2(0.9)^6 = 28 \cdot 0.01 \cdot 0.531441 = 28 \cdot 0.00531441 \approx 0.1489
$$

**(b)** $E[X] = np = 8 \cdot 0.1 = 0.8$ packets dropped on average.
:::

Example 12.18 — At Least One Success

A test suite has 10 independent test cases, each of which independently catches a bug with probability 0.3. What is the probability the bug is caught (by at least one test)?

:::answer[Answer]
$P(\text{caught}) \approx 97.2\%$
:::

:::answer
Work

Use the complement. $X \sim \text{Binomial}(10, 0.3)$.

$P(X = 0) = \binom{10}{0}(0.3)^0(0.7)^{10} = 0.7^{10} \approx 0.0282$.

$P(X \geq 1) = 1 - P(X = 0) \approx 1 - 0.0282 = 0.9718$.
:::

:::callout-pitfall[Common Pitfall]
The binomial formula requires

independent

trials. Drawing cards

without replacement

violates independence — use the

hypergeometric distribution

instead. Also, $\binom{n}{k}$ counts unordered selections; make sure you're not double-counting or under-counting arrangements.
:::

:::summary
### Chapter 12 — Quick Reference

| Concept | Formula / Key Fact |
| --- | --- |
| Uniform probability | $P(E) = |E|/|S|$ |
| Addition rule | $P(E \cup F) = P(E)+P(F)-P(E \cap F)$ |
| Complement | $P(\bar{E}) = 1 - P(E)$ |
| Conditional probability | $P(E \mid F) = P(E \cap F)/P(F)$ |
| Independence | $P(E \cap F) = P(E)\cdot P(F)$ |
| Chain rule | $P(E \cap F) = P(F)\cdot P(E \mid F)$ |
| Bayes' theorem | $P(F \mid E) = P(E \mid F)\,P(F)\;/\;P(E)$ |
| Expected value | $E[X] = \sum_k k\,P(X=k)$ |
| Linearity | $E[X+Y] = E[X]+E[Y]$ (always) |
| Indicator trick | $E[X_i] = P(\text{event}_i)$; sum for total |
| Binomial PMF | $P(X=k)=\binom{n}{k}p^k(1-p)^{n-k}$ |
| Binomial mean | $E[X]=np$ |
| Binomial variance | $\text{Var}[X]=np(1-p)$ |
:::

## Practice Problems

:::problem[12.1]{difficulty="easy"}
12.1

A bag contains 4 red, 3 blue, and 2 green marbles. One marble is drawn at random. Find: (a) $P(\text{red})$, (b) $P(\text{not blue})$, (c) $P(\text{red or green})$.

::::solution[Solution]
Total marbles: $4+3+2=9$.

(a) $P(\text{red}) = 4/9$

(b) $P(\text{not blue}) = 1 - 3/9 = 6/9 = 2/3$

(c) $P(\text{red or green}) = (4+2)/9 = 6/9 = 2/3$ (mutually exclusive: no marble is both red and green).
::::
:::

:::problem[12.2]{difficulty="easy"}
12.2

Two fair dice are rolled. Find the probability that: (a) both show the same number ("doubles"), (b) the product of the two results is even, (c) at least one die shows a 4.

::::solution[Solution]
$|S| = 36$.

(a) Doubles: $(1,1),(2,2),(3,3),(4,4),(5,5),(6,6)$ — 6 outcomes. $P = 6/36 = 1/6$.

(b) Product is odd only when both dice are odd: $3 \times 3 = 9$ outcomes. Product is even for remaining $36 - 9 = 27$. $P = 27/36 = 3/4$. (Or: $P(\text{odd}) = (3/6)^2 = 1/4$, so $P(\text{even}) = 3/4$.)

(c) Complement: neither die shows 4. $P(\text{no 4}) = (5/6)^2 = 25/36$. $P(\text{at least one 4}) = 1 - 25/36 = 11/36$.
::::
:::

:::problem[12.3]{difficulty="standard"}
12.3

A class has 12 CS majors and 8 math majors. Three students are selected at random without replacement. What is the probability all three are CS majors?

::::solution[Solution]
Use the chain rule (or equivalently, count ordered selections):

$P(\text{1st is CS}) = 12/20$

$P(\text{2nd is CS} \mid \text{1st CS}) = 11/19$

$P(\text{3rd is CS} \mid \text{first two CS}) = 10/18$

$$
P(\text{all CS}) = \frac{12}{20}\cdot\frac{11}{19}\cdot\frac{10}{18} = \frac{1320}{6840} = \frac{22}{114} = \frac{11}{57} \approx 19.3\%
$$

Alternatively using combinations: $\binom{12}{3}/\binom{20}{3} = 220/1140 = 11/57$. ✓
::::
:::

:::problem[12.4]{difficulty="standard"}
12.4

A software component has two redundant subsystems A and B that operate independently. A fails with probability 0.05; B fails with probability 0.08. The whole system fails only if both subsystems fail. (a) What is $P(\text{system fails})$? (b) Given the system failed, what is $P(\text{A failed})$?

::::solution[Solution]
(a) By independence: $P(\text{both fail}) = P(A)\cdot P(B) = 0.05 \times 0.08 = 0.004$.

(b) System fails iff both fail, so $\{\text{system fails}\} = \{\text{A fails} \cap \text{B fails}\}$.

$P(\text{A failed} \mid \text{system failed}) = P(\text{A fails} \cap \text{system fails})/P(\text{system fails})$.

But system fails $\implies$ A fails, so the intersection equals "system fails".

$P(\text{A failed} \mid \text{system failed}) = P(\text{system fails})/P(\text{system fails}) = 1$.

If the system failed, A must have failed (since both must fail).
::::
:::

:::problem[12.5]{difficulty="standard"}
12.5

A factory produces chips on three lines: Line 1 makes 50% of chips (2% defective), Line 2 makes 30% (4% defective), Line 3 makes 20% (5% defective). A chip is selected at random and found defective. What is the probability it came from Line 2? (Apply Bayes' theorem.)

::::solution[Solution]
Let $L_i$ = from line $i$, $D$ = defective.

$P(L_1)=0.5,\; P(L_2)=0.3,\; P(L_3)=0.2$.

$P(D \mid L_1)=0.02,\; P(D \mid L_2)=0.04,\; P(D \mid L_3)=0.05$.

Total probability of defective:

$$
P(D) = 0.02(0.5)+0.04(0.3)+0.05(0.2) = 0.01+0.012+0.01 = 0.032
$$

Bayes:

$$
P(L_2 \mid D) = \frac{P(D\mid L_2)\,P(L_2)}{P(D)} = \frac{0.04 \times 0.3}{0.032} = \frac{0.012}{0.032} = \frac{3}{8} = 37.5\%
$$
::::
:::

:::problem[12.6]{difficulty="standard"}
12.6

Let $X$ be the number showing on a fair die. Find: (a) $E[X]$, (b) $E[X^2]$, (c) $E[3X - 1]$.

::::solution[Solution]
(a) $E[X] = (1+2+3+4+5+6)/6 = 21/6 = 7/2 = 3.5$.

(b) $E[X^2] = (1+4+9+16+25+36)/6 = 91/6 \approx 15.17$.

(c) By linearity: $E[3X-1] = 3E[X] - 1 = 3(3.5) - 1 = 10.5 - 1 = 9.5$.
::::
:::

:::problem[12.7]{difficulty="challenge"}
12.7

A randomized algorithm picks a random permutation of $n$ elements. Let $X$ be the number of "inversions" (pairs $i < j$ where $\pi(i) > \pi(j)$). Use linearity of expectation and indicator variables to find $E[X]$.

::::solution[Solution]
For each pair $(i,j)$ with $i < j$, define indicator $X_{ij} = 1$ if $\pi(i) > \pi(j)$ (an inversion), else 0.

There are $\binom{n}{2}$ such pairs.

By symmetry, for any pair of positions the probability that the element at $i$ is larger than the element at $j$ is exactly $1/2$ (since the permutation is uniformly random).

So $E[X_{ij}] = 1/2$.

By linearity of expectation:

$$
E[X] = \sum_{i < j} E[X_{ij}] = \binom{n}{2} \cdot \frac{1}{2} = \frac{n(n-1)}{4}
$$

For $n = 4$: expected inversions $= 4\cdot3/4 = 3$. The maximum possible is $\binom{4}{2} = 6$.
::::
:::

:::problem[12.8]{difficulty="challenge"}
12.8

A biased coin has $P(\text{heads}) = 0.6$. You flip it 10 times. (a) Find $P(X = 6)$ where $X$ is the number of heads. (b) Find $P(X \geq 9)$. (c) Find $E[X]$ and the standard deviation of $X$.

::::solution[Solution]
$X \sim \text{Binomial}(10, 0.6)$. Note $1-p = 0.4$.

(a) $P(X=6) = \binom{10}{6}(0.6)^6(0.4)^4 = 210 \cdot 0.046656 \cdot 0.0256 \approx 210 \times 0.001194 \approx 0.2508$.

(b) $P(X \geq 9) = P(X=9)+P(X=10)$.

$P(X=9) = \binom{10}{9}(0.6)^9(0.4)^1 = 10 \times 0.010078 \times 0.4 \approx 0.04031$.

$P(X=10) = (0.6)^{10} \approx 0.006047$.

$P(X \geq 9) \approx 0.04031 + 0.00605 \approx 0.04636$.

(c) $E[X] = np = 10(0.6) = 6$. $\text{Var}[X] = np(1-p) = 10(0.6)(0.4) = 2.4$. $\sigma = \sqrt{2.4} \approx 1.549$.
::::
:::

## LeetCode Practice

| # | Problem | Difficulty | Connection |
| --- | --- | --- | --- |
| [382](https://leetcode.com/problems/linked-list-random-node/) | Linked List Random Node | Medium | Reservoir sampling — uniform random selection from unknown-length stream; relies on equal probability per element (§12.1) |
| [398](https://leetcode.com/problems/random-pick-index/) | Random Pick Index | Medium | Reservoir sampling with repeated values; expected selections per target use linearity of expectation (§12.7) |
| [470](https://leetcode.com/problems/implement-rand10-using-rand7/) | Implement Rand10() Using Rand7() | Medium | Expected calls = geometric RV (§12.6); uniform distribution construction via rejection sampling |
| [519](https://leetcode.com/problems/random-flip-matrix/) | Random Flip Matrix | Medium | Each unflipped cell equally likely — uniform probability space (§12.1–§12.2) |
