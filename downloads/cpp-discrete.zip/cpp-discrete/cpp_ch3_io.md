---
title: "Basic I/O & Streams"
source: "cpp_ch3_io.html"
---

CSE 1384

# Basic I/O & Streams

§3.1 – §3.9

## Chapter Overview

You already know `cout <<` and `cin >>`. This chapter reveals what's actually happening under the hood: both are *streams* — flowing sequences of characters. Once you understand that model, output formatting becomes intuitive, reading from a file is almost identical to reading from the keyboard, and you can even build streams from strings. This is the chapter that makes your programs talk to the world beyond the terminal.

:::callout-key[Prerequisites]
Chapters 1 and 2 — comfortable with variable types, arithmetic, and basic `cout`/`cin`.
:::

**What you'll learn:** the stream abstraction, formatting output with `<iomanip>`, parsing strings with `istringstream`, building strings with `ostringstream`, reading and writing files with `ifstream`/`ofstream`, error handling on file operations, and overloading `<<`/`>>` for your own types.

## 1 · Streams & the Flow Model (§3.1)

:::callout-intuition[Intuition]
A **stream** is a sequence of characters flowing in one direction — like water through a pipe. An *output stream* carries characters from your program to somewhere (the screen, a file, a string). An *input stream* carries characters from somewhere into your program. The `<<` operator pushes characters into an output stream; `>>` pulls characters out of an input stream.
:::

:::definition[Definition 3.1Stream]
A **stream** is an abstraction representing a sequence of bytes flowing between a program and an I/O device (screen, keyboard, file, string buffer). C++ streams are objects — they have state, methods, and can signal errors.
:::

```
┌─────────────┐   << (insert)    ┌──────────────┐   characters   ┌───────────┐
│  Your code  │ ────────────────▶ │  cout stream │ ─────────────▶ │  Terminal │
└─────────────┘                   └──────────────┘                └───────────┘

┌─────────────┐   >> (extract)   ┌──────────────┐   characters   ┌───────────┐
│  Your code  │ ◀──────────────── │  cin stream  │ ◀───────────── │  Keyboard │
└─────────────┘                   └──────────────┘                └───────────┘
```

### The Standard Streams

| Object | Type | Direction | Default device |
| --- | --- | --- | --- |
| `cout` | `ostream` | Output | Terminal (stdout) |
| `cin` | `istream` | Input | Keyboard (stdin) |
| `cerr` | `ostream` | Output (errors) | Terminal (stderr, unbuffered) |
| `clog` | `ostream` | Output (log) | Terminal (stderr, buffered) |

### How `cin` Reads

`cin >> variable` skips whitespace, then reads characters until the next whitespace. This is called *whitespace-delimited* input — it reads one "token" (word or number) at a time.

```cpp
int age;
string name;

// User types: Alice 20
cin >> name;   // reads "Alice" (stops at space)
cin >> age;    // reads "20"

// Chain input just like chain output:
cin >> name >> age;   // reads both in one statement
```

### Reading Entire Lines with `getline()`

`cin >>` stops at spaces — so it can't read "Hello World" as one string. Use `getline(cin, str)` to read a full line including spaces:

```cpp
string fullName;
cout << "Enter your full name: ";
getline(cin, fullName);   // reads everything up to '\n'
cout << "Hello, " << fullName << "!" << endl;
```

:::callout-pitfall[The cin/getline Pitfall]
If you use `cin >>` before `getline()`, there's a leftover newline in the buffer from when the user pressed Enter. `getline()` immediately reads that empty line instead of waiting for new input. Fix: call `cin.ignore()` (or `cin.ignore(1000, '\n')`) after `cin >>` and before `getline()`.

```cpp
int age;
string name;
cin >> age;
cin.ignore();           // discard the leftover '\n'
getline(cin, name);     // now works correctly
```
:::

### Stream State & Error Checking

Streams track whether they're in a good state. After reading, always check if it succeeded — especially with user input:

```cpp
int n;
if (cin >> n) {
    cout << "You entered: " << n << endl;
} else {
    cout << "Bad input!" << endl;
    cin.clear();             // reset error flags
    cin.ignore(1000, '\n');  // discard bad input
}
```

### Practice — Streams

:::problem[3.1easy]{difficulty="easy"}
What is the difference between `cout` and `cerr`? When would you use `cerr` instead of `cout`?

::::solution[Solution]
Both write to the terminal, but `cerr` is the *error stream* (stderr) and is unbuffered (output appears immediately, not held in a buffer). Use `cerr` for error messages — this way errors appear even if `cout`'s buffer hasn't been flushed, and output can be redirected separately (e.g., `./program 2>errors.txt` sends cerr to a file while cout still goes to screen).
::::
:::

:::problem[3.2standard]{difficulty="standard"}
Write a program that prompts the user for their first name, last name, and age on separate lines (using `getline` for names), then prints: `Name: [first] [last], Age: [age]`.

::::solution[Solution]
```cpp
#include <iostream>
#include <string>
using namespace std;
int main() {
    string first, last;
    int age;
    cout << "First name: "; getline(cin, first);
    cout << "Last name: ";  getline(cin, last);
    cout << "Age: ";        cin >> age;
    cout << "Name: " << first << " " << last
         << ", Age: " << age << endl;
    return 0;
}
```
::::
:::

:::problem[3.3challenge]{difficulty="challenge"}
A student writes this code and says it "skips" the name input. Explain exactly why and fix it:

```cpp
int score;
string name;
cin >> score;
getline(cin, name);
cout << name;
```

::::solution[Solution]
When the user types a score and presses Enter, `cin >> score` reads the number but leaves the `'\n'` (Enter) in the input buffer. `getline` then immediately reads up to that leftover newline and gets an empty string.

```cpp
int score;
string name;
cin >> score;
cin.ignore();       // consume the leftover '\n'
getline(cin, name);
cout << name;
```
::::
:::

## 2 · Output Formatting (§3.2)

:::callout-intuition[Intuition]
By default, C++ prints numbers with as many digits as it thinks are necessary. For financial output ($1234.50, not $1234.5), aligned tables, or scientific displays, you need precise control. The `<iomanip>` (I/O manipulators) header gives you that control through objects you insert directly into the stream with `<<`.
:::

### Essential `<iomanip>` Manipulators

| Manipulator | What it does | Sticky? |
| --- | --- | --- |
| `setw(n)` | Set minimum field width to n characters | No (one use only) |
| `setprecision(n)` | Set number of significant digits (or decimal places with `fixed`) | Yes |
| `fixed` | Use fixed decimal notation (always show decimal point) | Yes |
| `scientific` | Use scientific notation (e.g., 1.23e+04) | Yes |
| `left` | Left-align within field width | Yes |
| `right` | Right-align within field width (default) | Yes |
| `setfill(c)` | Fill unused field space with character c (default: space) | Yes |
| `boolalpha` | Print `true`/`false` instead of 1/0 | Yes |
| `hex` | Print integers in hexadecimal | Yes |
| `oct` | Print integers in octal | Yes |
| `dec` | Restore integers to decimal (default) | Yes |
| `endl` | Insert newline AND flush the buffer | No |

**"Sticky"** means the setting persists for all subsequent output until you change it. `setw` is the notable exception — it resets after each use.

:::example[Example 3.1 — Financial report table]
Print a two-column table of items and prices, right-aligned, with two decimal places. Column widths: item name 12 chars, price 8 chars.

::::answer[Answer]

::::

```cpp
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    cout << fixed << setprecision(2);   // sticky: all doubles 2 decimal places
    cout << left;                         // sticky: left-align strings

    // Header
    cout << setw(12) << "Item"
         << right << setw(8) << "Price" << endl;
    cout << string(20, '-') << endl;

    // Rows
    cout << left  << setw(12) << "Apple"
         << right << setw(8)  << 1.25 << endl;
    cout << left  << setw(12) << "Bread"
         << right << setw(8)  << 3.50 << endl;
    cout << left  << setw(12) << "Milk"
         << right << setw(8)  << 2.99 << endl;
    return 0;
}
```

Output:

```
Item            Price
--------------------
Apple            1.25
Bread            3.50
Milk             2.99
```
:::

:::example[Example 3.2 — Hex and octal output]
Print the decimal value 255 in hex, octal, and binary-style hex with uppercase letters and a `0x` prefix.

::::answer[Answer]

::::

```cpp
#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int n = 255;
    cout << dec << n << endl;              // 255
    cout << hex << n << endl;              // ff
    cout << uppercase << hex << n << endl; // FF
    cout << showbase << hex << n << endl;   // 0XFF (with 0x prefix)
    cout << oct << n << endl;              // 377
    cout << dec;                            // restore to decimal
    return 0;
}
```
:::

### Practice — Output Formatting

:::problem[3.4easy]{difficulty="easy"}
What does the following print?

`cout << fixed << setprecision(3) << 3.14159 << endl;`

 Then: `cout << 2.71828 << endl;`

::::solution[Solution]
First line: **3.142** (rounds to 3 decimal places).

 Second line: **2.718** — because `fixed` and `setprecision(3)` are sticky, they still apply to the second `cout`.
::::
:::

:::problem[3.5standard]{difficulty="standard"}
Write code to print a three-column student grade report. Columns: Student name (left, 15 chars), Score (right, 5 chars), Grade letter (right, 5 chars). Use at least two rows of data.

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    cout << left << setw(15) << "Student"
         << right << setw(5) << "Score"
         << setw(5) << "Grade" << endl;
    cout << string(25, '-') << endl;
    cout << left  << setw(15) << "Alice"
         << right << setw(5)  << 94
         << setw(5) << "A" << endl;
    cout << left  << setw(15) << "Bob"
         << right << setw(5)  << 78
         << setw(5) << "C" << endl;
    return 0;
}
```
::::
:::

:::problem[3.6challenge]{difficulty="challenge"}
Print a number using a zero-padded field of width 8 — e.g., the number 42 should appear as `00000042`.

::::solution[Solution]
```cpp
cout << setfill('0') << setw(8) << 42 << endl;  // 00000042
```

`setfill` is sticky (sets the fill character), but `setw` resets after each use. Remember to restore: `cout << setfill(' ');` afterward if you need normal output later.
::::
:::

## 3 · String Streams (§3.3–§3.4)

:::callout-intuition[Intuition]
What if you want to parse a string *as if* it were keyboard input, or build a formatted string without printing it yet? String streams let you treat a `string` variable exactly like a stream — reading from it with `>>` or writing to it with `<<`. This is enormously useful for parsing structured data and for assembling complex output before deciding where it goes.
:::

Add `#include <sstream>` to use string streams.

### `istringstream` — Input from a String (§3.3)

Use `istringstream` to parse values out of a string, token by token:

```cpp
#include <sstream>
#include <string>
#include <iostream>
using namespace std;

int main() {
    string line = "Alice 95 3.8";
    istringstream iss(line);    // wrap the string in a stream

    string name;
    int score;
    double gpa;
    iss >> name >> score >> gpa;   // works just like cin >>

    cout << name  << endl;   // Alice
    cout << score << endl;   // 95
    cout << gpa   << endl;   // 3.8
    return 0;
}
```

A common pattern is reading a whole line with `getline`, then parsing the line with `istringstream`. This is safer than reading directly with `cin >>` because you process one complete line at a time:

```cpp
string line;
while (getline(cin, line)) {       // read each line
    istringstream iss(line);
    int a, b;
    if (iss >> a >> b) {           // try to parse two ints
        cout << "Sum: " << a + b << endl;
    } else {
        cerr << "Bad line: " << line << endl;
    }
}
```

### `ostringstream` — Build a String (§3.4)

Use `ostringstream` to build a formatted string in memory. Call `.str()` to get the resulting string:

```cpp
ostringstream oss;
oss << "Player: " << "Alice"
    << ", Score: " << fixed << setprecision(1) << 98.5;

string result = oss.str();   // "Player: Alice, Score: 98.5"
cout << result << endl;

// Common use: convert a number to a string
ostringstream numToStr;
numToStr << 42;
string s = numToStr.str();   // s = "42"
// C++11 shortcut: s = to_string(42);
```

:::example[Example 3.3 — Parse a CSV-style line]
Given the string `"2024-05-15 14:30 45.7"` representing a date, time, and temperature reading, extract each field into separate variables.

::::answer[Answer]

::::

```cpp
string record = "2024-05-15 14:30 45.7";
istringstream iss(record);

string date, time;
double temp;
iss >> date >> time >> temp;

cout << "Date: " << date << endl;   // 2024-05-15
cout << "Time: " << time << endl;   // 14:30
cout << "Temp: " << temp << endl;   // 45.7
```

Because `>>` splits on whitespace, "2024-05-15" is read as a single token (the hyphen is not whitespace). This is exactly what we want here.
:::

### Practice — String Streams

:::problem[3.7easy]{difficulty="easy"}
How do you get the accumulated string out of an `ostringstream` named `oss`?

::::solution[Solution]
Call `oss.str()` — it returns a `std::string` containing everything written to the stream so far.
::::
:::

:::problem[3.8standard]{difficulty="standard"}
Use an `istringstream` to extract three integer coordinates from the string `"10 -4 7"` and compute their sum.

::::solution[Solution]
```cpp
string data = "10 -4 7";
istringstream iss(data);
int x, y, z;
iss >> x >> y >> z;
cout << "Sum: " << x + y + z << endl;  // 13
```
::::
:::

:::problem[3.9challenge]{difficulty="challenge"}
Write a function that takes an integer and returns it as a zero-padded 6-digit string (e.g., 42 → "000042") using `ostringstream` and `iomanip`.

::::solution[Solution]
```cpp
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

string zeroPad(int n) {
    ostringstream oss;
    oss << setw(6) << setfill('0') << n;
    return oss.str();
}

// zeroPad(42)   → "000042"
// zeroPad(1234) → "001234"
```
::::
:::

## 4 · File Input & Output (§3.5–§3.8)

:::callout-intuition[Intuition]
Reading a file is almost identical to reading from `cin`. Writing to a file is almost identical to writing to `cout`. The key difference is you first *open* a file stream object and connect it to a filename, then use it exactly like `cin`/`cout`. When you're done, you close it.
:::

Add `#include <fstream>` for file streams.

### Reading Files — `ifstream` (§3.5)

```cpp
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

int main() {
    ifstream inFile("data.txt");   // open for reading

    // ALWAYS check that the file opened successfully:
    if (!inFile) {
        cerr << "Error: could not open data.txt" << endl;
        return 1;   // non-zero return = failure
    }

    // Read line by line:
    string line;
    while (getline(inFile, line)) {
        cout << line << endl;
    }

    inFile.close();   // optional but good practice
    return 0;
}
```

You can also use `>>` to read tokens (words/numbers) from a file, just like `cin`:

```cpp
ifstream inFile("scores.txt");
int score;
while (inFile >> score) {    // reads until EOF or bad input
    cout << "Score: " << score << endl;
}
```

### Writing Files — `ofstream` (§3.7)

```cpp
ofstream outFile("output.txt");   // creates (or overwrites!) the file

if (!outFile) {
    cerr << "Error: could not create output.txt" << endl;
    return 1;
}

outFile << "Line 1" << endl;
outFile << "Score: " << 95 << endl;

outFile.close();
```

To *append* to an existing file instead of overwriting it, pass `ios::app` as the second argument:

```cpp
ofstream logFile("log.txt", ios::app);   // append mode
logFile << "New log entry" << endl;
```

:::callout-warning[ofstream overwrites by default]
Opening an existing file with `ofstream` (without `ios::app`) immediately truncates (empties) the file — even before you write a single character. If you need to preserve existing content, use append mode or read the file first.
:::

### File Open Modes

| Mode flag | Meaning |
| --- | --- |
| `ios::in` | Open for reading (default for ifstream) |
| `ios::out` | Open for writing (default for ofstream), truncates |
| `ios::app` | Append — all writes go to end of file |
| `ios::ate` | Open and seek to end immediately |
| `ios::trunc` | Truncate (erase) file on open |
| `ios::binary` | Open in binary mode (no newline translation) |

Combine flags with `|`: `fstream f("data.bin", ios::in | ios::binary);`

:::example[Example 3.4 — §3.6 Parsing and validating an input file]
A file `students.txt` contains lines like `Alice 88` (name and score). Read the file, skip any line where the score is not between 0 and 100, and print valid entries.

::::answer[Answer]

::::

```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

int main() {
    ifstream inFile("students.txt");
    if (!inFile) {
        cerr << "Cannot open students.txt" << endl;
        return 1;
    }

    string line;
    int lineNum = 0;
    while (getline(inFile, line)) {
        lineNum++;
        istringstream iss(line);
        string name;
        int score;

        if (!(iss >> name >> score)) {
            cerr << "Line " << lineNum << ": bad format" << endl;
            continue;
        }
        if (score < 0 || score > 100) {
            cerr << "Line " << lineNum << ": score " << score << " out of range" << endl;
            continue;
        }
        cout << name << ": " << score << endl;
    }

    inFile.close();
    return 0;
}
```

Key pattern: `getline` + `istringstream` gives robust parsing — if a line is malformed, you skip just that line (not the whole file).
:::

:::example[Example 3.5 — §3.8 Saving and retrieving program data]
Write a program that saves three high scores to a file, then reads them back and prints the highest.

::::answer[Answer]

::::

```cpp
#include <iostream>
#include <fstream>
using namespace std;

int main() {
    // --- Save high scores ---
    ofstream outFile("highscores.txt");
    if (!outFile) { cerr << "Write error" << endl; return 1; }
    outFile << 9500 << "\n" << 12340 << "\n" << 8800 << "\n";
    outFile.close();

    // --- Read them back ---
    ifstream inFile("highscores.txt");
    if (!inFile) { cerr << "Read error" << endl; return 1; }

    int score, highest = 0;
    while (inFile >> score) {
        if (score > highest) highest = score;
    }
    inFile.close();

    cout << "Highest score: " << highest << endl;  // 12340
    return 0;
}
```
:::

### Practice — File I/O

:::problem[3.10easy]{difficulty="easy"}
What header is needed for file I/O? What two classes handle file reading vs. file writing?

::::solution[Solution]
Header: `#include <fstream>`.

 Reading: `ifstream` (input file stream).

 Writing: `ofstream` (output file stream).

 (There is also `fstream` which can do both simultaneously.)
::::
:::

:::problem[3.11standard]{difficulty="standard"}
Write a program that reads all integers from a file named `nums.txt` (one per line) and prints their sum and count. Handle the case where the file doesn't exist.

::::solution[Solution]
```cpp
#include <iostream>
#include <fstream>
using namespace std;
int main() {
    ifstream f("nums.txt");
    if (!f) { cerr << "Cannot open nums.txt" << endl; return 1; }
    int n, sum = 0, count = 0;
    while (f >> n) { sum += n; count++; }
    cout << "Count: " << count << ", Sum: " << sum << endl;
    return 0;
}
```
::::
:::

:::problem[3.12challenge]{difficulty="challenge"}
Write a program that copies a text file named `source.txt` to `dest.txt`, prepending each line with its line number (e.g., `1: first line`). Handle file open errors.

::::solution[Solution]
```cpp
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() {
    ifstream src("source.txt");
    ofstream dst("dest.txt");
    if (!src) { cerr << "Cannot open source.txt" << endl; return 1; }
    if (!dst) { cerr << "Cannot create dest.txt"  << endl; return 1; }
    string line;
    int lineNum = 1;
    while (getline(src, line)) {
        dst << lineNum++ << ": " << line << "\n";
    }
    src.close(); dst.close();
    cout << "Done. " << lineNum - 1 << " lines copied." << endl;
    return 0;
}
```
::::
:::

## 5 · Overloading Stream Operators (§3.9)

:::callout-intuition[Intuition]
Right now, `cout << myObject` doesn't work for custom types — the compiler doesn't know how to print a `Student` or a `Point`. By overloading `operator<<`, you teach the stream how to handle your type. This is one of C++'s most elegant features: your type becomes a first-class citizen of the stream system.
:::

:::callout-connect[Prerequisite Note]
This section previews classes and operator overloading, which are covered fully in Chapter 13. You don't need to master all the details now — focus on the pattern and what the syntax means at a high level.
:::

### Overloading `operator<<`

The signature for overloading the output stream operator is always:

```cpp
ostream& operator<<(ostream& os, const MyType& obj) {
    os << /* output obj's fields */ ;
    return os;   // MUST return os to allow chaining
}
```

:::example[Example 3.6 — Overloading << for a Point struct]
```cpp
#include <iostream>
using namespace std;

struct Point {
    double x;
    double y;
};

// Teach cout how to print a Point:
ostream& operator<<(ostream& os, const Point& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
}

int main() {
    Point a = {3.0, 4.0};
    Point b = {-1.5, 2.5};

    cout << "A = " << a << endl;          // A = (3, 4)
    cout << "B = " << b << endl;          // B = (-1.5, 2.5)
    cout << "Points: " << a << ", " << b; // chaining works too
    return 0;
}
```

Why `return os`? Because `cout << a << b` is actually `(cout << a) << b` — the result of the first `<<` must be the stream so the second `<<` can chain onto it.
:::

### Overloading `operator>>`

The input operator uses a non-const reference (you're modifying the object) and an `istream`:

```cpp
istream& operator>>(istream& is, Point& p) {
    is >> p.x >> p.y;
    return is;
}

// Usage:
Point p;
cin >> p;   // user types: 3.5 2.1
cout << p;  // (3.5, 2.1)
```

### Practice — Stream Operators

:::problem[3.13easy]{difficulty="easy"}
Why must `operator<<` return `ostream&` (a reference to the stream)?

::::solution[Solution]
To enable **chaining**. When you write `cout << a << b`, it evaluates as `(cout << a) << b`. The expression `cout << a` must produce the stream object so that the second `<< b` can continue writing to it. If it returned `void` or a copy, chaining would fail.
::::
:::

:::problem[3.14standard]{difficulty="standard"}
Given this struct, write `operator<<` that prints it as `[R, G, B]`:
 `struct Color { int r, g, b; };`

::::solution[Solution]
```cpp
ostream& operator<<(ostream& os, const Color& c) {
    os << "[" << c.r << ", " << c.g << ", " << c.b << "]";
    return os;
}
// Color red = {255, 0, 0};
// cout << red;  →  [255, 0, 0]
```
::::
:::

## 6 · Full Worked Examples

:::example[Example 3.7 — Grade book: read from file, write report]
A file `grades.txt` has lines of the form `StudentName Score`. Read all entries, compute the class average, and write a report file `report.txt` that includes each student's name, score, letter grade, and the class average at the bottom.

::::answer[Answer]

::::

```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>
using namespace std;

char letterGrade(int score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
}

int main() {
    ifstream inFile("grades.txt");
    if (!inFile) { cerr << "Cannot open grades.txt" << endl; return 1; }

    vector<string> names;
    vector<int>    scores;
    string line;
    while (getline(inFile, line)) {
        istringstream iss(line);
        string name; int score;
        if (iss >> name >> score) {
            names.push_back(name);
            scores.push_back(score);
        }
    }
    inFile.close();

    // Compute average
    double sum = 0;
    for (int s : scores) sum += s;
    double avg = (scores.empty()) ? 0 : sum / scores.size();

    // Write report
    ofstream outFile("report.txt");
    if (!outFile) { cerr << "Cannot create report.txt" << endl; return 1; }

    outFile << fixed << setprecision(1);
    outFile << left << setw(15) << "Name"
            << right << setw(6) << "Score"
            << setw(6) << "Grade" << "\n";
    outFile << string(27, '-') << "\n";
    for (int i = 0; i < (int)names.size(); i++) {
        outFile << left  << setw(15) << names[i]
                << right << setw(6)  << scores[i]
                << setw(6) << letterGrade(scores[i]) << "\n";
    }
    outFile << string(27, '-') << "\n";
    outFile << "Class average: " << avg << "\n";
    outFile.close();

    cout << "Report written to report.txt" << endl;
    return 0;
}
```

This example combines: `ifstream` + `getline` + `istringstream` for reading, `vector` for storage (Ch 6 preview), a helper function, and `ofstream` + `iomanip` for formatted writing.
:::

:::summary
## Chapter 3 Summary

| Concept | Key Syntax / Rule |
| --- | --- |
| Streams | `cout` (output), `cin` (input), `cerr` (errors) |
| Read full line | `getline(cin, str)` — reads spaces; call `cin.ignore()` after `cin >>` first |
| Stream state | `if (cin >> n)` — checks success; `cin.clear()` resets error flags |
| setw(n) | Field width (not sticky); right-aligned by default |
| fixed / setprecision(n) | Decimal places for doubles; both sticky |
| setfill(c) | Fill character for padding (default space); sticky |
| hex / oct / dec | Change integer output base; sticky |
| istringstream | `#include <sstream>`; parse string like `cin` |
| ostringstream | Build string like `cout`; retrieve with `.str()` |
| ifstream | `#include <fstream>`; open file for reading; check `if (!f)` |
| ofstream | Opens & truncates by default; use `ios::app` to append |
| operator<< | Returns `ostream&` to enable chaining; takes `const MyType&` |
:::

## Mixed Practice

:::problem[M.1easy]{difficulty="easy"}
What is the output of: `cout << setw(5) << 7 << setw(5) << 7;`

::::solution[Solution]
`    7    7` — each 7 is right-aligned in a field of 5 characters (4 spaces + digit). `setw` resets after each use, so you need to call it before each value.
::::
:::

:::problem[M.2easy]{difficulty="easy"}
Name two differences between reading with `cin >>` and reading with `getline()`.

::::solution[Solution]
(1) `cin >>` skips leading whitespace and stops at whitespace — reads one token. `getline()` reads everything including spaces up to a newline.

 (2) `cin >>` leaves the newline in the buffer; `getline()` consumes the newline as its delimiter.
::::
:::

:::problem[M.3standard]{difficulty="standard"}
Write a program that appends a timestamp string to a log file `app.log` each time it runs. The timestamp can just be a fixed string for now, like `"[RUN] Program started\n"`.

::::solution[Solution]
```cpp
#include <fstream>
#include <iostream>
using namespace std;
int main() {
    ofstream log("app.log", ios::app);
    if (!log) { cerr << "Cannot open app.log" << endl; return 1; }
    log << "[RUN] Program started" << "\n";
    log.close();
    cout << "Log entry added." << endl;
    return 0;
}
```
::::
:::

:::problem[M.4standard]{difficulty="standard"}
Use an `ostringstream` to build the string `"Score: 42/100 (42.0%)"` from integer variables `score=42` and `total=100`.

::::solution[Solution]
```cpp
int score = 42, total = 100;
ostringstream oss;
oss << "Score: " << score << "/" << total
    << " (" << fixed << setprecision(1)
    << (100.0 * score / total) << "%)";
string result = oss.str();
cout << result << endl;  // Score: 42/100 (42.0%)
```
::::
:::

:::problem[M.5challenge]{difficulty="challenge"}
A file contains lines in the format `ITEM QUANTITY PRICE` (e.g., `Widget 3 9.99`). Write a program that reads each line and prints a running total of `quantity × price` for all items, plus a grand total at the end.

::::solution[Solution]
```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;
int main() {
    ifstream f("inventory.txt");
    if (!f) { cerr << "Cannot open inventory.txt" << endl; return 1; }
    string line;
    double grandTotal = 0;
    cout << fixed << setprecision(2);
    while (getline(f, line)) {
        istringstream iss(line);
        string item; int qty; double price;
        if (!(iss >> item >> qty >> price)) continue;
        double subtotal = qty * price;
        grandTotal += subtotal;
        cout << left << setw(12) << item
             << right << setw(4) << qty << " x $"
             << setw(6) << price << " = $"
             << setw(8) << subtotal << "\n";
    }
    cout << string(40, '-') << "\n";
    cout << right << setw(33) << "Grand total: $" << setw(8) << grandTotal << "\n";
    return 0;
}
```
::::
:::

## LeetCode Practice

:::callout-tip[LeetCode Problems for Chapter 3]
These problems involve string parsing and manipulation — the same skills that make string streams powerful. Practice reading structured input and building formatted output. Solve in C++.

| # | Problem | Difficulty | Why it fits |
| --- | --- | --- | --- |
| [#14](https://leetcode.com/problems/longest-common-prefix/) | Longest Common Prefix | Easy | String parsing — iterate characters and compare, just like parsing stream tokens. Also practices defensive coding (§3.5 validation theme). |
| [#13](https://leetcode.com/problems/roman-to-integer/) | Roman to Integer | Easy | Parsing structured character input — mirrors reading and interpreting tokens from a stream. |
| [#9](https://leetcode.com/problems/palindrome-number/) | Palindrome Number | Easy | One elegant approach uses `to_string()` (or an `ostringstream`) to convert the number to a string, then checks it — a direct application of §3.4. |

**Tip for #9:** Try two approaches — one purely arithmetic (no strings), and one using `to_string()` or `ostringstream` to convert the number to a string and compare. Both are valid; the string approach directly exercises this chapter's material.
:::
