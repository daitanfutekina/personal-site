---
title: "Chapter 9 — Searching & Sorting Algorithms"
source: "markdown"
---

CSE 1384

DSA

# Chapter 9 — Searching & Sorting Algorithms

§9.1 – §9.7

## §9.1 · Searching and Algorithms

A **searching algorithm** locates a target value within a collection. The two fundamental strategies are **linear search** (scan every element in order) and **binary search** (halve the search space each step on a sorted collection). Choosing the right one depends entirely on whether the data is sorted and how often you search.

### Linear search

Linear search examines each element from left to right until it finds the target or exhausts the array. It works on **unsorted** data and is the only option when sorting is not feasible.

```cpp
// Returns index of target, or -1 if not found
int linearSearch(const vector<int>& v, int target) {
    for (int i = 0; i < (int)v.size(); ++i)
        if (v[i] == target) return i;
    return -1;
}

int main() {
    vector<int> data = {4, 7, 2, 9, 1, 5};
    cout << linearSearch(data, 9) << '\n';   // 3
    cout << linearSearch(data, 8) << '\n';   // -1
}
```

| Property | Linear Search |
| --- | --- |
| Requires sorted data? | No |
| Best case | O(1) — target is at index 0 |
| Worst / Average case | O(n) — target at end or not found |
| Space | O(1) |
| Best for | Small arrays, unsorted data, searching once |

:::callout-intuition
Linear search is like looking for your keys by checking every drawer one by one. It always works, but it's slow. If your keys were kept in alphabetical order, you could do much better — that's the idea behind binary search.
:::

## §9.2 – §9.3 · Binary Search

Binary search requires a **sorted** array. It repeatedly halves the search range: compare the target to the middle element, then eliminate the half that cannot contain the target. Each comparison discards half the remaining candidates — $n$ elements requires at most $\lceil \log_2 n \rceil$ comparisons.

### Visual trace — find 7 in {1, 3, 5, 7, 9, 11, 13}

Array indices 0–6. lo = left bound, hi = right bound, mid = midpoint being checked.

Step 1 — mid = (0+6)/2 = 3 → arr[3] = 7 == target ✓

1

lo=0

3

5

7

mid=3

9

11

13

hi=6

Found at index 3 in just 1 comparison! (vs up to 7 for linear search)

Harder trace — find 11 in the same array:

1

lo=0

3

5

7

mid=3

9

11

13

hi=6

arr[3]=7 < 11 → target in right half → lo = mid+1 = 4

1

3

5

7

9

lo=4

11

mid=5

13

hi=6

arr[5]=11 == target → found at index 5 in 2 comparisons.

### Iterative implementation

```cpp
// Returns index of target in sorted array v, or -1 if not found
int binarySearch(const vector<int>& v, int target) {
    int lo = 0, hi = (int)v.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;   // avoids integer overflow vs (lo+hi)/2
        if      (v[mid] == target) return mid;
        else if (v[mid] <  target) lo = mid + 1;
        else                       hi = mid - 1;
    }
    return -1;   // not found
}

int main() {
    vector<int> sorted = {1, 3, 5, 7, 9, 11, 13};
    cout << binarySearch(sorted, 7)  << '\n';  // 3
    cout << binarySearch(sorted, 11) << '\n';  // 5
    cout << binarySearch(sorted, 4)  << '\n';  // -1
}
```

:::callout-pitfall
Integer overflow

:

(lo + hi) / 2

can overflow when both

lo

and

hi

are large positive ints near `INT_MAX`. The safe idiom is

lo + (hi - lo) / 2

— subtracting first keeps intermediate values small.
:::

:::callout-pitfall
Infinite loop

: forgetting the

+1

or

-1

when updating

lo

/

hi

can make the loop stall. If

v[mid] < target

and you set

lo = mid

(not

mid + 1

), and

mid

doesn't change next iteration — you spin forever. Always

narrow

the range.
:::

### Binary search variants — lower bound and upper bound

Two common variants find the *first* or *last* position where a value could be inserted while keeping the array sorted. The C++ STL provides these as `lower_bound` and `upper_bound`.

```cpp
#include <algorithm>
#include <vector>
using namespace std;

int main() {
    vector<int> v = {1, 3, 3, 3, 7, 9};

    // lower_bound: first position >= target
    auto lo = lower_bound(v.begin(), v.end(), 3);
    cout << (lo - v.begin()) << '\n';   // 1 (first 3 at index 1)

    // upper_bound: first position > target
    auto hi = upper_bound(v.begin(), v.end(), 3);
    cout << (hi - v.begin()) << '\n';   // 4 (first element after all 3s)

    // Count occurrences of 3:
    cout << (hi - lo) << '\n';          // 3
}
```

### Hand-coding lower bound (for interviews)

```cpp
// Returns index of first element >= target; returns n if none exists
int lowerBound(const vector<int>& v, int target) {
    int lo = 0, hi = (int)v.size();   // hi = n (one past end)
    while (lo < hi) {                 // note: lo < hi, not lo <= hi
        int mid = lo + (hi - lo) / 2;
        if (v[mid] < target) lo = mid + 1;
        else                  hi = mid;    // mid could be the answer
    }
    return lo;
}
// lowerBound({1,3,3,3,7,9}, 3) → 1
// lowerBound({1,3,3,3,7,9}, 5) → 4  (index where 5 would be inserted)
```

:::callout-connect
Binary search appears far beyond just "find a value." Whenever you can phrase a problem as "find the smallest value where some condition first becomes true," binary search on the answer applies. This pattern —

binary search on the answer

— solves classics like "minimum possible maximum," "allocate books," and Koko eating bananas (LeetCode #875). You'll encounter it in DSA and coding interviews.
:::

## §9.4 – §9.7 · Sorting Algorithms

Sorting arranges elements into a defined order. The three O(n²) sorts below are taught because their logic is transparent and their behavior is easy to trace by hand. Understanding them builds the intuition you need for O(n log n) sorts (merge sort, quicksort) in later courses.

Bubble Sort

Best: O(n)

Average: O(n²)

Worst: O(n²)

Space: O(1) · Stable ✓

Selection Sort

Best: O(n²)

Average: O(n²)

Worst: O(n²)

Space: O(1) · Unstable ✗

Insertion Sort

Best: O(n) ← nearly sorted

Average: O(n²)

Worst: O(n²)

Space: O(1) · Stable ✓

std::sort (introsort)

Best: O(n log n)

Average: O(n log n)

Worst: O(n log n)

Space: O(log n) · Unstable ✗

### §9.5 Bubble Sort

Repeatedly compare adjacent pairs and swap if out of order. After each full pass, the largest unsorted element has "bubbled" to its final position. An *early-exit* flag makes it O(n) on already-sorted data.

```cpp
void bubbleSort(vector<int>& v) {
    int n = v.size();
    for (int pass = 0; pass < n - 1; ++pass) {
        bool swapped = false;
        for (int j = 0; j < n - 1 - pass; ++j) {
            if (v[j] > v[j + 1]) {
                swap(v[j], v[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;   // already sorted — early exit
    }
}
```

Full trace of `{5, 3, 8, 1, 4}`:

| Pass | Comparisons | Array after pass | Swaps? |
| --- | --- | --- | --- |
| 0 | j=0..3: swap(5,3), no, swap(8,1), swap(8,4) | {3, 5, 1, 4, 8} | Yes |
| 1 | j=0..2: no, swap(5,1), swap(5,4) | {3, 1, 4, 5, 8} | Yes |
| 2 | j=0..1: swap(3,1), no | {1, 3, 4, 5, 8} | Yes |
| 3 | j=0: no swap | {1, 3, 4, 5, 8} ✓ | No → break |

### §9.6 Selection Sort

Divide the array into a sorted left portion and an unsorted right portion. In each pass, scan the unsorted portion for its minimum, then swap it into the next sorted position. Exactly n−1 swaps total.

```cpp
void selectionSort(vector<int>& v) {
    int n = v.size();
    for (int i = 0; i < n - 1; ++i) {
        // Find index of minimum in v[i..n-1]
        int minIdx = i;
        for (int j = i + 1; j < n; ++j)
            if (v[j] < v[minIdx]) minIdx = j;
        // Swap minimum into sorted position
        if (minIdx != i) swap(v[i], v[minIdx]);
    }
}
```

Trace of `{5, 3, 8, 1, 4}`:

| i | Min in unsorted portion | Swap | Array after |
| --- | --- | --- | --- |
| 0 | v[3]=1 | swap(v[0],v[3]) | {**1**, 3, 8, 5, 4} |
| 1 | v[1]=3 | no swap needed | {1, **3**, 8, 5, 4} |
| 2 | v[4]=4 | swap(v[2],v[4]) | {1, 3, **4**, 5, 8} |
| 3 | v[3]=5 | no swap needed | {1, 3, 4, **5**, 8} ✓ |

:::callout-intuition
Selection sort makes the fewest

swaps

(at most n−1) but always does the same number of

comparisons

regardless of input order. Useful when writes are expensive (e.g., flash memory). Bubble sort does more swaps but can exit early on nearly-sorted data.
:::

### §9.7 Insertion Sort

Build the sorted portion one element at a time. Take the next unsorted element and *insert* it into its correct position in the sorted prefix by shifting larger elements rightward. Excellent for nearly-sorted data — O(n) in the best case.

```cpp
void insertionSort(vector<int>& v) {
    int n = v.size();
    for (int i = 1; i < n; ++i) {
        int key = v[i];     // element to insert
        int j   = i - 1;
        // Shift elements greater than key one position right
        while (j >= 0 && v[j] > key) {
            v[j + 1] = v[j];
            --j;
        }
        v[j + 1] = key;     // place key in its correct slot
    }
}
```

Trace of `{5, 3, 8, 1, 4}`:

| i | key | Shifts | Array after insertion |
| --- | --- | --- | --- |
| 1 | 3 | shift 5 right | {3, 5, 8, 1, 4} |
| 2 | 8 | none (8 > 5) | {3, 5, 8, 1, 4} |
| 3 | 1 | shift 8, 5, 3 right | {1, 3, 5, 8, 4} |
| 4 | 4 | shift 8, 5 right | {1, 3, 4, 5, 8} ✓ |

:::callout-key
Stability

means equal elements keep their original relative order after sorting. Bubble and insertion sort are stable; selection sort is not. Stability matters when sorting objects by one field that have equal keys in another (e.g., sort employees by department, preserving alphabetical name order within each department).
:::

### Choosing a sorting algorithm

| Scenario | Recommended | Why |
| --- | --- | --- |
| General-purpose production code | `std::sort` | O(n log n) guaranteed, highly optimized |
| Nearly-sorted data | Insertion sort | O(n) best case; low overhead for small n |
| Minimizing writes (e.g. flash) | Selection sort | Exactly n−1 swaps regardless of input |
| Need stable sort | `std::stable_sort` | O(n log n), preserves relative order of equals |
| Teaching / interviews | Insertion sort | Most practically used of the O(n²) trio; real libraries use it for small sub-arrays |

#### Putting it all together — sort then binary search

```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> data = {42, 17, 83, 5, 61, 29, 75};

    // Step 1: sort (use std::sort for production)
    sort(data.begin(), data.end());
    // {5, 17, 29, 42, 61, 75, 83}

    // Step 2: binary search for 61
    int target = 61;
    int lo = 0, hi = (int)data.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if      (data[mid] == target) { cout << "Found at " << mid << '\n'; break; }
        else if (data[mid] <  target)  lo = mid + 1;
        else                            hi = mid - 1;
    }
    // Found at 4

    // Step 3: check for existence using STL
    if (binary_search(data.begin(), data.end(), 29))
        cout << "29 is in the list\n";
}
```

## §9.8 – §9.10 · STL Search & Sort Algorithms

The C++ Standard Library ships production-quality implementations of every algorithm covered in this chapter. Use them in real code — hand-rolling sorts is only appropriate for learning or custom types.

### Sorting

```cpp
#include <algorithm>
#include <vector>
using namespace std;

vector<int> v = {5, 2, 8, 1, 9, 3};

// Ascending (default)
sort(v.begin(), v.end());                       // {1,2,3,5,8,9}  O(n log n) — introsort

// Descending
sort(v.begin(), v.end(), greater<int>());       // {9,8,5,3,2,1}

// Stable sort — equal elements keep original relative order
stable_sort(v.begin(), v.end());                // O(n log² n) or O(n log n) with extra memory

// Sort only part of the array
sort(v.begin(), v.begin() + 3);                 // sort first 3 elements only

// Custom comparator (sort structs by a field)
struct Student { string name; int gpa; };
vector<Student> students = {{"Alice",3},{"Bob",4},{"Carol",3}};
sort(students.begin(), students.end(),
     [](const Student& a, const Student& b){ return a.gpa > b.gpa; }); // by GPA desc
```

### Searching (requires sorted range)

```cpp
vector<int> s = {1, 2, 3, 5, 5, 8, 9};   // must be sorted

// Existence check — O(log n)
bool found = binary_search(s.begin(), s.end(), 5);   // true

// First position >= target (lower bound) — O(log n)
auto lo = lower_bound(s.begin(), s.end(), 5);
cout << *lo << "
";              // 5 (index 3)
cout << (lo - s.begin()) << "
"; // 3 (position)

// First position > target (upper bound) — O(log n)
auto hi = upper_bound(s.begin(), s.end(), 5);
cout << (hi - s.begin()) << "
"; // 5 (past last 5)

// Count occurrences of 5
int count = hi - lo;              // 2

// Check range [lo, hi) contains exactly what you want
if (lo != s.end() && *lo == 5)
    cout << "Found 5 at index " << (lo - s.begin()) << "
";
```

### Other useful <algorithm> functions

| Function | Complexity | Description |
| --- | --- | --- |
| `min_element / max_element` | O(n) | Iterator to smallest/largest element in range |
| `count(b,e,val)` | O(n) | Count occurrences of val in [b,e) |
| `find(b,e,val)` | O(n) | Iterator to first occurrence, or e if not found |
| `reverse(b,e)` | O(n) | Reverse elements in place |
| `rotate(b,mid,e)` | O(n) | Cyclic rotate: [mid,e) then [b,mid) |
| `nth_element(b,nth,e)` | O(n) avg | Rearrange so \*nth is what it would be if sorted; O(n) average! |
| `partition(b,e,pred)` | O(n) | Move elements satisfying pred before those that don't |
| `unique(b,e)` | O(n) | Remove consecutive duplicates (sort first!); returns new end |
| `accumulate(b,e,init)` | O(n) | Sum (or custom fold) of range — in <numeric> |

:::callout-key
nth\_element

is underused but powerful. It puts the k-th smallest element in position k in O(n) average time — without fully sorting the array. Use it for "top-k" problems and median finding. Under the hood it runs an incomplete quicksort (introselect).
:::

#### Worked Example — K-th Largest Element

```cpp
// Find the k-th largest element in O(n) average time
int kthLargest(vector<int> v, int k) {
    // nth_element places the (n-k)-th element in sorted order at position n-k
    int pos = (int)v.size() - k;
    nth_element(v.begin(), v.begin() + pos, v.end());
    return v[pos];
}

int main() {
    vector<int> data = {3, 2, 1, 5, 6, 4};
    cout << kthLargest(data, 2) << "
";  // 5 (2nd largest)
}
```

This beats a full O(n log n) sort when k is small. The heap-based approach (maintain a min-heap of size k) runs O(n log k) and uses O(k) space — better when n is enormous and k is tiny.

:::summary
### Chapter 9 — Key Takeaways

- **Linear search** — O(n), no prerequisites. Scan every element. Use when data is unsorted or tiny.
- **Binary search** — O(log n), requires sorted data. Halves the search space each step. Safe midpoint: `lo + (hi - lo) / 2`.
- Loop invariant: `lo <= hi`; narrow range with `lo = mid + 1` or `hi = mid - 1` to avoid infinite loops.
- **lower\_bound / upper\_bound** find insertion positions and count occurrences in O(log n).
- **Bubble sort** — adjacent swaps; O(n) best with early-exit flag; stable.
- **Selection sort** — finds minimum each pass; exactly n−1 swaps; unstable.
- **Insertion sort** — shifts elements rightward; O(n) on nearly-sorted input; stable. Best of the three for small/nearly-sorted arrays.
- All three simple sorts are O(n²) average/worst. Use `std::sort` (O(n log n)) for real code.
- **Stability** preserves the relative order of equal elements — important when sorting multi-field records.
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Classic Binary Search

Given a sorted array of distinct integers and a target, return the index of the target or `-1` if not found. Write it from scratch without using STL search functions.

::::solution[Solution]
```cpp
int search(const vector<int>& v, int target) {
    int lo = 0, hi = (int)v.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if      (v[mid] == target) return mid;
        else if (v[mid] <  target) lo = mid + 1;
        else                       hi = mid - 1;
    }
    return -1;
}
```

Termination guarantee: each iteration either returns or strictly shrinks `[lo, hi]`. Loop exits when `lo > hi` — empty range.
::::
:::

:::problem{difficulty="easy"}
P2 — Search Insert Position

Given a sorted array and a target, return the index where the target is found, or the index where it *would be inserted* to keep the array sorted. Example: `{1,3,5,6}`, target=2 → `1`. Target=7 → `4`.

::::solution[Solution]
```cpp
int searchInsert(const vector<int>& v, int target) {
    int lo = 0, hi = (int)v.size();   // hi = size (past-end is valid insert pos)
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (v[mid] < target) lo = mid + 1;
        else                  hi = mid;
    }
    return lo;   // lo == hi: first position >= target
}
// {1,3,5,6}, target=5 → 2
// {1,3,5,6}, target=2 → 1
// {1,3,5,6}, target=7 → 4
```

This is the **lower bound** pattern — loop uses `lo < hi` and `hi = mid` (not `mid-1`). When the loop exits, `lo` is the first index ≥ target.
::::
:::

:::problem{difficulty="easy"}
P3 — Trace Insertion Sort

Without running the code, manually trace insertion sort on `{6, 2, 9, 4, 1}`. Show the array state after each outer iteration (`i = 1` through `i = 4`).

::::solution[Solution]
| i | key | Array after inserting key |
| --- | --- | --- |
| 1 | 2 | {2, 6, 9, 4, 1} |
| 2 | 9 | {2, 6, 9, 4, 1} (no shifts — 9 > 6) |
| 3 | 4 | {2, 4, 6, 9, 1} (shift 9, 6 right) |
| 4 | 1 | {1, 2, 4, 6, 9} ✓ (shift 9, 6, 4, 2 right) |
::::
:::

:::problem{difficulty="standard"}
P4 — Count Occurrences in Sorted Array

Given a sorted array and a target, count how many times the target appears. Do it in O(log n) using binary search — not a linear scan.

::::solution[Solution]
```cpp
// First position >= target
int lowerB(const vector<int>& v, int t) {
    int lo=0, hi=(int)v.size();
    while(lo<hi){int m=lo+(hi-lo)/2; if(v[m]<t)lo=m+1; else hi=m;} return lo;
}
// First position > target
int upperB(const vector<int>& v, int t) {
    int lo=0, hi=(int)v.size();
    while(lo<hi){int m=lo+(hi-lo)/2; if(v[m]<=t)lo=m+1; else hi=m;} return lo;
}

int countOccurrences(const vector<int>& v, int target) {
    return upperB(v, target) - lowerB(v, target);
}
// {1,2,3,3,3,4,5}, target=3 → 3
// {1,2,3,3,3,4,5}, target=6 → 0
```

`upperBound - lowerBound` gives the count in O(log n). The STL version: `upper_bound(v.begin(),v.end(),t) - lower_bound(v.begin(),v.end(),t)`.
::::
:::

:::problem{difficulty="challenge"}
P5 — First Bad Version (Binary Search on Answer)

You have `n` versions labeled 1 through `n`. An API `bool isBad(int version)` returns true if a version is bad; all versions after the first bad one are also bad. Find the *first* bad version using the minimum number of API calls.

::::solution[Solution]
```cpp
// isBad() is a given API (simulated here for illustration)
bool isBad(int v) { return v >= 4; }  // example: versions 4,5 are bad out of 1..5

int firstBadVersion(int n) {
    int lo = 1, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (isBad(mid)) hi = mid;      // mid might be the first bad — keep it
        else            lo = mid + 1;  // mid is good — first bad is later
    }
    return lo;   // lo == hi: first bad version
}
// firstBadVersion(5) → 4
```

Classic **lower-bound binary search**: we're finding the first position where `isBad` becomes true. Key: use `hi = mid` (not `mid-1`) because `mid` itself could be the answer.
::::
:::

:::problem{difficulty="easy"}
P6 — lower\_bound as Insert Position

Given a sorted array `{1, 3, 5, 7, 9}`, use `lower_bound` to find the index where 6 should be inserted to keep the array sorted. Then insert it and print the result. Do this with STL in 3 lines.

::::solution[Solution]
```cpp
vector<int> v = {1, 3, 5, 7, 9};
auto it = lower_bound(v.begin(), v.end(), 6);   // iterator to first element >= 6 → points at 7
cout << "Insert at index " << (it - v.begin()) << "
";  // 3
v.insert(it, 6);
// {1, 3, 5, 6, 7, 9}
```
::::
:::

:::problem{difficulty="standard"}
P7 — Count Range Occurrences

Given a sorted vector of integers that may have duplicates and a target value, return how many times the target appears. Use only STL binary search functions, not `std::count`. What is the time complexity?

::::solution[Solution]
```cpp
int countOccurrences(const vector<int>& v, int target) {
    auto lo = lower_bound(v.begin(), v.end(), target);   // first occurrence
    auto hi = upper_bound(v.begin(), v.end(), target);   // one past last
    return (int)(hi - lo);
}
// Example: {1,3,3,3,5,7} target=3 → lo at index 1, hi at index 4 → 3
```

**Complexity:** O(log n) — two binary searches. The naïve linear scan is O(n). This is the standard "find frequency in sorted array" pattern.
::::
:::

:::problem{difficulty="standard"}
P8 — Custom Sort with Comparator

Sort a vector of strings first by length (shortest first), then alphabetically for equal-length strings. Use `std::sort` with a lambda comparator. Test on: `{"banana","fig","apple","kiwi","pear","grape"}`.

::::solution[Solution]
```cpp
vector<string> fruits = {"banana","fig","apple","kiwi","pear","grape"};
sort(fruits.begin(), fruits.end(),
    [](const string& a, const string& b) {
        if (a.size() != b.size()) return a.size() < b.size();  // shorter first
        return a < b;                                            // alphabetical tie-break
    });
// Result: {"fig", "kiwi", "pear", "apple", "grape", "banana"}
```

The comparator must be a *strict weak ordering*: irreflexive (a < a is false), asymmetric (a < b → !(b < a)), transitive. Violating these causes undefined behavior in `std::sort`.
::::
:::

:::callout-tip
All five of these problems are pure binary search — no sorting required. They progress from textbook implementation to the "binary search on answer" pattern you'll encounter constantly in DSA.

| # | Problem | Difficulty | Pattern |
| --- | --- | --- | --- |
| 704 | [Binary Search](https://leetcode.com/problems/binary-search/) | Easy | Textbook lo/mid/hi implementation |
| 35 | [Search Insert Position](https://leetcode.com/problems/search-insert-position/) | Easy | Lower-bound variant |
| 278 | [First Bad Version](https://leetcode.com/problems/first-bad-version/) | Easy | Binary search on condition (minimize API calls) |
| 374 | [Guess Number Higher or Lower](https://leetcode.com/problems/guess-number-higher-or-lower/) | Easy | Binary search with external oracle |
| 744 | [Find Smallest Letter Greater Than Target](https://leetcode.com/problems/find-smallest-letter-greater-than-target/) | Easy | Upper-bound / wrap-around edge case |
:::
