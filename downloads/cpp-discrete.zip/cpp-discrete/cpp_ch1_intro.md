---
title: "Introduction to C++"
source: "cpp_ch1_intro.html"
---

CSE 1384

# Introduction to C++

## Overview

This chapter answers one question before writing a single line of code: *what is a program, and how does the machine run it?* You'll write your first working C++ program, learn why whitespace and precision are non-negotiable, and build a mental model of the compile–link–run pipeline that underlies every project in this course.

:::callout-key[What you'll be able to do after this chapter]
- Write, compile, and run a basic C++ program that reads input and writes output
- Explain the difference between syntax errors, runtime errors, and logic errors
- Describe what a CPU, RAM, and compiler do in plain English
- Decompose a simple word problem into an algorithm before touching the keyboard
:::

## 1. What Is Programming? (§1.1, §1.6, §1.11)

:::callout-intuition[Intuition]
A computer is the fastest errand-runner in existence — it will do exactly what you say, billions of times per second, without getting tired or bored. The catch: it only understands an incredibly precise, unambiguous language. **Programming is the act of translating a human idea into that language.** The computer does not understand intent; it only understands instructions.
:::

:::definition[Definition 1.1 — Program]
A **program** is a sequence of instructions that a computer can execute to accomplish a task. Each instruction is unambiguous and performs one small, well-defined operation.
:::

:::definition[Definition 1.2 — Programming Language]
A **programming language** is a formal notation with strict syntax rules for writing programs. C++ is a compiled, statically-typed, general-purpose language released in 1985 by Bjarne Stroustrup as an extension of C.
:::

### Why C++?

You are a Computer Engineering student, not a web developer. C++ matters to you for three concrete reasons:

- **Performance:** C++ gives you direct control over memory and hardware. Embedded systems, game engines, operating systems, and real-time signal processors are written in C++ (or C) because no other language is fast enough.
- **Portability:** A C++ program compiled for one architecture can be recompiled for another with minimal changes. The same language runs on your laptop, an FPGA co-processor, and an Arduino.
- **Foundation:** Every concept you learn here — pointers, stack frames, object layout in memory — maps directly onto the hardware you'll design in Digital Devices and the algorithms you'll analyze in Honors DSA.

:::callout-connect[Connection to your CE curriculum]
When you take Digital Devices & Logic Design, you will design circuits at the gate level. Those circuits implement the same operations C++ performs: arithmetic, comparisons, data movement. Understanding how C++ instructions execute on a CPU makes those circuits concrete rather than abstract.
:::

### A brief language history (§1.9)

C++ did not appear from nowhere. The lineage matters because you'll encounter code from every era:

- **1972 — C:** Dennis Ritchie at Bell Labs. Low-level, fast, used to write Unix. No objects, manual memory management.
- **1985 — C++:** Bjarne Stroustrup added classes, operator overloading, and templates on top of C. The name "C++" is a programming joke — `++` is the increment operator, so C++ means "one better than C."
- **2011 — C++11:** A major modernization. Added `auto`, range-based for loops, lambdas, smart pointers. This textbook uses C++11 features throughout.
- **2014/17/20/23:** Incremental improvements. Most industry code today targets C++17.

## 2. Your First C++ Program (§1.2, §1.3)

:::callout-intuition[Intuition]
Before worrying about what every word means, just get something running. A working program that you can modify is worth more than a perfect understanding of a program you've never compiled. Read the program below as a paragraph, then we'll dissect it line by line.
:::

Here is the simplest meaningful C++ program — it reads your name from the keyboard and greets you:

```cpp
#include <iostream>
#include <string>
using namespace std;

int main() {
    string userName;

    cout << "Enter your name: ";
    cin  >> userName;
    cout << "Hello, " << userName << "!" << endl;

    return 0;
}
```

**Read it aloud:** "Include the input/output library. Include the string library. Use the standard namespace. Define main — the starting point. Create a string variable. Print a prompt. Read a word into userName. Print a greeting. Return zero (success)."

### Anatomy of a C++ program — line by line

| Line | What it does | Why it's needed |
| --- | --- | --- |
| `#include <iostream>` | Loads the input/output library | Without it, `cout` and `cin` don't exist |
| `#include <string>` | Loads the string class | Lets you use `string` as a type |
| `using namespace std;` | Tells the compiler "when I write `cout`, I mean `std::cout`" | Avoids typing `std::` everywhere |
| `int main() { ... }` | The entry point of every program | The OS calls `main()` when your program runs |
| `cout << "...";` | Prints to the terminal | `cout` = character output, `<<` = "send to" |
| `cin >> userName;` | Reads one word of input | `cin` = character input, `>>` = "read into" |
| `return 0;` | Signals success to the OS | Convention: 0 means "no error" |

:::callout-tip[The semicolon rule]
Every *statement* in C++ ends with a semicolon `;`. Preprocessor directives (`#include`, `#define`) and block closers (`}`) do **not**. Forgetting a semicolon is the single most common beginner error — the compiler error message will often point to the line *after* the one missing it, which is confusing at first.
:::

### Output with `cout`

`cout` (pronounced "see-out") outputs text to the terminal. You chain pieces together with `<<` (called the *insertion operator*). `endl` ends the current line (equivalent to pressing Enter):

```cpp
cout << "The answer is " << 42 << endl;
// Output: The answer is 42
```

You can chain as many pieces as you like — strings, numbers, variables — as long as each is separated by `<<`.

### Input with `cin` (§1.3)

`cin` (pronounced "see-in") reads from the keyboard. The `>>` operator (the *extraction operator*) places the value into a variable. `cin` skips leading whitespace and stops at the next whitespace character — so it reads one "word" at a time:

```cpp
int age;
cout << "Enter your age: ";
cin  >> age;
cout << "You are " << age << " years old." << endl;
```

:::callout-warning[cin and spaces]
`cin >> someString` only reads up to the first space. If you need a full line (including spaces), use `getline(cin, someString)` instead. This trips up almost everyone their first week.
:::

### Worked examples

:::example[Example 1.1 — Print a rectangle of stars]
Write a program that prints a 3×5 rectangle of asterisks using only `cout` statements.

::::answer[Answer]
Five `cout` lines, each printing three asterisks followed by `endl`.
::::

Program

```cpp
#include <iostream>
using namespace std;

int main() {
    cout << "***" << endl;
    cout << "***" << endl;
    cout << "***" << endl;
    cout << "***" << endl;
    cout << "***" << endl;
    return 0;
}
```

Output:

```
***
***
***
***
***
```

Note: this approach is fine for a fixed size. In Chapter 5 (Loops) you'll learn to do this with two nested loops regardless of the dimensions.
:::

:::example[Example 1.2 — Read two integers and print their sum]
Write a program that reads two integers from the user and prints their sum.

::::answer[Answer]
Declare two `int` variables, read both with `cin`, compute the sum inline in the `cout`.
::::

Program

```cpp
#include <iostream>
using namespace std;

int main() {
    int x;
    int y;

    cout << "Enter two integers: ";
    cin  >> x >> y;     // reads two values separated by whitespace
    cout << "Sum: " << x + y << endl;

    return 0;
}
```

Notice that `cin >> x >> y` chains two extractions — the user can enter them on one line separated by a space, or press Enter between them. Either works.
:::

:::callout-pitfall[Watch out for]
- **Missing semicolons.** Every statement ends with `;`. The compiler error will often blame the next line, not the real culprit.
- **Mismatched braces.** Every `{` needs a matching `}`. Count them if something looks wrong.
- **Case sensitivity.** `cout` ≠ `Cout` ≠ `COUT`. C++ is case-sensitive everywhere.
- **Printing vs. storing.** `cout << x + y` prints the sum but does not save it. If you need the result later, store it: `int sum = x + y;`
:::

### Practice problems

:::problem[Problem 1.1 easy]{difficulty="easy"}
Write a complete C++ program that prints exactly this to the screen (including the blank line):

```
Hello, World!

I am learning C++.
```

::::solution[Solution]
```cpp
#include <iostream>
using namespace std;
int main() {
    cout << "Hello, World!" << endl;
    cout << endl;                         // blank line
    cout << "I am learning C++." << endl;
    return 0;
}
```

The second `cout << endl;` outputs a newline with nothing before it, creating the blank line.
::::
:::

:::problem[Problem 1.2 easy]{difficulty="easy"}
What is the output of the following program?

```cpp
#include <iostream>
using namespace std;
int main() {
    cout << "A" << "B" << "C" << endl;
    cout << "1" << "2" << "3" << endl;
    return 0;
}
```

::::solution[Solution]
Output:

```
ABC
123
```

Multiple `<<` operators on one `cout` line concatenate directly with no spaces.
::::
:::

:::problem[Problem 1.3 standard]{difficulty="standard"}
Write a program that prompts the user for their first name and last name (as two separate inputs), then prints: `Full name: [first] [last]`.

::::solution[Solution]
```cpp
#include <iostream>
#include <string>
using namespace std;
int main() {
    string first, last;
    cout << "First name: ";
    cin  >> first;
    cout << "Last name: ";
    cin  >> last;
    cout << "Full name: " << first << " " << last << endl;
    return 0;
}
```
::::
:::

:::problem[Problem 1.4 standard]{difficulty="standard"}
A student writes: `Cin >> x;` and gets a compile error. What is wrong, and how do you fix it?

::::solution[Solution]
C++ is case-sensitive. The correct spelling is `cin` (all lowercase). `Cin` is not defined anywhere — the compiler will say something like `error: 'Cin' was not declared in this scope`. Fix: change `Cin` to `cin`.
::::
:::

:::problem[Problem 1.5 challenge]{difficulty="challenge"}
Write a program that reads three integers and prints them in reverse order, each on its own line.

::::solution[Solution]
```cpp
#include <iostream>
using namespace std;
int main() {
    int a, b, c;
    cout << "Enter three integers: ";
    cin  >> a >> b >> c;
    cout << c << endl;
    cout << b << endl;
    cout << a << endl;
    return 0;
}
```
::::
:::

## 3. Comments & Whitespace (§1.4, §1.12)

:::callout-intuition[Intuition]
Code is read far more often than it is written — by your future self, by teammates, by graders. Comments are notes you leave for those readers. Whitespace is the visual breathing room that lets a reader's eye parse structure instantly. Neither affects what the program *does*; both affect whether anyone can understand what it *means*.
:::

### Single-line comments

Anything after `//` on a line is ignored by the compiler:

```cpp
int speed = 60;   // speed in miles per hour
// The next line computes travel time
double time = distance / speed;
```

### Multi-line comments

Block comments start with `/*` and end with `*/`. Everything between is ignored:

```cpp
/*
  Author:  Jack Spinks
  Date:    2026-05-18
  Purpose: Calculates employee salary after tax deductions.
*/
```

### Why whitespace matters (§1.12)

The compiler ignores extra spaces, tabs, and blank lines. These two programs are *identical* to the compiler:

```cpp
// Version A — readable
int main() {
    int x = 5;
    int y = 10;
    cout << x + y << endl;
    return 0;
}
```

```cpp
// Version B — compiler is fine with this; humans are not
int main(){int x=5;int y=10;cout<<x+y<<endl;return 0;}
```

The convention in this course (and industry) is: **one statement per line, indent with 4 spaces inside every `{ }` block, and leave blank lines between logical sections.** You will be graded on style.

:::callout-pitfall[Watch out for]
- **Commenting out code to "fix" a bug.** Commented-out code left in a submission is a red flag — either the code is needed (put it back) or it isn't (delete it).
- **Comments that restate the obvious.** `// increment x by 1` above `x++;` adds no value. Comments should explain *why*, not *what*.
- **Forgetting to close a block comment.** If you open `/*` and never write `*/`, the compiler will eat the rest of your file as a comment — often causing very confusing errors far away from the opening.
:::

## 4. Errors & Warnings (§1.5)

:::callout-intuition[Intuition]
Errors are not failures — they are the compiler trying to help you. A beginner reads a compiler error and panics; an experienced programmer reads the same error and immediately knows where to look. The skill here is learning to *read* error messages rather than guess-and-recompile.
:::

There are three categories of errors in C++, and they require completely different responses:

| Type | When it's caught | Example | Response |
| --- | --- | --- | --- |
| **Syntax error** | At compile time — program won't run at all | Missing semicolon, misspelled keyword, unmatched brace | Read the compiler message. It gives a file and line number. Go there. |
| **Runtime error** | While the program is running | Dividing by zero, accessing memory out of bounds | Add output statements to narrow down where it crashes; use a debugger. |
| **Logic error** | Never — the program runs but gives wrong output | Using `+` when you meant `*`, off-by-one in a loop | Trace execution by hand; add `cout` statements to print intermediate values. |

### Warnings vs. errors

A **warning** is a message the compiler produces when code is legal but suspicious. Warnings do not stop compilation. However, treat every warning as a bug waiting to happen — in this course, submit code with zero warnings.

```cpp
// This compiles but generates a warning:
int x;
cout << x;   // warning: 'x' is used uninitialized
              // x contains whatever garbage was in that memory location
```

:::example[Example 1.3 — Reading a compiler error]
A student writes the following and gets an error. Identify and fix it.

```cpp
#include <iostream>
using namespace std;
int main() {
    cout << "The answer is " << 42 << endl
    return 0;
}
```

::::answer[Answer]
Missing semicolon at the end of the `cout` line. Add `;` after `endl`.
::::

How to read the error

The compiler produces something like: `error: expected ';' before 'return'`. It blames the *return* line because that's where the parser finally gave up — but the real missing semicolon is one line above. **Always look at the line before the one the compiler flags.**
:::

### Practice problems

:::problem[Problem 1.6 easy]{difficulty="easy"}
Classify each error: syntax, runtime, or logic?

1. A program prints `15` when the correct answer is `16`.
2. The program crashes with "segmentation fault" when the user enters a negative number.
3. The compiler says `error: 'cot' was not declared in this scope`.

::::solution[Solution]
**a.** Logic error — produces wrong output without crashing or failing to compile.

**b.** Runtime error — the program ran, then crashed on a specific input.

**c.** Syntax error — `cot` is a misspelling of `cout`; caught at compile time.
::::
:::

:::problem[Problem 1.7 standard]{difficulty="standard"}
Find and fix all errors in this program (there are three):

```cpp
#include <iostream>
using namespace std
int Main() {
    cout << "hello" << endl;
    return 0;
}
```

::::solution[Solution]
1. Missing semicolon after `using namespace std` → add `;`
2. `Main` should be `main` (lowercase) — C++ is case-sensitive and the OS looks for exactly `main`
3. Those are the only two compile errors. The logic is fine.

```cpp
#include <iostream>
using namespace std;     // fix 1: semicolon
int main() {             // fix 2: lowercase main
    cout << "hello" << endl;
    return 0;
}
```
::::
:::

## 5. How Computers Work (§1.8)

:::callout-intuition[Intuition]
You don't need to know how an engine works to drive a car — but if you want to *build* engines, you do. As a Computer Engineer, you'll eventually design the very hardware your programs run on. This section gives you the vocabulary to connect your C++ programs to physical circuits.
:::

| Component | What it does | C++ connection |
| --- | --- | --- |
| **CPU** (Central Processing Unit) | Fetches and executes instructions one at a time, billions per second | Every line of your compiled C++ becomes a sequence of CPU instructions |
| **RAM** (Random Access Memory) | Stores the running program and its data; fast but volatile (lost on power-off) | Every variable you declare lives in RAM while the program runs |
| **Storage** (SSD/HDD) | Long-term storage; slower than RAM but persistent | Your `.cpp` source file and compiled executable live here |
| **I/O devices** | Keyboard, screen, network, sensors | `cin` reads from keyboard; `cout` writes to screen |

### The compile-link-run pipeline

When you press "Run" in your IDE, three things happen in sequence:

1. **Compile:** The compiler (e.g., `g++`) reads your `.cpp` file and translates it into *machine code* — the binary instructions the CPU actually executes. If there are syntax errors, compilation fails here.
2. **Link:** The linker combines your compiled code with any libraries you used (`iostream`, etc.) into a single executable file.
3. **Run:** The OS loads the executable into RAM and the CPU begins executing it starting at `main()`.

:::callout-connect[Connection — Digital Devices & Logic Design]
The CPU is built from the exact gates and circuits you will design in that course. An adder that computes `x + y` in C++ is a real physical circuit of AND, OR, and XOR gates on the chip. When you write `int sum = x + y;`, you are ultimately activating that circuit.
:::

## 6. IDEs & Compilation (§1.7)

An **Integrated Development Environment (IDE)** bundles a text editor, compiler, debugger, and build system into one tool. The IDE used in CSE 1384 at MSState is typically **Visual Studio** or **VS Code with g++**. Either way, the underlying process is the same.

### Compiling from the command line (§19.18 preview)

Understanding the command line matters — embedded and server environments often have no GUI. The basic compile command is:

```bash
g++ -Wall -Wextra -std=c++17 -o myprogram myprogram.cpp
```

| Flag | Meaning |
| --- | --- |
| `-Wall` | Enable all common warnings |
| `-Wextra` | Enable extra warnings |
| `-std=c++17` | Use the C++17 standard |
| `-o myprogram` | Name the output executable `myprogram` |

Then run it: `./myprogram` (Linux/Mac) or `myprogram.exe` (Windows).

## 7. Problem Solving (§1.10, §1.12)

:::callout-intuition[Intuition]
The biggest mistake beginners make is opening a code editor the moment they read a problem. Professional programmers spend more time thinking than typing. A program written from a clear plan takes 20 minutes; a program hacked together without one takes 3 hours and still has bugs.
:::

### The four-step algorithm design process

1. **Understand the problem.** What are the inputs? What are the outputs? What are the edge cases (empty input, negative numbers, zero)?
2. **Work an example by hand.** Solve a specific instance with concrete numbers before writing any code. If you can't do it by hand, you can't write code for it.
3. **Write an algorithm in plain English (pseudocode).** Sequence of steps that a non-programmer could follow. No C++ syntax yet.
4. **Translate to C++.** Each step in your pseudocode becomes one or a few lines of code.

:::definition[Definition 1.3 — Algorithm]
An **algorithm** is a finite, unambiguous sequence of instructions that solves a problem for any valid input and always terminates. Every program implements one or more algorithms.
:::

### Worked examples

:::example[Example 1.4 — Salary calculation (§1.13)]
A worker earns an hourly wage. Given the number of hours worked and the hourly rate, compute gross pay. Hours over 40 earn 1.5× the rate (overtime).

::::answer[algorithm first]
If hours ≤ 40: gross = hours × rate. Else: gross = 40 × rate + (hours − 40) × rate × 1.5.
::::

Step 1 — Work an example by hand

Hours = 45, rate = $20/hr.

 Regular pay: 40 × 20 = $800.

 Overtime hours: 45 − 40 = 5.

 Overtime pay: 5 × 20 × 1.5 = $150.

 Gross = 800 + 150 = **$950**.

Step 2 — Pseudocode

```
READ hours, rate
IF hours <= 40
    gross = hours * rate
ELSE
    gross = 40 * rate + (hours - 40) * rate * 1.5
PRINT gross
```

Step 3 — C++ translation

```cpp
#include <iostream>
using namespace std;

int main() {
    double hours, rate, gross;

    cout << "Hours worked: ";
    cin  >> hours;
    cout << "Hourly rate ($): ";
    cin  >> rate;

    if (hours <= 40.0) {
        gross = hours * rate;
    } else {
        gross = 40.0 * rate + (hours - 40.0) * rate * 1.5;
    }

    cout << "Gross pay: $" << gross << endl;
    return 0;
}
```

For 45 hours at $20: output is `Gross pay: $950`. ✓
:::

:::example[Example 1.5 — Married-couple names (§1.14)]
Two people are getting married. One keeps their last name; the other hyphenates. Given two last names, print both the kept name and the hyphenated combined name.

::::answer[Answer]
Read two strings, print the first as-is, then print `first + "-" + second`.
::::

Work

```cpp
#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName1, lastName2;

    cout << "Enter first last name: ";
    cin  >> lastName1;
    cout << "Enter second last name: ";
    cin  >> lastName2;

    cout << "Kept name:       " << lastName1 << endl;
    cout << "Hyphenated name: " << lastName1 << "-" << lastName2 << endl;

    return 0;
}
```

Sample run — input `Smith` and `Jones`:

`Kept name: Smith`

`Hyphenated name: Smith-Jones`
:::

:::callout-pitfall[Watch out for]
- **Skipping the hand-worked example.** If your hand calculation is wrong, your code will be wrong in exactly the same way — and you won't know it.
- **Precision in output.** Floating-point numbers like `950.0` may print as `950` or `950.000000` depending on format settings. Chapter 3 covers output formatting.
- **Integer vs. floating-point division.** `5 / 2` is `2` in C++ (integer division). `5.0 / 2` is `2.5`. If your salary calculation uses all `int` variables, you'll lose cents. Use `double` for money.
:::

:::summary
## Chapter Summary

### Key concepts

| Concept | What to remember |
| --- | --- |
| Program structure | `#include` → `using namespace std;` → `int main()` → statements → `return 0;` |
| Output | `cout << value << endl;` |
| Input | `cin >> variable;` — reads one whitespace-delimited token |
| Comments | `// single line` or `/* multi-line */` |
| Error types | Syntax (compile-time) · Runtime (crash) · Logic (wrong output) |
| Compile pipeline | Source (.cpp) → Compiler → Machine code → Linker → Executable → CPU |
| Algorithm design | Understand → Work example → Pseudocode → Translate to C++ |

### If you remember nothing else

Every program is just: **get data in, compute something, send data out.** `cin` gets data in. Arithmetic computes. `cout` sends it out. Everything else in this course is building more powerful ways to do those three things.
:::

## Mixed Practice

These problems span the entire chapter. Try each before opening the solution.

:::problem[Problem M.1 easy]{difficulty="easy"}
What three files/steps are involved in going from a `.cpp` source file to a running program?

::::solution[Solution]
**Compile** (source → object code), **link** (object code + libraries → executable), **run** (OS loads executable into RAM, CPU executes starting at `main()`).
::::
:::

:::problem[Problem M.2 easy]{difficulty="easy"}
What is the output?

```cpp
cout << "Score: " << 3 * 4 + 1 << endl;
```

::::solution[Solution]
`Score: 13` — multiplication before addition: 3×4 = 12, then 12+1 = 13.
::::
:::

:::problem[Problem M.3 easy]{difficulty="easy"}
A student wants to read a full sentence (with spaces) into a string. They write `cin >> sentence;` but only the first word is stored. What should they use instead?

::::solution[Solution]
`getline(cin, sentence);` — reads the entire line including spaces until Enter is pressed.
::::
:::

:::problem[Problem M.4 standard]{difficulty="standard"}
Write a complete program that reads a temperature in Celsius and prints it in Fahrenheit. Formula: `F = C × 9/5 + 32`.

::::solution[Solution]
```cpp
#include <iostream>
using namespace std;
int main() {
    double celsius, fahrenheit;
    cout << "Temperature in Celsius: ";
    cin  >> celsius;
    fahrenheit = celsius * 9.0 / 5.0 + 32.0;
    cout << fahrenheit << " F" << endl;
    return 0;
}
```

Key point: write `9.0 / 5.0`, not `9 / 5`. Integer division of 9/5 gives 1, destroying the fractional part.
::::
:::

:::problem[Problem M.5 standard]{difficulty="standard"}
Find every error (there may be more than one) and state whether each is a syntax, runtime, or logic error:

```cpp
#include <iostream>
using namespace std;
int main() {
    int x = 10
    int y = 0;
    cout << x / y << endl;  // divide by zero
    return 0
}
```

::::solution[Solution]
- Line 4: missing semicolon after `int x = 10` → **syntax error**
- Line 6: dividing by zero → **runtime error** (undefined behavior / crash)
- Line 7: missing semicolon after `return 0` → **syntax error**
::::
:::

:::problem[Problem M.6 standard]{difficulty="standard"}
Write the pseudocode (plain English steps, no C++ syntax) for a program that reads a student's score (0–100) and prints "Pass" if ≥ 60, "Fail" otherwise.

::::solution[Solution]
```
READ score
IF score >= 60
    PRINT "Pass"
ELSE
    PRINT "Fail"
```

The C++ translation uses an `if/else` statement — covered fully in Chapter 4.
::::
:::

:::problem[Problem M.7 challenge]{difficulty="challenge"}
Write a complete program that reads a distance in miles and a time in hours, then prints the speed in both mph and km/h. (1 mile = 1.60934 km.)

::::solution[Solution]
```cpp
#include <iostream>
using namespace std;
int main() {
    double miles, hours;
    cout << "Distance (miles): ";
    cin  >> miles;
    cout << "Time (hours): ";
    cin  >> hours;

    double mph  = miles / hours;
    double kmph = mph * 1.60934;

    cout << "Speed: " << mph  << " mph"  << endl;
    cout << "Speed: " << kmph << " km/h" << endl;
    return 0;
}
```
::::
:::

## LeetCode Practice

These problems use only the concepts from Chapter 1 — basic I/O, arithmetic, and following a logical sequence of steps. Type them out fully rather than copy-pasting; the physical act of writing code cements the syntax.

:::callout-tip[Strategy for this chapter]
At this stage, focus on getting each program to compile and run correctly before worrying about elegance. Read the problem statement carefully, work one example by hand, then code it. If the output is wrong, add `cout` statements to print intermediate values until you find where your logic diverges from the expected result.
:::

| # | Problem | Difficulty | Why it fits Chapter 1 |
| --- | --- | --- | --- |
| [#412](https://leetcode.com/problems/fizz-buzz/) | **Fizz Buzz** | Easy | Straight-line logic with conditional output — exactly the problem-solving process from §1.10. Work the pattern by hand for 1–15 before coding. |
| [#9](https://leetcode.com/problems/palindrome-number/) | **Palindrome Number** | Easy | Exercises thinking about inputs, edge cases (negatives, multiples of 10), and following a logical algorithm step by step. |
| [#13](https://leetcode.com/problems/roman-to-integer/) | **Roman to Integer** | Easy | Table-driven logic: map symbols to values, scan left-to-right, handle the subtraction rule. Good algorithm-design practice. |
| [#14](https://leetcode.com/problems/longest-common-prefix/) | **Longest Common Prefix** | Easy | Working with strings character-by-character — previews Chapter 4's string operations in a low-stakes context. |
| [#7](https://leetcode.com/problems/reverse-integer/) | **Reverse Integer** | Medium | Uses modulo and integer division to extract digits — concepts from §2.11. A natural stretch problem once you've done the Easy four. |

---

CSE 1384 & 2813 Self-Study Textbook · Chapter 1 · Generated 2026-05-18
