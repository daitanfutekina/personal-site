---
title: "Chapter 20: Artificial Intelligence"
source: "cpp_ch20_ai.html"
---

CSE 1384

# Chapter 20: Artificial Intelligence

§20.1 – §20.5

## §20.1 — What is Artificial Intelligence?

**Artificial Intelligence (AI)** is the field of computer science focused on creating systems that perform tasks that typically require human-level intelligence: reasoning, learning, perception, natural language understanding, and problem-solving.

### AI Subfields

#### Machine Learning (ML)

Systems that learn patterns from data without being explicitly programmed. Input: labeled examples → Output: predictions on new data.

#### Deep Learning (DL)

ML using artificial neural networks with many layers. Powerful for images, speech, and text at the cost of huge data and compute requirements.

#### Natural Language Processing (NLP)

AI that understands and generates human language. Powers chatbots, translation, summarization, and sentiment analysis.

#### Computer Vision

AI that interprets images and video — object detection, facial recognition, medical imaging, self-driving car perception.

#### Reinforcement Learning (RL)

Agent learns by trial-and-error, maximizing reward. Powers game-playing AIs (AlphaGo, chess engines) and robotics.

#### Expert Systems / Rules

Hand-coded knowledge bases with if-then rules. Classical AI approach — still used in medical diagnosis, legal reasoning.

### AI in Context: Narrow vs. General

| Type | Definition | Examples | Status |
| --- | --- | --- | --- |
| Narrow AI (ANI) | Specialized for one domain | Chess engine, spam filter, GPT | Exists now |
| General AI (AGI) | Human-level across all domains | Fictional AI | Not achieved |
| Superintelligence (ASI) | Exceeds humans in every domain | Theoretical | Speculative |

## §20.2 — Generative AI & Large Language Models

**Generative AI** creates new content (text, images, code, audio) rather than just classifying existing content. **Large Language Models (LLMs)** are the engine behind text-based generative AI.

### How LLMs Work (Conceptually)

```text
Training phase (happens once, requires massive compute):
  1. Collect enormous text dataset (internet, books, code)
  2. Train a Transformer neural network to predict the next token
     - "The cat sat on the ___" → learns "mat" is probable
  3. Fine-tune on human preference data (RLHF)
  4. Result: billions of parameters encoding statistical language patterns

Inference phase (happens each time you use it):
  Input: "Explain sorting algorithms"
  LLM: predicts tokens one by one, each conditioned on all previous
  Output: coherent explanation built token by token
```

### Key Terms

| Term | Definition |
| --- | --- |
| **Token** | Basic unit of text (≈ 4 characters or ¾ word) |
| **Context window** | Maximum text the model sees at once |
| **Prompt** | Input given to the model |
| **Temperature** | Controls randomness: 0=deterministic, 1=creative |
| **Hallucination** | Confidently wrong output — LLMs can fabricate facts |
| **Fine-tuning** | Further training on domain-specific data |
| **RAG** | Retrieval-Augmented Generation: supplement model with external knowledge |

## §20.3 — Generative AI in Action

LLMs can assist with programming tasks across the software development lifecycle. Understanding their strengths and limitations makes you a more effective developer.

### Code Generation Example

```text
Prompt: "Write a C++ function to check if a string is a palindrome,
         ignoring case and non-alphanumeric characters."

LLM output:
bool isPalindrome(const string& s) {
    string cleaned;
    for (char c : s)
        if (isalnum(c)) cleaned += tolower(c);
    return cleaned == string(cleaned.rbegin(), cleaned.rend());
}

Verification:
  "A man a plan a canal Panama" → "amanaplanacanalpanama" → palindrome ✓
  "race a car" → "raceacar" → not palindrome ✓
```

### What LLMs Are Good At (for Programmers)

- Boilerplate code generation (getters, constructors, file I/O)
- Explaining unfamiliar code or APIs
- Generating unit tests for known specifications
- Debugging assistance (explain what the error means)
- Translating between programming languages
- Generating documentation from code

### What LLMs Struggle With

- Novel algorithmic reasoning (may produce plausible-looking but wrong algorithms)
- Maintaining correctness across very long code contexts
- Understanding runtime behavior without execution
- Domain-specific edge cases it wasn't trained on
- Security-critical code (may generate vulnerable patterns)

:::callout-warning
Always verify LLM-generated code.

Test it, review it, and understand it before using it. An LLM code assistant is like a fast but junior colleague — prolific but sometimes confidently wrong. The programmer remains responsible for correctness.
:::

## §20.4 — Building AI Systems

Modern AI development uses a layered stack. As a CE student, you'll interact with multiple layers.

```text
AI System Stack:
┌──────────────────────────────────────┐
│  Application Layer                   │  ← Your app (chatbot, classifier)
│  (Python/C++ code, business logic)   │
├──────────────────────────────────────┤
│  AI Framework Layer                  │  ← TensorFlow, PyTorch, ONNX
│  (model training and inference)      │
├──────────────────────────────────────┤
│  Model Layer                         │  ← Pre-trained weights (GPT, BERT)
│  (Transformer architecture)          │
├──────────────────────────────────────┤
│  Hardware Layer                      │  ← GPUs, TPUs, dedicated AI chips
│  (CUDA, tensor cores)                │
└──────────────────────────────────────┘
```

### A Simple ML Pipeline in C++ (conceptual)

```cpp
// Simplified linear regression — the "hello world" of ML
// Predict y from x: y = w*x + b

double predict(double x, double w, double b) { return w*x + b; }

double mse(const vector<pair<double,double>>& data, double w, double b) {
    double loss = 0;
    for (auto& [x, y] : data)
        loss += pow(predict(x, w, b) - y, 2);
    return loss / data.size();
}

// Gradient descent training loop
void train(vector<pair<double,double>>& data, double& w, double& b,
           double lr = 0.01, int epochs = 1000) {
    int n = data.size();
    for (int e = 0; e < epochs; e++) {
        double dw = 0, db = 0;
        for (auto& [x, y] : data) {
            double err = predict(x, w, b) - y;
            dw += 2 * err * x / n;   // gradient wrt w
            db += 2 * err / n;        // gradient wrt b
        }
        w -= lr * dw;   // step opposite to gradient
        b -= lr * db;
        if (e % 100 == 0)
            cout << "Epoch " << e << " loss: " << mse(data, w, b) << "\n";
    }
}

int main() {
    // Data: y ≈ 2x + 1
    vector<pair<double,double>> data = {{1,3},{2,5},{3,7},{4,9},{5,11}};
    double w = 0, b = 0;
    train(data, w, b);
    cout << "Learned: w=" << w << " b=" << b << "\n";  // ~2.0, ~1.0
}
```

## §20.5 — Risks and Ethics in AI

As an engineer building AI-powered systems, you will face ethical decisions that the technology itself cannot make for you.

### Key Concerns

#### Bias and Fairness

Models trained on biased data perpetuate and amplify that bias. A hiring AI trained on historical data may discriminate by gender or race. Bias audits and diverse training data are essential.

#### Hallucination and Trust

LLMs generate confident-sounding false information. In high-stakes domains (medicine, law, engineering), unverified AI output can cause serious harm.

#### Privacy

Training data may contain private information. Models can memorize and leak personally identifiable information. GDPR and similar laws regulate AI data use.

#### Intellectual Property

Training on copyrighted text raises legal questions. Ownership of AI-generated output is unsettled. Engineers must understand their organization's AI policy.

#### Safety and Alignment

AI systems optimizing for a metric may find unexpected shortcuts. A content-recommendation AI optimizing engagement may promote outrage. Specification of goals must account for unintended consequences.

#### Accountability

When an AI makes a wrong decision, who is responsible? The developer? The company? The user? Legal and professional frameworks are still developing.

:::callout-key
Engineering ethics in the AI era:

the IEEE Code of Ethics and ACM Code of Ethics both emphasize that engineers must prioritize public safety and disclose conflicts of interest. For AI, this means: (1) document your model's limitations, (2) test for bias before deployment, (3) maintain human oversight of consequential decisions, (4) be transparent about when AI is making decisions affecting people.
:::

:::callout-connect
For CE students specifically:

you'll design embedded systems and hardware that runs AI models. This creates responsibility not just for the software but for the physical consequences — a self-driving car algorithm, a medical device classifier, an industrial control system. The gap between "the model works on the training set" and "the system is safe to deploy" is your professional responsibility to bridge.
:::

:::summary
### Chapter 20 — Key Takeaways

- **AI** is the broad field; **ML** learns from data; **Deep Learning** uses layered neural networks; **LLMs** are large-scale language models trained to predict tokens.
- Modern AI is *Narrow AI* — superhuman in its domain, helpless outside it. AGI does not exist yet.
- LLMs generate text token-by-token using statistical patterns — they do not "understand" in the human sense. Hallucinations are a direct consequence of this architecture.
- **Always verify AI-generated code.** An LLM is a prolific but fallible collaborator: strong at boilerplate and explanation, weak at novel reasoning and security-critical logic.
- AI systems run on a stack: App → Framework (PyTorch/TensorFlow) → Model weights → Hardware (GPU/TPU). CE students will work across all layers.
- Linear regression via gradient descent is the conceptual foundation of all modern ML: minimize loss by stepping in the direction opposite the gradient.
- Engineering ethics requirements (IEEE/ACM) extend to AI: document limitations, test for bias, maintain human oversight, be transparent when AI affects people.
:::

### Practice Problems

:::problem{difficulty="easy"}
P1 — Classify the AI Task

For each scenario below, identify which AI subfield is most relevant: (a) Automatically tagging spam email, (b) A robot learning to walk by trial-and-error, (c) Translating English to Spanish, (d) Identifying tumors in X-ray images.

::::solution[Solution]
(a) **ML / Classification** — spam detection is a classic binary classification problem trained on labeled examples.

(b) **Reinforcement Learning** — the robot (agent) learns by receiving reward signals, not labeled data.

(c) **NLP / Sequence-to-sequence** — machine translation is a core NLP task, now dominated by Transformer LLMs.

(d) **Computer Vision / Deep Learning** — convolutional neural networks analyze pixel data to detect visual features.
::::
:::

:::problem{difficulty="easy"}
P2 — LLM Vocabulary

Match each term to its definition: Token, Temperature, Hallucination, RAG, Context window, Fine-tuning.

::::solution[Solution]
- **Token** — Basic unit of text (~4 chars / ¾ word) that the model processes.
- **Temperature** — Controls output randomness; 0 = deterministic, 1+ = creative/risky.
- **Hallucination** — Confident but factually incorrect output; a fundamental failure mode of LLMs.
- **RAG** — Retrieval-Augmented Generation; grounds LLM output in external documents to reduce hallucinations.
- **Context window** — The maximum text (in tokens) the model can "see" at once when generating a response.
- **Fine-tuning** — Further training an existing model on domain-specific data to specialize its behavior.
::::
:::

:::problem{difficulty="standard"}
P3 — Gradient Descent by Hand

You are training a linear model `y = w*x` (no bias). The dataset has one point: x=2, y=6. Currently w=1. Using MSE loss and learning rate α=0.1, compute one gradient descent step. What is the new value of w?

::::solution[Solution]
**Step 1 — Predict:** ŷ = w·x = 1·2 = 2

**Step 2 — Error:** ŷ − y = 2 − 6 = −4

**Step 3 — MSE gradient w.r.t. w:** ∂L/∂w = 2·(ŷ−y)·x = 2·(−4)·2 = −16 (for one point, divide by n=1)

**Step 4 — Update:** w\_new = w − α·(∂L/∂w) = 1 − 0.1·(−16) = 1 + 1.6 = **2.6**

After this step the model predicts 2.6·2 = 5.2, which is closer to the target of 6. Gradient descent iterates this process until convergence.
::::
:::

:::problem{difficulty="standard"}
P4 — Prompt Engineering

You need an LLM to write a C++ function that checks whether a number is prime, with O(√n) complexity. Write a prompt that would reliably produce correct, efficient, well-commented code. What elements should your prompt include?

::::solution[Solution]
A strong prompt includes: **role**, **specification**, **constraints**, and **output format**:

```text
You are an expert C++ programmer. Write a function:
  bool isPrime(int n)
Requirements:
  - Returns true if n is prime, false otherwise
  - Handle edge cases: n < 2 returns false
  - Time complexity: O(sqrt(n)) — trial division up to sqrt(n) only
  - Include inline comments explaining each step
  - Use only standard C++ (no external libraries)
```

**Why each element matters:**

- *Role context* — sets the LLM's frame of reference and style expectations
- *Exact signature* — prevents the model from guessing parameter types or naming
- *Explicit edge cases* — LLMs commonly forget n=0, n=1 without prompting
- *Complexity constraint* — without it, the model may produce O(n) trial division
- *Comment requirement* — makes verification easier and code more maintainable
::::
:::

:::problem{difficulty="standard"}
P5 — Ethics Case Study

A hospital deploys an AI model to triage ER patients and recommend which cases are urgent. The model was trained on 10 years of historical triage data. In testing it performs well overall (94% accuracy). However, it systematically under-prioritizes elderly patients and patients from lower-income zip codes. Should this model be deployed? What actions should the engineering team take?

::::solution[Solution]
**No — this model should not be deployed as-is.**

High overall accuracy masks disparate impact on protected groups. In a medical triage context, systematic under-prioritization means delayed care that can directly harm or kill patients. The fact that historical data is biased (possibly reflecting systemic healthcare inequity) does not make the model's perpetuation of that bias acceptable — it makes it more harmful.

**Required engineering actions:**

- **Bias audit** — Disaggregate accuracy metrics by age, zip code (proxy for income/race), and other demographic groups. Report per-subgroup precision and recall for the "urgent" class.
- **Root cause analysis** — Determine whether historical triage decisions themselves were inequitable. If so, the training labels are poisoned.
- **Rebalancing / re-weighting** — Apply fairness constraints, oversample underrepresented groups, or use fairness-aware training objectives.
- **Human-in-the-loop** — In high-stakes medical decisions, AI should assist clinicians, not replace them. Flag low-confidence predictions for mandatory human review.
- **Regulatory compliance** — Medical AI is subject to FDA oversight in the US. Disparate impact may also trigger civil rights regulations.
- **Transparency** — Disclose the model's known limitations to all clinicians using it.

IEEE and ACM codes require engineers to prioritize public safety and disclose known hazards. Deploying this model without remediation would violate both.
::::
:::

## LeetCode — Applied Algorithmic Thinking

While the AI chapter is conceptual, the programming skills from earlier chapters directly apply to implementing AI algorithms:

| # | Problem | Difficulty | Connection to AI Chapter |
| --- | --- | --- | --- |
| [#287](https://leetcode.com/problems/find-the-duplicate-number/) | Find the Duplicate Number | Medium | Hashing / Floyd's cycle — core ML data-cleaning pattern for deduplication |
| [#53](https://leetcode.com/problems/maximum-subarray/) | Maximum Subarray (Kadane's) | Medium | Dynamic programming — same gradient-of-cumulative-sum logic used in training loss optimization |
| [#20](https://leetcode.com/problems/valid-parentheses/) | Valid Parentheses | Easy | Token parsing — exactly what LLM tokenizers do when parsing structured input |
| [#706](https://leetcode.com/problems/design-hashmap/) | Design HashMap | Easy | Hash tables underpin embedding lookup tables, vocabulary maps, and model caches in every LLM |
