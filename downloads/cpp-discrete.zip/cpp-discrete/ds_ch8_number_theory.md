---
title: "DS–8: Number Theory"
source: "ds_ch8_number_theory.html"
---

CSE 2813

# DS–8: Number Theory

§8.1 – §8.8

## §8.1 Divisibility and the Division Algorithm

:::definition[Definition]
Divisibility

We say $a \mid b$ ("$a$ divides $b$") if there exists an integer $k$ such that $b = ka$. Properties:

- $a \mid a$ (reflexive)
- $a \mid b$ and $b \mid c \Rightarrow a \mid c$ (transitive)
- $a \mid b$ and $a \mid c \Rightarrow a \mid (bx + cy)$ for all integers $x,y$ (linear combinations)
:::

:::theorem[Theorem]
Division Algorithm

For integers $a$ and $b > 0$, there exist unique integers $q$ (quotient) and $r$ (remainder) with:

$$
a = qb + r, \quad 0 \le r < b
$$

 We write $r = a \bmod b$.
:::

## §8.2 GCD and the Euclidean Algorithm

:::definition[Definition]
Greatest Common Divisor

$\gcd(a,b)$ is the largest integer dividing both $a$ and $b$. $\gcd(a,0)=a$.
:::

:::theorem[Theorem]
Euclidean Algorithm

$\gcd(a,b) = \gcd(b, a \bmod b)$. Repeat until remainder is 0; the last nonzero remainder is the GCD. Time: $O(\log \min(a,b))$.
:::

Example 8.1 — Euclidean Algorithm Trace

Compute $\gcd(252, 105)$.

:::answer[Solution]
| $a$ | $b$ | $a \bmod b$ |
| --- | --- | --- |
| 252 | 105 | 42 |
| 105 | 42 | 21 |
| 42 | 21 | 0 |

$\gcd(252,105) = \mathbf{21}$.
:::

:::theorem[Theorem]
Bézout's Identity

For any integers $a,b$ (not both zero), there exist integers $x,y$ such that:

$$
ax + by = \gcd(a,b)
$$

 The extended Euclidean algorithm finds $x$ and $y$ in $O(\log\min(a,b))$ time.
:::

## §8.3 Modular Arithmetic

:::definition[Definition]
Congruence

$a \equiv b \pmod{m}$ iff $m \mid (a-b)$. The residue class $[a]_m = \{a + km : k \in \mathbb{Z}\}$. We work in $\mathbb{Z}_m = \{0,1,\ldots,m-1\}$.
:::

Modular arithmetic supports addition, subtraction, and multiplication:

- $(a+b)\bmod m = ((a\bmod m)+(b\bmod m))\bmod m$
- $(ab)\bmod m = ((a\bmod m)(b\bmod m))\bmod m$

Example 8.2 — Clock Arithmetic

A server processes jobs in 7-hour cycles. If it is currently at hour 3 of the cycle, what cycle-hour will it be at after 100 more hours?

:::answer[Solution]
$(3 + 100) \bmod 7 = 103 \bmod 7$. $103 = 14\times7 + 5$. Answer: hour $\mathbf{5}$.
:::

:::callout-connect[Connection → Hash Tables]
The simplest hash function: $h(k) = k \bmod m$ where $m$ is the table size. Choosing $m$ prime minimizes collision clustering.
:::

## §8.4 Modular Inverses

:::definition[Definition]
Modular Inverse

The modular inverse of $a$ modulo $m$ is an integer $a^{-1}$ such that $a \cdot a^{-1} \equiv 1 \pmod{m}$. It exists iff $\gcd(a,m)=1$ (i.e., $a$ and $m$ are coprime).
:::

**Finding the inverse:** Use the extended Euclidean algorithm to find $x,y$ with $ax+my=1$; then $x \bmod m$ is the inverse.

Example 8.3 — Modular Inverse

Find $3^{-1} \pmod{7}$.

:::answer[Solution]
We need $3x \equiv 1 \pmod 7$. Try: $3\times1=3$, $3\times2=6$, $3\times3=9\equiv2$, $3\times4=12\equiv5$, $3\times5=15\equiv1$ ✓. So $3^{-1}\equiv\mathbf{5}\pmod7$.
:::

## §8.5 Primes and the Fundamental Theorem of Arithmetic

:::theorem[Theorem]
Fundamental Theorem of Arithmetic

Every integer $n > 1$ has a unique prime factorization (up to reordering):

$$
n = p_1^{a_1} p_2^{a_2} \cdots p_k^{a_k}
$$

 Using prime factorizations: $\gcd(a,b)$ takes minimum exponents; $\text{lcm}(a,b)$ takes maximum exponents. Note $\gcd(a,b)\cdot\text{lcm}(a,b) = ab$.
:::

Example 8.4 — GCD and LCM via Factorization

Find $\gcd(360, 504)$ and $\text{lcm}(360, 504)$.

:::answer[Solution]
$360 = 2^3\cdot3^2\cdot5$, $504 = 2^3\cdot3^2\cdot7$.

$\gcd = 2^3\cdot3^2 = 8\cdot9 = \mathbf{72}$.

$\text{lcm} = 2^3\cdot3^2\cdot5\cdot7 = 72\cdot35 = \mathbf{2520}$.

Check: $72\times2520 = 181440 = 360\times504$ ✓.
:::

## §8.6 Primality Testing

A naive test divides $n$ by all integers up to $\sqrt{n}$ — this is $O(\sqrt{n})$. Better: the **Sieve of Eratosthenes** finds all primes up to $N$ in $O(N\log\log N)$ time.

```cpp
// Sieve of Eratosthenes — O(N log log N)
vector<bool> sieve(int N) {
    vector<bool> is_prime(N+1, true);
    is_prime[0] = is_prime[1] = false;
    for (int p = 2; (long long)p*p <= N; ++p)
        if (is_prime[p])
            for (int m = p*p; m <= N; m += p)
                is_prime[m] = false;
    return is_prime;
}
```

:::callout-pitfall[Common Pitfall]
Start marking composites at $p^2$, not $2p$. All smaller multiples $2p, 3p, \ldots, (p-1)p$ were already marked by smaller primes.
:::

## §8.7 Fermat's Little Theorem and Euler's Theorem

:::theorem[Theorem]
Fermat's Little Theorem

If $p$ is prime and $\gcd(a,p)=1$:

$$
a^{p-1} \equiv 1 \pmod{p}
$$

 Equivalently, $a^p \equiv a \pmod{p}$.

**Corollary:** For prime $p$, $a^{-1} \equiv a^{p-2} \pmod{p}$. Fast inverse computation!
:::

:::theorem[Theorem]
Euler's Theorem

For $\gcd(a,m)=1$: $a^{\phi(m)} \equiv 1 \pmod{m}$, where $\phi(m)$ is Euler's totient function (count of integers in $[1,m]$ coprime to $m$). For prime $p$: $\phi(p)=p-1$, recovering Fermat's theorem.
:::

## §8.8 Fast Modular Exponentiation

Computing $a^b \bmod m$ naively takes $O(b)$ multiplications. **Repeated squaring** reduces this to $O(\log b)$.

:::theorem[Algorithm]
Repeated Squaring

Write $b$ in binary. Scan bits from MSB to LSB: square at each step, and multiply by $a$ when the bit is 1.
:::

Example 8.5 — Compute $3^{13} \bmod 7$

:::answer[Solution]
$13 = 1101_2$. Starting with result $= 1$:

| Bit | Square | Multiply by $a$? | Result mod 7 |
| --- | --- | --- | --- |
| 1 | $1^2=1$ | yes: $1\times3=3$ | 3 |
| 1 | $3^2=9\equiv2$ | yes: $2\times3=6$ | 6 |
| 0 | $6^2=36\equiv1$ | no | 1 |
| 1 | $1^2=1$ | yes: $1\times3=3$ | 3 |

$3^{13} \bmod 7 = \mathbf{3}$. Check: $3^6\equiv1$, so $3^{12}\equiv1$, $3^{13}\equiv3$ ✓.
:::

```cpp
// Fast modular exponentiation: base^exp mod m — O(log exp)
long long modpow(long long base, long long exp, long long m) {
    long long result = 1;
    base %= m;
    while (exp > 0) {
        if (exp & 1) result = result * base % m;
        base = base * base % m;
        exp >>= 1;
    }
    return result;
}
```

## §8.9 Chinese Remainder Theorem

:::theorem[Theorem]
Chinese Remainder Theorem (CRT)

If $m_1, m_2, \ldots, m_k$ are pairwise coprime, the system:

$$
x \equiv a_1 \pmod{m_1}, \quad x\equiv a_2\pmod{m_2}, \quad \ldots
$$

 has a unique solution modulo $M = m_1 m_2\cdots m_k$.
:::

Example 8.6 — CRT

Solve: $x \equiv 2 \pmod 3$, $x \equiv 3 \pmod 5$, $x \equiv 2 \pmod 7$.

:::answer[Solution]
$M = 3\cdot5\cdot7 = 105$. $M_1=35, M_2=21, M_3=15$.

Inverses: $35^{-1}\bmod3=2$, $21^{-1}\bmod5=1$, $15^{-1}\bmod7=1$.

$x = (2\cdot35\cdot2 + 3\cdot21\cdot1 + 2\cdot15\cdot1)\bmod105$

$= (140 + 63 + 30)\bmod105 = 233\bmod105 = \mathbf{23}$.

Verify: $23=7\cdot3+2$ ✓, $23=4\cdot5+3$ ✓, $23=3\cdot7+2$ ✓.
:::

## §8.10 RSA Cryptography

RSA is a public-key cryptosystem whose security rests on the difficulty of factoring large integers.

Example 8.7 — RSA Walkthrough

Demonstrate RSA key generation, encryption, and decryption with small primes.

:::answer[Step 1 — Key Generation]
Choose primes $p=61$, $q=53$. $n=pq=3233$.

$\phi(n)=(p-1)(q-1)=60\times52=3120$.

Choose $e=17$ (coprime to 3120). Find $d=e^{-1}\bmod3120$: extended GCD gives $d=2753$.

Public key:

$(n,e)=(3233,17)$.

Private key:

$(n,d)=(3233,2753)$.

Message $m=65$. Ciphertext $c = m^e \bmod n = 65^{17}\bmod3233 = \mathbf{2790}$.

$m = c^d \bmod n = 2790^{2753}\bmod3233 = \mathbf{65}$ ✓ (recovered original message).

By Euler: $m^{\phi(n)}\equiv1\pmod n$, so $c^d = m^{ed} \equiv m^{1+k\phi(n)} \equiv m\pmod n$.
:::

:::callout-key[Key Concept — Security of RSA]
The modulus $n=pq$ is public, but factoring it back into $p$ and $q$ is believed to be computationally infeasible for large $n$ (2048+ bits). Without $p$ and $q$, an adversary cannot compute $\phi(n)$ and therefore cannot find the private key $d$.
:::

:::summary
### Chapter 8 Summary

- **Division algorithm:** $a = qb + r$ uniquely. Foundation of all modular arithmetic.
- **Euclidean algorithm:** $\gcd(a,b)=\gcd(b, a\bmod b)$ in $O(\log\min(a,b))$.
- **Bézout:** $ax+by=\gcd(a,b)$ — extended Euclidean finds $x,y$; gives modular inverses.
- **Modular arithmetic:** $\mathbb{Z}_m$ with addition, subtraction, multiplication — inverse exists iff $\gcd(a,m)=1$.
- **FTA:** unique prime factorization; GCD = min exponents, LCM = max exponents.
- **Fermat's Little Theorem:** $a^{p-1}\equiv1\pmod p$ for prime $p$ — fast inverse: $a^{-1}\equiv a^{p-2}$.
- **Fast modular exponentiation:** repeated squaring in $O(\log b)$.
- **CRT:** simultaneous congruences with coprime moduli have a unique solution mod product.
- **RSA:** public-key crypto using modular exponentiation; security = hardness of factoring.
:::

## Practice Problems

:::problem[Problem 1]{difficulty="easy"}
Problem 1

Compute $\gcd(1071, 462)$ using the Euclidean algorithm. Show each step.

::::solution[Solution]
$1071 = 2\times462+147$; $462=3\times147+21$; $147=7\times21+0$. $\gcd=\mathbf{21}$.
::::
:::

:::problem[Problem 2]{difficulty="easy"}
Problem 2

Find all primes up to 30 using the Sieve of Eratosthenes.

::::solution[Solution]
Mark composites: $4,6,8,9,10,12,14,15,16,18,20,21,22,24,25,26,27,28$. Primes: $\mathbf{2,3,5,7,11,13,17,19,23,29}$.
::::
:::

:::problem[Problem 3]{difficulty="standard"}
Problem 3

Compute $7^{100} \bmod 13$ using Fermat's Little Theorem.

::::solution[Solution]
$p=13$ prime, $\gcd(7,13)=1$. FLT: $7^{12}\equiv1\pmod{13}$.

$100 = 8\times12+4$, so $7^{100}=(7^{12})^8\cdot7^4\equiv1^8\cdot7^4=7^4\pmod{13}$.

$7^2=49\equiv10$; $7^4\equiv10^2=100\equiv9\pmod{13}$. Answer: $\mathbf{9}$.
::::
:::

:::problem[Problem 4]{difficulty="standard"}
Problem 4

Solve the system: $x\equiv1\pmod4$, $x\equiv2\pmod5$, using CRT.

::::solution[Solution]
$M=20$. $M_1=5, M_2=4$. $5^{-1}\bmod4=1$ (since $5\equiv1$); $4^{-1}\bmod5=4$ (since $4\times4=16\equiv1$).

$x=(1\times5\times1+2\times4\times4)\bmod20=(5+32)\bmod20=37\bmod20=\mathbf{17}$.
::::
:::

:::problem[Problem 5]{difficulty="standard"}
Problem 5

Implement modular exponentiation and compute $2^{1000} \bmod 1000$ by hand (trace first few steps).

::::solution[Solution]
Use repeated squaring. $1000=1111101000_2$. The C++ function above gives the answer directly: $2^{1000}\bmod1000=\mathbf{376}$.
::::
:::

:::problem[Problem 6]{difficulty="challenge"}
Problem 6

Build an RSA mini-cryptosystem: choose primes $p=11$, $q=13$. Generate keys, encrypt the message $m=7$, then decrypt.

::::solution[Solution]
$n=143$, $\phi(n)=10\times12=120$. Choose $e=7$ ($\gcd(7,120)=1$).

Extended GCD: $7d\equiv1\pmod{120}$ → $d=103$ (since $7\times103=721=6\times120+1$).

Encrypt:

$c=7^7\bmod143$. $7^2=49$, $7^4=49^2=2401\equiv2401-16\times143=2401-2288=113$, $7^7=7^4\times7^2\times7=113\times49\times7\bmod143$. $113\times49=5537\equiv5537-38\times143=5537-5434=103$. $103\times7=721\equiv721-5\times143=721-715=\mathbf{6}$.

Decrypt:

$6^{103}\bmod143 = \mathbf{7}$ ✓ (use repeated squaring).
::::
:::

:::problem[Problem 7]{difficulty="challenge"}
Problem 7

Prove Bézout's Identity: for any integers $a,b$ not both zero, $\gcd(a,b)$ can be written as $ax+by$ for some integers $x,y$.

::::solution[Solution]
Let $S=\{ax+by : x,y\in\mathbb{Z}\}\cap\mathbb{Z}^+$ (set of positive linear combinations). $S$ is nonempty (since $a^2+b^2>0$ is in $S$). Let $d$ be the smallest element of $S$. By the division algorithm, $a=qd+r$ for $0\le r<d$. Then $r=a-qd\in S\cup\{0\}$. Since $d$ is the minimum of $S$ and $r<d$, we must have $r=0$, so $d\mid a$. Similarly $d\mid b$. Any common divisor $c\mid a,c\mid b$ implies $c\mid d$, so $d=\gcd(a,b)$. $\square$
::::
:::

## LeetCode Practice

| # | Title | Difficulty | Concept |
| --- | --- | --- | --- |
| 69 | [Sqrt(x)](https://leetcode.com/problems/sqrtx/) | Easy | Integer division, Newton's method |
| 204 | [Count Primes](https://leetcode.com/problems/count-primes/) | Medium | Sieve of Eratosthenes |
| 168 | [Excel Sheet Column Title](https://leetcode.com/problems/excel-sheet-column-title/) | Easy | Base conversion (mod / div) |
| 171 | [Excel Sheet Column Number](https://leetcode.com/problems/excel-sheet-column-number/) | Easy | Base-26 arithmetic |
| 7 | [Reverse Integer](https://leetcode.com/problems/reverse-integer/) | Medium | Modular arithmetic, overflow |
