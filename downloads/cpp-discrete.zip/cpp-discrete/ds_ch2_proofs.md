---
title: "DS–2: Proofs"
source: "ds_ch2_proofs.html"
---

CSE 2813

# DS–2: Proofs

§2.1 – §2.9

:::callout-connect
Why proofs?

In mathematics and computer science, a proof is the only way to be

certain

something is true. Proofs underlie algorithm correctness (why does quicksort always sort?), security guarantees (why is RSA hard to break?), and program verification (why does this loop terminate?). This chapter gives you the toolkit: seven proof strategies you'll use throughout the course.
:::

## §2.1 — What Is a Proof?

A **proof** is a valid argument that establishes the truth of a mathematical statement. Every step in a proof must follow from either a given premise, a definition, an axiom, or a previously proved theorem — via a named rule of inference (Chapter 1).

| Term | Meaning | Example |
| --- | --- | --- |
| **Axiom** | Accepted as true without proof | $a + b = b + a$ for real numbers |
| **Definition** | Precise meaning of a term | "$n$ is even iff $\exists k\,(n = 2k)$" |
| **Theorem** | Important proved statement | There are infinitely many primes |
| **Lemma** | Helper theorem used in a bigger proof | "The product of two odd numbers is odd" |
| **Corollary** | Theorem that follows easily from another | The sum of two even numbers is even (from the definition) |

### Standard Definitions You Must Know

:::definition[Definition]
Even Integer

An integer $n$ is **even** if $\exists k \in \mathbb{Z}$ such that $n = 2k$.
:::

:::definition[Definition]
Odd Integer

An integer $n$ is **odd** if $\exists k \in \mathbb{Z}$ such that $n = 2k + 1$.
:::

:::definition[Definition]
Divisibility

$a \mid b$ ("$a$ divides $b$") means $\exists k \in \mathbb{Z}$ such that $b = ka$. (Also written $a | b$.)
:::

:::definition[Definition]
Rational Number

$r$ is **rational** if $\exists p, q \in \mathbb{Z},\ q \neq 0$ such that $r = p/q$ in lowest terms.
:::

:::callout-key
Always start by unpacking definitions.

To prove something about even numbers, write $n = 2k$. To prove divisibility, write $b = ka$. Definitions convert abstract concepts into algebra you can manipulate.
:::

## §2.2 — Direct Proof

A **direct proof** proves $p \to q$ by assuming $p$ is true and showing that $q$ must follow through a chain of logical deductions.

:::definition[Structure]
Direct Proof Template

Assume $p$. [Chain of definitions, algebra, and known results.] Therefore $q$. ∎
:::

### Worked Example 1 — Sum of Two Even Integers

Theorem: The sum of two even integers is even.

**Proof.** Let $m$ and $n$ be even integers. By definition of even, $m = 2j$ and $n = 2k$ for some integers $j, k$. Then:

$m + n = 2j + 2k = 2(j + k)$

Since $j + k$ is an integer, $m + n = 2(j+k)$ has the form $2 \cdot \text{(integer)}$, so $m + n$ is even by definition. ∎

### Worked Example 2 — Product of Two Odd Integers

Theorem: The product of two odd integers is odd.

**Proof.** Let $m$ and $n$ be odd. Then $m = 2j + 1$ and $n = 2k + 1$ for integers $j, k$. Multiply:

$mn = (2j+1)(2k+1) = 4jk + 2j + 2k + 1 = 2(2jk + j + k) + 1$

Let $t = 2jk + j + k \in \mathbb{Z}$. Then $mn = 2t + 1$, which is odd by definition. ∎

### Worked Example 3 — Divisibility

Theorem: If $a \mid b$ and $a \mid c$, then $a \mid (b + c)$.

**Proof.** Assume $a \mid b$ and $a \mid c$. By definition, $b = ja$ and $c = ka$ for integers $j, k$. Then:

$b + c = ja + ka = a(j + k)$

Since $j + k \in \mathbb{Z}$, we have $a \mid (b+c)$. ∎

:::callout-pitfall
Don't use examples as proofs.

Showing "2+4=6 is even" does NOT prove the theorem for all even numbers. A direct proof must work for arbitrary (general) choices of the variables.
:::

## §2.3 — Proof by Contrapositive

Since $p \to q \equiv \neg q \to \neg p$ (the contrapositive), we can prove $p \to q$ by instead proving: "assume $\neg q$, derive $\neg p$." This is often easier when the conclusion $q$ involves something hard to manipulate directly.

:::callout-intuition
When to choose contrapositive:

If $p$ involves "there exist" or "there is a…" and $q$ involves "is divisible by / is even / is odd," it's often easier to negate $q$ (a concrete arithmetic property) and derive $\neg p$. If the direct path from $p$ to $q$ requires knowing what $p$ looks like explicitly, contrapositive is likely cleaner.
:::

### Worked Example — Odd Square Implies Odd

Theorem: If $n^2$ is odd, then $n$ is odd.

**Proof (Contrapositive).** We prove the contrapositive: "If $n$ is even, then $n^2$ is even." Assume $n$ is even, so $n = 2k$ for some $k \in \mathbb{Z}$. Then:

$n^2 = (2k)^2 = 4k^2 = 2(2k^2)$

Since $2k^2 \in \mathbb{Z}$, $n^2 = 2(2k^2)$ is even. The contrapositive is proved, so the original statement holds. ∎

:::callout-tip
Why not direct?

Trying to prove this directly — "assume $n^2$ is odd, show $n$ is odd" — you would write $n^2 = 2k+1$ and need to extract information about $n$, which requires square roots and is messy. The contrapositive flips the direction and gives you clean algebra.
:::

### Worked Example 2 — Rationality

Theorem: If $\sqrt{2}$ is irrational, then $\sqrt{2} + 1$ is irrational.

**Proof (Contrapositive).** Prove: if $\sqrt{2} + 1$ is rational, then $\sqrt{2}$ is rational. Assume $\sqrt{2} + 1 = p/q$ for $p,q \in \mathbb{Z},\ q \neq 0$. Then $\sqrt{2} = p/q - 1 = (p - q)/q$. Since $p - q \in \mathbb{Z}$ and $q \neq 0$, $\sqrt{2}$ is rational. ∎

## §2.4 — Proof by Contradiction

To prove proposition $P$: assume $\neg P$, then derive a contradiction — a statement of the form $Q \land \neg Q$ (something and its negation both being true). Since $\neg P \to \text{contradiction}$ and contradictions are impossible, $\neg P$ must be false, so $P$ must be true.

:::definition[Structure]
Proof by Contradiction Template

Assume $\neg P$. [Chain of valid steps.] This leads to $Q \land \neg Q$ (a contradiction). Therefore $\neg P$ is false, so $P$ is true. ∎
:::

### Worked Example 1 — Irrationality of $\sqrt{2}$ (Classic)

Theorem: $\sqrt{2}$ is irrational.

**Proof.** Assume for contradiction that $\sqrt{2}$ is rational. Then $\sqrt{2} = p/q$ where $p, q \in \mathbb{Z}$, $q \neq 0$, and the fraction is in *lowest terms* (so $p$ and $q$ share no common factors, in particular they are not both even).

Squaring both sides: $2 = p^2/q^2$, so $p^2 = 2q^2$. This means $p^2$ is even. By the theorem from §2.3 (odd square → odd, contrapositive), $p$ must be even. Write $p = 2m$.

Substituting: $(2m)^2 = 2q^2 \Rightarrow 4m^2 = 2q^2 \Rightarrow q^2 = 2m^2$. So $q^2$ is even, hence $q$ is even.

But now $p$ and $q$ are *both even* — contradicting our assumption that $p/q$ is in lowest terms. This contradiction shows our assumption was wrong. ∎

### Worked Example 2 — Infinitely Many Primes

Theorem: There are infinitely many prime numbers.

**Proof (Euclid, ~300 BCE).** Assume for contradiction that there are finitely many primes: $p_1, p_2, \ldots, p_n$. Consider the number:

$N = p_1 \cdot p_2 \cdots p_n + 1$

$N > 1$, so $N$ has at least one prime divisor $p$. But $p$ must be one of $p_1, \ldots, p_n$ (our complete list). However, dividing $N$ by any $p_i$ leaves remainder 1 (since $N \equiv 1 \pmod{p_i}$), so $p_i \nmid N$. Contradiction — $N$ has no prime divisor. Therefore the list of primes is infinite. ∎

:::callout-key
Contradiction vs. Contrapositive:

Both use negation, but differently.

- Contrapositive: proves $p \to q$ by proving $\neg q \to \neg p$. Direct chain.
- Contradiction: assumes $\neg P$ (the whole statement), then derives any impossibility. More flexible — used when you can't see how to chain deductions forward.
:::

## §2.5 — Proof by Cases

When a statement's truth depends on which of several exhaustive, mutually exclusive categories the variable falls into, prove each case separately. The full proof is complete only when every case is covered.

:::callout-intuition
Think of it as:

$P$ is true because either Case A holds or Case B holds (or Case C…), and in every case, $P$ follows. The cases must be

exhaustive

(cover all possibilities) and each case must establish $P$.
:::

### Worked Example — $n^2 + n$ Is Even for All Integers

Theorem: For all $n \in \mathbb{Z}$, $n^2 + n$ is even.

**Proof by Cases.** Every integer is either even or odd.

**Case 1: $n$ is even.** Write $n = 2k$. Then $n^2 + n = 4k^2 + 2k = 2(2k^2 + k)$, which is even.

**Case 2: $n$ is odd.** Write $n = 2k+1$. Then:

$n^2 + n = (2k+1)^2 + (2k+1) = 4k^2+4k+1+2k+1 = 4k^2+6k+2 = 2(2k^2+3k+1)$

This is even. In both cases $n^2 + n$ is even. ∎

:::callout-connect
Alternative observation:

$n^2 + n = n(n+1)$ — the product of two consecutive integers. One of them must be even (consecutive integers alternate parity), so the product is always even. This is a more elegant version, but the case-based proof is more instructive for learning the technique.
:::

### Worked Example 2 — Absolute Value Inequality

Theorem: $|a| \cdot |b| = |ab|$ for all real $a, b$.

**Proof by Cases** (showing each sign combination):

**Case 1: $a \geq 0$, $b \geq 0$.** Then $ab \geq 0$. LHS $= a \cdot b$. RHS $= ab$. Equal. ✓

**Case 2: $a < 0$, $b < 0$.** Then $ab > 0$. LHS $= (-a)(-b) = ab$. RHS $= ab$. Equal. ✓

**Case 3: $a \geq 0$, $b < 0$.** Then $ab \leq 0$. LHS $= a \cdot (-b)$. RHS $= -ab = a(-b)$. Equal. ✓

**Case 4: $a < 0$, $b \geq 0$.** Symmetric to Case 3. ✓ ∎

## §2.6 — Existence Proofs

An existence proof establishes $\exists x\, P(x)$ — that at least one element satisfying the property exists. There are two flavors:

| Type | Method | When to Use |
| --- | --- | --- |
| **Constructive** | Exhibit a specific witness (give the actual value) | When you can find the witness explicitly |
| **Non-constructive** | Show existence without finding the value (often via contradiction or counting arguments) | When the witness is hard to compute but existence follows logically |

### Constructive Existence Proof

Theorem: There exist irrational numbers $x$ and $y$ such that $x^y$ is rational.

**Attempt 1 — Non-constructive.** Consider $\sqrt{2}^{\sqrt{2}}$. Either it is rational or irrational.

**Case A:** If $\sqrt{2}^{\sqrt{2}}$ is rational, take $x = y = \sqrt{2}$ (both irrational). Done.

**Case B:** If $\sqrt{2}^{\sqrt{2}}$ is irrational, take $x = \sqrt{2}^{\sqrt{2}}$ and $y = \sqrt{2}$. Then:

$x^y = \left(\sqrt{2}^{\sqrt{2}}\right)^{\sqrt{2}} = \sqrt{2}^{\sqrt{2} \cdot \sqrt{2}} = \sqrt{2}^2 = 2 \in \mathbb{Q}$

In either case, such $x, y$ exist — but this proof doesn't tell us *which* case we're in! (It is in fact Case A, but that's hard to prove.) This is a non-constructive existence proof. ∎

Constructive alternative: $x = \sqrt{2}$, $y = 2\log_{\sqrt{2}} 3 = 2\log_2 3$. Then $x^y = (\sqrt{2})^{2\log_2 3} = 2^{\log_2 3} = 3$ (rational). Both $x$ and $y$ are irrational.

### Disproving Existence: Counterexamples

To disprove $\forall x\, P(x)$ (which is equivalent to proving $\exists x\, \neg P(x)$), it suffices to exhibit one counterexample.

Example — Disprove "Every prime is odd."

:::answer
Counterexample: 2. The number 2 is prime and even. One counterexample is sufficient. ∎
:::

:::callout-pitfall
Asymmetry:

One counterexample DISPROVES a universal claim. But one example does NOT PROVE a universal claim. "I found one odd prime" does not prove "all primes are odd."
:::

## §2.7 — Mathematical Induction (Weak Form)

Mathematical induction is the standard tool for proving statements about all natural numbers (or all integers $\geq n_0$). It works like a chain of dominoes: knock the first one over, and prove each domino knocks over the next.

:::theorem[Theorem]
Principle of Mathematical Induction

To prove $\forall n \geq n_0,\ P(n)$:

1. **Base Case:** Show $P(n_0)$ is true.
2. **Inductive Step:** Show $\forall k \geq n_0,\ P(k) \to P(k+1)$.

Conclude: $P(n)$ is true for all $n \geq n_0$.
:::

:::callout-key
The inductive hypothesis (IH)

is the assumption "$P(k)$ is true" made at the start of the inductive step. You are allowed to assume it — the goal is to derive $P(k+1)$ from it. The base case + IH together chain to all values of $n$.
:::

### Worked Example 1 — Sum Formula

Base Case

**Claim:** $\displaystyle\sum_{i=1}^{n} i = \frac{n(n+1)}{2}$ for all $n \geq 1$.

**Base case ($n = 1$):** LHS $= 1$. RHS $= \frac{1 \cdot 2}{2} = 1$. ✓

Inductive Hypothesis

Assume for some $k \geq 1$: $\displaystyle\sum_{i=1}^{k} i = \frac{k(k+1)}{2}$

Inductive Step

Show $P(k+1)$: $\displaystyle\sum_{i=1}^{k+1} i = \frac{(k+1)(k+2)}{2}$

$\displaystyle\sum_{i=1}^{k+1} i = \left(\sum_{i=1}^{k} i\right) + (k+1) \overset{\text{IH}}{=} \frac{k(k+1)}{2} + (k+1) = (k+1)\left(\frac{k}{2} + 1\right) = \frac{(k+1)(k+2)}{2}$ ✓

By induction, the formula holds for all $n \geq 1$. **∎**

### Worked Example 2 — Powers of 2

Theorem: $2^n > n$ for all $n \geq 1$.

**Base case ($n=1$):** $2^1 = 2 > 1$. ✓

**IH:** Assume $2^k > k$ for some $k \geq 1$.

**Inductive step:** Show $2^{k+1} > k+1$.

$2^{k+1} = 2 \cdot 2^k \overset{\text{IH}}{>} 2k = k + k \geq k + 1$ (since $k \geq 1$)

By induction, $2^n > n$ for all $n \geq 1$. ∎

:::callout-pitfall
The "proof" that all horses are the same color.

A famous flawed induction "proof" claims all horses in any group have the same color. The base case ($n=1$: one horse) is trivially true. The inductive step claims that in any group of $k+1$ horses, overlapping the first $k$ and last $k$ shows they all share a color. The flaw: the overlap argument breaks down at $k=1 \to k+1=2$ (two horses, no overlap). Always verify the inductive step covers the transition from the base case.
:::

## §2.8 — Strong (Complete) Induction

In weak induction, the inductive step only uses $P(k)$ to prove $P(k+1)$. In **strong induction**, the inductive hypothesis is that $P(j)$ holds for ALL values $j$ from $n_0$ to $k$, not just $P(k)$ alone. This is useful when $P(k+1)$ depends on earlier cases besides just the immediate predecessor.

:::theorem[Theorem]
Principle of Strong Induction

To prove $\forall n \geq n_0,\ P(n)$:

1. **Base Case(s):** Verify $P(n_0)$ (and possibly a few extra base cases).
2. **Inductive Step:** Assume $P(j)$ for all $n_0 \leq j \leq k$. Prove $P(k+1)$.
:::

### Worked Example — Every Integer > 1 Has a Prime Factor

Theorem: Every integer $n \geq 2$ has a prime divisor.

**Proof by strong induction.**

**Base case ($n=2$):** 2 is prime, so 2 | 2. ✓

**IH (strong):** Assume every integer $j$ with $2 \leq j \leq k$ has a prime divisor.

**Inductive step:** Consider $k+1$.

*Case A — $k+1$ is prime:* Then $k+1$ divides itself. ✓

*Case B — $k+1$ is composite:* Then $k+1 = ab$ for $2 \leq a, b \leq k$. By the IH, $a$ has a prime divisor $p$. Since $p \mid a$ and $a \mid (k+1)$, we have $p \mid (k+1)$. ✓

By strong induction, every integer $n \geq 2$ has a prime divisor. ∎

### Worked Example 2 — Fibonacci Closed Form (partial)

Claim: Fibonacci numbers satisfy $F_n \geq \phi^{n-2}$ where $\phi = (1+\sqrt{5})/2 \approx 1.618$.

**Proof.** (Requires strong induction since $F_n = F_{n-1} + F_{n-2}$ references TWO prior values.)

**Base cases:** $F_1 = 1 \geq \phi^{-1}$ ✓, $F_2 = 1 \geq \phi^0 = 1$ ✓.

**IH:** $F_{k-1} \geq \phi^{k-3}$ and $F_k \geq \phi^{k-2}$ for some $k \geq 2$.

**Step:** $F_{k+1} = F_k + F_{k-1} \geq \phi^{k-2} + \phi^{k-3} = \phi^{k-3}(\phi + 1)$. Since $\phi^2 = \phi + 1$ (the defining property of the golden ratio!): $= \phi^{k-3} \cdot \phi^2 = \phi^{k-1}$. ✓ ∎

:::callout-intuition
When to use strong vs. weak induction:

If the recurrence defining the quantity references only $k$ (the single previous value), use weak. If it references $k$, $k-1$, or any earlier values (like Fibonacci, or the prime factorization above), use strong. Strong induction is never wrong to use — it's just more general.
:::

## §2.9 — Well-Ordering Principle & Choosing a Proof Strategy

### The Well-Ordering Principle

:::theorem[Axiom]
Well-Ordering Principle

Every nonempty subset of the positive integers has a smallest (least) element.
:::

This is actually *equivalent* to mathematical induction — each can be proved from the other. It gives an alternative proof strategy: assume the theorem fails, take the *smallest counterexample*, and derive a contradiction.

Theorem (via Well-Ordering): Every positive integer > 1 is divisible by a prime.

**Proof.** Let $S$ = {positive integers > 1 with no prime divisor}. Suppose for contradiction $S \neq \emptyset$. By well-ordering, $S$ has a minimum element $m$. Since $m \in S$, $m$ is not prime, so $m = ab$ with $1 < a, b < m$. Since $a < m$ = minimum of $S$, $a \notin S$, so $a$ has a prime divisor $p$. But then $p \mid a \mid m$, so $m$ has a prime divisor — contradiction with $m \in S$. Thus $S = \emptyset$. ∎

### Proof Strategy Cheat Sheet

| Strategy | Use when... | Core move |
| --- | --- | --- |
| **Direct** | $p$ gives you concrete algebra to work with | Assume $p$, derive $q$ |
| **Contrapositive** | $\neg q$ is easier to work with than $p$ | Assume $\neg q$, derive $\neg p$ |
| **Contradiction** | Can't see how to derive $q$; negating $P$ gives something to work with | Assume $\neg P$, reach impossibility |
| **Cases** | Variable could be in several categories (even/odd, positive/zero/negative) | Cover all cases; each implies conclusion |
| **Existence (constructive)** | Need to show something exists; can exhibit a witness | Give the specific example |
| **Weak Induction** | Proving $\forall n \geq n_0,\ P(n)$; step only uses $P(k)$ | BC + IH: $P(k) \Rightarrow P(k+1)$ |
| **Strong Induction** | $P(k+1)$ needs more than just $P(k)$ (e.g., Fibonacci) | BC + IH: all $P(j), j \leq k$ ⇒ $P(k+1)$ |

:::summary
## Chapter Summary — DS–2: Proofs

- **Proofs** are valid arguments built from definitions, axioms, and inference rules. Always start by unpacking definitions (even, odd, divisible, rational) into algebraic form.
- **Direct proof:** Assume $p$, manipulate algebraically, arrive at $q$. Best when $p$ immediately gives usable structure.
- **Contrapositive:** Prove $\neg q \to \neg p$ instead of $p \to q$. Use when $\neg q$ is a concrete arithmetic property and $p$ is abstract.
- **Contradiction:** Assume $\neg P$, derive a logical impossibility. The most flexible strategy — used for irrationality, infinitude of primes, etc.
- **Proof by cases:** Partition into exhaustive cases, prove each. Every integer is even or odd — the most common partition.
- **Existence proofs:** Constructive (exhibit a witness) or non-constructive (show existence without finding it). One counterexample disproves a universal claim.
- **Weak induction:** Base case + $P(k) \Rightarrow P(k+1)$. For sum formulas, inequalities, divisibility patterns.
- **Strong induction:** Base case(s) + all $P(j) (j \leq k) \Rightarrow P(k+1)$. For recurrences that look back more than one step.
- **Well-ordering:** Every nonempty subset of $\mathbb{Z}^+$ has a minimum. Equivalent to induction; enables "smallest counterexample" arguments.
:::

## Practice Problems

:::problem[P1]{difficulty="easy"}
P1 — Direct Proof — Divisibility

Prove: If $n$ is odd, then $n^2 - 1$ is divisible by 8.

::::solution[Solution]
**Direct proof.** Let $n$ be odd, so $n = 2k+1$ for some $k \in \mathbb{Z}$.

$n^2 - 1 = (2k+1)^2 - 1 = 4k^2 + 4k + 1 - 1 = 4k^2 + 4k = 4k(k+1)$

Since $k$ and $k+1$ are consecutive integers, one of them is even: either $2 \mid k$ or $2 \mid (k+1)$. Therefore $2 \mid k(k+1)$, so $8 \mid 4k(k+1) = n^2 - 1$. ∎
::::
:::

:::problem[P2]{difficulty="easy"}
P2 — Choose Your Strategy

Prove: If $n^3$ is even, then $n$ is even. Identify which proof strategy you use and why.

::::solution[Solution]
**Contrapositive** is the right choice: proving the direct direction ($n^3$ even → $n$ even) is awkward because taking cube roots is messy. The contrapositive "if $n$ is odd, then $n^3$ is odd" is straightforward algebra.

**Proof (Contrapositive).** Assume $n$ is odd: $n = 2k+1$.

$n^3 = (2k+1)^3 = 8k^3 + 12k^2 + 6k + 1 = 2(4k^3 + 6k^2 + 3k) + 1$

This is odd. The contrapositive is proved. ∎
::::
:::

:::problem[P3]{difficulty="standard"}
P3 — Proof by Contradiction

Prove: $\sqrt{3}$ is irrational. (Hint: mimic the $\sqrt{2}$ proof, but consider divisibility by 3.)

::::solution[Solution]
**Proof by contradiction.** Assume $\sqrt{3} = p/q$ in lowest terms ($\gcd(p,q) = 1$).

Squaring: $3 = p^2/q^2$, so $p^2 = 3q^2$. Thus $3 \mid p^2$.

Since 3 is prime: if $3 \mid p^2$ then $3 \mid p$ (prime divisibility property). Write $p = 3m$.

Then $(3m)^2 = 3q^2 \Rightarrow 9m^2 = 3q^2 \Rightarrow q^2 = 3m^2$. So $3 \mid q^2$, hence $3 \mid q$.

Now $3 \mid p$ and $3 \mid q$ — contradicting $\gcd(p,q) = 1$. Therefore $\sqrt{3}$ is irrational. ∎
::::
:::

:::problem[P4]{difficulty="standard"}
P4 — Weak Induction — Summation Formula

Prove by mathematical induction: $\displaystyle\sum_{i=1}^{n} i^2 = \frac{n(n+1)(2n+1)}{6}$ for all $n \geq 1$.

::::solution[Solution]
**Base case ($n=1$):** LHS $= 1^2 = 1$. RHS $= \frac{1 \cdot 2 \cdot 3}{6} = 1$. ✓

**IH:** Assume $\displaystyle\sum_{i=1}^{k} i^2 = \frac{k(k+1)(2k+1)}{6}$.

**Inductive step:** Show the formula for $k+1$.

$\displaystyle\sum_{i=1}^{k+1} i^2 = \frac{k(k+1)(2k+1)}{6} + (k+1)^2 = (k+1)\left[\frac{k(2k+1)}{6} + (k+1)\right]$

$= (k+1) \cdot \frac{k(2k+1) + 6(k+1)}{6} = (k+1) \cdot \frac{2k^2+7k+6}{6} = (k+1) \cdot \frac{(k+2)(2k+3)}{6}$

$= \frac{(k+1)(k+2)(2k+3)}{6}$ ✓ This matches the formula with $n = k+1$. By induction, the formula holds for all $n \geq 1$. ∎
::::
:::

:::problem[P5]{difficulty="standard"}
P5 — Strong Induction — Stamps Problem

Prove that every integer $n \geq 8$ can be represented as $3a + 5b$ where $a, b$ are non-negative integers. (This models making $n$ cents with 3-cent and 5-cent stamps.)

::::solution[Solution]
**Proof by strong induction.**

**Base cases:**

- $n = 8 = 3(1) + 5(1)$ ✓
- $n = 9 = 3(3) + 5(0)$ ✓
- $n = 10 = 3(0) + 5(2)$ ✓

**IH (strong):** Assume every integer $j$ with $8 \leq j \leq k$ (where $k \geq 10$) can be expressed as $3a + 5b$.

**Inductive step:** Show $k+1$ works. Since $k \geq 10$, we have $k - 2 \geq 8$. By the IH, $k - 2 = 3a + 5b$ for some $a, b \geq 0$. Then $k+1 = (k-2) + 3 = 3a + 5b + 3 = 3(a+1) + 5b$. ✓

By strong induction, every integer $n \geq 8$ is representable. ∎
::::
:::

:::problem[P6]{difficulty="challenge"}
P6 — Proof by Cases + Induction — Geometric Sum

Prove: For all $n \geq 0$ and $r \neq 1$, $\displaystyle\sum_{i=0}^{n} r^i = \frac{r^{n+1} - 1}{r - 1}$. Then use this result to explain why the running time $T(n) = 1 + 2 + 4 + \cdots + 2^n = 2^{n+1} - 1$, connecting it to the full-binary-tree node count covered in the C++ chapters.

::::solution[Solution]
**Proof by induction on $n$.**

**Base case ($n=0$):** LHS $= r^0 = 1$. RHS $= \frac{r^1 - 1}{r-1} = \frac{r-1}{r-1} = 1$. ✓

**IH:** Assume $\displaystyle\sum_{i=0}^{k} r^i = \frac{r^{k+1}-1}{r-1}$.

**Inductive step:**

$\displaystyle\sum_{i=0}^{k+1} r^i = \frac{r^{k+1}-1}{r-1} + r^{k+1} = \frac{r^{k+1}-1 + r^{k+1}(r-1)}{r-1} = \frac{r^{k+2}-1}{r-1}$ ✓

**CS connection:** Setting $r = 2$: $1 + 2 + 4 + \cdots + 2^n = \frac{2^{n+1} - 1}{2-1} = 2^{n+1} - 1$. A complete binary tree of depth $n$ has nodes at levels $0, 1, \ldots, n$ contributing $2^0 + 2^1 + \cdots + 2^n = 2^{n+1} - 1$ total nodes. This formula also explains why a heap stored in an array has size $O(2^h)$ where $h$ is height, and why building a heap from scratch by repeated insertion costs $O(n \log n)$ total.
::::
:::

## LeetCode Connections

Induction and mathematical identities appear directly in runtime analysis and in problems where closed-form formulas reduce an $O(n)$ loop to $O(1)$. Many "trick" solutions are just applications of the sum formulas you proved above.

| # | Problem | Difficulty | Connection to This Chapter |
| --- | --- | --- | --- |
| [#2652](https://leetcode.com/problems/sum-of-multiples/) | Sum of Multiples | Easy | Apply inclusion-exclusion (a proof-by-cases counting argument) to avoid double-counting multiples of 3, 5, and 7 up to $n$. The formula $\lfloor n/k \rfloor \cdot k \cdot (\lfloor n/k \rfloor+1)/2$ uses the induction-proved triangle-number identity. |
| [#70](https://leetcode.com/problems/climbing-stairs/) | Climbing Stairs | Easy | The recurrence $f(n) = f(n-1) + f(n-2)$ is exactly the Fibonacci structure from §2.8. A strong induction proof shows $f(n) = F_{n+1}$ (Fibonacci). Understanding this lets you jump straight to the closed form or DP. |
| [#231](https://leetcode.com/problems/power-of-two/) | Power of Two | Easy | Prove by induction that powers of 2 have exactly one set bit. The proof structure mirrors §2.7 Example 2 ($2^n > n$). The bit trick `n & (n-1) == 0` is the efficient check, provable by the same inductive reasoning. |
| [#168](https://leetcode.com/problems/excel-sheet-column-title/) | Excel Sheet Column Title | Easy | A bijective base-26 system — prove by induction that the encoding is a bijection (1-1 and onto). Connects to §2.6 existence/uniqueness proofs: showing the encoding always has a unique decoding requires an inductive argument on the number of digits. |
| [#343](https://leetcode.com/problems/integer-break/) | Integer Break | Medium | The optimal greedy strategy (maximize use of 3s) can be proved correct using a proof by cases (compare $n = 3k$, $3k+1$, $3k+2$) plus an inductive argument showing the product grows. A direct algorithmic application of §2.5 proof by cases. |
