---
title: "Variables & Assignments"
source: "cpp_ch2_variables.html"
---

CSE 1384

# Variables & Assignments

§2.1 – §2.24

## Chapter Overview

Variables are how your program *remembers* things. Every number you compute, every name a user types, every running total — all of it lives in a variable. This chapter builds the vocabulary you'll use in every C++ program you ever write: how to declare, name, and manipulate variables of different types, how arithmetic works (including the surprising rules of integer division), and how the computer represents numbers at the bit level.

:::callout-key[Prerequisites]
Chapter 1 — you should be comfortable with the basic structure of a C++ program (`main()`, `cout`, `#include`, compilation). Nothing else is needed.
:::

**What you'll learn:** declaring int/double variables, the rules for naming identifiers, arithmetic operators and precedence, floating-point precision, `const`, the `cmath` library, integer division and modulo, implicit/explicit type conversions, binary representation, overflow, unsigned integers, characters, strings, random numbers, and the `auto` keyword.

## 1 · Variables & the Box Model (§2.1–§2.3)

:::callout-intuition[Intuition]
Think of a variable as a labeled box. You give the box a name (`score`), a type (it can only hold integers), and then you put a value inside it (`95`). Later you can look inside the box, change what's in it, or do math with it. The computer reserves a chunk of memory for each box, and the type tells the computer how big the chunk needs to be.
:::

:::definition[Definition 2.1Variable]
A **variable** is a named storage location in memory that holds a value of a specific type. The value can change during program execution. A variable must be *declared* before it is used.
:::

### Declaring and Assigning int Variables (§2.1, §2.2)

The most common whole-number type in C++ is `int`, which typically stores 32-bit signed integers (roughly −2.1 billion to +2.1 billion).

```cpp
// Declaration: reserve a box named "score" that holds ints
int score;

// Assignment: put 95 into that box
score = 95;

// Declaration + assignment in one line (initialization)
int age = 20;

// You can declare multiple variables of the same type at once
int x = 3, y = 7, z = 0;

// Read from a variable using its name
cout << score;   // prints 95
```

:::callout-warning[Watch out — uninitialized variables]
If you declare a variable but never assign a value, it contains *garbage* — whatever bits happened to be sitting in that memory location. Reading an uninitialized variable gives unpredictable results. **Always initialize your variables** when you declare them, or assign before you first use them.
:::

### Identifiers & Naming Rules (§2.3)

An **identifier** is a name you give to a variable, function, or other program entity. C++ naming rules:

- May contain letters (`a–z`, `A–Z`), digits (`0–9`), and underscores (`_`)
- Must *start* with a letter or underscore (never a digit)
- Case-sensitive: `Score` and `score` are different identifiers
- Cannot be a reserved keyword (`int`, `return`, `while`, etc.)

| Valid | Invalid | Why invalid |
| --- | --- | --- |
| `age` | `2fast` | Starts with digit |
| `player_score` | `player-score` | Hyphens not allowed |
| `totalCost` | `int` | Reserved keyword |
| `_helper` | `my score` | Spaces not allowed |

**Convention in this course:** use *camelCase* for variable names (`totalScore`, `playerAge`) and *ALL\_CAPS\_WITH\_UNDERSCORES* for named constants (`MAX_SPEED`).

### Worked Examples

:::example[Example 2.1 — Declare, assign, and print]
Write a program that stores a student's score (88) and number of absences (2), then prints both with labels.

::::answer[Answer]

::::

```cpp
#include <iostream>
using namespace std;

int main() {
    int score = 88;
    int absences = 2;

    cout << "Score: " << score << endl;
    cout << "Absences: " << absences << endl;

    return 0;
}
// Output:
// Score: 88
// Absences: 2
```
:::

:::example[Example 2.2 — Swap two variables]
Given `int a = 5, b = 9;`, swap their values so `a` becomes 9 and `b` becomes 5. You may not just reassign directly.

::::answer[use a temporary variable]

::::

You need a third "temp" box to hold one value while you move the other:

```cpp
int a = 5, b = 9;
int temp = a;   // temp = 5, a = 5, b = 9
a = b;          // temp = 5, a = 9, b = 9
b = temp;       // temp = 5, a = 9, b = 5
cout << a << " " << b;  // 9 5
```

If you tried `a = b; b = a;` without `temp`, you'd overwrite `a`'s original value and both would end up as 9.
:::

### Practice — Variables & Identifiers

:::problem[2.1easy]{difficulty="easy"}
Which of the following are *valid* C++ identifiers? Circle all that apply.

`myAge`   `3score`   `total_cost`   `double`   `_x`   `player 1`   `MAX`

::::solution[Solution]
Valid: `myAge`, `total_cost`, `_x`, `MAX`

 Invalid: `3score` (starts with digit), `double` (reserved keyword), `player 1` (contains space).
::::
:::

:::problem[2.2easy]{difficulty="easy"}
Declare an `int` variable `year` initialized to 2024. Then write a second statement that changes it to 2025.

::::solution[Solution]
```cpp
int year = 2024;
year = 2025;
```

Note: no `int` on the second line — you only declare once; after that you just assign.
::::
:::

:::problem[2.3standard]{difficulty="standard"}
What does the following print?

`int x = 10; int y = x; x = 99; cout << y;`

::::solution[Solution]
**10.** When you write `int y = x;`, y gets a *copy* of x's value (10). Changing x to 99 afterward doesn't affect y — variables store independent copies, not references.
::::
:::

:::problem[2.4standard]{difficulty="standard"}
Write a program that declares three integer variables representing the lengths of a triangle's sides (e.g., 3, 4, 5) and prints their sum.

::::solution[Solution]
```cpp
#include <iostream>
using namespace std;
int main() {
    int a = 3, b = 4, c = 5;
    cout << "Perimeter: " << a + b + c << endl;
    return 0;
}
```
::::
:::

:::problem[2.5challenge]{difficulty="challenge"}
Without using a temporary variable and without using arithmetic, describe (in plain English or pseudocode) how XOR can swap two integers. Why does this work?

::::solution[Solution]
XOR swap: `a ^= b; b ^= a; a ^= b;`

It works because XOR is its own inverse: `x ^ x == 0` and `x ^ 0 == x`. After step 1, `a` holds `a_orig XOR b_orig`. Step 2 extracts `b = (a_orig XOR b_orig) XOR b_orig = a_orig`. Step 3 recovers `a = (a_orig XOR b_orig) XOR a_orig = b_orig`. Note: never use XOR swap when `a` and `b` are the *same variable* — it zeroes the value.
::::
:::

## 2 · Arithmetic Expressions (§2.4–§2.6)

:::callout-intuition[Intuition]
Arithmetic in C++ looks almost exactly like math class — `+`, `-`, `*`, `/` — with one big surprise: when both operands are integers, division gives you an integer result (truncated toward zero, not rounded). That behavior trips up almost every beginner at least once.
:::

### The Five Basic Operators

| Operator | Name | Example | Result |
| --- | --- | --- | --- |
| `+` | Addition | `3 + 4` | 7 |
| `-` | Subtraction | `10 - 6` | 4 |
| `*` | Multiplication | `5 * 3` | 15 |
| `/` | Division | `7 / 2` | 3 (int!) |
| `%` | Modulo (remainder) | `7 % 2` | 1 |

### Operator Precedence

C++ follows standard math order of operations: `*`, `/`, `%` are evaluated before `+` and `-`. Equal-precedence operators evaluate left to right. Use parentheses to override.

```cpp
int result = 3 + 4 * 2;    // 3 + 8 = 11  (not 14)
int result2 = (3 + 4) * 2; // 7 * 2 = 14
int result3 = 10 - 3 - 2;  // (10 - 3) - 2 = 5  (left-to-right)
```

### Compound Assignment & Increment/Decrement

Shortcuts that modify a variable in place:

```cpp
int n = 10;

n += 5;   // same as n = n + 5;  → n = 15
n -= 3;   // n = n - 3;          → n = 12
n *= 2;   // n = n * 2;          → n = 24
n /= 4;   // n = n / 4;          → n = 6
n %= 4;   // n = n % 4;          → n = 2

n++;      // n = n + 1;          → n = 3  (post-increment)
++n;      // n = n + 1;          → n = 4  (pre-increment)
n--;      // n = n - 1;          → n = 3  (post-decrement)
```

The difference between `n++` and `++n` matters when used inside a larger expression: `n++` returns the old value first, then increments; `++n` increments first, then returns the new value.

### §2.6 Health Data Example

:::example[Example 2.3 — BMI Calculator]
A patient's weight is 70 kg and height is 1.75 m. Compute and print their BMI. BMI = weight / (height × height).

::::answer[Answer]

::::

```cpp
#include <iostream>
using namespace std;

int main() {
    double weight = 70.0;    // kg
    double height = 1.75;    // m
    double bmi = weight / (height * height);

    cout << "BMI: " << bmi << endl;   // BMI: 22.8571
    return 0;
}
```

Note that we use `double` here (not `int`) because the result has a fractional part. We'll cover `double` fully in the next section.
:::

:::example[Example 2.4 — Running total with +=]
Start with a balance of 1000. Add a deposit of 250, then subtract a fee of 35. Print the final balance using compound assignment operators.

::::answer[Answer]

::::

```cpp
int balance = 1000;
balance += 250;   // balance = 1250
balance -= 35;    // balance = 1215
cout << "Balance: $" << balance << endl;  // Balance: $1215
```
:::

:::callout-pitfall[Common Pitfalls]
- **Integer division truncates:** `7 / 2` is `3`, not `3.5`. If you need 3.5, at least one operand must be a `double` (see §2.7).
- **Forgetting parentheses:** `a + b / c` divides first, then adds — often not what you want.
- **Division by zero:** causes undefined behavior for integers (runtime crash). Always check that a divisor can't be zero.
:::

### Practice — Arithmetic

:::problem[2.6easy]{difficulty="easy"}
What is the value of `result` after: `int result = 2 + 3 * 4 - 1;`

::::solution[Solution]
**13.** Multiplication first: `3 * 4 = 12`. Then left-to-right: `2 + 12 = 14`, then `14 - 1 = 13`.
::::
:::

:::problem[2.7easy]{difficulty="easy"}
What does `cout << 17 / 5 << " " << 17 % 5;` print?

::::solution[Solution]
**3 2.** Integer division: 17 ÷ 5 = 3 remainder 2. So `17/5 = 3` and `17%5 = 2`. Verify: 3 × 5 + 2 = 17. ✓
::::
:::

:::problem[2.8standard]{difficulty="standard"}
Write code that computes the number of minutes and remaining seconds given a total of `int totalSeconds = 245;`.

::::solution[Solution]
```cpp
int totalSeconds = 245;
int minutes = totalSeconds / 60;    // 4
int seconds = totalSeconds % 60;    // 5
cout << minutes << " min " << seconds << " sec" << endl;
// Output: 4 min 5 sec
```
::::
:::

:::problem[2.9standard]{difficulty="standard"}
Given `int x = 5;`, what are the values of `a` and `x` after `int a = x++;`? What about after `int b = ++x;` (starting fresh from x=5)?

::::solution[Solution]
**Post-increment (`x++`):** `a = 5`, then `x` becomes 6. The old value is returned first.

**Pre-increment (`++x`):** `x` becomes 6 first, then `b = 6`. The new value is returned.
::::
:::

:::problem[2.10challenge]{difficulty="challenge"}
Write a program that takes a 4-digit integer (e.g., 1234) stored as `int num = 1234;` and extracts each individual digit using only `/` and `%`. Print them on separate lines.

::::solution[Solution]
```cpp
int num = 1234;
int thousands = num / 1000;         // 1
int hundreds  = (num / 100) % 10;   // 2
int tens      = (num / 10)  % 10;   // 3
int ones      = num % 10;           // 4
cout << thousands << "\n" << hundreds << "\n"
     << tens << "\n" << ones << endl;
```

Key insight: dividing by a power of 10 shifts digits right; modulo 10 extracts the last digit.
::::
:::

## 3 · Floating-Point Numbers (§2.7–§2.8)

:::callout-intuition[Intuition]
Integers can't store fractions. To represent 3.14, 98.6°F, or $19.99, you need a **floating-point** type. C++ gives you `float` (32-bit, ~7 significant digits) and `double` (64-bit, ~15 significant digits). Use `double` by default — it's more precise and modern hardware handles it just as fast.
:::

```cpp
double price    = 19.99;
double pi       = 3.14159265358979;
double tiny     = 0.000001;
double negative = -273.15;   // absolute zero in Celsius

// Arithmetic works the same as int:
double area = pi * 3.5 * 3.5;   // pi * r^2, r = 3.5
cout << area;   // 38.4845...
```

### Scientific Notation Literals (§2.8)

For very large or very small numbers you can use the `e` notation directly in your code. `6.02e23` means $6.02 \times 10^{23}$; `1.6e-19` means $1.6 \times 10^{-19}$.

```cpp
double avogadro    = 6.022e23;    // 6.022 × 10^23
double electronCharge = 1.602e-19; // 1.602 × 10^-19
double speed = 3.0e8;              // 3 × 10^8 m/s (speed of light)
```

### Mixing int and double

When you perform arithmetic between an `int` and a `double`, C++ automatically promotes the int to double — so the result is a `double`:

```cpp
int a = 7;
double b = 2.0;
double result = a / b;   // 7 → 7.0, then 7.0/2.0 = 3.5  ✓

// But this is STILL integer division:
double bad = a / 2;   // 7/2 = 3 (int math!), then 3 → 3.0  ✗
```

:::callout-pitfall[Floating-Point Precision Pitfall]
Floating-point numbers are stored in binary, and most decimal fractions can't be represented exactly. The number 0.1 is stored as the closest binary approximation (~0.1000000000000000055511...). This means:

```cpp
double x = 0.1 + 0.2;
cout << (x == 0.3);   // prints 0 (false!!)
```

Never compare floating-point values with `==`. Instead, check whether they're *close enough*: `abs(x - 0.3) < 1e-9`.
:::

### Controlling Output Precision

```cpp
#include <iostream>
#include <iomanip>
using namespace std;

double pi = 3.14159265;
cout << fixed << setprecision(2) << pi;   // 3.14
cout << fixed << setprecision(5) << pi;   // 3.14159
```

### Practice — Floating-Point

:::problem[2.11easy]{difficulty="easy"}
What does `cout << 5 / 2.0;` print? What about `cout << 5 / 2;`?

::::solution[Solution]
`5 / 2.0` → **2.5** (double division, because 2.0 is a double literal).

`5 / 2` → **2** (integer division, both operands are ints).
::::
:::

:::problem[2.12standard]{difficulty="standard"}
Write a program that computes the area of a circle with radius `4.5`. Use `double pi = 3.14159;` and print the answer rounded to 2 decimal places.

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    double pi = 3.14159;
    double r  = 4.5;
    double area = pi * r * r;
    cout << fixed << setprecision(2) << area << endl;  // 63.62
    return 0;
}
```
::::
:::

:::problem[2.13standard]{difficulty="standard"}
Express the speed of light ($2.998 \times 10^8$ m/s) as a C++ `double` literal using `e` notation, and print it.

::::solution[Solution]
```cpp
double c = 2.998e8;
cout << c << endl;   // 2.998e+08  or  299800000
```
::::
:::

:::problem[2.14challenge]{difficulty="challenge"}
A student writes `double avg = 70 + 80 + 90 / 3;` hoping to get 80.0. What do they actually get, and why? Write the corrected version.

::::solution[Solution]
They get **180.0**, not 80.0. Division has higher precedence than addition, so `90 / 3 = 30` first, then `70 + 80 + 30 = 180`. The variable type is `double` but that doesn't affect the arithmetic — type only matters for storing the result.

```cpp
// Corrected:
double avg = (70 + 80 + 90) / 3.0;   // 240 / 3.0 = 80.0
```

Using `3.0` (not `3`) forces floating-point division; the parentheses ensure we sum first.
::::
:::

## 4 · Constants & Math Functions (§2.9–§2.10)

### The `const` Keyword (§2.9)

:::callout-intuition[Intuition]
Some values should *never* change: the value of π, the number of hours in a day, a maximum allowed speed. Marking them `const` does two things: (1) the compiler prevents accidental modification and gives an error if you try, and (2) it communicates intent to anyone reading your code.
:::

```cpp
const double PI = 3.14159265358979;
const int HOURS_PER_DAY = 24;
const double TAX_RATE = 0.08;

// PI = 3.14;   // ERROR: assignment of read-only variable 'PI'
```

By convention, `const` variables are named in ALL\_CAPS. You must initialize them at declaration — you can't set a `const` later.

### Math Functions with `<cmath>` (§2.10)

The `<cmath>` header provides standard mathematical functions. Add `#include <cmath>` at the top of your file.

| Function | What it does | Example | Result |
| --- | --- | --- | --- |
| `sqrt(x)` | Square root | `sqrt(9.0)` | 3.0 |
| `pow(b,e)` | b raised to the e | `pow(2.0, 10.0)` | 1024.0 |
| `abs(x)` | Absolute value (int) | `abs(-7)` | 7 |
| `fabs(x)` | Absolute value (double) | `fabs(-3.5)` | 3.5 |
| `ceil(x)` | Round up | `ceil(2.1)` | 3.0 |
| `floor(x)` | Round down | `floor(2.9)` | 2.0 |
| `round(x)` | Round to nearest | `round(2.5)` | 3.0 |
| `log(x)` | Natural log ln(x) | `log(M_E)` | 1.0 |
| `log10(x)` | Base-10 log | `log10(100)` | 2.0 |

:::example[Example 2.5 — Hypotenuse of a right triangle]
Compute the hypotenuse of a right triangle with legs a = 3.0 and b = 4.0. Use the Pythagorean theorem: $c = \sqrt{a^2 + b^2}$.

::::answer[Answer: 5.0]

::::

```cpp
#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double a = 3.0, b = 4.0;
    double c = sqrt(pow(a, 2.0) + pow(b, 2.0));
    // Or equivalently: sqrt(a*a + b*b)
    cout << "Hypotenuse: " << c << endl;   // 5
    return 0;
}
```
:::

:::callout-warning[pow() is for doubles]
Don't use `pow(2, 10)` expecting an integer result. `pow` works with doubles and can introduce tiny floating-point errors for integer exponents (e.g., you might get 1023.9999... instead of 1024). For integer powers, use repeated multiplication or write your own loop.
:::

### Practice — Constants & Math Functions

:::problem[2.15easy]{difficulty="easy"}
What does `cout << ceil(3.0) << " " << floor(3.0) << " " << ceil(3.1) << " " << floor(3.9);` print?

::::solution[Solution]
**3 3 4 3**. `ceil(3.0) = 3` (already whole), `floor(3.0) = 3`, `ceil(3.1) = 4` (rounds up), `floor(3.9) = 3` (rounds down).
::::
:::

:::problem[2.16standard]{difficulty="standard"}
Declare a constant for the speed of sound in air (343 m/s). Then compute how long it takes sound to travel 1 km and print the result in seconds (to 3 decimal places).

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    const double SPEED_SOUND = 343.0;  // m/s
    double distance = 1000.0;           // 1 km in meters
    double time = distance / SPEED_SOUND;
    cout << fixed << setprecision(3) << time << " s" << endl;  // 2.915 s
    return 0;
}
```
::::
:::

:::problem[2.17challenge]{difficulty="challenge"}
The distance formula between two points $(x_1,y_1)$ and $(x_2,y_2)$ is $d = \sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}$. Write a complete program that computes the distance between (1.0, 2.0) and (4.0, 6.0). What is the exact answer?

::::solution[Solution]
Exact answer: $\sqrt{(3)^2 + (4)^2} = \sqrt{9+16} = \sqrt{25} = 5.0$

```cpp
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double x1=1.0, y1=2.0, x2=4.0, y2=6.0;
    double dx = x2 - x1;   // 3.0
    double dy = y2 - y1;   // 4.0
    double d = sqrt(dx*dx + dy*dy);
    cout << "Distance: " << d << endl;  // 5
    return 0;
}
```
::::
:::

## 5 · Integer Division & Modulo (§2.11)

:::callout-intuition[Intuition]
When two children split 7 cookies equally, each gets 3 and there's 1 left over. C++ integer division gives you the "3" (`7 / 2 = 3`) and modulo gives you the "1 left over" (`7 % 2 = 1`). Together they're incredibly useful: converting seconds to minutes, checking if a number is even, extracting digits, cycling through array indices.
:::

```cpp
// The relationship: a = (a/b)*b + (a%b)
cout << 17 / 5;   // 3   (quotient)
cout << 17 % 5;   // 2   (remainder: 17 = 3*5 + 2)

// Check even/odd:
int n = 42;
if (n % 2 == 0) cout << "even";  // 42 is even

// Extract last digit:
int num = 1738;
int lastDigit = num % 10;         // 8

// Wrap around (cycling):
int position = 7 % 5;             // 2  (position in array of size 5)
```

### Negative Operands

When the dividend (left side) is negative, C++ truncates *toward zero*:

```cpp
cout << -7 / 2;    // -3  (not -4; truncates toward 0)
cout << -7 % 2;    // -1  (sign of result matches dividend)
cout <<  7 / -2;   // -3
cout <<  7 % -2;   //  1  (sign of result matches dividend)
```

:::callout-pitfall[Modulo with Negative Numbers]
In C++, `-7 % 2` gives `-1`, not `1`. If you need a non-negative remainder (e.g., for circular array indexing), use: `((x % n) + n) % n`.
:::

### Practice — Integer Division & Modulo

:::problem[2.18easy]{difficulty="easy"}
A movie is 137 minutes long. Write expressions to compute how many full hours that is, and how many minutes remain.

::::solution[Solution]
```cpp
int totalMin = 137;
int hours   = totalMin / 60;   // 2
int minutes = totalMin % 60;   // 17
cout << hours << "h " << minutes << "m";  // 2h 17m
```
::::
:::

:::problem[2.19standard]{difficulty="standard"}
Write an expression that returns `true` if an integer `n` is divisible by both 3 and 5.

::::solution[Solution]
```cpp
bool divisible = (n % 3 == 0) && (n % 5 == 0);
// Equivalently: n % 15 == 0
```
::::
:::

:::problem[2.20challenge]{difficulty="challenge"}
Given an integer `n` representing a number of seconds (could be very large), write code that prints it in HH:MM:SS format. For example, 3723 seconds → 1:02:03.

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int n = 3723;
    int hours   = n / 3600;
    int minutes = (n % 3600) / 60;
    int seconds = n % 60;
    cout << hours << ":"
         << setw(2) << setfill('0') << minutes << ":"
         << setw(2) << setfill('0') << seconds << endl;
    // Output: 1:02:03
    return 0;
}
```

`setw(2)` pads to width 2; `setfill('0')` fills with zeros instead of spaces — that's how you get "02" instead of " 2".
::::
:::

## 6 · Type Conversions (§2.12)

:::callout-intuition[Intuition]
C++ is strongly typed — every variable has a fixed type — but values sometimes need to move between types. There are two kinds of conversion: *implicit* (C++ does it automatically, sometimes silently losing data) and *explicit* (you tell C++ exactly what you want with a cast).
:::

### Implicit Conversion

**Widening** (safe — no data loss): smaller type → larger type.

```cpp
int   i = 42;
double d = i;    // 42 → 42.0  (widening: int → double, safe)
```

**Narrowing** (potentially unsafe — data loss): larger type → smaller type.

```cpp
double pi = 3.14159;
int    n  = pi;   // 3.14159 → 3  (fractional part DROPPED, no warning!)
```

### Explicit Cast: `static_cast<>()`

When you intentionally want to convert between types, use `static_cast`. This is the modern C++ way — it's explicit, safe, and searchable:

```cpp
int a = 7, b = 2;

// Without cast: integer division
double bad = a / b;          // 3.0 (computed as int 3, then stored as double)

// With cast: force floating-point division
double good = static_cast<double>(a) / b;   // 3.5  ✓

// Cast result of an expression
int score = static_cast<int>(98.7);         // 98 (truncates)
```

:::example[Example 2.6 — Letter grade percentage]
A student got 37 out of 50 questions correct. Compute the percentage as a decimal (74.0%), not integer (74%).

::::answer[Answer: 74.0%]

::::

```cpp
int correct = 37, total = 50;

// Wrong: integer division
double pctBad = correct / total * 100;             // 0 * 100 = 0 !!

// Right: cast before dividing
double pctGood = static_cast<double>(correct) / total * 100;  // 74.0

cout << pctGood << "%" << endl;  // 74%
```

The bug in the "wrong" version: `37 / 50` is integer division → 0, then `0 * 100 = 0`. Always cast *before* the division.
:::

:::callout-pitfall[Common Pitfalls]
- **Casting the result, not the operand:** `static_cast<double>(a / b)` still does integer division first, then converts 3 → 3.0. You need `static_cast<double>(a) / b`.
- **C-style casts:** You may see `(double)a` in older code. Prefer `static_cast<double>(a)` — it's safer and easier to find with a text search.
:::

### Practice — Type Conversions

:::problem[2.21easy]{difficulty="easy"}
What is the value of `x`? `int x = static_cast<int>(9.9);`

::::solution[Solution]
**9**. `static_cast<int>` truncates toward zero — the fractional part is dropped, not rounded.
::::
:::

:::problem[2.22standard]{difficulty="standard"}
Three students scored 71, 84, and 90. Compute their average as a `double` (should be 81.6̄) using `static_cast`.

::::solution[Solution]
```cpp
int a = 71, b = 84, c = 90;
double avg = static_cast<double>(a + b + c) / 3;  // 245 / 3 = 81.666...
cout << avg;
```

Cast the entire sum `(a+b+c)` — that way the sum is computed as int first (fine), then the division is floating-point.
::::
:::

## 7 · Binary & Numeric Types (§2.13, §2.16–§2.18) LOGIC

:::callout-connect[Downstream Connection]
This section is tagged **LOGIC** — it's foundational for ECE Digital Devices & Logic Design. Binary representation, overflow behavior, and unsigned integers appear constantly in hardware-level programming.
:::

### Binary Representation (§2.13)

:::callout-intuition[Intuition]
Computers store everything as bits (0s and 1s). A 32-bit `int` is literally 32 switches. To convert a decimal number to binary: repeatedly divide by 2 and collect the remainders from bottom to top.
:::

Each bit position represents a power of 2:

$$
\underbrace{1}_{2^3}\underbrace{0}_{2^2}\underbrace{1}_{2^1}\underbrace{1}_{2^0} = 8 + 0 + 2 + 1 = 11
$$

```cpp
// C++14+ binary literals (prefix 0b):
int a = 0b1011;    // binary 1011 = 11
int b = 0b11111111; // binary 11111111 = 255

// Hex literals (prefix 0x) — each hex digit = 4 bits:
int c = 0xFF;      // hex FF = 255
int d = 0x1A;      // hex 1A = 26

cout << a << " " << c;   // 11 255
```

:::example[Example 2.7 — Decimal to binary by hand]
Convert 45 to binary.

::::answer[Answer: 0b101101]

::::

Work

Divide by 2, write remainders:

```

45 ÷ 2 = 22  R 1   ← least significant bit
22 ÷ 2 = 11  R 0
11 ÷ 2 =  5  R 1
 5 ÷ 2 =  2  R 1
 2 ÷ 2 =  1  R 0
 1 ÷ 2 =  0  R 1   ← most significant bit

Reading remainders bottom-to-top: 101101
```

Verify: $1\times32 + 0\times16 + 1\times8 + 1\times4 + 0\times2 + 1\times1 = 32+8+4+1 = 45$ ✓
:::

### Integer Overflow (§2.16)

A 32-bit signed `int` can hold values from $-2^{31}$ to $2^{31}-1$ (about −2.1 billion to +2.1 billion). If a computation exceeds this range, the result *wraps around* — you don't get an error, you get garbage:

```cpp
int maxInt = 2147483647;   // 2^31 - 1, the largest int
cout << maxInt + 1;        // -2147483648 !!  (overflow: wraps to min)
```

Use `long long` (64-bit, up to ~9.2 × 10¹⁸) when you need larger values.

### Numeric Data Types (§2.17)

| Type | Size | Range | Use when… |
| --- | --- | --- | --- |
| `short` | 16-bit | −32768 to 32767 | Memory is very constrained |
| `int` | 32-bit | ~±2.1 billion | Default integer choice |
| `long long` | 64-bit | ~±9.2 × 10¹⁸ | Large counts, timestamps |
| `float` | 32-bit | ~7 sig. digits | Graphics (GPU prefers float) |
| `double` | 64-bit | ~15 sig. digits | Default floating-point choice |
| `bool` | 8-bit | `true` / `false` | Flags and conditions |
| `char` | 8-bit | 0–255 (ASCII) | Single characters |

### Unsigned Integers (§2.18) LOGIC

Adding `unsigned` before an integer type makes it non-negative and *doubles the positive range* (no bits wasted on sign):

```cpp
unsigned int u = 4294967295u;   // 2^32 - 1 (max for 32-bit unsigned)\nu++;                             // wraps to 0 (unsigned overflow is defined!)

// Common in hardware/systems programming:
uint8_t  byte_val  = 255;        // 8-bit unsigned (0–255)
uint16_t port_num  = 8080;       // 16-bit unsigned
uint32_t pixel     = 0xFF5733u;  // RGB color as 32-bit hex
```

:::callout-pitfall[Mixing Signed and Unsigned]
When you compare or compute with mixed signed/unsigned values, the signed value gets silently converted to unsigned — and if it was negative, it becomes a huge positive number. Example: `-1 < 0u` evaluates to **false** because -1 becomes 4294967295.
:::

### Practice — Binary & Numeric Types

:::problem[2.23easy]{difficulty="easy"}
Convert `0b10110` to decimal.

::::solution[Solution]
$1\times16 + 0\times8 + 1\times4 + 1\times2 + 0\times1 = 16+4+2 = \mathbf{22}$
::::
:::

:::problem[2.24standard]{difficulty="standard"}
Convert decimal 100 to binary.

::::solution[Solution]
100 ÷ 2 = 50 R 0 | 50 ÷ 2 = 25 R 0 | 25 ÷ 2 = 12 R 1 | 12 ÷ 2 = 6 R 0 | 6 ÷ 2 = 3 R 0 | 3 ÷ 2 = 1 R 1 | 1 ÷ 2 = 0 R 1

 Bottom-to-top: **1100100**

 Verify: 64+32+4 = 100 ✓
::::
:::

:::problem[2.25standard]{difficulty="standard"}
What type would you use for: (a) a person's age, (b) a pixel's red channel value (0–255), (c) the number of atoms in the universe (~10⁸⁰), (d) a temperature like 98.6°F?

::::solution[Solution]
(a) `int` — small positive whole number. (b) `unsigned char` or `uint8_t` — exactly 0–255 range. (c) No integer type can hold 10⁸⁰; use `double` for the magnitude. (d) `double` — fractional temperature.
::::
:::

## 8 · Characters & Strings (§2.14–§2.15)

### The `char` Type (§2.14)

:::callout-intuition[Intuition]
A `char` is a single character — one letter, digit, punctuation mark, or special symbol. Under the hood it's just an integer (0–127 in ASCII). The character `'A'` is stored as the number 65. This dual nature (character AND number) lets you do arithmetic on characters: `'A' + 1 == 'B'`.
:::

```cpp
char grade  = 'A';       // single quotes for char literals
char newline = '\n';     // escape sequences are also single chars
char tab     = '\t';

// char is really a small integer:
cout << (int)'A';        // 65 (ASCII code for 'A')
cout << (int)'a';        // 97
cout << (char)66;        // 'B'  (65+1)

// Arithmetic on chars:
char ch = 'e';
cout << (char)(ch - 32); // 'E'  (lowercase to uppercase: subtract 32)
```

| Character | ASCII Code | Character | ASCII Code |
| --- | --- | --- | --- |
| `'0'`–`'9'` | 48–57 | `'A'`–`'Z'` | 65–90 |
| `'a'`–`'z'` | 97–122 | `' '` (space) | 32 |
| `'\n'` | 10 | `'\t'` | 9 |

### The `string` Type (§2.15)

A `string` is a sequence of characters. It requires `#include <string>` (usually included via `<iostream>` in practice, but best to include explicitly).

```cpp
#include <string>
using namespace std;

string name = "Alice";
string greeting = "Hello, " + name + "!";  // concatenation with +
cout << greeting;    // Hello, Alice!

// Length / size:
cout << name.length();     // 5
cout << name.size();       // 5  (same as length())

// Access individual character by index (0-based):
cout << name[0];           // 'A'
cout << name[4];           // 'e'

// Check if empty:
string empty = "";
cout << empty.empty();     // 1 (true)

// Substring: .substr(start_index, length)
cout << name.substr(1, 3); // "lic"  (starting at index 1, 3 chars)
```

:::callout-warning[String concatenation vs. arithmetic]
`"5" + "3"` gives `"53"` (string concatenation), not `8`. Don't confuse strings of digits with actual numbers. If `s = "42"`, use `stoi(s)` to convert to int, or `stod(s)` to convert to double.
:::

### Practice — Characters & Strings

:::problem[2.26easy]{difficulty="easy"}
What does `cout << 'Z' - 'A';` print?

::::solution[Solution]
**25**. 'Z' = 90, 'A' = 65, so 90 − 65 = 25. This is how you find the alphabetical distance between two letters.
::::
:::

:::problem[2.27standard]{difficulty="standard"}
Write code that takes `string word = "programming";` and prints: (a) its length, (b) the first character, (c) the last character, (d) the substring "gram".

::::solution[Solution]
```cpp
string word = "programming";
cout << word.length()           << "\n";  // 11
cout << word[0]                 << "\n";  // 'p'
cout << word[word.length() - 1] << "\n";  // 'g'
cout << word.substr(3, 4)       << "\n";  // "gram"
```

"gram" starts at index 3 ('g' = index 3), length 4.
::::
:::

:::problem[2.28challenge]{difficulty="challenge"}
Write an expression that converts a digit *character* like `'7'` to its numeric value 7, using only arithmetic on the character (no library functions).

::::solution[Solution]
```cpp
char digitChar = '7';
int numericVal = digitChar - '0';   // '7' (55) - '0' (48) = 7
```

This works because digit characters '0'–'9' have consecutive ASCII codes 48–57. Subtracting '0' (48) gives the actual digit value.
::::
:::

## 9 · Random Numbers (§2.19)

:::callout-intuition[Intuition]
Games, simulations, and tests all need random numbers. C++ provides `rand()` which generates a pseudo-random integer between 0 and `RAND_MAX` (at least 32767). "Pseudo-random" means it's a mathematical sequence that *looks* random — it starts from a *seed*. Use the same seed and you get the same sequence every time (great for debugging). Use `time(0)` as the seed for a different sequence each run.
:::

```cpp
#include <iostream>
#include <cstdlib>   // for rand(), srand(), RAND_MAX
#include <ctime>     // for time()
using namespace std;

int main() {
    // Seed with current time (different sequence each run)
    srand(time(0));

    // Generate a random int in range [low, high] inclusive:
    // Formula: low + rand() % (high - low + 1)
    int low = 1, high = 6;
    int dieRoll = low + rand() % (high - low + 1);

    cout << "Die roll: " << dieRoll << endl;  // 1, 2, 3, 4, 5, or 6

    // Random double in [0.0, 1.0):
    double r = static_cast<double>(rand()) / (RAND_MAX + 1.0);
    cout << "Random double: " << r << endl;

    return 0;
}
```

:::callout-warning[Modern Alternative]
C++11 introduced `<random>` with better distributions and generators. For this course, `rand()`/`srand()` is standard. In professional code, prefer `std::mt19937` with `std::uniform_int_distribution`.
:::

### Practice — Random Numbers

:::problem[2.29easy]{difficulty="easy"}
Write the expression to generate a random integer between 10 and 20 inclusive.

::::solution[Solution]
```cpp
int r = 10 + rand() % 11;   // range = 20 - 10 + 1 = 11
```
::::
:::

:::problem[2.30standard]{difficulty="standard"}
Write a complete program that simulates rolling two 6-sided dice and prints their sum. Seed with `time(0)`.

::::solution[Solution]
```cpp
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main() {
    srand(time(0));
    int die1 = 1 + rand() % 6;
    int die2 = 1 + rand() % 6;
    cout << "Die 1: " << die1 << ", Die 2: " << die2
         << ", Sum: " << (die1 + die2) << endl;
    return 0;
}
```
::::
:::

## 10 · Debugging, `auto`, and Style (§2.20–§2.22)

### Debugging Strategies (§2.20)

When output doesn't match expectation, start with these techniques:

- **Trace with `cout`:** Add temporary print statements to show variable values at key points. Remove them before submitting.
- **Desk check:** Trace the code manually on paper before running it. Catches logic errors before you ever compile.
- **Narrow it down:** Comment out half the code, test — if bug is gone, it's in the commented half. Repeat (binary search the code).
- **Read compiler errors bottom-up:** The first error often causes a cascade of fake errors below it. Fix the first real error and recompile.

:::example[Example 2.8 — Debugging a wrong average]
A student's code prints 0 instead of 75 for an average. Add a trace to find the bug.

```cpp
// Buggy version:
int a = 70, b = 80;
double avg = a + b / 2;   // Expected 75, got 110
```

::::answer[Debug trace reveals the bug]

::::

```cpp
int a = 70, b = 80;
cout << "b/2 = " << b/2 << endl;   // Prints: b/2 = 40
cout << "a + b/2 = " << a + b/2;   // Prints: 110 ← bug found!

// Fix: use parentheses
double avg = (a + b) / 2.0;   // 75.0  ✓
```
:::

### The `auto` Keyword (§2.21)

In C++11 and later, you can use `auto` and let the compiler deduce the type from the initializer:

```cpp
auto x = 42;          // x is int
auto y = 3.14;        // y is double
auto z = 'A';         // z is char
auto s = string("hi"); // s is string

// Useful with long type names:
auto result = static_cast<double>(10) / 3;  // result is double
```

`auto` is great when the type is obvious from context. Don't overuse it — explicit types make code easier to read for beginners and reviewers.

### Style Guidelines (§2.22)

| Rule | Example |
| --- | --- |
| One statement per line | `int x = 1; int y = 2;` |
| Spaces around operators | `area = pi * r * r;` |
| camelCase for variables | `totalScore, playerAge` |
| ALL\_CAPS for constants | `MAX_SIZE, TAX_RATE` |
| Blank lines between logical blocks | After `#include`s, after declarations |
| Meaningful names | `numStudents` not `ns` |
| Initialize all variables | `int count = 0;` not `int count;` |

## 11 · Full Worked Examples (§2.23–§2.24)

:::example[Example 2.9 — Salary Calculation with Variables (§2.23)]
An employee earns $18.75/hour and works 43 hours this week. Hours over 40 are paid at 1.5× rate. Compute and print regular pay, overtime pay, and total pay.

::::answer[Answer: Regular $750.00 | Overtime $84.38 | Total $834.38]

::::

How we get there

```cpp
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const double HOURLY_RATE    = 18.75;
    const int    REGULAR_HOURS  = 40;
    const double OT_MULTIPLIER  = 1.5;

    int totalHours = 43;

    // Regular pay: min of actual hours and 40
    int regHours = (totalHours <= REGULAR_HOURS) ? totalHours : REGULAR_HOURS;
    double regularPay = regHours * HOURLY_RATE;

    // Overtime pay: any hours beyond 40
    int otHours = (totalHours > REGULAR_HOURS) ? (totalHours - REGULAR_HOURS) : 0;
    double otPay = otHours * HOURLY_RATE * OT_MULTIPLIER;

    double totalPay = regularPay + otPay;

    cout << fixed << setprecision(2);
    cout << "Regular pay:  $" << regularPay << endl;  // $750.00
    cout << "Overtime pay: $" << otPay      << endl;  // $84.38
    cout << "Total pay:    $" << totalPay   << endl;  // $834.38

    return 0;
}
```

**Key techniques used:** `const` for unchanging values, `fixed`/`setprecision` for formatted output, the ternary operator `?:` to choose between two values without a full `if` statement (we'll cover `if` fully in Ch 4).
:::

:::example[Example 2.10 — Married-Couple Names with Variables (§2.24)]
Two people get married. Alex Rivera (keeps last name) and Jordan Smith (takes partner's name). Print both full names after the marriage. Store names as string variables.

::::answer[Answer: Alex Rivera and Jordan Rivera]

::::

```cpp
#include <iostream>
#include <string>
using namespace std;

int main() {
    string firstName1 = "Alex";
    string lastName1  = "Rivera";

    string firstName2 = "Jordan";
    // Jordan takes Alex's last name:
    string lastName2  = lastName1;    // copy the string "Rivera"

    string fullName1 = firstName1 + " " + lastName1;
    string fullName2 = firstName2 + " " + lastName2;

    cout << "After marriage:" << endl;
    cout << fullName1 << endl;   // Alex Rivera
    cout << fullName2 << endl;   // Jordan Rivera

    return 0;
}
```

Notice: `lastName2 = lastName1` makes a *copy* of the string. If you later changed `lastName1`, `lastName2` would remain "Rivera" — strings are value-copied, not shared.
:::

:::summary
## Chapter 2 Summary

| Concept | Key Syntax / Rule |
| --- | --- |
| Variable declaration | `int x = 0;` — type, name, optional initializer |
| Identifier rules | Letters/digits/underscore; start with letter or \_; no keywords |
| Integer arithmetic | `+ - * / %` — **division truncates**, modulo gives remainder |
| Floating-point | `double` preferred; 15 sig. digits; never compare with `==` |
| Constants | `const double PI = 3.14159;` — ALL\_CAPS convention |
| Math functions | `#include <cmath>` → `sqrt`, `pow`, `abs`, `ceil`, `floor` |
| Type conversion | `static_cast<double>(a)` — cast before dividing for float result |
| Binary literals | `0b1011` = 11; hex `0xFF` = 255 |
| Unsigned | `unsigned int` — non-negative, wraps on overflow |
| char | Single quotes: `'A'`; arithmetic: `'a' - 'A'` = 32 |
| string | `#include <string>`; `+` to concatenate; `.length()`; `[i]` to index |
| Random numbers | `srand(time(0));` then `low + rand() % (high-low+1)` |
| auto | `auto x = 3.14;` — compiler deduces type from initializer |
:::

## Mixed Practice

:::problem[M.1easy]{difficulty="easy"}
Declare and initialize variables to store: your name as a string, your age as an int, and your GPA as a double. Print all three with labels.

::::solution[Solution]
```cpp
string name  = "Alice";
int    age   = 20;
double gpa   = 3.85;
cout << "Name: " << name << "\nAge: " << age << "\nGPA: " << gpa << endl;
```
::::
:::

:::problem[M.2easy]{difficulty="easy"}
What is the value of `x` after this code?

`int x = 100; x /= 3; x += 5; x %= 12;`

::::solution[Solution]
Step by step: `x = 100` → `x /= 3`: 100/3 = 33 (int division) → `x += 5`: 33+5 = 38 → `x %= 12`: 38%12 = 2. Answer: **2**.
::::
:::

:::problem[M.3standard]{difficulty="standard"}
Write a program to convert a temperature from Celsius to Fahrenheit. Formula: $F = \frac{9}{5} \times C + 32$. Test with C = 100. Expected output: 212.

::::solution[Solution]
```cpp
double celsius = 100.0;
double fahrenheit = (9.0 / 5.0) * celsius + 32.0;
cout << fahrenheit;   // 212
```

Critical: use `9.0/5.0`, not `9/5`. Integer division `9/5 = 1`, which would give the wrong formula entirely.
::::
:::

:::problem[M.4standard]{difficulty="standard"}
A parking garage charges $3 for the first hour and $1.50 for each additional hour (partial hours count as full). Write variables and expressions for a 2.5-hour stay. (Hint: use `ceil()`.)

::::solution[Solution]
```cpp
#include <cmath>
double hoursParked = 2.5;
double rate = 1.50;
int    billableHours = static_cast<int>(ceil(hoursParked));  // 3

double cost = 3.00;   // first hour flat
if (billableHours > 1) cost += (billableHours - 1) * rate;   // 2 more hours
cout << "$" << fixed << setprecision(2) << cost;  // $6.00
```
::::
:::

:::problem[M.5standard]{difficulty="standard"}
Given `string s = "Computer";`, write expressions for: (a) the number of characters, (b) the last character, (c) whether the string is empty.

::::solution[Solution]
```cpp
string s = "Computer";
cout << s.length();               // 8
cout << s[s.length() - 1];        // 'r'
cout << s.empty();                 // 0 (false)
```
::::
:::

:::problem[M.6challenge]{difficulty="challenge"}
A 32-bit signed `int` can hold values from $-2^{31}$ to $2^{31}-1$. Compute $2^{31}-1$ using only the `int` value 1, left-shift (`<<`), and subtraction — and explain what each step does. (You'll need `long long` for the intermediate result.)

::::solution[Solution]
```cpp
long long maxInt = (1LL << 31) - 1;   // 2147483647
cout << maxInt;
```

`1LL << 31`: left-shift 1 by 31 positions in binary = 2³¹. `- 1` gives 2³¹ - 1 = 2147483647. We use `long long` (64-bit) because 2³¹ itself doesn't fit in a 32-bit signed int!
::::
:::

:::problem[M.7challenge]{difficulty="challenge"}
Write a program that generates 5 random integers in the range [1, 100] and prints their sum and average (as a double, to 1 decimal place). Seed with `srand(42)` so your output is reproducible.

::::solution[Solution]
```cpp
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
int main() {
    srand(42);
    int sum = 0;
    for (int i = 0; i < 5; i++) {
        int r = 1 + rand() % 100;
        cout << r << " ";
        sum += r;
    }
    cout << "\nSum: " << sum;
    cout << "\nAvg: " << fixed << setprecision(1)
         << static_cast<double>(sum) / 5 << endl;
    return 0;
}
```

Note: `for` loops are covered in Chapter 5 — this is a preview. The key variable concepts here are: sum accumulation with `+=`, and the cast-before-divide pattern for the average.
::::
:::

## LeetCode Practice

:::callout-tip[LeetCode Problems for Chapter 2]
These problems directly exercise the integer arithmetic, modulo, and variable concepts from this chapter. Solve them in C++. For each problem, think about the variable types you'll need and whether integer or floating-point math applies.

| # | Problem | Difficulty | Why it fits |
| --- | --- | --- | --- |
| [#412](https://leetcode.com/problems/fizz-buzz/) | Fizz Buzz | Easy | Directly uses modulo (`%` from §2.11) to check divisibility — the most important operator in this chapter. |
| [#7](https://leetcode.com/problems/reverse-integer/) | Reverse Integer | Medium | Uses `% 10` to extract digits and `/ 10` to shift — exercises everything in §2.5 and §2.11. Also tests overflow awareness (§2.16). |
| [#9](https://leetcode.com/problems/palindrome-number/) | Palindrome Number | Easy | Integer variable manipulation — check if reversing an integer's digits gives the same number. Great practice for the digit-extraction pattern. |
| [#13](https://leetcode.com/problems/roman-to-integer/) | Roman to Integer | Easy | Combines variable assignment, arithmetic, and character comparison — ties together §2.2, §2.4, and §2.14. |

**Tip for #7 (Reverse Integer):** The digit-extraction loop uses the exact same pattern as Example 2.7 — `digit = n % 10`, then `n /= 10`. Try coding that loop before looking at hints.
:::
