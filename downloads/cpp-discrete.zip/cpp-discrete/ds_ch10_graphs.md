---
title: "DS–10: Graphs"
source: "ds_ch10_graphs.html"
---

CSE 2813

# DS–10: Graphs

§10.1 – §10.9

## §10.1 Graph Definitions and Degree

:::definition[Definition]
Graph

A **graph** $G=(V,E)$ consists of a set of **vertices** $V$ and a set of **edges** $E\subseteq V\times V$. An **undirected** graph has unordered pairs $\{u,v\}$; a **directed** graph (digraph) has ordered pairs $(u,v)$. A **weighted** graph assigns a real number to each edge.
:::

| Term | Definition |
| --- | --- |
| Adjacent | $u,v$ are adjacent if $\{u,v\}\in E$ |
| Degree $\deg(v)$ | Number of edges incident to $v$ |
| In/Out-degree | For digraphs: edges entering / leaving $v$ |
| Path | Sequence of vertices $v_0,v_1,\ldots,v_k$ where each consecutive pair is adjacent |
| Cycle | A path $v_0,\ldots,v_k=v_0$ starting and ending at the same vertex |
| Connected | Every pair of vertices has a path between them |
| DAG | Directed Acyclic Graph — directed, no directed cycles |

:::theorem[Theorem]
Handshaking Lemma

For any undirected graph: $\sum_{v\in V}\deg(v) = 2|E|$.

Corollary: the number of vertices with odd degree is always even.
:::

Example 10.1 — Handshaking

A social network has 10 users. Each user has at least 3 friends. What is the minimum number of friendships (edges)?

:::answer[Solution]
$\sum\deg(v)\ge10\times3=30$. By handshaking, $|E|\ge30/2=\mathbf{15}$ edges minimum.
:::

## §10.2 Graph Representations

### Adjacency Matrix

$n\times n$ matrix where $A[i][j]=1$ iff $(i,j)\in E$. Space: $O(n^2)$. Edge lookup: $O(1)$. Good for dense graphs.

### Adjacency List

Array of lists: `adj[v]` contains all neighbors of $v$. Space: $O(V+E)$. Good for sparse graphs (most real-world graphs).

```cpp
// Adjacency list representation
int n = 5;
vector<vector<int>> adj(n);
adj[0].push_back(1);
adj[0].push_back(2);
adj[1].push_back(3);
// For weighted graphs:
vector<vector<pair<int,int>>> wadj(n); // {neighbor, weight}
wadj[0].push_back({1, 5});
```

| Operation | Adj. Matrix | Adj. List |
| --- | --- | --- |
| Space | $O(V^2)$ | $O(V+E)$ |
| Edge $(u,v)$ exists? | $O(1)$ | $O(\deg(u))$ |
| All neighbors of $v$ | $O(V)$ | $O(\deg(v))$ |
| Add edge | $O(1)$ | $O(1)$ |
| Preferred when | Dense, frequent edge lookup | Sparse, BFS/DFS traversal |

## §10.3 Breadth-First Search (BFS)

BFS explores vertices in order of increasing distance from the source. Uses a queue. Time: $O(V+E)$.

```cpp
// BFS — O(V+E)
vector<int> bfs(int src, vector<vector<int>>& adj, int n) {
    vector<int> dist(n, -1);
    queue<int> q;
    dist[src] = 0;
    q.push(src);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : adj[u]) {
            if (dist[v] == -1) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
    return dist; // dist[v] = shortest path from src to v
}
```

Example 10.2 — BFS Trace

BFS from vertex 0 on graph: $0\to\{1,2\}$, $1\to\{3\}$, $2\to\{3,4\}$, $3\to\{5\}$, $4\to\{5\}$.

:::answer[Level-order distances]
| Step | Queue | Distances found |
| --- | --- | --- |
| 1 | [0] | dist[0]=0 |
| 2 | [1,2] | dist[1]=1, dist[2]=1 |
| 3 | [3,3,4] | dist[3]=2, dist[4]=2 |
| 4 | [5,5] | dist[5]=3 |

BFS guarantees shortest paths in unweighted graphs.
:::

## §10.4 Depth-First Search (DFS)

DFS explores as far as possible before backtracking. Uses a stack (or recursion). Time: $O(V+E)$.

```cpp
// DFS (iterative) — O(V+E)
void dfs(int src, vector<vector<int>>& adj, vector<bool>& visited) {
    stack<int> st;
    st.push(src);
    while (!st.empty()) {
        int u = st.top(); st.pop();
        if (visited[u]) continue;
        visited[u] = true;
        for (int v : adj[u])
            if (!visited[v]) st.push(v);
    }
}

// DFS (recursive) — cleaner, O(V+E)
void dfsRec(int u, vector<vector<int>>& adj, vector<bool>& vis) {
    vis[u] = true;
    for (int v : adj[u])
        if (!vis[v]) dfsRec(v, adj, vis);
}
```

### DFS Applications

- **Cycle detection:** back-edge exists iff graph has a cycle
- **Topological sort:** output vertices in decreasing finish time (post-order)
- **Connected components:** call DFS for each unvisited vertex
- **Articulation points / bridges:** vertices/edges whose removal disconnects the graph

:::callout-intuition[BFS vs DFS]
BFS: shortest path in unweighted graphs, level-by-level exploration, uses a queue.

DFS: reachability, cycle detection, topological sort, uses a stack/recursion.

Both run in $O(V+E)$ with an adjacency list.
:::

## §10.5 Dijkstra's Algorithm

Finds shortest paths from a source to all vertices in a weighted graph with non-negative edge weights. Time: $O((V+E)\log V)$ with a min-heap.

```cpp
// Dijkstra's Algorithm — O((V+E) log V)
vector<long long> dijkstra(int src, int n,
    vector<vector<pair<int,int>>>& adj) {
    const long long INF = 1e18;
    vector<long long> dist(n, INF);
    priority_queue<pair<long long,int>,
        vector<pair<long long,int>>, greater<>> pq;
    dist[src] = 0;
    pq.push({0, src});
    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (d > dist[u]) continue; // stale entry
        for (auto [v, w] : adj[u]) {
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}
```

Example 10.3 — Dijkstra Trace

Find shortest paths from A. Edges: A→B(4), A→C(2), C→B(1), B→D(5), C→D(8).

:::answer[Step-by-step]
| Extract | dist[A] | dist[B] | dist[C] | dist[D] |
| --- | --- | --- | --- | --- |
| A(0) | 0 | 4 | 2 | ∞ |
| C(2) | 0 | 3✓ | 2 | 10 |
| B(3) | 0 | 3 | 2 | 8✓ |
| D(8) | 0 | 3 | 2 | 8 |

Shortest paths: A→A=0, A→C→B=3, A→C=2, A→C→B→D=8.
:::

:::callout-pitfall[Common Pitfall]
Dijkstra's algorithm FAILS on graphs with negative edge weights. Use Bellman-Ford ($O(VE)$) instead, which handles negative edges and detects negative cycles.
:::

## §10.6 Minimum Spanning Trees

:::definition[Definition]
Spanning Tree

A **spanning tree** of a connected graph $G$ is a tree subgraph that includes all vertices. An **MST** is one with minimum total edge weight.
:::

### Kruskal's Algorithm

Sort edges by weight. Add each edge if it doesn't create a cycle (use Union-Find). $O(E\log E)$.

### Prim's Algorithm

Start from any vertex, greedily add the minimum-weight edge connecting the tree to a new vertex. $O((V+E)\log V)$ with a min-heap.

```cpp
// Kruskal's MST — O(E log E)
struct Edge { int u, v, w; };
long long kruskal(int n, vector<Edge>& edges) {
    sort(edges.begin(), edges.end(), [](auto& a, auto& b){ return a.w < b.w; });
    UnionFind uf(n);
    long long total = 0;
    for (auto& [u, v, w] : edges)
        if (uf.unite(u, v)) total += w;
    return total;
}
```

## §10.7 Euler Paths and Circuits

:::definition[Definition]
Euler Path / Circuit

An **Euler path** traverses every edge exactly once. An **Euler circuit** is an Euler path that starts and ends at the same vertex.
:::

:::theorem[Theorem]
Euler's Criteria

For a connected undirected graph:

- **Euler circuit exists** iff every vertex has even degree.
- **Euler path exists** iff exactly 0 or 2 vertices have odd degree (the odd-degree vertices are the endpoints).
:::

Example 10.4 — Königsberg Bridges

The city of Königsberg had 7 bridges connecting 4 landmasses. Is there a walk crossing each bridge exactly once?

:::answer[Solution]
Model landmasses as vertices, bridges as edges. Degrees: land A=5, B=3, C=3, D=3. All four vertices have odd degree — but an Euler path requires exactly 0 or 2 odd-degree vertices. So

no

, such a walk is impossible. This was Euler's 1736 proof — the birth of graph theory.
:::

## §10.8 Hamilton Paths and Cycles

:::definition[Definition]
Hamilton Path / Cycle

A **Hamilton path** visits every vertex exactly once. A **Hamilton cycle** visits every vertex exactly once and returns to the start. Unlike Euler paths, there is no simple necessary-and-sufficient condition — finding a Hamilton cycle is NP-complete.
:::

:::theorem[Theorem]
Sufficient Conditions

**Dirac's theorem:** If $|V|\ge3$ and every vertex has degree $\ge|V|/2$, a Hamilton cycle exists.

 **Ore's theorem:** If $|V|\ge3$ and $\deg(u)+\deg(v)\ge|V|$ for every non-adjacent pair, a Hamilton cycle exists.
:::

:::callout-connect[Connection → NP-Completeness]
The Traveling Salesman Problem (TSP) asks for the minimum-weight Hamilton cycle — it's NP-hard. This is why Dijkstra doesn't help: it finds shortest paths, not shortest tours visiting all vertices.
:::

## §10.9 Graph Coloring and Planarity

:::definition[Definition]
Graph Coloring

A **proper coloring** assigns colors to vertices such that no two adjacent vertices share a color. The **chromatic number** $\chi(G)$ is the minimum number of colors needed.
:::

:::theorem[Theorem]
Four Color Theorem

Every planar graph can be properly colored with at most 4 colors. (Proved in 1976 — the first major theorem proven with computer assistance.)
:::

:::definition[Definition]
Planar Graph

A graph is **planar** if it can be drawn in the plane with no edge crossings. Euler's formula: $V - E + F = 2$ (for connected planar graphs), where $F$ = number of faces (including the outer infinite face).
:::

:::theorem[Theorem]
Kuratowski's Theorem

A graph is planar iff it contains no subdivision of $K_5$ (complete graph on 5 vertices) or $K_{3,3}$ (complete bipartite graph).
:::

:::callout-connect[Connection → Register Allocation]
Compilers use graph coloring to allocate CPU registers: variables are vertices, an edge means two variables are alive at the same time (can't share a register). Minimum colors = minimum registers needed.
:::

:::summary
### Chapter 10 Summary

- **Graph $G=(V,E)$**: vertices and edges; directed/undirected/weighted. Handshaking: $\sum\deg=2|E|$.
- **Representations:** adjacency matrix ($O(V^2)$ space) vs. adjacency list ($O(V+E)$).
- **BFS:** $O(V+E)$, shortest paths in unweighted graphs, uses a queue.
- **DFS:** $O(V+E)$, cycle detection, topological sort, components, uses stack/recursion.
- **Dijkstra:** $O((V+E)\log V)$, shortest paths in non-negative weighted graphs.
- **MST:** Kruskal ($O(E\log E)$, greedy by edge weight + Union-Find), Prim ($O((V+E)\log V)$).
- **Euler path/circuit:** 0 or 2 odd-degree vertices (path); all even degree (circuit).
- **Hamilton cycle:** NP-complete; Dirac's/Ore's conditions are sufficient but not necessary.
- **Coloring / planarity:** $\chi(G)\le4$ for planar graphs; Euler's formula $V-E+F=2$.
:::

## Practice Problems

:::problem[Problem 1]{difficulty="easy"}
Problem 1

For the graph: vertices $\{A,B,C,D,E\}$, edges $AB,AC,BC,CD,DE$. What are the degrees? Does an Euler path exist? An Euler circuit?

::::solution[Solution]
$\deg(A)=2, \deg(B)=2, \deg(C)=3, \deg(D)=2, \deg(E)=1$. Odd-degree vertices: $C$ (deg 3) and $E$ (deg 1) — exactly 2. So an

Euler path exists

(from $C$ to $E$ or vice versa), but no Euler circuit (which needs all even).
::::
:::

:::problem[Problem 2]{difficulty="easy"}
Problem 2

Use BFS to find shortest paths from vertex 1 in the graph: $1\to\{2,3\}$, $2\to\{4\}$, $3\to\{4,5\}$, $4\to\{6\}$, $5\to\{6\}$.

::::solution[Solution]
dist[1]=0, dist[2]=1, dist[3]=1, dist[4]=2, dist[5]=2, dist[6]=3.
::::
:::

:::problem[Problem 3]{difficulty="standard"}
Problem 3

Run Dijkstra's from vertex $s$ on: $s\to A(3)$, $s\to B(1)$, $B\to A(1)$, $A\to C(5)$, $B\to C(8)$. Show the priority queue at each step.

::::solution[Solution]
Initial: dist[s]=0; PQ={(0,s)}.

Pop (0,s): relax A→3, B→1. PQ={(1,B),(3,A)}.

Pop (1,B): relax A→min(3,2)=2, C→9. PQ={(2,A),(3,A),{9,C}}.

Pop (2,A): relax C→min(9,7)=7. PQ={(3,A),(7,C),(9,C)}.

Pop (3,A) stale. Pop (7,C): done.

Distances: s=0, B=1, A=2, C=7.
::::
:::

:::problem[Problem 4]{difficulty="standard"}
Problem 4

Find the MST of the graph with edges: AB=4, AC=2, BC=5, BD=8, CD=3, DE=7, CE=6. Use Kruskal's algorithm.

::::solution[Solution]
Sort: AC=2, CD=3, AB=4, BC=5, CE=6, DE=7, BD=8.

Add AC (2) ✓. Add CD (3) ✓. Add AB (4) ✓. Skip BC (5) — creates cycle A-C-B-A. Add CE (6) ✓. Skip DE (7) — creates cycle. MST edges: AC,CD,AB,CE. Total = 2+3+4+6 =

15

.
::::
:::

:::problem[Problem 5]{difficulty="standard"}
Problem 5

Is $K_4$ (complete graph on 4 vertices) planar? Verify using Euler's formula.

::::solution[Solution]
$K_4$: $V=4$, $E=6$. If planar: $V-E+F=2\Rightarrow F=2-4+6=4$ faces. Each face borders $\ge3$ edges, and each edge borders $\le2$ faces: $2E\ge3F\Rightarrow12\ge12$ ✓. So $K_4$ is planar (it can be drawn without crossings — draw a triangle with one vertex inside).
::::
:::

:::problem[Problem 6]{difficulty="challenge"}
Problem 6

Prove the Handshaking Lemma: for any undirected graph, $\sum_{v} \deg(v) = 2|E|$.

::::solution[Solution]
Each edge $\{u,v\}\in E$ contributes exactly 1 to $\deg(u)$ and 1 to $\deg(v)$, for a total contribution of 2 to the sum $\sum\deg(v)$. Summing over all edges: $\sum_{v}\deg(v) = \sum_{e\in E}2 = 2|E|$. $\square$
::::
:::

## LeetCode Practice

| # | Title | Difficulty | Concept |
| --- | --- | --- | --- |
| 200 | [Number of Islands](https://leetcode.com/problems/number-of-islands/) | Medium | BFS/DFS on grid graphs |
| 743 | [Network Delay Time](https://leetcode.com/problems/network-delay-time/) | Medium | Dijkstra's algorithm |
| 684 | [Redundant Connection](https://leetcode.com/problems/redundant-connection/) | Medium | Kruskal's / Union-Find (cycle detection) |
| 785 | [Is Graph Bipartite?](https://leetcode.com/problems/is-graph-bipartite/) | Medium | BFS 2-coloring |
| 127 | [Word Ladder](https://leetcode.com/problems/word-ladder/) | Hard | BFS shortest path on implicit graph |
