---
title: "Chapter 17: Linked Lists"
crumb: "C++ · Chapter 17"
meta:
  - "Est. study time: ~3 hours"
  - "CSE 1384 · Mississippi State University"
source: "markdown"
---

# Chapter 17: Linked Lists

## Overview

An array stores its elements in one contiguous block, which is what makes `a[500]` instant: the
address is arithmetic. It is also what makes inserting at the front expensive — every element has
to shuffle up to make room — and what makes growing expensive, since a bigger block must be
allocated and the whole thing copied.

A **linked list** gives up the contiguity. Each element sits wherever the allocator put it and
carries a pointer to the next one. Nothing is adjacent, so nothing has to move: inserting at the
front is three assignments regardless of how long the list is.

The price is everything the contiguity was buying. There is no `a[500]` — reaching the five
hundredth element means following five hundred pointers. Every element costs an extra pointer of
memory, plus an allocation. And because the nodes are scattered, traversal misses the cache
constantly, so a linked list is slower than an array even at the operations where its Big-O looks
better.

That trade is the real subject of this chapter, and it is worth stating plainly at the start:
**linked lists are the right structure less often than a first course suggests.** What they are
always worth is the pointer practice. Every operation here is three or four lines, every one of
those lines must happen in the right order, and getting them wrong produces leaks, cycles and
crashes rather than merely wrong answers. That is why the chapter is long.

:::callout-key[What you'll learn]
- Singly-linked lists: prepend, append, insert, search, remove
- Why removal needs the *previous* node, and what that costs
- Doubly-linked lists, and what the second pointer buys and costs
- Circular lists, and traversal that has no natural stopping point
- Merge sort on a list, and the slow/fast pointer trick for finding the middle
- Dummy nodes, which delete the special cases rather than handling them
- Recursive formulations, and where the stack runs out
:::

:::callout-tip[Prerequisites]
Pointers, `new` and `delete` from Chapter 8 — this chapter is almost entirely pointer
manipulation. Classes, constructors and destructors from Chapter 13. Big-O from Chapter 10, since
every operation here is justified by its complexity.
:::

## §17.1 — List Abstract Data Type

A **list** is an ordered collection with insertion, removal and search. That is the interface, and
it says nothing about how the elements are stored — which is exactly the point of calling it an
abstract data type. An array and a linked list implement the same ADT and make opposite trades:

| Operation | Array / `vector` | Linked list |
| --- | --- | --- |
| Access by index | $O(1)$ | $O(n)$ |
| Insert at front | $O(n)$ | $O(1)$ |
| Insert at back | $O(1)$ amortized | $O(1)$ with a tail pointer |
| Insert after a known node | $O(n)$ | $O(1)$ |
| Search by value | $O(n)$ | $O(n)$ |
| Memory per element | just the element | element plus one or two pointers |
| Cache behaviour | excellent | poor |

**Read the "insert after a known node" row carefully**, because it is the one that gets misquoted.
Linked-list insertion is $O(1)$ *once you are holding the node to insert after*. Finding that node
is $O(n)$, so inserting at a given **index** is $O(n)$ either way — the list wins only when you
already have a pointer, which happens when you are iterating.

**The last two rows are why arrays usually win in practice.** Big-O counts operations and treats
every memory access as equal; real hardware charges a few cycles for a cache hit and a few hundred
for a miss. An array walks through consecutive addresses that the prefetcher can predict; a linked
list chases pointers into scattered memory and stalls on nearly every one.

## §17.2 — Singly-Linked Lists: Structure

Each **node** stores a value and a pointer to the next node. The list is reached through a `head`
pointer, and the last node's `next` is `nullptr`.

```
head
 │
 ▼
┌──────┬──────┐     ┌──────┬──────┐     ┌──────┬──────┐
│  10  │  ───────►  │  20  │  ───────►  │  30  │ null │
└──────┴──────┘     └──────┴──────┘     └──────┴──────┘
  val   next          val   next           val   next
```

```cpp
#include <iostream>
using namespace std;

struct Node {
    int   data;
    Node* next;
    Node(int d) : data(d), next(nullptr) {}
};

class SinglyLinkedList {
private:
    Node* head;
    int   sz;

public:
    SinglyLinkedList() : head(nullptr), sz(0) {}

    ~SinglyLinkedList() {
        Node* cur = head;
        while (cur) {
            Node* next = cur->next;
            delete cur;
            cur = next;
        }
    }

    // declared here, defined in the sections that follow
    void prepend(int val);
    void append(int val);
    bool insertAfter(int target, int val);
    Node* search(int val) const;
    bool remove(int val);
    int  removeAll(int val);

    int  size()    const { return sz; }
    bool isEmpty() const { return head == nullptr; }

    void print() const {
        Node* cur = head;
        while (cur) {
            cout << cur->data;
            if (cur->next) cout << " → ";
            cur = cur->next;
        }
        cout << " → null\n";
    }
};
```

**`Node` holds a `Node*`, not a `Node`, and that is a requirement rather than a preference.**
Inside its own definition a class is an *incomplete type* — the compiler has not finished working
out how big it is. A pointer member is legal anyway, because every pointer is the same size
whatever it points at, and that size is known before the pointed-to type is. A value member is
not: `Node next;` would make the size of a `Node` equal to its own size plus an `int`, which has
no solution, and the compiler rejects it as a field of incomplete type. Recursion in a data
structure has to be expressed through indirection — which is why the diagram above draws arrows
between separate boxes instead of boxes nested inside boxes.

**`Node` is a `struct` with public members, and `SinglyLinkedList` is a `class` with private
ones.** That is the §13.9 heuristic applied: a node is a plain data aggregate with no invariant to
protect, while the list has one — `sz` must always equal the number of nodes — and so needs
control over who can change it.

**The destructor is not optional and cannot be shortened.** It walks the chain deleting as it
goes, and the `Node* next = cur->next;` on the line *before* the `delete` is essential: after
`delete cur`, reading `cur->next` is reading freed memory. Save the pointer, then delete, then
advance. Getting those three in the wrong order is the commonest way to write a destructor that
appears to work and corrupts the heap.

**Without a destructor the whole list leaks**, every node of it. Unlike a `vector` member, a raw
`Node*` frees nothing on its own.

The methods are declared in the class and defined below with the `SinglyLinkedList::` qualifier,
exactly as §13.8 sets out. That is also why they can see `head` and `sz`: they are member
functions, just written outside the braces.

## §17.3 — Singly-Linked Lists: Search & Insert

### Prepend (insert at head)

```
Before:  head → [20] → [30] → null

                     newNode = new Node(10)

After:   head → [10] → [20] → [30] → null
                 ↑
         newNode->next = old head;  head = newNode
```

```cpp
void SinglyLinkedList::prepend(int val) {
    Node* newNode = new Node(val);
    newNode->next = head;    // point new node to old head
    head = newNode;           // move head to new node
    sz++;
}
```

**The order of those two assignments is the entire operation, and reversing them destroys the
list.** Do `head = newNode` first and `head` no longer names the old first node — so
`newNode->next = head` makes the node point at *itself*, producing a one-element cycle with the
rest of the list unreachable and leaked. Both lines still execute, nothing crashes, and the list
now reports the wrong contents forever.

The rule that generalises to every insertion in this chapter: **attach the new node to the list
before detaching the list from what pointed at it.**

**This is $O(1)$ no matter how long the list is** — one allocation and two pointer writes. It is
the operation linked lists exist for.

### Append (insert at tail)

```cpp
void SinglyLinkedList::append(int val) {
    Node* newNode = new Node(val);
    if (!head) {               // empty list
        head = newNode;
    } else {
        Node* cur = head;
        while (cur->next)      // walk to last node
            cur = cur->next;
        cur->next = newNode;   // link last node to new node
    }
    sz++;
}
```

**The empty-list case has to be separate**, and it is the shape of special case that recurs
throughout the chapter. When the list is empty there is no last node to attach to, and the thing
that must change is `head` itself. Without the `if`, the `while` loop would dereference a null
`cur` immediately.

**The loop condition is `cur->next`, not `cur`.** Looping while `cur` is non-null would walk one
step too far and leave `cur` null; we want to *stop on* the last node, which is the one whose
`next` is null.

**This is $O(n)$**, because finding the tail means walking the whole list. That is the asymmetry
with `prepend`, and it is why §17.5's doubly-linked list keeps a `tail` pointer — with one, append
becomes $O(1)$ too.

### Insert after a given value

```cpp
// Insert 'val' after the first node with data == 'target'
// Returns true if target was found, false otherwise
bool SinglyLinkedList::insertAfter(int target, int val) {
    Node* cur = head;
    while (cur) {
        if (cur->data == target) {
            Node* newNode = new Node(val);
            newNode->next = cur->next;  // new → rest
            cur->next = newNode;         // prev → new
            sz++;
            return true;
        }
        cur = cur->next;
    }
    return false;   // target not found
}
```

Again the two-line pattern, and again the order matters: `newNode->next = cur->next` must come
first, because the second line overwrites `cur->next` and the tail of the list would be lost.

**The function returns `bool` rather than silently doing nothing**, which is the right choice: "the
target was not in the list" is information the caller needs, and a `void` version would leave them
believing the insertion happened.

### Search

```cpp
// Returns pointer to first node with matching data, or nullptr
Node* SinglyLinkedList::search(int val) const {
    Node* cur = head;
    while (cur) {
        if (cur->data == val) return cur;
        cur = cur->next;
    }
    return nullptr;
}
```

**`nullptr` is the "not found" answer**, which works because no valid node ever lives at address
zero. That is the pattern §19.21 calls "the pointer is the optional".

**The function is `const` but returns a non-const `Node*`**, which is a genuine hole in the
interface: a caller can modify the list through the returned pointer while holding a `const`
reference to it. Tightening it means returning `const Node*` from a `const` search and providing a
non-const overload, exactly as §13.15 does for `operator[]`.

:::callout-intuition[Every singly-linked insertion is the same two steps]
1. Point the **new node** at the rest of the list.
2. Point the **predecessor** at the new node.

In that order, always. Doing step 2 first overwrites the only pointer to the rest of the list, and
everything after the insertion point becomes unreachable — leaked, and gone from the list.

The reason this is worth memorising as a shape rather than as three separate functions is that
`prepend`, `insertAfter`, and the doubly-linked versions in §17.6 are all the same two steps with
different names for the predecessor.
:::

## §17.4 — Singly-Linked Lists: Remove

Removal needs the node *before* the target, so that its `next` can be redirected past it.

```
Remove 20 from: head → [10] → [20] → [30] → null

Step 1: prev = [10], cur = [20]
Step 2: prev->next = cur->next  →  [10].next = [30]
Step 3: delete cur

Result: head → [10] → [30] → null
```

```cpp
// Remove first node with data == val
// Returns true if found and removed, false otherwise
bool SinglyLinkedList::remove(int val) {
    if (!head) return false;

    // Special case: remove head
    if (head->data == val) {
        Node* toDelete = head;
        head = head->next;
        delete toDelete;
        sz--;
        return true;
    }

    // General case: find predecessor
    Node* prev = head;
    Node* cur  = head->next;
    while (cur) {
        if (cur->data == val) {
            prev->next = cur->next;   // bypass cur
            delete cur;
            sz--;
            return true;
        }
        prev = cur;
        cur  = cur->next;
    }
    return false;   // not found
}
```

**Why the head is a special case at all.** The general branch redirects `prev->next`. The head has
no predecessor — the thing pointing at it is the `head` member itself, not a node — so there is no
`prev` to redirect and the code has to assign to `head` directly. Attempting the general path on
the head would dereference a null `prev` and crash.

**The two pointers move in lockstep**, `prev` one node behind `cur`. That trailing pointer is the
whole reason removal is more awkward than insertion in a singly-linked list: you cannot go
backwards, so you must remember where you were. A doubly-linked list has a `prev` pointer in every
node and needs no such bookkeeping — §17.7.

**The `delete` comes after the relink**, and the copy `toDelete` exists so the head branch can
advance `head` before freeing. Delete first and `cur->next` reads freed memory.

:::callout-pitfall[The two classic removal bugs]
1. **Forgetting to `delete`.** Unlinking a node removes it from the list and leaks it. The list
   behaves perfectly and the program's memory grows forever, which is why this survives testing.
2. **Not handling the head separately.** Any code that assumes a predecessor exists crashes on the
   first element — the case most likely to appear in a test and least likely to be thought about.

Both disappear with the sentinel of §17.11, which gives the real head a predecessor and removes
the special case entirely.
:::

:::problem[Practice 17.4 standard]{difficulty="standard"}
**Remove all occurrences.** Extend the list with `removeAll(int val)`, removing every matching
node rather than the first, and returning how many were removed.

::::solution[Solution]
```cpp
int SinglyLinkedList::removeAll(int val) {
    int count = 0;
    // Remove leading matches
    while (head && head->data == val) {
        Node* tmp = head; head = head->next; delete tmp; count++; sz--;
    }
    if (!head) return count;
    // Remove interior matches
    Node* prev = head, *cur = head->next;
    while (cur) {
        if (cur->data == val) {
            prev->next = cur->next; delete cur; cur = prev->next; count++; sz--;
        } else { prev = cur; cur = cur->next; }
    }
    return count;
}
```

**The leading matches need a `while`, not an `if`.** On the list `[7,7,7,1]` removing 7, a single
`if` would strip one node and leave two at the front for the general loop, which never examines the
head. The loop keeps going while the head still matches.

**`cur = prev->next` after a deletion, not `cur = cur->next`.** This is the subtle one: `cur` has
just been deleted, so `cur->next` reads freed memory. Since `prev->next` was already redirected to
the following node, it holds the correct value and is safe to read.

**`prev` deliberately does not advance in the deletion branch.** It must stay put, because the next
node might also match and would then need the same predecessor. Advancing `prev` on every
iteration is the bug that makes `removeAll` skip every second match in a run of them.

Check on `[7,7,1,7,7]`: the leading loop removes two, leaving `[1,7,7]`; the interior loop then
removes both remaining sevens because `prev` stays on the 1. Returns 4.
::::
:::

## §17.5 — Doubly-Linked Lists: Structure

Each node carries a `prev` as well as a `next`, so the list can be walked in both directions. A
`tail` pointer is kept as well, making append and reverse traversal $O(1)$.

```
head                                                          tail
 │                                                             │
 ▼                                                             ▼
┌──────┬──────┬──────┐   ┌──────┬──────┬──────┐   ┌──────┬──────┬──────┐
│ null │  10  │  ──────►  ◄───  │  20  │  ──────►  ◄───  │  30  │ null │
└──────┴──────┴──────┘   └──────┴──────┴──────┘   └──────┴──────┴──────┘
  prev   val   next        prev   val   next        prev   val   next
```

```cpp
struct DNode {
    int    data;
    DNode* prev;
    DNode* next;
    DNode(int d) : data(d), prev(nullptr), next(nullptr) {}
};

class DoublyLinkedList {
private:
    DNode* head;
    DNode* tail;
    int    sz;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr), sz(0) {}

    ~DoublyLinkedList() {
        DNode* cur = head;
        while (cur) { DNode* nxt = cur->next; delete cur; cur = nxt; }
    }

    void pushFront(int val);
    void pushBack(int val);
    bool remove(int val);

    int  size() const { return sz; }
    bool isEmpty() const { return head == nullptr; }

    void printForward() const {
        for (DNode* c = head; c; c = c->next) cout << c->data << " ";
        cout << "\n";
    }
    void printBackward() const {
        for (DNode* c = tail; c; c = c->prev) cout << c->data << " ";
        cout << "\n";
    }
};
```

**`printBackward` is what the extra pointer bought**, and it is impossible on a singly-linked list
without either reversing the list or recursing. Note it walks from `tail` using `prev`, a perfect
mirror of `printForward`.

**The cost is one pointer per node — often 8 bytes on top of a 4-byte `int`** — plus a second
pointer to maintain on every insertion and removal, which is more code and more chances to get it
wrong. The rule of thumb: add `prev` when you genuinely need backward traversal or $O(1)$ removal
given a node, and not otherwise.

## §17.6 — Doubly-Linked Lists: Search & Insert

```cpp
void DoublyLinkedList::pushFront(int val) {
    DNode* n = new DNode(val);
    n->next = head;
    if (head) head->prev = n;   // old head now points back
    else      tail = n;          // list was empty: n is also the tail
    head = n;
    sz++;
}

void DoublyLinkedList::pushBack(int val) {
    DNode* n = new DNode(val);
    n->prev = tail;
    if (tail) tail->next = n;
    else      head = n;          // list was empty: n is also the head
    tail = n;
    sz++;
}
```

**Four pointers change on every insertion, not two.** The new node's `prev` and `next`, plus the
neighbour on each side pointing back at it. Miss one and the list is consistent walking forwards
and broken walking backwards — a bug that only shows up in `printBackward`, possibly much later.

**Both functions have the same empty-list branch, and it is easy to get subtly wrong.** When the
list is empty, the new node is simultaneously the head *and* the tail, so the pointer that is *not*
being set by the main logic must be set in the `else`. Forgetting it leaves a list whose `tail` is
null while `head` is not, and the next `pushBack` writes through a null pointer.

**`pushBack` is $O(1)$ here**, against $O(n)$ for the singly-linked `append`, purely because of the
`tail` pointer. That, not the backward walk, is often the real reason to reach for a doubly-linked
list.

## §17.7 — Doubly-Linked Lists: Remove

```cpp
bool DoublyLinkedList::remove(int val) {
    DNode* cur = head;
    while (cur && cur->data != val) cur = cur->next;
    if (!cur) return false;                 // not found

    if (cur->prev) cur->prev->next = cur->next;
    else           head = cur->next;        // removing the head

    if (cur->next) cur->next->prev = cur->prev;
    else           tail = cur->prev;        // removing the tail

    delete cur;
    sz--;
    return true;
}
```

**No trailing `prev` pointer is needed**, because every node already knows its predecessor. That is
the structural advantage: given a pointer to a node, a doubly-linked list can unlink it in $O(1)$,
while a singly-linked list must first walk from the head to find what precedes it.

**The two `if`/`else` pairs handle the two ends**, and they are independent — removing the only
node in a one-element list takes the `else` on both, correctly setting `head` and `tail` to null.
Working through that case is the fastest way to convince yourself the code is right.

## §17.8 — Circular Linked Lists

In a **circular** list the last node points back to the first instead of to `nullptr`. There is no
end, which is useful for anything that cycles: round-robin scheduling, a turn order, a repeating
playlist.

```
      ┌──────────────────────────────────────┐
      │                                      │
      ▼                                      │
┌──────┬──────┐   ┌──────┬──────┐   ┌──────┬─┴────┐
│  10  │  ──────► │  20  │  ──────► │  30  │  ──  │
└──────┴──────┘   └──────┴──────┘   └──────┴──────┘
```

```cpp
// Traversal must not test for null — it must count, or stop where it started
void printCircular(Node* head) {
    if (!head) return;
    Node* cur = head;
    do {
        cout << cur->data << " ";
        cur = cur->next;
    } while (cur != head);       // stop when we come back round
    cout << "\n";
}
```

**`while (cur)` would never terminate**, because no node's `next` is ever null. The stopping
condition must be "we are back where we started", and it must be tested at the *bottom* — which is
why this is a `do-while`, one of the few places §19.1's construct is genuinely the right one. A
`while (cur != head)` tested at the top would exit immediately, printing nothing.

**Every algorithm in the chapter has to be re-examined for a circular list.** Searching for a value
that is absent loops forever unless it counts nodes or watches for the head. That is the cost of
removing the terminator.

## §17.9 — Linked List Traversal Patterns

```cpp
// Pattern 1: count nodes
int countNodes(Node* head) {
    int n = 0;
    for (Node* cur = head; cur; cur = cur->next) n++;
    return n;
}

// Pattern 2: find the last node
Node* lastNode(Node* head) {
    if (!head) return nullptr;
    Node* cur = head;
    while (cur->next) cur = cur->next;
    return cur;
}

// Pattern 3: two pointers at different speeds — find the middle in one pass
Node* middleNode(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }
    return slow;
}

// Pattern 4: reverse the links in place
Node* reverseList(Node* head) {
    Node* prev = nullptr;
    Node* cur  = head;
    while (cur) {
        Node* nxt = cur->next;   // save before overwriting
        cur->next = prev;         // flip the link
        prev = cur;               // advance both
        cur  = nxt;
    }
    return prev;                  // prev is the new head
}
```

**Pattern 3 is the trick worth memorising.** Two pointers start together; one moves one node per
step, the other two. When the fast pointer reaches the end the slow one is exactly halfway, and it
took a single pass with no counting and no second traversal. The same idea detects a cycle — if the
fast pointer ever meets the slow one, the list loops — which is Floyd's algorithm.

**Pattern 4 needs three pointers and cannot be done with two.** `cur->next = prev` destroys the
only link to the rest of the list, so `nxt` must be saved first. Trace it on `[1,2,3]` and watch
`prev` walk forward as the reversed prefix while `cur` consumes the unreversed remainder; at the
end `cur` is null and `prev` is the node that used to be last.

## §17.10 — Sorting Linked Lists

Merge sort is the algorithm of choice for linked lists. It needs no random access — which rules out
quicksort's usual partitioning and heapsort entirely — and it can relink nodes rather than moving
data, so the elements themselves never get copied.

### Merge two sorted lists

```cpp
// Merge two already-sorted lists, return head of merged result
Node* merge(Node* a, Node* b) {
    Node dummy(0);         // sentinel to avoid head special-case
    Node* tail = &dummy;

    while (a && b) {
        if (a->data <= b->data) {
            tail->next = a;  a = a->next;
        } else {
            tail->next = b;  b = b->next;
        }
        tail = tail->next;
    }
    tail->next = a ? a : b;   // append remaining
    return dummy.next;
}
```

**The dummy node is the reason this is short.** Without it, the first append would be a special case
— there is no `tail` to attach to yet, so `head` would have to be set instead — and that `if` would
sit inside the loop being tested on every iteration. A stack-allocated sentinel gives the first
real node a predecessor, and `dummy.next` is the answer at the end. This is §17.11's pattern.

**`<=` rather than `<` keeps the sort stable**: when two elements compare equal, the one from `a`
is taken first, preserving their original relative order. Changing it to `<` breaks stability and
nothing else, which is why the bug is invisible on distinct data.

**The final line handles both leftovers at once.** The loop ends when either list is exhausted, and
whichever remains is already sorted and already linked, so it can be attached wholesale — no loop
needed.

### Find the middle (split point)

```cpp
// Returns the node just before the middle (for even-length lists)
Node* findMid(Node* head) {
    Node* slow = head;
    Node* fast = head->next;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;   // slow is the end of the first half
}
```

**Note `fast` starts one node ahead**, unlike Pattern 3 above. That offset makes `slow` stop at the
*end of the first half* rather than the start of the second, which is what the split needs. On
`[3,1,4,1,5]` it returns the node holding 4, so the halves are `[3,1,4]` and `[1,5]`.

The offset also guarantees progress on a two-element list: without it, `slow` would not move, the
"first half" would be the whole list, and `mergeSort` would recurse on the same list forever.

### Full merge sort

```cpp
Node* mergeSort(Node* head) {
    if (!head || !head->next) return head;   // base case

    Node* mid   = findMid(head);
    Node* right = mid->next;
    mid->next   = nullptr;   // split the list

    Node* sortedLeft  = mergeSort(head);
    Node* sortedRight = mergeSort(right);

    return merge(sortedLeft, sortedRight);
}

// Usage:
// head = mergeSort(head);   // reassign head to new sorted head
```

**`mid->next = nullptr` is what actually performs the split.** Until that line the two halves are
one list; cutting the link makes them two independent lists, each properly null-terminated so the
recursive calls terminate.

**The base case covers empty *and* single-element lists.** A one-node list is already sorted, and
without that check `findMid` would dereference `head->next` on it.

**The comment about reassigning `head` matters.** `mergeSort` returns a *new* head — the node that
sorted to the front — and the old `head` variable now points into the middle of the list. Calling
`mergeSort(head);` and discarding the result leaves the list scrambled.

**Complexity is $O(n \log n)$ time and $O(\log n)$ space**, the space being the recursion depth.
That beats the $O(n)$ auxiliary array a merge sort on an array needs, which is one place the linked
list genuinely wins.

### Trace on `[3, 1, 4, 1, 5]`

| Call | Input | Left half | Right half | Result |
| --- | --- | --- | --- | --- |
| `mergeSort` | `[3,1,4,1,5]` | `[3,1,4]` | `[1,5]` | recurse on both |
| `mergeSort` | `[3,1,4]` | `[3,1]` | `[4]` | recurse on both |
| `mergeSort` | `[3,1]` | `[3]` | `[1]` | both are base cases |
| `merge` | `[3]` + `[1]` | — | — | `[1,3]` |
| `merge` | `[1,3]` + `[4]` | — | — | `[1,3,4]` |
| `mergeSort` | `[1,5]` | `[1]` | `[5]` | both are base cases |
| `merge` | `[1]` + `[5]` | — | — | `[1,5]` |
| `merge` | `[1,3,4]` + `[1,5]` | — | — | `[1,1,3,4,5]` |

The final merge is where stability shows: the two 1s are compared, `<=` takes the one from the left
half first, and they appear in their original relative order.

## §17.11 — Dummy Nodes (Sentinel Pattern)

A **dummy node** is a placeholder at the front of the list carrying no real data. Its purpose is to
give the first real node a predecessor, which deletes the head special case from every operation
rather than handling it.

```cpp
class SentinelList {
    struct SNode { int data; SNode* next; SNode(int d=-1):data(d),next(nullptr){} };
    SNode* dummy;   // always exists; its data is never used
    int    sz;

public:
    SentinelList() : dummy(new SNode()), sz(0) {}
    ~SentinelList() {
        SNode* cur = dummy;
        while (cur) { SNode* n = cur->next; delete cur; cur = n; }
    }

    // No head special case anywhere below.
    void insertFront(int val) {
        SNode* n = new SNode(val);
        n->next = dummy->next;
        dummy->next = n;
        sz++;
    }

    bool remove(int val) {
        SNode* prev = dummy;                 // ALWAYS exists
        while (prev->next && prev->next->data != val) prev = prev->next;
        if (!prev->next) return false;
        SNode* target = prev->next;
        prev->next = target->next;
        delete target;
        sz--;
        return true;
    }

    int size() const { return sz; }
};
```

**Compare this `remove` with §17.4's.** The earlier version needed a fifteen-line special case for
the head; this one has none, because `prev` starts at the dummy and is therefore never null. The
node after the dummy is the real head, and removing it is the ordinary case.

**The cost is one node's worth of memory and remembering that the list starts at `dummy->next`.**
Every traversal must skip it, and forgetting to is the one bug the pattern introduces — a `print`
that starts at `dummy` shows a phantom `-1` at the front.

:::callout-intuition[Delete the special case, do not handle it]
The sentinel is worth understanding as a general technique, not a linked-list trick. Special cases
are where bugs concentrate, because they are the paths least often executed and least often tested.
Restructuring the data so the special case *cannot arise* removes a whole class of bug rather than
guarding against it.

The same idea appears as the padding row around a grid so that neighbour lookups never go out of
bounds, and as the `merge` sentinel above. Whenever you find yourself writing "if this is the first
one", ask whether a sentinel would make it not be.
:::

## §17.12 — Linked Lists & Recursion

A linked list is recursive by construction: it is either empty, or a node followed by another list.
Many operations express naturally that way.

```cpp
// Recursive sum
int sumR(Node* head) {
    if (!head) return 0;               // base case: empty
    return head->data + sumR(head->next);  // recursive case
}

// Recursive print in reverse (elegant, but O(n) stack space)
void printReverse(Node* head) {
    if (!head) return;
    printReverse(head->next);   // recurse first
    cout << head->data << " "; // then print (on the way back up)
}

// Recursive search
bool containsR(Node* head, int val) {
    if (!head) return false;
    if (head->data == val) return true;
    return containsR(head->next, val);
}

// Recursive reverse — returns new head
Node* reverseR(Node* head) {
    if (!head || !head->next) return head;  // 0 or 1 nodes
    Node* newHead = reverseR(head->next);   // reverse the rest
    head->next->next = head;                // make the next node point back
    head->next = nullptr;                   // and cut the old forward link
    return newHead;                          // the deepest node, unchanged
}
```

**`printReverse` is the one that shows what recursion buys.** Printing a singly-linked list
backwards iteratively requires either reversing it or a stack; recursively it is two lines, because
the call stack *is* the stack. Everything happens on the way back up.

**`reverseR` returns the same pointer all the way up.** `newHead` is the last node of the original
list, found at the deepest call, and every level returns it unchanged while relinking its own two
pointers on the way out. The `head->next = nullptr` is easy to omit and produces a two-node cycle at
what should be the tail.

:::callout-pitfall[Recursion depth is a hard limit]
Every recursive call here consumes a stack frame, so the depth equals the length of the list. A
default stack is around 1 MB on Windows and 8 MB on Linux; at roughly 50 bytes a frame, a list of a
few hundred thousand nodes overflows the stack and the program dies with no useful message.

The iterative versions use $O(1)$ space and have no such limit. **For data structures, prefer
iteration unless the depth is bounded** — which it is for a balanced tree, where depth is
$O(\log n)$, and is not for a list, where it is $O(n)$.

`sumR` and `containsR` are *tail-recursive* in shape, and some compilers will convert them into
loops at `-O2`, removing the limit. Some will not, and none guarantee it — so it is not something to
rely on.
:::

## Chapter summary

:::callout-key[Mechanics]
- A node is data plus a pointer; the list is reached through `head`
- **Insertion is two steps in a fixed order**: point the new node at the rest, then point the
  predecessor at the new node
- Removal needs the *predecessor*, so a singly-linked list carries a trailing `prev` pointer
- Save `cur->next` before `delete cur` — always
- The destructor must walk and delete every node, or the whole list leaks
- Prepend is $O(1)$; append is $O(n)$ without a tail pointer and $O(1)$ with one
- Doubly-linked adds backward traversal and $O(1)$ removal given a node, for one extra pointer per
  node and four pointer updates per insertion
- Circular lists have no null terminator, so traversal must stop where it started
:::

:::callout-tip[Judgement]
- Linked lists win on insertion **at a node you already hold**, not at an index
- Arrays usually win in practice on cache behaviour, whatever Big-O says
- Slow and fast pointers find the middle, and detect a cycle, in one pass
- Merge sort is the right sort for a list: $O(n \log n)$, no random access, relinks rather than
  copies
- Reassign the head after sorting — `mergeSort` returns a new one
- A sentinel node deletes the head special case instead of handling it
- Recursion on a list is elegant and depth-limited; iterate for anything long
:::

## Practice Problems

:::problem[P1 easy]{difficulty="easy"}
**Count occurrences.** Write `int countOccurrences(Node* head, int val)` returning how many nodes
hold `val`. Do it iteratively.

::::solution[Solution]
```cpp
int countOccurrences(Node* head, int val) {
    int count = 0;
    for (Node* cur = head; cur; cur = cur->next)
        if (cur->data == val) count++;
    return count;
}
```

**The `for` loop is the idiomatic traversal**, and it reads better than the equivalent `while`
because the three parts of the walk — start at the head, continue while non-null, advance to next —
are on one line where they can be checked together.

**No early exit**, unlike `search`. The function must see every node, so the loop always runs to the
end and the complexity is $O(n)$ regardless of the data.

On an empty list the loop body never runs and the function returns 0, which is correct and needs no
special case — a good sign that the loop is written properly.
::::
:::

:::problem[P2 standard]{difficulty="standard"}
**Detect a cycle.** Write `bool hasCycle(Node* head)` that returns whether the list loops back on
itself. Use $O(1)$ extra space.

::::solution[Solution]
```cpp
bool hasCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;   // they met — there is a loop
    }
    return false;                         // fast reached the end
}
```

**This is Floyd's algorithm**, and the argument that it works is worth following. If there is no
cycle, `fast` reaches the null terminator and the loop ends. If there is one, both pointers
eventually enter it, and from then on `fast` gains exactly one node per step on `slow` — so the gap
between them shrinks by one each iteration and must reach zero. They cannot step over each other.

**Comparing pointers, not data.** `slow == fast` asks whether they are at the *same node*. Comparing
`slow->data == fast->data` would report a false cycle on any list with a repeated value.

**$O(1)$ space is the constraint that makes this interesting.** The obvious solution — a `set` of
visited nodes — is $O(n)$ memory. Two pointers use none, which matters when the "list" is a stream
you cannot store.

**The loop condition tests both `fast` and `fast->next`** because `fast` advances two steps; without
the second test, `fast->next->next` dereferences null on an even-length list.
::::
:::

:::problem[P3 challenge]{difficulty="challenge"}
**Merge two sorted lists into a third.** Without allocating any new nodes, and without a sentinel —
handle the head case explicitly. Explain why the sentinel version is preferable.

::::solution[Solution]
```cpp
Node* mergeNoSentinel(Node* a, Node* b) {
    if (!a) return b;
    if (!b) return a;

    Node* head;                       // the head must be chosen first
    if (a->data <= b->data) { head = a; a = a->next; }
    else                    { head = b; b = b->next; }

    Node* tail = head;
    while (a && b) {
        if (a->data <= b->data) { tail->next = a; a = a->next; }
        else                    { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a ? a : b;
    return head;
}
```

**Count what the sentinel removed.** This version needs two empty-list guards, a separate
head-selection block that duplicates the comparison logic, and a `tail` initialised from it — about
eight lines that §17.10's version does not have. The comparison `a->data <= b->data` now appears
twice, so a change to the ordering has to be made in both places or the sort silently loses
stability at the first element only.

**The sentinel version's whole trick** is that `Node dummy(0);` gives the first real node somewhere
to attach to, so the loop handles it like any other. `dummy.next` is then the head, chosen by the
same code that chose everything else.

**One thing both versions share:** no new nodes are allocated. The merge relinks the existing nodes,
which is why merge sort on a list needs no auxiliary array. Note this means both input lists are
destroyed — their nodes now belong to the merged list — so the caller must not use `a` or `b`
afterwards.
::::
:::

## LeetCode Problems

:::callout-tip[Practice beyond the chapter]
Linked lists are one of the most heavily represented topics in interview problems, precisely because
they test pointer discipline rather than cleverness.

| # | Problem | Difficulty | Key concept |
| --- | --- | --- | --- |
| 206 | [Reverse Linked List](https://leetcode.com/problems/reverse-linked-list/) | Easy | Pattern 4 of §17.9 — three pointers, in place |
| 141 | [Linked List Cycle](https://leetcode.com/problems/linked-list-cycle/) | Easy | Floyd's algorithm, as in P2 |
| 21 | [Merge Two Sorted Lists](https://leetcode.com/problems/merge-two-sorted-lists/) | Easy | The `merge` of §17.10; the sentinel earns its keep |
| 876 | [Middle of the Linked List](https://leetcode.com/problems/middle-of-the-linked-list/) | Easy | Slow and fast pointers, one pass |
| 19 | [Remove Nth Node From End](https://leetcode.com/problems/remove-nth-node-from-end-of-list/) | Medium | Two pointers `n` apart; a sentinel removes the head case |
| 148 | [Sort List](https://leetcode.com/problems/sort-list/) | Medium | The full merge sort of §17.10 |
:::
