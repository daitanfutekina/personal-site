---
title: "Orthogonality and Least Squares"
crumb: "Linear Algebra · Chapter 6"
meta:
  - "Est. study time: ~7–9 hours, including practice"
  - "MA 3113 · Mississippi State University"
  - "Lay 6th ed. · §§6.1–6.6: Inner Product; Orthogonal Sets; Projections; Gram–Schmidt and QR; Least Squares; Linear Models / Regression"
source: "markdown"
---

## Overview

Suppose you need the nearest point on a line, need to find coordinates without solving a system, or need a line that fits measurements that do not lie exactly on one line. Those look like three separate tasks. In this chapter they turn out to be one idea: **the error left over after the best approximation is perpendicular to the space of possible answers**. A dot product measures perpendicularity; an orthogonal basis makes it easy to calculate; a projection gives the closest point; least squares applies the same projection to inconsistent systems and data.

The six sections follow Lay and Kim's numbering: **§6.1 Inner Product, Length, and Orthogonality; §6.2 Orthogonal Sets; §6.3 Orthogonal Projections; §6.4 The Gram–Schmidt Process and QR Factorization; §6.5 Least-Squares Problems; §6.6 Applications: Linear Models / Regression**. Symmetric-matrix material belongs to chapter seven of Lay and appears after mixed practice in **Beyond the course: Symmetric Matrices**, not interleaved with the exam path.

:::callout-key[Prerequisites and written-test method]
Know matrix multiplication, row reduction, bases, $\rank$ and $\nullity$ from Chapters 2–4. Here $\Row A$, $\Nul A$ and $\Col A$ denote row, null and column spaces. Keep fractions exact, write the dot product **before** substituting a projection, and verify orthogonality by checking a dot product equals zero. You do not need a calculator. Where a problem gives an answer, show the intermediate arithmetic that earns credit.
:::

## 6.1 Inner Product, Length, and Orthogonality

You already know that two arrows can point in different directions. To compute how much one arrow points *along* another, we need a number that is positive when they point somewhat together, negative when they point against each other, and zero when they make a right angle. That number is the **dot product**. Its other use is subtle: dotting a vector with itself squares its length. That single operation therefore measures angles, distances, and the normal directions to a line or plane.

For example, the vector $(3,4)$ describes a displacement of three units horizontally and four units vertically. Its length is five, not seven, because those components are perpendicular and Pythagoras applies. Similarly, to decide whether $(2,-1,3)$ is perpendicular to an entire plane, you do not inspect infinitely many points on the plane. You dot it with two spanning directions. If both are zero, every linear combination is also perpendicular. This converts a geometric problem into a small matrix equation.

:::definition[Definition 6.1 — Inner Product]
For $\mathbf u,\mathbf v\in\R^n$, the **inner product** or **dot product** is $\mathbf u\cdot\mathbf v=\mathbf u^T\mathbf v=u_1v_1+\cdots+u_nv_n$. It produces a **scalar**, not a vector. The operation is symmetric, distributive over addition, and compatible with scalars: $(c\mathbf u)\cdot\mathbf v=c(\mathbf u\cdot\mathbf v)$ and $(\mathbf u+\mathbf v)\cdot\mathbf w=\mathbf u\cdot\mathbf w+\mathbf v\cdot\mathbf w$.
:::

:::definition[Definition 6.2 — Norm, Unit Vector, Distance]
The **norm** (length) is $\|\mathbf v\|=\sqrt{\mathbf v\cdot\mathbf v}=\sqrt{v_1^2+\cdots+v_n^2}$. A vector is a **unit vector** if its norm is one. For $\mathbf v\ne\mathbf0$, its unit vector in the same direction is $\mathbf v/\|\mathbf v\|$. Distance is $\operatorname{dist}(\mathbf u,\mathbf v)=\|\mathbf u-\mathbf v\|$. Important: $\|c\mathbf v\|=|c|\|\mathbf v\|$; a negative scalar reverses direction but not length.
:::

:::definition[Definition 6.3 — Orthogonality]
Vectors $\mathbf u$ and $\mathbf v$ are **orthogonal** precisely when $\mathbf u\cdot\mathbf v=0$. The zero vector is orthogonal to every vector, although it has no direction. For **nonzero** vectors, $\mathbf u\cdot\mathbf v=\|\mathbf u\|\|\mathbf v\|\cos\theta$, so zero dot product means a $90^\circ$ angle.
:::

:::theorem[Theorem 6.1 — Pythagorean and Parallelogram Identities]
Two vectors are orthogonal if and only if $\|\mathbf u+\mathbf v\|^2=\|\mathbf u\|^2+\|\mathbf v\|^2$. For arbitrary vectors, $\|\mathbf u+\mathbf v\|^2+\|\mathbf u-\mathbf v\|^2=2\|\mathbf u\|^2+2\|\mathbf v\|^2$.
:::

:::proof[Why the identities work]
Expand using distributivity: $(\mathbf u+\mathbf v)\cdot(\mathbf u+\mathbf v)=\mathbf u\cdot\mathbf u+2\mathbf u\cdot\mathbf v+\mathbf v\cdot\mathbf v$. The middle term disappears exactly when the vectors are orthogonal. Repeat with $\mathbf u-\mathbf v$ to obtain the negative cross term; adding the two expansions cancels both cross terms. This proof is a reliable exam justification when you forget either identity.
:::

:::definition[Definition 6.4 — Orthogonal Complement]
For a subspace $W\subseteq\R^n$, $W^\perp=\{\mathbf z\in\R^n: \mathbf z\cdot\mathbf w=0\text{ for every }\mathbf w\in W\}$. To find it, arrange a spanning set of $W$ as **rows** of a matrix $B$, then solve $B\mathbf z=\mathbf0$. Equivalently, if $W=\Col A$, use $W^\perp=\Nul(A^T)$.
:::

:::theorem[Theorem 6.2 — Four Fundamental Subspaces]
For $A$ of size $m\times n$, $(\Row A)^\perp=\Nul A$ **inside $\R^n$**, whereas $(\Col A)^\perp=\Nul(A^T)$ **inside $\R^m$**. Moreover, $W^\perp$ is a subspace, $\dim W+\dim W^\perp=n$, $W\cap W^\perp=\{\mathbf0\}$ and $(W^\perp)^\perp=W$.
:::

The dimension count comes directly from rank–nullity. If $B$ has the basis vectors of $W$ as rows, then $\rank B=\dim W$, while $\dim\Nul B=n-\rank B$. Because $W^\perp=\Nul B$, the dimensions sum to $n$. For the intersection statement, a vector belonging to both $W$ and $W^\perp$ must be orthogonal to *itself*. Then $\mathbf z\cdot\mathbf z=0$, so $\mathbf z=\mathbf0$.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="An illustrative row-space plane through the origin with a perpendicular null-space direction; distinguish row/null from column/left-null">
<path class="fig-fill" d="M 54 138 L 209 190 L 351 108 L 196 56 Z"/>
<line class="fig-axis" x1="28" y1="171" x2="383" y2="171"/>
<line class="fig-axis" x1="194" y1="214" x2="194" y2="21"/>
<path class="fig-curve" d="M 195 143 L 294 143"/>
<path class="fig-curve-alt" d="M 195 143 L 232 100"/>
<path class="fig-arrow" d="M 195 143 L 165 55"/>
<line class="fig-guide" x1="165" y1="55" x2="165" y2="155"/>
<circle class="fig-point" cx="195" cy="143" r="4"/>
<circle class="fig-point" cx="165" cy="55" r="4"/>
<text class="fig-label" x="300" y="136">Row A</text>
<text class="fig-label" x="240" y="96">r₂</text>
<text class="fig-label" x="98" y="41">Nul A</text>
<text class="fig-label" x="179" y="154">0</text>
<text class="fig-label" x="172" y="62">n</text>
</svg>
<figcaption>The row space and null space occupy the same $\R^n$ and meet at right angles: $\Row A\perp\Nul A$. In contrast, $\Col A$ and $\Nul(A^T)$ form a perpendicular pair in $\R^m$.</figcaption>
</figure>

### A four-step method worth memorizing

**Dot product:** check equal vector lengths, multiply matching entries and add. **Length or distance:** first square each component (or subtract components), then add, then take one square root. **Unit vector:** divide *all* entries by the positive norm; do not separately divide each entry by its absolute value. **Complement:** make a homogeneous system from directions in $W$, row-reduce, and express every free variable as a basis vector. When the question asks whether a vector belongs to a complement, one nonzero dot product disproves it; to prove membership, every spanning direction must pass.

:::example[Example 6.1 — Dot product, norms and the orthogonality decision]
Let $\mathbf u=\begin{bmatrix}1\\-2\\3\end{bmatrix}$ and $\mathbf v=\begin{bmatrix}4\\2\\0\end{bmatrix}$. Compute their dot product and lengths, and test orthogonality.

::::answer[Answer]
**Answer:** $\mathbf u\cdot\mathbf v=0$, $\|\mathbf u\|=\sqrt{14}$, $\|\mathbf v\|=2\sqrt5$; **yes, orthogonal**.

1. Match each coordinate: $(1)(4)+(-2)(2)+(3)(0)=4-4+0=0$.

2. For the first norm, square and add: $1^2+(-2)^2+3^2=1+4+9=14$, then square-root.

3. For the second norm, $4^2+2^2+0^2=16+4=20$, so $\sqrt{20}=2\sqrt5$.

4. The zero dot product is the condition for orthogonality.

5. Do not confuse the dot product, which is zero, with either length, which is positive.
::::

:::

:::example[Example 6.2 — Orthogonal complement by row reduction]
Let $W=\span\{(1,1,0)^T,(0,1,1)^T\}\subseteq\R^3$. Find a basis for $W^\perp$.

::::answer[Answer]
**Answer:** $W^\perp=\span\{(1,-1,1)^T\}$.

1. Write $\mathbf z=(z_1,z_2,z_3)^T$.

2. Orthogonality to each displayed spanning vector means $z_1+z_2=0$ and $z_2+z_3=0$.

3. Set these as **rows**: $B=\begin{bmatrix}1&1&0\\0&1&1\end{bmatrix}$.

4. Row operation $R_1\leftarrow R_1-R_2$ gives $\begin{bmatrix}1&0&-1\\0&1&1\end{bmatrix}$.

5. The free variable is $z_3=t$.

6. Back-substitution gives $z_1=t$, $z_2=-t$, so $\mathbf z=t(1,-1,1)^T$.

7. Check both dots: $1-1=0$, and $-1+1=0$.

8. There is one free variable because this two-dimensional plane in $\R^3$ has a one-dimensional perpendicular line.
::::

:::

:::example[Example 6.3 — Distance and normalization]
Let $\mathbf a=(7,1)^T$ and $\mathbf b=(3,2)^T$. Find the distance between them. Separately, normalize $\mathbf w=(3,4)^T$.

::::answer[Answer]
**Answer:** $\operatorname{dist}(\mathbf a,\mathbf b)=\sqrt{17}$; $\mathbf w/\|\mathbf w\|=(3/5,4/5)^T$.

1. Subtract first, component by component: $\mathbf a-\mathbf b=(7-3,1-2)^T=(4,-1)^T$.

2. Then $\|\mathbf a-\mathbf b\|^2=4^2+(-1)^2=16+1=17$.

3. For $\mathbf w$, $\|\mathbf w\|=\sqrt{3^2+4^2}=\sqrt{25}=5$.

4. Divide both components by five.

5. Verify unit length: $(3/5)^2+(4/5)^2=9/25+16/25=1$.

6. Distance compares two *points*; normalization changes the magnitude of one *direction* while keeping it parallel.
::::

:::

:::example[Example 6.4 — Finding a perpendicular direction in four coordinates]
Let $W=\span\{(1,0,1,0)^T,(0,1,0,1)^T\}\subseteq\R^4$. Find $W^\perp$ and verify its dimension.

::::answer[Answer]
**Answer:** $W^\perp=\span\{(-1,0,1,0)^T,(0,-1,0,1)^T\}$ and $\dim W^\perp=2$.

1. A general vector $\mathbf z=(a,b,c,d)^T$ is perpendicular to the first generator when $a+c=0$, and to the second when $b+d=0$.

2. Thus $a=-c$ and $b=-d$.

3. With free parameters $c=s$ and $d=t$, the full vector is $(-s,-t,s,t)^T=s(-1,0,1,0)^T+t(0,-1,0,1)^T$.

4. The two displayed basis vectors are independent because their third and fourth components isolate $s$ and $t$.

5. The original generators are also independent, so $\dim W=2$ and $2+2=4$, matching the theorem.

6. It is a mistake to say the complement is only one vector: a basis is a set of generators, not the entire subspace.
::::

:::


### Orthogonality is about direction, not visual shape

When a diagram is drawn in two coordinates, a right angle is easy to recognize. In four coordinates, there is no useful ordinary picture, yet the dot product gives precisely the same test. A vector with four entries is still an arrow in a four-dimensional vector space: $u\cdot v=0$ is the algebraic meaning of perpendicularity. Do not invent a four-dimensional sketch for an exam. Write one multiplication-and-addition line and explain that a zero result establishes orthogonality.

The sign of a nonzero dot product also has meaning. If $u$ and $v$ are nonzero, $u\cdot v=\|u\|\|v\|\cos\theta$. Positive means the angle between them is acute; negative means obtuse; zero means right. For example, $(1,0)\cdot(1,1)=1$ is positive: one direction points along the rightward component of the other. But $(1,0)\cdot(-1,1)=-1$ is negative, and $(1,0)\cdot(0,1)=0$. Do not divide by norms to find an angle unless the problem explicitly asks; the **sign and zero test** are available with integer arithmetic alone. A unit vector does not automatically mean two vectors form an orthonormal pair: each must have norm one **and** their mutual dot must be zero.

A second geometric connection is the triangle inequality $\|u+v\|\le\|u\|+\|v\|$. Equal-length directions pointing together maximize the combined length, while opposing directions may partially cancel. Orthogonal directions follow a different, more precise squared-length law. If $u=(3,0)$ and $v=(0,4)$, the sum has length $5$, even though the individual lengths sum to $7$. This is why the true/false claim that perpendicular vector **lengths** add is false. Length **squares** add. The difference matters because square roots do not distribute over addition.

### Turning a plane's spanning vectors into equations

An orthogonal complement sounds like an abstract collection, but the computation is only elimination. Suppose $W$ is the span of $u_1=(1,2,0)$ and $u_2=(0,1,3)$. To find the vectors perpendicular to *all* of $W$, give an unknown $z=(a,b,c)$ three components. The two dot-product conditions are $a+2b=0$ and $b+3c=0$. You now have a homogeneous system with two equations and three unknowns. Set $c=t$, then $b=-3t$ and $a=-2b=6t$. So the perpendicular vectors are precisely $t(6,-3,1)$, including zero when $t=0$. A student who checks only the first spanning vector would leave too large a set, because perpendicularity to one line does not guarantee perpendicularity to a plane.

The order of spanning vectors does not affect the resulting complement. Replacing the spanning set by another basis of the same subspace leaves every perpendicular vector unchanged. This follows from distributivity: if $z$ dots to zero with two directions, it also dots to zero with any combination $s u_1+t u_2$ because $z\cdot(su_1+tu_2)=s(z\cdot u_1)+t(z\cdot u_2)=0$. Conversely, a vector perpendicular to the entire subspace is certainly perpendicular to each listed generator. This equivalence is the formal reason that **a finite number of equations describes perpendicularity to infinitely many vectors**.

Keep the location of each subspace explicit. For $A$ with two rows and three columns, the row vectors have three components, so $\Row A$ and $\Nul A$ live in $\R^3$. The column vectors have two components, so $\Col A$ and $\Nul(A^T)$ live in $\R^2$. There is **no general claim** that $\Col A$ and $\Nul A$ are perpendicular: unless $A$ happens to be square, they do not even inhabit the same ambient space. Even for square $A$, the valid automatic pairings remain row/null and column/left-null. That is an excellent conceptual question because memorizing the words without checking dimensions makes an incorrect assertion seem plausible.

### How to present short proofs

The three most likely short proofs are: (1) show a sum of vectors remains orthogonal to $W$; (2) show $W\cap W^\perp=\{0\}$; and (3) establish the dimension of the complement. For closure, if $z_1,z_2\in W^\perp$ and $w\in W$, then $(z_1+z_2)\cdot w=z_1\cdot w+z_2\cdot w=0+0=0$. For scalar multiples, $(cz_1)\cdot w=c(z_1\cdot w)=0$. Those two checks, together with inclusion of zero, establish a subspace. For the intersection, choose $w=z$ and use $z\cdot z=0$ to conclude $z=0$. For dimension, put a basis of $W$ into matrix rows and invoke rank–nullity, accounting for the number of **columns** as the ambient dimension. These are short written justifications, not lengthy geometry arguments.



### Length, squared length, and the angle test are separate outputs

Many short questions ask you to compute several quantities from the same vectors. Keep them separate rather than collapsing all arithmetic into one line. Start with $u\cdot v$ to answer perpendicularity; compute $u\cdot u$ and $v\cdot v$ to answer lengths; compute $u-v$ before its squared norm to answer distance. The **squared norm** is often the cleanest intermediate value on paper because it is an integer even if the final length is a radical. If a question asks $\|u\|^2$, do not take a square root and then square it again: just calculate $u\cdot u$.

An angle question may use $\cos\theta=(u\cdot v)/(\|u\|\|v\|)$. For directions $(1,0)$ and $(1,1)$, the numerator is one, and the lengths are one and $\sqrt2$, so $\cos\theta=1/\sqrt2$ and the smaller angle is $45^\circ$. This is a special angle that can be recognized without a calculator. Other ratios may not give familiar angles, so on a written test an exact cosine expression is preferable to a made-up decimal degree value. If either vector is zero, this quotient is undefined because one norm vanishes; that is why the geometric angle formula explicitly assumes both vectors are nonzero.

Distance is invariant under translating both endpoints by the same vector: $\|(u+w)-(v+w)\|=\|u-v\|$. This should match your geometric intuition: moving both points to another part of the page cannot change the gap between them. It provides a useful shortcut if both vectors contain an awkward common offset. On the other hand, changing the sign of **one** endpoint can change the distance, because $\|u-v\|$ and $\|u+v\|$ usually differ. Their squares differ by $4u\cdot v$, so these two distances are equal precisely when $u$ and $v$ are orthogonal. That identity is another likely true/false proof and follows by expanding the two dot products.

### A matrix is sometimes just several dot products at once

If the rows of $B$ are $r_1,r_2,r_3$, then $Bz$ is a column vector whose entries are $r_1\cdot z$, $r_2\cdot z$, and $r_3\cdot z$. Consequently $Bz=0$ is a compact way of saying "$z$ is perpendicular to each row of $B$." This observation is the entire reason $\Nul B=(\Row B)^\perp$. If instead the directions of interest are the **columns** of $A$, first transpose them to make rows: $A^Tz=0$. No new rule is necessary. It is the same dot-product equation, organized so ordinary matrix multiplication checks all directions simultaneously.



### A final decision tree for complement problems

If the question supplies a **span**, its listed vectors are the directions to dot against, so use those vectors as rows and find a null space. If it supplies $\Row A$, use $\Nul A$ without transposing. If it supplies $\Col A$, use $\Nul(A^T)$ and check the number of rows of $A$ to identify the ambient dimension. If it supplies a plane equation $ax+by+cz=0$, the normal $(a,b,c)$ generates the complement, provided the normal is nonzero. Finally, check the dimension: a nonzero plane in $\R^3$ has a one-dimensional complement. That check will not determine a basis by itself, but it quickly reveals a missing free variable or an extra, dependent basis vector.


:::callout-pitfall[§6.1: The mistakes that lose written-test points]
Never calculate distance by subtracting *norms*: $\|u-v\|$ is generally not $\|u\|-\|v\|$. Never replace $\sqrt{a^2+b^2}$ with $a+b$. A dot product uses corresponding entries rather than all possible pair products. When finding a complement, mixing up $\Nul A$ and $\Nul A^T$ is a **dimension error**: for an $m\times n$ matrix the first lives in $\R^n$ and the second in $\R^m$. Finally, the zero vector satisfies the dot-product test, but does not define an angle or a direction to normalize.
:::

:::problem[Problem 6.1 — Pairwise orthogonality]{difficulty=easy}
Determine if $\mathbf u=(3,-2,1)^T$ and $\mathbf v=(2,3,0)^T$ are orthogonal.

::::solution[Solution]
**Answer:** yes.

1. Use the orthogonality test: two vectors in $\mathbb R^3$ are orthogonal exactly when their dot product is zero.
2. Match the first coordinates: $(3)(2)=6$. Match the second: $(-2)(3)=-6$. Match the third: $(1)(0)=0$.
3. Add all three products: $u\cdot v=6+(-6)+0=6-6=0$. Thus the vectors are orthogonal, regardless of their lengths.
**Check:** The full coordinate calculation $3(2)+(-2)(3)+1(0)=0$ confirms perpendicularity.
::::

:::

:::problem[Problem 6.2 — Unit vector]{difficulty=easy}
Find a unit vector in the direction of $\mathbf v=(2,-1,2)^T$.

::::solution[Solution]
**Answer:** $(2/3,-1/3,2/3)^T$.

1. Since $v$ is nonzero, normalization is defined. Normalize by dividing the vector by its Euclidean length: $q=v/\|v\|$.
2. Calculate its squared length coordinate by coordinate: $\|v\|^2=2^2+(-1)^2+2^2=4+1+4=9$.
3. Take the positive square root, $\|v\|=\sqrt9=3$. Dividing by the length, not the squared length, gives $q=(2/3,-1/3,2/3)^T$.
**Check:** $\|q\|^2=(2/3)^2+(-1/3)^2+(2/3)^2=4/9+1/9+4/9=1$, so $\|q\|=1$.
::::

:::

:::problem[Problem 6.3 — Extremal complements]{difficulty=standard}
Describe $(\R^n)^\perp$ and $\{\mathbf0\}^\perp$ and justify both statements.

::::solution[Solution]
**Answer:** $(\R^n)^\perp=\{\mathbf0\}$ and $\{\mathbf0\}^\perp=\R^n$.

1. Recall $W^\perp=\{z:z\cdot w=0\text{ for every }w\in W\}$. Start with $W=\mathbb R^n$.
2. A vector $z\in(\mathbb R^n)^\perp$ must be perpendicular to every vector, including itself. Hence $z\cdot z=z_1^2+\cdots+z_n^2=0$. Each square is nonnegative, so every $z_i=0$ and $z=0$.
3. For $W=\{0\}$, let $z$ be arbitrary in $\mathbb R^n$. The only required dot product is $z\cdot0=z_1(0)+\cdots+z_n(0)=0$, which always holds.
4. Therefore the first complement contains only $0$, while the second contains every vector in $\mathbb R^n$.
**Check:** Their dimensions satisfy $n+0=n$ and $0+n=n$, in agreement with $\dim W+\dim W^\perp=n$.
::::

:::

:::problem[Problem 6.4 — Distance with a negative coordinate]{difficulty=standard}
Find the distance between $\mathbf a=(1,-3,2)^T$ and $\mathbf b=(-1,1,1)^T$.

::::solution[Solution]
**Answer:** $\sqrt{21}$.

1. Use the Euclidean distance formula $\operatorname{dist}(a,b)=\|a-b\|$ in $\mathbb R^3$.
2. Subtract entries, keeping the negative signs: $a-b=(1-(-1),-3-1,2-1)^T=(1+1,-4,1)^T=(2,-4,1)^T$.
3. Square the displacement coordinates and add: $\|a-b\|^2=2^2+(-4)^2+1^2=4+16+1=21$.
4. Take the nonnegative root because a distance is a length: $\|a-b\|=\sqrt{21}$.
**Check:** Reversing the subtraction gives $b-a=(-2,4,-1)^T$ with the same sum of squares $4+16+1=21$.
::::

:::

:::problem[Problem 6.5 — Complement as a null space]{difficulty=standard}
Find a basis for $W^\perp$ if $W=\span\{(1,2,-1)^T,(0,1,1)^T\}$.

::::solution[Solution]
**Answer:** $W^\perp=\span\{(3,-1,1)^T\}$.

1. Write an arbitrary perpendicular vector as $z=(x,y,z_3)^T$. It must have dot product zero with each generator of $W$.
2. Expand the two conditions: $(1,2,-1)\cdot(x,y,z_3)=x+2y-z_3=0$ and $(0,1,1)\cdot(x,y,z_3)=y+z_3=0$.
3. Make those generators the rows of $B=\begin{bmatrix}1&2&-1\\0&1&1\end{bmatrix}$. Apply $R_1\leftarrow R_1-2R_2$ to obtain $\begin{bmatrix}1&0&-3\\0&1&1\end{bmatrix}$.
4. Since the third column is free, put $z_3=t$. The reduced equations are $x-3t=0$ and $y+t=0$, yielding $x=3t$, $y=-t$.
5. Thus every solution is $(x,y,z_3)^T=t(3,-1,1)^T$, and the single nonzero generator is a basis of $W^\perp$.
**Check:** $(1,2,-1)\cdot(3,-1,1)=3-2-1=0$ and $(0,1,1)\cdot(3,-1,1)=0-1+1=0$.
::::

:::

:::problem[Problem 6.6 — True/false with justifications]{difficulty=challenge}
Decide whether each statement is true: (a) $\|u+v\|^2=\|u\|^2+\|v\|^2$ implies $u\perp v$; (b) for $A\in\R^{2\times3}$, $\Nul A$ is a subspace of $\R^2$; (c) $\mathbf u\cdot\mathbf v=\mathbf0$ is a vector equation.

::::solution[Solution]
**Answer:** T, F, F.

1. (a) Expand the left: the difference is $2u\cdot v$, so it must vanish.

2. (b) Every solution to $Ax=0$ has **three** components, because $A$ has three columns: it belongs to $\R^3$.

3. (c) Dot products are scalars; the correct right-hand side is the scalar $0$, not a vector $\mathbf0$.
::::

:::

## 6.2 Orthogonal Sets

A single right angle is useful; a whole collection of mutually perpendicular directions is much better. Consider ordinary horizontal and vertical axes. If your vector is three units right and two up, its horizontal and vertical coordinates can be read independently because the axes do not interfere with each other. An **orthogonal basis** gives the same independence in $\R^3$, $\R^4$, or any $\R^n$. Instead of solving one large system for coordinates, you compute independent dot products.

The surprising point is that different lengths do not spoil this convenience. Directions $(2,0)$ and $(0,3)$ are perpendicular, even though their lengths are two and three. To recover the weight of the first from a vector, take its dot product with the first direction, then divide by the *squared* length four. If every direction already has length one, that denominator is one. An **orthonormal** basis is just the most convenient version of an orthogonal basis.

:::definition[Definition 6.5 — Orthogonal Set and Orthogonal Basis]
A collection $\{u_1,\ldots,u_p\}$ is **orthogonal** when $u_i\cdot u_j=0$ for every pair with $i\ne j$. It is an **orthogonal basis for $W$** if its vectors are nonzero, pairwise orthogonal, and span $W$. An orthogonal set need not consist of unit vectors.
:::

:::definition[Definition 6.6 — Orthonormal Set]
A set is **orthonormal** when its vectors have length one and are mutually orthogonal. Equivalently, $q_i\cdot q_j=1$ for $i=j$ and $0$ for $i\ne j$. If $U=[q_1\;\cdots\;q_p]$, the matrix statement is $U^TU=I_p$ even when $U$ is rectangular.
:::

:::theorem[Theorem 6.3 — Why orthogonal sets are independent]
Every **orthogonal set of nonzero vectors** is linearly independent, so it is a basis for its span. If $c_1u_1+\cdots+c_pu_p=0$, dot both sides with $u_j$. All terms except $c_j(u_j\cdot u_j)$ disappear. Since $u_j\ne0$, its squared length is positive, giving $c_j=0$.
:::

This argument matters on a written exam: the **nonzero** requirement is essential. You can have a collection containing the zero vector that satisfies all pairwise dot products but is still dependent. A quick orthogonality check also does not prove that an arbitrary orthogonal set is a basis for all of $\R^n$; you need **$n$ vectors in $\R^n$**, or an independent dimension argument. Three nonzero perpendicular vectors in $\R^4$ span a three-dimensional subspace, not the whole of $\R^4$.

:::theorem[Theorem 6.4 — Coordinates in an Orthogonal Basis]
If $u_1,\ldots,u_p$ is an orthogonal basis of $W$ and $y\in W$, then $y=c_1u_1+\cdots+c_pu_p$ has **unique** coefficients $c_j=(y\cdot u_j)/(u_j\cdot u_j)$. If the basis is orthonormal, the formula simplifies to $c_j=y\cdot u_j$. This is a formula for **coordinates**, not a projection onto an unrelated space.
:::

:::proof[Deriving one coefficient instead of memorizing all of them]
Start with $y=c_1u_1+\cdots+c_pu_p$. Dot with a particular $u_j$. Distribute: $y\cdot u_j=\sum_i c_i(u_i\cdot u_j)$. Pairwise perpendicularity makes every term with $i\ne j$ equal zero, leaving $y\cdot u_j=c_j(u_j\cdot u_j)$. Divide by the positive number $u_j\cdot u_j$. Repeat independently for each $j$. If the denominator is missing in your calculation, you have silently assumed the basis is *orthonormal*.
:::

:::theorem[Theorem 6.5 — Orthonormal Column Test]
For an $m\times p$ matrix $U$, the columns are orthonormal **if and only if** $U^TU=I_p$. Consequently $\|Ux\|=\|x\|$ for every $x\in\R^p$, and $(Ux)\cdot(Uy)=x\cdot y$. If $U$ is square, also $UU^T=I$, $U^{-1}=U^T$, and $|\det U|=1$. A rectangular $U$ generally does **not** satisfy $UU^T=I_m$.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="The vector y split into horizontal and vertical mutually perpendicular components c1u1 and c2u2">
<line class="fig-axis" x1="38" y1="194" x2="381" y2="194"/>
<line class="fig-axis" x1="75" y1="225" x2="75" y2="22"/>
<line class="fig-gridline" x1="125" y1="34" x2="125" y2="215"/>
<line class="fig-gridline" x1="175" y1="34" x2="175" y2="215"/>
<line class="fig-gridline" x1="225" y1="34" x2="225" y2="215"/>
<line class="fig-gridline" x1="275" y1="34" x2="275" y2="215"/>
<line class="fig-gridline" x1="325" y1="34" x2="325" y2="215"/>
<line class="fig-gridline" x1="46" y1="54" x2="381" y2="54"/>
<line class="fig-gridline" x1="46" y1="94" x2="381" y2="94"/>
<line class="fig-gridline" x1="46" y1="134" x2="381" y2="134"/>
<line class="fig-gridline" x1="46" y1="174" x2="381" y2="174"/>
<path class="fig-curve" d="M 75 194 L 301 194"/>
<path class="fig-curve-alt" d="M 75 194 L 75 58"/>
<path class="fig-arrow" d="M 75 194 L 301 58"/>
<line class="fig-guide" x1="301" y1="194" x2="301" y2="58"/>
<circle class="fig-point" cx="301" cy="58" r="4"/>
<circle class="fig-point" cx="301" cy="194" r="4"/>
<circle class="fig-point" cx="75" cy="58" r="4"/>
<text class="fig-label" x="313" y="54">y</text>
<text class="fig-label" x="302" y="208">c₁u₁</text>
<text class="fig-label" x="84" y="47">c₂u₂</text>
<text class="fig-label" x="56" y="211">0</text>
</svg>
<figcaption>With perpendicular directions, the two weights $c_1$ and $c_2$ can be recovered independently by dot products: $c_j=(y\cdot u_j)/(u_j\cdot u_j)$.</figcaption>
</figure>

### Choosing between two coordinate methods

For an arbitrary basis, you set up a linear combination and row-reduce. For an **orthogonal** basis, dotting with each basis vector isolates the corresponding weight; there is no need for elimination. For an **orthonormal** basis, the weight is just a dot product. This hierarchy is the point of §6.2. A common exam prompt gives a set and says, “Verify orthogonality, then express $y$ as a linear combination.” Do not skip the verification: if just one pair has nonzero dot product, the shortcut formula is invalid. When checking three vectors, there are exactly three distinct pairwise dots, not nine: $u_1\cdot u_2$, $u_1\cdot u_3$, and $u_2\cdot u_3$.

:::example[Example 6.5 — Verify an orthogonal set]
Check $u_1=(1,-1,0)^T$, $u_2=(1,1,1)^T$, and $u_3=(-1,-1,2)^T$.

::::answer[Answer]
**Answer:** orthogonal, but not orthonormal.

1. Calculate all three distinct dots: $u_1\cdot u_2=1-1+0=0$; $u_1\cdot u_3=-1+1+0=0$; $u_2\cdot u_3=-1-1+2=0$.

2. Each vector is nonzero, so the set is also linearly independent.

3. Its squared norms are $2$, $3$, and $6$, not all one.

4. The previous chapter draft incorrectly started with a “not orthogonal” verdict using wrong signs, then contradicted itself; all three correct pair tests show **yes**.
::::

:::

:::example[Example 6.6 — Find weights in a non-unit orthogonal basis]
Let $u_1=(1,1,0)^T$, $u_2=(1,-1,0)^T$, and $u_3=(0,0,2)^T$. Express $y=(4,2,6)^T$ in this basis.

::::answer[Answer]
**Answer:** $y=3u_1+u_2+3u_3$.

1. Check perpendicularity: $u_1\cdot u_2=1-1=0$; $u_1\cdot u_3=0$; $u_2\cdot u_3=0$.

2. The squared norms are $2$, $2$, and $4$.

3. The three numerators are $y\cdot u_1=4+2=6$, $y\cdot u_2=4-2=2$, and $y\cdot u_3=6(2)=12$.

4. Therefore $c_1=6/2=3$, $c_2=2/2=1$, and $c_3=12/4=3$.

5. Check by rebuilding the vector: $3(1,1,0)+(1,-1,0)+3(0,0,2)=(4,2,6)$.

6. The last coefficient is **three**, not twelve, because $u_3$ is not unit length.
::::

:::

:::example[Example 6.7 — Orthonormal columns and transpose multiplication]
For $U=\frac13\begin{bmatrix}1&2\\2&-2\\2&1\end{bmatrix}$, test whether its two columns are orthonormal. Find $U^T(3,0,0)^T$.

::::answer[Answer]
**Answer:** $U^TU=I_2$ and $U^T(3,0,0)^T=(1,2)^T$.

1. Call the unscaled columns $a=(1,2,2)$ and $b=(2,-2,1)$.

2. Their squares are $a\cdot a=1+4+4=9$ and $b\cdot b=4+4+1=9$, while $a\cdot b=2-4+2=0$.

3. Multiplying every dot by $1/9$ gives $U^TU=\begin{bmatrix}1&0\\0&1\end{bmatrix}$.

4. To compute $U^Ty$, dot $y=(3,0,0)$ with the columns of $U$: $(3/3,6/3)=(1,2)$.

5. Because $U$ is $3\times2$, do **not** claim $UU^T=I_3$ or that $U^{-1}$ exists.
::::

:::

:::example[Example 6.8 — Recover a coordinate from an orthonormal expansion]
Suppose $\{u_1,u_2,u_3\}$ is orthonormal and $y=3u_1-2u_2+5u_3$. Find $y\cdot u_2$.

::::answer[Answer]
**Answer:** $y\cdot u_2=-2$.

1. Distribute the dot over all three terms: $3(u_1\cdot u_2)-2(u_2\cdot u_2)+5(u_3\cdot u_2)=3(0)-2(1)+5(0)=-2$.

2. The $u_2$ dot with itself is **one**, not zero.

3. If the basis were only orthogonal, you would obtain $-2\|u_2\|^2$ instead.
::::

:::


### Why dot-product coordinates beat row reduction

Imagine that you know $y=c_1u_1+c_2u_2$ and $u_1\perp u_2$. Ordinarily you could write two coordinate equations and solve them simultaneously. Orthogonality makes every other direction disappear when you dot with a selected basis vector. To isolate $c_2$, take $y\cdot u_2=c_1(u_1\cdot u_2)+c_2(u_2\cdot u_2)=c_2\|u_2\|^2$. Thus a coefficient is not found by comparing matching entries; it is obtained by comparing the **whole vector** with one basis direction. This distinction matters for vectors with all nonzero entries and for bases whose columns have inconvenient fractions.

Suppose two nonzero perpendicular basis vectors both lie in $\R^3$ and their span is a plane. The coefficient formula still recovers the plane components **provided $y$ lies in that plane**. If $y$ has a perpendicular part outside the plane, the same dot products recover the coefficients of its **projection**, not a representation of all of $y$. For instance, with $u_1=(1,0,0)$, $u_2=(0,1,0)$, and $y=(2,3,4)$, the dot-product weights are two and three. However, $y\ne2u_1+3u_2$; the right side is $(2,3,0)$. The leftover $(0,0,4)$ is perpendicular to both basis vectors. The transition from **orthogonal coordinates** in §6.2 to **orthogonal projection** in §6.3 is precisely the distinction between $y\in W$ and arbitrary $y\in\R^n$.

### What $U^TU=I$ checks, entry by entry

Matrix multiplication sometimes hides the simple scalar facts involved. Let $U=[q_1\ q_2]$ have two columns, each with $m$ entries. Then $U^TU=\begin{bmatrix}q_1\cdot q_1&q_1\cdot q_2\\q_2\cdot q_1&q_2\cdot q_2\end{bmatrix}$. The diagonal asks whether each norm is one; off-diagonal entries ask whether different columns are perpendicular. So the single matrix equality $U^TU=I_2$ simultaneously tests normalization and mutual orthogonality. If a column has length two, its diagonal entry is **four**, not two. A student who puts the norms themselves on the diagonal is forgetting that matrix multiplication produces dot products.

Notice the dimensions before multiplying. If $U$ has five rows and two columns, then $U^TU$ is $2\times2$. It can equal $I_2$ because two independent unit directions fit in five dimensions. By contrast, $UU^T$ is $5\times5$ but has rank at most two, so it cannot equal $I_5$. The rectangular matrix is an **isometry from $\R^2$ into its two-dimensional column space in $\R^5$**, not an invertible map between five-dimensional spaces. That is why $U^T$ is a left inverse, $U^TU=I_2$, but not a two-sided inverse. The word "orthogonal matrix" is sometimes reserved for the **square** case; "matrix with orthonormal columns" is safer for rectangles.

### Length preservation and a useful inequality

If $U$ has orthonormal columns, use associativity to find $\|Ux\|^2=(Ux)^T(Ux)=x^TU^TUx=x^TIx=x^Tx=\|x\|^2$. Because lengths are nonnegative, $\|Ux\|=\|x\|$. The same one-line calculation gives $(Ux)\cdot(Uy)=x\cdot y$. These are not magical geometric properties: they follow directly from $U^TU=I$. When $U$ is square, multiplying any vector by $U$ rotates or reflects the coordinate geometry without distorting lengths. In two dimensions, the familiar $90^\circ$ rotation $\begin{bmatrix}0&-1\\1&0\end{bmatrix}$ has perpendicular unit columns, and its inverse is its transpose. Unlike a general matrix, its inverse requires no elimination.

With an orthonormal set $q_1,\ldots,q_p$, the sum of the squared dot-product coordinates cannot exceed $\|y\|^2$: $\sum_j(y\cdot q_j)^2\le\|y\|^2$. Why? In §6.3 the projection has squared length $\sum_j(y\cdot q_j)^2$, and the perpendicular leftover has nonnegative squared length. If $y$ lies entirely in the span, equality holds. This observation can be used as an error check **even before** computing the full projection: if your reported orthonormal weights have squared sum greater than $\|y\|^2$, at least one dot product is wrong. A basis calculation can therefore be checked using length, not just coordinate reconstruction.

### Written-test ordering

When asked to show that a set is an orthogonal basis, present the evidence in this order: all pairwise dot products are zero; none of the vectors is zero; therefore the collection is independent; finally explain why it spans the requested subspace. If the problem says it is already a spanning set, the last step is immediate. If it claims a basis of the whole of $\R^n$, count the vectors: exactly $n$ nonzero orthogonal vectors in $\R^n$ give a basis. State the theorem by name instead of performing redundant row reduction. If the task asks for **orthonormal**, compute squared lengths as a separate line, normalize, and optionally recheck the resulting diagonals of $U^TU$.



### A three-line matrix solution for orthonormal coordinates

When the columns of $U$ form an orthonormal basis for $W$ and $y\in W$, the coefficient vector is simply $c=U^Ty$. To prove it, start from $Uc=y$, left-multiply by $U^T$, and obtain $U^TUc=U^Ty$. Because $U^TU=I$, the left side simplifies to $c$. Notice why this argument does **not** require inverting $U$: its columns may be fewer than its rows, so $U$ may be rectangular, but $U^T$ still acts as a left inverse on the column space. This is the matrix version of taking one dot product for each basis vector.

If $y$ is not in $W$, you cannot solve $Uc=y$ exactly, but $U^Ty$ is still a meaningful vector of coefficients. Reconstructing with $UU^Ty$ keeps only the part of $y$ that the given basis can represent. For a concrete check, $U=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$ and $y=(7,-2,5)^T$ give $c=(7,-2)^T$ and $Uc=(7,-2,0)^T$. The missing third component is not a failure of the coefficient computation: it lies outside the two-dimensional column space. This single example explains why the same expression $U^Ty$ appears in both **orthogonal coordinates** and **projection**.

### How the number of vectors constrains the answer

A set of four pairwise perpendicular nonzero vectors in $\R^3$ is impossible. The independence theorem would imply four independent vectors in a three-dimensional space, contradicting dimension. If a problem presents four alleged nonzero orthogonal vectors in $\R^3$, at least one claim must be wrong. You can often reject the set without checking every pair: for instance, if a displayed vector is zero, the nonzero condition fails; otherwise an assumed set of four would already contradict dimension. The maximum size of a nonzero orthogonal set in $\R^n$ is $n$.

Orthogonality is stronger than independence, not the same thing. The vectors $(1,0)$ and $(1,1)$ are independent in $\R^2$ but not perpendicular because their dot product is one. An independent set can become orthogonal through Gram–Schmidt, but multiplying each original vector by a different scalar does **not** fix its nonzero dot product; scaling changes a nonzero dot by the product of the scalars. Normalization changes lengths, not angles. This explains why "just normalize the basis" is not a substitute for orthogonalization in §6.4.



### How to recognize an incorrect coordinate answer quickly

When a problem gives an orthogonal basis and asks for weights, reconstruct $y$ from the proposed weights. The reconstructed vector must equal the original in **every** component. This takes one multiplication for each coefficient, but it is a strong check because an incorrectly omitted squared-norm denominator often changes several components. If the reconstruction fails, inspect each coefficient's dot numerator and denominator separately. If it succeeds, orthogonal independence guarantees no second, different weight list could represent the same $y$. For a basis that is merely orthogonal, keep the fraction $(y\cdot u_j)/(u_j\cdot u_j)$ displayed before simplifying. For an orthonormal basis, state explicitly why the denominator equals one. Those small written details are how you justify using the shortcut rather than a linear-system method.


:::callout-pitfall[§6.2: Pairwise does not mean pairwise-plus-self zero]
For orthogonal vectors, off-diagonal dots are zero; the diagonal $u_i\cdot u_i$ is **positive**, not zero. Test every distinct pair when there are three or more vectors. Do not infer a basis for all of $\R^n$ from a shorter independent set. Do not write $U^{-1}=U^T$ unless $U$ is **square**; the rectangular identity you may use is $U^TU=I$. And do not use weights $y\cdot u_i$ without dividing by $u_i\cdot u_i$ unless each basis vector is unit length.
:::

:::problem[Problem 6.7 — Orthogonal set decision]{difficulty=easy}
Is $\{(1,-1,0)^T,(1,1,1)^T,(-1,-1,2)^T\}$ an orthogonal set?

::::solution[Solution]
**Answer:** yes.

1. An orthogonal set requires the dot product of every pair of distinct vectors to vanish. There are $\binom32=3$ pairs to test.
2. First and second: $(1,-1,0)\cdot(1,1,1)=1(1)+(-1)(1)+0(1)=1-1+0=0$.
3. First and third: $(1,-1,0)\cdot(-1,-1,2)=1(-1)+(-1)(-1)+0(2)=-1+1+0=0$.
4. Second and third: $(1,1,1)\cdot(-1,-1,2)=1(-1)+1(-1)+1(2)=-1-1+2=0$. All vectors are nonzero, so the displayed set is orthogonal.
**Check:** All three pairwise dot products equal $0$, which exhausts the pairwise test.
::::

:::

:::problem[Problem 6.8 — Read an orthonormal coefficient]{difficulty=easy}
An orthonormal basis satisfies $y=3u_1-2u_2+5u_3$. Find $y\cdot u_2$.

::::solution[Solution]
**Answer:** $-2$.

1. Take the dot product of the given expansion with $u_2$ on both sides: $y\cdot u_2=(3u_1-2u_2+5u_3)\cdot u_2$.
2. Distribute the dot product: $y\cdot u_2=3(u_1\cdot u_2)-2(u_2\cdot u_2)+5(u_3\cdot u_2)$.
3. Orthonormal means distinct vectors are perpendicular and each vector has norm one. Thus $u_1\cdot u_2=0$, $u_2\cdot u_2=1$, and $u_3\cdot u_2=0$.
4. Substitute and simplify: $3(0)-2(1)+5(0)=0-2+0=-2$.
**Check:** The coefficient of $u_2$ in an orthonormal expansion equals $y\cdot u_2$, matching the given coefficient $-2$.
::::

:::

:::problem[Problem 6.9 — Orthogonal coordinates]{difficulty=standard}
For $u_1=(1,1)^T$, $u_2=(1,-1)^T$, express $y=(6,2)^T$ as $c_1u_1+c_2u_2$.

::::solution[Solution]
**Answer:** $y=4u_1+2u_2$.

1. First confirm the two generators are orthogonal: $u_1\cdot u_2=(1)(1)+(1)(-1)=1-1=0$.
2. For an orthogonal basis, calculate each coefficient using $c_i=(y\cdot u_i)/(u_i\cdot u_i)$.
3. The first numerator is $y\cdot u_1=6(1)+2(1)=8$; its denominator is $u_1\cdot u_1=1^2+1^2=2$. Hence $c_1=8/2=4$.
4. The second numerator is $y\cdot u_2=6(1)+2(-1)=6-2=4$; its denominator is $1^2+(-1)^2=2$. Thus $c_2=4/2=2$.
**Check:** $4u_1+2u_2=(4,4)^T+(2,-2)^T=(6,2)^T=y$.
::::

:::

:::problem[Problem 6.10 — Rectangular column test]{difficulty=standard}
Let $U=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$. Find $U^TU$, $UU^T$, and state which one is an identity.

::::solution[Solution]
**Answer:** $U^TU=I_2$ but $UU^T=\operatorname{diag}(1,1,0)\ne I_3$.

1. The two columns of $U$ are $u_1=(1,0,0)^T$ and $u_2=(0,1,0)^T$. Because $U$ is $3\times2$, $U^TU$ must be $2\times2$.
2. Compute its four dot products: $u_1\cdot u_1=1$, $u_1\cdot u_2=0$, $u_2\cdot u_1=0$, and $u_2\cdot u_2=1$. Hence $U^TU=\begin{bmatrix}1&0\\0&1\end{bmatrix}=I_2$.
3. Reverse the order: $UU^T=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}\begin{bmatrix}1&0&0\\0&1&0\end{bmatrix}=\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}$.
4. The final diagonal entry is $0$ rather than $1$, so this $3\times3$ product is not $I_3$.
**Check:** $U^TU(1,0)^T=(1,0)^T$, but $UU^T(0,0,1)^T=(0,0,0)^T$, confirming only the first product is an identity.
::::

:::

:::problem[Problem 6.11 — Normalize an orthogonal basis]{difficulty=standard}
Normalize $u_1=(3,0,0)^T$ and $u_2=(0,4,0)^T$ to obtain an orthonormal basis of their span.

::::solution[Solution]
**Answer:** $q_1=(1,0,0)^T$ and $q_2=(0,1,0)^T$.

1. Use the normalization rule $q_i=u_i/\|u_i\|$. The given vectors are already perpendicular because $u_1\cdot u_2=3(0)+0(4)+0(0)=0$.
2. Compute $\|u_1\|=\sqrt{3^2+0^2+0^2}=\sqrt9=3$, so $q_1=(3,0,0)^T/3=(1,0,0)^T$.
3. Compute $\|u_2\|=\sqrt{0^2+4^2+0^2}=\sqrt{16}=4$, so $q_2=(0,4,0)^T/4=(0,1,0)^T$.
4. Scaling by nonzero numbers does not change a span, so $q_1,q_2$ still span the original $xy$-plane.
**Check:** $q_1\cdot q_1=1$, $q_2\cdot q_2=1$, and $q_1\cdot q_2=0$; the set is orthonormal.
::::

:::

:::problem[Problem 6.12 — Orthogonality versus independence]{difficulty=challenge}
True or false, with reason: (a) every orthogonal set is independent; (b) three nonzero orthogonal vectors in $\R^3$ form a basis of $\R^3$; (c) if $U^TU=I$ for a $3\times2$ matrix, then $UU^T=I_3$.

::::solution[Solution]
**Answer:** F, T, F.

1. (a) A set containing $0$ may be pairwise orthogonal yet dependent; the theorem needs *nonzero*.

2. (b) Nonzero pairwise orthogonal means independent, and three independent vectors in $\R^3$ are a basis.

3. (c) The rank of $UU^T$ is at most two and cannot equal the rank-three matrix $I_3$.
::::

:::

## 6.3 Orthogonal Projections

A vector outside a line cannot be represented exactly by a multiple of the line's direction. But one multiple is closer than all others. Imagine dropping a perpendicular from the tip of a vector to the line. Its foot is the **orthogonal projection**. The same idea works when the target is a plane or any subspace: the projection is the part of the vector *inside* the subspace, and the difference is the part perpendicular to it. Both parts are valuable. The first is your approximation; the second measures how inaccurate the approximation is.

The most important distinction in this section is between a **line projection** and a **subspace projection**. You may project onto one nonzero direction using one dot-product ratio. To project onto a plane, you need either an **orthogonal basis of the plane** or another valid method, such as subtracting the projection onto its perpendicular normal. Adding projections along *nonorthogonal* spanning directions is wrong because those directions overlap and double-count part of the vector.

:::definition[Definition 6.7 — Projection onto a Line]
For $u\ne0$, the projection of $y$ onto the line $L=\span\{u\}$ is $\proj_L y=\frac{y\cdot u}{u\cdot u}u$. The **orthogonal error vector** is $z=y-\proj_L y$. By construction $z\cdot u=0$; the projection is parallel to $u$, but $z$ is not generally parallel to $y$.
:::

:::theorem[Theorem 6.6 — Orthogonal Decomposition Theorem]
For each subspace $W\subseteq\R^n$ and each $y\in\R^n$, there is exactly one pair $\hat y\in W$ and $z\in W^\perp$ with $y=\hat y+z$. If $u_1,\ldots,u_p$ is an **orthogonal basis** for $W$, then $\hat y=\proj_Wy=\sum_{j=1}^{p}\frac{y\cdot u_j}{u_j\cdot u_j}u_j$ and $z=y-\hat y$.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="Line projection and perpendicular error: the foot is at (240,98), the vector tip is (195,23), so the two drawn directions have dot product zero">
<line class="fig-axis" x1="36" y1="208" x2="388" y2="208"/>
<line class="fig-axis" x1="80" y1="227" x2="80" y2="18"/>
<path class="fig-curve" d="M 60 206 L 360 26"/>
<path class="fig-arrow" d="M 80 194 L 240 98"/>
<path class="fig-curve-alt" d="M 80 194 L 195 23"/>
<path class="fig-guide" d="M 240 98 L 195 23"/>
<path class="fig-guide" d="M 229 105 L 222 94 L 233 87"/>
<circle class="fig-point" cx="80" cy="194" r="4"/>
<circle class="fig-point" cx="240" cy="98" r="4"/>
<circle class="fig-point" cx="195" cy="23" r="4"/>
<text class="fig-label" x="201" y="20">y</text>
<text class="fig-label" x="249" y="106">ŷ</text>
<text class="fig-label" x="213" y="61">z</text>
<text class="fig-label" x="343" y="38">L</text>
<text class="fig-label" x="65" y="205">0</text>
</svg>
<figcaption>The line projection $\hat y$ is the foot of the perpendicular from $y$ to $L$; the remaining vector $z=y-\hat y$ is perpendicular to $L$, so $\|z\|$ is the distance.</figcaption>
</figure>

:::theorem[Theorem 6.7 — Best Approximation Theorem]
The orthogonal projection $\hat y=\proj_Wy$ is the unique point in $W$ minimizing $\|y-v\|$ over all $v\in W$. The distance from the vector to the subspace is $\operatorname{dist}(y,W)=\|y-\proj_Wy\|$. For any other $v\in W$, the perpendicular pieces give $\|y-v\|^2=\|y-\hat y\|^2+\|\hat y-v\|^2$.
:::

:::proof[Why the closest point must have a perpendicular error]
Write $y=\hat y+z$ with $z\perp W$. Every candidate point $v\in W$ gives $y-v=z+(\hat y-v)$. The second summand lies in $W$ because subspaces are closed under subtraction, and the first lies in $W^\perp$. Hence the summands are perpendicular. Pythagoras says $\|y-v\|^2=\|z\|^2+\|\hat y-v\|^2$. The second term is nonnegative and becomes zero only when $v=\hat y$. So no other point of $W$ can be closer. This short argument is also the entire geometric reason least squares works in §6.5.
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="Schematized plane W with y above it, its projection y hat on the plane and orthogonal residual z">
<path class="fig-fill" d="M 55 173 L 212 225 L 379 137 L 220 80 Z"/>
<path class="fig-guide" d="M 55 173 L 212 225 L 379 137"/>
<path class="fig-guide" d="M 55 173 L 220 80 L 379 137"/>
<path class="fig-curve" d="M 200 172 L 282 130"/>
<path class="fig-curve-alt" d="M 200 172 L 282 32"/>
<path class="fig-arrow" d="M 282 130 L 282 32"/>
<path class="fig-guide" d="M 270 124 L 270 113 L 282 113"/>
<circle class="fig-point" cx="200" cy="172" r="4"/>
<circle class="fig-point" cx="282" cy="130" r="4"/>
<circle class="fig-point" cx="282" cy="32" r="4"/>
<text class="fig-label" x="292" y="34">y</text>
<text class="fig-label" x="293" y="141">ŷ</text>
<text class="fig-label" x="292" y="79">z</text>
<text class="fig-label" x="112" y="172">W</text>
<text class="fig-label" x="184" y="190">0</text>
</svg>
<figcaption>In a plane $W$, the closest point $\hat y=\proj_Wy$ lies in the plane while the error $z=y-\hat y$ is perpendicular to **every** vector of the plane, not merely one chosen direction.</figcaption>
</figure>

### The projection calculation in seven handwriting lines

First, **read the target**. Is it a line with one generator, a plane specified by orthogonal generators, a plane given by a normal equation, or the column space of a matrix? Second, **verify the basis** if you plan to sum one-dimensional projections. Third, list the numerator $y\cdot u_j$ and denominator $u_j\cdot u_j$ separately for each basis vector. Fourth, reduce the coefficient fractions before multiplying; this prevents large numbers. Fifth, add the scaled vectors coordinate by coordinate. Sixth, subtract from $y$ to obtain the error. Seventh, verify that error dots to zero with **every** spanning vector and calculate its norm only if distance is asked.

A subspace can also be given as a normal equation $n\cdot x=0$. Then the orthogonal error lies on the line through $n$, so $\operatorname{dist}(y,W)=|y\cdot n|/\|n\|$, and the projected point is $y-[(y\cdot n)/(n\cdot n)]n$. This is often faster than finding two perpendicular directions inside a plane. The sign of $y\cdot n$ locates the side of the plane; distance requires an absolute value because a distance cannot be negative.

:::example[Example 6.9 — Projection onto a line]
Project $y=(7,6)^T$ onto $u=(4,2)^T$, and give its perpendicular error.

::::answer[Answer]
**Answer:** $\proj_u y=(8,4)^T$ and $z=(-1,2)^T$.

1. Compute the numerator $y\cdot u=7(4)+6(2)=28+12=40$ and denominator $u\cdot u=4^2+2^2=16+4=20$.

2. The coefficient is $40/20=2$.

3. Multiply **the whole vector**: $2(4,2)=(8,4)$.

4. Subtract: $(7,6)-(8,4)=(-1,2)$.

5. Finally $z\cdot u=(-1)(4)+(2)(2)=-4+4=0$.

6. This is a useful example because the projected point has first coordinate **larger** than the original; projection is not component-by-component clipping.
::::

:::

:::example[Example 6.10 — Project onto an orthogonal plane]
Let $W=\span\{u_1,u_2\}$, where $u_1=(2,5,-1)^T$, $u_2=(-2,1,1)^T$, and $y=(1,2,3)^T$. Find $\proj_Wy$ and the distance to $W$.

::::answer[Answer]
**Answer:** $\hat y=(-2/5,2,1/5)^T$, $z=(7/5,0,14/5)^T$, and $\operatorname{dist}(y,W)=7/\sqrt5$.

1. First verify the basis directions: $u_1\cdot u_2=2(-2)+5(1)+(-1)(1)=-4+5-1=0$.

2. Then $y\cdot u_1=2+10-3=9$ and $u_1\cdot u_1=4+25+1=30$, giving $c_1=9/30=3/10$.

3. Likewise $y\cdot u_2=-2+2+3=3$ and $u_2\cdot u_2=4+1+1=6$, giving $c_2=1/2$.

4. Add the two pieces: $(3/10)(2,5,-1)+(1/2)(-2,1,1)=(3/5,3/2,-3/10)+(-1,1/2,1/2)=(-2/5,2,1/5)$.

5. Subtract to get $z=(1+2/5,2-2,3-1/5)=(7/5,0,14/5)$.

6. Check $z\cdot u_1=14/5-14/5=0$ and $z\cdot u_2=-14/5+14/5=0$.

7. Its norm is $\sqrt{49/25+196/25}=\sqrt{245}/5=7/\sqrt5$.

8. Fractions are more reliable than decimals on a written test.
::::

:::

:::example[Example 6.11 — Find the distance to a plane from its normal]
Find the distance from $y=(3,1,5)^T$ to $W=\{x:x_1-x_2+2x_3=0\}$.

::::answer[Answer]
**Answer:** $\operatorname{dist}(y,W)=2\sqrt6$.

1. The equation has normal $n=(1,-1,2)^T$, so $W^\perp=\span\{n\}$.

2. Dot $y\cdot n=3-1+10=12$.

3. The normal's squared length is $n\cdot n=1+1+4=6$.

4. Its norm is $\sqrt6$.

5. Distance is the magnitude of the perpendicular component: $|12|/\sqrt6=12/\sqrt6=(12\sqrt6)/6=2\sqrt6$.

6. To find the projected point as a cross-check, subtract $(12/6)n=2(1,-1,2)$ from $y$ and get $(1,3,1)$.

7. Indeed $1-3+2(1)=0$, so the point is in the plane.

8. The original notes found nonorthogonal plane generators; the normal method avoids an unnecessary Gram–Schmidt calculation.
::::

:::

:::example[Example 6.12 — Projection matrix from orthonormal columns]
Let $U=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$ and $y=(2,-3,4)^T$. Compute $P=UU^T$, $Py$, and $y-Py$.

::::answer[Answer]
**Answer:** $P=\operatorname{diag}(1,1,0)$, $Py=(2,-3,0)^T$, and $y-Py=(0,0,4)^T$.

1. Because $U^TU=I_2$, its columns form an orthonormal basis for the $xy$-plane.

2. Form the product: $UU^T=\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}$.

3. Multiply by $(2,-3,4)$: the first two entries survive, while the third becomes zero.

4. Subtracting gives $(0,0,4)$, which is perpendicular to both $(1,0,0)$ and $(0,1,0)$.

5. Reapplying $P$ changes nothing: $P(Py)=Py$, hence $P^2=P$.

6. A projection matrix need not be invertible; indeed this one maps the entire $z$-axis to zero.
::::

:::


### Deriving the projection coefficient from a right angle

A memorized formula is easy to misapply, so derive it once. We want the point $cu$ on the line through $u$ closest to $y$. The error is $z=y-cu$. For the best approximation the error must be perpendicular to the line, so $(y-cu)\cdot u=0$. Distribute: $y\cdot u-c(u\cdot u)=0$. Since $u\ne0$, its squared length $u\cdot u$ is positive, and $c=(y\cdot u)/(u\cdot u)$. Substitute into $cu$ to obtain the projection. This derivation exposes three common wrong answers: using $\|u\|$ rather than $u\cdot u$ in the denominator; reporting only $c$ when the question asks for the **vector**; and using $c$ without multiplying by the entire $u$. The coefficient $c$ is dimensionless in this context, while the projected vector has the same number of components as $y$.

Projections can have a negative coefficient. If $y$ points largely opposite the chosen basis direction $u$, then $y\cdot u$ is negative and $cu$ points against $u$. This is not an error; the **line** spanned by $u$ includes both positive and negative multiples. Also, rescaling $u$ does not change the projected vector. If you replace $u$ by $3u$, the new coefficient is $(y\cdot3u)/((3u)\cdot(3u))=3(y\cdot u)/(9u\cdot u)$, so multiplying by the new $3u$ cancels all the extra factors. This is useful when a problem gives a direction as $(1/2,-1/2,1)$: multiply it by two first to avoid fractions in the dot products. The resulting line and projection are identical.

### The residual identifies the error, not a second fitted vector

Draw the vector decomposition $y=\hat y+z$. The first component lies in $W$; the second lies in $W^\perp$. Because they are perpendicular, Pythagoras gives $\|y\|^2=\|\hat y\|^2+\|z\|^2$. For an exact membership test, if $z=0$ then $y\in W$ and projecting changes nothing. If $\hat y=0$, then $y\in W^\perp$, and its nearest point in $W$ is zero. Those are two genuinely different special cases. For a nonzero vector outside $W$, the projection generally has a positive length and the error generally has a positive length; neither equals the full length.

The residual also explains why the closest point is **unique**. Suppose two different vectors $w_1,w_2\in W$ were equally closest to $y$ and both had perpendicular errors. Then $y-w_1$ and $y-w_2$ would lie in $W^\perp$, so subtracting gives $w_2-w_1\in W^\perp$. But because $W$ is a subspace, $w_2-w_1\in W$ as well. The only vector belonging to both is zero, forcing $w_1=w_2$. Thus the projection is not one of many equally good points: it is the **single** closest one.

### Projection matrices and the geometry of the two spaces

When columns of $U$ are orthonormal, the formula for the projection is compact: $\hat y=UU^Ty$. First $U^Ty$ computes the dot-product coordinates of $y$ along the columns of $U$. Then multiplying by $U$ converts those coordinates back to a vector in the original ambient space. The matrix $P=UU^T$ therefore describes the projection operation. It has three properties worth recognizing: $P^T=P$ (symmetry), $P^2=P$ (idempotence), and $\Col P=\Col U$ (its outputs land in the intended space). Verify the second using $P^2=UU^TUU^T=U(U^TU)U^T=UIU^T=P$. The complementary projection is $I-P$, since $(I-P)y=y-Py$ is the residual.

What if the spanning columns are independent but **not orthonormal**? Then $UU^T$ is generally not a projection. You can first orthogonalize with Gram–Schmidt and build an appropriate $Q$, or use the formula $P=A(A^TA)^{-1}A^T$ for a full-column-rank $A$. The latter formula is derived from least squares in §6.5: solve the normal equations for the coefficients, then multiply by $A$ to produce the projected point. This is one of the most useful bridges in the chapter. The projection formula for an orthogonal basis and the least-squares normal-equation formula do **exactly the same geometric job**; they differ only in whether you already have perpendicular columns.

### Three plausible-looking wrong distances

If $W$ is a plane $x_1-x_2+2x_3=0$ and $y=(3,1,5)$, a quick normal computation shows the signed component along $n=(1,-1,2)$ is $(y\cdot n)/\|n\|=12/\sqrt6$. The distance is its absolute value $2\sqrt6$. Dividing by $n\cdot n=6$ instead gives the **coefficient** $2$, not the distance. Multiplying the coefficient by $n$ gives an **error vector** $(2,-2,4)$, not the distance. Taking the norm of the *projected point* gives yet another length. In written work, label each object as scalar coefficient, projection vector, error vector, or final nonnegative distance. That simple labeling prevents most answer-shape mistakes.



### A projection is a map that can be tested without knowing the formula

Suppose a problem gives a candidate vector $p$ and asks whether it is $\proj_Wy$. You can establish the answer with two conditions: (1) $p\in W$, and (2) $y-p\perp W$. If both hold, the Orthogonal Decomposition Theorem guarantees $p$ is the unique projection. This is often substantially shorter than recomputing the projection from scratch. To verify membership, express $p$ as a combination of the given spanning vectors or check the defining plane equation. To verify perpendicularity, dot $y-p$ with a spanning set, or check that $A^T(y-p)=0$ when $W=\Col A$.

For instance, let $W=\span\{(1,1)^T\}$, $y=(4,2)^T$, and someone claims the projection is $(3,3)^T$. It is indeed in $W$, since it equals three times $(1,1)$. The residual is $(1,-1)$, whose dot with $(1,1)$ is $1-1=0$. Both conditions pass, so the claimed projection is correct. If the proposed point were $(2,2)$, membership would still pass but the residual $(2,0)$ would have dot product two with the generator and fail. **Membership alone is not enough** to certify closest approximation.

### Projection onto a line through the origin versus a shifted line

All formulas in this chapter apply to **subspaces**, which contain the origin. A line $L=\span\{u\}$ consists of multiples of $u$, so its projection has the form $cu$. A shifted line $p_0+\span\{u\}$ is an affine set rather than a subspace. To project $y$ onto it, first translate by $p_0$, project $y-p_0$ onto the direction $u$, then translate back: $p_0+\proj_u(y-p_0)$. Using $\proj_u y$ without accounting for the shift would land on the wrong line. A standard Chapter 6 exam usually gives subspaces, but recognizing the role of the origin prevents you from applying a familiar formula to a geometrically different object.

Even when the target is a subspace, the choice of basis vectors must not affect the answer. If you use a different **orthogonal basis** of the same $W$, the individual projection terms may change, but their sum is the same unique closest point. If two valid calculations produce different projections for the same $y$ and $W$, one has an arithmetic or orthogonality error. You can detect that disagreement by checking the two-condition certificate rather than trying to compare the basis choices directly.



### Why the diagram's right angle matters more than its slope

A projection diagram must show the error meeting the **target subspace** at a right angle, not merely an attractive triangle. In the line case, all scalar multiples of the generator share the line's direction. If the residual is perpendicular to one nonzero generator, it is perpendicular to every point of the line considered as a direction. In the plane case, checking just one generator does not suffice because the residual might still point along a second independent plane direction. You need two orthogonal tests or one test against a known normal-space description. This is exactly why a good diagram should accompany, not replace, the dot-product verification in the written work.


:::callout-pitfall[§6.3: The danger is projecting onto the wrong directions]
The formula $\sum[(y\cdot u_i)/(u_i\cdot u_i)]u_i$ needs an **orthogonal basis**. Independence alone is not enough. To find distance to a subspace, use the **residual** length, never the projection length. For a plane given by $n\cdot x=0$, $n$ points **out** of the plane, so projecting onto $n$ gives the *error*, and subtracting that gives the *closest point*. Finally, show one perpendicularity check after arithmetic; it is a fast way to catch a bad sign.
:::

:::problem[Problem 6.13 — Projection in four coordinates]{difficulty=easy}
Let $W=\span\{(1,1,0,0)^T,(1,-1,1,1)^T\}$ and $y=(1,0,1,0)^T$. Verify the generators are orthogonal and compute $\proj_Wy$.

::::solution[Solution]
**Answer:** $\hat y=(1,0,1/2,1/2)^T$.

1. Let $u_1=(1,1,0,0)^T$ and $u_2=(1,-1,1,1)^T$. Compute $u_1\cdot u_2=1(1)+1(-1)+0(1)+0(1)=1-1=0$, so the orthogonal-projection formula applies.
2. For $u_1$, calculate $y\cdot u_1=1(1)+0(1)+1(0)+0(0)=1$ and $u_1\cdot u_1=1+1=2$. The coefficient is $1/2$.
3. For $u_2$, calculate $y\cdot u_2=1(1)+0(-1)+1(1)+0(1)=2$ and $u_2\cdot u_2=1+1+1+1=4$. The coefficient is $2/4=1/2$.
4. Add the projections: $\hat y=\tfrac12u_1+\tfrac12u_2=(1/2,1/2,0,0)^T+(1/2,-1/2,1/2,1/2)^T=(1,0,1/2,1/2)^T$.
**Check:** The residual $y-\hat y=(0,0,1/2,-1/2)^T$ has dot products $0$ with $u_1$ and $1/2-1/2=0$ with $u_2$.
::::

:::

:::problem[Problem 6.14 — Distance to a plane]{difficulty=easy}
Find the distance from $y=(3,1,5)^T$ to the plane $x_1-x_2+2x_3=0$.

::::solution[Solution]
**Answer:** $2\sqrt6$.

1. A plane $x_1-x_2+2x_3=0$ has normal vector $n=(1,-1,2)^T$. The distance from $y$ to this plane through the origin is $|y\cdot n|/\|n\|$.
2. Compute the numerator one coordinate at a time: $y\cdot n=3(1)+1(-1)+5(2)=3-1+10=12$.
3. Compute the normal's squared length and length: $\|n\|^2=1^2+(-1)^2+2^2=1+1+4=6$, so $\|n\|=\sqrt6$.
4. Divide and rationalize: $12/\sqrt6=(12\sqrt6)/6=2\sqrt6$. That is the positive distance, not a signed displacement.
5. To locate the closest point, subtract the normal component: $\hat y=y-(12/6)n=(3,1,5)^T-(2,-2,4)^T=(1,3,1)^T$.
**Check:** $1-3+2(1)=0$, so $\hat y$ lies in the plane, and $\|y-\hat y\|=\sqrt{2^2+(-2)^2+4^2}=\sqrt{24}=2\sqrt6$.
::::

:::

:::problem[Problem 6.15 — Projection and residual]{difficulty=standard}
Project $y=(4,1)^T$ onto the line through $u=(1,1)^T$, and state the residual.

::::solution[Solution]
**Answer:** $\hat y=(5/2,5/2)^T$, $z=(3/2,-3/2)^T$.

1. Project onto the one-dimensional span of $u$ using $\hat y=((y\cdot u)/(u\cdot u))u$.
2. Compute $y\cdot u=4(1)+1(1)=5$. Compute $u\cdot u=1^2+1^2=2$, so the projection coefficient is $5/2$.
3. Multiply the entire vector: $\hat y=(5/2)(1,1)^T=(5/2,5/2)^T$.
4. Subtract to obtain the residual: $z=y-\hat y=(4-5/2,1-5/2)^T=(8/2-5/2,2/2-5/2)^T=(3/2,-3/2)^T$.
**Check:** $z\cdot u=(3/2)(1)+(-3/2)(1)=0$, so the residual is perpendicular to the projection line.
::::

:::

:::problem[Problem 6.16 — Projection onto a normal plane]{difficulty=standard}
Find $\proj_W(2,3,1)^T$ where $W=\{x:x_3=0\}$, and give the distance.

::::solution[Solution]
**Answer:** $\hat y=(2,3,0)^T$ and distance $1$.

1. The subspace $W=\{x:x_3=0\}$ is the $xy$-plane, with normal vector $n=(0,0,1)^T$.
2. The component of $y=(2,3,1)^T$ along the normal is $((y\cdot n)/(n\cdot n))n$. Compute $y\cdot n=2(0)+3(0)+1(1)=1$ and $n\cdot n=1$, giving $(0,0,1)^T$.
3. Subtract the normal component: $\hat y=y-(0,0,1)^T=(2-0,3-0,1-1)^T=(2,3,0)^T$.
4. The residual is $z=y-\hat y=(0,0,1)^T$; its length is $\sqrt{0^2+0^2+1^2}=1$.
**Check:** $\hat y$ has third coordinate zero, and $z$ is perpendicular to both $(1,0,0)^T$ and $(0,1,0)^T$.
::::

:::

:::problem[Problem 6.17 — Nonorthogonal basis warning]{difficulty=standard}
Take $u_1=(1,0)^T$ and $u_2=(1,1)^T$. Is $\proj_{\span\{u_1,u_2\}}(0,2)^T$ equal to the sum of the two individual line projections?

::::solution[Solution]
**Answer:** no.

1. Test whether the two given generators are orthogonal: $u_1\cdot u_2=1(1)+0(1)=1\ne0$. Therefore the formula for adding separate line projections does not apply.
2. The vectors are independent because $\det\begin{bmatrix}1&1\\0&1\end{bmatrix}=1\ne0$; hence their span is all of $\mathbb R^2$. The correct projection of $y=(0,2)^T$ onto that span is $y$ itself.
3. Compute its first line projection: $y\cdot u_1=0(1)+2(0)=0$, $u_1\cdot u_1=1$, so $\operatorname{proj}_{u_1}y=0u_1=(0,0)^T$.
4. For the second line, $y\cdot u_2=0(1)+2(1)=2$ and $u_2\cdot u_2=1+1=2$, so $\operatorname{proj}_{u_2}y=(2/2)u_2=(1,1)^T$.
5. Their sum is $(0,0)^T+(1,1)^T=(1,1)^T$, which differs from $(0,2)^T$. Use an orthogonal basis or solve simultaneous projection equations instead.
**Check:** $y=-2u_1+2u_2=(0,2)^T$ lies in the span already; the correct projection error is zero.
::::

:::

:::problem[Problem 6.18 — Projection theorem, true or false]{difficulty=challenge}
Judge (a) the closest point of $W$ to $y$ belongs to $W$; (b) the distance to $W$ equals $\|\proj_Wy\|$; (c) the projection operator satisfies $P^2=P$; (d) $\proj_Wy=0$ if $y\in W^\perp$.

::::solution[Solution]
**Answer:** T, F, T, T.

1. (a) The point is a projection *into* $W$.

2. (b) Distance is $\|y-\proj_Wy\|$; for $W=\{0\}$, projection length is zero although distance can be positive.

3. (c) A point already in $W$ remains fixed by a second projection.

4. (d) Its entire component along $W$ is zero.
::::

:::

## 6.4 The Gram–Schmidt Process and QR Factorization

You may know a basis of a subspace without having any perpendicular directions in it. If you try the easy projection formula with such a basis, it double-counts. **Gram–Schmidt** solves this by changing the basis, without changing the span. Start with one vector. For each following vector, subtract precisely the part that lies in the directions you already have. What remains is new information, perpendicular to all earlier directions. The final vectors make projections simple, while their normalized versions become the columns of a useful matrix $Q$.

One trap must be confronted immediately: Gram–Schmidt is **not** the same as making the input columns independent. You must start with an independent list to obtain the same number of nonzero orthogonal outputs. If a new input vector already belongs to the earlier span, subtracting its projection leaves zero. That is a discovery of dependence, and zero cannot be normalized. On written tests, work with the unnormalized orthogonal vectors until the end. Normalizing too soon introduces square roots in all subsequent dot products.

:::theorem[Theorem 6.8 — Gram–Schmidt Algorithm]
For linearly independent $x_1,\ldots,x_p$, define $v_1=x_1$, then $v_k=x_k-\sum_{j=1}^{k-1}\frac{x_k\cdot v_j}{v_j\cdot v_j}v_j$ for $k=2,\ldots,p$. The $v_j$ are mutually orthogonal and span the same subspace as the $x_j$. An **orthonormal** basis is $q_j=v_j/\|v_j\|$.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="Geometric Gram-Schmidt triangle showing x2, its projection onto v1, and the perpendicular remainder v2">
<line class="fig-axis" x1="42" y1="204" x2="385" y2="204"/>
<line class="fig-axis" x1="68" y1="223" x2="68" y2="21"/>
<path class="fig-curve" d="M 68 204 L 345 204"/>
<path class="fig-curve-alt" d="M 68 204 L 241 52"/>
<path class="fig-guide" d="M 68 204 L 241 204"/>
<path class="fig-arrow" d="M 241 204 L 241 52"/>
<path class="fig-guide" d="M 229 192 L 229 180 L 241 180"/>
<circle class="fig-point" cx="241" cy="52" r="4"/>
<circle class="fig-point" cx="241" cy="204" r="4"/>
<circle class="fig-point" cx="68" cy="204" r="4"/>
<text class="fig-label" x="350" y="198">v₁</text>
<text class="fig-label" x="244" y="48">x₂</text>
<text class="fig-label" x="246" y="120">v₂</text>
<text class="fig-label" x="138" y="218">proj</text>
<text class="fig-label" x="54" y="221">0</text>
</svg>
<figcaption>Gram–Schmidt takes a new vector $x_2$, subtracts its projection onto the first direction $v_1$, and leaves the perpendicular remainder $v_2=x_2-\proj_{v_1}x_2$.</figcaption>
</figure>

:::proof[Why each subtraction really creates perpendicularity]
For the second vector, dot $v_2=x_2-[(x_2\cdot v_1)/(v_1\cdot v_1)]v_1$ with $v_1$. The terms are $x_2\cdot v_1$ and **the same quantity** with a minus sign, so their sum is zero. At step $k$, dot $v_k$ with any earlier $v_i$. Because the earlier vectors are orthogonal, every other subtracted term is perpendicular to $v_i$ and disappears. The term involving $v_i$ cancels the $x_k\cdot v_i$ part exactly. Each $v_k$ is also $x_k$ minus a combination of earlier inputs, so adding it does not change the span. This is why checking all adjacent dots after each step is not optional on a test.
:::

:::definition[Definition 6.8 — Reduced QR Factorization]
Let $A$ be $m\times n$ with linearly independent columns (so $m\ge n$). **Reduced QR** means $A=QR$, where $Q$ is $m\times n$ with orthonormal columns ($Q^TQ=I_n$), and $R$ is $n\times n$, upper triangular, with **positive diagonal entries** when $q_j$ is chosen in the direction of $v_j$. Compute $R=Q^TA$. Its $j$th diagonal entry is $\|v_j\|$.
:::


### The next result

:::theorem[Theorem 6.9 — QR and a simpler least-squares system]
If $A=QR$ has full column rank, then the unique least-squares solution of $Ax=b$ satisfies $R\hat x=Q^Tb$. Since $R$ is upper triangular, use back-substitution instead of forming $(A^TA)^{-1}$. Algebraically, $A^TA=R^TR$ and $A^Tb=R^TQ^Tb$; because $R^T$ is invertible, cancel it to obtain $R\hat x=Q^Tb$.
:::

### The paper algorithm and error checks

Write $v_1=x_1$. On the next line record $v_1\cdot v_1$; this denominator will be used repeatedly. For $v_2$, compute $x_2\cdot v_1$, write its ratio, then subtract the scaled $v_1$ **coordinate by coordinate**. Check $v_2\cdot v_1=0$. For $v_3$, you need **two** coefficients: $(x_3\cdot v_1)/(v_1\cdot v_1)$ and $(x_3\cdot v_2)/(v_2\cdot v_2)$. Subtract both terms from the **original** $x_3$, not from $v_2$. Check both new dot products. Only then normalize. For QR, arrange the normalized outputs as the columns of $Q$ and calculate $Q^TA$ to produce $R$; verify $QR=A$ by column multiplication.

Because orthogonality is unaffected by multiplying a whole vector by a nonzero scalar, you may rescale intermediate $v_j$ to clear fractions, which can be a major written-test shortcut. If you rescale before assembling $Q$, recompute its norm. The QR convention with positive diagonal is recovered by choosing each $q_j$ to point along the actual remainder $v_j$, not opposite it. There is no requirement that the unnormalized Gram–Schmidt basis itself be unique; its sign and scale can change while the perpendicular subspaces remain the same.

:::example[Example 6.13 — Gram–Schmidt on three vectors]
Apply Gram–Schmidt to $x_1=(1,1,0)^T$, $x_2=(1,0,1)^T$, $x_3=(0,1,1)^T$.

::::answer[Answer]
**Answer:** An orthogonal basis is $v_1=(1,1,0)^T$, $v_2=(1/2,-1/2,1)^T$, and $v_3=(-2/3,2/3,2/3)^T$.

1. Convenient integer-scaled alternatives are $(1,1,0)$, $(1,-1,2)$, $(-1,1,1)$.

2. First $v_1=x_1$ and $v_1\cdot v_1=2$.

3. Next $x_2\cdot v_1=1$, so $v_2=x_2-(1/2)v_1=(1,0,1)-(1/2,1/2,0)=(1/2,-1/2,1)$.

4. Check $v_2\cdot v_1=1/2-1/2=0$ and $v_2\cdot v_2=1/4+1/4+1=3/2$.

5. For the third input, $x_3\cdot v_1=1$ and $x_3\cdot v_2=-1/2+1=1/2$, giving coefficients $1/2$ and $(1/2)/(3/2)=1/3$.

6. Subtract $v_3=(0,1,1)-(1/2)(1,1,0)-(1/3)(1/2,-1/2,1)=(-2/3,2/3,2/3)$.

7. Check $v_3\cdot v_1=-2/3+2/3=0$ and $v_3\cdot v_2=-1/3-1/3+2/3=0$.

8. The third squared norm is $4/9+4/9+4/9=4/3$.
::::

:::

:::example[Example 6.14 — QR of the same matrix]
Find the reduced QR factorization of $A=\begin{bmatrix}1&1&0\\1&0&1\\0&1&1\end{bmatrix}$ using the preceding example.

::::answer[Answer]
**Answer:** $Q=\begin{bmatrix}1/\sqrt2&1/\sqrt6&-1/\sqrt3\\1/\sqrt2&-1/\sqrt6&1/\sqrt3\\0&2/\sqrt6&1/\sqrt3\end{bmatrix}$ and $R=\begin{bmatrix}\sqrt2&1/\sqrt2&1/\sqrt2\\0&\sqrt6/2&1/\sqrt6\\0&0&2/\sqrt3\end{bmatrix}$.

1. The first two unscaled orthogonal remainders from Example 6.13 are $v_1=(1,1,0)$ and $v_2=(1/2,-1/2,1)$, with lengths $\sqrt2$ and $\sqrt{3/2}$.

2. The third is $(-2/3,2/3,2/3)$, with length $2/\sqrt3$.

3. Dividing each by its norm yields $q_1=(1,1,0)/\sqrt2$, $q_2=(1,-1,2)/\sqrt6$, and $q_3=(-1,1,1)/\sqrt3$.

4. Form $R=Q^TA$: its first row comes from dotting $q_1$ with columns $x_1,x_2,x_3$, yielding $(\sqrt2,1/\sqrt2,1/\sqrt2)$.

5. The second row yields $(0,\sqrt6/2,1/\sqrt6)$.

6. The last yields $(0,0,2/\sqrt3)$.

7. The lower triangular entries vanish because each $q_i$ is perpendicular to all previous columns.

8. Check the first column: $Q(\sqrt2,0,0)^T=(1,1,0)^T$; the other columns follow the same reconstruction.
::::

:::

:::example[Example 6.15 — Two-vector Gram–Schmidt without radicals]
Apply Gram–Schmidt to $x_1=(2,0)^T$ and $x_2=(1,3)^T$, then normalize.

::::answer[Answer]
**Answer:** $v_1=(2,0)^T$, $v_2=(0,3)^T$; the orthonormal basis is $q_1=(1,0)^T$, $q_2=(0,1)^T$.

1. Compute $x_2\cdot v_1=2$ and $v_1\cdot v_1=4$.

2. Therefore $v_2=(1,3)-(2/4)(2,0)=(1,3)-(1,0)=(0,3)$.

3. Dot check: $(2,0)\cdot(0,3)=0$.

4. Lengths are $2$ and $3$, so normalization simply divides each by its length.

5. In this example $R=\begin{bmatrix}2&1\\0&3\end{bmatrix}$ if the two input vectors are columns of $A$, and $Q=I_2$.

6. The fact that $R=A$ here is a special consequence of $A$ already being upper triangular with positive diagonal.
::::

:::

:::example[Example 6.16 — Detect a dependent input]
Apply the first two Gram–Schmidt steps to $x_1=(1,2)^T$, $x_2=(2,4)^T$. Explain why a two-column reduced QR with two independent columns is impossible.

::::answer[Answer]
**Answer:** $v_2=(0,0)^T$ and $\rank A=1$.

1. Set $v_1=x_1=(1,2)$.

2. Its squared norm is $1^2+2^2=5$.

3. The numerator $x_2\cdot v_1=2+8=10$.

4. Hence $v_2=(2,4)-(10/5)(1,2)=(2,4)-(2,4)=(0,0)$.

5. The zero remainder means $x_2$ adds no direction: $x_2=2x_1$.

6. You cannot compute $q_2=v_2/\|v_2\|$, because that divides by zero.

7. A rank-revealing or one-column QR is possible, but the full-column-rank formula of this section cannot produce two orthonormal directions spanning a one-dimensional line.
::::

:::


### Gram–Schmidt as a repeated projection problem

The first time you meet Gram–Schmidt, the third vector formula looks much longer than the second. The underlying step is identical. For $x_2$, remove the component that lies along $v_1$. For $x_3$, remove the component in the **whole plane** spanned by $v_1,v_2$. Because $v_1$ and $v_2$ are already perpendicular, the plane projection is the sum of two line projections. This produces $v_3=x_3-\proj_{\span\{v_1,v_2\}}x_3$. For $x_k$, subtract the projection on the entire subspace already built. The result is the part of the new vector that earlier directions cannot explain. This is why Gram–Schmidt is also an algorithm for detecting dependence: if there is no unexplained part, the remainder is zero.

There is an algebraic reason the original span is not lost. For step two, $v_2=x_2-cv_1$, so $v_2$ is in the span of $x_1,x_2$. Conversely, $x_2=v_2+cv_1$, so the original second vector is in the span of $v_1,v_2$. Thus the two spans are equal. At later steps the same reasoning holds, because you subtract only combinations of the preceding vectors. State both directions if a proof asks why Gram–Schmidt preserves the span. Merely stating that the output vectors are perpendicular is not enough to show that they still span the desired space.

### How to avoid terrifying fractions

Suppose the second remainder is $v_2=(1/2,-1/2,1)$. Instead of carrying halves everywhere, replace it by $w_2=2v_2=(1,-1,2)$. This does not change perpendicularity to $v_1$ or the span. The projection of any later vector $x$ onto the line through $w_2$ is $(x\cdot w_2)/(w_2\cdot w_2)\,w_2$, which is identical to the projection using $v_2$ because the scale cancels. Clear denominators only by rescaling the **whole vector**. It would be incorrect to clear one component but not the others. For a no-calculator exam, small-integer scaled remainders can shorten every subsequent dot product and make errors more visible.

The normalization step sometimes leaves radicals. In the three-vector example of this chapter, $w_1=(1,1,0)$, $w_2=(1,-1,2)$, $w_3=(-1,1,1)$ have squared norms $2,6,3$. Therefore $q_1=w_1/\sqrt2$, $q_2=w_2/\sqrt6$, $q_3=w_3/\sqrt3$. You do not need to rationalize every component separately; leaving the scalar $1/\sqrt6$ outside the whole column vector is exact and easier to read. If you check $q_2\cdot q_2=(1+1+4)/6=1$, the normalization is correct. If you find $q_2\cdot q_3$ nonzero, revisit the subtraction before assuming the radical is the problem.

### Where the upper triangular $R$ comes from

Let $A=[x_1\ x_2\ x_3]$ and $Q=[q_1\ q_2\ q_3]$ after Gram–Schmidt. By construction, $x_1$ lies in the span of $q_1$ alone. Thus $q_2\cdot x_1=q_3\cdot x_1=0$. Similarly, $x_2$ lies in the span of $q_1,q_2$, so $q_3\cdot x_2=0$. In $R=Q^TA$, those are exactly the entries **below** the diagonal, making $R$ upper triangular. The diagonal terms are the lengths of the successive unnormalized remainders, so they are positive under the standard choice of $q_i$. This is a geometric explanation of the triangular pattern, not merely a fact to memorize.

Notice what QR does **not** do. The equality $A=QR$ is not a row reduction; it rewrites the same linear map as an orthonormal-column map followed by an upper triangular map. If $A$ has full column rank and $Q$ is tall, $Q^TA$ produces its $R$, but $AQ^T$ does not generally make sense dimensionally. Always write the sizes: $A$ is $m\times n$, $Q$ is $m\times n$, $R$ is $n\times n$, so $QR$ is $m\times n$ and $Q^TA$ is $n\times n$. Size checks are an easy way to catch invalid factor orders.

### When to use QR rather than normal equations

A problem that explicitly supplies $Q$ and $R$ is telling you to use $R\hat x=Q^Tb$. Dot $b$ with the orthonormal columns of $Q$, then back-substitute in the upper triangular matrix. A problem that supplies only a tiny integer $A$ may be quicker through $A^TA\hat x=A^Tb$, unless the columns are easy to orthogonalize. Both methods produce the same least-squares fitted vector. For computer implementations, QR is usually preferable to forming normal equations because $A^TA$ can magnify numerical conditioning problems. That computational consideration is not a reason to reject exact normal equations on a written MA 3113 test: the exam matrices are intentionally small, and correct method selection depends on what the question provides.



### Write the $R$ entries in a pattern you can check

For reduced QR, the entry $r_{ij}$ is $q_i\cdot x_j$. It is zero when $i>j$, because a later orthonormal direction is perpendicular to all earlier input columns. For the first column $x_1$, the only nonzero $R$ entry is $r_{11}=\|x_1\|$. For the second column, the first row records how much $x_2$ lies along $q_1$, while $r_{22}$ is the length of the remaining part. For a three-column matrix, the third column of $R$ records three weights: components along $q_1$ and $q_2$, followed by the new perpendicular remainder length along $q_3$. Reading $R$ this way makes the upper-triangular shape inevitable rather than mysterious.

One can reconstruct individual input columns without multiplying the whole matrices. The equality $A=QR$ says $x_1=r_{11}q_1$, $x_2=r_{12}q_1+r_{22}q_2$, and $x_3=r_{13}q_1+r_{23}q_2+r_{33}q_3$. These are merely the Gram–Schmidt decompositions read backward. If your $R$ has a nonzero $r_{31}$, it would claim the first input vector contains a component along a direction that was created only from the third input vector, contradicting the construction. This is a faster diagnostic than recalculating every entry.

### A shortcut that is allowed and one that is not

It is legitimate to clear fractions in an intermediate **orthogonal** vector because a nonzero scalar multiple has the same direction. It is **not** legitimate to replace a basis vector by an arbitrary sum of the others after you have used the perpendicularity formula, because such a change may destroy orthogonality. Example: $(1,0)$ and $(0,1)$ are orthogonal; replacing the first with $(1,1)$ makes its dot with $(0,1)$ equal one. If you choose a different orthogonal basis later, verify it again before projecting onto it.

In a two-column QR problem, do not spend time computing a three-column full orthogonal matrix unless the question explicitly asks for a full $m\times m$ $Q$. **Reduced QR** has $m\times n$ $Q$ and $n\times n$ $R$, and is sufficient to represent the given $m\times n$ matrix when it has independent columns. This distinction saves both pencil work and space. A common trap is to manufacture extra perpendicular columns, then accidentally report a square $R$ of the wrong dimension.



### Three things a complete QR answer should contain

A full credit QR response includes the **matrix $Q$**, the **matrix $R$**, and an explanation that the columns of $Q$ are orthonormal. The orthogonal remainders alone are not yet $Q$; their lengths still need to be made one. Reporting $R=Q^TA$ without carrying out its entries may be incomplete if the problem specifically asks to find the factorization. After computing, make one direct reconstruction check using $QR$, or at least demonstrate that its columns equal the original columns of $A$. The two conditions $Q^TQ=I$ and $QR=A$ are more informative together than either one alone: the first checks geometry, while the second checks that you did not change the original matrix.


:::callout-pitfall[§6.4: Gram–Schmidt needs all earlier directions]
When building $v_3$, subtract the projection onto **both** $v_1$ and $v_2$, not just onto $v_2$. The denominators are squared norms $v_j\cdot v_j$, not norms $\|v_j\|$. Never normalize a zero remainder. In QR, $Q^TQ=I$ must be checked, but $QQ^T=I$ is not generally true for tall $Q$. The product $Q^TA$ is **upper** triangular: if you find a lower-left nonzero entry, revisit your dot products before attempting the next step.
:::

:::problem[Problem 6.19 — Gram–Schmidt in a coordinate plane]{difficulty=easy}
Apply Gram–Schmidt to $x_1=(3,0,0)^T$, $x_2=(1,1,0)^T$ and find an orthonormal basis.

::::solution[Solution]
**Answer:** $(1,0,0)^T,(0,1,0)^T$.

1. Gram–Schmidt begins with $v_1=x_1=(3,0,0)^T$. Its squared length is $v_1\cdot v_1=3^2+0^2+0^2=9$.
2. Compute the component of $x_2$ along $v_1$: $x_2\cdot v_1=1(3)+1(0)+0(0)=3$, so its coefficient is $3/9=1/3$.
3. Subtract that component: $v_2=x_2-(1/3)v_1=(1,1,0)^T-(1,0,0)^T=(0,1,0)^T$.
4. Normalize both vectors: $\|v_1\|=\sqrt9=3$, giving $q_1=v_1/3=(1,0,0)^T$; $\|v_2\|=\sqrt1=1$, giving $q_2=v_2=(0,1,0)^T$.
**Check:** $q_1\cdot q_1=q_2\cdot q_2=1$, $q_1\cdot q_2=0$, and both belong to $\span\{x_1,x_2\}$.
::::

:::

:::problem[Problem 6.20 — Gram–Schmidt in four coordinates]{difficulty=challenge}
Apply Gram–Schmidt to $x_1=(1,-1,0,0)^T$, $x_2=(1,0,-1,0)^T$, $x_3=(1,0,0,-1)^T$.

::::solution[Solution]
**Answer:** $v_1=(1,-1,0,0)^T$, $v_2=(1/2,1/2,-1,0)^T$, $v_3=(1/3,1/3,1/3,-1)^T$.

1. Gram–Schmidt first sets $v_1=x_1=(1,-1,0,0)^T$. Its squared norm is $v_1\cdot v_1=1^2+(-1)^2=2$.
2. Find the projection coefficient for $x_2$: $x_2\cdot v_1=1(1)+0(-1)+(-1)(0)+0(0)=1$, giving $1/2$.
3. Subtract: $v_2=x_2-\tfrac12v_1=(1,0,-1,0)^T-(1/2,-1/2,0,0)^T=(1/2,1/2,-1,0)^T$.
4. Calculate $v_2\cdot v_2=(1/2)^2+(1/2)^2+(-1)^2=1/4+1/4+1=3/2$.
5. Project $x_3$ onto $v_1$: $(x_3\cdot v_1)/(v_1\cdot v_1)=(1(1)+0(-1)+0(0)+(-1)(0))/2=1/2$.
6. Project $x_3$ onto $v_2$: $(x_3\cdot v_2)/(v_2\cdot v_2)=(1/2)/(3/2)=(1/2)(2/3)=1/3$.
7. Subtract both orthogonal components: $v_3=x_3-\tfrac12v_1-\tfrac13v_2=(1,0,0,-1)^T-(1/2,-1/2,0,0)^T-(1/6,1/6,-1/3,0)^T=(1/3,1/3,1/3,-1)^T$.
**Check:** $v_1\cdot v_2=1/2-1/2=0$, $v_1\cdot v_3=1/3-1/3=0$, and $v_2\cdot v_3=1/6+1/6-1/3=0$.
::::

:::

:::problem[Problem 6.21 — Two-vector reduction]{difficulty=easy}
Orthogonalize $(1,0,0)^T$ and $(1,1,0)^T$.

::::solution[Solution]
**Answer:** $(1,0,0)^T,(0,1,0)^T$.

1. Gram–Schmidt starts with the first vector unchanged: $v_1=x_1=(1,0,0)^T$.
2. Its squared norm is $v_1\cdot v_1=1^2+0^2+0^2=1$. The dot product with the second input is $x_2\cdot v_1=1(1)+1(0)+0(0)=1$.
3. Divide to get the projection coefficient $1/1=1$, then remove the component parallel to $v_1$: $v_2=x_2-(1)v_1=(1,1,0)^T-(1,0,0)^T=(0,1,0)^T$.
4. Neither vector is zero, so they form an orthogonal basis of the original two-dimensional span.
**Check:** $v_1\cdot v_2=1(0)+0(1)+0(0)=0$, and $v_1+v_2=x_2$.
::::

:::

:::problem[Problem 6.22 — QR of a tall two-column matrix]{difficulty=standard}
Find reduced QR for $A=\begin{bmatrix}1&1\\1&-1\\0&0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $Q=\frac1{\sqrt2}\begin{bmatrix}1&1\\1&-1\\0&0\end{bmatrix}$, $R=\begin{bmatrix}\sqrt2&0\\0&\sqrt2\end{bmatrix}$.

1. Write the columns as $a_1=(1,1,0)^T$ and $a_2=(1,-1,0)^T$. Their dot product is $1(1)+1(-1)+0(0)=0$, so Gram–Schmidt requires no subtraction.
2. Compute both lengths: $\|a_1\|=\sqrt{1^2+1^2}=\sqrt2$ and $\|a_2\|=\sqrt{1^2+(-1)^2}=\sqrt2$.
3. Normalize to obtain $q_1=(1,1,0)^T/\sqrt2$, $q_2=(1,-1,0)^T/\sqrt2$, hence $Q=(1/\sqrt2)\begin{bmatrix}1&1\\1&-1\\0&0\end{bmatrix}$.
4. Form $R=Q^TA$. Its entries are $r_{11}=q_1\cdot a_1=\sqrt2$, $r_{12}=q_1\cdot a_2=0$, $r_{21}=q_2\cdot a_1=0$, and $r_{22}=q_2\cdot a_2=\sqrt2$. Therefore $R=\begin{bmatrix}\sqrt2&0\\0&\sqrt2\end{bmatrix}$.
**Check:** $Q^TQ=I_2$ from the unit lengths and zero dot product, and $QR=(1/\sqrt2)A(\sqrt2 I_2)=A$.
::::

:::

:::problem[Problem 6.23 — Compute a QR entry]{difficulty=standard}
If $x_1=(1,1)^T$ and $x_2=(1,0)^T$, find the upper-right entry $r_{12}$ in reduced QR of $A=[x_1\;x_2]$.

::::solution[Solution]
**Answer:** $r_{12}=1/\sqrt2$.

1. In reduced QR, the first orthonormal column is $q_1=x_1/\|x_1\|$. Compute $\|x_1\|=\sqrt{1^2+1^2}=\sqrt2$.
2. Divide each component: $q_1=(1/\sqrt2,1/\sqrt2)^T$.
3. The upper-right entry of $R=Q^TA$ is $r_{12}=q_1^Tx_2$. Compute its numerator by coordinates: $q_1^Tx_2=(1/\sqrt2)(1)+(1/\sqrt2)(0)=1/\sqrt2+0=1/\sqrt2$.
4. This entry is available before constructing $q_2$ because it only measures the component of $x_2$ in the $q_1$ direction.
**Check:** $x_2-r_{12}q_1=(1,0)^T-(1/2,1/2)^T=(1/2,-1/2)^T$, whose dot product with $q_1$ is zero.
::::

:::

:::problem[Problem 6.24 — QR and least squares]{difficulty=standard}
For $Q=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$, $R=\begin{bmatrix}2&1\\0&3\end{bmatrix}$, and $b=(5,6,2)^T$, solve $R\hat x=Q^Tb$.

::::solution[Solution]
**Answer:** $\hat x=(3/2,2)^T$.

1. Because $Q$ has orthonormal columns, the reduced-QR least-squares system is $R\hat x=Q^Tb$.
2. Transpose and multiply: $Q^T=\begin{bmatrix}1&0&0\\0&1&0\end{bmatrix}$, so $Q^Tb=(1(5)+0(6)+0(2),0(5)+1(6)+0(2))^T=(5,6)^T$.
3. Write the upper-triangular equations: $2x_1+x_2=5$ and $3x_2=6$. Solve the second equation first, $x_2=6/3=2$.
4. Substitute into the first equation: $2x_1+2=5$, so $2x_1=5-2=3$, hence $x_1=3/2$.
5. Reconstruct the fitted vector: $QR=\begin{bmatrix}2&1\\0&3\\0&0\end{bmatrix}$, so $(QR)\hat x=(2(3/2)+2,3(2),0)^T=(5,6,0)^T$.
**Check:** The residual is $b-(QR)\hat x=(0,0,2)^T$; multiplying by $Q^T$ gives zero, as required for least squares.
::::

:::

## 6.5 Least-Squares Problems

An inconsistent system cannot be solved exactly, but it can still have a **best approximation**. Suppose three measurements ask two parameters to satisfy three different equations. No choice of parameters may make all three measurements match perfectly. Instead of declaring failure, we choose the parameters that make the total squared mismatch as small as possible. That is the **least-squares solution**. The key is to distinguish two spaces: the unknown coefficients $x$ live in $\R^n$, whereas the prediction $Ax$ and observed data $b$ live in $\R^m$.

Every possible prediction $Ax$ belongs to $\Col A$, regardless of whether the system is consistent. So the closest prediction to $b$ is simply its **projection onto $\Col A$**. From §6.3, the error $e=b-A\hat x$ must be orthogonal to every column of $A$. Writing all of these dot-product equations at once gives $A^Te=0$, and rearranging gives the **normal equations**. Notice the logic: we are not making the system consistent by wishful thinking. We are solving a *new* consistent system that describes the best approximate answer.

:::definition[Definition 6.9 — Least-Squares Solution and Residual]
A **least-squares solution** $\hat x$ of $Ax=b$ minimizes $\|b-Ax\|^2$ over all $x\in\R^n$. The fitted vector is $\hat b=A\hat x$, the **residual** is $e=b-\hat b$, the **least-squares error** is $\|e\|$, and the **sum of squared errors** is $\|e\|^2$. These last two are not the same quantity.
:::

:::theorem[Theorem 6.10 — Normal Equations]
The least-squares solutions of $Ax=b$ are exactly the solutions of $A^TA\hat x=A^Tb$. These equations are **always consistent**. The geometric condition is $b-A\hat x\perp\Col A$; equivalently, $A^T(b-A\hat x)=0$. Every least-squares solution produces the **same fitted vector** $A\hat x=\proj_{\Col A}b$, even when coefficient vectors are not unique.
:::

:::proof[Normal equations from perpendicular error]
If $\hat b=A\hat x$ is the nearest point in $\Col A$, then the residual $b-\hat b$ is in $(\Col A)^\perp=\Nul(A^T)$. Thus $A^T(b-A\hat x)=0$. Distribute: $A^Tb-A^TA\hat x=0$, so $A^TA\hat x=A^Tb$. Conversely, any solution of the normal equations has its fitted point in $\Col A$ and its residual in $(\Col A)^\perp$, so the Best Approximation Theorem says it minimizes error. There is always a closest point in a finite-dimensional subspace, so the normal equations are always consistent. The original equation $Ax=b$, however, may still be inconsistent.
:::

:::theorem[Theorem 6.11 — Uniqueness and the Full-Column-Rank Formula]
The normal equations have a **unique** solution if and only if $A$ has linearly independent columns. In that case $A^TA$ is invertible and $\hat x=(A^TA)^{-1}A^Tb$. The proof uses $x^TA^TAx=\|Ax\|^2$: if $A^TAx=0$, then $Ax=0$; thus $\Nul(A^TA)=\Nul A$. The inverse formula is a theoretical convenience, not an instruction to compute a large inverse by hand.
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="Least-squares geometry showing b outside column-space plane, its closest vector Axhat and orthogonal residual e">
<path class="fig-fill-alt" d="M 52 173 L 218 222 L 390 141 L 222 86 Z"/>
<path class="fig-guide" d="M 52 173 L 218 222 L 390 141 L 222 86 Z"/>
<path class="fig-curve" d="M 201 177 L 292 143"/>
<path class="fig-curve-alt" d="M 201 177 L 293 34"/>
<path class="fig-arrow" d="M 292 143 L 293 34"/>
<path class="fig-guide" d="M 279 143 L 279 132 L 292 132"/>
<circle class="fig-point" cx="201" cy="177" r="4"/>
<circle class="fig-point" cx="292" cy="143" r="4"/>
<circle class="fig-point" cx="293" cy="34" r="4"/>
<text class="fig-label" x="301" y="38">b</text>
<text class="fig-label" x="302" y="150">A x̂</text>
<text class="fig-label" x="302" y="94">e</text>
<text class="fig-label" x="88" y="178">Col A</text>
<text class="fig-label" x="191" y="190">0</text>
</svg>
<figcaption>Least squares chooses the reachable vector $A\hat x$ closest to the observation $b$. The residual $e=b-A\hat x$ is perpendicular to $\Col A$, giving the normal equations $A^TA\hat x=A^Tb$.</figcaption>
</figure>

### Build the system without skipping a matrix multiplication

For an $m\times n$ matrix, write $A^T$ first. Multiplying an $n\times m$ matrix by an $m\times n$ matrix gives an $n\times n$ matrix $A^TA$. Every entry is a dot product of two **columns of $A$**. The right-hand side $A^Tb$ has $n$ entries, one dot product of each column with the measured vector. Then write the augmented matrix $[A^TA\mid A^Tb]$ and row-reduce. On a no-calculator exam with two unknowns, elimination is normally shorter and less error-prone than computing $(A^TA)^{-1}$.

After solving for $\hat x$, do not stop if the problem asks for error. Multiply **the original** $A$ by $\hat x$ to find $\hat b$. Form $e=b-\hat b$ and calculate $\sqrt{e_1^2+\cdots+e_m^2}$. One required check is $A^Te=0$. If it does not vanish, something is wrong with the normal equations, elimination, or subtraction. If you need only the squared error, there is a shortcut: because $\hat b\perp e$, Pythagoras gives $\|e\|^2=\|b\|^2-\|\hat b\|^2=\|b\|^2-\hat x^TA^Tb$. This helps when $m$ is large but the coefficient vector is small.

The rank condition deserves attention. If two columns of $A$ are equal, different coefficient pairs can produce the same prediction. The residual is still uniquely determined, but the coefficients are not. A least-squares problem **always** has at least one solution; a unique solution requires independent columns. Also, fitting exact data is not contradictory to least squares: if $b\in\Col A$, the minimum error is zero and the least-squares solution is an ordinary exact solution.

:::example[Example 6.17 — Solve normal equations and find error]
For $A=\begin{bmatrix}1&1\\1&2\\1&3\end{bmatrix}$ and $b=(2,2,4)^T$, find the least-squares solution and its error.

::::answer[Answer]
**Answer:** $\hat x=(2/3,1)^T$ and $\|e\|=\sqrt6/3$.

1. Transpose $A^T=\begin{bmatrix}1&1&1\\1&2&3\end{bmatrix}$.

2. Multiply columns: $A^TA=\begin{bmatrix}3&6\\6&14\end{bmatrix}$, since the second diagonal is $1+4+9=14$.

3. Dot columns with $b$: $A^Tb=(2+2+4,2+4+12)^T=(8,18)^T$.

4. The augmented normal matrix is $\begin{bmatrix}3&6&8\\6&14&18\end{bmatrix}$.

5. Apply $R_2\leftarrow R_2-2R_1$ to obtain $\begin{bmatrix}3&6&8\\0&2&2\end{bmatrix}$.

6. Row two gives $x_2=1$; row one gives $3x_1+6=8$, hence $x_1=2/3$.

7. Multiply back: $\hat b=A\hat x=(5/3,8/3,11/3)^T$.

8. Subtract: $e=b-\hat b=(1/3,-2/3,1/3)^T$.

9. Its squared length is $1/9+4/9+1/9=6/9$, so its norm is $\sqrt6/3$.

10. Check $A^Te=(1-2+1,(1)-4+3)^T/3=(0,0)^T$.
::::

:::

:::example[Example 6.18 — A truly inconsistent two-parameter system]
For $A=\begin{bmatrix}1&0\\0&1\\1&1\end{bmatrix}$ and $b=(1,1,1)^T$, find $\hat x$, $\hat b$, and $e$.

::::answer[Answer]
**Answer:** $\hat x=(2/3,2/3)^T$, $\hat b=(2/3,2/3,4/3)^T$, and $e=(1/3,1/3,-1/3)^T$.

1. The original equations are $x_1=1$, $x_2=1$, and $x_1+x_2=1$, so they cannot all hold.

2. Transpose and multiply: $A^TA=\begin{bmatrix}2&1\\1&2\end{bmatrix}$, $A^Tb=(2,2)^T$.

3. Solve $2x_1+x_2=2$ and $x_1+2x_2=2$.

4. Subtract the equations to obtain $x_1-x_2=0$, hence $x_1=x_2$.

5. Substitute $3x_1=2$ to get $2/3$ each.

6. Multiplying by the original $A$ gives the fitted values.

7. Subtract those from $b$ to obtain the residual.

8. Its squared length is $1/9+1/9+1/9=1/3$, and $A^Te=(1/3-1/3,1/3-1/3)=(0,0)$.

9. The least-squares system has a perfect solution although the original system does not.
::::

:::

:::example[Example 6.19 — Nonunique coefficients, unique fitted vector]
Let $A=\begin{bmatrix}1&1\\2&2\end{bmatrix}$, $b=(1,3)^T$. Find all least-squares solutions and the fitted vector.

::::answer[Answer]
**Answer:** All solutions satisfy $x_1+x_2=7/5$; the fitted vector is $\hat b=(7/5,14/5)^T$, and $\|e\|=1/\sqrt5$.

1. The columns are identical, so $A^TA=\begin{bmatrix}5&5\\5&5\end{bmatrix}$ and $A^Tb=(7,7)^T$.

2. The normal equations reduce to one equation $5x_1+5x_2=7$, or $x_1+x_2=7/5$.

3. Taking $x_2=t$ gives the whole family $x=(7/5-t,t)^T$.

4. Yet every choice produces $Ax=(7/5,14/5)^T$, because the two columns always receive the same combined weight.

5. Residual $e=(1-7/5,3-14/5)=(-2/5,1/5)$ and squared length $4/25+1/25=1/5$.

6. The rank of $A$ is one, so $(A^TA)^{-1}$ does not exist.

7. Do not use the inverse formula merely because $A^TA$ is square.
::::

:::


### Worked examples: Least squares without forming normal equations

:::example[Example 6.20 — Least squares without forming normal equations]
Let $Q=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$ and $R=\begin{bmatrix}2&1\\0&2\end{bmatrix}$, and let $A=QR$, $b=(4,2,3)^T$. Find the least-squares coefficients by QR.

::::answer[Answer]
**Answer:** $\hat x=(3/2,1)^T$ and error $3$.

1. Calculate $Q^Tb=(4,2)^T$.

2. The reduced QR method says solve $R\hat x=Q^Tb$, namely $2x_1+x_2=4$ and $2x_2=2$.

3. From the second row $x_2=1$.

4. Substitute into the first: $2x_1=3$, so $x_1=3/2$.

5. Multiply $A=QR=\begin{bmatrix}2&1\\0&2\\0&0\end{bmatrix}$.

6. Thus $A\hat x=(4,2,0)^T$.

7. Residual $(0,0,3)^T$ has norm three; it is perpendicular to both columns of $A$, which have third coordinate zero.

8. QR and normal equations must give the same result, but QR avoids squaring the entries in $A$.
::::

:::


### Why squaring the error makes algebra easier

Least squares minimizes $\|b-Ax\|$, but we nearly always compute with its square. Since norms are nonnegative, the same $x$ minimizes both quantities: if $0\le p\le q$, then $p^2\le q^2$, and conversely. The squared error is a sum of squares, $E(x)=\sum_i(b_i-(Ax)_i)^2$, not a sum of signed residuals. Signed residuals can cancel to zero while individual errors remain significant. For example, errors $1$ and $-1$ sum to zero but have squared error $1^2+(-1)^2=2$. This is why the normal equations do not simply ask that the residual entries add to zero; they demand perpendicularity to **every** design column.

There is a useful algebraic proof that requires no calculus. Let $\hat x$ solve the normal equations and let $x=\hat x+h$ be another candidate. Write $e=b-A\hat x$. Then $b-Ax=e-Ah$. Because $A^Te=0$, we know $e\cdot(Ah)=(A^Te)\cdot h=0$. Expand the squared norm: $\|e-Ah\|^2=\|e\|^2+\|Ah\|^2$ by Pythagoras. The second term is nonnegative, so $\hat x$ has minimum error. Equality occurs precisely when $Ah=0$, meaning $h\in\Nul A$. This proof simultaneously explains **existence of the minimum, nonuniqueness of coefficients when $\Nul A$ is nontrivial, and uniqueness of the fitted vector**. It is often more enlightening than memorizing the inverse formula.

### Three different kinds of solution questions

A question may ask for a **least-squares coefficient vector** $\hat x$, a **fitted observation vector** $\hat b=A\hat x$, or a **least-squares error** $\|b-\hat b\|$. These have different shapes. If $A$ has five rows and two columns, then $\hat x$ has two components, but $\hat b$ and residual $e$ each have five. In a no-calculator setting, count the components in your final answer. Writing a two-entry vector as the fitted data for five observations is a dimension error, even if its entries happen to equal the correct regression coefficients.

For the same reason, the normal equations are not solved by transposing the entire **augmented** matrix. Construct $A^TA$ and $A^Tb$ as two separate products. Compute entries from dot products rather than blindly multiplying by rows: $[(A^TA)_{ij}]=[a_i\cdot a_j]$, where $a_i$ are the columns of $A$. Symmetry is a built-in check: if your computed $A^TA$ is not symmetric, the multiplication is wrong. A second check is nonnegativity of its diagonal: the $i$th diagonal is $a_i\cdot a_i=\|a_i\|^2\ge0$.

### Positive definiteness gives uniqueness

There is an exact correspondence between independent columns and an invertible normal matrix. For any nonzero $x$, $x^TA^TAx=\|Ax\|^2$. If the columns are independent, the equation $Ax=0$ has only the zero solution, so for every nonzero $x$, $\|Ax\|^2>0$. That property makes $A^TA$ **positive definite**. If the columns are dependent, there exists nonzero $h$ with $Ah=0$, and hence $h^TA^TAh=0$, making $A^TA$ singular. You do not need a determinant computation in every conceptual problem: demonstrating that two columns are proportional is enough to disprove uniqueness immediately. Conversely, a visible pivot in every column of $A$ establishes unique coefficients for all $b$.

The projection itself stays unique even with a singular $A^TA$. If $\hat x$ is a particular least-squares solution and $h\in\Nul A$, then $A(\hat x+h)=A\hat x+Ah=A\hat x$. The entire affine family $\hat x+\Nul A$ produces the same fitted vector. The normal-equation solution set is therefore not the same thing as a set of multiple equally good fitted points; it is multiple descriptions of a **single** closest point. When an answer key gives only one particular solution for a rank-deficient problem, that is not the full general solution if the question asks for *all* coefficients.

### Two residual checks beyond $A^Te=0$

First, verify that $\hat b$ is in $\Col A$: display the actual combination of columns with coefficients $\hat x$. Second, use the energy identity $\|b\|^2=\|\hat b\|^2+\|e\|^2$ to check the residual norm. This follows because $\hat b\in\Col A$ and $e\perp\Col A$, so $\hat b\perp e$. Since $\|\hat b\|^2=(A\hat x)^T(A\hat x)=\hat x^TA^TA\hat x=\hat x^TA^Tb$, the shortcut $\|e\|^2=\|b\|^2-\hat x^TA^Tb$ requires only the right-hand side already computed for normal equations. If the result is negative, it signals a calculation error, because a squared norm cannot be negative.



### Matrix sizes give a fast plausibility test

Let $A$ have $m$ equations and $n$ unknown coefficients. The original equation $Ax=b$ compares vectors in $\R^m$, but the normal equations compare vectors in $\R^n$. That is why $A^T$ appears on **both** sides: it converts the original $m$ residual conditions into $n$ dot-product conditions. If your normal equations have $m$ rows, you probably formed $AA^T$ instead. That matrix may be square too, but it acts on vectors with the wrong number of coordinates for the original unknown $x$.

If the columns of $A$ are orthogonal already, $A^TA$ is diagonal. If they are orthonormal, $A^TA=I$, and $\hat x=A^Tb$: least squares reduces to dot products, just as orthonormal basis coordinates did in §6.2. This is not a coincidence. The two computations are the same projection geometry expressed with different language. The general normal equations are what is left when the columns no longer have the convenient perpendicularity property. Gram–Schmidt and QR can restore that convenience, but for small exam matrices it is often faster to multiply $A^TA$ directly.

### An exact fit is the zero-error special case

A least-squares problem does not automatically mean the original system is inconsistent. If the observations already lie in the column space, then the projection of $b$ onto $\Col A$ is $b$ itself, and the residual is zero. For instance, with $A$ having columns $(1,1,1)^T$ and $(0,1,2)^T$, the vector $(3,2,1)^T$ equals $3(1,1,1)^T-1(0,1,2)^T$. Consequently the least-squares coefficient pair is simply $(3,-1)$ and the minimum error is zero. This is why the practice problem yields an **exact** line despite being labeled a least-squares exercise.

When you obtain a zero residual, it is worth checking directly that $A\hat x=b$ rather than just accepting a zero under a square root. On the other hand, a small nonzero residual does not mean your algebra is wrong; it may represent the best achievable approximation. Use $A^Te=0$ as the optimality condition. The residuals need not be individually small or have matching signs, but their dot products with all design columns must cancel.



### A short grading checklist for normal equations

Label all four objects: $A$, $b$, $A^TA$, and $A^Tb$. If there are two unknowns, the normal matrix should be $2\times2$ and its right side a two-entry column. Show the row operation that solves the augmented matrix. State $\hat x$ in vector form, then calculate $A\hat x$ and $b-A\hat x$ separately when the error is requested. A final $A^Te=0$ verification distinguishes a true minimizer from a plausible but merely close guess. Each of these lines corresponds to a different conceptual step, so omitting them hides whether the error came from constructing, solving, or interpreting the least-squares system.


:::callout-pitfall[§6.5: The fitted vector is not the coefficient vector]
$\hat x$ is an $n$-component coefficient vector; $A\hat x$ is an $m$-component prediction. The residual is $b-A\hat x$, not $b-\hat x$ unless dimensions happen to match and that expression is truly intended. Form **$A^TA$**, not $AA^T$, for the normal equations. Minimize the *norm*, but you may minimize its **square** because squaring a nonnegative quantity preserves which choice is smallest. A rank-deficient matrix still has least-squares solutions; it may have infinitely many and must not be inverted.
:::

:::problem[Problem 6.25 — Normal equations from orthogonality]{difficulty=easy}
Explain why $\hat x$ is a least-squares solution exactly when $A^T(A\hat x-b)=0$.

::::solution[Solution]
**Answer:** $A^TA\hat x=A^Tb$.

1. A least-squares solution minimizes $\|b-Ax\|$. At the closest vector $A\hat x$ in $\Col A$, the residual $e=b-A\hat x$ must be perpendicular to that column space.

2. Perpendicular to every column means $A^Te=0$, because each entry of $A^Te$ is one column dotted with $e$.

3. Substitute the residual: $A^T(b-A\hat x)=0$.

4. Distribute $A^T$: $A^Tb-A^TA\hat x=0$.

5. Rearrange to obtain $A^TA\hat x=A^Tb$. Check: substitution back gives $A^T(b-A\hat x)=0$, the required perpendicularity.
::::

:::

:::problem[Problem 6.26 — Consistent data, still least squares]{difficulty=easy}
Find the least-squares solution to $Ax=b$ with $A=\begin{bmatrix}1&0\\1&1\\1&2\end{bmatrix}$ and $b=(3,2,1)^T$.

::::solution[Solution]
**Answer:** $\hat x=(3,-1)^T$; error $0$.

1. A least-squares coefficient vector satisfies the normal equations $(A^TA)\hat x=A^Tb$, even when the data happen to be consistent.
2. The columns of $A$ are $a_1=(1,1,1)^T$ and $a_2=(0,1,2)^T$. Their dot products give $a_1^Ta_1=3$, $a_1^Ta_2=0+1+2=3$, and $a_2^Ta_2=0+1+4=5$, so $A^TA=\begin{bmatrix}3&3\\3&5\end{bmatrix}$.
3. Multiply by the response: $a_1^Tb=3+2+1=6$ and $a_2^Tb=0(3)+1(2)+2(1)=4$. Thus $A^Tb=(6,4)^T$.
4. Write the augmented system $\left[\begin{array}{cc|c}3&3&6\\3&5&4\end{array}\right]$. Apply $R_2\leftarrow R_2-R_1$ to obtain $\left[\begin{array}{cc|c}3&3&6\\0&2&-2\end{array}\right]$.
5. Back-substitute: $2x_2=-2\Rightarrow x_2=-1$. Then $3x_1+3(-1)=6\Rightarrow3x_1=9\Rightarrow x_1=3$.
**Check:** $A(3,-1)^T=(3,3-1,3-2)^T=(3,2,1)^T=b$, so the residual and its norm are both zero.
::::

:::

:::problem[Problem 6.27 — One-column least squares]{difficulty=standard}
Find the best $c$ satisfying approximately $c(1,2)^T=(2,3)^T$. Give the error.

::::solution[Solution]
**Answer:** $c=8/5$ and error $1/\sqrt5$.

1. With one column $a=(1,2)^T$, the normal equation for scalar $c$ is $(a^Ta)c=a^Tb$.

2. Compute $a^Ta=1^2+2^2=1+4=5$, and $a^Tb=(1)(2)+(2)(3)=2+6=8$.

3. Solve $5c=8$ by dividing both sides by five: $c=8/5$.

4. Find the prediction $ac=(8/5,16/5)^T$.

5. Subtract from $b=(2,3)^T$: $e=(2-8/5,3-16/5)^T=(2/5,-1/5)^T$.

6. Square and add: $\|e\|^2=(2/5)^2+(-1/5)^2=4/25+1/25=5/25=1/5$. Therefore $\|e\|=1/\sqrt5$.

7. Check orthogonality: $a^Te=1(2/5)+2(-1/5)=2/5-2/5=0$.
::::

:::

:::problem[Problem 6.28 — Form normal equations]{difficulty=standard}
For $A=\begin{bmatrix}1&1\\1&2\\1&3\end{bmatrix}$ and $b=(1,2,2)^T$, calculate $A^TA$ and $A^Tb$ but do not solve.

::::solution[Solution]
**Answer:** $A^TA=\begin{bmatrix}3&6\\6&14\end{bmatrix}$, $A^Tb=(5,11)^T$.

1. Use the columns of $A$, namely $a_1=(1,1,1)^T$ and $a_2=(1,2,3)^T$. By definition $(A^TA)_{ij}=a_i^Ta_j$.

2. Compute $a_1^Ta_1=1+1+1=3$.

3. Compute $a_1^Ta_2=1(1)+1(2)+1(3)=1+2+3=6$; symmetry gives $a_2^Ta_1=6$.

4. Compute $a_2^Ta_2=1^2+2^2+3^2=1+4+9=14$.

5. For $b=(1,2,2)^T$, compute $a_1^Tb=1+2+2=5$.

6. Compute $a_2^Tb=1(1)+2(2)+3(2)=1+4+6=11$. Check: $A^TA$ is symmetric, as every Gram matrix must be.
::::

:::

:::problem[Problem 6.29 — Residual squared norm shortcut]{difficulty=standard}
A least-squares fit has $\|b\|^2=30$ and $\hat x^TA^Tb=22$. What is the least-squares error?

::::solution[Solution]
**Answer:** $2\sqrt2$.

1. Write the fitted vector as $\hat b=A\hat x$ and the residual as $e=b-\hat b$. At a least-squares solution, $\hat b\cdot e=0$.
2. Use the Pythagorean identity for perpendicular vectors: $\|b\|^2=\|\hat b+e\|^2=\|\hat b\|^2+\|e\|^2$.
3. Express the fitted squared length using the normal equations: $\|\hat b\|^2=\hat x^TA^TA\hat x=\hat x^TA^Tb=22$.
4. Insert the given $\|b\|^2=30$: $30=22+\|e\|^2$. Subtract $22$ to get $\|e\|^2=30-22=8$.
5. Take the nonnegative square root: $\|e\|=\sqrt8=\sqrt{4\cdot2}=2\sqrt2$.
**Check:** $\|\hat b\|^2+\|e\|^2=22+8=30$, matching $\|b\|^2$.
::::

:::

:::problem[Problem 6.30 — Rank and uniqueness]{difficulty=challenge}
Why is it invalid to use $(A^TA)^{-1}A^Tb$ merely because $A^TA$ is square? Give a concrete dependent-column example.

::::solution[Solution]
**Answer:** a square matrix can still be singular.

1. Take $A=\begin{bmatrix}1&1\\2&2\end{bmatrix}$.

2. Its columns are equal, $A^TA=\begin{bmatrix}5&5\\5&5\end{bmatrix}$, and determinant $25-25=0$.

3. In general $\Nul(A^TA)=\Nul A$ because $x^TA^TAx=\|Ax\|^2$.

4. Therefore $A^TA$ is invertible **exactly when** the columns of $A$ are independent, not merely when it is square.
::::

:::

## 6.6 Applications: Linear Models / Regression

In least squares, the columns of $A$ are all the patterns your model is allowed to combine. For a **straight-line model** $y=\beta_0+\beta_1x$, the patterns are a constant column of ones and a column of observed $x$-values. The unknown vector $\beta=(\beta_0,\beta_1)^T$ contains the intercept and slope. Measured $y$-values become the right-hand side. There are usually more observations than coefficients, and observations rarely lie perfectly on one line, so the system is usually inconsistent. Nothing new needs to be invented: it is exactly the least-squares problem of §6.5.

The interpretation of an individual residual is especially concrete. At a data point $(x_i,y_i)$, the prediction is $\hat y_i=\beta_0+\beta_1x_i$. The **vertical** residual is $e_i=y_i-\hat y_i$. Least-squares regression minimizes the sum $\sum_i e_i^2$, so an error of magnitude two contributes four units to the sum, while an error of magnitude one contributes one. The distances being minimized are **vertical deviations**, not perpendicular geometric distances from points to the drawn line in the $xy$-plane. That distinction explains the method's dependence on which quantity is treated as the response.

:::definition[Definition 6.10 — Design Matrix for Linear Regression]
Given data $(x_1,y_1),\ldots,(x_m,y_m)$, a least-squares line $y\approx\beta_0+\beta_1x$ uses $A=\begin{bmatrix}1&x_1\\\vdots&\vdots\\1&x_m\end{bmatrix}$, $b=(y_1,\ldots,y_m)^T$, and unknown $\beta=(\beta_0,\beta_1)^T$. Solve $A^TA\hat\beta=A^Tb$. The prediction at a new input $x_*$ is $\hat y_*=\hat\beta_0+\hat\beta_1x_*$.
:::

:::theorem[Theorem 6.12 — Line-Fitting Normal Equations]
For $m$ data points, the normal equations for intercept and slope are $\begin{bmatrix}m&\sum x_i\\\sum x_i&\sum x_i^2\end{bmatrix}\begin{bmatrix}\beta_0\\\beta_1\end{bmatrix}=\begin{bmatrix}\sum y_i\\\sum x_i y_i\end{bmatrix}$. The least-squares line is unique when not all $x_i$ are equal. If $x_i$ are all equal, the intercept and slope cannot be separately identified because the two design columns are proportional.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 420 240" width="420" height="240" role="img" aria-label="Four measured points (0,0), (1,3), (2,4), (3,5) and their vertically drawn residual segments to the computed least-squares line y equals 0.6 plus 1.6x">
<line class="fig-axis" x1="42" y1="207" x2="395" y2="207"/>
<line class="fig-axis" x1="74" y1="220" x2="74" y2="15"/>
<path class="fig-curve" d="M 74 187.8 L 382 8.6"/>
<line class="fig-guide" x1="74" y1="207" x2="74" y2="187.8"/>
<line class="fig-guide" x1="162" y1="111" x2="162" y2="137.0"/>
<line class="fig-guide" x1="250" y1="79" x2="250" y2="85.4"/>
<line class="fig-guide" x1="338" y1="47" x2="338" y2="34.2"/>
<circle class="fig-point" cx="74" cy="207" r="4"/>
<circle class="fig-point" cx="162" cy="111" r="4"/>
<circle class="fig-point" cx="250" cy="79" r="4"/>
<circle class="fig-point" cx="338" cy="47" r="4"/>
<text class="fig-label" x="60" y="224">0</text>
<text class="fig-label" x="160" y="224">1</text>
<text class="fig-label" x="248" y="224">2</text>
<text class="fig-label" x="336" y="224">3</text>
<text class="fig-label" x="397" y="209">x</text>
<text class="fig-label" x="60" y="18">y</text>
<text class="fig-label" x="147" y="34">ŷ = 0.6 + 1.6x</text>
<text class="fig-label" x="266" y="118">vertical residuals</text>
</svg>
<figcaption>For the data $(0,0),(1,3),(2,4),(3,5)$, the least-squares line is $\hat y=3/5+(8/5)x$. The dashed **vertical** segments are the residuals $y_i-\hat y_i$, which are squared and added.</figcaption>
</figure>

:::definition[Definition 6.11 — General Linear Models]
A model is **linear in its coefficients** if $\hat y=\beta_0\phi_0(x)+\cdots+\beta_p\phi_p(x)$ with known functions $\phi_j$. Its design matrix is $A_{ij}=\phi_j(x_i)$. It can therefore be a least-squares problem even when the graph is curved in $x$. For example, fitting a quadratic $\beta_0+\beta_1x+\beta_2x^2$ is still linear in the three unknown coefficients.
:::

:::theorem[Theorem 6.13 — Mean residual and regression checks]
For a line fit **with an intercept**, the residuals satisfy $\sum_i e_i=0$ because the first design column is all ones and $A^Te=0$. The residuals also satisfy $\sum_i x_ie_i=0$. Consequently the fitted line passes through the point $(\bar x,\bar y)$, where $\bar x=(\sum x_i)/m$ and $\bar y=(\sum y_i)/m$. These exact checks often catch arithmetic mistakes before a final answer is submitted.
:::

### A table is faster than four separate matrix products

For a regression problem, draw columns titled $x$, $y$, $x^2$, and $xy$. Record the sums at the bottom. You only need five numbers: $m$, $\sum x$, $\sum y$, $\sum x^2$, and $\sum xy$. Put them in the normal equations in the exact pattern from Theorem 6.12. Solve the two equations using elimination. Then write the result as **$y=\hat\beta_0+\hat\beta_1x$**, not merely the coefficient vector. If the question asks for a prediction, substitute the new input into this formula, and if it asks for total squared error, evaluate each observed $y$ minus its predicted value and sum the squares.

You can sometimes simplify arithmetic by centering the input values. When $\sum x_i=0$, the normal matrix becomes diagonal: $\begin{bmatrix}m&0\\0&\sum x_i^2\end{bmatrix}$. Thus $\beta_0=(\sum y_i)/m$ and $\beta_1=(\sum x_i y_i)/(\sum x_i^2)$ immediately. If the given $x$-values are $0,1,2,3$, shifting to centered coordinates $t=x-3/2$ removes the cross-term, although the intercept must then be translated back. On a written test, use this only if the translated arithmetic is actually easier; the direct normal equations are reliable with small data.

### Regression language you should not confuse

The **independent variable** or predictor $x$ selects the model columns; the **response** or observed output $y$ is approximated. The intercept $\beta_0$ is the model's predicted response at $x=0$. The slope $\beta_1$ is the change in predicted $y$ for one unit increase in $x$. A positive slope is not a guarantee that each individual observation increases. A fitted line is not necessarily forced through any one observed point. And linear regression is not the same as interpolation: interpolation requires an exact match to every point, while least squares minimizes disagreement when an exact fit is unavailable.

:::example[Example 6.21 — Four-point least-squares line]
Fit $y=\beta_0+\beta_1x$ to $(1,1),(2,3),(3,6),(4,8)$.

::::answer[Answer]
**Answer:** $\hat y=-\frac32+\frac{12}{5}x$.

1. Build $A=\begin{bmatrix}1&1\\1&2\\1&3\\1&4\end{bmatrix}$ and $b=(1,3,6,8)^T$.

2. The data sums are $m=4$, $\sum x=10$, $\sum x^2=1+4+9+16=30$, $\sum y=1+3+6+8=18$, and $\sum xy=1+6+18+32=57$. **The old draft used $56$, an arithmetic error.** Thus $\begin{bmatrix}4&10\\10&30\end{bmatrix}\begin{bmatrix}\beta_0\\\beta_1\end{bmatrix}=(18,57)^T$.

3. Multiply the first equation by $5/2$: $10\beta_0+25\beta_1=45$.

4. Subtract from $10\beta_0+30\beta_1=57$ to get $5\beta_1=12$, hence $\beta_1=12/5$.

5. Substitute into $4\beta_0+10(12/5)=18$: $4\beta_0=-6$, $\beta_0=-3/2$.

6. Predictions are $(9/10,33/10,57/10,81/10)$, so residuals are $(1/10,-3/10,3/10,-1/10)$.

7. Both $\sum e_i=0$ and $\sum x_i e_i=0$.

8. The fitted line is the best *vertical least-squares* line, not a line through all four data points.
::::

:::

:::example[Example 6.22 — Fit a quadratic curve]
Fit $y=\beta_0+\beta_1x+\beta_2x^2$ to $(0,1),(1,2),(2,5),(3,11)$.

::::answer[Answer]
**Answer:** $\hat y=\frac{21}{20}-\frac9{20}x+\frac54x^2$.

1. The four design rows are $(1,0,0)$, $(1,1,1)$, $(1,2,4)$, and $(1,3,9)$, so $A=\begin{bmatrix}1&0&0\\1&1&1\\1&2&4\\1&3&9\end{bmatrix}$.

2. Using sums of $1,x,x^2,x^3,x^4$, obtain $A^TA=\begin{bmatrix}4&6&14\\6&14&36\\14&36&98\end{bmatrix}$.

3. Correctly dot the columns with $b=(1,2,5,11)^T$: $A^Tb=(19,45,121)^T$, not $(19,49,131)^T$ from the old draft.

4. Eliminate from $4a+6b+14c=19$, $6a+14b+36c=45$, $14a+36b+98c=121$.

5. Do $2R_2-3R_1$ to get $10b+30c=33$, and $2R_3-7R_1$ to get $30b+98c=109$.

6. Subtract three times the first reduced equation from the second: $8c=10$, so $c=5/4$.

7. Then $10b+30(5/4)=33$, giving $10b=-9/2$, $b=-9/20$.

8. Finally $4a+6(-9/20)+14(5/4)=19$, so $4a=21/5$ and $a=21/20$.

9. The coefficients are exact hand-friendly fractions, not the earlier incorrect approximations.
::::

:::

:::example[Example 6.23 — Three simple points and a quick prediction]
Fit a line to $(0,1),(1,2),(2,2)$ and predict the response at $x=3$.

::::answer[Answer]
**Answer:** $\hat y=7/6+x/2$ and $\hat y(3)=8/3$.

1. Tabulate $m=3$, $\sum x=0+1+2=3$, $\sum x^2=0+1+4=5$, $\sum y=1+2+2=5$, $\sum xy=0+2+4=6$.

2. Normal equations are $3\beta_0+3\beta_1=5$ and $3\beta_0+5\beta_1=6$.

3. Subtract to obtain $2\beta_1=1$, so $\beta_1=1/2$.

4. Substitute: $3\beta_0=5-3/2=7/2$, hence $\beta_0=7/6$.

5. At $x=3$, predict $7/6+3/2=7/6+9/6=16/6=8/3$.

6. Do not confuse this prediction with a fourth observation that should be added to the fitting system.
::::

:::

:::example[Example 6.24 — Centered inputs separate intercept and slope]
Fit $y=\beta_0+\beta_1x$ to $(-1,1),(0,2),(1,5)$.

::::answer[Answer]
**Answer:** $\hat y=8/3+2x$.

1. Because $\sum x=-1+0+1=0$, the cross-term in $A^TA$ vanishes.

2. Compute $m=3$, $\sum x^2=1+0+1=2$, $\sum y=1+2+5=8$, and $\sum xy=(-1)(1)+0(2)+(1)(5)=4$.

3. The normal equations become $3\beta_0=8$ and $2\beta_1=4$.

4. Therefore $\beta_0=8/3$ and $\beta_1=2$.

5. Predicted values are $(2/3,8/3,14/3)$; residuals are $(1/3,-2/3,1/3)$, whose sum is zero.

6. The data are not perfectly collinear, but symmetry of the predictor values saves nearly all elimination work.
::::

:::


### Why the fitted line passes through the sample means

With an intercept, the first normal equation says $m\beta_0+(\sum x_i)\beta_1=\sum y_i$. Divide the entire equation by $m$ to get $\beta_0+\beta_1\bar x=\bar y$. This means the fitted line always passes through the point of sample averages $(\bar x,\bar y)$, even if the actual measurements scatter around it. That does **not** say it passes through the data point whose $x$-value is closest to $\bar x$, or even that a measurement exists at the mean. It is a property of fitting an intercept alongside the slope.

You can use this identity to check a result in one multiplication. Suppose the input values are $1,2,3,4$ and the observed responses sum to $18$. Then $\bar x=5/2$ and $\bar y=9/2$. The fitted line $-3/2+(12/5)x$ from Example 6.21 predicts $-3/2+(12/5)(5/2)=-3/2+6=9/2$, exactly the sample mean. If the earlier incorrect line $-1+2.2x$ is used, it predicts $-1+5.5=4.5$ as well, so the means check alone would **not** catch every wrong coefficient pair. That is why both normal equations, or equivalently both residual orthogonality sums, should be verified when the arithmetic matters.

### An alternate slope formula when the sums get awkward

Eliminate $\beta_0$ from the two normal equations. The first gives $\beta_0=\bar y-\beta_1\bar x$. Substitute into the second to obtain $\beta_1[\sum x_i^2-m\bar x^2]=\sum x_iy_i-m\bar x\bar y$. Equivalently, $\beta_1=\frac{\sum_i(x_i-\bar x)(y_i-\bar y)}{\sum_i(x_i-\bar x)^2}$. This is the **centered-data slope formula**. It is the same answer as normal equations, not a different regression method. The denominator measures spread in the predictor values; if all $x_i$ are equal, that denominator is zero, which explains the loss of a unique slope. The intercept is then $\beta_0=\bar y-\beta_1\bar x$.

On paper, the centered formula is best when $\bar x$ is a small integer or the $x$-values are symmetric around zero. It can be worse when every centered value introduces halves or thirds. Do not feel compelled to derive it for every exercise. The reliable method is the five-sum table and a $2\times2$ elimination. A written test may award most points for a correct design matrix and correct normal equations even when later arithmetic goes wrong, so present those intermediate objects rather than jumping to a line from inspection.

### More model columns, same least-squares geometry

A quadratic model $y=a+bx+cx^2$ uses three columns: ones, $x$, and $x^2$. A cubic adds an $x^3$ column. If a problem asks for a model $y=a+bx+cz$ with *two predictors* $x,z$, use rows $(1,x_i,z_i)$ instead. The columns represent distinct known patterns; the unknown numbers that combine them are the regression coefficients. This distinction is what "linear model" means in linear algebra: the prediction is a **linear combination of unknown coefficients**, even though the input functions may be nonlinear. A polynomial regression with $x^2$ is linear in the unknowns, but a model $y=a e^{bx}$ is **not** linear in the unknown exponent coefficient $b$.

When three data points with distinct $x$-values determine a quadratic, the three-column design matrix is a square Vandermonde matrix and is invertible. Then least squares produces an **exact** interpolating polynomial, because three coefficients can match three independent constraints. With four points and only three quadratic coefficients, the system is usually overdetermined. It might still fit exactly if the points happen to lie on a quadratic, but there is no general guarantee. Model complexity and number of data points should not be confused with goodness of fit; adding more columns increases the range of predictions but can also make the coefficient system dependent when the observed predictor values are repeated.

### Residuals and what a line actually means

For each observation, record the predicted response $\hat y_i$ and error $e_i=y_i-\hat y_i$. The sign of $e_i$ tells whether the point lies above or below the fitted line in the **vertical** sense: positive residual means observed $y$ is above predicted $y$, while negative means below. The sum $\sum e_i=0$ with an intercept says positive and negative residuals balance. It does **not** imply that all residuals are zero, nor that the squared residual sum is zero. For instance, errors $(1,-2,1)$ sum to zero but their squared sum is six. This is why a student can correctly verify the first normal equation and still have a visibly imperfect fit.

Regression uses the observed inputs as given. Swapping the roles of $x$ and $y$ creates a different design matrix and asks a different question, generally producing a different best-fit line. The objective minimizes discrepancies in the **response** coordinate only. If the problem instead asks for shortest Euclidean distances from points to a line in the plane, that is a different optimization problem, often called orthogonal-distance regression or total least squares. On an MA 3113 written exam, the standard phrase "fit $y$ on $x$ by least squares" means vertical residuals and the design matrix with a column of ones and a column of $x$.


### Predicting new observations does not refit the model

Once the coefficients are computed, a request such as "predict the response at $x=5$" is only substitution into the fitted line. The new predictor value does not belong in the original training-data matrix unless the problem explicitly supplies a new observed $y$ and asks you to refit. For a quadratic fit, substitute into every power of $x$: $\hat y(5)=a+5b+25c$. Keep prediction and fitting logically separate. In particular, an extra test input may lie outside the range of the observations; the formula still computes a number, although interpreting that extrapolation requires care beyond the algebra of the exam.


### Two quick checks for the final fitted equation

After solving, write the line in intercept-slope order and substitute a sample $x$-value. The predicted $y$ need not match that observation exactly, but it should agree with the fitted vector from $A\hat\beta$. Next, verify $\hat\beta_0+\hat\beta_1\bar x=\bar y$. These two checks test different things: a numerical substitution catches a swapped slope and intercept, while the mean check tests the first normal equation. For a model with a quadratic term, use $A\hat\beta$ to check predictions at every input rather than assuming the simple two-parameter mean relation fully describes the fit.

:::callout-pitfall[§6.6: Data-column arithmetic errors affect everything]
Compute $\sum xy$ by **multiplying each pair** of $x$ and $y$ values first, then adding. Do not confuse $\sum x^2$ with $(\sum x)^2$. Keep the design columns in the chosen coefficient order: if the first is ones, the first coefficient is the **intercept**. Do not read $\beta_1$ as the intercept. A regression slope is not an angle, and a least-squares line minimizes vertical residual squares, not the shortest Euclidean distances from points to the slanted line. For a quadratic, a column of $x^2$ is required; the second power does not make the model nonlinear in its coefficients.
:::

:::problem[Problem 6.31 — Normal equation reasoning]{difficulty=easy}
Show that least-squares coefficients give a residual perpendicular to every design column.

::::solution[Solution]
**Answer:** $A^Te=0$ where $e=b-A\hat\beta$.

1. The normal equations for least-squares coefficients are $A^TA\hat\beta=A^Tb$. These express the condition for minimizing the squared residual norm.
2. Move all terms to one side: $A^Tb-A^TA\hat\beta=0$.
3. Factor $A^T$ by distributivity: $A^T(b-A\hat\beta)=0$.
4. Define the residual $e=b-A\hat\beta$. Substitution gives $A^Te=0$. Its $j$th coordinate is $a_j^Te=\sum_i(a_j)_ie_i$, the dot product of the $j$th design column with $e$.
5. Therefore every such dot product vanishes. For a line-fitting design with columns $(1,\ldots,1)^T$ and $(x_1,\ldots,x_m)^T$, these equations become $\sum_i e_i=0$ and $\sum_i x_ie_i=0$.
**Check:** Expanding $A^Te=0$ recovers $A^Tb-A^TA\hat\beta=0$, exactly the normal equations.
::::

:::

:::problem[Problem 6.32 — Fit exact linear data]{difficulty=easy}
Find the least-squares line for $A=\begin{bmatrix}1&0\\1&1\\1&2\end{bmatrix}$ and $b=(3,2,1)^T$.

::::solution[Solution]
**Answer:** $\hat y=3-x$.

1. Form the design matrix $A=\begin{bmatrix}1&0\\1&1\\1&2\end{bmatrix}$ and response vector $b=(3,2,1)^T$.

2. Compute the normal matrix $A^TA=\begin{bmatrix}3&3\\3&5\end{bmatrix}$: the entry sums are $1+1+1=3$, $0+1+2=3$, and $0^2+1^2+2^2=5$.

3. Compute $A^Tb=(3+2+1,\,0(3)+1(2)+2(1))^T=(6,4)^T$.

4. Set up the two equations $3\beta_0+3\beta_1=6$ and $3\beta_0+5\beta_1=4$.

5. Subtract the first equation from the second: $2\beta_1=4-6=-2$, hence $\beta_1=-1$.

6. Substitute into the first equation: $3\beta_0+3(-1)=6$, so $3\beta_0=9$ and $\beta_0=3$.

7. Check the fitted values: $3-0=3$, $3-1=2$, $3-2=1$, identical to $b$. Hence the residual is zero and the squared error is $0$.
::::

:::

:::problem[Problem 6.33 — Why full column rank matters]{difficulty=standard}
Explain why the inverse form $(A^TA)^{-1}A^Tb$ requires independent design columns, even though $A^TA$ is always square.

::::solution[Solution]
**Answer:** $A^TA$ is invertible if and only if $\Nul A=\{0\}$.

1. Indeed $x^TA^TAx=\|Ax\|^2$, so $A^TAx=0$ implies $Ax=0$; the converse is immediate.

2. Thus $\Nul(A^TA)=\Nul A$.

3. Repeated $x$-values may make the ones column proportional to the predictor column, so slope and intercept cannot be separately determined.
::::

:::

:::problem[Problem 6.34 — Four-point regression]{difficulty=standard}
Find the least-squares line through $(0,0),(1,1),(2,2),(3,4)$.

::::solution[Solution]
**Answer:** $\hat y=-1/5+13x/10$.

1. Fit $y=a+bx$ by minimizing squared residuals. For the four data points compute $m=4$, $\sum x_i=0+1+2+3=6$, and $\sum x_i^2=0+1+4+9=14$.
2. Also compute $\sum y_i=0+1+2+4=7$ and $\sum x_iy_i=0(0)+1(1)+2(2)+3(4)=0+1+4+12=17$.
3. The normal equations are $4a+6b=7$ and $6a+14b=17$. Multiply the first equation by $3/2$: $6a+9b=21/2$.
4. Subtract this equation from the second: $(6a+14b)-(6a+9b)=17-21/2$, so $5b=(34-21)/2=13/2$ and $b=(13/2)/5=13/10$.
5. Substitute into $4a+6b=7$: $4a=7-6(13/10)=70/10-78/10=-8/10=-4/5$, so $a=(-4/5)/4=-1/5$.
6. Therefore the fitted line is $\hat y=a+bx=-1/5+(13/10)x$.
**Check:** The fitted values at $x=0,1,2,3$ are $(-2,11,24,37)/10$, giving residuals $(2,-1,-4,3)/10$. Their sum is $0$ and their $x$-weighted sum is $(-1-8+9)/10=0$.
::::

:::

:::problem[Problem 6.35 — Quadratic design matrix]{difficulty=standard}
Write the design matrix $A$ and observation vector $b$ for a quadratic fit to $(0,1),(1,3),(2,5)$, and identify whether an exact fit exists.

::::solution[Solution]
**Answer:** $A=\begin{bmatrix}1&0&0\\1&1&1\\1&2&4\end{bmatrix}$, $b=(1,3,5)^T$; the exact polynomial is $y=1+2x$ with quadratic coefficient zero.

1. A quadratic model has form $y=a+bx+cx^2$. Each design row at coordinate $x$ is $[1,x,x^2]$ because these multiply the unknown coefficients $(a,b,c)^T$.
2. At $x=0$, the row is $[1,0,0]$ and the observation is $1$. At $x=1$, the row is $[1,1,1]$ and the observation is $3$.
3. At $x=2$, the row is $[1,2,4]$ because $2^2=4$ and the observation is $5$. Thus $A=\begin{bmatrix}1&0&0\\1&1&1\\1&2&4\end{bmatrix}$ and $b=(1,3,5)^T$.
4. Solve the three equations $a=1$, $a+b+c=3$, and $a+2b+4c=5$. Substituting $a=1$ gives $b+c=2$ and $2b+4c=4$.
5. Double the first reduced equation: $2b+2c=4$. Subtract it from $2b+4c=4$ to obtain $2c=0$, so $c=0$. Then $b+0=2$, hence $b=2$.
**Check:** $A(1,2,0)^T=(1,1+2,1+2(2))^T=(1,3,5)^T=b$, so the quadratic fit is exact and has zero quadratic coefficient.
::::

:::

:::problem[Problem 6.36 — Regression true/false traps]{difficulty=challenge}
True or false: (a) any polynomial in $x$ is a nonlinear model in its coefficients; (b) a line with an intercept has residuals summing to zero; (c) one may fit distinct data with fewer coefficients than observations; (d) the least-squares line always passes through every observed point.

::::solution[Solution]
**Answer:** F, T, T, F.

1. (a) The polynomial $a+bx+cx^2$ is linear in $a,b,c$ despite curvature in $x$.

2. (b) The dot product of the residual with the all-ones column is zero.

3. (c) This is the typical overdetermined setting for least squares.

4. (d) An exact fit is possible only for suitably aligned data; generally the residuals do not all vanish.
::::

:::

## Chapter Summary

:::summary[The six tools, their tests, and their uses]
**Inner products** are $u\cdot v=\sum u_iv_i$. Length is $\|v\|=\sqrt{v\cdot v}$; distance is $\|u-v\|$; a unit direction is $v/\|v\|$ for $v\ne0$. Orthogonal vectors have $u\cdot v=0$. Pythagoras is $\|u+v\|^2=\|u\|^2+\|v\|^2$ **if and only if** $u\perp v$.

**Orthogonal complements:** $(\Row A)^\perp=\Nul A\subseteq\R^n$; $(\Col A)^\perp=\Nul A^T\subseteq\R^m$ for $A\in\R^{m\times n}$. For a subspace $W\subseteq\R^n$, $\dim W+\dim W^\perp=n$. Make the generators of $W$ into matrix rows to solve for $W^\perp$.

**Orthogonal-basis weights:** If $y=\sum c_iu_i$ is in the span of orthogonal nonzero vectors, $c_i=(y\cdot u_i)/(u_i\cdot u_i)$. For an orthonormal basis $q_i$, $c_i=y\cdot q_i$. An orthogonal nonzero set is independent. Orthonormal columns satisfy $U^TU=I$. Only square orthogonal matrices satisfy $U^{-1}=U^T$.

**Projection:** $\proj_uy=((y\cdot u)/(u\cdot u))u$. For an orthogonal basis of $W$, $\proj_Wy=\sum_i((y\cdot u_i)/(u_i\cdot u_i))u_i$. Always write $y=\hat y+e$ with $\hat y\in W$ and $e\in W^\perp$. The distance is $\|e\|$, not $\|\hat y\|$. For a plane $n\cdot x=0$, $\operatorname{dist}(y,W)=|n\cdot y|/\|n\|$.

**Gram–Schmidt:** $v_1=x_1$ and $v_k=x_k-\sum_{j<k}((x_k\cdot v_j)/(v_j\cdot v_j))v_j$. Normalize $q_k=v_k/\|v_k\|$ to make $Q$. Reduced QR is $A=QR$ with $R=Q^TA$ upper triangular, and for full column rank $R\hat x=Q^Tb$ computes least squares.

**Normal equations:** $A^TA\hat x=A^Tb$ are always consistent and yield the projection $A\hat x=\proj_{\Col A}b$. The error is $\|b-A\hat x\|$, with residual test $A^T(b-A\hat x)=0$. Unique coefficients require independent columns. If rank is deficient, there may be many coefficient vectors but the fitted vector is unique.

**Regression:** For $y=\beta_0+\beta_1x$, each design row is $(1,x_i)$. Summation equations are $m\beta_0+(\sum x_i)\beta_1=\sum y_i$ and $(\sum x_i)\beta_0+(\sum x_i^2)\beta_1=\sum x_iy_i$. A polynomial in $x$ remains a linear least-squares model when it is linear in its unknown coefficients.

**Written-test checkpoint:** Identify the **space**; state the correct formula; show every dot product or matrix entry; reduce fractions; write the final answer in the asked form; and verify with either a perpendicularity dot product, $A^Te=0$, $QR=A$, or a fitted-value check.
:::

## Mixed Practice

These problems deliberately alternate between topics. Try each before opening its solution. The symmetric-matrix problem is in the appendix because it belongs to chapter seven of Lay of Lay.

:::problem[Problem M.1 — Dot product, distance, projection]{difficulty=easy}
Let $a=(1,2,3)^T$, $b=(2,-1,0)^T$. Compute $a\cdot b$, $\|a-b\|$, and $\proj_ba$.

::::solution[Solution]
**Answer:** $a\cdot b=0$, distance $\sqrt{19}$, projection $(0,0,0)^T$.

1. Use the dot-product definition, multiplying corresponding coordinates: $a\cdot b=1(2)+2(-1)+3(0)=2-2+0=0$.
2. Distance is the norm of the difference. Subtract coordinate by coordinate: $a-b=(1-2,2-(-1),3-0)^T=(-1,3,3)^T$.
3. Square and add: $\|a-b\|^2=(-1)^2+3^2+3^2=1+9+9=19$, so $\|a-b\|=\sqrt{19}$.
4. Project $a$ onto the nonzero direction $b$ using $\operatorname{proj}_ba=((a\cdot b)/(b\cdot b))b$. Here $b\cdot b=2^2+(-1)^2+0^2=4+1=5$.
5. The projection coefficient is $0/5=0$, so $\operatorname{proj}_ba=0(2,-1,0)^T=(0,0,0)^T$.
**Check:** $a\cdot b=0$ means $a$ is already perpendicular to the line through $b$, so its projection onto that line must be zero.
::::

:::

:::problem[Problem M.2 — Nonorthogonal generators require orthogonalization]{difficulty=standard}
Let $W=\span\{(1,2,-1)^T,(3,0,1)^T\}$ and $y=(1,0,0)^T$. Project $y$ onto $W$. Are the generators orthogonal? If not, apply Gram–Schmidt.

::::solution[Solution]
**Answer:** the original generators are **not** orthogonal, and $\proj_Wy=(13/14,1/7,3/14)^T$.

1. Dot test gives $3-1=2\ne0$.

2. Set $v_1=(1,2,-1)$, so $v_1\cdot v_1=6$.

3. Then $v_2=(3,0,1)-(2/6)(1,2,-1)=(8/3,-2/3,4/3)$ and $v_2\cdot v_2=(64+4+16)/9=84/9=28/3$.

4. Coefficients for projecting $y$ are $(y\cdot v_1)/6=1/6$ and $(y\cdot v_2)/(28/3)=(8/3)/(28/3)=2/7$.

5. Thus $\hat y=(1/6)(1,2,-1)+(2/7)(8/3,-2/3,4/3)=(1/6+16/21,1/3-4/21,-1/6+8/21)=(13/14,1/7,3/14)$.

6. The original draft's final vector $(43/42,3/7,1/14)$ was an arithmetic mistake: the component fractions actually simplify as shown.

7. Residual $(1/14,-1/7,-3/14)$ dots to zero with both generators.
::::

:::

:::problem[Problem M.3 — Regression from four observations]{difficulty=standard}
Find the least-squares line through $(0,0),(1,3),(2,4),(3,5)$. Give the slope and intercept.

::::solution[Solution]
**Answer:** $\hat y=3/5+(8/5)x$.

1. Here $m=4$, $\sum x=6$, $\sum x^2=14$, $\sum y=12$, $\sum xy=0+3+8+15=26$.

2. So $4a+6b=12$ and $6a+14b=26$.

3. Multiply the first by $3/2$: $6a+9b=18$.

4. Subtract to get $5b=8$, hence $b=8/5$.

5. Substitute back: $4a=12-6(8/5)=12/5$, so $a=3/5$.

6. The original mixed solution wrongly changed the elimination right-hand side from $8$ to $5$ and obtained an incorrect line.
::::

:::

:::problem[Problem M.4 — True/false about projections]{difficulty=standard}
Justify: (a) if $u\perp v$, then $\|u+v\|=\|u\|+\|v\|$; (b) $\proj_Wy\in W$; (c) a projection matrix $P$ satisfies $P^2=P$; (d) every real symmetric matrix is orthogonally diagonalizable.

::::solution[Solution]
**Answer:** F, T, T, T.

1. (a) Pythagoras adds **squared** lengths, not lengths; take perpendicular unit vectors to get $\sqrt2\ne2$.

2. (b) This is the definition of the projection's destination.

3. (c) A second projection changes nothing because the first output is already in $W$.

4. (d) This is the Spectral Theorem from chapter seven of Lay of Lay, explained in the appendix below; it is a true statement but not a required Chapter 6 technique.
::::

:::

:::problem[Problem M.5 — Least-squares error from normal equations]{difficulty=challenge}
A fit has $\begin{bmatrix}5&10\\10&30\end{bmatrix}\hat\beta=(14,32)^T$, $\|b\|^2=60$, and $\|\hat b\|^2=\hat\beta^TA^Tb$. Find $\hat\beta$ and the error.

::::solution[Solution]
**Answer:** $\hat\beta=(2,2/5)^T$ and error $\sqrt{96/5}$.

1. Eliminate in the augmented system: subtract twice row one from row two to obtain $[0\;10\mid4]$, hence $\beta_1=4/10=2/5$.

2. Row one gives $5\beta_0+10(2/5)=14$, so $5\beta_0=10$ and $\beta_0=2$.

3. Now $\|\hat b\|^2=2(14)+(2/5)(32)=28+64/5=204/5$.

4. Error squared is $60-204/5=(300-204)/5=96/5$.

5. Thus error $\sqrt{96/5}=4\sqrt{30}/5$.

6. Decimal rounding to about $4.38$ is unnecessary on a no-calculator test.
::::

:::

:::problem[Problem M.6 — Orthogonal complement by elimination]{difficulty=easy}
Find $W^\perp$ for $W=\span\{(1,0,1)^T,(0,1,1)^T\}$.

::::solution[Solution]
**Answer:** $W^\perp=\span\{(-1,-1,1)^T\}$.

1. A vector $z=(a,b,c)^T$ lies in $W^\perp$ when its dot product with each spanning vector of $W$ is zero.
2. Expand the conditions: $(1,0,1)\cdot(a,b,c)=a+c=0$ and $(0,1,1)\cdot(a,b,c)=b+c=0$.
3. These are the homogeneous system $\begin{bmatrix}1&0&1\\0&1&1\end{bmatrix}(a,b,c)^T=0$. The matrix already has pivots in the first two columns, so $c$ is free.
4. Set $c=t$. The first equation yields $a=-t$, while the second yields $b=-t$. Consequently $z=t(-1,-1,1)^T$, which has one free parameter and gives a basis.
**Check:** $(1,0,1)\cdot(-1,-1,1)=-1+1=0$ and $(0,1,1)\cdot(-1,-1,1)=-1+1=0$.
::::

:::

:::problem[Problem M.7 — Find an orthonormal set]{difficulty=standard}
Normalize the pair $u=(2,0,0)^T$, $v=(0,-3,0)^T$, then find the weights of $y=(4,6,1)^T$ on their span.

::::solution[Solution]
**Answer:** $q_1=(1,0,0)^T$, $q_2=(0,-1,0)^T$; weights $4,-6$.

1. Check the pair is orthogonal: $u\cdot v=2(0)+0(-3)+0(0)=0$. Normalize each direction separately.
2. Compute $\|u\|=\sqrt{2^2+0^2+0^2}=2$, so $q_1=u/2=(1,0,0)^T$.
3. Compute $\|v\|=\sqrt{0^2+(-3)^2+0^2}=3$, so $q_2=v/3=(0,-1,0)^T$.
4. For an orthonormal basis, projection weights are dot products: $c_1=y\cdot q_1=4(1)+6(0)+1(0)=4$ and $c_2=y\cdot q_2=4(0)+6(-1)+1(0)=-6$.
5. Form the projection $c_1q_1+c_2q_2=4(1,0,0)^T-6(0,-1,0)^T=(4,6,0)^T$. The unused component is $(0,0,1)^T$.
**Check:** $q_i\cdot q_j$ is $1$ when $i=j$ and $0$ otherwise, and the residual $(0,0,1)^T$ is perpendicular to both basis vectors.
::::

:::

:::problem[Problem M.8 — From a QR decomposition to coefficients]{difficulty=standard}
For $Q=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$ and $R=\begin{bmatrix}1&2\\0&2\end{bmatrix}$, solve the least-squares problem $(QR)x\approx(5,4,3)^T$.

::::solution[Solution]
**Answer:** $\hat x=(1,2)^T$, error $3$.

1. Because $Q$ has orthonormal columns, reduce the least-squares problem $(QR)x\approx b$ to the triangular system $Rx=Q^Tb$.
2. Multiply $Q^T=\begin{bmatrix}1&0&0\\0&1&0\end{bmatrix}$ by $b=(5,4,3)^T$ to get $Q^Tb=(5,4)^T$.
3. Write the equations from $\begin{bmatrix}1&2\\0&2\end{bmatrix}(x_1,x_2)^T=(5,4)^T$: $x_1+2x_2=5$ and $2x_2=4$.
4. Back-substitute: $x_2=4/2=2$, then $x_1=5-2(2)=5-4=1$.
5. Check the prediction using $QR=\begin{bmatrix}1&2\\0&2\\0&0\end{bmatrix}$: $QR(1,2)^T=(1+4,4,0)^T=(5,4,0)^T$.
6. Subtract from the observations to get $e=b-QR\hat x=(5-5,4-4,3-0)^T=(0,0,3)^T$, whose length is $\sqrt{0+0+9}=3$.
**Check:** $Q^Te=(0,0)^T$, so the residual is perpendicular to the design columns, as least squares requires.
::::

:::

:::problem[Problem M.9 — One-dimensional projection and distance]{difficulty=easy}
Project $y=(3,4)^T$ onto the line generated by $u=(1,0)^T$, then give the distance to that line.

::::solution[Solution]
**Answer:** projection $(3,0)^T$, distance $4$.

1. For a line generated by a nonzero vector $u$, use the projection formula $\hat y=((y\cdot u)/(u\cdot u))u$.
2. Compute the numerator: $y\cdot u=3(1)+4(0)=3+0=3$. The denominator is $u\cdot u=1^2+0^2=1$.
3. Divide to get the coefficient $3/1=3$, then multiply $u$: $\hat y=3(1,0)^T=(3,0)^T$.
4. The residual is $e=y-\hat y=(3-3,4-0)^T=(0,4)^T$. Its length, the distance to the line, is $\sqrt{0^2+4^2}=\sqrt{16}=4$.
**Check:** $e\cdot u=0(1)+4(0)=0$, so the displacement from the line is perpendicular to it.
::::

:::

:::problem[Problem M.10 — Full-column-rank trap]{difficulty=standard}
Given $A=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$ and $b=(2,3,5)^T$, state the least-squares coefficient vector and least-squares error.

::::solution[Solution]
**Answer:** $\hat x=(2,3)^T$, error $5$.

1. The two columns of $A$ are $a_1=(1,0,0)^T$ and $a_2=(0,1,0)^T$. Compute $A^TA$ from their dot products: $a_1\cdot a_1=1$, $a_1\cdot a_2=0$, and $a_2\cdot a_2=1$.
2. Thus $A^TA=\begin{bmatrix}1&0\\0&1\end{bmatrix}=I_2$. The normal equations $(A^TA)\hat x=A^Tb$ reduce to $\hat x=A^Tb$.
3. Multiply $A^T=\begin{bmatrix}1&0&0\\0&1&0\end{bmatrix}$ by $b=(2,3,5)^T$: $A^Tb=(1(2)+0(3)+0(5),0(2)+1(3)+0(5))^T=(2,3)^T$.
4. The fitted vector is $A\hat x=(2,3,0)^T$. Subtract it from $b$ to get the residual $(0,0,5)^T$, whose length is $\sqrt{0^2+0^2+5^2}=5$.
**Check:** $A^T(b-A\hat x)=A^T(0,0,5)^T=(0,0)^T$, satisfying both normal equations.
::::

:::

:::problem[Problem M.11 — Find a perpendicular direction]{difficulty=challenge}
Find a basis for $(\Col A)^\perp$ if $A=\begin{bmatrix}1&0\\1&1\\0&1\end{bmatrix}$. Explain why your answer lies in $\R^3$, not $\R^2$.

::::solution[Solution]
**Answer:** $(\Col A)^\perp=\span\{(1,-1,1)^T\}$.

1. Since the columns of the $3\times2$ matrix $A$ are vectors in $\mathbb R^3$, their orthogonal complement also lies in $\mathbb R^3$. Use $(\Col A)^\perp=\Nul(A^T)$.
2. Transpose to get $A^T=\begin{bmatrix}1&1&0\\0&1&1\end{bmatrix}$. Solve $A^Tz=0$ for $z=(z_1,z_2,z_3)^T$.
3. Multiply out the rows: $z_1+z_2=0$ and $z_2+z_3=0$. The first two columns have pivots, so let the free variable $z_3=t$.
4. Back-substitute into the second equation: $z_2+t=0\Rightarrow z_2=-t$. Then the first becomes $z_1-t=0\Rightarrow z_1=t$.
5. Therefore $z=(t,-t,t)^T=t(1,-1,1)^T$; setting $t=1$ gives a basis generator for the one-dimensional complement.
**Check:** $A^T(1,-1,1)^T=(1-1,-1+1)^T=(0,0)^T$, and $\dim(\Col A)^\perp=3-2=1$.
::::

:::

:::problem[Problem M.12 — Interpret residual orthogonality]{difficulty=challenge}
Suppose $A=\begin{bmatrix}1&0\\1&1\\1&2\end{bmatrix}$, $b=(1,3,2)^T$, and $\hat x$ is its least-squares solution. Find $\hat x$ and check the two residual dot products.

::::solution[Solution]
**Answer:** $\hat x=(3/2,1/2)^T$; $e=(-1/2,1,-1/2)^T$ and $A^Te=(0,0)^T$.

1. Compute $A^TA=\begin{bmatrix}3&3\\3&5\end{bmatrix}$ and $A^Tb=(6,7)^T$.

2. The equations $3a+3b=6$ and $3a+5b=7$ differ by $2b=1$, so $b=1/2$.

3. Then $3a=6-3/2=9/2$, so $a=3/2$.

4. Predictions at $x=0,1,2$ are $(3/2,2,5/2)$.

5. Thus residuals are $(1-3/2,3-2,2-5/2)=(-1/2,1,-1/2)$.

6. Dot with the all-ones column: $-1/2+1-1/2=0$.

7. Dot with the predictor column $(0,1,2)$: $0+1-1=0$.
::::

:::

## Beyond the course: Symmetric Matrices

*This material belongs to chapter seven of Lay of Lay and is beyond the Chapter 6 projection and regression sequence.* A **real symmetric** matrix satisfies $S^T=S$. Its eigenvalues are real, and eigenvectors corresponding to **distinct** eigenvalues are perpendicular. The **Spectral Theorem** says there is an orthogonal $P$ and real diagonal $D$ such that $S=PDP^T$. If $P$ has unit eigenvectors $u_i$ as columns, then $S=\sum_i\lambda_i u_iu_i^T$. These one-dimensional operators are geometric projections weighted by eigenvalues.

:::example[Example 6.25 — Symmetric matrix with two distinct eigenvalues]
Orthogonally diagonalize $S=\begin{bmatrix}3&-2\\-2&3\end{bmatrix}$.

::::answer[Answer]
**Answer:** $P=\frac1{\sqrt2}\begin{bmatrix}1&1\\1&-1\end{bmatrix}$, $D=\operatorname{diag}(1,5)$, and $S=PDP^T$.

1. Compute $\det(S-\lambda I)=(3-\lambda)^2-4=\lambda^2-6\lambda+5=(\lambda-1)(\lambda-5)$.

2. For $\lambda=1$, $S-I=\begin{bmatrix}2&-2\\-2&2\end{bmatrix}$ gives $x_1=x_2$; choose $(1,1)/\sqrt2$.

3. For $\lambda=5$, $S-5I=\begin{bmatrix}-2&-2\\-2&-2\end{bmatrix}$ gives $x_1=-x_2$; choose $(1,-1)/\sqrt2$.

4. The normalized eigenvectors are perpendicular and form the columns of $P$.

5. The corresponding eigenvalues go on $D$'s diagonal **in the same order**.
::::

:::

:::example[Example 6.26 — Repeated eigenvalue]
Orthogonally diagonalize $S=\begin{bmatrix}5&0&0\\0&1&2\\0&2&4\end{bmatrix}$.

::::answer[Answer]
**Answer:** $D=\operatorname{diag}(0,5,5)$ and $P=[u_0\;u_5\;w_5]$, with $u_0=(0,-2,1)^T/\sqrt5$, $u_5=(1,0,0)^T$, and $w_5=(0,1,2)^T/\sqrt5$.

1. Expand along the first row: $\det(S-\lambda I)=(5-\lambda)[(1-\lambda)(4-\lambda)-4]=(5-\lambda)(\lambda^2-5\lambda)=-\lambda(5-\lambda)^2$.

2. Thus eigenvalues are $0,5,5$.

3. For zero, equations give $x_1=0$, $x_2=-2x_3$; choose $(0,-2,1)$.

4. For five, the only independent constraint is $-4x_2+2x_3=0$, so $x_1$ and $x_2$ are free; choose $(1,0,0)$ and $(0,1,2)$.

5. Normalize and check all pairwise dots vanish.

6. The repeated eigenvalue has a **two-dimensional eigenspace**, so two eigenvectors must be included.
::::

:::

:::problem[Problem 6.37 — Symmetric diagonalization]{difficulty=standard}
Orthogonally diagonalize $S=\begin{bmatrix}6&2\\2&3\end{bmatrix}$.

::::solution[Solution]
**Answer:** $P=\frac1{\sqrt5}\begin{bmatrix}1&2\\-2&1\end{bmatrix}$, $D=\operatorname{diag}(2,7)$.

1. A real symmetric matrix admits orthogonal diagonalization. Find eigenvalues from $\det(S-\lambda I)=(6-\lambda)(3-\lambda)-2(2)$.
2. Expand and factor: $18-6\lambda-3\lambda+\lambda^2-4=\lambda^2-9\lambda+14=(\lambda-2)(\lambda-7)$. Thus the eigenvalues are $2$ and $7$.
3. For $\lambda=2$, $S-2I=\begin{bmatrix}4&2\\2&1\end{bmatrix}$. The first-row equation $4x_1+2x_2=0$ reduces to $2x_1+x_2=0$, so choose $v_1=(1,-2)^T$.
4. For $\lambda=7$, $S-7I=\begin{bmatrix}-1&2\\2&-4\end{bmatrix}$. The first-row equation $-x_1+2x_2=0$ gives $x_1=2x_2$, so choose $v_2=(2,1)^T$.
5. Both norms are $\sqrt{1^2+(-2)^2}=\sqrt5$ and $\sqrt{2^2+1^2}=\sqrt5$; their dot product is $1(2)+(-2)(1)=0$. Normalize and form $P=(1/\sqrt5)\begin{bmatrix}1&2\\-2&1\end{bmatrix}$ and matching $D=\operatorname{diag}(2,7)$.
**Check:** $Sv_1=(2,-4)^T=2v_1$, $Sv_2=(14,7)^T=7v_2$, and $P^TP=I$, hence $P^TSP=D$.
::::

:::

:::problem[Problem 6.38 — Powers and the correct spectral bound]{difficulty=challenge}
For a symmetric $S$ with eigenvalues $\lambda_1\ge\cdots\ge\lambda_n$ and orthonormal eigenvectors $u_i$, express $S^k$ and bound $\|Sx\|$ for any $x$.

::::solution[Solution]
**Answer:** $S^k=\sum_{i=1}^n\lambda_i^k u_iu_i^T$ and $\|Sx\|\le (\max_i|\lambda_i|)\|x\|$.

1. Write $S=PDP^T$.

2. Because $P^TP=I$, multiplying two copies gives $S^2=PD^2P^T$; induction yields $S^k=PD^kP^T$ and the sum formula.

3. Expand $x=\sum_i c_iu_i$, so $Sx=\sum_i\lambda_ic_iu_i$ and $\|Sx\|^2=\sum_i\lambda_i^2 c_i^2\le (\max_i|\lambda_i|)^2\sum_i c_i^2$.

4. The **original draft's $|\lambda_1|$ bound was false** under algebraic ordering alone: $\lambda_1=1$, $\lambda_n=-5$ is a counterexample.

5. The correct bound uses maximum **absolute** eigenvalue.
::::

:::
