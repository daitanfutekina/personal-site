---
source: "markdown"
title: "Chapter 5 Quiz Study Guide: Eigenvalues and Applications"
crumb: "Linear Algebra · Chapter 5 quiz prep"
meta:
  - "MA 3113 · Pant · Lay 6th edition"
  - "No calculator · Quiz 1: November 13 · Quiz 2: November 16, 2026"
  - "Sections 5.1–5.3, 5.5, 5.7, 5.9"
---

## Overview

Pant's written questions reward a short, justified chain of algebra, not an impressive amount of algebra. The central question for every calculation is: **what is the question asking for?** Checking a proposed vector is one multiplication. Checking a proposed eigenvalue is one null-space test or determinant. Finding *all* eigenvalues is a characteristic polynomial. Finding eigenspaces requires solving a homogeneous system. A diagonalization requires enough independent eigenvectors, ordered alongside their eigenvalues. Applications reuse these same calculations with one extra condition: an initial value for differential equations, or a sum of one for a probability vector.

These notes use the convention in Chapter 5: the characteristic polynomial is $\det(A-\lambda I)$; Markov matrices are **column-stochastic**; and $\mathbf{x}'=A\mathbf{x}$ means a time-dependent vector whose derivative equals its matrix product. Arithmetic is small enough to do without a calculator. A solution that identifies the right shortcut can be shorter and better than a solution with thirty unnecessary row operations.

### Use the guide like a written quiz, not like a page to memorise

On a first pass, cover the worked answers and read only the given data. Say aloud which of the seven families the problem belongs to. Then write its **first** calculation. That single decision matters more than remembering the entire procedure: someone who forms $A-2I$ immediately when a vector was already supplied will waste time even if the arithmetic is perfect. After checking the example, redo it with a different small number in the matrix. This tests whether the technique transferred or whether you merely remembered the displayed result.

For an especially efficient review, separate mistakes into three groups. A **recognition error** means you chose the wrong tool, such as a determinant when multiplication was enough. An **algebra error** means the tool was right but a signed cofactor or fraction was wrong. A **conclusion error** means your arithmetic was correct but you stated the wrong mathematical object, such as giving eigenvalues instead of a basis or giving a null-space direction without normalising its probability entries. Fix these categories differently: practise identification for recognition errors, redo two-line arithmetic for algebra errors, and rehearse the final definition for conclusion errors.

Pant's earlier assessments used extended written justification, so the free-response steps deserve special attention even when a practice set also contains multiple-choice items. A correct final number without visible pivot/free-variable work is much harder to defend than a short computation with named reasons. Conversely, do not copy every row operation from a textbook solution onto an exam when a single obvious equation already determines the null space. The goal is an argument that the instructor can verify line by line, with no unnecessary branches.

:::callout-key[First choose the target]
A **given vector**: multiply $A\mathbf v$. A **given scalar**: check whether $A-\lambda I$ is singular. **Every eigenvalue**: find $\det(A-\lambda I)=0$. An **eigenspace basis**: solve $(A-\lambda I)\mathbf x=\mathbf0$. **Diagonalize**: collect $n$ independent eigenvectors, or prove that you cannot. A **differential system**: add exponential factors and fit the initial vector. A **Markov steady state**: solve $(P-I)\mathbf q=\mathbf0$ and make the coordinates add to one.
:::

## 5.1 Eigen-Definition Checks

:::callout-intuition[An unchanged direction, not an unchanged vector]
Most vectors are sent to new directions by a matrix. An eigenvector is special because its image remains on its original line. It may stretch, shrink, reverse direction, or collapse to zero. If $A\mathbf v=3\mathbf v$, the vector triples; if $A\mathbf v=-2\mathbf v$, it reverses and doubles in length; if $A\mathbf v=\mathbf0$, then zero is its eigenvalue even though $\mathbf v$ itself is nonzero. The zero vector is excluded because every matrix sends zero to zero, and so it would make every number look like an eigenvalue.
:::

### Recognise exactly which definition is being tested

A statement such as "Is this **vector** an eigenvector?" supplies the vector. Do not start by factoring a polynomial. Multiply the matrix by that vector and ask whether the result is one common multiple of it. A statement such as "Is $3$ an eigenvalue?" supplies a **number**, not necessarily a vector. Either test $\det(A-3I)=0$ or solve $(A-3I)\mathbf x=\mathbf0$ and show a nonzero solution. The second method becomes especially useful if the question also asks for a basis. Beware a coordinate of zero: division by that coordinate is illegal, but the direct equation $A\mathbf v=\lambda\mathbf v$ still works perfectly.

The equivalence is a direct algebra move, not a memorised trick:

$$
A\mathbf v=\lambda\mathbf v
\quad\Longleftrightarrow\quad
A\mathbf v-\lambda I\mathbf v=\mathbf0
\quad\Longleftrightarrow\quad
(A-\lambda I)\mathbf v=\mathbf0.
$$

A number $\lambda$ is an eigenvalue only if this equation has a **nonzero** solution. That is exactly when $A-\lambda I$ is not invertible. Therefore, a proposed eigenvalue can also be checked with a zero determinant. The Invertible Matrix Theorem ties together the determinant, nontrivial null space, and singularity. In particular, $0$ is an eigenvalue of $A$ precisely when $A$ itself is singular.

### Shortest written method

1. Write the proposed $\lambda$ and nonzero $\mathbf v$; decide whether the problem gives a vector or only a scalar.
2. If the vector is given, calculate $A\mathbf v$ one row at a time.
3. Compare *all* components with $\lambda\mathbf v$, including any zero components.
4. State yes or no and display the decisive equality or mismatch. If only a scalar is given, substitute into $A-\lambda I$ and find a nontrivial null-space vector or a zero determinant.

:::example[Example 5.1 — Check a proposed eigenpair]
For

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix},\qquad
\mathbf v=\begin{bmatrix}1\\0\end{bmatrix},
$$

is $\mathbf v$ an eigenvector with eigenvalue $2$?

::::answer[Answer]
**Answer:** Yes; $\lambda=2$.

1. First confirm that the proposed vector is nonzero. Its first entry is $1$, so the definition permits it.
2. Multiply, using each row of $A$ rather than guessing from the diagonal:
   $$
   A\mathbf v=\begin{bmatrix}2(1)+1(0)\\0(1)+3(0)\end{bmatrix}
   =\begin{bmatrix}2\\0\end{bmatrix}.
   $$
3. The proposed multiple is
   $$
   2\mathbf v=2\begin{bmatrix}1\\0\end{bmatrix}
   =\begin{bmatrix}2\\0\end{bmatrix}.
   $$
4. Both coordinates agree. Because $A\mathbf v=2\mathbf v$ and $\mathbf v\ne\mathbf0$, the definition is satisfied. No determinant or row reduction was necessary.
5. Check the potentially misleading second coordinate: both sides are zero, so the zero entry creates no contradiction.
::::
:::

:::callout-pitfall[What loses points]
Calling $\mathbf0$ an eigenvector; comparing only one coordinate; dividing by a zero entry; and doing a full characteristic-polynomial calculation when the question already gives a proposed eigenvector. Conversely, finding one eigenvector does **not** automatically give you every eigenvalue. Read the verb in the question.
:::

**What earns the points:** the multiplication $A\mathbf v$, a comparison with $\lambda\mathbf v$, a statement that $\mathbf v\ne\mathbf0$, and an explicit yes/no conclusion. If the given object is only a scalar, show $A-\lambda I$ and why it has a free variable or zero determinant. A conclusion without the decisive algebra is a guess, even if correct.

## 5.2 Characteristic Polynomials and the Cofactor Shortcut

:::callout-intuition[Find precisely when a matrix loses an inverse]
For an arbitrary number $t$, the matrix $A-tI$ usually maps a nonzero vector to a nonzero result. Eigenvalues are the exceptional values where it destroys some nonzero direction. The determinant detects that event: it becomes zero exactly when the columns are dependent. Thus $\det(A-\lambda I)=0$ is not a magical equation imported from elsewhere; it is the ordinary test for whether a homogeneous system has a nonzero solution.
:::

### Recognise a polynomial problem

"Find the characteristic polynomial," "find every eigenvalue," "state algebraic multiplicities," and "show that $2$ is a root" belong here. Keep the sign convention straight: Chapter 5 writes $\det(A-\lambda I)$, not $\det(\lambda I-A)$. For a $3\times3$ matrix, these polynomials differ by a minus sign, though their roots agree. If you report the complete polynomial, its sign matters. The sum of the eigenvalues equals $\operatorname{tr}(A)$ and their product equals $\det A$, counting repeated roots. These checks are usually faster than redoing the expansion.

For a $2\times2$ matrix, subtract $\lambda$ only from the diagonal and use $ad-bc$:

$$
\det\begin{bmatrix}a-\lambda&b\\c&d-\lambda\end{bmatrix}
=(a-\lambda)(d-\lambda)-bc.
$$

For a triangular matrix, do not expand cofactors. The determinant is the product of the diagonal entries, so the eigenvalues are already displayed along the diagonal, repetitions included. If a triangular matrix has diagonal entries $2,2,-1$, then $\det(A-\lambda I)=(2-\lambda)^2(-1-\lambda)$ and $2$ has algebraic multiplicity two. The entries above or below its diagonal can change eigenvectors, but not its eigenvalues.

For a genuinely nontriangular $3\times3$ matrix, look for a row or column with zeros. The checkerboard cofactor signs are

$$
\begin{bmatrix}+&-&+\\-&+&-\\+&-&+\end{bmatrix}.
$$

A term from position $(i,j)$ equals its matrix entry multiplied by $(-1)^{i+j}$ and by the determinant of the remaining $2\times2$ matrix. Cross out the row and column *before* taking the small determinant. You never have to expand along the first row: choosing the sparsest line is legitimate and faster. If the row is $[0,0,5-\lambda]$, only one term survives. **Do not divide by $\lambda-2$ during symbolic row reduction:** at $\lambda=2$, that division is invalid and might erase the root you need.

### Shortest written method

1. Display $A-\lambda I$; subtract $\lambda$ from diagonal positions only.
2. If triangular, multiply its diagonal entries. Otherwise choose the row or column with most zeros, and write the surviving signed $2\times2$ determinant(s).
3. Expand $ad-bc$ in every minor. Expand the resulting polynomial before factoring, so the arithmetic can be graded.
4. Factor and solve the zero-product equation. Mark repeated roots and their multiplicities.
5. Check the sum against the trace and the product against $\det A$; for a $3\times3$ matrix the leading term should be $-\lambda^3$.

:::example[Example 5.2 — Sparse-column cofactor expansion]
Find the characteristic polynomial and eigenvalues of

$$
A=\begin{bmatrix}3&1&0\\1&3&0\\0&0&5\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\det(A-\lambda I)=-(\lambda-2)(\lambda-4)(\lambda-5)$; eigenvalues $2,4,5$.

1. Subtract $\lambda$ from the three diagonal entries:
   $$
   A-\lambda I=\begin{bmatrix}3-\lambda&1&0\\1&3-\lambda&0\\0&0&5-\lambda\end{bmatrix}.
   $$
2. Expand along column three. Its first two entries are zero, and the position $(3,3)$ has positive cofactor sign. The entire $3\times3$ determinant is therefore
   $$
   (5-\lambda)\det\begin{bmatrix}3-\lambda&1\\1&3-\lambda\end{bmatrix}.
   $$
3. Use $ad-bc$ in that minor:
   $$
   (5-\lambda)\big((3-\lambda)(3-\lambda)-1\big)
   =(5-\lambda)(\lambda^2-6\lambda+8).
   $$
4. Factor the quadratic: $\lambda^2-6\lambda+8=(\lambda-2)(\lambda-4)$. Reversing the first factor gives the stated negative-leading-cubic form.
5. Set each factor to zero. The eigenvalues are $2$, $4$, and $5$. Their sum is $11$, exactly $\operatorname{tr}(A)=3+3+5$, so the final list passes a quick check.
::::
:::

:::callout-pitfall[The standard cofactor failures]
Forgetting to subtract $\lambda$ from *all* diagonal entries; swapping the cofactor signs; forgetting the negative leading coefficient for a $3\times3$ $\det(A-\lambda I)$; expanding the wrong $2\times2$ minor; or trying to factor an unexpanded expression by inspection. Do not confuse algebraic multiplicity with the number of eigenvectors.
:::

**What earns the points:** the correct shifted matrix, the selected cofactor line and sign, the surviving minor(s) with $ad-bc$ shown, the simplified factorization, and every eigenvalue. If Pant asks only for eigenvalues of a triangular matrix, one line explaining the diagonal shortcut is better than a needless symbolic determinant.

## 5.3 Eigenspace Bases and Free Variables

:::callout-intuition[An eigenspace is a null space you already know]
The eigenvalue tells you the multiplier, but it does not tell you which vectors are multiplied that way. Those vectors are exactly the solutions of $(A-\lambda I)\mathbf x=\mathbf0$. This is your Chapter 4 null-space problem again. A single free variable gives an eigen-line, two free variables give an eigen-plane, and so on. The eigenspace includes zero because it is a subspace; the **eigenvectors** are the nonzero members of that space.
:::

### Recognise a basis question

"Find a basis for $E_2$," "find all eigenvectors associated with $3$," and "what is the geometric multiplicity?" all request null-space work. The supplied eigenvalue can be used immediately. Do not find it all over again unless specifically asked. A question that asks for *all* eigenspace bases requires repeating the null-space calculation for **each distinct eigenvalue**. Your final answer should be a collection of column vectors, not the reduced matrix itself.

Algebraic multiplicity means how often a root repeats in the characteristic polynomial. Geometric multiplicity means the number of independent eigenvectors for that root, equal to the dimension of the eigenspace. A repeated eigenvalue of algebraic multiplicity two can have geometric multiplicity one **or** two. Always count pivots and free variables instead of guessing from the repeated root. If the original matrix has three columns and $A-\lambda I$ has one pivot, there are two free variables and the eigenspace needs two basis vectors. Setting *both* free variables to one produces only a single combination and loses a basis direction.

### Shortest written method

1. Write $A-\lambda I$ for the requested $\lambda$.
2. Row-reduce with displayed integer arithmetic; stop as soon as the pivot equations are obvious.
3. Identify every pivot variable and every free variable. Write the pivot variables in terms of free variables.
4. Set one free variable to $1$ and the others to $0$ to obtain each basis column. Clear fractions if helpful.
5. State $E_\lambda=\operatorname{span}\{\ldots\}$ and its dimension. Optionally multiply $A\mathbf v$ to verify one basis vector.

:::example[Example 5.3 — Two independent eigendirections for one root]
Find a basis and dimension of $E_2$ for

$$
A=\begin{bmatrix}2&0&0\\0&2&0\\0&0&5\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\dim E_2=2$; basis columns $(1,0,0)^T,(0,1,0)^T$.

1. Subtract $2I$, not $\lambda I$ with a new unknown, because $\lambda=2$ is already supplied:
   $$
   A-2I=\begin{bmatrix}0&0&0\\0&0&0\\0&0&3\end{bmatrix}.
   $$
2. The homogeneous equation says $3x_3=0$, so $x_3=0$. Columns one and two have no pivots, which makes $x_1$ and $x_2$ free.
3. Set $x_1=1,x_2=0$ for the first basis vector, then $x_1=0,x_2=1$ for the second:
   $$
   E_2=\operatorname{span}\left\{\begin{bmatrix}1\\0\\0\end{bmatrix},\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}.
   $$
4. There are two independent free directions; therefore $\dim E_2=2$. The characteristic polynomial has factor $(2-\lambda)^2$, consistent with algebraic multiplicity two.
5. Check directly that $A$ doubles each displayed basis column. This verifies the claimed eigenspace without recalculating the determinant.
::::
:::

:::callout-pitfall[Null-space errors]
Dropping a free variable; reporting a single vector when the eigenspace is two-dimensional; reporting $\mathbf0$ as part of a basis; or reporting RREF rows as eigenvectors. Row operations preserve the **solution set** of $(A-\lambda I)\mathbf x=\mathbf0$, not the original matrix's eigenvectors if you row-reduce $A$ in isolation.
:::

**What earns the points:** the exact $A-\lambda I$, enough row operations to justify the pivot structure, the free-variable assignments, a properly written basis, and $\dim E_\lambda$. For a two-free-variable problem, both independent basis columns are essential. A check $A\mathbf v=\lambda\mathbf v$ is especially convincing when arithmetic is easy.

## 5.4 Diagonalization and the Failure Test

:::callout-intuition[Choose coordinates where the transformation stops mixing]
A diagonal matrix multiplies each coordinate independently. A complicated matrix may become diagonal if you measure vectors along its eigenvector directions instead of the usual coordinate axes. The columns of $P$ are those new basis directions. The diagonal entries of $D$ say how much the corresponding directions stretch. The equation $AP=PD$ simply says, column by column, that multiplying an eigenvector by $A$ has the same effect as multiplying it by its eigenvalue.
:::

### Recognise a diagonalization problem

Phrases include "find $P$ and $D$ such that $A=PDP^{-1}$," "is this matrix diagonalizable?", "use diagonalization to compute $A^k$," and "why does diagonalization fail?" The decisive issue is whether you have $n$ **linearly independent eigenvectors**. Distinct eigenvalues guarantee independent eigenvectors, but a repeated eigenvalue does not doom the matrix. Compare the dimension of each eigenspace with its algebraic multiplicity. In a $3\times3$ matrix, if a root repeats twice and yields only one independent eigenvector, only two independent eigenvectors are available overall. No invertible $P$ can be formed. Stop there and write the obstruction; inventing a third column would be wrong.

The order is not fixed: you may place eigenvectors in any order, **provided** the diagonal of $D$ uses the same order. If column two of $P$ is a vector for $\lambda=4$, then the second diagonal entry of $D$ must be $4$. The check $AP=PD$ directly catches a mismatch, and is usually less work than calculating $P^{-1}$. Only compute $P^{-1}$ when asked for it or when a power calculation genuinely requires it.

For powers, neighbouring factors cancel:

$$
A^k=(PDP^{-1})^k=PD^kP^{-1}.
$$

That is useful because $D^k$ merely raises its diagonal entries. **Do not** raise every entry of $A$ to the $k$th power. The factor $P^{-1}$ must stay on the right, not be moved across $D$. If an eigenvalue is zero, the matrix can still be diagonalizable, although its inverse does not exist.

### Shortest written method

1. Find eigenvalues, using a triangular shortcut if available.
2. Solve each $(A-\lambda I)\mathbf x=\mathbf0$ and count basis columns.
3. If the total number is below $n$, state "not diagonalizable" and cite the multiplicity gap.
4. Otherwise put the eigenvectors into $P$ and put matching eigenvalues on the diagonal of $D$.
5. Check $AP=PD$ and $\det P\ne0$. Use $PD^kP^{-1}$ only if a power is requested.

:::example[Example 5.4 — A correctly ordered diagonalization]
Diagonalize

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** Columns of $P$: $(1,0)^T,(1,1)^T$; diagonal of $D$: $2,3$; $AP=PD$.

1. The matrix is triangular, so its eigenvalues are $2$ and $3$. They are distinct, so two eigenvectors will be independent.
2. At $\lambda=2$, solve
   $$
   A-2I=\begin{bmatrix}0&1\\0&1\end{bmatrix},\qquad x_2=0.
   $$
   An eigenvector is the first standard column vector.
3. At $\lambda=3$, solve
   $$
   A-3I=\begin{bmatrix}-1&1\\0&0\end{bmatrix},\qquad x_1=x_2.
   $$
   An eigenvector has both coordinates equal to one.
4. Arrange the eigenvectors and their multipliers in precisely the same order:
   $$
   P=\begin{bmatrix}1&1\\0&1\end{bmatrix},\qquad
   D=\begin{bmatrix}2&0\\0&3\end{bmatrix}.
   $$
5. Verify by multiplication:
   $$
   AP=\begin{bmatrix}2&3\\0&3\end{bmatrix}
   =PD.
   $$
   Also $\det P=1$, so $P$ is invertible. The verification justifies $A=PDP^{-1}$ without calculating an inverse.
::::
:::

:::callout-pitfall[Two opposite bad shortcuts]
Do not claim a matrix with a repeated eigenvalue is automatically defective. Do not claim it is diagonalizable merely because you can list three roots **with repetition**. The question is whether you have three independent vectors. Also, never put a vector for $\lambda_1$ beside the diagonal entry $\lambda_2$; the order must match exactly.
:::

**What earns the points:** each eigenvalue and multiplicity, sufficient eigenspace work, a count of independent vectors, the proposed $P,D$ or a precise statement of failure, and $AP=PD$ when diagonalization succeeds. For a failure, one clear rank/nullity argument is more valuable than an attempted inverse.

## 5.5 Complex Eigenvalues and Rotation–Scaling

:::callout-intuition[Complex roots mean a rotating real plane]
A real matrix can rotate every real direction instead of leaving any one real line unchanged. Then it has no real eigenvectors, even though its characteristic polynomial still has roots over the complex numbers. The simplest example is a quarter-turn: no nonzero real vector points in its former direction after rotation. Complex eigenvalues package that turning motion with possible growth or shrinkage. A conjugate pair $a\pm bi$ describes rotation and a scale factor $\sqrt{a^2+b^2}$ in suitable real coordinates.
:::

### Recognise the complex question

Look for a $2\times2$ real matrix whose quadratic discriminant is negative, an explicit eigenvalue $a+bi$, a request for a complex eigenvector, or a request to write a real $2\times2$ rotation–scaling block. For any real matrix, nonreal eigenvalues and their eigenvectors occur in conjugate pairs. You do not have to solve the quadratic twice: once $a+bi$ is known, $a-bi$ follows. When asked for a complex eigenvector, use the same null-space equation $(A-\lambda I)\mathbf v=\mathbf0$, now allowing complex coefficients. Use $i^2=-1$ carefully.

**Sign convention matters.** Chapter 5 gives the real block

$$
C=\begin{bmatrix}a&-b\\b&a\end{bmatrix}
$$

when the complex eigenvalue is written $\lambda=a-bi$ and the corresponding eigenvector is $\mathbf v=\mathbf p+i\mathbf q$, with the real columns of $P$ ordered $[\mathbf p\ \mathbf q]$. To see why, expand the equation $A(\mathbf p+i\mathbf q)=(a-bi)(\mathbf p+i\mathbf q)$ and equate real and imaginary parts:

$$
A\mathbf p=a\mathbf p+b\mathbf q,
\qquad A\mathbf q=-b\mathbf p+a\mathbf q.
$$

Those are exactly the two columns of $AP=PC$. If you instead start with $a+bi$ and keep the same columns, the off-diagonal signs reverse. A sign mismatch in $C$ is a basis-order/convention issue, not an irrelevant cosmetic choice.

For a matrix already of the form $C$, the scale is $r=\sqrt{a^2+b^2}$. Its rotation angle satisfies $\cos\theta=a/r$ and $\sin\theta=b/r$. A positive $b$ is counterclockwise, a negative $b$ clockwise, in the displayed real coordinates. The real part of a continuous-time eigenvalue controls an ODE's exponential growth or decay; do not confuse that $a$ with the discrete-step scaling factor $r$.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 440 220" role="img" aria-label="An eigenvalue-free real rotation-scaling matrix sends a rightward vector to a longer counterclockwise-turned vector.">
<line class="fig-axis" x1="62" y1="155" x2="384" y2="155"/>
<line class="fig-axis" x1="158" y1="191" x2="158" y2="20"/>
<line class="fig-curve" x1="158" y1="155" x2="207" y2="155"/>
<path class="fig-arrow" d="M195 150 L207 155 L195 160"/>
<line class="fig-curve-alt" x1="158" y1="155" x2="256" y2="106"/>
<path class="fig-arrow" d="M243 107 L256 106 L248 117"/>
<text class="fig-label" x="212" y="166">v = (1, 0)</text>
<text class="fig-label" x="259" y="98">Av = (2, 1)</text>
</svg>
<figcaption>For the real matrix with entries $2,-1;1,2$, the rightward unit vector goes to an up-right vector. Its direction turns counterclockwise and its length is multiplied by $\sqrt5$. It is not a real eigenvector.</figcaption>
</figure>

### Shortest written method

1. Compute $\det(A-\lambda I)$ using $ad-bc$, then solve the quadratic.
2. If it has a negative discriminant, state both conjugate roots.
3. If an eigenvector is required, solve one complex homogeneous equation and obtain the conjugate vector for the other root.
4. If a real block is requested, identify the chosen sign convention for $\lambda$ and split $\mathbf v=\mathbf p+i\mathbf q$.
5. Form the real basis $P=[\mathbf p\ \mathbf q]$ and verify $AP=PC$; report scale and rotation only when asked.

:::example[Example 5.5 — A visible rotation and stretch]
Find the complex eigenvalues and real rotation–scaling block for

$$
A=\begin{bmatrix}2&-1\\1&2\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\lambda=2\pm i$; the real block is $A$ itself, with scale $\sqrt5$.

1. Form the characteristic determinant:
   $$
   \det(A-\lambda I)=\det\begin{bmatrix}2-\lambda&-1\\1&2-\lambda\end{bmatrix}
   =(2-\lambda)^2+1.
   $$
2. Set this equal to zero. Then $(2-\lambda)^2=-1$, so $2-\lambda=\pm i$. Therefore $\lambda=2\pm i$.
3. Compare $A$ with the real block. It has $a=2$ and $b=1$, giving
   $$
   C=\begin{bmatrix}2&-1\\1&2\end{bmatrix}.
   $$
4. The scaling factor is $\sqrt{2^2+1^2}=\sqrt5$. Since the lower-left entry is positive, the rotation is counterclockwise in this basis.
5. Check the roots: their sum $4$ matches the trace, and their product $(2+i)(2-i)=5$ matches $\det A=5$.
::::
:::

:::callout-pitfall[Complex-sign traps]
Changing $i^2=-1$ to $+1$; forgetting the conjugate root; using the sign-reversed off-diagonal block without checking which sign of the eigenvalue and which real basis order you selected; or describing the factor $a$ alone as the discrete rotation–scale factor. The actual scale is $\sqrt{a^2+b^2}$.
:::

**What earns the points:** the shifted determinant, both complex roots, a correctly solved complex null-space equation if required, the defined real basis, an explicitly signed real block, and a multiplication check $AP=PC$. You can gain most of the credit with correct complex arithmetic even if you forget the geometric interpretation.

## 5.6 Linear Differential Systems and Trajectory Types

:::callout-intuition[The eigenvector directions evolve without mixing]
For the system $\mathbf x'(t)=A\mathbf x(t)$, suppose the state starts exactly along an eigenvector $\mathbf v$ with eigenvalue $\lambda$. Then the solution can stay on that line while its length changes. The scalar equation $y'=\lambda y$ has solution $y=ce^{\lambda t}$, so the vector solution is $ce^{\lambda t}\mathbf v$. When there are enough independent eigenvectors, a general initial state is a sum of these independent modes. Each mode grows or decays at its own exponential rate.
:::

### Recognise the two tasks in an ODE question

"Solve $\mathbf x'=A\mathbf x$" means find the general solution with free constants. "Given $\mathbf x(0)=\mathbf x_0$" means also determine those constants. A question asking for "trajectory type" or "stability" may not require the explicit constants at all: inspect the eigenvalues first. Two negative real eigenvalues give an attracting node, two positive real eigenvalues a repelling node, and opposite signs a saddle. A nonreal conjugate pair with negative real part gives an inward spiral; with positive real part an outward spiral; a pure imaginary pair for a real $2\times2$ system gives a center of closed ellipses. Repeated or zero-real-part cases can require more information, so do not overgeneralise from a sign alone.

For a diagonalizable matrix whose eigenvectors are $\mathbf v_1,\mathbf v_2$, the form follows from differentiating each term:

$$
\mathbf x(t)=c_1e^{\lambda_1t}\mathbf v_1+c_2e^{\lambda_2t}\mathbf v_2.
$$

At $t=0$, both exponentials equal one. The initial condition becomes the ordinary linear system $c_1\mathbf v_1+c_2\mathbf v_2=\mathbf x_0$. In matrix terms, $P\mathbf c=\mathbf x_0$. Solve this two-variable system by substitution. Writing $P^{-1}$ is optional and usually slower. A useful check is to verify both $\mathbf x(0)=\mathbf x_0$ and $\mathbf x'=A\mathbf x$, at least in one coordinate.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 440 220" role="img" aria-label="A saddle flow has arrows toward the origin on one axis and away from the origin on the other.">
<line class="fig-axis" x1="58" y1="111" x2="380" y2="111"/>
<line class="fig-axis" x1="220" y1="198" x2="220" y2="22"/>
<line class="fig-curve" x1="95" y1="111" x2="186" y2="111"/>
<path class="fig-arrow" d="M175 106 L186 111 L175 116"/>
<line class="fig-curve" x1="347" y1="111" x2="255" y2="111"/>
<path class="fig-arrow" d="M266 106 L255 111 L266 116"/>
<line class="fig-curve-alt" x1="220" y1="107" x2="220" y2="40"/>
<path class="fig-arrow" d="M215 51 L220 40 L225 51"/>
<line class="fig-curve-alt" x1="220" y1="115" x2="220" y2="183"/>
<path class="fig-arrow" d="M215 172 L220 183 L225 172"/>
<text class="fig-label" x="106" y="98">decay</text>
<text class="fig-label" x="236" y="49">growth</text>
</svg>
<figcaption>For a diagonal system with one negative and one positive real eigenvalue, horizontal trajectories approach the origin, while vertical trajectories depart. The origin is a saddle because the behaviours differ by eigendirection.</figcaption>
</figure>

### Shortest written method

1. Find the eigenvalues, using the triangular diagonal if possible; find an eigenvector for each distinct real eigenvalue.
2. Write the vector exponential mode for each eigenpair and sum them with constants.
3. Substitute $t=0$ and solve for those constants using the components of the initial vector.
4. State the solution and the qualitative trajectory type, if asked.
5. Check the initial condition and differentiate one representative mode: the factor $\lambda$ should reproduce multiplication by $A$.

:::example[Example 5.6 — A system with one growing and one decaying direction]
Solve $\mathbf x'=A\mathbf x$ with

$$
A=\begin{bmatrix}-1&0\\0&2\end{bmatrix},\qquad
\mathbf x(0)=\begin{bmatrix}3\\1\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\mathbf x(t)=(3e^{-t},e^{2t})^T$; the origin is a saddle.

1. The matrix is diagonal. Its eigenvalues are $-1$ and $2$, with the first and second coordinate unit vectors as corresponding eigenvectors.
2. Write the two separate modes:
   $$
   \mathbf x(t)=c_1e^{-t}\begin{bmatrix}1\\0\end{bmatrix}
   +c_2e^{2t}\begin{bmatrix}0\\1\end{bmatrix}.
   $$
3. Evaluate at zero. Because $e^0=1$, the initial vector equation gives $c_1=3$ from the first coordinate and $c_2=1$ from the second.
4. Therefore
   $$
   \mathbf x(t)=\begin{bmatrix}3e^{-t}\\e^{2t}\end{bmatrix}.
   $$
   The first coordinate decays, while the second grows for increasing $t$; mixed signs make a saddle.
5. Check: $\mathbf x(0)$ equals the given vector, and differentiating gives\n   $$\n   \mathbf x'(t)=\begin{bmatrix}-3e^{-t}\\2e^{2t}\end{bmatrix}=A\mathbf x(t).\n   $$
::::
:::

:::callout-pitfall[ODE shortcuts that fail]
Forgetting the exponentials; plugging the initial vector into the *eigenvalue* equation instead of the linear combination of eigenvectors; assuming the coefficients are the coordinates of $\mathbf x_0$ before changing basis; or calling a saddle stable because one mode decays. Both modes matter. The eigenvalues do not always settle a zero-real-part or defective case without checking more structure.
:::

**What earns the points:** eigenvalues and eigenvectors when the system must be solved, correctly weighted exponential modes, a visible $t=0$ coefficient system, constants obtained from that system, and the verified final solution. For a classification-only question, give the eigenvalue signs and the corresponding trajectory name rather than unnecessarily solving the initial-value problem.

## 5.7 Markov Chains and the Steady State

:::callout-intuition[Repeated transitions preserve total probability]
A Markov chain keeps track of probabilities assigned to several states. In this chapter, each **column** of the transition matrix gives the destinations of the state named by that column. Thus a column sums to one: every unit of probability starting in that state must end somewhere. Multiplying by the transition matrix moves a probability vector forward one step. A steady state is a distribution that the transition leaves unchanged. Algebraically, it is an eigenvector for eigenvalue one, scaled to be a probability distribution.
:::

### Recognise transition versus steady state

"After one step" means $\mathbf x_1=P\mathbf x_0$; "after two steps" means $\mathbf x_2=P(P\mathbf x_0)$, which is $P^2\mathbf x_0$. "Long-run steady state" means solve $P\mathbf q=\mathbf q$ and force $\sum q_i=1$ with nonnegative entries. Do not assume the starting vector is itself the steady vector. Also do not assume a unique limiting distribution just because columns sum to one: the extra regularity condition, that some positive integer power of $P$ has all positive entries, guarantees uniqueness and convergence. A perfectly alternating two-state chain may have a steady vector but not converge to it from an arbitrary initial vector.

Write $P-I$ to bring the eigenvalue-one equation into null-space form. The rows of $P-I$ are dependent because a column-stochastic matrix always has eigenvalue one. Choose any convenient nonzero direction from its null space, then divide by the sum of its coordinates. If the direction has entries $(2,3)^T$, normalise it to $(2/5,3/5)^T$. Adding a sum-to-one equation directly to the homogeneous system is an equally good way to work. For three states, the same principle holds: find a null-space direction and divide by its coordinate sum.

The easiest orientation check is to read a transition aloud. The entry in row two, column one is the probability of arriving at state two **from state one**. If a question says 30% move from state one to state two, then the first column's second entry is $0.30$. This is the opposite of a row-stochastic convention used in some other courses; follow this chapter's column convention. If a matrix contains a negative entry, it is not stochastic even if the columns sum to one.

### Shortest written method

1. Check nonnegative entries and **column** sums if stochasticity is in question.
2. For a finite number of steps, multiply once per step and keep entries as exact fractions.
3. For steady state, form $P-I$ and solve $(P-I)\mathbf q=\mathbf0$.
4. Normalise the resulting nonnegative null-space direction so its entries add to one.
5. Check both $P\mathbf q=\mathbf q$ and the coordinate sum. If claiming convergence from every initial distribution, justify regularity or another suitable convergence condition.

:::example[Example 5.7 — Normalize an eigenvector into a probability vector]
Find the steady state for

$$
P=\begin{bmatrix}\frac34&\frac14\\\frac14&\frac34\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\mathbf q=(\frac12,\frac12)^T$.

1. Both columns sum to $1$ and all entries are nonnegative, so $P$ is a valid column-stochastic transition matrix.
2. Subtract the identity:
   $$
   P-I=\begin{bmatrix}-\frac14&\frac14\\\frac14&-\frac14\end{bmatrix}.
   $$
3. Multiply the first equation by four: $-q_1+q_2=0$, which gives $q_1=q_2$. A nonzero null-space direction is therefore the column of two ones.
4. Impose $q_1+q_2=1$. Because the two entries are equal, each is $\frac12$:
   $$
   \mathbf q=\begin{bmatrix}\frac12\\\frac12\end{bmatrix}.
   $$
5. Check by multiplying $P\mathbf q$: each output coordinate is $\frac34\cdot\frac12+\frac14\cdot\frac12=\frac12$. The entries are nonnegative and sum to one. All entries of $P$ are positive, so the steady state is also the unique attracting long-run distribution.
::::
:::

:::callout-pitfall[Markov errors that are easy to catch]
Checking row sums instead of column sums; finding the null space of $P$ rather than $P-I$; reporting an unnormalised eigenvector as a probability distribution; forgetting the nonnegativity condition; and concluding that every stochastic chain converges. For a two-step question, $P\mathbf x_0$ is only the first step. Apply $P$ again.
:::

**What earns the points:** a correct column convention, the matrix equation $P\mathbf q=\mathbf q$, the explicit homogeneous system, a nonnegative direction, a sum-to-one normalization, and a check. For finite-step questions, give the intermediate vector rather than skipping straight to an unexplained power.

## Chapter Summary

:::summary[One-page written-quiz decision sheet]
**Identify the request before calculating.**

| If the problem says… | First move | Essential final evidence |
|---|---|---|
| Is this vector an eigenvector? | Multiply $A\mathbf v$. | $\mathbf v\ne\mathbf0$ and $A\mathbf v=\lambda\mathbf v$, or a mismatch. |
| Is $c$ an eigenvalue? | Check $A-cI$. | $\det(A-cI)=0$ or a nonzero null-space vector. |
| Find eigenvalues / polynomial. | Form $A-\lambda I$. | Correct determinant, factorization, roots and multiplicities. |
| Find a basis for $E_c$. | Solve $(A-cI)\mathbf x=0$. | Pivots, free variables, basis columns, dimension. |
| Diagonalize / explain failure. | Count independent eigenvectors. | Ordered $P,D$ and $AP=PD$, or multiplicity gap. |
| Complex pair / real block. | Quadratic determinant. | Conjugate roots and correctly signed real block. |
| Solve $\mathbf x'=A\mathbf x$. | Find eigenmodes. | Exponentials, constants from $\mathbf x(0)$, verification. |
| Markov steady state. | Solve $(P-I)\mathbf q=0$. | Nonnegative entries, sum one, $P\mathbf q=\mathbf q$. |

**Four arithmetic safeguards:** For a $2\times2$ determinant use $ad-bc$. For a $3\times3$ determinant, choose the sparsest cofactor line and show its signs; triangular matrices need only a diagonal product. The characteristic polynomial $\det(A-\lambda I)$ has leading sign $(-1)^n$. Check eigenvalue sums against $\operatorname{tr}(A)$ and products against $\det A$.

**One null-space safeguard:** Geometric multiplicity is the **number of free variables** for that eigenvalue. Algebraic multiplicity is its repetition in the polynomial. A repeated root does not decide diagonalizability; the total number of independent eigenvectors does.

**Complex safeguard:** A real matrix has conjugate eigenvalues $a\pm bi$. If $\lambda=a-bi$ and $\mathbf v=\mathbf p+i\mathbf q$, the basis $[\mathbf p\ \mathbf q]$ gives the real block\n\n$$\nC=\begin{bmatrix}a&-b\\b&a\end{bmatrix}.\n$$\n\nIts discrete scaling factor is $\sqrt{a^2+b^2}$.

**Qualitative safeguards:** Real ODE eigenvalues both negative = sink, both positive = source, opposite signs = saddle. Complex real part negative = inward spiral, positive = outward spiral; purely imaginary = center for the standard diagonalizable real $2\times2$ case. Stochasticity needs nonnegative entries and *column* sums one. Regularity, not mere stochasticity, guarantees convergence to a unique steady state.

**Minimum written-answer chain:** show the relevant equation, the shortest justified calculation, the final result, and one check. Do not turn a one-multiplication eigenvector question into a full diagonalization.
:::
