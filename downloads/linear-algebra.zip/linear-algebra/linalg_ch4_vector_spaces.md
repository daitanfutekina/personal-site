---
title: "Vector Spaces"
crumb: "Linear Algebra · Chapter 4"
meta:
  - "Est. study time: ~10–12 hours"
  - "MA 3113 · Mississippi State University"
  - "Lay 6e §4.1–§4.6 · sections: subspaces, Nul/Col, bases, coordinates, dimension, rank"
source: "markdown"
---

## Overview

So far every vector has lived in $\R^n$. In this chapter we generalize: a **vector space** is any set that obeys the same arithmetic rules as $\R^n$. Polynomials, matrices, and continuous functions all qualify. This generalization lets us apply everything we know about $\R^n$—linear independence, spanning, bases—to a much wider universe of objects.

The key concepts of this chapter are:

- The ten axioms defining a vector space and how to verify them
- Subspaces and the two-condition subspace test
- Null space, column space, row space, and their connection to $A\mathbf{x}=\mathbf{b}$
- Bases, dimension, rank, and the Rank–Nullity Theorem
- Coordinate vectors and change-of-basis

:::callout-key[Prerequisites]
You should be comfortable with: linear independence in $\R^n$ (§1.7), matrix transformations (§1.8–1.9), and row reduction (§1.2). Review those before proceeding.
:::

## 4.1 Vector Spaces and Subspaces

:::callout-intuition[Intuition]
A vector space is a set where you can *add* elements and *scale* them by real numbers, and the results always stay inside the set. The familiar $\R^n$ is the prototype, but the set of all $2\times 2$ matrices, or all polynomials of degree $\le 3$, follow exactly the same rules.
:::

:::definition[Definition 4.1 — Vector Space]
A **vector space** is a nonempty set $V$ with two operations — *addition* $\mathbf{u}+\mathbf{v}$ and *scalar multiplication* $c\mathbf{u}$ — satisfying all ten axioms for every $\mathbf{u},\mathbf{v},\mathbf{w}\in V$ and every $c,d\in\R$:

1. (Closure under addition) $\mathbf{u}+\mathbf{v}\in V$
2. (Commutativity) $\mathbf{u}+\mathbf{v}=\mathbf{v}+\mathbf{u}$
3. (Associativity) $(\mathbf{u}+\mathbf{v})+\mathbf{w}=\mathbf{u}+(\mathbf{v}+\mathbf{w})$
4. (Zero vector) There exists $\mathbf{0}\in V$ such that $\mathbf{u}+\mathbf{0}=\mathbf{u}$
5. (Additive inverse) For each $\mathbf{u}$ there is $-\mathbf{u}\in V$ with $\mathbf{u}+(-\mathbf{u})=\mathbf{0}$
6. (Closure under scalar mult.) $c\mathbf{u}\in V$
7. (Distributive I) $c(\mathbf{u}+\mathbf{v})=c\mathbf{u}+c\mathbf{v}$
8. (Distributive II) $(c+d)\mathbf{u}=c\mathbf{u}+d\mathbf{u}$
9. (Associativity of scaling) $c(d\mathbf{u})=(cd)\mathbf{u}$
10. (Scalar identity) $1\cdot\mathbf{u}=\mathbf{u}$

Elements of $V$ are called **vectors**; elements of $\R$ are called **scalars**.
:::

:::callout-tip[Common Vector Spaces]
- $\R^n$ — $n$-tuples of real numbers
- $\mathcal{M}_{m\times n}$ — all $m\times n$ real matrices
- $\mathcal{P}_n$ — all polynomials of degree $\le n$ (with the zero polynomial)
- $\mathcal{P}$ — all polynomials (no degree bound)
- $\mathcal{C}[a,b]$ — all continuous functions on $[a,b]$
- $\{\mathbf{0}\}$ — the zero vector space (trivial space)
:::

### The question behind every subspace problem

In Chapter 1, vectors were lists of coordinates. Here, a "vector" might be a polynomial, a function, or a matrix. The definition is deliberately about **operations**, not appearance. A polynomial is a vector because you can add two polynomials and multiply one by a real number while obeying the familiar algebraic rules. A matrix is a vector in exactly the same abstract sense. You do not have to draw a polynomial as an arrow to use linear independence or a basis later.

The ten axioms look intimidating because they are written for an arbitrary set with arbitrary operations. On a subset of an already known vector space, you usually do **not** re-prove ten axioms. The ambient space supplies the familiar algebraic laws. You need to check that the proposed subset still contains its zero vector and stays closed under addition and scaling. It is the operations that make the set a subspace, not the presence of visually familiar points.

There are two exam tasks. A **proof** must work for any two elements of the set and any real scalar. A **counterexample** needs only one specific violation. Students waste time proving three properties for a set that fails the zero-vector test in the first line. Use the zero vector as a fast filter, then do the general closure arguments only if it passes.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 480 195" width="480" height="195" role="img" aria-label="A line through the origin is a subspace and a parallel shifted line is not">
<path class="fig-axis" d="M20 155H220 M110 185V10 M265 155H470 M358 185V10"/>
<path class="fig-gridline" d="M50 10V185 M80 10V185 M140 10V185 M170 10V185 M298 10V185 M328 10V185 M388 10V185 M418 10V185"/>
<path class="fig-curve" d="M25 185L195 15"/>
<path class="fig-curve-alt" d="M270 155L440 -15"/>
<path class="fig-point" d="M107 152h6v6h-6Z M355 152h6v6h-6Z"/>
<text class="fig-label-em" x="30" y="20">y = x</text><text class="fig-label" x="282" y="35">y = x + 1</text><text class="fig-label" x="65" y="190">through zero</text><text class="fig-label" x="375" y="190">misses zero</text>
</svg>
<figcaption>The line $y=x$ is a subspace of $\R^2$ because it contains the origin and is closed under addition and scaling; the shifted line $y=x+1$ fails immediately because $(0,0)$ is not on it.</figcaption>
</figure>

### How to write an actual proof, with quantifiers

Suppose $H=\{(x,y,z)\in\R^3:x+2y-z=0\}$. Start: $(0,0,0)\in H$ since $0+2(0)-0=0$. For addition, let $\mathbf{u},\mathbf{v}$ be **arbitrary** vectors of $H$; therefore $u_1+2u_2-u_3=0$ and $v_1+2v_2-v_3=0$. Then

$$
(u_1+v_1)+2(u_2+v_2)-(u_3+v_3)
=(u_1+2u_2-u_3)+(v_1+2v_2-v_3)=0.
$$

The sum lies in $H$. For scaling, let $c\in\R$ be **arbitrary**, so $cu_1+2cu_2-cu_3=c(u_1+2u_2-u_3)=0$. The scaled vector lies in $H$. You have now proved the three checkpoints; you did not merely test two sample vectors. By contrast, for $H'=\{(x,y,z):x+2y-z=5\}$, the zero vector produces $0\ne5$, so $H'$ is not a subspace, regardless of the closure behavior of particular pairs.

The explicit zero test is useful even though a textbook may call the subspace theorem the "two-condition test." The theorem assumes the set is nonempty; if closure under scaling is established for a nonempty set, multiply any member by zero to obtain the zero vector. On a handwritten proof, checking zero directly is often clearer and avoids the logical gap of claiming the empty set qualifies. Both presentations lead to exactly the same class of subspaces.

### Turn a parameter description into a span

A set given in parameters often reveals its subspace structure immediately. If $H=\{(s+2t,3s-t,4t):s,t\in\R\}$, split the $s$ and $t$ contributions:

$$
\begin{bmatrix}s+2t\\3s-t\\4t\end{bmatrix}
=s\begin{bmatrix}1\\3\\0\end{bmatrix}
+t\begin{bmatrix}2\\-1\\4\end{bmatrix}.
$$

Thus $H=\span\{(1,3,0),(2,-1,4)\}$. Every span is a subspace: the zero vector is obtained with all coefficients zero; adding two linear combinations adds their coefficients; multiplying by a scalar multiplies those coefficients. This is a general proof that works for one, two, or a hundred spanning vectors. It is almost always shorter than proving closure by expanding every coordinate separately.

To reverse the process, start with a homogeneous equation $x-2y+z=0$, choose free variables $y=s,z=t$, and solve $x=2s-t$. Then $H=\span\{(2,1,0),(-1,0,1)\}$. The equation describes which vectors belong; the span describes **how to make** them. Both describe the same set, and converting between them is a recurring skill in Chapter 4.

### Polynomials, matrices, and functions

For polynomials, membership is decided by coefficient constraints. The set of all polynomials $p(t)=at^2+bt$ is a subspace of $\mathcal P_2$ because it is $\span\{t^2,t\}$. The set $p(t)=at^2+bt+1$ is *not* a subspace because every polynomial has constant term $1$, so it excludes the zero polynomial. The set of polynomials with **integer coefficients** is not a real vector subspace: multiply $p(t)=t$ by $1/2$, and the coefficient is no longer an integer. Do not confuse closure under integer scaling with closure under **every real** scalar.

For matrices, a property like "symmetric" is linear: $(A+B)^T=A^T+B^T$ and $(cA)^T=cA^T$, so it survives both operations. A property like "invertible" is not linear: the zero matrix is not invertible. A trace equation $\tr A=0$ is linear, since trace adds and scales normally. The requirement $\tr A=1$ misses the zero matrix and fails. A set of all upper-triangular matrices is linear because the entries below the diagonal remain zero under both operations.

For functions, $H=\{f:f(0)=0\}$ is a subspace of functions defined at zero: if $f(0)=g(0)=0$, then $(f+g)(0)=0$ and $(cf)(0)=0$. But $H'=\{f:f(0)=1\}$ excludes the zero function. The objects look nothing like familiar coordinate vectors, but the logic is identical.

### Three common false shortcuts

First, passing the zero test is **necessary, not sufficient**. The first quadrant of $\R^2$ contains $(0,0)$ and is closed under addition, but multiplying $(1,0)$ by $-1$ leaves the set. Second, being closed under positive scalars is insufficient; test negative and zero scalars. Third, showing two particular elements add to another element does not establish universal closure. State that your input vectors are arbitrary. For a failed property, however, one concrete counterexample is conclusive.

The phrase "a subspace of $\R^3$" has a literal meaning: every member must be an element of $\R^3$. As ordinarily defined, $\R^2$ is not a subset of $\R^3$; the plane $\{(x,y,0):x,y\in\R\}$ is a **copy** of $\R^2$ inside $\R^3$ and is a subspace. This distinction matters when you study the coordinate map in §4.4.

If a set is empty, it is not a vector space. If its defining equation has a nonzero right-hand side, test zero immediately. If it is a span or a homogeneous solution set, expect a subspace and demonstrate why. And if it is defined by an inequality, a fixed norm, positive entries, integer coefficients, or invertibility, look for an easy counterexample before attempting a proof.

:::example[Example 4.1 — Verifying $\mathcal{P}_2$ is a Vector Space]
Let $\mathcal{P}_2 = \{a_0 + a_1 t + a_2 t^2 : a_0,a_1,a_2\in\R\}$ with the usual polynomial addition and scalar multiplication. Verify it is a vector space.


::::answer[Answer]
**Answer:** Yes, $\mathcal P_2$ is a vector space.

1. **Closure under addition:** If $p = a_0+a_1t+a_2t^2$ and $q=b_0+b_1t+b_2t^2$, then $p+q=(a_0+b_0)+(a_1+b_1)t+(a_2+b_2)t^2\in\mathcal{P}_2$. ✓

2. **Closure under scalar mult.:** $cp = ca_0+ca_1t+ca_2t^2\in\mathcal{P}_2$. ✓

3. **Zero vector:** The zero polynomial $0+0\cdot t+0\cdot t^2$ satisfies $p+0=p$. ✓

4. Axioms 2, 3, 7–10 all follow from the corresponding properties of real number arithmetic. All ten axioms hold, so $\mathcal{P}_2$ is a vector space.
::::
:::

:::example[Example 4.2 — A Set That Fails to Be a Vector Space]
Let $V = \{(x,y)\in\R^2 : x\ge 0,\, y\ge 0\}$ (the first quadrant, including axes) with standard operations. Is $V$ a vector space?


::::answer[Answer]
**Answer:** No, $V$ is not a vector space: $-(1,0)=(-1,0)\notin V$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Axiom 5 fails: the additive inverse of $(1,0)$ would be $(-1,0)$, which is not in $V$. Also, scalar multiplication by $-1$ violates Axiom 6. **One failed axiom is enough to disqualify $V$.**
::::
:::

### Subspaces

:::definition[Definition 4.2 — Subspace]
A subset $H\subseteq V$ is a **subspace** of $V$ if $H$ is itself a vector space under the same operations as $V$.
:::

:::theorem[Theorem 4.1 — Subspace Test (Two-Condition Test)]
A nonempty subset $H$ of a vector space $V$ is a subspace of $V$ if and only if:

1. **Closed under addition:** For all $\mathbf{u},\mathbf{v}\in H$, $\mathbf{u}+\mathbf{v}\in H$.
2. **Closed under scalar multiplication:** For all $\mathbf{u}\in H$ and $c\in\R$, $c\mathbf{u}\in H$.

(Note: $\mathbf{0}\in H$ is guaranteed by condition 2 with $c=0$.)
:::

:::callout-pitfall[Common Pitfall]
Many students forget to check that $H$ is *nonempty*. The easiest check: show $\mathbf{0}\in H$. If $\mathbf{0}\notin H$, then $H$ cannot be a subspace. **Always start by verifying $\mathbf{0}\in H$.**
:::

:::example[Example 4.3 — Is a Plane Through the Origin a Subspace of $\R^3$?]
Let $H = \{(x_1,x_2,x_3)\in\R^3 : x_1 - 2x_2 + 4x_3 = 0\}$. Show $H$ is a subspace of $\R^3$.


::::answer[Answer]
**Answer:** Yes, $H$ is a subspace of $\mathbb R^3$.

1. **Zero vector:** $(0,0,0)$: $0-0+0=0$ ✓

2. **Closure under addition:** If $\mathbf{u}=(u_1,u_2,u_3)$ and $\mathbf{v}=(v_1,v_2,v_3)$ satisfy the equation, then:

$$
(u_1+v_1)-2(u_2+v_2)+4(u_3+v_3) = (u_1-2u_2+4u_3)+(v_1-2v_2+4v_3)=0+0=0\checkmark
$$

3. **Closure under scalar mult.:** $(cu_1)-2(cu_2)+4(cu_3) = c(u_1-2u_2+4u_3)=c\cdot 0=0$ ✓

4. Both conditions hold, so $H$ is a subspace.
::::
:::

:::example[Example 4.4 — A Plane Not Through the Origin]
Is $H = \{(x_1,x_2,x_3): x_1 + x_2 + x_3 = 1\}$ a subspace of $\R^3$?


::::answer[Answer]
**Answer:** No, $H$ is not a subspace.

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. Check the zero vector: $0+0+0=0\ne 1$, so $\mathbf{0}\notin H$. $H$ fails to be a subspace. (Geometrically, only planes through the origin can be subspaces.)
::::
:::

:::problem[Problem 4.1 — Test the subspace property]{difficulty=easy}
Is $\mathcal{P}_1 = \{a_0+a_1t : a_0,a_1\in\R\}$ a subspace of $\mathcal{P}_2$?


::::solution[Solution]
**Answer:** Yes, $\mathcal P_1$ is a subspace of $\mathcal P_2$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Check: $\mathbf{0}\in\mathcal{P}_1$? Yes (both coefficients 0). Sum of two degree-$\le 1$ polynomials has degree $\le 1$. Scalar multiple of a degree-$\le 1$ polynomial has degree $\le 1$. Both conditions hold — **yes, $\mathcal{P}_1$ is a subspace of $\mathcal{P}_2$**.
::::
:::

:::problem[Problem 4.2 — Test the subspace property]{difficulty=standard}
Let $H = \left\{\begin{bmatrix}a\\b\\c\end{bmatrix}: a+2b=0\right\}$. Verify $H$ is a subspace of $\R^3$ or find a counterexample.


::::solution[Solution]
**Answer:** Yes, $H$ is a subspace of $\mathbb R^3$.

1. Zero vector: $0+2(0)=0$ ✓. Closure under addition: if $a_1+2b_1=0$ and $a_2+2b_2=0$, then $(a_1+a_2)+2(b_1+b_2)=0$ ✓. Closure under scalar mult.: $(ca)+2(cb)=c(a+2b)=0$ ✓. **$H$ is a subspace.**

2. Check the result against the definition: an affirmative subspace claim must include the zero vector, sums and scalar multiples; one counterexample suffices for a negative claim.
::::
:::

:::problem[Problem 4.3 — Test the subspace property]{difficulty=standard}
Which of the following are subspaces of $\mathcal{M}_{2\times 2}$? (a) All symmetric matrices $A=A^T$. (b) All invertible matrices. (c) All matrices with trace 0.


::::solution[Solution]
**Answer:** (a) yes; (b) no; (c) yes.

1. (a) **Yes.** If $A=A^T$ and $B=B^T$, then $(A+B)^T=A^T+B^T=A+B$, and $(cA)^T=cA^T=cA$. ✓

2. (b) **No.** The zero matrix is not invertible, so $\mathbf{0}\notin H$. ✗

3. (c) **Yes.** $\text{tr}(A+B)=\text{tr}(A)+\text{tr}(B)=0$, and $\text{tr}(cA)=c\cdot\text{tr}(A)=0$. ✓

4. The zero matrix is symmetric and has trace zero, so it belongs to (a) and (c). In contrast, the zero matrix cannot belong to (b), because it is singular.
::::
:::

:::problem[Problem 4.4 — Span and membership]{difficulty=easy}
Is the set $\{(x,y)\in\R^2:y=2x\}$ a subspace? Give a span description.


::::solution[Solution]
**Answer:** Yes. $H=\span\{(1,2)\}$.

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. **Answer: yes**, $\span\{(1,2)\}$. Put $x=t$, then $(x,y)=(t,2t)=t(1,2)$. Spans contain zero and are closed under both operations.
::::
:::

:::problem[Problem 4.5 — Span and membership]{difficulty=standard}
Show whether the set of $2\times2$ matrices with $a_{11}+a_{22}=0$ is a subspace.


::::solution[Solution]
**Answer:** Yes; the trace-zero matrices form a subspace.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. **Answer: yes.** The zero matrix has trace zero. If $A,B$ have trace zero, $\tr(A+B)=\tr A+\tr B=0$. For any $c\in\R$, $\tr(cA)=c\tr A=0$. Thus the subset is closed under addition and scaling. A spanning form is $\begin{bmatrix}a&b\\c&-a\end{bmatrix}=a\begin{bmatrix}1&0\\0&-1\end{bmatrix}+b\begin{bmatrix}0&1\\0&0\end{bmatrix}+c\begin{bmatrix}0&0\\1&0\end{bmatrix}$.
::::
:::

:::problem[Problem 4.6 — Span and membership]{difficulty=standard}
For $W=\{(x,y,z):x-y+2z=0\}$, find two vectors whose span is $W$ and prove it is a subspace.


::::solution[Solution]
**Answer:** $W=\span\{(1,1,0),(-2,0,1)\}$; it is a subspace.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $W=\span\{(1,1,0),(-2,0,1)\}$. Let $y=s,z=t$. Then $x=s-2t$, giving $(x,y,z)=s(1,1,0)+t(-2,0,1)$. The span theorem proves the subspace conditions. Directly, the homogeneous equation evaluates to zero on the zero vector, sums, and scalar multiples.
::::
:::

## 4.2 Null Spaces, Column Spaces, and Linear Transformations

:::callout-intuition[Intuition]
For a matrix $A$, two subspaces arise naturally from the equation $A\mathbf{x}=\mathbf{b}$: the *null space* captures all solutions when $\mathbf{b}=\mathbf{0}$, and the *column space* captures all possible right-hand sides that make the system consistent. Understanding these spaces completely answers the existence and uniqueness questions for linear systems.
:::

### Null Space

:::definition[Definition 4.3 — Null Space]
The **null space** of an $m\times n$ matrix $A$ is the set of all solutions of the homogeneous equation $A\mathbf{x}=\mathbf{0}$:

$$
\Nul A = \{\mathbf{x}\in\R^n : A\mathbf{x}=\mathbf{0}\}
$$
:::

:::theorem[Theorem 4.2 — Null Space is a Subspace]
The null space of an $m\times n$ matrix $A$ is a subspace of $\R^n$.
:::

:::proof
**Proof.** (i) $\mathbf{0}\in\Nul A$ since $A\mathbf{0}=\mathbf{0}$. (ii) If $A\mathbf{u}=\mathbf{0}$ and $A\mathbf{v}=\mathbf{0}$, then $A(\mathbf{u}+\mathbf{v})=A\mathbf{u}+A\mathbf{v}=\mathbf{0}+\mathbf{0}=\mathbf{0}$. (iii) $A(c\mathbf{u})=cA\mathbf{u}=c\mathbf{0}=\mathbf{0}$. Both subspace conditions hold.
:::

:::callout-key[Key Fact]
$\Nul A$ lives in $\R^n$ (input space, $n$ columns). Finding a basis for $\Nul A$ is the same as solving $A\mathbf{x}=\mathbf{0}$ and writing the general solution in parametric vector form — the free-variable vectors are the basis.
:::

### A matrix has an input space and an output space

An $m\times n$ matrix takes an input vector with $n$ entries and returns an output with $m$ entries. It is a machine $T:\R^n\to\R^m$. The **null space** asks which inputs the machine erases to zero. The **column space** asks which outputs the machine can actually produce. Those are different questions and their answers generally live in different-sized spaces. For a $2\times3$ matrix, an input has three entries and an output has two. A vector with three entries can be in its null space; a vector with two entries can be in its column space. They are not even eligible for the opposite roles.

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 490 196" width="490" height="196" role="img" aria-label="A maps an input in R three to an output in R two, while its null space maps to zero">
<path class="fig-axis" d="M55 145L130 145 M88 175V35 M88 145L28 175"/>
<path class="fig-axis" d="M368 145H470 M418 185V35"/>
<path class="fig-curve" d="M88 145L119 70 M418 145L453 88"/>
<path class="fig-guide" d="M88 145L57 90"/>
<path class="fig-arrow" d="M160 92L339 92 M160 141L339 141"/>
<text class="fig-label-em" x="25" y="30">inputs: R³</text><text class="fig-label-em" x="376" y="30">outputs: R²</text>
<text class="fig-label" x="220" y="81">A : R³ → R²</text><text class="fig-label" x="195" y="132">null input → 0</text>
<text class="fig-label" x="30" y="186">Nul A</text><text class="fig-label" x="424" y="186">Col A</text>
</svg>
<figcaption>For $A$ of size $2\times3$, $\Nul A\subseteq\R^3$ consists of inputs sent to zero, while $\Col A\subseteq\R^2$ consists of reachable outputs $A\mathbf{x}$.</figcaption>
</figure>

### Solve null space by the same method as homogeneous systems

Let $A\mathbf{x}=\mathbf0$. Put $A$ in echelon or reduced echelon form; row operations preserve the **solutions** of a homogeneous system because they apply invertible operations to its equations. Mark pivot and free columns. Assign a parameter to each free variable, solve for pivot variables, and split the answer into a sum of parameter times fixed vectors. Those fixed vectors are a basis for $\Nul A$. There is one basis vector for every free variable, so the dimension is the number of nonpivot columns.

For instance, for $A=\begin{bmatrix}1&2&-1&3\\0&0&1&2\end{bmatrix}$ the equations are $x_1+2x_2-x_3+3x_4=0$ and $x_3+2x_4=0$. Pivots are in columns 1 and 3; let $x_2=s$ and $x_4=t$. Solve **bottom up**: $x_3=-2t$, then $x_1=-2s+x_3-3t=-2s-5t$. Hence

$$
\mathbf{x}=s\begin{bmatrix}-2\\1\\0\\0\end{bmatrix}+t\begin{bmatrix}-5\\0\\-2\\1\end{bmatrix}.
$$

Every step is necessary: an unexplained jump to the basis often hides a wrong sign. Check both basis vectors by multiplying by the original $A$. The result must be zero, not just a zero under the row-reduced matrix. Because each special-solution vector has a unique $1$ in its own free-variable slot and $0$ in the other free-variable slots, the vectors are independent.

### Column space is a question about consistency

Writing $A=[\mathbf{a}_1\ \cdots\ \mathbf{a}_n]$, the equation $A\mathbf{x}=\mathbf b$ is the same as $x_1\mathbf{a}_1+\cdots+x_n\mathbf{a}_n=\mathbf b$. Thus $\mathbf b$ can be reached exactly when it belongs to the span of the columns. To **test membership**, augment with $\mathbf b$ and row-reduce $[A\mid\mathbf b]$. If a row becomes $[0\ \cdots\ 0\mid c]$ with $c\ne0$, the system is inconsistent and $\mathbf b\notin\Col A$. Otherwise it belongs. When the problem asks for a particular $\mathbf x$, back-substitute to find one.

To **find a basis for $\Col A$**, do *not* take the pivot columns from the row-reduced matrix. Row operations can change the actual column vectors. They preserve which original columns are independent and which are combinations of earlier pivot columns, so the pivot **indices** carry over; take the corresponding columns of the **original matrix**. This gives vectors in $\R^m$ that genuinely belong to the original column space.

### Why row operations change a column space

Take $A=\begin{bmatrix}1&1\\1&1\end{bmatrix}$. Its column space is the line $\span\{(1,1)\}$. Replace row 2 by row 2 minus row 1, obtaining $U=\begin{bmatrix}1&1\\0&0\end{bmatrix}$. The column space of $U$ is instead $\span\{(1,0)\}$. Both matrices have rank 1 and pivot column 1, but the spaces are different lines in $\R^2$. Using $(1,0)$ as a basis for $\Col A$ would be wrong. In contrast, $\Nul A=\Nul U$: both equations say $x_1+x_2=0$. This gives a concrete reason for the two distinct recipes.

### Kernel and range translate the same ideas to general spaces

For $T:V\to W$, the kernel is the set of inputs in $V$ mapped to the zero vector in $W$. The range is the set of outputs reached inside $W$. Both are subspaces because linearity preserves sums and scalar multiples: $T(\mathbf u+\mathbf v)=T\mathbf u+T\mathbf v$ and $T(c\mathbf u)=cT\mathbf u$. When $T(\mathbf x)=A\mathbf x$, the kernel is $\Nul A$ and the range is $\Col A$.

For differentiation $D:\mathcal P_2\to\mathcal P_2$, $D(a+bt+ct^2)=b+2ct$. Constants go to zero, so $\ker D=\span\{1\}$. Every linear polynomial $u+vt$ is a derivative: choose $p(t)=ut+(v/2)t^2$. Hence $\operatorname{range}D=\mathcal P_1=\span\{1,t\}$. This is exactly the same logic as a matrix with a one-dimensional null space and a two-dimensional column space.

### One calculation, two different questions

If $A\mathbf x=\mathbf b$ is consistent and $\mathbf x_p$ is one solution, all solutions are $\mathbf x_p+\mathbf z$ where $\mathbf z\in\Nul A$. To see it, write $A(\mathbf x_p+\mathbf z)=A\mathbf x_p+A\mathbf z=\mathbf b$. Conversely, subtract two solutions to get a null-space vector. Thus the column space determines **whether** a solution exists, while the null space determines **how many degrees of freedom** remain. This distinction is the most useful interpretation of the two spaces on a written exam.

A kernel of only zero means the transformation is one-to-one: two different inputs never give the same output, because their difference would lie in the kernel. A range equal to all of $W$ means the transformation is onto: every proposed output is reachable. Neither property automatically implies the other for a rectangular matrix. For an $n\times n$ matrix, the Invertible Matrix Theorem makes them equivalent; for a $2\times3$ matrix they answer different questions.

### Reliable exam checklist

Write the matrix shape first: $m\times n$. Label $\Nul A\subseteq\R^n$ and $\Col A\subseteq\R^m$. For a null basis, solve the homogeneous equations and split the parameters. For a column basis, row-reduce only to determine pivot **positions**, then go back to the untouched matrix. For membership, use an augmented system and look for contradictions. Finally verify a proposed null vector by $A\mathbf v=\mathbf0$ and a proposed column basis by membership in the original column span. A column-space answer with the wrong number of entries is definitively incorrect even if its arithmetic looks neat.

:::example[Example 4.5 — Finding a Basis for $\Nul A$]
Find a basis for the null space of

$$
A = \begin{bmatrix}1&-3&0&-3\\0&1&-1&-2\\0&0&0&0\end{bmatrix}
$$


::::answer[Answer]
**Answer:** $\Nul A=\operatorname{Span}\{(3,1,1,0)^T,(9,2,0,1)^T\}$, dimension $2$.

1. This is already in echelon form. Pivot columns: 1, 2. Free variables: $x_3, x_4$.

2. **Back-substitution:**

3. Row 2: $x_2 = x_3 + 2x_4$

4. Row 1: $x_1 = 3x_2 + 3x_4 = 3(x_3+2x_4)+3x_4 = 3x_3 + 9x_4$

5. Set $(x_3,x_4)=(1,0)$: $\mathbf{v}_1 = (3,1,1,0)$. Set $(x_3,x_4)=(0,1)$: $\mathbf{v}_2 = (9,2,0,1)$.

$$
\Nul A = \span\left\{\begin{bmatrix}3\\1\\1\\0\end{bmatrix},\begin{bmatrix}9\\2\\0\\1\end{bmatrix}\right\}
$$

6. A basis for $\Nul A$ is $\left\{\mathbf{v}_1,\mathbf{v}_2\right\}$. The null space has *dimension 2*.
::::
:::

### Column Space and Row Space

:::definition[Definition 4.4 — Column Space and Row Space]
For an $m\times n$ matrix $A$ with columns $\mathbf{a}_1,\ldots,\mathbf{a}_n$:

- The **column space** is $\Col A = \span\{\mathbf{a}_1,\ldots,\mathbf{a}_n\}\subseteq\R^m$.
- The **row space** is $\Row A = \span\{\text{rows of }A\}\subseteq\R^n$.
:::

:::theorem[Theorem 4.3 — Column Space and Consistency]
$A\mathbf{x}=\mathbf{b}$ is consistent if and only if $\mathbf{b}\in\Col A$.
:::

:::callout-warning[Warning — Spaces Live in Different Dimensions]
For an $m\times n$ matrix: $\Nul A\subseteq\R^n$ (same size as the input $\mathbf{x}$), and $\Col A\subseteq\R^m$ (same size as the output $\mathbf{b}$). Students frequently confuse these.
:::

:::example[Example 4.6 — Basis for $\Col A$]
Find a basis for the column space of

$$
A = \begin{bmatrix}1&0&-3&5\\2&1&-5&11\\0&-1&1&-3\end{bmatrix}
$$


::::answer[Answer]
**Answer:** $\{(1,2,0)^T,(0,1,-1)^T,(-3,-5,1)^T\}$ is a basis for $\Col A$.

1. Row reduce $A$:

$$
\begin{bmatrix}1&0&-3&5\\2&1&-5&11\\0&-1&1&-3\end{bmatrix}
    \xrightarrow{R_2-2R_1}
    \begin{bmatrix}1&0&-3&5\\0&1&1&1\\0&-1&1&-3\end{bmatrix}
    \xrightarrow{R_3+R_2}
    \begin{bmatrix}1&0&-3&5\\0&1&1&1\\0&0&2&-2\end{bmatrix}
$$

2. Pivot columns: 1, 2, 3. The corresponding *original* columns of $A$ form a basis:

$$
\text{Basis for }\Col A = \left\{\begin{bmatrix}1\\2\\0\end{bmatrix},\begin{bmatrix}0\\1\\-1\end{bmatrix},\begin{bmatrix}-3\\-5\\1\end{bmatrix}\right\}
$$

3. **Critical rule:** The pivot columns of the *original* $A$ (not the row-reduced form) form a basis for $\Col A$. Row operations change the column space!
::::
:::

:::example[Example 4.7 — Null space and column space of one rectangular matrix]
For $A=\begin{bmatrix}1&2&-1\\0&1&1\end{bmatrix}$, find bases for $\Nul A$ and $\Col A$.


::::answer[Answer]
**Answer:** $\Nul A=\span\{(3,-1,1)\}$; $\Col A=\span\{(1,0),(2,1)\}=\mathbb R^2$.

1. $\Nul A=\span\{(3,-1,1)\}$; $\Col A=\span\{(1,0),(2,1)\}=\R^2$.

2. The equations are $x_1+2x_2-x_3=0$, $x_2+x_3=0$. Let $x_3=t$. Then $x_2=-t$ and $x_1=-2(-t)+t=3t$, so $\mathbf x=t(3,-1,1)$. The basis vector passes the check $A(3,-1,1)^T=(3-2-1,-1+1)^T=(0,0)^T$. Pivot columns are 1 and 2, so the corresponding original columns $(1,0)^T$ and $(2,1)^T$ form a basis for the column space. The rank is 2 and nullity is 1; $2+1=3$ columns.
::::
:::

:::example[Example 4.8 — Does a requested output belong to the range?]
Let $A=\begin{bmatrix}1&2\\2&4\\0&0\end{bmatrix}$ and $\mathbf b=(3,6,1)^T$. Is $\mathbf b\in\Col A$?


::::answer[Answer]
**Answer:** No, the requested vector is not in the range.

1. **Answer: no.**

2. Set up $[A\mid\mathbf b]=\begin{bmatrix}1&2&3\\2&4&6\\0&0&1\end{bmatrix}$. Replace row 2 by $R_2-2R_1$, giving $\begin{bmatrix}1&2&3\\0&0&0\\0&0&1\end{bmatrix}$. The third row says $0=1$, so the system is inconsistent. Thus $(3,6,1)$ is not in the column space. Every column of $A$ has third entry zero, which also makes the impossibility visible immediately.
::::
:::

:::callout-pitfall[Critical Pitfall — Row Operations and Column Space]
Row operations **preserve the row space** but **change the column space**. To find a basis for $\Col A$: row reduce to find which columns are pivot columns, then use those columns from the *original* matrix $A$. Never use the reduced matrix's columns.
:::

### Connection to Linear Transformations

:::definition[Definition 4.5 — Kernel and Range]
For a linear transformation $T:V\to W$:

- The **kernel** of $T$ is $\ker(T)=\{\mathbf{v}\in V : T(\mathbf{v})=\mathbf{0}\}\subseteq V$.
- The **range** of $T$ is $\text{range}(T)=\{T(\mathbf{v}) : \mathbf{v}\in V\}\subseteq W$.

For the matrix transformation $T(\mathbf{x})=A\mathbf{x}$: $\ker(T)=\Nul A$ and $\text{range}(T)=\Col A$.
:::

:::problem[Problem 4.7 — Build an augmented matrix]{difficulty=easy}
Is $\mathbf{b}=\begin{bmatrix}3\\1\end{bmatrix}$ in $\Col A$ where $A=\begin{bmatrix}1&-2\\-2&4\end{bmatrix}$?


::::solution[Solution]
**Answer:** No, $\mathbf b\notin\Col A$.

1. Ask: is $A\mathbf{x}=\mathbf{b}$ consistent? Augmented matrix: $\begin{bmatrix}1&-2&3\\-2&4&1\end{bmatrix}\to\begin{bmatrix}1&-2&3\\0&0&7\end{bmatrix}$. Row 2 gives $0=7$ — **inconsistent**. So $\mathbf{b}\notin\Col A$.

2. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.

3. The elimination used $R_2\leftarrow R_2+2R_1$. Its right-hand side becomes $1+2(3)=7$, but both left-hand coefficients become zero, making $0=7$ impossible.
::::
:::

:::problem[Problem 4.8 — Recognize echelon form]{difficulty=standard}
Find a basis for $\Nul A$ where $A=\begin{bmatrix}1&2&0&-1\\0&0&1&3\end{bmatrix}$.


::::solution[Solution]
**Answer:** Basis $\{(-2,1,0,0)^T,(1,0,-3,1)^T\}$.

1. Already in REF. Pivots in columns 1, 3; free variables $x_2, x_4$. Back-sub: $x_1=-2x_2+x_4$, $x_3=-3x_4$. Basis: $\left\{\begin{bmatrix}-2\\1\\0\\0\end{bmatrix},\begin{bmatrix}1\\0\\-3\\1\end{bmatrix}\right\}$.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.9 — Find kernel and range]{difficulty=challenge}
Let $T:\mathcal{P}_2\to\mathcal{P}_2$ be defined by $T(p)(t)=p'(t)$ (differentiation). Find the kernel and range of $T$.


::::solution[Solution]
**Answer:** $\ker T=\mathcal P_0$ (dimension $1$); $\operatorname{range}T=\mathcal P_1$ (dimension $2$).

1. **Kernel:** $T(p)=0$ means $p'=0$, so $p$ is constant: $\ker(T)=\{a_0 : a_0\in\R\}\cong\R$, dimension 1.

2. **Range:** The derivative of $a_0+a_1t+a_2t^2$ is $a_1+2a_2t$, which spans all of $\mathcal{P}_1$. So $\text{range}(T)=\mathcal{P}_1$, dimension 2.

3. For any target $b_0+b_1t\in\mathcal P_1$, the polynomial $b_0t+(b_1/2)t^2$ differentiates to it. This establishes surjectivity onto the stated range, not just containment.
::::
:::

:::problem[Problem 4.10 — Find a null-space basis]{difficulty=easy}
For $A=\begin{bmatrix}1&2&3\\0&1&1\end{bmatrix}$, state the ambient spaces containing $\Nul A$ and $\Col A$.


::::solution[Solution]
**Answer:** $\Nul A\subseteq\R^3$; $\Col A\subseteq\R^2$. The number of columns is the input dimension, and the number of rows is the output dimension.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. $\Nul A\subseteq\R^3$; $\Col A\subseteq\R^2$. The number of columns is the input dimension, and the number of rows is the output dimension.
::::
:::

:::problem[Problem 4.11 — Find a null-space basis]{difficulty=standard}
Find a basis of $\Nul A$ for $A=\begin{bmatrix}1&1&0&2\\0&0&1&-1\end{bmatrix}$.


::::solution[Solution]
**Answer:** $\{(-1,1,0,0),(-2,0,1,1)\}$. Pivots $x_1,x_3$; set $x_2=s,x_4=t$. The second row gives $x_3=t$. The first gives $x_1=-s-2t$. Thus $\mathbf x=s(-1,1,0,0)+t(-2,0,1,1)$. Both vectors multiply to zero under $A$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $\{(-1,1,0,0),(-2,0,1,1)\}$. Pivots $x_1,x_3$; set $x_2=s,x_4=t$. The second row gives $x_3=t$. The first gives $x_1=-s-2t$. Thus $\mathbf x=s(-1,1,0,0)+t(-2,0,1,1)$. Both vectors multiply to zero under $A$.
::::
:::

:::problem[Problem 4.12 — Find a column-space basis]{difficulty=standard}
Find a basis for $\Col A$ if $A=\begin{bmatrix}1&2&3\\0&1&1\\1&3&4\end{bmatrix}$.


::::solution[Solution]
**Answer:** $\{(1,0,1),(2,1,3)\}$. Row 3 minus row 1 minus row 2 gives zero. Pivots occur in columns 1 and 2. Select those columns from the **original** matrix. The third original column equals column 1 plus column 2, so it adds no new direction.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $\{(1,0,1),(2,1,3)\}$. Row 3 minus row 1 minus row 2 gives zero. Pivots occur in columns 1 and 2. Select those columns from the **original** matrix. The third original column equals column 1 plus column 2, so it adds no new direction.
::::
:::

## 4.3 Linearly Independent Sets and Bases

:::callout-intuition[Intuition]
A **basis** is the "most efficient" description of a subspace: it spans the space (so every vector can be expressed using it) but has no redundancy (the vectors are linearly independent). The basis concept generalizes from $\R^n$ to any vector space.
:::

:::definition[Definition 4.6 — Linear Independence in an Abstract Vector Space]
A set $\{\mathbf{v}_1,\ldots,\mathbf{v}_p\}$ in a vector space $V$ is **linearly independent** if the only solution to

$$
c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + \cdots + c_p\mathbf{v}_p = \mathbf{0}
$$

is $c_1=c_2=\cdots=c_p=0$. Otherwise the set is **linearly dependent**.
:::

:::definition[Definition 4.7 — Basis]
A **basis** of a vector space $V$ is a set $\mathcal{B}=\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$ that is:

1. Linearly independent, and
2. Spanning: $V = \span\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$.
:::

:::callout-key[Standard Bases]
- $\R^n$: $\mathcal{E}=\{\mathbf{e}_1,\ldots,\mathbf{e}_n\}$ (standard basis vectors)
- $\mathcal{P}_n$: $\{1, t, t^2, \ldots, t^n\}$ (monomial basis)
- $\mathcal{M}_{2\times 2}$: $\left\{\begin{bmatrix}1&0\\0&0\end{bmatrix},\begin{bmatrix}0&1\\0&0\end{bmatrix},\begin{bmatrix}0&0\\1&0\end{bmatrix},\begin{bmatrix}0&0\\0&1\end{bmatrix}\right\}$
:::

### The Spanning Set Theorem and Basis for Subspaces

:::theorem[Theorem 4.4 — Spanning Set Theorem]
Let $S=\{\mathbf{v}_1,\ldots,\mathbf{v}_p\}$ be a set in $V$ and $H=\span S$.

1. If one of the $\mathbf{v}_k$ is a linear combination of the others, it can be removed and the span is unchanged.
2. If $H\ne\{\mathbf{0}\}$, some subset of $S$ forms a basis for $H$.
:::

:::theorem[Theorem 4.5 — Unique Representation Theorem]
Let $\mathcal{B}=\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$ be a basis for $V$. Then every $\mathbf{v}\in V$ has a *unique* representation:

$$
\mathbf{v} = c_1\mathbf{b}_1 + c_2\mathbf{b}_2 + \cdots + c_n\mathbf{b}_n
$$
:::

### Basis means enough directions and no wasted directions

A spanning set is *enough* to make every vector in a space, but may contain unnecessary vectors. A line in $\R^2$ can be spanned by $(1,2)$ and $(2,4)$, but the second adds nothing because it is twice the first. A basis removes this redundancy. A set is a basis only when it both spans the intended space and is linearly independent. It is possible for a set to pass one test and fail the other: $(1,0)$ alone is independent in $\R^2$ but does not span all of $\R^2$; $(1,0),(0,1),(1,1)$ spans $\R^2$ but is dependent.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 480 185" width="480" height="185" role="img" aria-label="A single line has only one independent direction while two nonparallel vectors span the plane">
<path class="fig-axis" d="M20 155H225 M110 177V15 M260 155H475 M365 177V15"/>
<path class="fig-guide" d="M40 175L205 10"/>
<path class="fig-arrow" d="M110 155L145 120 M110 155L180 85 M365 155L436 155 M365 155L385 60"/>
<text class="fig-label" x="42" y="25">redundant multiples</text><text class="fig-label-em" x="286" y="25">independent directions</text>
</svg>
<figcaption>Two nonzero vectors on the same line are dependent and offer only one direction; two nonparallel planar vectors are independent and span $\R^2$.</figcaption>
</figure>

### How to prove independence without guessing

Take arbitrary coefficients and set the linear combination equal to zero. For vectors $\mathbf v_1,\ldots,\mathbf v_p$, solve $c_1\mathbf v_1+\cdots+c_p\mathbf v_p=\mathbf0$. If only $c_1=\cdots=c_p=0$ works, the set is independent. If a nonzero solution exists, it is dependent. In $\R^n$, put the vectors as **columns** of a matrix and row-reduce the homogeneous system. A pivot in every column means no free coefficient and therefore independence. An extra nonpivot column means a free coefficient and a dependence relation.

To check a proposed basis for a *particular* subspace $H=\span\{\mathbf a,\mathbf b,\mathbf c\}$, do not mistake independence in the ambient $\R^n$ for spanning **$H$**. First verify the candidate vectors lie in $H$ and span every original generator (or row-reduce a matrix of all generators to find pivot columns). Then show the candidate list is independent. Taking a subset of pivot columns of the original generator matrix automatically does both.

### Polynomials are coefficient vectors in disguise

In $\mathcal P_2$, write $p(t)=a+bt+ct^2$ as the coefficient column $(a,b,c)^T$ relative to $\{1,t,t^2\}$. A linear combination of polynomials is zero precisely when each coefficient is zero. Therefore independence and spanning of a polynomial set can be checked by row-reducing a matrix made of its coefficient columns. For example, $\{1+t,t+t^2,1+t^2\}$ becomes

$$
P=\begin{bmatrix}1&0&1\\1&1&0\\0&1&1\end{bmatrix}.
$$

Subtract row 1 from row 2, giving $\begin{bmatrix}1&0&1\\0&1&-1\\0&1&1\end{bmatrix}$, then subtract row 2 from row 3, giving $\begin{bmatrix}1&0&1\\0&1&-1\\0&0&2\end{bmatrix}$. Three pivots mean three independent polynomials. Since $\dim\mathcal P_2=3$, they also span all of $\mathcal P_2$ and form a basis. This coefficient technique is the bridge to coordinate vectors in the next section.

### Remove redundant generators systematically

Suppose the columns $\mathbf v_1,\mathbf v_2,\mathbf v_3$ generate a subspace, and $\mathbf v_3=\mathbf v_1+2\mathbf v_2$. Any combination $a\mathbf v_1+b\mathbf v_2+c\mathbf v_3$ can be rewritten $(a+c)\mathbf v_1+(b+2c)\mathbf v_2$. So deleting $\mathbf v_3$ does not change the span. That is the Spanning Set Theorem in action. When the relationship is not obvious, row-reduce $[\mathbf v_1\ \mathbf v_2\ \mathbf v_3]$ to locate pivot columns, then keep the corresponding original vectors. If all columns are pivots, none is redundant.

A subtle point: a set can have more than one different basis. A line spanned by $(1,2)$ is equally spanned by $(3,6)$, provided the selected vector is nonzero. The *coordinates* of a vector change when the basis changes, but the *number* of elements in a basis stays fixed. That invariant number is the dimension studied in §4.5.

### Why the basis representation is unique

Suppose $\mathcal B=\{\mathbf b_1,\ldots,\mathbf b_k\}$ is independent and spanning, and a vector has two representations:

$$
\mathbf x=c_1\mathbf b_1+\cdots+c_k\mathbf b_k
=d_1\mathbf b_1+\cdots+d_k\mathbf b_k.
$$

Subtract them: $(c_1-d_1)\mathbf b_1+\cdots+(c_k-d_k)\mathbf b_k=\mathbf0$. Independence forces each difference $c_i-d_i=0$, so $c_i=d_i$. Thus spanning gives *existence* of coefficients; independence gives *uniqueness*. Without both, a proposed coordinate system is either unable to describe some vectors or gives multiple addresses to the same vector.

### Three traps from written tests

One zero vector in a proposed basis makes it dependent, because multiplying that vector by $1$ and all others by $0$ gives a nontrivial zero combination. More vectors than the dimension force dependence; fewer vectors than the dimension cannot span. However, merely seeing exactly $n$ vectors in $\R^n$ does **not** prove a basis. You must establish either independence or spanning. A $3\times3$ matrix of three candidate columns with determinant zero has exactly the right count but is still not a basis.

Also keep the distinction between a **basis for $H$** and a basis for the ambient space. A two-vector basis can describe a plane in $\R^3$ perfectly, even though it cannot form a basis for all of $\R^3$. State which space your answer claims to span. In polynomial questions, compare coefficients rather than substituting one numerical $t$ value; checking an identity at $t=1$ is not enough to prove two polynomials equal for every real $t$.

A useful self-check is to start from each generator and make it from your proposed basis, then check a zero combination has only zero coefficients. If the problem requests only one basis, keep your answer simple: pivot columns of an original generator matrix, or monomials/standard unit vectors when the space has an obvious standard basis.


### Basis problems with parameters: distinguish the free coefficients from the basis

Suppose you are given a polynomial constraint $H=\{a+bt+ct^2:2a-b+c=0\}$. Solve for one coefficient, say $b=2a+c$. Substitution gives

$$
p(t)=a+ (2a+c)t+ct^2=a(1+2t)+c(t+t^2).
$$

This proves $H=\span\{1+2t,t+t^2\}$. For independence, set $\alpha(1+2t)+\beta(t+t^2)=0$. The constant term forces $\alpha=0$; then the $t^2$ coefficient forces $\beta=0$. So those two polynomials are a basis. The set $H$ may look like it uses three real coefficients, but its one independent linear constraint leaves only two free coefficients, matching the two basis vectors.

This procedure generalizes to matrix spaces. To find a basis of upper-triangular $2\times2$ matrices, assign separate parameters to the three unrestricted entries, then split them into three matrices with a single $1$ in the allowed positions. Spanning follows from the parameterization and independence from comparing matrix entries. The same move works for any solution set defined by linear homogeneous conditions. The important order is: solve the constraints, express the general element as a linear combination, and then check the proposed generators for independence.

:::example[Example 4.9 — Basis for a Subspace of $\mathcal{P}_2$]
Find a basis for $H = \{a_0+a_1t+a_2t^2 : a_0+2a_1-a_2=0\}\subseteq\mathcal{P}_2$.


::::answer[Answer]
**Answer:** $\{t-2,\,1+t^2\}$ is a basis for $H$.

1. Solve the constraint: $a_0 = -2a_1+a_2$. Write $a_1=s, a_2=r$ (free):

$$
p = (-2s+r) + st + rt^2 = s(-2+t) + r(1+t^2)
$$

2. So $H = \span\{-2+t,\; 1+t^2\}$. These two polynomials are not scalar multiples of each other, hence linearly independent. **Basis:** $\{-2+t,\; 1+t^2\}$.
::::
:::

:::example[Example 4.10 — Checking Linear Independence in $\mathcal{P}_2$]
Are $p_1=1+t^2,\; p_2=2-t,\; p_3=3t+t^2$ linearly independent in $\mathcal{P}_2$?


::::answer[Answer]
**Answer:** Yes, the three polynomials are linearly independent.

1. Solve $c_1(1+t^2)+c_2(2-t)+c_3(3t+t^2)=0$. Collecting by powers of $t$:

2. constant: $c_1+2c_2=0$

3. $t$: $-c_2+3c_3=0$

4. $t^2$: $c_1+c_3=0$

5. Write as a system and row reduce:

$$
\begin{bmatrix}1&2&0\\0&-1&3\\1&0&1\end{bmatrix}\to\begin{bmatrix}1&2&0\\0&-1&3\\0&-2&1\end{bmatrix}\to\begin{bmatrix}1&2&0\\0&-1&3\\0&0&-5\end{bmatrix}
$$

6. Three pivots $\Rightarrow$ only trivial solution $\Rightarrow$ **linearly independent.**
::::
:::

:::example[Example 4.11 — Drop a redundant spanning vector]
Let $H=\span\{(1,2,0),(0,1,1),(1,4,2)\}$. Find a basis for $H$.


::::answer[Answer]
**Answer:** $\{(1,2,0),(0,1,1)\}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Call the three vectors $\mathbf v_1,\mathbf v_2,\mathbf v_3$. The third is $\mathbf v_1+2\mathbf v_2=(1,2,0)+(0,2,2)=(1,4,2)$. Thus it adds no direction; the first two already span $H$. To test independence, set $a(1,2,0)+b(0,1,1)=(0,0,0)$. The first coordinate gives $a=0$ and the third gives $b=0$. So the proposed two-vector spanning set is independent and is a basis. The ambient space is $\R^3$, but $H$ has dimension $2$.
::::
:::

:::example[Example 4.12 — Test a polynomial basis by coefficients]
Is $\{1+t,\ 1-t\}$ a basis for $\mathcal P_1$?


::::answer[Answer]
**Answer:** Yes, the two polynomials form a basis for $\mathcal P_1$.

1. **Answer: yes.**

2. Set $a(1+t)+b(1-t)=0$. Matching constants gives $a+b=0$, and matching coefficients of $t$ gives $a-b=0$. Adding yields $2a=0$, so $a=0$, then $b=0$: independence. To span an arbitrary $u+vt$, solve $a+b=u$, $a-b=v$. Add: $2a=u+v$, so $a=(u+v)/2$; subtract: $2b=u-v$, so $b=(u-v)/2$. Every linear polynomial is obtained, establishing spanning. Both basis conditions have been shown without a calculator.
::::
:::



:::callout-pitfall[A spanning set can still be dependent]
Three vectors in $\R^2$ can span the whole plane, but they cannot be independent. A vector that is zero or a combination of earlier vectors never belongs in a basis. Conversely, two independent vectors in $\R^3$ are not automatically a basis for **all** of $\R^3$; always name the subspace you mean.
:::

:::problem[Problem 4.13 — Test or construct a basis]{difficulty=easy}
Is $\{1+t, 1-t, 2\}$ a basis for $\mathcal{P}_1$? (Note: $\mathcal{P}_1$ has dimension 2.)


::::solution[Solution]
**Answer:** No, the three polynomials do not form a basis for $\mathcal P_1$.

1. Three vectors in a 2-dimensional space must be linearly dependent (by the dimension theorem we'll see in §4.5). Verify: $(1+t)+(1-t)-(2)=0$. So the set is linearly dependent, hence **not a basis**.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.14 — Find a null-space basis]{difficulty=standard}
Find a basis for the null space of $A=\begin{bmatrix}1&3&-2&0\\0&0&1&4\\0&0&0&0\end{bmatrix}$.


::::solution[Solution]
**Answer:** Basis $\{(-3,1,0,0)^T,(-8,0,-4,1)^T\}$.

1. Pivots in columns 1, 3; free vars $x_2, x_4$. Row 2: $x_3=-4x_4$. Row 1: $x_1=-3x_2+2x_3=-3x_2-8x_4$. Basis: $\left\{\begin{bmatrix}-3\\1\\0\\0\end{bmatrix},\begin{bmatrix}-8\\0\\-4\\1\end{bmatrix}\right\}$.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.15 — Find a null-space basis]{difficulty=challenge}
Let $A$ be a $3\times 5$ matrix with $\text{rank}(A)=2$. How many vectors are in a basis for $\Nul A$? For $\Col A$?


::::solution[Solution]
**Answer:** By the Rank–Nullity Theorem: $\text{nullity}(A)=5-\text{rank}(A)=5-2=3$. So $\Nul A$ basis has **3 vectors**. $\Col A$ has rank 2, so its basis has **2 vectors**.

1. By the Rank–Nullity Theorem: $\text{nullity}(A)=5-\text{rank}(A)=5-2=3$. So $\Nul A$ basis has **3 vectors**. $\Col A$ has rank 2, so its basis has **2 vectors**.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.16 — Test or construct a basis]{difficulty=easy}
Is $\{(1,0,0),(0,1,0)\}$ a basis for $\R^3$? Is it a basis for its own span?


::::solution[Solution]
**Answer:** Not a basis for $\mathbb R^3$; yes, a basis for their own span (the plane $z=0$).

1. not for $\R^3$, yes for its own span. The vectors are independent, but no combination has nonzero third coordinate, so they do not span $\R^3$. They do form a basis for the plane $z=0$.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.17 — Test or construct a basis]{difficulty=standard}
Choose a basis for $H=\span\{(1,1,0),(2,2,0),(0,1,1)\}$.


::::solution[Solution]
**Answer:** $\{(1,1,0),(0,1,1)\}$. The second listed generator equals twice the first, so remove it. The remaining vectors are independent: $a(1,1,0)+b(0,1,1)=0$ implies $a=0$ from the first coordinate and $b=0$ from the third.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $\{(1,1,0),(0,1,1)\}$. The second listed generator equals twice the first, so remove it. The remaining vectors are independent: $a(1,1,0)+b(0,1,1)=0$ implies $a=0$ from the first coordinate and $b=0$ from the third.
::::
:::

:::problem[Problem 4.18 — Test or construct a basis]{difficulty=standard}
Do the polynomials $1+t$, $1-t$, and $2$ form a basis for $\mathcal P_2$? Give a dependence relation.


::::solution[Solution]
**Answer:** No, the polynomials do not form a basis for $\mathcal P_2$: they are dependent and do not span $\mathcal P_2$.

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. **Answer: no.** They lack a $t^2$ term and so cannot span $\mathcal P_2$. Also $(1+t)+(1-t)-(2)=0$ is a nontrivial dependence relation among the listed polynomials.
::::
:::

## 4.4 Coordinate Systems

:::callout-intuition[Intuition]
Choosing a basis is like choosing a coordinate system. Once you pick a basis $\mathcal{B}$, every vector in the space has a unique "address" — its coordinate vector $[\mathbf{x}]_{\mathcal{B}}$. This lets us convert problems in abstract vector spaces into familiar matrix equations in $\R^n$.
:::

:::definition[Definition 4.8 — $\mathcal{B}$-Coordinates]
If $\mathcal{B}=\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$ is a basis for $V$ and $\mathbf{x}=c_1\mathbf{b}_1+\cdots+c_n\mathbf{b}_n$, then the **coordinate vector of $\mathbf{x}$ relative to $\mathcal{B}$** is:

$$
[\mathbf{x}]_{\mathcal{B}} = \begin{bmatrix}c_1\\\vdots\\c_n\end{bmatrix}\in\R^n
$$

The $c_i$ are called the **$\mathcal{B}$-coordinates** of $\mathbf{x}$.
:::

### A vector can have several correct coordinate descriptions

A vector in $\R^2$ might be $(3,4)$ in standard coordinates, but that ordered pair does not tell you how many steps to take along a **different** pair of basis arrows. Coordinates are coefficients in a specified basis. When a basis is not the standard one, the coordinates are usually different from the vector's usual entries. In this chapter, writing $\mathbf x$ and $[\mathbf x]_{\mathcal B}$ as the same symbol would hide the most important distinction. They belong to different descriptions of the same underlying vector, connected by a change-of-coordinates matrix.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 480 220" width="480" height="220" role="img" aria-label="Standard axes and a nonorthogonal basis describe the same physical vector">
<path class="fig-axis" d="M30 185H455 M60 210V15"/>
<path class="fig-gridline" d="M60 145H455 M60 105H455 M60 65H455 M100 15V210 M140 15V210 M180 15V210 M220 15V210 M260 15V210 M300 15V210"/>
<path class="fig-arrow" d="M60 185L180 185 M60 185L100 105 M60 185L260 25"/>
<path class="fig-guide" d="M180 185L260 105L260 25 M100 105L260 25"/>
<text class="fig-label" x="185" y="192">b₁</text><text class="fig-label" x="96" y="99">b₂</text><text class="fig-label-em" x="270" y="30">x = b₁ + 2b₂</text>
</svg>
<figcaption>If $\mathbf b_1=(3,0)$ and $\mathbf b_2=(1,2)$, then $\mathbf x=(5,4)=1\mathbf b_1+2\mathbf b_2$; its standard column $(5,4)^T$ differs from its $\mathcal B$-coordinate column $(1,2)^T$.</figcaption>
</figure>

The basis is an **ordered list**, even if a mathematical definition writes braces. Swapping basis vectors swaps the coordinate entries. If $\mathcal B=(\mathbf b_1,\mathbf b_2)$, the coordinate vector $[\mathbf x]_{\mathcal B}=(2,-1)^T$ specifically means $\mathbf x=2\mathbf b_1-\mathbf b_2$, not the other way around. A coordinate problem is fundamentally a linear-combination problem.

### The two directions of a coordinate problem

If the basis vectors and the *coordinates* are given, multiply. Put basis vectors into columns of $P_{\mathcal B}$, and calculate $\mathbf x=P_{\mathcal B}[\mathbf x]_{\mathcal B}$. If the ordinary vector $\mathbf x$ is given and its *basis coordinates* are required, solve the linear system $P_{\mathcal B}\mathbf c=\mathbf x$ by elimination or compute $P_{\mathcal B}^{-1}\mathbf x$ for a small matrix. These are opposite directions of the same reversible mapping. The determinant of $P_{\mathcal B}$ must be nonzero for a legitimate basis of $\R^n$.

For example, let $\mathbf b_1=(1,1)$ and $\mathbf b_2=(1,-1)$. To find $[\,(4,2)^T\,]_{\mathcal B}$, solve $c_1+c_2=4$ and $c_1-c_2=2$. Add the equations: $2c_1=6$, so $c_1=3$; subtract: $2c_2=2$, so $c_2=1$. Check $3(1,1)+1(1,-1)=(4,2)$. Writing the final result as $[\mathbf x]_{\mathcal B}=(3,1)^T$ makes the basis dependence explicit.

### Augmented matrix method, line by line

For $P_{\mathcal B}=\begin{bmatrix}2&1\\1&1\end{bmatrix}$ and $\mathbf x=(5,3)^T$, start with

$$
\left[\begin{array}{cc|c}2&1&5\\1&1&3\end{array}\right].
$$

Swap rows to get a leading $1$: $\left[\begin{array}{cc|c}1&1&3\\2&1&5\end{array}\right]$. Replace $R_2\gets R_2-2R_1$: $\left[\begin{array}{cc|c}1&1&3\\0&-1&-1\end{array}\right]$. Multiply row 2 by $-1$: $\left[\begin{array}{cc|c}1&1&3\\0&1&1\end{array}\right]$. Replace $R_1\gets R_1-R_2$ to obtain $\left[\begin{array}{cc|c}1&0&2\\0&1&1\end{array}\right]$. Thus $[\mathbf x]_{\mathcal B}=(2,1)^T$, and the check $2(2,1)+(1,1)=(5,3)$ verifies the result. You may stop after back-substitution instead of completing the final row operations if you prefer.

### Abstract coordinates: polynomial bases

The same matrix procedure works in $\mathcal P_2$, except the vectors are polynomials and the “standard entries” are coefficients relative to $\{1,t,t^2\}$. If $\mathcal B=(1+t,\ t+t^2,\ 1)$ and $p(t)=3+2t+t^2$, write

$$
c_1(1+t)+c_2(t+t^2)+c_3=3+2t+t^2.
$$

Matching coefficients gives $c_1+c_3=3$, $c_1+c_2=2$, $c_2=1$. Solve bottom up: $c_2=1$, $c_1=1$, $c_3=2$. Therefore $[p]_{\mathcal B}=(1,1,2)^T$. You do not plug in convenient values of $t$; you match coefficients of like powers because polynomial equality holds for **every** $t$.

### Between two nonstandard bases

If $\mathcal B$ and $\mathcal C$ are bases for $\R^n$, converting $\mathcal B$-coordinates to $\mathcal C$-coordinates has two transparent stages. First decode to the actual vector, $\mathbf x=P_{\mathcal B}[\mathbf x]_{\mathcal B}$. Then encode in $\mathcal C$, $[\mathbf x]_{\mathcal C}=P_{\mathcal C}^{-1}\mathbf x$. Combining them gives

$$
[\mathbf x]_{\mathcal C}=P_{\mathcal C}^{-1}P_{\mathcal B}[\mathbf x]_{\mathcal B}.
$$

The order matters because matrix multiplication is not commutative. The matrix $P_{\mathcal C}^{-1}P_{\mathcal B}$ is the *change-of-coordinates matrix from $\mathcal B$ to $\mathcal C$*. You do not generally subtract coordinate vectors or compare their entries until you know they refer to the same ordered basis.

### Why the conversion is unique

The columns of $P_{\mathcal B}$ are a basis, so they are linearly independent. This makes $P_{\mathcal B}$ invertible in $\R^n$. The matrix equation $P_{\mathcal B}\mathbf c=\mathbf x$ therefore has exactly one solution, which is the coordinate vector. This is not just computational convenience: it is precisely the unique representation theorem from §4.3. It also explains why a **dependent** spanning list cannot be treated as a coordinate basis. Such a list gives multiple coefficient choices, so the inverse matrix would not exist.

### Common mistakes to catch before submitting

First, do not simply copy $\mathbf x$ as $[\mathbf x]_{\mathcal B}$. That only works when $\mathcal B$ is the standard basis. Second, do not build $P_{\mathcal B}$ with basis vectors as **rows**; by definition they go in columns. Third, write the direction of conversion above your work: $\mathcal B\to$ standard uses $P_{\mathcal B}$; standard $\to\mathcal B$ uses its inverse or an augmented solve. Fourth, check that the basis order is preserved. Finally, multiply your proposed coordinate column by $P_{\mathcal B}$ and verify that you recover the original vector, a direct numerical test that catches almost every sign error.


### A direction check for three basis notations

A notation such as $[\mathbf{x}]_{\mathcal B}$ means “the coefficient column **with respect to** $\mathcal B$.” It is not the physical vector in standard coordinates, and it is not the coordinate matrix $P_{\mathcal B}$. The columns of $P_{\mathcal B}$ are physical basis vectors, so multiplying $P_{\mathcal B}[\mathbf{x}]_{\mathcal B}$ produces a physical vector. Once you see this through the column-combination formula, the direction of multiplication is unavoidable. The inverse matrix is needed only when you have the physical vector and want to recover the coefficients.

There is also a practical way to check a change-of-basis matrix without computing a second inverse. If a matrix $Q$ claims to change coordinates from $\mathcal B$ to $\mathcal C$, test its columns. The first column of $Q$ should be $[\mathbf b_1]_{\mathcal C}$; the second should be $[\mathbf b_2]_{\mathcal C}$, and so on. In matrix form, this means $P_{\mathcal C}Q=P_{\mathcal B}$. Multiplying these small matrices is often easier than re-solving the full conversion, and it catches an accidental reversal $P_{\mathcal B}^{-1}P_{\mathcal C}$.

For polynomial bases, the same principle applies: a coordinate vector is a column of coefficients **in the listed polynomial basis**, not necessarily the ordinary monomial coefficients. If a problem gives $[p]_{\mathcal B}$ directly, reconstruct $p$ by multiplying and adding the basis polynomials. If it gives $p$ and asks for $[p]_{\mathcal B}$, compare coefficients after setting up the linear combination. These two directions are the most reliable sanity check for one another.

:::example[Example 4.13 — Computing $\mathcal{B}$-Coordinates]
Let $\mathcal{B}=\left\{\mathbf{b}_1=\begin{bmatrix}1\\0\end{bmatrix},\mathbf{b}_2=\begin{bmatrix}1\\2\end{bmatrix}\right\}$ and $\mathbf{x}=\begin{bmatrix}3\\4\end{bmatrix}$. Find $[\mathbf{x}]_{\mathcal{B}}$.


::::answer[Answer]
**Answer:** $[\mathbf x]_{\mathcal B}=\begin{bmatrix}1\\2\end{bmatrix}$.

1. Solve $c_1\begin{bmatrix}1\\0\end{bmatrix}+c_2\begin{bmatrix}1\\2\end{bmatrix}=\begin{bmatrix}3\\4\end{bmatrix}$:

$$
\begin{bmatrix}1&1&3\\0&2&4\end{bmatrix}\to\begin{bmatrix}1&0&1\\0&1&2\end{bmatrix}
$$

2. So $c_1=1, c_2=2$ and $[\mathbf{x}]_{\mathcal{B}}=\begin{bmatrix}1\\2\end{bmatrix}$.

3. *Verification:* $1\cdot\mathbf{b}_1+2\cdot\mathbf{b}_2 = \begin{bmatrix}1\\0\end{bmatrix}+\begin{bmatrix}2\\4\end{bmatrix}=\begin{bmatrix}3\\4\end{bmatrix}$ ✓
::::
:::

:::theorem[Theorem 4.6 — The Coordinate Mapping is an Isomorphism]
Let $\mathcal{B}=\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$ be a basis for $V$. The coordinate map $\mathbf{x}\mapsto[\mathbf{x}]_{\mathcal{B}}$ is a one-to-one linear transformation from $V$ onto $\R^n$. It preserves addition and scalar multiplication:

$$
[\mathbf{u}+\mathbf{v}]_{\mathcal{B}}=[\mathbf{u}]_{\mathcal{B}}+[\mathbf{v}]_{\mathcal{B}},\qquad [c\mathbf{u}]_{\mathcal{B}}=c[\mathbf{u}]_{\mathcal{B}}
$$
:::

### Change of Basis

:::definition[Definition 4.9 — Change-of-Coordinates Matrix]
Let $\mathcal{B}=\{\mathbf{b}_1,\ldots,\mathbf{b}_n\}$ be a basis for $\R^n$. The **change-of-coordinates matrix from $\mathcal{B}$ to the standard basis** is:

$$
P_{\mathcal{B}} = [\mathbf{b}_1\;\mathbf{b}_2\;\cdots\;\mathbf{b}_n]
$$

It satisfies: $\mathbf{x} = P_{\mathcal{B}}[\mathbf{x}]_{\mathcal{B}}$, or equivalently $[\mathbf{x}]_{\mathcal{B}} = P_{\mathcal{B}}^{-1}\mathbf{x}$.
:::

:::example[Example 4.14 — Change-of-Basis in $\R^2$]
Basis $\mathcal{B}=\left\{\begin{bmatrix}1\\-4\end{bmatrix},\begin{bmatrix}2\\-7\end{bmatrix}\right\}$, standard basis $\mathcal{E}$. Given $[\mathbf{x}]_{\mathcal{B}}=\begin{bmatrix}5\\1\end{bmatrix}$, find $\mathbf{x}$; and given $\mathbf{x}=\begin{bmatrix}6\\-13\end{bmatrix}$, find $[\mathbf{x}]_{\mathcal{B}}$.


::::answer[Answer]
**Answer:** $\mathbf x=(7,-27)^T$ and $[\mathbf x]_{\mathcal B}=(-16,11)^T$ in the second conversion.

1. **Finding $\mathbf{x}$:** $\mathbf{x}=P_{\mathcal{B}}[\mathbf{x}]_{\mathcal{B}}=\begin{bmatrix}1&2\\-4&-7\end{bmatrix}\begin{bmatrix}5\\1\end{bmatrix}=\begin{bmatrix}5+2\\-20-7\end{bmatrix}=\begin{bmatrix}7\\-27\end{bmatrix}$.

2. **Finding $[\mathbf{x}]_{\mathcal{B}}$:** Solve $P_{\mathcal{B}}[\mathbf{x}]_{\mathcal{B}}=\begin{bmatrix}6\\-13\end{bmatrix}$:

$$
\left[\begin{array}{cc|c}1&2&6\\-4&-7&-13\end{array}\right]\to\left[\begin{array}{cc|c}1&0&-16\\0&1&11\end{array}\right]
$$

3. So $[\mathbf{x}]_{\mathcal{B}}=\begin{bmatrix}-16\\11\end{bmatrix}$.
::::
:::

:::example[Example 4.15 — Coordinates of a polynomial in a new basis]
Let $\mathcal B=(1+t,\ t+t^2,\ 1)$ in $\mathcal P_2$. Find $[3+2t+t^2]_{\mathcal B}$.


::::answer[Answer]
**Answer:** $\begin{bmatrix}1\\1\\2\end{bmatrix}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Write $c_1(1+t)+c_2(t+t^2)+c_3=3+2t+t^2$. Compare coefficients: $c_1+c_3=3$, $c_1+c_2=2$, and $c_2=1$. Thus $c_2=1$, $c_1=1$, $c_3=2$. Check $1(1+t)+1(t+t^2)+2(1)=3+2t+t^2$. The ordering of coordinates is the ordering of the listed basis.
::::
:::

:::example[Example 4.16 — Convert between two bases]
Let $\mathcal B=((1,0),(1,1))$ and $\mathcal C=((1,1),(0,1))$. Given $[\mathbf x]_{\mathcal B}=(2,3)^T$, find $[\mathbf x]_{\mathcal C}$.


::::answer[Answer]
**Answer:** $[\mathbf x]_{\mathcal C}=\begin{bmatrix}5\\-2\end{bmatrix}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Decode using $\mathcal B$: $\mathbf x=2(1,0)+3(1,1)=(5,3)$. Encode using $\mathcal C$: solve $d_1(1,1)+d_2(0,1)=(5,3)$. The first coordinate gives $d_1=5$; the second gives $d_1+d_2=3$, so $d_2=3-5=-2$. The check $5(1,1)-2(0,1)=(5,3)$ establishes the result.
::::
:::



:::callout-pitfall[Don't confuse the vector and its coordinates]
The entries of $\mathbf x$ and $[\mathbf x]_{\mathcal B}$ generally differ. Put basis vectors in the **columns** of $P_{\mathcal B}$, not its rows; multiply by $P_{\mathcal B}$ to decode and solve with $P_{\mathcal B}$ to encode. Swapping the basis order swaps the coefficient order.
:::

:::problem[Problem 4.19 — Test or construct a basis]{difficulty=easy}
Basis $\mathcal{B}=\{1+2t,\;3+4t\}$ for $\mathcal{P}_1$. Find $[2+6t]_{\mathcal{B}}$.


::::solution[Solution]
**Answer:** $[2+6t]_{\mathcal B}=\begin{bmatrix}5\\-1\end{bmatrix}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Solve $c_1(1+2t)+c_2(3+4t)=2+6t$: constant gives $c_1+3c_2=2$; $t$-coefficient gives $2c_1+4c_2=6$. Subtract twice the first from the second: $-2c_2=2\Rightarrow c_2=-1, c_1=5$. $[2+6t]_{\mathcal{B}}=\begin{bmatrix}5\\-1\end{bmatrix}$.

3. Check by recombining: $5(1+2t)-(3+4t)=5+10t-3-4t=2+6t$. Thus the two coefficients really are the coordinates in the specified ordered basis.
::::
:::

:::problem[Problem 4.20 — Determine the solution set]{difficulty=standard}
Let $P_{\mathcal{B}}=\begin{bmatrix}2&1\\-1&3\end{bmatrix}$. Find $[\mathbf{x}]_{\mathcal{B}}$ when $\mathbf{x}=\begin{bmatrix}5\\7\end{bmatrix}$.


::::solution[Solution]
**Answer:** $[\mathbf x]_{\mathcal B}=\begin{bmatrix}8/7\\19/7\end{bmatrix}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Find $P_{\mathcal{B}}^{-1}$: $\det=6+1=7$, so $P_{\mathcal{B}}^{-1}=\tfrac{1}{7}\begin{bmatrix}3&-1\\1&2\end{bmatrix}$. Then $[\mathbf{x}]_{\mathcal{B}}=\tfrac{1}{7}\begin{bmatrix}3&-1\\1&2\end{bmatrix}\begin{bmatrix}5\\7\end{bmatrix}=\tfrac{1}{7}\begin{bmatrix}8\\19\end{bmatrix}=\begin{bmatrix}8/7\\19/7\end{bmatrix}$.

3. The inverse is valid because $2(3)-1(-1)=7\ne0$. Check $P_{\mathcal B}(8/7,19/7)^T=((16+19)/7,(-8+57)/7)^T=(5,7)^T$. Because the determinant is nonzero, the ordered basis vectors really do form a basis, and the coordinate vector is the unique solution of that two-by-two system.
::::
:::

:::problem[Problem 4.21 — Change coordinates]{difficulty=easy}
With $\mathcal B=((1,0),(0,2))$, find the ordinary vector corresponding to $[\mathbf x]_{\mathcal B}=(3,-1)^T$.


::::solution[Solution]
**Answer:** $\mathbf x=(3,-2)^T$. By definition $\mathbf x=3(1,0)-1(0,2)=(3,-2)$.

1. Use the specific relation in the question to construct a candidate result, then substitute the candidate into that relation to verify it.

2. $\mathbf x=(3,-2)^T$. By definition $\mathbf x=3(1,0)-1(0,2)=(3,-2)$.

3. As a check, return to the original definition and confirm that the conclusion answers each part of the question.
::::
:::

:::problem[Problem 4.22 — Change coordinates]{difficulty=standard}
Let $\mathcal B=((1,1),(2,1))$. Find $[(5,3)^T]_{\mathcal B}$.


::::solution[Solution]
**Answer:** $[(5,3)^T]_{\mathcal B}=(1,2)^T$.

1. Use the specific relation in the question to construct a candidate result, then substitute the candidate into that relation to verify it.

2. $(1,2)^T$. Solve $c_1+2c_2=5$, $c_1+c_2=3$. Subtract the second equation from the first: $c_2=2$. Then $c_1=1$. Check $(1,1)+2(2,1)=(5,3)$.

3. The matrix with basis vectors as columns is $\begin{bmatrix}1&2\\1&1\end{bmatrix}$. Multiplying it by $(1,2)^T$ returns $(5,3)^T$, so the coordinates satisfy both defining equations.
::::
:::

:::problem[Problem 4.23 — Change coordinates]{difficulty=standard}
In $\mathcal P_1$, let $\mathcal B=(1+t,\ 1-t)$. Find $[6+2t]_{\mathcal B}$.


::::solution[Solution]
**Answer:** $[6+2t]_{\mathcal B}=(4,2)^T$.

1. Use the specific relation in the question to construct a candidate result, then substitute the candidate into that relation to verify it.

2. $(4,2)^T$. Solve $a+b=6$ and $a-b=2$. Adding gives $2a=8$, so $a=4$; then $b=2$. Check $4(1+t)+2(1-t)=6+2t$.

3. The coefficient map is $(a,b)\mapsto(a+b)+(a-b)t$. Evaluating at $(4,2)$ returns $6+2t$, confirming both the constant term and the coefficient of $t$.
::::
:::

:::problem[Problem 4.24 — Compute basis coordinates]{difficulty=challenge}
Let $\mathcal B=((1,0),(1,1))$ and $\mathcal C=((1,1),(0,1))$. Find the matrix taking $\mathcal B$-coordinates directly to $\mathcal C$-coordinates.


::::solution[Solution]
**Answer:** $P_{\mathcal C}^{-1}P_{\mathcal B}=\begin{bmatrix}1&1\\-1&0\end{bmatrix}$. Here $P_{\mathcal B}=\begin{bmatrix}1&1\\0&1\end{bmatrix}$ and $P_{\mathcal C}=\begin{bmatrix}1&0\\1&1\end{bmatrix}$, so $P_{\mathcal C}^{-1}=\begin{bmatrix}1&0\\-1&1\end{bmatrix}$. Multiply to obtain the displayed matrix. Test $(2,3)^T$: the result is $(5,-2)^T$, agreeing with Example 4.21.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $P_{\mathcal C}^{-1}P_{\mathcal B}=\begin{bmatrix}1&1\\-1&0\end{bmatrix}$. Here $P_{\mathcal B}=\begin{bmatrix}1&1\\0&1\end{bmatrix}$ and $P_{\mathcal C}=\begin{bmatrix}1&0\\1&1\end{bmatrix}$, so $P_{\mathcal C}^{-1}=\begin{bmatrix}1&0\\-1&1\end{bmatrix}$. Multiply to obtain the displayed matrix. Test $(2,3)^T$: the result is $(5,-2)^T$, agreeing with Example 4.21.
::::
:::

## 4.5 Dimension of a Vector Space

:::callout-intuition[Dimension counts independent choices]
A line requires one independent direction, a plane requires two, and ordinary three-dimensional space requires three. **Dimension** makes that counting idea precise for any vector space, including polynomials and matrices. It is the number of vectors in a basis, not the number of entries in a single convenient description. A plane sitting inside $\R^3$ still has dimension $2$; every vector on it has three coordinates, but only two independent choices are needed to specify one. This distinction will become crucial when counting free variables in null spaces.
:::


:::definition[Definition 4.10 — Dimension]
If $V$ is spanned by a *finite* set, $V$ is **finite-dimensional**. The **dimension** of $V$, written $\dim V$, is the number of vectors in any basis for $V$. The dimension of $\{\mathbf{0}\}$ is 0.
:::

:::theorem[Theorem 4.7 — Basis Uniqueness of Size]
If $V$ has a basis of $n$ vectors, then *every* basis of $V$ has exactly $n$ vectors.
:::

:::theorem[Theorem 4.8 — The $n$-Vector Tests]
Let $V$ have dimension $n$, and let $S=\{\mathbf{v}_1,\ldots,\mathbf{v}_n\}$ be a set of exactly $n$ vectors in $V$. Then the following are equivalent:

1. $S$ is a basis for $V$.
2. $S$ is linearly independent.
3. $S$ spans $V$.

Any one condition implies the other two — *if you have the right count of vectors*.
:::

### Dimension is the size of every basis, not just one

If a vector space has a basis with $k$ vectors, no other basis can have a different number. This fact is what makes $\dim V=k$ meaningful. It would be useless to define dimension as the size of an arbitrary spanning set, because spanning sets may contain duplicates, zero vectors, and other redundancies. Nor can we use the size of an arbitrary independent set, because an independent set may fail to reach much of the space. A **basis** hits both targets and has the correct invariant size.

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 480 180" width="480" height="180" role="img" aria-label="A line needs one basis vector and a plane needs two independent basis vectors">
<path class="fig-axis" d="M25 150H210 M110 175V12 M270 150H470 M360 175V12"/>
<path class="fig-curve" d="M38 170L193 15 M293 170L430 33"/>
<path class="fig-arrow" d="M110 150L155 105 M360 150L430 150 M360 150L390 70"/>
<path class="fig-guide" d="M285 120L445 120 M315 80L450 80"/>
<text class="fig-label-em" x="42" y="20">dimension 1</text><text class="fig-label-em" x="330" y="20">dimension 2</text>
</svg>
<figcaption>A line through the origin has one independent direction and dimension $1$, while a plane has two independent directions and dimension $2$, even if it is embedded in $\R^3$.</figcaption>
</figure>

The standard basis of $\R^4$ has four vectors, so $\dim\R^4=4$. The polynomials in $\mathcal P_2$ have the basis $(1,t,t^2)$, so $\dim\mathcal P_2=3$. In general, $\mathcal P_n$ has dimension $n+1$ because the constant term counts: $(1,t,\ldots,t^n)$ contains $n+1$ distinct monomials. A $2\times3$ matrix has six entries; the six position matrices with one $1$ and all other entries zero form a basis of $\mathcal M_{2\times3}$, so its dimension is $6$. Finally, the zero vector space $\{\mathbf0\}$ has dimension $0$: its basis is the *empty set*. The zero vector itself cannot be a basis element because a set containing it is dependent.

### The extremely useful $n$-vector tests

Suppose $V$ has dimension $n$ and someone hands you exactly $n$ candidate vectors. Normally a basis requires both spanning and independence, but for **exactly $n$ vectors** one of the two tests is enough. Prove independence and spanning follows; prove spanning and independence follows. This is a time-saving theorem, not an excuse to skip checking. A set of $n$ arbitrary vectors may be dependent and fail to span. Also, if the proposed list has $n-1$ vectors, showing independence does not make it a basis for an $n$-dimensional space; if it has $n+1$, showing it spans does not make it a basis either.

To show three polynomials form a basis of $\mathcal P_2$, write their coefficient columns, row-reduce, and check there are three pivots. The number matches the known dimension $3$, so no separate spanning calculation is needed. If you are proving a basis of an unfamiliar subspace $H$, first calculate or reason about $\dim H$. A null space or column space can have dimension smaller than its ambient coordinate space. The $n$-vector theorem applies with $n=\dim H$, not necessarily the number of entries in the vectors.

### Pivot count and free-variable count

For an $m\times n$ matrix, the number of pivots is the rank $r$. There are $n$ variable columns in the homogeneous system $A\mathbf{x}=\mathbf0$, and exactly $r$ of their variables are pivots. The other $n-r$ are free. Each free variable contributes one special-solution basis vector to the null space, so $\dim\Nul A=n-r$. Meanwhile the original pivot columns form a basis for the column space, so $\dim\Col A=r$. Adding these gives

$$
\dim\Col A+\dim\Nul A=r+(n-r)=n.
$$

This is the Rank–Nullity Theorem. It is not a mysterious arithmetic relationship: it is a partition of the **number of input variables** into constrained pivot choices and unconstrained free choices. The right side is the number of **columns**, not the number of rows. If a matrix is $4\times7$, its rank cannot exceed $4$, so its nullity is at least $7-4=3$. There is no way to have seven independent columns in $\R^4$.

### Examples of dimension reasoning without row reduction

If $H=\span\{(1,0,1),(0,1,1)\}\subseteq\R^3$, the displayed vectors are independent because the first coordinate forces the first coefficient to vanish and the second coordinate forces the other to vanish. They span $H$ by definition. Hence $\dim H=2$, even though every member has three components. If $K=\{a+bt+ct^2:p(1)=0\}\subseteq\mathcal P_2$, substitute $a+b+c=0$, so $a=-b-c$ and $p=b(t-1)+c(t^2-1)$. Its two displayed generators are independent, so $\dim K=2$.

For a system that has a unique solution to $A\mathbf x=\mathbf0$, the nullity is zero and the null space is only $\{\mathbf0\}$. If $A$ is square, rank–nullity then forces full rank, so $A$ is invertible. If $A$ is rectangular and has full **column** rank $n$, it can still have no inverse in the ordinary square sense, despite having trivial null space. Distinguish the one-to-one property from invertibility for rectangular matrices.

### The difference between finite and infinite dimension

Every $\mathcal P_n$ is finite-dimensional because the largest power of $t$ is fixed. The space of **all** real polynomials $\mathcal P$ has no finite spanning set: for any proposed finite list, take a power of $t$ higher than the degrees in that list. No linear combination of those shorter polynomials can produce it. Thus $\mathcal P$ is infinite-dimensional. The same idea applies to many function spaces. An exam that asks for the dimension of $\mathcal P_3$ expects $4$, whereas asking about all polynomials expects infinite dimension; the subscript matters.

### How to answer a rank/nullity word problem

Write the shape first, $m\times n$. Mark $n$, the number of columns. Extract the given rank or nullity and use $r+\nu=n$. If the question also asks whether the columns span $\R^m$, compare $r$ with the **row count** $m$. If it asks whether the columns are independent, compare $r$ with the **column count** $n$. The two comparisons need not agree. For example, a $3\times5$ matrix of rank $3$ maps onto all of $\R^3$, but its five columns are necessarily dependent and its nullity is $5-3=2$.

Three checkpoint statements are worth remembering. Full row rank ($r=m$) means $\Col A=\R^m$ and the transformation is onto. Full column rank ($r=n$) means $\Nul A=\{\mathbf0\}$ and the transformation is one-to-one. A square matrix has both properties together exactly when $r=n=m$, the invertible case. These conclusions come from dimensions, not from whether the numbers in the matrix look complicated.

### Mistakes that can be ruled out by bounds

The rank always satisfies $0\le r\le\min(m,n)$. Nullity always satisfies $0\le\nu\le n$. An answer of rank $5$ for a $3\times8$ matrix is impossible. So is nullity $6$ for a $4\times4$ matrix. A basis for a space of dimension $k$ must contain **exactly $k$ vectors**, not $k+1$. Whenever you finish an elimination, check that the pivot count plus free-variable count equals the number of columns. If they do not add up, you have misidentified a pivot or lost a variable.


### Count restrictions, but only independent restrictions

It is tempting to conclude that every written equation removes one dimension. That is not always correct. Consider $H=\{(x,y,z):x+y+z=0,\ 2x+2y+2z=0\}$. The second condition is exactly twice the first, so it imposes no new restriction. Set $y=s,z=t$ to get $x=-s-t$, hence

$$
H=\span\{(-1,1,0),(-1,0,1)\},\qquad \dim H=2.
$$

Although two equations were printed, the coefficient matrix has **rank one**, so there is only one independent constraint. In general, for a homogeneous system with $n$ variables and rank $r$, the solution space has dimension $n-r$, not “$n$ minus the number of rows.” A dependent or zero row does not eliminate a degree of freedom. This explains why row reduction comes before counting.

If a question tells you the dimension of a null space and asks for the possible shape of a matrix, first consider its number of columns. A nullity of four requires at least four columns; a rank of three requires at least three rows *and* three columns. Both inequalities can be combined with $r+\nu=n$ to rule out impossible descriptions before any arithmetic.

:::example[Example 4.17 — Finding Dimension]
What is the dimension of $H=\span\{1+t^2,\;t-t^2,\;2+t-t^2\}\subseteq\mathcal{P}_2$?


::::answer[Answer]
**Answer:** $\dim H=3$.

1. Ask whether the third is a combination of the first two: $a(1+t^2)+b(t-t^2) = a + bt + (a-b)t^2$. Matching $2+t-t^2$ forces $a=2$ from the constant and $b=1$ from the $t$ term, and then the $t^2$ coefficient is $a-b = 1$, not $-1$. No such $a,b$ exist, so the third polynomial is *not* in the span of the first two and all three are independent. Row reducing the coordinate matrix (columns are the three polynomials in the basis $\{1,t,t^2\}$) says the same:

$$
\begin{bmatrix}1&0&2\\0&1&1\\1&-1&-1\end{bmatrix}\to\begin{bmatrix}1&0&2\\0&1&1\\0&0&-2\end{bmatrix}
$$

2. Three pivots $\Rightarrow$ linearly independent $\Rightarrow$ $\dim H=3$. (In fact $H=\mathcal{P}_2$ since $\dim\mathcal{P}_2=3$.)
::::
:::

### Rank–Nullity (Dimension) Theorem

:::theorem[Theorem 4.9 — The Rank–Nullity Theorem]
If $A$ is an $m\times n$ matrix, then:

$$
\underbrace{\rank(A)}_{\dim\Col A} + \underbrace{\nullity(A)}_{\dim\Nul A} = n
$$

In words: *number of pivot columns* + *number of free variables* = *number of columns*.
:::

:::callout-key[How to Use Rank–Nullity]
If $A$ is $m\times n$: $\rank(A)=$ number of pivots (found by row reduction). Then $\nullity(A)=n-\rank(A)$ without further computation. The rank also equals the number of non-zero rows in any echelon form.
:::

:::example[Example 4.18 — Rank and Nullity]
For $A=\begin{bmatrix}1&-2&0&4&5\\0&0&1&-3&-2\\0&0&0&0&0\end{bmatrix}$, find $\rank(A)$ and $\nullity(A)$, and verify the Rank–Nullity Theorem.


::::answer[Answer]
**Answer:** $\rank A=2$, $\nullity A=3$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. The matrix is in echelon form. Pivots in columns 1 and 3. So $\rank(A)=2$. Number of columns $n=5$. By the theorem: $\nullity(A)=5-2=3$. Free variables: $x_2, x_4, x_5$ (columns 2, 4, 5). Verification: $2+3=5$ ✓.
::::
:::

:::example[Example 4.19 — Dimension of a polynomial constraint space]
Find the dimension of $H=\{a+bt+ct^2\in\mathcal P_2:a+b+c=0\}$ and a basis.


::::answer[Answer]
**Answer:** $\dim H=2$, with basis $\{t-1,t^2-1\}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Solve the constraint $a=-b-c$. Substitute into $p(t)$ to get $p=(-b-c)+bt+ct^2=b(t-1)+c(t^2-1)$. The two polynomials span $H$. For independence, $b(t-1)+c(t^2-1)=0$ implies $b=0$ from the $t$ coefficient and $c=0$ from the $t^2$ coefficient. Therefore the two spanning polynomials are independent, and the dimension is $2$.
::::
:::

:::example[Example 4.20 — Dimension bounds on a rectangular matrix]
A $3\times5$ matrix $A$ has rank $3$. Find its nullity. Are its columns independent? Do they span $\R^3$?


::::answer[Answer]
**Answer:** $\nullity(A)=2$; columns dependent; columns span $\mathbb R^3$.

1. $\nullity(A)=2$; columns dependent; columns span $\R^3$.

2. The input count is $n=5$. Rank–nullity gives $3+\nullity(A)=5$, hence $\nullity(A)=2$. Because five columns live in $\R^3$ and rank $3\ne5$, they cannot be independent. Because the rank equals the output dimension $m=3$, the column space has dimension $3$, so it equals $\R^3$ and the transformation is onto. These are different questions with different comparisons.
::::
:::



:::callout-pitfall[Dimension is not the number of visible entries]
A plane in $\R^3$ may have dimension $2$ even though its vectors have three components. In $\mathcal P_n$, count the constant term: dimension is $n+1$. For an $m\times n$ matrix, rank plus nullity equals **$n$ columns**, not $m$ rows.
:::

:::problem[Problem 4.25 — Find a null-space basis]{difficulty=easy}
A $4\times 7$ matrix $A$ has $\rank(A)=3$. What is $\dim(\Nul A)$?


::::solution[Solution]
**Answer:** $\dim(\Nul A)=7-3=4$.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. $\dim(\Nul A)=7-3=4$.

3. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.26 — Find a null-space basis]{difficulty=standard}
A matrix $A$ is $5\times 8$ and $\dim(\Nul A)=3$. What is $\rank(A)$? Can the columns of $A$ span $\R^5$?


::::solution[Solution]
**Answer:** $\rank(A)=8-3=5$. Since $\rank=5=m$, the columns *do* span $\R^5$ (maximum possible rank for a $5\times 8$ matrix is 5).

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. $\rank(A)=8-3=5$. Since $\rank=5=m$, the columns *do* span $\R^5$ (maximum possible rank for a $5\times 8$ matrix is 5).
::::
:::

:::problem[Problem 4.27 — Test consistency]{difficulty=challenge}
Suppose $A$ is $6\times 6$, $\Nul A=\{\mathbf{0}\}$, and the equation $A\mathbf{x}=\mathbf{b}$ is consistent for some $\mathbf{b}$. What can you say about solutions to $A\mathbf{x}=\mathbf{c}$ for *any* $\mathbf{c}\in\R^6$?


::::solution[Solution]
**Answer:** $\Nul A=\{\mathbf{0}\}\Rightarrow\nullity=0\Rightarrow\rank=6$. So $A$ is invertible (by IMT). Therefore $A\mathbf{x}=\mathbf{c}$ has a *unique solution* for every $\mathbf{c}\in\R^6$.

1. $\Nul A=\{\mathbf{0}\}\Rightarrow\nullity=0\Rightarrow\rank=6$. So $A$ is invertible (by IMT). Therefore $A\mathbf{x}=\mathbf{c}$ has a *unique solution* for every $\mathbf{c}\in\R^6$.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.28 — Determine the solution set]{difficulty=easy}
What is $\dim\mathcal P_4$? What is $\dim\mathcal M_{2\times3}$?


::::solution[Solution]
**Answer:** $5$ and $6$. Bases are $(1,t,t^2,t^3,t^4)$ and the six position matrices, one for each matrix entry.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

2. $5$ and $6$. Bases are $(1,t,t^2,t^3,t^4)$ and the six position matrices, one for each matrix entry.
::::
:::

:::problem[Problem 4.29 — Find a null-space basis]{difficulty=standard}
For a $3\times6$ matrix with rank $2$, give the dimensions of $\Nul A$ and $\Col A$, and decide whether its columns span $\R^3$.


::::solution[Solution]
**Answer:** nullity $6-2=4$, column-space dimension $2$, and no, the columns do not span $\R^3$. To span all of $\R^3$, the rank would need to equal $3$.

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. nullity $6-2=4$, column-space dimension $2$, and no, the columns do not span $\R^3$. To span all of $\R^3$, the rank would need to equal $3$.
::::
:::

:::problem[Problem 4.30 — Test or construct a basis]{difficulty=standard}
Find the dimension of $H=\{p\in\mathcal P_3:p(0)=0\}$ and give a basis.


::::solution[Solution]
**Answer:** $\dim H=3$, basis $\{t,t^2,t^3\}$. The condition $p(0)=0$ forces the constant coefficient to vanish. Every member is $bt+ct^2+dt^3$, and the three monomials are independent.

1. $\dim H=3$, basis $\{t,t^2,t^3\}$. The condition $p(0)=0$ forces the constant coefficient to vanish. Every member is $bt+ct^2+dt^3$, and the three monomials are independent.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

## 4.6 Rank

:::callout-intuition[One row reduction, three answers]
The rank is the number of genuinely independent column directions of a matrix. Its value also equals the number of independent row directions, although those rows live in a different space when the matrix is rectangular. This apparent coincidence is a theorem, not a license to swap row and column bases. A single row reduction tells you pivot **indices**, the number of independent rows, and the free variables. The catch is remembering which original or reduced data belongs to which space.
:::


:::definition[Definition 4.11 — Rank and Nullity]
The **rank** of $A$ is $\rank(A)=\dim(\Col A)$. The **nullity** of $A$ is $\nullity(A)=\dim(\Nul A)$.
:::

:::theorem[Theorem 4.10 — Row Space and Column Space have the Same Dimension]
$\dim(\Col A) = \dim(\Row A) = \rank(A)$.

Equivalently: the number of pivot columns = the number of nonzero rows in any echelon form of $A$.
:::

:::theorem[Theorem 4.11 — Basis for Row Space]
Row operations preserve the row space. Therefore the nonzero rows of any echelon form of $A$ form a basis for $\Row A$.
:::

:::callout-warning[Row vs. Column Space Bases]
- **$\Row A$:** Use the nonzero rows of the *row-reduced* (echelon) form.
- **$\Col A$:** Find pivot positions in the echelon form, then use those columns from the *original* $A$.
- **$\Nul A$:** Solve $A\mathbf{x}=\mathbf{0}$ in parametric form; the free-variable vectors are the basis.
:::

### A three-space workflow that earns method points

For an $m\times n$ matrix $A$, keep a copy of the **original matrix** untouched. Row-reduce a separate copy to echelon form $U$ and mark pivot columns. Then proceed in three branches. For $\Col A$, take the columns of **original $A$** whose indices are pivots. For $\Row A$, take all nonzero rows of **echelon $U$**. For $\Nul A$, solve $U\mathbf x=\mathbf0$ using the free variables. Finally count the vectors in these bases: the first two counts should both be $r$, and the null-space count should be $n-r$.

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 500 200" width="500" height="200" role="img" aria-label="An original matrix and its echelon form feed different rules for column, row, and null-space bases">
<path class="fig-axis" d="M20 30H150V80H20Z M350 30H480V80H350Z"/>
<path class="fig-curve" d="M155 56H345"/>
<path class="fig-arrow" d="M85 88V135 M413 88V135 M250 91V170"/>
<text class="fig-label-em" x="42" y="56">original A</text><text class="fig-label-em" x="373" y="56">echelon U</text>
<text class="fig-label" x="180" y="45">row-reduce →</text>
<text class="fig-label" x="15" y="155">Col A: original</text><text class="fig-label" x="365" y="155">Row A: rows</text><text class="fig-label" x="197" y="188">Nul A: solve Ux=0</text>
<text class="fig-label" x="22" y="174">pivot columns</text><text class="fig-label" x="359" y="174">of U</text>
</svg>
<figcaption>Row reduction finds pivot positions; use original columns for $\Col A$, nonzero echelon rows for $\Row A$, and homogeneous solutions of the echelon matrix for $\Nul A$.</figcaption>
</figure>

### Why the row basis comes from the reduced matrix

Each elementary row operation replaces a row by a linear combination of rows, or rearranges/scales them. Since each operation is reversible, the original and new row lists generate exactly the same set of row combinations. Thus row operations preserve $\Row A$. In echelon form, nonzero rows have leading entries in distinct columns, so they are independent. They also span the row space, since zero rows add nothing. Therefore the nonzero echelon rows are a basis. You do **not** have to reduce all the way to RREF for this purpose; any echelon form works, and your basis may differ from someone else's while having the same span and size.

By contrast, applying a row operation to a column vector changes its entries. That may rotate or shear the column space as a subset of $\R^m$, even while preserving the pivot relations. The pivot positions are a map telling you **which old columns** to keep, not a set of new basis vectors to copy from the echelon matrix. This separation is the single most important detail in rank problems.

### Dimension and orthogonality preview

Every row of $A$ has $n$ entries, just like every vector in $\Nul A$. If $\mathbf x\in\Nul A$, then each row of $A$ dotted with $\mathbf x$ equals zero because $A\mathbf x=\mathbf0$. So every null-space vector is perpendicular to every row-space vector. The row space and null space are not generally the same, but they occupy complementary dimensions inside $\R^n$: $\dim\Row A=r$ and $\dim\Nul A=n-r$. This geometric interpretation explains why solving homogeneous equations removes one degree of freedom per independent row constraint.

There is also a left-null space $\Nul(A^T)\subseteq\R^m$, whose dimension is $m-r$. You do not need this extra space to find the usual three bases, but knowing the transpose relationship prevents confusion: $\Col A=\Row(A^T)$ as sets of length-$m$ vectors, and $\Row A=\Col(A^T)$ as sets of length-$n$ vectors. All these identities respect the ambient dimensions.

### Translate rank into uniqueness and existence

If $\rank(A)=n$, there is a pivot in every **column**, so $\Nul A=\{\mathbf0\}$ and $A\mathbf x=\mathbf b$ has at most one solution for each $\mathbf b$. If $\rank(A)=m$, there is a pivot in every **row**, so $\Col A=\R^m$ and $A\mathbf x=\mathbf b$ has at least one solution for every $\mathbf b$. If the matrix is square and both equal $n=m$, every system has exactly one solution and $A^{-1}$ exists. If $r<n$, then whenever $A\mathbf x=\mathbf b$ is consistent, its solution set has $n-r$ free parameters and therefore infinitely many solutions over the real numbers.

In a $2\times3$ matrix of rank $2$, the columns span $\R^2$ and there is one free input direction, so every right-hand side is reachable but no right-hand side has a unique solution. A $3\times2$ matrix of rank $2$ has independent columns and no free variables, so reachable right-hand sides have unique solutions, but not every vector in $\R^3$ is reachable. The two cases have the same rank and entirely different output-side behavior; the shape must always be stated.

### A complete exam example to imitate

Take $A=\begin{bmatrix}1&1&2\\2&3&5\end{bmatrix}$. Replace $R_2\gets R_2-2R_1$, obtaining $U=\begin{bmatrix}1&1&2\\0&1&1\end{bmatrix}$. Pivot columns are 1 and 2, so $r=2$. The original columns 1 and 2 yield $\Col A=\span\{(1,2),(1,3)\}$. The nonzero rows of $U$ yield $\Row A=\span\{(1,1,2),(0,1,1)\}$. For the null space, solve $x_2+x_3=0$ and $x_1+x_2+2x_3=0$. Let $x_3=t$, giving $x_2=-t$ and $x_1=t-2t=-t$. Thus $\Nul A=\span\{(-1,-1,1)\}$. Check $A(-1,-1,1)^T=(-1-1+2,-2-3+5)^T=0$. Dimensions are $2,2,1$ respectively, and $r+\nu=2+1=3$ columns.

### True-or-false with a reason, not a guess

“If the columns of $A$ are dependent, every system $A\mathbf x=\mathbf b$ is inconsistent” is false: $\mathbf b=\mathbf0$ always gives a consistent homogeneous system. “If a matrix has a pivot in every row, its columns are independent” is false for a wide matrix such as a rank-$2$ $2\times3$ matrix. “If $\Col A=\R^m$, $A$ has rank $m$” is true by the definition of rank. “If row operations preserve rank, they preserve column space” is false: rank is a dimension, not the entire subspace. These explanations are as valuable on the exam as the True/False letters.

### The final checks

Never report a $\Col A$ basis vector with $n$ entries unless the matrix also happens to have $m=n$; column vectors always have $m$ entries. Never report a $\Nul A$ basis vector with $m$ entries if $m\ne n$; null vectors have $n$ entries. Confirm every proposed column-space basis vector is literally a column of the original matrix at one of the pivot indices, every row basis vector is a nonzero row from the echelon matrix, and every null basis vector satisfies $A\mathbf v=0$. Count pivots only once; a pivot's position is tied to its column, not to the number of nonzero numbers in that column. If your basis counts fail $r+\nu=n$, revisit the free variables.


### Different matrices can have the same rank and different spaces

Consider $A=\begin{bmatrix}1&1\\1&1\end{bmatrix}$ and $B=\begin{bmatrix}1&1\\0&0\end{bmatrix}$. They are row equivalent because $R_2\gets R_2-R_1$ turns $A$ into $B$. Both have one pivot, hence rank one. Their row spaces agree: each is the span of $(1,1)$. Their null spaces also agree, since both reduce to the equation $x_1+x_2=0$. But their column spaces are different lines: $\Col A=\span\{(1,1)\}$ and $\Col B=\span\{(1,0)\}$. Equal rank means equal **dimension**, not equal column spaces.

This counterexample is particularly useful for True/False items. “Row operations preserve all four subspaces” is false. “Row operations preserve the number of pivot columns” is true. “The nonzero rows of an echelon form are a basis for the original row space” is true. “Its pivot columns are always a basis for the original column space” is false unless you go back to the original matrix. Each conclusion follows from a specific part of the same calculation.

:::example[Example 4.21 — Finding Bases for All Three Fundamental Subspaces]
For $A=\begin{bmatrix}1&2&-1&3\\2&4&0&4\\-1&-2&-1&-1\end{bmatrix}$, find bases for $\Row A$, $\Col A$, and $\Nul A$, and state the dimensions.


::::answer[Answer]
**Answer:** $\Col A$, $\Row A$, and $\Nul A$ have the bases derived below; $\rank A=2$, $\nullity A=2$.

1. **Step 1 — Row reduce:**

$$
\begin{bmatrix}1&2&-1&3\\2&4&0&4\\-1&-2&-1&-1\end{bmatrix}
    \xrightarrow{R_2-2R_1,\;R_3+R_1}
    \begin{bmatrix}1&2&-1&3\\0&0&2&-2\\0&0&-2&2\end{bmatrix}
    \xrightarrow{R_3+R_2}
    \begin{bmatrix}1&2&-1&3\\0&0&2&-2\\0&0&0&0\end{bmatrix}
$$

2. Pivots in columns 1 and 3. $\rank(A)=2$.

3. **Basis for $\Row A$:** nonzero rows of the echelon form:

$$
\left\{(1,2,-1,3),\;(0,0,2,-2)\right\}
$$

4. **Basis for $\Col A$:** columns 1 and 3 of original $A$:

$$
\left\{\begin{bmatrix}1\\2\\-1\end{bmatrix},\begin{bmatrix}-1\\0\\-1\end{bmatrix}\right\}
$$

5. **Basis for $\Nul A$:** free vars $x_2, x_4$. From echelon: row 2 gives $2x_3=2x_4\Rightarrow x_3=x_4$. Row 1: $x_1=-2x_2+x_3-3x_4=-2x_2+x_4-3x_4=-2x_2-2x_4$. Set $(x_2,x_4)=(1,0)$: $(-2,1,0,0)$. Set $(0,1)$: $(-2,0,1,1)$.

$$
\text{Basis for }\Nul A=\left\{\begin{bmatrix}-2\\1\\0\\0\end{bmatrix},\begin{bmatrix}-2\\0\\1\\1\end{bmatrix}\right\}
$$

6. Check: $2+2=4$ ✓ (rank–nullity).
::::
:::

### Additions to the Invertible Matrix Theorem

:::theorem[Theorem 4.12 — IMT (Extended)]
For an $n\times n$ matrix $A$, the following are equivalent to $A$ being invertible (add to the original IMT from §2.3):

1. The columns of $A$ form a basis for $\R^n$.
2. $\Col A = \R^n$
3. $\dim(\Col A)=n$
4. $\rank(A)=n$
5. $\Nul A=\{\mathbf{0}\}$
6. $\dim(\Nul A)=0$
:::

:::example[Example 4.22 — All three spaces from one small matrix]
For $A=\begin{bmatrix}1&1&2\\2&3&5\end{bmatrix}$, find bases for $\Col A$, $\Row A$, and $\Nul A$.


::::answer[Answer]
**Answer:** $\Col A$: $\{(1,2),(1,3)\}$; $\Row A$: $\{(1,1,2),(0,1,1)\}$; $\Nul A$: $\{(-1,-1,1)\}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Replace $R_2\gets R_2-2R_1$, giving $U=\begin{bmatrix}1&1&2\\0&1&1\end{bmatrix}$. Its pivots are in columns 1 and 2, so use those **original** columns $(1,2),(1,3)$ for the column basis. Use both nonzero rows of $U$ for the row basis. For the null space, $x_2+x_3=0$ gives $x_2=-t$ when $x_3=t$. Then $x_1+x_2+2x_3=0$ gives $x_1=-t$. Therefore $\mathbf x=t(-1,-1,1)$. Multiplication by $A$ verifies zero. Rank $2$, nullity $1$, and $2+1=3$.
::::
:::

:::example[Example 4.23 — Rank two does not guarantee invertibility]
A matrix $A$ is $2\times3$ and has rank $2$. State whether $A\mathbf x=\mathbf b$ is solvable for every $\mathbf b\in\R^2$, and whether any solution can be unique.


::::answer[Answer]
**Answer:** Every $\mathbf b\in\mathbb R^2$ is reachable, but no solution is unique.

1. every $\mathbf b\in\R^2$ is reachable, but no solution is unique.

2. Because $r=m=2$, $\Col A=\R^2$, making every system consistent. Rank–nullity gives $\nullity(A)=n-r=3-2=1$, so the homogeneous equation has a nonzero solution $\mathbf z$. If $\mathbf x_p$ solves $A\mathbf x=\mathbf b$, then $\mathbf x_p+t\mathbf z$ also solves it for every $t\in\R$, producing infinitely many distinct solutions. The non-square matrix has no ordinary two-sided inverse.
::::
:::



:::callout-pitfall[The three bases come from different places]
Use the **original** pivot columns for $\Col A$; nonzero **echelon** rows for $\Row A$; and the free-variable vectors for $\Nul A$. A row operation can alter $\Col A$ even while it preserves rank. Before handing in, verify every null basis vector by multiplication with the original $A$.
:::

:::problem[Problem 4.31 — Find a null-space basis]{difficulty=easy}
A $3\times 5$ matrix $A$ has $\rank=2$. State the dimensions of $\Col A$, $\Row A$, and $\Nul A$.


::::solution[Solution]
**Answer:** $\dim(\Col A)=2$ (in $\R^3$), $\dim(\Row A)=2$ (in $\R^5$), $\dim(\Nul A)=5-2=3$ (in $\R^5$).

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. $\dim(\Col A)=2$ (in $\R^3$), $\dim(\Row A)=2$ (in $\R^5$), $\dim(\Nul A)=5-2=3$ (in $\R^5$).
::::
:::

:::problem[Problem 4.32 — Find a row-space basis]{difficulty=standard}
Find a basis for the row space of $B=\begin{bmatrix}1&-2&5&-3\\2&-5&8&-4\\-3&8&-9&3\end{bmatrix}$.


::::solution[Solution]
**Answer:** $\Row B$ basis $\{(1,-2,5,-3),(0,-1,-2,2),(0,0,2,-2)\}$; rank $3$.

1. Row reduce: $R_2-2R_1\to(0,-1,-2,2)$; $R_3+3R_1\to(0,2,6,-6)$; then $R_3+2R_2\to(0,0,2,-2)$. Nonzero rows of echelon form: $\{(1,-2,5,-3),\;(0,-1,-2,2),\;(0,0,2,-2)\}$. $\rank=3$.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 4.33 — Test consistency]{difficulty=challenge}
Suppose $A$ is $4\times 4$ with $\rank(A)=3$. How many solutions does $A\mathbf{x}=\mathbf{b}$ have when it is consistent? When is it consistent?


::::solution[Solution]
**Answer:** $\nullity=4-3=1$, so the homogeneous equation has a 1-parameter family of solutions. When $A\mathbf{x}=\mathbf{b}$ is consistent, it has *infinitely many* solutions (a particular solution plus one free parameter). Consistency: $\mathbf{b}\in\Col A$, which is a 3-dimensional subspace of $\R^4$ — so not every $\mathbf{b}$ works.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $\nullity=4-3=1$, so the homogeneous equation has a 1-parameter family of solutions. When $A\mathbf{x}=\mathbf{b}$ is consistent, it has *infinitely many* solutions (a particular solution plus one free parameter). Consistency: $\mathbf{b}\in\Col A$, which is a 3-dimensional subspace of $\R^4$ — so not every $\mathbf{b}$ works.
::::
:::

:::problem[Problem 4.34 — Find a null-space basis]{difficulty=easy}
For a $2\times4$ matrix of rank $2$, state the dimensions of its column space, row space, and null space.


::::solution[Solution]
**Answer:** $2,2,2$ respectively. Column-space and row-space dimensions equal rank $2$; nullity is $4-2=2$.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. $2,2,2$ respectively. Column-space and row-space dimensions equal rank $2$; nullity is $4-2=2$.
::::
:::

:::problem[Problem 4.35 — Find a null-space basis]{difficulty=standard}
For $A=\begin{bmatrix}1&1&0\\0&1&2\end{bmatrix}$, find bases of all three spaces and check rank–nullity.


::::solution[Solution]
**Answer:** $\Col A$: $\{(1,0),(1,1)\}$; $\Row A$: $\{(1,1,0),(0,1,2)\}$; $\Nul A$: $\{(2,-2,1)\}$; rank $2$, nullity $1$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $\Col A$ basis $\{(1,0),(1,1)\}$; $\Row A$ basis $\{(1,1,0),(0,1,2)\}$; $\Nul A$ basis $\{(2,-2,1)\}$. Both rows are already echelon. Pivots are in original columns 1 and 2. Solve $x_2+2x_3=0$: with $x_3=t$, $x_2=-2t$. Then $x_1+x_2=0$ gives $x_1=2t$. Rank $2$, nullity $1$, and $2+1=3$ columns.
::::
:::

:::problem[Problem 4.36 — Solve by row operations]{difficulty=standard}
True or false, justify: (a) row-equivalent matrices always have the same column space; (b) a matrix with a pivot in every column has trivial null space; (c) a full-row-rank $3\times5$ matrix has nullity $2$.


::::solution[Solution]
**Answer:** (a) false; (b) true; (c) true.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. (a) False, because row operations can change the column vectors; (b) True, because no free variables remain in $A\mathbf x=0$; (c) True, because rank $3$ and $n=5$ yield $\nullity=5-3=2$. For (a), compare $\begin{bmatrix}1&1\\1&1\end{bmatrix}$ with the row-equivalent $\begin{bmatrix}1&1\\0&0\end{bmatrix}$, whose column spaces are different lines.
::::
:::

:::summary
## Chapter Summary

### Key results

#### Vector spaces and subspaces

**A vector space** is a set with an addition and a scalar multiplication satisfying the eight
 algebraic properties from §1.3 — commutativity, associativity, a zero vector, additive
 inverses, the two distributive laws, associativity of scalars, and $1\mathbf{u} = \mathbf{u}$.
 The point of the abstraction is that the elements need not be lists of numbers: polynomials,
 matrices and functions all qualify, and every theorem proved here applies to all of them.

**The Subspace Test.** A **nonempty** subset $H$ of a vector space $V$ is a subspace if and
 only if both hold:

1. **Closed under addition:** for all $\mathbf{u}, \mathbf{v} \in H$,
   $\mathbf{u} + \mathbf{v} \in H$.
2. **Closed under scalar multiplication:** for all $\mathbf{u} \in H$ and all $c \in \R$,
   $c\mathbf{u} \in H$.

Two conditions, not three: $\mathbf{0} \in H$ follows from the second with $c = 0$, provided
 $H$ is nonempty. Checking $\mathbf{0} \in H$ is still the fastest way to *disqualify* a set.

#### The spaces attached to a matrix

For an $m \times n$ matrix $A$:

$$
\Nul A = \{\mathbf{x} : A\mathbf{x} = \mathbf{0}\} \subseteq \R^n,
\qquad
\Col A = \span\{\text{columns of } A\} \subseteq \R^m
$$

$\Row A$ is the span of the rows, a subspace of $\R^n$. Keep the ambient spaces straight:
 $\Nul A$ and $\Row A$ live in $\R^n$, $\Col A$ lives in $\R^m$.

**Column space and consistency.** $A\mathbf{x} = \mathbf{b}$ is consistent **if and only if**
 $\mathbf{b} \in \Col A$. That is the definition of the column space restated, and it is what
 makes it worth naming.

**Kernel and range** are the same two ideas for a linear transformation $T$: the kernel is
 everything sent to $\mathbf{0}$, the range is everything actually hit. For $T(\mathbf{x}) =
 A\mathbf{x}$ the kernel is $\Nul A$ and the range is $\Col A$.

#### Bases and dimension

**A basis** for a subspace $H$ is a set that is both linearly independent **and** spans $H$.
 Both halves are required — a spanning set that is dependent has redundancy, an independent
 set that does not span misses part of $H$.

**The Spanning Set Theorem.** If one vector in a spanning set is a linear combination of the
 others, it can be deleted and the span is unchanged; repeating this, any spanning set of
 $H \neq \{\mathbf{0}\}$ contains a basis. Spanning sets can always be trimmed down to a
 basis; independent sets can always be extended up to one.

**Unique representation.** If $\mathcal{B} = \{\mathbf{b}_1, \ldots, \mathbf{b}_n\}$ is a
 basis for $V$, then every $\mathbf{x} \in V$ has **exactly one** expression

$$
\mathbf{x} = c_1\mathbf{b}_1 + c_2\mathbf{b}_2 + \cdots + c_n\mathbf{b}_n
$$

Uniqueness is what independence buys, and it is what makes coordinates well defined.

**$\mathcal{B}$-coordinates.** The weights above, collected as a vector, are the coordinate
 vector $[\mathbf{x}]_{\mathcal{B}}$. With
 $P_{\mathcal{B}} = [\,\mathbf{b}_1\ \mathbf{b}_2\ \cdots\ \mathbf{b}_n\,]$, the
 change-of-coordinates matrix:

$$
\mathbf{x} = P_{\mathcal{B}}\,[\mathbf{x}]_{\mathcal{B}}
\qquad\text{and}\qquad
[\mathbf{x}]_{\mathcal{B}} = P_{\mathcal{B}}^{-1}\mathbf{x}
$$

The coordinate mapping $\mathbf{x} \mapsto [\mathbf{x}]_{\mathcal{B}}$ is an **isomorphism**:
 any $n$-dimensional vector space behaves exactly like $\R^n$ once a basis is fixed, which is
 why results proved for $\R^n$ transfer to polynomials and matrices unchanged.

**Dimension** is the number of vectors in a basis. It is well defined because every basis of
 a given space has the same size.

**The $n$-vector tests.** If $\dim V = n$ and $S$ has **exactly $n$** vectors, then these are
 equivalent: $S$ is a basis; $S$ is linearly independent; $S$ spans $V$. With the right count,
 checking either property gives you the other for free — but the count must be right first.

#### Rank

**Rank and nullity.** $\rank(A) = \dim \Col A$, the number of pivot columns;
 $\nullity(A) = \dim \Nul A$, the number of free variables. The **Rank–Nullity Theorem** says

$$
\rank(A) + \nullity(A) = n
$$

where $n$ is the number of **columns** of $A$. Every column is either a pivot column or free.

**Row rank equals column rank:** $\dim \Row A = \dim \Col A = \rank(A)$. The row space and
 column space usually sit in different spaces and contain different vectors, yet always have
 the same dimension.

**Finding each basis** — all three come from one row reduction, but they are read off
 differently, and mixing them up is the most common error in this chapter:

| space | basis |
| --- | --- |
| $\Col A$ | the pivot columns **of the original $A$** |
| $\Row A$ | the **nonzero rows of the echelon form** |
| $\Nul A$ | the vectors attached to free variables in the parametric solution |

Row operations preserve the row space but change the column space, which is exactly why the
 row basis is taken from the reduced matrix and the column basis from the original one.

**The Invertible Matrix Theorem, extended.** For an $n \times n$ matrix, add to the Chapter 2
 list: $A$ is invertible $\iff$ $\Col A = \R^n$ $\iff$ $\rank(A) = n$ $\iff$
 $\Nul A = \{\mathbf{0}\}$ $\iff$ $\nullity(A) = 0$ $\iff$ the columns of $A$ form a basis for
 $\R^n$.

### If you remember nothing else

A subspace is a set closed under the two operations; a basis is the smallest set that still
 describes it; dimension is how many vectors that takes. **One row reduction answers almost
 every question in this chapter** — it gives the pivot columns (a basis for $\Col A$), the
 nonzero echelon rows (a basis for $\Row A$), the free variables (a basis for $\Nul A$), and
 the two numbers whose sum is the column count.
:::

## Mixed Practice

These problems reflect the depth and style of MA 3113 exams.

:::problem[Problem M.1 — Test the subspace property]{difficulty=easy}
Which of the following are subspaces of $\R^2$? Justify each answer.

(a) $\{(x,y): y=3x\}$ (b) $\{(x,y): x\ge 0\}$ (c) $\{(x,y): x+y=0\}$ (d) $\{(0,0)\}$


::::solution[Solution]
**Answer:** (a) yes; (b) no; (c) yes; (d) yes.

1. (a) **Yes.** Lines through the origin are subspaces. Closed under + and scalar mult.

2. (b) **No.** If $(1,0)\in H$, then $-1\cdot(1,0)=(-1,0)\notin H$. Scalar mult. fails.

3. (c) **Yes.** Same as (a) — this is $y=-x$, a line through the origin.

4. (d) **Yes.** The trivial subspace.
::::
:::

:::problem[Problem M.2 — Find a null-space basis]{difficulty=standard}
Let $A=\begin{bmatrix}2&0&-6\\-1&3&4\\-1&3&4\end{bmatrix}$. Find bases for $\Col A$, $\Row A$, and $\Nul A$. State the rank and nullity.


::::solution[Solution]
**Answer:** $\rank A=2$, $\nullity A=1$; the three fundamental-space bases appear below.

1. Row reduce: $R_2+\tfrac{1}{2}R_1\to(0,3,1)$; $R_3+\tfrac{1}{2}R_1\to(0,3,1)$; $R_3-R_2\to(0,0,0)$. Echelon form: $\begin{bmatrix}2&0&-6\\0&3&1\\0&0&0\end{bmatrix}$.

2. $\rank=2$, pivots in cols 1, 2.

3. **Basis for $\Col A$:** $\left\{\begin{bmatrix}2\\-1\\-1\end{bmatrix},\begin{bmatrix}0\\3\\3\end{bmatrix}\right\}$.

4. **Basis for $\Row A$:** $\{(2,0,-6),(0,3,1)\}$.

5. **Basis for $\Nul A$:** Free var $x_3$: row 2 gives $x_2=-x_3/3$, row 1 gives $x_1=3x_3$. Setting $x_3=3$: $\begin{bmatrix}9\\-1\\3\end{bmatrix}$. Nullity = 1.
::::
:::

:::problem[Problem M.3 — Test or construct a basis]{difficulty=standard}
Let $\mathcal{B}=\{1+t,\;2-t+t^2,\;t^2\}$ be a basis for $\mathcal{P}_2$. Find $[3+5t+2t^2]_{\mathcal{B}}$.


::::solution[Solution]
**Answer:** $[3+5t+2t^2]_{\mathcal B}=(13/3,-2/3,8/3)^T$.

1. Solve $c_1(1+t)+c_2(2-t+t^2)+c_3(t^2)=3+5t+2t^2$.

2. constant: $c_1+2c_2=3$; $t$: $c_1-c_2=5$; $t^2$: $c_2+c_3=2$.

3. From first two: subtract to get $3c_2=-2\Rightarrow c_2=-2/3$. Then $c_1=5+c_2=13/3$. Then $c_3=2-c_2=8/3$. So $[p]_{\mathcal{B}}=\begin{bmatrix}13/3\\-2/3\\8/3\end{bmatrix}$.

4. Check all three coefficient equations: $13/3+2(-2/3)=3$, $13/3-(-2/3)=5$, and $(-2/3)+(8/3)=2$. These reconstruct the original polynomial exactly. Since the three basis polynomials are linearly independent, matching the three coefficients fixes the coordinates uniquely and leaves no arbitrary parameter.
::::
:::

:::problem[Problem M.4 — Solve by row operations]{difficulty=standard}
True or False. Justify each.

(a) If $\{v_1,v_2,v_3\}$ is a basis for $V$, then $\dim V=3$.

(b) If $A$ is $5\times 7$ and has rank 4, then $\Nul A$ is 3-dimensional.

(c) A basis for $\Nul A$ consists of vectors in $\R^m$ if $A$ is $m\times n$.

(d) Row operations do not change $\Col A$.


::::solution[Solution]
**Answer:** (a) true; (b) true; (c) false; (d) false.

1. (a) **True.** By definition, dimension = number of basis vectors.

2. (b) **True.** $\nullity=7-4=3$.

3. (c) **False.** $\Nul A\subseteq\R^n$ (column space of $A$ is in $\R^m$, but null space is in the domain $\R^n$).

4. (d) **False.** Row operations preserve the row space but can change the column space.
::::
:::

:::problem[Problem M.5 — Find a column-space basis]{difficulty=challenge}
Suppose $A$ is a $3\times 3$ matrix with $\rank(A)=2$ and $\mathbf{v}_1,\mathbf{v}_2$ are vectors not in $\Col A$. Must $\{\mathbf{v}_1,\mathbf{v}_2\}$ be linearly independent? Prove or give a counterexample.


::::solution[Solution]
**Answer:** No, two vectors outside the column space need not be independent.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. **No.** Counterexample: $A=\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}$. Then $\Col A=\span\{\mathbf{e}_1,\mathbf{e}_2\}$. Take $\mathbf{v}_1=\mathbf{e}_3$ and $\mathbf{v}_2=2\mathbf{e}_3$. Neither is in $\Col A$, but $\mathbf{v}_2=2\mathbf{v}_1$ so they are linearly dependent.
::::
:::

:::problem[Problem M.6 — Test or construct a basis]{difficulty=challenge}
Let $V$ be the set of all $2\times 2$ matrices of the form $\begin{bmatrix}a&b\\0&c\end{bmatrix}$ (upper triangular). Show $V$ is a subspace of $\mathcal{M}_{2\times 2}$ and find a basis. What is $\dim V$?


::::solution[Solution]
**Answer:** Yes, the upper-triangular matrices form a subspace.

1. **Subspace:** (i) Zero matrix $\in V$. (ii) Sum of two upper triangular matrices is upper triangular. (iii) Scalar multiple of upper triangular is upper triangular. ✓

2. **Basis:** Any matrix in $V$ is $a\begin{bmatrix}1&0\\0&0\end{bmatrix}+b\begin{bmatrix}0&1\\0&0\end{bmatrix}+c\begin{bmatrix}0&0\\0&1\end{bmatrix}$. These three matrices are linearly independent and span $V$. **Basis has 3 vectors; $\dim V=3$.**
::::
:::

:::problem[Problem M.7 — Find a null-space basis]{difficulty=easy}
For a $3\times4$ matrix $A$, in which spaces do the vectors of $\Nul A$ and $\Col A$ live?


::::solution[Solution]
**Answer:** $\Nul A\subseteq\R^4$ and $\Col A\subseteq\R^3$. Inputs have four coordinates; outputs have three.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

2. $\Nul A\subseteq\R^4$ and $\Col A\subseteq\R^3$. Inputs have four coordinates; outputs have three.

3. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.
::::
:::

:::problem[Problem M.8 — Test the subspace property]{difficulty=easy}
Is $H=\{(x,y)\in\R^2:x+y=3\}$ a subspace? Justify.


::::solution[Solution]
**Answer:** No; the set omits $\mathbf0$ because $0+0\ne3$.

1. Use the defining equation to test the zero element, addition and real scaling. A parameterization as a span gives the same three conditions automatically.

2. **Answer: no.** The zero vector has $0+0=0\ne3$, so $\mathbf0\notin H$. One failure suffices.

3. Check the result against the definition: an affirmative subspace claim must include the zero vector, sums and scalar multiples; one counterexample suffices for a negative claim.
::::
:::

:::problem[Problem M.9 — Test or construct a basis]{difficulty=standard}
Find the basis and dimension of $H=\{(a,b,c)\in\R^3:a+2b-c=0\}$.


::::solution[Solution]
**Answer:** basis $\{(-2,1,0),(1,0,1)\}$, dimension $2$. Set $b=s,c=t$, then $a=-2s+t$ and $(a,b,c)=s(-2,1,0)+t(1,0,1)$. The vectors are independent because the second and third coordinates isolate the coefficients.

1. basis $\{(-2,1,0),(1,0,1)\}$, dimension $2$. Set $b=s,c=t$, then $a=-2s+t$ and $(a,b,c)=s(-2,1,0)+t(1,0,1)$. The vectors are independent because the second and third coordinates isolate the coefficients.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem M.10 — Find a null-space basis]{difficulty=standard}
Let $A=\begin{bmatrix}1&1&2\\2&3&5\end{bmatrix}$. Find the rank, nullity, and a basis of $\Nul A$.


::::solution[Solution]
**Answer:** rank $2$, nullity $1$, basis $\{(-1,-1,1)\}$. Replace row 2 by row 2 minus twice row 1, obtaining $\begin{bmatrix}1&1&2\\0&1&1\end{bmatrix}$. Set $x_3=t$, so $x_2=-t$ and $x_1=-t$. Both equations are satisfied.

1. rank $2$, nullity $1$, basis $\{(-1,-1,1)\}$. Replace row 2 by row 2 minus twice row 1, obtaining $\begin{bmatrix}1&1&2\\0&1&1\end{bmatrix}$. Set $x_3=t$, so $x_2=-t$ and $x_1=-t$. Both equations are satisfied.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem M.11 — Change coordinates]{difficulty=standard}
Given $\mathcal B=((1,1),(2,1))$ and $\mathbf x=(7,4)^T$, find $[\mathbf x]_{\mathcal B}$.


::::solution[Solution]
**Answer:** $(1,3)^T$. The equations are $c_1+2c_2=7$, $c_1+c_2=4$. Subtract to get $c_2=3$, then $c_1=1$. Check $(1,1)+3(2,1)=(7,4)$.

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. $(1,3)^T$. The equations are $c_1+2c_2=7$, $c_1+c_2=4$. Subtract to get $c_2=3$, then $c_1=1$. Check $(1,1)+3(2,1)=(7,4)$.
::::
:::

:::problem[Problem M.12 — Test consistency]{difficulty=challenge}
A $4\times6$ matrix has rank $4$. Can its columns be independent? Does $A\mathbf x=\mathbf b$ have a solution for every $\mathbf b\in\R^4$? When it is consistent, can the solution be unique?


::::solution[Solution]
**Answer:** columns dependent; every $\mathbf b$ reachable; no unique solution. With $n=6$ and rank $4$, the nullity is $6-4=2$. Since $r=m=4$, $\Col A=\R^4$. Every particular solution has two free parameters, so infinitely many solutions.

1. columns dependent; every $\mathbf b$ reachable; no unique solution. With $n=6$ and rank $4$, the nullity is $6-4=2$. Since $r=m=4$, $\Col A=\R^4$. Every particular solution has two free parameters, so infinitely many solutions.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::
