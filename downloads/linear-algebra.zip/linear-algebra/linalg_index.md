---
title: "Linear Algebra"
crumb: "Self-study Textbook"
source: "linalg_index.html"
---

MA 3113 — Mississippi State University
 Based on Dr. Seongjai Kim's Lecture Notes
 Ref: Lay, Lay & McDonald 6th Ed.

This self-study textbook follows the MA 3113 curriculum at Mississippi State. It covers
 solving linear systems, matrix algebra, determinants, vector spaces, eigenvalues, and
 orthogonality — with intuition-first explanations, fully-worked examples, and practice
 problems at every step. Applications include regression analysis and Markov chains.

6 / 6 — Chapters done

~10h — Est. total study time

## Chapters

:::solution[✓
 Ch 1
 \[Linear Equations\](linalg_ch1_linear_equations.html)
 120 min ▶]
- 1.1 — Systems of Linear Equations
- 1.2 — Row Reduction and Echelon Forms

  - 1.2.1Echelon Forms
  - 1.2.2The General Solution of Linear Systems

- 1.3 — Vector Equations

  - 1.3.1Vectors in ℝⁿ
  - 1.3.2Linear Combinations and Span

- 1.4 — Matrix Equation Ax = b
- 1.5 — Solution Sets of Linear Systems

  - 1.5.1Solutions of Homogeneous Linear Systems
  - 1.5.2Solutions of Nonhomogeneous Linear Systems

- 1.7 — Linear Independence
- 1.8 — Linear Transformations
- 1.9 — The Matrix of a Linear Transformation

  - 1.9.1The Standard Matrix
  - 1.9.2Existence and Uniqueness Questions
:::

:::solution[✓
 Ch 2
 \[Matrix Algebra\](linalg_ch2_matrix_algebra.html)
 105 min ▶]
- 2.1 — Matrix Operations

  - 2.1.1Sum, Scalar Multiple, and Matrix Multiplication
  - 2.1.2Properties of Matrix Multiplication

- 2.2 — The Inverse of a Matrix
- 2.3 — Characterizations of Invertible Matrices
- 2.5 — Solving Linear Systems by Matrix Factorizations

  - 2.5.1The LU Factorization / Decomposition
  - 2.5.2Solutions of Triangular Algebraic Systems

- 2.8 — Subspaces of ℝⁿ
- 2.9 — Dimension and Rank

  - 2.9.1Coordinate Systems
  - 2.9.2Dimension of a Subspace
:::

:::solution[✓
 Ch 3
 \[Determinants\](linalg_ch3_determinants.html)
 60 min ▶]
- 3.1 — Introduction to Determinants
- 3.2 — Properties of Determinants
:::

:::solution[✓
 Ch 4
 \[Vector Spaces\](linalg_ch4_vector_spaces.html)
 90 min ▶]
- 4.1 — Vector Spaces and Subspaces
- 4.2 — Null Spaces, Column Spaces, and Linear Transformations
:::

:::solution[✓
 Ch 5
 \[Eigenvalues & Eigenvectors\](linalg_ch5_eigenvalues.html)
 120 min ▶]
- 5.1 — Eigenvectors and Eigenvalues
- 5.2 — The Characteristic Equation and Similarity Transformation
- 5.3 — Diagonalization

  - 5.3.1The Diagonalization Theorem
  - 5.3.2Diagonalizable Matrices

- 5.5 — Complex Eigenvalues
- 5.7 — Applications to Differential Equations

  - 5.7.1Dynamical Systems: First-Order Differential Equations
  - 5.7.2Attractors, Repellers, and Saddle Points

- 5.8 — Iterative Estimates for Eigenvalues

  - 5.8.1The Power Method
  - 5.8.2Inverse Power Method

- 5.9 — Applications to Markov Chains

  - 5.9.1Probability Vectors and Stochastic Matrices
  - 5.9.2Steady-State Vectors
:::

:::solution[✓
 Ch 6
 \[Orthogonality & Least Squares\](linalg_ch6_orthogonality.html)
 105 min ▶]
- 6.1 — Inner Product, Length, and Orthogonality

  - 6.1.1Inner Product and Length
  - 6.1.2Orthogonal Vectors

- 6.2 — Orthogonal Sets

  - 6.2.1An Orthogonal Projection
  - 6.2.2Orthonormal Basis and Orthogonal Matrix

- 6.3 — Orthogonal Projections
- 6.4 — The Gram-Schmidt Process and QR Factorization

  - 6.4.1The Gram-Schmidt Process
  - 6.4.2QR Factorization of Matrices

- 6.5 — Least-Squares Problems
- 6.6 — Machine Learning: Regression Analysis

  - 6.6.1Regression Line
  - 6.6.2Least-Squares Fitting of Other Curves
:::

## Resources

External references for this subject:

- Primary: Seongjai Kim, *Introduction to Linear Algebra* — [Lecture Notes PDF](http://skim.math.msstate.edu/LectureNotes/Linear_Algebra_LectureNote.pdf)
- Reference: Lay, Lay & McDonald, *Linear Algebra and Its Applications*, 6th Ed.
- Syllabus: [MA 3113 Syllabus PDF](https://skim.math.msstate.edu/Class/ma3113-LinAlg-23fall/MA3113-Linear-Algebra-Syllabus.pdf)
- Lecture videos: [Dr. Kim's YouTube (@mathtalent)](https://www.youtube.com/@mathtalent)
- 3Blue1Brown — [*Essence of Linear Algebra*](https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab)
