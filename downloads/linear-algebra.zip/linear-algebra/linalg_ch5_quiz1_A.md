---
source: "markdown"
title: "Practice Quiz 1 A: Realistic Warm-Up"
crumb: "Linear Algebra · Chapter 5 quiz prep"
meta:
  - "MA 3113 · Pant · no calculator"
  - "Time limit: 50 minutes"
  - "Chapter 5: 5.1–5.3, 5.5, 5.7, 5.9"
---

## Instructions

No calculator. Write enough arithmetic to justify every determinant, eigenspace, and conclusion. Choose exactly one option (A)–(E) on each multiple-choice question; (E) always means “I don't know.” For free response, show the shortest correct by-hand method, including a check when possible. Solutions are collapsed in Lectern; attempt the question before opening one.

### Multiple Choice

:::problem[Problem 1 — Proposed eigenvector]{difficulty=easy}

Decide whether the displayed nonzero vector is an eigenvector of $A$ for the stated eigenvalue. Give the decisive multiplication.

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix}
$$

$$
\mathbf v=\begin{bmatrix}1\\0\end{bmatrix}
$$
Proposed $\lambda=2$.

(A) Yes; the proposed eigenpair works.

(B) No; the proposed eigenpair fails.

(C) Yes; every nonzero vector is an eigenvector.

(D) Yes; any triangular matrix has this eigenpair.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Yes; the proposed eigenpair works.

1. The proposed vector is nonzero, so it is eligible for the eigenvector definition $A\mathbf v=\lambda\mathbf v$.

2. Multiply one row at a time: 
   
   $$
   A\mathbf v=\begin{bmatrix}2\\0\end{bmatrix}
   $$
   
   
   The displayed entries come from the dot products of the rows with $\mathbf v$.

3. The proposed multiple is 
   
   $$
   2\mathbf v=\begin{bmatrix}2\\0\end{bmatrix}
   $$
   
   
   Compare both coordinates, including any zero component.

4. All coordinates match; therefore this is a genuine eigenpair.

5. Check: direct multiplication is decisive; a characteristic-polynomial computation would be unnecessary for this question.

::::

:::
:::problem[Problem 2 — Upper-triangular spectrum]{difficulty=easy}

Find all eigenvalues of $A$. Use the quickest valid method.

$$
A=\begin{bmatrix}3&1&0\\0&-1&2\\0&0&2\end{bmatrix}
$$

(A) Eigenvalues: $0,3,4$.

(B) Eigenvalues: $-1,2,3$.

(C) Eigenvalues: $-2,1,2$.

(D) Eigenvalues: $1,-2,-3$.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Eigenvalues: $-1,2,3$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}3 - \lambda&1&0\\0&- \lambda - 1&2\\0&0&2 - \lambda\end{bmatrix}
   $$

2. The shifted matrix is triangular. Its determinant is the product of its diagonal entries, so no cofactor expansion or symbolic row reduction is required.

3. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 4 \lambda^{2} - \lambda - 6
   $$

4. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 3\right) \left(\lambda - 2\right) \left(\lambda + 1\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $-1,2,3$.

5. Check: the root sum is $4$, which matches $\operatorname{tr}(A)=4$; their product is $-6=\det A$.

::::

:::
:::problem[Problem 3 — Two-by-two characteristic polynomial]{difficulty=easy}

Compute $\det(A-\lambda I)$.

$$
A=\begin{bmatrix}2&1\\1&2\end{bmatrix}
$$

(A) Characteristic polynomial: $\lambda^{2} - 4 \lambda + 4$.

(B) Characteristic polynomial: $\lambda^{2} - 4 \lambda + 2$.

(C) Characteristic polynomial: $\lambda^{2} - 4 \lambda + 3$.

(D) Characteristic polynomial: $- \lambda^{2} + 4 \lambda - 3$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Characteristic polynomial: $\lambda^{2} - 4 \lambda + 3$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}2 - \lambda&1\\1&2 - \lambda\end{bmatrix}
   $$

2. For a $2\times2$ determinant, multiply the main diagonal and subtract the other diagonal: $ad-bc$. This is faster than row-reducing a symbolic matrix.

3. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=\lambda^{2} - 4 \lambda + 3
   $$

4. Factor the polynomial and set it equal to zero: 
   
   $$
   \left(\lambda - 3\right) \left(\lambda - 1\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $1,3$.

5. Check: the root sum is $4$, which matches $\operatorname{tr}(A)=4$; their product is $3=\det A$.

::::

:::
:::problem[Problem 4 — Zero eigenvalue and invertibility]{difficulty=easy}

Decide whether $A$ is invertible and whether $0$ is an eigenvalue.

$$
A=\begin{bmatrix}1&2\\2&4\end{bmatrix}
$$

(A) Invertible; $0$ is not an eigenvalue.

(B) Singular because the trace is nonzero.

(C) Invertible because an eigenvalue is positive.

(D) Singular; $0$ is an eigenvalue.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Singular; $0$ is an eigenvalue.

1. Compute the determinant by the ordinary $ad-bc$ rule: $\det A=0$.

2. The Invertible Matrix Theorem says $A$ is singular exactly when its determinant is zero.

3. Zero is an eigenvalue exactly when $A-0I=A$ has a nontrivial null space, which is the same singularity condition.

4. Check: the determinant and zero-eigenvalue conclusions are consistent, so they support rather than contradict each other.

::::

:::
:::problem[Problem 5 — Eigenspace basis from one equation]{difficulty=standard}

Which statement gives a basis and dimension for the indicated eigenspace?

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix}
$$

Given $\lambda=2$.

(A) Basis for $E_{2}$: $(1,0)^T$; dimension $1$.

(B) Basis for $E_{2}$: $(1,1)^T$; dimension $1$.

(C) Basis for $E_{2}$: $(1,2)^T$; dimension $1$.

(D) Basis for $E_{2}$: $(1,-1)^T$; dimension $1$.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Basis for $E_{2}$: $(1,0)^T$; dimension $1$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(2)I=\begin{bmatrix}0&1\\0&1\end{bmatrix}
   $$

2. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 2. 
   
   $$
   \begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

3. Pivot columns are 2; free variables are $x_1$. Each free variable supplies one independent eigendirection.

4. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}1\\0\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{2}=1$.

5. Check: $A\mathbf v_1=2\mathbf v_1$ for the displayed basis columns. They also solve the homogeneous equations.

::::

:::
:::problem[Problem 6 — Distinct roots and diagonalizability]{difficulty=easy}

Is $A$ diagonalizable?

$$
A=\begin{bmatrix}1&2\\0&4\end{bmatrix}
$$

(A) Not diagonalizable.

(B) Diagonalizable.

(C) Diagonalizable only if its determinant is positive.

(D) Not diagonalizable because it is not symmetric.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Diagonalizable.

1. Compute the characteristic polynomial and factor it: 
   
   $$
   \left(\lambda - 4\right) \left(\lambda - 1\right)=0.
   $$
   
   
   The eigenvalues, counted with algebraic multiplicity, are $1,4$.

2. For $\lambda=4$, 
   
   $$
   A-\lambda I=\begin{bmatrix}-3&2\\0&0\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $1$.

3. For $\lambda=1$, 
   
   $$
   A-\lambda I=\begin{bmatrix}0&2\\0&3\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $1$.

4. The eigenspace dimensions add to the matrix size, so there are enough independent eigenvectors to diagonalize.

5. Check: compare geometric multiplicity to algebraic multiplicity for **each** repeated root. The repeated root alone does not decide the verdict.

::::

:::
:::problem[Problem 7 — Complex conjugate roots]{difficulty=standard}

Find the (possibly complex) eigenvalues of $A$ exactly.

$$
A=\begin{bmatrix}2&-1\\1&2\end{bmatrix}
$$

(A) Eigenvalues: $2\pm 2i$.

(B) Eigenvalues: $3\pm i$.

(C) Eigenvalues: $2\pm i$.

(D) Eigenvalues: $2\pm $.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Eigenvalues: $2\pm i$.

1. Start with $A-\lambda I$ and its $2\times2$ determinant: 
   
   $$
   \begin{bmatrix}2 - \lambda&-1\\1&2 - \lambda\end{bmatrix}
   $$
   
   
   The polynomial is $\lambda^{2} - 4 \lambda + 5$.

2. Complete the square or use the quadratic equation. The equation $\lambda^{2} - 4 \lambda + 5=0$ has a negative discriminant, so its roots have nonzero imaginary parts.

3. The complex roots are $2\pm i$. Because the matrix is real, one conjugate root always accompanies the other.

4. Check: the roots sum to $4$ and their product is $5$, matching the trace and determinant.

::::

:::
:::problem[Problem 8 — Recognize a saddle]{difficulty=easy}

Classify the trajectories near the origin of $\mathbf{x}\prime=A\mathbf{x}$. Do not solve for coefficients.

$$
A=\begin{bmatrix}-2&0\\0&1\end{bmatrix}
$$

(A) Trajectory: Stable node.

(B) Trajectory: Unstable node.

(C) Trajectory: Inward spiral.

(D) Trajectory: Saddle.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Trajectory: Saddle.

1. Inspect the eigenvalues without solving for constants: $-2,1$. For a diagonal or triangular matrix, they are its diagonal entries.

2. Positive real parts make exponential modes grow; negative real parts make them decay. A nonzero imaginary part adds rotation.

3. Applying those signs to **both** modes gives saddle. A trajectory type cannot be inferred from only one eigenvalue.

4. Check: the eigenvalue signs agree with the stated long-time behaviour of the modes.

::::

:::
:::problem[Problem 9 — Uniform Markov steady state]{difficulty=standard}

Find the normalized steady-state probability vector of the column-stochastic matrix $P$.

$$
P=\begin{bmatrix}\frac{3}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{3}{4}\end{bmatrix}
$$

(A) Steady state: $(\frac{1}{2},\frac{1}{2})^T$.

(B) Steady state: $(\frac{3}{4},\frac{1}{2})^T$.

(C) Steady state: $(\frac{3}{2},\frac{1}{2})^T$.

(D) Steady state: $(1,0)^T$.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Steady state: $(\frac{1}{2},\frac{1}{2})^T$.

1. Check the column convention: every entry is nonnegative, and the columns of $P$ sum to one. Seek a probability vector satisfying $P\mathbf q=\mathbf q$.

2. Move all terms to the same side: 
   
   $$
   (P-I)\mathbf q=\mathbf0,\qquad P-I=\begin{bmatrix}- \frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&- \frac{1}{4}\end{bmatrix}
   $$

3. Divide row 1 by $- \frac{1}{4}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1\\\frac{1}{4}&- \frac{1}{4}\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(\frac{1}{4})R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

5. The null-space equations give a direction 
   
   $$
   \mathbf v=\begin{bmatrix}1\\1\end{bmatrix}
   $$
   
   
   This direction is not yet a probability vector unless its coordinates add to one.

6. Divide the nonnegative direction by the sum of its coordinates. The normalized steady state is 
   
   $$
   \mathbf q=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}
   $$

7. Check: 
   
   $$
   P\mathbf q=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}=\mathbf q,\qquad\sum q_i=1.
   $$
   
   
   All coordinates are nonnegative, which completes the probability requirement.

::::

:::
:::problem[Problem 10 — Compute an entry of a diagonal power]{difficulty=easy}

Compute entry $(1,1)$ of $A^{4}$ without a calculator. Use its structure.

$$
A=\begin{bmatrix}2&0\\0&-1\end{bmatrix}
$$

(A) Entry $(1,1)$ of $A^{4}$: $15$.

(B) Entry $(1,1)$ of $A^{4}$: $16$.

(C) Entry $(1,1)$ of $A^{4}$: $17$.

(D) Entry $(1,1)$ of $A^{4}$: $-16$.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Entry $(1,1)$ of $A^{4}$: $16$.

1. Read the requested entry and exponent carefully. A matrix power means **matrix multiplication**, not raising individual entries.

2. Use the shortest structure available: a diagonal matrix stays diagonal, while a matrix with distinct eigenvalues can be written $PD^kP^{-1}$. Its eigenvalues are $-1,2$.

3. Since the matrix is diagonal, simply raise each diagonal entry to the 4th power: 
   
   $$
   A^{4}=\begin{bmatrix}16&0\\0&1\end{bmatrix}
   $$

4. Read position $(1,1)$ from the completed matrix: $16$. Check its location before copying the result.

::::

:::
### Written Free Response

:::problem[Problem 11 — Sparse cofactor expansion in three dimensions]{difficulty=standard}

Find all eigenvalues of $A$ using a cofactor expansion, and show the characteristic polynomial.

$$
A=\begin{bmatrix}3&1&0\\1&3&0\\0&0&5\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Eigenvalues: $2,4,5$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}3 - \lambda&1&0\\1&3 - \lambda&0\\0&0&5 - \lambda\end{bmatrix}
   $$

2. Expand along column 3, where 2 entries vanish; the cofactor signs alternate across each row and column.

3. The surviving signed minors give 
   
   $$
   \det(A-\lambda I)=(5 - \lambda)\det\begin{bmatrix}3 - \lambda&1\\1&3 - \lambda\end{bmatrix}
   $$

4. Evaluate each $2\times2$ minor explicitly using $ad-bc$ before expanding: 
   
   $$
   +(5 - \lambda)\left[(3 - \lambda)(3 - \lambda)-(1)(1)\right]
   $$

5. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 11 \lambda^{2} - 38 \lambda + 40
   $$

6. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 5\right) \left(\lambda - 4\right) \left(\lambda - 2\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $2,4,5$.

7. Check: the root sum is $11$, which matches $\operatorname{tr}(A)=11$; their product is $40=\det A$.

**What earns the points:**

- [ ] Correct $A-\lambda I$ and cofactor signs.
- [ ] A factored characteristic polynomial.
- [ ] Complete roots with a trace check.

::::

:::
:::problem[Problem 12 — Repeated root with a two-vector eigenspace]{difficulty=standard}

Find a basis for the indicated eigenspace and state its dimension.

$$
A=\begin{bmatrix}2&0&0\\0&2&0\\0&0&5\end{bmatrix}
$$

Given $\lambda=2$.

::::solution[Solution]
**Answer:** Basis for $E_{2}$: $(1,0,0)^T,(0,1,0)^T$; dimension $2$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(2)I=\begin{bmatrix}0&0&0\\0&0&0\\0&0&3\end{bmatrix}
   $$

2. Swap $R_1$ with $R_3$ to put a nonzero pivot first. 
   
   $$
   \begin{bmatrix}0&0&3\\0&0&0\\0&0&0\end{bmatrix}
   $$

3. Divide row 1 by $3$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}0&0&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

4. Pivot columns are 3; free variables are $x_1$, $x_2$. Each free variable supplies one independent eigendirection.

5. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}1\\0\\0\end{bmatrix},\qquad\begin{bmatrix}0\\1\\0\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{2}=2$.

6. Check: $A\mathbf v_1=2\mathbf v_1$, $A\mathbf v_2=2\mathbf v_2$ for the displayed basis columns. They also solve the homogeneous equations.

**What earns the points:**

- [ ] Shifted homogeneous system.
- [ ] Row operations and free variables.
- [ ] A complete basis and its dimension.

::::

:::
:::problem[Problem 13 — Diagonalize and check AP = PD]{difficulty=standard}

Diagonalize $A$ by finding $P,D$ with $A=PDP^{-1}$, or show that it is impossible. Check $AP=PD$.

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Columns of $P$: $(1,0)^T,(1,1)^T$; diagonal of $D$: $2,3$.

1. Find the characteristic roots first: 
   
   $$
   \left(\lambda - 3\right) \left(\lambda - 2\right)=0.
   $$
   
   
   The roots are $2,3$.

2. Solve $\operatorname{Nul}(A-(2)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}1\\0\end{bmatrix}
   $$

3. The shifted system begins with 
   
   $$
   A-(2)I=\begin{bmatrix}0&1\\0&1\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 2. 
   
   $$
   \begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

5. There are 1 free variables. Set them independently to obtain the displayed eigenbasis.

6. Solve $\operatorname{Nul}(A-(3)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}1\\1\end{bmatrix}
   $$

7. The shifted system begins with 
   
   $$
   A-(3)I=\begin{bmatrix}-1&1\\0&0\end{bmatrix}
   $$

8. Divide row 1 by $-1$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

9. There are 1 free variables. Set them independently to obtain the displayed eigenbasis.

10. There are 2 independent eigenvectors. Put them in columns of $P$; put their eigenvalues in the **matching** order on the diagonal of $D$: 
   
   $$
   P=\begin{bmatrix}1&1\\0&1\end{bmatrix},\qquad D=\begin{bmatrix}2&0\\0&3\end{bmatrix}
   $$

11. Check multiplication directly, without wasting time finding $P^{-1}$: 
   
   $$
   AP=\begin{bmatrix}2&3\\0&3\end{bmatrix}=PD=\begin{bmatrix}2&3\\0&3\end{bmatrix}
   $$
   
   
   Since $\det P=1\ne0$, $P$ is invertible and $A=PDP^{-1}$.

**What earns the points:**

- [ ] Eigenvalues and basis columns.
- [ ] Consistent order in $P,D$.
- [ ] The check $AP=PD$ and invertibility of $P$.

::::

:::
:::problem[Problem 14 — Solve a triangular differential system]{difficulty=challenge}

Solve $\mathbf{x}\prime(t)=A\mathbf{x}(t)$ with the specified initial vector. Give the qualitative trajectory type and check the initial condition.

$$
A=\begin{bmatrix}3&1\\0&1\end{bmatrix}
$$

$$
\mathbf{x}(0)=\begin{bmatrix}1\\3\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Solution: $\mathbf{x}(t)=(\frac{5 e^{3 t}}{2} - \frac{3 e^{t}}{2},3 e^{t})^T$; unstable node.

1. The eigenvalues are $1,3$. Solve their homogeneous systems and choose eigenvector columns: 
   
   $$
   P=\begin{bmatrix}-1&1\\2&0\end{bmatrix},\qquad D=\begin{bmatrix}1&0\\0&3\end{bmatrix}
   $$

2. Because each eigenvector satisfies $A\mathbf v_j=\lambda_j\mathbf v_j$, a solution along it has factor $e^{\lambda_jt}$. Add these modes: 
   
   $$
   \mathbf x(t)=c_1e^{1t}\begin{bmatrix}-1\\2\end{bmatrix} + c_2e^{3t}\begin{bmatrix}1\\0\end{bmatrix}
   $$

3. At $t=0$, every exponential equals one, so $P\mathbf c=\mathbf x_0$. Substitute the initial vector and solve the ordinary linear equations; the constants are 
   
   $$
   \mathbf c=\begin{bmatrix}\frac{3}{2}\\\frac{5}{2}\end{bmatrix}
   $$

4. Insert those coefficients into the exponential modes and combine components: 
   
   $$
   \mathbf x(t)=\begin{bmatrix}\frac{5 e^{3 t}}{2} - \frac{3 e^{t}}{2}\\3 e^{t}\end{bmatrix}
   $$
   
   
   The eigenvalue signs identify the trajectory as unstable node.

5. Check: at zero this becomes 
   
   $$
   \mathbf x(0)=\begin{bmatrix}1\\3\end{bmatrix}
   $$
   
   
   which equals the stated starting vector. Differentiating each eigenmode gives $\mathbf x\prime=A\mathbf x$.

**What earns the points:**

- [ ] Eigenmodes and correct exponentials.
- [ ] Initial-condition equations for coefficients.
- [ ] Solution and verification.

::::

:::
:::problem[Problem 15 — Normalize a nonuniform steady state]{difficulty=standard}

Find the normalized steady-state probability vector of the column-stochastic matrix $P$.

$$
P=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Steady state: $(\frac{2}{3},\frac{1}{3})^T$.

1. Check the column convention: every entry is nonnegative, and the columns of $P$ sum to one. Seek a probability vector satisfying $P\mathbf q=\mathbf q$.

2. Move all terms to the same side: 
   
   $$
   (P-I)\mathbf q=\mathbf0,\qquad P-I=\begin{bmatrix}- \frac{1}{4}&\frac{1}{2}\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

3. Divide row 1 by $- \frac{1}{4}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-2\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(\frac{1}{4})R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

5. The null-space equations give a direction 
   
   $$
   \mathbf v=\begin{bmatrix}2\\1\end{bmatrix}
   $$
   
   
   This direction is not yet a probability vector unless its coordinates add to one.

6. Divide the nonnegative direction by the sum of its coordinates. The normalized steady state is 
   
   $$
   \mathbf q=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}
   $$

7. Check: 
   
   $$
   P\mathbf q=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}=\mathbf q,\qquad\sum q_i=1.
   $$
   
   
   All coordinates are nonnegative, which completes the probability requirement.

**What earns the points:**

- [ ] $(P-I)\mathbf q=0$ and null-space algebra.
- [ ] Nonnegative sum-to-one normalization.
- [ ] Direct $P\mathbf q=\mathbf q$ check.

::::

:::
