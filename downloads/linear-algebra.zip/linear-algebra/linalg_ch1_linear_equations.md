---
title: "Linear Equations"
crumb: "Linear Algebra · Chapter 1"
meta:
  - "Est. study time: ~200 min"
  - "MA 3113 · Mississippi State University"
source: "markdown"
---

## Overview

This chapter is the foundation of everything in linear algebra. You will learn how to set
 up and solve systems of linear equations — the single most important computational task
 in the subject — and then discover that virtually every concept we introduce later
 (matrices, vector spaces, eigenvalues) is really just a way of asking the same question in
 a more sophisticated language.

:::callout-key[What you'll learn]
- How to represent and solve systems of equations with augmented matrices and row operations
- What vectors, spans, and linear combinations mean geometrically
- How to write $\mathbf{Ax} = \mathbf{b}$ and connect it back to a linear system
- The difference between homogeneous and nonhomogeneous solution sets
- How to test for linear independence and understand linear transformations
:::

:::callout-tip[Prerequisites]
Basic algebra (solving two equations in two unknowns). No calculus needed for this chapter.
:::

## 1.1 Systems of Linear Equations

:::callout-intuition[Intuition first]
You've solved two equations in two unknowns since middle school: find where two lines cross.
 Linear algebra just scales that idea up. Instead of 2 equations and 2 unknowns, we might have
 1000 equations and 1000 unknowns — and we need a *systematic* method that a computer
 can run automatically. That method is row reduction, and it all starts here.
:::

:::definition[Definition 1.1 — Linear Equation]
A **linear equation** in variables $x_1, x_2, \ldots, x_n$ is any equation
 of the form

$$
a_1 x_1 + a_2 x_2 + \cdots + a_n x_n = b,
$$

 where $b$ and the *coefficients* $a_1, \ldots, a_n$ are real (or complex) numbers.
 A **system of linear equations** (a *linear system*) is a collection of
 one or more such equations sharing the same variables.
:::

The key word is *linear*: no $x_1^2$, no $x_1 x_2$, no $\sin(x_1)$. Every variable
 appears only to the first power and never multiplied by another variable.

A single linear equation in three variables:

$$
3x_1 + 4x_2 - 2x_3 = 5
$$

and a system of two linear equations sharing the same three variables:

$$
\begin{cases}2x_1 + x_2 - x_3 = 5\\ -x_1 + 2x_2 + 3x_3 = 4\end{cases}
$$

Nothing requires the number of equations to match the number of variables. Two equations in
 three unknowns is a perfectly good system — it simply will not pin down a single point, as
 section 1.5 makes precise.

### Solution sets and consistency

A **solution** is a list of numbers $(s_1, s_2, \ldots, s_n)$ that makes every
 equation true simultaneously. The **solution set** is the collection of all such lists.
 A system is **consistent** if it has at least one solution; **inconsistent**
 if it has none.

:::theorem[Theorem 1.1 — Exactly Three Outcomes]
Any linear system has exactly one of three outcomes:

1. **No solution** (inconsistent)
2. **Exactly one solution** (consistent, unique)
3. **Infinitely many solutions** (consistent, dependent)
:::

Geometrically in $\mathbb{R}^2$: two lines either are parallel (no solution), cross at one point
 (unique solution), or are the same line (infinitely many solutions).

### The augmented matrix

Writing out all the variable names repeatedly wastes time. The **augmented matrix**
 strips a system down to just its coefficients and constants:

$$
\begin{cases}
        x_1 - 2x_2 + x_3 = 0 \\
        2x_2 - 8x_3 = 8 \\
        5x_1 - 5x_3 = 10
      \end{cases}
      \quad\longrightarrow\quad
      \left[\begin{array}{rrr|r}
        1 & -2 & 1 & 0 \\
        0 & 2 & -8 & 8 \\
        5 & 0 & -5 & 10
      \end{array}\right]
$$

The vertical bar separates the coefficient matrix on the left from the constants on the right.
 Each row is one equation; each column (left of the bar) is one variable.

Two matrices come out of every system, and the difference between them matters more than it
 looks. Take the system we will use repeatedly from here on — call it $(*)$:

$$
(*)\qquad
\begin{cases}
  x_1 - 2x_2 + x_3 = 0 \\
  \phantom{x_1 -\;} 2x_2 - 8x_3 = 8 \\
  -4x_1 + 5x_2 + 9x_3 = -9
\end{cases}
$$

:::definition[Definition 1.1a — Coefficient and Augmented Matrix]
The **coefficient matrix** holds only the coefficients of the variables; the
 **augmented matrix** appends the constants as one more column:

$$
\underbrace{\begin{bmatrix} 1 & -2 & 1 \\ 0 & 2 & -8 \\ -4 & 5 & 9 \end{bmatrix}}_{\text{coefficient matrix}}
\qquad
\underbrace{\left[\begin{array}{rrr|r} 1 & -2 & 1 & 0 \\ 0 & 2 & -8 & 8 \\ -4 & 5 & 9 & -9 \end{array}\right]}_{\text{augmented matrix}}
$$
:::

Note the $0$ in the second row of the coefficient matrix. The second equation has no $x_1$
 term, and a missing term is a coefficient of zero, not a gap. Writing the system out with a
 variable skipped is the single most common way to build the wrong matrix.

Why keep both? The coefficient matrix is the *transformation* — it is what $A$ will mean in
 $A\mathbf{x} = \mathbf{b}$ later in this chapter. The augmented matrix is the *question you
 are asking of it* for one particular $\mathbf{b}$. Section 1.4 turns on being able to tell
 statements about $A$ apart from statements about $[A \mid \mathbf{b}]$, and students who
 blur the two here lose marks there.

:::definition[Definition 1.1b — Equivalent Systems]
Two linear systems are **equivalent** if they have the same solution set.
:::

That is the entire justification for everything we are about to do. Row reduction is worth
 doing only because each step produces an equivalent system — a different-looking set of
 equations with exactly the same solutions. We are never "changing" the problem, only
 rewriting it into a form that displays its answer.

### Elementary row operations

Three operations transform an augmented matrix without changing the solution set:

1. **Row swap** — interchange two rows: $R_i \leftrightarrow R_j$
2. **Row scaling** — multiply a row by a nonzero constant: $R_i \leftarrow c\,R_i$
3. **Row replacement** — add a multiple of one row to another: $R_i \leftarrow R_i + c\,R_j$

Each one is reversible, which is why no solutions are gained or lost: a swap undoes itself,
 a scaling by $c$ undoes with $1/c$ (this is why $c \neq 0$ is required), and
 $R_i \leftarrow R_i + cR_j$ undoes with $R_i \leftarrow R_i - cR_j$.

:::definition[Definition 1.1c — Row Equivalent Matrices]
Two matrices are **row equivalent** if there is a sequence of elementary row operations
 that transforms one into the other.
:::

:::theorem[Theorem 1.1a — Row Equivalence Preserves Solutions]
If the augmented matrices of two linear systems are row equivalent, then the two systems
 have the same solution set.
:::

This theorem is the bridge between the two definitions above, and it is what licenses the
 whole method: *row equivalent matrices* $\Rightarrow$ *equivalent systems*. Every arrow you
 draw in a row reduction is an appeal to it.

### The two fundamental questions

Almost everything in this chapter is one of two questions about a system, and it is worth
 naming them now because later theorems are organized around answering them:

1. **Existence.** Is the system **consistent** — does at least one solution exist?
2. **Uniqueness.** If a solution exists, is it the only one?

Theorem 1.1 says the answers can only combine in three ways. Section 1.2 will let you read
 both answers straight off a row-reduced matrix, without ever solving for a variable.

### Worked examples

:::example[Example 1.1 — Solving a 2×2 system]
Solve: $\quad 2x_1 + 3x_2 = 7$, $\quad x_1 - x_2 = 1$.


::::answer[Answer]
**Answer:** $x_1 = 2,\quad x_2 = 1$

1. Write the augmented matrix:

$$
\left[\begin{array}{rr|r} 2 & 3 & 7 \\ 1 & -1 & 1 \end{array}\right]
$$

2. $R_1 \leftrightarrow R_2$ (put a leading 1 in the top-left):

$$
\left[\begin{array}{rr|r} 1 & -1 & 1 \\ 2 & 3 & 7 \end{array}\right]
$$

3. $R_2 \leftarrow R_2 - 2R_1$:

$$
\left[\begin{array}{rr|r} 1 & -1 & 1 \\ 0 & 5 & 5 \end{array}\right]
$$

4. $R_2 \leftarrow \tfrac{1}{5}R_2$:

$$
\left[\begin{array}{rr|r} 1 & -1 & 1 \\ 0 & 1 & 1 \end{array}\right]
$$

5. $R_1 \leftarrow R_1 + R_2$:

$$
\left[\begin{array}{rr|r} 1 & 0 & 2 \\ 0 & 1 & 1 \end{array}\right]
$$

6. Reading off: $x_1 = 2$, $x_2 = 1$. Check: $2(2)+3(1)=7\,\checkmark$ and $2-1=1\,\checkmark$.
::::
:::

:::example[Example 1.2 — An inconsistent system]
Show that the system $x_1 + x_2 = 3$, $2x_1 + 2x_2 = 7$ has no solution.


::::answer[Answer]
**Answer:** No solution — the system is inconsistent.

1. Write the relevant equation or row-operation calculation explicitly:

$$
\left[\begin{array}{rr|r}1&1&3\\2&2&7\end{array}\right]
        \xrightarrow{R_2 - 2R_1}
        \left[\begin{array}{rr|r}1&1&3\\0&0&1\end{array}\right]
$$

2. The second row reads $0 = 1$ — a contradiction. No matter what $x_1$ and $x_2$ are,
 this is never true, so the system is inconsistent.
 Geometrically, the two "lines" are parallel (same slope, different intercepts).
::::
:::

:::example[Example 1.3 — All three outcomes, from nearly the same system]
Solve each, and say which of the three outcomes it is:

$$
\text{(a)}\;\begin{cases}2x_1 - x_2 = 1\\ x_1 + x_2 = 2\end{cases}
\qquad
\text{(b)}\;\begin{cases}2x_1 - x_2 = 1\\ -2x_1 + x_2 = 2\end{cases}
\qquad
\text{(c)}\;\begin{cases}2x_1 - x_2 = 1\\ -2x_1 + x_2 = -1\end{cases}
$$


::::answer[Answer]
**Answer:** (a) unique solution $(1,1)$ (b) no solution (c) infinitely many solutions

1. These three differ only in the second equation, and that is the point: the outcome is not a
 property of how hard a system looks, it is a property of how the equations sit relative to
 one another.

2. **(a)** Add the two equations: $3x_1 = 3$, so $x_1 = 1$ and then $x_2 = 1$. The two lines
 have different slopes ($2$ and $-1$), so they cross exactly once.

3. **(b)** Add the two equations: the left side cancels completely and we get $0 = 3$. The
 second equation is the first one negated on the left but *not* on the right — same slope,
 different intercept. Parallel lines, never meeting.

4. **(c)** Add the two equations: $0 = 0$. Here the second equation is exactly $-1$ times the
 first, right side included, so it is the same line written twice. Every point on that line
 solves both. Setting $x_2 = t$ gives $x_1 = \tfrac{1+t}{2}$ for every $t \in \mathbb{R}$.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 160 150" width="160" height="150"
     role="img" aria-label="one solution — two lines in the plane">
<path class="fig-gridline" d="M18.18 138L18.18 12M49.09 138L49.09 12M80 138L80 12M110.91 138L110.91 12M141.82 138L141.82 12M12 133.33L148 133.33M12 110L148 110M12 86.67L148 86.67M12 63.33L148 63.33M12 40L148 40M12 16.67L148 16.67"/>
<path class="fig-axis" d="M12 86.67L148 86.67M49.09 138L49.09 12"/>
<path class="fig-curve" d="M30.55 138L114 12"/>
<path class="fig-curve-alt" d="M12 12L148 114.67"/>
<circle class="fig-point" cx="80" cy="63.33" r="3.4"/>
<text class="fig-label" x="86" y="58.33">(1,1)</text>
<text class="fig-label" x="140" y="82.67">x&#8321;</text>
<text class="fig-label" x="54.09" y="20">x&#8322;</text>
</svg>
<figcaption>(a) one solution</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 160 150" width="160" height="150"
     role="img" aria-label="no solution — two lines in the plane">
<path class="fig-gridline" d="M18.18 138L18.18 12M49.09 138L49.09 12M80 138L80 12M110.91 138L110.91 12M141.82 138L141.82 12M12 133.33L148 133.33M12 110L148 110M12 86.67L148 86.67M12 63.33L148 63.33M12 40L148 40M12 16.67L148 16.67"/>
<path class="fig-axis" d="M12 86.67L148 86.67M49.09 138L49.09 12"/>
<path class="fig-curve" d="M30.55 138L114 12"/>
<path class="fig-curve-alt" d="M12 96L67.64 12"/>
<text class="fig-label" x="140" y="82.67">x&#8321;</text>
<text class="fig-label" x="54.09" y="20">x&#8322;</text>
</svg>
<figcaption>(b) no solution</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 160 150" width="160" height="150"
     role="img" aria-label="infinitely many — two lines in the plane">
<path class="fig-gridline" d="M18.18 138L18.18 12M49.09 138L49.09 12M80 138L80 12M110.91 138L110.91 12M141.82 138L141.82 12M12 133.33L148 133.33M12 110L148 110M12 86.67L148 86.67M12 63.33L148 63.33M12 40L148 40M12 16.67L148 16.67"/>
<path class="fig-axis" d="M12 86.67L148 86.67M49.09 138L49.09 12"/>
<path class="fig-curve" d="M30.55 138L114 12"/>
<path class="fig-guide" d="M30.55 138L114 12"/>
<text class="fig-label" x="140" y="82.67">x&#8321;</text>
<text class="fig-label" x="54.09" y="20">x&#8322;</text>
</svg>
<figcaption>(c) infinitely many</figcaption>
</figure>

</div>

:::::callout-tip[Key takeaway]
Watch what happens to the *right-hand side* when the left sides cancel. Left cancels and
 right does not $\Rightarrow$ contradiction, no solution. Both cancel $\Rightarrow$ a
 redundant equation, infinitely many solutions. That one observation distinguishes (b) from
 (c), and it is the same test you will apply to a bottom row $[0\ \cdots\ 0 \mid c]$ for the
 rest of the chapter.
:::::
::::
:::

:::example[Example 1.4 — Solving the system $(*)$ in full]
Solve the system $(*)$ from the previous page:

$$
\begin{cases}
  x_1 - 2x_2 + x_3 = 0 \\
  2x_2 - 8x_3 = 8 \\
  -4x_1 + 5x_2 + 9x_3 = -9
\end{cases}
$$


::::answer[Answer]
**Answer:** $x_1 = 29,\quad x_2 = 16,\quad x_3 = 3$

1. Start from the augmented matrix. The first column already has its leading $1$, so clear
 below it — only row 3 has an $x_1$ term to remove, and $R_3 \leftarrow R_3 + 4R_1$ does it:

$$
\left[\begin{array}{rrr|r}1&-2&1&0\\0&2&-8&8\\-4&5&9&-9\end{array}\right]
\xrightarrow{R_3 + 4R_1}
\left[\begin{array}{rrr|r}1&-2&1&0\\0&2&-8&8\\0&-3&13&-9\end{array}\right]
$$

2. Row 3 entry by entry: $-4+4(1) = 0$, $\;5+4(-2) = -3$, $\;9+4(1) = 13$, $\;-9+4(0) = -9$.

3. Scale row 2 to get a leading $1$, then clear below it with $R_3 \leftarrow R_3 + 3R_2$:

$$
\xrightarrow{\frac{1}{2}R_2}
\left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&-3&13&-9\end{array}\right]
\xrightarrow{R_3 + 3R_2}
\left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&0&1&3\end{array}\right]
$$

4. That is row echelon form, and it is already enough to finish by back-substitution:
 $x_3 = 3$, then $x_2 - 4(3) = 4$ gives $x_2 = 16$, then $x_1 - 2(16) + 3 = 0$ gives
 $x_1 = 29$.

5. Carrying on to reduced row echelon form instead makes the answer readable with no
 substitution at all. Clear *above* each pivot, working from the bottom up:

$$
\xrightarrow{R_2 + 4R_3,\;R_1 - R_3}
\left[\begin{array}{rrr|r}1&-2&0&-3\\0&1&0&16\\0&0&1&3\end{array}\right]
\xrightarrow{R_1 + 2R_2}
\left[\begin{array}{rrr|r}1&0&0&29\\0&1&0&16\\0&0&1&3\end{array}\right]
$$

6. Check all three original equations, not just the one you solved last —
 $29 - 32 + 3 = 0\,\checkmark$, $\;32 - 24 = 8\,\checkmark$,
 $\;-116 + 80 + 27 = -9\,\checkmark$.

7. This system has no free variables — every column left of the bar carries a pivot — so by
 the two fundamental questions it is consistent *and* unique. Keep this example in view: we
 return to it in 1.2 to read consistency off the matrix without solving, and again in 1.5
 with the right-hand side set to zero.
::::
:::

:::example[Example 1.5 — Deciding consistency without finding the solution]
Determine whether each system is consistent.

$$
\text{1)}\begin{cases}x_1 - 2x_2 + x_3 = 0\\ 2x_2 - 8x_3 = 8\\ -4x_1 + 5x_2 + 9x_3 = -9\end{cases}
\qquad
\text{2)}\begin{cases}x_2 - 4x_3 = 8\\ 2x_1 - 3x_2 + 2x_3 = 1\\ 5x_1 - 8x_2 + 7x_3 = 1\end{cases}
$$


::::answer[Answer]
**Answer:** 1) consistent, with a unique solution 2) inconsistent — no solution

1. **1)** This is the system $(*)$, and Example 1.4 already reduced it to

$$
\left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&0&1&3\end{array}\right]
\;\Longrightarrow\;
\begin{cases}x_1 - 2x_2 + x_3 = 0\\ x_2 - 4x_3 = 4\\ x_3 = 3\end{cases}
$$

2. No row of the form $[0\ 0\ 0 \mid c]$ with $c \neq 0$, so it is **consistent**; and every
 column left of the bar has a pivot, so there are no free variables and the solution is
 **unique**. Both questions answered without computing a single value of $x$.

3. **2)** The first equation has no $x_1$ term, so the top-left entry is $0$ — swap a usable row
 up before eliminating:

$$
\left[\begin{array}{rrr|r}0&1&-4&8\\2&-3&2&1\\5&-8&7&1\end{array}\right]
\xrightarrow{R_1 \leftrightarrow R_2}
\left[\begin{array}{rrr|r}2&-3&2&1\\0&1&-4&8\\5&-8&7&1\end{array}\right]
$$

4. Now clear column 1 with $R_3 \leftarrow R_3 - \tfrac52 R_1$, then column 2 with
 $R_3 \leftarrow R_3 + \tfrac12 R_2$:

$$
\longrightarrow
\left[\begin{array}{rrr|r}2&-3&2&1\\0&1&-4&8\\0&-\frac12&2&-\frac32\end{array}\right]
\longrightarrow
\left[\begin{array}{rrr|r}2&-3&2&1\\0&1&-4&8\\0&0&0&\frac52\end{array}\right]
$$

5. The bottom row reads $0x_1 + 0x_2 + 0x_3 = \tfrac52$, that is $0 = \tfrac52$. **No solution.**

:::::callout-tip[Key takeaway]
Consistency is a question about the *shape* of the reduced matrix, not about the values of
 the variables. You can answer it — and answer uniqueness with it — the moment you reach
 echelon form, long before back-substituting. When a question only asks "is it consistent?",
 solving the system is wasted work.
:::::
::::
:::

:::callout-pitfall[Watch out for]
- **Sign errors in row replacement.** When you compute $R_2 \leftarrow R_2 - 2R_1$,
 subtract every entry — including the right-hand side.
- **Dividing by zero.** Row scaling requires a *nonzero* constant. If a
 leading entry is 0, swap that row with one below it first.
- **Confusing "no solution" and "infinitely many."** A row $[0\ 0\ |\ 0]$
 means a dependent equation (one fewer constraint). A row $[0\ 0\ |\ c]$ with $c\neq 0$
 means contradiction (no solution).
:::

### Practice problems

:::problem[Problem 1.1 — Build an augmented matrix]{difficulty=easy}
Write the augmented matrix for the system $\;3x - y = 5$, $\;x + 2y = 4$.


::::solution[Solution]
**Answer:** $\left[\begin{array}{rr|r}3&-1&5\\1&2&4\end{array}\right]$

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. $\left[\begin{array}{rr|r}3&-1&5\\1&2&4\end{array}\right]$

3. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.
::::
:::

:::problem[Problem 1.2 — Test linearity]{difficulty=easy}
Is the equation $x_1^2 + x_2 = 3$ linear? Is $2x_1 - 5x_2 + x_3 = 0$ linear? Explain.


::::solution[Solution]
**Answer:** $x_1^2+x_2=3$ is not linear; $2x_1-5x_2+x_3=0$ is linear.

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. $x_1^2 + x_2 = 3$ is **not linear** — the term $x_1^2$ is degree 2.

3. $2x_1 - 5x_2 + x_3 = 0$ **is linear** — every variable appears exactly once, to the first power.
::::
:::

:::problem[Problem 1.3 — Build an augmented matrix]{difficulty=standard}
Use row operations to solve:

$$
\begin{cases}x_1 + 2x_2 - x_3 = 4\\2x_1 + 3x_2 + x_3 = 5\\-x_1 + x_2 + 2x_3 = 1\end{cases}
$$


::::solution[Solution]
**Answer:** $x_1=-9,\quad x_2=\tfrac{36}{5},\quad x_3=\tfrac{7}{5}$.

1. Start with the augmented matrix and eliminate:

$$
\left[\begin{array}{rrr|r}1&2&-1&4\\2&3&1&5\\-1&1&2&1\end{array}\right]
          \xrightarrow{R_2-2R_1,\;R_3+R_1}
          \left[\begin{array}{rrr|r}1&2&-1&4\\0&-1&3&-3\\0&3&1&5\end{array}\right]
$$

2. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{-R_2,\;R_3+3R_2}
          \left[\begin{array}{rrr|r}1&2&-1&4\\0&1&-3&3\\0&0&10&14\end{array}\right]
          \xrightarrow{\frac{1}{10}R_3}
          \left[\begin{array}{rrr|r}1&2&-1&4\\0&1&-3&3\\0&0&1&\frac{7}{5}\end{array}\right]
$$

3. Back-substitute: $x_3 = \tfrac{7}{5}$, then $x_2 = 3 + 3\cdot\tfrac{7}{5} = \tfrac{36}{5}$, then
 $x_1 = 4 - 2\cdot\tfrac{36}{5} + \tfrac{7}{5} = 4 - \tfrac{65}{5} = 4 - 13 = -9$.

4. So $x_1 = -9,\; x_2 = \tfrac{36}{5},\; x_3 = \tfrac{7}{5}$.
::::
:::

:::problem[Problem 1.4 — Test consistency]{difficulty=standard}
Determine whether the following system is consistent, and if so, whether the solution is unique or there are infinitely many:
 $x_1 - 3x_2 = 2$, $-2x_1 + 6x_2 = -4$.


::::solution[Solution]
**Answer:** Consistent with infinitely many solutions: $x_1=2+3t,\ x_2=t$, $t\in\mathbb R$.

1. Write the relevant equation or row-operation calculation explicitly:

$$
\left[\begin{array}{rr|r}1&-3&2\\-2&6&-4\end{array}\right]
          \xrightarrow{R_2+2R_1}
          \left[\begin{array}{rr|r}1&-3&2\\0&0&0\end{array}\right]
$$

2. The second row is all zeros — not a contradiction. The system is **consistent with infinitely many solutions**.
 Setting $x_2 = t$ (free variable), we get $x_1 = 2 + 3t$ for any $t \in \mathbb{R}$.
 Geometrically, both equations describe the *same* line.
::::
:::

:::problem[Problem 1.5 — Test consistency]{difficulty=challenge}
For what value(s) of $h$ is the system consistent?
 $x_1 + hx_2 = 3$, $2x_1 + 4x_2 = 6$.


::::solution[Solution]
**Answer:** Consistent for every $h$. If $h=2$, infinitely many solutions; otherwise the unique solution $(x_1,x_2)=(3,0)$.

1. Write the relevant equation or row-operation calculation explicitly:

$$
\left[\begin{array}{rr|r}1&h&3\\2&4&6\end{array}\right]
          \xrightarrow{R_2-2R_1}
          \left[\begin{array}{rr|r}1&h&3\\0&4-2h&0\end{array}\right]
$$

2. The second row reads $(4-2h)x_2 = 0$. This is consistent for *all* values of $h$
 (the right side is 0, never a contradiction). If $h = 2$, then $x_2$ is free and there are
 infinitely many solutions. If $h \neq 2$, the unique solution is $x_2 = 0$, $x_1 = 3$.
::::
:::

## 1.2 Row Reduction and Echelon Forms

:::callout-intuition[Intuition first]
Row operations let you simplify any augmented matrix. But "simplified" needs a precise target.
 *Row echelon form* is that target — a staircase pattern that makes back-substitution trivial.
 *Reduced row echelon form* goes one step further and makes the answer readable directly
 from the matrix, no substitution required.
:::

### Matrix vocabulary

Before defining the target we need names for the parts.

:::definition[Definition 1.2a — Matrix, Size, Entries]
A matrix with $m$ rows and $n$ columns is an **$m \times n$ matrix** (rows first, always):

$$
A = \begin{bmatrix}
a_{11} & a_{12} & \cdots & a_{1n} \\
a_{21} & a_{22} & \cdots & a_{2n} \\
\vdots & \vdots & \ddots & \vdots \\
a_{m1} & a_{m2} & \cdots & a_{mn}
\end{bmatrix}
$$

The numbers $a_{ij}$ are the **entries**. In $a_{ij}$ the **first subscript $i$ is the row**
 and the **second subscript $j$ is the column**.

- If $m = n$ the matrix is **square**, and $a_{11}, a_{22}, \ldots, a_{nn}$ are its
  **main diagonal entries**.
- The **leading entry** of a row is its leftmost nonzero entry. A row of all zeros has none.
:::

Two conventions here cause more errors than anything else in the chapter, and both are pure
 memorization with no reasoning to fall back on:

- **Size is rows $\times$ columns.** A $2 \times 3$ matrix is short and wide, not tall and
  narrow.
- **Subscripts are row-then-column.** $a_{23}$ is row 2, column 3.

:::example[Example 1.6 — Naming matrices by size]
$$
[-3] \qquad
\begin{bmatrix}0&1\\2&-1\end{bmatrix} \qquad
\begin{bmatrix}3\\-1\\0\end{bmatrix} \qquad
\begin{bmatrix}2&3&4\\0&-3&2\end{bmatrix}
$$


::::answer[Answer]
**Answer:** $1\times1$ (square) $\;\cdot\;$ $2\times2$ (square) $\;\cdot\;$ $3\times1$ $\;\cdot\;$ $2\times3$

1. The third is $3 \times 1$: three rows, one column. A matrix with a single column is a
 **vector**, which is the whole subject of 1.3 — so vectors are not a new kind of object,
 just a matrix of a particular shape.

2. In the fourth, $a_{23} = 2$ (row 2, column 3) while $a_{32}$ does not exist — there is no
 row 3. Neither of the last two is square, so neither has a main diagonal.
::::
:::

:::definition[Definition 1.2 — Row Echelon Form (REF)]
A matrix is in **row echelon form** if:

1. All zero rows are at the bottom.
2. Each row's leading entry (the first nonzero entry) is to the *right* of the leading entry of every row above it.
3. All entries below a leading entry are zero.

A **pivot position** is the location of a leading entry in a REF of the matrix.
 A **pivot column** is a column containing a pivot position.
:::

:::definition[Definition 1.3 — Reduced Row Echelon Form (RREF)]
A matrix is in **reduced row echelon form** if it satisfies REF *and*:

1. Every leading entry is **1** (a pivot of 1).
2. Each leading 1 is the *only* nonzero entry in its column.
:::

:::theorem[Theorem 1.2a — Uniqueness of the Reduced Echelon Form]
Each matrix is row equivalent to **one and only one** reduced echelon matrix.
:::

This asymmetry is easy to miss and worth stating plainly: a matrix has **many** row echelon
 forms but exactly **one** reduced row echelon form. Two students reducing the same matrix
 can legitimately reach different REFs — different choices of scaling or of which row to
 swap up — and both be right. If they carry on to RREF, they must agree entry for entry. If
 they do not, one of them has made an arithmetic error.

That uniqueness is also what makes the next definition well posed. Since the RREF is
 determined by the matrix alone, so is the *location* of its leading $1$s — which means we
 can talk about the pivot positions of the original matrix, before doing any work.

:::example[Example 1.7 — Which form is this in?]
Classify each matrix: row echelon form, reduced row echelon form, or neither.

$$
\text{(a)}\begin{bmatrix}1&-1&2&3\\0&1&0&2\\0&0&1&-2\end{bmatrix}
\quad
\text{(b)}\begin{bmatrix}0&1&0&3\\0&0&1&1\\0&0&0&0\end{bmatrix}
\quad
\text{(c)}\begin{bmatrix}1&0&0&-2\\0&1&0&1\\0&0&1&3\end{bmatrix}
$$

$$
\text{(d)}\begin{bmatrix}1&-2&3&4\\0&3&-1&1\\0&1&0&-2\end{bmatrix}
\qquad
\text{(e)}\begin{bmatrix}1&-2&3&-4\\0&0&0&0\\0&1&2&3\end{bmatrix}
$$


::::answer[Answer]
**Answer:** (a) REF only (b) RREF (c) RREF (d) neither (e) neither

1. **(a) REF but not RREF.** The staircase is right and the leading entries are all $1$, so
 conditions 1–4 hold. Condition 5 fails: column 2 has the leading $1$ of row 2, but it also
 has $-1$ sitting above it in row 1. A leading $1$ must be *alone* in its column.

2. **(b) RREF.** Leading $1$s in columns 2 and 3, each alone in its column, zero row at the
 bottom. Column 1 being entirely zero is not a defect — it just means $x_1$ is a free
 variable. Nothing requires a pivot in the first column.

3. **(c) RREF.** The identity matrix with an extra column. This is the form you are aiming for
 whenever a system has a unique solution.

4. **(d) Neither.** Row 2's leading entry is in column 2, and row 3's is *also* in column 2.
 Condition 2 demands each leading entry sit strictly to the right of the one above. The
 staircase does not descend, so this is not even REF — and RREF is out of the question,
 since RREF requires REF first.

5. **(e) Neither.** A zero row appears above a nonzero row, violating condition 1. Note this
 matrix is only a row swap away from being fine, which is exactly the point: REF is a
 statement about the arrangement you have, not about the arrangement you could reach.

:::::callout-tip[Key takeaway]
Check the conditions in order and stop at the first failure. Conditions 1–3 are about
 *shape* (where the zeros are); conditions 4–5 are about *values* (leading entries equal to
 $1$, alone in their columns). If shape fails, you never get to values.
:::::
::::
:::

:::example[Example 1.8 — Locating pivot positions and pivot columns]
Find the pivot positions and pivot columns of

$$
A = \begin{bmatrix}0&-3&-6&4&9\\-1&-2&-1&3&1\\-2&-3&0&3&-1\\1&4&5&-9&-7\end{bmatrix}
$$


::::answer[Answer]
**Answer:** Pivot columns are **1, 2, and 4**.

1. The pivot positions are defined by the RREF, so reduce. The top-left entry is $0$, so swap a
 nonzero row up — $R_1 \leftrightarrow R_4$ — then clear column 1 with
 $R_2 \leftarrow R_2 + R_1$ and $R_3 \leftarrow R_3 + 2R_1$:

$$
\xrightarrow{\;R_1 \leftrightarrow R_4\;}
\begin{bmatrix}1&4&5&-9&-7\\-1&-2&-1&3&1\\-2&-3&0&3&-1\\0&-3&-6&4&9\end{bmatrix}
\longrightarrow
\begin{bmatrix}1&4&5&-9&-7\\0&2&4&-6&-6\\0&5&10&-15&-15\\0&-3&-6&4&9\end{bmatrix}
$$

2. Now clear column 2 below the pivot: $R_3 \leftarrow R_3 - \tfrac{5}{2}R_2$ wipes row 3 out
 entirely, and $R_4 \leftarrow R_4 + \tfrac{3}{2}R_2$ leaves only a $-5$ in column 4:

$$
\longrightarrow
\begin{bmatrix}1&4&5&-9&-7\\0&2&4&-6&-6\\0&0&0&-5&0\\0&0&0&0&0\end{bmatrix}
\xrightarrow{\frac12 R_2,\;-\frac15 R_3}
\begin{bmatrix}1&4&5&-9&-7\\0&1&2&-3&-3\\0&0&0&1&0\\0&0&0&0&0\end{bmatrix}
$$

3. Leading entries now sit in **columns 1, 2 and 4**. Those are the pivot columns; the pivot
 positions are $(1,1)$, $(2,2)$ and $(3,4)$.

4. The subtlety worth pausing on: pivot positions are positions **in $A$**, not in the reduced
 matrix. Position $(1,1)$ of the original $A$ is a pivot position even though $a_{11} = 0$.
 The definition asks where the leading $1$s *end up*, and reading that back onto $A$ is what
 lets us say "column 3 of $A$ is not a pivot column" — a fact about $A$ itself that will
 mean "$x_3$ is a free variable" once there is a system attached.
::::
:::

### The row reduction algorithm

Two phases: *forward elimination* creates REF; *back substitution* (or upward elimination) creates RREF.

1. Find the leftmost nonzero column. That is a pivot column.
2. Move a nonzero entry to the top of that column via a row swap if needed.
3. Use row replacements to create zeros in all entries *below* the pivot.
4. Repeat steps 1–3 on the submatrix below the current pivot row.
5. *(For RREF)* Work from bottom to top: scale each pivot row so the pivot is 1, then eliminate everything *above* each pivot.

### The two methods have names

Where you stop determines which method you are using, and both names appear on exams.

:::definition[Definition 1.3a — Gaussian Elimination with Back-Substitution]
1. Write the augmented matrix.
2. Use elementary row operations to bring it to **row echelon form**.
3. Write the system corresponding to that matrix, and use **back-substitution** to find the
   solution.
:::

:::definition[Definition 1.3b — Gauss–Jordan Elimination]
Carry the reduction all the way to **reduced row echelon form**. The solution is then read
 directly off the matrix; there is no back-substitution step.
:::

So they are the same forward elimination, differing only in the endgame. Gaussian stops at
 the staircase and finishes with algebra; Gauss–Jordan keeps doing row operations until the
 algebra is unnecessary.

Which to use? By hand, Gaussian elimination is usually faster for a system with a unique
 solution — back-substituting three variables is quicker than clearing three columns
 upward. Gauss–Jordan is worth the extra work when there are free variables, because the
 parametric solution falls out of RREF almost for free, and it is what you want whenever the
 question asks for a *description* of the solution set rather than a single answer. Read the
 question: if it says "in reduced echelon form", Gaussian elimination alone will not answer
 it.

### Free variables and the general solution

Variables corresponding to pivot columns are **basic variables**; the rest are
 **free variables**. Free variables can be any real number — you assign them
 parameters (usually $t$, $s$, etc.) and express the basic variables in terms of them.
 This gives the **general solution** (parametric form).

:::theorem[Theorem 1.2 — Existence and Uniqueness from RREF]
After row-reducing the augmented matrix $[A \mid \mathbf{b}]$:

- The system is **inconsistent** iff there is a pivot in the last (augmented) column, i.e., a row $[0\ \cdots\ 0 \mid c]$ with $c \neq 0$.
- If consistent: the solution is **unique** iff every variable is basic (no free variables); otherwise there are **infinitely many** solutions.
:::

### Worked examples

:::example[Example 1.9 — Row-reduce to RREF and solve]
Solve the system:

$$
\begin{cases} x_1 - 2x_2 + x_3 = 0 \\ 2x_2 - 8x_3 = 8 \\ 5x_1 - 5x_3 = 10 \end{cases}
$$


::::answer[Answer]
**Answer:** $x_1 = 1,\quad x_2 = 0,\quad x_3 = -1$

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. Augmented matrix, then row reduce:

$$
\left[\begin{array}{rrr|r}1&-2&1&0\\0&2&-8&8\\5&0&-5&10\end{array}\right]
      \xrightarrow{R_3-5R_1}
      \left[\begin{array}{rrr|r}1&-2&1&0\\0&2&-8&8\\0&10&-10&10\end{array}\right]
$$

3. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{\frac{1}{2}R_2}
      \left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&10&-10&10\end{array}\right]
      \xrightarrow{R_3-10R_2}
      \left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&0&30&-30\end{array}\right]
$$

4. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{\frac{1}{30}R_3}
      \left[\begin{array}{rrr|r}1&-2&1&0\\0&1&-4&4\\0&0&1&-1\end{array}\right]
$$

5. Now back-substitute for RREF. $R_2 \leftarrow R_2 + 4R_3$:

$$
\left[\begin{array}{rrr|r}1&-2&1&0\\0&1&0&0\\0&0&1&-1\end{array}\right]
      \xrightarrow{R_1 - R_3,\; R_1 + 2R_2}
      \left[\begin{array}{rrr|r}1&0&0&1\\0&1&0&0\\0&0&1&-1\end{array}\right]
$$

6. Read off: $x_1 = 1$, $x_2 = 0$, $x_3 = -1$.
::::
:::

:::example[Example 1.10 — System with a free variable]
Find the general solution of

$$
\left[\begin{array}{rrrr|r}1&3&0&-2&0\\0&0&1&4&0\\0&0&0&0&0\end{array}\right]
$$


::::answer[Answer]
**Answer:** $x_1 = -3s + 2t,\quad x_2 = s,\quad x_3 = -4t,\quad x_4 = t\quad$ for any $s, t \in \mathbb{R}$.

1. Pivot columns are 1 and 3, so **basic variables** are $x_1, x_3$;
 **free variables** are $x_2 = s$ and $x_4 = t$.

2. Row 1: $x_1 + 3x_2 - 2x_4 = 0 \;\Rightarrow\; x_1 = -3x_2 + 2x_4 = -3s + 2t$.

3. Row 2: $x_3 + 4x_4 = 0 \;\Rightarrow\; x_3 = -4x_4 = -4t$.

4. Row 3: $0 = 0$ — no information, consistent. The solution set is a plane in $\mathbb{R}^4$.
::::
:::

:::example[Example 1.11 — Gaussian elimination with back-substitution]
Find the solutions of

$$
\text{(a)}\begin{cases}2x_1 + 3x_2 + x_3 = 10\\ 2x_1 - 3x_2 - 3x_3 = 22\\ 4x_1 - 2x_2 + 3x_3 = -2\end{cases}
\qquad
\text{(b)}\begin{cases}x_1 + 2x_2 + 6x_3 = 1\\ 2x_1 + 5x_2 + 15x_3 = 4\\ 3x_1 + x_2 + 3x_3 = -6\end{cases}
$$


::::answer[Answer]
**Answer:** (a) $x_1 = 5,\; x_2 = 2,\; x_3 = -6$ (b) no solution

1. **(a)** Note the leading entry is $2$, not $1$. There is no need to scale it — Gaussian
 elimination only needs the *staircase*, and dividing row 1 by $2$ would introduce fractions
 into every later step for no benefit. Clear column 1 with $R_2 - R_1$ and $R_3 - 2R_1$:

$$
\left[\begin{array}{rrr|r}2&3&1&10\\2&-3&-3&22\\4&-2&3&-2\end{array}\right]
\longrightarrow
\left[\begin{array}{rrr|r}2&3&1&10\\0&-6&-4&12\\0&-8&1&-22\end{array}\right]
\xrightarrow{-\frac12 R_2}
\left[\begin{array}{rrr|r}2&3&1&10\\0&3&2&-6\\0&-8&1&-22\end{array}\right]
$$

2. Clear below the second pivot with $R_3 \leftarrow R_3 + \tfrac{8}{3}R_2$. The entries:
 $1 + \tfrac83(2) = \tfrac{19}{3}$ and $-22 + \tfrac83(-6) = -38$:

$$
\longrightarrow
\left[\begin{array}{rrr|r}2&3&1&10\\0&3&2&-6\\0&0&\frac{19}{3}&-38\end{array}\right]
\;\Longrightarrow\;
\begin{cases}2x_1 + 3x_2 + x_3 = 10\\ 3x_2 + 2x_3 = -6\\ \tfrac{19}{3}x_3 = -38\end{cases}
$$

3. Back-substitute upward: $x_3 = -38 \cdot \tfrac{3}{19} = -6$; then $3x_2 + 2(-6) = -6$ gives
 $x_2 = 2$; then $2x_1 + 3(2) + (-6) = 10$ gives $x_1 = 5$.

4. (You may see the last constant written $-\tfrac{114}{3}$ rather than $-38$ — same number,
 left unreduced so the division by $\tfrac{19}{3}$ is easier to see.)

5. **(b)** Here the leading entry is already $1$, so clear column 1 with $R_2 - 2R_1$ and
 $R_3 - 3R_1$, then column 2 with $R_3 + 5R_2$:

$$
\left[\begin{array}{rrr|r}1&2&6&1\\2&5&15&4\\3&1&3&-6\end{array}\right]
\longrightarrow
\left[\begin{array}{rrr|r}1&2&6&1\\0&1&3&2\\0&-5&-15&-9\end{array}\right]
\xrightarrow{R_3 + 5R_2}
\left[\begin{array}{rrr|r}1&2&6&1\\0&1&3&2\\0&0&0&1\end{array}\right]
$$

6. The last row reads $0x_1 + 0x_2 + 0x_3 = 1$, that is $0 = 1$. **No solution.** Stop here —
 there is nothing to back-substitute into, and continuing to RREF would only produce a
 tidier contradiction.
::::
:::

:::example[Example 1.12 — Gauss–Jordan elimination]
Find the solutions of

$$
\text{(a)}\begin{cases}-x_1 + x_2 + 2x_3 = 1\\ 2x_1 + 3x_2 + x_3 = -2\\ 5x_1 + 4x_2 + 2x_3 = 4\end{cases}
\qquad
\text{(b)}\begin{cases}2x_1 + 4x_2 - 2x_3 = 0\\ 3x_1 + 5x_2 \phantom{{}- 2x_3} = 1\end{cases}
$$


::::answer[Answer]
**Answer:** (a) $x_1 = 2,\; x_2 = -3,\; x_3 = 3$ (b) $x_1 = 2 - 5t,\; x_2 = -1 + 3t,\; x_3 = t$ for any $t \in \mathbb{R}$

1. (a) $x_1 = 2,\; x_2 = -3,\; x_3 = 3$
 (b) $x_1 = 2 - 5t,\; x_2 = -1 + 3t,\; x_3 = t$ for any $t \in \mathbb{R}$

2. **(a)** Clear column 1 using the $-1$ in place ($R_2 + 2R_1$, $R_3 + 5R_1$), then tidy the
 rows by scaling:

$$
\left[\begin{array}{rrr|r}-1&1&2&1\\2&3&1&-2\\5&4&2&4\end{array}\right]
\longrightarrow
\left[\begin{array}{rrr|r}-1&1&2&1\\0&5&5&0\\0&9&12&9\end{array}\right]
\xrightarrow{-R_1,\;\frac15R_2,\;\frac13R_3}
\left[\begin{array}{rrr|r}1&-1&-2&-1\\0&1&1&0\\0&3&4&3\end{array}\right]
$$

3. Forward elimination finishes with $R_3 - 3R_2$. Then the Gauss–Jordan part: clear *upward*,
 bottom row first.

$$
\xrightarrow{R_3 - 3R_2}
\left[\begin{array}{rrr|r}1&-1&-2&-1\\0&1&1&0\\0&0&1&3\end{array}\right]
\xrightarrow{R_2 - R_3,\;R_1 + 2R_3}
\left[\begin{array}{rrr|r}1&-1&0&5\\0&1&0&-3\\0&0&1&3\end{array}\right]
\xrightarrow{R_1 + R_2}
\left[\begin{array}{rrr|r}1&0&0&2\\0&1&0&-3\\0&0&1&3\end{array}\right]
$$

4. Read it off: $x_1 = 2$, $x_2 = -3$, $x_3 = 3$. No substitution was needed — that is what the
 extra upward work bought.

5. **(b)** Two equations, three unknowns. Before touching it, notice there are at most two
 pivots and three columns, so at least one variable *must* be free — infinitely many
 solutions are guaranteed if it is consistent at all.

$$
\left[\begin{array}{rrr|r}2&4&-2&0\\3&5&0&1\end{array}\right]
\xrightarrow{\frac12 R_1}
\left[\begin{array}{rrr|r}1&2&-1&0\\3&5&0&1\end{array}\right]
\xrightarrow{R_2 - 3R_1}
\left[\begin{array}{rrr|r}1&2&-1&0\\0&-1&3&1\end{array}\right]
$$

6. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{-R_2,\;R_1 - 2R_2}
\left[\begin{array}{rrr|r}1&0&5&2\\0&1&-3&-1\end{array}\right]
\;\Longrightarrow\;
\begin{cases}x_1 \phantom{{}+ x_2} + 5x_3 = 2\\ \phantom{x_1 + {}} x_2 - 3x_3 = -1\end{cases}
$$

7. Columns 1 and 2 carry pivots, so $x_1$ and $x_2$ are basic and $x_3$ is free. Set
 $x_3 = t$ and solve each basic variable in terms of it:

$$
x_1 = 2 - 5t, \qquad x_2 = -1 + 3t, \qquad x_3 = t, \qquad t \in \mathbb{R}
$$

8. This is the **parametric representation** of the solution set. Each value of $t$ gives one
 solution; check $t=0$ against both original equations: $(2,-1,0)$ gives
 $2(2)+4(-1)-2(0) = 0\,\checkmark$ and $3(2)+5(-1) = 1\,\checkmark$. In 1.5 we rewrite this
 same answer as a vector equation, which is where its geometry becomes visible.
::::
:::

:::callout-pitfall[Watch out for]
- **Stopping at REF when RREF is needed.** REF still requires back-substitution.
 RREF lets you read off the answer directly. Know which one is being asked for.
- **Misidentifying pivot columns.** Look at the staircase in REF — each "step"
 marks a pivot column. Columns without a pivot are free-variable columns.
- **Forgetting the right-hand side in row operations.** The augmented column
 transforms too — it's part of the matrix.
:::

### Practice problems

:::problem[Problem 1.6 — Recognize echelon form]{difficulty=easy}
Is the following matrix in REF? In RREF?

$$
\begin{bmatrix}1&2&0\\0&1&3\\0&0&1\end{bmatrix}
$$


::::solution[Solution]
**Answer:** REF: yes; RREF: no.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. **REF: Yes** — each leading entry is to the right of those above it, zeros below.
 **RREF: No** — the leading 1 in row 3 has a nonzero entry above it in row 2 (entry $3$).
 To reach RREF we'd need $R_2 \leftarrow R_2 - 3R_3$ and then $R_1 \leftarrow R_1 - 0\cdot R_3$ (already zero there).
::::
:::

:::problem[Problem 1.7 — Row reduction and solution]{difficulty=standard}
Row-reduce to RREF and find the general solution:

$$
\begin{cases}2x_1 + 4x_2 - 2x_3 = 0 \\ x_1 + 2x_2 + x_3 = 3 \\ -x_1 - 2x_2 + 3x_3 = 3\end{cases}
$$


::::solution[Solution]
**Answer:** $x_1=\tfrac32-2t,\ x_2=t,\ x_3=\tfrac32$ for any real $t$.

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

$$
\left[\begin{array}{rrr|r}2&4&-2&0\\1&2&1&3\\-1&-2&3&3\end{array}\right]
          \xrightarrow{R_1\leftrightarrow R_2}
          \left[\begin{array}{rrr|r}1&2&1&3\\2&4&-2&0\\-1&-2&3&3\end{array}\right]
$$

2. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{R_2-2R_1,\;R_3+R_1}
          \left[\begin{array}{rrr|r}1&2&1&3\\0&0&-4&-6\\0&0&4&6\end{array}\right]
          \xrightarrow{R_3+R_2}
          \left[\begin{array}{rrr|r}1&2&1&3\\0&0&-4&-6\\0&0&0&0\end{array}\right]
$$

3. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{-\frac{1}{4}R_2}
          \left[\begin{array}{rrr|r}1&2&1&3\\0&0&1&\frac{3}{2}\\0&0&0&0\end{array}\right]
          \xrightarrow{R_1-R_2}
          \left[\begin{array}{rrr|r}1&2&0&\frac{3}{2}\\0&0&1&\frac{3}{2}\\0&0&0&0\end{array}\right]
$$

4. Pivot columns: 1 and 3. Free variable: $x_2 = t$.

5. $x_3 = \tfrac{3}{2}$, $\;x_1 = \tfrac{3}{2} - 2t$.
::::
:::

:::problem[Problem 1.8 — Determine the solution set]{difficulty=challenge}
For what value of $k$ does the system have (a) no solution, (b) a unique solution, (c) infinitely many solutions?

$$
\begin{cases}x + y = 2 \\ x + ky = k^2 - 3\end{cases}
$$


::::solution[Solution]
**Answer:** No solution for $k=1$; unique solution for $k\neq1$; infinitely many: never.

1. Write the relevant equation or row-operation calculation explicitly:

$$
\left[\begin{array}{rr|r}1&1&2\\1&k&k^2-3\end{array}\right]
          \xrightarrow{R_2-R_1}
          \left[\begin{array}{rr|r}1&1&2\\0&k-1&k^2-5\end{array}\right]
$$

2. If $k \neq 1$: unique solution (both variables basic). $y = \tfrac{k^2-5}{k-1} = \tfrac{(k-\sqrt5)(k+\sqrt5)}{k-1}$, $x = 2-y$.

3. If $k = 1$: row 2 becomes $[0\ 0\ |\ 1^2-5] = [0\ 0\ |-4]$. Since $-4 \neq 0$: **(a) no solution**.

4. Summary: (b) unique solution for all $k \neq 1$; (a) no solution for $k = 1$; (c) never (right-hand side can't equal 0 when $k=1$).
::::
:::

## 1.3 Vector Equations

:::callout-intuition[Intuition first]
Instead of listing individual equations, we can think of the columns of a matrix as
 *vectors* and ask: can we combine those vectors with some set of weights to
 produce a target vector $\mathbf{b}$? This reframing — from "solve the system" to
 "write $\mathbf{b}$ as a linear combination of columns" — turns out to be the same
 question, just from a geometric angle. It lets us visualize high-dimensional problems.
:::

:::definition[Definition 1.4 — Vectors in $\mathbb{R}^n$]
A **vector** in $\mathbb{R}^n$ is an ordered list of $n$ real numbers, written
 as a column: $\mathbf{v} = \begin{pmatrix}v_1\\v_2\\\vdots\\v_n\end{pmatrix}$.
 Two vectors are equal iff every corresponding component is equal.
 **Addition** and **scalar multiplication** are done componentwise:

$$
\mathbf{u} + \mathbf{v} = \begin{pmatrix}u_1+v_1\\\vdots\\u_n+v_n\end{pmatrix},
        \qquad
        c\mathbf{v} = \begin{pmatrix}cv_1\\\vdots\\cv_n\end{pmatrix}.
$$
:::

:::callout-warning[A column is not a row]
For convenience a vector is often written along the line as $(u_1, u_2)$ — with
 **parentheses and commas**. That is shorthand for the column. But

$$
\begin{pmatrix}u_1\\u_2\end{pmatrix} \;\neq\; \begin{bmatrix}u_1 & u_2\end{bmatrix}
$$

A $2 \times 1$ column and a $1 \times 2$ row are different matrices of different sizes, and
 the difference is not pedantry: in 1.4 you will multiply $A\mathbf{x}$, and whether
 $\mathbf{x}$ is a column or a row decides whether that product is even defined.
:::

Some vectors, one from each of $\mathbb{R}^2$, $\mathbb{R}^3$ and $\mathbb{R}^4$:

$$
\begin{pmatrix}1\\-2\end{pmatrix} \in \mathbb{R}^2,
\qquad
\begin{pmatrix}3\\4\\1\end{pmatrix} \in \mathbb{R}^3,
\qquad
\begin{pmatrix}2\\-1\\5\\3\end{pmatrix} \in \mathbb{R}^4
$$

$\mathbb{R}^4$ has no picture, and that is the point of doing this algebraically: the rules
 below never mention dimension, so they keep working where intuition stops.

:::example[Example 1.13 — Arithmetic in $\mathbb{R}^2$ and $\mathbb{R}^3$]
Let $\mathbf{u} = \begin{pmatrix}2\\-1\end{pmatrix}$ and
 $\mathbf{v} = \begin{pmatrix}1\\3\end{pmatrix}$. Compute $2\mathbf{u}$, $-3\mathbf{v}$ and
 $2\mathbf{u} - 3\mathbf{v}$. Then compute
 $(-2)\begin{pmatrix}3\\-1\\2\end{pmatrix}$ and
 $\begin{pmatrix}1\\2\\-1\end{pmatrix} - 2\begin{pmatrix}3\\-1\\2\end{pmatrix}$.


::::answer[Answer]
**Answer:** $2\mathbf{u} = \begin{pmatrix}4\\-2\end{pmatrix}$, $\;-3\mathbf{v} = \begin{pmatrix}-3\\-9\end{pmatrix}$, $\;2\mathbf{u}-3\mathbf{v} = \begin{pmatrix}1\\-11\end{pmatrix}$; $\;\begin{pmatrix}-6\\2\\-4\end{pmatrix}$; $\;\begin{pmatrix}-5\\4\\-5\end{pmatrix}$

1. $2\mathbf{u} = \begin{pmatrix}4\\-2\end{pmatrix}$,
 $\;-3\mathbf{v} = \begin{pmatrix}-3\\-9\end{pmatrix}$,
 $\;2\mathbf{u}-3\mathbf{v} = \begin{pmatrix}1\\-11\end{pmatrix}$;
 $\;\begin{pmatrix}-6\\2\\-4\end{pmatrix}$;
 $\;\begin{pmatrix}-5\\4\\-5\end{pmatrix}$

2. Scale each entry, then add entry by entry. Subtraction is not a third operation — it is
 addition of a negative multiple, $2\mathbf{u} - 3\mathbf{v} = 2\mathbf{u} + (-3)\mathbf{v}$:

$$
2\begin{pmatrix}2\\-1\end{pmatrix} = \begin{pmatrix}4\\-2\end{pmatrix},
\qquad
(-3)\begin{pmatrix}1\\3\end{pmatrix} = \begin{pmatrix}-3\\-9\end{pmatrix},
\qquad
\begin{pmatrix}4\\-2\end{pmatrix} + \begin{pmatrix}-3\\-9\end{pmatrix} = \begin{pmatrix}1\\-11\end{pmatrix}
$$

3. In $\mathbb{R}^3$ the rule is identical — only the number of entries changes:

$$
(-2)\begin{pmatrix}3\\-1\\2\end{pmatrix} = \begin{pmatrix}-6\\2\\-4\end{pmatrix},
\qquad
\begin{pmatrix}1\\2\\-1\end{pmatrix} + \begin{pmatrix}-6\\2\\-4\end{pmatrix} = \begin{pmatrix}-5\\4\\-5\end{pmatrix}
$$

4. Watch the signs on the middle entry of the last one: $2 + 2 = 4$, because $-2$ times $-1$ is
 $+2$. A sign lost inside a scalar multiple is the most common arithmetic slip in this
 section, and unlike a row-reduction error it produces a perfectly plausible-looking vector.
::::
:::

### The geometry of $\mathbb{R}^2$

Identify the point $(a,b)$ in the plane with the vector $\begin{pmatrix}a\\b\end{pmatrix}$.
 Then $\mathbb{R}^2$ *is* the set of all points in the plane, and a vector can be pictured
 either as a point or as an arrow from the origin to that point. The arrow picture is what
 makes the two operations visible.

**Addition — the parallelogram rule.** Draw $\mathbf{u}$ and $\mathbf{v}$ as arrows from the
 origin. Complete the parallelogram having them as two sides; $\mathbf{u} + \mathbf{v}$ is
 the arrow from the origin along its diagonal.

**Addition — the triangle rule.** Equivalently: draw $\mathbf{u}$ from the origin, then draw
 $\mathbf{v}$ starting at the *tip* of $\mathbf{u}$ instead of at the origin. The arrow from
 the origin to where you end up is $\mathbf{u} + \mathbf{v}$.

These are the same fact seen twice — the parallelogram's opposite sides are equal, so
 sliding $\mathbf{v}$ to the tip of $\mathbf{u}$ traces one half of it. Use the triangle rule
 when chaining several vectors, the parallelogram rule when you want to see that
 $\mathbf{u} + \mathbf{v} = \mathbf{v} + \mathbf{u}$ (both diagonals of the same figure).

To see it concretely, take $\mathbf{u} = \begin{pmatrix}2\\-1\end{pmatrix}$ and
 $\mathbf{v} = \begin{pmatrix}1\\3\end{pmatrix}$. Their sum is
 $\begin{pmatrix}3\\2\end{pmatrix}$. Plot $(2,-1)$, $(1,3)$ and $(3,2)$: the origin and those
 three points are the four corners of a parallelogram.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 190 170" width="190" height="170"
     role="img" aria-label="The parallelogram rule: u and v from the origin, their sum along the diagonal">
<path class="fig-gridline" d="M35.71 158L35.71 12M75.24 158L75.24 12M114.76 158L114.76 12M154.29 158L154.29 12M12 141.15L178 141.15M12 113.08L178 113.08M12 85L178 85M12 56.92L178 56.92M12 28.85L178 28.85"/>
<path class="fig-axis" d="M12 113.08L178 113.08M35.71 158L35.71 12"/>
<path class="fig-guide" d="M114.76 141.15L154.29 56.92"/>
<path class="fig-guide" d="M75.24 28.85L154.29 56.92"/>
<path class="fig-curve" d="M35.71 113.08L110.05 139.48"/><polygon class="fig-arrow" points="114.76,141.15 109.35,141.46 110.75,137.5"/>
<path class="fig-curve-alt" d="M35.71 113.08L73.11 33.37"/><polygon class="fig-arrow" points="75.24,28.85 75.02,34.26 71.21,32.48"/>
<path class="fig-curve" d="M35.71 113.08L149.77 59.06"/><polygon class="fig-arrow" points="154.29,56.92 150.67,60.96 148.87,57.17"/>
<text class="fig-label-em" x="121.76" y="151.15">u</text>
<text class="fig-label-em" x="64.24" y="25.85">v</text>
<text class="fig-label-em" x="158.29" y="50.92">u+v</text>
</svg>
<figcaption>Parallelogram rule: both from the origin, sum along the diagonal.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 190 170" width="190" height="170"
     role="img" aria-label="The triangle rule: u drawn from the tip of v reaches the same point">
<path class="fig-gridline" d="M35.71 158L35.71 12M75.24 158L75.24 12M114.76 158L114.76 12M154.29 158L154.29 12M12 141.15L178 141.15M12 113.08L178 113.08M12 85L178 85M12 56.92L178 56.92M12 28.85L178 28.85"/>
<path class="fig-axis" d="M12 113.08L178 113.08M35.71 158L35.71 12"/>
<path class="fig-curve-alt" d="M35.71 113.08L73.11 33.37"/><polygon class="fig-arrow" points="75.24,28.85 75.02,34.26 71.21,32.48"/>
<path class="fig-curve" d="M75.24 28.85L149.57 55.25"/><polygon class="fig-arrow" points="154.29,56.92 148.87,57.23 150.28,53.27"/>
<path class="fig-curve" d="M35.71 113.08L149.77 59.06"/><polygon class="fig-arrow" points="154.29,56.92 150.67,60.96 148.87,57.17"/>
<text class="fig-label-em" x="64.24" y="25.85">v</text>
<text class="fig-label-em" x="117.76" y="37.88">u</text>
<text class="fig-label-em" x="158.29" y="50.92">u+v</text>
</svg>
<figcaption>Triangle rule: slide $\mathbf{u}$ to the tip of $\mathbf{v}$ — same endpoint.</figcaption>
</figure>

</div>

**Scalar multiplication — stretching along a line.** $c\mathbf{u}$ always lies on the line
 through the origin and $\mathbf{u}$. Only the position along that line changes:

- $c > 1$: same direction, longer than $\mathbf{u}$.
- $0 < c < 1$: same direction, shorter — between the origin and $\mathbf{u}$.
- $c < 0$: **opposite** direction, on the far side of the origin.
- $c = 0$: the zero vector, at the origin.

That the whole line is swept out as $c$ ranges over $\mathbb{R}$ is the reason
 $\text{Span}\{\mathbf{v}\}$ turns out to be a line, later in this section.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 300 150" width="300" height="150"
     role="img" aria-label="Scalar multiples of u lie on one line through the origin: 2u beyond u, half u between, minus u on the far side">
<path class="fig-gridline" d="M35 138L35 12M73.33 138L73.33 12M111.67 138L111.67 12M150 138L150 12M188.33 138L188.33 12M226.67 138L226.67 12M265 138L265 12M12 115.09L288 115.09M12 86.45L288 86.45M12 57.82L288 57.82M12 29.18L288 29.18"/>
<path class="fig-axis" d="M12 86.45L288 86.45M111.67 138L111.67 12"/>
<path class="fig-guide" d="M12 123.68L288 20.59"/>
<circle class="fig-point" cx="265" cy="29.18" r="3.2"/>
<text class="fig-label-em" x="261" y="21.18">2u</text>
<circle class="fig-point" cx="188.33" cy="57.82" r="3.2"/>
<text class="fig-label-em" x="184.33" y="49.82">u</text>
<circle class="fig-point" cx="150" cy="72.14" r="3.2"/>
<text class="fig-label-em" x="146" y="64.14">&#189;u</text>
<circle class="fig-point" cx="35" cy="115.09" r="3.2"/>
<text class="fig-label-em" x="31" y="107.09">&#8722;u</text>
<path class="fig-curve" d="M111.67 86.45L183.65 59.57"/><polygon class="fig-arrow" points="188.33,57.82 184.38,61.53 182.91,57.6"/>
</svg>
<figcaption>Every multiple $c\mathbf{u}$ lands on one line through the origin — $c>1$ beyond $\mathbf{u}$, $0 \lt c \lt 1$ between, $c \lt 0$ on the far side.</figcaption>
</figure>

### Algebraic properties of $\mathbb{R}^n$

Addition and scalar multiplication in $\mathbb{R}^n$ are defined entry by entry, exactly as
 in $\mathbb{R}^2$, for every $n$ — including $n = 3$ and beyond, where the pictures stop
 but the algebra does not.

:::theorem[Theorem 1.3a — The Eight Algebraic Properties]
For all $\mathbf{u}, \mathbf{v}, \mathbf{w} \in \mathbb{R}^n$ and all scalars $c, d$:

| | |
|---|---|
| (1) $\mathbf{u} + \mathbf{v} = \mathbf{v} + \mathbf{u}$ | (5) $c(\mathbf{u} + \mathbf{v}) = c\mathbf{u} + c\mathbf{v}$ |
| (2) $(\mathbf{u} + \mathbf{v}) + \mathbf{w} = \mathbf{u} + (\mathbf{v} + \mathbf{w})$ | (6) $(c + d)\mathbf{u} = c\mathbf{u} + d\mathbf{u}$ |
| (3) $\mathbf{u} + \mathbf{0} = \mathbf{0} + \mathbf{u} = \mathbf{u}$ | (7) $c(d\mathbf{u}) = (cd)\mathbf{u}$ |
| (4) $\mathbf{u} + (-\mathbf{u}) = \mathbf{0}$ | (8) $1\mathbf{u} = \mathbf{u}$ |
:::

Every one of these is immediate: both sides are computed entry by entry, and each entry is
 an ordinary statement about real numbers. Property (1), for instance, holds in the $i$-th
 entry because $u_i + v_i = v_i + u_i$ for numbers.

So why write them down at all? Two reasons, and the second is the real one.

First, they are what let you manipulate vector expressions without dropping back to
 coordinates — $2\mathbf{u} - 3\mathbf{v}$ can be rearranged and regrouped like ordinary
 algebra, and properties (5)–(7) are the licence to do it.

Second, this exact list of eight is the **definition of a vector space**, which is Chapter 4.
 There you will meet sets whose elements are polynomials, or matrices, or functions — not
 lists of numbers at all — and the only thing making them "vectors" is that these eight hold.
 $\mathbb{R}^n$ is the example the general definition was reverse-engineered from. Learning
 them now costs nothing extra and makes Chapter 4 a recognition rather than a surprise.

:::definition[Definition 1.5 — Linear Combination & Span]
Given vectors $\mathbf{v}_1, \ldots, \mathbf{v}_p \in \mathbb{R}^n$ and scalars
 $c_1, \ldots, c_p$, the vector

$$
y = c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + \cdots + c_p\mathbf{v}_p
$$

 is called a **linear combination** of $\mathbf{v}_1, \ldots, \mathbf{v}_p$
 with *weights* $c_1, \ldots, c_p$.

The **span** of $\{\mathbf{v}_1, \ldots, \mathbf{v}_p\}$ is the set of
 *all* possible linear combinations:

$$
\text{Span}\{\mathbf{v}_1,\ldots,\mathbf{v}_p\} = \{c_1\mathbf{v}_1 + \cdots + c_p\mathbf{v}_p \mid c_1,\ldots,c_p \in \mathbb{R}\}.
$$
:::

:::theorem[Theorem 1.3 — Vector Equation = Linear System]
$\mathbf{b}$ is a linear combination of $\mathbf{v}_1, \ldots, \mathbf{v}_p$
 *if and only if* the linear system with augmented matrix
 $[\mathbf{v}_1\ \mathbf{v}_2\ \cdots\ \mathbf{v}_p \mid \mathbf{b}]$
 is consistent.
:::

:::callout-key[How to build that matrix]
There is nothing to compute. The augmented matrix in Theorem 1.3 is just the vectors
 **stood side by side as columns**, in order, with $\mathbf{b}$ last:

$$
x_1\mathbf{a}_1 + x_2\mathbf{a}_2 + \cdots + x_n\mathbf{a}_n = \mathbf{b}
\qquad\Longleftrightarrow\qquad
\left[\begin{array}{cccc|c}\mathbf{a}_1 & \mathbf{a}_2 & \cdots & \mathbf{a}_n & \mathbf{b}\end{array}\right]
$$

A vector equation and a linear system are not two problems that happen to have the same
 answer — they are the same problem written two ways, and the translation between them is
 pure transcription.
:::

### The geometry of span

Two cases in $\mathbb{R}^3$ are worth holding as pictures, because almost every span question
 reduces to one of them.

**One vector.** Let $\mathbf{v} \in \mathbb{R}^3$ with $\mathbf{v} \neq \mathbf{0}$. Then
 $\text{Span}\{\mathbf{v}\}$ is the set of all multiples $c\mathbf{v}$ — the **line through
 the origin and $\mathbf{v}$**. It is a line, not a ray: negative $c$ gives the other half.

**Two vectors.** Let $\mathbf{u}, \mathbf{v} \in \mathbb{R}^3$ be nonzero, with $\mathbf{v}$
 **not** a scalar multiple of $\mathbf{u}$. Then $\text{Span}\{\mathbf{u}, \mathbf{v}\}$ is
 the **plane through the origin containing $\mathbf{u}$ and $\mathbf{v}$**.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 190 175" width="190" height="175"
     role="img" aria-label="The span of one nonzero vector is the whole line through it and the origin">
<path class="fig-axis" d="M79.8 105L49.77 127.93M79.8 105L134.4 105M79.8 105L79.8 50.4"/>
<path class="fig-guide" d="M29.88 133.55L136.38 72.65"/>
<path class="fig-curve" d="M79.8 105L108.74 88.45"/><polygon class="fig-arrow" points="113.08,85.97 109.78,90.27 107.7,86.63"/>
<text class="fig-label-em" x="119.08" y="82.97">v</text>
<text class="fig-label" x="37.77" y="133.93">x&#8321;</text><text class="fig-label" x="138.4" y="109">x&#8322;</text><text class="fig-label" x="81.8" y="47.4">x&#8323;</text>
</svg>
<figcaption>$\text{Span}\{\mathbf{v}\}$ — the whole line through $\mathbf{v}$ and $\mathbf{0}$, both directions.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 190 175" width="190" height="175"
     role="img" aria-label="The span of two vectors that are not multiples of one another is the plane through them and the origin">
<polygon class="fig-fill" points="36.7,130.95 137.42,126.49 126.27,76.61 25.54,81.07"/>
<path class="fig-axis" d="M79.8 105L49.77 127.93M79.8 105L134.4 105M79.8 105L79.8 50.4"/>
<path class="fig-guide" d="M36.7 130.95L137.42 126.49L126.27 76.61L25.54 81.07 Z"/>
<path class="fig-curve" d="M79.8 105L113.54 103.51"/><polygon class="fig-arrow" points="118.54,103.28 113.64,105.6 113.45,101.41"/>
<text class="fig-label-em" x="123.54" y="99.28">u</text>
<path class="fig-curve" d="M79.8 105L75.82 87.21"/><polygon class="fig-arrow" points="74.73,82.33 77.87,86.75 73.77,87.67"/>
<text class="fig-label-em" x="79.73" y="78.33">v</text>
<text class="fig-label" x="37.77" y="133.93">x&#8321;</text><text class="fig-label" x="138.4" y="109">x&#8322;</text><text class="fig-label" x="81.8" y="47.4">x&#8323;</text>
</svg>
<figcaption>$\text{Span}\{\mathbf{u},\mathbf{v}\}$ — a plane, and it must contain the origin.</figcaption>
</figure>

</div>

The condition on the second case is the whole content of it. If $\mathbf{v}$ *were* a
 multiple of $\mathbf{u}$, every combination $c_1\mathbf{u} + c_2\mathbf{v}$ would collapse
 back onto a multiple of $\mathbf{u}$ and the span would be a line again — which is exactly
 what happens in Example 1.15 below.

Notice that every span contains $\mathbf{0}$ (take all weights zero), so these lines and
 planes always pass through the origin. A line or plane that misses the origin is never a
 span — a fact that becomes the whole distinction between $A\mathbf{x} = \mathbf{0}$ and
 $A\mathbf{x} = \mathbf{b}$ in section 1.5.

### Worked examples

:::example[Example 1.14 — Is b in the span?]
Let $\mathbf{a}_1 = \begin{pmatrix}1\\-2\\0\end{pmatrix}$,
 $\mathbf{a}_2 = \begin{pmatrix}0\\1\\2\end{pmatrix}$,
 $\mathbf{b} = \begin{pmatrix}3\\-2\\4\end{pmatrix}$.
 Is $\mathbf{b} \in \text{Span}\{\mathbf{a}_1, \mathbf{a}_2\}$?


::::answer[Answer]
**Answer:** No — $\mathbf{b} \notin \text{Span}\{\mathbf{a}_1, \mathbf{a}_2\}$.

1. Row-reduce $[\mathbf{a}_1\ \mathbf{a}_2 \mid \mathbf{b}]$:

$$
\left[\begin{array}{rr|r}1&0&3\\-2&1&-2\\0&2&4\end{array}\right]
      \xrightarrow{R_2+2R_1}
      \left[\begin{array}{rr|r}1&0&3\\0&1&4\\0&2&4\end{array}\right]
      \xrightarrow{R_3-2R_2}
      \left[\begin{array}{rr|r}1&0&3\\0&1&4\\0&0&-4\end{array}\right]
$$

2. Read the last row: it says $0 = -4$. No choice of weights can make that true,
 so the system has no solution and $\mathbf{b}$ is **not** in the span.

3. It is worth being sure of the arithmetic rather than of the shape of the answer, because a
 contradiction is exactly what a slip looks like. Take $R_2 + 2R_1$ one entry at a time:
 $-2 + 2(1) = 0$, then $1 + 2(0) = 1$, then $-2 + 2(3) = 4$. That row is $[0\ \ 1\ \mid 4]$.
 Now $R_3 - 2R_2$: $0 - 0 = 0$, then $2 - 2 = 0$, then $4 - 8 = -4$. The contradiction is real.

4. The geometry behind it is worth a sentence. Two vectors in $\mathbb{R}^3$ span a plane through
 the origin, and a plane is a thin thing to hit — most vectors in space miss it. Here
 $\mathbf{a}_1$ and $\mathbf{a}_2$ are not multiples of each other, so they really do span a
 plane, and $\mathbf{b}$ simply lies off it. The first two coordinates can always be matched:
 row one forces $c_1 = 3$ and row two then forces $c_2 = 4$. It is the third coordinate that
 refuses — those weights give $2(4) = 8$ where $\mathbf{b}$ needs $4$.

:::::callout-tip[Key takeaway]
Always row-reduce rather than guess. The row-reduction is the authoritative check — it's easy to be led astray by trying to solve by inspection.
:::::
::::
:::

:::example[Example 1.15 — Span of two vectors in $\mathbb{R}^2$]
Let $\mathbf{v}_1 = \begin{pmatrix}1\\2\end{pmatrix}$, $\mathbf{v}_2 = \begin{pmatrix}3\\6\end{pmatrix}$.
 Describe $\text{Span}\{\mathbf{v}_1, \mathbf{v}_2\}$.


::::answer[Answer]
**Answer:** The line through the origin in the direction $(1,2)^T$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Note that $\mathbf{v}_2 = 3\mathbf{v}_1$, so any linear combination
 $c_1\mathbf{v}_1 + c_2\mathbf{v}_2 = c_1\mathbf{v}_1 + 3c_2\mathbf{v}_1 = (c_1+3c_2)\mathbf{v}_1$.
 This is just a scalar multiple of $\mathbf{v}_1$ — the span collapses to a single line.
 Two vectors only span a *plane* when they are not parallel (not scalar multiples of each other).
::::
:::

:::example[Example 1.16 — Finding the weights, not just deciding they exist]
Let

$$
\mathbf{a}_1 = \begin{pmatrix}1\\-2\\2\end{pmatrix},\quad
\mathbf{a}_2 = \begin{pmatrix}0\\1\\1\end{pmatrix},\quad
\mathbf{a}_3 = \begin{pmatrix}2\\0\\9\end{pmatrix},\quad
\mathbf{b} = \begin{pmatrix}-5\\11\\7\end{pmatrix}.
$$

Determine whether $\mathbf{b}$ is a linear combination of $\mathbf{a}_1, \mathbf{a}_2,
 \mathbf{a}_3$, and if so find the weights.


::::answer[Answer]
**Answer:** Yes: $\;-37\,\mathbf{a}_1 - 63\,\mathbf{a}_2 + 16\,\mathbf{a}_3 = \mathbf{b}$.

1. We are asking whether weights $x_1, x_2, x_3$ exist with

$$
x_1\begin{pmatrix}1\\-2\\2\end{pmatrix} + x_2\begin{pmatrix}0\\1\\1\end{pmatrix} + x_3\begin{pmatrix}2\\0\\9\end{pmatrix} = \begin{pmatrix}-5\\11\\7\end{pmatrix}
$$

2. Scaling and adding on the left gives a single vector, and two vectors are equal exactly when
 their entries match — so reading the equation off row by row turns it into a system:

$$
\begin{pmatrix}x_1 + 2x_3\\-2x_1 + x_2\\2x_1 + x_2 + 9x_3\end{pmatrix} = \begin{pmatrix}-5\\11\\7\end{pmatrix}
\;\Longleftrightarrow\;
\begin{cases}x_1 \phantom{{}+x_2} + 2x_3 = -5\\ -2x_1 + x_2 \phantom{{}+9x_3} = 11\\ 2x_1 + x_2 + 9x_3 = 7\end{cases}
$$

3. Its augmented matrix is the four vectors side by side, exactly as the box above promised.
 Reduce:

$$
\left[\begin{array}{rrr|r}1&0&2&-5\\-2&1&0&11\\2&1&9&7\end{array}\right]
\xrightarrow{R_2+2R_1,\;R_3-2R_1}
\left[\begin{array}{rrr|r}1&0&2&-5\\0&1&4&1\\0&1&5&17\end{array}\right]
\xrightarrow{R_3-R_2}
\left[\begin{array}{rrr|r}1&0&2&-5\\0&1&4&1\\0&0&1&16\end{array}\right]
$$

4. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{R_1-2R_3,\;R_2-4R_3}
\left[\begin{array}{rrr|r}1&0&0&-37\\0&1&0&-63\\0&0&1&16\end{array}\right]
$$

5. Consistent, so $\mathbf{b}$ *is* a linear combination — with weights $x_1 = -37$,
 $x_2 = -63$, $x_3 = 16$. Weights are allowed to be large and negative; nothing in the
 definition asks them to be small or tidy.

6. Verify, because weights this ugly are worth checking:

$$
-37\begin{pmatrix}1\\-2\\2\end{pmatrix} - 63\begin{pmatrix}0\\1\\1\end{pmatrix} + 16\begin{pmatrix}2\\0\\9\end{pmatrix}
= \begin{pmatrix}-37+0+32\\74-63+0\\-74-63+144\end{pmatrix}
= \begin{pmatrix}-5\\11\\7\end{pmatrix}\;\checkmark
$$

:::::callout-tip[Key takeaway]
"Is $\mathbf{b}$ in the span?" is answered by *consistency* — you only need to know whether
 a solution exists. "What are the weights?" requires actually solving. Read which one the
 question wants before you decide how far to reduce.
:::::
::::
:::

:::example[Example 1.17 — A parameter in the target vector]
Let $\mathbf{v}_1 = \begin{pmatrix}1\\0\\-2\end{pmatrix}$,
 $\mathbf{v}_2 = \begin{pmatrix}-3\\1\\8\end{pmatrix}$,
 $\mathbf{y} = \begin{pmatrix}h\\-5\\-3\end{pmatrix}$.
 For what values of $h$ is $\mathbf{y} \in \text{Span}\{\mathbf{v}_1, \mathbf{v}_2\}$?


::::answer[Answer]
**Answer:** Only $h = -\tfrac{7}{2}$.

1. Consider the vector equation $x_1\mathbf{v}_1 + x_2\mathbf{v}_2 = \mathbf{y}$ and reduce
 $[\mathbf{v}_1\ \mathbf{v}_2 \mid \mathbf{y}]$, carrying $h$ along as an ordinary symbol:

$$
\left[\begin{array}{rr|r}1&-3&h\\0&1&-5\\-2&8&-3\end{array}\right]
\xrightarrow{R_3+2R_1}
\left[\begin{array}{rr|r}1&-3&h\\0&1&-5\\0&2&-3+2h\end{array}\right]
\xrightarrow{R_3-2R_2}
\left[\begin{array}{rr|r}1&-3&h\\0&1&-5\\0&0&7+2h\end{array}\right]
$$

2. The bottom row reads $0 = 7 + 2h$. By the consistency test, the system has a solution
 exactly when that constant is zero:

$$
7 + 2h = 0 \quad\Longrightarrow\quad h = -\tfrac{7}{2}
$$

3. For every other $h$ the last row is a contradiction and $\mathbf{y}$ lies off the span.

4. The geometry says the same thing. $\mathbf{v}_1$ and $\mathbf{v}_2$ are not multiples of one
 another, so their span is a plane through the origin in $\mathbb{R}^3$. Varying $h$ slides
 $\mathbf{y}$ along a line in the $x_1$ direction, and a line meets a plane it is not
 parallel to in exactly one point — one value of $h$. Getting a *single* answer here is what
 you should expect; a range of $h$ would have been a reason to recheck.
::::
:::

:::callout-pitfall[Watch out for]
- **Assuming two vectors always span $\mathbb{R}^2$.** If they are scalar multiples of each other (parallel), the span is just a line.
- **Confusing the span with the set of vectors.** $\text{Span}\{\mathbf{v}_1,\mathbf{v}_2\}$ is an infinite set containing all linear combinations — not just $\mathbf{v}_1$ and $\mathbf{v}_2$ themselves.
- **Weights can be zero or negative.** Any real number is a valid weight, including fractions, negatives, and zero.
:::

### Practice problems

:::problem[Problem 1.9 — Compute the vector result]{difficulty=easy}
Compute $2\mathbf{u} - 3\mathbf{v}$ where $\mathbf{u}=\begin{pmatrix}1\\-1\\2\end{pmatrix}$ and $\mathbf{v}=\begin{pmatrix}0\\3\\1\end{pmatrix}$.


::::solution[Solution]
**Answer:** $2\begin{pmatrix}1\\-1\\2\end{pmatrix} - 3\begin{pmatrix}0\\3\\1\end{pmatrix} = \begin{pmatrix}2\\-2\\4\end{pmatrix} - \begin{pmatrix}0\\9\\3\end{pmatrix} = \begin{pmatrix}2\\-11\\1\end{pmatrix}$

1. $2\begin{pmatrix}1\\-1\\2\end{pmatrix} - 3\begin{pmatrix}0\\3\\1\end{pmatrix} = \begin{pmatrix}2\\-2\\4\end{pmatrix} - \begin{pmatrix}0\\9\\3\end{pmatrix} = \begin{pmatrix}2\\-11\\1\end{pmatrix}$

2. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.

3. The check is componentwise: $2(1)-3(0)=2$, $2(-1)-3(3)=-11$, and $2(2)-3(1)=1$. Each entry of the final vector therefore matches the original linear combination.
::::
:::

:::problem[Problem 1.10 — Row reduction and solution]{difficulty=standard}
Determine if $\mathbf{b} = \begin{pmatrix}1\\2\\3\end{pmatrix}$ is in $\text{Span}\left\{\begin{pmatrix}1\\0\\1\end{pmatrix}, \begin{pmatrix}0\\1\\1\end{pmatrix}\right\}$. If yes, find the weights.


::::solution[Solution]
**Answer:** Yes, $\mathbf b=\mathbf a_1+2\mathbf a_2$ (weights $1,2$).

1. Row-reduce $\left[\begin{array}{rr|r}1&0&1\\0&1&2\\1&1&3\end{array}\right]$:

$$
\xrightarrow{R_3-R_1-R_2}\left[\begin{array}{rr|r}1&0&1\\0&1&2\\0&0&0\end{array}\right]
$$

2. Consistent! Weights: $c_1 = 1$, $c_2 = 2$. Check: $\begin{pmatrix}1\\0\\1\end{pmatrix} + 2\begin{pmatrix}0\\1\\1\end{pmatrix} = \begin{pmatrix}1\\2\\3\end{pmatrix}\,\checkmark$.

3. The last row becomes $0=0$, so neither equation conflicts with the proposed weights. Both independent coordinate equations determine the coefficients $1$ and $2$, while the third coordinate verifies $1+2=3$.
::::
:::

:::problem[Problem 1.11 — Span and membership]{difficulty=standard}
Describe $\text{Span}\left\{\begin{pmatrix}1\\0\\0\end{pmatrix}, \begin{pmatrix}0\\1\\0\end{pmatrix}\right\}$ geometrically.


::::solution[Solution]
**Answer:** The $xy$-plane $\{(c_1,c_2,0):c_1,c_2\in\mathbb R\}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Any linear combination is $c_1\begin{pmatrix}1\\0\\0\end{pmatrix}+c_2\begin{pmatrix}0\\1\\0\end{pmatrix}=\begin{pmatrix}c_1\\c_2\\0\end{pmatrix}$.
 This is the $xy$-plane in $\mathbb{R}^3$ (all vectors with third component = 0).
 The two vectors are not parallel, so they span a full plane.
::::
:::

## 1.4 Matrix Equation $\mathbf{A}\mathbf{x} = \mathbf{b}$

:::callout-intuition[Intuition first]
The product $\mathbf{Ax}$ is defined so that it equals exactly the linear combination of
 columns of $\mathbf{A}$ with weights from $\mathbf{x}$. This single compact notation
 — one matrix equation — captures an entire linear system. From now on, you should be fluent
 in all three equivalent views: (1) a list of scalar equations, (2) a vector equation
 (linear combination of columns), and (3) a matrix equation $\mathbf{Ax}=\mathbf{b}$.
:::

:::definition[Definition 1.6 — Matrix-Vector Product]
If $A$ is an $m \times n$ matrix with columns $\mathbf{a}_1, \ldots, \mathbf{a}_n$
 and $\mathbf{x} \in \mathbb{R}^n$, then

$$
A\mathbf{x} = x_1\mathbf{a}_1 + x_2\mathbf{a}_2 + \cdots + x_n\mathbf{a}_n.
$$

 Equivalently, the $i$-th entry of $A\mathbf{x}$ is the dot product of row $i$ of $A$ with $\mathbf{x}$.
:::

:::callout-warning[When $A\mathbf{x}$ does not exist]
$A\mathbf{x}$ is defined **only if the number of columns of $A$ equals the number of entries
 in $\mathbf{x}$.** This is forced by the definition: $A\mathbf{x}$ pairs each column of $A$
 with one entry of $\mathbf{x}$ as its weight, so a leftover column or a leftover entry
 leaves the expression meaningless. There is no convention for patching it.

$$
\begin{bmatrix}2&-1&2\\0&1&3\end{bmatrix}\begin{pmatrix}-1\\2\end{pmatrix}
\qquad\text{is \textbf{not defined}} \quad (3 \text{ columns},\; 2 \text{ entries})
$$

If $A$ is $m \times n$ then $\mathbf{x}$ must be in $\mathbb{R}^n$, and the result
 $A\mathbf{x}$ lands in $\mathbb{R}^m$. Check this before computing anything — "undefined"
 is a complete and correct answer, and it is a free mark on an exam.
:::

### Two ways to compute $A\mathbf{x}$

**1. By the definition** — scale each column of $A$ by the matching entry of $\mathbf{x}$ and
 add the columns.

**2. By the row–vector rule** — the $i$-th entry of $A\mathbf{x}$ is the dot product of the
 $i$-th **row** of $A$ with $\mathbf{x}$.

:::example[Example 1.18 — The same product, both ways]
Let $A = \begin{bmatrix}1&0&2\\-2&3&4\\2&-3&1\end{bmatrix}$ and
 $\mathbf{x} = \begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix}$. Find $A\mathbf{x}$.


::::answer[Answer]
**Answer:** $A\mathbf{x} = \begin{pmatrix}x_1 + 2x_3\\-2x_1+3x_2+4x_3\\2x_1-3x_2+x_3\end{pmatrix}$

1. **By the definition** — three columns, three weights, added:

$$
x_1\begin{pmatrix}1\\-2\\2\end{pmatrix} + x_2\begin{pmatrix}0\\3\\-3\end{pmatrix} + x_3\begin{pmatrix}2\\4\\1\end{pmatrix}
= \begin{pmatrix}x_1 + 2x_3\\-2x_1 + 3x_2 + 4x_3\\2x_1 - 3x_2 + x_3\end{pmatrix}
$$

2. **By the row–vector rule** — three rows, three dot products with $\mathbf{x}$. Row 3 is
 $\begin{bmatrix}2&-3&1\end{bmatrix}$, giving $2x_1 - 3x_2 + x_3$. Same vector.

3. The methods read the matrix in perpendicular directions — the first goes down columns, the
 second across rows — which is precisely why running both catches slips. A wrong entry
 almost never survives being computed two different ways.

:::::callout-pitfall[The most common slip here]
Losing track of *which* index a coefficient belongs to. In the third entry, the $2x_1$ comes
 from $a_{31} = 2$, the third entry of the **first column**. It is easy to reach instead for
 a number from the third column, or from row 1, and write $3x_1$. If your two computations
 disagree, this is almost always where.
:::::
::::
:::

### Three equivalent ways to view a system

Everything so far has been the same object in different clothing. For
 $A = [\mathbf{a}_1\ \cdots\ \mathbf{a}_n]$:

| view | written as |
|---|---|
| system of linear equations | $\begin{cases}a_{11}x_1 + \cdots + a_{1n}x_n = b_1\\ \vdots\end{cases}$ |
| vector equation | $x_1\mathbf{a}_1 + x_2\mathbf{a}_2 + \cdots + x_n\mathbf{a}_n = \mathbf{b}$ |
| matrix equation | $A\mathbf{x} = \mathbf{b}$ |

:::theorem[Theorem 1.3b — The Three Views Agree]
The matrix equation $A\mathbf{x} = \mathbf{b}$ has the same solution set as the vector
 equation $x_1\mathbf{a}_1 + \cdots + x_n\mathbf{a}_n = \mathbf{b}$, which in turn has the
 same solution set as the system whose augmented matrix is
 $[\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_n \mid \mathbf{b}]$.
:::

**And there is still only one way to solve it: row-reduce the augmented matrix.** The three
 views are for *thinking* — each makes a different question look easy. "Is $\mathbf{b}$
 reachable?" is obvious in the vector view; "what does $A$ do to $\mathbf{x}$?" is obvious in
 the matrix view. But whichever view a problem arrives in, the computation is the same one
 you learned in 1.2.

Being fluent in all three is worth real marks, because exam questions routinely state a
 problem in one view and ask for an answer in another.

:::example[Example 1.19 — One system, all three views]
Write the system

$$
\begin{cases}x_1 - x_2 + 2x_3 = 2\\ 2x_1 \phantom{{}- x_2} + 3x_3 = 1\end{cases}
$$

as a vector equation and as a matrix equation.


::::answer[Answer]
**Answer:** $x_1\begin{pmatrix}1\\2\end{pmatrix} + x_2\begin{pmatrix}-1\\0\end{pmatrix} + x_3\begin{pmatrix}2\\3\end{pmatrix} = \begin{pmatrix}2\\1\end{pmatrix}$ and $\begin{bmatrix}1&-1&2\\2&0&3\end{bmatrix}\begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix} = \begin{pmatrix}2\\1\end{pmatrix}$

1. $x_1\begin{pmatrix}1\\2\end{pmatrix} + x_2\begin{pmatrix}-1\\0\end{pmatrix} + x_3\begin{pmatrix}2\\3\end{pmatrix} = \begin{pmatrix}2\\1\end{pmatrix}$
 and $\begin{bmatrix}1&-1&2\\2&0&3\end{bmatrix}\begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix} = \begin{pmatrix}2\\1\end{pmatrix}$

2. Read **down the columns**, not across the rows. The coefficients of $x_1$ are $1$ and $2$ —
 one from each equation — and those become the first vector. The coefficients of $x_2$ are
 $-1$ and $0$; the missing $x_2$ in equation two is a coefficient of zero, and it must be
 written.

$$
x_1\begin{pmatrix}1\\2\end{pmatrix} + x_2\begin{pmatrix}-1\\0\end{pmatrix} + x_3\begin{pmatrix}2\\3\end{pmatrix} = \begin{pmatrix}2\\1\end{pmatrix}
$$

3. Standing those same three vectors side by side as the columns of a matrix gives the matrix
 equation, with $A$ being $2 \times 3$ — two equations, three unknowns:

$$
\underbrace{\begin{bmatrix}1&-1&2\\2&0&3\end{bmatrix}}_{A}
\underbrace{\begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix}}_{\mathbf{x}}
= \underbrace{\begin{pmatrix}2\\1\end{pmatrix}}_{\mathbf{b}}
$$

4. Nothing was computed. The system's coefficients, the vector equation's vectors, and the
 matrix's columns are the same numbers in the same places — only the punctuation changed.
::::
:::

:::theorem[Theorem 1.4 — Existence of Solutions]
Let $A$ be $m\times n$ and $\mathbf{b} \in \mathbb{R}^m$. The following are equivalent:

1. The equation $A\mathbf{x} = \mathbf{b}$ has a solution.
2. $\mathbf{b}$ is a linear combination of the columns of $A$.
3. $\mathbf{b} \in \text{Span}\{\mathbf{a}_1,\ldots,\mathbf{a}_n\}$.
4. The augmented matrix $[A \mid \mathbf{b}]$ has no pivot in the last column.
:::

Theorem 1.4 is about **one particular $\mathbf{b}$**. A different and much stronger question
 is whether $A\mathbf{x} = \mathbf{b}$ can be solved for *every* $\mathbf{b}$ at once — that
 is a property of $A$ alone, and it has its own theorem.

:::theorem[Theorem 1.4a — Solvable for Every $\mathbf{b}$]
Let $A = [\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_n]$ be an $m \times n$ matrix. The
 following statements are **equivalent** — either all four hold, or none do:

(a) For each $\mathbf{b} \in \mathbb{R}^m$, the equation $A\mathbf{x} = \mathbf{b}$ has a
 solution.
(b) Each $\mathbf{b} \in \mathbb{R}^m$ is a linear combination of the columns of $A$.
(c) $\mathbb{R}^m = \text{Span}\{\mathbf{a}_1, \mathbf{a}_2, \ldots, \mathbf{a}_n\}$ — the
 columns of $A$ span all of $\mathbb{R}^m$.
(d) $A$ has a **pivot position in every row**.
:::

:::callout-warning[The single most common error in this section]
Condition (d) is about $A$ — the coefficient matrix. It is **not** about the augmented
 matrix $[\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_n\ \mathbf{b}]$.

Writing "$[A \mid \mathbf{b}]$ has a pivot in every row" is a different claim, and a false
 one — that matrix having a pivot in its last row is exactly the *inconsistent* case. The two
 theorems point in opposite directions:

| | about | condition |
|---|---|---|
| **Theorem 1.4** | one specific $\mathbf{b}$ | $[A \mid \mathbf{b}]$ has **no** pivot in the last **column** |
| **Theorem 1.4a** | every $\mathbf{b}$ at once | $A$ has a pivot in every **row** |

Row versus column, $A$ versus $[A \mid \mathbf{b}]$. Read which is being asked.
:::

Why (d) gives (a) is worth seeing rather than memorizing. Row-reduce $A$ to echelon form.

- **If every row has a pivot**, then no row of that echelon form is entirely zero. So when
  you attach any $\mathbf{b}$ and reduce, you can never produce a row
  $[0\ \cdots\ 0 \mid c]$ with $c \neq 0$ — there is always a pivot to the left absorbing it.
  Consistent for every $\mathbf{b}$.
- **If some row has no pivot**, that row is all zeros in the echelon form of $A$. Now
  $\mathbf{b}$ can be chosen to make that row's augmented entry nonzero, producing exactly
  the contradictory row. So there exists a $\mathbf{b}$ with no solution, and (a) fails.

A quick consequence worth carrying: an $m \times n$ matrix has at most one pivot per row and
 at most one per column, so it has at most $\min(m,n)$ pivots. If $n < m$ — fewer columns
 than rows — there are not enough pivots to fill every row, and (d) is impossible. **Fewer
 than $m$ columns can never span $\mathbb{R}^m$.** Three vectors cannot span $\mathbb{R}^4$,
 no matter which three.

:::example[Example 1.20 — Computing Ax]
Compute $A\mathbf{x}$ where
 $A = \begin{bmatrix}1&2&-1\\0&-5&3\end{bmatrix}$ and $\mathbf{x} = \begin{pmatrix}4\\-2\\7\end{pmatrix}$.


::::answer[Answer]
**Answer:** $A\mathbf{x} = \begin{pmatrix}-7\\31\end{pmatrix}$

1. Row dot-product method — row 1 of $A$ dotted with $\mathbf{x}$:

$$
(1)(4) + (2)(-2) + (-1)(7) = 4 - 4 - 7 = -7
$$

2. Row 2:

$$
(0)(4) + (-5)(-2) + (3)(7) = 0 + 10 + 21 = 31
$$

3. Now check it the other way. The two methods are not two tricks for the same arithmetic —
 they are the definition and a consequence of it, and they must agree. By the definition,
 $A\mathbf{x}$ is the linear combination of the *columns* of $A$ with weights from $\mathbf{x}$:

$$
4\begin{pmatrix}1\\0\end{pmatrix} + (-2)\begin{pmatrix}2\\-5\end{pmatrix} + 7\begin{pmatrix}-1\\3\end{pmatrix}
 = \begin{pmatrix}4\\0\end{pmatrix}+\begin{pmatrix}-4\\10\end{pmatrix}+\begin{pmatrix}-7\\21\end{pmatrix}
 = \begin{pmatrix}-7\\31\end{pmatrix}\;\checkmark
$$

4. Same answer, arrived at by adding three scaled columns instead of taking two dot products.
 Running both is the cheapest self-check you have on this operation.
::::
:::

### The identity matrix

:::definition[Definition 1.6a — Identity Matrix]
The **identity matrix** $I_n$ is the $n \times n$ matrix with $1$s on the main diagonal and
 $0$s everywhere else:

$$
I_3 = \begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}
$$

For every $\mathbf{x} \in \mathbb{R}^n$: $\quad I_n\mathbf{x} = \mathbf{x}$.
:::

The reason is immediate from the definition of the product: $I_n\mathbf{x}$ is the
 combination of the columns of $I_n$ with weights $x_1, \ldots, x_n$, and the columns of
 $I_n$ are exactly the vectors with a single $1$ in each position. So the combination
 reassembles $\mathbf{x}$ entry by entry.

$I_n$ is the "do nothing" matrix — the matrix analogue of multiplying a number by $1$. It is
 also the form the coefficient matrix takes when a system has been reduced all the way to a
 unique solution: an RREF of $\left[\begin{array}{rrr|r}1&0&0&29\\0&1&0&16\\0&0&1&3\end{array}\right]$
 is precisely $[\,I_3 \mid \mathbf{x}\,]$, which is why the answer can be read straight off.

### Two properties of the product

:::theorem[Theorem 1.4b — Linearity of $A\mathbf{x}$]
If $A$ is an $m \times n$ matrix, $\mathbf{u}, \mathbf{v} \in \mathbb{R}^n$, and $c$ is a
 scalar, then

$$
\text{(a)}\quad A(\mathbf{u} + \mathbf{v}) = A\mathbf{u} + A\mathbf{v}
\qquad\qquad
\text{(b)}\quad A(c\mathbf{u}) = c\,(A\mathbf{u})
$$
:::

These two lines are small but they carry a great deal of the rest of the course.

Immediately, they are what proves Theorem 1.5 in the next section: if $A\mathbf{p} =
 \mathbf{b}$ and $A\mathbf{v}_h = \mathbf{0}$, then
 $A(\mathbf{p} + \mathbf{v}_h) = A\mathbf{p} + A\mathbf{v}_h = \mathbf{b} + \mathbf{0} =
 \mathbf{b}$ — so adding any homogeneous solution to a particular solution gives another
 solution. The structure of every solution set in 1.5 follows from property (a).

Further out, a map satisfying exactly these two properties is what section 1.8 will call a
 **linear transformation**. Theorem 1.4b says that multiplying by a matrix is one — and 1.9
 proves the converse, that every linear transformation from $\mathbb{R}^n$ to $\mathbb{R}^m$
 is multiplication by some matrix. That correspondence is the reason matrices matter at all,
 and it starts here.

### Practice problems

:::problem[Problem 1.12 — Compute a matrix product]{difficulty=easy}
Compute each product, or say that it is not defined.

$$
\text{(i)}\;\begin{bmatrix}1&-2&3\\2&0&-1\end{bmatrix}\begin{pmatrix}1\\-1\\2\end{pmatrix}
\qquad
\text{(ii)}\;\begin{bmatrix}1&-2\\2&0\\-1&3\end{bmatrix}\begin{pmatrix}2\\-3\end{pmatrix}
\qquad
\text{(iii)}\;\begin{bmatrix}2&-1&2\\0&1&3\end{bmatrix}\begin{pmatrix}-1\\2\end{pmatrix}
$$


::::solution[Solution]
**Answer:** (i) $(9,0)^T$; (ii) $(8,4,-11)^T$; (iii) not defined because the dimensions do not match.

1. **(i)** $A$ is $2\times3$ and $\mathbf{x}$ has $3$ entries — defined, result in $\mathbb{R}^2$.
 By the definition:

$$
1\begin{pmatrix}1\\2\end{pmatrix} - 1\begin{pmatrix}-2\\0\end{pmatrix} + 2\begin{pmatrix}3\\-1\end{pmatrix}
= \begin{pmatrix}1\\2\end{pmatrix} + \begin{pmatrix}2\\0\end{pmatrix} + \begin{pmatrix}6\\-2\end{pmatrix}
= \begin{pmatrix}9\\0\end{pmatrix}
$$

2. **(ii)** $A$ is $3\times2$ and $\mathbf{x}$ has $2$ entries — defined, result in $\mathbb{R}^3$:

$$
2\begin{pmatrix}1\\2\\-1\end{pmatrix} - 3\begin{pmatrix}-2\\0\\3\end{pmatrix}
= \begin{pmatrix}2\\4\\-2\end{pmatrix} + \begin{pmatrix}6\\0\\-9\end{pmatrix}
= \begin{pmatrix}8\\4\\-11\end{pmatrix}
$$

3. **(iii)** **Not defined.** $A$ has $3$ columns but $\mathbf{x}$ has only $2$ entries. There
 is no third weight for the third column.
::::
:::

:::problem[Problem 1.13 — Compute a matrix product]{difficulty=easy}
Compute each product using the row–vector rule.

$$
\text{(a)}\;\begin{bmatrix}1&-2\\-1&2\\0&3\end{bmatrix}\begin{pmatrix}3\\4\end{pmatrix}
\qquad
\text{(b)}\;\begin{bmatrix}2&-1&1\\1&0&3\end{bmatrix}\begin{pmatrix}2\\3\\1\end{pmatrix}
\qquad
\text{(c)}\;\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}\begin{pmatrix}r\\s\\t\end{pmatrix}
$$


::::solution[Solution]
**Answer:** (a) $(-5,5,12)^T$; (b) $(2,5)^T$; (c) $(r,s,t)^T$.

1. **(a)** Row by row: $1(3)+(-2)(4) = -5$; $\;-1(3)+2(4) = 5$; $\;0(3)+3(4) = 12$.

$$
\begin{pmatrix}-5\\5\\12\end{pmatrix}
$$

2. **(b)** $2(2)+(-1)(3)+1(1) = 2$; $\;1(2)+0(3)+3(1) = 5$.

$$
\begin{pmatrix}2\\5\end{pmatrix}
$$

3. **(c)** This is $I_3\mathbf{x}$, so the answer is $\mathbf{x}$ itself:
 $\begin{pmatrix}r\\s\\t\end{pmatrix}$. Worth doing once by hand to see why — row 1 is
 $\begin{bmatrix}1&0&0\end{bmatrix}$, whose dot product with $(r,s,t)^T$ picks out $r$ and
 discards the rest. Each row of $I_3$ selects exactly one entry.
::::
:::

:::problem[Problem 1.14 — Set up a matrix equation]{difficulty=easy}
Write the system $x_1 - 3x_2 = 7$, $2x_1 + x_2 = 4$ as a single matrix equation $A\mathbf{x}=\mathbf{b}$.


::::solution[Solution]
**Answer:** $\begin{bmatrix}1&-3\\2&1\end{bmatrix}\begin{pmatrix}x_1\\x_2\end{pmatrix} = \begin{pmatrix}7\\4\end{pmatrix}$

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. $\begin{bmatrix}1&-3\\2&1\end{bmatrix}\begin{pmatrix}x_1\\x_2\end{pmatrix} = \begin{pmatrix}7\\4\end{pmatrix}$

3. To check the construction, the first matrix row gives $1x_1+(-3)x_2=7$ and the second gives $2x_1+1x_2=4$. These are exactly the two original equations.
::::
:::

:::problem[Problem 1.15 — Test consistency]{difficulty=standard}
Let $A = \begin{bmatrix}1&3\\2&6\end{bmatrix}$. For which $\mathbf{b} = \begin{pmatrix}b_1\\b_2\end{pmatrix}$ is $A\mathbf{x}=\mathbf{b}$ consistent?


::::solution[Solution]
**Answer:** Consistent exactly when $b_2=2b_1$.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

$$
\left[\begin{array}{rr|r}1&3&b_1\\2&6&b_2\end{array}\right]\xrightarrow{R_2-2R_1}\left[\begin{array}{rr|r}1&3&b_1\\0&0&b_2-2b_1\end{array}\right]
$$

2. Consistent iff $b_2 - 2b_1 = 0$, i.e., $b_2 = 2b_1$. Geometrically: $\mathbf{b}$ must lie on the line spanned by the columns of $A$ (both columns are $k\cdot(1,2)^T$).
::::
:::

## 1.5 Solution Sets of Linear Systems

:::callout-intuition[Intuition first]
When you set the right-hand side $\mathbf{b} = \mathbf{0}$, you get a
 *homogeneous* system — one that always has at least the trivial solution
 $\mathbf{x} = \mathbf{0}$. Understanding homogeneous solutions is the key to
 understanding *all* solutions: the general solution of any consistent system
 is "one particular solution + all homogeneous solutions."
:::

:::definition[Definition 1.7 — Homogeneous System]
The system $A\mathbf{x} = \mathbf{0}$ is called **homogeneous**.
 It always has the **trivial solution** $\mathbf{x} = \mathbf{0}$.
 It has a nontrivial solution iff there is a free variable (iff at least one column of $A$ is not a pivot column).
:::

A homogeneous system can never be inconsistent — $\mathbf{x} = \mathbf{0}$ always works — so
 the existence question is settled before you start. **The only question about a homogeneous
 system is uniqueness**, and by the definition above that means: are there free variables?

:::definition[Definition 1.7a — Parametric Vector Form]
When a solution set is written as a linear combination of fixed vectors with the free
 variables as the parameters — as in $\mathbf{x} = s\mathbf{u} + t\mathbf{v}$, or
 $\mathbf{x} = \mathbf{p} + t\mathbf{v}$ — the solution is said to be in
 **parametric vector form**.
:::

:::example[Example 1.21 — A homogeneous solution set that is a line]
Solve $\;3x_1 + 5x_2 - 4x_3 = 0,\; -3x_1 - 2x_2 + 4x_3 = 0,\; 6x_1 + x_2 - 8x_3 = 0$.


::::answer[Answer]
**Answer:** $\mathbf{x} = t\begin{pmatrix}4/3\\0\\1\end{pmatrix}$, $\;t \in \mathbb{R}$ — a line through the origin.

1. $\mathbf{x} = t\begin{pmatrix}4/3\\0\\1\end{pmatrix}$, $\;t \in \mathbb{R}$ — a line through
 the origin.

2. The right-hand column is all zeros and stays that way through every row operation, so it
 carries no information — but keep writing it, because the moment you drop it you are
 reducing $A$ rather than $[A \mid \mathbf{0}]$ and the habit will cost you on a
 nonhomogeneous problem.

$$
\left[\begin{array}{rrr|r}3&5&-4&0\\-3&-2&4&0\\6&1&-8&0\end{array}\right]
\xrightarrow{R_2+R_1,\;R_3-2R_1}
\left[\begin{array}{rrr|r}3&5&-4&0\\0&3&0&0\\0&-9&0&0\end{array}\right]
\xrightarrow{R_3+3R_2}
\left[\begin{array}{rrr|r}3&5&-4&0\\0&3&0&0\\0&0&0&0\end{array}\right]
$$

3. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{\frac13R_2,\;R_1-5R_2,\;\frac13R_1}
\left[\begin{array}{rrr|r}1&0&-\frac43&0\\0&1&0&0\\0&0&0&0\end{array}\right]
\;\Longrightarrow\;
\begin{cases}x_1 - \tfrac43 x_3 = 0\\ x_2 = 0\\ 0 = 0\end{cases}
$$

4. Pivots in columns 1 and 2, so $x_3$ is free. Then $x_1 = \tfrac43 x_3$ and $x_2 = 0$:

$$
\mathbf{x} = \begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix} = \begin{pmatrix}\tfrac43 x_3\\0\\x_3\end{pmatrix}
= x_3\begin{pmatrix}\tfrac43\\0\\1\end{pmatrix}
$$

5. Writing $t$ for $x_3$: the solution set is $\text{Span}\{\mathbf{v}\}$ with
 $\mathbf{v} = (\tfrac43, 0, 1)^T$ — geometrically **a line through $\mathbf{0}$ and
 $\mathbf{v}$**. One free variable, one direction, a line.
::::
:::

:::example[Example 1.22 — A homogeneous solution set that is a plane]
Solve $\;x_1 - x_2 - x_3 = 0,\; 2x_1 - 2x_2 - 2x_3 = 0$.


::::answer[Answer]
**Answer:** $\mathbf{x} = s\begin{pmatrix}1\\1\\0\end{pmatrix} + t\begin{pmatrix}1\\0\\1\end{pmatrix}$, $\;s,t \in \mathbb{R}$ — a plane through the origin.

1. $\mathbf{x} = s\begin{pmatrix}1\\1\\0\end{pmatrix} + t\begin{pmatrix}1\\0\\1\end{pmatrix}$,
 $\;s,t \in \mathbb{R}$ — a plane through the origin.

2. The second equation is twice the first, so it vanishes:

$$
\left[\begin{array}{rrr|r}1&-1&-1&0\\2&-2&-2&0\end{array}\right]
\xrightarrow{R_2-2R_1}
\left[\begin{array}{rrr|r}1&-1&-1&0\\0&0&0&0\end{array}\right]
\;\Longrightarrow\; x_1 - x_2 - x_3 = 0
$$

3. One pivot, so $x_2$ and $x_3$ are both free and $x_1 = x_2 + x_3$. Now separate the two free
 variables — this is the step that produces parametric vector form:

$$
\mathbf{x} = \begin{pmatrix}x_2 + x_3\\x_2\\x_3\end{pmatrix}
= \begin{pmatrix}x_2\\x_2\\0\end{pmatrix} + \begin{pmatrix}x_3\\0\\x_3\end{pmatrix}
= x_2\begin{pmatrix}1\\1\\0\end{pmatrix} + x_3\begin{pmatrix}1\\0\\1\end{pmatrix}
$$

4. The solution set is $\text{Span}\{\mathbf{u}, \mathbf{v}\}$ — **a plane containing
 $\mathbf{0}$, $\mathbf{u}$ and $\mathbf{v}$**.

:::::callout-key[The pattern]
For a homogeneous system, the number of free variables *is* the dimension of the solution
 set: none gives the single point $\mathbf{0}$, one gives a line, two give a plane, $k$ gives
 a $k$-dimensional flat through the origin. And the solution set is always a span — which is
 why it always contains $\mathbf{0}$ and always passes through the origin.
:::::
::::
:::

:::theorem[Theorem 1.5 — Structure of the General Solution]
Suppose $A\mathbf{x} = \mathbf{b}$ is consistent and let $\mathbf{p}$ be
 any particular solution. Then the complete solution set is

$$
\{\mathbf{p} + \mathbf{v}_h \mid A\mathbf{v}_h = \mathbf{0}\},
$$

 i.e., every solution is a particular solution plus a solution of the associated homogeneous system.
:::

:::example[Example 1.23 — The same matrix, now with $\mathbf{b} \neq \mathbf{0}$]
Solve $A\mathbf{x} = \mathbf{b}$ for the **same $A$ as Example 1.21**, with
 $\mathbf{b} = (7, -1, -4)^T$:

$$
\begin{bmatrix}3&5&-4\\-3&-2&4\\6&1&-8\end{bmatrix}\begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix} = \begin{pmatrix}7\\-1\\-4\end{pmatrix}
$$


::::answer[Answer]
**Answer:** $\mathbf{x} = \begin{pmatrix}-1\\2\\0\end{pmatrix} + t\begin{pmatrix}4/3\\0\\1\end{pmatrix}$, $\;t \in \mathbb{R}$.

1. $\mathbf{x} = \begin{pmatrix}-1\\2\\0\end{pmatrix} + t\begin{pmatrix}4/3\\0\\1\end{pmatrix}$,
 $\;t \in \mathbb{R}$.

2. The left-hand side is identical to Example 1.21, so the row operations are identical too —
 only the augmented column differs:

$$
\left[\begin{array}{rrr|r}3&5&-4&7\\-3&-2&4&-1\\6&1&-8&-4\end{array}\right]
\xrightarrow{R_2+R_1,\;R_3-2R_1}
\left[\begin{array}{rrr|r}3&5&-4&7\\0&3&0&6\\0&-9&0&-18\end{array}\right]
\xrightarrow{R_3+3R_2}
\left[\begin{array}{rrr|r}3&5&-4&7\\0&3&0&6\\0&0&0&0\end{array}\right]
$$

3. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{\frac13R_2,\;R_1-5R_2,\;\frac13R_1}
\left[\begin{array}{rrr|r}1&0&-\frac43&-1\\0&1&0&2\\0&0&0&0\end{array}\right]
\;\Longrightarrow\;
\begin{cases}x_1 - \tfrac43x_3 = -1\\ x_2 = 2\\ 0 = 0\end{cases}
$$

4. The bottom row is $0 = 0$, not $0 = c$, so the system is consistent. $x_3$ is free:

$$
\mathbf{x} = \begin{pmatrix}-1 + \tfrac43 x_3\\2\\x_3\end{pmatrix}
= \underbrace{\begin{pmatrix}-1\\2\\0\end{pmatrix}}_{\mathbf{p}} + x_3\underbrace{\begin{pmatrix}\tfrac43\\0\\1\end{pmatrix}}_{\mathbf{v}}
$$

:::::callout-key[Compare this with Example 1.21]
The direction vector $\mathbf{v} = (\tfrac43, 0, 1)^T$ is **exactly the same** one that
 solved the homogeneous system. That is not a coincidence — it is Theorem 1.5 made visible.
 Changing $\mathbf{b}$ from $\mathbf{0}$ to $(7,-1,-4)^T$ did not change the *shape* of the
 solution set at all; it only moved it off the origin by $\mathbf{p}$.

$$
\underbrace{\mathbf{x} = t\mathbf{v}}_{\text{solves } A\mathbf{x}=\mathbf{0}}
\qquad\longrightarrow\qquad
\underbrace{\mathbf{x} = \mathbf{p} + t\mathbf{v}}_{\text{solves } A\mathbf{x}=\mathbf{b}}
$$
:::::
::::
:::

### The geometry of a solution set

Theorem 1.5 has a short geometric statement: **the solution set of $A\mathbf{x} = \mathbf{b}$
 is the solution set of $A\mathbf{x} = \mathbf{0}$, translated by any one particular
 solution $\mathbf{p}$.** Same shape, same direction vectors, shifted off the origin.

For $n = 3$:

| free variables | $A\mathbf{x} = \mathbf{0}$ | $A\mathbf{x} = \mathbf{b}$ (consistent) |
|---|---|---|
| none | the single point $\mathbf{0}$ | the single point $\mathbf{p}$ |
| one | a **line** through the origin | a **parallel line** through $\mathbf{p}$ |
| two | a **plane** through the origin | a **parallel plane** through $\mathbf{p}$ |

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 330 195" width="330" height="195"
     role="img" aria-label="The solution set of Ax equals b is the solution line of Ax equals zero shifted along p, running parallel to it">
<path class="fig-axis" d="M118 120L86.65 143.94M118 120L175 120M118 120L118 63"/>
<path class="fig-guide" d="M75.58 130.89L163.57 108.3"/>
<path class="fig-curve-alt" d="M88.1 92.28L176.09 69.69"/>
<path class="fig-curve" d="M118 120L128.98 86.15"/><polygon class="fig-arrow" points="130.53,81.39 130.98,86.79 126.98,85.5"/>
<circle class="fig-point" cx="130.53" cy="81.39" r="3.4"/>
<circle class="fig-point" cx="118" cy="120" r="3"/>
<text class="fig-label-em" x="117.53" y="78.39">p</text>
<text class="fig-label" x="107" y="131">0</text>
<text class="fig-label" x="169.57" y="120.3">Ax = 0</text>
<text class="fig-label-em" x="182.09" y="71.69">Ax = b</text>
<text class="fig-label" x="74.65" y="149.94">x&#8321;</text><text class="fig-label" x="179" y="124">x&#8322;</text><text class="fig-label" x="120" y="60">x&#8323;</text>
</svg>
<figcaption>One free variable: $A\mathbf{x}=\mathbf{0}$ is a line through the origin, and $A\mathbf{x}=\mathbf{b}$ is that same line moved along $\mathbf{p}$ — same direction, shifted off the origin.</figcaption>
</figure>

The homogeneous set always contains the origin; the nonhomogeneous set contains the origin
 only if $\mathbf{b} = \mathbf{0}$. This is why a span can never be the solution set of a
 consistent nonhomogeneous system — spans go through the origin, and $\mathbf{p} + t\mathbf{v}$
 generally does not.

Two consequences worth carrying:

- **$\mathbf{p}$ is not unique, but the set is.** Any solution can play the role of
  $\mathbf{p}$; picking a different one just relabels which point of the same line you
  started from. Two students can write the same solution set with different-looking
  $\mathbf{p}$ and both be right.
- **An inconsistent system has no geometry here at all.** Theorem 1.5 begins "suppose
  $A\mathbf{x} = \mathbf{b}$ is consistent". With no $\mathbf{p}$ there is nothing to
  translate, and the solution set is empty — not a shifted line, not a point.

:::example[Example 1.24 — Homogeneous system with free variables]
Find all solutions of $A\mathbf{x} = \mathbf{0}$ where
 $A = \begin{bmatrix}1&3&-2&0\\2&6&-4&0\\-1&-3&2&0\end{bmatrix}$.


::::answer[Answer]
**Answer:** $\mathbf{x} = s\begin{pmatrix}-3\\1\\0\\0\end{pmatrix} + t\begin{pmatrix}2\\0\\1\\0\end{pmatrix} + u\begin{pmatrix}0\\0\\0\\1\end{pmatrix}$, $\quad s,t,u \in \mathbb{R}$.

1. The augmented matrix (right side is all zeros — stays zero throughout row reduction):

$$
\left[\begin{array}{rrrr|r}1&3&-2&0&0\\2&6&-4&0&0\\-1&-3&2&0&0\end{array}\right]
      \xrightarrow{R_2-2R_1,\;R_3+R_1}
      \left[\begin{array}{rrrr|r}1&3&-2&0&0\\0&0&0&0&0\\0&0&0&0&0\end{array}\right]
$$

2. Only one pivot (column 1). Free variables: $x_2 = s$, $x_3 = t$, $x_4 = u$.

3. Row 1: $x_1 + 3x_2 - 2x_3 = 0 \;\Rightarrow\; x_1 = -3s + 2t$.

$$
\mathbf{x} = \begin{pmatrix}-3s+2t\\s\\t\\u\end{pmatrix} = s\begin{pmatrix}-3\\1\\0\\0\end{pmatrix}+t\begin{pmatrix}2\\0\\1\\0\end{pmatrix}+u\begin{pmatrix}0\\0\\0\\1\end{pmatrix}
$$
::::
:::

:::example[Example 1.25 — Nonhomogeneous: particular + homogeneous]
Express the general solution of
 $\left[\begin{array}{rrr|r}1&-3&4&7\\0&1&-2&-3\end{array}\right]$
 in the form $\mathbf{p} + t\mathbf{v}_h$.


::::answer[Answer]
**Answer:** $\mathbf{x} = \begin{pmatrix}-2\\-3\\0\end{pmatrix} + t\begin{pmatrix}2\\2\\1\end{pmatrix}$, $\; t \in \mathbb{R}$.

1. Back-substitute: $R_1 \leftarrow R_1 + 3R_2$:

$$
\left[\begin{array}{rrr|r}1&0&-2&-2\\0&1&-2&-3\end{array}\right]
$$

2. Free variable: $x_3 = t$. Basic: $x_2 = -3 + 2t$, $x_1 = -2 + 2t$.

$$
\mathbf{x} = \begin{pmatrix}-2+2t\\-3+2t\\t\end{pmatrix} = \underbrace{\begin{pmatrix}-2\\-3\\0\end{pmatrix}}_{\mathbf{p}} + t\underbrace{\begin{pmatrix}2\\2\\1\end{pmatrix}}_{\mathbf{v}_h}
$$

3. Verify $A\mathbf{p} = \mathbf{b}$: $1(-2)-3(-3)+4(0) = -2+9 = 7\,\checkmark$.
::::
:::

:::callout-pitfall[Watch out for]
- **Adding homogeneous solutions to an inconsistent system.** Theorem 1.5 only applies when the system *is* consistent. If $A\mathbf{x}=\mathbf{b}$ has no solution, there is no $\mathbf{p}$ to start from.
- **Thinking the trivial solution is the only homogeneous solution.** If there are $k$ free variables, there are $k$ independent directions in the homogeneous solution set.
:::

### The procedure, start to finish

Every solution-set problem in this section is the same four steps. Once you have checked the
 system is consistent:

1. **Row reduce the augmented matrix to reduced echelon form.** RREF, not just REF — the
   later steps read coefficients directly off the rows, and that only works once each pivot
   is a $1$ alone in its column.
2. **Express each basic variable in terms of the free variables**, one equation at a time.
   Every nonzero row gives you exactly one basic variable.
3. **Write a typical solution $\mathbf{x}$ as a vector** whose entries are those expressions,
   with each free variable standing for itself.
4. **Decompose $\mathbf{x}$ into a linear combination**, splitting off a constant vector and
   one vector per free variable. The result is parametric vector form.

Step 4 is the one that gets skipped, and it is where the geometry lives. Stopping at step 3
 leaves you with a correct answer that shows nothing; carrying out the split turns it into
 $\mathbf{p} + s\mathbf{u} + t\mathbf{v}$, where you can immediately read off a point on the
 set and the directions it runs in.

Two checks worth making before you move on. The number of vectors attached to parameters
 should equal the number of free variables — if you have two free variables and one
 direction vector, an entry has been dropped. And for a homogeneous system there is no
 constant vector at all: if a $\mathbf{p}$ appears when $\mathbf{b} = \mathbf{0}$, something
 has gone wrong, because $\mathbf{x} = \mathbf{0}$ must be in the set.

### Practice problems

:::problem[Problem 1.16 — Determine the solution set]{difficulty=easy}
Does $A\mathbf{x}=\mathbf{0}$ always have at least one solution? If so, what is it?


::::solution[Solution]
**Answer:** Yes — always. The **trivial solution** $\mathbf{x} = \mathbf{0}$ satisfies $A\mathbf{0} = \mathbf{0}$ for any matrix $A$.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

2. Yes — always. The **trivial solution** $\mathbf{x} = \mathbf{0}$ satisfies $A\mathbf{0} = \mathbf{0}$ for any matrix $A$.

3. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.
::::
:::

:::problem[Problem 1.17 — Determine the solution set]{difficulty=standard}
Find the solution set of $A\mathbf{x}=\mathbf{0}$ for $A = \begin{bmatrix}1&-2&3\\-2&4&-6\end{bmatrix}$.


::::solution[Solution]
**Answer:** $\mathbf x=s(2,1,0)^T+t(-3,0,1)^T$ for $s,t\in\mathbb R$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

$$
\left[\begin{array}{rrr|r}1&-2&3&0\\-2&4&-6&0\end{array}\right]\xrightarrow{R_2+2R_1}\left[\begin{array}{rrr|r}1&-2&3&0\\0&0&0&0\end{array}\right]
$$

2. Free variables: $x_2=s$, $x_3=t$. Then $x_1=2s-3t$.

$$
\mathbf{x}=s\begin{pmatrix}2\\1\\0\end{pmatrix}+t\begin{pmatrix}-3\\0\\1\end{pmatrix}
$$
::::
:::

:::problem[Problem 1.18 — Compute the vector result]{difficulty=challenge}
Suppose $\mathbf{p}_1$ and $\mathbf{p}_2$ are both solutions of $A\mathbf{x}=\mathbf{b}$.
 Show that $\mathbf{p}_1 - \mathbf{p}_2$ is a solution of $A\mathbf{x}=\mathbf{0}$.


::::solution[Solution]
**Answer:** $A(\mathbf p_1-\mathbf p_2)=\mathbf0$; the difference is in $\Nul A$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Compute: $A(\mathbf{p}_1 - \mathbf{p}_2) = A\mathbf{p}_1 - A\mathbf{p}_2 = \mathbf{b} - \mathbf{b} = \mathbf{0}$. So $\mathbf{p}_1 - \mathbf{p}_2$ is a homogeneous solution. This confirms that the difference of any two particular solutions is always in the null space of $A$.
::::
:::

## 1.7 Linear Independence

:::callout-intuition[Intuition first]
A set of vectors is *linearly independent* if no vector in the set can be built
 from the others. In other words, none of them is "redundant." Redundancy is bad: it
 means some directions in your span are covered multiple times, leading to infinitely many
 ways to express the same vector — and, as we'll see later, matrices with redundant columns
 are the singular (non-invertible) ones.
:::

:::definition[Definition 1.8 — Linear Independence]
Vectors $\mathbf{v}_1, \ldots, \mathbf{v}_p$ are **linearly independent** if
 the only solution to

$$
c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + \cdots + c_p\mathbf{v}_p = \mathbf{0}
$$

 is $c_1 = c_2 = \cdots = c_p = 0$ (the trivial solution).
 They are **linearly dependent** if there exists a nontrivial solution
 (at least one $c_i \neq 0$).
:::

:::theorem[Theorem 1.6 — Independence Test by Row Reduction]
Form the matrix $A = [\mathbf{v}_1 \cdots \mathbf{v}_p]$. The vectors are linearly
 independent iff $A\mathbf{x}=\mathbf{0}$ has only the trivial solution, i.e., iff
 every column of $A$ is a pivot column (no free variables).
:::

:::theorem[Theorem 1.7 — Too Many Vectors]
Any set of more than $n$ vectors in $\mathbb{R}^n$ is automatically linearly dependent.
 (You can't have more independent directions than the dimension of the space.)
:::

:::example[Example 1.26 — Testing independence]
Are $\mathbf{v}_1 = \begin{pmatrix}1\\2\\3\end{pmatrix}$,
 $\mathbf{v}_2 = \begin{pmatrix}4\\5\\6\end{pmatrix}$,
 $\mathbf{v}_3 = \begin{pmatrix}2\\1\\0\end{pmatrix}$ linearly independent?


::::answer[Answer]
**Answer:** Linearly dependent: $2\mathbf v_1-\mathbf v_2+\mathbf v_3=\mathbf0$.

1. **Linearly dependent.** $2\mathbf{v}_1 - \mathbf{v}_3 = \begin{pmatrix}0\\3\\6\end{pmatrix}\neq\mathbf{v}_2$, so let's do the algebra.

$$
\left[\begin{array}{rrr|r}1&4&2&0\\2&5&1&0\\3&6&0&0\end{array}\right]
      \xrightarrow{R_2-2R_1,\;R_3-3R_1}
      \left[\begin{array}{rrr|r}1&4&2&0\\0&-3&-3&0\\0&-6&-6&0\end{array}\right]
$$

2. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{R_3-2R_2}
      \left[\begin{array}{rrr|r}1&4&2&0\\0&-3&-3&0\\0&0&0&0\end{array}\right]
$$

3. The third column is not a pivot column (free variable $x_3$), so the system has nontrivial solutions.
 The vectors are **linearly dependent**. Setting $x_3 = 3$: $-3x_2 = 9 \Rightarrow x_2 = -3$,
 $x_1 = -4(x_2) - 2x_3 = 12 - 6 = 6$.
 Check: $6\mathbf{v}_1 - 3\mathbf{v}_2 + 3\mathbf{v}_3 = (6-12+6, 12-15+3, 18-18+0)^T = \mathbf{0}\,\checkmark$.
::::
:::

:::callout-pitfall[Watch out for]
- **The zero vector always creates dependence.** If any $\mathbf{v}_i = \mathbf{0}$, the set is immediately linearly dependent (set $c_i = 1$, all others 0).
- **Two vectors: check for proportionality.** $\{\mathbf{u},\mathbf{v}\}$ is dependent iff $\mathbf{u} = k\mathbf{v}$ for some scalar $k$.
- **Independence is about the set, not individual vectors.** Each individual nonzero vector is "independent" on its own; dependence only makes sense for a *set* of two or more.
:::

### Dependence relations and free variables

:::definition[Definition 1.8A — Linear Dependence Relation]
If scalars $c_1,\ldots,c_p$, not all zero, satisfy

$$
c_1\mathbf{v}_1+c_2\mathbf{v}_2+\cdots+c_p\mathbf{v}_p=\mathbf{0},
$$

then this equation is a **linear dependence relation** among the vectors. Row reduction does more than answer yes or no: each free variable in the homogeneous system gives a way to produce such a relation.
:::

:::example[Example 1.27 — Producing a dependence relation]
Let

$$
\mathbf{v}_1=\begin{bmatrix}3\\2\\-4\end{bmatrix},\qquad
\mathbf{v}_2=\begin{bmatrix}-6\\1\\7\end{bmatrix},\qquad
\mathbf{v}_3=\begin{bmatrix}0\\-5\\1\end{bmatrix}.
$$

Determine whether the set is linearly independent and, if possible, find a dependence relation.


::::answer[Answer]
**Answer:** **The set is linearly dependent, and one relation is $2\mathbf{v}_1+\mathbf{v}_2+\mathbf{v}_3=\mathbf{0}$.**

1. Consider $x_1\mathbf{v}_1+x_2\mathbf{v}_2+x_3\mathbf{v}_3=\mathbf{0}$:

$$
\begin{bmatrix}3&-6&0&0\\2&1&-5&0\\-4&7&1&0\end{bmatrix}
\sim
\begin{bmatrix}1&0&-2&0\\0&1&-1&0\\0&0&0&0\end{bmatrix}.
$$

2. Thus $x_1$ and $x_2$ are basic, $x_3$ is free, and
$x_1=2x_3$, $x_2=x_3$. Choosing the convenient value $x_3=1$ gives
$x_1=2$ and $x_2=1$, hence

$$
2\mathbf{v}_1+\mathbf{v}_2+\mathbf{v}_3=\mathbf{0}.
$$

3. The free variable is exactly what makes a nontrivial relation possible.
::::
:::

:::theorem[Theorem 1.6A — Independence of Matrix Columns]
For $A=[\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_p]$, the columns of $A$ are linearly independent if and only if $A\mathbf{x}=\mathbf{0}$ has only the trivial solution.
:::

:::proof[Proof]
The matrix equation is the vector equation

$$
A\mathbf{x}=x_1\mathbf{a}_1+x_2\mathbf{a}_2+\cdots+x_p\mathbf{a}_p=\mathbf{0}.
$$

Saying that its only solution is $x_1=\cdots=x_p=0$ is precisely the definition that the columns are linearly independent.
:::

:::example[Example 1.28 — Independent columns]
Let

$$
A=\begin{bmatrix}3&-6&0\\2&1&5\\-4&7&2\end{bmatrix}.
$$


::::answer[Answer]
**Answer:** **The columns of $A$ are linearly independent.**

1. Row-reduce the homogeneous system:

$$
\begin{bmatrix}3&-6&0&0\\2&1&5&0\\-4&7&2&0\end{bmatrix}
\sim
\begin{bmatrix}1&-2&0&0\\0&1&1&0\\0&0&1&0\end{bmatrix}.
$$

2. There is a pivot in every variable column, so there are no free variables. Therefore $A\mathbf{x}=\mathbf{0}$ has only the trivial solution, and the columns are linearly independent.
::::
:::

### Sets of one or two vectors

For a one-vector set $\{\mathbf{v}\}$, the relevant equation is $a\mathbf{v}=\mathbf{0}$. If $\mathbf{v}\neq\mathbf{0}$, then $a=0$, so the set is linearly independent. If $\mathbf{v}=\mathbf{0}$, every scalar $a$ works, so the set is linearly dependent. Therefore a one-vector set is linearly independent exactly when its vector is nonzero.

For a two-vector set, if $\mathbf{v}_1=c\mathbf{v}_2$, then
$\mathbf{v}_1-c\mathbf{v}_2=\mathbf{0}$ is a nontrivial dependence relation. The same argument works if $\mathbf{v}_2$ is a multiple of $\mathbf{v}_1$. Conversely, if neither vector is a scalar multiple of the other, the equation
$x_1\mathbf{v}_1+x_2\mathbf{v}_2=\mathbf{0}$ forces $x_1=x_2=0$.

:::callout-key[One- and two-vector tests]
- A set containing one vector is linearly independent if and only if that vector is not the zero vector.
- A set containing two vectors is linearly independent if and only if neither vector is a scalar multiple of the other.
- Geometrically, two vectors are linearly dependent if and only if they lie on the same line through the origin.
:::

### When one vector is built from the others

:::theorem[Theorem 1.7A — Characterization of Linear Dependence]
A set of two or more vectors $\{\mathbf{v}_1,\ldots,\mathbf{v}_p\}$ is linearly dependent if and only if at least one vector in the set is a linear combination of the others.
:::

:::proof[Proof]
First suppose the set is linearly dependent. Then there are scalars $c_1,\ldots,c_p$, not all zero, such that

$$
c_1\mathbf{v}_1+\cdots+c_p\mathbf{v}_p=\mathbf{0}.
$$

At least one coefficient is nonzero. Relabel if necessary so that $c_1\neq0$. Solving for $\mathbf{v}_1$ gives

$$
\mathbf{v}_1=-\frac{c_2}{c_1}\mathbf{v}_2-\cdots-\frac{c_p}{c_1}\mathbf{v}_p,
$$

so $\mathbf{v}_1$ is a linear combination of the other vectors.

Conversely, suppose one vector is a linear combination of the others, say

$$
\mathbf{v}_1=c_2\mathbf{v}_2+\cdots+c_p\mathbf{v}_p.
$$

Moving every term to the left produces

$$
1\mathbf{v}_1-c_2\mathbf{v}_2-\cdots-c_p\mathbf{v}_p=\mathbf{0}.
$$

The coefficient of $\mathbf{v}_1$ is $1$, so the coefficients are not all zero. This is a nontrivial dependence relation; hence the set is linearly dependent.
:::

:::example[Example 1.29 — A plane spanned by two independent vectors]

::::answer[Answer]
**Answer:** $\operatorname{Span}\{\mathbf{u},\mathbf{v}\}$ is the $x_2x_3$-plane, and the two vectors are linearly independent.

1. Let

$$
\mathbf{u}=\begin{bmatrix}0\\1\\2\end{bmatrix},\qquad
\mathbf{v}=\begin{bmatrix}0\\2\\1\end{bmatrix}.
$$

2. Neither vector is a scalar multiple of the other, so they are linearly independent. Both have first coordinate zero, and their last two coordinates form an independent pair, so

$$
\operatorname{Span}\{\mathbf{u},\mathbf{v}\}=\text{the }x_2x_3\text{-plane}.
$$

3. For any $\mathbf{w}$ in this plane,

$$
\mathbf{w}\in\operatorname{Span}\{\mathbf{u},\mathbf{v}\}
\quad\Longleftrightarrow\quad
\mathbf{w},\mathbf{u},\mathbf{v}\text{ are linearly dependent}.
$$
::::
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 240 180" role="img" aria-label="The vectors u and v drawn in the x2 x3 plane">
<path class="fig-fill" d="M48 142 L122 42 L210 72 L136 170 Z"/>
<path class="fig-axis" d="M38 150 L215 150 M56 168 L56 25 M56 150 L214 66"/>
<path class="fig-arrow" d="M56 150 L108 76 M108 76 L102 88 M108 76 L95 80"/>
<path class="fig-arrow" d="M56 150 L162 103 M162 103 L150 102 M162 103 L154 112"/>
<text class="fig-label" x="216" y="156">x₂</text>
<text class="fig-label" x="45" y="24">x₃</text>
<text class="fig-label" x="212" y="65">x₁</text>
<text class="fig-label-em" x="101" y="69">u</text>
<text class="fig-label-em" x="166" y="100">v</text>
</svg>
<figcaption>The independent vectors $\mathbf{u}$ and $\mathbf{v}$ lie in, and span, the entire $x_2x_3$-plane.</figcaption>
</figure>

:::theorem[Theorem 1.7B — More Vectors Than Entries]
Any set $\{\mathbf{v}_1,\ldots,\mathbf{v}_p\}$ in $\mathbb{R}^n$ is linearly dependent if $p>n$.
:::

:::proof[Proof]
Let $A=[\mathbf{v}_1\ \cdots\ \mathbf{v}_p]$. Then $A$ is an $n\times p$ matrix, so the homogeneous system $A\mathbf{x}=\mathbf{0}$ has $n$ equations and $p$ unknowns. If $p>n$, there cannot be a pivot in every one of the $p$ columns. At least one variable is free, so the homogeneous system has a nontrivial solution. Therefore the columns of $A$ are linearly dependent.
:::

For example,

$$
\left\{\begin{bmatrix}1\\2\end{bmatrix},
\begin{bmatrix}2\\0\end{bmatrix},
\begin{bmatrix}3\\1\end{bmatrix}\right\}
$$

is linearly dependent because it contains three vectors in $\mathbb{R}^2$.

:::theorem[Theorem 1.7C — A Set Containing the Zero Vector]
If a set $\{\mathbf{v}_1,\ldots,\mathbf{v}_p\}$ contains the zero vector, then the set is linearly dependent.
:::

:::proof[Proof]
Suppose $\mathbf{v}_1=\mathbf{0}$. Then

$$
1\mathbf{v}_1+0\mathbf{v}_2+\cdots+0\mathbf{v}_p=\mathbf{0}.
$$

Because the coefficient $1$ is nonzero, this is a nontrivial dependence relation. Hence the set is linearly dependent.
:::

### Practice problems

:::problem[Problem 1.19 — Test independence]{difficulty=easy}
By inspection (no computation), are $\begin{pmatrix}2\\-1\end{pmatrix}$ and $\begin{pmatrix}-4\\2\end{pmatrix}$ linearly independent?


::::solution[Solution]
**Answer:** **Linearly dependent.** $\begin{pmatrix}-4\\2\end{pmatrix} = -2\begin{pmatrix}2\\-1\end{pmatrix}$ — one is a scalar multiple of the other.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. **Linearly dependent.** $\begin{pmatrix}-4\\2\end{pmatrix} = -2\begin{pmatrix}2\\-1\end{pmatrix}$ — one is a scalar multiple of the other.
::::
:::

:::problem[Problem 1.20 — Test independence]{difficulty=standard}
Determine if $\begin{pmatrix}1\\0\\0\end{pmatrix}, \begin{pmatrix}0\\2\\0\end{pmatrix}, \begin{pmatrix}0\\0\\-3\end{pmatrix}$ are linearly independent.


::::solution[Solution]
**Answer:** Yes, the three vectors are linearly independent.

1. Form the matrix $A$ with these as columns. It is diagonal with nonzero diagonal entries. Row-reducing gives $I_3$: all columns are pivots, no free variables.

2. **Linearly independent.** (Any three standard-axis-pointing vectors with nonzero lengths are independent.)

3. Check the result against the definition: an affirmative subspace claim must include the zero vector, sums and scalar multiples; one counterexample suffices for a negative claim.
::::
:::

:::problem[Problem 1.21 — Test independence]{difficulty=challenge}
Suppose $\{\mathbf{v}_1, \mathbf{v}_2, \mathbf{v}_3\}$ is linearly independent. Prove that $\{\mathbf{v}_1, \mathbf{v}_2\}$ is also linearly independent.


::::solution[Solution]
**Answer:** Yes, every subset of an independent set is independent.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. Suppose for contradiction that $\{\mathbf{v}_1,\mathbf{v}_2\}$ is linearly dependent. Then there exist $c_1, c_2$ not both zero with $c_1\mathbf{v}_1 + c_2\mathbf{v}_2 = \mathbf{0}$. But then $c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + 0\cdot\mathbf{v}_3 = \mathbf{0}$ is a nontrivial solution for the larger set, contradicting independence of $\{\mathbf{v}_1,\mathbf{v}_2,\mathbf{v}_3\}$. $\square$
::::
:::

:::problem[Problem 1.22 — One-vector test]{difficulty=easy}
Determine whether $\left\{\begin{bmatrix}0\\0\\0\end{bmatrix}\right\}$ is linearly independent, and exhibit a dependence relation if it is not.


::::solution[Solution]
**Answer:** The set $\{\mathbf0\}$ is dependent: $1\cdot(0,0,0)^T=\mathbf0$ is a nontrivial relation.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. **The set is linearly dependent.** The relation

$$
1\begin{bmatrix}0\\0\\0\end{bmatrix}=\mathbf{0}
$$

3. has a nonzero coefficient.
::::
:::

:::problem[Problem 1.23 — Two-vector geometry]{difficulty=easy}
Are $\mathbf{u}=\begin{bmatrix}3\\-6\end{bmatrix}$ and $\mathbf{v}=\begin{bmatrix}-1\\2\end{bmatrix}$ linearly independent? Interpret the result geometrically.


::::solution[Solution]
**Answer:** Because $\mathbf{u}=-3\mathbf{v}$, the relation $\mathbf{u}+3\mathbf{v}=\mathbf{0}$ is nontrivial. The vectors are **linearly dependent**, and they lie on the same line through the origin.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. Because $\mathbf{u}=-3\mathbf{v}$, the relation $\mathbf{u}+3\mathbf{v}=\mathbf{0}$ is nontrivial. The vectors are **linearly dependent**, and they lie on the same line through the origin.
::::
:::

:::problem[Problem 1.24 — Relation from a free variable]{difficulty=standard}
For

$$
A=\begin{bmatrix}1&2&-1\\2&4&-2\\0&1&3\end{bmatrix},
$$

find a nontrivial relation among the columns.


::::solution[Solution]
**Answer:** Dependent: $7\mathbf a_1-3\mathbf a_2+\mathbf a_3=\mathbf0$.

1. The homogeneous equations reduce to $x_2+3x_3=0$ and $x_1+2x_2-x_3=0$. Let $x_3=1$. Then $x_2=-3$ and $x_1=7$. Therefore, if the columns are $\mathbf{a}_1,\mathbf{a}_2,\mathbf{a}_3$,

$$
7\mathbf{a}_1-3\mathbf{a}_2+\mathbf{a}_3=\mathbf{0}.
$$

2. Directly, $7(1,2,0)^T-3(2,4,1)^T+(-1,-2,3)^T=(0,0,0)^T$.

3. The coefficients $7,-3,1$ are not all zero. That matters because only a nontrivial solution to $A\mathbf x=\mathbf0$ proves the three columns linearly dependent.
::::
:::

:::problem[Problem 1.25 — More vectors than entries]{difficulty=easy}
Without row reduction, decide whether five vectors in $\mathbb{R}^4$ can be linearly independent.


::::solution[Solution]
**Answer:** No; five vectors in $\mathbb R^4$ are necessarily dependent.

1. Count independent pivot columns and choose each remaining coordinate as a free parameter. For a basis, verify both spanning and independence in the specified ambient space.

2. **No.** A set of $p=5$ vectors in $\mathbb{R}^n$ with $n=4$ has $p>n$, so it is automatically linearly dependent.
::::
:::

:::problem[Problem 1.26 — Combination of the others]{difficulty=standard}
Suppose $\mathbf{v}_4=2\mathbf{v}_1-\mathbf{v}_2+5\mathbf{v}_3$. Write a dependence relation for $\{\mathbf{v}_1,\mathbf{v}_2,\mathbf{v}_3,\mathbf{v}_4\}$.


::::solution[Solution]
**Answer:** $2\mathbf v_1-\mathbf v_2+5\mathbf v_3-\mathbf v_4=\mathbf0$.

1. Use the specific relation in the question to construct a candidate result, then substitute the candidate into that relation to verify it.

2. Move every term to one side:

$$
2\mathbf{v}_1-\mathbf{v}_2+5\mathbf{v}_3-\mathbf{v}_4=\mathbf{0}.
$$

3. The coefficients are not all zero, so this is a linear dependence relation.
::::
:::

:::problem[Problem 1.27 — Span and dependence]{difficulty=challenge}
Let $\mathbf{u}=\begin{bmatrix}0\\1\\2\end{bmatrix}$ and $\mathbf{v}=\begin{bmatrix}0\\2\\1\end{bmatrix}$. Determine whether $\mathbf{w}=\begin{bmatrix}0\\5\\4\end{bmatrix}$ lies in their span and give the resulting dependence relation among $\mathbf{w},\mathbf{u},\mathbf{v}$.


::::solution[Solution]
**Answer:** $\mathbf w=\mathbf u+2\mathbf v$; the three vectors are dependent.

1. Solve $a\mathbf{u}+b\mathbf{v}=\mathbf{w}$. The last two coordinates give

$$
a+2b=5,\qquad 2a+b=4.
$$

2. From $a=5-2b$, the second equation gives $10-4b+b=4$, so $b=2$ and $a=1$. Thus

$$
\mathbf{w}=\mathbf{u}+2\mathbf{v},
\qquad
\mathbf{w}-\mathbf{u}-2\mathbf{v}=\mathbf{0}.
$$

3. Therefore $\mathbf{w}$ lies in the span, and the three vectors are linearly dependent.
::::
:::

## 1.8 Linear Transformations

:::callout-intuition[Intuition first]
A *transformation* is just a function from vectors to vectors: you put a vector in,
 you get a vector out. A *linear* transformation is one that respects addition and
 scaling — if you scale the input, the output scales the same way; if you add two inputs,
 the output is the sum of the individual outputs. Rotations, reflections, projections,
 and stretches are all linear. Translations (shifting) are not.
:::

:::definition[Definition 1.9 — Linear Transformation]
A **transformation** (or function) $T: \mathbb{R}^n \to \mathbb{R}^m$ is
 **linear** if for all $\mathbf{u}, \mathbf{v} \in \mathbb{R}^n$ and
 scalars $c$:

1. $T(\mathbf{u} + \mathbf{v}) = T(\mathbf{u}) + T(\mathbf{v})$ (additivity)
2. $T(c\mathbf{u}) = cT(\mathbf{u})$ (homogeneity)

Equivalently: $T(c\mathbf{u} + d\mathbf{v}) = cT(\mathbf{u}) + dT(\mathbf{v})$ for all scalars $c, d$.
:::

:::callout-key[Key consequence]
Every linear transformation satisfies $T(\mathbf{0}) = \mathbf{0}$.
 (Set $c = 0$ in property 2.) So if a function moves the origin, it is *not* linear.
:::

:::example[Example 1.30 — Verifying linearity]
Let $T: \mathbb{R}^2 \to \mathbb{R}^2$ be defined by $T\begin{pmatrix}x_1\\x_2\end{pmatrix} = \begin{pmatrix}3x_1\\x_1-x_2\end{pmatrix}$.
 Is $T$ linear?


::::answer[Answer]
**Answer:** Yes, $T$ is linear.

1. Let $\mathbf{u}=\begin{pmatrix}u_1\\u_2\end{pmatrix}$, $\mathbf{v}=\begin{pmatrix}v_1\\v_2\end{pmatrix}$, $c \in \mathbb{R}$.

2. Additivity: $T(\mathbf{u}+\mathbf{v}) = T\begin{pmatrix}u_1+v_1\\u_2+v_2\end{pmatrix} = \begin{pmatrix}3(u_1+v_1)\\(u_1+v_1)-(u_2+v_2)\end{pmatrix} = \begin{pmatrix}3u_1\\u_1-u_2\end{pmatrix}+\begin{pmatrix}3v_1\\v_1-v_2\end{pmatrix} = T(\mathbf{u})+T(\mathbf{v})$. \checkmark\)

3. Homogeneity: $T(c\mathbf{u}) = \begin{pmatrix}3cu_1\\cu_1-cu_2\end{pmatrix} = c\begin{pmatrix}3u_1\\u_1-u_2\end{pmatrix} = cT(\mathbf{u})$. \checkmark\)
::::
:::

:::example[Example 1.31 — A non-linear transformation]
Is $T\begin{pmatrix}x_1\\x_2\end{pmatrix} = \begin{pmatrix}x_1 + 1 \\ x_2\end{pmatrix}$ linear?


::::answer[Answer]
**Answer:** No — it fails $T(\mathbf{0}) = \mathbf{0}$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. $T\begin{pmatrix}0\\0\end{pmatrix} = \begin{pmatrix}1\\0\end{pmatrix} \neq \begin{pmatrix}0\\0\end{pmatrix}$. Done — $T$ shifts the origin, so it cannot be linear. (This is a *translation*, not a linear map.)
::::
:::

:::callout-pitfall[Watch out for]
- **Translations are NOT linear.** $T(\mathbf{x}) = A\mathbf{x} + \mathbf{b}$ with $\mathbf{b}\neq\mathbf{0}$ is called an *affine* map, not linear.
- **$T(\mathbf{x}) = x_1 x_2$ is NOT linear.** Anything with products of variables breaks homogeneity.
- **Checking one property isn't enough.** You must verify both additivity and homogeneity (or disprove either one).
:::

### Transformations, domains, codomains, and ranges

Start with the matrix

$$
A=\begin{bmatrix}2&3&1\\0&1&2\end{bmatrix}.
$$

It sends two different vectors in $\mathbb{R}^3$ to two vectors in $\mathbb{R}^2$:

$$
A\begin{bmatrix}1\\-1\\2\end{bmatrix}=\begin{bmatrix}1\\3\end{bmatrix},
\qquad
A\begin{bmatrix}0\\1\\2\end{bmatrix}=\begin{bmatrix}5\\5\end{bmatrix}.
$$

:::definition[Definition 1.9A — Transformation, Domain, Codomain, and Range]
A **transformation**, also called a **function** or **mapping**, from $\mathbb{R}^n$ to $\mathbb{R}^m$ is a rule that assigns to every vector $\mathbf{x}\in\mathbb{R}^n$ exactly one vector $T(\mathbf{x})\in\mathbb{R}^m$.

The input space $\mathbb{R}^n$ is the **domain**. The declared output space $\mathbb{R}^m$ is the **codomain**. The **range** is the set of outputs the transformation actually produces; it may fill the codomain or may be only part of it.
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 300 150" role="img" aria-label="A transformation sends vectors u and v from R3 to vectors b and c inside the range in R2">
<path class="fig-fill" d="M18 24 C4 54 9 115 50 130 C92 145 126 116 123 68 C121 30 82 10 18 24 Z"/>
<path class="fig-fill-alt" d="M181 21 C153 48 160 116 205 133 C260 151 297 112 289 59 C283 20 224 5 181 21 Z"/>
<path class="fig-guide" d="M203 48 C183 67 190 105 220 114 C255 124 275 99 269 70 C264 45 230 35 203 48 Z"/>
<path class="fig-arrow" d="M117 67 C139 52 158 52 181 66 M181 66 L170 60 M181 66 L171 72"/>
<circle class="fig-point" cx="44" cy="62" r="4"/>
<circle class="fig-point" cx="83" cy="98" r="4"/>
<circle class="fig-point" cx="219" cy="65" r="4"/>
<circle class="fig-point" cx="244" cy="91" r="4"/>
<text class="fig-label" x="45" y="18">domain R³</text>
<text class="fig-label" x="207" y="18">codomain R²</text>
<text class="fig-label-em" x="39" y="57">u</text>
<text class="fig-label-em" x="87" y="104">v</text>
<text class="fig-label-em" x="210" y="61">b</text>
<text class="fig-label-em" x="249" y="96">c</text>
<text class="fig-label" x="213" y="120">range</text>
<text class="fig-label-em" x="143" y="47">T</text>
</svg>
<figcaption>A transformation assigns each vector in its domain one output in the codomain; the outputs actually reached form the range.</figcaption>
</figure>

:::definition[Definition 1.9B — Matrix Transformation]
Let $A$ be an $m\times n$ matrix. The rule

$$
T(\mathbf{x})=A\mathbf{x},\qquad \mathbf{x}\in\mathbb{R}^n,
$$

defines a **matrix transformation** $T:\mathbb{R}^n\to\mathbb{R}^m$. It is also written $\mathbf{x}\mapsto A\mathbf{x}$. The number of columns of $A$ determines the domain, and the number of rows determines the codomain.
:::

:::example[Example 1.32 — Images, existence, and uniqueness]
Let

$$
A=\begin{bmatrix}1&-3\\3&5\\-1&7\end{bmatrix},\quad
\mathbf{u}=\begin{bmatrix}1\\-3\end{bmatrix},\quad
\mathbf{b}=\begin{bmatrix}3\\2\\-5\end{bmatrix},\quad
\mathbf{c}=\begin{bmatrix}3\\2\\5\end{bmatrix},
$$

and define $T:\mathbb{R}^2\to\mathbb{R}^3$ by $T(\mathbf{x})=A\mathbf{x}$. Find $T(\mathbf{u})$; solve $T(\mathbf{x})=\mathbf{b}$ and decide whether the solution is unique; then decide whether $T(\mathbf{x})=\mathbf{c}$ is solvable.


::::answer[Answer]
**Answer:** $T(\mathbf{u})=(10,-12,-22)^T$. The equation $T(\mathbf{x})=\mathbf{b}$ has the unique solution $\mathbf{x}=(3/2,-1/2)^T$. The equation $T(\mathbf{x})=\mathbf{c}$ has no solution.

1. First,

$$
T(\mathbf{u})=
\begin{bmatrix}1&-3\\3&5\\-1&7\end{bmatrix}
\begin{bmatrix}1\\-3\end{bmatrix}
=\begin{bmatrix}10\\-12\\-22\end{bmatrix}.
$$

2. For $\mathbf{b}$, row reduction gives

$$
\begin{bmatrix}1&-3&3\\3&5&2\\-1&7&-5\end{bmatrix}
\sim
\begin{bmatrix}1&0&\tfrac32\\0&1&-\tfrac12\\0&0&0\end{bmatrix}.
$$

3. Thus $\mathbf{x}=(3/2,-1/2)^T$, and because both variables are basic this solution is unique. This is a uniqueness question.

4. For $\mathbf{c}$,

$$
\begin{bmatrix}1&-3&3\\3&5&2\\-1&7&5\end{bmatrix}
\sim
\begin{bmatrix}1&-3&3\\0&1&2\\0&0&1\end{bmatrix}.
$$

5. The last row represents $0=1$, so there is no solution. Hence $\mathbf{c}$ is not in the range of $T$. This is an existence question.
::::
:::

### Projection onto the $x_2x_3$-plane

:::example[Example 1.33 — A coordinate-plane projection]

::::answer[Answer]
**Answer:** $P(x_1,x_2,x_3)^T=(0,x_2,x_3)^T$; projection onto the $x_2x_3$-plane.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. Let

$$
P=\begin{bmatrix}0&0&0\\0&1&0\\0&0&1\end{bmatrix}.
$$

3. Then

$$
\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}
\longmapsto
P\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}
=\begin{bmatrix}0\\x_2\\x_3\end{bmatrix}.
$$

4. The first coordinate is erased while the other two are preserved, so this matrix transformation projects every point in $\mathbb{R}^3$ onto the $x_2x_3$-plane.
::::
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 280 190" role="img" aria-label="A point projects parallel to the x1 axis onto the x2 x3 plane">
<path class="fig-fill" d="M42 147 L111 42 L240 78 L171 180 Z"/>
<path class="fig-axis" d="M42 147 L251 147 M42 147 L42 22 M42 147 L245 62"/>
<path class="fig-guide" d="M205 54 L148 102"/>
<circle class="fig-point" cx="205" cy="54" r="5"/>
<circle class="fig-point" cx="148" cy="102" r="5"/>
<path class="fig-arrow" d="M198 60 L150 100 M150 100 L156 89 M150 100 L162 99"/>
<text class="fig-label" x="252" y="153">x₂</text>
<text class="fig-label" x="30" y="21">x₃</text>
<text class="fig-label" x="247" y="60">x₁</text>
<text class="fig-label-em" x="210" y="50">x</text>
<text class="fig-label-em" x="132" y="119">P(x)</text>
</svg>
<figcaption>Projection onto the $x_2x_3$-plane sends $(x_1,x_2,x_3)$ to $(0,x_2,x_3)$ by moving parallel to the $x_1$-axis.</figcaption>
</figure>

### The lecture definition of linearity

:::definition[Definition 1.9C — The Two Conditions for Linearity]
A transformation $T$ is **linear** when both of the following hold for every pair $\mathbf{u},\mathbf{v}$ in its domain and every scalar $c$:

1. $T(\mathbf{u}+\mathbf{v})=T(\mathbf{u})+T(\mathbf{v})$.
2. $T(c\mathbf{u})=cT(\mathbf{u})$.

Matrix transformations satisfy these conditions because matrix multiplication distributes over vector addition and respects scalar multiplication.
:::

:::theorem[Theorem 1.8A — Immediate Consequences of Linearity]
If $T$ is linear, then

$$
T(\mathbf{0})=\mathbf{0}
$$

and, for all scalars $c,d$,

$$
T(c\mathbf{u}+d\mathbf{v})=cT(\mathbf{u})+dT(\mathbf{v}).
$$
:::

:::proof[Proof]
Homogeneity with the scalar $0$ gives

$$
T(\mathbf{0})=T(0\mathbf{u})=0T(\mathbf{u})=\mathbf{0}.
$$

For the second identity, use additivity first and homogeneity on each term:

$$
T(c\mathbf{u}+d\mathbf{v})=T(c\mathbf{u})+T(d\mathbf{v})
=cT(\mathbf{u})+dT(\mathbf{v}).
$$
:::

Applying the same reasoning repeatedly yields

$$
T(c_1\mathbf{v}_1+\cdots+c_p\mathbf{v}_p)
=c_1T(\mathbf{v}_1)+\cdots+c_pT(\mathbf{v}_p).
$$

This is the **superposition principle**: a linear transformation acts on a linear combination one component at a time.

:::example[Example 1.34 — Uniform scaling]

::::answer[Answer]
**Answer:** $T(\mathbf{x})=2\mathbf{x}$ is linear.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. The rule $T:\mathbb{R}^2\to\mathbb{R}^2$ defined by $T(\mathbf{x})=2\mathbf{x}$ is linear because

$$
T(\mathbf{u}+\mathbf{v})=2\mathbf{u}+2\mathbf{v}
=T(\mathbf{u})+T(\mathbf{v})
$$

3. and $T(c\mathbf{u})=2c\mathbf{u}=cT(\mathbf{u})$.
::::
:::

:::note[Lecture note — Contraction versus dilation]
For the scaling transformation $T(\mathbf{x})=r\mathbf{x}$, the lecture calls $T$ a **contraction** when $0\leq r\leq1$ and a **dilation** when $r>1$. A contraction shortens or preserves every distance from the origin; a dilation lengthens it.
:::

### Practice problems

:::problem[Problem 1.28 — Test linear equations]{difficulty=easy}
Without computation: is $T(\mathbf{x}) = \mathbf{0}$ (the zero map) linear? Justify.


::::solution[Solution]
**Answer:** Yes, the zero transformation is linear.

1. **Yes.** $T(\mathbf{u}+\mathbf{v})=\mathbf{0}=\mathbf{0}+\mathbf{0}=T(\mathbf{u})+T(\mathbf{v})$ and $T(c\mathbf{u})=\mathbf{0}=c\cdot\mathbf{0}=cT(\mathbf{u})$. The zero map satisfies both properties trivially.

2. Check the result against the definition: an affirmative subspace claim must include the zero vector, sums and scalar multiples; one counterexample suffices for a negative claim.
::::
:::

:::problem[Problem 1.29 — Compute the vector result]{difficulty=standard}
Let $T: \mathbb{R}^3\to\mathbb{R}^2$, $T\begin{pmatrix}x_1\\x_2\\x_3\end{pmatrix}=\begin{pmatrix}x_1+x_2\\2x_3\end{pmatrix}$. Compute $T\begin{pmatrix}1\\-1\\2\end{pmatrix}$ and verify $T(2\mathbf{u})=2T(\mathbf{u})$ for your vector $\mathbf{u}$.


::::solution[Solution]
**Answer:** $T(1,-1,2)^T=(0,4)^T$, and $T(2, -2,4)^T=(0,8)^T=2T(1,-1,2)^T$.

1. $T\begin{pmatrix}1\\-1\\2\end{pmatrix}=\begin{pmatrix}0\\4\end{pmatrix}$.

2. $T\begin{pmatrix}2\\-2\\4\end{pmatrix}=\begin{pmatrix}0\\8\end{pmatrix}=2\begin{pmatrix}0\\4\end{pmatrix}\,\checkmark$.

3. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.

4. For the first image, the two output coordinates are $1+(-1)=0$ and $2(2)=4$. Doubling the input gives $2+(-2)=0$ and $2(4)=8$, agreeing with twice the first image.
::::
:::

:::problem[Problem 1.30 — Domain and codomain]{difficulty=easy}
If $A$ is a $4\times3$ matrix and $T(\mathbf{x})=A\mathbf{x}$, state the domain and codomain of $T$.


::::solution[Solution]
**Answer:** Domain $\mathbb R^3$; codomain $\mathbb R^4$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. The three columns require inputs in $\mathbb{R}^3$, and the four rows produce outputs in $\mathbb{R}^4$. Thus $T:\mathbb{R}^3\to\mathbb{R}^4$.
::::
:::

:::problem[Problem 1.31 — A matrix image]{difficulty=easy}
Let $T(\mathbf{x})=A\mathbf{x}$ with $A=\begin{bmatrix}2&3&1\\0&1&2\end{bmatrix}$. Compute $T(0,1,2)^T$.


::::solution[Solution]
**Answer:** $T(0,1,2)^T=(5,5)^T$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

$$
T\begin{bmatrix}0\\1\\2\end{bmatrix}
=\begin{bmatrix}2&3&1\\0&1&2\end{bmatrix}
\begin{bmatrix}0\\1\\2\end{bmatrix}
=\begin{bmatrix}5\\5\end{bmatrix}.
$$
::::
:::

:::problem[Problem 1.32 — Projection]{difficulty=standard}
The matrix $P=\begin{bmatrix}0&0&0\\0&1&0\\0&0&1\end{bmatrix}$ projects onto the $x_2x_3$-plane. Find $P(4,-2,7)^T$ and then compute $P^2(4,-2,7)^T$.


::::solution[Solution]
**Answer:** $P(4,-2,7)^T=P^2(4,-2,7)^T=(0,-2,7)^T$.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

$$
P\begin{bmatrix}4\\-2\\7\end{bmatrix}
=\begin{bmatrix}0\\-2\\7\end{bmatrix}.
$$

2. Applying $P$ again leaves the point unchanged because its first coordinate is already zero:

$$
P^2\begin{bmatrix}4\\-2\\7\end{bmatrix}
=P\begin{bmatrix}0\\-2\\7\end{bmatrix}
=\begin{bmatrix}0\\-2\\7\end{bmatrix}.
$$
::::
:::

:::problem[Problem 1.33 — Superposition]{difficulty=standard}
Suppose $T$ is linear, $T(\mathbf{u})=(1,-2)^T$, and $T(\mathbf{v})=(3,4)^T$. Find $T(2\mathbf{u}-3\mathbf{v})$.


::::solution[Solution]
**Answer:** $T(2\mathbf u-3\mathbf v)=(-7,-16)^T$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. By superposition,

$$
T(2\mathbf{u}-3\mathbf{v})
=2T(\mathbf{u})-3T(\mathbf{v})
=2\begin{bmatrix}1\\-2\end{bmatrix}
-3\begin{bmatrix}3\\4\end{bmatrix}
=\begin{bmatrix}-7\\-16\end{bmatrix}.
$$
::::
:::

:::problem[Problem 1.34 — Failure at the origin]{difficulty=easy}
Is $T(x_1,x_2)=(2x_1,x_2+5)$ linear?


::::solution[Solution]
**Answer:** No, since $T(0,0)=(0,5)\neq(0,0)$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. **No.** A linear transformation must send the zero vector to the zero vector, but

$$
T(0,0)=(0,5)\neq(0,0).
$$
::::
:::

:::problem[Problem 1.35 — Contraction or dilation]{difficulty=standard}
For each scaling transformation, classify it using the lecture terminology and compute the image of $(2,-4)^T$: (a) $T(\mathbf{x})=\tfrac14\mathbf{x}$; (b) $S(\mathbf{x})=3\mathbf{x}$.


::::solution[Solution]
**Answer:** (a) contraction: $(\tfrac12,-1)^T$; (b) dilation: $(6,-12)^T$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. (a) Since $0\leq\tfrac14\leq1$, $T$ is a contraction, and

$$
T\begin{bmatrix}2\\-4\end{bmatrix}
=\begin{bmatrix}\tfrac12\\-1\end{bmatrix}.
$$

3. (b) Since $3>1$, $S$ is a dilation, and

$$
S\begin{bmatrix}2\\-4\end{bmatrix}
=\begin{bmatrix}6\\-12\end{bmatrix}.
$$
::::
:::

## 1.9 The Matrix of a Linear Transformation

:::callout-intuition[Intuition first]
Every linear transformation $T: \mathbb{R}^n \to \mathbb{R}^m$ can be completely
 described by a single matrix $A$ such that $T(\mathbf{x}) = A\mathbf{x}$ for all
 $\mathbf{x}$. To find this matrix, you just need to know where $T$ sends each
 standard basis vector $\mathbf{e}_1, \mathbf{e}_2, \ldots, \mathbf{e}_n$ — those
 images become the columns of $A$.
:::

:::theorem[Theorem 1.8 — The Standard Matrix]
Let $T: \mathbb{R}^n \to \mathbb{R}^m$ be a linear transformation.
 There is a unique $m\times n$ matrix $A$ such that

$$
T(\mathbf{x}) = A\mathbf{x} \quad \text{for all } \mathbf{x} \in \mathbb{R}^n.
$$

 The matrix is given by

$$
A = [T(\mathbf{e}_1)\quad T(\mathbf{e}_2)\quad \cdots\quad T(\mathbf{e}_n)],
$$

 where $\mathbf{e}_j$ is the $j$-th standard basis vector of $\mathbb{R}^n$.
 $A$ is called the **standard matrix** of $T$.
:::

:::definition[Definition 1.10 — One-to-One and Onto]
$T: \mathbb{R}^n \to \mathbb{R}^m$ is **one-to-one** (injective) if distinct
 inputs give distinct outputs: $T(\mathbf{u}) = T(\mathbf{v}) \Rightarrow \mathbf{u}=\mathbf{v}$.
 Equivalently, $A\mathbf{x}=\mathbf{0}$ has only the trivial solution (columns of $A$ are linearly independent).

$T$ is **onto** (surjective) if every $\mathbf{b}\in\mathbb{R}^m$ is in the
 range of $T$. Equivalently, $A\mathbf{x}=\mathbf{b}$ is consistent for all $\mathbf{b}$
 (columns of $A$ span $\mathbb{R}^m$).
:::

:::example[Example 1.35 — Finding the standard matrix]
$T: \mathbb{R}^2 \to \mathbb{R}^2$ rotates every vector by $90°$ counterclockwise.
 Find the standard matrix.


::::answer[Answer]
**Answer:** $A = \begin{bmatrix}0&-1\\1&0\end{bmatrix}$

1. Find where the basis vectors go under 90° CCW rotation:

2. $T(\mathbf{e}_1) = T\begin{pmatrix}1\\0\end{pmatrix} = \begin{pmatrix}0\\1\end{pmatrix}$ — the vector pointing right becomes the vector pointing up.

3. $T(\mathbf{e}_2) = T\begin{pmatrix}0\\1\end{pmatrix} = \begin{pmatrix}-1\\0\end{pmatrix}$ — the vector pointing up becomes the vector pointing left.

4. Assemble as columns: $A = [T(\mathbf{e}_1)\mid T(\mathbf{e}_2)] = \begin{bmatrix}0&-1\\1&0\end{bmatrix}$.

5. Verify: $A\begin{pmatrix}1\\0\end{pmatrix}=\begin{pmatrix}0\\1\end{pmatrix}\,\checkmark$ and $A\begin{pmatrix}0\\1\end{pmatrix}=\begin{pmatrix}-1\\0\end{pmatrix}\,\checkmark$.
::::
:::

:::example[Example 1.36 — One-to-one and onto check]
Let $T: \mathbb{R}^2\to\mathbb{R}^3$ have standard matrix $A=\begin{bmatrix}1&0\\0&1\\0&0\end{bmatrix}$.
 Is $T$ one-to-one? Is it onto?


::::answer[Answer]
**Answer:** One-to-one: **Yes**. Onto: **No**.

1. Row-reduce $A$: already in RREF with two pivot columns and no free variables.
 So $A\mathbf{x}=\mathbf{0}$ has only the trivial solution → **one-to-one**.

2. For onto, we'd need columns of $A$ to span $\mathbb{R}^3$ — but $A$ is $3\times2$,
 so it has at most 2 pivot rows, never 3. The vector $\begin{pmatrix}0\\0\\1\end{pmatrix}$
 is not in the range of $T$. → **not onto**.
::::
:::

:::callout-pitfall[Watch out for]
- **One-to-one lives in the domain; onto lives in the codomain.** One-to-one is about the columns of $A$ being independent (no repeated inputs map to the same output). Onto is about the rows having enough pivots to cover $\mathbb{R}^m$.
- **$T: \mathbb{R}^n\to\mathbb{R}^m$ with $n > m$ cannot be one-to-one.** More columns than rows means there must be a free variable.
- **$T: \mathbb{R}^n\to\mathbb{R}^m$ with $n < m$ cannot be onto.** Fewer columns than rows means you can't have a pivot in every row.
:::

### Deriving the standard matrix from the standard basis

:::example[Example 1.37 — Build the formula from $T(\mathbf{e}_j)$]
Let $T:\mathbb{R}^3\to\mathbb{R}^2$ be linear, with

$$
T(\mathbf{e}_1)=\begin{bmatrix}1\\-1\end{bmatrix},\qquad
T(\mathbf{e}_2)=\begin{bmatrix}2\\3\end{bmatrix},\qquad
T(\mathbf{e}_3)=\begin{bmatrix}-3\\2\end{bmatrix}.
$$

Find $T(\mathbf{x})$ for an arbitrary $\mathbf{x}\in\mathbb{R}^3$.


::::answer[Answer]
**Answer:** $T(\mathbf{x})=\begin{bmatrix}1&2&-3\\-1&3&2\end{bmatrix}\mathbf{x}$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. Every vector $\mathbf{x}=(x_1,x_2,x_3)^T$ has the standard-basis expansion

$$
\mathbf{x}=x_1\mathbf{e}_1+x_2\mathbf{e}_2+x_3\mathbf{e}_3.
$$

3. Linearity and superposition give

$$
\begin{aligned}
T(\mathbf{x})
&=x_1T(\mathbf{e}_1)+x_2T(\mathbf{e}_2)+x_3T(\mathbf{e}_3)\\
&=x_1\begin{bmatrix}1\\-1\end{bmatrix}
+x_2\begin{bmatrix}2\\3\end{bmatrix}
+x_3\begin{bmatrix}-3\\2\end{bmatrix}\\
&=\begin{bmatrix}1&2&-3\\-1&3&2\end{bmatrix}
\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}.
\end{aligned}
$$

4. Thus the images of the standard basis vectors become the columns of the standard matrix.
::::
:::

:::proof[Proof of existence and uniqueness in Theorem 1.8]
For existence, write $\mathbf{x}=x_1\mathbf{e}_1+\cdots+x_n\mathbf{e}_n$. Linearity gives

$$
T(\mathbf{x})=x_1T(\mathbf{e}_1)+\cdots+x_nT(\mathbf{e}_n)
=[T(\mathbf{e}_1)\ \cdots\ T(\mathbf{e}_n)]\mathbf{x}.
$$

Therefore the displayed matrix represents $T$.

For uniqueness, suppose both $A$ and $B$ represent $T$. For every standard basis vector,

$$
A\mathbf{e}_j=T(\mathbf{e}_j)=B\mathbf{e}_j.
$$

But $A\mathbf{e}_j$ is column $j$ of $A$, and $B\mathbf{e}_j$ is column $j$ of $B$. Corresponding columns agree for every $j$, so $A=B$.
:::

:::example[Example 1.38 — Standard matrix of a contraction]

::::answer[Answer]
**Answer:** $A=\begin{bmatrix}\tfrac12&0&0\\0&\tfrac12&0\\0&0&\tfrac12\end{bmatrix}$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. For $T:\mathbb{R}^3\to\mathbb{R}^3$ defined by $T(\mathbf{x})=\tfrac12\mathbf{x}$,

$$
T(\mathbf{e}_1)=\begin{bmatrix}\tfrac12\\0\\0\end{bmatrix},\quad
T(\mathbf{e}_2)=\begin{bmatrix}0\\\tfrac12\\0\end{bmatrix},\quad
T(\mathbf{e}_3)=\begin{bmatrix}0\\0\\\tfrac12\end{bmatrix}.
$$

3. Therefore the standard matrix is

$$
A=\begin{bmatrix}\tfrac12&0&0\\0&\tfrac12&0\\0&0&\tfrac12\end{bmatrix}.
$$
::::
:::

### Five geometric transformations of $\mathbb{R}^2$

The unit square makes the action of a matrix visible. In each panel below, the dashed square is the original unit square and the solid outline is its image.

<div class="fig-grid">
<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 180 150" role="img" aria-label="The unit square rotated counterclockwise">
<path class="fig-axis" d="M18 122 L166 122 M42 140 L42 12"/>
<path class="fig-guide" d="M42 122 L102 122 L102 62 L42 62 Z"/>
<path class="fig-curve" d="M42 122 L94 92 L64 40 L12 70 Z"/>
<path class="fig-arrow" d="M112 96 C126 77 125 59 114 45 M114 45 L114 57 M114 45 L124 51"/>
<text class="fig-label-em" x="126" y="62">φ</text>
</svg>
<figcaption>Rotation through $\varphi$ uses $\begin{bmatrix}\cos\varphi&-\sin\varphi\\\sin\varphi&\cos\varphi\end{bmatrix}$.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 180 150" role="img" aria-label="The unit square reflected across the x1 axis">
<path class="fig-axis" d="M12 75 L168 75 M42 140 L42 12"/>
<path class="fig-guide" d="M42 75 L102 75 L102 25 L42 25 Z"/>
<path class="fig-curve" d="M42 75 L102 75 L102 125 L42 125 Z"/>
<path class="fig-arrow" d="M117 46 L117 106 M117 106 L111 95 M117 106 L123 95"/>
</svg>
<figcaption>Reflection across the $x_1$-axis uses $\begin{bmatrix}1&0\\0&-1\end{bmatrix}$.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 180 150" role="img" aria-label="The unit square expanded horizontally">
<path class="fig-axis" d="M12 125 L170 125 M30 140 L30 12"/>
<path class="fig-guide" d="M30 125 L85 125 L85 70 L30 70 Z"/>
<path class="fig-curve" d="M30 125 L140 125 L140 70 L30 70 Z"/>
<path class="fig-arrow" d="M83 57 L138 57 M138 57 L127 51 M138 57 L127 63"/>
</svg>
<figcaption>Horizontal expansion by $k>1$ uses $\begin{bmatrix}k&0\\0&1\end{bmatrix}$; values $0\leq k\leq1$ contract instead.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 180 150" role="img" aria-label="The unit square sheared to the right">
<path class="fig-axis" d="M10 125 L170 125 M30 140 L30 12"/>
<path class="fig-guide" d="M30 125 L90 125 L90 65 L30 65 Z"/>
<path class="fig-curve" d="M30 125 L90 125 L132 65 L72 65 Z"/>
<path class="fig-arrow" d="M91 52 L129 52 M129 52 L118 46 M129 52 L118 58"/>
</svg>
<figcaption>A horizontal shear uses $\begin{bmatrix}1&k\\0&1\end{bmatrix}$ and sends $(0,1)$ to $(k,1)$.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 180 150" role="img" aria-label="The unit square projected onto the x1 axis">
<path class="fig-axis" d="M12 118 L168 118 M36 140 L36 12"/>
<path class="fig-guide" d="M36 118 L112 118 L112 42 L36 42 Z"/>
<path class="fig-curve" d="M36 118 L112 118"/>
<path class="fig-arrow" d="M128 43 L128 113 M128 113 L122 102 M128 113 L134 102"/>
</svg>
<figcaption>Projection onto the $x_1$-axis uses $\begin{bmatrix}1&0\\0&0\end{bmatrix}$ and collapses the square to a segment.</figcaption>
</figure>
</div>

Rotation, reflection, contraction with a nonzero factor, expansion, and shear are all one-to-one. Projection is the exception: different points lying above one another can project to the same point.

### Onto and one-to-one mappings

:::definition[Definition 1.10A — Onto]
A transformation $T:\mathbb{R}^n\to\mathbb{R}^m$ is **onto $\mathbb{R}^m$** if, for each $\mathbf{b}\in\mathbb{R}^m$, there is at least one $\mathbf{x}\in\mathbb{R}^n$ such that $T(\mathbf{x})=\mathbf{b}$.
:::

:::definition[Definition 1.10B — One-to-One]
A transformation $T:\mathbb{R}^n\to\mathbb{R}^m$ is **one-to-one** if every $\mathbf{b}\in\mathbb{R}^m$ is the image of at most one $\mathbf{x}\in\mathbb{R}^n$.

Equivalently, for each $\mathbf{b}$, the equation $T(\mathbf{x})=\mathbf{b}$ has either one solution or no solution at all.
:::

<div class="fig-grid">
<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 180 130" role="img" aria-label="An onto map whose range fills the codomain">
<path class="fig-guide" d="M10 16 C0 42 4 106 45 116 C78 124 89 89 83 54 C78 22 44 5 10 16 Z M112 14 C91 34 96 103 132 116 C169 129 183 88 174 47 C168 18 137 2 112 14 Z"/>
<circle class="fig-point" cx="31" cy="42" r="3"/><circle class="fig-point" cx="53" cy="83" r="3"/>
<circle class="fig-point" cx="130" cy="38" r="3"/><circle class="fig-point" cx="149" cy="65" r="3"/><circle class="fig-point" cx="139" cy="93" r="3"/>
<path class="fig-arrow" d="M34 42 L126 38 M126 38 L116 33 M126 38 L116 43 M56 82 L145 66 M145 66 L134 63 M145 66 L136 72"/>
</svg>
<figcaption>An onto map reaches every point of the codomain, so its range equals the codomain.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 180 130" role="img" aria-label="A map that is not onto because part of the codomain is missed">
<path class="fig-guide" d="M10 16 C0 42 4 106 45 116 C78 124 89 89 83 54 C78 22 44 5 10 16 Z M112 14 C91 34 96 103 132 116 C169 129 183 88 174 47 C168 18 137 2 112 14 Z"/>
<path class="fig-fill" d="M120 38 C108 53 113 88 137 96 C158 101 168 75 159 51 C151 34 132 28 120 38 Z"/>
<circle class="fig-point" cx="31" cy="42" r="3"/><circle class="fig-point" cx="53" cy="83" r="3"/><circle class="fig-point" cx="137" cy="51" r="3"/><circle class="fig-point" cx="145" cy="79" r="3"/>
<path class="fig-arrow" d="M34 42 L133 51 M133 51 L123 46 M133 51 L123 56 M56 82 L141 79 M141 79 L131 74 M141 79 L131 84"/>
</svg>
<figcaption>A map is not onto when its range is a proper subset of the codomain.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 180 130" role="img" aria-label="A one-to-one map with distinct targets for distinct inputs">
<path class="fig-guide" d="M10 16 C0 42 4 106 45 116 C78 124 89 89 83 54 C78 22 44 5 10 16 Z M112 14 C91 34 96 103 132 116 C169 129 183 88 174 47 C168 18 137 2 112 14 Z"/>
<circle class="fig-point" cx="28" cy="42" r="3"/><circle class="fig-point" cx="55" cy="83" r="3"/><circle class="fig-point" cx="132" cy="41" r="3"/><circle class="fig-point" cx="151" cy="85" r="3"/>
<path class="fig-arrow" d="M31 42 L128 41 M128 41 L118 36 M128 41 L118 46 M58 83 L147 85 M147 85 L137 79 M147 85 L137 90"/>
</svg>
<figcaption>A one-to-one map sends distinct inputs to distinct outputs.</figcaption>
</figure>
<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 180 130" role="img" aria-label="A map that is not one-to-one because two inputs share one target">
<path class="fig-guide" d="M10 16 C0 42 4 106 45 116 C78 124 89 89 83 54 C78 22 44 5 10 16 Z M112 14 C91 34 96 103 132 116 C169 129 183 88 174 47 C168 18 137 2 112 14 Z"/>
<circle class="fig-point" cx="27" cy="39" r="3"/><circle class="fig-point" cx="55" cy="86" r="3"/><circle class="fig-point" cx="145" cy="64" r="3"/>
<path class="fig-arrow" d="M30 40 L141 63 M141 63 L132 56 M141 63 L130 67 M58 84 L141 65 M141 65 L130 62 M141 65 L132 71"/>
</svg>
<figcaption>A map is not one-to-one when two different inputs have the same image.</figcaption>
</figure>
</div>

:::example[Example 1.39 — Onto but not one-to-one]

::::answer[Answer]
**Answer:** $T$ is onto $\mathbb{R}^3$ but not one-to-one.

1. Let $T$ have standard matrix

$$
A=\begin{bmatrix}1&-1&2&3\\0&1&-1&3\\-1&1&0&4\end{bmatrix}.
$$

2. For a general $\mathbf{b}\in\mathbb{R}^3$,

$$
\begin{bmatrix}1&-1&2&3&b_1\\0&1&-1&3&b_2\\-1&1&0&4&b_3\end{bmatrix}
\sim
\begin{bmatrix}1&-1&2&3&b_1\\0&1&-1&3&b_2\\0&0&2&7&b_3+b_1\end{bmatrix}.
$$

3. There is a pivot in every row, so $A\mathbf{x}=\mathbf{b}$ is consistent for every $\mathbf{b}$ and $T$ is onto $\mathbb{R}^3$. There are four variables but only three rows, so at least one variable is free. Each consistent system has infinitely many solutions, so $T$ is not one-to-one.
::::
:::

:::theorem[Theorem 1.8B — The Zero-Output Test for One-to-One]
A linear transformation $T$ is one-to-one if and only if $T(\mathbf{x})=\mathbf{0}$ has only the trivial solution $\mathbf{x}=\mathbf{0}$.
:::

:::proof[Proof]
Suppose first that $T$ is one-to-one. Linearity gives $T(\mathbf{0})=\mathbf{0}$. Since a one-to-one map allows at most one input for an output, any $\mathbf{x}$ satisfying $T(\mathbf{x})=\mathbf{0}=T(\mathbf{0})$ must equal $\mathbf{0}$.

Conversely, suppose $T(\mathbf{x})=\mathbf{0}$ has only the trivial solution. If $T(\mathbf{u})=T(\mathbf{v})$, then

$$
T(\mathbf{u}-\mathbf{v})=T(\mathbf{u})-T(\mathbf{v})=\mathbf{0}.
$$

The hypothesis forces $\mathbf{u}-\mathbf{v}=\mathbf{0}$, so $\mathbf{u}=\mathbf{v}$. Therefore $T$ is one-to-one.
:::

:::theorem[Theorem 1.8C — Onto and One-to-One in Terms of Columns]
Let $T:\mathbb{R}^n\to\mathbb{R}^m$ be linear with standard matrix $A$.

1. $T$ is onto $\mathbb{R}^m$ if and only if the columns of $A$ span $\mathbb{R}^m$.
2. $T$ is one-to-one if and only if the columns of $A$ are linearly independent.
:::

:::proof[Proof]
For the first statement, the columns of $A$ span $\mathbb{R}^m$ exactly when $A\mathbf{x}=\mathbf{b}$ is consistent for every $\mathbf{b}\in\mathbb{R}^m$. Because $T(\mathbf{x})=A\mathbf{x}$, this is exactly the definition that $T$ maps onto $\mathbb{R}^m$.

For the second statement, the zero-output theorem says that $T$ is one-to-one exactly when $T(\mathbf{x})=\mathbf{0}$ has only the trivial solution. Since $T(\mathbf{x})=A\mathbf{x}$, this is equivalent to $A\mathbf{x}=\mathbf{0}$ having only the trivial solution, which is equivalent to the columns of $A$ being linearly independent.
:::

:::example[Example 1.40 — A map from $\mathbb{R}^2$ to $\mathbb{R}^3$, two ways]
Let

$$
T(x_1,x_2)=(3x_1-x_2,\ x_1+2x_2,\ x_1+3x_2).
$$

Show that $T$ is one-to-one and decide whether it maps onto $\mathbb{R}^3$.


::::answer[Answer]
**Answer:** **$T$ is one-to-one but is not onto $\mathbb{R}^3$.**

1. The standard matrix is

$$
A=\begin{bmatrix}3&-1\\1&2\\1&3\end{bmatrix}.
$$

2. Its two columns are not scalar multiples, so they are linearly independent. Therefore $T$ is one-to-one.

3. **Method 1: pivot count.** The $3\times2$ matrix has only two columns, so it can have at most two pivots. It cannot have a pivot in all three rows. Thus its columns do not span $\mathbb{R}^3$, and $T$ is not onto.

4. **Method 2: carry a symbolic right-hand side.** For $\mathbf{b}=(b_1,b_2,b_3)^T$,

$$
\begin{bmatrix}3&-1&b_1\\1&2&b_2\\1&3&b_3\end{bmatrix}
\sim
\begin{bmatrix}1&2&b_2\\0&-7&b_1-3b_2\\0&1&b_3-b_2\end{bmatrix}
\sim
\begin{bmatrix}1&2&b_2\\0&1&b_3-b_2\\0&0&b_1-10b_2+7b_3\end{bmatrix}.
$$

5. Whenever

$$
b_1-10b_2+7b_3\neq0,
$$

6. the last row is inconsistent. Such right-hand sides exist, so the equation is not solvable for every $\mathbf{b}$ and $T$ is not onto $\mathbb{R}^3$.
::::
:::

### Practice problems

:::problem[Problem 1.36 — Find the standard matrix]{difficulty=easy}
Find the standard matrix of the transformation $T:\mathbb{R}^2\to\mathbb{R}^2$ that reflects vectors across the $x_1$-axis (flips the sign of the second component).


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}1&0\\0&-1\end{bmatrix}$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. $T(\mathbf{e}_1)=\begin{pmatrix}1\\0\end{pmatrix}$, $T(\mathbf{e}_2)=\begin{pmatrix}0\\-1\end{pmatrix}$.
 Standard matrix: $A=\begin{bmatrix}1&0\\0&-1\end{bmatrix}$.

3. The reflection keeps the first coordinate and negates the second, so multiplying the displayed matrix by $(a,b)^T$ gives $(a,-b)^T$, exactly the required reflection for every vector.
::::
:::

:::problem[Problem 1.37 — Find the standard matrix]{difficulty=standard}
Given $T:\mathbb{R}^3\to\mathbb{R}^2$ defined by $T(\mathbf{e}_1)=\begin{pmatrix}1\\3\end{pmatrix}$, $T(\mathbf{e}_2)=\begin{pmatrix}-2\\0\end{pmatrix}$, $T(\mathbf{e}_3)=\begin{pmatrix}4\\1\end{pmatrix}$, find $T\begin{pmatrix}2\\-1\\3\end{pmatrix}$.


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}1&-2&4\\3&0&1\end{bmatrix}$; $T(2,-1,3)^T=(16,9)^T$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. Standard matrix: $A=\begin{bmatrix}1&-2&4\\3&0&1\end{bmatrix}$.

$$
A\begin{pmatrix}2\\-1\\3\end{pmatrix}=\begin{pmatrix}2+2+12\\6+0+3\end{pmatrix}=\begin{pmatrix}16\\9\end{pmatrix}
$$

3. The input is $2\mathbf e_1-\mathbf e_2+3\mathbf e_3$. By linearity, its image is $2(1,3)^T-(-2,0)^T+3(4,1)^T=(16,9)^T$, checking the stated result.
::::
:::

:::problem[Problem 1.38 — Test independence]{difficulty=challenge}
Suppose $T:\mathbb{R}^4\to\mathbb{R}^3$. Can $T$ be both one-to-one and onto? Justify.


::::solution[Solution]
**Answer:** No. A $3\times4$ matrix cannot have a pivot in every column.

1. $T$ is one-to-one iff the columns of its $3\times4$ standard matrix $A$ are linearly independent — which requires $\leq 3$ columns. But $A$ has 4 columns in $\mathbb{R}^3$, so by Theorem 1.7, they must be linearly dependent → $T$ **cannot be one-to-one**.

2. It's also impossible to be both: a bijection between $\mathbb{R}^4$ and $\mathbb{R}^3$ would be an isomorphism, which can only happen between spaces of equal dimension.
::::
:::

:::problem[Problem 1.39 — Assemble the standard matrix]{difficulty=easy}
Suppose $T:\mathbb{R}^3\to\mathbb{R}^2$ is linear and
$T(\mathbf{e}_1)=(2,1)^T$, $T(\mathbf{e}_2)=(-1,4)^T$, and $T(\mathbf{e}_3)=(3,0)^T$. Find the standard matrix.


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}2&-1&3\\1&4&0\end{bmatrix}$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. The images of the standard basis vectors are the columns:

$$
A=[T(\mathbf{e}_1)\ T(\mathbf{e}_2)\ T(\mathbf{e}_3)]
=\begin{bmatrix}2&-1&3\\1&4&0\end{bmatrix}.
$$
::::
:::

:::problem[Problem 1.40 — Contraction matrix]{difficulty=easy}
Find the standard matrix of $T:\mathbb{R}^2\to\mathbb{R}^2$ defined by $T(\mathbf{x})=\tfrac13\mathbf{x}$.


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}\tfrac13&0\\0&\tfrac13\end{bmatrix}$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. $T(\mathbf{e}_1)=(1/3,0)^T$ and $T(\mathbf{e}_2)=(0,1/3)^T$, so

$$
A=\begin{bmatrix}\tfrac13&0\\0&\tfrac13\end{bmatrix}.
$$

3. Indeed, multiplying this matrix by $(x_1,x_2)^T$ gives $(x_1/3,x_2/3)^T=(1/3)\mathbf x$. Both columns therefore agree with the images of the standard basis vectors.
::::
:::

:::problem[Problem 1.41 — A shear]{difficulty=standard}
The horizontal shear $T(x_1,x_2)=(x_1+2x_2,x_2)$ acts on the unit square. Find its standard matrix and the images of $(1,0)^T$ and $(0,1)^T$.


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}1&2\\0&1\end{bmatrix}$; $T(1,0)^T=(1,0)^T$; $T(0,1)^T=(2,1)^T$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

$$
T(\mathbf{e}_1)=\begin{bmatrix}1\\0\end{bmatrix},\qquad
T(\mathbf{e}_2)=\begin{bmatrix}2\\1\end{bmatrix}.
$$

2. Therefore

$$
A=\begin{bmatrix}1&2\\0&1\end{bmatrix}.
$$

3. The first basis vector stays fixed and the second moves to $(2,1)^T$.
::::
:::

:::problem[Problem 1.42 — Projection is not one-to-one]{difficulty=standard}
For $P(x_1,x_2)=(x_1,0)$, give two distinct inputs with the same output and find all solutions of $P(\mathbf{x})=\mathbf{0}$.


::::solution[Solution]
**Answer:** $P$ is not one-to-one; $\Nul P=\{(0,t):t\in\mathbb R\}$.

1. For example, $P(1,0)=P(1,5)=(1,0)$, so $P$ is not one-to-one. Also,

$$
P(x_1,x_2)=(0,0)
$$

2. requires $x_1=0$ but leaves $x_2$ free. Thus every vector $(0,t)^T$ lies in the zero-output set, confirming that the solution is not only the trivial one.
::::
:::

:::problem[Problem 1.43 — Onto and one-to-one from pivots]{difficulty=standard}
Let $T:\mathbb{R}^3\to\mathbb{R}^2$ have standard matrix

$$
A=\begin{bmatrix}1&0&2\\0&1&-1\end{bmatrix}.
$$

Is $T$ onto? Is it one-to-one?


::::solution[Solution]
**Answer:** Onto: yes; one-to-one: no.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. There is a pivot in each of the two rows, so the columns span $\mathbb{R}^2$ and $T$ is **onto**. There are three variables but only two pivot columns, so one variable is free in $A\mathbf{x}=\mathbf{0}$. Therefore the columns are dependent and $T$ is **not one-to-one**.
::::
:::

:::problem[Problem 1.44 — Symbolic consistency condition]{difficulty=challenge}
For the lecture matrix

$$
A=\begin{bmatrix}3&-1\\1&2\\1&3\end{bmatrix},
$$

decide whether $\mathbf{b}=(3,1,1)^T$ and $\mathbf{c}=(0,1,0)^T$ belong to the range of $T(\mathbf{x})=A\mathbf{x}$.


::::solution[Solution]
**Answer:** $\mathbf b=(3,1,1)^T\in\operatorname{range}(T)$; $\mathbf c=(0,1,0)^T\notin\operatorname{range}(T)$.

1. The symbolic consistency condition is

$$
b_1-10b_2+7b_3=0.
$$

2. For $\mathbf{b}=(3,1,1)^T$, the left side is $3-10+7=0$, so $\mathbf{b}$ is in the range. Indeed, $x_1=1$, $x_2=0$ gives $A\mathbf{x}=\mathbf{b}$.

3. For $\mathbf{c}=(0,1,0)^T$, the left side is $0-10+0=-10\neq0$, so the augmented system is inconsistent and $\mathbf{c}$ is not in the range.
::::
:::

:::summary
## The pivot map

:::callout-intuition[Reduce once, then read the map]
Most concept questions in this chapter are not new computations. They are new sentences about
the same pivot pattern. Reduce once, mark where the pivots landed, and the matrix has already
answered whether a solution exists, whether every target can be reached, and whether the
columns are independent.
:::

There are only three questions to ask after row reduction.

1. **Is there a pivot in the augmented column?** If yes, the particular system is
   inconsistent. If no, it is consistent.
2. **Is there a pivot in every row of $A$?** If yes, $A\mathbf{x}=\mathbf{b}$ is consistent
   for every $\mathbf{b}\in\mathbb{R}^m$. Equivalently, the columns span $\mathbb{R}^m$ and
   the map $\mathbf{x}\mapsto A\mathbf{x}$ is onto.
3. **Is there a pivot in every column of $A$?** If yes, there are no free variables.
   Equivalently, the columns are independent, the homogeneous equation has only the trivial
   solution, and $\mathbf{x}\mapsto A\mathbf{x}$ is one-to-one.

A row holds at most one pivot because a pivot is that row's **first nonzero entry** in
echelon form. Once that entry has been named, the same row cannot have a second first nonzero
entry. An $m$-row matrix therefore has at most $m$ pivots, no matter how many columns it has.

Existence and uniqueness are the only two things a system has to say. Question 2 settles
existence for every possible right-hand side, and Question 3 settles uniqueness whenever a
solution exists. Question 1 is the one-right-hand-side version of existence.

<figure class="fig">
<iframe src="pivot-map.html" height="640" title="Interactive pivot map"></iframe>
<figcaption>Choose a matrix and right-hand side to see how the pivot positions determine consistency, spanning, independence, and the number of solutions.</figcaption>
</figure>

Here is the translation table. A dash means that the section is not asking that particular
question; it does not mean that the pivot fact stops being true.

| pivot fact | Section 1.2 | Section 1.3 | Section 1.4 | Section 1.7 | Section 1.9 |
|---|---|---|---|---|---|
| pivot in the augmented column | inconsistent | $\mathbf{b}$ is not in the span of the columns | $A\mathbf{x}=\mathbf{b}$ has no solution | — | $\mathbf{b}$ is not in the range |
| pivot in every row of $A$ | no zero row in an echelon form of $A$ | the columns span $\mathbb{R}^m$ | solvable for every $\mathbf{b}$ | — | the transformation is onto |
| pivot in every column of $A$ | no free variables; a consistent system is unique | every reachable vector has unique coefficients | a consistent $A\mathbf{x}=\mathbf{b}$ has a unique solution | the columns are independent; $A\mathbf{x}=\mathbf{0}$ has the trivial solution only | the transformation is one-to-one |

The vocabulary changes from section to section, but the evidence never changes: it is the
location of the pivots.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 180 165"
     role="img" aria-label="An augmented matrix with its augmented column marked">
<text class="fig-label-em" x="35" y="21">augmented pivot?</text>
<path class="fig-gridline" d="M24 39H156V123H24ZM57 39V123M90 39V123M123 39V123M24 67H156M24 95H156"/>
<path class="fig-guide" d="M123 34V128"/>
<path class="fig-curve" d="M128 43H151V119H128Z"/>
<circle class="fig-point" cx="139.5" cy="109" r="5"/>
<text class="fig-label" x="132" y="146">b</text>
</svg>
<figcaption>existence for this one $mathbf{b}$</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 180 165"
     role="img" aria-label="An augmented matrix with every coefficient row marked">
<text class="fig-label-em" x="42" y="21">every row?</text>
<path class="fig-gridline" d="M24 39H156V123H24ZM57 39V123M90 39V123M123 39V123M24 67H156M24 95H156"/>
<path class="fig-guide" d="M123 34V128"/>
<circle class="fig-point" cx="16" cy="53" r="5"/>
<circle class="fig-point" cx="16" cy="81" r="5"/>
<circle class="fig-point" cx="16" cy="109" r="5"/>
<text class="fig-label" x="132" y="146">b</text>
</svg>
<figcaption>existence for every $mathbf{b}$ — spans, onto</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 180 165"
     role="img" aria-label="An augmented matrix with every coefficient column marked">
<text class="fig-label-em" x="34" y="21">every column?</text>
<path class="fig-gridline" d="M24 39H156V123H24ZM57 39V123M90 39V123M123 39V123M24 67H156M24 95H156"/>
<path class="fig-guide" d="M123 34V128"/>
<circle class="fig-point" cx="40.5" cy="31" r="5"/>
<circle class="fig-point" cx="73.5" cy="31" r="5"/>
<circle class="fig-point" cx="106.5" cy="31" r="5"/>
<text class="fig-label" x="132" y="146">b</text>
</svg>
<figcaption>uniqueness — independent, one-to-one</figcaption>
</figure>

</div>

### Four matrices, four pivot shapes

The next four matrices cover every combination of the two properties that belong to the
columns: spanning the codomain and being independent. In each example, the row reduction
does all the work; the verdicts are translations of its pivot map.

:::example[Example 1.41 — spans and is independent]
Let

$$
M_1=\begin{bmatrix}1&2&3\\2&5&7\\3&7&11\end{bmatrix},
\qquad
\mathbf{b}=\begin{pmatrix}1\\4\\6\end{pmatrix}.
$$


::::answer[Answer]
**Answer:** $M_1$ has three pivots, so its columns span $\mathbb{R}^3$ and are linearly independent; the unique solution is $\mathbf{x}=(-4,1,1)^T$.

1. $M_1$ has three pivots, so its columns span $\mathbb{R}^3$ and are linearly independent;
the unique solution is $\mathbf{x}=(-4,1,1)^T$.

2. Subtract twice row 1 from row 2 and three times row 1 from row 3:

$$
\left[\begin{array}{rrr|r}1&2&3&1\\2&5&7&4\\3&7&11&6\end{array}\right]
\xrightarrow{R_2-2R_1,\;R_3-3R_1}
\left[\begin{array}{rrr|r}1&2&3&1\\0&1&1&2\\0&1&2&3\end{array}\right]
\xrightarrow{R_3-R_2}
\left[\begin{array}{rrr|r}1&2&3&1\\0&1&1&2\\0&0&1&1\end{array}\right].
$$

3. The pivots already occupy every row and every column. Continue upward to display the
solution:

$$
\xrightarrow{R_2-R_3,\;R_1-3R_3}
\left[\begin{array}{rrr|r}1&2&0&-2\\0&1&0&1\\0&0&1&1\end{array}\right]
\xrightarrow{R_1-2R_2}
\left[\begin{array}{rrr|r}1&0&0&-4\\0&1&0&1\\0&0&1&1\end{array}\right].
$$

4. Three rows and three columns are all covered: existence for every $\mathbf{b}$ and
uniqueness for every $\mathbf{b}$ both hold.
::::
:::

:::example[Example 1.42 — spans but is dependent]
Let

$$
M_2=\begin{bmatrix}1&2&0&3\\0&1&1&2\\2&5&1&9\end{bmatrix},
\qquad
\mathbf{b}=\begin{pmatrix}1\\2\\5\end{pmatrix}.
$$


::::answer[Answer]
**Answer:** The pivots are in columns $1$, $2$, and $4$. The columns span $\mathbb{R}^3$ but are dependent, with $2\mathbf{a}_1-\mathbf{a}_2+\mathbf{a}_3=\mathbf{0}$; the system has infinitely many solutions.

1. The pivots are in columns $1$, $2$, and $4$. The columns span $\mathbb{R}^3$ but are
dependent, with $2\mathbf{a}_1-\mathbf{a}_2+\mathbf{a}_3=\mathbf{0}$; the system has
infinitely many solutions.

2. First clear column 1, then compare the last two rows:

$$
\left[\begin{array}{rrrr|r}1&2&0&3&1\\0&1&1&2&2\\2&5&1&9&5\end{array}\right]
\xrightarrow{R_3-2R_1}
\left[\begin{array}{rrrr|r}1&2&0&3&1\\0&1&1&2&2\\0&1&1&3&3\end{array}\right]
\xrightarrow{R_3-R_2}
\left[\begin{array}{rrrr|r}1&2&0&3&1\\0&1&1&2&2\\0&0&0&1&1\end{array}\right].
$$

3. Thus columns $1$, $2$, and $4$ are pivot columns. Clear above the third pivot and then
above the second:

$$
\xrightarrow{R_2-2R_3,\;R_1-3R_3}
\left[\begin{array}{rrrr|r}1&2&0&0&-2\\0&1&1&0&0\\0&0&0&1&1\end{array}\right]
\xrightarrow{R_1-2R_2}
\left[\begin{array}{rrrr|r}1&0&-2&0&-2\\0&1&1&0&0\\0&0&0&1&1\end{array}\right].
$$

4. Set the free variable $x_3=t$. Then

$$
x_1=-2+2t,\qquad x_2=-t,\qquad x_3=t,\qquad x_4=1.
$$

5. There is a pivot in every row, so every target in $\mathbb{R}^3$ is reachable. There is no
pivot in column 3, so representations are not unique. To expose the dependence relation,
use the same coefficient matrix with right-hand side $\mathbf{0}$ and choose $t=1$:

$$
2\mathbf{a}_1-\mathbf{a}_2+\mathbf{a}_3+0\mathbf{a}_4=\mathbf{0}.
$$
::::
:::

:::example[Example 1.43 — independent but does not span]
Let

$$
M_3=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\\1&1&1\end{bmatrix}.
$$

Test the two right-hand sides

$$
\mathbf{b}=\begin{pmatrix}2\\3\\1\\6\end{pmatrix}
\qquad\text{and}\qquad
\mathbf{b}'=\begin{pmatrix}2\\3\\1\\7\end{pmatrix}.
$$


::::answer[Answer]
**Answer:** The columns are independent but do not span $\mathbb{R}^4$. For $\mathbf{b}$ the unique solution is $(2,3,1)^T$; for $\mathbf{b}'$ there is no solution. The range is exactly the set of vectors satisfying $b_4=b_1+b_2+b_3$.

1. The columns are independent but do not span $\mathbb{R}^4$. For $\mathbf{b}$ the unique
solution is $(2,3,1)^T$; for $\mathbf{b}'$ there is no solution. The range is exactly the
set of vectors satisfying $b_4=b_1+b_2+b_3$.

2. Carry both right-hand sides through the same row operation. Replace row 4 by row 4 minus
rows 1, 2, and 3:

$$
\left[\begin{array}{rrr|r|r}
1&0&0&2&2\\
0&1&0&3&3\\
0&0&1&1&1\\
1&1&1&6&7
\end{array}\right]
\xrightarrow{R_4-R_1-R_2-R_3}
\left[\begin{array}{rrr|r|r}
1&0&0&2&2\\
0&1&0&3&3\\
0&0&1&1&1\\
0&0&0&0&1
\end{array}\right].
$$

3. The first augmented column ends in $0=0$, so it gives the unique solution
$(2,3,1)^T$. The second ends in $0=1$, so it is inconsistent. The three pivots fill all
three columns, proving independence, but four rows cannot be filled by only three pivots.
Therefore the columns cannot span $\mathbb{R}^4$.
::::
:::

:::example[Example 1.44 — neither spans nor is independent]
Let

$$
M_4=\begin{bmatrix}1&4&3\\2&6&4\\3&8&5\end{bmatrix}.
$$

Test $\mathbf{b}=(1,0,0)^T$ and $\mathbf{c}=(1,2,3)^T$.


::::answer[Answer]
**Answer:** The columns satisfy $\mathbf{a}_1+\mathbf{a}_3=\mathbf{a}_2$, so they are dependent, and there is no pivot in every row, so they do not span $\mathbb{R}^3$. The first system is inconsistent; the second is consistent and has infinitely many solutions.

1. The columns satisfy $\mathbf{a}_1+\mathbf{a}_3=\mathbf{a}_2$, so they are dependent, and
there is no pivot in every row, so they do not span $\mathbb{R}^3$. The first system is
inconsistent; the second is consistent and has infinitely many solutions.

2. Reduce with a symbolic right-hand side so that both cases are visible in one computation:

$$
\left[\begin{array}{rrr|r}1&4&3&b_1\\2&6&4&b_2\\3&8&5&b_3\end{array}\right]
\xrightarrow{R_2-2R_1,\;R_3-3R_1}
\left[\begin{array}{rrr|r}1&4&3&b_1\\0&-2&-2&b_2-2b_1\\0&-4&-4&b_3-3b_1\end{array}\right]
$$

3. Write the relevant equation or row-operation calculation explicitly:

$$
\xrightarrow{R_3-2R_2}
\left[\begin{array}{rrr|r}1&4&3&b_1\\0&-2&-2&b_2-2b_1\\0&0&0&b_1-2b_2+b_3\end{array}\right].
$$

4. For $\mathbf{b}=(1,0,0)^T$, the last entry is $1$, and the last row reads $0=1$.
For $\mathbf{c}=(1,2,3)^T$, the last entry is $1-4+3=0$, so the system is consistent.
In the consistent case, divide row 2 by $-2$ and clear column 2:

$$
\left[\begin{array}{rrr|r}1&4&3&1\\0&-2&-2&0\\0&0&0&0\end{array}\right]
\xrightarrow{-\frac12R_2,\;R_1-4R_2}
\left[\begin{array}{rrr|r}1&0&-1&1\\0&1&1&0\\0&0&0&0\end{array}\right].
$$

5. With $x_3=t$, the solutions are $x_1=1+t$, $x_2=-t$, $x_3=t$. Applying the same RREF
equations to the homogeneous system and choosing $t=1$ gives
$\mathbf{a}_1-\mathbf{a}_2+\mathbf{a}_3=\mathbf{0}$, which is the stated visible relation.
::::
:::

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 165 150"
     role="img" aria-label="M1 has a pivot in every row and every column">
<text class="fig-label-em" x="73" y="17">M1</text>
<path class="fig-gridline" d="M45 29H120V104H45ZM70 29V104M95 29V104M45 54H120M45 79H120"/>
<circle class="fig-point" cx="57.5" cy="41.5" r="5"/>
<circle class="fig-point" cx="82.5" cy="66.5" r="5"/>
<circle class="fig-point" cx="107.5" cy="91.5" r="5"/>
<text class="fig-label" x="61" y="126">3 by 3</text>
</svg>
<figcaption>$M_1$: spans yes; independent yes.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 165 150"
     role="img" aria-label="M2 has a pivot in every row but not every column">
<text class="fig-label-em" x="73" y="17">M2</text>
<path class="fig-gridline" d="M32.5 29H132.5V104H32.5ZM57.5 29V104M82.5 29V104M107.5 29V104M32.5 54H132.5M32.5 79H132.5"/>
<circle class="fig-point" cx="45" cy="41.5" r="5"/>
<circle class="fig-point" cx="70" cy="66.5" r="5"/>
<circle class="fig-point" cx="120" cy="91.5" r="5"/>
<text class="fig-label" x="61" y="126">3 by 4</text>
</svg>
<figcaption>$M_2$: spans yes; independent no.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 165 150"
     role="img" aria-label="M3 has a pivot in every column but not every row">
<text class="fig-label-em" x="73" y="14">M3</text>
<path class="fig-gridline" d="M45 20H120V120H45ZM70 20V120M95 20V120M45 45H120M45 70H120M45 95H120"/>
<circle class="fig-point" cx="57.5" cy="32.5" r="5"/>
<circle class="fig-point" cx="82.5" cy="57.5" r="5"/>
<circle class="fig-point" cx="107.5" cy="82.5" r="5"/>
<text class="fig-label" x="61" y="141">4 by 3</text>
</svg>
<figcaption>$M_3$: spans no; independent yes.</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 165 150"
     role="img" aria-label="M4 lacks a pivot in every row and every column">
<text class="fig-label-em" x="73" y="17">M4</text>
<path class="fig-gridline" d="M45 29H120V104H45ZM70 29V104M95 29V104M45 54H120M45 79H120"/>
<circle class="fig-point" cx="57.5" cy="41.5" r="5"/>
<circle class="fig-point" cx="82.5" cy="66.5" r="5"/>
<text class="fig-label" x="61" y="126">3 by 3</text>
</svg>
<figcaption>$M_4$: spans no; independent no.</figcaption>
</figure>

</div>

### Shortcuts that prove a negative

Some verdicts can be reached before row reduction.

- **More vectors than entries forces dependence.** More than $m$ vectors in
  $\mathbb{R}^m$ means more columns than rows, so there cannot be a pivot in every column.
- **A set containing the zero vector is dependent.** Give the zero vector coefficient $1$
  and every other vector coefficient $0$.
- **A visible multiple or visible relation proves dependence.** If
  $\mathbf{v}_3=2\mathbf{v}_1-\mathbf{v}_2$, then
  $2\mathbf{v}_1-\mathbf{v}_2-\mathbf{v}_3=\mathbf{0}$ is already a nontrivial relation.
- **Fewer vectors than entries cannot span.** Fewer than $m$ vectors in
  $\mathbb{R}^m$ means fewer columns than rows, so there cannot be a pivot in every row.

:::callout-pitfall[The shortcuts point only one way]
Every shortcut above proves a **negative** answer: dependent or does not span. Failing to
spot a zero vector, a multiple, or an obvious relation proves nothing positive. Nothing
short of a valid reduction proves independence or spanning. “I do not see a relation” is
not evidence that no relation exists.
:::

### Keep $A$ separate from $\mathbf{b}$

Consistency is a fact about the pair $(A,\mathbf{b})$. Independence is a fact about the
columns of $A$ alone. Changing the right-hand side can reverse the consistency verdict, but
it cannot move a pivot column of $A$ or change a dependence relation among those columns.

Matrix $M_4$ makes the separation exact. Under both right-hand sides its columns obey
$\mathbf{a}_1+\mathbf{a}_3=\mathbf{a}_2$, so the columns are dependent in both systems.
Yet $(1,0,0)^T$ produces $0=1$, while $(1,2,3)^T$ produces $0=0$. The coefficient matrix
did not change; only the target's compatibility with its range changed.

There is one free lunch. If $A$ has a pivot in every row, then $A\mathbf{x}=\mathbf{b}$ is
consistent for every $\mathbf{b}$. No zero row of $A$ exists for an inconsistency to live
in, so there is no need to carry a particular augmented column through the reduction.

### The only shape of inconsistency

There is exactly one way for a linear system to be inconsistent: row reduction produces

$$
\left[\begin{array}{cccc|c}0&0&\cdots&0&c\end{array}\right],
\qquad c\ne0.
$$

The row reads $0=c$. Every inconsistent system, however complicated it looked at the
start, ends with this same refusal.

The cause is a dependence among the **rows** of $A$. A zero row means that some nonzero
combination $\mathbf{y}$ of the original equations cancels every coefficient on the left.
Any genuine solution must make the same combination of the right-hand sides cancel, so it
must satisfy $\mathbf{y}\mathbin{\boldsymbol{\cdot}}\mathbf{b}=0$. Inconsistency is exactly
$\mathbf{b}$ refusing that constraint. The row operations that create the zero row record
the coefficients of $\mathbf{y}$, so finding the compatibility equation costs no extra
reduction.

For example, let

$$
M_5=\begin{bmatrix}1&1&0\\0&1&1\\1&2&1\end{bmatrix}.
$$

Its rows satisfy $\mathbf{r}_1+\mathbf{r}_2=\mathbf{r}_3$. Apply precisely that relation to
the augmented matrix:

$$
\left[\begin{array}{rrr|r}1&1&0&b_1\\0&1&1&b_2\\1&2&1&b_3\end{array}\right]
\xrightarrow{R_3-R_1-R_2}
\left[\begin{array}{rrr|r}1&1&0&b_1\\0&1&1&b_2\\0&0&0&b_3-b_1-b_2\end{array}\right].
$$

Thus consistency requires $b_3=b_1+b_2$. For $(b_1,b_2,b_3)=(1,2,5)$, the last row is
$0=2$, so the system is inconsistent. For $(1,2,3)$, the last row is $0=0$, so the system
is consistent. The operation $R_3-R_1-R_2$ has simultaneously found the zero row and the
row-dependence vector $\mathbf{y}=(-1,-1,1)^T$.

### Span, range, and consistency are one statement

For the linear transformation $T(\mathbf{x})=A\mathbf{x}$,

$$
\operatorname{range}(T)
=\{A\mathbf{x}:\mathbf{x}\in\mathbb{R}^n\}
=\operatorname{Span}\{\mathbf{a}_1,\ldots,\mathbf{a}_n\}.
$$

Therefore “$\mathbf{b}$ is not in the range of $T$,” “$\mathbf{b}$ is not in the span of
the columns,” and “$A\mathbf{x}=\mathbf{b}$ is inconsistent” are one statement in three
dialects.

For $M_3$, the row relation is

$$
\mathbf{r}_1+\mathbf{r}_2+\mathbf{r}_3-\mathbf{r}_4=\mathbf{0}.
$$

It forces every output $\mathbf{b}=M_3\mathbf{x}$ to obey
$b_1+b_2+b_3-b_4=0$. Hence

$$
\operatorname{range}(T)
=\left\{\mathbf{b}\in\mathbb{R}^4:b_4=b_1+b_2+b_3\right\}.
$$

The row relation is literally the equation defining the range. Once it is known, testing a
new $\mathbf{b}$ against $b_4=b_1+b_2+b_3$ replaces another reduction.

### Three planes and the missing common point

Each row of a three-variable system is the normal vector to a plane in $\mathbb{R}^3$.
When the three row normals are coplanar, the planes share a common direction. Looking along
that direction turns the planes into lines in a two-dimensional cross-section.

<div class="fig-grid">

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 190 175"
     role="img" aria-label="Three concurrent lines representing three planes that share a line">
<text class="fig-label-em" x="66" y="20">consistent</text>
<path class="fig-curve" d="M25 139L165 43"/>
<path class="fig-axis" d="M25 43L165 139"/>
<path class="fig-guide" d="M18 91H172"/>
<circle class="fig-point" cx="95" cy="91" r="5"/>
<text class="fig-label" x="151" y="45">E1</text>
<text class="fig-label" x="151" y="143">E2</text>
<text class="fig-label" x="158" y="85">E3</text>
</svg>
<figcaption>consistent — planes share a line</figcaption>
</figure>

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 190 175"
     role="img" aria-label="Three lines forming a triangle represent planes forming a triangular prism">
<text class="fig-label-em" x="60" y="20">inconsistent</text>
<path class="fig-curve" d="M25 139L165 43"/>
<path class="fig-axis" d="M25 43L165 139"/>
<path class="fig-guide" d="M18 78H172"/>
<circle class="fig-point" cx="76" cy="78" r="4"/>
<circle class="fig-point" cx="127" cy="78" r="4"/>
<circle class="fig-point" cx="101.5" cy="95.5" r="4"/>
<path class="fig-guide" d="M76 78L127 78L101.5 95.5Z"/>
<text class="fig-label" x="151" y="45">E1</text>
<text class="fig-label" x="151" y="143">E2</text>
<text class="fig-label" x="158" y="72">E3</text>
</svg>
<figcaption>inconsistent — triangular prism</figcaption>
</figure>

</div>

The left panel represents three planes sharing one line of solutions. In the right panel,
each pair of planes still meets, but the three intersection lines are parallel and distinct;
together the planes form the sides of a triangular prism and have no common point. Matrix
$M_5$ with $\mathbf{b}=(1,2,5)^T$ is this triangle case because no two of its row normals
are proportional, yet the third normal is the sum of the first two.

There is no analogous prism case for lines in $\mathbb{R}^2$. Two dependent nonzero vectors
in the plane must be parallel, so dependent row normals there produce parallel lines rather
than three pairwise intersections running along a common direction.

The complete classification for three planes in $\mathbb{R}^3$ is:

| pivots in $A$ | consistency | geometric configuration | number of solutions |
|---:|---|---|---:|
| 3 | always consistent | three planes meet at one point | exactly 1 |
| 2 | consistent | three planes share one line | infinitely many |
| 2 | inconsistent | a proportional row pair gives parallel sheets; with no proportional pair, the planes form a triangular prism | 0 |
| 1 | consistent | all three equations describe the same plane | infinitely many |
| 1 | inconsistent | at least two distinct parallel planes | 0 |

The tiebreak in the two-pivot inconsistent case is visible before a full reduction. A
proportional pair of rows gives two parallel sheets. If no pair is proportional, every pair
of planes meets, but the three meetings fail to coincide: that is the prism.

:::callout-pitfall[Close the remaining traps]
- The number of solutions is always **zero, exactly one, or infinitely many**. A free
  variable ranges over all real numbers, so a linear system can never have exactly two,
  seventeen, or any other finite number greater than one.
- A homogeneous system is never inconsistent because $\mathbf{x}=\mathbf{0}$ always solves
  $A\mathbf{x}=\mathbf{0}$.
- For a square matrix, “pivot in every row” and “pivot in every column” collapse into the
  same condition. For a non-square matrix they are independent, as $M_2$ and $M_3$ show.
- Reduce $A$ alone when testing independence. Carry $\mathbf{b}$ only when consistency is
  at issue and $A$ fails to have a pivot in every row; if every row already has a pivot,
  consistency for every $\mathbf{b}$ is automatic.
:::

### Practice problems

:::problem[Problem 1.45 — Read a square pivot pattern]{difficulty=easy}
An echelon form of a $3\times3$ matrix $A$ has pivots in columns 1 and 2 and a zero third
row. Without reducing again, decide whether the columns span $\mathbb{R}^3$, whether they
are independent, and how many solutions $A\mathbf{x}=\mathbf{0}$ has.


::::solution[Solution]
**Answer:** Does not span $\mathbb R^3$; dependent columns; infinitely many homogeneous solutions.

1. The columns do **not** span $\mathbb{R}^3$ because there is no pivot in every row. They are
**dependent** because there is no pivot in every column. The homogeneous system is
consistent and has one free variable, so it has **infinitely many solutions**.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 1.46 — Read an augmented pivot]{difficulty=easy}
Row reduction of $[A\mid\mathbf{b}]$ produces

$$
\left[\begin{array}{rrr|r}1&0&2&4\\0&1&-1&3\\0&0&0&5\end{array}\right].
$$

What can you conclude about consistency and about the independence of the three columns of
$A$?


::::solution[Solution]
**Answer:** Inconsistent system; dependent coefficient columns.

1. The pivot in the augmented column makes the system **inconsistent**. Within $A$, only
columns 1 and 2 are pivot columns, so the three columns are **linearly dependent**. These
are separate verdicts: the first concerns $(A,\mathbf{b})$, while the second concerns $A$.

2. Finally, substitute the stated result into each original equation, or read a zero-equals-nonzero row to reject an inconsistent system.
::::
:::

:::problem[Problem 1.47 — A wide matrix]{difficulty=easy}
A $2\times4$ matrix has pivots in columns 1 and 3. Decide whether its columns span
$\mathbb{R}^2$, whether they are independent, and how many solutions
$A\mathbf{x}=\mathbf{b}$ has for each $\mathbf{b}\in\mathbb{R}^2$.


::::solution[Solution]
**Answer:** Columns span $\mathbb R^2$ but are dependent; infinitely many solutions for every $\mathbf b$.

1. Two pivots fill both rows, so the columns **span $\mathbb{R}^2$** and every
$\mathbf{b}\in\mathbb{R}^2$ is reachable. Two nonpivot columns give two free variables, so
the columns are **dependent** and every system has **infinitely many solutions**.

2. Check the pivot count against the claimed dimension, and distinguish a pivot in each row (spanning) from a pivot in each column (independence).
::::
:::

:::problem[Problem 1.48 — Reduce and read every verdict]{difficulty=standard}
Reduce the augmented matrix, solve the system, and decide whether the columns of $A$ span
$\mathbb{R}^3$ and whether they are independent:

$$
\left[\begin{array}{rrr|r}1&1&1&3\\2&3&1&7\\1&2&0&4\end{array}\right].
$$


::::solution[Solution]
**Answer:** $\mathbf x=(2-2t,\ 1+t,\ t)^T$; consistent with infinitely many solutions; columns neither span $\mathbb R^3$ nor are independent.

1. Clear column 1, then compare rows 2 and 3:

$$
\left[\begin{array}{rrr|r}1&1&1&3\\2&3&1&7\\1&2&0&4\end{array}\right]
\xrightarrow{R_2-2R_1,\;R_3-R_1}
\left[\begin{array}{rrr|r}1&1&1&3\\0&1&-1&1\\0&1&-1&1\end{array}\right]
\xrightarrow{R_3-R_2}
\left[\begin{array}{rrr|r}1&1&1&3\\0&1&-1&1\\0&0&0&0\end{array}\right].
$$

2. Now clear above the second pivot:

$$
\xrightarrow{R_1-R_2}
\left[\begin{array}{rrr|r}1&0&2&2\\0&1&-1&1\\0&0&0&0\end{array}\right].
$$

3. Let $x_3=t$. Then

$$
x_1=2-2t,\qquad x_2=1+t,\qquad x_3=t.
$$

4. The system is consistent with infinitely many solutions. There is neither a pivot in every
row nor a pivot in every column, so the columns neither span $\mathbb{R}^3$ nor are
independent.
::::
:::

:::problem[Problem 1.49 — Find the dependence relation]{difficulty=standard}
Find a nontrivial dependence relation among

$$
\mathbf{v}_1=\begin{pmatrix}1\\0\\2\end{pmatrix},\qquad
\mathbf{v}_2=\begin{pmatrix}2\\1\\5\end{pmatrix},\qquad
\mathbf{v}_3=\begin{pmatrix}0\\1\\1\end{pmatrix}.
$$


::::solution[Solution]
**Answer:** $2\mathbf v_1-\mathbf v_2+\mathbf v_3=\mathbf0$.

1. Multiply each matrix row by the input column, adding all component products. Check the output dimension against the number of matrix rows.

2. Put the vectors in the columns and solve the homogeneous system:

$$
\left[\begin{array}{rrr|r}1&2&0&0\\0&1&1&0\\2&5&1&0\end{array}\right]
\xrightarrow{R_3-2R_1}
\left[\begin{array}{rrr|r}1&2&0&0\\0&1&1&0\\0&1&1&0\end{array}\right]
\xrightarrow{R_3-R_2}
\left[\begin{array}{rrr|r}1&2&0&0\\0&1&1&0\\0&0&0&0\end{array}\right].
$$

3. Choose $x_3=1$. Then $x_2=-1$ and $x_1=2$, giving

$$
2\mathbf{v}_1-\mathbf{v}_2+\mathbf{v}_3=\mathbf{0}.
$$
::::
:::

:::problem[Problem 1.50 — Test membership in a range]{difficulty=standard}
For $T(\mathbf{x})=M_3\mathbf{x}$, decide without row reduction whether

$$
\mathbf{u}=\begin{pmatrix}4\\-1\\2\\5\end{pmatrix}
\qquad\text{and}\qquad
\mathbf{v}=\begin{pmatrix}4\\-1\\2\\6\end{pmatrix}
$$

belong to $\operatorname{range}(T)$. If a vector belongs, state its preimage.


::::solution[Solution]
**Answer:** $\mathbf u=(4,-1,2,5)^T$ is in the range, with preimage $(4,-1,2)^T$; $\mathbf v=(4,-1,2,6)^T$ is not.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. The range equation is $b_4=b_1+b_2+b_3$. For $\mathbf{u}$,
$4+(-1)+2=5=u_4$, so $\mathbf{u}$ belongs to the range, and its unique preimage is
$(4,-1,2)^T$. For $\mathbf{v}$, the first three entries still sum to $5$, not $6$, so
$\mathbf{v}$ does not belong to the range.
::::
:::

:::problem[Problem 1.51 — Classify three planes]{difficulty=challenge}
Three planes in $\mathbb{R}^3$ have a coefficient matrix with two pivots. The system is
inconsistent, and no pair of coefficient rows is proportional. What is the geometric
configuration? What would change if one pair of rows were proportional?


::::solution[Solution]
**Answer:** Three pairwise-intersecting planes with no common intersection (triangular-prism configuration); if one pair of normals is proportional, that pair is parallel.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. With two pivots the row normals are dependent but span a two-dimensional set. Because no
pair is proportional, every pair of planes meets, while inconsistency prevents one common
line; the three planes form a **triangular prism** configuration. If one pair of rows were
proportional, that pair of planes would instead be distinct parallel sheets, which already
explains the inconsistency.
::::
:::

## Chapter Summary

### Key results

#### 1.1 Systems of linear equations

**A linear equation** in the variables $x_1, x_2, \ldots, x_n$ is one that can be written

$$
a_1x_1 + a_2x_2 + \cdots + a_nx_n = b
$$

where $b$ and the coefficients $a_1, \ldots, a_n$ are constants. Every variable appears to
 the first power and is never multiplied by another variable, so $x_1^2$, $x_1x_2$ and
 $\sin(x_1)$ each disqualify an equation. A **system** is a collection of such equations
 sharing the same variables, and its **solution set** is the list of every
 $(s_1, \ldots, s_n)$ that satisfies all of them at once.

**Every linear system has exactly one of three outcomes:** no solution (it is
 **inconsistent**), exactly one solution, or infinitely many. Nothing else is possible,
 because two distinct solutions force infinitely many — if $\mathbf{p}$ and $\mathbf{q}$
 both solve the system then so does every blend $t\mathbf{p} + (1-t)\mathbf{q}$, giving the
 whole line through them.

**The three elementary row operations** each leave the solution set unchanged, because each
 is reversible:

- **Replacement:** $R_i \leftarrow R_i + cR_j$ — add a multiple of one row to another.
- **Interchange:** $R_i \leftrightarrow R_j$ — swap two rows.
- **Scaling:** $R_i \leftarrow cR_i$ with $c \neq 0$ — multiply a row by a nonzero constant.
  The constant must be nonzero, or the step cannot be undone.

Two matrices linked by a sequence of these are **row equivalent**, and if the augmented
 matrices of two systems are row equivalent then the systems have the same solution set.
 That theorem is what licenses every arrow you draw in a row reduction.

#### 1.2 Row reduction and echelon forms

**A matrix is in row echelon form (REF)** when all zero rows are at the bottom, each row's
 leading entry lies strictly to the right of the leading entry of the row above, and every
 entry below a leading entry is zero. It is in **reduced row echelon form (RREF)** when, in
 addition, every leading entry is $1$ and each leading $1$ is the only nonzero entry in its
 column. A matrix has **many** row echelon forms but **exactly one** RREF.

**The existence and uniqueness test.** Row-reduce the augmented matrix $[A \mid \mathbf{b}]$
 and read both answers off its shape, without solving for any variable:

- The system is **inconsistent** exactly when some row reads $[\,0\ 0\ \cdots\ 0 \mid c\,]$
  with $c \neq 0$ — that row says $0 = c$.
- If it is consistent, the solution is **unique** when every variable column holds a pivot,
  and there are **infinitely many** solutions when at least one column does not. A column
  without a pivot is a **free variable**.

**Gaussian elimination** stops at REF and finishes by back-substitution;
 **Gauss–Jordan elimination** carries on to RREF, where the answer is read off directly.
 Same forward elimination, different endgame.

#### 1.3 Vector equations

**A linear combination** of $\mathbf{v}_1, \ldots, \mathbf{v}_p$ with weights
 $c_1, \ldots, c_p$ is the vector $c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + \cdots + c_p\mathbf{v}_p$.
 Weights may be any real numbers, including zero and negatives.

**The span** of $\mathbf{v}_1, \ldots, \mathbf{v}_p$ is the set of **all** such combinations:

$$
\text{Span}\{\mathbf{v}_1, \ldots, \mathbf{v}_p\}
= \{\,c_1\mathbf{v}_1 + \cdots + c_p\mathbf{v}_p \;:\; c_1, \ldots, c_p \in \mathbb{R}\,\}
$$

In $\mathbb{R}^3$: the span of one nonzero vector is the **line** through the origin and that
 vector; the span of two nonzero vectors, neither a multiple of the other, is the **plane**
 through the origin containing both. Every span contains $\mathbf{0}$, so all of them pass
 through the origin.

**Deciding membership.** $\mathbf{b}$ is a linear combination of
 $\mathbf{a}_1, \ldots, \mathbf{a}_n$ **if and only if** the system whose augmented matrix is
 $[\,\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_n \mid \mathbf{b}\,]$ is consistent. That
 matrix is built by standing the vectors side by side as columns — there is nothing to
 compute.

#### 1.4 The matrix equation $A\mathbf{x} = \mathbf{b}$

**The matrix–vector product** is *defined* as the linear combination of the columns of $A$
 with weights taken from $\mathbf{x}$:

$$
A\mathbf{x} = \begin{bmatrix}\mathbf{a}_1 & \mathbf{a}_2 & \cdots & \mathbf{a}_n\end{bmatrix}
\begin{pmatrix}x_1\\x_2\\\vdots\\x_n\end{pmatrix}
= x_1\mathbf{a}_1 + x_2\mathbf{a}_2 + \cdots + x_n\mathbf{a}_n
$$

Equivalently, by the **row–vector rule**, the $i$-th entry of $A\mathbf{x}$ is the dot
 product of row $i$ of $A$ with $\mathbf{x}$. The product is **defined only when the number
 of columns of $A$ equals the number of entries in $\mathbf{x}$**: if $A$ is $m \times n$
 then $\mathbf{x} \in \mathbb{R}^n$ and $A\mathbf{x} \in \mathbb{R}^m$.

**Two theorems that are easy to confuse — read which one is being asked.**

- **For one particular $\mathbf{b}$:** $A\mathbf{x} = \mathbf{b}$ has a solution $\iff$
  $\mathbf{b}$ is a linear combination of the columns of $A$ $\iff$
  $\mathbf{b} \in \text{Span}\{\mathbf{a}_1, \ldots, \mathbf{a}_n\}$ $\iff$
  $[A \mid \mathbf{b}]$ has **no pivot in the last column**.
- **For every $\mathbf{b} \in \mathbb{R}^m$ at once:** $A\mathbf{x} = \mathbf{b}$ is solvable
  for all $\mathbf{b}$ $\iff$ the columns of $A$ span $\mathbb{R}^m$ $\iff$ **$A$ has a pivot
  position in every row**. This is a statement about $A$, **not** about
  $[A \mid \mathbf{b}]$, and the condition is on **rows**, not columns.

A consequence worth carrying: an $m \times n$ matrix has at most $\min(m,n)$ pivots, so if
 $n < m$ its columns can never span $\mathbb{R}^m$. Three vectors cannot span $\mathbb{R}^4$.

**Linearity.** For any $\mathbf{u}, \mathbf{v} \in \mathbb{R}^n$ and scalar $c$:

$$
A(\mathbf{u} + \mathbf{v}) = A\mathbf{u} + A\mathbf{v}, \qquad A(c\mathbf{u}) = c(A\mathbf{u})
$$

And $I_n\mathbf{x} = \mathbf{x}$, where the **identity matrix** $I_n$ is $n \times n$ with
 $1$s on the main diagonal and $0$s elsewhere.

#### 1.5 Solution sets

**A homogeneous system** is one of the form $A\mathbf{x} = \mathbf{0}$. It is **always**
 consistent, since $\mathbf{x} = \mathbf{0}$ — the **trivial solution** — always works. So the
 only open question is uniqueness: it has a **nontrivial** solution **if and only if** the
 system has at least one free variable.

**Parametric vector form.** A solution set written as a linear combination of fixed vectors,
 with the free variables as the parameters, is in parametric vector form. For a homogeneous
 system the number of free variables is the dimension of the solution set: none gives the
 single point $\mathbf{0}$, one gives a line through the origin, two give a plane.

**Structure of the general solution.** If $A\mathbf{x} = \mathbf{b}$ is consistent and
 $\mathbf{p}$ is any one solution, then the complete solution set is

$$
\{\,\mathbf{p} + \mathbf{v}_h \;:\; A\mathbf{v}_h = \mathbf{0}\,\}
$$

that is, every solution is that particular solution plus a solution of the associated
 homogeneous system. Geometrically the solution set of $A\mathbf{x} = \mathbf{b}$ is the
 solution set of $A\mathbf{x} = \mathbf{0}$ **translated by $\mathbf{p}$** — same shape, same
 direction vectors, shifted off the origin. Note $\mathbf{p}$ is not unique, but the set is,
 and the theorem applies **only** when the system is consistent.

#### 1.7 Linear independence

**A set $\{\mathbf{v}_1, \ldots, \mathbf{v}_p\}$ is linearly independent** when the only
 solution of

$$
c_1\mathbf{v}_1 + c_2\mathbf{v}_2 + \cdots + c_p\mathbf{v}_p = \mathbf{0}
$$

is $c_1 = c_2 = \cdots = c_p = 0$. If any solution has some $c_i \neq 0$ the set is
 **linearly dependent**, and that relation writes one of the vectors in terms of the others.

**The test** is row reduction: the columns of $A$ are linearly independent exactly when
 $A\mathbf{x} = \mathbf{0}$ has only the trivial solution, that is, when **every column of
 $A$ holds a pivot** and there are no free variables.

**Any set of more than $n$ vectors in $\mathbb{R}^n$ is automatically dependent** — more
 columns than rows means more columns than possible pivots, so some column is free.

#### 1.8–1.9 Linear transformations

**A transformation $T : \mathbb{R}^n \to \mathbb{R}^m$ is linear** when, for all
 $\mathbf{u}, \mathbf{v}$ in $\mathbb{R}^n$ and all scalars $c, d$:

$$
T(c\mathbf{u} + d\mathbf{v}) = c\,T(\mathbf{u}) + d\,T(\mathbf{v})
$$

Two consequences fall straight out: $T(\mathbf{0}) = \mathbf{0}$, and multiplication by any
 matrix is a linear transformation.

**The standard matrix.** Every linear transformation from $\mathbb{R}^n$ to $\mathbb{R}^m$ is
 multiplication by exactly one matrix, obtained by feeding it the standard basis vectors:

$$
A = \begin{bmatrix} T(\mathbf{e}_1) & T(\mathbf{e}_2) & \cdots & T(\mathbf{e}_n)\end{bmatrix}
$$

where $\mathbf{e}_j$ has a $1$ in position $j$ and $0$s elsewhere. The columns of $A$ are the
 images of the standard basis vectors — that is the whole construction.

**One-to-one and onto**, both read off the same reduction:

- $T$ is **one-to-one** (distinct inputs give distinct outputs) $\iff$ $A\mathbf{x} =
  \mathbf{0}$ has only the trivial solution $\iff$ the columns of $A$ are linearly
  independent $\iff$ **every column has a pivot** (no free variables).
- $T$ is **onto** (every $\mathbf{b} \in \mathbb{R}^m$ is hit) $\iff$ the columns of $A$ span
  $\mathbb{R}^m$ $\iff$ **every row has a pivot**.

Columns for one-to-one, rows for onto.

### If you remember nothing else

Every question in this chapter — "does a solution exist?", "is this vector in the span?",
 "are these vectors independent?", "is this transformation one-to-one?" — is answered by
 the same act: **row-reduce the augmented (or plain) matrix and count the pivots**.
:::

## Mixed Practice

Problems spanning the whole chapter. Attempt before checking solutions.

:::problem[Problem M.1 — Determine the solution set]{difficulty=easy}
Rewrite the vector equation $x_1\begin{pmatrix}2\\-1\end{pmatrix}+x_2\begin{pmatrix}0\\3\end{pmatrix}=\begin{pmatrix}4\\5\end{pmatrix}$ as a linear system and solve it.


::::solution[Solution]
**Answer:** $x_1=2,\quad x_2=\tfrac73$.

1. Write one row per equation, keep variables in the stated column order, and perform invertible row replacements on the entire augmented matrix, including constants.

2. System: $2x_1 = 4$ and $-x_1+3x_2=5$. From row 1: $x_1=2$. Then $-2+3x_2=5\Rightarrow x_2=\frac{7}{3}$.

3. Substitution checks both coordinates of the original vector equation: $2(2)+0(7/3)=4$ and $(-1)(2)+3(7/3)=-2+7=5$. Thus the displayed weights solve the given system.
::::
:::

:::problem[Problem M.2 — Test independence]{difficulty=standard}
Find a value of $c$ that makes the columns of $A=\begin{bmatrix}1&2&c\\0&1&3\\0&0&c-2\end{bmatrix}$ linearly dependent.


::::solution[Solution]
**Answer:** $c=2$.

1. Identify the input conditions and the appropriate matrix or vector-space definition before carrying out the computation.

2. The matrix is already upper triangular. Its columns are linearly independent iff all diagonal entries (pivots) are nonzero. The (3,3) entry is $c-2$; set it to zero: $c = 2$. With $c=2$, the third column produces a zero row — free variable, so the columns are **linearly dependent**.
::::
:::

:::problem[Problem M.3 — Find the standard matrix]{difficulty=standard}
A linear transformation $T:\mathbb{R}^2\to\mathbb{R}^2$ satisfies $T\begin{pmatrix}1\\0\end{pmatrix}=\begin{pmatrix}2\\5\end{pmatrix}$ and $T\begin{pmatrix}0\\1\end{pmatrix}=\begin{pmatrix}-1\\3\end{pmatrix}$. Find $T\begin{pmatrix}4\\-2\end{pmatrix}$.


::::solution[Solution]
**Answer:** $A=\begin{bmatrix}2&-1\\5&3\end{bmatrix}$ and $T(4,-2)^T=(10,14)^T$.

1. For a linear transformation, apply the defining input-output rule or compute the images of the standard basis vectors. Check the zero-output or pivot condition when one-to-one or onto is asked.

2. Standard matrix: $A=\begin{bmatrix}2&-1\\5&3\end{bmatrix}$.

$$
T\begin{pmatrix}4\\-2\end{pmatrix}=A\begin{pmatrix}4\\-2\end{pmatrix}=\begin{pmatrix}8+2\\20-6\end{pmatrix}=\begin{pmatrix}10\\14\end{pmatrix}
$$

3. Check the two row products independently: $2(4)+(-1)(-2)=8+2=10$ and $5(4)+3(-2)=20-6=14$. Both coordinates match the claimed image.
::::
:::

:::problem[Problem M.4 — Recognize echelon form]{difficulty=standard}
Let $A=\begin{bmatrix}1&-2&0&3\\0&0&1&-1\\0&0&0&0\end{bmatrix}$ and $\mathbf{b}=\begin{pmatrix}5\\-2\\0\end{pmatrix}$. Find the general solution of $A\mathbf{x}=\mathbf{b}$ in parametric form.


::::solution[Solution]
**Answer:** $\mathbf x=(5,0,-2,0)^T+s(2,1,0,0)^T+t(-3,0,1,1)^T$.

1. This is already in REF (pivot columns 1 and 3). Free variables: $x_2=s$, $x_4=t$.

2. Row 2: $x_3 - t = -2 \Rightarrow x_3 = -2+t$.

3. Row 1: $x_1 - 2s + 3t = 5 \Rightarrow x_1 = 5+2s-3t$.

$$
\mathbf{x}=\begin{pmatrix}5\\0\\-2\\0\end{pmatrix}+s\begin{pmatrix}2\\1\\0\\0\end{pmatrix}+t\begin{pmatrix}-3\\0\\1\\1\end{pmatrix}
$$
::::
:::

:::problem[Problem M.5 — Test consistency]{difficulty=challenge}
Suppose the columns of an $m\times n$ matrix $A$ span $\mathbb{R}^m$.
 What can you conclude about the relationship between $m$ and $n$?
 What can you say about whether the system $A\mathbf{x}=\mathbf{b}$ is consistent?


::::solution[Solution]
**Answer:** $n\ge m$; $A\mathbf x=\mathbf b$ is consistent for every $\mathbf b\in\mathbb R^m$.

1. If the columns span $\mathbb{R}^m$, then $A$ has a pivot in every row — so there are at least $m$ pivot positions.
 Since pivot positions correspond to columns, we need at least $m$ columns: $n \geq m$.

2. Because there's a pivot in every row, the system $A\mathbf{x}=\mathbf{b}$ is consistent *for every* $\mathbf{b}\in\mathbb{R}^m$ — this is exactly the definition of $T(\mathbf{x})=A\mathbf{x}$ being onto.
::::
:::

:::problem[Problem M.6 — Find the standard matrix]{difficulty=challenge}
Let $T:\mathbb{R}^2\to\mathbb{R}^2$ be the transformation that first reflects across
 the $x_1$-axis and then rotates $90°$ counterclockwise. Find the standard matrix
 of the composed transformation.


::::solution[Solution]
**Answer:** $QR=\begin{bmatrix}0&1\\1&0\end{bmatrix}$, the reflection across $x_1=x_2$.

1. Reflection across $x_1$-axis: $R=\begin{bmatrix}1&0\\0&-1\end{bmatrix}$.

2. Rotation $90°$ CCW: $Q=\begin{bmatrix}0&-1\\1&0\end{bmatrix}$.

3. The composed transformation applies $R$ first, then $Q$: the standard matrix is $QR$ (right-to-left composition).

$$
QR=\begin{bmatrix}0&-1\\1&0\end{bmatrix}\begin{bmatrix}1&0\\0&-1\end{bmatrix}=\begin{bmatrix}0&1\\1&0\end{bmatrix}
$$

4. This is reflection across the line $x_1 = x_2$.
::::
:::

---

Chapter 1 · Linear Algebra · Based on MA 3113, Mississippi State University.
 Primary source: Dr. Seongjai Kim's lecture notes.
