---
source: "markdown"
title: "Practice Quiz 1 B: Comprehensive Coverage"
crumb: "Linear Algebra · Chapter 5 quiz prep"
meta:
  - "MA 3113 · Pant · no calculator"
  - "Time limit: Untimed · comprehensive"
  - "Chapter 5: 5.1–5.3, 5.5, 5.7, 5.9"
---

## Instructions

No calculator. Write enough arithmetic to justify every determinant, eigenspace, and conclusion. Choose exactly one option (A)–(E) on each multiple-choice question; (E) always means “I don't know.” For free response, show the shortest correct by-hand method, including a check when possible. Solutions are collapsed in Lectern; attempt the question before opening one.

### Multiple Choice

:::problem[Problem 1 — Check a proposed scalar with a determinant]{difficulty=easy}

Is the proposed scalar an eigenvalue of $A$? Decide without finding an entire eigenspace.

$$
A=\begin{bmatrix}1&2\\2&1\end{bmatrix}
$$

Given $\lambda=-1$.

(A) Yes; $-1$ is an eigenvalue.

(B) No; the proposed scalar is not an eigenvalue.

(C) Yes; only because the trace equals the scalar.

(D) No; a nonzero determinant proves the scalar is an eigenvalue.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Yes; $-1$ is an eigenvalue.

1. Substitute the **given scalar** into $A-\lambda I$; there is no need to solve a general characteristic polynomial: 
   
   $$
   A-(-1)I=\begin{bmatrix}2&2\\2&2\end{bmatrix}
   $$

2. Take the determinant: $\det(A-(-1)I)=0$. A zero determinant means the homogeneous equation has a nonzero solution.

3. The determinant is zero, so the proposed scalar is an eigenvalue.

4. Check: the conclusion uses the Invertible Matrix Theorem rather than mistaking any number on the matrix diagonal for an eigenvalue.

::::

:::
:::problem[Problem 2 — Why zero is excluded]{difficulty=easy}

For the displayed matrix, could the zero vector itself be an eigenvector? Explain the definition.

$$
A=\begin{bmatrix}0&0\\0&5\end{bmatrix}
$$

(A) The zero vector is an eigenvector for every eigenvalue.

(B) The zero vector cannot be an eigenvector.

(C) The zero vector is an eigenvector only for $\lambda=0$.

(D) The zero vector is an eigenvector only for singular matrices.

(E) I don't know

::::solution[Solution]
**Answer:** (B) The zero vector cannot be an eigenvector.

1. Use the literal definition: an eigenvector must be **nonzero** and satisfy $A\mathbf v=\lambda\mathbf v$.

2. Every matrix satisfies $A\mathbf0=\mathbf0$, and every scalar satisfies $\lambda\mathbf0=\mathbf0$. That identity would not distinguish any eigenvalue.

3. The definition therefore excludes zero, even when $A$ is singular and $0$ is a legitimate **eigenvalue**.

4. Check: an eigenspace does contain the zero vector as part of its null space, but that does not make zero a member of an eigenvector basis.

::::

:::
:::problem[Problem 3 — Repeated diagonal root in a lower triangle]{difficulty=easy}

Find all eigenvalues of $A$. Use the quickest valid method.

$$
A=\begin{bmatrix}4&0&0\\1&4&0\\0&2&-2\end{bmatrix}
$$

(A) Eigenvalues: $-1,5,5$.

(B) Eigenvalues: $-3,3,3$.

(C) Eigenvalues: $-2,4,4$.

(D) Eigenvalues: $2,-4,-4$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Eigenvalues: $-2,4,4$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}4 - \lambda&0&0\\1&4 - \lambda&0\\0&2&- \lambda - 2\end{bmatrix}
   $$

2. The shifted matrix is triangular. Its determinant is the product of its diagonal entries, so no cofactor expansion or symbolic row reduction is required.

3. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 6 \lambda^{2} - 32
   $$

4. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 4\right)^{2} \left(\lambda + 2\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $-2,4,4$.

5. Check: the root sum is $6$, which matches $\operatorname{tr}(A)=6$; their product is $-32=\det A$.

::::

:::
:::problem[Problem 4 — Characteristic polynomial via a middle row]{difficulty=standard}

Compute $\det(A-\lambda I)$.

$$
A=\begin{bmatrix}3&0&1\\0&2&0\\1&0&3\end{bmatrix}
$$

(A) Characteristic polynomial: $- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 17$.

(B) Characteristic polynomial: $- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 15$.

(C) Characteristic polynomial: $\lambda^{3} - 8 \lambda^{2} + 20 \lambda - 16$.

(D) Characteristic polynomial: $- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 16$.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Characteristic polynomial: $- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 16$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}3 - \lambda&0&1\\0&2 - \lambda&0\\1&0&3 - \lambda\end{bmatrix}
   $$

2. Expand along column 2, where 2 entries vanish; the cofactor signs alternate across each row and column.

3. The surviving signed minors give 
   
   $$
   \det(A-\lambda I)=(2 - \lambda)\det\begin{bmatrix}3 - \lambda&1\\1&3 - \lambda\end{bmatrix}
   $$

4. Evaluate each $2\times2$ minor explicitly using $ad-bc$ before expanding: 
   
   $$
   +(2 - \lambda)\left[(3 - \lambda)(3 - \lambda)-(1)(1)\right]
   $$

5. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 16
   $$

6. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 4\right) \left(\lambda - 2\right)^{2}=0.
   $$
   
   
   Thus the roots, including their repetitions, are $2,2,4$.

7. Check: the root sum is $8$, which matches $\operatorname{tr}(A)=8$; their product is $16=\det A$.

::::

:::
:::problem[Problem 5 — Trace and determinant cross-check]{difficulty=easy}

Compute the trace and determinant as an eigenvalue consistency check.

$$
A=\begin{bmatrix}2&1\\1&2\end{bmatrix}
$$

(A) Trace $4$; determinant $3$.

(B) Trace $5$; determinant $3$.

(C) Trace $4$; determinant $4$.

(D) Trace $3$; determinant $4$.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Trace $4$; determinant $3$.

1. The trace is the sum of the main diagonal entries: $\operatorname{tr}(A)=4$.

2. For this $2\times2$ matrix, use $ad-bc$ to find $\det A=3$.

3. As a check, the eigenvalues are $1,3$; their sum and product are respectively the trace and determinant.

4. This cross-check is cheap and catches characteristic-polynomial sign errors before they spread to an eigenspace calculation.

::::

:::
:::problem[Problem 6 — Same roots do not guarantee similarity]{difficulty=standard}

The matrices have the same eigenvalues, with multiplicity. Must they be similar? Decide for this specific pair using eigenspace dimensions.

$$
A=\begin{bmatrix}2&0\\0&2\end{bmatrix}
$$

$$
B=\begin{bmatrix}2&1\\0&2\end{bmatrix}
$$

(A) Similar.

(B) Not similar.

(C) Not similar because one matrix has more entries.

(D) Similar whenever their traces are equal.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Not similar.

1. Both matrices have characteristic roots $2,2$. Equal eigenvalues are necessary for similarity, but **not sufficient**.

2. For each repeated root, compare null-space dimensions. In $A$, the eigenspace dimensions are $2: 2$.

3. In $B$, they are $2: 1$.

4. The dimensions differ, so these matrices cannot be similar. Similar matrices preserve nullity at every eigenvalue.

5. Check: trace and determinant can agree for two matrices that are still not similar. The eigenspace comparison supplies the missing evidence.

::::

:::
:::problem[Problem 7 — Dimension of a defective eigenspace]{difficulty=standard}

What is the geometric multiplicity of the indicated eigenvalue?

$$
A=\begin{bmatrix}3&1\\0&3\end{bmatrix}
$$

Given $\lambda=3$.

(A) Geometric multiplicity: $0$.

(B) Geometric multiplicity: $2$.

(C) Geometric multiplicity: $1$.

(D) Geometric multiplicity: $3$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Geometric multiplicity: $1$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(3)I=\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

2. No row operation is necessary because the nonzero equations already show the pivot and free columns.

3. Pivot columns are 2; free variables are $x_1$. Each free variable supplies one independent eigendirection.

4. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}1\\0\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{3}=1$.

5. Check: $A\mathbf v_1=3\mathbf v_1$ for the displayed basis columns. They also solve the homogeneous equations.

::::

:::
:::problem[Problem 8 — Repeated roots and the diagonalization verdict]{difficulty=standard}

Is $A$ diagonalizable?

$$
A=\begin{bmatrix}1&1&0\\0&1&0\\0&0&4\end{bmatrix}
$$

(A) Diagonalizable.

(B) Not diagonalizable only because its determinant is zero.

(C) Diagonalizable because every repeated root gives enough eigenvectors.

(D) Not diagonalizable.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Not diagonalizable.

1. Compute the characteristic polynomial and factor it: 
   
   $$
   - \left(\lambda - 4\right) \left(\lambda - 1\right)^{2}=0.
   $$
   
   
   The eigenvalues, counted with algebraic multiplicity, are $1,1,4$.

2. For $\lambda=1$, 
   
   $$
   A-\lambda I=\begin{bmatrix}0&1&0\\0&0&0\\0&0&3\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $2$.

3. For $\lambda=4$, 
   
   $$
   A-\lambda I=\begin{bmatrix}-3&1&0\\0&-3&0\\0&0&0\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $1$.

4. The dimensions of the eigenspaces do **not** add to the matrix size; no invertible matrix of eigenvectors $P$ exists.

5. Check: compare geometric multiplicity to algebraic multiplicity for **each** repeated root. The repeated root alone does not decide the verdict.

::::

:::
:::problem[Problem 9 — A block matrix eigenspace]{difficulty=standard}

Which statement gives a basis and dimension for the indicated eigenspace?

$$
A=\begin{bmatrix}3&1&0\\1&3&0\\0&0&2\end{bmatrix}
$$

Given $\lambda=2$.

(A) Basis for $E_{2}$: $(-1,1,0)^T,(0,0,1)^T$; dimension $2$.

(B) Basis for $E_{2}$: $(0,1,0)^T$; dimension $1$.

(C) Basis for $E_{2}$: $(1,1,0)^T$; dimension $1$.

(D) Basis for $E_{2}$: $(-2,1,0)^T$; dimension $1$.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Basis for $E_{2}$: $(-1,1,0)^T,(0,0,1)^T$; dimension $2$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(2)I=\begin{bmatrix}1&1&0\\1&1&0\\0&0&0\end{bmatrix}
   $$

2. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&1&0\\0&0&0\\0&0&0\end{bmatrix}
   $$

3. Pivot columns are 1; free variables are $x_2$, $x_3$. Each free variable supplies one independent eigendirection.

4. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}-1\\1\\0\end{bmatrix},\qquad\begin{bmatrix}0\\0\\1\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{2}=2$.

5. Check: $A\mathbf v_1=2\mathbf v_1$, $A\mathbf v_2=2\mathbf v_2$ for the displayed basis columns. They also solve the homogeneous equations.

::::

:::
:::problem[Problem 10 — Reordered diagonalization columns]{difficulty=standard}

Which pairing of the eigenvector columns of $P$ and diagonal entries of $D$ gives $AP=PD$?

$$
A=\begin{bmatrix}2&1\\0&3\end{bmatrix}
$$

(A) Columns of $P$: $(1,0)^T,(1,1)^T$; diagonal of $D$: $3,2$.

(B) Columns of $P$: $(1,1)^T,(1,0)^T$; diagonal of $D$: $3,2$.

(C) Columns of $P$: $(1,0)^T,(1,1)^T$; diagonal of $D$: $3,4$.

(D) Not diagonalizable.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Columns of $P$: $(1,1)^T,(1,0)^T$; diagonal of $D$: $3,2$.

1. Find the characteristic roots first: 
   
   $$
   \left(\lambda - 3\right) \left(\lambda - 2\right)=0.
   $$
   
   
   The roots are $2,3$.

2. Solve $\operatorname{Nul}(A-(2)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}1\\0\end{bmatrix}
   $$

3. Solve $\operatorname{Nul}(A-(3)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}1\\1\end{bmatrix}
   $$

4. There are 2 independent eigenvectors. Put them in columns of $P$; put their eigenvalues in the **matching** order on the diagonal of $D$: 
   
   $$
   P=\begin{bmatrix}1&1\\1&0\end{bmatrix},\qquad D=\begin{bmatrix}3&0\\0&2\end{bmatrix}
   $$

5. Check multiplication directly, without wasting time finding $P^{-1}$: 
   
   $$
   AP=\begin{bmatrix}3&2\\3&0\end{bmatrix}=PD=\begin{bmatrix}3&2\\3&0\end{bmatrix}
   $$
   
   
   Since $\det P=-1\ne0$, $P$ is invertible and $A=PDP^{-1}$.

::::

:::
:::problem[Problem 11 — Power of a symmetric non-diagonal matrix]{difficulty=challenge}

Compute entry $(1,2)$ of $A^{3}$ without a calculator. Use eigenvalues if helpful.

$$
A=\begin{bmatrix}2&1\\1&2\end{bmatrix}
$$

(A) Entry $(1,2)$ of $A^{3}$: $12$.

(B) Entry $(1,2)$ of $A^{3}$: $14$.

(C) Entry $(1,2)$ of $A^{3}$: $13$.

(D) Entry $(1,2)$ of $A^{3}$: $-13$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Entry $(1,2)$ of $A^{3}$: $13$.

1. Read the requested entry and exponent carefully. A matrix power means **matrix multiplication**, not raising individual entries.

2. Use the shortest structure available: a diagonal matrix stays diagonal, while a matrix with distinct eigenvalues can be written $PD^kP^{-1}$. Its eigenvalues are $1,3$.

3. Find the eigenvector basis and use adjacent cancellations: 
   
   $$
   P=\begin{bmatrix}-1&1\\1&1\end{bmatrix},\qquad D=\begin{bmatrix}1&0\\0&3\end{bmatrix}
   $$
   
   
   Then 
   
   $$
   A^{3}=PD^{3}P^{-1}=\begin{bmatrix}14&13\\13&14\end{bmatrix}
   $$

4. Read position $(1,2)$ from the completed matrix: $13$. Check its location before copying the result.

::::

:::
:::problem[Problem 12 — A real matrix with no real eigenvectors]{difficulty=standard}

Find the (possibly complex) eigenvalues of $A$ exactly.

$$
A=\begin{bmatrix}0&-2\\2&0\end{bmatrix}
$$

(A) Eigenvalues: $0\pm 3i$.

(B) Eigenvalues: $1\pm 2i$.

(C) Eigenvalues: $0\pm 2$.

(D) Eigenvalues: $0\pm 2i$.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Eigenvalues: $0\pm 2i$.

1. Start with $A-\lambda I$ and its $2\times2$ determinant: 
   
   $$
   \begin{bmatrix}- \lambda&-2\\2&- \lambda\end{bmatrix}
   $$
   
   
   The polynomial is $\lambda^{2} + 4$.

2. Complete the square or use the quadratic equation. The equation $\lambda^{2} + 4=0$ has a negative discriminant, so its roots have nonzero imaginary parts.

3. The complex roots are $0\pm 2i$. Because the matrix is real, one conjugate root always accompanies the other.

4. Check: the roots sum to $0$ and their product is $4$, matching the trace and determinant.

::::

:::
:::problem[Problem 13 — Signs in a rotation–scaling block]{difficulty=standard}

Treat $A$ as the real rotation–scaling block. State the scale and the direction of rotation.

$$
A=\begin{bmatrix}1&-2\\2&1\end{bmatrix}
$$

(A) Scale $\sqrt{5}$; counterclockwise rotation.

(B) Scale $\sqrt{5}$; clockwise rotation.

(C) Scale $1$; counterclockwise rotation.

(D) Scale $1 + \sqrt{5}$; counterclockwise rotation.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Scale $\sqrt{5}$; counterclockwise rotation.

1. Identify the real block: 
   
   $$
   A=\begin{bmatrix}1&-2\\2&1\end{bmatrix}
   $$
   
   
   It has the form 
   
   $$
   \begin{bmatrix}a&-b\\b&a\end{bmatrix}
   $$
   
   
   with $a=1$ and $b=2$.

2. The length scale is $r=\sqrt{a^2+b^2}=\sqrt{1+4}=\sqrt{5}$. It is not just the diagonal entry $a$.

3. Because $b>0$, the orientation is counterclockwise. The sine and cosine of the angle are $b/r$ and $a/r$.

4. Check: the determinant is $5=r^2$, as expected for a rotation followed by a uniform stretch.

::::

:::
:::problem[Problem 14 — A clockwise rotation step]{difficulty=standard}

Treat $A$ as the real rotation–scaling block. State the scale and the direction of rotation.

$$
A=\begin{bmatrix}0&1\\-1&0\end{bmatrix}
$$

(A) Scale $1$; counterclockwise rotation.

(B) Scale $1$; clockwise rotation.

(C) Scale $0$; clockwise rotation.

(D) Scale $2$; clockwise rotation.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Scale $1$; clockwise rotation.

1. Identify the real block: 
   
   $$
   A=\begin{bmatrix}0&1\\-1&0\end{bmatrix}
   $$
   
   
   It has the form 
   
   $$
   \begin{bmatrix}a&-b\\b&a\end{bmatrix}
   $$
   
   
   with $a=0$ and $b=-1$.

2. The length scale is $r=\sqrt{a^2+b^2}=\sqrt{0+1}=1$. It is not just the diagonal entry $a$.

3. Because $b<0$, the orientation is clockwise. The sine and cosine of the angle are $b/r$ and $a/r$.

4. Check: the determinant is $1=r^2$, as expected for a rotation followed by a uniform stretch.

::::

:::
:::problem[Problem 15 — Exponential factor along an eigendirection]{difficulty=standard}

If the state lies along the given eigenvector, which exponential time factor solves $\mathbf{x}\prime=A\mathbf{x}$?

$$
A=\begin{bmatrix}2&0\\0&-3\end{bmatrix}
$$

$$
\mathbf v=\begin{bmatrix}0\\1\end{bmatrix}
$$
Given $\lambda=-3$.

(A) Mode: $e^{-2 t}$ along the proposed eigendirection.

(B) Mode: $e^{3 t}$ along the proposed eigendirection.

(C) Mode: $e^{-3 t}$ along the proposed eigendirection.

(D) Mode: $t^{-3}$ along the proposed eigendirection.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Mode: $e^{-3 t}$ along the proposed eigendirection.

1. First multiply the matrix by the proposed direction: 
   
   $$
   A\mathbf v=\begin{bmatrix}0\\-3\end{bmatrix}
   $$

2. Since this equals $-3\mathbf v$, the direction is an eigenvector and the scalar equation for its coefficient is $c\prime=-3c$.

3. The solution to this scalar differential equation is $c(t)=c(0)e^{-3t}$, so the mode contains the displayed exponential factor.

4. Check by differentiation: the derivative multiplies this mode by $-3$, exactly matching $A\mathbf v$.

::::

:::
:::problem[Problem 16 — An exponentially decaying spiral]{difficulty=standard}

Classify the trajectories near the origin of $\mathbf{x}\prime=A\mathbf{x}$. Do not solve for coefficients.

$$
A=\begin{bmatrix}-1&-1\\1&-1\end{bmatrix}
$$

(A) Trajectory: Saddle.

(B) Trajectory: Stable node.

(C) Trajectory: Unstable node.

(D) Trajectory: Inward spiral.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Trajectory: Inward spiral.

1. Inspect the eigenvalues without solving for constants: $-1 - i,-1 + i$. For a diagonal or triangular matrix, they are its diagonal entries.

2. Positive real parts make exponential modes grow; negative real parts make them decay. A nonzero imaginary part adds rotation.

3. Applying those signs to **both** modes gives inward spiral. A trajectory type cannot be inferred from only one eigenvalue.

4. Check: the eigenvalue signs agree with the stated long-time behaviour of the modes.

::::

:::
:::problem[Problem 17 — A center from imaginary roots]{difficulty=standard}

Classify the trajectories near the origin of $\mathbf{x}\prime=A\mathbf{x}$. Do not solve for coefficients.

$$
A=\begin{bmatrix}0&-1\\1&0\end{bmatrix}
$$

(A) Trajectory: Center.

(B) Trajectory: Saddle.

(C) Trajectory: Stable node.

(D) Trajectory: Unstable node.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Trajectory: Center.

1. Inspect the eigenvalues without solving for constants: $- i,i$. For a diagonal or triangular matrix, they are its diagonal entries.

2. Positive real parts make exponential modes grow; negative real parts make them decay. A nonzero imaginary part adds rotation.

3. Applying those signs to **both** modes gives center. A trajectory type cannot be inferred from only one eigenvalue.

4. Check: the eigenvalue signs agree with the stated long-time behaviour of the modes.

::::

:::
:::problem[Problem 18 — Two Markov transitions, not one]{difficulty=standard}

Starting from the given probability vector, compute the distribution after 2 transitions, showing the intermediate step.

$$
P=\begin{bmatrix}\frac{2}{3}&\frac{1}{3}\\\frac{1}{3}&\frac{2}{3}\end{bmatrix}
$$

$$
\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}
$$

(A) After 2 steps: $(\frac{2}{3},\frac{1}{3})^T$.

(B) After 2 steps: $(\frac{5}{9},\frac{4}{9})^T$.

(C) After 2 steps: $(\frac{14}{27},\frac{13}{27})^T$.

(D) After 2 steps: $(1,0)^T$.

(E) I don't know

::::solution[Solution]
**Answer:** (B) After 2 steps: $(\frac{5}{9},\frac{4}{9})^T$.

1. The column-stochastic matrix sends the probability vector forward by left multiplication. Start at the given $\mathbf x_0$; do not transpose $P$.

2. Step 1: multiply each row of $P$ by the previous distribution: 
   
   $$
   \mathbf x_1=P\mathbf x_0=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}
   $$

3. Step 2: multiply each row of $P$ by the previous distribution: 
   
   $$
   \mathbf x_2=P\mathbf x_1=\begin{bmatrix}\frac{5}{9}\\\frac{4}{9}\end{bmatrix}
   $$

4. Check the entries: they are nonnegative, and their sum is $1$, so the result remains a probability vector.

::::

:::
:::problem[Problem 19 — Column sums versus row sums]{difficulty=easy}

Is this a valid column-stochastic transition matrix?

$$
P=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}
$$

(A) Not column-stochastic.

(B) Valid because the rows add to $1$.

(C) Valid column-stochastic matrix.

(D) Not column-stochastic because there are fractional entries.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Valid column-stochastic matrix.

1. A column-stochastic matrix must have nonnegative entries, and every **column** must sum to one. The rows do not need to sum to one.

2. The column sums are $1$, $1$. Check every entry separately for a negative probability.

3. Both conditions hold; this is a column-stochastic matrix.

4. Check: a sum of one alone does not rescue a negative entry. The definition requires **both** conditions.

::::

:::
:::problem[Problem 20 — One is always a Markov eigenvalue]{difficulty=easy}

Which scalar must be an eigenvalue of this column-stochastic matrix?

$$
P=\begin{bmatrix}\frac{1}{2}&\frac{1}{3}\\\frac{1}{2}&\frac{2}{3}\end{bmatrix}
$$

(A) $0$ is always an eigenvalue.

(B) $-1$ is always an eigenvalue.

(C) $2$ is always an eigenvalue.

(D) $1$ is an eigenvalue.

(E) I don't know

::::solution[Solution]
**Answer:** (D) $1$ is an eigenvalue.

1. For a column-stochastic matrix, the sum of every column is one. Thus the all-ones **row** vector satisfies $\mathbf1^TP=\mathbf1^T$.

2. This means one is an eigenvalue of $P^T$. A matrix and its transpose have the same characteristic polynomial.

3. Therefore one is also an eigenvalue of $P$. This existence result does not require finding or normalizing its eigenvector.

4. Check: the determinant $\det(P-I)$ vanishes, because the columns of $P-I$ each sum to zero.

::::

:::
### Written Free Response

:::problem[Problem 21 — Cofactor expansion using the middle row]{difficulty=standard}

Find all eigenvalues of $A$ using a cofactor expansion, and show the characteristic polynomial.

$$
A=\begin{bmatrix}2&1&0\\0&3&0\\1&0&4\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Eigenvalues: $2,3,4$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}2 - \lambda&1&0\\0&3 - \lambda&0\\1&0&4 - \lambda\end{bmatrix}
   $$

2. Expand along column 3, where 2 entries vanish; the cofactor signs alternate across each row and column.

3. The surviving signed minors give 
   
   $$
   \det(A-\lambda I)=(4 - \lambda)\det\begin{bmatrix}2 - \lambda&1\\0&3 - \lambda\end{bmatrix}
   $$

4. Evaluate each $2\times2$ minor explicitly using $ad-bc$ before expanding: 
   
   $$
   +(4 - \lambda)\left[(2 - \lambda)(3 - \lambda)-(1)(0)\right]
   $$

5. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 9 \lambda^{2} - 26 \lambda + 24
   $$

6. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 4\right) \left(\lambda - 3\right) \left(\lambda - 2\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $2,3,4$.

7. Check: the root sum is $9$, which matches $\operatorname{tr}(A)=9$; their product is $24=\det A$.

**What earns the points:**

- [ ] Correct $A-\lambda I$ and cofactor signs.
- [ ] A factored characteristic polynomial.
- [ ] Complete roots with a trace check.

::::

:::
:::problem[Problem 22 — Cofactor polynomial with a complex pair]{difficulty=challenge}

Compute $\det(A-\lambda I)$ by a cofactor expansion; factor it and give the eigenvalues.

$$
A=\begin{bmatrix}2&0&-1\\0&1&0\\1&0&2\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Characteristic polynomial: $- \lambda^{3} + 5 \lambda^{2} - 9 \lambda + 5$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}2 - \lambda&0&-1\\0&1 - \lambda&0\\1&0&2 - \lambda\end{bmatrix}
   $$

2. Expand along column 2, where 2 entries vanish; the cofactor signs alternate across each row and column.

3. The surviving signed minors give 
   
   $$
   \det(A-\lambda I)=(1 - \lambda)\det\begin{bmatrix}2 - \lambda&-1\\1&2 - \lambda\end{bmatrix}
   $$

4. Evaluate each $2\times2$ minor explicitly using $ad-bc$ before expanding: 
   
   $$
   +(1 - \lambda)\left[(2 - \lambda)(2 - \lambda)-(-1)(1)\right]
   $$

5. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 5 \lambda^{2} - 9 \lambda + 5
   $$

6. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 1\right) \left(\lambda^{2} - 4 \lambda + 5\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $1,2 - i,2 + i$.

7. For the remaining quadratic, complete the square instead of guessing integer roots: 
   
   $$
   (\lambda-2)^2=-1
   $$
   
   . Taking square roots gives $\lambda=2\pm i$.

8. Check: the root sum is $5$, which matches $\operatorname{tr}(A)=5$; their product is $\left(2 - i\right) \left(2 + i\right)=\det A$.

**What earns the points:**

- [ ] Visible signed minors, not an unexplained cubic.
- [ ] Correct polynomial and factorization.
- [ ] All roots and multiplicities.

::::

:::
:::problem[Problem 23 — A repeated root that does diagonalize]{difficulty=standard}

Find a basis for the indicated eigenspace and state its dimension.

$$
A=\begin{bmatrix}2&1&0\\1&2&0\\0&0&1\end{bmatrix}
$$

Given $\lambda=1$.

::::solution[Solution]
**Answer:** Basis for $E_{1}$: $(-1,1,0)^T,(0,0,1)^T$; dimension $2$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(1)I=\begin{bmatrix}1&1&0\\1&1&0\\0&0&0\end{bmatrix}
   $$

2. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&1&0\\0&0&0\\0&0&0\end{bmatrix}
   $$

3. Pivot columns are 1; free variables are $x_2$, $x_3$. Each free variable supplies one independent eigendirection.

4. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}-1\\1\\0\end{bmatrix},\qquad\begin{bmatrix}0\\0\\1\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{1}=2$.

5. Check: $A\mathbf v_1=1\mathbf v_1$, $A\mathbf v_2=1\mathbf v_2$ for the displayed basis columns. They also solve the homogeneous equations.

**What earns the points:**

- [ ] Shifted homogeneous system.
- [ ] Row operations and free variables.
- [ ] A complete basis and its dimension.

::::

:::
:::problem[Problem 24 — Prove a three-by-three matrix is defective]{difficulty=challenge}

Determine whether $A$ is diagonalizable. Justify using eigenvalues and eigenspace dimensions.

$$
A=\begin{bmatrix}2&1&0\\0&2&1\\0&0&2\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Not diagonalizable.

1. Compute the characteristic polynomial and factor it: 
   
   $$
   - \left(\lambda - 2\right)^{3}=0.
   $$
   
   
   The eigenvalues, counted with algebraic multiplicity, are $2,2,2$.

2. For $\lambda=2$, 
   
   $$
   A-\lambda I=\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $3$.

3. The shifted matrix is already in echelon form; no row operation is needed.

4. The shifted matrix has 2 pivot columns and 1 free variables. The free-variable count is the eigenspace dimension.

5. The dimensions of the eigenspaces do **not** add to the matrix size; no invertible matrix of eigenvectors $P$ exists.

6. Check: compare geometric multiplicity to algebraic multiplicity for **each** repeated root. The repeated root alone does not decide the verdict.

**What earns the points:**

- [ ] Characteristic roots and multiplicities.
- [ ] A null-space dimension count.
- [ ] A specific reason for success or failure.

::::

:::
:::problem[Problem 25 — Construct a matrix from an eigenbasis]{difficulty=standard}

Find independent eigenvectors, construct $P,D$ and justify $A=PDP^{-1}$ without calculating $P^{-1}$.

$$
A=\begin{bmatrix}2&0\\1&3\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Columns of $P$: $(-1,1)^T,(0,1)^T$; diagonal of $D$: $2,3$.

1. Find the characteristic roots first: 
   
   $$
   \left(\lambda - 3\right) \left(\lambda - 2\right)=0.
   $$
   
   
   The roots are $2,3$.

2. Solve $\operatorname{Nul}(A-(2)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}-1\\1\end{bmatrix}
   $$

3. The shifted system begins with 
   
   $$
   A-(2)I=\begin{bmatrix}0&0\\1&1\end{bmatrix}
   $$

4. Swap $R_1$ with $R_2$ to put a nonzero pivot first. 
   
   $$
   \begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

5. There are 1 free variables. Set them independently to obtain the displayed eigenbasis.

6. Solve $\operatorname{Nul}(A-(3)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}0\\1\end{bmatrix}
   $$

7. The shifted system begins with 
   
   $$
   A-(3)I=\begin{bmatrix}-1&0\\1&0\end{bmatrix}
   $$

8. Divide row 1 by $-1$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&0\\1&0\end{bmatrix}
   $$

9. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

10. There are 1 free variables. Set them independently to obtain the displayed eigenbasis.

11. There are 2 independent eigenvectors. Put them in columns of $P$; put their eigenvalues in the **matching** order on the diagonal of $D$: 
   
   $$
   P=\begin{bmatrix}-1&0\\1&1\end{bmatrix},\qquad D=\begin{bmatrix}2&0\\0&3\end{bmatrix}
   $$

12. Check multiplication directly, without wasting time finding $P^{-1}$: 
   
   $$
   AP=\begin{bmatrix}-2&0\\2&3\end{bmatrix}=PD=\begin{bmatrix}-2&0\\2&3\end{bmatrix}
   $$
   
   
   Since $\det P=-1\ne0$, $P$ is invertible and $A=PDP^{-1}$.

13. If you need to reconstruct $A$ from $P$ and $D$, use the equivalent relation $AP=PD$ or multiply $PDP^{-1}$; the column matching is the real reason the calculation works.

**What earns the points:**

- [ ] Eigenvalues and basis columns.
- [ ] Consistent order in $P,D$.
- [ ] The check $AP=PD$ and invertibility of $P$.

::::

:::
:::problem[Problem 26 — Build a real block from a complex vector]{difficulty=challenge}

The real vectors $\mathbf p,\mathbf q$ are the real and imaginary parts of a complex eigenvector for $A$. Form $P=[\mathbf p\ \mathbf q]$, compute $C=P^{-1}AP$ by the relation $AP=PC$, and identify the corresponding eigenvalue $a-bi$.

$$
A=\begin{bmatrix}2&-2\\1&0\end{bmatrix}
$$

$$
\mathbf p=\begin{bmatrix}1\\0\end{bmatrix},\qquad\mathbf q=\begin{bmatrix}1\\1\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Real block diagonals $1,1$; off-diagonals $-1,1$.

1. Split the given complex eigenvector as $\mathbf v=\mathbf p+i\mathbf q$. The stated real column order is $P=[\mathbf p\ \mathbf q]$: 
   
   $$
   P=\begin{bmatrix}1&1\\0&1\end{bmatrix}
   $$

2. Compute how $A$ acts on these two real columns: 
   
   $$
   A\mathbf p=\begin{bmatrix}2\\1\end{bmatrix},\qquad A\mathbf q=\begin{bmatrix}0\\1\end{bmatrix}
   $$

3. Express those images in the basis $\mathbf p,\mathbf q$. The coefficient columns give 
   
   $$
   C=\begin{bmatrix}1&-1\\1&1\end{bmatrix}
   $$
   
   
   so $AP=PC$.

4. With this convention, 
   
   $$
   C=\begin{bmatrix}a&-b\\b&a\end{bmatrix}
   $$
   
   
   The corresponding complex eigenvalue is $a-bi=1 - i$. This sign follows by expanding $A(\mathbf p+i\mathbf q)$.

5. Check: 
   
   $$
   AP=\begin{bmatrix}2&0\\1&1\end{bmatrix}=PC=\begin{bmatrix}2&0\\1&1\end{bmatrix}
   $$
   
   
   Also $\det P=1\ne0$, so this is a genuine real change of basis.

**What earns the points:**

- [ ] Real and imaginary eigenvector parts.
- [ ] The signed real block.
- [ ] The equality $AP=PC$.

::::

:::
:::problem[Problem 27 — Solve a non-diagonal decay-and-growth IVP]{difficulty=challenge}

Solve $\mathbf{x}\prime(t)=A\mathbf{x}(t)$ with the specified initial vector. Give the qualitative trajectory type and check the initial condition.

$$
A=\begin{bmatrix}1&1\\0&-2\end{bmatrix}
$$

$$
\mathbf{x}(0)=\begin{bmatrix}2\\3\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Solution: $\mathbf{x}(t)=(3 e^{t} - e^{- 2 t},3 e^{- 2 t})^T$; saddle.

1. The eigenvalues are $-2,1$. Solve their homogeneous systems and choose eigenvector columns: 
   
   $$
   P=\begin{bmatrix}-1&1\\3&0\end{bmatrix},\qquad D=\begin{bmatrix}-2&0\\0&1\end{bmatrix}
   $$

2. Because each eigenvector satisfies $A\mathbf v_j=\lambda_j\mathbf v_j$, a solution along it has factor $e^{\lambda_jt}$. Add these modes: 
   
   $$
   \mathbf x(t)=c_1e^{-2t}\begin{bmatrix}-1\\3\end{bmatrix} + c_2e^{1t}\begin{bmatrix}1\\0\end{bmatrix}
   $$

3. At $t=0$, every exponential equals one, so $P\mathbf c=\mathbf x_0$. Substitute the initial vector and solve the ordinary linear equations; the constants are 
   
   $$
   \mathbf c=\begin{bmatrix}1\\3\end{bmatrix}
   $$

4. Insert those coefficients into the exponential modes and combine components: 
   
   $$
   \mathbf x(t)=\begin{bmatrix}3 e^{t} - e^{- 2 t}\\3 e^{- 2 t}\end{bmatrix}
   $$
   
   
   The eigenvalue signs identify the trajectory as saddle.

5. Check: at zero this becomes 
   
   $$
   \mathbf x(0)=\begin{bmatrix}2\\3\end{bmatrix}
   $$
   
   
   which equals the stated starting vector. Differentiating each eigenmode gives $\mathbf x\prime=A\mathbf x$.

**What earns the points:**

- [ ] Eigenmodes and correct exponentials.
- [ ] Initial-condition equations for coefficients.
- [ ] Solution and verification.

::::

:::
:::problem[Problem 28 — Solve a spiral IVP in real coordinates]{difficulty=challenge}

Solve $\mathbf{x}\prime(t)=A\mathbf{x}(t)$ with the specified initial vector. Give the qualitative trajectory type and check the initial condition.

$$
A=\begin{bmatrix}-1&-1\\1&-1\end{bmatrix}
$$

$$
\mathbf{x}(0)=\begin{bmatrix}1\\0\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Solution: $\mathbf{x}(t)=(e^{- t} \cos{\left(t \right)},e^{- t} \sin{\left(t \right)})^T$; inward spiral.

1. The characteristic polynomial is $\lambda^{2} + 2 \lambda + 2$, so the eigenvalues are $-1 - i,-1 + i$. Their common real part sets decay or growth.

2. The matrix is a real rotation–scaling generator; write the solution using $e^{at}$ times sine and cosine. Choose the orientation from the off-diagonal entries, not by guessing a sign.

3. Apply the given initial vector at $t=0$. The resulting real-valued solution is 
   
   $$
   \mathbf x(t)=\begin{bmatrix}e^{- t} \cos{\left(t \right)}\\e^{- t} \sin{\left(t \right)}\end{bmatrix}
   $$

4. The real part $-1$ is negative, so the origin is an inward spiral; its imaginary part gives angular motion.

5. Check both requirements: 
   
   $$
   \mathbf x(0)=\begin{bmatrix}1\\0\end{bmatrix},\qquad\mathbf x\prime(t)=\begin{bmatrix}- e^{- t} \sin{\left(t \right)} - e^{- t} \cos{\left(t \right)}\\- e^{- t} \sin{\left(t \right)} + e^{- t} \cos{\left(t \right)}\end{bmatrix}
   $$
   
   
   The derivative agrees with $A\mathbf x(t)$ by direct multiplication.

**What earns the points:**

- [ ] Correct complex eigenpair.
- [ ] Real sine-cosine solution with the correct signs.
- [ ] Initial condition and differential-equation check.

::::

:::
:::problem[Problem 29 — Three-state probability balance]{difficulty=challenge}

Find the normalized steady-state probability vector of the column-stochastic matrix $P$.

$$
P=\begin{bmatrix}\frac{1}{2}&\frac{1}{4}&0\\\frac{1}{2}&\frac{1}{2}&\frac{1}{2}\\0&\frac{1}{4}&\frac{1}{2}\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Steady state: $(\frac{1}{4},\frac{1}{2},\frac{1}{4})^T$.

1. Check the column convention: every entry is nonnegative, and the columns of $P$ sum to one. Seek a probability vector satisfying $P\mathbf q=\mathbf q$.

2. Move all terms to the same side: 
   
   $$
   (P-I)\mathbf q=\mathbf0,\qquad P-I=\begin{bmatrix}- \frac{1}{2}&\frac{1}{4}&0\\\frac{1}{2}&- \frac{1}{2}&\frac{1}{2}\\0&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

3. Divide row 1 by $- \frac{1}{2}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{1}{2}&0\\\frac{1}{2}&- \frac{1}{2}&\frac{1}{2}\\0&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(\frac{1}{2})R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&- \frac{1}{2}&0\\0&- \frac{1}{4}&\frac{1}{2}\\0&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

5. Divide row 2 by $- \frac{1}{4}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{1}{2}&0\\0&1&-2\\0&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

6. Use $R_1\leftarrow R_1-(- \frac{1}{2})R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&-1\\0&1&-2\\0&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

7. Use $R_3\leftarrow R_3-(\frac{1}{4})R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&-1\\0&1&-2\\0&0&0\end{bmatrix}
   $$

8. The null-space equations give a direction 
   
   $$
   \mathbf v=\begin{bmatrix}1\\2\\1\end{bmatrix}
   $$
   
   
   This direction is not yet a probability vector unless its coordinates add to one.

9. Divide the nonnegative direction by the sum of its coordinates. The normalized steady state is 
   
   $$
   \mathbf q=\begin{bmatrix}\frac{1}{4}\\\frac{1}{2}\\\frac{1}{4}\end{bmatrix}
   $$

10. Check: 
   
   $$
   P\mathbf q=\begin{bmatrix}\frac{1}{4}\\\frac{1}{2}\\\frac{1}{4}\end{bmatrix}=\mathbf q,\qquad\sum q_i=1.
   $$
   
   
   All coordinates are nonnegative, which completes the probability requirement.

**What earns the points:**

- [ ] $(P-I)\mathbf q=0$ and null-space algebra.
- [ ] Nonnegative sum-to-one normalization.
- [ ] Direct $P\mathbf q=\mathbf q$ check.

::::

:::
:::problem[Problem 30 — Nonuniform steady state and two-step update]{difficulty=challenge}

Starting from the given probability vector, compute the distribution after 2 transitions, showing the intermediate step. Also calculate the steady state.

$$
P=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}
$$

$$
\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}
$$

::::solution[Solution]
**Answer:** After 2 steps: $(\frac{11}{16},\frac{5}{16})^T$. Steady state: $(\frac{2}{3},\frac{1}{3})^T$.

1. The column-stochastic matrix sends the probability vector forward by left multiplication. Start at the given $\mathbf x_0$; do not transpose $P$.

2. Step 1: multiply each row of $P$ by the previous distribution: 
   
   $$
   \mathbf x_1=P\mathbf x_0=\begin{bmatrix}\frac{3}{4}\\\frac{1}{4}\end{bmatrix}
   $$

3. Step 2: multiply each row of $P$ by the previous distribution: 
   
   $$
   \mathbf x_2=P\mathbf x_1=\begin{bmatrix}\frac{11}{16}\\\frac{5}{16}\end{bmatrix}
   $$

4. Check the entries: they are nonnegative, and their sum is $1$, so the result remains a probability vector.

5. For the extra steady-state request solve $(P-I)\mathbf q=0$ and normalize the null-space vector; the result is 
   
   $$
   \mathbf q=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}
   $$

**What earns the points:**

- [ ] A separate multiplication for every step.
- [ ] Exact probability fractions.
- [ ] Normalization and any requested steady state.

::::

:::
